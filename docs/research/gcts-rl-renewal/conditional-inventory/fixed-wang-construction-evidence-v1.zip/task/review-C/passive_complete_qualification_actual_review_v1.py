"""C-owned complete saved-data joins only. No construction, simulation or replay."""
import hashlib
import json
from pathlib import Path
from collections import Counter

F=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021')
C=F/'review-C';R=F/'root';BASE=F.parents[1];checked={}

def need(value,message):
    if not value:raise ValueError(message)

def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode('ascii')

def same(left,right):return canonical(left)==canonical(right)

def digest(value):return hashlib.sha256(canonical(value)).hexdigest()

def pin(path):
    path=Path(path)
    need(path.is_absolute() and path.resolve()==path and path.is_file() and not path.is_symlink(),'canonical ordinary raw file')
    body=path.read_bytes();value=dict(path=str(path),bytes=len(body),sha256=hashlib.sha256(body).hexdigest())
    if str(path) in checked:need(checked[str(path)]==value,'current raw body stable')
    checked[str(path)]=value;return value

def verify(value):
    need(set(value)=={'path','bytes','sha256'} and type(value['bytes']) is int and pin(value['path'])==value,'exact current pin');return value

def unique(pairs):
    value={}
    for key,item in pairs:
        need(key not in value,'duplicate JSON key');value[key]=item
    return value

def decode(body):
    return json.loads(body,object_pairs_hook=unique,parse_constant=lambda text:(_ for _ in ()).throw(ValueError(text)))

def load(value):
    if isinstance(value,(Path,str)):value=pin(value)
    verify(value);need('.partial' not in Path(value['path']).name,'never parse partial body')
    return decode(Path(value['path']).read_bytes())

def passed(value):
    need(value['review_passed'] is True and value['checks'] and all(row['passed'] is True for row in value['checks']) and value['failures']==[],'current independent prior allPASS')

offer_pin=pin(R/'qualification-terminal-review-offer-v1.json');offer=load(offer_pin)
need((offer_pin['bytes'],offer_pin['sha256'])==(6289,'6c48acbc8b23edbd951a34a225a6980a135802248839bccad7f9bc57a51998ae'),'exact complete terminal offer')
whole=load(offer['whole_Source_review']);passed(whole)
grant_review=load(offer['grant_component_review']);passed(grant_review)
plan=load(offer['plan']);protocol=load(offer['protocol']);proposal=load(offer['proposal'])
need(offer['plan']==whole['plan']==grant_review['plan'] and offer['protocol']==whole['protocol']
     and offer['proposal']==grant_review['proposal'],'same exact current reviewed composition')
need(len(plan['files'])==25 and sorted(plan['files'],key=lambda row:row['path'])==whole['input_pins']
     and plan['limits']==whole['limits']==protocol['limits'],'all25 original guards/caps')
for row in plan['files']:verify(row)
grant=load(offer['grant']);barrier=load(offer['barrier']);invocation=load(offer['invocation'])
need(grant['schema']=='Root-fixed-Wang-once-execution-grant-v1'
     and grant['status']=='AUTHORIZED_ONCE_AFTER_CURRENT_C_AND_FRESH_IDLE_BARRIER'
     and grant['authorized'] is True and grant['review_passed'] is True
     and type(grant['uses']) is int and grant['uses']==1,'distinct actual once execution grant')
need(grant['plan']==offer['plan'] and grant['plan_sha256']==offer['plan']['sha256']
     and grant['runner_sha256']==whole['runner']['sha256']
     and grant['proposal']==offer['proposal'] and grant['whole_Source_plan_review']==offer['whole_Source_review']
     and grant['grant_component_review']==offer['grant_component_review']
     and grant['fresh_tools_idle_barrier']==offer['barrier'],'grant binds exact plan/proposal/C/barrier')
need(barrier['plan']==offer['plan'] and barrier['reviews']==[offer['whole_Source_review'],offer['grant_component_review']]
     and barrier['current_guard_count']==25 and barrier['current_guards_match'] is True
     and barrier['actual_observer_and_execution_grant_absent'] is True
     and barrier['Root_tool_sessions_running']==barrier['browser_network_preview_tools_running']==barrier['scientific_actuals_running']==[]
     and all(value=='COMPLETED_TOOLS_IDLE' for value in barrier['agents'].values()),'Root-labeled fresh idle barrier')
need(invocation['plan']==offer['plan'] and invocation['grant']==offer['grant']
     and invocation['invocations']==1 and invocation['tool_exit_code']==0 and invocation['no_rescue_rerun_or_probe'] is True,'Root-labeled once terminal invocation, not independent timing')

actual=Path(plan['actual_dir']);observed=Path(str(actual)+'.observer')
physical=[]
for directory in (actual,observed):
    need(directory.is_dir() and directory.resolve()==directory and not directory.is_symlink(),'exact owned actual directory')
    for path in sorted(directory.rglob('*')):
        need(not path.is_symlink(),'no actual symlink')
        if path.is_file():physical.append(pin(path))
physical.sort(key=lambda row:row['path'])
need(physical==sorted(offer['raw_census'],key=lambda row:row['path'])
     and len(physical)==offer['raw_file_count']==10
     and sum(row['bytes'] for row in physical)==offer['raw_bytes']==1335233
     and offer['partial_count']==0 and all('.partial' not in row['path'] for row in physical),'entire postterminal10-file raw census, zero partials')
pins={Path(row['path']).name:row for row in physical if Path(row['path']).parent==actual}
result_pin=pins['result.json'];header_pin=pins['worker-header.json'];terminal_pin=pins['terminal.json'];observer_pin=pin(observed/'observer.json')
need((result_pin['bytes'],result_pin['sha256'])==(1328693,'ec080f1764949cc5b3a217fc5c25bd211f41934b946dd7fd12f8f8ff25b68b88'),'exact full result')
result,header,terminal,observer=load(result_pin),load(header_pin),load(terminal_pin),load(observer_pin)
consumed,owner=load(pins['CONSUMED.json']),load(pins['owned-child.json'])
need(consumed==dict(schema='proof-search-case-consumed-v1',case_id=plan['case_id'],uses=1,
                   plan_sha256=offer['plan']['sha256'],grant_sha256=offer['grant']['sha256']),'exact fresh once consumption')
need(owner==observer['owned_child'] and owner['schema']=='Root-owned-child-group-v1'
     and owner['case_id']==plan['case_id'] and owner['plan_sha256']==offer['plan']['sha256']
     and owner['parent_pid']==20206 and owner['child_pid']==owner['child_pgid']==20208,'owned current parent/child/group joins')
need(offer['owned_handles_after_terminal']==[dict(absent=True,pid=20206,role='parent'),dict(absent=True,pid=20208,role='child')],'Root-reported owner absence; C makes no live probe')
need(result['schema']=='proof-search-case-worker-v1' and result['status']=='COMPLETE'
     and result['stage']=='qualify' and result['case_id']==plan['case_id'] and result['worker_version']=='fixed-Wang-qualification-worker-v1'
     and result['source_unchanged'] is True and result['first_Root_fault'] is False and result['error'] is None
     and result['qualification_complete'] is True and result['scientific_result'] is None
     and result['old_qualification_reused'] is False and result['full_physical_Wang_claim'] is False,'complete finite qualification only')
need(result['native_requests_started']==result['native_peak_bytes']==0 and result['native_queries']==[]
     and result['guard_compilations']==result['work_snapshots']==[]
     and result['native_transport']['closed'] is True and result['native_transport']['all_reaped'] is True
     and result['native_transport']['subprocesses_started']==result['native_transport']['native_exit_code']==result['native_transport']['native_high_water_bytes']==0,'literal vacuous absence of Native')
need(header['status']=='COMPLETE' and header['result']==result_pin and header['source_unchanged'] is True
     and header['first_Root_fault'] is False and header['native_closed_and_reaped'] is True
     and header['native_peak_bytes']==0 and header['native_scope']=='VACUOUS_NO_NATIVE_SUBPROCESS'
     and header['callbacks']==result['callbacks']+1==52828,'post-serialization checkpoint explains distinct result/header callback counts')
need(terminal['process_exit_code']==0 and terminal['header_valid'] is True and terminal['header']==header
     and terminal['result']==result_pin and terminal['reason'] is None and terminal['errors']==[]
     and terminal['sources_unchanged'] is True and terminal['threads_terminal'] is True
     and terminal['final_custody_gate_passed'] is True and terminal['old_qualification_reused'] is False,'complete parent output/EOF/custody gate')
caps=plan['limits']
for logs,directory,cap in [(terminal['logs'],actual,caps['log_bytes']),(observer['logs'],observed,1048576)]:
    for label,row in logs.items():
        q=pin(directory/(label+'.bin'))
        need(row['eof'] is True and row['overflow'] is False and row['bytes']==row['stored']==q['bytes']<=cap,'full bounded log with EOF')
need(pins['stderr.bin']['bytes']==0 and pin(observed/'stderr.bin')['bytes']==0,'no stderr')
worker_stdout=decode((actual/'stdout.bin').read_bytes());parent_stdout=decode((observed/'stdout.bin').read_bytes())
need(parent_stdout==terminal and worker_stdout['case_id']==plan['case_id']
     and worker_stdout['status']=='COMPLETE' and worker_stdout['callbacks']==header['callbacks'],'complete raw stdout joins, timestamps kept distinct')
need(result['elapsed_seconds']<caps['work_seconds'] and result['elapsed_seconds']<=header['seconds']<=worker_stdout['seconds']<=terminal['known_exit_seconds']<=caps['positive_seconds']
     and terminal['final_custody_gate_seconds']<=caps['custody_seconds'],'direct distinct worker/header/exit/custody clocks')
need(observer['parent_exit_code']==0 and observer['resource_candidate_before_receipt'] is True
     and observer['resource_candidate_accepted'] is True and observer['reason'] is None and observer['errors']==[]
     and observer['fallback_trigger_seconds'] is None and observer['partial_files_parsed'] is False
     and observer['known_parent_exit_seconds']<=observer['elapsed_seconds']<=observer['final_observer_gate_seconds']<=caps['custody_seconds'],'whole observer gates, ordinary210 distinct from fallback225')
terminal_peak=terminal['parent_usage']['ru_maxrss']+max(terminal['child_usage']['ru_maxrss'],header['python_peak_after_output_bytes'])+header['native_peak_bytes']+9437184
whole_peak=terminal_peak+observer['final_observer_peak_bytes']+9437184
need(terminal_peak==terminal['conservative_combined_peak_bytes']==110133248
     and whole_peak==observer['final_conservative_whole_peak_bytes']==141377536<caps['memory_bytes'],'strict final conservative whole memory with both reserves')
need(result_pin['bytes']<=caps['result_bytes'] and len(physical)==10
     and sum(row['bytes'] for row in physical if Path(row['path']).parent==actual and Path(row['path']).name!='terminal.json')==terminal['stored_bytes_before_terminal_receipt']
     and sum(row['bytes'] for row in physical if row['path']!=observer_pin['path'])==observer['stored_bytes_before_observer_receipt']
     and sum(row['bytes'] for row in physical)<=caps['physical_bytes'],'complete byte accounting before/after receipts')
need([row['name'] for row in result['stages']]==['IMPORT exact frozen compiler','IMPORT exact independent bank','RUN all45 construction controls']
     and all(row['status']=='COMPLETED' and row['began']>=0 and row['seconds']>=0 for row in result['stages']),'all charged stages complete, nested clocks not added')

qualification=result['qualification_result'];controls=qualification['controls'];by_id={row['id']:row['evidence'] for row in controls}
need(qualification['schema']=='independent-fixed-Wang-qualification-v1' and qualification['complete'] is True
     and type(qualification['control_count']) is int and qualification['control_count']==45
     and type(qualification['passed_count']) is int and qualification['passed_count']==45
     and qualification['failures']==[] and qualification['subject_version']=='deterministic-single-head-framed-Wang-v1'
     and [row['id'] for row in controls]==protocol['control_order']==whole['control_order']
     and len(by_id)==45 and all(set(row)=={'id','passed','evidence'} and row['passed'] is True for row in controls),'all45 complete original rows, no subset')
defs=load(F/'diagnostics-L/fixed-Wang-qualification-control-definitions-v1.json')
main_machine=defs['literal_machine'];palette_records=[];palettes=[]

def ext(cell):
    # Representation-only tag join; never a machine transition.
    if cell[0]=='T':return ['symbol',cell[1]]
    need(cell[0]=='H','literal reference cell tag');return ['head',cell[1],cell[2]]

for ordinal in (0,1):
    evidence=controls[ordinal]['evidence'];machine=evidence['machine'];palette=evidence['full_actual_palette']
    if ordinal==0:need(same(machine,main_machine),'main machine exact literal')
    else:need({key:value for key,value in machine.items() if key!='start'}=={key:value for key,value in main_machine.items() if key!='start'} and machine['start']=='acc','only declared accepting-start variant')
    need(evidence['whole_relation_complete'] is True and evidence['witness_validation_is_separate'] is True
         and palette['machine']==machine and palette['machine_sha256']==digest(machine),'full completed machine-bound observation')
    need(palette['schema']=='framed-deterministic-Wang-palette-v1' and palette['version']=='deterministic-single-head-framed-Wang-v1'
         and palette['transformations']=='integer-grid translations only; no rotation/reflection'
         and palette['layout']=='one input selector row; zero or more core rows; one accepting cap row; two persistent side-wall columns','exact saved palette schema/layout/transform scope')
    triples=evidence['full_expected_local_triples'];frame=evidence['full_expected_frame'];colors=palette['colors'];tiles=palette['tiles']
    need(len(triples)==3840 and len(frame)==51 and len(tiles)==571 and len(colors)==143,'literal completed per-palette cardinalities')
    def valid(cell):
        return (type(cell) is list and ((len(cell)==2 and cell[0]=='symbol' and cell[1] in machine['symbols']) or (len(cell)==3 and cell[0]=='head' and cell[1] in machine['states'] and cell[2] in machine['symbols'])))
    expected_map={};reason_counts=Counter()
    for row in triples:
        need(set(row)=={'old','new','reason','reference_context'} and len(row['old'])==3,'saved expected triple fields')
        a,b,c=row['old'];need((a==['wall','left'] or valid(a)) and valid(b) and (c==['wall','right'] or valid(c)),'every saved triple in the exact finite domain')
        key=canonical(row['old']);need(key not in expected_map,'unique saved expected triple');expected_map[key]=row
        heads=sum(cell[0]=='head' for cell in row['old']);reason_counts[row['reason']]+=1
        if heads==0:need(row['reason']=='plain-copy' and row['new']==b and row['reference_context'] is None,'saved no-head copy observation')
        elif heads>1:need(row['reason']=='multiple-heads' and row['new'] is None and row['reference_context'] is None,'saved forbidden multihead observation')
        else:
            context=row['reference_context'];need(set(context)=={'old','new','center'} and type(context['center']) is int,'full saved independent context')
            center=context['center'];need(ext(context['old'][center])==b,'saved reference center joins old center')
            if a==['wall','left']:need(center==0,'left ghost context alignment')
            else:need(center==2 and ext(context['old'][1])==a and context['old'][0]==['T',machine['blank']],'saved left un-walled padding')
            if c==['wall','right']:need(len(context['old'])==center+1,'right ghost context alignment')
            else:need(ext(context['old'][center+1])==c and context['old'][center+2]==['T',machine['blank']] and len(context['old'])==center+3,'saved right un-walled padding')
            if row['new'] is None:need(row['reason']=='center-wall-exit' and context['new'] is None,'saved reference wall exit')
            else:need(row['reason']=='global-context-projection' and valid(row['new']) and context['new'] is not None and ext(context['new'][center])==row['new'],'saved reference projection joins emitted new center; no transition replay')
    # Typed unique3840 entries fill the finite16*15*16 domain by cardinality; no cube is regenerated.
    need(len(expected_map)==(len(machine['symbols'])*(len(machine['states'])+1)+1)**2*(len(machine['symbols'])*(len(machine['states'])+1)),'full saved domain coverage by typed cardinality')
    need(reason_counts=={'multiple-heads':3312,'global-context-projection':472,'plain-copy':48,'center-wall-exit':8},'entire saved reason census')
    actual_core={};actual_frame=[];decoded_records=[];used_colors=set();edge_tuples=set()
    for index,tile in enumerate(tiles):
        need(type(tile['id']) is int and tile['id']==index and set(tile)=={'id','kind','north','east','south','west','certificate'},'all indexed saved tile records')
        ports={name:colors[tile[name]] for name in ('north','east','south','west')}
        need(all(type(tile[name]) is int and 0<=tile[name]<len(colors) for name in ports),'strict color IDs')
        signature=tuple(ports[name] for name in ('north','east','south','west'));need(signature not in edge_tuples,'no duplicate ordinary tile tuple');edge_tuples.add(signature);used_colors.update(signature)
        decoded=dict(kind=tile['kind'],certificate=tile['certificate'],**ports);decoded_records.append(decoded)
        if tile['kind']=='core':
            certificate=tile['certificate'];key=canonical(certificate['old']);expected=expected_map[key]
            need(set(certificate)=={'old','new'} and expected['new'] is not None and certificate['new']==expected['new'] and key not in actual_core,'each core certificate joins one saved defined expectation')
            a,b,c=certificate['old'];need(decode(ports['north'])==['configuration',b] and decode(ports['south'])==['configuration',certificate['new']] and decode(ports['west'])==['old-pair',a,b] and decode(ports['east'])==['old-pair',b,c],'all core ports join saved certificate fields')
            actual_core[key]=tile['id']
        else:actual_frame.append(decoded)
    need(set(actual_core)=={key for key,row in expected_map.items() if row['new'] is not None}
         and Counter(canonical(row) for row in actual_frame)==Counter(canonical(row) for row in frame)
         and colors==sorted(used_colors) and decoded_records==sorted(decoded_records,key=canonical),'entire emitted core/frame/colors/order equals saved independent expectations')
    palette_records.append(dict(control_id=controls[ordinal]['id'],machine_sha256=digest(machine),palette_sha256=digest(palette),tiles=571,colors=143,expected_triples=3840,defined_core_records=520,expected_frame_records=51,reason_counts=dict(reason_counts)))
    palettes.append(palette)

for ordinal in range(2,7):
    evidence=controls[ordinal]['evidence'];need(evidence['actual']==[ext(cell) for cell in evidence['expected']],'literal global-step observed output equals saved manual expectation')
refusal_messages={
 'width1-left-wall-refusal':'head cannot cross either finite wall','width1-right-wall-refusal':'head cannot cross either finite wall',
 'global-no-head-refusal':'global reference requires exactly one head','global-distant-two-head-refusal':'global reference requires exactly one head',
 'input-no-head-refusal':'exactly one prescribed start head; free cells never contain heads','input-distant-two-head-refusal':'exactly one prescribed start head; free cells never contain heads',
 'input-free-head-refusal':'free plain-symbol input cell','machine-bool-move-refusal':'typed nonhalt deterministic transition',
 'machine-duplicate-transition-refusal':'duplicate/ambiguous transition','machine-missing-transition-refusal':'total delta on every nonhalt state/symbol',
 'codec-duplicate-key-refusal':'duplicate JSON key','codec-nonfinite-refusal':'nonfinite JSON constant','codec-boolean-not-machine':'exact deterministic machine schema',
 'bool-step-count-refusal':'exact nonnegative computational step count','tableau-fixed-input-corruption-refusal':'vertical local equality/top input',
 'tableau-core-corruption-refusal':'horizontal local equality/left frame','tableau-bool-ID-refusal':'exact tile ID, bool refused',
 'tableau-missing-row-refusal':'full rectangular tableau','point-bool-ID-refusal':'exact translated tile/cell indices','point-bool-coordinate-refusal':'exact translated tile/cell indices'}
for identity,message in refusal_messages.items():need(by_id[identity]==dict(owned_refusal='Invalid',message=message),'all20 exact saved private-owner refusal observations')

witness_rows=[]
for ordinal in range(21,27):
    evidence=controls[ordinal]['evidence'];palette=palettes[1 if ordinal==26 else 0];machine=palette['machine'];boundary=evidence['boundary'];receipt=evidence['receipt'];tableau=evidence['tableau']
    declaration=defs['literal_trajectories'][ordinal-21] if ordinal<26 else defs['zero_step_literal']
    configurations=[[ext(cell) for cell in row] for row in declaration['rows']]
    need(receipt['schema']=='framed-Wang-tableau-check-v1' and receipt['accepted'] is True and receipt['complete'] is True
         and receipt['configurations']==configurations and boundary['input']['cells']==declaration['cells'],'every saved witness receipt equals original declared configurations')
    need(receipt['machine_sha256']==boundary['machine_sha256']==digest(machine)
         and receipt['palette_sha256']==boundary['palette_sha256']==digest(palette)
         and receipt['width']==boundary['width']==len(declaration['cells'])+2
         and receipt['height']==boundary['height']==len(declaration['rows'])+1
         and receipt['steps']==boundary['steps']==len(declaration['rows'])-1,'exact witness machine/palette/boundary dimensions and hashes')
    if ordinal<26:need(evidence['origin']=='constructed qualification witness from literal independently checked trajectory; not search' and evidence['input']==boundary['input'],'supplied witness attribution exact')
    height,width=boundary['height'],boundary['width'];need(len(tableau)==height and all(len(row)==width for row in tableau),'complete saved rectangle')
    need(boundary['schema']=='framed-deterministic-Wang-boundary-v1'
         and decode(palette['colors'][boundary['north'][0]])==['top','left']
         and decode(palette['colors'][boundary['north'][-1]])==['top','right']
         and all(decode(palette['colors'][value])==['outer','bottom'] for value in boundary['south'])
         and all(decode(palette['colors'][value])==['outer','left'] for value in boundary['west'])
         and all(decode(palette['colors'][value])==['outer','right'] for value in boundary['east']),'full saved fixed exterior label scope')
    for index,descriptor in enumerate(boundary['input']['cells']):
        need(decode(palette['colors'][boundary['north'][index+1]])==['input']+descriptor,'each fixed top input descriptor joins its saved color')
    selected=[]
    for y,row in enumerate(tableau):
        for x,identity in enumerate(row):
            need(type(identity) is int and 0<=identity<len(palette['tiles']),'strict selected current tile ID');tile=palette['tiles'][identity];selected.append(identity)
            need(tile['west']==(boundary['west'][y] if x==0 else palette['tiles'][row[x-1]]['east'])
                 and tile['north']==(boundary['north'][x] if y==0 else palette['tiles'][tableau[y-1][x]]['south']),'saved adjacency/perimeter literal joins')
            if x==width-1:need(tile['east']==boundary['east'][y],'saved right perimeter join')
            if y==height-1:need(tile['south']==boundary['south'][x],'saved bottom perimeter join')
            if 0<x<width-1:
                if y==0:need(decode(palette['colors'][tile['south']])==['configuration',configurations[0][x-1]],'saved selector-to-input configuration join')
                elif y<height-1:
                    certificate=tile['certificate'];need(certificate['old'][1]==configurations[y-1][x-1] and certificate['new']==configurations[y][x-1],'saved core certificate-to-existing configuration joins')
                else:need(decode(palette['colors'][tile['north']])==['configuration',configurations[-1][x-1]],'saved cap-to-final configuration join')
    witness_rows.append(dict(id=controls[ordinal]['id'],machine_sha256=digest(machine),palette_sha256=digest(palette),width=width,height=height,steps=boundary['steps'],supplied_tableau_cells=len(selected),qualification_witness_not_search=True))
for ordinal,expected in zip(range(27,32),[False,False,False,False,True]):need(controls[ordinal]['evidence']['accepted_by_complete_cap_relation'] is expected,'five saved cap-language outcomes, no cap-path replay')
point=by_id['point-placement-literal'];need(point['actual']==point['expected'] and point['actual']['key']==[30,0,0]
     and point['actual']['occupancy']==[[[1,1],12]] and len(point['actual']['marks'])==4
     and any(mark[1]==0 for mark in point['actual']['marks']),'literal center/ports and assigned zero')
point_boundary=by_id['point-boundary-width1-literal'];pb=point_boundary['actual']
need(pb['roots']==point_boundary['expected_roots'] and len(pb['roots'])==9 and pb['capacity']==12
     and pb['initial_totals']==[] and pb['generations']==[[point,0] for point in pb['roots']]
     and len(pb['initial_marks'])==12,'full saved point boundary/root/generation observation')
apis=['decode_document','parse_machine','parse_input','compile_palette','make_boundary','machine_step','validate_tableau','point_placement','point_boundary']
for ordinal,kind in zip(range(40,45),['RuntimeError','ValueError','StopIteration','Invalid','JSONDecodeError']):
    evidence=controls[ordinal]['evidence'];need(evidence['class_name']==kind and evidence['exact_identity'] is True
         and evidence['first_callback_escapes']==[dict(API=name,exact_identity=True) for name in apis],'all45 saved first-callback exact-identity observations; no object reconstruction')

for value in tuple(checked.values()):verify(value)
checks=[
 ('exact-once-plan-grant-barrier-consumption-and25guards','Current full Source/plan and grant-component reviews join the distinct execution grant, exact proposal and fresh Root-labeled idle barrier. CONSUMED binds plan/grantSHA/case/uses1. All25 Source/runtime/semantic pins remain unchanged. Root invocation reports one terminalexit0 without rescue; C verifies saved custody and does not independently attest live scheduling.'),
 ('complete-owned10file-custody-and-no-prefix','The full current actual+observer census is exactly10 ordinary files/1,335,233 bytes with zero partials. Owned parent20206/worker/group20208 agree across raw ownership and observer; Root reports both absent, with no live C probe. Result, post-output header, parent terminal/stdout and observer bind the same complete packet; all logs reach EOF, stderr/errors are empty and cleanup is complete. No prefix, previous result or FPC-H1 input is adopted.'),
 ('all-original-resource-gates-and-distinct-clocks','Original work160/positive180/custody210/fallback225 and byte/callback caps remain unchanged. Exact observer.elapsed_seconds is0.43236604100093246; later finalgate0.43269420800788794 and toolsummary0.4330988330038963 are distinct. Conservative wholepeak141,377,536 bytes follows parent+maxchild/postoutputHWM+observer+reserves, strictly below1GiB. All complete byte/log/physical gates pass. Nested bank/import/header/custody clocks are not added.'),
 ('all45-whole-outcomes-and-vacuous-Native','All45 original ordered rows returnpassedtrue, complete/passed_count45/failures[]/exactsubjectversion under a complete unchangedSource worker with no Rootfault. Result/header callback counts52827/52828 differ by the reviewed post-serialization check. Native starts/queries/processes/peaks are genuinely absent and compatibilityclosed/reaped fields are explicitly vacuous. There is no logical proof, learner, library, policy or scientific_result export.'),
 ('two-full-relations-and-saved-independent-expectations','Each saved machine-bound observation has3840 unique typed old neighborhoods, including3312 multihead undefined and8 center-wall exits, plus48 plaincopies/472 saved global-context projections. Typed cardinality proves the saved domain is complete without enumerating a new cube. All520 emitted core certificates/ports exactly join saved defined expectations; all51 frame records,571 tiles and143 colors match their saved full relation/order with no duplicate edge tuple. C regenerates no local/global expectation or palette.'),
 ('six-supplied-witnesses-refusals-point-and-foreign-records','All six supplied witnesses bind current palette/machine hashes, literal original configurations/dimensions, selected existing tile records and full stored perimeter/adjacency joins. Twenty exact saved owned refusal messages, five cap-language outcomes, point center/zero/root observations and five-by-nine foreign identity carriers match Source/control definitions. C performs literal joins only, with no machine step, cap search, validator or fixture replay. In-process object-identity observations are supported by reviewed Source and completed raw carriers, not reconstructed JSON object identities.'),
 ('finite-construction-scope-and-separate-Root-disposition','This completed actual supports only the two frozen machine-bound complete-relation observations and declared finite construction controls. Six trajectories are authored qualification witnesses; no GCTS search, theorem discovery, mathematical verifier, generic formal proof, universal/whole-plane Wang qualification, resource-fit forecast or utility advantage follows. The handwritten conditional Source argument, future FPC-H1 calculus and current main study remain separate. Root alone issues the later qualification disposition/publication authority.')]
receipt=dict(schema='F-C-fixed-Wang-construction-qualification-actual-review-v1',case_id=plan['case_id'],stage='qualify',
    review_passed=True,resource_admitted=True,scientific_qualified=True,stage_complete=True,
    plan=offer['plan'],protocol=offer['protocol'],result=result_pin,header=header_pin,terminal=terminal_pin,observer=observer_pin,
    terminal_offer=offer_pin,whole_Source_review=offer['whole_Source_review'],grant_component_review=offer['grant_component_review'],
    proposal=offer['proposal'],grant=offer['grant'],barrier=offer['barrier'],Root_invocation=offer['invocation'],
    input_pins=sorted(plan['files'],key=lambda row:row['path']),complete_actual_file_census=physical,
    physical_census=dict(file_count=10,total_bytes=1335233,files=physical),qualification_result_sha256=digest(qualification),
    qualification_counts=dict(top_level_passed=45,top_level_expected=45,palette_relation_controls=2,constructed_supplied_witnesses=6,
        exact_owned_refusal_observations=20,cap_language_observations=5,foreign_classes=5,APIs_per_foreign_class=9,foreign_subobservations=45),
    palette_literal_reviews=palette_records,supplied_witness_literal_reviews=witness_rows,
    control_ids=[row['id'] for row in controls],worker_callbacks=result['callbacks'],header_callbacks=header['callbacks'],
    whole_seconds=observer['elapsed_seconds'],final_observer_gate_seconds=observer['final_observer_gate_seconds'],
    Root_tool_summary_seconds=invocation['observer_summary_seconds'],whole_peak_bytes=whole_peak,
    cost_scope='One fresh whole observer sample includes the full once qualification and custody. Nested stages/result/header/terminal/tool samples remain distinct and are not summed.',
    checks=[dict(id=key,passed=True,finding=value) for key,value in checks],failures=[],
    scientific_imports=0,scientific_calls=0,subject_imports=0,subject_calls=0,helper_invocations=0,
    subject_replays=0,expectations_regenerated=0,palettes_regenerated=0,fixtures_regenerated=0,
    partial_files_parsed=0,Root_admission_issued=False,
    scope='Independent complete current finite construction qualification saved-record/resource/custody review only. No Root disposition, formal generic theorem, fixed logical verifier, searched proof, GCTS/RL utility or publication authority.',
    review_program=pin(Path(__file__).resolve()),tools_idle_after_freeze=True)
output=C/'typed-fixed-Wang-complete-qualification-actual-review-v1.json'
with output.open('xb') as stream:stream.write((json.dumps(receipt,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode())
review_pin=pin(output)

# Explicit minimum evidence proposal only; this is not a packaging invocation or Root authority.
selected={}
def select(value,role):
    verify(value)
    if value['path'] in selected:return
    path=Path(value['path']);need(path.is_relative_to(BASE) and '.partial' not in path.name,'public Source/complete evidence path only')
    member=('task/'+str(path.relative_to(F))) if path.is_relative_to(F) else ('external-source/'+str(path.relative_to(BASE)))
    selected[value['path']]=dict(value,role=role,archive_path=member)
python_pin=plan['python']
for value in plan['files']:
    if value!=python_pin:select(value,'complete_guarded_Source_or_semantics')
for value in physical:select(value,'complete_current_once_actual')
for key in ('plan','protocol','proposal','grant','barrier','invocation','whole_Source_review','grant_component_review'):
    select(offer[key],'current_explicit_custody_or_independent_review')
select(offer_pin,'complete_terminal_review_offer');select(plan['closed_inputs'],'complete_semantic_closure')
for value in (whole['construction_argument'],whole['next_verifier_obligations']):select(value,'separate_Source_math_scope')
for value in (whole['review_program'],grant_review['review_program'],receipt['review_program'],review_pin):select(value,'independent_C_review_or_passive_review_Source')
allowlist=dict(schema='F-C-minimal-public-evidence-file-allowlist-proposal-v1',proposal_only=True,publication_authorized=False,
    current_actual_review=review_pin,protocol=offer['protocol'],plan=offer['plan'],selected_files=sorted(selected.values(),key=lambda row:row['archive_path']),
    omitted_runtime=[dict(python_pin,role='fixed_interpreter_pin_only',reason='Exact interpreter identity retained; binary body omitted. Installed stdlib/OS remains the declared trusted substrate.')],
    selected_count=len(selected),selected_bytes=sum(row['bytes'] for row in selected.values()),current_actual_files=10,
    scope='Minimal explicit raw file proposal for this one finite construction qualification. Retains all25 guards via24 complete bodies plus one runtime pin, all10 current actual files, exact named custody/C/math records. No recursive pin chasing, old science, Native bodies, FPC-H1 or private/index/primary-reader/.gcts-active intake. Root must separately author/review concrete publication authority, inventory, packaging/output and installation/live gates.',
    scientific_imports=0,scientific_calls=0,helper_invocations=0,partial_files_parsed=0,Root_admission_issued=False)
allowlist_path=C/'minimal-public-evidence-file-allowlist-proposal-v1.json'
with allowlist_path.open('xb') as stream:stream.write((json.dumps(allowlist,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode())
print(json.dumps(review_pin));print(json.dumps(pin(allowlist_path)))
print(json.dumps(dict(checks=len(checks),failures=0,all45_passed=True,whole_seconds=observer['elapsed_seconds'],whole_peak_bytes=whole_peak,actual_files=10,proposed_public_bodies=len(selected),runtime_pin_only=1,tools_idle=True)))
