"""C-owned raw complete-JSON output joins only; no subject or display execution."""
import hashlib
import json
from pathlib import Path

F=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021');C=F/'review-C';checked={}
def need(value,message):
    if not value:raise ValueError(message)
def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def pin(path):
    path=Path(path);need(path.is_absolute() and path.resolve()==path and path.is_file() and not path.is_symlink(),'canonical ordinary raw body')
    body=path.read_bytes();value=dict(path=str(path),bytes=len(body),sha256=hashlib.sha256(body).hexdigest())
    if str(path) in checked:need(checked[str(path)]==value,'stable current raw body')
    checked[str(path)]=value;return value
def unique(pairs):
    value={}
    for key,item in pairs:need(key not in value,'duplicate JSON key');value[key]=item
    return value
def load(value):
    if isinstance(value,(Path,str)):value=pin(value)
    need(set(value)=={'path','bytes','sha256'} and pin(value['path'])==value and '.partial' not in Path(value['path']).name,'strict complete current pin')
    return json.loads(Path(value['path']).read_bytes(),object_pairs_hook=unique,parse_constant=lambda text:(_ for _ in ()).throw(ValueError(text)))

admission_pin=pin(F/'root/admission/qualify-fixed-wang-0-v1.json');admission=load(admission_pin)
data_pin=pin(F/'publication/fixed-wang-construction-data-v1.json');data=load(data_pin)
need((admission_pin['bytes'],admission_pin['sha256'])==(14237,'467772026b660368292ddca18b4f6a90f6c87576d3245a95cc493ab54bdd4c6c'),'exact Root disposition')
need((data_pin['bytes'],data_pin['sha256'])==(6163799,'6fad726664004042fc0df49d36d920e90844d50216fff7f7370d9d26d60a5d89'),'exact passive display envelope')
actual_review=load(admission['C_actual_review'])
need(admission['C_actual_review']['sha256']=='77269e3573c41aa264280658e26825a9ef42b9a612600d4e7b5549a9ba3a4c8a'
     and actual_review['review_passed'] is True and len(actual_review['checks'])==7
     and all(row['passed'] is True for row in actual_review['checks']) and actual_review['failures']==[],'current whole actual C PASS reused by exact equality')
need(admission['schema']=='Root-fixed-Wang-construction-qualification-admission-v1'
     and admission['case_id']==actual_review['case_id']=='qualify-fixed-wang-0'
     and admission['stage']=='qualify' and admission['status']=='QUALIFIED'
     and admission['gates']==dict(admitted=True,resource_admitted=True,scientific_qualified=True,stage_complete=True)
     and all(actual_review[key] is True for key in ('resource_admitted','scientific_qualified','stage_complete')),'consistent separate Root fourgate disposition')
for key in ('plan','protocol','result','header','terminal','observer','grant','terminal_offer'):
    need(admission[key]==actual_review[key],'same current component '+key);load(admission[key])
plan=load(admission['plan']);worker=load(admission['result']);header=load(admission['header']);terminal=load(admission['terminal']);observer=load(admission['observer'])
need(admission['current_guards']==plan['files'] and sorted(plan['files'],key=lambda row:row['path'])==actual_review['input_pins'] and len(plan['files'])==25,'exact original25 guard declarations')
for row in plan['files']:need(pin(row['path'])==row,'all current Source/runtime guards')
need(admission['actual_census']==actual_review['complete_actual_file_census'] and len(admission['actual_census'])==10,'complete exact10file census')
for row in admission['actual_census']:need(pin(row['path'])==row,'all current actual bodies')
need(admission['observer_seconds']==actual_review['whole_seconds']==observer['elapsed_seconds']==0.43236604100093246
     and admission['final_observer_gate_seconds']==actual_review['final_observer_gate_seconds']==observer['final_observer_gate_seconds']==0.43269420800788794
     and admission['conservative_whole_peak_bytes']==actual_review['whole_peak_bytes']==observer['final_conservative_whole_peak_bytes']==141377536,'separate exact direct clocks and whole memory')
need(admission['control_count']==admission['passed_count']==45 and admission['supplied_trajectory_count']==6
     and admission['no_retry_or_prefix_salvage'] is True and admission['broad_goal_active'] is True,'limited population and no broad-goal completion')
resource=load(admission['Root_resource_observation'])
need(resource['schema']=='Root-fixed-Wang-terminal-resource-observation-v1' and resource['checks_passed'] is True
     and all(value is True for value in resource['checks'].values()) and resource['Root_scientific_admission'] is False
     and resource['header']==admission['header'] and resource['terminal']==admission['terminal'] and resource['observer']==admission['observer']
     and resource['terminal_offer']==admission['terminal_offer'] and resource['file_count']==10 and resource['physical_bytes']==1335233
     and resource['observer_seconds']==admission['observer_seconds'] and resource['conservative_whole_peak_bytes']==admission['conservative_whole_peak_bytes'],'earlier Root resource-only observation remains scoped and current')
need(set(data)=={'authority','input_pins','observer','schema','terminal','worker_header','worker_result'}
     and data['schema']=='fixed-Wang-construction-reader-data-v1','exact passive display envelope fields')
need(data['authority']==dict(C_actual_review=admission['C_actual_review'],Root_admission=admission_pin,gates=admission['gates'],state='QUALIFIED'),'exact Root/C data authority pins, no invented upgrade')
expected_inputs=[admission['result'],admission['header'],admission['terminal'],admission['observer'],admission_pin,admission['C_actual_review']]
need(data['input_pins']==expected_inputs and len({row['path'] for row in data['input_pins']})==6,'allandonly six direct current input pins')
for row in data['input_pins']:load(row)
joins=[]
for field,value,source in [('worker_result',worker,admission['result']),('worker_header',header,admission['header']),('terminal',terminal,admission['terminal']),('observer',observer,admission['observer'])]:
    need(canonical(data[field])==canonical(value),'entire copied complete object equality '+field)
    joins.append(dict(field=field,source=source,canonical_sha256=hashlib.sha256(canonical(value)).hexdigest()))
qualification=data['worker_result']['qualification_result']
need(qualification['complete'] is True and qualification['control_count']==qualification['passed_count']==45
     and len(qualification['controls'])==45 and all(row['passed'] is True for row in qualification['controls'])
     and qualification['failures']==[] and data['worker_result']['scientific_result'] is None
     and data['worker_result']['full_physical_Wang_claim'] is False
     and data['worker_result']['native_requests_started']==0 and data['worker_result']['native_queries']==[],'all complete finite evidence and vacuous Native forwarded without reconstruction')
need('supplied witnesses, not found by search' in admission['scope']
     and 'No mathematical theorem/proof search' in admission['scope']
     and 'no proof/policy/library/seal export' in admission['scope'],'explicit finite claim boundary remains in Root authority')
for row in tuple(checked.values()):need(pin(row['path'])==row,'final raw stability')
checks=[
 ('exact-current-Root-disposition-and-C-whole-PASS','The exact14,237-byte Root qualification disposition binds the current seven-check C actual PASS and exact plan/protocol/result/header/terminal/observer/grant/terminaloffer. All four Root gates are true consistently with C findings. This review validates Root output and does not itself issue a disposition.'),
 ('all25-guards10census-and-resource-scope','All25 declared Source/runtime guards and all10 complete actual bodies remain exact. Root resource-only observation stays explicitly separate from semantic admission. Direct observer sample0.43236604100093246, later finalgate0.43269420800788794 and conservative wholepeak141,377,536 bytes match current raw authorities. No new threshold, summed nested clocks, retry or prefix adoption.'),
 ('whole-passive-envelope-and-six-input-equalities','The exact6,163,799-byte envelope has only the declared seven fields and six unique exact source pins. Every complete worker_result, worker_header, terminal and observer object equals the current saved JSON canonically, including every full relation, certificate, supplied witness, refusal, foreign diagnostic and resource field. There is no inferred primitive step, regenerated palette or reconstructed scientific result.'),
 ('finite-construction-only-and-HTML-publication-separate','All45 passing controls/six supplied trajectories remain finite synthetic construction evidence. Worker scientific_result is null, Native compatibility is vacuous, and Root explicitly excludes proof/search/GCTS/RL/universal/formal-generic/whole-plane claims and any proof/policy/library/seal export. Broad goal stays active. HTML Source, rendering, archive/inventory and publication authority are separate future reviews; this envelope review supplies none of them.')]
receipt=dict(schema='F-C-fixed-Wang-disposition-and-reader-data-review-v1',review_passed=True,
    Root_admission=admission_pin,reader_data=data_pin,C_actual_review=admission['C_actual_review'],
    plan=admission['plan'],protocol=admission['protocol'],result=admission['result'],header=admission['header'],terminal=admission['terminal'],observer=admission['observer'],
    Root_resource_observation=admission['Root_resource_observation'],Root_gates=admission['gates'],input_pins=data['input_pins'],
    complete_actual_file_census=admission['actual_census'],current_guard_count=25,complete_actual_files=10,
    complete_object_literal_joins=joins,control_count=45,supplied_trajectory_count=6,
    whole_seconds=admission['observer_seconds'],final_observer_gate_seconds=admission['final_observer_gate_seconds'],whole_peak_bytes=admission['conservative_whole_peak_bytes'],
    checks=[dict(id=key,passed=True,finding=value) for key,value in checks],failures=[],
    scientific_imports=0,scientific_calls=0,subject_replays=0,helper_invocations=0,palettes_or_expectations_regenerated=0,
    partial_files_parsed=0,Root_admission_issued=False,HTML_reviewed=False,browser_executed=False,publication_authorized=False,
    scope='Independent current Root qualification disposition and passive complete display-envelope equality only. Prior full scientific/custody review reused by exact current raw identity. No new scientific inference, HTML/render readiness, package/install or publication authority.',
    review_program=pin(Path(__file__).resolve()),tools_idle_after_freeze=True)
output=C/'typed-fixed-Wang-disposition-and-reader-data-review-v1.json'
with output.open('xb') as stream:stream.write((json.dumps(receipt,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode())
print(json.dumps(pin(output)));print(json.dumps(dict(checks=len(checks),failures=0,exact_objects=4,input_pins=6,tools_idle=True)))
