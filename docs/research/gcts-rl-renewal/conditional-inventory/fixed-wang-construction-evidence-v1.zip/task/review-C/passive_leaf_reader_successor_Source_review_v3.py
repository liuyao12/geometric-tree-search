"""Raw successor/inverse and complete saved-JSON joins; no subject or JS execution."""
from pathlib import Path
import hashlib
import json

F = Path(__file__).resolve().parents[1]
C = F / 'review-C'
OUT = C / 'typed-fixed-Wang-leaf-reader-successor-Source-review-v3.json'


def pin(path):
    p = Path(path)
    raw = p.read_bytes()
    return {'path': str(p.resolve()), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def read(path):
    return json.loads(Path(path).read_text())


def need(value, message):
    if not value:
        raise AssertionError(message)


need(not OUT.exists(), 'immutable output exists')
handoff_path = F / 'publication/fixed-wang-construction-reader-Source-handoff-v2.json'
handoff = read(handoff_path)
need(pin(handoff_path)['sha256'] == 'e8247008eb580299194fdd91dabbd6ad26e7ea6f5cdf4821302bfd02e3d602d0', 'handoff')
for row in handoff['files']:
    need(pin(row['path']) == row, 'current handoff body')
need(pin(handoff['predecessor_handoff']['path']) == handoff['predecessor_handoff'], 'preserved v1 handoff')
need(pin(handoff['unchanged_data']['path']) == handoff['unchanged_data'], 'unchanged data')
api = read(F / 'publication/fixed-wang-construction-reader-v2-Source-delta-and-API-v1.json')
for key in ('HTML_Source', 'preserved_v1', 'Root_QA_negative', 'inherited_contract', 'inherited_manual', 'unchanged_existing_data'):
    need(pin(api[key]['path']) == api[key], key)
old_path, mid_path = Path(api['preserved_v1']['path']), Path(api['HTML_Source']['path'])
old, mid = old_path.read_bytes(), mid_path.read_bytes()
inverse = api['raw_inverse']
restored = mid
for new_key, old_key in [('new_function', 'old_function'), ('new_default_fragment', 'old_default_fragment'), ('new_control_row', 'old_control_row')]:
    a, b = inverse[new_key].encode(), inverse[old_key].encode()
    need(restored.count(a) == 1, 'one declared display substitution')
    restored = restored.replace(a, b, 1)
need(restored == old, 'entire v2 inverse equals entire v1')
label_path = F / 'root/reader-label-successor-v3.json'
label = read(label_path)
for key in ('preimage', 'successor', 'C_negative', 'data_unchanged'):
    need(pin(label[key]['path']) == label[key], 'label successor current binding')
need(label['preimage'] == pin(mid_path), 'label preimage is exact v2')
final_path = Path(label['successor']['path'])
final = final_path.read_bytes()
need(pin(final_path) == {'path': str(final_path), 'bytes': 25206, 'sha256': 'de07adc4a79411d1e70d5e0da4a60c97fdc170711cdcf958a0a9d25d7968f91b'}, 'final v3 pin')
need(mid.count(label['old'].encode()) == 1 and final.count(label['new'].encode()) == 1, 'unique occupancy label change')
need(final.replace(label['new'].encode(), label['old'].encode(), 1) == mid, 'entire v3 inverse equals entire v2')
prior_path = C / 'typed-fixed-Wang-leaf-reader-Source-negative-v1.json'
prior = read(prior_path)
need(pin(prior_path) == label['C_negative'], 'preserved independent negative')
need(prior['counts'] == {'checks': 6, 'passed': 5, 'blockers': 1, 'controls': 45, 'palettes': 2,
                         'tiles_per_palette': 571, 'colors_per_palette': 143,
                         'supplied_rectangles': 6, 'saved_rectangle_cells': 87}, 'prior full review reused exactly')
need(prior['HTML'] == pin(old_path), 'prior full-body Source pin')
for row in prior['input_pins']:
    need(pin(row['path']) == row, 'prior reviewed raw body unchanged')
data = read(handoff['unchanged_data']['path'])
controls = data['worker_result']['qualification_result']['controls']
large = [(i, c) for i, c in enumerate(controls) if 'full_actual_palette' in c['evidence']]
need([i for i, c in large] == [0, 1] and len(controls) == 45, 'two summarized controls; full 45 denominator')
summaries = []
for i, control in large:
    evidence = control['evidence']
    palette = evidence['full_actual_palette']
    summary = {'control_index': i, 'control_id': control['id'], 'recorded_pass': control['passed'],
               'full_data': 'fixed-wang-construction-data-v1.json',
               'JSON_pointer': '/worker_result/qualification_result/controls/' + str(i),
               'evidence_keys': list(evidence), 'saved_palette_tiles': len(palette['tiles']),
               'saved_palette_colors': len(palette['colors']),
               'saved_expected_local_carrier_rows': len(evidence['full_expected_local_triples']),
               'saved_expected_frame_records': len(evidence['full_expected_frame']),
               'machine_sha256': palette['machine_sha256']}
    need([summary[k] for k in ('saved_palette_tiles', 'saved_palette_colors', 'saved_expected_local_carrier_rows', 'saved_expected_frame_records')] == [571, 143, 3840, 51], 'literal saved summary counts')
    current = data
    for token in summary['JSON_pointer'].split('/')[1:]:
        current = current[int(token)] if isinstance(current, list) else current[token]
    need(current == control, 'exact complete-control JSON locator')
    summaries.append(summary)
need(controls[2]['id'] == 'global-right-destination-old-symbol' and 'full_actual_palette' not in controls[2]['evidence'], 'small exact default control2')
text = final.decode()
need(inverse['new_function'] in text and inverse['new_default_fragment'] in text and inverse['new_control_row'] in text, 'all declared v2 logic retained in v3')
need("el('control-evidence').textContent=pretty(c);" in inverse['new_function'], 'other 43 control records remain full')
need("Small display summary only." in inverse['new_function'] and "JSON_pointer:" in inverse['new_function'], 'explicit summary scope and locator')
need(label['new'] in text and label['old'] not in text, 'raw occupancy label now accurate')
need("'t('+p.join(',')+')=\\\\frac{'+v+'}{'+boundary.capacity+'}'" in text, 'normalized t formula unchanged')
need("fetch('fixed-wang-construction-data-v1.json')" in text, 'data fetch unchanged')
checks = [
    {'id': 'exact-frozen-lineage-and-whole-byte-inverses', 'passed': True,
     'finding': 'All handoff/API/negative/predecessor/data bindings are current. Three exact v2 substitutions reverse to the entire v1 body; the unique v3 occupancy-label substitution reverses to the entire v2 body. No other Source delta exists.'},
    {'id': 'large-control-summary-is-literal-and-nonauthoritative', 'passed': True,
     'finding': 'Only saved relation controls0/1 use clearly labeled small summaries. Both exact JSON locators resolve to the complete unchanged current records; literal counts are571 tiles/143 colors/3840 expected-local entries/51 expected-frame records. Expected entries are not misclassified as emitted tiles. Raw data/archive links retain full evidence; no inference or regeneration occurs.',
     'saved_summary_fields': summaries},
    {'id': 'all-control-denominator-and-small-default-preserved', 'passed': True,
     'finding': 'The complete45-row table/selector is unchanged. Default2 is the saved global-right-destination-old-symbol observation; other43 nonpalette controls remain full pretty JSON. This is a DOM payload reduction only, not evidence that a specific host timeout was caused or cured by that payload.'},
    {'id': 'independent-point-label-negative-resolved', 'passed': True,
     'finding': 'SVG now says occupancy:12. Adjacent LaTeX still defines normalized t=12/12=1, and every saved point mark/root/boundary field is unchanged. Prior negative d421fa0a remains preserved; only this successor resolves its label issue.'},
    {'id': 'full-prior-display-and-finite-scope-findings-retained', 'passed': True,
     'finding': 'Exact inverse reuses the prior five passing complete Source/data-ABI checks: both oriented palettes and tagged N/E/S/W colors, all87 existing cells in six supplied rectangles/configurations, four envelope gates and separate direct clocks, complete controls, exact six unrun future targets and escaped presentation. No proof-verifier/universality/search/RL/Graph qualification is added. Browser authority checks pin shape only; raw authority validation remains the prior independent C/Root work.'},
]
receipt = {
    'schema': 'F-C-fixed-Wang-leaf-reader-successor-Source-review-v3',
    'review_passed': True, 'status': 'PASS_SOURCE_ONLY_PENDING_ROOT_BROWSER_AND_ARCHIVE_GATES',
    'HTML_Source': pin(final_path), 'public_HTML_basename': handoff['public_HTML_basename'],
    'reader_data': handoff['unchanged_data'], 'preserved_negative': pin(prior_path),
    'input_pins': sorted([pin(handoff_path), *handoff['files'], pin(label_path), pin(final_path),
                          handoff['unchanged_data'], pin(prior_path), *prior['input_pins']], key=lambda p: p['path']),
    'checks': checks, 'failures': [],
    'scope': 'Final current display Source and exact repaired delta review only; no subject, bank, compiler, scientific helper, JavaScript, browser, palette, fixture or expectation execution. This receipt neither admits a new scientific result nor authorizes archive/install/publication.',
    'limits': {'scientific_or_subject_calls': 0, 'subject_imports': 0, 'JavaScript_execution': 0,
               'browser_network_QA': False, 'partial_files_parsed': 0,
               'Root_admission_issued': False, 'publication_authority': False,
               'host_timeout_causality_or_cure_established': False},
    'review_program': pin(__file__), 'tools_idle_after_receipt': True,
}
# The input list is a raw-pin set, never a traversal request.
receipt['input_pins'] = sorted({row['path']: row for row in receipt['input_pins']}.values(), key=lambda p: p['path'])
with OUT.open('x') as stream:
    json.dump(receipt, stream, indent=2, ensure_ascii=False)
    stream.write('\n')
print(json.dumps({'receipt': pin(OUT), 'checks': len(checks), 'failures': 0}, sort_keys=True))
