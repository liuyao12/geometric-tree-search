"""C-owned literal parent HTML Source/prose review. No rendering or publication."""
import hashlib
import json
from pathlib import Path
from html.parser import HTMLParser

F=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021');C=F/'review-C';R=F/'root';checked={}
def need(value,message):
    if not value:raise ValueError(message)
def pin(path):
    path=Path(path);need(path.is_absolute() and path.resolve()==path and path.is_file() and not path.is_symlink(),'canonical ordinary raw body')
    body=path.read_bytes();value=dict(path=str(path),bytes=len(body),sha256=hashlib.sha256(body).hexdigest())
    if str(path) in checked:need(checked[str(path)]==value,'current raw stability')
    checked[str(path)]=value;return value
def load(value):
    if isinstance(value,(str,Path)):value=pin(value)
    need(pin(value['path'])==value and '.partial' not in Path(value['path']).name,'current complete JSON')
    return json.loads(Path(value['path']).read_bytes())
before_pin=pin(R/'parent-reader-preimage-v1.html');block_pin=pin(R/'parent-insertion-v1.html');after_pin=pin(R/'parent-reader-proposed-v2.html')
need((before_pin['bytes'],before_pin['sha256'])==(130633,'728c99800d7176f645b4fbe11a12fc4497824929d443660e831785b0f7c4de2f')
     and block_pin['bytes']==1985 and (after_pin['bytes'],after_pin['sha256'])==(132618,'37769be85d04a5196d39db00f90c6643f856c11f477b5ede135b7d0d876cb6bb'),'exact offered parent Sources')
before=Path(before_pin['path']).read_bytes();block=Path(block_pin['path']).read_bytes();after=Path(after_pin['path']).read_bytes();tail=b'</main></body></html>\n'
need(len(tail)==22 and before.endswith(tail) and before[:-22]==after[:130611]
     and after==before[:-22]+block+tail and after.count(block)==1 and block not in before
     and after.replace(block,b'',1)==before,'exact single append/full old-content inverse')
negative_pin=pin(R/'parent-splice-authoring-negative-v1.json');negative=load(negative_pin)
need(negative['schema']=='Root-parent-splice-authoring-negative-v1' and negative['output_created'] is False
     and negative['scientific_calls']==0 and not(R/'parent-reader-proposed-v1.html').exists(),'prewrite newline-assumption negative preserved; no first candidate')
data_review_pin=pin(C/'typed-fixed-Wang-disposition-and-reader-data-review-v1.json');data_review=load(data_review_pin)
need(data_review['review_passed'] is True and all(row['passed'] is True for row in data_review['checks']) and data_review['failures']==[],'current Root/data output PASS')
admission=load(data_review['Root_admission']);actual=load(data_review['C_actual_review'])
need(admission['control_count']==admission['passed_count']==45 and admission['supplied_trajectory_count']==6
     and all(row['tiles']==571 and row['colors']==143 for row in actual['palette_literal_reviews'])
     and len(actual['palette_literal_reviews'])==2 and admission['conservative_whole_peak_bytes']==141377536
     and admission['observer_seconds']==0.43236604100093246,'all parent numeric statements bind current complete authorities')
class Inspector(HTMLParser):
    def __init__(self):super().__init__();self.ids=[];self.hrefs=[];self.tags=[];self.events=[]
    def handle_starttag(self,tag,attrs):
        self.tags.append(tag)
        for key,value in attrs:
            if key=='id':self.ids.append(value)
            if key=='href':self.hrefs.append(value)
            if key.startswith('on'):self.events.append((key,value))
parser=Inspector();parser.feed(block.decode());parser.close()
need(parser.ids==['fixed-wang-construction-v1'] and not parser.events and 'script' not in parser.tags
     and parser.hrefs==['fixed-wang-construction-v1.html','fixed-wang-construction-data-v1.json','fixed-wang-construction-evidence-v1.zip','fixed-wang-construction-manifest-v1.json'],'static isolated task section/four precise prospective relative links')
text=block.decode()
for literal in ('all \\(45\\) original construction controls','two test machines produced \\(571\\)','\\(143\\) edge colors','Six supplied computation histories','not discovered by proof search','\\(0.432366\\,\\mathrm{s}\\)','\\(141{,}377{,}536\\) bytes','no mathematical theorem discovery, GCTS/RL advantage or universal-palette claim','remain separate integration work','broad tiling and proof-search goal remains active'):
    need(literal in text,'precise finite/source-only parent wording '+literal)
need(text.count('\\(')==text.count('\\)') and '\\(' in text and 'capture checks' in text,'LaTeX delimiters and separately proposed next-step wording')
for value in tuple(checked.values()):need(pin(value['path'])==value,'final current pin stability')
checks=[
 ('exact-single1985byte-append-and-whole-inverse','The130,633-byte allowed-parent preimage728c9980 is unchanged outside its final22-byte closing tail. The exact1,985-byte task block is inserted once at offset130611, producing132,618 bytes/37769be8; deleting that block restores the complete preimage byte-for-byte. All original N6 and earlier content is retained.'),
 ('preserved-prewrite-authoring-negative','The preserved Root note records a mistaken two-newline suffix assertion before any output write. The v1 candidate is absent; the v2 candidate uses the actual single-newline tail. This is passive splice metadata, with no Source/actual/helper/deployed change or scientific retry.'),
 ('current-finite-qualification-prose-and-safe-links','The prose matches current Root/C output authority:45 complete controls, two observed571-type/143-color palettes, six supplied histories, observer0.432366s and exact141,377,536-byte conservative peak. It explicitly excludes discovered proofs, GCTS/RL advantage and universal palette, keeps Graph/rollback/fixed-verifier integration open, and labels the checker as next work. One static section and four exact prospective relative leaf/data/evidence/manifest links introduce no script or event handler. Mathematical notation uses paired LaTeX delimiters.'),
 ('Source-only-parent-candidate-no-display-authority','This review covers the exact Root candidate copies and parent prose only. It does not read/mutate Publisher, establish installation or live preimage, execute HTML/JS/MathJax, approve the forthcoming leaf reader Source, or issue package/publication/scientific authority. Those current output, Source, archive/install and visual/live gates remain separate.')]
receipt=dict(schema='F-C-fixed-Wang-parent-splice-and-prose-Source-review-v1',review_passed=True,
    preimage=before_pin,insertion=block_pin,proposed_parent=after_pin,preserved_authoring_negative=negative_pin,
    current_output_data_review=data_review_pin,Root_admission=data_review['Root_admission'],C_actual_review=data_review['C_actual_review'],
    splice=dict(offset_zero_based=130611,closing_tail_bytes=22,inserted_bytes=1985,net_bytes=1985,forward_exact=True,inverse_exact=True),
    prospective_links=parser.hrefs,checks=[dict(id=key,passed=True,finding=value) for key,value in checks],failures=[],
    scientific_imports=0,scientific_calls=0,helper_invocations=0,HTML_executed=False,Publisher_accessed=False,
    publication_authorized=False,Root_admission_issued=False,partial_files_parsed=0,
    scope='Independent literal current parent splice/prose Source check only. Forthcoming leaf HTML Source/display, package and publication authority remain separate.',
    review_program=pin(Path(__file__).resolve()),tools_idle_after_freeze=True)
output=C/'typed-fixed-Wang-parent-splice-and-prose-Source-review-v1.json'
with output.open('xb') as stream:stream.write((json.dumps(receipt,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode())
print(json.dumps(pin(output)));print(json.dumps(dict(checks=len(checks),failures=0,tools_idle=True)))
