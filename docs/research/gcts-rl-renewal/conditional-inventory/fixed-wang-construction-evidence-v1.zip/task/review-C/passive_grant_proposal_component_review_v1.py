"""C-owned narrow current raw/metadata grant composition review; no invocation."""
import hashlib
import json
from pathlib import Path

F=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021')
C=F/'review-C';R=F/'root';checked={}

def need(value,message):
    if not value:raise ValueError(message)

def pin(path):
    path=Path(path)
    need(path.is_absolute() and path.resolve()==path and path.is_file() and not path.is_symlink(),'canonical ordinary raw body')
    body=path.read_bytes();value=dict(path=str(path),bytes=len(body),sha256=hashlib.sha256(body).hexdigest())
    if str(path) in checked:need(checked[str(path)]==value,'raw stability')
    checked[str(path)]=value;return value

def unique(pairs):
    value={}
    for key,item in pairs:
        need(key not in value,'duplicate JSON key');value[key]=item
    return value

def load(value):
    if isinstance(value,(Path,str)):value=pin(value)
    need(set(value)=={'path','bytes','sha256'} and type(value['bytes']) is int and pin(value['path'])==value,'exact strict raw pin')
    need('.partial' not in Path(value['path']).name,'no partial intake')
    return json.loads(Path(value['path']).read_bytes(),object_pairs_hook=unique,parse_constant=lambda text:(_ for _ in ()).throw(ValueError(text)))

proposal_pin=pin(R/'grant-proposal-v1.json');proposal=load(proposal_pin)
need((proposal_pin['bytes'],proposal_pin['sha256'])==(1718,'412e359f417287b5833c19a30538355b7caa8c9930aa6a0d106ec3fa13196ff7'),'exact offered proposal')
need(set(proposal)=={'authorized','case_id','created_utc','future_execution_grant_path','plan','plan_sha256','review_passed','runner_sha256','schema','scope','status','uses','whole_Source_plan_review'},'exact proposal fields')
need(proposal['schema']=='Root-fixed-Wang-once-grant-proposal-v1'
     and proposal['status']=='PROSPECTIVE_CONTENT_ONLY_NOT_EXECUTION_AUTHORITY'
     and proposal['case_id']=='qualify-fixed-wang-0','explicit prospective-only current identity')
whole_pin=proposal['whole_Source_plan_review'];whole=load(whole_pin)
need((whole_pin['bytes'],whole_pin['sha256'])==(63617,'37dee6ba5293cdeb42df6d3d66ec4d6d940e1dfc6c5fb782bb3b3b014ad09075')
     and whole['schema']=='F-C-fixed-Wang-whole-prospective-Source-plan-review-v1'
     and whole['review_passed'] is True and len(whole['checks'])==15
     and all(item['passed'] is True for item in whole['checks']) and whole['failures']==[],'exact independent whole Source/plan PASS')
plan_pin=proposal['plan'];plan=load(plan_pin);protocol=load(whole['protocol'])
need(plan_pin==whole['plan'] and (plan_pin['bytes'],plan_pin['sha256'])==(10304,'cf617a26d0435ce51985122605a775cdee920e31f917796e681e0ed86cf13ecd')
     and proposal['plan_sha256']==plan_pin['sha256'],'current full reviewed plan and declared hash')
need(plan['case_id']==proposal['case_id']==whole['case_id'] and plan['stage']=='qualify'
     and plan['required_upstream_ids']==[] and plan['limits']==whole['limits']==protocol['limits'],'same cold all45 recipe/caps')
need(len(plan['files'])==whole['guard_count']==25
     and sorted(plan['files'],key=lambda row:row['path'])==whole['input_pins'],'unchanged exact25 guards')
for row in plan['files']:
    need(pin(row['path'])==row,'current full guard')
for key in ('subject','bank','worker','runner','observer','python'):
    need(pin(whole[key]['path'])==whole[key]==protocol[key],'current fixed Source/runtime role '+key)
need(proposal['runner_sha256']==whole['runner']['sha256']=='98c55321bb87a8c04b2c6d56b357aba9c3a8f5fc98660474ae3ac1c9d00b0aca'
     and plan['runner_path']==whole['runner']['path'] and plan['observer_path']==whole['observer']['path'],'exact unchanged custodian/observer ABI')
required=dict(authorized=True,uses=1,review_passed=True,plan_sha256=plan_pin['sha256'],runner_sha256=whole['runner']['sha256'])
need(all(proposal[key]==value for key,value in required.items())
     and proposal['authorized'] is True and proposal['review_passed'] is True
     and type(proposal['uses']) is int and proposal['uses']==1,'all original typed runner/observer grant fields')
need(protocol['control_order']==whole['control_order'] and len(protocol['control_order'])==45
     and protocol['population']['top_level_controls']==45 and whole['controls_executed']==0,'entire original45 controls remain unrun')
future_path=Path(proposal['future_execution_grant_path'])
need(str(future_path)==protocol['canonical_paths']['grant']==whole['absent_paths']['grant']
     and future_path==R/'grants/qualify-fixed-wang-0-v1.json' and future_path!=Path(proposal_pin['path']),'distinct canonical future execution grant path')
absence=dict(grant=str(future_path),actual=plan['actual_dir'],observer=plan['actual_dir']+'.observer')
need(all(not Path(path).exists() for path in absence.values()),'future grant/actual/observer all absent')
for value in tuple(checked.values()):need(pin(value['path'])==value,'final current raw stability')

checks=[
 ('exact-proposal-and-whole-PASS-binding','The exact1,718-byte proposal412e359f names only qualify-fixed-wang-0 and the exact cf617a26 plan/current independent whole PASS37dee6ba. All15 prior checks remain allpassed by current raw identity. Its schema/status and distinct path explicitly label proposed content, with no current actual or execution grant.'),
 ('current25guards-all45-original-caps-and-cold-input','All25 current plan guards and compiler/bank/worker/custodian/observer/Python identities rehash unchanged. Protocol, cold no-upstream identity, all45 control IDs and all original caps are identical to the whole reviewed plan. No changed fixture, FPC-H1, historical proof/library/policy or smaller bank is introduced.'),
 ('typed-runner-observer-ABI-and-authority-limit','authorized and review_passed are exact true, uses is exact integer1, and both required SHA fields match current plan/runner. These satisfy the unchanged generic runner/observer field subset. Those generic Sources do not validate proposal schema/status/path: prospective-only authority is a Root workflow contract, not a technical assertion that passing this payload directly would be rejected. C does not invoke it or authorize such a call.'),
 ('future-distinct-grant-fresh-barrier-and-no-current-invocation','The canonical grants/qualify-fixed-wang-0-v1.json and both actual directories remain absent. Root may create that distinct execution-authority body only after this exact C receipt and a fresh all-agent/tools-idle barrier, retaining required fields and adding exact proposal/current C/fresh barrier pins with execution schema/status. Final grant raw custody and complete once actual/resource/scientific review remain later. No grant, helper call, palette generation or admission is issued by C.')]
receipt=dict(schema='F-C-fixed-Wang-grant-proposal-component-review-v1',review_passed=True,case_id=plan['case_id'],stage='qualify',
    proposal=proposal_pin,whole_Source_plan_review=whole_pin,plan=plan_pin,protocol=whole['protocol'],runner=whole['runner'],observer=whole['observer'],
    input_pins=whole['input_pins'],guard_count=25,control_count=45,limits=plan['limits'],required_runner_fields=required,
    future_execution_grant_path=str(future_path),absent_paths=absence,
    future_materialization_contract=dict(distinct_grant_required=True,retains_required_runner_fields=True,
        binds_exact_proposal=True,binds_current_C_component_review=True,binds_fresh_all_tools_idle_barrier=True,
        schema_and_status_change_to_Root_execution_authority=True,not_yet_materialized=True),
    technical_authority_limit='The unchanged custodian/observer enforce the required field subset, not proposal schema/status/path. Root workflow must select only the later distinct exact execution grant after the fresh barrier.',
    checks=[dict(id=key,passed=True,finding=value) for key,value in checks],failures=[],scientific_imports=0,scientific_calls=0,
    subject_imports=0,subject_calls=0,fixtures_generated=0,palettes_generated=0,helper_invocations=0,controls_executed=0,
    partial_files_parsed=0,grant_issued=False,actual_started=False,Root_admission_issued=False,
    scope='Narrow prospective Source/raw metadata grant-component composition review only. Reuses exact whole Source/plan PASS by current raw equality. No current execution/grant, actual qualification, resource forecast, scientific result or publication authority.',
    review_program=pin(Path(__file__).resolve()),tools_idle_after_freeze=True)
output=C/'typed-fixed-Wang-grant-proposal-component-review-v1.json'
with output.open('xb') as stream:stream.write((json.dumps(receipt,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode())
print(json.dumps(pin(output)))
print(json.dumps(dict(checks=len(checks),failures=0,guards=25,all45_UNRUN=True,tools_idle=True)))
