"""C-owned raw/complete-JSON and HTML Source inspection; never execute the reader."""
from pathlib import Path
from html.parser import HTMLParser
import hashlib
import json

F = Path(__file__).resolve().parents[1]
C = F / 'review-C'
OUT = C / 'typed-fixed-Wang-leaf-reader-Source-negative-v1.json'


def pin(path):
    path = Path(path)
    raw = path.read_bytes()
    return {'path': str(path.resolve()), 'bytes': len(raw),
            'sha256': hashlib.sha256(raw).hexdigest()}


def read(path):
    return json.loads(Path(path).read_text())


def need(condition, message):
    if not condition:
        raise AssertionError(message)


class Tags(HTMLParser):
    def __init__(self):
        super().__init__()
        self.ids = []
        self.links = []
        self.scripts = []
        self.events = []

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if 'id' in attrs:
            self.ids.append(attrs['id'])
        if tag == 'a' and 'href' in attrs:
            self.links.append(attrs['href'])
        if tag == 'script':
            self.scripts.append(attrs.get('src'))
        self.events += [name for name in attrs if name.startswith('on')]


need(not OUT.exists(), 'immutable output already exists')
handoff_path = F / 'publication/fixed-wang-construction-reader-Source-handoff-v1.json'
handoff = read(handoff_path)
need(pin(handoff_path)['sha256'] == 'b67892b41b9037e04279ca915b6a1f9b4d35d52590d1d67f35a0f0947bd15e3a', 'handoff pin')
for declared in handoff['files']:
    need(pin(declared['path']) == declared, 'handoff body changed')
data_pin = handoff['existing_Root_data_read_only']
need(pin(data_pin['path']) == data_pin, 'data changed')
target_pin = handoff['optional_static_future_targets']
need(pin(target_pin['path']) == target_pin, 'future target Source changed')
html_path = Path(handoff['files'][0]['path'])
html = html_path.read_text()
contract = read(F / 'publication/fixed-wang-construction-reader-data-contract-v1.json')
manual = read(F / 'publication/fixed-wang-construction-reader-manual-scope-v1.json')
static = read(F / 'publication/fixed-wang-construction-reader-static-Source-audit-v1.json')
need(contract['HTML'] == pin(html_path) == manual['HTML'] == static['HTML'], 'HTML metadata bindings')
data = read(data_pin['path'])
q = data['worker_result']['qualification_result']
need(q['control_count'] == q['passed_count'] == len(q['controls']) == 45, 'saved control census')
need(len({c['id'] for c in q['controls']}) == 45, 'unique controls')
palettes = [c for c in q['controls'] if 'full_actual_palette' in c.get('evidence', {})]
trajectories = [c for c in q['controls'] if 'tableau' in c.get('evidence', {})
                and 'configurations' in c['evidence'].get('receipt', {})]
need(len(palettes) == 2 and len(trajectories) == 6, 'display carrier populations')
for c in palettes:
    p = c['evidence']['full_actual_palette']
    need(len(p['tiles']) == 571 and len(p['colors']) == 143, 'saved palette census')
    need([t['id'] for t in p['tiles']] == list(range(571)), 'direct tile-index ABI')
    need(all(type(t[k]) is int and 0 <= t[k] < 143
             for t in p['tiles'] for k in ('north', 'east', 'south', 'west')), 'all literal port indexes')
    need(all(type(s) is str for s in p['colors']), 'complete tagged color labels')
    need(len(c['evidence']['full_expected_local_triples']) == 3840, 'expected carrier distinct from emitted core')
cell_count = 0
for c in trajectories:
    e = c['evidence']
    matches = [p['evidence']['full_actual_palette'] for p in palettes
               if p['evidence']['full_actual_palette']['machine_sha256'] == e['receipt']['machine_sha256']]
    need(len(matches) == 1, 'unique displayed machine namespace')
    p = matches[0]
    need(e['receipt']['accepted'] is True and e['receipt']['complete'] is True, 'recorded witness flags')
    need(len(e['tableau']) == e['boundary']['height'], 'saved height')
    need(all(len(row) == e['boundary']['width'] for row in e['tableau']), 'saved width')
    need(all(type(i) is int and 0 <= i < len(p['tiles']) for row in e['tableau'] for i in row), 'all saved tile IDs')
    need(len(e['receipt']['configurations']) == e['receipt']['steps'] + 1, 'recorded configuration count')
    cell_count += sum(map(len, e['tableau']))
need(cell_count == 87, 'all supplied rectangle cells')
by_id = {c['id']: c for c in q['controls']}
placement = by_id['point-placement-literal']['evidence']['actual']
boundary = by_id['point-boundary-width1-literal']['evidence']['actual']
need(placement['occupancy'] == [[[1, 1], 12]] and boundary['capacity'] == 12, 'one saved scaled occupancy')
need(placement['marks'] == [[[1, 0], 14], [[2, 1], 0], [[1, 2], 138], [[0, 1], 0]], 'point ports/assigned zero')
need(len(boundary['roots']) == len(boundary['generations']) == 9, 'complete saved root carrier')
need(len(boundary['initial_marks']) == 12, 'complete boundary mark carrier')
need(data['authority']['state'] == 'QUALIFIED' and all(v is True for v in data['authority']['gates'].values()), 'current envelope four gates')
for key in ('Root_admission', 'C_actual_review'):
    need(pin(data['authority'][key]['path']) == data['authority'][key], 'current authority raw pin')
tags = Tags()
tags.feed(html)
need(len(tags.ids) == len(set(tags.ids)) == 34 and not tags.events, 'anchors/no inline event attributes')
need(tags.links == static['links'], 'final exact links')
need(tags.scripts == [None, 'https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js', None], 'script surface')
need(all(h[1:] in tags.ids for h in tags.links if h.startswith('#')), 'local anchors resolve')
targets = read(target_pin['path'])
need(len(targets['targets']) == 6 and all(t['goal_latex'] in html for t in targets['targets']), 'six exact unrun target formulas')
need("fetch('fixed-wang-construction-data-v1.json')" in html, 'single fixed complete-data fetch')
need("num=x=>x===null||x===undefined?'unavailable':String(x)" in html, 'null clock/peak preserved')
need("['admitted','resource_admitted','scientific_qualified','stage_complete'].every(k=>g[k]===true)" in html, 'four exact authority gates')
need("t: '+esc(placement.occupancy[0][1])" in html, 'exact observed display defect preimage')
need("'t('+p.join(',')+')=\\\\frac{'+v+'}{'+boundary.capacity+'}'" in html, 'adjacent normalized t formula')

checks = [
    {'id': 'exact-frozen-offer-and-metadata-current', 'passed': True,
     'finding': 'All four handoff bodies, current data, optional six-target Source and HTML metadata pins match; full HTML/contract/manual/static Source was read.'},
    {'id': 'literal-oriented-tile-and-color-mapping', 'passed': True,
     'finding': 'Both 571-tile/143-color saved palettes have exact array-index IDs and all four valid color indexes. Source places north/top, east/right, south/bottom, west/left and displays complete tagged labels; hue is only a repeating visual aid. No rotation/reflection or palette generation.'},
    {'id': 'six-supplied-rectangles-and-configuration-views', 'passed': True,
     'finding': 'Six machine-hash-owned saved tableaux contain 87 existing tile IDs; unique displayed palettes, recorded dimensions/configuration arrays and complete/accepted fields match the consumed ABI. Source only selects/draws existing records and describes saved head/symbol fields; no transition/adjacency validation or witness search executes.'},
    {'id': 'complete-controls-authority-cost-and-scope', 'passed': True,
     'finding': 'All 45 raw control records are accessible. The renderer requires four exact true envelope gates plus both raw-pin shapes; its shape check is explicitly not raw-file verification/admission. Current documents were already independently raw-joined by C. Direct observer/final-gate clocks remain separate, null stays unavailable, Native zero is vacuous, and no proof/universality/GCTS/RL result is inferred.'},
    {'id': 'static-target-navigation-math-and-rendering-boundary', 'passed': True,
     'finding': 'Six exact Root unrun LaTeX target declarations match; 34 unique anchors and final leaf/data/ZIP/manifest links match the handoff. Dynamic record strings are escaped; MathJax is the sole external script. Responsive containment is Source-visible only; no JS or browser/layout/math execution or live-link validation was performed.'},
    {'id': 'point-occupancy-label-versus-normalized-t', 'passed': False,
     'finding': 'HTML line81 prints raw occupancy 12 with SVG label t:12, while line34 and the adjacent LaTeX formula define normalized t=12/12=1. This gives the same t notation two values. The saved point data itself is correct; four assigned marks (including zero), nine roots and twelve boundary marks are retained.',
     'minimum_correction': 'Preserve v1. Change the SVG raw-value label to occupancy:12 (or an explicitly scaled-occupancy label); retain normalized t=12/12=1 in the LaTeX formula. No data/science recomputation is needed.'}
]
failures = [c for c in checks if not c['passed']]
prior_paths = [
    C / 'typed-fixed-Wang-complete-qualification-actual-review-v1.json',
    C / 'typed-fixed-Wang-disposition-and-reader-data-review-v1.json',
    C / 'typed-fixed-Wang-parent-splice-and-prose-Source-review-v1.json',
]
receipt = {
    'schema': 'F-C-fixed-Wang-leaf-reader-Source-review-v1',
    'status': 'DISPLAY_SOURCE_NEGATIVE_ONE_NARROW_LABEL',
    'review_passed': False,
    'HTML': pin(html_path), 'handoff': pin(handoff_path), 'reader_data': data_pin,
    'input_pins': sorted([pin(handoff_path), *handoff['files'], data_pin, target_pin,
                          *[pin(p) for p in prior_paths]], key=lambda p: p['path']),
    'checks': checks, 'failures': failures,
    'counts': {'checks': len(checks), 'passed': len(checks)-len(failures), 'blockers': len(failures),
               'controls': 45, 'palettes': 2, 'tiles_per_palette': 571, 'colors_per_palette': 143,
               'supplied_rectangles': 6, 'saved_rectangle_cells': 87},
    'scope': 'Independent complete current HTML/contract/manual/static Source and saved-data ABI review only. Prior whole actual/data/parent reviews reused by current raw equality. This is one display-label negative, not a new scientific failure or an alteration of Root qualification.',
    'limits': {'scientific_or_subject_calls': 0, 'subject_imports': 0, 'JavaScript_execution': 0,
               'browser_network_QA': False, 'palette_or_expectation_generation': False,
               'partial_files_parsed': 0, 'Root_admission_issued': False,
               'publication_or_installation_authority': False},
    'review_program': pin(__file__),
    'tools_idle_after_receipt': True,
}
with OUT.open('x') as f:
    json.dump(receipt, f, indent=2, ensure_ascii=False)
    f.write('\n')
print(json.dumps({'receipt': pin(OUT), 'checks': len(checks), 'blockers': len(failures)}, sort_keys=True))
