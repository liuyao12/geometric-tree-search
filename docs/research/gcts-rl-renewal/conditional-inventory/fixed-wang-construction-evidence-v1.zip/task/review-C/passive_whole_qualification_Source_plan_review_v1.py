"""C-owned raw/AST-only prospective audit. No subject module is imported or run."""
import ast
import hashlib
import json
from pathlib import Path

F = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021')
C = F/'review-C'
R = F/'root'
checked = {}

def need(value, message):
    if not value:
        raise ValueError(message)

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode()

def pin(path):
    path = Path(path)
    need(path.is_absolute() and path.resolve() == path and path.is_file() and not path.is_symlink(), 'canonical ordinary raw body')
    body = path.read_bytes()
    value = dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())
    if str(path) in checked:
        need(checked[str(path)] == value, 'stable current raw body')
    checked[str(path)] = value
    return value

def raw(value):
    return {key:value[key] for key in ('path', 'bytes', 'sha256')}

def verify(value):
    need(set(value) == {'path', 'bytes', 'sha256'} and type(value['bytes']) is int and value['bytes'] >= 0
         and pin(value['path']) == value, 'strict current raw pin')
    return value

def unique(pairs):
    value = {}
    for key, item in pairs:
        need(key not in value, 'duplicate JSON key')
        value[key] = item
    return value

def load(value):
    if isinstance(value, (Path, str)):
        value = pin(value)
    verify(value)
    need('.partial' not in Path(value['path']).name, 'no partial JSON intake')
    return json.loads(Path(value['path']).read_bytes(), object_pairs_hook=unique,
                      parse_constant=lambda text: (_ for _ in ()).throw(ValueError(text)))

def called(node):
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        parent = called(node.value)
        return (parent+'.'+node.attr) if parent else node.attr
    return None

def calls(node):
    return sorted({called(item.func) for item in ast.walk(node) if isinstance(item, ast.Call) and called(item.func)})

def imports(tree):
    result = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            result.extend(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom):
            result.append(node.module)
    return sorted(set(result))

def assignment(tree, name):
    values = [node.value for node in tree.body if isinstance(node, ast.Assign)
              and any(isinstance(target, ast.Name) and target.id == name for target in node.targets)]
    need(len(values) == 1, 'one exact literal assignment '+name)
    return values[0]

def literal_ast_matches(node, value):
    # AST comparison only; neither expression is evaluated and no fixture is constructed.
    return ast.dump(node, include_attributes=False) == ast.dump(ast.parse(repr(value), mode='eval').body, include_attributes=False)

offer_pin = pin(R/'whole-qualification-prospective-review-request-v1.json')
need((offer_pin['bytes'], offer_pin['sha256']) == (4992, '74eb7a32b8f4072a6b99ec8733c2408496cb8fb94444608da61e440e6a3d45bc'), 'exact whole offer')
offer = load(offer_pin)
need(offer['schema'] == 'Root-fixed-Wang-whole-prospective-Source-review-request-v1'
     and offer['actual_started'] is False and offer['grant_created'] is False
     and offer['scientific_calls'] == offer['scientific_imports'] == 0, 'Source-only whole offer')
protocol_pin, closure_pin, plan_pin = offer['protocol'], offer['closed_inputs'], offer['plan']
protocol, closure, plan = load(protocol_pin), load(closure_pin), load(plan_pin)
need((protocol_pin['bytes'], protocol_pin['sha256']) == (13986, '07cf883bc3e31fabe8defa080d46e3323535e6415d31e073148cec622fac6daa'), 'exact protocol')
need((closure_pin['bytes'], closure_pin['sha256']) == (13893, 'cb31d92e9716f9e9b348858eb8b3e153df1add364c760389e0c824117fc5ecf1'), 'exact closure')
need((plan_pin['bytes'], plan_pin['sha256']) == (10304, 'cf617a26d0435ce51985122605a775cdee920e31f917796e681e0ed86cf13ecd'), 'exact canonical plan')
need(protocol['schema'] == 'Root-fixed-Wang-qualification-protocol-v1'
     and closure['schema'] == 'Root-fixed-Wang-qualification-closed-inputs-v1'
     and plan['schema'] == 'proof-search-case-once-plan-v1', 'exact composed schemas')
need(plan['protocol'] == protocol_pin == closure['protocol'] and plan['closed_inputs'] == closure_pin, 'same current protocol and closure')
need(plan['stage'] == 'qualify' and plan['case_id'] == 'qualify-fixed-wang-0'
     and plan['experiment'] == protocol['experiment'] == 'fixed-Wang-TM-localization-qualification-v1'
     and plan['required_upstream_ids'] == [], 'single cold qualification identity and no upstream')
guards = plan['files']
need(len(guards) == len(closure['files']) == closure['guard_count'] == 25
     and len({row['path'] for row in guards}) == 25
     and guards == [raw(row) for row in closure['files']], 'exact full25 guard list and ordered closure projection')
for row in guards:
    verify(row)
    need('.partial' not in Path(row['path']).name and not any(part in ('actual', 'admission', 'seals', 'publication', '.git', '.gcts-active') for part in Path(row['path']).parts), 'no old/current outcome or publication body in child guards')
guard_map = {row['path']:row for row in guards}
need(str(Path(plan_pin['path'])) not in guard_map and closure_pin['path'] not in guard_map
     and offer_pin['path'] not in guard_map, 'no circular self-guard or full-review intake')
need(set(plan['module_pins']) == {'subject', 'bank'}, 'only two scientific module roles')
for key in ('subject', 'bank'):
    need(plan['module_pins'][key] == protocol[key] and guard_map[protocol[key]['path']] == protocol[key], 'exact frozen module role '+key)
for key in ('worker', 'runner', 'observer'):
    need(plan[key+'_path'] == protocol[key]['path'] and guard_map[protocol[key]['path']] == protocol[key], 'exact Source role '+key)
need(plan['python'] == protocol['python'] == guard_map[protocol['python']['path']], 'exact isolated Python')
expected_caps = dict(work_seconds=160, positive_seconds=180, custody_seconds=210, observer_fallback_seconds=225,
                     memory_bytes=1073741824, physical_bytes=134217728, result_bytes=50331648,
                     log_bytes=4194304, reserved_outer_bytes=9437184, root_callbacks=400000000)
need(plan['limits'] == protocol['limits'] == expected_caps
     and all(type(value) is int for value in plan['limits'].values()), 'all original whole caps unchanged')
need(protocol['job_recipes'] == [dict(Native_requests=0, case_id='qualify-fixed-wang-0', control_bank='independent-fixed-Wang-qualification-v1', required_upstream_ids=[], stage='qualify', top_level_control_count=45, uses=1)], 'single entire45 original once recipe')
for key, expected in [('constructed_literal_trajectory_controls',6), ('first_callback_APIs_per_foreign_class',9), ('foreign_classes',5), ('machine_bound_palette_relation_controls',2), ('once_actual_jobs',1), ('top_level_controls',45)]:
    need(protocol['population'][key] == expected, 'exact declared control population '+key)

trees = {}; definitions = {}; source_audits = []
for key in ('subject', 'bank', 'worker', 'runner', 'observer'):
    source_pin = protocol[key]; body = Path(source_pin['path']).read_bytes()
    tree = ast.parse(body, filename=source_pin['path'])
    unused_code = compile(tree, source_pin['path'], 'exec', dont_inherit=True)
    del unused_code
    trees[key] = tree
    definitions[key] = {node.name:node for node in tree.body if isinstance(node, (ast.FunctionDef, ast.ClassDef))}
    source_audits.append(dict(role=key, Source=source_pin, AST_parsed=True, unused_compile=True,
        imports=imports(tree), definitions=[dict(name=name, line=node.lineno, end_line=node.end_lineno) for name,node in definitions[key].items()]))
need(imports(trees['subject']) == imports(trees['bank']) == ['hashlib', 'json'], 'compiler/bank stdlib-only import surface')
need(imports(trees['worker']) == ['hashlib','importlib.util','json','math','os','pathlib','resource','sys','time','traceback'], 'exact worker stdlib imports')
subject_defs, bank_defs = definitions['subject'], definitions['bank']
for name in ('_reference_step', '_expected_relation'):
    need(not any(name.startswith('subject.') for name in calls(bank_defs[name])), 'independent expectation contains no subject helper call')
need(not any(name == 'subject._local_successor' for name in calls(trees['bank'])), 'bank never calls subject local rule')
reachable = set(); pending = ['validate_tableau']
while pending:
    name = pending.pop()
    if name in reachable:
        continue
    reachable.add(name)
    pending.extend(target for target in calls(subject_defs[name]) if target in subject_defs and target not in reachable)
need('compile_palette' not in reachable and '_local_successor' not in reachable and 'machine_step' in reachable, 'independent whole-tableau validator dependency surface')
worker_caps_node = assignment(trees['worker'], 'CAPS')
need(isinstance(worker_caps_node, ast.Call) and called(worker_caps_node.func) == 'dict'
     and {item.arg:item.value.value for item in worker_caps_node.keywords} == expected_caps, 'worker literal CAPS match exact plan')
for role, constant in [('subject','SUBJECT'),('bank','BANK')]:
    need(literal_ast_matches(assignment(trees['worker'],constant), (protocol[role]['bytes'],protocol[role]['sha256'])), 'worker literal frozen role identity')

all_guard_JSON = []
for row in guards:
    if Path(row['path']).suffix == '.json':
        load(row)
        all_guard_JSON.append(row)
control_def_pin = guard_map[str(F/'diagnostics-L/fixed-Wang-qualification-control-definitions-v1.json')]
control_defs = load(control_def_pin)
control_node = assignment(trees['bank'], 'CONTROL_IDS')
need(isinstance(control_node, ast.List) and all(isinstance(item,ast.Constant) and type(item.value) is str for item in control_node.elts), 'literal bank ID list only')
control_ids = [item.value for item in control_node.elts]
need(len(control_ids) == len(set(control_ids)) == 45 and control_ids == protocol['control_order']
     == [row['id'] for row in control_defs['controls']] and control_defs['control_count'] == 45
     and all(row['status'] == 'UNRUN' for row in control_defs['controls']), 'all45 literal bank/definition/protocol IDs and order')
need(literal_ast_matches(assignment(trees['bank'],'MACHINE'), control_defs['literal_machine'])
     and literal_ast_matches(assignment(trees['bank'],'WITNESSES'), control_defs['literal_trajectories'])
     and len(control_defs['literal_trajectories']) == 5, 'manual literal machine/witness declarations match published definitions by AST only')
control_ledger = []
for ordinal, identity in enumerate(control_ids):
    if ordinal < 2:
        kind = 'complete independent emitted local/frame relation'
    elif ordinal < 7:
        kind = 'literal whole-word global-step observation'
    elif ordinal < 21:
        kind = 'exact owned intake/global/codec/boundary refusal'
    elif ordinal < 27:
        kind = 'constructed supplied accepting trajectory; never search'
    elif ordinal < 32:
        kind = 'complete cap-language observation; never grid search'
    elif ordinal < 36:
        kind = 'exact owned corrupted supplied-tableau refusal'
    elif ordinal < 40:
        kind = 'literal point adapter or strict bool refusal'
    else:
        kind = 'one foreign class, nine exact first-callback API identities'
    control_ledger.append(dict(ordinal=ordinal,id=identity,qualification_kind=kind,
        declaration_line=control_node.elts[ordinal].lineno,Source_reviewed=True,execution_status='UNRUN',
        expected_scope=control_defs['controls'][ordinal]['expected']))

argument = load(offer['construction_argument'])
need(argument['schema'] == 'F-L-finite-framed-TM-Wang-construction-argument-v1'
     and [row['id'] for row in argument['lemmas_by_source_inspection']]
         == ['L1_local_update','L2_forced_phases_and_walls','L3_old_triple_consistency','L4_one_head_induction','L5_cap_acceptance'], 'exact separate handwritten construction argument')
for row in argument['inputs']:
    verify(row)
load(offer['next_verifier_obligations'])
load(offer['offer'])
for row in offer['component_review_basis']:
    review = load(row)
    need(review['review_passed'] is True and review['checks'] and all(item['passed'] is True for item in review['checks']) and review['failures'] == [], 'current authored component review; not independent whole qualification authority')

absence = dict(actual=Path(plan['actual_dir']), observer=Path(plan['actual_dir']+'.observer'), grant=Path(protocol['canonical_paths']['grant']))
need(plan['actual_dir'] == protocol['canonical_paths']['actual']
     and plan_pin['path'] == protocol['canonical_paths']['plan']
     and protocol_pin['path'] == protocol['canonical_paths']['protocol']
     and closure_pin['path'] == protocol['canonical_paths']['closure'], 'canonical current paths')
need(all(not path.exists() for path in absence.values()), 'no qualification actual/observer/grant yet')
need(not any('FPC' in path or 'logical-calculus' in path or 'proof_calculus' in path for path in guard_map), 'separate logical-calculus design excluded')
for row in tuple(checked.values()):
    verify(row)
need(all(not path.exists() for path in absence.values()), 'absence remains current at freeze')

checks = [
 ('exact-current-offer-protocol-plan-and25guards', 'The exact Root offer, protocol07cf883b, closed-inputscb31d92e and plan cf617a26 compose one cold qualify-fixed-wang-0 job. Every current25 raw guard is unique and matches the complete ordered closure projection; worker, bank, compiler, parent, observer, Python and semantic roles join exactly. Closure, plan, grant and this review do not self-pin in child guards.'),
 ('typed-deterministic-machine-and-canonical-colors', 'Source requires finite typed symbols/states, total single-valued nonhalt transitions and exact integer moves; bool/duplicate/missing transitions are refused. Accept and reject stutter under the explicit normalization. Canonical tagged configuration, old-pair, input, frame, outer and cap labels are disjoint structured values before deterministic integer IDs. Assigned color zero is retained.'),
 ('complete-core-rule-and-neighborhood-enumeration', 'All zero-head and three possible one-head locations are enumerated with real centers and only corresponding left/right ghosts. A moving head writes at its source and the arriving head reads the old destination symbol; stationary heads use the written symbol. An outward move is omitted at the center-head wall neighborhood. No local nondeterministic choice or per-cell invention is present.'),
 ('input-frame-phase-and-unique-accept-cap', 'Top descriptors force one prescribed start head and fixed/plain free-symbol input choices only. Tagged colors force one input row, persistent wall columns, exactly the declared core rows and one last cap row. Bottom colors cannot continue upward. The cap has only BEFORE-to-AFTER at an actual accept head; plain cells preserve the flag, so it admits exactly one accept head and no rejecting, headless or two-head cap.'),
 ('conditional-two-way-mathematical-correspondence', 'Manual Source reasoning independently checks pair-overlap reconstruction, vertical identity, initial single-head induction, wall-safe unique successors and accepting cap soundness. Conversely each legal bounded accepting run has all required selector/core/wall/cap records in the exact completed constructor output, including width1 and zero-step accepting start. This is a conditional finite-rectangle handwritten/static argument, not a formal certificate, generated palette observation or whole-plane theorem.'),
 ('global-validator-distinct-from-palette-coverage', 'validate_tableau checks exact boundary, every typed tile ID and adjacency, decoded input and each full independent global machine_step, plus the final unique accept head. Its reachable Source helpers contain neither compile_palette nor _local_successor. Shape-valid palette carriers and one supplied witness do not prove relation completeness; the reviewed theorem explicitly requires exact completed output, and the bank separately compares the whole emitted relation.'),
 ('independent-complete-relation-bank-and-padding', 'For both frozen machine declarations, bank expectation traverses the entire declared alphabet cube, retaining defined/undefined triples. Its own T/H whole-word step and padding at only un-walled ends determine the center update, without subject local/global helpers. Padding correctly preserves locally legal outward off-center movement; a center next to a real ghost cannot escape. The full frame, color catalogue, sorted records, certificates and IDs are compared, including absence of duplicate edge tuples.'),
 ('entire45control-bank-and-six-supplied-trajectories', 'All45 IDs and order match Source, full control definitions and Root protocol. Two full relation controls, literal global cases, strict refusals, cap-language observations and point cases are checked manually against Source. Five main trajectories plus the separate accepting-start zero-step trajectory are correctly supplied construction witnesses, not GCTS discovery, proof search or independent stochastic trials. A full receipt requires every row; no sampled subset or failed prefix qualifies.'),
 ('owned-refusals-and-foreign-first-identity', 'Refusal catches accept only the subject exact private-owner Invalid predicate and immediately rethrow any other error. Each of five foreign classes exercises nine public APIs at the first callback. The sentinel is raised only after the genuine Root check; a nonsentinel exception is bare re-raised before another callback. The source intentionally claims first-callback scope, not exhaustive internal interruption coverage.'),
 ('point-t-m-adapter-and-master-conformance-boundary', 'Scaled integer translations put occupancy12 at each required center of capacity12 and all four exact color marks at edge midpoints. All board centers are generation0 roots; color0 remains assigned. Under the declared full in-board placement universe this represents oriented Wang equality without a geometric predicate. No Graph/State, complete incidence, scheduler or rollback engine is run or qualified; those master-contract integration obligations remain explicit.'),
 ('cold-worker-intake-imports-and-sticky-first-fault', 'The worker accepts exact consumed once identity and current25 guards, verifies compiler/bank byte identities, and imports only those two exact paths using fresh owned module names. Genuine Root callbacks latch their first work/callback/HWM fault. All imports, expectation generation, copying/hashing, construction, witness validation and full result serialization are charged from parent ROOT_START. Foreign failures or changed Source prevent a complete qualification result.'),
 ('whole-output-no-prefix-and-vacuous-Native', 'Success requires the entire45-row exact-version receipt and unchanged Source. Full result serialization has before/after work checks and a complete byte ceiling; any fault selects failure.json with qualification_result null. Post-output header pins bind current result and HWM. Native imports, binary/table/oracle processes and queries are absent; zero/closed/reaped compatibility fields are explicitly vacuous and convey no logical proof authority.'),
 ('unchanged-owned-custody-and-all-original-caps', 'The exact unchanged custodian/observer Sources consume one grant, create fresh directories, own worker groups and bounded logs, close groups and drain threads, and rehash guards. Work160, positive180, custody210 and fallback225 remain distinct. Strict wholepeak<1GiB includes parent/worker/observer/reserves; physical128MiB, result48MiB, log4MiB, outer9MiB and400m callbacks are unchanged. No added header.seconds<=160 predicate or fit/realtime guarantee is inferred.'),
 ('closed-intake-no-history-or-new-calculus', 'The closed scientific intake is only the literal bank and exact five executed/imported Sources plus pinned runtime/semantic guards. No D19/D20/D21 result, proof, library, policy, admission, seal, publication body or Native program is adopted. New FPC-H1 logical-calculus design stays outside all25 guards and this qualification. The handwritten verifier-obligation note is context, not implementation or an expanded bank.'),
 ('static-current-Source-and-future-authority-only', 'All25 guards and additional named offer/argument/component metadata rehash unchanged. Five Python Sources parse and unused-compile without execution; compiler/bank imports are only json/hashlib and the worker/custodians use explicit stdlib paths. Actual, observer and one-use grant paths are absent. This independent C whole Source/plan PASS does not issue a grant, forecast fit, qualify a generated palette, admit an actual or authorize publication. Fresh Root tools-idle once grant and independent complete actual/custody/resource review remain required.')
]
receipt = dict(schema='F-C-fixed-Wang-whole-prospective-Source-plan-review-v1',review_passed=True,
    case_id=plan['case_id'],stage=plan['stage'],whole_offer=offer_pin,protocol=protocol_pin,closed_inputs=closure_pin,plan=plan_pin,
    subject=protocol['subject'],bank=protocol['bank'],worker=protocol['worker'],runner=protocol['runner'],observer=protocol['observer'],python=protocol['python'],
    input_pins=sorted(guards,key=lambda row:row['path']),guard_count=25,limits=expected_caps,
    control_count=45,control_order=control_ids,control_Source_ledger=control_ledger,
    prospective_population=protocol['population'],construction_argument=offer['construction_argument'],
    next_verifier_obligations=offer['next_verifier_obligations'],component_review_basis=offer['component_review_basis'],
    component_reviews_are_not_whole_authority=True,Source_audits=source_audits,
    validator_static_reachable_helpers=sorted(reachable),bank_reference_static_calls={key:calls(bank_defs[key]) for key in ('_reference_step','_expected_relation')},
    absent_paths={key:str(value) for key,value in absence.items()},all_current_pins=sorted(checked.values(),key=lambda row:row['path']),
    checks=[dict(id=key,passed=True,finding=value) for key,value in checks],failures=[],
    scientific_imports=0,scientific_calls=0,subject_module_imports=0,subject_functions_called=0,
    compiler_invocations=0,bank_invocations=0,worker_invocations=0,helper_invocations=0,
    palettes_generated=0,fixtures_or_tableaux_constructed=0,controls_executed=0,partial_files_parsed=0,
    actual_started=False,grant_issued=False,Root_admission_issued=False,
    static_execution='Only C-owned stdlib raw/JSON/AST checks and discarded unused compile objects; no experimental Source execution.',
    scope='Independent prospective whole exact Source/plan review for the single original finite construction qualification only. No formal universal theorem, verifier instantiation, proof discovery, GCTS/RL/utility claim, actual qualification, resource-fit prediction, execution grant or publication authority.',
    review_program=pin(Path(__file__).resolve()),tools_idle_after_freeze=True)
output=C/'typed-fixed-Wang-whole-prospective-Source-plan-review-v1.json'
with output.open('xb') as stream:
    stream.write((json.dumps(receipt,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode())
print(json.dumps(pin(output)))
print(json.dumps(dict(checks=len(checks),failures=0,guard_count=25,controls_UNRUN=45,unused_compiled_Sources=5,tools_idle=True)))
