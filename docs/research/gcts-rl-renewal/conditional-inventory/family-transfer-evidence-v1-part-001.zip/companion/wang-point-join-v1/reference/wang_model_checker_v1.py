"""Independent finite Wang model, selected-tile decoder and Boolean oracle.

Standard library only. No fixture, palette generator, solver, graph checker or
certificate builder is imported. Boolean enumeration is a post-search API;
verify_model itself never chooses input bits or constructs a tiling witness.
"""
import hashlib
import itertools
import json
import re


VERSION = 'Independent-tiny-Wang-model-and-decoder-v1'
OPS = ('CROSS', 'READ', 'NAND', 'NOT', 'WRITE')
PALETTE_SOURCE_SHA256 = '8d4c09e1977302fd89454f1ab6d8b752d475c0a1a318ddcedac3f434518635fc'


class Refusal(ValueError):
    pass


def _need(condition, reason):
    if not condition:
        raise ValueError(reason)


def _wire(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       separators=(',', ':'), allow_nan=False)+'\n').encode('ascii')


def _sha(value):
    return hashlib.sha256(_wire(value)).hexdigest()


def _guard(operation, function):
    try:
        return dict(version=VERSION, operation=operation, **function())
    except (Refusal, MemoryError, RecursionError) as error:
        return dict(version=VERSION, operation=operation, status='UNKNOWN', reason=str(error))
    except (ValueError, TypeError, KeyError, IndexError) as error:
        return dict(version=VERSION, operation=operation, status='REJECTED', reason=str(error))


def palette_table():
    """Decode every integer ID independently, rather than import a palette."""
    rows = []
    for identifier in range(100):
        operation_word, following = divmod(identifier, 5)
        operation, bit_word = divmod(operation_word, 4)
        north, west = divmod(bit_word, 2)
        if operation == 0:
            east, south = west, north
        elif operation == 1:
            east, south = north, north
        elif operation == 2:
            east, south = int(not (north == 1 and west == 1)), north
        elif operation == 3:
            east, south = int(north == 0), north
        else:
            east, south = west, west
        rows.append(dict(id=identifier, N=[OPS[operation], north], S=[OPS[following], south],
                         W=west, E=east))
    return dict(schema='FP-fixed-Wang-palette-v1', tiles=rows)


def _circuit(prepared):
    circuit = prepared['fixture']['circuit']
    _need(type(circuit) is dict and set(circuit) == {'schema', 'inputs', 'gates', 'output'}
          and circuit['schema'] == 'FP-NAND-circuit-v1', 'CIRCUIT_SCHEMA')
    inputs, gates = circuit['inputs'], circuit['gates']
    _need(type(inputs) is list and len(inputs) >= 2 and type(gates) is list and gates, 'NONEMPTY_CIRCUIT')
    names = set()
    for item in inputs:
        _need(type(item) is dict and set(item) == {'name', 'value'} and type(item['name']) is str
              and item['name'] and item['name'] not in names, 'INPUT_SIGNATURE')
        names.add(item['name'])
        _need(item['value'] is None or type(item['value']) is int and item['value'] in (0, 1), 'INPUT_BIT_TYPE')
    _need(inputs[:2] == [dict(name='zero', value=0), dict(name='one', value=1)], 'CONSTANT_INPUTS')
    for y, gate in enumerate(gates):
        _need(type(gate) is list and len(gate) == 2 and all(type(v) is int and
              0 <= v < len(inputs)+y for v in gate), 'STRICTLY_PRIOR_NAND_REFERENCES')
    _need(type(circuit['output']) is int and 0 <= circuit['output'] < len(inputs)+len(gates), 'OUTPUT_REFERENCE')
    width, height = len(inputs)+len(gates), len(gates)
    if width*height > 100:
        raise Refusal('TINY_LITERAL_CELL_CAP100')
    return circuit, width, height


def _role(circuit, x, y):
    if y == len(circuit['gates']):
        return 'CROSS'
    a, b = circuit['gates'][y]
    if x == len(circuit['inputs'])+y:
        return 'WRITE'
    if a == b:
        return 'NOT' if x == a else 'CROSS'
    if x == min(a, b):
        return 'READ'
    if x == max(a, b):
        return 'NAND'
    return 'CROSS'


def _v(x, y, component):
    return 'v:%d:%d:%s' % (x, y, component)


def _h(x, y):
    return 'h:%d:%d:bit' % (x, y)


def _center(x, y):
    return 'c:%d:%d' % (x, y)


def _point_map(rows, positive):
    _need(type(rows) is list, 'POINT_ROW_ARRAY')
    result = {}
    for pair in rows:
        _need(type(pair) is list and len(pair) == 2, 'POINT_ROW_PAIR')
        p, value = pair
        _need(type(p) is str and p not in result, 'UNIQUE_LITERAL_POINT')
        _need((type(value) is int and value > 0) if positive else type(value) is str, 'POINT_VALUE_TYPE')
        result[p] = value
    return result


def _row(row):
    _need(type(row) is dict and set(row) == {'id', 't', 'm'} and type(row['id']) is str, 'PLACEMENT_FIELDS')
    t, m = _point_map(row['t'], True), _point_map(row['m'], False)
    _need(t, 'POSITIVE_CENTER_REQUIRED')
    return dict(id=row['id'], t=sorted([p, v] for p, v in t.items()),
                m=sorted([p, v] for p, v in m.items()))


def _tile_row(x, y, tile):
    return dict(id='%04d:%04d:%02d' % (y, x, tile['id']), t=[[_center(x, y), 1]],
        m=sorted([[_v(x, y, 'op'), tile['N'][0]], [_v(x, y, 'bit'), str(tile['N'][1])],
                  [_v(x, y+1, 'op'), tile['S'][0]], [_v(x, y+1, 'bit'), str(tile['S'][1])],
                  [_h(x, y), str(tile['W'])], [_h(x+1, y), str(tile['E'])]]))


def _admit(prepared):
    circuit, width, height = _circuit(prepared)
    fixture, model = prepared['fixture'], prepared['model']
    _need(fixture['schema'] == 'Fresh-literal-Wang-fixture-v1', 'FIXTURE_SCHEMA')
    for name, value in dict(width=width, height=height, cells=width*height, all_types_per_cell=100,
                            cell_cap=100, acceptance_bit=1).items():
        _need(type(fixture[name]) is int and fixture[name] == value, 'FIXTURE_DIMENSION:'+name)
    _need(fixture['actions'] == 'TRANSLATIONS_ONLY', 'NO_ROTATIONS_OR_REFLECTIONS')
    _need(fixture['generator_source_sha256'] == PALETTE_SOURCE_SHA256, 'GENERATOR_SOURCE_BINDING')
    _need(prepared['supplied_boolean_witness'] is False, 'NO_SUPPLIED_BOOLEAN_WITNESS')
    palette = palette_table()
    _need(_wire(prepared['palette']) == _wire(palette), 'EXACT100_DECORATED_TYPES')
    _need(fixture['palette_sha256'] == _sha(palette) and fixture['circuit_sha256'] == _sha(circuit),
          'PALETTE_AND_CIRCUIT_HASH_BINDINGS')
    _need(len({(tuple(t['N']), tuple(t['S']), t['W'], t['E']) for t in palette['tiles']}) == 100,
          'DISTINCT100_EDGE_QUADRUPLES')
    _need(type(model) is dict and set(model) == {'schema', 'version', 'capacity', 'roots', 'seed', 'inventory'},
          'POINT_MODEL_FIELDS')
    _need(model['schema'] == 'Z-growing-point-model-v1' and model['version'] == 'FP-finite-Wang-point-model-v1'
          and type(model['capacity']) is int and model['capacity'] == 1, 'POINT_CAPACITY_AND_PROFILE')
    expected_roots = {_center(x, y) for y in range(height) for x in range(width)}
    _need(type(model['roots']) is list and all(type(p) is str for p in model['roots'])
          and len(model['roots']) == len(expected_roots) and set(model['roots']) == expected_roots,
          'ALL_CELL_CENTERS_REQUIRED_ONCE')
    _need(type(model['seed']) is dict and set(model['seed']) == {'t', 'm'} and model['seed']['t'] == [],
          'NO_SELECTED_TILE_OR_POSITIVE_SEED_WITNESS')
    pins = {_v(x, y, 'op'): _role(circuit, x, y)
            for y in range(height+1) for x in range(width)}
    for x in range(width):
        known = circuit['inputs'][x]['value'] if x < len(circuit['inputs']) else 0
        if known is not None:
            pins[_v(x, 0, 'bit')] = str(known)
    pins[_v(circuit['output'], height, 'bit')] = '1'
    for y in range(height):
        pins[_h(0, y)] = '0'
    _need(_point_map(model['seed']['m'], False) == pins, 'EXACT_PROGRAM_CONSTANT_AND_ACCEPTANCE_PINS')
    _need(type(model['inventory']) is dict and set(model['inventory']) == {'kind', 'placements'}
          and model['inventory']['kind'] == 'EXPLICIT', 'EXPLICIT_COMPLETE_CELL_INVENTORY')
    expected = {}
    for y in range(height):
        for x in range(width):
            for tile in palette['tiles']:
                row = _tile_row(x, y, tile)
                expected[row['id']] = row
    for rows in (model['inventory']['placements'], prepared['universe']):
        _need(type(rows) is list and len(rows) == 100*width*height, 'ALL100_TYPES_PER_CELL_NOT_PREFILTERED')
        actual = {}
        for supplied in rows:
            row = _row(supplied)
            _need(row['id'] not in actual, 'DUPLICATE_CELL_TILE_ID')
            actual[row['id']] = row
        _need(_wire(actual) == _wire(expected), 'EXACT_TRANSLATED_POINT_AND_EDGE_MARK_ROWS')
    return circuit, width, height, palette, expected, pins


def verify_model(prepared):
    def run():
        circuit, width, height, palette, rows, pins = _admit(prepared)
        return dict(status='VERIFIED', reason='INDEPENDENT_FIXED100_PALETTE_CELL_AND_PROGRAM_RECONSTRUCTION',
            width=width, height=height, cells=width*height, palette_types=100,
            placements=len(rows), free_inputs=sum(item['value'] is None for item in circuit['inputs']),
            fixed_mark_ports=len(pins), palette_sha256=_sha(palette), circuit_sha256=_sha(circuit),
            model_sha256=_sha(prepared['model']), universe_sha256=_sha(sorted(rows.values(), key=lambda r: r['id'])),
            scope='All100 ordinary fixed-orientation Wang types offered at every required cell; interior selectors are problem pins. No Boolean input witness computed.')
    return _guard('verify_model', run)


def _selected_ids(selected, expected):
    _need(type(selected) is list, 'SELECTED_PLACEMENT_ARRAY')
    ids = []
    for item in selected:
        if type(item) is str:
            cid = item
        else:
            row = _row(item)
            cid = row['id']
            _need(cid in expected and _wire(row) == _wire(expected[cid]), 'SELECTED_IMMUTABLE_ROW')
        _need(cid in expected and cid not in ids, 'SELECTED_UNKNOWN_OR_REPEATED_ID')
        ids.append(cid)
    return ids


def _decode(prepared, selected):
    circuit, width, height, palette, expected, pins = _admit(prepared)
    ids = _selected_ids(selected, expected)
    cells, assignments = {}, dict(pins)
    for cid in ids:
        match = re.fullmatch(r'(\d{4}):(\d{4}):(\d{2})', cid)
        _need(match is not None, 'TRANSLATION_ONLY_CELL_TILE_ID')
        y, x, tile_id = map(int, match.groups())
        _need((x, y) not in cells and 0 <= x < width and 0 <= y < height and 0 <= tile_id < 100,
              'EXACTLY_ONE_TILE_PER_CELL')
        cells[x, y] = palette['tiles'][tile_id]
        for p, value in expected[cid]['m']:
            _need(p not in assignments or assignments[p] == value, 'EXACT_SHARED_EDGE_OR_PIN_MATCH')
            assignments[p] = value
    _need(set(cells) == {(x, y) for y in range(height) for x in range(width)}, 'COMPLETE_RECTANGLE_REQUIRED')
    input_bits = [cells[x, 0]['N'][1] for x in range(len(circuit['inputs']))]
    values = list(input_bits)
    for item, bit in zip(circuit['inputs'], input_bits):
        _need(item['value'] is None or item['value'] == bit, 'DECODED_FIXED_INPUT')
    gate_bits = []
    for y, (a, b) in enumerate(circuit['gates']):
        bit = cells[len(input_bits)+y, y]['S'][1]
        _need(bit == int(not (values[a] and values[b])), 'DECODED_GATE_NAND_TRUTH')
        gate_bits.append(bit)
        values.append(bit)
    wires = input_bits+[0]*height
    for y in range(height):
        bus = 0
        next_wires = []
        for x in range(width):
            tile = cells[x, y]
            _need(tile['N'] == [_role(circuit, x, y), wires[x]] and tile['W'] == bus,
                  'ROW_NORTH_AND_HORIZONTAL_TRANSPORT')
            _need(tile['S'][0] == _role(circuit, x, y+1), 'INTERIOR_PROGRAM_SELECTOR')
            next_wires.append(tile['S'][1])
            bus = tile['E']
        wires = next_wires
    output = values[circuit['output']]
    _need(output == 1 and wires[circuit['output']] == 1, 'BOTTOM_ACCEPTANCE_BIT')
    return dict(status='VERIFIED', reason='ACTUAL_SELECTED_WANG_TILES_DECODE_TO_ACCEPTING_BOOLEAN_ASSIGNMENT',
        cells=width*height, selected_count=len(ids), selected_ids_sha256=_sha(sorted(ids)),
        input_bits=input_bits, gate_bits=gate_bits, output_bit=output,
        free_input_values={item['name']: bit for item, bit in zip(circuit['inputs'], input_bits) if item['value'] is None},
        tiles=[dict(x=x, y=y, tile_id=cells[x, y]['id']) for y in range(height) for x in range(width)],
        circuit_sha256=_sha(circuit), palette_sha256=_sha(palette), model_sha256=_sha(prepared['model']),
        scope='Reverse decoding of solver-selected primitive tiles, not a tiling constructed from a supplied Boolean witness. Native frontier trace assurance is separate.')


def decode_selected(prepared, selected):
    return _guard('decode_selected', lambda: _decode(prepared, selected))


def _truth_table(prepared):
    circuit, width, height = _circuit(prepared)
    free = [i for i, item in enumerate(circuit['inputs']) if item['value'] is None]
    if len(free) > 12:
        raise Refusal('BOOLEAN_EXHAUSTION_FREE_INPUT_CAP12')
    rows, accepted = [], 0
    for choice in itertools.product((0, 1), repeat=len(free)):
        bits = [item['value'] for item in circuit['inputs']]
        for i, bit in zip(free, choice):
            bits[i] = bit
        values = list(bits)
        for a, b in circuit['gates']:
            values.append(0 if values[a] == values[b] == 1 else 1)
        output = values[circuit['output']]
        accepted += output == 1
        rows.append(dict(input_bits=bits, gate_bits=values[len(bits):], output_bit=output, accepts=output == 1))
    return dict(status='VERIFIED', reason='INDEPENDENT_EXHAUSTIVE_BOOLEAN_EXISTENCE',
        circuit_sha256=_sha(circuit), assignments=len(rows), accepting_assignments=accepted,
        satisfiable=accepted > 0, rows=rows,
        scope='Post-search Boolean oracle only. No tile assignment or input bits from this table are supplied to search.')


def boolean_existence(prepared):
    """Call only after the declared primitive search; does not run a solver."""
    return _guard('boolean_existence', lambda: _truth_table(prepared))


def verify_result(prepared, result):
    """Post-search palette decoding/existence join, separate from graph audit."""
    def run():
        _admit(prepared)
        truth = _truth_table(prepared)
        search_status = result['status']
        _need(search_status in ('SAT', 'UNSAT', 'UNKNOWN'), 'SEARCH_STATUS')
        if search_status == 'UNKNOWN':
            return dict(status='UNKNOWN', reason='PRIMITIVE_SEARCH_INCOMPLETE', boolean_existence=truth)
        if search_status == 'UNSAT':
            _need(not truth['satisfiable'], 'EXHAUSTED_TILE_SEARCH_CONTRADICTS_BOOLEAN_EXISTENCE')
            _need(result['certificate'] is None and result['selected'] == [], 'NEGATIVE_RESULT_HAS_SELECTED_CERTIFICATE')
            return dict(status='VERIFIED', reason='FINITE_WANG_EXISTENCE_AGREES_WITH_EXHAUSTIVE_BOOLEAN_ORACLE',
                        search_status=search_status, boolean_existence=truth,
                        scope='Boolean equivalence for this exact finite program; native exhaustive frontier trace must be checked separately.')
        certificate = result['certificate']
        _need(type(certificate) is dict and type(certificate['capacity']) is int and certificate['capacity'] == 1,
              'POINT_SOLUTION_CERTIFICATE_REQUIRED')
        decoded = _decode(prepared, certificate['placements'])
        _need(sorted(result['selected']) == sorted(row['id'] for row in certificate['placements']),
              'SEARCH_SELECTED_AND_CERTIFICATE_JOIN')
        _need(truth['satisfiable'], 'DECODED_TILING_CONTRADICTS_BOOLEAN_EXISTENCE')
        return dict(status='VERIFIED', reason='SEARCH_TO_LITERAL_PALETTE_TO_BOOLEAN_JOIN', search_status=search_status,
            decoded=decoded, boolean_existence=truth,
            scope='Fresh tiny circuit qualification, not mathematical theorem search, universal logical completeness or a speed comparison.')
    return _guard('verify_result', run)
