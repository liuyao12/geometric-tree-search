"""Fresh finite literal Wang search inputs; no Boolean witness is supplied.

prepare() only constructs complete point inventories from fixed circuits.
Independent Boolean enumeration/decoding is a separate post-search API.
"""
import hashlib
import importlib.util
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PALETTE_SOURCE_SHA256 = '8d4c09e1977302fd89454f1ab6d8b752d475c0a1a318ddcedac3f434518635fc'


def _wire(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       separators=(',', ':'), allow_nan=False)+'\n').encode('ascii')


def _upstream():
    path = ROOT/'reference/fixed_palette_upstream_v1.py'
    if hashlib.sha256(path.read_bytes()).hexdigest() != PALETTE_SOURCE_SHA256:
        raise ValueError('Pinned fixed-palette generator Source differs.')
    spec = importlib.util.spec_from_file_location('fixed_palette_for_fresh_wang', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def declarations():
    """Circuit programs only. No evaluate/certificate/truth-table call here."""
    def inputs(*names):
        return [dict(name='zero', value=0), dict(name='one', value=1)]+[
            dict(name=name, value=None) for name in names]

    return [
        dict(id='wj-two-gate-asymmetric', label='Two-gate asymmetric NAND chain',
             circuit=dict(schema='FP-NAND-circuit-v1', inputs=inputs('alpha', 'beta'),
                          gates=[[2, 3], [4, 2]], output=5)),
        dict(id='wj-three-gate-reuse', label='Three-gate NAND circuit with a reused source',
             circuit=dict(schema='FP-NAND-circuit-v1', inputs=inputs('rho', 'sigma'),
                          gates=[[2, 3], [2, 4], [5, 3]], output=6)),
        dict(id='wj-four-gate-parity', label='Four-gate NAND circuit with two free inputs',
             circuit=dict(schema='FP-NAND-circuit-v1', inputs=inputs('eta', 'theta'),
                          gates=[[2, 3], [2, 4], [3, 4], [5, 6]], output=7)),
        dict(id='wj-three-gate-inconsistent-output', label='Free-input circuit with an impossible acceptance pin',
             circuit=dict(schema='FP-NAND-circuit-v1', inputs=inputs('kappa'),
                          gates=[[2, 2], [2, 3], [4, 4]], output=5)),
    ]


def prepare():
    """Return all100 types at every cell, before any Boolean/search outcome.

    Seed values specify the circuit program, constants, initial unused-wire
    zeros, west bus zeros and bottom acceptance1. Free input bits stay absent.
    Interior program selectors are explicit problem-defining pins.
    """
    fp = _upstream()
    palette = fp.palette()
    result = []
    for declaration in declarations():
        circuit = declaration['circuit']
        width = len(circuit['inputs'])+len(circuit['gates'])
        height = len(circuit['gates'])
        if not 0 < width*height <= 100:
            raise ValueError('Tiny literal point-model cell cap exceeded.')
        model = fp.point_model(circuit, palette)
        universe = model['inventory']['placements']
        if len(universe) != 100*width*height:
            raise ValueError('The complete100-type-per-cell inventory was not constructed.')
        fixture = dict(schema='Fresh-literal-Wang-fixture-v1', id=declaration['id'],
            label=declaration['label'], circuit=circuit, width=width, height=height,
            cells=width*height, all_types_per_cell=100, cell_cap=100, acceptance_bit=1,
            circuit_sha256=hashlib.sha256(_wire(circuit)).hexdigest(),
            palette_sha256=hashlib.sha256(_wire(palette)).hexdigest(),
            generator_source_sha256=PALETTE_SOURCE_SHA256,
            actions='TRANSLATIONS_ONLY', program='Operation pins at every vertical edge, including the interior.',
            scope='Tiny primitive fixed-palette search qualification; not logical proof search, outer-boundary universality or a performance claim.')
        result.append(dict(fixture=fixture, palette=palette, model=model,
                           universe=universe, supplied_boolean_witness=False))
    return result
