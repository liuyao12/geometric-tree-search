"""Byte/ZIP utilities; no scientific code, networking or Git operations."""
import hashlib
import json
from pathlib import Path,PurePosixPath
import zipfile

ROOT=Path(__file__).resolve().parents[1]
PREFIX='docs/research/gcts-rl-renewal/conditional-inventory/'
BASE_URL='https://liuyao12.github.io/geometric-tree-search/'
MANIFEST='family-transfer-evidence-manifest-v1.json'
INTERNAL='ARCHIVE-file-manifest-v1.json'
PART_STEM='family-transfer-evidence-v1-part-'
MAX_PART=44*1024*1024

def wire(v):return (json.dumps(v,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')
def digest(raw):return hashlib.sha256(raw).hexdigest()
def stream_pin(stream):
    h=hashlib.sha256();size=0
    for block in iter(lambda:stream.read(1048576),b''):h.update(block);size+=len(block)
    return dict(bytes=size,sha256=h.hexdigest())
def pin(path):
    with path.open('rb') as f:return stream_pin(f)
def relative_name(value):
    assert type(value) is str and value and '\\' not in value and '\x00' not in value
    p=PurePosixPath(value)
    assert not p.is_absolute() and all(v not in ('','.','..') for v in p.parts) and p.as_posix()==value
    return value
def local(root,value):
    p=root/relative_name(value);assert root.resolve() in p.resolve().parents
    return p
def inventory_from_manifest(manifest):
    assert manifest['schema']=='PFT-physical-multipart-evidence-v1' and manifest['inventory_file']==INTERNAL
    core={k:v for k,v in manifest.items() if k not in ('inventory_sha256','inventory_schema','inventory_file')}
    core['schema']=manifest['inventory_schema']
    core['parts']=[dict(number=p['number'],name=p['name']) for p in manifest['parts']]
    assert core['schema']=='PFT-physical-evidence-inventory-v1' and digest(wire(core))==manifest['inventory_sha256']
    return core
def verify_archive(folder,manifest):
    core=inventory_from_manifest(manifest);entries=manifest['files'];by_path={e['path']:e for e in entries}
    assert len(by_path)==len(entries)==manifest['original_files'] and manifest['all_originals_physically_stored'] is True
    assert sum(e['bytes'] for e in entries)==manifest['original_bytes']
    for e in entries:
        relative_name(e['path']);assert type(e['part']) is int and 1<=e['part']<=len(manifest['parts'])
    parts=[];verified=set()
    for number,part in enumerate(manifest['parts'],1):
        assert part['number']==number and part['name']==PART_STEM+'%03d.zip'%number
        archive=local(folder,part['name']);actual=pin(archive)
        assert wire(actual)==wire({k:part[k] for k in ('bytes','sha256')}) and actual['bytes']<=MAX_PART and actual['bytes']<50*1024*1024
        expected={e['path'] for e in entries if e['part']==number}
        with zipfile.ZipFile(archive) as z:
            assert len(z.namelist())==len(set(z.namelist())) and set(z.namelist())==expected|{INTERNAL}
            assert z.read(INTERNAL)==wire(core) and z.testzip() is None
            for name in sorted(expected):
                e=by_path[name];assert name not in verified and z.getinfo(name).file_size==e['bytes']
                with z.open(name) as stream:p=stream_pin(stream)
                assert wire(p)==wire({k:e[k] for k in ('bytes','sha256')});verified.add(name)
        parts.append(dict(number=number,name=part['name'],**actual,CRC='PASS'))
    assert verified==set(by_path)
    return dict(status='PASS',original_files=len(entries),all_original_files_physically_stored=True,
        all_original_paths_byte_verified=True,all_CRC_verified=True,parts=parts)
