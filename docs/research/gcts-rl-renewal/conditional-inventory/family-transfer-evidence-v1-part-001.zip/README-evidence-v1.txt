Arithmetic/incidence proof-family transfer evidence, 2026-11-03.

Download EVERY family-transfer-evidence-v1-part-NNN.zip and the external
family-transfer-evidence-manifest-v1.json. Each volume is a separate valid ZIP,
at most forty-four MiB. Extract all volumes into one empty directory. Each has
the identical ARCHIVE-file-manifest-v1.json; identical copies may overwrite.
Every original task path is physically stored exactly once, without aliases or
deduplication. The manifest binds every original path/byte count/SHA256 and every
volume's completed bytes/hash. Publication verifies every original and every CRC.

All task Sources, declarations, acquired tables, raw search/circuit data,
certificates, retained UNKNOWN results, Wang failed attempt/recovery, indexed
FILTER follow-up, logs, reviews and viewer assets at the archive cut are kept.
Publication Python Sources are physically included. Generated package outputs
and publication planning/deployment receipts are excluded to avoid recursion.
Deployment receipts created after this cut remain local custody evidence. Full task archive
and local paths are explicitly approved for the existing public destination.

Serve the extracted directory with python3 -m http.server and open
report/family-transfer-v1.html. Scientific code is inert data for the reader.
These are finite RF profile/height proofs and separate tiny literal fixed-palette
circuits. Bounded absence is not unrestricted nonprovability. Retained resource
refusals do not become negative proofs. A follow-up on the same admitted inputs
is not a new held-out cohort. No ATP/RL superiority, complete PA/Hilbert geometry,
practical universal Wang search or plane tiling is established. Program ACTIVE.
