"""Passive combined family/native-proof and literal-Wang report materializer.

Reader graph/CSS helpers adapted from proof-frontier report Source
31962 bytes / 9aaed8fd4a9cdb82f98cba0c047201c2d3fbf9632dffea4b4271fb5e18150ec9.
No scientific module import; no checker, circuit evaluator or search runs here.
"""
import gzip
import hashlib
import html
import json
from pathlib import Path
import re
import sys

STYLE = r'''
:root{color-scheme:light;--ink:#172334;--muted:#526477;--line:#d9e1e8;--blue:#176ca4;--purple:#774caf;--paper:#f5f7fa}*{box-sizing:border-box}body{margin:0;background:var(--paper);color:var(--ink);font:16px/1.55 system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}a{color:#145f96}header,main,footer{max-width:1260px;margin:auto;padding:25px}header{padding-top:52px}h1{font:600 clamp(2rem,4vw,3rem)/1.12 Georgia,serif;max-width:950px;letter-spacing:-.025em;margin:12px 0 20px}h2{font:600 1.6rem/1.2 Georgia,serif;margin:0 0 15px}h3{font-size:1.03rem}.eyebrow{letter-spacing:.13em;text-transform:uppercase;color:var(--blue);font-size:.75rem;font-weight:750}.lede{font-size:1.12rem;max-width:950px}.muted,.note{color:var(--muted)}.note{font-size:.88rem}.card{background:white;border:1px solid var(--line);border-radius:14px;padding:23px;margin-bottom:22px}.scope{border-left:5px solid var(--purple)}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:16px}.stat{font-size:1.35rem;font-weight:750}.badge{display:inline-block;font:650 .74rem/1.5 ui-monospace,monospace;border:1px solid var(--line);border-radius:5px;padding:2px 7px;background:#eff3f7;white-space:nowrap}.good{background:#e7f4ed;color:#205c3b}.bad{background:#f8eded;color:#963e3e}.unknown{background:#fff3d9;color:#785819}.toolbar{display:flex;gap:12px;flex-wrap:wrap;align-items:end;margin:18px 0}label{display:flex;flex-direction:column;gap:6px;font-size:.85rem;font-weight:650}select,button{font:inherit;padding:9px 11px;border:1px solid #b8c7d4;border-radius:7px;background:white;color:var(--ink);max-width:100%}select{min-width:200px}button{cursor:pointer}button:hover{background:#edf5fa}.scroll{overflow:auto;max-width:100%}.bounded{max-height:480px}table{border-collapse:collapse;width:100%;font-size:.86rem}th,td{padding:10px 11px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top}th{background:#f4f7fa;position:sticky;top:0;z-index:1;font-size:.77rem}code,pre{font:12px/1.5 ui-monospace,SFMono-Regular,Consolas,monospace}code{overflow-wrap:anywhere}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#f2f5f8;border-radius:8px;padding:13px;max-height:420px;overflow:auto}.graph{overflow:auto;max-height:660px;border:1px solid var(--line);border-radius:9px;background:linear-gradient(90deg,#f5faff,#fff)}.graph svg{display:block;min-width:1050px;width:100%}.graph .edge{stroke:#96adc1;opacity:.55;fill:none;stroke-width:1.2}.graph .edge-label{font:10px ui-monospace,monospace;fill:#526477}.graph .point circle{fill:#eaf5fc;stroke:#207daf;stroke-width:2}.graph .candidate rect{fill:#f5f7fa;stroke:#8393a2;stroke-width:1.3}.graph text{fill:var(--ink);font:12px ui-monospace,monospace}.graph .small{font-size:10px;fill:#526477}.graph .dim{opacity:.12}.graph g.candidate{cursor:pointer}.graph g.candidate:hover rect,.graph g.candidate:focus rect{stroke:var(--purple);stroke-width:3}.chip{display:inline-flex;gap:7px;align-items:center;border:1px solid var(--line);padding:5px 9px;border-radius:7px;margin:4px;font-size:.8rem}.swatch{width:12px;height:12px;border-radius:3px;display:inline-block;flex-shrink:0}.formula{min-width:250px}.proof tr:hover{background:#f4f9fd}.links{display:flex;flex-wrap:wrap;gap:15px}.split{display:grid;grid-template-columns:1fr 1fr;gap:18px}.error{border-left:5px solid #b14545;background:#fff4f4;padding:14px}.math-legend{margin:12px 0}details{margin:14px 0}summary{cursor:pointer;font-weight:650}.empty{padding:22px;color:var(--muted)}footer{font-size:.85rem;color:var(--muted);padding-bottom:45px}@media(max-width:760px){header,main,footer{padding:18px}.card{padding:16px}.split{grid-template-columns:1fr}header{padding-top:30px}select{min-width:0;width:100%}label{width:100%}th,td{padding:8px}h1{font-size:2.1rem}}

#wang-grid{overflow:auto}#wang-grid svg{min-width:600px;max-width:1100px;width:100%;display:block}.wang-cell{cursor:pointer}.wang-cell:focus{outline:3px solid #774caf}.profile-tabs{margin-bottom:12px}[hidden]{display:none!important}
'''

SCRIPT = r'''
const $=id=>document.getElementById(id), esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const absent=x=>x===null||x===undefined, show=x=>absent(x)?'Unavailable':typeof x==='object'?JSON.stringify(x):String(x);
const badge=x=>{let s=show(x),c=/^(VERIFIED|PASS|SAT|COMPLETE)/.test(s)?'good':/^(REJECTED|FAIL|UNSAT)/.test(s)?'bad':/UNKNOWN|INCOMPLETE|UNAVAILABLE/i.test(s)?'unknown':'';return `<span class="badge ${c}">${esc(s)}</span>`};
let data,rows=[],current,trace,state,checkpoints=[],loadToken=0;
function typeset(node=document){if(window.MathJax?.typesetPromise)window.MathJax.typesetPromise([node]).catch(()=>{});}
function color(value){let h=2166136261;for(let c of String(value))h=Math.imul(h^c.charCodeAt(0),16777619);return `hsl(${(h>>>0)%360} 57% 43%)`;}
function table(headers,body){return `<div class="scroll"><table><thead><tr>${headers.map(h=>`<th>${esc(h)}</th>`).join('')}</tr></thead><tbody>${body.join('')}</tbody></table></div>`;}
function pairs(value){if(absent(value))return '<p class="note">Unavailable.</p>';if(typeof value!=='object')return `<p>${esc(show(value))}</p>`;return table(['Recorded field','Recorded value'],Object.entries(value).map(([k,v])=>`<tr><td><code>${esc(k)}</code></td><td>${typeof v==='object'?`<pre>${esc(JSON.stringify(v,null,2))}</pre>`:esc(show(v))}</td></tr>`));}
function markMath(value){try{return astLatex(JSON.parse(value));}catch{return null;}}
function short(x,n=42){x=String(x);return x.length>n?x.slice(0,n-1)+'…':x;}
function pointLabel(p){return p===''?'root (empty ID)':String(p);}
function cidLabel(id){try{let a=JSON.parse(id);if(Array.isArray(a)&&typeof a[0]==='string'){let d=a[1];if(typeof d==='string')d=JSON.parse(d);let role=Array.isArray(d)?String(d[0]).toUpperCase():'CID';return {label:(a[0]===''?'root':a[0])+' · '+role,role};}}catch{}return {label:short(id),role:'CID'};}
function renderCheckpointBase(index){let cp=checkpoints[index];if(!cp)return;state=cp.state;if(!state){$('graph').innerHTML='<p class="empty">This observation has no retained state.</p>';return;}$('event-data').textContent=JSON.stringify(cp.event??{source:cp.source},null,2);
 const totals=new Map(state.totals||[]),gens=new Map(state.Q||[]),marks=new Map((state.marks||[]).map(r=>[r[0],r])),cap=trace.model?.capacity??trace.result?.certificate?.capacity;
 const allValues=[...new Set((state.marks||[]).map(r=>r[1]))].sort();$('legend').innerHTML=allValues.length?allValues.map(v=>{let m=markMath(v);return `<span class="chip"><span class="swatch" style="background:${color(v)}"></span><code title="${esc(v)}">${esc(short(v,55))}</code>${m?`<span>\\(${esc(m)}\\)</span>`:''}</span>`;}).join(''):'<span class="note">No assigned markings in this checkpoint. Missing remains unconstrained.</span>';
 $('points').innerHTML=table(['Required point ID','Generation','Recorded total units','Capacity','Frontier / assigned mark'],(state.Q||[]).map(([p,g])=>`<tr><td><code>${esc(pointLabel(p))}</code></td><td>${esc(g)}</td><td>${totals.has(p)?esc(totals.get(p)):'Unavailable'}</td><td>${esc(show(cap))}</td><td>${(state.domains||[]).some(r=>r[0]===p)?'Frontier':'Full / inactive frontier'}${marks.has(p)?'<br><code>'+esc(marks.get(p)[1])+'</code>':'<br><span class="note">No assigned mark</span>'}</td></tr>`));
 $('marks').innerHTML=table(['Mark point ID','Literal assigned value','Reference count','Domain'],(state.marks||[]).map(([p,v,n])=>`<tr><td><code>${esc(p===''?'root (empty ID)':p)}</code></td><td><span class="swatch" style="background:${color(v)}"></span> <code>${esc(v)}</code></td><td>${esc(n)}</td><td>${gens.has(p)?'Required point':'Mark-only point'}</td></tr>`));
 $('incidence').innerHTML=table(['Frontier point','Shared candidate ID','Exact contribution units'],(state.forward||[]).map(([p,c,u])=>`<tr><td><code>${esc(pointLabel(p))}</code></td><td><code>${esc(c)}</code></td><td>${esc(u)}</td></tr>`));
 $('state-extra').textContent=JSON.stringify({selected:state.selected,excluded:state.excluded,eligible:state.eligible,loaded:state.loaded,dependencies:state.dependencies,reverse:state.reverse,edge_count:state.edge_count},null,2);
 drawGraph(state,totals,gens,marks,cap);typeset($('legend'));}
function drawGraph(s,totals,gens,marks,cap){let domains=s.domains||[],ids=[...new Set(domains.flatMap(r=>r[1]))].sort(),pindex=new Map(domains.map((r,i)=>[r[0],i])),cindex=new Map(ids.map((c,i)=>[c,i])),rowHeight=43,height=65+Math.max(domains.length,ids.length,1)*rowHeight;
 if(!domains.length){$('graph').innerHTML='<div class="empty">The saved frontier is empty. The result and independent assurance determine what this checkpoint certifies.</div>';$('candidate').textContent='No candidate node in this frontier.';return;}
 let parts=[`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1120 ${height}" role="img" aria-label="Recorded whole frontier point and shared candidate graph"><text x="28" y="24">FRONTIER POINTS</text><text x="660" y="24">SHARED CANDIDATE IDENTITIES</text>`];
 for(let [p,c,u] of s.forward||[]){if(!pindex.has(p)||!cindex.has(c))continue;let i=pindex.get(p),j=cindex.get(c),y=55+i*rowHeight,z=55+j*rowHeight;parts.push(`<path class="edge" data-p="${i}" data-c="${j}" d="M 294 ${y} C 455 ${y},505 ${z},650 ${z}"/><text class="edge-label" data-p="${i}" data-c="${j}" x="${440+(i%3)*37}" y="${(y+z)/2-3}">${esc(u)}</text>`);}
 domains.forEach(([p,domain],i)=>{let y=55+i*rowHeight,m=marks.get(p);parts.push(`<g class="point" data-p="${i}"><title>${esc(JSON.stringify({point:p,generation:gens.get(p),total:totals.get(p),capacity:cap,domain,mark:m}))}</title><circle cx="284" cy="${y}" r="9"${m?` style="stroke:${color(m[1])}"`:''}/><text x="16" y="${y-3}">${esc(short(pointLabel(p),36))}</text><text class="small" x="16" y="${y+12}">units:${esc(show(totals.get(p)))} capacity:${esc(show(cap))} gen:${esc(show(gens.get(p)))} degree:${domain.length}</text></g>`);});
 ids.forEach((c,j)=>{let y=55+j*rowHeight,label=cidLabel(c);parts.push(`<g class="candidate" data-c="${j}" tabindex="0" role="button" aria-label="Inspect candidate ${esc(c)}"><title>${esc(c)}</title><rect x="650" y="${y-17}" width="452" height="34" rx="6"/><text x="662" y="${y-2}">${esc(short(label.label,58))}</text><text class="small" x="662" y="${y+11}">${esc(short(c,68))}</text></g>`);});parts.push('</svg>');$('graph').innerHTML=parts.join('');
 let highlight=(type,index)=>{$('graph').querySelectorAll('.edge,.edge-label,.point,.candidate').forEach(n=>{let hit=type==='p'?n.dataset.p===index:n.dataset.c===index;if(n.classList.contains('point')&&type==='c')hit=(s.forward||[]).some(([p,c])=>cindex.get(c)===Number(index)&&pindex.get(p)===Number(n.dataset.p));if(n.classList.contains('candidate')&&type==='p')hit=(domains[Number(index)]?.[1]||[]).includes(ids[Number(n.dataset.c)]);n.classList.toggle('dim',!hit);});};
 $('graph').querySelectorAll('g.point,g.candidate').forEach(n=>{let type=n.classList.contains('point')?'p':'c',idx=n.dataset[type];n.addEventListener('mouseenter',()=>highlight(type,idx));n.addEventListener('mouseleave',()=>{$('graph').querySelectorAll('.dim').forEach(k=>k.classList.remove('dim'));});if(type==='c'){let inspect=()=>{$('candidate').textContent=JSON.stringify((s.placements||[]).find(r=>r.id===ids[Number(idx)])??{id:ids[Number(idx)],record:'No registered row retained'},null,2);};n.addEventListener('click',inspect);n.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' ')inspect();});}});$('candidate').textContent='Select a candidate card to inspect its exact positive support and literal markings.';
}
function category(r){return r.kind==='WANG'?'Wang':String(r.case_id||r.id).includes('arithmetic')?'Arithmetic':String(r.case_id||r.id).includes('incidence')?'Incidence':'Other';}
function mathRow(p){return `<span>\\(${esc(p?.formula_latex??'\\text{Unavailable}')}\\)</span>`;}
function astLatex(n){if(!Array.isArray(n))return null;let t=n[0],legend=current?.theory_reader?.symbol_legend||[],name=x=>legend.find(r=>r.native===x)?.display??x,tx=x=>String(name(x)).replace(/([_{}%&#$])/g,'\\$1'),r=astLatex;if(t==='var')return tx(n[1]);if(t==='fun'||t==='pred'){let a=(n[2]||[]).map(r);return a.some(x=>x===null)?null:`\\operatorname{${tx(n[1])}}${a.length?'('+a.join(',')+')':''}`;}if(['eq','imp','and','or'].includes(t)){let a=r(n[1]),b=r(n[2]);return a===null||b===null?null:'('+a+({eq:'=',imp:'\\to ',and:'\\land ',or:'\\lor '}[t])+b+')';}if(t==='all'){let a=r(n[2]);return a===null?null:'\\forall '+tx(n[1])+'.\\,'+a;}if(t==='not'){let a=r(n[1]);return a===null?null:'\\neg '+a;}return t==='bot'?'\\bot':null;}
function renderOverview(){
 $('status').innerHTML=badge(data.status);$('coverage').innerHTML=pairs(data.coverage);$('costs').innerHTML=pairs(data.costs);$('limitations').innerHTML=Array.isArray(data.limitations)?'<ul>'+data.limitations.map(x=>`<li>${esc(show(x))}</li>`).join('')+'</ul>':pairs(data.limitations);
 $('outcomes').innerHTML=['Arithmetic','Incidence','Wang','Other'].map(group=>{let selected=rows.map((r,i)=>({r,i})).filter(x=>category(x.r)===group);if(!selected.length)return '';return `<h3>${esc(group==='Incidence'?'Symbolic incidence':group)}</h3>`+table(['Case / method','Recorded outcome','Whole graph','Native / tile decoder','Search / setup / pipeline'],selected.map(({r,i})=>`<tr><td><button data-case="${i}">${esc(r.id)}</button><br><code>${esc(r.mode||r.kind||'')}</code></td><td>${badge(r.display?.result_status)}</td><td>${r.kind==='DP'?'<span class="note">Memoized control; no graph claim</span>':badge(r.display?.graph_status)}</td><td>${badge(r.kind==='WANG'?r.display?.decode_status:r.display?.native_status)}</td><td><code>${esc(show(r.search_seconds))} / ${esc(show(r.display?.setup_seconds))} / ${esc(show(r.pipeline_seconds??r.pipeline_seconds_before_record))}</code></td></tr>`));}).join('');
 document.querySelectorAll('[data-case]').forEach(b=>b.addEventListener('click',()=>{$('profile').value=category(rows[Number(b.dataset.case)]);populateCases();$('case').value=b.dataset.case;loadCase(Number(b.dataset.case));$('reader').scrollIntoView({behavior:'smooth'});}));
 $('preparations').innerHTML=table(['Preparation','Status','Complete pinned input'],(data.preparations||[]).map(p=>`<tr><td>${esc(p.id??p.path??'prepared input')}</td><td>${badge(p.status)}</td><td>${p.download?`<a href="${esc(p.download)}" download>Prepared archive</a>`:p.prepared_download?`<a href="${esc(p.prepared_download)}" download>Prepared archive</a>`:'See evidence index'}</td></tr>`));
}
function populateCases(){let filter=$('profile').value;$('case').innerHTML=rows.map((r,i)=>({r,i})).filter(x=>filter==='All'||category(x.r)===filter).map(({r,i})=>`<option value="${i}">${esc(r.id+(r.mode?' · '+r.mode:''))}</option>`).join('');}
async function loadCase(index){let token=++loadToken;current=rows[index];$('reader-status').innerHTML='<p class="note">Loading the selected recorded trace…</p>';try{let response=await fetch(current.reader_trace);if(!response.ok)throw Error('Trace HTTP '+response.status);let bytes=new Uint8Array(await response.arrayBuffer()),text;if(bytes.length>=2&&bytes[0]===0x1f&&bytes[1]===0x8b){if(typeof DecompressionStream==='undefined')throw Error('This browser cannot decompress the reader gzip; exact archives remain available');text=await new Response(new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'))).text();}else text=new TextDecoder().decode(bytes);let payload=JSON.parse(text);if(token!==loadToken)return;trace=payload;
 let scope=current.kind==='WANG'?'Literal100-type Wang circuit search, translation only; every cell offers all100 types.':current.kind==='DP'?'Conventional memoized finite grammar control. No point graph is claimed for this run.':'Anchored finite symbolic point proof search, separate from the fixed Wang grid.';
 $('case-meta').innerHTML=`<div class="grid"><div><strong>${esc(current.id)}</strong><p>${badge(current.display?.result_status)} ${badge(current.kind==='WANG'?current.display?.decode_status:current.display?.native_status)}</p></div><div><strong>${esc(category(current))}</strong><p class="note">${esc(scope)}</p></div></div>`;
 $('downloads').innerHTML=`<a href="${esc(current.reader_trace)}" download>Compressed reader JSON (.gz)</a><a href="${esc(current.raw_download)}" download>Exact raw archive</a>${current.prepared_download?`<a href="${esc(current.prepared_download)}" download>Complete prepared input / universe</a>`:''}<a href="family-transfer-results-v1.json" download>Summary</a>`;
 $('raw-pin').textContent=JSON.stringify({raw:current.raw,raw_copy_pin:current.public_raw_pin,projection:trace.reader_projection,reader_trace_compressed_pin:current.reader_trace_pin,reader_trace_uncompressed_pin:current.reader_trace_uncompressed_pin,complete_universe:current.universe_ref},null,2);
 checkpoints=(trace.observations||[]).map((o,i)=>({state:o.state,event:o.event,label:`${i} · ${o.event?.kind||'recorded event'}${o.event?.point!==null&&o.event?.point!==undefined?' · '+pointLabel(o.event.point):''}`}));for(let [key,label] of [['entry_state','Saved entry checkpoint'],['final_state','Saved final checkpoint'],['restored_state','Saved restored checkpoint']])if(trace.result?.[key])checkpoints.push({state:trace.result[key],event:null,label,source:key});
 $('event').innerHTML=checkpoints.map((o,i)=>`<option value="${i}">${esc(o.label)}</option>`).join('');$('event').disabled=!checkpoints.length;$('previous').disabled=!checkpoints.length;$('next').disabled=!checkpoints.length;
 $('reader-status').innerHTML=`<p class="note">${current.kind==='DP'?'No point-event stream is produced by this memoized control.':checkpoints.length+' retained event/checkpoint views. Entire domain/weight/mark/generation tables are displayed.'} Reader traces are gzip-compressed; their byte/hash pins describe the compressed download, with the uncompressed pin recorded separately. The projection omits duplicate inventory bodies and registered row bodies outside the current frontier/selected set; exact raw records and the complete prepared universe remain downloadable.</p>`;
 $('stream').innerHTML=pairs({event_extent:trace.result?.event_extent,rollback_extent:trace.result?.rollback_extent,journal:trace.journal,provider_evidence:trace.result?.provider_evidence?{mode:trace.result.provider_evidence.mode,total:trace.result.provider_evidence.total,retained:trace.result.provider_evidence.retained,sha256:trace.result.provider_evidence.sha256,scope:trace.result.provider_evidence.scope}:null});
 $('wang-panel').hidden=current.kind!=='WANG';renderProof();if(checkpoints.length){let initial=0;if(current.kind==='WANG'){let final=checkpoints.findIndex(c=>c.source==='final_state');initial=final>=0?final:Math.max(0,(trace.observations||[]).length-1);}$('event').value=initial;renderCheckpoint(initial);}else{state=null;$('graph').innerHTML='<div class="empty">'+(current.kind==='DP'?'Memoized control: no point-frontier graph.':'No complete checkpoint retained.')+'</div>';for(let id of ['incidence','points','marks','legend'])$(id).innerHTML='';for(let id of ['event-data','candidate','state-extra'])$(id).textContent='Unavailable';if(current.kind==='WANG')renderWang(null);}typeset($('reader'));
 }catch(e){$('reader-status').innerHTML=`<div class="error">${esc(e.message)}. No sample data have been substituted.</div>`;}}
function renderProof(){let theory=current.theory_reader;if(theory){$('theory').innerHTML=`<p class="note">${esc(show(theory.scope))}</p>`+table(['Declared hypothesis','Formula','English'],(theory.hypotheses||[]).map(p=>`<tr><td><code>${esc(p.name)}</code></td><td class="formula">${mathRow(p)}</td><td>${esc(show(p.english))}</td></tr>`))+(theory.conclusion?`<h3>Target statement</h3><p>${mathRow(theory.conclusion)}</p><p>${esc(show(theory.conclusion.english))}</p>`:'')+`<p class="note">${esc(show(theory.interpretation))}</p><details><summary>Literal-to-display symbol legend</summary>${pairs(theory.symbol_legend)}</details>`;}else $('theory').innerHTML=current.kind==='WANG'?'<p class="note">This case is a Boolean circuit qualification, not an arithmetic or incidence theorem.</p>':'<p class="note">No theory reader was supplied.</p>';
 let proof=current.proof_reader;if(!Array.isArray(proof)||!proof.length){$('proof').innerHTML='<p class="note">No checked native derivation is supplied for this recorded result.</p>';return;}$('proof').innerHTML=table(['Line','Formula in display aliases','English reading','Rule, dependencies and justification'],proof.map(p=>`<tr><td>${esc(show(p.line))}</td><td class="formula">${mathRow(p)}</td><td>${esc(show(p.english))}</td><td><code>${esc(show(p.rule))}</code><br><span class="note">${esc(show(p.dependencies))}</span><br>${esc(show(p.reason))}</td></tr>`));typeset($('theory'));typeset($('proof'));}
function renderCheckpoint(index){renderCheckpointBase(index);if(current.kind==='WANG')renderWang(state);}
function renderWang(saved){$('wang-tile-info').textContent='Select an actual tile in this saved state.';let fixture=current.fixture||trace.fixture,palette=current.wang_palette||data.wang_palette,tiles=palette?.tiles;if(!fixture||!Array.isArray(tiles)){$('wang-grid').innerHTML='<p class="note">A pinned fixture/palette is unavailable; no tiles have been invented.</p>';return;}let selected=new Map();for(let [cid,generation] of saved?.selected||[]){let m=/^(\d{4}):(\d{4}):(\d{2})$/.exec(cid);if(m)selected.set(Number(m[2])+','+Number(m[1]),{id:Number(m[3]),cid,generation});}
 let width=fixture.width,height=fixture.height,size=108,pad=28,opColor={CROSS:'#8396a5',READ:'#2989a6',NAND:'#dc9a35',NOT:'#b65e7d',WRITE:'#6977b5'},bitColor=['#263b56','#f0cf65'],parts=[`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${width*size+2*pad} ${height*size+2*pad}" role="img" aria-label="Actual selected fixed-orientation Wang tile grid">`];
 for(let y=0;y<height;y++)for(let x=0;x<width;x++){let X=pad+x*size,Y=pad+y*size,a=selected.get(x+','+y),t=a?tiles.find(t=>t.id===a.id):null;if(!t){parts.push(`<g><rect x="${X}" y="${Y}" width="100" height="100" rx="3" fill="#f5f7fa" stroke="#b8c6d1" stroke-dasharray="4 4"/><text x="${X+10}" y="${Y+47}" font-size="11" fill="#63778a">unselected</text><text x="${X+10}" y="${Y+64}" font-size="10" fill="#63778a">cell ${x},${y}</text></g>`);continue;}
 parts.push(`<g class="wang-cell" tabindex="0" role="button" data-cell="${x},${y}"><title>${esc(JSON.stringify({cell:[x,y],selected:a,tile:t}))}</title><rect x="${X}" y="${Y}" width="100" height="100" fill="white" stroke="#8ca2b3"/><rect x="${X}" y="${Y}" width="100" height="8" fill="${opColor[t.N[0]]}"/><rect x="${X}" y="${Y+8}" width="100" height="6" fill="${bitColor[t.N[1]]}"/><rect x="${X}" y="${Y+92}" width="100" height="8" fill="${opColor[t.S[0]]}"/><rect x="${X}" y="${Y+86}" width="100" height="6" fill="${bitColor[t.S[1]]}"/><rect x="${X}" y="${Y+14}" width="8" height="72" fill="${bitColor[t.W]}"/><rect x="${X+92}" y="${Y+14}" width="8" height="72" fill="${bitColor[t.E]}"/><text x="${X+17}" y="${Y+33}" font-size="11" fill="#263b56">${esc(t.N[0])}</text><text x="${X+17}" y="${Y+49}" font-size="12" fill="#263b56">type ${t.id}</text><circle cx="${X+50}" cy="${Y+62}" r="4" fill="#176ca4"/><text x="${X+17}" y="${Y+80}" font-size="10" fill="#526477">center unit1</text></g>`);}
 parts.push('</svg>');$('wang-grid').innerHTML=parts.join('');$('wang-caption').textContent=`${selected.size} actual selected cells of ${width*height}; ${fixture.label||fixture.id}. ${current.display?.result_status==='SAT'?'Inspect event-by-event selection and its checked final assignment.':'This is a retained partial state, not a fabricated successful tiling.'}`;
 $('wang-legend').innerHTML=Object.entries(opColor).map(([op,c])=>`<span class="chip"><span class="swatch" style="background:${c}"></span>${op}</span>`).join('')+bitColor.map((c,b)=>`<span class="chip"><span class="swatch" style="background:${c}"></span>bit ${b}</span>`).join('');
 $('wang-grid').querySelectorAll('[data-cell]').forEach(n=>{let inspect=()=>{let a=selected.get(n.dataset.cell),t=tiles.find(t=>t.id===a.id);$('wang-tile-info').textContent=JSON.stringify({cell:n.dataset.cell,selected:a,N:t.N,S:t.S,W:t.W,E:t.E},null,2);};n.addEventListener('click',inspect);n.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' ')inspect();});});$('wang-decoder').innerHTML=pairs(current.decode_result);}
async function init(){try{let response=await fetch('family-transfer-results-v1.json');if(!response.ok)throw Error('Summary HTTP '+response.status);data=await response.json();rows=[...(data.families||[]),...(data.wang||[])];renderOverview();populateCases();$('profile').addEventListener('change',()=>{populateCases();if($('case').value!=='')loadCase(Number($('case').value));});$('case').addEventListener('change',()=>loadCase(Number($('case').value)));$('event').addEventListener('change',()=>renderCheckpoint(Number($('event').value)));$('previous').addEventListener('click',()=>{let i=Math.max(0,Number($('event').value)-1);$('event').value=i;renderCheckpoint(i);});$('next').addEventListener('click',()=>{let i=Math.min(checkpoints.length-1,Number($('event').value)+1);$('event').value=i;renderCheckpoint(i);});if(rows.length){let initial=rows.findIndex(r=>category(r)==='Arithmetic'&&r.mode==='MARKS'&&r.display?.result_status==='SAT');if(initial<0)initial=rows.findIndex(r=>category(r)==='Arithmetic'&&r.display?.result_status==='SAT');if(initial<0)initial=0;$('profile').value=category(rows[initial]);populateCases();$('case').value=String(initial);await loadCase(initial);}else $('reader-status').innerHTML='<p>No completed records supplied.</p>';typeset();}catch(e){$('status').innerHTML=`<div class="error">${esc(e.message)}. No demonstration results have been substituted.</div>`;}}
init();
'''


MAIN = r'''
<header><div class="eyebrow">GCTS · Fresh finite families and a literal palette bridge</div><h1>Proof families, inspected from the frontier</h1><p class="lede">Read actual arithmetic derivations and bounded symbolic incidence searches, inspect their exact point-frontier traces, and examine a separate tiny fixed-palette Wang search qualification.</p><div id="status">Loading recorded status…</div><div class="links"><a href="family-transfer-evidence-v1.html">Evidence and downloads</a><a href="frontier-audit-v1.html">Previous frontier audit</a><a href="failure-markings-v1.html">Failure markings</a><a href="#reader">Open a reader</a></div><p><!-- TRANSFER_ARCHIVE_LINK --></p></header>
<main><section class="card"><h2>Findings in this run</h2><p>This run demonstrates automated bounded proof discovery without a supplied derivation. Its positive arithmetic examples are one addition-zero corollary under two literal symbol renamings, not two independent new theorems. Certified failure pruning works within the declared finite grammar, but the matched ordinary indexed filter reproduces the arithmetic proof and event outputs. These results establish no distinctive GCTS advantage and no new RL contribution.</p><p>Arithmetic at \(H=4\) yielded checked proofs with __ARITHMETIC_POINT_PROOF_LINES__ lines from both literal markings and the matched indexed-filter control; their proofs and event streams matched for each literal renaming. The memoized control found proofs with __ARITHMETIC_DP_PROOF_LINES__ lines. These line counts are derived from the saved proof-reader rows and checked when the report is built. At \(H=3\), the matched indexed-filter control exhausted the declared finite grammar. These arithmetic statements use addition-zero and congruence, without induction.</p><p>The matched indexed filter reproduces the apparent marking advantage over the earlier explicit filtered inventory. This comparison therefore does not isolate a gain from representing failures as markings: incident-enumeration format matters. The cost and outcome tables retain those controls separately.</p><p>No symbolic incidence target was proved at either bound: the matched indexed-filter control exhausted \(H=3\), while \(H=4\) remained unknown under the declared limits. The separate fixed100-type Wang qualification has two found tilings, one exhausted impossible acceptance condition, and one work-limited unknown. It does not discover these arithmetic or incidence proofs on the Wang palette.</p></section><section class="card scope"><h2>Separate questions, separate checks</h2><p>The family lane searches an anchored symbolic point model, with native logical validity checked separately. Arithmetic uses addition-zero and congruence, without induction or full PA. Geometry uses a purely symbolic one-sorted incidence fragment, without coordinates or full Hilbert geometry. Human names and English are display legends.</p><p>The Wang lane searches primitive square cells using one fixed100-type palette, by translation only, on fresh tiny Boolean programs. Its free input bits are not supplied as a witness. Operation selectors are problem pins on every vertical edge, including the interior. This qualification is separate from searching mathematical proofs on that palette.</p><p class="note">No newly trained RL, ATP superiority, unrestricted first-order completeness or universal practical Wang proof search is claimed. A finite profile failure and a resource refusal have different meanings. Complete proof-set enumeration has not been attempted for the richer family profiles; any preservation claim must carry its stated certificate argument.</p></section>
<section class="card"><h2>Recorded outcomes and method costs</h2><div id="outcomes"></div><p class="note">Seconds are displayed as search / setup / recorded pipeline. An unavailable quantity is not replaced by zero. Memoized controls have no point-graph claim.</p></section>
<section id="reader" class="card"><h2>Proof and trace reader</h2><div class="toolbar"><label>Profile<select id="profile"><option>All</option><option>Arithmetic</option><option>Incidence</option><option>Wang</option><option>Other</option></select></label><label>Recorded run<select id="case"></select></label><label>Actual event / saved checkpoint<select id="event"></select></label><button id="previous">Previous</button><button id="next">Next</button></div><div id="case-meta"></div><div id="reader-status"></div><div id="downloads" class="links"></div>
<h3>Hypotheses, target and symbol interpretation</h3><div id="theory"></div><h3>Native proof, line by line</h3><div id="proof" class="proof"></div>
<section id="wang-panel" hidden><h3>Actual selected Wang squares</h3><p id="wang-caption" class="note"></p><p>North and south have separate operation and bit stripes; west and east carry a bit stripe. The full vertical color is \((\mathrm{OP},b)\). Cell centers supply unit occupancy. Empty squares are unselected cells, not invented tiles. Select a square for its literal edge colors.</p><div id="wang-legend"></div><div id="wang-grid"></div><pre id="wang-tile-info">Select an actual tile.</pre><details><summary>Independent selected-tile / Boolean decoder receipt</summary><div id="wang-decoder"></div></details></section>
<h3>Recorded point / candidate graph</h3><p class="note">Circles are frontier points and cards are shared candidate identities; edge labels give exact units. This is a point-graph layout, not a square-tile embedding of the native arithmetic or incidence proof. All current incidences remain in the table and graph.</p><div id="graph" class="graph"></div><div class="split"><div><h3>Actual event</h3><pre id="event-data"></pre></div><div><h3>Exact candidate support</h3><pre id="candidate"></pre></div></div><h3>Assigned-value color legend</h3><div id="legend" class="math-legend"></div><details open><summary>All weighted incidences</summary><div id="incidence" class="bounded scroll"></div></details><details><summary>All required points, including zeros</summary><div id="points" class="bounded scroll"></div></details><details><summary>All markings, including remote assigned zeros</summary><div id="marks" class="bounded scroll"></div></details><details><summary>Inventory, exclusions, dependencies and reverse incidence</summary><pre id="state-extra"></pre></details><details><summary>Event retention, exact raw pins and projection scope</summary><div id="stream"></div><pre id="raw-pin"></pre></details></section>
<section class="card"><h2>Prepared inputs and complete universes</h2><div id="preparations"></div></section><section class="card"><h2>Coverage</h2><div id="coverage"></div></section><section class="card"><h2>Cost ledger</h2><div id="costs"></div><p class="note">Preparation, failure acquisition, search, assurance and recording have separate scopes. Reused observations and lost timers do not establish a measured cold cost.</p></section><section class="card"><h2>Limitations</h2><div id="limitations"></div></section></main><footer>Passive rendering of actual saved records. This reader invokes no search, circuit evaluator, native kernel or graph checker. Projected traces are for inspection; exact raw and complete prepared archives remain available.</footer>
'''


def canonical(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       separators=(',', ':'), allow_nan=False)+'\n').encode('ascii')


def pin(raw):
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def is_ref(value):
    return isinstance(value, dict) and {'path', 'bytes', 'sha256'} <= set(value)


def read_ref(root, reference):
    if not is_ref(reference):
        raise ValueError('Expected pinned {path,bytes,sha256} reference.')
    path = (root/reference['path']).resolve()
    if root != path and root not in path.parents:
        raise ValueError('Reference leaves the declared run root.')
    raw = path.read_bytes()
    if pin(raw) != {key: reference[key] for key in ('bytes', 'sha256')}:
        raise ValueError('Pinned reference bytes differ: '+reference['path'])
    return path, raw


def decode_ref(root, reference):
    path, raw = read_ref(root, reference)
    return json.loads(gzip.decompress(raw) if path.suffix == '.gz' else raw)


def recorded_status(root, value):
    if is_ref(value):
        value = decode_ref(root, value)
    return value.get('status') if isinstance(value, dict) else value if isinstance(value, str) else None


def projected_state(state):
    if not isinstance(state, dict):
        return state
    result = dict(state)
    rows = state.get('placements')
    if isinstance(rows, list):
        needed = {cid for point, ids in state.get('domains', []) for cid in ids}
        needed.update(cid for cid, generation in state.get('selected', []))
        kept = [row for row in rows if row['id'] in needed]
        result['placements'] = kept
        result['reader_omitted_registered_rows'] = len(rows)-len(kept)
    return result


def project(raw):
    result = dict(raw)
    if isinstance(raw.get('model'), dict):
        model = dict(raw['model'])
        if isinstance(model.get('inventory'), dict) and 'placements' in model['inventory']:
            inventory = dict(model['inventory'])
            inventory['reader_omitted_placement_rows'] = len(inventory.pop('placements'))
            model['inventory'] = inventory
        result['model'] = model
    if 'universe' in result:
        result['reader_omitted_universe_rows'] = len(result.pop('universe'))
    if isinstance(raw.get('observations'), list):
        result['observations'] = [dict(observation, state=projected_state(observation.get('state')))
                                  for observation in raw['observations']]
    if isinstance(raw.get('result'), dict):
        native = dict(raw['result'])
        for key in ('entry_state', 'final_state', 'restored_state'):
            if key in native:
                native[key] = projected_state(native[key])
        result['result'] = native
    result['reader_projection'] = dict(schema='Passive-transfer-reader-projection-v1',
        preserved='Every observation/event; all domains, forward/reverse weighted incidence, totals, point/placement generations, marks/refcounts, dependencies, eligible/excluded/loaded sets, selected IDs and result metadata.',
        omitted='Only duplicate complete inventory/universe bodies and registered placement-row bodies whose IDs are neither currently incident to a frontier nor selected. Exact counts are recorded per projected state/model.',
        warning='Projected model/state objects are display data, not valid replacement inputs for a scientific checker. Use pinned exact raw and complete prepared archives.')
    return result


def page(title, body, script=''):
    return ('<!doctype html><html lang="en"><head><meta charset="utf-8">'
        '<meta name="viewport" content="width=device-width, initial-scale=1"><title>'+html.escape(title)+
        '</title><style>'+STYLE+'</style>'+
        r'<script>window.MathJax={tex:{inlineMath:[["\\(","\\)"]],displayMath:[["\\[","\\]"]]},options:{skipHtmlTags:["script","noscript","style","textarea","pre","code"]}};</script>'+
        '<script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js"></script></head><body>'+
        body+('<script>'+script+'</script>' if script else '')+'</body></html>')


def build(root):
    root = root.resolve()
    source = root/'data/report-summary-v1.json'
    source_bytes = source.read_bytes()
    summary = json.loads(source_bytes)
    out = root/'report'
    traces, downloads = out/'transfer-traces-v1', out/'transfer-downloads-v1'
    traces.mkdir(parents=True, exist_ok=True)
    downloads.mkdir(parents=True, exist_ok=True)
    copied, download_index = {}, []

    def public_copy(reference):
        path, raw = read_ref(root, reference)
        key = (reference['bytes'], reference['sha256'])
        if key not in copied:
            basename = re.sub('[^a-zA-Z0-9_.-]', '-', path.name)
            name = reference['sha256'][:16]+'-'+basename
            (downloads/name).write_bytes(raw)
            copied[key] = 'transfer-downloads-v1/'+name
            download_index.append(dict(original=reference['path'], download=copied[key], **pin(raw)))
        return copied[key]

    def prepared_reference(record, raw):
        for value in (record.get('prepared'), record.get('preparedref'), raw.get('prepared_ref'), raw.get('universe_ref')):
            if is_ref(value):
                return value
        return None

    all_records = []
    for group in ('families', 'wang'):
        for index, record in enumerate(summary.get(group, [])):
            path, raw_bytes = read_ref(root, record['raw'])
            raw = json.loads(gzip.decompress(raw_bytes) if path.suffix == '.gz' else raw_bytes)
            if not isinstance(raw, dict) or not isinstance(raw.get('result'), dict):
                raise ValueError('Saved run/result object missing: '+record['id'])
            record.setdefault('kind', 'WANG' if group == 'wang' else raw.get('kind', 'FAMILY'))
            record['raw_download'] = public_copy(record['raw'])
            record['public_raw_pin'] = pin(raw_bytes)
            complete = prepared_reference(record, raw)
            if complete is not None:
                record['prepared_download'] = public_copy(complete)
            if is_ref(raw.get('universe_ref')):
                record['universe_ref'] = dict(raw['universe_ref'], download=public_copy(raw['universe_ref']))
            record['display'] = dict(result_status=raw['result'].get('status'),
                graph_status=recorded_status(root, record.get('graph_check')),
                native_status=recorded_status(root, record.get('native_check')),
                model_status=recorded_status(root, record.get('model_check')),
                decode_status=recorded_status(root, record.get('decode_check')),
                setup_seconds=record.get('setup_seconds'))
            if record['display']['setup_seconds'] is None and isinstance(record.get('setup'), dict):
                record['display']['setup_seconds'] = record['setup'].get('seconds', record['setup'].get('setup_seconds'))
            for key in ('graph_check', 'native_check', 'model_check', 'decode_check'):
                if is_ref(record.get(key)):
                    record[key+'_download'] = public_copy(record[key])
            if record['kind'] == 'WANG':
                record.setdefault('fixture', raw.get('fixture'))
                if is_ref(record.get('decode_check')):
                    record['decode_result'] = decode_ref(root, record['decode_check'])
                if 'wang_palette' in summary:
                    record['wang_palette'] = (decode_ref(root, summary['wang_palette'])
                                              if is_ref(summary['wang_palette']) else summary['wang_palette'])
                elif is_ref(raw.get('universe_ref')):
                    reference = raw['universe_ref']
                    prepared = decode_ref(root, reference)
                    pointer = str(reference.get('pointer', '')).split('/')
                    item = prepared[int(pointer[1])] if isinstance(prepared, list) and len(pointer) > 1 and pointer[1].isdigit() else prepared
                    if isinstance(item, dict) and 'palette' in item:
                        record['wang_palette'] = item['palette']
            for key in ('proof_reader', 'theory_reader'):
                if is_ref(record.get(key)):
                    record[key] = decode_ref(root, record[key])
            view = project(raw)
            key = group+'-%03d-' % index+re.sub('[^a-zA-Z0-9_-]', '-', str(record['id']))[:90]
            view_bytes = canonical(view)
            compressed_view = gzip.compress(view_bytes, compresslevel=6, mtime=0)
            (traces/(key+'.reader.json.gz')).write_bytes(compressed_view)
            record['reader_trace'] = 'transfer-traces-v1/'+key+'.reader.json.gz'
            record['reader_trace_pin'] = pin(compressed_view)
            record['reader_trace_uncompressed_pin'] = pin(view_bytes)
            all_records.append(record)
    for prepared in summary.get('preparations', []):
        reference = prepared if is_ref(prepared) else prepared.get('prepared') if isinstance(prepared, dict) else None
        if is_ref(reference):
            prepared['download'] = public_copy(reference)
    summary['reader_materialization'] = dict(schema='Passive-family-transfer-report-v1', input_summary=pin(source_bytes),
        runs=len(all_records), pinned_downloads=len(download_index),
        trace_encoding='Deterministic gzip (mtime0); reader_trace_pin is compressed bytes; reader_trace_uncompressed_pin binds the decoded canonical JSON.',
        scope='No scientific modules imported or executed. Display projections are explicitly labeled; all graph tables retained; exact raw/prepared data remain downloadable.')
    summary['download_index'] = download_index
    (out/'family-transfer-results-v1.json').write_bytes(canonical(summary))
    arithmetic = [r for r in all_records if 'arithmetic' in str(r.get('case_id', r['id']))]
    point_counts = {len(r['proof_reader']) for r in arithmetic
                    if r.get('mode') in ('MARKS', 'IFILTER') and r['display']['result_status'] == 'SAT'}
    dp_counts = {len(r['proof_reader']) for r in arithmetic
                 if r.get('kind') == 'DP' and r['display']['result_status'] == 'DERIVABLE'}
    if point_counts != {12} or dp_counts != {8}:
        raise ValueError('Saved arithmetic proof counts differ from the admitted assessment: '+
                         repr(dict(point=sorted(point_counts), dp=sorted(dp_counts))))
    main = MAIN.replace('__ARITHMETIC_POINT_PROOF_LINES__', str(next(iter(point_counts))))
    main = main.replace('__ARITHMETIC_DP_PROOF_LINES__', str(next(iter(dp_counts))))
    (out/'family-transfer-v1.html').write_text(page('GCTS fresh proof families and Wang join', main, SCRIPT))
    table_rows = []
    for item in download_index:
        table_rows.append('<tr><td><code>'+html.escape(item['original'])+'</code></td><td><a download href="'+
            html.escape(item['download'], quote=True)+'">Exact saved file</a></td><td>'+str(item['bytes'])+
            '</td><td><code>'+html.escape(item['sha256'])+'</code></td></tr>')
    evidence = ('<header><div class="eyebrow">GCTS · Fresh evidence</div><h1>Proof-family and Wang evidence</h1>'
        '<p class="lede">Pinned exact raw traces, complete prepared universes, native/graph/tile receipts and clearly labeled browser projections.</p>'
        '<div class="links"><a href="family-transfer-v1.html">Open combined reader</a><a download href="family-transfer-results-v1.json">Results and download index</a></div>'
        '<p><!-- TRANSFER_ARCHIVE_LINK --></p></header><main><section class="card scope"><h2>Two models, distinct claims</h2>'
        '<p>Arithmetic/incidence proofs use a finite symbolic anchored point grammar. Literal Wang records use the fixed100-type palette on tiny Boolean circuits. The latter do not claim to discover these mathematical proofs on a Wang grid. Memoized DP controls do not expose the point-frontier graph.</p>'
        '<p>Reader projections preserve every actual event/graph/mark/generation table, but omit registered row bodies outside current domains and selections, plus duplicate full inventories. Reader JSON uses deterministic gzip with separate compressed and uncompressed byte/hash pins. It is not a substitute checker input. Exact raw and complete prepared files below preserve all original data, including symbolic universe pointers.</p>'
        '<p>Resource refusals remain unknown. Preservation arguments for the rich finite profiles are not exhaustive enumeration of all complete proofs. No RL learning, general ATP superiority, full PA/Hilbert or practical universal-palette proof search is claimed.</p></section>'
        '<section class="card"><h2>Exact downloadable files</h2><div class="scroll"><table><thead><tr><th>Original saved path</th><th>Download</th><th>Bytes</th><th>SHA256</th></tr></thead><tbody>'+
        ''.join(table_rows)+'</tbody></table></div></section><section class="card"><h2>Input summary pin</h2><pre>'+
        html.escape(json.dumps(pin(source_bytes), indent=2))+'</pre></section></main><footer>Passive materialization only. No search, circuit evaluation, native proof checking or graph reconstruction occurs in this reader.</footer>')
    (out/'family-transfer-evidence-v1.html').write_text(page('GCTS family transfer evidence', evidence))
    return dict(status='PASSIVE_TRANSFER_REPORT_BUILT', runs=len(all_records), downloads=len(download_index),
                summary_pin=pin((out/'family-transfer-results-v1.json').read_bytes()))


if __name__ == '__main__':
    if len(sys.argv) > 2:
        raise SystemExit('Usage: python3 report/build_transfer_report_v2.py [RUN]')
    root = Path(sys.argv[1]) if len(sys.argv) == 2 else Path(__file__).resolve().parents[1]
    print(json.dumps(build(root)), flush=True)
