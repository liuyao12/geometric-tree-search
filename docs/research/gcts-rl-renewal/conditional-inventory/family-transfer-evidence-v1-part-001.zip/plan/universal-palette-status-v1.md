# Status of the single-palette proof direction

This is a read-only Source assessment, dated 2026-11-03. It adds no experiment, proof discovery, performance result or deployment. Scientific modules were neither imported nor executed. Existing saved JSON receipts were read with the standard library; current Source bytes were hashed. The master contract was read from the audited run's exact noncloud copy, pinned below. Historical review conclusions are attributed to their saved records rather than re-established by this assessment.

The program already has one fixed palette of 100 ordinary, fixed-orientation Wang types and a subsequent raw first-order proof-checker compiler. What remains missing is a demonstrated practical search on that palette for nontrivial mathematical proofs, a fully independent reverse decoder/statement-binding join, and a justified unbounded uniform interface. The recently audited proof-tree point search is a useful search frontend, but is a different tile model.

## What exists

The two intact noncloud source roots are:

- `/Users/liuyao/.codex/visualizations/2026/10/09/01a11e8d-0cf0-7ed2-8930-2aa7f4aab37b/gcts-fixed-palette-20261103-v1` (abbreviated `FP` below).
- `/Users/liuyao/.codex/visualizations/2026/10/09/01a11e8d-0cf0-7ed2-8930-2aa7f4aab37b/gcts-fol-kernel-20261103-v1` (abbreviated `NK`).

`FP/source/fixed_palette_v1.py` defines five operation roles, two north bits, two west bits, and five next-operation selectors. The vertical edge colors are pairs consisting of an operation and a bit; horizontal colors are bits. This gives 100 distinct edge quadruples, 10 typed vertical colors and two horizontal colors. There are no rotations or reflections in the construction. The point realization has unit occupancy at each cell center and marking-only operation/bit ports at shared edges. All 100 types are offered at every required cell; the inventory does not choose a type based on a witness.

The instance pins the operation component on **every vertical edge**, including the default `CROSS` cells and the bottom selectors. Known input bits and future-wire zeros are pinned at the top, the west bus is zero, and one bottom output is one. The program therefore resides partly in interior problem-defining pins. This is an ordinary edge-colored palette with an interior constrained instance; it is not an outer-boundary-only universal Wang system.

`Builder` lowers a circuit to a NAND DAG. The routing compiler uses one row per gate, preserves source columns, writes into a fresh destination, and routes across all intervening `CROSS` cells. With input count \(I\) and gate count \(G\), the explicit rectangle has \(G(I+G)\) cells. Fixing the free top input bits determines the whole row-major tiling before the final output test. Thus the construction's existence equivalence is between an accepting Boolean input assignment and a tiling satisfying the prescribed program pins. NAND completeness supports finite circuit representation; it is not by itself a proof of unrestricted mathematical provability or proof-search effectiveness.

`FP/source/producer_frontend_v1.py` compiles a **whole finite** `ZERO`/`MP`/`GEN` producer table and an exact line bound before encoding a proof witness. It checks valid table selections, strictly earlier active references, premise/output formula-ID incidence, zero unused references and the final goal. Logical admission of the producer table is external. This frontend does not independently interpret arbitrary first-order syntax or prove a `ZERO` formula.

`NK/source/raw_kernel_circuit_v1.py` goes further: raw syntax rows, function/predicate arities, proof records and capture-free substitution maps are circuit data. Its eleven rules are `AXIOM`, `MP`, `GEN`, `UI`, `REFL`, `DIST`, `EQSUB`, `AX1`, `AX2`, `AX3`, and `BOT_FALSE`. It checks all syntax and substitution tasks, including unused ones; strict child/reference bounds; free-variable vectors; closed assumptions; rule incidence; and the final goal. `v2` changes field materialization, and `v3` raises only the NAND construction ceiling. It uses the exact same palette bytes as `FP`.

`NK/source/kernel_data_v1.py` has `build_problem`, `build_witness` and `encode_bits`. `build_problem` freezes all signature arities, assumption IDs, the goal ID, and every field of their complete recursive syntax closure. Later syntax, proof-line fields and substitution words remain free. Axiom padding repeats an existing assumption; it does not introduce a new assumption. The witness encoder supplies a previously obtained derivation. There is no separately implemented inverse `decode_bits` or tile-to-raw-certificate-to-human-statement decoder in this source pipeline. The independent raw checker accepts a supplied raw certificate, and the encoder ties its fields to circuit inputs; that is a narrower direction of checking.

The primitive syntax uses implication, negation, universal quantification, equality, functions, predicates and bottom. Human conjunction and disjunction are desugared as

\[
A\land B:=\neg(A\to\neg B),\qquad A\lor B:=(\neg A)\to B.
\]

The conventional existential abbreviation is \(\exists x A:=\neg\forall x\neg A\), but there is no direct existential human-AST handler. Equality is genuine logical equality, not merely an uninterpreted predicate. The calculus is classical first-order logic over standard nonempty domains, from the supplied **closed** assumption set \(\Gamma\). Soundness means \(\Gamma\vdash\varphi\Longrightarrow\Gamma\models\varphi\); it does not validate \(\Gamma\) as PA, Hilbert geometry, or a foundational theory.

## Existing qualification and its scope

The fixed-palette admission record reports a searched five-cell free-input NAND patch and an exhausted fixed-input companion. The large arithmetic and symbolic-incidence examples were automatically found in a finite semantic producer-tree model, decoded to seven-line derivations, then supplied to the circuit/palette backend. They were not found by searching their expanded Wang rectangles. The independent ribbon checker validates the exact 100-type table, the 20 `CROSS` transport cases, every active tile, bus continuity, exact complementary ribbon intervals, operation tags and acceptance boundary. Its compressed certificates imply exact finite expansions; they do not exhibit all primitive search decisions.

Saved fixed-palette qualification contains 1,024 assignments across four tiny producer-circuit truth tables, 24 tiny counter-state assignments, and eight corruptions rejected by both ribbon and literal checkers. These counts are not a general compiler-equivalence theorem. Its old per-event graph audit also does not become the new whole-result/packet/exclusion audit merely because the engine Source hash is the same.

The raw-kernel saved qualification has 17 cases: 13 accepted and four rejected, all eleven rule kinds represented in accepted fixtures, plus 13 rejected unlisted-rule mutations. A separate fully pinned tiny syntax problem exhausted 1,024 free proof assignments for eager/lazy Boolean equivalence. Only the tiny reflexivity certificate was literally expanded and checked, covering 14,645 cells; the other positive qualification ribbons were symbolic and their literal resource refusals remain `UNKNOWN`.

The admitted research witnesses are the two reused seven-line proofs. The incidence compiler produced 573,693 NAND gates; the PA compiler required the separate two-million ceiling and produced 1,344,049 gates. Their nominal grids have 330,411,025,341 and 1,809,470,319,867 cells respectively. Both selected literal checks remain `UNKNOWN`, and both symbolic checks report zero expanded cells. Earlier PA one-million-ceiling refusals remain in the evidence. These are verification/resource observations, not proof-search or speed results.

## What does and does not follow about universality

The corrected unbounded eleven-rule calculus corresponds to a standard complete first-order Hilbert basis with equality. The saved mathematical review gives the soundness/basis argument and explicitly does not supply a fully formalized completeness metatheorem. Every finite derivation can in principle have some finite shared AST, enough fresh variables, enough substitution tasks and enough line slots. This statement is about a parameterized construction, not the currently capped executable: actual caps include 64 syntax nodes, 16 lines, eight variables, 16 function/predicate/axiom slots, four substitution tasks and arity four. Resource refusal is not nonprovability. A fair dovetailing policy over increasing bounds, together with appropriately extended checked implementations, is not yet an implemented search service.

`FP/source/counter_frontend_v1.py` is a generic bounded two-counter trace compiler with `INC`, conditional decrement/zero test and absorbing `HALT`. It validates PC range, counter changes, overflow/underflow, unchanged other registers and final halting. It provides a credible uniform route from arbitrarily bounded computations to the same palette, without an efficiency claim. The existing construction notes cite Minsky's 1961 Theorem Ia for the underlying two-counter universality. This assessment did not browse or independently re-verify that primary citation. No proof-checker interpreter has been compiled into that counter language here, and a single finite circuit has no unbounded computational capacity.

For “all mathematics,” one must specify a recursively presented foundation, its effective axiom/derivation syntax, and the input convention. A fixed finite calculus can express derivations in many theories; arbitrary declared assumptions are not automatically axioms of the intended theory. The PA examples use an addition-zero axiom and no induction. The geometry example is a one-sorted incidence-uniqueness fragment, not full Hilbert geometry. For sufficiently expressive arithmetic, no sound effectively axiomatized system proves every true sentence. Aperiodicity is not the missing ingredient: this palette even admits a periodic all-zero `CROSS` tiling.

## Joining the currently audited point proof search

The current `gcts-proof-frontier-audit-20261103-v1` qualifies the unchanged engine on an anchored producer-tree point model: symbolic sites, capacity two, literal formula colors, and optional remote certified-absence ports. It checks the complete supplied finite universe, provider packets, actual graph domains, scheduler, generations, failed-child exclusions and restoration, with native rooted proof checking separate. Formula colors and producer placements vary with the compiled basis. This model is not the fixed 100-type square-cell inventory, and its negative results are bounded to that finite grammar and address depth.

There is nevertheless a clean positive certificate route:

\[
\text{fully audited point search}\longrightarrow
\text{rooted native derivation}\longrightarrow
\text{raw kernel certificate}\longrightarrow
\text{NAND acceptance witness}\longrightarrow
\text{fixed-palette ribbon expansion}.
\]

The old sources implement most arrows separately; they have not joined the **fresh** fully audited traces through all of them with an independent reverse decoder and explicit common statement binding. Trees can repeat subproofs, whereas the producer circuit uses bounded line/DAG records; tree height and line count must not be identified. General native `tautology` producers also need an explicit derivation in `AX1`/`AX2`/`AX3` rather than automatic admission by a truth-table receipt. Current fresh axiom/`MP`/vacuous-`GEN` fixtures avoid that particular lowering problem.

## Next implementable gate

Use a fresh tiny axiom/`MP`/`GEN` family, not a selected proof supplied by a human. Freeze the declared closed theory, goal, complete producer grammar, address bound, raw syntax/line bounds, full statement pins and palette hash before search. Run the audited engine and whole-frontier checker with retained full evidence. Independently decode a positive rooted proof, encode it through the raw kernel, evaluate its circuit, construct its ribbon certificate, and check it with the independent raw and ribbon checkers. Add a separate standard-library inverse decoder from circuit top input bits to raw records and then to the named human AST, checking the exact frozen signature/assumption/goal closure rather than trusting the encoder metadata alone. Re-encode after decoding and require the canonical bit round-trip. Reject altered statement bits, axiom IDs, active references, capture maps, output pins, palette IDs and ribbon selectors. Preserve every compilation/literal refusal as `UNKNOWN`.

In the same gate, repeat actual primitive Wang **search** on several fresh small NAND circuits within the existing 100-cell `point_model` cap. Offer all 100 types at every cell, keep witness bits free, qualify the entire explicit universe independently, and retain every callback for the current whole-frontier checker. Decode found tile assignments instead of constructing them from a chosen Boolean witness. Exhaust every free Boolean assignment separately and compare existence for the complete tiny cases, including an impossible output constraint. This is a tractable checked bridge to the literal palette, without claiming that nontrivial raw proof circuits fit the tiny cap.

Success would establish a fresh end-to-end positive backend join plus tiny literal palette-search conformance. It would still not establish practical large-grid proof search, a solution-set equivalence between arbitrary high-level clusters and primitive Wang search, unrestricted logical completeness of the capped code, outer-boundary-only universality, or GCTS/RL advantage. Large certified ribbons are expansion macros; using them to skip primitive scheduling needs a separate equivalence argument. Any later semantic search over them must be labeled as such and compared to conventional proof search on the same semantic grammar with all translation/checking costs charged.

## Current byte pins

Paths in this table are relative to the full noncloud roots above; `FA` abbreviates their sibling `gcts-proof-frontier-audit-20261103-v1`. The hashes identify this Source reading; they are not new execution receipts.

| Path | Bytes | SHA256 |
| --- | ---: | --- |
| `FP/source/fixed_palette_v1.py` and identical `NK/source/fixed_palette_v1.py` | 8368 | `8d4c09e1977302fd89454f1ab6d8b752d475c0a1a318ddcedac3f434518635fc` |
| `FP/source/producer_frontend_v1.py` | 12901 | `8ee8bb8e4f3b0f2bfb7b5dde460415436c2f5e517686c0e2078473a2032ab6c5` |
| `FP/source/counter_frontend_v1.py` | 12039 | `cfe79af31a34ed2490f0ee5e1f2e9c58bb44677f30e83e5d9a2a217a0e52d110` |
| `FP/source/logical_cases_v1.py` | 8126 | `eb6f6123dced6310e4c1d319974d5caa5dd94ac56f1bd10deacc3c47452a7289` |
| `FP/source/run_study_v2.py` | 23157 | `a87407a9ef27e514fab0a3cc3c53bc024dc024b9f70521833310be84fe1f33af` |
| `FP/reference/ribbon_checker_v1.py` | 14485 | `1be1f676f5da02b3f24a08a484b9eac612496fbc9addd184fc6d534e5deb98ce` |
| `FP/attempt-v2/qualification-v1.json` | 14250 | `d25d67116599ab8b1b7f69845a7e7bc2e2167425dec5cd1885fbaa8e117bf850` |
| `FP/review/milestone-admission-v1.json` | 2073 | `aedb34bec3b37627ae3957b982ea5f623e46a1ce31ed92e8e605d2f33f1309e1` |
| `NK/source/kernel_data_v1.py` | 21103 | `7fc693a12fca8940e95fa7d49ce0982094d03efdfda32d23d839fbe52833596f` |
| `NK/source/raw_kernel_circuit_v1.py` | 17729 | `493e903c688e7aa5a57b5e4eaa4630182bc0bd42245685f3f58cf548d93c089d` |
| `NK/source/raw_kernel_circuit_v2.py` | 2895 | `a38aa4f2415965e894ce6b6764b0fb5be166f10259b0e12664b11780604f99cb` |
| `NK/source/raw_kernel_circuit_v3.py` | 1295 | `921dd80dfff1db388a8d36b7e8ae93df5cba33dfc0a01917f15a178d86b7593f` |
| `NK/source/run_kernel_study_v3.py` | 13380 | `3c8dfa160b5cad2e939c50d85290e505edd88741dc4c5f8318020d9ba96c7647` |
| `NK/reference/raw_fol_checker_v1.py` | 12948 | `831727d9a9ef0e0d4c37a480921b9b4787ad5f3e009f21877e9a36a9f01071c2` |
| `NK/reference/ribbon_checker_v3.py` | 14489 | `e346951922cfe71366f6c31b474c77955a51715eb3e043ff053c169dc8b0adbd` |
| `NK/reference/kernel-spec-v1.txt` | 5118 | `6fe494ed6e03d2b380ee0e534f3ea37f04bb8453fbd9fe5c45a784f701da2c71` |
| `NK/review/qualification-passive-audit-v1.json` | 12516 | `f010bcf359b5c7dec5775ef2fce1235a2b9006cd5f069b6169621e59d7f79c1f` |
| `NK/review/lazy-equivalence-v1.json` | 1629 | `7b212efa2f97ee335ffc8f15a62465ea88afeb45ee972884e5bb35d23d7a19c9` |
| `NK/review/research-passive-admission-v1.json` | 21797 | `699a1d12cfd3f548626a857cfd30980da562014805c61cfb93f03ec9906eea4f` |
| `FA/reference/basic-tiling-algorithm.md` | 21657 | `c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9` |
| `FA/reference/growing_point_search_v2.py` | 39556 | `6e9687145ec2c86719266e07f7ddee4077d88a386c67152dec368657eae43cbb` |
| `FA/reference/frontier_trace_checker_v1.py` | 27040 | `01f46bdf34b414c7470f75f1507f3e76bfefa739533fcc4b2fd121900378343f` |
| `FA/source/native_fixtures_v1.py` | 27450 | `8a631669db12642ac7ee27ec76b8c341345ba100854c380345848831d326a3a6` |
| `FA/review/peer-saved-data-review-v1.json` | 51284 | `0ea992bb005ff676313aa54339d2132385d729fdeee3120cb6a45d4b68efef34` |
