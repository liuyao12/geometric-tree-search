# Arithmetic and symbolic geometry: proposed frontier transfer gate

Status: **Source assessment and prospective contract only**. No engine, classifier, provider, decoder, kernel, graph checker or scientific driver was imported or executed. Only existing Source and stored declarations/preparation metadata were read. No old run or primary checkout was changed. This is preparation for the next goal step, not a new proof or performance result.

Let `W` denote `/Users/liuyao/.codex/visualizations/2026/10/09/01a11e8d-0cf0-7ed2-8930-2aa7f4aab37b`. All paths below are relative to that exact noncloud workspace unless written as absolute paths.

## Recommended two target families

Use the following archived *declaration schemas*, freshly renamed and freshly compiled. Select them because together they exercise native universal instantiation, equality substitution, modus ponens and generalization beyond the new tiny Horn gate. Do not load a target derivation, prior selected CID set, proof certificate, learned library, imported lemma or successful producer path.

**Arithmetic: addition-zero congruence.** Signature: a constant \(0\), unary function \(S\), binary function \(\operatorname{add}\), equality and quantifiers. The only nonlogical hypothesis is

\[
\forall x\;\operatorname{add}(x,0)=x.
\]

The target is

\[
\forall x\;S\bigl(\operatorname{add}(S(x),0)\bigr)=S(S(x)).
\]

In words: applying the successor function to the sum of the successor of an arbitrary object and zero gives the double successor. This is an addition-zero and equality-congruence fragment, with no induction or full Peano arithmetic claim. It is the schema of `source/cases_v1.py::_pa(...,d=1,k=1)` in `gcts-receptor-families-20261103-v1`; the archived declaration ID is `train-pa-d1-k1`. Its frozen declaration SHA256 is `a257234714d7680f00dc84cb53d20cab2c3c82ef7fd689f720d22077d9e7c6ce` using canonical sorted-key ASCII JSON plus LF. That hash is a source locator, not a new cohort ID.

**Symbolic geometry: incidence uniqueness with function congruence.** Signature: constants \(a,b,\ell,m_0\), a unary function \(\operatorname{stamp}\), a binary predicate \(\operatorname{On}\), equality and quantifiers. Define the following abbreviation, expanded as the right-associated conjunction used in the Source:

\[
C(u,v):=\neg(a=b)\land\bigl(\operatorname{On}(a,u)\land(\operatorname{On}(b,u)\land(\operatorname{On}(a,v)\land\operatorname{On}(b,v)))\bigr).
\]

The complete nonlogical hypothesis set is

\[
\left\{\forall l\,\forall m\;\bigl(C(l,m)\to l=m\bigr),\quad C(\ell,m_0)\right\}.
\]

The target is

\[
\operatorname{stamp}(\ell)=\operatorname{stamp}(m_0).
\]

In words: two purported lines containing the same two distinct named points have identical outputs under an uninterpreted function. `stamp` is a signature symbol, not a GCTS marking. The archived function is named `mark`; fresh declaration authoring may rename it mechanically to avoid that ambiguity. This is the schema of `source/cases_v1.py::_incidence(1)` in the same RF run; archived ID `test-incidence-mark-1`, frozen declaration SHA256 `8e06c7293c1b01519821c35b2f582b846e3591d91a92f834114f665218517cae`.

This geometry is entirely symbolic: there are no coordinates, diagrams, metric computations or drawn objects in the proof engine. It is a one-sorted incidence/equality fragment with a specialized uniqueness hypothesis for the named pair, not a complete formalization of Hilbert geometry, not a segment-congruence theorem and not a claim about every geometry model. A later genuine Hilbert benchmark must declare point/line sorts or guarded predicates and the actual incidence/order/congruence axiom set; that is a distinct enlargement, not a relabeling of this gate.

## Available noncloud evidence and resource sizes

The useful RF declaration and basis Source files are intact; its final results retain preparation counts but do not retain complete compiled bases per case. Therefore rebuild these two declarations prospectively. Saved counts are sizing evidence only; fresh renaming can change canonical formula/CID ordering and tie behavior, and every fresh output must be admitted on its actual bytes.

| Archived RF schema | Frozen terms | Equality contexts | Formula registry | ZERO | MP | GEN | Definitions |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Arithmetic above | 7 | 12 | 488 | 245 | 426 | 2 | 673 |
| Incidence above | 8 | 8 | 891 | 410 | 784 | 4 | 1198 |

These are the stored `preparation` records in `gcts-receptor-families-20261103-v1/data/results-v1.json.gz`; no old proof outputs were used to select an answer. The arithmetic profile freezes original subterms and equality contexts, uses one instantiation round, and has no extra declared terms. The incidence profile uses two instantiation rounds and restricts instantiation terms to the two line constants, while the equality/reflexivity pool remains all original terms. Both have the archived caps `max_terms=20`, `max_templates=24`, `max_definitions=8000`; no tautological bridge generation or imported lemma is used by this RF compiler.

For all binary addresses through depth \(H\), include every ZERO at every site and every unary/binary producer at each nonleaf site. The full immutable universe row count is

\[
N(H)=Z(2^{H+1}-1)+(M+G)(2^H-1).
\]

The stored catalogue sizes imply the following **prospective inventory sizes**, not runs or admitted fresh catalogues:

| Schema | \(H=3\) | \(H=4\) |
| --- | ---: | ---: |
| Arithmetic | 6671 | 14015 |
| Incidence | 11666 | 24530 |

An intact earlier compiled archive also exists at `gcts-history-publication-20261102-v1/assets/history-marked-proof-search-evidence-v1.zip`: 4825184 bytes, SHA256 `6cc21e851efc1beb7bffb170d1c9f1a5da0adc112d28873df4933bbe33977844`. Inside it, the member prefix is `originals/upstream-indexed/contents/originals/private/tmp/gcts-indexed-producers-20261028-v1/root/frozen-inputs/`.

- `train-arith-successor-one-whole-build.json.gz`: 19837 bytes, SHA256 `fbe82ee09a95491d942975b226596bff7d985a5b9e1f7b3b830f1885b7879a9c`; stored compiled counts are 552 formulas, 288 ZERO, 272 MP, 19 GEN. Original theory has two recursive-addition axioms, while its *compiled* theory has four axioms after prior lemma application.
- `heldout-incidence-joint-equalities-whole-build.json.gz`: 140849 bytes, SHA256 `ad3d6ecdf82758385cf59e41e61165ce96b2aec5a0177031782aa969e5a64b10`; stored counts are 4500 formulas, 2521 ZERO, 3283 MP, 186 GEN. Original theory has one guarded incidence-uniqueness axiom, while its compiled theory has two axioms after prior lemma application.
- Their matching `*-whole-preparation.json` members retain the **original** symbolic hypotheses/conclusion and prior catalogue/ZERO audit receipts. Member pins respectively: 14413 bytes / `f525196da1717a978c288ce85f119e60b3a9aecdef0409130a30872ead008430`, and 32697 bytes / `931de57bf8dd9f66e39226863c45c7fa02d4fcd0985c63566c0768563dba5a9f`.

Those old compiled extensions are evidence of available language/basis infrastructure, **not** inputs for this new gate. They carry prior lemma axioms and a different basis profile. Never silently use their enriched theory, extension bank or proofs as a fresh original-theory search. The smaller RF targets avoid this dependency and make full-row evidence practical to attempt.

## Existing Source pins to copy unchanged into the fresh run

| Exact source locator | Bytes | SHA256 |
| --- | ---: | --- |
| `gcts-receptor-families-20261103-v1/source/cases_v1.py` | 8634 | `4c91742ccbdf72be61e674339bca9c57fd5047736aa8469c51c1b9eb743c0035` |
| `gcts-receptor-families-20261103-v1/source/finite_basis_v1.py` | 14044 | `97225dcffd98dd5386aeb560a2fc5634dfcc4606ff475a46536207768932a0dc` |
| `gcts-receptor-families-20261103-v1/source/proof_core_v1.py` | 5508 | `d363b72e6f4355225d3dbbdc66c64f746d27bf96de5c4d8a17471cc95b70091c` |
| `gcts-receptor-families-20261103-v1/upstream/indexed_proof_provider_v1.py` | 26917 | `5261bf552924105f3c9ac3a4e9ddce0490869105b1812a8d897610267623b26e` |
| `gcts-receptor-families-20261103-v1/upstream/growing_proof_verifier_v2.py` | 69970 | `6286d6b151d460e6ee0b97983fd9f081168a6d76256a33c3e0f9ead0ffae3aa1` |
| `gcts-receptor-families-20261103-v1/upstream/independent_fol_checker_v1.py` | 21560 | `099454304f3a67c8ec49b1a3685c0dc0896662ae0bc26a18db9320d6cb3404b1` |
| `gcts-proof-frontier-audit-20261103-v1/reference/growing_point_search_v2.py` | 39556 | `6e9687145ec2c86719266e07f7ddee4077d88a386c67152dec368657eae43cbb` |
| `gcts-proof-frontier-audit-20261103-v1/reference/frontier_trace_checker_v1.py` | 27040 | `01f46bdf34b414c7470f75f1507f3e76bfefa739533fcc4b2fd121900378343f` |
| `gcts-proof-frontier-audit-20261103-v1/source/native_fixtures_v1.py` (interface reference only) | 27450 | `8a631669db12642ac7ee27ec76b8c341345ba100854c380345848831d326a3a6` |

The RF frozen declaration container is `gcts-receptor-families-20261103-v1/data/cohort-frozen-v1.json`: 71311 bytes / `9dea8dcf04eaabd4ae17139dbb18195c86a8037aeeb48e99023e5aea73c813d6`. Its preparation-results container is 10577023 bytes / `b3483916597396ca4a8a051dce979b5374ec8f41c90ad542d482df46d15865d2`.

The current master `/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md` is 21657 bytes / `c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9`. Re-pin its current bytes, all dependency bytes and the actual runtime before execution. Do not infer a fresh pin from this assessment alone.

## Required new admission work

1. **New declaration-only cohort.** Freeze two independent alpha/symbol/axiom-name renamings of each schema, at both \(H=3\) and \(H=4\), before classification or target search: eight statement/bound cases. New IDs, renaming maps, exact signatures, hypotheses, goal, basis profile and limits belong in the new run. Preserve archived names only as provenance. Author no target derivation. Do not call the old successful driver or load old learned weights/libraries.
2. **Extend catalogue admission, not the logical kernel.** The tiny Horn gate's `_definitions` accepts only its intended named axioms and reflexivity ZERO lines. It must not be reused unchanged: these profiles contain native `instantiate` and `eq_subst` ZERO schemas. Independently validate every ZERO with the pinned native FOL checker, reconstruct all structural MP/GEN entries from the literal registry, and bind ZERO IDs/output colors/native rules exactly. Audit free-for substitution, original term/context freezing, all allowed instantiation rounds/pairs and equality-output retention. `verify_factory` checks the declared carrier but explicitly leaves catalogue-generation truth external. It is not a substitute for this audit.
3. **State the precise completeness premise.** The initial feasible fallback is to freeze the complete explicit ZERO list as the declared finite grammar, kernel-check every member, and qualify the full placement universe relative to that list. That supports sound positives and exhaustion of that stated grammar. Claiming completeness for *all* instances of the RF generation profile additionally needs an independent reconstruction of its native instance enumeration; a matching Source version or successful ZERO checks alone does not establish absence of omitted instances. Record this distinction instead of silently upgrading a narrower check.
4. **Independent complete row construction.** Build all depth-admissible canonical `site,definitionID` rows without provider placement/enumeration helpers. Verify row uniqueness, exact own/first/second premise contacts, capacity two, root seed one, literal formula colors and no arbitrary disconnected seed roots. Retain the entire universe and its digest. For MARKS, retain every original CID with the exact additional premise-port marks; for FILTER, build an explicit certified-redundant restricted inventory with honest reduced counts. Reuse the new frontier checker's ABI unchanged if it accepts actual resource sizes.
5. **Raw before assurance, every step.** Fresh provider per run; save model/universe/factory/basis/generation and complete raw search before checking. Retain every audit callback and all completed indexed packets, full event/query/rollback stream records and hashes, total/retained census, before/after Source guards and actual process exit. Check `frontier_trace_checker.verify(model,universe,observations,result)` with no endpoint-only substitution. Reject omitted weighted edges, remote marking dependencies, unjustified/sibling exclusions, emergent generation changes and altered rows even when counts/hashes were coherently changed.
6. **Positive logic stays separate.** For actual solver-selected CIDs only, run the pinned decoder, independent tree verifier and native FOL kernel against the fresh original theory/goal. The tiny Horn direct fragment checker is outside its advertised fragment here and must not be relabeled as arithmetic/geometry assurance. Translate actual decoded lines into LaTeX formulas plus English and prior-line references. A point-complete disconnected nonproof must still fail native decoding. No output proof from any control is fed into another lane.

## Lanes, bounds and cost accounting

Run BASE, literal certified MARKS and explicit FILTER for each of the eight frozen cases: 24 prospective point-engine jobs. Add eight independent `growing_proof_verifier_v2.tree_control` jobs on the same original compiled grammar and height. That routine already implements formula/remaining-height dynamic programming, minimizes expanded tree-node count and emits every tree occurrence separately; its memoized work is not DAG proof-size compression. It is a specialized conventional control and need not obey the GCTS frontier scheduler. Its positive outputs require the same native kernel join, while `NOT_DERIVABLE` means only this finite grammar and height. Its objective differs from first-proof point search; do not compare its node counter numerically with graph-event counts as if they measure the same work.

For the first frozen protocol, a reasonable **proposed** cap is 20 seconds/5000 expanded search nodes per point job, 50000 candidate registrations, 4096 active points and 50000 retained events/rollback records; use explicit global observer CPU/RSS/storage guards as well. Full evidence is mandatory for admission: hitting a retention cap without a completed independent stream is `UNKNOWN`, not a verified negative. Predeclare checker bounds such as 100 million JSON items and a separate 30-second check window, then retain actual Source/API/resource refusals. These values are a planning proposal, not evidence of feasibility; no adapter may silently truncate the universe or observations to fit them. Full snapshots with long formula-color strings could dominate checking/storage, so report actual materialized bytes and separate construction/search/checking costs.

Freeze a syntax-only request policy for failures before learning: the 24 most frequent premise FIDs, excluding the top-level goal FID, ties by canonical ID, with remaining heights below the declared top bound. Independent checked absence DAGs alone create literal negative seed flags; unresolved requests are unconstrained. Positive classification witnesses and any top-level proof discovered during preprocessing remain separate preprocessing evidence, never search input. Retain all preprocessing cost and start a fresh classifier/memo table per case; do not preload old failures. The same checked certificate drives MARKS and FILTER. They test geometric transport of tabling constraints, not novel theorem-proving power.

Compare both prepared-input solve cost and end-to-end cost including compilation, all ZERO checks, full factory/universe admission, failure acquisition and output verification. Rotate lane order prospectively; counters, limits and evidence overhead remain labeled by method. Native negative results are bounded exhaustion only. FOL terms/syntax are not grown fairly without bound in this protocol. There is no RL or learned-family bank in the initial transfer gate and no claim of advantage over general ATPs.

The previous tiny gate exhaustively enumerated all rooted proof sets. Full enumeration can explode for these richer equality catalogues. Attempt an independent bounded reference enumeration only under a declared nontruncating cap; publish a set count/equality claim only on `COMPLETE`. Otherwise report preservation via the independently checked absence-certificate argument and exact row transformation, conditional on the admitted finite grammar, and label exhaustive set counts `UNKNOWN`. A DP existence agreement is not equality of all proof sets. Never turn an incomplete enumerator, sampling or a chosen successful proof into an exact-set preservation claim.

## Explicit unresolved boundaries and completion criterion

The next milestone is complete only if at least one fresh arithmetic and one fresh incidence case produce a fully retained, independently accepted frontier trace plus separately native-checked solver output, with complete immutable universes qualified on their actual bytes. A bounded `UNKNOWN` is an honest result to retain; it does not close that positive-transfer objective, and it should not trigger unreported tuning or replay of already executed jobs. New bounds or assurance repairs require new versioned Sources/protocols and preserve original raw attempts.

Remaining boundaries are the richer ZERO-catalogue admission, evidence/resource scaling, exact-set enumeration if attempted, full Hilbert axiom/sort formalization, unrestricted proof search, and eventual lemma-family/RL transfer. This assessment establishes none of those. It supplies concrete declarations and a reproducible next gate without inserting the target proof.
