"""Inert X guidance qualification; producers and old independent W audit injected.

The frozen W qualifier supplies complete tiny member/solution/state/base-result
checks. New code checks protected requests, full packet unions, retained guide
traces and scheduler decisions. No project imports, IO or module-body calls.
"""
import hashlib
import math
import time

VERSION = 'X-INDEPENDENT-CLUSTER-GUIDANCE-QUALIFICATION-v1'
ENGINE_LIMITS = {'wall_seconds': 5, 'max_nodes': 50000, 'max_operations': 100000000,
                 'max_definitions': 10000, 'max_virtual_members': 100000,
                 'max_events': 100000}
BUILD_LIMITS = {'wall_seconds': 5, 'max_work': 100000000, 'max_basis': 10000,
                'max_instances': 10000, 'max_depth': 128,
                'max_cache_entries': 100000, 'max_interned': 100000}
PROPOSAL_LIMITS = {'max_calls': 128, 'max_members': 4, 'max_packets': 4, 'max_records': 512}
SCOPE = 'Complete six tiny catalogues/graphs/solution sets and focused guidance protocol; original primitive logical truth and production matcher/RL usefulness remain separately checked.'


def _need(ok, reason):
    if not ok:
        raise AssertionError(reason)


def _fields(value, fields):
    _need(type(value) is dict and len(value) == len(fields) and set(value) == set(fields), 'exact fields')


def _cases():
    p = ['pred', 'P', []]; q = ['pred', 'Q', []]; r = ['pred', 'R', []]
    return [
        ('FORCED', {'p': p}, p, 2),
        ('LATE-DEAD', {'p': p}, q, 2),
        ('MP', {'p': p, 'pq': ['imp', p, q]}, q, 3),
        ('BAD-FIRST', {'bad': ['imp', r, q], 'p': p, 'pq': ['imp', p, q]}, q, 3),
        ('ALIASES', {'a': p, 'b': p}, p, 3),
        ('CYCLE', {'pq': ['imp', p, q], 'qp': ['imp', q, p]}, p, 4),
    ]


def _legal(graph, state, row):
    if state['occupied'][row]:
        return []
    return sorted(cid for cid, (q, marks, _) in graph['candidates'].items()
                  if q == row and cid not in state['excluded'] and
                  all(state['values'][point] is None or state['values'][point] == value
                      for point, value in marks.items()))


def _packet_wire(packet, maximum):
    if type(packet) is not dict or set(packet) != {'id', 'members'}:
        return False
    pid, members = packet['id'], packet['members']
    return (type(pid) is str and 1 <= len(pid) <= 128 and
            all(32 <= ord(c) <= 126 for c in pid) and type(members) is list and
            1 <= len(members) <= maximum and
            all(type(cid) is str and 1 <= len(cid) <= 128 and
                all(32 <= ord(c) <= 126 for c in cid) for cid in members) and
            len(set(members)) == len(members))


def _packet(graph, state, row, packet, continuation=False):
    """Independent full union check; errors are a set, not kernel precedence."""
    errors = set(); shared = []; new = []
    if type(packet) is not dict or set(packet) != {'id', 'members'}:
        return {'PACKET_FIELDS'}, shared, new
    pid, members = packet['id'], packet['members']
    if type(pid) is not str or not 1 <= len(pid) <= 128 or not all(32 <= ord(c) <= 126 for c in pid):
        errors.add('PACKET_ID')
    if type(members) is not list or not 1 <= len(members) <= PROPOSAL_LIMITS['max_members']:
        return errors | {'MEMBER_LIMIT_OR_TYPE'}, shared, new
    if not all(type(cid) is str and 1 <= len(cid) <= 128 and all(32 <= ord(c) <= 126 for c in cid) for cid in members):
        return errors | {'MEMBER_ID'}, shared, new
    if len(set(members)) != len(members):
        errors.add('DUPLICATE_MEMBER_ID')
    rows = {}; union = {}
    for cid in members:
        if cid not in graph['candidates']:
            errors.add('MALFORMED_BASE_MEMBER'); continue
        positive, marks, _ = graph['candidates'][cid]
        if positive in rows and rows[positive] != cid:
            errors.add('DUPLICATE_POSITIVE_ROW')
        rows[positive] = cid
        if cid in state['excluded']:
            errors.add('SCOPED_EXCLUSION')
        if state['occupied'][positive]:
            if state['selected'][positive] == cid:
                shared.append(cid)
            else:
                errors.add('OCCUPIED_BY_OTHER_MEMBER')
        else:
            new.append(cid)
        for point, value in marks.items():
            if state['values'][point] is not None and state['values'][point] != value:
                errors.add('CURRENT_MARK_CONFLICT')
            if point in union and union[point] != value:
                errors.add('PACKET_MARK_CONFLICT')
            union[point] = value
    if not continuation and not any(cid in new and graph['candidates'][cid][0] == row for cid in members):
        errors.add('NOT_INCIDENT_TO_ANCHOR')
    return errors, shared, new


def _event(graph, event, state, audit, previous, legacy, meter):
    _fields(event, ('seq', 'kind', 'data'))
    old = None if previous is None else previous['state']
    kind, data = event['kind'], event['data']
    if old is None:
        _need(kind == 'ENTRY' and event['seq'] == 0, 'initial observation')
        return
    legal = previous['audit']['legal_ids']
    same = lambda a, b: legacy._same(a, b, meter)
    if kind == 'BRANCH':
        frontier = [q for q in range(len(legal)) if not old['occupied'][q]]
        _need(frontier and all(len(legal[q]) >= 2 for q in frontier), 'dead/forced before branch')
        row = min(frontier, key=lambda q: (len(legal[q]), 'slot:' + str(q)))
        _fields(data, ('row', 'generation', 'degree', 'first_candidate', 'order'))
        _need(data['row'] == row and type(data['row']) is int and type(data['generation']) is int and data['generation'] == 0 and data['degree'] == len(legal[row]), 'root MRV')
        _need(data['first_candidate'] in legal[row] and same(old, state), 'actual branch member')
        _need(data['order'] in ('COMPLETE_U_LEXICAL_VIRTUAL_MEMBERS', 'VALIDATED_CLUSTER_MEMBER_WITH_COMPLETE_BASE_FALLBACK'), 'declared policy')
        if data['order'] == 'COMPLETE_U_LEXICAL_VIRTUAL_MEMBERS':
            _need(data['first_candidate'] == legal[row][0], 'complete lexical fallback')
    elif kind == 'PLACED':
        _fields(data, ('candidate', 'row', 'forced', 'root_generation', 'tile_generation'))
        q, cid = data['row'], data['candidate']
        _need(type(q) is int and 0 <= q < len(legal) and type(data['forced']) is bool and cid in legal[q], 'actual legal placement')
        _need(type(data['root_generation']) is int and data['root_generation'] == 0 and type(data['tile_generation']) is int and data['tile_generation'] == 1, 'generations')
        if data['forced']:
            singles = [j for j in range(len(legal)) if not old['occupied'][j] and len(legal[j]) == 1]
            _need(all(legal[j] for j in range(len(legal)) if not old['occupied'][j]) and singles and q == min(singles, key=lambda j: 'slot:' + str(j)), 'global forced priority')
        expected = list(old['selected']); expected[q] = cid
        _need(same(expected, state['selected']) and same(old['excluded'], state['excluded']), 'single base placement')
    elif kind == 'DEAD':
        q = data['row']
        _need(type(q) is int and not state['occupied'][q] and not audit['legal_ids'][q] and same(old, state), 'complete actual dead')
    elif kind == 'EXCLUDED':
        cid = data['candidate']
        _need(cid in graph['candidates'] and cid not in old['excluded'] and state['excluded'] == sorted(old['excluded'] + [cid]), 'one scoped exclusion')
        _need(all(same(old[k], state[k]) for k in ('occupied', 'selected', 'values', 'refs')), 'exclusion changes only exclusion')
        _need(data['parent_core_sha256'] == previous['audit']['core_sha256'], 'exclusion parent')
    elif kind == 'ROLLBACK':
        _need(data['reason'] == 'FAILED_CHILD' and data['before_core_sha256'] == previous['audit']['core_sha256'] and data['after_core_sha256'] == data['expected_parent_core_sha256'] == audit['core_sha256'], 'failed child core restoration')
    elif kind == 'SOLUTION':
        _need(all(state['occupied']) and data['selected'] == audit['selected'] and same(old, state), 'whole solution')
    else:
        raise AssertionError('unexpected observed event')


def _trace(graph, result, observations, callbacks, legacy, meter):
    heuristic = result['heuristic']
    _fields(heuristic, ('schema', 'limits', 'stats', 'trace', 'scope'))
    _need(heuristic['schema'] == 'X-validated-cluster-guide-v1', 'heuristic schema')
    stats = heuristic['stats']
    intkeys = ('calls', 'offered_packets', 'valid_packets', 'rejected_packets', 'continuation_tests', 'continuation_uses', 'preferred_placements', 'max_covered', 'limit_skips')
    _fields(stats, intkeys + ('executed_packet_ids', 'callback_seconds', 'validation_seconds'))
    _need(all(type(stats[k]) is int and stats[k] >= 0 for k in intkeys), 'heuristic counters')
    _need(all(type(stats[k]) in (int, float) and math.isfinite(stats[k]) and stats[k] >= 0 for k in ('callback_seconds', 'validation_seconds')), 'heuristic clocks')
    executed = stats['executed_packet_ids']
    _need(type(executed) is dict and all(type(k) is str and type(v) is int and v >= 0 for k, v in executed.items()) and sum(executed.values()) == stats['preferred_placements'], 'actual preferred placements')
    trace = heuristic['trace']
    _fields(trace, ('count', 'retained', 'JSONL_bytes', 'SHA256', 'records'))
    records = trace['records']
    _need(type(records) is list and all(type(trace[k]) is int and trace[k]>=0 for k in ('count','retained','JSONL_bytes')) and trace['count'] == trace['retained'] == len(records), 'full guide trace retained')
    stream = b''.join(legacy._wire(row, meter) for row in records)
    _need(trace['JSONL_bytes'] == len(stream) and trace['SHA256'] == hashlib.sha256(stream).hexdigest(), 'guide full-body hash')
    callback_index = 0; validated = 0; rejected = 0
    by_branch = []
    reasons = {'PACKET_FIELDS','PACKET_ID','MEMBER_LIMIT_OR_TYPE','MEMBER_ID','DUPLICATE_MEMBER_ID','MALFORMED_BASE_MEMBER','DUPLICATE_POSITIVE_ROW','INTERNAL_COINCIDENT_MARK_CONFLICT','SCOPED_EXCLUSION','OCCUPIED_BY_OTHER_MEMBER','CURRENT_MARK_CONFLICT','PACKET_MARK_CONFLICT','NOT_INCIDENT_TO_ANCHOR'}
    statuses = {'NOT_CALLED','REJECTED_RESPONSE_FIELDS','REJECTED_MODEL_BINDING','REJECTED_QUERY_BINDING','REJECTED_PACKET_LIMIT_OR_TYPE','COMPLETE_BOUNDED_REPLY'}
    for number, record in enumerate(records):
        _fields(record, ('seq','row','required_output','state','core_sha256','carried','offered','response_status','response_binding','validations','chosen_packet','chosen_candidate','cause'))
        _need(type(record['seq']) is int and record['seq'] == number and record['response_status'] in statuses, 'guide sequence/status')
        state, row = record['state'], record['row']
        audit = legacy.audit_state(graph['compiled'], graph['model']['slots'], state)
        _need(audit['status'] == 'VERIFIED' and audit['core_sha256'] == record['core_sha256'], 'protected guide state')
        _need(type(row) is int and 0 <= row < graph['model']['slots'] and not state['occupied'][row], 'guide row')
        frontier = [q for q in range(graph['model']['slots']) if not state['occupied'][q]]
        _need(all(len(audit['legal_ids'][q]) >= 2 for q in frontier) and row == min(frontier,key=lambda q:(len(audit['legal_ids'][q]),'slot:'+str(q))), 'guidance only after propagation/MRV')
        fixed = graph['model']['goal_id'] if row == graph['model']['slots'] - 1 else state['values'][row]
        _need(record['required_output'] == fixed and (record['required_output'] is None or type(record['required_output']) is int), 'required output binding')
        offered, carried = record['offered'], record['carried']
        _need(type(offered) is list and (carried is None or type(carried) is dict), 'packet projections')
        packets = list(offered)
        if carried is not None:
            packets.append(carried)
        if record['response_status'] != 'NOT_CALLED':
            _need(callback_index < len(callbacks), 'actual callback association')
            called = callbacks[callback_index]; callback_index += 1
            request, response = called['request'], called.get('response')
            _fields(request, ('schema','query_id','model_sha256','slots','row','required_output','state','limits'))
            _need(request['schema'] == 'X-cluster-proposal-request-v1' and type(request['query_id']) is int and request['query_id'] == callback_index - 1, 'query schema/nonce')
            _need(type(request['model_sha256']) is str and request['model_sha256'] == result['model_sha256'] and type(request['slots']) is type(request['row']) is int and request['slots'] == graph['model']['slots'] and request['row'] == row and request['required_output'] == fixed and (request['required_output'] is None or type(request['required_output']) is int) and legacy._same(request['state'], state, meter), 'complete callback request')
            _fields(request['limits'], ('max_packets','max_members'))
            _need(request['limits'] == {k:heuristic['limits'][k] for k in ('max_packets','max_members')}, 'query limits')
            projection = None
            if type(response) is dict and type(response.get('model_sha256')) is str and len(response['model_sha256']) == 64 and type(response.get('query_id')) is int and 0 <= response['query_id'] <= 100000:
                projection = {'model_sha256':response['model_sha256'],'query_id':response['query_id']}
            _need(legacy._same(record['response_binding'], projection, meter), 'bounded actual response header')
            if type(response) is not dict or set(response) != {'model_sha256','query_id','packets'}:
                expected_status='REJECTED_RESPONSE_FIELDS'
            elif type(response['model_sha256']) is not str or response['model_sha256']!=result['model_sha256']:
                expected_status='REJECTED_MODEL_BINDING'
            elif type(response['query_id']) is not int or response['query_id']!=request['query_id']:
                expected_status='REJECTED_QUERY_BINDING'
            elif type(response['packets']) is not list or len(response['packets'])>request['limits']['max_packets']:
                expected_status='REJECTED_PACKET_LIMIT_OR_TYPE'
            else:
                expected_status='COMPLETE_BOUNDED_REPLY'
            _need(record['response_status']==expected_status,'exact response refusal scope')
            if record['response_status'] == 'COMPLETE_BOUNDED_REPLY':
                _fields(response, ('model_sha256','query_id','packets'))
                _need(response['model_sha256'] == result['model_sha256'] and type(response['query_id']) is int and response['query_id'] == request['query_id'], 'accepted response scope')
                _need(type(response['packets']) is list and len(response['packets']) <= request['limits']['max_packets'] and len(offered) == len(response['packets']), 'bounded complete packet list')
                for raw, normalized in zip(response['packets'], offered):
                    if normalized is not None:
                        _need(_packet_wire(raw, request['limits']['max_members']) and legacy._same(raw, normalized, meter), 'no offered field loss')
                    else:
                        _need(not _packet_wire(raw, request['limits']['max_members']), 'only malformed packets normalize to null')
            else:
                _need(record['chosen_packet'] is None and not offered, 'rejected response falls back')
        if record['response_status']=='NOT_CALLED':
            _need(record['response_binding'] is None,'no fabricated callback header')
        for verdict in record['validations']:
            _fields(verdict, ('origin','packet_id','status','reason','shared_members','new_members'))
            _need(verdict['origin'] in ('CALLBACK','CONTINUATION') and verdict['status'] in ('VALID','REJECTED'), 'verdict types')
            candidates = [p for p in (offered if verdict['origin']=='CALLBACK' else [carried]) if type(p) is dict and p.get('id') == verdict['packet_id']]
            _need(type(verdict['shared_members']) is type(verdict['new_members']) is list and all(type(cid) is str for cid in verdict['shared_members'] + verdict['new_members']), 'verdict visited members')
            if verdict['status'] == 'VALID':
                _need(verdict['reason'] is None and candidates, 'valid packet identified')
                matches = []
                for packet in candidates:
                    errors, shared, new = _packet(graph,state,row,packet,verdict['origin']=='CONTINUATION')
                    matches.append(not errors and shared == verdict['shared_members'] and new == verdict['new_members'])
                _need(any(matches), 'whole actual packet union')
                validated += int(verdict['origin']=='CALLBACK')
            else:
                _need(verdict['reason'] in reasons, 'rejection reason')
                if candidates:
                    _need(all(_packet(graph,state,row,p,verdict['origin']=='CONTINUATION')[0] for p in candidates), 'no false rejection of complete valid packet')
                rejected += int(verdict['origin']=='CALLBACK')
        legal = audit['legal_ids'][row]
        chosen = record['chosen_candidate']
        _need(chosen in legal, 'guide never invents legal member')
        if record['cause'] == 'COMPLETE_LEXICAL_FALLBACK':
            _need(record['chosen_packet'] is None and chosen == legal[0], 'full base fallback')
        else:
            _need(record['cause'] in ('VALIDATED_CONTINUATION','VALIDATED_NEW_CLUSTER') and type(record['chosen_packet']) is str, 'declared preferred cause')
            eligible = [p for p in packets if type(p) is dict and p.get('id') == record['chosen_packet'] and chosen in p.get('members',[])]
            _need(any(not _packet(graph,state,row,p,record['cause']=='VALIDATED_CONTINUATION')[0] for p in eligible), 'chosen whole current union')
        by_branch.append((record['core_sha256'],row,chosen,record['cause'],record['chosen_packet']))
    _need(callback_index <= len(callbacks) and stats['calls'] == len(callbacks), 'callback count')
    if result['status'] != 'UNKNOWN':
        _need(callback_index == len(callbacks) and stats['valid_packets'] == validated and stats['rejected_packets'] == rejected, 'complete callback verdict counts')
    for observed in observations:
        event = observed['event']
        if event['kind'] == 'BRANCH' and event['data']['order'] == 'VALIDATED_CLUSTER_MEMBER_WITH_COMPLETE_BASE_FALLBACK':
            data=event['data']
            _need(any(core==observed['audit']['core_sha256'] and row==data['row'] and cid==data['first_candidate'] and cause!='COMPLETE_LEXICAL_FALLBACK' for core,row,cid,cause,pid in by_branch), 'actual preferred branch provenance')
    actual_preferred={}
    for index,observed in enumerate(observations):
        event=observed['event']
        if index and event['kind']=='PLACED' and not event['data']['forced']:
            before=observations[index-1]['audit']['core_sha256']
            matches=[pid for core,row,cid,cause,pid in by_branch if core==before and row==event['data']['row'] and cid==event['data']['candidate'] and cause!='COMPLETE_LEXICAL_FALLBACK']
            if matches:
                pid=matches[-1];actual_preferred[pid]=actual_preferred.get(pid,0)+1
    if result['status']!='UNKNOWN':
        _need({pid:n for pid,n in executed.items() if n}==actual_preferred,'every actual preferred-placement credit')
    else:
        _need(all(executed.get(pid,0)>=n for pid,n in actual_preferred.items()),'observed preferred credit lower bound')
    maximum = max([sum(row['state']['occupied']) for row in observations]+[0])
    if result['status']!='UNKNOWN':
        _need(stats['max_covered'] == maximum, 'actual completed occupancy maximum')
    else:
        _need(maximum<=stats['max_covered']<=graph['model']['slots'],'owned-stop observation-prefix occupancy scope')
    _need(stats['preferred_placements'] <= result['stats']['placements'], 'actual preferred credit')
    return {'status':'VERIFIED','guide_records':len(records),'callbacks':len(callbacks),'valid_packets':validated,'rejected_packets':rejected}


def _callback(mode, graph, legacy, meter, calls):
    def propose(request, charge):
        protected = legacy._clone(request,meter)
        row,state = protected['row'],protected['state']
        record={'request':protected};calls.append(record)
        legal=_legal(graph,state,row)
        _need(len(legal)>=2,'callback only at branching frontier')
        packets=[]
        if mode=='FOREIGN':
            raise ForeignCallbackError('deliberate qualification callback')
        if mode=='OWNED-STOP':
            charge(1000000000000)
            raise AssertionError('owned stop not raised')
        if mode=='FORBIDDEN':
            raise AssertionError('mandatory propagation called proposer')
        if mode=='MALFORMED':
            response={'wrong':True}
        else:
            if mode in ('PREFER','BAD-FIRST','EXCLUDED'):
                chosen=legal[-1]
                if mode=='BAD-FIRST' and row==0:
                    bad=[cid for cid in legal if graph['steps'][cid]['line'].get('name')=='bad']
                    _need(bad,'bad-first candidate exists');chosen=bad[0]
                members=[chosen]
                if mode=='PREFER':
                    for q in range(graph['model']['slots']):
                        if q==row or state['occupied'][q]:continue
                        for cid in _legal(graph,state,q):
                            packet={'id':mode,'members':members+[cid]}
                            if not _packet(graph,state,row,packet)[0]:
                                members.append(cid);break
                if mode=='EXCLUDED' and state['excluded']:
                    members=[state['excluded'][0],chosen]
                packets=[{'id':mode,'members':members}]
                if mode=='EXCLUDED':
                    blocked=next((cid for cid,(q,marks,_) in graph['candidates'].items() if q!=row and not state['occupied'][q] and any(state['values'][point] is not None and state['values'][point]!=value for point,value in marks.items())),None)
                    if blocked is not None:
                        packets.insert(0,{'id':'CURRENT-BLOCK','members':[chosen,blocked]})
            elif mode=='SAME-ROW':
                packets=[{'id':mode,'members':legal[:2]}]
            elif mode=='REMOTE-CONFLICT':
                found=None
                for cid in legal:
                    for other,(q,_,_) in graph['candidates'].items():
                        if q==row or other not in _legal(graph,state,q):continue
                        packet={'id':mode,'members':[cid,other]}
                        if 'PACKET_MARK_CONFLICT' in _packet(graph,state,row,packet)[0]:
                            found=packet;break
                    if found:break
                _need(found is not None,'remote union-conflict control exists');packets=[found]
            elif mode=='BAD-CIDS':
                head=next(fi for fi,a,b in graph['model']['mp_index'] if b==graph['model']['goal_id'] and fi!=a)
                packets=[{'id':'UNKNOWN-CID','members':[legal[0],'r999:i0']},
                         {'id':'COINCIDENT-MARKS','members':[legal[0],'r2:mp:'+str(head)+':0:0']}]
            elif mode=='OCCUPIED':
                for q,selected in enumerate(state['selected']):
                    if selected is not None:
                        other=next(cid for cid,(positive,_,_) in graph['candidates'].items() if positive==q and cid!=selected)
                        packets=[{'id':mode,'members':[legal[0],other]}];break
            elif mode=='TOO-MANY':
                packets=[{'id':'overflow'+str(i),'members':[legal[0]]} for i in range(protected['limits']['max_packets']+1)]
            response={'model_sha256':protected['model_sha256'],'query_id':protected['query_id'],'packets':packets}
            if mode=='STALE-MODEL':response['model_sha256']='0'*64
            if mode=='STALE-QUERY':response['query_id']+=1
        record['response']=legacy._clone(response,meter)
        if mode=='MUTATE':
            request['state']['values'][0]=999999999
            request['state']['selected'][0]='forged-query-only'
            request['row']=999999999
        return response
    return propose


class ForeignCallbackError(Exception):
    pass


def _solve(engine, compiled, slots, graph, solutions, core, legacy, meter,
           mode=None, proposal_limits=None, is_baseline=False, capture=None):
    observations=[];calls=[]
    input_sha=legacy._sha(compiled,meter)
    if capture is not None:
        capture.update({'observations':observations,'calls':calls,'input_sha256':input_sha})
    def observe(event,state):
        audit=legacy.audit_state(compiled,slots,state)
        _need(audit['status']=='VERIFIED','full independent W state audit')
        chosen=set(audit['selected'])
        for cid in state['excluded']:
            _need(not any(chosen.union([cid]).issubset(solution) for solution in solutions), 'scoped exclusion preserves all tiny completions')
        _event(graph,event,state,audit,observations[-1] if observations else None,legacy,meter)
        observations.append({'event':legacy._clone(event,meter),'state':legacy._clone(state,meter),'audit':audit})
        return False
    kwargs={'observe':observe}
    if not is_baseline:
        kwargs['proposal_limits']=dict(PROPOSAL_LIMITS if proposal_limits is None else proposal_limits)
        if mode is not None:kwargs['propose']=_callback(mode,graph,legacy,meter,calls)
    result=engine.solve(compiled,slots,dict(ENGINE_LIMITS),**kwargs)
    _need(legacy._sha(compiled,meter)==input_sha,'complete producer input unchanged')
    base=dict(result)
    if not is_baseline:
        _need(result['schema']=='X-cluster-guided-unit-point-result-v1' and result['version']=='X-CLUSTER-GUIDED-UNIT-PROOF-POINT-SEARCH-v1','X result identity')
        base.pop('heuristic');base['schema']='W-aggregate-unit-point-result-v1'
    actual_solutions=None if result['status']=='UNKNOWN' else solutions
    audit=legacy._result(graph,base,observations,meter,actual_solutions,expected_version=result['version'])
    if not is_baseline:
        guidance=_trace(graph,result,observations,calls,legacy,meter)
        _need(result['heuristic']['limits']==kwargs['proposal_limits'],'exact proposal limits')
    else:guidance=None
    selection=None
    if result['status']=='SAT':
        selection=core.verify_selection(graph['problem'],compiled,slots,result['selected'])
        _need(selection['status']=='VERIFIED','whole actual selected proof')
    return {'result':result,'observations':observations,'calls':calls,'audit':audit,
            'guidance_audit':guidance,'selection':selection}


def qualify(basis, engine, baseline, core, legacy, emit):
    """Six injected modules/callbacks; all calls occur only inside a future once."""
    meter=legacy._Meter(wall=60,work=1000000000)
    _need(callable(emit),'emit callable')
    fixtures={};emitted=0;counts={'basis_build':0,'engine_solve':0,'baseline_solve':0,'core_compiled':0,'core_selection':0,'emit':0}
    for name,axioms,goal,slots in _cases():
        problem={'theory':{'functions':{},'predicates':{'P':0,'Q':0,'R':0},'axioms':axioms},
                 'goal':goal,'profile':{'ui_rounds':0,'bridge_arity':0,'max_tautology_atoms':4}}
        built=basis.build_basis(problem['theory'],goal,problem['profile'],dict(BUILD_LIMITS));counts['basis_build']+=1
        _need(built['status']=='COMPLETE','tiny complete basis')
        compiled=built['compiled'];check=core.verify_compiled(problem,compiled);counts['core_compiled']+=1
        _need(check['status']=='VERIFIED','entire tiny compiled basis')
        graph=legacy._graph(compiled,slots,meter)
        predicted=1
        for domain in graph['domain']:
            meter.tick()
            predicted*=len(domain)
            _need(predicted<=10000,'preflight tiny product cap')
        product,solutions=legacy._solutions(graph,meter)
        expected={'FORCED':(1,1),'LATE-DEAD':(0,0),'MP':(8,2),'BAD-FIRST':(36,2),'ALIASES':(8,8),'CYCLE':(144,0)}
        _need(product==predicted and (product,len(solutions))==expected[name],'complete analytical tiny census')
        graph['compiled']=compiled;graph['problem']=problem
        before=legacy._sha(compiled,meter)
        mandatory_mode='FORBIDDEN' if name in ('FORCED','LATE-DEAD') else None
        plain=_solve(engine,compiled,slots,graph,solutions,core,legacy,meter,mandatory_mode);counts['engine_solve']+=1
        if mandatory_mode is not None:_need(not plain['calls'],'global mandatory stage precedes callback')
        old=_solve(baseline,compiled,slots,graph,solutions,core,legacy,meter,is_baseline=True);counts['baseline_solve']+=1
        counts['core_selection']+=int(plain['selection'] is not None)+int(old['selection'] is not None)
        for field in ('status','selected','certificate','model','families','model_sha256','entry_state','restored_state','state_hashes','events','event_extent','rollback_records'):
            _need(legacy._same(plain['result'][field],old['result'][field],meter),'no-hook complete W equivalence '+field)
        _need(legacy._sha(compiled,meter)==before,'compiler inputs unchanged')
        record={'problem':problem,'slots':slots,'basis_return':built,'compiled_check':check,'product':product,
                'full_solution_ID_sets':[list(s) for s in sorted(solutions)],'point':plain,'baseline':old}
        emit('NOHOOK-'+name,record);emitted+=1;counts['emit']+=1
        fixtures[name]=(compiled,slots,graph,solutions,record)
    modes=[('PREFER','ALIASES'),('BAD-FIRST','BAD-FIRST'),('REMOTE-CONFLICT','MP'),
           ('SAME-ROW','ALIASES'),('BAD-CIDS','MP'),('MALFORMED','ALIASES'),
           ('STALE-MODEL','ALIASES'),('STALE-QUERY','ALIASES'),('TOO-MANY','ALIASES'),
           ('EXCLUDED','CYCLE'),('MUTATE','ALIASES'),('OCCUPIED','ALIASES')]
    for mode,name in modes:
        compiled,slots,graph,solutions,_=fixtures[name]
        run=_solve(engine,compiled,slots,graph,solutions,core,legacy,meter,mode);counts['engine_solve']+=1
        _need(run['result']['status'] in ('SAT','UNSAT'),'ordinary proposal control complete')
        counts['core_selection']+=int(run['selection'] is not None)
        h=run['result']['heuristic'];reasons=[v['reason'] for row in h['trace']['records'] for v in row['validations']]
        if mode=='PREFER':
            _need(h['stats']['continuation_uses']>0 and h['stats']['preferred_placements']>=2 and any(v['shared_members'] for row in h['trace']['records'] for v in row['validations'] if v['status']=='VALID'),'real shared continuation')
        elif mode=='BAD-FIRST':
            _need(run['result']['stats']['backtracks']>0 and any(row['event']['kind']=='ROLLBACK' for row in run['observations']),'actual failed-child guidance restoration')
        elif mode=='REMOTE-CONFLICT':_need('PACKET_MARK_CONFLICT' in reasons,'remote marking conflict refused')
        elif mode=='SAME-ROW':_need('DUPLICATE_POSITIVE_ROW' in reasons,'same-row capacity refused')
        elif mode=='BAD-CIDS':_need(h['stats']['rejected_packets']>=2 and not h['stats']['valid_packets'],'unknown/internal-coincident members refused')
        elif mode=='EXCLUDED':
            scope_hit=False;current_hit=False
            for record in h['trace']['records']:
                for packet in record['offered']:
                    if type(packet) is not dict:continue
                    errors,_,_=_packet(graph,record['state'],record['row'],packet)
                    refused=any(v['origin']=='CALLBACK' and v['packet_id']==packet['id'] and v['status']=='REJECTED' for v in record['validations'])
                    scope_hit=scope_hit or ('SCOPED_EXCLUSION' in errors and refused)
                    current_hit=current_hit or ('CURRENT_MARK_CONFLICT' in errors and refused)
            _need(scope_hit and current_hit,'actual scoped exclusion and remote current mark refusals')
        elif mode=='OCCUPIED':_need('OCCUPIED_BY_OTHER_MEMBER' in reasons,'occupied different identity refused')
        elif mode in ('MALFORMED','STALE-MODEL','STALE-QUERY','TOO-MANY'):
            _need(h['stats']['preferred_placements']==0 and any(row['response_status'].startswith('REJECTED_') for row in h['trace']['records']),'bad reply exact fallback')
        emit('PROPOSAL-'+mode,{'problem':graph['problem'],'slots':slots,'mode':mode,'run':run});emitted+=1;counts['emit']+=1
    compiled,slots,graph,solutions,_=fixtures['ALIASES']
    for key in ('max_calls','max_packets','max_members','max_records'):
        limits=dict(PROPOSAL_LIMITS);limits[key]=0
        run=_solve(engine,compiled,slots,graph,solutions,core,legacy,meter,'FORBIDDEN',limits);counts['engine_solve']+=1
        _need(run['result']['status']=='SAT' and not run['calls'],'zero heuristic cap gives complete fallback')
        counts['core_selection']+=1
        emit('ZERO-'+key.replace('_','-'),{'problem':graph['problem'],'slots':slots,'proposal_limits':limits,'run':run});emitted+=1;counts['emit']+=1
    stopped=_solve(engine,compiled,slots,graph,solutions,core,legacy,meter,'OWNED-STOP');counts['engine_solve']+=1
    _need(stopped['result']['status']=='UNKNOWN' and stopped['result']['selected'] is None and stopped['result']['certificate'] is None,'owned charged refusal remains UNKNOWN')
    emit('OWNED-CHARGE-STOP',{'problem':graph['problem'],'slots':slots,'run':stopped});emitted+=1;counts['emit']+=1
    caught=False;prefix={}
    try:
        counts['engine_solve']+=1
        _solve(engine,compiled,slots,graph,solutions,core,legacy,meter,'FOREIGN',capture=prefix)
    except ForeignCallbackError:
        caught=True
    _need(caught and legacy._sha(compiled,meter)==prefix['input_sha256'],'foreign callback propagates with immutable inputs; no fabricated postthrow state')
    emit('FOREIGN-CALLBACK',{'exception':'ForeignCallbackError','propagated':caught,'postthrow_result':None,'actual_prefix':prefix,
                             'scope':'No postthrow state receipt; cleanup also covered by Source review.'});emitted+=1;counts['emit']+=1
    _need(emitted==24 and counts['engine_solve']==24 and counts['baseline_solve']==6 and counts['basis_build']==6,'closed call/emit census')
    return {'status':'PASS','version':VERSION,'counts':counts,'emitted':emitted,
            'seconds':time.perf_counter()-meter.start,'scope':SCOPE}
