from pathlib import Path
import ast,hashlib,json,difflib
R=Path('/private/tmp/gcts-conditional-proof-clusters-20261028-v1/root')
old=Path('/private/tmp/gcts-scalable-proof-search-20261028-v1/root/aggregate_proof_point_search_v2.py')
b=old.read_text();assert hashlib.sha256(b.encode()).hexdigest()=='cc2ae5550730fa9c90acc9b8c5657c86da97e9128877f981bf209e87124beb81'
helper=r'''

def _proposal_limits(value):
    defaults=dict(max_calls=128,max_packets=4,max_members=4,max_records=32)
    value=defaults if value is None else value
    _need(type(value)is dict and set(value)==set(defaults),'proposal limits exact4')
    for key,cap in [('max_calls',100000),('max_packets',32),('max_members',64),('max_records',1024)]:
        _need(type(value[key])is int and 0<=value[key]<=cap,'bounded proposal limit')
    return dict(value)

class _Guide:
    """Ordering metadata only. A packet never supplies a domain or a forced move."""
    def __init__(self,m,propose,limits):
        self.m,self.propose,self.limits=m,propose,limits
        self.state=None;self.model_hash=None
        self.stats={k:0 for k in ('calls','offered_packets','valid_packets','rejected_packets',
            'continuation_tests','continuation_uses','preferred_placements','max_covered','limit_skips')}
        self.stats.update(callback_seconds=0.0,validation_seconds=0.0,executed_packet_ids={})
        self.records=[];self.count=0;self.bytes=0;self.digest=hashlib.sha256()
    def charge(self,n=1):
        _need(type(n)is int and 0<=n<=10**12,'public proposal charge')
        self.m.tick(n)
    def public(self,p):
        return None if p is None else {'id':p[0],'members':list(p[1])}
    def normalize(self,p):
        self.m.tick()
        if type(p)is not dict or set(p)!={'id','members'}:return None,'PACKET_FIELDS'
        if type(p['id'])is not str or not 1<=len(p['id'])<=128 or not all(32<=ord(c)<=126 for c in p['id']):return None,'PACKET_ID'
        a=p['members']
        if type(a)is not list or not 1<=len(a)<=self.limits['max_members']:return None,'MEMBER_LIMIT_OR_TYPE'
        if not all(type(x)is str and 1<=len(x)<=128 for x in a):return None,'MEMBER_ID'
        if len(set(a))!=len(a):return None,'DUPLICATE_MEMBER_ID'
        self.m.tick(sum(len(x)for x in a))
        return (p['id'],tuple(a)),None
    def validate(self,p,row=None):
        """Rebuild full packet t/m from the current frozen base model."""
        started=time.perf_counter();s=self.state
        rows={};marks={};shared=[];new=[]
        reason=None
        try:
            for cid in p[1]:
                self.m.tick()
                try:member=s.parse(cid);mm=s.marks(member)
                except (InputError,ValueError,TypeError,OverflowError):
                    reason='MALFORMED_BASE_MEMBER';break
                r=member[0]
                if r in rows:reason='DUPLICATE_POSITIVE_ROW';break
                rows[r]=cid
                if mm is None:reason='INTERNAL_COINCIDENT_MARK_CONFLICT';break
                if s.forbidden(cid,member):reason='SCOPED_EXCLUSION';break
                if s.occupied[r]:
                    if s.selected[r]!=cid:reason='OCCUPIED_BY_OTHER_MEMBER';break
                    shared.append(cid)
                else:new.append(cid)
                for q,f in mm.items():
                    self.m.tick()
                    if not s.compatible(q,f):reason='CURRENT_MARK_CONFLICT';break
                    if q in marks and marks[q]!=f:reason='PACKET_MARK_CONFLICT';break
                    marks[q]=f
                if reason is not None:break
            if reason is None and row is not None and (row not in rows or s.occupied[row]):reason='NOT_INCIDENT_TO_ANCHOR'
            return dict(status='VALID' if reason is None else 'REJECTED',reason=reason,
                        shared_members=shared,new_members=new),rows
        finally:self.stats['validation_seconds']+=time.perf_counter()-started
    def record(self,value):
        value=dict(seq=self.count,**value)
        raw=_wire(value);self.m.tick(len(raw));self.digest.update(raw)
        self.bytes+=len(raw);self.count+=1
        if len(self.records)<self.limits['max_records']:self.records.append(value)
    def choose(self,row,hint):
        s=self.state
        if self.propose is None and hint is None:return s.first(row),None,None
        if hint is None and self.stats['calls']>=self.limits['max_calls']:
            self.stats['limit_skips']+=1
            return s.first(row),None,None
        snapshot=json.loads(_wire(s.snapshot()));self.m.tick(len(_wire(snapshot)))
        core_hash=_hash(s.core());checks=[];offered=[];response_status='NOT_CALLED'
        carried=None
        if hint is not None:
            self.stats['continuation_tests']+=1
            verdict,rows=self.validate(hint)
            checks.append(dict(origin='CONTINUATION',packet_id=hint[0],**verdict))
            if verdict['status']=='VALID' and verdict['new_members']:
                carried=hint
                if row in rows:
                    cid=rows[row];self.stats['continuation_uses']+=1
                    self.record(dict(row=row,required_output=s.summaries[row][2],state=snapshot,
                        core_sha256=core_hash,carried=self.public(hint),offered=offered,
                        response_status=response_status,validations=checks,chosen_packet=hint[0],
                        chosen_candidate=cid,cause='VALIDATED_CONTINUATION'))
                    return cid,hint,hint[0]
        if self.propose is not None and self.stats['calls']<self.limits['max_calls']:
            query=self.stats['calls'];self.stats['calls']+=1
            request=dict(schema='X-cluster-proposal-request-v1',query_id=query,
                model_sha256=self.model_hash,slots=s.n,row=row,required_output=s.summaries[row][2],
                state=json.loads(_wire(snapshot)),limits={k:self.limits[k]for k in ('max_packets','max_members')})
            self.m.tick(len(_wire(request)));entered=time.perf_counter()
            try:reply=self.propose(request,self.charge)
            finally:self.stats['callback_seconds']+=time.perf_counter()-entered
            self.m.tick()
            if type(reply)is not dict or set(reply)!={'model_sha256','query_id','packets'}:response_status='REJECTED_RESPONSE_FIELDS'
            elif type(reply['model_sha256'])is not str or reply['model_sha256']!=self.model_hash:response_status='REJECTED_MODEL_BINDING'
            elif type(reply['query_id'])is not int or reply['query_id']!=query:response_status='REJECTED_QUERY_BINDING'
            elif type(reply['packets'])is not list or len(reply['packets'])>self.limits['max_packets']:response_status='REJECTED_PACKET_LIMIT_OR_TYPE'
            else:
                response_status='COMPLETE_BOUNDED_REPLY';first=None
                for item in reply['packets']:
                    self.stats['offered_packets']+=1
                    packet,error=self.normalize(item)
                    offered.append(self.public(packet))
                    if packet is None:
                        self.stats['rejected_packets']+=1
                        checks.append(dict(origin='CALLBACK',packet_id=None,status='REJECTED',reason=error,shared_members=[],new_members=[]))
                        continue
                    verdict,rows=self.validate(packet,row)
                    checks.append(dict(origin='CALLBACK',packet_id=packet[0],**verdict))
                    if verdict['status']=='VALID':
                        self.stats['valid_packets']+=1
                        if first is None:first=(rows[row],packet)
                    else:self.stats['rejected_packets']+=1
                if first is not None:
                    cid,packet=first
                    self.record(dict(row=row,required_output=s.summaries[row][2],state=snapshot,
                        core_sha256=core_hash,carried=self.public(hint),offered=offered,
                        response_status=response_status,validations=checks,chosen_packet=packet[0],
                        chosen_candidate=cid,cause='VALIDATED_NEW_CLUSTER'))
                    return cid,packet,packet[0]
        else:self.stats['limit_skips']+=1
        cid=s.first(row)
        self.record(dict(row=row,required_output=s.summaries[row][2],state=snapshot,
            core_sha256=core_hash,carried=self.public(hint),offered=offered,
            response_status=response_status,validations=checks,chosen_packet=None,
            chosen_candidate=cid,cause='COMPLETE_LEXICAL_FALLBACK'))
        return cid,carried,None
    def placed(self,packet_id=None):
        self.m.tick(self.state.n+1)
        self.stats['max_covered']=max(self.stats['max_covered'],sum(self.state.occupied))
        if packet_id is not None:
            self.stats['preferred_placements']+=1
            d=self.stats['executed_packet_ids'];d[packet_id]=d.get(packet_id,0)+1
    def result(self):
        return dict(schema='X-validated-cluster-guide-v1',limits=dict(self.limits),
            stats=dict(self.stats,executed_packet_ids=dict(self.stats['executed_packet_ids'])),
            trace=dict(count=self.count,retained=len(self.records),JSONL_bytes=self.bytes,
                       SHA256=self.digest.hexdigest(),records=self.records),
            scope='Ordering-only trusted callback, not a Python sandbox. Complete base graph/degrees and scheduler remain authoritative. '
                  'Every packet rebuilt against current model/t/m and whole positive support; shared selected identity counted once. '
                  'One immutable continuation hint, revalidated and restored with search stack; newer packet may replace it. '
                  'All callback/matching/validation/query/trace costs inside point timer and charged work. '
                  'Bounded optional pool never proves candidate absence. Trace records cover heuristic decisions only; '
                  'budget stop may occur after a decision but before actual placement. executed_packet_ids counts completed preferred placements.')
'''
s=b.replace("VERSION = 'W-AGGREGATE-UNIT-PROOF-POINT-SEARCH-v1'","VERSION = 'X-CLUSTER-GUIDED-UNIT-PROOF-POINT-SEARCH-v1'")
s=s.replace('\ndef solve(compiled, slots, limits, *, observe=None):',helper+'\n\ndef solve(compiled, slots, limits, *, observe=None, propose=None, proposal_limits=None):')
s=s.replace("    _need(observe is None or callable(observe), 'observer callable')","    _need(observe is None or callable(observe), 'observer callable')\n    _need(propose is None or callable(propose), 'proposer callable')\n    guide=_Guide(m,propose,_proposal_limits(proposal_limits));hint=None")
s=s.replace("        state = _State(model, m)\n", "        state = _State(model, m)\n        guide.state=state;guide.model_hash=model_hash\n")
s=s.replace('                target, child, parent_hash = stack.pop()','                target, child, parent_hash, hint = stack.pop()')
s=s.replace("                cid = state.first(forced); state.place(cid)\n", "                cid = state.first(forced); state.place(cid)\n                guide.placed()\n")
s=s.replace('            cid = state.first(row)\n            parent_hash', '            parent_hint=hint\n            cid, hint, preferred_id = guide.choose(row,hint)\n            parent_hash')
s=s.replace("'order': 'COMPLETE_U_LEXICAL_VIRTUAL_MEMBERS'", "'order': 'COMPLETE_U_LEXICAL_VIRTUAL_MEMBERS' if preferred_id is None else 'VALIDATED_CLUSTER_MEMBER_WITH_COMPLETE_BASE_FALLBACK'")
s=s.replace('            stack.append((len(state.trail), cid, parent_hash))','            stack.append((len(state.trail), cid, parent_hash,parent_hint))')
s=s.replace("            state.place(cid)\n            emit('PLACED'", "            state.place(cid)\n            guide.placed(preferred_id)\n            emit('PLACED'")
s=s.replace("return dict(schema='W-aggregate-unit-point-result-v1'", "return dict(schema='X-cluster-guided-unit-point-result-v1'")
s=s.replace("state_hashes=dict(entry=entry_hash, restored=restored_hash), rollback_records=rollbacks,", "state_hashes=dict(entry=entry_hash, restored=restored_hash), rollback_records=rollbacks, heuristic=guide.result(),")
s=s.replace("'No fractional/shared-support/growing geometry, unrestricted FOL, RL or Wang claim. '","'Optional validated cluster ordering, complete native fallback; coarse certified inventory rows need separate primitive proof lowering. '\n              'No fractional/shared-support/growing geometry, unrestricted FOL or literal universal Wang claim. '")
p=R/'cluster_guided_point_search_v1.py';p.open('x').write(s);a=ast.parse(s);compile(s,str(p),'exec')
def ref(p):
 d=p.read_bytes();return dict(path=str(p),bytes=len(d),sha256=hashlib.sha256(d).hexdigest())
patch=R/'W-engine2-to-X-engine1.patch';patch.open('x').write(''.join(difflib.unified_diff(b.splitlines(True),s.splitlines(True),fromfile=str(old),tofile=str(p))))
print(json.dumps({'Source':ref(p),'patch':ref(patch),'inherited_classes':['InputError','_Stop','_Meter','_Group','_State'],'subject_calls':0}))
