from pathlib import Path
import ast,hashlib,json
r=Path('/private/tmp/gcts-conditional-proof-clusters-20261028-v1/root')
w=Path('/private/tmp/gcts-scalable-proof-search-20261028-v1/root/scalable_first_order_study_once_v2.py')
s=w.read_text();a=s.index('def proof_ancestry(');b=s.index('def worker(');c=s.index('def observer(')
header=s[:a];tail=s[c:]
header=header.replace('Closed W scalable worker','Closed X conditional-cluster worker').replace('/private/tmp/gcts-scalable-proof-search-20261028-v1','/private/tmp/gcts-conditional-proof-clusters-20261028-v1')
a=header.index('ROLES = ');b=header.index('\n\n\n',a)
roles=['runner','experiment','compiler','engine','independent','graph_audit','xqualifier','xengine','inventory','bank_verifier','policy','tree_machine','codec','carrier','fol_checker','real_parser']
header=header[:a]+'ROLES = '+repr(set(roles))+header[b:]
header=header.replace('W-scalable-first-order-proof-once-authority-v1','X-conditional-cluster-proof-once-authority-v1').replace('W-scalable-first-order-proof-once-plan-v1','X-conditional-cluster-proof-once-plan-v1').replace("'study-002'","'study-001'")
header=header.replace("'worker_seconds': 360, 'observer_seconds': 390","'worker_seconds': 1200, 'observer_seconds': 1230").replace("'total_bytes': 536870912, 'max_files': 384","'total_bytes': 1073741824, 'max_files': 768")
tail=tail.replace('>= 390','>= 1230').replace('total <= 536870912','total <= 1073741824').replace('len(files) <= 383','len(files) <= 767').replace('W-owned-scalable-first-order-observer-result-v1','X-owned-conditional-cluster-observer-result-v1').replace('with390s','with1230s')
worker='''def worker(plan_path):
    started = time.perf_counter()
    plan, plan_raw, sources, metadata = load_plan(plan_path)
    directory = Path(plan['actual_dir'])
    marker_path = directory / 'CONSUMED.json'
    marker_raw = marker_path.read_bytes()
    marker = json.loads(marker_raw)
    authority_raw = read_ref(marker['authority'])
    check_authority(authority_raw, plan_path, plan_raw, plan)
    consume_raw = read_ref(marker['consumed'])
    require(json.loads(consume_raw) == {'authority': marker['authority'],
            'plan': raw_ref(plan_path, plan_raw), 'status': 'SPENT'}, 'worker once joins')
    artifacts, total_bytes, calls = [], 0, {}

    def budget():
        require(time.perf_counter() - started < 1200, 'whole worker sampled wall')
        require(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss <= 1073741824,
                'whole worker sampled RSS bytes on Darwin')

    def emit(name, data):
        nonlocal total_bytes
        budget()
        require(type(name) is str and name and name.isascii()
                and all(c.isalnum() or c in '-.' for c in name), 'artifact name')
        require(len(artifacts) < 760, 'artifact count')
        raw = raw_json(data)
        require(len(raw) <= 67108864, 'full artifact raw cap')
        compressed = len(raw) > 65536
        stored = gzip.compress(raw, mtime=0) if compressed else raw
        total_bytes += len(stored)
        require(len(stored) <= 67108864 and total_bytes <= 1040187392,
                'whole artifact stored cap')
        ref = put(directory / (name + ('.json.gz' if compressed else '.json')), stored)
        require((gzip.decompress(stored) if compressed else stored) == raw,
                'lossless complete artifact')
        answer = {'name': name, 'stored': ref, 'encoding': 'gzip-json' if compressed else 'json',
                  'raw_bytes': len(raw), 'raw_sha256': hashlib.sha256(raw).hexdigest()}
        artifacts.append(answer)
        return answer

    donor_manifest = json.loads(metadata['donor_manifest'])
    require(donor_manifest['schema'] == 'X-six-original-W-donor-raw-source-manifest-v1'
            and type(donor_manifest['donors']) is list and len(donor_manifest['donors']) == 6,
            'closed six-donor raw manifest')
    donor_stored, donor_refs = {}, {}
    donor_total = 0
    for row in donor_manifest['donors']:
        budget()
        require(type(row['id']) is str and row['id'] not in donor_stored, 'unique donor identity')
        require(type(row['uncompressed_bytes']) is int and 0 < row['uncompressed_bytes'] <= 67108864,
                'donor decoded extent')
        raw = read_ref(row['source_ref'], 67108864)
        donor_total += len(raw)
        require(donor_total <= 67108864, 'six-donor aggregate compressed bound')
        donor_stored[row['id']] = raw
        donor_refs[row['id']] = row['source_ref']
    modules = {}
    for role in sorted(ROLES - {'runner', 'real_parser'}):
        budget()
        module = types.ModuleType('X_' + role)
        module.__file__ = plan['sources'][role]['path']
        exec(compile(sources[role], module.__file__, 'exec', dont_inherit=True), module.__dict__)
        modules[role] = module

    def call(role, name, *args, **kwargs):
        budget()
        key = role + '.' + name
        calls[key] = calls.get(key, 0) + 1
        require(calls[key] <= 512, 'public outer entry cap')
        value = getattr(modules[role], name)(*args, **kwargs)
        budget()
        return value

    context = {'plan': plan, 'sources': sources, 'metadata': metadata, 'donor_stored': donor_stored}
    experiment = call('experiment', 'run', modules, context, emit, budget, call)
    require(type(experiment) is dict and experiment.get('status') == 'COMPLETE',
            'complete closed experiment')
    result = {'schema': 'X-conditional-cluster-proof-search-study-v1', 'status': 'COMPLETE',
              'experiment': experiment, 'outer_public_calls': dict(calls), 'artifacts': list(artifacts),
              'scope': 'Complete bounded conditional-cluster cohort. Exact stored sources/data and six original donors authenticated. '
                       'One owned child with complete output capture and mandatory wait/group/EOF confirmation. '
                       'No scientific result is admitted merely by this custody envelope; independent saved-data review remains required.'}
    result_ref = emit('worker-result', result)
    for role, ref in plan['sources'].items():
        require(read_ref(ref) == sources[role], 'post Source guard')
    for role, ref in plan['metadata'].items():
        require(read_ref(ref) == metadata[role], 'post data guard')
    for name, ref in donor_refs.items():
        require(read_ref(ref, 67108864) == donor_stored[name], 'post original donor guard')
    read_ref(plan['python'], 33554432); read_ref(plan['bootstrap'])
    require(Path(plan_path).read_bytes() == plan_raw, 'post plan guard')
    require(marker_path.read_bytes() == marker_raw, 'post marker guard')
    require(read_ref(marker['authority']) == authority_raw, 'post authority guard')
    require(read_ref(marker['consumed']) == consume_raw, 'post consumed guard')
    budget()
    sys.stdout.buffer.write(raw_json({'status': 'COMPLETE', 'result': result_ref,
        'plan': raw_ref(plan_path, plan_raw), 'public_calls': calls,
        'elapsed_seconds': time.perf_counter() - started,
        'self_lifetime_peak_bytes': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}))
    sys.stdout.buffer.flush()
    return 0


'''
s=header+worker+tail;p=r/'conditional_cluster_study_once_v1.py';assert not p.exists();p.write_text(s)
t=ast.parse(s);compile(t,str(p),'exec')
def ref(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
a=dict(schema='X-owned-worker-observer-complete-public-ABI-v1',Source=ref(p),predecessor=ref(w),roles=sorted(roles),entry='main --mode observer --plan exact-absolute-plan --authority fresh exact A6; retained Source through authenticated bootstrap stdin; child main --mode worker --plan same',plan_exact7=['schema','sources','metadata','python','bootstrap','actual_dir','limits'],plan_schema='X-conditional-cluster-proof-once-plan-v1',authority_schema='X-conditional-cluster-proof-once-authority-v1',actual_dir='/private/tmp/gcts-conditional-proof-clusters-20261028-v1/actual/study-001',limits=dict(worker_seconds=1200,observer_seconds=1230,rss_bytes=1073741824,file_bytes=67108864,total_bytes=1073741824,max_files=768,stream_bytes=1048576),donor='Read six exact source_refs from metadata.donor_manifest explicitly <=64MiB each/aggregate stored<=64MiB, retain compressed bytes by donorID, postguard all six. Experiment verifies decompressed pins and complete historical custody before acquisition. No historical authority/memo reused.',experiment='Only call experiment.run(modules, context, emit, budget, call); context exact4 plan/sources/metadata/donor_stored; every role except runner/real_parser loaded from retained bytes with true Source.__file__. Experiment is itself module. Return dictstatusCOMPLETE wrapped in worker-result schema X-conditional-cluster-proof-search-study-v1.',emit='Same W descriptor5 name/stored/encoding/raw_bytes/raw_sha256; max760 emits, raw/stored perfile64MiB, total stored<=1GiB-32MiB. Lossless gzip if raw>65536, exclusive write/readback/fsync. Worker result list covers preceding artifacts; outer supervisor retains full final inventory.',call='call(role,name,*args,**kwargs) budget before/after, counted role.name cap512 each; injected lower-level calls explicitly enumerated in experiment/qualifier API. No project functions invoked at authoring.',ownership='Reuses complete W supervisor: nonblocking retained Source stdin, both output capture/EOF, wait4 lifetimeDarwinRSS, no blockingwait, ownedprocessgroup kill/check, observer1230s +5s cleanup, failclosed on streamcap/stderr/nonzero/unconfirmed. Full source/data/python/bootstrap/plan/authority/spent/marker postguards. Explicitly cooperative sampled quotas; OS spawn/readback tail excluded from hard wall.',subject_calls=0,execution_authority=False,static=dict(lines=len(s.splitlines()),named_units=len([n for n in ast.walk(t)if isinstance(n,(ast.FunctionDef,ast.ClassDef))]),unused_compile='discarded without evaluation'))
ap=r/'X-owned-worker-observer-complete-public-ABI-v1.json';ap.write_text(json.dumps(a,indent=2,sort_keys=True)+'\n');print(json.dumps(dict(Source=ref(p),API=ref(ap),static=a['static']),indent=2))
