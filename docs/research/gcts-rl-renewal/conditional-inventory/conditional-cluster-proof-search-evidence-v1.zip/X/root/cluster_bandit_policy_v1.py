"""Small episodic contextual-bandit pilot for learned proof-cluster ordering.

Pure data and injected matcher calls only. No project imports, IO or fixtures.
A new planner per engine call prepares its matcher lazily under engine charge.
Weights are frozen inside a solve and updated only between verified episodes.
"""
import hashlib
import json
import math
import random
import time

VERSION='X-CLUSTER-EPISODIC-BANDIT-v1'
TAGS={'all','eq','pred','imp','and','or','not','bot','missing'}

class InputError(ValueError):pass
class _Budget(Exception):pass

def _need(ok,reason):
    if not ok:raise InputError(reason)

def _wire(x):
    return (json.dumps(x,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')

def _sha(x):return hashlib.sha256(_wire(x)).hexdigest()

class _Meter:
    def __init__(self,limits,charge=None):
        _need(type(limits)is dict and set(limits)=={'wall_seconds','max_work','max_depth'},'policy limits exact3')
        _need(type(limits['wall_seconds'])in(int,float) and math.isfinite(limits['wall_seconds']) and 0<limits['wall_seconds']<=60,'wall')
        _need(type(limits['max_work'])is int and 0<=limits['max_work']<=1000000000 and type(limits['max_depth'])is int and 0<=limits['max_depth']<=128,'work/depth')
        _need(charge is None or callable(charge),'charge')
        self.limits=dict(limits);self.charge=charge;self.start=time.perf_counter();self.work=0
    def tick(self,n=1):
        _need(type(n)is int and n>=0,'own work increment')
        if n>self.limits['max_work']-self.work:raise _Budget('WORK')
        if self.charge is not None:self.charge(n)
        self.work+=n
        if time.perf_counter()-self.start>self.limits['wall_seconds']:raise _Budget('WALL')
    def costs(self):return dict(work=self.work,seconds=time.perf_counter()-self.start,scope='Own validation/copy/ranking/bookkeeping included; injected matcher costs separate and charged to same engine. Caller/module/serialization tail separate; cooperative limits.')

def _copy(x,m,depth=0):
    m.tick()
    if depth>m.limits['max_depth']:raise _Budget('DEPTH')
    if x is None or type(x)in(bool,int):return x
    if type(x)is float:_need(math.isfinite(x),'finite');return x
    if type(x)is str:m.tick(len(x));return x
    if type(x)is list:m.tick(len(x));return [_copy(v,m,depth+1)for v in x]
    _need(type(x)is dict and all(type(k)is str for k in x),'native JSON')
    m.tick(len(x));return {k:_copy(v,m,depth+1)for k,v in x.items()}

def _patterns(p,m):
    _need(type(p)is dict and set(p)=={'schema','version','patterns','pattern_sha256'},'patterns exact4')
    _need(p['schema']=='X-donor-DAG-patterns-v1' and p['version']=='X-CERTIFIED-LEMMA-PATTERNS-v1','pattern identity')
    _need(type(p['patterns'])is list and len(p['patterns'])<=10000,'pattern count')
    m.tick(len(_wire(p)))
    _need(p['pattern_sha256']==_sha({k:p[k]for k in ('schema','version','patterns')}),'pattern digest')
    ids=[r['id']for r in p['patterns']]
    _need(all(type(s)is str and len(s)==64 and all(c in '0123456789abcdef'for c in s)for s in ids),'pattern IDs')
    _need(ids==sorted(set(ids)),'canonical distinct arms')
    return ids

def _state(s,m,arms=None,pattern_sha=None):
    _need(type(s)is dict and set(s)=={'schema','pattern_sha256','arm_ids','values','counts','episodes'},'policy state exact6')
    _need(s['schema']=='X-episodic-cluster-bandit-state-v1','policy identity')
    a=s['arm_ids'];_need(type(a)is list and a==sorted(set(a)) and all(type(k)is str for k in a),'arms')
    if arms is not None:_need(a==arms and s['pattern_sha256']==pattern_sha,'frozen learned pattern bank')
    _need(type(s['values'])is type(s['counts'])is dict and set(s['values'])==set(s['counts']),'context values/counts')
    for ctx,vals in s['values'].items():
        m.tick();_need(ctx in TAGS and type(vals)is dict and type(s['counts'][ctx])is dict and set(vals)==set(s['counts'][ctx]),'context')
        for arm,v in vals.items():
            m.tick();c=s['counts'][ctx][arm]
            _need(arm in a and type(v)in(int,float) and math.isfinite(v) and type(c)is int and c>0,'mean/count')
    _need(type(s['episodes'])is list and len(s['episodes'])<=10000,'episode log cap')
    return _copy(s,m)

def _receipt(status,reason,value,m):
    return dict(schema='X-bandit-policy-result-v1',status=status,reason=reason,value=value,costs=m.costs())

def initial_state(patterns,limits):
    m=_Meter(limits)
    try:
        a=_patterns(patterns,m)
        value=dict(schema='X-episodic-cluster-bandit-state-v1',pattern_sha256=patterns['pattern_sha256'],arm_ids=list(a),values={},counts={},episodes=[])
        return _receipt('COMPLETE',None,value,m)
    except _Budget as e:return _receipt('UNKNOWN',str(e),None,m)

class _Planner:
    def __init__(self,compiled,slots,patterns,inventory,state,mode,seed,config):
        self.compiled=compiled;self.slots=slots;self.patterns=patterns;self.inventory=inventory
        self.state_input=state;self.mode=mode;self.seed=seed;self.config=config
        self.state=None;self.arms=None;self.rng=None;self.prepared=None;self.prepare_attempted=False
        self.preparation=None;self.model_sha=None;self.policy_sha=None;self.packet_bindings={};self.trace=[]
        self.stats=dict(queries=0,prepare_calls=0,propose_calls=0,unknowns=0,matcher_work=0,matcher_seconds=0.0,policy_work=0,policy_seconds=0.0,exploratory_queries=0)
    def __call__(self,request,charge):
        m=_Meter(self.config['policy'],charge)
        try:
            _need(type(request)is dict and set(request)=={'schema','query_id','model_sha256','slots','row','required_output','state','limits'},'engine request exact8')
            _need(request['schema']=='X-cluster-proposal-request-v1' and request['slots']==self.slots,'request slots')
            self.stats['queries']+=1
            if self.state is None:
                self.arms=_patterns(self.patterns,m);self.state=_state(self.state_input,m,self.arms,self.patterns['pattern_sha256'])
                self.policy_sha=_sha(self.state);self.rng=random.Random(self.seed)
            if not self.prepare_attempted:
                self.prepare_attempted=True;self.stats['prepare_calls']+=1
                self.prepared,self.preparation=self.inventory.prepare_matcher(self.compiled,self.slots,self.patterns,self.config['prepare'],charge=charge)
                self.stats['matcher_work']+=self.preparation['costs']['work'];self.stats['matcher_seconds']+=self.preparation['costs']['seconds']
                if self.preparation['status']=='UNKNOWN':self.stats['unknowns']+=1
                else:_need(self.preparation['status']=='COMPLETE' and self.prepared is not None,'matcher prepared')
            if self.prepared is None:return dict(model_sha256=request['model_sha256'],query_id=request['query_id'],packets=[])
            _need(self.prepared.model_sha256==request['model_sha256'],'current compiled model binding')
            self.model_sha=self.prepared.model_sha256
            fid=request['required_output']
            if fid is None:ctx='missing'
            else:
                _need(type(fid)is int and 0<=fid<len(self.compiled['logical_basis']['formulas']),'output FID')
                ctx=self.compiled['logical_basis']['formulas'][fid][0]
                _need(ctx in TAGS,'formula root context')
            order=list(self.arms);m.tick(len(order));self.rng.shuffle(order)
            explore=self.mode=='uniform' or (self.mode=='train' and self.rng.random()<self.config['epsilon'])
            if explore:self.stats['exploratory_queries']+=1
            else:
                vals=self.state['values'].get(ctx,{})
                m.tick(len(order)*max(1,len(order).bit_length()));order.sort(key=lambda arm:vals.get(arm,0.0),reverse=True)
            self.stats['propose_calls']+=1
            result=self.inventory.propose_clusters(self.prepared,{'row':request['row'],'state':request['state']},order,self.config['match'],charge=charge)
            self.stats['matcher_work']+=result['costs']['work'];self.stats['matcher_seconds']+=result['costs']['seconds']
            packets=[]
            if result['status']=='UNKNOWN':self.stats['unknowns']+=1
            else:
                _need(result['status']=='COMPLETE','matcher result')
                packets=result['value']['packets']
                _need(len(packets)<=request['limits']['max_packets'],'matcher agrees engine packet cap')
                for rec in result['value']['records']:
                    m.tick();_need(rec['pattern_id']in self.arms,'known proposed arm')
                    binding=dict(pattern_id=rec['pattern_id'],context=ctx)
                    if rec['id']in self.packet_bindings:_need(self.packet_bindings[rec['id']]==binding,'packet credit binding')
                    else:self.packet_bindings[rec['id']]=binding
            if len(self.trace)<self.config['max_records']:
                self.trace.append(dict(query_id=request['query_id'],context=ctx,order=list(order),exploratory=explore,matcher=_copy(result,m)))
            return dict(model_sha256=request['model_sha256'],query_id=request['query_id'],packets=packets)
        except _Budget:
            self.stats['unknowns']+=1
            return dict(model_sha256=request['model_sha256'],query_id=request['query_id'],packets=[])
        finally:
            self.stats['policy_work']+=m.work;self.stats['policy_seconds']+=time.perf_counter()-m.start
    def summary(self):
        return dict(schema='X-cluster-bandit-proposer-summary-v1',mode=self.mode,seed=self.seed,
            policy_sha256=self.policy_sha or _sha(self.state_input),pattern_sha256=self.patterns['pattern_sha256'],
            model_sha256=self.model_sha,preparation=self.preparation,stats=dict(self.stats),
            packet_bindings=json.loads(_wire(self.packet_bindings)),trace=json.loads(_wire(self.trace)),
            scope='One per-solve trusted planner. Cold matcher preparation inside engine charge. Policy frozen at first query; changes only between episodes. '
                  'Pattern-bank arms only, finite pilot not unrestricted cluster invention/neural RL. Root tag is only context, no theorem/answer labels. '
                  'Actual engine completed preferred-base-placement counters supply credit; proposed or rejected packets alone receive no credit. '
                  'Full bounded matcher receipts retained for first max_records calls; all execution packet bindings retained.')

def make_proposer(compiled,slots,patterns,inventory,state,mode,seed,config):
    """O(1) references; all pattern/index/state validation lazily charged inside engine."""
    _need(type(config)is dict and set(config)=={'policy','prepare','match','epsilon','max_records'},'planner config exact5')
    m=_Meter(config['policy'])
    try:
        _need(type(slots)is int and 1<=slots<=64 and mode in ('uniform','train','trained'),'planner slots/mode')
        _need(type(seed)is int and 0<=seed<2**63,'seed')
        _need(type(config['epsilon'])in(int,float) and math.isfinite(config['epsilon']) and 0<=config['epsilon']<=1,'epsilon')
        _need(type(config['max_records'])is int and 0<=config['max_records']<=128,'trace cap')
        cfg=_copy(config,m)
        value=_Planner(compiled,slots,patterns,inventory,state,mode,seed,cfg)
        return value,_receipt('COMPLETE',None,{'lazy':True},m)
    except _Budget as e:return None,_receipt('UNKNOWN',str(e),None,m)

def summarize(proposer):
    _need(type(proposer)is _Planner,'owned planner')
    return proposer.summary()

def update_policy(state,episode_id,engine_result,summary,verified,limits):
    """Empirical mean reward per actually executed base-placement arm, between solves."""
    m=_Meter(limits)
    try:
        q=_state(state,m)
        _need(type(episode_id)is str and 1<=len(episode_id)<=128,'episode ID')
        _need(type(verified)is bool,'verification flag')
        _need(summary['mode']=='train' and summary['policy_sha256']==_sha(state) and summary['pattern_sha256']==state['pattern_sha256'],'frozen episode policy')
        _need(engine_result['schema']=='X-cluster-guided-unit-point-result-v1' and engine_result['status']in('SAT','UNSAT','UNKNOWN'),'actual engine result')
        if engine_result['status']=='SAT':_need(verified,'SAT reward requires coarse and original native checks')
        else:_need(not verified,'nonproof cannot verified')
        n=engine_result['model']['slots'];h=engine_result['heuristic']['stats'];base=engine_result['stats']
        _need(type(n)is int and 1<=n<=64 and type(h['max_covered'])is int and 0<=h['max_covered']<=n,'actual covered roots')
        _need(type(base['nodes'])is int and base['nodes']>=0,'actual nodes')
        covered=h['max_covered'];cost=h['callback_seconds']+h['validation_seconds']
        elapsed=base['elapsed_seconds'];_need(type(elapsed)in(int,float) and elapsed>=0 and math.isfinite(elapsed),'point seconds')
        reward=covered/n+float(verified)-min(1.0,base['nodes']/1000.0)-min(1.0,cost/max(elapsed,1e-9))
        credits={}
        for pid,count in h['executed_packet_ids'].items():
            m.tick();_need(type(count)is int and count>0 and pid in summary['packet_bindings'],'actual executed packet')
            b=summary['packet_bindings'][pid];ctx,arm=b['context'],b['pattern_id']
            _need(ctx in TAGS and arm in q['arm_ids'],'credit arm/context')
            credits[(ctx,arm)]=credits.get((ctx,arm),0)+count
        changes=[]
        for (ctx,arm),count in sorted(credits.items()):
            m.tick();v=q['values'].setdefault(ctx,{});c=q['counts'].setdefault(ctx,{})
            old=v.get(arm,0.0);oldc=c.get(arm,0);new=(old*oldc+reward*count)/(oldc+count)
            v[arm]=new;c[arm]=oldc+count
            changes.append(dict(context=ctx,pattern_id=arm,base_placements=count,old_count=oldc,new_count=oldc+count,old_value=old,new_value=new))
        episode=dict(id=episode_id,status=engine_result['status'],verified=verified,covered_roots=covered,slots=n,
            nodes=base['nodes'],guidance_seconds=cost,point_seconds=elapsed,reward=reward,updates=changes)
        _need(len(q['episodes'])<10000,'episode cap');q['episodes'].append(episode)
        changed=any(r['old_value']!=r['new_value']for r in changes)
        return _receipt('COMPLETE',None,dict(state=q,episode=episode,changed_estimates=changed),m)
    except _Budget as e:return _receipt('UNKNOWN',str(e),None,m)
