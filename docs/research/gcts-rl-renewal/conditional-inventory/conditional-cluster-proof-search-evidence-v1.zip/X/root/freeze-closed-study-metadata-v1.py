from pathlib import Path
import json,hashlib,ast,math
R=Path('/private/tmp/gcts-conditional-proof-clusters-20261028-v1');W=Path('/private/tmp/gcts-scalable-proof-search-20261028-v1')
def ref(p):
 p=Path(p);assert p.is_absolute()and p.is_file()and not p.is_symlink();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def put(name,x):
 p=R/'root'/name;assert not p.exists();p.write_text(json.dumps(x,indent=2,sort_keys=True,allow_nan=False)+'\n');return ref(p)
def strict(x):
 if x is None or type(x)in(bool,str):return
 if type(x)is int:assert x.bit_length()<=256;return
 if type(x)is float:assert math.isfinite(x);return
 if type(x)is list:
  for v in x:strict(v)
  return
 assert type(x)is dict and all(type(k)is str for k in x)
 for v in x.values():strict(v)
old=json.loads((W/'root/study-once-plan-002.json').read_bytes())
reuse=('compiler','engine','independent','graph_audit','tree_machine','codec','carrier','fol_checker','real_parser')
sources={k:old['sources'][k]for k in reuse}
new={
'runner':('root/conditional_cluster_study_once_v1.py','36be77d1a0c7904b82c3f68110bd058280979dd737620d335c40bbd788ee4919'),
'experiment':('implementation-C/conditional_cluster_experiment_v2.py','21048c79c6d1125017b475361b0639c909d0abe8be910befc06ba8a1ca78d094'),
'xengine':('root/cluster_guided_point_search_v4.py','7b7125af8487ea1fe3ff95a945e86b7027a989fbab4df2ff010a6deb6012b4ad'),
'xqualifier':('implementation-L/cluster_guidance_qualification_v3.py','4eb14f49230b71bd45559cd8531c1060a686600367903d5a0ba087a2912ec69b'),
'inventory':('implementation-B/certified_lemma_patterns_v2.py','5f9c82c6ce3c8d492d598030cbe6705928a7c996781ee232d083589318dfcf0b'),
'bank_verifier':('implementation-L/lemma_bank_verifier_v1.py','0882bd40237f425768fc6ee86b417c7bd273f40f39c366caae3efc82e6c9dc9f'),
'policy':('root/cluster_bandit_policy_v4.py','40b207f244120a7fec02efd1c0fda2d82e91865bd0c90f577d0d931aecb6f6d9')}
for k,(p,h)in new.items():
 rr=ref(R/p);assert rr['sha256']==h;sources[k]=rr
assert len(sources)==16
for k,v in sources.items():
 assert ref(v['path'])==v and v['bytes']<=1048576
 if k!='real_parser':compile(ast.parse(Path(v['path']).read_bytes()),v['path'],'exec')
assert ref(old['python']['path'])==old['python']and ref(old['bootstrap']['path'])==old['bootstrap']
peer_paths={
'engine_peer':R/'implementation-C/X-cluster-engine-Source4-focused-independent-peer-v1.json',
'engine_inherited_peer':R/'implementation-C/X-cluster-engine-complete-independent-Source-peer-v1.json',
'bank_verifier_peer':R/'implementation-C/X-lemma-bank-verifier-complete-independent-Source-peer-v1.json',
'policy_peer':Path('/private/tmp/gcts-B-X-policy-Source-peer-v1/X-cluster-bandit-policy4-complete-independent-Source-peer-review-v1.json'),
'wrapper_peer':Path('/private/tmp/gcts-B-X-owned-wrapper-Source-peer-v1/X-owned-wrapper-complete-independent-Source-peer-review-v1.json'),
'qualifier_peer':Path('/private/tmp/gcts-B-X-guidance-qualification-Source-peer-v1/X-guidance-qualification3-complete-inherited-focused-Source-peer-review-v1.json'),
'qualifier_inherited_peer':Path('/private/tmp/gcts-B-X-guidance-qualification-Source-peer-v1/X-guidance-qualification2-complete-independent-Source-peer-review-v1.json'),
'inventory_peer':Path('/private/tmp/gcts-L-X-inventory-Source-peer-v1/X-inventory-Source2-complete-inherited-independent-Source-peer-review-v1.json'),
'inventory_inherited_peer':Path('/private/tmp/gcts-L-X-inventory-Source-peer-v1/X-inventory-Source1-complete-independent-Source-peer-review-v1.json'),
'experiment_peer':Path('/private/tmp/gcts-L-X-experiment-Source-peer-v1/X-experiment-Source2-complete-inherited-independent-Source-peer-review-v1.json'),
'experiment_inherited_peer':Path('/private/tmp/gcts-L-X-experiment-Source-peer-v1/X-experiment-Source1-complete-independent-Source-peer-review-v1.json')}
peers={k:ref(v)for k,v in peer_paths.items()}
apis={
'caller_ABI':R/'root/X-owned-worker-observer-complete-public-ABI-v1.json',
'experiment_ABI':R/'implementation-C/X-conditional-cluster-experiment-complete-public-ABI-v2.json',
'engine_ABI':R/'root/X-cluster-engine-complete-public-ABI-v3.json',
'policy_ABI':R/'root/X-cluster-bandit-complete-public-ABI-v3.json',
'qualifier_ABI':R/'implementation-L/X-independent-cluster-guidance-qualification-complete-public-ABI-v3.json',
'inventory_ABI':R/'implementation-B/X-lemma-pattern-complete-effective-public-ABI-v2.json',
'bank_verifier_ABI':R/'implementation-L/X-independent-lemma-bank-verifier-complete-public-ABI-v1.json'}
api_refs={k:ref(v)for k,v in apis.items()}
join=put('Root-experiment2-current-qualifier3-caller-join-v1.json',dict(schema='X-Root-experiment2-current-qualifier3-caller-join-v1',experiment=sources['experiment'],qualifier=sources['xqualifier'],qualifier_ABI=api_refs['qualifier_ABI'],qualifier_peer=peers['qualifier_peer'],join='Experiment2 run only calls qualify(basis,engine,baseline,core,legacy,emit), checks PASS/24records/23native and never hardcodes qualifierVERSION or Source2. Qualifier3 changes only its controlled BAD-FIRST callback plus VERSION, preserving exact entry/all control rows/caps/census. Experiment2 historical public_refs list qualifier2; this exact current operational join and plan supersede that reference, without modifying any target path. Source graph/primitive validity and costs unchanged.',subject_calls=0,execution_authority=False))
adoption=put('Root-complete-conditional-cluster-Source-adoption-v1.json',dict(schema='X-Root-complete-conditional-cluster-Source-adoption-v1',status='ADOPTED_COMPLETE_CURRENT_SOURCE_ONLY_READY_FOR_FRESH_CLOSED_ONCE',sources=sources,public_ABIs=api_refs,independent_peers=peers,caller_join=join,inherited_complete_reused_Source_adoption=old['metadata']['Root_adoption'],master=old['metadata']['master'],Root_intake='All7new/changed component bodies read completely or inherited full current body+exact whole inverse/changed-unit review. Whole experiment2/qualifier3/bankverifier/inventory2/policy4/engine4/ownedwrapper1, all public APIs and all current complete/focused independent peers read. Reused9Source exact pins inherit admitted complete W Source intake; shared master reread in full this turn. All AST compile objects discarded unevaluated. No X subject calls yet.',scope='Finite coarse unit/root0 proof-row adaptation only. Same closed certified inventory/compiled universe/profile/coarse bound for four lanes; proof validity actual coarse+lowered original C1+B. Complete base graph/globaldead/forced/generation then tie scheduler, ordinary cluster constituent placement and exact rollback. Optional learned ordering never prunes. All incomplete outcomes retained. No unrestricted proof/Wang/PA/Hilbert/tiling, novelty or advantage claim from Source adoption.',subjects_UNRUN=True,prior_grants='All historical grants SPENT and never reused. Fresh authority only after exact typed plan/current pins preflight.',execution_authority=False))
metadata={k:ref(v)for k,v in apis.items()};metadata.update(peers)
for k in ('compiler_ABI','compiler_full_ABI','compiler_equivalence','compiler_source_peer','independent_ABI','independent_reuse_ABI','independent_source_peer','native_recipe','bridge_admission','bridge_result','bridge_peer','bridge_observer','qualifier_ABI','qualifier_Source2_peer','qualifier_source_peer','engine_ABI','engine_source_peer','engine_literal_supplement'):
 metadata['reused_'+k]=old['metadata'][k]
metadata.update(Root_adoption=adoption,caller_current_join=join,master=old['metadata']['master'],prior_Root_adoption=old['metadata']['Root_adoption'])
for k,p in {
'cases':R/'implementation-C/X-prospective-assertion-only-cases-v2.json',
'design':R/'implementation-C/X-prospective-conditional-cluster-benchmark-design-v2.json',
'experiment_limits':R/'root/prospective-conditional-cluster-experiment-limits-v1.json',
'donor_manifest':R/'root/X-six-original-W-donor-raw-source-manifest-v1.json',
'donor_admission':R/'root/X-six-W-donor-passive-custody-v1.json',
'donor_passive_support':R/'root/X-six-historical-donor-saved-custody-admission-v1.json',
'W_donor_original_admission':W/'root/Root-study002-complete-scientific-admission-v1.json',
'W_donor_original_observer':W/'actual/study-002/observer-result.json'}.items():metadata[k]=ref(p)
for v in metadata.values():assert v['bytes']<=1048576 and ref(v['path'])==v;strict(json.loads(Path(v['path']).read_bytes()))
plan=dict(schema='X-conditional-cluster-proof-once-plan-v1',sources=sources,metadata=metadata,python=old['python'],bootstrap=old['bootstrap'],actual_dir=str(R/'actual/study-001'),limits=dict(worker_seconds=1200,observer_seconds=1230,rss_bytes=1073741824,file_bytes=67108864,total_bytes=1073741824,max_files=768,stream_bytes=1048576))
strict(plan);assert not Path(plan['actual_dir']).exists();pr=put('study-once-plan-001.json',plan)
print(json.dumps(dict(adoption=adoption,caller_join=join,plan=pr,Source_roles=len(sources),metadata_roles=len(metadata),subjects_run=0),indent=2))
