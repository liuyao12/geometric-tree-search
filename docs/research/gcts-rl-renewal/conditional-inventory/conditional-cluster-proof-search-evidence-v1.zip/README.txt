Conditional proof clusters — prepublication evidence cut

This archive contains all 164 physical originals of the sole X study001, the current 16-Source closure and 48 retained metadata inputs, six original compressed W donor certificates, immutable Source revisions, current independent Source and saved-data reviews, the report and local browser checks. MANIFEST.json maps every stored member to its original absolute path, exact byte count and SHA-256.

The Python runtime binary is not duplicated; its exact path, byte length and SHA-256 are in the closed plan. Indirect historical runs are not recursively duplicated. The earlier full W archive is available at https://liuyao12.github.io/geometric-tree-search/docs/research/gcts-rl-renewal/conditional-inventory/scalable-first-order-proof-search-evidence-v1.zip . Current inputs and direct Source dependencies are included here.

Main base events, guide bodies and policy bodies have explicit retained-prefix caps. Complete recorded artifacts are preserved; unrecorded suffix bodies are not reconstructed. Authored regression proofs are separate from automatically searched target proofs. One distinct held-out typing statement succeeded in all four lanes; numerical RL weights did not change. See the report for finite-model and cost limitations.

This is a prepublication science evidence cut. Publication, normal-TLS download and final live-browser receipts necessarily follow this immutable ZIP and are retained separately in the task's durable research folder. The broader research goal remains active.

The user explicitly approved publishing the full archive, including Sources, raw proof certificates, execution logs and provenance paths, to the existing public GitHub Pages destination on 2026-10-28.
