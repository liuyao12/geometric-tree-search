"""One-case administrative saved-record joins only; no project imports/calls."""
from pathlib import Path
import json,gzip,hashlib,math,collections
X=Path('/private/tmp/gcts-conditional-proof-clusters-20261028-v1');A=X/'actual/study-001';O=Path('/private/tmp/gcts-B-X-study001-saved-review-v1')
def pairs(rows):
 d={}
 for k,v in rows:
  assert k not in d,('duplicate key',k)
  d[k]=v
 return d
def parse(b):return json.loads(b,object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in()).throw(AssertionError(x)))
def wire(v):return (json.dumps(v,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')
def sha(b):return hashlib.sha256(b).hexdigest()
def ref(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def readref(r):
 assert type(r)is dict and set(r)=={'path','bytes','sha256'} and type(r['path'])is str and type(r['bytes'])is int and r['bytes']>=0 and type(r['sha256'])is str and len(r['sha256'])==64
 p=Path(r['path']);assert p.is_absolute()and p.is_file()and not p.is_symlink();b=p.read_bytes();assert ref(p)==r;return b
outerp=X/'root/study-001-original-outer-exit.json';outer=parse(outerp.read_bytes());obs=parse(readref(outer['terminal_output']['receipt']));planp=X/'root/study-once-plan-001.json';plan=parse(planp.read_bytes())
assert outer['exit_code']==0 and outer['initial_chunk']=='e6bffd'and outer['terminal_chunk']=='28356d'and outer['session_id']==95967
assert obs['status']=='COMPLETE'and obs['returncode']==0 and obs['failure']is None and not obs['cleanup_errors']
assert obs['wait_confirmed']and obs['both_streams_EOF']and obs['group_gone']and all(obs['retained_streams_complete'].values())
assert obs['stdin_bytes_sent']==plan['sources']['runner']['bytes']and obs['wait4_peak_bytes']<=plan['limits']['rss_bytes']and obs['whole_observer_seconds']<=plan['limits']['observer_seconds']
physical={str(p):ref(p)for p in A.iterdir()if p.is_file()and not p.is_symlink()};assert len(physical)==164
assert {r['path']:r for r in obs['files']}=={k:v for k,v in physical.items()if not k.endswith('/observer-result.json')}
assert sum(r['bytes']for r in obs['files'])==obs['stored_bytes']and sum(r['bytes']for r in physical.values())<=plan['limits']['total_bytes']and len(physical)<=plan['limits']['max_files']
for r in physical.values():assert r['bytes']<=plan['limits']['file_bytes']
for group in('sources','metadata'):
 for v in plan[group].values():readref(v)
readref(plan['python']);readref(plan['bootstrap'])
stdout=readref(obs['streams']['stdout']);stderr=readref(obs['streams']['stderr']);terminal=parse(stdout);assert not stderr and terminal==obs['worker_terminal']and terminal['plan']==ref(planp)
assert obs['observed_stream_bytes']=={'stdout':len(stdout),'stderr':len(stderr)}and max(map(len,(stdout,stderr)))<=plan['limits']['stream_bytes']
marker=parse((A/'CONSUMED.json').read_bytes());authority=parse(readref(marker['authority']));consumed=parse(readref(marker['consumed']))
assert authority=={'schema':'X-conditional-cluster-proof-once-authority-v1','uses':1,'authorized':True,'plan':ref(planp),'runner':plan['sources']['runner'],'python':plan['python']}
assert type(authority['uses'])is int and type(authority['authorized'])is bool and consumed=={'authority':marker['authority'],'plan':ref(planp),'status':'SPENT'}
objects={};descs={};rawsizes={};files=[]
def descriptor(d):
 assert set(d)=={'name','stored','encoding','raw_bytes','raw_sha256'}and type(d['name'])is str and d['encoding']in('json','gzip-json')
 stored=readref(d['stored']);assert d['stored']['path']in physical
 raw=gzip.decompress(stored)if d['encoding']=='gzip-json'else stored
 assert len(raw)==d['raw_bytes']and sha(raw)==d['raw_sha256']and len(raw)<=plan['limits']['file_bytes']
 obj=parse(raw);assert wire(obj)==raw
 if d['name']in descs:assert descs[d['name']]==d
 else:descs[d['name']]=d;objects[d['name']]=obj;rawsizes[d['name']]=len(raw)
 return obj
w=descriptor(terminal['result']);assert w['status']=='COMPLETE'and w['outer_public_calls']==terminal['public_calls']
for d in w['artifacts']:descriptor(d)
assert len(w['artifacts'])==159 and len(descs)==160
assert set(physical)=={d['stored']['path']for d in descs.values()}|{str(A/n)for n in('CONSUMED.json','stdout.bin','stderr.bin','observer-result.json')}
counts=collections.Counter();descriptor_occurrences=0;rawref_occurrences=0
for name,obj in objects.items():
 stack=[obj];n=0
 while stack:
  v=stack.pop();n+=1;counts[type(v).__name__]+=1
  if type(v)is dict:
   if set(v)=={'name','stored','encoding','raw_bytes','raw_sha256'}:
    assert v['name']in descs and v==descs[v['name']];descriptor_occurrences+=1
   if set(v)=={'path','bytes','sha256'}and type(v.get('path'))is str and v['path'].startswith(str(A)+'/'):
    assert v==physical[v['path']];rawref_occurrences+=1
   stack.extend(v.values())
  elif type(v)is list:stack.extend(v)
 files.append({'name':name,'descriptor':descs[name],'JSON_values':n})
e=w['experiment'];design=parse(readref(plan['metadata']['design']));limits=parse(readref(plan['metadata']['experiment_limits']));cases=parse(readref(plan['metadata']['cases']))
assert e['status']=='COMPLETE'and e['design']==design and e['limits']==limits
assert len(e['training'])==6 and [x['case_id']for x in e['training']]==design['training_episode_order']
assert len(e['evaluation'])==12 and [x['id']for x in e['evaluation']]==design['heldout']
assert e['qualification']['status']=='PASS'and e['qualification']['emitted']==24 and len(e['qualification_checks'])==23
assert e['qualification']['counts']=={'basis_build':6,'engine_solve':24,'baseline_solve':6,'core_compiled':6,'core_selection':23,'emit':24}
# All native current receipts and complete key bytes, including memo-hit first refs.
program=objects[e['native_program']['name']];identity={'sources':{k:plan['sources'][k]['sha256']for k in('tree_machine','codec','carrier','fol_checker','real_parser')},'program':sha(wire(program)),'limits':{k:limits[k]for k in('native','codec','carrier','checker')}}
memo=e['native_memo'];assert memo['request_count']==len(memo['requests'])==43 and memo['executions']==20 and memo['hits']==23
seen={};native_rows=[];allnative={}
for req in memo['requests']:
 c=objects[req['receipt_ref']['name']];assert c['status']=='VERIFIED'and c['native']['status']=='accepted'and type(c['native']['value'])is int and c['native']['value']==1 and c['independent']['status']=='VERIFIED'
 key=wire({'identity':identity,'theory':c['theory'],'goal':c['goal'],'proof':c['proof']});assert sha(key)==req['key_sha256']
 if key in seen:assert req['cache_hit']and req['receipt_ref']==seen[key]['receipt_ref']and req['first_execution_seconds']==seen[key]['first_execution_seconds']
 else:assert req['cache_hit']is False;seen[key]=req
 assert len(c['proof'])==req['proof_lines']<=64 and c['proof'][-1]['formula']==c['goal']and c['independent']['checked_lines']==len(c['proof'])
 assert c['encoding']['status']==c['decoding']['status']=='COMPLETE'and c['decoding']['proof']==c['proof']
 stream=bytes.fromhex(c['encoding']['stream_hex']);assert len(stream)==req['proof_bytes']==c['encoding']['offset']==c['decoding']['offset']and c['choice']['status']=='VERIFIED'and c['choice']['byte_values']==list(stream)
 assert c['independent']['rule_counts']==dict(collections.Counter(x['rule']for x in c['proof']))
 cv=c['carrier']['value'];assert cv['program_sha256']==identity['program']and cv['byte_count']==len(stream)
 expect=[list(n)for n in cv['nodes']]
 for row in cv['byte_rows']:expect[row['node_index']][0]=stream[row['byte_index']]
 assert expect==c['initial_nodes']and c['final_heap'][:len(expect)]==expect
 assert c['native']['steps']==req['native_steps']<=limits['native']['max_steps']and len(c['final_heap'])<=limits['native']['max_heap_nodes']and c['seconds']==req['first_execution_seconds']
 for i,line in enumerate(c['proof']):
  for k in ('antecedent','implication')if line['rule']=='mp'else('source',)if line['rule']=='generalize'else():assert type(line[k])is int and 0<=line[k]<i
 allnative[req['request_id']]=c
 native_rows.append({'request_id':req['request_id'],'hit':req['cache_hit'],'key_sha256':req['key_sha256'],'receipt':req['receipt_ref'],'proof_lines':len(c['proof']),'bytes':len(stream),'steps':c['native']['steps']})
assert len(seen)==20 and math.isclose(sum(objects[x['receipt_ref']['name']]['seconds']for x in seen.values()),memo['execution_seconds'],rel_tol=1e-12)
# Full bank/pattern identity and saved independent transformations.
bank=e['bank']['value'];assert e['bank']['status']=='COMPLETE'and e['bank_check']['status']=='VERIFIED'and bank==objects['complete-lemma-bank']['result']['value']
assert len(bank['donors'])==6 and len(bank['lemmas'])==4 and bank['bank_sha256']==sha(wire({k:bank[k]for k in('schema','version','donors','lemmas')}))
assert len(e['donor_custody'])==6
for d in bank['donors']:
 assert d['proof'][-1]['formula']==d['goal']and d['source_rows']==sorted(set(d['source_rows']))and len(d['source_rows'])==len(d['proof'])
 assert d['required_axioms']=={x['name']:d['theory']['axioms'][x['name']]for x in d['proof']if x['rule']=='axiom'}
 assert d['original_proof_sha256'] in wire(objects['six-historical-donor-projections']).decode()
patterns=e['patterns']['value'];assert e['patterns']==objects['automatically-mined-patterns']and patterns['pattern_sha256']==sha(wire({k:patterns[k]for k in('schema','version','patterns')}))
assert [p['id']for p in patterns['patterns']]==sorted(set(p['id']for p in patterns['patterns']))
for p in patterns['patterns']:assert p['id']==sha(wire({k:p[k]for k in('nodes','edges','receptors','root')}))and 1<=len(p['nodes'])<=4
# Every saved result, current restoration, full retained streams and counters; no solver replay.
point_rows=[];state_count=rollback_count=event_bodies=guide_bodies=0
for name,obj in objects.items():
 stack=[obj]
 while stack:
  z=stack.pop()
  if type(z)is dict:
   if z.get('schema')in('X-cluster-guided-unit-point-result-v1','W-aggregate-unit-point-result-v1'):
    assert z['status']in('SAT','UNSAT','UNKNOWN');prepared=z['entry_state']is not None
    if prepared:
     assert z['restored_state']==z['entry_state']and z['state_hashes']=={'entry':sha(wire(z['entry_state'])),'restored':sha(wire(z['restored_state']))};state_count+=2
    else:assert z['status']=='UNKNOWN'and z['restored_state']is None
    ex=z['event_extent'];ev=z['events'];assert len(ev)==ex['retained']<=ex['count']and [v['seq']for v in ev]==list(range(len(ev)));event_bodies+=len(ev)
    if ex['retained']==ex['count']:assert ex['JSONL_bytes']==sum(len(wire(v))for v in ev)and ex['SHA256']==sha(b''.join(wire(v)for v in ev))
    assert z['stats']['trail_writes']==z['stats']['trail_undos']==sum(v['undone']for v in z['rollback_records']);rollback_count+=len(z['rollback_records'])
    if prepared:assert z['rollback_records'][-1]['full_restored_sha256']==z['state_hashes']['restored']
    if z['model']is not None:assert z['model_sha256']==sha(wire(z['model']))
    if z['status']=='SAT':assert z['selected']and z['certificate']is not None
    else:assert z['selected']is z['certificate']is None
    if 'heuristic'in z:
     ht=z['heuristic'];tr=ht['trace'];assert len(tr['records'])==tr['retained']<=tr['count'];guide_bodies+=len(tr['records'])
     if tr['retained']==tr['count']:assert tr['JSONL_bytes']==sum(len(wire(v))for v in tr['records'])and tr['SHA256']==sha(b''.join(wire(v)for v in tr['records']))
     assert sum(ht['stats']['executed_packet_ids'].values())==ht['stats']['preferred_placements']<=z['stats']['placements']
    point_rows.append({'artifact':name,'status':z['status'],'model_sha256':z['model_sha256'],'selected':z['selected'],'events':ex,'rollback_rows':len(z['rollback_records']),'nodes':z['stats']['nodes']})
   stack.extend(z.values())
  elif type(z)is list:stack.extend(z)
# Identical complete case data, policy functional updates, current result refs.
policy=e['initial_policy'];assert not policy['values']and not policy['counts'];training=[]
for i,row in enumerate(e['training']):
 assert row['episode']==i and row['state_before']==policy and objects[row['ref']['name']]=={k:v for k,v in row.items()if k!='ref'}
 attempt=row['attempt'];assert attempt['seed']==1000+i
 if row['update']is None:assert attempt['status']=='NOT_RUN_UNKNOWN_BUILD'and row['state_after']==policy
 else:
  raw=objects[attempt['ref']['name']];res=raw['result'];summary=raw['summary'];up=row['update'];assert up['status']=='COMPLETE'and up['value']['state']==row['state_after']and summary['policy_sha256']==sha(wire(policy))and not attempt['verified']
  ep=up['value']['episode'];h=res['heuristic']['stats'];reward=h['max_covered']/summary['slots']-min(1,res['stats']['nodes']/1000)-min(1,(h['callback_seconds']+h['validation_seconds'])/max(res['stats']['elapsed_seconds'],1e-9))
  assert math.isclose(reward,ep['reward'],rel_tol=1e-14)and not h['executed_packet_ids']and not ep['updates']and not up['value']['changed_estimates']
  assert row['state_after']==dict(policy,episodes=policy['episodes']+[ep])
 policy=row['state_after'];training.append({'episode':i,'case':row['case_id'],'status':attempt['status'],'updated':row['update']is not None})
assert policy==e['frozen_policy']and not policy['values']and not policy['counts'];frozen=sha(wire(policy));evaluation=[];positive_rows=[]
for idx,row in enumerate(e['evaluation']):
 assert row['original']==cases[row['id']]and row['slots']==design['slots'][row['id']]and row['frozen_policy_sha256']==frozen and set(row['lanes'])==set(design['lanes'])
 assert objects[row['ref']['name']]=={k:v for k,v in row.items()if k!='ref'}
 prep=objects[row['preparation_ref']['name']];assert prep['original']==row['original']and prep['slots']==row['slots'];app=prep['application'];assert app==prep['extension']['value']and prep['extension_check']['status']=='VERIFIED'
 assert app['original_theory_sha256']==sha(wire(row['original']['theory']))and app['bank_sha256']==bank['bank_sha256']
 for lane,att in row['lanes'].items():
  if lane!='SAME_INVENTORY_SHARED_DAG':assert att['seed']==2000+idx
  if att['status']=='NOT_RUN_UNKNOWN_BUILD':assert not att['verified']and prep['build']['status']=='UNKNOWN'
  else:
   raw=objects[att['ref']['name']];assert raw['preparation_ref']==row['preparation_ref']and raw['status']==att['status']and raw['verified']==att['verified']
   if raw.get('summary')is not None:assert raw['summary']['policy_sha256']==frozen and raw['summary']['pattern_sha256']==patterns['pattern_sha256']
   if att['verified']:
    pos=raw['positive'];assert pos=={k:v for k,v in att['positive'].items()if k!='ref'}or pos==att['positive']
    assert pos['verified']and pos['original_status']=='VERIFIED'and pos['lowering']['status']=='COMPLETE'and pos['lowering_audit']['status']=='VERIFIED'
    lower=pos['lowering']['value'];assert lower['theory']==row['original']['theory']and lower['goal']==row['original']['goal']and lower['proof']==pos['original_proof']and len(lower['proof'])<=64 and lower['proof'][-1]['formula']==row['original']['goal']
    assert pos['coarse_proof'][-1]['formula']==row['original']['goal']and lower['coarse_to_primitive'][-1]==len(lower['proof'])-1
    for stage,theory,proof in(('coarse',app['theory'],pos['coarse_proof']),('original',row['original']['theory'],pos['original_proof'])):
     checked=objects[pos[stage+'_check']['receipt_ref']['name']];assert checked['theory']==theory and checked['goal']==row['original']['goal']and checked['proof']==proof
    positive_rows.append({'case':row['id'],'lane':lane,'coarse_lines':len(pos['coarse_proof']),'primitive_lines':len(pos['original_proof']),'lemma_expansions':lower['lemma_expansions'],'original_check':pos['original_check'],'coarse_check':pos['coarse_check']})
  evaluation.append({'case':row['id'],'lane':lane,'status':att['status'],'verified':att['verified'],'search_seconds':att.get('search_seconds')})
support={'schema':'X-study001-complete-passive-association-support-v1','original_outer':ref(outerp),'observer':ref(A/'observer-result.json'),'worker':terminal['result'],'original_file_inventory':list(physical.values()),'physical_files':len(physical),'physical_bytes':sum(x['bytes']for x in physical.values()),'artifact_descriptors':len(descs),'artifact_raw_bytes':sum(rawsizes.values()),'all_artifact_profiles':files,'JSON_value_types':dict(counts),'descriptor_occurrences_joined':descriptor_occurrences,'current_actual_rawref_occurrences_joined':rawref_occurrences,'current_Source_guards':plan['sources'],'current_metadata_guards':plan['metadata'],'qualification':e['qualification'],'native_requests':native_rows,'native_unique_executions':20,'native_hits':23,'all_saved_point_result_occurrences':point_rows,'state_occurrences':state_count,'rollback_record_occurrences':rollback_count,'retained_event_body_occurrences':event_bodies,'retained_guide_body_occurrences':guide_bodies,'training':training,'frozen_policy_sha256':frozen,'numeric_values_empty':not policy['values'],'numeric_counts_empty':not policy['counts'],'patterns':len(patterns['patterns']),'evaluation':evaluation,'searched_positives':positive_rows,'native_memo_full_key_join':True,'outer_public_calls':terminal['public_calls'],'subject_calls':0,'scope':'Repeated result occurrences in summary/control carriers are counted as occurrences; final receipt distinguishes unique original records. Full suffix hashes are recomputed only where all bodies retained. No project Source or helper replay.'}
sp=O/'X-study001-complete-passive-association-support-v1.json';sp.write_bytes((json.dumps(support,sort_keys=True,indent=2,allow_nan=False)+'\n').encode());print(json.dumps(ref(sp)));print('CENSUS',len(physical),sum(rawsizes.values()),len(point_rows),len(positive_rows),len(patterns['patterns']));print('EVAL',dict(collections.Counter((x['lane'],x['status'])for x in evaluation)))
