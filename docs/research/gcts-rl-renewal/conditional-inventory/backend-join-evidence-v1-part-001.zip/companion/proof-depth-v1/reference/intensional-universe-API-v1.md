# Intensional native universe, Source-only version 1

Status: implemented Source, AST inspection only; no compiler, classifier, provider, search, graph checker or kernel has run for this continuation. Existing Sources and studies remain unchanged. The master reference is copied with SHA256 `c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9`.

## Public APIs

`source/native_universe_v1.py` exposes:

```python
make_lane(compiled, generation, depth, mode='BASE', certificate=None,
          *, factory_limits=None)
```

The success result is a dictionary with `status='PREPARED'`, `model`, a fresh `provider` (the only non-JSON value), unchanged native `factory`, compact JSON `descriptor`, `absence_check` and actual `setup` metadata. A factory/certificate resource refusal returns `UNKNOWN` without an admitted model/provider. A rejected certificate returns its rejected status. BASE ignores a supplied certificate. MARKS and IFILTER independently check its bounded absence DAG with the pinned prior independent checker. No target proof or prior search trace is read.

The unchanged indexed producer is used for BASE. MARKS decorates each premise with literal failure-port value `"1"`, seeds exactly the certified requested absences as `"0"`, and retains rows through ordinary full marking agreement. Missing stays unconstrained. IFILTER is the matched conventional static-inventory control: it retains exactly original rows with no certified-absent premise at their actual remaining height. Its packet potential count describes this restricted inventory, rather than the larger original inventory. No full filtered row index is constructed.

The descriptor binds the entire compiled core, logical basis, generation, native definitions, height, mode, negative requests/certificate/scope, exact per-level arity counts and inventory identity. Its compact content hash is **not an expanded row-stream hash**. The current implementation declares a resource scope through height sixteen, at most two thousand formulas and twenty thousand native definitions in the independent oracle; this continuation proposes only heights five and six.

`reference/native_universe_checker_v1.py` exposes:

```python
verify_descriptor(compiled, generation, descriptor, certificate=None,
                  model=None, *, max_items=100000000, wall_seconds=30.0)
Universe(compiled, generation, descriptor, certificate=None, *,
         charge=callback, max_cached_rows=200000,
         max_incident_entries=500000)
materialize_tiny(compiled, generation, descriptor, certificate=None,
                 *, max_rows=2000)
```

`verify_descriptor` returns VERIFIED/REJECTED/UNKNOWN without expanding addresses. It checks every structural native definition, descriptor integer count and identity, the optional exact model/seed binding, and the independent absence certificate where relevant. Logical truth of ZERO lines and completeness of RF instance generation stay separate native-kernel and independent RF-profile obligations. A forged receipt supplied by a caller does not replace the absence checker.

An admitted `Universe` supports `row(cid)`, `incident(point)`, `bind_model(normalized_model)` and `receipt()`. Its `rows` and `incidents` mapping facades are intended for the independent frontier checker. It has no all-row iterator. A cache or work refusal raises an explicit resource exception; it never returns a shortened domain. Immutable row/potential-incident caches are not logical search state and contain no context-compatible answers. Every contextual legality test is recomputed against the current restored totals, marks, inventory selection and exclusions.

`materialize_tiny` is a qualification-only full expansion. It refuses an exact represented count above its explicit cap; it returns COMPLETE plus every canonical row and the expanded-row SHA only when the entire tiny set is retained. It is not a deeper-run input constructor or an approximate universe.

`reference/frontier_trace_checker_v2.py` extends the unchanged baseline reader:

```python
verify(model, universe, observations, result, *, native_context=None,
       oracle_limits=None, max_items=10000000, wall_seconds=30.0)
```

When `universe` is the original explicit list, the previous finite-universe path is retained. When it is an intensional descriptor, supply exactly

```python
native_context = {
    'compiled': compiled,
    'generation': generation,
    'certificate': certificate_or_None,
}
```

The optional `oracle_limits` contains only `max_cached_rows` and `max_incident_entries`. Descriptor mode requires an indexed-inventory model; explicit models continue to use the old list path. A tiny equivalence run should therefore use the exact same indexed model/provider/raw search once, then check that raw trace against an explicit universe with v1 and the descriptor/context with v2.

V2 changes only complete universe access and descriptor/model admission. Event replay, global dead/forced/earliest-generation scheduling, weighted graph reconstruction, branch-frame exclusions, exact logical rollback and retained-stream requirements are copied unchanged. A successful intensional receipt has `universe_sha256=None`, a separately named `universe_descriptor_sha256`, and `universe_hash_scope='INTENSIONAL_DESCRIPTOR_NOT_EXPANDED_ROW_STREAM'`. The nested `intensional_universe_admission` records represented counts, actual oracle materializations and cache use. A valid schema receipt is not a successful trace or native logical proof.

## Why incident enumeration remains complete

Every placement contributes one unit at its own binary address and at one or two premise-child addresses. A CID touching point \(p\) therefore has either its own site equal to \(p\), or its site equal to the immediate parent of \(p\) with a premise in that child role. These cases are disjoint by site. For a final child digit zero, both unary and binary parent producers apply; for digit one only binary parents apply. At the final height only ZERO placements can own the point. IFILTER applies the same static certified premise test at each candidate's own site; MARKS retains all original CIDs.

Thus the oracle can enumerate every positive-support alignment locally without traversing all addresses, and full current domains can still be reconstructed after every event. Mark-only ports carry no positive support and never create required points. Their values still participate in every candidate's full marking legality check. No provider `complete:true`, proposal shortlist or observed positive proof supplies the independent universe.

## Resource sizes and costs

For the unchanged incidence schema the stored profile has \(Z=410\), \(G=4\), \(M=784\), so there are \(D=1198\) definitions. The represented BASE and MARKS row count is

\[
N(H)=Z(2^{H+1}-1)+(G+M)(2^H-1).
\]

| Height | Addresses | Represented rows | Total potential point/CID incidences |
| --- | ---: | ---: | ---: |
| five | 63 | 50258 | 98990 |
| six | 127 | 101714 | 200750 |

These are exact arithmetic sizing consequences of that previously stored profile, not freshly compiled/admitted results. IFILTER's exact counts depend on its newly checked absence certificate and are recomputed per level. At an internal point ending in zero there are at most \(1198+784+4=1986\) potential CIDs; a final-height point has at most \(410+784+4=1198\). Counts are numbers of candidate identities, not fill-capacity estimates.

Descriptor construction and independent definition/level admission require order \(D(H+1)\) definition tests and storage proportional to the compiled grammar plus these level lists. The reference oracle stores actual demanded CID rows and potential incidence lists only; its explicit counters and resource bounds remain visible. It can eventually materialize many of the represented rows if the trace visits enough points. This avoids mandatory exponential preparation, not the inherent size of large domains or a full proof search. Full graph snapshots, raw journals and verification may still dominate time/storage and must remain separately budgeted. Cache limits or incomplete journals yield UNKNOWN, never a certified dead/forced move or logical negative.

## Prospective qualification before deeper search

1. Author fresh tiny closed native theories containing distinct ZERO aliases, unary GEN and binary MP alternatives, a reachable goal, an ungrounded cycle and dead alternate. Add a tiny RF universal-instantiation/equality-context declaration. Supply hypotheses/goals only, never a target derivation or selected producer path. Freeze all source/runtime/declaration/bound/resource pins first.
2. For BASE, MARKS and IFILTER at tiny heights, independently enumerate the explicit universe using the unchanged prior `transfer_inputs_v1._universe` authoring helper (within its old small-height scope), and compare it row-for-row with `materialize_tiny`. For IFILTER use the same checked absence certificate to construct the explicit static restricted inventory. This independent enumeration must not call the new production descriptor or provider placement methods as its oracle.
3. Run each fresh indexed model/provider once. Save raw results, every event/snapshot and every completed packet before assurance. Run the unchanged v1 full-list checker and v2 descriptor checker on those same saved observations. Require equal status, reconstructed event/query/graph counters and complete streams for each completed search, plus separate native B/tree checks of any actual proof. Compare all retained packet counts to the full tiny inventory, including own and both parent roles. No rerun merely to repair assurance.
4. Mutate a native definition/registry binding, descriptor depth/counts/identity, negative certificate producer coverage/scope, literal zero flag, remaining-height port, packet row (with adjusted counts), weighted incidence, emergent generation and sibling exclusion. Recompute ordinary content hashes where relevant; the semantic checks must reject, rather than rely on stale checksums.
5. Keep generic explicit-path fixtures for a remote untouched zero target and global dead-before-forced order. V2's native profile intentionally permits only the goal root, so adding a remote native root is instead a profile-binding mutant, not evidence of a valid multi-root native problem. Omitted full-frontier points/edges/dependencies in actual native snapshots must also be refused.
6. Deliberately cap oracle rows/incidences or verifier work and retain UNKNOWN. A partial potential set must never return VERIFIED or create a degree-zero/one conclusion. Retain the existing engine resource/refusal and exact rollback checks.
7. Only after this gate freeze the new deeper incidence cohort. Preserve all hypotheses, native grammar, lexical primitive fallback, scheduler and bounds; use fresh classifiers and providers. Save compact descriptor/context references and every full graph observation. Compare BASE, MARKS, IFILTER and the declared memoized control without changing original jobs or claiming sampled/full set equality. Every found native proof requires its own tree/B/line-reader join. No policy/RL is enabled here.

This is still an anchored symbolic point-proof adaptation, not a fixed translation-only Wang plane grid, a full Hilbert formalization, unrestricted first-order completeness or a proof-search performance result.
