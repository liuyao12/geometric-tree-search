"""Independent complete RF frozen-original-input catalogue reconstruction.

Only stdlib is imported. No compiler, provider, engine, logical kernel, or
saved proof is consulted. Literal JSON equality includes native number types.
Logical soundness of the ZERO schemas is a separate native-kernel obligation.
"""
import hashlib
import json
import math
import time

VERSION = 'RF-INDEPENDENT-CATALOGUE-CHECKER-v1'
SCOPE = ('RF-frozen-original-term/UI/original-EQ-context basis; complete native '
         'ZERO/MP/GEN within this explicit basis, not unbounded FOL completeness.')
EQ_SCOPE = ('Every EQ occurrence in original theory/goal only; each individual '
            'term occurrence replaced by one fresh hole.')
TERM_SCOPE = ('All original theory/goal/declared-term subterms, frozen before UI. '
              'UI output terms do not enlarge this pool.')


class _Reject(Exception):
    pass


class _Bound(Exception):
    pass


class _Capture(Exception):
    pass


def _need(condition, reason):
    if not condition:
        raise _Reject(reason)


class _Meter:
    def __init__(self, items, work, seconds):
        _need(type(items) is int and items >= 1 and type(work) is int and work >= 1,
              'CHECKER_ITEM_WORK_LIMITS')
        _need(type(seconds) in (int, float) and math.isfinite(seconds) and seconds > 0,
              'CHECKER_WALL_LIMIT')
        self.max_items, self.max_work = items, work
        self.items, self.work = 0, 0
        self.start = time.monotonic()
        self.deadline = self.start + seconds

    def charge(self, amount=1):
        self.work += amount
        if self.work > self.max_work:
            raise _Bound('CHECKER_WORK_BOUND')
        if time.monotonic() > self.deadline:
            raise _Bound('CHECKER_WALL_BOUND')

    def scan(self, value, depth=0):
        self.charge()
        if depth > 128:
            raise _Bound('CHECKER_JSON_DEPTH_BOUND')
        self.items += 1
        if type(value) is str:
            self.items += len(value)
        elif type(value) is int:
            self.items += max(1, value.bit_length() // 8)
        elif type(value) is list:
            for child in value:
                self.scan(child, depth + 1)
        elif type(value) is dict:
            for key, child in value.items():
                _need(type(key) is str, 'JSON_OBJECT_KEY_TYPE')
                self.scan(key, depth + 1)
                self.scan(child, depth + 1)
        else:
            _need(value is None or type(value) is bool or
                  type(value) is float and math.isfinite(value), 'NATIVE_FINITE_JSON_REQUIRED')
        if self.items > self.max_items:
            raise _Bound('CHECKER_ITEM_BOUND')


class _Reference:
    """Immutable syntax trees and set/worklist closure, not compiler helpers."""
    def __init__(self, declaration, meter):
        self.m = meter
        _need(type(declaration) is dict and type(declaration.get('problem')) is dict,
              'DECLARATION_PROBLEM')
        problem = declaration['problem']
        _need('theory' in problem and 'goal' in problem, 'PROBLEM_FIELDS')
        theory = problem['theory']
        _need(type(theory) is dict and set(theory) == {'functions', 'predicates', 'axioms'},
              'THEORY_FIELDS')
        self.theory, self.declaration = theory, declaration
        for group in ('functions', 'predicates'):
            sig = theory[group]
            _need(type(sig) is dict and all(type(k) is str and k and
                  type(v) is int and v >= 0 for k, v in sig.items()), 'SIGNATURE_'+group)
        _need(type(theory['axioms']) is dict and all(type(k) is str and k for k in theory['axioms']),
              'NAMED_AXIOMS')
        self.free_cache, self.json_cache = {}, {}
        self.assumptions = {name:self.parse(form, False) for name, form in theory['axioms'].items()}
        self.goal = self.parse(problem['goal'], False)
        _need(all(not self.free(f) for f in self.assumptions.values()), 'CLOSED_GAMMA')
        requested = declaration.get('profile', {})
        _need(type(requested) is dict, 'PROFILE_OBJECT')
        self.requested = requested
        self.rounds = requested.get('ui_rounds', declaration.get('ui_rounds', 1))
        self.definition_limit = requested.get('max_definitions', 8000)
        self.term_limit = requested.get('max_terms', 20)
        self.template_limit = requested.get('max_templates', 24)
        _need(type(self.rounds) is int and self.rounds >= 0, 'UI_ROUNDS')
        _need(type(self.definition_limit) is int and 1 <= self.definition_limit <= 8000,
              'DEFINITION_PROFILE_LIMIT')
        _need(type(self.term_limit) is int and self.term_limit >= 1 and
              type(self.template_limit) is int and self.template_limit >= 0, 'TERM_TEMPLATE_PROFILE_LIMITS')

    def parse(self, ast, term, depth=0):
        self.m.charge()
        if depth > 96:
            raise _Bound('CHECKER_AST_DEPTH_BOUND')
        _need(type(ast) is list and ast and type(ast[0]) is str, 'AST_LIST_TAG')
        tag = ast[0]
        _need((tag in ('var', 'fun')) == term, 'AST_SORT')
        if tag == 'var':
            _need(len(ast) == 2 and type(ast[1]) is str and ast[1], 'VARIABLE_SYNTAX')
            return (tag, ast[1])
        if tag in ('fun', 'pred'):
            group = self.theory['functions' if tag == 'fun' else 'predicates']
            _need(len(ast) == 3 and type(ast[1]) is str and ast[1] in group and
                  type(ast[2]) is list and len(ast[2]) == group[ast[1]], 'SYMBOL_APPLICATION')
            return (tag, ast[1], tuple(self.parse(x, True, depth+1) for x in ast[2]))
        if tag in ('eq', 'imp', 'and', 'or'):
            _need(len(ast) == 3, 'BINARY_FORMULA')
            return (tag, self.parse(ast[1], tag == 'eq', depth+1),
                    self.parse(ast[2], tag == 'eq', depth+1))
        if tag == 'all':
            _need(len(ast) == 3 and type(ast[1]) is str and ast[1], 'BINDER_SYNTAX')
            return (tag, ast[1], self.parse(ast[2], False, depth+1))
        if tag == 'not':
            _need(len(ast) == 2, 'NEGATION_SYNTAX')
            return (tag, self.parse(ast[1], False, depth+1))
        _need(tag == 'bot' and len(ast) == 1, 'FORMULA_TAG')
        return ('bot',)

    def native(self, value):
        self.m.charge(1 + len(value) if type(value) is str else 1)
        if isinstance(value, tuple):
            return [self.native(v) for v in value]
        return value

    def text(self, value):
        self.m.charge()
        if isinstance(value, tuple):
            if value not in self.json_cache:
                self.json_cache[value] = json.dumps(self.native(value), sort_keys=True,
                    ensure_ascii=True, separators=(',', ':'), allow_nan=False)
            return self.json_cache[value]
        parts = []
        encoder = json.JSONEncoder(sort_keys=True, ensure_ascii=True, separators=(',', ':'), allow_nan=False)
        for chunk in encoder.iterencode(value):
            self.m.charge(len(chunk))
            parts.append(chunk)
        return ''.join(parts)

    def children(self, node):
        tag = node[0]
        if tag in ('fun', 'pred'):
            return node[2]
        if tag in ('eq', 'imp', 'and', 'or'):
            return node[1:]
        if tag == 'all':
            return (node[2],)
        return (node[1],) if tag == 'not' else ()

    def free(self, node):
        self.m.charge()
        if node not in self.free_cache:
            if node[0] == 'var':
                result = {node[1]}
            else:
                result = set()
                for child in self.children(node):
                    result.update(self.free(child))
                if node[0] == 'all':
                    result.discard(node[1])
            self.free_cache[node] = frozenset(result)
        return self.free_cache[node]

    def all_nodes(self, root):
        pending = [root]
        while pending:
            self.m.charge()
            node = pending.pop()
            yield node
            pending.extend(reversed(self.children(node)))

    def replacement(self, node, variable, term):
        self.m.charge()
        tag = node[0]
        if tag == 'var':
            return term if node[1] == variable else node
        if tag == 'all':
            if node[1] == variable:
                return node
            if variable in self.free(node[2]) and node[1] in self.free(term):
                raise _Capture()
        children = tuple(self.replacement(c, variable, term) for c in self.children(node))
        if tag in ('fun', 'pred'):
            return (tag, node[1], children)
        if tag == 'all':
            return (tag, node[1], children[0])
        return (tag,) + children

    def hole_variants(self, term, hole):
        """Replace exactly one occurrence, including the entire argument."""
        self.m.charge()
        yield ('var', hole)
        if term[0] == 'fun':
            for position, child in enumerate(term[2]):
                for changed in self.hole_variants(child, hole):
                    yield ('fun', term[1], term[2][:position] + (changed,) + term[2][position+1:])

    def reconstruct(self):
        d, m = self.declaration, self.m
        originals = [self.assumptions[n] for n in sorted(self.assumptions)] + [self.goal]
        declared_terms = d.get('terms', [])
        _need(type(declared_terms) is list, 'DECLARED_TERMS_LIST')
        extra = [self.parse(t, True) for t in declared_terms]
        terms = {node for source in originals+extra for node in self.all_nodes(source)
                 if node[0] in ('var', 'fun')}
        ordered_terms = sorted(terms, key=self.text)
        if len(terms) > self.term_limit:
            raise _Bound('PROFILE_MAX_FIXED_TERMS')
        if 'instantiation_terms' in d:
            _need(type(d['instantiation_terms']) is list, 'INSTANTIATION_TERMS_LIST')
            ui_terms = {self.parse(t, True) for t in d['instantiation_terms']}
            _need(ui_terms <= terms, 'UI_POOL_OUTSIDE_ORIGINAL_TERMS')
            ui_terms = sorted(ui_terms, key=self.text)
        else:
            ui_terms = list(ordered_terms)
        names = {node[1] for root in originals+extra for node in self.all_nodes(root)
                 if node[0] in ('var', 'all')}
        hole = '__rf_hole'
        while hole in names:
            m.charge();hole += '_'
        equations, templates, raw_templates = set(), set(), 0
        for source in originals:
            for node in self.all_nodes(source):
                if node[0] != 'eq':
                    continue
                equations.add(node)
                for side in (1, 2):
                    for variant in self.hole_variants(node[side], hole):
                        raw_templates += 1
                        templates.add(('eq', variant, node[2]) if side == 1 else ('eq', node[1], variant))
        ordered_templates = sorted(templates, key=self.text)
        if len(templates) > self.template_limit:
            raise _Bound('PROFILE_MAX_ORIGINAL_EQ_TEMPLATES')
        formulas, zeros = set(), {}
        counts = dict(mp=0, gen=0, capture_omissions=0, ui_attempts=0,
                      equality_term_instances=0, equality_retained_pairs=0)

        def closure(root):
            pending = [root]
            while pending:
                m.charge();node = pending.pop()
                if node in formulas:
                    continue
                formulas.add(node)
                counts['mp'] += int(node[0] == 'imp')
                counts['gen'] += int(node[0] == 'all')
                if node[0] in ('imp', 'and', 'or'):
                    pending.extend(node[1:])
                elif node[0] == 'all':
                    pending.append(node[2])
                elif node[0] == 'not':
                    pending.append(node[1])
                resource()

        def resource():
            if len(zeros)+counts['mp']+counts['gen'] > self.definition_limit:
                raise _Bound('PROFILE_MAX_DEFINITIONS')

        def zero(line):
            m.charge();key = self.text(line)
            if key not in zeros:
                # Parse by independent syntax validation, not compiler interning.
                closure(self.parse(line['formula'], False))
                zeros[key] = line
                resource()

        closure(self.goal)
        for name in sorted(self.assumptions):
            zero(dict(rule='axiom', name=name, formula=self.native(self.assumptions[name])))
        for term in ordered_terms:
            zero(dict(rule='refl', formula=self.native(('eq', term, term))))
        stages = [dict(stage='frozen_original_inputs', fixed_terms=len(terms), ui_terms=len(ui_terms),
                       raw_eq_templates=raw_templates, eq_templates=len(templates),
                       source_equations=[self.native(e) for e in sorted(equations, key=self.text)])]
        for round_index in range(self.rounds):
            m.charge()
            universals = sorted((f for f in formulas if f[0] == 'all'), key=self.text)
            before, omitted = len(zeros), counts['capture_omissions']
            for universal in universals:
                for term in ui_terms:
                    m.charge();counts['ui_attempts'] += 1
                    try:
                        instance = self.replacement(universal[2], universal[1], term)
                    except _Capture:
                        counts['capture_omissions'] += 1
                        continue
                    zero(dict(rule='instantiate', universal=self.native(universal), term=self.native(term),
                              formula=self.native(('imp', universal, instance))))
            stages.append(dict(stage='ui', round=round_index+1, universals=len(universals),
                new_zero_instances=len(zeros)-before, capture_omissions=counts['capture_omissions']-omitted))
            if len(zeros) == before:
                break
        for template in ordered_templates:
            retained = []
            for term in ordered_terms:
                result = self.replacement(template, hole, term)
                result_terms = {n for n in self.all_nodes(result) if n[0] in ('var','fun')}
                if result_terms <= terms:
                    retained.append((term, result))
            counts['equality_term_instances'] += len(retained)
            for left, antecedent in retained:
                for right, consequent in retained:
                    m.charge();counts['equality_retained_pairs'] += 1
                    zero(dict(rule='eq_subst', variable=hole, template=self.native(template),
                        left=self.native(left), right=self.native(right),
                        formula=self.native(('imp', ('eq',left,right), ('imp',antecedent,consequent)))))
        ordered_forms = sorted(formulas, key=self.text)
        colors = [self.text(f) for f in ordered_forms]
        identifiers = {f:i for i,f in enumerate(ordered_forms)}
        native_zeros = [zeros[k] for k in sorted(zeros)]
        mp = [[i,identifiers[f[1]],identifiers[f[2]]] for i,f in enumerate(ordered_forms) if f[0] == 'imp']
        gen = [[i,identifiers[f[2]],f[1]] for i,f in enumerate(ordered_forms) if f[0] == 'all']
        definition_count = len(native_zeros)+len(mp)+len(gen)
        profile = dict(self.requested, ui_rounds=self.rounds, bridge_arity=0, max_tautology_atoms=0,
            max_definitions=self.definition_limit, max_terms=self.term_limit, max_templates=self.template_limit,
            fixed_term_count=len(terms), ui_term_count=len(ui_terms),
            ui_pool='explicit-case-instantiation-terms' if 'instantiation_terms' in d else 'original-fixed-terms',
            eq_context_scope=EQ_SCOPE, raw_eq_template_count=raw_templates, eq_template_count=len(templates),
            unique_source_equations=len(equations), eq_pairs_before_output_filter=len(templates)*len(terms)**2,
            eq_retained_pairs=counts['equality_retained_pairs'], term_scope=TERM_SCOPE, definition_count=definition_count)
        stages.append(dict(stage='native_equality', reflexivity_instances=len(terms),
                           retained_ordered_pairs=counts['equality_retained_pairs']))
        compiled = dict(schema='V-interned-Hilbert8-basis-v1', version='V-INTERNED-FINITE-HILBERT8-v1',
            theory=self.theory, goal=self.native(self.goal), goal_id=identifiers[self.goal], profile=profile,
            logical_basis=dict(instantiation_terms=[self.native(t) for t in ui_terms],
                terms=[self.native(t) for t in ordered_terms], variables=sorted(names|{hole}),
                formulas=[self.native(f) for f in ordered_forms], colors=colors,
                templates=[self.native(t) for t in ordered_templates], hole=hole, stages=stages),
            zero_instances=[dict(id='i'+str(i),rule=z['rule'],formula_id=identifiers[self.parse(z['formula'],False)],line=z)
                            for i,z in enumerate(native_zeros)], mp_index=mp, gen_index=gen, scope=SCOPE)
        core = {k:v for k,v in compiled.items() if k != 'scope'}
        generation = dict(schema='Y-goal-receptor-universe-v1', version='Y-GOAL-RECEPTOR-FAMILY-v1',
            profile=profile, compiled_core_sha256=_hash(self.text(core)), core_stages=[], core_assertions=[],
            goal_receptors=[], bridge_premises=[], scope=SCOPE)
        cost_counts = dict(formulas=len(ordered_forms), instances=len(native_zeros), definitions=definition_count,
            fixed_terms=len(terms), raw_eq_templates=raw_templates, eq_templates=len(templates), **counts)
        return compiled, generation, cost_counts


def _hash(canonical_text):
    return hashlib.sha256((canonical_text+'\n').encode('ascii')).hexdigest()


def verify(declaration, compiled, generation, *, max_items=10000000,
           max_work=20000000, wall_seconds=30.0):
    """Check an entire successfully compiled RF profile; no proof search.

    Bounds/refusals are UNKNOWN. Any content/type/order/count mismatch is
    REJECTED. Only compiled.costs.seconds is a measured, non-exact field.
    """
    meter, stage = None, 'limits'
    try:
        meter = _Meter(max_items,max_work,wall_seconds)
        stage = 'input_json'
        for value in (declaration,compiled,generation):
            meter.scan(value)
        stage = 'declaration_and_profile'
        reference = _Reference(declaration,meter)
        stage = 'complete_reconstruction'
        expected, expected_generation, costs = reference.reconstruct()
        stage = 'compiled_content'
        _need(type(compiled) is dict and set(compiled) == set(expected)|{'costs'}, 'COMPILED_FIELDS')
        _need(reference.text({k:v for k,v in compiled.items() if k != 'costs'}) == reference.text(expected),
              'ENTIRE_COMPILED_CATALOGUE_MISMATCH')
        actual_costs = compiled['costs']
        _need(type(actual_costs) is dict and set(actual_costs) == set(costs)|{'seconds'}, 'COST_FIELDS')
        seconds = actual_costs['seconds']
        _need(type(seconds) in (int,float) and math.isfinite(seconds) and seconds >= 0, 'MEASURED_SECONDS')
        _need(reference.text({k:v for k,v in actual_costs.items() if k != 'seconds'}) == reference.text(costs),
              'DETERMINISTIC_COST_COUNTS_MISMATCH')
        stage = 'generation_content'
        _need(reference.text(generation) == reference.text(expected_generation), 'ENTIRE_GENERATION_MISMATCH')
        return dict(schema='RF-complete-catalogue-check-receipt-v1', status='VERIFIED', version=VERSION,
            reason='ENTIRE_FROZEN_RF_PROFILE_RECONSTRUCTED', counts=costs,
            compiled_core_sha256=expected_generation['compiled_core_sha256'],
            declaration_sha256=_hash(reference.text(declaration)), checked_items=meter.items, work=meter.work,
            measured_cost_fields_exempt=['compiled.costs.seconds'],
            scope='Complete finite RF enumeration/registry/IDs/metadata only. Every ZERO logical validity, placement carrier, frontier trace and returned native proof require separate checks.')
    except _Reject as error:
        return dict(status='REJECTED',version=VERSION,stage=stage,reason=str(error),
                    work=meter.work if meter else 0,checked_items=meter.items if meter else 0)
    except (_Bound,MemoryError,RecursionError) as error:
        return dict(status='UNKNOWN',version=VERSION,stage=stage,reason=str(error) or type(error).__name__,
                    work=meter.work if meter else 0,checked_items=meter.items if meter else 0)
    except (KeyError,TypeError,ValueError,IndexError,OverflowError) as error:
        return dict(status='REJECTED',version=VERSION,stage=stage,reason='MALFORMED_INPUT:'+type(error).__name__,
                    work=meter.work if meter else 0,checked_items=meter.items if meter else 0)
