"""Independent exact intensional native point-universe reconstruction.

No producer/compiler/engine/policy imports. A pinned independent bounded-absence
checker is loaded lazily for MARKS/IFILTER. Native logical ZERO truth and full RF
profile-generation completeness are external, separately recorded obligations.
"""
import copy
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import time

VERSION = 'PFD-INDEPENDENT-INTENSIONAL-UNIVERSE-v1'
SCHEMA = 'PFD-intensional-native-universe-v1'
MAX_DEPTH = 16
MAX_FORMULAS = 2000
MAX_DEFINITIONS = 20000
ABSENCE_PIN = '2436cc872737f9400c7bbb78949a366919a64804ca3088be1577fcdc7c7e88db'
_ABSENCE = None


class Rejected(Exception):
    pass


class Bound(Exception):
    pass


def need(condition, reason):
    if not condition:
        raise Rejected(reason)


def text(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(',', ':'), allow_nan=False)


def sha(value):
    return hashlib.sha256((text(value) + '\n').encode('ascii')).hexdigest()


def absence_checker():
    global _ABSENCE
    if _ABSENCE is None:
        path = Path(__file__).resolve().parent / 'upstream/failure_certificate_checker_v1.py'
        need(hashlib.sha256(path.read_bytes()).hexdigest() == ABSENCE_PIN, 'ABSENCE_CHECKER_SOURCE_PIN')
        spec = importlib.util.spec_from_file_location('pfd_independent_absence', path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        _ABSENCE = module
    return _ABSENCE


class Rows:
    """Mapping protocol intentionally has no operation to expand every address."""
    def __init__(self, universe):
        self.universe = universe

    def __contains__(self, cid):
        try:
            self.universe.parse(cid)
            return True
        except Rejected:
            return False

    def __getitem__(self, cid):
        return self.universe.row(cid)

    def __iter__(self):
        raise Bound('INTENSIONAL_ALL_ROW_ITERATION_FORBIDDEN')


class Incidents:
    def __init__(self, universe):
        self.universe = universe

    def get(self, point, default=()):
        if not self.universe.is_site(point):
            return default
        return self.universe.incident(point)


class Universe:
    def __init__(self, compiled, generation, descriptor, certificate=None, *, charge=lambda n=1: None,
                 max_cached_rows=200000, max_incident_entries=500000):
        self.charge = charge
        need(type(max_cached_rows) is int and max_cached_rows > 0 and
             type(max_incident_entries) is int and max_incident_entries > 0, 'ORACLE_CACHE_LIMITS')
        self.max_cached_rows, self.max_incident_entries = max_cached_rows, max_incident_entries
        self.row_cache, self.incident_cache, self.incident_entries = {}, {}, 0
        self.stats = dict(row_materializations=0, row_cache_hits=0, incident_materializations=0,
                          incident_cache_hits=0, definition_tests=0)
        need(type(compiled) is dict and type(generation) is dict and type(descriptor) is dict, 'NATIVE_CONTEXT')
        self.depth, self.mode = descriptor.get('depth'), descriptor.get('mode')
        need(type(self.depth) is int and 0 <= self.depth <= MAX_DEPTH, 'INTENSIONAL_DEPTH_BOUND')
        need(self.mode in ('BASE', 'MARKS', 'IFILTER'), 'UNIVERSE_MODE')
        forms = compiled['logical_basis']['formulas']
        colors = compiled['logical_basis']['colors']
        need(type(forms) is list and type(colors) is list and len(forms) == len(colors), 'REGISTRY_SHAPE')
        if len(forms) > MAX_FORMULAS:
            raise Bound('ORACLE_FORMULA_RESOURCE_BOUND')
        need(all(type(v) is str for v in colors) and colors == sorted(set(colors)), 'CANONICAL_COLORS')
        self.charge(1 + sum(len(c) for c in colors))
        need(colors == [text(f) for f in forms], 'LITERAL_FORMULA_COLORS')
        self.colors = tuple(colors)
        ids = {c: i for i, c in enumerate(colors)}
        need(type(compiled['goal_id']) is int and 0 <= compiled['goal_id'] < len(forms) and
             colors[compiled['goal_id']] == text(compiled['goal']), 'GOAL_COLOR')
        self.goal_color = colors[compiled['goal_id']]
        definitions, mp, gen = [], [], []
        for index, zero in enumerate(compiled['zero_instances']):
            self.charge(1)
            need(type(zero) is dict and set(zero) == {'id', 'rule', 'formula_id', 'line'}, 'ZERO_FIELDS')
            fid = zero['formula_id']
            need(zero['id'] == 'i' + str(index) and type(fid) is int and 0 <= fid < len(forms), 'ZERO_ID_OUTPUT')
            need(type(zero['rule']) is str and zero['rule'] == zero['line']['rule'] and
                 colors[fid] == text(zero['line']['formula']), 'ZERO_NATIVE_LINE_BINDING')
            definitions.append(dict(id=text(['zero', zero['id']]), kind='ZERO', output=fid,
                premises=[], zero_id=zero['id'], variable=None, native_rule=zero['rule']))
        for fid, form in enumerate(forms):
            self.charge(1)
            need(type(form) is list and form and type(form[0]) is str, 'FORMULA_CONTAINER')
            if form[0] == 'imp':
                need(len(form) == 3 and text(form[1]) in ids and text(form[2]) in ids, 'IMPLICATION_REGISTRY_CLOSURE')
                left, right = ids[text(form[1])], ids[text(form[2])]
                mp.append([fid, left, right])
                definitions.append(dict(id=text(['mp', fid, left, right]), kind='MP', output=right,
                    premises=[left, fid], zero_id=None, variable=None, native_rule='mp'))
            elif form[0] == 'all':
                need(len(form) == 3 and type(form[1]) is str and text(form[2]) in ids, 'UNIVERSAL_REGISTRY_CLOSURE')
                body, variable = ids[text(form[2])], form[1]
                gen.append([fid, body, variable])
                definitions.append(dict(id=text(['gen', fid, body, variable]), kind='GEN', output=fid,
                    premises=[body], zero_id=None, variable=variable, native_rule='generalize'))
        need(text(mp) == text(compiled['mp_index']) and text(gen) == text(compiled['gen_index']),
             'COMPLETE_STRUCTURAL_NATIVE_INDICES')
        if len(definitions) > MAX_DEFINITIONS:
            raise Bound('ORACLE_DEFINITION_RESOURCE_BOUND')
        definitions.sort(key=lambda row: row['id'])
        need(len({d['id'] for d in definitions}) == len(definitions), 'UNIQUE_DEFINITIONS')
        self.definitions = {d['id']: d for d in definitions}
        core = {k: v for k, v in compiled.items() if k not in ('costs', 'scope')}
        self.charge(1 + len(text(core)) + len(text(generation)))
        core_hash = sha(core)
        need(generation['compiled_core_sha256'] == core_hash, 'GENERATION_COMPILED_CORE_BINDING')
        base_identity = sha(dict(schema='Z-anchored-proof-inventory-identity-v1',
            version='Z-ANCHORED-PROOF-PRODUCER-v1', compiled_core_sha256=core_hash, depth=self.depth))
        active = certificate if self.mode != 'BASE' else None
        self.absence_receipt = None
        if self.mode != 'BASE':
            need(type(active) is dict, 'FAILURE_CERTIFICATE_REQUIRED')
            self.charge(1 + len(text(active)))
            self.absence_receipt = absence_checker().verify(compiled, active)
            status = self.absence_receipt['status']
            if status == 'UNKNOWN':
                raise Bound('INDEPENDENT_ABSENCE_CHECK_RESOURCE')
            need(status == 'VERIFIED', 'INDEPENDENT_ABSENCE_CERTIFICATE_REJECTED')
            self.charge(1)
        requests = active['requests'] if active is not None else []
        self.negative = {tuple(pair) for pair in requests}
        self.failure_scope = active['scope_sha256'] if active else None
        levels, self.allowed = [], []
        for level in range(self.depth + 1):
            permitted = [[], [], []]
            for did, definition in self.definitions.items():
                self.charge(1)
                self.stats['definition_tests'] += 1
                premises = definition['premises']
                if premises and level == self.depth:
                    continue
                if self.mode == 'IFILTER' and any((p, self.depth - level - 1) in self.negative for p in premises):
                    continue
                permitted[len(premises)].append(did)
            self.allowed.append(tuple(tuple(sorted(group)) for group in permitted))
            arities = [len(group) for group in permitted]
            levels.append(dict(level=level, sites=1 << level, by_arity=arities,
                definitions_per_site=sum(arities), rows=(1 << level) * sum(arities)))
        body = dict(schema=SCHEMA, row_rule='CANONICAL_SITE_DEFINITION_UNIT_PORTS-v1',
            compiled_core_sha256=core_hash, registry_sha256=sha(compiled['logical_basis']),
            generation_sha256=sha(generation), definitions_sha256=sha(definitions),
            depth=self.depth, mode=self.mode, base_inventory_identity=base_identity,
            failure_scope_sha256=active['scope_sha256'] if active else None,
            failure_certificate_sha256=sha(active) if active else None,
            negative_requests=copy.deepcopy(requests), levels=levels,
            represented_rows=sum(level['rows'] for level in levels),
            represented_sites=(1 << (self.depth + 1)) - 1,
            scope='All canonical native producer rows at every depth-admissible binary address; IFILTER only removes checked-absent-premise rows. Logical ZERO truth and RF-profile completeness are separately admitted.')
        if self.mode == 'BASE':
            identity = base_identity
        elif self.mode == 'MARKS':
            identity = text(['FM-provider-v1', base_identity, 'MARKS', sha(requests), active['scope_sha256']])
        else:
            identity = text(['PFD-intensional-IFILTER-v1', base_identity, sha(body)])
        expected = dict(body, inventory_identity=identity)
        need(text(descriptor) == text(expected), 'EXACT_INTENSIONAL_DESCRIPTOR')
        self.descriptor, self.identity = copy.deepcopy(expected), identity
        self.rows, self.incidents = Rows(self), Incidents(self)

    def is_site(self, point):
        return type(point) is str and len(point) <= self.depth and all(c in '01' for c in point)

    def parse(self, cid):
        self.charge(1)
        need(type(cid) is str and len(cid) <= 4096, 'CID_STRING')
        self.charge(len(cid))
        try:
            parts = json.loads(cid)
        except (ValueError, RecursionError) as error:
            raise Rejected('CID_JSON') from error
        need(type(parts) is list and len(parts) == 2 and type(parts[0]) is str and
             type(parts[1]) is str and text(parts) == cid, 'CANONICAL_NATIVE_CID')
        site, did = parts
        need(self.is_site(site) and did in self.definitions, 'CID_SITE_OR_DEFINITION')
        native = self.definitions[did]
        need(not native['premises'] or len(site) < self.depth, 'PREMISE_OUTSIDE_HEIGHT')
        need(self.mode != 'IFILTER' or not any((fid, self.depth - len(site) - 1) in self.negative
             for fid in native['premises']), 'CID_OUTSIDE_CERTIFIED_FILTER_INVENTORY')
        return site, native

    def row(self, cid):
        if cid in self.row_cache:
            self.charge(1)
            self.stats['row_cache_hits'] += 1
            return self.row_cache[cid]
        site, native = self.parse(cid)
        if len(self.row_cache) >= self.max_cached_rows:
            raise Bound('ORACLE_ROW_CACHE_RESOURCE')
        points = [site] + [site + str(i) for i in range(len(native['premises']))]
        colors = [self.colors[fid] for fid in [native['output']] + native['premises']]
        marks = dict(zip(points, colors))
        if self.mode == 'MARKS':
            for fid in native['premises']:
                marks[text(['FM-port-v1', self.failure_scope, fid, self.depth - len(site) - 1])] = '1'
        row = dict(id=cid, t=[[p, 1] for p in points], m=[[p, v] for p, v in sorted(marks.items())])
        self.charge(1 + len(text(row)))
        self.row_cache[cid] = row
        self.stats['row_materializations'] += 1
        return row

    def incident(self, point):
        need(self.is_site(point), 'NATIVE_INCIDENT_POINT')
        if point in self.incident_cache:
            self.charge(1)
            self.stats['incident_cache_hits'] += 1
            return self.incident_cache[point]
        own = self.allowed[len(point)]
        total = sum(len(group) for group in own)
        parent_groups = []
        if point:
            parent = self.allowed[len(point) - 1]
            parent_groups = [parent[2]] + ([parent[1]] if point[-1] == '0' else [])
            total += sum(len(group) for group in parent_groups)
        if self.incident_entries + total > self.max_incident_entries:
            raise Bound('ORACLE_INCIDENT_CACHE_RESOURCE')
        result = set()
        for group in own:
            for did in group:
                self.charge(8 + 12 * (len(point) + len(did)))
                result.add(text([point, did]))
        if point:
            for group in parent_groups:
                for did in group:
                    self.charge(8 + 12 * (len(point) + len(did)))
                    result.add(text([point[:-1], did]))
        need(len(result) == total, 'DISTINCT_OWN_AND_PARENT_ROLES')
        result = frozenset(result)
        self.incident_cache[point] = result
        self.incident_entries += total
        self.stats['incident_materializations'] += 1
        return result

    def bind_model(self, model):
        marks = {'': self.goal_color}
        if self.mode == 'MARKS':
            for fid, remaining in self.descriptor['negative_requests']:
                marks[text(['FM-port-v1', self.failure_scope, fid, remaining])] = '0'
        expected = dict(schema='Z-growing-point-model-v1',
            version='PFD-intensional-IFILTER-v1' if self.mode == 'IFILTER' else 'Z-ANCHORED-PROOF-PRODUCER-v1',
            capacity=2, roots=[''], seed=dict(t=[['', 1]], m=[[p, v] for p, v in sorted(marks.items())]),
            inventory=dict(kind='CERTIFIED_INCIDENT', identity=self.identity))
        need(text(model) == text(expected), 'EXACT_NATIVE_MODEL_SEED_IDENTITY_BINDING')

    def receipt(self):
        return dict(status='VERIFIED', version=VERSION, descriptor_sha256=sha(self.descriptor),
            represented_rows=self.descriptor['represented_rows'],
            represented_sites=self.descriptor['represented_sites'],
            definitions=len(self.definitions), depth=self.depth, mode=self.mode,
            absence_check=self.absence_receipt, costs=dict(self.stats),
            cache_rows=len(self.row_cache), cache_incident_entries=self.incident_entries,
            hash_scope='INTENSIONAL_DESCRIPTOR_NOT_EXPANDED_ROW_STREAM',
            scope='Exact all-CID row and complete own/first/second-parent-role incidence reconstruction in this admitted finite native carrier. ZERO logical truth and complete RF profile generation require separate kernel/profile receipts; no target proof or unbounded completeness is established.')


def materialize_tiny(compiled, generation, descriptor, certificate=None, *, max_rows=2000):
    """Independent explicit equivalence fixture helper, never a deep-run input."""
    need(type(max_rows) is int and 0 < max_rows <= 20000, 'TINY_EXPLICIT_CAP')
    universe = Universe(compiled, generation, descriptor, certificate)
    if universe.descriptor['represented_rows'] > max_rows:
        raise Bound('TINY_EXPLICIT_MATERIALIZATION_REFUSED')
    rows = []
    for level, groups in enumerate(universe.allowed):
        for ordinal in range(1 << level):
            site = format(ordinal, '0%db' % level) if level else ''
            for group in groups:
                for did in group:
                    rows.append(universe.row(text([site, did])))
    rows.sort(key=lambda row: row['id'])
    need(len(rows) == universe.descriptor['represented_rows'], 'TINY_FULL_EXPANSION_CENSUS')
    return dict(status='COMPLETE', universe=rows, rows=len(rows),
        descriptor_sha256=sha(descriptor), expanded_universe_sha256=sha(rows),
        scope='Tiny full expansion for independent explicit/intensional equivalence qualification only.')


def verify_descriptor(compiled, generation, descriptor, certificate=None, model=None, *,
                      max_items=100000000, wall_seconds=30.0):
    """Independent compact schema/model admission; does not expand the universe."""
    started, used, universe = time.perf_counter(), 0, None
    try:
        need(type(max_items) is int and max_items > 0 and type(wall_seconds) in (int, float)
             and math.isfinite(wall_seconds) and wall_seconds > 0, 'ADMISSION_RESOURCE_LIMITS')
        def charge(amount=1):
            nonlocal used
            used += amount
            if used > max_items:
                raise Bound('ADMISSION_ITEM_BOUND')
            if time.perf_counter() - started >= wall_seconds:
                raise Bound('ADMISSION_WALL_BOUND')
        pending = [(value, 0) for value in (compiled, generation, descriptor, certificate, model)]
        while pending:
            value, depth = pending.pop()
            charge()
            if depth > 256:
                raise Bound('ADMISSION_JSON_DEPTH')
            if value is None or type(value) in (bool, str, int):
                if type(value) is str:
                    charge(len(value))
                elif type(value) is int:
                    need(value.bit_length() <= 256, 'ADMISSION_INTEGER_BITS')
            elif type(value) is float:
                need(math.isfinite(value), 'FINITE_JSON')
            elif type(value) is list:
                charge(len(value))
                pending.extend((item, depth + 1) for item in value)
            elif type(value) is dict:
                need(all(type(k) is str for k in value), 'JSON_OBJECT_KEYS')
                charge(2 * len(value))
                pending.extend((key, depth + 1) for key in value)
                pending.extend((item, depth + 1) for item in value.values())
            else:
                raise Rejected('NATIVE_JSON_REQUIRED')
        universe = Universe(compiled, generation, descriptor, certificate, charge=charge)
        if model is not None:
            universe.bind_model(model)
        receipt = universe.receipt()
    except Rejected as error:
        receipt = dict(status='REJECTED', reason=str(error))
    except (Bound, MemoryError) as error:
        receipt = dict(status='UNKNOWN', reason=str(error) or type(error).__name__)
    except (ValueError, KeyError, TypeError, IndexError, RecursionError) as error:
        receipt = dict(status='REJECTED', reason='MALFORMED_NATIVE_CONTEXT:' + type(error).__name__ + ':' + str(error))
    receipt.update(items=used, seconds=time.perf_counter() - started)
    return receipt
