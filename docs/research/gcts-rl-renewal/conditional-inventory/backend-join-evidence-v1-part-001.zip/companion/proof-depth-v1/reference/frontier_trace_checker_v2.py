"""Independent whole-frontier reader with finite/intensional universe support.

No engine/provider/logic imports or execution. The complete immutable universe
is an externally qualified premise. Indexed packets are joined to actual load
contexts; packets precede selected/excluded filtering. This checks point-trace
conformance, not native logical truth or an unrestricted nonprovability claim.
"""
import copy
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import time

VERSION='Independent-IP-frontier-trace-checker-v2-intensional'
NATIVE_UNIVERSE_PIN='73f184963f6f4e4a70a52d4cb6c9560b27460f56eb39e3af887d32d5a28d1916'
_NATIVE=None
ENGINE='IP-GROWING-POINT-SEARCH-v2'
SNAP_FIELDS={'Q','totals','selected','marks','excluded','eligible','domains','forward','reverse','placements','loaded','dependencies','edge_count'}
EVENT_FIELDS={'seq','kind','point','candidate','data'}
RESULT_FIELDS={'schema','version','status','reason','model_sha256','selected','certificate','entry_state','final_state','restored_state','state_hashes','events','event_extent','rollback_records','rollback_extent','stats','limits','provider_evidence'}

class Rejected(Exception):pass
class Incomplete(Exception):pass
class Budget(Exception):pass

def need(ok,reason):
    if not ok:raise Rejected(reason)
def integer(value,minimum=0):return type(value) is int and value>=minimum and value.bit_length()<=256
def wire(value):return (json.dumps(value,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')
def sha(value):return hashlib.sha256(wire(value)).hexdigest()
def same(a,b):return wire(a)==wire(b)
def fields(value,names,reason):need(type(value) is dict and set(value)==set(names),reason)
def hash_string(value):return type(value) is str and len(value)==64 and all(c in '0123456789abcdef' for c in value)

def native_module():
    global _NATIVE
    if _NATIVE is None:
        path=Path(__file__).resolve().parent/'native_universe_checker_v1.py'
        need(hashlib.sha256(path.read_bytes()).hexdigest()==NATIVE_UNIVERSE_PIN,'NATIVE_UNIVERSE_SOURCE_PIN')
        spec=importlib.util.spec_from_file_location('pfd_frontier_native_universe',path)
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);_NATIVE=module
    return _NATIVE

class Meter:
    def __init__(self,items,seconds):
        need(integer(items,1),'CHECKER_MAX_ITEMS');need(type(seconds) in (int,float) and math.isfinite(seconds) and seconds>0,'CHECKER_WALL_SECONDS')
        self.limit=items;self.deadline=time.perf_counter()+seconds;self.used=0
    def tick(self,n=1):
        self.used+=n
        if self.used>self.limit:raise Budget('VERIFIER_MAX_ITEMS')
        if time.perf_counter()>=self.deadline:raise Budget('VERIFIER_WALL_SECONDS')
    def json(self,value):
        pending=[(value,0)]
        while pending:
            v,d=pending.pop();self.tick()
            if d>256:raise Budget('VERIFIER_JSON_DEPTH')
            if v is None or type(v) in (bool,str,int):
                if type(v) is int:need(v.bit_length()<=256,'INTEGER_BITS')
                elif type(v) is str:self.tick(len(v))
            elif type(v) is float:need(math.isfinite(v),'NONFINITE_METADATA')
            elif type(v) is list:
                self.tick(len(v));pending.extend((x,d+1) for x in v)
            elif type(v) is dict:
                need(all(type(k) is str for k in v),'JSON_KEYS');self.tick(2*len(v))
                pending.extend((k,d+1) for k in v);pending.extend((x,d+1) for x in v.values())
            else:raise Rejected('NON_NATIVE_JSON')

class Checker:
    def __init__(self,model,universe,observations,result,meter,native_context=None,oracle_limits=None):
        self.meter=meter;self.raw_model=model;self.observations=observations;self.result=result
        self.counts=dict(observations_checked=0,graphs_checked=0,queries_checked=0,packet_rows_checked=0,registrations_reconstructed=0,provider_loads=0,placements_replayed=0,forced=0,branches=0,dead=0,exclusions=0,solutions=0,exhausted=0,rollback_records_checked=0,nonlexical_orders=0,ordering_request_gap=0)
        self.gaps=[];self.failures=[];self.stack=[];self.failed=None;self.pending=None;self.terminal=None;self.qindex=0;self.expected_rollbacks=[]
        fields(model,('schema','version','capacity','roots','seed','inventory'),'MODEL_FIELDS')
        need(model['schema']=='Z-growing-point-model-v1' and type(model['version']) is str and bool(model['version']),'MODEL_VERSION')
        self.capacity=model['capacity'];need(integer(self.capacity,1),'CAPACITY')
        self.native_oracle=None
        if type(universe) is dict:
            fields(native_context,('compiled','generation','certificate'),'NATIVE_CONTEXT_FIELDS')
            if oracle_limits is None:oracle_limits={}
            need(type(oracle_limits) is dict and set(oracle_limits)<= {'max_cached_rows','max_incident_entries'},'ORACLE_LIMIT_FIELDS')
            self.native_oracle=native_module().Universe(native_context['compiled'],native_context['generation'],
                universe,native_context['certificate'],charge=meter.tick,**oracle_limits)
            self.rows=self.native_oracle.rows;self.incident=self.native_oracle.incidents;self.universe=None
        else:
            need(type(universe) is list,'UNIVERSE_LIST');self.rows={}
            for raw in universe:
                row=self.placement(raw);need(row['id'] not in self.rows,'DUPLICATE_UNIVERSE_CID');self.rows[row['id']]=row
            self.universe=[self.rows[c] for c in sorted(self.rows)];self.incident={}
            for c,row in self.rows.items():
                for p,n in row['t']:self.incident.setdefault(p,set()).add(c)
        need(type(model['roots']) is list and all(type(p) is str for p in model['roots']) and len(set(model['roots']))==len(model['roots']),'ROOTS')
        fields(model['seed'],('t','m'),'SEED_FIELDS');seed=dict(t=self.point_rows(model['seed']['t'],False,True),m=self.point_rows(model['seed']['m'],True))
        inv=model['inventory'];need(type(inv) is dict,'INVENTORY')
        if self.native_oracle is not None:need(inv.get('kind')=='CERTIFIED_INCIDENT','INTENSIONAL_MODEL_REQUIRES_INDEXED_INVENTORY')
        if inv.get('kind')=='EXPLICIT':
            fields(inv,('kind','placements'),'EXPLICIT_FIELDS');need(type(inv['placements']) is list,'EXPLICIT_ROWS')
            declared=[self.placement(x) for x in inv['placements']];declared.sort(key=lambda r:r['id'])
            need(len({r['id'] for r in declared})==len(declared) and same(declared,self.universe),'EXPLICIT_UNIVERSE_EXACT_EQUALITY')
            inventory=dict(kind='EXPLICIT',placements=declared)
        else:
            fields(inv,('kind','identity'),'INCIDENT_FIELDS');need(inv['kind']=='CERTIFIED_INCIDENT' and type(inv['identity']) is str and bool(inv['identity']),'INCIDENT_IDENTITY')
            inventory=dict(kind=inv['kind'],identity=inv['identity'])
        self.model=dict(schema=model['schema'],version=model['version'],capacity=self.capacity,roots=sorted(model['roots']),seed=seed,inventory=inventory)
        if self.native_oracle is not None:self.native_oracle.bind_model(self.model)
        fields(result,RESULT_FIELDS,'RESULT_FIELDS');need(result['schema']=='Z-growing-point-search-result-v1' and result['version']==ENGINE,'RESULT_VERSION')
        need(result['status'] in ('SAT','UNSAT','UNKNOWN'),'RESULT_STATUS')
        if result['model_sha256'] is not None:need(result['model_sha256']==sha(self.model),'MODEL_HASH')
        elif result['status']!='UNKNOWN':raise Rejected('MISSING_MODEL_HASH')
        self.validate_limits(result['limits'])
        fields(result['state_hashes'],('entry','final','restored'),'STATE_HASH_FIELDS')
        for name in ('entry','final','restored'):
            value=result[name+'_state'];digest=result['state_hashes'][name]
            need((value is None and digest is None) or (value is not None and digest==sha(value)),'STATE_HASH_'+name)
        need(type(result['events']) is list and type(result['rollback_records']) is list and type(observations) is list,'EVIDENCE_LISTS')
        self.events_complete=self.extent(result['events'],result['event_extent'],'BOUNDED_PREFIX_COMPLETE_EMITTED_STREAM_HASH','events')
        self.rollbacks_complete=self.extent(result['rollback_records'],result['rollback_extent'],'BOUNDED_PREFIX_COMPLETE_EMITTED_STREAM_HASH','rollback')
        pe=result['provider_evidence'];fields(pe,('mode','total','retained','sha256','scope','records','costs'),'PROVIDER_EVIDENCE_FIELDS')
        need(type(pe['records']) is list,'QUERY_RECORDS');self.queries=pe['records'];self.mode=pe['mode']
        self.queries_complete=self.extent(self.queries,{k:pe[k] for k in ('total','retained','sha256','scope')},'BOUNDED_PREFIX_OF_COMPLETED_VALIDATED_INDEX_QUERIES','query')
        if inventory['kind']=='EXPLICIT':need(self.mode in ('EXPLICIT','UNINITIALIZED'),'EXPLICIT_PROVIDER_MODE')
        else:need(self.mode in ('INDEXED_CURRENT_TM_COMPATIBLE','EAGER_ALL_POTENTIAL','UNINITIALIZED'),'INCIDENT_PROVIDER_MODE')
        if self.mode!='INDEXED_CURRENT_TM_COMPATIBLE':need(pe['total']==0 and pe['records']==[],'NONINDEXED_QUERY_JOURNAL')
        self.state=self.seed_state();self.entry=None

    def point_rows(self,raw,marking,seed=False):
        need(type(raw) is list,'POINT_ROWS');seen=set();out=[]
        for row in raw:
            self.meter.tick();need(type(row) is list and len(row)==2 and type(row[0]) is str and row[0] not in seen,'POINT_ROW')
            p,v=row;seen.add(p)
            need(type(v) is str if marking else integer(v,0 if seed else 1) and v<=self.capacity,'POINT_VALUE')
            out.append([p,v])
        return sorted(out,key=lambda r:r[0])
    def placement(self,raw):
        self.meter.tick();fields(raw,('id','t','m'),'PLACEMENT_FIELDS');need(type(raw['id']) is str and bool(raw['id']),'CID')
        t=self.point_rows(raw['t'],False);need(bool(t),'EMPTY_POSITIVE_SUPPORT')
        return dict(id=raw['id'],t=t,m=self.point_rows(raw['m'],True))
    def validate_limits(self,v):
        fields(v,('wall_seconds','max_work','max_nodes','max_events','max_rollback_records','max_candidates','max_points'),'LIMITS_FIELDS')
        need(type(v['wall_seconds']) in (int,float) and math.isfinite(v['wall_seconds']) and 0<v['wall_seconds']<=3600,'WALL_LIMIT')
        for k in v:
            if k!='wall_seconds':need(integer(v[k],1 if k in ('max_work','max_candidates','max_points') else 0),'INTEGER_LIMIT')
    def extent(self,records,extent,scope,name):
        fields(extent,('total','retained','sha256','scope'),'EXTENT_FIELDS_'+name)
        need(integer(extent['total']) and integer(extent['retained']) and extent['retained']==len(records)<=extent['total'] and extent['scope']==scope and hash_string(extent['sha256']),'EXTENT_'+name)
        complete=extent['total']==len(records)
        if complete:
            h=hashlib.sha256()
            for row in records:self.meter.tick();h.update(wire(row))
            need(h.hexdigest()==extent['sha256'],'STREAM_HASH_'+name)
        else:self.gaps.append('TRUNCATED_'+name.upper()+'_JOURNAL')
        return complete
    def seed_state(self):
        t=dict(self.model['seed']['t']);q={p:0 for p,n in t.items() if n}
        for p in self.model['roots']:q[p]=0;t.setdefault(p,0)
        return dict(T=t,Q=q,M={p:(v,1) for p,v in self.model['seed']['m']},selected={},sequence=[],excluded=set(),registered=set(),loaded=set())
    def compatible(self,c):
        row=self.rows[c];self.meter.tick(1+len(row['t'])+len(row['m']))
        return all(self.state['T'].get(p,0)+u<=self.capacity for p,u in row['t']) and all(p not in self.state['M'] or self.state['M'][p][0]==v for p,v in row['m'])
    def legal(self,c):return c not in self.state['selected'] and c not in self.state['excluded'] and self.compatible(c)
    def register(self,c):
        if c not in self.state['registered']:
            if self.model['inventory']['kind']=='CERTIFIED_INCIDENT':need(all(p not in self.state['loaded'] for p,u in self.rows[c]['t']),'NEW_CID_TOUCHES_EXHAUSTED_POINT')
            self.state['registered'].add(c);self.counts['registrations_reconstructed']+=1
    def missing(self,reason):
        if self.result['status']=='UNKNOWN' or self.gaps:raise Incomplete(reason)
        raise Rejected(reason)
    def load_point(self,p):
        if p in self.state['loaded']:return
        if self.model['inventory']['kind']=='CERTIFIED_INCIDENT':
            self.counts['provider_loads']+=1
            potential=self.incident.get(p,set())
            if self.mode=='INDEXED_CURRENT_TM_COMPATIBLE':
                if self.qindex>=len(self.queries):self.missing('MISSING_CONTEXT_JOINED_QUERY')
                packet=self.queries[self.qindex];self.qindex+=1
                fields(packet,('query','reply'),'QUERY_PACKET_FIELDS');query=packet['query'];reply=packet['reply']
                expected=dict(schema='IP-current-tm-incident-query-v1',inventory_identity=self.model['inventory']['identity'],point=p,capacity=self.capacity,totals=[[x,n] for x,n in sorted(self.state['T'].items())],marks=[[x,v] for x,(v,n) in sorted(self.state['M'].items())])
                need(same(query,expected),'QUERY_ACTUAL_CONTEXT_AND_POINT')
                fields(reply,('point','context_sha256','complete','placements','certificate'),'QUERY_REPLY_FIELDS')
                need(reply['point']==p and reply['context_sha256']==sha(query) and reply['complete'] is True and type(reply['placements']) is list,'QUERY_REPLY_BINDING')
                compatible={c for c in potential if self.compatible(c)};ids=[]
                for raw in reply['placements']:
                    row=self.placement(raw);c=row['id'];need(c in self.rows and same(row,self.rows[c]) and same(raw,row),'QUERY_IMMUTABLE_CANONICAL_ROW')
                    ids.append(c);self.counts['packet_rows_checked']+=1
                need(len(ids)==len(set(ids)) and set(ids)==compatible,'COMPLETE_PURE_TM_PACKET_BEFORE_INVENTORY_FILTER')
                certificate=dict(scope='COMPLETE_CURRENT_TM_COMPATIBLE_INCIDENT_SET',potential_count=len(potential),compatible_count=len(compatible))
                need(same(reply['certificate'],certificate),'EXACT_PACKET_COUNTS')
                for c in ids:self.register(c)
                self.counts['queries_checked']+=1
            elif self.mode=='EAGER_ALL_POTENTIAL':
                for c in sorted(potential):self.register(c)
            else:self.missing('UNINITIALIZED_PROVIDER')
        self.state['loaded'].add(p)
    def initialize(self):
        if self.model['inventory']['kind']=='EXPLICIT':
            for c in self.rows:self.register(c)
        for p in sorted(self.state['Q']):
            if self.state['T'].get(p,0)<self.capacity:self.load_point(p)
        self.entry=self.snapshot()
    def domains(self):
        out={}
        for p in sorted(self.state['Q']):
            self.meter.tick()
            if self.state['T'].get(p,0)<self.capacity:
                ids=sorted(c for c in self.incident.get(p,()) if self.legal(c))
                need(all(c in self.state['registered'] for c in ids),'UNREGISTERED_LEGAL_FRONTIER_CANDIDATE')
                out[p]=ids
        return out
    def snapshot(self):
        s=self.state;domains=self.domains();eligible=sorted(c for c in s['registered'] if self.legal(c));tdep={};mdep={};forward=[];reverse={}
        for c in sorted(s['registered']):
            self.meter.tick()
            for p,n in self.rows[c]['t']:tdep.setdefault(p,[]).append(c)
            for p,v in self.rows[c]['m']:mdep.setdefault(p,[]).append(c)
        for p,ids in domains.items():
            for c in ids:
                u=dict(self.rows[c]['t'])[p];forward.append([p,c,u]);reverse.setdefault(c,[]).append([p,u])
        return dict(Q=[[p,g] for p,g in sorted(s['Q'].items())],totals=[[p,n] for p,n in sorted(s['T'].items())],selected=[[c,g] for c,g in sorted(s['selected'].items())],marks=[[p,v,n] for p,(v,n) in sorted(s['M'].items())],excluded=sorted(s['excluded']),eligible=eligible,domains=[[p,ids] for p,ids in domains.items()],forward=forward,reverse=[[c,ps] for c,ps in sorted(reverse.items())],placements=[self.rows[c] for c in sorted(s['registered'])],loaded=sorted(s['loaded']),dependencies=dict(t=[[p,ids] for p,ids in sorted(tdep.items())],m=[[p,ids] for p,ids in sorted(mdep.items())]),edge_count=len(forward))
    def graph_check(self,supplied):
        fields(supplied,SNAP_FIELDS,'SNAPSHOT_FIELDS');expected=self.snapshot();need(same(supplied,expected),'WHOLE_GRAPH_VALUES_GENERATIONS_REGISTRATION_DEPENDENCIES')
        self.counts['graphs_checked']+=1;return expected
    def decision(self):
        domains=self.domains();q=self.state['Q'];dead=[p for p,ids in domains.items() if not ids]
        if dead:return 'DEAD',min(dead,key=lambda p:(q[p],p)),domains
        forced=[p for p,ids in domains.items() if len(ids)==1]
        if forced:return 'FORCED',min(forced,key=lambda p:(q[p],p)),domains
        if not domains:return 'SOLUTION',None,domains
        return 'BRANCH',min(domains,key=lambda p:(q[p],len(domains[p]),p)),domains
    def place(self,c):
        need(c in self.rows and c in self.state['registered'] and self.legal(c),'PLACEMENT_GLOBAL_LEGALITY')
        s=self.state;row=self.rows[c];existing=[s['Q'][p] for p,n in row['t'] if p in s['Q']];need(bool(existing),'DISCONNECTED_NONROOT_PLACEMENT')
        gen=1+min(existing);s['selected'][c]=gen;s['sequence'].append(c)
        for p,n in row['t']:
            s['T'][p]=s['T'].get(p,0)+n;need(s['T'][p]<=self.capacity,'OVER_CAPACITY')
            s['Q'][p]=min(s['Q'].get(p,gen),gen)
        for p,v in row['m']:
            old=s['M'].get(p);need(old is None or old[0]==v,'SELECTED_MARK_CONFLICT');s['M'][p]=(v,1 if old is None else old[1]+1)
        for p,n in row['t']:
            if s['T'][p]<self.capacity:self.load_point(p)
        return gen
    def event(self,event,snapshot):
        fields(event,EVENT_FIELDS,'EVENT_FIELDS');kind=event['kind'];need(type(kind) is str,'EVENT_KIND')
        if self.terminal is not None:raise Rejected('EVENT_AFTER_TERMINAL')
        if kind=='READY':
            need(self.counts['observations_checked']==0 and event['point'] is None and event['candidate'] is None and same(event['data'],{}),'READY_FORMAT')
        elif kind=='PLACED':
            need(self.pending is not None,'PLACED_WITHOUT_REFERENCE_DECISION');p,c,forced=self.pending
            need(event['point']==p and event['candidate']==c,'PLACED_DECISION_BINDING');gen=self.place(c)
            need(same(event['data'],dict(generation=gen,forced=forced)),'PLACED_GENERATION_AND_KIND')
            self.pending=None;self.counts['placements_replayed']+=1
        elif kind=='EXCLUDE':
            need(self.failed is not None and bool(self.stack),'PHANTOM_OR_UNKNOWN_EXCLUSION')
            frame=self.stack.pop();need(self.failed['frame'] is frame,'EXCLUSION_BRANCH_STACK')
            need(event['point'] is None and event['candidate']==frame['candidate'] and same(event['data'],{}),'EXCLUSION_FAILED_CHILD_ID')
            self.expected_rollbacks.append(dict(reason='FAILED_CHILD',selected_before=len(self.state['selected']),selected_after=len(frame['state']['selected'])))
            self.state=copy.deepcopy(frame['state']);c=frame['candidate'];need(c not in self.state['selected'] and c not in self.state['excluded'],'EXCLUSION_PARENT_CONTEXT')
            self.state['excluded'].add(c);self.failures.append(dict(cid=c,parent_sha256=frame['parent_sha256'],dead_sha256=self.failed['dead_sha256'],dead_event=self.failed['seq'],exclude_event=event['seq']))
            self.failed=None;self.counts['exclusions']+=1
        elif kind=='EXHAUSTED':
            need(self.failed is not None and not self.stack and event['point'] is None and event['candidate'] is None and same(event['data'],{}),'UNJUSTIFIED_EXHAUSTION')
            self.terminal='UNSAT';self.counts['exhausted']+=1
        else:
            need(self.pending is None and self.failed is None,'MISSING_PLACED_OR_EXCLUDE_EVENT')
            expected,p,domains=self.decision();need(kind==expected and event['point']==p,'GLOBAL_REFERENCE_SCHEDULER')
            if kind=='DEAD':
                need(event['candidate'] is None and same(event['data'],dict(generation=self.state['Q'][p])),'DEAD_FORMAT')
                self.failed=dict(frame=self.stack[-1] if self.stack else None,dead_sha256=sha(self.snapshot()),seq=event['seq']);self.counts['dead']+=1
            elif kind=='FORCED':
                c=domains[p][0];need(event['candidate']==c and same(event['data'],dict(generation=self.state['Q'][p])),'FORCED_DOMAIN')
                self.pending=(p,c,True);self.counts['forced']+=1
            elif kind=='BRANCH':
                need(event['candidate'] is None,'BRANCH_CANDIDATE_FIELD');fields(event['data'],('generation','legal','order'),'BRANCH_DATA')
                data=event['data'];order=data['order'];need(same(data['generation'],self.state['Q'][p]) and same(data['legal'],domains[p]),'BRANCH_FULL_DOMAIN')
                need(type(order) is list and all(type(c) is str for c in order) and len(order)==len(set(order))==len(domains[p]) and set(order)==set(domains[p]),'BRANCH_FULL_FALLBACK_PERMUTATION')
                self.counts['nonlexical_orders']+=order!=domains[p];c=order[0]
                self.stack.append(dict(candidate=c,state=copy.deepcopy(self.state),parent_sha256=sha(self.snapshot())));self.pending=(p,c,False);self.counts['branches']+=1
            else:
                need(kind=='SOLUTION' and event['candidate'] is None and same(event['data'],{}),'SOLUTION_FORMAT');self.terminal='SAT';self.counts['solutions']+=1
        self.graph_check(snapshot);self.counts['observations_checked']+=1
    def certificate(self):
        s=self.state;points=set(s['Q']);need(all(s['T'].get(p,0)==self.capacity for p in points),'CERTIFICATE_ACTIVE_EXACTNESS')
        return dict(capacity=self.capacity,roots=self.model['roots'],seed=self.model['seed'],placements=[self.rows[c] for c in sorted(s['selected'])],totals=[[p,s['T'].get(p,0)] for p in sorted(points)],marks=[[p,v,n] for p,(v,n) in sorted(s['M'].items())])
    def rollback_check(self,complete):
        rows=self.result['rollback_records'];expected=list(self.expected_rollbacks)
        if complete:expected.append(dict(reason='FINAL_RESTORE',selected_before=len(self.state['selected']),selected_after=0))
        if complete:need(len(rows)==len(expected),'ROLLBACK_CARDINALITY')
        for i,row in enumerate(rows):
            fields(row,('reason','from_trail','to_trail','undone','selected_before','selected_after'),'ROLLBACK_ROW_FIELDS')
            need(row['reason'] in ('FAILED_CHILD','FINAL_RESTORE') and all(integer(row[k]) for k in row if k!='reason'),'ROLLBACK_TYPES')
            need(row['from_trail']>=row['to_trail'] and row['undone']==row['from_trail']-row['to_trail'],'ROLLBACK_ARITHMETIC')
            if row['reason']=='FINAL_RESTORE':need(i==len(rows)-1 and row['to_trail']==0 and row['selected_after']==0,'FINAL_RESTORE_ROW')
            if i<len(expected):need(all(same(row[k],v) for k,v in expected[i].items()),'ROLLBACK_PARENT_SELECTED_BINDING')
            self.counts['rollback_records_checked']+=1
    def run(self):
        self.initialize()
        if self.result['entry_state'] is None:raise Incomplete('NO_COMPLETE_ENTRY_CHECKPOINT')
        self.graph_check(self.result['entry_state']);need(same(self.entry,self.result['entry_state']),'ENTRY_STATE')
        need(same(self.result['restored_state'],self.entry),'EXACT_FINAL_ENTRY_RESTORATION')
        records=self.result['events'];obs=self.observations;total=self.result['event_extent']['total']
        need(len(obs)<=total,'EXCESS_AUDIT_CALLBACKS')
        for i,item in enumerate(obs):
            self.meter.tick();fields(item,('event','state'),'OBSERVATION_FIELDS');event=item['event'];fields(event,EVENT_FIELDS,'EVENT_FIELDS')
            if not integer(event['seq']) or event['seq']!=i:raise Incomplete('MISSING_OR_NONCHRONOLOGICAL_AUDIT_CALLBACK')
            if i<len(records):need(same(event,records[i]),'RETAINED_EVENT_AUDIT_JOIN')
            if i==0:need(event['kind']=='READY','INITIAL_READY_REQUIRED')
            self.event(event,item['state'])
        if len(obs)==total:
            h=hashlib.sha256()
            for item in obs:h.update(wire(item['event']))
            need(h.hexdigest()==self.result['event_extent']['sha256'],'FULL_AUDIT_EVENT_STREAM_HASH')
        else:self.gaps.append('AUDIT_CALLBACK_PREFIX_ONLY')
        complete=self.result['status']!='UNKNOWN' and len(obs)==total and self.rollbacks_complete and self.queries_complete
        self.rollback_check(complete)
        if self.qindex!=len(self.queries):
            if self.result['status']!='UNKNOWN':raise Rejected('UNJOINED_PROVIDER_QUERY_SUFFIX')
            self.gaps.append('UNJOINED_RESOURCE_INTERRUPTED_QUERY_SUFFIX')
        if self.mode=='EAGER_ALL_POTENTIAL' and self.counts['provider_loads']:
            self.gaps.append('EAGER_RAW_PROVIDER_PACKET_WIRE_NOT_RETAINED')
        if self.result['status']=='UNKNOWN':
            need(self.result['selected']==[] and self.result['certificate'] is None and self.result['final_state'] is None,'UNKNOWN_MUST_NOT_CLAIM_SOLUTION')
            raise Incomplete('RESOURCE_LIMITED_RESULT_PREFIX_ONLY')
        if self.gaps or len(obs)!=total:raise Incomplete('INCOMPLETE_RETAINED_EVIDENCE')
        need(self.terminal==self.result['status'] and self.pending is None,'MISSING_TERMINAL_TRACE')
        need(same(self.result['final_state'],self.snapshot()),'FINAL_STATE_TRACE_JOIN')
        if self.terminal=='SAT':
            need(self.result['reason']=='FINITE_ACTIVE_OBLIGATIONS_EXACT','SAT_REASON');need(same(self.result['selected'],sorted(self.state['selected'])) and same(self.result['certificate'],self.certificate()),'EXACT_SELECTED_CERTIFICATE')
        else:need(self.result['reason']=='EXHAUSTED_DECLARED_FINITE_INVENTORY' and self.result['selected']==[] and self.result['certificate'] is None and not self.stack,'UNSAT_FINITE_EXHAUSTION')
        stats=self.result['stats'];need(type(stats) is dict,'STATS')
        expected=dict(events_total=total,audit_calls=len(obs),placements=self.counts['placements_replayed'],forced=self.counts['forced'],branches=self.counts['branches'],dead_ends=self.counts['dead'],backtracks=self.counts['exclusions'],exclusions=self.counts['exclusions'],rollbacks_total=len(self.result['rollback_records']),rollback_edits=sum(r['undone'] for r in self.result['rollback_records']),candidate_registrations=self.counts['registrations_reconstructed'])
        for k,v in expected.items():need(same(stats.get(k),v),'TRACE_STAT_'+k)
        calls=stats.get('ordering_calls');need(integer(calls) and calls in (0,self.counts['branches']),'ORDERING_CALL_COVERAGE');self.counts['ordering_request_gap']=calls
        self.meter.tick()
        return dict(status='VERIFIED',reason='COMPLETE_POINT_GRAPH_EVENT_PROVIDER_AND_RESULT_JOIN',run_status=self.result['status'],counts=self.counts,model_sha256=sha(self.model),universe_sha256=sha(self.universe) if self.native_oracle is None else None,universe_descriptor_sha256=None if self.native_oracle is None else sha(self.native_oracle.descriptor),universe_hash_scope='EXPANDED_CANONICAL_ROWS' if self.native_oracle is None else 'INTENSIONAL_DESCRIPTOR_NOT_EXPANDED_ROW_STREAM',failure_provenance=self.failures,gaps=[],scope='Exact finite point-trace conformance conditional on complete qualified universe. No native logical truth, rooted proof decoding or unrestricted nonprovability claim.',metadata_scope='Wall/work metrics are nonsemantic; rollback trail lengths are checked arithmetically and bound to independently restored parent selections, not reverse-engineered instruction counts.')

def verify(model,universe,observations,result,*,native_context=None,oracle_limits=None,max_items=10000000,wall_seconds=30.0):
    started=time.perf_counter();checker=None;meter=None
    try:
        meter=Meter(max_items,wall_seconds)
        for value in (model,universe,observations,result,native_context,oracle_limits):meter.json(value)
        checker=Checker(model,universe,observations,result,meter,native_context,oracle_limits);answer=checker.run()
    except Rejected as error:answer=dict(status='REJECTED',reason=str(error))
    except (Incomplete,Budget) as error:answer=dict(status='UNKNOWN',reason=str(error),verified_prefix_only=True)
    except MemoryError:answer=dict(status='UNKNOWN',reason='VERIFIER_MEMORY_RESOURCE',verified_prefix_only=True)
    except (KeyError,TypeError,ValueError,IndexError,RecursionError) as error:answer=dict(status='REJECTED',reason='MALFORMED_INPUT:'+type(error).__name__+': '+str(error))
    except Exception as error:
        if _NATIVE is not None and isinstance(error,_NATIVE.Rejected):answer=dict(status='REJECTED',reason='NATIVE_UNIVERSE:'+str(error))
        elif _NATIVE is not None and isinstance(error,_NATIVE.Bound):answer=dict(status='UNKNOWN',reason='NATIVE_UNIVERSE:'+str(error),verified_prefix_only=True)
        else:raise
    answer.update(version=VERSION,seconds=time.perf_counter()-started,items=0 if meter is None else meter.used)
    if checker is not None:
        answer.setdefault('counts',checker.counts);answer.setdefault('gaps',checker.gaps)
        if checker.native_oracle is not None:answer['intensional_universe_admission']=checker.native_oracle.receipt()
    answer.setdefault('counts',{})
    return answer
