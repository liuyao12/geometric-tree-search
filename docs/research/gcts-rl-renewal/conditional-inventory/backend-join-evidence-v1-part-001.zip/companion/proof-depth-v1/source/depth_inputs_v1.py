"""Fresh depth inputs and compact admissions; inert until explicit API calls.

Never calls the prior prepare() or deep explicit _universe(). No archived proof,
compiled extension, failure table, library or policy is read.
"""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import time

ROOT = Path(__file__).resolve().parents[1]
HELPER_PIN = 'b1e3ea3d9e6d30a6aada9d125b4b336dbdae87289ccaa4dec5d7dbf88daa6920'
PROFILE_LIMITS = dict(max_items=100000000, max_work=1000000000, wall_seconds=30)
DESCRIPTOR_LIMITS = dict(max_items=100000000, wall_seconds=30)
ACQUISITION_SECONDS = 15
_LOCAL = {}


def text(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(',', ':'), allow_nan=False)


def sha(value):
    return hashlib.sha256((text(value) + '\n').encode('ascii')).hexdigest()


def local(name, relative):
    if name not in _LOCAL:
        path = ROOT / relative
        if name == 'helper':
            assert hashlib.sha256(path.read_bytes()).hexdigest() == HELPER_PIN
        spec = importlib.util.spec_from_file_location('pdi_' + name, path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        _LOCAL[name] = module
    return _LOCAL[name]


def dependencies():
    helper = local('helper', 'source/transfer_inputs_v1.py')
    return helper, helper._modules(), local('adapter', 'source/native_universe_v1.py'), local(
        'universe_reference', 'reference/native_universe_checker_v1.py')


def prepare(declaration):
    started = boundary = time.perf_counter()
    stages = {}
    def end(name):
        nonlocal boundary
        now = time.perf_counter()
        stages[name] = now - boundary
        boundary = now
    def refusal(status, stage, **evidence):
        now = time.perf_counter()
        stages['interrupted_stage_seconds'] = now - boundary
        return dict(status=status, id=declaration['id'], stage=stage,
            preparation_seconds=now-started, stage_seconds=stages, **evidence,
            scope='No partial model/descriptor has been admitted for target search.')
    helper, modules, adapter, reference = dependencies()
    end('dependency_loading_seconds')
    try:
        compiled, generation = modules['finite_basis_v1'].compile_case(declaration)
    except modules['finite_basis_v1'].BasisLimit as error:
        return refusal('UNKNOWN', 'COMPILATION', receipt=error.receipt())
    end('compile_seconds')
    profile = modules['rf_catalogue_checker_v1'].verify(declaration, compiled, generation, **PROFILE_LIMITS)
    end('independent_profile_seconds')
    if profile['status'] != 'VERIFIED':
        return refusal(profile['status'], 'RF_PROFILE', receipt=profile)
    definitions = helper._definitions(compiled)
    depth = declaration['depth']
    model, provider, factory = modules['indexed_proof_provider_v1'].make_provider(
        compiled, generation, depth, helper.FACTORY_LIMITS)
    if factory['status'] != 'COMPLETE':
        return refusal('UNKNOWN', 'NATIVE_FACTORY', receipt=factory)
    assert text(factory['value']['definitions']) == text(definitions)
    factory_check = modules['growing_proof_verifier_v2'].verify_factory(
        compiled, generation, depth, model, factory, limits=helper.VERIFY_LIMITS)
    end('factory_admission_seconds')
    if factory_check['status'] != 'VERIFIED':
        return refusal(factory_check['status'], 'FACTORY_ADMISSION', receipt=factory_check)
    zeros = []
    for zero in compiled['zero_instances']:
        check = modules['independent_fol_checker_v1'].check(
            compiled['theory'], [zero['line']], zero['line']['formula'], helper.KERNEL_LIMITS)
        zeros.append(dict(id=zero['id'], native_rule=zero['rule'], receipt=check))
        if check['status'] != 'VERIFIED':
            return refusal(check['status'], 'NATIVE_ZERO', zero_checks=zeros)
    end('all_native_zero_seconds')
    query_pairs, frequencies = helper._requests(definitions, compiled['goal_id'], depth)
    catalogue = modules['proof_core_v1'].Catalogue(compiled, definitions, depth)
    learned = modules['failure_markings_v1'].learn(catalogue, query_pairs, seconds=ACQUISITION_SECONDS)
    certificate = learned['certificate']
    absence = modules['failure_certificate_checker_v1'].verify(compiled, certificate)
    end('failure_acquisition_admission_seconds')
    if absence['status'] != 'VERIFIED':
        return refusal(absence['status'], 'ABSENCE_CERTIFICATE', acquisition=learned, receipt=absence)
    lanes = {}
    for mode in ('BASE', 'MARKS', 'IFILTER'):
        lane_started = time.perf_counter()
        lane = adapter.make_lane(compiled, generation, depth, mode, certificate)
        if lane['status'] != 'PREPARED':
            return refusal(lane['status'], 'LANE_CONSTRUCTION_' + mode, receipt={
                k:v for k,v in lane.items() if k != 'provider'})
        admitted = reference.verify_descriptor(compiled, generation, lane['descriptor'],
            certificate, lane['model'], **DESCRIPTOR_LIMITS)
        if admitted['status'] != 'VERIFIED':
            return refusal(admitted['status'], 'DESCRIPTOR_ADMISSION_' + mode, receipt=admitted)
        assert text(lane['factory']['value']) == text(factory['value'])
        lanes[mode] = dict(model=lane['model'], descriptor=lane['descriptor'],
            descriptor_check=admitted, construction_setup=lane['setup'],
            absence_check=lane['absence_check'], preparation_lane_seconds=time.perf_counter()-lane_started)
        del lane
    end('all_compact_lane_admissions_seconds')
    prepared = dict(status='PREPARED', id=declaration['id'], declaration=copy.deepcopy(declaration),
        compiled=compiled, generation=generation, depth=depth, definitions=definitions,
        factory_model=model, factory=factory, factory_check=factory_check, profile_check=profile,
        zero_checks=zeros, failure_certificate=certificate, lanes=lanes,
        acquisition=dict(requests=query_pairs, selected_frequencies=frequencies, learned=learned,
            absence_check=absence, seconds_limit=ACQUISITION_SECONDS,
            request_policy='Top24 premise-FID occurrence frequency excluding goal; tie by canonical FID; remaining0..H-1; frozen before labels.',
            preservation_scope='Only complete independently checked bounded absences become constraints. Unknown classifications remain unconstrained; no exhaustive all-proof-set count is claimed.'),
        theory_reader=helper.theory_reader(declaration),
        scope='Fresh original finite RF grammar, compact complete native row schema, native B/tree proof joins. No expanded deep row array, full Hilbert formalization, universal Wang proof search or RL.')
    end('reader_and_return_data_seconds')
    prepared['stage_seconds'] = stages
    prepared['preparation_seconds'] = sum(stages.values())
    prepared['cost_scope'] = ('Preparation observed once per case and reused. Stage timers are disjoint; per-lane '
        'construction clocks are nested. DP requires compile/profile/nativeZERO costs, not point factories, '
        'failure acquisition or schema/point materialization. No independent cold-method timing is claimed.')
    return prepared


def make_lane(prepared, mode):
    assert prepared['status'] == 'PREPARED' and mode in ('BASE', 'MARKS', 'IFILTER')
    helper, modules, adapter, reference = dependencies()
    lane = adapter.make_lane(prepared['compiled'], prepared['generation'],
        prepared['depth'], mode, prepared['failure_certificate'])
    if lane['status'] == 'PREPARED':
        assert text(lane['model']) == text(prepared['lanes'][mode]['model'])
        assert text(lane['descriptor']) == text(prepared['lanes'][mode]['descriptor'])
        assert text(lane['factory']['value']) == text(prepared['factory']['value'])
    return lane


def native_context(prepared):
    return dict(compiled=prepared['compiled'], generation=prepared['generation'],
                certificate=prepared['failure_certificate'])


def check_solution(prepared, result):
    return local('helper', 'source/transfer_inputs_v1.py').check_solution(prepared, result)


def explicit_tiny(prepared, mode, *, max_rows=20000):
    """Prior independent authoring helper only within its old small-height scope."""
    assert prepared['status'] == 'PREPARED' and prepared['depth'] <= 3
    assert type(max_rows) is int and 0 < max_rows <= 20000
    helper = local('helper', 'source/transfer_inputs_v1.py')
    compiled, definitions, depth = prepared['compiled'], prepared['definitions'], prepared['depth']
    base_count = prepared['lanes']['BASE']['descriptor']['represented_rows']
    if base_count > max_rows:
        return dict(status='UNKNOWN', reason='TINY_FULL_ENUMERATION_BOUND')
    rows = helper._universe(compiled, definitions, depth,
        prepared['failure_certificate'] if mode == 'MARKS' else None)
    if mode == 'IFILTER':
        negative = {tuple(q) for q in prepared['failure_certificate']['requests']}
        by_id = {d['id']:d for d in definitions}
        rows = [row for row in rows if not any((fid, depth-len(json.loads(row['id'])[0])-1) in negative
                for fid in by_id[json.loads(row['id'])[1]]['premises'])]
    return dict(status='COMPLETE', universe=rows, rows=len(rows), expanded_universe_sha256=sha(rows),
        scope='Independent prior authoring implementation, tiny qualification only; no deep row expansion.')
