"""Prospective qualification then deeper compact-universe study.

All original raw searches are persisted before graph/native assurance. Nothing
here reads a historical target proof, enriched compiled theory, bank or policy.
"""
import argparse
import collections
import copy
import gc
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import resource
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
MASTER = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md')
MASTER_SHA = 'c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9'
ENGINE = dict(wall_seconds=20, max_work=2000000000, max_nodes=5000,
    max_events=50000, max_rollback_records=50000, max_candidates=50000, max_points=4096)
GRAPH = dict(max_items=500000000, wall_seconds=30)
ORACLE = dict(max_cached_rows=200000, max_incident_entries=500000)
DP = dict(wall_seconds=20, max_work=500000000, max_depth=128,
          max_items=10000000, max_states=200000, max_proof_lines=4096)
JOURNAL_BYTES = 256 * 1024 * 1024


def wire(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(',', ':'), allow_nan=False)+'\n').encode('ascii')


def sha(value):
    return hashlib.sha256(wire(value)).hexdigest()


def pin(path):
    raw = path.read_bytes()
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def save(name, value):
    path = ROOT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    data = wire(value)
    if name.endswith('.gz'):
        data = gzip.compress(data, mtime=0)
    with path.open('xb') as stream:
        stream.write(data)
    return dict(path=name, **pin(path))


def read(reference):
    name = reference['path'] if type(reference) is dict else reference
    path = ROOT / name
    if type(reference) is dict:
        assert pin(path) == {k: reference[k] for k in ('bytes', 'sha256')}
    with (gzip.open(path, 'rt', encoding='ascii') if name.endswith('.gz') else path.open('r', encoding='ascii')) as stream:
        return json.load(stream)


def module(name, relative):
    spec = importlib.util.spec_from_file_location('pdi_run_' + name, ROOT / relative)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


def freeze(phase, declarations):
    assert pin(MASTER)['sha256'] == MASTER_SHA
    assert pin(MASTER) == pin(ROOT / 'reference/basic-tiling-algorithm.md')
    paths = sorted(p for folder in ('source', 'reference') for p in (ROOT/folder).rglob('*')
                   if p.is_file() and '__pycache__' not in p.parts)
    receipt = dict(schema='PDI-prospective-protocol-v1', phase=phase,
        pins={p.relative_to(ROOT).as_posix(): pin(p) for p in paths},
        runtime=dict(path=sys.executable, version=sys.version, **pin(Path(sys.executable))),
        primary_master=dict(path=str(MASTER), **pin(MASTER)),
        declarations=declarations, declarations_sha256=sha(declarations),
        engine_limits=ENGINE, graph_limits=GRAPH, oracle_limits=ORACLE, dp_limits=DP,
        journal_bytes=JOURNAL_BYTES, lane_rotation=['BASE', 'MARKS', 'IFILTER'],
        scope='Finite original native RF grammar/height; compact complete universe; no policy, full Hilbert geometry, universal Wang proof search or cold speedup claim.')
    save('data/'+phase+'-protocol-v1.json', receipt)
    return receipt


def unchanged(protocol):
    for name, expected in protocol['pins'].items():
        assert pin(ROOT/name) == expected, name
    assert pin(MASTER) == {k: protocol['primary_master'][k] for k in ('bytes', 'sha256')}
    assert pin(Path(protocol['runtime']['path'])) == {k: protocol['runtime'][k] for k in ('bytes', 'sha256')}


def loaded():
    return dict(inputs=module('inputs', 'source/depth_inputs_v1.py'),
        engine=module('engine', 'reference/upstream/growing_point_search_v2.py'),
        full=module('old_full', 'reference/upstream/frontier_trace_checker_v1.py'),
        compact=module('compact', 'reference/frontier_trace_checker_v2.py'),
        universe=module('universe', 'reference/native_universe_checker_v1.py'),
        dp=module('dp', 'reference/upstream/growing_proof_verifier_v2.py'))


def run_point(modules, run_id, lane, universe_ref, context, context_ref, extra,
              *, explicit=None, explicit_ref=None):
    save('data/runs/'+run_id+'-started-v1.json', dict(id=run_id, model_sha256=sha(lane['model']),
        universe_ref=universe_ref, native_context_ref=context_ref, limits=ENGINE, extra=extra))
    observations, journal = [], dict(retained_bytes=0, refusal=None)
    def audit(event, state, charge):
        item = dict(event=event, state=state)
        size = len(wire(item))
        if journal['retained_bytes'] + size > JOURNAL_BYTES:
            journal['refusal'] = dict(reason='AUDIT_STORAGE_BOUND', event_seq=event['seq'], next_bytes=size)
            charge(1 << 128)
        observations.append(item)
        journal['retained_bytes'] += size
    kwargs = dict(audit=audit)
    if lane['provider'] is not None:
        kwargs['enumerate_incident'] = lane['provider']
    started = time.perf_counter()
    result = modules['engine'].solve(lane['model'], ENGINE, **kwargs)
    seconds = time.perf_counter() - started
    raw = dict(id=run_id, model=lane['model'], universe_ref=universe_ref,
        native_context_ref=context_ref, observations=observations, result=result,
        search_seconds=seconds, journal=journal, **extra)
    if explicit_ref is not None:
        raw['explicit_universe_ref'] = explicit_ref
    raw_ref = save('data/runs/'+run_id+'-raw.json.gz', raw)
    graph = modules['compact'].verify(lane['model'], lane['descriptor'], observations, result,
        native_context=context, oracle_limits=ORACLE, **GRAPH)
    graph_ref = save('data/runs/'+run_id+'-compact-check.json', graph)
    record = dict(id=run_id, raw=raw_ref, graph_check=graph_ref, result=result['status'],
        assurance=graph['status'], search_seconds=seconds, events=len(observations),
        journal_bytes=journal['retained_bytes'], journal_refusal=journal['refusal'])
    if explicit is not None:
        full = modules['full'].verify(lane['model'], explicit, observations, result, **GRAPH)
        record['full_graph_check'] = save('data/runs/'+run_id+'-full-check.json', full)
        record['full_assurance'] = full['status']
        if result['status'] != 'UNKNOWN':
            assert graph['status'] == full['status'] == 'VERIFIED', (run_id, graph, full)
            assert graph['counts'] == full['counts'], (run_id, graph['counts'], full['counts'])
    print(json.dumps(dict(id=run_id,result=result['status'],assurance=graph['status'],events=len(observations))),flush=True)
    return raw, record


def fixture_declarations():
    c = ['fun', 'qc', []]
    atoms = {name:['pred', 'q'+name, [c]] for name in ('P','Q','U','R','G')}
    p,q,u,r,g = [atoms[n] for n in ('P','Q','U','R','G')]
    def declaration(cid, functions, predicates, axioms, goal, depth, rounds):
        names = dict(c='qc', P='qP', Q='qQ', U='qU', R='qR', G='qG', u='qu', x='qx', f='qf')
        return dict(id=cid, family='qualification', goal_label=cid, depth=depth,
            problem=dict(theory=dict(functions=functions,predicates=predicates,axioms=axioms),goal=goal),
            terms=[c], profile=dict(ui_rounds=rounds,max_terms=20,max_templates=24,max_definitions=8000),
            names=names, labels={n:n for n in names},
            scope='Fresh tiny qualification hypothesis/goal, no supplied target derivation.')
    horn = declaration('pdi-qual-horn-h3', {'qc':0}, {'q'+n:1 for n in atoms},
        dict(fact=p,duplicate=p,step=['imp',p,q],finish=['imp',q,g],dead=['imp',u,g],cycle=['imp',r,r]),g,3,0)
    gen = declaration('pdi-qual-gen-h2', {'qc':0}, {'qP':1}, dict(given=p), ['all','qu',p],2,0)
    x = ['var','qx'];f = lambda t:['fun','qf',[t]]
    eq = declaration('pdi-qual-ui-eq-h2', {'qc':0,'qf':1},{},
        dict(given=['all','qx',['eq',f(x),x]]), ['eq',f(c),c],2,1)
    return [horn,gen,eq]


def generic_declarations():
    source = module('generic_fixtures', 'reference/upstream/abstract_fixtures_v1.py')
    selected = {'untouched-zero-explicit','late-global-dead-explicit','nested-exclusion-scope-indexed'}
    return source, [case for case in source.cases() if case['id'] in selected]


def rehash(raw):
    """Coherent ordinary stream/state checksums; no search/checker helper call."""
    result, observations = raw['result'], raw['observations']
    for index,item in enumerate(observations):
        item['event']['seq'] = index
    result['events'] = [copy.deepcopy(item['event']) for item in observations]
    def stream(records):
        digest=hashlib.sha256()
        for row in records:digest.update(wire(row))
        return digest.hexdigest()
    result['event_extent'].update(total=len(observations),retained=len(observations),sha256=stream(result['events']))
    result['stats'].update(events_total=len(observations),audit_calls=len(observations))
    if observations and observations[0]['event']['kind']=='READY':
        result['entry_state']=copy.deepcopy(observations[0]['state'])
        result['restored_state']=copy.deepcopy(result['entry_state'])
    if result['final_state'] is not None and observations:
        result['final_state']=copy.deepcopy(observations[-1]['state'])
    for name in ('entry','final','restored'):
        value=result[name+'_state'];result['state_hashes'][name]=None if value is None else sha(value)
    evidence=result['provider_evidence'];records=evidence['records']
    evidence.update(total=len(records),retained=len(records),sha256=stream(records))
    if 'journal' in raw:
        raw['journal']['retained_bytes']=sum(len(wire(item)) for item in observations)


def remove_incidence(state,cid):
    for point,ids in state['domains']:
        if cid in ids:ids.remove(cid)
    state['forward']=[row for row in state['forward'] if row[1]!=cid]
    state['reverse']=[row for row in state['reverse'] if row[0]!=cid]
    state['edge_count']=len(state['forward'])


def mutations(modules, records, preparations, generic_records):
    result=[];pending=[]
    def choose(mode):
        return next((r for r in records if r['mode']==mode and r['result']!='UNKNOWN'
                     and r['assurance']=='VERIFIED' and r['case_id']=='pdi-qual-horn-h3'),None)
    base,marked=choose('BASE'),choose('MARKS')
    if base is None or marked is None:
        return dict(records=[],pending=['No complete Horn BASE/MARKS trace for requested mutations.'])
    prepared=read(preparations[base['case_id']]);context=modules['inputs'].native_context(prepared)
    def descriptor_attack(name,mode,edit):
        lane=prepared['lanes'][mode]
        payload=dict(model=copy.deepcopy(lane['model']),descriptor=copy.deepcopy(lane['descriptor']),
                     native_context=copy.deepcopy(context))
        edit(payload)
        evidence=save('data/qualification/mutants/'+name+'-evidence.json.gz',payload)
        ctx=payload['native_context']
        receipt=modules['universe'].verify_descriptor(ctx['compiled'],ctx['generation'],payload['descriptor'],
            ctx['certificate'],payload['model'],max_items=100000000,wall_seconds=30)
        check=save('data/qualification/mutants/'+name+'-check.json',receipt)
        result.append(dict(id=name,evidence=evidence,check=check,status=receipt['status'],expected='REJECTED'))
        assert receipt['status']=='REJECTED',(name,receipt)
    def refresh_binding(payload):
        ctx=payload['native_context'];d=payload['descriptor'];c=ctx['compiled'];g=ctx['generation']
        core=sha({k:v for k,v in c.items() if k not in ('costs','scope')});g['compiled_core_sha256']=core
        d.update(compiled_core_sha256=core,generation_sha256=sha(g),registry_sha256=sha(c['logical_basis']))
        identity=sha(dict(schema='Z-anchored-proof-inventory-identity-v1',version='Z-ANCHORED-PROOF-PRODUCER-v1',
            compiled_core_sha256=core,depth=d['depth']))
        d['base_inventory_identity']=identity
        if d['mode']=='BASE':d['inventory_identity']=identity
        elif d['mode']=='MARKS':
            cert=ctx['certificate'];d.update(failure_scope_sha256=cert['scope_sha256'],failure_certificate_sha256=sha(cert),
                negative_requests=copy.deepcopy(cert['requests']))
            d['inventory_identity']=wire(['FM-provider-v1',identity,'MARKS',sha(cert['requests']),cert['scope_sha256']]).decode().rstrip('\n')
        else:
            body={k:v for k,v in d.items() if k!='inventory_identity'}
            d['inventory_identity']=wire(['PFD-intensional-IFILTER-v1',identity,sha(body)]).decode().rstrip('\n')
        payload['model']['inventory']['identity']=d['inventory_identity']
    def omit_definition(payload):
        payload['native_context']['compiled']['mp_index'].pop()
        refresh_binding(payload)
    descriptor_attack('omitted-native-definition-rebound','BASE',omit_definition)
    descriptor_attack('wrong-depth','BASE',lambda p:p['descriptor'].__setitem__('depth',p['descriptor']['depth']+1))
    descriptor_attack('wrong-level-count','BASE',lambda p:p['descriptor']['levels'][0].__setitem__('rows',999))
    descriptor_attack('wrong-inventory-identity','BASE',lambda p:p['model']['inventory'].__setitem__('identity','wrong'))
    def bad_scope(payload):
        payload['native_context']['certificate']['scope_sha256']='0'*64
        refresh_binding(payload)
    descriptor_attack('wrong-certificate-scope-rebound','MARKS',bad_scope)
    def flag(payload,delete=False):
        rows=payload['model']['seed']['m'];index=next(i for i,(p,v) in enumerate(rows) if p.startswith('['))
        if delete:rows.pop(index)
        else:rows[index][1]='1'
    descriptor_attack('wrong-negative-flag','MARKS',lambda p:flag(p))
    descriptor_attack('literal-zero-is-not-missing','MARKS',lambda p:flag(p,True))
    def remote_root(payload):
        payload['model']['roots'].append('remote-root-zero')
        payload['model']['seed']['t'].append(['remote-root-zero',0])
    descriptor_attack('native-profile-remote-root','BASE',remote_root)
    def trace_attack(name,row,edit,expected='REJECTED',oracle_limits=None,max_items=GRAPH['max_items']):
        raw=read(row['raw']);edit(raw);rehash(raw)
        evidence=save('data/qualification/mutants/'+name+'-evidence.json.gz',raw)
        lane=prepared['lanes'][row['mode']]
        receipt=modules['compact'].verify(raw['model'],lane['descriptor'],raw['observations'],raw['result'],
            native_context=context,oracle_limits=ORACLE if oracle_limits is None else oracle_limits,
            max_items=max_items,wall_seconds=GRAPH['wall_seconds'])
        check=save('data/qualification/mutants/'+name+'-check.json',receipt)
        result.append(dict(id=name,evidence=evidence,check=check,status=receipt['status'],expected=expected,
            original_run=row['id'],prepared=preparations[row['case_id']],descriptor_mode=row['mode'],
            checker_limits=dict(max_items=max_items,wall_seconds=GRAPH['wall_seconds'],
                oracle_limits=ORACLE if oracle_limits is None else oracle_limits)))
        assert receipt['status']==expected,(name,receipt)
    def omitted_packet(raw):
        packet=next(p for p in raw['result']['provider_evidence']['records'] if p['reply']['placements'])
        packet['reply']['placements'].pop();packet['reply']['certificate']['compatible_count']-=1
    trace_attack('packet-row-omission-adjusted-count',base,omitted_packet)
    def mark_port(raw,change_remaining):
        rows=[r for p in raw['result']['provider_evidence']['records'] for r in p['reply']['placements']]
        candidate=next(r for r in rows if any(p.startswith('[') for p,v in r['m']))
        index=next(i for i,(p,v) in enumerate(candidate['m']) if p.startswith('['))
        if change_remaining:
            port=json.loads(candidate['m'][index][0]);port[-1]+=1
            candidate['m'][index][0]=wire(port).decode().rstrip('\n')
            candidate['m'].sort(key=lambda pair:pair[0])
        else:candidate['m'][index][1]='0'
    trace_attack('wrong-premise-flag-value',marked,lambda raw:mark_port(raw,False))
    trace_attack('wrong-premise-remaining-port',marked,lambda raw:mark_port(raw,True))
    def weighted(raw):
        state=raw['observations'][0]['state'];point,cid,units=state['forward'][0]
        next(r for r in state['forward'] if r[:2]==[point,cid])[2]=units+1
        next(r for c,rows in state['reverse'] if c==cid for r in rows if r[0]==point)[1]=units+1
    trace_attack('coherent-wrong-weight',base,weighted)
    def generation(raw):
        state=next(item['state'] for item in raw['observations'] if item['event']['kind']=='PLACED')
        next(pair for pair in state['Q'] if pair[0]!='' and pair[1]>0)[1]=0
    trace_attack('wrong-emergent-generation',base,generation)
    trace_attack('oracle-cache-refusal',base,lambda raw:None,expected='UNKNOWN',
        oracle_limits=dict(max_cached_rows=1,max_incident_entries=500000))
    trace_attack('verifier-work-refusal',base,lambda raw:None,expected='UNKNOWN',max_items=10)
    nested=next((r for r in generic_records if r['fixture_id']=='nested-exclusion-scope-indexed'
                 and r['result']!='UNKNOWN'),None)
    if nested is None:
        pending.append('No complete nested generic trace for sibling-exclusion mutant.')
    else:
        raw=read(nested['raw'])
        state=next(item['state'] for item in raw['observations'] if item['event']['kind']=='PLACED'
                   and item['event']['candidate']=='b-outer-good')
        assert 'c-inner' in state['eligible']
        state['excluded'].append('c-inner');state['excluded'].sort();state['eligible'].remove('c-inner')
        remove_incidence(state,'c-inner');rehash(raw)
        evidence=save('data/qualification/mutants/sibling-exclusion-leak-evidence.json.gz',raw)
        fixture=read(nested['fixture'])
        check=modules['compact'].verify(raw['model'],fixture['universe'],raw['observations'],raw['result'],**GRAPH)
        ref=save('data/qualification/mutants/sibling-exclusion-leak-check.json',check)
        assert check['status']=='REJECTED'
        result.append(dict(id='sibling-exclusion-leak',evidence=evidence,check=ref,status=check['status'],expected='REJECTED'))
    return dict(records=result,pending=pending)


def qualification():
    declarations=fixture_declarations();generic_source,generic_cases=generic_declarations()
    protocol=freeze('qualification',dict(native=declarations,generic=generic_cases))
    modules=loaded();records=[];preparations={};equivalence=[];complete=True
    for declaration in declarations:
        prepared=modules['inputs'].prepare(declaration)
        prep_ref=save('data/qualification/'+declaration['id']+'-prepared.json.gz',prepared)
        preparations[declaration['id']]=prep_ref
        if prepared['status']!='PREPARED':
            complete=False;continue
        explicit={}
        for mode in ('BASE','MARKS','IFILTER'):
            old=modules['inputs'].explicit_tiny(prepared,mode,max_rows=20000)
            old_ref=save('data/qualification/'+declaration['id']+'-'+mode+'-old-expansion.json.gz',old)
            new=modules['universe'].materialize_tiny(prepared['compiled'],prepared['generation'],
                prepared['lanes'][mode]['descriptor'],prepared['failure_certificate'],max_rows=20000)
            new_ref=save('data/qualification/'+declaration['id']+'-'+mode+'-new-expansion.json.gz',new)
            assert old['status']==new['status']=='COMPLETE' and wire(old['universe'])==wire(new['universe'])
            explicit[mode]=old
            equivalence.append(dict(case_id=declaration['id'],mode=mode,status='VERIFIED',
                rows=old['rows'],expanded_universe_sha256=old['expanded_universe_sha256'],
                old_expansion=old_ref,new_expansion=new_ref))
        explicit_ref=save('data/qualification/'+declaration['id']+'-explicit.json.gz',explicit)
        for mode in ('BASE','MARKS','IFILTER'):
            started=time.perf_counter()
            lane=modules['inputs'].make_lane(prepared,mode);assert lane['status']=='PREPARED'
            run_id=declaration['id']+'--'+mode
            raw,record=run_point(modules,run_id,lane,
                dict(**prep_ref,pointer='/lanes/'+mode+'/descriptor'),
                modules['inputs'].native_context(prepared),dict(**prep_ref,
                    pointers=dict(compiled='/compiled',generation='/generation',certificate='/failure_certificate')),
                dict(kind='NATIVE_QUALIFICATION',case_id=declaration['id'],mode=mode,prepared_ref=prep_ref,setup=lane['setup']),
                explicit=explicit[mode]['universe'],explicit_ref=dict(**explicit_ref,pointer='/'+mode+'/universe'))
            native=modules['inputs'].check_solution(prepared,raw['result'])
            record.update(case_id=declaration['id'],mode=mode,prepared=prep_ref,setup=lane['setup'],
                native_check=save('data/runs/'+run_id+'-native-check.json',native),
                proof_reader=native.get('proof_reader',[]),theory_reader=prepared['theory_reader'])
            record['pipeline_seconds_before_record']=time.perf_counter()-started
            save('data/runs/'+run_id+'-record.json',record);records.append(record)
            if raw['result']['status']=='SAT':assert native['status']=='VERIFIED'
            if raw['result']['status']=='UNKNOWN':complete=False
            del raw,lane;gc.collect()
        del prepared,explicit;gc.collect()
    generic_records=[]
    for case in generic_cases:
        fixture_ref=save('data/qualification/generic-'+case['id']+'.json.gz',case)
        provider=generic_source.provider_for(case)
        lane=dict(model=case['model'],provider=provider,descriptor=case['universe'])
        run_id='pdi-generic-'+case['id']
        raw,record=run_point(modules,run_id,lane,dict(**fixture_ref,pointer='/universe'),None,None,
            dict(kind='GENERIC_POINT_QUALIFICATION',fixture_id=case['id']),
            explicit=case['universe'],explicit_ref=dict(**fixture_ref,pointer='/universe'))
        record.update(fixture_id=case['id'],fixture=fixture_ref)
        save('data/runs/'+run_id+'-record.json',record);generic_records.append(record)
        if raw['result']['status']=='UNKNOWN':complete=False
        else:assert raw['result']['status']==case['expectation']['status']
        del raw;gc.collect()
    attacked=mutations(modules,records,preparations,generic_records)
    if attacked['pending']:complete=False
    unchanged(protocol)
    save('data/qualification-results-v1.json',dict(status='QUALIFIED' if complete else 'INCOMPLETE',
        native_records=records,preparations=preparations,explicit_equivalence=equivalence,
        generic_records=generic_records,mutations=attacked,sources_unchanged=True,
        scope='Same actual tiny traces checked by old full-list and new complete descriptor readers; every native positive separately B/tree checked. Generic fixtures are point-contract tests, not theorems. No deeper search occurred.'))


def study():
    gate=read('data/qualification-results-v1.json');assert gate['status']=='QUALIFIED'
    unchanged(read('data/qualification-protocol-v1.json'))
    declarations=module('declarations','source/depth_cases_v1.py').declarations()
    protocol=freeze('study',declarations);modules=loaded();records=[];preparations=[]
    for index,declaration in enumerate(declarations):
        prepared=modules['inputs'].prepare(declaration)
        prep_ref=save('data/prepared/'+declaration['id']+'.json.gz',prepared)
        preparations.append(dict(id=declaration['id'],prepared=prep_ref,status=prepared['status']))
        if prepared['status']!='PREPARED':continue
        modes=['BASE','MARKS','IFILTER'];shift=index%3;modes=modes[shift:]+modes[:shift]
        jobs=modes+['DP'] if index%2==0 else ['DP']+modes
        for mode in jobs:
            run_id=declaration['id']+'--'+mode;started=time.perf_counter()
            if mode=='DP':
                save('data/runs/'+run_id+'-started-v1.json',dict(id=run_id,kind='DP',prepared_ref=prep_ref,limits=DP))
                clock=time.perf_counter();result=modules['dp'].tree_control(prepared['compiled'],prepared['depth'],DP)
                seconds=time.perf_counter()-clock
                raw_ref=save('data/runs/'+run_id+'-raw.json.gz',dict(id=run_id,kind='DP',prepared_ref=prep_ref,
                    result=result,search_seconds=seconds))
                selected=(result.get('details') or {}).get('selected',[])
                native=modules['inputs'].check_solution(prepared,dict(status='SAT' if result['status']=='DERIVABLE' else 'UNKNOWN',selected=selected))
                record=dict(id=run_id,case_id=declaration['id'],depth=prepared['depth'],mode=mode,kind='DP',prepared=prep_ref,raw=raw_ref,
                    result=result['status'],search_seconds=seconds,
                    native_check=save('data/runs/'+run_id+'-native-check.json',native),
                    proof_reader=native.get('proof_reader',[]),theory_reader=prepared['theory_reader'])
                if result['status']=='DERIVABLE':assert native['status']=='VERIFIED'
            else:
                lane=modules['inputs'].make_lane(prepared,mode)
                if lane['status']!='PREPARED':
                    ref=save('data/runs/'+run_id+'-setup-refusal.json',{k:v for k,v in lane.items() if k!='provider'})
                    refusal=dict(id=run_id,case_id=declaration['id'],mode=mode,status='UNKNOWN_SETUP',
                        setup_refusal=ref,pipeline_seconds_before_record=time.perf_counter()-started)
                    save('data/runs/'+run_id+'-record.json',refusal);records.append(refusal)
                    continue
                raw,record=run_point(modules,run_id,lane,dict(**prep_ref,pointer='/lanes/'+mode+'/descriptor'),
                    modules['inputs'].native_context(prepared),dict(**prep_ref,
                        pointers=dict(compiled='/compiled',generation='/generation',certificate='/failure_certificate')),
                    dict(kind='FAMILY',case_id=declaration['id'],mode=mode,prepared_ref=prep_ref,setup=lane['setup']))
                native=modules['inputs'].check_solution(prepared,raw['result'])
                record.update(kind='FAMILY',case_id=declaration['id'],depth=prepared['depth'],mode=mode,prepared=prep_ref,setup=lane['setup'],
                    native_check=save('data/runs/'+run_id+'-native-check.json',native),
                    proof_reader=native.get('proof_reader',[]),theory_reader=prepared['theory_reader'])
                if raw['result']['status']=='SAT':assert native['status']=='VERIFIED'
                assert record['assurance']!='REJECTED',(run_id,read(record['graph_check']))
                del raw,lane;gc.collect()
            record['pipeline_seconds_before_record']=time.perf_counter()-started
            save('data/runs/'+run_id+'-record.json',record);records.append(record)
            print(json.dumps(dict(id=run_id,result=record.get('result'))),flush=True)
        del prepared;gc.collect()
    unchanged(protocol)
    save('data/study-results-v1.json',dict(status='SCHEDULE_EXECUTED',preparations=preparations,
        records=records,sources_unchanged=True,qualification=gate['status'],
        scope='Original finite incidence grammar at declared heights; no full row expansion, RL, unrestricted nonprovability or universal fixed-palette proof search. UNKNOWN and setup/preparation refusals retained separately.'))


def main():
    parser=argparse.ArgumentParser();parser.add_argument('phase',choices=('qualification','study'));args=parser.parse_args()
    started=time.perf_counter()
    try:
        {'qualification':qualification,'study':study}[args.phase]()
    finally:
        save('review/'+args.phase+'-invocation-v1.json',dict(status='FAILED' if sys.exc_info()[0] else 'COMPLETE',
            phase=args.phase,main_seconds=time.perf_counter()-started,platform=sys.platform,
            ru_maxrss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            scope='Fresh main invocation including preparation, actual searches, native/graph assurance and prior writes. Startup/final receipt excluded; Darwin ru_maxrss is bytes.'))


if __name__=='__main__':
    main()
