"""Fresh RF-profile inputs; scientific work occurs only in explicit API calls.

No historical compiled bases, proof outputs, lemma banks or policies are read.
All upstream scientific dependencies are unchanged, pinned byte copies. The
independent RF catalogue checker is a separately reviewed local dependency.
"""
from pathlib import Path
import collections
import copy
import hashlib
import importlib.util
import itertools
import json
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
VERSION = 'PFT-fresh-transfer-inputs-v1'
PINS = {
    'finite_basis_v1.py': '97225dcffd98dd5386aeb560a2fc5634dfcc4606ff475a46536207768932a0dc',
    'proof_core_v1.py': 'd363b72e6f4355225d3dbbdc66c64f746d27bf96de5c4d8a17471cc95b70091c',
    'failure_markings_v1.py': '4b0f735c6a1114925fd1032c2a5cba37bffa61f447a0b71e1aaea8bf8e09a529',
    'failure_certificate_checker_v1.py': '2436cc872737f9400c7bbb78949a366919a64804ca3088be1577fcdc7c7e88db',
    'marked_point_checker_v1.py': '513ac4c616a2db3154c79156f40807228c9a667f601230a35330673d3105aa26',
    'indexed_proof_provider_v1.py': '5261bf552924105f3c9ac3a4e9ddce0490869105b1812a8d897610267623b26e',
    'growing_proof_verifier_v2.py': '6286d6b151d460e6ee0b97983fd9f081168a6d76256a33c3e0f9ead0ffae3aa1',
    'independent_fol_checker_v1.py': '099454304f3a67c8ec49b1a3685c0dc0896662ae0bc26a18db9320d6cb3404b1',
    'growing_point_search_v2.py': '6e9687145ec2c86719266e07f7ddee4077d88a386c67152dec368657eae43cbb',
    'frontier_trace_checker_v1.py': '01f46bdf34b414c7470f75f1507f3e76bfefa739533fcc4b2fd121900378343f',
}
FACTORY_LIMITS = dict(max_work=1000000000, max_depth=256, max_definitions=20000,
    max_proof_lines=4096, wall_seconds=15)
VERIFY_LIMITS = dict(max_depth=256, max_items=100000000, max_work=1000000000, wall_seconds=30)
KERNEL_LIMITS = dict(max_depth=256, max_operations=10000000, max_proof_lines=4096)
PROFILE_LIMITS = dict(max_items=100000000, max_work=1000000000, wall_seconds=30)
CLASSIFICATION_SECONDS = 15
REQUEST_LIMIT = 24
MAX_UNIVERSE_ROWS = 30000
PROFILE_CHECKER_SHA256 = '146df0b295c28c5ffe743f687e83fd5454ae5ab7915b5900f80b22d86a42d9ab'
_MODULES = None


def need(condition, reason):
    if not condition:
        raise ValueError(reason)


def text(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(',', ':'), allow_nan=False)


def sha(value):
    return hashlib.sha256((text(value) + '\n').encode('ascii')).hexdigest()


def source_pins():
    result = {}
    for name, expected in PINS.items():
        path = ROOT / 'reference/upstream' / name
        data = path.read_bytes()
        need(hashlib.sha256(data).hexdigest() == expected, 'PINNED_SOURCE:' + name)
        result['reference/upstream/' + name] = dict(bytes=len(data), sha256=expected)
    for relative in ('source/transfer_cases_v1.py', 'source/transfer_inputs_v1.py',
                     'reference/rf_catalogue_checker_v1.py'):
        data = (ROOT / relative).read_bytes()
        if relative == 'reference/rf_catalogue_checker_v1.py':
            need(hashlib.sha256(data).hexdigest() == PROFILE_CHECKER_SHA256, 'PINNED_RF_PROFILE_CHECKER')
        result[relative] = dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
    return result


def _modules():
    """Lazy scientific loading; no compiler/checker/search call at module import."""
    global _MODULES
    source_pins()
    if _MODULES is not None:
        return _MODULES
    modules, absent = {}, object()
    saved = {name: sys.modules.get(name, absent)
             for name in ('proof_core_v1', 'failure_certificate_checker_v1')}
    try:
        for name in ('proof_core_v1', 'finite_basis_v1', 'failure_certificate_checker_v1',
                     'failure_markings_v1', 'marked_point_checker_v1',
                     'indexed_proof_provider_v1', 'growing_proof_verifier_v2',
                     'independent_fol_checker_v1', 'rf_catalogue_checker_v1'):
            folder = ROOT / 'reference' if name == 'rf_catalogue_checker_v1' else ROOT / 'reference/upstream'
            spec = importlib.util.spec_from_file_location('pft_pinned_' + name, folder / (name + '.py'))
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            modules[name] = module
            if name in saved:
                sys.modules[name] = module
    finally:
        for name, value in saved.items():
            if value is absent:
                sys.modules.pop(name, None)
            else:
                sys.modules[name] = value
    _MODULES = modules
    return modules


def _definitions(compiled):
    """All native definitions from the independently admitted exact carrier."""
    forms, colors = compiled['logical_basis']['formulas'], compiled['logical_basis']['colors']
    need(colors == sorted(set(colors)) and colors == [text(f) for f in forms], 'LITERAL_REGISTRY')
    ids, definitions, mp, gen = {v: i for i, v in enumerate(colors)}, [], [], []
    for i, zero in enumerate(compiled['zero_instances']):
        need(zero['id'] == 'i' + str(i) and zero['rule'] == zero['line']['rule'] and
             colors[zero['formula_id']] == text(zero['line']['formula']), 'ZERO_ID_OUTPUT_RULE')
        definitions.append(dict(id=text(['zero', zero['id']]), kind='ZERO', output=zero['formula_id'],
            premises=[], zero_id=zero['id'], variable=None, native_rule=zero['rule']))
    for i, form in enumerate(forms):
        if form[0] == 'imp':
            a, b = ids[text(form[1])], ids[text(form[2])]
            mp.append([i, a, b])
            definitions.append(dict(id=text(['mp', i, a, b]), kind='MP', output=b,
                premises=[a, i], zero_id=None, variable=None, native_rule='mp'))
        elif form[0] == 'all':
            body, variable = ids[text(form[2])], form[1]
            gen.append([i, body, variable])
            definitions.append(dict(id=text(['gen', i, body, variable]), kind='GEN', output=i,
                premises=[body], zero_id=None, variable=variable, native_rule='generalize'))
    need(text(mp) == text(compiled['mp_index']) and text(gen) == text(compiled['gen_index']),
         'COMPLETE_STRUCTURAL_INDICES')
    return sorted(definitions, key=lambda row: row['id'])


def _universe(compiled, definitions, depth, certificate=None):
    """Full independent row expansion, not provider enumeration or placements."""
    need(type(depth) is int and 0 <= depth <= 4, 'TRANSFER_HEIGHT_SCOPE')
    z = sum(not d['premises'] for d in definitions)
    expected = z * ((1 << (depth + 1)) - 1) + (len(definitions) - z) * ((1 << depth) - 1)
    need(expected <= MAX_UNIVERSE_ROWS, 'FULL_UNIVERSE_RESOURCE_BOUND')
    colors, rows = compiled['logical_basis']['colors'], []
    for length in range(depth + 1):
        for bits in itertools.product('01', repeat=length):
            site = ''.join(bits)
            for d in definitions:
                if d['premises'] and length == depth:
                    continue
                points = [site] + [site + str(i) for i in range(len(d['premises']))]
                marks = dict(zip(points, [colors[f] for f in [d['output']] + d['premises']]))
                if certificate is not None:
                    for fid in d['premises']:
                        port = text(['FM-port-v1', certificate['scope_sha256'], fid, depth - length - 1])
                        marks[port] = '1'
                rows.append(dict(id=text([site, d['id']]), t=[[p, 1] for p in points],
                    m=[[p, v] for p, v in sorted(marks.items())]))
    need(len(rows) == expected and len({r['id'] for r in rows}) == expected, 'FULL_ROW_CENSUS')
    return sorted(rows, key=lambda row: row['id'])


def _requests(definitions, goal_id, depth):
    frequency = collections.Counter(fid for d in definitions for fid in d['premises'] if fid != goal_id)
    selected = sorted(frequency, key=lambda fid: (-frequency[fid], fid))[:REQUEST_LIMIT]
    return [[fid, remaining] for fid in selected for remaining in range(depth)], [
        dict(fid=fid, premise_occurrences=frequency[fid]) for fid in selected]


def _expected_marked_model(base, certificate, base_identity):
    model = copy.deepcopy(base)
    model['inventory']['identity'] = text(['FM-provider-v1', base_identity, 'MARKS',
        sha(certificate['requests']), certificate['scope_sha256']])
    marks = dict(model['seed']['m'])
    for fid, remaining in certificate['requests']:
        marks[text(['FM-port-v1', certificate['scope_sha256'], fid, remaining])] = '0'
    model['seed']['m'] = [[p, v] for p, v in sorted(marks.items())]
    return model


def prepare(declaration):
    """Compile/admit/acquire one cold case; return JSON only, never a provider.

    A non-PREPARED return is not a search input. Every admission refusal and
    interrupted classification remains explicit. Source/protocol review must
    precede this scientific API; importing this module does not invoke it.
    """
    started = boundary = time.perf_counter()
    stage_seconds = {}

    def end_stage(name):
        nonlocal boundary
        now = time.perf_counter()
        stage_seconds[name] = now - boundary
        boundary = now

    def refused(status, stage, **partial):
        now = time.perf_counter()
        stage_seconds['interrupted_stage_seconds'] = now - boundary
        return dict(status=status, id=declaration['id'], stage=stage,
            stage_seconds=stage_seconds, preparation_seconds=now - started,
            scope='No partial model or universe is admitted for search.', **partial)

    modules = _modules()
    end_stage('dependency_loading_seconds')
    basis = modules['finite_basis_v1']
    try:
        compiled, generation = basis.compile_case(declaration)
    except basis.BasisLimit as error:
        return refused('UNKNOWN', 'COMPILATION', refusal=error.receipt())
    end_stage('compile_seconds')
    profile = modules['rf_catalogue_checker_v1'].verify(declaration, compiled, generation, **PROFILE_LIMITS)
    end_stage('independent_profile_admission_seconds')
    if profile['status'] != 'VERIFIED':
        return refused(profile['status'], 'INDEPENDENT_RF_PROFILE', receipt=profile)
    depth = declaration['depth']
    definitions = _definitions(compiled)
    model, provider, factory = modules['indexed_proof_provider_v1'].make_provider(
        compiled, generation, depth, FACTORY_LIMITS)
    if factory['status'] != 'COMPLETE':
        return refused('UNKNOWN', 'FACTORY', receipt=factory)
    need(text(definitions) == text(factory['value']['definitions']), 'EXACT_FACTORY_DEFINITIONS')
    factory_check = modules['growing_proof_verifier_v2'].verify_factory(
        compiled, generation, depth, model, factory, limits=VERIFY_LIMITS)
    if factory_check['status'] != 'VERIFIED':
        return refused(factory_check['status'], 'FACTORY_CHECK', receipt=factory_check)
    factory_seconds = time.perf_counter() - boundary
    zero_started = time.perf_counter()
    zero_checks = []
    for z in compiled['zero_instances']:
        receipt = modules['independent_fol_checker_v1'].check(
            compiled['theory'], [z['line']], z['line']['formula'], KERNEL_LIMITS)
        zero_checks.append(dict(id=z['id'], native_rule=z['rule'], receipt=receipt))
        if receipt['status'] != 'VERIFIED':
            return refused(receipt['status'], 'NATIVE_ZERO', zero_checks=zero_checks)
    zero_seconds = time.perf_counter() - zero_started
    end_stage('factory_and_zero_seconds')
    base_rows = _universe(compiled, definitions, depth)
    end_stage('base_universe_seconds')
    query_pairs, request_frequencies = _requests(definitions, compiled['goal_id'], depth)
    catalogue = modules['proof_core_v1'].Catalogue(compiled, definitions, depth)
    learned = modules['failure_markings_v1'].learn(catalogue, query_pairs, seconds=CLASSIFICATION_SECONDS)
    certificate = learned['certificate']
    absence = modules['failure_certificate_checker_v1'].verify(compiled, certificate)
    if absence['status'] != 'VERIFIED':
        return refused(absence['status'], 'FAILURE_CERTIFICATE', acquisition=learned, receipt=absence)
    end_stage('failure_acquisition_and_check_seconds')
    marked_catalogue = modules['failure_markings_v1'].MarkedCatalogue(compiled, definitions, depth, certificate)
    marked_provider = modules['failure_markings_v1'].Provider(provider, model, marked_catalogue, 'MARKS')
    expected_marked = _expected_marked_model(model, certificate, provider.identity)
    need(text(expected_marked) == text(marked_provider.model), 'EXACT_MARKED_SEED_AND_IDENTITY')
    marked_rows = _universe(compiled, definitions, depth, certificate)
    marked_checker = modules['marked_point_checker_v1'].Checker(
        compiled, depth, certificate['scope_sha256'], certificate['requests'])
    marked_check = marked_checker.check_model(marked_provider.model)
    if marked_check['status'] != 'VERIFIED':
        return refused(marked_check['status'], 'MARKED_MODEL', receipt=marked_check)
    for row in marked_rows:
        need(text(row) == text(marked_checker.placement(row['id'])), 'INDEPENDENT_EVERY_MARKED_ROW')
    end_stage('marked_universe_materialization_binding_seconds')
    negatives, by_id = {tuple(q) for q in certificate['requests']}, {d['id']: d for d in definitions}
    filtered, removed = [], []
    for row in base_rows:
        site, definition_id = json.loads(row['id'])
        blockers = [[fid, depth - len(site) - 1] for fid in by_id[definition_id]['premises']
                    if (fid, depth - len(site) - 1) in negatives]
        if blockers:
            removed.append(dict(id=row['id'], certified_absent_premises=blockers))
        else:
            filtered.append(row)
    filter_model = copy.deepcopy(model)
    filter_model['version'] = 'PFT-certified-filter-explicit-inventory-v1'
    filter_model['inventory'] = dict(kind='EXPLICIT', placements=copy.deepcopy(filtered))
    need([r['id'] for r in base_rows] == [r['id'] for r in marked_rows], 'MARKS_PRESERVES_ALL_CIDS')
    end_stage('filter_construction_seconds')
    prepared = dict(status='PREPARED', version=VERSION, id=declaration['id'],
        declaration=copy.deepcopy(declaration), compiled=compiled, generation=generation,
        depth=depth, definitions=definitions, factory_model=model, factory=factory,
        profile_check=profile, factory_check=factory_check, zero_checks=zero_checks,
        lanes=dict(BASE=dict(model=model, universe=base_rows),
                   MARKS=dict(model=marked_provider.model, universe=marked_rows),
                   FILTER=dict(model=filter_model, universe=filtered)),
        acquisition=dict(request_policy='Top24 premise-FID frequency, excluding top-level goal; ties by FID; heights0..H-1; frozen before classification.',
            requests=query_pairs, selected_frequencies=request_frequencies, learned=learned,
            absence_check=absence, marked_model_check=marked_check,
            all_marked_rows_independently_checked=len(marked_rows), removed_rows=removed,
            preservation_scope='Checked bounded absence contradicts an original rooted producer subtree; only certified absent premises remove rows. No exhaustive all-proof-set count claimed.',
            filter_scope='Explicit proved-redundant restricted-inventory control, not old FILTER packet potential counts.'),
        failure_certificate=certificate,
        universe_pins={mode: dict(rows=len(rows), sha256=sha(rows))
                       for mode, rows in [('BASE', base_rows), ('MARKS', marked_rows), ('FILTER', filtered)]},
        theory_reader=theory_reader(declaration), source_pins=source_pins(),
        scope='Fresh finite original-term/UI/equality-context profile; anchored symbolic point proof trees. No full PA/Hilbert, universal Wang grid, unbounded negative, RL or performance claim.')
    end_stage('return_data_hashes_reader_pins_seconds')
    prepared['stage_seconds'] = stage_seconds
    prepared['preparation_seconds'] = sum(stage_seconds.values())
    prepared['nested_stage_seconds'] = dict(factory_part_of_factory_and_zero=factory_seconds,
        zero_part_of_factory_and_zero=zero_seconds,
        scope='Nested nonadditive subdivisions. DP needs compilation/profile/native ZERO assurance; point factory, universes and marking acquisition are separate point-only costs. Common preparation is observed once per case and reused, not measured independent cold executions.')
    return prepared


def make_lane(prepared, mode):
    """Fresh model/provider/universe/setup dict; provider is the only non-JSON value."""
    need(prepared.get('status') == 'PREPARED' and mode in ('BASE', 'MARKS', 'FILTER'), 'ADMITTED_LANE_REQUIRED')
    started, modules = time.perf_counter(), _modules()
    if mode == 'FILTER':
        return dict(model=copy.deepcopy(prepared['lanes'][mode]['model']), provider=None,
            universe=prepared['lanes'][mode]['universe'],
            setup=dict(seconds=time.perf_counter() - started, inventory='EXPLICIT',
                scope='Fresh explicit inventory model; no incident index or classification rerun.'))
    compiled, generation, depth = prepared['compiled'], prepared['generation'], prepared['depth']
    model, provider, factory = modules['indexed_proof_provider_v1'].make_provider(
        compiled, generation, depth, FACTORY_LIMITS)
    need(factory['status'] == 'COMPLETE' and text(model) == text(prepared['factory_model']) and
         text(factory['value']) == text(prepared['factory']['value']), 'FRESH_FACTORY_IDENTITY')
    if mode == 'MARKS':
        catalogue = modules['failure_markings_v1'].MarkedCatalogue(
            compiled, prepared['definitions'], depth, prepared['failure_certificate'])
        provider = modules['failure_markings_v1'].Provider(provider, model, catalogue, 'MARKS')
        model = provider.model
    need(text(model) == text(prepared['lanes'][mode]['model']), 'FRESH_LANE_MODEL')
    return dict(model=model, provider=provider, universe=prepared['lanes'][mode]['universe'],
        setup=dict(seconds=time.perf_counter() - started, factory_costs=factory['costs'],
            inventory='CERTIFIED_INCIDENT', scope='Fresh index/provider; frozen checked failures only, no proof/policy/cache transfer.'))


def check_solution(prepared, result):
    """Check actual selected CIDs through rooted native tree and independent FOL."""
    if result.get('status') != 'SAT':
        return dict(status='NOT_APPLICABLE', reason='NO_POSITIVE_SOLVER_CERTIFICATE', proof_reader=[])
    modules, compiled, depth = _modules(), prepared['compiled'], prepared['depth']
    try:
        decoded = modules['indexed_proof_provider_v1'].decode(
            compiled, depth, result['selected'], FACTORY_LIMITS)
    except modules['indexed_proof_provider_v1'].InputError as error:
        return dict(status='REJECTED', reason='NATIVE_DECODER_REJECTED:' + str(error), proof_reader=[])
    if decoded['status'] != 'UNVERIFIED_CERTIFICATE':
        return dict(status='UNKNOWN' if decoded['status'] == 'UNKNOWN' else 'REJECTED',
            decoder=decoded, proof_reader=[])
    tree = modules['growing_proof_verifier_v2'].verify_tree(
        compiled, depth, result['selected'], decoded, limits=VERIFY_LIMITS)
    native = modules['independent_fol_checker_v1'].check(
        compiled['theory'], decoded['proof'], compiled['goal'], KERNEL_LIMITS)
    status = 'VERIFIED' if tree['status'] == native['status'] == 'VERIFIED' else 'REJECTED'
    if 'UNKNOWN' in (tree['status'], native['status']):
        status = 'UNKNOWN'
    return dict(status=status, decoded=decoded, tree=tree, native_fol_kernel=native,
        proof_reader=proof_reader(prepared['declaration'], decoded['proof']),
        scope='Actual original-theory solver output, rooted tree plus independent native FOL; no tiny-Horn fragment checker or separate C1 claim.')


def _tex_name(name):
    return r'\mathrm{' + str(name).replace('_', r'\_').replace('{', r'\{').replace('}', r'\}') + '}'


def _latex(ast, names):
    tag = ast[0]
    reverse = {v: k for k, v in names.items()}
    if tag == 'var':
        return _tex_name(reverse.get(ast[1], ast[1]))
    if tag in ('fun', 'pred'):
        label = reverse.get(ast[1], ast[1])
        if tag == 'fun' and not ast[2]:
            return '0' if label == 'zero' else _tex_name(label)
        return _tex_name(label) + r'\bigl(' + ','.join(_latex(x, names) for x in ast[2]) + r'\bigr)'
    if tag == 'all':
        return r'\forall ' + _tex_name(reverse.get(ast[1], ast[1])) + r'\,\bigl(' + _latex(ast[2], names) + r'\bigr)'
    if tag == 'not':
        return r'\neg\bigl(' + _latex(ast[1], names) + r'\bigr)'
    if tag == 'bot':
        return r'\bot'
    symbols = {'eq': '=', 'imp': r'\to ', 'and': r'\land ', 'or': r'\lor '}
    return r'\bigl(' + _latex(ast[1], names) + symbols[tag] + _latex(ast[2], names) + r'\bigr)'


def _english(ast, declaration):
    names, labels = declaration['names'], declaration['labels']
    reverse = {v: k for k, v in names.items()}
    tag = ast[0]
    if tag == 'var':
        return reverse.get(ast[1], ast[1])
    if tag in ('fun', 'pred'):
        label = reverse.get(ast[1], ast[1])
        args = [_english(x, declaration) for x in ast[2]]
        if not args:
            return labels.get(label, label)
        if label == 'S':
            return 'the successor of (' + args[0] + ')'
        if label == 'add':
            return 'the sum of (' + args[0] + ') and (' + args[1] + ')'
        if label == 'stamp':
            return 'the stamp of (' + args[0] + ')'
        if label == 'On':
            return args[0] + ' is incident with ' + args[1]
        return label + '(' + ', '.join(args) + ')'
    if tag == 'all':
        return 'for every ' + reverse.get(ast[1], ast[1]) + ', ' + _english(ast[2], declaration)
    if tag == 'not':
        return 'it is false that (' + _english(ast[1], declaration) + ')'
    if tag == 'bot':
        return 'a contradiction'
    left, right = _english(ast[1], declaration), _english(ast[2], declaration)
    if tag == 'eq':
        return left + ' equals ' + right
    if tag == 'imp':
        return 'if (' + left + '), then (' + right + ')'
    return '(' + left + ') ' + ('and' if tag == 'and' else 'or') + ' (' + right + ')'


def theory_reader(declaration):
    theory = declaration['problem']['theory']
    return dict(scope=declaration['scope'],
        symbol_legend=[dict(native=native, display=display, english=declaration['labels'][display])
                       for display, native in declaration['names'].items()],
        hypotheses=[dict(name=name, formula=formula, formula_latex=_latex(formula, declaration['names']),
                         english=_english(formula, declaration)) for name, formula in sorted(theory['axioms'].items())],
        conclusion=dict(formula=declaration['problem']['goal'],
                        formula_latex=_latex(declaration['problem']['goal'], declaration['names']),
                        english=_english(declaration['problem']['goal'], declaration)),
        interpretation='English is a display legend for uninterpreted symbols; no extra hypotheses, coordinates or semantic geometry are supplied.')


def proof_reader(declaration, proof):
    rows = []
    for index, line in enumerate(proof):
        rule, references = line['rule'], []
        if rule == 'mp':
            references = [line['antecedent'] + 1, line['implication'] + 1]
            reason = 'Apply the implication on line %d to line %d.' % (references[1], references[0])
        elif rule == 'generalize':
            references = [line['source'] + 1]
            reason = 'Generalize line %d; all original hypotheses are closed.' % references[0]
        elif rule == 'axiom':
            reason = 'Use the declared hypothesis ' + line['name'] + '.'
        elif rule == 'refl':
            reason = 'Use equality reflexivity.'
        elif rule == 'instantiate':
            reason = 'Use the native free-for universal-specialization implication schema.'
        elif rule == 'eq_subst':
            reason = 'Use the native equality-substitution implication schema.'
        else:
            reason = 'Use the native rule ' + rule + '.'
        rows.append(dict(line=index + 1, formula=line['formula'],
            formula_latex=_latex(line['formula'], declaration['names']),
            english=_english(line['formula'], declaration), rule=rule,
            dependencies=references, reason=reason))
    return rows
