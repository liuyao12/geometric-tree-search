"""Intensional finite native-universe lanes; no scientific work at import.

The unchanged indexed producer supplies BASE candidates. MARKS adds literal
failure-port values; IFILTER is a separately labeled certified static-inventory
control with honest restricted potential counts. No all-address row list,
target proof, learned policy or contextual pruning table is constructed.
"""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import time

ROOT = Path(__file__).resolve().parents[1]
SCHEMA = 'PFD-intensional-native-universe-v1'
MAX_DEPTH = 16
PINS = {'indexed_proof_provider_v1.py': '5261bf552924105f3c9ac3a4e9ddce0490869105b1812a8d897610267623b26e',
        'failure_certificate_checker_v1.py': '2436cc872737f9400c7bbb78949a366919a64804ca3088be1577fcdc7c7e88db'}
FACTORY = dict(max_work=1000000000, max_depth=256, max_definitions=20000,
               max_proof_lines=4096, wall_seconds=15)
_MODULES = None


def text(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(',', ':'), allow_nan=False)


def sha(value):
    return hashlib.sha256((text(value) + '\n').encode('ascii')).hexdigest()


def need(condition, reason):
    if not condition:
        raise ValueError(reason)


def modules():
    global _MODULES
    if _MODULES is not None:
        return _MODULES
    loaded = {}
    for name, expected in PINS.items():
        path = ROOT / 'reference/upstream' / name
        need(hashlib.sha256(path.read_bytes()).hexdigest() == expected, 'SOURCE_PIN:' + name)
        spec = importlib.util.spec_from_file_location('pfd_lane_' + name[:-3], path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        loaded[name[:-3]] = module
    _MODULES = loaded
    return loaded


def scope_payload(compiled):
    return dict(schema='FM-native-producer-scope-v1', depth_semantics='FM-rooted-tree-height-v1',
        compiled_schema=compiled['schema'], compiled_version=compiled['version'], theory=compiled['theory'],
        registry=dict(formulas=compiled['logical_basis']['formulas'], colors=compiled['logical_basis']['colors']),
        zero_instances=compiled['zero_instances'], mp_index=compiled['mp_index'], gen_index=compiled['gen_index'])


def descriptor(compiled, generation, depth, mode, definitions, base_identity, certificate=None):
    """Compact exact schema, including integer row counts but no row-stream SHA."""
    need(type(depth) is int and 0 <= depth <= MAX_DEPTH, 'INTENSIONAL_DEPTH_BOUND')
    need(mode in ('BASE', 'MARKS', 'IFILTER'), 'UNIVERSE_MODE')
    active_certificate = certificate if mode != 'BASE' else None
    requests = active_certificate['requests'] if active_certificate is not None else []
    negative = {tuple(q) for q in requests}
    levels = []
    for level in range(depth + 1):
        arities = [0, 0, 0]
        for definition in definitions:
            premises = definition['premises']
            if premises and level == depth:
                continue
            if mode == 'IFILTER' and any((fid, depth - level - 1) in negative for fid in premises):
                continue
            arities[len(premises)] += 1
        levels.append(dict(level=level, sites=1 << level, by_arity=arities,
            definitions_per_site=sum(arities), rows=(1 << level) * sum(arities)))
    core = {k: v for k, v in compiled.items() if k not in ('costs', 'scope')}
    body = dict(schema=SCHEMA, row_rule='CANONICAL_SITE_DEFINITION_UNIT_PORTS-v1',
        compiled_core_sha256=sha(core), registry_sha256=sha(compiled['logical_basis']),
        generation_sha256=sha(generation), definitions_sha256=sha(definitions),
        depth=depth, mode=mode, base_inventory_identity=base_identity,
        failure_scope_sha256=active_certificate['scope_sha256'] if active_certificate else None,
        failure_certificate_sha256=sha(active_certificate) if active_certificate else None,
        negative_requests=copy.deepcopy(requests), levels=levels,
        represented_rows=sum(row['rows'] for row in levels),
        represented_sites=(1 << (depth + 1)) - 1,
        scope='All canonical native producer rows at every depth-admissible binary address; IFILTER only removes checked-absent-premise rows. Logical ZERO truth and RF-profile completeness are separately admitted.')
    if mode == 'BASE':
        identity = base_identity
    elif mode == 'MARKS':
        identity = text(['FM-provider-v1', base_identity, 'MARKS', sha(requests), active_certificate['scope_sha256']])
    else:
        identity = text(['PFD-intensional-IFILTER-v1', base_identity, sha(body)])
    return dict(body, inventory_identity=identity)


class Adapter:
    incident_query_abi = 'IP-CURRENT-TM-INCIDENT-v1'

    def __init__(self, base, model, compiled, definitions, definition, certificate):
        self.base, self.model = base, model
        self.definition = definition
        self.definitions = {d['id']: d for d in definitions}
        self.depth, self.mode = definition['depth'], definition['mode']
        self.identity = definition['inventory_identity']
        self.scope = certificate['scope_sha256']
        self.negative = {tuple(pair) for pair in certificate['requests']}
        self.calls = self.rows = self.removed = self.work = 0
        self.seconds = 0.0
        self.by_level = [row['by_arity'] for row in definition['levels']]

    def potential_count(self, point):
        need(type(point) is str and len(point) <= self.depth and all(c in '01' for c in point), 'NATIVE_POINT')
        own = sum(self.by_level[len(point)])
        if not point:
            return own
        parent = self.by_level[len(point) - 1]
        return own + parent[2] + (parent[1] if point[-1] == '0' else 0)

    def __call__(self, query, charge):
        started = time.perf_counter()
        try:
            need(query['inventory_identity'] == self.identity, 'ADAPTER_QUERY_IDENTITY')
            def reserve(n=1):
                self.work += n
                charge(n)
            reserve(len(text(query)) + 1)
            translated = copy.deepcopy(query)
            translated['inventory_identity'] = self.base.identity
            packet = self.base(translated, reserve)
            current_marks, output = dict(query['marks']), []
            for row in packet['placements']:
                reserve(8 + len(row['id']))
                site, did = json.loads(row['id'])
                native = self.definitions[did]
                if self.mode == 'MARKS':
                    candidate = copy.deepcopy(row)
                    marks = dict(candidate['m'])
                    for fid in native['premises']:
                        reserve(8 + len(site))
                        marks[text(['FM-port-v1', self.scope, fid, self.depth - len(site) - 1])] = '1'
                    candidate['m'] = [[p, value] for p, value in sorted(marks.items())]
                    keep = all(p not in current_marks or current_marks[p] == value for p, value in candidate['m'])
                    reserve(2 * len(candidate['m']))
                else:
                    candidate = row
                    reserve(2 * len(native['premises']))
                    keep = not any((fid, self.depth - len(site) - 1) in self.negative for fid in native['premises'])
                if keep:
                    output.append(candidate)
                else:
                    self.removed += 1
            potential = self.potential_count(query['point'])
            self.calls += 1
            self.rows += len(output)
            reserve(sum(len(text(row)) + 1 for row in output) + len(text(query)) + 1)
            return dict(point=query['point'], context_sha256=sha(query), complete=True, placements=output,
                certificate=dict(scope='COMPLETE_CURRENT_TM_COMPATIBLE_INCIDENT_SET',
                    potential_count=potential, compatible_count=len(output)))
        finally:
            self.seconds += time.perf_counter() - started

    def snapshot(self):
        return dict(mode=self.mode, identity=self.identity, calls=self.calls, rows=self.rows,
            removed=self.removed, charged_adapter_work=self.work, seconds=self.seconds,
            base=self.base.snapshot(), represented_rows=self.definition['represented_rows'],
            scope='Fresh indexed adapter telemetry; no all-address row index, query cache, target proof or policy.')


def make_lane(compiled, generation, depth, mode='BASE', certificate=None, *, factory_limits=None):
    """Return {model,provider,factory,descriptor,absence_check,setup}.

    This explicit API builds a fresh unchanged native index. Call only after
    Source review and separate RF-profile/native-ZERO admission. BASE ignores
    any certificate argument; MARKS/IFILTER independently check its absence DAG.
    """
    started = time.perf_counter()
    need(type(depth) is int and 0 <= depth <= MAX_DEPTH, 'INTENSIONAL_DEPTH_BOUND')
    need(mode in ('BASE', 'MARKS', 'IFILTER'), 'UNIVERSE_MODE')
    loaded = modules()
    model, base, factory = loaded['indexed_proof_provider_v1'].make_provider(
        compiled, generation, depth, FACTORY if factory_limits is None else factory_limits)
    if factory['status'] != 'COMPLETE':
        return dict(status='UNKNOWN', reason='NATIVE_FACTORY_REFUSAL', factory=factory,
            setup=dict(seconds=time.perf_counter() - started))
    definitions = factory['value']['definitions']
    absence = None
    if mode != 'BASE':
        need(type(certificate) is dict and certificate['scope_sha256'] == sha(scope_payload(compiled)),
             'CERTIFICATE_CURRENT_NATIVE_SCOPE')
        absence = loaded['failure_certificate_checker_v1'].verify(compiled, certificate)
        if absence['status'] != 'VERIFIED':
            return dict(status=absence['status'], reason='ABSENCE_CERTIFICATE_REFUSAL',
                absence_check=absence, setup=dict(seconds=time.perf_counter() - started))
    definition = descriptor(compiled, generation, depth, mode, definitions, base.identity, certificate)
    if mode != 'BASE':
        model = copy.deepcopy(model)
        model['inventory']['identity'] = definition['inventory_identity']
        if mode == 'MARKS':
            marks = dict(model['seed']['m'])
            for fid, remaining in certificate['requests']:
                marks[text(['FM-port-v1', certificate['scope_sha256'], fid, remaining])] = '0'
            model['seed']['m'] = [[p, value] for p, value in sorted(marks.items())]
        else:
            model['version'] = 'PFD-intensional-IFILTER-v1'
        provider = Adapter(base, model, compiled, definitions, definition, certificate)
    else:
        provider = base
    return dict(status='PREPARED', model=model, provider=provider, factory=factory, descriptor=definition,
        absence_check=absence, setup=dict(seconds=time.perf_counter() - started,
            native_factory_costs=factory['costs'], definitions=len(definitions),
            level_definition_tests=(depth + 1) * len(definitions),
            descriptor_bytes=len((text(definition) + '\n').encode('ascii')),
            represented_rows=definition['represented_rows'],
            scope='Fresh native index, compact exact depth/row schema and optional checked absence adapter. No exponential all-address placement list or row-stream hash is materialized.'))
