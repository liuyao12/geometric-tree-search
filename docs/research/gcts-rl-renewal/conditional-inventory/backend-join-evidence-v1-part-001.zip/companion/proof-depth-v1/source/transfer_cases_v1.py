"""Fresh declarations only; no compiler, classifier, proof or solver imports."""
import copy
import hashlib

VERSION = 'PFT-fresh-declarative-cohort-v1'


def declarations():
    """Two symbol renamings of two statement families at two frozen heights.

    The namespace depends on family/renaming, not height: each renamed
    statement has the same grammar at both bounds. No expected answer,
    selected producer path or target derivation is part of a declaration.
    """
    cases = []
    for family in ('arithmetic', 'incidence'):
        for renaming in (0, 1):
            salt = 'PFT-20261103-v1:%s:%d' % (family, renaming)
            stem = 'pft' + hashlib.sha256(salt.encode('ascii')).hexdigest()[:10]
            symbols = ('zero', 'S', 'add', 'x') if family == 'arithmetic' else (
                'a', 'b', 'ell', 'emm', 'stamp', 'On', 'l', 'm')
            names = {name: stem + name for name in symbols}
            v = lambda name: ['var', names[name]]
            f = lambda name, *args: ['fun', names[name], list(args)]
            if family == 'arithmetic':
                x, z = v('x'), f('zero')
                add_zero = ['all', names['x'], ['eq', f('add', x, z), x]]
                target = ['all', names['x'], ['eq', f('S', f('add', f('S', x), z)), f('S', f('S', x))]]
                theory = dict(functions={names['zero']: 0, names['S']: 1, names['add']: 2},
                    predicates={}, axioms={stem + 'addzero': add_zero})
                terms, ui_terms = [], None
                profile = dict(ui_rounds=1, max_terms=20, max_templates=24, max_definitions=8000,
                    original_eq_context_snapshot=True, family='PA-addition-zero-fragment',
                    congruence_depth=1, shift=1, full_PA=False, induction=False)
                labels = dict(zero='zero', S='successor', add='addition', x='x')
                scope = 'Addition-zero and equality congruence; no induction or full PA formalization.'
            else:
                a, b, ell, emm = [f(name) for name in ('a', 'b', 'ell', 'emm')]
                on = lambda point, line: ['pred', names['On'], [point, line]]

                def common(u, w):
                    return ['and', ['not', ['eq', a, b]], ['and', on(a, u),
                        ['and', on(b, u), ['and', on(a, w), on(b, w)]]]]

                uniqueness = ['all', names['l'], ['all', names['m'],
                    ['imp', common(v('l'), v('m')), ['eq', v('l'), v('m')]]]]
                theory = dict(functions={names[n]: 0 for n in ('a', 'b', 'ell', 'emm')},
                    predicates={names['On']: 2}, axioms={stem + 'uniqueness': uniqueness,
                        stem + 'commonpoints': common(ell, emm)})
                theory['functions'][names['stamp']] = 1
                target = ['eq', f('stamp', ell), f('stamp', emm)]
                terms, ui_terms = [ell, emm], [ell, emm]
                profile = dict(ui_rounds=2, max_terms=20, max_templates=24, max_definitions=8000,
                    original_eq_context_snapshot=True, family='one-sorted-incidence-fragment',
                    mark_depth=1, UI_subset='ell/emm constants only', full_Hilbert_geometry=False)
                labels = dict(a='first named point', b='second named point', ell='first named line',
                    emm='second named line', stamp='stamp', On='is incident with', l='l', m='m')
                scope = 'Purely symbolic one-sorted incidence and function congruence; not full Hilbert geometry.'
            for height in (3, 4):
                case = dict(id='pft-%s-r%d-h%d-v1' % (family, renaming, height), family=family,
                    goal_label=family, renaming_index=renaming, renaming_salt=salt, names=names,
                    labels=labels, depth=height, problem=dict(theory=theory, goal=target),
                    terms=terms, profile=profile, scope=scope,
                    generation='Fresh literal names and original hypotheses/goal only; no target proof, imported lemma or expected result supplied.')
                if ui_terms is not None:
                    case['instantiation_terms'] = ui_terms
                cases.append(copy.deepcopy(case))
    return cases
