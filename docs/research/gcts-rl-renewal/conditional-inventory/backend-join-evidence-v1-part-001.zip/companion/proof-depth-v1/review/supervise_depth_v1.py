"""Observe one owned child; transient ps failures never restart that child."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time
ROOT=Path(__file__).resolve().parents[1]
PY='/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12'
def cpu(text):
    parts=text.strip().split(':');total=0.0
    for part in parts:total=60*total+float(part)
    return total
def main():
    phase=sys.argv[1];assert phase in ('qualification','study')
    receipt=ROOT/'review'/('observer-'+phase+'-v1.json');assert not receipt.exists()
    stdout=ROOT/'review'/(phase+'.stdout.log');stderr=ROOT/'review'/(phase+'.stderr.log')
    assert not stdout.exists() and not stderr.exists()
    command=[PY,'-I','-S','-B',str(ROOT/'source/run_depth_v1.py'),phase]
    started=time.monotonic();samples=[];failures=[];guard=None
    with stdout.open('xb') as out,stderr.open('xb') as err:
        child=subprocess.Popen(command,cwd=ROOT,stdout=out,stderr=err)
        while child.poll() is None:
            try:
                observed=subprocess.run(['ps','-p',str(child.pid),'-o','rss=','-o','time=','-o','stat='],capture_output=True,text=True,timeout=3)
                if observed.returncode==0 and observed.stdout.strip():
                    rss,t,state=observed.stdout.split();sample=dict(seconds=time.monotonic()-started,rss_bytes=int(rss)*1024,cpu_seconds=cpu(t),state=state)
                    samples.append(sample)
                    if sample['rss_bytes']>2*1024**3:guard='RSS_2_GIB'
                    if sample['cpu_seconds']>900:guard='CPU_900_SECONDS'
                elif child.poll() is None:failures.append(dict(seconds=time.monotonic()-started,error=observed.stderr or 'No ps row while child not yet terminal'))
            except (OSError,ValueError,subprocess.TimeoutExpired) as error:
                failures.append(dict(seconds=time.monotonic()-started,error=type(error).__name__+': '+str(error)))
            if time.monotonic()-started>1200:guard='WALL_1200_SECONDS'
            if guard:
                child.terminate()
                try:child.wait(timeout=5)
                except subprocess.TimeoutExpired:child.kill();child.wait()
                break
            time.sleep(1)
        status=child.wait()
    value=dict(status='TERMINAL',phase=phase,native_pid=child.pid,native_exit=status,guard=guard,
        command=command,seconds=time.monotonic()-started,samples=samples,observation_failures=failures,
        sampled_peak_rss_bytes=max((x['rss_bytes'] for x in samples),default=None),
        source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        scope='Same original child observed through Popen handle. Guards cause explicit termination/unknown evidence, never proof of failure. Sampled RSS is not an exact peak; child phase receipts separately retain lifetime ru_maxrss.')
    receipt.write_text(json.dumps(value,indent=2)+'\n');print(json.dumps({k:value[k] for k in ('status','phase','native_pid','native_exit','guard','seconds')}),flush=True)
    raise SystemExit(0 if status==0 and guard is None else 1)
if __name__=='__main__':main()
