"""Saved-byte depth audit/report summary, without scientific module execution.

No compiler, provider, classifier, decoder, graph/native checker or search is
imported. One prepared case and one raw payload are resident at a time.
"""
import collections
import gc
import gzip
import hashlib
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MASTER = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md')
PARENT_DECLARATIONS = ROOT/'review/prior-family-declarations-v1.json'
PARENT_DECLARATIONS_SOURCE = ROOT.parent/'gcts-proof-family-transfer-20261103-v1/data/family-declarations-v1.json'
MASTER_SHA = 'c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9'
HASH_SCOPE = 'INTENSIONAL_DESCRIPTOR_NOT_EXPANDED_ROW_STREAM'


def wire(value):
    return (json.dumps(value,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')


def sha(value):
    return hashlib.sha256(wire(value)).hexdigest()


def pin(path):
    digest=hashlib.sha256();total=0
    with path.open('rb') as stream:
        while True:
            data=stream.read(1024*1024)
            if not data:break
            digest.update(data);total+=len(data)
    return dict(bytes=total,sha256=digest.hexdigest())


def path(name):
    value=(ROOT/name).resolve()
    assert not Path(name).is_absolute() and value.is_relative_to(ROOT),name
    return value


def read(name):
    p=path(name)
    with (gzip.open(p,'rt',encoding='ascii') if p.suffix=='.gz' else p.open('r',encoding='ascii')) as stream:
        return json.load(stream)


def save(name,value):
    p=ROOT/name;p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('xb') as stream:stream.write(wire(value))
    return dict(path=name,**pin(p))


def ptr(value,pointer):
    assert type(pointer) is str and pointer.startswith('/')
    for item in pointer[1:].split('/'):
        item=item.replace('~1','/').replace('~0','~')
        value=value[int(item)] if type(value) is list else value[item]
    return value


def normalized_model(model):
    """Ordering-only normalization already specified by the frozen engine ABI."""
    inv=dict(model['inventory'])
    if inv['kind']=='EXPLICIT':
        inv['placements']=sorted([dict(id=r['id'],t=sorted(r['t'],key=lambda x:x[0]),
            m=sorted(r['m'],key=lambda x:x[0])) for r in inv['placements']],key=lambda r:r['id'])
    return dict(schema=model['schema'],version=model['version'],capacity=model['capacity'],
        roots=sorted(model['roots']),seed=dict(t=sorted(model['seed']['t'],key=lambda x:x[0]),
            m=sorted(model['seed']['m'],key=lambda x:x[0])),inventory=inv)


def fm_port(point):
    try:
        value=json.loads(point)
        return type(value) is list and len(value)==4 and value[0]=='FM-port-v1'
    except (TypeError,ValueError):
        return False


def normalized_snapshot(snapshot):
    """Inspection-only projection erasing solely named failure-marking ports."""
    result=dict(snapshot)
    result['marks']=[row for row in snapshot['marks'] if not fm_port(row[0])]
    result['placements']=[dict(row,m=[pair for pair in row['m'] if not fm_port(pair[0])])
                          for row in snapshot['placements']]
    result['dependencies']=dict(snapshot['dependencies'])
    result['dependencies']['m']=[row for row in snapshot['dependencies']['m'] if not fm_port(row[0])]
    return result


def differences(left,right,prefix=''):
    if type(left) is not type(right):return [prefix or '/']
    if type(left) is dict:
        result=[]
        for key in sorted(set(left)|set(right)):
            p=prefix+'/'+str(key).replace('~','~0').replace('/','~1')
            result.extend([p] if key not in left or key not in right else differences(left[key],right[key],p))
        return result
    if type(left) is list:
        result=[] if len(left)==len(right) else [prefix+'/length']
        for i,(a,b) in enumerate(zip(left,right)):result.extend(differences(a,b,prefix+'/'+str(i)))
        return result
    return [] if left==right else [prefix or '/']


def normalized_problem(declaration):
    """Mechanical symbol-name erasure for declaration provenance, not inference."""
    reverse={native:display for display,native in declaration['names'].items()}
    def ast(value):
        tag=value[0]
        if tag=='var':return [tag,reverse.get(value[1],value[1])]
        if tag in ('fun','pred'):return [tag,reverse.get(value[1],value[1]),[ast(c) for c in value[2]]]
        if tag=='all':return [tag,reverse.get(value[1],value[1]),ast(value[2])]
        if tag in ('eq','imp','and','or'):return [tag,ast(value[1]),ast(value[2])]
        if tag=='not':return [tag,ast(value[1])]
        assert tag=='bot';return ['bot']
    theory=declaration['problem']['theory']
    value=dict(functions={reverse.get(k,k):v for k,v in theory['functions'].items()},
        predicates={reverse.get(k,k):v for k,v in theory['predicates'].items()},
        axioms=sorted([ast(v) for v in theory['axioms'].values()],key=lambda x:wire(x)),
        goal=ast(declaration['problem']['goal']),terms=[ast(t) for t in declaration.get('terms',[])],
        profile=declaration['profile'])
    if 'instantiation_terms' in declaration:value['instantiation_terms']=[ast(t) for t in declaration['instantiation_terms']]
    return value


class Audit:
    def __init__(self):
        self.refs={};self.files={};self.source_pins={}
        self.counts=collections.defaultdict(collections.Counter)
        self.graph_counts=collections.defaultdict(collections.Counter)
        self.event_kinds=collections.defaultdict(collections.Counter)
        self.run_checks=[];self.preparations=[];self.cost_rows=[];self.proofs=[]

    def file(self,name):
        value=dict(path=name,**pin(path(name)));self.files[name]={k:value[k] for k in ('bytes','sha256')}
        return value

    def ref(self,value):
        assert type(value) is dict and {'path','bytes','sha256'}<=set(value)
        expected={k:value[k] for k in ('bytes','sha256')};name=value['path']
        if name not in self.refs:
            assert pin(path(name))==expected,name;self.refs[name]=expected
        else:assert self.refs[name]==expected,name
        return name

    def load(self,reference):
        return read(self.ref(reference))

    def walk(self,value):
        if type(value) is dict:
            if {'path','bytes','sha256'}<=set(value) and not Path(value['path']).is_absolute():self.ref(value)
            for child in value.values():self.walk(child)
        elif type(value) is list:
            for child in value:self.walk(child)

    def provenance(self):
        protocols={};observers={};invocations={}
        assert pin(MASTER)['sha256']==MASTER_SHA
        assert pin(path('reference/basic-tiling-algorithm.md'))==pin(MASTER)
        supervisor_pins={p.relative_to(ROOT).as_posix():pin(p) for p in (ROOT/'review').iterdir()
                         if p.name.startswith('supervise_') and p.suffix=='.py'}
        for phase in ('qualification','study'):
            protocol=read('data/'+phase+'-protocol-v1.json')
            assert protocol['declarations_sha256']==sha(protocol['declarations'])
            for name,expected in protocol['pins'].items():
                assert pin(path(name))==expected,name
                if name in self.source_pins:assert self.source_pins[name]==expected,('CHANGED_PHASE_INTERSECTION',name)
                self.source_pins[name]=expected
            runtime=protocol['runtime']
            assert pin(Path(runtime['path']))=={k:runtime[k] for k in ('bytes','sha256')}
            assert pin(MASTER)=={k:protocol['primary_master'][k] for k in ('bytes','sha256')}
            observer=read('review/observer-'+phase+'-v1.json')
            assert observer['status']=='TERMINAL' and observer['native_exit']==0 and observer['guard'] is None
            assert observer['source_sha256'] in {p['sha256'] for p in supervisor_pins.values()}
            invocation=read('review/'+phase+'-invocation-v1.json');assert invocation['status']=='COMPLETE'
            protocols[phase]=dict(reference=self.file('data/'+phase+'-protocol-v1.json'),
                pinned_files=len(protocol['pins']),runtime=runtime,declarations_sha256=protocol['declarations_sha256'])
            observers[phase]=dict(reference=self.file('review/observer-'+phase+'-v1.json'),
                **{k:v for k,v in observer.items() if k not in ('samples','command')},
                sample_count=len(observer.get('samples',[])))
            invocations[phase]=dict(reference=self.file('review/'+phase+'-invocation-v1.json'),**invocation)
            for suffix in ('.stdout.log','.stderr.log'):self.file('review/'+phase+suffix)
        self.file('review/root-peer-source-review-v1.json');self.file('review/dependency-snapshot-v1.json')
        return dict(protocols=protocols,observers=observers,invocations=invocations,
            current_source_pins=self.source_pins,supervisor_pins=supervisor_pins,
            current_master=dict(path=str(MASTER),**pin(MASTER)),
            unchanged_engine=self.source_pins['reference/upstream/growing_point_search_v2.py'],
            scope='Both recorded Source/runtime/master phase pins rechecked; intersections agree. Original native exits0 retained; observed RSS is sampled and invocation ru_maxrss is lifetime high-water.')

    def prepared(self,reference,group):
        p=self.load(reference);assert p['status']=='PREPARED'
        c,g=p['compiled'],p['generation'];profile=p['profile_check']
        assert profile['status']==p['factory_check']['status']=='VERIFIED'
        assert profile['declaration_sha256']==sha(p['declaration'])
        core=sha({k:v for k,v in c.items() if k not in ('costs','scope')})
        assert profile['compiled_core_sha256']==g['compiled_core_sha256']==core
        assert profile['counts']=={k:v for k,v in c['costs'].items() if k!='seconds'}
        assert p['factory']['status']=='COMPLETE' and p['factory']['value']['definitions']==p['definitions']
        assert len(p['zero_checks'])==len(c['zero_instances'])
        for check,zero in zip(p['zero_checks'],c['zero_instances']):
            assert check['id']==zero['id'] and check['native_rule']==zero['rule']
            assert check['receipt']['status']=='VERIFIED' and check['receipt']['checked_lines']==1
        self.counts[group]['native_zero_receipts']+=len(p['zero_checks'])
        cert=p['failure_certificate'];acq=p['acquisition'];absence=acq['absence_check']
        payload=dict(schema='FM-native-producer-scope-v1',depth_semantics='FM-rooted-tree-height-v1',
            compiled_schema=c['schema'],compiled_version=c['version'],theory=c['theory'],
            registry=dict(formulas=c['logical_basis']['formulas'],colors=c['logical_basis']['colors']),
            zero_instances=c['zero_instances'],mp_index=c['mp_index'],gen_index=c['gen_index'])
        assert cert['scope_sha256']==absence['scope_sha256']==sha(payload)
        assert absence['status']=='VERIFIED' and absence['certificate_sha256']==sha(cert)
        assert absence['negative_requests']==cert['requests']
        assert absence['checked_node_count']==len(cert['nodes'])
        assert absence['checked_nodes']==sorted([[n['fid'],n['remaining']] for n in cert['nodes']])
        assert acq['learned']['certificate']==cert and acq['learned']['requests']==acq['requests']
        classes=acq['learned']['classifications']
        assert [[q['fid'],q['remaining']] for q in classes]==acq['requests']
        assert [[q['fid'],q['remaining']] for q in classes if q['status']=='ABSENT']==cert['requests']
        self.counts[group].update(collections.Counter('classification/'+q['status'] for q in classes))
        self.counts[group]['negative_requests']+=len(cert['requests'])
        for mode,lane in p['lanes'].items():
            d,admission=lane['descriptor'],lane['descriptor_check']
            assert 'universe' not in lane
            assert admission['status']=='VERIFIED' and admission['hash_scope']==HASH_SCOPE
            assert admission['descriptor_sha256']==sha(d)
            assert admission['represented_rows']==d['represented_rows']
            assert admission['represented_sites']==d['represented_sites']==(1<<(p['depth']+1))-1
            assert admission['mode']==d['mode']==mode and admission['depth']==d['depth']==p['depth']
            assert d['compiled_core_sha256']==core and d['generation_sha256']==sha(g)
            assert d['registry_sha256']==sha(c['logical_basis']) and d['definitions_sha256']==sha(p['definitions'])
            assert d['inventory_identity']==lane['model']['inventory']['identity']
            assert lane['model']['inventory']['kind']=='CERTIFIED_INCIDENT'
            assert sum(level['rows'] for level in d['levels'])==d['represented_rows']
            for level in d['levels']:
                assert level['sites']==1<<level['level']
                assert level['definitions_per_site']==sum(level['by_arity'])
                assert level['rows']==level['sites']*level['definitions_per_site']
            if mode=='BASE':
                assert d['failure_scope_sha256'] is None and d['failure_certificate_sha256'] is None and d['negative_requests']==[]
            else:
                assert d['failure_scope_sha256']==cert['scope_sha256'] and d['failure_certificate_sha256']==sha(cert)
                assert d['negative_requests']==cert['requests']
                assert lane['absence_check']['status']=='VERIFIED'
                assert admission['absence_check']['status']=='VERIFIED'
            self.counts[group]['descriptor_admissions']+=1
        assert p['lanes']['BASE']['descriptor']['represented_rows']==p['lanes']['MARKS']['descriptor']['represented_rows']
        stages=p['stage_seconds'];assert all(type(v) in (int,float) and math.isfinite(v) and v>=0 for v in stages.values())
        assert math.isclose(sum(stages.values()),p['preparation_seconds'],abs_tol=1e-8)
        self.preparations.append(dict(id=p['id'],prepared=reference,group=group,status=p['status'],depth=p['depth'],
            definitions=len(p['definitions']),formulas=len(c['logical_basis']['formulas']),
            native_zero_receipts=len(p['zero_checks']),negative_requests=len(cert['requests']),
            classification_counts=dict(collections.Counter(q['status'] for q in classes)),
            represented_counts={m:l['descriptor']['represented_rows'] for m,l in p['lanes'].items()},
            descriptor_pins={m:sha(l['descriptor']) for m,l in p['lanes'].items()},
            preparation_seconds=p['preparation_seconds'],stage_seconds=stages,
            per_lane_preparation_seconds={m:l['preparation_lane_seconds'] for m,l in p['lanes'].items()},
            scope_sha256=cert['scope_sha256']))
        return p

    def stream(self,records,extent,label):
        assert extent['retained']==len(records)<=extent['total'],label
        if len(records)==extent['total']:
            digest=hashlib.sha256()
            for row in records:digest.update(wire(row))
            assert digest.hexdigest()==extent['sha256'],label
            return True
        return False

    def point(self,row,raw,group,prepared=None,mode=None):
        result,obs=raw['result'],raw['observations'];graph=self.load(row['graph_check'])
        assert row['id']==raw['id'] and row['result']==result['status'] and row['assurance']==graph['status']
        assert row['events']==len(obs)<=result['event_extent']['total']
        assert [o['event'] for o in obs]==result['events'][:len(obs)]
        assert all(o['event']['seq']==i for i,o in enumerate(obs))
        event_hash=self.stream(result['events'],result['event_extent'],row['id']+'/events')
        rollback_hash=self.stream(result['rollback_records'],result['rollback_extent'],row['id']+'/rollbacks')
        pe=result['provider_evidence'];query_hash=self.stream(pe['records'],pe,row['id']+'/queries')
        for packet in pe['records']:assert packet['reply']['context_sha256']==sha(packet['query'])
        assert result['model_sha256']==sha(normalized_model(raw['model']))
        for key in ('entry','final','restored'):
            value=result[key+'_state'];assert result['state_hashes'][key]==(sha(value) if value is not None else None)
        assert result['entry_state']==result['restored_state']
        journal=sum(len(wire(o)) for o in obs)
        assert journal==raw['journal']['retained_bytes']==row['journal_bytes']
        counts=graph.get('counts',{})
        assert counts.get('observations_checked',0)<=len(obs)
        assert counts.get('queries_checked',0)<=len(pe['records'])
        if graph['status']=='VERIFIED':
            assert result['status'] in ('SAT','UNSAT') and len(obs)==result['event_extent']['total']
            assert event_hash and rollback_hash and query_hash
            assert counts['observations_checked']==len(obs) and counts['queries_checked']==len(pe['records'])
            assert graph['model_sha256']==sha(normalized_model(raw['model'])) and graph['gaps']==[]
        else:
            assert graph['status']=='UNKNOWN'
        if prepared is not None:
            d=prepared['lanes'][mode]['descriptor']
            assert raw['model']==prepared['lanes'][mode]['model']
            for ref_name in ('universe_ref','native_context_ref'):
                value=raw[ref_name];self.ref(value)
                assert {k:value[k] for k in ('path','bytes','sha256')}==row['prepared']
            assert raw['universe_ref']['pointer']=='/lanes/'+mode+'/descriptor'
            assert ptr(prepared,raw['universe_ref']['pointer'])==d
            pointers=raw['native_context_ref']['pointers']
            assert pointers==dict(compiled='/compiled',generation='/generation',certificate='/failure_certificate')
            admission=graph['intensional_universe_admission']
            assert admission['status']=='VERIFIED' and admission['descriptor_sha256']==sha(d)
            assert admission['represented_rows']==d['represented_rows'] and admission['hash_scope']==HASH_SCOPE
            if graph['status']=='VERIFIED':
                assert graph['universe_sha256'] is None and graph['universe_descriptor_sha256']==sha(d)
                assert graph['universe_hash_scope']==HASH_SCOPE
        if 'full_graph_check' in row:
            full=self.load(row['full_graph_check'])
            assert full['status']==row['full_assurance']
            if result['status']!='UNKNOWN':
                assert full['status']==graph['status']=='VERIFIED' and full['counts']==graph['counts']
        if result['status']=='UNKNOWN':
            assert result['selected']==[] and result['certificate'] is None and result['final_state'] is None
        self.counts[group].update({'point_jobs':1,'point_result/'+result['status']:1,'graph/'+graph['status']:1,
            'retained_observations':len(obs),'emitted_events':result['event_extent']['total'],
            'retained_queries':len(pe['records']),'emitted_queries':pe['total'],
            'retained_rollbacks':len(result['rollback_records'])})
        self.graph_counts[group].update(counts);self.event_kinds[group].update(o['event']['kind'] for o in obs)
        check=dict(id=row['id'],group=group,mode=mode,result=result['status'],reason=result['reason'],
            graph_status=graph['status'],graph_reason=graph.get('reason'),event_total=result['event_extent']['total'],
            retained_observations=len(obs),observations_semantically_checked=counts.get('observations_checked',0),
            observation_retention_gap=result['event_extent']['total']-len(obs),
            retained_observations_not_semantically_checked=len(obs)-counts.get('observations_checked',0),
            completed_query_records=pe['total'],queries_semantically_checked=counts.get('queries_checked',0),
            event_record_hash_verified=event_hash,query_record_hash_verified=query_hash,
            rollback_record_hash_verified=rollback_hash,journal_bytes=journal,journal_refusal=raw['journal']['refusal'],
            graph_gaps=graph.get('gaps',[]),last_retained_selected=len(obs[-1]['state']['selected']) if obs else None)
        self.run_checks.append(check)
        return graph

    def native(self,row,raw,prepared,group):
        receipt=self.load(row['native_check']);status=raw['result']['status']
        assert row['proof_reader']==receipt.get('proof_reader',[])
        assert row['theory_reader']==prepared['theory_reader']
        assert prepared['theory_reader']['conclusion']['formula']==prepared['compiled']['goal']
        if status not in ('SAT','DERIVABLE'):
            assert receipt['status']=='NOT_APPLICABLE'
            return None
        assert receipt['status']==receipt['tree']['status']==receipt['native_fol_kernel']['status']=='VERIFIED'
        decoded=receipt['decoded'];proof=decoded['proof'];reader=receipt['proof_reader']
        assert decoded['target']==prepared['compiled']['goal']
        assert len(proof)==len(reader)==receipt['native_fol_kernel']['checked_lines']
        selected=sorted(raw['result']['selected'] if status=='SAT' else raw['result']['details']['selected'])
        assert selected==decoded['tree']['selected'] and len(selected)==len(set(selected))==len(proof)
        if status=='DERIVABLE':
            assert raw['result']['proof']==proof and raw['result']['details']['minimum_tree_nodes']==len(proof)
        for i,(line,r) in enumerate(zip(proof,reader),1):
            assert r['line']==i and r['formula']==line['formula'] and r['rule']==line['rule']
            assert r['formula_latex'] and r['english'] and type(r['formula_latex']) is str
            refs=([line['antecedent']+1,line['implication']+1] if line['rule']=='mp'
                  else [line['source']+1] if line['rule']=='generalize' else [])
            assert r['dependencies']==refs and all(type(n) is int and 0<n<i for n in refs)
        item=dict(id=row['id'],case_id=row['case_id'],mode=row['mode'],group=group,depth=prepared['depth'],
            lines=len(proof),proof_ast_sha256=sha(proof),actual_selected_cid_list_sha256=sha(selected),
            actual_selected_cid_count=len(selected),goal_sha256=sha(prepared['compiled']['goal']),
            rules=dict(collections.Counter(line['rule'] for line in proof)),native_check=row['native_check'])
        self.proofs.append(item);self.counts[group]['native_positive_outputs']+=1
        return item

    def cost(self,row,prepared,graph,group):
        stages=prepared['stage_seconds']
        core=sum(stages[k] for k in ('compile_seconds','independent_profile_seconds','all_native_zero_seconds'))
        mode=row['mode']
        if mode=='DP':
            accounted=core
        else:
            accounted=(core+stages['dependency_loading_seconds']+stages['factory_admission_seconds']+
                stages['reader_and_return_data_seconds']+prepared['lanes'][mode]['preparation_lane_seconds'])
            if mode!='BASE':accounted+=stages['failure_acquisition_admission_seconds']
        pipeline=row.get('pipeline_seconds_before_record')
        self.cost_rows.append(dict(id=row['id'],group=group,mode=mode,depth=prepared['depth'],
            observed_search_seconds=row['search_seconds'],
            observed_setup_seconds=row.get('setup',{}).get('seconds'),
            observed_pipeline_seconds=pipeline,observed_graph_checker_seconds=graph.get('seconds') if graph else None,
            accounted_selected_reused_preparation_seconds=accounted,
            accounted_pipeline_plus_selected_preparation_seconds=None if pipeline is None else pipeline+accounted,
            once_observed_preparation=prepared['id'],
            accounting_scope='Projection of once-observed reused stages, not an independently timed cold trial. DP includes only compile/profile/allZERO. Each point method includes its own nested compact-lane admission; MARKS/IFILTER also include failure acquisition. All actual once-only preparation/process totals are separately retained.'))


def main():
    audit=Audit();qualification=read('data/qualification-results-v1.json');study=read('data/study-results-v1.json')
    assert qualification['status']=='QUALIFIED' and qualification['sources_unchanged'] is True
    assert study['status']=='SCHEDULE_EXECUTED' and study['sources_unchanged'] is True
    assert qualification['mutations']['pending']==[]
    audit.walk(qualification);audit.walk(study);provenance=audit.provenance()
    old_declarations=json.loads(PARENT_DECLARATIONS.read_text(encoding='ascii'))
    assert pin(PARENT_DECLARATIONS)==pin(PARENT_DECLARATIONS_SOURCE)
    old_incidence=[d for d in old_declarations if d['family']=='incidence']
    assert old_incidence
    normalized_original=normalized_problem(old_incidence[0])
    assert all(normalized_problem(d)==normalized_original for d in old_incidence)
    protocol=read('data/study-protocol-v1.json');declarations=protocol['declarations']
    assert len(declarations)==4 and {d['depth'] for d in declarations}=={5,6}
    assert {(d['renaming_index'],d['depth']) for d in declarations}=={(0,5),(0,6),(1,5),(1,6)}
    assert all(d['family']=='incidence' and normalized_problem(d)==normalized_original for d in declarations)
    old_symbols={name for d in old_incidence for name in d['names'].values()}
    assert all(not (set(d['names'].values())&old_symbols) for d in declarations)
    lineage=dict(original_declarations=audit.file('review/prior-family-declarations-v1.json'),
        original_declarations_source=dict(path=str(PARENT_DECLARATIONS_SOURCE),**pin(PARENT_DECLARATIONS_SOURCE)),
        normalized_original_hypotheses_goal_profile_sha256=sha(normalized_original),
        fresh_study_declarations_sha256=sha(declarations),
        scope='Only native symbols/axiom labels and the address bounds change; original hypotheses, target, signatures, terms/UI pool and RF profile agree after mechanical renaming. No original proof is read or reused.')
    # Qualification: audit only retained complete expansions/receipts, not any reconstruction algorithm.
    for equivalent in qualification['explicit_equivalence']:
        old,new=audit.load(equivalent['old_expansion']),audit.load(equivalent['new_expansion'])
        assert equivalent['status']=='VERIFIED' and old['status']==new['status']=='COMPLETE'
        assert old['universe']==new['universe']
        assert len(old['universe'])==old['rows']==new['rows']==equivalent['rows']
        assert sha(old['universe'])==old['expanded_universe_sha256']==new['expanded_universe_sha256']==equivalent['expanded_universe_sha256']
        del old,new
    qual_by_case=collections.defaultdict(list)
    for row in qualification['native_records']:qual_by_case[row['case_id']].append(row)
    for case_id,reference in qualification['preparations'].items():
        prepared=audit.prepared(reference,'qualification')
        for row in qual_by_case.pop(case_id):
            raw=audit.load(row['raw'])
            assert row['prepared']==reference and raw['prepared_ref']==reference
            graph=audit.point(row,raw,'qualification',prepared,row['mode'])
            audit.native(row,raw,prepared,'qualification');audit.cost(row,prepared,graph,'qualification')
            del raw;gc.collect()
        del prepared;gc.collect()
    assert not qual_by_case
    for row in qualification['generic_records']:
        raw=audit.load(row['raw']);fixture=audit.load(row['fixture'])
        graph=audit.point(row,raw,'generic_qualification')
        assert raw['universe_ref']['pointer']=='/universe' and raw['model']==fixture['model']
        assert row['result']==fixture['expectation']['status']
        del raw,fixture;gc.collect()
    mutation_counts=collections.Counter()
    for row in qualification['mutations']['records']:
        receipt=audit.load(row['check']);assert row['status']==receipt['status']==row['expected']
        mutation_counts[receipt['status']]+=1
    assert mutation_counts=={'REJECTED':14,'UNKNOWN':2}
    # Study: one case and one potentially large raw trace resident at a time.
    by_case=collections.defaultdict(list)
    for row in study['records']:by_case[row['case_id']].append(row)
    comparisons=[];namespace_cores={};goal_instances=set()
    for item in study['preparations']:
        prepared=audit.prepared(item['prepared'],'study');d=prepared['declaration']
        assert item['status']=='PREPARED' and prepared['id']==item['id']
        assert d==next(decl for decl in declarations if decl['id']==item['id'])
        core=prepared['generation']['compiled_core_sha256']
        if d['renaming_index'] in namespace_cores:assert namespace_cores[d['renaming_index']]==core
        namespace_cores[d['renaming_index']]=core
        profile=prepared['profile_check']['counts'];h=prepared['depth']
        z,m,g=profile['instances'],profile['mp'],profile['gen']
        exact=z*((1<<(h+1))-1)+(m+g)*((1<<h)-1)
        assert prepared['lanes']['BASE']['descriptor']['represented_rows']==exact
        assert exact=={5:50258,6:101714}[h]
        rows=by_case.pop(prepared['id']);assert {r['mode'] for r in rows}=={'BASE','MARKS','IFILTER','DP'}
        pair={};outcomes={}
        for row in rows:
            raw=audit.load(row['raw']);assert row['prepared']==item['prepared'] and raw['prepared_ref']==item['prepared']
            assert raw['id']==row['id'] and raw['search_seconds']==row['search_seconds']
            mode=row['mode'];outcomes[mode]=raw['result']['status']
            graph=None
            if mode=='DP':
                assert row['result']==raw['result']['status']
                audit.counts['study']['DP/'+row['result']]+=1
            else:
                graph=audit.point(row,raw,'study',prepared,mode)
            proof=audit.native(row,raw,prepared,'study');audit.cost(row,prepared,graph,'study')
            if proof:goal_instances.add((d['renaming_index'],h))
            if mode in ('MARKS','IFILTER') and row['result']=='SAT':
                normalized=hashlib.sha256()
                event_projection=[]
                for observation in raw['observations']:
                    normalized.update(wire(dict(event=observation['event'],state=normalized_snapshot(observation['state']))))
                    event_projection.append({k:observation['event'][k] for k in ('kind','point','candidate')})
                pair[mode]=dict(events=raw['result']['events'],event_projection=event_projection,
                    normalized_observation_stream_sha256=normalized.hexdigest(),proof=proof,
                    selected_sha256=sha(sorted(raw['result']['selected'])))
            del raw;gc.collect()
        if set(pair)=={'MARKS','IFILTER'}:
            a,b=pair['MARKS'],pair['IFILTER'];paths=differences(a['events'],b['events'])
            comparisons.append(dict(case_id=prepared['id'],depth=h,
                outcomes=outcomes,exact_event_dicts_equal=not paths,event_difference_count=len(paths),
                event_difference_paths=paths[:200],difference_paths_retained='ALL' if len(paths)<=200 else 'FIRST200',
                kind_point_candidate_projection_equal=a['event_projection']==b['event_projection'],
                normalized_observation_stream_equal=a['normalized_observation_stream_sha256']==b['normalized_observation_stream_sha256'],
                normalized_observation_sha256={mode:pair[mode]['normalized_observation_stream_sha256'] for mode in pair},
                actual_selected_cid_lists_equal=a['selected_sha256']==b['selected_sha256'],
                actual_selected_cid_list_sha256={mode:pair[mode]['selected_sha256'] for mode in pair},
                actual_native_proof_asts_equal=a['proof']['proof_ast_sha256']==b['proof']['proof_ast_sha256'],
                actual_native_proof_ast_sha256={mode:pair[mode]['proof']['proof_ast_sha256'] for mode in pair},
                selected_proof_lines={mode:pair[mode]['proof']['lines'] for mode in pair},
                scope='These are actual returned proof CID lists and actual trace comparisons, not all bounded proof sets. Projection removes only explicitly tagged FM-port-v1 mark rows/dependencies; raw/model/packet telemetry differences are retained separately.'))
        del prepared,pair;gc.collect()
    assert not by_case
    per_method={}
    for mode in ('BASE','MARKS','IFILTER','DP'):
        rows=[r for r in audit.cost_rows if r['group']=='study' and r['mode']==mode]
        totals={}
        for key in ('observed_search_seconds','observed_setup_seconds','observed_pipeline_seconds',
                    'observed_graph_checker_seconds','accounted_selected_reused_preparation_seconds',
                    'accounted_pipeline_plus_selected_preparation_seconds'):
            values=[r[key] for r in rows if r.get(key) is not None]
            totals[key]=dict(available=len(values),unavailable=len(rows)-len(values),total=sum(values) if values else None)
        per_method[mode]=dict(jobs=len(rows),totals=totals)
    coverage=dict(study=dict(audit.counts['study']),qualification_native=dict(audit.counts['qualification']),
        qualification_generic=dict(audit.counts['generic_qualification']),
        qualification_searches=len(qualification['native_records'])+len(qualification['generic_records']),
        qualification_full_expansion_equivalences=len(qualification['explicit_equivalence']),
        qualification_mutants=dict(mutation_counts),study_jobs=len(study['records']),
        study_fresh_statement_bound_cases=len(study['preparations']),positive_literal_statement_bound_cases=len(goal_instances),
        schematic_positive_target_families=1,graph_receipt_counts={k:dict(v) for k,v in audit.graph_counts.items()},
        event_kinds={k:dict(v) for k,v in audit.event_kinds.items()},
        actual_native_outputs=audit.proofs,matched_MARKS_IFILTER_comparisons=comparisons,
        exact_all_bounded_proof_set_enumeration='NOT_ATTEMPTED')
    limitations=[
        'The target is a fresh symbolic one-sorted incidence/equality consequence, with uninterpreted point/line labels and an uninterpreted stamp function. There are no coordinates, metric computations or full Hilbert axiom/sort formalization.',
        'Twelve positive study outputs across methods, two renamings and two heights are repeated searches of one schematic implication, not twelve new theorems. Point proofs may be padded; the memoized control minimizes expanded tree-node count in the same finite native grammar.',
        'BASE resource UNKNOWNs remain original incomplete searches, not logical negatives. Their graph checkers also timed out on prefixes; retained observations/query records beyond those prefixes are not independently certified merely because their byte hashes are known.',
        'Complete intensional universe admission is conditional on separate checked RF-profile enumeration and every native ZERO schema. Tiny explicit/intensional equivalence and mutation qualification support the unchanged engine/checker extension; no global unrestricted conformance theorem is claimed.',
        'Descriptor hashes bind compact exact CID/row schemas and represented counts. They are not expanded-universe row-stream hashes; no deep full row list was materialized.',
        'No exhaustive set of all bounded proofs was computed. Bounded absence certificates justify the stated redundant marking/filter transformation; actual returned CID-list equality is a narrower observation.',
        'MARKS versus IFILTER compares literal global-port constraints with direct static filtering under the same indexed base and finite scope. Matched trace equality supports this implementation comparison, not a new logical inference rule or superiority over conventional memoization.',
        'Preparation was measured once per case and reused. Per-method end-to-end totals are explicitly labeled accounting projections, not separately measured cold trials. DP is charged only compile/profile/all-ZERO stages; point-only factory, acquisition and descriptor work are excluded from its projection.',
        'This remains an anchored binary-address point-proof adaptation. It is not arithmetic/geometry proof search on a single universal fixed Wang square-grid palette, and it contains no newly trained RL or general ATP benchmark.',
        'This report assembler only joins saved bytes, extents, scope digests and existing receipts. It reruns no native checker, provider, classifier, proof decoder, graph oracle or search.'
    ]
    costs=dict(study_per_method=per_method,per_run=audit.cost_rows,
        preparations=audit.preparations,process_invocations=provenance['invocations'],
        observers=provenance['observers'],
        once_observed_study_preparation_seconds=sum(p['preparation_seconds'] for p in audit.preparations if p['group']=='study'),
        scope='Search/setup/pipeline/check clocks have their recorded windows. Native verification, persistence and cleanup are within pipeline where no separate timer exists. Reused-stage accounting is not additive to inclusive process clocks and does not claim independently measured cold runs.')
    qualifier=dict(status=qualification['status'],reference=audit.file('data/qualification-results-v1.json'),
        native_records=qualification['native_records'],generic_records=qualification['generic_records'],
        explicit_equivalence=qualification['explicit_equivalence'],mutations=qualification['mutations'],
        native_preparations=qualification['preparations'],
        scope='Nine actual native and three generic searches; both readers use the same retained raw result per tiny search. Mutants and resource refusals do not rerun any search.')
    for name in ('data/study-results-v1.json','data/qualification-results-v1.json',
                 'review/assemble_depth_results_v1.py','reference/intensional-universe-API-v1.md'):
        audit.file(name)
    result=dict(status='PASS_SAVED_DEPTH_AUDIT',method=__doc__,coverage=coverage,provenance=provenance,lineage=lineage,
        preparations=audit.preparations,run_checks=audit.run_checks,references_verified=audit.refs,
        files=audit.files,limitations=limitations)
    audit_ref=save('review/saved-data-audit-v1.json',result)
    summary=dict(schema='PDI-saved-depth-summary-v1',status='EXECUTED_WITH_BASE_UNKNOWNS',
        records=study['records'],families=study['records'],preparations=study['preparations'],
        qualification=qualifier,coverage=coverage,costs=costs,limitations=limitations,
        provenance=provenance,lineage=lineage,saved_data_audit=audit_ref,
        descriptor_hash_scope=HASH_SCOPE,
        normalization_scope='Ordering-only model hashing follows the frozen engine ABI. MARKS/IFILTER inspection projection removes only named FM-port-v1 mark/dependency entries; raw artifacts remain unchanged and projected states are not replacement checker inputs.')
    summary_ref=save('data/report-summary-v1.json',summary)
    print(json.dumps(dict(status=result['status'],audit=audit_ref,summary=summary_ref,study=coverage['study']),sort_keys=True))


if __name__=='__main__':
    main()
