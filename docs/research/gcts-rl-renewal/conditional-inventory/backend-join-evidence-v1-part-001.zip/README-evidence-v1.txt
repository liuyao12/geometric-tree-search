Arithmetic backend join and admitted depth companion, 2026-11-03.

Download EVERY backend-join-evidence-v1-part-NNN.zip and the external
backend-join-evidence-manifest-v1.json. Each volume is a separate valid ZIP,
at most forty-four MiB. Extract all volumes into one empty directory. Each has
the identical ARCHIVE-file-manifest-v1.json; identical copies may overwrite.
Every original task path is physically stored exactly once, without aliases or
deduplication. The manifest binds every original path/byte count/SHA256 and every
volume's completed bytes/hash. Publication verifies every original and every CRC.

All task Sources, original declarations/selected proof, circuit/raw/map data,
certificates, actual counterchecks, logs, reviews, retained UNKNOWN and viewer
assets at the archive cut are kept. The entire admitted companion/proof-depth-v1
tree is physically included with its Sources, acquisitions, raw searches,
certificates, qualification, failures/refusals, graph checks and logs.
Publication Python Sources are physically included. Generated package outputs
and publication planning/deployment receipts are excluded to avoid recursion.
Deployment receipts created after this cut remain local custody evidence. Full task archive
and local paths are explicitly approved for the existing public destination.

Serve the extracted directory with python3 -m http.server and open
report/backend-join-v1.html. Scientific code is inert data for the reader.
The actual previously searched 12-line arithmetic proof is joined through raw
syntax and named logical checks, independent inverse/statement binding, NAND
acceptance and the fixed 100-type Wang palette's compressed certificate. Its
nominal large tile count is not primitive search or literal expanded work; the
literal resource refusal remains UNKNOWN. The deeper symbolic-incidence study
is a separate finite RF grammar/height proof search, not a geometry-to-NAND join.
Bounded absence is not unrestricted nonprovability. No ATP/RL superiority,
complete PA/Hilbert geometry, universal primitive Wang proof search or plane
tiling is established. The full research program remains ACTIVE.
