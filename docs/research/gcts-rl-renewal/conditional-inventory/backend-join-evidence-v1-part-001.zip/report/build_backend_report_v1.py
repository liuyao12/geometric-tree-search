"""Passive backend reader; no encoder/compiler/kernel/circuit/search import.

Requires the admitted saved-data summary. Exact compressed artifacts remain
downloadable. Only explicitly labeled display samples of ribbons are projected.
"""
import gzip
import hashlib
import html
import json
from pathlib import Path
import sys


STYLE = r'''
:root{--ink:#182839;--muted:#586b7b;--line:#d8e1e9;--blue:#1b6d9b;--purple:#7754ab}*{box-sizing:border-box}body{margin:0;background:#f4f7fa;color:var(--ink);font:16px/1.55 system-ui,-apple-system,sans-serif}header,main,footer{max-width:1230px;margin:auto;padding:25px}header{padding-top:48px}h1{font:600 clamp(2rem,4vw,3.1rem)/1.12 Georgia,serif;letter-spacing:-.025em;max-width:950px}h2{font:600 1.6rem/1.2 Georgia,serif;margin-top:0}h3{font-size:1.02rem}.eyebrow{text-transform:uppercase;letter-spacing:.13em;font-weight:750;font-size:.73rem;color:var(--blue)}.lede{font-size:1.12rem;max-width:960px}.card{background:#fff;border:1px solid var(--line);border-radius:14px;padding:23px;margin-bottom:22px}.scope{border-left:5px solid var(--purple)}.note{color:var(--muted);font-size:.88rem}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:13px}.metric{padding:15px;background:#eff5f9;border-radius:9px}.metric strong{display:block;font-size:1.45rem}.chain{display:flex;gap:10px;flex-wrap:wrap}.chain span{border:1px solid var(--line);border-radius:7px;padding:9px;background:#f6f9fb}a{color:#155f95}.links{display:flex;gap:14px;flex-wrap:wrap}.badge{display:inline-block;font:650 .74rem/1.5 ui-monospace,monospace;padding:3px 7px;border:1px solid var(--line);border-radius:5px;background:#edf1f5}.good{background:#e9f5ed;color:#245e3d}.unknown{background:#fff2d5;color:#7a5b17}.bad{background:#faeaea;color:#973c3c}.toolbar{display:flex;gap:12px;flex-wrap:wrap;align-items:end;margin:17px 0}label{display:flex;flex-direction:column;font-size:.85rem;font-weight:650;gap:5px}select,button{font:inherit;color:var(--ink);background:white;border:1px solid #b9c8d5;border-radius:7px;padding:8px 10px;max-width:100%}button{cursor:pointer}button:hover{background:#edf5fa}.scroll{overflow:auto;max-width:100%}table{border-collapse:collapse;width:100%;font-size:.86rem}th,td{padding:10px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top}th{background:#f2f6f9;font-size:.77rem}pre,code{font:12px/1.5 ui-monospace,SFMono-Regular,Consolas,monospace;overflow-wrap:anywhere}pre{background:#f1f5f8;border-radius:8px;padding:13px;white-space:pre-wrap;max-height:430px;overflow:auto}.split{display:grid;grid-template-columns:1fr 1fr;gap:17px}.formula{min-width:250px}.current{background:#edf7fc}.swatch{display:inline-block;width:12px;height:12px;border-radius:3px;margin-right:6px}.chip{display:inline-flex;align-items:center;border:1px solid var(--line);border-radius:6px;padding:5px 8px;margin:4px;font-size:.8rem}#tiles svg,#top-tiles svg{display:block;width:100%;min-width:700px;max-width:1180px}.tile{cursor:pointer}.tile:focus{outline:3px solid var(--purple)}details{margin:13px 0}summary{cursor:pointer;font-weight:650}.bands{overflow:auto}.bands svg{min-width:750px;width:100%;display:block}.error{padding:14px;background:#fff0f0;border-left:4px solid #a54646}footer{font-size:.86rem;color:var(--muted);padding-bottom:42px}@media(max-width:760px){header,main,footer{padding:17px}.card{padding:16px}.split{grid-template-columns:1fr}header{padding-top:28px}label{width:100%}h1{font-size:2.1rem}}
'''

STYLE += r'''
#proof-table table,#depth-proof-table table{table-layout:fixed;width:100%}#proof-table th:nth-child(1),#depth-proof-table th:nth-child(1){width:5%}#proof-table th:nth-child(2),#depth-proof-table th:nth-child(2){width:43%}#proof-table th:nth-child(3),#depth-proof-table th:nth-child(3){width:31%}#proof-table th:nth-child(4),#depth-proof-table th:nth-child(4){width:21%}#proof-table td,#depth-proof-table td{min-width:0;overflow-wrap:anywhere}#proof-table td.formula,#depth-proof-table td.formula{min-width:0}.formula-scroll{max-width:100%;overflow-x:auto;overflow-y:hidden;padding-bottom:7px}.formula-scroll mjx-container{min-width:max-content}#depth-proof-table{margin-top:14px}body{overflow-x:clip}.card,.split>*{min-width:0}#statement .formula-scroll{max-width:100%}
'''


SCRIPT = r'''
const $=id=>document.getElementById(id),esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let data,lineIndex=0,groupIndex=0,rowIndex=0,windowIndex=0;
const show=x=>x===null||x===undefined?'Unavailable':typeof x==='object'?JSON.stringify(x):String(x), badge=x=>`<span class="badge ${/^(VERIFIED|PASS)/.test(show(x))?'good':/UNKNOWN|PENDING|INCOMPLETE/.test(show(x))?'unknown':/REJECT|FAIL/.test(show(x))?'bad':''}">${esc(show(x))}</span>`;
const table=(headers,rows)=>`<div class="scroll"><table><thead><tr>${headers.map(x=>`<th>${esc(x)}</th>`).join('')}</tr></thead><tbody>${rows.join('')}</tbody></table></div>`;
function pairs(value){return value&&typeof value==='object'?table(['Recorded field','Recorded value'],Object.entries(value).map(([k,v])=>`<tr><td><code>${esc(k)}</code></td><td>${v&&typeof v==='object'?`<pre>${esc(JSON.stringify(v,null,2))}</pre>`:esc(show(v))}</td></tr>`)):`<p>${esc(show(value))}</p>`;}
let mathQueue=Promise.resolve();function typeset(node=document.body){mathQueue=mathQueue.then(async()=>{if(window.MathJax?.startup?.promise)await window.MathJax.startup.promise;if(window.MathJax?.typesetPromise)await window.MathJax.typesetPromise([node]);});mathQueue.catch(error=>console.error("Math typesetting failed",error));}window.addEventListener("load",()=>typeset(document.body));
function formula(row){return `\\(${esc(row?.formula_latex??'\\text{Unavailable}')}\\)`;}
function proofTable(){return table(['Line','Original mathematical formula','English reading','Rule and dependencies'],data.lines.map((l,i)=>`<tr class="${i===lineIndex?'current':''}"><td><button data-line="${i}">${i+1}</button></td><td class="formula"><div class="formula-scroll">${formula(l.reader)}</div></td><td>${esc(show(l.reader.english))}</td><td><code>${esc(l.reader.rule)}</code><br>${esc(show(l.reader.dependencies))}<br><span class="note">${esc(show(l.reader.reason))}</span></td></tr>`));}
function renderProof(){let l=data.lines[lineIndex];$('proof-table').innerHTML=proofTable();document.querySelectorAll('[data-line]').forEach(b=>b.addEventListener('click',()=>selectLine(Number(b.dataset.line))));$('selected-formula').innerHTML=`<h3>Proof line ${lineIndex+1}</h3><div class="formula-scroll">${formula(l.reader)}</div><p>${esc(l.reader.english)}</p><p class="note">${esc(l.reader.reason)}</p>`;$('raw-record').textContent=JSON.stringify({zero_based_record_index:lineIndex,raw_record:l.raw_record,raw_rule_name:l.raw_rule_name,independently_decoded_line:l.decoded_line,formula_AST_from_raw_node:l.raw_formula_ast},null,2);
 $('fields').innerHTML=table(['Raw field','Integer','Bits, least significant first','Top input columns'],l.input_fields.map(f=>`<tr><td><code>${esc(f.field)}</code></td><td><code>${f.value}</code></td><td><code>${f.bits_lsb.join(' ')}</code></td><td><code>${f.input_columns.join(', ')}</code></td></tr>`));
 $('top-windows').innerHTML=l.top_windows.map((w,i)=>`<option value="${i}">Input columns ${w.start}…${w.end-1}</option>`).join('');renderTop();typeset($('proof-reader'));}
function selectLine(i){lineIndex=i;$('line').value=i;let match=data.groups.findIndex(g=>g.proof_line===i);if(match>=0){groupIndex=match;$('group').value=match;rowIndex=windowIndex=0;}renderProof();renderGroup();}
function renderBands(){let total=data.metrics.compile.gates,parts=[`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1100 ${35+data.groups.length*24}" role="img" aria-label="Actual compiler gate intervals">`];data.groups.forEach((g,i)=>{let y=20+i*24,x=300+780*g.start/total,w=Math.max(1,780*(g.end-g.start)/total);parts.push(`<g data-band="${i}" tabindex="0" role="button"><title>${esc(JSON.stringify({label:g.label,start:g.start,end:g.end,proof_line:g.proof_line}))}</title><text x="8" y="${y+11}" font-size="11" fill="#526477">${esc(g.label)}</text><rect x="${x}" y="${y}" width="${w}" height="16" rx="3" fill="${i===groupIndex?'#cf9140':g.proof_line!==undefined?'#397ea5':'#8063ab'}"/></g>`);});parts.push('</svg>');$('bands').innerHTML=parts.join('');document.querySelectorAll('[data-band]').forEach(b=>b.addEventListener('click',()=>{groupIndex=Number(b.dataset.band);$('group').value=groupIndex;rowIndex=windowIndex=0;renderGroup();}));}
function renderGroup(){let g=data.groups[groupIndex];renderBands();$('association').innerHTML=g.proof_line===lineIndex?'<p class="note">This interval contains newly emitted checker gates for the selected raw proof record. Shared dependencies may be in earlier intervals.</p>':'<p class="note">This is a global check or a different proof-record band. It is not a new mathematical inference for the currently selected formula.</p>';$('gate-range').textContent=`Recorded half-open gate interval [${g.start}, ${g.end}); ${g.end-g.start} newly emitted NAND gates.`;
 $('row').innerHTML=g.samples.map((r,i)=>`<option value="${i}">Gate row ${r.y} · ${r.position}</option>`).join('');rowIndex=Math.min(rowIndex,Math.max(0,g.samples.length-1));$('row').value=rowIndex;renderRow();}
function renderRow(){let g=data.groups[groupIndex],r=g.samples[rowIndex];if(!r){$('tiles').innerHTML='<p class="note">No sampled row in this band.</p>';return;}$('window').innerHTML=r.windows.map((w,i)=>`<option value="${i}">${esc(w.label)} · columns ${w.start}…${w.end-1}</option>`).join('');windowIndex=Math.min(windowIndex,r.windows.length-1);$('window').value=windowIndex;$('gate-record').textContent=JSON.stringify({gate_row:r.y,nand_input_wire_ids:r.nand,output_wire:r.output_wire,recorded_output_bit:r.output_bit,compressed_row:r.compressed_row},null,2);renderWindow();}
function renderWindow(){let r=data.groups[groupIndex].samples[rowIndex],w=r?.windows[windowIndex];if(!w)return;$('tiles').innerHTML=tilesSVG(w.cells);wireTiles('tiles',w.cells);$('sample-caption').textContent=`Display sample only: gate row ${r.y}, columns ${w.start}…${w.end-1}. Each square comes from its stored active ID or stored CROSS interval. The full literal checker remains ${data.checks.literal.status}.`;$('tile-info').textContent='Select a sampled square to inspect its full edge colors and compressed-record origin.';}
function renderTop(){let windows=data.lines[lineIndex].top_windows,w=windows[Number($('top-windows').value)||0];if(!w)return;$('top-tiles').innerHTML=tilesSVG(w.cells);wireTiles('top-tiles',w.cells);}
function tilesSVG(cells){let op={CROSS:'#8797a5',READ:'#2b8ba7',NAND:'#d89937',NOT:'#b2607c',WRITE:'#6b78b8'},bit=['#273d58','#f0cd66'],parts=[`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${cells.length*102+12} 132" role="img" aria-label="Actual fixed orientation Wang ribbon samples">`];cells.forEach((c,i)=>{let t=data.palette.tiles.find(t=>t.id===c.tile_id),x=6+i*102,y=6;parts.push(`<g class="tile" tabindex="0" role="button" data-tile="${i}"><title>${esc(JSON.stringify({sample:c,tile:t}))}</title><rect x="${x}" y="${y}" width="96" height="96" fill="white" stroke="#8ca3b5"/><rect x="${x}" y="${y}" width="96" height="8" fill="${op[t.N[0]]}"/><rect x="${x}" y="${y+8}" width="96" height="6" fill="${bit[t.N[1]]}"/><rect x="${x}" y="${y+88}" width="96" height="8" fill="${op[t.S[0]]}"/><rect x="${x}" y="${y+82}" width="96" height="6" fill="${bit[t.S[1]]}"/><rect x="${x}" y="${y+14}" width="7" height="68" fill="${bit[t.W]}"/><rect x="${x+89}" y="${y+14}" width="7" height="68" fill="${bit[t.E]}"/><text x="${x+14}" y="${y+32}" font-size="10" fill="#263d55">${t.N[0]}</text><text x="${x+14}" y="${y+49}" font-size="12" fill="#263d55">type ${t.id}</text><circle cx="${x+48}" cy="${y+61}" r="4" fill="#176da1"/><text x="${x+14}" y="${y+77}" font-size="9" fill="#526477">center unit1</text><text x="${x+5}" y="${y+113}" font-size="9" fill="#526477">column ${c.x}</text></g>`);});parts.push('</svg>');return parts.join('');}
function wireTiles(id,cells){$(id).querySelectorAll('[data-tile]').forEach(n=>{let inspect=()=>{let c=cells[Number(n.dataset.tile)],t=data.palette.tiles.find(t=>t.id===c.tile_id);$('tile-info').textContent=JSON.stringify({sample:c,N:t.N,S:t.S,W:t.W,E:t.E,orientation:'fixed; translations only'},null,2);};n.addEventListener('click',inspect);n.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' ')inspect();});});}
function renderDepth(){let depth=data.depth;$('depth-status').innerHTML=badge(depth.status);if(depth.status!=='ADMITTED'){$('depth-data').innerHTML='<p class="note">Deeper symbolic incidence searches are pending review. No result or geometry proof is inferred from work still in progress.</p>';return;}let records=depth.records||[];let coverage=depth.recorded_result?.coverage||{},comparisons=coverage.matched_MARKS_IFILTER_comparisons||[];let matched=comparisons.length>0&&comparisons.every(c=>c.exact_event_dicts_equal&&c.actual_native_proof_asts_equal);$("depth-status").innerHTML+=`<p class="note">Four fresh cases cover two symbol renamings at address heights five and six. Markings and the matched ordinary filter found checked proofs in all four cases each; unfiltered BASE searches remain resource UNKNOWN. The point proofs have 23 or 27 lines; the conventional memoized control found 11-line proofs. ${matched?"All four completed markings/filter pairs have identical full event records and actual proof ASTs.":"Inspect the saved comparison receipts for the exact scope."} These are repeated searches of one incidence corollary. No newly trained RL or distinctive GCTS advantage has been demonstrated.</p><p class="note">The complete candidate universes are represented by independently checked schemas: 50,258 rows at height five and 101,714 at height six. Descriptor hashes bind those schemas; they are not hashes of expanded row lists.</p>`;if(!records.length){$('depth-data').innerHTML='<p class="note">The admitted dataset contains no proof-reader records.</p>';return;}let first=records.findIndex(r=>r.kind!=='DP'&&r.recorded_status==='SAT'&&r.native_status==='VERIFIED'&&r.proof_reader?.length);if(first<0)first=records.findIndex(r=>r.kind==='DP'&&r.recorded_status==='DERIVABLE'&&r.native_status==='VERIFIED'&&r.proof_reader?.length);if(first<0)first=0;
 $('depth-data').innerHTML=table(['Case','Method','Bound as recorded','Outcome','Native check'],records.map(r=>`<tr><td><code>${esc(r.case_id??r.id)}</code></td><td>${esc(r.kind==='DP'?'Conventional memoized DP':r.mode??r.kind??'Point search')}</td><td><code>${esc(show(r.recorded_bound))}</code></td><td>${badge(r.recorded_status)}</td><td>${badge(r.native_status)}</td></tr>`))+`<div class="toolbar"><label>Recorded incidence case / method<select id="depth-case">${records.map((r,i)=>`<option value="${i}">${esc(r.id+(r.mode?' · '+r.mode:''))}</option>`).join('')}</select></label></div><div id="depth-selected"></div><div id="depth-proof-table"></div>`;
 let choose=index=>{let r=records[index],theory=r.theory_reader,proved=(r.recorded_status==='SAT'||r.kind==='DP'&&r.recorded_status==='DERIVABLE')&&r.native_status==='VERIFIED'&&r.proof_reader?.length;let title=r.kind==='DP'?'Conventional memoized derivation':'Point-search derivation';$('depth-selected').innerHTML=`<h3>${esc(r.id)}</h3><p>${esc(r.kind==='DP'?'Conventional memoized DP control':r.mode??r.kind??'Point search')} · bound <code>${esc(show(r.recorded_bound))}</code> · ${badge(r.recorded_status)}</p>`+(theory?`<p class="note">${esc(show(theory.scope))}</p>${table(['Hypothesis','Formula','English'],(theory.hypotheses||[]).map(h=>`<tr><td><code>${esc(h.name)}</code></td><td><div class="formula-scroll">${formula(h)}</div></td><td>${esc(show(h.english))}</td></tr>`))}<h3>Recorded target</h3><div class="formula-scroll">${formula(theory.conclusion)}</div><p>${esc(show(theory.conclusion?.english))}</p>`:'');$('depth-proof-table').innerHTML=proved?`<h3>${title}</h3>`+table(['Line','Formula','English','Rule / dependencies'],r.proof_reader.map(p=>`<tr><td>${esc(p.line)}</td><td class="formula"><div class="formula-scroll">${formula(p)}</div></td><td>${esc(show(p.english))}</td><td><code>${esc(show(p.rule))}</code><br>${esc(show(p.dependencies))}<br>${esc(show(p.reason))}</td></tr>`)):'<p class="note">No independently checked proof is supplied for this recorded outcome. An unknown or bounded failed search is not a geometry proof.</p>';typeset($('depth-data'));};$('depth-case').value=first;$('depth-case').addEventListener('change',()=>choose(Number($('depth-case').value)));choose(first);}
async function init(){try{let response=await fetch('backend-join-results-v1.json.gz');if(!response.ok)throw Error('Reader data HTTP '+response.status);let bytes=new Uint8Array(await response.arrayBuffer()),text;if(bytes[0]===31&&bytes[1]===139){if(typeof DecompressionStream==='undefined')throw Error('Gzip browser decompression is unavailable');text=await new Response(new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'))).text();}else text=new TextDecoder().decode(bytes);data=JSON.parse(text);
 $('status').innerHTML=badge(data.status);$('metrics').innerHTML=[['Original proof lines',data.lines.length],['NAND computation rows',data.metrics.compile.gates],['Nominal grid cells',data.metrics.compile.nominal_grid_cells],['Literal arithmetic check',data.checks.literal.status]].map(([a,b])=>`<div class="metric"><span class="note">${esc(a)}</span><strong>${esc(typeof b==='number'?b.toLocaleString():b)}</strong></div>`).join('');
 let th=data.theory_reader;$('statement').innerHTML=table(['Declared hypothesis','Formula','English'],(th.hypotheses||[]).map(h=>`<tr><td><code>${esc(h.name)}</code></td><td class="formula"><div class="formula-scroll">${formula(h)}</div></td><td>${esc(h.english)}</td></tr>`))+`<h3>Same original conclusion</h3><div class="formula-scroll">${formula(th.conclusion)}</div><p>${esc(th.conclusion.english)}</p><p class="note">${esc(th.scope)}</p>`;
 $('checks').innerHTML=table(['Independent check','Recorded status','Reason'],Object.entries(data.checks).map(([name,r])=>`<tr><td>${esc(name)}</td><td>${badge(r.status)}</td><td>${esc(show(r.reason))}</td></tr>`));$('binding').innerHTML=pairs(data.binding);$('costs').innerHTML=pairs(data.metrics);$('assessment').innerHTML='<p>The original searched arithmetic proof round-trips to the same statement and proof. Independent logical kernels and the compressed tile certificate pass. Literal full-grid verification remains UNKNOWN.</p><details><summary>Exact saved-data assessment</summary>'+pairs(data.saved_data_summary)+'</details>';$('qualification').innerHTML='<p>The tiny case checks all 1,024 free proof-field assignments: 16 accepted assignments agree between the raw kernel and NAND circuit. Its 14,300-cell literal grid is checked. Four codec mutations and an altered tile are rejected; an intentionally limited decoder remains UNKNOWN.</p><details><summary>Qualification records</summary>'+pairs(data.qualification)+'</details>';renderDepth();
 $('downloads').innerHTML=table(['Exact saved artifact','Download','Bytes','SHA256'],data.downloads.map(d=>`<tr><td><code>${esc(d.original)}</code></td><td><a href="${esc(d.download)}" download>Saved file</a></td><td>${d.bytes}</td><td><code>${d.sha256}</code></td></tr>`));
 $('line').innerHTML=data.lines.map((l,i)=>`<option value="${i}">Proof line ${i+1} · ${esc(l.reader.rule)}</option>`).join('');$('group').innerHTML=data.groups.map((g,i)=>`<option value="${i}">${esc(g.label)}</option>`).join('');$('line').addEventListener('change',()=>selectLine(Number($('line').value)));$('group').addEventListener('change',()=>{groupIndex=Number($('group').value);rowIndex=windowIndex=0;renderGroup();});$('row').addEventListener('change',()=>{rowIndex=Number($('row').value);windowIndex=0;renderRow();});$('window').addEventListener('change',()=>{windowIndex=Number($('window').value);renderWindow();});$('top-windows').addEventListener('change',renderTop);selectLine(0);typeset();
 }catch(e){$('status').innerHTML=`<div class="error">${esc(e.message)}. No demonstration data have been substituted.</div>`;}}
init();
'''


MAIN = r'''
<header><div class="eyebrow">GCTS · Audited proof to fixed-palette backend</div><h1>One discovered proof, across the encoding</h1><p class="lede">The previously searched arithmetic proof is retained line for line, encoded as raw first-order records, independently decoded back, and represented by a checked compressed certificate over the same fixed Wang palette.</p><div id="status">Loading admitted saved data…</div><p class="note">This backend run certifies an existing searched proof. It does not perform new proof discovery, primitive Wang proof search or RL training.</p><div class="links"><a href="backend-join-evidence-v1.html">Evidence</a><a href="family-transfer-v1.html">Original proof-search study</a><a href="#proof-reader">Read the proof and encoding</a></div><p><!-- BACKEND_ARCHIVE_LINK --></p></header>
<main><section class="card"><div id="metrics" class="grid"></div></section><section class="card scope"><h2>The crucial distinction</h2><p>A mathematical proof line is decoded from a record in the top input, together with the original signature, hypotheses and goal. A Wang row here represents one NAND gate in the proof <em>checker</em>. One proof record requires many gate checks, and shared syntax, substitution and acceptance checks span additional bands. There is no natural one-row-to-one-inference identification.</p><div class="chain"><span>Audited point-search output</span><span>Raw proof records</span><span>NAND checker computation</span><span>Compressed fixed100 Wang expansion</span></div><p>The nominal grid size counts an implied finite expansion. It is not the number of tiles searched or literally checked. The compressed arithmetic certificate is verified; its full literal expansion remains unknown, with zero expanded cells in that check. Display samples below do not change this status.</p><p class="note">This closes a concrete backend/common-statement interface for one addition-zero corollary, without induction. It does not establish a distinctive GCTS advantage, a new RL contribution, practical universal Wang proof search or a whole-plane theorem.</p></section>
<section class="card"><h2>Original statement</h2><div id="statement"></div></section>
<section id="proof-reader" class="card"><h2>Proof line, encoded record and checker band</h2><div class="toolbar"><label>Mathematical proof line<select id="line"></select></label><label>Compiler gate band<select id="group"></select></label></div><div id="selected-formula"></div><div id="proof-table"></div><div class="split"><div><h3>Actual raw record and inverse-decoded line</h3><pre id="raw-record"></pre></div><div><h3>Top boundary record bits</h3><div id="fields"></div><p class="note">Bit words are shown least significant first. Raw references use zero-based record indices; the human reader numbers proof lines from one. Unused raw fields are retained, not silently removed.</p></div></div><h3>Actual top-row transport of these input columns</h3><div class="toolbar"><label>Input-column sample<select id="top-windows"></select></label></div><div id="top-tiles" class="scroll"></div><p class="note">These are sampled row-zero tiles carrying the encoded input. The input record is not an inference made by a single tile.</p><h3>Compiler intervals</h3><div id="bands" class="bands"></div><div id="association"></div><p id="gate-range" class="note"></p><p class="note">Bands show newly emitted gates, not independent subproofs or a complete partition of all dependencies. Hash-consed wires can refer to earlier bands.</p>
<div class="toolbar"><label>Sampled NAND row<select id="row"></select></label><label>Sampled columns<select id="window"></select></label></div><div id="tiles" class="scroll"></div><p id="sample-caption" class="note"></p><p>North and south colors have an operation stripe and a bit stripe; west/east colors are bits. The vertical color is \((\mathrm{OP},b)\). Tiles keep their fixed orientation and are placed by translation.</p><div class="split"><div><h3>Stored gate and compressed row</h3><pre id="gate-record"></pre></div><div><h3>Selected sample square</h3><pre id="tile-info">Select a sampled square.</pre></div></div></section>
<section class="card"><h2>Checks and common statement</h2><div id="checks"></div><details><summary>Bindings and round-trip data</summary><div id="binding"></div></details></section><section class="card"><h2>Qualification and interface controls</h2><p class="note">The controls test different interfaces. A damaged raw substitution map can leave the separately named native proof valid. An extra proof-dependent known pin can preserve raw validity and circuit acceptance while violating the frozen problem definition, which the codec rejects. A rejected interface does not automatically make the original named proof invalid.</p><div id="qualification"></div></section><section class="card"><h2>Measured stage costs and scale</h2><div id="costs"></div></section><section class="card"><h2>Saved-data assessment</h2><div id="assessment"></div></section><section class="card" id="incidence-reader"><h2>Deeper symbolic incidence search</h2><div id="depth-status"></div><div id="depth-data"></div><p class="note">These are bounded symbolic incidence searches, with any conventional control identified separately. No coordinates or additional geometric assumptions are supplied by the English interpretation.</p></section><section class="card"><h2>Exact downloads</h2><div id="downloads"></div></section></main><footer>Passive reader projection only. It imports no scientific modules, invokes no checker/evaluator/search, and does not relabel selected ribbon samples as full literal verification.</footer>
'''


OPS = ('CROSS', 'READ', 'NAND', 'NOT', 'WRITE')


def canonical(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       separators=(',', ':'), allow_nan=False)+'\n').encode('ascii')


def pin(raw):
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def is_ref(value):
    return isinstance(value, dict) and {'path', 'bytes', 'sha256'} <= set(value)


def read_ref(root, reference):
    if not is_ref(reference):
        raise ValueError('Pinned saved artifact reference required.')
    path = (root/reference['path']).resolve()
    if root != path and root not in path.parents:
        raise ValueError('Saved reference leaves the run root.')
    raw = path.read_bytes()
    if pin(raw) != {key: reference[key] for key in ('bytes', 'sha256')}:
        raise ValueError('Saved reference byte/hash differs: '+reference['path'])
    return path, raw


def decode_ref(root, reference):
    path, raw = read_ref(root, reference)
    return json.loads(gzip.decompress(raw) if path.suffix == '.gz' else raw)


def admitted_depth(root, reference):
    """Resolve display records only after Root's explicit addon admission."""
    payload = decode_ref(root, reference)
    path = (root/reference['path']).resolve()
    containing_run = next((parent.parent for parent in path.parents if parent.name == 'data'), root)
    supplied = payload.get('records', payload.get('families', [])) if isinstance(payload, dict) else []
    if not isinstance(supplied, list):
        raise ValueError('Admitted incidence reader records must be an array.')
    records = []
    for record in supplied:
        item = dict(record)
        item.setdefault('kind', 'DP' if item.get('mode') in ('DP', 'DP_CONTROL') else 'FAMILY')
        result = item.get('result')
        item['recorded_status'] = result.get('status') if isinstance(result, dict) else result
        item['recorded_bound'] = item.get('depth', item.get('height', item.get('bound', item.get('bounds'))))
        receipt = item.get('native_check')
        if is_ref(receipt):
            errors = []
            for base in dict.fromkeys((root, containing_run)):
                try:
                    receipt = decode_ref(base, item['native_check'])
                    break
                except (OSError, ValueError) as error:
                    errors.append(str(error))
            else:
                raise ValueError('Admitted incidence native receipt cannot be resolved: '+repr(errors))
        item['native_status'] = receipt.get('status') if isinstance(receipt, dict) else item.get('native_status', item.get('native_check_status'))
        records.append(item)
    return dict(status='ADMITTED', reference=reference, records=records,
                recorded_result=payload,
                scope='Saved deeper incidence records admitted by Root; native receipts read passively, no solver or checker invoked by the reader.')


def references(value):
    if is_ref(value):
        yield value
    elif isinstance(value, dict):
        for child in value.values():
            yield from references(child)
    elif isinstance(value, list):
        for child in value:
            yield from references(child)


def role(circuit, x, y):
    if y == len(circuit['gates']):
        return 'CROSS'
    a, b = circuit['gates'][y]
    if x == len(circuit['inputs'])+y:
        return 'WRITE'
    if a == b:
        return 'NOT' if x == a else 'CROSS'
    return 'READ' if x == min(a, b) else 'NAND' if x == max(a, b) else 'CROSS'


def sample_cell(circuit, encoded, ribbon_packet, palette, x, y):
    """Project one actual compressed-record cell; no circuit is evaluated."""
    cert, gates = ribbon_packet['ribbon'], ribbon_packet['gate_bits']
    row = cert['rows'][y]
    active = [tile_id for column, tile_id in row['active'] if column == x]
    interval = [r for r in row['ribbons'] if r[0] <= x < r[1]]
    if len(active)+len(interval) != 1:
        raise ValueError('Sample cell has missing or ambiguous compressed coverage.')
    count = len(encoded['input_bits'])
    north = encoded['input_bits'][x] if x < count else gates[x-count] if x-count < y else 0
    if active:
        tile_id, origin = active[0], 'stored active tile ID'
    else:
        bus = interval[0][2]
        tile_id = 5*(2*north+bus)+OPS.index(role(circuit, x, y+1))
        origin = 'stored CROSS transport interval'
    tile = palette['tiles'][tile_id]
    if tile['id'] != tile_id or tile['N'] != [role(circuit, x, y), north]:
        raise ValueError('Sample and stored palette north color disagree.')
    return dict(x=x, y=y, tile_id=tile_id, origin=origin,
                interval=interval[0] if interval else None)


def window(circuit, encoded, ribbon_packet, palette, start, y, label):
    width = len(circuit['inputs'])+len(circuit['gates'])
    start = max(0, min(start, max(0, width-12)))
    end = min(width, start+12)
    return dict(label=label, start=start, end=end,
        cells=[sample_cell(circuit, encoded, ribbon_packet, palette, x, y) for x in range(start, end)])


def page(title, body, script=''):
    return ('<!doctype html><html lang="en"><head><meta charset="utf-8">'
        '<meta name="viewport" content="width=device-width, initial-scale=1"><title>'+html.escape(title)+
        '</title><style>'+STYLE+'</style>'+
        r'<script>window.MathJax={tex:{inlineMath:[["\\(","\\)"]],displayMath:[["\\[","\\]"]]},options:{skipHtmlTags:["script","noscript","style","textarea","pre","code"]}};</script>'+
        '<script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js"></script></head><body>'+
        body+('<script>'+script+'</script>' if script else '')+'</body></html>')


def build(root):
    root = root.resolve()
    admitted_path = root/'data/report-summary-v1.json'
    admitted_bytes = admitted_path.read_bytes()
    admitted = json.loads(admitted_bytes)
    actual = json.loads((root/'data/arithmetic-results-v1.json').read_bytes())
    qualification = json.loads((root/'data/qualification-results-v1.json').read_bytes())
    record, refs = actual['record'], actual['record']['artifacts']
    prepared = decode_ref(root, refs['prepare'])
    backend = decode_ref(root, refs['compile'])
    encoded = decode_ref(root, refs['encode'])
    inverse = decode_ref(root, refs['inverse'])
    ribbon_packet = decode_ref(root, refs['ribbon'])
    checks = {key: decode_ref(root, refs[key]) for key in ('binding', 'raw', 'inverse', 'native', 'symbolic', 'literal')}
    circuit, palette = backend['circuit'], backend['palette']
    if len(actual['original_proof_reader']) != len(encoded['raw_certificate']['proof']):
        raise ValueError('Saved proof reader and raw record counts differ.')
    groups = []
    for group in backend['metadata']['groups']:
        item = dict(group)
        if item['end'] > item['start']:
            rows = sorted({item['start'], (item['start']+item['end']-1)//2, item['end']-1})
        else:
            rows = []
        item['samples'] = []
        for y in rows:
            row = ribbon_packet['ribbon']['rows'][y]
            a, b = circuit['gates'][y]
            starts = [('First NAND source', max(0, min(a, b)-2)),
                      ('Second NAND source', max(0, max(a, b)-2)),
                      ('Output column', max(0, len(circuit['inputs'])+y-5))]
            windows, used = [], set()
            for label, start in starts:
                view = window(circuit, encoded, ribbon_packet, palette, start, y, label)
                if view['start'] not in used:
                    used.add(view['start'])
                    windows.append(view)
            position = 'band start' if y == item['start'] else 'band end minus one' if y == item['end']-1 else 'band midpoint'
            item['samples'].append(dict(y=y, position=position, nand=[a, b],
                output_wire=len(circuit['inputs'])+y, output_bit=ribbon_packet['gate_bits'][y],
                compressed_row=row, windows=windows))
        groups.append(item)
    lines = []
    for i, reader in enumerate(actual['original_proof_reader']):
        fields = []
        for field in ('rule', 'formula', 'ref0', 'ref1', 'aux0', 'aux1'):
            prefix = 'line.%d.%s.' % (i, field)
            entries = sorted((int(item['name'][len(prefix):]), j) for j, item in enumerate(circuit['inputs'])
                             if item['name'].startswith(prefix))
            bits = [encoded['input_bits'][j] for bit, j in entries]
            value = sum(bit << k for k, bit in enumerate(bits))
            if value != encoded['raw_certificate']['proof'][i][field]:
                raise ValueError('Saved input-word sample differs from raw proof field.')
            fields.append(dict(field=field, value=value, bits_lsb=bits,
                               input_columns=[j for bit, j in entries]))
        columns = [j for field in fields for j in field['input_columns']]
        top = [window(circuit, encoded, ribbon_packet, palette, start, 0, 'Proof-record top input')
               for start in range(min(columns), max(columns)+1, 12)]
        raw = encoded['raw_certificate']['proof'][i]
        lines.append(dict(reader=reader, native_exact=prepared['proof'][i], raw_record=raw,
            raw_rule_name=backend['metadata']['rule_names'][raw['rule']],
            decoded_line=inverse['human']['proof'][i],
            raw_formula_ast=inverse['human']['node_asts'][raw['formula']],
            input_fields=fields, top_windows=top))
    out, download_dir = root/'report', root/'report/backend-downloads-v1'
    download_dir.mkdir(parents=True, exist_ok=True)
    downloads, copied = [], {}
    for reference in list(references(actual))+list(references(qualification)):
        if not str(reference['path']).startswith(('data/', 'input/')):
            continue
        path, raw = read_ref(root, reference)
        key = (reference['bytes'], reference['sha256'])
        if key not in copied:
            name = reference['sha256'][:16]+'-'+path.name
            (download_dir/name).write_bytes(raw)
            copied[key] = 'backend-downloads-v1/'+name
            downloads.append(dict(original=reference['path'], download=copied[key], **pin(raw)))
    depth = dict(status='PENDING', scope='No independently admitted depth addon was supplied. No result inferred from companion work.')
    addon_path = root/'data/report-addons-v1.json'
    if addon_path.exists():
        addon = json.loads(addon_path.read_bytes())
        if addon.get('status') == 'ADMITTED' and is_ref(addon.get('depth')):
            depth = admitted_depth(root, addon['depth'])
    view = dict(schema='Passive-proof-backend-reader-v1', status=actual['status'],
        saved_data_summary=admitted, input_summary_pin=pin(admitted_bytes),
        theory_reader=actual['original_theory_reader'], lines=lines, groups=groups, palette=palette,
        checks=checks, metrics=dict(record['metrics'], pipeline_seconds=record['pipeline_seconds']),
        binding=dict(original_statement_sha256=prepared['original_statement_sha256'],
            normalized_statement_sha256=prepared['normalized_statement_sha256'],
            original_proof_sha256=prepared['original_proof_sha256'], normalization=prepared['normalization'],
            raw_bit_roundtrip=inverse['raw_bit_roundtrip'], common_statement=checks['binding'],
            provenance=actual['provenance']),
        qualification=qualification, depth=depth, downloads=downloads,
        reader_projection=dict(scope='Deterministic selected-band/row/column samples of saved compressed data. No scientific modules imported, NAND evaluated, proof searched or whole grid expanded.',
            sample_rows=sum(len(g['samples']) for g in groups),
            warning='Viewer samples are not added to literal checker expanded_cells or presented as an independently checked literal grid.'))
    compressed = gzip.compress(canonical(view), compresslevel=6, mtime=0)
    (out/'backend-join-results-v1.json.gz').write_bytes(compressed)
    (out/'backend-join-v1.html').write_text(page('GCTS proof to raw kernel to Wang backend', MAIN, SCRIPT))
    rows = ''.join('<tr><td><code>'+html.escape(d['original'])+'</code></td><td><a download href="'+
        html.escape(d['download'], quote=True)+'">Exact saved artifact</a></td><td>'+str(d['bytes'])+
        '</td><td><code>'+d['sha256']+'</code></td></tr>' for d in downloads)
    evidence = ('<header><div class="eyebrow">GCTS · Backend evidence</div><h1>Exact proof and encoding artifacts</h1>'
        '<p class="lede">The original point-search output, raw records, circuit, inverse decode and compressed ribbon are retained separately.</p>'
        '<div class="links"><a href="backend-join-v1.html">Open the linked reader</a><a download href="backend-join-results-v1.json.gz">Compressed reader projection</a></div>'
        '<p><!-- BACKEND_ARCHIVE_LINK --></p></header><main><section class="card scope"><h2>What is and is not expanded</h2>'
        '<p>The arithmetic ribbon has a checked symbolic expansion. Its full literal check is unknown with zero expanded cells. The colored squares in the reader are deterministic display samples of that stored expansion, not a newly searched Wang proof or a full literal verification.</p>'
        '<p>The one-line reflexivity qualification and its fully checked tiny grid are separate from the unchanged twelve-line searched arithmetic proof. No shorter control proof replaces the research witness.</p></section>'
        '<section class="card"><div class="scroll"><table><thead><tr><th>Original path</th><th>Download</th><th>Bytes</th><th>SHA256</th></tr></thead><tbody>'+rows+
        '</tbody></table></div></section><section class="card"><h2>Admitted summary pin</h2><pre>'+html.escape(json.dumps(pin(admitted_bytes), indent=2))+
        '</pre></section></main><footer>No encoder, compiler, evaluator or checker runs in this reader.</footer>')
    (out/'backend-join-evidence-v1.html').write_text(page('GCTS backend exact evidence', evidence))
    return dict(status='PASSIVE_BACKEND_REPORT_BUILT', proof_lines=len(lines),
                sample_rows=sum(len(g['samples']) for g in groups), downloads=len(downloads),
                reader_pin=pin(compressed))


if __name__ == '__main__':
    if len(sys.argv) > 2:
        raise SystemExit('Usage: python3 report/build_backend_report_v1.py [RUN]')
    root = Path(sys.argv[1]) if len(sys.argv) == 2 else Path(__file__).resolve().parents[1]
    print(json.dumps(build(root)), flush=True)
