"""Same raw Hilbert kernel, materializing only consumed lookup fields.

The logical predicates/bounds are inherited unchanged. Each requested field
uses the same finite mux as v1; unused outputs no longer create dead NAND gates.
For a full power-of-two table every in-width index is present, so found=1.
"""
from raw_kernel_circuit_v1 import Compiler as EagerCompiler, ResourceLimit, CAPS, GATE_CAP, RULES


class Arguments:
    def __init__(self,view):self.view=view
    def __getitem__(self,k):
        if not 0<=k<self.view.compiler.bounds['arity']:raise IndexError(k)
        return self.view.field('arg'+str(k),[n['args'][k] for n in self.view.compiler.nodes],self.view.compiler.w['node'])
    def __iter__(self):
        return (self[k] for k in range(self.view.compiler.bounds['arity']))


class Node:
    def __init__(self,compiler,word):
        self.compiler=compiler;self.word=list(word);self.cache={'id':self.word,'args':Arguments(self)}
    def field(self,name,rows,width):
        if name not in self.cache:self.cache[name]=self.compiler.lookup(rows,self.word,width)[0]
        return self.cache[name]
    def __getitem__(self,name):
        if name in self.cache:return self.cache[name]
        c=self.compiler
        if name=='found':
            count=c.bounds['nodes'];value=1 if count==1<<len(self.word) else c.b.any(c.selectors(self.word,count))
        elif name in ('tag','head','fv'):
            width={'tag':4,'head':c.w['head'],'fv':c.bounds['variables']}[name]
            value=self.field(name,[n[name] for n in c.nodes],width)
        elif name in ('is_term','is_formula'):
            value=self.field(name,[[n[name]] for n in c.nodes],1)[0]
        else:raise KeyError(name)
        self.cache[name]=value;return value


class Compiler(EagerCompiler):
    def lookup(self,rows,word,width):
        normalized=[self.b.resolve(x) for x in word]
        if all(x in (0,1) for x in normalized):
            i=sum(v<<k for k,v in enumerate(normalized))
            return (list(rows[i]),1) if i<len(rows) else ([0]*width,0)
        selected=self.selectors(normalized,len(rows))
        found=1 if len(rows)==1<<len(normalized) else self.b.any(selected)
        return [self.b.any([self.b.AND(s,row[k]) for s,row in zip(selected,rows)]) for k in range(width)],found

    def node(self,word):
        key=tuple(self.b.resolve(v) for v in word)
        if key not in self.node_cache:self.node_cache[key]=Node(self,word)
        return self.node_cache[key]

    def compile(self):
        circuit,metadata=super().compile()
        metadata['optimization']='Lazy materialization of lookup fields; full power-of-two table membership. Same logical predicates, bounds, proof inputs and problem pins as v1.'
        metadata['schema']='NK-raw-kernel-circuit-metadata-v2'
        return circuit,metadata


def compile_kernel(bounds,pins):return Compiler(bounds,pins).compile()
