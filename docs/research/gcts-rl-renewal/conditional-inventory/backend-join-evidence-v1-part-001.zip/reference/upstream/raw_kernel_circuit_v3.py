"""Resource extension only: identical lazy kernel, two-million NAND ceiling."""
from raw_kernel_circuit_v1 import Builder as BaseBuilder, ResourceLimit, CAPS, RULES
from raw_kernel_circuit_v2 import Compiler as LazyCompiler

GATE_CAP=2000000


class Builder(BaseBuilder):
    def raw(self,a,b):
        key=tuple(sorted((a,b)))
        if key not in self.cache:
            if len(self.gates)>=GATE_CAP:raise ResourceLimit('NAND_GATE_CAP_2M')
            self.cache[key]=len(self.inputs)+len(self.gates)
            self.gates.append(list(key))
        return self.cache[key]


class Compiler(LazyCompiler):
    def __init__(self,bounds,pins):
        super().__init__(bounds,pins)
        # Base construction has allocated inputs only; no gate or selector yet.
        assert not self.b.gates and not self.select_cache and not self.node_cache
        self.b=Builder(self.inputs)
    def compile(self):
        circuit,meta=super().compile()
        meta.update(schema='NK-raw-kernel-circuit-metadata-v3',gate_cap=GATE_CAP,
                    resource_change='Only construction ceiling raised from1M to2M; logical bounds, pins, rules, lookup optimization and acceptance predicate unchanged.')
        return circuit,meta


def compile_kernel(bounds,pins):return Compiler(bounds,pins).compile()
