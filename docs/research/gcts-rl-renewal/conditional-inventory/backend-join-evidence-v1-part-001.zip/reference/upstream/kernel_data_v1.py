"""NK-v1 human-AST data encoder. No proof search, admission or validity checker.

Problem syntax/signatures are frozen first. Proofs merely supply raw fields;
reference order, rule instances, closed Gamma and the goal require the separate
kernel/circuit. Substitution traversal constructs the required witness maps.
No compiler, evaluator, procedural checker or other scientific module imports.
"""
import copy
import json

VERSION = 'NK-data-encoder-v1'
BOUND_KEYS = ('nodes', 'variables', 'functions', 'predicates', 'axioms',
              'lines', 'substitutions', 'arity')
TAGS = {'var': 1, 'fun': 2, 'pred': 3, 'eq': 4, 'not': 5,
        'imp': 6, 'all': 7, 'bot': 10}
RULES = {'axiom': 0, 'mp': 1, 'generalize': 2, 'instantiate': 3,
         'refl': 4, 'distribute': 5, 'eq_subst': 6,
         'ax1': 7, 'ax2': 8, 'ax3': 9, 'bot_false': 10}


class EncodingError(ValueError):
    pass


def _need(ok, message):
    if not ok:
        raise EncodingError(message)


def _uint(value, label):
    _need(type(value) is int and value >= 0, label + ' must be a native nonnegative int')
    return value


def _bounds(bounds):
    _need(type(bounds) is dict and set(bounds) == set(BOUND_KEYS), 'Exact NK-v1 bounds fields required')
    b = {key: _uint(bounds[key], key) for key in BOUND_KEYS}
    _need(b['nodes'] >= 2 and b['variables'] >= 1 and b['lines'] >= 1
          and b['arity'] >= 2, 'Insufficient basic bounds')
    return b


def _widths(b):
    return dict(node=max(1, (b['nodes'] - 1).bit_length()),
                head=max(1, (max(b['variables'], b['functions'], b['predicates'], 1) - 1).bit_length()),
                arity=max(1, b['arity'].bit_length()),
                ref=max(1, (b['lines'] - 1).bit_length()),
                aux=max(1, (max(b['axioms'], b['substitutions'], 1) - 1).bit_length()))


def _key(ast):
    return json.dumps(ast, ensure_ascii=True, separators=(',', ':'))


def _name(value):
    _need(type(value) is str and bool(value), 'Expected nonempty symbol name')
    return value


def _signature(value, capacity, arity, label):
    _need(type(value) is dict and all(type(k) is str for k in value), label + ' signature must be a name/arity dict')
    names = sorted(value)
    _need(len(names) <= capacity, label + ' signature exceeds bound')
    values = []
    for name in names:
        _name(name)
        n = _uint(value[name], label + ' arity')
        _need(n <= arity, label + ' arity exceeds argument slots')
        values.append(n)
    return {name: i for i, name in enumerate(names)}, values + [0] * (capacity - len(values))


class _Pool:
    def __init__(self, bounds, maps, rows=None, asts=None):
        self.b, self.maps = bounds, maps
        self.rows = copy.deepcopy(rows) if rows is not None else [[0] * (2 + bounds['arity'])]
        self.asts = copy.deepcopy(asts) if asts is not None else [None]
        _need(len(self.rows) == len(self.asts), 'Prefix AST/row counts differ')
        self.ids = {_key(ast): i for i, ast in enumerate(self.asts) if i and ast is not None}
        self.fv = {}

    def norm(self, ast, kind=None):
        _need(type(ast) in (list, tuple) and bool(ast) and type(ast[0]) is str, 'Expected literal AST sequence')
        tag = ast[0]
        _need(tag in TAGS or tag in ('and', 'or'), 'Unsupported AST tag: ' + tag)
        actual_kind = 'term' if tag in ('var', 'fun') else 'formula'
        _need(kind is None or actual_kind == kind, 'AST sort mismatch')
        if tag == 'var':
            _need(len(ast) == 2 and _name(ast[1]) in self.maps['variable'], 'Variable outside declared pool')
            return ['var', ast[1]]
        if tag in ('fun', 'pred'):
            _need(len(ast) == 3 and type(ast[2]) in (list, tuple), 'Malformed symbol application')
            names = self.maps['function' if tag == 'fun' else 'predicate']
            _need(_name(ast[1]) in names, 'Symbol outside declared signature: ' + ast[1])
            arities = self.maps['function_arities' if tag == 'fun' else 'predicate_arities']
            _need(len(ast[2]) == arities[names[ast[1]]], 'Symbol argument count differs from signature')
            return [tag, ast[1], [self.norm(t, 'term') for t in ast[2]]]
        if tag in ('eq', 'imp', 'and', 'or'):
            _need(len(ast) == 3, 'Malformed binary AST')
            child_kind = 'term' if tag == 'eq' else 'formula'
            a, c = self.norm(ast[1], child_kind), self.norm(ast[2], child_kind)
            if tag == 'and':
                return ['not', ['imp', a, ['not', c]]]
            if tag == 'or':
                return ['imp', ['not', a], c]
            return [tag, a, c]
        if tag == 'all':
            _need(len(ast) == 3 and _name(ast[1]) in self.maps['variable'], 'Binder outside declared pool')
            return ['all', ast[1], self.norm(ast[2], 'formula')]
        if tag == 'not':
            _need(len(ast) == 2, 'Malformed negation')
            return ['not', self.norm(ast[1], 'formula')]
        _need(tag == 'bot' and len(ast) == 1, 'Malformed bottom')
        return ['bot']

    @staticmethod
    def children(ast):
        if ast[0] in ('fun', 'pred'):
            return ast[2]
        if ast[0] in ('eq', 'imp'):
            return ast[1:]
        if ast[0] == 'all':
            return [ast[2]]
        return [ast[1]] if ast[0] == 'not' else []

    def store(self, ast):
        key = _key(ast)
        if key in self.ids:
            return self.ids[key]
        children = [self.store(c) for c in self.children(ast)]
        _need(len(self.rows) < self.b['nodes'], 'Syntax node bound exceeded')
        tag, head = ast[0], 0
        if tag in ('var', 'all'):
            head = self.maps['variable'][ast[1]]
        elif tag in ('fun', 'pred'):
            head = self.maps['function' if tag == 'fun' else 'predicate'][ast[1]]
        row = [TAGS[tag], head] + children + [0] * (self.b['arity'] - len(children))
        index = len(self.rows)
        self.rows.append(row)
        self.asts.append(ast)
        self.ids[key] = index
        return index

    def add(self, ast, kind=None):
        return self.store(self.norm(ast, kind))

    def free(self, index):
        if index not in self.fv:
            ast, row = self.asts[index], self.rows[index]
            if ast[0] == 'var':
                value = {row[1]}
            else:
                count = len(self.children(ast))
                value = set().union(*(self.free(i) for i in row[2:2 + count]))
                if ast[0] == 'all':
                    value.discard(row[1])
            self.fv[index] = value
        return self.fv[index]

    def substitution(self, source, variable, term):
        """Construct structural maps, even if capture-invalid; no hygiene oracle."""
        changed = {}

        def visit(index):
            if index in changed:
                return changed[index]
            ast, row = self.asts[index], self.rows[index]
            if ast[0] == 'var':
                target = term if row[1] == variable else index
            elif ast[0] == 'all' and row[1] == variable:
                target = index
            else:
                count = len(self.children(ast))
                mapped = [self.asts[visit(i)] for i in row[2:2 + count]]
                if ast[0] in ('fun', 'pred'):
                    result = [ast[0], ast[1], mapped]
                elif ast[0] in ('eq', 'imp'):
                    result = [ast[0]] + mapped
                elif ast[0] == 'all':
                    result = ['all', ast[1], mapped[0]]
                elif ast[0] == 'not':
                    result = ['not', mapped[0]]
                else:
                    result = ['bot']
                target = self.store(result)
            changed[index] = target
            return target

        result = visit(source)
        return result, changed


def _word(target, prefix, value, width):
    value = _uint(value, prefix)
    _need(value < (1 << width), prefix + ' exceeds flat word width')
    for bit in range(width):
        target[prefix + '.' + str(bit)] = (value >> bit) & 1


def _node_words(target, b, w, i, row):
    _need(type(row) is list and len(row) == 2 + b['arity'], 'Node row width differs')
    _word(target, 'node.%d.tag' % i, row[0], 4)
    _word(target, 'node.%d.head' % i, row[1], w['head'])
    for k, value in enumerate(row[2:]):
        _word(target, 'node.%d.arg.%d' % (i, k), value, w['node'])


def build_problem(bounds, theory, goal):
    """Return (partial_flat_pins, metadata). Freeze before witness generation.

    theory['variables'] is the ordered name pool, padded with unused names to V.
    Signatures/axiom names sort lexically. Spare signature slots are nullary;
    spare axiom slots duplicate the first axiom, never introduce an assumption.
    """
    b = _bounds(bounds)
    _need(type(theory) is dict, 'Theory must be a dict')
    declared = theory.get('variables')
    _need(type(declared) in (list, tuple), 'Explicit theory.variables list required')
    variables = list(declared)
    _need(len(variables) <= b['variables']
          and all(type(x) is str and x for x in variables)
          and len(set(variables)) == len(variables), 'Explicit unique theory.variables pool required')
    counter = 0
    while len(variables) < b['variables']:
        name = '__unused_variable_%d' % counter
        counter += 1
        if name not in variables:
            variables.append(name)
    functions, fa = _signature(theory['functions'], b['functions'], b['arity'], 'Function')
    predicates, pa = _signature(theory['predicates'], b['predicates'], b['arity'], 'Predicate')
    maps = dict(variable={v: i for i, v in enumerate(variables)}, function=functions,
                predicate=predicates, function_arities=fa, predicate_arities=pa)
    axioms = theory['axioms']
    _need(type(axioms) is dict and all(type(n) is str and n for n in axioms), 'Named axiom dict required')
    names = sorted(axioms)
    _need(len(names) <= b['axioms'], 'Axiom bound too small')
    _need(bool(names) or b['axioms'] == 0, 'Empty Gamma requires zero axiom slots')
    pool = _Pool(b, maps)
    axiom_ids = [pool.add(axioms[n], 'formula') for n in names]
    goal_id = pool.add(goal, 'formula')
    axiom_slots = axiom_ids + [axiom_ids[0]] * (b['axioms'] - len(axiom_ids)) if axiom_ids else []
    # Safe extra syntax, not extra axioms or preselected proof producers.
    var0 = pool.add(['var', variables[0]], 'term') if len(pool.rows) < b['nodes'] or _key(['var', variables[0]]) in pool.ids else None
    identity = next((i for i in axiom_ids if not pool.free(i)), None)
    if b['substitutions'] and identity is None:
        identity = pool.add(['not', ['bot']], 'formula')
    pins, w = {}, _widths(b)
    for label, values in [('function', fa), ('predicate', pa)]:
        for i, value in enumerate(values):
            _word(pins, '%s.%d.arity' % (label, i), value, w['arity'])
    for i, row in enumerate(pool.rows):
        _node_words(pins, b, w, i, row)
    for i, value in enumerate(axiom_slots):
        _word(pins, 'axiom.%d' % i, value, w['node'])
    _word(pins, 'goal', goal_id, w['node'])
    meta = dict(schema='NK-data-problem-metadata-v1', version=VERSION, bounds=b,
                theory=copy.deepcopy(theory), goal=copy.deepcopy(goal), variables=variables,
                maps=maps, axiom_names={n: i for i, n in enumerate(names)},
                axioms=axiom_slots, goal_id=goal_id, var0_id=var0,
                identity_source=identity, node_prefix=copy.deepcopy(pool.rows),
                prefix_asts=copy.deepcopy(pool.asts), pins=dict(pins),
                scope='Data encoding only. Problem prefix/signatures/axiom IDs/goal pinned; other syntax, proof lines and substitution words free. No producer catalogue or proof validity result.')
    return pins, meta


def _schema_rule(f):
    """Exact literal AX1/AX2/AX3/BOT_FALSE pattern encoding, no truth table."""
    imp = lambda a: type(a) is list and len(a) == 3 and a[0] == 'imp'
    neg = lambda a: type(a) is list and len(a) == 2 and a[0] == 'not'
    if f == ['not', ['bot']]:
        return 10
    if imp(f) and imp(f[2]) and f[1] == f[2][2]:
        return 7
    if imp(f) and imp(f[1]) and imp(f[1][2]) and imp(f[2]) and imp(f[2][1]) and imp(f[2][2]):
        a, bc = f[1][1], f[1][2]
        if f[2][1] == ['imp', a, bc[1]] and f[2][2] == ['imp', a, bc[2]]:
            return 8
    if imp(f) and imp(f[1]) and neg(f[1][1]) and neg(f[1][2]) and imp(f[2]):
        if f[2] == ['imp', f[1][2][1], f[1][1][1]]:
            return 9
    raise EncodingError('Tautology is not an exact AX1/AX2/AX3/BOT_FALSE instance; no general tautology oracle is used')


def build_witness(bounds, meta, proof):
    """Encode supplied lines and substitution maps; never check proof validity.

    Exactly L human lines are required; no proof padding is invented. References
    are copied as nonnegative integers without testing prior-line or rule facts.
    """
    b = _bounds(bounds)
    _need(meta['bounds'] == b, 'Witness bounds differ from frozen problem')
    lines = proof.get('lines') if type(proof) is dict else proof
    _need(type(lines) is list and len(lines) == b['lines'], 'Supply exactly bounds.lines proof rows')
    pool = _Pool(b, meta['maps'], meta['node_prefix'], meta['prefix_asts'])
    formula_ids = [pool.add(line['formula'], 'formula') for line in lines]
    tasks, task_ids = [], {}

    def task(source, variable, term):
        result, changed = pool.substitution(source, variable, term)
        key = (source, variable, term, result)
        if key not in task_ids:
            _need(len(tasks) < b['substitutions'], 'Distinct substitution task bound exceeded')
            task_ids[key] = len(tasks)
            tasks.append(dict(source=source, variable=variable, term=term,
                              result=result, changed=changed))
        return task_ids[key]

    native = []
    for line, fid in zip(lines, formula_ids):
        rule = line['rule']
        if rule == 'tautology':
            code = _schema_rule(pool.asts[fid])
        else:
            _need(type(rule) is str and rule.lower() in RULES, 'Unsupported human proof rule')
            code = RULES[rule.lower()]
        row = dict(rule=code, formula=fid, ref0=0, ref1=0, aux0=0, aux1=0)
        if code == 0:
            _need(line['name'] in meta['axiom_names'], 'Unknown named axiom')
            row['aux0'] = meta['axiom_names'][line['name']]
        elif code == 1:
            row['ref0'] = _uint(line['antecedent'], 'antecedent')
            row['ref1'] = _uint(line['implication'], 'implication')
        elif code == 2:
            row['ref0'] = _uint(line['source'], 'source reference')
        elif code == 3:
            universal = pool.norm(line['universal'], 'formula')
            _need(universal[0] == 'all', 'UI parameter must supply a universal AST')
            source = pool.add(universal[2], 'formula')
            variable = meta['maps']['variable'][universal[1]]
            term = pool.add(line['term'], 'term')
            row['aux0'] = task(source, variable, term)
        elif code == 6:
            source = pool.add(line['template'], 'formula')
            _need(line['variable'] in meta['maps']['variable'], 'Substitution variable outside pool')
            variable = meta['maps']['variable'][line['variable']]
            row['aux0'] = task(source, variable, pool.add(line['left'], 'term'))
            row['aux1'] = task(source, variable, pool.add(line['right'], 'term'))
        native.append(row)
    if len(tasks) < b['substitutions']:
        _need(meta['identity_source'] is not None, 'No frozen identity-task source')
        term = meta['var0_id']
        if term is None:
            term = pool.add(['var', meta['variables'][0]], 'term')
        source = meta['identity_source']
        result, changed = pool.substitution(source, 0, term)
        _need(result == source, 'Identity padding source is not independent of variable0')
        filler = dict(source=source, variable=0, term=term, result=result, changed=changed)
        while len(tasks) < b['substitutions']:
            tasks.append(copy.deepcopy(filler))
    # Unused VAR0 padding rows do not enter the semantic interning table.
    filler_row = [1, 0] + [0] * b['arity']
    nodes = copy.deepcopy(pool.rows) + [list(filler_row) for _ in range(b['nodes'] - len(pool.rows))]
    substitutions = []
    for original in tasks:
        active, mapping = [0] * b['nodes'], [0] * b['nodes']
        for source, result in original['changed'].items():
            active[source], mapping[source] = 1, result
        substitutions.append(dict(source=original['source'], variable=original['variable'],
                                  term=original['term'], result=original['result'],
                                  active=active, map=mapping))
    return dict(functions=list(meta['maps']['function_arities']),
                predicates=list(meta['maps']['predicate_arities']), nodes=nodes,
                axioms=list(meta['axioms']), goal=meta['goal_id'],
                proof=native, substitutions=substitutions)


def _flat(bounds, cert):
    b, flat = _bounds(bounds), {}
    w = _widths(b)
    expected = {'functions', 'predicates', 'nodes', 'axioms', 'goal', 'proof', 'substitutions'}
    _need(type(cert) is dict and set(cert) == expected, 'Exact native certificate fields required')
    for label, field, size in [('function', 'functions', b['functions']), ('predicate', 'predicates', b['predicates'])]:
        _need(len(cert[field]) == size, field + ' length differs')
        for i, value in enumerate(cert[field]):
            _word(flat, '%s.%d.arity' % (label, i), value, w['arity'])
    _need(len(cert['nodes']) == b['nodes'], 'Node count differs')
    for i, row in enumerate(cert['nodes']):
        _node_words(flat, b, w, i, row)
    _need(len(cert['axioms']) == b['axioms'], 'Axiom count differs')
    for i, value in enumerate(cert['axioms']):
        _word(flat, 'axiom.%d' % i, value, w['node'])
    _word(flat, 'goal', cert['goal'], w['node'])
    _need(len(cert['proof']) == b['lines'], 'Proof row count differs')
    fields = [('rule', 4), ('formula', w['node']), ('ref0', w['ref']),
              ('ref1', w['ref']), ('aux0', w['aux']), ('aux1', w['aux'])]
    for i, row in enumerate(cert['proof']):
        _need(set(row) == {name for name, _ in fields}, 'Exact proof row fields required')
        for name, width in fields:
            _word(flat, 'line.%d.%s' % (i, name), row[name], width)
    _need(len(cert['substitutions']) == b['substitutions'], 'Task count differs')
    for i, task in enumerate(cert['substitutions']):
        _need(set(task) == {'source', 'variable', 'term', 'result', 'active', 'map'}, 'Exact task fields required')
        for name in ('source', 'variable', 'term', 'result'):
            _word(flat, 'sub.%d.%s' % (i, name), task[name], w['head'] if name == 'variable' else w['node'])
        _need(len(task['active']) == len(task['map']) == b['nodes'], 'Task vector length differs')
        for node, (active, value) in enumerate(zip(task['active'], task['map'])):
            _need(type(active) is int and active in (0, 1), 'Active value must be a native bit')
            flat['sub.%d.active.%d' % (i, node)] = active
            _word(flat, 'sub.%d.map.%d' % (i, node), value, w['node'])
    return flat


def encode_bits(bounds, cert, input_names):
    """Return bits in compiler order; check only layout/width/pin alignment.

    Accept metadata {'inputs':...,'pins':...}, a name list, or input records
    {'name':str,'value':None|0|1}; two-item [name,value] records also work.
    Known metadata pins may include fields optimized out of the input list.
    """
    flat = _flat(bounds, cert)
    metadata = input_names if type(input_names) is dict else {}
    if metadata:
        input_names = metadata.get('inputs', metadata.get('input_names'))
        for name, value in metadata.get('pins', {}).items():
            _need(type(value) is int and value in (0, 1) and name in flat and flat[name] == value,
                  'Certificate differs from frozen pin: ' + str(name))
    _need(type(input_names) in (list, tuple), 'Ordered compiler inputs required')
    bits, seen = [], set()
    for item in input_names:
        if type(item) is str:
            name, known = item, None
        elif type(item) is dict:
            name, known = item['name'], item.get('value')
        else:
            _need(type(item) in (list, tuple) and len(item) == 2, 'Malformed input record')
            name, known = item
        _need(type(name) is str and name not in seen, 'Input names must be unique strings')
        seen.add(name)
        _need(known is None or type(known) is int and known in (0, 1), 'Known input value must be a bit or None')
        value = flat.get(name, {'zero': 0, 'one': 1}.get(name, known))
        _need(type(value) is int and value in (0, 1), 'Unknown free input name: ' + name)
        _need(known is None or value == known, 'Certificate/input fixed value differs: ' + name)
        bits.append(value)
    return bits
