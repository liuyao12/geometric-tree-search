"""Independent inverse of the bounded raw-Hilbert circuit input format.

No encoder, compiler, evaluator, proof search or logical kernel is imported.
VERIFIED means a lossless codec/common-statement join, NOT a valid derivation.
The returned raw and named proofs require their separate logical checkers.
"""
import hashlib
import json
import math
import time

VERSION='BJ-INDEPENDENT-RAW-INPUT-DECODER-v1'
BOUND_KEYS=('nodes','variables','functions','predicates','axioms','lines','substitutions','arity')
RULES=('AXIOM','MP','GEN','UI','REFL','DIST','EQSUB','AX1','AX2','AX3','BOT_FALSE')

class _Reject(Exception):pass
class _Unknown(Exception):pass

def _need(ok,reason):
    if not ok:raise _Reject(reason)

class _Budget:
    def __init__(self,items,work,seconds):
        _need(type(items) is int and items>0 and type(work) is int and work>0,'RESOURCE_LIMITS')
        _need(type(seconds) in (int,float) and math.isfinite(seconds) and seconds>0,'WALL_LIMIT')
        self.max_items,self.max_work=items,work;self.items=self.work=0;self.deadline=time.monotonic()+seconds
    def tick(self,n=1):
        self.work+=n
        if self.work>self.max_work:raise _Unknown('WORK_BOUND')
        if time.monotonic()>self.deadline:raise _Unknown('WALL_BOUND')
    def scan(self,v,depth=0):
        self.tick()
        if depth>128:raise _Unknown('JSON_DEPTH_BOUND')
        self.items+=1
        if type(v) is str:self.items+=len(v)
        elif type(v) is int:self.items+=max(1,v.bit_length()//8)
        elif type(v) is list:
            for x in v:self.scan(x,depth+1)
        elif type(v) is dict:
            for k,x in v.items():
                _need(type(k) is str,'JSON_KEY_TYPE');self.scan(k,depth+1);self.scan(x,depth+1)
        else:_need(v is None or type(v) is bool or type(v) is float and math.isfinite(v),'FINITE_NATIVE_JSON')
        if self.items>self.max_items:raise _Unknown('ITEM_BOUND')
    def canonical(self,v):
        chunks=[]
        for x in json.JSONEncoder(sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False).iterencode(v):
            self.tick(len(x));chunks.append(x)
        return ''.join(chunks)
    def sha(self,v):return hashlib.sha256((self.canonical(v)+'\n').encode('ascii')).hexdigest()

def _bounds(value):
    _need(type(value) is dict and set(value)==set(BOUND_KEYS),'BOUNDS_FIELDS')
    for k in BOUND_KEYS:
        lower=2 if k in ('nodes','arity') else 1 if k in ('variables','lines') else 0
        _need(type(value[k]) is int and value[k]>=lower,'BOUND_'+k)
    return dict(value)

def _widths(b):
    return dict(node=max(1,(b['nodes']-1).bit_length()),
        head=max(1,(max(b['variables'],b['functions'],b['predicates'],1)-1).bit_length()),
        arity=max(1,b['arity'].bit_length()),ref=max(1,(b['lines']-1).bit_length()),
        aux=max(1,(max(b['axioms'],b['substitutions'],1)-1).bit_length()))

def _native(value,m):
    m.tick(1+len(value) if type(value) is str else 1)
    return [_native(x,m) for x in value] if isinstance(value,tuple) else value

class _Statement:
    """Independently intern the problem-only prefix and required known pins."""
    def __init__(self,b,statement,variables,m):
        self.b,self.m=b,m
        _need(type(statement) is dict and set(statement)=={'theory','goal'},'STATEMENT_FIELDS')
        th=statement['theory'];_need(type(th) is dict and set(th)=={'functions','predicates','axioms'},'THEORY_FIELDS')
        _need(type(variables) is list and len(variables)<=b['variables'] and all(type(v) is str and v for v in variables)
              and len(set(variables))==len(variables),'VARIABLE_POOL')
        self.variables=list(variables);counter=0
        while len(self.variables)<b['variables']:
            m.tick();name='__unused_variable_'+str(counter);counter+=1
            if name not in self.variables:self.variables.append(name)
        self.var_ids={v:i for i,v in enumerate(self.variables)}
        self.fnames,self.pnames=[],[];self.signatures={}
        for key,capacity in (('functions',b['functions']),('predicates',b['predicates'])):
            sig=th[key];_need(type(sig) is dict and len(sig)<=capacity,'SIGNATURE_FIELDS_'+key)
            _need(all(type(k) is str and k and type(v) is int and 0<=v<=b['arity'] for k,v in sig.items()),'SIGNATURE_ARITIES_'+key)
            names=sorted(sig);self.signatures[key]=[sig[n] for n in names]+[0]*(capacity-len(names))
            if key=='functions':self.fnames=names
            else:self.pnames=names
        self.fids={n:i for i,n in enumerate(self.fnames)};self.pids={n:i for i,n in enumerate(self.pnames)}
        _need(type(th['axioms']) is dict and len(th['axioms'])<=b['axioms'] and all(type(k) is str and k for k in th['axioms']),'AXIOM_NAMES')
        self.axiom_names=sorted(th['axioms']);_need(self.axiom_names or b['axioms']==0,'EMPTY_GAMMA_SLOTS')
        self.rows=[[0]*(2+b['arity'])];self.asts=[None];self.ids={};self.free={}
        normalized_axioms={n:self.normalize(th['axioms'][n],False) for n in self.axiom_names}
        _need(all(not self.fv(f) for f in normalized_axioms.values()),'CLOSED_GAMMA')
        roots=[self.intern(normalized_axioms[n]) for n in self.axiom_names]
        self.normalized_goal=self.normalize(statement['goal'],False);self.goal=self.intern(self.normalized_goal)
        self.axiom_ids=roots+[roots[0]]*(b['axioms']-len(roots)) if roots else []
        # Match the format's safe auxiliary syntax, which is NOT an assumption.
        var0=('var',self.variables[0])
        if len(self.rows)<b['nodes'] or var0 in self.ids:self.intern(var0)
        if b['substitutions'] and not roots:self.intern(('not',('bot',)))
        self.normalized_theory={k:dict(th[k]) for k in ('functions','predicates')}
        self.normalized_theory['axioms']={n:_native(normalized_axioms[n],m) for n in self.axiom_names}
        self.pins={'zero':0,'one':1};w=_widths(b)
        def word(name,value,width):
            _need(0<=value<1<<width,'PREFIX_WORD_RANGE')
            for bit in range(width):m.tick();self.pins[name+'.'+str(bit)]=(value>>bit)&1
        for field,label in (('functions','function'),('predicates','predicate')):
            for i,a in enumerate(self.signatures[field]):word(label+'.'+str(i)+'.arity',a,w['arity'])
        for i,row in enumerate(self.rows):
            word('node.%d.tag'%i,row[0],4);word('node.%d.head'%i,row[1],w['head'])
            for k,value in enumerate(row[2:]):word('node.%d.arg.%d'%(i,k),value,w['node'])
        for i,value in enumerate(self.axiom_ids):word('axiom.'+str(i),value,w['node'])
        word('goal',self.goal,w['node'])

    def normalize(self,a,term,depth=0):
        self.m.tick()
        if depth>96:raise _Unknown('STATEMENT_AST_DEPTH_BOUND')
        _need(type(a) is list and a and type(a[0]) is str,'STATEMENT_AST')
        tag=a[0];_need((tag in ('var','fun'))==term,'STATEMENT_AST_SORT')
        if tag=='var':
            _need(len(a)==2 and a[1] in self.var_ids,'STATEMENT_VARIABLE');return (tag,a[1])
        if tag in ('fun','pred'):
            ids=self.fids if tag=='fun' else self.pids;sig=self.signatures['functions' if tag=='fun' else 'predicates']
            _need(len(a)==3 and type(a[1]) is str and a[1] in ids and type(a[2]) is list and len(a[2])==sig[ids[a[1]]],'STATEMENT_SYMBOL')
            return (tag,a[1],tuple(self.normalize(t,True,depth+1) for t in a[2]))
        if tag in ('eq','imp','and','or'):
            _need(len(a)==3,'STATEMENT_BINARY')
            x,y=(self.normalize(c,tag=='eq',depth+1) for c in a[1:])
            if tag=='and':return ('not',('imp',x,('not',y)))
            if tag=='or':return ('imp',('not',x),y)
            return (tag,x,y)
        if tag=='all':
            _need(len(a)==3 and type(a[1]) is str and a[1] in self.var_ids,'STATEMENT_BINDER')
            return (tag,a[1],self.normalize(a[2],False,depth+1))
        if tag=='not':
            _need(len(a)==2,'STATEMENT_NOT');return (tag,self.normalize(a[1],False,depth+1))
        _need(tag=='bot' and len(a)==1,'STATEMENT_TAG');return ('bot',)

    def children(self,a):
        if a[0] in ('fun','pred'):return a[2]
        if a[0] in ('eq','imp'):return a[1:]
        if a[0]=='all':return (a[2],)
        return (a[1],) if a[0]=='not' else ()
    def fv(self,a):
        self.m.tick()
        if a not in self.free:
            values={a[1]} if a[0]=='var' else set().union(*(self.fv(c) for c in self.children(a)))
            if a[0]=='all':values.discard(a[1])
            self.free[a]=frozenset(values)
        return self.free[a]
    def intern(self,a):
        self.m.tick()
        if a in self.ids:return self.ids[a]
        children=[self.intern(c) for c in self.children(a)]
        if len(self.rows)>=self.b['nodes']:raise _Unknown('STATEMENT_PREFIX_NODE_BOUND')
        tag=a[0];head=self.var_ids[a[1]] if tag in ('var','all') else self.fids[a[1]] if tag=='fun' else self.pids[a[1]] if tag=='pred' else 0
        codes={'var':1,'fun':2,'pred':3,'eq':4,'not':5,'imp':6,'all':7,'bot':10}
        row=[codes[tag],head]+children+[0]*(self.b['arity']-len(children))
        i=len(self.rows);self.ids[a]=i;self.rows.append(row);self.asts.append(a);return i

def _layout(b,w,m):
    for group,label in (('functions','function'),('predicates','predicate')):
        for i in range(b[group]):m.tick();yield label+'.%d.arity'%i,(group,i),w['arity'],False
    for i in range(b['nodes']):
        m.tick();yield 'node.%d.tag'%i,('nodes',i,0),4,False
        yield 'node.%d.head'%i,('nodes',i,1),w['head'],False
        for k in range(b['arity']):m.tick();yield 'node.%d.arg.%d'%(i,k),('nodes',i,k+2),w['node'],False
    for i in range(b['axioms']):m.tick();yield 'axiom.'+str(i),('axioms',i),w['node'],False
    yield 'goal',('goal',),w['node'],False
    for i in range(b['lines']):
        for field,width in (('rule',4),('formula',w['node']),('ref0',w['ref']),('ref1',w['ref']),('aux0',w['aux']),('aux1',w['aux'])):
            m.tick();yield 'line.%d.%s'%(i,field),('proof',i,field),width,False
    for i in range(b['substitutions']):
        for field in ('source','variable','term','result'):
            m.tick();yield 'sub.%d.%s'%(i,field),('substitutions',i,field),w['head'] if field=='variable' else w['node'],False
        for j in range(b['nodes']):m.tick();yield 'sub.%d.active.%d'%(i,j),('substitutions',i,'active',j),1,True
        for j in range(b['nodes']):m.tick();yield 'sub.%d.map.%d'%(i,j),('substitutions',i,'map',j),w['node'],False

def _empty(b,m):
    # Reserve structural allocations before creating the arrays.
    m.tick(10+b['nodes']*(3+b['arity'])+b['lines']*8+b['substitutions']*(8+2*b['nodes'])+b['functions']+b['predicates']+b['axioms'])
    return dict(functions=[0]*b['functions'],predicates=[0]*b['predicates'],
        nodes=[[0]*(2+b['arity']) for _ in range(b['nodes'])],axioms=[0]*b['axioms'],goal=0,
        proof=[{} for _ in range(b['lines'])],
        substitutions=[dict(active=[0]*b['nodes'],map=[0]*b['nodes']) for _ in range(b['substitutions'])])

def _get(value,path):
    for part in path:value=value[part]
    return value
def _put(value,path,item):
    for part in path[:-1]:value=value[part]
    value[path[-1]]=item

def _names(actual,count,label):
    result=list(actual);used=set(actual)
    while len(result)<count:
        name='__nk_'+label+'_slot_'+str(len(result))
        while name in used:name+='_' 
        result.append(name);used.add(name)
    return result

def _human(raw,b,statement,m):
    fn=_names(statement.fnames,b['functions'],'function');pn=_names(statement.pnames,b['predicates'],'predicate')
    variables=statement.variables;asts=[None];sorts=['NULL'];free=[set()]
    _need(raw['nodes'][0]==[0]*(2+b['arity']),'NULL_NODE')
    for i,row in enumerate(raw['nodes'][1:],1):
        m.tick();tag,head,args=row[0],row[1],row[2:]
        if tag==1:
            _need(head<b['variables'],'RAW_VARIABLE_HEAD');used,sort,childsort=0,'TERM',None;ast=['var',variables[head]]
        elif tag in (2,3):
            arities=raw['functions' if tag==2 else 'predicates'];names=fn if tag==2 else pn
            _need(head<len(arities) and arities[head]<=b['arity'],'RAW_SYMBOL_HEAD_ARITY')
            used,sort,childsort=arities[head],'TERM' if tag==2 else 'FORMULA','TERM';ast=None
        else:
            _need(tag in (4,5,6,7,10),'RAW_NODE_TAG')
            _need(head<b['variables'] if tag==7 else head==0,'RAW_LOGICAL_HEAD')
            used={4:2,5:1,6:2,7:1,10:0}[tag];sort='FORMULA';childsort='TERM' if tag==4 else 'FORMULA';ast=None
        _need(all(x==0 for x in args[used:]),'RAW_UNUSED_ARGUMENTS')
        for child in args[:used]:
            _need(0<child<i and sorts[child]==childsort,'RAW_STRICT_PRIOR_CHILD_SORT')
        children=[asts[c] for c in args[:used]]
        if tag in (2,3):ast=['fun' if tag==2 else 'pred',names[head],children]
        elif tag in (4,6):ast=['eq' if tag==4 else 'imp']+children
        elif tag==5:ast=['not',children[0]]
        elif tag==7:ast=['all',variables[head],children[0]]
        elif tag==10:ast=['bot']
        fv={head} if tag==1 else set().union(*(free[c] for c in args[:used]))
        if tag==7:fv.discard(head)
        asts.append(ast);sorts.append(sort);free.append(fv)
    def node(i,sort):
        _need(type(i) is int and 0<i<len(asts) and sorts[i]==sort,'RAW_NODE_ID_SORT');return asts[i]
    for task in raw['substitutions']:
        m.tick();node(task['source'],'FORMULA');node(task['result'],'FORMULA');node(task['term'],'TERM')
        _need(task['variable']<b['variables'] and all(x<b['nodes'] for x in task['map']),'RAW_TASK_IDS')
    for i in raw['axioms']:
        node(i,'FORMULA');_need(not free[i],'RAW_OPEN_ASSUMPTION')
    goal=node(raw['goal'],'FORMULA');proof=[]
    for record in raw['proof']:
        m.tick();rule=record['rule'];_need(rule<len(RULES),'RAW_UNLISTED_RULE')
        f=node(record['formula'],'FORMULA');line=dict(formula=f)
        if rule==0:
            slot=record['aux0'];_need(slot<b['axioms'] and statement.axiom_names,'RAW_AXIOM_SLOT')
            line.update(rule='axiom',name=statement.axiom_names[slot] if slot<len(statement.axiom_names) else statement.axiom_names[0])
        elif rule==1:line.update(rule='mp',antecedent=record['ref0'],implication=record['ref1'])
        elif rule==2:
            _need(f[0]=='all','RAW_GEN_DISPLAY_SHAPE');line.update(rule='generalize',source=record['ref0'],variable=f[1])
        elif rule in (3,6):
            _need(record['aux0']<len(raw['substitutions']),'RAW_ACTIVE_TASK_SLOT')
            first=raw['substitutions'][record['aux0']]
            if rule==3:line.update(rule='instantiate',universal=['all',variables[first['variable']],asts[first['source']]],term=asts[first['term']])
            else:
                _need(record['aux1']<len(raw['substitutions']),'RAW_SECOND_TASK_SLOT');second=raw['substitutions'][record['aux1']]
                line.update(rule='eq_subst',variable=variables[first['variable']],template=asts[first['source']],left=asts[first['term']],right=asts[second['term']])
        elif rule==4:line.update(rule='refl')
        elif rule==5:
            _need(f[0]=='imp' and f[1][0]=='all' and f[1][2][0]=='imp','RAW_DIST_DISPLAY_SHAPE')
            line.update(rule='distribute',variable=f[1][1],antecedent=f[1][2][1],consequent=f[1][2][2])
        else:line.update(rule='tautology')
        proof.append(line)
    _need(raw['proof'][-1]['formula']==raw['goal'],'RAW_FINAL_STATEMENT_ID')
    normalized_goal=_native(statement.normalized_goal,m)
    _need(m.canonical(goal)==m.canonical(normalized_goal),'NAMED_GOAL_BINDING')
    for i,name in enumerate(statement.axiom_names):
        _need(m.canonical(asts[raw['axioms'][i]])==m.canonical(statement.normalized_theory['axioms'][name]),'NAMED_AXIOM_BINDING')
    theory=dict(functions=dict(zip(fn,raw['functions'])),predicates=dict(zip(pn,raw['predicates'])),
                axioms=statement.normalized_theory['axioms'])
    return dict(theory=theory,goal=goal,proof=proof,node_asts=asts,
        variable_names=variables,function_names=fn,predicate_names=pn,
        normalized_original_statement=dict(theory=statement.normalized_theory,goal=normalized_goal),
        conservative_padding=dict(functions=fn[len(statement.fnames):],predicates=pn[len(statement.pnames):],
            duplicate_axiom_slots=max(0,b['axioms']-len(statement.axiom_names))))

def decode(bounds,circuit_inputs,input_bits,original_statement,*,variables,
           max_items=10000000,max_work=20000000,wall_seconds=30.0):
    """Decode exact circuit inputs and certify only their common-statement join.

    The input-name order AND every fixed/missing pin are independently checked.
    Raw rules/substitution maps remain data for separate logical validation.
    """
    m=None;stage='resources'
    try:
        m=_Budget(max_items,max_work,wall_seconds);stage='input_json'
        for v in (bounds,circuit_inputs,input_bits,original_statement,variables):m.scan(v)
        b=_bounds(bounds);w=_widths(b);stage='problem_prefix'
        statement=_Statement(b,original_statement,variables,m)
        _need(type(circuit_inputs) is list and type(input_bits) is list and len(circuit_inputs)==len(input_bits),'INPUT_VECTOR_COUNTS')
        cursor=0
        def bit(name):
            nonlocal cursor
            m.tick(1+len(name));_need(cursor<len(input_bits),'MISSING_INPUT_BIT')
            row,value=circuit_inputs[cursor],input_bits[cursor];cursor+=1
            _need(type(row) is dict and set(row)=={'name','value'} and type(row['name']) is str and row['name']==name,'EXACT_INPUT_LAYOUT')
            known=row['value'];_need(known is None or type(known) is int and known in (0,1),'INPUT_PIN_TYPE')
            _need(type(value) is int and value in (0,1),'INPUT_BIT_TYPE')
            required=statement.pins.get(name)
            _need(type(known) is type(required) and known==required,'EXACT_PROBLEM_ONLY_PIN_SET')
            _need(known is None or value==known,'FIXED_INPUT_BIT_BINDING')
            return value
        _need(bit('zero')==0 and bit('one')==1,'CONSTANT_INPUT_BITS')
        stage='raw_fields';raw=_empty(b,m)
        for name,path,width,scalar in _layout(b,w,m):
            value=bit(name) if scalar else sum(bit(name+'.'+str(k))<<k for k in range(width))
            _put(raw,path,value)
        _need(cursor==len(input_bits),'EXTRA_INPUT_FIELDS')
        stage='raw_bit_roundtrip';roundtrip=[0,1]
        for name,path,width,scalar in _layout(b,w,m):
            value=_get(raw,path);m.tick(width);roundtrip.extend((value>>k)&1 for k in range(width))
        _need(roundtrip==input_bits,'LOSSLESS_RAW_BIT_ROUNDTRIP')
        stage='named_decode';human=_human(raw,b,statement,m)
        stage='receipt'
        return dict(schema='BJ-input-raw-human-join-receipt-v1',status='VERIFIED',version=VERSION,
            reason='EXACT_INPUT_RAW_NAMED_STATEMENT_JOIN',raw_certificate=raw,human=human,
            bounds=b,input_count=len(input_bits),known_pins=len(statement.pins),statement_prefix_nodes=len(statement.rows),
            raw_certificate_sha256=m.sha(raw),input_bits_sha256=m.sha(input_bits),input_layout_sha256=m.sha(circuit_inputs),
            original_statement_sha256=m.sha(original_statement),normalized_statement_sha256=m.sha(human['normalized_original_statement']),
            prefix_sha256=m.sha(statement.rows),raw_bit_roundtrip=True,proof_lines=b['lines'],substitution_tasks=b['substitutions'],
            proof_validity='NOT_CHECKED_REQUIRES_RAW_AND_NATIVE_LOGICAL_KERNELS',
            scope='Exact codec, deterministic problem-only/padding pins and common named statement. No circuit evaluation, logical rule/capture validation, proof search, tile search or unbounded completeness claim.',
            work=m.work,checked_items=m.items)
    except _Reject as error:
        return dict(status='REJECTED',version=VERSION,stage=stage,reason=str(error),work=m.work if m else 0)
    except (_Unknown,MemoryError,RecursionError) as error:
        return dict(status='UNKNOWN',version=VERSION,stage=stage,reason=str(error) or type(error).__name__,work=m.work if m else 0)
    except (KeyError,TypeError,IndexError,ValueError,OverflowError) as error:
        return dict(status='REJECTED',version=VERSION,stage=stage,reason='MALFORMED_INPUT:'+type(error).__name__,work=m.work if m else 0)
