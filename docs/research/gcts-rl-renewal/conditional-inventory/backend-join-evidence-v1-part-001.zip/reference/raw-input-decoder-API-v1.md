# Independent raw circuit input decoder

This is Source-only handoff, not an execution or qualification receipt. The author imported no scientific module, built no witness/circuit and ran no decoder/kernel/search. The current master contract was read directly from the primary project before implementation.

## API and meaning

`raw_input_decoder_v1.decode(bounds, circuit_inputs, input_bits, original_statement, *, variables, max_items=10000000, max_work=20000000, wall_seconds=30.0)` returns a JSON receipt.

- `original_statement` has exactly `theory` and `goal`. The theory has exactly `functions`, `predicates` and named `axioms`, with the same native ASTs/signatures as the original problem. It contains no selected proof or encoder metadata.
- `variables` is the prospectively declared unique ordered variable pool. It is supplied separately from the original mathematical statement. It must include the variables needed by original syntax; the raw format pads it deterministically if the declared bound is larger.
- `circuit_inputs` is the actual ordered `circuit.inputs` array of exact `{name,value}` records. `input_bits` is the complete assigned top-input vector. Known zero is distinct from an unassigned value.
- `bounds` has the eight raw-kernel fields `nodes`, `variables`, `functions`, `predicates`, `axioms`, `lines`, `substitutions`, and `arity`. This decoder is parameterized by those widths; it does not introduce the old kernel's finite numerical caps as logical limits. Explicit decoder work/item/wall/depth guards can still refuse with `UNKNOWN`.

`VERIFIED` means **exact codec/common-statement binding**, not a valid proof. The receipt explicitly carries `proof_validity: NOT_CHECKED_REQUIRES_RAW_AND_NATIVE_LOGICAL_KERNELS`. The caller must separately require the raw kernel, named native kernel, Boolean acceptance and physical tile/ribbon checks. `REJECTED` means malformed data, an unsupported raw/display structure, or any binding/layout/type/pin mismatch. A resource or depth refusal is `UNKNOWN`.

The verified output includes:

- `raw_certificate`: all signature arities, syntax rows, assumption/goal IDs, proof records and substitution active/map arrays.
- `human.theory`, `human.goal`, `human.proof`: named ASTs and native-rule proof records. Raw propositional basis rules are displayed as the native `tautology` rule; the separate raw kernel must still validate the particular raw basis code.
- `human.normalized_original_statement`: the original theory and goal after the explicitly declared conjunction/disjunction definitions below.
- `human.node_asts`, variable/function/predicate names, and any conservative padding information.
- Exact SHA256 identities for original/normalized statement, actual input layout, assigned input bits, raw certificate and deterministic prefix; a full raw-bit round-trip result.

The inverse uses no encoder/compiler/kernel imports. It independently recreates the entire ordered input-field layout, little-endian words, postorder shared problem prefix, signature/assumption/goal closure and safe auxiliary syntax. It requires exactly the problem-only known pins produced by that format. Extra known witness/proof pins are rejected, even if they agree with this particular assignment. All other syntax/proof/substitution input fields remain free. The caller's prospective source/protocol custody must separately establish that the circuit was frozen before the witness was supplied; an inverse cannot establish chronology from values alone.

The decoder validates raw acyclic syntax/sorts, referenced display structures and the final statement ID sufficiently to decode all named objects. It deliberately does not reimplement substitution-map hygiene or complete logical rule incidence. Capture-invalid maps are not proved valid by this receipt. The raw bit round-trip preserves unused ref/aux fields and all substitution fields; reconstructing only the displayed human proof would discard such representational data. The returned raw object is therefore the lossless representation.

## Normalization and padding

The two definitional translations are

\[
A\land B:=\neg(A\to\neg B),\qquad A\lor B:=(\neg A)\to B.
\]

The decoded native proof must be checked against the **normalized** named theory and goal. Passing the original conjunction AST as an axiom while using its desugared raw AST as the proof line would fail the native checker's syntactic axiom rule. Arithmetic in the present target has no conjunction/disjunction and its statement is unchanged by this normalization.

Spare function/predicate slots have the format's pinned nullary arity and receive fresh deterministic names. They are an explicit conservative language extension; no new assumption is introduced. Spare axiom slots repeat the first named assumption and decode back to that same name. An empty theory requires zero axiom slots. Safe variable and bottom-falsity source syntax is frozen as syntax only, never an extra assumption. No alpha-renaming is performed.

## Actual arithmetic compatibility assessment

Only saved JSON was inspected. The selected fresh `pft-arithmetic-r0-h4-v1--MARKS` output has 12 original lines; its rules are `refl`, `eq_subst`, `mp`, `axiom`, `instantiate` and `generalize`. It uses the original arithmetic variable and `__rf_hole`. Its supplied formulas/schema parameters contain 22 distinct literal syntax subtrees and four distinct source/variable/term tasks: one UI task, one shared reflexive EQSUB task, and two tasks for the nonreflexive EQSUB. Those are passive structural counts, not an executed encoding bound certificate. Substitution-result intermediates and the null/padding syntax still require actual admission.

The proposed unchanged proof has bounds `nodes=32`, `variables=2`, `functions=3`, `predicates=0`, `axioms=1`, `lines=12`, `substitutions=4`, `arity=2`. The raw layout at those bounds has 1,618 input bits. No padding/reordering/deduplication of the original 12 proof lines is required. Circuit construction may still hit the existing gate ceiling; that outcome must remain `UNKNOWN`. This assessment does not claim compilation success or a new search result.

The selected native receipt is an actual prior solver output, used here only as a backend witness. It must not become a future target-search input. Its locator is `gcts-proof-family-transfer-20261103-v1/data/runs/pft-arithmetic-r0-h4-v1--MARKS-native-check.json`: 62,628 bytes, SHA256 `656477350694302e44fc6c85a00bbb758ac856722550b3159f5bc6d60aded790`.

## Source pins inspected

These are existing noncloud sources under sibling `gcts-fol-kernel-20261103-v1`; they were read, not executed:

| Path | Bytes | SHA256 |
| --- | ---: | --- |
| `source/kernel_data_v1.py` | 21103 | `7fc693a12fca8940e95fa7d49ce0982094d03efdfda32d23d839fbe52833596f` |
| `source/raw_kernel_circuit_v1.py` | 17729 | `493e903c688e7aa5a57b5e4eaa4630182bc0bd42245685f3f58cf548d93c089d` |
| `source/raw_kernel_circuit_v2.py` | 2895 | `a38aa4f2415965e894ce6b6764b0fb5be166f10259b0e12664b11780604f99cb` |
| `source/raw_kernel_circuit_v3.py` | 1295 | `921dd80dfff1db388a8d36b7e8ae93df5cba33dfc0a01917f15a178d86b7593f` |
| `reference/kernel-spec-v1.txt` | 5118 | `6fe494ed6e03d2b380ee0e534f3ea37f04bb8453fbd9fe5c45a784f701da2c71` |

The primary `docs/basic-tiling-algorithm.md` is 21,657 bytes, SHA256 `c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9`. The new decoder's Source pin is delivered separately to avoid self-reference.

Prospective qualification should round-trip an actually encoded accepted certificate; then mutate native bit types, input names/order, known/missing pins, signature slots, statement closure, assumption/goal IDs and active map words. Test conjunction normalization, empty theory and conservative padding. Invalid logical maps/references require a separate raw/native rejection; codec acceptance alone is not a logical failure. An explicit low work/item guard must remain `UNKNOWN`. These checks have not been run by this author.
