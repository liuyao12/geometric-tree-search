"""Byte-only copy/admission of the completed depth study; no scientific imports."""
from pathlib import Path
import hashlib,json,shutil

ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT.parent/'gcts-proof-depth-20261103-v1'
TARGET=ROOT/'companion/proof-depth-v1'
def wire(v):return (json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=True)+'\n').encode('ascii')
def pin(p):
    h=hashlib.sha256();n=0
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b);n+=len(b)
    return dict(bytes=n,sha256=h.hexdigest())
def save(p,v):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('xb') as f:f.write(wire(v))
audit=json.loads((SOURCE/'review/saved-data-audit-v1.json').read_bytes())
summary=json.loads((SOURCE/'data/report-summary-v1.json').read_bytes())
assert audit['status']=='PASS_SAVED_DEPTH_AUDIT'
assert summary['status']=='EXECUTED_WITH_BASE_UNKNOWNS'
assert summary['coverage']['study']['point_result/SAT']==8
assert summary['coverage']['study']['point_result/UNKNOWN']==4
assert summary['coverage']['study']['DP/DERIVABLE']==4
for comparison in summary['coverage']['matched_MARKS_IFILTER_comparisons']:
    assert comparison['exact_event_dicts_equal'] and comparison['actual_native_proof_asts_equal']
for phase in ('qualification','study'):
    protocol=json.loads((SOURCE/('data/'+phase+'-protocol-v1.json')).read_bytes())
    for name,expected in protocol['pins'].items():assert pin(SOURCE/name)==expected,name
    runtime=protocol['runtime'];assert pin(Path(runtime['path']))=={k:runtime[k] for k in ('bytes','sha256')}
    master=protocol['primary_master'];assert pin(Path(master['path']))=={k:master[k] for k in ('bytes','sha256')}
    observer=json.loads((SOURCE/('review/observer-'+phase+'-v1.json')).read_bytes())
    assert observer['status']=='TERMINAL' and observer['native_exit']==0 and observer['guard'] is None
assert not TARGET.exists()
inventory=[]
for p in sorted(SOURCE.rglob('*')):
    assert not p.is_symlink(),p
    if p.is_dir():continue
    name=p.relative_to(SOURCE).as_posix();q=TARGET/name;q.parent.mkdir(parents=True,exist_ok=True)
    before=pin(p);shutil.copyfile(p,q);assert pin(p)==pin(q)==before
    inventory.append(dict(path=name,**before))
def ref(name):return dict(path=name,**pin(ROOT/name))
receipt=dict(status='PASS',source_root=str(SOURCE),copied_root='companion/proof-depth-v1',
    files=inventory,file_count=len(inventory),original_bytes=sum(x['bytes'] for x in inventory),
    audit=ref('companion/proof-depth-v1/review/saved-data-audit-v1.json'),
    summary=ref('companion/proof-depth-v1/data/report-summary-v1.json'),
    scope='Exact complete completed companion copy, all Source/runtime/master phase pins rechecked; all copied file bytes agree. No scientific execution repeated.')
save(ROOT/'review/depth-addon-admission-v1.json',receipt)
save(ROOT/'data/report-addons-v1.json',dict(status='ADMITTED',depth=receipt['summary'],admission=ref('review/depth-addon-admission-v1.json')))
print(json.dumps(dict(status=receipt['status'],files=len(inventory),bytes=receipt['original_bytes'])))
