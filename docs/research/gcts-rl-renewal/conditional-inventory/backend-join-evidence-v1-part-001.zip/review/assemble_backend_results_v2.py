"""Passive saved-data/hash/census assembly; imports no scientific module.

No encoder/compiler/decoder/kernel/circuit evaluator or tile checker is called.
Existing semantic receipts are joined on full retained bytes and provenance;
their mathematical predicates are not replayed by this assembler.
"""
import gzip
import hashlib
import json
from pathlib import Path,PurePosixPath
import resource
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
PRIOR=ROOT.parent/'gcts-proof-family-transfer-20261103-v1'
PUBLIC_COMMIT='8b2f7e381943d713b4dd200250f30eb508cbaefc'

def canonical_chunks(value):
    yield from json.JSONEncoder(sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False).iterencode(value)
    yield '\n'
def sha(value):
    h=hashlib.sha256()
    for part in canonical_chunks(value):h.update(part.encode('ascii'))
    return h.hexdigest()
def equal(a,b):return sha(a)==sha(b)
def pin(path):
    h=hashlib.sha256();n=0
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1048576),b''):h.update(block);n+=len(block)
    return dict(bytes=n,sha256=h.hexdigest())
def safe(root,name):
    p=PurePosixPath(name);assert type(name) is str and p.as_posix()==name and not p.is_absolute() and '..' not in p.parts and '\\' not in name
    result=root/name;assert root.resolve() in result.resolve().parents;return result
def read(name,root=ROOT):
    p=safe(root,name)
    with (gzip.open(p,'rt',encoding='ascii') if p.suffix=='.gz' else p.open(encoding='ascii')) as f:return json.load(f)
def ref(name,root=ROOT):return dict(path=name,**pin(safe(root,name)))
REFERENCES=[]
def checked(entry,root=ROOT):
    assert equal(pin(safe(root,entry['path'])),{k:entry[k] for k in ('bytes','sha256')}),entry['path']
    REFERENCES.append(dict(root=str(root),**entry));return read(entry['path'],root)
def save(name,value):
    p=safe(ROOT,name);p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('xb') as f:
        for part in canonical_chunks(value):f.write(part.encode('ascii'))
    return ref(name)
def snapshot_copy(source,name):
    p=safe(ROOT,name);p.parent.mkdir(parents=True,exist_ok=True)
    with source.open('rb') as incoming,p.open('xb') as outgoing:
        for block in iter(lambda:incoming.read(1048576),b''):outgoing.write(block)
    assert equal(pin(source),pin(p));return ref(name)
def normalize(a):
    tag=a[0]
    if tag=='var':return list(a)
    if tag in ('fun','pred'):return [tag,a[1],[normalize(x) for x in a[2]]]
    if tag in ('eq','imp','and','or'):
        left,right=normalize(a[1]),normalize(a[2])
        if tag=='and':return ['not',['imp',left,['not',right]]]
        if tag=='or':return ['imp',['not',left],right]
        return [tag,left,right]
    if tag=='all':return [tag,a[1],normalize(a[2])]
    if tag=='not':return [tag,normalize(a[1])]
    assert tag=='bot';return ['bot']
def projection(lines):
    fields=dict(axiom=('name',),mp=('antecedent','implication'),generalize=('source','variable'),
        instantiate=('universal','term'),refl=(),eq_subst=('variable','template','left','right'),
        distribute=('variable','antecedent','consequent'),tautology=())
    asts={'formula','universal','term','template','left','right'}
    return [{k:normalize(line[k]) if k in asts else line[k] for k in ('rule','formula')+fields[line['rule']]} for line in lines]

def join_record(record):
    assert record['status']=='VERIFIED_COMPRESSED_BACKEND_JOIN'
    objects={name:checked(value) for name,value in record['artifacts'].items()}
    p,c,e,i,r=(objects[k] for k in ('prepare','compile','encode','inverse','ribbon'))
    raw,native,binding,symbolic,literal=(objects[k] for k in ('raw','native','binding','symbolic','literal'))
    assert p['status']=='PREPARED' and c['status']=='COMPILED' and e['status']=='ENCODED' and r['status']=='CERTIFICATE_BUILT'
    assert all(x['status']=='VERIFIED' for x in (i,raw,native,binding,symbolic))
    assert c['prepared_sha256']==e['prepared_sha256']==r['prepared_sha256']==sha(p)
    statement=sha(p['original_statement'])
    assert statement==p['original_statement_sha256']==c['original_statement_sha256']==e['original_statement_sha256']==r['original_statement_sha256']==i['original_statement_sha256']==binding['original_statement_sha256']
    circuit=c['circuit'];palette=c['palette'];cert=r['ribbon'];gates=r['gate_bits']
    assert sha(circuit)==c['circuit_sha256']==e['circuit_sha256']==r['circuit_sha256']==symbolic['circuit_sha256']==cert['circuit_sha256']
    assert sha(c['metadata'])==c['metadata_sha256'] and equal(c['metadata']['inputs'],circuit['inputs'])
    assert sha(palette)==c['palette_sha256']==r['palette_sha256']==symbolic['palette_sha256']==cert['palette_sha256']
    assert sha(cert)==r['ribbon_sha256']==symbolic['certificate_sha256']
    assert sha(gates)==r['gate_bits_sha256'] and equal(gates,cert['gate_bits'])
    assert all(type(x) is int and x in (0,1) for x in gates+e['input_bits'])
    assert equal(e['input_bits'],cert['input_bits']) and sha(e['input_bits'])==e['input_bits_sha256']==r['input_bits_sha256']==i['input_bits_sha256']
    assert sha(e['raw_certificate'])==e['raw_certificate_sha256']==r['raw_certificate_sha256']==i['raw_certificate_sha256']==raw['certificate_sha256']
    assert equal(e['raw_certificate'],i['raw_certificate']) and i['raw_bit_roundtrip'] is True
    assert i['input_layout_sha256']==sha(circuit['inputs']) and i['proof_validity']=='NOT_CHECKED_REQUIRES_RAW_AND_NATIVE_LOGICAL_KERNELS'
    assert sha(p['proof'])==p['original_proof_sha256']==e['original_proof_sha256']
    projected=projection(p['proof']);decoded=projection(i['human']['proof'])
    assert equal(projected,decoded) and sha(decoded)==binding['normalized_native_line_sha256']
    assert sha(i['human']['normalized_original_statement'])==i['normalized_statement_sha256']==p['normalized_statement_sha256']==binding['normalized_statement_sha256']
    assert all(binding[k] is True for k in ('exact_bit_roundtrip','exact_normalized_native_lines','raw_certificate_roundtrip'))
    lines=len(p['proof']);assert lines==record['proof_lines']==p['bounds']['lines']==native['checked_lines']==raw['checked_lines']==i['proof_lines']
    assert raw['closed_Gamma'] is True and sum(raw['rule_counts'].values())==lines and sum(native['rule_counts'].values())==lines
    assert equal(record['bounds'],p['bounds']) and equal(raw['bounds'],p['bounds']) and equal(c['metadata']['bounds'],p['bounds'])
    inputs,height=len(circuit['inputs']),len(circuit['gates']);width=inputs+height;cells=width*height
    fixed_inputs=sum(row['value'] is not None for row in circuit['inputs'])
    assert fixed_inputs==c['metrics']['fixed_input_bits']==i['known_pins']==p['metrics']['problem_pin_bits']+2
    assert len(gates)==len(cert['rows'])==height and r['circuit_acceptance_bit']==1
    for y,gate in enumerate(circuit['gates']):assert type(gate) is list and len(gate)==2 and all(type(x) is int and 0<=x<inputs+y for x in gate)
    assert len(palette['tiles'])==100 and [t['id'] for t in palette['tiles']]==list(range(100))
    assert len({sha({k:v for k,v in t.items() if k!='id'}) for t in palette['tiles']})==100
    active=sum(len(row['active']) for row in cert['rows']);intervals=sum(len(row['ribbons']) for row in cert['rows'])
    assert active==symbolic['active_cells'] and intervals==symbolic['ribbon_intervals']
    assert cells==symbolic['cells']==r['metrics']['nominal_grid_cells']==c['metrics']['nominal_grid_cells']
    assert width==symbolic['width']==c['metrics']['nominal_grid_width'] and height==symbolic['height']==c['metrics']['nominal_grid_height']
    assert symbolic['ribbon_cells']==cells-active and symbolic['expanded_cells']==0 and symbolic['cross_transport_cases']==20
    assert all(symbolic[k] is True for k in ('all_literal_edge_interfaces_agree','all_vertical_op_selectors_bound_to_circuit','exact_cell_partition_t1'))
    assert symbolic['output_column']==circuit['output'] and symbolic['bottom_output_bit']==1
    proof_bands=[group for group in c['metadata']['groups'] if 'proof_line' in group]
    assert len(proof_bands)==lines and sorted(x['proof_line'] for x in proof_bands)==list(range(lines))
    assert all(0<=x['start']<=x['end']<=height for x in c['metadata']['groups'])
    assert literal['status'] in ('VERIFIED','UNKNOWN')
    if literal['status']=='VERIFIED':assert literal['expanded_cells']==literal['cells']==cells
    metrics=dict(proof_lines=lines,raw_nodes=len(e['raw_certificate']['nodes']),substitution_tasks=len(e['raw_certificate']['substitutions']),
        input_bits=inputs,known_input_bits=fixed_inputs,free_input_bits=inputs-fixed_inputs,
        statement_prefix_nodes=p['metrics']['problem_prefix_nodes'],nand_gates=height,nominal_grid_width=width,nominal_grid_height=height,
        nominal_tile_instances=cells,palette_types=100,active_tile_instances=active,
        ribbon_tile_instances=cells-active,ribbon_intervals=intervals,symbolic_expanded_cells=0,
        literal_status=literal['status'],literal_reason=literal['reason'],
        literal_verified_expanded_cells=literal.get('expanded_cells') if literal['status']=='VERIFIED' else None)
    return objects,dict(status=record['status'],metrics=metrics,bounds=p['bounds'],
        checks={k:objects[k]['status'] for k in ('inverse','raw','native','binding','symbolic','literal')},
        original_statement_sha256=statement,normalized_statement_sha256=p['normalized_statement_sha256'],
        original_proof_sha256=p['original_proof_sha256'],circuit_sha256=c['circuit_sha256'],
        palette_sha256=c['palette_sha256'],ribbon_sha256=r['ribbon_sha256'],
        raw_rule_counts=raw['rule_counts'],native_rule_counts=native['rule_counts'],
        artifacts=record['artifacts'],pipeline_seconds=record['pipeline_seconds'])

def main():
    started=time.perf_counter()
    try:
        protocols=[];base_maps=[]
        for phase in ('qualification','arithmetic','counterchecks'):
            name='data/'+phase+'-protocol-v1.json';protocol=checked(ref(name))
            for path,value in protocol['pins'].items():assert equal(pin(safe(ROOT,path)),value),path
            runtime=protocol['python'];assert equal(pin(Path(runtime['path'])),{k:runtime[k] for k in ('bytes','sha256')})
            if phase!='counterchecks':base_maps.append(protocol['pins'])
            protocols.append(dict(phase=phase,reference=ref(name),source_pin_count=len(protocol['pins']),runtime=runtime))
        assert equal(base_maps[0],base_maps[1])
        master=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md')
        assert equal(pin(master),pin(ROOT/'reference/basic-tiling-algorithm.md'))
        observers=[];costs={}
        for phase in ('qualification','arithmetic','counterchecks'):
            obs=checked(ref('review/observer-'+phase+'-v1.json'))
            assert obs['status']=='TERMINAL' and obs['native_exit']==0 and obs['guard'] is None
            monitor='review/supervise_counterchecks_v1.py' if phase=='counterchecks' else 'review/supervise_join_v1.py'
            assert obs['source_sha256']==pin(ROOT/monitor)['sha256']
            observers.append(dict(phase=phase,seconds=obs['seconds'],native_exit=0,guard=None,
                sampled_peak_rss_bytes=obs['sampled_peak_rss_bytes'],observation_failures=len(obs['observation_failures'])))
        for phase in ('qualification','arithmetic','counterchecks'):
            invocation=checked(ref('review/'+phase+'-invocation-v1.json'));assert invocation['status']=='COMPLETE'
            costs[phase]=invocation
        snapshot=checked(ref('review/input-snapshot-v1.json'));assert snapshot['status']=='COPIED_EXACT_PRIOR_ACTUAL_SEARCH_OUTPUT'
        for entry in snapshot['files']:
            assert equal(pin(safe(ROOT,entry['path'])),{k:entry[k] for k in ('bytes','sha256')})
            REFERENCES.append(dict(root=str(ROOT),**entry))
        original=read('input/arithmetic-prepared.json.gz');prior_raw=read('input/arithmetic-search-raw.json.gz')
        prior_native=read('input/arithmetic-native-check.json');prior_graph=read('input/arithmetic-graph-check.json')
        assert prior_raw['result']['status']=='SAT' and prior_native['status']==prior_graph['status']=='VERIFIED'
        assert sha(prior_raw['model'])==prior_graph['model_sha256'] and sha(original['lanes']['MARKS']['universe'])==prior_graph['universe_sha256']
        assert sorted(prior_raw['result']['selected'])==prior_native['decoded']['tree']['selected']
        # Bind copied scientific inputs back to the exact already-published
        # physical archive entries, without replaying the historical run.
        old_manifest_name='package/family-transfer-evidence-manifest-v1.json'
        old_manifest=checked(ref(old_manifest_name,PRIOR),PRIOR)
        old_prepared=checked(ref('publication/prepared-v1.json',PRIOR),PRIOR);assert old_prepared['commit']==PUBLIC_COMMIT
        archive_snapshot=snapshot_copy(PRIOR/old_manifest_name,'review/prior-public-archive-manifest-v1.json')
        publication_snapshot=snapshot_copy(PRIOR/'publication/prepared-v1.json','review/prior-publication-prepared-v1.json')
        old_files={e['path']:e for e in old_manifest['files']}
        mapping={'input/arithmetic-prepared.json.gz':'data/prepared/pft-arithmetic-r0-h4-v1.json.gz',
            'input/arithmetic-search-raw.json.gz':'data/runs/pft-arithmetic-r0-h4-v1--MARKS-raw.json.gz',
            'input/arithmetic-native-check.json':'data/runs/pft-arithmetic-r0-h4-v1--MARKS-native-check.json',
            'input/arithmetic-graph-check.json':'data/runs/pft-arithmetic-r0-h4-v1--MARKS-graph-check.json'}
        provenance_files=[]
        for current,old in mapping.items():
            entry=old_files[old];assert equal(pin(ROOT/current),{k:entry[k] for k in ('bytes','sha256')})
            provenance_files.append(dict(input=current,archived_original=old,part=entry['part'],bytes=entry['bytes'],sha256=entry['sha256']))
        for part in old_manifest['parts']:assert equal(pin(PRIOR/'package'/part['name']),{k:part[k] for k in ('bytes','sha256')})
        qualification=checked(ref('data/qualification-results-v1.json'));assert qualification['status']=='VERIFIED_BACKEND_QUALIFICATION'
        qobjects,qsummary=join_record(qualification['baseline'])
        table=checked(qualification['truth_table']);trials=table['assignments']
        assert len(trials)==qualification['assignments']==1024 and len(table['free_indices'])==10
        assert [t['mask'] for t in trials]==list(range(1024))
        assert sum(t['circuit_acceptance_bit'] for t in trials)==table['accepted']==qualification['accepted']==16
        for t in trials:
            assert t['raw_check']['status'] in ('VERIFIED','REJECTED') and t['circuit_acceptance_bit']==int(t['raw_check']['status']=='VERIFIED')
            assert t['raw_check'].get('certificate_sha256',sha(t['raw_certificate']))==sha(t['raw_certificate'])
            if t['circuit_acceptance_bit']:assert t['decoder_status']=='VERIFIED'
        for control in qualification['codec_controls']:
            checked(control['input']);assert checked(control['check'])['status']=='REJECTED'
        assert qualification['resource_refusal']['status']=='UNKNOWN'
        checked(qualification['ribbon_mutant']['input']);mutant=checked(qualification['ribbon_mutant']['check'])
        assert all(x['status']=='REJECTED' for x in mutant.values())
        arithmetic=checked(ref('data/arithmetic-results-v1.json'));assert arithmetic['status']=='VERIFIED_COMPRESSED_BACKEND_JOIN'
        aobjects,asummary=join_record(arithmetic['record']);p=aobjects['prepare'];e=aobjects['encode'];backend=aobjects['compile']
        assert p['original_compiled_sha256']==sha(original['compiled']) and equal(p['proof'],prior_native['decoded']['proof'])
        assert equal(p['original_statement'],dict(theory=original['compiled']['theory'],goal=original['compiled']['goal']))
        assert len(p['proof'])==12 and asummary['metrics']['literal_status']=='UNKNOWN'
        assert asummary['metrics']['nand_gates']==492792 and asummary['metrics']['input_bits']==1618 and asummary['metrics']['nominal_tile_instances']==243641292720
        reader=arithmetic['original_proof_reader'];assert len(reader)==12
        for i,(line,view) in enumerate(zip(p['proof'],reader)):
            assert view['line']==i+1 and equal(view['formula'],line['formula']) and view['rule']==line['rule']
            refs=[line['antecedent']+1,line['implication']+1] if line['rule']=='mp' else [line['source']+1] if line['rule']=='generalize' else []
            assert view['dependencies']==refs and all(0<r<=i for r in refs)
        counters=checked(ref('data/counterchecks-results-v1.json'));assert counters['status']=='VERIFIED_POST_POSITIVE_COUNTERCHECKS' and counters['sources_runtime_master_unchanged'] is True
        expected={'actual-ui-root-active-omitted':dict(raw='REJECTED',decoder='VERIFIED',native='VERIFIED',circuit=0),
            'actual-mp-future-reference':dict(raw='REJECTED',decoder='VERIFIED',native='REJECTED',circuit=0),
            'actual-unlisted-rule11':dict(raw='REJECTED',decoder='REJECTED',native='NOT_APPLICABLE',circuit=0),
            'extra-known-proof-pin':dict(raw='VERIFIED',decoder='REJECTED',native='NOT_APPLICABLE',circuit=1)}
        assert len(counters['records'])==4 and {x['id'] for x in counters['records']}==set(expected)
        for record in counters['records']:
            assert record['status']=='VERIFIED' and equal(record['actual'],expected[record['id']]) and equal(record['expected'],expected[record['id']])
            packet=checked(record['input']);rc=checked(record['raw_check']);dc=checked(record['inverse_check']);nc=checked(record['native_check']);ev=checked(record['circuit_evaluation'])
            assert rc['status']==record['actual']['raw'] and dc['status']==record['actual']['decoder'] and nc['status']==record['actual']['native']
            assert ev['acceptance_bit']==record['actual']['circuit'] and ev['circuit_sha256']==backend['circuit_sha256']==packet['original_circuit_sha256']
            assert sha(packet['input_bits'])==ev['input_bits_sha256'] and sha(ev['gate_bits'])==ev['gate_bits_sha256'] and len(ev['gate_bits'])==asummary['metrics']['nand_gates']
            if dc['status']=='VERIFIED':assert equal(dc['raw_certificate'],packet['raw_certificate'])
        limitations=[
            'This is an end-to-end verification join of a previously automatically searched 12-line arithmetic proof, not new proof search or primitive Wang-grid search.',
            'The fixed 100-type palette instance uses interior operation pins. Its 243641292720 tile instances are nominal compressed coverage; symbolic expanded_cells is 0 and literal verification remains UNKNOWN.',
            'The inverse certifies codec/common-statement binding only. Separate raw and named logical kernels are necessary; the UI-map countercheck makes this distinction visible.',
            'Qualification exhausts 1024 free assignments for one tiny fully pinned syntax case and verifies its 14300-cell literal grid. It is not a complete compiler-equivalence theorem.',
            'No new geometry proof, complete PA/Hilbert formalization, unrestricted first-order completeness of capped implementations, universal practical palette search, RL/ATP advantage or plane tiling follows.',
            'This assembly recomputes saved byte/content hashes, structural/census and line/provenance joins. It does not replay semantic kernels, decoder, NAND truth or tile matching predicates.']
        qsummary.update(assignments=1024,accepted_assignments=16,codec_controls_rejected=len(qualification['codec_controls']),ribbon_corruptions_rejected=len(mutant),resource_refusal='UNKNOWN')
        summary=dict(schema='BJ-saved-backend-join-summary-v1',status='VERIFIED_ARITHMETIC_COMPRESSED_BACKEND_JOIN',
            qualification=qsummary,arithmetic=asummary,counterchecks=dict(status=counters['status'],records=counters['records'],post_positive=True),
            costs=dict(invocations=costs,observers=observers,scope='Invocation timers include inline checking and preceding persistence. Nested compile/encode/ribbon/pipeline subtotals are not additive. Prior proof search/acquisition/publication are reused costs, not measured again.'),
            provenance=dict(source_public_commit=PUBLIC_COMMIT,input_snapshot=ref('review/input-snapshot-v1.json'),
                original_compiled_sha256=p['original_compiled_sha256'],prior_archive_manifest=archive_snapshot,
                prior_publication_prepared=publication_snapshot,prior_source_root=str(PRIOR),
                prior_archive_volumes=[dict(**part,url='https://liuyao12.github.io/geometric-tree-search/docs/research/gcts-rl-renewal/conditional-inventory/'+part['name']) for part in old_manifest['parts']],original_copies=provenance_files),
            protocols=protocols,current_master=dict(path=str(master),**pin(master)),limitations=limitations,program_goal_status='ACTIVE')
        summary_ref=save('data/report-summary-v1.json',summary)
        save('review/saved-data-audit-v1.json',dict(schema='BJ-passive-saved-data-audit-v1',status='PASS_SAVED_BACKEND_JOIN_AUDIT',
            summary=summary_ref,referenced_files=REFERENCES,protocols=protocols,assembly_source=ref('review/assemble_backend_results_v2.py'),
            checks=dict(actual12lines_preserved=True,raw_named_codec_circuit_ribbon_bindings=True,source_runtime_master_current=True,
                exact_prior_public_archive_input_bindings=True,qualification_assignments=1024,actual_post_positive_controls=4,literal_arithmetic_status='UNKNOWN'),
            scope='Passive standard-library JSON/gzip/hash/structural/census association only; no scientific Source import or semantic replay.'))
        print(json.dumps(dict(status=summary['status'],arithmetic=asummary['metrics'],qualification_assignments=1024,counterchecks=4)),flush=True)
    finally:
        save('review/assembly-invocation-v2.json',dict(status='FAILED' if sys.exc_info()[0] else 'COMPLETE',
            main_seconds=time.perf_counter()-started,platform=sys.platform,ru_maxrss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            scope='Passive assembly/hash/read/persistence only; no scientific replay.'))
if __name__=='__main__':main()
