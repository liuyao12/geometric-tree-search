from pathlib import Path
base=Path('/private/tmp/gcts-indexed-first-order-search-20261028-v1/root/indexed_first_order_study_once_v2.py');s=base.read_text()
s=s.replace('Closed V worker and owned observer.','Closed W scalable worker and owned observer.')
s=s.replace("ROOT = Path('/private/tmp/gcts-indexed-first-order-search-20261028-v1')","ROOT = Path('/private/tmp/gcts-scalable-proof-search-20261028-v1')")
s=s.replace("'tree_machine', 'codec', 'carrier', 'fol_checker', 'real_parser'}","'tree_machine', 'codec', 'carrier', 'fol_checker', 'real_parser', 'vengine'}")
s=s.replace('V-indexed-first-order-proof-once-','W-scalable-first-order-proof-once-')
s=s.replace('V-indexed-first-order-proof-search-study-v1','W-scalable-first-order-proof-search-study-v1')
s=s.replace('V-owned-indexed-observer-result-v1','W-owned-scalable-first-order-observer-result-v1')
s=s.replace("types.ModuleType('V_' + role)","types.ModuleType('W_' + role)")
s=s.replace("'worker_seconds': 210, 'observer_seconds': 240","'worker_seconds': 360, 'observer_seconds': 390")
s=s.replace("'file_bytes': 33554432","'file_bytes': 67108864")
s=s.replace("started < 210, 'whole worker", "started < 360, 'whole worker")
s=s.replace("len(raw) <= 33554432, 'full artifact raw cap'","len(raw) <= 67108864, 'full artifact raw cap'")
s=s.replace("len(stored) <= 33554432 and total_bytes", "len(stored) <= 67108864 and total_bytes")
s=s.replace('started >= 240:', 'started >= 390:')
s=s.replace("read_ref(terminal['result']['stored'], 33554432)","read_ref(terminal['result']['stored'], 67108864)")
s=s.replace("len(raw) <= 33554432 and total <=", "len(raw) <= 67108864 and total <=")
s=s.replace('with240s sampled deadline','with390s sampled deadline')
insert='''

def proof_ancestry(proof, axioms, budget):
    """Goal-dependent axiom names, from actual checked proof references only."""
    require(type(proof) is list and proof, 'checked whole proof for ancestry')
    seen, names, pending = set(), set(), [len(proof) - 1]
    while pending:
        budget()
        index = pending.pop()
        if index in seen: continue
        require(type(index) is int and 0 <= index < len(proof), 'ancestry line')
        seen.add(index); line = proof[index]; rule = line['rule']
        if rule == 'axiom':
            require(type(line['name']) is str and line['name'] in axioms, 'ancestry theory axiom')
            names.add(line['name'])
        elif rule in ('mp', 'generalize'):
            fields = ('antecedent', 'implication') if rule == 'mp' else ('source',)
            for field in fields:
                source = line[field]
                require(type(source) is int and 0 <= source < index, 'ancestry strict prior')
                pending.append(source)
        else:
            require(rule in ('tautology', 'refl', 'instantiate', 'distribute', 'eq_subst'),
                    'ancestry eight rules')
    return {'last_line': len(proof) - 1, 'reachable_lines': sorted(seen),
            'axiom_names': sorted(names), 'used_axiom_count': len(names)}
'''
s=s.replace('\n\ndef worker(plan_path):',insert+'\n\ndef worker(plan_path):')
s=s.replace("    bridge_qualification = json.loads(metadata['bridge_result'])", """    expected_qualification_checks = design['expected_qualification_checks']
    require(type(expected_qualification_checks) is int and 0 <= expected_qualification_checks <= 128,
            'prospective native qualification census')
    bridge_qualification = json.loads(metadata['bridge_result'])""")
s=s.replace("                'check': checked_proof(identity, lane, data['problem'], proof)})", """                'check': checked_proof(identity, lane, data['problem'], proof),
                'goal_ancestry': proof_ancestry(proof, data['problem']['theory']['axioms'], budget)})""")
s=s.replace("                         modules['engine'], modules['explicit'], modules['independent'],", "                         modules['engine'], modules['vengine'], modules['explicit'], modules['independent'],")
s=s.replace("len(qualification_checks) == 25,", "len(qualification_checks) == expected_qualification_checks,")
s=s.replace("               'build_costs': built['costs'],", "               'build_costs': built['costs'], 'build_optimization': built['optimization'],")
s=s.replace("                 'proof': None, 'check': None, 'tiles': [], 'selection_audit_seconds': 0}","                 'proof': None, 'check': None, 'goal_ancestry': None,\n                 'tiles': [], 'selection_audit_seconds': 0}")
s=s.replace("            point['check'] = checked_proof(name, 'point', problem, decoded['proof'])", """            point['check'] = checked_proof(name, 'point', problem, decoded['proof'])
            point['goal_ancestry'] = proof_ancestry(decoded['proof'], problem['theory']['axioms'], budget)""")
s=s.replace("                           'costs': control['costs'], 'check': None}", "                           'costs': control['costs'], 'check': None, 'goal_ancestry': None}")
s=s.replace("            control_summary['check'] = checked_proof(name, 'control', problem, control['proof'])", """            control_summary['check'] = checked_proof(name, 'control', problem, control['proof'])
            control_summary['goal_ancestry'] = proof_ancestry(control['proof'], problem['theory']['axioms'], budget)""")
s=s.replace("'logical catalogue, compressed exact indexed point graph and shared-fact '","'logical catalogue with bounded LRU/scratch compiler, aggregate exact indexed point graph and shared-fact '")
s=s.replace("'U projection and explicit domains/every observed transition. Main graph '","'V/U projection, old V engine, explicit domains/every observed transition. Main graph '")
s=s.replace("'counters differ by implementation and cannot establish speed ratios.'}", """'counters differ by implementation and cannot establish speed ratios. Automatic '
                       'goal ancestry reports only actual dependency-reachable axiom names; '
                       'no teacher path or minimum-proof assertion is supplied.'}""")
out=Path('/private/tmp/gcts-scalable-proof-search-20261028-v1/root/scalable_first_order_study_once_v1.py');out.write_text(s)
