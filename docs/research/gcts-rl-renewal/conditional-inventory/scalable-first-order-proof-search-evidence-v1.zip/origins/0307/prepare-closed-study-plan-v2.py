from pathlib import Path
import json,hashlib,re,ast,os
W=Path('/private/tmp/gcts-scalable-proof-search-20261028-v1');R=W/'root'
def ref(p):
 p=Path(p);assert p.is_absolute() and p.is_file() and not p.is_symlink();b=p.read_bytes()
 return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def native(x):
 if x is None or type(x) in (str,bool,int):return
 if type(x) is float:
  import math
  assert math.isfinite(x);return
 if type(x) is list:
  for v in x:native(v)
  return
 assert type(x) is dict and all(type(k) is str for k in x)
 for v in x.values():native(v)
def read(p):
 d=json.loads(Path(p).read_bytes());native(d);return d
def check(r):
 assert type(r) is dict and set(r)=={'path','bytes','sha256'} and type(r['path']) is str and type(r['bytes']) is int and r['bytes']>=0
 assert type(r['sha256']) is str and re.fullmatch('[a-f0-9]{64}',r['sha256']) and ref(r['path'])==r
 return Path(r['path']).read_bytes()
def put(p,d):
 b=(json.dumps(d,sort_keys=True,ensure_ascii=True,indent=2,allow_nan=False)+'\n').encode()
 with p.open('xb') as f:f.write(b);f.flush();os.fsync(f.fileno())
 assert p.read_bytes()==b;return ref(p)
p=read(R/'study-once-plan-001.json')
qh=read(W/'implementation-L/W-independent-aggregate-graph-qualification-complete-inert-handoff-v2.json')
qb=qh['Source'];wb=ref(R/'scalable_first_order_study_once_v2.py')
assert qb['sha256']=='2966eb148b5e638a1f7486c21c92dda5f0477cc0f6d247787fab266f5871fb01'
assert wb['sha256']=='a68d336968ecaefd1d221b259d7289c590d3a8556b32af53c6790ca6a9ecde9c'
old=check(p['sources']['runner']);assert check(wb)==old.replace(b"ROOT / 'actual' / 'study-001'",b"ROOT / 'actual' / 'study-002'")
oldq=check(p['sources']['graph_audit']);newq=check(qb)
expected=oldq.replace(b"VERSION = 'W-INDEPENDENT-AGGREGATE-GRAPH-QUALIFICATION-v1'",b"VERSION = 'W-INDEPENDENT-AGGREGATE-GRAPH-QUALIFICATION-v2'").replace(b"'markings': [['out:' + str(q), graph['model']['colors'][values[q]], refs[q]] for q in range(n)]",b"'markings': [['out:' + str(q), graph['model']['colors'][values[q]], refs[q]] for q in sorted(range(n), key=lambda q: 'out:' + str(q))]")
assert expected==newq
for b in (old,newq,check(wb)):ast.parse(b)
p['sources'].update(runner=wb,graph_audit=qb);p['actual_dir']=str(W/'actual/study-002')
m=p['metadata'];m['prior_Root_adoption']=m.pop('Root_adoption');m['prior_caller_ABI']=m['caller_ABI'];m['prior_qualifier_ABI']=m['qualifier_ABI']
newmeta={
 'caller_ABI':R/'W-owned-worker-observer-complete-effective-ABI-v2.json',
 'caller_Source2_peer':W/'implementation-C/W-owned-worker2-complete-inherited-independent-Source-peer-v1.json',
 'caller_qualifier2_join':W/'implementation-C/W-worker2-qualifier2-current-public-caller-join-v1.json',
 'qualifier_ABI':Path(qh['API']['path']),
 'qualifier_Source2_peer':Path('/private/tmp/gcts-B-W-independent-graph-peer-v1/W-qualifier-Source2-focused-complete-independent-peer-v1.json'),
 'qualifier_correction':Path(qh['correction_inverse']['path']),
 'failed001_observer':W/'actual/study-001/observer-result.json',
 'failed001_outer':R/'study-001-outer-exit.json',
 'failed001_peer':Path('/private/tmp/gcts-B-W-study001-saved-review-v1/W-study001-complete-independent-saved-failure-review-v1.json')}
for k,path in newmeta.items():m[k]=ref(path)
for k in ('caller_Source2_peer','caller_qualifier2_join','qualifier_Source2_peer'):
 d=read(m[k]['path']);assert d.get('blockers',d.get('material_blockers',[]))==[]
 assert any('PASS' in str(d.get(a,'')) for a in ('decision','status','disposition'))
assert read(m['failed001_observer']['path'])['status']=='UNADMITTED'
assert read(m['design']['path'])['expected_qualification_checks']==37
assert read(m['experiment_limits']['path'])==read(m['caps_prefreeze']['path'])['experiment_limits_exact8']
assert p['limits']==read(m['caps_prefreeze']['path'])['process_limits_exact7']
assert not Path(p['actual_dir']).exists()
for rr in [*p['sources'].values(),*m.values(),p['python'],p['bootstrap']]:check(rr)
adoption=put(R/'Root-complete-Source-adoption-v2.json',{
 'schema':'W-Root-complete-Source-adoption-v2','status':'ADOPTED_FOR_FRESH_STUDY002_ONLY','sources':p['sources'],'reviewed_metadata':m,
 'intake':'Full predecessor Source/API/complete peers inherited by exact raw association. Root current full qualifier2API10029/correction3311/complete1098patch and worker2API8973/one literal inverse read; exact two qualifier changes and one worker literal rederived. Current independent qualifier2 and worker2 Source peers plus final public ABI join read. All Sources/metadata/runtime/bootstrap fully authenticated before grant; no current qualifier2 or worker2 body has executed.',
 'failure':'Study001 authority permanently spent, originals retained unadmitted. Source defect was only expected nonindexed certificate marking array string order; no inference or main outcome promoted from failed prefix. All26 controls/37primary proofs and same8main inputs/profile/slots/caps must run fresh. No theorem proof/teacher/old answer supplied.',
 'scope':'Same finite anchored unit/root0 exact aggregate graph adaptation and actual C1+B checker contract. Complete graph counts and all native reference identities preserved. No new RL or unconditional completeness/speed/superiority claim.'})
m['Root_adoption']=adoption
native(p);assert set(p)=={'schema','sources','metadata','python','bootstrap','actual_dir','limits'} and len(p['sources'])==13
pr=put(R/'study-once-plan-002.json',p)
auth={'schema':'W-scalable-first-order-proof-once-authority-v1','uses':1,'authorized':True,'plan':pr,'runner':wb,'python':p['python']}
for f in ('study-once-authority-002.json','study-once-authority-002.json.CONSUMED.json','study-002-outer-stdout.bin','study-002-outer-stderr.bin','study-002-outer-exit.json'):assert not (R/f).exists()
ar=put(R/'study-once-authority-002.json',auth)
print(json.dumps({'status':'FRESH_CLOSED_STUDY002_ONCE_GRANTED','plan':pr,'authority':ar,'adoption':adoption,'sources':len(p['sources']),'metadata':len(m),'main_outcome_inputs':False}))
