from pathlib import Path
import json,hashlib
W=Path('/private/tmp/gcts-scalable-proof-search-20261028-v1');R=W/'root'
def ref(p):
 p=Path(p);assert p.is_file() and not p.is_symlink();b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def put(p,x):
 b=(json.dumps(x,sort_keys=True,indent=2)+'\n').encode();p.open('xb').write(b);assert p.read_bytes()==b;return ref(p)
paths={str(p) for p in W.rglob('*') if p.is_file()}
for name in ('study-once-plan-001.json','study-once-plan-002.json'):
 p=json.loads((R/name).read_bytes())
 for r in [*p['sources'].values(),*p['metadata'].values(),p['bootstrap']]:
  assert ref(r['path'])==r;paths.add(r['path'])
extra=[
 '/private/tmp/gcts-B-W-independent-graph-peer-v1/W-independent-aggregate-graph-complete-Source-peer-review-v1.json',
 '/private/tmp/gcts-B-W-independent-graph-peer-v1/W-independent-aggregate-graph-complete-peer-support-v1.json',
 '/private/tmp/gcts-B-W-independent-graph-peer-v1/W-independent-graph-prefrozen-peer-expectations-v1.json',
 '/private/tmp/gcts-B-W-independent-graph-peer-v1/W-qualifier-Source2-focused-complete-independent-peer-v1.json',
 '/private/tmp/gcts-B-W-independent-graph-peer-v1/W-qualifier-Source2-focused-complete-peer-support-v1.json',
 '/private/tmp/gcts-B-W-study001-saved-review-v1/W-study001-complete-independent-saved-failure-review-v1.json',
 '/private/tmp/gcts-B-W-study001-saved-review-v1/W-study001-complete-saved-failure-support-v1.json',
 '/private/tmp/gcts-B-W-study001-saved-review-v1/W-study001-prefrozen-whole-saved-review-expectations-v1.json',
 '/private/tmp/gcts-B-W-publication-Source-peer-v1/W-publication-publisher2-TLS1-complete-independent-Source-peer-v1.json',
 '/private/tmp/gcts-B-W-publication-Source-peer-v1/W-publication-publisher2-TLS1-complete-Source-peer-support-v1.json',
 '/private/tmp/gcts-B-W-study002-saved-review-v1/W-study002-complete-independent-saved-cohort-review-v1.json',
 '/private/tmp/gcts-B-W-study002-saved-review-v1/W-study002-complete-passive-saved-support-v1.json']
paths.update(extra)
files=[ref(p) for p in sorted(paths)]
plan={'schema':'W-full-evidence-archive-plan-v1','files':files,'science_admission':ref(R/'Root-study002-complete-scientific-admission-v1.json'),'runtime_excluded':json.loads((R/'study-once-plan-002.json').read_bytes())['python'],'source':ref(R/'package_saved_evidence_v1.py')}
assert plan['runtime_excluded']['path'] not in paths
for n,count in [('study-001',61),('study-002',128)]:assert len([p for p in paths if Path(p).parent==W/'actual'/n])==count
assert sum(r['bytes'] for r in files)<268435456
print(json.dumps({'plan':put(R/'evidence-archive-plan-v1.json',plan),'files':len(files),'bytes':sum(r['bytes'] for r in files)}))
