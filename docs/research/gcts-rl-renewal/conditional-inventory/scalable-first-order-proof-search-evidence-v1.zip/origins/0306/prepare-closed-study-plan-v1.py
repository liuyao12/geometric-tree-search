import json, hashlib, re, ast, os
from pathlib import Path
W=Path('/private/tmp/gcts-scalable-proof-search-20261028-v1'); R=W/'root'
V=Path('/private/tmp/gcts-indexed-first-order-search-20261028-v1')
def raw(x):return (json.dumps(x,sort_keys=True,ensure_ascii=True,indent=2,allow_nan=False)+'\n').encode('ascii')
def native(x):
 if x is None or type(x) in (str,bool,int):return
 if type(x) is float:
  import math
  assert math.isfinite(x);return
 if type(x) is list:
  for v in x:native(v)
  return
 assert type(x) is dict and all(type(k) is str for k in x)
 for v in x.values():native(v)
def ref(p):
 p=Path(p);assert p.is_absolute() and p.is_file() and not p.is_symlink()
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def check(r):
 assert type(r) is dict and set(r)=={'path','bytes','sha256'}
 assert type(r['path']) is str and type(r['bytes']) is int and r['bytes']>=0
 assert type(r['sha256']) is str and re.fullmatch('[a-f0-9]{64}',r['sha256'])
 assert ref(r['path'])==r
 return Path(r['path']).read_bytes()
def read(p):
 d=json.loads(Path(p).read_bytes());native(d);return d
def put(p,d):
 b=raw(d)
 with p.open('xb') as f:f.write(b);f.flush();os.fsync(f.fileno())
 assert p.read_bytes()==b;return ref(p)
old=read(V/'root/study-once-plan-001.json')
caps=read(R/'W-owned-study-prospective-input-and-caps-ABI-v1.json')
limits=put(R/'prospective-study-limits-v1.json',caps['experiment_limits_exact8'])
design=read(V/'root/prospective-design-v1.json')
design['expected_qualification_checks']=37
design['lanes']=['complete aggregate point graph','same-basis bounded shared-fact backward DAG']
design['reuse']='Same eight U/V assertion-only inputs, uniform UI1/bridge1/atoms12 and row bounds. W prospectively enlarges compiler20s/1bwork/50kformula/10kwitness/500kintern/200kcache, reclaims memo/scratch, and aggregates full virtual candidate degrees. Main point2s/control2s unchanged. No proof/old result/teacher path supplied. Work units and changed caps prevent causal V speed ratios. No RL.'
designref=put(R/'prospective-design-v1.json',design)
ch=read(W/'implementation-B/W-scalable-compiler-complete-inert-Source-handoff-v1.json')
qh=read(W/'implementation-L/W-independent-aggregate-graph-qualification-complete-inert-handoff-v1.json')
wh=read(R/'W-owned-worker-observer-complete-inert-Source-handoff-v1.json')
ea=read(R/'W-aggregate-engine-complete-public-ABI-v1.json')
sources=dict(old['sources']);sources.update(runner=wh['Source'],compiler=ch['Source'],engine=ea['Source'],graph_audit=qh['Source'],independent=qh['core'],reference=old['sources']['compiler'],vengine=old['sources']['engine'])
assert len(sources)==13
for role,r in sources.items():
 b=check(r)
 if role!='real_parser':ast.parse(b)
assert sources['compiler']['sha256']=='6476d6f063b255c8c0d6bcb5cd3a1b3e5bf0f826c0481936f238dd4a76f863fa'
assert sources['engine']['sha256']=='cc2ae5550730fa9c90acc9b8c5657c86da97e9128877f981bf209e87124beb81'
assert sources['graph_audit']['sha256']=='04139b95a89dba7e7ccdb42c3ffca9a0d0ab6e5378c89a2f927cf6346ab54fa2'
assert sources['runner']['sha256']=='93b402c0e9ac21c6cfb5beccc8d511a82168d4a240fdb594da6ca63ab36b765f'
metadata={k:old['metadata'][k] for k in ('bridge_admission','bridge_observer','bridge_peer','bridge_result','cases','calibrations','profile','native_recipe','independent_ABI','independent_source_peer')}
metadata.update(experiment_limits=limits,design=designref,master=ref('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md'))
assert metadata['master']['sha256']=='c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9'
files={
 'caller_ABI':R/'W-owned-worker-observer-complete-effective-ABI-v1.json',
 'caller_source_peer':W/'implementation-C/W-owned-worker-observer-complete-independent-Source-peer-v1.json',
 'caller_final_ABI_join':W/'implementation-C/W-owned-worker-observer-final-public-ABI-join-v1.json',
 'compiler_ABI':W/'implementation-B/W-scalable-Hilbert8-compiler-complete-public-ABI-v1.json',
 'compiler_full_ABI':W/'implementation-B/W-scalable-Hilbert8-compiler-prefrozen-public-ABI-v1.json',
 'compiler_source_peer':W/'implementation-C/W-scalable-compiler-complete-independent-Source-peer-v1.json',
 'compiler_equivalence':W/'implementation-B/W-scalable-compiler-complete-walk-and-equivalence-v1.json',
 'engine_ABI':R/'W-aggregate-engine-complete-public-ABI-v1.json',
 'engine_source_peer':W/'implementation-C/W-aggregate-engine-complete-independent-Source-peer-v1.json',
 'engine_literal_supplement':R/'W-aggregate-graph-literal-descriptor-supplement-v1.json',
 'qualifier_ABI':W/'implementation-L/W-independent-aggregate-graph-qualification-complete-public-ABI-v1.json',
 'qualifier_source_peer':Path('/private/tmp/gcts-B-W-independent-graph-peer-v1/W-independent-aggregate-graph-complete-Source-peer-review-v1.json'),
 'independent_reuse_ABI':W/'implementation-L/W-independent-core-reuse-complete-public-ABI-v1.json',
 'reference_ABI':Path(old['metadata']['compiler_ABI']['path']),
 'vengine_ABI':Path(old['metadata']['engine_ABI']['path']),
 'caps_prefreeze':R/'W-owned-study-prospective-input-and-caps-ABI-v1.json'}
for k,p in files.items():metadata[k]=ref(p)
for k,r in metadata.items():
 d=json.loads(check(r)) if k!='master' else None
 if d is not None:native(d)
for k in ('compiler_source_peer','engine_source_peer','caller_source_peer','caller_final_ABI_join','qualifier_source_peer'):
 d=read(metadata[k]['path'])
 for name in ('blockers','material_blockers','material_Source_blockers'):
  if name in d:assert d[name]==[]
 assert any('PASS' in str(d.get(a,'')) for a in ('decision','status','disposition'))
# Exact old assertion-only cohort is preserved, and contains no proof fields.
cases=read(metadata['cases']['path']);calibs=read(metadata['calibrations']['path']);profile=read(metadata['profile']['path'])
assert len(cases)==6 and len(calibs)==2 and set(cases)|set(calibs)==set(design['order'])
assert profile=={'ui_rounds':1,'bridge_arity':1,'max_tautology_atoms':12}
for row in list(cases.values())+list(calibs.values()):assert set(row)=={'theory','goal'} and set(row['theory'])=={'functions','predicates','axioms'}
assert design['slots']==read(V/'root/prospective-design-v1.json')['slots']
adopt=put(R/'Root-complete-Source-adoption-v1.json',{
 'schema':'W-Root-complete-Source-adoption-v1','status':'ADOPTED_FOR_FRESH_BOUNDED_ONCE_ONLY',
 'sources':sources,'reviewed_metadata':metadata,
 'complete_intake':'Root full current qualifier974 lines/worker595 lines and public APIs, all current independent complete Source peers including final L/caller ABI join; full W compiler changed bodies and exact inverse/preserved42unit predecessor proof; full aggregate engine authored/read with complete independent peer. Reused core/native/explicit/V references exact-byte inherited full previous intake, all Sources rehashed now. No current module/fixture/compiler/solver/checker/VM has run.',
 'contract':'Current master exact bytes. Finite anchored unit proof row/root-generation0 adaptation: complete virtual candidates/dependencies and exact aggregate counts, global dead/forced then generation ordering, contextual proved exclusions/exact rollback. No growth/fractional/fullFOL/PA/Hilbert/RL/universal literal Wang or performance advantage claim.',
 'native':'Every actual primary proof receives unchanged actual C1 integer1 and independent B;37 qualification proofs prospectively required, main success unknown. Goal ancestry computed only from verified actual proof dependencies.',
 'input_scope':'Eight unchanged assertion-only inputs/profile/slots, no teacher or previous proof input. Prior20 bridge records admitted administrative compatibility evidence only.',
 'authority':'All prior grants permanently spent. This adoption is not execution; only upcoming fresh exact once authority can permit owned observer+one worker.'})
metadata['Root_adoption']=adopt
plan={'schema':'W-scalable-first-order-proof-once-plan-v1','sources':sources,'metadata':metadata,'python':old['python'],'bootstrap':old['bootstrap'],'actual_dir':str(W/'actual/study-001'),'limits':caps['process_limits_exact7']}
assert not Path(plan['actual_dir']).exists()
for r in [*sources.values(),*metadata.values(),plan['python'],plan['bootstrap']]:check(r)
native(plan);assert len(plan)==7 and type(plan['limits']['worker_seconds']) is int
planref=put(R/'study-once-plan-001.json',plan)
auth={'schema':'W-scalable-first-order-proof-once-authority-v1','uses':1,'authorized':True,'plan':planref,'runner':sources['runner'],'python':plan['python']}
assert not (R/'study-once-authority-001.json.CONSUMED.json').exists()
for f in ('study-001-outer-stdout.bin','study-001-outer-stderr.bin','study-001-outer-exit.json'):assert not (R/f).exists()
authref=put(R/'study-once-authority-001.json',auth)
print(json.dumps({'status':'FRESH_CLOSED_ONCE_GRANTED','plan':planref,'authority':authref,'Root_adoption':adopt,'sources':len(sources),'metadata':len(metadata),'qualification_checks':37,'project_subject_calls':0}))
