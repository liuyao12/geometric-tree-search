"""Package an explicit frozen list of opaque saved files; no scientific execution."""
from pathlib import Path, PurePosixPath
import argparse, hashlib, json, os, zipfile
W=Path('/private/tmp/gcts-scalable-proof-search-20261028-v1')
R=W/'root'
CAP=33554432

def ref(p):
    b=p.read_bytes()
    return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}

def read(r):
    assert type(r) is dict and set(r)=={'path','bytes','sha256'}
    assert type(r['path']) is str and type(r['bytes']) is int and 0<=r['bytes']<=67108864
    assert type(r['sha256']) is str and len(r['sha256'])==64 and all(c in '0123456789abcdef' for c in r['sha256'])
    p=Path(r['path']);assert p.is_absolute() and p.is_file() and not p.is_symlink()
    b=p.read_bytes();assert len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256']
    return b

def put(p,b):
    with p.open('xb') as f:f.write(b);f.flush();os.fsync(f.fileno())
    assert p.read_bytes()==b

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--plan',required=True);ap.add_argument('--output',required=True)
    args=ap.parse_args();pp=Path(args.plan);out=Path(args.output)
    assert pp.parent==R and out.parent==R and pp.is_absolute() and out.is_absolute() and not out.exists() and not out.is_symlink()
    pr=ref(pp);planraw=read(pr);p=json.loads(planraw)
    assert type(p) is dict and set(p)=={'schema','files','science_admission','runtime_excluded','source'}
    assert p['schema']=='W-full-evidence-archive-plan-v1' and type(p['files']) is list and 1<=len(p['files'])<=1000
    assert p['source']['path']==__file__;read(p['source']);read(p['science_admission'])
    assert p['runtime_excluded']['path'] not in [x['path'] for x in p['files']]
    assert p['runtime_excluded']=={'path':'/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12','bytes':18058560,'sha256':'d90bce0f5ac3aa40e2ee5900ad243bad0b2205ce17408278f088b34aed737840'}
    paths=[x['path'] for x in p['files']];assert paths==sorted(set(paths))
    for attempt,count in [('study-001',61),('study-002',128)]:
        directory=W/'actual'/attempt
        actual={str(q) for q in directory.iterdir()};declared={x for x in paths if Path(x).parent==directory}
        assert actual==declared and len(actual)==count
    entries=[];total=0
    for i,r in enumerate(p['files']):
        b=read(r);total+=len(b);assert total<=268435456
        name=Path(r['path']).name;entry='origins/%04d/%s'%(i,name)
        q=PurePosixPath(entry);assert not q.is_absolute() and '..' not in q.parts and '\\' not in entry
        entries.append(dict(r,archive_path=entry))
    manifest={'schema':'W-full-evidence-archive-manifest-v1','files':entries,'original_files':len(entries),'original_bytes':total,'archive_plan':pr,'science_admission':p['science_admission'],'runtime_excluded':p['runtime_excluded'],'scope':'Complete current W189 original actual files (including whole unadmitted001), current Sources/APIs/direct plan metadata/peer reports, input assertions, original outer captures and reader provenance through this prepublication cut. Each original path remains a distinct manifest row even for byte-identical contents. PLAN.json is an exact copy of the packaging input. This is not an infinitely recursive archive of indirect older research history. Later publication/TLS/live UI receipts are retained separately in the durable research run.'}
    mb=(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode()
    rb=b'''GCTS research milestone W: complete prepublication evidence cut\n\nMANIFEST.json maps each complete original absolute path to an archive member,\nits stored byte length and SHA-256. PLAN.json is the exact frozen packaging\ninput. Original .json.gz files remain lossless opaque gzip artifacts; their\nraw JSON hashes/lengths are in the original worker artifact receipts.\n\nStudy001 is wholly UNADMITTED and permanently spent; its 33 prefix checks\nare not pooled with the complete study002. Study002 has 37 qualification\nchecks and six main proof checks, all actual native C1 plus independent B.\nOnly two calibration proofs were found by GCTS; the conventional control\nalso found the 12-line addition and 15-line incidence proofs. This is no\nGCTS advantage or new RL result. Finite catalogue exhaustion is not full\nmathematical unprovability.\n\nSources, raw certificates, byte heaps, logs and local file paths are\nintentionally included under the user's explicit full-archive approval.\nNo credentials or environment dump is needed. The external Python runtime\nbinary is identified by its exact pin rather than redistributed. Direct\ncurrent dependencies are included; references to indirect older history\nare provenance, not a claim to archive that entire history recursively.\nPublication, subsequent normal-TLS and final live-browser evidence occur\nafter this cut and are retained separately in the durable research run.\n\nReview Sources before executing. No scientific code is executed by this\npackager. Original absolute paths describe the recorded environment; the\nmanifest supports relocation and manual inspection.\n'''
    out.mkdir();zp=out/'scalable-first-order-proof-search-evidence-v1.zip'
    with zipfile.ZipFile(zp,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6,allowZip64=False) as z:
        z.writestr('MANIFEST.json',mb);z.writestr('README.txt',rb);z.writestr('PLAN.json',planraw)
        for r in entries:z.writestr(r['archive_path'],read({k:r[k] for k in ('path','bytes','sha256')}))
    assert zp.stat().st_size<=CAP
    with zipfile.ZipFile(zp) as z:
        assert len(z.infolist())==len(entries)+3 and len(set(z.namelist()))==len(entries)+3
        assert z.read('MANIFEST.json')==mb and z.read('README.txt')==rb and z.read('PLAN.json')==planraw
        for r in entries:
            b=z.read(r['archive_path'])
            assert len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256']
    for r in p['files']:read(r)
    assert read(pr)==planraw;read(p['source']);read(p['science_admission'])
    put(out/'ARCHIVE-MANIFEST-v1.json',mb)
    receipt={'schema':'W-full-evidence-archive-readback-v1','status':'ALL_MEMBERS_FULL_BYTES_HASH_CRC_MATCH','archive':ref(zp),'manifest':ref(out/'ARCHIVE-MANIFEST-v1.json'),'plan':pr,'original_files':len(entries),'members':len(entries)+3,'original_bytes':total,'source':p['source']}
    put(out/'archive-readback-v1.json',(json.dumps(receipt,sort_keys=True,indent=2)+'\n').encode())
    print(json.dumps(receipt,sort_keys=True))

if __name__=='__main__':main()
