from pathlib import Path
p=Path('/private/tmp/gcts-indexed-first-order-search-20261028-v1/implementation-B/interned_fol_basis_v2.py')
s=p.read_text()
s=s.replace('"""Losslessly interned U finite Hilbert-eight catalogue, without row expansion.','"""W bounded-LRU compiler of the exact V/U finite Hilbert-eight catalogue.')
s=s.replace('import time\n','import time\nfrom collections import OrderedDict\n')
s=s.replace("VERSION = 'V-INTERNED-FINITE-HILBERT8-v1'","# VERSION is the intentionally unchanged public compiled wire, not Source identity.\nIMPLEMENTATION_VERSION = 'W-SCALABLE-FINITE-HILBERT8-v1'\nVERSION = 'V-INTERNED-FINITE-HILBERT8-v1'")
s=s.replace('        self.canonical_serializations = self.substitution_calls = 0\n','''        self.canonical_serializations = self.substitution_calls = 0
        self.cache_entries = self.cache_peak_entries = self.cache_evictions = 0
        self.interned_nodes = self.peak_interned_nodes = 0
        self.transient_nodes_discarded = self.equality_probes = 0
        self.bridge_tests = self.bridge_rejections = 0
''')
needle='\n\ndef _name(value, meter):'
insert='''
    def optimization(self):
        return {'implementation_version': IMPLEMENTATION_VERSION,
                'cache_capacity': self.limits['max_cache_entries'],
                **{k: getattr(self, k) for k in ('cache_entries', 'cache_peak_entries',
                   'cache_evictions', 'interned_nodes', 'peak_interned_nodes',
                   'transient_nodes_discarded', 'equality_probes',
                   'bridge_tests', 'bridge_rejections')}}
'''
assert needle in s;s=s.replace(needle,'\n'+insert+needle)
s=s.replace('        self.nodes, self.colors, self.depths, self.intern, self.memo = [], [], [], {}, {}','''        self.nodes, self.colors, self.depths, self.intern = [], [], [], {}
        self.memo = OrderedDict()
        self.transient = False''')
s=s.replace('        index = len(self.nodes)\n        self.nodes.append(row);', '''        # Reserve cleanup work before a transient node can be retained.
        if self.transient: self.m.tick()
        index = len(self.nodes)
        self.nodes.append(row);''')
s=s.replace('        self.m.canonical_serializations += 1\n        return index','''        self.m.canonical_serializations += 1
        self.m.interned_nodes = len(self.nodes)
        self.m.peak_interned_nodes = max(self.m.peak_interned_nodes, len(self.nodes))
        return index''')
a=s.index('    def cached(self, key, compute):');b=s.index('    def ordered(self, ids):',a)
s=s[:a]+'''    def cached(self, key, compute):
        self.m.tick()
        if key in self.memo:
            self.m.cache_hits += 1
            self.memo.move_to_end(key)
            return self.memo[key]
        self.m.cache_misses += 1
        result = compute()
        capacity = self.m.limits['max_cache_entries']
        # During a probe, memo keys/values must never capture temporary IDs.
        if self.transient or capacity == 0: return result
        while len(self.memo) >= capacity:
            self.m.tick()
            self.memo.popitem(last=False); self.m.cache_evictions += 1
        self.memo[key] = result
        self.m.cache_entries = len(self.memo)
        self.m.cache_peak_entries = max(self.m.cache_peak_entries, len(self.memo))
        return result

    def equality_pair(self, template, hole, left, right, allowed):
        """Read-only memo, rollback-only scratch nodes; return old allowed IDs."""
        self.m.tick(); self.m.equality_probes += 1
        checkpoint = len(self.nodes)
        self.transient = True
        try:
            a = self.subst(template, hole, left)
            if a not in allowed: return None
            b = self.subst(template, hole, right)
            return (a, b) if b in allowed else None
        finally:
            # Each deletion was reserved before allocation; cleanup cannot Stop.
            for row in reversed(self.nodes[checkpoint:]): del self.intern[row]
            removed = len(self.nodes) - checkpoint
            del self.nodes[checkpoint:]; del self.colors[checkpoint:]; del self.depths[checkpoint:]
            self.m.transient_nodes_discarded += removed
            self.m.interned_nodes = checkpoint
            self.transient = False

'''+s[b:]
a=s.index('    def line_color(self, line):')
s=s[:a]+'''    def bridge_tautology(self, antecedent, goal, maximum, middle=None):
        """Exact truth of a=>g or a=>(b=>g), without a bridge AST/vector."""
        self.m.tick(); self.m.bridge_tests += 1
        parts = [self.atoms(antecedent), self.atoms(goal)]
        if middle is not None: parts.append(self.atoms(middle))
        self.m.tick(sum(len(p) for p in parts))
        atoms = frozenset().union(*parts)
        if len(atoms) > maximum:
            self.m.bridge_rejections += 1
            return False
        atoms = tuple(self.ordered(atoms))
        self.m.tick(max(1, ((1 << len(atoms)) + 63) // 64))
        full = (1 << (1 << len(atoms))) - 1
        value = (self.truth_bits(antecedent, atoms) ^ full) | self.truth_bits(goal, atoms)
        if middle is not None: value |= self.truth_bits(middle, atoms) ^ full
        accepted = value == full
        if not accepted: self.m.bridge_rejections += 1
        return accepted

'''+s[a:]
s=s.replace('''            a, b = pool.subst(template, hole, left), pool.subst(template, hole, right)
            if a in atom_extended and b in atom_extended:
                out = pool.node(('imp', equality, pool.node(('imp', a, b))))''','''            pair = pool.equality_pair(template, hole, left, right, atom_extended)
            if pair is not None:
                a, b = pair
                out = pool.node(('imp', equality, pool.node(('imp', a, b))))''')
s=s.replace("        variable = row[1]; p, q = pool.nodes[row[2]][1:]; all_q = pool.node(('all', variable, q))", "        variable = row[1]; p, q = pool.nodes[row[2]][1:]\n        pool.m.tick(); all_q = pool.intern.get(('all', variable, q))")
s=s.replace('''                bridge = pool.node(('imp', a, g))
                if pool.tautology(bridge, profile['max_tautology_atoms']): _zero({'rule': 'tautology', 'formula': bridge}, zero, formulas, pool)''','''                if pool.bridge_tautology(a, g, profile['max_tautology_atoms']):
                    bridge = pool.node(('imp', a, g))
                    _zero({'rule': 'tautology', 'formula': bridge}, zero, formulas, pool)''')
s=s.replace('''                        bridge2 = pool.node(('imp', a, pool.node(('imp', b, g))))
                        if pool.tautology(bridge2, profile['max_tautology_atoms']): _zero({'rule': 'tautology', 'formula': bridge2}, zero, formulas, pool)''','''                        if pool.bridge_tautology(a, g, profile['max_tautology_atoms'], b):
                            bridge2 = pool.node(('imp', a, pool.node(('imp', b, g))))
                            _zero({'rule': 'tautology', 'formula': bridge2}, zero, formulas, pool)''')
s=s.replace("'status': 'COMPLETE', 'reason': None, 'compiled': compiled, 'costs': costs}","'status': 'COMPLETE', 'reason': None, 'compiled': compiled, 'costs': costs,\n                'optimization': meter.optimization()}")
s=s.replace("'status': 'UNKNOWN', 'reason': str(error), 'compiled': None, 'costs': meter.costs()}","'status': 'UNKNOWN', 'reason': str(error), 'compiled': None, 'costs': meter.costs(),\n                'optimization': meter.optimization()}")
assert "raise _Stop('CACHE_LIMIT')" not in s
out=Path('/private/tmp/gcts-scalable-proof-search-20261028-v1/implementation-B/scalable_fol_basis_v1.py');out.write_text(s)
