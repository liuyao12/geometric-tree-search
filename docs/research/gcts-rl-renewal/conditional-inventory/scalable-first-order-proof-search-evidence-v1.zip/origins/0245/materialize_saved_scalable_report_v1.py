"""Render already admitted W saved JSON only; never run a scientific component.

External Root adoption is required before invocation. No imports or callbacks to
project code, no proof search/checker/VM/codec replay, no archive or publication.
Prior failed attempts are supplied separately and never pooled into current totals.
"""
from pathlib import Path
import argparse
import collections
import gzip
import hashlib
import json

ROOT = Path('/private/tmp/gcts-scalable-proof-search-20261028-v1')
R = ROOT / 'root'
TEMPLATE = Path(__file__).with_name('scalable-first-order-reader-template-v1.html')
LIMIT = 67108864
EXPECTED_PLAN = {'path': str(R / 'study-once-plan-002.json'), 'bytes': 14713, 'sha256': '22dff3a33a9f8fd0bc0308f12695a5dc896790e5cebfb89ad2039589afa324bf'}
EXPECTED_OBSERVER = {'path': str(ROOT / 'actual/study-002/observer-result.json'), 'bytes': 30276, 'sha256': '01eb4b547f540cad2f5ef44e4105676bff335e909bf75babddec8878c91ea3a4'}
EXPECTED_WORKER_STORED = {'path': str(ROOT / 'actual/study-002/worker-result.json.gz'), 'bytes': 23299, 'sha256': 'b32e4f4925e73abbdc357133a6de444a7e4d2ca66a1998dc55862ec7dccecd90'}
EXPECTED_WORKER_RAW = {'bytes': 209832, 'sha256': 'cc952922835e563166c45ed6d717a07a7f7fee738aaad24380e0845c0793e464'}


def load(path):
    """Trusted, previously admitted saved JSON; not a hostile gzip firewall."""
    path = Path(path)
    stored = path.read_bytes()
    assert len(stored) <= LIMIT
    raw = gzip.decompress(stored) if path.suffix == '.gz' else stored
    assert len(raw) <= LIMIT
    return json.loads(raw)


def ref(path):
    path = Path(path)
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def saved(record, actual):
    p = Path(record['stored']['path'])
    assert p.parent == actual and p.is_file() and not p.is_symlink()
    assert ref(p) == record['stored']
    stored = p.read_bytes()
    assert record['encoding'] in ('json', 'gzip-json')
    raw = gzip.decompress(stored) if record['encoding'] == 'gzip-json' else stored
    assert len(raw) == record['raw_bytes'] <= LIMIT
    assert hashlib.sha256(raw).hexdigest() == record['raw_sha256']
    return json.loads(raw)


def materialize(plan_path, admission_path, history_path, output):
    """All arguments are explicit administrative files after Root data adoption."""
    plan_path, admission_path, history_path, output = map(Path, (plan_path, admission_path, history_path, output))
    assert all(p.is_absolute() and p.parent == R for p in (plan_path, admission_path, history_path, output))
    assert admission_path.is_file() and not admission_path.is_symlink()
    assert ref(plan_path) == EXPECTED_PLAN
    plan = load(plan_path)
    assert plan['schema'] == 'W-scalable-first-order-proof-once-plan-v1'
    actual = Path(plan['actual_dir'])
    assert actual == ROOT / 'actual/study-002'
    assert ref(actual / 'observer-result.json') == EXPECTED_OBSERVER
    observer = load(actual / 'observer-result.json')
    assert observer['status'] == 'COMPLETE'
    terminal = observer['worker_terminal']
    assert terminal['status'] == 'COMPLETE'
    assert terminal['plan'] == ref(plan_path)
    assert terminal['result']['stored'] == EXPECTED_WORKER_STORED
    assert terminal['result']['raw_bytes'] == EXPECTED_WORKER_RAW['bytes']
    assert terminal['result']['raw_sha256'] == EXPECTED_WORKER_RAW['sha256']
    w = saved(terminal['result'], actual)
    assert w['status'] == 'COMPLETE' and w['schema'] == 'W-scalable-first-order-proof-search-study-v1'
    design_ref = plan['metadata']['design']
    assert ref(design_ref['path']) == design_ref
    design = load(design_ref['path'])
    history = load(history_path)
    assert set(history) == {'schema', 'attempts'} and history['schema'] == 'W-reader-attempt-history-v1'
    assert type(history['attempts']) is list and history['attempts']
    for attempt in history['attempts']:
        assert set(attempt) == {'id', 'status', 'phase', 'summary', 'evidence'}
        assert all(type(attempt[k]) is str for k in ('id', 'status', 'phase', 'summary'))
        assert attempt['status'] == 'UNADMITTED' and attempt['id'] != actual.name
        assert type(attempt['evidence']) is list and attempt['evidence']
        for evidence in attempt['evidence']:
            p = Path(evidence['path'])
            assert p.is_relative_to(ROOT) and ref(p) == evidence
    assert any(x['id'] == 'study-001' and x['phase'] == 'qualification' for x in history['attempts'])
    artifacts = {x['name']: x for x in w['artifacts']}
    assert len(artifacts) == len(w['artifacts'])

    def artifact(name):
        return saved(artifacts[name], actual)

    cases = []
    for original in w['results']:
        row = json.loads(json.dumps(original))
        row['candidate_count'] = None
        row['graph_counts'] = None
        built = artifact(row['id'] + '-full-build')
        assert built['status'] == row['build_status']
        assert built['optimization'] == row['build_optimization']
        if row['build_status'] == 'COMPLETE':
            point_name = row['id'] + '-point-full-result'
            answer = artifact(point_name)
            row['point_archive_artifact'] = artifacts[point_name]
            row['point_state_hashes'] = answer['state_hashes']
            row['point_model_sha256'] = answer['model_sha256']
            if answer['entry_state'] is not None:
                row['graph_counts'] = {k: answer['stats'][v] for k, v in
                    (('members', 'virtual_members'), ('families', 'families'), ('definitions', 'definitions'))}
        for tile in row['point'].get('tiles', []):
            assert len(tile['t']) == 1
            tile['slot'] = int(tile['t'][0].split(':')[1])
        row['point'].get('tiles', []).sort(key=lambda tile: tile['slot'])
        for lane in (row['point'], row['control']):
            if lane.get('proof'):
                ga = lane['goal_ancestry']
                assert set(ga) == {'last_line', 'reachable_lines', 'axiom_names', 'used_axiom_count', 'seconds'}
                assert ga['last_line'] == len(lane['proof']) - 1
                assert ga['reachable_lines'] == sorted(set(ga['reachable_lines']))
                assert ga['last_line'] in ga['reachable_lines']
                assert all(type(i) is int and 0 <= i < len(lane['proof']) for i in ga['reachable_lines'])
                assert ga['axiom_names'] == sorted(set(ga['axiom_names']))
                assert ga['used_axiom_count'] == len(ga['axiom_names'])
                assert all(n in row['problem']['theory']['axioms'] for n in ga['axiom_names'])
                assert lane['check']['status'] == 'VERIFIED'
        # Display-only receptor diagram from actual saved certificate references.
        # These are not claimed point-engine selections or additional search results.
        row['control']['certificate_tiles'] = []
        proof = row['control'].get('proof') or []
        for i, line in enumerate(proof):
            marks = {'out:' + str(i): line['formula']}
            refs = ([line['antecedent'], line['implication']] if line['rule'] == 'mp'
                    else [line['source']] if line['rule'] == 'generalize' else [])
            for j in refs:
                assert type(j) is int and 0 <= j < i
                marks['out:' + str(j)] = proof[j]['formula']
            row['control']['certificate_tiles'].append(dict(
                id='control-certificate-line-' + str(i), slot=i, t=['slot:' + str(i)],
                m=[[point, json.dumps(value, ensure_ascii=True, separators=(',', ':'))]
                   for point, value in sorted(marks.items())],
                origin='SAVED_CERTIFICATE_DISPLAY_ONLY_NOT_POINT_SELECTED'))
        cases.append(row)
    assert len(cases) == 8 and [x['id'] for x in cases] == design['order']
    checks = []
    for name in sorted(artifacts):
        if not name.endswith('-whole-proof-check'):
            continue
        item = artifacts[name]
        x = saved(item, actual)
        assert x['status'] == 'VERIFIED' and x['native']['status'] == 'accepted'
        assert type(x['native']['value']) is int and x['native']['value'] == 1
        assert x['independent']['status'] == 'VERIFIED'
        checks.append(dict(artifact=item, proof_lines=len(x['proof']),
            proof_bytes=len(bytes.fromhex(x['encoding']['stream_hex'])),
            native_steps=x['native']['steps'], seconds=x['seconds'],
            native_status=x['native']['status'], native_value=x['native']['value'],
            independent=x['independent']['status']))
    normal, multidigit = [], []
    for name in artifacts:
        if not name.startswith('qualification-') or name.endswith('-whole-proof-check'):
            continue
        q = artifact(name)
        if 'full_solution_ID_sets' in q:
            target = normal if q['product'] is not None else multidigit
            target.append(dict(id=q['case'] + '-' + str(q['slots']), status=q['graph_audit']['status'],
                transitions=q['product'], solutions=None if q['full_solution_ID_sets'] is None else len(q['full_solution_ID_sets'])))
    assert len(normal) == 15 and len(multidigit) == 1
    assert len(w['qualification_checks']) == design['expected_qualification_checks'] == 37
    assert w['qualification']['status'] == 'PASS'
    complete = [x for x in cases if x['build_status'] == 'COMPLETE']
    ps = [x for x in cases if x['point']['status'] == 'SAT']
    cs = [x for x in cases if x['control']['status'] == 'DERIVABLE']
    assert len(checks) == 37 + len(ps) + len(cs) == 43
    main = set(design['cohorts']['main'])
    pm, cm = [x for x in ps if x['id'] in main], [x for x in cs if x['id'] in main]
    assert len(complete) == 8 and len(ps) == 2 and len(cs) == 4 and len(pm) == 0 and len(cm) == 2
    refusals = collections.Counter(x.get('build_reason') for x in cases if x['build_status'] != 'COMPLETE')
    build_total = sum(x['build_seconds'] for x in cases)
    findings = [
        f"The W compiler completed {len(complete)} of eight unchanged prospective inputs. GCTS point search produced {len(ps)} verified certificates; the same-basis backward shared-DAG control produced {len(cs)}. Among the six substantive arithmetic/geometry targets, the counts are {len(pm)} and {len(cm)} respectively. Neither lane received a proof sequence.",
        'Compilation refusals: ' + (', '.join(f'{k}: {v}' for k, v in sorted(refusals.items())) if refusals else 'none') + '. An unfinished catalogue or capped search remains UNKNOWN; it does not establish unprovability.',
        f"All {len(checks)} whole-certificate checks in this separately admitted attempt passed actual unchanged native C1 and the independent first-order checker, totaling {sum(x['proof_lines'] for x in checks)} lines. Thirty-seven certificates belong to qualification. The original worker took {terminal['elapsed_seconds']:.4f} seconds, including failed work, audits, logging and verification. Earlier unadmitted-prefix checks are not pooled into these totals.",
        f"Common catalogue construction took {build_total:.4f} seconds in total; native proof checks took {sum(x['seconds'] for x in checks):.4f} seconds. Phase samples are not a partition of the whole run. Search pipelines and checked totals are retained separately. This is one cold run, not a statistical speed comparison."]
    findings.append(f"The compiler recorded {sum(x['build_optimization']['transient_nodes_discarded'] for x in cases):,} discarded scratch nodes and {sum(x['build_optimization']['cache_evictions'] for x in cases):,} memo evictions. These are operational counts, not bytes saved or isolated causal evidence.")
    assessment = [
        'All eight catalogues completed under the new prospectively increased caps. The two substantive backward-control proofs combine the addition defining equations and use the incidence unique-line axiom respectively. The arithmetic input contains no induction schema; the incidence proof is a symbolic consequence of its declared axiom, not a new geometric theorem.',
        'GCTS proved only the two calibration cases and hit its wall on all six substantive targets. The backward control proved the calibrations plus arith-right-one and incidence-distinct-lines-common-points, and exhausted the other four finite bounded catalogues. This configuration provides no GCTS search-advantage evidence.', 
        'The table reports every case and both lanes, including incomplete construction, finite-catalogue exhaustion and resource cutoffs. A smaller UNKNOWN node count or time is not a search win. A finite NOT_DERIVABLE control result is limited to the complete reviewed catalogue and declared line bound, not unrestricted mathematical unprovability.',
        'Both lanes share the W catalogue. Cache reclamation and aggregate degree bookkeeping change representation and resource costs; the same complete non-cost catalogue and candidate identities are retained. This cohort does not isolate these changes with equal-cost cache or aggregate ablations, and its changed caps/work units do not establish a V-to-W speed ratio.',
        'Checked proof ancestry records only actual dependency-reachable named axioms. Several names in the original theory may be unused or serve only padding. Used names do not establish a minimal axiom set, indispensability or a new theorem.',
        'A GCTS-specific practical benefit still needs a prospectively declared marking/cluster contribution against a control with equal available lemmas and acquisition/invocation costs. The current engine uses complete base candidates and has no new learned policy or RL training.',
        'These finite symbolic point rows do not provide unrestricted FOL/PA/Hilbert completeness, the Peano induction schema, or a fixed literal universal Wang palette. Whole-machine lowering and accepting-boundary equivalence remain open. No broad superiority or novel mathematics claim follows.']
    data = dict(cases=cases, findings=findings, assessment=assessment, attempt_history=history,
        profile=dict(generation_profile=w['profile'], limits=w['limits'], design=design,
            original_worker_seconds=terminal['elapsed_seconds'], original_observer_seconds=observer['whole_observer_seconds'],
            child_wait4_peak_bytes=observer['wait4_peak_bytes'], common_compilation_seconds=build_total,
            all_kernel_bridge_seconds=sum(x['seconds'] for x in checks),
            cost_scope='One cold admitted attempt. Component clocks are cooperative; checked totals are not a disjoint partition. Common native preparation, qualification and storage are separately retained. No hard OS quota or cross-implementation work equivalence.'),
        bridge_summary=f"Fifteen tiny models exhaustively checked all {sum(x['transitions'] for x in normal)} complete row combinations and {sum(x['solutions'] for x in normal)} satisfying assignments across separate models. Every actual observed W domain and aggregate was checked independently. The separate twelve-row multidigit control checks lexical references and whole observed domains without enumerating its full Cartesian solution set. Other controls cover four resource refusals, detached/mutating and foreign callbacks, five isolated forgeries, shared-DAG bounds, and compiler cache/equality/distribution/bridge cases. Each solver returns one witness when successful; it does not enumerate all solutions.",
        bridge_controls=normal + multidigit)
    public = dict(schema='W-scalable-first-order-proof-search-public-results-v1', observed=w, reader=data,
        all_native_checks=checks, original_observer=ref(actual / 'observer-result.json'),
        original_worker=terminal['result'], source_pins=plan['sources'], metadata_pins=plan['metadata'],
        scientific_admission=ref(admission_path), attempt_history_ref=ref(history_path),
        renderer=ref(__file__), template=ref(TEMPLATE), native_check_totals=dict(certificates=len(checks),
            lines=sum(x['proof_lines'] for x in checks), bytes=sum(x['proof_bytes'] for x in checks),
            native_steps=sum(x['native_steps'] for x in checks)),
        interpretation='Complete bounded symbolic row candidates and exact aggregates, with actual checked proof ancestry. Separate unadmitted history retained. No new RL, fixed universal literal Wang palette, unrestricted logical completeness, or superiority claim.')
    html = TEMPLATE.read_text()
    embedded = json.dumps(data, ensure_ascii=True, sort_keys=True, separators=(',', ':')).replace('<', '\\u003c').replace('&', '\\u0026')
    assert html.count('__RESEARCH_DATA__') == 1
    html = html.replace('__RESEARCH_DATA__', embedded)
    assert len(html.encode()) <= 1048576, 'HTML publication cap'
    public_raw = (json.dumps(public, indent=2, sort_keys=True, ensure_ascii=True, allow_nan=False) + '\n').encode()
    assert len(public_raw) <= 8388608, 'JSON publication cap'
    output.mkdir()
    refs = []
    for name, body in [('scalable-first-order-proof-search-v1.html', html.encode()),
            ('scalable-first-order-proof-search-results-v1.json', public_raw)]:
        path = output / name
        with path.open('xb') as f:
            f.write(body)
        assert path.read_bytes() == body
        refs.append(ref(path))
    return refs


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', required=True)
    parser.add_argument('--admission', required=True)
    parser.add_argument('--attempt-history', required=True)
    parser.add_argument('--output', default=str(R / 'report-draft'))
    args = parser.parse_args()
    for item in materialize(args.plan, args.admission, args.attempt_history, args.output):
        print(json.dumps(item, sort_keys=True))


if __name__ == '__main__':
    main()
