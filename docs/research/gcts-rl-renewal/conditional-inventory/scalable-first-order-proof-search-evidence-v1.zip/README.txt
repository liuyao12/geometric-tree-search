GCTS research milestone W: complete prepublication evidence cut

MANIFEST.json maps each complete original absolute path to an archive member,
its stored byte length and SHA-256. PLAN.json is the exact frozen packaging
input. Original .json.gz files remain lossless opaque gzip artifacts; their
raw JSON hashes/lengths are in the original worker artifact receipts.

Study001 is wholly UNADMITTED and permanently spent; its 33 prefix checks
are not pooled with the complete study002. Study002 has 37 qualification
checks and six main proof checks, all actual native C1 plus independent B.
Only two calibration proofs were found by GCTS; the conventional control
also found the 12-line addition and 15-line incidence proofs. This is no
GCTS advantage or new RL result. Finite catalogue exhaustion is not full
mathematical unprovability.

Sources, raw certificates, byte heaps, logs and local file paths are
intentionally included under the user's explicit full-archive approval.
No credentials or environment dump is needed. The external Python runtime
binary is identified by its exact pin rather than redistributed. Direct
current dependencies are included; references to indirect older history
are provenance, not a claim to archive that entire history recursively.
Publication, subsequent normal-TLS and final live-browser evidence occur
after this cut and are retained separately in the durable research run.

Review Sources before executing. No scientific code is executed by this
packager. Original absolute paths describe the recorded environment; the
manifest supports relocation and manual inspection.
