"""C-owned report population offer review only; never writes Root state."""
from pathlib import Path
import collections,hashlib,json
D=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-conditional-selector-main-20261021');R=D/'root';C=D/'review-C';checked={}
def need(value,message):
 if not value:raise ValueError(message)
def wire(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def same(a,b):return wire(a)==wire(b)
def digest(value):return hashlib.sha256(wire(value)).hexdigest()
def pin(path):
 path=Path(path);need(path.is_absolute()and path.resolve()==path and path.is_file()and not path.is_symlink()and '.partial'not in path.name,'ordinary canonical complete file');b=path.read_bytes();q=dict(path=str(path),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
 if str(path)in checked:need(checked[str(path)]==q,'stable current raw identity')
 checked[str(path)]=q;return q
def verify(q):need(pin(q['path'])==q,'exact current raw pin');return q
def load(q):
 if isinstance(q,(str,Path)):q=pin(q)
 verify(q);return json.loads(Path(q['path']).read_bytes())
def passed(q):
 v=load(q);need(v['review_passed']is True and v['checks']and all(x['passed']is True for x in v['checks'])and v['failures']==[],'nonempty allPASS review');return v

offer_pin=pin(R/'conditional-main-report-state-offer-v6.json');need(offer_pin['bytes']==26378 and offer_pin['sha256']=='2c8df1f89a7a4a2bc78767d8d42605be8b3e46664ead05f5de571178fb39985f','exact offered N5 population')
state=load(offer_pin);need(state['schema']=='D21-Root-main-report-state-v3'and type(state['report_version'])is int and state['report_version']==6 and state['closed']is True and 'C_review'not in state,'open offer before separate final state')
disposition={key:value for key,value in state.items()if key!='C_review'}
disposition_sha=digest(disposition);need(disposition_sha=='f51f0b6dc31482ce92f1d22a910d46e0500c6fda0353e9daf7e6373958231db7','entire state digest excluding only top-level C_review')
protocol_pin=verify(state['protocol']);protocol=load(protocol_pin);need(protocol_pin['sha256']=='c04ff4523941d5552b6ffee42f73d8a5c189191ea1004b82fc28d0122b3e7422','unchanged original protocol')
recipes=protocol['job_recipes'];need(len(recipes)==len(state['jobs'])==34 and [x['stage_id']for x in recipes]==[x['stage_id']for x in state['jobs']],'full original ordered34recipes')
need(collections.Counter(x['status']for x in state['jobs'])==dict(QUALIFIED=32,FAILED=2),'exact current16/1/17whole dispositions')
source_review_pin=pin(C/'typed-reusable-compact-reader-Source-review-v4.json');passed(source_review_pin)
source_pin=pin(D/'diagnostics-L/project_conditional_main_reader_v4.py');template_pin=pin(D/'diagnostics-L/conditional-main-v4.html');api_pin=pin(D/'diagnostics-L/reader-API-v4.json')
need(source_pin['sha256']=='81838f929750cc78f5a3b5f9562f83449fdfa21d6459f855a91c37eb2f3c9da9'and template_pin['sha256']=='80ac1e2822809a6b6a99f27e0780f60c96bac9126cffedc91ed6eb3bffd5a122'and api_pin['sha256']=='21f4278959f8698adfdaf983c1cf0255bdfc054e785582ce8043c368cf306e51','unchanged reviewed reader4Source/API/template')
first_output_review_pin=pin(C/'typed-first-evaluation-admission-actual-output-review-v1.json');first_output_review=passed(first_output_review_pin)
five_output_review_pin=pin(C/'typed-five-evaluation-admission-actual-output-batch-review-v1.json');five_output_review=passed(five_output_review_pin)
negative_output_review_pin=pin(C/'typed-quantified02-negative-disposition-actual-output-review-v1.json');negative_output_review=passed(negative_output_review_pin)
remaining_output_review_pin=pin(C/'typed-remaining16-evaluation-admission-actual-output-batch-review-v1.json');remaining_output_review=passed(remaining_output_review_pin)
need(remaining_output_review_pin['sha256']=='650fb9690ed53f94f68e2f498cdb60ad4eb57242c077926b8cd73bfa00aa7507','current complete16output review')
negative1_output_review_pin=pin(C/'typed-quantified02-seed1-negative-disposition-actual-output-review-v1.json');negative1_output_review=passed(negative1_output_review_pin)
negative_outputs={row['stage_id']:dict(receipt=q,row=row) for q,row in [(negative_output_review_pin,negative_output_review),(negative1_output_review_pin,negative1_output_review)]}
positive_eval_output_reviews={first_output_review['stage_id']:dict(receipt=first_output_review_pin,row=first_output_review)}
for q,batch in [(five_output_review_pin,five_output_review),(remaining_output_review_pin,remaining_output_review)]:
 for entry in batch['per_output']:positive_eval_output_reviews[entry['stage_id']]=dict(receipt=q,row=entry)
need(len(positive_eval_output_reviews)==22 and len(negative_outputs)==2,'all24current evaluation outputreview owners')
documents={phase:load(q)for phase,q in protocol['phase_inputs'].items()}
current=[];proofs=[];episodes=[];eval_slots=[];policy_bundles=[];unknown_episodes=[];unknown_evaluations=[];previous_policies=None;total_seconds=0.0;phase_seconds=dict(acquire=0.0,train=0.0,evaluate=0.0);decided_census={};guard_union={}
seal_fields={'stage_id','stage','resource_admitted','stage_complete','plan','result','header','terminal','observer','export_sha256','whole_seconds','whole_peak_bytes','prior_cost_receipts'}
for recipe,row in zip(recipes,state['jobs'],strict=True):
 identity=recipe['stage_id'];stage=recipe['stage']
 need(set(row)=={'stage_id','stage','status','admission','blocking_stage_ids','reason'}and row['stage']==stage and row['blocking_stage_ids']==[]and type(row['reason'])is str and bool(row['reason']),'complete exact typed status row')
 if stage=='evaluate':eval_slots.extend(dict(stage_id=identity,method=method,state=row['status'],order_label=recipe['order_label'],stratum=recipe['stratum'])for method in recipe['method_order'])
 if row['status']=='PENDING':
  need(row['admission']is None and stage=='evaluate','no invented pending admission')
  need((R/'plans'/(identity+'-v1.json')).is_file(),'original materialized pending plan remains')
  need(all(not path.exists()for path in(D/'actual'/identity,D/'actual'/(identity+'.observer'),R/'grants'/(identity+'-v1.json'),R/'admission'/(identity+'-v1.json'))),'no pending actual/grant/decision')
  continue
 admission=load(row['admission']);need(admission['schema']=='D21-Root-conditional-stage-admission-v1'and admission['stage_id']==identity and admission['stage']==stage and admission['protocol']==protocol_pin,'current exact Root decision')
 review=passed(admission['C_actual_review']);need(review['schema']=='D21-C-conditional-stage-actual-review-v1'and review['Root_admission_issued']is False and type(review['partial_files_parsed'])is int and review['partial_files_parsed']==0,'current whole actual C ABI')
 for key in('plan','header','terminal','observer'):verify(admission[key]);need(review[key]==admission[key],'exact current decision/C components')
 plan=load(admission['plan']);need(plan['case_id']==identity and plan['stage']==stage and plan['Root_recipe']==recipe and plan['protocol']==protocol_pin,'whole original plan/recipe')
 need(review['input_pins']==sorted(plan['files'],key=lambda q:q['path']),'exact plan-only guards')
 for q in review['input_pins']:verify(q);guard_union[q['path']]=q
 for q in review['complete_actual_file_census']:verify(q);decided_census[q['path']]=q
 paths=sorted(str(p)for folder in(D/'actual'/identity,D/'actual'/(identity+'.observer'))for p in folder.rglob('*')if p.is_file())
 need(paths==sorted(q['path']for q in review['complete_actual_file_census'])and admission['complete_actual_file_census']==review['complete_actual_file_census'],'full current postterminal census')
 observer=load(admission['observer']);need(admission['whole_seconds']==observer['elapsed_seconds']==review['whole_seconds']and admission['whole_peak_bytes']==observer['final_conservative_whole_peak_bytes']==review['whole_peak_bytes'],'direct observer cost/qualified peak including null')
 total_seconds+=admission['whole_seconds'];phase_seconds[stage]+=admission['whole_seconds']
 if row['status']=='FAILED':
  need(identity in negative_outputs and row['admission']==negative_outputs[identity]['row']['Root_negative_output'],'each exact independently reviewed whole-negative output')
  need(all(admission[k]is False for k in('admitted','resource_admitted','scientific_qualified','stage_complete'))and all(review[k]is False for k in('resource_admitted','scientific_qualified','stage_complete')),'whole failed fourfalse gates')
  need(admission['result']is review['result']is None and admission['failure']==review['failure']and admission['whole_peak_bytes']is None,'failed result null/exact failure/null qualified peak')
  failure=load(admission['failure']);need(failure['scientific_result']is None and failure['error']['type']=='RootBudget'and failure['first_Root_fault']is True,'no returned scientific carrier or arm salvage')
  need(len(review['complete_actual_file_census'])==13 and not(R/'seals'/(identity+'-v1.json')).exists(),'failure census and absent seal')
  current.append(dict(stage_id=identity,status='FAILED',admission=row['admission'],C_actual_review=admission['C_actual_review'],failure=admission['failure'],whole_seconds=admission['whole_seconds'],whole_peak_bytes=None))
  continue
 need(row['status']=='QUALIFIED'and all(admission[k]is True for k in('admitted','resource_admitted','scientific_qualified','stage_complete'))and all(review[k]is True for k in('resource_admitted','scientific_qualified','stage_complete')),'only full positive stages supply artifacts')
 verify(admission['result']);need(admission['result']==review['result']and len(review['complete_actual_file_census'])==14,'same complete positive result/census')
 worker=load(admission['result']);science=worker['scientific_result'];need(worker['status']=='COMPLETE'and worker['error']is None and worker['source_unchanged']is True and science['stage_complete']is science['job_record_complete']is True and science['inputs']==documents[stage]and same(science['native_records'],worker['native_queries']),'current complete owned stage')
 need(digest(science['export'])==review['export_sha256'],'canonical actual export/summary digest')
 if stage in('acquire','train'):
  seal_pin=pin(R/'seals'/(identity+'-v1.json'));seal=load(seal_pin);need(set(seal)==seal_fields and seal['resource_admitted']is seal['stage_complete']is True and seal['prior_cost_receipts']==[],'original direct seal only')
  for key in seal_fields-{'prior_cost_receipts'}:need(same(seal[key],admission[key]),'same Root/seal shared fields')
 else:
  output_review=positive_eval_output_reviews[identity];need(output_review['row']['admission_output']==row['admission']and output_review['row']['C_actual_review']==admission['C_actual_review'],'current separate passive output review')
  need(science['all_eight_searched']is True and science['policies_updated']is False and [arm['id']for arm in science['records'][0]['arms']]==recipe['method_order'],'whole eight original frozen-policy arms')
  need(not(R/'seals'/(identity+'-v1.json')).exists()and 'qualified'not in science['export'],'no eval seal/qualified policy')
 current.append(dict(stage_id=identity,status='QUALIFIED',admission=row['admission'],C_actual_review=admission['C_actual_review'],result=admission['result'],whole_seconds=admission['whole_seconds'],whole_peak_bytes=admission['whole_peak_bytes']))
 for case_index,case in enumerate(science['records']):
  records=[('S0',case)]if stage=='acquire'else [(record['engine']+'-learned',record)for record in case['episodes']]if stage=='train'else[(record['id'],record)for record in case['arms']]
  for record_index,(method,record)in enumerate(records):
   if stage=='train':episodes.append(record['descriptor'])
   gate=record['proof_check'];search=record['search'];spec=case['spec']
   if gate['status']!='HOST_REGION_NATIVE_ACCEPTED':
    need(gate['status']=='NO_PROOF_CANDIDATE' and gate['native_proof_accepted'] is False and search['proof'] is None and search['placements']==[] and all(gate[key] is None for key in ('host_check','region','native_record')),'bounded local UNKNOWN has no proof authority or placements')
    if stage=='train':
     need(record['descriptor']['global_ordinal'] in (2,25),'only two preserved training localUNKNOWNs');unknown_episodes.append(record['descriptor']['global_ordinal'])
    else:
     need(stage=='evaluate' and spec['id']=='eval-equality-02' and record['engine']=='point' and method in ('P0','PF','PU','PR') and search['status']=='unknown_search_budget','exact equality02point localUNKNOWN source')
     unknown_evaluations.append(dict(stage_id=identity,method=method,search_status=search['status'],proof_status=gate['status']))
    continue
   query=gate['native_record'];proof=search['proof'];model=case['model']
   need(gate['native_proof_accepted']is gate['host_check']['accepted']is gate['region']['complete']is True and query['result']['status']=='accepted','full proof acceptance gates')
   need(query['request']['blocks']==[]and query['request']['theory']==spec['theory']and query['request']['proof']==proof and query['request']['target']==spec['target']and sum(same(query,q)for q in worker['native_queries'])==1,'fresh unique owned full flat Native proof')
   need(len(proof)==spec['length']and len(search['placements'])==2*len(proof)and len({tuple(key)for key in search['placements']})==len(search['placements']),'all original primitive rows/basecards')
   catalog={tuple(value['key']):value for value in model['placements']};need(len(catalog)==len(model['placements'])and model['word_terminator']==256,'complete current catalog and word identity')
   for key in search['placements']:
    placement=catalog[tuple(key)];slot,index=placement['command_reference'];need(model['domains'][slot][index]==proof[slot],'full selected command/guard literal owner')
    for point,value in placement['marks']:
     if point[1]==100:need(type(value)is int and 0<=value<len(model['word_dictionary']),'whole word ID including zero')
   proofs.append(dict(stage_id=identity,stage=stage,problem_id=spec['id'],method=method,record_index=record_index,primitive_rows=len(proof),base_cards=len(search['placements']),native_query=query['id'],proof_sha256=digest(proof),record_sha256=digest(record)))
 if stage=='train':
  need(science['policies']==science['export']['policies'],'exact admitted current bundle')
  for engine in('symbolic','point'):
   policy=science['policies'][engine];need(policy['episodes']==len(policy['history'])==2*(int(identity[-1])+1),'full original policy prefix length')
   if previous_policies is not None:need(same(policy['history'][:len(previous_policies[engine]['history'])],previous_policies[engine]['history']),'immutable exact prior histories')
  previous_policies=science['policies'];policy_bundles.append(dict(stage_id=identity,result=admission['result'],export_sha256=digest(science['export']),episodes_per_engine=science['policies']['symbolic']['episodes']))
expected_episodes=[descriptor for recipe in recipes if recipe['stage']=='train'for descriptor in recipe['episodes']]
need(episodes==expected_episodes and len(episodes)==32 and unknown_episodes==[2,25],'complete32training descriptors/two preserved UNKNOWNs')
need(len(eval_slots)==192 and collections.Counter(x['state']for x in eval_slots)==dict(QUALIFIED=176,FAILED=16),'full192slots with unavailable distinct from UNKNOWN')
proof_rows=sum(x['primitive_rows'] for x in proofs);base_cards=sum(x['base_cards'] for x in proofs)
need(len(proofs)==200 and base_cards==2*proof_rows,'derive all200accepted occurrences/primitive rows/basecards from current eligible literal records')
need(sum(x['stage']=='evaluate' for x in proofs)==168 and len(unknown_evaluations)==8,'22wholecomplete evaluation jobs168proofs8localUNKNOWNs')
need(len(policy_bundles)==8 and len(current)==34 and len(decided_census)==474,'all current decided jobs/raw censuses')
need(not(R/'conditional-main-report-state-v6.json').exists()and not(R/'conditional-main-reader-request-v6.json').exists(),'final Root state/request still separate and absent')
for value in tuple(checked.values()):verify(value)
counts=dict(planned_jobs=34,qualified_jobs=32,failed_jobs=2,pending_jobs=0,training_episode_slots=32,training_returned=32,training_accepted_proof_occurrences=30,training_local_UNKNOWN=2,evaluation_slots=192,evaluation_returned=176,evaluation_accepted_proof_occurrences=168,evaluation_search_UNKNOWN=len(unknown_evaluations),evaluation_whole_failure_unavailable_slots=16,evaluation_pending_slots=0,current_policy_bundles=8,eligible_proof_occurrences=len(proofs),eligible_primitive_rows=proof_rows,eligible_base_cards=base_cards,decided_actual_census_files=len(decided_census))
checks=[
 ('entire-closed-N6-disposition-original34recipes','Exact26,378-byte offer is schema3/report_version6,closedtrue,withall34originalordered recipes and noC_reviewyet. Entirestatecanonicaldigest excludesonlyfuturetopC_review and equalsf51f0b6dc31482ce92f1d22a910d46e0500c6fda0353e9daf7e6373958231db7.32QUALIFIED/twoFAILED/zeroPENDING are explicitRootdecisions,not inferredfromabsence or upgraded tofullscientificsuccess.'),
 ('all-current-positive-Root-C-and22-evaluation-output-owners','Alltenacquisition/trainingadmissions/seals and22positiveevaluationadmissions bind currentfourtruegates,completeCactuals/fivecomponents,currentSourceguards/censuses andrawexports/summaries. Separatefirst/five/remaining16 outputreviews bind everycurrentevaluationadmission. No oldresult/policyadoption or evaluationseal.'),
 ('two-negative-whole-failures-distinct-from-localUNKNOWN','Both exactquantified02Rootnegatives andCfailure/outputreviews retainfourfalsegates,resultnull,fullfailurepins,nullqualifiedpeaks and13rawfileseach. Scientific_resultnullsuppliesnoarm/proof/model/policyprefix,includingdiagnosticSUquery.16slotsremainwholejobunavailable. Eightreturned equality02pointlocalUNKNOWNs have noHost/region/Nativeproof orplacements;they arenotwholefailures or substitutedproofs.'),
 ('full32training192evaluation-derived-proof-row-card-populations',f'All32trainingdescriptors/eightimmutablepolicybundles remain,with30acceptedtrainingproofs/twolocalUNKNOWNglobal2/global25 plus2S0donorproofs. All192evalslots remain:176returned=168acceptedproofs+8localUNKNOWN,16wholefailureunavailable,0pending. Literalcurrenteligibleproofrowsderive{len(proofs)}views/{proof_rows}primitive rows/{base_cards}basecards;no guess or Nativequeryprefix was countedasproof. EveryacceptedproofcurrentHost/fullfinitewordregion/uniqueownedNativeblocks-empty/querytheory/target/proof/cardcatalog joinswithoutscientificreplay.'),
 ('all34-observer-cost-samples-and-honest-closed-original-scope','All34decided observer.elapsed_seconds samples,includingbothwholefailures once,fold inoriginalrecipeorder;qualifiednullpeaksstaynull. Nestedsetup/search/arm/helper/custody/QAclocks arenotadded. Originalplannedmainstudyisclosed,butbroaderresearch/fullscientificqualification/learning-GCTS-SOTAutilityare notestablished. Publicauthoredinputstructureholdouts arenotblind orproof-DAGdisjoint,method/orderrealizations arenotindependentstatisticalreplicas.'),
 ('unchanged-reader4-separate-final-state-request-output','Reader4Source/API/template/fullSourcePASS remainexact. Its positive-onlyartifactboundary forwardsbothfailedjobsdiagnostically withoutscience/proof/policy. This typedofferreview bindsentiredispositiononly;Rootmayadd itsCpin toaseparatefinalstate. Exactreaderrequest/onceprojection/data-HTML/browser/package/install/livepublicationgatesremainseparate;CwritesnoRootstate.')]
receipt=dict(schema='D21-C-main-report-population-review-v1',review_passed=True,report_version=6,protocol=protocol_pin,population_offer=offer_pin,population_disposition_sha256=disposition_sha,disposition_rows_sha256=digest(state['jobs']),closed=True,reader_Source=source_pin,reader_API=api_pin,reader_template=template_pin,reader_Source_review=source_review_pin,first_evaluation_admission_output_review=first_output_review_pin,five_evaluation_admission_output_review=five_output_review_pin,remaining16_evaluation_admission_output_review=remaining_output_review_pin,negative_disposition_output_reviews=[negative_output_review_pin,negative1_output_review_pin],counts=counts,current_decisions=current,eligible_proof_literal_counts=proofs,current_policy_bundles=policy_bundles,retained_training_UNKNOWN_ordinals=unknown_episodes,returned_evaluation_local_UNKNOWNs=unknown_evaluations,training_descriptor_sha256=digest(expected_episodes),evaluation_slot_descriptors_sha256=digest(eval_slots),decided_unique_observer_sample_seconds=total_seconds,phase_observer_sample_seconds=phase_seconds,checked_unique_current_pin_count=len(checked),checked_current_pins_sha256=digest(sorted(checked.values(),key=lambda q:q['path'])),checks=[dict(id=k,passed=True,finding=v) for k,v in checks],failures=[],partial_files_parsed=0,projector_invocations=0,helper_invocations=0,scientific_calls=0,Root_admission_issued=False,Root_state_written_by_C=False,scope='Exact closed ORIGINAL N6reporting populationoffer/digest only. Bothwholefailures andalllocalUNKNOWNs remain. Closureisallplannedjobsdecided,notwholeprogramorfullscientificsuccess/benefit. No finalRootstate/request/output/browser/archive/publication authority;prioractualreviews reused onlybycurrentrawequality,nosubjectreplay.',review_program=pin(Path(__file__).resolve()),preserved_prior_review_program=pin(C/'passive_open_progress_population_offer_review_v5.py'),tools_idle_after_freeze=True)
out=C/'typed-closed-N6-population-offer-review-v1.json'
with out.open('xb') as stream:stream.write((json.dumps(receipt,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode())
print(json.dumps(pin(out)));print(json.dumps(counts));print(json.dumps(dict(observer_sample_seconds=total_seconds,phase_samples=phase_seconds,tools_idle=True)))
