"""Dispatch only C's frozen stdlib passive reviewer, then index its receipts."""
from pathlib import Path
import collections
import hashlib
import json
import subprocess

D=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-conditional-selector-main-20261021')
C=D/'review-C'; R=D/'root'
PY='/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12'
SCRIPT=C/'passive_remaining16_evaluation_actual_reviews_v1_1.py'
def pin(path):
    path=Path(path); assert path.is_absolute() and path.resolve()==path and path.is_file() and not path.is_symlink()
    body=path.read_bytes(); return dict(path=str(path),bytes=len(body),sha256=hashlib.sha256(body).hexdigest())
def load(value):
    if isinstance(value,(str,Path)):value=pin(value)
    assert '.partial' not in Path(value['path']).name and pin(value['path'])==value
    return json.loads(Path(value['path']).read_bytes())
def wire(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def passed(value):
    result=load(value); assert result['review_passed'] is True and result['checks'] and all(row['passed'] is True for row in result['checks']) and result['failures']==[]
    return result

script_pin=pin(SCRIPT); assert script_pin['sha256']=='0d095f1bbffa26024781f94826c96030f75164eac441179bb9c92664c470a894'
parameters_pin=pin(C/'remaining16-positive-evaluation-review-parameters-v1.json')
assert parameters_pin['sha256']=='dee4082a4251d1c312f7dc443b978fb4f5ef257501aede7a229d416a0910bd6d'
parameters=load(parameters_pin); packet_pin=parameters['Root_terminal_packet']; packet=load(packet_pin)
assert packet_pin['sha256']=='2bf439d7510099286d8aad889f83ea51a6b84e9f7b4ccee85e89327073b3700f'
identities=parameters['stage_ids']; assert identities==[row['stage_id'] for row in packet['jobs']] and len(identities)==16
first_pin=pin(C/('typed-'+identities[0]+'-actual-review-v1.json'))
assert first_pin['sha256']=='dad9707df4c1ab3484760a219dd931d903d389fe31880503e5effdc1106efd3a'
passed(first_pin)
for identity in identities[1:]:
    result=subprocess.run([PY,'-I','-S','-B',str(SCRIPT),'--stage-id',identity],capture_output=True,text=True)
    if result.returncode:
        print(json.dumps(dict(stage_id=identity,exit_code=result.returncode,stdout=result.stdout,stderr=result.stderr)),flush=True)
        raise RuntimeError('C passive review stopped; preserve its Source and investigate without subject replay')
    print(result.stdout.strip(),flush=True)

reviews=[]; rows=[]; guards={}; census={}; native=collections.Counter(); counts=collections.Counter(); seconds=0.0
preflight=load(packet['preflight']); window=load(packet['window'])
assert window['raw_plan_preflight']==packet['preflight'] and window['remaining_original_jobs']==16 and window['stop_window_on_any_whole_failure'] is True
prior_pin=pin(R/'admission/eval-eval-quantified-02-seed1-v1.json'); prior=load(prior_pin)
assert prior_pin['sha256']=='e9d48b3f68ae7a72a7992fe2b7176fcf0c1b3b8ebed23b16a9240c6f8aabe0d9'
previous={key:prior[key] for key in ('header','terminal','observer')}
for identity,offered in zip(identities,packet['jobs'],strict=True):
    q=pin(C/('typed-'+identity+'-actual-review-v1.json')); review=passed(q)
    assert review['schema']=='D21-C-conditional-stage-actual-review-v1' and review['stage_id']==identity and review['stage']=='evaluate'
    assert all(review[key] is True for key in ('resource_admitted','scientific_qualified','stage_complete')) and review['Root_admission_issued'] is False
    assert type(review['partial_files_parsed']) is int and review['partial_files_parsed']==0
    assert review['review_program']==script_pin and review['review_parameters']==parameters_pin
    assert all(review[key]==offered[key] for key in ('plan','result','header','terminal','observer'))
    plan=load(review['plan']); assert review['input_pins']==sorted(plan['files'],key=lambda value:value['path']) and len(plan['files'])==109
    for value in review['input_pins']:
        assert pin(value['path'])==value; guards[value['path']]=value
    assert review['complete_actual_file_census']==sorted(offered['complete_actual_file_census'],key=lambda value:value['path']) and len(review['complete_actual_file_census'])==14
    for value in review['complete_actual_file_census']:
        assert pin(value['path'])==value; census[value['path']]=value
    grant=load(review['grant']); barrier=load(review['serial_barrier'])
    assert barrier['window_checkpoint']==packet['window'] and all(barrier['previous_'+key]==value for key,value in previous.items())
    assert grant['serial_barrier']==review['serial_barrier'] and grant['uses']==1 and grant['plan_sha256']==review['plan']['sha256']
    previous={key:review[key] for key in ('header','terminal','observer')}
    assert review['whole_seconds']==offered['observer_elapsed_seconds'] and review['whole_peak_bytes']==offered['resource_candidate_peak_bytes']
    seconds+=review['whole_seconds']; native.update(review['counts']['Native_status_counts'])
    for key in ('arms','accepted_proof_occurrences','UNKNOWN_arms','proof_rows','base_cards','current_Native_records','control_rows','inherited_domain_audits','point_domain_audits','marking_certificates','selector_decisions','Root_snapshots','raw_completed_pools','raw_packets','executable_groups','ordered_candidate_lists'):
        counts[key]+=review['counts'][key]
    assert not(R/'admission'/(identity+'-v1.json')).exists() and not(R/'seals'/(identity+'-v1.json')).exists()
    reviews.append(q); rows.append(dict(stage_id=identity,C_actual_review=q,plan=review['plan'],result=review['result'],whole_seconds=review['whole_seconds'],whole_peak_bytes=review['whole_peak_bytes'],counts=review['counts'],declared_stratum=review['declared_stratum'],unfinished_carriers=review['unfinished_carriers']))
assert sorted(guards.values(),key=lambda value:value['path'])==preflight['explicit_unique_guard_pins'] and len(guards)==124 and len(census)==224
assert counts['arms']==128 and counts['accepted_proof_occurrences']==120 and counts['UNKNOWN_arms']==8
assert counts['current_Native_records']==532 and native==dict(accepted=168,rejected=364)
prior_outputs=[]
for identity,expected in [('eval-eval-quantified-02-seed0','64fb429c1271f8c2ef9cf44c86722271eb08e7c94edccf05403960ebca41ddd1'),('eval-eval-quantified-02-seed1','e9d48b3f68ae7a72a7992fe2b7176fcf0c1b3b8ebed23b16a9240c6f8aabe0d9')]:
    q=pin(R/'admission'/(identity+'-v1.json')); value=load(q)
    assert q['sha256']==expected and value['result'] is value['whole_peak_bytes'] is None and all(value[key] is False for key in ('admitted','resource_admitted','scientific_qualified','stage_complete'))
    prior_outputs.append(q)
negative_pin=pin(R/'remaining16-positive-barrier-authoring-negative-v1.json'); negative=load(negative_pin)
assert 'failed before writing barrier/grant or scientific call' in negative['scope']
for q in reviews+[script_pin,parameters_pin,packet_pin,packet['preflight'],packet['window']]+prior_outputs:assert pin(q['path'])==q
checks=[
    dict(id='sixteen-complete-independent-whole-actual-receipts',passed=True,finding='All16 exact original once jobs have separate strict Cactual receipts,each with eight all-passed checks,109plan-onlyguards,14complete currentcensus pins,originalcaps/frozenall10predecessors andfourtruequalificationgates. Cissues noRootadmission orseal.'),
    dict(id='literal128-outcomes-and-532-current-Native-records',passed=True,finding='All128originalslots return:120accepted primitiveproof occurrences and8boundedpointsearchUNKNOWNs,without proof/gate/substitute forUNKNOWN. All532ownedNative records are complete:168acceptedchecks/364rejectedlicencecandidates,with finalHost/fullfinitewordregion/freshblocks-emptyNativeproofgates onlyforacceptedproofs. Fullcontrols/models/markings/traces/rawpools/grouping/Rootsamples/rollback/fallback/costchecks remain unchanged.'),
    dict(id='current-serial-custody-and-negative-metadata-distinction',passed=True,finding='All16currentoncegrant/consumption/barriers bind the samefreshwindow;eachpreviousheader/terminal/observer equals the immediate priorwholepacket,startingfromnegativequantified02seed1. Rootwrongheaderliteral authoringnegative is preserved as passive prewriteerror,not actualfailure/retry. Bothpriorquantified02wholefailures remainfourfalse/resultnull/peaknull,without prefixsalvage.'),
    dict(id='batch-only-no-admission-or-comparative-benefit',passed=True,finding='Thisbatch indexes current Cwholeactualreviews only. All34originalmainjobs are terminal;currentRootdecisions fornew16await separate exactrequest/outputreview. Original192evalslots include22completejobs/176returnedrecords,168acceptedproofs,8localUNKNOWNsand16wholefailureunavailable. Declaredinputstructureholdouts remainpublic/notblind/noproofDAGdisjointclaim;no learning/GCTS/SOTA/comparative benefit is inferred.')]
receipt=dict(schema='D21-C-remaining16-evaluation-current-actual-review-index-v1',review_passed=True,Root_terminal_packet=packet_pin,Root_preflight=packet['preflight'],Root_window=packet['window'],review_program=pin(Path(__file__).resolve()),per_job_review_program=script_pin,review_parameters=parameters_pin,reviewer_parameterization=pin(C/'passive-remaining16-reviewer-parameterization-v1.json'),owned_reviewer_metadata_negative=pin(C/'typed-remaining16-owned-passive-metadata-ABI-negative-v1.json'),Root_barrier_authoring_negative=negative_pin,reviews=reviews,per_job=rows,counts=dict(counts),Native_status_counts=dict(native),new_complete_actual_census_files=224,unique_current_guard_pins=124,guard_union_sha256=hashlib.sha256(wire(sorted(guards.values(),key=lambda value:value['path']))).hexdigest(),new_unique_observer_sample_seconds=seconds,prior_quantified02_Root_negatives=prior_outputs,original_population=dict(main_jobs=34,main_jobs_terminal=34,evaluation_jobs=24,evaluation_jobs_terminal=24,evaluation_slots=192,returned_evaluation_records=176,accepted_evaluation_proof_occurrences=168,local_evaluation_UNKNOWN=8,whole_failure_unavailable_evaluation_slots=16,new_Root_admissions_issued_by_C=0),checks=checks,failures=[],scientific_calls=0,scientific_imports=0,subject_replays=0,helper_invocations=0,partial_files_parsed=0,Root_admission_issued=False,scope='Index of16independently reviewed completeoriginalactuals,not Rootadmission,newgrants,scientificreplay orcomparativeutility. Priorwholefailuresremainnegative;separate exactpassiveadmissionrequest/outputreviews required.',tools_idle_after_freeze=True)
out=C/'typed-remaining16-evaluation-current-actual-review-index-v1.json'
with out.open('x') as stream:json.dump(receipt,stream,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False);stream.write('\n')
print(json.dumps(pin(out)),flush=True)
print(json.dumps(dict(counts=dict(counts),Native_status_counts=dict(native),observer_sample_seconds=seconds,tools_idle=True)),flush=True)
