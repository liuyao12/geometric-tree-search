"""C-owned report population offer review only; never writes Root state."""
from pathlib import Path
import collections,hashlib,json
D=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-conditional-selector-main-20261021');R=D/'root';C=D/'review-C';checked={}
def need(value,message):
 if not value:raise ValueError(message)
def wire(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def same(a,b):return wire(a)==wire(b)
def digest(value):return hashlib.sha256(wire(value)).hexdigest()
def pin(path):
 path=Path(path);need(path.is_absolute()and path.resolve()==path and path.is_file()and not path.is_symlink()and '.partial'not in path.name,'ordinary canonical complete file');b=path.read_bytes();q=dict(path=str(path),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
 if str(path)in checked:need(checked[str(path)]==q,'stable current raw identity')
 checked[str(path)]=q;return q
def verify(q):need(pin(q['path'])==q,'exact current raw pin');return q
def load(q):
 if isinstance(q,(str,Path)):q=pin(q)
 verify(q);return json.loads(Path(q['path']).read_bytes())
def passed(q):
 v=load(q);need(v['review_passed']is True and v['checks']and all(x['passed']is True for x in v['checks'])and v['failures']==[],'nonempty allPASS review');return v

offer_pin=pin(R/'conditional-main-report-state-offer-v5.json');need(offer_pin['bytes']==16702 and offer_pin['sha256']=='1a0e0f2b56c8b23929df1fad0f513c50dafbb44d21327806dc328e95138749e1','exact offered N5 population')
state=load(offer_pin);need(state['schema']=='D21-Root-main-report-state-v3'and type(state['report_version'])is int and state['report_version']==5 and state['closed']is False and 'C_review'not in state,'open offer before separate final state')
disposition={key:value for key,value in state.items()if key!='C_review'}
disposition_sha=digest(disposition);need(disposition_sha=='e79b7fa5c507c280c069abf19cd58a55f6873e45c76caddd6dd877ff55e0db2f','entire state digest excluding only top-level C_review')
protocol_pin=verify(state['protocol']);protocol=load(protocol_pin);need(protocol_pin['sha256']=='c04ff4523941d5552b6ffee42f73d8a5c189191ea1004b82fc28d0122b3e7422','unchanged original protocol')
recipes=protocol['job_recipes'];need(len(recipes)==len(state['jobs'])==34 and [x['stage_id']for x in recipes]==[x['stage_id']for x in state['jobs']],'full original ordered34recipes')
need(collections.Counter(x['status']for x in state['jobs'])==dict(QUALIFIED=16,FAILED=1,PENDING=17),'exact current16/1/17whole dispositions')
source_review_pin=pin(C/'typed-reusable-compact-reader-Source-review-v4.json');passed(source_review_pin)
source_pin=pin(D/'diagnostics-L/project_conditional_main_reader_v4.py');template_pin=pin(D/'diagnostics-L/conditional-main-v4.html');api_pin=pin(D/'diagnostics-L/reader-API-v4.json')
need(source_pin['sha256']=='81838f929750cc78f5a3b5f9562f83449fdfa21d6459f855a91c37eb2f3c9da9'and template_pin['sha256']=='80ac1e2822809a6b6a99f27e0780f60c96bac9126cffedc91ed6eb3bffd5a122'and api_pin['sha256']=='21f4278959f8698adfdaf983c1cf0255bdfc054e785582ce8043c368cf306e51','unchanged reviewed reader4Source/API/template')
first_output_review_pin=pin(C/'typed-first-evaluation-admission-actual-output-review-v1.json');first_output_review=passed(first_output_review_pin)
five_output_review_pin=pin(C/'typed-five-evaluation-admission-actual-output-batch-review-v1.json');five_output_review=passed(five_output_review_pin)
negative_output_review_pin=pin(C/'typed-quantified02-negative-disposition-actual-output-review-v1.json');negative_output_review=passed(negative_output_review_pin)
positive_eval_output_reviews={first_output_review['stage_id']:dict(receipt=first_output_review_pin,row=first_output_review)}
for entry in five_output_review['per_output']:positive_eval_output_reviews[entry['stage_id']]=dict(receipt=five_output_review_pin,row=entry)
documents={phase:load(q)for phase,q in protocol['phase_inputs'].items()}
current=[];proofs=[];episodes=[];eval_slots=[];policy_bundles=[];unknown_episodes=[];previous_policies=None;total_seconds=0.0;phase_seconds=dict(acquire=0.0,train=0.0,evaluate=0.0);decided_census={};guard_union={}
seal_fields={'stage_id','stage','resource_admitted','stage_complete','plan','result','header','terminal','observer','export_sha256','whole_seconds','whole_peak_bytes','prior_cost_receipts'}
for recipe,row in zip(recipes,state['jobs'],strict=True):
 identity=recipe['stage_id'];stage=recipe['stage']
 need(set(row)=={'stage_id','stage','status','admission','blocking_stage_ids','reason'}and row['stage']==stage and row['blocking_stage_ids']==[]and type(row['reason'])is str and bool(row['reason']),'complete exact typed status row')
 if stage=='evaluate':eval_slots.extend(dict(stage_id=identity,method=method,state=row['status'],order_label=recipe['order_label'],stratum=recipe['stratum'])for method in recipe['method_order'])
 if row['status']=='PENDING':
  need(row['admission']is None and stage=='evaluate','no invented pending admission')
  need((R/'plans'/(identity+'-v1.json')).is_file(),'original materialized pending plan remains')
  need(all(not path.exists()for path in(D/'actual'/identity,D/'actual'/(identity+'.observer'),R/'grants'/(identity+'-v1.json'),R/'admission'/(identity+'-v1.json'))),'no pending actual/grant/decision')
  continue
 admission=load(row['admission']);need(admission['schema']=='D21-Root-conditional-stage-admission-v1'and admission['stage_id']==identity and admission['stage']==stage and admission['protocol']==protocol_pin,'current exact Root decision')
 review=passed(admission['C_actual_review']);need(review['schema']=='D21-C-conditional-stage-actual-review-v1'and review['Root_admission_issued']is False and type(review['partial_files_parsed'])is int and review['partial_files_parsed']==0,'current whole actual C ABI')
 for key in('plan','header','terminal','observer'):verify(admission[key]);need(review[key]==admission[key],'exact current decision/C components')
 plan=load(admission['plan']);need(plan['case_id']==identity and plan['stage']==stage and plan['Root_recipe']==recipe and plan['protocol']==protocol_pin,'whole original plan/recipe')
 need(review['input_pins']==sorted(plan['files'],key=lambda q:q['path']),'exact plan-only guards')
 for q in review['input_pins']:verify(q);guard_union[q['path']]=q
 for q in review['complete_actual_file_census']:verify(q);decided_census[q['path']]=q
 paths=sorted(str(p)for folder in(D/'actual'/identity,D/'actual'/(identity+'.observer'))for p in folder.rglob('*')if p.is_file())
 need(paths==sorted(q['path']for q in review['complete_actual_file_census'])and admission['complete_actual_file_census']==review['complete_actual_file_census'],'full current postterminal census')
 observer=load(admission['observer']);need(admission['whole_seconds']==observer['elapsed_seconds']==review['whole_seconds']and admission['whole_peak_bytes']==observer['final_conservative_whole_peak_bytes']==review['whole_peak_bytes'],'direct observer cost/qualified peak including null')
 total_seconds+=admission['whole_seconds'];phase_seconds[stage]+=admission['whole_seconds']
 if row['status']=='FAILED':
  need(identity=='eval-eval-quantified-02-seed0'and row['admission']==negative_output_review['Root_negative_output'],'exact independently reviewed negative output')
  need(all(admission[k]is False for k in('admitted','resource_admitted','scientific_qualified','stage_complete'))and all(review[k]is False for k in('resource_admitted','scientific_qualified','stage_complete')),'whole failed fourfalse gates')
  need(admission['result']is review['result']is None and admission['failure']==review['failure']and admission['whole_peak_bytes']is None,'failed result null/exact failure/null qualified peak')
  failure=load(admission['failure']);need(failure['scientific_result']is None and failure['error']['type']=='RootBudget'and failure['first_Root_fault']is True,'no returned scientific carrier or arm salvage')
  need(len(review['complete_actual_file_census'])==13 and not(R/'seals'/(identity+'-v1.json')).exists(),'failure census and absent seal')
  current.append(dict(stage_id=identity,status='FAILED',admission=row['admission'],C_actual_review=admission['C_actual_review'],failure=admission['failure'],whole_seconds=admission['whole_seconds'],whole_peak_bytes=None))
  continue
 need(row['status']=='QUALIFIED'and all(admission[k]is True for k in('admitted','resource_admitted','scientific_qualified','stage_complete'))and all(review[k]is True for k in('resource_admitted','scientific_qualified','stage_complete')),'only full positive stages supply artifacts')
 verify(admission['result']);need(admission['result']==review['result']and len(review['complete_actual_file_census'])==14,'same complete positive result/census')
 worker=load(admission['result']);science=worker['scientific_result'];need(worker['status']=='COMPLETE'and worker['error']is None and worker['source_unchanged']is True and science['stage_complete']is science['job_record_complete']is True and science['inputs']==documents[stage]and same(science['native_records'],worker['native_queries']),'current complete owned stage')
 need(digest(science['export'])==review['export_sha256'],'canonical actual export/summary digest')
 if stage in('acquire','train'):
  seal_pin=pin(R/'seals'/(identity+'-v1.json'));seal=load(seal_pin);need(set(seal)==seal_fields and seal['resource_admitted']is seal['stage_complete']is True and seal['prior_cost_receipts']==[],'original direct seal only')
  for key in seal_fields-{'prior_cost_receipts'}:need(same(seal[key],admission[key]),'same Root/seal shared fields')
 else:
  output_review=positive_eval_output_reviews[identity];need(output_review['row']['admission_output']==row['admission']and output_review['row']['C_actual_review']==admission['C_actual_review'],'current separate passive output review')
  need(science['all_eight_searched']is True and science['policies_updated']is False and [arm['id']for arm in science['records'][0]['arms']]==recipe['method_order'],'whole eight original frozen-policy arms')
  need(not(R/'seals'/(identity+'-v1.json')).exists()and 'qualified'not in science['export'],'no eval seal/qualified policy')
 current.append(dict(stage_id=identity,status='QUALIFIED',admission=row['admission'],C_actual_review=admission['C_actual_review'],result=admission['result'],whole_seconds=admission['whole_seconds'],whole_peak_bytes=admission['whole_peak_bytes']))
 for case_index,case in enumerate(science['records']):
  records=[('S0',case)]if stage=='acquire'else [(record['engine']+'-learned',record)for record in case['episodes']]if stage=='train'else[(record['id'],record)for record in case['arms']]
  for record_index,(method,record)in enumerate(records):
   if stage=='train':episodes.append(record['descriptor'])
   gate=record['proof_check'];search=record['search'];spec=case['spec']
   if gate['status']!='HOST_REGION_NATIVE_ACCEPTED':
    need(stage=='train'and record['descriptor']['global_ordinal']in(2,25)and gate['status']=='NO_PROOF_CANDIDATE'and gate['native_proof_accepted']is False,'only preserved two training local UNKNOWNs')
    unknown_episodes.append(record['descriptor']['global_ordinal']);continue
   query=gate['native_record'];proof=search['proof'];model=case['model']
   need(gate['native_proof_accepted']is gate['host_check']['accepted']is gate['region']['complete']is True and query['result']['status']=='accepted','full proof acceptance gates')
   need(query['request']['blocks']==[]and query['request']['theory']==spec['theory']and query['request']['proof']==proof and query['request']['target']==spec['target']and sum(same(query,q)for q in worker['native_queries'])==1,'fresh unique owned full flat Native proof')
   need(len(proof)==spec['length']and len(search['placements'])==2*len(proof)and len({tuple(key)for key in search['placements']})==len(search['placements']),'all original primitive rows/basecards')
   catalog={tuple(value['key']):value for value in model['placements']};need(len(catalog)==len(model['placements'])and model['word_terminator']==256,'complete current catalog and word identity')
   for key in search['placements']:
    placement=catalog[tuple(key)];slot,index=placement['command_reference'];need(model['domains'][slot][index]==proof[slot],'full selected command/guard literal owner')
    for point,value in placement['marks']:
     if point[1]==100:need(type(value)is int and 0<=value<len(model['word_dictionary']),'whole word ID including zero')
   proofs.append(dict(stage_id=identity,stage=stage,problem_id=spec['id'],method=method,record_index=record_index,primitive_rows=len(proof),base_cards=len(search['placements']),native_query=query['id'],proof_sha256=digest(proof),record_sha256=digest(record)))
 if stage=='train':
  need(science['policies']==science['export']['policies'],'exact admitted current bundle')
  for engine in('symbolic','point'):
   policy=science['policies'][engine];need(policy['episodes']==len(policy['history'])==2*(int(identity[-1])+1),'full original policy prefix length')
   if previous_policies is not None:need(same(policy['history'][:len(previous_policies[engine]['history'])],previous_policies[engine]['history']),'immutable exact prior histories')
  previous_policies=science['policies'];policy_bundles.append(dict(stage_id=identity,result=admission['result'],export_sha256=digest(science['export']),episodes_per_engine=science['policies']['symbolic']['episodes']))
expected_episodes=[descriptor for recipe in recipes if recipe['stage']=='train'for descriptor in recipe['episodes']]
need(episodes==expected_episodes and len(episodes)==32 and unknown_episodes==[2,25],'complete32training descriptors/two preserved UNKNOWNs')
need(len(eval_slots)==192 and collections.Counter(x['state']for x in eval_slots)==dict(QUALIFIED=48,FAILED=8,PENDING=136),'full192slots with unavailable distinct from UNKNOWN')
need(len(proofs)==80 and sum(x['primitive_rows']for x in proofs)==944 and sum(x['base_cards']for x in proofs)==1888,'all80eligible occurrences/944rows/1888cards')
need(sum(x['stage']=='evaluate'for x in proofs)==48 and sum(x['primitive_rows']for x in proofs if x['stage']=='evaluate')==608,'six evaluation jobs48proofs608rows')
need(len(policy_bundles)==8 and len(current)==17 and len(decided_census)==237,'all current decided jobs/raw censuses')
need(not(R/'conditional-main-report-state-v5.json').exists()and not(R/'conditional-main-reader-request-v5.json').exists(),'final Root state/request still separate and absent')
for value in tuple(checked.values()):verify(value)
counts=dict(planned_jobs=34,qualified_jobs=16,failed_jobs=1,pending_jobs=17,training_episode_slots=32,training_returned=32,training_accepted_proof_occurrences=30,training_local_UNKNOWN=2,evaluation_slots=192,evaluation_returned=48,evaluation_accepted_proof_occurrences=48,evaluation_search_UNKNOWN=0,evaluation_whole_failure_unavailable_slots=8,evaluation_pending_slots=136,current_policy_bundles=8,eligible_proof_occurrences=80,eligible_primitive_rows=944,eligible_base_cards=1888,decided_actual_census_files=237)
checks=[('entire-open-N5-disposition-and-original-recipes','Exact16,702-byte offer uses schema3/report_version5, closedfalse, all34original ordered recipes and no C_review yet. Entire state canonical digest excludes only top-level C_review and equals e79b7fa5…. There are16QUALIFIED,oneFAILED and17PENDING, with no missing/duplicate/status-upgraded job.'),('all-current-positive-Root-C-and-output-evidence','All ten acquisition/training admissions/seals and six evaluation admissions bind current four-true gates, complete C actuals/five components, Source guards/censuses and raw exports/summaries. First and five-batch passive evaluation output reviews bind each current admission. No old result/policy adoption or evaluation seal.'),('preserved-negative-and-pending-population','The exact64fb429c… whole-negative decision and C failure/output reviews preserve fourfalse gates,resultnull,failurepin,nullqualifiedpeak and13rawfiles. Scientific_result isnull; no failed arm/proof/policy prefix supplies artifacts. Eight slots are whole-job unavailable,not UNKNOWN. All17independent future plans remain present and unconsumed,with136pending slots.'),('full-training-proofs-policies-and-evaluation-denominator','All32training descriptors and eight immutable policy bundles remain,with30accepted training proof occurrences and localUNKNOWN global2/global25. All192evalslots remain:48returnedaccepted,8whole-failureunavailable,136pending. Current complete packets support80proofoccurrences,944primitive rows and1888basecards,including32prior donor/training views and48evalviews. Whole Host/finite-region/current-owned Native blocks-empty and selected catalog owners join literally; no scientific replay.'),('honest-current-costs-and-exposed-scope','Every decided job observer sample,including the failed job once,is folded in original recipe order;nullqualifiedpeak is notfilled from RSS. Nested setup/arm/helper/QA clocks are notadded. The six evaluated jobs are exposed regressions/orders,not completed held-out comparisons,independent statistical replicas,new theorems or learning/GCTS/SOTA advantage evidence.'),('unchanged-reader4-and-separate-final-state-request','Reader4Source/API/template and full Source PASS remain exact. Its positive-only artifact boundary forwards failed jobs diagnostically while returning no science/proof/policy from them. This offer review binds the entire disposition digest; Root alone may add this typed C pin to a separate final state. Exact readerrequest,onceprojection,output/browser/package/publication and futureactual gates remain separate; C writes no Root state.')]
receipt=dict(schema='D21-C-main-report-population-review-v1',review_passed=True,report_version=5,protocol=protocol_pin,population_offer=offer_pin,population_disposition_sha256=disposition_sha,disposition_rows_sha256=digest(state['jobs']),closed=False,reader_Source=source_pin,reader_API=api_pin,reader_template=template_pin,reader_Source_review=source_review_pin,first_evaluation_admission_output_review=first_output_review_pin,five_evaluation_admission_output_review=five_output_review_pin,negative_disposition_output_review=negative_output_review_pin,counts=counts,current_decisions=current,eligible_proof_literal_counts=proofs,current_policy_bundles=policy_bundles,training_descriptor_sha256=digest(expected_episodes),evaluation_slot_descriptors_sha256=digest(eval_slots),decided_unique_observer_sample_seconds=total_seconds,phase_observer_sample_seconds=phase_seconds,checked_unique_current_pin_count=len(checked),checked_current_pins_sha256=digest(sorted(checked.values(),key=lambda q:q['path'])),checks=[dict(id=k,passed=True,finding=v)for k,v in checks],failures=[],partial_files_parsed=0,projector_invocations=0,helper_invocations=0,scientific_calls=0,Root_admission_issued=False,Root_state_written_by_C=False,scope='Exact N5OPEN reporting population offer/digest only. No final Rootstate/readerrequest/output/browser/package/publication or futureactual authority. Prior scientific reviews reused only by current raw equality; no subject replay.',review_program=pin(Path(__file__).resolve()),tools_idle_after_freeze=True)
out=C/'typed-open-N5-population-offer-review-v1.json'
with out.open('xb')as stream:stream.write((json.dumps(receipt,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode())
print(json.dumps(pin(out)));print(json.dumps(counts));print(total_seconds)
