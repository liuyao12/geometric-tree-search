"""Independent complete passive admission output joins; no subject invocation."""
from pathlib import Path
import hashlib,json
D=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-conditional-selector-main-20261021');R=D/'root';C=D/'review-C';ID='eval-eval-sharing-01-seed0';seen={}
def need(v,m):
 if not v:raise ValueError(m)
def wire(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def pin(p):
 p=Path(p);need(p.is_absolute() and p.resolve()==p and p.is_file() and not p.is_symlink(),'ordinary canonical file');b=p.read_bytes();q=dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
 if str(p)in seen:need(seen[str(p)]==q,'stable raw body')
 seen[str(p)]=q;return q
def verify(q):need(pin(q['path'])==q,'exact current pin');return q
def load(q):
 if isinstance(q,(str,Path)):q=pin(q)
 verify(q);need('.partial' not in Path(q['path']).name,'complete JSON only');return json.loads(Path(q['path']).read_bytes())
def passed(q):
 v=load(q);need(v['review_passed'] is True and v['checks'] and all(x['passed'] is True for x in v['checks']) and v['failures']==[],'independent allPASS');return v
manifest_pin=pin(R/'remaining16-evaluation-admission-outputs-v1.json')
need(manifest_pin['bytes']==18417 and manifest_pin['sha256']=='fc6a8cfafe9964803d024a92f45138e316a6bfcbf38de82b06bf514179c2cd52','exact offered output manifest')
manifest=load(manifest_pin);need(manifest['schema']=='D21-Root-remaining16-passive-admission-invocation-output-manifest-v1' and manifest['invocations']==16 and len(manifest['outputs'])==16,'sixteen Root-reported once outputs')
request_review_pin=manifest['C_request_review'];request_batch=passed(request_review_pin);need(request_review_pin['sha256']=='fd76929acc29fb1b57d7c00b2a6224f1d6f1487ae5dc926fb1f11e29c6cbfdaa','exact current sixteen-request composition review')
load(manifest['offer']);need([row['stage_id'] for row in manifest['outputs']]==[row['stage_id'] for row in request_batch['per_request']],'all sixteen original output identities/order')
results=[]
for offered in manifest['outputs']:
 ID=offered['stage_id'];invocation=load(offered['invocation']);need(invocation['process_exit_code']==0 and invocation['stage_id']==ID and invocation['stderr_utf8']=='','Root-reported terminal passive invocation')
 outpin=pin(R/'admission'/(ID+'-v1.json'));need(outpin==offered['admission'],'exact offered actual admission output')
 a=load(outpin);request=load(a['request']);actual=passed(a['C_actual_review']);rr=next(row for row in request_batch['per_request'] if row['stage_id']==ID);component=passed(rr['Source_component_review'])
 need(rr['request']==a['request']==offered['request'] and rr['C_actual_review']==a['C_actual_review'],'same exact approved request and current C actual')
 need(invocation['request']==a['request'] and invocation['C_request_review']==request_review_pin and invocation['argv']==rr['prospective_invocation'] and invocation['bootstrap']==rr['bootstrap_source'] and invocation['helper']==rr['evaluation_source'] and json.loads(invocation['stdout_utf8'])==outpin,'same exact reviewed isolated argv/current Sources/output stdout pin')
 verify(invocation['bootstrap']);verify(invocation['helper'])
 need(a['schema']=='D21-Root-conditional-stage-admission-v1' and a['stage_id']==ID and a['stage']=='evaluate' and all(a[k] is True for k in ('admitted','resource_admitted','scientific_qualified','stage_complete')),'exact positive output identity/four gates')
 need(a['helper']==component['evaluation_source'] and a['policy_freeze']==request['policy_freeze']==actual['final_policy_audit'] and a['protocol']==request['protocol']==actual['protocol'],'exact reviewed helper/audit/protocol')
 for q in component['input_pins']:verify(q)
 for k in ('plan','result','header','terminal','observer'):verify(a[k]);need(a[k]==request[k]==actual[k],'same five exact components')
 need(a['prior_admissions']==[pair['admission'] for pair in request['upstream']]==[pair['admission'] for pair in actual['upstream']],'exact ten ordered predecessor admissions')
 for pair in request['upstream']:
  for q in pair.values():verify(q)
 for q in actual['input_pins']+actual['complete_actual_file_census']:verify(q)
 need(a['complete_actual_file_census']==actual['complete_actual_file_census'],'same full current14-file census')
 worker=load(a['result']);science=worker['scientific_result'];case=science['records'][0];observer=load(a['observer'])
 need(a['whole_seconds']==actual['whole_seconds']==observer['elapsed_seconds'] and a['whole_peak_bytes']==actual['whole_peak_bytes']==observer['final_conservative_whole_peak_bytes'],'exact observer sample and peak')
 joined=a['literal_provenance'];need(joined['returned_summary_sha256']==actual['export_sha256']==hashlib.sha256(wire(science['export'])).hexdigest() and joined['frozen_policy_heads_sha256']==actual['frozen_policy_heads_sha256'],'summary/frozen-head digest output')
 need(len(joined['arms'])==len(case['arms'])==len(actual['arm_literal_joins'])==8,'all eight literal output arms')
 for saved,record,crow in zip(joined['arms'],case['arms'],actual['arm_literal_joins'],strict=True):
  need(saved['method']==record['id']==crow['id'] and saved['engine']==record['engine']==crow['engine'] and saved['selection']==record['selection']==crow['selection'],'exact actual arm identity/mode')
  need(saved['proof_accepted'] is record['proof_check']['native_proof_accepted'] and saved['proof_accepted'] is (crow['proof_rows']>0) and saved['proof_status']==crow['proof_status']==record['proof_check']['status'] and saved['search_status']==crow['search_status']==record['search']['status'],'exact accepted or local-UNKNOWN outcome rather than relabeling')
  if not saved['proof_accepted']:need(saved['proof_status']=='NO_PROOF_CANDIDATE' and saved['search_status']=='unknown_search_budget' and record['search']['proof'] is None and record['search']['placements']==[] and all(record['proof_check'][key] is None for key in ('host_check','region','native_record')),'localUNKNOWN has no substituted proof/Host/region/Native authority')
  expected=[dict(gate=row['gate'],trace_decision=row['trace_index'],status=row['status']) for row in crow['pool_joins']]
  need(saved['selector']==expected and saved['fallback']['completed_orderings']==crow['ordered_candidate_lists'] and saved['fallback']['decisions']==sum(row['event']=='decision' for row in record['search']['trace']),'full saved selector/fallback projection')
 need(joined['accepted_methods']==[record['id'] for record in case['arms'] if record['proof_check']['native_proof_accepted']] and joined['used_snapshot_ordinals']==list(range(len(worker['work_snapshots']))) and joined['unused_snapshot_count']==0,'exact ordered accepted-method subset and all current Root ordinals')
 need(all(type(a[k]) is int and a[k]==0 for k in ('scientific_imports','scientific_calls','numeric_RNG_Graph_checker_replays','partial_files_parsed')),'typed zero replay counters')
 need(not any(k in a for k in ('seal','export_sha256','policies','qualified')) and not (R/'seals'/(ID+'-v1.json')).exists(),'evaluation admission creates no policy or seal authority')
 for q in tuple(seen.values()):verify(q)
 checks=[('exact-positive-output-and-request-Source-binding',f'Full{outpin["bytes"]:,}-byte output has the exact offered hash, current reviewed request/helper/bootstrap dependencies and C actual receipt. Identity/schema/four positive gates, all five components, ten prior admissions and final policy audit match. Root reported once terminal invocation; C independently verifies saved output, not process execution.'),('literal-eight-arm-provenance-and-summary','All eight output arm identities/modes/accepted-versus-localUNKNOWN statuses, selector gate/raw-pool status projections, fallback decision/order counts, summary digest and frozen-head digest equal the independent whole actual review and raw complete result. All current Root ordinals are exact and no unused sample or arm is invented.'),('current-census-costs-and-limited-authority','All109 input guards and14 actual census pins remain exact; exact current observer elapsed and qualified peak are preserved. This is one original declared-stratum case/order;public authored input-structure holdouts remain not blind or proof-DAG-disjoint,and no comparative benefit is inferred.'),('no-evaluation-seal-policy-or-replay','Output contains typed zero replay counters and no policy/qualified/export-seal fields; no evaluation seal exists. C invokes no helper or scientific code. Separate future requests, actuals, report/population and publication gates remain. No failed prefix or other evaluation is adopted.')]
 receipt=dict(schema='D21-C-evaluation-admission-actual-output-review-v1',review_passed=True,stage_id=ID,admission_output=outpin,request=a['request'],exact_request_review=request_review_pin,Root_invocation=offered['invocation'],C_actual_review=a['C_actual_review'],Source_component_review=rr['Source_component_review'],helper_source=a['helper'],protocol=a['protocol'],policy_freeze=a['policy_freeze'],components={k:a[k] for k in ('plan','result','header','terminal','observer')},literal_provenance_sha256=hashlib.sha256(wire(joined)).hexdigest(),counts=dict(arms=8,accepted_proof_occurrences=len(joined['accepted_methods']),local_UNKNOWN=8-len(joined['accepted_methods']),Root_snapshots=len(worker['work_snapshots']),actual_census_files=14,guards=109),whole_seconds=a['whole_seconds'],whole_peak_bytes=a['whole_peak_bytes'],checks=[dict(id=k,passed=True,finding=v) for k,v in checks],failures=[],scientific_imports=0,scientific_calls=0,helper_invocations=0,subject_replays=0,partial_files_parsed=0,Root_admission_issued=False,scope='Independent actual passive Root admission output/current literal projection check only. Root is the admission issuer. No subject replay, new scientific qualification, later actual or reporting/publication authority.',review_program=pin(Path(__file__).resolve()),tools_idle_after_current_review_batch=True)
 results.append(receipt)
need(len({row['stage_id']for row in results})==16,'sixteen unique output stages')
need(sum(row['counts']['accepted_proof_occurrences'] for row in results)==120 and sum(row['counts']['local_UNKNOWN'] for row in results)==8,'preserved120accepted8localUNKNOWN under128returnedslots')
prior_negatives=[]
for identity,sha in [('eval-eval-quantified-02-seed0','64fb429c1271f8c2ef9cf44c86722271eb08e7c94edccf05403960ebca41ddd1'),('eval-eval-quantified-02-seed1','e9d48b3f68ae7a72a7992fe2b7176fcf0c1b3b8ebed23b16a9240c6f8aabe0d9')]:
 q=pin(R/'admission'/(identity+'-v1.json'));negative=load(q)
 need(q['sha256']==sha and negative['result'] is negative['whole_peak_bytes'] is None and all(negative[key] is False for key in ('admitted','resource_admitted','scientific_qualified','stage_complete')),'both prior wholefailures remain exact negatives')
 prior_negatives.append(q)
for q in tuple(seen.values()):verify(q)
receipt=dict(schema='D21-C-remaining16-evaluation-admission-actual-output-batch-review-v1',review_passed=True,manifest=manifest_pin,request_batch_review=request_review_pin,outputs=[row['admission_output'] for row in results],per_output=results,counts=dict(admission_outputs=16,returned_original_slots=128,accepted_proof_occurrences=120,local_UNKNOWN=8),prior_quantified02_Root_negatives=prior_negatives,checks=[dict(id='sixteen-exact-current-output-invocation-Source-request-C-bindings',passed=True),dict(id='all-eight-arm-acceptance-UNKNOWN-provenance-census-Root-summary-costs',passed=True),dict(id='no-evaluation-seal-policy-replay-or-whole-failure-prefix',passed=True)],failures=[],scientific_imports=0,scientific_calls=0,helper_invocations=0,subject_replays=0,partial_files_parsed=0,Root_admission_issued=False,scope='Independent sixteen actualpassive Rootadmission outputs only. Root is issuer;Cchecks exact complete current bindings/literalprojections.120accepted8localUNKNOWN remain distinct;priorwholefailuresstaynegative. No subject replay,lateractual,report/population orpublication authority.',review_program=pin(Path(__file__).resolve()),predecessor_review_program=pin(C/'passive_five_evaluation_admission_output_reviews_v1.py'),tools_idle_after_freeze=True)
output=C/'typed-remaining16-evaluation-admission-actual-output-batch-review-v1.json'
with output.open('xb') as stream:stream.write((json.dumps(receipt,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode())
print(json.dumps(pin(output)));print(json.dumps(dict(per_output_checks=4,outputs=16,aggregate_checks=3,failures=0,accepted=120,local_UNKNOWN=8,tools_idle=True)))
