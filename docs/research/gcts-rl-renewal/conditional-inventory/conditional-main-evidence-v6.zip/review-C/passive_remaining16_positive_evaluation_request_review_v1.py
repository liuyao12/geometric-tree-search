"""Exact passive admission request review; no helper import or invocation."""
from pathlib import Path
import ast
import hashlib
import json

D=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-conditional-selector-main-20261021')
C=D/'review-C'; R=D/'root'; B=D/'implementation-B'; STAGE='eval-eval-sharing-01-seed0'; checked={}
def need(value,message):
 if not value: raise ValueError(message)
def wire(value): return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def digest(value): return hashlib.sha256(wire(value)).hexdigest()
def pin(path):
 path=Path(path); need(path.is_absolute() and path.resolve()==path and path.is_file() and not path.is_symlink(),'ordinary canonical current file')
 body=path.read_bytes(); result=dict(path=str(path),bytes=len(body),sha256=hashlib.sha256(body).hexdigest())
 if str(path) in checked: need(checked[str(path)]==result,'stable raw identity')
 checked[str(path)]=result; return result
def verify(value): need(pin(value['path'])==value,'exact current raw pin'); return value
def load(value):
 if isinstance(value,(str,Path)): value=pin(value)
 verify(value); need('.partial' not in Path(value['path']).name,'only complete JSON'); return json.loads(Path(value['path']).read_bytes())
def passed(value):
 result=load(value); need(result['review_passed'] is True and result['checks'] and all(row['passed'] is True for row in result['checks']) and result['failures']==[],'nonempty all-passed independent review'); return result

manifest_pin=pin(R/'remaining16-evaluation-admission-request-offer-v1.json')
need(manifest_pin['bytes']==7427 and manifest_pin['sha256']=='7352e80a85af00c937589b666c0701a240cb30de3d4442bfbe9fc1a332b121cb','exact sixteen-request offer')
manifest=load(manifest_pin);need(manifest['schema']=='D21-Root-remaining16-exact-evaluation-admission-request-offer-v1' and manifest['request_count']==len(manifest['requests'])==16 and manifest['positive_helper_invocations']==0,'sixteen uninvoked original requests')
index=passed(manifest['C_actual_review_index']);need(manifest['C_actual_review_index']['sha256']=='ba8fbab62d5e27a2677524c04f93c01459c8008b2bf00cf352a76417eb3d4b42','exact current complete sixteen-actual index')
actual_rows={row['stage_id']:row for row in index['per_job']};need([row['stage_id'] for row in manifest['requests']]==[row['stage_id'] for row in index['per_job']],'all16 exact original stage order')
results=[]
for offered in manifest['requests']:
 STAGE=offered['stage_id']
 request_pin=pin(R/('evaluation-admission-request-'+STAGE+'-v1.json'))
 need(request_pin==offered['request'],'exact offered request')
 request=load(request_pin)
 need(set(request)=={'schema','protocol','plan','result','header','terminal','observer','C_actual_review','upstream','policy_freeze'} and request['schema']=='D21-passive-evaluation-admission-request-v1','exact ten-field positive-only evaluation ABI')
 component_review_pin=pin(C/'typed-evaluation-admission-and-isolated-bootstrap-Source-review-v1.json'); component=passed(component_review_pin)
 need(component_review_pin['sha256']=='e5c0ca449deae991f4cf7b6516c794c61e6e16d84d6bc4e0fb82f00a5f2f510b','current complete evaluator/bootstrap Source PASS')
 for value in component['input_pins']: verify(value)
 need(component['protocol']==request['protocol'],'same exact protocol')
 review=passed(request['C_actual_review'])
 need(request['C_actual_review']==actual_rows[STAGE]['C_actual_review'],'exact current full actual C review')
 need(review['schema']=='D21-C-conditional-stage-actual-review-v1' and review['stage_id']==STAGE and review['stage']=='evaluate' and all(review[key] is True for key in ('resource_admitted','scientific_qualified','stage_complete')) and review['Root_admission_issued'] is False and type(review['partial_files_parsed']) is int and review['partial_files_parsed']==0,'strict actual ABI and four positive gates')
 need(review['protocol']==request['protocol'],'same current actual protocol')
 for key in ('plan','result','header','terminal','observer'):
  verify(request[key]); need(request[key]==review[key],'same exact five complete current components')
 plan=load(request['plan']); protocol=load(request['protocol']); worker=load(request['result']); science=worker['scientific_result']; observer=load(request['observer'])
 need(plan['case_id']==STAGE and plan['stage']=='evaluate' and plan['protocol']==request['protocol'],'current whole evaluation plan')
 need(review['input_pins']==sorted(plan['files'],key=lambda value:value['path']) and len(plan['files'])==109,'actual input pins only complete current plan guards')
 for value in review['input_pins']+review['complete_actual_file_census']: verify(value)
 need(len(review['complete_actual_file_census'])==14,'complete current postterminal physical census')
 actual=D/'actual'/STAGE; outer=D/'actual'/(STAGE+'.observer')
 current_census=sorted([pin(path) for directory in (actual,outer) for path in directory.rglob('*') if path.is_file()],key=lambda value:value['path'])
 need(current_census==review['complete_actual_file_census'],'no changed or additional physical actual body')
 need(worker['status']=='COMPLETE' and worker['error'] is None and worker['source_unchanged'] is True and worker['first_Root_fault'] is False and science['stage_complete'] is science['job_record_complete'] is science['all_eight_searched'] is True and science['policies_updated'] is False,'current whole completed actual unchanged')
 need(review['whole_seconds']==observer['elapsed_seconds'] and review['whole_peak_bytes']==observer['final_conservative_whole_peak_bytes'] and observer['resource_candidate_accepted'] is True,'exact observer cost sample and original resource qualification')
 need(digest(science['export'])==review['export_sha256'] and science['export']['stage']=='evaluate' and 'qualified' not in science['export'] and 'policies' not in science['export'],'exact C summary digest, no qualified-policy export')
 records=science['records'][0]['arms'];need([record['id'] for record in records]==plan['Root_recipe']['method_order'],'all eight exact original ordered arms')
 accepted_count=sum(record['proof_check']['status']=='HOST_REGION_NATIVE_ACCEPTED' for record in records);unknown_count=sum(record['proof_check']['status']=='NO_PROOF_CANDIDATE' for record in records)
 need(accepted_count==review['counts']['accepted_proof_occurrences'] and unknown_count==review['counts']['UNKNOWN_arms'] and accepted_count+unknown_count==8,'exact accepted versus local-UNKNOWN population')
 for record in records:
  if record['proof_check']['status']=='NO_PROOF_CANDIDATE':need(record['search']['status']=='unknown_search_budget' and record['search']['proof'] is None and record['search']['placements']==[] and record['proof_check']['native_proof_accepted'] is False and all(record['proof_check'][key] is None for key in ('host_check','region','native_record')),'bounded local UNKNOWN stays unsolved with no proof authority')
 need(request['upstream']==review['upstream'] and len(request['upstream'])==10,'all ten original ordered pairs')
 freeze_review=passed(review['final_policy_review']); audit_review=passed(review['final_policy_audit_output_review'])
 need(request['policy_freeze']==review['final_policy_audit'],'exact actual-frozen audit pin')
 audit=load(request['policy_freeze']); need(audit['audit_only'] is audit['audit_complete'] is True and audit['protocol']==request['protocol'] and audit['predecessors']==request['upstream']==freeze_review['predecessors'] and audit['bundle']==freeze_review['bundle']==audit_review['bundle'],'same exact full final bundle and audit/C review')
 load(audit['request']); passed(audit['C_policy_review']); verify(audit['helper'])
 ids=['acquire-0','acquire-1']+['train-'+str(index) for index in range(8)]; cost=0.0
 for identity,pair in zip(ids,request['upstream'],strict=True):
  admission=load(pair['admission']); seal=load(pair['seal'])
  need(admission['stage_id']==seal['stage_id']==identity and all(admission[key] is True for key in ('admitted','resource_admitted','scientific_qualified','stage_complete')) and admission['seal']==pair['seal'],'complete current positive predecessor')
  need(len(seal)==13 and seal['resource_admitted'] is seal['stage_complete'] is True and seal['prior_cost_receipts']==[],'strict direct predecessor seal')
  prior=passed(admission['C_actual_review'])
  for key in ('plan','result','header','terminal','observer'): verify(seal[key]); need(seal[key]==admission[key]==prior[key],'complete exact predecessor components')
  for value in prior['input_pins']+prior['complete_actual_file_census']: verify(value)
  cost+=seal['whole_seconds']
 need(plan['upstream_receipts']==[pair['seal'] for pair in request['upstream']] and cost==248.2828798759947 and science['cumulative_costs']['whole_seconds']==cost,'original ordered ten-chain input and direct cost fold')
 bootstrap=verify(component['bootstrap_source']); evaluator=verify(component['evaluation_source']); support=verify(component['support_source']); base=verify(component['base_source'])
 bootstrap_ast=ast.parse(Path(bootstrap['path']).read_text()); compile(bootstrap_ast,bootstrap['path'],'exec')
 literal=next(ast.literal_eval(node.value) for node in bootstrap_ast.body if isinstance(node,ast.Assign) and any(isinstance(target,ast.Name) and target.id=='SOURCES' for target in node.targets))
 need(list(literal)==[(Path(value['path']).name,value['bytes'],value['sha256']) for value in (base,support,evaluator)],'same three exact isolated passive imports')
 python_pin=verify(plan['python'])
 invocation=[python_pin['path'],'-I','-S','-B',bootstrap['path'],'--request',request_pin['path']]
 target=R/'admission'/(STAGE+'-v1.json'); no_seal=R/'seals'/(STAGE+'-v1.json')
 need(not target.exists() and not no_seal.exists(),'exclusive positive admission target absent; no evaluation seal')
 for value in tuple(checked.values()): verify(value)
 need(not target.exists() and not no_seal.exists(),'final output absence')
 checks=[
  ('exact-request-current-component-Source-and-isolated-CLI',f'The exact{request_pin["bytes"]:,}-byte request has exactly the ten reviewed API fields and the current complete evaluator/bootstrap Source PASS. All bootstrap/base/support/evaluator/API pins remain unchanged. The prospective pinned-Python -I -S -B invocation names only the canonical current Root request and reviewed bootstrap; C does not import or call them.'),
  ('current-whole-actual-C-five-components-and-census','The request binds exact current five components and the full eight-check C actual PASS, four true gates, strict D21 actual ABI, sorted109 plan-only guards and unchanged14-file postterminal physical census. No partial input, missing arm or failed prefix is substituted. Existing full controls/model/trace/pool/Root/proof/current Native joins remain covered by current raw equality.'),
  ('ten-current-pairs-and-final-policy-audit','All ten original ordered admission/seal pairs remain current, positive and strict13-field; current C receipts/components/guards/censuses and costs rehash. The exact final-policy audit, its original request/helper/C policy receipt and independently reviewed complete bundle agree. It is Root request-level provenance, outside child guard/input authority.'),
  ('summary-digest-proof-population-and-cost-sample',f'The C export digest is the exact eight-outcome summary, not a qualified policy. The{accepted_count}accepted original-row-bound proof occurrences retain prior full evidence;the{unknown_count}bounded local point-search UNKNOWNs retain no proof/Host/region/Native authority. Current observer elapsed and peak are literal; final gate sample is distinct. Prior costs fold once to248.2828798759947; no nested-clock addition or comparative claim.'),
  ('exclusive-positive-output-and-separate-Root-invocation','The single fixed Root evaluation admission target is absent and no evaluation seal exists or is authorized. Helper is positive-only and must refuse whole/unresolved evidence; no earlier-arm salvage. This request composition review does not issue an admission, actual grant, retry, later-evaluation or Wang authority. Root alone owns the once passive invocation and separate output validation.')]
 receipt=dict(schema='D21-C-positive-evaluation-admission-request-review-v1',review_passed=True,stage_id=STAGE,request=request_pin,protocol=request['protocol'],Source_component_review=component_review_pin,C_actual_review=request['C_actual_review'],bootstrap_source=bootstrap,evaluation_source=evaluator,support_source=support,base_source=base,python=python_pin,prospective_invocation=invocation,components={key:request[key] for key in ('plan','result','header','terminal','observer')},upstream=request['upstream'],policy_freeze=request['policy_freeze'],final_policy_review=review['final_policy_review'],final_policy_audit_output_review=review['final_policy_audit_output_review'],export_sha256=review['export_sha256'],accepted_proof_occurrences=accepted_count,local_UNKNOWN=unknown_count,whole_seconds=review['whole_seconds'],whole_peak_bytes=review['whole_peak_bytes'],exclusive_output_path=str(target),evaluation_seal_path_absent=str(no_seal),checks=[dict(id=key,passed=True,finding=finding) for key,finding in checks],failures=[],scientific_imports=0,scientific_calls=0,helper_imports=0,helper_invocations=0,subject_replays=0,partial_files_parsed=0,Root_admission_issued=False,grants_issued=0,scope='Exact current original positive evaluation admission request/isolated invocation composition only. No subject invocation, Root admission or later actual authority. Existing whole actual evidence reused only by current exact raw equality.',review_program=pin(Path(__file__).resolve()),tools_idle_after_freeze=True)
 results.append(receipt)
need(len({row['stage_id'] for row in results})==16,'all sixteen unique exact current requests')
need(sum(row['accepted_proof_occurrences'] for row in results)==120 and sum(row['local_UNKNOWN'] for row in results)==8,'exact128 slots preserve120accepted8UNKNOWN')
prior_negatives=[]
for identity,sha in [('eval-eval-quantified-02-seed0','64fb429c1271f8c2ef9cf44c86722271eb08e7c94edccf05403960ebca41ddd1'),('eval-eval-quantified-02-seed1','e9d48b3f68ae7a72a7992fe2b7176fcf0c1b3b8ebed23b16a9240c6f8aabe0d9')]:
 q=pin(R/'admission'/(identity+'-v1.json'));negative=load(q)
 need(q['sha256']==sha and negative['result'] is negative['whole_peak_bytes'] is None and all(negative[key] is False for key in ('admitted','resource_admitted','scientific_qualified','stage_complete')),'both prior whole-negative decisions unchanged')
 prior_negatives.append(q)
for q in tuple(checked.values()):verify(q)
receipt=dict(schema='D21-C-remaining16-positive-evaluation-admission-request-batch-review-v1',review_passed=True,manifest=manifest_pin,C_actual_review_index=manifest['C_actual_review_index'],requests=[row['request'] for row in results],per_request=results,counts=dict(requests=16,returned_original_slots=128,accepted_proof_occurrences=120,local_UNKNOWN=8,output_paths_absent=16),prior_quantified02_Root_negatives=prior_negatives,checks=[dict(id='all-sixteen-exact-ten-field-request-compositions',passed=True),dict(id='all-current-Source-C-custody-pool-summary-freeze-joins',passed=True),dict(id='all-sixteen-outputs-absent-and-UNKNOWN-negatives-preserved',passed=True)],failures=[],scientific_calls=0,scientific_imports=0,helper_invocations=0,partial_files_parsed=0,Root_admission_issued=False,scope='Sixteen exact positive-only passive request compositions;120accepted8localUNKNOWN remain distinct. Bothpriorwholefailures staynegative. Root-only once isolated invocations and separate outputvalidation remain;no scientific replay or admission byC.',review_program=pin(Path(__file__).resolve()),predecessor_review_program=pin(C/'passive_five_positive_evaluation_request_review_v1.py'),tools_idle_after_current_review_batch=True)
output=C/'typed-remaining16-positive-evaluation-admission-request-batch-review-v1.json'
with output.open('xb') as stream:stream.write((json.dumps(receipt,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode())
print(json.dumps(pin(output)));print(json.dumps(dict(per_request_checks=5,requests=16,aggregate_checks=3,failures=0,accepted=120,local_UNKNOWN=8,tools_idle=True)))
