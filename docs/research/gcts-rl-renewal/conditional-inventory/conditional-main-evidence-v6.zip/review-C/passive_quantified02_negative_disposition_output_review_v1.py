"""Raw negative Root disposition output review; no admission or subject replay."""
from pathlib import Path
import hashlib,json
D=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-conditional-selector-main-20261021');R=D/'root';C=D/'review-C';ID='eval-eval-quantified-02-seed0';seen={}
def need(v,m):
 if not v:raise ValueError(m)
def pin(p):
 p=Path(p);need(p.is_absolute() and p.resolve()==p and p.is_file() and not p.is_symlink(),'ordinary canonical file');b=p.read_bytes();q=dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
 if str(p)in seen:need(seen[str(p)]==q,'stable current pin')
 seen[str(p)]=q;return q
def verify(q):need(pin(q['path'])==q,'exact raw pin');return q
def load(q):
 if isinstance(q,(str,Path)):q=pin(q)
 verify(q);need('.partial'not in Path(q['path']).name,'complete JSON only');return json.loads(Path(q['path']).read_bytes())
outpin=pin(R/'admission'/(ID+'-v1.json'));need(outpin['bytes']==6678 and outpin['sha256']=='64fb429c1271f8c2ef9cf44c86722271eb08e7c94edccf05403960ebca41ddd1','exact offered negative output')
a=load(outpin);c=load(a['C_actual_review'])
need(a['C_actual_review']['bytes']==49390 and a['C_actual_review']['sha256']=='bcbd2371b98edf5ff8ea67ea05ddf9955cfb6e0059c7852c4c3e4b72c4564a95','exact independent whole failure review')
need(c['review_passed']is True and c['checks']and all(row['passed']is True for row in c['checks'])and c['failures']==[],'supported negative classification')
need(a['schema']=='D21-Root-conditional-stage-admission-v1'and a['stage_id']==c['stage_id']==ID and a['stage']==c['stage']=='evaluate','exact negative schema/identity')
need(all(a[key]is False for key in ('admitted','resource_admitted','scientific_qualified','stage_complete'))and all(c[key]is False for key in ('resource_admitted','scientific_qualified','stage_complete')),'all four Root gates false')
need(a['result']is c['result']is None and a['failure']==c['failure']and a['whole_peak_bytes']is c['whole_peak_bytes']is None,'null result/qualified peak and exact complete failure')
for key in ('plan','failure','header','terminal','observer','protocol'):verify(a[key]);need(a[key]==c[key],'same current failed components/protocol')
need(a['complete_actual_file_census']==c['complete_actual_file_census']and len(a['complete_actual_file_census'])==13,'same complete13rawfile census')
for value in c['input_pins']+c['complete_actual_file_census']:verify(value)
actual=D/'actual'/ID;outer=D/'actual'/(ID+'.observer')
census=sorted([pin(path)for directory in(actual,outer)for path in directory.rglob('*')if path.is_file()],key=lambda q:q['path'])
need(census==c['complete_actual_file_census']and not any('.partial'in Path(q['path']).name for q in census),'exact unchanged physical census/no partial')
w=load(a['failure']);o=load(a['observer']);t=load(a['terminal']);h=load(a['header'])
need(w['scientific_result']is None and w['first_Root_fault']is True and w['error']['type']==a['error']['type']=='RootBudget'and w['error']['message']==a['error']['message']=='absolute case work deadline','same whole fault with no returned scientific prefix')
need(a['disposition']=='WHOLE_JOB_WORK_DEADLINE_FAILURE'and type(a['arms'])is str and a['arms']=='All eight original slots unavailable due to whole-job failure; no arm or proof admitted.','explanatory unavailable text only, no structured arm/proof payload')
need(a['whole_seconds']==c['whole_seconds']==o['elapsed_seconds']==160.84695704100886 and o['final_conservative_whole_peak_bytes']is None,'literal failed-job cost and null qualified peak')
need(o['resource_candidate_accepted']is False and t['process_exit_code']==o['parent_exit_code']==2 and h['native_closed_and_reaped']is t['threads_terminal']is True and w['native_transport']['closed']is w['native_transport']['all_reaped']is True,'same reviewed failure and completed cleanup')
need(all(type(a[key])is int and a[key]==0 for key in ('scientific_imports','scientific_calls','numeric_RNG_Graph_checker_replays','partial_files_parsed')),'typed zero replay counters')
need(not any(key in a for key in ('seal','helper','request','export_sha256','policies','qualified','literal_provenance'))and not(actual/'result.json').exists()and not(R/'seals'/(ID+'-v1.json')).exists(),'no positive helper/request/export/seal or prefix authority')
for value in tuple(seen.values()):verify(value)
checks=[('exact-negative-output-C-and-components','The exact6,678-byte Root output binds the current independent five-check whole-failure receipt and exact plan/failure/header/terminal/observer/protocol pins. All13physical files and109guard pins remain current; no partial is present or parsed.'),('four-false-gates-null-result-and-qualified-peak','Admitted/resource/scientific/stage gates are allfalse, result isnull, complete failurepin is exact and qualified whole peak staysnull. Observer elapsed160.84695704100886 is preserved. No Python/native RSS sample is relabeled as a qualified peak or measured memory exceedance.'),('whole-failure-no-arm-or-seal-salvage','Sticky work-deadline error and null scientific_result remain exact. The arms field is explanatory text only: no structured arm, proof, model or outcome prefix is admitted. No positive helper/request/export/policy/seal fields or result/evaluation seal file exists. Native and terminal cleanup facts match the independent review.'),('Root-negative-only-and-future-barrier','Root is the negative-disposition issuer; C only validates saved output. Remaining17original evaluation plans remain pending and independent, without retry, cohort shrink, Source/cap change or automatic grant. A fresh explicit Root cleanup/tools-idle barrier is still required before any future actual.')]
receipt=dict(schema='D21-C-whole-failure-negative-disposition-output-review-v1',review_passed=True,stage_id=ID,Root_negative_output=outpin,C_whole_failure_review=a['C_actual_review'],protocol=a['protocol'],components={key:a[key]for key in('plan','failure','header','terminal','observer')},result=None,resource_admitted=False,scientific_qualified=False,stage_complete=False,admitted=False,whole_seconds=a['whole_seconds'],whole_peak_bytes=None,complete_actual_file_census=a['complete_actual_file_census'],checks=[dict(id=k,passed=True,finding=v)for k,v in checks],failures=[],scientific_imports=0,scientific_calls=0,helper_invocations=0,subject_replays=0,partial_files_parsed=0,Root_admission_issued=False,scope='Independent exact Root negative-output preservation review only. Review PASS confirms the supported whole failure; no stage/arm/proof/policy is qualified. No helper/scientific invocation, retry or future actual authority.',review_program=pin(Path(__file__).resolve()),tools_idle_after_freeze=True)
out=C/'typed-quantified02-negative-disposition-actual-output-review-v1.json'
with out.open('xb')as stream:stream.write((json.dumps(receipt,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode())
print(json.dumps(pin(out)))
