"""Complete failed-job/custody diagnosis only; no scientific prefix adoption."""
from pathlib import Path
import collections,hashlib,json
D=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-conditional-selector-main-20261021');R=D/'root';C=D/'review-C';ID='eval-eval-quantified-02-seed1';seen={}
def need(v,m):
 if not v: raise ValueError(m)
def wire(v): return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def pin(p):
 p=Path(p);need(p.is_absolute() and p.resolve()==p and p.is_file() and not p.is_symlink(),'ordinary canonical file');b=p.read_bytes();q=dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
 if str(p) in seen: need(seen[str(p)]==q,'stable raw body')
 seen[str(p)]=q;return q
def verify(q): need(pin(q['path'])==q,'exact raw pin');return q
def load(p):
 if type(p)is dict: verify(p);p=p['path']
 need('.partial' not in Path(p).name,'complete JSON only');pin(p);return json.loads(Path(p).read_bytes())
a=D/'actual'/ID;o=D/'actual'/(ID+'.observer')
parts={k:pin(p) for k,p in dict(plan=R/'plans'/(ID+'-v1.json'),failure=a/'failure.json',header=a/'worker-header.json',terminal=a/'terminal.json',observer=o/'observer.json').items()}
offered=dict(failure=(524922,'9f22b1c50230cc01a58177d5cd5f85f7ca5b8987fabb81a127da625aa9cad6f1'),header=(604,'d72819035584708bb742df573d5197f2bbfb3a8ae845641b36af2f0968987cd3'),terminal=(1769,'48f4cdf503120e8decfa05149b5c1cfb37a24f985b4c950a95948d074047a7da'),observer=(1495,'9881345794a179e283bf737f1eaf56159b4af6c5fb921777c7c4035053a75398'))
for k,v in offered.items():need((parts[k]['bytes'],parts[k]['sha256'])==v,'exact offered complete failure component')
p=load(parts['plan']);w=load(parts['failure']);h=load(parts['header']);t=load(parts['terminal']);v=load(parts['observer']);protocol=load(p['protocol'])
batchpin=pin(C/'typed-remaining23-evaluation-whole-prospective-Source-plan-review-v1.json');batch=load(batchpin)
need(batchpin['sha256']=='32399b45e2e83c2ae332cd817df21363afa986a2419ae2ac8c0a7f0ef9ed122f' and batch['review_passed'] is True and parts['plan'] in batch['plans'],'exact original reviewed failed-job plan')
need(p['Root_recipe']==next(x for x in protocol['job_recipes'] if x['stage_id']==ID) and p['Root_recipe']['method_order']==['SU','SF','S0','PR','PU','PF','P0','SR'] and p['Root_recipe']['order_label']==1 and p['Root_recipe']['exact_rows']==11,'original first arm/order/caps')
need(len(p['files'])==len({x['path'] for x in p['files']})==109,'full unchanged109guard closure')
for q in p['files']:verify(q)
continuation_pin=pin(C/'typed-next-original-quantified02-seed1-current-continuation-review-v1.json');continuation=load(continuation_pin)
need(continuation_pin['sha256']=='7a54bbf17a60969224132d24134bc52339fb3abd1a0d4dfc82c90dcc3adbcf78' and continuation['review_passed'] is True and continuation['plan']==parts['plan'] and continuation['earlier_evaluation_success_required'] is False,'exact current independent-stage continuation review')
grantpin=pin(R/'grants'/(ID+'-v1.json'));g=load(grantpin);barrierpin=g['serial_barrier'];barrier=load(barrierpin);cons=load(a/'CONSUMED.json');owner=load(a/'owned-child.json')
need(g['authorized'] is g['review_passed'] is True and g['uses']==1 and g['plan_sha256']==parts['plan']['sha256'] and g['prospective_review']==continuation_pin and cons['grant_sha256']==grantpin['sha256'] and cons['plan_sha256']==parts['plan']['sha256'] and cons['uses']==1,'once current grant/consumption')
need(barrier['stage_id']==ID and barrier['peer_tools_idle_since_checkpoint'] is barrier['owned_browser_tools_idle'] is barrier['network_tools_idle'] is True and barrier['other_experimental_sessions_running'] is False,'Root-labeled serial barrier')
verify(barrier['window_checkpoint'])
need(w['case_id']==h['case_id']==t['case_id']==v['case_id']==ID and w['stage']=='evaluate','current exact failed identity')
need(w['status']==h['status']=='FAILED_CASE_NOT_ADMITTED' and w['source_unchanged'] is h['source_unchanged'] is t['sources_unchanged'] is True and w['first_Root_fault'] is h['first_Root_fault'] is True,'sticky whole fault and unchanged Source')
need(w['error']['type']=='RootBudget' and w['error']['message']=='absolute case work deadline' and w['scientific_result'] is None,'exact first fault/no scientific carrier')
need(h['result']==parts['failure'] and t['header']==h and t['result'] is None and t['header_valid'] is False and t['process_exit_code']==v['parent_exit_code']==2 and v['resource_candidate_accepted'] is False,'failed COMPLETE/resource gates without result substitution')
need(t['threads_terminal'] is t['final_custody_gate_passed'] is h['native_closed_and_reaped'] is True and t['errors']==v['errors']==[] and t['reason'] is v['reason'] is None and v['fallback_trigger_seconds'] is None,'complete bounded terminal/custody closure')
need(t['known_exit_seconds']<=180 and t['final_custody_gate_seconds']<=210 and v['final_observer_gate_seconds']<=210 and t['conservative_combined_peak_bytes'] is v['final_conservative_whole_peak_bytes'] is v['conservative_whole_peak_bytes'] is None,'original cleanup deadlines and null qualified peak')
for outer in (t,v):
 for log in outer['logs'].values():need(log['eof'] is True and log['overflow'] is False and log['bytes']==log['stored']<=4194304,'bounded complete logs')
need(load(o/'stdout.bin')==t and v['owned_child']==owner and owner['plan_sha256']==parts['plan']['sha256'],'outer exact terminal/owner binding')
transport=w['native_transport'];queries=w['native_queries'];stages=transport['request_stages']
need(w['native_requests_started']==136 and len(queries)==transport['complete_records']==135 and len(stages)==136,'one unresolved current Native start retained')
need(transport['closed'] is transport['all_reaped'] is transport['stdout_eof'] is transport['stderr_complete'] is True and transport['cleanup_errors']==[] and transport['native_exit_code']==-15 and transport['termination_signals']==[15] and transport['wait4_status']==15,'Native SIGTERM wait/reap/EOF cleanup, not accepted completion')
need(transport['parent_pid']==transport['parent_pgid']==transport['native_pgid']==owner['child_pid']==owner['child_pgid'],'same owned process group')
for ordinal,(q,s) in enumerate(zip(queries,stages[:135],strict=True)):
 need(q['id']==s['ordinal']==s['record_id']==ordinal and s['stage']=='COMPLETED' and s['limit']==1000000000 and q['request_sha256']==hashlib.sha256(wire(q['request'])).hexdigest(),'all complete Native prefix records literal membership')
 need(all(q[k]==s[k] for k in ('purpose','request_sha256','input_sha256','output_sha256')) and q['request']['blocks']==[] and q['request']['protocol']=='gcts-fol-1','owned full flat current request/transport')
pending=stages[-1];need(pending['ordinal']==135 and pending['stage']=='SENT' and pending['purpose']=='conditional_evaluation_eval-quantified-02_SF' and 'record_id' not in pending and 'output_sha256' not in pending and pending['limit']==1000000000,'pending second prescribed SF final check remains unresolved')
need(pin(a/'native/input.bin')['sha256']==pending['input_sha256'],'raw current pending input ownership without decoding')
need(pin(a/'native/boundary-oracle')['sha256']=='2b6bf8bb09a4e03d0cb1b4595dea1fe6d4432aa93d8f7eed72c30077fd9941a4' and pin(a/'native/code.bin')['sha256']=='97f0b600cffd83552c4e0f0c4fb1f5d26cfdb76e3e74b267bbaebeddc836e7ed','exact fixed Native identities')
need(len(w['guard_compilations'])==1,'one retained compiler diagnostic ledger');ledger=w['guard_compilations'][0]
need(ledger['complete'] is True and ledger['status']=='complete' and ledger['resolved']==len(ledger['members'])==155 and ledger['unresolved']==0 and ledger['active_query'] is None,'compiler completed before later whole work failure')
for q in ledger['query_records']:need(q==queries[q['id']],'current diagnostic compiler records only')
for member in ledger['members']:
 q=queries[member['native_query']];need(member['status']==q['result']['status'] and q['request']['proof'][member['native_row']]==member['command'],'retained resolved member mapping, no model/arm authority')
trace=w['error']['traceback'];need(all(text in trace for text in ('run_conditional_stage','_conditional_search_and_check','_finish_selector_proof','_read_line','absolute case work deadline')),'full saved stack locates final Native wait after search')
need(all(x['status']=='COMPLETED' for x in w['stages'][:-1]) and w['stages'][-1]['status']=='STARTED','whole scientific stage never returned')
census=sorted([pin(path) for directory in (a,o) for path in directory.rglob('*') if path.is_file()],key=lambda q:q['path'])
need(len(census)==13 and not any('.partial' in Path(q['path']).name for q in census) and sum(q['bytes'] for q in census)<=134217728,'complete13rawfile census/no partial parse')
need(not (a/'result.json').exists() and not (R/'admission'/(ID+'-v1.json')).exists() and not (R/'seals'/(ID+'-v1.json')).exists(),'no result/admission/seal or prefix adoption')
remaining=[x for x in protocol['job_recipes'][18:] if x['stage']=='evaluate'];need(len(remaining)==16,'original16later independent evaluation recipes')
for recipe in remaining:
 identity=recipe['stage_id'];need((R/'plans'/(identity+'-v1.json')).is_file(),'original already-materialized plan retained')
 need(all(not path.exists() for path in (D/'actual'/identity,D/'actual'/(identity+'.observer'),R/'grants'/(identity+'-v1.json'),R/'admission'/(identity+'-v1.json'))),'remaining16actual/grant/admission paths absent')
for q in tuple(seen.values()):verify(q)
packet_pin=pin(R/'original-quantified02-seed1-terminal-packet-v1.json');packet=load(packet_pin)
need((packet_pin['bytes'],packet_pin['sha256'])==(6385,'478e6db9fd9048c8121ff10676cafca67e67628ad435da3c61c5dc6f1d5460b5'),'exact Root terminal review offer')
need(all(packet[key]==parts[key] for key in parts) and packet['grant']==grantpin and sorted(packet['complete_raw_census'],key=lambda q:q['path'])==census and packet['partial_raw_pins']==[] and packet['process_exit_code']==2 and packet['serial_window_stopped'] is True,'Root offer exact components and full current census')
need((parts['plan']['bytes'],parts['plan']['sha256'])==(38348,'5cf53ce1dc127a17626e11fb7310487161b686396388796ba635ae895ebee002'),'exact original unchanged seed1plan')
need(g['runner_sha256']=='98c55321bb87a8c04b2c6d56b357aba9c3a8f5fc98660474ae3ac1c9d00b0aca' and barrier['current_continuation_review']==continuation_pin and barrier['previous_resource_positive_required'] is False and barrier['previous_whole_failure_preserved'] is True and barrier['previous_qualified_peak'] is None and barrier['owned_preview_tools_idle'] is True,'new Root barrier preserves independent-job semantics and prior failure')
window=load(barrier['window_checkpoint']);need(window['current_continuation_review']==continuation_pin and window['stop_window_on_any_whole_failure'] is True and window['per_case_fresh_barrier_and_once_grant_required'] is True,'fresh resumed Root tools-idle window,not old positive-prior script')
need(transport['same_owned_process_group'] is True and owner['parent_pid']==7699 and owner['child_pid']==owner['child_pgid']==7700 and transport['native_pid']==7701,'exact current owned custodian/worker/group/Native identities')
counts=dict(collections.Counter(q['result']['status'] for q in queries));purposes=dict(collections.Counter(q['purpose'] for q in queries))
need(counts==dict(accepted=10,rejected=125),'literal Native status census')
need(purposes=={'first_order_theory_admission':1,'first_order_zero_read_batch':133,'conditional_evaluation_eval-quantified-02_SU':1},'literal complete purpose census,not arm qualification')
need(queries[-1]['id']==134 and queries[-1]['purpose']=='conditional_evaluation_eval-quantified-02_SU' and queries[-1]['result']['status']=='accepted','raw SU-purpose query retained diagnostically only')
for q in queries:
    need(q['query_target']=='fixed_assertion' and q['result']['start']==88986 and q['result']['micro_fnv64']=='14087427401139407292' and type(q['result']['micro_steps']) is int and 0<=q['result']['micro_steps']<=p['experiment_limits']['native_steps'],'fixed Native entry/micro identity and original query budget')
need(w['native_requests_started']<=p['experiment_limits']['compile_queries'] and p['limits']==batch['limits'] and p['experiment_limits']==batch['experiment_limits'],'all original outer/local/global Native caps unchanged')
need(v['elapsed_seconds']==160.8284132500121 and v['final_observer_gate_seconds']==160.82865216700884 and ledger['seconds']==131.32466583300265,'distinct direct observer and completed compiler samples')
need(len(ledger['query_records'])==134,'full compiler query count')
prior_negative_pin=pin(R/'admission/eval-eval-quantified-02-seed0-v1.json');prior_negative=load(prior_negative_pin)
prior_failure_review_pin=pin(C/'typed-first-quantified02-whole-failure-actual-review-v1.json');verify(prior_negative['C_actual_review'])
need(prior_negative_pin['sha256']=='64fb429c1271f8c2ef9cf44c86722271eb08e7c94edccf05403960ebca41ddd1' and prior_negative['C_actual_review']==prior_failure_review_pin and prior_negative['result'] is prior_negative['whole_peak_bytes'] is None and all(prior_negative[key] is False for key in ('admitted','resource_admitted','scientific_qualified','stage_complete')),'previous failed seed0 stays fourfalse/null,result and no rescue')
for q in tuple(seen.values()):verify(q)
checks=[
 ('exact-current-once-plan-source-grant-barrier-and-census','All109guardpins,exact original seed1plan/recipe/11rows/eightmethods/order/RNG/caps and current continuation PASS join. Freshone-usegrant/CONSUMED and newbarrier/windowcheckpoint match the plan;priorresource-positive evaluation is not required. ExactRootterminalpacket and13currentcomplete rawfiles match,with no partial path or result/admission/seal.'),
 ('sticky-deadline-after-complete-compiler-no-whole-science','The saved firstfault is RootBudget absolutecaseworkdeadline with scientific_resultnull and wholeRUNstageSTARTED. Compilerledger completed155/155members,unresolved0 before the later finalNative wait;pendingordinal135 purpose is secondprescribedSF. This is not setup-only failure or a returned accepted/UNKNOWNarm. No controls/model/region/arm/proof/export prefix is reconstructed or admitted.'),
 ('current-owned-Native-records-program-budget-and-cleanup','136Native starts retain135complete records,10accepted/125rejected,and oneSENTrequest without output/record. Completepurposes are1theory,133compilerbatch and1SU;rawSUacceptance remains diagnostic,not an arm/proof. Requestdigest/fullflatblocks-empty/currenttransport/querytarget/fixedentry/microidentity/1e9budget and nativeexecutable/code/input rawpins join. NativeSIGTERM15/wait4,reaped/closed,ownedgroup,allEOF,threads andcleanup are complete.'),
 ('whole-resource-false-null-peak-and-distinct-costs','Workerexit2/failedCOMPLETEgate andobserverresourcefalse are preserved;qualifiedwholepeak staysnull,not diagnosticRSS or measuredmemoryexceedance. Directobserverelapsed160.8284132500121 andfinalgate160.82865216700884 remain distinct;completedcompiler131.32466583300265 is nested andnotadded. Originalpositive/custody/log/physical bounds andfull13-filecensus join.'),
 ('all-eight-unavailable-prior-negative-and-full-population','All8currentarm slots are UNAVAILABLE_WHOLE_JOB_WORK_FAILURE,with no science/proof/policy/nativeprefixsalvage. Seed0exactRootnegative remainsfourfalse/resultnull/peaknull. Tenacquisition/train prerequisites remain unchanged throughcurrent109guards/currentcontinuation;16lateroriginalplans remain unconsumed,pending128slots,not dependencyfailures or cohortshrink. C issues no Rootadmission,grant,retry or cap/Sourcechange.')]
receipt=dict(schema='D21-C-conditional-stage-actual-review-v1',stage_id=ID,stage='evaluate',review_passed=True,resource_admitted=False,scientific_qualified=False,stage_complete=False,plan=parts['plan'],result=None,failure=parts['failure'],header=parts['header'],terminal=parts['terminal'],observer=parts['observer'],protocol=p['protocol'],export_sha256=None,input_pins=sorted(p['files'],key=lambda q:q['path']),complete_actual_file_census=census,whole_seconds=v['elapsed_seconds'],whole_peak_bytes=None,Root_terminal_packet=packet_pin,prospective_review=continuation_pin,prior_whole_prospective_review=batchpin,prior_Root_negative=prior_negative_pin,grant=grantpin,serial_barrier=barrierpin,resumed_window=barrier['window_checkpoint'],consumed=pin(a/'CONSUMED.json'),owned_child=pin(a/'owned-child.json'),diagnosis=dict(error=w['error'],scientific_result=None,Native_starts=136,Native_complete_records=135,Native_status_counts=counts,Native_complete_purposes=purposes,pending_native=pending,compiler_members=155,compiler_query_records=134,compiler_seconds=ledger['seconds'],Root_snapshots_diagnostic_only=len(w['work_snapshots']),final_observer_gate_seconds=v['final_observer_gate_seconds'],cleanup_complete=True,qualified_whole_peak_bytes=None,raw_completed_SU_query_is_not_arm_admission=True),arms=[dict(id=method,disposition='UNAVAILABLE_WHOLE_JOB_WORK_FAILURE',scientific_result=None) for method in p['Root_recipe']['method_order']],remaining16_stage_ids=[x['stage_id'] for x in remaining],checks=[dict(id=k,passed=True,finding=x) for k,x in checks],failures=[],scientific_calls=0,scientific_imports=0,helper_invocations=0,subject_replays=0,partial_files_parsed=0,Root_admission_issued=False,scope='Independent complete negative wholeactual/custody/cleanup classification only. review_passed means classification supported;resource/science/stagegatesfalse. No diagnosticNative/model/arm/proof/library/policy prefixadoption,retry,rescue or changedbounds. Rootnegative disposition andfreshbarrier/grants forremainingoriginalindependentjobs remain separate.',review_program=pin(Path(__file__).resolve()),preserved_prior_failure_review_program=pin(C/'passive_quantified02_whole_failure_review_v1.py'),tools_idle_after_current_review_batch=True)
out=C/'typed-second-quantified02-whole-failure-actual-review-v1.json'
with out.open('xb') as stream:stream.write((json.dumps(receipt,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode())
print(json.dumps(pin(out)));print(json.dumps(dict(checks=len(checks),failures=0,Native_starts=136,Native_complete=135,Native_status_counts=counts,pending_purpose=pending['purpose'],qualified_peak=None,tools_idle=True)))
