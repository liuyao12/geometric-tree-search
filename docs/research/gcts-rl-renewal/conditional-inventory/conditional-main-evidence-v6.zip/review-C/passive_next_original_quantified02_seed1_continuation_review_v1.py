"""Literal prospective plan batch review only; no helper or scientific calls."""
from pathlib import Path
import collections
import hashlib
import json

D=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-conditional-selector-main-20261021')
R=D/'root'; C=D/'review-C'; checked={}
IDS=['acquire-0','acquire-1']+['train-'+str(i) for i in range(8)]
METHODS=['S0','SF','SU','SR','P0','PF','PU','PR']
FIRST='eval-eval-sharing-01-seed0'
def need(value,message):
 if not value: raise ValueError(message)
def wire(value): return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def same(a,b): return wire(a)==wire(b)
def pin(path):
 path=Path(path); need(path.is_absolute() and path.resolve()==path and path.is_file() and not path.is_symlink(),'canonical ordinary file')
 body=path.read_bytes(); result=dict(path=str(path),bytes=len(body),sha256=hashlib.sha256(body).hexdigest())
 if str(path) in checked: need(checked[str(path)]==result,'stable current raw body')
 checked[str(path)]=result; return result
def verify(value): need(pin(value['path'])==value,'exact current raw pin'); return value
def load(value):
 if isinstance(value,(str,Path)): value=pin(value)
 verify(value); need('.partial' not in Path(value['path']).name,'complete JSON only'); return json.loads(Path(value['path']).read_bytes())
def passed(value):
 result=load(value); need(result['review_passed'] is True and result['checks'] and all(row['passed'] is True for row in result['checks']) and result['failures']==[],'nonempty independent PASS'); return result

TARGET='eval-eval-quantified-02-seed1';FAILED='eval-eval-quantified-02-seed0'
plan_pin=pin(R/'plans'/(TARGET+'-v1.json'));plan=load(plan_pin)
need((plan_pin['bytes'],plan_pin['sha256'])==(38348,'5cf53ce1dc127a17626e11fb7310487161b686396388796ba635ae895ebee002'),'exact original pending plan')
batch_pin=pin(C/'typed-remaining23-evaluation-whole-prospective-Source-plan-review-v1.json');batch=passed(batch_pin)
need(batch_pin['sha256']=='32399b45e2e83c2ae332cd817df21363afa986a2419ae2ac8c0a7f0ef9ed122f','unchanged whole23 prospective review')
prior_plan=next(row for row in batch['per_plan'] if row['stage_id']==TARGET)
need(prior_plan['plan']==plan_pin and prior_plan['failures']==[] and all(row['passed'] is True for row in prior_plan['checks']),'same exact previously approved original plan')
protocol=load(batch['protocol']);need(plan['protocol']==batch['protocol'] and batch['protocol']['sha256']=='c04ff4523941d5552b6ffee42f73d8a5c189191ea1004b82fc28d0122b3e7422','unchanged original protocol')
recipe=next(row for row in protocol['job_recipes'] if row['stage_id']==TARGET)
need(plan['Root_recipe']==recipe and plan['stage']=='evaluate' and plan['case_id']==TARGET and recipe['exact_rows']==11 and recipe['case_id']=='eval-quantified-02' and recipe['order_label']==1 and recipe['stratum']=='EXPOSED_D18_REGRESSION','exact original eleven-row exposed regression/order1')
need(recipe['method_order']==['SU','SF','S0','PR','PU','PF','P0','SR'] and recipe['rng_seeds']==dict(point=13001,symbolic=3001),'unchanged eight methods/order/RNG recipe')
need(plan['required_upstream_ids']==recipe['required_upstream_ids']==IDS and len(plan['upstream_receipts'])==10,'only acquisition/train prerequisites,not earlier evaluation success')
closure=load(batch['Source_closure']);template=load(plan['template']);phase=protocol['phase_inputs']['evaluate'];load(phase)
need(template['files']==closure['common_source']+[phase] and len(closure['common_source'])==47 and closure['runtime_modules']==35,'unchanged active closure and one phase body')
for key in ('entry_path','worker_path','runner_path','runtime_dir','python','native'):need(same(plan[key],closure[key]),'same current active ABI '+key)
need(plan['modules']==closure['role_mapping'] and plan['limits']==protocol['limits']==batch['limits'] and plan['experiment_limits']==protocol['experiment_limits']==batch['experiment_limits'],'unchanged roles/all original local and outer limits')
need(len(plan['files'])==len({q['path'] for q in plan['files']})==109,'109 unique current guards')
for q in plan['files']:verify(q)
guards={q['path']:q for q in plan['files']}
for field,sha in [('entry_path','f866615a8fd0b33837fa24148c652c0700bea7365d9b626ca83ef688ec2bd7e9'),('worker_path','4d8a5a562a12f8dbd3568debef06f1393644a3fd661f82becfcd4b2ac3dbefb1'),('runner_path','98c55321bb87a8c04b2c6d56b357aba9c3a8f5fc98660474ae3ac1c9d00b0aca')]:need(guards[plan[field]]['sha256']==sha,'unchanged driver/worker/runner Source')
observer_source=pin(R/'observe_conditional_case_v1.py') if (R/'observe_conditional_case_v1.py').is_file() else next(q for q in plan['files'] if q['sha256']=='24804c7d4558d8df511942d9e6b2e4d8d2cfd88ce7df6f5b5f775f87d0c20ca9')
verify(observer_source);need(observer_source['sha256']=='24804c7d4558d8df511942d9e6b2e4d8d2cfd88ce7df6f5b5f775f87d0c20ca9','unchanged original observer Source')
policy_review=passed(batch['final_policy_review']);audit=load(batch['final_policy_audit']);passed(batch['final_policy_audit_output_review'])
need(audit['audit_only'] is audit['audit_complete'] is True and audit['bundle']==policy_review['bundle'],'same reviewed immutable final-policy audit/bundle')
seals=[];upstream_files=[];predecessors=[];prior_seconds=0.0;final_export=None
seal_fields={'stage_id','stage','resource_admitted','stage_complete','plan','result','header','terminal','observer','export_sha256','whole_seconds','whole_peak_bytes','prior_cost_receipts'}
for identity,pair in zip(IDS,batch['predecessors'],strict=True):
    admission=load(pair['admission']);seal=load(pair['seal']);review=passed(admission['C_actual_review'])
    need(admission['stage_id']==seal['stage_id']==identity and admission['protocol']==batch['protocol'] and admission['seal']==pair['seal'] and all(admission[key] is True for key in ('admitted','resource_admitted','scientific_qualified','stage_complete')),'current complete positive acquisition/train prerequisite')
    need(set(seal)==seal_fields and seal['stage'] in ('acquire','train') and seal['resource_admitted'] is seal['stage_complete'] is True and seal['prior_cost_receipts']==[],'exact current strict13field seal')
    need(review['schema']=='D21-C-conditional-stage-actual-review-v1' and all(review[key] is True for key in ('resource_admitted','scientific_qualified','stage_complete')),'current positive independent stage review')
    for key in ('plan','result','header','terminal','observer'):
        verify(seal[key]);need(seal[key]==admission[key]==review[key],'same current prerequisite component');upstream_files.append(seal[key])
    for q in review['complete_actual_file_census']:verify(q)
    worker=load(seal['result']);export=worker['scientific_result']['export'];observer=load(seal['observer'])
    need(worker['status']=='COMPLETE' and worker['source_unchanged'] is True and worker['first_Root_fault'] is False and export['qualified'] is True and hashlib.sha256(wire(export)).hexdigest()==seal['export_sha256']==review['export_sha256'],'unchanged admitted fresh export')
    need(seal['whole_seconds']==observer['elapsed_seconds'] and seal['whole_peak_bytes']==observer['final_conservative_whole_peak_bytes'],'original observer cost sample')
    prior_seconds+=seal['whole_seconds'];seals.append(pair['seal']);upstream_files.append(pair['seal']);predecessors.append(pair)
    if identity=='train-7':final_export=export
need(seals==plan['upstream_receipts'] and predecessors==policy_review['predecessors']==audit['predecessors'] and prior_seconds==248.2828798759947,'all ten original prerequisite pairs/costs and order')
need(hashlib.sha256(wire(final_export)).hexdigest()==policy_review['final_policy_export_sha256']=='94e392556876125614c55fa299abed24d00d5fb22acb9762404db3fa2b0cf3b8' and len(final_export['episode_bindings'])==32 and all(final_export['policies'][engine]['episodes']==len(final_export['policies'][engine]['history'])==16 for engine in ('symbolic','point')),'unchanged final train7bundle/full32bindings/16perengine')
expected=dict(template);expected.update(schema='proof-search-case-once-plan-v1',files=template['files']+[plan['template']]+upstream_files,upstream_receipts=seals,template=plan['template'],scope='Fresh exact one-use whole plan only, requiring independent exact prospective review and Root grant. Every prescribed current predecessor is sealed; no prefix salvage or historical adoption.')
need(same(expected,plan),'whole plan is unchanged original template plus exact ten-chain materialization')
need(all('/actual/eval-' not in path and '/publication/' not in path and '/review-C/' not in path and '/diagnostics-L/' not in path and 'report-state' not in path for path in guards),'no earlier evaluation/result/report/peer bodies in child intake')
need(all(q['path'] not in guards for phase_name,q in protocol['phase_inputs'].items() if phase_name!='evaluate') and batch['final_policy_audit']['path'] not in guards,'physical evaluation phase only,final audit not added to child guards')

failure_review_pin=pin(C/'typed-first-quantified02-whole-failure-actual-review-v1.json');failure_review=passed(failure_review_pin)
negative_review_pin=pin(C/'typed-quantified02-negative-disposition-actual-output-review-v1.json');negative_review=passed(negative_review_pin)
negative_pin=pin(R/'admission'/(FAILED+'-v1.json'));negative=load(negative_pin)
need(failure_review_pin['sha256']=='bcbd2371b98edf5ff8ea67ea05ddf9955cfb6e0059c7852c4c3e4b72c4564a95' and negative_review_pin['sha256']=='f7e4a503cd61bc1d0fd3c6c554c6cb416140511e6609745dd7fa6cf6ad8902cd' and negative_pin['sha256']=='64fb429c1271f8c2ef9cf44c86722271eb08e7c94edccf05403960ebca41ddd1','unchanged independent failure and negative disposition')
need(negative['C_actual_review']==failure_review_pin and negative['result'] is failure_review['result'] is None and all(negative[key] is False for key in ('admitted','resource_admitted','scientific_qualified','stage_complete')) and negative['whole_peak_bytes'] is failure_review['whole_peak_bytes'] is None,'prior failed job remains whole-negative/null qualified peak')
for key in ('plan','failure','header','terminal','observer'):verify(failure_review[key]);need(negative[key]==failure_review[key],'same current failure custody components')
for q in failure_review['complete_actual_file_census']:verify(q)
need(len(failure_review['complete_actual_file_census'])==13,'complete prior failed physical census')
failure=load(failure_review['failure']);header=load(failure_review['header']);terminal=load(failure_review['terminal']);observer=load(failure_review['observer']);owned=load(failure_review['owned_child']);transport=failure['native_transport']
need(failure['scientific_result'] is None and failure['first_Root_fault'] is True and failure['source_unchanged'] is True and failure['error']['type']=='RootBudget' and failure['error']['message']=='absolute case work deadline','whole failed packet,no science or arm salvage')
need(header['native_closed_and_reaped'] is True and header['first_Root_fault'] is True and header['source_unchanged'] is True and terminal['header']==header and terminal['threads_terminal'] is terminal['final_custody_gate_passed'] is terminal['sources_unchanged'] is True and terminal['process_exit_code']==observer['parent_exit_code']==2 and terminal['errors']==observer['errors']==[],'terminal failure ownership/custody closure independent of scientific qualification')
need(all(log['eof'] is True and log['overflow'] is False for logs in (terminal['logs'],observer['logs']) for log in logs.values()),'parent and observer log EOF/no overflow')
need(transport['closed'] is transport['all_reaped'] is transport['same_owned_process_group'] is transport['stdout_eof'] is transport['stderr_complete'] is True and transport['cleanup_errors']==[] and transport['native_exit_code']==-15 and transport['wait4_status']==15,'Native SIGTERM cleanup/wait4/reaped/EOF exact')
need(observer['owned_child']==owned and owned['child_pid']==owned['child_pgid']==transport['parent_pid']==transport['parent_pgid']==transport['native_pgid'] and owned['plan_sha256']==failure_review['plan']['sha256'],'same declared prior owned group/plan')
need(observer['resource_candidate_accepted'] is False and observer['final_conservative_whole_peak_bytes'] is None and negative['whole_seconds']==observer['elapsed_seconds']==160.84695704100886,'no resource-positive upgrade or diagnostic RSS peak filling')
cleanup_pin=pin(R/'before-resumed-evaluation-raw-pin-cleanup-check-v1.json');cleanup=load(cleanup_pin)
need((cleanup_pin['bytes'],cleanup_pin['sha256'])==(8493,'497c7d98ce427a07b13418dae99f21bbf40a3406bf5823035637580f2a9a338e') and cleanup['plan']==plan_pin and cleanup['all_guards_exact'] is True and cleanup['guard_count']==109 and cleanup['previous_failure_gates_preserved'] is True and cleanup['previous_failure_qualified_peak'] is None,'exact Root fresh raw/known-owner check')
need(cleanup['required_upstream']==[dict(pair,stage_id=identity) for identity,pair in zip(IDS,predecessors,strict=True)],'same ten current Root cleanup prerequisite pins')
need(cleanup['previous_failed_terminal']==failure_review['terminal'] and cleanup['previous_failed_observer']==failure_review['observer'] and cleanup['previous_failed_owner']==failure_review['owned_child'],'same failed owner and terminal evidence')
need(cleanup['fresh_owned_ID_checks']==[dict(absent_now=True,id=owned['parent_pid'],kind='pid'),dict(absent_now=True,id=owned['child_pid'],kind='pid'),dict(absent_now=True,id=owned['child_pgid'],kind='pgid')],'Root records fresh exact owned PID/group absence,not a C live probe')
absent=[Path(plan['actual_dir']),D/'actual'/(TARGET+'.observer'),R/'grants'/(TARGET+'-v1.json'),R/'admission'/(TARGET+'-v1.json'),R/'seals'/(TARGET+'-v1.json')]
need(all(not path.exists() for path in absent),'next original job is unrun/unconsumed/unadmitted')
for q in tuple(checked.values()):verify(q)
checks=[
 ('exact-original-pending-plan-Source-recipe-and-caps','Exact38,348-byte plan5cf53ce1… remains the original plan in prior23wholeprospectivePASS32399b45…. All109currentuniqueguards,47common/35runtimeSources,worker/driver/runner/observer,onephysicalevalinput,elevenrows,orderlabel1,eight original methods andRNGseeds remain exact. No template/target/intake/cap/population change.'),
 ('ten-current-positive-prerequisites-and-frozen-policy','All ten required acquisition/training Rootadmissions/currentCactuals/strict13fieldseals,fivecomponents and140rawcensus bodies remain current and positive. Final train7export94e392… retains32bindings/16episodesperengine and exact reviewed finalaudit/bundle. Whole plan equals its frozen template plus only these ordered ten predecessor components/seals.'),
 ('evaluations-independent-no-positive-prior-eval-assumption','Original required_upstream_ids contains onlyacquire0/1 andtrain0..7. Frozen worker intake accepts onlyacquire/train upstreamseals;unchanged evaluation branch sets index8 and uses this finalbundle. No earlier evaluation success/resource-positive admission is required or added to guards. Previousfailedseed0 is not retried,replaced,adopted or made a dependent prerequisite.'),
 ('prior-whole-failure-cleanup-and-negative-retained','ExactCfailure/Cnegativeoutput/Rootnegative,13currentrawfiles,resultnull,fourfalsegates andnullqualifiedpeak remain. Savedheader/transport/terminal/observer record NativeSIGTERMwait4/reaped/closed,ownedgroupidentity,alllogEOF,nocleanuperrors andterminalthreadsclosed. These saved complete diagnostics support a fresh Rootcleanup assessment without scientific admission or prefixsalvage;C has not performed livePIDinspection.'),
 ('fresh-barrier-grant-and-once-actual-still-Root-owned','Next actual/observer/grant/admission/seal paths remain absent. This current prospective continuation receipt authorizes no execution,grant,helper,retry,changedrecipe or forecast. Pinned fresh Rootcleanup receipt separately records the exact failed ownerPIDs/group absent and current109guards/tenseals exact;C performs no livePIDquery. Root must still confirm all toolsidle and author its fresh barrier/one-use grant before any once originaljob invocation. Each subsequent result needs independent wholeactual review.')]
receipt=dict(schema='D21-C-current-original-evaluation-continuation-Source-plan-review-v1',review_passed=True,stage_id=TARGET,plan=plan_pin,protocol=batch['protocol'],prior_whole_prospective_review=batch_pin,prior_per_plan_checks=prior_plan['checks'],recipe=recipe,limits=plan['limits'],experiment_limits=plan['experiment_limits'],Source_closure=batch['Source_closure'],guard_count=109,current_guard_pins_sha256=hashlib.sha256(wire(sorted(plan['files'],key=lambda q:q['path']))).hexdigest(),entry_Source=guards[plan['entry_path']],worker_Source=guards[plan['worker_path']],runner_Source=guards[plan['runner_path']],observer_Source=observer_source,predecessors=predecessors,predecessor_count=10,prior_unique_observer_sample_seconds=prior_seconds,final_policy_review=batch['final_policy_review'],final_policy_audit=batch['final_policy_audit'],final_policy_audit_output_review=batch['final_policy_audit_output_review'],final_policy_export_sha256=policy_review['final_policy_export_sha256'],earlier_evaluation_success_required=False,prior_failure_review=failure_review_pin,prior_negative_output_review=negative_review_pin,prior_Root_negative=negative_pin,Root_fresh_cleanup_check=cleanup_pin,Root_reported_owned_ID_checks=cleanup['fresh_owned_ID_checks'],prior_failure_components={key:failure_review[key] for key in ('plan','failure','header','terminal','observer','owned_child')},prior_failure_qualified_peak=None,prior_failure_observer_sample_seconds=observer['elapsed_seconds'],saved_native_ownership=dict(parent_pid=transport['parent_pid'],parent_pgid=transport['parent_pgid'],native_pid=transport['native_pid'],native_pgid=transport['native_pgid'],all_reaped=True,closed=True,live_process_state_checked_by_C=False),absent_paths=[str(path) for path in absent],checks=[dict(id=key,passed=True,finding=finding) for key,finding in checks],failures=[],scientific_calls=0,scientific_imports=0,subject_replays=0,helper_invocations=0,live_PID_probes=0,browser_network_calls=0,partial_files_parsed=0,Root_admission_issued=False,grants_issued=0,scope='Exact current original quantified02 seed1 prospective continuation only. Priorfailure stays negative;cleanup evidence is saved custody,not current livePID authority. Root alone owns fresh barrier/grant/onceinvocation;no actual or outcome authority.',review_program=pin(Path(__file__).resolve()),tools_idle_after_freeze=True)
output=C/'typed-next-original-quantified02-seed1-current-continuation-review-v1.json'
with output.open('xb') as f:f.write((json.dumps(receipt,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode())
print(json.dumps(pin(output)));print(json.dumps(dict(checks=len(checks),failures=0,current_guards=109,current_positive_prerequisites=10,prior_failure_kept_negative=True,tools_idle=True)))
