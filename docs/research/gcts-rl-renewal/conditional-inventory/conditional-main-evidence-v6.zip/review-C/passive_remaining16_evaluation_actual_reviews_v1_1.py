"""C-only complete saved evidence joins. No experimental imports or replay."""
from pathlib import Path
import collections
import hashlib
import json
import math
import argparse

D=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-conditional-selector-main-20261021')
R=D/'root'; C=D/'review-C'; SEEN={}
parser=argparse.ArgumentParser(description=__doc__); parser.add_argument('--stage-id',required=True); ARGS=parser.parse_args(); STAGE=ARGS.stage_id
assert STAGE in ['eval-eval-equality-01-seed0', 'eval-eval-equality-01-seed1', 'eval-eval-equality-02-seed0', 'eval-eval-equality-02-seed1', 'eval-context-atomic-serial-seed0', 'eval-context-atomic-serial-seed1', 'eval-context-opaque-equality-seed0', 'eval-context-opaque-equality-seed1', 'eval-holdout-alternative-01-seed0', 'eval-holdout-alternative-01-seed1', 'eval-holdout-alternative-02-seed0', 'eval-holdout-alternative-02-seed1', 'eval-holdout-cycle-01-seed0', 'eval-holdout-cycle-01-seed1', 'eval-holdout-cycle-02-seed0', 'eval-holdout-cycle-02-seed1']
IDS=['acquire-0','acquire-1']+['train-'+str(i) for i in range(8)]
METHODS=['S0','SF','SU','SR','P0','PF','PU','PR']

def pin(path):
 p=Path(path); assert p==p.resolve() and p.is_file() and not p.is_symlink()
 b=p.read_bytes(); value=dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
 if str(p) in SEEN: assert SEEN[str(p)]==value
 SEEN[str(p)]=value; return value
def verify(value): assert pin(value['path'])==value
def object_pairs(pairs):
 value={}
 for key,item in pairs: assert key not in value; value[key]=item
 return value
def load(path):
 assert '.partial' not in Path(path).name; pin(path)
 return json.loads(Path(path).read_bytes(),object_pairs_hook=object_pairs,parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))
def wire(value): return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def same(left,right): return wire(left)==wire(right)
def digest(value): return hashlib.sha256(wire(value)).hexdigest()
def number(value): return type(value) in (int,float) and math.isfinite(value)
def vector(value,size): assert type(value) is list and len(value)==size and all(number(item) for item in value)
def passed(value):
 verify(value); result=load(value['path'])
 assert result['review_passed'] is True and result['checks'] and all(row['passed'] is True for row in result['checks']) and result['failures']==[]
 return result

actual=D/'actual'/STAGE; outer=D/'actual'/(STAGE+'.observer')
components=dict(plan=pin(R/'plans'/(STAGE+'-v1.json')),result=pin(actual/'result.json'),header=pin(actual/'worker-header.json'),terminal=pin(actual/'terminal.json'),observer=pin(outer/'observer.json'))
parameters_pin=pin(C/'remaining16-positive-evaluation-review-parameters-v1.json'); parameters=load(parameters_pin['path'])
assert components==parameters['components'][STAGE]
packet_offer=load(parameters['Root_terminal_packet']['path']);verify(parameters['Root_terminal_packet'])
assert parameters['Root_terminal_packet']['sha256']=='2bf439d7510099286d8aad889f83ea51a6b84e9f7b4ccee85e89327073b3700f'
packet_row=next(row for row in packet_offer['jobs'] if row['stage_id']==STAGE);assert all(packet_row[key]==value for key,value in components.items())
plan=load(components['plan']['path']); worker=load(components['result']['path']); header=load(components['header']['path']); terminal=load(components['terminal']['path']); observer=load(components['observer']['path'])
science=worker['scientific_result']; protocol=load(plan['protocol']['path']); document=load(plan['input_path']); recipe=plan['Root_recipe']
prospective_pin=pin(C/'typed-remaining23-evaluation-whole-prospective-Source-plan-review-v1.json'); prospective=passed(prospective_pin)
assert prospective_pin['sha256']=='32399b45e2e83c2ae332cd817df21363afa986a2419ae2ac8c0a7f0ef9ed122f' and components['plan'] in prospective['plans']
assert plan['case_id']==STAGE and plan['stage']=='evaluate' and plan['required_upstream_ids']==IDS and recipe==next(row for row in protocol['job_recipes'] if row['stage_id']==STAGE)
assert recipe['stratum']==document['protocol']['case_strata'][recipe['case_id']] and recipe['method_order']==document['protocol']['arm_order'][recipe['case_id']][str(recipe['order_label'])] and recipe['rng_seeds']==document['protocol']['rng_seeds'][recipe['case_id']][str(recipe['order_label'])]
METHODS=recipe['method_order']; assert len(METHODS)==8 and set(METHODS)=={'S0','SF','SU','SR','P0','PF','PU','PR'}
assert len(plan['files'])==len({p['path'] for p in plan['files']})==109 and all(p in prospective['input_pins'] for p in plan['files'])
for value in plan['files']: verify(value)
assert plan['limits']==protocol['limits']==prospective['limits'] and plan['experiment_limits']==protocol['experiment_limits']==prospective['experiment_limits']
grant_pin=pin(R/'grants'/(STAGE+'-v1.json')); grant=load(grant_pin['path']); barrier_pin=grant['serial_barrier']; verify(barrier_pin); barrier=load(barrier_pin['path'])
assert grant['authorized'] is grant['review_passed'] is True and type(grant['uses']) is int and grant['uses']==1
assert grant['plan_sha256']==components['plan']['sha256'] and grant['runner_sha256']=='98c55321bb87a8c04b2c6d56b357aba9c3a8f5fc98660474ae3ac1c9d00b0aca' and grant['prospective_review']==prospective_pin
assert barrier['stage_id']==STAGE and barrier['plan']==components['plan'] and barrier['prospective_review']==prospective_pin and barrier['all_guard_pins_current'] is True
assert barrier['other_experimental_sessions_running'] is False and barrier['owned_browser_tools_idle'] is barrier['network_tools_idle'] is True
verify(barrier['window_checkpoint']);assert barrier['window_checkpoint']==parameters['Root_window']
window=load(barrier['window_checkpoint']['path']);assert window['remaining_original_jobs']==16 and window['stop_window_on_any_whole_failure'] is True
metadata_negative_pin=pin(R/'remaining16-positive-barrier-authoring-negative-v1.json');metadata_negative=load(metadata_negative_pin['path'])
assert metadata_negative['schema']=='D21-Root-passive-metadata-authoring-negative-v1' and 'failed before writing barrier/grant or scientific call' in metadata_negative['scope']
assert barrier['owned_preview_tools_idle'] is barrier['peer_tools_idle_since_checkpoint'] is True
for name in ('previous_header','previous_terminal','previous_observer'): verify(barrier[name])
consumed=load(actual/'CONSUMED.json'); owner=load(actual/'owned-child.json')
assert consumed['case_id']==STAGE and consumed['plan_sha256']==components['plan']['sha256'] and consumed['grant_sha256']==grant_pin['sha256'] and consumed['uses']==1
assert worker['status']==header['status']=='COMPLETE' and worker['error'] is None and worker['first_Root_fault'] is header['first_Root_fault'] is False
assert worker['source_unchanged'] is header['source_unchanged'] is terminal['sources_unchanged'] is True and worker['old_qualification_reused'] is worker['full_physical_Wang_claim'] is False
assert worker['stage']=='evaluate' and worker['case_id']==header['case_id']==terminal['case_id']==observer['case_id']==STAGE
assert header['result']==terminal['result']==components['result'] and terminal['header']==header
assert terminal['header_valid'] is terminal['threads_terminal'] is terminal['final_custody_gate_passed'] is True
assert terminal['process_exit_code']==observer['parent_exit_code']==0 and terminal['reason'] is observer['reason'] is None
assert terminal['errors']==observer['errors']==[] and observer['resource_candidate_accepted'] is True and observer['fallback_trigger_seconds'] is None
assert terminal['known_exit_seconds']<=180 and terminal['final_custody_gate_seconds']<=210 and observer['final_observer_gate_seconds']<=210
assert type(worker['callbacks']) is int and 0<=worker['callbacks']<=400000000 and components['result']['bytes']<=50331648
assert terminal['stored_bytes_before_terminal_receipt']<=134217728 and observer['stored_bytes_before_observer_receipt']+observer['receipt_allowance_bytes']<=134217728
assert terminal['memory_terminal_output_reserve_bytes']==observer['final_output_memory_reserve_bytes']==9437184
for item in (terminal,observer):
 for log in item['logs'].values(): assert log['eof'] is True and log['overflow'] is False and log['bytes']==log['stored']<=4194304
paths=sorted([p for directory in (actual,outer) for p in directory.rglob('*') if p.is_file()])
assert not any(p.is_symlink() for directory in (actual,outer) for p in directory.rglob('*'))
census=sorted([pin(p) for p in paths],key=lambda p:p['path']); assert len(census)==14 and not any('.partial' in Path(p['path']).name for p in census)
assert census==sorted(packet_row['complete_actual_file_census'],key=lambda value:value['path']) and packet_row['scientific_admission']=='AWAITING_INDEPENDENT_C_AND_ROOT' and packet_offer['new_scientific_admissions']==0
assert observer['elapsed_seconds']==packet_row['observer_elapsed_seconds'] and observer['final_conservative_whole_peak_bytes']==packet_row['resource_candidate_peak_bytes']
physical=sum(p['bytes'] for p in census); assert physical<134217728
assert load(outer/'stdout.bin')==terminal
assert all(stage['status']=='COMPLETED' for stage in worker['stages'])
queries=worker['native_queries']; transport=worker['native_transport']
assert worker['native_requests_started']==len(queries)==transport['complete_records'] and 0<len(queries)<=512
assert transport['closed'] is transport['all_reaped'] is transport['constructor_completed'] is True and transport['native_exit_code']==0 and transport['cleanup_errors']==[]
assert transport['parent_pid']==transport['parent_pgid']==owner['child_pid']==owner['child_pgid']==transport['native_pgid']
assert observer['owned_child']==owner and owner['plan_sha256']==components['plan']['sha256'] and header['native_closed_and_reaped'] is True
assert worker['native_peak_bytes']==header['native_peak_bytes']==transport['native_high_water_bytes']
assert len(transport['request_stages'])==len(queries) and set(q['result']['status'] for q in queries)<={'accepted','rejected'}
for index,(query,owned_stage) in enumerate(zip(queries,transport['request_stages'],strict=True)):
 assert type(query['id']) is int and query['id']==index==owned_stage['ordinal']==owned_stage['record_id'] and owned_stage['stage']=='COMPLETED'
 assert owned_stage['limit']==1000000000 and query['request_sha256']==digest(query['request'])
 assert all(query[key]==owned_stage[key] for key in ('purpose','request_sha256','input_sha256','output_sha256'))
 assert query['request']['protocol']=='gcts-fol-1' and query['request']['blocks']==[] and query['query_target']=='fixed_assertion' and query['result']['micro_steps']<=1000000000
assert pin(actual/'native/input.bin')['sha256']==queries[-1]['input_sha256'] and pin(actual/'native/output.bin')['sha256']==queries[-1]['output_sha256']
assert pin(actual/'native/boundary-oracle')['sha256']=='2b6bf8bb09a4e03d0cb1b4595dea1fe6d4432aa93d8f7eed72c30077fd9941a4'
assert pin(actual/'native/code.bin')['sha256']=='97f0b600cffd83552c4e0f0c4fb1f5d26cfdb76e3e74b267bbaebeddc836e7ed'
python_peak=max(worker['python_peak_bytes'],header['python_peak_after_output_bytes'],terminal['child_usage']['ru_maxrss'])
combined=python_peak+worker['native_peak_bytes']+terminal['parent_usage']['ru_maxrss']+9437184
assert combined==terminal['conservative_combined_peak_bytes'] and combined+observer['final_observer_peak_bytes']+9437184==observer['final_conservative_whole_peak_bytes']<1073741824
assert science['stage_id']==STAGE and science['stage']=='evaluate' and science['status']=='EVALUATION_EIGHT_METHOD_RECORD'
assert science['stage_complete'] is science['job_record_complete'] is science['all_eight_searched'] is True and science['resource_admitted'] is science['policies_updated'] is False
assert science['inputs']==document and science['limits']==plan['experiment_limits'] and science['native_records']==queries and science['evaluation_seed']==recipe['order_label']
assert science['format_check']['complete'] is True and science['format_check']['phase']=='evaluation' and science['format_check']['statement_ids']==[value['id'] for value in document['evaluation']]

# All predecessor assertions are literal current saved joins, not research replay.
receipts=[]; exports=[]; pairs=[]; upstream_review_pins=[]
for index,value in enumerate(plan['upstream_receipts']):
 verify(value); seal=load(value['path']); identity=IDS[index]; admission_pin=pin(R/'admission'/(identity+'-v1.json')); admission=load(admission_pin['path'])
 assert seal['stage_id']==admission['stage_id']==identity and seal['stage']==admission['stage']==('acquire' if index<2 else 'train')
 assert admission['seal']==value and admission['protocol']==plan['protocol'] and all(admission[key] is True for key in ('admitted','resource_admitted','scientific_qualified','stage_complete'))
 assert len(seal)==13 and seal['prior_cost_receipts']==[] and seal['resource_admitted'] is seal['stage_complete'] is True
 for key in components: verify(seal[key]); assert seal[key]==admission[key]
 previous=load(seal['result']['path']); prior_review=passed(admission['C_actual_review'])
 assert prior_review['schema']=='D21-C-conditional-stage-actual-review-v1' and all(prior_review[key] is True for key in ('resource_admitted','scientific_qualified','stage_complete'))
 assert all(prior_review[key]==seal[key] for key in components) and previous['scientific_result']['stage_complete'] is True
 for guard in prior_review['input_pins']: verify(guard)
 assert len(prior_review['complete_actual_file_census'])==14
 for item in prior_review['complete_actual_file_census']: verify(item)
 exported=previous['scientific_result']['export']; assert exported['qualified'] is True and digest(exported)==seal['export_sha256']==prior_review['export_sha256']
 assert seal['whole_seconds']==load(seal['observer']['path'])['elapsed_seconds']==prior_review['whole_seconds']
 receipts.append(seal); exports.append(exported); pairs.append(dict(admission=admission_pin,seal=value)); upstream_review_pins.append(admission['C_actual_review'])
freeze_review_pin=pin(C/'typed-complete-ten-stage-final-policy-freeze-review-v1.json'); freeze_review=passed(freeze_review_pin)
audit_review_pin=pin(C/'typed-final-policy-freeze-actual-output-review-v1.json'); audit_review=passed(audit_review_pin)
audit_pin=pin(R/'final-policy-freeze-v1.json'); audit=load(audit_pin['path'])
assert audit['predecessors']==pairs==freeze_review['predecessors'] and audit['bundle']==freeze_review['bundle']==audit_review['bundle'] and audit['audit_complete'] is audit['audit_only'] is True
final=exports[-1]; policies=final['policies']
assert digest(final)==audit['bundle']['final_policy_export_sha256'] and digest(policies)==audit['bundle']['policies_sha256'] and len(final['episode_bindings'])==32
assert science['policy_check']['complete'] is True and science['policy_check']['shards']==8 and science['policy_check']['episodes']==32
for engine in ('symbolic','point'):
 assert policies[engine]['episodes']==len(policies[engine]['history'])==16 and science['policy_check']['policies'][engine]['complete'] is True
 assert science['policy_check']['policies'][engine]==load(receipts[-1]['result']['path'])['scientific_result']['policy_checks'][engine]
costs=science['cumulative_costs']; prior_seconds=0.0
for receipt in receipts: prior_seconds+=receipt['whole_seconds']
assert same(costs['receipts'],receipts) and costs['stage_ids']==IDS and same(costs['whole_seconds'],prior_seconds)
assert costs['maximum_prior_whole_peak_bytes']==max(value['whole_peak_bytes'] for value in receipts) and costs['current_whole_seconds'] is None
assert same(costs['current_entry_seconds'],science['seconds']) and same(costs['upstream_plus_current_entry_seconds'],prior_seconds+science['seconds'])
acq=science['acquisition_check']; assert acq['complete'] is True and len(acq['donor_exports'])==2
certificates=[cert for exported in exports[:2] for cert in exported['certificates']]
for index,(exported,check) in enumerate(zip(exports[:2],acq['donor_exports'],strict=True)):
 assert check['complete'] is check['qualified'] is True and check['donors']==1 and check['certificates']==4 and check['pairing']==exported['pairing']
 prior_queries=load(receipts[index]['result']['path'])['native_queries']
 for evidence in check['Native_evidence']:
  query=prior_queries[evidence['query']]; assert query['result']['status']=='accepted' and query['request_sha256']==evidence['request_sha256'] and digest(query['result'])==evidence['result_sha256']
 assert {row['query'] for row in check['Native_evidence']}=={45,46,47,48,49}
classes={}
for ordinal,cert in enumerate(certificates): classes.setdefault(cert['families']['atom']['id'],[]).append(ordinal)
pairing=acq['pairing']; assert pairing['no_principal_coalescence'] is True and pairing['raw_certificates']==8 and pairing['paired_units']==5 and pairing['principal_structures']==4
assert len(pairing['units'])==len(classes)==len(science['library'])==5 and science['library']==acq['libraries']['principal'] and digest(science['library'])==final['library_sha256']
for unit in pairing['units']:
 identity=unit['paired_unit_id']; indices=classes[identity]; assert [row['certificate_ordinal'] for row in unit['members']]==indices
 for mode in ('atom','principal'):
  wrapper=next(row for row in acq['libraries'][mode] if row['id']==identity); origin=indices[0]; inner=certificates[origin]['families'][mode]
  assert wrapper['structural_family']==inner and wrapper['source_certificate_ordinal']==origin and wrapper['paired_unit_id']==identity and wrapper['structural_id']==inner['id']
  assert all(wrapper[key]==(identity if key=='id' else value) for key,value in inner.items()) and unit['wrapper_checks'][mode]['complete'] is True
library_ids={family['id'] for family in science['library']}

# Fresh controls: full rows and strict population IDs; no arithmetic/unifier replay.
BANKS=dict(numeric=23,word=48,graph=22,encoding=40,principal=53,matched_symbolic=13,conditional_numeric=57,conditional_semantic=18)
control_IDs={}
for name,count in BANKS.items():
 bank=science['controls'][name]; rows=bank['controls']; assert bank['complete'] is True and len(rows)==count and len({row['id'] for row in rows})==count
 assert all(row.get('passed') is True or row.get('status')=='PASSED' for row in rows); control_IDs[name]=[row['id'] for row in rows]
assert sum(BANKS.values())==274 and science['controls']['conditional_corpus_status']=='NOT_REQUESTED_FOR_THIS_PHASE'
assert all(science['controls'][name] is None for name in ('conditional_corpus','corpus','native_batch','guard_resolver','guard_differential','reference_setup_calibration'))
population_only=load(receipts[-1]['result']['path'])['scientific_result']['controls']
assert all(control_IDs[name]==[row['id'] for row in population_only[name]['controls']] for name in BANKS)
inherited=science['controls']['inherited']; assert inherited['status']=='complete' and inherited['base_solutions']==inherited['marked_solutions'] and len(inherited['full_domain_audits'])==9
assert inherited['callback_identity_propagated'] is inherited['global_dead_forced_generation_controls'] is inherited['incomplete_certificate_rejected'] is True
assert all(row['complete'] is True for row in inherited['full_domain_audits'])

used_native=set()
def owned(query):
 assert query==queries[query['id']]; used_native.add(query['id'])
def accepted(query,spec,proof):
 owned(query); assert query['result']['status']=='accepted' and query['request']==dict(protocol='gcts-fol-1',theory=spec['theory'],blocks=[],proof=proof,target=spec['target'])

assert len(science['records'])==1; case=science['records'][0]; spec=case['spec']; model=case['model']; domains=model['domains']
assert spec==next(value for value in document['evaluation'] if value['id']==recipe['case_id']) and len(case['arms'])==8 and [row['id'] for row in case['arms']]==METHODS
assert case['diagnostic_ground_registry'] is None and spec['length']==recipe['exact_rows']
assert len(worker['guard_compilations'])==1; ledger=worker['guard_compilations'][0]
assert ledger['complete'] is True and ledger['status']=='complete' and ledger['active_query'] is None and type(ledger['unresolved']) is int and ledger['unresolved']==0 and ledger['resolved']==len(ledger['members'])
assert case['compiler']['guard_evidence']==ledger and case['compiler']['status']=='complete'
for query in ledger['query_records']: owned(query); assert query['request']['theory']==spec['theory']
assert queries[ledger['theory_query']]['result']['status']=='accepted'
for batch in ledger['batches']:
 query=queries[batch['query_id']]; assert query==ledger['query_records'][batch['query_record_ordinal']] and batch['status']==query['result']['status']
 assert query['request']['proof']==[member['command'] for member in ledger['members'][batch['start']:batch['stop']]] and query['request']['target']==query['request']['proof'][-1]['formula']
 if batch['status']=='rejected' and batch['stop']-batch['start']>1:
  children=[item for item in ledger['batches'] if item['parent']==batch['index']]; assert len(children)==2 and children[0]['start']==batch['start'] and children[0]['stop']==children[1]['start'] and children[1]['stop']==batch['stop']
for ordinal,member in enumerate(ledger['members']):
 query=queries[member['native_query']]; assert member['ordinal']==ordinal and query['request']['proof'][member['native_row']]==member['command'] and member['status']==query['result']['status'] and member['command']['rule'] in ('tautology','instantiate','eq_subst')
 if member['status']=='rejected': assert member['resolution_kind']=='singleton_rejection' and len(query['request']['proof'])==1
reference=case['reference_check']; word_check=case['word_model_check']; guard_check=case['guard_acquisition_check']
assert reference['complete'] is word_check['complete'] is guard_check['complete'] is True and guard_check['carrier_verified'] is True
assert guard_check['native_queries']==len(ledger['query_records']) and guard_check['original_members']==guard_check['resolved']==len(ledger['members']) and guard_check['unresolved']==0
assert case['word_reference_differential']['performed_on_this_model'] is False and model['word_terminator']==256 and model['arity']==0 and model['mode_ids']=={} and len(domains)==spec['length']
assert len(set(model['word_dictionary']))==len(model['word_dictionary'])==word_check['dictionary_words']==reference['distinct_complete_words']
assert model['word_dictionary'][0]==wire(spec['target']).hex() and [[4*(spec['length']-1),100],0] in model['initial']['marks']
assert len(model['placements'])==word_check['placements']==reference['accepted_placements'] and len(model['dependencies'])==reference['dependency_points']
placements={tuple(value['key']):value for value in model['placements']}; assert len(placements)==len(model['placements'])
for key,value in placements.items():
 assert value['command_reference']==[key[0],key[2]] and 0<=key[0]<spec['length'] and 0<=key[2]<len(domains[key[0]]) and domains[key[0]][key[2]]['rule'] not in ('block','assumption')
 for point,word_id in value['marks']:
  if point[1]==100 and point[0]>=0: assert type(word_id) is int and 0<=word_id<len(model['word_dictionary'])
assert all(all(tuple(key) in placements for key in row['keys']) for row in model['alignments']+model['dependencies'])
marking=case['marking']; assert marking['marking_certificate_check']['complete'] is marking['marked_extension_check']['complete'] is True
certs=marking['markings']['certificates']; assert len(certs)==marking['marking_certificate_check']['certificates']==12 and marking['marked_extension_check']['auxiliary_points']==marking['marked_extension_check']['changed_placements']==12
aux={tuple(cert['auxiliary']['point']):cert['auxiliary'] for cert in certs}; assert len(aux)==12
for cert in certs:
 assert tuple(cert['auxiliary']['placement']) in placements and cert['auxiliary']['initial_value']!=cert['auxiliary']['placement_value']
 assert all(tuple(row['key']) in placements for row in cert['all_candidates'])
assert all(number(marking[key]) and marking[key]>=0 for key in ('construction_seconds','certificate_verification_seconds','overlay_construction_seconds','extension_verification_seconds','seconds'))

# Only literal stack/catalog/trace projection below, never State/Graph simulation.
snapshot_keys=[]
for sample in worker['work_snapshots']:
 assert set(sample)=={'callbacks','elapsed_seconds'} and type(sample['callbacks']) is int and type(sample['elapsed_seconds']) is float and math.isfinite(sample['elapsed_seconds'])
 assert 0<=sample['callbacks']<=worker['callbacks'] and 0<=sample['elapsed_seconds']<=worker['elapsed_seconds']
 snapshot_keys.append((sample['callbacks'],sample['elapsed_seconds'].hex()))
assert len(snapshot_keys)==len(set(snapshot_keys)) and all(left[0]<right[0] for left,right in zip(snapshot_keys,snapshot_keys[1:]))
snapshot_cursor=0; raw_pool_count=raw_packet_count=group_count=all_orders=0; unfinished=[]; arm_rows=[]
def consume(sample):
 global snapshot_cursor
 assert (sample['callbacks'],sample['elapsed_seconds'].hex())==snapshot_keys[snapshot_cursor]
 ordinal=snapshot_cursor; snapshot_cursor+=1; return ordinal
def literal_tiers(keys,prefix,command_of,preferred):
 tiers=[[],[],[],[]]; formulas=[command['formula'] for command in prefix]
 for key in keys: tiers[2*int(command_of(key)['formula'] in formulas)+int(key not in preferred)].append(key)
 return [key for tier in tiers for key in tier]

def arm_join(record):
 global raw_pool_count,raw_packet_count,group_count,all_orders
 method=record['id']; engine='symbolic' if method[0]=='S' else 'point'; mode={'0':'none','F':'fixed','U':'uniform','R':'learned'}[method[1]]
 search=record['search']; trace=search['trace']; decisions=search.get('selector_decisions',[]); contexts={}; stack=[]; order_count=0
 assert record['engine']==engine and record['selection']==mode and record['seed']==recipe['rng_seeds'][engine] and record['execution_status']=='SEARCH_RETURNED'
 assert record['certified_markings'] is (engine=='point') and record['problem_defining_word_structure_marks'] is True and record['cluster_ordering'] is (mode!='none') and search['cluster_ordering'] is (mode!='none')
 assert search['attempt_unit']==('primitive proof-row extension' if engine=='symbolic' else 'primitive point placement')
 assert not any(key in record for key in ('episode','policy_update','descriptor'))
 for index,event in enumerate(trace):
  kind=event['event']
  if kind=='decision':
   if engine=='symbolic':
    prefix=[domains[row][key[0]] for row,key in enumerate(stack)]; assert event['row']==len(prefix)
    if mode=='none' or event['ordering_complete'] is True:
     old=event['original_candidates']; new=event['ordered_candidates']; assert sorted(old)==sorted(new)
     if mode=='none': assert old==new and event['proposals']==[]
     else:
      preferred=[key for key in old if domains[len(prefix)][key[0]]==event['preferred_command']]
      assert new==literal_tiers(old,prefix,lambda key:domains[len(prefix)][key[0]],preferred)
     order_count+=1
    else:
     assert event['ordered_candidates'] is None and search['status']=='unknown_search_budget' and trace[-1]['event']=='cutoff' and not any(row['event'] in ('decision','extend') for row in trace[index+1:])
     unfinished.append(dict(method=method,trace_index=index,row=event['row'],proposal_present=event['proposal'] is not None))
   else:
    prefix=[]
    for row in range(len(domains)):
     commands=[key for key in stack if key[0]==row and key[1]==0]; guards=[key for key in stack if key[0]==row and key[1]==1]
     if not commands or not guards: break
     assert len(commands)==len(guards)==1 and commands[0][2]==guards[0][2]; prefix.append(domains[row][commands[0][2]])
    assert event['ordinal']==index and event['kind'] in ('branch','forced','dead','empty')
    if event['kind']=='forced': assert len(event['original_alternatives'])==1
   contexts[index]=dict(prefix=prefix,event=event)
  elif kind=='order':
   context=contexts[event['decision']]; old=context['event']['original_alternatives']; new=event['alternatives']; prefix=context['prefix']
   assert engine=='point' and sorted(old)==sorted(new)
   assert new==(old if context['event']['kind']=='forced' else literal_tiers(old,prefix,lambda key:domains[key[0]][key[2]],event['preferred']))
   order_count+=1
  elif kind=='extend':
   event_owner=trace[event['decision']]; assert engine=='symbolic' and event_owner['row']==len(stack) and [event['skeleton'],event['variant']] in event_owner['ordered_candidates']
   if mode!='none': assert event_owner['ordering_complete'] is True
   stack.append([event['skeleton'],event['variant']])
  elif kind=='place': assert engine=='point' and tuple(event['key']) in placements; stack.append(event['key'])
  elif kind=='return':
   assert stack; key=stack.pop(); assert (key==event['key'] if engine=='point' else key[0]==event['skeleton'])
 assert search['root_restored'] is True
 if search['status']!='unknown_search_budget': assert stack==[]
 assert search['metrics']['attempts']==sum(row['event']==('place' if engine=='point' else 'extend') for row in trace)<=600
 all_orders+=order_count; consumed_continuations=set(); joins=[]
 if mode=='none': assert decisions==[]
 for ordinal,decision in enumerate(decisions):
  assert type(decision['ordinal']) is int and decision['ordinal']==ordinal; snapshot_index=consume(decision['snapshot'])
  node=decision['context']['trace_decision']; context=contexts[node]; prefix=context['prefix']; event=context['event']; action=decision['action']; head=decision['head']; dimension=8 if head=='gate' else 12
  assert head in ('gate','continuation') and decision['context']['engine']==engine and decision['context']['prefix']==prefix and decision['attempts']<=search['metrics']['attempts']
  vector(action['weights'],dimension); assert action['weights']==policies[engine]['heads'][head]['weights'] and action['mode']==mode
  assert type(action['choice']) is int and len(action['features'])==len(action['probabilities']) and 0<=action['choice']<len(action['features'])
  assert all(number(value) and 0<=value<=1 for value in action['probabilities'])
  for values in action['features']: vector(values,dimension)
  if mode=='fixed': assert action['choice']==0 and action['draw'] is None and action['probabilities']==[1.0]+[0.0]*(len(action['features'])-1)
  else:
   assert type(action['draw']) is float and 0<=action['draw']<1
   if mode=='uniform': assert len(set(action['probabilities']))==1
  if head=='continuation': assert ordinal in consumed_continuations; continue
  assert decision['pool_ordinal'] is None and action['features']==[decision['context']['gate_features'],[0.0]*8]
  old=event['original_candidates'] if engine=='symbolic' else event['original_alternatives']
  assert decision['context']['original_candidate_count']==len(old) and decision['context']['selected_point']==(None if engine=='symbolic' else event['point'])
  if engine=='symbolic': proposal=event['proposal']
  else:
   candidates=[row['proposal'] for row in trace if row['event']=='conditional_proposal' and row['decision']==node]; assert len(candidates)<=1; proposal=candidates[0] if candidates else None
  if proposal is None:
   assert ordinal==len(decisions)-1 and action['choice']==0 and search['status']=='unknown_search_budget' and trace[-1]['event']=='cutoff'
   joins.append(dict(gate=ordinal,trace_index=node,status='INTERRUPTED_POOL_NOT_RETURNED')); continue
  assert proposal['gate_decision']==ordinal
  if action['choice']==1:
   assert proposal['status']=='POOL_NOT_REQUESTED_GATE_ABSTAIN' and proposal['pool'] is proposal['grouping'] is proposal['continuation_decision'] is None
   joins.append(dict(gate=ordinal,trace_index=node,status=proposal['status'])); continue
  next_index=proposal['continuation_decision']; assert next_index==ordinal+1 and next_index<len(decisions)
  continuation=decisions[next_index]; assert continuation['head']=='continuation' and continuation['context']['trace_decision']==node and continuation['context']['gate_decision']==ordinal and continuation['context']['prefix']==prefix
  assert continuation['pool_ordinal']==sum(row['head']=='continuation' for row in decisions[:ordinal]); consumed_continuations.add(next_index)
  pool=proposal['pool']; grouping=proposal['grouping']; assert proposal['status']=='COMPLETE_DECLARED_BOUNDED_POOL' and pool['complete'] is True and pool['termination'] in ('declared_occurrences_exhausted','packet_quota','work_prefix')
  assert same(grouping,continuation['context']['grouping']) and same(grouping['features'],continuation['action']['features'])
  packets=pool['packets']; groups=grouping['groups']; aliases=[]; signatures=set()
  assert len(packets)<=16 and grouping['abstain_index']==len(groups) and len(grouping['features'])==len(groups)+1
  for group in groups:
   indices=group['raw_packet_ordinals']; aliases.extend(indices); assert group['representative_packet_ordinal'] in indices
   representative=packets[group['representative_packet_ordinal']]; signature=wire([representative['members'],representative['commands']]); assert signature not in signatures; signatures.add(signature)
   for raw in indices: assert type(raw) is int and 0<=raw<len(packets) and wire([packets[raw]['members'],packets[raw]['commands']])==signature
   assert group['minimum_incremental_validation_checks']==min(packets[raw]['incremental_validation_checks'] for raw in indices)
  assert sorted(aliases)==list(range(len(packets))) and grouping['raw_packet_count']==len(packets) and grouping['executable_continuation_count']==len(groups)
  for packet in packets:
   commands=packet['commands']; assert packet['family'] in library_ids and commands and packet['prefix_rows']==len(prefix) and packet['checked_primitive_proof']==prefix+commands
   assert packet['host_check']['accepted'] is True and packet['host_check']['rows']==len(prefix)+len(commands) and packet['host_check']['target']==packet['result_formula'] and len(packet['members'])==2*len(commands)
   for offset,command in enumerate(commands):
    command_key,guard_key=packet['members'][2*offset:2*offset+2]; row=len(prefix)+offset
    assert command_key[:2]==[row,0] and guard_key[:2]==[row,1] and command_key[2]==guard_key[2] and domains[row][command_key[2]]==command and tuple(command_key) in placements and tuple(guard_key) in placements
   for source in packet['source_binding']:
    assert (0<=source['row']<len(prefix) and source['formula']==prefix[source['row']]['formula']) if source['kind']=='prefix' else (source['kind']=='axiom' and source['formula']==spec['theory']['axioms'][source['name']])
  choice=continuation['action']['choice']; assert 0<=choice<=len(groups) and proposal['selected_group']==(choice if choice<len(groups) else None)
  raw_pool_count+=1; raw_packet_count+=len(packets); group_count+=len(groups)
  joins.append(dict(gate=ordinal,trace_index=node,status=proposal['status'],raw_packets=len(packets),groups=len(groups),selected_group=proposal['selected_group'],snapshot_index=snapshot_index,pool_sha256=digest(pool)))
 terminal_snapshot_index=consume(record['terminal_snapshot'])
 if engine=='point':
  assert len(search['domain_audits'])==2 and all(row['complete'] is True for row in search['domain_audits'])
  events=[row for row in trace if row['event']=='decision'][:2]
  for row,event in zip(search['domain_audits'],events,strict=True): assert row['decision']==[event['kind'],event['point'],event['original_alternatives']]
  removals=search['initial_auxiliary_removals']; assert len(removals)==12 and search['metrics']['initial_auxiliary_removed_incidences']==12
  for removal in removals:
   certificate=aux[tuple(removal['auxiliary_point'])]; assert removal['candidate']==certificate['placement'] and removal['candidate_value']==certificate['placement_value'] and removal['assigned_value']==certificate['initial_value'] and removal['assigned_owner']=='initial'
 check=record['proof_check']; proof=search['proof']
 if proof is None:
  assert search['status'] in ('unknown_search_budget','exhausted_finite_symbolic_grammar','exhausted_finite_point_region') and check['status']=='NO_PROOF_CANDIDATE' and check['native_proof_accepted'] is False and check['host_check'] is check['region'] is check['native_record'] is None and search['placements']==[]
 else:
  assert check['status']=='HOST_REGION_NATIVE_ACCEPTED' and check['host_check']['accepted'] is check['native_proof_accepted'] is check['region']['complete'] is True
  assert len(proof)==spec['length']==check['host_check']['rows']==check['region']['decoded_rows'] and check['host_check']['target']==spec['target']
  assert check['region']['required_points']==check['region']['selected_placements']==2*len(proof) and check['native_limit']==1000000000; accepted(check['native_record'],spec,proof)
  assert check['native_record']['purpose']=='conditional_evaluation_'+spec['id']+'_'+method
  assert len(search['placements'])==2*len(proof) and len({tuple(key) for key in search['placements']})==len(search['placements'])
  commands={key[0]:key for key in search['placements'] if key[1]==0}; guards={key[0]:key for key in search['placements'] if key[1]==1}
  for row,command in enumerate(proof):
   ck,gk=commands[row],guards[row]; assert ck[2]==gk[2] and domains[row][ck[2]]==command and tuple(ck) in placements and tuple(gk) in placements
 assert all(number(value) and value>=0 for value in (record['full_arm_seconds'],search['seconds']))
 return dict(id=method,engine=engine,selection=mode,seed=record['seed'],search_status=search['status'],proof_status=check['status'],proof_rows=0 if proof is None else len(proof),proof_sha256=None if proof is None else digest(proof),native_query=None if check['native_record'] is None else check['native_record']['id'],attempts=search['metrics']['attempts'],attempt_unit=search['attempt_unit'],decisions=len(decisions),gate_decisions=sum(row['head']=='gate' for row in decisions),continuation_decisions=sum(row['head']=='continuation' for row in decisions),ordered_candidate_lists=order_count,terminal_snapshot_index=terminal_snapshot_index,trace_sha256=digest(trace),decisions_sha256=digest(decisions),record_sha256=digest(record),full_arm_seconds=record['full_arm_seconds'],search_seconds=search['seconds'],pool_joins=joins)

for record in case['arms']: arm_rows.append(arm_join(record))
assert snapshot_cursor==len(snapshot_keys)==sum(row['decisions']+1 for row in arm_rows) and used_native==set(range(len(queries)))
expected_summary=dict(schema=final['schema'],stage='evaluate',stage_id=STAGE,case_id=spec['id'],seed=recipe['order_label'],library_sha256=digest(science['library']),final_policy_export_sha256=digest(final),acquisition_exports=[digest(value) for value in exports[:2]],outcomes=[dict(id=row['id'],search_status=row['search_status'],proof_status=row['proof_status']) for row in arm_rows])
assert science['export']==expected_summary and 'qualified' not in science['export'] and 'policies' not in science['export']
assert digest(policies)==audit['bundle']['policies_sha256'] and science['policies_updated'] is False
assert observer['elapsed_seconds']<=observer['final_observer_gate_seconds']<=210
assert not (R/'admission'/(STAGE+'-v1.json')).exists() and not (R/'seals'/(STAGE+'-v1.json')).exists()
for value in tuple(SEEN.values()): verify(value)
final_census=sorted([pin(p) for directory in (actual,outer) for p in directory.rglob('*') if p.is_file()],key=lambda value:value['path']); assert final_census==census
native_counts=dict(collections.Counter(query['result']['status'] for query in queries))
counts=dict(arms=8,accepted_proof_occurrences=sum(row['proof_rows']>0 for row in arm_rows),UNKNOWN_arms=sum(row['proof_status']=='NO_PROOF_CANDIDATE' for row in arm_rows),proof_rows=sum(row['proof_rows'] for row in arm_rows),base_cards=2*sum(row['proof_rows'] for row in arm_rows),current_Native_records=len(queries),Native_status_counts=native_counts,current_guard_licence_members=len(ledger['members']),guard_compilation_ledgers=1,control_rows=sum(BANKS.values()),inherited_domain_audits=9,point_domain_audits=8,marking_certificates=12,selector_decisions=sum(row['decisions'] for row in arm_rows),Root_snapshots=len(snapshot_keys),raw_completed_pools=raw_pool_count,raw_packets=raw_packet_count,executable_groups=group_count,ordered_candidate_lists=all_orders,primitive_symbolic_attempts=sum(row['attempts'] for row in arm_rows if row['engine']=='symbolic'),primitive_point_attempts=sum(row['attempts'] for row in arm_rows if row['engine']=='point'),physical_census_files=len(census),physical_census_bytes=physical)
checks=[
 ('exact-once-plan-grant-barrier-custody-and-resources','Current five raw components match the offered hashes and the exact prospective plan. All109 guards, original caps, one-use grant/consumption, Root-labeled idle barrier and owned child group join. Complete worker/header/terminal/observer, bounded EOF logs, full14-file postterminal census, physical/output/reserve gates and independently folded conservative peak all pass. No partial file is present or parsed.'),
 ('complete-current-Native-owner-and-compiler-evidence',f'All {len(queries)} starts have complete current owned request/transport records, exact fixed executable/code pins, query budgets and last raw input/output hashes. Status census {native_counts} distinguishes accepted checks and rejected licence candidates, not theorem failures. The full one-ledger {len(ledger["members"])}-member request/row/theory/status map and fresh guard verifier receipts join; no Native replay.'),
 ('fresh-controls-word-model-markings-and-audits','All274 current named control receipts are complete and passed; bank IDs retain the frozen population without adopting earlier pass results. Training-only corpus and acquisition-only banks are explicitly unrequested. Nine inherited audits, full current v3 word/reference/indexed model checks, entire catalog/key ownership, target dictionary ID0/terminator256, twelve marking certificates/extensions and eight point audits/initial-removal joins agree. No Graph/checker/classifier/unifier control is rerun by C.'),
 ('all-ten-predecessors-frozen-inventory-and-policy-chain','All ten current positive Root admissions/seals/C actual components, raw guards/censuses, qualified exports and direct costs remain exact. Fresh in-actual donor evidence revalidation joins the owned acquisition Native receipts and dual wrappers: eight certificates, five paired units and four principal structures. Final16-per-engine histories/heads and32bindings match the independent final-policy freeze; no policy update or old result adoption.'),
 ('all-eight-traces-pools-actions-and-Root-samples','All eight original methods/order/seeds use the expected engines and fixed/uniform/learned modes. Every logged action has its exact frozen head and literal prefix/context/features, all returned complete pools retain raw aliases/guard variants/source bindings/Host rows, executable class partitions and representative choices. Every original candidate multiplicity and completed ordering/extension joins, symbolic novelty tiers and point forced ordering remain intact, roots roll back, and all current genuine Root samples bind in order. No RNG, softmax, reward, gradient, legality or State/Graph replay.'),
 ('current-accepted-proof-authorities-and-bounded-UNKNOWNs',f'Every returned proof has the original {spec["length"]} rows and {2*spec["length"]} distinct catalog command/guard placements, exact commands/target, accepted Host, full finite point-word region and fresh accepted owned Native blocks-empty request. The {counts["accepted_proof_occurrences"]} proof occurrences / {counts["proof_rows"]} rows are not distinct new theorems. The {counts["UNKNOWN_arms"]} bounded no-proof arms have no Host/region/Native proof or placements; they remain unsolved rather than whole failures. Declared input-structure holdouts are public authored cases,not blind or proof-DAG-disjoint. Any cutoff suffix remains subject to the original reviewed rules.'),
 ('exact-summary-no-update-and-nonoverlapping-costs','The canonical export is exactly the eight-outcome evaluation summary bound to both acquisitions, final train7 export and immutable principal library. It is neither qualified policy nor future upstream seal. Whole_seconds is the exact current observer.elapsed_seconds; its later final-gate sample is recorded separately. Prior ten-job samples fold once to248.2828798759947; common setup, marking and marginal arm clocks overlap and are not added as cold solver totals.'),
 ('whole-stage-review-only-no-comparative-claim','All eight stage outcomes and complete resource evidence qualify this one original declared-stratum case/order for a separate Root admission request. C issues no admission, seal, retry, grant or future-stage authority. The192-slot denominator remains; no blind/proof-DAG-disjoint,learning/GCTS-specific,speed,SOTA or scientific whole-study success claim is made;the two earlier whole failures remain preserved. Root must separately review and invoke the passive positive admission request if appropriate.')]
receipt=dict(schema='D21-C-conditional-stage-actual-review-v1',stage_id=STAGE,stage='evaluate',review_passed=True,resource_admitted=True,scientific_qualified=True,stage_complete=True,**components,protocol=plan['protocol'],export_sha256=digest(science['export']),input_pins=sorted(plan['files'],key=lambda value:value['path']),complete_actual_file_census=census,whole_seconds=observer['elapsed_seconds'],whole_peak_bytes=observer['final_conservative_whole_peak_bytes'],prospective_review=prospective_pin,grant=grant_pin,serial_barrier=barrier_pin,consumed=pin(actual/'CONSUMED.json'),owned_child=pin(actual/'owned-child.json'),upstream=pairs,upstream_C_actual_reviews=upstream_review_pins,final_policy_review=freeze_review_pin,final_policy_audit=audit_pin,final_policy_audit_output_review=audit_review_pin,frozen_policy_export_sha256=digest(final),frozen_policy_heads_sha256=digest({engine:policies[engine]['heads'] for engine in ('symbolic','point')}),counts=counts,bank_counts=BANKS,bank_ID_sequences_sha256=digest(control_IDs),arm_literal_joins=arm_rows,unfinished_carriers=unfinished,costs=dict(observer_elapsed_sample_seconds=observer['elapsed_seconds'],final_observer_gate_seconds=observer['final_observer_gate_seconds'],worker_elapsed_sample_seconds=worker['elapsed_seconds'],current_entry_seconds=science['seconds'],prior_unique_observer_samples_seconds=prior_seconds,shared_setup_seconds=case['shared_setup_seconds'],compile_and_model_seconds=case['compile_and_model_seconds'],word_model_seconds=case['word_model_seconds'],marking_seconds=marking['seconds'],scope='Distinct overlapping samples. No sum of nested setup/arm/worker clocks and no end-to-end tool-clock claim.'),checks=[dict(id=key,passed=True,finding=finding) for key,finding in checks],failures=[],scientific_imports=0,scientific_calls=0,helper_invocations=0,subject_replays=0,numeric_RNG_Graph_checker_replays=0,partial_files_parsed=0,Root_admission_issued=False,grants_issued=0,review_program=pin(Path(__file__).resolve()),review_parameters=parameters_pin,Root_terminal_packet=parameters['Root_terminal_packet'],Root_window=parameters['Root_window'],Root_barrier_authoring_negative=metadata_negative_pin,owned_passive_metadata_correction=pin(C/'typed-remaining16-owned-passive-metadata-ABI-negative-v1.json'),declared_stratum=recipe['stratum'],predecessor_passive_review_program=pin(C/'passive_five_evaluation_actual_reviews_v1.py'),scope='Independent current complete original evaluation saved-evidence review only. Primitive proof/Native/current Source receipts are joined literally; no scientific replay or Root admission. The original declared stratum is retained;public authored input-structure holdouts are not blind or all-proof-DAG-disjoint. Exact future passive requests/outputs remain separate;prior whole failures are never salvaged.',tools_idle_after_freeze=True)
output=C/('typed-'+STAGE+'-actual-review-v1.json')
with output.open('xb') as stream: stream.write((json.dumps(receipt,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode())
print(json.dumps(pin(output)))
