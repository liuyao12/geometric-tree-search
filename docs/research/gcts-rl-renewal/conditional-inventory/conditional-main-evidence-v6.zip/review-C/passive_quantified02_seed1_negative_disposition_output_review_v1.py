"""Raw negative Root disposition output review; no admission or subject replay."""
from pathlib import Path
import hashlib,json
D=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-conditional-selector-main-20261021');R=D/'root';C=D/'review-C';ID='eval-eval-quantified-02-seed1';seen={}
def need(v,m):
 if not v:raise ValueError(m)
def pin(p):
 p=Path(p);need(p.is_absolute() and p.resolve()==p and p.is_file() and not p.is_symlink(),'ordinary canonical file');b=p.read_bytes();q=dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
 if str(p)in seen:need(seen[str(p)]==q,'stable current pin')
 seen[str(p)]=q;return q
def verify(q):need(pin(q['path'])==q,'exact raw pin');return q
def load(q):
 if isinstance(q,(str,Path)):q=pin(q)
 verify(q);need('.partial'not in Path(q['path']).name,'complete JSON only');return json.loads(Path(q['path']).read_bytes())
outpin=pin(R/'admission'/(ID+'-v1.json'));need(outpin['bytes']==6807 and outpin['sha256']=='e9d48b3f68ae7a72a7992fe2b7176fcf0c1b3b8ebed23b16a9240c6f8aabe0d9','exact offered negative output')
a=load(outpin);c=load(a['C_actual_review'])
need(a['C_actual_review']['bytes']==52188 and a['C_actual_review']['sha256']=='3dfa1a4dbb834b2c05d334a39ec6d26414237cdee25e192bebe5debcfb468daa','exact independent whole failure review')
need(c['review_passed']is True and c['checks']and all(row['passed']is True for row in c['checks'])and c['failures']==[],'supported negative classification')
need(a['schema']=='D21-Root-conditional-stage-admission-v1'and a['stage_id']==c['stage_id']==ID and a['stage']==c['stage']=='evaluate','exact negative schema/identity')
need(all(a[key]is False for key in ('admitted','resource_admitted','scientific_qualified','stage_complete'))and all(c[key]is False for key in ('resource_admitted','scientific_qualified','stage_complete')),'all four Root gates false')
need(a['result']is c['result']is None and a['failure']==c['failure']and a['whole_peak_bytes']is c['whole_peak_bytes']is None,'null result/qualified peak and exact complete failure')
for key in ('plan','failure','header','terminal','observer','protocol'):verify(a[key]);need(a[key]==c[key],'same current failed components/protocol')
need(a['complete_actual_file_census']==c['complete_actual_file_census']and len(a['complete_actual_file_census'])==13,'same complete13rawfile census')
for value in c['input_pins']+c['complete_actual_file_census']:verify(value)
actual=D/'actual'/ID;outer=D/'actual'/(ID+'.observer')
census=sorted([pin(path)for directory in(actual,outer)for path in directory.rglob('*')if path.is_file()],key=lambda q:q['path'])
need(census==c['complete_actual_file_census']and not any('.partial'in Path(q['path']).name for q in census),'exact unchanged physical census/no partial')
w=load(a['failure']);o=load(a['observer']);t=load(a['terminal']);h=load(a['header'])
need(w['scientific_result']is None and w['first_Root_fault']is True and w['error']['type']==a['error']['type']=='RootBudget'and w['error']['message']==a['error']['message']=='absolute case work deadline','same whole fault with no returned scientific prefix')
need(a['disposition']=='WHOLE_JOB_WORK_DEADLINE_FAILURE'and type(a['arms'])is str and a['arms']=='All eight original slots unavailable due to whole-job failure; no arm or proof admitted.','explanatory unavailable text only, no structured arm/proof payload')
need(a['whole_seconds']==c['whole_seconds']==o['elapsed_seconds']==160.8284132500121 and o['final_conservative_whole_peak_bytes']is None,'literal failed-job cost and null qualified peak')
need(o['resource_candidate_accepted']is False and t['process_exit_code']==o['parent_exit_code']==2 and h['native_closed_and_reaped']is t['threads_terminal']is True and w['native_transport']['closed']is w['native_transport']['all_reaped']is True,'same reviewed failure and completed cleanup')
need(all(type(a[key])is int and a[key]==0 for key in ('scientific_imports','scientific_calls','numeric_RNG_Graph_checker_replays','partial_files_parsed')),'typed zero replay counters')
need(not any(key in a for key in ('seal','helper','request','export_sha256','policies','qualified','literal_provenance'))and not(actual/'result.json').exists()and not(R/'seals'/(ID+'-v1.json')).exists(),'no positive helper/request/export/seal or prefix authority')
for value in tuple(seen.values()):verify(value)
need(set(a)=={'C_actual_review','admitted','arms','author','complete_actual_file_census','created_utc','disposition','error','failure','header','numeric_RNG_Graph_checker_replays','observer','partial_files_parsed','plan','protocol','resource_admitted','result','schema','scientific_calls','scientific_imports','scientific_qualified','scope','stage','stage_complete','stage_id','terminal','whole_peak_bytes','whole_seconds'},'negative output exact common fieldset,not positive provenance or arm carriers')
need(w['native_requests_started']==136 and len(w['native_queries'])==135 and w['native_transport']['request_stages'][-1]['purpose']=='conditional_evaluation_eval-quantified-02_SF' and w['native_transport']['request_stages'][-1]['ordinal']==135 and w['native_transport']['request_stages'][-1]['stage']=='SENT','current whole failure finalSFquery unresolved')
need(w['native_queries'][-1]['purpose']=='conditional_evaluation_eval-quantified-02_SU' and 'Complete SU-purpose Native query stays raw diagnostic evidence, not an admitted arm/proof or a recovered scientific prefix.' in a['scope'],'Root scope explicitly excludes completedSUquery salvage')
prior_pin=pin(R/'admission/eval-eval-quantified-02-seed0-v1.json');prior=load(prior_pin)
prior_review_pin=pin(C/'typed-quantified02-negative-disposition-actual-output-review-v1.json');prior_review=load(prior_review_pin)
need(prior_pin['bytes']==6678 and prior_pin['sha256']=='64fb429c1271f8c2ef9cf44c86722271eb08e7c94edccf05403960ebca41ddd1' and prior_review_pin['sha256']=='f7e4a503cd61bc1d0fd3c6c554c6cb416140511e6609745dd7fa6cf6ad8902cd','frozen prior seed0negative/current output review')
need(prior_review['review_passed'] is True and prior_review['Root_negative_output']==prior_pin and prior_review['checks'] and all(row['passed'] is True for row in prior_review['checks']) and prior_review['failures']==[] and prior['result'] is prior['whole_peak_bytes'] is None and all(prior[key] is False for key in ('admitted','resource_admitted','scientific_qualified','stage_complete')),'prior seed0negative is not upgraded or replaced')
for value in tuple(seen.values()):verify(value)
checks=[
 ('exact-current-negative-output-and-C-components','Exact6,807-byte Rootnegative binds the current52,188-byte independent five-check wholefailure review and exactplan/failure/header/terminal/observer/protocol pins. All13physical files and109plan-onlyguards rehash current;no partial is present or parsed.'),
 ('four-false-gates-null-result-peak-and-direct-cost','Admitted/resource/scientific/stagegates are allfalse,resultnull,completefailurepin exact,qualifiedwholepeaknull. Directobserver.elapsed_seconds160.8284132500121 is preserved without adding laterfinalgate or nestedclocks. No Python/NativeRSS is relabeled as qualifiedpeak or evidenceofmemoryexceedance.'),
 ('no-SU-prefix-arm-proof-export-helper-or-seal-admission','Null scientific_result and stickywholeworkdeadline remain. Saveddiagnostics have135completerecords and onependingordinal135SFquery;completeSUquery stays diagnostic only,explicit inRootscope. Arms is explanatory unavailabletext,not8structuredresults or prefix. Exactnegativefieldset has no helper/request/export/policy/seal/provenance admission fields;resultandsealpaths absent. Native/terminalcleanup remainscomplete.'),
 ('prior-seed0-negative-preserved-and-future-independent-work','Frozen6,678-byte seed0Rootnegative and itsCoutputPASS remainexact,fourfalse/resultnull/peaknull. Currentseed1Rootnegative does notretry,repair,adoptorreplaceit. C validates savedoutputs only. The16lateroriginalindependent jobs remain pending undertheir originalrecipe/caps and require a fresh Roottools-idle cleanupbarrier/oneusegrant before anyactual;no helper/scientific invocation or futureauthority.')]
receipt=dict(schema='D21-C-whole-failure-negative-disposition-output-review-v1',review_passed=True,stage_id=ID,Root_negative_output=outpin,C_whole_failure_review=a['C_actual_review'],protocol=a['protocol'],components={key:a[key] for key in ('plan','failure','header','terminal','observer')},result=None,resource_admitted=False,scientific_qualified=False,stage_complete=False,admitted=False,whole_seconds=a['whole_seconds'],whole_peak_bytes=None,complete_actual_file_census=a['complete_actual_file_census'],prior_seed0_Root_negative=prior_pin,prior_seed0_output_review=prior_review_pin,checks=[dict(id=k,passed=True,finding=v) for k,v in checks],failures=[],scientific_imports=0,scientific_calls=0,helper_invocations=0,subject_replays=0,partial_files_parsed=0,live_PID_probes=0,Root_admission_issued=False,scope='Independent exact current Rootnegative-output preservation only. ReviewPASS confirms supported wholefailure withallqualificationgatesfalse;noarm/proof/policy/export qualified. Priorseed0negative remainsimmutable. No helper/scientific invocation,retry,liveprobe or futureactual authority.',review_program=pin(Path(__file__).resolve()),preserved_prior_review_program=pin(C/'passive_quantified02_negative_disposition_output_review_v1.py'),tools_idle_after_freeze=True)
out=C/'typed-quantified02-seed1-negative-disposition-actual-output-review-v1.json'
with out.open('xb') as stream:stream.write((json.dumps(receipt,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode())
print(json.dumps(pin(out)));print(json.dumps(dict(checks=len(checks),failures=0,all_four_qualification_gates=False,qualified_peak=None,tools_idle=True)))
