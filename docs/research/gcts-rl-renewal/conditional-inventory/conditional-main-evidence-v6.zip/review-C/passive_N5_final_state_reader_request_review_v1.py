"""C-owned narrow current N5 state/request composition review; no subject calls."""
from pathlib import Path
import collections
import hashlib
import json

D = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-conditional-selector-main-20261021')
R, C, L = D/'root', D/'review-C', D/'diagnostics-L'
checked = {}

def need(value, message):
    if not value:
        raise ValueError(message)

def wire(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode()

def digest(value):
    return hashlib.sha256(wire(value)).hexdigest()

def pin(path):
    path = Path(path)
    need(path.is_absolute() and path.resolve() == path and path.is_file() and not path.is_symlink() and '.partial' not in path.name, 'ordinary canonical complete file')
    body = path.read_bytes()
    value = dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())
    if str(path) in checked:
        need(checked[str(path)] == value, 'stable current raw identity')
    checked[str(path)] = value
    return value

def verify(value):
    need(pin(value['path']) == value, 'exact current raw pin')
    return value

def load(value):
    if isinstance(value, (str, Path)):
        value = pin(value)
    verify(value)
    return json.loads(Path(value['path']).read_bytes())

def passed(value):
    body = load(value)
    need(body['review_passed'] is True and body['checks'] and all(check['passed'] is True for check in body['checks']) and body['failures'] == [], 'nonempty all-PASS review')
    return body

state_pin = pin(R/'conditional-main-report-state-v5.json')
request_pin = pin(R/'conditional-main-reader-request-v5.json')
need((state_pin['bytes'], state_pin['sha256']) == (17009, 'e67c8812d159d2bb4d488f6244eea4b0396ccdff00947616420f75713ca036eb'), 'exact final N5 state')
need((request_pin['bytes'], request_pin['sha256']) == (938, '65672ba3f4516ae190f217c4bef206e89f738f6fd058b7a6a02d33f0f94b2e6b'), 'exact five-field reader request')
state, request = load(state_pin), load(request_pin)
population_pin = pin(C/'typed-open-N5-population-offer-review-v1.json')
need((population_pin['bytes'], population_pin['sha256']) == (65257, 'b2599ce701c0b7c207acef06e317f857627842986528813515b9da325000599e'), 'exact prior population PASS')
population = passed(population_pin)
offer_pin = verify(population['population_offer'])
offer = load(offer_pin)
need(set(state) == set(offer) | {'C_review'} and 'C_review' not in offer and state['C_review'] == population_pin, 'sole added top-level C review pin')
disposition = {key: value for key, value in state.items() if key != 'C_review'}
need(wire(disposition) == wire(offer), 'final state equals complete reviewed offer except sole C review pin')
disposition_sha = digest(disposition)
need(disposition_sha == population['population_disposition_sha256'] == 'e79b7fa5c507c280c069abf19cd58a55f6873e45c76caddd6dd877ff55e0db2f', 'entire disposition digest unchanged')
need(population['schema'] == 'D21-C-main-report-population-review-v1' and population['report_version'] == 5 and state['schema'] == 'D21-Root-main-report-state-v3' and state['report_version'] == 5 and state['closed'] is False, 'typed OPEN N5 bindings')

protocol_pin = verify(population['protocol'])
protocol = load(protocol_pin)
need(state['protocol'] == protocol_pin and (protocol_pin['bytes'], protocol_pin['sha256']) == (38955, 'c04ff4523941d5552b6ffee42f73d8a5c189191ea1004b82fc28d0122b3e7422'), 'unchanged original protocol')
need(set(request) == {'schema', 'report_version', 'protocol', 'population', 'template'} and request['schema'] == 'D21-passive-main-reader-request-v3' and type(request['report_version']) is int and request['report_version'] == 5 and request['protocol'] == protocol_pin and request['population'] == state_pin, 'exact five-field current request')
source_pin, api_pin, template_pin = [verify(population[key]) for key in ('reader_Source', 'reader_API', 'reader_template')]
source_review_pin = verify(population['reader_Source_review'])
source_review = passed(source_review_pin)
need(source_review['Source'] == source_pin and source_review['API'] == api_pin and source_review['template'] == template_pin and source_review['current_protocol'] == protocol_pin, 'exact unchanged prior Source review composition')
need((source_pin['bytes'], source_pin['sha256']) == (28157, '81838f929750cc78f5a3b5f9562f83449fdfa21d6459f855a91c37eb2f3c9da9') and (api_pin['bytes'], api_pin['sha256']) == (10030, '21f4278959f8698adfdaf983c1cf0255bdfc054e785582ce8043c368cf306e51'), 'unchanged Source4 and API4')
need(request['template'] == template_pin and template_pin['path'] == str(L/'conditional-main-v4.html') and (template_pin['bytes'], template_pin['sha256']) == (20538, '80ac1e2822809a6b6a99f27e0780f60c96bac9126cffedc91ed6eb3bffd5a122'), 'exact reviewed template pin')
template_text = Path(template_pin['path']).read_text()
need(template_text.count('@@D21_DATA_FILENAME@@') == 2 and template_text.count('@@D21_ARCHIVE_FILENAME@@') == template_text.count('@@D21_MANIFEST_FILENAME@@') == 1, 'reviewed fixed token occurrences')

need(len(state['jobs']) == len(protocol['job_recipes']) == 34 and [row['stage_id'] for row in state['jobs']] == [row['stage_id'] for row in protocol['job_recipes']], 'full original ordered recipe population')
need(collections.Counter(row['status'] for row in state['jobs']) == dict(QUALIFIED=16, FAILED=1, PENDING=17), 'current unchanged 16/1/17 population')
rows = {row['stage_id']: row for row in state['jobs']}
need(len(population['current_decisions']) == 17, 'prior whole current decision set')
for value in population['current_decisions']:
    need(rows[value['stage_id']]['admission'] == value['admission'], 'same state decision owner')
    admission = load(value['admission'])
    verify(value['C_actual_review'])
    need(admission['C_actual_review'] == value['C_actual_review'] and admission['protocol'] == protocol_pin, 'same current admission and C actual binding')
for key in ('first_evaluation_admission_output_review', 'five_evaluation_admission_output_review', 'negative_disposition_output_review'):
    passed(population[key])
need(population['counts']['training_episode_slots'] == 32 and population['counts']['evaluation_slots'] == 192 and population['counts']['evaluation_whole_failure_unavailable_slots'] == 8 and population['counts']['evaluation_pending_slots'] == 136, 'original training/evaluation denominators retained')

destinations = dict(reader_data=str(D/'publication/conditional-main-data-v5.json'), reader_html=str(D/'publication/conditional-main-report-v5.html'))
need(all(not Path(path).exists() for path in destinations.values()), 'both intended exclusive outputs absent')
for value in tuple(checked.values()):
    verify(value)

checks = [
    ('exact-final-state-only-adds-reviewed-C-pin', 'The exact 17,009-byte final state equals the previously reviewed complete 16,702-byte offer plus only its exact typed C_review pin. The canonical entire disposition excluding only C_review retains e79b7fa5c507c280c069abf19cd58a55f6873e45c76caddd6dd877ff55e0db2f.'),
    ('exact-five-field-version-five-request', 'The exact 938-byte request has only the reviewed schema, integer report_version 5, current protocol, exact final population pin, and exact template pin. Canonical current paths match unchanged reader4 request handling.'),
    ('current-Source-API-template-and-prior-reviews', 'Reader4 Source, API4, template4, full independent Source PASS, typed population PASS and separate evaluation output reviews remain byte-identical. Template token occurrences remain two data, one archive and one manifest; no Source or renderer call occurred.'),
    ('unchanged-open-disposition-current-decision-pins', 'All 34 original ordered recipes retain 16 QUALIFIED, one FAILED and 17 PENDING. All 17 current Root admission pins and associated C actual pins remain exact. All 32 training and 192 evaluation slots remain; the failure supplies eight unavailable slots, with 136 pending. Prior full scientific validation is reused by exact raw identity, without repetition or prefix salvage.'),
    ('absent-exclusive-outputs-and-prospective-scope', 'Both derived N5 data and HTML output paths are absent. This receipt reviews the exact intended unchanged reader4 composition only. Root alone may invoke the passive projector once; output, browser, packaging, publication and future actual qualification remain separate.'),
]
receipt = dict(schema='D21-C-main-final-state-reader-request-review-v1', review_passed=True, report_version=5,
    protocol=protocol_pin, population=state_pin, reader_request=request_pin, population_offer=offer_pin,
    C_population_review=population_pin, population_disposition_sha256=disposition_sha,
    reader_Source=source_pin, reader_API=api_pin, reader_template=template_pin, reader_Source_review=source_review_pin,
    counts=population['counts'], observer_sample_seconds=population['decided_unique_observer_sample_seconds'],
    current_decision_raw_pins=[value['admission'] for value in population['current_decisions']],
    intended_outputs=destinations, intended_outputs_absent=True,
    checked_current_pins=sorted(checked.values(), key=lambda value: value['path']),
    checks=[dict(id=key, passed=True, finding=finding) for key, finding in checks], failures=[],
    partial_files_parsed=0, scientific_calls=0, scientific_imports=0, subject_replays=0,
    helper_invocations=0, projector_invocations=0, Root_state_written_by_C=False, Root_admission_issued=False,
    scope='Exact prospective N5 final-state and reader-request composition only; no output, browser, archive, publication or scientific execution authority.',
    review_program=pin(Path(__file__).resolve()), tools_idle_after_freeze=True)
out = C/'typed-open-N5-final-state-reader-request-review-v1.json'
with out.open('xb') as stream:
    stream.write((json.dumps(receipt, sort_keys=True, indent=2, ensure_ascii=False, allow_nan=False)+'\n').encode())
print(json.dumps(pin(out)))
print(json.dumps(dict(checks=len(checks), failures=0, tools_idle=True)))
