"""Independent raw saved-data joins. No projector or scientific module is imported/called."""
import hashlib
import json
from pathlib import Path
from collections import Counter
S=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-conditional-selector-main-20261021')
C=S/'review-C';R=S/'root';checked={};expected_inputs={}
def need(v,msg):
    if not v:raise ValueError(msg)
def wire(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def same(a,b):return wire(a)==wire(b)
def pin(p):
    p=Path(p);need(p.is_absolute() and p.resolve()==p and p.is_file() and not p.is_symlink() and '.partial' not in p.name,'complete canonical ordinary file')
    b=p.read_bytes();q=dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
    if str(p) in checked:need(checked[str(p)]==q,'stable current body')
    checked[str(p)]=q;return q
def unique(rows):
    out={}
    for k,v in rows:need(k not in out,'duplicate JSON key');out[k]=v
    return out
def load(q,projection=False):
    if isinstance(q,(Path,str)):q=pin(q)
    need(set(q)=={'path','bytes','sha256'} and pin(q['path'])==q,'strict current pin')
    if projection:expected_inputs[q['path']]=q
    return json.loads(Path(q['path']).read_bytes(),object_pairs_hook=unique,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
def passed(v):need(v['review_passed'] is True and v['checks'] and all(x['passed'] is True for x in v['checks']) and v['failures']==[],'typed prior PASS')
def at(value,locator):
    for key in locator:value=value[key]
    return value

data_pin=pin(S/'publication/conditional-main-data-v6.json');html_pin=pin(S/'publication/conditional-main-report-v6.html')
need(data_pin['bytes']==31911254 and data_pin['sha256']=='82626cce597491a74b42da6d2ddc22fe174e6bf47e84e8e202ccd3036547129b' and html_pin['bytes']==20570 and html_pin['sha256']=='2f2b210cba72c5fcafd014bb5234815e36e104d8674d4a78258f6273b608e357','offered current outputs')
d=load(data_pin);request_pin=pin(R/'conditional-main-reader-request-v6.json');request=load(request_pin,True)
p=load(request['protocol'],True);state=load(request['population'],True)
template_pin=request['template'];load_template=pin(template_pin['path']);need(load_template==template_pin,'exact template');expected_inputs[template_pin['path']]=template_pin
population_review_pin=pin(C/'typed-closed-N6-population-offer-review-v1.json');pop=load(population_review_pin,True);passed(pop)
request_review_pin=pin(C/'typed-closed-N6-final-state-reader-request-review-v1.json');request_review=load(request_review_pin);passed(request_review)
source_review_pin=pin(C/'typed-reusable-compact-reader-Source-review-v4.json');sr=load(source_review_pin);passed(sr)
need(request_review['reader_request']==request_pin and request_review['population']==request['population'] and request_review['C_population_review']==population_review_pin and state['C_review']==population_review_pin and pop['protocol']==request['protocol'] and pop['population_disposition_sha256']==hashlib.sha256(wire({k:v for k,v in state.items() if k!='C_review'})).hexdigest(),'exact independently reviewed N6 population and final request')
need(request_review_pin['sha256']=='88b367fb57581f6cddbf82716473a8e1eacbfea816d224b35356a3a47f9e77d1' and population_review_pin['sha256']=='d247c0d2e321698efbdaad786a0cae9e61be21cd375ab7fe7df46929223ef145','exact prior independent receipts')
need(sr['Source']==pin(S/'diagnostics-L/project_conditional_main_reader_v4.py') and sr['template']==template_pin and sr['API']==pin(S/'diagnostics-L/reader-API-v4.json'),'unchanged full reader Source/API/template review')
need(d['schema']=='D21-passive-conditional-main-reader-v3' and type(d['report_version']) is int and d['report_version']==6 and d['closed'] is True and d['as_of']==state['as_of'],'exact closed original N6 headers')
need(d['protocol_source']==request['protocol'] and d['population_source']==request['population'] and d['request_source']==request_pin,'exact output request/protocol/state')
expected_render=dict(template_source=template_pin,data_filename='conditional-main-data-v6.json',html_filename='conditional-main-report-v6.html',archive_filename='conditional-main-evidence-v6.zip',manifest_filename='conditional-main-manifest-v6.json')
need(d['rendering']==expected_render,'same numbered fouroutput names')
html=Path(html_pin['path']).read_bytes();template=Path(template_pin['path']).read_bytes()
expected_html=template.replace(b'@@D21_DATA_FILENAME@@',b'conditional-main-data-v6.json').replace(b'@@D21_ARCHIVE_FILENAME@@',b'conditional-main-evidence-v6.zip').replace(b'@@D21_MANIFEST_FILENAME@@',b'conditional-main-manifest-v6.json')
need(html==expected_html and b'@@D21_' not in html,'exact reviewed HTML plus four safe filename substitutions only')
docs={phase:load(q,True) for phase,q in p['phase_inputs'].items()};need(same(d['documents'],docs),'all three exact phase documents as report only')
need(len(d['jobs'])==34 and len(d['training'])==32 and len(d['evaluation'])==192 and len(d['proofs'])==200 and len(d['inventory'])==2 and len(d['policies'])==8,'full output array populations')
proof_position=0;training_position=0;evaluation_position=0;inventory_position=0;policy_position=0;seconds=0.0
trace_joins=[];proof_joins=[];job_joins=[];family_ids=set();structure_ids=set();training_unknown=[]
for recipe,row,job in zip(p['job_recipes'],state['jobs'],d['jobs'],strict=True):
    identity=recipe['stage_id'];stage=recipe['stage'];positive=row['status']=='QUALIFIED'
    expected_base=dict(stage_id=identity,stage=stage,state=row['status'],reason=row['reason'],blocking_stage_ids=row['blocking_stage_ids'],required_upstream_ids=recipe['required_upstream_ids'])
    for k,v in expected_base.items():need(same(job[k],v),'job literal state '+k)
    science=None;packet=None;admission=None
    if row['status'] in ('QUALIFIED','FAILED'):
        admission=load(row['admission'],True);plan=load(admission['plan'],True);review=load(admission['C_actual_review'],True);passed(review)
        for k in ('header','terminal','observer'):load(admission[k],True)
        active='result' if positive else 'failure'
        raw_packet=load(admission[active],True);observer=load(admission['observer'],True)
        need(job['admission_source']==row['admission'] and same(job['admission'],admission) and job['packet_source']==admission[active],'exact current full admission and active result/failure forwarding')
        need(set(job)==set(expected_base)|{'admission_source','admission','packet_source','complete_record_returned','observer_sample_seconds','observer_final_gate_seconds','whole_peak_bytes','worker_status','error','Native_started','callbacks'},'exact complete job fieldset')
        for k in ('plan','header','terminal','observer',active):need(review[k]==admission[k],'same current C components')
        need(plan['Root_recipe']==recipe and plan['protocol']==request['protocol'] and plan['case_id']==identity,'original whole plan owner')
        need(job['worker_status']==raw_packet['status'] and same(job['error'],raw_packet['error']) and job['Native_started']==raw_packet['native_requests_started'] and job['callbacks']==raw_packet['callbacks'],'full current worker diagnostics')
        need(job['observer_sample_seconds']==admission['whole_seconds']==observer['elapsed_seconds'] and job['observer_final_gate_seconds']==observer.get('final_observer_gate_seconds') and job['whole_peak_bytes']==admission['whole_peak_bytes']==observer['final_conservative_whole_peak_bytes'],'direct distinct observer clocks and qualified peak including null')
        seconds+=job['observer_sample_seconds']
        if positive:
            packet=raw_packet;science=packet['scientific_result']
            need(all(admission[k] is True for k in ('admitted','resource_admitted','scientific_qualified','stage_complete')) and all(review[k] is True for k in ('resource_admitted','scientific_qualified','stage_complete')),'positive whole gates')
            need(science['stage_id']==identity and science['stage_complete'] is True and science['job_record_complete'] is True and packet['status']=='COMPLETE' and packet['source_unchanged'] is True and packet['error'] is None,'complete current actual eligibility')
            need(same(science['inputs'],docs[stage]) and same(science['native_records'],packet['native_queries']),'exact current phase and owned stream')
            need(hashlib.sha256(wire(science['export'])).hexdigest()==(admission['literal_provenance']['returned_summary_sha256'] if stage=='evaluate' else admission['export_sha256'])==review['export_sha256'],'same admitted export or evaluation summary in its declared stage-specific carrier')
            need(job['complete_record_returned'] is True,'complete positive record returned')
        else:
            need(identity in ('eval-eval-quantified-02-seed0','eval-eval-quantified-02-seed1') and all(admission[k] is False for k in ('admitted','resource_admitted','scientific_qualified','stage_complete')) and all(review[k] is False for k in ('resource_admitted','scientific_qualified','stage_complete')),'exact whole-negative fourfalse disposition')
            need(admission['result'] is review['result'] is None and raw_packet['scientific_result'] is None and raw_packet['first_Root_fault'] is True and raw_packet['error']['type']=='RootBudget' and job['complete_record_returned'] is False,'no failed scientific packet or earlier-arm salvage')
            need(job['whole_peak_bytes'] is None and job['observer_sample_seconds']==review['whole_seconds'] and job['observer_final_gate_seconds']==review['diagnosis']['final_observer_gate_seconds'],'failed null qualified peak and distinct unchanged samples')
            need(len(admission['complete_actual_file_census'])==13 and same(admission['complete_actual_file_census'],review['complete_actual_file_census']),'full negative census reference retained')
            need(not(R/'seals'/(identity+'-v1.json')).exists(),'no evaluation seal')
        job_joins.append(dict(stage_id=identity,state=row['status'],admission=row['admission'],C_actual_review=admission['C_actual_review'],active_packet=admission[active]))
    else:
        for k in ('admission_source','admission','packet_source','observer_sample_seconds','observer_final_gate_seconds','whole_peak_bytes','worker_status','error','Native_started','callbacks'):need(job[k] is None,'pending literal null '+k)
        need(job['complete_record_returned'] is False,'pending not returned')
    if stage=='acquire' and positive:
        case=science['records'][0];cases=[(case,case,'S0',None)]
        inv=d['inventory'][inventory_position];inventory_position+=1
        need(inv['stage_id']==identity and inv['donor_id']==case['spec']['id'] and inv['source']==admission['result'],'perdonor inventory owner')
        for k in ('libraries','certificates','pairing'):need(same(inv[k],science[k]),'full saved inventory '+k)
        for f in inv['libraries']['principal']:family_ids.add(f['paired_unit_id']);structure_ids.add(f['structural_id'])
        need(len(inv['libraries']['atom'])==3 and len(inv['libraries']['principal'])==3 and len(inv['certificates'])==4,'perdonor3units4certoccurrences')
    else:cases=[]
    if stage=='train':
        returned={}
        if positive:
            for ci,case in enumerate(science['records']):
                for ei,record in enumerate(case['episodes']):returned[record['descriptor']['global_ordinal']]=(case,record,ci,ei)
            need(set(returned)=={x['global_ordinal'] for x in recipe['episodes']},'allfour prescribed current episodes')
            policy=d['policies'][policy_position];policy_position+=1;export=science['export']
            need(policy['stage_id']==identity and policy['source']==admission['result'] and policy['admitted'] is True and policy['bundle_sha256']==admission['export_sha256'],'current admitted bundle owner/digest')
            need(same(policy['heads'],{e:x['heads'] for e,x in export['policies'].items()}) and policy['episodes']=={e:x['episodes'] for e,x in export['policies'].items()} and policy['history_counts']=={e:len(x['history']) for e,x in export['policies'].items()} and same(policy['policy_checks'],science['policy_checks']),'all policy heads/history/count/check fields exact')
        for descriptor in recipe['episodes']:
            item=d['training'][training_position];training_position+=1
            need(item['stage_id']==identity and item['descriptor']==descriptor and item['state']==row['status'],'training slot exactrecipe')
            if not positive:
                need(item==dict(stage_id=identity,descriptor=descriptor,state=row['status'],returned=False,admitted_proof=False,proof_view_index=None,search_status=None,proof_status=None),'pending training placeholder')
                continue
            case,record,ci,ei=returned[descriptor['global_ordinal']];search=record['search'];locator=['scientific_result','records',ci,'episodes',ei,'search']
            need(item['returned'] is True and item['search_status']==search['status'] and item['proof_status']==record['proof_check']['status'] and item['native_proof_observed']==record['proof_check']['native_proof_accepted'],'training raw statuses')
            for target,source in [('metrics','metrics'),('attempt_unit','attempt_unit'),('search_seconds','seconds'),('root_restored','root_restored')]:need(same(item[target],search.get(source,{} if source=='metrics' else None)),'raw search field '+target)
            for key in ('full_arm_seconds','terminal_snapshot','cost_scope','selection','seed'):need(same(item[key],record.get(key)),'raw episode field '+key)
            ref=item['trace_reference'];need(ref['packet_source']==admission['result'] and ref['search_locator']==locator and same(at(packet,locator),search),'literal complete search locator')
            need(set(ref['arrays'])=={'trace','selector_decisions'},'two declared diagnostic arrays')
            for field in ('trace','selector_decisions'):
                arr=ref['arrays'][field];present=field in search
                need(type(arr['present']) is bool and arr['present'] is present,'literal array presence')
                if present:
                    need(type(search[field]) is list and type(arr['rows']) is int and arr['rows']==len(search[field]) and arr['canonical_sha256']==hashlib.sha256(wire(search[field])).hexdigest() and arr['locator']==locator+[field] and same(at(packet,arr['locator']),search[field]),'exact array length/hash/locator')
                else:need(arr['rows'] is None and arr['canonical_sha256'] is None and arr['locator'] is None,'missing instrumentation staysnull')
            need(item['selector_decisions']==ref['arrays']['selector_decisions']['rows'],'selector count exact')
            trace_joins.append(dict(stage_id=identity,descriptor=descriptor,packet_source=ref['packet_source'],search_locator=locator,arrays=ref['arrays']))
            if not item['admitted_proof']:training_unknown.append(dict(stage_id=identity,descriptor=descriptor,status=item['search_status'],proof_status=item['proof_status']))
            cases.append((case,record,descriptor['engine']+'-learned',item))
    if stage=='evaluate':
        arms=[];case=None
        if positive:
            need(len(science['records'])==1 and science['policies_updated'] is False and science['all_eight_searched'] is True,'one complete immutable-policy eight-arm packet')
            case=science['records'][0];arms=case['arms']
            need(case['spec']['id']==recipe['case_id'] and [arm['id'] for arm in arms]==recipe['method_order'],'exact original ordered eight methods')
            need(not(R/'seals'/(identity+'-v1.json')).exists(),'evaluation creates no policy seal')
        for index,method in enumerate(recipe['method_order']):
            item=d['evaluation'][evaluation_position];evaluation_position+=1
            base=dict(stage_id=identity,case_id=recipe['case_id'],order_label=recipe['order_label'],stratum=recipe['stratum'],method=method,source_index=index,rng_seeds=recipe['rng_seeds'],state=row['status'],returned=False,admitted_proof=False,proof_view_index=None,search_status=None,proof_status=None)
            for key,value in base.items():
                if key not in ('returned','admitted_proof','proof_view_index','search_status','proof_status'):need(same(item[key],value),'literal original evaluation slot '+key)
            if not positive:
                need(item==base,'whole failure or pending slot has no returned arm, status, proof or compact diagnostic artifact')
                continue
            record=arms[index];search=record['search'];locator=['scientific_result','records',0,'arms',index,'search']
            need(item['returned'] is True and item['search_status']==search['status'] and item['proof_status']==record['proof_check']['status'] and item['native_proof_observed']==record['proof_check']['native_proof_accepted'],'evaluation raw statuses')
            for target,source in [('metrics','metrics'),('attempt_unit','attempt_unit'),('search_seconds','seconds'),('root_restored','root_restored')]:need(same(item[target],search.get(source,{} if source=='metrics' else None)),'raw evaluation search field '+target)
            for key in ('full_arm_seconds','terminal_snapshot','cost_scope','selection','seed'):need(same(item[key],record.get(key)),'raw evaluation arm field '+key)
            ref=item['trace_reference'];need(ref['packet_source']==admission['result'] and ref['search_locator']==locator and same(at(packet,locator),search),'exact current complete arm search locator')
            need(set(ref['arrays'])=={'trace','selector_decisions'},'two declared compact diagnostic arrays')
            for field in ('trace','selector_decisions'):
                arr=ref['arrays'][field];present=field in search
                need(type(arr['present']) is bool and arr['present'] is present,'literal evaluation array presence')
                if present:
                    need(type(search[field]) is list and type(arr['rows']) is int and arr['rows']==len(search[field]) and arr['canonical_sha256']==hashlib.sha256(wire(search[field])).hexdigest() and arr['locator']==locator+[field] and same(at(packet,arr['locator']),search[field]),'exact evaluation array count/hash/locator')
                else:need(arr['rows'] is None and arr['canonical_sha256'] is None and arr['locator'] is None,'missing diagnostic remains null rather than zero')
            need(item['selector_decisions']==ref['arrays']['selector_decisions']['rows'],'evaluation decision count literal')
            trace_joins.append(dict(stage_id=identity,method=method,packet_source=ref['packet_source'],search_locator=locator,arrays=ref['arrays']))
            cases.append((case,record,method,item))
    for case,record,method,item in cases:
        gate=record['proof_check'];search=record['search']
        if gate['status']!='HOST_REGION_NATIVE_ACCEPTED':
            need(item is not None and item['admitted_proof'] is False and item['proof_view_index'] is None and gate['native_proof_accepted'] is False and search['proof'] is None and search['placements']==[] and all(gate[key] is None for key in ('host_check','region','native_record')),'UNKNOWN no proof view or Host/region/Native substitute');continue
        view=d['proofs'][proof_position]
        if item is not None:need(item['admitted_proof'] is True and item['proof_view_index']==proof_position,'exact proof index')
        proof_position+=1;spec=case['spec'];model=case['model']
        for key,value in [('stage_id',identity),('id',spec['id']),('title',spec['title']),('method',method),('source',admission['result']),('spec',spec),('target',spec['target']),('proof',search['proof']),('proof_check',gate),('marking_evidence',case.get('marking'))]:need(same(view[key],value),'full proof field '+key)
        need(view['admitted_proof'] is True and gate['host_check']['accepted'] is True and gate['region']['complete'] is True and gate['native_proof_accepted'] is True,'Host/fullfinitewordregion/freshNative gates')
        q=gate['native_record'];need(q['result']['status']=='accepted' and q['request']['blocks']==[] and same(q['request']['proof'],search['proof']) and same(q['request']['target'],spec['target']) and same(q['request']['theory'],spec['theory']) and sum(same(q,x) for x in packet['native_queries'])==1,'unique owned exact current final proof request')
        lookup={tuple(t['key']):t for t in model['placements']};tiles=[lookup[tuple(k)] for k in search['placements']]
        need(same(view['tiles'],tiles) and len(tiles)==2*len(search['proof']) and len(search['proof'])==spec['length'],'allfullrowpaired basecards exact')
        need(len({tuple(x['key']) for x in tiles})==len(tiles),'selected card uniqueness')
        words={}
        for tile in tiles:
            ri,di=tile['command_reference'];need(same(model['domains'][ri][di],search['proof'][ri]),'cardtoactualprimitive command')
            for point,value in tile['marks']:
                if point[1]==100:
                    need(type(value) is int and 0<=value<len(model['word_dictionary']),'strict wholeword ID zeroallowed')
                    raw=model['word_dictionary'][value];words[str(value)]=dict(hex=raw,literal=json.loads(bytes.fromhex(raw).decode(),object_pairs_hook=unique))
        need(view['word_terminator']==model['word_terminator']==256 and same(view['words'],words),'entire selected word payloads and256terminator')
        proof_joins.append(dict(stage_id=identity,problem_id=spec['id'],method=method,proof_rows=len(view['proof']),base_cards=len(view['tiles']),selected_word_ids=sorted(int(x) for x in words),packet_source=admission['result']))
need(proof_position==200 and training_position==32 and evaluation_position==192 and inventory_position==2 and policy_position==8,'no extra or missing output rows')
need(len(trace_joins)==208 and len(training_unknown)==2 and [(r['descriptor']['global_ordinal'],r['descriptor']['engine']) for r in training_unknown]==[(2,'symbolic'),(25,'point')],'earlier qualified symbolicUNKNOWN retained')
need(len(family_ids)==5 and len(structure_ids)==4,'literal perexport IDunion not recomputed admission')
need(sum(x['proof_rows'] for x in proof_joins)==2264 and sum(x['base_cards'] for x in proof_joins)==4528,'fullrow/cardcounts')
expected_summary=dict(planned_jobs=34,job_states=dict(PENDING=0,AWAITING_REVIEW=0,QUALIFIED=32,FAILED=2,UNAVAILABLE_REQUIRED_STAGE=0),training_episode_slots=32,training_records_returned=32,evaluation_slots=192,evaluation_records_returned=176,evaluation_proofs_admitted=168,evaluation_search_unknown=8,admitted_proof_occurrences=200,admitted_policy_bundles=8,unavailable_is_not_UNKNOWN=True)
need(same(d['summary'],expected_summary) and d['decided_unique_observer_sample_seconds']==seconds==pop['decided_unique_observer_sample_seconds'],'all counts and oncefolded directcost')
need(d['input_pins']==sorted(expected_inputs.values(),key=lambda q:q['path']) and len(d['input_pins'])==246,'all and only 246 current flat projector input pins')
for q in d['input_pins']:need(pin(q['path'])==q,'all 246 output input pins remain current')
for key in ('scientific_calls','scientific_imports','partial_files_parsed'):need(type(d[key]) is int and d[key]==0,'no replay/int0scope')
need('not standalone solver cost' in d['cost_scope'] and 'not blind or proof-DAG-disjoint' in d['scope'] and 'Domain results never feed the main learner' in d['scope'],'explicit cost/holdout/domain qualifications')
for q in tuple(checked.values()):need(pin(q['path'])==q,'final raw stability')

need(sum(x['stage_id'].startswith('eval-') for x in proof_joins)==168 and sum(x['proof_rows'] for x in proof_joins if x['stage_id'].startswith('eval-'))==1928,'168 current evaluation proofs and1928primitive rows')
need(Counter(x['state'] for x in d['evaluation'])==dict(QUALIFIED=176,FAILED=16),'176 returned,16whole-job unavailable,zero pending original evaluation slots')
need(seconds==1437.492677413,'all34 decided original-order observer sample fold')
need(set(d)=={'as_of','closed','cost_scope','decided_unique_observer_sample_seconds','documents','evaluation','input_pins','inventory','jobs','open_gaps','partial_files_parsed','policies','population_source','proofs','protocol_source','rendering','report_version','request_source','schema','scientific_calls','scientific_imports','scope','summary','training'},'exact full reader data fieldset')
need(d['open_gaps']==['physical universal Wang encoding','whole-plane coverage','induction-based Peano arithmetic','full Hilbert geometry','Turtle/Penrose generality','learned utility/external prover comparison'],'broader unsupported claims remain explicit gaps')
for view in d['proofs']:
    attribution=('Conventional symbolic S0 donor discovery; checked through the finite word-point region, Host and fresh Native. No point-search or RL discovery attribution.' if view['stage_id'].startswith('acquire-') else 'Current admitted '+view['method']+' record. Discovery method and selector mode are explicit; this individual certificate is not a comparative utility claim.')
    need(view['attribution']==attribution and view['scope']=='Exact saved primitive rows and base problem-defining command/guard cards. Translation-only aligned complete-word adaptation. Saved auxiliary certificate evidence is separate; no learned mark is invented on a base card.','truthful exact proof attribution and base/auxiliary distinction')
for item in d['training']+[x for x in d['evaluation'] if x['returned']]:
    reference=item['trace_reference']
    need(reference['canonical_encoding']=='UTF-8 json.dumps(sort_keys=True,separators=(comma,colon),ensure_ascii=False,allow_nan=False)' and reference['scope']=='Exact literal references to complete current saved arrays in the raw evidence ZIP. Missing instrumentation is null, not zero. Hashes/counts do not reconstruct decisions, full pools, preferred placements or completed clusters.','compact evidence scope remains literal rather than reconstructed')
for value in tuple(checked.values()):need(pin(value['path'])==value,'final all-input raw stability')
unknown_eval=[item for item in d['evaluation'] if item['returned'] and not item['admitted_proof']]
need(len(unknown_eval)==8 and all(item['case_id']=='eval-equality-02' and item['method'] in ('P0','PF','PU','PR') and item['search_status']=='unknown_search_budget' and item['proof_status']=='NO_PROOF_CANDIDATE' and item['proof_view_index'] is None and item['native_proof_observed'] is False for item in unknown_eval),'exact eight returned localpointUNKNOWNs,no proof card or gate substitution')
projection_pin=pin(R/'conditional-main-reader-projection-actual-v6.json');projection=load(projection_pin)
need((projection_pin['bytes'],projection_pin['sha256'])==(2358,'e6e8e1b621c799c2e18f1b1d7d644914512a0fce2c24fa2db30abded4a99abb5') and projection['artifacts']==[data_pin,html_pin] and projection['request']==request_pin and projection['population']==request['population'] and projection['prospective_review']==request_review_pin and projection['projector']==sr['Source'] and projection['invocations']==1 and projection['terminal_exit_code']==0,'exact Root-labeled one passive projection receipt,not independent process measurement')
prior_N5_data_review_pin=pin(C/'typed-open-first-evaluations-reader-data-review-v5.json');prior_N5_data_review=load(prior_N5_data_review_pin);passed(prior_N5_data_review)
prior_N5_archive_review_pin=pin(C/'typed-numbered-main-actual-archive-review-v5.json');prior_N5_archive_review=load(prior_N5_archive_review_pin);passed(prior_N5_archive_review)
for q in (prior_N5_data_review['reader_data'],prior_N5_data_review['reader_html'],prior_N5_archive_review['archive'],prior_N5_archive_review['manifest']):need(pin(q['path'])==q,'all four N5 report/evidence outputs preserved unchanged')
for value in tuple(checked.values()):need(pin(value['path'])==value,'final current inputs/output/priorartifact stability')
checks=[
 ('exact-N6-data-HTML-and-current-report-authority','Exact31,911,254-byte data and20,570-byte HTML bind currentprotocol/finalstate/request/Cpopulation/requestcomposition andRootone-invocationreceipt. HTML equals exactreviewedtemplate4 withonlyfour N6filename replacements,not aJS/render or scientificSource change. AllfourN5report/evidenceoutputs remainunchanged.'),
 ('all34-32-192-closed-original-population-and-whole-gates','Every34job/32trainingdescriptor/192evalslot matches originalrecipe/currentRootstate.32qualified,twofailed,zeropending.176evalrecordsreturned=168acceptedproofs+8boundedlocalpointUNKNOWN;16wholefailure slots unavailable. All32positiveRoot/C/currentcompletepacketgates remainexact. Closedmeansoriginalplannedjobsdecided,notbroadergoal orfullscientificsuccess.'),
 ('all200proofviews2264rows4528basecards-and-complete-word-payloads','Everyacceptedproofview retains exactcurrent spec/target/primitive rows/Host/fullfinitewordregion/uniqueownedacceptedNativeblocks-empty/theory/proof request and selectedcommand-guardcatalog. All2,264rows/4,528basecards,selectedwholewordhex/literalpayloads,ID0/terminator256 andseparateauxmarkingevidence matchcurrentrawpackets.168evaluationproofviewsaccountfor1,928rows;no localUNKNOWN orfailedprefix creates aview.'),
 ('all208returned-record-compact-diagnostic-joins','All32training and176evalsummaries retain exactmetrics/modes/seeds/terminalRootsamples/rollback/overlappingclocks. Everytrace/selectorarray hasliteralpresence/null,count,canonicalSHA andpacket/search/arraylocator. Missinginstrumentation staysnull;Cdoesnotreconstructactions,rawpools,preferences,completedclusters orlegality.'),
 ('eight-localUNKNOWNs-and-two-whole-negative-null-boundaries','Exactlyeight equality02pointlocalUNKNOWNrecords have proofviewindexnull/nativeproofobservedfalse and noHost/region/Nativeproof orselectedplacements. Bothquantified02wholefailures preservefullRootnegative/failure/C/rawdiagnostics with scientific_resultnull,13-filecensuses andqualifiedpeaksnull. All16wholefailedslots have returnedfalse,no proof/status/index/compacttrace artifact. NeitherSUrawNativeprefix nor RSS is promoted.'),
 ('two-inventories-and-eight-policy-history-bundles','Bothcurrentperdonor full libraries/certificates/pairingcarriers remainexact,with3units/4certificates each,literalunion5pairedIDs/4principalIDs andno newmerge. All8admittedpolicybundles preserveexactheads/historycounts/checks/exportdigests through16episodesperengine;trainingUNKNOWNglobal2/global25remain. Evaluationdoesnotupdatepolicyorcreateaseal.'),
 ('all246flatinputs-direct-observer-fold-and-limited-scope','All246exactflatprojectorinputs remaincurrent/unique/complete. All34observer.elapsed_seconds samples,includingbothfailuresonce,fold inoriginalorder to1437.492677413seconds;laterfinalgates/nestedsetup/search/selector/arm/helper/custodyclocks remainoverlappingandnotadded. Publicauthoredinputstructureholdouts arenotblind orproofDAGdisjoint. No learning/GCTS/SOTAutility/newtheorem/fullbroadergoal claim;RootbrowserQA andexactarchive/install/livegatesremainseparate.')]
receipt=dict(schema='D21-C-main-reader-data-review-v3',report_version=6,review_passed=True,protocol=request['protocol'],reader_data=data_pin,reader_html=html_pin,reader_Source_review=source_review_pin,population_review=population_review_pin,request_composition_review=request_review_pin,request=request_pin,population=request['population'],reader_template=template_pin,Root_projection_receipt=projection_pin,summary=d['summary'],eligible_proof_rows=2264,eligible_base_cards=4528,current_inventory_literal_census=dict(per_export_units=[3,3],per_export_certificates=[4,4],union_paired_unit_ids=5,union_principal_structural_ids=4,merged_inventory_inferred=False),proof_literal_joins=proof_joins,current_job_joins=job_joins,compact_diagnostic_array_joins=trace_joins,retained_training_UNKNOWN=training_unknown,returned_evaluation_local_UNKNOWN=unknown_eval,evaluation_dispositions=dict(returned=176,accepted_proof_occurrences=168,whole_failure_unavailable=16,pending=0,local_search_UNKNOWN=8),decided_unique_observer_sample_seconds=seconds,input_pins=d['input_pins'],preserved_N5_data_review=prior_N5_data_review_pin,preserved_N5_archive_review=prior_N5_archive_review_pin,checks=[dict(id=k,passed=True,finding=v) for k,v in checks],failures=[],scientific_calls=0,scientific_imports=0,subject_replays=0,projector_invocations=0,helper_invocations=0,partial_files_parsed=0,Root_admission_issued=False,scope='Independent literalcurrent N6generateddata/HTML reviewonly. Originalstudyclosure isallplannedjobsdecided,notbroader/fullscientificsuccess orcomparativebenefit. Prioractualproof/control/Source reviews reusedonlybycurrentrawidentity. NoRootbrowser/archive/install/publicationornewactualauthority.',review_program=pin(Path(__file__).resolve()),preserved_prior_review_program=pin(C/'passive_first_evaluations_reader_data_review_v5_1.py'),tools_idle_after_freeze=True)
output=C/'typed-closed-original-reader-data-review-v6.json'
with output.open('xb') as f:f.write(json.dumps(receipt,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False).encode()+b'\n')
print(json.dumps(pin(output)))
print(json.dumps(dict(checks=len(checks),failures=0,summary=d['summary'],proof_rows=2264,base_cards=4528,returned_record_references=len(trace_joins),flat_inputs=len(d['input_pins']),observer_sample_seconds=seconds,tools_idle=True)))
