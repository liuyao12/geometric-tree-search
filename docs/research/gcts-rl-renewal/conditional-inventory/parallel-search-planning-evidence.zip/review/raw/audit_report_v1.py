"""Own stdlib publication-data audit only; no project or scientific execution."""
import collections
import hashlib
import html
from html.parser import HTMLParser
import json
import pathlib
import re
from urllib.parse import urlsplit, unquote
import zipfile

OUT = pathlib.Path(__file__).parent
PUB = pathlib.Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/parallel-search-planning-progress-20261018/publication-source-v1')
OLD = pathlib.Path('/private/tmp/gcts-split-controls-publish-20261015/docs/research/gcts-rl-renewal/conditional-inventory')
AUTHOR = pathlib.Path('/private/tmp/gcts-first-order-next-benchmark-source-20261018')
checks = []

def check(ok, label):
    checks.append({'check': label, 'passed': bool(ok)})
    if not ok:
        raise ValueError(label)

def raw(path):
    path = pathlib.Path(path)
    if path.stat().st_flags & 0x40000000:
        raise ValueError('No dataless reads: ' + str(path))
    return path.read_bytes()

def pin(path):
    b = raw(path)
    return {'path': str(path), 'sha256': hashlib.sha256(b).hexdigest(), 'bytes': len(b)}

def load(path):
    def pairs(values):
        d = {}
        for k, v in values:
            if k in d:
                raise ValueError('duplicate JSON key')
            d[k] = v
        return d
    return json.loads(raw(path), object_pairs_hook=pairs)

def verify(d):
    check(pin(d['path']) == {k: d[k] for k in ('path', 'sha256', 'bytes')}, 'full raw descriptor: ' + d['path'])

def canonical(x):
    return json.dumps(x, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode()

report = raw(PUB / 'parallel-search-planning.html').decode()
manifest = load(PUB / 'parallel-search-planning-evidence-manifest.json')
summary = load(PUB / 'parallel-search-planning-summary.json')
root_checks = load(PUB.parent / 'ROOT-static-input-and-report-checks-v1.json')
check(len(root_checks['checks']) == 466 and not root_checks['findings'] and all(x['ok'] for x in root_checks['checks']), 'Root distinct static input/report record: 466 checks, zero findings')
verify(summary['report'])
check(manifest['report_review_pending'] is True, 'current manifest truthfully retains pending report review')
check(summary['new_scientific_runs'] == summary['new_proofs'] == 0 and summary['new_RL_training'] is False and summary['goal_complete'] is False and summary['actual_execution_authorized'] is False, 'current milestone has no new runs/proof/RL/authorization/complete-goal claim')
for d in manifest['objects']:
    verify(d)
check(len(manifest['objects']) == 20, 'twenty pre-manifest published object bindings')
with zipfile.ZipFile(PUB / 'parallel-search-planning-evidence.zip') as z:
    names = z.namelist()
    expected = [d['archive_name'] for d in manifest['archive_objects']]
    check(len(names) == len(set(names)) == 57 and set(names) == set(expected), 'publication-only ZIP has exact 57 unique declared members')
    for d in manifest['archive_objects']:
        verify(d)
        check(z.read(d['archive_name']) == raw(d['path']), 'ZIP full raw member equality: ' + d['archive_name'])
    check(any(n.endswith('/final-input-envelope-audit-v1.json') for n in names), 'late own-input envelope audit is already included losslessly')

# Parse only the report's ordinary LaTeX serialization subset back to syntax.
# This is a display-data comparison, never a renderer, formula evaluator or prover.
class LatexInput:
    def __init__(self, text, theory):
        text = re.sub(r'\\(?:left|right)(?=[()])', '', text).replace(r'\,', '')
        self.tokens = []
        while text.strip():
            text = text.lstrip()
            m = re.match(r'\\mathrm\{([^}]+)\}', text)
            if m:
                self.tokens.append(('name', m.group(1))); text = text[m.end():]; continue
            found = False
            for command in (r'\forall', r'\neg', r'\rightarrow'):
                if text.startswith(command):
                    self.tokens.append(command); text = text[len(command):]; found = True; break
            if found:
                continue
            if text[0] in '(),=':
                self.tokens.append(text[0]); text = text[1:]; continue
            raise ValueError('Unsupported display token: ' + text[:60])
        self.i = 0
        self.theory = theory

    def peek(self):
        return self.tokens[self.i] if self.i < len(self.tokens) else None

    def take(self, wanted=None):
        got = self.peek()
        if got is None or (wanted is not None and got != wanted):
            raise ValueError(('display token mismatch', wanted, got))
        self.i += 1
        return got

    def name(self):
        n = self.take()
        if not isinstance(n, tuple) or n[0] != 'name':
            raise ValueError('display name expected')
        return n[1]

    def arguments(self, arity, env):
        if not arity:
            return []
        self.take('(')
        args = [self.term(env)]
        for _ in range(arity - 1):
            self.take(','); args.append(self.term(env))
        self.take(')')
        return args

    def term(self, env):
        n = self.name()
        if n in env:
            return ['var', n]
        if n not in self.theory['functions']:
            raise ValueError('undeclared display term')
        return ['fun', n, self.arguments(self.theory['functions'][n], env)]

    def atom(self, env):
        t = self.peek()
        if t == r'\forall':
            self.take(); n = self.name(); return ['all', n, self.formula(env + [n])]
        if t == r'\neg':
            self.take(); return ['not', self.atom(env)]
        if t == '(':
            self.take(); a = self.formula(env); self.take(')'); return a
        if isinstance(t, tuple) and t[1] in self.theory['predicates']:
            n = self.name(); return ['pred', n, self.arguments(self.theory['predicates'][n], env)]
        left = self.term(env); self.take('='); return ['eq', left, self.term(env)]

    def formula(self, env):
        a = self.atom(env)
        if self.peek() == r'\rightarrow':
            self.take(); return ['imp', a, self.formula(env)]
        return a

    def result(self):
        f = self.formula([])
        if self.peek() is not None:
            raise ValueError('unconsumed display serialization')
        return f

suite = load(PUB / 'parallel-search-planning-benchmark-suite.json')
benchmark = load(PUB / 'parallel-search-planning-benchmark-manifest.json')
source_suite = load(AUTHOR / 'suite-input-index-v1.json')
check(suite['case_count'] == len(suite['cases']) == 10 and suite['structural_groups'] == 8, 'ten inputs/eight groups')
check(benchmark['design'] == load(AUTHOR / 'design-holdout-controls-v1.json') and benchmark['coverage'] == load(AUTHOR / 'coverage-provenance-v1.json'), 'complete authored design/coverage copied without changed claims')
check(benchmark['primary_sources'] == load(AUTHOR / 'primary-sources-v1.json'), 'complete primary-source provenance copied')
panels = report.split('<details class="suite-case"')[1:]
check(len(panels) == 10, 'ten human formula/input panels')
formula_count = 0
groups = collections.defaultdict(list)
for entry, panel, source_meta in zip(suite['cases'], panels, source_suite['receivers']):
    spec = entry['spec']; meta = entry['metadata']; cid = spec['id']
    original = load(AUTHOR / (cid + '.json'))
    check(spec == original and meta == source_meta, 'full spec and metadata equal frozen input: ' + cid)
    check(raw(PUB / ('parallel-search-planning-' + cid + '.json')) == raw(AUTHOR / (cid + '.json')), 'published raw input bytes equal original: ' + cid)
    check(cid in panel.split('</summary>')[0] and 'data-group="' + meta['group'] + '"' in panel.split('</summary>')[0], 'display case ID and group: ' + cid)
    embedded = re.search(r'<pre>(.*?)</pre>', panel, re.S).group(1)
    check(json.loads(html.unescape(embedded)) == original, 'full displayed ordinary JSON preimage: ' + cid)
    display = re.search(r'<div class="formula">(.*?)</div>', panel, re.S).group(1)
    prefix = r'\[\begin{aligned}'; suffix = r'\end{aligned}\]'
    check(display.startswith(prefix) and display.endswith(suffix), 'display math and aligned delimiters: ' + cid)
    rows = display[len(prefix):-len(suffix)].split(r'\\')
    expected = [('Axiom ' + k, v) for k, v in sorted(original['theory']['axioms'].items())] + [('Target', original['target'])]
    check(len(rows) == len(expected), 'all axioms and target displayed once: ' + cid)
    for row, (label, ast) in zip(rows, expected):
        m = re.fullmatch(r'\\text\{([^}]+)\}&:\\quad (.*)', row)
        check(m is not None and m.group(1) == label and LatexInput(m.group(2), original['theory']).result() == ast, 'literal displayed formula AST and label: ' + cid + '/' + label)
        formula_count += 1
    check(meta['expected_runtime_status'] is meta['expected_proof_rows'] is meta['expected_basis_or_inventory_counts'] is None, 'no expected outcome/census/proof-length filter: ' + cid)
    check(original['length'] == 12 and original['instantiation_rounds'] == 2 and original['theory']['schemas'] == [], 'unchanged authored finite input profile and no new schema: ' + cid)
    groups[meta['group']].append(cid)
check(dict(groups) == benchmark['case_groups'] and formula_count == 30, 'all eight grouping lists and thirty formula rows exact')
for case in suite['cases']:
    m = case['metadata']
    if m['renaming_control_of']:
        parent = next(x for x in suite['cases'] if x['spec']['id'] == m['renaming_control_of'])
        check(m['shape'] == parent['metadata']['shape'] and not m['structural_primary'], 'renaming controls remain correlated parent group: ' + m['case_id'])

extract = load(PUB / 'parallel-search-planning-search-observations.json')
diag = load(PUB / 'parallel-search-planning-diagnosis.json')
obs = load(PUB / 'parallel-search-planning-family-observations.json')
family = load(PUB / 'parallel-search-planning-family-design.json')
support = load(PUB / 'parallel-search-planning-support-design.json')
admission = load(diag['ROOT_original_admission']['path'])
verify(diag['ROOT_original_admission'])
for mode, a in extract['actuals'].items():
    for field, v in a.items():
        if isinstance(v, dict) and 'value' in v:
            b = canonical(v['value'])
            check(hashlib.sha256(b).hexdigest() == v['sha256'] and len(b) == v['bytes'], 'complete saved preimage canonical pin: ' + mode + '/' + field)
    original = next(z for z in admission['actuals'] if z['invocation_id'] == 'structural-quantified-c3-' + mode + '-ROOT-20261018-v1')
    check(a['ROOT_resource_admitted'] == original['ROOT_resource_admitted'] and a['proof'] is None and a['result_status'] == 'unknown_search_budget' and a['root_restored'] is True, 'historical resource/UNKNOWN/no-proof/root scope: ' + mode)
    c = next(z for z in family['old_c3_controls'] if z['mode'] == mode)
    check(c['metrics'] == a['search_metrics']['value'] and c['search_seconds'] == a['search_seconds'] and c['result'] == a['raw_result'], 'distinct family note agrees with retained extract counters/times/raw result: ' + mode)
    check(c['ROOT_resource_admitted'] == a['ROOT_resource_admitted'] and c['ROOT_mathematical_data_admitted'] is False, 'distinct family note preserves admission scope: ' + mode)
    check(c['observed_conservative_peak_MiB'] == original['observed_conservative_peak_MiB'], 'retained whole resource peak: ' + mode)
check(extract['actuals']['base']['search_metrics']['value']['attempts'] == 2030 and extract['actuals']['fixed']['search_metrics']['value']['attempts'] == 2739, 'displayed historical point placement counts')
s = extract['actuals']['symbolic']
check(s['search_metrics']['value']['prefix_extensions'] == sum(s['event_row_histogram'].values()) == 5000 and s['event_row_histogram']['10'] == 4677 and s['event_row_histogram'].get('11', 0) == 0, 'symbolic 4677/5000 late-row concentration is not exhaustion')
check(round(extract['actuals']['base']['search_seconds'], 3) == 30.174 and round(extract['actuals']['fixed']['search_seconds'], 3) == 30.027 and round(s['search_seconds'], 3) == 6.709, 'all human-rounded search-stage seconds')
licence = s['target_licence_event']['value']['command']
check(licence['rule'] == 'instantiate' and licence['formula'] == ['imp', licence['universal'], ['pred', 'R', [['var', 'x']]]], 'saved event is a zero-read UI implication licence, not its consequent fact')
distances = {canonical(x['formula']): x['distance'] for x in s['backward_distances']['value']}
curried = obs['declaration']['theory']['axioms']['universal_curried_implication']
check(distances[canonical(licence['formula'])] == 2 and distances[canonical(curried)] == 4, 'historical target licence/curried distances 2 versus 4')
check(obs['metrics'] == extract['actuals']['fixed']['search_metrics']['value'] and obs['metrics']['hints_started'] == 350 and obs['metrics']['hint_completed'] == 120 and obs['hint_counts']['kinds']['lemma'] == 194, '350 hints/120 completed-phase visits/194 lemma hints, different scopes')
interfaces = extract['actuals']['fixed']['registered_interfaces']['value']
definitions = extract['actuals']['fixed']['native_definitions']['value']
check(len(interfaces) == len(obs['inventory']['interfaces']) == 8 and interfaces == [i['name'] for i in obs['inventory']['interfaces']] and all(i['level'] == 1 for i in obs['inventory']['interfaces']), 'all eight retained admitted interface names and reported levels agree')
check([d['name'] for d in definitions] == interfaces and all(r['rule'] != 'block' for d in definitions for r in d['proof']), 'all eight saved native ground definitions have no dependent block calls')
check('node-visit phase metric, not unique proved lemmas' in obs['count_scope'] and obs['flags']['essential_hint_use_claimed'] is False, 'completed-phase count explicitly not theorem/family-use evidence')
check(support['implementation_proposed_only'] is True and family['proposed_design']['status'] == 'PROPOSED_NOT_IMPLEMENTED' and 'ordering only' in summary['selected_next_intervention'] and 'multirow closure separately deferred' in summary['selected_next_intervention'], 'lighter support-ordering selected first; separate multirow proposal unimplemented/deferred')
for phrase in ('not recorded Wang tiles', 'The licence is a valid formula; its antecedent is not thereby an available fact', 'not counts of distinct proved lemmas', 'no second-level theorem inventory was demonstrated', 'not imported official TPTP problems', 'rather than a blinded benchmark', 'Difficult or UNKNOWN cases will stay', 'no new RL training', 'The research goal remains active'):
    check(phrase in report, 'human scope wording: ' + phrase)
check('hint_completed' not in report or 'completed-phase' in report, 'human display does not relabel hint completion as proof')

class LinkParser(HTMLParser):
    def __init__(self):
        super().__init__(); self.links = []; self.ids = []
    def handle_starttag(self, tag, attrs):
        d = dict(attrs)
        if 'id' in d: self.ids.append(d['id'])
        for k in ('href', 'src'):
            if k in d: self.links.append(d[k])

parser = LinkParser(); parser.feed(report)
check(len(parser.ids) == len(set(parser.ids)), 'report IDs unique')
pending = []
historical_targets = []
local_link_count = 0
for href in parser.links:
    u = urlsplit(href)
    if u.scheme or u.netloc:
        continue
    local_link_count += 1
    if not u.path:
        check(u.fragment in parser.ids, 'same-report local anchor: ' + href); continue
    q = PUB / unquote(u.path)
    if not q.exists(): q = OLD / unquote(u.path)
    if not q.exists():
        check(u.path == 'parallel-search-planning-report-review.json', 'only declared future report-review asset absent: ' + href)
        pending.append(href); continue
    check(q.is_file(), 'local/historical file exists: ' + href)
    if q.parent == OLD:
        historical_targets.append({'href': href, 'path': str(q), 'bytes': q.stat().st_size})
    if u.fragment and q.suffix == '.html':
        other = LinkParser(); other.feed(raw(q).decode())
        if u.path == 'reader.html' and u.fragment == 'parallel-search-planning' and u.fragment not in other.ids:
            pending.append(href)
        else:
            check(u.fragment in other.ids, 'existing local/historical anchor: ' + href)
check(set(pending) == {'parallel-search-planning-report-review.json', 'reader.html#parallel-search-planning'}, 'exact two declared final publication closure conditions')
check(report.count(r'\[') == report.count(r'\]') and report.count(r'\(') == report.count(r'\)'), 'raw display/inline LaTeX delimiters balanced')

assets = [pin(q) for q in sorted(PUB.iterdir()) if q.is_file()]
audit = {
    'schema': 'parallel-search-planning-bounded-human-and-input-audit-v1',
    'reviewer_identity': '/root/receiver_driver_review', 'report_author_identity': '/root',
    'source_only': True, 'scientific_calls': 0, 'scientific_replays': 0,
    'project_imports': 0, 'renderer_evaluations': 0,
    'scope': 'Ordinary JSON/hash/HTML-display AST and publication ZIP custody only. No scientific implementation review, activation, trial, logic evaluation, Native codec, or mathematical replay.',
    'checks': checks, 'check_count': len(checks), 'findings': [],
    'publication_assets': assets, 'formula_rows': formula_count,
    'archive_members': 57, 'local_link_count': local_link_count,
    'historical_link_targets': historical_targets,
    'pending_publication_conditions': pending,
    'authorship_disclosure': 'Reviewer authored the ten input-only specs and an older separate qualification harness, and reviewed prior Sources/data. Report is Root-authored. Display/copy review is distinct from report author; this is NOT independent certification of own corpus selection/authorship or prior harness implementation.',
    'own_audit_preflight_notes': 'Two stdlib audit assumptions were corrected before receipt creation: delimiter stripping must not remove the prefix of the LaTeX arrow command, and the retained registered_interfaces field contains names rather than interface objects. No report/input/result changed and no scientific evaluation occurred.',
}
audit_path = OUT / 'audit-v1.json'
if audit_path.exists(): raise ValueError('do not overwrite frozen audit')
audit_path.write_text(json.dumps(audit, indent=2, sort_keys=True, ensure_ascii=False) + '\n')
review = {
    'schema': 'parallel-search-planning-human-report-and-static-input-review-v1',
    'reviewer_identity': '/root/receiver_driver_review', 'author_identity': '/root',
    'distinct_report_reviewer': True, 'independent_corpus_authorship_certificate': False,
    'authorship_disclosure': audit['authorship_disclosure'],
    'source_only': True, 'scientific_calls': 0, 'scientific_replays': 0,
    'scientific_acceptance': False, 'actual_execution_authorized': False,
    'implementation_source_review': False, 'report_review_passed': True,
    'static_input_copy_and_display_review_passed': True,
    'publication_ready': False, 'conditional_report_pass': True,
    'report': pin(PUB / 'parallel-search-planning.html'),
    'evidence_manifest': pin(PUB / 'parallel-search-planning-evidence-manifest.json'),
    'summary': pin(PUB / 'parallel-search-planning-summary.json'),
    'audit': pin(audit_path), 'audit_Source': pin(pathlib.Path(__file__)),
    'publication_assets': assets,
    'bounded_evidence': {'checks': len(checks), 'mismatches': 0, 'published_assets': len(assets), 'archive_members': 57, 'case_inputs': 10, 'structural_groups': 8, 'renaming_controls': 2, 'formula_rows': formula_count},
    'findings': [],
    'required_final_metadata_closure': [
        'Publish this exact typed receipt at the declared report-review asset and set report_review_pending false using a new manifest; do not overwrite frozen V1 evidence.',
        'Add and verify reader.html#parallel-search-planning and the final publication bindings. Root owns deployed-byte and visual verification.'
    ],
    'limitations': [
        'Exact current HTML/report-data scope only. No search/native/proof result produced or independently rechecked by executing a mathematical checker.',
        'Historical c3 interpretation compared retained extracts, original Root admission and distinct authors notes; not a new exhaustive audit or counterfactual intervention.',
        'Thirty displayed formulas parsed syntactically back to the full original ASTs. This validates display fidelity, not entailment or finite catalog feasibility.',
        'CASC/TPTP/SZS links are benchmark-practice sources; corpus is authored synthetic, unexecuted, visible and not an official/blind/ranked benchmark.',
        'Publication ZIP inspected only as report transport; no Native codec or scientific archive replay. No live rendering/browser check performed.'
    ],
    'status': 'CONDITIONAL_HUMAN_REPORT_AND_STATIC_DISPLAY_PASS_NO_SCIENCE',
}
review_path = OUT / 'typed-report-review-v1.json'
if review_path.exists(): raise ValueError('do not overwrite frozen review')
review_path.write_text(json.dumps(review, indent=2, sort_keys=True, ensure_ascii=False) + '\n')
handoff = {'schema': 'parallel-search-planning-report-peer-handoff-v1', 'review': pin(review_path), 'audit': pin(audit_path), 'source_only': True, 'scientific_calls': 0, 'scientific_acceptance': False, 'actual_execution_authorized': False, 'report_review_passed': True, 'publication_ready': False, 'pending': pending}
hpath = OUT / 'handoff-v1.json'
if hpath.exists(): raise ValueError('do not overwrite frozen handoff')
hpath.write_text(json.dumps(handoff, indent=2, sort_keys=True) + '\n')
print(json.dumps({'handoff': pin(hpath), 'review': pin(review_path), 'audit': pin(audit_path), 'checks': len(checks), 'findings': 0}, sort_keys=True))
