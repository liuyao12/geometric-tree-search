"""Retained JSON/Source metadata only; imports no research implementation."""
from pathlib import Path
import ast
import gc
import hashlib
import json

D = Path('/private/tmp/gcts-curried-search-diagnosis-20261018')
R = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True).encode('ascii')

def pin(path):
    path = Path(path).resolve()
    h = hashlib.sha256()
    size = 0
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(65536), b''):
            h.update(chunk)
            size += len(chunk)
    return {'path': str(path), 'sha256': h.hexdigest(), 'bytes': size}

def preimage(value):
    raw = canonical(value)
    return {'canonicalization': 'stdlib-json-sort_keys-compact-ensure_ascii-v1',
            'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw), 'value': value}

def write(name, value):
    path = D / name
    path.write_text(json.dumps(value, sort_keys=True, indent=2, ensure_ascii=True) + '\n')
    return pin(path)

scope = dict(source_and_retained_data_only=True, scientific_calls=0, scientific_acceptance=False,
             target_imports=0, scientific_replays=0, actual_execution_authorized=False,
             implementation_proposed_only=True, proof_route_supplied=False)
ancestry = {
    'author_identity': '/root/conventional_control_review',
    'parent_identity': '/root',
    'authored_prior_components': [
        'quantified_symbolic_control_v1', 'structural quantified benchmark cases',
        'quantified receiver driver', 'bounded native broker and earlier outer runners',
        'compact-model cold once runner v1/v2', 'earlier finite checkers/CASEs and reports'],
    'independence_limit': 'This is a Source-backed diagnosis by an original control author, not an independent Source certificate of that control. Root alone executed and admitted the retained actuals.'}
closure_path = R / '.gcts-active/compact-model-cold-integration-progress-20261018/runtime-closure-v1.json'
closure = json.loads(closure_path.read_bytes())
source_roles = ['quantified_symbolic_control_v1', 'semantic_inventory_search',
                'semantic_inventory_guidance', 'semantic_lemma_inventory',
                'native_inventory_policy', 'native_inference_inventory',
                'quantified_family_points_v2', 'quantified_receptors_v1', 'turtle']
source_map = {}
source_regions = {}
for role in source_roles:
    descriptor = closure['project_sources'][role]
    actual = pin(descriptor['path'])
    assert actual == descriptor, (role, actual, descriptor)
    source_map[role] = actual
    raw = Path(descriptor['path']).read_bytes()
    tree = ast.parse(raw)
    source_regions[role] = {node.name: {'line': node.lineno, 'end_line': node.end_lineno}
                            for node in tree.body if isinstance(node, (ast.FunctionDef, ast.ClassDef))}

observation_path = D / 'retained-search-observations-v1.json'
observations = json.loads(observation_path.read_bytes())
evidence = {}
for observed in observations['actuals']:
    mode = observed['mode']
    descriptor = observed['raw_result']
    assert pin(descriptor['path']) == descriptor
    raw = json.loads(Path(descriptor['path']).read_bytes())
    search = raw['outputs']['search']
    compile_out = raw['outputs']['compile']
    register = raw['outputs']['register']
    model = raw['outputs']['model']
    entries = {
        'search_metrics': preimage(search['metrics']),
        'search_limits': preimage(search['limits']),
        'events_complete': {'sha256': hashlib.sha256(canonical(search.get('events', []))).hexdigest(),
                            'bytes': len(canonical(search.get('events', []))), 'count': len(search.get('events', []))},
        'tree_complete': {'sha256': hashlib.sha256(canonical(search.get('tree'))).hexdigest(),
                          'bytes': len(canonical(search.get('tree')))},
        'compile_catalog': preimage(compile_out['catalog']),
        'registered_interfaces': preimage(register['interfaces']),
        'native_definitions': preimage(register['native_blocks']),
        'model_placement_count': len(model['placements']),
        'raw_result': descriptor,
        'result_status': search['status'], 'search_seconds': search['seconds'],
        'ROOT_resource_admitted': observed['ROOT_resource_admitted'],
        'proof': search.get('proof'), 'root_restored': observed['root_restored']}
    if mode == 'symbolic':
        entries.update(reason=search['reason'],
                       event_row_histogram=observed['row_hist'],
                       event_action_histogram=observed['action_hist'],
                       complete_exhaustion=search['complete_exhaustion'],
                       backward_distances=preimage(search['backward_distances']),
                       target_licence_event=preimage(search['events'][3]),
                       first_seven_event_outcomes=preimage(search['events'][:7]),
                       interrupted_prefix=preimage(search['interrupted_prefix']),
                       last_event_ancestor_chain=preimage(observed['last_event_ancestor_chain']))
    else:
        entries.update(tree_summary=preimage(observed['retained_tree_summary']),
                       cutoff_placement_metadata=preimage(observed['first_chain_placement_commands']),
                       hints_complete={'sha256': hashlib.sha256(canonical(search.get('hints', []))).hexdigest(),
                                       'bytes': len(canonical(search.get('hints', []))), 'count': len(search.get('hints', []))})
        if mode == 'fixed':
            entries['first_policy_event'] = preimage(search['events'][0])
    evidence[mode] = entries
    del raw, search, compile_out, register, model
    gc.collect()

evidence_pin = write('retained-evidence-preimages-v1.json', dict(
    schema='curried-search-literal-evidence-preimages-v1', **scope,
    preimages_are_historical_observations_not_future_hints=True,
    original_observations=pin(observation_path), actuals=evidence))

diagnosis = {
    'schema': 'curried-search-source-retained-diagnosis-v1', **scope, 'ancestry': ancestry,
    'master': pin(R / 'docs/basic-tiling-algorithm.md'),
    'declaration': pin(R / '.gcts-active/structural-quantified-progress-20261018/experiment-declaration-v2.json'),
    'ROOT_original_admission': observations['admission'],
    'current_runtime_closure': pin(closure_path), 'sources': source_map,
    'Source_regions': source_regions, 'literal_evidence': evidence_pin,
    'receiver_statement_latex': r'\(\forall x\,(P(x)\Rightarrow(Q(x)\Rightarrow R(x))),\;\forall x\,P(x),\;\forall x\,Q(x)\;\vdash\;\forall x\,R(x)\)',
    'common_completed_problem': {
        'root_rows': 12, 'syntax_rounds': 2, 'basis_formulas': 13,
        'registered_exported_interfaces': 8, 'model_placements': 11440,
        'compiler_status': 'complete', 'registry_status': 'native_accepted',
        'arity': 3,
        'scope': 'All three old c3 runs reached the same completed compiled and registered finite problem. This does not imply equal search traces or method-specific work units.'},
    'findings': [
        {'id': 'SYMBOLIC_PREFIX_LIMIT',
         'observation': 'Symbolic search returned unknown_search_budget with reason prefix_extension_budget after 5000 extensions in 6.709443915984593 seconds, not the nominal 30-second limit.',
         'counts': {'extensions': 5000, 'backtracks': 4990, 'dead_prefixes': 4677,
                    'events_at_row10': 4677, 'events_at_row11': 0, 'first_seven_choices_not_backtracked': 7},
         'interpretation': 'Chronological depth-first suffix enumeration consumed the limit under an early prefix. The last-row target restriction generated no successful row-11 extension in visited prefixes. Neither this nor dead-prefix counts establish complete grammar exhaustion or target nonprovability.'},
        {'id': 'CYCLE_BLIND_ORDER',
         'Source_evidence': 'The control flattens all alternative implication and exported-interface prerequisite sets into a reverse dependency graph, then sorts novel outputs by unweighted backward BFS distance and original skeleton index.',
         'retained_evidence': 'Event 3 writes a legal zero-read UI implication licence whose universal operand is the receiver target. Its saved backward distance is 2; the curried theory axiom has distance 4. The target is not an available fact at that event.',
         'limit': 'This exhibits an ordering weakness and a concrete self-supporting relevance path. It is not an unsound guard, unavailable native rule, or causal demonstration that another order solves the case.'},
        {'id': 'POINT_WALL_LIMIT',
         'base': {'seconds': 30.173799750045873, 'placements': 2030, 'branches': 249, 'forced': 1226, 'dead': 556, 'backtracks': 1984},
         'fixed': {'seconds': 30.027331374934874, 'placements': 2739, 'branches': 419, 'forced': 1518, 'dead': 803, 'backtracks': 2689},
         'interpretation': 'Both point searches hit their wall-time condition below 5000 placements. These are placement units, not symbolic row extensions. Both are old out-of-memory-profile diagnostic observations, with no admitted proof.'},
        {'id': 'LOCAL_HINTS_NOT_DEPENDENCY_PLANS',
         'retained_evidence': 'Fixed starts 350 hints; 120 completed-phase visits and 808 invalid-phase visits are recorded. Proposal construction/scoring consumes 4.233819758053869 seconds. The first policy event prefers a smaller-marking novel axiom over the larger curried axiom; no prerequisite-support feature is present.',
         'Source_evidence': 'Join constructs one completed command/guard/input-role row at a time plus sampled clusters of at most three placements. It does not recursively acquire missing receptor premises. Existing new_fact and direct target_output features do not measure marginal target support.',
         'limit': 'Hint phase counts are visits, not distinct proof-relevant successes or unique invalid proposals. Repeated known facts in saved partial paths are legal duplicate words; they are not all necessarily removable under exact bounded-word semantics.'},
        {'id': 'CURRENT_PROOF_SEARCH_SCOPE',
         'observation': 'The point lane performs real complete-domain point search and validated cluster ordering; the conventional lane performs direct symbolic row search. Neither old c3 run found a proof. All three report unknown, and the point diagnostics failed the old full resource envelope.',
         'limit': 'No evidence here establishes a GCTS speed advantage, necessity of geometry, learned markings, reinforcement learning, new theorem, or generic transfer success.'}],
    'conformance': {
        'existing_point_route': 'Graph decision remains global dead then forced then earliest generation. Hints only reorder incident alternatives; each constituent uses current legality, graph update and reversible state copies.',
        'control_scope': 'Symbolic chronological DFS is a conventional specialized control with the same completed logical language; it is not the geometric scheduler.',
        'gaps': ['No runtime counterfactual ordering ablation has occurred.',
                 'The saved cutoff paths are partial historical branches, not complete proofs.',
                 'The current bounded Join proposal pool can omit a useful row; ordering cannot guarantee its availability.',
                 'Repeated output/ref/padding multiplicity is retained. No duplicate elimination is proposed without a separate equivalence argument.',
                 'No failed branch, memory diagnostic or native UNKNOWN is a mathematical refutation.']}}
diagnosis_pin = write('curried-search-diagnosis-v1.json', diagnosis)

design = {
    'schema': 'curried-next-search-ordering-design-v1', **scope, 'ancestry': ancestry,
    'diagnosis': diagnosis_pin,
    'proposal_id': 'ACYCLIC_RECEPTOR_SUPPORT_POTENTIAL_V1',
    'one_change': 'Replace scalar cycle-blind backward-distance relevance with a contextual positive-cost AND-receptor support potential for ordering existing validated choices. No new cluster generator, marking, primitive, lemma template or pruning rule is part of this proposal.',
    'generic_input_boundary': 'Read the declared target, full current compiled guards, all admitted exported ground interfaces and currently recursively justified rows. No c3 predicates, axiom names, source node IDs, row route, proof word or family binding may be hardcoded or imported from the historical traces.',
    'potential_definition': [
        'Build finite formula-level hyperedges from the unchanged admitted command/interface data. Every ordered premise of an MP or block remains a joint requirement. Keep interface provenance and port ordering even where scoring later ignores reference multiplicity.',
        'A legal zero-read command can supply only its literal output. In particular instantiate and equality transport supply implication licences, not their operand or consequent facts. Universal generalization requires its actual body prerequisite and existing scope policy.',
        'Seed zero cost only from actually complete recursively justified current rows. Admitted zero-premise commands have positive row cost. Compute a bounded least positive-cost support relaxation from those seeds; cyclic dependencies alone never establish a free seed.',
        'Use a declared finite row-cost combination such as one plus the sum of required support estimates. This is a heuristic: shared subderivations, references, row capacity and scope may make it inaccurate. It is not an admissible lower bound or independent proof checker.',
        'For a candidate/validated row-cluster projection, credit only additional fully completed recursively justified outputs, then compare marginal target-support reduction. Unfilled receptors, arbitrary partial samples and duplicate known outputs receive no invented fact credit. Unknown/infinite/overbudget scoring falls back to a stable declared ordering.'],
    'point_integration': [
        'Use the score only after Graph has selected a genuine branch point under the unchanged global dead/forced/earliest-generation scheduler.',
        'Rerank the existing validated Join item pool and/or incident alternatives through an explicitly declared mapping. Do not ask the scorer to replace graph domains, certify singleton/EOF, choose a later generation, bulk-place a cluster or exclude an alternative.',
        'Preserve arbitrary sampled proposals, every original incident fallback alternative, each constituent legality/update/rollback, full literal model and final fresh native/point checks. No learned pruning or RL credit.'],
    'symbolic_integration': [
        'Apply the same support potential to already legal yielded row candidates, retaining all original skeleton k, basis variant v, interface modes, strict-prior ordered source tuples and exact-word duplicates/padding.',
        'Keep novel-first or other stable lexical tie policy prospectively explicit. The heuristic is ordering only; no dominance quotient, new rule or prefix rejection.'],
    'prospective_experiment': {
        'status': 'DESIGN_ONLY_ROOT_STEER_AND_DISTINCT_SOURCE_REVIEW_REQUIRED',
        'minimal_factorial': ['point existing ordering', 'point receptor-support ordering',
                              'symbolic existing ordering', 'symbolic receptor-support ordering'],
        'fixed_problem': 'Same c3 assertion and any separately frozen new benchmark cases; same 12 rows, two syntax rounds, complete native registry/library, primitive grammar and common completed point model. Compact storage and shared result Reader are fixed engineering configuration, not new treatment factors.',
        'limits': 'Keep the coherent current 180-second whole-work, 210-second terminal, 1-GiB conservative aggregate and 128-MiB output envelope; nominal search 30 seconds/5000 method-specific extensions or placements unless Root prospectively chooses a new coherent declaration before any outcomes. No retries or outcome-dependent increase.',
        'charge': 'Charge support graph construction, relaxation, candidate scoring, cluster validation, full model acquisition, source custody, rollback, native/point verification, serialization and transport.',
        'primary_endpoint': 'A fresh whole Native-accepted and full point-verified final proof within the complete declared resource profile. Outside-profile proof data remain diagnostic.',
        'retain': ['full semantic and model preimages', 'exact candidate ordering before/after with scoring reason',
                   'support seeds and ordered joint-premise provenance', 'all returned UNKNOWN and partial stages',
                   'complete selected DAG/word and essential ancestry', 'hints offered, incident consumption and completed useful premises separately',
                   'exact rollback and full Native/point receipts', 'proposal/scoring/setup/whole timings and conservative peaks'],
        'interpretation': 'If both search methods improve, that supports a generic proof-search heuristic contribution rather than a geometry-specific advantage. A point-only gain would still require causal ordering/essential-cluster evidence and replication. One c3 observation establishes neither speed superiority nor generalization. No RL is introduced.'},
    'rejected_overclaims': ['No claim this heuristic solves c3 or fits the resource profile.',
                           'No proof route is inferred or supplied.', 'No complete finite proof-space exhaustion is claimed.',
                           'No source-only estimate is a runtime prediction.',
                           'A larger recursive receptor-cluster generator is a separate possible design, not silently included in this one-change ordering experiment.']}
design_pin = write('ordering-design-v1.json', design)

html_ready = {
    'schema': 'curried-search-html-ready-findings-v1', **scope, 'ancestry': ancestry,
    'diagnosis': diagnosis_pin, 'design': design_pin,
    'title': 'Why the curried case remains unresolved',
    'lead': 'The saved runs expose shallow relevance scoring and expensive suffix exploration. They provide a concrete next experiment, not a proof that a new heuristic will succeed.',
    'statement_latex': diagnosis['receiver_statement_latex'],
    'rows': [
        {'method': 'symbolic', 'status': 'UNKNOWN: row-extension limit', 'search_seconds': 6.709443915984593,
         'work_count': 5000, 'work_unit': 'legal row extensions', 'backtracks': 4990,
         'old_resource_profile_pass': True},
        {'method': 'point base', 'status': 'UNKNOWN: nominal search wall limit', 'search_seconds': 30.173799750045873,
         'work_count': 2030, 'work_unit': 'tile placements', 'backtracks': 1984,
         'old_resource_profile_pass': False},
        {'method': 'point fixed', 'status': 'UNKNOWN: nominal search wall limit', 'search_seconds': 30.027331374934874,
         'work_count': 2739, 'work_unit': 'tile placements', 'backtracks': 2689,
         'old_resource_profile_pass': False}],
    'callouts': [
        {'title': 'Suffix exploration dominates', 'text': 'The symbolic trace records 4,677 extensions at row 10 and none at row 11. Its first seven choices remain ancestors at the cutoff. This is one bounded DFS observation, not a global impossibility result.'},
        {'title': 'A licence can look relevant without supplying its premise', 'text': 'A target-derived UI implication licence is ranked nearer the target than a necessary-looking theory axiom by the old reverse BFS. The licence is legal; it does not make the target an available fact. The ordering is cycle-blind, while the proof guards remain separate.'},
        {'title': 'One shared next change', 'text': 'Order existing validated candidates by the marginal support of all required receptors together, grounded in facts already justified by the current state. Keep all graph propagation, fallback alternatives and whole-proof checks.'},
        {'title': 'Conventional comparison is essential', 'text': 'Apply the same heuristic to the symbolic control. Gains shared by both would be evidence for a useful general search heuristic, not a unique contribution of geometric representation.'}],
    'display_limits': ['No c3 proof or new theorem was obtained.', 'No learned marking or RL policy is tested.',
                       'Point timing data came from old memory-profile failures and remain diagnostic.',
                       'Current proposal generation is bounded and predominantly single-row; this ordering proposal does not enlarge it.',
                       'Source reasoning and retained trace correlations do not establish causal speed or future success.']}
html_pin = write('html-ready-findings-v1.json', html_ready)
handoff = dict(schema='curried-search-diagnosis-handoff-v1', **scope,
               author_identity=ancestry['author_identity'], ancestry=ancestry,
               diagnosis=diagnosis_pin, proposed_design=design_pin, html_ready_findings=html_pin,
               literal_evidence=evidence_pin, original_observations=pin(observation_path),
               metadata_scripts=[pin(D/'read_retained_v1.py'), pin(Path(__file__))],
               no_implementation=True, no_activation=True, no_future_hint_payload=True,
               requested_next_action='Root selects/finalizes the single common heuristic experiment, then commissions separately reviewed Source and prospective grants. No agent execution is authorized by this packet.')
handoff_pin = write('handoff-v1.json', handoff)
print(json.dumps(handoff_pin, sort_keys=True))
