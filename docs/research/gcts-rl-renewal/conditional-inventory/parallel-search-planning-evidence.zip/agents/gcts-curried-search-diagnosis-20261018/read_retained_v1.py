from pathlib import Path
import json,hashlib,collections,gc
D=Path('/private/tmp/gcts-curried-search-diagnosis-20261018');R=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
def pin(p):
 p=Path(p).resolve();h=hashlib.sha256();n=0
 with p.open('rb') as f:
  for b in iter(lambda:f.read(65536),b''):h.update(b);n+=len(b)
 return dict(path=str(p),bytes=n,sha256=h.hexdigest())
def canon(x):return json.dumps(x,sort_keys=True,separators=(',',':'))
a=json.loads((R/'.gcts-active/structural-quantified-progress-20261018/ROOT-actual-admission-v1.json').read_bytes())
rows=[r for r in a['actuals'] if 'c3' in r['invocation_id']];reports=[]
for r in rows:
 raw=Path(r['result']['path']).read_bytes();assert len(raw)==r['result']['bytes'] and hashlib.sha256(raw).hexdigest()==r['result']['sha256'];d=json.loads(raw);del raw
 s=d['outputs']['search'];rec=dict(mode=r['mode'],raw_result=r['result'],ROOT_resource_admitted=r['ROOT_resource_admitted'],status=s['status'],seconds=s['seconds'],search_keys=list(s),metrics=s['metrics'],proof=s.get('proof'),limits=s.get('limits'),root_restored=s.get('root_restored',s.get('root_path_restored')),catalog=d['outputs']['compile'].get('catalog'),inventory={k:d['outputs']['register'][k] for k in ['status','interfaces','definitions','native_blocks'] if k in d['outputs']['register']})
 if r['mode']=='symbolic':
  ev=s['events'];rec['reason']=s.get('reason');rec['preparation_seconds']=s.get('preparation_seconds');rec['backward_distances']=s.get('backward_distances');rec['interrupted_prefix']=s.get('interrupted_prefix');rec['complete_exhaustion']=s.get('complete_exhaustion')
  rec['event_count']=len(ev);rec['row_hist']=dict(collections.Counter(e['row'] for e in ev));rec['rule_hist']=dict(collections.Counter(e['command']['rule'] for e in ev));rec['action_hist']=dict(collections.Counter(e['action'] for e in ev));rec['output_hist']=dict(collections.Counter(canon(e['command']['formula']) for e in ev));rec['first_events']=ev[:20];rec['last_events']=ev[-12:]
  byid={e['id']:e for e in ev};last=ev[-1] if ev else None;chain=[]
  while last is not None:
   chain.append(last);last=byid.get(last['parent'])
  rec['last_event_ancestor_chain']=list(reversed(chain))
  rec['distinct_output_count_by_prefixdepth']={str(depth):len({canon(e['command']['formula']) for e in ev if e['row']==depth}) for depth in sorted({e['row'] for e in ev})}
 else:
  tree=s.get('tree');stack=[(tree,0,[])];kinds=collections.Counter();depths=collections.Counter();cuts=[];maxdepth=0;firstchain=[];nodes=0
  while stack:
   t,depth,path=stack.pop()
   if not isinstance(t,dict):continue
   nodes+=1;maxdepth=max(maxdepth,depth);kinds[t.get('kind')]+=1;depths[depth]+=1
   if t.get('cutoff'):cuts.append(dict(depth=depth,path=path,cutoff=t['cutoff'],point=t.get('point'),kind=t.get('kind'),alternatives=t.get('alternatives'),review=t.get('review')))
   for ch in reversed(t.get('children',[])):stack.append((ch['tree'],depth+1,path+[ch['key']]))
  t=tree
  while isinstance(t,dict):
   firstchain.append({k:t.get(k) for k in ['kind','point','hint_in','hint_start','review','alternatives','cutoff']});children=t.get('children',[]);t=children[0]['tree'] if children else None
  rec['retained_tree_summary']=dict(nodes=nodes,maxdepth=maxdepth,kinds=dict(kinds),depth_hist=dict(depths),cutoffs=cuts,first_branch_chain=firstchain)
  rec['events_count']=len(s.get('events',[]));rec['hints_count']=len(s.get('hints',[]));rec['first_policy_events']=s.get('events',[])[:3];rec['last_policy_events']=s.get('events',[])[-2:];rec['first_hints']=s.get('hints',[])[:3]
  # Literal metadata lookup only: map recorded cutoff keys to their stored row
  # command/role data. This invokes no Model/inference operation.
  placements={tuple(p['key']):p for p in d['outputs']['model']['placements']}
  rec['first_chain_placement_commands']=[dict(key=k,packet={x:placements[tuple(k)].get(x) for x in ['kind','slot','command','requirements']}) for k in (cuts[0]['path'] if cuts else [])]
  rec['cutoff_census_summary']=[]
  if cuts:
   route=cuts[0]['path'];t=tree
   for k in route:
    t=next(ch['tree'] for ch in t['children'] if ch['key']==k)
   rec['cutoff_census_summary']=[dict(point=x['point'],generation=x['generation'],keys_count=len(x['keys'])) for x in t.get('census',[])]
 reports.append(rec);print(r['mode'],'metrics',s['metrics'],'seconds',s['seconds'],'reason',s.get('reason'));del d,s;gc.collect()
p=D/'retained-search-observations-v1.json';p.write_text(json.dumps(dict(schema='curried-retained-search-observations-v1',scientific_calls=0,scientific_acceptance=False,target_imports=0,retained_JSON_data_analysis_only=True,source_only=True,admission=pin(R/'.gcts-active/structural-quantified-progress-20261018/ROOT-actual-admission-v1.json'),actuals=reports),sort_keys=True,indent=2)+'\n');print(pin(p))
