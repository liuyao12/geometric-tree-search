"""Author ordinary theorem INPUT data only; no proof/candidate/model generation."""
from pathlib import Path
import json,hashlib,copy
OUT=Path('/private/tmp/gcts-first-order-next-benchmark-source-20261018')
REPO=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode('utf8')
def pin(p):
 p=Path(p);s=p.stat();assert not getattr(s,'st_flags',0)&0x40000000;b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def write(name,x):
 p=OUT/name;assert not p.exists();p.write_bytes(json.dumps(x,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False).encode()+b'\n');return pin(p)
def data(p):
 p=Path(p);r=pin(p);return r,json.loads(p.read_bytes())
# These constructors merely assemble JSON arrays; no formula is evaluated.
def v(n):return ['var',n]
def f(n,*a):return ['fun',n,list(a)]
def p(n,*a):return ['pred',n,list(a)]
def eq(a,b):return ['eq',a,b]
def imp(a,b):return ['imp',a,b]
def all_(n,a):return ['all',n,a]
def neg(a):return ['not',a]
x=v('x');y=v('y');a=f('a');b=f('b');c=f('c')
base_scope='Authored prospective synthetic first-order assertion; closed axioms and closed target, no open root assumptions or schemas. Input only, no proof/route/instance hints; twelve rows and two frozen catalog rounds. All runtime outcomes unmeasured.'
def spec(n,functions,predicates,axioms,target):
 return dict(id='prospective-fol-20261018-'+str(n).zfill(3),title='Prospective first-order assertion '+str(n).zfill(2),theory=dict(functions=functions,predicates=predicates,axioms={'a'+str(i):q for i,q in enumerate(axioms)},schemas=[]),target=target,length=12,instantiation_rounds=2,scope=base_scope)
cases=[
 spec(1,{'a':0,'b':0},{'P':1},[eq(a,b),p('P',a)],p('P',b)),
 spec(2,{'a':0,'b':0,'f':1},{},[eq(a,b)],eq(f('f',a),f('f',b))),
 spec(3,{'a':0,'b':0,'c':0},{},[eq(a,b),eq(b,c)],eq(a,c)),
 spec(4,{'a':0,'f':1},{'P':1,'Q':1},[all_('x',imp(p('P',x),p('Q',f('f',x)))),p('P',a)],p('Q',f('f',a))),
 spec(5,{'a':0,'b':0},{'R':2,'S':2},[all_('x',all_('y',imp(p('R',x,y),p('S',y,x)))),p('R',a,b)],p('S',b,a)),
 spec(6,{},dict(P=1,Q=1,R=1,S=1),[all_('x',imp(p('P',x),p('Q',x))),all_('x',imp(p('P',x),p('R',x))),all_('x',imp(p('Q',x),imp(p('R',x),p('S',x)))),all_('x',p('P',x))],all_('x',p('S',x))),
 spec(7,{},dict(P=1,Q=1,R=1),[all_('x',imp(p('P',x),p('Q',x))),all_('x',imp(p('Q',x),p('R',x)))],all_('x',imp(p('P',x),p('R',x)))),
 spec(8,{},dict(P=1,Q=1),[all_('x',imp(p('P',x),p('Q',x)))],all_('x',imp(neg(p('Q',x)),neg(p('P',x)))))
]
# Systematic global symbol/binder/axiom renamings, NOT extra structural groups.
def renamed(source,n,functions,predicates,variables,axioms):
 r=copy.deepcopy(source);r['id']='prospective-fol-20261018-'+str(n).zfill(3);r['title']='Prospective first-order assertion '+str(n).zfill(2)
 def term(t):return ['var',variables.get(t[1],t[1])] if t[0]=='var' else ['fun',functions.get(t[1],t[1]),[term(a) for a in t[2]]]
 def form(q):
  k=q[0]
  if k=='pred':return [k,predicates.get(q[1],q[1]),[term(a) for a in q[2]]]
  if k=='eq':return [k,term(q[1]),term(q[2])]
  if k=='all':return [k,variables.get(q[1],q[1]),form(q[2])]
  if k=='bot':return [k]
  return [k,*[form(z) for z in q[1:]]]
 r['theory']['functions']={functions.get(k,k):a for k,a in source['theory']['functions'].items()};r['theory']['predicates']={predicates.get(k,k):a for k,a in source['theory']['predicates'].items()};r['theory']['axioms']={axioms.get(k,k):form(q) for k,q in source['theory']['axioms'].items()};r['target']=form(source['target']);return r
maps=[dict(functions={'a':'c0','b':'c1'},predicates={'P':'U'},variables={},axioms={'a0':'h0','a1':'h1'}),dict(functions={'a':'d0','b':'d1'},predicates={'R':'V','S':'W'},variables={'x':'m','y':'n'},axioms={'a0':'k0','a1':'k1'})]
cases.extend([renamed(cases[0],9,**maps[0]),renamed(cases[4],10,**maps[1])])
latex=[
 r'\{a=b,\ P(a)\}\ \vdash\ P(b)',
 r'\{a=b\}\ \vdash\ f(a)=f(b)',
 r'\{a=b,\ b=c\}\ \vdash\ a=c',
 r'\{\forall x\,(P(x)\Rightarrow Q(f(x))),\ P(a)\}\ \vdash\ Q(f(a))',
 r'\{\forall x\,\forall y\,(R(x,y)\Rightarrow S(y,x)),\ R(a,b)\}\ \vdash\ S(b,a)',
 r'\{\forall x\,(P(x)\Rightarrow Q(x)),\ \forall x\,(P(x)\Rightarrow R(x)),\ \forall x\,(Q(x)\Rightarrow(R(x)\Rightarrow S(x))),\ \forall x\,P(x)\}\ \vdash\ \forall x\,S(x)',
 r'\{\forall x\,(P(x)\Rightarrow Q(x)),\ \forall x\,(Q(x)\Rightarrow R(x))\}\ \vdash\ \forall x\,(P(x)\Rightarrow R(x))',
 r'\{\forall x\,(P(x)\Rightarrow Q(x))\}\ \vdash\ \forall x\,(\neg Q(x)\Rightarrow\neg P(x))',
 r'\{c_0=c_1,\ U(c_0)\}\ \vdash\ U(c_1)',
 r'\{\forall m\,\forall n\,(V(m,n)\Rightarrow W(n,m)),\ V(d_0,d_1)\}\ \vdash\ W(d_1,d_0)'
]
labels=['ground-equality-predicate-transport','unary-function-congruence','ground-equality-chain','functional-universal-horn','binary-relational-permutation','quantified-shared-premise-fork-join','quantified-hypothetical-composition','quantified-contraposition']
# Static ordinary JSON field/signature/closure inspection only; no native checker,
# logical truth test, substitution, scheme enumeration, catalog/model/proof search.
def inspect(s):
 assert set(s)=={'id','title','theory','target','length','instantiation_rounds','scope'} and s['length']==12 and s['instantiation_rounds']==2
 t=s['theory'];assert set(t)=={'functions','predicates','axioms','schemas'} and t['schemas']==[]
 assert all(type(n)is str and type(k)is int and k>=0 for n,k in list(t['functions'].items())+list(t['predicates'].items()))
 nodes=0;tags={};binders=set()
 def term(q,bound):
  nonlocal nodes
  nodes+=1;assert type(q)is list
  if q[0]=='var':assert len(q)==2 and type(q[1])is str;return {q[1]}-bound
  assert q[0]=='fun' and len(q)==3 and type(q[2])is list and q[1] in t['functions'] and len(q[2])==t['functions'][q[1]]
  return set().union(*(term(z,bound) for z in q[2]))
 def formula(q,bound=frozenset()):
  nonlocal nodes
  nodes+=1;assert type(q)is list and type(q[0])is str;tag=q[0];tags[tag]=tags.get(tag,0)+1
  if tag=='all':assert len(q)==3 and type(q[1])is str;binders.add(q[1]);return formula(q[2],bound|{q[1]})
  if tag=='pred':assert len(q)==3 and q[1] in t['predicates'] and len(q[2])==t['predicates'][q[1]];return set().union(*(term(z,bound) for z in q[2]))
  if tag=='eq':assert len(q)==3;return term(q[1],bound)|term(q[2],bound)
  if tag=='bot':assert len(q)==1;return set()
  assert tag in ['not','imp','and','or'] and len(q)==(2 if tag=='not' else 3)
  return set().union(*(formula(z,bound) for z in q[1:]))
 for q in [*t['axioms'].values(),s['target']]:assert not formula(q)
 assert canonical(s['target']) not in [canonical(q) for q in t['axioms'].values()]
 assert not any(k in str(s) for k in ['"proof"','"rule"','"registered_family"','"selected"'])
 return dict(static_envelope_checked=True,all_axioms_closed=True,target_closed=True,formula_tag_occurrences=tags,initial_binder_names=sorted(binders),input_AST_nodes=nodes,native_status=None,compiled_catalog=None,model=None,proof=None)
# Renaming-invariant DATA shape: ordered premises, binder deBruijn positions,
# first-occurrence function/predicate IDs. This does not decide entailment.
def shape(s):
 fn={};pn={}
 def name(table,k,arity):
  key=(k,arity)
  if key not in table:table[key]=len(table)
  return [table[key],arity]
 def term(q,env):
  if q[0]=='var':return ['bound',env[::-1].index(q[1])] if q[1] in env else ['free',q[1]]
  return ['fun',name(fn,q[1],len(q[2])),[term(z,env) for z in q[2]]]
 def form(q,env=()):
  if q[0]=='all':return ['all',form(q[2],env+(q[1],))]
  if q[0]=='pred':return ['pred',name(pn,q[1],len(q[2])),[term(z,env) for z in q[2]]]
  if q[0]=='eq':return ['eq',term(q[1],env),term(q[2],env)]
  return [q[0],*[form(z,env) for z in q[1:]]]
 return dict(axioms=[form(q) for k,q in sorted(s['theory']['axioms'].items())],target=form(s['target']))
closure_pin,closure=data(REPO/'.gcts-active/compact-model-cold-integration-progress-20261018/runtime-closure-v1.json')
parent_pin,parent=data(REPO/'.gcts-active/structural-quantified-progress-20261018/experiment-declaration-v2.json')
probe_pin,probes=data('/private/tmp/gcts-quantified-structural-benchmark-source-20261018/scope-and-coverage-probes-v1.json')
profile_pin,oldprofile=data(REPO/'.gcts-active/compact-model-cold-integration-progress-20261018/experiment-declaration-v1.json')
policy_pin=pin('/private/tmp/gcts-semantic-family-next-audit-20261018/semantic-inventory-policy-001.json')
master_pin=pin(REPO/'docs/basic-tiling-algorithm.md');native_pin=pin('/private/tmp/gcts-semantic-family-next-audit-20261018/fol_checker.tree')
source_refs=dict(runtime_closure=closure_pin,parent_development_declaration=parent_pin,prior_coverage_probes=probe_pin,current_profile_declaration=profile_pin,complete_prior_library=policy_pin,master=master_pin,native_checker_Source=native_pin,compiler=closure['project_sources']['quantified_receptors_v1'],ordinary_model=closure['project_sources']['quantified_family_points_v2'],compact_model=closure['project_sources']['interned_quantified_family_points_v1'],symbolic_control=closure['project_sources']['quantified_symbolic_control_v1'],driver=closure['additional_nonseed_components']['receiver_driver'])
for r in source_refs.values():pin(r['path'])
oldshapes={q['id']:shape(q) for q in parent['receivers']}
primaryshapes=[shape(q) for q in cases[:8]]
assert len({hashlib.sha256(canonical(z)).hexdigest() for z in primaryshapes})==8
assert all(z not in oldshapes.values() for z in primaryshapes)
assert shape(cases[8])==shape(cases[0]) and shape(cases[9])==shape(cases[4])
assert len({q['id'] for q in cases})==10
case_rows=[]
for i,q in enumerate(cases):
 r=write(q['id']+'.json',q);meta=inspect(q);group=i if i<8 else (0 if i==8 else 4)
 row=dict(case_id=q['id'],input=r,group=labels[group],structural_primary=i<8,renaming_control_of=None if i<8 else cases[group]['id'],formula_latex=latex[i],input_only=True,source_shape_sha256=hashlib.sha256(canonical(shape(q))).hexdigest(),shape=shape(q),static_authoring=meta,expected_runtime_status=None,expected_proof_rows=None,expected_basis_or_inventory_counts=None)
 if i>=8:row['renaming_map']=maps[i-8]
 case_rows.append(row)
refs=[
 dict(id='TPTP_PROBLEMS',title='TPTP Format for Problems',url='https://tptp.org/UserDocs/QuickGuide/Problems.html',primary=True,verified_online_date='2026-10-18',supports='FOF problem organization uses axioms and a conjecture; not an official import for this corpus.'),
 dict(id='TPTP_DERIVATIONS',title='TPTP Format for Derivations',url='https://tptp.org/UserDocs/QuickGuide/Derivations.html',primary=True,verified_online_date='2026-10-18',supports='Acyclic, traceable proof output ending in the requested conclusion and explicit premise/dependency provenance; any future external translation requires its own validation.'),
 dict(id='CASC_J13_DESIGN',title='CASC-J13 Design and Organization',url='https://tptp.org/CASC/J13/Design.html',primary=True,verified_online_date='2026-10-18',supports='General-purpose strategy freeze, limited similar-problem duplication, bounded execution, accepted complete solution output, and clear timing/resource accounting; this suite is not CASC eligible or ranked data.'),
 dict(id='SZS_ONTOLOGIES',title='The SZS Ontologies',url='https://szs.tptp.org/',primary=True,verified_online_date='2026-10-18',supports='Separate semantic success from no-success causes and justifying proof data. UNKNOWN/time/resource/error is not CounterSatisfiable.'),
]
references=write('primary-sources-v1.json',dict(schema='authored-first-order-primary-source-map-v1',scientific_calls=0,web_browsing_only=True,sources=refs,source_content_use='Short paraphrases and direct links only. No official theorem/problem/proof file imported, no external prover or online problem-processing service invoked.'))
index=write('suite-input-index-v1.json',dict(schema='authored-first-order-next-suite-input-index-v1',author_identity='/root/receiver_driver_review',created_date='2026-10-18',status='FROZEN_INPUT_ONLY_UNEXECUTED',source_only=True,scientific_calls=0,actual_execution_authorized=False,scientific_acceptance=False,goal_complete=False,suite_name='Prospective closed first-order structural suite 20261018 V1',provenance_class='AUTHORED_SYNTHETIC_NOT_OFFICIAL_TPTP',structural_group_count=8,case_count=10,renaming_control_count=2,source_refs=source_refs,primary_sources=references,receivers=case_rows))
coverage=write('coverage-provenance-v1.json',dict(schema='authored-first-order-suite-coverage-provenance-v1',author_identity='/root/receiver_driver_review',source_only=True,scientific_calls=0,source_refs=source_refs,suite=index,development_only=[dict(id=q['id'],shape_sha256=hashlib.sha256(canonical(oldshapes[q['id']])).hexdigest()) for q in parent['receivers']],prior_probes_development_only=[p['id'] for p in probes['probes']],novelty_scope='Eight primary input AST shapes differ from each other and the declared three development shapes under bound-variable/symbol renaming. Two controls intentionally share parent shapes. No all-history logical independence or blind sampling claim.',supported_input_lane=['Closed untyped first-order terms var/fun with declared finite arity; constants are zero-arity function applications.','Native formula tags bot/not/imp/and/or/all/pred/eq are available; this suite uses pred/eq/imp/not/all, constants and one unary function.','All named axioms and targets closed; schemas empty, no open root assumptions or predicate/function variables. Same exact receiver envelope,12rows,2catalog UI rounds.','Native supports axiom/tautology/refl/instantiate/eq_subst/mp/generalize/block and additional rules; current search catalog is narrower. No primitive exists, PA/Hilbert/geometry/typed or arithmetic assertion is introduced.'],finite_search_limits=['Frozen target-free input/target subterms plus explicit variable term for every initial binder. Because every target here is closed, only closed subterms plus binder variables enter the fixed pool. No arbitrary fresh ground-term closure.','Two UI catalog construction snapshots, not a global limit of two UI inference steps. Later capture-renamed names may enter variable metadata but do not grow the term pool. No percase source substitution is evaluated here.','Current generated equality schemes use one atomic-template layer and closed operand pairs from existing equality subformulas; no general equational saturation. Equality specimens use closed ground operands deliberately within that declared syntax lane.','Native tautology rule is broader than finite basis admission. Composition/contraposition may lack required intermediate propositional formulas in current subformula/UI/EQ catalog; no bridge formulas/axioms/helper lemmas are supplied and no finite-grammar impossibility is asserted.','All four old formula-family templates and all newly natively admitted specializations retained without filtering; derived physical arity covers every admitted interface. Grammar,registry,query,memory or search stops remain outcomes.'],unresolved_cases=[dict(case_id=cases[i]['id'],reason=reason) for i,reason in [(4,'Nested binary universal instance/argument-order/capture catalog may incur substantial setup/registry cost; no full catalog computed.'),(5,'Shared-premise branching and multiple quantified premises may exceed finite12-row/macro/domain/resource lane; no proof length or solvability claim.'),(6,'Hypothetical composition tests missing intermediate propositional synthesis coverage, not only exploration order.'),(7,'Negative polarity/contraposition tests finite propositional bridge coverage, not only exploration order.')]],case_status='All ten unexecuted; no native admission, catalog census, Model, proof, result or timing exists. All intended as classical theorem candidates; logical intent is author judgment, not a Native-certified status.',scope_exclusions=['No official TPTP problem IDs/content, CASC ratings or external solver results.','No truth/eigenvariable/substitution/Native/template/codec evaluation, benchmark trials or handwritten proof command sequence.','No additional rule, axiom schema, natural-number induction or Euclidean/Hilbert geometry theory.','No current cold activation compatibility: existing frozen cold/outer bind the earlier structural declaration and six selected-receiver subjects. A new genuinely reviewed declaration/selection/closure/cohort/grant composition is required.']))
design=write('design-holdout-controls-v1.json',dict(schema='authored-first-order-suite-design-v1',author_identity='/root/receiver_driver_review',source_only=True,scientific_calls=0,actual_execution_authorized=False,scientific_acceptance=False,suite=index,coverage=coverage,primary_sources=references,authorship='Reviewer authored a separate qualification harness and prior Source/data reviews, not the current search engines. This is new synthetic INPUT authorship, not independent own-input validation or a new proof-search implementation. Distinct Source/declaration review required.',split_policy=dict(development='All prior arithmetic/semantic cases, especially commutation/diagonal/curried and previously published coverage probes; prior outcomes were known and used only to exclude these inputs from the new structural list.',training='Only preexisting declared training/development proofs and frozen prior four-family library. Do not mine/train/tune on any new-suite outcome before cohort closure.',evaluation='Ten fixed inputs/eight groups authored before any of these cases were executed. Agent selected cases without consulting the parallel current-search diagnosis outcomes. No anticipated success/census/resource filter.',blindness='Prospective held-fixed synthetic evaluation, not a hidden blind test, random sample or official benchmark. Architecture and development results were known to author; formulas become visible on publication.',promotion='After any outcome is used for tuning/mining, mark that case/group as development in subsequent claims and require a new independently fixed evaluation corpus. Preserve every old outcome/version.'),profile=dict(parent=profile_pin,limits_literal=oldprofile['limits'],rows=12,instantiation_rounds=2,complete_output=True,conservative_peak_scope='Exact scientific worker+CPP wait4 high-water sum, may doublecount and excludes observer/parent; posthoc bound not live aggregate cap.',timing='Whole setup/import/compile/native-registry/full model+all candidates/search/native final/full point/output/reader/inverse/custody charged;180work/210overall. Same compact representation/common23-module setup initially in all methods.'),method_comparison=dict(initial_methods=['base','fixed','symbolic'],knowledge='Same full spec, complete compiler/admitted guards, full four-template prior policy and complete registered definitions/interfaces/native_blocks, full Model/initial state in every arm.',current_symbolic_control='Chronological finite proof-word prefix control over same compiled grammar/ordered prior ports, no GCTS points during its search; common point model construction and verification remain charged. It is not a complete dedicated FOL saturation prover or no-encoding-cost baseline.',operation_units='Point placement attempts and symbolic prefix extensions are different units; same numeric cap is a profile choice, not equal computational work or a speed ratio. Native queries/microsteps and complete wall/resource costs reported separately.',future_external_control='A separately reviewed TPTP translation and an established external FOL prover can test mathematical/corpus coverage. Such a prover has a different calculus/search space. Charge translation/library/preprocessing/proof production and independently validate accepted proof/translation; do not call it an exact finite-grammar control or invoke it now.'),success_and_reporting=dict(primary='Fresh whole Native-accepted proof of the exact target, full selected finite t/m/row verification, complete output/custody and declared resource/terminal gates. Report all three conjuncts separately.',secondary='Actual essential UI,GEN,equality,registered-family/cluster use and exact selected-path hint consumption are observations. Ground equality cases need not have UI or GEN; do not require the old UI+GEN milestone for their primary proof success.',all_outcomes='Retain input rejection, compile/registry/native space/timeout, model/transport/whole-point/resource failures and search UNKNOWN. Bounded failure is not theorem refutation or CounterSatisfiable; no outcome dropped/retried/recapped or fitted by grammar reduction.',grouping='Report10case slots and8structural groups separately; renaming controls are correlated tests, never independent new theorem families. For conservative group success require all group members to pass, not whichever rename succeeds.',inference='No significance/general superiority/RL benefit from one run per method/case. Prior storage engineering success on a familiar case is not this suite result.'),prospective_schedule_requirements=['Root separately freezes complete allcase/method subjects and unique fresh dirs/oncegrants after independent input/Source/composition review. No slots/grants/actuals are created here.','Use same strategy/profile for every input, no case IDs/titles/expected solutions in policies or special branches. Method order should be balanced/counterbalanced prospectively, with all seeds and any repetitions fixed before outcomes.','No handwritten proofs/rowcommands/routes/registered instance IDs in inputs. Posthoc line-by-line human proofs must be generated only from discovered admitted output.','All agents idle during Root sequential measurement windows; preserve failures and full records. Any Source repair or later larger-budget study gets a distinct prospective version, not relabeling old runs.'],benchmark_practice_mapping=[dict(source='TPTP_PROBLEMS',application='We use explicit axioms plus a target conjecture, but our JSON envelope is not TPTP syntax and no official library problem was imported.'),dict(source='CASC_J13_DESIGN',application='Freeze general strategies and test inputs before trials, retain complete acceptable solution output under declared bounds, group near-duplicate controls and disclose timing/measurement scope. This is methodological guidance, not CASC compliance/eligibility/ranking.'),dict(source='TPTP_DERIVATIONS',application='Require source-bound acyclic ordered premise links and final target/proof provenance; any future external transformation/proof format needs separate validation. Our native proof format remains distinct.'),dict(source='SZS_ONTOLOGIES',application='Keep theorem/proof acceptance separate from no-success reasons such as timeout,incompleteness,error. Our retained resource diagnostic is not automatically an SZS success or countermodel certificate.' )]))
audit=write('static-input-authoring-audit-v1.json',dict(schema='authored-first-order-suite-static-authoring-audit-v1',source_only=True,scientific_calls=0,target_imports=0,compiler_calls=0,model_calls=0,native_calls=0,solver_calls=0,codec_calls=0,renderer_calls=0,case_trials=0,proof_payloads=0,case_count=10,structural_groups=8,renaming_controls=2,all_native_statuses_unknown=True,ordinary_JSON_checks='Exact required envelope; declared term/predicate arity; closed premises/targets; distinct IDs; target not literally a supplied axiom; no proof/rule/selected fields; eight static renaming-invariant shapes distinct from old three development shapes and controls equal their parent shapes. No entailment/substitution/catalog/proof-length test.',suite=index,coverage=coverage,design=design,inputs=[r['input'] for r in case_rows]))
script=pin(__file__)
handoff=write('handoff-v1.json',dict(schema='authored-first-order-next-benchmark-handoff-v1',author_identity='/root/receiver_driver_review',source_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,goal_complete=False,status='FROZEN_INPUT_ONLY_UNEXECUTED',suite=index,coverage_provenance=coverage,design_holdout_controls=design,primary_sources=references,static_authoring_audit=audit,authoring_Source=script,inputs=[dict(case_id=r['case_id'],input=r['input'],group=r['group'],structural_primary=r['structural_primary'],renaming_control_of=r['renaming_control_of']) for r in case_rows],required_next='Root/distinct author reviews complete ordinary specs/provenance/grammar scope, then separately freezes new compatible input-selection/declaration/Source closure and all-method prospective subjects. No activation or results in this packet.',provenance='Ten authored synthetic JSON assertions, eight structural groups and two renaming controls. Not imported official TPTP/CASC problems; no theorem proof route or registered family instance supplied.'))
print(json.dumps(handoff))
