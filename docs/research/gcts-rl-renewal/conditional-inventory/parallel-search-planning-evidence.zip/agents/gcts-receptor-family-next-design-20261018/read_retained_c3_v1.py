from pathlib import Path
import collections,hashlib,json
OUT=Path('/private/tmp/gcts-receptor-family-next-design-20261018')
rawpath=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/structural-quantified-c3-fixed-ROOT-20261018-v1/result.json')
def pin(p):
 p=Path(p);h=hashlib.sha256();n=0
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b);n+=len(b)
 return dict(path=str(p),sha256=h.hexdigest(),bytes=n)
p=pin(rawpath);assert p['sha256']=='33656cdc3810198b6413ea9428811811b170f7614c760e8e8b1782eb60fb7cdc' and p['bytes']==78204773
before=rawpath.stat()
# Saved JSON data only. No scientific module, Model, reader or search invoked.
with rawpath.open() as f:data=json.load(f)
after=rawpath.stat();assert (before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns)==(after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns)
s=data['outputs']['search'];model=data['outputs']['model'];reg=data['outputs']['register'];compiledata=data['outputs']['compile']
defs={x['name']:x for x in reg['definitions']};placed={tuple(x['key']):x for x in model['placements']}
hint_kind=collections.Counter();hintlevel=collections.Counter();hint_size=collections.Counter();rules=collections.Counter();families=collections.Counter();hint_rows=collections.Counter()
for h in s['hints']:
 item=h['item'];hint_kind[item['kind']]+=1;hintlevel[str(item['level'])]+=1;hint_size[str(len(item['members']))]+=1
 for k in item['members']:
  k=tuple(k)
  if k[1]==1:
   cmd=placed[k]['command'];rules[cmd['rule']]+=1;hint_rows[str(k[0])]+=1
   if cmd['rule']=='block':families[defs[cmd['name']]['family']]+=1
cutoffs=[];nodes=0;depths=collections.Counter();policy_selected=collections.Counter();changed_order=0;selected_hint_count=0
stack=[(s['tree'],0)]
while stack:
 t,depth=stack.pop();nodes+=1;depths[str(depth)]+=1
 if 'cutoff' in t:cutoffs.append(dict(depth=depth,kind=t['kind'],point=t['point'],cutoff=t['cutoff'],candidate_count=len(t.get('alternatives',[]))))
 if 'policy_event' in t:
  e=s['events'][t['policy_event']];item=e['items'][e['index']];policy_selected['defer' if item is None else item['kind']]+=1
  if item is not None:selected_hint_count+=1
  actual=t.get('alternatives',[]);canonical_keys=sorted(actual)
  if actual and actual!=canonical_keys:changed_order+=1
 for child in t['children']:stack.append((child['tree'],depth+1))
summary=dict(schema='retained-c3-family-search-observation-v1',scientific_calls=0,scientific_replays=0,project_imports=0,result_json_decodes=1,scope='Static Source and saved JSON counts only, no model/proof/search replay. Counters do not prove absent routes or family usefulness.',raw_result=p,declaration=data['declaration'],status=data['status'],native_proof_accepted=data['native_proof_accepted'],search_status=s['status'],search_proof_present=s['proof'] is not None,root_restored=s['root_restored'],seconds=s['seconds'],limits=s['limits'],metrics=s['metrics'],catalog=dict(basis_count=len(compiledata['basis']),variables=compiledata['variables'],terms=compiledata['catalog']['terms'],rounds=compiledata['catalog']['rounds'],admitted_scheme_count=len(compiledata['admitted_schemes'])),inventory=dict(status=reg['status'],interface_count=len(reg['interfaces']),definition_count=len(reg['definitions']),interfaces=[dict(name=n,family=defs[n]['family'],level=defs[n]['level'],premise_count=len(defs[n]['definition']['premises'])) for n in reg['interfaces']]),model=dict(placements=len(model['placements']),arity=model['arity'],roots=len(model['roots'])),hint_counts=dict(kinds=dict(hint_kind),levels=dict(hintlevel),member_sizes=dict(hint_size),guard_rules=dict(rules),ground_family_counts=dict(families),guard_output_rows=dict(hint_rows)),policy_counts=dict(selected=dict(policy_selected),chosen_hint_count=selected_hint_count,tree_nodes_with_changed_canonical_alternative_order=changed_order),tree_summary=dict(nodes=nodes,cutoffs=cutoffs,maximum_selected_depth=max(map(int,depths)),empty_leaf_count=0),flags=dict(essential_hint_use_claimed=False,no_proof_no_essential_ancestry=True,hint_completed_is_pending_tile_status_not_lemma_truth=True))
(OUT/'retained-c3-observation-v1.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:summary[k] for k in ['status','search_status','search_proof_present','root_restored','catalog','inventory','model','hint_counts','policy_counts','tree_summary']},indent=2))
