"""Metadata-only report assembly. No project imports, inference, or search."""
import collections, hashlib, html, json, pathlib, zipfile
R=pathlib.Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
P=R/'.gcts-active/parallel-search-planning-progress-20261018'
O=P/'publication-source-v1'
O.mkdir(exist_ok=False)
checks=[]
def check(ok,label):
    checks.append({'ok':bool(ok),'check':label})
    if not ok: raise ValueError(label)
def pin(path):
    p=pathlib.Path(path); raw=p.read_bytes()
    return dict(path=str(p),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))
def verify(d):
    q=pin(d['path']); check(q==d,'literal descriptor '+d['path']); return pathlib.Path(d['path']).read_bytes()
def read(d): return json.loads(verify(d))
def load(p): return json.loads(pathlib.Path(p).read_bytes())
def write(p,d): p.write_text(json.dumps(d,indent=2,sort_keys=True,ensure_ascii=False,allow_nan=False)+'\n')
def publish(d,name):
    (O/name).write_bytes(verify(d)); return dict(name=name,original=d,published=pin(O/name))
C=load('/private/tmp/gcts-curried-search-diagnosis-20261018/handoff-v1.json')
L=load('/private/tmp/gcts-receptor-family-next-design-20261018/handoff-v1.json')
B=load('/private/tmp/gcts-first-order-next-benchmark-source-20261018/handoff-v1.json')
diagnosis=read(C['diagnosis']); proposal=read(C['proposed_design'])
family=read(L['design']); observation=read(L['retained_observation'])
suite=read(B['suite']); design=read(B['design_holdout_controls']); coverage=read(B['coverage_provenance'])
check(all(h['scientific_calls']==0 and h['actual_execution_authorized'] is False for h in (C,L,B)),'all three handoffs Source/retained-input only')
check(suite['case_count']==10 and len(suite['receivers'])==10,'ten frozen inputs')
check(diagnosis['findings'][0]['counts']['events_at_row10']==4677,'retained late-row concentration')
check(observation['metrics']['hint_completed']==120,'completed-phase visit count')
check(observation['hint_counts']['kinds']['lemma']==194,'selected lemma hints')
groups=collections.defaultdict(list); specs=[]; shapes={}; ids=set()
def term(t,theory,env,names):
    check(type(t) is list and len(t)>=2,'ordinary term AST')
    if t[0]=='var':
        check(len(t)==2 and type(t[1]) is str and t[1] in env,'all input variables bound')
        return ['bound',list(reversed(env)).index(t[1])]
    check(t[0]=='fun' and len(t)==3 and t[1] in theory['functions'] and type(t[2]) is list,'declared function application')
    check(len(t[2])==theory['functions'][t[1]],'function arity')
    names['fun'].setdefault(t[1],len(names['fun']))
    return ['fun',[names['fun'][t[1]],len(t[2])],[term(x,theory,env,names) for x in t[2]]]
def formula(f,theory,env,names):
    check(type(f) is list and len(f)>=1,'ordinary formula AST')
    tag=f[0]
    if tag=='all':
        check(len(f)==3 and type(f[1]) is str,'binder shape')
        return ['all',formula(f[2],theory,env+[f[1]],names)]
    if tag=='pred':
        check(len(f)==3 and f[1] in theory['predicates'] and type(f[2]) is list,'declared predicate')
        check(len(f[2])==theory['predicates'][f[1]],'predicate arity')
        names['pred'].setdefault(f[1],len(names['pred']))
        return ['pred',[names['pred'][f[1]],len(f[2])],[term(x,theory,env,names) for x in f[2]]]
    if tag=='eq':
        check(len(f)==3,'equality arity')
        return ['eq',term(f[1],theory,env,names),term(f[2],theory,env,names)]
    arities={'not':1,'imp':2,'and':2,'or':2,'bot':0}
    check(tag in arities and len(f)==arities[tag]+1,'connective shape')
    return [tag,*[formula(x,theory,env,names) for x in f[1:]]]
def texname(s): return r'\mathrm{'+s.replace('_',r'\_')+'}'
def ttex(t):
    if t[0]=='var': return texname(t[1])
    return texname(t[1])+(r'\left('+','.join(ttex(a) for a in t[2])+r'\right)' if t[2] else '')
def ftex(f):
    t=f[0]
    if t=='all': return r'\forall '+texname(f[1])+r'\,\left('+ftex(f[2])+r'\right)'
    if t=='pred': return texname(f[1])+(r'\left('+','.join(ttex(x) for x in f[2])+r'\right)' if f[2] else '')
    if t=='eq': return ttex(f[1])+'='+ttex(f[2])
    if t=='not': return r'\neg\left('+ftex(f[1])+r'\right)'
    if t=='bot': return r'\bot'
    return r'\left('+ftex(f[1])+r'\right)'+{'imp':r'\rightarrow','and':r'\land','or':r'\lor'}[t]+r'\left('+ftex(f[2])+r'\right)'
cases_html=[]
for meta in suite['receivers']:
    s=read(meta['input']); cid=s['id']
    check(cid==meta['case_id'] and cid not in ids,'unique input ID'); ids.add(cid)
    check(set(s)=={'id','title','scope','target','theory','length','instantiation_rounds'},'input-only exact envelope')
    check(s['length']==12 and s['instantiation_rounds']==2,'fixed grammar bounds')
    t=s['theory']; check(set(t)=={'functions','predicates','axioms','schemas'} and t['schemas']==[],'closed theory envelope with no schemas')
    check(all(type(v) is int and v>=0 for d in ('functions','predicates') for v in t[d].values()),'ordinary finite arities')
    names={'fun':{},'pred':{}}
    shape={'axioms':[formula(t['axioms'][k],t,[],names) for k in sorted(t['axioms'])],'target':formula(s['target'],t,[],names)}
    check(s['target'] not in t['axioms'].values(),'target not literal supplied axiom')
    check(shape==meta['shape'],'independent static normalized shape matches index')
    shapes[cid]=shape;groups[meta['group']].append(cid);specs.append({'metadata':meta,'spec':s})
    name='parallel-search-planning-'+cid+'.json'
    publish(meta['input'],name)
    rows=[r'\text{Axiom '+html.escape(k)+r'}&:\quad '+ftex(v) for k,v in sorted(t['axioms'].items())]
    rows.append(r'\text{Target}&:\quad '+ftex(s['target']))
    panel=r'\[\begin{aligned}'+r'\\'.join(rows)+r'\end{aligned}\]'
    rename=('<p>Renaming control of <code>'+html.escape(meta['renaming_control_of'])+'</code>; grouped with its parent.</p>') if meta['renaming_control_of'] else '<p>Primary structural input; unexecuted.</p>'
    cases_html.append('<details class="suite-case" data-group="'+html.escape(meta['group'],quote=True)+'"><summary>'+html.escape(meta['group'].replace('-',' '))+' · <code>'+cid+'</code></summary>'+rename+'<div class="formula">'+panel+'</div><p class="result-label">No scientific result or proof yet.</p><p><a href="'+name+'">Exact original input JSON</a></p><details><summary>Inspect the complete input value</summary><pre>'+html.escape(json.dumps(s,indent=2,ensure_ascii=False))+'</pre></details></details>')
check(len(groups)==8,'eight structural groups')
primary=[m for m in suite['receivers'] if m['structural_primary']]
check(len(primary)==8 and len({json.dumps(shapes[m['case_id']],sort_keys=True) for m in primary})==8,'eight distinct static primary shapes')
for m in suite['receivers']:
    if m['renaming_control_of']: check(shapes[m['case_id']]==shapes[m['renaming_control_of']],'rename grouped with identical static parent shape')
root_suite=dict(schema='ROOT-complete-authored-first-order-input-values-v1',scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,source_index=B['suite'],case_count=10,structural_groups=8,cases=specs,scope='Complete original JSON values with exact original descriptors; raw original files are separately published and bundled. Static envelope/signature/closure/renaming checks are not native admission or entailment checks.')
write(O/'parallel-search-planning-benchmark-suite.json',root_suite)
manifest=dict(schema='ROOT-authored-first-order-benchmark-manifest-v1',scientific_calls=0,actual_execution_authorized=False,agent_handoff=pin('/private/tmp/gcts-first-order-next-benchmark-source-20261018/handoff-v1.json'),author_input_index=B['suite'],case_groups=dict(groups),design=design,coverage=coverage,primary_sources=read(B['primary_sources']),input_descriptors=B['inputs'],scope='Prospectively fixed authored synthetic inputs. No official problem import, scientific execution or grants.')
write(O/'parallel-search-planning-benchmark-manifest.json',manifest)
bindings=[]
for d,n in ((C['diagnosis'],'diagnosis'),(C['proposed_design'],'support-design'),(C['literal_evidence'],'search-observations'),(L['design'],'family-design'),(L['retained_observation'],'family-observations')):
    bindings.append(publish(d,'parallel-search-planning-'+n+'.json'))
template=(P/'parallel-search-planning.template.html').read_text()
options=''.join('<option value="'+html.escape(g,quote=True)+'">'+html.escape(g.replace('-',' '))+'</option>' for g in groups)
report=template.replace('@@GROUP_OPTIONS@@',options).replace('@@CASES@@','\n'.join(cases_html))
check('@@' not in report,'all template fields resolved')
(O/'parallel-search-planning.html').write_text(report)
summary=dict(schema='ROOT-parallel-search-planning-summary-v1',date='2026-10-18',scientific_calls=0,new_scientific_runs=0,new_proofs=0,new_RL_training=False,goal_complete=False,actual_execution_authorized=False,source_scope=pin(P/'ROOT-scope-v1.json'),agent_handoffs={k:pin(v) for k,v in {'diagnosis':'/private/tmp/gcts-curried-search-diagnosis-20261018/handoff-v1.json','families':'/private/tmp/gcts-receptor-family-next-design-20261018/handoff-v1.json','benchmarks':'/private/tmp/gcts-first-order-next-benchmark-source-20261018/handoff-v1.json'}.items()},published_bindings=bindings,selected_next_intervention='ACYCLIC_RECEPTOR_SUPPORT_POTENTIAL_V1 ordering only in point and symbolic controls; multirow closure separately deferred',report=pin(O/'parallel-search-planning.html'),benchmark_cases=10,benchmark_groups=8,benchmark_status='FIXED_INPUT_ONLY_UNEXECUTED_NOT_BLIND_NOT_OFFICIAL_TPTP',known_gaps=['New heuristic and recursive proposer unimplemented','Input-selection/closure/declaration composition needs new review before any run','No fresh mathematical assertion proved','No trained RL or GCTS advantage established'])
write(O/'parallel-search-planning-summary.json',summary)
archive_objects={}
for folder in ('/private/tmp/gcts-curried-search-diagnosis-20261018','/private/tmp/gcts-receptor-family-next-design-20261018','/private/tmp/gcts-first-order-next-benchmark-source-20261018'):
    for path in sorted(pathlib.Path(folder).iterdir()):
        if path.is_file():archive_objects['agents/'+path.parent.name+'/'+path.name]=path
source_descriptors={**diagnosis['sources'],**coverage['source_refs']}
for key,d in source_descriptors.items():
    if pathlib.Path(d['path']).suffix in ('.py','.md','.tree','.json'):
        verify(d);archive_objects['inspected-sources/'+key+'/'+pathlib.Path(d['path']).name]=pathlib.Path(d['path'])
for path in (P/'ROOT-scope-v1.json',P/'parallel-search-planning.template.html',pathlib.Path(__file__)):
    archive_objects['Root/'+path.name]=path
# The zip is publication transport only, never a Native codec or scientific replay.
with zipfile.ZipFile(O/'parallel-search-planning-evidence.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name,path in sorted(archive_objects.items()):z.writestr(name,path.read_bytes())
evidence=dict(schema='ROOT-parallel-search-planning-evidence-manifest-v1',scientific_calls=0,actual_execution_authorized=False,objects=[pin(p) | {'name':p.name} for p in sorted(O.iterdir())],archive_objects=[pin(p)|{'archive_name':n} for n,p in sorted(archive_objects.items())],report_review_pending=True,notes='Paths in original frozen author artifacts are provenance. All ten exact original case files are published and included in archive. The full old actuals remain in the previous structural release, not replayed here.')
write(O/'parallel-search-planning-evidence-manifest.json',evidence)
check(pin(R/'docs/research/gcts-rl-renewal/index.html')['sha256']=='d04878220b6c43b16bbc1ff6cd17d24d824e2c3049a2b47600f0e26eec0cd770','protected Root overview unchanged')
write(P/'ROOT-static-input-and-report-checks-v1.json',dict(schema='ROOT-parallel-static-input-report-checks-v1',scientific_calls=0,checks=checks,findings=[x for x in checks if not x['ok']],scope='Raw descriptor/hash, ordinary input AST/signature/closed-variable/renaming and report assembly checks only. No engine/kernel/compiler/solver/native/renderer import, evaluation or inference.',publication_source=pin(O/'parallel-search-planning-evidence-manifest.json')))
print(json.dumps({'objects':len(list(O.iterdir())),'archive_objects':len(archive_objects),'checks':len(checks),'findings':0,'report':pin(O/'parallel-search-planning.html'),'evidence':pin(O/'parallel-search-planning-evidence-manifest.json')}))
