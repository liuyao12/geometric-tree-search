"""Close the report review and stage exact task-only publication bytes."""
import hashlib,json,pathlib,re,shutil,zipfile
R=pathlib.Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
P=R/'.gcts-active/parallel-search-planning-progress-20261018'
S=P/'publication-source-v1'
O=P/'publication-source-v2'
W=pathlib.Path('/private/tmp/gcts-split-controls-publish-20261015')
D=W/'docs/research/gcts-rl-renewal/conditional-inventory'
def pin(p):
 p=pathlib.Path(p);b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def load(p):return json.loads(pathlib.Path(p).read_bytes())
def write(p,d):pathlib.Path(p).write_text(json.dumps(d,indent=2,sort_keys=True,ensure_ascii=False,allow_nan=False)+'\n')
review=load(P/'ROOT-review-adoption-v1.json')
q=review['report_review']
assert pin(q['path'])==q
assert review['accepted_for_report_publication'] is True and review['scientific_activation_authorized'] is False
old=load(S/'parallel-search-planning-evidence-manifest.json')
for d in old['objects']:
 assert pin(S/d['name'])['sha256']==d['sha256'] and (S/d['name']).stat().st_size==d['bytes']
assert not O.exists()
shutil.copytree(S,O)
(O/'parallel-search-planning-report-review.json').write_bytes(pathlib.Path(q['path']).read_bytes())
summary=load(O/'parallel-search-planning-summary.json')
summary['report_review']=q
summary['review_adoption']=pin(P/'ROOT-review-adoption-v1.json')
summary['clarification']='The frozen coverage note phrase No primitive exists means no exists formula tag; primitive inference rules remain present.'
write(O/'parallel-search-planning-summary.json',summary)
archive=O/'parallel-search-planning-evidence.zip'
closure_archive_objects=[]
with zipfile.ZipFile(archive,'a',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name,p in [('Root/ROOT-static-input-and-report-checks-v1.json',P/'ROOT-static-input-and-report-checks-v1.json'),('Root/ROOT-review-adoption-v1.json',P/'ROOT-review-adoption-v1.json'),('Root/ROOT-next-work-v1.json',P/'ROOT-next-work-v1.json'),('Root/close_and_stage_v1.py',pathlib.Path(__file__)),('review/typed-report-review-v1.json',pathlib.Path(q['path'])),('Root/publication-manifest-v1-pending.json',S/'parallel-search-planning-evidence-manifest.json')]:
  assert name not in z.namelist();z.writestr(name,p.read_bytes());closure_archive_objects.append(pin(p)|{'archive_name':name})
 for p in sorted(pathlib.Path(q['path']).parent.iterdir()):
  if p.is_file() and p.resolve()!=pathlib.Path(q['path']).resolve():
   name='review/raw/'+p.name
   assert name not in z.namelist();z.writestr(name,p.read_bytes());closure_archive_objects.append(pin(p)|{'archive_name':name})
new=dict(old)
new['schema']='ROOT-parallel-search-planning-evidence-manifest-v2'
new['report_review_pending']=False
new['report_review']=q
new['review_adoption']=pin(P/'ROOT-review-adoption-v1.json')
new['prior_pending_manifest']=pin(S/'parallel-search-planning-evidence-manifest.json')
new['archive_objects']=old['archive_objects']+closure_archive_objects
new['objects']=[pin(p)|{'name':p.name} for p in sorted(O.iterdir()) if p.name!='parallel-search-planning-evidence-manifest.json']
new['closure_delta']='Same reviewed human HTML and frozen notes/inputs. Add exact review/adoption, close pending review, update summary/archive/manifest transport only. No scientific execution.'
write(O/'parallel-search-planning-evidence-manifest.json',new)
assert (S/'parallel-search-planning.html').read_bytes()==(O/'parallel-search-planning.html').read_bytes()
reader=D/'reader.html';prior=reader.read_text()
assert prior.count('<section id="model-storage-integration">')==1 and 'id="parallel-search-planning"' not in prior
section=r'<section id="parallel-search-planning"><p class="eyebrow">CURRENT RESEARCH · SOURCE AND RETAINED DATA</p><h2>Parallel investigations prepare the next proof-search test.</h2><p>Three separate investigations diagnose the curried UNKNOWN, assess reusable receptor families, and freeze \(10\) unrun first-order inputs across \(8\) structural groups. A generic AND-support ordering heuristic is selected for the next controlled implementation; recursive multirow closure remains a separate proposed change. No new scientific runs, proofs or RL training are reported.</p><p><a href="parallel-search-planning.html#roles"><b>Agent roles and inspectable findings</b></a> · <a href="parallel-search-planning.html#diagnosis">Where the earlier search budget went</a> · <a href="parallel-search-planning.html#benchmarks">Browse the frozen input formulas</a> · <a href="parallel-search-planning.html#next">Controls needed to establish a contribution</a>.</p></section>'
updated=prior.replace('<title>Proof-search research: complete-pipeline Model storage</title>','<title>Proof-search research: parallel investigations and prospective inputs</title>',1)
updated=updated.replace('<h1>Complete-pipeline Model storage.</h1>','<h1>Parallel proof-search investigations.</h1>',1)
oldlead=r'<p class="lead">Admitted complete-pipeline proofs: \(3\) of \(6\); \(3\) compact and \(0\) ordinary. Every consumed outcome is retained. The new report retains all outcomes and separates storage engineering from proof-search contribution.</p>'
newlead=r'<p class="lead">Parallel diagnosis, receptor-family design and a frozen input suite prepare the next search experiment. This Source and retained-data update reports \(0\) new scientific runs. The latest measured compact-storage results remain below.</p>'
assert oldlead in updated;updated=updated.replace(oldlead,newlead,1)
updated=updated.replace('<section id="model-storage-integration">',section+'<section id="model-storage-integration">',1)
updated=updated.replace('CURRENT RESULT · COMPLETE PIPELINE','LATEST MEASURED RESULT · COMPLETE PIPELINE',1)
(O/'reader.html').write_text(updated)
status=load(D/'parallel-work-status.json')
status['schema']='GCTS-parallel-research-status-v20'
status['current_research_report']='parallel-search-planning.html#roles'
status['current_research_summary']='parallel-search-planning-summary.json'
status['current_research_phase']='SOURCE_RETAINED_DATA_AND_FROZEN_INPUTS_ONLY'
status['current_research_new_scientific_runs']=0
status['current_research_new_proofs']=0
status['current_research_new_RL_training']=False
status['current_research_case_count']=10
status['current_research_structural_groups']=8
status['current_research_review']='parallel-search-planning-report-review.json'
status['current_assignments']={'ROOT':'Integrate distinct findings, independently check ordinary input envelopes/shapes, select one next intervention and publish; future scientific runs sequential','conventional_control_review':'Frozen Source/retained c3 failure diagnosis and generic AND-support ordering design','conventional_library':'Frozen reusable family capability assessment and separate proposed multirow receptor closure','receiver_driver_review':'Frozen authored input-only benchmark suite; distinct Root report review with own corpus authorship disclosed'}
status['current_checking_tasks']='Closed Source/retained-data planning milestone and input freeze. No new implementation, Source activation, scientific run, proof or RL. Existing measured storage result is preserved in current_report/current_result.'
status['next_bounded_hypothesis']='Implement and independently review generic positive-cost AND-receptor support ordering, supplied equally to point and conventional symbolic controls. Use curried assertion as development, freeze implementation before the10case/eightgroup prospective synthetic suite. Recursive multirow closure is separate. Fresh reviewed input selection/closure/declaration/grants required, no consumed retries.'
write(O/'parallel-work-status.json',status)
for p in sorted(O.iterdir()): shutil.copyfile(p,D/p.name)
changed=[str((D/p.name).relative_to(W)) for p in sorted(O.iterdir())]
# All new report links resolve against this exact overlay or existing publication.
from html.parser import HTMLParser
from urllib.parse import urlparse,unquote
class Links(HTMLParser):
 def __init__(self):super().__init__();self.links=[];self.ids=[]
 def handle_starttag(self,tag,attrs):
  a=dict(attrs)
  if 'id' in a:self.ids.append(a['id'])
  if tag in ('a','script','link'):
   v=a.get('href') or a.get('src')
   if v:self.links.append(v)
findings=[];link_checks=[]
for p in (D/'parallel-search-planning.html',D/'reader.html'):
 a=Links();a.feed(p.read_text())
 if len(a.ids)!=len(set(a.ids)):findings.append({'duplicate_ids':str(p)})
 checked_links=a.links
 if p.name=='reader.html':
  newlinks=Links();newlinks.feed(section);checked_links=newlinks.links
 for href in checked_links:
  u=urlparse(href)
  if u.scheme or u.netloc:continue
  target=(p.parent/unquote(u.path)).resolve() if u.path else p
  if not target.is_file(): findings.append({'missing':href,'from':str(p)});continue
  if u.fragment and target.suffix=='.html':
   b=Links();b.feed(target.read_text())
   if u.fragment not in b.ids: findings.append({'missing_fragment':href,'from':str(p)})
  link_checks.append({'from':p.name,'href':href,'target_exists':True})
assert not findings,findings
assert pin(R/'docs/research/gcts-rl-renewal/index.html')['sha256']=='d04878220b6c43b16bbc1ff6cd17d24d824e2c3049a2b47600f0e26eec0cd770'
write(P/'publication-inventory-v1.json',dict(schema='ROOT-parallel-search-planning-publication-inventory-v1',scientific_calls=0,scientific_activation_authorized=False,paths=changed,assets=[pin(D/p.name)|{'relative':str((D/p.name).relative_to(W))} for p in sorted(O.iterdir())],link_checks=link_checks,findings=findings,protected_overview_unchanged=True,report_HTML_unchanged_from_review=True,report_review=q))
print(json.dumps({'staged_assets':len(changed),'links':len(link_checks),'findings':len(findings),'HTML':pin(D/'parallel-search-planning.html')}))
