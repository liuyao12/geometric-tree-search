"""Separate automatic-search qualification fixture; inert until Root runs it.

No prospective cohort, held-out case, trained policy or supplied derivation is
read. The mined fixture library is qualification-only and must not be reused
as the prospective inventory. Scientific imports/calls occur only at runtime.
"""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT/'source'), str(ROOT/'reference')]
import proof_core_v1 as core
from finite_basis_v1 import compile_case
import semantic_families_v1 as semantic
from receptor_family_checker_v1 import verify


def fixture():
    x = ['var','qualification_x']
    fx = ['fun','qualification_f',[x]]
    p = lambda t: ['pred','qualification_P',[t]]
    q = lambda t: ['pred','qualification_Q',[t]]
    close = lambda f: ['all','qualification_x',f]
    return {'id':'qualification-only-quantified-Horn-v1','split':'qualification-only',
            'problem':{'theory':{'functions':{'qualification_f':1},
                       'predicates':{'qualification_P':1,'qualification_Q':1},
                       'axioms':{'qualification_fact':close(p(x)),
                                 'qualification_step':close(['imp',p(x),q(fx)])}},
                       'goal':close(q(fx))},
            'terms':[x,fx], 'profile':{'ui_rounds':1,'max_terms':8,'max_templates':8,'max_definitions':2000},
            'scope':'Independent API fixture, declared theory/goal only. No supplied proof, prospective case or learned inventory.'}


def nodes(value):
    if type(value) is list:
        yield value
        for child in value:
            yield from nodes(child)
    elif type(value) is dict:
        for child in value.values():
            yield from nodes(child)


def subject_match(cat, family, proposal, charge):
    """Exercise the subject matcher on THIS expansion, not a new proof search."""
    table = {cat.decode_id(row['id'])[0]:cat.decode_id(row['id'])[1] for row in proposal['placements']}
    environment = {'terms':{},'symbols':{}}
    seen = set()
    def visit(node, site):
        if site not in table or site in seen:
            return False
        seen.add(site); definition = table[site]
        if core.native(definition) != node['native'] or len(node['premises']) != len(definition['premises']):
            return False
        if not semantic.match_formula(node['output'],cat.forms[definition['output']],environment,charge):
            return False
        if not all(semantic.match_formula(t,cat.forms[f],environment,charge) for t,f in zip(node['premises'],definition['premises'])):
            return False
        return all(child is None or visit(child,site+str(i)) for i,child in enumerate(node['children']))
    return visit(family['semantic'],proposal['root_site']) and seen == set(table)


def run(output=None):
    output = Path(output) if output is not None else ROOT/'qualification-run-v1'
    output.mkdir(parents=True,exist_ok=False)
    source_paths = [ROOT/'source'/name for name in ('proof_core_v1.py','finite_basis_v1.py','semantic_families_v1.py')]
    source_paths += [ROOT/'reference'/name for name in ('qualification_v1.py','receptor_family_checker_v1.py','cluster_verifier_v3.py')]
    source_paths += [ROOT/'upstream'/name for name in core.PINS]
    def pins():
        return [{'path':str(path),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()} for path in source_paths]
    before = pins(); started = time.perf_counter()
    try:
        case = fixture(); core.write(output/'declared-fixture.json',case)
        modules = core.load_modules(); compiled,generation = compile_case(case); depth = 8
        zero_checks = [modules['independent_fol_checker_v1'].check(compiled['theory'],[zero['line']],zero['line']['formula'],core.CHECK) for zero in compiled['zero_instances']]
        assert all(receipt['status']=='VERIFIED' for receipt in zero_checks)
        model,provider,factory,cat = core.make_catalogue(modules,compiled,generation,depth)
        factory_check = modules['growing_proof_verifier_v2'].verify_factory(compiled,generation,depth,model,factory,limits=core.AUDIT)
        assert factory_check['status']=='VERIFIED',factory_check
        control = modules['growing_proof_verifier_v2'].tree_control(compiled,depth,
            dict(max_depth=256,max_items=20000000,max_proof_lines=4096,max_states=200000,max_work=1000000000,wall_seconds=15))
        core.write(output/'automatic-donor-control.json',control)
        assert control['status']=='DERIVABLE',control
        positive = core.check_positive(modules,compiled,depth,control['details']['selected'])
        library = semantic.mine(positive['tree'],cat,maximum=6)
        assert library and len({f['id'] for f in library})==len(library)
        for family in library:
            assert 2<=core.pattern_size(family['pattern'])==family['size']<=6
            assert family['id']==core.sha([family['pattern'],family['semantic']])[:20]
            family['origins']=[case['id']]
        library.sort(key=lambda f:(-f['axiom_requirements'],-f['term_slots'],-f['size'],f['id']))
        instantiator = semantic.Instantiator(cat,library,per_family=4)
        by_site = {cat.decode_id(row['id'])[0]:row['id'] for row in positive['tree']['placements']}
        meter = core.Meter(90); tested=[]
        # Ancestor prefixes are reconstructed from the found proof, not written.
        for point in sorted(by_site,key=lambda s:(len(s),s))[:8]:
            selected = [cid for site,cid in sorted(by_site.items()) if len(site)<len(point) and point.startswith(site)]
            totals,marks = cat.values(selected,meter.tick)
            query = {'schema':'IP-current-tm-incident-query-v1','inventory_identity':factory['value']['identity'],
                     'point':point,'capacity':2,'totals':[[p,n] for p,n in sorted(totals.items())],
                     'marks':[[p,value] for p,value in sorted(marks.items())]}
            packet = provider(query,meter.tick)
            assert packet['complete'] is True
            legal = [row['id'] for row in packet['placements'] if row['id'] not in selected]
            fid = cat.fid[marks[point]]
            pool = instantiator.pool(point,fid,legal,selected,[],meter.tick,cap=16)
            for offered in pool:
                family = next(f for f in library if f['id']==offered['family'])
                proposal = {key:offered[key] for key in ('root_site','pattern','placements')}
                assert subject_match(cat,family,proposal,meter.tick)
                checked = verify(compiled,depth,selected,family,proposal)
                assert checked['status']=='VERIFIED',checked
                tested.append({'family':family,'proposal':proposal,'selected':selected,'receipt':checked})
        assert tested and any(t['proposal']['root_site']=='' for t in tested)
        assert any(t['proposal']['root_site']!='' for t in tested)
        def pairs(binding):
            return [(a,b) for a in binding for b in binding if a!=b]
        def rich(test):
            receipt=test['receipt']
            terms=[(a,b) for a,b in pairs(receipt['term_bindings']) if core.text(a[1])!=core.text(b[1])]
            symbols=[(a,b) for a,b in pairs(receipt['symbol_bindings']) if a[0]==b[0] and a[2]==b[2] and a[3]!=b[3]]
            return bool(terms and symbols and receipt['axiom_dependencies'])
        selected_test=next(t for t in tested if rich(t))
        family,proposal,prefix = selected_test['family'],selected_test['proposal'],selected_test['selected']
        receipt=selected_test['receipt']; results=[]
        def negative(name,changed_family=None,changed_proposal=None,changed_compiled=None,subject_expected=None):
            f=changed_family if changed_family is not None else family
            p=changed_proposal if changed_proposal is not None else proposal
            c=changed_compiled if changed_compiled is not None else compiled
            subject=None
            if subject_expected is not None:
                subject=subject_match(cat,f,p,meter.tick);assert subject is subject_expected
            checked=verify(c,depth,prefix,f,p)
            assert checked['status']=='REJECTED',(name,checked)
            results.append({'name':name,'expected':'REJECTED','receipt':checked,'subject_match':subject})
        terms=next((a,b) for a,b in pairs(receipt['term_bindings']) if core.text(a[1])!=core.text(b[1]))
        changed=copy.deepcopy(family)
        slot=next(n for n in nodes(changed['semantic']) if n[:2]==['term_slot',terms[0][0]])
        slot[1]=terms[1][0]
        negative('inconsistent-shared-term',changed_family=changed,subject_expected=False)
        symbols=next((a,b) for a,b in pairs(receipt['symbol_bindings']) if a[0]==b[0] and a[2]==b[2] and a[3]!=b[3])
        changed=copy.deepcopy(family)
        slot=next(n for n in nodes(changed['semantic']) if len(n)==4 and n[:3]==['symbol',symbols[0][0],symbols[0][1]])
        slot[2]=symbols[1][1]
        negative('inconsistent-shared-symbol',changed_family=changed,subject_expected=False)
        changed=copy.deepcopy(family);slot=next(n for n in nodes(changed['semantic']) if n and n[0]=='term_slot');slot[1]=True
        negative('boolean-term-slot-is-not-zero',changed_family=changed)
        changed=copy.deepcopy(family);slot=next(n for n in nodes(changed['semantic']) if n and n[0]=='term_slot');slot[:]=[0]
        negative('literal-zero-is-not-a-wildcard',changed_family=changed)
        changed=copy.deepcopy(family);slot=next(n for n in nodes(changed['semantic']) if n and n[0]=='symbol');slot[3]+=1
        negative('wrong-symbol-arity',changed_family=changed)
        changed=copy.deepcopy(family);del changed['semantic']['output']
        negative('missing-semantic-key',changed_family=changed)
        changed=copy.deepcopy(proposal);changed['placements'].pop()
        negative('missing-base-placement',changed_proposal=changed)
        changed=copy.deepcopy(proposal);changed['placements'].append(copy.deepcopy(changed['placements'][0]))
        negative('double-base-placement',changed_proposal=changed)
        foreign=copy.deepcopy(compiled);dependency=receipt['axiom_dependencies'][0]
        del foreign['theory']['axioms'][dependency['name']]
        negative('foreign-current-Gamma-axiom',changed_compiled=foreign)
        # Different slot IDs MAY alias the same concrete term; split one reuse.
        changed=copy.deepcopy(family)
        uses=[n for n in nodes(changed['semantic']) if n and n[0]=='term_slot']
        repeated=next(slot for slot in {n[1] for n in uses} if sum(n[1]==slot for n in uses)>=2)
        next(n for n in uses if n[1]==repeated)[1]=max(n[1] for n in uses)+1
        alias=verify(compiled,depth,prefix,changed,proposal)
        assert alias['status']=='VERIFIED' and subject_match(cat,changed,proposal,meter.tick),alias
        assert any(slot==0 for test in tested for slot,value in test['receipt']['term_bindings'])
        after=pins();assert before==after
        result={'schema':'RF-separate-qualification-v1','status':'PASS','case':case,'depth':depth,
                'compiled':compiled,'generation':generation,'zero_checks':zero_checks,'factory_check':factory_check,
                'automatic_control':control,'positive':positive,'mined_families':library,
                'checked_proposals':tested,'negative_mutants':results,'alias_positive':alias,
                'summary':{'automatic_donor_verified':True,'families':len(library),'checked_proposals':len(tested),
                           'root_proposals':sum(t['proposal']['root_site']=='' for t in tested),
                           'child_proposals':sum(t['proposal']['root_site']!='' for t in tested),
                           'negative_mutants':len(results),'alias_accepted':True,'slot_zero_accepted':True},
                'source_before':before,'source_after':after,'seconds':time.perf_counter()-started,
                'scope':'Automatically solved independent API fixture only; no prospective/held-out data read and no qualification proof/library may enter the study inventory.'}
        ref=core.write(output/'qualification-result.json.gz',result)
        core.write(output/'completion.json',{'status':'PASS','result':ref,'summary':result['summary'],'seconds':result['seconds']})
        return ref
    except Exception as error:
        core.write(output/'failure.json',{'status':'FAILED_OR_UNKNOWN_NOT_ADMITTED','type':type(error).__name__,
                   'reason':str(error),'seconds':time.perf_counter()-started,'source_before':before,'source_after':pins()})
        raise


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--out',type=Path,default=None)
    print(json.dumps(run(parser.parse_args().out),sort_keys=True))
