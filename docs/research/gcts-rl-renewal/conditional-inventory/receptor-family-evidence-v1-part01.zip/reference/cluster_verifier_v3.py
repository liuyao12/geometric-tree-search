"""Independent bounded cluster expansion checker; inert stdlib-only Source.

VERIFIED means an exact legal partial cluster relative to the supplied audited
finite compiled catalogue. It is not a logical kernel or extension certificate.
No provider, solver, archived helper, IO, randomness or process API is used.
"""
import json
import math

VERSION = 'RF-INDEPENDENT-CLUSTER-VERIFIER-v3'
BOUNDS = {'formulas': 16000, 'definitions': 200000, 'selected': 4096,
          'new_placements': 6, 'proposal_records': 8, 'tree_depth': 32, 'json_nodes': 5000000,
          'json_depth': 128, 'string_length': 1048576, 'string_units': 67108864}
ZERO_RULES = frozenset(('axiom', 'instantiate', 'refl', 'tautology', 'eq_subst', 'distribute'))


class _Refusal(Exception):
    def __init__(self, status, reason):
        self.status, self.reason = status, reason


def _need(condition, reason):
    if not condition:
        raise _Refusal('REJECTED', reason)


def _bound(condition, reason):
    if not condition:
        raise _Refusal('UNKNOWN', reason)


def _text(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=True,
                      separators=(',', ':'), allow_nan=False)


def _fields(value, names, reason):
    _need(type(value) is dict and set(value) == set(names)
          and all(type(k) is str for k in value), reason)


def _json(value):
    """Bound native JSON traversal, including unused catalogue metadata."""
    active, nodes, strings = set(), 0, 0
    stack = [(value, 0, False)]
    while stack:
        item, depth, leaving = stack.pop()
        if leaving:
            active.remove(id(item))
            continue
        nodes += 1
        _bound(nodes <= BOUNDS['json_nodes'] and depth <= BOUNDS['json_depth'], 'JSON_BOUND')
        kind = type(item)
        if kind is str:
            strings += len(item)
            _bound(len(item) <= BOUNDS['string_length'] and strings <= BOUNDS['string_units'], 'STRING_BOUND')
        elif kind is int:
            _bound(item.bit_length() <= 256, 'INTEGER_BOUND')
        elif kind is float:
            _need(math.isfinite(item), 'NONFINITE_JSON')
        elif item is None or kind is bool:
            pass
        else:
            _need(kind in (list, dict), 'NATIVE_JSON_TYPE')
            _need(id(item) not in active, 'JSON_CYCLE')
            _bound(nodes + len(stack) + 1 + len(item) * (2 if kind is dict else 1) <= BOUNDS['json_nodes'], 'JSON_BOUND')
            active.add(id(item)); stack.append((item, depth, True))
            if kind is dict:
                _need(all(type(k) is str for k in item), 'JSON_KEY')
                for key, child in item.items():
                    stack.append((key, depth + 1, False)); stack.append((child, depth + 1, False))
            else:
                stack.extend((child, depth + 1, False) for child in item)


def _name(value):
    _need(type(value) is str and 1 <= len(value) <= 64
          and all(32 <= ord(c) <= 126 for c in value), 'SYMBOL_NAME')
    return value


def _term(value, functions):
    _need(type(value) is list and bool(value) and type(value[0]) is str, 'TERM')
    if value[0] == 'var' and len(value) == 2:
        return {_name(value[1])}
    _need(value[0] == 'fun' and len(value) == 3, 'TERM_SHAPE')
    name = _name(value[1]); args = value[2]
    _need(type(args) is list and name in functions and len(args) == functions[name], 'FUNCTION_ARITY')
    return set().union(*(_term(child, functions) for child in args))


def _formula(value, functions, predicates):
    _need(type(value) is list and bool(value) and type(value[0]) is str, 'FORMULA')
    tag = value[0]
    if tag == 'bot' and len(value) == 1:
        return set()
    if tag == 'eq' and len(value) == 3:
        return _term(value[1], functions) | _term(value[2], functions)
    if tag == 'pred' and len(value) == 3:
        name = _name(value[1]); args = value[2]
        _need(type(args) is list and name in predicates and len(args) == predicates[name], 'PREDICATE_ARITY')
        return set().union(*(_term(child, functions) for child in args))
    if tag == 'all' and len(value) == 3:
        return _formula(value[2], functions, predicates) - {_name(value[1])}
    if tag == 'not' and len(value) == 2:
        return _formula(value[1], functions, predicates)
    _need(tag in ('imp', 'and', 'or') and len(value) == 3, 'FORMULA_SHAPE')
    return _formula(value[1], functions, predicates) | _formula(value[2], functions, predicates)


def _catalogue(compiled):
    _fields(compiled, ('schema', 'version', 'theory', 'goal', 'goal_id', 'profile', 'logical_basis',
                       'zero_instances', 'mp_index', 'gen_index', 'costs', 'scope'), 'COMPILED_FIELDS')
    _need(compiled['schema'] == 'V-interned-Hilbert8-basis-v1'
          and compiled['version'] == 'V-INTERNED-FINITE-HILBERT8-v1', 'COMPILED_IDENTITY')
    theory = compiled['theory']; _fields(theory, ('functions', 'predicates', 'axioms'), 'THEORY_FIELDS')
    for signature in (theory['functions'], theory['predicates']):
        _need(type(signature) is dict, 'SIGNATURE')
        for symbol, arity in signature.items():
            _name(symbol); _need(type(arity) is int and arity >= 0, 'SIGNATURE_ARITY')
    _need(type(theory['axioms']) is dict, 'THEORY_AXIOMS')
    for name, value in theory['axioms'].items():
        _name(name); _need(not _formula(value, theory['functions'], theory['predicates']), 'OPEN_THEORY_AXIOM')
    basis = compiled['logical_basis']
    _fields(basis, ('instantiation_terms', 'terms', 'variables', 'formulas', 'colors', 'templates', 'hole', 'stages'), 'BASIS_FIELDS')
    forms, colors = basis['formulas'], basis['colors']
    _need(type(forms) is list and type(colors) is list and len(forms) == len(colors), 'FORMULA_COLORS')
    _bound(len(forms) <= BOUNDS['formulas'], 'FORMULA_BOUND')
    for value in forms:
        _formula(value, theory['functions'], theory['predicates'])
    _need(all(type(color) is str and color == _text(value) for value, color in zip(forms, colors)), 'LITERAL_COLORS')
    _need(colors == sorted(colors) and len(set(colors)) == len(colors), 'FORMULA_ORDER')
    goal = compiled['goal_id']
    _need(type(goal) is int and 0 <= goal < len(forms), 'GOAL_ID')
    _need(_text(compiled['goal']) == colors[goal], 'GOAL_BINDING')
    lookup = {color: i for i, color in enumerate(colors)}
    mp, gen = [], []
    for i, value in enumerate(forms):
        if value[0] == 'imp':
            a, b = lookup.get(_text(value[1])), lookup.get(_text(value[2]))
            if a is not None and b is not None:
                mp.append([i, a, b])
        if value[0] == 'all':
            body = lookup.get(_text(value[2]))
            if body is not None:
                gen.append([i, body, value[1]])
    _need(type(compiled['mp_index']) is list and type(compiled['gen_index']) is list
          and _text(mp) == _text(compiled['mp_index']) and _text(gen) == _text(compiled['gen_index']), 'COMPLETE_TYPED_INDICES')
    zeros = compiled['zero_instances']; _need(type(zeros) is list, 'ZERO_INSTANCES')
    _bound(len(zeros) + len(mp) + len(gen) <= BOUNDS['definitions'], 'DEFINITION_BOUND')
    definitions = {}
    for i, zero in enumerate(zeros):
        _fields(zero, ('id', 'rule', 'formula_id', 'line'), 'ZERO_FIELDS')
        fid, rule, line = zero['formula_id'], zero['rule'], zero['line']
        _need(type(zero['id']) is str and zero['id'] == 'i' + str(i)
              and type(rule) is str and rule in ZERO_RULES and type(fid) is int
              and 0 <= fid < len(forms) and type(line) is dict, 'ZERO_BINDING')
        _need(line.get('rule') == rule and _text(line.get('formula')) == colors[fid], 'ZERO_LINE_BINDING')
        definitions[_text(['zero', zero['id']])] = ('ZERO', fid, (), rule)
    for head, a, out in mp:
        definitions[_text(['mp', head, a, out])] = ('MP', out, (a, head), None)
    for head, body, variable in gen:
        definitions[_text(['gen', head, body, variable])] = ('GEN', head, (body,), None)
    return colors, definitions, goal


def _site(value, depth):
    _need(type(value) is str and all(c in '01' for c in value), 'BINARY_SITE')
    _need(len(value) <= depth, 'PLACEMENT_DEPTH')
    return value


def _candidate(cid, depth, colors, definitions):
    _need(type(cid) is str, 'CANDIDATE_ID_TYPE')
    _bound(len(cid) <= 4096, 'CANDIDATE_ID_BOUND')
    try:
        value = json.loads(cid)
    except (ValueError, RecursionError):
        raise _Refusal('REJECTED', 'CANDIDATE_ID_JSON')
    _need(type(value) is list and len(value) == 2 and all(type(x) is str for x in value), 'CANDIDATE_ID_SHAPE')
    site, identity = value; _site(site, depth)
    _need(_text(value) == cid and identity in definitions, 'CANONICAL_ALLOWED_CANDIDATE_ID')
    definition = definitions[identity]; _, out, premises, _ = definition
    _need(not premises or len(site) < depth, 'PREMISE_DEPTH')
    points = [site] + [site + str(i) for i in range(len(premises))]
    expected = {'id': cid, 't': [[point, 1] for point in points],
                'm': [[point, colors[fid]] for point, fid in zip(points, (out,) + premises)]}
    return site, definition, expected


def _add(row, totals, marks):
    for point, units in row['t']:
        totals[point] = totals.get(point, 0) + units
        _need(totals[point] <= 2, 'CAPACITY_CONFLICT')
    for point, value in row['m']:
        _need(point not in marks or marks[point] == value, 'MARKING_CONFLICT')
        marks[point] = value


def _pattern(pattern, site, bindings):
    _need(type(pattern) is list and bool(pattern) and type(pattern[0]) is str, 'PATTERN_NODE')
    _bound(len(bindings) < BOUNDS['proposal_records'], 'PATTERN_BOUND')
    tag = pattern[0]
    if tag == 'MP':
        _need(len(pattern) == 3, 'MP_PATTERN_ARITY'); children = pattern[1:]
    elif tag == 'GEN':
        _need(len(pattern) == 2, 'GEN_PATTERN_ARITY'); children = pattern[1:]
    else:
        _need(len(pattern) == 1 and tag.startswith('ZERO:') and tag[5:] in ZERO_RULES, 'ZERO_PATTERN_RULE')
        children = []
    bindings[site] = tag
    for i, child in enumerate(children):
        if child is not None:
            _pattern(child, site + str(i), bindings)


def verify(compiled, depth, selected, proposal):
    """Check an attached exact 2..6-placement expansion without changing inputs."""
    try:
        _need(type(depth) is int and depth >= 0, 'DEPTH_TYPE_OR_RANGE')
        _bound(depth <= BOUNDS['tree_depth'], 'DEPTH_BOUND')
        _need(type(selected) is list, 'SELECTED_LIST')
        _bound(len(selected) <= BOUNDS['selected'], 'SELECTED_BOUND')
        _fields(proposal, ('root_site', 'pattern', 'placements'), 'PROPOSAL_FIELDS')
        _need(type(proposal['placements']) is list, 'PLACEMENT_LIST')
        count = len(proposal['placements'])
        _bound(count <= BOUNDS['proposal_records'], 'PROPOSAL_BOUND')
        _need(count >= 2, 'CLUSTER_TOO_SMALL')
        _need(count <= BOUNDS['new_placements'], 'CURRENT_CLUSTER_SIZE_LIMIT')
        _json(compiled); _json(selected); _json(proposal)
        colors, definitions, goal = _catalogue(compiled)
        totals, marks = {'': 1}, {'': colors[goal]}
        current, ids = {}, set()
        for cid in selected:
            site, definition, row = _candidate(cid, depth, colors, definitions)
            _need(cid not in ids and site not in current, 'SELECTED_DUPLICATE')
            ids.add(cid); current[site] = definition; _add(row, totals, marks)
        for site in current:
            _need(site == '' or site[:-1] in current
                  and int(site[-1]) < len(current[site[:-1]][2]), 'SELECTED_NOT_ROOT_CONNECTED')
        root = _site(proposal['root_site'], depth)
        _need(root in totals and totals[root] < 2, 'ROOT_NOT_LIVE_RECEPTOR')
        bindings = {}; _pattern(proposal['pattern'], root, bindings)
        proposed, rows, candidates = {}, [], set()
        aggregate_t, aggregate_m = {}, {}
        for supplied in proposal['placements']:
            _fields(supplied, ('id', 't', 'm'), 'PLACEMENT_FIELDS')
            site, definition, row = _candidate(supplied['id'], depth, colors, definitions)
            _need(_text(supplied) == _text(row), 'EXACT_BASE_PLACEMENT_BINDING')
            _need(row['id'] not in ids and row['id'] not in candidates and site not in proposed, 'NEW_PLACEMENT_DUPLICATE')
            candidates.add(row['id']); proposed[site] = (definition, row['id']); rows.append(row)
            _add(row, aggregate_t, aggregate_m)
        _need(set(proposed) == set(bindings) and root in proposed, 'PATTERN_PLACEMENT_COVERAGE')
        for site, tag in bindings.items():
            definition = proposed[site][0]
            actual = 'ZERO:' + definition[3] if definition[0] == 'ZERO' else definition[0]
            _need(tag == actual, 'PATTERN_NATIVE_RULE_BINDING')
            if site != root:
                _need(site[:-1] in proposed and int(site[-1]) < len(proposed[site[:-1]][0][2]), 'NO_POSITIVE_PARENT_CONTACT')
        current_totals = dict(totals)
        for row in rows:
            _add(row, totals, marks)
        boundary = [{'point': point, 'role': 'attachment' if point == root else 'open_receptor',
                     'current_t': current_totals.get(point, 0), 'cluster_t': units,
                     'combined_t': totals[point], 'mark': aggregate_m[point]}
                    for point, units in sorted(aggregate_t.items()) if units == 1]
        return {'status': 'VERIFIED', 'reason': 'EXACT_ATTACHED_PARTIAL_CLUSTER', 'version': VERSION,
                'root_site': root, 'root_candidate_id': proposed[root][1],
                'candidate_ids': sorted(candidates), 'new_placements': count, 'selected_count': len(selected),
                'boundary_points': boundary, 'open_receptors': [row['point'] for row in boundary if row['role'] == 'open_receptor'],
                'remaining_frontier': sorted(point for point, units in totals.items() if units < 2),
                'aggregate_t': [[point, units] for point, units in sorted(aggregate_t.items())],
                'aggregate_m': [[point, value] for point, value in sorted(aggregate_m.items())],
                'combined_point_count': len(totals), 'scope': 'Partial point legality and exact catalogue/pattern binding only; no extendibility or logical-kernel claim.'}
    except _Refusal as refusal:
        return {'status': refusal.status, 'reason': refusal.reason, 'version': VERSION}
