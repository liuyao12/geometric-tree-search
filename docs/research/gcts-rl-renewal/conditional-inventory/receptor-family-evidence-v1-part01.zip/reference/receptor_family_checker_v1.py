"""Independent receptor-family binding checker; inert Source.

Only the public base point-cluster verifier is delegated. No compiler, policy,
matcher, search or proposal constructor is imported. A family is guidance,
not a newly admitted logical axiom or universally valid theorem scheme.
"""
import json
import math
from cluster_verifier_v3 import verify as _verify_base

VERSION = 'RF-INDEPENDENT-RECEPTOR-FAMILY-CHECKER-v1'
BASE_SHA256 = 'e59d08f310f802c23d29c4c1759c19a78ff4c28b650af7fbb106e9ebcc3e2caf'
MAX_MEMBERS, MAX_DEPTH, MAX_AST_NODES, MAX_SLOT, MAX_ARITY = 6, 64, 20000, 1023, 64


class _Failure(Exception):
    def __init__(self, status, reason):
        self.status, self.reason = status, reason


def _need(condition, reason):
    if not condition:
        raise _Failure('REJECTED', reason)


def _limit(condition, reason):
    if not condition:
        raise _Failure('UNKNOWN', reason)


def _fields(value, names, reason):
    _need(type(value) is dict and all(type(k) is str for k in value)
          and set(value) == set(names), reason)


def _text(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(',', ':'), allow_nan=False)


def _json_guard(value):
    active, count, units = set(), 0, 0
    stack = [(value, 0, False)]
    while stack:
        item, depth, leaving = stack.pop()
        if leaving:
            active.remove(id(item)); continue
        count += 1
        _limit(count + len(stack) <= 100000 and depth <= 128, 'FAMILY_JSON_RESOURCE_BOUND')
        kind = type(item)
        if kind is str:
            units += len(item); _limit(units <= 2097152, 'FAMILY_STRING_RESOURCE_BOUND')
        elif kind is int:
            _limit(item.bit_length() <= 256, 'FAMILY_INTEGER_RESOURCE_BOUND')
        elif kind is float:
            _need(math.isfinite(item), 'NONFINITE_FAMILY_JSON')
        elif item is None or kind is bool:
            pass
        else:
            _need(kind in (list, dict) and id(item) not in active, 'FAMILY_NATIVE_JSON_OR_CYCLE')
            _limit(count + len(stack) + 1 + len(item) * (2 if kind is dict else 1) <= 100000, 'FAMILY_JSON_RESOURCE_BOUND')
            active.add(id(item)); stack.append((item, depth, True))
            if kind is dict:
                _need(all(type(key) is str for key in item), 'FAMILY_JSON_KEYS')
                for key, child in item.items():
                    stack.append((key, depth + 1, False)); stack.append((child, depth + 1, False))
            else:
                stack.extend((child, depth + 1, False) for child in item)


class _Match:
    def __init__(self, theory):
        self.theory = theory
        self.terms, self.symbols, self.count = {}, {}, 0

    def tick(self, depth):
        self.count += 1
        _limit(depth <= MAX_DEPTH and self.count <= MAX_AST_NODES, 'TEMPLATE_AST_RESOURCE_BOUND')

    def slot(self, value):
        _need(type(value) is int and value >= 0, 'SLOT_NATIVE_INTEGER')
        _limit(value <= MAX_SLOT, 'SLOT_RESOURCE_BOUND')
        return value

    def symbol(self, template, actual, kind, arity, depth):
        self.tick(depth)
        _need(type(template) is list and len(template) == 4
              and type(template[0]) is str and template[0] == 'symbol'
              and type(template[1]) is str and template[1] == kind, 'TYPED_SYMBOL_TEMPLATE')
        slot = self.slot(template[2]); declared = template[3]
        _need(type(declared) is int and declared >= 0, 'SYMBOL_ARITY_TYPE')
        _limit(declared <= MAX_ARITY, 'SYMBOL_ARITY_RESOURCE_BOUND')
        _need(declared == arity and (kind != 'variable' or declared == 0), 'SYMBOL_ARITY_BINDING')
        _need(type(actual) is str and 1 <= len(actual) <= 64
              and all(32 <= ord(char) <= 126 for char in actual), 'ACTUAL_SYMBOL_NAME')
        if kind != 'variable':
            signature = self.theory['functions' if kind == 'function' else 'predicates']
            _need(actual in signature and type(signature[actual]) is int and signature[actual] == arity, 'ACTUAL_SYMBOL_SIGNATURE')
        key, binding = (kind, slot), (declared, actual)
        _need(key not in self.symbols or self.symbols[key] == binding, 'SHARED_SYMBOL_BINDING')
        self.symbols[key] = binding

    def actual_term(self, actual, depth):
        self.tick(depth)
        _need(type(actual) is list and bool(actual) and type(actual[0]) is str, 'ACTUAL_TERM')
        if actual[0] == 'var':
            _need(len(actual) == 2 and type(actual[1]) is str, 'ACTUAL_VARIABLE')
        else:
            _need(actual[0] == 'fun' and len(actual) == 3 and type(actual[1]) is str
                  and type(actual[2]) is list and actual[1] in self.theory['functions']
                  and len(actual[2]) == self.theory['functions'][actual[1]], 'ACTUAL_FUNCTION_TERM')
            for child in actual[2]:
                self.actual_term(child, depth + 1)

    def term(self, template, actual, depth=0):
        self.tick(depth)
        _need(type(template) is list and bool(template) and type(template[0]) is str, 'TERM_TEMPLATE')
        if template[0] == 'term_slot':
            _need(len(template) == 2, 'TERM_SLOT_SHAPE')
            slot = self.slot(template[1]); self.actual_term(actual, depth + 1)
            value = _text(actual)
            _need(slot not in self.terms or self.terms[slot] == value, 'SHARED_TERM_BINDING')
            self.terms[slot] = value
        elif template[0] == 'var':
            _need(len(template) == 2 and type(actual) is list and len(actual) == 2 and actual[0] == 'var', 'VARIABLE_TEMPLATE_SHAPE')
            self.symbol(template[1], actual[1], 'variable', 0, depth + 1)
        else:
            _need(template[0] == 'fun' and len(template) == 3 and type(template[2]) is list
                  and type(actual) is list and len(actual) == 3 and actual[0] == 'fun'
                  and type(actual[2]) is list and len(template[2]) == len(actual[2]), 'FUNCTION_TEMPLATE_SHAPE')
            self.symbol(template[1], actual[1], 'function', len(actual[2]), depth + 1)
            for child, concrete in zip(template[2], actual[2]):
                self.term(child, concrete, depth + 1)

    def formula(self, template, actual, depth=0):
        self.tick(depth)
        _need(type(template) is list and bool(template) and type(template[0]) is str
              and type(actual) is list and bool(actual) and template[0] == actual[0], 'FORMULA_TEMPLATE_TAG')
        tag = template[0]
        if tag == 'bot':
            _need(len(template) == len(actual) == 1, 'BOTTOM_TEMPLATE')
        elif tag == 'eq':
            _need(len(template) == len(actual) == 3, 'EQUALITY_TEMPLATE')
            self.term(template[1],actual[1],depth+1); self.term(template[2],actual[2],depth+1)
        elif tag == 'pred':
            _need(len(template) == len(actual) == 3 and type(template[2]) is list
                  and type(actual[2]) is list and len(template[2]) == len(actual[2]), 'PREDICATE_TEMPLATE')
            self.symbol(template[1],actual[1],'predicate',len(actual[2]),depth+1)
            for child, concrete in zip(template[2],actual[2]):
                self.term(child,concrete,depth+1)
        elif tag == 'all':
            _need(len(template) == len(actual) == 3, 'UNIVERSAL_TEMPLATE')
            self.symbol(template[1],actual[1],'variable',0,depth+1)
            self.formula(template[2],actual[2],depth+1)
        elif tag == 'not':
            _need(len(template) == len(actual) == 2, 'NEGATION_TEMPLATE')
            self.formula(template[1],actual[1],depth+1)
        else:
            _need(tag in ('imp','and','or') and len(template) == len(actual) == 3, 'BINARY_FORMULA_TEMPLATE')
            self.formula(template[1],actual[1],depth+1); self.formula(template[2],actual[2],depth+1)


def verify(compiled, depth, selected, family, proposal):
    """Bind one semantic family, then retain the concrete base legality receipt."""
    try:
        _need(type(family) is dict and all(type(key) is str for key in family)
              and {'id','pattern','semantic','origins'} <= set(family), 'FAMILY_REQUIRED_FIELDS')
        _need(type(family['id']) is str and 1 <= len(family['id']) <= 256
              and type(family['origins']) is list, 'FAMILY_ID_OR_ORIGINS')
        _json_guard(family)
        base = _verify_base(compiled,depth,selected,proposal)
        if base['status'] != 'VERIFIED':
            return {'status':base['status'],'reason':'BASE_'+base['reason'],'version':VERSION,'base':base}
        _need(_text(family['pattern']) == _text(proposal['pattern']), 'FAMILY_NATIVE_PATTERN_BINDING')
        forms = compiled['logical_basis']['formulas']
        zeros = {zero['id']:zero for zero in compiled['zero_instances']}
        mp = {_text(row) for row in compiled['mp_index']}
        gen = {_text(row) for row in compiled['gen_index']}
        by_site, axioms = {}, []
        for placement in proposal['placements']:
            value = json.loads(placement['id']); site, identity = value
            code = json.loads(identity)
            _need(type(code) is list and bool(code) and type(code[0]) is str, 'DEFINITION_CODE')
            if code[0] == 'zero':
                _need(len(code) == 2 and type(code[1]) is str and code[1] in zeros, 'ZERO_DEFINITION_ID')
                zero = zeros[code[1]]; output, premises = zero['formula_id'], []
                native = 'ZERO:' + zero['rule']
                if zero['rule'] == 'axiom':
                    line = zero['line']; name = line.get('name')
                    gamma = compiled['theory']['axioms']
                    _need(type(name) is str and name in gamma
                          and _text(gamma[name]) == _text(forms[output]), 'AXIOM_NOT_IN_EXACT_CURRENT_GAMMA')
                    axioms.append({'site':site,'zero_id':zero['id'],'name':name,'formula_id':output})
            elif code[0] == 'mp':
                _need(len(code) == 4 and all(type(fid) is int for fid in code[1:])
                      and _text(code[1:]) in mp, 'MP_DEFINITION_INCIDENCE')
                head, antecedent, output = code[1:]; native, premises = 'MP', [antecedent,head]
                _need(_text(forms[head]) == _text(['imp',forms[antecedent],forms[output]]), 'MP_NATIVE_FORMULAS')
            else:
                _need(code[0] == 'gen' and len(code) == 4 and type(code[1]) is int
                      and type(code[2]) is int and type(code[3]) is str and _text(code[1:]) in gen, 'GEN_DEFINITION_INCIDENCE')
                output, body, variable = code[1:]; native, premises = 'GEN', [body]
                _need(_text(forms[output]) == _text(['all',variable,forms[body]]), 'GEN_NATIVE_FORMULAS')
            _need(site not in by_site, 'DUPLICATE_MEMBER_SITE')
            by_site[site] = {'site':site,'candidate_id':placement['id'],'native':native,
                             'output_id':output,'premise_ids':premises}
        match, visited = _Match(compiled['theory']), set()

        def node(semantic, pattern, site):
            _limit(len(visited) < MAX_MEMBERS, 'FAMILY_MEMBER_RESOURCE_BOUND')
            _fields(semantic,('native','output','premises','children'),'SEMANTIC_NODE_FIELDS')
            _need(site in by_site and site not in visited, 'SEMANTIC_MEMBER_SITE')
            actual = by_site[site]; visited.add(site)
            _need(type(semantic['native']) is str and semantic['native'] == actual['native'] == pattern[0], 'SEMANTIC_NATIVE_RULE')
            premises, children = semantic['premises'], semantic['children']
            arity = len(actual['premise_ids'])
            _need(type(premises) is list and type(children) is list and len(premises) == len(children) == arity
                  and len(pattern) == arity + 1, 'SEMANTIC_PREMISE_OR_CHILD_ARITY')
            match.formula(semantic['output'],forms[actual['output_id']])
            for i, (template, fid, child) in enumerate(zip(premises,actual['premise_ids'],children)):
                match.formula(template,forms[fid])
                _need((child is None) == (pattern[i+1] is None), 'SEMANTIC_OPEN_RECEPTOR_SHAPE')
                if child is not None:
                    node(child,pattern[i+1],site+str(i))
        node(family['semantic'],family['pattern'],proposal['root_site'])
        _need(visited == set(by_site), 'EXACT_SEMANTIC_MEMBER_COVERAGE')
        return {'status':'VERIFIED','reason':'SHARED_TYPED_BINDING_AND_EXACT_BASE_CLUSTER','version':VERSION,
                'family_id':family['id'],'root_site':proposal['root_site'],
                'term_bindings':[[slot,json.loads(value)] for slot,value in sorted(match.terms.items())],
                'symbol_bindings':[[kind,slot,arity,name] for (kind,slot),(arity,name) in sorted(match.symbols.items())],
                'members':[by_site[site] for site in sorted(by_site)],'axiom_dependencies':axioms,'base':base,
                'scope':'Concrete family matching and base partial point legality only. Slot aliases allowed; repeated bindings exact. No new logical axiom, parametric theorem, extension or proof-search claim. Native zero truth/final proofs remain separately kernel-checked.'}
    except _Failure as failure:
        return {'status':failure.status,'reason':failure.reason,'version':VERSION}
