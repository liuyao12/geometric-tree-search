"""Passive RF report projection. Standard library only; no scientific imports."""
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LANES = ['LEXICAL_GCTS', 'SEM_UNIFORM_GCTS', 'SEM_HEURISTIC_GCTS', 'RL_SHAPE_GCTS',
         'RL_BINDING_GCTS', 'RL_BINDING_LEADER_ONLY_GCTS', 'CLUSTER_DFS_CONTROL', 'DP_CONTROL']
NAMES = dict(zip(LANES, ['Lexical GCTS', 'Uniform families', 'Binding heuristic',
    'RL shape only', 'RL binding', 'RL binding · leader only', 'Memoized cluster DFS', 'Dynamic programming']))


def pin(path, body=None):
    body = path.read_bytes() if body is None else body
    return dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def load(path):
    body = path.read_bytes()
    return json.loads(gzip.decompress(body) if path.suffix == '.gz' else body), pin(path, body)


def checked(answer):
    c = answer.get('checked')
    if c is None:
        return False
    if c['host_check']['status'] != 'VERIFIED' or c['tree_check']['status'] != 'VERIFIED':
        raise ValueError('A displayed proof lacks both independent checks')
    return True


def classification(answer):
    if checked(answer):
        return 'verified'
    return 'finite' if answer['status'] in ('UNSAT', 'NOT_DERIVABLE') else 'unknown'


def reason(answer):
    return (answer.get('reason') or answer.get('control', {}).get('reason')
            or answer.get('preparation', {}).get('refusal', {}).get('reason'))


def total(values):
    return sum(x for x in values if type(x) in (int, float))


def family_role(pattern, relative):
    for bit in relative:
        if pattern is None or int(bit) + 1 >= len(pattern):
            return 'unrecorded'
        pattern = pattern[int(bit) + 1]
    return pattern[0] if pattern else 'open'


def proposal_projection(record, family, selected):
    proposal = record['proposal']
    placements = proposal['placements']
    occupied = {json.loads(p['id'])[0] for p in placements}
    root = proposal['root_site']
    members, receptors = [], {}
    final_ids = [p['id'] for p in placements if p['id'] in selected]
    for placement in placements:
        site = json.loads(placement['id'])[0]
        marks = {point: json.loads(value) for point, value in placement['m']}
        premises = [point for point, units in placement['t'] if point != site and units]
        members.append(dict(id=placement['id'], site=site, formula=marks[site],
            native=family_role(family['pattern'], site[len(root):]),
            premises=premises, final=placement['id'] in selected))
        for point in premises:
            if point not in occupied:
                receptors[point] = marks[point]
    later = [a for a in record.get('adoptions', []) if not a['forced']
             and a['candidate'] in record.get('guided_later', []) and a['candidate'] in selected]
    output=members[0]['formula']
    nonreflexive=output[0]=='eq' and output[1]!=output[2]
    nonreflexive_receptors=sum(f[0]=='eq' and f[1]!=f[2] for f in receptors.values())
    productive=nonreflexive and nonreflexive_receptors>0 and all(f!=output for f in receptors.values())
    return dict(family=family['id'], origins=family['origins'], root=root,
        bindings=record.get('bindings', {}), members=members,
        receptors=[dict(site=p, formula=f) for p, f in sorted(receptors.items())],
        final_ids=final_ids, final_count=len(final_ids), fully_final=len(final_ids) == len(members),
        root_in_final=bool(members and members[0]['final']), later_nonforced_final_occurrences=len(later),
        model_probability=record.get('chosen_probability'),nonreflexive_output=nonreflexive,
        nonreflexive_equality_receptors=nonreflexive_receptors,nonrecursive_equality_transfer=productive,
        literal=dict(proposal=proposal, bindings=record.get('bindings'),
                     selected_before=record.get('selected_before'),
                     guided_later=record.get('guided_later'), adoptions=record.get('adoptions')))


def build():
    raw, input_pin = load(ROOT / 'data/results-v1.json.gz')
    if raw['schema'] != 'RF-receptor-family-study-v1':
        raise ValueError('Unexpected completed results schema')
    frozen = raw['cohort']
    cases = {c['id']: c for c in frozen['cases']}
    test = [c for c in frozen['cases'] if c['split'] == 'test']
    if len(test) != 16 or frozen['protocol']['lanes'] != LANES:
        raise ValueError('Expected complete prospective cohort and eight lanes')
    library = {f['id']: f for f in raw['library']}
    index = {}
    counts = {k: dict(verified=0, finite=0, unknown=0, search_seconds=0.,
        assurance_seconds=0., timed_positions=0, within_window=0) for k in LANES}
    transfer, transfer_keys = [], set()
    proof_candidates = {}
    rows = []
    for row in raw['results']:
        cid, lane, answer = row['case'], row['lane'], row['answer']
        if cid not in {c['id'] for c in test} or lane not in LANES or (cid, lane) in index:
            raise ValueError('Unexpected or duplicate held-out method position')
        index[cid, lane] = answer
        kind = classification(answer)
        if answer['status'] in ('SAT', 'DERIVABLE') and kind != 'verified':
            raise ValueError('Positive result lacks admitted certificate')
        counts[lane][kind] += 1
        for field in ('search_seconds', 'assurance_seconds'):
            counts[lane][field] += total([answer.get(field)])
        counts[lane]['timed_positions'] += type(answer.get('search_seconds')) in (int, float)
        counts[lane]['within_window'] += answer.get('within_search_window') is True
        rows.append(dict(case=cid, lane=lane, status=answer['status'], classification=kind,
            reason=reason(answer), search_seconds=answer.get('search_seconds'),
            assurance_seconds=answer.get('assurance_seconds'), allowed_seconds=answer.get('allowed_seconds'),
            within_search_window=answer.get('within_search_window'), stats=answer.get('stats'),
            recorded_proposals=len(answer.get('guidance', {}).get('proposals', []))))
        if kind != 'verified':
            continue
        check = answer['checked']
        if not check['proof'] or check['proof'][-1]['formula'] != cases[cid]['problem']['goal']:
            raise ValueError('Displayed proof is not bound to the frozen goal')
        selected = set(check['tree']['selected'])
        proposals = answer.get('guidance', {}).get('proposals', [])
        receipts = answer.get('family_checks', [])
        if len(proposals) != len(receipts) or any(r['status'] != 'VERIFIED' for r in receipts):
            raise ValueError('Chosen family expansions lack independent receipts')
        projected = []
        for ordinal, record in enumerate(proposals):
            family = library[record['family']]
            p = proposal_projection(record, family, selected)
            p['ordinal'] = ordinal
            if 'final_realized' in record and p['final_count'] != record['final_realized']:
                raise ValueError('Final family membership differs from the saved record')
            projected.append(p)
            pa_only = bool(family['origins']) and all(cases[o]['profile']['family'] == 'PA-addition-zero-fragment' for o in family['origins'])
            geometry = cases[cid]['profile']['family'] == 'one-sorted-incidence-fragment'
            if pa_only and geometry and p['final_count'] >= 2:
                key = (cid, lane, family['id'], tuple(sorted(p['final_ids'])))
                transfer_keys.add(key)
                transfer.append(dict(case=cid, lane=lane, family=family['id'], ordinal=ordinal,
                    final_count=p['final_count'], requested=len(p['members']), fully_final=p['fully_final'],
                    nonreflexive_output=p['nonreflexive_output'],nonrecursive_equality_transfer=p['nonrecursive_equality_transfer'],
                    root_in_final=p['root_in_final'], later_nonforced_final_occurrences=p['later_nonforced_final_occurrences']))
        projected.sort(key=lambda p: (p['nonrecursive_equality_transfer'],p['nonreflexive_output'],p['fully_final'], p['final_count'], p['later_nonforced_final_occurrences']), reverse=True)
        demos = projected[:2]
        cross = [p for p in projected if any(t['case'] == cid and t['lane'] == lane and t['ordinal'] == p['ordinal'] for t in transfer)]
        if cross and cross[0] not in demos:
            demos.append(cross[0])
        proof_candidates[cid, lane] = dict(lane=lane, proof=check['proof'],
            site_to_line=check['tree']['site_to_line'], selected=check['tree']['selected'],
            checks=dict(host=check['host_check'], tree=check['tree_check']),
            proposals=demos, recorded_proposals=len(proposals))
    if set(index) != {(c['id'], k) for c in test for k in LANES}:
        raise ValueError('Missing held-out positions; no fabricated outcomes are inserted')
    priority = ['RL_BINDING_GCTS', 'DP_CONTROL', 'CLUSTER_DFS_CONTROL', 'RL_SHAPE_GCTS',
                'SEM_HEURISTIC_GCTS', 'SEM_UNIFORM_GCTS', 'LEXICAL_GCTS', 'RL_BINDING_LEADER_ONLY_GCTS']
    readers = []
    for c in test:
        available = [k for k in priority if (c['id'], k) in proof_candidates]
        chosen = available[:1]
        demonstrations = [t for t in transfer if t['case'] == c['id']]
        demonstrations.sort(key=lambda t: (t['nonrecursive_equality_transfer'],t['nonreflexive_output'],t['fully_final'], t['root_in_final'],
                             t['later_nonforced_final_occurrences'], t['final_count']), reverse=True)
        if demonstrations and demonstrations[0]['lane'] not in chosen:
            chosen.append(demonstrations[0]['lane'])
        readers.append(dict(case=c, proofs=[proof_candidates[c['id'], k] for k in chosen]))
    qualification, qualification_pin = load(ROOT / 'qualification-run-v1/completion.json')
    if qualification['status'] != 'PASS':
        raise ValueError('Qualification is not PASS')
    donor_path = ROOT / 'data/donors-v1.json.gz'
    donor_cost = None
    if donor_path.is_file():
        donors, donor_pin = load(donor_path)
        donor_cost = dict(search_and_assurance_seconds=total(d.get('answer', {}).get('checked_total_seconds') for d in donors),
                          recorded_cases=len(donors), source=donor_pin,
                          scope='Sum of recorded donor search and assurance; family mining time is not separately recorded.')
    summary = dict(schema='RF-passive-reader-summary-v1', input=input_pin, names=NAMES,
        protocol=frozen['protocol'], counts=counts, rows=rows, readers=readers,
        library=[dict(id=f['id'], pattern=f['pattern'], output=f['semantic']['output'],
            premises=f['semantic']['premises'], origins=f['origins'], size=f['size'],
            open_receptors=f['open_receptors'], axiom_requirements=f['axiom_requirements'], term_slots=f['term_slots'])
            for f in raw['library']],
        transfer=dict(criterion='PA-only-origin proposal occurrences with at least two exact member IDs in a checked final incidence proof; partial overlaps are not full-cluster realizations.',
            occurrences=len(transfer), distinct_case_lane_family_member_sets=len(transfer_keys),
            full_occurrences=sum(t['fully_final'] for t in transfer),
            nonreflexive_occurrences=sum(t['nonreflexive_output'] for t in transfer),
            full_nonrecursive_equality_occurrences=sum(t['fully_final'] and t['nonrecursive_equality_transfer'] for t in transfer),
            root_present_occurrences=sum(t['root_in_final'] for t in transfer), records=transfer),
        costs=dict(driver_seconds=raw['total_seconds'], preparation=raw['preparation'],
            preparation_seconds=total(x['seconds'] for x in raw['preparation']),
            training=raw['training'], donor=donor_cost,
            evaluation_search_seconds=total(r['search_seconds'] for r in rows),
            evaluation_assurance_seconds=total(r['assurance_seconds'] for r in rows)),
        qualification=qualification, qualification_source=qualification_pin,
        environment=raw['environment'], source_pins=frozen['source_pins'],
        projection_scope='All held-out outcomes; one representative checked proof per case, preferring RL binding then conventional controls, plus a selected cross-domain demonstration where available. Up to three representative recorded proposals per displayed proof. Full literal records and all certificates remain in the evidence archive.')
    data = json.dumps(summary, ensure_ascii=True, sort_keys=True, separators=(',', ':'), allow_nan=False)
    html = TEMPLATE.replace('__DATA__', data.replace('<', '\\u003c').replace('&', '\\u0026'))
    output = ROOT / 'report'
    with (output / 'results-summary-v1.json').open('x') as handle:
        handle.write(data + '\n')
    with (output / 'receptor-families-v1.html').open('x') as handle:
        handle.write(html)
    print(json.dumps([pin(output / name) for name in ('results-summary-v1.json', 'receptor-families-v1.html')], sort_keys=True))


TEMPLATE = r'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Receptor-bound families · GCTS research</title>
<script>window.MathJax={tex:{inlineMath:[['\\(','\\)']],displayMath:[['\\[','\\]']]},options:{skipHtmlTags:['script','noscript','style','textarea','pre','code']}};</script><script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-svg.js"></script>
<style>:root{font:16px/1.6 system-ui,sans-serif;color:#203443;background:#f1f5f7;--base:#28789b;--binding:#8553a1;--ok:#278365}*{box-sizing:border-box}body{margin:0}main{max-width:1280px;margin:auto;padding:34px 24px 70px}h1{font-size:clamp(32px,5vw,52px);line-height:1.12;max-width:22ch}h2{font-size:25px;line-height:1.3}h3{font-size:18px}.eyebrow{text-transform:uppercase;font-size:12px;letter-spacing:.07em;font-weight:750;color:#567080}.lede{font-size:19px;max-width:80ch}a{color:#16658b}.panel{padding:24px;margin:22px 0;background:white;border:1px solid #d4e0e7;border-radius:12px;min-width:0}.finding{border-left:5px solid var(--ok)}.scope{border-left:5px solid #bd852d;background:#fffdf7}.muted,.english{color:#536d7c}.scroll,.formula{max-width:100%;overflow-x:auto}.formula{padding:5px 0;overflow-y:hidden}table{border-collapse:collapse;width:100%;font-size:13px}td,th{text-align:left;padding:10px;vertical-align:top;border-bottom:1px solid #dbe5eb}th{background:#edf4f7}.badge{font:700 11px/1.5 ui-monospace,monospace;padding:3px 6px;border-radius:4px;display:inline-block;background:#fff0cf;color:#7a581d}.verified{background:#ddf0e5;color:#236448}.finite{background:#ece5f5;color:#68438a}.controls,.metrics,.legend{display:flex;gap:13px;flex-wrap:wrap;align-items:end}label{display:flex;flex-direction:column;gap:5px;font-weight:650;max-width:100%}select,button{font:inherit;border:1px solid #a5b8c5;background:white;border-radius:6px;padding:8px;max-width:100%}button{cursor:pointer}.metric{padding:12px 15px;background:#f3f8fa;border:1px solid #dce5eb;border-radius:7px}.metric strong{display:block;font-size:22px}.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(310px,1fr));gap:12px}.card{padding:16px;border:1px solid #d4e0e8;border-radius:8px;min-width:0}.diagram{overflow:auto;background:#f7fafc;border:1px solid #dce5eb;border-radius:7px}.diagram svg{display:block;margin:auto}.line{display:grid;grid-template-columns:72px minmax(0,1fr);gap:16px;border-top:1px solid #dbe5eb;padding:18px 0;scroll-margin-top:15px}.line.highlight{background:#fff6dc}.glyph{width:62px;height:62px;border:3px solid var(--base);background:#f0f7fb;display:flex;align-items:center;justify-content:center;font:10px/1.3 ui-monospace,monospace;text-align:center;position:relative;padding:4px}.glyph:before{content:"";width:13px;height:13px;border:2px solid white;border-radius:50%;background:var(--color);position:absolute;top:-8px;left:22px}.ports{display:flex;gap:8px;flex-wrap:wrap}.port{font-size:12px;border:2px solid var(--color)}.empty{border:1px dashed #a9bfcd;padding:17px;color:#536d7c}.dot{display:inline-block;width:12px;height:12px;border-radius:50%;background:var(--color);margin-right:4px}.legend{align-items:center;font-size:13px;margin:12px 0}code,pre{font:12px/1.5 ui-monospace,monospace;overflow-wrap:anywhere}pre{white-space:pre-wrap;background:#eef4f7;padding:14px;border-radius:6px}details{margin:15px 0}summary{cursor:pointer;font-weight:650}mjx-container{max-width:100%}.footer{font-size:13px;color:#536d7c}@media(max-width:700px){main{padding:20px 12px 50px}.panel{padding:16px}.line{grid-template-columns:52px minmax(0,1fr);gap:10px}.glyph{width:46px;height:46px;font-size:9px}.glyph:before{left:14px}.cards{grid-template-columns:1fr}}</style></head><body><main id="reader">
<div class="eyebrow">GCTS research · receptor-bound proof families</div><h1>Reusable families transfer; the binding policy is a separate test</h1><p class="lede">A family carries a shared environment for symbols and terms, fits a current receptor, and expands to primitive proof placements. Inspect what survived in checked proofs, alongside every held-out search outcome.</p><p><a href="raw-first-order-kernel-v1.html">Previous raw first-order kernel</a> · <a href="receptor-family-evidence-v1.html">Evidence and full records</a> · <a href="receptor-family-results-summary-v1.json">Reader data</a> · <a href="#proof-reader">Proof reader</a></p>
<section class="panel finding"><h2>What the experiment found</h2><div id="assessment"></div><div id="coverage" class="scroll"></div><div id="transfer-summary"></div></section>
<section class="panel scope"><h2>What was searched</h2><p>These are semantic point-proof-tree searches. Every displayed primitive first-order proof and every chosen concrete family expansion receives an independent check. Families guide continuation order; they do not remove primitive candidates or add logical axioms.</p><p>This study did not search a literal Wang grid or compile these new certificates into the preceding raw NAND checker and its fixed tile palette. Square icons below depict fixed proof roles and point markings. They do not show a newly solved Wang patch or evidence that physical tiling accelerates first-order search.</p><p>The arithmetic theory is the finite addition-zero fragment, without induction. Geometry is a one-sorted symbolic incidence fragment with an uninterpreted line function. These are not full PA or Hilbert geometry. Family templates are empirical proposals, not admitted universal lemmas.</p></section>
<section class="panel"><h2>Every held-out target and all eight methods</h2><p class="muted">Verified proofs, exhausted finite-basis searches and unknowns are distinct. The complete basis and fixed depth apply to every method. Timing is one sequential observation, not evidence of statistical or ATP superiority.</p><div id="results" class="scroll"></div></section>
<section class="panel" id="proof-reader"><h2>Read a found proof</h2><div class="controls"><label>Target<select id="case"></select></label><label>Recorded certificate<select id="proof-choice"></select></label><button id="download">Download exact literal proof</button></div><p id="proof-source"></p><div id="statement" class="formula"></div><details><summary>Closed hypotheses and display-name aliases</summary><div id="axioms"></div><pre id="aliases"></pre></details><p class="muted">The UI reverses each case’s recorded symbol renaming to display familiar names such as successor and addition. Downloads preserve the exact original literal ASTs and names. The reader includes representative checked certificates; all other certificates remain in the evidence archive.</p>
<h3>A recorded family instance</h3><label>Representative proposal<select id="proposal"></select></label><p id="proposal-status"></p><div class="legend"><span><i class="dot" style="--color:#278365"></i>Exact member in final proof</span><span><i class="dot" style="--color:#a68b64"></i>Requested member</span><span><i class="dot" style="--color:#8553a1"></i>Shared bindings</span></div><div id="proposal-diagram" class="diagram"></div><div id="bindings" class="scroll"></div><div id="receptors"></div><details><summary>Literal proposal and chronological records</summary><pre id="proposal-json"></pre></details><p class="muted">Final membership is not chronological adoption or an atomic macro. A shared ID in a final proof does not establish that the policy was necessary. Later nonforced ordering choices, when recorded, are counted separately.</p>
<h3>Proof lines</h3><div id="proof"></div></section>
<section class="panel"><h2>The frozen inventory</h2><p>Cards show native-rule compositions and their abstract result interfaces. Hollow receptors are later obligations. Term slots and typed symbol slots share one binding environment across a family. Full semantic trees are in the evidence; these cards are not additional axioms.</p><div class="controls"><label>Origins<select id="origin-filter"><option value="all">All origins</option><option value="pa">PA-origin families</option></select></label></div><p id="inventory-count"></p><div id="inventory" class="cards"></div></section>
<section class="panel"><h2>What to change next</h2><p>The saved scores show an active learned binding policy: all twelve binding coefficients are nonzero. At the same incidence receptor and within the same family, it scored a self-demanding instance above an available productive binding. Its positive weights for repeated output obligations and already marked formulas are a candidate explanation; one run does not establish causation.</p><p>Keep uniform selection, the fixed heuristic and dynamic programming as controls. The next learning experiment should value unresolved receptors, test recurrence handling on a fresh held-out cohort, and measure the benefit of certified failure reuse. This inventory was mined from conventional donor proofs; useful lemma discovery by RL remains an open objective.</p></section><section class="panel"><h2>Costs and qualification</h2><div id="cost-metrics" class="metrics"></div><div id="training" class="scroll"></div><p>Prepared-input search time includes a fresh index and matcher plus ordinary search and in-search proposal validation. Basis compilation, factory assurance and native zero-rule audits happen once per case outside that window. Independent final-proof and family assurance is post-search. Training time includes its episodes and checks. Donor mining, recording and other driver work remain in total elapsed time; they are not free inventory.</p><p id="qualification"></p><details><summary>Exact budget, preparation and provenance records</summary><pre id="provenance"></pre></details></section><p class="footer">Finite-basis evidence with complete held-out outcome reporting. The broader research program remains active.</p>
<script type="application/json" id="saved-data">__DATA__</script><script>
'use strict';const D=JSON.parse(document.getElementById('saved-data').textContent),$=id=>document.getElementById(id),esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));let C=null,P=null,Q=null,queue=Promise.resolve();const json=x=>JSON.stringify(x,null,2),seconds=x=>typeof x==='number'?x.toFixed(3)+' s':'not recorded',keys=Object.keys(D.names),badge=r=>'<span class="badge '+r.classification+'">'+esc(r.status)+'</span>';
function typeset(nodes){queue=queue.then(async()=>{if(window.MathJax?.typesetPromise){await MathJax.startup.promise;await MathJax.typesetPromise(nodes.filter(n=>n?.isConnected));}}).catch(e=>console.warn(e));}
function alias(s,kind){const m=C?.case?.renaming?.[kind]||{};return Object.keys(m).find(k=>m[k]===s)||s;}
function nm(s,kind){if(Array.isArray(s)&&s[0]==='symbol'){const letters={function:'f',predicate:'P',variable:'x'};return '\\mathsf{'+letters[s[1]]+'}_{'+s[2]+'}';}s=alias(s,kind);return '\\mathrm{'+String(s).replace(/[\\{}_#$%&]/g,c=>'\\'+c)+'}';}
function term(t){if(t[0]==='term_slot')return '\\tau_{'+t[1]+'}';if(t[0]==='var')return nm(t[1],'variable');const n=Array.isArray(t[1])?null:alias(t[1],'function');if(n==='zero'&&!t[2].length)return '0';if(n==='add'&&t[2].length===2)return '\\left('+term(t[2][0])+'+'+term(t[2][1])+'\\right)';return nm(t[1],'function')+(t[2].length?'\\left('+t[2].map(term).join(',')+'\\right)':'');}
function operand(f){const s=formula(f);return f[0]==='all'?'\\left('+s+'\\right)':s;}
function formula(f){switch(f[0]){case'eq':return term(f[1])+'='+term(f[2]);case'pred':return nm(f[1],'predicate')+(f[2].length?'\\left('+f[2].map(term).join(',')+'\\right)':'');case'all':return '\\forall '+nm(f[1],'variable')+'.\\;'+formula(f[2]);case'not':return '\\neg\\left('+formula(f[1])+'\\right)';case'bot':return '\\bot';default:return '\\left('+operand(f[1])+({imp:'\\rightarrow',and:'\\land',or:'\\lor'}[f[0]])+operand(f[2])+'\\right)';}}
function tw(t){if(t[0]==='var')return '\\('+term(t)+'\\)';const n=alias(t[1],'function');if(n==='zero'&&!t[2].length)return 'zero';if(n==='S'&&t[2].length===1)return 'the successor of '+tw(t[2][0]);if(n==='add'&&t[2].length===2)return 'the sum of '+tw(t[2][0])+' and '+tw(t[2][1]);return '\\('+term(t)+'\\)';}
function words(f){switch(f[0]){case'eq':return tw(f[1])+' equals '+tw(f[2]);case'pred':if(alias(f[1],'predicate')==='On'&&f[2].length===2)return tw(f[2][0])+' lies on '+tw(f[2][1]);return 'the predicate \\('+formula(f)+'\\) holds';case'all':return 'for every \\('+nm(f[1],'variable')+'\\), '+words(f[2]);case'imp':return 'if ('+words(f[1])+'), then ('+words(f[2])+')';case'and':return '('+words(f[1])+') and ('+words(f[2])+')';case'or':return '('+words(f[1])+') or ('+words(f[2])+')';case'not':return 'it is not the case that ('+words(f[1])+')';default:return 'a contradiction holds';}}
function explain(l){switch(l.rule){case'axiom':return 'Use the supplied closed hypothesis “'+alias(l.name,'axiom')+'”.';case'instantiate':return 'Use universal instantiation with the recorded capture-free term substitution.';case'mp':return 'From line '+(l.antecedent+1)+' and implication line '+(l.implication+1)+', infer the consequent.';case'generalize':return 'Generalize line '+(l.source+1)+' over \\('+nm(l.variable,'variable')+'\\), with closed theory assumptions.';case'eq_subst':return 'Substitute the two equal terms in the same recorded formula context.';case'refl':return 'A term equals itself.';default:return 'Use the recorded '+l.rule+' rule.';}}
function color(f){let h=0;for(const c of JSON.stringify(f))h=(Math.imul(h,31)+c.charCodeAt(0))>>>0;return 'hsl('+(h%360)+',55%,40%)';}
function jump(i){const el=$('line-'+i);if(!el)return;document.querySelectorAll('.line.highlight').forEach(x=>x.classList.remove('highlight'));el.classList.add('highlight');el.scrollIntoView({behavior:'smooth',block:'center'});}
function svgNodes(pattern,members=null,receptors=[]){const ns='http://www.w3.org/2000/svg',make=(tag,a)=>{const e=document.createElementNS(ns,tag);for(const[k,v]of Object.entries(a))e.setAttribute(k,v);return e;},nodes=[];function walk(p,s,parent){if(p===null){nodes.push({site:s,parent,open:true,native:'open'});return;}nodes.push({site:s,parent,native:p[0]});p.slice(1).forEach((q,i)=>walk(q,s+i,s));}if(members){const root=Q.root;for(const m of members)nodes.push({...m,site:m.site.slice(root.length),parent:m.site===root?null:m.site.slice(root.length,-1)});for(const r of receptors)nodes.push({site:r.site.slice(root.length),parent:r.site.slice(root.length,-1),open:true,formula:r.formula});}else walk(pattern,'',null);const by=new Map(nodes.map(n=>[n.site,n])),xy=new Map();let leaf=0;function place(s){const kids=nodes.filter(n=>n.parent===s);for(const n of kids)place(n.site);xy.set(s,[kids.length?kids.reduce((a,n)=>a+xy.get(n.site)[0],0)/kids.length:55+105*leaf++,42+98*s.length]);}place('');const w=Math.max(310,leaf*105),h=95+98*Math.max(0,...nodes.map(n=>n.site.length)),svg=make('svg',{width:w,height:h,viewBox:'0 0 '+w+' '+h,role:'img','aria-label':'Recorded native rule family and open receptors'});for(const n of nodes){const[x,y]=xy.get(n.site);if(n.parent!==null&&xy.has(n.parent)){const[a,b]=xy.get(n.parent);svg.appendChild(make('line',{x1:a,y1:b+23,x2:x,y2:y-23,stroke:n.formula?color(n.formula):'#8dabbc','stroke-width':2}));}if(n.open)svg.appendChild(make('circle',{cx:x,cy:y,r:15,fill:'white',stroke:n.formula?color(n.formula):'#8553a1','stroke-width':3}));else{svg.appendChild(make('rect',{x:x-29,y:y-29,width:58,height:58,fill:n.final?'#e4f3e9':'#f5f9fb',stroke:n.final?'#278365':n.native?.includes('EQ')?'#b9852a':'#28789b','stroke-width':3}));if(n.formula)svg.appendChild(make('circle',{cx:x,cy:y-29,r:6,fill:color(n.formula),stroke:'white','stroke-width':2}));svg.appendChild(make('circle',{cx:x+21,cy:y+21,r:4,fill:'#d6a145'}));}const t=make('text',{x,y:y+4,'text-anchor':'middle','font-size':9,fill:'#203443'});t.textContent=n.open?'open':n.native;svg.appendChild(t);}return svg;}
function showProposal(){Q=P?.proposals[Number($('proposal').value)];$('proposal-diagram').replaceChildren();$('bindings').replaceChildren();$('receptors').replaceChildren();$('proposal-json').textContent=Q?json(Q.literal):'No representative family proposal in this certificate.';if(!Q){$('proposal-status').textContent='No recorded family proposal is displayed for this certificate.';return;}const f=D.library.find(f=>f.id===Q.family);$('proposal-status').textContent='Family '+Q.family+' from '+Q.origins.join(', ')+'. Root receptor '+(Q.root||'root')+'. '+Q.final_count+' of '+Q.members.length+' exact members are in the final proof; '+Q.later_nonforced_final_occurrences+' recorded later nonforced adoption occurrences survive. '+(Q.model_probability==null?'':'Recorded probability is the model softmax score, not the uniform/heuristic behavior probability.');$('proposal-diagram').appendChild(svgNodes(f.pattern,Q.members,Q.receptors));const table=document.createElement('table');table.innerHTML='<thead><tr><th>Binding layer / slot</th><th>Readable binding</th><th>Exact literal value</th></tr></thead><tbody></tbody>';for(const [slot,value]of Object.entries(Q.bindings.terms||{})){const tr=document.createElement('tr');tr.innerHTML='<td style="color:#8553a1">Term slot '+esc(slot)+'</td><td class="formula"></td><td><code>'+esc(value)+'</code></td>';tr.children[1].textContent='\\(\\tau_{'+slot+'}='+term(JSON.parse(value))+'\\)';table.tBodies[0].appendChild(tr);}for(const [slot,value]of Object.entries(Q.bindings.symbols||{})){const[k,i]=JSON.parse(slot),tr=document.createElement('tr');tr.innerHTML='<td style="color:#8553a1">'+esc(k)+' slot '+i+'</td><td class="formula"></td><td><code>'+esc(json(value))+'</code></td>';tr.children[1].textContent='\\('+nm(value[1],k)+'\\), arity '+value[0];table.tBodies[0].appendChild(tr);}$('bindings').appendChild(table);for(const r of Q.receptors){const p=document.createElement('p');p.className='formula';p.textContent='Open receptor '+(r.site||'root')+': \\('+formula(r.formula)+'\\)';$('receptors').appendChild(p);}typeset([$('bindings'),$('receptors')]);}
function showProof(){P=C.proofs[Number($('proof-choice').value)];$('proof').replaceChildren();$('proposal').replaceChildren();$('download').disabled=!P;$('proof-source').textContent=P?'Actual checked certificate found by '+D.names[P.lane]+'. '+P.recorded_proposals+' chosen proposals recorded; representative instances below.':'No representative independently checked proof is available under the recorded limits.';if(!P){$('proof').innerHTML='<p class="empty">Unknown or finite-closure outcomes remain in the complete results table.</p>';showProposal();return;}const sites=new Map(P.site_to_line.map(([s,i])=>[i,s]));P.proof.forEach((l,i)=>{const row=document.createElement('div');row.className='line';row.id='line-'+i;row.style.setProperty('--color',color(l.formula));row.innerHTML='<div class="glyph">'+esc(l.rule)+'</div><div><strong>Line '+(i+1)+'</strong> · <code>'+esc(sites.get(i)||'root')+'</code><div class="formula"></div><p class="english"></p><div class="ports"></div></div>';row.querySelector('.formula').textContent='\\('+formula(l.formula)+'\\)';row.querySelector('.english').textContent=words(l.formula)+'. '+explain(l);for(const j of l.rule==='mp'?[l.antecedent,l.implication]:l.rule==='generalize'?[l.source]:[]){const b=document.createElement('button');b.className='port';b.style.setProperty('--color',color(P.proof[j].formula));b.textContent='Line '+(j+1);b.onclick=()=>jump(j);row.querySelector('.ports').appendChild(b);}$('proof').appendChild(row);});P.proposals.forEach((p,i)=>{const o=document.createElement('option');o.value=i;o.textContent=p.family+' · '+p.final_count+'/'+p.members.length+' final members';$('proposal').appendChild(o);});showProposal();typeset([$('proof')]);}
function showCase(){C=D.readers.find(r=>r.case.id===$('case').value);$('statement').textContent='\\['+formula(C.case.problem.goal)+'\\]';$('proof-choice').replaceChildren();C.proofs.forEach((p,i)=>{const o=document.createElement('option');o.value=i;o.textContent=D.names[p.lane];$('proof-choice').appendChild(o);});$('axioms').replaceChildren();for(const[n,f]of Object.entries(C.case.problem.theory.axioms)){const p=document.createElement('p');p.className='formula';p.textContent=alias(n,'axiom')+': \\('+formula(f)+'\\)';$('axioms').appendChild(p);}$('aliases').textContent=json(C.case.renaming);showProof();typeset([$('statement'),$('axioms')]);}
function inventory(){const values=D.library.filter(f=>$('origin-filter').value!=='pa'||f.origins.some(o=>o.includes('-pa-')));$('inventory-count').textContent=values.length+' of '+D.library.length+' frozen families shown.';$('inventory').replaceChildren();for(const f of values){const card=document.createElement('div');card.className='card';card.innerHTML='<h3>'+esc(f.id)+'</h3><p>'+f.size+' members · '+f.open_receptors+' open receptors · '+f.term_slots+' term slots</p><div class="diagram"></div><div class="formula"></div><p class="muted">Origins: '+esc(f.origins.join(', '))+'</p>';card.querySelector('.diagram').appendChild(svgNodes(f.pattern));card.querySelector('.formula').textContent='Result interface: \\('+formula(f.output)+'\\)';$('inventory').appendChild(card);}typeset([$('inventory')]);}
function fill(){const b=D.counts.RL_BINDING_GCTS,s=D.counts.RL_SHAPE_GCTS,l=D.counts.LEXICAL_GCTS,dp=D.counts.DP_CONTROL;$('assessment').textContent='RL binding found '+b.verified+' checked held-out proofs, compared with '+s.verified+' for shape-only RL, '+l.verified+' for lexical GCTS and '+dp.verified+' for dynamic programming. '+(b.verified<s.verified?'The learned binding policy performed worse than its shape-only ablation in this run. ':'')+'These measurements do not establish a GCTS or RL advantage. Family reuse and policy effectiveness are different findings.';const cov=document.createElement('table');cov.innerHTML='<thead><tr><th>Method</th><th>Verified</th><th>Finite closure</th><th>Unknown</th><th>Prepared-input search sum</th><th>Post-search assurance sum</th></tr></thead><tbody></tbody>';for(const k of keys){const c=D.counts[k],tr=document.createElement('tr');tr.innerHTML='<td>'+esc(D.names[k])+'</td><td>'+c.verified+'</td><td>'+c.finite+'</td><td>'+c.unknown+'</td><td>'+seconds(c.search_seconds)+'</td><td>'+seconds(c.assurance_seconds)+'</td>';cov.tBodies[0].appendChild(tr);}$('coverage').appendChild(cov);const t=D.transfer;$('transfer-summary').textContent=t.occurrences?t.occurrences+' PA-only-origin proposal occurrences have at least two exact members in final checked incidence proofs ('+t.distinct_case_lane_family_member_sets+' distinct case/method/family/member sets). '+t.full_occurrences+' occurrences contain the complete requested cluster; partial overlaps are counted separately. Only '+t.nonreflexive_occurrences+' have non-reflexive outputs. '+t.full_nonrecursive_equality_occurrences+' full instances have a non-reflexive equality receptor and do not demand their own output again; the default reader selects one. Reflexive padding and recursive instances are not counted as productive equality transfer. This does not establish a policy speed advantage.':'No PA-only-origin proposal with at least two final members was recorded in a checked incidence proof.';
 const results=document.createElement('table');results.innerHTML='<thead><tr><th>Target</th>'+keys.map(k=>'<th>'+esc(D.names[k])+'</th>').join('')+'</tr></thead><tbody></tbody>';for(const r of D.readers){const o=document.createElement('option');o.value=r.case.id;o.textContent=r.case.id;$('case').appendChild(o);const tr=document.createElement('tr');tr.innerHTML='<td>'+esc(r.case.id)+'<br><button>Read</button></td>'+keys.map(k=>{const a=D.rows.find(x=>x.case===r.case.id&&x.lane===k);return '<td>'+badge(a)+'<br>'+seconds(a.search_seconds)+(a.reason?'<br>'+esc(a.reason):'')+'</td>';}).join('');tr.querySelector('button').onclick=()=>{$('case').value=r.case.id;showCase();$('proof-reader').scrollIntoView({behavior:'smooth'});};results.tBodies[0].appendChild(tr);}$('results').appendChild(results);const costs=D.costs;for(const[label,value]of [['Driver elapsed',costs.driver_seconds],['Preparation + native-zero/factory assurance',costs.preparation_seconds],['Prepared-input held-out search',costs.evaluation_search_seconds],['Held-out post-search assurance',costs.evaluation_assurance_seconds]]){const m=document.createElement('div');m.className='metric';const n=document.createElement('strong');n.textContent=seconds(value);m.append(n,document.createTextNode(label));$('cost-metrics').appendChild(m);}const tt=document.createElement('table');tt.innerHTML='<thead><tr><th>Training policy</th><th>Block time</th><th>Episodes</th><th>Checked successes</th><th>Recorded actions</th></tr></thead><tbody></tbody>';for(const r of costs.training){const tr=document.createElement('tr');tr.innerHTML='<td>'+esc(D.names[r.lane])+'</td><td>'+seconds(r.seconds)+'</td><td>'+r.episodes+'</td><td>'+r.checked_successes+'</td><td>'+r.action_count+'</td>';tt.tBodies[0].appendChild(tr);}$('training').appendChild(tt);const q=D.qualification;$('qualification').textContent='Separate qualification: '+q.status+'. '+q.summary.negative_mutants+' negative mutants; '+q.summary.checked_proposals+' checked proposals ('+q.summary.root_proposals+' root, '+q.summary.child_proposals+' child), '+q.summary.families+' families, automatic donor verified: '+q.summary.automatic_donor_verified+'.';$('provenance').textContent=json({input:D.input,protocol:D.protocol,costs:D.costs,qualification:D.qualification_source,environment:D.environment,source_pins:D.source_pins,projection_scope:D.projection_scope});const cross=D.transfer.records.slice().sort((a,b)=>Number(b.nonrecursive_equality_transfer)-Number(a.nonrecursive_equality_transfer)||Number(b.nonreflexive_output)-Number(a.nonreflexive_output)||Number(b.fully_final)-Number(a.fully_final)||b.final_count-a.final_count)[0],positive=cross?D.readers.find(r=>r.case.id===cross.case):D.readers.find(r=>r.proofs.length)||D.readers[0];if(positive){$('case').value=positive.case.id;showCase();if(cross){const i=C.proofs.findIndex(p=>p.lane===cross.lane);if(i>=0){$('proof-choice').value=i;showProof();const j=P.proposals.findIndex(p=>p.family===cross.family&&p.ordinal===cross.ordinal);if(j>=0){$('proposal').value=j;showProposal();}}}}inventory();}
$('case').onchange=showCase;$('proof-choice').onchange=showProof;$('proposal').onchange=showProposal;$('origin-filter').onchange=inventory;$('download').onclick=()=>{if(!P)return;const literal={case:C.case.id,lane:P.lane,theory:C.case.problem.theory,goal:C.case.problem.goal,proof:P.proof,checks:P.checks},url=URL.createObjectURL(new Blob([json(literal)+'\n'],{type:'application/json'})),a=document.createElement('a');a.href=url;a.download=C.case.id+'--'+P.lane+'--literal-proof.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);};fill();
</script></main></body></html>'''


if __name__ == '__main__':
    build()
