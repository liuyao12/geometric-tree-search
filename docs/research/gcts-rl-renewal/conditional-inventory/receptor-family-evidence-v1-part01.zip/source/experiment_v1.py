"""Prospective receptor-family study. Native execution only when explicitly run."""
import copy
import hashlib
import json
from pathlib import Path
import platform
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'reference'))
from proof_core_v1 import *
from finite_basis_v1 import compile_case,BasisLimit
from cases_v1 import cohort
from semantic_families_v1 import mine
from family_policy_v1 import Policy,dfs_control
from receptor_family_checker_v1 import verify as check_family

DEPTH=12
SECONDS=1.5
TRAIN_SECONDS=.6
EPISODES=32
LANES=['LEXICAL_GCTS','SEM_UNIFORM_GCTS','SEM_HEURISTIC_GCTS','RL_SHAPE_GCTS',
       'RL_BINDING_GCTS','RL_BINDING_LEADER_ONLY_GCTS','CLUSTER_DFS_CONTROL','DP_CONTROL']
ENGINE_LIMITS=dict(wall_seconds=SECONDS,max_work=1000000000,max_nodes=1000000,
    max_events=1024,max_rollback_records=256,max_candidates=50000,max_points=4000)
CONTROL_LIMITS=dict(wall_seconds=SECONDS,max_depth=256,max_items=20000000,
    max_proof_lines=4096,max_states=200000,max_work=1000000000)

def emit(kind,**data):print(text(dict(kind=kind,**data)),flush=True)
def pins():
    return {str(p.relative_to(ROOT)):dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
            for dirname in ('source','reference','upstream') for p in sorted((ROOT/dirname).glob('*.py'))
            if p.name!='qualification_v1.py'}

def freeze():
    value=cohort();value['protocol']=dict(depth=DEPTH,solve_seconds=SECONDS,training_seconds=TRAIN_SECONDS,
        episodes_per_policy=EPISODES,lanes=LANES,library_maximum=128,fragment_nodes=[2,6],pool_cap=48,per_family_cap=8,
        seeds='Training 2026110300+episode; evaluation case.seed+17.',
        order='All training donors first; frozen donor bank; train both policies; freeze both weights; evaluate all16 held-out cases in declared order.',
        budget='Basis compilation, all native-zero audits and factory assurance once per case outside prepared-input search window. Each lane recreates fresh index/matcher inside search window. Post-search independent proof and family assurance separately measured; search timeout never called a proof negative.',
        comparison='Finite-basis controls only. Single sequential run, no ATP comparison or statistical superiority claim.',
        training='Automatically discovered DP donor trees only. No supplied target derivation; policy-gradient cluster selection does not establish autonomous useful-lemma discovery.',
        engine_limits=ENGINE_LIMITS,control_limits=CONTROL_LIMITS,
        family_scope='Empirical templates, concrete current-catalogue instances; all primitive candidates remain available.')
    value['source_pins']=pins();write(ROOT/'data/cohort-frozen-v1.json',value)
    emit('FROZEN',cases=len(value['cases']),sha256=sha(value))

def prepare(modules,case):
    start=time.perf_counter()
    try:c,g=compile_case(case)
    except BasisLimit as error:return dict(status='UNKNOWN',refusal=error.receipt(),seconds=time.perf_counter()-start)
    model,provider,factory,cat=make_catalogue(modules,c,g,DEPTH)
    audit=modules['growing_proof_verifier_v2'].verify_factory(c,g,DEPTH,model,factory,limits=AUDIT)
    assert audit['status']=='VERIFIED',audit
    zeros=[]
    for z in c['zero_instances']:
        receipt=modules['independent_fol_checker_v1'].check(c['theory'],[z['line']],z['line']['formula'],CHECK)
        assert receipt['status']=='VERIFIED',(case['id'],z,receipt)
        zeros.append(dict(id=z['id'],receipt=receipt))
    out=dict(status='PREPARED',compiled=c,generation=g,factory_check=audit,
             zero_checks=zeros,seconds=time.perf_counter()-start)
    write(ROOT/'data/prepared'/ (case['id']+'.json.gz'),out)
    emit('PREPARED',case=case['id'],seconds=out['seconds'],definitions=c['profile']['definition_count'])
    return out

def assure(modules,c,result,library):
    start=time.perf_counter();by_id={f['id']:f for f in library};receipts=[]
    if result['status'] in ('SAT','DERIVABLE'):
        result['checked']=check_positive(modules,c,DEPTH,result['selected'])
    for p in result.get('guidance',{}).get('proposals',[]):
        receipt=check_family(c,DEPTH,p['selected_before'],by_id[p['family']],p['proposal'])
        assert receipt['status']=='VERIFIED',(p['family'],receipt)
        receipts.append(receipt)
    result['family_checks']=receipts;result['assurance_seconds']=time.perf_counter()-start
    result['checked_total_seconds']=result['search_seconds']+result['assurance_seconds']
    result['within_search_window']=result['search_seconds']<=result['allowed_seconds']
    return result

def run(modules,prepared,lane,library,weights,seed,training=False):
    c,g=prepared['compiled'],prepared['generation'];seconds=TRAIN_SECONDS if training else SECONDS
    start=time.perf_counter();policy=None
    if lane=='DP_CONTROL':
        limits=dict(CONTROL_LIMITS,wall_seconds=seconds)
        out=modules['growing_proof_verifier_v2'].tree_control(c,DEPTH,limits)
        result=dict(status=out['status'],selected=(out.get('details') or {}).get('selected',[]),
                    stats=out['costs'],control=out)
    else:
        model,provider,factory,cat=make_catalogue(modules,c,g,DEPTH)
        remaining=max(0,seconds-(time.perf_counter()-start))
        if lane=='CLUSTER_DFS_CONTROL':
            result=dfs_control(cat,library,weights,remaining)
            result['guidance']=dict(proposals=result.pop('proposals'))
        else:
            if lane!='LEXICAL_GCTS':
                mode='train' if training else ('uniform' if lane=='SEM_UNIFORM_GCTS' else 'heuristic' if lane=='SEM_HEURISTIC_GCTS' else 'greedy')
                policy=Policy(cat,library,weights,mode,seed,shape_only=lane=='RL_SHAPE_GCTS',leader_only=lane=='RL_BINDING_LEADER_ONLY_GCTS')
            limits=dict(ENGINE_LIMITS,wall_seconds=remaining)
            if remaining<=0:
                result=dict(status='UNKNOWN',reason='INDEX_EXHAUSTED_SEARCH_WINDOW',selected=[],stats={})
            else:
                result=modules['growing_point_search_v2'].solve(model,limits,enumerate_incident=provider,
                            order=policy,audit=policy.audit if policy else None)
            result['provider']=provider.snapshot()
            if policy:result['guidance']=policy.finish(result['selected'])
            # Exact rollback is part of the unchanged engine's contract.
            if 'entry_state' in result:assert result['entry_state']==result['restored_state']
    result['search_seconds']=time.perf_counter()-start;result['allowed_seconds']=seconds
    result=assure(modules,c,result,library)
    return result,policy

def donors(modules,values,prepared):
    bank={};records=[]
    for case in values:
        if case['split']!='train':continue
        prep=prepared[case['id']]
        if prep['status']!='PREPARED':records.append(dict(case=case['id'],status='UNKNOWN_PREPARATION'));continue
        answer,_=run(modules,prep,'DP_CONTROL',[],[],case['seed'])
        record=dict(case=case['id'],answer=answer)
        if 'checked' in answer:
            _,_,_,cat=make_catalogue(modules,prep['compiled'],prep['generation'],DEPTH)
            families=mine(answer['checked']['tree'],cat)
            for f in families:
                item=bank.setdefault(f['id'],f)
                if case['id'] not in item['origins']:item['origins'].append(case['id'])
            record['mined_families']=len(families)
        records.append(record);emit('DONOR',case=case['id'],status=answer['status'],families=len(bank))
    # Same deterministic bank and ordering for every semantic-guidance lane.
    library=sorted(bank.values(),key=lambda f:(-len(f['origins']),-f['size'],f['id']))[:128]
    write(ROOT/'data/donors-v1.json.gz',records);write(ROOT/'data/library-frozen-v1.json',library)
    emit('LIBRARY_FROZEN',families=len(library),sha256=sha(library))
    return library

def train(modules,values,prepared,library,shape_only):
    lane='RL_SHAPE_GCTS' if shape_only else 'RL_BINDING_GCTS';weights=[0.]*(len(library)+16);baseline=0.;episodes=[]
    training=[c for c in values if c['split']=='train'];start=time.perf_counter()
    for episode in range(EPISODES):
        case=training[episode%len(training)];prep=prepared[case['id']]
        if prep['status']!='PREPARED':episodes.append(dict(episode=episode,case=case['id'],status='UNKNOWN_PREPARATION'));continue
        result,policy=run(modules,prep,lane,library,weights,2026110300+episode,True)
        stats=result['stats'];reward=(1. if 'checked' in result else -1.)-.002*stats.get('branches',0)-.001*stats.get('backtracks',0)-min(.5,policy.work/10000000)
        advantage=reward-baseline;baseline=.9*baseline+.1*reward
        for action in policy.actions:
            for j in range(len(weights)):weights[j]=max(-8,min(8,weights[j]+.08*advantage*(action['chosen'][j]-action['expectation'][j])))
        episodes.append(dict(episode=episode,case=case['id'],reward=reward,advantage=advantage,weights_after=list(weights),answer=result))
        write(ROOT/'data/training'/ (lane+'-%02d.json.gz'%episode),episodes[-1])
        emit('TRAIN',lane=lane,episode=episode,status=result['status'],actions=len(policy.actions))
    receipt=dict(lane=lane,weights=weights,seconds=time.perf_counter()-start,episodes=EPISODES,
                 checked_successes=sum('checked' in e.get('answer',{}) for e in episodes),
                 action_count=sum(len(e.get('answer',{}).get('guidance',{}).get('proposals',[])) for e in episodes))
    write(ROOT/'data'/ (lane+'-weights-frozen-v1.json'),receipt)
    return receipt

def execute():
    frozen=json.loads((ROOT/'data/cohort-frozen-v1.json').read_text());assert frozen['source_pins']==pins(),'Source changed after freeze; create an explicit revision rather than silently changing the study.'
    modules=load_modules();start=time.perf_counter();prepared={}
    for case in frozen['cases']:prepared[case['id']]=prepare(modules,case)
    library=donors(modules,frozen['cases'],prepared)
    shape=train(modules,frozen['cases'],prepared,library,True)
    binding=train(modules,frozen['cases'],prepared,library,False)
    results=[]
    for case in frozen['cases']:
        if case['split']!='test':continue
        prep=prepared[case['id']]
        for lane in LANES:
            if prep['status']!='PREPARED':result=dict(status='UNKNOWN_PREPARATION',selected=[],preparation=prep)
            else:
                weights=shape['weights'] if lane=='RL_SHAPE_GCTS' else binding['weights']
                result,_=run(modules,prep,lane,library,weights,case['seed']+17)
            row=dict(case=case['id'],lane=lane,answer=result);results.append(row)
            write(ROOT/'data/evaluation'/ (case['id']+'--'+lane+'.json.gz'),row)
            emit('TEST',case=case['id'],lane=lane,status=result['status'],seconds=result.get('search_seconds'),proposals=len(result.get('guidance',{}).get('proposals',[])))
    summary=dict(schema='RF-receptor-family-study-v1',cohort=frozen,library=library,training=[shape,binding],results=results,
        preparation=[dict(case=c['id'],status=prepared[c['id']]['status'],seconds=prepared[c['id']]['seconds'],
                         costs=prepared[c['id']].get('compiled',{}).get('costs')) for c in frozen['cases']],
        total_seconds=time.perf_counter()-start,environment=dict(python=sys.version,executable=sys.executable,platform=platform.platform()))
    write(ROOT/'data/results-v1.json.gz',summary);emit('COMPLETE',seconds=summary['total_seconds'])

if __name__=='__main__':
    if sys.argv[1:] == ['freeze']:freeze()
    elif sys.argv[1:] == ['run']:execute()
    else:raise SystemExit('Choose freeze or run')
