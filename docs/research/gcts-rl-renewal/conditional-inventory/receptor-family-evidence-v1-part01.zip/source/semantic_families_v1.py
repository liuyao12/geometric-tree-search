"""Mine and instantiate empirical, shared-binding point-cluster families.

No family is a new logical axiom. Guidance expands exact current definitions;
the unchanged base engine retains all candidates and independent checks decide
whether a final proof is valid. Literal names do not enter policy features.
"""
import copy
import json
import math
from proof_core_v1 import native,pattern_size,text,sha


def atomic_arguments(form):
    tag=form[0]
    if tag=='eq':return form[1:]
    if tag=='pred':return form[2]
    if tag=='all':return atomic_arguments(form[2])
    if tag=='not':return atomic_arguments(form[1])
    if tag in ('imp','and','or'):return atomic_arguments(form[1])+atomic_arguments(form[2])
    return []


def term_size(t):return 1+sum(term_size(a) for a in t[2]) if t[0]=='fun' else 1
def term_depth(t):return 1+max((term_depth(a) for a in t[2]),default=-1) if t[0]=='fun' else 0


class Abstract:
    def __init__(self,candidates):self.candidates={text(t) for t in candidates};self.terms={};self.symbols={}
    def symbol(self,kind,name,arity):
        key=(kind,name,arity)
        if key not in self.symbols:self.symbols[key]=sum(k[0]==kind for k in self.symbols)
        return ['symbol',kind,self.symbols[key],arity]
    def term(self,t):
        key=text(t)
        if key in self.candidates or t[0]=='var':
            if key not in self.terms:self.terms[key]=len(self.terms)
            return ['term_slot',self.terms[key]]
        return ['fun',self.symbol('function',t[1],len(t[2])),[self.term(a) for a in t[2]]]
    def formula(self,f):
        tag=f[0]
        if tag=='eq':return ['eq',self.term(f[1]),self.term(f[2])]
        if tag=='pred':return ['pred',self.symbol('predicate',f[1],len(f[2])),[self.term(t) for t in f[2]]]
        if tag=='all':return ['all',self.symbol('variable',f[1],0),self.formula(f[2])]
        if tag=='not':return ['not',self.formula(f[1])]
        if tag in ('imp','and','or'):return [tag,self.formula(f[1]),self.formula(f[2])]
        return ['bot']


def mine(tree,cat,maximum=6):
    by_site={}
    for row in tree['placements']:
        site,d=cat.decode_id(row['id']);assert site not in by_site;by_site[site]=d
    def fragments(site):
        d=by_site[site];products=[[]]
        for i in range(len(d['premises'])):
            choices=[None]+fragments(site+str(i));products=[p+[q] for p in products for q in choices if 1+sum(pattern_size(x) for x in p)+pattern_size(q)<=maximum]
        return [[native(d),*p] for p in products]
    result={}
    for root in sorted(by_site):
        for pattern in fragments(root):
            if pattern_size(pattern)<2:continue
            concrete=[];receptors=[];axiom_receptors=[]
            def collect(p,site):
                d=by_site[site];concrete.append((site,d))
                if native(d)=='ZERO:axiom':axiom_receptors.append(cat.forms[d['output']])
                for i,(child,fid) in enumerate(zip(p[1:],d['premises'])):
                    if child is None:receptors.append(cat.forms[fid])
                    else:collect(child,site+str(i))
            collect(pattern,root)
            abstract=Abstract([t for f in receptors+axiom_receptors for t in atomic_arguments(f)])
            def semantic(p,site):
                d=by_site[site]
                # Exact traversal order is part of canonicalization.
                out=abstract.formula(cat.forms[d['output']]);premises=[abstract.formula(cat.forms[f]) for f in d['premises']]
                return dict(native=native(d),output=out,premises=premises,
                            children=[None if q is None else semantic(q,site+str(i)) for i,q in enumerate(p[1:])])
            sem=semantic(pattern,root);key=text([pattern,sem])
            result[key]=dict(id=sha([pattern,sem])[:20],pattern=pattern,semantic=sem,origins=[],size=pattern_size(pattern),
                             open_receptors=len(receptors),axiom_requirements=len(axiom_receptors),term_slots=len(abstract.terms),
                             scope='Empirical proposal family; concrete current-Gamma instances are revalidated, not admitted as new axioms.')
    return list(result.values())


def bind_symbol(template,actual,kind,arity,env):
    if template[:2]!=['symbol',kind] or template[3]!=arity:return False
    key=text([kind,template[2]]);value=[arity,actual]
    if key in env['symbols'] and env['symbols'][key]!=value:return False
    env['symbols'][key]=value;return True


def match_term(template,actual,env,charge):
    charge(2)
    if template[0]=='term_slot':
        key=str(template[1]);value=text(actual)
        if key in env['terms'] and env['terms'][key]!=value:return False
        env['terms'][key]=value;return True
    if template[0]!=actual[0]:return False
    if template[0]=='var':return bind_symbol(template[1],actual[1],'variable',0,env)
    if len(template[2])!=len(actual[2]) or not bind_symbol(template[1],actual[1],'function',len(actual[2]),env):return False
    return all(match_term(a,b,env,charge) for a,b in zip(template[2],actual[2]))


def match_formula(template,actual,env,charge):
    charge(2)
    if template[0]!=actual[0]:return False
    tag=template[0]
    if tag=='eq':return match_term(template[1],actual[1],env,charge) and match_term(template[2],actual[2],env,charge)
    if tag=='pred':
        return len(template[2])==len(actual[2]) and bind_symbol(template[1],actual[1],'predicate',len(actual[2]),env) and all(match_term(a,b,env,charge) for a,b in zip(template[2],actual[2]))
    if tag=='all':return bind_symbol(template[1],actual[1],'variable',0,env) and match_formula(template[2],actual[2],env,charge)
    if tag=='not':return match_formula(template[1],actual[1],env,charge)
    if tag in ('imp','and','or'):return match_formula(template[1],actual[1],env,charge) and match_formula(template[2],actual[2],env,charge)
    return tag=='bot'


class Instantiator:
    def __init__(self,cat,library,per_family=8):
        self.cat=cat;self.library=library;self.per_family=per_family;self.cache={};self.cache_hits=0
    def instantiate(self,sem,site,fid,env,charge):
        charge(4+len(site))
        if sem is None:return [([],env)]
        if len(site)>self.cat.depth:return []
        answers=[]
        for d in self.cat.by_out.get(fid,[]):
            charge(10+len(d['id']))
            if native(d)!=sem['native'] or len(d['premises'])!=len(sem['premises']):continue
            if d['premises'] and len(site)>=self.cat.depth:continue
            binding=copy.deepcopy(env)
            if not match_formula(sem['output'],self.cat.forms[fid],binding,charge):continue
            if not all(match_formula(t,self.cat.forms[f],binding,charge) for t,f in zip(sem['premises'],d['premises'])):continue
            products=[([self.cat.placement(site,d)],binding)]
            for i,(child,premise) in enumerate(zip(sem['children'],d['premises'])):
                expanded=[]
                for rows,bound in products:
                    for extra,new in self.instantiate(child,site+str(i),premise,copy.deepcopy(bound),charge):
                        expanded.append((rows+extra,new))
                        if len(expanded)>=self.per_family:break
                    if len(expanded)>=self.per_family:break
                products=expanded
            answers.extend(products)
            if len(answers)>=self.per_family:break
        return answers[:self.per_family]
    def pool(self,point,fid,legal,selected,excluded,charge,cap):
        proposals=[];legal=set(legal)
        for family in self.library:
            key=(family['id'],fid,self.cat.depth-len(point))
            if key not in self.cache:
                # Cache relative exact expansions, never a proof failure or a base degree.
                rows=self.instantiate(family['semantic'],'',fid,{'terms':{},'symbols':{}},charge)
                self.cache[key]=[(r,b) for r,b in rows if all(len(json.loads(p['id'])[0])<=self.cat.depth-len(point) for p in r)]
            else:charge(1);self.cache_hits+=1
            for relative,binding in self.cache[key]:
                rows=[]
                for placement in relative:
                    suffix,d=self.cat.decode_id(placement['id']);rows.append(self.cat.placement(point+suffix,d));charge(3)
                if rows[0]['id'] not in legal or not self.cat.valid(rows,selected,excluded,charge):continue
                proposals.append(dict(root_site=point,pattern=family['pattern'],placements=rows,family=family['id'],bindings=copy.deepcopy(binding)))
                if len(proposals)>=cap:return proposals
        return proposals


def open_receptors(cat,proposal):
    occupied={cat.decode_id(r['id'])[0] for r in proposal['placements']};holes=[]
    for row in proposal['placements']:
        site,d=cat.decode_id(row['id'])
        holes.extend((site+str(i),fid) for i,fid in enumerate(d['premises']) if site+str(i) not in occupied)
    return holes


def features(cat,proposal,library,point_marks=None,shape_only=False):
    rows=proposal['placements'];holes=open_receptors(cat,proposal);size=len(rows)
    base=[float(f['id']==proposal['family']) for f in library]+[size/6,len(holes)/8,len(proposal['root_site'])/12,1.]
    terms=[json.loads(v) for v in proposal['bindings']['terms'].values()]
    counts=[len(cat.by_out.get(fid,[])) for _,fid in holes];total=max(1,len(holes))
    root=cat.decode_id(rows[0]['id'])[1]['output'];marks=list((point_marks or {}).values())
    actual=[text(cat.forms[f]) for _,f in holes]
    binding=[sum(f in cat.axiom_out for _,f in holes)/total,sum(f in cat.zero_out for _,f in holes)/total,
             sum(math.log1p(c) for c in counts)/total/10,min(counts,default=0)/100,
             max((term_depth(t) for t in terms),default=0)/10,
             sum(term_size(t) for t in terms)/max(1,len(terms))/20,
             len(set(text(t) for t in terms))/max(1,len(terms)),
             sum(f==root for _,f in holes)/total,
             sum(v in marks for v in actual)/total,
             len(set(actual))/total,
             sum(c==1 for c in counts)/total,sum(c==0 for c in counts)/total]
    return base+([0.]*12 if shape_only else binding)


def heuristic(vector,library):
    offset=len(library)+4;v=vector[offset:]
    return 4*v[1]+2*v[0]-3*v[7]-v[2]-vector[len(library)+1]
