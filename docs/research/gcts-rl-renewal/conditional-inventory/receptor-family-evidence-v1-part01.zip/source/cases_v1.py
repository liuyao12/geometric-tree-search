"""Prospective declarative RF-v1 cohort; no proofs, labels or search execution.

Call cohort()/make_cases() and save the returned data before compilation/search.
Each case has an independent, recorded variable/symbol/axiom-name renaming.
"""
import copy
import random

VERSION = 'RF-declarative-cohort-v1'


def var(name):
    return ['var', name]


def fun(name, *args):
    return ['fun', name, list(args)]


def power(name, term, depth):
    for _ in range(depth):
        term = fun(name, term)
    return term


def _vars(ast):
    tag = ast[0]
    if tag == 'var':
        return {ast[1]}
    if tag in ('fun', 'pred'):
        return set().union(*(_vars(c) for c in ast[2]))
    if tag == 'all':
        return {ast[1]} | _vars(ast[2])
    if tag in ('eq', 'imp', 'and', 'or'):
        return _vars(ast[1]) | _vars(ast[2])
    return _vars(ast[1]) if tag == 'not' else set()


def _rename(case):
    case = copy.deepcopy(case)
    seed = case['seed'] ^ 0x5A17D3
    rng = random.Random(seed)
    theory = case['problem']['theory']
    all_ast = list(theory['axioms'].values()) + [case['problem']['goal']] + case['terms']
    variable_names = sorted(set().union(*(_vars(f) for f in all_ast)))
    stem = 'rf%x_' % case['seed']

    def mapping(names, kind):
        names = sorted(names)
        numbers = rng.sample(range(len(names) * 11 + 1), len(names))
        return {n: stem + kind + str(i) for n, i in zip(names, numbers)}

    maps = dict(function=mapping(theory['functions'], 'f'),
                predicate=mapping(theory['predicates'], 'p'),
                variable=mapping(variable_names, 'v'),
                axiom=mapping(theory['axioms'], 'a'))

    def change(ast):
        tag = ast[0]
        if tag == 'var':
            return ['var', maps['variable'][ast[1]]]
        if tag in ('fun', 'pred'):
            kind = 'function' if tag == 'fun' else 'predicate'
            return [tag, maps[kind][ast[1]], [change(c) for c in ast[2]]]
        if tag == 'all':
            return ['all', maps['variable'][ast[1]], change(ast[2])]
        if tag in ('eq', 'imp', 'and', 'or'):
            return [tag, change(ast[1]), change(ast[2])]
        return ['not', change(ast[1])] if tag == 'not' else ['bot']

    renamed = dict(functions={maps['function'][n]: a for n, a in theory['functions'].items()},
                   predicates={maps['predicate'][n]: a for n, a in theory['predicates'].items()},
                   axioms={maps['axiom'][n]: change(f) for n, f in theory['axioms'].items()})
    case['problem'] = dict(theory=renamed, goal=change(case['problem']['goal']))
    case['terms'] = [change(t) for t in case['terms']]
    if 'instantiation_terms' in case:
        case['instantiation_terms'] = [change(t) for t in case['instantiation_terms']]
    case['renaming_seed'], case['renaming'] = seed, maps
    case['generation'] = 'Declarative theory and goal fixed before truth labels or search. No target derivation or selected producer path supplied.'
    return case


def _profile(rounds, **extra):
    return dict(ui_rounds=rounds, max_terms=20, max_templates=24,
                max_definitions=8000, original_eq_context_snapshot=True, **extra)


def _horn(split, ordinal):
    seed = (11032001 if split == 'train' else 11033001) + ordinal * 7919
    rng = random.Random(seed)
    size = 5 + ordinal % 2 if split == 'train' else 8 + ordinal % 3
    depth = 1 + ordinal % 2 if split == 'train' else 4
    x = var('x')
    term = lambda d: power('f', x, d)
    pred = lambda i, d=0: ['pred', 'P' + str(i), [term(d)]]
    close = lambda f: ['all', 'x', f]
    axioms = {'fact0': close(pred(0)), 'fact1': close(pred(1))}
    # All rule edges and the goal are sampled; none is a planted proof path.
    for i in range(size + (4 if split == 'train' else 6)):
        left, right = rng.sample(range(size), 2)
        a, b = rng.randrange(min(2, depth) + 1), rng.randrange(min(2, depth) + 1)
        body = ['imp', pred(left, a), pred(right, b)]
        if rng.random() < .3:
            extra = rng.randrange(size)
            body = ['imp', pred(left, a), ['imp', pred(extra), pred(right, b)]]
        axioms['rule' + str(i)] = close(body)
    goal_predicate, goal_depth = rng.randrange(2, size), rng.randrange(depth + 1)
    case = dict(id=split + '-horn-' + str(ordinal), split=split, kind='quantified Horn',
        seed=seed, quantified=True, max_term=depth,
        profile=_profile(1, family='quantified-Horn', signature_predicates=size,
                         original_term_depth=depth, sampled_goal_depth=goal_depth),
        problem=dict(theory=dict(functions={'f': 1}, predicates={'P' + str(i): 1 for i in range(size)}, axioms=axioms),
                     goal=close(pred(goal_predicate, goal_depth))),
        terms=[term(i) for i in range(depth + 1)])
    return _rename(case)


def _pa(split, ordinal, d, k):
    seed = (11034001 if split == 'train' else 11035001) + ordinal * 7919
    x, zero = var('x'), fun('zero')
    shifted = power('S', x, k)
    left = power('S', fun('add', shifted, zero), d)
    right = power('S', x, d + k)
    theory = dict(functions={'zero': 0, 'S': 1, 'add': 2}, predicates={},
                  axioms={'add_zero': ['all', 'x', ['eq', fun('add', x, zero), x]]})
    return _rename(dict(id=split + '-pa-d%d-k%d' % (d, k), split=split,
        kind='addition-zero and equality congruence', seed=seed, quantified=True,
        profile=_profile(1, family='PA-addition-zero-fragment', congruence_depth=d, shift=k,
                         full_PA=False, induction=False),
        problem=dict(theory=theory, goal=['all', 'x', ['eq', left, right]]), terms=[]))


def _incidence(depth):
    seed = 11036001 + (depth - 1) * 7919
    a, b, ell, emm = [fun(n) for n in ('a', 'b', 'ell', 'emm')]
    l, m = var('l'), var('m')
    on = lambda point, line: ['pred', 'On', [point, line]]

    def conjunction(items):
        out = items[-1]
        for item in reversed(items[:-1]):
            out = ['and', item, out]
        return out

    def common(u, v):
        return conjunction([['not', ['eq', a, b]], on(a, u), on(b, u), on(a, v), on(b, v)])

    theory = dict(functions={'a': 0, 'b': 0, 'ell': 0, 'emm': 0, 'mark': 1}, predicates={'On': 2},
        axioms={'incidence_uniqueness_ab': ['all', 'l', ['all', 'm', ['imp', common(l, m), ['eq', l, m]]]],
                'given_common_points': common(ell, emm)})
    return _rename(dict(id='test-incidence-mark-' + str(depth), split='test',
        kind='symbolic incidence and line-function congruence', seed=seed, quantified=True,
        profile=_profile(2, family='one-sorted-incidence-fragment', mark_depth=depth,
                         UI_subset='ell/emm constants only', full_Hilbert_geometry=False),
        problem=dict(theory=theory, goal=['eq', power('mark', ell, depth), power('mark', emm, depth)]),
        terms=[ell, emm], instantiation_terms=[ell, emm]))


def make_cases():
    training = [_horn('train', i) for i in range(4)]
    training += [_pa('train', i, d, k) for i, (d, k) in enumerate(
        [(1, 1), (1, 2), (2, 1), (2, 2)])]
    tests = [_horn('test', i) for i in range(6)]
    tests += [_pa('test', i, d, k) for i, (d, k) in enumerate(
        [(2, 3), (2, 4), (2, 5), (3, 3), (3, 4), (3, 5)])]
    tests += [_incidence(d) for d in range(1, 5)]
    return training + tests


def cases():
    return make_cases()


def cohort():
    values = make_cases()
    design = dict(schema='RF-prospective-cohort-design-v1', version=VERSION,
        training_cases=8, test_cases=16, case_order=[c['id'] for c in values],
        limits=dict(max_definitions=8000, max_terms=20, max_templates=24),
        split='Four fresh random quantified-Horn and four PA congruence training cases; six larger fresh Horn, six deeper/shifted PA and four incidence-congruence tests.',
        holdout='Training PA d,k in1..2; test d in2..3 and k in3..5. Horn signatures are strictly larger in tests. Every case has independent literal-name renaming; disjoint proof cores are not claimed.',
        basis='Fixed original subterms; finite free-for UI rounds; original-source individual-occurrence EQ templates, all ordered fixed-term pairs whose outputs remain in the original term pool; native reflexivity.',
        freeze='Save this entire cohort before compilation, donor discovery, truth labels, training or evaluation. No supplied target proofs.',
        scope='Finite native logical basis and empirical receptor-family guidance. No full PA/Hilbert formalization, unbounded FOL completeness or proof-search advantage assumed.')
    return dict(schema='RF-declarative-cohort-v1', design=design, cases=values)
