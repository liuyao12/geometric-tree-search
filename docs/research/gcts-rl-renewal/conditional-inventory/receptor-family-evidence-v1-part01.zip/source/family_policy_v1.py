"""Shared family-pool policies and a conventional memoized cluster control."""
import math
import random
import time
from proof_core_v1 import Meter,Stop,probabilities,text
from semantic_families_v1 import Instantiator,features,heuristic


class Policy:
    def __init__(self,cat,library,weights,mode,seed,cap=48,shape_only=False,leader_only=False):
        self.cat=cat;self.library=library;self.weights=weights;self.mode=mode;self.rng=random.Random(seed);self.cap=cap
        self.shape_only=shape_only;self.leader_only=leader_only;self.inst=Instantiator(cat,library)
        self.state=None;self.records=[];self.plans=[];self.orders=[];self.actions=[];self.work=0;self.seconds=0.;self.continuations=0
    def audit(self,event,state,charge):
        charge(2+len(state['selected']));self.state=state;selected={cid for cid,g in state['selected']}
        for plan in self.records:
            if plan.get('dead'):continue
            if plan.get('activated') and plan['leader'] not in selected:plan['dead']=True;plan['invalidated_by_rollback']=True
            if plan['leader'] in selected:plan['activated']=True
            if event['kind']=='PLACED' and event['candidate'] in plan['members']:
                plan['adoptions'].append(dict(candidate=event['candidate'],forced=event['data']['forced'],seq=event['seq']))
        self.plans=[p for p in self.plans if not p.get('dead')]
    def __call__(self,request,charge):
        start=time.perf_counter()
        def reserve(n=1):self.work+=n;charge(n)
        try:return self.order(request,reserve)
        finally:self.seconds+=time.perf_counter()-start
    def order(self,request,charge):
        assert self.state is not None
        selected=request['selected'];excluded=set(request['excluded']);legal=request['legal']
        assert selected==sorted(cid for cid,g in self.state['selected']) and request['excluded']==self.state['excluded']
        assert dict(self.state['domains'])[request['point']]==legal
        if not self.leader_only:
            for plan in self.plans:
                if not plan.get('activated'):continue
                remaining=[p for p in plan['proposal']['placements'] if p['id'] not in set(selected)]
                if not self.cat.valid(remaining,selected,excluded,charge):continue
                member=next((p['id'] for p in remaining if p['id'] in legal),None)
                if member:
                    self.continuations+=1;plan['guided_later'].append(member)
                    self.orders.append(dict(point=request['point'],kind='CONTINUATION',candidate=member));return [member]
        if len(self.records)>=200:
            self.orders.append(dict(point=request['point'],kind='RECORD_CAP_BASE_FALLBACK'));return []
        totals,marks=self.cat.values(selected,charge)
        if totals.get(request['point'])!=1 or request['point'] not in marks:return []
        fid=self.cat.fid[marks[request['point']]]
        pool=self.inst.pool(request['point'],fid,legal,selected,excluded,charge,self.cap)
        if not pool:
            self.orders.append(dict(point=request['point'],kind='NO_FAMILY_BASE_FALLBACK'));return []
        vectors=[features(self.cat,p,self.library,marks,self.shape_only) for p in pool]
        charge(len(pool)*(len(self.weights)+4));probs=probabilities(vectors,self.weights)
        if self.mode=='uniform':choice=self.rng.randrange(len(pool))
        elif self.mode=='train':choice=self.rng.choices(range(len(pool)),weights=probs,k=1)[0]
        elif self.mode=='heuristic':choice=max(range(len(pool)),key=lambda i:heuristic(vectors[i],self.library))
        else:choice=max(range(len(pool)),key=lambda i:probs[i])
        proposal=pool[choice];leader=proposal['placements'][0]['id']
        self.actions.append(dict(chosen=vectors[choice],expectation=[sum(p*v[j] for p,v in zip(probs,vectors)) for j in range(len(self.weights))]))
        record=dict(family=proposal['family'],proposal={k:proposal[k] for k in ('root_site','pattern','placements')},
                    bindings=proposal['bindings'],leader=leader,members=[r['id'] for r in proposal['placements']],
                    selected_before=list(selected),excluded_before=request['excluded'],adoptions=[],guided_later=[],
                    chosen_features=vectors[choice],chosen_probability=probs[choice],
                    pool=[dict(family=p['family'],leader=p['placements'][0]['id'],bindings=p['bindings'],features=v,probability=q)
                          for p,v,q in zip(pool,vectors,probs)])
        self.records.append(record)
        if not self.leader_only:self.plans.append(record)
        self.orders.append(dict(point=request['point'],kind='NEW_FAMILY',candidate=leader,family=proposal['family']));return [leader]
    def finish(self,selected):
        selected=set(selected)
        for record in self.records:
            record['final_realized']=sum(cid in selected for cid in record['members'])
            record['fully_in_final_proof']=record['final_realized']==len(record['members'])
        return dict(proposals=self.records,orders=self.orders,continuation_choices=self.continuations,
                    proposal_work=self.work,proposal_seconds=self.seconds,cache_entries=len(self.inst.cache),cache_hits=self.inst.cache_hits,
                    final_two_member_realizations=sum(r['final_realized']>=2 for r in self.records),
                    final_full_realizations=sum(r['fully_in_final_proof'] for r in self.records))


def dfs_control(cat,library,weights,seconds,cap=48):
    """Same family bank, matcher and binding features; conventional memoization."""
    meter=Meter(seconds);inst=Instantiator(cat,library);cache={};calls=0;macro_tries=0;records=[]
    def expand(tree,site):
        meter.tick();out=[cat.placement(site,cat.defs[tree[0]])['id']]
        for i,child in enumerate(tree[1]):out+=expand(child,site+str(i))
        return out
    def complete(fid,site,forced,prefix):
        d=forced.get(site)
        if d is None:return search(fid,site,prefix)
        if d['output']!=fid or d['premises'] and len(site)>=cat.depth:return None
        nextprefix=prefix+[cat.placement(site,d)['id']];children=[]
        for i,premise in enumerate(d['premises']):
            child=complete(premise,site+str(i),forced,nextprefix)
            if child is None:return None
            children.append(child);nextprefix+=expand(child,site+str(i))
        return [d['id'],children]
    def search(fid,site,prefix):
        nonlocal calls,macro_tries
        meter.tick();calls+=1;key=(fid,cat.depth-len(site))
        if key in cache:return cache[key]
        if len(site)>cat.depth:return None
        candidates=[cat.placement(site,d)['id'] for d in cat.by_out.get(fid,[]) if not d['premises'] or len(site)<cat.depth]
        pool=inst.pool(site,fid,candidates,prefix,set(),meter.tick,cap)
        if pool:
            totals,marks=cat.values(prefix,meter.tick)
            vectors=[features(cat,p,library,marks) for p in pool];meter.tick(len(pool)*(len(weights)+4))
            probs=probabilities(vectors,weights);chosen=max(range(len(pool)),key=lambda i:probs[i]);p=pool[chosen];macro_tries+=1
            if len(records)<200:records.append(dict(family=p['family'],proposal={k:p[k] for k in ('root_site','pattern','placements')},
                                                     selected_before=list(prefix),bindings=p['bindings'],chosen_features=vectors[chosen]))
            forced={cat.decode_id(r['id'])[0]:cat.decode_id(r['id'])[1] for r in p['placements']}
            tree=complete(fid,site,forced,prefix)
            if tree is not None:cache[key]=tree;return tree
        # A failed family cannot populate a negative cache entry. Exhaust base.
        for d in cat.by_out.get(fid,[]):
            meter.tick(10+len(d['id']))
            if d['premises'] and len(site)>=cat.depth:continue
            children=[];nextprefix=prefix+[cat.placement(site,d)['id']]
            for i,premise in enumerate(d['premises']):
                child=search(premise,site+str(i),nextprefix)
                if child is None:break
                children.append(child);nextprefix+=expand(child,site+str(i))
            if len(children)==len(d['premises']):
                tree=[d['id'],children];cache[key]=tree;return tree
        cache[key]=None;return None
    try:
        tree=search(cat.c['goal_id'],'',[]);selected=sorted(expand(tree,'')) if tree else []
        return dict(status='DERIVABLE' if tree else 'NOT_DERIVABLE',selected=selected,
                    stats=dict(nodes=calls,work=meter.work,cache_entries=len(cache),macro_tries=macro_tries,
                               matching_cache_entries=len(inst.cache),matching_cache_hits=inst.cache_hits),
                    proposals=records)
    except Stop as error:
        return dict(status='UNKNOWN',reason=str(error),selected=[],stats=dict(nodes=calls,work=meter.work,macro_tries=macro_tries),proposals=records)
