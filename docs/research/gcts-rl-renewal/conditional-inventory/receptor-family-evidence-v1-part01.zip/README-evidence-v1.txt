Receptor-family proof-search experiment,2026-11-03.
The full prospective24-case cohort and Source hashes were saved before any
compilation, truth labels, donor proof discovery, policy training or testing.
Data contain all preparation audits, all64training episodes, all128held-out
lane answers, native proof trees, independent first-order proof checks,
independent family-instance checks, and frozen library/weights. UNKNOWN and
failed searches are retained. No human-written target proof was supplied.
Families are empirical search proposals, not new axioms. Every accepted proof
expands into native primitive rules under its own current hypotheses.

Reproduce in a FRESH copy of this directory, excluding data/,execution logs,
package/ and publication/ generated outputs. Python3.12 stdlib only. Add source/
to sys.path and run experiment_v1.py freeze,then run. Qualification has a separate
reference/qualification_v1.py entry point. Do not overwrite this evidence copy.
The observed pinned runtime path is recorded in data/results-v1.json.gz.
Prepared inputs, training and post-search assurance costs are reported separately;
single sequential experiments do not establish broad speed superiority.

The user expressly approved publication of full task-owned Sources, raw proof
certificates, execution logs and local paths to the existing public Pages site.
No unrelated checkout changes or retired materials research are included.
This archive cut excludes package/ generated outputs and publication/ later
deployment receipts to avoid recursive archives. All original files in the cut
are partitioned across ordinary ZIPs; extract every part to one directory.
