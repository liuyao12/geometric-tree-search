"""Unexecuted Source: specialized finite unit-center Wang point search.

No compiler/verifier imports. All roots have generation zero. No learned marks,
RL, geometric legality test, candidate sampling, or machine-history shortcut.
Input is the ordinary JSON projection of the complete compiler problem record.
"""

VERSION = 'finite-wang-complete-point-search-v3-primitive-nogoods'
SNAPSHOT_SCHEMA = 'finite-wang-complete-graph-snapshot-v1'
LIMIT_KEYS = ('work', 'cells', 'tiles', 'colors', 'candidates', 'data_depth',
              'decisions', 'trace_rows', 'snapshot_items')
INSTANCE_KEYS = ('schema', 'version', 'status', 'palette', 'initial_word', 'machine_steps',
                 'tape_width', 'board_width', 'board_height', 'boundary_NESW',
                 'required_centers', 'admissible_origins', 'fixed_background_marks',
                 'candidate_universe', 'all_root_generations', 'attempted_work',
                 'mathematical_authority', 'executed_source_qualified')


class InputError(Exception):
    pass


class SearchLimit(Exception):
    def __init__(self, reason, *, owner=None):
        self.reason = reason
        self._owner = owner
        super().__init__(reason)


class _Work:
    def __init__(self, check, limits):
        if (not callable(check) or type(limits) is not dict
                or any(type(key) is not str for key in limits) or set(limits) != set(LIMIT_KEYS)):
            raise InputError('explicit check and exact finite limits required')
        for name in LIMIT_KEYS:
            if type(name) is not str or type(limits[name]) is not int or limits[name] < 1:
                raise InputError('positive exact-int limits required')
        if limits['data_depth'] > 128:
            raise InputError('Source recursive input-depth profile is at most128')
        self.check = check
        self.limits = dict(limits)
        self.owner = object()
        self.counts = {'work': 0}
        check()

    def charge(self, kind):
        self.counts['work'] += 1
        self.counts[kind] = self.counts.get(kind, 0) + 1

    def step(self, kind='operations'):
        self.charge(kind)
        if self.counts['work'] > self.limits['work']:
            raise SearchLimit('work', owner=self.owner)
        self.check()

    def bound(self, name, value):
        self.step('bound_checks')
        if value > self.limits[name]:
            raise SearchLimit(name, owner=self.owner)


def _object(value, keys):
    if type(value) is not dict or any(type(k) is not str for k in value) or set(value) != set(keys):
        raise InputError('exact object fields required')


def _int(value, low=0, high=None):
    if type(value) is not int or value < low or (high is not None and value >= high):
        raise InputError('exact integer outside domain')
    return value


def _array(value, size=None):
    if type(value) is not list or (size is not None and len(value) != size):
        raise InputError('ordinary array shape required')
    return value


def _copy(value, w, depth=0, active=None):
    w.step('input_nodes')
    w.bound('data_depth', depth)
    kind = type(value)
    if value is None or kind in (bool, int):
        return value
    if kind is str:
        for character in value:
            w.step('input_characters')
            if 0xD800 <= ord(character) <= 0xDFFF:
                raise InputError('Unicode scalar strings only')
        return value
    if kind in (list, dict):
        if active is None:
            active = set()
        identity = id(value)
        if identity in active:
            raise InputError('cyclic caller container')
        active.add(identity)
        try:
            if kind is list:
                return [_copy(item, w, depth + 1, active) for item in value]
            result = {}
            for key, item in value.items():
                if type(key) is not str:
                    raise InputError('exact string keys required')
                result[_copy(key, w, depth + 1, active)] = _copy(item, w, depth + 1, active)
            return result
        finally:
            active.remove(identity)
    raise InputError('strict ordinary JSON subset; normalize compiler tuples before this boundary')


def _term(value, w):
    w.step('color_terms')
    if type(value) in (str, int):
        return (type(value).__name__, value)
    items = []
    for item in _array(value):
        items.append(_term(item, w))
    return ('array', tuple(items))


def _point(value):
    return tuple(_int(n) for n in _array(value, 2))


def _model(value, w):
    p = _copy(value, w)
    _object(p, INSTANCE_KEYS)
    if (p['schema'] != 'finite-framed-wang-instance-v1'
            or p['version'] != 'finite-framed-wang-spacetime-compiler-v1'
            or p['status'] != 'FINITE_PROBLEM_CANDIDATE'
            or p['mathematical_authority'] is not False or p['executed_source_qualified'] is not False):
        raise InputError('exact untrusted compiler candidate schema required')
    width = _int(p['board_width'], 3)
    height = _int(p['board_height'], 1)
    if width != _int(p['tape_width'], 1) + 2 or height != _int(p['machine_steps']) + 1:
        raise InputError('finite rectangle dimensions disagree')
    if type(p['all_root_generations']) is not int or p['all_root_generations'] != 0:
        raise InputError('all finite roots must have generation zero')
    _int(p['attempted_work'])
    if p['candidate_universe'] != 'every palette tile ID at every admissible origin; no rotations/reflections':
        raise InputError('complete candidate convention required')
    w.bound('cells', width * height)
    origins = []
    for y in range(height):
        for x in range(width):
            w.step('target_cells')
            origins.append((2 * x, 2 * y))
    required = tuple(_point(x) for x in _array(p['required_centers'], len(origins)))
    admitted = tuple(_point(x) for x in _array(p['admissible_origins'], len(origins)))
    if required != tuple(origins) or admitted != required:
        raise InputError('all and only row-major board centers must be required/origins')
    palette = p['palette']
    _object(palette, ('schema', 'version', 'machine', 'color_constructors', 'tiles',
                      'transformations', 'point_profile', 'edge_order', 'mathematical_authority'))
    if (palette['schema'] != 'finite-framed-wang-spacetime-v1'
            or palette['version'] != p['version'] or palette['transformations'] != 'translations_only_2Z2'
            or palette['point_profile'] != 'integer-center-midpoint-translation-only-v1'
            or palette['edge_order'] != 'NESW' or palette['mathematical_authority'] is not False):
        raise InputError('exact translation-only center/midpoint palette required')
    colors = _array(palette['color_constructors'])
    w.bound('colors', len(colors))
    if not colors:
        raise InputError('nonempty finite colors required')
    terms = set()
    for color in colors:
        term = _term(color, w)
        if term in terms:
            raise InputError('duplicate literal color constructor')
        terms.add(term)
    tiles = _array(palette['tiles'])
    w.bound('tiles', len(tiles))
    if not tiles:
        raise InputError('nonempty full palette required')
    edges = []
    for index, tile in enumerate(tiles):
        w.step('palette_tiles')
        _object(tile, ('id', 'kind', 'origin', 'edges_NESW', 't', 'm'))
        if _int(tile['id']) != index or type(tile['kind']) is not str:
            raise InputError('unique ordered palette identities required')
        _array(tile['origin'])
        four = tuple(_int(c, 0, len(colors)) for c in _array(tile['edges_NESW'], 4))
        occupancy = _array(tile['t'], 1)
        _array(occupancy[0], 2)
        if _point(occupancy[0][0]) != (0, 0) or type(occupancy[0][1]) is not int or occupancy[0][1] != 1:
            raise InputError('exact unit-center occupancy only')
        marks = _array(tile['m'], 4)
        for offset, entry, code in zip(((0, -1), (1, 0), (0, 1), (-1, 0)), marks, four):
            w.step('palette_markings')
            _array(entry, 3)
            xy = tuple(_int(n, -1, 2) for n in _array(entry[0], 2))
            if xy != offset or entry[1] != 'edge' or _int(entry[2], 0, len(colors)) != code:
                raise InputError('all four ordered assigned midpoint values required')
        edges.append(four)
    w.bound('candidates', len(origins) * len(edges))
    boundary = _array(p['boundary_NESW'], 4)
    for side, length in zip(boundary, (width, height, width, height)):
        for code in _array(side, length):
            w.step('boundary_values')
            _int(code, 0, len(colors))
    expected_pins = {}
    for y in range(height):
        expected_pins[-1, 2 * y] = boundary[3][y]
        expected_pins[2 * width - 1, 2 * y] = boundary[1][y]
    for x in range(width):
        expected_pins[2 * x, -1] = boundary[0][x]
        expected_pins[2 * x, 2 * height - 1] = boundary[2][x]
    pins = {}
    for row in _array(p['fixed_background_marks'], len(expected_pins)):
        w.step('fixed_marks')
        _array(row, 3)
        xy = tuple(_int(n, -1) for n in _array(row[0], 2))
        code = _int(row[2], 0, len(colors))
        if row[1] != 'edge' or xy in pins or xy not in expected_pins or expected_pins[xy] != code:
            raise InputError('exact complete exterior boundary section required')
        pins[xy] = code
    return dict(origins=tuple(origins), edges=tuple(edges), pins=pins,
                width=width, height=height, palette_ids=tuple(range(len(edges))))


class _Graph:
    def __init__(self, model, w, observe):
        self.model, self.w, self.observe = model, w, observe
        self.occ = [None] * len(model['origins'])
        self.marks = {point: (code, 1) for point, code in model['pins'].items()}
        self.generations = {}
        self.excluded = set()
        self.domains = [set() for point in self.occ]
        self.candidates, self.cmarks, self.dep_t, self.dep_m = [], [], {}, {}
        self.active, self.reverse = [], []
        self.trail, self.trace = [], []
        self.branch_choices = 0
        for point_index, (x, y) in enumerate(model['origins']):
            self.dep_t[point_index] = set()
            for tile_id, four in enumerate(model['edges']):
                w.step('candidate_construction')
                cid = len(self.candidates)
                self.candidates.append((point_index, tile_id))
                marks = tuple((x + dx, y + dy, code) for (dx, dy), code in
                              zip(((0, -1), (1, 0), (0, 1), (-1, 0)), four))
                self.cmarks.append(marks)
                self.dep_t[point_index].add(cid)
                for mx, my, code in marks:
                    w.step('mark_dependency_construction')
                    self.dep_m.setdefault((mx, my), set()).add(cid)
                self.active.append(False)
                self.reverse.append(None)
        for cid in range(len(self.candidates)):
            if self.legal(cid):
                point = self.candidates[cid][0]
                self.active[cid] = True
                self.domains[point].add(cid)
                self.reverse[cid] = point
        self.initial_domains = tuple(tuple(sorted(domain)) for domain in self.domains)

    def legal(self, cid):
        self.w.step('candidate_legality')
        point, tile = self.candidates[cid]
        if self.occ[point] is not None or cid in self.excluded:
            return False
        for mx, my, code in self.cmarks[cid]:
            self.w.step('mark_comparisons')
            existing = self.marks.get((mx, my))
            if existing is not None and existing[0] != code:
                return False
        return True

    def event(self, kind, **values):
        self.w.bound('trace_rows', len(self.trace) + 1)
        self.trace.append(dict(kind=kind, **values))
        key = 'metric_events_' + kind
        self.w.counts[key] = self.w.counts.get(key, 0) + 1

    def snapshot(self, reason):
        """Detached full graph; no internal list/set/dict is handed to observer."""
        w = self.w
        items = 0

        def item():
            nonlocal items
            items += 1
            w.bound('snapshot_items', items)
        points, candidates, marks, forward, reverse, deps = [], [], [], [], [], []
        for i, xy in enumerate(self.model['origins']):
            item()
            points.append([i, list(xy), 0 if self.occ[i] is None else 1, 0])
            forward.append([i, sorted(self.domains[i])])
            for cid in self.domains[i]:
                item()
        for cid, (point, tile) in enumerate(self.candidates):
            item()
            candidates.append([cid, point, tile, self.active[cid]])
            reverse.append([cid, [] if self.reverse[cid] is None else [self.reverse[cid]]])
        for xy in sorted(self.marks):
            item()
            code, count = self.marks[xy]
            marks.append([list(xy), code, count, xy in self.model['pins']])
        for point in range(len(self.occ)):
            item()
            row = sorted(self.dep_t[point])
            for cid in row:
                item()
            deps.append(['t', point, row])
        for xy in sorted(self.dep_m):
            item()
            row = sorted(self.dep_m[xy])
            for cid in row:
                item()
            deps.append(['m', list(xy), row])
        chosen, boundary, excluded = [], [], []
        for cid in sorted(self.generations):
            item()
            point, tile = self.candidates[cid]
            chosen.append([cid, point, tile, self.generations[cid]])
        for point, code in sorted(self.model['pins'].items()):
            item()
            boundary.append([list(point), code])
        for cid in sorted(self.excluded):
            item()
            excluded.append(cid)
        decision, point, options = self.choose()
        return dict(schema=SNAPSHOT_SCHEMA, reason=reason, points=points, candidates=candidates,
                    chosen=chosen, marks=marks, forward=forward, reverse=reverse,
                    dependencies=deps, boundary=boundary, exclusions=excluded,
                    scheduler=dict(kind=decision, point=point, options=list(options)),
                    trail_length=len(self.trail), work=dict(w.counts), authority=False)

    def notify(self, reason):
        if self.observe is not None:
            packet = self.snapshot(reason)
            self.w.step('observer_calls')
            self.observe(packet)  # Direct foreign errors propagate without conversion.

    def choose(self):
        frontier, dead, forced = [], [], []
        for point, occupied in enumerate(self.occ):
            self.w.step('global_census_points')
            if occupied is None:
                degree = len(self.domains[point])
                frontier.append((0, degree, point))
                if degree == 0:
                    dead.append(point)
                elif degree == 1:
                    forced.append(point)
        if dead:
            return 'DEAD', min(dead), ()
        if forced:
            point = min(forced)
            return 'FORCED', point, tuple(sorted(self.domains[point]))
        if not frontier:
            return 'COMPLETE', None, ()
        point = min(frontier)[2]  # Generation first; all explicit finite roots are0.
        return 'BRANCH', point, tuple(sorted(self.domains[point]))

    def place(self, cid, kind):
        if not self.active[cid] or not self.legal(cid):
            raise InputError('graph selected a nonmember candidate')
        point, tile = self.candidates[cid]
        self.w.step('placements')
        self.trail.append(('occ', point, self.occ[point]))
        self.occ[point] = tile
        self.trail.append(('generation', cid, None))
        self.generations[cid] = 1  #1+min(root generation0) on its singleton t-support.
        affected = set(self.dep_t[point])
        for mx, my, code in self.cmarks[cid]:
            self.w.step('mark_assignments')
            xy = (mx, my)
            old = self.marks.get(xy)
            self.trail.append(('mark', xy, old))
            self.marks[xy] = (code, 1 if old is None else old[1] + 1)
            for dependent in self.dep_m[xy]:
                self.w.step('affected_dependencies')
                affected.add(dependent)
        removed, occupancy_removed, mark_removed = [], [], []
        for candidate in sorted(affected):
            if self.active[candidate] and not self.legal(candidate):
                self.w.step('candidate_removals')
                origin = self.candidates[candidate][0]
                self.trail.append(('active', candidate, True))
                self.active[candidate] = False
                self.reverse[candidate] = None
                self.domains[origin].remove(candidate)
                removed.append(candidate)
                (occupancy_removed if origin == point else mark_removed).append(candidate)
        self.event(kind, candidate=cid, point=point, tile_id=tile, generation=1,
                   removed=removed, removed_occupancy=occupancy_removed, removed_mark=mark_removed)

    def branch_place(self, cid, kind):
        self.w.bound('decisions', self.branch_choices + 1)
        self.branch_choices += 1
        self.place(cid, kind)

    def exclude_failed_child(self, cid):
        # Only a completely DEAD/exhausted child reaches this operation.
        # This parent-context exclusion is itself trailed and never global.
        if not self.active[cid] or not self.legal(cid):
            raise InputError('failed child did not restore its exact legal parent')
        self.w.step('proved_child_exclusions')
        point = self.candidates[cid][0]
        self.trail.append(('exclude', cid, None))
        self.excluded.add(cid)
        self.trail.append(('active', cid, True))
        self.active[cid] = False
        self.reverse[cid] = None
        self.domains[point].remove(cid)
        self.event('parent_context_exclusion', candidate=cid, point=point)

    def undo(self, checkpoint):
        # Callback-free critical rollback; attempted work is still monotone.
        # A success must recheck the total work/deadline after this cleanup.
        while len(self.trail) > checkpoint:
            self.w.charge('rollback_operations')
            kind, key, old = self.trail.pop()
            if kind == 'active':
                point = self.candidates[key][0]
                self.active[key] = old
                self.reverse[key] = point
                self.domains[point].add(key)
            elif kind == 'mark':
                if old is None:
                    del self.marks[key]
                else:
                    self.marks[key] = old
            elif kind == 'generation':
                del self.generations[key]
            elif kind == 'exclude':
                self.excluded.remove(key)
            elif kind == 'occ':
                self.occ[key] = old
            else:
                raise InputError('invalid owned rollback opcode')

    def verify_complete_points(self):
        section = {xy: code for xy, code in self.model['pins'].items()}
        for point, tile in enumerate(self.occ):
            self.w.step('whole_target_verification')
            if tile is None:
                raise InputError('unfilled target in candidate solution')
            x, y = self.model['origins'][point]
            for (dx, dy), code in zip(((0, -1), (1, 0), (0, 1), (-1, 0)), self.model['edges'][tile]):
                self.w.step('whole_mark_verification')
                xy = (x + dx, y + dy)
                if xy in section and section[xy] != code:
                    raise InputError('whole point marking conflict')
                section[xy] = code

    def root_check(self):
        for point, domain in enumerate(self.domains):
            self.w.step('root_restoration_checks')
            if self.occ[point] is not None or tuple(sorted(domain)) != self.initial_domains[point]:
                raise InputError('root occupancy/domain restoration failure')
        if self.generations or self.excluded or self.trail or self.marks != {p: (c, 1) for p, c in self.model['pins'].items()}:
            raise InputError('root generation/mark restoration failure')
        for cid, active in enumerate(self.active):
            self.w.step('root_reverse_checks')
            point = self.candidates[cid][0]
            expected = cid in self.domains[point]
            if active is not expected or self.reverse[cid] != (point if expected else None):
                raise InputError('root reverse restoration failure')

    def run(self):
        stack = []
        self.notify('INITIAL')
        while True:
            self.notify('STATE')
            decision, point, options = self.choose()
            self.event('census', decision=decision, point=point, options=list(options))
            if decision == 'COMPLETE':
                self.verify_complete_points()
                placements = []
                for index, tile in enumerate(self.occ):
                    self.w.step('certificate_rows')
                    placements.append(dict(tile_id=tile, origin=list(self.model['origins'][index])))
                return dict(status='TILING_CANDIDATE', certificate=dict(
                    schema='finite-wang-placement-certificate-v1', placements=placements))
            if decision == 'FORCED':
                self.place(options[0], 'forced')
                continue
            if decision == 'BRANCH':
                frame = dict(checkpoint=len(self.trail), point=point, options=options, chosen=options[0])
                stack.append(frame)
                self.branch_place(options[0], 'branch')
                continue
            # A known global dead point is handled before any forced/branch move.
            if stack:
                frame = stack.pop()
                self.undo(frame['checkpoint'])
                self.event('rollback', checkpoint=frame['checkpoint'], point=frame['point'])
                self.notify('ROLLBACK')
                restored_decision, restored_point, restored_options = self.choose()
                self.event('rollback_census', decision=restored_decision, point=restored_point,
                           options=list(restored_options))
                if (restored_decision != 'BRANCH' or restored_point != frame['point']
                        or restored_options != frame['options']):
                    raise InputError('restored global decision differs from exact parent')
                self.exclude_failed_child(frame['chosen'])
                # Re-enter complete global DEAD/FORCED/earliest-generation
                # selection; all other original parent alternatives remain.
                continue
            else:
                return dict(status='FINITE_EXHAUSTED', certificate=None)


def _error_cleanup(graph):
    if graph is not None:
        try:
            graph.undo(0)
        except BaseException:
            # No returned success; preserve an already active caller exception.
            pass


def search(instance, *, check, limits, observe=None):
    """Source-only API: no production/test invocation has been performed.

    Only an own per-call quota produces UNKNOWN; caller exceptions are exact.
    Observe consumes detached data, supplies no choices/pruning, and may refuse.
    """
    w = _Work(check, limits)
    graph = None
    if observe is not None and not callable(observe):
        raise InputError('observe must be callable or None')
    try:
        model = _model(instance, w)
        graph = _Graph(model, w, observe)
        result = graph.run()
        graph.undo(0)
        graph.root_check()
        graph.notify('ROOT_RESTORED')
        w.step('successful_return_check')
        result.update(version=VERSION, scope='SPECIALIZED_FINITE_UNIT_CENTER_WANG',
                      root_restored=True, counts=dict(w.counts), trace=graph.trace,
                      independent_output_verification_required=True, learned_marks=False, RL=False)
        return result
    except SearchLimit as error:
        if type(error) is not SearchLimit or error._owner is not w.owner:
            _error_cleanup(graph)
            raise
        _error_cleanup(graph)
        return dict(status='UNKNOWN', reason=error.reason, version=VERSION,
                    counts=dict(w.counts), trace=[] if graph is None else graph.trace,
                    certificate=None, root_restoration='cleanup attempted; not rechecked after quota',
                    independent_output_verification_required=True)
    except BaseException:
        _error_cleanup(graph)
        raise


# V3 explicit, redundant, same-instance constraints. Never geometric markings/RL.
NOGOOD_VERSION = 'wang-primitive-empty-support-v1'
NOGOOD_SNAPSHOT_SCHEMA = 'finite-wang-complete-graph-snapshot-v2-nogoods'
NOGOOD_LIMIT_KEYS = ('clauses', 'witness_rows', 'proof_work')
_legacy_search = search


class _NogoodGraph(_Graph):
    def __init__(self, model, w, observe, scope, ng_limits, observe_certificate):
        self.scope = scope
        self.ng_limits = dict(ng_limits)
        self.observe_certificate = observe_certificate
        self.certificates = []
        self.certificate_keys = set()
        self.clause_dependencies = {}
        self.blocked = {}
        self.conflicts = ()
        self.knowledge_version = 0
        self.applied_version = 0
        self.activation = 'ACTIVE'
        self.proof_work = 0
        self.witness_rows = 0
        self.last_restore = None
        self.finalized = False
        super().__init__(model, w, observe)

    def _proof_step(self, kind):
        # Attempted proof/inference work never rolls back or renews its allowance.
        self.proof_work += 1
        self.w.charge('nogood_' + kind)
        if self.w.counts['work'] > self.w.limits['work']:
            raise SearchLimit('work', owner=self.w.owner)
        if self.proof_work > self.ng_limits['proof_work']:
            raise SearchLimit('nogood_proof_work', owner=self.w.owner)
        self.w.check()

    def _proof_bound(self, name, value):
        self._proof_step('bound_checks')
        if value > self.ng_limits[name]:
            raise SearchLimit('nogood_' + name, owner=self.w.owner)

    def _require_active(self):
        if self.finalized or self.activation != 'ACTIVE' or self.applied_version != self.knowledge_version:
            raise InputError('no search continuation under suspended or stale knowledge')

    def legal(self, cid):
        return _Graph.legal(self, cid) and cid not in self.blocked

    def _literal_marks(self, cid):
        self._proof_step('literal_placements')
        origin, tile = self.candidates[cid]
        x, y = self.model['origins'][origin]
        result = []
        for (dx, dy), value in zip(((0, -1), (1, 0), (0, 1), (-1, 0)), self.model['edges'][tile]):
            self._proof_step('literal_edge_values')
            result.append(((x + dx, y + dy), value))
        return result

    def _validate_primitive(self, packet):
        # A local full primitive checker, not the independent B checker.
        self._proof_step('certificate_header')
        _object(packet, ('schema', 'scope', 'id', 'point', 'support', 'witnesses'))
        if (packet['schema'] != NOGOOD_VERSION or packet['scope'] != 'CURRENT_INVOCATION_INSTANCE'
                or _int(packet['id']) != len(self.certificates)):
            raise InputError('exact fresh same-instance primitive certificate required')
        point = _int(packet['point'], 0, len(self.occ))
        if self.occ[point] is not None:
            raise InputError('distinguished support obligation must be unfilled')
        support = []
        occupied = set()
        section = dict(self.model['pins'])
        support_marks = {}
        for cid in _array(packet['support']):
            self._proof_step('certificate_support')
            cid = _int(cid, 0, len(self.candidates))
            if support and cid <= support[-1]:
                raise InputError('sorted distinct support candidate identities required')
            origin, tile = self.candidates[cid]
            if origin == point or origin in occupied or cid not in self.generations:
                raise InputError('legal selected support must exclude the distinguished origin')
            occupied.add(origin)
            support.append(cid)
            rows = self._literal_marks(cid)
            support_marks[cid] = dict(rows)
            for xy, value in rows:
                self._proof_step('certificate_support_agreement')
                if xy in section and section[xy] != value:
                    raise InputError('support violates literal primitive marking agreement')
                section[xy] = value
        used = set()
        size = len(self.model['edges'])
        for tile, witness in enumerate(_array(packet['witnesses'], size)):
            self._proof_step('certificate_witness')
            _object(witness, ('tile_id', 'point', 'channel', 'candidate_value',
                              'blocker_kind', 'blocker_cid', 'blocker_value'))
            if _int(witness['tile_id']) != tile or witness['channel'] != 'edge':
                raise InputError('every original ordered tile requires its own raw edge witness')
            xy = tuple(_int(n, -1) for n in _array(witness['point'], 2))
            value = _int(witness['candidate_value'], 0, len(self.scope['palette']['color_constructors']))
            actual = dict(self._literal_marks(point * size + tile))
            if xy not in actual or actual[xy] != value:
                raise InputError('witness is not an assigned original candidate edge')
            blocker = _int(witness['blocker_value'], 0, len(self.scope['palette']['color_constructors']))
            if blocker == value:
                raise InputError('explicit assigned values must actually disagree')
            if witness['blocker_kind'] == 'pin':
                if witness['blocker_cid'] is not None or xy not in self.model['pins'] or self.model['pins'][xy] != blocker:
                    raise InputError('literal permanent boundary blocker required')
            elif witness['blocker_kind'] == 'placement':
                cid = _int(witness['blocker_cid'], 0, len(self.candidates))
                if cid not in support_marks or xy not in support_marks[cid] or support_marks[cid][xy] != blocker:
                    raise InputError('literal selected clause placement blocker required')
                used.add(cid)
            else:
                raise InputError('domain absence or branch exclusions are not primitive witnesses')
        if used != set(support):
            raise InputError('support must be all and only the placement witnesses')

    def learn_primitive_empty_support(self, point):
        self._require_active()
        self._proof_step('learning_attempts')
        if self.occ[point] is not None:
            raise InputError('cannot learn from a filled obligation')
        owners = {}
        for cid in sorted(self.generations):
            for xy, value in self._literal_marks(cid):
                self._proof_step('owner_index_entries')
                owners.setdefault(xy, []).append((cid, value))
        witnesses, support = [], set()
        size = len(self.model['edges'])
        for tile in range(size):
            self._proof_step('all_original_tiles')
            witness = None
            for xy, value in self._literal_marks(point * size + tile):
                self._proof_step('primitive_witness_tests')
                if xy in self.model['pins'] and self.model['pins'][xy] != value:
                    witness = dict(tile_id=tile, point=list(xy), channel='edge', candidate_value=value,
                                   blocker_kind='pin', blocker_cid=None, blocker_value=self.model['pins'][xy])
                    break
                for cid, blocker in owners.get(xy, ()):
                    self._proof_step('placement_witness_tests')
                    if blocker != value:
                        support.add(cid)
                        witness = dict(tile_id=tile, point=list(xy), channel='edge', candidate_value=value,
                                       blocker_kind='placement', blocker_cid=cid, blocker_value=blocker)
                        break
                if witness is not None:
                    break
            if witness is None:
                self.event('primitive_nogood_abstain', point=point, original_tile=tile,
                           reason='no primitive mark rejection; exclusions never count')
                return False
            witnesses.append(witness)
        packet = dict(schema=NOGOOD_VERSION, scope='CURRENT_INVOCATION_INSTANCE',
                      id=len(self.certificates), point=point, support=sorted(support), witnesses=witnesses)
        self._validate_primitive(packet)
        key = (point, tuple(packet['support']))
        if key in self.certificate_keys:
            self.event('primitive_nogood_duplicate', point=point, support=packet['support'][:])
            return False
        self._proof_bound('clauses', len(self.certificates) + 1)
        self._proof_bound('witness_rows', self.witness_rows + len(witnesses))
        # Every fallible copy/index/check/callback precedes activation/publication.
        owned = _copy(packet, self.w)
        offered = _copy(packet, self.w)
        dependencies = {cid: list(ids) for cid, ids in self.clause_dependencies.items()}
        for cid in packet['support']:
            self._proof_step('certificate_index_entries')
            dependencies.setdefault(cid, []).append(packet['id'])
        catalogue = self.certificates + [owned]
        keys = set(self.certificate_keys)
        keys.add(key)
        self.w.step('certificate_observer_calls')
        self.observe_certificate(offered)  # Exact foreign exception; return ignored.
        self._proof_step('certificate_activation')
        self.certificates = catalogue
        self.certificate_keys = keys
        self.clause_dependencies = dependencies
        self.witness_rows += len(witnesses)
        self.knowledge_version += 1
        self._propagate_current_knowledge()
        self.event('primitive_nogood_learned', clause=owned['id'], point=point,
                   support=owned['support'][:], knowledge_version=self.knowledge_version)
        self.notify('KNOWLEDGE_GROWN')
        return True

    def _set_active(self, cid, wanted):
        self._proof_step('incidence_reconciliation')
        if self.active[cid] is wanted:
            return
        origin = self.candidates[cid][0]
        self.trail.append(('active', cid, self.active[cid]))
        self.active[cid] = wanted
        self.reverse[cid] = origin if wanted else None
        if wanted:
            self.domains[origin].add(cid)
        else:
            self.domains[origin].remove(cid)

    def _save_overlay(self):
        self.trail.append(('nogood_overlay', None,
            (self.blocked, self.conflicts, self.applied_version, self.activation)))

    def _propagate_current_knowledge(self):
        if self.finalized:
            raise InputError('final teardown cannot resume without a new invocation')
        blocked, conflicts = {}, []
        size = len(self.model['edges'])
        for packet in self.certificates:
            missing = []
            for cid in packet['support']:
                self._proof_step('selected_support_tests')
                if cid not in self.generations:
                    missing.append(cid)
            if not missing:
                self._proof_step('clause_conflicts')
                if self.occ[packet['point']] is not None:
                    raise InputError('primitive conflicting support cannot coexist with a filled distinguished point')
                conflicts.append(packet['id'])
                for tile in range(size):
                    self._proof_step('conflict_incidence')
                    blocked.setdefault(packet['point'] * size + tile, []).append(packet['id'])
            elif len(missing) == 1:
                self._proof_step('unit_clause_inferences')
                blocked.setdefault(missing[0], []).append(packet['id'])
        new = {cid: tuple(ids) for cid, ids in blocked.items()}
        affected = sorted(set(self.blocked) | set(new))
        self._proof_step('overlay_publication')
        self._save_overlay()
        self.blocked, self.conflicts = new, tuple(conflicts)
        self.applied_version, self.activation = self.knowledge_version, 'ACTIVE'
        for cid in affected:
            self._set_active(cid, _Graph.legal(self, cid) and cid not in self.blocked)

    def place(self, cid, kind):
        self._require_active()
        _Graph.place(self, cid, kind)  # Original physical incremental update.
        self._propagate_current_knowledge()

    def undo(self, checkpoint):
        # Callback-free exact cleanup; knowledge catalogue is monotone, not trailed.
        while len(self.trail) > checkpoint:
            self.w.charge('rollback_operations')
            kind, key, old = self.trail.pop()
            if kind == 'active':
                point = self.candidates[key][0]
                self.active[key] = old
                self.reverse[key] = point if old else None
                if old:
                    self.domains[point].add(key)
                else:
                    self.domains[point].remove(key)
            elif kind == 'nogood_overlay':
                self.blocked, self.conflicts, self.applied_version, self.activation = old
            elif kind == 'mark':
                if old is None:
                    del self.marks[key]
                else:
                    self.marks[key] = old
            elif kind == 'generation':
                del self.generations[key]
            elif kind == 'exclude':
                self.excluded.remove(key)
            elif kind == 'occ':
                self.occ[key] = old
            else:
                raise InputError('invalid owned rollback opcode')

    def _physical_core(self):
        # Full values, never digest/identity comparison. Domains follow raw legality.
        occ, marks, generations, excluded = [], [], [], []
        for value in self.occ:
            self._proof_step('physical_core_cells')
            occ.append(value)
        for xy in sorted(self.marks):
            self._proof_step('physical_core_marks')
            marks.append((xy, self.marks[xy]))
        for cid in sorted(self.generations):
            self._proof_step('physical_core_generations')
            generations.append((cid, self.generations[cid]))
        for cid in sorted(self.excluded):
            self._proof_step('physical_core_exclusions')
            excluded.append(cid)
        return (tuple(occ), tuple(marks), tuple(generations), tuple(excluded))

    def _suspend_for_replay(self):
        self._proof_step('knowledge_suspensions')
        self._save_overlay()
        self.blocked, self.conflicts = {}, ()
        self.applied_version, self.activation = None, 'SUSPENDED_ROLLBACK_REPLAY'
        # Rule-version barrier: full original physical incidence, not stale domains.
        for cid in range(len(self.candidates)):
            self._set_active(cid, _Graph.legal(self, cid))

    def snapshot(self, reason):
        packet = _Graph.snapshot(self, reason)
        packet['schema'] = NOGOOD_SNAPSHOT_SCHEMA
        knowledge = dict(mode='primitive_empty_support', version=self.knowledge_version,
            applied_version=self.applied_version, activation=self.activation,
            clauses=[], blocked=[], conflicts=list(self.conflicts), dependencies=[],
            last_restore=self.last_restore, scheduler_evaluation_only=self.activation != 'ACTIVE')
        for certificate in self.certificates:
            self.w.step('snapshot_clause_summaries')
            knowledge['clauses'].append([certificate['id'], certificate['point'], certificate['support'][:]])
        for cid in sorted(self.blocked):
            self.w.step('snapshot_clause_blocks')
            knowledge['blocked'].append([cid, list(self.blocked[cid])])
        for cid in sorted(self.clause_dependencies):
            self.w.step('snapshot_clause_dependencies')
            knowledge['dependencies'].append([cid, list(self.clause_dependencies[cid])])
        packet['knowledge'] = _copy(knowledge, self.w)
        # New complete-packet occurrence cap, including all knowledge metadata.
        pending, items = [packet], 0
        while pending:
            value = pending.pop()
            self.w.step('complete_snapshot_occurrences')
            items += 1
            self.w.bound('snapshot_items', items)
            if type(value) is dict:
                for key, child in value.items():
                    pending.append(key)
                    pending.append(child)
            elif type(value) is list:
                pending.extend(value)
        return packet

    def finish_root(self):
        self.undo(0)
        self.activation, self.applied_version = 'SUSPENDED_FINAL_CLEANUP', None
        self.blocked, self.conflicts = {}, ()
        # Explicit final teardown: catalogue persists; no later search continuation.
        for cid in range(len(self.candidates)):
            self._proof_step('final_base_rebuild')
            wanted = _Graph.legal(self, cid)
            point = self.candidates[cid][0]
            self.active[cid] = wanted
            self.reverse[cid] = point if wanted else None
            if wanted:
                self.domains[point].add(cid)
            else:
                self.domains[point].discard(cid)
        _Graph.root_check(self)
        self.finalized = True
        self.notify('ROOT_RESTORED')

    def run(self):
        self._require_active()
        stack = []
        self.notify('INITIAL')
        while True:
            self._require_active()
            self.notify('STATE')
            decision, point, options = self.choose()
            self.event('census', decision=decision, point=point, options=list(options))
            if decision == 'COMPLETE':
                self.verify_complete_points()
                placements = []
                for index, tile in enumerate(self.occ):
                    self.w.step('certificate_rows')
                    placements.append(dict(tile_id=tile, origin=list(self.model['origins'][index])))
                return dict(status='TILING_CANDIDATE', certificate=dict(
                    schema='finite-wang-placement-certificate-v1', placements=placements))
            if decision == 'FORCED':
                self.place(options[0], 'forced')
                continue
            if decision == 'BRANCH':
                frame = dict(checkpoint=len(self.trail), point=point, options=options, chosen=options[0],
                             knowledge_version=self.knowledge_version, physical_core=self._physical_core())
                stack.append(frame)
                self.branch_place(options[0], 'branch')
                continue
            self.learn_primitive_empty_support(point)  # May abstain, never trusts exclusions.
            if not stack:
                return dict(status='FINITE_EXHAUSTED', certificate=None)
            frame = stack.pop()
            current_version = self.knowledge_version
            self.undo(frame['checkpoint'])
            if self._physical_core() != frame['physical_core']:
                raise InputError('original physical/context core failed exact rollback')
            self._suspend_for_replay()
            self.last_restore = dict(checkpoint=frame['checkpoint'], saved_version=frame['knowledge_version'],
                current_version=current_version, physical_core_equal=True,
                knowledge_changed=current_version != frame['knowledge_version'])
            self.event('rollback', checkpoint=frame['checkpoint'], point=frame['point'],
                       saved_version=frame['knowledge_version'], current_version=current_version)
            self.notify('ROLLBACK_PHYSICAL')  # Explicit non-active rule-version barrier.
            self._propagate_current_knowledge()
            self.notify('ROLLBACK_REPLAYED')
            decision_now, point_now, options_now = self.choose()
            self.event('rollback_census', decision=decision_now, point=point_now, options=list(options_now),
                       original_parent_point=frame['point'], original_parent_options=list(frame['options']))
            cid = frame['chosen']
            if self.active[cid] and self.legal(cid):
                self.exclude_failed_child(cid)
            else:
                if not _Graph.legal(self, cid) or cid not in self.blocked:
                    raise InputError('restored failed child lost availability without a certified clause')
                self.event('failed_child_already_certified', candidate=cid, knowledge_version=self.knowledge_version)
            # Always re-enter global DEAD/FORCED/earliest with current knowledge.


def search(instance, *, check, limits, observe=None, nogoods='off',
           nogood_limits=None, observe_certificate=None):
    """V3 off/on entry. New redundant clauses, not markings or RL.

    On requires a separate charged certificate observer before activation.
    Its return is ignored: it supplies no candidates, constraints or truth flag.
    Caller must bind it to the independently reviewed certificate checker.
    """
    if type(nogoods) is not str or nogoods not in ('off', 'primitive_empty_support'):
        raise InputError('explicit off/on nogood mode required')
    if nogood_limits is not None:
        if (type(nogood_limits) is not dict or any(type(k) is not str for k in nogood_limits)
                or set(nogood_limits) != set(NOGOOD_LIMIT_KEYS)):
            raise InputError('exact finite nogood profile required')
        for name in NOGOOD_LIMIT_KEYS:
            if type(nogood_limits[name]) is not int or nogood_limits[name] < 1:
                raise InputError('positive exact-int nogood limits required')
        nogood_limits = dict(nogood_limits)
    if observe_certificate is not None and not callable(observe_certificate):
        raise InputError('certificate observer must be callable or None')
    if nogoods == 'off':
        # Matched arms may pass identical profile/observers; off learns nothing.
        result = _legacy_search(instance, check=check, limits=limits, observe=observe)
        result.update(nogood_mode='off', nogood_version=NOGOOD_VERSION,
                      nogood_certificates=[], knowledge_version=0,
                      nogood_limits=nogood_limits, proof_work=0)
        return result
    if nogood_limits is None or observe_certificate is None:
        raise InputError('on requires finite nogood profile and certificate observer')
    w = _Work(check, limits)
    graph = None
    if observe is not None and not callable(observe):
        raise InputError('observe must be callable or None')
    scope = None
    try:
        scope = _copy(instance, w)  # Full owned literal scope, not a digest/cache key.
        model = _model(scope, w)
        graph = _NogoodGraph(model, w, observe, scope, nogood_limits, observe_certificate)
        result = graph.run()
        graph.finish_root()
        w.step('successful_return_check')
        result.update(version=VERSION, scope='SPECIALIZED_FINITE_UNIT_CENTER_WANG',
            root_restored=True, counts=dict(w.counts), trace=graph.trace,
            independent_output_verification_required=True, learned_marks=False, RL=False,
            nogood_mode=nogoods, nogood_version=NOGOOD_VERSION, nogood_scope=scope,
            nogood_certificates=graph.certificates, knowledge_version=graph.knowledge_version,
            nogood_limits=dict(graph.ng_limits), witness_rows=graph.witness_rows,
            proof_work=graph.proof_work, final_activation=graph.activation,
            restoration_scope='original physical/context graph restored; monotone proof catalogue retained inactive')
        return result
    except SearchLimit as error:
        if type(error) is not SearchLimit or error._owner is not w.owner:
            _error_cleanup(graph)
            raise
        _error_cleanup(graph)
        return dict(status='UNKNOWN', reason=error.reason, version=VERSION,
            counts=dict(w.counts), trace=[] if graph is None else graph.trace,
            certificate=None, root_restoration='cleanup attempted; not rechecked after quota',
            independent_output_verification_required=True, nogood_mode=nogoods, nogood_version=NOGOOD_VERSION,
            nogood_scope=scope, nogood_certificates=[] if graph is None else graph.certificates,
            knowledge_version=0 if graph is None else graph.knowledge_version,
            proof_work=0 if graph is None else graph.proof_work,
            nogood_limits=nogood_limits, witness_rows=0 if graph is None else graph.witness_rows)
    except BaseException:
        _error_cleanup(graph)
        raise
