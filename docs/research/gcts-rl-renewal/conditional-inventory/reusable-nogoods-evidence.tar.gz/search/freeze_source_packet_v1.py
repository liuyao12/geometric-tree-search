"""Raw/AST/ordinary metadata author. No subject import or function evaluation."""
import ast
import difflib
import hashlib
import json
from pathlib import Path

D=Path('/private/tmp/gcts-wang-nogood-search-library-20261019')
P=Path('/private/tmp/gcts-wang-search-library-20261019/wang_point_search_v2.py')
F=D/'wang_point_search_v3.py'

def pin(path):
    path=Path(path).resolve();raw=path.read_bytes()
    return dict(path=str(path),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))

def save(name,value):
    path=D/name
    with path.open('xb')as stream:stream.write(json.dumps(value,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False).encode()+b'\n')
    return pin(path)

old=P.read_text();extension=(D/'nogood-extension-source.txt').read_text()
assert pin(P)['sha256']=='7c09bfe44ab2288066f4e71f4516763376c4b2cddda7acfdb99220f5e4008d2d'
# Duplicate clauses need no new storage allowance; all full proof work remains charged.
a="        self._proof_bound('clauses', len(self.certificates) + 1)\n        self._proof_bound('witness_rows', self.witness_rows + len(witnesses))\n"
assert extension.count(a)==1;extension=extension.replace(a,'')
a="        # Every fallible copy/index/check/callback precedes activation/publication.\n"
assert extension.count(a)==1;extension=extension.replace(a,"        self._proof_bound('clauses', len(self.certificates) + 1)\n        self._proof_bound('witness_rows', self.witness_rows + len(witnesses))\n"+a)
(D/'nogood-extension-source.txt').write_text(extension)
new=old.replace("VERSION = 'finite-wang-complete-point-search-v2'","VERSION = 'finite-wang-complete-point-search-v3-primitive-nogoods'")+extension
F.write_text(new)
t=ast.parse(new,filename=str(F));compile(t,str(F),'exec')
prefix=new[:-len(extension)]
assert prefix.replace("VERSION = 'finite-wang-complete-point-search-v3-primitive-nogoods'","VERSION = 'finite-wang-complete-point-search-v2'")==old
assert not any(isinstance(n,(ast.Import,ast.ImportFrom,ast.Yield,ast.YieldFrom,ast.AsyncFunctionDef,ast.Await))for n in ast.walk(t))
checks=[
 'Entire V2 text prefix retained except VERSION; exact inverse restoration checked.',
 'Off uses original _legacy_search; unchanged generator/Graph/scheduler/rollback/whole-point bodies.',
 'On requires exact three finite nogood limits and independent certificate observer; off accepts identical supplied profile/observer without invoking certification.',
 'Every original tile enumerated; no primitive rejection from parent exclusions or effective domains.',
 'Support is current chosen cid, unique/sorted, excludes distinguished origin, mutually literal-compatible with pins.',
 'Full candidate/blocker mark values checked including0; all and only used placement supports retained.',
 'Own primitive validation and detached independent observer precede activation; observer return is ignored.',
 'Inference missing count uses selected generations, not active domain membership.',
 'Every candidate effect updates single active/forward/reverse graph and is trailed; all original static dependencies remain.',
 'Callback-free undo restores both oldTrue and oldFalse activity and original mark/refcount/generation/context deltas.',
 'New knowledge survives rollback; explicit physical suspension/rebuild then current-version replay precedes the next decision.',
 'Saved physical core compared by full tuples; independent B must compare offered full graphs, not trust own flag.',
 'Final explicit overlay teardown restores original whole graph/trail0; proof catalogue persists, continuation is disabled.',
 'Old global work allowance and external check remain; proof quota uses same per-call private owner and monotone attempted costs.',
 'Snapshot knowledge data detached; complete final snapshot occurrences additionally bounded by existing snapshot_items.',
 'Full same-instance scope and completed certificate prefix retained on own UNKNOWN, never proof success.',
 'Foreign exceptions propagate exactly after callback-free cleanup; no generator wrappers.',
 'No imports, target invocations, callback invocations, simulations or fixture execution during authoring.'
]
for name,left,right in [('search-v2-to-v3.patch',old,new),('search-v3-to-v2.patch',new,old)]:
    with(D/name).open('x')as stream:stream.write(''.join(difflib.unified_diff(left.splitlines(True),right.splitlines(True),fromfile='search.py',tofile='search.py')))
common=dict(author_identity='/root/conventional_library',source_only=True,scientific_calls=0,fixture_calls=0,subject_imports=0,
    scientific_acceptance=False,actual_execution_authorized=False)
api=save('API-v1.json',dict(schema='wang-primitive-nogood-search-API-v1',**common,Source=pin(F),parent=pin(P),
    entry="search(instance,*,check,limits,observe=None,nogoods='off',nogood_limits=None,observe_certificate=None)",
    modes=['off','primitive_empty_support'],version='finite-wang-complete-point-search-v3-primitive-nogoods',
    old_limits='Exact V2 nine-key limits unchanged. Off with omitted new arguments delegates directly. Matched off/on can pass identical new limits/observer; off never certifies.',
    nogood_limits=dict(clauses='maximum stored completed certificates',witness_rows='maximum TOTAL stored all-tile witness rows',proof_work='maximum cumulative attempted new derivation/validation/inference/replay operations'),
    limit_rules='All3 exact positive builtin ints; required on, optional off. Each new proof operation also charges old total work/check. Reaching a quota is private-owner UNKNOWN, not exhaustion. No fixed numbers selected here.',
    callback='observe_certificate(detached_packet): mandatory on. Own full primitive validation first; callback must raise unless independent B certify returns VALID_SAME_INSTANCE_PRIMITIVE_NOGOOD. No callback return/boolean becomes authority. Exact exceptions propagate and packet is not activated if callback fails.',
    certificate=dict(keys=['schema','scope','id','point','support','witnesses'],schema='wang-primitive-empty-support-v1',scope='CURRENT_INVOCATION_INSTANCE',
        id='zero-based contiguous accepted catalogue index',point='required origin index, unfilled at derivation',support='sorted unique actually selected candidate IDs, excluding point; empty is allowed if pins alone block all tiles',
        witnesses='One exact row per ALL original palette IDs, in tile-ID order.',
        witness_keys=['tile_id','point','channel','candidate_value','blocker_kind','blocker_cid','blocker_value'],
        witness_domain="point=[mx,my];channel='edge';blocker_kind='pin'|'placement';blocker_cid=null|support cid. Both exact assigned color IDs, including0, must disagree at the same literal midpoint."),
    scope_custody='Scope string is not an instance identity. Every independent certification must receive exact same complete current instance as separate argument; result.nogood_scope retains complete owned ordinary input. No cross-invocation import/cache/reuse API.',
    result_additions=['nogood_mode','nogood_version','nogood_certificates','knowledge_version','nogood_limits','proof_work'],
    on_result_additions=['nogood_scope','witness_rows','final_activation','restoration_scope'],
    UNKNOWN='Own work/extra-cap UNKNOWN retains complete accepted certificate prefix/full scope but no tiling proof or certified restored state; foreign failures return no success.',
    geometry='Certified redundant nogoods only. No additional m-values, geometric gadgets, learned hypotheses/RL, machine-specific facts or answer routes.'))
snapshot=save('snapshot-API-v2.json',dict(schema='finite-wang-nogood-snapshot-API-v2',**common,Source=pin(F),
    off='Original finite-wang-complete-graph-snapshot-v1 and complete original15 fields, unchanged parent body.',
    on_schema='finite-wang-complete-graph-snapshot-v2-nogoods',
    on_keys=['schema','reason','points','candidates','chosen','marks','forward','reverse','dependencies','boundary','exclusions','scheduler','trail_length','work','authority','knowledge'],
    inherited_fields='Same complete V1 literal representations/cid=origin_index*palette_size+tileID. Forward/reverse/candidate activity are the SINGLE current graph, including overlay whenever ACTIVE. Exclusions remain only original parent-context exclusions.',
    knowledge_keys=['mode','version','applied_version','activation','clauses','blocked','conflicts','dependencies','last_restore','scheduler_evaluation_only'],
    knowledge=dict(mode='primitive_empty_support',version='len accepted catalogue, monotone',applied_version='version if ACTIVE, null if suspended',
        activation=['ACTIVE','SUSPENDED_ROLLBACK_REPLAY','SUSPENDED_FINAL_CLEANUP'],
        clauses='[[id,point,[sorted support cids]],...] ordered by contiguous id. Full packets separately callback-retained and returned; oracle receives certificates=complete ordinary accepted list.',
        blocked='[[cid,[ordered clauseIDs]],...] sorted cid, includes inactive/physically illegal cids. Unit missing1 blocks its single absent SUPPORT cid. Missing0 blocks ALL tile candidates at distinguished point.',
        conflicts='ordered clause IDs whose entire support is actually selected; includes empty support',
        dependencies='[[supportcid,[ordered containing clauseIDs]],...] sorted cid. Independent of original t/m dependency fields, which remain complete.',
        last_restore='null initially; else exact {checkpoint,saved_version,current_version,physical_core_equal:true,knowledge_changed:bool}. Own flag is not independent evidence.',
        scheduler_evaluation_only='true iff suspended. Snapshot scheduler is descriptive complete census only; no placement/run can continue from suspended/final graph.'),
    reasons=dict(INITIAL='ACTIVE version0',STATE='ACTIVE current knowledge before each decision',KNOWLEDGE_GROWN='new complete callback-accepted catalogue activated/reconciled',
        ROLLBACK_PHYSICAL='original occupied/mark/refcount/generation/context-exclusion core restored by full value, overlay suspended and ALL physical/base-exclusion incidence rebuilt; nondecision barrier',
        ROLLBACK_REPLAYED='all current persistent clauses replayed, ACTIVE current effective domains, no old-options-equality assumption',
        ROOT_RESTORED='final teardown; original exact initial mutable graph/marks/gens/exclusions/incidence/trail0 checked, overlay inactive, accepted catalogue/version retained. No resumption API.'),
    baseline_pairing='Physical comparison projects points/chosen/marks/boundary/context exclusions plus complete physical incidence independently rederived from raw data; effective domains compare only under equal active knowledge. Never compare old parent effective options to newer replay as if versions were equal. Root worker/B oracle must version its pairing accordingly.',
    counters='work is detached at inherited parent snapshot cutoff, BEFORE extra knowledge-copy/count work and observer checkpoint; not terminal totals. Existing snapshot_items ALSO bounds complete on-packet occurrence traversal.',
    audit='B independent certify required via observer before activation; B audit_snapshot(instance,snapshot,certificates=full accepted packets,check,limits) must recheck bodies and derive current consequences. Current Source has no independent runtime pass.'))
contract=save('Source-contract-v1.json',dict(schema='wang-primitive-nogood-Source-contract-v1',**common,Source=pin(F),parent=pin(P),API=api,snapshot_API=snapshot,
    authority='Search remains proposer; complete final raw-palette/point/global TM verifier mandatory. Own primitive checker is same author and not independent mathematical certification.',
    proof='Every original tile covering unfilled p has an exact primitive disagreement with fixed pins or selected compatible support C outside p. Any complete tiling containing C must fill p with one of those original tiles, contradiction. Hence forbidding conjunction C is redundant. Any failure to obtain every witness abstains; no exclusion/domain-absence witness is permitted.',
    propagation='All support selected implies distinguished-point DEAD. All but one selected forbids only the remaining support placement. Uses selected identities only. Recomputes finite clause consequences, updates only indexed affected active incidence except full version-barrier/final rebuilds. Original global DEAD/FORCED/earliest scheduler and base fallback remain.',
    rollback='Original mutable t/m/refcounts/generations/context exclusions exactly restored first. Effective graph separately rebuilt/replayed at latest persistent version before decision. Overlay changes and both directions of activity trailed. Checkpoint core is full value; no hash comparison.',
    teardown='Final root restore explicitly deactivates overlay and fully reconstructs/checks original graph with trail0; catalogue is monotone and separately visible. Pure final descriptive census is allowed; _require_active blocks run/place and finalized blocks replay.',
    cost='New proof limit cumulative per invocation; old totalwork/callback/caps retained. Complete scope copies, full proof retention, physical rollback census/rebuilds, clause rescans, observer checks and snapshot metadata all cost time/memory/output. No prediction of fitting original680+55 or improvement.',
    gaps=['Zero functions/fixtures/simulations executed. No actual authorization or consumed-grant retry.',
        'B independent certificate/oracle Source and Root worker/baseline pairing adaptation required before any activation.',
        'Ordinary graph/certificate/trace output can inflate limits; none raised. Global worker wall/RAM/output guards remain Root-owned.',
        'No geometric marking, learned m-values, RL or fixed FOL checker/palette claim.'],
    ancestry='Library authored original compiler/search/verifier and this successor plus earlier proof/evidence code. Author checks are not independent own Source certification; C/Root/B supply distinct scrutiny.'))
audit=save('author-static-audit-v1.json',dict(schema='wang-primitive-nogood-author-static-audit-v1',**common,Source=pin(F),
    raw_prefix_exact_except_VERSION=True,raw_inverse_exact=True,checks=checks,check_count=len(checks),unused_compiles=2,
    patches=[pin(D/'search-v2-to-v3.patch'),pin(D/'search-v3-to-v2.patch')],
    future_qualification=['Off V2 behavioral parity; independent exhaustive domains every state both modes.',
        'Primitive certificates incl assigned0, pins-only empty support, no-witness/exclusion-only abstention, incompatible/malformed/tampered witness refusals.',
        'Unit/conflict consequences in complete domains, different knowledge-version parent rollback, whole final teardown equality, cold proof-store scope.',
        'Private quotas and callback RuntimeError/ValueError/StopIteration exact objects at certificate and snapshot seams; no UNKNOWN pruning or false exhaustion.'],
    statement='All listed future cases unexecuted. Static checks are author argument, not test outcomes.'))
h=save('handoff-v1.json',dict(schema='wang-primitive-nogood-search-handoff-v1',**common,Source=pin(F),API=api,
    snapshot_API=snapshot,Source_contract=contract,author_static_audit=audit,author_Source=pin(__file__),
    parent=pin(P),original_snapshot_API=pin('/private/tmp/gcts-wang-search-library-20261019/snapshot-API-v1.json'),
    status='FROZEN_SOURCE_ONLY_PENDING_INDEPENDENT_REVIEW_AND_EXACT_ROOT_GRANT',tools_stopped_after_handoff=True))
print(json.dumps(dict(Source=pin(F),API=api,snapshot_API=snapshot,handoff=h),sort_keys=True))
