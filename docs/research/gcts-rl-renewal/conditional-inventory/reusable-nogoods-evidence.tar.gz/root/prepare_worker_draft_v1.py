"""Ordinary Source author only: read/copy/replace text; no subject import/call."""
from pathlib import Path

D=Path('/private/tmp/gcts-wang-receptor-ROOT-20261019-v1')
old=Path('/private/tmp/gcts-wang-calibration-worker-20261019/qualify_wang_calibration_worker_v2.py').read_text()

def change(before,after):
    global old
    if old.count(before)!=1:raise ValueError('nonunique Source edit: '+before[:90])
    old=old.replace(before,after)

change("VERSION = 'complete-wang-calibration-worker-v2'", "VERSION = 'complete-wang-reusable-nogood-comparison-worker-v1'")
change("    'search': ('7c09bfe44ab2288066f4e71f4516763376c4b2cddda7acfdb99220f5e4008d2d', 24685),", "    'search': ('SEARCH_SOURCE_PIN_PENDING', 0),")
change("    'oracle': ('f77f395b1e8b3731dc8fc64deb6cd82c970009e088b91776a18b2e547af97369', 12476),", "    'oracle': ('ORACLE_SOURCE_PIN_PENDING', 0),")
change("        placements=1024,exclusions=1000000,trail_entries=10000000,metadata_entries=1024),", "        placements=1024,exclusions=1000000,trail_entries=10000000,metadata_entries=1024,\n        clauses=256,clause_literals=4096,witness_rows=1000000,proof_work=400000000),")
change('CHECKPOINT_LIMIT = 400000000', "NOGOOD_LIMITS = dict(clauses=256,witness_rows=1000000,proof_work=400000000)\nMODES = ('off','primitive_empty_support')\nCHECKPOINT_LIMIT = 400000000")
change('        self.component_limits=clone(COMPONENT_LIMITS)', '''        self.component_limits=clone(COMPONENT_LIMITS)
        self.mode=None;self.inclusive_wall_ns={};self.phase_receipts=[]

    def elapsed(self,key,began):
        # Inclusive API wall time: nested oracle calls are inside search time.
        # These intervals must never be summed as exclusive component costs.
        elapsed=NOW()-began
        self.inclusive_wall_ns[key]=self.inclusive_wall_ns.get(key,0)+elapsed

    def phase(self,event):
        self.check();need(len(self.phase_receipts)<2048,'bounded passive phase metadata')
        self.phase_receipts.append(dict(event=event,stage=self.stage,active=self.active,
            elapsed_from_runner_entry_ns=NOW()-self.began,root_check_calls=self.root_calls,
            completed_cases=len(self.rows),diagnostic_groups=len(self.diagnostics)))''')
change("        try:\n            value=action()\n        except BaseException as error:\n            self.raised[key]", "        began=NOW()\n        try:\n            value=action()\n        except BaseException as error:\n            self.elapsed(key,began)\n            self.raised[key]")
change('        self.fault_gate();self.guard()\n        expected=before if expected_after is None else canonical(expected_after)\n        self.policy(lambda:need(canonical(data()if callable(data)else data)==expected,\'full literal call arguments unchanged\'))', '        self.elapsed(key,began)\n        self.fault_gate();self.guard()\n        expected=before if expected_after is None else canonical(expected_after)\n        self.policy(lambda:need(canonical(data()if callable(data)else data)==expected,\'full literal call arguments unchanged\'))')
start=old.index('def observer_for(');end=old.index('\n\ndef invoke_verifier(',start)
old=old[:start]+'''def observer_for(s,instance,observations,certificates,keep_first=False):
    oracle=s.modules['oracle'];initial=None;branches=[];first=None;restored=False
    replay_pending=None;terminal=False
    def observe(snapshot):
        nonlocal initial,first,restored,replay_pending,terminal
        s.check();need(not terminal,'no continuation after final knowledge-disabled teardown')
        limits=base_limits(s,'oracle')
        audit=s.call('oracle','audit_snapshot',dict(instance=instance,snapshot=snapshot,
            limits=limits,certificates=certificates),lambda:oracle.audit_snapshot(
            instance,snapshot,check=s.check,limits=limits,certificates=certificates))
        need(audit['status']=='EXACT_FINITE_POINT_CENSUS_MATCH','independent full graph census')
        # The independent oracle must supply both complete effective and complete
        # original physical/context graphs. Never obtain restoration by silently
        # dropping changed domain entries from an effective graph.
        census=audit['census'];physical=audit['physical_context_census']
        body=canonical(census);core=canonical(physical);packet=canonical(snapshot)
        compared=False;effective_compared=False;reason=snapshot['reason']
        knowledge=snapshot.get('knowledge');version=0 if knowledge is None else knowledge['version']
        if reason=='INITIAL':
            need(initial is None,'one initial graph');initial=core
            if keep_first:first=clone(snapshot)
        elif reason=='STATE'and snapshot['scheduler']['kind']=='BRANCH':
            need(replay_pending is None,'all rollback knowledge reapplied before branch')
            branches.append(dict(physical=core,effective=body,version=version))
        elif reason=='ROLLBACK':
            need(branches and knowledge is None,'off-mode parent branch retained')
            saved=branches.pop();need(body==saved['effective']and core==saved['physical'],
                'off-mode complete typed restoration equality');compared=True;effective_compared=True
        elif reason=='ROLLBACK_PHYSICAL':
            need(branches and replay_pending is None and knowledge is not None and
                knowledge['activation']=='SUSPENDED_ROLLBACK_REPLAY','explicit suspended restoration phase')
            saved=branches.pop();need(core==saved['physical'],'full original physical/context/trail restoration')
            replay_pending=saved;compared=True
        elif reason=='ROLLBACK_REPLAYED':
            need(replay_pending is not None and knowledge is not None and
                knowledge['activation']=='ACTIVE'and core==replay_pending['physical'],
                'full current-version knowledge reapplication without physical mutation')
            if version==replay_pending['version']:
                need(body==replay_pending['effective'],'unchanged-knowledge full effective restoration')
                effective_compared=True
            replay_pending=None;compared=True
        elif reason=='ROOT_RESTORED':
            need(initial is not None and core==initial,'full original initial/restored mutable graph equality')
            need(knowledge is None or (knowledge['activation']=='SUSPENDED_FINAL_CLEANUP'and
                knowledge['scheduler_evaluation_only']is True),'explicit terminal inactive inventory')
            restored=True;compared=True;terminal=True;branches.clear();replay_pending=None
        elif reason in('STATE','KNOWLEDGE_GROWN'):
            need(replay_pending is None,'no stable active observation before knowledge replay')
        else:raise PolicyFailure('undeclared snapshot lifecycle reason')
        observations.append(dict(sequence=len(observations),reason=reason,
            snapshot=dict(bytes=len(packet),sha256=hashlib.sha256(packet).hexdigest()),
            census=dict(bytes=len(body),sha256=hashlib.sha256(body).hexdigest()),
            physical_context_census=dict(bytes=len(core),sha256=hashlib.sha256(core).hexdigest()),
            audit_work=audit['audit_work'],scheduler=clone(snapshot['scheduler']),
            trail_length=snapshot['trail_length'],full_value_restoration_compared=compared,
            full_effective_value_restoration_compared=effective_compared,
            knowledge_version=version,knowledge_activation=None if knowledge is None else knowledge['activation']))
    def summary():return dict(root_restored=restored,first_snapshot=first)
    return observe,summary


def invoke_search(s,instance,observations,variant=None,check=None,observe_override=None,keep_first=False):
    module=s.modules['search'];oracle=s.modules['oracle'];limits=base_limits(s,'search',variant)
    certificates=[];certificate_audits=[];nogood_limits=clone(NOGOOD_LIMITS)
    observer,summary=observer_for(s,instance,observations,certificates,keep_first)
    callback=s.check if check is None else check
    def certify(packet):
        s.check();proof_limits=base_limits(s,'oracle')
        audit=s.call('oracle','certify',dict(instance=instance,packet=packet,limits=proof_limits),
            lambda:oracle.certify(instance,packet,check=s.check,limits=proof_limits))
        need(audit['status']=='VALID_SAME_INSTANCE_PRIMITIVE_NOGOOD','independent primitive clause acceptance before activation')
        need(canonical(audit['clause'])==canonical({k:packet[k]for k in('id','point','support','witnesses')}),
            'full independently checked certificate join')
        certificates.append(clone(packet));certificate_audits.append(audit)
    def offered(snapshot):
        observer(snapshot)
        if observe_override is not None:observe_override(snapshot)
    value=s.call('search','search',dict(instance=instance,limits=limits,nogoods=s.mode,nogood_limits=nogood_limits),
        lambda:module.search(instance,check=callback,limits=limits,observe=offered,
            nogoods=s.mode,nogood_limits=nogood_limits,observe_certificate=certify))
    state=summary();state.update(certificates=certificates,certificate_audits=certificate_audits)
    return value,state
''' +old[end:]
# Existing standalone oracle diagnostics require the same explicit empty proof
# inventory. Their base snapshot is INITIAL, before any clause is accepted.
change("lambda:oracle.audit_snapshot(base['instance'],base['snapshot'],check=fault,limits=limits))", "lambda:oracle.audit_snapshot(base['instance'],base['snapshot'],check=fault,limits=limits,certificates=[]))")
change("lambda:oracle.audit_snapshot(base['instance'],base['snapshot'],check=s.check,limits=limits))", "lambda:oracle.audit_snapshot(base['instance'],base['snapshot'],check=s.check,limits=limits,certificates=[]))")
change("        s.stage='COMPLETE_CASE';s.active=case['id'];machine=machine_by_id[case['machine_id']]", "        s.stage='COMPLETE_CASE';s.active=case['id'];s.phase('CASE_STARTED');machine=machine_by_id[case['machine_id']]")
change("        s.rows.append(row)\n    diagnostics", "        row['independent_primitive_certificates']=restoration['certificates']\n        row['independent_primitive_certificate_audits']=restoration['certificate_audits']\n        s.rows.append(row);s.phase('CASE_COMPLETED')\n    diagnostics")
change("        all_complete=all_complete,full_pipeline_qualified=False,mathematical_proof_accepted=False)", "        all_complete=all_complete,nogood_mode=s.mode,nogood_limits=NOGOOD_LIMITS,\n        per_API_inclusive_wall_ns=s.inclusive_wall_ns,phase_receipts=s.phase_receipts,\n        timing_scope='Inclusive guarded API action time; nested oracle/certificate intervals lie inside search. Do not sum as exclusive cost. Failure counters are cutoff observations.',\n        full_pipeline_qualified=False,mathematical_proof_accepted=False)")
change("             declaration['checkpoint_limit']==CHECKPOINT_LIMIT,'prospectively fixed worker limits')", "             declaration['checkpoint_limit']==CHECKPOINT_LIMIT and\n             declaration['nogood_limits']==NOGOOD_LIMITS and declaration['nogood_mode']in MODES,\n             'prospectively fixed worker limits/mode')\n        s.mode=declaration['nogood_mode']")
change("            oracle_work_scope='sum exported", "            nogood_mode=s.mode,nogood_limits=NOGOOD_LIMITS,\n            independent_primitive_certificate_count=sum(len(r['independent_primitive_certificates'])for r in s.rows),\n            per_API_inclusive_wall_ns=s.inclusive_wall_ns,\n            oracle_work_scope='sum exported")
change("            root_check_calls=s.root_calls,first_available_fault=information(primary),outputs=s.output_pins,", "            root_check_calls=s.root_calls,first_available_fault=information(primary),outputs=s.output_pins,\n            nogood_mode=s.mode,per_API_inclusive_wall_ns=s.inclusive_wall_ns,phase_receipts=s.phase_receipts,\n            failure_scope='Diagnostic prefix only, no failed-prefix acceptance or result rescue; inclusive times are not exclusive and partial failed API work may be unavailable.',")
target=D/'qualify_wang_reusable_worker_DRAFT_v1.py'
with target.open('x')as output:output.write(old)
print(str(target))
