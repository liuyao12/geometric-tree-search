"""Ordinary raw Source author. No subject imports/calls or sample execution."""
from pathlib import Path
import hashlib
import json
import ast

D=Path('/private/tmp/gcts-wang-receptor-ROOT-20261019-v1')
SEARCH=Path('/private/tmp/gcts-wang-nogood-search-library-20261019/wang_point_search_v3.py')
ORACLE=Path('/private/tmp/gcts-wang-nogood-oracle-20261019/wang_nogood_oracle_v1.py')
def pin(path):
    b=path.read_bytes();return dict(path=str(path.resolve()),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
raw=(D/'qualify_wang_reusable_worker_DRAFT_v2.py').read_text()
def edit(before,after):
    global raw
    if raw.count(before)!=1:raise ValueError('nonunique edit '+before[:80])
    raw=raw.replace(before,after)
def main():
    # Caller waits for the independent author handoff, then verifies it separately.
    source_pins={k:pin(v)for k,v in [('search',SEARCH),('oracle',ORACLE)]}
    for key,label in [('search','SEARCH'),('oracle','ORACLE')]:
        p=source_pins[key]
        edit("'"+label+"_SOURCE_PIN_PENDING', 0",repr(p['sha256'])+', '+str(p['bytes']))
    edit("    def certify(packet):\n        s.check();proof_limits=base_limits(s,'oracle')", "    def certify(packet):\n        s.check();need(type(packet['id'])is int and packet['id']==len(certificates),\n            'fresh ordered owner-accepted clause identity')\n        proof_limits=base_limits(s,'oracle')")
    edit("    state=summary();state.update(certificates=certificates,certificate_audits=certificate_audits)", """    if value['status']in('TILING_CANDIDATE','FINITE_EXHAUSTED'):
        need(canonical(value['nogood_certificates'])==canonical(certificates)and
            type(value['knowledge_version'])is int and value['knowledge_version']==len(certificates),
            'all and only independently accepted clauses retained in successful result')
        if s.mode=='primitive_empty_support':
            need(canonical(value['nogood_scope'])==canonical(instance),'full literal returned same-instance scope')
    state=summary();state.update(certificates=certificates,certificate_audits=certificate_audits)""")
    edit("Inclusive guarded API action time; nested oracle/certificate intervals lie inside search.", "Inclusive API action intervals only; wrapper guards are outside these intervals, while nested oracle/certificate intervals lie inside search.")
    target=D/'qualify_wang_reusable_worker_v1.py'
    ast.parse(raw);compile(raw,str(target),'exec')  # Unused code, never evaluated.
    with target.open('x')as f:f.write(raw)
    with (D/'worker-source-freeze-v1.json').open('x')as f:
        json.dump(dict(source=pin(target),components=source_pins,source_only=True,component_calls=0,
            AST_parse_only=True,unused_compile=True,actual_execution_authorized=False),f,indent=2,sort_keys=True)
        f.write('\n')
    print(json.dumps(pin(target),sort_keys=True))
if __name__=='__main__':main()
