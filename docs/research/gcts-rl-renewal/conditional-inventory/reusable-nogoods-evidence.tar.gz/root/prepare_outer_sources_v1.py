"""Raw Source author: inherit reviewed bounded lifecycle, add mode joins."""
from pathlib import Path
D=Path('/private/tmp/gcts-wang-receptor-ROOT-20261019-v1')
P=Path('/private/tmp/gcts-wang-execution-ROOT-20261019')
source=(P/'run_wang_encoding_once_v5.py').read_text()
before="VERSION='wang-encoding-once-runner-v5'"
assert source.count(before)==1
source=source.replace(before,"VERSION='wang-reusable-comparison-once-runner-v1'")
before="    need(q['all_palettes_invariant_across_instances']is True and q['foreign_faults_preserved_exactly']is True,"
after="""    need(q['nogood_mode']==declaration['nogood_mode']and
         q['nogood_limits']==declaration['nogood_limits']and
         type(q['independent_primitive_certificate_count'])is int and
         q['independent_primitive_certificate_count']>=0,'declared exact off/on mode and certificate census')
    if q['nogood_mode']=='off':need(q['independent_primitive_certificate_count']==0,'off arm never certifies')
    need(type(q['per_API_inclusive_wall_ns'])is dict and all(type(k)is str and type(v)is int and v>=0
         for k,v in q['per_API_inclusive_wall_ns'].items()),'passive inclusive action-time observations')
    need(q['all_palettes_invariant_across_instances']is True and q['foreign_faults_preserved_exactly']is True,"""
assert source.count(before)==1
source=source.replace(before,after)
with (D/'run_wang_reusable_once_v1.py').open('x')as f:f.write(source)
with (D/'observe_wang_encoding_once_v1.py').open('xb')as f:f.write((P/'observe_wang_encoding_once_v1.py').read_bytes())
print('Authored raw outer Sources only; no actual')
