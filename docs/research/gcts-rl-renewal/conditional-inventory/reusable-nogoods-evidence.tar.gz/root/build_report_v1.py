"""Passive report/archive assembly from whole saved bytes; no subject calls."""
from pathlib import Path
import hashlib
import json
import html
import tarfile
import io
D=Path('/private/tmp/gcts-wang-receptor-ROOT-20261019-v1')
OUT=D/'publication'
def pin(path):
    raw=path.read_bytes();return dict(path=str(path.resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def escape(v):return html.escape(str(v),quote=True)
def main():
    OUT.mkdir()
    summary=json.loads((D/'ROOT-saved-comparison-v1.json').read_bytes())
    if not summary['all_actuals_closed']:raise ValueError('must close all actuals before report')
    table=[];apirows=[]
    for row in summary['rows']:
        q=row['qualification'];calls=row['diagnostic_only_call_completed']if q is None else {}
        complete='Complete candidate'if q is not None else'Incomplete; no admission'
        prefix=len(row['diagnostic_only_completed_case_ids'])if q is None else 680
        variants=sum(len(g['variants'])for g in row['diagnostic_only_prefix'])if q is None else 55
        certs=calls.get('oracle.certify',0)if q is None else q['independent_primitive_certificate_count']
        table.append('<tr>'+''.join('<td>'+escape(x)+'</td>'for x in[
            row['mode'],complete,f"{row['elapsed_seconds']:.3f} s",prefix,variants,
            calls.get('oracle.audit_snapshot','See packet'),certs,row['diagnostic_only_active_case']or'—'])+'</tr>')
        wall=row['diagnostic_only_API_inclusive_wall_ns']if q is None else q['per_API_inclusive_wall_ns']
        for name,ns in sorted(wall.items()):
            apirows.append('<tr>'+''.join('<td>'+escape(x)+'</td>'for x in[
                row['mode'],name,f'{ns/1e9:.6f} s',calls.get(name,'See packet')])+'</tr>')
    rows='\n'.join(table);apis='\n'.join(apirows)
    report=r'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Reusable failure constraints: first off/on comparison — GCTS</title>
<script>window.MathJax={tex:{inlineMath:[['\\(','\\)']],displayMath:[['\\[','\\]']]},options:{skipHtmlTags:['script','noscript','style','textarea','pre','code']}};</script><script defer src="https://cdn.jsdelivr.net/npm/mathjax@3.2.2/es5/tex-chtml.js"></script>
<style>*{box-sizing:border-box}body{margin:0;background:#f0f5f2;color:#1e3e46;font:17px/1.65 system-ui,sans-serif}main{max-width:1140px;margin:auto;padding:28px 24px 65px}a{color:#126577}nav{display:flex;gap:20px;flex-wrap:wrap;font-size:14px}h1,h2{font-family:Georgia,serif;line-height:1.17}h1{font-size:clamp(33px,5vw,50px)}h2{font-size:29px}.lead{font-size:21px}.notice{padding:18px 22px;background:#fff0d5;border-left:5px solid #b48035}.small,figcaption{font-size:14px;color:#536f77}section{margin-top:39px}.cards{display:grid;grid-template-columns:repeat(3,1fr);gap:18px}.card{background:white;padding:20px;border:1px solid #bfd2cc}.card h3{margin-top:0}.wrap,.math{overflow:auto}table{border-collapse:collapse;width:100%;font-size:14px;background:white}td,th{padding:12px;text-align:left;vertical-align:top;border-bottom:1px solid #c8d8d1}th{background:#dfece5}code{font:13px ui-monospace,monospace;overflow-wrap:anywhere;background:#e0ebe6;padding:2px 4px}.flow{display:flex;gap:12px;align-items:stretch;flex-wrap:wrap}.flow div{background:#fff;border:1px solid #bfd2cc;padding:16px;flex:1;min-width:190px}.arrow{color:#328a88;font-size:24px;align-self:center}footer{border-top:1px solid #c3d6cf;margin-top:42px;padding-top:20px}@media(max-width:750px){.cards{grid-template-columns:1fr}main{padding:22px 16px 50px}}
</style></head><body><main>
<nav><a href="reader.html">Research notebook</a><a href="wang-execution.html">Previous calibration</a><a href="nogood-marking-construction.html">Colored marking construction</a><a href="fixed-fol-checker.html">First-order checker boundary</a><a href="#evidence">Evidence</a></nav>
<p class="small">19 October 2026 · independently authored search, certificate census and review</p>
<h1>Reusable failure constraints: first off/on comparison</h1>
<p class="lead">The new search can retain a proved forbidden combination after backtracking. A separate checker verifies every offered certificate before activation, and independently reconstructs each observed candidate graph under the current knowledge.</p>
<div class="notice"><b>Read the outcome table literally.</b> A deadline or error leaves the full calibration unqualified. Completed prefix counts and certification returns in a failed run are diagnostic observations, not admitted theorem or tiling results. Neither arm implements the geometric marking gadget or trained reinforcement learning.</div>
<section id="outcome"><h2>Two fresh whole-workload attempts</h2><p>Both arms used the same seven Sources and the same original 680-case, four-machine bank, followed by the same 55 diagnostic variants in 30 groups. The declared mode was the only arm difference. Positive work and known exit had to finish within \(180\,\mathrm{s}\), complete custody and external terminal observation within \(210\,\mathrm{s}\), with standalone worker high water at most \(1\,\mathrm{GiB}\) and logical, expanded and physical outputs each bounded by \(128\,\mathrm{MiB}\).</p>
<div class="wrap"><table><thead><tr><th>Mode</th><th>Whole-run outcome</th><th>External elapsed</th><th>Case prefix</th><th>Diagnostic prefix</th><th>Returned graph audits</th><th>Returned certifications</th><th>Interrupted case</th></tr></thead><tbody>__ROWS__</tbody></table></div>
<p class="small">Prefixes and wrapper counters are taken from the complete failure metadata at its recorded cutoff. The failure packets contain no full clause packets, tiling certificates, graph snapshots, search traces or total exported component-work values. The certification count is API returns, not an archived activated, unique or reused-clause count. Single serial observations, off then on, give no statistical speedup estimate. The earlier failed whole workload remains failed.</p>
<p class="small">The control cleanup recorded one intermediate group-probe <code>PermissionError</code>. A permission failure was treated as unknown, and subsequent genuine worker reaping and two absent-group observations closed custody; it was not counted as absence on its own. Both negative runs closed before the original custody deadline.</p></section>
<section id="method"><h2>What changed</h2><div class="flow"><div>Find an unfilled required point with no primitive support</div><span class="arrow" aria-hidden="true">→</span><div>Supply one actual edge conflict for every original tile ID</div><span class="arrow" aria-hidden="true">→</span><div>Independent certificate check, then retain the forbidden combination</div></div>
<div class="math">\[C=\{c_1,\ldots,c_k\},\qquad\neg\bigwedge_{i=1}^{k}\operatorname{Chosen}(c_i).\]</div>
<p>A witness must use a permanent boundary pin or a selected support placement. Missing active-domain support, parent exclusions and earlier clause filtering cannot replace primitive conflicts. The full current instance binds the certificate; its scope string is not a portable identity.</p>
<p>When every support placement is selected, the clause exposes a dead obligation. When all but one are selected, it eliminates the remaining placement. Full clause dependencies and effective graph incidence are checked at every offered snapshot. Existing global dead-end, forced-move and earliest-generation rules remain in force.</p>
<div class="cards"><article class="card"><h3>Implementation agent</h3><p>V3 search has matched off/on entries, full original-palette witnesses, private finite quotas, an independent-check callback before activation and a persistent proof catalogue.</p></article><article class="card"><h3>Independent oracle agent</h3><p>Separately written code rechecks certificates and reconstructs all original and effective graph fields, clause units, conflicts and dependencies.</p></article><article class="card"><h3>Review agent</h3><p>Source review challenges both implementations and the complete owner coupling. It distinguishes graph restoration from control history and evaluates the separate marking argument.</p></article></div>
<p>At rollback, all ten original graph fields are compared in full: points, candidates, chosen placements, assigned marks, forward and reverse incidence, dependencies, boundary pins, context exclusions and scheduler. The saved raw undo checkpoint is checked separately. Overlay replay may append control-trail instructions, while knowledge history persists. Final teardown requires the original graph and actual empty trail; its proof catalogue is explicitly inactive and cannot continue search.</p></section>
<section id="markings"><h2>A concrete route to colored markings</h2><p>The <a href="nogood-marking-construction.html">illustrated construction note</a> gives a finite auxiliary strip. Purple links read actual base tile IDs, teal links carry a Boolean prefix state, amber anchors fix auxiliary roles, and the original edge channel remains separate.</p>
<div class="math">\[s_0=1,\qquad s_i=s_{i-1}\land[v_i=u_i],\qquad s_k=0.\]</div><p>The informal extension lemma says an original tiling extends exactly when at least one forbidden choice differs. It uses at most \(2k|T|\) auxiliary prototypes and \(k\) added unit-center placements for nonempty support. It depends on exact allowed origins, assigned center anchors and literal base tile IDs. This is an unexecuted, instance-specific construction; it is not a fixed universal palette or a measured search improvement.</p></section>
<section id="cost"><h2>Observed API action intervals</h2><p>These are inclusive monotonic action intervals. Wrapper guards and serialization outside the action are excluded; nested graph and certificate checks are inside the search interval. Interrupted actions may have no recorded interval. Do not add these rows to obtain exclusive costs or infer a bottleneck from call counts alone. The external elapsed column above includes the whole run.</p>
<div class="wrap"><table><thead><tr><th>Mode</th><th>API entry</th><th>Inclusive recorded interval</th><th>Returned calls at cutoff</th></tr></thead><tbody>__APIS__</tbody></table></div></section>
<section id="assessment"><h2>No positive performance signal from this implementation</h2><p>Both original whole-workload attempts hit the deadline. The off arm recorded a prefix of \(68\) cases and the on arm \(53\), with worker high water respectively \(68.72\,\mathrm{MiB}\) and \(140.25\,\mathrm{MiB}\). The cache arm recorded \(842\) certification returns. These are incomplete-run observations, not comparable completed-bank timing scores or accepted proofs. Neither arm reached the original diagnostic phase.</p>
<p>Recorded inclusive graph-audit action intervals were approximately \(69.06\,\mathrm{s}\) off and \(58.87\,\mathrm{s}\) on; the latter covered fewer audits and a different prefix. Separate certification action intervals totaled approximately \(0.85\,\mathrm{s}\) on. These intervals do not isolate repeated certificate validation inside graph audits, graph copying or wrapper guards, and do not justify attributing all overhead to one cause.</p>
<p>A complete run would qualify this finite specialization and its actual observed certificate opportunities. It would not qualify the entire proof system, every malformed certificate or interruption site, generic mixed-generation GCTS, or a GCTS+RL advantage. The new supplemental 21-group / 28-subcase diagnostic proposal remains unexecuted and is not counted among the original 55 variants.</p>
<p>The direct cache is a conventional certified-constraint baseline. Any geometric or learned version should face a control with the same clauses and all certification, candidate maintenance and output costs charged. The fixed faithful first-order checker machine, its one palette, unknown-proof grammar and arithmetic/Hilbert bridges remain unfinished. This comparison discovers no new arithmetic or geometry theorem.</p>
<p>The next implementation question is whether the colored gadget can be compiled with exact projection checks and practical cost. The next proof-system question remains the faithful fixed checker encoding. Turtle, Penrose and practical region tiling stay in the wider program; this finite cache experiment does not settle them.</p></section>
<section id="evidence"><h2>Whole saved evidence</h2><p><a href="reusable-nogoods-summary.json">Saved comparison summary</a> · <a href="reusable-nogoods-manifest.json">Archive manifest</a> · <a href="reusable-nogoods-evidence.tar.gz">Sources, plans, reviews and complete actual metadata</a></p><p>The archive contains literal Sources and ordinary saved data with a path-to-hash map. No interpreter binary, credential, private primary reader or opaque compiled proof program is included. Review receipts distinguish Source assessment from runtime and formal-kernel authority.</p></section>
<footer><p class="small">Root report assembled passively from saved files. No target program was imported, called or simulated during report assembly. Goal remains active; no GCTS+RL advantage, trained policy, fixed FOL palette, or plane-tiling proof is claimed.</p></footer></main></body></html>'''
    report=report.replace('__ROWS__',rows).replace('__APIS__',apis)
    (OUT/'reusable-nogoods.html').write_text(report)
    (OUT/'reusable-nogoods-summary.json').write_bytes((D/'ROOT-saved-comparison-v1.json').read_bytes())
    (OUT/'nogood-marking-construction.html').write_bytes((D/'nogood-marking-construction.html').read_bytes())
    roots=[('root',D),('search',Path('/private/tmp/gcts-wang-nogood-search-library-20261019')),
        ('oracle',Path('/private/tmp/gcts-wang-nogood-oracle-20261019')),('review',Path('/private/tmp/gcts-wang-nogood-review-20261019'))]
    files=[]
    for label,base in roots:
        for path in sorted(base.rglob('*')):
            if not path.is_file()or path.is_symlink()or OUT in path.parents:continue
            if '__pycache__'in path.parts or path.suffix in('.png','.jpg'):continue
            files.append((label+'/'+str(path.relative_to(base)),path))
    for label,path in [('compiler',Path('/private/tmp/gcts-wang-spacetime-library-20261019/wang_spacetime_compiler_v1.py')),
        ('verifier',Path('/private/tmp/gcts-wang-search-library-20261019/wang_history_verifier_v2.py'))]:
        files.append(('unchanged/'+label+'.py',path))
    mapping=[]
    archive=OUT/'reusable-nogoods-evidence.tar.gz'
    with tarfile.open(archive,'w:gz')as tar:
        for name,path in files:
            raw=path.read_bytes();mapping.append(dict(member=name,source=pin(path)))
            info=tarfile.TarInfo(name);info.size=len(raw);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(raw))
        raw=json.dumps(mapping,sort_keys=True,indent=2).encode()+b'\n'
        info=tarfile.TarInfo('PATH-MAP.json');info.size=len(raw);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(raw))
    manifest=dict(schema='reusable-nogood-publication-manifest-v1',archive=pin(archive),raw_members=len(files),
        raw_source_bytes=sum(r['source']['bytes']for r in mapping),all_raw_members=mapping,
        reports=[pin(OUT/name)for name in('reusable-nogoods.html','reusable-nogoods-summary.json','nogood-marking-construction.html')],
        target_execution_in_assembly=False,goal_status='active',scientific_acceptance=False)
    (OUT/'reusable-nogoods-manifest.json').write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n')
    print(json.dumps(dict(output=str(OUT),members=len(files),archive=pin(archive)),sort_keys=True))
if __name__=='__main__':main()
