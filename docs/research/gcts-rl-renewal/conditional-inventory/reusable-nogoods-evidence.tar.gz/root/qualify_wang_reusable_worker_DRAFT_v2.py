"""UNEXECUTED worker Source for one complete declared finite Wang calibration.

Only future reviewed once-run execution may load/call the four components.
No Native/FOL/Model/Reader/inverse/solver imports or calls. No hostile sandbox
claim: input ownership, Source/callable custody and finite external gates apply.
"""
import time
NOW = time.monotonic_ns
ENTRY_NS = NOW()
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import types

VERSION = 'complete-wang-reusable-nogood-comparison-worker-v1'
SOURCE_ROLES = ('worker', 'compiler', 'search', 'verifier', 'oracle', 'runner', 'observer')
SOURCE_PINS = {
    'compiler': ('92a8c49bd9be346faf9e6472c588140d3844c4e52c1f0a18fef24409e7ff20ba', 13084),
    'search': ('SEARCH_SOURCE_PIN_PENDING', 0),
    'verifier': ('136d9306b2389576b38ffd6c60350514835583f625a5f45467cefc044fa3908d', 23707),
    'oracle': ('ORACLE_SOURCE_PIN_PENDING', 0),
}
INPUT_SHA = '60ced7c79f91fd475ef88e90cace3ce5fffe15b0c8450d4b3e934d3764ffb80e'
INPUT_BYTES = 232943
OUTER_LIMITS = dict(work_seconds=180, overall_seconds=210, memory_bytes=1073741824,
    result_bytes=134217728, expanded_bytes=134217728, stdout_bytes=4194304,
    stderr_bytes=4194304, worker_receipt_bytes=4194304,
    runner_metadata_bytes=8388608, observer_bytes=1048576)
COMPONENT_LIMITS = {
    'compiler': dict(work=400000000,symbols=16,states=16,tiles=100000,colors=100000,cells=1024,dimension=64),
    'search': dict(work=400000000,cells=1024,tiles=100000,colors=100000,candidates=1000000,
        data_depth=64,decisions=100000,trace_rows=100000,snapshot_items=10000000),
    'verifier': dict(work=400000000,cells=1024,tiles=100000,colors=100000,symbols=16,states=16,
        data_depth=64,history_cells=1024),
    'oracle': dict(work=400000000,points=1024,candidates=1000000,mark_points=4096,
        placements=1024,exclusions=1000000,trail_entries=10000000,metadata_entries=1024,
        clauses=256,clause_literals=4096,witness_rows=1000000,proof_work=400000000),
}
NOGOOD_LIMITS = dict(clauses=256,witness_rows=1000000,proof_work=400000000)
MODES = ('off','primitive_empty_support')
CHECKPOINT_LIMIT = 400000000
RESERVE_BYTES = 9437184
FORBIDDEN_EVENTS = ('subprocess.Popen','os.system','os.fork','os.posix_spawn','socket.connect','ctypes.dlopen')


class PolicyFailure(RuntimeError):
    pass


class PlannedForeign(BaseException):
    pass


def need(ok, message):
    if not ok:
        raise PolicyFailure(message)


def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode('utf8')


def clone(value):
    return json.loads(canonical(value))


def descriptor(path, raw):
    return dict(path=str(Path(path).resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


def checked(pin, cap=16777216):
    need(type(pin)is dict and set(pin)=={'path','bytes','sha256'} and type(pin['path'])is str and
         type(pin['bytes'])is int and 0<=pin['bytes']<=cap and type(pin['sha256'])is str and
         len(pin['sha256'])==64,'strict finite raw descriptor')
    path=Path(pin['path'])
    need(path.is_absolute()and path==path.resolve()and path.is_file()and not path.is_symlink(),'canonical regular raw input')
    raw=path.read_bytes();need(descriptor(path,raw)==pin,'complete raw hash/size/path join');return raw


def information(error):
    try:return dict(type=type(error).__name__,message=str(error)[:512])
    except BaseException:return dict(type='UNAVAILABLE',message='error metadata unavailable')


def callable_seal(module):
    rows=[];seen=set();pending=[('',vars(module))]
    while pending:
        prefix,values=pending.pop()
        for name,value in sorted(values.items()):
            key=prefix+name
            if type(value)is types.FunctionType and value.__module__==module.__name__:
                rows.append((key,id(value),id(value.__code__),id(value.__defaults__),id(value.__kwdefaults__)))
            elif type(value)is type and value.__module__==module.__name__ and id(value)not in seen:
                seen.add(id(value));rows.append((key,id(value)))
                owned={}
                for child,item in vars(value).items():
                    if type(item)in(staticmethod,classmethod):item=item.__func__
                    owned[child]=item
                pending.append((key+'.',owned))
    return tuple(sorted(rows))


class Session:
    def __init__(self,plan,plan_pin,consumed,actual):
        self.plan,self.plan_pin,self.actual=plan,plan_pin,actual
        self.began=consumed['began_ns'];self.work_deadline=consumed['work_deadline_ns']
        self.overall_deadline=consumed['overall_deadline_ns']
        self.root_calls=0;self.first_fault=None;self.stage='INTAKE';self.active=None
        self.started={};self.completed={};self.raised={};self.modules={};self.seals={};self.denied=[]
        self.oracle_work=0;self.oracle_work_unavailable=0;self.expanded_subtree_delta=0
        self.rows=[];self.diagnostics=[];self.retained=[];self.output_pins=[]
        self.component_limits=clone(COMPONENT_LIMITS)
        self.mode=None;self.inclusive_wall_ns={};self.phase_receipts=[]

    def elapsed(self,key,began):
        # Inclusive API wall time: nested oracle calls are inside search time.
        # These intervals must never be summed as exclusive component costs.
        elapsed=NOW()-began
        self.inclusive_wall_ns[key]=self.inclusive_wall_ns.get(key,0)+elapsed

    def phase(self,event):
        self.check();need(len(self.phase_receipts)<2048,'bounded passive phase metadata')
        self.phase_receipts.append(dict(event=event,stage=self.stage,active=self.active,
            elapsed_from_runner_entry_ns=NOW()-self.began,root_check_calls=self.root_calls,
            completed_cases=len(self.rows),diagnostic_groups=len(self.diagnostics)))

    def check(self):
        self.root_calls+=1
        try:
            need(self.root_calls<=CHECKPOINT_LIMIT,'invocation-total400m Root callback limit')
            need(NOW()<self.work_deadline,'original absolute180s work deadline')
            if self.first_fault is not None:raise self.first_fault
        except BaseException as error:
            if self.first_fault is None:self.first_fault=error
            raise

    def policy(self,action):
        try:return action()
        except BaseException as error:
            if self.first_fault is None:self.first_fault=error
            raise

    def guard(self):
        def action():
            self.check()
            for role,pin in self.plan['sources'].items():
                checked(pin)
            for role,module in self.modules.items():
                need(module.__file__==self.plan['sources'][role]['path'] and
                     callable_seal(module)==self.seals[role],'owned module origin/function/code/default binding')
            self.check()
        return self.policy(action)

    def fault_gate(self):
        if self.first_fault is not None:raise self.first_fault

    def own_oracle_limit(self,error):
        self.fault_gate();self.guard();key='oracle.is_own_limit'
        self.started[key]=self.started.get(key,0)+1
        value=self.modules['oracle'].is_own_limit(error)
        self.completed[key]=self.completed.get(key,0)+1;self.guard()
        return value

    def call(self,role,name,data,action,expected_after=None):
        self.guard();before=canonical(data()if callable(data)else data)
        self.check();key=role+'.'+name;self.started[key]=self.started.get(key,0)+1
        began=NOW()
        try:
            value=action()
        except BaseException as error:
            self.elapsed(key,began)
            self.raised[key]=self.raised.get(key,0)+1
            self.fault_gate()
            if role=='oracle'and name in('audit_snapshot','certify'):
                oracle=self.modules['oracle']
                if type(error)is oracle.SnapshotLimit and self.own_oracle_limit(error):self.oracle_work+=error.attempted_work
                else:self.oracle_work_unavailable+=1
            self.fault_gate()
            self.guard()
            expected=before if expected_after is None else canonical(expected_after)
            self.policy(lambda:need(canonical(data()if callable(data)else data)==expected,'full literal call arguments after refusal/fault'))
            raise
        self.elapsed(key,began)
        self.fault_gate();self.guard()
        expected=before if expected_after is None else canonical(expected_after)
        self.policy(lambda:need(canonical(data()if callable(data)else data)==expected,'full literal call arguments unchanged'))
        self.completed[key]=self.completed.get(key,0)+1
        if role=='oracle'and name in('audit_snapshot','certify'):self.oracle_work+=value['audit_work']
        return value

    def load(self,role):
        self.check();pin=self.plan['sources'][role];checked(pin)
        name='wang_actual_'+role
        spec=importlib.util.spec_from_file_location(name,pin['path'])
        need(spec is not None and spec.loader is not None,'exact Python Source loader')
        module=importlib.util.module_from_spec(spec);sys.modules[name]=module
        spec.loader.exec_module(module)
        need(module.__file__==pin['path'],'exact loaded Source origin')
        self.modules[role]=module;self.seals[role]=callable_seal(module);self.guard()
        return module

    def calls(self,role):
        return sum(value for key,value in self.started.items()if key.startswith(role+'.'))

    def write_json(self,name,value,cap,closure=False):
        path=self.actual/name;temporary=self.actual/(name+'.partial')
        need(not path.exists()and not temporary.exists(),'never overwrite or retry a packet')
        digest=hashlib.sha256();size=0;parts=0
        fd=os.open(str(temporary),os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
        with os.fdopen(fd,'wb')as output:
            for part in json.JSONEncoder(sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).iterencode(value):
                raw=part.encode('utf8');size+=len(raw);need(size+1<=cap,'whole JSON packet cap')
                output.write(raw);digest.update(raw);parts+=1
                if parts%1024==0:
                    if closure:need(NOW()<self.overall_deadline,'failure metadata210 deadline')
                    else:self.check()
            output.write(b'\n');digest.update(b'\n');size+=1;output.flush();os.fsync(output.fileno())
        if closure:need(NOW()<self.overall_deadline,'failure metadata completed before210')
        else:self.check()
        os.rename(temporary,path)
        return dict(path=str(path),bytes=size,sha256=digest.hexdigest())


def compiler_word(word):
    # Explicit declared evidence codec, not a simulator or altered alphabet.
    return [tuple(cell)for cell in word]


def base_limits(session,role,variant=None):
    limits=clone(session.component_limits[role])
    if variant:
        limits.update(variant.get('limit_overrides',{}))
        malformed=variant.get('malformed_limits')
        if malformed=='zero_work':limits['work']=0
        elif malformed=='boolean_work':limits['work']=True
        elif malformed=='extra_key':limits['undeclared']=1
        elif malformed is not None:raise PolicyFailure('unknown malformed-limits recipe')
    return limits


def invoke_compiler(s,operation,machine,word=None,steps=None,variant=None,check=None,expected_after=None):
    module=s.modules['compiler'];limits=base_limits(s,'compiler',variant)
    arguments=dict(machine=machine,limits=limits)
    if operation=='compile_finite_problem':arguments.update(word=word,steps=steps)
    callback=s.check if check is None else check
    if operation=='compile_palette':
        action=lambda:module.compile_palette(machine,check=callback,limits=limits)
    elif operation=='compile_finite_problem':
        action=lambda:module.compile_finite_problem(machine,word,steps,check=callback,limits=limits)
    else:raise PolicyFailure('unknown compiler operation')
    return s.call('compiler',operation,arguments,action,expected_after=expected_after)


def palette_check(s,palette):
    v=s.modules['verifier'];limits=base_limits(s,'verifier')
    budget=s.call('verifier','_Budget',dict(limits=limits),lambda:v._Budget(s.check,limits))
    result=s.call('verifier','_palette',dict(palette=palette),lambda:v._palette(palette,budget))
    return dict(status='FULL_PALETTE_SCHEMA_CHECK_COMPLETED',colors=len(result[1]),tiles=len(result[2]),counts=dict(budget.counts))


def reference_after_search(s,machine,word,steps):
    # Explicitly permitted pinned private entries; no compiler F or search input.
    v=s.modules['verifier'];limits=base_limits(s,'verifier')
    budget=s.call('verifier','_Budget',dict(limits=limits),lambda:v._Budget(s.check,limits))
    parsed=s.call('verifier','_machine',dict(machine=machine),lambda:v._machine(machine,budget))
    tape=[cell[-1]for cell in word];heads=[i for i,cell in enumerate(word)if cell[0]=='head']
    need(len(heads)==1,'reference initial single head');head=heads[0];state=word[head][1]
    rows=[];stop=None
    for time_index in range(steps+1):
        s.check();data=dict(tape=tape,head=head,state=state)
        configuration=s.call('verifier','_configuration',data,lambda:v._configuration(tape,head,state,budget))
        rows.append(dict(time=time_index,tape=list(tape),head=head,state=state,configuration=configuration))
        if time_index==steps:break
        try:
            def all_arguments():
                return dict(tape=tape,head=head,state=state,parsed_machine=list(parsed[:5])+[
                    [[old,read]+list(value)for(old,read),value in sorted(parsed[5].items())]])
            tape,head,state=s.call('verifier','_global_transition',all_arguments,
                                  lambda:v._global_transition(tape,head,state,parsed,budget))
        except BaseException as error:
            s.fault_gate()
            if type(error)is v.InvalidCertificate:
                stop=information(error);break
            raise
    return dict(accepts_exact_steps=stop is None and state==parsed[4],rows=rows,stop=stop,
                counts=dict(budget.counts),not_supplied_to_search=True)


def observer_for(s,instance,observations,certificates,keep_first=False):
    oracle=s.modules['oracle'];initial=None;branches=[];first=None;restored=False
    replay_pending=None;terminal=False
    def observe(snapshot):
        nonlocal initial,first,restored,replay_pending,terminal
        s.check();need(not terminal,'no continuation after final knowledge-disabled teardown')
        limits=base_limits(s,'oracle')
        audit=s.call('oracle','audit_snapshot',dict(instance=instance,snapshot=snapshot,
            limits=limits,certificates=certificates),lambda:oracle.audit_snapshot(
            instance,snapshot,check=s.check,limits=limits,certificates=certificates))
        need(audit['status']=='EXACT_FINITE_POINT_CENSUS_MATCH','independent full graph census')
        # The independent oracle must supply both complete effective and complete
        # original physical/context graphs. Never obtain restoration by silently
        # dropping changed domain entries from an effective graph.
        census=audit['census'];physical=audit['physical_context_census']
        graph_fields=('points','candidates','chosen','marks','forward','reverse',
            'dependencies','boundary','exclusions','scheduler')
        # Exact complete original graph projections. Raw control-trail length
        # and historical last_restore are separately retained and checked: a
        # suspended/replayed overlay legitimately appends control instructions.
        graph_value={k:census[k]for k in graph_fields}
        physical_value={k:physical[k]for k in graph_fields}
        body=canonical(graph_value);core=canonical(physical_value);packet=canonical(snapshot)
        need(physical['trail_length']==snapshot['trail_length'],'literal observed raw trail length')
        compared=False;effective_compared=False;reason=snapshot['reason']
        knowledge=snapshot.get('knowledge');version=0 if knowledge is None else knowledge['version']
        if reason=='INITIAL':
            need(initial is None and snapshot['trail_length']==0,'one initial graph/empty trail');initial=core
            if keep_first:first=clone(snapshot)
        elif reason=='STATE'and snapshot['scheduler']['kind']=='BRANCH':
            need(replay_pending is None,'all rollback knowledge reapplied before branch')
            branches.append(dict(physical=core,effective=body,version=version,trail_length=snapshot['trail_length']))
        elif reason=='ROLLBACK':
            need(branches and knowledge is None,'off-mode parent branch retained')
            saved=branches.pop();need(body==saved['effective']and core==saved['physical']and
                snapshot['trail_length']==saved['trail_length'],
                'off-mode complete typed restoration equality');compared=True;effective_compared=True
        elif reason=='ROLLBACK_PHYSICAL':
            need(branches and replay_pending is None and knowledge is not None and
                knowledge['activation']=='SUSPENDED_ROLLBACK_REPLAY','explicit suspended restoration phase')
            saved=branches.pop();need(core==saved['physical']and
                knowledge['last_restore']['checkpoint']==saved['trail_length'],
                'full original physical/context graph and saved raw undo checkpoint')
            replay_pending=saved;compared=True
        elif reason=='ROLLBACK_REPLAYED':
            need(replay_pending is not None and knowledge is not None and
                knowledge['activation']=='ACTIVE'and core==replay_pending['physical'],
                'full current-version knowledge reapplication without physical mutation')
            if version==replay_pending['version']:
                need(body==replay_pending['effective'],'unchanged-knowledge full effective restoration')
                effective_compared=True
            replay_pending=None;compared=True
        elif reason=='ROOT_RESTORED':
            need(initial is not None and core==initial and snapshot['trail_length']==0,
                'full original initial/restored mutable graph equality and actual empty trail')
            need(knowledge is None or (knowledge['activation']=='SUSPENDED_FINAL_CLEANUP'and
                knowledge['scheduler_evaluation_only']is True),'explicit terminal inactive inventory')
            restored=True;compared=True;terminal=True;branches.clear();replay_pending=None
        elif reason in('STATE','KNOWLEDGE_GROWN'):
            need(replay_pending is None,'no stable active observation before knowledge replay')
        else:raise PolicyFailure('undeclared snapshot lifecycle reason')
        observations.append(dict(sequence=len(observations),reason=reason,
            snapshot=dict(bytes=len(packet),sha256=hashlib.sha256(packet).hexdigest()),
            census=dict(bytes=len(body),sha256=hashlib.sha256(body).hexdigest()),
            physical_context_graph=dict(bytes=len(core),sha256=hashlib.sha256(core).hexdigest()),
            complete_audit_census=dict(bytes=len(canonical(census)),sha256=hashlib.sha256(canonical(census)).hexdigest()),
            restoration_scope='All ten original graph fields compared in full; actual raw control-trail length/history retained separately. Replay may append control instructions. No raw replay-trail equality claim.',
            audit_work=audit['audit_work'],scheduler=clone(snapshot['scheduler']),
            trail_length=snapshot['trail_length'],full_value_restoration_compared=compared,
            full_effective_value_restoration_compared=effective_compared,
            knowledge_version=version,knowledge_activation=None if knowledge is None else knowledge['activation']))
    def summary():return dict(root_restored=restored,first_snapshot=first)
    return observe,summary


def invoke_search(s,instance,observations,variant=None,check=None,observe_override=None,keep_first=False):
    module=s.modules['search'];oracle=s.modules['oracle'];limits=base_limits(s,'search',variant)
    certificates=[];certificate_audits=[];nogood_limits=clone(NOGOOD_LIMITS)
    observer,summary=observer_for(s,instance,observations,certificates,keep_first)
    callback=s.check if check is None else check
    def certify(packet):
        s.check();proof_limits=base_limits(s,'oracle')
        audit=s.call('oracle','certify',dict(instance=instance,packet=packet,limits=proof_limits),
            lambda:oracle.certify(instance,packet,check=s.check,limits=proof_limits))
        need(audit['status']=='VALID_SAME_INSTANCE_PRIMITIVE_NOGOOD','independent primitive clause acceptance before activation')
        need(canonical(audit['clause'])==canonical({k:packet[k]for k in('id','point','support','witnesses')}),
            'full independently checked certificate join')
        certificates.append(clone(packet));certificate_audits.append(audit)
    def offered(snapshot):
        observer(snapshot)
        if observe_override is not None:observe_override(snapshot)
    value=s.call('search','search',dict(instance=instance,limits=limits,nogoods=s.mode,nogood_limits=nogood_limits),
        lambda:module.search(instance,check=callback,limits=limits,observe=offered,
            nogoods=s.mode,nogood_limits=nogood_limits,observe_certificate=certify))
    state=summary();state.update(certificates=certificates,certificate_audits=certificate_audits)
    return value,state


def invoke_verifier(s,instance,certificate,variant=None,check=None):
    module=s.modules['verifier'];limits=base_limits(s,'verifier',variant)
    callback=s.check if check is None else check
    return s.call('verifier','verify',dict(instance=instance,certificate=certificate,limits=limits),
        lambda:module.verify(instance,certificate,check=callback,limits=limits))


def mutate(instance,recipe):
    value=clone(instance);p=value['palette'];colors=len(p['color_constructors']);changed=None
    if recipe=='north_word_mismatch':value['boundary_NESW'][0][1]=(value['boundary_NESW'][0][1]+1)%colors;changed=['boundary_NESW',0,1]
    elif recipe=='south_stop_mismatch':value['boundary_NESW'][2][1]=(value['boundary_NESW'][2][1]+1)%colors;changed=['boundary_NESW',2,1]
    elif recipe=='exterior_pin_mismatch':value['fixed_background_marks'][0][2]=(value['fixed_background_marks'][0][2]+1)%colors;changed=['fixed_background_marks',0,2]
    elif recipe=='remove_required_center':value['required_centers'].pop();changed=['required_centers']
    elif recipe=='duplicate_required_center':value['required_centers'][-1]=list(value['required_centers'][0]);changed=['required_centers',len(value['required_centers'])-1]
    elif recipe=='extra_admissible_origin':value['admissible_origins'].append([2*value['board_width'],0]);changed=['admissible_origins']
    elif recipe in('remove_assigned_zero_mark','boolean_zero_mark'):
        location=None
        for ti,tile in enumerate(p['tiles']):
            for mi,mark in enumerate(tile['m']):
                if type(mark[2])is int and mark[2]==0:location=(ti,mi);break
            if location is not None:break
        need(location is not None,'actual assigned-zero mark reached');ti,mi=location
        if recipe=='remove_assigned_zero_mark':p['tiles'][ti]['m'].pop(mi)
        else:p['tiles'][ti]['m'][mi][2]=False
        changed=['palette','tiles',ti,'m',mi]
    elif recipe=='reverse_edge_order':p['edge_order']='WSEN';changed=['palette','edge_order']
    elif recipe=='rotation_field':p['tiles'][0]['rotation']=1;changed=['palette','tiles',0,'rotation']
    elif recipe=='wrong_mark_channel':p['tiles'][0]['m'][0][1]='other';changed=['palette','tiles',0,'m',0,1]
    else:raise PolicyFailure('undeclared mutation recipe')
    need(canonical(value)!=canonical(instance),'mutation actually changed the complete original packet')
    return value,changed


def diagnostics(s,inputs,base,normal_rows):
    compiler=s.modules['compiler'];search=s.modules['search'];verifier=s.modules['verifier'];oracle=s.modules['oracle']
    need(base is not None,'actual searched/verified SAT instance needed for refusal controls')
    variant_count=0
    for group in inputs['diagnostics']:
        s.stage='DIAGNOSTIC';group_row=dict(id=group['id'],status='UNFINISHED',variants=[])
        s.diagnostics.append(group_row);before=s.root_calls
        for variant in group['variants']:
            s.active=group['id']+'/'+variant['id'];s.check();start=s.root_calls;operation=variant['operation']
            record=dict(id=variant['id'],expected=variant['expected'],declaration=clone(variant),status='UNFINISHED',
                check_calls_before=start,role=variant.get('role','compiler'if operation.startswith('compile')else'verifier'),
                callback=variant.get('callback'),stage=operation,own_resource=None,exact_foreign_identity=None)
            group_row['variants'].append(record);actual_error=None;returned=None;reached=False;details={}
            try:
                if operation in('compile_palette','compile_finite_problem'):
                    machine=clone(variant['machine']);word=compiler_word(variant.get('initial_word',[]))
                    returned=invoke_compiler(s,operation,machine,word,variant.get('steps'),variant)
                elif operation=='mutate_actual_compiled_instance':
                    changed,path=mutate(base['instance'],variant['recipe']);reached=True
                    details.update(mutation_path=path,mutated_instance=changed,original_case=base['case_id'])
                    returned=invoke_verifier(s,changed,base['certificate'])
                elif operation=='compile_with_mutating_callback':
                    machine=clone(variant['machine']);after=clone(machine);at=variant['at_callback'];hits=0
                    need(variant['path']==['blank'],'only declared persistent scalar mutation')
                    after['blank']=variant['replacement'];limits=base_limits(s,'compiler',variant)
                    def mutation_check():
                        nonlocal hits,reached
                        s.check();hits+=1
                        if hits==at:machine['blank']=variant['replacement'];reached=True
                    returned=invoke_compiler(s,'compile_palette',machine,variant=variant,check=mutation_check,
                        expected_after=dict(machine=after,limits=limits))
                    details['local_callbacks']=hits
                elif operation=='inject_external_fault':
                    role=variant['role'];hits=0
                    if variant['sentinel']=='foreign_compile_limit':
                        sentinel=s.call('compiler','CompileLimit',{},lambda:compiler.CompileLimit('planned_foreign',0))
                    else:sentinel=PlannedForeign('planned foreign callback object')
                    def fault(*unused):
                        nonlocal hits,reached
                        s.check();hits+=1
                        if hits==variant['at_callback']:reached=True;raise sentinel
                    try:
                        if role=='compiler':returned=invoke_compiler(s,'compile_palette',clone(inputs['machines'][0]['machine']),check=fault)
                        elif role=='search':
                            if variant['callback']=='observe':returned=invoke_search(s,base['instance'],[],observe_override=fault)
                            else:returned=invoke_search(s,base['instance'],[],check=fault)
                        elif role=='verifier':returned=invoke_verifier(s,base['instance'],base['certificate'],check=fault)
                        elif role=='oracle':
                            limits=base_limits(s,'oracle');returned=s.call('oracle','audit_snapshot',
                                dict(instance=base['instance'],snapshot=base['snapshot'],limits=limits),
                                lambda:oracle.audit_snapshot(base['instance'],base['snapshot'],check=fault,limits=limits,certificates=[]))
                        else:raise PolicyFailure('unknown fault role')
                    except BaseException as error:
                        s.fault_gate();need(error is sentinel,'exact planned foreign exception identity')
                        actual_error=error;details.update(exact_exception_identity=True,local_callbacks=hits)
                    need(reached and actual_error is sentinel,'fault callback reached and escaped, not normalized')
                elif operation=='exercise_owned_work_limit':
                    role=variant['role'];reached=True
                    if role=='search':returned=invoke_search(s,base['instance'],[],variant=variant)[0]
                    elif role=='verifier':returned=invoke_verifier(s,base['instance'],base['certificate'],variant)
                    elif role=='oracle':
                        limits=base_limits(s,'oracle',variant)
                        try:returned=s.call('oracle','audit_snapshot',dict(instance=base['instance'],snapshot=base['snapshot'],limits=limits),
                            lambda:oracle.audit_snapshot(base['instance'],base['snapshot'],check=s.check,limits=limits,certificates=[]))
                        except BaseException as error:
                            s.fault_gate();need(s.own_oracle_limit(error),'actual private oracle own-work limit')
                            actual_error=error;details['own_limit']=information(error)
                    else:raise PolicyFailure('unknown own-limit role')
                elif operation=='compare_every_root_restoration':
                    reached=True;need(len(normal_rows)==680 and all(r['root_restored']is True for r in normal_rows),'every complete root compared')
                    returned=dict(complete_roots=len(normal_rows))
                else:raise PolicyFailure('unimplemented declared diagnostic operation')
            except BaseException as error:
                s.fault_gate();actual_error=error;reached=True
            s.fault_gate();expected=variant['expected']
            if operation=='compile_with_mutating_callback':
                details.update(local_callbacks=hits,mutation_reached=hits>=variant['at_callback'])
                need(hits>=variant['at_callback'],'declared persistent mutation callback actually reached')
            if expected=='DeclarationError':need(type(actual_error)is compiler.DeclarationError,'actual compiler declaration refusal')
            elif expected=='OWN_COMPILE_LIMIT_NO_RETURNED_CANDIDATE':
                need(type(actual_error)is compiler.CompileLimit and returned is None and
                     actual_error.reason in variant['limit_overrides'],'actual declared compiler own cap')
            elif expected=='INDEPENDENT_INSTANCE_OR_PALETTE_REJECTION':need(type(actual_error)is verifier.InvalidCertificate,'actual independent refusal')
            elif expected=='EXACT_FOREIGN_OBJECT_PROPAGATED':need(details.get('exact_exception_identity')is True,'finite exact foreign-object control')
            elif expected=='OWNED_RESOURCE_NO_ACCEPTANCE':
                if variant['role']=='oracle':need(type(actual_error)is oracle.SnapshotLimit and s.own_oracle_limit(actual_error),'own oracle limit')
                else:need(type(returned)is dict and returned.get('status')=='UNKNOWN'and returned.get('reason')=='work','own per-call UNKNOWN, no acceptance')
            elif expected=='EXACT_FULL_ROOT_STATE_EQUALITY':need(returned=={'complete_roots':680},'full-domain root restoration diagnostic')
            else:raise PolicyFailure('unknown diagnostic expectation')
            record.update(status='PASSED',reached=reached or actual_error is not None,
                check_calls_after=s.root_calls,error=None if actual_error is None else information(actual_error),
                returned=returned,details=details,expectation_satisfied=True,foreign_fault_misclassified=False,
                actual_outcome='RAISED'if actual_error is not None else'RETURNED',
                actual_class=None if actual_error is None else type(actual_error).__name__,
                actual_reason=getattr(actual_error,'reason',None)if actual_error is not None else returned.get('reason')if type(returned)is dict else None,
                own_resource=True if expected in('OWN_COMPILE_LIMIT_NO_RETURNED_CANDIDATE','OWNED_RESOURCE_NO_ACCEPTANCE')else None,
                exact_foreign_identity=True if expected=='EXACT_FOREIGN_OBJECT_PROPAGATED'else None)
            variant_count+=1
        group_row.update(status='PASSED',reached=all(v['reached']for v in group_row['variants']),
            expectation_satisfied=True,foreign_fault_misclassified=False,
            check_calls_before=before,check_calls_after=s.root_calls)
    need(variant_count==55 and len(s.diagnostics)==30,'all original55 variants/30groups actually reached')
    s.active=None


def bind_original_case(s,instance,machine,case):
    # Literal input/frame binding for SAT AND exhausted decisions, before search.
    s.check()
    need(type(instance)is dict and type(instance['palette'])is dict and
         type(instance['palette']['machine'])is dict and
         canonical(instance['palette']['machine'])==canonical(machine),
         'instance full palette machine is exact original machine')
    word=case['initial_word'];steps=case['steps'];width=len(word);height=steps+1
    need(type(word)is list and type(instance['initial_word'])is list and
         canonical(instance['initial_word'])==canonical(word),'instance full original initial word')
    expected_dimensions=dict(machine_steps=steps,tape_width=width,board_width=width+2,board_height=height)
    for name,wanted in expected_dimensions.items():
        s.check();need(type(wanted)is int and type(instance[name])is int and instance[name]==wanted,
                       'strict original case dimension '+name)
    constructors=instance['palette']['color_constructors'];need(type(constructors)is list,'full verified palette constructors')
    color_ids={}
    for index,value in enumerate(constructors):
        s.check();key=canonical(value);need(key not in color_ids,'unique full literal palette color constructor')
        color_ids[key]=index
    def color(value):
        s.check();key=canonical(value);need(key in color_ids,'original boundary constructor present in full verified palette')
        return color_ids[key]
    north=[color(['side','left','run'])]+[color(['cell',cell])for cell in word]+[color(['side','right','run'])]
    south=[color(['side','left','done'])]+[color(['stop'])]*width+[color(['side','right','done'])]
    east=[color(['exterior','right'])]*height;west=[color(['exterior','left'])]*height
    boundary=[north,east,south,west]
    need(type(instance['boundary_NESW'])is list and canonical(instance['boundary_NESW'])==canonical(boundary),
         'full boundary NESW bound to original word and exact time/acceptance frame')
    pins=[]
    for y in range(height):
        s.check();pins.append([[-1,2*y],'edge',west[y]])
        pins.append([[2*(width+2)-1,2*y],'edge',east[y]])
    for x in range(width+2):
        s.check();pins.append([[2*x,-1],'edge',north[x]])
        pins.append([[2*x,2*height-1],'edge',south[x]])
    need(type(instance['fixed_background_marks'])is list and
         canonical(instance['fixed_background_marks'])==canonical(pins),
         'complete ordered exterior pin list bound to original case')
    s.check()
    return dict(status='EXACT_ORIGINAL_CASE_AND_BOUNDARY_BOUND',original_case=clone(case),
        original_machine=clone(machine),expected_dimensions=expected_dimensions,
        expected_boundary_NESW=boundary,expected_fixed_background_marks=pins,
        full_canonical_comparisons=True,mathematical_authority=False)


def calibrate(s,inputs):
    c=s.modules['compiler'];palettes=[];palette_by_id={};machine_by_id={};palette_checks=[]
    for item in inputs['machines']:
        s.stage='FULL_MACHINE_PALETTE';s.active=item['id'];machine=clone(item['machine']);machine_by_id[item['id']]=machine
        original=invoke_compiler(s,'compile_palette',machine);s.retained.append(original)
        projected=clone(original);need(canonical(projected)==canonical(original),'complete tuple-to-array JSON projection')
        palette=projected['palette']
        need(type(palette['machine'])is dict and canonical(palette['machine'])==canonical(machine),
             'complete machine-only palette exact original machine')
        audit=palette_check(s,palette)
        palette_by_id[item['id']]=palette;palettes.append(dict(id=item['id'],palette=palette,
            compile_palette_fields={k:v for k,v in projected.items()if k!='palette'}))
        palette_checks.append(dict(id=item['id'],check=audit))
    base=None;all_complete=True
    for case in inputs['cases']:
        s.stage='COMPLETE_CASE';s.active=case['id'];s.phase('CASE_STARTED');machine=machine_by_id[case['machine_id']]
        original=invoke_compiler(s,'compile_finite_problem',machine,compiler_word(case['initial_word']),case['steps'])
        s.retained.append(original);instance=clone(original);need(canonical(instance)==canonical(original),'full compiler object JSON projection')
        need(canonical(instance['palette'])==canonical(palette_by_id[case['machine_id']]),'entire machine-only palette invariant')
        input_binding=bind_original_case(s,instance,machine,case)
        observations=[];result,restoration=invoke_search(s,instance,observations,keep_first=base is None)
        s.retained.append(result);verification=None
        if result['status']=='TILING_CANDIDATE':
            verification=invoke_verifier(s,instance,result['certificate'])
            need(verification['status']=='VALID_FINITE_ACCEPTING_TILING','fresh independent complete SAT certificate check')
            s.retained.append(verification)
        # The reference is strictly after search, never used as a suggestion.
        reference=reference_after_search(s,machine,case['initial_word'],case['steps'])
        sat=result['status']=='TILING_CANDIDATE';complete=result['status']in('TILING_CANDIDATE','FINITE_EXHAUSTED')
        agreement=complete and sat is reference['accepts_exact_steps']
        if complete:need(agreement,'independent whole TM agreement for complete finite decision')
        else:all_complete=False
        if complete:need(restoration['root_restored']is True,'full-value initial/restored census')
        if base is None and sat:
            base=dict(case_id=case['id'],instance=instance,certificate=result['certificate'],snapshot=restoration['first_snapshot'])
        fields={k:v for k,v in instance.items()if k!='palette'}
        compact_problem=dict(fields=fields,palette_id=case['machine_id'])
        s.expanded_subtree_delta+=len(canonical(instance))-len(canonical(compact_problem))
        row=dict(id=case['id'],original_case=clone(case),compiler_problem=dict(fields=fields,palette_id=case['machine_id']),
            input_binding=input_binding,
            search=result,verification=verification,reference_after_search=reference,observations=observations,
            root_restored=restoration['root_restored'],status='FINITE_EXACT_TILING'if sat else result['status'],
            independent_TM_agreement=agreement,graph_census_complete=complete and restoration['root_restored'],
            graph_audit_mismatches=0,graph_states_checked=len(observations),complete_point_certificate_verified=sat)
        row['independent_primitive_certificates']=restoration['certificates']
        row['independent_primitive_certificate_audits']=restoration['certificate_audits']
        s.rows.append(row);s.phase('CASE_COMPLETED')
    diagnostics(s,inputs,base,s.rows)
    need(len(s.rows)==inputs['case_count']==680,'whole frozen case domain retained')
    return dict(schema='complete-finite-wang-calibration-packet-v1',inputs=inputs,
        palettes=palettes,palette_checks=palette_checks,rows=s.rows,diagnostics=s.diagnostics,
        palette_reconstruction='Each row.compiler_problem.fields plus the full palette at matching palette_id reconstructs its entire ordinary compiler result. No mathematical field omitted.',
        expanded_subtree_delta_bytes=s.expanded_subtree_delta,
        expanded_accounting='Expanded view replaces each compiler_problem reference object with its exact complete ordinary compiler problem; palette bank remains. Canonical byte length is stored packet bytes plus sum of exact subtree byte deltas. Both views include one external LF.',
        snapshot_lifecycle='Each offered detached snapshot and independent full census held through complete actual audit; branch/root baselines held through full canonical value comparison. Intermediate values then released. Archive every offered snapshot size/hash/reason/audit-cost receipt, not reconstructable all-state values; no hash-only verification.',
        all_complete=all_complete,nogood_mode=s.mode,nogood_limits=NOGOOD_LIMITS,
        per_API_inclusive_wall_ns=s.inclusive_wall_ns,phase_receipts=s.phase_receipts,
        timing_scope='Inclusive guarded API action time; nested oracle/certificate intervals lie inside search. Do not sum as exclusive cost. Failure counters are cutoff observations.',
        full_pipeline_qualified=False,mathematical_proof_accepted=False)


def main(plan_path):
    plan_raw=Path(plan_path).read_bytes();need(len(plan_raw)<=16777216,'bounded plan')
    plan=json.loads(plan_raw);plan_pin=descriptor(plan_path,plan_raw)
    need(type(plan)is dict and set(plan)=={'schema','invocation_id','actual_directory','python','sources','inputs','limits','declaration','runtime_closure','authorization'}and
         plan['schema']=='ROOT-wang-encoding-qualification-plan-v1','exact whole once plan')
    need(plan['limits']==OUTER_LIMITS and set(plan['sources'])==set(SOURCE_ROLES),'original outer caps and seven Sources')
    actual=Path(plan['actual_directory']);need(actual.is_absolute()and actual==actual.resolve()and actual.is_dir(),'owned existing once actual')
    consumed_raw=(actual/'CONSUMED.json').read_bytes();consumed=json.loads(consumed_raw)
    need(consumed['plan']==plan_pin and consumed['invocation_id']==plan['invocation_id']and
         consumed['schema']=='wang-encoding-qualification-consumed-v1'and
         type(consumed['maximum_worker_launches'])is int and consumed['maximum_worker_launches']==1 and consumed['consumed_before_Popen']is True and
         type(consumed['began_ns'])is int and consumed['work_deadline_ns']==consumed['began_ns']+180000000000 and
         consumed['overall_deadline_ns']==consumed['began_ns']+210000000000,'original inherited Source-entry epoch')
    s=Session(plan,plan_pin,consumed,actual)
    try:
        s.check();need(descriptor(__file__,Path(__file__).read_bytes())==plan['sources']['worker'],'whole worker Source')
        for role,(sha,size)in SOURCE_PINS.items():need((plan['sources'][role]['sha256'],plan['sources'][role]['bytes'])==(sha,size),'exact component Source pin')
        for pin in plan['sources'].values():checked(pin)
        checked(plan['python'],67108864)
        declaration=json.loads(checked(plan['declaration']));closure=json.loads(checked(plan['runtime_closure']))
        need(declaration['schema']=='ROOT-wang-encoding-qualification-declaration-v1'and
             declaration['limits']==OUTER_LIMITS and declaration['component_limits']==COMPONENT_LIMITS and
             declaration['checkpoint_limit']==CHECKPOINT_LIMIT and
             declaration['nogood_limits']==NOGOOD_LIMITS and declaration['nogood_mode']in MODES,
             'prospectively fixed worker limits/mode')
        s.mode=declaration['nogood_mode']
        need(closure['schema']=='ROOT-wang-encoding-runtime-closure-v1'and closure['python']==plan['python']and
             closure['sources']==plan['sources']and closure['declaration']==plan['declaration'],'complete current Source/runtime closure')
        for pin in closure['stdlib_files']:checked(pin)
        need(plan['inputs']==declaration['inputs']and len(plan['inputs'])==1,'one whole frozen input capsule')
        input_raw=checked(plan['inputs'][0]['pin'],134217728)
        need(len(input_raw)==INPUT_BYTES and hashlib.sha256(input_raw).hexdigest()==INPUT_SHA,'all original680+55 preimage')
        inputs=json.loads(input_raw);s.retained.append(inputs)
        need([v['id']for v in inputs['cases']]==declaration['case_ids']and
             [v['id']for v in inputs['machines']]==declaration['machine_ids']and
             [v['id']for v in inputs['diagnostics']]==declaration['diagnostic_ids'],'full prospectively frozen order')
        subject={k:v for k,v in plan.items()if k!='authorization'};auth=json.loads(checked(plan['authorization']))
        need(auth['actual_execution_authorized']is True and auth['author_identity']=='/root'and
             type(auth['maximum_actual_invocations'])is int and auth['maximum_actual_invocations']==1 and
             auth['subject_sha256']==hashlib.sha256(canonical(subject)).hexdigest(),'exact max-one Root subject authorization')
        s.write_json('WORKER_CONSUMED.json',dict(plan=plan_pin,pid=os.getpid(),ppid=os.getppid(),worker_entry_ns=ENTRY_NS,maximum_invocations=1),1048576)
        def audit(event,args):
            if event in FORBIDDEN_EVENTS:
                s.denied.append(event);s.policy(lambda:need(False,'forbidden process/network/dlopen event'))
        sys.addaudithook(audit)
        for role in('compiler','search','verifier','oracle'):s.load(role)
        s.stage='CALIBRATION';packet=calibrate(s,inputs);s.active=None
        s.guard();s.stage='FULL_PACKET_WRITE'
        output=s.write_json('canonical-wang-calibration.json',packet,134217728-RESERVE_BYTES)
        s.output_pins.append(output)
        need(packet['all_complete'],'UNKNOWN leaves calibration false, never expected-outcome filtering')
        q=dict(schema='wang-encoding-calibration-candidate-v1',status='COMPLETE_FINITE_CALIBRATION_CANDIDATE',
            outputs=s.output_pins,case_ids=declaration['case_ids'],machine_ids=declaration['machine_ids'],
            diagnostic_ids=declaration['diagnostic_ids'],full_palettes_verified=len(packet['palette_checks']),
            rows=[{k:r[k]for k in('id','status','independent_TM_agreement','graph_census_complete','graph_audit_mismatches','graph_states_checked','complete_point_certificate_verified')}for r in s.rows],
            diagnostics=s.diagnostics,diagnostics_passed=len(s.diagnostics),all_palettes_invariant_across_instances=True,
            foreign_faults_preserved_exactly=True,root_check_calls=s.root_calls,
            root_check_calls_scope='snapshot before result metadata serialization; later callbacks remain under the same invocation ceiling',
            compiler_calls=s.calls('compiler'),search_calls=s.calls('search'),verifier_calls=s.calls('verifier'),oracle_calls=s.calls('oracle'),
            oracle_work=s.oracle_work,oracle_work_unavailable_calls=s.oracle_work_unavailable,
            nogood_mode=s.mode,nogood_limits=NOGOOD_LIMITS,
            independent_primitive_certificate_count=sum(len(r['independent_primitive_certificates'])for r in s.rows),
            per_API_inclusive_wall_ns=s.inclusive_wall_ns,
            oracle_work_scope='sum exported successful audit_work and owned-limit attempted_work; foreign faults without exported counter remain unavailable, never fabricated zero',
            full_pipeline_qualified=False,mathematical_proof_accepted=False,fixed_FOL_palette_qualified=False,
            gcts_rl_advantage_established=False,learned_markings=False,trained_RL=False)
        zeros=dict(Native_calls=0,Model_calls=0,inverse_calls=0,Reader_calls=0,proof_checker_calls=0,opaque_program_decodes=0)
        payload=dict(schema='wang-encoding-qualification-result-v1',invocation_id=plan['invocation_id'],plan=plan_pin,
            declaration=plan['declaration'],runtime_closure=plan['runtime_closure'],qualification=q,outputs=s.output_pins,
            denied_events=s.denied,canonical_logical_bytes=output['bytes'],compiler_calls=s.calls('compiler'),
            expanded_canonical_packet_bytes=output['bytes']+s.expanded_subtree_delta,
            search_calls=s.calls('search'),verifier_calls=s.calls('verifier'),oracle_calls=s.calls('oracle'),
            full_pipeline_qualified=False,scientific_acceptance=False,mathematical_proof_accepted=False,**zeros)
        s.stage='RESULT_WRITE';result=s.write_json('result.json',payload,134217728-RESERVE_BYTES-output['bytes'])
        s.guard()
        for pin in closure['stdlib_files']:checked(pin)
        checked(plan['inputs'][0]['pin'],134217728);s.check()
        logical=output['bytes']+result['bytes'];expanded=output['bytes']+s.expanded_subtree_delta+result['bytes']
        need(logical<=134217728 and 0<expanded<=134217728,'stored AND fully expanded logical result caps')
        header=dict(schema='wang-encoding-qualification-worker-receipt-v1',version=VERSION,
            invocation_id=plan['invocation_id'],plan=plan_pin,began_ns=s.began,work_deadline_ns=s.work_deadline,
            overall_deadline_ns=s.overall_deadline,pid=os.getpid(),ppid=os.getppid(),worker_entry_ns=ENTRY_NS,
            result=result,outputs=s.output_pins,logical_result_bytes=logical,expanded_logical_result_bytes=expanded,outer_metadata_reservation=RESERVE_BYTES,
            finite_encoding_candidate=True,full_pipeline_qualified=False,scientific_acceptance=False,
            mathematical_proof_accepted=False,call_started=s.started,call_completed=s.completed,call_raised=s.raised,
            root_check_calls=s.root_calls,positive_worker_completed_ns=NOW(),snapshot_cutoff_scope='before worker receipt serialization/final callback/known exit',**zeros)
        s.stage='HEADER_WRITE';s.write_json('worker-receipt.json',header,4194304)
        need(sum(p.stat().st_size for p in actual.iterdir()if p.is_file())+RESERVE_BYTES<=134217728,'complete physical ledger/reservation')
        s.check();return 0
    except BaseException as error:
        primary=s.first_fault if s.first_fault is not None else error
        prefix=[]
        for group in s.diagnostics:
            variants=[]
            for row in group['variants']:
                variants.append({key:row[key]for key in('id','expected','status','check_calls_before','check_calls_after',
                    'actual_outcome','actual_class','actual_reason','own_resource','exact_foreign_identity','reached')if key in row})
            prefix.append(dict(id=group['id'],status=group['status'],variants=variants))
        failure=dict(schema='wang-encoding-worker-failure-v1',status='FAILED_OR_UNFINISHED',invocation_id=plan['invocation_id'],
            plan=plan_pin,stage=s.stage,active_row=s.active,completed_case_ids=[r['id']for r in s.rows],
            diagnostic_prefix=prefix,call_started=s.started,call_completed=s.completed,call_raised=s.raised,
            compiler_calls=None if 'compiler'not in s.modules else s.calls('compiler'),
            search_calls=None if 'search'not in s.modules else s.calls('search'),
            verifier_calls=None if 'verifier'not in s.modules else s.calls('verifier'),
            oracle_calls=None if 'oracle'not in s.modules else s.calls('oracle'),
            root_check_calls=s.root_calls,first_available_fault=information(primary),outputs=s.output_pins,
            nogood_mode=s.mode,per_API_inclusive_wall_ns=s.inclusive_wall_ns,phase_receipts=s.phase_receipts,
            failure_scope='Diagnostic prefix only, no failed-prefix acceptance or result rescue; inclusive times are not exclusive and partial failed API work may be unavailable.',
            finite_encoding_candidate=False,scientific_acceptance=False,mathematical_proof_accepted=False,
            full_pipeline_qualified=False,Native_calls=0,Model_calls=0,inverse_calls=0,Reader_calls=0,proof_checker_calls=0)
        try:s.write_json('worker-failure.json',failure,1048576,closure=True)
        except BaseException:
            try:s.write_json('worker-failure-unavailable.json',dict(status='UNAVAILABLE',admitted=False,stage=s.stage,
                first_fault=information(primary),call_started=s.started,call_completed=s.completed),1048576,closure=True)
            except BaseException:pass
        return 2


if __name__=='__main__':
    need(len(sys.argv)==2,'one once-plan path')
    raise SystemExit(main(sys.argv[1]))
