"""Passive whole saved-JSON projection only, never a mathematical subject call."""
from pathlib import Path
import hashlib
import json
import datetime
D=Path('/private/tmp/gcts-wang-receptor-ROOT-20261019-v1')
def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def pin(path):
    raw=path.read_bytes();return dict(path=str(path.resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def read(path):return json.loads(path.read_bytes())
def main():
    rows=[]
    for label in('off','on'):
        planpath=D/('plan-authorized-'+label+'-v1.json');plan=read(planpath)
        actual=Path(plan['actual_directory']);runnerpath=actual/'runner-receipt.json'
        terminalpath=D/('plan-authorized-'+label+'-v1-terminal-observation')/'terminal.json'
        r=read(runnerpath);t=read(terminalpath)
        if r['plan']!=pin(planpath)or t['plan']!=pin(planpath)or t['runner_receipt']!=pin(runnerpath):raise ValueError('complete current plan/runner/terminal binding')
        closed=(r['worker_reaped']is True and r['owned_group_absent']is True and
            r['regular_logs_closed']is True and t['terminal_observed_ns']<r['overall_deadline_ns'])
        failurepath=actual/'worker-failure.json';f=read(failurepath)if failurepath.is_file()else None
        q=None
        if t['terminal_gate_passed']is True:
            if not(r['resource_candidate_accepted']is True and r['finite_encoding_candidate']is True):raise ValueError('positive gate conjunction')
            result=read(actual/'result.json');q=result['qualification']
            if len(q['case_ids'])!=680 or len(q['diagnostics'])!=30:raise ValueError('whole workload, no prefix')
        rows.append(dict(mode=label,plan=pin(planpath),runner=pin(runnerpath),terminal=pin(terminalpath),
            terminal_closed_before210=closed,terminal_gate_passed=t['terminal_gate_passed'],
            complete_calibration_candidate=q is not None,resource_candidate_accepted=r['resource_candidate_accepted'],
            elapsed_seconds=t.get('runner_clock_elapsed_seconds'),worker_exit_code=r.get('worker_exit_code'),
            worker_wait4_usage=r.get('worker_wait4_usage'),physical_ledger=r.get('final_physical_ledger'),
            primary_failure=r.get('primary_failure'),failure=None if f is None else pin(failurepath),
            diagnostic_only_completed_case_ids=[]if f is None else f['completed_case_ids'],
            diagnostic_only_active_case=None if f is None else f['active_row'],
            diagnostic_only_call_started={}if f is None else f['call_started'],
            diagnostic_only_call_completed={}if f is None else f['call_completed'],
            diagnostic_only_call_raised={}if f is None else f['call_raised'],
            diagnostic_only_prefix=[]if f is None else f['diagnostic_prefix'],
            diagnostic_only_API_inclusive_wall_ns={}if f is None else f.get('per_API_inclusive_wall_ns',{}),
            diagnostic_only_phase_receipts=[]if f is None else f.get('phase_receipts',[]),
            qualification=q,scientific_acceptance=False,mathematical_proof_accepted=False))
    result=dict(schema='ROOT-reusable-nogood-saved-comparison-v1',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        classification='PROGRESS',goal_status='active',rows=rows,whole_case_count=680,original_diagnostic_variants=55,
        original_diagnostic_groups=30,actual_invocations=2,all_actuals_closed=all(r['terminal_closed_before210']for r in rows),
        comparison_scope='Fresh V3 off then on, single observation each. Same original680+55, order, caps and Sources except declared mode. Diagnostic prefixes are not admitted results and cannot rescue a failed whole run.',
        per_API_time_scope='Inclusive action intervals only, wrapper/guard costs outside intervals; nested oracle/certificate time lies inside search. Interrupted actions may have no interval. Do not sum as exclusive cost.',
        geometric_marking_implementation=False,marking_construction='Separate finite unexecuted instance-specific projection argument',
        trained_RL=False,fixed_FOL_palette_qualified=False,full_pipeline_qualified=False,gcts_rl_advantage_established=False,
        new_automatically_discovered_theorems=0,preserved_prior_failures=True,no_target_execution_in_projection=True)
    path=D/'ROOT-saved-comparison-v1.json'
    with path.open('xb')as f:f.write(json.dumps(result,sort_keys=True,indent=2,ensure_ascii=False).encode()+b'\n')
    print(json.dumps(dict(summary=pin(path),outcomes=[dict(mode=r['mode'],elapsed=r['elapsed_seconds'],complete=r['complete_calibration_candidate'],closed=r['terminal_closed_before210'],diagnostic_prefix_cases=len(r['diagnostic_only_completed_case_ids']))for r in rows]),sort_keys=True))
if __name__=='__main__':main()
