"""Task-only file author in isolated publisher; never reads primary reader."""
from pathlib import Path
import subprocess
import hashlib
import json
from html.parser import HTMLParser
D=Path('/private/tmp/gcts-wang-receptor-ROOT-20261019-v1')
P=Path('/private/tmp/gcts-split-controls-publish-20261015')
REL='docs/research/gcts-rl-renewal/conditional-inventory/'
NAMES=('reusable-nogoods.html','reusable-nogoods-summary.json','reusable-nogoods-manifest.json','reusable-nogoods-evidence.tar.gz','nogood-marking-construction.html')
def pin(path):
    raw=path.read_bytes();return dict(path=str(path.resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
class Parse(HTMLParser):
    def __init__(self):super().__init__(convert_charrefs=False);self.html=0;self.main=0;self.svgs=0
    def handle_starttag(self,tag,attrs):
        if tag=='html':self.html+=1
        if tag=='main':self.main+=1
        if tag=='svg':self.svgs+=1
def main():
    status=subprocess.run(['git','status','--porcelain'],cwd=P,check=True,stdout=subprocess.PIPE).stdout
    if status:raise ValueError('preserve unrelated publisher changes: require clean before mutation')
    base=subprocess.run(['git','rev-parse','HEAD'],cwd=P,check=True,stdout=subprocess.PIPE,text=True).stdout.strip()
    if base!='ad04ca42ee844a2175784e23d5cb2df640162c84':raise ValueError('new base needs reviewed join')
    validation=[]
    for name in NAMES:
        path=D/'publication'/name;raw=path.read_bytes()
        if name.endswith('.html'):
            parser=Parse();parser.feed(raw.decode());parser.close()
            if parser.html!=1 or parser.main!=1 or '__ROWS__'in raw.decode():raise ValueError('complete HTML document')
            validation.append(dict(name=name,one_html=True,one_main=True,svg_figures=parser.svgs))
        (P/REL/name).write_bytes(raw)
    reader_rel=REL+'reader.html'
    original=subprocess.run(['git','show','HEAD:'+reader_rel],cwd=P,check=True,stdout=subprocess.PIPE).stdout
    source=original.decode()
    if source.count('</main>')!=1 or 'id="reusable-nogood-comparison"'in source:raise ValueError('one fresh isolated reader append')
    addition='''<section id="reusable-nogood-comparison"><h2>Reusable failures: off/on measurement and colored construction</h2>
<p>The first full V3 comparison produced two deadline negatives: diagnostic prefixes of \\(68\\) cases off and \\(53\\) on. The cache arm recorded \\(842\\) independent certification returns, with no archived activated/reused clause catalogue or admitted full-bank result. Neither arm reached the original diagnostic phase. There is no positive performance signal for this implementation.</p>
<p><a href="reusable-nogoods.html">Read the complete comparison, costs and frozen evidence</a>. The separate <a href="nogood-marking-construction.html">colored long-range marking construction</a> supplies an informal finite projection/extension argument, with exact origins and anchors. The construction is unexecuted and distinct from the direct clause cache. Parallel agents wrote the search and independent oracle and reviewed their coupling; neither trained RL nor a new mathematical theorem discovered by proof search is claimed.</p></section>
'''
    updated=source.replace('</main>',addition+'</main>')
    if updated.replace(addition,'')!=source:raise ValueError('exact append-only inverse')
    (P/reader_rel).write_text(updated)
    record=dict(schema='ROOT-isolated-publication-preparation-v1',base_commit=base,
        source='Isolated publisher Git object only; no primary reader/index read or mutation',
        reader_original_sha256=hashlib.sha256(original).hexdigest(),reader_append_only=True,
        validation=validation,files=[dict(relative=REL+n,descriptor=pin(P/REL/n))for n in NAMES]+[dict(relative=reader_rel,descriptor=pin(P/reader_rel))],
        full_target_execution_in_preparation=False,overview_index_touched=False)
    with (D/'ROOT-publication-preparation-v1.json').open('x')as f:json.dump(record,f,sort_keys=True,indent=2);f.write('\n')
    print(json.dumps(dict(files=len(record['files']),base=base,HTML_validation=validation),sort_keys=True))
if __name__=='__main__':main()
