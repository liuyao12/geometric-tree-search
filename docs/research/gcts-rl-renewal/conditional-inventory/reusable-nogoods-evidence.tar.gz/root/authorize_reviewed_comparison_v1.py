"""Root-only ordinary authorization metadata author; no subject execution."""
from pathlib import Path
import hashlib
import json
import sys
D=Path('/private/tmp/gcts-wang-receptor-ROOT-20261019-v1')
def canon(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def pin(path):
    raw=path.read_bytes();return dict(path=str(path.resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(name,value):
    path=D/name
    with path.open('xb')as f:f.write(json.dumps(value,sort_keys=True,indent=2,ensure_ascii=False).encode()+b'\n')
    return pin(path)
def main():
    if len(sys.argv)!=3:raise ValueError('off and on complete review paths required')
    for label,path in zip(('off','on'),map(Path,sys.argv[1:])):
        offer=json.loads((D/('Source-only-offer-'+label+'-v1.json')).read_bytes())
        review=json.loads(path.read_bytes());subject=offer['subject']
        if not(review['schema']=='wang-encoding-Source-prospective-review-v1'and
            review['reviewer_identity']=='/root/conventional_control_review'and
            review['review_passed']is True and review['source_only']is True and
            type(review['component_calls'])is int and review['component_calls']==0 and
            review['actual_execution_authorized']is False and review['subject']==subject and
            review['subject_sha256']==hashlib.sha256(canon(subject)).hexdigest()):
            raise ValueError('exact independent current Source/prospective PASS required')
        for descriptor in subject['sources'].values():
            if pin(Path(descriptor['path']))!=descriptor:raise ValueError('changed Source')
        if Path(subject['actual_directory']).exists():raise ValueError('already consumed actual')
        auth=dict(schema='ROOT-wang-encoding-authorization-v1',author_identity='/root',actual_execution_authorized=True,
            maximum_actual_invocations=1,subject_sha256=offer['subject_sha256'],review=pin(path),
            scope='One Root-owned original full680+55 actual in the exact declared mode, after fresh all-peer STOP barrier. Original180/210/1GiB/128MiB and all work limits. No failed-prefix admission/retry/cap raise/smaller bank. This grant is not component qualification or mathematical acceptance.')
        ap=save('authorization-'+label+'-v1.json',auth)
        pp=save('plan-authorized-'+label+'-v1.json',dict(subject,authorization=ap))
        print(json.dumps(dict(mode=label,plan=pp),sort_keys=True))
if __name__=='__main__':main()
