"""Raw Source author only; no subject execution."""
from pathlib import Path
D=Path('/private/tmp/gcts-wang-receptor-ROOT-20261019-v1')
raw=(D/'qualify_wang_reusable_worker_DRAFT_v1.py').read_text()
def edit(before,after):
    global raw
    if raw.count(before)!=1:raise ValueError('nonunique edit '+before[:80])
    raw=raw.replace(before,after)
edit("        census=audit['census'];physical=audit['physical_context_census']\n        body=canonical(census);core=canonical(physical);packet=canonical(snapshot)", """        census=audit['census'];physical=audit['physical_context_census']
        graph_fields=('points','candidates','chosen','marks','forward','reverse',
            'dependencies','boundary','exclusions','scheduler')
        # Exact complete original graph projections. Raw control-trail length
        # and historical last_restore are separately retained and checked: a
        # suspended/replayed overlay legitimately appends control instructions.
        graph_value={k:census[k]for k in graph_fields}
        physical_value={k:physical[k]for k in graph_fields}
        body=canonical(graph_value);core=canonical(physical_value);packet=canonical(snapshot)
        need(physical['trail_length']==snapshot['trail_length'],'literal observed raw trail length')""")
edit("            need(initial is None,'one initial graph');initial=core", "            need(initial is None and snapshot['trail_length']==0,'one initial graph/empty trail');initial=core")
edit("            branches.append(dict(physical=core,effective=body,version=version))", "            branches.append(dict(physical=core,effective=body,version=version,trail_length=snapshot['trail_length']))")
edit("            saved=branches.pop();need(body==saved['effective']and core==saved['physical'],", "            saved=branches.pop();need(body==saved['effective']and core==saved['physical']and\n                snapshot['trail_length']==saved['trail_length'],")
edit("            saved=branches.pop();need(core==saved['physical'],'full original physical/context/trail restoration')", "            saved=branches.pop();need(core==saved['physical']and\n                knowledge['last_restore']['checkpoint']==saved['trail_length'],\n                'full original physical/context graph and saved raw undo checkpoint')")
edit("            need(initial is not None and core==initial,'full original initial/restored mutable graph equality')", "            need(initial is not None and core==initial and snapshot['trail_length']==0,\n                'full original initial/restored mutable graph equality and actual empty trail')")
edit("            physical_context_census=dict(bytes=len(core),sha256=hashlib.sha256(core).hexdigest()),", "            physical_context_graph=dict(bytes=len(core),sha256=hashlib.sha256(core).hexdigest()),\n            complete_audit_census=dict(bytes=len(canonical(census)),sha256=hashlib.sha256(canonical(census)).hexdigest()),\n            restoration_scope='All ten original graph fields compared in full; actual raw control-trail length/history retained separately. Replay may append control instructions. No raw replay-trail equality claim.',")
edit("            if role=='oracle'and name=='audit_snapshot':", "            if role=='oracle'and name in('audit_snapshot','certify'):")
edit("        if role=='oracle'and name=='audit_snapshot':self.oracle_work+=value['audit_work']", "        if role=='oracle'and name in('audit_snapshot','certify'):self.oracle_work+=value['audit_work']")
with (D/'qualify_wang_reusable_worker_DRAFT_v2.py').open('x')as f:f.write(raw)
print('Authored v2 draft Source only')
