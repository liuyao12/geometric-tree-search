"""Ordinary prospective metadata author. Never imports/evaluates a subject."""
from pathlib import Path
import hashlib
import json
import ast
import sys
D=Path('/private/tmp/gcts-wang-receptor-ROOT-20261019-v1')
P=Path('/private/tmp/gcts-wang-execution-ROOT-20261019')
PYTHON=Path('/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12')
SOURCES=dict(worker=D/'qualify_wang_reusable_worker_v1.py',
 compiler=Path('/private/tmp/gcts-wang-spacetime-library-20261019/wang_spacetime_compiler_v1.py'),
 search=Path('/private/tmp/gcts-wang-nogood-search-library-20261019/wang_point_search_v3.py'),
 verifier=Path('/private/tmp/gcts-wang-search-library-20261019/wang_history_verifier_v2.py'),
 oracle=Path('/private/tmp/gcts-wang-nogood-oracle-20261019/wang_nogood_oracle_v1.py'),
 runner=D/'run_wang_reusable_once_v1.py',observer=D/'observe_wang_encoding_once_v1.py')
def canon(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def pin(path):
    path=path.resolve();raw=path.read_bytes();return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(name,value):
    target=D/name
    with target.open('xb')as output:output.write(json.dumps(value,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False).encode()+b'\n')
    return pin(target)
def main():
    need_python=Path(sys.executable).resolve()==PYTHON.resolve()
    if not need_python:raise ValueError('pinned Python3.12 AST attribution required')
    raw=(P/'cohort-inputs-v1.json').read_bytes()
    if hashlib.sha256(raw).hexdigest()!='60ced7c79f91fd475ef88e90cace3ce5fffe15b0c8450d4b3e934d3764ffb80e':raise ValueError('whole frozen input')
    with (D/'cohort-inputs-v1.json').open('xb')as f:f.write(raw)
    inputs=json.loads(raw);sources={k:pin(v)for k,v in SOURCES.items()}
    previous=json.loads((P/'declaration-v3.json').read_bytes())
    oldclosure=json.loads((P/'runtime-closure-v3.json').read_bytes())
    census=[]
    for role,path in SOURCES.items():
        tree=ast.parse(path.read_bytes());imports=[]
        for node in ast.walk(tree):
            if isinstance(node,ast.Import):imports.extend(x.name for x in node.names)
            elif isinstance(node,ast.ImportFrom):imports.append(node.module)
        census.append(dict(role=role,source=sources[role],direct_imports=sorted(set(imports)),
            AST_sha256=hashlib.sha256(ast.dump(tree,include_attributes=False).encode()).hexdigest()))
    all_offers=[]
    for label,mode in [('off','off'),('on','primitive_empty_support')]:
        declaration=json.loads(json.dumps(previous))
        declaration.update(inputs=[dict(id='complete-four-machine-680-case-55-variant-bank',pin=pin(D/'cohort-inputs-v1.json'))],
            nogood_mode=mode,nogood_limits=dict(clauses=256,witness_rows=1000000,proof_work=400000000),
            comparison='Fresh V3 off then on, one invocation per exact subject. Same seven Sources, original680+55, original ordering and original outer/per-component work caps. Only prospective mode differs. Single serial observations give no statistical speedup estimate.',
            snapshot_lifecycle='Full current effective graph and full original physical/context graph independently reconstructed at every offered state. All ten original graph fields compared by complete canonical values at rollback. Saved raw undo checkpoint compared separately; overlay suspension/replay can add control-trail instructions. Final original graph and actual trail0 equal initial; catalogue remains explicitly inactive with no continuation. Historical knowledge metadata is not rolled back.',
            source_contract='Integer unit-center translation-only framed Wang specialization. V3 certified primitive empty-support clause cache on/off, no implemented geometric auxiliary gadget or RL. Full original palette and instance bindings preserved; boundary pins/selected placements only justify witnesses, never exclusions.',
            finite_fault_coverage=previous['finite_fault_coverage']+' New certificate/knowledge diagnostic proposal remains Source-only, not included or claimed executed. Runtime validation here rechecks every actually offered certificate and every current graph, not every conceivable malformed certificate.',
            no_rescue='Maximum one fresh actual for EACH distinct declared off/on subject; no repeated subject. Complete original680+55 required separately for admission. Earlier failed whole680+55 and six-root production outcomes remain negative; no smaller bank/higher caps/failed-prefix rescue.',
            timing='API action inclusive monotonic intervals are measured only for completed/raised action intervals, not wrappers, termination gaps or exclusive costs. Nested oracle/certificate intervals lie inside search; do not sum intervals. Outer total wall includes all measured/unmeasured work.',
            marking_construction='Separate unexecuted finite instance-specific gadget proof note; not implemented, not a fixed universal palette, not enabled in either comparison arm.',
            benchmark_diagnostic_execution_order='Original unchanged: all four palette checks, all680 cases in frozen order, then all55 original variants/30groups. No early-prefix admission.')
        declaration['component_limits']['oracle'].update(clauses=256,clause_literals=4096,witness_rows=1000000,proof_work=400000000)
        dp=save('declaration-'+label+'-v1.json',declaration)
        closure=dict(oldclosure,python=pin(PYTHON),sources=sources,declaration=dp,
            stdlib_files=[pin(Path(row['path']))for row in oldclosure['stdlib_files']],direct_import_census=census,
            AST_parser=dict(executable=str(Path(sys.executable).resolve()),version=sys.version,
                policy='ast.dump(ast.parse(raw),include_attributes=False), UTF-8 sha256, Source-only structural census'),
            source_only=True,actual_execution_authorized=False)
        cp=save('runtime-closure-'+label+'-v1.json',closure)
        subject=dict(schema='ROOT-wang-encoding-qualification-plan-v1',
            invocation_id='complete-wang-reusable-'+label+'-680-v1',actual_directory=str(D/('actual-'+label+'-680-v1')),
            python=pin(PYTHON),sources=sources,inputs=declaration['inputs'],limits=declaration['limits'],declaration=dp,runtime_closure=cp)
        sha=hashlib.sha256(canon(subject)).hexdigest()
        ap=save('authorization-false-'+label+'-v1.json',dict(schema='ROOT-wang-encoding-authorization-v1',author_identity='/root',
            actual_execution_authorized=False,maximum_actual_invocations=0,subject_sha256=sha,review=None,
            scope='Prospective Source-only offer; no actual permission.'))
        pp=save('plan-false-'+label+'-v1.json',dict(subject,authorization=ap))
        offer=dict(schema='ROOT-wang-prospective-offer-v1',subject=subject,subject_sha256=sha,false_plan=pp,
            sources=sources,component_calls=0,actual_execution_authorized=False)
        op=save('Source-only-offer-'+label+'-v1.json',offer)
        all_offers.append(dict(mode=mode,offer=op,subject_sha256=sha))
    save('comparison-offers-v1.json',dict(offers=all_offers,component_calls=0,source_only=True,actual_execution_authorized=False))
    print(json.dumps(all_offers,sort_keys=True))
if __name__=='__main__':main()
