"""Unexecuted Source: separate finite Wang/whole-machine certificate verifier.

No compiler/search imports or calls. Palette completeness is reconstructed from
the declaration; accepting history is additionally replayed on a whole tape,
head index and state, independently of both local schema code and graph state.
Same Library author: implementation separation is not an independent author audit.
"""

VERSION = 'finite-wang-global-history-verifier-v2'
LIMIT_KEYS = ('work', 'cells', 'tiles', 'colors', 'symbols', 'states', 'data_depth', 'history_cells')
INSTANCE_KEYS = ('schema', 'version', 'status', 'palette', 'initial_word', 'machine_steps',
                 'tape_width', 'board_width', 'board_height', 'boundary_NESW',
                 'required_centers', 'admissible_origins', 'fixed_background_marks',
                 'candidate_universe', 'all_root_generations', 'attempted_work',
                 'mathematical_authority', 'executed_source_qualified')


class InvalidCertificate(Exception):
    pass


class VerificationLimit(Exception):
    def __init__(self, reason, *, owner=None):
        self.reason, self._owner = reason, owner
        super().__init__(reason)


class _Budget:
    def __init__(self, check, limits):
        if (not callable(check) or type(limits) is not dict
                or any(type(key) is not str for key in limits) or set(limits) != set(LIMIT_KEYS)):
            raise InvalidCertificate('exact finite limits and check required')
        for key in LIMIT_KEYS:
            if type(limits[key]) is not int or limits[key] <= 0:
                raise InvalidCertificate('exact positive-int limits required')
        if limits['data_depth'] > 128:
            raise InvalidCertificate('input recursive-depth profile maximum128')
        self.limits, self.check = dict(limits), check
        self.owner = object()
        self.counts = {'work': 0}
        check()

    def tick(self, kind):
        self.counts['work'] += 1
        self.counts[kind] = self.counts.get(kind, 0) + 1
        if self.counts['work'] > self.limits['work']:
            raise VerificationLimit('work', owner=self.owner)
        self.check()

    def cap(self, name, number):
        self.tick('limit_checks')
        if number > self.limits[name]:
            raise VerificationLimit(name, owner=self.owner)


def _obj(value, names):
    if type(value) is not dict or any(type(k) is not str for k in value) or set(value) != set(names):
        raise InvalidCertificate('unexpected or missing object field')


def _list(value, size=None):
    if type(value) is not list or (size is not None and len(value) != size):
        raise InvalidCertificate('ordinary list of exact length required')
    return value


def _number(value, low=0, upper=None):
    if type(value) is not int or value < low or (upper is not None and value >= upper):
        raise InvalidCertificate('exact integer outside range; booleans excluded')
    return value


def _owned(value, budget, depth=0, active=None):
    budget.tick('input_values')
    budget.cap('data_depth', depth)
    kind = type(value)
    if value is None or kind is bool or kind is int:
        return value
    if kind is str:
        for c in value:
            budget.tick('string_characters')
            if 0xD800 <= ord(c) <= 0xDFFF:
                raise InvalidCertificate('lone surrogate in literal')
        return value
    if kind in (list, dict):
        if active is None:
            active = set()
        identity = id(value)
        if identity in active:
            raise InvalidCertificate('cyclic ordinary container')
        active.add(identity)
        try:
            if kind is list:
                return [_owned(item, budget, depth + 1, active) for item in value]
            result = {}
            for key in value:
                if type(key) is not str:
                    raise InvalidCertificate('literal string object keys required')
                result[_owned(key, budget, depth + 1, active)] = _owned(value[key], budget, depth + 1, active)
            return result
        finally:
            active.remove(identity)
    raise InvalidCertificate('strict ordinary JSON projection only')


def _tuple_literal(value, budget):
    budget.tick('schema_literal_items')
    if type(value) is str or type(value) is int:
        return value
    items = []
    for item in _list(value):
        items.append(_tuple_literal(item, budget))
    return tuple(items)


def _machine(raw, budget):
    _obj(raw, ('alphabet_size', 'state_count', 'blank', 'initial', 'accepting', 'transitions'))
    a = _number(raw['alphabet_size'], 1)
    q = _number(raw['state_count'], 1)
    budget.cap('symbols', a)
    budget.cap('states', q)
    blank = _number(raw['blank'], 0, a)
    initial = _number(raw['initial'], 0, q)
    accepting = _number(raw['accepting'], 0, q)
    rules = {}
    for row in _list(raw['transitions']):
        budget.tick('machine_rules')
        old, read, new, write, move = _list(row, 5)
        _number(old, 0, q)
        _number(read, 0, a)
        _number(new, 0, q)
        _number(write, 0, a)
        _number(move, -1, 2)
        if old == accepting or (old, read) in rules:
            raise InvalidCertificate('accepting outgoing rule or nondeterminism')
        rules[old, read] = (new, write, move)
    return a, q, blank, initial, accepting, rules


def _cell(raw, machine, wall=False):
    a, q, blank, initial, accepting, rules = machine
    _list(raw)
    if wall and raw == ['wall']:
        return ('wall',)
    if len(raw) == 2 and type(raw[0]) is str and raw[0] == 'plain':
        return ('plain', _number(raw[1], 0, a))
    if len(raw) == 3 and type(raw[0]) is str and raw[0] == 'head':
        return ('head', _number(raw[1], 0, q), _number(raw[2], 0, a))
    raise InvalidCertificate('malformed cell constructor')


def _color(raw, machine):
    _list(raw)
    if not raw or type(raw[0]) is not str:
        raise InvalidCertificate('tagged color required')
    tag = raw[0]
    if tag == 'cell' and len(raw) == 2:
        return ('cell', _cell(raw[1], machine))
    if tag == 'pair' and len(raw) == 3:
        return ('pair', _cell(raw[1], machine, True), _cell(raw[2], machine, True))
    if tag == 'seen' and len(raw) == 2:
        return ('seen', _number(raw[1], 0, 2))
    if tag == 'stop' and len(raw) == 1:
        return ('stop',)
    if tag == 'side' and len(raw) == 3 and raw[1] in ('left', 'right') and raw[2] in ('run', 'done'):
        return ('side', raw[1], raw[2])
    if tag == 'exterior' and len(raw) == 2 and raw[1] in ('left', 'right'):
        return ('exterior', raw[1])
    raise InvalidCertificate('unknown or malformed color constructor')


def _project_neighborhood(triple, machine, budget):
    """Independent schema reconstruction by writing/moving a tiny tape section.

    This is not used by the whole-history replay below. An outgoing neighbor
    head may leave this local section; only a center escaping into wall rejects.
    """
    budget.tick('schema_neighborhoods')
    tape, head = {}, None
    for index, cell in enumerate(triple):
        budget.tick('schema_cells')
        if cell[0] == 'wall':
            continue
        tape[index] = cell[-1]
        if cell[0] == 'head':
            if head is not None:
                return None
            head = (index, cell[1])
    if head is None:
        return ('plain', tape[1])
    position, state = head
    rule = machine[5].get((state, tape[position]))
    if rule is None:
        return None
    new_state, written, move = rule
    destination = position + move
    if position == 1 and destination not in tape:
        return None
    tape[position] = written
    if destination == 1:
        return ('head', new_state, tape[1])
    return ('plain', tape[1])


def _expected_palette(machine, budget):
    a, q, blank, initial, accepting, rules = machine
    cells = []
    for symbol in range(a):
        budget.tick('expected_cells')
        cells.append(('plain', symbol))
    for state in range(q):
        for symbol in range(a):
            budget.tick('expected_cells')
            cells.append(('head', state, symbol))
    expected, colors = set(), set()

    def schema(kind, origin, north, east, south, west):
        budget.tick('expected_schemas')
        row = (kind, origin, north, east, south, west)
        if row in expected:
            raise InvalidCertificate('internal duplicate expected schema')
        expected.add(row)
        budget.cap('tiles', len(expected))
        for value in (north, east, south, west):
            budget.tick('expected_colors')
            colors.add(value)
            budget.cap('colors', len(colors))

    for a_cell in cells + [('wall',)]:
        for b_cell in cells:
            for c_cell in cells + [('wall',)]:
                triple = (a_cell, b_cell, c_cell)
                answer = _project_neighborhood(triple, machine, budget)
                if answer is not None:
                    schema('step', triple, ('cell', b_cell), ('pair', b_cell, c_cell),
                           ('cell', answer), ('pair', a_cell, b_cell))
    for symbol in range(a):
        for flag in (0, 1):
            schema('collect_plain', (symbol, flag), ('cell', ('plain', symbol)),
                   ('seen', flag), ('stop',), ('seen', flag))
        schema('collect_accept', (accepting, symbol), ('cell', ('head', accepting, symbol)),
               ('seen', 1), ('stop',), ('seen', 0))
    for cell in cells:
        schema('left_step_frame', (cell,), ('side', 'left', 'run'), ('pair', ('wall',), cell),
               ('side', 'left', 'run'), ('exterior', 'left'))
        schema('right_step_frame', (cell,), ('side', 'right', 'run'), ('exterior', 'right'),
               ('side', 'right', 'run'), ('pair', cell, ('wall',)))
    schema('left_accept_frame', (), ('side', 'left', 'run'), ('seen', 0),
           ('side', 'left', 'done'), ('exterior', 'left'))
    schema('right_accept_frame', (), ('side', 'right', 'run'), ('exterior', 'right'),
           ('side', 'right', 'done'), ('seen', 1))
    for cell in cells:
        budget.tick('complete_color_alphabet')
        colors.add(('cell', cell))
    for value in (('stop',), ('side', 'left', 'run'), ('side', 'right', 'run'),
                  ('side', 'left', 'done'), ('side', 'right', 'done'),
                  ('exterior', 'left'), ('exterior', 'right')):
        budget.tick('complete_color_alphabet')
        colors.add(value)
    budget.cap('colors', len(colors))
    return expected, colors


def _palette(raw, budget):
    _obj(raw, ('schema', 'version', 'machine', 'color_constructors', 'tiles', 'transformations',
              'point_profile', 'edge_order', 'mathematical_authority'))
    if (raw['schema'] != 'finite-framed-wang-spacetime-v1'
            or raw['version'] != 'finite-framed-wang-spacetime-compiler-v1'
            or raw['transformations'] != 'translations_only_2Z2'
            or raw['point_profile'] != 'integer-center-midpoint-translation-only-v1'
            or raw['edge_order'] != 'NESW' or raw['mathematical_authority'] is not False):
        raise InvalidCertificate('palette profile mismatch')
    machine = _machine(raw['machine'], budget)
    expected, expected_colors = _expected_palette(machine, budget)
    color_rows = _list(raw['color_constructors'])
    budget.cap('colors', len(color_rows))
    colors, seen = [], set()
    for row in color_rows:
        budget.tick('declared_colors')
        color = _color(row, machine)
        if color in seen:
            raise InvalidCertificate('noninjective literal color coding')
        seen.add(color)
        colors.append(color)
    if seen != expected_colors:
        raise InvalidCertificate('incomplete or extended color alphabet')
    tiles = _list(raw['tiles'])
    budget.cap('tiles', len(tiles))
    observed, edges = set(), []
    for index, tile in enumerate(tiles):
        budget.tick('declared_tiles')
        _obj(tile, ('id', 'kind', 'origin', 'edges_NESW', 't', 'm'))
        if _number(tile['id']) != index or type(tile['kind']) is not str:
            raise InvalidCertificate('ordered palette identities malformed')
        codes = tuple(_number(value, 0, len(colors)) for value in _list(tile['edges_NESW'], 4))
        semantic = tuple(colors[value] for value in codes)
        signature = (tile['kind'], _tuple_literal(tile['origin'], budget)) + semantic
        if signature not in expected or signature in observed:
            raise InvalidCertificate('invalid or duplicate tile schema')
        observed.add(signature)
        trow = _list(_list(tile['t'], 1)[0], 2)
        tpoint = tuple(_number(x) for x in _list(trow[0], 2))
        if tpoint != (0, 0) or type(trow[1]) is not int or trow[1] != 1:
            raise InvalidCertificate('unit-center t data malformed')
        for offset, mark, code in zip(((0, -1), (1, 0), (0, 1), (-1, 0)), _list(tile['m'], 4), codes):
            budget.tick('declared_midpoint_marks')
            _list(mark, 3)
            point = tuple(_number(x, -1, 2) for x in _list(mark[0], 2))
            if point != offset or mark[1] != 'edge' or _number(mark[2], 0, len(colors)) != code:
                raise InvalidCertificate('four assigned m values do not equal raw edge colors')
        edges.append(codes)
    if observed != expected:
        raise InvalidCertificate('missing machine tile schemas; witness does not justify trimming')
    return machine, tuple(colors), tuple(edges)


def _global_transition(tape, head, state, machine, budget):
    """Whole configuration: single lookup, single write, single head movement."""
    budget.tick('global_machine_steps')
    if state == machine[4]:
        raise InvalidCertificate('acceptance cannot be padded with fictitious machine steps')
    instruction = machine[5].get((state, tape[head]))
    if instruction is None:
        raise InvalidCertificate('nonaccepting halt before claimed final time')
    state_after, write, displacement = instruction
    destination = head + displacement
    if destination < 0 or destination >= len(tape):
        raise InvalidCertificate('head escapes declared tape walls')
    next_tape = []
    for position, symbol in enumerate(tape):
        budget.tick('global_tape_cells')
        next_tape.append(write if position == head else symbol)
    return next_tape, destination, state_after


def _configuration(tape, head, state, budget):
    result = []
    for position, symbol in enumerate(tape):
        budget.tick('history_cell_comparisons')
        result.append(('head', state, symbol) if position == head else ('plain', symbol))
    return tuple(result)


def _verify(instance, certificate, budget):
    """Validate a complete ordinary certificate; no internal search/compilation.

    The public wrapper distinguishes only its own per-call quota. It never
    returns partial success or converts a caller-origin exception.
    """
    problem = _owned(instance, budget)
    proof = _owned(certificate, budget)
    _obj(problem, INSTANCE_KEYS)
    if (problem['schema'] != 'finite-framed-wang-instance-v1'
            or problem['version'] != 'finite-framed-wang-spacetime-compiler-v1'
            or problem['status'] != 'FINITE_PROBLEM_CANDIDATE'
            or problem['mathematical_authority'] is not False
            or problem['executed_source_qualified'] is not False):
        raise InvalidCertificate('instance candidate schema mismatch')
    machine, colors, edges = _palette(problem['palette'], budget)
    tape_width = _number(problem['tape_width'], 1)
    steps = _number(problem['machine_steps'])
    width, height = _number(problem['board_width'], 3), _number(problem['board_height'], 1)
    if width != tape_width + 2 or height != steps + 1:
        raise InvalidCertificate('dimension/time declaration mismatch')
    budget.cap('cells', width * height)
    budget.cap('history_cells', tape_width * (steps + 1))
    _number(problem['attempted_work'])
    if (type(problem['all_root_generations']) is not int or problem['all_root_generations'] != 0
            or problem['candidate_universe'] != 'every palette tile ID at every admissible origin; no rotations/reflections'):
        raise InvalidCertificate('full finite point convention mismatch')
    initial, tape, head, state = [], [], None, None
    for position, raw in enumerate(_list(problem['initial_word'], tape_width)):
        budget.tick('initial_configuration_cells')
        cell = _cell(raw, machine)
        initial.append(cell)
        tape.append(cell[-1])
        if cell[0] == 'head':
            if head is not None or cell[1] != machine[3]:
                raise InvalidCertificate('initial head count/state mismatch')
            head, state = position, cell[1]
    if head is None:
        raise InvalidCertificate('missing initial head')
    color_ids = {color: index for index, color in enumerate(colors)}
    north = [color_ids[('side', 'left', 'run')]] + [color_ids[('cell', c)] for c in initial] + [color_ids[('side', 'right', 'run')]]
    south = [color_ids[('side', 'left', 'done')]] + [color_ids[('stop',)]] * tape_width + [color_ids[('side', 'right', 'done')]]
    east = [color_ids[('exterior', 'right')]] * height
    west = [color_ids[('exterior', 'left')]] * height
    boundary = _list(problem['boundary_NESW'], 4)
    for actual, expected in zip(boundary, (north, east, south, west)):
        for value, wanted in zip(_list(actual, len(expected)), expected):
            budget.tick('boundary_word_checks')
            if _number(value, 0, len(colors)) != wanted:
                raise InvalidCertificate('boundary word not the declared machine input/acceptance frame')
    origins = []
    for y in range(height):
        for x in range(width):
            budget.tick('required_center_checks')
            origins.append((2 * x, 2 * y))
    for name in ('required_centers', 'admissible_origins'):
        actual = []
        for row in _list(problem[name], len(origins)):
            budget.tick('complete_origin_lists')
            actual.append(tuple(_number(v) for v in _list(row, 2)))
        if actual != origins:
            raise InvalidCertificate('target/origin omission, duplication or change')
    expected_pins = {}
    for y in range(height):
        budget.tick('expected_boundary_points')
        expected_pins[-1, 2 * y] = west[y]
        expected_pins[2 * width - 1, 2 * y] = east[y]
    for x in range(width):
        budget.tick('expected_boundary_points')
        expected_pins[2 * x, -1] = north[x]
        expected_pins[2 * x, 2 * height - 1] = south[x]
    declared_pins = {}
    for mark in _list(problem['fixed_background_marks'], len(expected_pins)):
        budget.tick('background_mark_checks')
        _list(mark, 3)
        xy = tuple(_number(n, -1) for n in _list(mark[0], 2))
        code = _number(mark[2], 0, len(colors))
        if mark[1] != 'edge' or xy in declared_pins or expected_pins.get(xy) != code:
            raise InvalidCertificate('missing/changed/duplicate background mark')
        declared_pins[xy] = code
    _obj(proof, ('schema', 'placements'))
    if proof['schema'] != 'finite-wang-placement-certificate-v1':
        raise InvalidCertificate('certificate schema mismatch')
    board = {}
    point_values = dict(declared_pins)
    for row in _list(proof['placements'], len(origins)):
        budget.tick('placement_checks')
        _obj(row, ('tile_id', 'origin'))  # No orientation, rotation, or scale accepted.
        tile = _number(row['tile_id'], 0, len(edges))
        xy = tuple(_number(v) for v in _list(row['origin'], 2))
        if xy[0] % 2 or xy[1] % 2 or xy[0] >= 2 * width or xy[1] >= 2 * height or xy in board:
            raise InvalidCertificate('outside/rotated-grid/duplicate placement')
        board[xy] = tile
        for offset, code in zip(((0, -1), (1, 0), (0, 1), (-1, 0)), edges[tile]):
            budget.tick('whole_point_mark_checks')
            point = (xy[0] + offset[0], xy[1] + offset[1])
            if point in point_values and point_values[point] != code:
                raise InvalidCertificate('assigned midpoint conflict including code zero')
            point_values[point] = code
    for xy in origins:
        budget.tick('whole_target_checks')
        if xy not in board:
            raise InvalidCertificate('unfilled required center')
    # A second, direct raw four-edge/rectangle check is separate from point union.
    for y in range(height):
        for x in range(width):
            budget.tick('raw_four_edge_checks')
            n, e, s, w = edges[board[2 * x, 2 * y]]
            if ((y == 0 and n != north[x]) or (x == 0 and w != west[y])
                    or (y == height - 1 and s != south[x]) or (x == width - 1 and e != east[y])):
                raise InvalidCertificate('raw outside edge mismatch')
            if x + 1 < width and e != edges[board[2 * (x + 1), 2 * y]][3]:
                raise InvalidCertificate('raw horizontal edge mismatch')
            if y + 1 < height and s != edges[board[2 * x, 2 * (y + 1)]][0]:
                raise InvalidCertificate('raw vertical edge mismatch')
    # Independently replay exactH complete global transitions, never compiler F.
    history = []
    for time in range(steps + 1):
        configuration = _configuration(tape, head, state, budget)
        saved_tape = []
        for symbol in tape:
            budget.tick('retained_history_cells')
            saved_tape.append(symbol)
        history.append(dict(time=time, head=head, state=state, tape=saved_tape))
        for position in range(tape_width):
            budget.tick('history_north_word_checks')
            tile = board[2 * (position + 1), 2 * time]
            if colors[edges[tile][0]] != ('cell', configuration[position]):
                raise InvalidCertificate('tiling row is not the actual whole machine configuration')
        if time < steps:
            tape, head, state = _global_transition(tape, head, state, machine, budget)
            wanted = _configuration(tape, head, state, budget)
            for position in range(tape_width):
                budget.tick('history_south_word_checks')
                tile = board[2 * (position + 1), 2 * time]
                if colors[edges[tile][2]] != ('cell', wanted[position]):
                    raise InvalidCertificate('machine transition output mismatch')
    if state != machine[4]:
        raise InvalidCertificate('final unique head is not accepting')
    budget.tick('successful_completion')
    return dict(status='VALID_FINITE_ACCEPTING_TILING', version=VERSION,
                scope='DECLARED_FINITE_SINGLE_TAPE_MACHINE_ONLY',
                board_cells=len(origins), machine_steps=steps, history=history,
                whole_point_and_edges_checked=True, complete_palette_checked=True,
                independent_global_transition_replay=True, counts=dict(budget.counts),
                FOL_checker_or_universal_palette_established=False)


def verify(instance, certificate, *, check, limits):
    """Own per-call quota is UNKNOWN, never malformed/untilable or accepted.

    A callback raising this same public exception class has a different owner
    and is re-raised as the exact original object. No foreign fault is normalized.
    """
    budget = _Budget(check, limits)
    try:
        return _verify(instance, certificate, budget)
    except VerificationLimit as error:
        if type(error) is not VerificationLimit or error._owner is not budget.owner:
            raise
        return dict(status='UNKNOWN', reason=error.reason, version=VERSION,
                    counts=dict(budget.counts), accepting_history_checked=False,
                    mathematical_authority=False)
