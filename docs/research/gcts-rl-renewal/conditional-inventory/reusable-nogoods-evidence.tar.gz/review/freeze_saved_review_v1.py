"""Passive independent raw-byte/ordinary-JSON joins; no subject loading/probes."""
from pathlib import Path
import hashlib
import json
import sys

C=Path('/private/tmp/gcts-wang-nogood-review-20261019')
D=Path('/private/tmp/gcts-wang-receptor-ROOT-20261019-v1')
checks=[];raw_files={}
def h(raw):return hashlib.sha256(raw).hexdigest()
def pin(path):
    p=Path(path);b=p.read_bytes()
    value=dict(path=str(p),bytes=len(b),sha256=h(b));raw_files[str(p)]=value
    return value
def read(path):return json.loads(Path(path).read_bytes())
def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def need(name,ok):
    checks.append(dict(id=name,passed=bool(ok)))
    if not ok:raise AssertionError(name)
def raw(name,value):need(name,pin(value['path'])==value and not Path(value['path']).is_symlink())
def descriptors(value):
    if type(value)is dict:
        if set(value)=={'path','bytes','sha256'}:
            yield value
        else:
            for v in value.values():yield from descriptors(v)
    elif type(value)is list:
        for v in value:yield from descriptors(v)

auditpin=pin(D/'ROOT-saved-comparison-v1.json')
need('Root comparison exact offered raw pin',auditpin['sha256']=='730cb7826de5743430af8f23b2947eabdfdfeedcf0df58dcd952cb1c9793a85f'and auditpin['bytes']==86201)
root=read(auditpin['path']);retirement=read(D/'ROOT-retirement-v1.json')
delta=read(C/'typed-final-grant-delta-review-v1.json')
need('exact prelaunch final-delta ancestry',delta['final_grant_delta_review_passed']is True and delta['mismatch_count']==0)
need('Root two modes and no authority',len(root['rows'])==2 and root['actual_invocations']==2 and root['all_actuals_closed']is True and root['geometric_marking_implementation']is False and root['full_pipeline_qualified']is False and root['fixed_FOL_palette_qualified']is False and root['gcts_rl_advantage_established']is False and root['trained_RL']is False)
need('two retired grants',len(retirement['actuals'])==2 and all(v['closed']is True and v['consumed']==1 and v['maximum']==1 and v['remaining']==0 and v['retired']is True for v in retirement['actuals']))
for i,value in enumerate(descriptors(root)):raw('Root raw descriptor '+str(i),value)
for i,value in enumerate(descriptors(retirement)):raw('retirement raw descriptor '+str(i),value)

expected={'off':dict(prefix=68,audits=10737,certify=0,hwm=72056832,compiler=69,search=69,verify=10,root=102218321),
          'on':dict(prefix=53,audits=5226,certify=842,hwm=147062784,compiler=54,search=54,verify=7,root=253411765)}
rows=[];terminals=[]
for index,(mode,e)in enumerate(expected.items()):
    pre=mode+': '
    planpath=D/('plan-authorized-'+mode+'-v1.json');planpin=pin(planpath);plan=read(planpath)
    review=read(C/('typed-combined-Source-prospective-review-'+mode+'-v1.json'))
    subject={k:v for k,v in plan.items()if k!='authorization'}
    need(pre+'full original subject unchanged',subject==review['subject'] and h(canon(subject))==review['subject_sha256'])
    for i,value in enumerate(descriptors(subject)):raw(pre+'subject whole dependency '+str(i),value)
    raw(pre+'current authorization',plan['authorization']);auth=read(plan['authorization']['path'])
    raw(pre+'adopted exact review',auth['review'])
    need(pre+'Root maxone exact scope',auth['author_identity']=='/root'and auth['actual_execution_authorized']is True and type(auth['maximum_actual_invocations'])is int and auth['maximum_actual_invocations']==1 and auth['subject_sha256']==review['subject_sha256'])
    closure=read(plan['runtime_closure']['path']);declaration=read(plan['declaration']['path'])
    need(pre+'complete runtime and declaration binding',closure['sources']==plan['sources']and closure['python']==plan['python']and closure['declaration']==plan['declaration']and declaration['limits']==plan['limits']and declaration['inputs']==plan['inputs'])
    for i,value in enumerate(closure['stdlib_files']):raw(pre+'stdlib '+str(i),value)
    inputs=read(plan['inputs'][0]['pin']['path']);ids=[r['id']for r in inputs['cases']]
    need(pre+'whole original680+55 preserved',len(ids)==680 and ids==declaration['case_ids']and inputs['diagnostics']==declaration['diagnostics']and sum(len(r['variants'])for r in inputs['diagnostics'])==55)
    actual=Path(plan['actual_directory']);observer=planpath.with_name(planpath.stem+'-terminal-observation')
    f=read(actual/'worker-failure.json');r=read(actual/'runner-receipt.json');t=read(observer/'terminal.json')
    c=read(actual/'CONSUMED.json');w=read(actual/'WORKER_CONSUMED.json');oc=read(observer/'CONSUMED.json')
    for p in sorted(actual.iterdir()):
        need(pre+'actual regular raw file '+p.name,p.is_file()and not p.is_symlink());pin(p)
    for p in sorted(observer.iterdir()):
        need(pre+'observer regular raw file '+p.name,p.is_file()and not p.is_symlink());pin(p)
    need(pre+'exact actual file inventory',sorted(p.name for p in actual.iterdir())==['CONSUMED.json','WORKER_CONSUMED.json','runner-receipt.json','stderr.bin','stdout.bin','worker-failure.json'])
    need(pre+'exact observer file inventory',sorted(p.name for p in observer.iterdir())==['CONSUMED.json','stderr.bin','stdout.bin','terminal.json'])
    need(pre+'no full outputs or partial rescue',f['outputs']==[]and all(not(actual/n).exists()for n in ['result.json','worker-receipt.json','canonical-wang-calibration.json']))
    need(pre+'whole plan joins',all(v['plan']==planpin for v in [f,r,t,c,w,oc]))
    need(pre+'one-use markers before launch',c['maximum_worker_launches']==1 and c['consumed_before_Popen']is True and w['maximum_invocations']==1 and oc['maximum_runner_launches']==1 and c['subject_sha256']==review['subject_sha256'])
    need(pre+'literal Source-entry epoch',c['began_ns']==r['began_ns']and c['work_deadline_ns']==r['work_deadline_ns']==r['began_ns']+180000000000 and c['overall_deadline_ns']==r['overall_deadline_ns']==r['began_ns']+210000000000)
    need(pre+'worker identity and command',w['pid']==r['worker_pid']==r['owned_pgid']and w['ppid']==t['runner_pid']and r['command']==[plan['python']['path'],'-I','-S','-B',plan['sources']['worker']['path'],str(planpath)]and t['command']==[plan['python']['path'],'-I','-S','-B',plan['sources']['runner']['path'],str(planpath)])
    need(pre+'worker entry after marker epoch',r['began_ns']<w['worker_entry_ns']<r['work_deadline_ns']and oc['observer_started_ns']==t['observer_started_ns']<r['began_ns'])
    need(pre+'parent deadline distinct from worker fault',r['primary_failure']['type']=='ValueError'and r['primary_failure']['message']=='complete positive result/header/bytes/known-exit before180'and f['first_available_fault']=={'type':'PolicyFailure','message':'original absolute180s work deadline'})
    need(pre+'worker TERM wait4 and known runner exit',r['worker_launch_attempts']==1 and r['worker_reaped']is True and r['worker_exit_code']==-15 and r['worker_wait4_status']==15 and t['runner_exit_code']==2 and len(r['signals'])==1 and r['signals'][0]['signal']==15)
    need(pre+'all actual acceptance flags false',all(v[k]is False for v in [r,f] for k in ['finite_encoding_candidate','scientific_acceptance','mathematical_proof_accepted','full_pipeline_qualified'])and r['resource_candidate_accepted']is False and t['terminal_gate_passed']is False and t['ROOT_resource_accepted']is False)
    need(pre+'all forbidden runtime role counts zero',all(type(r[k])is int and r[k]==0 for k in ['Native_calls','Model_calls','Reader_calls','inverse_calls','FOL_proof_search_calls','proof_checker_calls'])and all(type(f[k])is int and f[k]==0 for k in ['Native_calls','Model_calls','Reader_calls','inverse_calls','proof_checker_calls']))
    need(pre+'outer missing accepted API counts are null',all(r[k]is None for k in ['compiler_calls','search_calls','verifier_calls','oracle_calls']))
    cleanup=r['cleanup'];events=cleanup['events']
    need(pre+'bounded cleanup complete',cleanup['diagnostics_incomplete']is False and cleanup['dropped_events']==0 and len(events)<=32 and cleanup['poll_cycles']<=2048 and cleanup['completed_before_deadline']is True)
    need(pre+'saved final group absence no reappearance',r['owned_group_absent']is True and cleanup['group_state']=='ABSENT'and cleanup['group_seen_absent']is True and cleanup['group_reappeared']is False and sum(v['operation']=='group_probe'and v['outcome']=='ABSENT'for v in events)>=2)
    need(pre+'genuine wait4 and parent closes',any(v['operation']=='wait4'and v['outcome']=='REAPED'for v in events)and r['regular_logs_closed']is True and all(v['opened']is True and v['close_attempts']==1 and v['closed']is True for v in r['log_close_observations'].values()))
    need(pre+'cleanup ordered within outer original window',all(r['began_ns']<=v['observed_ns']<=r['overall_deadline_ns']for v in events)and r['work_deadline_ns']<r['worker_terminal_observed_ns']<=r['closed_ns']<r['overall_deadline_ns'])
    for name in ['post_child_raw_custody','whole_log_custody','final_physical_ledger']:
        v=r[name];need(pre+name+' original210 clock',v['completed_before_deadline']is True and r['closed_ns']<=v['completed_ns']<r['overall_deadline_ns'])
    need(pre+'negative post-child raw closure',r['post_child_raw_custody']['checked']is True and r['whole_log_custody']['stable']is True and r['whole_log_custody']['complete']is True and r['finalization_errors']==[])
    for name in ['stdout','stderr']:
        raw(pre+'whole worker log '+name,r[name]);need(pre+'empty full worker log '+name,r[name]['bytes']==0)
    before=sum(p.stat().st_size for p in actual.iterdir()if p.name!='runner-receipt.json')
    ledger=r['final_physical_ledger']
    need(pre+'full physical pre-receipt ledger and reserve',ledger['before_receipt_bytes']==before and ledger['conservative_bytes']==before+9437184 and ledger['enumeration_complete']is True and ledger['stable_writer_quiescence']is True and ledger['within_original_cap']is True and ledger['conservative_bytes']<=134217728)
    need(pre+'actual reservations and log limits',pin(actual/'runner-receipt.json')['bytes']<=8388608 and sum(p.stat().st_size for p in observer.iterdir())<=1048576 and all((observer/n).stat().st_size<=4194304 for n in ['stdout.bin','stderr.bin']))
    need(pre+'observed wait4 standalone HWM',type(r['worker_wait4_usage']['ru_maxrss'])is int and r['worker_wait4_usage']['ru_maxrss']==e['hwm']<1073741824)
    raw(pre+'terminal receipt descriptor',t['runner_receipt']);raw(pre+'consumed descriptor',r['consumed_marker'])
    need(pre+'terminal clocks numeric exact join',abs(t['runner_clock_elapsed_seconds']-(t['terminal_observed_ns']-r['began_ns'])/1e9)<1e-9 and abs(t['observed_instrument_elapsed_seconds']-(t['terminal_observed_ns']-t['observer_started_ns'])/1e9)<1e-9 and r['work_deadline_ns']<t['terminal_observed_ns']<r['overall_deadline_ns'])
    need(pre+'failure original mode and stage',f['schema']=='wang-encoding-worker-failure-v1'and f['status']=='FAILED_OR_UNFINISHED'and f['stage']=='COMPLETE_CASE'and f['nogood_mode']==declaration['nogood_mode'])
    n=e['prefix'];need(pre+'exact unadmitted original prefix and active case',f['completed_case_ids']==ids[:n]and f['active_row']==ids[n]and f['diagnostic_prefix']==[])
    started=f['call_started'];completed=f['call_completed'];raised=f['call_raised']
    need(pre+'started-completed-raised census joins',all(type(v)is int and v>=0 for m in [started,completed,raised]for v in m.values())and all(started[k]==completed.get(k,0)+raised.get(k,0)for k in started))
    for role in ['compiler','search','verifier','oracle']:
        need(pre+role+' Session-entry count sum',f[role+'_calls']==sum(v for k,v in started.items()if k.startswith(role+'.')))
    need(pre+'normal call cutoff witnesses',completed['compiler.compile_palette']==4 and completed['compiler.compile_finite_problem']==e['compiler']and started['search.search']==e['search']and completed['search.search']==n and raised['search.search']==1 and completed['verifier._machine']==n and completed['verifier.verify']==e['verify'])
    need(pre+'oracle completed API entries only',completed['oracle.audit_snapshot']==e['audits']and completed.get('oracle.certify',0)==e['certify'])
    need(pre+'Root checkpoints remain below cap',type(f['root_check_calls'])is int and f['root_check_calls']==e['root']<400000000)
    phases=f['phase_receipts']
    need(pre+'all sequential completed phase pairs plus active start',len(phases)==2*n+1 and all(phases[2*i]['event']=='CASE_STARTED'and phases[2*i+1]['event']=='CASE_COMPLETED'and phases[2*i]['active']==phases[2*i+1]['active']==ids[i]and phases[2*i]['completed_cases']==i and phases[2*i+1]['completed_cases']==i+1 for i in range(n))and phases[-1]['event']=='CASE_STARTED'and phases[-1]['active']==ids[n]and phases[-1]['completed_cases']==n)
    need(pre+'phase clocks/counters monotone and original horizon',all(v['diagnostic_groups']==0 and v['stage']=='COMPLETE_CASE'and 0<=v['elapsed_from_runner_entry_ns']<180000000000 and type(v['root_check_calls'])is int and v['root_check_calls']<=f['root_check_calls'] for v in phases)and all(phases[i]['elapsed_from_runner_entry_ns']<=phases[i+1]['elapsed_from_runner_entry_ns']and phases[i]['root_check_calls']<=phases[i+1]['root_check_calls']for i in range(len(phases)-1)))
    times=f['per_API_inclusive_wall_ns'];need(pre+'inclusive API timing values only',all(type(k)is str and type(v)is int and v>=0 for k,v in times.items())and times['search.search']>=times['oracle.audit_snapshot']+times.get('oracle.certify',0))
    rr=root['rows'][index]
    for key,v in {'diagnostic_only_completed_case_ids':f['completed_case_ids'],'diagnostic_only_active_case':f['active_row'],'diagnostic_only_phase_receipts':phases,'diagnostic_only_call_started':started,'diagnostic_only_call_completed':completed,'diagnostic_only_call_raised':raised,'diagnostic_only_API_inclusive_wall_ns':times,'worker_wait4_usage':r['worker_wait4_usage'],'primary_failure':r['primary_failure'],'physical_ledger':ledger,'worker_exit_code':-15,'elapsed_seconds':t['runner_clock_elapsed_seconds']}.items():
        need(pre+'Root projection full exact '+key,rr[key]==v)
    need(pre+'Root flags remain negative',rr['qualification']is None and rr['resource_candidate_accepted']is False and rr['complete_calibration_candidate']is False and rr['terminal_closed_before210']is True and rr['terminal_gate_passed']is False)
    barrier=read(D/('ROOT-idle-barrier-'+mode+'-v1.json'));pin(D/('ROOT-idle-barrier-'+mode+'-v1.json'))
    need(pre+'declared fresh idle barrier before Source entry',barrier['mode']==mode and barrier['Root_exclusive_during_actual']is True and barrier['pinned_python_monotonic_ns']<r['began_ns'])
    rows.append(dict(mode=mode,classification='CLOSED_NEGATIVE_WORK_DEADLINE_NO_ADMISSION',
        plan=planpin,authorization=plan['authorization'],subject_sha256=review['subject_sha256'],
        runner=pin(actual/'runner-receipt.json'),terminal=pin(observer/'terminal.json'),worker_failure=pin(actual/'worker-failure.json'),
        unadmitted_completed_prefix_count=n,completed_case_ids=f['completed_case_ids'],active_case=f['active_row'],not_started_case_count=680-n-1,
        diagnostic_groups_reached=0,diagnostic_variants_reached=0,outputs=[],complete_packet_present=False,worker_header_present=False,
        parent_primary=r['primary_failure'],worker_fault=f['first_available_fault'],worker_exit_code=-15,runner_exit_code=2,
        external_runner_entry_elapsed_seconds=t['runner_clock_elapsed_seconds'],observer_main_elapsed_seconds=t['observed_instrument_elapsed_seconds'],
        standalone_worker_lifetime_peak_bytes=e['hwm'],standalone_worker_lifetime_peak_MiB=e['hwm']/1048576,
        peak_scope='Genuine saved Darwin wait4 lifetime worker-only highwater, diagnostic on a failed run; not simultaneous total RAM, per-phase allocation or positive resource admission.',
        negative_physical_pre_receipt_bytes=before,negative_physical_conservative_reserved_bytes=ledger['conservative_bytes'],
        cleanup_permission_observations=cleanup['error_summaries'],closed_custody_before210=True,
        recorded_call_started=started,recorded_call_completed=completed,recorded_call_raised=raised,
        successful_snapshot_audit_API_returns=e['audits'],successful_certificate_checker_API_returns=e['certify'],
        activated_or_unique_or_reused_clause_count=None,full_proof_catalogue_archived=False,total_exported_private_work=None,
        root_callback_count_at_failure_cutoff=f['root_check_calls'],inclusive_action_wall_ns=times,
        completed_phase_pairs=n,active_unfinished_phase_start=phases[-1],
        admission=False,scientific_acceptance=False,mathematical_proof_admitted=False,component_runtime_qualified=False))
    terminals.append(t)

need('strict original serial off then on',terminals[0]['terminal_observed_ns']<terminals[1]['observer_started_ns'])
need('retirement is postterminal administrative only',retirement['pinned_python_monotonic_ns']>terminals[1]['terminal_observed_ns'])
pin(D/'ROOT-retirement-v1.json');pin(C/'typed-final-grant-delta-review-v1.json')
limitations=[
 'This is a successful audit of two preserved negative outcomes, not a passing calibration. Neither arm produced the complete680+55 packet/result/header. Prefix68/53, verifier returns10/7 and all other recorded calls are diagnostic and do not admit partial cases, proofs, witnesses, clauses or runtime qualification.',
 'Call maps count instrumented API entries/returns/raised observations at the worker-failure cutoff. ON842 oracle.certify returns do not establish842 distinct/activated/reused clauses or an archived accepted catalogue. Full packet/graph/certificate/witness values and cumulative exported oracle/search semantic work were not retained; missing is unavailable, not zero. Root callback counts are their separate400m units.',
 'Inclusive API action intervals overlap: oracle/certifier time is nested in search, and wrapper Source/custody/serialization guards are outside those intervals. No exclusive phase, CPU, allocation or causal bottleneck attribution is established. No ratio is a controlled speedup or failure-free performance comparison.',
 'The off run records an intermediate PermissionError from a group probe. Subsequent saved wait4 TERM exit and two ABSENT observations establish the declared final cleanup gates; permission denial itself is UNKNOWN and never absence. This reviewer made no live process probe and relies on retained owned-process observations under the declared OS trust.',
 '210s negative custody/log/ledger closure does not rescue failed180s positive work. Retired grants remain consumed; administrative retirement is after the actual and not a backdated window check. No new actual, retry, cap raise or smaller input is authorized.',
 'A direct primitive same-instance clause cache remains distinct from the separate unexecuted long-range geometric gadget, literal GCTS marking implementation, trained RL or a fixed FOL checker/palette. No new theorem, universal engine, production/full-pipeline qualification or GCTS/RL advantage is established.',
 'The exact inherited Source/prospective loader, owner, runtime/OS, same-author/separate-implementation and finite fault-coverage limitations remain. Those prelaunch Source statements are historical; the two current helper actuals now executed and failed. Review used ordinary saved JSON/raw bytes only and no target imports/calls, opaque decoding, checking, simulation or replay.',
]
value=dict(schema='wang-reusable-nogood-saved-data-review-v1',reviewer_identity='/root/conventional_control_review',
    saved_review_passed=True,saved_data_only=True,review_component_calls=0,component_calls=0,scientific_calls=0,
    subject_imports=0,fixture_calls=0,simulations=0,process_probes=0,opaque_decodes=0,actual_execution_authorized=False,
    scientific_acceptance=False,mathematical_proof_admitted=False,full_pipeline_qualified=False,component_runtime_qualified=False,
    classification='TWO_CLOSED_NEGATIVES_CONSISTENT_WITH_RECORDED_GATES',rows=rows,
    exact_Root_saved_projection=auditpin,retirement=pin(D/'ROOT-retirement-v1.json'),
    prelaunch_final_delta=pin(C/'typed-final-grant-delta-review-v1.json'),raw_pins=sorted(raw_files.values(),key=lambda v:v['path']),
    typed_checks=checks,check_count=len(checks),mismatch_count=0,limitations=limitations,
    ancestry='Same C reviewer independently reviewed current Source/prospective/grant and this saved-data scope. C authored older protocol/control ancestors; Root owns current actuals, worker/controller; Library mathematical components and B distinct oracle authorship remain disclosed. No self-author independent kernel certificate is asserted.',
    interpreter=dict(executable=sys.executable,version=sys.version,flags='-I -S -B',activity='own stdlib ordinary JSON/raw hashes only'),tools_stopped_after_handoff=True)
p=C/'typed-saved-comparison-review-v1.json'
if p.exists():raise FileExistsError(p)
p.write_text(json.dumps(value,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
print(json.dumps(dict(receipt=pin(p),checks=len(checks),mismatch_count=0,rows=[{k:r[k]for k in ['mode','unadmitted_completed_prefix_count','external_runner_entry_elapsed_seconds','standalone_worker_lifetime_peak_bytes','successful_snapshot_audit_API_returns','successful_certificate_checker_API_returns']}for r in rows]),sort_keys=True))
