"""Ordinary JSON/raw metadata only; no targets or process operations."""
from pathlib import Path
import hashlib
import json
import sys

C=Path('/private/tmp/gcts-wang-nogood-review-20261019')
D=Path('/private/tmp/gcts-wang-receptor-ROOT-20261019-v1')
checks=[]
def h(raw):return hashlib.sha256(raw).hexdigest()
def pin(path):
    p=Path(path);raw=p.read_bytes()
    return dict(path=str(p),bytes=len(raw),sha256=h(raw))
def read(path):return json.loads(Path(path).read_bytes())
def canon(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def need(name,ok):
    checks.append(dict(id=name,passed=bool(ok)))
    if not ok:raise AssertionError(name)
def raw(name,p):need(name,pin(p['path'])==p and not Path(p['path']).is_symlink())

expected={
 'off':('09f4907dd39fcd04e68076b654ccc988c30084327726cd76960d4f65d92b016c',3320,
        'c289a699e09372f9412c11f47739b302e87027f60aaaf4afbd8986b9cb46d5d3',30062),
 'on':('c4bf985623f58fb4b15f87ed4f0929519579bbdd66a017f3f69729e1cce986ee',3315,
       'b6f570daa9f95ed691609509dc53965ec0524f10cbf32b66f0b80f910a1340ac',30074)}
rows=[]
for mode,(sha,size,reviewsha,reviewsize)in expected.items():
    p=D/('plan-authorized-'+mode+'-v1.json');current=pin(p)
    need(mode+': offered true plan exact',current['sha256']==sha and current['bytes']==size)
    plan=read(p);false=read(D/('plan-false-'+mode+'-v1.json'))
    need(mode+': only authorization field differs',set(plan)==set(false)and [k for k in plan if plan[k]!=false[k]]==['authorization'])
    subject={k:v for k,v in plan.items()if k!='authorization'}
    need(mode+': exactly nine subject fields',len(subject)==9)
    subjectsha=h(canon(subject));authpin=plan['authorization'];raw(mode+': Root grant raw bytes',authpin)
    auth=read(authpin['path'])
    need(mode+': exact seven-field Root maxone authorization',set(auth)=={'schema','author_identity','actual_execution_authorized','maximum_actual_invocations','subject_sha256','review','scope'}and
         auth['schema']=='ROOT-wang-encoding-authorization-v1'and auth['author_identity']=='/root'and auth['actual_execution_authorized']is True and
         type(auth['maximum_actual_invocations'])is int and auth['maximum_actual_invocations']==1 and auth['subject_sha256']==subjectsha)
    raw(mode+': exact review bytes',auth['review'])
    need(mode+': exact adopted review descriptor',auth['review']['sha256']==reviewsha and auth['review']['bytes']==reviewsize)
    review=read(auth['review']['path'])
    need(mode+': exact original reviewed subject',review['subject']==subject and review['subject_sha256']==subjectsha)
    need(mode+': required current scoped Source review',review['schema']=='wang-encoding-Source-prospective-review-v1'and review['reviewer_identity']=='/root/conventional_control_review'and
         review['review_passed']is True and review['source_only']is True and type(review['component_calls'])is int and review['component_calls']==0 and review['actual_execution_authorized']is False)
    need(mode+': full Sources retained',plan['sources']==review['sources'])
    for role,value in plan['sources'].items():raw(mode+': current whole Source '+role,value)
    raw(mode+': Python',plan['python']);raw(mode+': declaration',plan['declaration']);raw(mode+': closure',plan['runtime_closure'])
    for item in plan['inputs']:raw(mode+': whole input '+item['id'],item['pin'])
    closure=read(plan['runtime_closure']['path']);declaration=read(plan['declaration']['path'])
    need(mode+': unchanged closure and declaration join',closure['sources']==plan['sources']and closure['python']==plan['python']and closure['declaration']==plan['declaration']and declaration['inputs']==plan['inputs']and declaration['limits']==plan['limits'])
    for i,value in enumerate(closure['stdlib_files']):raw(mode+': declared stdlib '+str(i),value)
    actual=Path(plan['actual_directory']);observer=p.with_name(p.stem+'-terminal-observation')
    need(mode+': fresh canonical absent actual',actual.is_absolute()and str(actual.resolve())==str(actual)and actual.parent==D and not actual.exists())
    need(mode+': fresh absent authorized observer',not observer.exists())
    need(mode+': false plan remains false max0',read(false['authorization']['path'])['actual_execution_authorized']is False and read(false['authorization']['path'])['maximum_actual_invocations']==0)
    rows.append(dict(mode=mode,plan=current,false_plan=pin(D/('plan-false-'+mode+'-v1.json')),authorization=authpin,review=auth['review'],subject=subject,subject_sha256=subjectsha,actual_directory=str(actual),authorized_observer_directory=str(observer),paths_absent_at_review=True))
need('distinct fresh arm paths',rows[0]['actual_directory']!=rows[1]['actual_directory']and rows[0]['authorized_observer_directory']!=rows[1]['authorized_observer_directory'])
value=dict(schema='wang-encoding-final-grant-delta-review-v1',reviewer_identity='/root/conventional_control_review',final_grant_delta_review_passed=True,
    review_passed=True,source_only=True,metadata_only=True,component_calls=0,scientific_calls=0,subject_imports=0,fixture_calls=0,simulations=0,process_probes=0,
    actual_execution_authorized=False,rows=rows,typed_checks=checks,check_count=len(checks),mismatch_count=0,
    scope='Only two exact authorization descriptors change from the reviewed false plans. Full nine-field subjects, seven Source pins, interpreter/stdlib, complete original680+55 preimage, profiles and caps remain exact. Root author owns each fresh true max-one grant. This is neither grant creation nor actual launch.',
    limitations=['Point-in-time freshness only. No process table or privileged probe was taken. Parent must independently freeze fresh all-peer-idle/absence barrier immediately before each original-order serial actual.',
      'All limitations of the exact adopted Source/prospective reviews remain. No prior consumed subject may be retried, no partial prefix admitted, no cap raised, no smaller bank or theorem/GCTS/RL/implementation qualification inferred.'],
    interpreter=dict(executable=sys.executable,version=sys.version,flags='-I -S -B'),tools_stopped_after_handoff=True)
p=C/'typed-final-grant-delta-review-v1.json'
if p.exists():raise FileExistsError(p)
p.write_text(json.dumps(value,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
print(json.dumps(dict(receipt=pin(p),checks=len(checks),mismatches=0),sort_keys=True))
