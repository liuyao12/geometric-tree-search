"""Reviewer-owned raw/AST/ordinary-JSON inspection; never loads target code."""
from pathlib import Path
import ast
import hashlib
import json
import sys

C = Path('/private/tmp/gcts-wang-nogood-review-20261019')
D = Path('/private/tmp/gcts-wang-receptor-ROOT-20261019-v1')
PY = '/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12'
checks = []

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def pin(path):
    path = Path(path)
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=digest(raw))

def check(name, value):
    checks.append(dict(id=name, passed=bool(value)))
    if not value:
        raise AssertionError(name)

def read_json(path):
    return json.loads(Path(path).read_bytes())

def raw_pin(name, value):
    check(name, type(value) is dict and set(value) == {'path', 'bytes', 'sha256'}
          and pin(value['path']) == value and Path(value['path']).is_absolute()
          and str(Path(value['path']).resolve()) == value['path']
          and not Path(value['path']).is_symlink())

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False,
                      allow_nan=False).encode('utf8')

def tree(raw):
    return ast.parse(raw)

def ast_hash(raw):
    return digest(ast.dump(tree(raw), include_attributes=False).encode())

def definitions(raw):
    return {node.name: ast.dump(node, include_attributes=False)
            for node in tree(raw).body if isinstance(node, (ast.FunctionDef, ast.ClassDef))}

def literals(raw):
    result = {}
    for node in tree(raw).body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            try:
                result[node.targets[0].id] = ast.literal_eval(node.value)
            except (ValueError, TypeError):
                pass
    return result

def save(name, value):
    path = C / name
    if path.exists():
        raise FileExistsError(path)
    path.write_text(json.dumps(value, sort_keys=True, indent=2, ensure_ascii=False,
                               allow_nan=False) + '\n')
    return pin(path)

check('pinned reviewer parser executable', sys.executable == PY)
check('pinned reviewer parser version', sys.version.startswith('3.12.14 '))
master = Path('/private/tmp/gcts-wang-search-library-20261019/basic-tiling-algorithm-current.md')
check('master exact current pin', pin(master)['sha256'] == 'ca6ee206287bf18b69f88a35d30968312499567755f347a819af4cf49743e7d4'
      and pin(master)['bytes'] == 36240)
prior = C / 'typed-gadget-argument-review-v1.json'
g1 = read_json(prior)
argument = D / 'nogood-marking-construction.html'
html = argument.read_text()
check('prior gadget pin is already corrected current bytes', g1['argument'] == pin(argument))
for label, text in {
    'G1 exact origins': 'both <em>exactly</em> the original centers together with those auxiliary centers; no other translation origins are allowed.',
    'G2 every prototype anchor': 'Every allowed prototype assigns its own center anchor.',
    'G2 empty assigned conflict': 'Every allowed tile must still assign a different center-anchor value: leaving that channel unassigned would not conflict with the pin.',
    'G3 literal identity': 'geometrically identical prototypes remain distinct choices unless an explicit quotient is separately justified.',
    'gadget unimplemented': 'That cache is not this marking gadget.',
    'fixed palette open': 'A universal fixed interpreter palette would need a separate data encoding and correspondence proof.',
}.items():
    check(label, text in html)
g2 = dict(g1)
g2.update(schema='finite-nogood-marking-gadget-argument-review-v2', argument=pin(argument),
    prior_review=pin(prior), review_passed=True, conditional_argument_valid=True,
    resolved_specifications=['G1', 'G2', 'G3'], required_specifications=[],
    assessment_correction='The immutable V1 receipt already pinned these corrected HTML bytes while describing the earlier prose. V2 is a corrected independent reread of the SAME pinned bytes, not a fabricated Source byte delta. V1 remains preserved as the inconsistent earlier assessment.',
    verdict='The finite translation-only unit-center point-model conditional projection and unique-extension argument is coherent with the now-explicit origin, universal anchor and identity conventions. This is Source/manual reasoning only, not a generated gadget, formal proof or runtime qualification.',
    next='Any concrete generator and full enlarged instance still require separate Source, projection, unique-extension, cost and prospective reviews. No implemented literal m-gadget, ordinary nearest-neighbor Wang localization or fixed universal palette is supplied.',
    tools_stopped_after_handoff=False)
gadget_receipt = pin(C / 'typed-gadget-argument-review-v2.json')
check('frozen corrected gadget assessment exact', read_json(gadget_receipt['path']) == g2)

offers = read_json(D / 'comparison-offers-v1.json')
check('exact two comparison offers', [r['mode'] for r in offers['offers']] == ['off', 'primitive_empty_support'])
check('offer no permission', offers['actual_execution_authorized'] is False and type(offers['component_calls']) is int and offers['component_calls'] == 0)
sources = None
contexts = []
source_text = {}
for index, entry in enumerate(offers['offers']):
    prefix = 'off' if index == 0 else 'on'
    raw_pin(prefix + ': offer whole bytes', entry['offer'])
    offer = read_json(entry['offer']['path'])
    raw_pin(prefix + ': false plan whole bytes', offer['false_plan'])
    plan = read_json(offer['false_plan']['path'])
    check(prefix + ': exact ten plan fields', set(plan) == {'schema','invocation_id','actual_directory','python','sources','inputs','limits','declaration','runtime_closure','authorization'})
    subject = {k: v for k, v in plan.items() if k != 'authorization'}
    check(prefix + ': full exact nine-field subject', len(subject) == 9 and subject == offer['subject'])
    sha = digest(canonical(subject))
    check(prefix + ': subject digest', sha == offer['subject_sha256'] == entry['subject_sha256'])
    check(prefix + ': no offer actual permission', offer['actual_execution_authorized'] is False and offer['component_calls'] == 0)
    raw_pin(prefix + ': Python', plan['python'])
    check(prefix + ': Python exact version pin', plan['python']['path'] == PY and plan['python']['sha256'] == '21a9986bad1dbbcd813a252b19b4263fc0755ed2dbf8632c83e5d6117a12f319')
    check(prefix + ': seven Sources exact scope', set(plan['sources']) == {'worker','compiler','search','verifier','oracle','runner','observer'} and plan['sources'] == offer['sources'])
    if sources is None:
        sources = plan['sources']
    check(prefix + ': source-matched arms', sources == plan['sources'])
    for role, value in plan['sources'].items():
        raw_pin(prefix + ': whole Source ' + role, value)
        source_text[role] = Path(value['path']).read_text()
        unused_code = compile(source_text[role], value['path'], 'exec')
        del unused_code  # No code object is evaluated.
    raw_pin(prefix + ': declaration', plan['declaration'])
    raw_pin(prefix + ': runtime closure', plan['runtime_closure'])
    declaration = read_json(plan['declaration']['path'])
    closure = read_json(plan['runtime_closure']['path'])
    check(prefix + ': declaration complete inputs/profile', declaration['inputs'] == plan['inputs'] and declaration['limits'] == plan['limits'] and declaration['full_pipeline_qualified'] is False and declaration['actual_execution_authorized'] is False)
    check(prefix + ': exact declared mode', declaration['nogood_mode'] == entry['mode'])
    check(prefix + ': current full runtime binding', closure['sources'] == sources and closure['python'] == plan['python'] and closure['declaration'] == plan['declaration'])
    check(prefix + ': attributed pinned AST parser', closure['AST_parser']['executable'] == PY and closure['AST_parser']['version'] == sys.version)
    for row in closure['direct_import_census']:
        role = row['role']; text = source_text[role]
        check(prefix + ': AST source ' + role, row['source'] == sources[role] and row['AST_sha256'] == ast_hash(text))
        imports = sorted({(n.module if isinstance(n, ast.ImportFrom) else a.name)
                          for n in ast.walk(tree(text)) if isinstance(n, (ast.Import, ast.ImportFrom))
                          for a in (n.names if isinstance(n, ast.Import) else [None])})
        check(prefix + ': direct import census ' + role, imports == row['direct_imports'])
    check(prefix + ': AST role census complete', {r['role'] for r in closure['direct_import_census']} == set(sources))
    for i, value in enumerate(closure['stdlib_files']):
        raw_pin(prefix + ': stdlib raw pin ' + str(i), value)
    check(prefix + ': original full capsule count', len(plan['inputs']) == 1)
    value = plan['inputs'][0]['pin']; raw_pin(prefix + ': full input preimage', value)
    check(prefix + ': historical complete input bytes', value['sha256'] == '60ced7c79f91fd475ef88e90cace3ce5fffe15b0c8450d4b3e934d3764ffb80e' and value['bytes'] == 232943)
    inputs = read_json(value['path'])
    check(prefix + ': all680 original case IDs order', len(inputs['cases']) == 680 and [r['id'] for r in inputs['cases']] == declaration['case_ids'])
    check(prefix + ': all4 original machines order', len(inputs['machines']) == 4 and [r['id'] for r in inputs['machines']] == declaration['machine_ids'])
    check(prefix + ': all30 original groups order and full variants', len(inputs['diagnostics']) == 30 and inputs['diagnostics'] == declaration['diagnostics'] and sum(len(r['variants']) for r in inputs['diagnostics']) == 55 and [r['id'] for r in inputs['diagnostics']] == declaration['diagnostic_ids'])
    check(prefix + ': original strict case/group cardinalities', declaration['exact_case_count'] == 680 and declaration['exact_diagnostic_groups'] == 30 and declaration['exact_diagnostic_variants'] == 55)
    check(prefix + ': declared private profiles literal worker', declaration['checkpoint_limit'] == literals(source_text['worker'])['CHECKPOINT_LIMIT'] and declaration['nogood_limits'] == {'clauses':256, 'witness_rows':1000000, 'proof_work':400000000})
    raw_pin(prefix + ': false authorization', plan['authorization'])
    auth = read_json(plan['authorization']['path'])
    check(prefix + ': false max0 exact subject', auth['actual_execution_authorized'] is False and type(auth['maximum_actual_invocations']) is int and auth['maximum_actual_invocations'] == 0 and auth['subject_sha256'] == sha)
    check(prefix + ': fresh actual path', not Path(plan['actual_directory']).exists() and Path(plan['actual_directory']).parent == D)
    observer_path = Path(offer['false_plan']['path']).with_name(Path(offer['false_plan']['path']).stem + '-terminal-observation')
    check(prefix + ': fresh false observer path', not observer_path.exists())
    contexts.append(dict(mode=entry['mode'],offer=entry['offer'],plan=offer['false_plan'],subject=subject,sha=sha,
                         declaration=declaration,closure=closure,observer_path=str(observer_path)))

parent_search = Path('/private/tmp/gcts-wang-search-library-20261019/wang_point_search_v2.py')
parent_text = parent_search.read_text()
restored_prefix = source_text['search'].split('# V3 explicit, redundant, same-instance constraints.')[0].rstrip() + '\n'
restored_prefix = restored_prefix.replace("VERSION = 'finite-wang-complete-point-search-v3-primitive-nogoods'", "VERSION = 'finite-wang-complete-point-search-v2'")
check('search exact raw V2 prefix except VERSION', restored_prefix == parent_text)
check('search old definitions unchanged AST', all(definitions(source_text['search'])[k] == v for k, v in definitions(parent_text).items() if k != 'search'))
old_search_def = next(n for n in tree(parent_text).body if isinstance(n, ast.FunctionDef) and n.name == 'search')
new_search_defs = [n for n in tree(source_text['search']).body if isinstance(n, ast.FunctionDef) and n.name == 'search']
check('search original implementation retained before new entry', len(new_search_defs) == 2 and ast.dump(new_search_defs[0], include_attributes=False) == ast.dump(old_search_def, include_attributes=False))
parent_worker = Path('/private/tmp/gcts-wang-calibration-worker-20261019/qualify_wang_calibration_worker_v2.py')
old_defs = definitions(parent_worker.read_text()); new_defs = definitions(source_text['worker'])
changed = sorted(k for k in old_defs if old_defs[k] != new_defs.get(k))
check('worker exact known new coupling definitions only', changed == ['Session','calibrate','diagnostics','invoke_search','main','observer_for'])
for name in ['bind_original_case','reference_after_search','palette_check','invoke_compiler','invoke_verifier','mutate','callable_seal','checked','compiler_word']:
    check('worker historical body AST ' + name, old_defs[name] == new_defs[name])
parent_runner = Path('/private/tmp/gcts-wang-execution-ROOT-20261019/run_wang_encoding_once_v5.py')
old_defs = definitions(parent_runner.read_text()); new_defs = definitions(source_text['runner'])
check('outer only validate_qualification definition changes', [k for k in old_defs if old_defs[k] != new_defs.get(k)] == ['validate_qualification'])
parent_observer = Path('/private/tmp/gcts-wang-execution-ROOT-20261019/observe_wang_encoding_once_v1.py')
check('observer whole raw exact inherited', source_text['observer'] == parent_observer.read_text())
for role in ['compiler','search','verifier','oracle']:
    check(role + ': no imports', not any(isinstance(n,(ast.Import,ast.ImportFrom)) for n in ast.walk(tree(source_text[role]))))
    check(role + ': no generators', not any(isinstance(n,(ast.Yield,ast.YieldFrom)) for n in ast.walk(tree(source_text[role]))))
check('two mode declarations differ only mode and input context paths', {k:v for k,v in contexts[0]['declaration'].items() if k != 'nogood_mode'} == {k:v for k,v in contexts[1]['declaration'].items() if k != 'nogood_mode'})

# Static presence checks supplement, rather than substitute for, full manual Source reasoning.
for label, role, text in [
    ('independent proof before publication', 'search', 'self.observe_certificate(offered)'),
    ('selected support truth', 'search', 'if cid not in self.generations:'),
    ('every original tile witness', 'search', 'for tile in range(size):'),
    ('non-primitive abstention', 'search', "reason='no primitive mark rejection; exclusions never count'"),
    ('full active/counter inverse', 'search', "self.trail.append(('active', cid, self.active[cid]))"),
    ('physical restoration full equality', 'search', "if self._physical_core() != frame['physical_core']:"),
    ('latest knowledge replay', 'search', "self.notify('ROLLBACK_REPLAYED')"),
    ('terminal teardown', 'search', "self.activation, self.applied_version = 'SUSPENDED_FINAL_CLEANUP', None"),
    ('oracle full palette witnesses', 'oracle', "_need(len(rows)==g['size'],'exactly one witness per original palette tile')"),
    ('oracle raw selected consequence', 'oracle', 'if cid not in chosen_ids:missing.append(cid)'),
    ('full returned catalogue join', 'worker', "canonical(value['nogood_certificates'])==canonical(certificates)"),
    ('whole returned scope join', 'worker', "canonical(value['nogood_scope'])==canonical(instance)"),
    ('raw undo checkpoint separately joined', 'worker', "knowledge['last_restore']['checkpoint']==saved['trail_length']"),
    ('unchanged knowledge effective equality', 'worker', "if version==replay_pending['version']:"),
    ('final literal trail zero', 'worker', "core==initial and snapshot['trail_length']==0"),
    ('global Root first fault', 'worker', 'primary=s.first_fault if s.first_fault is not None else error'),
    ('outer expanded gate', 'runner', "payload['expanded_canonical_packet_bytes']+w['result']['bytes']"),
]:
    check(label, text in source_text[role])

manual = [
 dict(id='M1', status='NO_BLOCKER_IN_DECLARED_SOURCE_SCOPE', finding='For every original palette ID the learned packet contains one actual unequal assigned midpoint value supplied by a permanent pin or one selected mutually compatible support placement outside the distinguished point. Branch exclusions, older clauses and domain absence cannot justify the primitive proof. Separate B implementation rereads geometry and the full packet; Root retains its exact checked value before activation.'),
 dict(id='M2', status='NO_BLOCKER_IN_DECLARED_SOURCE_SCOPE', finding='Clause inference counts selected support identities only. Zero missing support produces a distinguished-point dead consequence; one missing support forbids that literal. Literal unavailability is not treated as selected truth. The complete original candidate/dependency universe and global DEAD/FORCED/earliest-generation scheduler remain; abstention preserves fallback.'),
 dict(id='M3', status='NO_BLOCKER_IN_DECLARED_SOURCE_SCOPE', finding='Physical occupancy, marks/refcounts, generations and parent exclusions restore in full before suspension; both directions of effective activity and overlay are trailed. Suspension rebuilds the complete original physical/context incidence. Latest persistent catalogue is replayed before an active stable state or new decision. Every old graph field is independently reconstructed and compared at paired rollback; effective equality is required when the version is unchanged. Actual control-trail length is distinct from graph equality and must match the saved undo checkpoint only through last_restore.checkpoint.'),
 dict(id='M4', status='NO_BLOCKER_IN_DECLARED_SOURCE_SCOPE', finding='Final root teardown explicitly suspends the overlay, rebuilds and checks the original complete graph and literal trail0, while retaining the monotone catalogue. Root checks the full initial graph values. This is terminal restoration, not a claim the graph is still active under retained knowledge, and no continuation is allowed.'),
 dict(id='M5', status='NO_BLOCKER_IN_DECLARED_SOURCE_SCOPE', finding='The B oracle separately validates every proof and all catalogue IDs, dependencies, unit/conflict reasons, physical/effective candidate sets, forward/reverse incidence, selected data and global scheduler. Exclusion soundness and historical equality are not inferred from a producer flag; the Source DFS plus Root paired full values provide those separate obligations.'),
 dict(id='M6', status='NO_BLOCKER_IN_DECLARED_SOURCE_SCOPE', finding='Exact original machine/initial word/horizon/dimensions and complete semantic NESW/exterior pins are joined before every normal search. Full machine-only palette verification, search-first ordering, subsequent whole TM reference and SAT point/TM certificate verification remain unchanged. No task answer is supplied to search.'),
 dict(id='M7', status='CONDITIONAL_RUNTIME_TRUST', finding='Private exact-class/per-call search limits produce UNKNOWN, never FINITE_EXHAUSTED. Oracle private ownership is checked after the first-Root-fault gate. Direct nongenerator callbacks preserve selected foreign objects in the declared ordinary owner regime. Wrapper serialization/counter/timing/diagnostic allocation and total diagnostic failures are not universally error-transparent; failures remain fail-closed and exact first Root faults are preferentially retained when recorded.'),
 dict(id='M8', status='COST_AND_COVERAGE_LIMITATION', finding='Full-instance copies, catalogue retention, proof checks, complete graph scans, repeated oracle audits, physical replay, output and Source guards all remain inside the original wall/RAM/output gates. Root checkpoint400m and distinct per-call semantic limits are not CPU work or interchangeable units. Inclusive API times overlap nested oracle/certificate intervals and exclude wrapper guards; do not sum them as exclusive costs.'),
 dict(id='M9', status='UNEXECUTED_COVERAGE_LIMITATION', finding='The same original680 cases,30 groups and55 variants are preserved in order. No supplemental malformed-certificate, selected-unit, learned-conflict, changed-version rollback, certificate-observer fault or mid-replay interruption fixture is added or claimed executed. Actual records alone may establish which new mechanisms were reached. Source review is not a runtime fixture pass or formal soundness theorem.'),
]
limitations = [
 'Source/manual reasoning and ordinary raw/AST/JSON checks only. No target module/code object, function, fixture, simulator, oracle, checker, compiler, search, verifier or renderer was invoked. No actual permission is granted.',
 'Specialized finite translation-only integer unit-center generation0 Wang problem. General fractional/shared-positive-support, mixed-generation and continuous geometry are not qualified.',
 'The on arm is a direct certified primitive-clause cache, not implemented literal GCTS m-markings, a generated receptor gadget, learned markings, RL, a fixed universal palette or a faithful FOL proof engine.',
 'Library authored compiler/search/verifier and the search successor; Root authored the current worker/controller, B the distinct oracle. Implementation separation and C independent review do not constitute a formal independent kernel certificate. C authored historical controls/protocol ancestors, not these current mathematical components.',
 'Raw-pinned exclusive-owner SourceFileLoader and postload origin/function/code/default-identity checks, pinned Python and declared stdlib entry files. Builtin/frozen/transitive runtime and OS are trusted. No initial compiled-object/pyc/default-content/closure-cell/global/OS or hostile-callback seal is claimed.',
 'All snapshot values and independent full census are held through actual checking and complete paired comparisons; intermediate values may then be released. Archived normal observation receipts are reason/size/hash/work summaries, not reconstructable all-state snapshots or witnesses.',
 'On a Root deadline/foreign interruption, the bounded failure packet may retain phase/call/count/ID prefix and not the active full certificate catalogue, total search counts, exact snapshot values, final witness or complete oracle work. Pending independently checked but not yet activated proposals cannot be promoted to an accepted catalogue; partial cases/failures have no acceptance.',
 'Positive worker/header/output reading and known worker exit must finish before original180s from runner Source entry; later raw/metadata/log/physical/custody and external terminal checks finish before210s. Observer225s is failure cleanup only. Worker-only Darwin lifetime highwater1GiB does not cover parent allocations or simultaneous total RAM.',
 'Stored and fully expanded logical outputs must both meet128MiB and physical ledger includes9MiB reservations; individual log caps4MiB, worker receipt4MiB. No fitting prediction or cap increase. Any failed gate remains negative.',
 'New off/on subjects are fresh one-use comparisons only after separate Root authorization and final delta/freshness/idle review. Earlier consumed680-prefix failure and six-root/production negatives remain preserved; no replay, rescue, statistical/causal speedup, GCTS/RL advantage, new theorem or general proof/universality qualification follows.',
]
prior_source = Path('/private/tmp/gcts-wang-finite-qualification-peer-20261019/typed-combined-Source-prospective-review-v3-final.json')
raw_pin('prior genuine Source ancestry review', pin(prior_source))
result_descriptors = []
for context in contexts:
    suffix = 'off' if context['mode'] == 'off' else 'on'
    result = dict(schema='wang-encoding-Source-prospective-review-v1', reviewer_identity='/root/conventional_control_review',
        author_identities=['/root','/root/conventional_library','/root/benchmark_design'],
        review_passed=True, source_only=True, component_calls=0, scientific_calls=0,
        subject_imports=0, fixture_calls=0, simulations=0, renderer_calls=0,
        actual_execution_authorized=False, scientific_acceptance=False, mathematical_proof_admitted=False,
        runtime_qualified=False, full_pipeline_qualified=False,
        subject=context['subject'], subject_sha256=context['sha'], sources=sources,
        false_plan=context['plan'], offer=context['offer'], mode=context['mode'],
        declaration=context['subject']['declaration'], runtime_closure=context['subject']['runtime_closure'],
        master=pin(master), prior_genuine_Source_review=pin(prior_source),
        design_obligations=pin(C/'typed-design-obligations-v1.json'), gadget_argument_review=gadget_receipt,
        manual_Source_assessment=manual, typed_static_checks=checks,
        static_check_count=len(checks), mismatch_count=0,
        review_interpreter=dict(path=PY, version=sys.version, flags='-I -S -B', activity='stdlib raw/AST/ordinary JSON; unused compile code objects discarded without evaluation'),
        limitations=limitations,
        publication_authorized=False, actual_launch_authorized=False,
        next='Root must explicitly adopt scope, create exact max-one authorization for this unchanged full subject, obtain a narrow auth-only delta/freshness receipt and independently freeze all-peer-idle/fresh-path barrier before any actual. This review never grants that authority.',
        tools_stopped_after_handoff=True)
    result_descriptors.append(save('typed-combined-Source-prospective-review-'+suffix+'-v1.json',result))
print(json.dumps(dict(checks=len(checks), mismatches=0, gadget=gadget_receipt, reviews=result_descriptors),sort_keys=True))
