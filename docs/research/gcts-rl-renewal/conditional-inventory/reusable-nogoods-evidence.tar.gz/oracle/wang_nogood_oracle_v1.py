"""UNEXECUTED independent primitive-certificate and full snapshot census.

No compiler, local update, search, verifier, solver, fixture or loader imports.
Declared parent exclusions are subtracted, never certified sound by this audit.
"""
VERSION = 'independent-finite-wang-nogood-oracle-v1'
CALLBACK_CADENCE = 1024
_OWNER = object()
LIMIT_KEYS = ('work','points','candidates','mark_points','placements',
              'exclusions','trail_entries','metadata_entries','clauses','clause_literals',
              'witness_rows','proof_work')
SNAPSHOT_KEYS = ('schema','reason','points','candidates','chosen','marks','forward',
    'reverse','dependencies','boundary','exclusions','scheduler','trail_length','work','authority')
OFFSETS = ((0,-1),(1,0),(0,1),(-1,0))


class SnapshotDataError(ValueError):
    def __init__(self,reason,*,_owner=None):
        self.reason=reason;self._owner=_owner
        super().__init__(reason)


class SnapshotLimit(RuntimeError):
    def __init__(self,reason,attempted_work,*,_owner=None):
        self.reason=reason;self.attempted_work=attempted_work;self._owner=_owner
        super().__init__(reason)


def is_own_limit(error):
    return type(error)is SnapshotLimit and error._owner is _OWNER


def is_own_data_error(error):
    return type(error)is SnapshotDataError and error._owner is _OWNER


def _need(ok,reason):
    if not ok:raise SnapshotDataError(reason,_owner=_OWNER)


class _Work:
    def __init__(self,check,limits):
        _need(callable(check),'explicit external check')
        _need(type(limits)is dict and all(type(k)is str for k in limits) and
              set(limits)==set(LIMIT_KEYS),'all exact private limits')
        for value in limits.values():
            _need(type(value)is int and value>0,'positive exact-int private limit')
        self.check=check;self.limits=dict(limits);self.work=0
        self.in_proof=False;self.proof_work=0
        check()
    def step(self):
        self.work+=1
        if self.in_proof:
            self.proof_work+=1
            if self.proof_work>self.limits['proof_work']:
                raise SnapshotLimit('proof_work',self.work,_owner=_OWNER)
        if self.work>self.limits['work']:
            raise SnapshotLimit('work',self.work,_owner=_OWNER)
        if self.work%CALLBACK_CADENCE==0:
            self.check()  # Direct call preserves every exact foreign object.
    def bound(self,key,value):
        self.step()
        if value>self.limits[key]:raise SnapshotLimit(key,self.work,_owner=_OWNER)


def _integer(value,reason,low=0):
    _need(type(value)is int and value>=low,reason);return value


def _point(value):
    _need(type(value)is list and len(value)==2,'literal two-int point')
    _need(all(type(x)is int for x in value),'exact integer point coordinates')
    return (value[0],value[1])


def _same(left,right,w):
    """Full exact typed structures, no digest or bool/int equality shortcut."""
    pending=[(left,right)]
    while pending:
        w.step();a,b=pending.pop()
        if type(a)is not type(b):return False
        kind=type(a)
        if kind is list:
            if len(a)!=len(b):return False
            for i in range(len(a)):pending.append((a[i],b[i]))
        elif kind is dict:
            if len(a)!=len(b) or set(a)!=set(b) or any(type(k)is not str for k in a):return False
            for key in a:pending.append((a[key],b[key]))
        elif kind in(str,int,bool) or a is None:
            if a!=b:return False
        else:return False
    return True


def _geometry(instance,w):
    _need(type(instance)is dict and instance.get('schema')=='finite-framed-wang-instance-v1',
          'validated finite framed instance required')
    width=_integer(instance['board_width'],'positive board width',1)
    height=_integer(instance['board_height'],'positive board height',1)
    w.bound('points',width*height)
    _need(type(instance['all_root_generations'])is int and instance['all_root_generations']==0,
          'unit-center generation-zero profile only')
    _need(type(instance['required_centers'])is list and type(instance['admissible_origins'])is list,
          'literal complete points/origins')
    origins=[]
    for y in range(height):
        for x in range(width):w.step();origins.append((2*x,2*y))
    origin_rows=[[x,y]for x,y in origins]
    _need(_same(instance['required_centers'],origin_rows,w) and
          _same(instance['admissible_origins'],origin_rows,w),'full row-major required origins')
    palette=instance['palette']
    _need(type(palette)is dict and palette['transformations']=='translations_only_2Z2' and
          palette['point_profile']=='integer-center-midpoint-translation-only-v1' and
          palette['edge_order']=='NESW','exact point/translation profile')
    tiles=palette['tiles'];colors=palette['color_constructors']
    _need(type(tiles)is list and bool(tiles) and type(colors)is list and bool(colors),
          'full nonempty literal palette')
    size=len(tiles);universe=len(origins)*size;w.bound('candidates',universe)
    tile_marks=[]
    for tid,tile in enumerate(tiles):
        w.step();_need(type(tile)is dict and type(tile['id'])is int and tile['id']==tid,
                     'every distinct ordered palette ID')
        _need(_same(tile['t'],[[[0,0],1]],w),'unit-center t only; fractional profile unsupported')
        edges=tile['edges_NESW'];_need(type(edges)is list and len(edges)==4,'four exact edge values')
        expected=[];local=[]
        for (dx,dy),color in zip(OFFSETS,edges):
            w.step();_integer(color,'exact nonnegative color ID')
            _need(color<len(colors),'color inside declared full palette')
            expected.append([[dx,dy],'edge',color]);local.append((dx,dy,color))
        _need(_same(tile['m'],expected,w),'every assigned midpoint, including color zero')
        tile_marks.append(local)

    boundary={}
    fixed=instance['fixed_background_marks']
    _need(type(fixed)is list,'complete fixed boundary section')
    for row in fixed:
        w.step();_need(type(row)is list and len(row)==3 and row[1]=='edge','literal boundary marking')
        p=_point(row[0]);color=_integer(row[2],'fixed color ID')
        _need(color<len(colors) and p not in boundary,'unique fixed midpoint/color')
        boundary[p]=color;w.bound('mark_points',len(boundary))
    words=instance['boundary_NESW']
    _need(type(words)is list and len(words)==4,'full boundary words')
    declared={}
    for side,word in enumerate(words):
        w.step();length=width if side in(0,2)else height
        _need(type(word)is list and len(word)==length,'exact boundary word length')
        for index,color in enumerate(word):
            w.step();_integer(color,'boundary word color');_need(color<len(colors),'boundary color range')
            p=((2*index,-1)if side==0 else(2*width-1,2*index)if side==1 else
               (2*index,2*height-1)if side==2 else(-1,2*index))
            _need(p not in declared,'nonduplicate exterior midpoint');declared[p]=color
    _need(boundary==declared,'all boundary midpoint pins exactly retained')

    return dict(width=width,height=height,origins=origins,size=size,universe=universe,
                tile_marks=tile_marks,boundary=boundary,tiles=tiles,palette=palette)


PACKET_KEYS=('schema','scope','id','point','support','witnesses')
WITNESS_KEYS=('tile_id','point','channel','candidate_value','blocker_kind',
              'blocker_cid','blocker_value')


def _object(value,keys,reason):
    _need(type(value)is dict and all(type(k)is str for k in value) and
          set(value)==set(keys),reason)


def _support(g,support,w):
    _need(type(support)is list,'literal support array')
    w.bound('clause_literals',len(support));last=-1;occupied=set();marks={}
    for cid in support:
        w.step();_integer(cid,'exact support cid')
        _need(last<cid<g['universe'],'sorted unique in-range support');last=cid
        pi,tid=divmod(cid,g['size']);_need(pi not in occupied,'support t overlap')
        occupied.add(pi);ox,oy=g['origins'][pi]
        for dx,dy,color in g['tile_marks'][tid]:
            w.step();p=(ox+dx,oy+dy)
            _need(p not in g['boundary'] or g['boundary'][p]==color,
                  'support disagrees with permanent pin')
            _need(p not in marks or marks[p]==color,'support m disagreement')
            marks[p]=color
    return occupied


def _certificate(g,packet,w):
    """Prove a forbidden conjunction from original point data only.

    CURRENT_INVOCATION_INSTANCE is an owner scope, not a cross-instance ID.
    Every use rechecks all witnesses against the exact supplied instance.
    No active domains, prior clauses or branch exclusions enter this proof.
    """
    _object(packet,PACKET_KEYS,'exact primitive packet fields')
    _need(type(packet['schema'])is str and packet['schema']=='wang-primitive-empty-support-v1' and
          type(packet['scope'])is str and packet['scope']=='CURRENT_INVOCATION_INSTANCE',
          'primitive invocation scope')
    identity=_integer(packet['id'],'nonnegative clause ID')
    point=_integer(packet['point'],'dead point index')
    _need(point<len(g['origins']),'dead point in complete original target')
    support=packet['support'];occupied=_support(g,support,w)
    _need(point not in occupied,'distinguished empty point is not already filled')
    rows=packet['witnesses'];_need(type(rows)is list,'complete witness rows')
    w.bound('witness_rows',len(rows))
    _need(len(rows)==g['size'],'exactly one witness per original palette tile')
    ox,oy=g['origins'][point];support_set=set(support);checked=[];used=set()
    for tid,row in enumerate(rows):
        w.step();_object(row,WITNESS_KEYS,'exact primitive witness fields')
        _need(type(row['tile_id'])is int and row['tile_id']==tid,
              'all original tile IDs once, in order')
        p=_point(row['point']);value=_integer(row['candidate_value'],'candidate color')
        _need(type(row['channel'])is str and row['channel']=='edge',
              'exact edge channel, no absent-domain witness')
        matches=[color for dx,dy,color in g['tile_marks'][tid]
                 if (ox+dx,oy+dy)==p]
        w.step();_need(len(matches)==1 and matches[0]==value,
                       'literal original tile midpoint/value')
        blocker=_integer(row['blocker_value'],'blocker color')
        kind=row['blocker_kind'];cid=row['blocker_cid']
        _need(type(kind)is str,'literal blocker kind')
        if kind=='pin':
            _need(cid is None and p in g['boundary'] and g['boundary'][p]==blocker,
                  'literal original permanent pin')
        elif kind=='placement':
            _integer(cid,'blocker support cid');_need(cid in support_set,'blocker belongs to support')
            pi,btid=divmod(cid,g['size']);bx,by=g['origins'][pi]
            values=[color for dx,dy,color in g['tile_marks'][btid]
                    if (bx+dx,by+dy)==p]
            w.step();_need(len(values)==1 and values[0]==blocker,
                           'literal selected-placement midpoint/value')
            used.add(cid)
        else:
            raise SnapshotDataError('only original pin/selected placement witnesses',_owner=_OWNER)
        _need(value!=blocker,'assigned values must actually disagree, including0')
        detached=dict(row);detached['point']=list(row['point']);checked.append(detached)
    _need(used==support_set,'support is all and only selected placement witnesses')
    return dict(id=identity,point=point,support=list(support),witnesses=checked)


def _attach_failure(error,w,stage):
    # Caller wraps this whole diagnostic path; no failure may mask its primary.
    error.nogood_oracle_prefix=dict(schema='independent-nogood-oracle-failure-prefix-v1',
        stage=stage,audit_work=0 if w is None else w.work,
        proof_work=0 if w is None else w.proof_work,
        cost_available=w is not None,cost_is_lower_bound=w is None,
        complete=False,authority=False)


def certify(instance,packet,*,check,limits):
    """Unexecuted independent same-current-instance primitive checker.

    Caller separately validates fixed Wang schema and owns exact instance /
    packet provenance, retention, callback fault latch and aggregate costs.
    Raises on malformed/invalid proof, own quota or exact foreign exception.
    """
    w=None
    try:
        w=_Work(check,limits);w.in_proof=True
        g=_geometry(instance,w);clause=_certificate(g,packet,w)
        w.step();check()
        return dict(schema='independent-primitive-empty-support-check-v1',
            version=VERSION,status='VALID_SAME_INSTANCE_PRIMITIVE_NOGOOD',
            clause=clause,audit_work=w.work,proof_work=w.proof_work,
            meaning='No complete original tiling contains every support placement.',
            scope='CURRENT_INVOCATION_INSTANCE; exact owner-retained input, rechecked here.',
            no_exclusion_or_domain_witness=True,authority=False,
            geometric_marking_certified=False,formal_kernel_certified=False,
            actual_execution_authorized=False)
    except BaseException as error:
        try:_attach_failure(error,w,'CERTIFY')
        except BaseException:pass
        raise  # Exact active primary, including foreign StopIteration.


KNOWLEDGE_KEYS=('mode','version','applied_version','activation','clauses',
    'blocked','conflicts','dependencies','last_restore','scheduler_evaluation_only')
RESTORE_KEYS=('checkpoint','saved_version','current_version',
              'physical_core_equal','knowledge_changed')
ON_SCHEMA='finite-wang-complete-graph-snapshot-v2-nogoods'


def _knowledge(g,snapshot,certificates,chosen_ids,occupied,w):
    """Independent full proof-store and effective-consequence reconstruction."""
    _need(type(certificates)is list,'explicit complete accepted certificate list')
    w.bound('clauses',len(certificates))
    enabled=snapshot['schema']==ON_SCHEMA
    if not enabled:
        _need(not certificates,'off has no accepted proof inventory')
        return None,{}
    supplied=snapshot['knowledge'];_object(supplied,KNOWLEDGE_KEYS,'exact knowledge fields')
    _need(type(supplied['mode'])is str and supplied['mode']=='primitive_empty_support',
          'exact primitive mode')
    version=_integer(supplied['version'],'knowledge version')
    _need(version==len(certificates),'version equals complete accepted catalogue size')
    clauses=[];dependencies={};blocked={};conflicts=[];keys=set();total_literals=0;total_rows=0
    for identity,packet in enumerate(certificates):
        w.in_proof=True;clause=_certificate(g,packet,w);w.in_proof=False
        _need(clause['id']==identity,'zero-based fresh complete catalogue IDs')
        support=clause['support'];point=clause['point'];key=(point,tuple(support))
        _need(key not in keys,'no duplicate distinguished-point/support certificate')
        keys.add(key);clauses.append([identity,point,list(support)])
        total_literals+=len(support);total_rows+=len(clause['witnesses'])
        w.bound('clause_literals',total_literals);w.bound('witness_rows',total_rows)
        missing=[]
        for cid in support:
            w.step();dependencies.setdefault(cid,[]).append(identity)
            if cid not in chosen_ids:missing.append(cid)
        if not missing:
            _need(occupied[point]==0,'conflicting support cannot coexist with a filled target')
            conflicts.append(identity)
            for tid in range(g['size']):
                w.step();blocked.setdefault(point*g['size']+tid,[]).append(identity)
        elif len(missing)==1:
            w.step();blocked.setdefault(missing[0],[]).append(identity)
    activation=supplied['activation'];_need(type(activation)is str,'literal activation')
    if activation=='ACTIVE':
        _need(type(supplied['applied_version'])is int and supplied['applied_version']==version and
              supplied['scheduler_evaluation_only']is False,'fully applied current knowledge')
        _need(snapshot['reason']in('INITIAL','STATE','KNOWLEDGE_GROWN','ROLLBACK_REPLAYED'),
              'active observer reason')
    else:
        _need(supplied['applied_version']is None and supplied['scheduler_evaluation_only']is True,
              'explicit suspended version/evaluation-only graph')
        _need((activation=='SUSPENDED_ROLLBACK_REPLAY' and snapshot['reason']=='ROLLBACK_PHYSICAL')or
              (activation=='SUSPENDED_FINAL_CLEANUP' and snapshot['reason']=='ROOT_RESTORED'),
              'suspension only at declared replay barrier or final teardown')
        blocked={};conflicts=[]
    restore=supplied['last_restore'];detached_restore=None
    if restore is not None:
        _object(restore,RESTORE_KEYS,'exact restore metadata')
        checkpoint=_integer(restore['checkpoint'],'restore checkpoint')
        w.bound('trail_entries',checkpoint)
        saved=_integer(restore['saved_version'],'saved knowledge version')
        current=_integer(restore['current_version'],'restored knowledge version')
        _need(saved<=current<=version and restore['physical_core_equal']is True and
              type(restore['knowledge_changed'])is bool and
              restore['knowledge_changed']==(saved!=current),'restore version/physical claims')
        if snapshot['reason']in('ROLLBACK_PHYSICAL','ROLLBACK_REPLAYED'):
            _need(current==version,'rollback barrier exposes latest knowledge')
        detached_restore=dict(restore)
    if snapshot['reason']in('ROLLBACK_PHYSICAL','ROLLBACK_REPLAYED'):
        _need(restore is not None,'rollback has explicit restore metadata')
    if snapshot['reason']=='INITIAL':
        _need(version==0 and restore is None,'fresh knowledge-empty INITIAL')
    expected=dict(mode='primitive_empty_support',version=version,
        applied_version=version if activation=='ACTIVE' else None,activation=activation,
        clauses=clauses,blocked=[[cid,ids]for cid,ids in sorted(blocked.items())],
        conflicts=conflicts,dependencies=[[cid,ids]for cid,ids in sorted(dependencies.items())],
        last_restore=detached_restore,scheduler_evaluation_only=activation!='ACTIVE')
    _need(_same(supplied,expected,w),'full independent knowledge catalogue/consequence mismatch')
    return expected,blocked


def _schedule(occupied,forward,w):
    frontier=[];dead=[];forced=[]
    for pi,total in enumerate(occupied):
        w.step()
        if total==0:
            frontier.append(pi)
            if not forward[pi]:dead.append(pi)
            elif len(forward[pi])==1:forced.append(pi)
    if dead:kind='DEAD';point=min(dead)
    elif forced:kind='FORCED';point=min(forced)
    elif frontier:kind='BRANCH';point=min(frontier,key=lambda pi:(0,len(forward[pi]),pi))
    else:kind='COMPLETE';point=None
    return dict(kind=kind,point=point,options=[]if point is None else list(forward[point])),frontier


def audit_snapshot(instance,snapshot,*,check,limits,certificates):
    """Full independent graph at current knowledge; no mutable proof cache.

    Exact ordinary inputs, separately validated fixed Wang schema. Owner retains
    full instance/packets/snapshots, binds identities, and sums every audit cost.
    Exclusion soundness and historical rollback equality remain separate gates.
    """
    w=None
    try:
        w=_Work(check,limits)
        _need(type(snapshot)is dict and all(type(k)is str for k in snapshot),
              'ordinary complete snapshot object')
        on=type(snapshot.get('schema'))is str and snapshot['schema']==ON_SCHEMA
        keys=SNAPSHOT_KEYS+('knowledge',)if on else SNAPSHOT_KEYS
        _need(set(snapshot)==set(keys),'exact off/on snapshot fields')
        _need(type(snapshot['schema'])is str and snapshot['schema']in
              ('finite-wang-complete-graph-snapshot-v1',ON_SCHEMA)and
              snapshot['authority']is False,'known nonauthoritative snapshot schema')
        reasons=('INITIAL','STATE','KNOWLEDGE_GROWN','ROLLBACK_PHYSICAL',
                 'ROLLBACK_REPLAYED','ROOT_RESTORED')if on else ('INITIAL','STATE','ROLLBACK','ROOT_RESTORED')
        _need(type(snapshot['reason'])is str and snapshot['reason']in reasons,'exact observer reason')
        g=_geometry(instance,w)
        origins=g['origins'];size=g['size'];universe=g['universe']
        tile_marks=g['tile_marks'];boundary=g['boundary']
        raw_chosen=snapshot['chosen'];_need(type(raw_chosen)is list,'chosen rows')
        w.bound('placements',len(raw_chosen));_need(len(raw_chosen)<=len(origins),'at most one per point')
        chosen=[];chosen_ids=set();occupied=[0]*len(origins)
        marks={p:[color,1,True]for p,color in boundary.items()}
        for row in raw_chosen:
            w.step();_need(type(row)is list and len(row)==4,'chosen exact row')
            cid=_integer(row[0],'chosen candidate ID');_need(cid<universe and cid not in chosen_ids,'unique chosen ID')
            pi,tid=divmod(cid,size)
            _need(_same(row,[cid,pi,tid,1],w),'chosen ID,origin,tile,generation1 join')
            _need(occupied[pi]==0,'chosen positive-t overlap forbidden');occupied[pi]=1
            chosen_ids.add(cid);chosen.append([cid,pi,tid,1]);ox,oy=origins[pi]
            for dx,dy,color in tile_marks[tid]:
                w.step();p=(ox+dx,oy+dy)
                if p in marks:
                    _need(marks[p][0]==color,'chosen marking disagreement');marks[p][1]+=1
                else:marks[p]=[color,1,False]
                w.bound('mark_points',len(marks))
        chosen.sort()
        _need(_same(raw_chosen,chosen,w),'sorted complete chosen rows')

        exclusions=snapshot['exclusions'];_need(type(exclusions)is list,'declared current-context exclusions')
        w.bound('exclusions',len(exclusions));excluded=set();last=-1
        for cid in exclusions:
            w.step();_integer(cid,'excluded candidate ID')
            _need(last<cid<universe and cid not in chosen_ids,'sorted unique in-range nonchosen exclusion')
            excluded.add(cid);last=cid
        # Exclusions can persist while another choice fills their point. Membership
        # in today's physical set is not required and does not prove failure sound.
        knowledge,blocked=_knowledge(g,snapshot,certificates,chosen_ids,occupied,w)
        physical=[];active=[];candidate_rows=[];forward=[[]for p in origins]
        base_candidates=[];base_forward=[[]for p in origins];base_reverse=[]
        reverse=[];m_dependencies={};t_dependencies=[]
        for pi,(ox,oy) in enumerate(origins):
            w.step();at_origin=[]
            for tid in range(size):
                w.step();cid=pi*size+tid;at_origin.append(cid);legal=occupied[pi]==0
                for dx,dy,color in tile_marks[tid]:
                    w.step();p=(ox+dx,oy+dy)
                    m_dependencies.setdefault(p,[]).append(cid)
                    if p in marks and marks[p][0]!=color:legal=False
                if legal:physical.append(cid)
                base_active=legal and cid not in excluded
                is_active=base_active and cid not in blocked
                base_candidates.append([cid,pi,tid,base_active])
                base_reverse.append([cid,[pi]if base_active else []])
                if base_active:base_forward[pi].append(cid)
                candidate_rows.append([cid,pi,tid,is_active])
                reverse.append([cid,[pi]if is_active else []])
                if is_active:active.append(cid);forward[pi].append(cid)
            t_dependencies.append(['t',pi,at_origin])
        w.bound('mark_points',len(m_dependencies))
        dependencies=t_dependencies
        for p in sorted(m_dependencies):
            w.step();dependencies.append(['m',[p[0],p[1]],m_dependencies[p]])
        scheduler,frontier=_schedule(occupied,forward,w)
        base_scheduler,unused_frontier=_schedule(occupied,base_forward,w)
        expected=dict(points=[[pi,[x,y],occupied[pi],0]for pi,(x,y)in enumerate(origins)],
            candidates=candidate_rows,chosen=chosen,
            marks=[[[p[0],p[1]],value[0],value[1],value[2]]for p,value in sorted(marks.items())],
            forward=[[pi,options]for pi,options in enumerate(forward)],reverse=reverse,
            dependencies=dependencies,boundary=[[[p[0],p[1]],color]for p,color in sorted(boundary.items())],
            exclusions=list(exclusions),scheduler=scheduler)
        if knowledge is not None:expected['knowledge']=knowledge
        for field,value in expected.items():
            _need(_same(snapshot[field],value,w),'full independent snapshot mismatch: '+field)
        trail=_integer(snapshot['trail_length'],'nonnegative trail length');w.bound('trail_entries',trail)
        diagnostic=snapshot['work'];_need(type(diagnostic)is dict,'passive ordinary work counters')
        w.bound('metadata_entries',len(diagnostic))
        for key,value in diagnostic.items():
            w.step();_need(type(key)is str,'counter name');_integer(value,'nonnegative exact-int counter')
        if snapshot['reason']in('INITIAL','ROOT_RESTORED'):
            _need(not chosen and not exclusions and trail==0,'complete initial/root-restored original context')
        expected['trail_length']=trail
        # Independent original physical+parent-context graph, without proof overlay.
        # Trail contents are not in the public ABI; only length is exposed separately.
        physical_projection={key:value for key,value in expected.items()
                             if key not in('knowledge','trail_length')}
        physical_projection['candidates']=base_candidates
        physical_projection['forward']=[[pi,options]for pi,options in enumerate(base_forward)]
        physical_projection['reverse']=base_reverse
        physical_projection['scheduler']=base_scheduler
        physical_projection['trail_length']=trail  # Real current raw log length, never fabricated.
        w.step();check()
        return dict(schema='independent-finite-wang-snapshot-audit-v2-nogoods',version=VERSION,
            status='EXACT_FINITE_POINT_CENSUS_MATCH',census=expected,
            physically_legal_candidates=physical,active_candidates=active,frontier=frontier,
            physical_context_census=physical_projection,
            knowledge_projection=knowledge,audit_work=w.work,proof_work=w.proof_work,
            reason=snapshot['reason'],
            exclusion_scope='Exact subtraction only; exhausted-child exclusion soundness is not certified.',
            rollback_scope='Compare every original graph field in physical_context_census; actual raw trail length and persistent knowledge/history are explicit separate lifecycle checks. last_restore.physical_core_equal is a checked-format producer claim, not an independent historical comparison.',
            instance_scope='Every original tile/pin rechecked; owner retains exact current instance and accepted packet provenance. Scope string is not a cross-instance identity.',
            authority=False,exclusion_soundness_certified=False,formal_kernel_certified=False,
            general_fractional_or_mixed_generation_engine_qualified=False,
            actual_execution_authorized=False)
    except BaseException as error:
        try:_attach_failure(error,w,'AUDIT_SNAPSHOT')
        except BaseException:pass
        raise  # Exact active primary, including foreign StopIteration.
