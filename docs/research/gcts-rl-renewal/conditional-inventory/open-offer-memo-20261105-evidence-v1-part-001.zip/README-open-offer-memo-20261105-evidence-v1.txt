Memoized local proof offers

Open report/open-offer-memo-20261105-v1.html. The evidence manifest lists
every retained source, input, output, log, review and proof certificate.
Extract all archive volumes together and verify the member hashes.

The two search methods share the same finite arithmetic declarations,
rank-marked models, fragment library and search limits. The memoized method
reuses local proposal packets within its fixed proposer. Every candidate
continues through independent instance admission and current-state checking.
The archive preserves time-limited prefixes and native proof outcomes.

Run the reviewed driver under the frozen runtime and flags to reproduce
the owned phases in a fresh directory. The passive audit and renderer read
the saved outputs. See plan/offer-memo-experiment-v1.md for the protocol.
