# Memoization of local fragment offers

Two search arms share the same theorem declarations, fragment library,
rank-marked inventory, independent checkers, and limits. The uncached arm
runs the matcher on each offer query. The memoized arm retains the literal
packet for an anchor within a single fixed proposer. Its cache holds candidate
packets and deterministic local work-limit packets with an empty offer list.
The wall, memory, setup and malformed-input outcomes go through fresh calls.

Both arms charge and count each logical query, including cache hits. They
retain the original 1,024-query and 128-callback-payload limits. The policy
runs independent instance admission and state compatibility on each offered
instance as usual. Search retains the same primitive candidate fallback.
Query records include their logical index, fresh origin index and actual
elapsed time. Packet cost fields describe the fresh origin even on a hit.

Run qualification and fresh materialization, then prepare each target with
the established finite RF basis and certified rank information. Within the
calibration run uncached first. Within nested equality run memoized first.
Each method owns a clean process and performs full event and native checks.
Record both proofs and resource-limited prefixes. Compare retained branch
orders and event streams where scopes permit. Report whole method time,
matching time, actual matcher calls, reuse and independent checking.

The finite cases and donor data come from the prior public archive. No prior
prepared model or target solution is supplied to the current search. The
current reference copy is the exact master from the prior publication base.
The new runtime and source hashes belong to this experiment.
