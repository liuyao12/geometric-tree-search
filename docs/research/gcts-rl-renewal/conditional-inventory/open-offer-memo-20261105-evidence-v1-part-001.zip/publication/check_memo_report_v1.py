"""Check the archive-linked report structure and its binding to audited data."""

from collections import Counter
import hashlib
from html.parser import HTMLParser
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MAIN = 'report/open-offer-memo-20261105-v1.html'
DATA = 'report/open-offer-memo-20261105-data-v1.json'
VOID = {'meta', 'link', 'br', 'hr', 'img', 'input'}


def reference(name):
    payload = (ROOT / name).read_bytes()
    return dict(path=name, bytes=len(payload), sha256=hashlib.sha256(payload).hexdigest())


def load(name):
    return json.loads((ROOT / name).read_bytes())


class Structure(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.stack = []
        self.tags = Counter()
        self.classes = Counter()
        self.ids = set()
        self.links = set()
        self.scripts = []
        self.math_count = 0

    def handle_starttag(self, tag, attributes):
        attrs = dict(attributes)
        self.tags[tag] += 1
        self.classes.update(attrs.get('class', '').split())
        if 'id' in attrs:
            assert attrs['id'] not in self.ids
            self.ids.add(attrs['id'])
        if tag == 'a':
            self.links.add(attrs['href'])
        if tag == 'script' and 'src' in attrs:
            self.scripts.append(attrs['src'])
        if tag not in VOID:
            self.stack.append(tag)

    def handle_endtag(self, tag):
        assert self.stack and self.stack[-1] == tag, (tag, self.stack)
        self.stack.pop()

    def handle_data(self, text):
        if self.stack and self.stack[-1] in ('script', 'style'):
            return
        assert text.count(r'\(') == text.count(r'\)')
        self.math_count += text.count(r'\(')


def main():
    plan = load('publication/archive-plan-v1.json')
    audit = load('publication/saved-data-audit-v1.json')
    data = load(DATA)
    assert plan['status'] == 'ARCHIVE_LINKS_PREPARED'
    assert plan['main'] == reference(MAIN) and plan['data'] == reference(DATA)
    assert audit['status'] == 'PASS'
    assert (ROOT / DATA).read_bytes() == (ROOT / audit['report_data']['path']).read_bytes()
    assert data['native_proofs'] or all(
        m['native_proof_id'] is None for case in data['cases'] for m in case['methods'])
    page = Structure()
    page.feed((ROOT / MAIN).read_text())
    page.close()
    assert not page.stack and page.tags['main'] == page.tags['h1'] == 1
    assert {'reader', 'evidence'} <= page.ids
    assert page.scripts == ['https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js']
    proofs, cases = data['native_proofs'], data['cases']
    expected_rows = sum(len(c['methods']) + 1 for c in cases) + sum(p['lines'] + 1 for p in proofs)
    assert page.tags['tr'] == expected_rows
    assert page.tags['details'] == len(proofs)
    assert page.classes['tile'] == sum(len(p['slots']) for p in proofs)
    assert page.math_count == len(cases) + sum(p['lines'] for p in proofs)
    assert page.classes['bar'] == 6 * len(cases)
    links = set(plan['parts']) | {Path(DATA).name, 'open-offer-memo-20261105-evidence-v1-manifest.json'}
    assert links <= page.links
    result = dict(status='PASS_STATIC_REPORT_CHECK', source=reference(MAIN), data=reference(DATA),
                  checked_html_structure=True, checked_proof_and_case_counts=True, checked_evidence_links=True,
                  proof_details=len(proofs), table_rows=expected_rows, latex_expressions=page.math_count,
                  archive_links=sorted(links), scope='Static structure and byte checks. Browser execution is separate.')
    with (ROOT / 'publication/static-report-check-v1.json').open('x') as stream:
        json.dump(result, stream, sort_keys=True, separators=(',', ':'))
        stream.write('\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
