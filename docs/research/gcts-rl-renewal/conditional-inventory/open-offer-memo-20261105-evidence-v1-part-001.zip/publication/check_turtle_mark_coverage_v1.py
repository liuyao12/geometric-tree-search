"""Reproduce rooted marking coverage from four prior saved artifacts."""

from collections import Counter
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
INPUTS = HERE / "turtle-coverage-input"
RECORD = HERE / "turtle-mark-coverage-v1.json"


def pin(raw):
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def main():
    record_raw = RECORD.read_bytes()
    record = json.loads(record_raw)
    originals = {}
    for ref in record["inputs"]:
        name = Path(ref["path"]).name
        raw = (INPUTS / name).read_bytes()
        require(pin(raw) == {k: ref[k] for k in ("bytes", "sha256")}, name)
        originals[name] = json.loads(raw)
    model = originals["corona-marked-point-model-v1.json"]
    learned = originals["corona-learned-marking-v1.json"]
    action = originals["corona-decorated-action-audit-v1.json"]
    labels = {tuple(c["attachment"]): c["status"] for c in learned["classifications"]}
    catalogue = {tuple(c) for c in originals["contact-catalogue-v1.json"]}
    require(len(labels) == len(learned["classifications"]) and set(labels) == catalogue,
            "Catalogue and classification coverage")
    require(action["status"] == "VERIFIED" and action["group_action"]["point_and_t_action_verified"]
            and action["group_action"]["typed_channel_action_verified"], "Rooted action")
    require(learned["root_attachment"] == [0, 0, 0], "Fixed first placement")
    points = {r["id"]: r["points"] for r in model["orientations"]}
    marks = {r["id"]: r["points"] for r in model["marking_orientations"]}
    require(set(points) == set(marks) == set(range(12)), "Orientation coverage")

    counts = Counter()
    uncovered = []
    root_marks = {(x, y, channel): value for x, y, channel, value in marks[0]}
    root_points = {(x, y): weight for x, y, weight in points[0]}
    for orientation, oriented_marks in sorted(marks.items()):
        translations = {(x - a, y - b) for x, y, channel in root_marks
                        for a, b, other, _ in oriented_marks if channel == other}
        for dx, dy in sorted(translations):
            key = orientation, dx, dy
            if key == (0, 0, 0):
                continue
            shifted = {(x + dx, y + dy, channel): value
                       for x, y, channel, value in oriented_marks}
            if not any(root_marks[k] != shifted[k] for k in root_marks.keys() & shifted.keys()):
                continue
            if any(root_points.get((x + dx, y + dy), 0) + weight > model["capacity"]
                   for x, y, weight in points[orientation]):
                counts["already_capacity_illegal"] += 1
            elif key in labels:
                counts["label_" + labels[key]] += 1
            else:
                counts["uncovered_mark_only"] += 1
                uncovered.append(list(key))
    require(dict(counts) == record["counts"], "Rooted category totals")
    require(uncovered == record["uncovered_mark_only"], "Exact uncovered attachments")
    result = {"status": "PASS_EXACT_TURTLE_MARK_COVERAGE", "record": pin(record_raw),
              "counts": dict(counts), "conflicting_attachments": sum(counts.values()),
              "scope": "Saved model and catalogue only. No search or global infeasibility claims."}
    with (HERE / "turtle-mark-coverage-check-v1.json").open("x") as stream:
        json.dump(result, stream, sort_keys=True)
        stream.write("\n")
    print(json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
