"""Passive exact-byte archive and isolated commit preparation; never pushes.

Source-only until Root reviews this complete file. No scientific imports,
helpers, replay, source edits, primary index or primary checkout writes.
Usage: pinned Python -I -S -B FILE --prepare-links; final UI/admission;
then FILE [EXPECTED_REMOTE_MAIN]. The official GET discovers the base.
"""
import argparse
import gzip
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import subprocess
import sys
import time
import zipfile
import zlib

ROOT = Path(__file__).resolve().parents[1]
GIT = '/private/tmp/gcts-history-publication-20261102-v1.git'
GH = '/Users/liuyao/bin/gh'
REPO = 'liuyao12/geometric-tree-search'
PREFIX = 'docs/research/gcts-rl-renewal/conditional-inventory/'
BASE_URL = 'https://liuyao12.github.io/geometric-tree-search/'
MAIN = 'open-offer-memo-20261105-v1.html'
DATA = 'open-offer-memo-20261105-data-v1.json'
OLD = 'open-receptor-composition-20261104-v1.html'
MANIFEST = 'open-offer-memo-20261105-evidence-v1-manifest.json'
PART_STEM = 'open-offer-memo-20261105-evidence-v1-part-'
PACKAGE_DIR = 'package/final-v1'
INTERNAL = 'ARCHIVE-file-manifest-v1.json'
BEGIN = b'<!-- OPEN_OFFER_MEMO_ARCHIVE_LINK -->'
END = b'<!-- /OPEN_OFFER_MEMO_ARCHIVE_LINK -->'
MAX_PART = 44 * 1024 * 1024
RESERVE = 2 * 1024 * 1024
CAPTURE = 128 * 1024 * 1024
PROTOCOL = 'protocol/frozen-protocol-v1.json'
PROTOCOL_PIN = dict(bytes=9550, sha256='3360c806ffb560a89c4a8ec4e995a8092f1ccdf2fa402b55920393b8c4893765')
BUILDER = 'publication/build_open_report_v1.py'
AUDITOR = 'publication/audit_open_saved_data_v1.py'
BUILD = 'report/build-receipt-v1.json'
ROOT_ADMISSION = 'publication/root-publication-admission-v1.json'
UI = 'publication/static-report-check-v1.json'
TRANSFER_AUDIT = 'publication/saved-data-audit-v1.json'
SOURCE_ADMISSION = 'review/root-source-admission-v1.json'
PRIMARY_MASTER = ROOT/'reference/basic-tiling-algorithm.md'
CASES = ('unary-transfer', 'chained-equality')
METHODS = ('open-fragments', 'memoized')
PHASES = ('qualify','materialize') + tuple(p for c in CASES for p in ('prepare-'+c,) + tuple('evaluate-'+c+'-'+m for m in METHODS))
README = r'''Memoized local proof offers

Open report/open-offer-memo-20261105-v1.html. The evidence manifest lists
every retained source, input, output, log, review and proof certificate.
Extract all archive volumes together and verify the member hashes.

The two search methods share the same finite arithmetic declarations,
rank-marked models, fragment library and search limits. The memoized method
reuses local proposal packets within its fixed proposer. Every candidate
continues through independent instance admission and current-state checking.
The archive preserves time-limited prefixes and native proof outcomes.

Run the reviewed driver under the frozen runtime and flags to reproduce
the owned phases in a fresh directory. The passive audit and renderer read
the saved outputs. See plan/offer-memo-experiment-v1.md for the protocol.
'''.encode('ascii')


def need(condition, reason):
    if not condition:
        raise AssertionError(reason)


def wire(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def stream_pin(stream):
    size, digest = 0, hashlib.sha256()
    for block in iter(lambda: stream.read(1048576), b''):
        size += len(block)
        digest.update(block)
    return dict(bytes=size, sha256=digest.hexdigest())


def pin(path):
    with path.open('rb') as stream:
        return stream_pin(stream)


def relative(name):
    need(type(name) is str and name and '\\' not in name and '\0' not in name, 'RELATIVE_PATH_TEXT')
    value = PurePosixPath(name)
    need(not value.is_absolute() and all(p not in ('', '.', '..') for p in value.parts)
         and value.as_posix() == name, 'CANONICAL_RELATIVE_PATH:' + name)
    return name


def local(name):
    path = ROOT / relative(name)
    need(not path.is_symlink() and path.resolve().is_relative_to(ROOT), 'TASK_CONTAINMENT:' + name)
    return path


def reference(name):
    return dict(path=name, **pin(local(name)))


def exact(reference_value):
    need(type(reference_value) is dict and {'path', 'bytes', 'sha256'} <= set(reference_value), 'FILE_REFERENCE')
    need(type(reference_value['bytes']) is int and reference_value['bytes'] >= 0, 'NATIVE_FILE_SIZE')
    need(type(reference_value.get('complete_json', True)) is bool, 'CAPTURE_COMPLETENESS_TYPE')
    need(wire(pin(local(reference_value['path']))) == wire({k: reference_value[k] for k in ('bytes', 'sha256')}),
         'EXACT_FILE_BYTES:' + reference_value['path'])


def load(name):
    path = local(name)
    with (gzip.open(path, 'rb') if path.suffix == '.gz' else path.open('rb')) as stream:
        raw = stream.read(CAPTURE + 1)
    need(len(raw) <= CAPTURE, 'JSON_CAPTURE_LIMIT:' + name)
    return json.loads(raw)


def owned(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        need(not path.is_symlink() and path.read_bytes() == raw, 'PRESERVE_DIFFERENT_EXISTING_BYTES:' + str(path))
    else:
        with path.open('xb') as stream:
            stream.write(raw)


def refs_in(value, found=None):
    found = {} if found is None else found
    if type(value) is dict:
        if {'path', 'bytes', 'sha256'} <= set(value) and type(value['path']) is str and not value['path'].startswith('/'):
            exact(value)
            found[value['path']] = {k: value[k] for k in ('path', 'bytes', 'sha256')}
        for child in value.values():
            refs_in(child, found)
    elif type(value) is list:
        for child in value:
            refs_in(child, found)
    return found


def verify_protocol():
    need(pin(local(PROTOCOL)) == PROTOCOL_PIN, 'EXACT_FROZEN_PROTOCOL_BYTES')
    protocol = load(PROTOCOL)
    need(protocol['schema'] == 'Open-offer-memo-protocol-v1'
         and protocol['status'] == 'FROZEN_BEFORE_SCIENTIFIC_IMPORTS', 'CURRENT_FROZEN_PROTOCOL')
    need(local(PROTOCOL).read_bytes() == wire(protocol), 'CANONICAL_PROTOCOL')
    need(protocol['phases'] == list(PHASES), 'EXACT_EIGHT_PHASES')
    admission = load(SOURCE_ADMISSION)
    need(admission['status'] == 'PASS_SOURCE_REVIEW_BEFORE_FREEZE', 'HISTORICAL_SOURCE_ADMISSION')
    names = {SOURCE_ADMISSION} | {r['path'] for r in admission['reviewed']}
    for folder in ('source', 'reference', 'input', 'plan'):
        for p in (ROOT / folder).rglob('*'):
            need(not p.is_symlink(), 'NO_FROZEN_SYMLINK')
            if p.is_file():
                need(p.suffix != '.pyc' and '__pycache__' not in p.parts, 'NO_BYTECODE')
                names.add(p.relative_to(ROOT).as_posix())
    need(len(protocol['files']) == len(names) and {r['path'] for r in protocol['files']} == names, 'EXACT_FROZEN_SET')
    for r in protocol['files']: exact(r)
    runtime = protocol['runtime']; binary = Path(sys.executable).resolve()
    need(runtime['executable'] == dict(path=str(binary), **pin(binary)) and runtime['version'] == sys.version
         and runtime['isolated'] == sys.flags.isolated == 1 and runtime['no_site'] == sys.flags.no_site == 1
         and runtime['dont_write_bytecode'] is sys.dont_write_bytecode is True, 'CURRENT_RUNTIME')
    need(protocol['master']['path'] == str(PRIMARY_MASTER), 'CURRENT_MASTER_PATH')
    need(pin(PRIMARY_MASTER) == {k: protocol['master'][k] for k in ('bytes','sha256')}
         == pin(local('reference/basic-tiling-algorithm.md')), 'CURRENT_MASTER_AND_COPY')
    phases = []
    for name in PHASES:
        records = {}
        for kind in ('started', 'invocation', 'observer'):
            p = 'run/' + name + '/' + kind + '.json'
            if local(p).exists(): records[kind] = load(p)
        result_path = 'data/' + name + '/result.json'
        result = load(result_path) if local(result_path).exists() else None
        available = [records[k] for k in ('started','invocation','observer') if k in records]
        pid = available[0]['pid'] if available else None
        need(all(r['phase'] == name and type(r['pid']) is int and r['pid'] > 0 and r['pid'] == pid for r in available), 'OWNED_PHASE_PID:' + name)
        a,b,c = (records.get(k) for k in ('started','invocation','observer'))
        if a: need(a['protocol'] == reference(PROTOCOL), 'STARTED_PROTOCOL:' + name)
        if c:
            need(c['status'] == 'TERMINAL' and type(c['native_exit_code']) is int, 'ALL_ATTEMPTS_STOPPED:' + name)
            need(c['log'] == reference('run/' + name + '/stdout.log'), 'ACTUAL_LOG:' + name)
        if b and b['result'] is not None:
            need(result is not None and b['result'].get('complete_json') is True, 'COMPLETE_RESULT:' + name)
            exact(b['result']);need({k:b['result'][k] for k in ('path','bytes','sha256')} == reference(result_path), 'RESULT_BYTES:' + name)
            need(b['scientific_status'] == result['status'], 'RESULT_STATUS:' + name)
        clean = bool(a and b and c and result is not None and b['result'] is not None
            and b['status'] == 'COMPLETE' and b['error_type'] is None and c['native_exit_code'] == 0
            and all(c[k] is None for k in ('guard_reason','observer_error','reap_error','postcheck_error'))
            and b['postcheck_error'] is None and b['frozen_postcheck'] == c['frozen_postcheck'] == 'FROZEN_BEFORE_SCIENTIFIC_IMPORTS')
        need(not available or c is not None, 'NO_LIVE_OR_UNOBSERVED_PHASE_AT_CUT:' + name)
        phases.append(dict(name=name,pid=pid,native_exit_code=None if c is None else c['native_exit_code'],
            scientific_status=None if result is None else result['status'],process_clean=clean,
            scientific_admitted=bool(clean and result['status'] == protocol['admitted_statuses'][name])))
    origin=load('input/library-origin-v1.json');exact(origin['file'])
    return dict(protocol=reference(PROTOCOL),frozen_files=len(names),phases=phases,
        library_origin=reference('input/library-origin-v1.json'),
        scope='Eight declared process positions with a shared untrusted fragment library.')


def audit_gates():
    audit=load(TRANSFER_AUDIT)
    need(audit['schema']=='Open-receptor-passive-audit-v1' and audit['status']=='PASS', 'PASS_SAVED_DATA_AUDIT')
    need(audit['protocol']==reference(PROTOCOL),'AUDIT_CURRENT_PROTOCOL')
    exact(audit['report_data'])
    need(audit['report_data']['path']=='data/report-data-v1.json','EXACT_AUDIT_PROJECTION_PATH')
    for r in audit['artifact_pins']:exact(r)
    for r in audit['physical_outputs']:exact(r)
    actual=verify_protocol();rows={p['name']:p for p in audit['phases']}
    need(len(rows)==len(audit['phases'])==len(PHASES) and set(rows)==set(PHASES),'AUDIT_ALL_PHASES')
    for p in actual['phases']:
        for key in ('pid','native_exit_code','scientific_status','process_clean','scientific_admitted'):
            need(wire(rows[p['name']][key])==wire(p[key]),'AUDIT_ACTUAL_PHASE:'+p['name']+':'+key)
    return dict(receipt=reference(TRANSFER_AUDIT),report_data=audit['report_data'],phases=actual['phases'])


def collapsed_archive_region(raw):
    need(raw.count(BEGIN)==1 and raw.count(END)<=1,'ONE_ARCHIVE_MARKER')
    if END not in raw:return raw
    left,tail=raw.split(BEGIN);_,right=tail.split(END)
    return left+BEGIN+right


def verify_report():
    receipt=load(BUILD)
    need(receipt['schema']=='Open-receptor-report-build-v1' and receipt['status']=='BUILT_FROM_ADMITTED_SAVED_DATA','PASSIVE_REPORT_BUILD')
    need(receipt['renderer_source']['path']==BUILDER,'EXACT_RENDERER');exact(receipt['renderer_source'])
    need(receipt['protocol']==reference(PROTOCOL),'BUILD_PROTOCOL')
    need(receipt['saved_data_audit']==reference(TRANSFER_AUDIT),'BUILD_SAVED_AUDIT')
    for r in receipt['artifact_pins']:exact(r)
    audit=load(TRANSFER_AUDIT);exact(audit['report_data']);exact(receipt['source_projection'])
    need(receipt['source_projection']==audit['report_data'],'BUILD_EXACT_AUDITED_PROJECTION')
    need(set(receipt['outputs'])=={'main','data'},'TWO_PUBLIC_OUTPUTS')
    main,data_ref=receipt['outputs']['main'],receipt['outputs']['data']
    need(main['path']=='report/'+MAIN and data_ref['path']=='report/'+DATA,'REPORT_NAMES');exact(data_ref)
    need(local(data_ref['path']).read_bytes()==local(audit['report_data']['path']).read_bytes(),'PUBLIC_DATA_EXACT_AUDITED_PROJECTION')
    data=load(data_ref['path'])
    need(data['schema']=='Open-receptor-report-data-v1' and data['status']=='PASS_SAVED_DATA_PROJECTION','PROJECTION_SCHEMA_STATUS')
    need(data['protocol']==reference(PROTOCOL),'PUBLIC_PROTOCOL')
    need([c['id'] for c in data['cases']]==list(CASES),'PUBLIC_CASE_SET')
    public={p['id']:p for p in data['native_proofs']};admitted={p['id']:p for p in audit['native_proofs']}
    need(len(public)==len(data['native_proofs']) and len(admitted)==len(audit['native_proofs']) and set(public)==set(admitted),'EXACT_NATIVE_PROOF_IDS')
    for key,p in public.items():
        for field in ('role','lines','statement_sha256','selected_sha256','proof_sha256','proof_ref','native_ref'):
            need(wire(p[field])==wire(admitted[key][field]),'PUBLIC_NATIVE_METADATA:'+field)
        need(p['proof_sha256']==sha(wire(p['proof'])) and p['statement_sha256']==sha(wire(p['statement']))
             and p['lines']==len(p['proof']),'PUBLIC_LITERAL_PROOF_HASHES')
        exact(p['proof_ref']);exact(p['native_ref'])
    original=local('publication/rendered-before-archive-links-v1.html')
    before=original.read_bytes() if original.exists() else local(main['path']).read_bytes()
    need(dict(bytes=len(before),sha256=sha(before))=={k:main[k] for k in ('bytes','sha256')},'ORIGINAL_RENDER_PIN')
    current=local(main['path']).read_bytes()
    need(collapsed_archive_region(current)==collapsed_archive_region(before),'ONLY_ARCHIVE_REGION_CHANGED')
    return dict(build=reference(BUILD),renderer_source=receipt['renderer_source'],main_original=main,
        main_current=reference(main['path']),data=data_ref)


def final_readiness():
    protocol,audits,report=verify_protocol(),audit_gates(),verify_report()
    ui=load(UI)
    need(ui['status']=='PASS_STATIC_REPORT_CHECK' and ui['checked_html_structure'] is True
         and ui['checked_proof_and_case_counts'] is True and ui['checked_evidence_links'] is True,
         'FINAL_STATIC_REPORT_CHECK')
    need(ui['source']['path']=='report/'+MAIN,'UI_MAIN_SOURCE');exact(ui['source'])
    root=load(ROOT_ADMISSION)
    need(root['status']=='PASS_REVIEWED_PUBLICATION_WITH_EXPLICIT_SCOPES','ROOT_PUBLICATION_ADMISSION')
    bound=refs_in(root)
    required={PROTOCOL,'report/'+MAIN,'report/'+DATA,BUILDER,AUDITOR,'publication/package_open_v1.py',TRANSFER_AUDIT,UI,BUILD,'publication/check_memo_report_v1.py'}
    need(required<=set(bound),'ROOT_BINDS_FINAL_PUBLICATION_BYTES')
    return dict(protocol=protocol,audits=audits,report=report,static_report=reference(UI),root_admission=reference(ROOT_ADMISSION))


def original_files():
    files = []
    for path in sorted(ROOT.rglob('*')):
        name = path.relative_to(ROOT).as_posix()
        if name.split('/')[0] == 'package':
            continue
        need(not path.is_symlink(), 'NO_ARCHIVE_SYMLINK:' + name)
        if path.is_file():
            files.append(dict(path=relative(name), **pin(path)))
    need(INTERNAL not in {x['path'] for x in files}, 'NO_GENERATED_MANIFEST_COLLISION')
    return files


def estimate(path):
    compressor, count = zlib.compressobj(6, zlib.DEFLATED, -15), 0
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            count += len(compressor.compress(block))
    return count + len(compressor.flush())


def partition(files):
    groups, used = [[]], 0
    for entry in files:
        charge = estimate(local(entry['path'])) + 256 + 4 * len(entry['path'].encode('utf8'))
        need(charge <= MAX_PART - RESERVE, 'SINGLE_MEMBER_EXCEEDS_DECLARED_VOLUME_DESIGN:' + entry['path'])
        if groups[-1] and used + charge > MAX_PART - RESERVE:
            groups.append([])
            used = 0
        groups[-1].append(entry['path'])
        used += charge
    return groups


def part_names(count):
    return [PART_STEM + '%03d.zip' % i for i in range(1, count + 1)]


def set_links(names):
    links = ' · '.join('<a href="' + name + '">Evidence volume ' + str(i) + '</a>'
                       for i, name in enumerate(names, 1))
    block = BEGIN + ('<p>Full approved current-run archive. ' + links +
        ' · <a href="' + MANIFEST + '">Every original path and hash</a>. Download all volumes and extract them together. '
        'The archive retains source, raw results, resource limits and logs. '
        '<a href="' + OLD + '#reader">Prior milestone and its separate full archive</a>.</p>').encode('utf8') + END
    path = local('report/' + MAIN)
    raw = path.read_bytes()
    need(raw.count(BEGIN) == 1 and raw.count(END) <= 1, 'ONE_RENDERER_ARCHIVE_MARKER')
    if END in raw:
        left, tail = raw.split(BEGIN)
        _, right = tail.split(END)
        new = left + block + right
    else:
        new = raw.replace(BEGIN, block, 1)
    if raw != new:
        path.write_bytes(new)


def prepare_links():
    need(not local(PACKAGE_DIR).exists() and not local('publication/prepared-v1.json').exists(), 'ARCHIVE_CUT_IMMUTABLE')
    verify_protocol()
    audit_gates()
    report = verify_report()
    original = local('publication/rendered-before-archive-links-v1.html')
    if not original.exists():
        owned(original, local('report/' + MAIN).read_bytes())
    exact(dict(path='publication/rendered-before-archive-links-v1.html',
               **{k: report['main_original'][k] for k in ('bytes', 'sha256')}))
    owned(local('README-open-offer-memo-20261105-evidence-v1.txt'), README)
    count = 1
    for iteration in range(16):
        names = part_names(count)
        set_links(names)
        groups = partition(original_files())
        print(json.dumps(dict(stage='ARCHIVE_PLAN', iteration=iteration, parts=len(groups))), flush=True)
        if len(groups) == count:
            break
        count = len(groups)
    else:
        raise AssertionError('ARCHIVE_VOLUME_PLAN_DID_NOT_STABILIZE')
    plan = dict(status='ARCHIVE_LINKS_PREPARED', parts=names,
                main=reference('report/' + MAIN), data=reference('report/' + DATA),
                scope='Planning only; final UI/admission must bind these bytes. Package refuses a changed part count.')
    # Replanning before a cut is explicit; preserve any earlier plan first.
    path = local('publication/archive-plan-v1.json')
    if path.exists() and path.read_bytes() != wire(plan):
        old = path.read_bytes()
        owned(local('publication/archive-plan-v1-history-' + sha(old) + '.json'), old)
    path.write_bytes(wire(plan))
    print(json.dumps(dict(status=plan['status'], parts=names, next='Run the final static report check and publication admission before packaging.')), flush=True)


def fresh_remote_base(expected=None):
    response = json.loads(subprocess.check_output([GH, 'api', '--hostname', 'github.com', '--method', 'GET',
        'repos/' + REPO + '/git/ref/heads/main'], timeout=50))
    observed = response['object']['sha']
    need(response['ref'] == 'refs/heads/main' and response['object']['type'] == 'commit'
         and type(observed) is str and len(observed) == 40
         and all(c in '0123456789abcdef' for c in observed), 'OFFICIAL_REMOTE_MAIN_COMMIT')
    need(expected is None or observed == expected, 'FRESH_OFFICIAL_REMOTE_MAIN_CHANGED')
    value = dict(status='FRESH_REMOTE_BASE_CONFIRMED', repository=REPO, base=observed,
                 observed_epoch=time.time(), method='Official GitHub GET git/ref/heads/main', response=response)
    owned(local('publication/remote-base-at-prepare-v1.json'), wire(value))
    return value


def verify_archive(folder, manifest):
    core = {k: v for k, v in manifest.items() if k not in ('inventory_sha256', 'inventory_file', 'inventory_schema')}
    core['schema'] = manifest['inventory_schema']
    core['parts'] = [dict(number=p['number'], name=p['name']) for p in manifest['parts']]
    need(sha(wire(core)) == manifest['inventory_sha256'], 'INTERNAL_INVENTORY_HASH')
    entries = {e['path']: e for e in core['files']}
    need(len(entries) == len(core['files']) == core['original_files']
         and sum(e['bytes'] for e in entries.values()) == core['original_bytes'], 'ALL_ORIGINAL_PATHS_AND_BYTES')
    seen, parts = set(), []
    for number, part in enumerate(manifest['parts'], 1):
        need(part['number'] == number and part['name'] == PART_STEM + '%03d.zip' % number, 'CANONICAL_VOLUME_NAME')
        path = folder / relative(part['name'])
        actual = pin(path)
        need(wire(actual) == wire({k: part[k] for k in ('bytes', 'sha256')})
             and actual['bytes'] <= MAX_PART and actual['bytes'] < 50 * 1024 * 1024, 'VOLUME_BYTES_AND_CEILING')
        expected = {name for name, e in entries.items() if e['part'] == number}
        with zipfile.ZipFile(path) as archive:
            need(len(archive.namelist()) == len(set(archive.namelist()))
                 and set(archive.namelist()) == expected | {INTERNAL}, 'EXACT_VOLUME_MEMBER_SET')
            need(archive.read(INTERNAL) == wire(core) and archive.testzip() is None, 'EVERY_MEMBER_CRC_AND_INVENTORY')
            for name in sorted(expected):
                relative(name)
                entry = entries[name]
                need(name not in seen and archive.getinfo(name).file_size == entry['bytes'], 'PHYSICAL_ONCE_AND_EXACT_SIZE')
                with archive.open(name) as stream:
                    actual_member = stream_pin(stream)
                need(wire(actual_member) == wire({k: entry[k] for k in ('bytes', 'sha256')}), 'EXACT_UNCOMPRESSED_MEMBER:' + name)
                seen.add(name)
        parts.append(dict(number=number, name=part['name'], **actual, CRC='PASS'))
    need(seen == set(entries), 'EVERY_ORIGINAL_PHYSICALLY_VERIFIED')
    return dict(status='PASS', original_files=len(entries), parts=parts,
                all_original_paths_byte_verified=True, all_originals_physically_stored_once=True,
                all_CRC_verified=True, alias_deduplication=False)


def package(base=None):
    need(base is None or type(base) is str and len(base) == 40
         and all(c in '0123456789abcdef' for c in base), 'OPTIONAL_REVIEWED_BASE_SHA')
    for name in (PACKAGE_DIR, 'publication/prepared-v1.json', 'package/index-v1'):
        need(not local(name).exists(), 'PRESERVE_FIRST_PACKAGING_ATTEMPT:' + name)
    readiness = final_readiness()
    plan = load('publication/archive-plan-v1.json')
    need(plan['status'] == 'ARCHIVE_LINKS_PREPARED', 'LINK_PLAN_BEFORE_FINAL_UI')
    exact(plan['main'])
    exact(plan['data'])
    owned(local('README-open-offer-memo-20261105-evidence-v1.txt'), README)
    remote = fresh_remote_base(base)
    base = remote['base']
    env = {k: v for k, v in os.environ.items() if not k.startswith('GIT_')}
    env.update(GIT_INDEX_FILE=str(local('package/index-v1')), GIT_NO_LAZY_FETCH='1',
               GIT_AUTHOR_NAME='Codex', GIT_AUTHOR_EMAIL='codex@openai.com',
               GIT_COMMITTER_NAME='Codex', GIT_COMMITTER_EMAIL='codex@openai.com')
    def git(*args, input=None):
        return subprocess.check_output(['git', '-c', 'core.hooksPath=/dev/null', '-c', 'gc.auto=0',
            '--git-dir=' + GIT, *args], env=env, input=input, timeout=180).decode().strip()
    need(git('rev-parse', '--is-bare-repository') == 'true'
         and git('cat-file', '-t', base) == 'commit', 'EXISTING_ISOLATED_BARE_GIT_AND_BASE')
    master = subprocess.check_output(['git', '--git-dir=' + GIT, 'show',
        base + ':docs/basic-tiling-algorithm.md'], env=env, timeout=180)
    need(master == PRIMARY_MASTER.read_bytes(), 'OFFICIAL_BASE_MASTER_BYTES')
    old = subprocess.check_output(['git', '--git-dir=' + GIT, 'show', base + ':' + PREFIX + OLD], env=env, timeout=180)
    need(old.count(b'</h1>') == 1 and MAIN.encode('ascii') not in old, 'ONLY_ORIGINAL_OLD_READER_BACKLINK')
    backlink = ('<p><a href="' + MAIN + '">Continue with the uncached and memoized '
                'fragment-offer comparison.</a></p>').encode('ascii')
    previous = local('publication/previous-report-with-backlink-v1.html')
    owned(previous, old.replace(b'</h1>', b'</h1>' + backlink, 1))
    files = original_files()
    groups = partition(files)
    names = part_names(len(groups))
    need(names == plan['parts'], 'FINAL_FILES_CHANGED_VOLUME_COUNT_REPEAT_LINKS_AND_UI_BEFORE_CUT')
    current_main = local('report/' + MAIN).read_bytes()
    need(all(name.encode('ascii') in current_main for name in names)
         and MANIFEST.encode('ascii') in current_main, 'ALL_ARCHIVE_VOLUMES_LINKED')
    assignments = {name: number for number, group in enumerate(groups, 1) for name in group}
    entries = [dict(**entry, part=assignments[entry['path']]) for entry in files]
    core = dict(schema='Open-receptor-physical-evidence-inventory-v1',
                original_files=len(entries), original_bytes=sum(e['bytes'] for e in entries), files=entries,
                parts=[dict(number=i, name=name) for i, name in enumerate(names, 1)],
                all_originals_physically_stored=True, alias_deduplication=False, readiness=readiness,
                previous_archive_separately_linked=BASE_URL + PREFIX + OLD,
                exclusions=['package/ generated archive outputs only; all other original paths present at the cut are physical members'],
                postcut_scope='Publication index, prepared commit, push, Pages and live receipts created after this cut are later custody records, not claimed inside their own prior archive.',
                generated_members=[INTERNAL])
    inventory = wire(core)
    need(len(zlib.compress(inventory, 6)) + 65536 < RESERVE, 'INVENTORY_HEADER_RESERVE')
    folder = local(PACKAGE_DIR)
    folder.mkdir(parents=True)
    parts = []
    for number, (name, group) in enumerate(zip(names, groups), 1):
        path = folder / name
        with zipfile.ZipFile(path, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
            for member in group:
                archive.write(local(member), member)
            archive.writestr(INTERNAL, inventory)
        value = pin(path)
        need(value['bytes'] <= MAX_PART and value['bytes'] < 50 * 1024 * 1024, 'ACTUAL_PHYSICAL_VOLUME_CEILING')
        parts.append(dict(number=number, name=name, **value))
        print(json.dumps(dict(stage='VOLUME_WRITTEN', part=number, **value)), flush=True)
    manifest = dict(core, schema='Open-receptor-physical-multipart-evidence-v1',
                    inventory_schema=core['schema'], inventory_file=INTERNAL,
                    inventory_sha256=sha(inventory), parts=parts)
    owned(folder / MANIFEST, wire(manifest))
    verified = verify_archive(folder, manifest)
    owned(folder / 'archive-verification-v1.json', wire(verified))
    for entry in files:
        exact(entry)
    need(wire(original_files()) == wire(files), 'CUT_FILE_SET_AND_ALL_BYTES_UNCHANGED')
    # Read-only network observation is repeated immediately before local Git
    # preparation. It creates no new receipt, so it cannot change the cut.
    current = json.loads(subprocess.check_output([GH, 'api', '--hostname', 'github.com', '--method', 'GET',
        'repos/' + REPO + '/git/ref/heads/main'], timeout=50))
    need(current['ref'] == 'refs/heads/main' and current['object']['type'] == 'commit'
         and current['object']['sha'] == base, 'REMOTE_STILL_EXACT_BASE_BEFORE_COMMIT')
    sources = [(local('report/' + MAIN), PREFIX + MAIN), (local('report/' + DATA), PREFIX + DATA)]
    sources += [(folder / part['name'], PREFIX + part['name']) for part in parts]
    sources += [(folder / MANIFEST, PREFIX + MANIFEST), (previous, PREFIX + OLD)]
    need(len(sources) == len({target for path, target in sources}), 'UNIQUE_TASK_ASSET_PATHS')
    git('read-tree', base)
    assets = []
    for path, target in sources:
        if target != PREFIX + OLD:
            need(not git('ls-tree', '--full-name', base, '--', target), 'NEW_ASSET_COLLISION:' + target)
        value = pin(path)
        need(value['bytes'] < 50 * 1024 * 1024, 'GIT_ASSET_PHYSICAL_SIZE')
        raw = path.read_bytes()
        need(sha(raw) == value['sha256'], 'EXACT_ASSET_READ')
        blob = git('hash-object', '-w', '--stdin', input=raw)
        git('update-index', '--add', '--cacheinfo', '100644', blob, target)
        assets.append(dict(local=path.relative_to(ROOT).as_posix(), path=target, **value,
                           git_blob=blob, url=BASE_URL + target))
    tree = git('write-tree', '--missing-ok')
    commit = git('commit-tree', tree, '-p', base, '-m', 'Publish the memoized fragment-offer comparison')
    need(git('rev-list', '--parents', '-n', '1', commit).split() == [commit, base], 'EXACT_SOLE_PARENT')
    need(git('rev-parse', commit + '^{tree}') == tree, 'EXACT_PREPARED_TREE')
    diff = git('diff-tree', '--no-commit-id', '--no-renames', '--name-status', '-r', base, commit)
    changes = [row.split('\t') for row in diff.splitlines()]
    need(all(len(row) == 2 for row in changes) and len(changes) == len(assets)
         and {name for status, name in changes} == {entry['path'] for entry in assets}
         and all(status == ('M' if name == PREFIX + OLD else 'A') for status, name in changes),
         'TASK_ASSETS_AND_ONE_BACKLINK_ONLY')
    value = dict(status='PREPARED_TASK_ASSETS_ONLY', base=base, tree=tree, commit=commit, assets=assets, diff=diff,
                 archive_manifest=PACKAGE_DIR + '/' + MANIFEST, archive_verification=verified,
                 remote_base_at_cut=remote, remote_base_before_commit=current,
                 readiness=readiness, primary_checkout_staged=False, pushed=False)
    owned(local('publication/prepared-v1.json'), wire(value))
    print(json.dumps(dict(status=value['status'], commit=commit, parent=base,
                          assets=len(assets), volumes=len(parts), original_files=len(files))), flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('base', nargs='?')
    parser.add_argument('--prepare-links', action='store_true')
    args = parser.parse_args()
    if args.prepare_links:
        need(args.base is None, 'PREPARE_LINKS_HAS_NO_COMMIT_BASE')
        prepare_links()
    else:
        package(args.base)


if __name__ == '__main__':
    main()
