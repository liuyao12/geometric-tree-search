"""Thin passive reader builder. No scientific imports, replay or checking.

Root reviews this Source before execution. The independently audited projection
is authoritative; the builder checks physical/metadata joins and renders it.
"""
import hashlib
from html import escape
import re
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
PROTOCOL='protocol/frozen-protocol-v1.json'
INPUT='data/report-data-v1.json'
AUDIT='publication/saved-data-audit-v1.json'
MAIN='report/open-offer-memo-20261105-v1.html'
DATA='report/open-offer-memo-20261105-data-v1.json'
RECEIPT='report/build-receipt-v1.json'
SOURCE='publication/build_open_report_v1.py'
TURTLE='publication/turtle-mark-coverage-v1.json'
TURTLE_CHECK='publication/turtle-mark-coverage-check-v1.json'


def need(ok,why):
    if not ok:raise ValueError(why)


def wire(v):
    return (json.dumps(v,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')


def same(a,b,why):
    need(wire(a)==wire(b),why)


def local(name):
    need(type(name) is str and name and not Path(name).is_absolute() and '..' not in Path(name).parts,'LOCAL_PATH')
    p=ROOT/name;q=p
    while q!=ROOT:
        need(not q.is_symlink(),'NO_SYMLINK');q=q.parent
    need(p.resolve().is_relative_to(ROOT),'CONTAINED_PATH')
    return p


def bytepin(p):
    n=0;h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):n+=len(b);h.update(b)
    return dict(bytes=n,sha256=h.hexdigest())


def ref(name):
    return dict(path=name,**bytepin(local(name)))


def exact(r):
    need(type(r) is dict and {'path','bytes','sha256'}<=set(r),'EXACT_REF')
    same(ref(r['path']),{k:r[k] for k in ('path','bytes','sha256')},'SAVED_PHYSICAL_BYTES')


def read(name):
    with local(name).open(encoding='ascii') as f:return json.load(f)


def artifact(r):
    import gzip
    exact(r);p=local(r['path'])
    with (gzip.open(p,'rt',encoding='ascii') if p.suffix=='.gz' else p.open(encoding='ascii')) as f:v=json.load(f)
    for k in (r.get('pointer') or '').split('/')[1:]:
        k=k.replace('~1','/').replace('~0','~');v=v[int(k)] if type(v) is list else v[k]
    return v


def verify_saved():
    protocol=read(PROTOCOL);audit=read(AUDIT);data=read(INPUT)
    need(protocol['status']=='FROZEN_BEFORE_SCIENTIFIC_IMPORTS','FROZEN_PROTOCOL')
    need(audit['schema']=='Open-receptor-passive-audit-v1' and audit['status']=='PASS','PASS_SAVED_AUDIT')
    need(data['schema']=='Open-receptor-report-data-v1' and data['status']=='PASS_SAVED_DATA_PROJECTION','ADMITTED_PROJECTION')
    same(audit['report_data'],ref(INPUT),'AUDIT_BINDS_PROJECTION_BYTES')
    same(data['protocol'],ref(PROTOCOL),'PROJECTION_CURRENT_PROTOCOL')
    same(audit['protocol'],ref(PROTOCOL),'AUDIT_CURRENT_PROTOCOL')
    same(data['frozen']['limits'],protocol['limits'],'PROJECTED_CURRENT_LIMITS')
    for r in protocol['files']:exact(r)
    admission=read('review/root-source-admission-v1.json')
    need(admission['status']=='PASS_SOURCE_REVIEW_BEFORE_FREEZE','ROOT_SOURCE_ADMISSION')
    files={'review/root-source-admission-v1.json'}
    for folder in ('source','reference','input','plan'):
        for p in local(folder).rglob('*'):
            need(not p.is_symlink(),'NO_FROZEN_SYMLINK')
            if p.is_file():files.add(p.relative_to(ROOT).as_posix())
    for r in admission['reviewed']:exact(r);files.add(r['path'])
    same([ref(n) for n in sorted(files)],protocol['files'],'EXACT_FROZEN_FILE_SET')
    runtime=protocol['runtime'];exe=Path(sys.executable).resolve()
    same(dict(executable=dict(path=str(exe),**bytepin(exe)),version=sys.version,
              isolated=sys.flags.isolated,no_site=sys.flags.no_site,dont_write_bytecode=sys.dont_write_bytecode),
         runtime,'FROZEN_RUNTIME')
    same(bytepin(Path(protocol['master']['path'])),{k:protocol['master'][k] for k in ('bytes','sha256')},'CURRENT_MASTER')
    for r in audit['artifact_pins']:exact(r)
    phases={p['name']:p for p in data['phases']};ap={p['name']:p for p in audit['phases']}
    need(len(phases)==len(data['phases']) and len(ap)==len(audit['phases']),'UNIQUE_PHASES')
    same(sorted(phases),sorted(protocol['phases']),'EXACT_PROTOCOL_PHASES')
    same(sorted(ap),sorted(phases),'AUDITED_PHASE_SET')
    for name,p in phases.items():
        for k in ('pid','native_exit_code','scientific_status','process_clean','scientific_admitted'):
            same(p[k],ap[name][k],'AUDITED_PHASE:'+name+':'+k)
    proofs={p['id']:p for p in data['native_proofs']};audited={p['id']:p for p in audit['native_proofs']}
    need(len(proofs)==len(data['native_proofs']) and len(audited)==len(audit['native_proofs']),'UNIQUE_PROOF_IDS')
    same(sorted(proofs),sorted(audited),'EXACT_NATIVE_PROOF_SET')
    for key,p in proofs.items():
        a=audited[key]
        for k in ('role','lines','statement_sha256','selected_sha256','proof_sha256'):
            same(p[k],a[k],'AUDITED_NATIVE:'+k)
        need(type(p['lines']) is int and p['lines']==len(p['proof']),'WHOLE_PROOF_LINES')
        same(hashlib.sha256(wire(p['proof'])).hexdigest(),p['proof_sha256'],'WHOLE_PROOF_HASH')
        same(hashlib.sha256(wire(p['statement'])).hexdigest(),p['statement_sha256'],'ORIGINAL_STATEMENT_HASH')
        same(hashlib.sha256(wire(sorted(r['id'] for r in p['selected_rows']))).hexdigest(),p['selected_sha256'],'SELECTED_ROWS_IDS')
        for field in ('proof_ref','native_ref'):
            same({k:p[field].get(k) for k in ('path','bytes','sha256','pointer')},
                 {k:a[field].get(k) for k in ('path','bytes','sha256','pointer')},'AUDITED_NATIVE_REF')
        same(artifact(p['proof_ref']),p['proof'],'LITERAL_SAVED_NATIVE_PROOF')
        native=artifact(p['native_ref'])
        need(native['status']=='VERIFIED' and type(native['checked_lines']) is int
             and native['checked_lines']==p['lines'],'WHOLE_NATIVE_RECEIPT')
    for case in data['cases']:
        for method in case['methods']:
            pid=method.get('native_proof_id')
            if pid is not None:
                need(pid in proofs and method['process_admitted'] is True
                     and method['admitted_status']=='VERIFIED_NATIVE_POSITIVE','ONLY_ADMITTED_METHOD_PROOF')
    return data,audit


def build():
    for n in (MAIN,DATA,RECEIPT):need(not local(n).exists(),'EXCLUSIVE_OUTPUT:'+n)
    data,audit=verify_saved();local('report').mkdir(exist_ok=True)
    turtle, check = read(TURTLE), read(TURTLE_CHECK)
    need(check['status'] == 'PASS_EXACT_TURTLE_MARK_COVERAGE'
         and check['counts'] == turtle['counts']
         and check['record'] == bytepin(local(TURTLE)), 'CHECKED_TURTLE_COVERAGE')
    local(DATA).open('xb').write(wire(data))
    local(MAIN).open('xb').write(page(data, check).encode('utf-8'))
    result=dict(schema='Open-receptor-report-build-v1',status='BUILT_FROM_ADMITTED_SAVED_DATA',
        protocol=ref(PROTOCOL),source_projection=ref(INPUT),saved_data_audit=ref(AUDIT),renderer_source=ref(SOURCE),
        outputs=dict(main=ref(MAIN),data=ref(DATA)),artifact_pins=audit['artifact_pins'],
        turtle_coverage=[ref(TURTLE),ref(TURTLE_CHECK)],
        counts=dict(cases=len(data['cases']),proofs=len(data['native_proofs'])))
    local(RECEIPT).open('xb').write(wire(result));print(json.dumps(result,sort_keys=True))


LABELS = {'open-fragments': 'Uncached', 'memoized': 'Memoized'}
CASES = {'unary-transfer': 'Unary transfer', 'chained-equality': 'Nested addition'}
SYMBOLS = {'qmtx': 'x', 'qmtzero': '0', 'qmtS': 'S', 'qmtH': 'H', 'qmtadd': 'add'}
CONNECTIVES = {'imp': r'\Rightarrow', 'and': r'\land', 'or': r'\lor'}

def symbol(name):
    name = SYMBOLS.get(name, name)
    need(re.fullmatch(r'[A-Za-z0-9_]+', name), 'NATIVE_DISPLAY_NAME')
    return name.replace('_', r'\_')


def term(tree):
    if tree[0] == 'var':
        return symbol(tree[1])
    need(tree[0] == 'fun', 'NATIVE_DISPLAY_TERM')
    name = symbol(tree[1])
    if len(name) > 1:
        name = r'\operatorname{' + name + '}'
    return name + ('(' + ','.join(map(term, tree[2])) + ')' if tree[2] else '')


def formula(tree):
    kind = tree[0]
    if kind == 'eq':
        return term(tree[1]) + '=' + term(tree[2])
    if kind == 'all':
        return r'\forall ' + symbol(tree[1]) + r'\,(' + formula(tree[2]) + ')'
    if kind in CONNECTIVES:
        return '(' + formula(tree[1]) + ' ' + CONNECTIVES[kind] + ' ' + formula(tree[2]) + ')'
    if kind == 'not':
        return r'\neg ' + formula(tree[1])
    if kind == 'bot':
        return r'\bot'
    need(kind == 'pred', 'NATIVE_DISPLAY_FORMULA')
    return r'\operatorname{' + symbol(tree[1]) + '}(' + ','.join(map(term, tree[2])) + ')'


def math(expression):
    return r'\(' + escape(expression) + r'\)'


def explanation(line):
    rule = line['rule']
    if rule == 'mp':
        return f"Apply the implication on line {line['implication']+1} to line {line['antecedent']+1}."
    if rule == 'generalize':
        return f"Quantify the variable in line {line['source']+1}."
    descriptions = {
        'axiom': 'Use the stated hypothesis.',
        'instantiate': 'Use the universal instantiation schema.',
        'eq_subst': 'Use substitution of equals in a formula.',
        'refl': 'Use equality reflexivity.',
        'distribute': 'Use the quantified distribution schema.',
        'tautology': 'Use a checked propositional tautology.',
    }
    return descriptions[rule]


def display_number(value):
    if value is None:
        return '—'
    return f'{value:,}' if type(value) is int else f'{value:.3f}'


def table(headers, rows):
    heading = ''.join(f'<th scope="col">{escape(title)}</th>' for title in headers)
    body = ''.join('<tr>' + ''.join(f'<td>{value}</td>' for value in row) + '</tr>' for row in rows)
    return f'<div class="scroll"><table><thead><tr>{heading}</tr></thead><tbody>{body}</tbody></table></div>'


def chart(label, values, unit):
    ceiling = max((value for value in values if value is not None), default=1) or 1
    rows = []
    for method, value in zip(LABELS, values):
        width = 100 * (value or 0) / ceiling
        rows.append(f'<div class="bar-row"><span>{LABELS[method]}</span>'
                    f'<div class="track"><div class="bar {method}" style="width:{width:.4f}%"></div></div>'
                    f'<strong>{display_number(value)} {unit}</strong></div>')
    return '<figure><figcaption>' + escape(label) + '</figcaption>' + ''.join(rows) + '</figure>'


def case_section(case, phases):
    methods = case['methods']
    fresh, process, matching = [], [], []
    rows = []
    for method in methods:
        counts = (method.get('policy') or {}).get('counts', {})
        elapsed = phases[method['phase']]['costs']['observed_process_seconds']
        fresh.append(counts.get('fresh_queries'))
        process.append(elapsed)
        matching.append(counts.get('fresh_seconds'))
        status = method['admitted_status']
        if method.get('reason') and status != 'VERIFIED_NATIVE_POSITIVE':
            status += ' / ' + method['reason']
        values = [
            LABELS[method['method']], status, method['stats'].get('branches'),
            counts.get('proposals'), counts.get('fresh_queries'), counts.get('offer_memo_hits'),
            counts.get('work_stop_memo_hits'), counts.get('proposal_seconds'),
            method['stats'].get('elapsed_seconds'), elapsed,
        ]
        rows.append([escape(value) if isinstance(value, str) else display_number(value) for value in values])
    comparison = case['comparison']
    if comparison['literal_emitted_stream_equal']:
        trace = 'The complete emitted event streams have identical digests and lengths.'
    else:
        trace = ('The saved traces share ' + display_number(comparison['common_retained_event_prefix'])
                 + ' initial events. The archive retains the full observed traces.')
        if comparison['common_retained_event_prefix'] == comparison['retained_event_lengths'][0]:
            trace += ' The entire saved uncached trace is a prefix of the memoized trace.'
    if comparison['literal_native_proof_equal']:
        trace += ' The two independently admitted native proofs have the same digest.'
    headers = ['Method', 'Proof outcome', 'Branches', 'Logical queries', 'Fresh calls', 'Offer hits',
               'Work-limit hits', 'Offer time (s)', 'Search time (s)', 'Process time (s)']
    return (f'<section><h2>{CASES[case["id"]]}</h2>'
            f'<p class="formula">{math(formula(case["declaration"]["problem"]["goal"]))}</p>'
            + table(headers, rows) + '<div class="charts">'
            + chart('Fresh matcher calls', fresh, 'calls')
            + chart('Fresh matching time', matching, 's')
            + chart('Whole method process', process, 's')
            + '</div><p class="note">' + escape(trace) + '</p></section>')


def proof_section(proof):
    case, method = proof['id'].split('--', 1)
    cards = []
    for slot in proof['slots']:
        line = slot['native_line_index_or_null']
        line_label = f'Line {line+1}' if line is not None else 'Padding'
        active = slot['active']
        kind = json.loads(slot['cid'])[1]
        cards.append(f'<div class="tile"><strong>Slot {slot["slot"]+1}</strong>'
                     f'<span>{escape(kind)} · {line_label}</span>'
                     f'<span class="activity">Activity {active}</span>'
                     f'<span class="fid">Formula ID {slot["formula_id"]}</span></div>')
    rows = []
    for index, line in enumerate(proof['proof'], 1):
        rows.append([str(index), math(formula(line['formula'])), escape(explanation(line))])
    return (f'<details><summary>{CASES[case]} · {LABELS[method]} · {proof["lines"]} checked lines</summary>'
            + '<div class="tile-grid">' + ''.join(cards) + '</div>'
            + table(['Line', 'Formula', 'Reason'], rows) + '</details>')


def turtle_section(check):
    counts = check['counts']
    return f'''<section id="turtle"><h2>Turtle marking coverage</h2>
<p>A separate audit enumerated all {check['conflicting_attachments']:,} rooted relative placements
with a disagreement in the saved learned marking. The original point capacities already
forbid {counts['already_capacity_illegal']:,}. The saved finite corona catalogue labels
{counts['label_NEGATIVE']:,} others negative. The remaining {counts['uncovered_mark_only']:,}
are capacity-compatible placements outside that catalogue.</p>
<p>Those placements require additional evidence before the full marking can be used
as a redundant pruning constraint. The archive includes the exact offsets, the four
saved inputs and a standalone checker for the enumeration.</p>
<p><a href="../turtle/corona-evidence-v1.html">Earlier Turtle corona experiment</a></p></section>'''


def page(data, turtle):
    phases = {p['name']: p for p in data['phases']}
    cases = ''.join(case_section(case, phases) for case in data['cases'])
    proofs = ''.join(proof_section(proof) for proof in data['native_proofs'])
    if not proofs:
        proofs = '<p>The proof reader has no admitted certificates for this run.</p>'
    return (START + cases + '<section id="reader"><h2>Checked proof lines and markings</h2>'
            '<p class="note">Each card is one slot. Color separates the activity and formula ID marking layers.</p>'
            + proofs + '</section>' + turtle_section(turtle) + END)


START = r'''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Caching local proof fragments</title>
<script>window.MathJax={tex:{inlineMath:[['\\(','\\)']]}};</script>
<script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js"></script>
<style>
:root{color-scheme:light;--ink:#183734;--rule:#c8d9d1;--green:#176d64;--paper:#f6f5ed}
*{box-sizing:border-box}
body{margin:0;background:var(--paper);color:var(--ink);font:16px/1.55 system-ui,sans-serif}
main{max-width:1140px;padding:24px;margin:auto}
header{max-width:850px;padding:26px 0}
h1{font:clamp(2.2rem,5vw,4rem)/1.06 Georgia,serif;margin:.55em 0 .4em}
h2{font:1.8rem/1.15 Georgia,serif;margin:0 0 .6em}
a{color:var(--green)}
section{background:#fffefa;border:1px solid var(--rule);border-radius:12px;padding:22px;margin:18px 0}
.eyebrow{font-size:.8rem;letter-spacing:.12em;text-transform:uppercase;color:var(--green)}
.scroll,.formula{overflow-x:auto}
table{width:100%;border-collapse:collapse;font-size:.9rem}
td,th{border-bottom:1px solid var(--rule);text-align:left;vertical-align:top;padding:8px}
th{color:#3d6661}
.charts{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(250px,100%),1fr));gap:12px}
figure{margin:16px 0;padding:12px;background:#edf4ef;border-radius:8px}
figcaption{font-weight:700;margin-bottom:6px}
.bar-row{display:grid;grid-template-columns:78px 1fr 78px;align-items:center;gap:6px;font-size:.8rem;margin:.35em 0}
.track{background:#dbe7e1;border-radius:3px;height:12px}
.bar{height:100%;border-radius:3px;background:#966a39}
.bar.memoized{background:var(--green)}
.note{font-size:.88rem;color:#48665e}
details{border-top:1px solid var(--rule);padding:10px 0}
summary{cursor:pointer;font-weight:650}
.tile-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(85px,1fr));gap:8px;margin:12px 0}
.tile{display:flex;flex-direction:column;gap:3px;background:#f4f7f5;border:1px solid var(--rule);border-radius:6px;padding:5px;font-size:.8rem}
.activity{background:#fff0d0;color:#6f450d}
.fid{background:#eee4fb;color:#573581}
</style>
</head>
<body><main>
<header><p class="eyebrow">GCTS research · arithmetic proof search</p>
<h1>Caching local proof fragments</h1>
<p>Both arms search the same rank-marked inventories with the same fragment library.
The cache reuses a local offer packet within one process. Each candidate still
goes through admission and a check against the current search state.</p>
<p><a href="open-receptor-composition-20261104-v1.html#reader">Prior experiment and fragment diagrams</a>
 · <a href="#reader">Proof lines</a> · <a href="#turtle">Turtle marking</a>
 · <a href="#evidence">Evidence</a></p></header>
'''

END = r'''<section id="evidence"><h2>Experiment records</h2>
<p>These are single method processes for two finite arithmetic statements.
Offer time includes fresh matching and cache lookups. This comparison isolates
memoization with the same geometric search and local offer policy in both arms.
The method process also includes model loading, event verification and final proof checks.
Common catalogue preparation and materialization have their own phase records.
A timed-out search supplies an observed prefix. The previous experiment gives
the conventional prover comparisons.</p>
<p><a href="open-offer-memo-20261105-data-v1.json">Audited data, exact native proofs and phase records</a></p>
<!-- OPEN_OFFER_MEMO_ARCHIVE_LINK -->
</section>
</main></body></html>
'''


if __name__ == '__main__':
    build()
