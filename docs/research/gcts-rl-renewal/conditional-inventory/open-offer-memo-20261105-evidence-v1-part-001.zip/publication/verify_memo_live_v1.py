"""Verify deployed reader assets and their archive against the prepared bytes."""
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[1]
PREPARED = ROOT / 'publication/prepared-v1.json'
PACKAGER = ROOT / 'publication/package_open_v1.py'
PACKAGER_SHA = 'd10fd595e94a067033ab447ea05bfb364cdd189645586f64ce516e5ebfee34ca'
PAGES = ROOT / 'publication/pages-state-final-v1.json'
BASE_URL = 'https://liuyao12.github.io/geometric-tree-search/'
DESTINATION = ROOT / 'publication/live-v1'


def file_pin(path):
    digest = hashlib.sha256()
    size = 0
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            size += len(block)
            digest.update(block)
    return {'bytes': size, 'sha256': digest.hexdigest()}


def main():
    if file_pin(PACKAGER)['sha256'] != PACKAGER_SHA:
        raise RuntimeError('Reviewed archive verifier changed')
    prepared = json.loads(PREPARED.read_bytes())
    commit = prepared['commit']
    pages = json.loads(PAGES.read_bytes())
    if (prepared['status'] != 'PREPARED_TASK_ASSETS_ONLY'
            or pages['headSha'] != commit or pages['status'] != 'completed'
            or pages['conclusion'] != 'success' or len(commit) != 40
            or any(c not in '0123456789abcdef' for c in commit)):
        raise RuntimeError('Exact Pages commit has not succeeded')
    if ({j['name'] for j in pages['jobs']} != {'build', 'report-build-status', 'deploy'}
            or any(j['status'] != 'completed' or j['conclusion'] != 'success' for j in pages['jobs'])):
        raise RuntimeError('Incomplete Pages job set')
    DESTINATION.mkdir()
    records = []
    for asset in prepared['assets']:
        name = Path(asset['path']).name
        url = BASE_URL + asset['path']
        if asset['url'] != url or not asset['path'].startswith('docs/research/gcts-rl-renewal/conditional-inventory/'):
            raise RuntimeError('Unexpected asset destination')
        body = DESTINATION / name
        headers = DESTINATION / (name + '.headers')
        query_url = url + '?v=' + commit[:12]
        response = subprocess.run([
            '/usr/bin/curl', '--silent', '--show-error', '--fail', '--http1.1',
            '--proto', '=https', '--connect-timeout', '15', '--max-time', '90',
            '--max-filesize', '52428800', '--header', 'Accept-Encoding: identity',
            '--dump-header', str(headers), '--output', str(body), '--write-out', '%{http_code}', query_url,
        ], capture_output=True, text=True, timeout=100)
        observed = {'path': asset['path'], 'url': query_url, 'http_status': response.stdout,
                    'native_exit_code': response.returncode, 'error': response.stderr,
                    'headers': file_pin(headers) if headers.exists() else None,
                    'body': file_pin(body) if body.exists() else None}
        records.append(observed)
        (DESTINATION / 'asset-observations.json').write_text(json.dumps(records, indent=2) + '\n')
        expected = {key: asset[key] for key in ('bytes', 'sha256')}
        if response.returncode or response.stdout != '200' or observed['body'] != expected:
            raise RuntimeError('Live asset mismatch: ' + name)
    spec = importlib.util.spec_from_file_location('reviewed_passive_packager', PACKAGER)
    archive_verifier = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(archive_verifier)
    manifest = json.loads((DESTINATION / Path(prepared['archive_manifest']).name).read_bytes())
    archive = archive_verifier.verify_archive(DESTINATION, manifest)
    if archive != prepared['archive_verification']:
        raise RuntimeError('Live archive verification mismatch')
    receipt = {'status': 'PASS_ALL_PREPARED_LIVE_BYTES_AND_ARCHIVE_ORIGINALS',
               'commit': commit, 'prepared': file_pin(PREPARED), 'assets': records, 'archive': archive}
    with (DESTINATION / 'receipt-v1.json').open('x') as stream:
        json.dump(receipt, stream, sort_keys=True, separators=(',', ':'))
        stream.write('\n')
    print(json.dumps({'status': receipt['status'], 'commit': commit,
                      'assets': len(records), 'archive_original_files': archive['original_files']}))


if __name__ == '__main__':
    main()
