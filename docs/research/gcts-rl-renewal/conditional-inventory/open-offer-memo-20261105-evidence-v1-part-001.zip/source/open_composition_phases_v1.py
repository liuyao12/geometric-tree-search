"""Prospective partial-fragment experiment, inert until the frozen worker.

The materialization child alone loads whole old templates. Method workers
receive only erased fragments; no old proof or target proof is consulted.
"""
import copy
import hashlib
import time


def need(ok, reason):
    if not ok:
        raise ValueError(reason)


class CaseContext:
    def __init__(self, ctx, case):
        self.parent, self.case = ctx, case
        self.root, self.mods, self.limits = ctx.root, ctx.mods, ctx.limits
        self.sha, self.wire = ctx.sha, ctx.wire

    def mapped(self, name):
        if name == 'input/arithmetic-declaration-v1.json':
            return 'input/case-' + self.case + '-v1.json'
        if name.startswith(('data/prepare/', 'data/rank/')):
            return 'data/cases/' + self.case + '/' + name[5:]
        return name

    def read(self, name):
        return self.parent.read(self.mapped(name))

    def save(self, name, value):
        return self.parent.save(self.mapped(name), value)


def referenced(ctx, ref):
    return ctx.mods['D'].read_ref(ctx, ref)


def qualify(ctx):
    old = ctx.mods['K'].run(ctx)
    refs = dict(original=ctx.save('data/qualify/existing.json.gz', old))
    need(old['status'] == 'QUALIFIED', 'FRESH_COMPLETE_ENGINE_RANK_QUALIFICATION')
    callbacks = ctx.mods['G'].run(ctx)
    refs['callbacks'] = ctx.save('data/qualify/callbacks.json.gz', callbacks)
    need(callbacks['status'] == 'QUALIFIED', 'FRESH_COMPLETE_ORDER_QUALIFICATION')
    refs['offer_memo'] = ctx.save('data/qualify/offer-memo.json', qualify_offer_memo())
    return dict(status='QUALIFIED', refs=refs,
        counts=dict(old=old.get('original_counts'), rank_actual=old['rank_actual_snapshots']),
        scope='Unchanged point/rank enumeration and actual callback/rollback qualification, fresh under this frozen protocol.')


def materialize(ctx):
    old = ctx.read('input/donor-library.json.gz')
    started = time.perf_counter()
    library = ctx.mods['L'].materialize(old, limits=ctx.limits['family'])
    costs = dict(materialize_seconds=time.perf_counter()-started)
    refs = dict(library=ctx.save('data/materialize/library.json.gz', library))
    answer = dict(status='MATERIALIZATION_RECORDED', library_status=library['status'],
        refs=refs, costs=costs, bounded_absence=False, RL=False,
        scope='Warm candidate data from V5, not an axiom or supplied recipient proof; only proper partial fragments survive. Materialization checks provenance, not universal logical soundness.')
    if library['status'] != 'MATERIALIZED':
        return answer
    started = time.perf_counter()
    receipt = ctx.mods['X'].verify_materialization(old, library, limits=ctx.limits['family'])
    costs['independent_materialize_seconds'] = time.perf_counter()-started
    refs['receipt'] = ctx.save('data/materialize/receipt.json.gz', receipt)
    answer['materialization_status'] = receipt['status']
    if receipt['status'] != 'VERIFIED_MATERIALIZATION':
        return answer
    need(receipt['bindings'] == dict(source_library_sha256=ctx.sha(old),
         library_sha256=ctx.sha(library)), 'EXACT_MATERIALIZATION_RECEIPT_BINDINGS')
    checks = ctx.mods['Y'].run_library(ctx, old, library)
    refs['qualification'] = ctx.save('data/materialize/qualification.json.gz', checks)
    answer['qualification_status'] = checks['status']
    need(checks['status'] == 'QUALIFIED', 'FRAGMENT_LIBRARY_MUTATION_GATE')
    answer['fragment_count'] = len(library['fragments'])
    return answer


def prepare(ctx, case):
    sub = CaseContext(ctx, case)
    preparation = ctx.mods['D'].run('prepare', sub)
    refs = dict(preparation=sub.save('data/prepare/result.json', preparation))
    answer = dict(status='CASE_RECORDED', case=case, refs=refs,
        preparation_status=preparation['status'], rank_status='NOT_ATTEMPTED',
        qualification_status='NOT_ATTEMPTED', bounded_absence=False)
    if preparation['status'] != 'PREPARED':
        return answer
    rank = ctx.mods['H'].rank(sub)
    refs['rank'] = sub.save('data/rank/result.json', rank)
    answer['rank_status'] = rank['status']
    if rank['status'] != 'RANK_ADMITTED':
        return answer
    materialized = ctx.admitted('materialize')
    if (materialized.get('qualification_status') != 'QUALIFIED'
        or materialized.get('materialization_status') != 'VERIFIED_MATERIALIZATION'):
        answer['qualification_status'] = 'UNADMITTED_LIBRARY'
        return answer
    library = referenced(ctx, materialized['refs']['library'])
    prepared, base = ctx.mods['D'].load_prepared(sub)
    del base
    model = referenced(ctx, rank['refs']['marked_model'])
    checks = ctx.mods['Y'].run_instances(ctx, prepared, model, library)
    refs['qualification'] = ctx.save('data/cases/' + case + '/fragment-qualification.json.gz', checks)
    answer['qualification_status'] = checks['status']
    need(checks['status'] == 'QUALIFIED', 'FRAGMENT_INSTANCE_AND_STATE_GATE')
    return answer


class OfferMemo:
    """Cache packets within one fixed proposer, never the current-state verdict."""

    def __init__(self, propose, enabled):
        self.propose = propose
        self.enabled = enabled
        self.entries = {}

    def fetch(self, anchor, charge, query_index):
        charge(1)
        if self.enabled and anchor in self.entries:
            return self.entries[anchor]
        packet = self.propose(anchor, charge=charge)
        work_limited = (packet['status'] == 'UNKNOWN'
                        and packet.get('reason') == 'MAX_WORK'
                        and packet['costs']['work'] > packet['limits']['max_work']
                        and packet['instances'] == [])
        if self.enabled and (packet['status'] == 'CANDIDATE_FRAGMENTS' or work_limited):
            self.entries[anchor] = packet, query_index
        return packet, query_index


def qualify_offer_memo():
    completed = dict(status='CANDIDATE_FRAGMENTS', instances=[{'id': 'one'}])
    work_stop = dict(status='UNKNOWN', reason='MAX_WORK', instances=[],
                     costs={'work': 3}, limits={'max_work': 2})
    wall_stop = dict(work_stop, reason='WALL_SECONDS')
    setup_stop = dict(work_stop, costs={'work': 1})
    packets = dict(completed=completed, work=work_stop, wall=wall_stop, setup=setup_stop)
    calls, units = [], []

    def propose(anchor, charge):
        calls.append(anchor)
        return packets[anchor]

    memo = OfferMemo(propose, True)
    for i, anchor in enumerate(packets):
        packet, origin = memo.fetch(anchor, units.append, 2*i)
        repeated, reused = memo.fetch(anchor, units.append, 2*i+1)
        need(packet == repeated == packets[anchor] and origin == 2*i, 'MEMO_LITERAL_PACKET')
        expected = 2*i if anchor in ('completed', 'work') else 2*i+1
        need(reused == expected, 'MEMO_SCOPE')
    control = OfferMemo(propose, False)
    need(control.fetch('completed', units.append, 8)[1] == 8
         and control.fetch('completed', units.append, 9)[1] == 9, 'UNCACHED_CONTROL')
    need(calls == ['completed', 'work', 'wall', 'wall', 'setup', 'setup', 'completed', 'completed']
         and units == [1]*10, 'MEMO_QUALIFICATION_CALLS')
    return dict(status='QUALIFIED', fresh_calls=calls, lookup_charges=units,
                cached_anchors=sorted(memo.entries), uncached_anchors=sorted(control.entries))


class OpenPolicy:
    def __init__(self, ctx, prepared, model, library, memoize):
        self.ctx = ctx
        start = time.perf_counter()
        self.identity = dict(model_sha256=ctx.sha(model), statement_sha256=ctx.sha(prepared['statement']),
            library_sha256=ctx.sha(library), prepared_scope=prepared['binding']['scope'])
        self.proposer = ctx.mods['L'].LocalProposer(prepared, model, library,
                                                  limits=ctx.limits['family'])
        self.offer_memo = OfferMemo(self.proposer.propose, memoize)
        self.checker = ctx.mods['X'].AdmissionChecker(prepared, model, library,
                                                     limits=ctx.limits['family'])
        self.cached = None
        self.disabled_reason = None
        self.log = []
        self.counts = dict(callbacks=0, proposals=0, candidate_instances=0, admitted=0,
            state_checks=0, compatible=0, cache_hits=0, no_preference=0,
            proposal_seconds=0.0, fresh_queries=0, offer_memo_hits=0, work_stop_memo_hits=0,
            fresh_seconds=0.0, memo_hit_seconds=0.0, admission_seconds=0.0, state_seconds=0.0,
            setup_seconds=time.perf_counter()-start,
            checker_status=self.checker.status, checker_reason=self.checker.reason)

    def digest(self, value, charge):
        encoded = self.ctx.wire(value)
        charge(1 + 2*len(encoded))
        return hashlib.sha256(encoded).hexdigest()

    def compatible(self, instance, request, charge, checked):
        start = time.perf_counter()
        receipt = self.checker.admit(instance)
        self.counts['admission_seconds'] += time.perf_counter()-start
        need(type(receipt.get('work_delta')) is int and receipt['work_delta'] >= 0,
             'EXPLICIT_ADMISSION_WORK_DELTA')
        charge(1 + receipt['work_delta'])
        checked.append(dict(stage='admit', instance_id=instance['id'], receipt=receipt))
        if receipt['status'] != 'VERIFIED_INSTANCE':
            return None
        need(receipt['bindings'] == dict(self.identity, instance_sha256=self.digest(instance, charge),
             fragment_id=instance['fragment_id']), 'EXACT_CURRENT_FRAGMENT_ADMISSION_BINDINGS')
        self.counts['admitted'] += 1
        start = time.perf_counter()
        state = self.checker.check(instance, request, charge)
        self.counts['state_seconds'] += time.perf_counter()-start
        self.counts['state_checks'] += 1
        checked.append(dict(stage='state', instance_id=instance['id'], receipt=state))
        if state['status'] == 'COMPATIBLE':
            union = sorted(set(request['selected']) | {cid for _, cid in instance['line_cids']})
            charge(1 + sum(len(cid) for cid in union))
            need(state['bindings'] == dict(model_sha256=self.identity['model_sha256'],
                instance_sha256=self.digest(instance, charge), selected_sha256=self.digest(request['selected'], charge),
                excluded_sha256=self.digest(request['excluded'], charge), union_sha256=self.digest(union, charge)),
                'EXACT_CURRENT_FRAGMENT_STATE_BINDINGS')
            self.counts['compatible'] += 1
            return state['preferred']
        return None

    def __call__(self, request, charge):
        charge(1 + sum(len(request[k]) for k in ('legal', 'selected', 'excluded')))
        self.counts['callbacks'] += 1
        if self.disabled_reason is not None:
            return []
        if len(self.log) >= 128:
            self.disabled_reason = 'POLICY_PAYLOAD_LOG_CAP_128_COMPLETE_CALLBACKS'
            self.counts['disabled_reason'] = self.disabled_reason
            return []
        checked, proposals, chosen, preferred = [], [], None, None
        if self.cached is not None:
            preferred = self.compatible(self.cached, request, charge, checked)
            if preferred:
                chosen = self.cached
                self.counts['cache_hits'] += 1
        if not preferred:
            self.cached = None
            for anchor in request['legal']:
                if self.counts['proposals'] >= 1024:
                    self.disabled_reason = 'POLICY_OFFER_CAP_1024_QUERIES'
                    self.counts['disabled_reason'] = self.disabled_reason
                    break
                charge(1 + len(anchor))
                start = time.perf_counter()
                query_index = self.counts['proposals']
                packet, origin = self.offer_memo.fetch(anchor, charge, query_index)
                elapsed = time.perf_counter() - start
                self.counts['proposal_seconds'] += elapsed
                self.counts['proposals'] += 1
                if origin == query_index:
                    self.counts['fresh_queries'] += 1
                    self.counts['fresh_seconds'] += elapsed
                else:
                    self.counts['offer_memo_hits'] += 1
                    self.counts['memo_hit_seconds'] += elapsed
                    self.counts['work_stop_memo_hits'] += packet['status'] == 'UNKNOWN'
                proposals.append(dict(anchor=anchor, packet=packet, query_index=query_index,
                                      origin_query_index=origin, elapsed_seconds=elapsed))
                if packet['status'] != 'CANDIDATE_FRAGMENTS':
                    continue
                need(packet['bindings'] == dict(prepared_scope=self.identity['prepared_scope'],
                     model_sha256=self.identity['model_sha256'],
                     library_sha256=self.identity['library_sha256'], anchor_cid=anchor),
                     'EXACT_LOCAL_PROPOSAL_BINDINGS')
                self.counts['candidate_instances'] += len(packet['instances'])
                for instance in packet['instances']:
                    preferred = self.compatible(instance, request, charge, checked)
                    if preferred:
                        chosen = instance
                        break
                if preferred:
                    break
        self.cached = chosen
        if not preferred:
            self.counts['no_preference'] += 1
            preferred = []
        charge(1 + len(checked) + len(proposals) + len(preferred))
        self.log.append(dict(request=copy.deepcopy(request), proposals=proposals,
            checked=checked, chosen=chosen, preferred=preferred))
        return preferred


def evaluate(ctx, case, method):
    admission = ctx.admitted('prepare-' + case)
    answer = dict(status='METHOD_RECORDED', case=case, method=method,
        admitted_status='UNKNOWN', bounded_absence=False, refs={}, costs={}, RL=False)
    if admission['preparation_status'] != 'PREPARED' or admission['rank_status'] != 'RANK_ADMITTED':
        answer['reason'] = 'UNADMITTED_PREPARATION_RANK_OR_FRAGMENT_QUALIFICATION'
        return answer
    if method in ('open-fragments', 'memoized') and admission['qualification_status'] != 'QUALIFIED':
        answer['reason'] = 'UNADMITTED_FRAGMENT_QUALIFICATION; PRIMITIVE_CONTROLS_REMAIN_INDEPENDENT'
        return answer
    start = time.perf_counter()
    sub = CaseContext(ctx, case)
    prepared, base = ctx.mods['D'].load_prepared(sub)
    del base
    rank = referenced(ctx, admission['refs']['rank'])
    model = referenced(ctx, rank['refs']['marked_model'])
    answer['costs']['input_loading_seconds'] = time.perf_counter()-start
    answer['model_sha256'] = ctx.sha(model)
    prefix = 'data/evaluation/' + case + '/' + method
    selected = None
    if method == 'conventional':
        start = time.perf_counter()
        search = ctx.mods['S'].search(prepared, referenced(ctx, rank['refs']['analysis']),
                                     limits=ctx.limits['S'])
        answer['costs']['search_seconds'] = time.perf_counter()-start
        answer['refs']['search'] = ctx.save(prefix + '/search.json.gz', search)
        answer['search_status'] = search['status']
        answer['scope'] = 'Specialized full-catalogue acyclic unique-formula AND/OR planner with same certified rank information; it has no fragment library, so cannot establish a GCTS-specific benefit. Failure is UNKNOWN.'
        if search['status'] == 'FOUND_CANDIDATE':
            selected = search['selected']
    else:
        policy = None
        if method in ('open-fragments', 'memoized'):
            materialized = ctx.admitted('materialize')
            library = referenced(ctx, materialized['refs']['library'])
            policy = OpenPolicy(ctx, prepared, model, library, memoize=method == 'memoized')
        start = time.perf_counter()
        run = ctx.engine('open-' + case + '-' + method, model, order=policy)
        answer['costs']['engine_and_semantic_seconds'] = time.perf_counter()-start
        answer.update(raw_status=run['raw']['status'], semantic_status=run['semantic']['status'],
                      stats=run['raw']['stats'])
        answer['refs'].update(run['refs'])
        if policy is not None:
            answer['policy_counts'] = policy.counts
            answer['refs']['policy_log'] = ctx.save(prefix + '/policy.json.gz', policy.log)
        del policy
        if run['raw']['status'] == 'SAT' and run['semantic']['status'] == 'VERIFIED':
            selected = list(run['raw']['selected'])
        del run
        answer['scope'] = 'One owned method process, same full rank-marked model, unchanged scheduler and complete primitive fallback. Fragment proposals do not solve outside receptors. Semantic replay before releasing raw graphs; exact M/N and native B are separate final gates.'
    del model, rank
    if selected is not None:
        try:
            proof = ctx.mods['D'].decode(ctx, prepared, selected, prefix + '/native')
        except ctx.mods['D'].StopPhase as failure:
            answer.update(admitted_status=failure.status, native_reason=failure.reason,
                          native_refs=failure.refs)
        else:
            answer.update(admitted_status='VERIFIED_NATIVE_POSITIVE',
                          native_lines=len(proof['proof']), native_refs=proof['refs'])
            answer['costs'].update(proof['costs'])
    return answer


def run(phase, ctx):
    start = time.perf_counter()
    if phase == 'qualify':
        result = qualify(ctx)
    elif phase == 'materialize':
        result = materialize(ctx)
    elif phase.startswith('prepare-'):
        result = prepare(ctx, phase[len('prepare-'):])
    else:
        case, method = next((c, m) for c in ('unary-transfer', 'chained-equality')
            for m in ('open-fragments', 'memoized')
            if phase == 'evaluate-' + c + '-' + m)
        result = evaluate(ctx, case, method)
    result.update(schema='Open-fragment-phase-result-v1', phase=phase,
                  module_seconds=time.perf_counter()-start)
    return result
