"""Independent finite-model control, never supplied to the proof searches."""


def evaluate_negative_control(input_document, *, check):
    tests = {item['id']: item for item in input_document['tests']}
    positive = tests['pilot-fork-join-positive']
    negative = tests['pilot-fork-join-missing-Pa']
    if (positive['target'] != negative['target']
            or positive['theory']['functions'] != negative['theory']['functions']
            or positive['theory']['predicates'] != negative['theory']['predicates']):
        raise ValueError('exact positive/negative signature and target required')
    axioms = positive['theory']['axioms'].copy()
    removed = axioms.pop('a3_Pa')
    if axioms != negative['theory']['axioms']:
        raise ValueError('only the declared premise may be removed')

    def term(value, environment):
        check()
        if value[0] == 'var':
            return environment[value[1]]
        if value[0] != 'fun' or len(value[2]) != negative['theory']['functions'][value[1]]:
            raise ValueError('declared finite-model term required')
        for argument in value[2]:
            term(argument, environment)
        return 0

    def formula(value, environment, true_predicates):
        check()
        kind = value[0]
        if kind == 'pred':
            if len(value[2]) != negative['theory']['predicates'][value[1]]:
                raise ValueError('declared finite-model predicate required')
            for argument in value[2]:
                term(argument, environment)
            return value[1] in true_predicates
        if kind == 'all':
            return formula(value[2], dict(environment, **{value[1]: 0}), true_predicates)
        if kind == 'imp':
            return (not formula(value[1], environment, true_predicates)
                    or formula(value[2], environment, true_predicates))
        if kind == 'eq':
            return term(value[1], environment) == term(value[2], environment)
        raise ValueError('control uses only the declared first-order fragment')

    def evaluate(true_predicates, include_removed):
        premises = list(axioms.values()) + ([removed] if include_removed else [])
        return {'premise_truths': [formula(p, {}, true_predicates) for p in premises],
                'goal_truth': formula(negative['target'], {}, true_predicates)}

    base = evaluate(set(), False)
    true_goal = evaluate({'S'}, False)
    added_premise = evaluate(set(), True)
    true_P = evaluate({'P'}, False)
    if not (all(base['premise_truths']) and base['goal_truth'] is False
            and all(true_goal['premise_truths']) and true_goal['goal_truth'] is True
            and not all(added_premise['premise_truths'])
            and not all(true_P['premise_truths'])):
        raise ValueError('countermodel or mutated-model control failed')
    return {'schema': 'independent-one-element-model-control-v1',
            'domain': [0], 'functions': 'all declared functions return0',
            'base': base, 'S_true': true_goal, 'removed_premise_restored': added_premise,
            'P_true': true_P, 'manual_model': True, 'machine_evaluated': True,
            'supplied_to_proof_search': False,
            'scope': 'One explicit finite model for the frozen missing-premise control; '
                     'not an automated model finder or a proof-search result.'}
