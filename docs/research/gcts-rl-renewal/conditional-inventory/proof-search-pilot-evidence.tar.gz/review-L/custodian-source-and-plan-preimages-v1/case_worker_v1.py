"""Child-only research entry for a fresh, declared Native/point pilot case.

All scientific imports, decoding, Native table preparation and searches occur
after the parent has consumed the exact reviewed one-use case grant.
"""
from pathlib import Path
import gzip
import hashlib
import importlib
import importlib.util
import json
import os
import resource
import shutil
import sys
import time
import traceback

PROGRAM_SHA = '877c47879b027b08f02d3923d1e6dd9ccaf9a12e354567109f1aaa640a8fb673'
MICRO_SHA = '2f9e430b0b7034ed615d81c3e9b3978dc47ba4136686227a9b86df5779b203ac'


class RootBudget(RuntimeError):
    pass


def raw_pin(path):
    body = Path(path).read_bytes()
    return {'path': str(Path(path).resolve()), 'bytes': len(body),
            'sha256': hashlib.sha256(body).hexdigest()}


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=False, allow_nan=False).encode('utf8')


def write_complete(path, value, cap):
    body = (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       allow_nan=False, separators=(',', ':'))+'\n').encode()
    if len(body) > cap:
        raise RootBudget('complete result byte limit; no truncated result admitted')
    temporary = path.with_name(path.name+'.partial')
    with temporary.open('xb') as stream:
        stream.write(body)
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)


def main(plan_path, directory, began):
    directory = Path(directory)
    plan_body = Path(plan_path).read_bytes()
    plan = json.loads(plan_body)
    consumed = json.loads((directory/'CONSUMED.json').read_bytes())
    if not (consumed['plan_sha256'] == hashlib.sha256(plan_body).hexdigest()
            and consumed['case_id'] == plan['case_id']
            and directory.resolve() == Path(plan['actual_dir']).resolve()):
        raise ValueError('complete consumed plan/case/actual directory binding')
    limits = plan['limits']
    if sys.platform != 'darwin' or os.getpid() != os.getpgrp():
        raise ValueError('declared Darwin runtime and new owned process group required')
    # RSS is checked during work and conservatively summed at admission.
    # A virtual-address limit would not measure Darwin resident memory.
    resource.setrlimit(resource.RLIMIT_FSIZE, (limits['physical_bytes'], limits['physical_bytes']))
    state = {'case_id': plan['case_id'], 'stage': 'PIN_INTAKE', 'callbacks': 0,
             'first_fault': None, 'stages': [], 'oracle': None}
    deadline = began + limits['work_seconds']
    oracle = None
    scientific_result = None
    external_controls = None
    primary = None
    original_files = plan['files']

    def check():
        if state['first_fault'] is not None:
            raise state['first_fault']
        state['callbacks'] += 1
        if state['callbacks'] > limits['root_callbacks']:
            state['first_fault'] = RootBudget('cumulative Root callback limit')
        elif time.monotonic() >= deadline:
            state['first_fault'] = RootBudget('absolute case work deadline')
        elif resource.getrusage(resource.RUSAGE_SELF).ru_maxrss > limits['memory_bytes']:
            state['first_fault'] = RootBudget('Python high-water memory limit')
        if state['first_fault'] is not None:
            raise state['first_fault']

    def custody_check():
        if state['first_fault'] is not None:
            raise state['first_fault']
        state['callbacks'] += 1
        if state['callbacks'] > limits['root_callbacks']:
            state['first_fault'] = RootBudget('cumulative Root callback limit during custody')
        elif time.monotonic()-began >= limits['custody_seconds']:
            state['first_fault'] = RootBudget('absolute case custody deadline')
        if state['first_fault'] is not None:
            raise state['first_fault']

    def stage(name, operation):
        check()
        state['stage'] = name
        entry = {'name': name, 'began': time.monotonic()-began,
                 'status': 'STARTED'}
        state['stages'].append(entry)
        answer = operation()
        check()
        entry.update(status='COMPLETED', seconds=time.monotonic()-began-entry['began'])
        return answer

    def verify_files():
        for row in original_files:
            if raw_pin(row['path']) != {k: row[k] for k in ('path', 'bytes', 'sha256')}:
                raise ValueError('declared Source/input/runtime changed: '+row['path'])

    try:
        verify_files()
        check()
        runtime = str(Path(plan['runtime_dir']).resolve())
        sys.path.insert(0, runtime)
        modules = {}
        for role, name in plan['modules'].items():
            modules[role] = stage('IMPORT '+name, lambda name=name: importlib.import_module(name))
        transport = stage('IMPORT bounded_request_oracle',
                          lambda: importlib.import_module('bounded_request_oracle'))
        registry = stage('IMPORT semantic_inventory_oracle',
                         lambda: importlib.import_module('semantic_inventory_oracle'))
        binary = stage('IMPORT tape_binary', lambda: importlib.import_module('tape_binary'))
        entry_path = Path(plan['entry_path']).resolve()
        spec = importlib.util.spec_from_file_location('owned_proof_search_pilot', entry_path)
        entry = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = entry
        stage('IMPORT pilot entry', lambda: spec.loader.exec_module(entry))
        native = plan['native']
        template = stage('DECODE fixed template',
            lambda: json.loads(Path(native['template_path']).read_bytes()))
        micro = stage('DECODE fixed microcode',
            lambda: json.loads(gzip.decompress(Path(native['micro_path']).read_bytes())))
        if not (hashlib.sha256(canonical(micro)).hexdigest() == MICRO_SHA
                and hashlib.sha256(canonical(template['program'])).hexdigest() == PROGRAM_SHA
                and template['program_sha256'] == PROGRAM_SHA
                and micro['program_sha256'] == PROGRAM_SHA
                and template['machine']['micro_sha256'] == MICRO_SHA
                and len(micro['rows']) == template['machine']['micro_states']):
            raise ValueError('unchanged complete program/microcode identity')
        native_dir = directory/'native'
        native_dir.mkdir(mode=0o700)
        code = native_dir/'code.bin'
        stage('ENCODE complete fixed Native table', lambda: binary.write_micro(micro, code))
        executable = native_dir/'boundary-oracle'
        shutil.copyfile(native['executable_path'], executable)
        executable.chmod(0o700)
        if raw_pin(executable)['sha256'] != raw_pin(native['executable_path'])['sha256']:
            raise ValueError('exact owned Native executable copy')
        factory = stage('MAKE bounded Native class', lambda: transport.make_request_oracle_factory(
            request_oracle_module=registry, deadline=deadline, tick=check,
            source_guard=custody_check, now=time.monotonic))
        def construct_oracle():
            nonlocal oracle
            oracle = factory(micro, template['cases'][0]['initial'], executable, code, native_dir)
            state['oracle'] = oracle
            return oracle
        stage('START bounded Native oracle', construct_oracle)
        input_document = stage('READ complete pilot input',
            lambda: json.loads(Path(plan['input_path']).read_bytes()))
        control_spec = importlib.util.spec_from_file_location(
            'owned_independent_countermodel', plan['control_path'])
        control = importlib.util.module_from_spec(control_spec)
        sys.modules[control_spec.name] = control
        stage('IMPORT independent finite-model control',
              lambda: control_spec.loader.exec_module(control))
        external_controls = stage('CHECK independent missing-premise model',
            lambda: control.evaluate_negative_control(input_document, check=check))
        scientific_result = stage('RUN complete six-arm case', lambda: entry.run_pilot(
            input_document, case_id=plan['case_id'], check=check,
            limits=plan['experiment_limits'], modules=modules, oracle=oracle))
        check()
    except BaseException as error:
        primary = state['first_fault'] or error
    finally:
        if oracle is not None:
            try:
                oracle.close()
            except BaseException as error:
                if primary is None:
                    primary = state['first_fault'] or error
        try:
            verify_files()
            source_unchanged = True
        except BaseException as error:
            source_unchanged = False
            if primary is None:
                primary = error
    transport_receipt = getattr(primary, 'native_transport_receipt', None) if primary is not None else None
    if oracle is not None:
        try:
            transport_receipt = oracle.transport_receipt()
        except BaseException as error:
            if primary is None:
                primary = error
    python_peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    native_peak = (transport_receipt or {}).get('native_high_water_bytes')
    if primary is None and not (
            transport_receipt and transport_receipt['all_reaped']
            and transport_receipt['closed'] and transport_receipt['native_exit_code'] == 0
            and type(native_peak) is int and python_peak+native_peak < limits['memory_bytes']
            and time.monotonic()-began < limits['positive_seconds']):
        primary = RootBudget('complete Native custody, combined peaks or positive deadline failed')
    receipt = {'schema': 'proof-search-case-worker-v1', 'case_id': plan['case_id'],
        'status': 'COMPLETE' if primary is None else 'FAILED_CASE_NOT_ADMITTED',
        'stages': state['stages'], 'callbacks': state['callbacks'],
        'elapsed_seconds': time.monotonic()-began, 'source_unchanged': source_unchanged,
        'python_peak_bytes': python_peak, 'native_peak_bytes': native_peak,
        'native_transport': transport_receipt,
        'native_queries': oracle.records if oracle is not None else [],
        'scientific_result': scientific_result,
        'independent_external_controls': external_controls,
        'error': None if primary is None else {
            'type': type(primary).__name__, 'message': str(primary),
            'traceback': ''.join(traceback.format_exception(primary))},
        'first_Root_fault': state['first_fault'] is not None,
        'old_qualification_reused': False, 'full_physical_Wang_claim': False,
        'scope': 'New fixed-dependency, nonhostile Native/point case experiment; '
                 'not a whole older qualification or security sandbox.'}
    if primary is None:
        write_complete(directory/'result.json', receipt, limits['result_bytes'])
    else:
        write_complete(directory/'failure.json', receipt, limits['result_bytes'])
    result_path = directory/('result.json' if primary is None else 'failure.json')
    header = {'schema': 'proof-search-case-worker-header-v1',
        'case_id': plan['case_id'], 'status': receipt['status'],
        'callbacks': state['callbacks'], 'seconds': time.monotonic()-began,
        'python_peak_after_output_bytes': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        'native_peak_bytes': native_peak, 'source_unchanged': source_unchanged,
        'native_closed_and_reaped': bool(transport_receipt and transport_receipt['closed']
                                        and transport_receipt['all_reaped']),
        'first_Root_fault': state['first_fault'] is not None,
        'result': raw_pin(result_path)}
    write_complete(directory/'worker-header.json', header, 4194304)
    print(json.dumps({'case_id': plan['case_id'], 'status': receipt['status'],
                      'callbacks': state['callbacks'], 'seconds': time.monotonic()-began}))
    return 0 if primary is None else 2


if __name__ == '__main__':
    if len(sys.argv) != 4:
        raise SystemExit('usage: case_worker_v1.py PLAN ACTUAL_DIR PARENT_MONOTONIC_START')
    raise SystemExit(main(sys.argv[1], sys.argv[2], float(sys.argv[3])))
