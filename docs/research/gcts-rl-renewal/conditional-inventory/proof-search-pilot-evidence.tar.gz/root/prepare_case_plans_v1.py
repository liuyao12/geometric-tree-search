"""Metadata-only plan freeze. No research module is imported or called."""
from pathlib import Path
import ast
import hashlib
import json
import sys

BASE = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-proof-search-pilot-20261020')
PYTHON = Path('/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12').resolve()
RECOVERED = BASE/'implementation-B/recovered/and-support'
RUNTIME = RECOVERED/'complete-runtime-Source'


def pin(path):
    path = path.resolve()
    assert '.partial' not in path.name
    body = path.read_bytes()
    return {'path': str(path), 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}


def save(path, value):
    assert not path.exists(), 'do not overwrite a frozen plan/offer'
    path.write_text(json.dumps(value, sort_keys=True, ensure_ascii=True, indent=2)+'\n')


entry = BASE/'implementation-B'/sys.argv[1]
api_path = BASE/'implementation-B'/sys.argv[2]
api = json.loads(api_path.read_bytes())
assert pin(entry) == api['source']
corpus = BASE/'corpus-L/pilot-inputs-v2.json'
assert pin(corpus) == api['input_pin']
input_document = json.loads(corpus.read_bytes())
assert len(input_document['tests']) == 3 and len(input_document['training']) == 3
modules = {role: Path(name).stem for role, name in api['modules'].items()}
native = dict(template_path=str(RECOVERED/'fixed-native-inputs/proof-boundary-001.json'),
              micro_path=str(RECOVERED/'fixed-native-inputs/proof-boundary-microcode-001.json.gz'),
              executable_path=str(RECOVERED/'Native-runtime/boundary-oracle-v2'))
sources = sorted(RUNTIME.glob('*.py')) + [entry, BASE/'root/run_case_once_v1.py',
    BASE/'root/case_worker_v1.py', BASE/'root/independent_countermodel_v1.py']
files = sources + [corpus, api_path, PYTHON, RECOVERED/'Native-runtime/boundary_oracle.cpp']
files += [Path(p) for p in native.values()]
checks = []
for path in sources:
    tree = ast.parse(path.read_bytes(), filename=str(path))
    compile(tree, str(path), 'exec')
    checks.append({'path': str(path), 'AST_and_unused_compile': True})
rows = [pin(p) for p in sorted(set(files))]
limits = dict(positive_seconds=180, custody_seconds=210, observer_fallback_seconds=225,
              work_seconds=160, memory_bytes=1073741824, physical_bytes=134217728,
              reserved_outer_bytes=9437184, log_bytes=4194304,
              root_callbacks=400000000, result_bytes=50331648)
plans = []
for case in input_document['tests']:
    case_id = case['id']
    actual = BASE/'actual'/case_id
    plan = dict(schema='proof-search-case-once-plan-v1', case_id=case_id,
        actual_dir=str(actual), worker_path=str(BASE/'root/case_worker_v1.py'),
        entry_path=str(entry), control_path=str(BASE/'root/independent_countermodel_v1.py'),
        runtime_dir=str(RUNTIME), modules=modules, native=native,
        input_path=str(corpus), python=pin(PYTHON), files=rows,
        limits=limits, experiment_limits=api['limits'],
        protocol='One separately granted new complete six-arm cold case; all three case outcomes required.',
        authority='No authority from this plan. A separately reviewed exact one-use Root grant is required.',
        trusted_runtime='Exact pinned CPython binary, bundled stdlib/platform loader and fixed declared code; '
                        'nonhostile research runtime, no security-sandbox or whole-OS proof claim.',
        old_qualifications='No old cohort, failed predicate, grant or G0/G1 accounting changed or reused.')
    path = BASE/'root'/('plan-'+case_id+'-v1.json')
    save(path, plan)
    plans.append(pin(path))
offer = dict(schema='proof-search-pilot-whole-prospective-offer-v1',
    plans=plans, files=rows, python=pin(PYTHON),
    source_AST_checks=checks, expected_case_jobs=3, expected_test_arms=18,
    new_scientific_calls=0, new_actuals=0, new_grants=0,
    old_grants_remaining=0, resource_fit='UNMEASURED: finite explicit work/search/output/deadline guards; '
        'actual full resource admission remains required. No guarantee of a completed positive run.',
    scope='New Native/point pilot, not full physical Wang/proof-system acceptance or a repair of old whole-VM qualification.',
    readiness='PENDING_FULL_SOURCE_CORPUS_PROTOCOL_CUSTODIAN_AND_RESOURCE_PREFLIGHT_REVIEWS')
save(BASE/'root/prospective-whole-offer-v1.json', offer)
print(json.dumps({'plans': plans, 'files': len(rows), 'all_source_AST_checks': len(checks),
                  'new_actuals': 0, 'new_grants': 0}))
