"""Package complete saved bytes only; no scientific imports or replay."""
from pathlib import Path
import hashlib
import io
import json
import shutil
import tarfile

B=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-proof-search-pilot-20261020')
D=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-batch-20261020/publisher/docs/research/gcts-rl-renewal/conditional-inventory')

def digest(body): return hashlib.sha256(body).hexdigest()
def pin(p):
    body=p.read_bytes()
    return dict(file=p.name,bytes=len(body),sha256=digest(body))

for source,target in [('review-L/typed-case-resource-custody-review-v1.json','proof-search-pilot-review-L.json')]:
    shutil.copyfile(B/source,D/target)

paths=set()
for folder in ['root','implementation-B','corpus-L','review-C','review-L','actual']:
    for p in (B/folder).rglob('*'):
        if p.is_file() and 'recovered' not in p.relative_to(B).parts:
            paths.add(p)
offer=json.loads((B/'root/prospective-whole-offer-v1.json').read_bytes())
omitted=[]
for row in offer['files']:
    p=Path(row['path'])
    if p==Path(offer['python']['path']):
        omitted.append(dict(pin=row,reason='Declared trusted CPython runtime; binary not redistributed. All research Sources and fixed Native assets are included.'))
    else: paths.add(p)

records=[]; partial=[]; bodies=[]
for p in sorted(paths):
    assert not p.is_symlink()
    body=p.read_bytes()
    record=dict(file=p.relative_to(B).as_posix(),bytes=len(body),sha256=digest(body))
    if '.partial' in p.name:
        partial.append(record)  # Raw metadata only, never parsed or admitted.
    else:
        records.append(record);bodies.append((record['file'],body))
manifest=dict(schema='complete-proof-search-pilot-archive-v1',files=records,
    omitted_trusted_runtime=omitted,partial_raw_metadata_only=partial,
    scientific_calls_during_packaging=0,actual_case_jobs=3,all_case_jobs_resource_failed=True,
    recipient_arms_reached=0,recipient_arms_unreached=18,
    reproduction='Exact consumed plans/grants are historical. A reproduction needs separately reviewed fresh paths/plans/grants; never reuse a consumed grant.')
manifest_body=(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode()
archive=D/'proof-search-pilot-evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=9) as tf:
    for name,body in bodies+[('MANIFEST.json',manifest_body)]:
        entry=tarfile.TarInfo(name);entry.size=len(body);entry.mode=0o644;entry.mtime=0
        tf.addfile(entry,io.BytesIO(body))
with tarfile.open(archive,'r:gz') as tf:
    assert len(tf.getmembers())==len(records)+1
    for record in records:
        body=tf.extractfile(record['file']).read()
        assert len(body)==record['bytes'] and digest(body)==record['sha256']
    assert tf.extractfile('MANIFEST.json').read()==manifest_body
scan=dict(schema='pilot-complete-archive-scan-v1',archive=pin(archive),
    members=len(records)+1,payload_bytes=sum(x['bytes'] for x in records),
    all_complete_members_byte_checked=True,partial_raw_metadata_only=partial,
    omitted_trusted_runtime=omitted)
(B/'root/archive-scan-v1.json').write_text(json.dumps(scan,indent=2,sort_keys=True)+'\n')
owned=sorted(D.glob('proof-search-pilot*'))
owned=[p for p in owned if p.name!='proof-search-pilot-manifest.json']+[D/'reader.html']
pub=dict(schema='proof-search-pilot-publication-manifest-v1',
    source_parent_commit='9ce8626fde64f9d7f17b11e378b91414d6d4a7dc',
    files=[pin(p) for p in owned],archive_scan=scan,
    conclusions='All three case jobs fail memory admission before recipient search. No completed comparison or GCTS/RL advantage.',
    reader_change='One exact712byte task-owned insertion; unchanged prior bytes retained locally and in archive.')
(D/'proof-search-pilot-manifest.json').write_text(json.dumps(pub,sort_keys=True,indent=2)+'\n')
print(json.dumps(scan))
