"""Passive complete-JSON reporting only; imports no research implementation."""
from pathlib import Path
import hashlib
import json

BASE = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-proof-search-pilot-20261020')
DEST = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-batch-20261020/publisher/docs/research/gcts-rl-renewal/conditional-inventory')

def pin(p):
    assert '.partial' not in p.name
    body=p.read_bytes()
    return dict(path=str(p.resolve()), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())

def save(p,d):
    p.write_text(json.dumps(d,ensure_ascii=True,allow_nan=False,sort_keys=True,indent=2)+'\n')

doc=json.loads((BASE/'corpus-L/pilot-inputs-v2.json').read_bytes())
names=['S0','SC','P00','P01','P10','P11']
cases=[]; observations=[]; proofs=[]; totals=[]; evidence=[]
for spec in doc['tests']:
    directory=BASE/'actual'/spec['id']
    terminal=json.loads((directory/'terminal.json').read_bytes())
    header=json.loads((directory/'worker-header.json').read_bytes())
    assert terminal['case_id']==header['case_id']==spec['id']
    assert terminal['process_exit_code']==2
    assert header['status']=='FAILED_CASE_NOT_ADMITTED'
    failure=directory/'failure.json'
    d=json.loads(failure.read_bytes())
    assert header['result']==pin(failure)
    assert d['scientific_result'] is None
    assert d['error']['message']=='Python high-water memory limit'
    failure_stage=('indexed model evidence construction' if 'model_record = indexed_model(model, check)' in d['error']['traceback'] else 'the check immediately after recipient Model construction')
    assert failure_stage=='indexed model evidence construction' or 'compile_case(spec)' in d['error']['traceback']
    qs=d['native_queries']
    training=[q for q in qs if q['purpose']=='pilot_training_whole_primitive']
    essential=[q for q in qs if q['purpose']=='pilot_training_essential_primitive']
    assert len(training)==len(essential)==3
    assert all(q['result']['status']=='accepted' for q in training+essential)
    assert not any(q['purpose'].startswith('pilot_test_') for q in qs)
    assert not any(q['purpose']=='pilot_ground_cluster_admission' for q in qs)
    for index,q in enumerate(training):
        donor=doc['training'][index]
        assert q['request']['theory']==donor['theory']
        assert q['request']['target']==donor['target']
        assert q['request']['proof']==essential[index]['request']['proof']
        observations.append(dict(case_id=spec['id'], donor_id=donor['id'],
            whole_query=q['id'], essential_query=essential[index]['id'],
            primitive_rows=len(q['request']['proof']), accepted=True,
            status='LOGICAL_OBSERVATION_FROM_COMPLETE_FAILED_JOB_NOT_CASE_ADMISSION'))
        if len(cases)==0:
            proofs.append(dict(title=donor['title'],spec=donor,proof=q['request']['proof'],
                status='Automatically searched donor; whole and essential primitive requests Native-accepted. The containing case failed its memory gate. No recipient proof or whole-case qualification is inferred.',
                query_id=q['id'],essential_query=essential[index]['id'],source=pin(failure)))
    peak=terminal['child_usage']['ru_maxrss']
    timing=terminal['known_exit_seconds']
    native_seconds=sum(q['seconds'] for q in qs)
    total=dict(case_id=spec['id'],worker_seconds=d['elapsed_seconds'],
        known_exit_seconds=timing,custodian_seconds=terminal['final_custody_gate_seconds'],
        python_peak_bytes=d['python_peak_bytes'],waited_child_peak_bytes=peak,
        native_peak_bytes=d['native_peak_bytes'],parent_peak_bytes=terminal['parent_usage']['ru_maxrss'],
        root_callbacks=d['callbacks'],native_queries=len(qs),native_query_wall_sum_seconds=native_seconds,failure_stage=failure_stage,
        physical_bytes_before_terminal=terminal['stored_bytes_before_terminal_receipt'],
        parent_exit_code=2,case_accepted=False,arms_reached=0,
        complete_failure_evidence=pin(failure),header=pin(directory/'worker-header.json'),terminal=pin(directory/'terminal.json'))
    totals.append(total)
    cases.append(dict(title=spec['title'],spec=spec,
        outcome='Memory failure during '+failure_stage+'. No arm reached; no recipient proof found or rejected.',
        failure='The case exceeded the unchanged memory allowance before its search arms. It is not admitted. Complete failure evidence and Native query records are retained.',
        metrics=[f'Known child exit: {timing:.3f} s',f'Python peak: {d["python_peak_bytes"]:,} bytes',f'Waited child peak: {peak:,} bytes',f'Native queries: {len(qs)}'],
        arms=[dict(id=a,outcome='UNREACHED — setup memory failure',attempts=None,forced_branches='—',aux_removals=None,cluster_proposals=None,times='—') for a in names],
        control=d['independent_external_controls'],
        cost_notes=[f'The failed cold case reached known child exit in {timing:.6f} seconds; the custodian final receipt clock was {terminal["final_custody_gate_seconds"]:.6f} seconds. This is wasted experimental cost, not a successful proof latency.',
            f'The complete record contains {len(qs)} Native queries; their recorded wall durations sum to {native_seconds:.6f} seconds. This sum excludes Python compilation/model construction and is not the whole pipeline cost.',
            'The exception prevented run_pilot from returning its scientific result. Per-donor search clocks, mined family bodies, tiny diagnostic results, target model, marking certificates and arm clocks are unavailable; they are not reconstructed from implementation intent.',
            'No per-method cold total or amortized speedup can be calculated. Training was physically repeated in each case; no free acquired library is assigned to a method.'],
        marking_notes=['Recipient marking discovery and every search arm were unreached. The target model was not returned. There is no measured recipient candidate-removal count or reusable target tile witness.',
            'No trained RL policy or recipient cluster realization was produced. The preserved Native donor proof checks are logical observations inside a resource-failed experiment.']))

summary=dict(schema='Root-passive-complete-failed-pilot-assessment-v1',
    comparison='INCOMPLETE_THREE_CASE_SETUP_MEMORY_FAILURES',
    cases=totals,logical_observations=observations,
    new_actuals=3,consumed_one_use_grants=3,remaining_one_use_grants=0,
    recipient_arms_reached=0,recipient_arms_unreached=18,
    recipient_proofs=0,trained_RL_policies=0,
    observer=json.loads((BASE/'root/external-tool-observer-v1.json').read_bytes()),
    scientific_result_returned=False,partial_files_parsed=False,
    scope='Passive complete-file field and equality joins only; no research code imports/calls or independent mathematical replay.',
    conclusions=['Three cold donor searches per case left Native-accepted3/5/5line proof requests.',
        'All three jobs fail memory during recipient setup (Model or indexed evidence construction), before markings, grounding or arm launch.',
        'This is concrete feasibility evidence against the current eager representation under these limits, not evidence against theorem provability or the broader GCTS idea.',
        'No successful six-arm comparison, resource-qualified new proof, target search advantage or RL result.'])
save(BASE/'root/passive-actual-assessment-v1.json',summary)
report=dict(schema='gcts-matched-proof-search-pilot-report-v1',
    headline='All three jobs stopped during recipient setup; no six-arm comparison ran.',
    conclusion='The eager point model or its indexed evidence construction exceeded the fixed memory allowance in every case. Automatically searched elementary donor proofs have Native acceptance records, but no recipient arm ran and no GCTS or RL advantage was measured.',
    proof_scope='Three distinct elementary donor proofs are visible below. Each was searched again in all three jobs, with both whole-proof and essential-proof Native checks accepted. These are logical observations from resource-failed jobs; the complete experiment did not pass.',
    cases=cases,proofs=proofs,tiles=[],actual_summary=summary,
    assessment=['Parallel work produced an executed, reproducible feasibility result and independent review. It also exposed an integration bottleneck that source inspection alone could not establish.',
        'There is no current evidence here that GCTS matches or surpasses conventional automated proof search. The methods never reached their recipient searches; numerical speed comparisons would be misleading.',
        'The immediate technical question is whether a compact or lazy exact candidate representation can fit the same frozen targets, grammar, scheduler and limits. Any successor must preserve complete incidence and exact checks; it must be a separately reviewed experiment, preserving these failures.',
        'Root missed the intended one-minute polling cadence in the first two case jobs. All three terminal tool observations were below the external225second fallback, but no hard external watchdog was installed. This observer deviation is preserved; none of the cases is admitted.',
        'Lemma families remain a plausible multiscale interface, but acquisition, applicability, expansion and validation must all be counted. This run does not establish useful recipient reuse.'],
    review_summary='Independent reviewers passed the frozen scientific sources and prospective custodian/plan design within their stated scopes. Runtime evidence has separate admission and review; a source pass did not predict memory fit.')
save(DEST/'proof-search-pilot-data.json',report)
print(json.dumps(dict(cases=len(cases),arms_reached=0,proofs=len(proofs),complete_native_whole_and_essential_observations=len(observations)*2,failed_cold_seconds=sum(x['known_exit_seconds'] for x in totals),data=pin(DEST/'proof-search-pilot-data.json'),assessment=pin(BASE/'root/passive-actual-assessment-v1.json'))))
