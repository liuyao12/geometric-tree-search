GCTS first-order search, milestone U: complete scientific evidence cut.

Contains all fifty original scientific files: six bridge-control files and forty-four first-order-study files. All actual proof streams, certificates, initial/final heaps, selected point models, retained logs, limits, Sources, input-only cases, prospective and saved-data reviews, Root admissions and local browser QA are included. The native runtime executable and operating system are not vendored; the exact runtime identity is in the plans.

One eight-row incidence-language calibration was proved; two rows are unused axiom padding. Seven builds remain UNKNOWN. BFS stopped at its state cap, so no speed advantage is established. Nine actual native-plus-independent certificates include eight qualification certificates. Twenty tiny structural machine-bridge controls do not construct a full C1 Wang palette. No new RL run.

MANIFEST.json binds every origin path, entry, length and SHA256. Sources and execution plans bind the current scientific closure. All scientific once authorities are spent; this archive is evidence, not permission to rerun them. The public source includes an explicitly documented generic huge-integer wall-limit classification edge outside the actual fixed plan. The archive is not a hermetic standalone runtime or a proof of unrestricted FOL completeness.

Archive cut precedes publication. Later publication/TLS authorities, GitHub request/response logs and live-browser verification are retained separately in the durable workspace completion record: embedding their hashes here would create a circular archive/publication dependency. Publication/TLS Sources and their Source peer are included. No primary reader or unrelated repository content is packaged.
