"""Administrative saved JSON/hash/equality/arithmetic joins only; no subject code."""
import collections,gzip,hashlib,json,pathlib,math
U=pathlib.Path('/private/tmp/gcts-first-order-proof-search-20261028-v1'); A=U/'actual/study-001'; D=pathlib.Path('/private/tmp/gcts-B-U-study001-saved-review-v1')
H=lambda b:hashlib.sha256(b).hexdigest()
def canon(x):return (json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False)+'\n').encode()
def color(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False)
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':H(b)}
def pair(xs):
 out={}
 for k,v in xs:
  assert k not in out,('duplicate JSON key',k)
  out[k]=v
 return out
def parse(b):return json.loads(b,object_pairs_hook=pair,parse_constant=lambda x:(_ for _ in()).throw(ValueError(x)))
def get(n):
 p=A/n;b=p.read_bytes();return parse(gzip.decompress(b) if p.suffix=='.gz' else b)
def equal(a,b):return canon(a)==canon(b)
def rawpin(ref):
 assert set(ref)=={'path','bytes','sha256'}
 assert pin(pathlib.Path(ref['path']))==ref,('raw pin',ref['path'])
 return True
W=get('worker-result.json.gz'); O=get('observer-result.json'); P=parse((U/'root/study-once-plan-001.json').read_bytes()); AUTH=parse((U/'root/study-once-authority-001.json').read_bytes())
assert W['status']==O['status']=='COMPLETE' and O['returncode']==0 and O['failure'] is None
assert O['both_streams_EOF'] and O['group_gone'] and O['wait_confirmed'] and O['cleanup_errors']==[]
assert equal(O['worker_terminal'],parse((A/'stdout.bin').read_bytes()))
assert parse((U/'root/study-001-outer-stdout.bin').read_bytes())=={'receipt':pin(A/'observer-result.json'),'status':'COMPLETE'}
assert (A/'stderr.bin').read_bytes()==(U/'root/study-001-outer-stderr.bin').read_bytes()==b''
assert AUTH['authorized'] is True and type(AUTH['uses'])is int and AUTH['uses']==1
assert AUTH['plan']==pin(U/'root/study-once-plan-001.json') and AUTH['python']==P['python'] and AUTH['runner']==P['sources']['runner']
C=parse((U/'root/study-once-authority-001.json.CONSUMED.json').read_bytes()); CC=get('CONSUMED.json')
assert C=={'authority':pin(U/'root/study-once-authority-001.json'),'plan':AUTH['plan'],'status':'SPENT'}
assert CC=={'authority':C['authority'],'consumed':pin(U/'root/study-once-authority-001.json.CONSUMED.json')}
for ref in O['files']:rawpin(ref)
assert set(x['path'] for x in O['files'])==set(str(x) for x in A.iterdir() if x.name!='observer-result.json')
assert O['stored_bytes']==sum(x['bytes'] for x in O['files'])
assert O['stdin_bytes_sent']==P['sources']['runner']['bytes']
for group in ('sources','metadata'):
 for role,ref in P[group].items():rawpin(ref)
rawpin(P['python']);rawpin(P['bootstrap'])
assert O['worker_terminal']['plan']==AUTH['plan'] and O['worker_terminal']['public_calls']==W['outer_public_calls']
assert O['wait4_peak_bytes']==O['worker_terminal']['self_lifetime_peak_bytes']<=P['limits']['rss_bytes']
assert O['whole_observer_seconds']<=P['limits']['observer_seconds'] and O['worker_terminal']['elapsed_seconds']<=P['limits']['worker_seconds']
assert all(x['bytes']<=P['limits']['file_bytes'] for x in O['files']) and len(O['files'])<=P['limits']['max_files'] and O['stored_bytes']<=P['limits']['total_bytes']
assert O['observed_stream_bytes']=={'stderr':0,'stdout':1098}
assert all(O['retained_streams_complete'].values())
artifacts={}; raw_records=[]
for ref in W['artifacts']+[O['worker_terminal']['result']]:
 rawpin(ref['stored']); path=pathlib.Path(ref['stored']['path']);stored=path.read_bytes();raw=gzip.decompress(stored) if ref['encoding']=='gzip-json' else stored
 assert len(raw)==ref['raw_bytes'] and H(raw)==ref['raw_sha256']
 data=parse(raw);assert raw==canon(data),('canonical artifact',path.name)
 assert ref['name'] not in artifacts;artifacts[ref['name']]=data
 raw_records.append({'name':ref['name'],'stored':ref['stored'],'raw_bytes':len(raw),'raw_sha256':H(raw)})
assert equal(artifacts['worker-result'],W)
assert len(artifacts)==40
assert W['profile']==parse((U/'root/prospective-profile-v1.json').read_bytes())
assert W['limits']==parse((U/'root/prospective-study-limits-v1.json').read_bytes())
value_count=0;typecounts=collections.Counter()
def allvalues(x):
 global value_count
 value_count+=1;typecounts[type(x).__name__]+=1
 if type(x)is dict:
  for k,v in x.items():assert type(k)is str;allvalues(v)
 elif type(x)is list:
  for v in x:allvalues(v)
 elif type(x)is float:assert math.isfinite(x)
 else:assert type(x)in(str,int,bool,type(None))
for data in artifacts.values():allvalues(data)
models=[]; events=[]; rollbacks=[]; proof_checks=[]
def selected_join(bundle,ids):
 cs={c['id']:c for c in bundle['model']['candidates']};steps=bundle['steps'];n=bundle['slots'];assert len(ids)==len(set(ids))==n
 totals=collections.Counter();marks={};refs=collections.Counter();rows={}
 for cid in ids:
  c=cs[cid];totals.update(c['t']);s=steps[cid];assert s['slot'] not in rows;rows[s['slot']]=s['line']
  for p,v in c['m']:
   assert p not in marks or marks[p]==v;marks[p]=v;refs[p]+=1
 assert dict(totals)==dict.fromkeys(bundle['model']['required'],1)
 proof=[rows[i] for i in range(n)]
 for i,line in enumerate(proof):
  assert marks['out:'+str(i)]==color(line['formula'])
  if line['rule']=='mp':
   a,b=line['antecedent'],line['implication'];assert type(a)is type(b)is int and 0<=a<i and 0<=b<i
   assert proof[b]['formula']==['imp',proof[a]['formula'],line['formula']]
  elif line['rule']=='generalize':
   s=line['source'];assert type(s)is int and 0<=s<i and line['formula']==['all',line['variable'],proof[s]['formula']]
 assert proof[-1]['formula']==bundle['goal']
 return proof,[[p,marks[p],refs[p]] for p in sorted(marks)],sorted(totals.items())
def model_join(label,bundle,ans):
 model=bundle['model'];n=bundle['slots'];cs={c['id']:c for c in model['candidates']};assert len(cs)==len(model['candidates']) and set(cs)==set(bundle['steps'])
 assert model['required']==['slot:'+str(i) for i in range(n)]
 rowcounts=collections.Counter();marksnum=0;rulecounts=collections.Counter()
 for c in model['candidates']:
  s=bundle['steps'][c['id']];i=s['slot'];line=s['line'];assert type(i)is int and 0<=i<n and c['t']==['slot:'+str(i)]
  expected={'out:'+str(i):color(line['formula'])};rule=line['rule'];rulecounts[rule]+=1;rowcounts[i]+=1
  if s['instance'] is not None:
   ins=bundle['instances'][int(s['instance'][1:])];assert ins['id']==s['instance'] and ins['line']==line
  elif rule=='mp':
   a,b=line['antecedent'],line['implication'];assert type(a)is type(b)is int and 0<=a<i and 0<=b<i
   # Full literal uses come from the saved final-F implication referenced in cid.
   fi=int(c['id'].split(':')[2]);imp=bundle['basis']['formulas'][fi]
   assert imp[0]=='imp' and imp[2]==line['formula']
   for p,v in [('out:'+str(a),color(imp[1])),('out:'+str(b),color(imp))]:assert p not in expected or expected[p]==v;expected[p]=v
  elif rule=='generalize':
   source=line['source'];assert type(source)is int and 0<=source<i and line['formula'][0]=='all' and line['variable']==line['formula'][1]
   expected['out:'+str(source)]=color(line['formula'][2])
  else:raise AssertionError('unrecognized step')
  assert c['m']==[[p,expected[p]] for p in sorted(expected)]
  if i==n-1:assert line['formula']==bundle['goal']
  marksnum+=len(c['m'])
 normalized={'required':sorted(model['required']),'candidates':sorted(model['candidates'],key=lambda x:x['id'])}
 assert H(canon(normalized))==ans['model_sha256']
 e=ans['entry_state'];r=ans['restored_state'];assert equal(e,r) and e['selected']==e['excluded']==e['markings']==[]
 assert e['totals']==[[p,0] for p in sorted(model['required'])] and e['generations']==[[p,0] for p in sorted(model['required'])]
 domains=[[p,sorted(c['id'] for c in cs.values() if c['t']==[p])] for p in sorted(model['required'])]
 forward=[[p,cid,1] for p,ids in domains for cid in ids]
 reverse=[[cid,cs[cid]['t'][0],1] for cid in sorted(cs)]
 assert e['domains']==domains
 # Native graph row shape is saved independently and checked below by exact expansion.
 assert e['forward_incidence']==forward,('forward',label,e['forward_incidence'][:1])
 assert e['reverse_incidence']==reverse,('reverse',label,e['reverse_incidence'][:1])
 assert ans['state_hashes']=={'entry':H(canon(e)),'restored':H(canon(r))}
 assert ans['stats']['candidates']==ans['stats']['initial_edges']==len(cs) and ans['stats']['required_points']==n
 assert ans['stats']['mark_assignments']==ans['stats']['dependency_links']==marksnum
 assert ans['stats']['trail_writes']==ans['stats']['trail_undos']
 assert ans['event_extent']['count']==ans['stats']['events'] and ans['event_extent']['retained']==len(ans['events'])==ans['stats']['retained_events']
 for i,ev in enumerate(ans['events']):
  assert ev['seq']==i and set(ev)=={'seq','kind','data'}
  data=ev['data']
  if ev['kind']=='BRANCH':assert data['ordering']==data['legal']==sorted(data['legal']) and data['generation']==0 and data['policy']=='LEXICAL' and all(cid in cs for cid in data['legal'])
  elif ev['kind']=='PLACED':assert data['candidate']in cs and cs[data['candidate']]['t']==[data['point']] and data['root_generation']==0 and data['tile_generation']==1
  events.append({'model':label,'seq':i,'kind':ev['kind'],'sha256':H(canon(ev))})
 if ans['event_extent']['retained_complete']:
  assert ans['event_extent']['retained']==ans['event_extent']['count'] and H(b''.join(canon(x)for x in ans['events']))==ans['event_extent']['SHA256']
 for row in ans['rollback_records']:
  assert row['equal'] is True and row['expected_sha256']==row['restored_sha256'] and row['from_trail']-row['to_trail']==row['undone']>=0
  rollbacks.append({'model':label,**row})
 assert sum(x['undone'] for x in ans['rollback_records'])==ans['stats']['trail_undos']
 if ans['status']=='SAT':
  proof,markings,totals=selected_join(bundle,ans['selected']);cert=ans['certificate']
  assert cert['selected']==ans['selected'] and cert['markings']==markings and cert['totals']==[list(x)for x in totals] and cert['generations']==[[cid,1]for cid in sorted(ans['selected'])]
 else:assert ans['status']=='UNSAT' and ans['selected']is None and ans['certificate']is None
 models.append({'label':label,'candidates':len(cs),'mark_assignments':marksnum,'row_counts':dict(sorted(rowcounts.items())),'rule_candidate_counts':dict(sorted(rulecounts.items())),'model_sha256':ans['model_sha256'],'entry_sha256':ans['state_hashes']['entry'],'status':ans['status'],'events_full':ans['event_extent']['count'],'events_retained':len(ans['events']),'rollback_records':len(ans['rollback_records']),'stats':ans['stats']})
 return cs
qual=[]
for name in ['given','MP','UI','GEN','finite-negative']:
 q=artifacts['qualification-U-'+name];built=q['build'];bundle=built['bundle'];assert built['status']=='COMPLETE' and built['reason']is None and built['costs']==bundle['costs'] and q['bundle_audit']['status']=='VERIFIED'
 assert all(bundle[k]==q['problem'][k] for k in ('theory','goal','slots','profile'))
 cs=model_join('qualification-'+name,bundle,q['answer'])
 product=1
 for p in bundle['model']['required']:product*=sum(c['t']==[p]for c in cs.values())
 assert product==q['brute']['assignments'] and len(q['brute']['solutions'])==len({tuple(x)for x in q['brute']['solutions']})
 for ids in q['brute']['solutions']:selected_join(bundle,ids)
 sat=bool(q['brute']['solutions']);assert q['answer']['status']==('SAT'if sat else'UNSAT') and q['BFS']['status']==('DERIVABLE'if sat else'NOT_DERIVABLE')
 if sat:
  proof,_,_=selected_join(bundle,q['answer']['selected']);assert sorted(q['answer']['selected'])in q['brute']['solutions']
  assert q['selection_audit']['status']=='VERIFIED' and q['selection_audit']['proof']==q['decoded']['proof']==proof and q['decoded']['status']=='UNVERIFIED_CERTIFICATE' and q['decoded']['target']==bundle['goal']
  assert q['BFS']['shortest_lines']==len(q['BFS']['proof'])<=bundle['slots'] and q['BFS']['proof'][-1]['formula']==bundle['goal']
 else:
  assert q['selection_audit']is q['decoded']is None and q['BFS']['proof']is None and q['BFS']['reason']=='FINITE_BASIS_LINE_EXHAUSTED'
  assert [m['id']for m in q['data_only_mutations']]==['missing-row','wrong-literal','future-reference','duplicate-cover']
  assert all(m['receipt']['status']=='REJECTED'and m['receipt']['proof']is None for m in q['data_only_mutations'])
  assert q['BFS_cap_refusal']['status']=='UNKNOWN'and q['BFS_cap_refusal']['proof']is None and q['BFS_cap_refusal']['counts']['states']==0
 qual.append({'id':q['id'],'slots':bundle['slots'],'candidates':len(cs),'assignments':product,'saved_legal_solutions':len(q['brute']['solutions']),'point_status':q['answer']['status'],'BFS_status':q['BFS']['status'],'BFS_counts':q['BFS']['counts']})
# All eight case/build associations, with no partial bundle promoted into search.
main=[]
for case in W['results']:
 cid=case['id'];input_record=artifacts[cid+'-input'];build=artifacts[cid+'-full-build'];assert input_record==case['problem']
 assert build['status']==case['build_status'] and build['costs']==case['build_costs'] and case['problem']['profile']==W['profile']
 assert build['costs']['work']<=W['limits']['compilation']['max_work']
 if build['status']=='UNKNOWN':
  assert build['bundle']is None and build['reason']==case['build_reason'] and case['point']['status']==case['control']['status']=='NOT_RUN_INCOMPLETE_BUILD'
 else:
  assert build['status']=='COMPLETE' and build['reason']is None and build['bundle']['slots']==case['problem']['slots']
  bundle=build['bundle'];ans=artifacts[cid+'-point-full-result'];cs=model_join(cid,bundle,ans)
  assert len(cs)==case['candidate_count']==1757 and len(bundle['instances'])==case['instance_count']==19
  assert artifacts[cid+'-independent-full-model']['status']=='VERIFIED' and artifacts[cid+'-independent-full-model']['candidates']==len(cs)
  proof,_,_=selected_join(bundle,ans['selected']);decoded=artifacts[cid+'-point-decoded-certificate'];sel=artifacts[cid+'-point-selection-audit'];state=artifacts[cid+'-point-state-audit']
  assert sel['status']==state['status']=='VERIFIED' and sel['proof']==proof==decoded['proof']==case['point']['proof'] and decoded['target']==bundle['goal']
  assert state['certificate']==ans['certificate'] and case['point']['tiles']==[dict(cs[cid],slot=bundle['steps'][cid]['slot'])for cid in ans['selected']] and case['point']['statistics']==ans['stats']
  assert case['point']['event_sha256']==ans['event_extent']['SHA256'] and case['point']['status']==ans['status']=='SAT'
  control=artifacts[cid+'-control-full-result'];assert control['status']==case['control']['status']=='UNKNOWN' and control['reason']=='STATES' and control['counts']['states']==W['limits']['bfs']['max_states'] and control['proof']is None
  assert case['control']['proof']is None and case['control']['tiles']==[] and case['control']['check']is None
  assert equal(artifacts[cid+'-whole-case-result'],case)
 main.append({'id':cid,'slots':case['problem']['slots'],'build_status':build['status'],'reason':build['reason'],'costs':build['costs'],'point_status':case['point']['status'],'control_status':case['control']['status']})
# Native/independent saved receipts and byte stream/heap associations, never re-executed.
for name,data in artifacts.items():
 if not name.endswith('whole-proof-check'):continue
 assert data['status']=='VERIFIED' and data['native']['status']=='accepted' and type(data['native']['value'])is int and data['native']['value']==1
 assert data['independent']['status']=='VERIFIED' and data['independent']['checked_lines']==len(data['proof']) and data['proof'][-1]['formula']==data['goal']
 enc,dec=data['encoding'],data['decoding'];assert enc['status']==dec['status']=='COMPLETE' and enc['proof']is None and dec['stream_hex']is None and dec['proof']==data['proof']
 stream=bytes.fromhex(enc['stream_hex']);assert len(stream)>0 and stream[0]==1 and stream[-1]==17 and dec['offset']==len(stream)
 assert data['choice']['status']=='VERIFIED' and data['choice']['byte_values']==list(stream)
 v=data['carrier']['value'];assert len(v['nodes'])==len(data['initial_nodes']) and v['byte_count']==len(stream)==len(v['byte_rows']) and len(set(v['marker_ids']))==len(stream)
 row_by_index={row['node_index']:row['byte_index']for row in v['byte_rows']}
 for j,(template,chosen)in enumerate(zip(v['nodes'],data['initial_nodes'])):
  assert chosen==([stream[row_by_index[j]],template[1]]if j in row_by_index else template)
 assert data['final_heap'][:len(data['initial_nodes'])]==data['initial_nodes'] and data['native']['heap_nodes']==len(data['final_heap'])
 assert v['known']['target']==data['goal'] and v['known']['theory']==dict(data['theory'],schemas=[])
 assert len(data['native']['trace'])<=W['limits']['native']['max_trace_records'] and data['native']['steps']<=W['limits']['native']['max_steps']
 for i,row in enumerate(v['byte_rows']):
  assert row['byte_index']==i
  assert row['node_id']==row['node_index']+257 and row['marker_id']==v['marker_ids'][i] and row['head_placeholder']==0
  assert row['domain']=={'all_values_allowed':True,'minimum':0,'maximum':255}
 # Raw per-line rule census is a data association to the saved checker receipt.
 rules=collections.Counter(x['rule']for x in data['proof']);assert all(data['independent']['rule_counts'][r]==rules[r] for r in data['independent']['rule_counts'])
 proof_checks.append({'name':name,'lines':len(data['proof']),'bytes':len(stream),'rule_counts':dict(rules),'native_steps':data['native']['steps'],'native_status':data['native']['status'],'B_status':data['independent']['status'],'proof_sha256':H(canon(data['proof']))})
assert len(proof_checks)==9
assert W['qualification']['status']=='PASS' and W['qualification']['counts']=={'BFS':6,'build':5,'data_only_mutations':4,'decode':4,'records':5,'solve':5}
assert len(W['qualification_checks'])==8
for chk in W['qualification_checks']:
 full=artifacts[chk['id']+'-'+chk['lane']+'-whole-proof-check'];assert chk['check']['status']==full['status'] and chk['check']['independent']==full['independent'] and chk['check']['native_steps']==full['native']['steps'] and chk['check']['proof_lines']==len(full['proof']) and chk['check']['proof_bytes']==len(bytes.fromhex(full['encoding']['stream_hex']))
# Twenty current retained bridge controls are data-only inspected; no machine run.
assert len(W['bridge_records'])==20
for row in W['bridge_records']:assert equal(row['input_before'],row['input_after'])
bridge=collections.Counter(r['answer']['status']for r in W['bridge_records'])
summary={'schema':'B-U-study001-complete-passive-support-v1','status':'PASS','method':'Strict saved JSON/gzip/hash/type/equality/arithmetic joins only. No subject module/helper/codec/checker/VM/compiler/solver calls or replay. Brute assignment space is NOT regenerated; its saved complete solution records and cardinality products are associated. Native soundness is inherited from actual authenticated saved checks and reviewed Sources.','observer':pin(A/'observer-result.json'),'worker_stored':pin(A/'worker-result.json.gz'),'actual_physical_files':len(list(A.iterdir())),'actual_physical_bytes':sum(p.stat().st_size for p in A.iterdir()),'observer_named_files':len(O['files']),'observer_named_bytes':O['stored_bytes'],'artifact_records':raw_records,'raw_artifact_bytes':sum(r['raw_bytes']for r in raw_records),'values':value_count,'typecounts':dict(typecounts),'qualification':qual,'main_cases':main,'models':models,'retained_events':events,'rollback_records':rollbacks,'native_checks':proof_checks,'bridge_status_census':dict(bridge),'public_calls':W['outer_public_calls'],'global_costs':{'worker_seconds':O['worker_terminal']['elapsed_seconds'],'observer_seconds':O['whole_observer_seconds'],'child_lifetime_RSS_bytes':O['wait4_peak_bytes']},'limitations':['No proof of completeness beyond supplied finite basis/schema/slots.','Main event log is retained prefix64 of149; full hash is authenticated in-actual Source output, not independently recomputable from omitted events.','Full native traces are prefix8; saved complete receipts, heaps, bytes and independent checks join.','Original tool exit is Root-owned evidence from parent authoritative message; this audit joins saved observer status0/full streams/consume but does not fabricate an absent tool transcript.','No advantage follows from point SAT versus state-capped BFS UNKNOWN; all build refusals remain UNKNOWN.']}
path=D/'complete-passive-saved-study-support-v1.json';raw=canon(summary);path.write_bytes(raw);print(json.dumps({'support':pin(path),'qual':qual,'main':main,'models':[{k:v for k,v in x.items()if k!='stats'}for x in models],'proof_checks':proof_checks,'files':summary['actual_physical_files'],'bytes':summary['actual_physical_bytes'],'values':value_count,'bridge':dict(bridge)},indent=2))
