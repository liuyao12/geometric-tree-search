"""Passive saved bytes and literal record/count joins. No subject code replay."""
import pathlib,json,gzip,hashlib,stat,collections,math
U=pathlib.Path('/private/tmp/gcts-first-order-proof-search-20261028-v1');A=U/'actual/study-001';O=pathlib.Path('/private/tmp/gcts-L-U-complete-saved-cohort-review-v1')
def image(v):return json.dumps(v,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False).encode('ascii')
def sha(b):return hashlib.sha256(b).hexdigest()
def unique(rows):
 d={}
 for k,v in rows:assert k not in d;d[k]=v
 return d
def parse(b):return json.loads(b,object_pairs_hook=unique,parse_constant=lambda x:(_ for _ in ()).throw(AssertionError(x)))
def read(p):return parse(pathlib.Path(p).read_bytes())
def pin(p):
 p=pathlib.Path(p);s=p.lstat();assert stat.S_ISREG(s.st_mode) and not p.is_symlink();b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def match(r):assert pin(r['path'])==r
obs=read(A/'observer-result.json');wt=obs['worker_terminal'];catalog={};objects={}
def artifact(r):
 assert set(r)=={'encoding','name','raw_bytes','raw_sha256','stored'};match(r['stored']);p=pathlib.Path(r['stored']['path']);assert p.parent==A
 b=p.read_bytes();raw=gzip.decompress(b) if r['encoding']=='gzip-json' else b
 assert r['encoding'] in ['json','gzip-json'] and len(raw)==r['raw_bytes'] and sha(raw)==r['raw_sha256']
 v=parse(raw);assert image(v)+b'\n'==raw
 if str(p) in catalog:assert catalog[str(p)]==r
 catalog[str(p)]=r;objects[r['name']]=v;return v
r=artifact(wt['result'])
for z in r['artifacts']:artifact(z)
assert len(r['artifacts'])==39 and len(catalog)==40
files=sorted(A.iterdir());pins=[pin(p) for p in files];idx={x['path']:x for x in pins};assert len(pins)==44 and len(obs['files'])==43
assert set(idx)=={x['path'] for x in obs['files']}|{str(A/'observer-result.json')}
for ref in obs['files']:assert idx[ref['path']]==ref
assert set(idx)-set(catalog)=={str(A/p) for p in ['CONSUMED.json','observer-result.json','stdout.bin','stderr.bin']}
assert sum(x['bytes'] for x in obs['files'])==obs['stored_bytes']==423385
assert sum(x['bytes'] for x in pins)==435290
assert obs['status']=='COMPLETE' and obs['returncode']==0 and obs['failure'] is None and obs['cleanup_errors']==[]
assert all(obs[k] is True for k in ['both_streams_EOF','wait_confirmed','group_gone']) and all(obs['retained_streams_complete'].values())
for x in obs['streams'].values():match(x)
assert (A/'stderr.bin').read_bytes()==b'' and parse((A/'stdout.bin').read_bytes())==wt
assert wt['status']=='COMPLETE' and obs['stdin_bytes_sent']==27722 and obs['wait4_peak_bytes']==50528256<1073741824
assert wt['self_lifetime_peak_bytes']==50528256 and wt['elapsed_seconds']<210 and obs['whole_observer_seconds']<240
plan=read(U/'root/study-once-plan-001.json');guards=[]
for label,ref in [('python',plan['python']),('bootstrap',plan['bootstrap']),*plan['sources'].items(),*plan['metadata'].items()]:match(ref);guards.append({'role':label,'reference':ref})
assert len(guards)==27 and wt['plan']==pin(U/'root/study-once-plan-001.json')
authpath=U/'root/study-once-authority-001.json';auth=read(authpath);spentpath=pathlib.Path(str(authpath)+'.CONSUMED.json');spent=read(spentpath)
assert auth=={'schema':'U-first-order-proof-once-authority-v1','authorized':True,'uses':1,'plan':wt['plan'],'runner':plan['sources']['runner'],'python':plan['python']}
assert type(auth['uses']) is int and type(auth['authorized']) is bool
assert spent=={'authority':pin(authpath),'plan':wt['plan'],'status':'SPENT'}
assert read(A/'CONSUMED.json')=={'authority':pin(authpath),'consumed':pin(spentpath)}
outer=read(U/'root/study-001-outer-stdout.bin');assert outer=={'status':'COMPLETE','receipt':pin(A/'observer-result.json')};assert (U/'root/study-001-outer-stderr.bin').read_bytes()==b''
assert obs['command']==[plan['python']['path'],'-I','-S','-B',plan['bootstrap']['path'],plan['sources']['runner']['path'],'27722',plan['sources']['runner']['sha256'],'--mode','worker','--plan',str(U/'root/study-once-plan-001.json')]
assert len(files)<=384 and max(x['bytes'] for x in pins)<33554432 and sum(x['bytes'] for x in pins)<536870912
cases=read(plan['metadata']['cases']['path']);cal=read(plan['metadata']['calibrations']['path']);design=read(plan['metadata']['design']['path']);limits=read(plan['metadata']['experiment_limits']['path']);profile=read(plan['metadata']['profile']['path'])
assert r['profile']==profile and r['limits']==limits and r['status']=='COMPLETE' and len(r['results'])==8
assert [x['id'] for x in r['results']]==design['order']
priorbridge=read(plan['metadata']['bridge_result']['path']);assert r['bridge_records']==priorbridge['records'] and len(r['bridge_records'])==20
buildreports=[];modelreports=[];solvereports=[];bfsreports=[];qualificationreports=[]
def verify_literal_model(bundle):
 model=bundle['model'];forms=bundle['basis']['formulas'];keys=[image(x).decode() for x in forms];iset={x['id']:x for x in bundle['instances']};ci={x['id']:x for x in model['candidates']};n=bundle['slots'];assert len(ci)==len(model['candidates']) and set(ci)==set(bundle['steps'])
 assert model['required']==['slot:'+str(i) for i in range(n)]
 fset=set(keys);imps=[(i,f) for i,f in enumerate(forms) if len(f)==3 and f[0]=='imp' and image(f[1]).decode() in fset and image(f[2]).decode() in fset];alls=[(i,f) for i,f in enumerate(forms) if len(f)==3 and f[0]=='all' and image(f[2]).decode() in fset]
 target=image(bundle['goal']).decode();expected_total=0;rowcounts=collections.Counter();families=collections.Counter()
 for i in range(n):
  z=sum(i!=n-1 or image(x['line']['formula']).decode()==target for x in iset.values())
  mp=sum(i!=n-1 or image(f[2]).decode()==target for j,f in imps)*i*(i-1)
  gen=sum(i!=n-1 or image(f).decode()==target for j,f in alls)*i
  expected_total+=z+mp+gen
 assert len(ci)==expected_total
 for cid,c in ci.items():
  assert set(c)=={'id','t','m'} and type(cid) is str
  a=cid.split(':');i=int(a[0][1:]);assert a[0]=='r'+str(i) and 0<=i<n and c['t']==['slot:'+str(i)]
  step=bundle['steps'][cid];assert set(step)=={'slot','line','instance'} and step['slot']==i
  line=step['line'];out=image(line['formula']).decode();marks={'out:'+str(i):out}
  if a[1].startswith('i'):
   assert len(a)==2 and step['instance']==a[1] and line==iset[a[1]]['line'];families['zero']+=1
  elif a[1]=='mp':
   assert len(a)==5;fi,aa,bb=map(int,a[2:]);f=forms[fi];assert f[0]=='imp' and type(aa) is type(bb) is int and 0<=aa<i and 0<=bb<i and aa!=bb
   assert line=={'rule':'mp','formula':f[2],'antecedent':aa,'implication':bb} and step['instance'] is None
   marks.update({'out:'+str(aa):image(f[1]).decode(),'out:'+str(bb):image(f).decode()});families['mp']+=1
  else:
   assert a[1]=='gen' and len(a)==4;fi,source=map(int,a[2:]);f=forms[fi];assert f[0]=='all' and 0<=source<i
   assert line=={'rule':'generalize','formula':f,'source':source,'variable':f[1]} and step['instance'] is None
   marks['out:'+str(source)]=image(f[2]).decode();families['generalize']+=1
  assert c['m']==[[p,v] for p,v in sorted(marks.items())] and (i!=n-1 or out==target)
  rowcounts[i]+=1
 return ci,{'candidates':len(ci),'formula_witnesses':len(forms),'zero_witnesses':len(iset),'row_counts':dict(rowcounts),'family_counts':dict(families),'scope':'Every supplied row validated against saved declared basis/native steps, exact closed counts prove no missing/extra valid row IDs. Logical basis generation itself inherits complete Source peers; not rerun.'}
def verify_saved_solver(identity,bundle,s):
 ci,mreport=verify_literal_model(bundle);model=bundle['model'];n=bundle['slots'];norm={'required':model['required'],'candidates':[{'id':c['id'],'t':c['t'],'m':sorted(c['m'])} for c in sorted(model['candidates'],key=lambda x:x['id'])]};assert s['model_sha256']==sha(image(norm)+b'\n')
 entry=s['entry_state'];assert entry is not None and entry==s['restored_state']
 assert set(entry)=={'schema','selected','totals','markings','domains','excluded','forward_incidence','reverse_incidence','generations'}
 assert entry['selected']==entry['excluded']==entry['markings']==[] and entry['totals']==[[p,0] for p in model['required']] and entry['generations']==[[p,0] for p in model['required']]
 domains=[[p,sorted(c['id'] for c in ci.values() if c['t']==[p])] for p in model['required']];assert entry['domains']==domains
 fw=sorted([[p,c['id'],1] for p,ids in domains for c in [ci[cid] for cid in ids]]);rv=sorted([[cid,p,1] for p,ids in domains for cid in ids]);assert entry['forward_incidence']==fw and entry['reverse_incidence']==rv
 h=sha(image(entry)+b'\n');assert s['state_hashes']=={'entry':h,'restored':h}
 stats=s['stats'];assert stats['trail_writes']==stats['trail_undos']==stats['cleanup_operations']
 for rb in s['rollback_records']:
  assert rb['equal'] is True and rb['expected_sha256']==rb['restored_sha256'] and rb['undone']==rb['from_trail']-rb['to_trail']>=0
 assert s['rollback_records'][-1]['reason']=='FINAL_MANDATORY_CLEANUP' and s['rollback_records'][-1]['to_trail']==0
 assert sum(x['undone'] for x in s['rollback_records'])==stats['trail_undos']
 for k,e in enumerate(s['events']):assert set(e)=={'seq','kind','data'} and e['seq']==k
 extent=s['event_extent'];assert len(s['events'])==extent['retained']==stats['retained_events']
 if extent['retained_complete']:
  b=b''.join(image(e)+b'\n' for e in s['events']);assert len(b)==extent['JSONL_bytes'] and sha(b)==extent['SHA256'] and extent['count']==len(s['events'])
 if s['status']=='SAT':
  ids=s['selected'];assert len(set(ids))==len(ids)==n;tot=collections.Counter();marks={};refcnt=collections.Counter();steps={}
  for cid in ids:
   c=ci[cid];tot.update(c['t']);steps[bundle['steps'][cid]['slot']]=bundle['steps'][cid]['line']
   for p,v in c['m']:assert p not in marks or marks[p]==v;marks[p]=v;refcnt[p]+=1
  assert dict(tot)==dict.fromkeys(model['required'],1)
  cert={'selected':ids,'totals':[[p,1] for p in model['required']],'markings':[[p,marks[p],refcnt[p]] for p in sorted(marks)],'generations':[[cid,1] for cid in ids]};assert s['certificate']==cert
  proof=[steps[i] for i in range(n)];assert proof[-1]['formula']==bundle['goal']
  for i,line in enumerate(proof):
   if line['rule']=='axiom':assert line['formula']==bundle['theory']['axioms'][line['name']]
   elif line['rule']=='mp':assert 0<=line['antecedent']<i and 0<=line['implication']<i and proof[line['implication']]['formula']==['imp',proof[line['antecedent']]['formula'],line['formula']]
   elif line['rule']=='generalize':assert 0<=line['source']<i and line['formula']==['all',line['variable'],proof[line['source']]['formula']]
 else:assert s['status']=='UNSAT' and s['selected'] is s['certificate'] is None;proof=None
 modelreports.append({'id':identity,**mreport});solvereports.append({'id':identity,'status':s['status'],'statistics':stats,'rollback_records':len(s['rollback_records']),'all_receipt_undo_sums_joined':True,'full_entry_restored_images':2,'events':extent,'proof_rules':None if proof is None else dict(collections.Counter(x['rule'] for x in proof))})
 return proof
for row in r['results']:
 name=row['id'];problem=dict((cal if name in cal else cases)[name],slots=design['slots'][name],profile=profile);assert row['problem']==problem==objects[name+'-input']
 b=objects[name+'-full-build'];assert b['status']==row['build_status'] and b['costs']==row['build_costs']
 assert b['costs']['work']<=limits['compilation']['max_work'] and b['costs']['formulas']<=limits['compilation']['max_basis'] and b['costs']['candidates']<=limits['compilation']['max_candidates']
 if b['status']=='UNKNOWN':
  assert b['bundle'] is None and b['reason']==row['build_reason'] and b['reason'] in ['WORK_LIMIT','BASIS_LIMIT']
  assert row['point']==row['control']=={'status':'NOT_RUN_INCOMPLETE_BUILD'}
 else:
  assert b['status']=='COMPLETE' and b['reason'] is None and b['bundle']['theory']==problem['theory'] and b['bundle']['goal']==problem['goal'] and b['bundle']['profile']==profile and b['bundle']['slots']==problem['slots']
  s=objects[name+'-point-full-result'];proof=verify_saved_solver(name,b['bundle'],s)
  assert s['status']==row['point']['status']=='SAT' and row['point']['proof']==proof==objects[name+'-point-decoded-certificate']['proof']==objects[name+'-point-selection-audit']['proof']
  assert row['point']['statistics']==s['stats'] and row['point']['event_sha256']==s['event_extent']['SHA256']
  assert row['point']['pipeline_seconds']==row['build_seconds']+row['point']['seconds']
  assert objects[name+'-point-state-audit']['certificate']==s['certificate'] and objects[name+'-point-state-audit']['status']==objects[name+'-point-selection-audit']['status']==objects[name+'-independent-full-model']['status']=='VERIFIED'
  assert row['point']['tiles']==[dict(next(c for c in b['bundle']['model']['candidates'] if c['id']==cid),slot=b['bundle']['steps'][cid]['slot']) for cid in s['selected']]
  ctrl=objects[name+'-control-full-result'];assert ctrl['status']==row['control']['status']=='UNKNOWN' and ctrl['reason']=='STATES' and ctrl['proof'] is ctrl['shortest_lines'] is None
  assert ctrl['counts']['states']==limits['bfs']['max_states']==20000 and ctrl['counts']['transitions']<500000 and ctrl['costs']['work']<20000000 and ctrl['costs']['seconds']<2
  assert row['control']['pipeline_seconds']==row['build_seconds']+row['control']['seconds'] and row['control']['proof'] is row['control']['check'] is None
  bfsreports.append({'id':name,'profile':'main','receipt':ctrl,'caller_seconds':row['control']['seconds'],'common_build_seconds':row['build_seconds']})
  assert row==objects[name+'-whole-case-result']
 buildreports.append({'id':name,'status':b['status'],'reason':b['reason'],'costs':b['costs'],'caller_build_seconds':row['build_seconds'],'slots':problem['slots'],'scope':'Prefix counters diagnostics only when UNKNOWN; no partial model/search admission.'})
assert collections.Counter(x['reason'] for x in buildreports if x['status']=='UNKNOWN')=={'WORK_LIMIT':5,'BASIS_LIMIT':2}
assert sum(x['status']=='COMPLETE' for x in buildreports)==1
for name,expectedstatus,length in [('given','SAT',1),('MP','SAT',3),('UI','SAT',3),('GEN','SAT',2),('finite-negative','UNSAT',None)]:
 q=objects['qualification-U-'+name];assert q['build']['status']=='COMPLETE' and q['bundle_audit']['status']=='VERIFIED';bundle=q['build']['bundle'];assert bundle['theory']==q['problem']['theory'] and bundle['goal']==q['problem']['goal']
 proof=verify_saved_solver('qualification-'+name,bundle,q['answer']);assert q['answer']['status']==expectedstatus
 groups=[[c for c in bundle['model']['candidates'] if c['t']==[p]] for p in bundle['model']['required']];assert math.prod(len(g) for g in groups)==q['brute']['assignments']
 ci={c['id']:c for c in bundle['model']['candidates']}
 for ids in q['brute']['solutions']:
  assert len(ids)==bundle['slots'] and len(set(ids))==len(ids);tot=collections.Counter();mm={}
  for cid in ids:
   tot.update(ci[cid]['t'])
   for p,v in ci[cid]['m']:assert p not in mm or mm[p]==v;mm[p]=v
  assert dict(tot)==dict.fromkeys(bundle['model']['required'],1)
 if proof is not None:assert proof==q['decoded']['proof']==q['selection_audit']['proof'] and sorted(q['answer']['selected']) in q['brute']['solutions']
 else:assert q['decoded'] is q['selection_audit'] is None and q['brute']['solutions']==[] and bundle['model']['candidates']==[]
 bf=q['BFS'];assert bf['status']==('DERIVABLE' if proof else 'NOT_DERIVABLE') and bf['shortest_lines']==length
 if proof:
  assert len(bf['proof'])==length and bf['proof'][-1]['formula']==bundle['goal']
  for i,line in enumerate(bf['proof']):
   if line['rule']=='axiom':assert line['formula']==bundle['theory']['axioms'][line['name']]
   if line['rule']=='mp':assert 0<=line['antecedent']<i and 0<=line['implication']<i and bf['proof'][line['implication']]['formula']==['imp',bf['proof'][line['antecedent']]['formula'],line['formula']]
   if line['rule']=='generalize':assert 0<=line['source']<i and line['formula']==['all',line['variable'],bf['proof'][line['source']]['formula']]
 else:assert bf['proof'] is None and bf['reason']=='FINITE_BASIS_LINE_EXHAUSTED'
 bfsreports.append({'id':name,'profile':'qualification','receipt':bf})
 if name=='finite-negative':
  z=q['BFS_cap_refusal'];assert z['status']=='UNKNOWN' and z['reason']=='STATES' and z['proof'] is None and z['counts']=={'states':0,'expanded':0,'transitions':0}
  bfsreports.append({'id':name,'profile':'qualification-zero-state-cap','receipt':z})
  assert [x['id'] for x in q['data_only_mutations']]==['missing-row','wrong-literal','future-reference','duplicate-cover']
  assert all(x['receipt']['status']=='REJECTED' and x['receipt']['proof'] is None for x in q['data_only_mutations'])
 qualificationreports.append({'id':name,'status':q['answer']['status'],'brute':q['brute'],'BFS_status':bf['status'],'shortest_lines':length,'data_only_mutations':q.get('data_only_mutations',[]),'scope':'Every saved solution literal cover and product extent joined; no new Cartesian product search/checker replay. Complete-brute assertion inherited reviewed Source plus whole saved record.'})
assert r['qualification']==objects['whole-point-compilation-qualification'] and r['qualification']['status']=='PASS' and r['qualification']['counts']=={'BFS':6,'build':5,'data_only_mutations':4,'decode':4,'records':5,'solve':5}
assert len(r['qualification_checks'])==8
for check in r['qualification_checks']:
 prefix=check['id']+'-'+check['lane'];whole=objects[prefix+'-whole-proof-check'];assert whole['status']=='VERIFIED' and whole['native']['status']=='accepted' and type(whole['native']['value']) is int and whole['native']['value']==1 and whole['independent']['status']=='VERIFIED'
 assert check['check']['independent']==whole['independent'] and check['check']['seconds']==whole['seconds']
wholechecks=[(k,v) for k,v in objects.items() if k.endswith('-whole-proof-check')];assert len(wholechecks)==9
assert len(bfsreports)==7 and len(solvereports)==6
assert wt['public_calls']==r['outer_public_calls'] and wt['public_calls']['compiler.build']==8 and wt['public_calls']['engine.solve']==wt['public_calls']['independent.bounded_bfs']==1 and wt['public_calls']['tree_machine.run']==9
out={'schema':'L-U-complete-saved-cohort-support-v1','scope':'Standard-library saved-data/readback/count/literal row joins only, no Source/project checker/solver/bridge/VM/proof search replay. No new mathematical proof generation.','observer':pin(A/'observer-result.json'),'worker_result':wt['result'],'all44files':pins,'all40artifacts':list(catalog.values()),'stored_bytes':435290,'raw_artifact_bytes':sum(x['raw_bytes'] for x in catalog.values()),'current27_raw_guards':guards,'authority':pin(authpath),'spent':pin(spentpath),'outer_stdout':pin(U/'root/study-001-outer-stdout.bin'),'outer_stderr':pin(U/'root/study-001-outer-stderr.bin'),'original_terminal_association':'Per trusted Root original handoff: initial exec1c253d, session48446, final0e223a exit0. Own saved full stdout/observer/worker/captures joined; no new OS observation.','worker_seconds':wt['elapsed_seconds'],'observer_seconds':obs['whole_observer_seconds'],'worker_lifetime_peak_bytes':wt['self_lifetime_peak_bytes'],'wait4_child_lifetime_peak_bytes':obs['wait4_peak_bytes'],'all8builds':buildreports,'all6_model_universes':modelreports,'all6saved_solves':solvereports,'all5qualification':qualificationreports,'all7BFS_receipts':bfsreports,'qualification':r['qualification'],'qualification_native_checks':r['qualification_checks'],'all9native_receipt_keys':[k for k,v in wholechecks],'public_outer_calls':r['outer_public_calls'],'common_build_seconds_sum':sum(x['caller_build_seconds'] for x in buildreports),'native_preparation_seconds':r['native_preparation_seconds'],'gaps':['No basis generation, logical substitution, truth table or search reexecution. Source-reviewed basis truth/completeness and actual C1+B selected proof validity remain the declared trust chain.','Main149 engine semantic events retain only64body rows; full-event hash is not recomputed from prefix. All27 rollback receipts and12 supplied entry/restored graph images joined, not complete intermediate graph snapshots.','Main BFS retains only counts/status, no20k-state archive; no independent exhaustion or counterfactual run inferred. It is STATES-cap UNKNOWN, not a time loser or proof of no derivation.','C complementary lane handles full nine native codec/carrier/heap/logic joins. This lane raw-joined all nine containing records.','All seven missing complete builds are UNKNOWN and no main arithmetic or substantive incidence/order goal was solved. Prefix counters are diagnostic only.']}
p=O/'U-complete-independent-saved-cohort-support-v1.json';p.write_bytes(json.dumps(out,sort_keys=True,indent=2,ensure_ascii=True).encode()+b'\n');print(json.dumps({'support':pin(p),'raw_bytes':out['raw_artifact_bytes'],'build_sum':out['common_build_seconds_sum'],'build_worker_fraction':out['common_build_seconds_sum']/wt['elapsed_seconds'],'model_counts':[(x['id'],x['candidates']) for x in modelreports],'rollback_count':sum(x['rollback_records'] for x in solvereports)},indent=2))
