"""Administrative raw/AST literal inheritance only; subject code never invoked."""
import pathlib,hashlib,json,ast,symtable,difflib
old=pathlib.Path('/private/tmp/gcts-proof-normalization-20261028-v1/root');u=pathlib.Path('/private/tmp/gcts-first-order-proof-search-20261028-v1');d=u/'implementation-B/publication-Source-v1'
H=lambda b:hashlib.sha256(b).hexdigest()
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':H(b)}
def save(name,obj):
 p=d/name;b=(json.dumps(obj,sort_keys=True,indent=2,ensure_ascii=True,allow_nan=False)+'\n').encode();assert not p.exists();p.write_bytes(b);return pin(p)
common=[('gcts-proof-normalization-20261028-v1','gcts-first-order-proof-search-20261028-v1'),('normalization-proof-search','first-order-proof-search'),('normalization_proof_search','first_order_proof_search'),('NORMALIZATION-PROOF-SEARCH','FIRST-ORDER-PROOF-SEARCH')]
configs=[('publish_normalization_proof_search_api_v1.py','publish_first_order_proof_search_api_v1.py','1deb4eca250da51372f92d8ad69a3e29296c975226a25d28d7d56bb9b454f45d',common+[('Publish proof normalization and cluster policy notebook','Publish finite first-order proof search outcomes and evidence'),('4085b1474aecd68bdc6406895f0e760a0c5ccc40','c32eaa5134ce869cebbd6db42eacddac6bf193ed'),('ba384acc046d9a637620fde0daeae75b7d2cd8e3','835b2fc75eb1c4ff5965eb7c34b3d4352eac87c1')]),('verify_normalization_proof_search_live_v1.py','verify_first_order_proof_search_live_v1.py','1c63604bad51e5e50bedf59879ad6792609dc91fe1d6c261359f3009ad98d1c2',common)]
records=[]
for oldname,newname,expected,repls in configs:
 op=old/oldname;np=u/'root'/newname;before=op.read_bytes();assert H(before)==expected;text=before.decode();counts=[]
 for a,b in repls:
  count=text.count(a);assert count>0;counts.append({'old':a,'new':b,'occurrences':count});text=text.replace(a,b)
 after=text.encode()
 if np.exists():assert np.read_bytes()==after
 else:np.write_bytes(after)
 # Study root must be inverted first: its new name contains the shorter new slug.
 inverse_order=[repls[0]]+list(reversed(repls[1:]));inverse=text
 for a,b in inverse_order:inverse=inverse.replace(b,a)
 assert inverse.encode()==before
 bt=ast.parse(before,filename=str(op));nt=ast.parse(after,filename=str(np));st=symtable.symtable(text,str(np),'exec');unused=compile(nt,str(np),'exec');del unused
 def normalize(x):
  if isinstance(x,ast.Constant)and type(x.value)is str:
   v=x.value
   for a,b in inverse_order:v=v.replace(b,a)
   x.value=v
  for c in ast.iter_child_nodes(x):normalize(c)
 normalize(nt);assert ast.dump(nt,include_attributes=False)==ast.dump(bt,include_attributes=False)
 nt=ast.parse(after,filename=str(np));lines=after.splitlines(keepends=True);helpers=[]
 def walk(n,path):
  for c in ast.iter_child_nodes(n):
   nxt=path
   if isinstance(c,(ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef)):
    nxt=path+'.'+c.name;raw=b''.join(lines[c.lineno-1:c.end_lineno]);helpers.append({'name':nxt,'line':c.lineno,'end_line':c.end_lineno,'raw_sha256':H(raw),'AST_sha256':H(ast.dump(c,include_attributes=False).encode()),'signature':ast.unparse(c.args)if isinstance(c,(ast.FunctionDef,ast.AsyncFunctionDef))else'class','callset':sorted({ast.unparse(z.func)for z in ast.walk(c)if isinstance(z,ast.Call)})})
   walk(c,nxt)
 walk(nt,'module');scopes=[]
 def sw(st,path):
  scopes.append({'path':path,'type':st.get_type(),'line':st.get_lineno(),'identifiers':sorted(st.get_identifiers())})
  for i,c in enumerate(st.get_children()):sw(c,path+'/'+c.get_name()+':'+str(c.get_lineno())+':'+str(i))
 sw(st,'module');patches=[]
 for label,a,b,an,bn in [('forward',before,after,str(op),str(np)),('inverse',after,before,str(np),str(op))]:
  raw=''.join(difflib.unified_diff(a.decode().splitlines(keepends=True),b.decode().splitlines(keepends=True),fromfile=an,tofile=bn)).encode();pp=d/(newname+'.'+label+'.patch');assert not pp.exists();pp.write_bytes(raw);patches.append(pin(pp))
 records.append({'predecessor':pin(op),'Source':pin(np),'replacements':counts,'inverse_order':'study-root first, then reversed shorter literal list (prevents overlapping slug substitution)','inverse_raw_exact':True,'inverse_normalized_AST_exact':True,'patches':patches,'helpers':helpers,'definition_count':len(helpers),'symbol_scope_count':len(scopes),'symbol_scopes':scopes,'AST_sha256':H(ast.dump(nt,include_attributes=False).encode()),'positioned_AST_sha256':H(ast.dump(nt,include_attributes=True).encode()),'static':'AST/symtable/discarded unused compile only; subject calls/imports/network zero.'})
s=save('U-publication-complete-literal-preservation-static-v1.json',{'schema':'U-publication-literal-preservation-static-v1','status':'PASS_SOURCE_ONLY','sources':records,'subject_calls':0,'network_calls':0,'payload_or_authority_created':False})
print(json.dumps({'static':s,'Sources':[r['Source']for r in records],'definitions':[r['definition_count']for r in records],'scopes':[r['symbol_scope_count']for r in records]},indent=2))
