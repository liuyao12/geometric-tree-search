"""Saved JSON/text/HTML materialization only; no scientific imports or calls."""
from pathlib import Path
import gzip
import hashlib
import json

ROOT = Path('/private/tmp/gcts-first-order-proof-search-20261028-v1')
R = ROOT / 'root'
A = ROOT / 'actual/study-001'

def load(path):
    path = Path(path)
    raw = path.read_bytes()
    return json.loads(gzip.decompress(raw) if path.suffix == '.gz' else raw)

def ref(path):
    path = Path(path)
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

w = load(A / 'worker-result.json.gz')
o = load(A / 'observer-result.json')
plan = load(R / 'study-once-plan-001.json')
cases = []
for row in w['results']:
    cases.append(dict(row, slots=row['problem']['slots'],
                      candidate_count=row.get('candidate_count')))
main = next(x for x in cases if x['build_status'] == 'COMPLETE')
bfs = load(A / (main['id'] + '-control-full-result.json'))
checks = []
for path in sorted(A.glob('*whole-proof-check.json*')):
    c = load(path)
    checks.append(dict(artifact=ref(path), proof_lines=len(c['proof']),
                       proof_bytes=len(bytes.fromhex(c['encoding']['stream_hex'])),
                       native_steps=c['native']['steps'], seconds=c['seconds'],
                       native_status=c['native']['status'], native_value=c['native']['value'],
                       independent=c['independent']['status']))
findings = [
    'One input-only calibration produced a kernel-verified quantified proof. It specializes the incidence typing axiom to a named line. The eight-row certificate contains two unused repeated axiom rows; its six other rows form the dependency chain. This is an elementary first-order specialization, not a substantive geometry theorem.',
    'Seven of eight prospective builds stopped before either search could run: five reached the compilation-work cap and two reached the formula-basis cap. Every ambitious arithmetic and geometry input is among these seven UNKNOWN outcomes. No arithmetic theorem was discovered in this run.',
    'On the one complete model, point search found a compatible tiling in %.4f seconds after %.4f seconds of common compilation. Its same-basis BFS control stopped at 20,000 states after %.4f seconds, with time remaining under its two-second limit. This state-capped comparison establishes no speed or superiority result.' % (main['point']['seconds'], main['build_seconds'], main['control']['seconds']),
    'All nine whole certificates passed the unchanged native checker and separate first-order checker: eight from qualification and one from the research calibration. They total 26 checked lines. The whole first-order worker took %.4f seconds, including failed construction, audits, logging and checking.' % o['worker_terminal']['elapsed_seconds'],
]
assessment = [
    'The search did choose inference tiles and earlier-line references without receiving a proof sequence. The successful model contains 1,757 candidates, 52 formulas and 19 zero-premise rule instances. It explored 64 nodes, with 33 branches, four forced placements and 26 backtracks; all 13,675 trailed writes were undone. The accepted proof uses axioms, universal instantiation, modus ponens and generalization.',
    'The dominant limitation is explicit catalogue construction. Even the simple arithmetic calibration reached its work cap after producing only a partial candidate universe, which was discarded. A larger formula pool would increase this cost. This result gives a concrete reason to redesign representation before spending more on RL.',
    'The next useful experiment should generate relevant rule instances and conditional cluster interfaces on demand, while preserving a complete fallback or explicitly returning UNKNOWN when coverage is incomplete. It should compare point constraints with a goal-directed symbolic control under matched time and memory limits. The present unguided, state-capped BFS is only a modest control; existing proof-search systems were not benchmarked here.',
]
data = dict(cases=cases, findings=findings, assessment=assessment,
            profile=dict(generation_profile=w['profile'], limits=w['limits'],
                         design=load(R / 'prospective-design-v1.json'),
                         original_worker_seconds=o['worker_terminal']['elapsed_seconds'],
                         original_observer_seconds=o['whole_observer_seconds'],
                         child_wait4_peak_bytes=o['wait4_peak_bytes'],
                         common_compilation_seconds=sum(x['build_seconds'] for x in cases),
                         all_kernel_bridge_seconds=sum(x['seconds'] for x in checks),
                         cost_scope='Separate phase samples are not an exhaustive partition. Whole worker includes all execution, audits and artifact storage. Returned serialization/caller tails follow component samples. One run, no hard OS quota or statistical claim.'),
            bridge_summary='All 20 controls passed: three complete tiny transition tables, ten malformed inputs, four resource refusals and three callback contracts. The adapter expands default loops with explicit override precedence and does not return partial machines. Full checker lowering and literal palette construction remain open.',
            bridge_controls=[dict(id=x['id'],
                status=x.get('answer', {}).get('status', x.get('status')),
                transitions=x.get('answer', {}).get('counts', {}).get('emitted_transitions'))
                for x in w['bridge_records']])
admission = R / 'Root-study001-complete-scientific-admission-v1.json'
public = dict(schema='U-first-order-proof-search-public-results-v1',
              observed=w, reader=data, all_native_checks=checks,
              original_observer=ref(A / 'observer-result.json'),
              original_worker=ref(A / 'worker-result.json.gz'),
              source_pins=plan['sources'], metadata_pins=plan['metadata'],
              scientific_admission=None if not admission.exists() else ref(admission),
              native_check_totals=dict(certificates=len(checks),
                  lines=sum(x['proof_lines'] for x in checks),
                  bytes=sum(x['proof_bytes'] for x in checks),
                  native_steps=sum(x['native_steps'] for x in checks)),
              interpretation='One simple first-order calibration, seven UNKNOWN_BUILD outcomes, nine actual double-checked certificates including eight qualifications. BFS state refusal is not a negative or superiority result. No new RL or full fixed Wang palette.')
out = R / 'report-draft'
out.mkdir(exist_ok=True)
html = (R / 'first-order-reader-template.html').read_text()
html = html.replace('white-space:nowrap}.pass', 'white-space:normal;max-width:100%;overflow-wrap:anywhere}.pass')
html = html.replace('font-size:12px}.formula', 'font-size:12px;max-width:100%;overflow-x:auto}.formula')
embedded = json.dumps(data, ensure_ascii=True, sort_keys=True, separators=(',', ':')).replace('<', '\\u003c').replace('&', '\\u0026')
assert html.count('__RESEARCH_DATA__') == 1
html = html.replace('__RESEARCH_DATA__', embedded)
for name, raw in [('first-order-proof-search-v1.html', html.encode()),
                  ('first-order-proof-search-results-v1.json',
                   (json.dumps(public, ensure_ascii=True, sort_keys=True, indent=2) + '\n').encode())]:
    p = out / name
    p.write_bytes(raw)
    assert p.read_bytes() == raw
    print(json.dumps(ref(p)))
