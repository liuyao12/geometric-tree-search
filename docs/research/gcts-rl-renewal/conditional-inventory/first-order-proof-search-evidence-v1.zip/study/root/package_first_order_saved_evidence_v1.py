"""Archive saved files only. No project import, scientific call, Git or network."""
from pathlib import Path
import hashlib
import json
import zipfile

U = Path('/private/tmp/gcts-first-order-proof-search-20261028-v1')
R = U / 'root'
OUT = R / 'report-draft/first-order-proof-search-evidence-v1.zip'
sources = {}
def add(path, name):
    p = Path(path)
    assert p.is_file() and not p.is_symlink()
    assert name and not name.startswith('/') and '..' not in name.split('/')
    if str(p) in sources:
        return
    raw = p.read_bytes()
    assert len(raw) <= 33554432
    sources[str(p)] = (name, raw)

skip_roots = {'publication-first-order-proof-search-v1',
              'publication-first-order-proof-search-api-v1',
              'first-order-proof-search-live-TLS-verification-v1',
              'publisher-first-order-proof-search-payload',
              'prepublication-renderer-v1-history'}
for path in sorted(U.rglob('*')):
    if not path.is_file() or path.is_symlink():
        continue
    relative = path.relative_to(U)
    if any(part in skip_roots for part in relative.parts):
        continue
    if path.suffix == '.zip' or path.name == 'U-worker-body-draft.py':
        continue
    if path.name.startswith(('archive-package-', 'FINAL-PUBLICATION',
                             'first-order-proof-search-publication-plan')):
        continue
    add(path, 'study/' + str(relative))

plan = json.loads((R / 'study-once-plan-001.json').read_bytes())
for role, value in plan['sources'].items():
    add(value['path'], 'sources/' + role + '/' + Path(value['path']).name)
for role, value in plan['metadata'].items():
    add(value['path'], 'metadata/' + role + '/' + Path(value['path']).name)
add(plan['bootstrap']['path'], 'runtime/' + Path(plan['bootstrap']['path']).name)
bridge_abi = json.loads((U / 'implementation-C/compressed-physical-NTM-complete-public-ABI-v1.json').read_bytes())
for role, value in bridge_abi['basis'].items():
    add(value['path'], 'bridge-design-basis/' + role + '/' + Path(value['path']).name)
publication_abi = json.loads((U / 'implementation-B/publication-Source-v1/U-first-order-proof-publication-complete-public-ABI-v1.json').read_bytes())
for value in publication_abi['predecessors']:
    add(value['path'], 'publication-predecessors/' + Path(value['path']).name)
for directory in [
    '/private/tmp/gcts-B-U-independent-verifier-peer-v1',
    '/private/tmp/gcts-B-U-study001-saved-review-v1',
    '/private/tmp/gcts-L-U-complete-saved-cohort-review-v1',
    '/private/tmp/gcts-C-U-publication-Source-peer-v1',
]:
    parent = Path(directory)
    for path in sorted(parent.rglob('*')):
        if path.is_file() and not path.is_symlink() and path.suffix != '.zip':
            add(path, 'independent-reviews/' + parent.name + '/' + str(path.relative_to(parent)))

assert len({v[0] for v in sources.values()}) == len(sources)
scientific = [p for p in sources if '/actual/' in p]
assert len(scientific) == 50
readme = (
    'GCTS first-order search, milestone U: complete scientific evidence cut.\n\n'
    'Contains all fifty original scientific files: six bridge-control files and forty-four first-order-study files. '
    'All actual proof streams, certificates, initial/final heaps, selected point models, retained logs, limits, '
    'Sources, input-only cases, prospective and saved-data reviews, Root admissions and local browser QA are included. '
    'The native runtime executable and operating system are not vendored; the exact runtime identity is in the plans.\n\n'
    'One eight-row incidence-language calibration was proved; two rows are unused axiom padding. '
    'Seven builds remain UNKNOWN. BFS stopped at its state cap, so no speed advantage is established. '
    'Nine actual native-plus-independent certificates include eight qualification certificates. '
    'Twenty tiny structural machine-bridge controls do not construct a full C1 Wang palette. No new RL run.\n\n'
    'MANIFEST.json binds every origin path, entry, length and SHA256. Sources and execution plans bind the current '
    'scientific closure. All scientific once authorities are spent; this archive is evidence, not permission to rerun them. '
    'The public source includes an explicitly documented generic huge-integer wall-limit classification edge outside '
    'the actual fixed plan. The archive is not a hermetic standalone runtime or a proof of unrestricted FOL completeness.\n\n'
    'Archive cut precedes publication. Later publication/TLS authorities, GitHub request/response logs and live-browser '
    'verification are retained separately in the durable workspace completion record: embedding their hashes here '
    'would create a circular archive/publication dependency. Publication/TLS Sources and their Source peer are included. '
    'No primary reader or unrelated repository content is packaged.\n'
).encode()
entries = [dict(entry=name, origin=origin, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
           for origin, (name, raw) in sorted(sources.items(), key=lambda item: item[1][0])]
manifest = dict(schema='U-complete-scientific-evidence-archive-v1',
                source_files=len(entries), scientific_originals=50,
                source_bytes=sum(x['bytes'] for x in entries), entries=entries,
                README_sha256=hashlib.sha256(readme).hexdigest(),
                runtime_external=plan['python'],
                scientific_admission=json.loads((R / 'Root-study001-complete-scientific-admission-v1.json').read_bytes()))
manifest_raw = (json.dumps(manifest, ensure_ascii=True, sort_keys=True, indent=2) + '\n').encode()
members = {name: raw for name, raw in sources.values()}
members['MANIFEST.json'] = manifest_raw
members['README.txt'] = readme
assert not OUT.exists()
with zipfile.ZipFile(OUT, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name in sorted(members):
        info = zipfile.ZipInfo(name, (2026, 10, 28, 0, 0, 0))
        info.create_system = 3
        info.external_attr = 0o100644 << 16
        info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, members[name], compresslevel=9)
with zipfile.ZipFile(OUT) as archive:
    assert archive.testzip() is None
    assert set(archive.namelist()) == set(members) and len(archive.namelist()) == len(members)
    for name, raw in members.items():
        assert archive.read(name) == raw
raw = OUT.read_bytes()
receipt = dict(schema='U-complete-archive-package-readback-v1', status='ALL_ENTRIES_MATCH',
               archive=dict(path=str(OUT), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()),
               members=len(members), origins=len(entries), scientific_originals=50,
               original_bytes=manifest['source_bytes'], manifest_sha256=hashlib.sha256(manifest_raw).hexdigest(),
               scope='All saved scientific originals and current closure; every compressed entry fully read back. No scientific function or network executed. Prepublication evidence cut explained in README.')
p = R / 'archive-package-readback-v2.json'
p.write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
print(json.dumps(receipt))
