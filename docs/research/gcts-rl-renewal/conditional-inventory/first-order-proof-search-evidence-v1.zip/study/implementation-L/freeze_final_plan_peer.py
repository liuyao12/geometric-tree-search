"""Passive exact administrative plan/current-byte join only; no subject call."""
import pathlib,json,hashlib,stat,sys
U=pathlib.Path('/private/tmp/gcts-first-order-proof-search-20261028-v1');O=U/'implementation-L';R=U/'root'
def pin(p):
 p=pathlib.Path(p);s=p.lstat();assert stat.S_ISREG(s.st_mode) and not p.is_symlink()
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def pairs(items):
 d={}
 for k,v in items:assert k not in d;d[k]=v
 return d
def read(p):return json.loads(pathlib.Path(p).read_bytes(),object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(AssertionError(x)))
def put(name,x):
 p=O/name;p.write_bytes(json.dumps(x,sort_keys=True,indent=2,ensure_ascii=True,allow_nan=False).encode()+b'\n');return pin(p)
def typed(x):
 if type(x) is dict:
  assert all(type(k) is str for k in x)
  for v in x.values():typed(v)
 elif type(x) is list:
  for v in x:typed(v)
 else:assert x is None or type(x) in (str,int,bool)
p=R/'study-once-plan-001.json';assert pin(p)=={'path':str(p),'bytes':7151,'sha256':'fde404d782dfa2285db70a42c4230b8acaafe19811f1fd5048239ba8a9170518'}
plan=read(p);typed(plan);assert set(plan)=={'schema','sources','metadata','python','bootstrap','actual_dir','limits'}
assert plan['schema']=='U-first-order-proof-once-plan-v1'
roles={'runner','compiler','engine','independent','state_audit','tree_machine','codec','carrier','fol_checker','real_parser'}
metas={'bridge_admission','bridge_observer','bridge_peer','bridge_result','calibrations','caller_ABI','cases','compiler_ABI','design','experiment_limits','independent_ABI','independent_source_peer','master','native_recipe','profile'}
assert set(plan['sources'])==roles and set(plan['metadata'])==metas
refs=[]
for role,x in [('python',plan['python']),('bootstrap',plan['bootstrap']),*[(k,v) for k,v in plan['sources'].items()],*[(k,v) for k,v in plan['metadata'].items()]]:
 assert set(x)=={'path','bytes','sha256'} and type(x['path']) is str and type(x['bytes']) is int and x['bytes']>=0 and type(x['sha256']) is str and len(x['sha256'])==64 and all(c in '0123456789abcdef' for c in x['sha256'])
 path=pathlib.Path(x['path']);assert path.is_absolute() and path.resolve()==path
 assert pin(path)==x;refs.append({'role':role,'reference':x})
assert plan['sources']['runner']['sha256']=='14d4230e09dd580ca3b029d49b1e1993da8a7a0ef015fea54257b1bf7e85b351'
assert plan['sources']['independent']['sha256']=='7b62edf64cd5cec507833819e30e7880def0fccf517b2106d21b8cac36c85aea'
assert plan['sources']['compiler']['sha256']=='a35fab59d3a19f676e6f72f0b5061ff67eb7241f540e9e4b401fff67676b9f2d'
assert plan['python']['sha256']=='d90bce0f5ac3aa40e2ee5900ad243bad0b2205ce17408278f088b34aed737840'
assert plan['bootstrap']['bytes']==344 and plan['bootstrap']['sha256']=='f0fb00e11e4d22c78467a2182f4f1e980578d5ec064c3fb3031c6c8dad345b62'
bootstrap=pathlib.Path(plan['bootstrap']['path']).read_text();assert 'exec(compile(' in bootstrap and 'sha256' in bootstrap
assert plan['limits']=={'worker_seconds':210,'observer_seconds':240,'rss_bytes':1073741824,'file_bytes':33554432,'total_bytes':536870912,'max_files':384,'stream_bytes':1048576}
assert all(type(v) is int for v in plan['limits'].values())
metadata={k:read(v['path']) for k,v in plan['metadata'].items() if v['path'].endswith('.json')}
assert metadata['caller_ABI']['Source']==plan['sources']['runner']
assert metadata['compiler_ABI']['Source']==plan['sources']['compiler']
assert metadata['independent_ABI']['Source']==plan['sources']['independent']
assert metadata['bridge_admission']['worker_result']==plan['metadata']['bridge_result'] and metadata['bridge_admission']['status']=='ADMITTED_COMPLETE_TINY_QUALIFICATION'
assert metadata['bridge_result']['status']=='COMPLETE' and len(metadata['bridge_result']['records'])==20
cases,calibs=metadata['cases'],metadata['calibrations'];assert len(cases)==6 and len(calibs)==2 and not set(cases)&set(calibs)
for obj in [*cases.values(),*calibs.values()]:assert set(obj)=={'theory','goal'}
d=metadata['design'];assert set(d['order'])==set(cases)|set(calibs) and len(d['order'])==len(set(d['order']))==8
assert d['slots']=={n:(6 if n=='arith-add-zero-at-successor' else 8 if n=='incidence-typing-specialized-line' else 16) for n in d['order']}
assert metadata['profile']=={'ui_rounds':1,'bridge_arity':1,'max_tautology_atoms':12}
lims=metadata['experiment_limits'];assert lims['compilation']=={'wall_seconds':5,'max_work':100000000,'max_candidates':20000,'max_basis':10000,'max_instances':10000,'max_depth':128}
assert lims['independent']=={'wall_seconds':15,'max_work':100000000,'max_depth':128,'max_candidates':100000}
assert lims['bfs']=={'wall_seconds':2,'max_states':20000,'max_transitions':500000,'max_work':20000000}
assert lims['point']=={'wall_seconds':2,'max_nodes':50000,'max_events':64}
actual=U/'actual/study-001';authority=R/'study-once-authority-001.json';consumed=pathlib.Path(str(authority)+'.CONSUMED.json');stdout=R/'study-001-outer-stdout.bin';stderr=R/'study-001-outer-stderr.bin'
assert plan['actual_dir']==str(actual)
fresh=[]
for x in [actual,authority,consumed,stdout,stderr]:assert not x.exists() and not x.is_symlink();fresh.append({'path':str(x),'absent':True})
argv=[plan['python']['path'],'-I','-S','-B',plan['bootstrap']['path'],plan['sources']['runner']['path'],str(plan['sources']['runner']['bytes']),plan['sources']['runner']['sha256'],'--mode','observer','--plan',str(p),'--authority',str(authority)]
command='set -C\n'+' '.join(argv)+' < '+plan['sources']['runner']['path']+' > '+str(stdout)+' 2> '+str(stderr)
support=put('U-final-plan-complete-independent-rawjoin-support-v1.json',{'schema':'L-U-final-plan-rawjoin-v1','plan':pin(p),'caller_ABI':plan['metadata']['caller_ABI'],'current27_raw_guards':refs,'fresh_paths':fresh,'frozen_limits':lims,'profile':metadata['profile'],'design':d,'bootstrap_literal':bootstrap,'proposed_exact_outer_argv':argv,'proposed_two_line_noclobber_command':command,'proposal_scope':'Concrete compatible invocation recipe for Root adoption, not executed/granted here. Original tool/session complete capture and terminal exit mandatory.','runtime_admin_interpreter':{'executable':sys.executable,'version':sys.version},'caller_Source_peer':pin(O/'U-Root-caller-complete-independent-Source-peer-v1.json'),'independent_Source_peer':plan['metadata']['independent_source_peer'],'subject_calls':0})
review=put('U-final-plan-complete-independent-prospective-review-v1.json',{'schema':'L-U-final-plan-complete-prospective-review-v1','status':'PASS_EXACT_PLAN_AND_SOURCE_JOIN_NO_EXECUTION_GRANT','review_passed':True,'blockers':[],'prefrozen':pin(O/'U-final-plan-prefrozen-bounded-requirements-v1.json'),'plan':pin(p),'caller_ABI':plan['metadata']['caller_ABI'],'support':support,'coverage':'Entire7151 exact native7field plan, all10currentSource+15metadata+D90+344bootstrap full rawpins, exact Source/API associations, whole8 input-onlycases/profile/slots/caps and saved admitted20bridge association; all current rawrefs absolute canonical leaf-regular paths. B compiler body was hashed only, not semantically intaken in this lane.','closed_counts':'5qualification builds/solves,4decodes,6BFS;8nativeC1+B qualification certificates. Main8build attempts, only COMPLETE bundles admit one point and one BFS; up to16main certificates. Nested counts are separate from outer entry dictionary.','freshness':fresh,'future_authority':'Exact U schema6field{schema,authorized:true,uses:exactint1,plan,runner,python}, raw pin this plan/27722Source/D90. Must be newly Root-authored after adoption and toolsidle; adjacent durable exclusive SPENT consume, no bridge or old reuse.','invocation':'Concrete no-clobber two-line D90-ISB authenticated retained-stdin observer recipe in support. Root owns original exec/session and full outerstdout/stderr; no capture Python/tee/scientific helper/retry. Pending Root adoption is not supplied by this receipt.','caps_and_scope':'210 sampled worker/240observer/5cleanup;1GiB sampledRSS with recorded wait4<=1GiB required at whole actual admission;32MiB raw/stored bodies/480MiB inner/512MiB readback/384files/1MiB each stream. Compilation5s/20k candidates, point2s50knodes64events, independent15s100mwork, BFS2s20kstates500ktransitions20mwork. No hard quota, numeric RSSsum or guaranteed completion.','science':'Finite Source-reviewed basis and flat-line bound only; UNKNOWN_BUILD has no partial universe, finite negative never unbounded FOL/PA/Hilbert impossibility. Full selected certificates require actual C1accepted exactint1 and independentBVERIFIED; no physical palette/RL/novelty/superiority result from plan.','remaining':'Root full compiler/currentSource peer adoptions, exact fresh A6 and all toolsidle before sole launch; whole original terminal/EOF/wait/group/rawcaps/postguards/outcomes and independent saved scientific review before admission. No authority, capture, actual, publication or runtime created by this reviewer.','subject_calls':0,'tools':'TERMINAL_IDLE'})
print(json.dumps({'review':review,'support':support},indent=2))
