"""Administrative literal JSON authoring only; no project import or subject call."""
import json,pathlib,hashlib,collections
O=pathlib.Path('/private/tmp/gcts-first-order-proof-search-20261028-v1/implementation-L')
def V(n):return ['var',n]
def F(n,*a):return ['fun',n,list(a)]
def P(n,*a):return ['pred',n,list(a)]
def All(names,p):
 for n in reversed(names):p=['all',n,p]
 return p
def Eq(a,b):return ['eq',a,b]
def Imp(a,b):return ['imp',a,b]
def Not(a):return ['not',a]
def And(items):
 r=items[-1]
 for a in reversed(items[:-1]):r=['and',a,r]
 return r
def pin(p):
 p=pathlib.Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def save(name,x):
 p=O/name;p.write_bytes(json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode()+b'\n');return pin(p)
x,y=V('x'),V('y');z=F('0');one=F('S',z)
addaxioms={'add-zero':All(['x'],Eq(F('add',x,z),x)),'add-successor':All(['x','y'],Eq(F('add',x,F('S',y)),F('S',F('add',x,y))))}
AT={'functions':{'0':0,'S':1,'add':2},'predicates':{},'axioms':addaxioms}
a,b,c,l,m=[V(n) for n in ['a','b','c','l','m']]
baseinc=[P('Point',a),P('Point',b),P('Line',l),P('Line',m)]
incidences=[P('On',a,l),P('On',b,l),P('On',a,m),P('On',b,m)]
IT={'functions':{},'predicates':{'Point':1,'Line':1,'On':2},'axioms':{'incidence-unique-line':All(['a','b','l','m'],Imp(And(baseinc+[Not(Eq(a,b))]+incidences),Eq(l,m)))}}
OT={'functions':{},'predicates':{'Point':1,'Between':3},'axioms':{
 'between-reversal':All(['a','b','c'],Imp(P('Between',a,b,c),P('Between',c,b,a))),
 'between-distinct-points':All(['a','b','c'],Imp(P('Between',a,b,c),And([P('Point',a),P('Point',b),P('Point',c),Not(Eq(a,b)),Not(Eq(a,c)),Not(Eq(b,c))]))),
 'between-middle-exclusion':All(['a','b','c'],Imp(P('Between',a,b,c),Not(P('Between',a,c,b))))}}
cohort={
 'arith-right-one':{'theory':AT,'goal':All(['x'],Eq(F('add',x,one),F('S',x)))},
 'arith-nested-right-one':{'theory':AT,'goal':All(['x'],Eq(F('add',F('add',x,one),one),F('S',F('S',x))))},
 'arith-successor-contrast':{'theory':AT,'goal':All(['x'],Eq(F('add',x,z),F('S',x)))},
 'incidence-distinct-lines-common-points':{'theory':IT,'goal':All(['a','b','l','m'],Imp(And(baseinc+[Not(Eq(l,m))]+incidences),Eq(a,b)))},
 'order-reversal-exclusion':{'theory':OT,'goal':All(['a','b','c'],Imp(P('Between',a,b,c),Not(P('Between',c,a,b))))},
 'order-middle-contrast':{'theory':OT,'goal':All(['a','b','c'],Imp(P('Between',a,b,c),P('Between',b,a,c)))}}
cp=save('U-prospective-input-only-quantified-cohort-v1.json',cohort)
# Evidence extraction reads saved records only, never checks or searches them.
R=pathlib.Path('/private/tmp/gcts-compact-proof-tiles-20261027-v1/actual/qualification-001');evidence=[]
for stem in ['addition-right-one','addition-one-plus-one','distinct-lines-common-points-coincide','equality-symmetry']:
 p=R/(stem+'-input-and-proposal.json');d=json.loads(p.read_bytes());g=d['generation'];pr=g.get('proposal',{});row={'case':stem,'input_and_proposal':pin(p),'proposal_origin':pr.get('origin'),'stored_proposal_lines':len(pr.get('proof',[])),'stored_rules':dict(collections.Counter(v['rule'] for v in pr.get('proof',[]))),'stored_generation_status':g['status'],'lanes':{}}
 for lane in ['point-markings','conventional-clauses']:
  p=R/(stem+'-'+lane+'-result.json');d=json.loads(p.read_bytes());ac=d.get('accepted');row['lanes'][lane]={'reference':pin(p),'stored_status':d['status'],'stored_accepted_matched_proposal':None if ac is None else ac.get('matched_proposal'),'stored_checker_status':None if ac is None else ac['checker']['status'],'stored_accepted_proof_lines':None if ac is None else len(ac['proof'])}
 evidence.append(row)
E=save('U-prior-evidence-focused-extraction-v1.json',{'schema':'L-U-focused-prior-evidence-v1','scope':'Saved JSON field extraction only, not a new prior scientific replay or complete re-admission. No protected/dataless original followed.','records':evidence})
base=pathlib.Path('/private/tmp/gcts-fixed-fol-proof-palette-20261027-v1/root')
metadata={
 'schema':'L-U-independent-first-order-design-v1','status':'PROSPECTIVE_INPUT_ONLY_NO_EXECUTION','cohort':cp,'evidence':E,
 'recommendation':'Make the unknown finite Hilbert-eight proof DAG the actual searched object: rule choices, formula/schema parameters, terms, earlier references and resulting formulas. A conventional prover may solve a separate comparison lane, but its proof/trace/clauses must never become the tile lane input or a singleton candidate inventory. Initially keep learning disabled; meaningful structural FOL search and independent certificate admission are the result sought.',
 'evidence_basis':[
  {'reference':pin('/private/tmp/gcts-fixed-fol-proof-palette-20261027-v1/implementation-B/independent_fol_checker_v1.py'),'inspection':'Complete current 21,560-byte independent eight-rule Source read. Equality, capture-free substitution and alpha equivalence are available, but it recognizes derivability from supplied CLOSED finite axioms, not PA/Hilbert membership or search completeness.'},
  {'reference':pin('/private/tmp/gcts-fixed-fol-proof-palette-20261027-v1/implementation-B/independent-fol-checker-complete-effective-public-ABI-v2.json'),'inspection':'Full current ABI read. instantiate produces the logical implication from a universal to its capture-free instance; MP must actually establish the instance. generalize references an earlier theorem, sound here only because theory axioms are closed and no local assumptions are hidden.'},
  {'reference':pin(base/'recovered-logical-Source-v1/first_order_cases.py'),'inspection':'Earlier case Source is assertion-only and includes quantified application/capture/equality controls. Useful regressions, not a new PA/Hilbert structural benchmark by itself.'},
  {'reference':pin(base/'recovered-logical-Source-v1/first_order_families.py'),'inspection':'Families explicitly mine actual donor proofs and admit matched ground definitions. Reuse as a disclosed learned-library control only; do not present donor/template specialization as cold discovery.'},
  {'reference':pin(base/'recovered-public-metadata-v1/first-order-suite-conformance.json'),'inspection':'Earlier notes explicitly limit the fixed finite case catalogue/two UI rounds and disclaim PA/Hilbert theorem/completeness/new RL. Historical literal paths retained only as metadata; no .gcts-active traversal.'}],
 'case_provenance':{
  'arith-right-one':{'family':'PA addition defining-equation fragment','role':'Earlier R target retained as regression, now unknown rule/reference structure rather than supplied generated proof.','latex':'\\forall x\\; x+S(0)=S(x)'},
  'arith-nested-right-one':{'family':'PA addition defining-equation fragment','role':'Nested function context and chained equality transport; no induction principle supplied.','latex':'\\forall x\\; (x+S(0))+S(0)=S(S(x))'},
  'arith-successor-contrast':{'family':'Same PA defining equations','role':'Contrast target, not an expected verdict supplied to search. Resource/catalogue failure remains unknown about mathematical validity.','latex':'\\forall x\\; x+0=S(x)'},
  'incidence-distinct-lines-common-points':{'family':'Hilbert-style relational plane-incidence uniqueness fragment','role':'Closed guarded at-most-one-line axiom plus equality; contrapositive/common-point consequence. Earlier R target retained as structural-search regression.','latex':'\\forall a\\,b\\,l\\,m\\; (\\operatorname{Point}(a)\\land\\operatorname{Point}(b)\\land\\operatorname{Line}(l)\\land\\operatorname{Line}(m)\\land l\\ne m\\land\\operatorname{On}(a,l)\\land\\operatorname{On}(b,l)\\land\\operatorname{On}(a,m)\\land\\operatorname{On}(b,m))\\to a=b'},
  'order-reversal-exclusion':{'family':'Hilbert-style strict-betweenness fragment','role':'Composition of reversal and at-most-one-middle clauses, instantiated with different variable orders; not a single supplied target axiom.','latex':'\\forall a\\,b\\,c\\;\\operatorname{Between}(a,b,c)\\to\\neg\\operatorname{Between}(c,a,b)'},
  'order-middle-contrast':{'family':'Same strict-betweenness fragment','role':'Incompatible-middle contrast with no stored expected answer or witness.','latex':'\\forall a\\,b\\,c\\;\\operatorname{Between}(a,b,c)\\to\\operatorname{Between}(b,a,c)'}},
 'provenance_precision':[
  'The two universally closed addition equations are standard defining equations used in PA, with the full signature explicit. No induction schema, successor injectivity/nonzero or PA axiom recognizer is included: call this a finite PA-defining-equation fragment, never full PA.',
  'Geometry is one-sorted FOL with explicit Point/Line guards and primitive On/Between predicates. The incidence uniqueness and strict order clauses are selected Hilbert-style relational fragments. No incidence existence, Pasch, congruence, parallel or continuity axioms, coordinates, Euclidean completeness or full Hilbert-system claim.',
  'Four-signature roles are only names in JSON; formula/theory validation and native/B admission remain required. No many-sorted semantics may be silently inferred.'],
 'bound_semantics':[
  'Freeze one theorem-independent finite term/formula/schema-parameter grammar before implementation. Include all candidates of that declared universe and all legal earlier references; lazy generation needs exhaustion/singleton certificates. Goal guidance may order but never remove complete base fallback.',
  'Start with one explicit finite-variable convention and subterm/term-depth closure; add the logical implication/schema formulas, equality templates and generic propositional bridge shapes required by the declared eight-rule profile. A subformula-only list is not the full Hilbert proof language. Any truncation during complete universe construction is UNKNOWN_BUILD, not a complete prefix.',
  'The proof bound counts emitted flat Hilbert lines, including logical schema lines, axioms, each MP and generalization. A short sequent or rewrite proof may expand beyond the Hilbert bound; the complete translated flat certificate determines admission and length.',
  'Exhaustion establishes NO_PROOF_IN_DECLARED_FINITE_UNIVERSE only. It is not FOL/PA/geometry unprovability. Wall/work/output/RAM or incomplete construction means UNKNOWN. Mathematical nonderivability requires an independently checked countermodel or separate completeness theorem.',
  'Do not inherit T PAD/GIVEN/MP normalization for eight rules without its own preservation argument; initially use transparent raw DAG candidates or only transformations justified for this exact closed-theory kernel.'],
 'practical_comparison':{
  'main':'Same finite Hilbert candidate universe and flat-line bound for point search and conventional symbolic DAG search, cold total compile+search costs and complete certificates.',
  'optional_control':'Goal-directed sequent/equational obligation search with explicit open-context/eigenvariable checks and deterministic Hilbert-eight certificate expansion. Attribute that proof discovery to this separate conventional method, never decorate it and call the tile search successful.',
  'metrics':'Retain every attempt, candidate/mark counts, nodes/forced/branches/backtracks, construction/check/native costs and whole memory scope. Structural success is unknown quantified rule/reference discovery; no RL effect inferred from weight changes or one cohort.',
  'suggested_initial_caps':'Six cases, no learning; prospectively one shared flat-line ceiling around48 and explicit term/formula/candidate/work construction ceilings selected with B before Source. Unknown construction is a useful honest outcome. No actual cap/grant is frozen by this recommendation.'},
 'independent_checker_and_controls_after_ABI':[
  'Reconstruct the complete declared candidate universe and selected t/m/earlier-reference proof DAG independently; decode the selected proof only, no teacher or prover callback.',
  'Capture-free substitution under shadowing, alpha-renaming, fresh variable collision, invalid distribute freshness, improper generalization under hidden local assumptions, term arity and exact native bool/int references.',
  'All eight payload shapes; instantiate implication versus derived instance; actual equality-template occurrences; future/self-reference, wrong theory axiom, goal/last-line association and schema-field mutation negatives.',
  'Whole original C1 raw protocol has theory schemas=[] and blocks=[]; do not add derived axioms. ASCII names and one canonical binder convention compatible with both kernels; C1 rejection/unknown is not overridden by B alpha acceptance.',
  'Tiny finite universe complete enumeration equivalence and bounded-negative scope; all malformed/budget outcomes retained. No checker or search function is authorized by this design.'],
 'scope':'No theorem novelty claim, no universal fixed finite Wang palette or full first-order completeness, no induction result, no actor/RL benefit. All prior once identities stay spent; new functional Source and any execution require Root next scope.'}
rp=save('U-independent-recommendation-and-cohort-provenance-v1.json',metadata)
print(json.dumps({'cohort':cp,'focused_evidence':E,'recommendation':rp},indent=2))
