"""Independent finite-row binding audit and exact same-catalogue fact-set BFS.

The published, Source-peer-reviewed basis/schema witness set is an explicit
input. This module independently enumerates its whole point universe and its
references; it does not certify the producer's logical catalogue construction.
Every admitted whole certificate still needs actual native C1 and independent B.
No project imports, IO, CLI, subject calls or executable module-body fixtures.
"""
import collections
import itertools
import json
import math
import time

VERSION = 'U-INDEPENDENT-FINITE-BASIS-AUDIT-v1'
VERIFY_LIMITS = dict(wall_seconds=15, max_work=100000000,
                     max_depth=128, max_candidates=100000)
BFS_LIMITS = dict(wall_seconds=2, max_states=20000,
                  max_transitions=500000, max_work=20000000)
SCOPE = ('Finite Source-reviewed basis/schema witnesses only. Independent full '
         'row/ref/literal-mark binding, not independent reconstruction of the '
         'logical basis generator. Actual native C1 and independent B must '
         'check every whole chosen proof. No full FOL unprovability claim.')
ZERO_FIELDS = {
    'axiom': {'rule', 'formula', 'name'},
    'tautology': {'rule', 'formula'},
    'refl': {'rule', 'formula'},
    'instantiate': {'rule', 'formula', 'universal', 'term'},
    'distribute': {'rule', 'formula', 'variable', 'antecedent', 'consequent'},
    'eq_subst': {'rule', 'formula', 'variable', 'template', 'left', 'right'},
}


class InputError(ValueError):
    pass


class BudgetExceeded(Exception):
    pass


def _need(ok, message):
    if not ok:
        raise InputError(message)


class _Meter:
    def __init__(self, limits, defaults):
        self.start = time.perf_counter()
        limits = dict(defaults) if limits is None else limits
        _need(type(limits) is dict and set(limits) == set(defaults), 'limits fields')
        w = limits['wall_seconds']
        _need(type(w) in (int, float) and math.isfinite(w) and 0 < w <= 60,
              'wall limit')
        _need(all(type(v) is int and v >= 0 for k, v in limits.items()
                  if k != 'wall_seconds'), 'integer limits')
        self.limits = dict(limits)
        self.work = 0

    def tick(self, n=1):
        if n > self.limits['max_work'] - self.work:
            raise BudgetExceeded('WORK')
        self.work += n
        if time.perf_counter() - self.start > self.limits['wall_seconds']:
            raise BudgetExceeded('WALL')

    def costs(self):
        return {'work': self.work, 'seconds': time.perf_counter() - self.start,
                'scope': 'Own preparation and audit/search/certificate construction included; returned serialization/caller tail excluded. Cooperative, not an OS quota.'}


def _fields(x, keys):
    _need(type(x) is dict and len(x) == len(keys)
          and all(type(k) is str for k in x) and set(x) == set(keys), 'record fields')


def _copy(x, m, depth=0):
    m.tick()
    if depth > m.limits.get('max_depth', 128): raise BudgetExceeded('DEPTH')
    if x is None or type(x) in (bool, int):
        return x
    if type(x) is float:
        _need(math.isfinite(x), 'nonfinite JSON'); return x
    if type(x) is str:
        m.tick(len(x)); return x
    if type(x) is list:
        m.tick(len(x)); return [_copy(y, m, depth + 1) for y in x]
    _need(type(x) is dict, 'native JSON')
    m.tick(len(x))
    _need(all(type(k) is str for k in x), 'native JSON keys')
    return {k: _copy(v, m, depth + 1) for k, v in x.items()}


def _key(x, m):
    # All callers supply already checked finite native JSON, not user objects.
    text = json.dumps(x, sort_keys=True, ensure_ascii=True,
                      separators=(',', ':'), allow_nan=False)
    m.tick(len(text)); return text


def _same(a, b, m):
    pending = [(a, b)]
    while pending:
        m.tick(); x, y = pending.pop()
        if type(x) is not type(y): return False
        if type(x) is dict:
            if set(x) != set(y): return False
            m.tick(len(x)); pending.extend((v, y[k]) for k, v in x.items())
        elif type(x) is list:
            if len(x) != len(y): return False
            m.tick(len(x)); pending.extend(zip(x, y))
        else:
            if type(x) is str: m.tick(len(x) + len(y))
            if x != y: return False
    return True


def _base(problem, bundle, m):
    _fields(problem, {'theory', 'goal', 'slots', 'profile'})
    _fields(bundle, {'schema', 'version', 'theory', 'goal', 'slots', 'profile',
                     'basis', 'instances', 'model', 'steps', 'costs', 'scope'})
    _need(type(bundle['schema']) is type(bundle['version']) is str
          and bundle['schema'] == 'U-finite-Hilbert8-point-model-v1'
          and bundle['version'] == 'U-FINITE-HILBERT8-BASIS-v1', 'bundle identity')
    _need(type(problem['slots']) is int and 1 <= problem['slots'] <= 64, 'slots')
    _fields(problem['profile'], {'ui_rounds', 'bridge_arity', 'max_tautology_atoms'})
    for k, cap in [('ui_rounds', 8), ('bridge_arity', 2), ('max_tautology_atoms', 16)]:
        _need(type(problem['profile'][k]) is int
              and 0 <= problem['profile'][k] <= cap, 'profile')
    for k in ('theory', 'goal', 'slots', 'profile'):
        _need(_same(_copy(problem[k], m), _copy(bundle[k], m), m), 'input binding')
    basis = bundle['basis']
    _fields(basis, {'instantiation_terms', 'terms', 'variables', 'formulas',
                    'templates', 'hole', 'stages'})
    basis = _copy(basis, m)
    for k in ('instantiation_terms', 'terms', 'formulas', 'templates'):
        _need(type(basis[k]) is list, 'basis list')
        keys = [_key(x, m) for x in basis[k]]
        _need(keys == sorted(set(keys)), 'canonical complete basis witness list')
    _need(type(basis['variables']) is list
          and all(type(v) is str for v in basis['variables'])
          and basis['variables'] == sorted(set(basis['variables']))
          and type(basis['hole']) is str, 'basis names')
    hole_number = 0
    while '__u_hole' + str(hole_number) in basis['variables']:
        m.tick(); hole_number += 1
    _need(basis['hole'] == '__u_hole' + str(hole_number), 'fresh catalogue hole')
    stages = basis['stages']
    _need(type(stages) is list, 'basis stages')
    labels = ['input'] + ['UI' + str(i + 1) for i in range(problem['profile']['ui_rounds'])] + ['equality', 'distribution', 'tautology']
    _need(len(stages) == len(labels), 'stage count')
    for row, label in zip(stages, labels):
        _fields(row, {'stage', 'formula_count', 'instance_count'})
        _need(type(row['stage']) is str and row['stage'] == label
              and type(row['formula_count']) is type(row['instance_count']) is int
              and 0 <= row['formula_count'] <= len(basis['formulas'])
              and 0 <= row['instance_count'] <= len(bundle['instances']), 'stage witness')
    formulas = basis['formulas']; keys = [_key(f, m) for f in formulas]
    index = {key: i for i, key in enumerate(keys)}
    _need(_key(problem['goal'], m) in index, 'goal in basis')
    instances = bundle['instances']; _need(type(instances) is list, 'instances')
    instances = _copy(instances, m); previous = None; zero = []
    for n, ins in enumerate(instances):
        m.tick(); _fields(ins, {'id', 'rule', 'line'})
        _need(ins['id'] == 'i' + str(n) and type(ins['rule']) is str
              and ins['rule'] in ZERO_FIELDS, 'instance identity')
        line = ins['line']; _fields(line, ZERO_FIELDS[ins['rule']])
        _need(line['rule'] == ins['rule'], 'instance rule')
        key = _key(line, m); _need(previous is None or previous < key,
                                 'canonical zero order'); previous = key
        formula = _key(line['formula'], m)
        _need(formula in index, 'instance formula in basis')
        if ins['rule'] == 'axiom':
            _need(type(line['name']) is str
                  and line['name'] in problem['theory']['axioms']
                  and _same(line['formula'], problem['theory']['axioms'][line['name']], m),
                  'given exact supplied axiom')
        zero.append((ins['id'], line, index[formula]))
    implications = []; universals = []
    for i, f in enumerate(formulas):
        m.tick()
        _need(type(f) is list and len(f) > 0 and type(f[0]) is str, 'formula witness')
        if f[0] == 'imp' and len(f) == 3:
            a, b = _key(f[1], m), _key(f[2], m)
            if a in index and b in index: implications.append((i, index[a], index[b]))
        if f[0] == 'all' and len(f) == 3 and type(f[1]) is str:
            p = _key(f[2], m)
            if p in index: universals.append((i, index[p], f[1]))
    return basis, formulas, keys, index, zero, implications, universals


def _expected(problem, formulas, keys, zero, implications, universals, m):
    n = problem['slots']; goal = _key(problem['goal'], m)
    for slot in range(n):
        for iid, line, out in zero:
            m.tick()
            if slot == n - 1 and keys[out] != goal: continue
            cid = 'r' + str(slot) + ':' + iid
            yield cid, {'id': cid, 't': ['slot:' + str(slot)],
                        'm': [['out:' + str(slot), keys[out]]]}, {
                            'slot': slot, 'line': line, 'instance': iid}
        for fi, antecedent, consequent in implications:
            if slot == n - 1 and keys[consequent] != goal: continue
            for a in range(slot):
                for b in range(slot):
                    m.tick(); marks = {'out:' + str(slot): keys[consequent]}
                    good = True
                    for p, v in [('out:' + str(a), keys[antecedent]),
                                 ('out:' + str(b), keys[fi])]:
                        if p in marks and marks[p] != v: good = False; break
                        marks[p] = v
                    if not good: continue
                    cid = 'r' + str(slot) + ':mp:' + str(fi) + ':' + str(a) + ':' + str(b)
                    yield cid, {'id': cid, 't': ['slot:' + str(slot)],
                                'm': [[p, v] for p, v in sorted(marks.items())]}, {
                                    'slot': slot, 'line': {'rule': 'mp',
                                    'formula': formulas[consequent],
                                    'antecedent': a, 'implication': b}, 'instance': None}
        for fi, body, variable in universals:
            if slot == n - 1 and keys[fi] != goal: continue
            for source in range(slot):
                m.tick(); cid = 'r' + str(slot) + ':gen:' + str(fi) + ':' + str(source)
                yield cid, {'id': cid, 't': ['slot:' + str(slot)],
                            'm': sorted([['out:' + str(slot), keys[fi]],
                                         ['out:' + str(source), keys[body]]])}, {
                                'slot': slot, 'line': {'rule': 'generalize',
                                'formula': formulas[fi], 'source': source,
                                'variable': variable}, 'instance': None}


def _universe(problem, bundle, m):
    basis, forms, keys, index, zero, implications, universals = _base(problem, bundle, m)
    model = bundle['model']; _fields(model, {'required', 'candidates'})
    _need(type(model['candidates']) is list, 'candidate list')
    if len(model['candidates']) > m.limits['max_candidates']:
        raise BudgetExceeded('CANDIDATES')
    _need(_same(model['required'], ['slot:' + str(i) for i in range(problem['slots'])], m),
          'all root obligations')
    byid = {}
    for cand in model['candidates']:
        m.tick(); _fields(cand, {'id', 't', 'm'})
        _need(type(cand['id']) is str and cand['id'] not in byid, 'candidate id')
        byid[cand['id']] = cand
    _need(type(bundle['steps']) is dict and set(bundle['steps']) == set(byid), 'step universe')
    seen = set()
    for cid, candidate, step in _expected(problem, forms, keys, zero, implications, universals, m):
        m.tick()
        if len(seen) >= m.limits['max_candidates']: raise BudgetExceeded('CANDIDATES')
        _need(cid in byid and cid not in seen, 'missing candidate')
        _need(_same(candidate, byid[cid], m), 'entire literal candidate')
        _need(_same(step, bundle['steps'][cid], m), 'entire native step')
        seen.add(cid)
    _need(seen == set(byid), 'extra candidate')
    return byid, forms, keys, index, zero, implications, universals


def _selection(problem, bundle, selected, byid, m):
    _need(type(selected) is list and len(selected) == problem['slots']
          and all(type(x) is str for x in selected)
          and len(set(selected)) == len(selected), 'complete unique selection')
    totals = collections.Counter(); marks = {}; rows = {}
    for cid in selected:
        m.tick(); _need(cid in byid, 'unknown selected id'); c = byid[cid]
        totals.update(c['t'])
        for p, v in c['m']:
            m.tick(); _need(p not in marks or marks[p] == v, 'literal m disagreement'); marks[p] = v
        step = bundle['steps'][cid]; _need(step['slot'] not in rows, 'duplicate row')
        rows[step['slot']] = _copy(step['line'], m)
    _need(dict(totals) == dict.fromkeys(bundle['model']['required'], 1), 'exact t cover')
    _need(set(rows) == set(range(problem['slots'])), 'all selected rows')
    proof = [rows[i] for i in range(problem['slots'])]
    for i, line in enumerate(proof):
        m.tick()
        _need(marks['out:' + str(i)] == _key(line['formula'], m), 'selected out formula')
        if line['rule'] == 'mp':
            a, b = line['antecedent'], line['implication']
            _need(type(a) is type(b) is int and 0 <= a < i and 0 <= b < i, 'earlier MP refs')
            _need(_same(proof[b]['formula'], ['imp', proof[a]['formula'], line['formula']], m),
                  'actual earlier MP formulas')
        elif line['rule'] == 'generalize':
            source = line['source']; _need(type(source) is int and 0 <= source < i,
                                           'earlier GEN ref')
            _need(_same(line['formula'], ['all', line['variable'], proof[source]['formula']], m),
                  'actual earlier GEN formula')
    _need(_same(proof[-1]['formula'], problem['goal'], m), 'actual final target')
    return proof


def _verify(problem, bundle, selected, limits):
    m = _Meter(limits, VERIFY_LIMITS)
    try:
        data = _universe(problem, bundle, m)
        proof = None if selected is None else _selection(problem, bundle, selected, data[0], m)
        m.tick()
        return {'status': 'VERIFIED', 'version': VERSION, 'proof': proof,
                'candidates': len(data[0]), 'reason': None, 'costs': m.costs(), 'scope': SCOPE}
    except (InputError, BudgetExceeded) as e:
        return {'status': 'UNKNOWN' if type(e) is BudgetExceeded else 'REJECTED',
                'version': VERSION, 'proof': None, 'candidates': None,
                'reason': str(e), 'costs': m.costs(), 'scope': SCOPE}


def verify_bundle(problem, bundle, *, limits=None):
    return _verify(problem, bundle, None, limits)


def verify_selection(problem, bundle, selected, *, limits=None):
    _need(selected is not None, 'selection cannot be null')
    return _verify(problem, bundle, selected, limits)


def bounded_bfs(problem, bundle, limits=None):
    """Exact EMPTY-start finite witness-set BFS, not a full FOL prover."""
    m = _Meter(limits, BFS_LIMITS); states = []; parents = []; actions = []; depths = []
    counts = {'states': 0, 'expanded': 0, 'transitions': 0}
    try:
        _, forms, keys, index, zero, imps, alls = _base(problem, bundle, m)
        goal = index[_key(problem['goal'], m)]; width = max(1, (len(forms) + 63) // 64)
        if m.limits['max_states'] < 1: raise BudgetExceeded('STATES')
        states.append(0); parents.append(None); actions.append(None); depths.append(0)
        seen = {0}; counts['states'] = 1; cursor = 0; found = None
        def add(out, action, parent):
            nonlocal found
            m.tick(width)
            bit = 1 << out
            if states[parent] & bit: return
            if counts['transitions'] >= m.limits['max_transitions']:
                raise BudgetExceeded('TRANSITIONS')
            counts['transitions'] += 1; mask = states[parent] | bit
            if mask in seen: return
            if len(states) >= m.limits['max_states']: raise BudgetExceeded('STATES')
            m.tick(width + 5); seen.add(mask); states.append(mask); parents.append(parent)
            actions.append((out, action)); depths.append(depths[parent] + 1)
            counts['states'] += 1
            if out == goal: found = len(states) - 1
        while cursor < len(states) and found is None:
            m.tick(width); q = cursor; cursor += 1
            if depths[q] >= problem['slots']: continue
            counts['expanded'] += 1; mask = states[q]
            for iid, line, out in zero:
                add(out, ('zero', iid), q)
                if found is not None: break
            if found is not None: break
            for fi, a, b in imps:
                m.tick(width)
                if (mask & (1 << a)) and (mask & (1 << fi)):
                    add(b, ('mp', a, fi), q)
                    if found is not None: break
            if found is not None: break
            for fi, body, variable in alls:
                m.tick(width)
                if mask & (1 << body):
                    add(fi, ('generalize', body, variable), q)
                    if found is not None: break
        if found is None:
            return {'schema': 'U-finite-basis-fact-set-BFS-v1', 'status': 'NOT_DERIVABLE',
                    'proof': None, 'shortest_lines': None, 'reason': 'FINITE_BASIS_LINE_EXHAUSTED',
                    'counts': counts, 'costs': m.costs(), 'scope': SCOPE}
        path = []
        while parents[found] is not None:
            m.tick(); path.append(actions[found]); found = parents[found]
        path.reverse(); lines = []; locations = {}; zero_byid = {i: line for i, line, out in zero}
        for out, action in path:
            m.tick(); kind = action[0]
            if kind == 'zero': line = _copy(zero_byid[action[1]], m)
            elif kind == 'mp':
                line = {'rule': 'mp', 'formula': _copy(forms[out], m),
                        'antecedent': locations[action[1]], 'implication': locations[action[2]]}
            else:
                line = {'rule': 'generalize', 'formula': _copy(forms[out], m),
                        'source': locations[action[1]], 'variable': action[2]}
            locations[out] = len(lines); lines.append(line)
        _need(len(lines) <= problem['slots'] and _same(lines[-1]['formula'], problem['goal'], m), 'BFS reconstruction')
        m.tick()
        return {'schema': 'U-finite-basis-fact-set-BFS-v1', 'status': 'DERIVABLE',
                'proof': lines, 'shortest_lines': len(lines), 'reason': None,
                'counts': counts, 'costs': m.costs(), 'scope': SCOPE}
    except BudgetExceeded as e:
        return {'schema': 'U-finite-basis-fact-set-BFS-v1', 'status': 'UNKNOWN',
                'proof': None, 'shortest_lines': None, 'reason': str(e),
                'counts': counts, 'costs': m.costs(), 'scope': SCOPE}


def _brute(model, cap=10000):
    # Qualification-only complete finite product, not a benchmark solver/control.
    required = model['required']; groups = [[c for c in model['candidates']
             if c['t'] == [p]] for p in required]
    size = 1
    for g in groups:
        size *= len(g); _need(size <= cap, 'tiny complete product cap')
    solutions = []; count = 0
    for selection in itertools.product(*groups):
        count += 1; marks = {}; good = True
        for c in selection:
            for p, v in c['m']:
                if p in marks and marks[p] != v: good = False; break
                marks[p] = v
            if not good: break
        if good: solutions.append(sorted(c['id'] for c in selection))
    return {'assignments': count, 'solutions': solutions}


def qualify(compiler, engine, emit=None):
    """Inert recipes: five tiny complete universes, only under future grant."""
    start = time.perf_counter()
    p = ['pred', 'P', []]; q = ['pred', 'Q', []]; c = ['fun', 'c', []]
    pc = ['pred', 'P', [c]]; px = ['pred', 'P', [['var', 'x']]]
    profile = {'ui_rounds': 1, 'bridge_arity': 0, 'max_tautology_atoms': 4}
    specs = [
        ('given', {'functions': {}, 'predicates': {'P': 0}, 'axioms': {'h': p}}, p, 1),
        ('MP', {'functions': {}, 'predicates': {'P': 0, 'Q': 0},
                'axioms': {'h': p, 'j': ['imp', p, q]}}, q, 3),
        ('UI', {'functions': {'c': 0}, 'predicates': {'P': 1},
                'axioms': {'h': ['all', 'x', px]}}, pc, 3),
        ('GEN', {'functions': {'c': 0}, 'predicates': {'P': 1},
                 'axioms': {'h': pc}}, ['all', 'x', pc], 2),
        ('finite-negative', {'functions': {}, 'predicates': {'P': 0, 'Q': 0},
                            'axioms': {'h': p}}, q, 1),
    ]
    buildlimits = {'wall_seconds': 2, 'max_work': 10000000, 'max_depth': 64,
                   'max_basis': 1000, 'max_instances': 1000, 'max_candidates': 20000}
    el = {'wall_seconds': 1, 'max_nodes': 10000, 'max_events': 64}
    records = []; saved = None
    for name, theory, goal, slots in specs:
        problem = {'theory': theory, 'goal': goal, 'slots': slots, 'profile': profile}
        built = compiler.build(theory, goal, slots, profile, buildlimits)
        _need(built['status'] == 'COMPLETE', 'qualification build complete')
        bundle = built['bundle']; v = verify_bundle(problem, bundle)
        _need(v['status'] == 'VERIFIED', 'qualification universe')
        brute = _brute(bundle['model']); answer = engine.solve(bundle['model'], el)
        _need(answer['status'] == ('SAT' if brute['solutions'] else 'UNSAT'), 'tiny exhaustive equality')
        _need(answer['entry_state'] is not None and answer['restored_state'] == answer['entry_state'], 'qualification rollback images')
        selected = decoded = None
        if answer['status'] == 'SAT':
            _need(sorted(answer['selected']) in brute['solutions'], 'tiny witness')
            selected = verify_selection(problem, bundle, answer['selected'])
            _need(selected['status'] == 'VERIFIED', 'tiny selected binding')
            decoded = compiler.decode(bundle, answer['selected'])
            _need(decoded['status'] == 'UNVERIFIED_CERTIFICATE' and decoded['proof'] == selected['proof']
                  and decoded['target'] == goal, 'complete native decoder agreement')
        bfs = bounded_bfs(problem, bundle)
        _need(bfs['status'] == ('DERIVABLE' if brute['solutions'] else 'NOT_DERIVABLE'), 'bounded BFS/exhaustive')
        record = {'id': 'U-' + name, 'problem': problem, 'build': built, 'bundle_audit': v,
                  'brute': brute, 'answer': answer, 'selection_audit': selected,
                  'decoded': decoded, 'BFS': bfs}
        if name == 'MP': saved = (problem, bundle, answer)
        records.append(record)
        if emit is not None and name != 'finite-negative': emit(record['id'], record)
    problem, bundle, answer = saved; mutations = []
    def clone(x): return json.loads(json.dumps(x, sort_keys=True, separators=(',', ':')))
    forged = clone(bundle); forged['model']['candidates'].pop()
    mutations.append(('missing-row', verify_bundle(problem, forged)))
    forged = clone(bundle); forged['model']['candidates'][0]['m'][0][1] = 'forged'
    mutations.append(('wrong-literal', verify_bundle(problem, forged)))
    forged = clone(bundle); cid = next(k for k, v in forged['steps'].items() if v['line']['rule'] == 'mp')
    forged['steps'][cid]['line']['antecedent'] = problem['slots']
    mutations.append(('future-reference', verify_bundle(problem, forged)))
    ids = list(answer['selected']); ids[0] = ids[1]
    mutations.append(('duplicate-cover', verify_selection(problem, bundle, ids)))
    _need(all(v['status'] == 'REJECTED' for k, v in mutations), 'isolated mutation negatives')
    limited = dict(BFS_LIMITS); limited['max_states'] = 0
    refusal = bounded_bfs(problem, bundle, limited)
    _need(refusal['status'] == 'UNKNOWN' and refusal['proof'] is None, 'bounded refusal unknown')
    records[-1]['data_only_mutations'] = [{'id': k, 'receipt': v} for k, v in mutations]
    records[-1]['BFS_cap_refusal'] = refusal
    if emit is not None: emit(records[-1]['id'], records[-1])
    return {'status': 'PASS', 'version': VERSION,
            'counts': {'build': 5, 'solve': 5, 'decode': 4, 'BFS': 6,
                       'records': 5, 'data_only_mutations': 4},
            'seconds': time.perf_counter() - start, 'scope': SCOPE,
            'records': [r['id'] for r in records]}
