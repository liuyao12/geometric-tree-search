"""Restricted independent FPC1 query writer; future authenticated actual only.

No certificate/proof intake, filesystem, provider, checker, builder or goal-name
dispatch. The only import is Python's byte-identity hash. Import runs no fixture.
"""

import hashlib

VERSION = "L-tiny-FPC-query-encoder-v1"
RETURN_SCHEMA = "independent-tiny-FPC-query-encoding-v1"
_OWNER = object()
LIMITS = {"symbols_per_sort": 4, "axioms": 4, "hypotheses": 4,
          "total_nodes": 256, "depth": 32, "natural": 65535,
          "query_bytes": 4096}


class TinyQueryInputError(ValueError):
    pass


def is_owned_error(error):
    return type(error) is TinyQueryInputError and getattr(error, "_owner", None) is _OWNER


class _Call:
    def __init__(self, check):
        self.check = check
        self.first = None
        self.nodes = 0

    def tick(self):
        if self.first is not None:
            raise self.first
        try:
            self.check()
        except BaseException as error:
            self.first = error
            raise

    def need(self, condition, message):
        if self.first is not None:
            raise self.first
        if not condition:
            error = TinyQueryInputError(message)
            error._owner = _OWNER
            raise error


def _natural(value, call):
    call.tick()
    call.need(type(value) is int and 0 <= value <= LIMITS["natural"], "bounded exact natural")
    return value


def _vector(value, maximum, call):
    call.tick()
    call.need(type(value) in (list, tuple) and len(value) <= maximum, "bounded vector")
    return value


def _tree(raw, sort, signatures, depth, call):
    call.tick()
    call.nodes += 1
    call.need(depth <= LIMITS["depth"] and call.nodes <= LIMITS["total_nodes"], "tiny syntax limit")
    call.need(type(raw) in (list, tuple) and bool(raw) and type(raw[0]) is str, "typed core node")
    tag = raw[0]
    if sort == "T":
        if tag == "var":
            call.need(len(raw) == 2, "var fields")
            variable = _natural(raw[1], call)
            return (tag, variable), {variable}
        call.need(tag == "fun" and len(raw) == 3, "term constructor")
        symbol = _natural(raw[1], call)
        call.need(symbol < len(signatures[0]), "function symbol")
        call.need(type(raw[2]) in (list, tuple) and len(raw[2]) == 0, "nullary function")
        return (tag, symbol, ()), set()
    if tag == "pred":
        call.need(len(raw) == 3, "pred fields")
        symbol = _natural(raw[1], call)
        call.need(symbol < len(signatures[1]), "predicate symbol")
        args = _vector(raw[2], 1, call)
        call.need(len(args) == signatures[1][symbol], "predicate arity")
        normalized, free = [], set()
        for arg in args:
            call.tick()
            value, child_free = _tree(arg, "T", signatures, depth + 1, call)
            normalized.append(value)
            free.update(child_free)
        return (tag, symbol, tuple(normalized)), free
    if tag in ("eq", "imp"):
        call.need(len(raw) == 3, "binary fields")
        child_sort = "T" if tag == "eq" else "F"
        left, left_free = _tree(raw[1], child_sort, signatures, depth + 1, call)
        right, right_free = _tree(raw[2], child_sort, signatures, depth + 1, call)
        return (tag, left, right), left_free | right_free
    if tag == "not":
        call.need(len(raw) == 2, "not fields")
        body, free = _tree(raw[1], "F", signatures, depth + 1, call)
        return (tag, body), free
    call.need(tag == "all" and len(raw) == 3, "formula constructor")
    variable = _natural(raw[1], call)
    body, free = _tree(raw[2], "F", signatures, depth + 1, call)
    return (tag, variable, body), free - {variable}


def _normalize(raw, call):
    call.tick()
    keys = {"version", "claim_mode", "function_arities", "predicate_arities",
            "theory_profile", "finite_axioms", "Gamma", "goal"}
    call.need(type(raw) is dict and set(raw) == keys, "exact semantic query fields")
    call.need(type(raw["version"]) is int and raw["version"] == 1, "version1")
    call.need(type(raw["claim_mode"]) is int and raw["claim_mode"] in (0, 1), "mode0/1")
    call.need(type(raw["theory_profile"]) is int and raw["theory_profile"] == 0, "finite profile0 only")
    functions, predicates = [], []
    for value in _vector(raw["function_arities"], LIMITS["symbols_per_sort"], call):
        call.tick()
        call.need(type(value) is int and value == 0, "nullary functions only")
        functions.append(value)
    for value in _vector(raw["predicate_arities"], LIMITS["symbols_per_sort"], call):
        call.tick()
        call.need(type(value) is int and value in (0, 1), "nullary/unary predicates only")
        predicates.append(value)
    signatures = (tuple(functions), tuple(predicates))
    axioms, gamma = [], []
    for raw_formula in _vector(raw["finite_axioms"], LIMITS["axioms"], call):
        call.tick()
        value, free = _tree(raw_formula, "F", signatures, 1, call)
        call.need(not free, "closed finite axiom")
        axioms.append(value)
    for raw_formula in _vector(raw["Gamma"], LIMITS["hypotheses"], call):
        call.tick()
        value, unused = _tree(raw_formula, "F", signatures, 1, call)
        gamma.append(value)
    goal, goal_free = _tree(raw["goal"], "F", signatures, 1, call)
    if raw["claim_mode"] == 0:
        call.need(not gamma and not goal_free, "closed theorem with empty Gamma")
    return {"version": 1, "claim_mode": raw["claim_mode"],
            "function_arities": signatures[0], "predicate_arities": signatures[1],
            "theory_profile": 0, "finite_axioms": tuple(axioms),
            "Gamma": tuple(gamma), "goal": goal}


def _emit_natural(value, output, call):
    call.tick()
    while value >= 128:
        call.tick()
        output.append((value & 127) | 128)
        value >>= 7
    output.append(value)


def _emit_tree(tree, sort, output, call):
    stack = [(sort, tree)]
    while stack:
        call.tick()
        kind, value = stack.pop()
        if kind == "N":
            _emit_natural(value, output, call)
            continue
        tag = value[0]
        if kind == "T":
            _emit_natural(0 if tag == "var" else 1, output, call)
            _emit_natural(value[1], output, call)
            if tag == "fun":
                _emit_natural(0, output, call)
            continue
        _emit_natural({"pred": 0, "eq": 1, "not": 2, "imp": 3, "all": 4}[tag], output, call)
        if tag == "pred":
            _emit_natural(value[1], output, call)
            _emit_natural(len(value[2]), output, call)
            for child in reversed(value[2]):
                call.tick()
                stack.append(("T", child))
        elif tag in ("eq", "imp"):
            child_sort = "T" if tag == "eq" else "F"
            stack.append((child_sort, value[2]))
            stack.append((child_sort, value[1]))
        elif tag == "not":
            stack.append(("F", value[1]))
        else:
            _emit_natural(value[1], output, call)
            stack.append(("F", value[2]))
        call.need(len(output) <= LIMITS["query_bytes"], "byte limit")


def _ordinary(value, call):
    call.tick()
    if type(value) is tuple:
        result = []
        for child in value:
            call.tick()
            result.append(_ordinary(child, call))
        return result
    if type(value) is dict:
        result = {}
        for key, child in value.items():
            call.tick()
            result[key] = _ordinary(child, call)
        return result
    return value


def encode_tiny_declared_query(query, *, check):
    """Encode only the explicit restricted profile0 semantic declaration."""
    call = _Call(check)
    call.tick()
    q = _normalize(query, call)
    output = bytearray(b"FPC1")
    _emit_natural(1, output, call)
    _emit_natural(q["claim_mode"], output, call)
    for name in ("function_arities", "predicate_arities"):
        call.tick()
        _emit_natural(len(q[name]), output, call)
        for arity in q[name]:
            call.tick()
            _emit_natural(arity, output, call)
    _emit_natural(0, output, call)
    for name in ("finite_axioms", "Gamma"):
        call.tick()
        _emit_natural(len(q[name]), output, call)
        for formula in q[name]:
            call.tick()
            _emit_tree(formula, "F", output, call)
    _emit_tree(q["goal"], "F", output, call)
    call.need(len(output) <= LIMITS["query_bytes"], "byte limit")
    call.tick()
    encoded = bytes(output)
    receipt = {"schema": RETURN_SCHEMA, "version": VERSION, "complete": True,
               "semantic_query": _ordinary(q, call),
               "query_identity": {"bytes": len(encoded), "sha256": hashlib.sha256(encoded).hexdigest()},
               "limits": dict(LIMITS), "expanded_nodes": call.nodes,
               "scope": "Independent restricted FPC1 query encoding only; no certificate, proof or parser authority"}
    call.tick()
    return {"query_bytes": encoded, "receipt": receipt}
