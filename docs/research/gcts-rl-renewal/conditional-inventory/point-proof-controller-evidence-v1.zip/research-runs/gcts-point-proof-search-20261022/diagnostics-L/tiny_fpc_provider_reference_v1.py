"""Independent complete tiny row inventories, not a production provider.

Scope: profile zero, nullary functions, nullary/unary predicates, b<=3, n<=4.
No provider, checker, builder, encoder, proof, fixture or other module is imported.
No function is invoked on import. All execution belongs in future once custody.
"""

VERSION = "L-tiny-FPC-provider-reference-v1"
_MARKER = object()
_FIELDS = ("rule_tag", "subtag", "witness", "formula", "references", "t", "m")


class TinyReferenceInputError(ValueError):
    pass


def is_owned_error(error):
    return type(error) is TinyReferenceInputError and getattr(error, "_marker", None) is _MARKER


class _Call:
    def __init__(self, check):
        self.check = check
        self.first = None
        self.syntax_nodes = 0

    def tick(self):
        if self.first is not None:
            raise self.first
        try:
            self.check()
        except BaseException as error:
            self.first = error
            raise

    def need(self, condition, message):
        if self.first is not None:
            raise self.first
        if not condition:
            error = TinyReferenceInputError(message)
            error._marker = _MARKER
            raise error


def _nat(value, call):
    call.tick()
    call.need(type(value) is int and 0 <= value <= 65535, "bounded strict natural")
    return value


def _seq(value, length, call):
    call.tick()
    call.need(type(value) in (list, tuple), "sequence")
    if length is not None:
        call.need(len(value) == length, "exact sequence length")
    return value


def _term(raw, q, call):
    call.syntax_nodes += 1
    call.need(call.syntax_nodes <= 256, "tiny query syntax limit")
    _seq(raw, None, call)
    call.need(bool(raw) and type(raw[0]) is str, "nonempty typed term")
    if raw[0] == "var":
        _seq(raw, 2, call)
        return ("var", _nat(raw[1], call))
    call.need(raw[0] == "fun", "term tag")
    _seq(raw, 3, call)
    symbol = _nat(raw[1], call)
    call.need(symbol < len(q["function_arities"]), "function symbol")
    _seq(raw[2], 0, call)
    return ("fun", symbol, ())


def _formula(raw, q, call, depth=1):
    call.syntax_nodes += 1
    call.need(call.syntax_nodes <= 256 and depth <= 32, "tiny query syntax limit")
    _seq(raw, None, call)
    call.need(bool(raw) and type(raw[0]) is str, "nonempty typed formula")
    tag = raw[0]
    if tag == "pred":
        _seq(raw, 3, call)
        symbol = _nat(raw[1], call)
        call.need(symbol < len(q["predicate_arities"]), "predicate symbol")
        _seq(raw[2], q["predicate_arities"][symbol], call)
        args = []
        for arg in raw[2]:
            call.tick()
            args.append(_term(arg, q, call))
        return ("pred", symbol, tuple(args))
    if tag in ("eq", "imp"):
        _seq(raw, 3, call)
        if tag == "eq":
            return (tag, _term(raw[1], q, call), _term(raw[2], q, call))
        return (tag, _formula(raw[1], q, call, depth+1), _formula(raw[2], q, call, depth+1))
    if tag == "not":
        _seq(raw, 2, call)
        return (tag, _formula(raw[1], q, call, depth+1))
    call.need(tag == "all", "formula tag")
    _seq(raw, 3, call)
    return (tag, _nat(raw[1], call), _formula(raw[2], q, call, depth+1))


def _size_and_ids(tree, call):
    call.tick()
    tag = tree[0]
    if tag == "var":
        return 1, {tree[1]}
    if tag in ("fun", "pred"):
        children = tree[2]
        ids = set()
    elif tag in ("eq", "imp"):
        children = tree[1:]
        ids = set()
    elif tag == "not":
        children = tree[1:]
        ids = set()
    else:
        children = tree[2:]
        ids = {tree[1]}
    size = 1
    for child in children:
        call.tick()
        child_size, child_ids = _size_and_ids(child, call)
        size += child_size
        ids.update(child_ids)
    return size, ids


def _fv(tree, bound, call):
    call.tick()
    tag = tree[0]
    if tag == "var":
        return set() if tree[1] in bound else {tree[1]}
    if tag in ("fun", "pred"):
        children = tree[2]
    elif tag == "all":
        return _fv(tree[2], bound | {tree[1]}, call)
    else:
        children = tree[1:]
    result = set()
    for child in children:
        call.tick()
        result.update(_fv(child, bound, call))
    return result


def _within(tree, b, call):
    size, ids = _size_and_ids(tree, call)
    if size > b:
        return False
    for variable in ids:
        call.tick()
        if variable >= b:
            return False
    return True


def _query(raw, call):
    call.tick()
    keys = {"version", "claim_mode", "function_arities", "predicate_arities", "theory_profile", "finite_axioms", "Gamma", "goal"}
    call.need(type(raw) is dict and set(raw) == keys, "exact tiny semantic query")
    call.need(type(raw["version"]) is int and raw["version"] == 1, "version")
    call.need(type(raw["claim_mode"]) is int and raw["claim_mode"] in (0,1), "mode")
    call.need(type(raw["theory_profile"]) is int and raw["theory_profile"] == 0, "tiny finite profile only")
    functions = []
    function_input = _seq(raw["function_arities"], None, call)
    call.need(len(function_input) <= 4, "tiny function count")
    for arity in function_input:
        call.tick()
        call.need(type(arity) is int and arity == 0, "tiny nullary functions only")
        functions.append(arity)
    predicates = []
    predicate_input = _seq(raw["predicate_arities"], None, call)
    call.need(len(predicate_input) <= 4, "tiny predicate count")
    for arity in predicate_input:
        call.tick()
        call.need(type(arity) is int and arity in (0,1), "tiny nullary/unary predicates only")
        predicates.append(arity)
    q = {"version":1, "claim_mode":raw["claim_mode"], "theory_profile":0,
         "function_arities":tuple(functions), "predicate_arities":tuple(predicates)}
    finite = []
    finite_input = _seq(raw["finite_axioms"], None, call)
    call.need(len(finite_input) <= 4, "tiny axiom count")
    for formula in finite_input:
        call.tick()
        value = _formula(formula, q, call)
        call.need(not _fv(value, set(), call), "finite axiom must be closed")
        finite.append(value)
    gamma = []
    gamma_input = _seq(raw["Gamma"], None, call)
    call.need(len(gamma_input) <= 4, "tiny Gamma count")
    for formula in gamma_input:
        call.tick()
        gamma.append(_formula(formula, q, call))
    q["finite_axioms"] = tuple(finite)
    q["Gamma"] = tuple(gamma)
    q["goal"] = _formula(raw["goal"], q, call)
    if q["claim_mode"] == 0:
        call.need(not gamma and not _fv(q["goal"], set(), call), "theorem mode query")
    return q


def _syntax(q, b, call):
    terms = []
    for variable in range(b):
        call.tick()
        terms.append(("var", variable))
    for symbol in range(len(q["function_arities"])):
        call.tick()
        terms.append(("fun", symbol, ()))
    by_size = [[] for unused in range(b + 1)]
    for size in range(1, b + 1):
        call.tick()
        current = by_size[size]
        for symbol, arity in enumerate(q["predicate_arities"]):
            call.tick()
            if arity == 0 and size == 1:
                current.append(("pred", symbol, ()))
            elif arity == 1 and size == 2:
                for term in terms:
                    call.tick()
                    current.append(("pred", symbol, (term,)))
        if size == 3:
            for left in terms:
                call.tick()
                for right in terms:
                    call.tick()
                    current.append(("eq", left, right))
        if size >= 2:
            for body in by_size[size - 1]:
                call.tick()
                current.append(("not", body))
        for left_size in range(1, size - 1):
            call.tick()
            right_size = size - 1 - left_size
            for left in by_size[left_size]:
                call.tick()
                for right in by_size[right_size]:
                    call.tick()
                    current.append(("imp", left, right))
        if size >= 2:
            for variable in range(b):
                call.tick()
                for body in by_size[size - 1]:
                    call.tick()
                    current.append(("all", variable, body))
    formulas = []
    for size in range(1, b + 1):
        call.tick()
        formulas.extend(by_size[size])
    return terms, formulas


def _member(row, rule, subtag, witness, formula, refs, call):
    marks = {row: formula}
    for source, value in refs:
        call.tick()
        if source in marks and marks[source] != value:
            return None
        marks[source] = value
    m = []
    for point_row in sorted(marks):
        call.tick()
        m.append(((point_row,1), ("FPC", marks[point_row])))
    return {"rule_tag":rule,"subtag":subtag,"witness":witness,"formula":formula,
            "references":tuple(refs),"t":(((row,0),(1,1)),),"m":tuple(m)}


def _intrinsic(q, b, row, terms, formulas, call):
    members = []
    for index, value in enumerate(q["Gamma"]):
        call.tick()
        if _within(value, b, call):
            members.append(_member(row,0,None,index,value,(),call))
    # Minimum expanded output sizes for H1/H2/H3/Q1/Q2/Q3/E2 are
    # 5/13/9/4/10/4/7, respectively. Only E1 can fit b<=3.
    for term in terms:
        call.tick()
        value = ("eq",term,term)
        if _within(value, b, call):
            members.append(_member(row,1,6,(term,),value,(),call))
    for index, value in enumerate(q["finite_axioms"]):
        call.tick()
        if _within(value, b, call):
            members.append(_member(row,2,0,index,value,(),call))
    for antecedent in formulas:
        call.tick()
        for consequent in formulas:
            call.tick()
            implication = ("imp",antecedent,consequent)
            if not _within(implication,b,call):
                continue
            for first in range(row):
                call.tick()
                for second in range(row):
                    call.tick()
                    if first != second:
                        members.append(_member(row,3,None,(first,second),consequent,
                                               ((first,antecedent),(second,implication)),call))
    gamma_fv = set()
    for formula in q["Gamma"]:
        call.tick()
        gamma_fv.update(_fv(formula,set(),call))
    for body in formulas:
        call.tick()
        for variable in range(b):
            call.tick()
            output = ("all",variable,body)
            if variable in gamma_fv or not _within(output,b,call):
                continue
            for source in range(row):
                call.tick()
                members.append(_member(row,4,None,(source,variable),output,((source,body),),call))
    return members


def _freeze(value, call):
    call.tick()
    if value is None or type(value) in (str,int):
        return value
    if type(value) in (tuple,list):
        result = []
        for child in value:
            call.tick()
            result.append(_freeze(child,call))
        return tuple(result)
    call.need(type(value) is dict, "semantic record/value")
    result = {}
    for key, child in value.items():
        call.tick()
        call.need(type(key) is str, "record key")
        result[key] = _freeze(child,call)
    return result


def _plain(value, call):
    call.tick()
    if type(value) in (tuple,list):
        result = []
        for child in value:
            call.tick()
            result.append(_plain(child,call))
        return result
    if type(value) is dict:
        result = {}
        for key, child in value.items():
            call.tick()
            result[key] = _plain(child,call)
        return result
    return value


def enumerate_tiny_row_members(query, frame, row, *, selected=(), check):
    """Complete current legal projections, not public handles or proof authority."""
    call = _Call(check)
    call.tick()
    q = _query(query,call)
    call.need(type(frame) is dict and set(frame)=={"schema","rows","syntax_nodes"}, "frame record")
    call.need(frame["schema"]=="FPC-point-frame-v1", "frame schema")
    n,b = _nat(frame["rows"],call),_nat(frame["syntax_nodes"],call)
    call.need(1<=n<=4 and 1<=b<=3, "tiny reference scope only")
    row = _nat(row,call)
    call.need(row<n,"row in frame")
    terms,formulas = _syntax(q,b,call)
    occupied = set()
    marks = {(n-1,1):("FPC",q["goal"])}
    refcounts = {(n-1,1):1}
    for raw in _seq(selected,None,call):
        call.tick()
        member = _freeze(raw,call)
        call.need(type(member) is dict and set(member)==set(_FIELDS),"selected member projection")
        t = member["t"]
        call.need(type(t) is tuple and len(t)==1,"unit member t")
        call.need(type(t[0]) is tuple and len(t[0])==2,"unit member t pair")
        point,units = t[0]
        call.need(type(point) is tuple and len(point)==2,"unit member point")
        source_row = point[0]
        call.need(type(source_row) is int and 0<=source_row<n and point==(source_row,0)
                  and units==(1,1),"selected unit row")
        call.need(source_row not in occupied,"selected occupancy conflict")
        intrinsic = _intrinsic(q,b,source_row,terms,formulas,call)
        call.need(member in intrinsic,"independent selected intrinsic membership")
        for mark_point,value in member["m"]:
            call.tick()
            call.need(mark_point not in marks or marks[mark_point]==value,"selected mark conflict")
            marks[mark_point]=value
            refcounts[mark_point]=refcounts.get(mark_point,0)+1
        occupied.add(source_row)
    legal = []
    for member in _intrinsic(q,b,row,terms,formulas,call):
        call.tick()
        if row in occupied:
            continue
        compatible = True
        for point,value in member["m"]:
            call.tick()
            if point in marks and marks[point]!=value:
                compatible=False
        if compatible:
            legal.append(member)
    mark_rows=[]
    for point in sorted(marks):
        call.tick()
        mark_rows.append((point,marks[point],refcounts[point]))
    return _plain({"schema":"independent-tiny-FPC-row-members-v1","complete":True,
                   "frame":dict(frame),"row":row,"members":legal,
                   "counts":{"terms":len(terms),"formulas":len(formulas),"members":len(legal)},
                   "selected_rows":sorted(occupied),"m_items_with_refcounts":mark_rows,
                   "scope":"profile0/nullary functions/nullary-unary predicates/b<=3/n<=4 only; no proof or provider authority"},call)
