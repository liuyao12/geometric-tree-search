"""Ten additional tiny full-provider groups; no fixture executes on import.

Only ordinary stdlib identity/copy utilities are imported. Authenticated provider,
reference, encoder, checker and builders are injected by a future whole worker.
These low-level domain enumerations are not GCTS scheduler traces or proofs.
"""

import hashlib
import json

VERSION = "L-tiny-full-FPC-provider-controls-v1"
RETURN_SCHEMA = "independent-tiny-full-FPC-provider-controls-v1"
POPULATION = "tiny-full-provider10"
DECLARATION_IDENTITY = '0d72dce6742d07594fef597290c53b4582bd1743711c52f974ac6d29aa2f3b49'
CONTROL_IDS = (
    "duplicate-HYP-table-full-domain",
    "GEN-full-formula-valued-identities",
    "MP-full-formula-valued-identities",
    "E1-singleton-requires-full-EOF",
    "full-Gamma-outside-envelope-blocks-GEN",
    "full-Gamma-unblocked-GEN-counterpart",
    "out-of-envelope-goal-stays-boundary",
    "remote-ports-rebind-retained-parent",
    "initial-inspection-not-tried-remainder",
    "inventory-first-fault-no-prefix",
)
FIXTURE_COUNTS = {"duplicate-base": 4, "GEN-unfounded": 8, "MP-incoming": 4,
                  "E1-single": 1, "Gamma-block-zero": 0,
                  "Gamma-allow-one": 2, "goal-outside": 0}
QUERY_KEYS = ("version", "claim_mode", "function_arities", "predicate_arities",
              "theory_profile", "finite_axioms", "Gamma", "goal")
RECORD_KEYS = ("key", "rule_tag", "subtag", "witness", "formula", "references", "t", "m")
STATE_KEYS = {"schema", "model", "state_serial", "parent_serial", "selected_keys",
              "t_items", "m_items_with_refcounts"}
CURSOR_KEYS = {"schema", "model", "cursor_serial", "kind", "parent_state_serial",
               "point", "phase", "inspection_frontier", "canonical_scan_frontier",
               "canonical_tried_frontier", "initial_shortcut_keys", "initial_shortcut_tried",
               "outstanding_offer_serial", "remainder_revision", "terminal", "counts"}
STEP_KEYS = {"schema", "kind", "committed", "action", "candidate", "offer",
             "cursor_serial", "state_serial", "classification_kind"}
CLASS_KEYS = {"schema", "kind", "coverage_complete", "witnesses", "state_serial",
              "point", "remainder_revision", "counts"}
COUNTERS = {"committed_actions", "raw_tuples_complete", "intrinsic_refusals",
            "envelope_exclusions", "point_conflicts", "distinct_legal_inspected",
            "shortcut_candidates_proved", "fallback_eof_events", "branch_offers",
            "failed_children_recorded", "tried_prefix_advances"}
_OWNER = object()


class TinyProviderControlError(ValueError):
    pass


def is_owned_error(error):
    return type(error) is TinyProviderControlError and getattr(error, "_owner", None) is _OWNER


class _Call:
    def __init__(self, check):
        self.check = check
        self.first = None

    def tick(self):
        if self.first is not None:
            raise self.first
        try:
            self.check()
        except BaseException as error:
            self.first = error
            raise

    def need(self, condition, message):
        if self.first is not None:
            raise self.first
        if not condition:
            error = TinyProviderControlError(message)
            error._owner = _OWNER
            raise error


def _plain(value, call):
    call.tick()
    if value is None or type(value) in (str, int, bool):
        return value
    if type(value) in (list, tuple):
        result = []
        for child in value:
            call.tick()
            result.append(_plain(child, call))
        return result
    call.need(type(value) is dict, "ordinary diagnostic carrier")
    result = {}
    for key, child in value.items():
        call.tick()
        call.need(type(key) is str, "ordinary diagnostic key")
        result[key] = _plain(child, call)
    return result


def _identity(value, call):
    ordinary = _plain(value, call)
    call.tick()
    return json.dumps(ordinary, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False, allow_nan=False)


def _same(left, right, call):
    return _identity(left, call) == _identity(right, call)


def _projection(record, call):
    call.tick()
    return {key: _plain(record[key], call) for key in RECORD_KEYS if key != "key"}


def _counts(raw, call):
    call.tick()
    call.need(type(raw) is dict and set(raw) == COUNTERS, "exact cursor counters")
    for value in raw.values():
        call.tick()
        call.need(type(value) is int and value >= 0, "nonnegative exact counter")


def _cursor_snapshot(provider, cursor, call):
    result = provider.snapshot(cursor, check=call.tick)
    call.need(type(result) is dict and set(result) == CURSOR_KEYS, "exact cursor snapshot keys")
    call.need(result["schema"] == "FPC-point-cursor-snapshot-v1"
              and result["kind"] in ("CLASSIFICATION", "BRANCH")
              and type(result["terminal"]) is bool, "cursor snapshot tags/flag")
    _counts(result["counts"], call)
    return result


def _record(provider, candidate, model, expected, call):
    record = provider.candidate_record(candidate, check=call.tick)
    call.need(type(record) is dict and set(record) == set(RECORD_KEYS), "exact candidate record")
    projected = _projection(record, call)
    call.need(_identity(projected, call) in expected, "member in independent complete row domain")
    t = record["t"]
    row = t[0][0][0]
    key = ["FPC-point-ground-key-v1", model, ["ROW", row], record["rule_tag"],
           record["subtag"], record["witness"], record["t"], record["m"]]
    call.need(_same(record["key"], key, call), "full exact model/witness/point identity")
    # A diagnostic result is a fresh copy; mutating it cannot alter the handle.
    saved = _plain(record, call)
    record["formula"][0] = "DISPLAY_MUTATION_ONLY"
    record["key"][1]["query"]["goal"][0] = "DISPLAY_MUTATION_ONLY"
    again = provider.candidate_record(candidate, check=call.tick)
    call.need(_same(again, saved, call), "fresh immutable member export")
    return saved


def _model(query, frame, query_bytes, call):
    return {"schema": "FPC-point-model-identity-v1",
            "inventory_version": "FPC-POINT-FULL-FRAME-PROVIDER-v1",
            "query_hex": query_bytes.hex(), "query": _plain(query, call),
            "frame": _plain(frame, call)}


def _new(provider, encoder, modules, fixture, call):
    source = _plain(fixture["query"], call)
    before = _identity(source, call)
    encoded = encoder.encode_tiny_declared_query(source, check=call.tick)
    call.need(type(encoded) is dict and set(encoded) == {"query_bytes", "receipt"}, "encoder wrapper")
    query_bytes = encoded["query_bytes"]
    call.need(type(query_bytes) is bytes, "immutable encoded query")
    call.need(_identity(source, call) == before, "encoder leaves declaration unchanged")
    receipt = encoded["receipt"]
    call.need(receipt["complete"] is True and _same(receipt["semantic_query"], source, call),
              "encoder exact semantic input receipt")
    byte_identity = {"bytes": len(query_bytes), "sha256": hashlib.sha256(query_bytes).hexdigest()}
    call.need(_same(receipt["query_identity"], byte_identity, call), "encoder exact bytes identity")
    parsed = modules["checker"].decode_query(query_bytes, check=call.tick)
    parsed_fields = {key: parsed[key] for key in QUERY_KEYS}
    call.need(_same(parsed_fields, source, call), "same-byte parser vs independent literal declaration")
    inventory = provider.create_inventory(query_bytes, frame=_plain(fixture["frame"], call),
                                          modules=modules, check=call.tick)
    state = provider.root_state(inventory, check=call.tick)
    model = _model(source, fixture["frame"], query_bytes, call)
    root_snapshot = provider.snapshot(state, check=call.tick)
    call.need(type(root_snapshot) is dict and set(root_snapshot) == STATE_KEYS,
              "exact state snapshot keys")
    call.need(root_snapshot["schema"] == "FPC-point-state-snapshot-v1"
              and _same(root_snapshot["model"], model, call), "exact root model")
    call.need(root_snapshot["parent_serial"] is None, "fresh root parent")
    return {"inventory": inventory, "state": state, "model": model,
            "query": source, "query_bytes": query_bytes,
            "encoding": _plain(receipt, call), "root_snapshot": root_snapshot}


def _oracle(oracle, fixture, row, selected, call):
    result = oracle.enumerate_tiny_row_members(fixture["query"], fixture["frame"], row,
                                               selected=selected, check=call.tick)
    call.need(result["schema"] == "independent-tiny-FPC-row-members-v1"
              and result["complete"] is True, "complete independent oracle result")
    expected = {}
    for member in result["members"]:
        call.tick()
        identity = _identity(member, call)
        call.need(identity not in expected, "independent intrinsic members distinct")
        expected[identity] = member
    call.need(result["counts"]["members"] == len(expected), "oracle count agreement")
    return result, expected


def _classify(provider, state, point, model, expected, call, remainder=None):
    cursor = provider.open_classification(state, point, remainder=remainder, check=call.tick)
    observed = []
    classification = provider.classification(cursor, check=call.tick)
    call.need(classification["kind"] == "UNRESOLVED", "classification starts unresolved")
    while classification["kind"] == "UNRESOLVED":
        call.tick()
        step = provider.advance(cursor, check=call.tick)
        call.need(type(step) is dict and set(step) == STEP_KEYS, "exact atomic Step")
        call.need(step["schema"] == "FPC-point-provider-step-v1" and step["committed"] is True,
                  "completed one-action Step")
        call.need(step["kind"] in ("PENDING", "CANDIDATE", "EOF"), "Step kind")
        call.need(step["action"] in ("NORMALIZE", "ENUMERATE", "INTRINSIC", "ENVELOPE",
                                     "POINT_CHECK", "EMIT", "EOF"), "Step action")
        call.need(step["offer"] is None, "classification never offers a branch")
        if step["kind"] == "CANDIDATE":
            observed.append(_record(provider, step["candidate"], model, expected, call))
        else:
            call.need(step["candidate"] is None, "noncandidate Step has no candidate")
        classification = provider.classification(cursor, check=call.tick)
        call.need(type(classification) is dict and set(classification) == CLASS_KEYS, "classification keys")
        _counts(classification["counts"], call)
        call.need(step["classification_kind"] == classification["kind"], "Step/classifier association")
        if step["kind"] == "EOF":
            call.need(classification["kind"] in ("EMPTY", "SINGLE"), "EOF classification complete")
    amount = len(expected)
    kind = "EMPTY" if amount == 0 else "SINGLE" if amount == 1 else "MANY"
    call.need(classification["kind"] == kind, "independent 0/1/>=2 classification")
    call.need(type(classification["coverage_complete"]) is bool, "strict coverage bool")
    if amount <= 1:
        call.need(classification["coverage_complete"] is True, "zero/one requires complete fallback EOF")
    witnesses = classification["witnesses"]
    call.need(type(witnesses) in (tuple, list) and len(witnesses) == min(amount, 2), "exact witness count")
    records = [_record(provider, handle, model, expected, call) for handle in witnesses]
    ids = [_identity(record["key"], call) for record in records]
    call.need(len(set(ids)) == len(ids), "distinct classified keys")
    observed_keys = [_identity(record["key"], call) for record in observed]
    call.need(len(set(observed_keys)) == len(observed_keys), "inspection emissions are distinct complete keys")
    return cursor, classification, list(witnesses), records, observed


def _state(provider, state, model, oracle_result, selected_records, n, call):
    snapshot = provider.snapshot(state, check=call.tick)
    call.need(type(snapshot) is dict and set(snapshot) == STATE_KEYS, "full state keys")
    call.need(_same(snapshot["model"], model, call), "state model unchanged")
    call.need(type(snapshot["state_serial"]) is int and snapshot["state_serial"] >= 0,
              "diagnostic state serial exact natural")
    call.need(snapshot["parent_serial"] is None or
              (type(snapshot["parent_serial"]) is int and snapshot["parent_serial"] >= 0),
              "diagnostic parent serial exact natural or null")
    call.need(_same(snapshot["m_items_with_refcounts"], oracle_result["m_items_with_refcounts"], call),
              "complete independent marks and owner counts")
    expected_keys = [None for unused in range(n)]
    expected_t = []
    for record in selected_records:
        call.tick()
        row = record["t"][0][0][0]
        expected_keys[row] = record["key"]
    for row in range(n):
        call.tick()
        expected_t.append([[row, 0], [1 if expected_keys[row] is not None else 0, 1]])
    call.need(_same(snapshot["selected_keys"], expected_keys, call), "full selected row-slot vector")
    call.need(_same(snapshot["t_items"], expected_t, call), "every exact row occupancy including zeros")
    probe = provider.snapshot(state, check=call.tick)
    probe["t_items"][0][0][0] = -1
    probe["m_items_with_refcounts"][0][1][0] = "DISPLAY_MUTATION_ONLY"
    call.need(_same(provider.snapshot(state, check=call.tick), snapshot, call), "deep fresh state diagnostics")
    return snapshot


def _child_justification(provider, oracle, fixture, bundle, child, record, selected, call):
    records = selected + [record]
    projections = [_projection(item, call) for item in records]
    n = fixture["frame"]["rows"]
    oracle_result, unused = _oracle(oracle, fixture, fixture["row"], projections, call)
    _state(provider, child, bundle["model"], oracle_result, records, n, call)
    if n == 1:
        call.need(len(records) == 1, "complete one-cell leaf enumeration")
        call.need(oracle_result["counts"]["members"] == 0, "occupied unit cell has no additional placement")
        return {"kind": "COMPLETELY_ENUMERATED_ONE_CELL_LEAF", "unsatisfiable": False}
    occupied = set(oracle_result["selected_rows"])
    for row in range(n):
        call.tick()
        if row not in occupied:
            domain, members = _oracle(oracle, fixture, row, projections, call)
            if not members:
                return {"kind": "INDEPENDENT_COMPLETE_EMPTY_ROW_DOMAIN", "row": row,
                        "oracle": domain, "unsatisfiable": True}
    call.need(False, "no justified acknowledgment for this child")


def _collect(provider, oracle, fixture, bundle, call, selected=None, state=None, row=None):
    selected = [] if selected is None else selected
    state = bundle["state"] if state is None else state
    row = fixture["row"] if row is None else row
    projections = [_projection(record, call) for record in selected]
    oracle_result, expected = _oracle(oracle, fixture, row, projections, call)
    if not selected and row == fixture["row"]:
        call.need(len(expected) == FIXTURE_COUNTS[fixture["id"]], "independent literal count cross-check")
    entry = _state(provider, state, bundle["model"], oracle_result, selected,
                   fixture["frame"]["rows"], call)
    cursor, classified, handles, records, observed = _classify(
        provider, state, (row, 0), bundle["model"], expected, call)
    if len(expected) < 2:
        got = {_identity(_projection(record, call), call) for record in records}
        call.need(got == set(expected), "full singleton/empty independent set equality")
        return {"oracle": oracle_result, "records": records, "handles": handles,
                "class": _ordinary_class(classified, records, call), "class_cursor": cursor,
                "branch": None, "acknowledgments": [], "entry": entry}
    branch = provider.open_branch(state, (row, 0), classified=cursor, check=call.tick)
    got, found, found_handles, justifications = set(), [], [], []
    while True:
        call.tick()
        step = provider.advance(branch, check=call.tick)
        call.need(type(step) is dict and set(step) == STEP_KEYS and step["committed"] is True,
                  "complete branch atomic Step")
        if step["kind"] == "EOF":
            call.need(step["candidate"] is None and step["offer"] is None, "branch EOF no offer")
            break
        if step["kind"] == "PENDING":
            call.need(step["candidate"] is None and step["offer"] is None, "branch pending no offer")
            continue
        call.need(step["kind"] == "CANDIDATE" and step["offer"] is not None, "exact outstanding offer")
        record = _record(provider, step["candidate"], bundle["model"], expected, call)
        identity = _identity(_projection(record, call), call)
        call.need(identity not in got, "each complete member offered only once")
        child = provider.place_state(state, step["candidate"], check=call.tick)
        justification = _child_justification(provider, oracle, fixture, bundle, child,
                                           record, selected, call)
        call.need(_same(provider.snapshot(state, check=call.tick), entry, call), "retained exact parent unchanged")
        provider.reject_offer(branch, step["offer"], check=call.tick)
        got.add(identity)
        found.append(record)
        found_handles.append(step["candidate"])
        justifications.append(justification)
        provider.close(child)
    call.need(got == set(expected), "complete offered set equals independent full domain")
    call.need(_same(provider.snapshot(state, check=call.tick), entry, call), "full enumeration preserves parent")
    return {"oracle": oracle_result, "records": found, "handles": found_handles,
            "class": _ordinary_class(classified, records, call), "class_cursor": cursor,
            "branch": branch, "acknowledgments": justifications, "entry": entry}


def _ordinary_class(classified, records, call):
    return {key: (_plain(records, call) if key == "witnesses" else _plain(value, call))
            for key, value in classified.items()}


def _refusal(provider, operation, call):
    try:
        operation()
    except BaseException as error:
        if call.first is not None:
            raise call.first
        if not provider.is_owned_error(error):
            raise
        call.tick()
        return error
    call.need(False, "expected completed owned API refusal")


def _remote(provider, oracle, encoder, modules, fixture, call):
    bundle = _new(provider, encoder, modules, fixture, call)
    try:
        whole = _collect(provider, oracle, fixture, bundle, call)
        target_index = None
        for index, record in enumerate(whole["records"]):
            call.tick()
            if _same(record["witness"], [0, 1], call):
                target_index = index
        call.need(target_index is not None, "independent source-zero GEN present")
        old_row1 = provider.open_classification(bundle["state"], (1, 0), check=call.tick)
        chosen = whole["records"][target_index]
        child = provider.place_state(bundle["state"], whole["handles"][target_index], check=call.tick)
        refused = _refusal(provider, lambda: provider.rebind_classification(old_row1, child, check=call.tick), call)
        child_domain = _collect(provider, oracle, fixture, bundle, call, selected=[chosen], state=child, row=1)
        call.need(child_domain["oracle"]["counts"]["members"] == 6, "literal remote row-one count")
        zero, unused = _oracle(oracle, fixture, 0, [_projection(chosen, call)], call)
        call.need(zero["counts"]["members"] == 0, "remote input mark creates complete empty row zero")
        call.need(_same(provider.snapshot(bundle["state"], check=call.tick), whole["entry"], call),
                  "rollback is retained parent, not imported snapshot")
        same_parent = provider.rebind_classification(old_row1, bundle["state"], check=call.tick)
        result = {"selected": chosen, "child_row_one": child_domain["oracle"],
                  "empty_row_zero": zero, "refusal": str(refused),
                  "parent_restored_exact_handle": True, "snapshot_resume_used": False}
        provider.close(same_parent)
        provider.close(child)
        provider.close(old_row1)
        return result
    finally:
        provider.close(bundle["inventory"])


def _remainders(provider, oracle, encoder, modules, fixture, call):
    bundle = _new(provider, encoder, modules, fixture, call)
    try:
        oracle_result, expected = _oracle(oracle, fixture, 0, [], call)
        cursor, classified, unused, records, observed = _classify(
            provider, bundle["state"], (0, 0), bundle["model"], expected, call)
        branch = provider.open_branch(bundle["state"], (0, 0), classified=cursor, check=call.tick)
        initial = _cursor_snapshot(provider, branch, call)
        call.need(len(initial["initial_shortcut_keys"]) <= 2
                  and not any(initial["initial_shortcut_tried"]), "initial inspection is not tried")
        call.need(initial["counts"]["failed_children_recorded"] == 0
                  and initial["counts"]["tried_prefix_advances"] == 0,
                  "inspection has no acknowledged child or tried prefix")
        shortcut_keys = _plain(initial["initial_shortcut_keys"], call)
        remaining = dict(expected)
        rows, offers, previous_remainder = [], set(), None
        for rejected in range(5):
            call.tick()
            branch_before = _cursor_snapshot(provider, branch, call)
            remainder, result, unused, witnesses, seen = _classify(
                provider, bundle["state"], (0, 0), bundle["model"], remaining, call, remainder=branch)
            call.need(_same(_cursor_snapshot(provider, branch, call), branch_before, call),
                      "remainder inspection changes no branch field or counter")
            rows.append({"rejected": rejected, "remaining": len(remaining),
                         "classification": _ordinary_class(result, witnesses, call)})
            if rejected == 4:
                break
            while True:
                call.tick()
                step = provider.advance(branch, check=call.tick)
                if step["kind"] != "PENDING":
                    break
            call.need(step["kind"] == "CANDIDATE" and step["offer"] is not None, "remaining branch offer")
            record = _record(provider, step["candidate"], bundle["model"], remaining, call)
            identity = _identity(_projection(record, call), call)
            call.need(identity not in offers, "no fallback/shortcut duplicate trial")
            child = provider.place_state(bundle["state"], step["candidate"], check=call.tick)
            justification = _child_justification(provider, oracle, fixture, bundle, child, record, [], call)
            provider.reject_offer(branch, step["offer"], check=call.tick)
            _refusal(provider, lambda: provider.classification(remainder, check=call.tick), call)
            after = _cursor_snapshot(provider, branch, call)
            call.need(_same(after["initial_shortcut_keys"], shortcut_keys, call), "shortcut cache never replenishes")
            call.need(after["counts"]["failed_children_recorded"] == rejected + 1,
                      "acknowledgment count is separate from inspection")
            offers.add(identity)
            remaining.pop(identity)
            provider.close(child)
            provider.close(remainder)
        while True:
            call.tick()
            end = provider.advance(branch, check=call.tick)
            if end["kind"] != "PENDING":
                break
        call.need(end["kind"] == "EOF" and len(offers) == 4, "all four exactly once then full EOF")
        return {"remainder_sequence": rows, "offers": 4,
                "initial_shortcut_keys": shortcut_keys,
                "scope": "complete one-cell leaf enumeration acknowledgments, not unsatisfiable-child or scheduler counts"}
    finally:
        provider.close(bundle["inventory"])


def _faults(provider, encoder, modules, fixture, call):
    donor = _new(provider, encoder, modules, fixture, call)
    retained = _refusal(provider, lambda: provider.open_classification(
        donor["state"], (fixture["frame"]["rows"], 0), check=call.tick), call)
    retained_fields, retained_args = dict(vars(retained)), retained.args
    provider.close(donor["inventory"])
    unowned = provider.ProviderInputError("authored foreign public-class callback")
    call.need(not provider.is_owned_error(unowned), "public message constructor is unowned")
    recipes = [("RuntimeError", RuntimeError("tiny-provider-first-fault")),
               ("StopIteration", StopIteration("tiny-provider-first-fault")),
               ("GeneratorExit", GeneratorExit("tiny-provider-first-fault")),
               ("unowned-public-class", unowned), ("retained-owned", retained)]
    evidence = []
    for name, sentinel in recipes:
        call.tick()
        bundle = _new(provider, encoder, modules, fixture, call)
        first = provider.open_classification(bundle["state"], (0, 0), check=call.tick)
        sibling = provider.open_classification(bundle["state"], (0, 0), check=call.tick)
        invocations = [0]

        def fault():
            call.tick()
            invocations[0] += 1
            raise sentinel

        try:
            try:
                provider.advance(first, check=fault)
            except BaseException as error:
                if error is not sentinel:
                    raise
                caught = error
            else:
                call.need(False, "fault must escape, never a Step")
            call.need(caught is sentinel and invocations[0] == 1, "first callback exact object")
            later_calls = [0]

            def forbidden_later_callback():
                later_calls[0] += 1
                raise RuntimeError("later callback must not replace first fault")

            for operation in (
                lambda: provider.snapshot(bundle["state"], check=forbidden_later_callback),
                lambda: provider.classification(sibling, check=forbidden_later_callback),
                lambda: provider.root_state(bundle["inventory"], check=forbidden_later_callback),
            ):
                call.tick()
                try:
                    operation()
                except BaseException as error:
                    if error is not sentinel:
                        raise
                else:
                    call.need(False, "poisoned inventory cannot output or resume")
            provider.close(first)
            provider.close(sibling)
            try:
                provider.root_state(bundle["inventory"], check=forbidden_later_callback)
            except BaseException as error:
                if error is not sentinel:
                    raise
            else:
                call.need(False, "close cannot clear first fault")
            call.need(later_calls[0] == 0, "no callbacks after latched first fault")
            if sentinel is retained:
                call.need(vars(retained) == retained_fields and retained.args == retained_args,
                          "retained genuine refusal data remains unchanged")
            evidence.append({"recipe": name, "same_object": True, "fault_callback_calls": invocations[0],
                             "later_callback_calls": later_calls[0], "prefix_output": False})
        finally:
            provider.close(bundle["inventory"])
    return {"recipes": evidence, "scope": "first advance callback plus inventory sibling propagation; not every late cutoff or cleanup allocation proof"}


def run_tiny_provider_controls(provider, *, declarations, oracle, encoder, modules, check):
    """Prospective ten groups, strict literal intake and no historical state."""
    call = _Call(check)
    call.tick()
    call.need(type(modules) is dict and set(modules) == {"checker", "builders"}, "exact provider helper roles")
    canonical = _identity(declarations, call).encode("utf-8")
    call.need(hashlib.sha256(canonical).hexdigest() == DECLARATION_IDENTITY,
              "frozen independent declaration document")
    call.need(tuple(declarations["control_ids"]) == CONTROL_IDS, "exact ten ordered IDs")
    fixtures = {}
    for raw in declarations["fixtures"]:
        call.tick()
        call.need(raw["id"] not in fixtures, "unique fixture ID")
        fixtures[raw["id"]] = raw
    call.need(set(fixtures) == set(FIXTURE_COUNTS), "exact seven literal inputs")
    intake_before = _identity(declarations, call)
    controls = []
    for group_id, fixture_id in zip(CONTROL_IDS[:7], FIXTURE_COUNTS):
        call.tick()
        fixture = fixtures[fixture_id]
        bundle = _new(provider, encoder, modules, fixture, call)
        try:
            result = _collect(provider, oracle, fixture, bundle, call)
            controls.append({"id": group_id, "status": "PASSED", "fixture": fixture_id,
                             "expected_count": FIXTURE_COUNTS[fixture_id], "oracle": result["oracle"],
                             "members": result["records"], "classification": result["class"],
                             "acknowledgments": result["acknowledgments"],
                             "query_encoding": bundle["encoding"]})
        finally:
            provider.close(bundle["inventory"])
    controls.append({"id": CONTROL_IDS[7], "status": "PASSED",
                     "evidence": _remote(provider, oracle, encoder, modules, fixtures["Gamma-allow-one"], call)})
    controls.append({"id": CONTROL_IDS[8], "status": "PASSED",
                     "evidence": _remainders(provider, oracle, encoder, modules, fixtures["duplicate-base"], call)})
    controls.append({"id": CONTROL_IDS[9], "status": "PASSED",
                     "evidence": _faults(provider, encoder, modules, fixtures["duplicate-base"], call)})
    call.need(_identity(declarations, call) == intake_before, "all literal inputs remain unchanged")
    call.need(tuple(row["id"] for row in controls) == CONTROL_IDS, "complete ordered group output")
    call.tick()
    return {"schema": RETURN_SCHEMA, "version": VERSION, "population": POPULATION,
            "complete": True, "control_ids": list(CONTROL_IDS), "controls": controls,
            "counts": {"groups": 10, "passed": 10, "failed": 0},
            "scope": "new tiny full-provider domain/identity/ownership only; no proof admission, scheduler conformance, all-profile completeness or original126 replacement"}
