"""Prospective raw13 + separately counted safety3 controls; never run on import.

The kernel is provided by the future whole worker. The independent oracle imports
no kernel. No FPC target, proof, old prefix, full provider or accepting fixture is
used here. All control execution belongs inside a future reviewed bounded actual.
"""

import hashlib
import json

from explicit_point_literal_oracle_v1 import inspect_literal_prefix, enumerate_literal_subsets


VERSION = "L-explicit-point-independent-controls-v1"
RETURN_SCHEMA = "independent-explicit-point-controls-v1"
RAW_CANONICAL_SHA256 = "242d2246323fdf29809da42a639ff7d91d84b54db12978346fcd695f0f40fad9"
RAW_IDS = (
    "global-dead-before-forced", "global-forced-before-earlier-branch",
    "generation-before-degree", "remote-mark-only-zero-is-assigned",
    "remote-conflict-dead-before-other-force", "shared-fractional-placement-once",
    "distinct-inventory-identical-point-functions", "rollback-parent-exclusion",
    "mark-reference-count-rollback", "generation-minimum-rollback",
    "outside-support-global-legality", "lazy-prefix-not-singleton", "frame-boundary-growth",
)
SAFETY_IDS = (
    "normal-refusal-and-input-ownership",
    "checkpoint-path-and-cursor-ownership",
    "first-fault-and-retained-owned-identity",
)
SEMANTIC_KEYS = (
    "capacity", "roots", "boundary", "inventory", "order", "selected", "excluded_ids",
    "active_points", "t_totals", "marks", "frontier", "candidates", "dependencies", "query_state",
)
METRIC_KEYS = (
    "inspect_calls", "place_calls", "forced_moves", "branch_nodes", "backtracks", "exclusions",
    "solution_visits", "duplicate_solutions", "max_selected", "max_frontier",
)
_MARKER = object()


class PointControlFailure(ValueError):
    pass


def is_owned_error(error):
    return isinstance(error, PointControlFailure) and getattr(error, "_marker", None) is _MARKER


class _Call:
    def __init__(self, check):
        self.check = check
        self.fault = None
        self.token = object()

    def tick(self):
        if self.fault is not None:
            raise self.fault
        try:
            self.check()
        except BaseException as error:
            self.fault = error
            raise

    def need(self, condition, message):
        if not condition:
            error = PointControlFailure(message)
            error._marker = _MARKER
            error._owner = self.token
            raise error


def _same(left, right):
    """Representation-only tuple/list agreement; bool is never an integer alias."""
    if type(left) in (list, tuple) and type(right) in (list, tuple):
        if len(left) != len(right):
            return False
        for index in range(len(left)):
            if not _same(left[index], right[index]):
                return False
        return True
    if type(left) is dict and type(right) is dict:
        if set(left) != set(right):
            return False
        for key in left:
            if not _same(left[key], right[key]):
                return False
        return True
    return type(left) is type(right) and left == right


def _copy(value, call, plain=False):
    call.tick()
    if type(value) in (list, tuple):
        result = []
        for item in value:
            call.tick()
            result.append(_copy(item, call, plain))
        return result if plain or type(value) is list else tuple(result)
    if type(value) is dict:
        result = {}
        for key, item in value.items():
            call.tick()
            call.need(type(key) is str, "ordinary record key")
            result[key] = _copy(item, call, plain)
        return result
    call.need(value is None or type(value) in (str, int, bool), "ordinary literal value")
    return value


def _exact(row, keys, call, label):
    call.tick()
    call.need(type(row) is dict and set(row) == set(keys), label + " exact keys")


def _public_id(value, call, root=True):
    """API IDs retain immutable types even though evidence later serializes them."""
    call.tick()
    if type(value) is str:
        call.need(bool(value), "nonempty public id")
        return
    if type(value) is int and not root:
        return
    call.need(type(value) is tuple, "public id immutable tuple/string")
    for item in value:
        call.tick()
        _public_id(item, call, False)


def _snapshot_ids(semantic, call):
    for row in semantic["inventory"]:
        call.tick()
        _public_id(row["id"], call)
        _public_id(row["identity"][0], call)
        call.need(type(row["identity"][0]) is type(row["id"])
                  and row["identity"][0] == row["id"], "full identity retains typed id")
    for row in semantic["candidates"]:
        call.tick()
        _public_id(row["id"], call)
        _public_id(row["identity"][0], call)
        call.need(type(row["identity"][0]) is type(row["id"])
                  and row["identity"][0] == row["id"], "candidate full typed identity")
    for row in semantic["selected"]:
        call.tick()
        _public_id(row["id"], call)
    for key in ("order", "excluded_ids"):
        for identity in semantic[key]:
            call.tick()
            _public_id(identity, call)
    for row in semantic["dependencies"]:
        call.tick()
        for key in ("t_ids", "m_ids"):
            for identity in row[key]:
                call.tick()
                _public_id(identity, call)
    for row in semantic["marks"]:
        call.tick()
        for owner in row["owners"]:
            call.tick()
            if owner["kind"] == "PLACEMENT":
                _public_id(owner["id"], call)


def _prefix_ids(model, call):
    result = []
    for row in model["prefix"]:
        call.tick()
        result.append(row["id"])
    return result


def _model(case, call, frame=None):
    """Interpret only the frozen declaration. This helper is actual-only code."""
    if frame is not None:
        placements = []
        outside_t = set()
        outside_m = set()
        n = frame["n"]
        for k in range(n):
            call.tick()
            for prototype in case["relative_prototypes"]:
                call.tick()
                t = []
                m = []
                for point, units in prototype["t"]:
                    call.tick()
                    translated = [point[0] + k, point[1]]
                    t.append([translated, units])
                    if translated[1] == 0 and not 0 <= translated[0] < n:
                        outside_t.add(tuple(translated))
                for point, value in prototype["m"]:
                    call.tick()
                    translated = [point[0] + k, point[1]]
                    m.append([translated, value])
                    if translated[1] == 1 and not 0 <= translated[0] < n:
                        outside_m.add(tuple(translated))
                placements.append({"id": (prototype["id"], k), "origin": [k, 0], "t": t, "m": m})
        fixed_t = []
        fixed_m = []
        for point in sorted(outside_t):
            call.tick()
            fixed_t.append([list(point), frame["exterior_cell_t"]])
        for point in sorted(outside_m):
            call.tick()
            fixed_m.append([list(point), frame["exterior_mark"]])
        fixed_m.append(_copy(frame["goal_mark"], call))
        order = []
        for row in placements:
            call.tick()
            order.append(row["id"])
        return {"schema": "explicit-point-model-v1", "capacity": case["capacity_denominator"],
                "roots": _copy(frame["root_points"], call), "boundary": {"t": fixed_t, "m": fixed_m},
                "placements": placements, "prefix": [], "order": order}
    placements = []
    prefix = []
    for row in case["initial_placements"]:
        call.tick()
        placements.append({"id": row["id"], "origin": _copy(row["origin"], call),
                           "t": _copy(row["t"], call), "m": _copy(row["m"], call)})
        prefix.append({"id": row["id"], "seed": row["generation"] == 0, "generation": row["generation"]})
    for row in case["allowed_placements"]:
        call.tick()
        placements.append(_copy(row, call))
    order = []
    if "branch_override" in case:
        for identity in case["branch_override"]:
            call.tick()
            order.append(identity)
    for row in placements:
        call.tick()
        if row["id"] not in order:
            order.append(row["id"])
    boundary = case.get("boundary", {"fixed_t": [], "fixed_m": []})
    return {"schema": "explicit-point-model-v1", "capacity": 12,
            "roots": _copy(case["root_points"], call),
            "boundary": {"t": _copy(boundary["fixed_t"], call), "m": _copy(boundary["fixed_m"], call)},
            "placements": placements, "prefix": prefix, "order": order}


def _snapshot(kernel, state, call):
    row = kernel.snapshot(state, check=call.tick)
    _exact(row, ("schema", "semantic", "diagnostics"), call, "snapshot")
    call.need(row["schema"] == "explicit-point-state-snapshot-v1", "snapshot schema")
    _exact(row["semantic"], SEMANTIC_KEYS, call, "semantic")
    _snapshot_ids(row["semantic"], call)
    _exact(row["diagnostics"], ("epoch", "callbacks", "metrics"), call, "diagnostics")
    for key in ("epoch", "callbacks"):
        call.need(type(row["diagnostics"][key]) is int and row["diagnostics"][key] >= 0, "strict diagnostic integer")
    call.need(type(row["diagnostics"]["metrics"]) is dict, "diagnostic metrics record")
    return _copy(row, call, True)


def _assert_state(kernel, state, model, selected, excluded, call):
    actual = _snapshot(kernel, state, call)
    expected = inspect_literal_prefix(model, selected, excluded, check=call.tick)
    # Cache-version algorithms are deliberately unspecified. Their WHOLE value
    # must restore, but all graph/totals/dependencies below are independently exact.
    left = dict(actual["semantic"])
    right = dict(expected["semantic"])
    left.pop("query_state")
    right.pop("query_state")
    call.need(_same(left, right), "independent full semantic recomputation")
    decision = kernel.inspect(state, check=call.tick)
    _exact(decision, ("schema", "status", "point", "generation", "candidate_ids", "complete_domains"), call, "decision")
    for identity in decision["candidate_ids"]:
        call.tick()
        _public_id(identity, call)
    call.need(_same(decision, expected["decision"]), "independent global scheduler decision")
    return actual, expected, _copy(decision, call, True)


def _place(kernel, state, model, selected, excluded, identity, call):
    result = kernel.place(state, identity, check=call.tick)
    _exact(result, ("id", "generation"), call, "placement")
    _public_id(result["id"], call)
    call.need(type(result["id"]) is type(identity) and result["id"] == identity, "exact typed placement id")
    selected.append(identity)
    snapshot, expected, decision = _assert_state(kernel, state, model, selected, excluded, call)
    expected_row = expected["semantic"]["selected"][-1]
    call.need(_same(result["id"], identity) and type(result["generation"]) is int
              and result["generation"] == expected_row["generation"], "computed placement generation")
    return snapshot, decision


def _refusal(kernel, operation, call):
    try:
        operation()
    except BaseException as error:
        if call.fault is not None:
            raise call.fault
        if not kernel.is_owned_error(error):
            raise
        return error
    call.need(False, "expected owned normal refusal")


def _restore(kernel, state, token, before, call):
    result = kernel.rollback(state, token, check=call.tick)
    call.need(result is None, "rollback returns None")
    after = _snapshot(kernel, state, call)
    call.need(_same(after["semantic"], before["semantic"]), "WHOLE semantic rollback including query_state")
    return after


def _refusal_no_move(kernel, state, operation, call):
    before = _snapshot(kernel, state, call)
    error = _refusal(kernel, operation, call)
    after = _snapshot(kernel, state, call)
    call.need(_same(after["semantic"], before["semantic"]), "every normal refusal leaves full semantics")
    return error


def _solutions(kernel, state, model, selected, excluded, call):
    before = _snapshot(kernel, state, call)
    expected = enumerate_literal_subsets(model, selected, excluded, check=call.tick)
    result = kernel.solve_all(state, check=call.tick)
    _exact(result, ("schema", "complete", "status", "solution_subsets", "metrics"), call, "all solutions")
    call.need(result["schema"] == "explicit-point-all-solutions-v1" and result["complete"] is True
              and result["status"] == "EXHAUSTED_FINITE_MODEL", "finite solver completion")
    for subset in result["solution_subsets"]:
        call.tick()
        for identity in subset:
            call.tick()
            _public_id(identity, call)
    call.need(_same(result["solution_subsets"], expected["solution_subsets"]), "complete independent solution subsets")
    _exact(result["metrics"], METRIC_KEYS, call, "solve metrics")
    for value in result["metrics"].values():
        call.tick()
        call.need(type(value) is int and value >= 0, "strict solver metric")
    after = _snapshot(kernel, state, call)
    call.need(_same(before["semantic"], after["semantic"]), "solve_all restores entire entry semantics")
    return {"oracle": expected, "kernel": _copy(result, call, True), "entry_restored": True}


def _point_row(snapshot, point, call):
    for row in snapshot["semantic"]["active_points"]:
        call.tick()
        if _same(row["point"], point):
            return row
    call.need(False, "expected active point")


def _mark_row(snapshot, point, call, required=True):
    for row in snapshot["semantic"]["marks"]:
        call.tick()
        if _same(row["point"], point):
            return row
    call.need(not required, "expected assigned mark")
    return None


def _candidate(snapshot, identity, call):
    for row in snapshot["semantic"]["candidates"]:
        call.tick()
        if _same(row["id"], identity):
            return row
    call.need(False, "expected candidate identity")


def _classification(kernel, state, point, cursor, positions, call):
    row = kernel.classify(state, point, cursor=cursor, max_positions=positions, check=call.tick)
    _exact(row, ("schema", "status", "point", "inspected_positions", "next_position", "witness_ids", "exhausted", "cursor"), call, "classification")
    call.need(row["schema"] == "explicit-point-classification-v1" and _same(row["point"], point), "classification identity")
    call.need(row["status"] in ("EMPTY", "SINGLE", "MANY", "UNRESOLVED"), "classification status")
    call.need(type(row["exhausted"]) is bool, "classification exact exhaustion bool")
    for key in ("inspected_positions", "next_position"):
        call.need(type(row[key]) is int and row[key] >= 0, "classification strict position")
    call.need(row["next_position"] == row["inspected_positions"], "canonical scan position")
    call.need(row["cursor"] is not None, "classification retains opaque cursor including EOF")
    for identity in row["witness_ids"]:
        call.tick()
        _public_id(identity, call)
    return row


def _class_receipt(row, call):
    result = {}
    for key, value in row.items():
        call.tick()
        if key != "cursor":
            result[key] = _copy(value, call, True)
    result["opaque_cursor_returned"] = row["cursor"] is not None
    return result


def _raw_case(kernel, case, call):
    identity = case["id"]
    if identity == "frame-boundary-growth":
        records = []
        for frame in case["frames"]:
            call.tick()
            model = _model(case, call, frame)
            state = kernel.create_state(model, check=call.tick)
            selected = []
            before, unused_expected, decision = _assert_state(kernel, state, model, selected, [], call)
            solutions = _solutions(kernel, state, model, selected, [], call)
            if frame["n"] == 1:
                call.need(solutions["oracle"]["accepted_subset_count"] == 0, "literal n1 empty")
            else:
                call.need(_same(solutions["oracle"]["solution_subsets"], [[["U", 0], ["V", 1]]]), "literal n2 subset")
                after, unused = _place(kernel, state, model, selected, [], ("U", 0), call)
                after, final_decision = _place(kernel, state, model, selected, [], ("V", 1), call)
                call.need(final_decision["status"] == "EXACT", "n2 exact")
                for point in frame["root_points"]:
                    call.tick()
                    call.need(_point_row(after, point, call)["generation"] == 0, "frame roots stay zero")
            records.append({"n": frame["n"], "entry": before["semantic"], "solutions": solutions})
        return {"population": "point-kernel13", "id": identity, "status": "PASSED", "frames": records}
    model = _model(case, call)
    selected = _prefix_ids(model, call)
    excluded = []
    state = kernel.create_state(model, check=call.tick)
    before, expected, decision = _assert_state(kernel, state, model, selected, excluded, call)
    solutions = _solutions(kernel, state, model, selected, excluded, call)
    if "complete_solution_subsets" in case["expected"]:
        call.need(_same(solutions["oracle"]["solution_subsets"], case["expected"]["complete_solution_subsets"]), "original literal subset expectation")
    detail = {"entry_decision": decision, "entry_semantic": before["semantic"], "solutions": solutions}
    if identity == "global-dead-before-forced":
        call.need(decision["status"] == "DEAD" and _same(decision["point"], [5,0])
                  and len(before["semantic"]["selected"]) == 0, "dead before any forced placement")
    elif identity == "global-forced-before-earlier-branch":
        call.need(decision["status"] == "FORCED" and _same(decision["candidate_ids"], ["F"])
                  and decision["generation"] == 1, "later singleton before earlier branch")
        after, next_decision = _place(kernel, state, model, selected, excluded, "F", call)
        detail["after_F"] = after["semantic"]
    elif identity == "generation-before-degree":
        call.need(decision["status"] == "BRANCH" and _same(decision["point"], [2,0])
                  and len(decision["candidate_ids"]) == 3 and decision["generation"] == 0, "generation beats smaller remote degree")
    elif identity in ("remote-mark-only-zero-is-assigned", "remote-conflict-dead-before-other-force"):
        call.need(decision["status"] == "FORCED" and _same(decision["candidate_ids"], ["A"]), "literal first A")
        after, next_decision = _place(kernel, state, model, selected, excluded, "A", call)
        call.need(_mark_row(after, [99,1], call)["value"] == 0
                  and type(_mark_row(after, [99,1], call)["value"]) is int, "assigned zero preserved")
        call.need(not _candidate(after, "B", call)["legal"], "remote B invalidated globally")
        if identity == "remote-mark-only-zero-is-assigned":
            call.need(next_decision["status"] == "FORCED" and _same(next_decision["candidate_ids"], ["C"]), "remote C forced")
            call.need([99,1] not in after["semantic"]["frontier"], "mark-only not frontier")
        else:
            call.need(next_decision["status"] == "DEAD" and _same(next_decision["point"], [10,0]), "remote dead before queued D")
        detail["after_A"] = after["semantic"]
    elif identity in ("shared-fractional-placement-once", "distinct-inventory-identical-point-functions"):
        expected_nodes = 1 if identity == "shared-fractional-placement-once" else 2
        call.need(len(before["semantic"]["candidates"]) == expected_nodes, "distinct shared nodes")
        incidence_count = 0
        for row in before["semantic"]["candidates"]:
            call.tick()
            incidence_count += len(row["incidence"])
        call.need(incidence_count == 2 * expected_nodes, "complete shared incidence")
        after, next_decision = _place(kernel, state, model, selected, excluded, "S", call)
        for point in ([0,0], [1,0]):
            call.need(_point_row(after, point, call)["total"] == 6, "fractional residual")
        if expected_nodes == 1:
            call.need(next_decision["status"] == "DEAD", "single-use shared S not double selected")
        else:
            call.need(next_decision["status"] == "FORCED" and _same(next_decision["candidate_ids"], ["R"]), "distinct equal-values R retained")
            after, final_decision = _place(kernel, state, model, selected, excluded, "R", call)
            call.need(final_decision["status"] == "EXACT", "S plus R exact")
        detail["after"] = after["semantic"]
    elif identity == "rollback-parent-exclusion":
        token = kernel.checkpoint(state, check=call.tick)
        child, child_decision = _place(kernel, state, model, selected, excluded, "B", call)
        call.need(child_decision["status"] == "DEAD", "B child dead")
        _restore(kernel, state, token, before, call)
        selected = _prefix_ids(model, call)
        call.need(kernel.exclude(state, "B", check=call.tick) is None, "exclude return")
        excluded.append("B")
        parent, unused_expected, parent_decision = _assert_state(kernel, state, model, selected, excluded, call)
        call.need(parent_decision["status"] == "FORCED" and _same(parent_decision["candidate_ids"], ["A"]), "B exclusion only parent")
        after, next_decision = _place(kernel, state, model, selected, excluded, "A", call)
        _restore(kernel, state, token, before, call)
        detail["failed_child"] = child["semantic"]
        detail["parent_after_B_exclusion"] = parent["semantic"]
        detail["whole_restore"] = True
    elif identity == "mark-reference-count-rollback":
        entry = kernel.checkpoint(state, check=call.tick)
        first, unused = _place(kernel, state, model, selected, excluded, "A", call)
        first_token = kernel.checkpoint(state, check=call.tick)
        both, unused = _place(kernel, state, model, selected, excluded, "B", call)
        call.need(_mark_row(both, [99,1], call)["reference_count"] == 2, "two mark owners")
        restored = _restore(kernel, state, first_token, first, call)
        call.need(_mark_row(restored, [99,1], call)["reference_count"] == 1, "one owner survives undo")
        restored = _restore(kernel, state, entry, before, call)
        call.need(_mark_row(restored, [99,1], call, False) is None, "last owner undo frees mark")
        detail["two_owner_mark"] = _mark_row(both, [99,1], call)
    elif identity == "generation-minimum-rollback":
        entry = kernel.checkpoint(state, check=call.tick)
        first, unused = _place(kernel, state, model, selected, excluded, "X", call)
        x_token = kernel.checkpoint(state, check=call.tick)
        second, unused = _place(kernel, state, model, selected, excluded, "Y", call)
        y_token = kernel.checkpoint(state, check=call.tick)
        third, unused = _place(kernel, state, model, selected, excluded, "Z", call)
        call.need(_point_row(second, [2,0], call)["generation"] == 2, "Y source minimum two")
        call.need(_point_row(third, [2,0], call)["generation"] == 1, "Z lowers minimum")
        _restore(kernel, state, y_token, second, call)
        _restore(kernel, state, x_token, first, call)
        _restore(kernel, state, entry, before, call)
        detail["transition_only_generations"] = [first["semantic"]["selected"][-1]["generation"],
                                                    second["semantic"]["selected"][-1]["generation"],
                                                    third["semantic"]["selected"][-1]["generation"]]
        call.need(detail["transition_only_generations"] == [1,2,1], "literal X Y Z labels")
    elif identity == "outside-support-global-legality":
        call.need(not _candidate(before, "A", call)["legal"] and decision["status"] == "FORCED"
                  and _same(decision["candidate_ids"], ["B"]), "outside support invalidates A")
        _refusal_no_move(kernel, state, lambda: kernel.place(state, "A", check=call.tick), call)
        call.need(_same(_snapshot(kernel, state, call)["semantic"], before["semantic"]), "illegal move is no mutation")
    elif identity == "lazy-prefix-not-singleton":
        cursor = None
        receipts = []
        specifications = [(0,"UNRESOLVED",[],False),(1,"UNRESOLVED",["A"],False),
                          (1,"MANY",["A","B"],False),(1,"MANY",["A","B","C"],True),
                          (0,"MANY",["A","B","C"],True)]
        for positions, status, witnesses, exhausted in specifications:
            call.tick()
            row = _classification(kernel, state, [0,0], cursor, positions, call)
            call.need(row["status"] == status and _same(row["witness_ids"], witnesses)
                      and row["exhausted"] is exhausted, "literal lazy prefix classification")
            call.need(row["next_position"] == len(witnesses), "lazy canonical position")
            cursor = row["cursor"]
            receipts.append(_class_receipt(row, call))
        call.need(_same(_snapshot(kernel, state, call)["semantic"], before["semantic"]), "classify is not branch trial")
        entry = kernel.checkpoint(state, check=call.tick)
        after, unused = _place(kernel, state, model, selected, excluded, "A", call)
        call.need(after["semantic"]["selected"][-1]["generation"] == 1
                  and _point_row(after, [0,0], call)["generation"] == 0, "binding: empty root0 gives ordinary tile1")
        _restore(kernel, state, entry, before, call)
        for tried in ("A", "B"):
            # These are explicit low-level exclusions, not claims of failed proofs.
            call.need(kernel.exclude(state, tried, check=call.tick) is None, "lowlevel exclusion return")
            excluded.append(tried)
        parent, unused_expected, final_decision = _assert_state(kernel, state, model, [], excluded, call)
        remainder = _classification(kernel, state, [0,0], None, None, call)
        call.need(remainder["status"] == "SINGLE" and _same(remainder["witness_ids"], ["C"])
                  and remainder["exhausted"] is True, "C remains canonical fallback")
        call.need(final_decision["status"] == "FORCED", "exact singleton after exclusions")
        _restore(kernel, state, entry, before, call)
        detail["classifications"] = receipts
        detail["remaining_C"] = _class_receipt(remainder, call)
        detail["exclusions_are_lowlevel_not_failed_proof_claims"] = True
    else:
        call.need(False, "unknown raw control id")
    return {"population": "point-kernel13", "id": identity, "status": "PASSED", "evidence": detail}


def _safety_ownership(kernel, lazy_case, call):
    model = _model(lazy_case, call)
    state = kernel.create_state(model, check=call.tick)
    before = _snapshot(kernel, state, call)
    error = _refusal_no_move(kernel, state, lambda: kernel.place(state, "NOT_AN_INVENTORY_ID", check=call.tick), call)
    call.need(_same(_snapshot(kernel, state, call)["semantic"], before["semantic"]), "normal refusal no semantic mutation")
    # Mutate only caller-owned input after construction; frozen raw document untouched.
    model["capacity"] = 6
    model["roots"].append([1000,0])
    model["placements"][0]["t"][0][1] = 1
    call.need(_same(_snapshot(kernel, state, call)["semantic"], before["semantic"]), "deep input ownership")
    returned = kernel.snapshot(state, check=call.tick)
    returned["semantic"]["roots"].append([2000,0])
    call.need(_same(_snapshot(kernel, state, call)["semantic"], before["semantic"]), "fresh output ownership")
    malformed = []
    bad = _model(lazy_case, call); bad["capacity"] = True; malformed.append(bad)
    bad = _model(lazy_case, call); bad["placements"][0]["m"] = [[[99,1],True]]; malformed.append(bad)
    bad = _model(lazy_case, call); bad["placements"][1]["id"] = "A"; malformed.append(bad)
    bad = _model(lazy_case, call); bad["placements"][0]["t"].append([[0,0],1]); malformed.append(bad)
    bad = _model(lazy_case, call); bad["prefix"] = [{"id":"A","seed":False,"generation":0}]; malformed.append(bad)
    for bad in malformed:
        call.tick()
        _refusal(kernel, lambda bad=bad: kernel.create_state(bad, check=call.tick), call)
    partial_boundary = {"schema":"explicit-point-model-v1","capacity":12,"roots":[],
                        "boundary":{"t":[[[0,0],6]],"m":[]},
                        "placements":[{"id":"P","origin":[0,0],"t":[[[0,0],6]],"m":[]}],
                        "prefix":[],"order":["P"]}
    s = kernel.create_state(partial_boundary, check=call.tick)
    first, unused_expected, decision = _assert_state(kernel, s, partial_boundary, [], [], call)
    call.need(decision["status"] == "EXACT" and first["semantic"]["active_points"] == [], "boundary alone not active")
    boundary_solutions = _solutions(kernel, s, partial_boundary, [], [], call)
    call.need(_same(boundary_solutions["oracle"]["solution_subsets"], [[]]), "no discretionary activation from boundary")
    after, unused = _place(kernel, s, partial_boundary, [], [], "P", call)
    call.need(after["semantic"]["selected"][-1]["generation"] == 1, "partial fixed boundary is generation source")
    missing_mark = {"schema":"explicit-point-model-v1","capacity":12,"roots":[[0,0],[1,0]],
                    "boundary":{"t":[],"m":[]},"prefix":[],"order":["A","B"],
                    "placements":[{"id":"A","origin":[0,0],"t":[[[0,0],12]],"m":[[[99,1],0]]},
                                  {"id":"B","origin":[1,0],"t":[[[1,0],12]],"m":[]}]}
    s = kernel.create_state(missing_mark, check=call.tick)
    selected = []
    after, decision = _place(kernel, s, missing_mark, selected, [], "A", call)
    call.need(_candidate(after, "B", call)["legal"] and decision["status"] == "FORCED", "missing mark remains compatible with zero")
    disconnected = {"schema":"explicit-point-model-v1","capacity":12,"roots":[[0,0]],
                    "boundary":{"t":[],"m":[]},"prefix":[],"order":["D"],
                    "placements":[{"id":"D","origin":[10,0],"t":[[[10,0],12]],"m":[]}]}
    s = kernel.create_state(disconnected, check=call.tick)
    after, unused = _place(kernel, s, disconnected, [], [], "D", call)
    call.need(after["semantic"]["selected"][-1]["generation"] == 0, "truly disconnected lowlevel tile0")
    island = {"schema":"explicit-point-model-v1","capacity":12,"roots":[[0,0]],
              "boundary":{"t":[],"m":[]},"prefix":[],"order":["A","D"],
              "placements":[{"id":"A","origin":[0,0],"t":[[[0,0],12]],"m":[]},
                            {"id":"D","origin":[10,0],"t":[[[10,0],12]],"m":[]}]}
    s = kernel.create_state(island, check=call.tick)
    island_solutions = _solutions(kernel, s, island, [], [], call)
    call.need(_same(island_solutions["oracle"]["solution_subsets"], [["A"]]), "rooted completion excludes optional island")
    return {"population":"point-kernel-safety3","id":SAFETY_IDS[0],"status":"PASSED",
            "evidence":{"malformed_models":5,"normal_refusal_semantics_unchanged":True,
                        "input_and_output_ownership":True,"boundary_only_not_active":True,
                        "boundary_generation_source":True,"missing_not_zero":True,
                        "disconnected_transition_not_scheduler_trace":True,
                        "no_discretionary_islands":True,
                        "retained_owned_refusal_available":kernel.is_owned_error(error)}}


def _safety_handles(kernel, lazy_case, remote_case, call):
    model = _model(lazy_case, call)
    state = kernel.create_state(model, check=call.tick)
    before = _snapshot(kernel, state, call)
    root = kernel.checkpoint(state, check=call.tick)
    kernel.place(state, "A", check=call.tick)
    abandoned = kernel.checkpoint(state, check=call.tick)
    _restore(kernel, state, root, before, call)
    kernel.place(state, "B", check=call.tick)
    same_length = _snapshot(kernel, state, call)
    _refusal_no_move(kernel, state, lambda: kernel.rollback(state, abandoned, check=call.tick), call)
    call.need(_same(_snapshot(kernel, state, call)["semantic"], same_length["semantic"]), "retired checkpoint cannot revive at equal trail length")
    _restore(kernel, state, root, before, call)
    other = kernel.create_state(_model(lazy_case, call), check=call.tick)
    foreign = kernel.checkpoint(other, check=call.tick)
    _refusal_no_move(kernel, state, lambda: kernel.rollback(state, foreign, check=call.tick), call)
    cursor_row = _classification(kernel, state, [0,0], None, 1, call)
    kernel.place(state, "B", check=call.tick)
    _refusal_no_move(kernel, state, lambda: kernel.classify(state, [0,0], cursor=cursor_row["cursor"], max_positions=1, check=call.tick), call)
    _restore(kernel, state, root, before, call)
    _refusal_no_move(kernel, state, lambda: kernel.classify(state, [0,0], cursor=cursor_row["cursor"], max_positions=1, check=call.tick), call)
    _refusal_no_move(kernel, other, lambda: kernel.classify(other, [0,0], cursor=cursor_row["cursor"], max_positions=1, check=call.tick), call)
    remote_model = _model(remote_case, call)
    remote_state = kernel.create_state(remote_model, check=call.tick)
    remote_cursor = _classification(kernel, remote_state, [0,0], None, 1, call)
    remote_before = _snapshot(kernel, remote_state, call)
    _refusal_no_move(kernel, remote_state, lambda: kernel.classify(remote_state, [10,0], cursor=remote_cursor["cursor"], max_positions=1, check=call.tick), call)
    call.need(_same(_snapshot(kernel, remote_state, call)["semantic"], remote_before["semantic"]), "wrong-point cursor refusal no move")
    return {"population":"point-kernel-safety3","id":SAFETY_IDS[1],"status":"PASSED",
            "evidence":{"stale_path_after_equal_length":True,"foreign_checkpoint":True,
                        "cursor_after_move_and_rollback":True,"foreign_and_wrong_point_cursor":True,
                        "no_checkpoint_or_cursor_serialization_intake":True}}


def _safety_faults(kernel, lazy_case, call):
    recipes = []
    names = ("create_state","snapshot","inspect","place","checkpoint","rollback","exclude","classify","solve_all")
    for name in names:
        call.tick()
        for fault_kind in ("RuntimeError","ValueError","StopIteration","unowned_same_class","retained_owned"):
            call.tick()
            model = _model(lazy_case, call)
            state = kernel.create_state(model, check=call.tick)
            token = kernel.checkpoint(state, check=call.tick)
            if name == "rollback":
                kernel.place(state, "A", check=call.tick)
            if fault_kind == "RuntimeError":
                sentinel = RuntimeError("intentional point-kernel control")
            elif fault_kind == "ValueError":
                sentinel = ValueError("intentional point-kernel control")
            elif fault_kind == "StopIteration":
                sentinel = StopIteration("intentional point-kernel control")
            elif fault_kind == "unowned_same_class":
                sentinel = kernel.PointInputError("intentional unowned same-class control")
                call.need(not kernel.is_owned_error(sentinel), "public message error is unowned")
            else:
                source_state = kernel.create_state(_model(lazy_case, call), check=call.tick)
                sentinel = _refusal(kernel, lambda: kernel.place(source_state, "MISSING", check=call.tick), call)
                call.need(kernel.is_owned_error(sentinel), "retained genuine refusal minted")
            before_vars = dict(vars(sentinel))
            before_args = sentinel.args
            later = RuntimeError("must not replace first fault")
            calls = [0]

            def inject():
                calls[0] += 1
                if calls[0] == 1:
                    call.tick()  # genuine Root accounting BEFORE intentional fault
                    raise sentinel
                raise later

            try:
                if name == "create_state":
                    kernel.create_state(model, check=inject)
                elif name == "snapshot":
                    kernel.snapshot(state, check=inject)
                elif name == "inspect":
                    kernel.inspect(state, check=inject)
                elif name == "place":
                    kernel.place(state, "A", check=inject)
                elif name == "checkpoint":
                    kernel.checkpoint(state, check=inject)
                elif name == "rollback":
                    kernel.rollback(state, token, check=inject)
                elif name == "exclude":
                    kernel.exclude(state, "A", check=inject)
                elif name == "classify":
                    kernel.classify(state, [0,0], max_positions=1, check=inject)
                else:
                    kernel.solve_all(state, check=inject)
            except BaseException as error:
                if call.fault is not None:
                    raise call.fault
                if error is not sentinel:
                    raise
            else:
                call.need(False, "first callback fault must escape")
            call.need(calls[0] == 1, "no callback after latched first fault")
            call.need(vars(sentinel) == before_vars and sentinel.args == before_args, "do not mutate retained exception attributes/args")
            # Faulted State is deliberately discarded: no snapshot/resume/prefix.
            recipes.append({"method":name,"fault":fault_kind,"identical":True,"callback_invocations":1,
                            "exception_attributes_unchanged":True,"faulted_state_resumed":False})
    return {"population":"point-kernel-safety3","id":SAFETY_IDS[2],"status":"PASSED",
            "evidence":{"recipes":recipes,"recipe_count":45,"fault_location":"FIRST_CALLBACK_ONLY",
                        "cleanup_observed":False,"late_mutation_fault_coverage":False}}


def run_point_kernel_controls(kernel, *, raw_models, check):
    """Execute only inside a future reviewed once actual; no import-time fixtures."""
    call = _Call(check)
    call.tick()
    call.need(type(raw_models) is dict, "raw13 complete record")
    canonical = json.dumps(raw_models, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode("utf-8")
    call.tick()
    call.need(hashlib.sha256(canonical).hexdigest() == RAW_CANONICAL_SHA256, "unchanged complete raw13 identity")
    call.need(raw_models.get("schema") == "L-point-proof-independent-raw-model-inputs-v1", "raw schema")
    call.need(_same(raw_models.get("control_ids"), RAW_IDS), "original ordered raw IDs")
    cases = raw_models.get("cases")
    call.need(type(cases) is list and len(cases) == 13, "raw population exactly thirteen")
    raw_controls = []
    by_id = {}
    for index, case in enumerate(cases):
        call.tick()
        call.need(type(case) is dict and case.get("id") == RAW_IDS[index], "raw ordered case identity")
        by_id[case["id"]] = case
        raw_controls.append(_raw_case(kernel, case, call))
    lazy = by_id["lazy-prefix-not-singleton"]
    remote = by_id["remote-mark-only-zero-is-assigned"]
    additions = [
        _safety_ownership(kernel, lazy, call),
        _safety_handles(kernel, lazy, remote, call),
        _safety_faults(kernel, lazy, call),
    ]
    for index, row in enumerate(additions):
        call.tick()
        call.need(row["id"] == SAFETY_IDS[index] and row["status"] == "PASSED", "additional population closure")
    result = {
        "schema": RETURN_SCHEMA, "version": VERSION, "complete": True,
        "raw_population": {"population":"point-kernel13","control_ids":list(RAW_IDS),"controls":raw_controls,
                           "counts":{"groups":13,"passed":13,"failed":0}},
        "additional_population": {"population":"point-kernel-safety3","control_ids":list(SAFETY_IDS),"controls":additions,
                                  "counts":{"groups":3,"passed":3,"failed":0}},
        "counts": {"raw_groups":13,"additional_groups":3,"groups":16,"passed":16,"failed":0},
        "scope": "Only current complete tiny literal explicit-list point behavior. No FPC inventory/search/proof admission, full-provider cursor qualification, resource-fit or speed claim. Existing six/126/caps remain separate and unchanged.",
        "limitations": ["No full-provider coverage or every callback ordinal.",
                        "First-callback identity controls do not observe cleanup or late mutation unwinding.",
                        "query_state cache versions are opaque except exact WHOLE restoration.",
                        "Successful low-level transition tests are not scheduler traces or proof/failure admissions."],
    }
    return _copy(result, call, True)
