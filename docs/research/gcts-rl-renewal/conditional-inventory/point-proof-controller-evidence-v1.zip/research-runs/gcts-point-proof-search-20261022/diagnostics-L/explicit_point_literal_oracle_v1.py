"""Independent tiny literal point-model oracle. Source only; no import-time work.

This recomputes sums, marks, generations and finite subsets from raw functions.
It imports no production kernel, graph, scheduler, trail or FPC implementation.
It is not a parser, proof verifier, full-provider oracle or admission authority.
"""

VERSION = "L-explicit-point-literal-oracle-v1"
MODEL_SCHEMA = "explicit-point-model-v1"
_MARKER = object()


class OracleInputError(ValueError):
    """Message construction is unowned; internal refusals carry call ownership."""


def is_owned_error(error):
    return isinstance(error, OracleInputError) and getattr(error, "_marker", None) is _MARKER


class _Call:
    def __init__(self, check):
        self.check = check
        self.token = object()
        self.fault = None

    def tick(self):
        if self.fault is not None:
            raise self.fault
        try:
            self.check()
        except BaseException as error:
            self.fault = error
            raise

    def reject(self, message):
        error = OracleInputError(message)
        error._marker = _MARKER
        error._owner = self.token
        raise error

    def need(self, condition, message):
        if not condition:
            self.reject(message)


def _keys(value, names, call):
    call.tick()
    call.need(type(value) is dict and set(value) == set(names), "exact record keys")


def _integer(value, call, minimum=None):
    call.tick()
    call.need(type(value) is int, "strict integer")
    if minimum is not None:
        call.need(value >= minimum, "integer lower bound")
    return value


def _point(value, call):
    call.tick()
    call.need(type(value) in (list, tuple) and len(value) == 2, "point pair")
    return (_integer(value[0], call), _integer(value[1], call))


def _mark(value, call):
    call.tick()
    if type(value) in (int, str):
        return value
    call.need(type(value) in (list, tuple), "mark tree")
    result = []
    for child in value:
        call.tick()
        result.append(_mark(child, call))
    return tuple(result)


def _id_atom(value, call):
    call.tick()
    if type(value) is str:
        call.need(bool(value), "empty id string")
        return value
    if type(value) is int:
        return value
    call.need(type(value) is tuple, "immutable typed id tree")
    result = []
    for child in value:
        call.tick()
        result.append(_id_atom(child, call))
    return tuple(result)


def _id(value, call):
    call.tick()
    call.need(type(value) in (str, tuple), "id must be string or immutable tuple")
    return _id_atom(value, call)


def _function(value, is_t, capacity, call):
    call.tick()
    call.need(type(value) in (list, tuple), "point function sequence")
    result = []
    seen = set()
    for entry in value:
        call.tick()
        call.need(type(entry) in (list, tuple) and len(entry) == 2, "point function entry")
        point = _point(entry[0], call)
        call.need(point not in seen, "duplicate function point")
        seen.add(point)
        if is_t:
            item = _integer(entry[1], call, 1)
            call.need(item <= capacity, "units above capacity")
        else:
            item = _mark(entry[1], call)
        result.append((point, item))
    result.sort(key=lambda entry: entry[0])
    return tuple(result)


def _normalize(model, call):
    _keys(model, ("schema", "capacity", "roots", "boundary", "placements", "prefix", "order"), call)
    call.need(model["schema"] == MODEL_SCHEMA, "model schema")
    capacity = _integer(model["capacity"], call, 1)
    call.need(type(model["roots"]) in (list, tuple), "root sequence")
    roots = []
    for item in model["roots"]:
        call.tick()
        point = _point(item, call)
        call.need(point not in roots, "duplicate root")
        roots.append(point)
    roots.sort()
    _keys(model["boundary"], ("t", "m"), call)
    boundary = {
        "t": _function(model["boundary"]["t"], True, capacity, call),
        "m": _function(model["boundary"]["m"], False, capacity, call),
    }
    call.need(type(model["placements"]) in (list, tuple), "inventory sequence")
    placements = []
    by_id = {}
    for raw in model["placements"]:
        call.tick()
        _keys(raw, ("id", "origin", "t", "m"), call)
        identity = _id(raw["id"], call)
        call.need(identity not in by_id, "duplicate inventory id")
        row = {
            "id": identity,
            "origin": _point(raw["origin"], call),
            "t": _function(raw["t"], True, capacity, call),
            "m": _function(raw["m"], False, capacity, call),
        }
        call.need(bool(row["t"]), "empty positive support")
        row["identity"] = (identity, row["origin"], row["t"], row["m"])
        by_id[identity] = row
        placements.append(row)
    call.need(type(model["order"]) in (list, tuple), "order sequence")
    order = []
    for item in model["order"]:
        call.tick()
        identity = _id(item, call)
        call.need(identity in by_id and identity not in order, "order identity")
        order.append(identity)
    call.need(len(order) == len(placements), "order is full permutation")
    call.need(type(model["prefix"]) in (list, tuple), "prefix sequence")
    prefix = []
    prefix_ids = []
    for raw in model["prefix"]:
        call.tick()
        _keys(raw, ("id", "seed", "generation"), call)
        identity = _id(raw["id"], call)
        call.need(identity in by_id and identity not in prefix_ids, "prefix identity")
        call.need(type(raw["seed"]) is bool, "exact seed bool")
        generation = _integer(raw["generation"], call, 0)
        if raw["seed"]:
            call.need(generation == 0, "seed generation")
        prefix.append({"id": identity, "seed": raw["seed"], "generation": generation})
        prefix_ids.append(identity)
    return {
        "capacity": capacity, "roots": tuple(roots), "boundary": boundary,
        "placements": tuple(placements), "by_id": by_id, "prefix": tuple(prefix),
        "prefix_ids": tuple(prefix_ids), "order": tuple(order),
    }


def _ids(values, model, call):
    call.need(type(values) in (list, tuple), "selected/excluded sequence")
    result = []
    for value in values:
        call.tick()
        identity = _id(value, call)
        call.need(identity in model["by_id"] and identity not in result, "selected/excluded identity")
        result.append(identity)
    return result


def _plain(value, call):
    call.tick()
    if type(value) in (tuple, list):
        result = []
        for item in value:
            call.tick()
            result.append(_plain(item, call))
        return result
    if type(value) is dict:
        result = {}
        for key, item in value.items():
            call.tick()
            result[key] = _plain(item, call)
        return result
    call.need(value is None or type(value) in (str, int, bool), "ordinary output value")
    return value


def _compute(model, selected_values, excluded_values, call):
    selected = _ids(selected_values, model, call)
    excluded = _ids(excluded_values, model, call)
    prefix_ids = model["prefix_ids"]
    call.need(tuple(selected[:len(prefix_ids)]) == prefix_ids, "entry prefix must be retained in order")
    call.need(len(selected) >= len(prefix_ids), "entry prefix missing")
    for identity in excluded:
        call.tick()
        call.need(identity not in selected, "selected identity excluded")
    totals = {}
    values = {}
    owners = {}
    generations = {}
    active = set(model["roots"])
    for point in model["roots"]:
        call.tick()
        generations[point] = 0
        totals[point] = 0
    for point, units in model["boundary"]["t"]:
        call.tick()
        totals[point] = totals.get(point, 0) + units
        generations[point] = 0
    for point, value in model["boundary"]["m"]:
        call.tick()
        values[point] = value
        owners[point] = [("BOUNDARY", None)]
    selected_rows = []
    for index, identity in enumerate(selected):
        call.tick()
        row = model["by_id"][identity]
        for point, units in row["t"]:
            call.tick()
            call.need(totals.get(point, 0) + units <= model["capacity"], "selected capacity conflict")
        for point, value in row["m"]:
            call.tick()
            call.need(point not in values or values[point] == value, "selected mark conflict")
        seed = index < len(model["prefix"]) and model["prefix"][index]["seed"]
        sources = []
        for point, unused_units in row["t"]:
            call.tick()
            if point in generations:
                sources.append(generations[point])
        generation = 0 if seed or not sources else 1 + min(sources)
        if index < len(model["prefix"]):
            call.need(generation == model["prefix"][index]["generation"], "nonseed prefix generation mismatch")
        selected_rows.append({"id": identity, "seed": seed, "generation": generation})
        for point, units in row["t"]:
            call.tick()
            totals[point] = totals.get(point, 0) + units
            active.add(point)
            generations[point] = min(generations.get(point, generation), generation)
        for point, value in row["m"]:
            call.tick()
            values[point] = value
            owners.setdefault(point, []).append(("PLACEMENT", identity))
    frontier = []
    active_rows = []
    for point in sorted(active):
        call.tick()
        total = totals.get(point, 0)
        active_rows.append({"point": point, "total": total, "generation": generations[point], "is_root": point in model["roots"]})
        if total < model["capacity"]:
            frontier.append(point)
    candidates = []
    domains = {}
    dependencies = {}
    for point in frontier:
        call.tick()
        domains[point] = []
    for row in model["placements"]:
        call.tick()
        identity = row["id"]
        legal = identity not in selected and identity not in excluded
        for point, units in row["t"]:
            call.tick()
            dependencies.setdefault(point, {"t_ids": [], "m_ids": []})["t_ids"].append(identity)
            if totals.get(point, 0) + units > model["capacity"]:
                legal = False
        for point, value in row["m"]:
            call.tick()
            dependencies.setdefault(point, {"t_ids": [], "m_ids": []})["m_ids"].append(identity)
            if point in values and values[point] != value:
                legal = False
        incidence = []
        if legal:
            for point, unused_units in row["t"]:
                call.tick()
                if point in domains:
                    incidence.append(point)
        candidates.append({"id": identity, "identity": row["identity"], "selected": identity in selected,
                           "excluded": identity in excluded, "legal": legal, "incidence": tuple(incidence)})
    legal_by_id = {}
    for row in candidates:
        call.tick()
        legal_by_id[row["id"]] = row
    for identity in model["order"]:
        call.tick()
        for point in legal_by_id[identity]["incidence"]:
            call.tick()
            domains[point].append(identity)
    inventory_index = {}
    for index, row in enumerate(model["placements"]):
        call.tick()
        inventory_index[row["id"]] = index
    mark_rows = []
    for point in sorted(values):
        call.tick()
        point_owners = list(owners[point])
        point_owners.sort(key=lambda owner: -1 if owner[0] == "BOUNDARY" else inventory_index[owner[1]])
        owner_rows = []
        for kind, identity in point_owners:
            call.tick()
            owner_rows.append({"kind": kind, "id": identity})
        mark_rows.append({"point": point, "value": values[point], "reference_count": len(point_owners), "owners": owner_rows})
    dependency_rows = []
    for point in sorted(dependencies):
        call.tick()
        dependency_rows.append({"point": point, "t_ids": dependencies[point]["t_ids"], "m_ids": dependencies[point]["m_ids"]})
    inventory = []
    for row in model["placements"]:
        call.tick()
        inventory.append({"id": row["id"], "origin": row["origin"], "t": row["t"], "m": row["m"], "identity": row["identity"]})
    excluded_ordered = []
    for row in model["placements"]:
        call.tick()
        if row["id"] in excluded:
            excluded_ordered.append(row["id"])
    semantic = {
        "capacity": model["capacity"], "roots": model["roots"], "boundary": model["boundary"],
        "inventory": inventory, "order": model["order"], "selected": selected_rows,
        "excluded_ids": excluded_ordered, "active_points": active_rows,
        "t_totals": tuple((point, totals[point]) for point in sorted(totals)),
        "marks": mark_rows, "frontier": frontier, "candidates": candidates,
        "dependencies": dependency_rows, "query_state": None,
    }
    if not frontier:
        status, chosen = "EXACT", None
    else:
        empty = []
        singleton = []
        for point in frontier:
            call.tick()
            if len(domains[point]) == 0:
                empty.append(point)
            elif len(domains[point]) == 1:
                singleton.append(point)
        if empty:
            status, chosen = "DEAD", min(empty)
        elif singleton:
            status, chosen = "FORCED", min(singleton)
        else:
            frontier_generations = []
            for point in frontier:
                call.tick()
                frontier_generations.append(generations[point])
            earliest = min(frontier_generations)
            earliest_points = []
            for point in frontier:
                call.tick()
                if generations[point] == earliest:
                    earliest_points.append(point)
            status, chosen = "BRANCH", min(earliest_points)
    decision = {"schema": "explicit-point-scheduler-decision-v1", "status": status, "point": chosen,
                "generation": None if chosen is None else generations[chosen],
                "candidate_ids": [] if chosen is None else domains[chosen], "complete_domains": True}
    return semantic, domains, decision


def inspect_literal_prefix(model, selected_ids, excluded_ids, *, check):
    """Fresh recomputation; selected order is caller-authored, never a graph snapshot."""
    call = _Call(check)
    call.tick()
    normalized = _normalize(model, call)
    semantic, domains, decision = _compute(normalized, selected_ids, excluded_ids, call)
    domain_rows = []
    for point in sorted(domains):
        call.tick()
        domain_rows.append({"point": point, "candidate_ids": domains[point]})
    return _plain({"schema": "independent-literal-point-prefix-v1", "complete": True,
                   "semantic": semantic, "domains": domain_rows, "decision": decision}, call)


def _anchored(model, initial_semantic, added_ids, call):
    """Independent incidence connectivity, no scheduler/graph helper."""
    reached = set()
    for row in initial_semantic["active_points"]:
        call.tick()
        reached.add(row["point"])
    remaining = list(added_ids)
    while remaining:
        call.tick()
        changed = False
        next_remaining = []
        for identity in remaining:
            call.tick()
            row = model["by_id"][identity]
            touches = False
            for point, unused_units in row["t"]:
                call.tick()
                if point in reached:
                    touches = True
            if touches:
                changed = True
                for point, unused_units in row["t"]:
                    call.tick()
                    reached.add(point)
            else:
                next_remaining.append(identity)
        if not changed:
            return False
        remaining = next_remaining
    return True


def enumerate_literal_subsets(model, selected_ids, excluded_ids, *, check):
    """Direct power-set specification for tiny models; no production search call."""
    call = _Call(check)
    call.tick()
    normalized = _normalize(model, call)
    initial, unused_domains, unused_decision = _compute(normalized, selected_ids, excluded_ids, call)
    selected = _ids(selected_ids, normalized, call)
    excluded = _ids(excluded_ids, normalized, call)
    available = []
    for row in normalized["placements"]:
        call.tick()
        if row["id"] not in selected and row["id"] not in excluded:
            available.append(row["id"])
    # The public scope is deliberately tiny. This is not a full-provider enumerator.
    call.need(len(available) <= 20, "tiny subset scope exceeded")
    solutions = []
    subset_count = 1 << len(available)
    for mask in range(subset_count):
        call.tick()
        added = []
        for index, identity in enumerate(available):
            call.tick()
            if mask & (1 << index):
                added.append(identity)
        if not _anchored(normalized, initial, added, call):
            continue
        try:
            semantic, unused_domains, decision = _compute(normalized, selected + added, excluded, call)
        except BaseException as error:
            if call.fault is not None:
                raise call.fault
            if not is_owned_error(error) or getattr(error, "_owner", None) is not call.token:
                raise
            continue
        if decision["status"] != "EXACT":
            continue
        selected_set = set(selected + added)
        vector = []
        ids = []
        for index, row in enumerate(normalized["placements"]):
            call.tick()
            if row["id"] in selected_set:
                vector.append(index)
                ids.append(row["id"])
        solutions.append((tuple(vector), ids))
    solutions.sort(key=lambda item: item[0])
    ordered = []
    for unused_vector, identities in solutions:
        call.tick()
        ordered.append(identities)
    anchors = []
    for row in initial["active_points"]:
        call.tick()
        anchors.append(row["point"])
    return _plain({"schema": "independent-literal-point-subsets-v1", "complete": True,
                   "solution_subsets": ordered, "subset_count": subset_count,
                   "accepted_subset_count": len(ordered), "entry_anchor_points": anchors}, call)
