"""Exact finite-list point search. SOURCE ONLY; not imported or runtime-qualified.

Contract: L explicit-point-kernel API v1 plus its generation binding. Ground
placements and their complete finite inventory are input; this module performs
no geometric tests, FPC enumeration, proof checking, learning or RL. Normal
search enumerates entry-support-anchored completions and restores its caller.
"""

VERSION = "explicit-point-kernel-v1"
_OWNER = object()
_ABSENT = object()


class PointInputError(ValueError):
    """Public construction is unowned; only the current call mints refusals."""


def is_owned_error(error):
    return type(error) is PointInputError and getattr(error, "_owner", None) is _OWNER


class _Call:
    def __init__(self, check, state=None):
        self.check = check
        self.state = state
        self.first = None
        self.token = object()
        self.calls = 0

    def tick(self):
        if self.first is not None:
            raise self.first
        self.calls += 1
        if self.state is not None:
            self.state.callbacks += 1
        try:
            self.check()
        except BaseException as error:
            self.first = error
            raise

    def fail(self, message):
        if self.first is not None:
            raise self.first
        error = PointInputError(message)
        error._owner = _OWNER
        error._call = self.token
        raise error


class _State:
    pass


class _Checkpoint(tuple):
    __slots__ = ()

    def __new__(cls, state, depth, tag):
        return tuple.__new__(cls, (_OWNER, state, depth, tag))

    owner = property(lambda self: self[0])
    state = property(lambda self: self[1])
    depth = property(lambda self: self[2])
    tag = property(lambda self: self[3])


class _Cursor(tuple):
    __slots__ = ()

    def __new__(cls, state, point, position, witnesses):
        return tuple.__new__(cls, (_OWNER, state, state.epoch, point, position, witnesses))

    owner = property(lambda self: self[0])
    state = property(lambda self: self[1])
    epoch = property(lambda self: self[2])
    point = property(lambda self: self[3])
    position = property(lambda self: self[4])
    witnesses = property(lambda self: self[5])


def _owned_state(state):
    return type(state) is _State and getattr(state, "owner", None) is _OWNER


def _run(call, state, operation):
    # A faulted handle never resumes, including by snapshot or another callback.
    if _owned_state(state) and state.poison is not None:
        raise state.poison
    try:
        call.tick()
        if state is not None and not _owned_state(state):
            call.fail("foreign state")
        return operation()
    except BaseException as error:
        target = call.state if _owned_state(call.state) else None
        if call.first is not None:
            if target is not None:
                target.poison = call.first
            raise call.first
        if is_owned_error(error) and getattr(error, "_call", None) is call.token:
            raise
        if target is not None:
            target.poison = error
        raise


def _keys(value, keys, call):
    call.tick()
    if type(value) is not dict:
        call.fail("expected exact dict")
    for key in value:
        call.tick()
        if type(key) is not str:
            call.fail("non-string record key")
    if set(value) != set(keys):
        call.fail("record keys")


def _integer(value, call, minimum=None, maximum=None):
    call.tick()
    if type(value) is not int:
        call.fail("expected strict integer")
    if minimum is not None and value < minimum:
        call.fail("integer below range")
    if maximum is not None and value > maximum:
        call.fail("integer above range")
    return value


def _sequence(value, call, length=None):
    call.tick()
    if type(value) not in (list, tuple):
        call.fail("expected sequence")
    if length is not None and len(value) != length:
        call.fail("sequence length")
    return value


def _point(value, call):
    value = _sequence(value, call, 2)
    return (_integer(value[0], call), _integer(value[1], call))


def _freeze(value, call, lists=True):
    """Iterative, cycle-detecting exact value copy; bool/float/null refused."""
    stack = [(0, value)]
    values = []
    active = set()
    while stack:
        call.tick()
        kind, node = stack.pop()
        if kind:
            identity, count = node
            children = values[-count:] if count else []
            if count:
                del values[-count:]
            active.remove(identity)
            values.append(tuple(children))
        elif type(node) in (int, str):
            values.append(node)
        elif type(node) is tuple or (lists and type(node) is list):
            identity = id(node)
            if identity in active:
                call.fail("cyclic value")
            active.add(identity)
            stack.append((1, (identity, len(node))))
            for child in reversed(node):
                call.tick()
                stack.append((0, child))
        else:
            call.fail("invalid exact value")
    return values[0]


def _identifier(value, call):
    result = _freeze(value, call, lists=False)
    if type(result) not in (str, tuple) or not result:
        call.fail("empty or invalid placement id")
    return result


def _thaw(value, call):
    stack = [(0, value)]
    result = []
    while stack:
        call.tick()
        kind, node = stack.pop()
        if kind:
            children = result[-node:] if node else []
            if node:
                del result[-node:]
            result.append(children)
        elif type(node) is tuple:
            stack.append((1, len(node)))
            for child in reversed(node):
                call.tick()
                stack.append((0, child))
        else:
            result.append(node)
    return result[0]


def _function(items, capacity, marking, call):
    _sequence(items, call)
    result = {}
    for item in items:
        call.tick()
        _sequence(item, call, 2)
        point = _point(item[0], call)
        if point in result:
            call.fail("duplicate function point")
        result[point] = (_freeze(item[1], call) if marking else
                         _integer(item[1], call, 1, capacity))
    return tuple(sorted(result.items()))


def _placement(value, capacity, call):
    _keys(value, ("id", "origin", "t", "m"), call)
    identity = _identifier(value["id"], call)
    origin = _point(value["origin"], call)
    t = _function(value["t"], capacity, False, call)
    if not t:
        call.fail("empty positive support")
    m = _function(value["m"], capacity, True, call)
    # A declared inventory id cannot subsequently acquire different point data.
    return (identity, origin, t, m, (identity, origin, t, m))


class _Journal:
    def __init__(self):
        self.items = []

    def mapping(self, mapping, key, value):
        old = mapping.get(key, _ABSENT)
        if value is _ABSENT:
            if old is _ABSENT:
                return
            self.items.append(("map", mapping, key, old))
            del mapping[key]
        else:
            self.items.append(("map", mapping, key, old))
            mapping[key] = value

    def member(self, collection, value, present):
        old = value in collection
        if old == present:
            return
        self.items.append(("set", collection, value, old))
        if present:
            collection.add(value)
        else:
            collection.remove(value)

    def append(self, target, value):
        self.items.append(("list", target, len(target), None))
        target.append(value)

    def slot(self, target, index, value):
        if target[index] == value:
            return
        self.items.append(("slot", target, index, target[index]))
        target[index] = value


def _point_generation(state, point, call):
    sources = state.generations.get(point, ())
    result = None
    for _, generation in sources:
        call.tick()
        result = generation if result is None else min(result, generation)
    return result


def _move_generation(state, index, call):
    found = []
    for point, _ in state.placements[index][2]:
        call.tick()
        generation = _point_generation(state, point, call)
        if generation is not None:
            found.append(generation)
    return 1 + min(found) if found else 0


def _legal(state, index, call):
    call.tick()
    state.metrics["candidate_checks"] += 1
    if index in state.selected or index in state.excluded:
        return False
    placement = state.placements[index]
    for point, units in placement[2]:
        call.tick()
        if state.totals.get(point, 0) + units > state.capacity:
            return False
    for point, value in placement[3]:
        call.tick()
        if point in state.marks and state.marks[point] != value:
            return False
    return True


def _refresh(state, journal, t_points, m_points, explicit, call):
    """Complete reverse indexes limit updates; a remote conflict is global."""
    affected = set(explicit)
    for point in t_points:
        call.tick()
        affected.update(state.reverse_t.get(point, ()))
        desired = point in state.active and state.totals.get(point, 0) < state.capacity
        old = point in state.frontier
        if desired != old:
            journal.member(state.frontier, point, desired)
            journal.mapping(state.domains, point, set() if desired else _ABSENT)
    for point in m_points:
        call.tick()
        affected.update(state.reverse_m.get(point, ()))
    for index in sorted(affected):
        call.tick()
        journal.slot(state.legal, index, _legal(state, index, call))
    for index in sorted(affected):
        call.tick()
        for point, _ in state.placements[index][2]:
            call.tick()
            desired = state.legal[index] and point in state.frontier
            journal.member(state.incidence[index], point, desired)
            if point in state.frontier:
                journal.member(state.domains[point], index, desired)
            state.metrics["edge_updates"] += 1


def _commit(state, journal, call):
    call.tick()
    state.trail.append(journal.items)
    state.path.append(object())
    state.epoch += 1
    state.metrics["mutations"] += 1


def _index(state, identity, call):
    key = _identifier(identity, call)
    if key not in state.by_id:
        call.fail("unknown placement")
    return state.by_id[key]


def _apply_place(state, index, seed, expected_generation, call):
    if not state.legal[index]:
        call.fail("illegal selected or excluded placement")
    generation = 0 if seed else _move_generation(state, index, call)
    if expected_generation is not None and generation != expected_generation:
        call.fail("prefix generation mismatch")
    placement = state.placements[index]
    journal = _Journal()
    journal.member(state.selected, index, True)
    journal.append(state.selection_order, index)
    journal.mapping(state.tile_generations, index, generation)
    if seed:
        journal.member(state.seeds, index, True)
    t_points = set()
    m_points = set()
    for point, units in placement[2]:
        call.tick()
        t_points.add(point)
        journal.mapping(state.totals, point, state.totals.get(point, 0) + units)
        journal.mapping(state.active, point, state.active.get(point, 0) + 1)
        sources = state.generations.get(point, ())
        journal.mapping(state.generations, point, sources + ((index, generation),))
    for point, value in placement[3]:
        call.tick()
        m_points.add(point)
        journal.mapping(state.marks, point, value)
        journal.mapping(state.mark_owners, point, state.mark_owners.get(point, ()) + (index,))
    _refresh(state, journal, t_points, m_points, (index,), call)
    _commit(state, journal, call)
    return {"id": placement[0], "generation": generation}


def _create(model, call):
    _keys(model, ("schema", "capacity", "roots", "boundary", "placements", "prefix", "order"), call)
    if type(model["schema"]) is not str or model["schema"] != "explicit-point-model-v1":
        call.fail("model schema")
    capacity = _integer(model["capacity"], call, 1)
    roots = []
    _sequence(model["roots"], call)
    for point in model["roots"]:
        call.tick()
        point = _point(point, call)
        if point in roots:
            call.fail("duplicate root")
        roots.append(point)
    _keys(model["boundary"], ("t", "m"), call)
    boundary_t = _function(model["boundary"]["t"], capacity, False, call)
    boundary_m = _function(model["boundary"]["m"], capacity, True, call)
    placements = []
    by_id = {}
    _sequence(model["placements"], call)
    for value in model["placements"]:
        call.tick()
        placement = _placement(value, capacity, call)
        if placement[0] in by_id:
            call.fail("duplicate inventory id")
        by_id[placement[0]] = len(placements)
        placements.append(placement)
    _sequence(model["order"], call)
    order = []
    for identity in model["order"]:
        call.tick()
        identity = _identifier(identity, call)
        if identity not in by_id or by_id[identity] in order:
            call.fail("invalid placement order")
        order.append(by_id[identity])
    if len(order) != len(placements):
        call.fail("incomplete placement order")
    prefix = []
    prefix_ids = set()
    _sequence(model["prefix"], call)
    for item in model["prefix"]:
        call.tick()
        _keys(item, ("id", "seed", "generation"), call)
        identity = _identifier(item["id"], call)
        if identity not in by_id or identity in prefix_ids:
            call.fail("invalid prefix id")
        prefix_ids.add(identity)
        if type(item["seed"]) is not bool:
            call.fail("prefix seed flag")
        generation = _integer(item["generation"], call, 0)
        if item["seed"] and generation != 0:
            call.fail("seed generation")
        prefix.append((by_id[identity], item["seed"], generation))

    state = _State()
    state.owner = _OWNER
    state.poison = None
    state.callbacks = call.calls
    state.epoch = 0
    state.metrics = {"candidate_checks": 0, "edge_updates": 0, "mutations": 0}
    call.state = state
    state.capacity = capacity
    state.roots = frozenset(roots)
    state.boundary_t = boundary_t
    state.boundary_m = boundary_m
    state.placements = tuple(placements)
    state.by_id = by_id
    state.order = tuple(order)
    state.totals = dict(boundary_t)
    state.active = {}
    state.generations = {}
    for point in roots:
        call.tick()
        state.active[point] = 1
        state.generations[point] = ((-2, 0),)
        state.totals.setdefault(point, 0)
    for point, _ in boundary_t:
        call.tick()
        state.generations[point] = state.generations.get(point, ()) + ((-1, 0),)
    state.marks = dict(boundary_m)
    state.mark_owners = {}
    for point, _ in boundary_m:
        call.tick()
        state.mark_owners[point] = (-1,)
    state.selected = set()
    state.selection_order = []
    state.tile_generations = {}
    state.seeds = set()
    state.excluded = set()
    state.reverse_t = {}
    state.reverse_m = {}
    for index, placement in enumerate(placements):
        call.tick()
        for point, _ in placement[2]:
            call.tick()
            state.reverse_t.setdefault(point, []).append(index)
        for point, _ in placement[3]:
            call.tick()
            state.reverse_m.setdefault(point, []).append(index)
    state.legal = []
    state.incidence = []
    for _ in placements:
        call.tick()
        state.incidence.append(set())
    state.frontier = set()
    state.domains = {}
    state.trail = []
    state.path = [object()]
    for point in state.active:
        call.tick()
        if state.totals.get(point, 0) < capacity:
            state.frontier.add(point)
            state.domains[point] = set()
    for index, placement in enumerate(placements):
        call.tick()
        legal = _legal(state, index, call)
        state.legal.append(legal)
        if legal:
            for point, _ in placement[2]:
                call.tick()
                if point in state.frontier:
                    state.incidence[index].add(point)
                    state.domains[point].add(index)
    for index, seed, generation in prefix:
        call.tick()
        _apply_place(state, index, seed, generation, call)
    # No checkpoint exists before this fixed entry prefix. Drop its journals.
    call.tick()
    state.trail = []
    state.path = [object()]
    return state


def create_state(model, *, check):
    call = _Call(check)
    return _run(call, None, lambda: _create(model, call))


def _checkpoint(state, call):
    call.tick()
    return _Checkpoint(state, len(state.trail), state.path[-1])


def checkpoint(state, *, check):
    call = _Call(check, state if _owned_state(state) else None)
    return _run(call, state, lambda: _checkpoint(state, call))


def _rollback(state, marker, call):
    call.tick()
    if (type(marker) is not _Checkpoint or marker.owner is not _OWNER or
            marker.state is not state or marker.depth >= len(state.path) or
            state.path[marker.depth] is not marker.tag):
        call.fail("foreign or abandoned checkpoint")
    while len(state.trail) > marker.depth:
        call.tick()
        journal = state.trail.pop()
        for kind, target, key, old in reversed(journal):
            call.tick()
            if kind == "map":
                if old is _ABSENT:
                    target.pop(key, None)
                else:
                    target[key] = old
            elif kind == "set":
                if old:
                    target.add(key)
                else:
                    target.discard(key)
            elif kind == "slot":
                target[key] = old
            else:
                del target[key:]
        state.path.pop()
    call.tick()
    state.epoch += 1
    state.metrics["mutations"] += 1


def rollback(state, marker, *, check):
    call = _Call(check, state if _owned_state(state) else None)
    return _run(call, state, lambda: _rollback(state, marker, call))


def place(state, placement_id, *, check):
    call = _Call(check, state if _owned_state(state) else None)
    return _run(call, state, lambda: _apply_place(state, _index(state, placement_id, call), False, None, call))


def _exclude(state, index, call):
    call.tick()
    if index in state.selected or index in state.excluded:
        call.fail("selected or already excluded identity")
    journal = _Journal()
    journal.member(state.excluded, index, True)
    _refresh(state, journal, (), (), (index,), call)
    _commit(state, journal, call)


def exclude(state, placement_id, *, check):
    call = _Call(check, state if _owned_state(state) else None)
    return _run(call, state, lambda: _exclude(state, _index(state, placement_id, call), call))


def _domain_ids(state, point, call):
    result = []
    for index in state.order:
        call.tick()
        if index in state.domains[point]:
            result.append(state.placements[index][0])
    return result


def _inspect(state, call):
    points = sorted(state.frontier)
    chosen = None
    status = "EXACT"
    for point in points:
        call.tick()
        if not state.domains[point]:
            chosen, status = point, "DEAD"
            break
    if chosen is None:
        for point in points:
            call.tick()
            if len(state.domains[point]) == 1:
                chosen, status = point, "FORCED"
                break
    if chosen is None and points:
        # A deterministic point key breaks only generation ties; no global MRV.
        chosen = min(points, key=lambda point: (_point_generation(state, point, call), point))
        status = "BRANCH"
    return {"schema": "explicit-point-scheduler-decision-v1", "status": status,
            "point": list(chosen) if chosen is not None else None,
            "generation": _point_generation(state, chosen, call) if chosen is not None else None,
            "candidate_ids": _domain_ids(state, chosen, call) if chosen is not None else [],
            "complete_domains": True}


def inspect(state, *, check):
    call = _Call(check, state if _owned_state(state) else None)
    return _run(call, state, lambda: _inspect(state, call))


def _classify(state, point, cursor, max_positions, call):
    point = _point(point, call)
    if point not in state.frontier:
        call.fail("classification point outside frontier")
    if max_positions is not None:
        _integer(max_positions, call, 0)
    if cursor is None:
        position, witnesses = 0, []
    else:
        if (type(cursor) is not _Cursor or cursor.owner is not _OWNER or
                cursor.state is not state or cursor.epoch != state.epoch or cursor.point != point):
            call.fail("foreign stale or cross-point cursor")
        position, witnesses = cursor.position, list(cursor.witnesses)
    stop = len(state.order) if max_positions is None else min(len(state.order), position + max_positions)
    while position < stop:
        call.tick()
        index = state.order[position]
        position += 1
        if index in state.domains[point]:
            witnesses.append(index)
    exhausted = position == len(state.order)
    status = "MANY" if len(witnesses) >= 2 else ("SINGLE" if witnesses else "EMPTY") if exhausted else "UNRESOLVED"
    call.tick()
    result_cursor = _Cursor(state, point, position, tuple(witnesses))
    witness_ids = []
    for index in witnesses:
        call.tick()
        witness_ids.append(state.placements[index][0])
    return {"schema": "explicit-point-classification-v1", "status": status,
            "point": list(point), "inspected_positions": position, "next_position": position,
            "witness_ids": witness_ids,
            "exhausted": exhausted, "cursor": result_cursor}


def classify(state, point, *, cursor=None, max_positions=None, check):
    call = _Call(check, state if _owned_state(state) else None)
    return _run(call, state, lambda: _classify(state, point, cursor, max_positions, call))


def _function_record(items, marking, call):
    result = []
    for point, value in items:
        call.tick()
        result.append([list(point), _thaw(value, call) if marking else value])
    return result


def _identity_record(placement, call):
    return [placement[0], list(placement[1]), _function_record(placement[2], False, call),
            _function_record(placement[3], True, call)]


def _id_records(state, indices, call):
    result = []
    for index in indices:
        call.tick()
        result.append(state.placements[index][0])
    return result


def _point_records(points, call):
    result = []
    for point in points:
        call.tick()
        result.append(list(point))
    return result


def _snapshot(state, call):
    inventory = []
    candidates = []
    for index, placement in enumerate(state.placements):
        call.tick()
        identity = _identity_record(placement, call)
        inventory.append({"id": placement[0], "origin": list(placement[1]),
                          "t": _function_record(placement[2], False, call),
                          "m": _function_record(placement[3], True, call), "identity": identity})
        candidates.append({"id": placement[0], "identity": _identity_record(placement, call),
                           "selected": index in state.selected, "excluded": index in state.excluded,
                           "legal": state.legal[index],
                           "incidence": _point_records(sorted(state.incidence[index]), call)})
    marks = []
    for point in sorted(state.marks):
        call.tick()
        owners = []
        for index in sorted(state.mark_owners[point]):
            call.tick()
            owners.append({"kind": "BOUNDARY" if index == -1 else "PLACEMENT",
                           "id": None if index == -1 else state.placements[index][0]})
        marks.append({"point": list(point), "value": _thaw(state.marks[point], call),
                      "reference_count": len(owners), "owners": owners})
    dependencies = []
    for point in sorted(set(state.reverse_t) | set(state.reverse_m)):
        call.tick()
        dependencies.append({"point": list(point),
            "t_ids": _id_records(state, state.reverse_t.get(point, ()), call),
            "m_ids": _id_records(state, state.reverse_m.get(point, ()), call)})
    selected = []
    for index in state.selection_order:
        call.tick()
        selected.append({"id": state.placements[index][0], "seed": index in state.seeds,
                         "generation": state.tile_generations[index]})
    excluded_ids = []
    for index, placement in enumerate(state.placements):
        call.tick()
        if index in state.excluded:
            excluded_ids.append(placement[0])
    active_points = []
    for point in sorted(state.active):
        call.tick()
        active_points.append({"point": list(point), "total": state.totals.get(point, 0),
            "generation": _point_generation(state, point, call), "is_root": point in state.roots})
    totals = []
    for point in sorted(state.totals):
        call.tick()
        totals.append([list(point), state.totals[point]])
    semantic = {"capacity": state.capacity, "roots": _point_records(sorted(state.roots), call),
        "boundary": {"t": _function_record(state.boundary_t, False, call),
                     "m": _function_record(state.boundary_m, True, call)},
        "inventory": inventory, "order": _id_records(state, state.order, call),
        "selected": selected, "excluded_ids": excluded_ids, "active_points": active_points,
        "t_totals": totals,
        "marks": marks, "frontier": _point_records(sorted(state.frontier), call),
        "candidates": candidates, "dependencies": dependencies, "query_state": None}
    call.tick()
    return {"schema": "explicit-point-state-snapshot-v1", "semantic": semantic,
            "diagnostics": {"epoch": state.epoch, "callbacks": state.callbacks, "metrics": dict(state.metrics)}}


def snapshot(state, *, check):
    call = _Call(check, state if _owned_state(state) else None)
    return _run(call, state, lambda: _snapshot(state, call))


def _solve_all(state, call):
    metrics = {key: 0 for key in ("inspect_calls", "place_calls", "forced_moves", "branch_nodes",
        "backtracks", "exclusions", "solution_visits", "duplicate_solutions", "max_selected", "max_frontier")}
    entry = _checkpoint(state, call)
    branches = []
    solutions = []
    seen = set()
    while True:
        call.tick()
        metrics["max_selected"] = max(metrics["max_selected"], len(state.selected))
        metrics["max_frontier"] = max(metrics["max_frontier"], len(state.frontier))
        decision = _inspect(state, call)
        metrics["inspect_calls"] += 1
        status = decision["status"]
        if status in ("EXACT", "DEAD"):
            if status == "EXACT":
                metrics["solution_visits"] += 1
                solution_indices = []
                for index in range(len(state.placements)):
                    call.tick()
                    if index in state.selected:
                        solution_indices.append(index)
                solution = tuple(solution_indices)
                if solution in seen:
                    metrics["duplicate_solutions"] += 1
                else:
                    seen.add(solution)
                    solutions.append(solution)
            if not branches:
                break
            parent, tried_index = branches.pop()
            _rollback(state, parent, call)
            # This child is now wholly enumerated (or immediately contradicted).
            # No UNKNOWN/fault path reaches this exclusion.
            _exclude(state, tried_index, call)
            metrics["backtracks"] += 1
            metrics["exclusions"] += 1
            continue
        index = state.by_id[decision["candidate_ids"][0]]
        if status == "BRANCH":
            branches.append((_checkpoint(state, call), index))
            metrics["branch_nodes"] += 1
        else:
            metrics["forced_moves"] += 1
        _apply_place(state, index, False, None, call)
        metrics["place_calls"] += 1
    _rollback(state, entry, call)
    result_subsets = []
    for solution in sorted(solutions):
        call.tick()
        result_subsets.append(_id_records(state, solution, call))
    call.tick()
    return {"schema": "explicit-point-all-solutions-v1", "complete": True,
            "status": "EXHAUSTED_FINITE_MODEL", "solution_subsets": result_subsets, "metrics": metrics}


def solve_all(state, *, check):
    call = _Call(check, state if _owned_state(state) else None)
    return _run(call, state, lambda: _solve_all(state, call))
