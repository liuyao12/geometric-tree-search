from pathlib import Path, PurePosixPath
from zipfile import ZipFile
import hashlib
import json
import stat
import zlib

BASE = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
STUDY = BASE / 'research-runs/gcts-point-proof-search-20261022'
ROOT = STUDY / 'root'
OUT = ROOT / 'report-v1'
REVIEW = STUDY / 'review-C'


def pin(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def load(path):
    return json.loads(path.read_bytes())


def safe(name):
    p = PurePosixPath(name)
    return bool(p.parts) and not p.is_absolute() and '\\' not in name and str(p) == name and all(x not in ('', '.', '..') for x in p.parts)


def match(path, expected):
    value = pin(path)
    assert value['bytes'] == expected['bytes'] and value['sha256'] == expected['sha256'], str(path)
    return value


manifest_path = OUT / 'point-proof-search-manifest-v1.json'
manifest = load(manifest_path)
receipt_path = ROOT / 'point-search-packaging-receipt-v1.json'
packaging = load(receipt_path)
assert packaging['schema'] == 'Root-point-search-display-packaging-v1'
assert packaging['raw_files'] == 25 and packaging['raw_bytes'] == 315919 and packaging['zip_members'] == 27
output_pins = [match(OUT / row['name'], row) for row in packaging['artifacts']]
assert len(output_pins) == 5 and len({row['path'] for row in output_pins}) == 5
assert manifest['source_files'] == manifest['archive']['files']
rows = manifest['source_files']
assert len(rows) == 25 and len({row['path'] for row in rows}) == 25
assert all(safe(row['path']) for row in rows)
assert sum(row['bytes'] for row in rows) == 315919
current = {}
for row in rows:
    p = BASE / row['path']
    assert p.is_file() and not p.is_symlink() and p.resolve().is_relative_to(BASE)
    current[row['path']] = match(p, row)

archive_path = OUT / 'point-proof-search-evidence-v1.zip'
member_pins = []
with ZipFile(archive_path) as z:
    infos = z.infolist()
    names = [i.filename for i in infos]
    assert len(names) == 27 and len(set(names)) == 27
    assert names == [row['path'] for row in rows] + ['MANIFEST.json', 'README.txt']
    for info in infos:
        assert safe(info.filename) and not info.is_dir() and not (info.flag_bits & 1)
        kind = stat.S_IFMT(info.external_attr >> 16)
        assert kind in (0, stat.S_IFREG)
        sha = hashlib.sha256()
        length = 0
        crc = 0
        with z.open(info) as stream:
            while True:
                chunk = stream.read(65536)
                if not chunk:
                    break
                length += len(chunk)
                sha.update(chunk)
                crc = zlib.crc32(chunk, crc)
        assert length == info.file_size and (crc & 0xffffffff) == info.CRC
        value = {'member': info.filename, 'bytes': length, 'sha256': sha.hexdigest(), 'crc32': f'{info.CRC:08x}'}
        member_pins.append(value)
    by_name = {row['member']: row for row in member_pins}
    for row in rows:
        actual = by_name[row['path']]
        assert actual['bytes'] == row['bytes'] and actual['sha256'] == row['sha256']
    snapshot = z.read('MANIFEST.json')
    assert json.loads(snapshot) == manifest['archive']
    assert len(snapshot) == 7622 and hashlib.sha256(snapshot).hexdigest() == 'af97f8a4f585d5ca8aec809a9f591343e3d4fc0dac600a4fd764b21f90824f78'
    readme = z.read('README.txt').decode('utf-8')
    assert 'All new controls are unrun' in readme and 'No theorem proof' in readme
assert sum(row['bytes'] for row in member_pins[:25]) == 315919
assert sum(row['bytes'] for row in member_pins) == 323834

decision_path = ROOT / 'point-proof-search-integration-decision-v1.json'
selection_path = ROOT / 'point-proof-new-model-selection-v1.json'
decision = load(decision_path)
selection = load(selection_path)
assert selection['decision'] == 'ACCEPT_NEW_MODEL_FOR_NEXT_ABI_DESIGN_ONLY'
assert selection['implementation_ready'] is False and selection['scientific_runtime_authority'] is False
match(decision_path, selection['integration'])
for row in decision['evidence'] + selection['concept_reviews']:
    assert Path(row['path']).relative_to(BASE).as_posix() in current
    match(Path(row['path']), row)
assert decision['new_scientific_execution'] is False and decision['current_result'] is None
assert decision['preserved']['old_controls'] == {'baseline56': 56, 'obligation47': 47, 'intro_integration1': 1, 'regression2': 2, 'point20': 20}
assert decision['preserved']['caps'] == {'work_seconds': 160, 'positive_seconds': 180, 'custody_seconds': 210, 'observer_fallback_seconds': 225, 'memory_bytes_strict_less_than': 1073741824, 'physical_bytes': 134217728, 'reserved_outer_bytes': 9437184, 'result_bytes': 50331648, 'log_bytes': 4194304, 'root_callbacks': 400000000}
data_path = OUT / 'point-proof-search-data-v1.json'
data = load(data_path)
assert data['status'] == 'MODEL_CONCEPT_REVIEWED_UNIMPLEMENTED_UNRUN'
for key, value in [('original_targets', 6), ('original_scoped_control_groups', 126), ('new_declarative_point_groups', 13), ('new_scientific_executions', 0), ('new_proofs_discovered', 0)]:
    assert type(data[key]) is int and data[key] == value
assert data['new_groups_executed'] is False
assert all(data[key] is None for key in ('qualification', 'strict_finite_Wang_palette', 'learned_GCTS_effect', 'RL_effect', 'comparison_result'))
assert data['concept_review'] == [{key: row[key] for key in ('bytes', 'sha256')} for row in selection['concept_reviews']]
raw13 = load(STUDY / 'diagnostics-L/point-proof-independent-raw-models-v1.json')
assert len(raw13['cases']) == 13 and [row['id'] for row in raw13['cases']] == raw13['control_ids']
assert len(set(raw13['control_ids'])) == 13

preimage_path = ROOT / 'parent-reader-preimage-v1.html'
parent_path = OUT / 'reader.html'
old = preimage_path.read_bytes()
new = parent_path.read_bytes()
match(preimage_path, manifest['parent']['preimage'])
match(parent_path, manifest['parent']['result'])
assert old.count(b'</body>') == 1
cut = old.index(b'</body>')
assert new[:cut] == old[:cut] and new[cut + 608:] == old[cut:]
addition = new[cut:cut + 608]
assert len(addition) == manifest['parent']['addition']['bytes'] == 608
assert hashlib.sha256(addition).hexdigest() == manifest['parent']['addition']['sha256']
assert new[:cut] + new[cut + 608:] == old
assert b'point-proof-search-v1' not in old and addition.count(b'id="point-proof-search-v1"') == 1
html_path = OUT / 'point-proof-search-v1.html'
html = html_path.read_text()
assert 'Design progress, not a discovered proof' in html
assert 'Model reviewed; unimplemented.' in html and 'No new proof from this study.' in html
assert html.count('data-degree=') == 4 and '.textContent=descriptions[' in html
for fragment in ('#tiles', '#inventory', '#domains', '#parallel', '#next'):
    assert f'id="{fragment[1:]}"' in html
for filename in ('point-proof-search-evidence-v1.zip', 'point-proof-search-manifest-v1.json', 'point-proof-search-data-v1.json'):
    assert f'href="{filename}"' in html
assert 'reader.html#point-proof-search-v1' in html
assert 'new Function' not in html and 'eval(' not in html
for row in rows:
    match(BASE / row['path'], row)
for row in output_pins:
    match(Path(row['path']), row)

review = {
    'schema': 'GCTS-C-point-proof-design-public-package-review-v1',
    'review_passed': True,
    'scope': 'Independent Source/manual, complete declarative JSON and streamed raw ZIP review only. No extraction, scientific/helper/JS/browser execution, generated fixtures or Publisher mutation.',
    'inputs': [pin(decision_path), pin(selection_path), pin(receipt_path), pin(manifest_path), pin(preimage_path)],
    'artifacts': output_pins,
    'archive_census': {'raw_files': 25, 'raw_payload_bytes': 315919, 'members': 27, 'total_member_bytes': 323834, 'embedded_manifest_bytes': 7622, 'README_bytes': 293, 'all_lengths_SHA256_CRC32_verified': True, 'safe_unique_non_directory_non_special_members': True, 'extractions': 0, 'member_pins': member_pins},
    'checks': [
        {'id': 'Root-integration-and-model-selection', 'passed': True, 'finding': 'Complete decision and selection read. B (n,b) is selected explicitly from L broader (n,V,D,M), with V=b,M=b and redundant D=b-1; full original Gamma remains in GEN even where a HYP member is outside the envelope. Exact placement identity, five families/eight schemas/induction, exact length, fair conditional restart, no late cluster members and original scopes/caps agree with the current C concept reviews. Strict cursor/state/atomic-transition ABI and all executable/whole gates remain pending.'},
        {'id': 'L-semantic-and-control-proposal-scope', 'passed': True, 'finding': 'All three L bodies were read in full; the initially truncated raw-case middle was retrieved separately. All thirteen literal cases and their stated scheduler/transition expectations were checked manually without enumeration or helper execution. No inconsistent literal found. Root precedence resolves L source-outside shorthand: unused out-of-envelope hypotheses need not force growth and still govern GEN. Raw13 remains prospective, additive and unrun. Transition-only cases are not falsely described as scheduler traces. A future subset verifier must include declared seeds and active positive-support deficits for the selected mode; tiny literal coverage does not qualify the full parametric provider or all callback paths.'},
        {'id': 'scientific-claims-and-static-display', 'passed': True, 'finding': 'Full HTML and compact data read. They say concept reviewed, engine/provider unimplemented, new scientific executions/proofs zero, qualification and comparative effects null, six targets/126 old groups retained and thirteen new groups unrun. Mandatory formula markings stay in all lanes; all-root-zero/unit-support limitations, parametric-versus-finite-Wang distinction, same-inventory comparison and consumed failure/no-prefix constraints are explicit. Formula/rule picture is labeled schematic. Established LaTeX/MathJax delimiters are present. Buttons only select fixed explanatory text using textContent; no proof computation or data authority is assigned to the UI. No C rendering/mobile/console or live-deployment claim.'},
        {'id': 'complete-archive-equality-and-public-allowlist', 'passed': True, 'finding': 'Every one of 27 members streamed to EOF with full byte length, SHA-256 and CRC32 verification; all 25 explicit raw sources equal current files before/after readback. Embedded manifest object equals outer archive snapshot; outer source list equals that snapshot. Safe unique relative names, no directory/symlink/special/encrypted members, no extra files. Explicit public design/master/calculus/adapter/declaration/review bodies only; no runtime binary, private actual, old proof/result/policy body, partial intake or recursive eligibility. Source references are not adopted proof inputs. Archive has no new execution or grant authority.'},
        {'id': 'exact-parent-splice-and-navigation', 'passed': True, 'finding': 'Allowed saved 139495-byte parent preimage plus exactly 608 bytes before its unique closing body gives the 140103-byte candidate. Entire old prefix and suffix preserved; inverse exact, addition hash exact and new section ID absent from the preimage. New report/archive/manifest/data basenames and notebook backlink agree. No primary reader/index or Publisher body was read or changed by C.'}
    ],
    'parent_addition': {'bytes': len(addition), 'sha256': hashlib.sha256(addition).hexdigest(), 'text': addition.decode()},
    'complete_current_source_pins': list(current.values()),
    'failures': [],
    'scientific_imports_calls': 0,
    'execution_authority': False,
    'Root_admission_issued': False,
    'publication_action_taken': False,
    'review_program': pin(Path(__file__))
}
target = REVIEW / 'typed-point-proof-design-public-package-review-v1.json'
with target.open('x') as stream:
    json.dump(review, stream, ensure_ascii=True, indent=2)
    stream.write('\n')
print(json.dumps(pin(target)))
print(addition.decode())
