"""Raw/AST metadata authoring and inert patch only; no target evaluation."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import subprocess

D=Path(__file__).parent
P=Path('/private/tmp/gcts-owned-evidence-integration-library-20261019/owned_evidence_cold_v3.py')
I=Path('/private/tmp/gcts-inverse-cadence-ROOT-20261019/independent_forest_inverse_v7.py')
M=Path('/private/tmp/gcts-owned-evidence-integration-ROOT-20261019/basic-tiling-algorithm.md')
PP=Path('/private/tmp/gcts-owned-evidence-integration-library-20261019/EVIDENCE_PROFILE-v3.json')
def pin(p):
    p=Path(p);raw=p.read_bytes()
    return dict(path=str(p),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))
def write(name,value):
    p=D/name;assert not p.exists(),name
    p.write_text(json.dumps(value,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
    return pin(p)
assert pin(P)==dict(path=str(P),sha256='a445a7fbbd2575c13223268cd23f0ad910d93bc34415421ec5583bee876828d4',bytes=62795)
assert pin(I)==dict(path=str(I),sha256='fcbed7c5b95c8b8e6b1fc152c3d93689d644aa2e3ac32810dc77857e475750a7',bytes=24144)
assert pin(M)==dict(path=str(M),sha256='c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9',bytes=21657)
assert pin(PP)==dict(path=str(PP),sha256='4a3fdafeed39e74c9a931c09800d26931e638d93f8b64b66d751541c719922bb',bytes=3648)
old=P.read_text();before=ast.parse(old)
assignments={n.targets[0].id:n for n in before.body if isinstance(n,ast.Assign)and isinstance(n.targets[0],ast.Name)}
literal=lambda name:ast.literal_eval(assignments[name].value)
changes=[];new=old
def replace(oldtext,newtext,label):
    global new
    assert new.count(oldtext)==1,(label,new.count(oldtext))
    new=new.replace(oldtext,newtext,1);changes.append(dict(label=label,old=oldtext,new=newtext))
replace("VERSION = 'owned-evidence-intake-cold-v3'","VERSION = 'owned-evidence-intake-cold-v4'",'own implementation version only')
old_evidence=literal('EVIDENCE_SOURCES');new_evidence=dict(old_evidence);new_evidence['inverse']=pin(I)
old_text=ast.get_source_segment(old,assignments['EVIDENCE_SOURCES'])
new_text=old_text.replace(repr(old_evidence['inverse']),repr(new_evidence['inverse']))
assert old_text!=new_text
replace(old_text,new_text,'only inverse Source descriptor in fixed four-role evidence map')
replace("INVERSE_VERSION = 'independent-evidence-forest-inverse-v6-full-scalar-and-ledger-bounds'",
        "INVERSE_VERSION = 'independent-evidence-forest-inverse-v7-bounded-callback-cadence'",'current inverse public version')
replace("INVERSE_PROFILE = 'independent-forest-actual-operations-v1'",
        "INVERSE_PROFILE = 'independent-forest-actual-operations-v2-callback-cadence1024'",'explicit changed inverse callback execution profile')
S=D/'owned_evidence_cold_v4.py';assert not S.exists()
after=ast.parse(new);compile(new,str(S),'exec');S.write_text(new);source=pin(S)

checks=[]
def check(name,condition,details):
    assert condition,name
    checks.append(dict(name=name,passed=True,method='raw Source/AST/metadata only',details=details))
check('four_constant_replacements',len(changes)==4,'No function-body or other statement change.')
reversed_text=new
for c in reversed(changes):
    assert reversed_text.count(c['new'])==1
    reversed_text=reversed_text.replace(c['new'],c['old'],1)
check('whole_raw_inverse',reversed_text==old,'Exact old complete Source recovered by four reversed replacements.')
aa=ast.parse(reversed_text)
check('whole_AST_inverse',ast.dump(aa,include_attributes=False)==ast.dump(before,include_attributes=False),'Whole parent AST exact after constant inverse.')
old_regions={n.name:n for n in before.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
new_regions={n.name:n for n in after.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
retained=[]
check('same_function_class_names',set(old_regions)==set(new_regions),'No function/class added or removed.')
for name,node in old_regions.items():
    other=new_regions[name];raw_equal=ast.get_source_segment(old,node)==ast.get_source_segment(new,other)
    AST_equal=ast.dump(node,include_attributes=False)==ast.dump(other,include_attributes=False)
    check('retained_'+name,raw_equal and AST_equal,'Entire body raw and AST exact, including main and all diagnostics.')
    retained.append(dict(name=name,parent_line=node.lineno,current_line=other.lineno,
                         raw_equal=raw_equal,AST_equal=AST_equal))
new_assign={n.targets[0].id:n for n in after.body if isinstance(n,ast.Assign)and isinstance(n.targets[0],ast.Name)}
for name,node in assignments.items():
    if name in ('VERSION','EVIDENCE_SOURCES','INVERSE_VERSION','INVERSE_PROFILE'):continue
    check('unchanged_constant_'+name,
        ast.get_source_segment(old,node)==ast.get_source_segment(new,new_assign[name]),
        'Whole raw constant retained, including every numeric cap and binding.')
check('same_schema_keys',literal('PLAN_SCHEMA')=='ROOT-owned-evidence-integration-worker-plan-v1'and
      literal('WORKER_SCHEMA')=='owned-evidence-integration-worker-receipt-v1',
      'Only implementation Source/version changes, no new wire/API/worker fields.')
check('same28_and_schema1',"len(names)==28"in new and "len(loaded)==28 and len(schema_loaded)==1"in new,
      'Same full early28 module aliases and later schema1 import/seal path.')
check('same_full001',"plan['receiver_id']=='prospective-fol-20261018-001'"in new,
      'Exact original001 assertion, no fallback/rescue input.')
check('all_caps_retained',all(str(n)in new for n in (180000000000,210000000000,134217728,400000000,30000000)),
      'No numeric budget or per-operation guard raised.')
check('same_diagnostics',"stores==8"in new and "ADAPTER_DIAGNOSTICS[4]"in new,'Same five groups/eight small Stores, unmodified test bodies.')
check('same_full_checks',all(x in new for x in ('verify_saved_evidence(','verify_literal_result(','verify_raw_region(',"canonical(result_data['records'])==canonical(oracle_box[0].records)")),
      'Fresh complete inverse, old full result decode/canonical inverse, point and Native ledger gates preserved.')

# Read the already frozen ordinary metadata profile; update exactly the three
# fields whose literal Source bindings changed. No component is evaluated.
profile=json.loads(PP.read_text());previous=json.loads(PP.read_text())
profile['sources']['inverse']=pin(I)
profile['inverse_version']='independent-evidence-forest-inverse-v7-bounded-callback-cadence'
profile['inverse_execution_profile']='independent-forest-actual-operations-v2-callback-cadence1024'
restored=json.loads(json.dumps(profile));restored['sources']['inverse']=previous['sources']['inverse']
restored['inverse_version']=previous['inverse_version'];restored['inverse_execution_profile']=previous['inverse_execution_profile']
check('profile_only_three_fields',restored==previous,'Every other full literal profile field, including diagnostics, remains exact.')
check('profile_matches_raw_bindings',profile['sources']==new_evidence,'Complete evidence Source map equals new raw constant.')
profile_pin=write('EVIDENCE_PROFILE-v4.json',profile)

# Apply actual inert forward/reverse text patches to fresh scratch copies.
patches=[]
for direction,start,wanted in [('forward',old,new),('inverse',new,old)]:
    patch=''.join(difflib.unified_diff(start.splitlines(True),wanted.splitlines(True),fromfile='cold.py',tofile='cold.py'))
    patch_path=D/('source-'+direction+'.patch');assert not patch_path.exists();patch_path.write_text(patch)
    scratch=D/'inert-patch'/direction;scratch.mkdir(parents=True)
    (scratch/'cold.py').write_text(start)
    process=subprocess.run(['/usr/bin/patch','--batch','-p0','-i',str(patch_path)],cwd=scratch,capture_output=True,text=True)
    assert process.returncode==0,(process.stdout,process.stderr)
    actual=(scratch/'cold.py').read_text();assert actual==wanted
    ast.parse(actual);compile(actual,str(scratch/'cold.py'),'exec')
    patches.append(dict(direction=direction,patch=pin(patch_path),result=pin(scratch/'cold.py'),
        actual_patch_applied=True,whole_bytes_equal=True,unused_compile=True,target_execution=False))
api=write('API-v1.json',dict(schema='inverse-cadence-integration-cold-API-v1',source=source,
    VERSION='owned-evidence-intake-cold-v4',entry='main(argv)',argv=['worker_plan','began_ns','work_deadline_ns','overall_deadline_ns'],
    unchanged_API_from=pin('/private/tmp/gcts-owned-evidence-integration-library-20261019/cold-API-v3.json'),
    PLAN_SCHEMA=literal('PLAN_SCHEMA'),EPOCH_SCHEMA=literal('EPOCH_SCHEMA'),WORKER_SCHEMA=literal('WORKER_SCHEMA'),
    EVIDENCE_PROFILE=profile,evidence_profile_raw=profile_pin,
    inverse=pin(I),inverse_VERSION=profile['inverse_version'],inverse_EXECUTION_PROFILE=profile['inverse_execution_profile'],
    same_alias='independent_forest_inverse',base_alias_count=28,separate_schema_alias_count=1,
    caller_requirements=['Root new exact declaration/closure/once plan/grants bind current V4 Source and full changed profile.',
        'Root outer authenticates new inverse raw+owned module pins, V7 VERSION/profile and callback statistics from saved result.',
        'All current full source/runtime/native/program/policy/input/Model/point/Native verification and resource gates remain required.',
        'This successor is inactive until distinct Source/plan/final-grant reviews and Root-only invocation.']))
argument=write('Source-argument-v1.json',dict(schema='inverse-cadence-integration-cold-Source-argument-v1',source=source,parent=pin(P),
    author_identity='/root/conventional_library',master=pin(M),master_read_full=True,changes=changes,
    retained_regions=retained,logical_body_changes=False,numeric_cap_changes=False,
    scope='Source-only coupling to separately qualified independent inverse V7. No scientific candidate/Model/search/ranking/Native rule or evidence datum changed.',
    ancestry='Author of parent cold/diagnostics, arena/registry and earlier Model/point work. This is an author static equivalence argument, not an independent certificate of own components.',
    limits=['No component function, fixture, Native, Model, search, codec or inverse was executed/imported.',
        'V7 changes callback dispatch profile; no claim of unchanged old ordinal/fault timing or runtime speed/memory improvement.',
        'No claim current full001 pair fits180/210 or resources. Future exact once cohort and all failures remain separate.',
        'Preserved logical proof and full verification bodies do not make specialized symbolic chronology the GCTS master scheduler.',
        'No old fixed failed actual is recovered or retried by Source authoring.']))
contract=write('Source-contract-v1.json',dict(schema='inverse-cadence-integration-cold-Source-contract-v1',source=source,sources=[source],
    author_identity='/root/conventional_library',parent=pin(P),master=pin(M),API=api,argument=argument,
    evidence_profile=profile_pin,inverse=pin(I),unchanged_evidence_sources={k:v for k,v in new_evidence.items()if k!='inverse'},
    source_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,
    unchanged='Every function/class/main body, all numeric limits and old public schemas/aliases are raw+AST identical. Only four constant bindings differ.',
    preserved_profile=dict(work_seconds=180,overall_seconds=210,worker_plus_Native_peak_bytes=1073741824,
        physical_output_bytes=134217728,logical_output_bytes=134217728,logs_bytes_each=4194304,
        arena_work=400000000,adapter_operations=400000000,inverse_operations=30000000),
    review_ABI=dict(schema='inverse-cadence-integration-cold-typed-Source-review-v1',author_identity='/root/conventional_library',
        reviewer_must_be_distinct=True,required_fields=['schema','source','sources','source_contract','author_identity','reviewer_identity',
            'source_only','source_review_passed','scientific_calls','scientific_acceptance','actual_execution_authorized','findings','limitations']),
    activation='Not authorized. Root owns exact new declaration/runtime/outer/plans/grants and independent current reviews.'))
audit=write('author-static-audit-v1.json',dict(schema='inverse-cadence-integration-author-static-audit-v1',source=source,parent=pin(P),
    author_identity='/root/conventional_library',independent=False,checks=checks,check_count=len(checks),mismatches=0,
    retained_regions=retained,inert_patches=patches,unused_compiles=3,
    scientific_calls=0,component_imports=0,component_calls=0,fixture_calls=0,
    runtime_tests='NOT_EXECUTED',actual_execution_authorized=False))
delta=write('Source-delta-v1.json',dict(schema='inverse-cadence-integration-cold-delta-v1',source=source,parent=pin(P),
    changes=changes,retained_regions=retained,inert_patches=patches,parent_raw_inverse_exact=True,parent_AST_inverse_exact=True,
    prior_artifacts_mutated=False,metadata_profile_changes=['sources.inverse','inverse_version','inverse_execution_profile']))
handoff=write('handoff-v1.json',dict(schema='inverse-cadence-integration-cold-author-handoff-v1',source=source,sources=[source],
    author_identity='/root/conventional_library',source_contract=contract,API=api,argument=argument,evidence_profile=profile_pin,
    author_static_audit=audit,delta=delta,parent=pin(P),inverse=pin(I),master=pin(M),
    source_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,
    status='FROZEN_SOURCE_ONLY_NOT_PIPELINE_QUALIFIED',pending='Distinct exact Source review and Root current closure/declaration/outer/prospective/final grant gates; no activation.'))
print(json.dumps(dict(source=source,profile=profile_pin,handoff=handoff,checks=len(checks),retained_regions=len(retained))))
