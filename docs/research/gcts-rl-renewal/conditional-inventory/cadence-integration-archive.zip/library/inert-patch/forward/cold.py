"""Root cold adapter for the declared semantic-family receiver.

This module is authored and compiled without evaluation. Only Root's separately
granted, exclusive external runner may invoke it. All project imports, native
table preparation, checking, search and result work occur inside that window.
"""
import time
_NOW_NS = time.monotonic_ns
import builtins
import ctypes
import gzip
import hashlib
import importlib
import json
import math
import os
from pathlib import Path
import platform
import stat
import sys
import types

VERSION = 'owned-evidence-intake-cold-v4'
PLAN_SCHEMA = 'ROOT-owned-evidence-integration-worker-plan-v1'
EPOCH_SCHEMA = 'semantic-family-receiver-source-epoch-v6-explicit-schema-admission'
WORKER_SCHEMA = 'owned-evidence-integration-worker-receipt-v1'
PROGRAM_SHA = '877c47879b027b08f02d3923d1e6dd9ccaf9a12e354567109f1aaa640a8fb673'
MICRO_SHA = '2f9e430b0b7034ed615d81c3e9b3978dc47ba4136686227a9b86df5779b203ac'
ROLE_MODULES = {'base_compiler': 'quantified_receptors_v1', 'family_miner': 'semantic_lemma_inventory', 'family_model': 'quantified_family_points_v2', 'family_search': 'semantic_inventory_search_v2', 'family_registry': 'semantic_inventory_oracle', 'point_smt': 'semantic_point_smt', 'symbolic_control': 'quantified_symbolic_control_v2', 'support_ordering': 'receptor_support_ordering_v1'}

PARENT_RUNTIME_CLOSURE = {'path': '/private/tmp/gcts-local-operational-20261019/parent-runtime-closure.json', 'sha256': '214e306b85ec29ea8863c32509c47649e4984c76498752d92d2b9756fcfe5c58', 'bytes': 73601}
COMPACT_MODEL_SOURCE = {'path': '/private/tmp/gcts-compact-point-representation-source-20261018/interned_quantified_family_points_v1.py', 'sha256': 'fb37663b4c0c3de4e9f3c28564678af833857f7ebe761cd83275d62f123b9a8e', 'bytes': 4311}
RECEIVER_DRIVER_SOURCE = {'path': '/private/tmp/gcts-owned-evidence-integration-ROOT-20261019/owned_evidence_receiver_driver_v4.py', 'sha256': '4850f66edeeb73033979ab5860ca745d5936eb3455bbef3eba10e5ba0c5ff62c', 'bytes': 114308}
REGISTRY_SOURCE = {'path': '/private/tmp/gcts-owned-evidence-integration-library-20261019/semantic_inventory_oracle_v5.py', 'sha256': '1692345882cd14076f52ad257ab9e29daac92711a677c6febb17664b47a07ee0', 'bytes': 55841}
ORDERING_COMPONENT_SOURCES = {'family_search': {'bytes': 15936, 'path': '/private/tmp/gcts-and-support-point-source-20261018/semantic_inventory_search_v2.py', 'sha256': '35443c958f2115efa18cc923fb4a4f1070e6e03ccf1d1adf2bb56ce1f7bab28b'}, 'support_ordering': {'path': '/private/tmp/gcts-schema-admission-ROOT-source-20261019/schema_admission_support_ordering_v2.py', 'bytes': 18508, 'sha256': '6e39f5cf5cd261c73515c29d3b315c43c27ae0bc64ef5fb509cea178b0251769'}, 'symbolic_control': {'path': '/private/tmp/gcts-schema-admission-ROOT-source-20261019/schema_admission_symbolic_control_v3.py', 'bytes': 27203, 'sha256': '8eda5d6fd91a137c9d22081bcba707631ab29733d2ae4ce413a2913a2b7d3bbe'}}

SCHEMA_SOURCES = {'mp_schema_certificate': {'path': '/private/tmp/gcts-mp-schema-source-20261019/mp_schema_certificate_v1.py', 'bytes': 26687, 'sha256': '7351d5954763e8b671411a78a821e5cc560ac1af19477a9491da573a735d2ae4'}}
SCHEMA_KERNEL_SOURCE = {'path': '/private/tmp/gcts-semantic-family-next-audit-20261018/fol_checker.tree', 'sha256': '8c86a24231d9c7d1777d7998b747a8cfd07087c168da64db6c5dff0820c802ed', 'bytes': 17577}

ORDINARY_MODEL_SOURCE = {'path': '/private/tmp/gcts-schema-admission-ROOT-source-20261019/schema_admission_family_points_v3.py', 'bytes': 8155, 'sha256': '7f95858af5af40d2f902d2aea6bc5d5a7944f7fe0b65b6b9a2ea66c0fb2ec4e3'}

MODEL_STORAGE_MODULES = {
    'ordinary': 'quantified_family_points_v2',
    'literal_interned': 'interned_quantified_family_points_v1',
}

# Owned evidence is an additional representation boundary, never proof authority.
EVIDENCE_SOURCES = {'adapter': {'path': '/private/tmp/gcts-owned-evidence-integration-ROOT-20261019/owned_evidence_adapter_v3.py', 'sha256': '91fb57f8a3fdd4563cb74f641b630bd725b813bd305608463920dd191f0216a8', 'bytes': 14997}, 'arena': {'path': '/private/tmp/gcts-direct-reconcile-library-20261019/exact_evidence_arena_v3.py', 'sha256': 'fd3f1e1372c59365cc43c06dd8c815bdaca8cab6a2e4fa292d23a901d7f146f8', 'bytes': 38300}, 'join': {'path': '/private/tmp/gcts-owned-evidence-integration-ROOT-20261019/owned_inventory_join_v2.py', 'sha256': '0287ee16f2da0cd2f8303f97f295f5e9bf091452718ef2f0fe2f3d0804daa872', 'bytes': 13359}, 'inverse': {'path': '/private/tmp/gcts-inverse-cadence-ROOT-20261019/independent_forest_inverse_v7.py', 'sha256': 'fcbed7c5b95c8b8e6b1fc152c3d93689d644aa2e3ac32810dc77857e475750a7', 'bytes': 24144}}
EVIDENCE_ALIASES = {'adapter':'owned_evidence_adapter','arena':'exact_evidence_arena',
                    'join':'owned_inventory_join','inverse':'independent_forest_inverse'}
ARENA_LIMITS = {'cache_bytes':8388608,'cache_entries':65536,'chunk_bytes':65536,'depth':512,
    'documents_expanded_bytes':134217728,'edges':8000000,'fragment_bytes':4096,'integer_digits':4096,
    'materialized_bytes':4194304,'materialized_occurrences':100000,'nodes':2000000,
    'root_expanded_bytes':134217728,'roots':4096,'scalar_bytes':16777216,'wire_bytes':134217728,'work':400000000}
ADAPTER_LIMITS = {'operations':400000000,'value_bytes':134217728,'depth':512,'chunk_bytes':65536}
INVERSE_LIMITS = {'nodes':2000000,'edges':8000000,'roots':4096,'depth':513,'work':30000000,
    'expanded_bytes':134217728,'wire_bytes':134217728,'scalar_bytes':16777216,'integer_digits':4096,
    'fragment_bytes':4096,'cache_bytes':8388608,'cache_entries':65536,'chunk_bytes':65536}
INVERSE_VERSION = 'independent-evidence-forest-inverse-v7-bounded-callback-cadence'
INVERSE_PROFILE = 'independent-forest-actual-operations-v2-callback-cadence1024'
EVIDENCE_DOCUMENT = 'receiver:complete-legacy-result'
OUTPUT_CAP_BYTES = 134217728
EVIDENCE_PROFILE = dict(schema='owned-evidence-integration-profile-v1',sources=EVIDENCE_SOURCES,
    arena_limits=ARENA_LIMITS,adapter_limits=ADAPTER_LIMITS,inverse_limits=INVERSE_LIMITS,
    inverse_version=INVERSE_VERSION,inverse_execution_profile=INVERSE_PROFILE,
    logical_output='complete-legacy-JSON-body-plus-LF',sole_document=EVIDENCE_DOCUMENT,
    unfinished_storage='NO_COMPLETE_RESULT_NO_PROOF_OR_RESOURCE_ADMISSION',
    physical_accounting='ordinary_result+forest+all_root_JSON_metadata_including_worker_receipt',
    encoded_and_logical_cap_bytes=OUTPUT_CAP_BYTES)

ADAPTER_DIAGNOSTICS = (
    'tuple_projection_and_typed_paths',
    'assembly_repeated_roots_and_full_canonical_body',
    'foreign_callback_exception_identity',
    'callback_reentrancy_fails_closed',
    'failed_assembly_prefix_has_no_usable_output')
DIAGNOSTIC_ARENA_LIMITS = dict(ARENA_LIMITS,work=1000000,nodes=4096,edges=16384,roots=64,
    depth=32,scalar_bytes=1048576,wire_bytes=1048576,root_expanded_bytes=1048576,
    documents_expanded_bytes=1048576,materialized_bytes=1048576,
    materialized_occurrences=10000,cache_bytes=4096,cache_entries=256,chunk_bytes=4096)
DIAGNOSTIC_ADAPTER_LIMITS = dict(operations=100000,value_bytes=1048576,depth=32,chunk_bytes=4096)
ADAPTER_DIAGNOSTIC_PROFILE = dict(schema='owned-adapter-finite-diagnostic-profile-v1',
    cases=list(ADAPTER_DIAGNOSTICS),maximum_fresh_Stores=8,
    arena_limits=DIAGNOSTIC_ARENA_LIMITS,adapter_limits=DIAGNOSTIC_ADAPTER_LIMITS,
    scope='Small finite adapter boundary checks before original full001 proof pipeline; same original total work/peak/output caps, not a carrier benchmark or proof authority.')
EVIDENCE_PROFILE['adapter_diagnostics']=ADAPTER_DIAGNOSTIC_PROFILE


class ColdError(ValueError):
    pass


def need(ok, message):
    if not ok:
        raise ColdError(message)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=False, allow_nan=False).encode('utf8')


def descriptor(path, raw=None):
    p=Path(path).resolve()
    if raw is None:
        raw=p.read_bytes()
    return dict(path=str(p), sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw))


def raw_file(pin, cap=134217728):
    need(type(pin) is dict and set(pin)=={'path','sha256','bytes'}, 'exact raw descriptor')
    p=Path(pin['path'])
    need(p.is_absolute() and p==p.resolve(), 'canonical absolute raw path')
    fd=os.open(str(p),os.O_RDONLY|os.O_NOFOLLOW)
    try:
        info=os.fstat(fd)
        need(stat.S_ISREG(info.st_mode) and info.st_size<=cap, 'bounded regular raw file')
        chunks=[];total=0
        while True:
            b=os.read(fd,65536)
            if not b:
                break
            total+=len(b);need(total<=cap,'raw file growth beyond cap');chunks.append(b)
        raw=b''.join(chunks)
        need(total==info.st_size and descriptor(p,raw)==pin,'whole raw size/hash/EOF')
        return raw
    finally:
        os.close(fd)


def write_new(path, value):
    raw=canonical(value)+b'\n'
    fd=os.open(str(path),os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
    try:
        at=0
        while at<len(raw):
            n=os.write(fd,raw[at:at+65536]);need(n>0,'whole new metadata output');at+=n
        os.fsync(fd)
    finally:
        os.close(fd)
    return descriptor(path,raw)


def seal_callables(modules, classes=()):
    """Retain identities and code objects; mutable search data is not frozen."""
    bindings=[];codes=[];seen_classes=set()
    def function(f):
        if isinstance(f,types.FunctionType):
            codes.append((f,f.__code__,f.__globals__,f.__defaults__,f.__kwdefaults__))
    def klass(c):
        if c in seen_classes:
            return
        seen_classes.add(c)
        for name,value in list(vars(c).items()):
            if isinstance(value,(staticmethod,classmethod)):
                bindings.append((c,name,value));function(value.__func__)
            elif isinstance(value,types.FunctionType):
                bindings.append((c,name,value));function(value)
            elif isinstance(value,property):
                bindings.append((c,name,value))
                for f in (value.fget,value.fset,value.fdel):
                    function(f)
    for module in modules:
        for name,value in list(vars(module).items()):
            if isinstance(value,(types.FunctionType,types.ModuleType,type,types.BuiltinFunctionType)):
                bindings.append((module,name,value));function(value)
                if isinstance(value,type) and value.__module__==module.__name__:
                    klass(value)
    for c in classes:
        klass(c)
    def guard():
        for owner,name,value in bindings:
            need(vars(owner).get(name) is value,'sealed callable/module binding: '+name)
        for f,code,namespace,defaults,kwdefaults in codes:
            need(f.__code__ is code and f.__globals__ is namespace and
                 f.__defaults__ is defaults and f.__kwdefaults__ is kwdefaults,
                 'sealed function code/globals/defaults')
    return guard


def verify_raw_region(data, work_ns):
    """Whole literal t/m union and row decoding, without engine/solver calls."""
    def check():
        need(_NOW_NS()<work_ns,'whole-region verification inside original work')
    def point(p):
        need(type(p) in (list,tuple) and len(p)==2 and all(type(v) is int for v in p),'exact integer point')
        return tuple(p)
    check();model=data['outputs']['model'];initial=data['initial_state']
    required={point(p) for p in model['roots']}
    need(len(required)==len(model['roots']) and required=={point(p) for p in initial['allowed_points']},'whole required target')
    totals={point(p):v for p,v in initial['totals']};marks={point(p):v for p,v in initial['marks']}
    need(len(totals)==len(initial['totals']) and len(marks)==len(initial['marks']),'unambiguous initial assignments')
    need(set(totals)<=required and all(type(v) is int and 0<=v<=12 for v in totals.values()),'initial exact unit capacity')
    candidates={tuple(p['key']):p for p in model['placements']}
    need(len(candidates)==len(model['placements']),'unique complete placement identity')
    selected=[tuple(k) for k in data['outputs']['search']['placements']]
    need(len(set(selected))==len(selected),'no duplicate selected placement')
    proof=data['outputs']['search']['proof'];slots={}
    for key in selected:
        check();need(key in candidates,'selected original candidate')
        c=candidates[key]
        need(len(key)==4 and all(type(v) is int for v in key) and 0<=key[0]<len(proof) and 0<=key[1]<2+model['arity'],'positional proof tile')
        need(c['occupancy']==[[[4*key[0],key[1]],12]],'declared single-root unit tile')
        need(key[:2] not in slots,'one tile for each row role');slots[key[:2]]=c
        for p,v in c['occupancy']:
            p=point(p);need(p in required and type(v) is int and v>0,'exact required t-support')
            totals[p]=totals.get(p,0)+v;need(totals[p]<=12,'whole-region capacity')
        for p,v in c['marks']:
            p=point(p);need(type(v) is int,'declared exact integer m-value')
            need(p not in marks or marks[p]==v,'whole-region assigned m-values agree')
            marks[p]=v
    need(set(totals)==required and all(v==12 for v in totals.values()),'every required point reaches exact capacity')
    need(len(slots)==len(proof)*(2+model['arity']),'complete row-role rectangle')
    definitions={d['name']:d['definition'] for d in data['outputs']['register']['definitions']}
    for j,line in enumerate(proof):
        check();row=[slots[j,r] for r in range(2+model['arity'])]
        command=dict(row[0]['command']);need(command==row[1]['command'],'C/G literal command agreement')
        if command['rule']=='block':
            n=len(definitions[command['name']]['premises'])
            ports=[row[2+r]['source'] for r in range(n)]
            need(all(type(i) is int and 0<=i<j for i in ports),'strict-earlier ordered receptor inputs')
            command['inputs']=ports
        need(command==line,'whole native proof is the decoded selected row')
    need(data['outputs']['final_request']['proof']==proof,'selected proof/final request literal join')
    check()
    return dict(status='VERIFIED_WHOLE_FINITE_POINT_REGION',selected_placements=len(selected),
        required_points=len(required),assigned_mark_points=len(marks),decoded_rows=len(proof),
        union_sha256=hashlib.sha256(canonical(dict(totals=sorted(totals.items()),marks=sorted(marks.items()),selected=sorted(selected)))).hexdigest(),
        completed_ns=_NOW_NS(),scope='Separate raw whole-target occupancy, initial/selected marking agreement and literal C/G/input row decoding; no engine, solver or logical kernel call.')


def verify_literal_result(data, raw, checkpoint):
    """Full streaming canonical inverse on the pinned writer domain."""
    checkpoint()
    body = raw[:-1] if raw.endswith(b'\n') else raw
    encoder = json.JSONEncoder(sort_keys=True, separators=(',', ':'),
                               ensure_ascii=False, allow_nan=False)
    offset = 0; chunks = 0
    for text in encoder.iterencode(data):
        value = text.encode('utf8')
        need(raw[offset:offset+len(value)] == value, 'whole canonical literal byte comparison')
        offset += len(value); chunks += 1
        if chunks % 65536 == 0:
            checkpoint()
    need(offset == len(body), 'whole canonical writer EOF')
    checkpoint()
    return dict(literal_bytes_equal=True, body_bytes=offset,
                body_sha256=hashlib.sha256(body).hexdigest(), chunks=chunks)


def select_receiver(declaration, receiver_id):
    """Select exact ordinary assertion data, never a route or proof."""
    need(type(declaration) is dict and
         declaration.get('schema')=='ROOT-closed-quantified-benchmark-declaration-v1',
         'frozen structural cohort declaration')
    need(type(receiver_id) is str and bool(receiver_id), 'explicit nonempty receiver selector')
    receivers=declaration.get('receivers')
    need(type(receivers) is list and bool(receivers), 'complete nonempty receiver list')
    ids=[]
    for spec in receivers:
        need(type(spec) is dict and type(spec.get('id')) is str and bool(spec['id']),
             'ordinary receiver with exact ID')
        ids.append(spec['id'])
    need(len(ids)==len(set(ids)), 'unique receiver IDs in whole declaration')
    need(receiver_id in ids, 'selected receiver must occur exactly once')
    spec=receivers[ids.index(receiver_id)]
    need(type(spec.get('length')) is int and spec['length']==12 and
         type(spec.get('instantiation_rounds')) is int and spec['instantiation_rounds']==2,
         'unchanged twelve-row/two-round receiver profile')
    return dict(schema='closed-quantified-receiver-selection-v1',
                receiver_id=receiver_id,spec=json.loads(canonical(spec)))



def verify_saved_evidence(inverse, wire, forest_pin, result_raw, epoch, check):
    """Independent fresh forest preparation and complete BODY+one-LF byte join.

    This verifies representation only. No hash or arena reference substitutes
    for either the ordinary point check or final current Native proof check.
    """
    check()
    need(type(wire) is dict and set(wire)=={'schema','version','source_epoch','semantic_epoch','roots','documents','nodes'},
         'exact seven-field saved forest')
    need(wire['schema']=='exact-evidence-forest-v1' and wire['version']=='exact-evidence-arena-v1' and
         type(wire['source_epoch']) is str and type(wire['semantic_epoch']) is str and
         wire['source_epoch']==canonical(epoch).decode('utf8') and
         wire['semantic_epoch']==canonical(epoch['evidence_storage']).decode('utf8'),
         'full literal Source and semantic epoch headers')
    need(type(wire['documents']) is list and wire['documents']==[EVIDENCE_DOCUMENT],
         'sole complete legacy logical document')
    need(inverse.VERSION==INVERSE_VERSION and inverse.EXECUTION_PROFILE==INVERSE_PROFILE,
         'qualified independent inverse ABI/profile')
    started=_NOW_NS();observed={}
    prepared=inverse.prepare_forest(wire,check,limits=dict(INVERSE_LIMITS),statistics=observed)
    check()
    need(prepared.documents==(EVIDENCE_DOCUMENT,),'prepared sole logical document')
    source=prepared.iter_document(EVIDENCE_DOCUMENT);offset=0
    try:
        while True:
            check()
            try:
                part=next(source)
            except StopIteration:
                # A delegated StopIteration is never accepted as completion.
                if source.completed is not True:
                    raise
                break
            need(type(part) is bytes and len(part)<=INVERSE_LIMITS['chunk_bytes'],
                 'bounded independent byte chunk')
            end=offset+len(part)
            need(end<=len(result_raw) and part==result_raw[offset:end],
                 'every reconstructed BODY byte equals the saved ordinary result')
            offset=end
        need(source.completed is True and result_raw[offset:]==b'\n',
             'exact single external LF and completed inverse')
    finally:
        source.close()
    check();stats=prepared.statistics()
    need(stats['prepared'] is True and stats['execution_profile']==INVERSE_PROFILE and
         stats['logical_documents']==1 and stats['wire_canonical_bytes']==forest_pin['bytes'] and
         stats['aggregate_document_bytes']==len(result_raw)<=OUTPUT_CAP_BYTES,
         'whole physical/logical inverse ledger')
    document=stats['documents'][EVIDENCE_DOCUMENT]
    need(document['completed'] is True and document['closed_incomplete'] is False and
         document['attempts']==1 and document['body_bytes']==offset and
         document['copied_body_bytes']==document['emitted_body_bytes']==offset and
         document['logical_file_bytes']==offset+1 and
         document['stream_value_occurrences']==document['logical_value_occurrences'],
         'complete one-attempt document bytes/occurrences')
    check()
    return dict(schema='owned-evidence-saved-forest-verification-v1',status='COMPLETE',
        representation_only=True,mathematical_authority=False,started_ns=started,completed_ns=_NOW_NS(),
        logical_body_bytes=offset,logical_file_bytes=len(result_raw),forest=forest_pin,
        declaration=epoch['independent_evidence_inverse'],statistics=stats)


def finalize_output_ledger(actual, header, result_pin, forest_pin, check):
    """Count every root JSON artifact plus the forthcoming complete receipt.

    Source/modules/native wire inputs and streams remain separate fixed inputs
    or separately bounded logs. Receipt bytes are a fixed-point length, not a
    self-hash. Its external raw descriptor is supplied by the once runner.
    """
    check();other=[]
    for p in sorted(actual.iterdir(),key=lambda p:p.name):
        check()
        if p.suffix!='.json' or p.name in ('result.json','evidence-forest.json','worker-receipt.json'):
            continue
        need(not p.is_symlink() and p.is_file(),'ordinary root JSON metadata')
        need(p.stat().st_size<=OUTPUT_CAP_BYTES,'bounded individual metadata artifact')
        raw=p.read_bytes();check();need(len(raw)<=OUTPUT_CAP_BYTES,'bounded metadata growth')
        other.append(descriptor(p,raw))
    base=result_pin['bytes']+forest_pin['bytes']+sum(p['bytes'] for p in other)
    ledger=dict(schema='owned-evidence-physical-output-ledger-v1',cap_bytes=OUTPUT_CAP_BYTES,
        ordinary_result=result_pin,evidence_forest=forest_pin,other_root_JSON_metadata=other,
        worker_receipt_bytes=0,aggregate_physical_bytes=base,
        logical_result_bytes=result_pin['bytes'],logical_cap_bytes=OUTPUT_CAP_BYTES,
        counted_once=True,worker_receipt_descriptor='external_once_runner',
        excluded='fixed Source/module/native inputs and separately bounded stdout/stderr')
    header['owned_output_ledger']=ledger
    for attempt in range(32):
        check();size=len(canonical(header))+1;check()
        total=base+size
        if ledger['worker_receipt_bytes']==size and ledger['aggregate_physical_bytes']==total:
            need(total<=OUTPUT_CAP_BYTES and result_pin['bytes']<=OUTPUT_CAP_BYTES,
                 'aggregate physical and complete expanded logical128MiB limits')
            return
        ledger['worker_receipt_bytes']=size;ledger['aggregate_physical_bytes']=total
    raise ColdError('receipt size ledger did not stabilize')


def failure_output_prefixes(actual, check):
    """Bounded ordinary file descriptors only; never a usable partial forest."""
    out=[]
    for name in ('evidence-forest.json','result.json'):
        check();p=actual/name
        if not p.exists():
            continue
        need(not p.is_symlink() and p.is_file(),'ordinary failed output path')
        size=p.stat().st_size
        need(size<=OUTPUT_CAP_BYTES,'bounded failed output artifact')
        digest=hashlib.sha256();total=0
        with p.open('rb') as stream:
            while True:
                check();part=stream.read(65536)
                if not part:break
                total+=len(part);need(total<=OUTPUT_CAP_BYTES,'failed output growth cap');digest.update(part)
        need(total==size,'failed artifact complete EOF')
        out.append(dict(path=str(p),sha256=digest.hexdigest(),bytes=total,
                        diagnostic_only=True,complete_output_accepted=False))
    return out



def run_adapter_diagnostics(adapter, arena, tick, guard, context):
    """Finite declared checks; append only fully completed groups, no authority.

    Only invoked by the separately authorized cold main. Root callback faults
    are latched by exact identity and cannot satisfy an expected refusal.
    """
    rows=[];external_fault=None;stores=0
    def external(callback):
        nonlocal external_fault
        try:callback()
        except BaseException as error:
            external_fault=error;raise
    def checked():external(tick)
    def guarded():external(guard)
    def fresh(check=None):
        nonlocal stores
        checked();guarded();stores+=1
        need(stores<=8,'finite diagnostic Store count')
        return adapter.Store(arena_module=arena,source_epoch=canonical(context).decode('utf8'),
            semantic_epoch=canonical(ADAPTER_DIAGNOSTIC_PROFILE).decode('utf8'),
            arena_limits=dict(DIAGNOSTIC_ARENA_LIMITS),check=checked if check is None else check,
            source_guard=guarded,limits=dict(DIAGNOSTIC_ADAPTER_LIMITS))
    def body(store,reference):
        source=store.canonical(reference);out=bytearray()
        try:
            while True:
                checked()
                try:part=next(source)
                except StopIteration:
                    if source.completed is not True:raise
                    break
                need(type(part)is bytes and len(out)+len(part)<=65536,'bounded diagnostic stream')
                out.extend(part)
            need(source.completed is True,'diagnostic full stream completion')
        finally:source.close()
        return bytes(out)
    def passed(name,details):
        checked();guarded()
        rows.append(dict(schema='owned-adapter-finite-diagnostic-v1',name=name,status='passed',
                         mathematical_authority=False,details=details))
    def expected(action,sentinel):
        try:action()
        except BaseException as error:
            if external_fault is not None:raise external_fault
            if error is not sentinel:raise
            return
        raise ColdError('expected exact diagnostic exception was not raised')

    store=fresh();value={'ports':(0,False,1.0,-0.0),'unicode':'line\n雪','null':None}
    reference=store.capture(value,label='diagnostic:typed')
    expected_value={'ports':[0,False,1.0,-0.0],'unicode':'line\n雪','null':None}
    need(reference.equals(value) is True and body(store,reference)==canonical(expected_value),
         'complete tuple-to-array legacy canonical projection')
    need(reference.at('ports').at(0).kind=='int' and reference.at('ports').at(1).kind=='bool' and
         reference.at('ports').at(2).kind=='float' and reference.at('ports').at(3).kind=='float' and
         math.copysign(1.0,reference.at('ports').at(3).scalar())==-1.0 and
         reference.get('absent').kind=='missing' and reference.at('null').kind=='null',
         'bool/int/float/signed zero and missing/null remain distinct')
    value['ports']=(99,);need(body(store,reference)==canonical(expected_value),'captured caller mutation isolation')
    passed(ADAPTER_DIAGNOSTICS[0],dict(tuple_projection=True,strict_types=True,caller_mutation_isolated=True))

    store=fresh();original={'values':[1,2]};reference=store.capture(original,label='diagnostic:shared')
    assembled=store.assemble({'ordered':(reference,reference),'ordinary':(False,None)},label='diagnostic:layout')
    expected_value={'ordered':[original,original],'ordinary':[False,None]}
    need(body(store,assembled)==canonical(expected_value),'ordered repeated same-Store whole-root references')
    sealed=store.seal(assembled);wire=store.wire(sealed)
    need(wire['documents']==['diagnostic:layout'],'sole diagnostic root covers complete catalogue')
    passed(ADAPTER_DIAGNOSTICS[1],dict(repeated_ports=True,full_body=True,sealed_document='diagnostic:layout'))

    identities=[]
    for exception_type in (RuntimeError,ValueError,StopIteration):
        armed=[False];sentinel=exception_type('owned-adapter-diagnostic-exact-callback')
        def injected():
            checked()
            if armed[0]:raise sentinel
        store=fresh(injected);armed[0]=True
        expected(lambda:store.capture([1],label='diagnostic:foreign'),sentinel)
        need(store.statistics()['failed'] is True,'callback capture has no usable Store')
        identities.append(exception_type.__name__)
    armed=[False];sentinel=StopIteration('owned-adapter-diagnostic-stream-stop')
    def injected_stream():
        checked()
        if armed[0]:raise sentinel
    store=fresh(injected_stream);reference=store.capture({'value':[1,2]},label='diagnostic:stream')
    source=store.canonical(reference);armed[0]=True
    try:
        seen=False
        for attempt in range(64):
            checked()
            try:next(source)
            except BaseException as error:
                if external_fault is not None:raise external_fault
                if error is not sentinel:raise
                need(source.completed is False,'foreign StopIteration cannot finish a stream')
                seen=True;break
        need(seen,'finite expected stream callback was reached')
    finally:source.close()
    passed(ADAPTER_DIAGNOSTICS[2],dict(capture_exact_exception_types=identities,
        manual_next_foreign_StopIteration=True,stream_completed=False,
        limitation='Finite callback opportunities; no universal exception-path coverage.'))

    armed=[False];holder=[None];observed=[None]
    def reentrant():
        checked()
        if armed[0]:
            armed[0]=False
            passive=holder[0].statistics()
            need(type(passive)is dict,'passive callback statistics allowed')
            try:holder[0].capture(None,label='diagnostic:forbidden-reentry')
            except BaseException as error:
                observed[0]=error;raise
    store=fresh(reentrant);holder[0]=store;armed[0]=True
    try:store.capture([1],label='diagnostic:outer')
    except BaseException as error:
        if external_fault is not None:raise external_fault
        need(type(error)is adapter.EvidenceReentrancy and error is observed[0],
             'same own reentrancy error propagates through outer operation')
    else:raise ColdError('callback reentrancy was accepted')
    need(store.statistics()['failed'] is True,'reentrancy leaves only failure prefix')
    passed(ADAPTER_DIAGNOSTICS[3],dict(passive_statistics=True,charged_reentry_rejected=True,
                                     exact_outer_error=True,usable_output=False))

    store=fresh();reference=store.capture([1],label='diagnostic:before-failure')
    before=store.statistics()
    try:store.assemble([reference,{'completed':1},object()],label='diagnostic:bad-layout')
    except BaseException as error:
        if external_fault is not None:raise external_fault
        if type(error)is not adapter.EvidenceDataError:raise
    else:raise ColdError('non-JSON assembly element was accepted')
    after=store.statistics()
    need(after['failed'] is True and after['operations']>before['operations'] and
         after['arena']['roots']>before['arena']['roots'],
         'completed assembly prefix is retained as failed statistics only')
    try:store.seal(reference)
    except BaseException as error:
        if external_fault is not None:raise external_fault
        if type(error)is not adapter.EvidenceDataError:raise
    else:raise ColdError('failed Store exposed a complete forest')
    passed(ADAPTER_DIAGNOSTICS[4],dict(partial_roots_preserved=True,attempted_cost_monotone=True,
        failed_prefix_only=True,complete_output_accepted=False))
    need(tuple(row['name']for row in rows)==ADAPTER_DIAGNOSTICS and stores==8,
         'all and only declared diagnostic groups completed')
    checked();guarded()
    return dict(schema='owned-adapter-finite-diagnostic-result-v1',status='COMPLETE',
        mathematical_authority=False,profile=ADAPTER_DIAGNOSTIC_PROFILE,groups=rows,
        fresh_Stores=stores,scope='Finite runtime observations only, charged to this full original001 invocation.')


def main(argv):
    need(len(argv)==4,'worker_plan,began_ns,work_deadline_ns,overall_deadline_ns')
    plan_path=Path(argv[0]).resolve()
    began,work_ns,overall_ns=[int(x) for x in argv[1:]]
    need(work_ns==began+180000000000 and overall_ns==began+210000000000,
         'one absolute180/210 clock from external entry')
    need(began<=_NOW_NS()<work_ns,'fresh original cold work window')
    need(sys.platform=='darwin' and platform.machine()=='arm64' and sys.byteorder=='little',
         'declared Darwin arm64/little-endian runtime')
    need(sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode,
         'isolated -I -S -B Python')
    need(os.getpid()==os.getpgrp(),'worker must lead the owned group')
    plan_raw=plan_path.read_bytes();need(len(plan_raw)<=16777216,'finite worker plan')
    plan=json.loads(plan_raw)
    fields={'schema','invocation_id','mode','actual_directory','cold','python',
            'project_sources','components','native_inputs','policy','declaration',
            'runtime_closure','z3','receiver_id','result_reader','integration_declaration','model_storage','search_ordering','inventory_certification_mode'}
    need(type(plan) is dict and set(plan)==fields and plan['schema']==PLAN_SCHEMA,
         'exact worker plan')
    need(plan['mode'] in ('fixed','symbolic'),'declared matched mechanism-control mode')
    need(plan['receiver_id']=='prospective-fol-20261018-001','fresh known full original001 integration control only')
    need(type(plan['search_ordering']) is str and plan['search_ordering'] in ('legacy','and_support'),
         'mandatory explicit search ordering')
    need(plan['inventory_certification_mode']=='schema_then_native', 'explicit new inventory certification lane')
    need(plan['search_ordering']=='and_support','fixed shared support ordering in certification comparison')
    need(plan['result_reader']=='interned','fixed complete interned result reader')
    need(type(plan['model_storage']) is str and plan['model_storage']=='literal_interned',
         'explicit ordinary/literal_interned Model storage; no fallback')
    actual=Path(plan['actual_directory'])
    need(actual.is_absolute() and actual==actual.resolve() and actual==Path.cwd(),
         'exact existing private actual directory')
    marker=json.loads((actual/'CONSUMED.json').read_bytes())
    need(marker['invocation_id']==plan['invocation_id'] and marker['mode']==plan['mode'] and
         marker['search_ordering']==plan['search_ordering'] and
         marker['inventory_certification_mode']==plan['inventory_certification_mode'] and
         marker['began_ns']==began and marker['work_deadline_ns']==work_ns and
         marker['overall_deadline_ns']==overall_ns and marker['consumed_before_Popen'] is True,
         'exclusive external consumption and shared deadlines')
    need(Path(plan['cold']['path']).resolve()==Path(__file__).resolve(), 'exact cold entry')
    need(Path(sys.executable).resolve()==Path(plan['python']['path']), 'exact Python entry')

    stages=[];oracle_box=[];module_guards=[];source_pins=[];artifact_pins=[]
    z3_core=None;z3_native_library=None
    def overall_tick():
        need(_NOW_NS()<overall_ns,'original total closure deadline')
    def now():
        return _NOW_NS()/1000000000
    def stage(label, action):
        overall_tick();start=_NOW_NS();value=action();end=_NOW_NS()
        stages.append(dict(stage=label,started_ns=start,returned_ns=end))
        need(end<work_ns,'Root cold setup returned after original work deadline: '+label)
        return value
    def full_artifacts():
        for pin in artifact_pins:
            overall_tick();raw_file(pin)
    def source_guard():
        # This guard remains usable after the scientific deadline for cleanup.
        for pin in source_pins:
            raw_file(pin,16777216)
        for guard in module_guards:
            guard()
        if z3_core is not None:
            need(z3_native_library is not None and
                 Path(z3_native_library._name).resolve()==Path(plan['z3']['library']['path']) and
                 z3_core.Z3_mk_config.__defaults__[0].f is z3_native_library.Z3_mk_config,
                 'exact supported Z3 native-library origin')

    result_pin=None
    try:
        for pin in [plan['cold'],plan['python'],plan['policy'],plan['declaration'],plan['runtime_closure'],plan['integration_declaration']]:
            stage('intake:'+Path(pin['path']).name,lambda pin=pin:raw_file(pin))
        source_pins.append(plan['cold']);artifact_pins.extend([plan['python'],plan['policy'],
            plan['declaration'],plan['runtime_closure'],plan['integration_declaration']])
        need(hashlib.sha256(raw_file(plan['declaration'])).hexdigest()==
             '1a42c2ab16680dddbac504ca5b2d79559370785884805cf4d56b5c1c22c63dc0',
             'exact prospectively declared receiver/profile')
        integration=json.loads(raw_file(plan['integration_declaration']))
        need(integration['schema']=='ROOT-owned-evidence-integration-comparison-declaration-v1' and
             integration['parent_structural_declaration']==plan['declaration'] and
             integration['selected_receiver_id']==plan['receiver_id'], 'unchanged selected assertion/cohort')
        need(canonical(integration['evidence_profile'])==canonical(EVIDENCE_PROFILE),
             'full Source-bound arena/adapter/inverse profile and unchanged encoded/logical caps')
        binding=next((r for r in integration['schedule'] if r['invocation_id']==plan['invocation_id']),None)
        need(binding is not None and all(binding[k]==plan[k] for k in
             ('mode','search_ordering','inventory_certification_mode','result_reader','receiver_id','actual_directory','model_storage')), 'complete declared method/ordering subject binding')
        schedule=integration['schedule']
        need(len(schedule)==2 and len({r['invocation_id'] for r in schedule})==2 and
             len({r['actual_directory'] for r in schedule})==2 and
             {(r['mode'],r['inventory_certification_mode']) for r in schedule}==
                 {('fixed','schema_then_native'),('symbolic','schema_then_native')} and
             all(r['receiver_id']==plan['receiver_id'] and r['model_storage']=='literal_interned' and
                 r['result_reader']=='interned' and r['search_ordering']=='and_support' for r in schedule),
             'two complete matched methods under the explicit schema admission lane')
        declaration=json.loads(raw_file(plan['declaration']))
        receiver_selection=stage('select frozen receiver',lambda:select_receiver(declaration,plan['receiver_id']))
        parent_closure=stage('intake:parent runtime closure',
            lambda:json.loads(raw_file(PARENT_RUNTIME_CLOSURE)))
        artifact_pins.append(PARENT_RUNTIME_CLOSURE)
        closure=json.loads(raw_file(plan['runtime_closure']))
        need(closure['schema']=='ROOT-owned-evidence-integration-raw-runtime-closure-v1' and
             closure['parent_closure']==PARENT_RUNTIME_CLOSURE,
             'new full closure with explicit previous-suite lineage')
        expected_project=dict(parent_closure['project_sources'])
        expected_project['semantic_inventory_oracle']=REGISTRY_SOURCE
        expected_project['quantified_family_points_v2']=ORDINARY_MODEL_SOURCE
        expected_project['receptor_support_ordering_v1']=ORDERING_COMPONENT_SOURCES['support_ordering']
        expected_project['quantified_symbolic_control_v2']=ORDERING_COMPONENT_SOURCES['symbolic_control']
        need(expected_project['interned_quantified_family_points_v1']==COMPACT_MODEL_SOURCE,
             'unchanged compact Model full Source')
        need(plan['project_sources']==closure['project_sources']==expected_project and
             all(closure[key]==parent_closure[key] for key in
                 ('Z3','Z3_imports','external_imports','fixed_native_inputs','native_CPP','runtime',
                  'stdlib_entry_references','authoring_python')) and
             plan['python']==closure['runtime']['Python_executable'],
             'literal complete fixed project/native/Z3/runtime maps')
        need(plan['components']==closure['additional_nonseed_components'] and
             plan['components']['receiver_driver']==RECEIVER_DRIVER_SOURCE and
             plan['components']['bounded_transport']==parent_closure['additional_nonseed_components']['bounded_transport'],
             'exact new driver and unchanged bounded transport pins')
        need(closure['evidence_sources']==EVIDENCE_SOURCES,
             'exact complete extra four evidence Sources without replacement of the base map')
        need(closure['schema_sources']==SCHEMA_SOURCES and closure['schema_kernel_source']==SCHEMA_KERNEL_SOURCE,
             'whole separately reviewed schema certifier and semantic kernel Source')
        expected_z3=[{k:p[k] for k in ('path','sha256','bytes')} for p in closure['Z3']['files']]
        need(plan['z3']['files']==expected_z3 and plan['z3']['root']==closure['Z3']['package_root'],
             'complete41-file Z3 raw map and package root')
        need(plan['z3']['library']['path']==str(Path(plan['z3']['root'])/'z3/lib/libz3.dylib'),
             'fixed supported owned Z3 library')
        modules_dir=actual/'modules';modules_dir.mkdir(mode=0o700)
        need(set(plan['components'])=={'receiver_driver','bounded_transport'},'two exact components')
        names={**plan['project_sources'],
               'semantic_receiver_driver':plan['components']['receiver_driver'],
               'bounded_request_oracle':plan['components']['bounded_transport'],
               **{EVIDENCE_ALIASES[role]:pin for role,pin in EVIDENCE_SOURCES.items()}}
        need(len(plan['project_sources'])==22 and len(names)==28 and
             closure['materialized_aliases']==names, 'complete same28 base project/component/evidence aliases in both arms')
        owned={}
        for name,pin in names.items():
            need(name.isidentifier() and name not in sys.modules,'fresh explicit project module')
            raw=stage('copy:'+name,lambda pin=pin:raw_file(pin,16777216))
            dest=modules_dir/(name+'.py');dest.write_bytes(raw)
            owned[name]=descriptor(dest,raw);source_pins.extend([pin,owned[name]])
        owned_schema={}
        for name,pin in SCHEMA_SOURCES.items():
            need(name.isidentifier() and name not in names and name not in sys.modules,'fresh separately scoped schema module')
            raw=stage('copy schema:'+name,lambda pin=pin:raw_file(pin,16777216))
            dest=modules_dir/(name+'.py');dest.write_bytes(raw)
            owned_schema[name]=descriptor(dest,raw);source_pins.extend([pin,owned_schema[name]])
        stage('kernel semantic raw Source',lambda:raw_file(SCHEMA_KERNEL_SOURCE))
        source_pins.append(SCHEMA_KERNEL_SOURCE)
        need(Path(plan['z3']['root']).is_absolute(),'owned Z3 package root')
        for pin in plan['z3']['files']:
            stage('Z3 intake:'+Path(pin['path']).name,lambda pin=pin:raw_file(pin))
            artifact_pins.append(pin)
        need(plan['z3']['library'] in plan['z3']['files'],'loaded Z3 library in complete package pins')
        builtins.Z3_LIB_DIRS=[str(Path(plan['z3']['library']['path']).parent)]
        sys.path[:0]=[str(modules_dir),plan['z3']['root']]
        loaded={name:stage('import:'+name,lambda name=name:importlib.import_module(name)) for name in names}
        for name,module in loaded.items():
            need(Path(module.__file__).resolve()==Path(owned[name]['path']),'exact project import origin')
        # The same pinned Z3 runtime is loaded and charged in every arm.
        # The pinned z3core Source deletes its temporary _lib global at EOF.
        # Capture the actual loader result during import, then restore stdlib.
        original_cdll=ctypes.CDLL;loaded_libraries=[]
        def observed_cdll(name,*args,**kwargs):
            library=original_cdll(name,*args,**kwargs)
            loaded_libraries.append(library)
            return library
        ctypes.CDLL=observed_cdll
        try:
            z3=stage('import:Z3',lambda:importlib.import_module('z3'))
        finally:
            ctypes.CDLL=original_cdll
        need(ctypes.CDLL is original_cdll and len(loaded_libraries)==1,
             'exact one observed Z3 native-library load and restored loader')
        z3_core=sys.modules['z3.z3core']
        z3_native_library=loaded_libraries[0]
        z3_modules=[]
        for name,module in list(sys.modules.items()):
            if name=='z3' or name.startswith('z3.'):
                file=Path(module.__file__).resolve()
                match=next((p for p in plan['z3']['files'] if Path(p['path'])==file),None)
                need(match is not None,'exact Z3 Python import origin');source_pins.append(match)
                z3_modules.append(module)
        need(Path(z3_native_library._name).resolve()==Path(plan['z3']['library']['path']) and
             z3_core.Z3_mk_config.__defaults__[0].f is z3_native_library.Z3_mk_config,
             'owned exact Z3 dynamic library')
        # Seal protected base28/Z3/cold callables BEFORE the separate schema import.
        # Keep this original guard; never rebaseline the protected objects.
        module_guards.append(seal_callables(list(loaded.values())+z3_modules+[sys.modules[__name__]]))
        source_guard()
        schema_loaded={}
        for name in SCHEMA_SOURCES:
            module=stage('import schema:'+name,lambda name=name:importlib.import_module(name))
            need(Path(module.__file__).resolve()==Path(owned_schema[name]['path']),'exact schema import origin')
            source_guard()
            module_guards.append(seal_callables([module]))
            schema_loaded[name]=module;source_guard()
        need(len(loaded)==28 and len(schema_loaded)==1,'full current base28 plus exactly1 schema import')
        native=plan['native_inputs']
        need(set(native)=={'program_and_template','opaque_microcode_gzip','native_cpp'},'fixed native inputs')
        need(native['program_and_template']==closure['fixed_native_inputs']['program_and_template'] and
             native['opaque_microcode_gzip']==closure['fixed_native_inputs']['opaque_microcode_gzip'] and
             native['native_cpp']==closure['native_CPP']['binary'],'literal native raw input maps')
        for pin in native.values():
            stage('native intake:'+Path(pin['path']).name,lambda pin=pin:raw_file(pin))
            artifact_pins.append(pin)
        old=stage('decode native template',lambda:json.loads(raw_file(native['program_and_template'])))
        micro=stage('decode fixed microcode',lambda:json.loads(gzip.decompress(raw_file(native['opaque_microcode_gzip']))))
        need(hashlib.sha256(canonical(micro)).hexdigest()==MICRO_SHA and
             hashlib.sha256(canonical(old['program'])).hexdigest()==PROGRAM_SHA and
             old['program_sha256']==PROGRAM_SHA and micro['program_sha256']==PROGRAM_SHA and
             old['machine']['micro_sha256']==MICRO_SHA and len(micro['rows'])==old['machine']['micro_states'],
             'unchanged canonical microcode/program/row identities')
        native_dir=actual/'native';native_dir.mkdir(mode=0o700);code=native_dir/'code.bin'
        stage('encode fixed native table',lambda:loaded['tape_binary'].write_micro(micro,code))
        code_pin=descriptor(code);artifact_pins.append(code_pin)
        source_pins.append(native['native_cpp'])
        epoch=dict(schema=EPOCH_SCHEMA,model_storage=plan['model_storage'],search_ordering=plan['search_ordering'],
                   inventory_certification_mode=plan['inventory_certification_mode'],
                   sources=dict(project=owned,original=names,cold=plan['cold']),
                   schema_sources=dict(original=SCHEMA_SOURCES,owned=owned_schema,kernel_source=SCHEMA_KERNEL_SOURCE),
                   native_inputs=dict(**native,code_bin=code_pin),
                   python=plan['python'],z3=plan['z3'],declaration=plan['declaration'],policy=plan['policy'],
                   receiver_selection=receiver_selection,
                   result_representation=dict(reader=plan['result_reader'],integration_declaration=plan['integration_declaration']),
                   custody='Exact raw project/component origins and captured callable identities; pinned Python/bundled stdlib and platform loader are trusted runtime. Z3 native origin/raw bytes gated separately. No whole OS formal validation claimed.')
        evidence_owned={role:owned[alias] for role,alias in EVIDENCE_ALIASES.items()}
        epoch['evidence_storage']=dict(schema='owned-evidence-storage-declaration-v1',
            sources={role:evidence_owned[role] for role in ('adapter','arena','join')},
            arena_limits=dict(ARENA_LIMITS),adapter_limits=dict(ADAPTER_LIMITS),
            logical_output='complete-legacy-JSON-body-plus-LF',
            unfinished_storage='NO_COMPLETE_RESULT_NO_PROOF_OR_RESOURCE_ADMISSION')
        epoch['independent_evidence_inverse']=dict(schema='owned-evidence-independent-inverse-declaration-v1',
            original=EVIDENCE_SOURCES['inverse'],owned=evidence_owned['inverse'],
            version=INVERSE_VERSION,execution_profile=INVERSE_PROFILE,limits=dict(INVERSE_LIMITS),
            sole_document=EVIDENCE_DOCUMENT,stream='BODY-only-plus-one-external-LF',
            authority='representation-only; no Native or mathematical acceptance')
        adapter_diagnostics=stage('owned-adapter-boundary-diagnostics',lambda:run_adapter_diagnostics(
            loaded[EVIDENCE_ALIASES['adapter']],loaded[EVIDENCE_ALIASES['arena']],
            lambda:need(_NOW_NS()<work_ns,'adapter diagnostics inside original work'),source_guard,
            dict(schema='owned-adapter-diagnostic-source-context-v1',invocation_id=plan['invocation_id'],
                 evidence_sources=evidence_owned,cold=plan['cold'])))
        factory_module=loaded['bounded_request_oracle'];registry=loaded['semantic_inventory_oracle']
        def oracle_factory(*,work_deadline,tick,source_guard,now):
            need(work_deadline==work_ns/1000000000,'factory original work deadline')
            cls=factory_module.make_request_oracle_factory(request_oracle_module=registry,
                deadline=work_deadline,tick=tick,source_guard=source_guard,now=now)
            # Seal all dynamic methods before the constructor or later queries.
            module_guards.append(seal_callables([],classes=[cls]))
            oracle=cls(micro,old['cases'][0]['initial'],native['native_cpp']['path'],code,native_dir)
            oracle_box.append(oracle)
            return oracle
        roles={role:loaded[name] for role,name in ROLE_MODULES.items()}
        roles['family_model']=loaded[MODEL_STORAGE_MODULES[plan['model_storage']]]
        roles['schema_certificate']=schema_loaded['mp_schema_certificate']
        overall_tick();need(_NOW_NS()<work_ns,'receiver starts in original work window')
        receipt=loaded['semantic_receiver_driver'].run_receiver_owned(receiver_spec=receiver_selection['spec'],mode=plan['mode'],search_ordering=plan['search_ordering'],
            inventory_certification_mode=plan['inventory_certification_mode'],
            policy_bytes=raw_file(plan['policy']),modules=roles,oracle_factory=oracle_factory,
            source_epoch=epoch,source_guard=source_guard,tick=overall_tick,now=now,
            work_deadline=work_ns/1000000000,closure_deadline=overall_ns/1000000000,
            closure_tick=overall_tick,output_path=actual/'result.json',
            evidence_module=loaded[EVIDENCE_ALIASES['adapter']],arena_module=loaded[EVIDENCE_ALIASES['arena']],
            owned_join_module=loaded[EVIDENCE_ALIASES['join']])
        returned=_NOW_NS();source_guard();full_artifacts();checked=_NOW_NS()
        need(receipt['receiver_id']==plan['receiver_id'] and receipt['search_ordering']==plan['search_ordering'],
             'returned exact receiver and ordering identity')
        need(len(oracle_box)==1,'one persistent native instance')
        transport=oracle_box[0].transport_receipt()
        need(transport['closed'] is True and transport['all_reaped'] is True and
             transport['native_exit_code']==0,'native exactly closed and reaped')
        result_pin={k:receipt['output'][k] for k in ('path','sha256','bytes')}
        need(receipt['version']=='semantic-family-owned-evidence-driver-v1' and
             receipt['independent_saved_forest_inverse_required'] is True and
             receipt['ROOT_resource_accepted'] is False, 'no worker receipt is resource authority')
        need(result_pin['path']==str(actual/'result.json'),'fresh exact full ordinary output path')
        forest_pin={k:receipt['evidence_forest'][k] for k in ('path','sha256','bytes')}
        need(forest_pin['path']==str(actual/'evidence-forest.json'),'fresh exact forest sidecar path')
        result_raw=raw_file(result_pin)
        reading_started=_NOW_NS();positive=receipt['native_proof_accepted'] or receipt['family_hint_success'] or receipt['schema_inventory_admitted']
        def reader_tick():
            overall_tick()
            if positive:
                need(_NOW_NS()<work_ns,'positive full result reading within original work')
        # Owned completion and both full representation checks are scientific
        # work even when the final search status is an ordinary UNKNOWN.
        def evidence_tick():
            overall_tick();need(_NOW_NS()<work_ns,'full saved evidence inverse within original work')
        evidence_tick();source_guard()
        forest_raw=raw_file(forest_pin)
        forest_wire=json.loads(forest_raw)
        evidence_tick()
        evidence_verification=verify_saved_evidence(loaded[EVIDENCE_ALIASES['inverse']],forest_wire,
            forest_pin,result_raw,epoch,evidence_tick)
        del forest_wire,forest_raw
        evidence_tick();source_guard()
        reader_tick();sharing=None
        if plan['result_reader']=='builtin':
            result_data=json.loads(result_raw)
        else:
            result_data,sharing=loaded['interned_result_reader_v2'].decode_result(result_raw,checkpoint=reader_tick)
        decoded_ns=_NOW_NS()
        literal=verify_literal_result(result_data,result_raw,reader_tick)
        reading_completed=_NOW_NS();source_guard()
        result_reading=dict(reader=plan['result_reader'],source=owned['interned_result_reader_v2'],
            started_ns=reading_started,decoded_ns=decoded_ns,completed_ns=reading_completed,
            decode_seconds=(decoded_ns-reading_started)/1e9,roundtrip=literal,sharing=sharing,
            scope='Complete result reading and literal reconstruction in original scientific worker with all old native/template/model lifetimes unchanged. Parent parser unchanged.')
        need(result_data['receiver_id']==plan['receiver_id'] and
             canonical(result_data['declaration'])==canonical(receiver_selection['spec']) and
             canonical(result_data['source_epoch']['receiver_selection'])==canonical(receiver_selection) and
             result_data['source_epoch']['schema']==EPOCH_SCHEMA and
             result_data['search_ordering']==plan['search_ordering'] and
             result_data['source_epoch']['search_ordering']==plan['search_ordering'] and
             result_data['inventory_certification_mode']==plan['inventory_certification_mode'] and
             result_data['source_epoch']['inventory_certification_mode']==plan['inventory_certification_mode'] and
             result_data['module_pins']['support_ordering']==owned[ROLE_MODULES['support_ordering']] and
             result_data['module_pins']['family_search' if plan['mode']=='fixed' else 'symbolic_control']==
                 owned[ROLE_MODULES['family_search' if plan['mode']=='fixed' else 'symbolic_control']] and
             result_data['source_epoch']['model_storage']==plan['model_storage'] and
             result_data['module_pins']['family_model']==owned[MODEL_STORAGE_MODULES[plan['model_storage']]],
             'whole output/current receiver and selected Model storage preimages')
        need(canonical(result_data['source_epoch'])==canonical(epoch),
             'complete evidence and scientific Source epoch preimage')
        region_check=(verify_raw_region(result_data,work_ns) if receipt['native_proof_accepted']
                      else dict(status='NOT_CHECKED_NO_NATIVE_PROOF'))
        source_guard()
        # New explicit registry permission never substitutes for final Native.
        need(canonical(result_data['records'])==canonical(oracle_box[0].records),
             'complete current Native ledger after driver closure')
        register=result_data['outputs'].get('register',{})
        cert=register.get('certification',{}) if type(register)is dict else {}
        complete_schema=(result_data['work_window_complete'] is True and
            register.get('status')=='schema_admitted' and cert.get('complete')is True and
            cert.get('Model_permission')is True)
        need(type(receipt['schema_inventory_admitted'])is bool and
             receipt['schema_inventory_admitted']is complete_schema,
             'current whole registry permission and driver work-window receipt')
        schema_observation=dict(mode='schema_then_native',
            inventory_status=register.get('status','NOT_REACHED'),
            complete_schema_inventory_admitted=complete_schema,
            registry_Model_permission=cert.get('Model_permission',False),
            native_accepted_by_schema=False,final_whole_Native_required=True,
            sources=dict(original=SCHEMA_SOURCES,owned=owned_schema),
            kernel_source=SCHEMA_KERNEL_SOURCE)
        source_guard()
        positive=receipt['native_proof_accepted'] or receipt['family_hint_success'] or receipt['schema_inventory_admitted']
        if positive:
            need(checked<work_ns and _NOW_NS()<work_ns,'positive result and full Root checks within work')
        else:
            overall_tick()
        origins=[]
        for name,module in sorted(sys.modules.items()):
            file=getattr(module,'__file__',None)
            if file:
                origins.append(dict(module=name,path=str(Path(file).resolve())))
        header=dict(schema=WORKER_SCHEMA,invocation_id=plan['invocation_id'],mode=plan['mode'],search_ordering=plan['search_ordering'],
            inventory_certification_mode=plan['inventory_certification_mode'],
            receiver_id=plan['receiver_id'],receiver_input_qualified=receipt['receiver_input_qualified'],
            receiver_selection_sha256=hashlib.sha256(canonical(receiver_selection)).hexdigest(),
            status=receipt['status'],result=result_pin,
            work_completed=checked<work_ns and receipt['status']!='unknown_receiver_work_deadline',
            logical_proof_accepted=receipt['native_proof_accepted'],
            schema_inventory_admitted=receipt['schema_inventory_admitted'],
            primary_family_hint_accepted=receipt['family_hint_success'],
            quantified_reasoning_success=receipt['quantified_reasoning_success'],native_transport=transport,
            worker_plan=descriptor(plan_path,plan_raw),cold=plan['cold'],python=plan['python'],
            began_ns=began,work_deadline_ns=work_ns,overall_deadline_ns=overall_ns,
            driver_returned_ns=returned,custody_checked_ns=checked,cold_stages=stages,
            schema_admission=schema_observation,
            source_epoch_sha256=hashlib.sha256(canonical(epoch)).hexdigest(),
            final_region_verification=region_check,result_reading=result_reading,
            evidence_forest=forest_pin,evidence_statistics=receipt['evidence_statistics'],
            evidence_verification=evidence_verification,evidence_profile=EVIDENCE_PROFILE,
            adapter_diagnostics=adapter_diagnostics,
            integration_declaration=plan['integration_declaration'],
            model_storage=plan['model_storage'],
            selected_search_module=dict(role=('family_search' if plan['mode']=='fixed' else 'symbolic_control'),
                module=ROLE_MODULES['family_search' if plan['mode']=='fixed' else 'symbolic_control'],
                original=ORDERING_COMPONENT_SOURCES['family_search' if plan['mode']=='fixed' else 'symbolic_control'],
                owned=owned[ROLE_MODULES['family_search' if plan['mode']=='fixed' else 'symbolic_control']]),
            support_ordering_module=dict(module=ROLE_MODULES['support_ordering'],
                original=ORDERING_COMPONENT_SOURCES['support_ordering'],owned=owned[ROLE_MODULES['support_ordering']]),
            selected_family_model=dict(module=MODEL_STORAGE_MODULES[plan['model_storage']],
                original=plan['project_sources'][MODEL_STORAGE_MODULES[plan['model_storage']]],
                owned=owned[MODEL_STORAGE_MODULES[plan['model_storage']]]),
            import_origins=origins,driver_output_receipt=receipt,
            scope='Root adapter headers are not resource or mathematical admission; outer exact terminal/resource gates remain required.')
        finalize_output_ledger(actual,header,result_pin,forest_pin,evidence_tick)
        evidence_tick();source_guard();full_artifacts();evidence_tick()
        write_new(actual/'worker-receipt.json',header)
        need((actual/'worker-receipt.json').stat().st_size==header['owned_output_ledger']['worker_receipt_bytes'],
             'exact serialized worker receipt physical length')
        evidence_tick()
        overall_tick()
        if positive:
            need(_NOW_NS()<work_ns,'worker positive header serialization within work')
    except BaseException as error:
        transport=getattr(error,'native_transport_receipt',None)
        if transport is None:
            transport=getattr(error,'transport_receipt',None)
        cleanup_errors=[]
        for oracle in oracle_box:
            try:
                oracle.close();transport=oracle.transport_receipt()
            except BaseException as cleanup:
                cleanup_errors.append(dict(type=type(cleanup).__name__,message=str(cleanup)))
                transport=getattr(cleanup,'transport_receipt',transport)
        # No late rewrite, partial Model permission or accepted forest fallback.
        # Metadata failures cannot replace the original exception object.
        try:
            prefixes=failure_output_prefixes(actual,overall_tick)
            failure=dict(schema='ROOT-owned-evidence-worker-failure-v1',
                error_type=type(error).__name__,message=str(error)[:4096],cleanup_errors=cleanup_errors,
                native_transport=transport,result_already_published=result_pin,
                owned_evidence_statistics=getattr(error,'owned_evidence_statistics',None),
                diagnostic_output_prefixes=prefixes,stage_intervals=stages,
                complete_output_accepted=False,scientific_acceptance=False,
                logical_proof_accepted=False,resource_accepted=False,retry_authorized=False)
            need(len(canonical(failure))+1<=1048576,'bounded ordinary failure metadata')
            overall_tick();write_new(actual/'worker-failure.json',failure)
        except BaseException as metadata_error:
            if hasattr(error,'add_note'):
                error.add_note('bounded failure metadata unavailable: '+type(metadata_error).__name__)
        raise


if __name__=='__main__':
    main(sys.argv[1:])
