"""Ordinary raw-document metadata only; no scientific component imports."""
from pathlib import Path
import hashlib
import json
import re

L=Path(__file__).parent
R=Path('/private/tmp/gcts-cadence-integration-ROOT-20261019')
N=R/'basic-tiling-algorithm-HEAD.md'
O=Path('/private/tmp/gcts-owned-evidence-integration-ROOT-20261019/basic-tiling-algorithm.md')
S=L/'owned_evidence_cold_v4.py';P=L/'EVIDENCE_PROFILE-v4.json'
def pin(p):
    b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
assert pin(N)==dict(path=str(N),sha256='ca6ee206287bf18b69f88a35d30968312499567755f347a819af4cf49743e7d4',bytes=36240)
assert pin(O)['sha256']=='c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9'
assert pin(S)['sha256']=='02a0e8f708b0c4928630b8eb7a7956ad9cde9341e658fd0b1528c3159b267377'
assert pin(P)['sha256']=='3a78d1d75a77f9d1aec11f531b9b2e88bfe920901aabdf691270cfbe2a906ee8'
old=O.read_text();new=N.read_text()
def sections(text):
    starts=list(re.finditer(r'^## ([0-9]+)\..*$',text,re.M));out={}
    for i,m in enumerate(starts):out[m.group(1)]=text[m.start():starts[i+1].start()if i+1<len(starts)else len(text)]
    return out
os=sections(old);ns=sections(new);unchanged=[]
for key in ('1','2','3','4','5','7','8'):
    assert os[key]==ns[key]
    unchanged.append(dict(section=key,raw_equal=True,current_line=new[:new.index(ns[key])].count('\n')+1,
                          bytes=len(ns[key].encode())))
marker='For each current or future subproject, record:'
assert old[old.index(marker):]==new[new.index(marker):]
headings=[dict(heading=line,line=i)for i,line in enumerate(new.splitlines(),1)if line.startswith(('## ','### '))]
value=dict(schema='cadence-cold-current-master-applicability-addendum-v1',author_identity='/root/conventional_library',
    source=pin(S),source_contract=pin(L/'Source-contract-v1.json'),prior_handoff=pin(L/'handoff-v1.json'),evidence_profile=pin(P),
    current_master=pin(N),current_master_read_in_full=True,
    current_master_origin='Root-fetched publisher HEADfa2c, as stated by Root; raw file identity verified locally.',
    historical_master=pin(O),master_diff=pin(R/'master-frozen-to-HEAD.patch'),
    status='CURRENT_MASTER_RECONCILED_NO_COLD_SOURCE_CHANGE_REQUIRED_WITHIN_DECLARED_SCOPE',
    source_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,
    unchanged_master_sections=unchanged,final_conformance_tail_raw_equal=True,current_headings=headings,
    new_or_revised_provisions=[
      dict(scope='Section6 marking-learning clarifications',
           summary='Distinguishes direct pair conflicts from operational frontier rejection, rebuilds positive equalities after free-support changes, makes witnesses/marking decisions and active rollback-aware marking sections inspectable, and authenticates explicit saved-library reuse and continuation costs.',
           applicability='No learner, provisional marking, catalogue labels, marking support, saved learned marking or training-continuation body is created or modified by coldV4. These are not new exemptions for inherited search.'),
      dict(scope='Sections6.1/6.2 corona consensus and alternating learned restrictions',
           summary='Requires complete enumeration, missing-value consensus semantics, separate marked/unmarked scope, independent alternatives, full frontier checks and total acquisition/reuse costs.',
           applicability='ColdV4 performs no corona enumeration, consensus, support reduction or marking extension. Its exact evidence forest is not a learned marking or pruning certificate.'),
      dict(scope='Section6.3 online marking probes',
           summary='Marked failures cannot establish unmarked negatives; labels and witness alternatives remain scoped, known controls diagnose representability without becoming targets, and complete cold acquisition/synthesis/fallback costs must be counted.',
           applicability='No online learner, probe, synthesis or known-marking training target exists in this cold binding change. All current output, conversion, inverse, old verification and Source/custody costs remain inside the declared whole invocation.'),
      dict(scope='Section6a certified negative-only lane',
           summary='Every activated disagreement needs a proved excluded configuration across transforms, reversals and mark-only contacts. Unknowns remain unrestricted, and finite patches remain distinct from infinite exact tilings.',
           applicability='No exclusion marking or new rejection/pruning authority is added. Schema certificates and representation handles remain distinct from Native whole-proof authority; frontier domains and base fallback are unchanged.'),
      dict(scope='Section9 implementation audit updates',
           summary='Updates separately labeled growth, fixed-window, SAT, voxel and periodic controls and their finite/solver/proof scopes.',
           applicability='These findings do not certify this theorem-search adaptation. Inherited complete finite point verification and Native proof gates remain required; symbolic chronology is a separately labeled specialized control.')],
    conformance_scope=[
      'Sections1-5/7/8 and the final requirements are raw-identical. Exact point values, missing versus zero, complete incidence, global dead/forced/earliest-generation decisions, exact rollback, primitive fallback, inspectable clusters and full-cost comparisons remain mandatory.',
      'ColdV4 changes only its version and inverse Source/version/execution-profile bindings. All fifteen function/class bodies, actual input, Model/inventory/Native rules, five adapter groups/eight Stores and numeric caps remain raw/AST identical to its parent.',
      'No universal GCTS conformance, new RL training, search gain, finite/infinite tiling theorem or runtime fit follows from constant-binding equivalence or this reconciliation.',
      'Original contracts identify the historical master actually read. This addendum applies the current master without rewriting historical evidence.'],
    ancestry='Author of coldV4/parent cold, arena/registry and older Model/point work. This is an author applicability addendum, not independent self-Source certification. Control distinct review remains separate.',
    preservation=dict(Source_unchanged=True,profile_unchanged=True,old_contracts_unchanged=True,old_actuals_unchanged=True,publication_unchanged=True),
    metadata_preflight='The initially supplied diff filename was absent; narrow ordinary file inventory found master-frozen-to-HEAD.patch. No Source or frozen object was changed.',
    pending='Distinct current-master-aware Source review, Root exact closure/declaration/outer/plans/grants and later Root-only actual. None authorized here.')
p=L/'current-master-applicability-addendum-v1.json';assert not p.exists()
p.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n');add=pin(p)
h=L/'current-master-addendum-handoff-v1.json';assert not h.exists()
h.write_text(json.dumps(dict(schema='cadence-cold-current-master-addendum-handoff-v1',addendum=add,
    current_master=pin(N),source=pin(S),evidence_profile=pin(P),source_only=True,scientific_calls=0,
    actual_execution_authorized=False,prior_frozen_objects_mutated=False),indent=2)+'\n')
print(json.dumps(dict(addendum=add,handoff=pin(h),unchanged_sections=[r['section']for r in unchanged])))
