from pathlib import Path
import json,hashlib
D=Path('/private/tmp/gcts-cadence-integration-ROOT-20261019'); C=Path('/private/tmp/gcts-cadence-integration-peer-20261019')
def rd(p):return json.loads(Path(p).read_bytes())
def ds(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def can(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
checks=[]
def ck(n,v):checks.append(dict(check=n,passed=bool(v)))
def contains(v,w):
 if type(v)is dict:return v==w or any(contains(x,w)for x in v.values())
 if type(v)is list:return any(contains(x,w)for x in v)
 return False
adopt=rd(D/'ROOT-scope-adoption-and-grants-v1.json');manifest=rd(D/'false-plan-manifest-v1.json');pros=rd(C/'typed-prospective-plan-review-v1.json');comp=rd(C/'typed-components-Source-review-v1.json');once=rd(C/'typed-once-Source-review-v1.json')
ck('offered Root adoption whole pin',ds(D/'ROOT-scope-adoption-and-grants-v1.json')==dict(path=str(D/'ROOT-scope-adoption-and-grants-v1.json'),sha256='9a8a42ac66a72cee166119b0a7a27980023b4395997fe00d50727c41dbacf525',bytes=2588))
ck('original false review and index current',ds(pros['prospective_manifest']['path'])==pros['prospective_manifest'] and pros['prospective_review_passed']is True)
expected_roles={'current_components_Source':('owned-evidence-integration-components-typed-Source-review-v1','source_review_passed',C/'typed-components-Source-review-v1.json'),'once_Source':('owned-evidence-integration-once-typed-Source-review-v1','source_review_passed',C/'typed-once-Source-review-v1.json'),'prospective_plans':('owned-evidence-integration-prospective-plan-review-v1','prospective_review_passed',C/'typed-prospective-plan-review-v1.json')}
for role,(schema,pflag,p) in expected_roles.items():
 r=rd(p);ck('exact current role receipt '+role,adopt['review_roles'][role]==ds(p));ck('role exact ABI and scope flags '+role,r['schema']==schema and r[pflag]is True and r['source_only']is True and type(r['scientific_calls'])is int and r['scientific_calls']==0 and r['scientific_acceptance']is False and r['actual_execution_authorized']is False and r['reviewer_identity']=='/root/conventional_control_review' and r['author_identity']=='/root')
ck('exactly two declared modes/serial order',[r['mode']for r in adopt['plans']]==[r['mode']for r in pros['subjects']]==['fixed','symbolic'])
ck('same reviewer across three scopes explicitly disclosed',len({rd(p)['reviewer_identity']for _,_,p in expected_roles.values()})==1 and adopt['inherited_author_overlap_disclosed']is True)
pins={}
def pin(d):pins[d['path']]=d
for d in comp['required_current_subjects']+list(once['sources'].values()):pin(d)
for k in ['declaration','runtime_closure']:pin(pros[k])
results=[]
for row,pr in zip(adopt['plans'],pros['subjects']):
 mode=row['mode'];f=rd(pr['false_once_plan']['path']);p=rd(row['once_plan']['path']);a=rd(row['authorization']['path']);s={k:v for k,v in p.items()if k!='authorization'};sha=hashlib.sha256(can(s)).hexdigest()
 ck('whole true once '+mode,ds(row['once_plan']['path'])==row['once_plan']);ck('whole current true grant '+mode,ds(row['authorization']['path'])==row['authorization']);ck('whole reviewed false once '+mode,ds(pr['false_once_plan']['path'])==pr['false_once_plan'])
 ck('authorization descriptor only plan delta '+mode,set(p)==set(f) and [k for k in p if p[k]!=f[k]]==['authorization'] and p['authorization']==row['authorization'])
 ck('full eighteen-field subject literal and hash '+mode,len(s)==18 and s==pr['subject'] and sha==pr['subject_sha256']==row['subject_sha256']==a['subject_sha256'])
 ck('false sentinel to true maximum one '+mode,f['authorization']==dict(path='NO_AUTHORIZATION_FALSE_PLAN',sha256='NO_AUTHORIZATION',bytes=0) and a['actual_execution_authorized']is True and type(a['maximum_actual_invocations'])is int and a['maximum_actual_invocations']==1 and a['author_identity']=='/root')
 ck('exact original authorization seven fields '+mode,set(a)=={'schema','subject_sha256','actual_execution_authorized','maximum_actual_invocations','author_identity','review_roles','scope'} and a['schema']=='ROOT-owned-evidence-integration-once-authorization-v1')
 ck('exact three current role names '+mode,set(a['review_roles'])==set(expected_roles))
 for role,(schema,pflag,rp) in expected_roles.items():
  rr=a['review_roles'][role];r=rd(rp)
  expected=comp['required_current_subjects'] if role=='current_components_Source' else list(once['sources'].values()) if role=='once_Source' else [pros['declaration'],pros['runtime_closure'],pr['worker_plan']]
  ck('exact receipt/reviewer/required full scope '+mode+'/'+role,set(rr)=={'receipt','reviewer_identity','required_subjects'} and rr['receipt']==ds(rp)==adopt['review_roles'][role] and rr['reviewer_identity']==r['reviewer_identity'] and rr['required_subjects']==expected)
  ck('full required descriptors contained in receipt '+mode+'/'+role,all(contains(r,d)for d in expected))
 ck('scope retains same qualified profile and no rescue '+mode,all(x in a['scope']for x in ['QualifiedV7profileonly','worker180/outer210 unchanged','No causal speed claim','no unchanged retry','failed arm grants no rescue']))
 act=Path(p['actual_directory']);op=Path(row['once_plan']['path']);obs=op.parent/(op.stem+'-terminal-observation')
 ck('fresh actual and once consumed marker absent '+mode,not act.exists() and not(act/'CONSUMED.json').exists());ck('fresh terminal observer and marker absent '+mode,not obs.exists() and not(obs/'CONSUMED.json').exists())
 ck('same worker/declaration/closure/runtime/limits profile '+mode,all(p[k]==f[k] for k in ['worker_plan','integration_declaration','runtime_closure','python','cold','runner','observer','limits','mode','search_ordering','inventory_certification_mode','model_storage','result_reader','receiver_id','environment']))
 pin(pr['worker_plan']);pin(pr['false_once_plan']);pin(row['once_plan']);pin(row['authorization'])
 results.append(dict(mode=mode,subject=s,subject_sha256=sha,false_once_plan=pr['false_once_plan'],once_plan=row['once_plan'],authorization=row['authorization'],observer_directory=str(obs),actual_directory=str(act)))
for d in pins.values():ck('current unchanged raw subject/pin '+d['path'],ds(d['path'])==d)
explicit=rd(D/'ROOT-explicit-scope-adoption-v1.json');ck('Root explicitly adopted exact current master and corrected clocks',explicit['current_master']==comp['current_master'] and 'knownexit'in explicit['clock_scope'] and '210s'in explicit['clock_scope'] and explicit['scientific_acceptance']is False)
failures=[x for x in checks if not x['passed']];audit=dict(schema='cadence-integration-final-grant-delta-audit-v1',source_only=True,scientific_calls=0,component_calls=0,fixture_calls=0,module_evaluations=0,actual_execution_authorized=False,check_count=len(checks),mismatch_count=len(failures),checks=checks,findings=failures,unique_raw_pin_count=len(pins),subjects=results)
p=C/'final-grant-delta-audit-v1.json';assert not p.exists();p.write_text(json.dumps(audit,sort_keys=True,indent=2)+'\n')
r=dict(schema='owned-evidence-integration-final-grant-delta-review-v1',author_identity='/root',reviewer_identity='/root/conventional_control_review',source_only=True,saved_metadata_only=True,scientific_calls=0,component_calls=0,fixture_calls=0,module_evaluations=0,scientific_acceptance=False,actual_execution_authorized=False,final_grant_delta_review_passed=not failures,check_count=len(checks),mismatch_count=len(failures),findings=failures,audit=ds(p),Root_grant_adoption=ds(D/'ROOT-scope-adoption-and-grants-v1.json'),Root_explicit_scope_adoption=ds(D/'ROOT-explicit-scope-adoption-v1.json'),prospective_review=ds(C/'typed-prospective-plan-review-v1.json'),current_Source_reviews={k:ds(v[2])for k,v in expected_roles.items()if k!='prospective_plans'},subjects=results,unique_raw_pin_count=len(pins),current_master=comp['current_master'],authorship_and_role_disclosure=comp['authorship_disclosure'],scope='Narrow auth-only metadata delta, exact three current role scopes, full subject/raw-pin joins and freshness only. No Source re-certification or scientific/actual/Native/proof/resource acceptance.',limitations=['Both full eighteen-field subjects remain literally unchanged; only the false authorization sentinel is replaced by the exact new Root true/max-one grant descriptor.','One disclosed reviewer fills three current scope roles. Whole required descriptors and role flags are checked here; Root authorizes execution and retains responsibility for external scope adoption, raw preflight and full saved outcome admission.','Worker positive work/result reading and known exit before180 seconds; later outer checks/terminal before210 seconds. All real and private caps are unchanged.','No actual or observer directory existed at this review closure. No consumed slot is reused. A new failure permits no restart, rescue, trim or cap relaxation.','Control tools stop immediately after handoff and remain idle throughout both serial measured windows until Root confirms terminal cohort closure.'],tools_stopped_after_handoff=True)
q=C/'typed-final-grant-delta-review-v1.json';assert not q.exists();q.write_text(json.dumps(r,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(receipt=ds(q),audit=ds(p),check_count=len(checks),mismatch_count=len(failures),raw_pins=len(pins),findings=failures),indent=2))
