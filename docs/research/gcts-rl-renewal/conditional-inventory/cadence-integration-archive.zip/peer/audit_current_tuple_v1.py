from pathlib import Path
import ast,json,hashlib,re,copy
C=Path('/private/tmp/gcts-cadence-integration-peer-20261019');D=Path('/private/tmp/gcts-cadence-integration-ROOT-20261019');L=Path('/private/tmp/gcts-cadence-integration-library-20261019');P=Path('/private/tmp/gcts-owned-evidence-integration-ROOT-20261019')
checks={'components':[],'once':[],'plans':[]}
def ck(g,n,v,detail=None):checks[g].append({'check':n,'passed':bool(v),'detail':detail})
def ds(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def read(p):return json.loads(Path(p).read_bytes())
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def asthash(s):return hashlib.sha256(ast.dump(ast.parse(s),include_attributes=False).encode()).hexdigest()
def regions(s):
 t=ast.parse(s);return {n.name:(ast.dump(n,include_attributes=False),ast.get_source_segment(s,n))for n in t.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
def const(s,name):return ast.literal_eval(next(n.value for n in ast.parse(s).body if isinstance(n,ast.Assign)and any(isinstance(x,ast.Name)and x.id==name for x in n.targets)))
def patch(source,text,rev=False):
 lines=text.splitlines(keepends=True);hunks=[];i=0
 while i<len(lines):
  if lines[i].startswith('@@'):
   m=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',lines[i]);os,oc,ns,nc=[int(v)if v is not None else 1 for v in m.groups()];i+=1;a=[];b=[]
   while i<len(lines)and not lines[i].startswith('@@'):
    q=lines[i]
    if q.startswith(' '):a.append(q[1:]);b.append(q[1:])
    elif q.startswith('-'):a.append(q[1:])
    elif q.startswith('+'):b.append(q[1:])
    else:raise AssertionError('unknown inert patch line')
    i+=1
   assert len(a)==oc and len(b)==nc;hunks.append((os,ns,a,b))
  else:i+=1
 src=source.splitlines(keepends=True);out=[];at=0
 for os,ns,a,b in hunks:
  start=(ns if rev else os)-1;x=b if rev else a;y=a if rev else b
  assert src[start:start+len(x)]==x;out+=src[at:start]+y;at=start+len(x)
 return ''.join(out+src[at:])
manifest=read(D/'false-plan-manifest-v1.json');closure=read(manifest['runtime_closure']['path']);oldclosure=read(P/'runtime-closure-v1.json');decl=read(manifest['case_declaration']['path']);olddecl=read(P/'case-declaration-v1.json');lc=read(L/'Source-contract-v1.json');handoff=read(L/'handoff-v1.json');outer=read(D/'outer-Source-contract-v1.json');delta=read(L/'Source-delta-v1.json')
ck('plans','offered manifest pin',ds(D/'false-plan-manifest-v1.json')['sha256']=='59046bf3d90ea3b12221f7e8df67a34994afcc759563d2cd89f2c7b1a2f04b66')
for k in ['runtime_closure','case_declaration','cold','runner','observer']:ck('plans','whole manifest '+k,ds(manifest[k]['path'])==manifest[k])
cold=Path(handoff['source']['path']).read_text();parent=Path(handoff['parent']['path']).read_text();forward=parent;reverse=cold
for v in delta['changes']:
 ck('components','unique forward delta '+v['label'],forward.count(v['old'])==1);forward=forward.replace(v['old'],v['new'],1)
for v in reversed(delta['changes']):
 ck('components','unique inverse delta '+v['label'],reverse.count(v['new'])==1);reverse=reverse.replace(v['new'],v['old'],1)
ck('components','actual inert cold whole forward/reverse',forward==cold and reverse==parent)
cr=regions(cold);pr=regions(parent);ck('components','all fifteen cold regions retained',len(cr)==len(pr)==15 and set(cr)==set(pr))
for n in cr:ck('components','cold raw/AST region '+n,cr[n]==pr[n])
ck('components','cold forward patch actual equality',patch(parent,(L/'source-forward.patch').read_text())==cold)
ck('components','cold inverse patch actual equality',patch(cold,(L/'source-forward.patch').read_text(),True)==parent)
for key in ['runner','observer']:
 new=Path(outer['sources'][key]['path']).read_text();old=Path(outer['parents'][key]['path']).read_text();pt=D/('outer-v1-v2.patch'if key=='runner'else'observer-v1-v2.patch')
 ck('once','offered whole raw '+key,ds(outer['sources'][key]['path'])==outer['sources'][key])
 ck('once','actual inert forward '+key,patch(old,pt.read_text())==new);ck('once','actual inert reverse '+key,patch(new,pt.read_text(),True)==old)
 nr=regions(new);orr=regions(old);ck('once','same callable set '+key,set(nr)==set(orr))
 for n in nr:ck('once','unchanged raw/AST '+key+'/'+n,nr[n]==orr[n])
 compile(new,outer['sources'][key]['path'],'exec');ck('once','unused compile '+key,True)
 ck('once','constant schema/caps/reviewroles unaffected '+key,all(ast.dump(n,include_attributes=False)==ast.dump(m,include_attributes=False)for n,m in zip(ast.parse(new).body,ast.parse(old).body)if not(isinstance(n,ast.Assign)and any(isinstance(x,ast.Name)and x.id in ['VERSION','COLD_PIN']for x in n.targets))and not(isinstance(n,ast.FunctionDef))))
# All thirty operative Source subjects are current; old28 aliases remain apart from inverse.
ck('components','project22/component2/schema1/evidence4 counts',len(closure['project_sources'])==22 and len(closure['additional_nonseed_components'])==2 and len(closure['schema_sources'])==1 and len(closure['evidence_sources'])==4 and len(closure['materialized_aliases'])==28)
first=read(manifest['plans'][0]['worker_plan']['path']);required=list(first['project_sources'].values())+list(first['components'].values())+list(closure['evidence_sources'].values())+list(closure['schema_sources'].values())+[manifest['cold']]
ck('components','complete thirty distinct required subjects',len(required)==len({x['path']for x in required})==30)
for d in required:
 s=Path(d['path']).read_text();tree=ast.parse(s);ck('components','current whole raw Source '+Path(d['path']).name,ds(d['path'])==d)
# independent census validation uses only AST, not scientific evaluation
ck('components','thirty AST census subjects complete',len(closure['Source_AST_census'])==30 and {x['source']['path']for x in closure['Source_AST_census']}=={x['path']for x in required})
for row in closure['Source_AST_census']:ck('components','current AST fingerprint '+row['alias'],asthash(Path(row['source']['path']).read_text())==row['AST_sha256'])
ck('components','retained original twentyseven subjects',closure['project_sources']==oldclosure['project_sources']and closure['additional_nonseed_components']==oldclosure['additional_nonseed_components']and closure['schema_sources']==oldclosure['schema_sources']and {k:v for k,v in closure['evidence_sources'].items()if k!='inverse'}=={k:v for k,v in oldclosure['evidence_sources'].items()if k!='inverse'})
ck('components','qualified inverse exact current Source',closure['evidence_sources']['inverse']==handoff['inverse']==const(cold,'EVIDENCE_SOURCES')['inverse'])
ck('components','evidence four-source map exact',const(cold,'EVIDENCE_SOURCES')==closure['evidence_sources'])
profile=read(L/'EVIDENCE_PROFILE-v4.json');expected=copy.deepcopy(oldclosure['evidence_profile']);expected['sources']['inverse']=handoff['inverse'];expected['inverse_version']=const(cold,'INVERSE_VERSION');expected['inverse_execution_profile']=const(cold,'INVERSE_PROFILE')
ck('components','literal full profile equals only allowed successor',profile==expected==closure['evidence_profile']==decl['evidence_profile'])
ck('components','all numeric arena/adapter/inverse caps unchanged',profile['arena_limits']==oldclosure['evidence_profile']['arena_limits']and profile['adapter_limits']==oldclosure['evidence_profile']['adapter_limits']and profile['inverse_limits']==oldclosure['evidence_profile']['inverse_limits'])
ck('components','qualified cadence Source/version/profile',const(cold,'INVERSE_VERSION')=='independent-evidence-forest-inverse-v7-bounded-callback-cadence'and const(cold,'INVERSE_PROFILE')=='independent-forest-actual-operations-v2-callback-cadence1024')
ck('components','five adapter groups/eight Stores unchanged',profile['adapter_diagnostics']==oldclosure['evidence_profile']['adapter_diagnostics']and len(profile['adapter_diagnostics']['cases'])==5 and profile['adapter_diagnostics']['maximum_fresh_Stores']==8)
ck('components','inherited peer bindings exact provenance',closure['inherited_role_bindings']==oldclosure['inherited_role_bindings'])
ck('components','Native runtime inputs/library/python unchanged',all(closure[k]==oldclosure[k]for k in ['runtime','native_CPP','fixed_native_inputs','Z3','Z3_imports','parent_closure','schema_kernel_source','external_imports','stdlib_entry_references']))
ck('components','prerequisite finite inverse qualification literal',closure['prerequisite_inverse_qualification']==decl['prerequisite_inverse_qualification']and ds(decl['prerequisite_inverse_qualification']['path'])==decl['prerequisite_inverse_qualification'])
ck('components','cold old independent full BODY+LF checker raw unchanged',cr['verify_saved_evidence']==pr['verify_saved_evidence']and 'if source.completed is not True:'in cr['verify_saved_evidence'][1]and "result_raw[offset:]==b'\\n'"in cr['verify_saved_evidence'][1])
ck('components','new callback fields do not require old exact statistics keyset',"stats['execution_profile']==INVERSE_PROFILE"in cr['verify_saved_evidence'][1]and 'set(stats)'not in cr['verify_saved_evidence'][1])
compile(cold,handoff['source']['path'],'exec');ck('components','unused compile current cold',True)
# Metadata pins, custody, complete schedule and subjects; binary/gzip rawhash only.
pins={}
def collect(x):
 if type(x)is dict:
  if set(x)=={'path','sha256','bytes'}and type(x['bytes'])is int and type(x['sha256'])is str and len(x['sha256'])==64:pins[x['path']]=x
  for v in x.values():collect(v)
 elif type(x)is list:
  for v in x:collect(v)
collect(closure);collect(decl);collect(manifest)
for d in pins.values():ck('plans','whole raw closure/metadata '+d['path'],ds(d['path'])==d)
ck('plans','same complete input selected',decl['selected_receiver']==olddecl['selected_receiver'] and decl['parent_structural_declaration']==olddecl['parent_structural_declaration'])
ck('plans','case/closure evidence profiles literal common',decl['runtime_closure']==manifest['runtime_closure'] and decl['evidence_profile']==closure['evidence_profile'])
ck('plans','all computational cap values same',decl['limits']==olddecl['limits'])
ck('plans','current clock description exact distinct180/210','worker positive work, full evidence/result reading and known worker exit before180s'in decl['clock_scope']and'outer full raw/metadata/resource/custody/group/EOF checks and external terminal before210s'in decl['clock_scope'])
ck('plans','no standalone stronger claim inherited','no standalone qualifier all-outer-check180 guarantee is inherited'in decl['clock_scope'])
ck('plans','two exact declared serial rows',[p['row']['mode']for p in manifest['plans']]==['fixed','symbolic']and [p['row']['order']for p in manifest['plans']]==[1,2]and decl['schedule']==[p['row']for p in manifest['plans']])
ck('plans','manifest/source false no current authority',manifest['actual_execution_authorized']is False and manifest['source_only']is True and manifest['scientific_calls']==0 and decl['actual_execution_authorized']is False)
subjects=[]
for entry in manifest['plans']:
 row=entry['row'];w=read(entry['worker_plan']['path']);p=read(entry['false_once_plan']['path']);mode=row['mode'];s={k:v for k,v in p.items()if k!='authorization'};sha=hashlib.sha256(canonical(s)).hexdigest()
 ck('plans','worker whole raw '+mode,ds(entry['worker_plan']['path'])==entry['worker_plan']);ck('plans','once whole raw '+mode,ds(entry['false_once_plan']['path'])==entry['false_once_plan'])
 ck('plans','full eighteen-field subject '+mode,len(s)==18 and len(p)==19)
 ck('plans','nonrunnable false authorization sentinel '+mode,p['authorization']==dict(path='NO_AUTHORIZATION_FALSE_PLAN',sha256='NO_AUTHORIZATION',bytes=0))
 ck('plans','literal worker+once subject joins '+mode,all(w[k]==p[k]==row[k]for k in ['invocation_id','actual_directory','mode','search_ordering','inventory_certification_mode','model_storage','result_reader','receiver_id']))
 ck('plans','common current worker metadata '+mode,w['cold']==p['cold']==manifest['cold']and w['python']==p['python']==closure['runtime']['Python_executable']and w['runtime_closure']==p['runtime_closure']==manifest['runtime_closure']and w['integration_declaration']==p['integration_declaration']==manifest['case_declaration'])
 ck('plans','common current complete scientific pins '+mode,w['project_sources']==closure['project_sources']and w['components']==closure['additional_nonseed_components'])
 ck('plans','exact frozen input/policy/native/Z3 '+mode,w['declaration']==decl['parent_structural_declaration']and w['native_inputs']==first['native_inputs']and w['policy']==first['policy']and w['z3']==first['z3'])
 ck('plans','exact current outer+worker descriptors '+mode,p['runner']==manifest['runner']and p['observer']==manifest['observer']and p['worker_plan']==entry['worker_plan'])
 ck('plans','fixed current factor enums '+mode,row['receiver_id']=='prospective-fol-20261018-001'and row['inventory_certification_mode']=='schema_then_native'and row['search_ordering']=='and_support'and row['model_storage']=='literal_interned'and row['result_reader']=='interned')
 act=Path(row['actual_directory']);ck('plans','fresh canonical local actual '+mode,act.is_absolute()and str(act.resolve())==str(act)and str(act).startswith('/private/tmp/')and not act.exists())
 ck('plans','fresh prospective observer dirs '+mode,not list((D/'plans-v1').rglob('*'+row['invocation_id']+'*terminal-observation')))
 subjects.append(dict(mode=mode,row=row,subject=s,subject_sha256=sha,worker_plan=entry['worker_plan'],false_once_plan=entry['false_once_plan']))
 ck('plans','outer original numeric limits '+mode,p['limits']==const(Path(manifest['runner']['path']).read_text(),'LIMITS'))
 ck('plans','source environment exact '+mode,p['environment']=={'LANG':'C','LC_ALL':'C','PYTHONHASHSEED':'0'})
ck('plans','same pair scientific preimages',read(manifest['plans'][0]['worker_plan']['path'])['project_sources']==read(manifest['plans'][1]['worker_plan']['path'])['project_sources'])
ck('plans','no current true grants or consumed actuals',not(D/'plans-v1/authorizations').exists()and not list(D.glob('actual-*/CONSUMED.json')))
out={'schema':'cadence-integration-independent-static-audit-v1','source_only':True,'scientific_calls':0,'component_evaluations':0,'actual_execution_authorized':False,'manifest':ds(D/'false-plan-manifest-v1.json'),'cold_handoff':ds(L/'handoff-v1.json'),'outer_contract':ds(D/'outer-Source-contract-v1.json'),'required_components_subjects':required,'once_subjects':outer['sources'],'plans':subjects,'unique_raw_metadata_pin_count':len(pins),'inert_forward_reverse_directions':6,'unused_compiles':3,'check_counts':{k:len(v)for k,v in checks.items()},'mismatch_counts':{k:sum(not c['passed']for c in v)for k,v in checks.items()},'checks':checks}
(C/'current-static-audit-v1.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k not in ['required_components_subjects','plans','checks']},indent=2));print('SUBJECTS',[(p['mode'],p['subject_sha256'])for p in subjects]);print('FAILURES',{k:[c for c in v if not c['passed']]for k,v in checks.items()})
