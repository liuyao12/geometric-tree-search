"""Explicit owned-reference translation of the V4 independent registry join.
Source-only unqualified. No mathematical rule or proof-search action here.
"""
VERSION='owned-inventory-independent-join-v1'

def check_owned_inventory(*,store,bundle,original,records,before,spec,context,boundary,record_join,error):
    boundary.check(full=True);inventory,root=store.unwrap_inventory(bundle)
    def node(r,*path):
        for key in path:r=r.at(key)
        return r
    def scalar(r,*path,kind=None):
        r=node(r,*path);v=r.scalar()
        if kind is not None and type(v)is not kind:raise error('strict owned scalar kind')
        return v
    def equal(r,path,value):return node(r,*path).equals(value)
    def array(r,*path):
        r=node(r,*path)
        if r.kind!='array':raise error('owned array required')
        return [r.at(i)for i in range(r.length)]
    extra={'status','query','queries','certification','seconds'}
    if root.kind!='object'or set(root.keys)!=set(original)|extra:raise error('complete original registry logical fields')
    if any(not root.at(k).equals(v)for k,v in original.items()):raise error('full original inventory retained')
    if type(inventory)is not dict or set(inventory)!=set(original)|extra:raise error('exact complete operational inventory fields')
    if any(not root.at(k).equals(inventory[k])for k in original):raise error('full typed operational/logical original inventory equality')
    cert=root.at('certification')
    expected={'schema':'schema-then-native-inventory-certification-v1','version':'inventory-schema-then-native-v1','mode':'schema_then_native','aggregate_micro_step_limit':5*10**9,'source_epoch':context['source_epoch'],'semantic_epoch':context['semantic_epoch'],'complete_original_library':context['library']}
    if cert.kind!='object'or any(not cert.at(k).equals(v)for k,v in expected.items()):raise error('current full schema registry context/cap')
    envelope=('schema','version','mode','complete','Model_permission','native_accepted','fresh_Native_target_proof_accepted','final_whole_Native_required')
    if type(inventory.get('certification'))is not dict or set(inventory['certification'])!=set(envelope):raise error('explicit operational admission envelope')
    if any(not cert.at(k).equals(inventory['certification'][k])for k in envelope):raise error('full logical/operational envelope join')
    if any(not root.at(k).equals(inventory[k])for k in ('status','query','queries','seconds')):raise error('complete operational status/query/timing join')
    library=context['library'];family_ids=[f['id']for f in library];rows=original['definitions'];names=[r['name']for r in rows]
    blocks={r['name']:r['definition']for r in rows};by_name={r['name']:r for r in rows};closures={};seen=set()
    for row in rows:
        boundary.check();name=row['name'];needed={name}
        if name in seen or row['definition']['name']!=name:raise error('unique original ground identity')
        for command in row['definition']['proof']:
            if command['rule']=='block':
                dep=command['name']
                if dep not in seen:raise error('strict original dependency order')
                needed.update(closures[dep])
        closures[name]=needed;seen.add(name)
    if (not cert.at('original_family_ids').equals(family_ids)or not cert.at('all_original_definition_names').equals(names)or
            not cert.at('all_original_interfaces').equals(original['interfaces'])or original['native_blocks']!=[r['definition']for r in rows]):
        raise error('full original family/definition/interface coverage preimages')
    taut=['imp',['bot'],['bot']];request=dict(protocol='gcts-fol-1',theory=spec['theory'],blocks=[],proof=[dict(rule='tautology',formula=taut)],target=taut)
    theory_id=context['theory_admission_record_id'];theory_join=record_join(records,theory_id,request,boundary);theory_record=records[theory_id]
    if (not 0<=theory_id<before or type(theory_record['id'])is not int or theory_record['purpose']!='first_order_theory_admission'or
            theory_join['result_status']!='accepted'or not equal(cert,('theory_admission','record_id'),theory_id)or
            not equal(cert,('theory_admission','record'),theory_record)or not equal(cert,('theory_admission','registration_microsteps_charged'),0)or
            not equal(cert,('theory_admission','compile_microsteps'),theory_record['result']['micro_steps'])):raise error('fresh current compiler theory custody')
    def packet(p,operation):
        boundary.check()
        if p.kind!='object'or any(not p.at(k).equals(v)for k,v in dict(schema='mp-schema-certificate-result-v1',version='mp-schema-certificates-v1',operation=operation).items()):raise error('retained complete component packet protocol')
        status=scalar(p,'status',kind=str)
        if status not in('ELIGIBLE_CERTIFICATE','GROUND_CORRESPONDENCE','NOT_ELIGIBLE','REJECTED','UNKNOWN'):raise error('component disposition')
        if any(scalar(p,'authority',k)is not False for k in('native_accepted','Model_permission','logical_target_proof_accepted','candidate_pruning','new_axiom')):raise error('component has no registry/Native authority')
        if status in('ELIGIBLE_CERTIFICATE','GROUND_CORRESPONDENCE'):
            if scalar(p,'input_custody_complete')is not True:raise error('complete positive component ownership')
            if not equal(p,('certificate','source_epoch'),context['source_epoch'])or not equal(p,('certificate','semantic_epoch'),context['semantic_epoch']):raise error('complete current certificate epochs')
        return status
    census=array(cert,'family_census')
    if [scalar(r,'family_id',kind=str)for r in census]!=family_ids[:len(census)]:raise error('full original-order family prefix')
    family_status={};locations=[]
    for f,row in zip(library,census):
        if scalar(row,'original_library_index',kind=int)!=family_ids.index(f['id']):raise error('original family ordinal')
        first=row.at('certification');status=packet(first,'certify_family');locations.append(dict(stage='family_certification',family_id=f['id']))
        if status=='ELIGIBLE_CERTIFICATE':
            c=first.at('certificate')
            if not c.at('family').equals(f)or not equal(first,('input_snapshot','family'),f):raise error('whole unchanged original family')
            again=row.at('revalidation');status=packet(again,'revalidate_certificate');locations.append(dict(stage='family_revalidation',family_id=f['id']))
            if status=='ELIGIBLE_CERTIFICATE'and not again.at('certificate').same(c):raise error('full certificate reconstruction equality')
        elif row.at('revalidation').kind!='null':raise error('only eligible family revalidation')
        if scalar(row,'disposition',kind=str)!=status:raise error('family disposition join')
        family_status[f['id']]=status
    if not cert.at('pending_family_ids').equals([f for f in family_ids if f not in family_status]):raise error('full pending original family IDs')
    ground=array(cert,'ground_census')
    if len(ground)>len(rows)or[scalar(g,'name',kind=str)for g in ground]!=names[:len(ground)]:raise error('original ground census prefix')
    fallback=[];schema_names=[];native_names=[];used=0
    for ordinal,(row,g)in enumerate(zip(rows,ground)):
        boundary.check()
        if scalar(g,'ordinal',kind=int)!=ordinal or scalar(g,'family_id',kind=str)!=row['family']:raise error('original ground binding ordinal')
        component=g.at('correspondence');native=g.at('Native_fallback');disposition=scalar(g,'disposition',kind=str)
        if component.kind!='null':
            status=packet(component,'check_ground_instance');locations.append(dict(stage='ground_correspondence',definition=row['name']))
            if family_status.get(row['family'])!='ELIGIBLE_CERTIFICATE':raise error('only eligible complete family ground checker')
            if status=='GROUND_CORRESPONDENCE':
                i=component.at('input_snapshot');p=component.at('ground_correspondence');closure=[by_name[n]for n in names if n in closures[row['name']]]
                expansion=p.at('primitive_expansion');proof=expansion.at('proof')
                if (not i.at('ground_definition').equals(row)or not i.at('arguments').equals(row['arguments'])or
                        not i.at('dependency_definitions').equals(rows)or not i.at('source_epoch').equals(context['source_epoch'])or not i.at('semantic_epoch').equals(context['semantic_epoch'])or
                        not p.at('root_name').equals(row['name'])or not p.at('arguments').equals(row['arguments'])or not p.at('ground_definition').equals(row)or
                        not p.at('original_ordered_closure').equals(closure)or scalar(p,'full_registry_preserved')is not True or
                        not expansion.at('premises').equals(row['definition']['premises'])or not expansion.at('conclusion').equals(row['definition']['conclusion'])or
                        proof.kind!='array'or proof.length==0 or not proof.at(proof.length-1).at('formula').equals(row['definition']['conclusion'])or native.kind!='null'or disposition!=status):
                    raise error('full original ground/closure/primitive correspondence')
                schema_names.append(row['name']);continue
            if status!='NOT_ELIGIBLE':
                if native.kind!='null'or disposition!=status:raise error('unknown/rejected component never fallback')
                continue
        elif family_status.get(row['family'])!='NOT_ELIGIBLE':raise error('absent ground correspondence requires ineligible original family')
        if native.kind=='null':
            if disposition!='PENDING_NATIVE_BUDGET'or used!=5*10**9:raise error('pending Native only after exact exhaustion')
            continue
        closure_names=[n for n in names if n in closures[row['name']]];request=dict(protocol='gcts-fol-1',theory=spec['theory'],blocks=[blocks[n]for n in closure_names],proof=[dict(rule='tautology',formula=taut)],target=taut)
        index=before+len(fallback);joined=record_join(records,index,request,boundary);r=records[index];steps=r['result']['micro_steps'];status=r['result']['status']
        expected_receipt=dict(ordinal=len(fallback),definition=row['name'],closure_names=closure_names,query=index,request=request,record=r,assigned_micro_step_limit=5*10**9-used,consumed_micro_steps=steps,aggregate_consumed_before=used,aggregate_consumed_after=used+steps,result_status=status)
        if (not native.equals(expected_receipt)or r['purpose']!='check_schema_ineligible_lemma_definition_closure'or type(steps)is not int or not 0<=steps<=5*10**9-used or
                status not in('accepted','rejected','unknown_space_budget','unknown_step_budget')or disposition!=('NATIVE_CLOSURE_ACCEPTED'if status=='accepted'else status)):
            raise error('every fresh fallback full request/closure/step join')
        fallback.append(native);used+=steps
        if status=='accepted':native_names.append(row['name'])
    fallback_census=array(cert,'Native_fallback_receipts')
    if (len(records)!=before+len(fallback)or len(fallback_census)!=len(fallback)or any(not a.same(b)for a,b in zip(fallback_census,fallback))or
            not cert.at('aggregate_consumed_micro_steps').equals(used)or not cert.at('schema_correspondence_definition_names').equals(schema_names)or
            not cert.at('Native_checked_definition_names').equals(native_names)or not cert.at('returned_component_packet_locations').equals(locations)or
            inventory['query']is not None or inventory['queries']!=[scalar(r,'query',kind=int)for r in fallback]):raise error('full serial fallback/component-prefix custody')
    covered=set(schema_names)|set(native_names)
    if not cert.at('pending_definition_names').equals([n for n in names if n not in covered]):raise error('full original pending coverage')
    complete=(scalar(cert,'stop_reason')is None and len(census)==len(library)and all(s in('ELIGIBLE_CERTIFICATE','NOT_ELIGIBLE')for s in family_status.values())and len(ground)==len(rows)and covered==set(names))
    if (scalar(cert,'complete')is not complete or scalar(cert,'Model_permission')is not complete or scalar(cert,'native_accepted')is not False or
            scalar(cert,'fresh_Native_target_proof_accepted')is not False or scalar(cert,'final_whole_Native_required')is not True or
            complete and(inventory['status']!='schema_admitted'or scalar(cert,'family_census_complete')is not True)or
            not complete and inventory['status']not in('schema_rejected','unknown_schema_inventory','native_rejected','unknown_native_inventory')):raise error('only complete whole inventory permits Model')
    boundary.check(full=True)
    return dict(schema='schema-inventory-independent-driver-join-v1',complete=complete,Model_permission=complete,native_accepted=False,final_whole_Native_required=True,original_families=len(library),original_definitions=len(rows),returned_family_packets=len(census),returned_ground_packets=len(ground),schema_definitions=len(schema_names),Native_fallback_definitions=len(native_names),fallback_queries=[scalar(r,'query',kind=int)for r in fallback],theory_join=theory_join,full_original_registry_preserved=True,scope='Independent full literal/custody/cost join of the declared structural gate; not an additional logical proof checker or Native theorem authority.')
