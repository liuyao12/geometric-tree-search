"""Narrow, proof-producing MP schema certificates; no Native permission.

Only implication/meta schemas with assumption, MP and certified dependency calls
are eligible. Current kernel/Model/registry are unchanged. All public inputs are
untrusted; a certificate is rebuilt from literal rules, not a boolean or hash.
No scientific module is imported here. This Source has not been evaluated.
"""
import hashlib
import json
import math

VERSION='mp-schema-certificates-v1'
RESULT_SCHEMA='mp-schema-certificate-result-v1'
CERTIFICATE_SCHEMA='mp-schema-certificate-v1'
GROUND_SCHEMA='mp-schema-ground-correspondence-v1'
FRAGMENT='IMPLICATION_META_ASSUMPTION_MP_CERTIFIED_DAG_V1'
KERNEL_SOURCE_SHA256='8c86a24231d9c7d1777d7998b747a8cfd07087c168da64db6c5dff0820c802ed'
KERNEL_SOURCE_BYTES=17577
DEFAULT_LIMITS=dict(work=200000,depth=128,schema_rows=4096,primitive_rows=16384,
                    parameters=64,output_bytes=8*1024*1024)
AUTHORITY=dict(native_accepted=False,Model_permission=False,new_axiom=False,
    candidate_pruning=False,logical_target_proof_accepted=False,
    scope='Narrow structural schema/correspondence only; fresh whole Native remains mandatory.')


class SchemaCustodyError(ValueError):
    """A Source guard returned but full owned input/formula custody changed."""


class SchemaCallbackProtocolError(ValueError):
    """The authenticated syntax-only callback returned an invalid protocol."""


class _Refusal(Exception):
    def __init__(self,owner,status,reason):
        self.owner,self.status,self.reason=owner,status,reason
        super().__init__(reason)


class _Stop(Exception):
    def __init__(self,owner,reason):
        self.owner,self.reason=owner,reason
        super().__init__(reason)


class _Work:
    def __init__(self,check,limits):
        self.check=check;self.owner=object();self.counts={};self.limits=dict(DEFAULT_LIMITS)
        if limits is not None:
            if type(limits) is not dict or set(limits)-set(self.limits):
                raise ValueError('declared MP-schema limits')
            self.limits.update(limits)
        if any(type(v) is not int or v<=0 for v in self.limits.values()):
            raise ValueError('positive strict integer MP-schema limits')
    def step(self,kind='work'):
        self.check()  # Delegated exceptions retain their exact object/origin.
        if self.counts.get('work',0)>=self.limits['work']:
            raise _Stop(self.owner,'schema_work_budget')
        self.counts['work']=self.counts.get('work',0)+1
        if kind!='work':self.counts[kind]=self.counts.get(kind,0)+1
    def reject(self,reason):
        raise _Refusal(self.owner,'REJECTED',reason)
    def ineligible(self,reason):
        raise _Refusal(self.owner,'NOT_ELIGIBLE',reason)
    def bound(self,name,value):
        self.step('bounds')
        if value>self.limits[name]:raise _Stop(self.owner,'schema_'+name+'_budget')


def _bytes(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode('utf8')


def _digest(value):
    return hashlib.sha256(_bytes(value)).hexdigest()


def _copy(value,w,depth=0,active=None):
    w.step('literal_nodes');w.bound('depth',depth)
    if active is None:active=set()
    if type(value) in (dict,list):
        identity=id(value)
        if identity in active:w.reject('cyclic non-JSON input')
        active.add(identity)
        if type(value) is dict:
            if any(type(k) is not str for k in value):w.reject('literal string-key object')
            result={k:_copy(v,w,depth+1,active) for k,v in value.items()}
        else:result=[_copy(v,w,depth+1,active) for v in value]
        active.remove(identity);return result
    if value is None or type(value) in (str,int,bool):return value
    if type(value) is float and math.isfinite(value):return value
    w.reject('ordinary finite JSON literal required')


def _fields(value,fields,w,reason):
    w.step('shape_checks')
    if type(value) is not dict or set(value)!=set(fields):w.reject(reason)


def _index(value,size,w,reason):
    w.step('index_checks')
    if type(value) is not int or not 0<=value<size:w.reject(reason)
    return value


def _hash(value,w):
    w.step('identity_checks')
    if type(value) is not str or len(value)!=64 or any(c not in '0123456789abcdef' for c in value):
        w.reject('literal full SHA256 identity')


def _epochs(source,semantic,w):
    w.step('epoch_checks')
    if type(source) is not dict or not source or type(semantic) is not dict:
        w.reject('complete current caller Source/semantic epochs required')
    if semantic.get('kernel_protocol')!='gcts-fol-1':w.reject('exact current kernel protocol')
    kernel=semantic.get('kernel_source')
    if (type(kernel) is not dict or type(kernel.get('path')) is not str or
            kernel.get('sha256')!=KERNEL_SOURCE_SHA256 or
            type(kernel.get('bytes')) is not int or kernel['bytes']!=KERNEL_SOURCE_BYTES):
        w.reject('pinned original kernel raw Source descriptor')
    # Remaining complete epoch fields are retained literally, never interpreted
    # as proof or as a caller's claimed validity flag. Root authenticates maps.


def _formula(formula,parameters,w,depth=0):
    w.step('schematic_formula_nodes');w.bound('depth',depth)
    if type(formula) is not list or not formula or type(formula[0]) is not str:
        w.reject('schematic formula AST')
    if formula[0]=='meta':
        if len(formula)!=2:w.reject('exact meta arity')
        _index(formula[1],parameters,w,'strict formula parameter index');return
    if formula[0]=='imp':
        if len(formula)!=3:w.reject('exact implication arity')
        _formula(formula[1],parameters,w,depth+1);_formula(formula[2],parameters,w,depth+1);return
    w.ineligible('formula outside implication/meta fragment')


def _replace(value,arguments,w):
    w.step('uniform_substitution_nodes')
    if type(value) is list:
        if len(value)==2 and value[0]=='meta':
            return _copy(arguments[_index(value[1],len(arguments),w,'substitution parameter')],w)
        return [_replace(v,arguments,w) for v in value]
    if type(value) is dict:return {k:_replace(v,arguments,w) for k,v in value.items()}
    return value


def _family_header(family,w):
    _fields(family,('id','parameters','template','dependencies','donor_atoms','provenance','scope'),w,'exact original family fields')
    _hash(family['id'],w);parameters=family['parameters']
    if type(parameters) is not int or parameters<0:w.reject('strict nonnegative parameter arity')
    w.bound('parameters',parameters)
    if (type(family['dependencies']) is not list or
            any(type(i) is not str for i in family['dependencies']) or
            family['dependencies']!=sorted(set(family['dependencies']))):w.reject('sorted unique declared dependency IDs')
    for i in family['dependencies']:_hash(i,w)
    if (type(family['donor_atoms']) is not list or len(family['donor_atoms'])!=parameters or
            any(type(n) is not str for n in family['donor_atoms']) or
            len(set(family['donor_atoms']))!=parameters):w.reject('exact original parameter provenance arity')
    if type(family['provenance']) is not dict or type(family['scope']) is not str:w.reject('literal original family provenance')
    t=family['template'];_fields(t,('premises','conclusion','proof'),w,'exact original template fields')
    if type(t['premises']) is not list or type(t['proof']) is not list or not t['proof']:
        w.reject('ordered premises/nonempty proof')
    if family['id']!=_digest(dict(parameters=parameters,template=t)):w.reject('whole original schema identity preimage')
    w.bound('schema_rows',len(t['proof']))
    for f in t['premises']:_formula(f,parameters,w)
    _formula(t['conclusion'],parameters,w)
    return t,parameters


def _rebuild(family,dependency_certificates,source,semantic,w,active):
    t,parameters=_family_header(family,w);fid=family['id']
    if fid in active:w.reject('cyclic certified family DAG')
    active=active|{fid}
    if type(dependency_certificates) is not list:w.reject('ordered direct certificate list')
    dependencies={};dependency_order=[]
    for c in dependency_certificates:
        w.step('dependency_certificates')
        rebuilt=_revalidate(c,source,semantic,w,active)
        did=rebuilt['family']['id']
        if did in dependencies:w.reject('duplicate dependency certificate identity')
        dependencies[did]=rebuilt;dependency_order.append(did)
    if dependency_order!=sorted(dependency_order):w.reject('canonical direct certificate order')
    if set(dependencies)-set(family['dependencies']):w.reject('undeclared extra dependency certificates')
    if set(family['dependencies'])-set(dependencies):w.ineligible('declared dependency has no eligible certificate')
    proved=[];rows=[];called=set()
    for position,command in enumerate(t['proof']):
        w.step('schema_rows_checked')
        if type(command) is not dict or type(command.get('rule')) is not str:w.reject('literal command rule')
        rule=command['rule'];formula=command.get('formula');_formula(formula,parameters,w)
        evidence={}
        if rule=='assumption':
            _fields(command,('rule','formula','index'),w,'exact assumption fields')
            i=_index(command['index'],len(t['premises']),w,'ordered assumption port')
            if formula!=t['premises'][i]:w.reject('assumption formula differs from exact indexed premise')
            evidence=dict(premise_port=i)
        elif rule=='mp':
            _fields(command,('rule','formula','antecedent','implication'),w,'exact MP fields')
            a=_index(command['antecedent'],position,w,'strict prior MP antecedent')
            b=_index(command['implication'],position,w,'strict prior MP implication')
            if proved[b]!=['imp',proved[a],formula]:w.reject('literal schematic MP mismatch')
            evidence=dict(antecedent_row=a,implication_row=b)
        elif rule=='block':
            _fields(command,('rule','formula','call','inputs'),w,'exact schematic call fields')
            call=command['call'];_fields(call,('family','arguments'),w,'exact schematic call descriptor')
            did=call['family'];_hash(did,w)
            if did not in dependencies:w.reject('call requires its exact declared certified dependency')
            d=dependencies[did]['family'];arguments=call['arguments']
            if type(arguments) is not list or len(arguments)!=d['parameters']:w.reject('exact dependency formula argument arity')
            for f in arguments:_formula(f,parameters,w)
            interface=_replace(dict(premises=d['template']['premises'],conclusion=d['template']['conclusion']),arguments,w)
            inputs=command['inputs']
            if type(inputs) is not list or len(inputs)!=len(interface['premises']):w.reject('complete ordered dependency ports')
            ports=[]
            for port,(source_row,wanted) in enumerate(zip(inputs,interface['premises'])):
                source_row=_index(source_row,position,w,'strict prior dependency input')
                if proved[source_row]!=wanted:w.reject('ordered/repeated dependency input formula')
                ports.append(dict(port=port,source_row=source_row,formula=wanted))
            if formula!=interface['conclusion']:w.reject('dependency conclusion correspondence')
            called.add(did);evidence=dict(family=did,arguments=arguments,ordered_ports=ports)
        else:w.ineligible('command outside assumption/MP/certified-call fragment')
        proved.append(formula);rows.append(dict(row=position,rule=rule,formula=formula,evidence=evidence))
    if called!=set(family['dependencies']):w.reject('all-and-only declared dependency calls')
    if proved[-1]!=t['conclusion']:w.reject('last exact schematic formula is not conclusion')
    return dict(schema=CERTIFICATE_SCHEMA,version=VERSION,fragment=FRAGMENT,
        family=family,dependency_certificates=[dependencies[i] for i in sorted(dependencies)],
        source_epoch=source,semantic_epoch=semantic,derived_rows=rows,
        interface=dict(premises=t['premises'],conclusion=t['conclusion'],ordered_ports=list(range(len(t['premises'])))),
        soundness_scope='Uniform whole-formula substitution preserves this implication/meta assumption/MP/certified-DAG derivation. No metavariable lies under an object-language binder.',
        authority=dict(AUTHORITY))


def _revalidate(certificate,source,semantic,w,active):
    _fields(certificate,('schema','version','fragment','family','dependency_certificates','source_epoch','semantic_epoch','derived_rows','interface','soundness_scope','authority'),w,'exact complete certificate fields')
    if (certificate['schema']!=CERTIFICATE_SCHEMA or certificate['version']!=VERSION or
            certificate['fragment']!=FRAGMENT or certificate['source_epoch']!=source or
            certificate['semantic_epoch']!=semantic):w.reject('whole current certificate Source/semantic custody')
    rebuilt=_rebuild(certificate['family'],certificate['dependency_certificates'],source,semantic,w,active)
    if _bytes(rebuilt)!=_bytes(certificate):w.reject('whole literal certificate reconstruction mismatch')
    return rebuilt


def _syntax(formula,validator,w):
    w.step('formula_WF_calls');before=_bytes(formula)
    valid=validator(formula)  # Syntax only, never a logical proof/Native boolean.
    w.step()
    if _bytes(formula)!=before:raise SchemaCustodyError('formula validator mutated owned formula')
    if type(valid) is not bool:raise SchemaCallbackProtocolError('formula validator must return strict syntax bool')
    if not valid:w.reject('current receiver signature/formula syntax rejected')


def _ground_records(certificate,arguments,w,validator):
    """Independent uniform specialization, not a call to the old specializer."""
    records={}
    def build(c,args):
        w.step('ground_instances')
        f=c['family']
        if type(args) is not list or len(args)!=f['parameters']:w.reject('exact whole-formula ground binding arity')
        for a in args:_syntax(a,validator,w)
        name='lemma'+_digest(dict(family=f['id'],arguments=args))
        ground=_replace(f['template'],args,w);body=[];level=1
        deps={d['family']['id']:d for d in c['dependency_certificates']}
        for command in ground['proof']:
            w.step('ground_commands');command=dict(command)
            if command['rule']=='block':
                call=command.pop('call');dep=build(deps[call['family']],call['arguments'])
                command['name']=dep;level=max(level,records[dep]['level']+1)
            _syntax(command['formula'],validator,w);body.append(command)
        for p in ground['premises']:_syntax(p,validator,w)
        _syntax(ground['conclusion'],validator,w)
        row=dict(name=name,family=f['id'],arguments=args,level=level,
            definition=dict(name=name,premises=ground['premises'],conclusion=ground['conclusion'],proof=body))
        if name in records and _bytes(records[name])!=_bytes(row):w.reject('full ground identity collision')
        records[name]=row;return name
    root=build(certificate,arguments)
    return root,records


def _registry(ground_definition,dependency_definitions,expected,w):
    """Check required closure in a FULL original registry, leaving extras intact."""
    if type(dependency_definitions) is not list:w.reject('full original ground definition registry')
    table={};positions={}
    for position,row in enumerate(dependency_definitions):
        w.step('original_registry_rows')
        _fields(row,('name','family','arguments','level','definition'),w,'exact original specialized definition fields')
        if type(row['name']) is not str or row['name'] in table:w.reject('unique original full registry names')
        if type(row['level']) is not int or row['level']<1:w.reject('strict original Native dependency level')
        _hash(row['family'],w)
        if type(row['arguments']) is not list:w.reject('complete original formula arguments')
        _fields(row['definition'],('name','premises','conclusion','proof'),w,'exact original Native definition fields')
        if (row['definition']['name']!=row['name'] or type(row['definition']['premises']) is not list or
                type(row['definition']['proof']) is not list):w.reject('complete original Native body/interface shape')
        table[row['name']]=row;positions[row['name']]=position
    if type(ground_definition) is not dict or ground_definition.get('name') not in table:
        w.reject('ground root must remain in complete original registry')
    if _bytes(table[ground_definition['name']])!=_bytes(ground_definition):w.reject('exact original root record custody')
    for name,row in expected.items():
        w.step('ground_correspondence_rows')
        if name not in table or _bytes(table[name])!=_bytes(row):w.reject('independent ground specialization differs from original')
        for cmd in row['definition']['proof']:
            if cmd['rule']=='block' and positions[cmd['name']]>=positions[name]:w.reject('original dependency-first registry order')
    return [row for row in dependency_definitions if row['name'] in expected]


def _flatten(root,records,w,validator):
    """Inline with exact caller source aliases, not new child assumptions."""
    primitive=[];frames=[]
    def emit(command):
        w.bound('primitive_rows',len(primitive)+1);primitive.append(command);return len(primitive)-1
    def frame(name,input_sources,path):
        w.step('expansion_frames');row=records[name];definition=row['definition'];mapping=[];events=[]
        if input_sources is not None:
            if len(input_sources)!=len(definition['premises']):w.reject('full expansion input arity')
            for port,(source,wanted) in enumerate(zip(input_sources,definition['premises'])):
                source=_index(source,len(primitive),w,'all ordered caller primitive sources')
                if primitive[source]['formula']!=wanted:w.reject('full ordered caller premise correspondence')
        for line,command in enumerate(definition['proof']):
            w.step('primitive_expansion_rows');rule=command['rule'];formula=command['formula']
            if rule=='assumption':
                port=_index(command['index'],len(definition['premises']),w,'expansion assumption port')
                if input_sources is None:
                    actual=emit(dict(rule='assumption',formula=formula,index=port));alias=False
                else:
                    actual=_index(input_sources[port],len(primitive),w,'actual caller primitive source')
                    if primitive[actual]['formula']!=formula:w.reject('child assumption actual caller formula')
                    alias=True
            elif rule=='mp':
                a=mapping[_index(command['antecedent'],line,w,'expanded strict prior antecedent')]
                b=mapping[_index(command['implication'],line,w,'expanded strict prior implication')]
                if primitive[b]['formula']!=['imp',primitive[a]['formula'],formula]:w.reject('expanded actual MP correspondence')
                actual=emit(dict(rule='mp',formula=formula,antecedent=a,implication=b));alias=False
            elif rule=='block':
                ports=[mapping[_index(i,line,w,'expanded ordered call input')] for i in command['inputs']]
                actual=frame(command['name'],ports,path+[line]);alias=True
                if primitive[actual]['formula']!=formula:w.reject('expanded dependency output formula')
            else:w.reject('unsupported rule escaped certified fragment')
            mapping.append(actual);events.append(dict(source_row=line,primitive_row=actual,alias=alias,rule=rule))
        if not mapping:w.reject('nonempty expanded frame')
        result=mapping[-1]
        if primitive[result]['formula']!=definition['conclusion']:w.reject('expanded frame exact result')
        frames.append(dict(call_path=path,name=name,input_sources=input_sources,row_mapping=events,result_row=result))
        return result
    result=frame(root,None,[]);tail=None
    if result!=len(primitive)-1:
        # A final identity call may alias an earlier result. Re-emit its actual
        # assumption/MP command, whose existing references are still earlier.
        prior=result;result=emit(dict(primitive[prior]));tail=dict(source_row=prior,appended_row=result,reason='kernel requires final literal formula to be target')
    premises=records[root]['definition']['premises'];conclusion=records[root]['definition']['conclusion'];proved=[]
    for position,command in enumerate(primitive):
        w.step('flat_primitive_recheck');formula=command['formula'];_syntax(formula,validator,w)
        if command['rule']=='assumption':
            _fields(command,('rule','formula','index'),w,'flat assumption fields')
            if premises[_index(command['index'],len(premises),w,'flat root assumption')]!=formula:w.reject('flat root assumption mismatch')
        elif command['rule']=='mp':
            _fields(command,('rule','formula','antecedent','implication'),w,'flat MP fields')
            a=_index(command['antecedent'],position,w,'flat prior antecedent');b=_index(command['implication'],position,w,'flat prior implication')
            if proved[b]!=['imp',proved[a],formula]:w.reject('flat MP mismatch')
        else:w.reject('flat proof must use only original assumption/MP rules')
        proved.append(formula)
    if not proved or proved[-1]!=conclusion:w.reject('flat proof must end at claimed conclusion')
    return dict(premises=premises,conclusion=conclusion,proof=primitive,frames=frames,result_row=result,
                tail_reification=tail,primitive_commands=len(primitive))


def _run(operation,inputs,check,source_guard,limits,action):
    if not callable(check) or not callable(source_guard):raise TypeError('charged check/current Source guard required')
    w=_Work(check,limits);owned=None;before=None;custody=False
    try:
        w.step();source_guard();w.step()
        owned=_copy(inputs,w);before=_bytes(owned)
        _epochs(owned['source_epoch'],owned['semantic_epoch'],w)
        try:
            result=action(owned,w)
        except _Refusal as refusal:
            if refusal.owner is not w.owner:raise
            result=dict(status=refusal.status,reason=refusal.reason,certificate=None,ground_correspondence=None)
        w.step('final_custody');source_guard();w.step()
        if _bytes(_copy(inputs,w))!=before:raise SchemaCustodyError('whole public input/epoch/certificate changed')
        custody=True
        result.update(schema=RESULT_SCHEMA,version=VERSION,operation=operation,
            input_snapshot=owned,input_custody_complete=True,limits=dict(w.limits),authority=dict(AUTHORITY))
        w.step('output_checks');result['counts']=dict(w.counts)
        encoded=_bytes(result);check()
        if len(encoded)>w.limits['output_bytes']:raise _Stop(w.owner,'schema_output_bytes_budget')
        return result
    except _Refusal as refusal:
        if refusal.owner is not w.owner:raise
        return dict(schema=RESULT_SCHEMA,version=VERSION,operation=operation,status=refusal.status,
            reason=refusal.reason,certificate=None,ground_correspondence=None,input_snapshot=None,
            input_custody_complete=False,counts=dict(w.counts),limits=dict(w.limits),authority=dict(AUTHORITY))
    except _Stop as stop:
        if stop.owner is not w.owner:raise
        return dict(schema=RESULT_SCHEMA,version=VERSION,operation=operation,status='UNKNOWN',
            reason=stop.reason,certificate=None,ground_correspondence=None,input_snapshot=None,
            input_custody_complete=custody,counts=dict(w.counts),limits=dict(w.limits),authority=dict(AUTHORITY))


def certify_family(*,family,certified_dependencies,source_epoch,semantic_epoch,source_guard,check,limits=None):
    def action(x,w):
        c=_rebuild(x['family'],x['certified_dependencies'],x['source_epoch'],x['semantic_epoch'],w,set())
        return dict(status='ELIGIBLE_CERTIFICATE',reason=None,certificate=c,ground_correspondence=None)
    return _run('certify_family',dict(family=family,certified_dependencies=certified_dependencies,
        source_epoch=source_epoch,semantic_epoch=semantic_epoch),check,source_guard,limits,action)


def revalidate_certificate(*,certificate,source_epoch,semantic_epoch,source_guard,check,limits=None):
    def action(x,w):
        c=_revalidate(x['certificate'],x['source_epoch'],x['semantic_epoch'],w,set())
        return dict(status='ELIGIBLE_CERTIFICATE',reason=None,certificate=c,ground_correspondence=None)
    return _run('revalidate_certificate',dict(certificate=certificate,source_epoch=source_epoch,
        semantic_epoch=semantic_epoch),check,source_guard,limits,action)


def check_ground_instance(*,certificate,arguments,ground_definition,dependency_definitions,
                          source_epoch,semantic_epoch,source_guard,formula_validator,check,limits=None):
    """dependency_definitions is the FULL original registry including the root.

    The syntax-only validator is caller-authenticated and must return bool;
    it is never treated as proof authority. All callbacks/errors propagate.
    No production gate consumes this Source-only correspondence result.
    """
    if not callable(formula_validator):raise TypeError('authenticated syntax-only formula validator required')
    def action(x,w):
        c=_revalidate(x['certificate'],x['source_epoch'],x['semantic_epoch'],w,set())
        root,records=_ground_records(c,x['arguments'],w,formula_validator)
        if type(x['ground_definition']) is not dict or x['ground_definition'].get('name')!=root:w.reject('bound original ground identity')
        closure=_registry(x['ground_definition'],x['dependency_definitions'],records,w)
        expanded=_flatten(root,records,w,formula_validator)
        result=dict(schema=GROUND_SCHEMA,version=VERSION,root_name=root,
            arguments=x['arguments'],ground_definition=records[root],original_ordered_closure=closure,
            primitive_expansion=expanded,full_registry_preserved=True,
            scope='Only exact required closure correspondence checked here; unrelated original registry entries are retained unchanged, not certified by this result.',
            authority=dict(AUTHORITY))
        return dict(status='GROUND_CORRESPONDENCE',reason=None,certificate=c,ground_correspondence=result)
    return _run('check_ground_instance',dict(certificate=certificate,arguments=arguments,
        ground_definition=ground_definition,dependency_definitions=dependency_definitions,
        source_epoch=source_epoch,semantic_epoch=semantic_epoch),check,source_guard,limits,action)
