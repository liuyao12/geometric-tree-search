"""Publish only saved-data presentation and raw bytes. Never evaluate research code."""
from pathlib import Path
import hashlib
import html
import json
import zipfile

D = Path('/private/tmp/gcts-cadence-integration-ROOT-20261019')
L = Path('/private/tmp/gcts-cadence-integration-library-20261019')
C = Path('/private/tmp/gcts-cadence-integration-peer-20261019')
DI = Path('/private/tmp/gcts-inverse-cadence-ROOT-20261019')
PUB = Path('/private/tmp/gcts-split-controls-publish-20261015')
WEB = PUB / 'docs/research/gcts-rl-renewal/conditional-inventory'
OUT = D / 'publication-v1'

def pin(p):
    p = Path(p).resolve()
    b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())

def write(name, value):
    p = OUT / name
    p.write_text(json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n')
    return pin(p)

def m(s):
    return r'\(' + str(s) + r'\)'

def num(v):
    return m(format(v, ',').replace(',', r'\,'))

def sec(v):
    return m(f'{v:.3f}' + r'\,\mathrm{s}')

def packet(v):
    return '<pre>' + html.escape(json.dumps(v, sort_keys=True, indent=2, allow_nan=False)) + '</pre>'

peer = json.loads((C / 'typed-saved-actual-review-v1.json').read_bytes())
audit = json.loads((D / 'ROOT-saved-actual-audit-v1.json').read_bytes())
timing = json.loads((D / 'ROOT-saved-timing-and-local-diagnostics-v1.json').read_bytes())
closure = json.loads((D / 'runtime-closure-v1.json').read_bytes())
DESIGN = Path('/private/tmp/gcts-owned-finalization-next-design-library-20261019')
design_path = DESIGN / 'ownnext-design-v1.json'
design = json.loads(design_path.read_bytes())
assert peer['saved_review_passed'] is True
assert peer['actual_qualification_passed'] is False
assert all(r['mathematical_proof_admitted'] is False and r['resource_admitted'] is False for r in peer['arms'])
assert peer['mismatch_count'] == 0
OUT.mkdir()
summary = dict(
    schema='cadence-integration-published-negative-outcome-v1',
    outcome='BOTH_FULL_SAVED_INVERSE_WORK_DEADLINE_FAILURES',
    mathematical_proof_admitted=False, resource_admitted=False,
    new_theorems=0, causal_speed_claim=False, RL_training_claim=False,
    broad_research_goal_complete=False,
    independent_saved_review=peer, Root_saved_audit=audit,
    saved_timing_diagnostics=timing, next_design=pin(design_path),
    current_master_reconciliation=json.loads((D / 'ROOT-current-master-reconciliation-v1.json').read_bytes()),
    plan_invariance=json.loads((D / 'ROOT-mathematical-input-invariance-v1.json').read_bytes()),
    source_only_next_step=True, no_new_execution_authorization=True,
)
write('cadence-integration-summary.json', summary)
(OUT / 'cadence-integration-next-design.json').write_bytes(design_path.read_bytes())

rows = []
bars = []
raws = []
stage_rows = []
for r, t in zip(peer['arms'], timing['arms']):
    assert r['mode'] == t['mode']
    mode = r['mode']
    where = 'Document streaming' if mode == 'fixed' else 'Forest preparation / cache building'
    rows.append('<tr><th>' + ('Fixed GCTS' if mode == 'fixed' else 'Symbolic control') + '</th><td>' + sec(t['scientific_stop_seconds']) + '</td><td>' + sec(r['runner_clock_elapsed_seconds']) + '</td><td>' + where + '</td><td>Failed · no admission</td></tr>')
    # Geometry is only a presentation of saved timestamps, not a scientific execution.
    fraction = 100 * t['scientific_stop_seconds'] / 210
    until = 100 * (180 - t['scientific_stop_seconds']) / 210
    terminal = 100 * r['runner_clock_elapsed_seconds'] / 210
    bars.append('<div class="timeline-row"><b>' + ('Fixed GCTS' if mode == 'fixed' else 'Symbolic control') + '</b><div class="timeline-track" aria-label="Scientific stop then unpartitioned evidence and incomplete inverse"><span class="scientific" style="width:' + f'{fraction:.6f}' + '%"></span><span class="evidence-cost" style="width:' + f'{until:.6f}' + '%"></span><i class="work-limit"></i><i class="terminal" style="left:' + f'{terminal:.6f}' + '%"></i></div><p>Scientific stop ' + sec(t['scientific_stop_seconds']) + '; terminal ' + sec(r['runner_clock_elapsed_seconds']) + '. Last location: ' + where.lower() + '.</p></div>')
    raws.append('<details class="raw-arm" id="raw-' + mode + '"><summary>' + ('Fixed GCTS' if mode == 'fixed' else 'Symbolic control') + ' · complete saved audit packet</summary>' + packet(r) + '</details>')
    durations = {s['stage']: s['stop'] - s['start'] for s in t['driver_stages']}
    stage_rows.append('<tr><th>' + mode + '</th><td>' + sec(durations['compile']) + '</td><td>' + sec(durations['inventory_record_join']) + '</td><td>' + sec(durations['search']) + '</td><td>' + sec(durations['final_native']) + '</td><td>' + num(t['logical_bytes']) + '</td><td>' + num(t['forest_bytes']) + '</td></tr>')

base = (WEB / 'inverse-cadence.html').read_text()
head = base.split('<head>', 1)[1].split('<style>', 1)[0]
head = head.replace('<title>Inverse callback qualification — GCTS research</title>', '<title>Fresh full-pipeline deadline outcomes — GCTS research</title>')
style = base.split('<style>', 1)[1].split('</style>', 1)[0]
page = '''<!doctype html><html lang="en"><head>''' + head + '''<style>''' + style + '''
.status-failed{color:#933b2c}.timeline-row{margin:28px 0}.timeline-track{position:relative;display:flex;height:35px;background:#e7eded;border:1px solid var(--line);margin:10px 0}.timeline-track span{display:block}.scientific{background:#2e7e83}.evidence-cost{background:repeating-linear-gradient(135deg,#ddba7d,#ddba7d 8px,#efd4a7 8px,#efd4a7 16px)}.work-limit{position:absolute;left:85.714286%;height:53px;top:-9px;border-left:2px dashed #873c31}.terminal{position:absolute;top:-4px;height:43px;border-left:3px solid #512c25}.timeline-row p{font-size:14px}.legend-line{display:flex;flex-wrap:wrap;gap:18px;font-size:14px}.swatch{display:inline-block;width:18px;height:12px;margin-right:6px}.raw-arm{padding:16px;background:white;border:1px solid var(--line)}.small-table{min-width:780px}.history{border-left:5px solid var(--purple);padding:18px 24px;background:#eee9f5}.audit-count{font-size:30px;font-weight:700}section{scroll-margin-top:24px}
</style></head><body><main><nav><a href="reader.html#cadence-integration">Research notebook</a><a href="#outcome">Current outcome</a><a href="#timeline">Where time went</a><a href="#next">Next measurement</a><a href="#records">Saved records</a><a href="owned-evidence.html#proof">Earlier admitted proof</a></nav>
<p class="eyebrow">19 October 2026 · Fresh matched inputs · Two retained negative outcomes</p><h1>Both fresh full runs miss the evidence-checking deadline.</h1><p class="lead">The qualified inverse is now integrated. Each arm finds a locally accepted proof, but neither completes the enclosing reconstruction and admission checks.</p><p class="boundary">These are failed full-pipeline attempts. No new theorem, resource-qualified result, RL improvement or GCTS advantage is established. The earlier standalone inverse qualification and earlier admitted symbolic proof retain their separate statuses.</p>
<section id="outcome"><h2>The complete result determines success.</h2><div class="cards"><article><b class="status-failed">Fixed GCTS · failed</b><p>Deadline reached while streaming the saved evidence document. The process closes with no final worker header and no complete independent reconstruction.</p></article><article><b class="status-failed">Symbolic control · failed</b><p>Deadline reached during forest preparation and cache building. Its local Native proof is also diagnostic; it does not bypass the same full evidence checks.</p></article></div><div class="table-wrap"><table class="small-table"><thead><tr><th>Current arm</th><th>Scientific stop</th><th>External terminal</th><th>Retained traceback location</th><th>Full outcome</th></tr></thead><tbody>''' + ''.join(rows) + '''</tbody><caption>Times are relative to the outer runner's Source-entry monotonic clock. A traceback identifies where the deadline was detected; it supplies no complete inverse duration or operation count.</caption></table></div><p>Both local ordinary result packets report <code>native_proof_discovered</code> and <code>native_proof_accepted: true</code>. Each retains ''' + num(16) + ''' completed Native records including the final request. The enclosing cold gate failed, so both mathematical and resource admissions are false. This is an experiment-admission failure; it does not assert that the saved local derivations are logically false.</p></section>
<section id="timeline"><h2>Measure the evidence path before optimizing it.</h2><p>The driver records scientific stop at ''' + sec(timing['arms'][0]['scientific_stop_seconds']) + ''' and ''' + sec(timing['arms'][1]['scientific_stop_seconds']) + '''. The Native oracle closes shortly afterwards. The subsequent interval includes evidence assembly, sealing, export, boundary checks and the incomplete inverse. Its internal costs were not separately retained.</p>''' + ''.join(bars) + '''<div class="legend-line"><span><i class="swatch scientific"></i>Through scientific stop</span><span><i class="swatch evidence-cost"></i>Unpartitioned evidence path and incomplete inverse</span><span>Dashed line: ''' + m(r'180\,\mathrm{s}') + ''' worker deadline</span><span>Track end: ''' + m(r'210\,\mathrm{s}') + ''' external deadline</span></div><p class="note">The striped segment ends at the worker deadline for readability; the dark marker gives actual terminal time. It must not be read as a measurement of inverse time alone. Neither current failure retains inverse counters, callback counts, a completed comparison, or final Arena/adapter work statistics.</p><details id="stage-details"><summary>Inspect the retained driver stage durations and output sizes</summary><div class="table-wrap"><table><thead><tr><th>Arm</th><th>Compile</th><th>Inventory record join</th><th>Search</th><th>Final Native</th><th>Ordinary result bytes</th><th>Forest bytes</th></tr></thead><tbody>''' + ''.join(stage_rows) + '''</tbody><caption>Diagnostic stage observations within two failed full runs. They are not a causal speed comparison; these selected intervals do not partition the whole job. “Compile” is the driver's recorded logical compilation phase.</caption></table></div></details></section>
<section id="limits"><h2>Same assertion, inventory, search rules and limits.</h2><p>Both arms use the original assertion ''' + m(r'a=b,\;P(a)\vdash P(b)') + ''', the same mathematical inputs and the same inventory of ''' + num(4) + ''' families / ''' + num(10) + ''' ground entries. No proof route is supplied. The only component change is binding the already qualified inverse successor; scientific search and Native validation bodies remain unchanged.</p><p>The inherited full-pipeline work boundary is ''' + m(r'180\,\mathrm{s}') + ''' for worker positive work, ordinary-result reading and known worker exit. Later outer metadata, resource, custody, process-group and EOF joins, plus external terminal, have ''' + m(r'210\,\mathrm{s}') + '''. Closing below the latter limit cannot admit failed work. Both workers exit with failure, both outer runners report failure, all Native children and owned worker groups close, and captured logs reach EOF.</p><p>The conservative separate worker-plus-Native highwater sums are ''' + m(f"{peer['arms'][0]['posthoc_diagnostic_sum_MiB']:.3f}" + r'\,\mathrm{MiB}') + ''' and ''' + m(f"{peer['arms'][1]['posthoc_diagnostic_sum_MiB']:.3f}" + r'\,\mathrm{MiB}') + '''. These are posthoc diagnostics, neither simultaneous live RAM peaks nor admitted resource aggregates. The accepted aggregate is <code>null</code> in both runner receipts. The original ''' + m(r'1\,\mathrm{GiB}') + ''' sum threshold, ''' + m(r'128\,\mathrm{MiB}') + ''' logical/physical output limits, ''' + m(r'4\,\mathrm{MiB}') + ''' log limits and operation caps were not raised.</p><p class="note">Inverse cap: ''' + num(30000000) + ''' attempted operations per fresh state. Arena and adapter each retain their separate ''' + num(400000000) + ''' work-unit caps; these are distinct counters. The outer wrapper does not implement a continuous live RSS bound. Runtime/observer startup prelude and outer/observer RAM exclusions remain the retained instrument scope.</p><details><summary>Contract reference correction</summary><p>The earlier archived master was stale. Before these actuals, Root, implementation and review reread the current master, ''' + num(36240) + ''' bytes, SHA-256 <code>ca6ee206287bf18b69f88a35d30968312499567755f347a819af4cf49743e7d4</code>. Its core point/frontier/rollback rules are unchanged; updated marking-learning and implementation-audit instructions were reconciled. This inverse binding does not add new learned markings or change mathematical bodies. The raw difference and reconciliation records are archived. This does not establish general engine conformance.</p></details></section>
<section id="parallel"><h2>Parallel work supplies distinct checks.</h2><div class="time-legend"><article><b>Implementation agent</b><p>Bound the qualified inverse into the cold worker with four constant-only changes; then inspected the evidence path as Source and saved data.</p></article><article><b>Review agent</b><p>Reviewed the component, wrapper, plan and grants before execution, then independently checked the retained negative records: ''' + num(peer['check_count']) + ''' checks, no mismatches.</p></article><article><b>Root</b><p>Froze inputs and limits, ran the two arms serially while other agents stopped tools, joined the saved outcomes and prepared the report. Parallel agent activity was kept outside the timed windows.</p></article></div><p class="note">The same reviewer covers several review roles and authored some historical helper/control algorithms. Those overlaps are disclosed in the receipts. Saved-record consistency is not a fresh independent proof of historical kernel soundness.</p></section>
<section id="next"><h2>The next change is measurement.</h2><p>Record bounded, failure-safe phase boundaries for driver return, assembly/export/sealing, inverse preparation, streaming and complete comparison, retaining a small diagnostic packet even on deadline. Charge that instrumentation and its output to the same original limits. This is a design proposal; it has not been implemented, qualified or executed.</p><p>The Arena already batches guard checks by weighted work; the adapter also checks a cumulative threshold. We should measure those costs before changing another cadence. Neither current arm retains the counters needed to attribute the timeout to either component. Historical successful counters cannot fill that gap.</p><p><a href="cadence-integration-next-design.json">Read the exact Source-only measurement design</a>. After implementation and review, use a new bounded subject rather than rerunning either consumed plan. Keep full evidence, point and Native checks; do not trim records or raise caps to turn failure into success.</p><p>Broader theorem benchmarks remain the research objective. We still need held-out assertions and conventional controls to establish whether GCTS markings, reusable receptor families or RL produce useful automated search behavior.</p></section>
<section id="history"><h2>Earlier evidence remains available.</h2><div class="history"><p><a href="inverse-cadence.html#outcome">Standalone inverse qualification</a>: the successor reconstructs both earlier complete saved forests and passes its finite diagnostics. That component success predicts no full-pipeline result.</p><p><a href="owned-evidence.html#proof">Earlier admitted symbolic proof, line by line</a>: formulas, English, raw steps and five proof blocks for the original assertion. The earlier fixed failure remains in the same historical report. Neither old result is relabeled by these two fresh failures.</p></div></section>
<section id="records"><h2>Inspect and reproduce the record.</h2><p><a href="cadence-integration-summary.json">Complete outcome, audits and timing metadata</a> · <a href="cadence-integration-manifest.json">Archive manifest</a> · <a href="cadence-integration-archive.zip">Full raw evidence, Sources, plans and reviews</a> · <a href="cadence-integration-next-design.json">Next measurement design</a></p><p>Expand either arm below for its literal independent saved audit packet. Complete ordinary results, forests, failure traces, consumed plans and terminal receipts are in the archive. No inverse or scientific component was replayed for this presentation.</p>''' + ''.join(raws) + '''<p class="note">The returned adapter-diagnostic aggregate stage is retained. Completion of its five groups and eight fresh Stores follows from reviewed Source; individual group packets are absent because neither final worker header was emitted. Source-backed inference and literal retained evidence are distinct.</p><p class="note">Raw Native payloads remain opaque: this reporting step does not decode or evaluate them. Python, OS, Z3 and prebuilt Native executable dependencies are external pinned prerequisites. Archived grants are consumed historical once-only records, not permission to replay them.</p></section><footer>Research program active. Engineering progress: a frozen negative result and a concrete measurement design. No full-program completion claim.</footer></main></body></html>'''
(OUT / 'cadence-integration.html').write_text(page)

# A raw snapshot; do not include generated publication bytes recursively.
members = []
for prefix, folder in [('ROOT', D), ('library', L), ('peer', C), ('next-design', DESIGN)]:
    for p in sorted(folder.rglob('*')):
        if not p.is_file() or OUT in p.parents:
            continue
        assert p.suffix in ('.json', '.py', '.patch', '.bin', '.md')
        members.append((prefix + '/' + str(p.relative_to(folder)), p))

# All current scientific Source files, plus schema/Native Source. Dependencies
# that are platform executable/library files are pinned externally, not copied.
source_descriptors = []
for key in ('materialized_aliases', 'schema_sources', 'fixed_native_inputs', 'native_CPP', 'evidence_sources'):
    source_descriptors.extend(v for v in closure[key].values() if isinstance(v, dict) and 'path' in v and 'sha256' in v)
source_descriptors.append(closure['schema_kernel_source'])
seen = set()
for row in source_descriptors:
    p = Path(row['path'])
    actual = pin(p)
    assert actual == {k: row[k] for k in ('path', 'bytes', 'sha256')}
    if str(p) in seen:
        continue
    if p.suffix not in ('.py', '.tree', '.cpp', '.json', '.gz'):
        continue
    seen.add(str(p))
    members.append(('sources/' + str(len(seen)).zfill(2) + '-' + p.name, p))
members.extend([
    ('prerequisite/ROOT-inverse-qualification-milestone.json', DI / 'ROOT-final-milestone-v1.json'),
    ('prerequisite/independent-inverse-qualification-review.json', Path('/private/tmp/gcts-inverse-cadence-peer-20261019/typed-saved-qualification-review-v1.json')),
    ('prerequisite/historical-integration-saved-review.json', Path('/private/tmp/gcts-owned-evidence-integration-peer-20261019/typed-owned-integration-saved-review-v1.json')),
])
assert len(set(n for n, p in members)) == len(members)
manifest = [dict(member=n, original=pin(p)) for n, p in members]
with zipfile.ZipFile(OUT / 'cadence-integration-archive.zip', 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for n, p in members:
        z.writestr(n, p.read_bytes())
write('cadence-integration-manifest.json', dict(
    schema='cadence-integration-raw-archive-manifest-v1',
    archive=pin(OUT / 'cadence-integration-archive.zip'),
    members=manifest, all_originals_raw=True, scientific_evaluations=0,
    external_prerequisites='Pinned Python/OS/Z3/prebuilt Native dependencies remain external; closure descriptors retain exact hashes.',
))
with zipfile.ZipFile(OUT / 'cadence-integration-archive.zip') as z:
    assert z.namelist() == [r['member'] for r in manifest]
    for r in manifest:
        b = z.read(r['member'])
        assert len(b) == r['original']['bytes']
        assert hashlib.sha256(b).hexdigest() == r['original']['sha256']

aside = '<aside id="cadence-integration-follow-up" class="boundary"><b>Fresh full-pipeline follow-up:</b> Both new arms hit the full evidence-reconstruction work deadline. Neither is admitted. The standalone qualification below remains valid. <a href="cadence-integration.html?v=20261019-ci1#outcome">Read the retained outcomes and next measurement</a>.</aside>'
assert base.count('<section id="outcome">') == 1
(OUT / 'inverse-cadence.html').write_text(base.replace('<section id="outcome">', aside + '\n<section id="outcome">', 1))
reader = (WEB / 'reader.html').read_text()
marker = '<section id="inverse-cadence">'
section = '<section id="cadence-integration"><p class="eyebrow">19 OCTOBER 2026 · FRESH FULL PIPELINE</p><h2>Both new arms miss the full evidence deadline.</h2><p>The qualified inverse is integrated, but both complete runs remain unqualified. The saved local Native proofs are diagnostic; earlier outcomes retain their separate statuses. <a href="cadence-integration.html?v=20261019-ci1#outcome"><b>Read both negative outcomes</b></a> · <a href="cadence-integration.html?v=20261019-ci1#timeline">Inspect the timing gap</a> · <a href="cadence-integration.html?v=20261019-ci1#next">Next measurement</a>.</p></section>'
assert reader.count(marker) == 1
(OUT / 'reader.html').write_text(reader.replace(marker, section + marker, 1))
assert (OUT / 'inverse-cadence.html').read_text().replace(aside + '\n', '', 1) == base
assert (OUT / 'reader.html').read_text().replace(section, '', 1) == reader
candidate = dict(
    schema='cadence-integration-publication-candidate-v1', files=[pin(p) for p in sorted(OUT.iterdir())],
    archive_members=len(manifest), mathematical_admission=False, resource_admission=False,
    baseline_HEAD='fa2c42742e49ae4f2c7ad1f56d57e1ce7ef8532d',
    existing_changes='One exact removable link/status addition each to inverse-cadence.html and reader.html.',
    protected_overview_changed=False, primary_checkout_read_or_written=False,
    scientific_evaluations=0, no_new_execution_authorization=True,
)
p = D / 'publication-candidate-v1.json'
p.write_text(json.dumps(candidate, sort_keys=True, indent=2) + '\n')
print(json.dumps(pin(p), sort_keys=True))
