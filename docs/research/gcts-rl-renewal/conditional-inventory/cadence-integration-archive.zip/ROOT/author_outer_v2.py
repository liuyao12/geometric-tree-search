"""Raw Source-only pin/version successor; never evaluates scientific components."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import sys
D=Path('/private/tmp/gcts-cadence-integration-ROOT-20261019')
P=Path('/private/tmp/gcts-owned-evidence-integration-ROOT-20261019')
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
assert len(sys.argv)==2,'frozen coldV4 Source path only'
cold=pin(sys.argv[1]);old=P/'owned_evidence_once_runner_v1.py';s=old.read_text()
assert pin(old)['sha256']=='ecf8bfcc34fad0cc87af0c9dc1147e80fe5b08188ac3a10b308b8b8b1ed05497'
node=next(n for n in ast.parse(s).body if type(n)is ast.Assign and any(type(t)is ast.Name and t.id=='COLD_PIN'for t in n.targets))
lines=s.splitlines(True);before=''.join(lines[node.lineno-1:node.end_lineno]);replacement='COLD_PIN = '+repr(cold)+'\n'
assert s.count(before)==1
s=s.replace(before,replacement,1).replace("VERSION = 'owned-evidence-external-once-runner-v1'", "VERSION = 'owned-evidence-external-once-runner-v2-cadence'")
dest=D/'owned_evidence_once_runner_v2.py';assert not dest.exists();ast.parse(s);compile(s,str(dest),'exec');dest.write_text(s)
observer=P/'observe_owned_evidence_runner_v1.py';t=observer.read_text()
assert pin(observer)['sha256']=='474550a70dbe13b7a7ca86dd765be78e0e5bf811fbdbc786a6c89e8344e3fe1c'
t=t.replace('owned-evidence-final-terminal-observer-v1','owned-evidence-final-terminal-observer-v2-cadence')
t=t.replace(pin(old)['sha256'],pin(dest)['sha256'])
out=D/'observe_owned_evidence_runner_v2.py';assert not out.exists();ast.parse(t);compile(t,str(out),'exec');out.write_text(t)
patch=''.join(difflib.unified_diff(old.read_text().splitlines(True),s.splitlines(True),fromfile=str(old),tofile=str(dest)))
(D/'outer-v1-v2.patch').write_text(patch)
patch=''.join(difflib.unified_diff(observer.read_text().splitlines(True),t.splitlines(True),fromfile=str(observer),tofile=str(out)))
(D/'observer-v1-v2.patch').write_text(patch)
v=dict(schema='ROOT-cadence-integration-outer-Source-contract-v1',author_identity='/root',source_only=True,
 sources=dict(runner=pin(dest),observer=pin(out)),parents=dict(runner=pin(old),observer=pin(observer)),cold=cold,
 changes='Only each ownVERSION and current downstream raw Source pin. All callables/bodies, schemas, numeric caps, reviewroles, exactly-once markers, transport/cleanup and success/resource checks unchanged.',
 inherited_scope='Same exact full pipeline parent Source-entry clock, worker work/resultreading+knownexit before180s; complete outer resource/custody/EOF/group/metadata and external terminal before210s. No Source/cold callable seal is weakened. No live-group RAM hard-enforcement claim.',
 mathematical_changes=False,scientific_calls=0,component_evaluations=0,actual_execution_authorized=False,scientific_acceptance=False,
 pending=['Independent Source and exact current common-profile plans review','Fresh Root maximum-one subject grants and finaldelta/freshness review','All peers idle during each serial bounded actual','Full saved Native/point/inverse/reader/currentSource/resource/terminal evidence admission'],goal_complete=False)
p=D/'outer-Source-contract-v1.json';p.write_text(json.dumps(v,sort_keys=True,indent=2)+'\n');print(json.dumps(pin(p),sort_keys=True))
