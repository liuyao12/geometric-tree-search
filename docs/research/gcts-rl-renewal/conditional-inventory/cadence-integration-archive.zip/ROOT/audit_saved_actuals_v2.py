"""Saved ordinary metadata checks only. No module, inverse, Model or proof replay."""
from pathlib import Path
import hashlib,json
D=Path('/private/tmp/gcts-cadence-integration-ROOT-20261019')
def read(p):return json.loads(Path(p).read_bytes())
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def checked(desc):
 assert pin(desc['path'])==desc;return read(desc['path'])
adopt=read(D/'ROOT-scope-adoption-and-grants-v1.json');rows=[]
for arm in adopt['plans']:
 plan=checked(arm['once_plan']);actual=Path(plan['actual_directory']);tp=Path(arm['once_plan']['path']);terminal=read(tp.parent/(tp.stem+'-terminal-observation')/'terminal.json')
 rr=checked(terminal['runner_receipt']) if 'runner_receipt'in terminal else None
 row=dict(mode=arm['mode'],once_plan=arm['once_plan'],terminal=pin(tp.parent/(tp.stem+'-terminal-observation')/'terminal.json'),ROOT_resource_accepted=False,ROOT_mathematical_proof_admitted=False,scientific_acceptance=False)
 if rr is not None:
  assert rr['plan']==arm['once_plan'] and rr['subject_sha256']==arm['subject_sha256']
  row.update(runner_receipt=terminal['runner_receipt'],resource_candidate=rr['resource_candidate_accepted'],worker_exit_code=rr['python_exit_code'],outer_exit_code=terminal['runner_exit_code'],group_absent=rr['owned_group_absent'],logs_complete=rr['log_capture_complete'],elapsed_seconds=(terminal['terminal_observed_ns']-rr['began_ns'])/1e9,aggregate_peak_bytes=rr['conservative_parent_plus_native_peak_bytes'],errors=rr['errors'],outputs=rr['outputs'])
  for key in ['result','evidence_forest','worker_receipt','stdout','stderr']:
   desc=rr['outputs'].get(key)
   if desc is not None:assert pin(desc['path'])==desc
  w=rr['worker_receipt'];positive=rr['resource_candidate_accepted'] is True and terminal['terminal_gate_passed'] is True
  if positive:
   assert rr['python_reaped']is True and rr['python_exit_code']==0 and rr['owned_group_absent']is True and rr['stdout_eof']is True and rr['stderr_eof']is True and rr['log_capture_complete']is True
   assert rr['worker_terminal_observed_ns']<rr['work_deadline_ns'] and terminal['terminal_observed_ns']<rr['overall_deadline_ns']
   assert rr['conservative_parent_plus_native_peak_bytes']<=1073741824 and rr['outputs']['physical_output_budget']['conservative_physical_bytes']<=134217728
   assert w['work_completed']is True and w['evidence_verification']['status']=='COMPLETE' and w['evidence_verification']['completed_ns']<rr['work_deadline_ns']
   assert w['result_reading']['roundtrip']['literal_bytes_equal']is True and w['result_reading']['completed_ns']<rr['work_deadline_ns']
   verification=w['evidence_verification'];stats=verification['statistics']
   assert verification['declaration']['version']=='independent-evidence-forest-inverse-v7-bounded-callback-cadence'
   assert verification['declaration']['execution_profile']==stats['execution_profile']=='independent-forest-actual-operations-v2-callback-cadence1024'
   assert stats['callback_cadence_operations']==1024 and stats['maximum_callback_operation_gap']<=1024 and stats['pending_callback_operations']==0
   assert sum(stats['operations_by_kind'].values())==stats['attempted_operations']<=30000000
   assert sum(stats['callback_dispatches_by_reason'].values())==stats['callback_dispatches']
   assert stats['last_callback_operation']==stats['attempted_operations']
   assert w['adapter_diagnostics']['status']=='COMPLETE' and len(w['adapter_diagnostics']['groups'])==5
   row.update(inverse_execution_profile=stats['execution_profile'],inverse_attempted_operations=stats['attempted_operations'],inverse_callback_dispatches=stats['callback_dispatches'],inverse_elapsed_seconds=(verification['completed_ns']-verification['started_ns'])/1e9,outer_checks_closed_seconds=(rr['checks_closed_ns']-rr['began_ns'])/1e9)
   native=w['native_transport'];assert native['closed']is True and native['all_reaped']is True and native['native_exit_code']==0
   row['ROOT_resource_accepted']=True
   if w['logical_proof_accepted']is True:
    assert rr['logical_proof_transport_candidate']is True and w['final_region_verification']['status']=='VERIFIED_WHOLE_FINITE_POINT_REGION'
    row['ROOT_mathematical_proof_admitted']=True
   row.update(worker_status=w['status'],schema_inventory_admitted=w['schema_inventory_admitted'],fresh_independent_inverse_completed=True,evidence_verification=w['evidence_verification'],evidence_statistics=w['evidence_statistics'],physical_output_ledger=w['owned_output_ledger'],adapter_diagnostics=w['adapter_diagnostics'],final_region_verification=w['final_region_verification'])
  failure=actual/'worker-failure.json'
  if failure.exists():row['worker_failure']=read(failure);row['worker_failure_descriptor']=pin(failure)
 rows.append(row)
v=dict(schema='ROOT-cadence-integration-saved-actual-audit-v1',author_identity='/root',saved_data_only=True,scientific_calls=0,component_imports=0,mathematical_replay=False,goal_complete=False,clock_scope='Inherited worker positive work, full resultreading+knownexit180; subsequent outer metadata/resource joins+terminal210. No all-outer-check180 guarantee.',historical_fixed_integration_admitted=False,new_RL_training=False,GCTS_RL_advantage_established=False,causal_speed_claim=False,scope='Raw saved receipts/pins and exact existing Native/point/resource evidence adoption only, within inherited trust/Source review scopes; no new theorem, blind generalization, search/RL or cost advantage.',arms=rows)
p=D/'ROOT-saved-actual-audit-v1.json';assert not p.exists();p.write_text(json.dumps(v,sort_keys=True,indent=2,allow_nan=False)+'\n')
print(json.dumps(pin(p)))
for a in rows:print(json.dumps({k:x for k,x in a.items() if k in ('mode','worker_exit_code','outer_exit_code','elapsed_seconds','aggregate_peak_bytes','ROOT_resource_accepted','ROOT_mathematical_proof_admitted','worker_status','errors')},indent=2))
