"""Saved ordinary JSON/Source metadata analysis only; never a component call."""
from pathlib import Path
from decimal import Decimal
import ast
import hashlib
import json

L=Path(__file__).parent
R=Path('/private/tmp/gcts-cadence-integration-ROOT-20261019')
OLD=Path('/private/tmp/gcts-owned-evidence-integration-ROOT-20261019')
def pin(p):
    p=Path(p);h=hashlib.sha256();size=0
    with p.open('rb')as f:
        while True:
            b=f.read(1048576)
            if not b:break
            h.update(b);size+=len(b)
    return dict(path=str(p),sha256=h.hexdigest(),bytes=size)
def load(p):return json.loads(Path(p).read_text())
def delta(a,b):return float(Decimal(str(b))-Decimal(str(a)))
def save(name,value):
    p=L/name;assert not p.exists()
    p.write_text(json.dumps(value,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
    return pin(p)

audit_path=R/'ROOT-saved-actual-audit-v1.json';audit=load(audit_path)
assert pin(audit_path)==dict(path=str(audit_path),sha256='08d0dace08316e5c78297a718b59470f7dd7ff7b346a281368fa774a6cf4efab',bytes=65904)
master=R/'basic-tiling-algorithm-HEAD.md'
assert pin(master)['sha256']=='ca6ee206287bf18b69f88a35d30968312499567755f347a819af4cf49743e7d4'
source_paths=dict(
    cold=Path('/private/tmp/gcts-cadence-integration-library-20261019/owned_evidence_cold_v4.py'),
    arena=Path('/private/tmp/gcts-direct-reconcile-library-20261019/exact_evidence_arena_v3.py'),
    adapter=OLD/'owned_evidence_adapter_v3.py',
    driver=OLD/'owned_evidence_receiver_driver_v4.py',
    inverse=Path('/private/tmp/gcts-inverse-cadence-ROOT-20261019/independent_forest_inverse_v7.py'))
citations=[]
for role,p in source_paths.items():
    text=p.read_text();tree=ast.parse(text)
    wanted={'cold':{'verify_saved_evidence','source_guard','main'},
        'arena':{'_step','_finish','_read','_cache','_Transaction','capture','seal','to_wire','statistics'},
        'adapter':{'_step','_finish','_capture','_canonical','assemble','_view','statistics'},
        'driver':{'check','_owned_store','_owned_atomic_output','_atomic_owned_stream','run_receiver_owned'},
        'inverse':{'tick','dispatch','prepare_forest'}}[role]
    for n in ast.walk(tree):
        if isinstance(n,(ast.FunctionDef,ast.ClassDef))and n.name in wanted:
            citations.append(dict(role=role,source=pin(p),symbol=n.name,line=n.lineno,end_line=n.end_lineno))

arms=[];rawpins=[pin(audit_path)];checks=[]
for mode in ('fixed','symbolic'):
    A=R/('actual-'+mode+'-v1');r=load(A/'result.json');failure=load(A/'worker-failure.json')
    marker=load(A/'CONSUMED.json');runner=load(A/'runner-receipt.json')
    root=next(v for v in audit['arms']if v['mode']==mode)
    assert root['ROOT_mathematical_proof_admitted']is False and root['ROOT_resource_accepted']is False
    assert root['worker_exit_code']==1 and root['outer_exit_code']==2
    assert failure['error_type']=='ColdError'and failure['message']=='full saved evidence inverse within original work'
    assert failure['owned_evidence_statistics']is None and not(A/'worker-receipt.json').exists()
    assert failure['complete_output_accepted']is False and failure['retry_authorized']is False
    assert marker['work_deadline_ns']-marker['began_ns']==180000000000
    assert marker['overall_deadline_ns']-marker['began_ns']==210000000000
    trace=(A/'stderr.bin').read_text()
    stage=('DOCUMENT_STREAM'if mode=='fixed'else'PREPARATION_CACHE_BUILD')
    assert ('part=next(source)'in trace if mode=='fixed'else'prepared=inverse.prepare_forest' in trace)
    assert ('self._advance()'in trace if mode=='fixed'else'part=parts.take()'in trace)
    assert 'operation_cadence'in trace
    pins={name:pin(A/name)for name in ('CONSUMED.json','result.json','evidence-forest.json',
        'worker-failure.json','runner-receipt.json','stderr.bin')}
    rawpins.extend(pins.values());start=Decimal(marker['began_ns'])/1000000000
    stop=r['scientific_stopped_monotonic'];closed=r['oracle_closed_monotonic']
    rows=[dict(stage=t['stage'],started_monotonic=t['started_monotonic'],returned_monotonic=t['returned_monotonic'],
               elapsed_seconds=delta(t['started_monotonic'],t['returned_monotonic']))for t in r['stage_intervals']]
    arms.append(dict(mode=mode,Root_admitted=False,resource_admitted=False,
        outer_elapsed_seconds=root['elapsed_seconds'],worker_exit_code=1,outer_exit_code=2,
        root_aggregate_peak_bytes=root['aggregate_peak_bytes'],group_absent=root['group_absent'],logs_complete=root['logs_complete'],
        saved_result_status=r['status'],saved_result_native_candidate=r['native_proof_accepted'],
        saved_result_work_window_complete=r['work_window_complete'],
        cold_whole_point_and_old_reader_completed=False,
        fixed_negative_or_symbolic_negative_preserved=True,
        failure_stage_direct_stderr=stage,failure_type=failure['error_type'],failure_message=failure['message'],
        endpoints=dict(Source_entry_began_ns=marker['began_ns'],work_deadline_ns=marker['work_deadline_ns'],
            overall_deadline_ns=marker['overall_deadline_ns'],scientific_stopped_monotonic=stop,
            oracle_closed_monotonic=closed,worker_terminal_observed_ns=runner['worker_terminal_observed_ns']),
        recorded_scientific_stop_from_entry_seconds=delta(start,stop),
        recorded_oracle_closed_from_entry_seconds=delta(start,closed),
        remaining_work_budget_after_oracle_close_seconds=delta(closed,Decimal(marker['work_deadline_ns'])/1000000000),
        phase_times=rows,source_custody_stats_retained=None,
        arena_adapter_work_or_callback_counts_retained=None,
        driver_returned_timestamp=None,assembly_seconds=None,seal_seconds=None,export_seconds=None,
        ordinary_output_write_seconds=None,inverse_start_timestamp=None,inverse_elapsed_seconds=None,
        inverse_operation_counts_retained=None,
        unavailable_scope='No worker success header, driver output receipt or active inverse observation was retained. Failure owned_evidence_statistics is explicitly null. File modification times are not substituted for monotonic stage timing.',
        raw=pins))
    checks.append(dict(name=mode+'_negative_metadata_scope',passed=True,
        detail='Original status, exit, explicit nulls, absence of success header and ordinary stderr joined; no representation/proof replay.'))

# The historical successful symbolic counters are scoped to that older actual.
old_header=OLD/'actual-symbolic-v1/worker-receipt.json';oh=load(old_header)
historical=dict(source=pin(old_header),scope='Earlier admitted symbolic V6-inverse integration only; not current counts or a matched storage/cadence ablation.',
    arena_work=oh['evidence_statistics']['arena']['counters']['work'],
    adapter_operations=oh['evidence_statistics']['operations'],
    callback_dispatch_counts='Not explicitly recorded by current arena/adapter statistics even in this historical header.',
    oracle_close_to_forest_serialization_start_seconds=delta(oh['driver_output_receipt']['evidence_forest']['serialization_started_monotonic'],
        oh['driver_output_receipt']['evidence_forest']['serialization_started_monotonic']))
# Preserve the already observed historical timing envelope without equating it
# to a new missing phase. Its start is in that same saved ordinary result.
old_result=load(OLD/'actual-symbolic-v1/result.json')
historical['oracle_close_to_forest_serialization_start_seconds']=delta(old_result['oracle_closed_monotonic'],
    oh['driver_output_receipt']['evidence_forest']['serialization_started_monotonic'])
historical['full_ordinary_output_serialization_to_preflight_seconds']=oh['driver_output_receipt']['output']['serialization_to_preflight_seconds']
historical['inverse_seconds']=(oh['evidence_verification']['completed_ns']-oh['evidence_verification']['started_ns'])/1000000000
historical['ordinary_canonical_roundtrip_seconds']=(oh['result_reading']['completed_ns']-oh['result_reading']['decoded_ns'])/1000000000

arena_text=source_paths['arena'].read_text();adapter_text=source_paths['adapter'].read_text()
assert 'while remaining==0 or left>remaining:'in arena_text
assert 'left-=remaining;self._invoke(self._check);remaining=1024'in arena_text
assert "if self._work-self._last_check>=1024:"in adapter_text
assert 'self._last_check=self._work;self._call(self._check)'in adapter_text
checks.extend([
    dict(name='arena_cadence_already_exists',passed=True,detail='Source weighted1024 repeated upfront check loop, not a new missing per-operation batching feature.'),
    dict(name='adapter_threshold_not_strict_gap',passed=True,detail='Source does one check after cumulative threshold; a large charged n can exceed1024 between callbacks.'),
    dict(name='complete_current_stats_not_fabricated',passed=True,detail='Both explicit null statistics and missing headers retained; historical counters never relabeled current.'),
    dict(name='phase_trace_differentiated',passed=True,detail='Fixed stream versus symbolic cache build from complete ordinary stderr, both after full emitted diagnostic files.'),
    dict(name='no_scientific_replay',passed=True,detail='Standard-library ordinary JSON, raw Source AST and hashes only. No codec/Model/Native/inverse function imported or called.')])

note=dict(schema='owned-finalization-next-design-v1',author_identity='/root/conventional_library',
    status='SOURCE_AND_SAVED_METADATA_ONLY_PROPOSED_UNIMPLEMENTED_UNMEASURED',
    source_only=True,saved_data_only=True,scientific_calls=0,scientific_replays=0,
    scientific_acceptance=False,future_execution_authorized=False,
    current_master=pin(master),Root_audit=pin(audit_path),sources={k:pin(v)for k,v in source_paths.items()},
    source_citations=citations,current_arms=arms,historical_context_only=historical,
    conclusions=[
        'Both current invocations failed their original whole180-work profile despite diagnostic Native candidates and full result/forest files. No current full point, old-reader, independent-inverse or resource/proof admission is established.',
        'Fixed reached inverse document streaming; symbolic reached inverse fragment/cache preparation. A qualified inverse-only component did not certify these full producer/consumer lifetimes or leave enough whole-pipeline time.',
        'Most mathematical/search stages ended well before180, but the remaining oracle-close-to-deadline window combines final assembly, reconciliation, seal, export, two writes, custody rereads and partial inverse. None of those current component durations was independently retained.',
        'The prior symbolic successful envelope81.065168s is not a current assembly duration and not a guard-overhead measurement. This new pair has no ordinary-storage arm, balanced repetition or profiler; no causal performance, memory-saving or GCTS/RL claim is supported.',
        'Arena/adapter already batch some clock checks. Repeating the inverse every-operation-to1024 change in those components is not the same available transformation. Full public/completion guards, normalization and validation remain substantial Source cost surfaces but their time shares are unmeasured.'
    ],
    callback_clock_scope=dict(
        arena=dict(existing_policy='Each _step charges all attempted work and per-kind counts; its while loop delegates check for each crossed weighted1024 block, including an initial dispatch. Bulk charges can schedule several callbacks before the corresponding actual copying/scanning work.',
            completion='Every _finish invokes Source guard and check; _read invokes _finish. Those forced boundaries are additional to weighted cadence.',
            quota_order='Work cap is checked after the current dispatch loop in frozen Source; this memo proposes no change to order, units or limits.',
            recorded_dispatch_count=None,latency='No bound on elapsed latency follows from prepaid logical callback blocks.'),
        adapter=dict(existing_policy='Each _step adds n to operations and tests its cap, then invokes check once if cumulative delta>=1024 and resets its last-check marker to current work.',
            caveat='A large n is a single post-charge callback, not a strict maximum1024-operation gap. Tightening it to repeated weighted callbacks can add calls rather than optimize them.',
            completion='Each _finish invokes check, full Source guard, check. Arena callbacks route through the same nonreentrant Store wrapper.',recorded_dispatch_count=None),
        driver=dict(existing_policy='Boundary.check invokes outer tick and clock, and only full=True also invokes full source_guard plus canonical epoch comparison. Store source_guard is explicitly full=True.',
            consequence='Counting weighted checks alone cannot attribute raw Source hashing/callable-seal cost. Forced public/view/completion full checks may dominate or may not; no current duration/call ledger exists.'),
        identity='Actual invoked foreign exception objects, own quota markers, passive-statistics reentrancy and custom-stream completion semantics remain mandatory.'),
    one_recommended_next_design=dict(
        choice='Bounded finalization/callback observability first, with unchanged existing checkpoint policies. Do not pick a new quantum or claim a batching speedup from missing data.',
        status='PROPOSED_NOT_IMPLEMENTED',execution_profile='A separately declared owned-finalization-phase-instrumented-v1 profile if implemented; no inherited timing/fault-ordinal coverage claim.',
        minimal_boundary_changes=[
            'Cold: after driver return retain a bounded owned copy of the existing driver receipt timing/descriptors and passive evidence_statistics for both success and later failure. Current ColdError after inverse cannot carry the discarded receipt statistics, which explains the null failure field.',
            'Driver: an invocation-local ordinary phase ledger around store.assemble(final_result), store.seal, store.wire, forest atomic write and complete ordinary BODY stream/write. Record begin/end/error clock endpoints and passive statistics snapshots; do not add these packets as Arena roots or append fields to an already frozen final document.',
            'Cold: retain start/end/error endpoints and the existing passive inverse observation at fresh forest read/JSON parse, independent prepare, independent document stream, old reader, canonical inverse and final point/receipt checks.',
            'Callback accounting: separate actual fast-check invocations, full Source-guard invocations and public/completion invocations, with full-guard cumulative duration only if captured around existing calls. Do not infer dispatch count from attempted work or introduce additional validation/stream calls to measure it.',
            'Write only bounded out-of-band ordinary metadata for success/failure; include every new byte in the existing physical128MiB ledger and all timing/peak costs in the original invocation. No extra or hidden logical document, root, snapshot authority or cleanup-phase scientific call.'
        ],
        invariants=[
            'Keep every original operation, cap test, exact typed equality, first capture plus direct reconciliation, transaction/sole publication, full catalogue reachability, full logical BODY+oneLF and original output inverse.',
            'Keep all completion/public Source guards and existing fast callback opportunities during this instrumentation step; no hidden batching/coalescing, quota reset, cached result, omitted witness or conditional baseline-only checking.',
            'All phase endpoints must come from the same absolute monotonic epoch. File mtimes and stdout timestamps are not substitutes.',
            'Never let metadata snapshot/write/clock failure mask the original callback/Source/deadline error. Retain only bounded partial phase and counts, never partial proof/Model/resource authority.',
            'Keep the mathematical core, four-family library/ten-ground complete inventory, all Model points/marks/candidates, master global dead/forced/earliest-generation scheduler, fallback and exact rollback unchanged.',
            'Keep original180 scientific work/positive serialization and known worker exit,210 terminal, conservative worker+Native1GiB, physical and expanded128MiB, logs4MiB, and400m/400m/30m private caps.'
        ],
        conditional_callback_candidate='Only after the ledger measures an actual dominating callback cost may a distinct bounded-delegation successor be proposed. It must specify weighted versus call-count cadence, preserve every nondelegated operation/cap/validation, keep forced completion/public Source checks, and name the changed custody/checkpoint profile. Coalescing full guards is not automatically equivalent merely because final bytes match.',
        finite_qualification_requirements=[
            'Independent raw/AST delta review shows all mathematical/validation/scheduler and existing callback calls unchanged in instrumentation, with added metadata bounded and invocation-local.',
            'Finite Source-defined diagnostics must actually reach initial, large bulk-charge, public view, prepublication, seal/export, yielded-last-chunk and trailing completion/failure paths. Test exact RuntimeError,ValueError,StopIteration objects and unexpected earlier own deadlines; no class-only UNKNOWN normalization.',
            'New callback-profile qualification, if later selected, needs explicit counters for first/forced/cadence dispatches, maximum weighted gap where meaningful, and no old ordinal-based test coverage inherited.',
            'Whole fixed and symbolic future controls use the same new instrumentation/representation Sources and original001 full inputs/caps, all conversion/verification costs included. Retain every failure and no same-subject retry. This memo grants no test or actual.',
            'No predicted time fit or improvement. Instrumentation can itself increase time/peak; a new profile result is a descriptive engineering observation, not theorem search/RL advantage.'
        ]),
    master_applicability='Current ca6ee master governs. Its learned-marking/corona/certified-negative provisions are not activated or modified by evidence storage or callback metadata. The theorem-search reduction and specialized symbolic chronology remain explicitly scoped; no new learner or pruning authority is introduced.',
    ancestry='Author of arena, adapter-integration cold/registry and earlier Model/point work; not an independent certificate of those own Sources. Root authored inverse/driver/adapter and actuals; Control separate negative saved-data review is not replaced.',
    limitations=['Current counters/timings marked null are unavailable, not zero and not reconstructed by running anything.',
        'Only ordinary result metadata and raw Source were read; no scientific module, codec, inverse, Native, Model, fixture or renderer was imported/called.',
        'No Source implementation, new grant, actual launch, publication edit or failed-output recovery is authorized or performed.'])
note_pin=save('ownnext-design-v1.json',note)
audit_pin=save('analysis-audit-v1.json',dict(schema='owned-finalization-next-author-analysis-audit-v1',note=note_pin,
    checks=checks,check_count=len(checks),mismatches=0,raw_inputs=rawpins,
    scientific_calls=0,component_imports=0,component_calls=0,existing_artifacts_mutated=False,
    independence='Descriptive Source/saved-data design role, not independent own Source certification.'))
handoff=save('handoff-v1.json',dict(schema='owned-finalization-next-design-handoff-v1',author_identity='/root/conventional_library',
    note=note_pin,audit=audit_pin,Root_audit=pin(audit_path),current_master=pin(master),
    status='PROPOSED_UNIMPLEMENTED_UNMEASURED',scientific_calls=0,scientific_acceptance=False,
    future_execution_authorized=False,prior_negative_actuals_preserved=True,tools_stop_after_handoff=True))
print(json.dumps(dict(note=note_pin,audit=audit_pin,handoff=handoff,checks=len(checks))))
