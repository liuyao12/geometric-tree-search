"""Prospective finite anchored marking experiment; science imports only after freeze.

Each declared phase/attempt runs once. Sources, inputs, limits, runtime and
review admission are checked before/after the owned worker. No supplied target
solution or marking is read by acquisition, pair labeling or synthesis.
"""
import argparse
import copy
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
MASTER = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md')
PROTOCOL = 'data/protocol-frozen-v1.json'
POINT = dict(wall_seconds=3.0, max_work=1000000000, max_nodes=10000,
             max_events=10000, max_rollback_records=10000,
             max_candidates=1000, max_points=128)
SEMANTIC = dict(max_items=100000000, max_work=10000000000, wall_seconds=30.0)
TRACE = dict(max_items=100000000, wall_seconds=30.0)
ORACLE = dict(max_candidates=16, max_subsets=65536, wall_seconds=10.0,
              max_work=1000000000)
SYNTHESIS = dict(max_patterns=100000, max_work=10000000, wall_seconds=10.0)
GUARDS = dict(wall_seconds=1200.0, cpu_seconds=900, rss_bytes=1073741824)
CAPTURE_BYTES = 16777216
MODULES = dict(E='source/growing_point_search_v3.py',
               C='source/semantic_event_checker_v2.py',
               T='source/frontier_trace_checker_v2.py',
               O='source/marking_preservation_oracle_v1.py',
               L='source/learn_literal_markings_v1.py')


def need(ok, reason):
    if not ok:
        raise ValueError(reason)


def wire(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')


def sha(value):
    return hashlib.sha256(wire(value)).hexdigest()


def local(name):
    need(type(name) is str and not Path(name).is_absolute(), 'RELATIVE_TASK_PATH')
    p = (ROOT / name).resolve()
    need(p.is_relative_to(ROOT), 'TASK_PATH_ESCAPE')
    return p


def pin(path):
    h = hashlib.sha256()
    size = 0
    with path.open('rb') as f:
        for b in iter(lambda: f.read(1048576), b''):
            size += len(b)
            h.update(b)
    return dict(bytes=size, sha256=h.hexdigest())


def ref(name):
    return dict(path=name, **pin(local(name)))


def read(name):
    p = local(name)
    with (gzip.open(p, 'rt', encoding='ascii') if p.suffix == '.gz'
          else p.open('r', encoding='ascii')) as f:
        return json.load(f)


def save(name, value):
    p = local(name)
    p.parent.mkdir(parents=True, exist_ok=True)
    count, complete = 0, True
    with p.open('xb') as raw:
        out = gzip.GzipFile(fileobj=raw, mode='wb', mtime=0) if p.suffix == '.gz' else raw
        try:
            for part in json.JSONEncoder(sort_keys=True, ensure_ascii=True,
                    separators=(',', ':'), allow_nan=False).iterencode(value):
                b = part.encode('ascii')
                if count + len(b) >= CAPTURE_BYTES:
                    out.write(b[:CAPTURE_BYTES-count])
                    count, complete = CAPTURE_BYTES, False
                    break
                out.write(b)
                count += len(b)
            if complete:
                out.write(b'\n')
                count += 1
        finally:
            if out is not raw:
                out.close()
    r = dict(path=name, **pin(p), logical_json_bytes=count, complete_json=complete)
    if not complete:
        with local(name + '.capture-refusal.json').open('x') as f:
            json.dump(dict(status='UNKNOWN_CAPTURE', prefix=r), f)
        raise RuntimeError('UNKNOWN_CAPTURE:' + name)
    return r


def stage(name, fn):
    start = time.perf_counter()
    value = fn()
    called = time.perf_counter()
    r = save(name, value)
    r.update(call_seconds=called-start, write_seconds=time.perf_counter()-called,
             pipeline_seconds=time.perf_counter()-start)
    print(json.dumps(dict(stage=name, status=value.get('status'),
                          call_seconds=r['call_seconds'])), flush=True)
    return value, r


def runtime():
    p = Path(sys.executable).resolve()
    return dict(executable=dict(path=str(p), **pin(p)), version=sys.version,
                isolated=sys.flags.isolated, no_site=sys.flags.no_site,
                dont_write_bytecode=sys.dont_write_bytecode)


def scientific_files():
    names = set()
    for folder in ('source', 'reference', 'input', 'plan'):
        for p in (ROOT/folder).rglob('*'):
            need(not p.is_symlink(), 'NO_SOURCE_SYMLINK')
            if p.is_file():
                need(p.suffix != '.pyc' and '__pycache__' not in p.parts, 'NO_BYTECODE')
                names.add(p.relative_to(ROOT).as_posix())
    admission = read('review/root-source-admission-v1.json')
    need(admission['status'] == 'PASS_SOURCE_REVIEW_BEFORE_FREEZE', 'ROOT_SOURCE_ADMISSION')
    names.add('review/root-source-admission-v1.json')
    for r in admission['reviewed']:
        need(pin(local(r['path'])) == {k: r[k] for k in ('bytes', 'sha256')}, 'REVIEW_PIN')
        names.add(r['path'])
    return [ref(n) for n in sorted(names)]


def limits():
    return dict(point=POINT, semantic=SEMANTIC, trace=TRACE, oracle=ORACLE,
                synthesis=SYNTHESIS, guards=GUARDS, capture_bytes=CAPTURE_BYTES)


def freeze():
    need(sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode,
         'ISOLATED_NO_SITE_NO_BYTECODE')
    need(not local(PROTOCOL).exists(), 'PRESERVE_FIRST_FREEZE')
    need(pin(local('reference/basic-tiling-algorithm.md'))['sha256'] ==
         'c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9',
         'PINNED_NORMATIVE_MASTER')
    need(pin(MASTER) == pin(local('reference/basic-tiling-algorithm.md')), 'CURRENT_MASTER_MATCHES_COPY')
    return save(PROTOCOL, dict(schema='Learned-literal-marking-protocol-v1',
        status='FROZEN_BEFORE_SCIENTIFIC_IMPORTS', files=scientific_files(),
        runtime=runtime(), limits=limits(), phases=['qualify', 'pilot'],
        master=dict(path=str(MASTER), **pin(MASTER)),
        master_scope='Current normative master and exact local copy both byte-bound at freeze and postchecked.',
        scope='Fresh E3 qualification, then finite anchored four-row marking learning. No RL, heldout target, geometric prototype transfer or speed claim.',
        frozen_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())))


def unchanged():
    p = read(PROTOCOL)
    need(p['status'] == 'FROZEN_BEFORE_SCIENTIFIC_IMPORTS', 'FROZEN_STATUS')
    need(p['files'] == scientific_files(), 'FROZEN_SOURCE_INPUT_REVIEW_SET')
    need(p['runtime'] == runtime() and p['limits'] == limits(), 'FROZEN_RUNTIME_LIMITS')
    need(pin(MASTER) == {k: p['master'][k] for k in ('bytes', 'sha256')}, 'CURRENT_MASTER_UNCHANGED')
    return p


def modules():
    unchanged()
    result = {}
    for name, path in MODULES.items():
        spec = importlib.util.spec_from_file_location('marking_pilot_' + name, local(path))
        m = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(m)
        result[name] = m
    return result


def paired_graphs(C, model, raw, observations):
    m = C.Meter(**dict(items=SEMANTIC['max_items'], work=SEMANTIC['max_work'],
                       seconds=SEMANTIC['wall_seconds']))
    for v in (model, raw, observations):
        m.scan(v, input_items=True)
    reader = C.Reader(model, raw, m)
    need(len(observations) == len(raw['events']) == raw['event_extent']['total'],
         'COMPLETE_ACTUAL_CALLBACKS')
    rows = []
    for i, observed in enumerate(observations):
        m.same(observed['event'], raw['events'][i], 'OBSERVED_EVENT')
        reader.event(observed['event'], i)
        reconstructed = reader.snapshot()
        m.same(reconstructed, observed['state'], 'INCREMENTAL_READER_EQUALS_ACTUAL_GRAPH')
        rows.append(dict(seq=i, kind=observed['event']['kind'],
                         actual_sha256=m.sha(observed['state']),
                         reconstructed_sha256=m.sha(reconstructed), equal=True))
    m.same(reader.snapshot(), raw['final_state'], 'ACTUAL_FINAL_GRAPH')
    return dict(status='VERIFIED', events_checked=len(rows), comparisons=rows,
                items=m.items, work=m.work,
                scope='Private C Reader versus actual E callbacks; T separately re-enumerates all actual graphs.')


def run_engine(name, model, mods, point=None):
    observations = []
    model_ref = save(name + '/model.json', model)
    def audit(event, state, charge):
        if len(observations) >= POINT['max_events']:
            charge(POINT['max_work'] + 1)
        charge(1)
        observations.append(dict(event=event, state=state))
    raw, rr = stage(name + '/raw.json.gz', lambda: mods['E'].solve(
        model, POINT if point is None else point, audit=audit, order=None))
    obs_ref = save(name + '/observations.json.gz', observations)
    # Persist every producer output before a checker/oracle can read it.
    c, cr = stage(name + '/semantic.json', lambda: mods['C'].verify_explicit_events(model, raw, **SEMANTIC))
    t, tr = stage(name + '/full-graphs.json', lambda: mods['T'].verify(
        model, model['inventory']['placements'], observations, raw, **TRACE))
    g, gr = stage(name + '/paired-graphs.json', lambda: paired_graphs(mods['C'], model, raw, observations))
    row = dict(raw_status=raw['status'], semantic_status=c['status'],
               full_graph_status=t['status'], paired_graph_status=g['status'],
               engine_calls=1, actual_snapshots=len(observations), metrics=raw['stats'],
               refs=dict(model=model_ref, raw=rr, observations=obs_ref,
                         semantic=cr, full_graphs=tr, paired_graphs=gr))
    save(name + '/attempt.json', row)
    need(raw['status'] in ('SAT', 'UNSAT'), 'DEFINITE_ENGINE_RESULT:' + name)
    need(c['status'] == t['status'] == g['status'] == 'VERIFIED', 'THREE_ASSURANCE_GATES:' + name)
    need(t['counts']['observations_checked'] == len(observations), 'FULL_GRAPH_COVERAGE')
    return row, raw, observations, c


def matches(value, subset):
    if type(subset) is dict:
        return type(value) is dict and all(k in value and matches(value[k], v) for k, v in subset.items())
    return wire(value) == wire(subset)


def required_observations(case, observations):
    checks = []
    for request in case['expected'].get('required_observations', []):
        need(request['position'] in ('FIRST_DECISION', 'ANY'), 'OBSERVATION_POSITION')
        source = ([x for x in observations if x['event']['kind'] != 'READY'][:1]
                  if request['position'] == 'FIRST_DECISION' else observations)
        found = False
        for observed in source:
            if not matches(observed['event'], request['event']):
                continue
            state = observed['state']
            included = all(all(any(wire(x) == wire(y) for y in state[k]) for x in want)
                           for k, want in request.get('snapshot_contains', {}).items())
            omitted = all(all(x not in [y[0] if type(y) is list else y for y in state[k]] for x in want)
                          for k, want in request.get('snapshot_omits', {}).items())
            if included and omitted:
                checks.append(dict(request=request, seq=observed['event']['seq']))
                found = True
                break
        need(found, 'MISSING_REQUIRED_OBSERVATION:' + case['id'])
    return checks


def qualification():
    mods = modules()
    cases = read('input/qualification-cases-v1.json')['cases'] + read('input/pair-qualification-v1.json')['cases']
    need(len(cases) == len({c['id'] for c in cases}) == 17, 'SEVENTEEN_DECLARED_FIXTURES')
    rows, saved = [], {}
    for case in cases:
        name = 'data/qualification/' + case['id']
        row, raw, obs, c = run_engine(name, case['model'], mods)
        o, ore = stage(name + '/subsets.json.gz', lambda: mods['O'].enumerate_model(case['model'], **ORACLE))
        need(raw['status'] == case['expected']['raw_status'] and o['status'] == 'EXHAUSTED'
             and o['exists'] is case['expected']['exists'] and o['exists'] is (raw['status'] == 'SAT'),
             'INDEPENDENT_QUALIFICATION_EXISTENCE:' + case['id'])
        row.update(id=case['id'], status='QUALIFIED', oracle=ore,
                   required_observations=required_observations(case, obs))
        save(name + '/qualified.json', row)
        rows.append(row)
        saved[case['id']] = (case['model'], raw, obs)
    model, raw, obs = saved['pq01-remote-pair-forced']
    controls = []
    for kind in read('input/pair-qualification-v1.json')['invalid_pairs']:
        bad = copy.deepcopy(model)
        if kind == 'self': bad['pair_nogoods'] = [['A', 'A']]
        elif kind == 'unknown': bad['pair_nogoods'] = [['A', 'UNKNOWN']]
        elif kind == 'unsorted_inner': bad['pair_nogoods'] = [['B', 'A']]
        elif kind == 'duplicate': bad['pair_nogoods'] *= 2
        elif kind == 'missing_key': del bad['pair_nogoods']
        elif kind == 'nonempty_indexed': bad['inventory'] = dict(kind='CERTIFIED_INCIDENT', identity='INVALID_NONEMPTY_PAIRS')
        else: raise ValueError('UNDECLARED_INVALID_CONTROL')
        save('data/controls/' + kind + '-input.json', bad)
        try:
            mods['E'].solve(bad, POINT)
        except mods['E'].InputError as error:
            answer = dict(status='REJECTED', reason=str(error))
        else:
            raise ValueError('MALFORMED_PAIR_ACCEPTED:' + kind)
        controls.append(dict(id=kind, receipt=save('data/controls/' + kind + '-receipt.json', answer)))
    low = dict(POINT, max_work=1)
    unknown, ur = stage('data/controls/resource-raw.json', lambda: mods['E'].solve(model, low))
    check, uc = stage('data/controls/resource-semantic.json', lambda: mods['C'].verify_explicit_events(model, unknown, **SEMANTIC))
    need(unknown['status'] == check['status'] == 'UNKNOWN' and check['bounded_absence'] is False, 'UNKNOWN_NOT_NEGATIVE')
    controls.append(dict(id='engine-resource-unknown', raw=ur, receipt=uc))
    bad = copy.deepcopy(raw)
    target = next(x for x in bad['events'] if x['kind'] == 'FORCED')
    target['candidate'] = 'B'
    h = hashlib.sha256()
    for e in bad['events']: h.update(wire(e))
    bad['event_extent']['sha256'] = h.hexdigest()
    save('data/controls/forbidden-forced-input.json.gz', bad)
    c, cr = stage('data/controls/forbidden-forced-check.json', lambda: mods['C'].verify_explicit_events(model, bad, **SEMANTIC))
    need(c['status'] == 'REJECTED' and c['bounded_absence'] is False, 'FORBIDDEN_FORCED_REJECTED')
    controls.append(dict(id='forbidden-forced', receipt=cr))
    altered = copy.deepcopy(obs)
    snap = next(x['state'] for x in altered if x['event']['kind'] == 'FORCED')
    snap['eligible'] = sorted(snap['eligible'] + ['B'])
    next(x[1] for x in snap['domains'] if x[0] == 'b').append('B')
    for row in snap['domains']: row[1].sort()
    snap['forward'].append(['b', 'B', 1]); snap['forward'].sort()
    snap['reverse'].append(['B', [['b', 1]]]); snap['reverse'].sort()
    snap['edge_count'] += 1
    save('data/controls/forbidden-graph-input.json.gz', altered)
    t, tr = stage('data/controls/forbidden-graph-check.json', lambda: mods['T'].verify(model, model['inventory']['placements'], altered, raw, **TRACE))
    need(t['status'] == 'REJECTED', 'FORBIDDEN_GRAPH_REJECTED')
    controls.append(dict(id='forbidden-graph', receipt=tr))
    l, lr = stage('data/controls/synthesis-resource.json', lambda: mods['L'].synthesize(
        sorted(x['id'] for x in model['inventory']['placements']), [], 'test-q', **dict(SYNTHESIS, max_patterns=1)))
    need(l['status'] == 'UNKNOWN' and l['assignments'] is None, 'SYNTHESIS_UNKNOWN_HAS_NO_ASSIGNMENT')
    controls.append(dict(id='synthesis-resource', receipt=lr))
    o, ore = stage('data/controls/oracle-resource.json', lambda: mods['O'].enumerate_model(model, **dict(ORACLE, max_subsets=1)))
    need(o['status'] == 'UNKNOWN', 'ORACLE_RESOURCE_UNKNOWN')
    controls.append(dict(id='oracle-resource', receipt=ore))
    return dict(status='QUALIFIED_LITERAL_MARKING_ENGINE_V3', cases=rows, controls=controls,
                fresh_regular_engine_calls=17, invalid_engine_calls=6, resource_engine_calls=1,
                actual_snapshots=sum(r['actual_snapshots'] for r in rows),
                scope='Fresh engine/filter/marking graph and semantic qualification; no speed or target-transfer result.')


def pair_catalog(model):
    rows = sorted(model['inventory']['placements'], key=lambda r: r['id'])
    need(model['pair_nogoods'] == [] and model['seed'] == dict(t=[], m=[])
         and all(r['m'] == [] for r in rows), 'INITIAL_UNMARKED_EMPTY_SEED_PROFILE')
    pairs = []
    for i, left in enumerate(rows):
        lt = dict(left['t'])
        for right in rows[i+1:]:
            rt = dict(right['t'])
            if set(lt) & set(rt) and all(lt.get(p, 0)+rt.get(p, 0) <= model['capacity'] for p in set(lt) | set(rt)):
                pairs.append([left['id'], right['id']])
    return pairs


def fixed_pair(model, pair):
    rows = {r['id']: r for r in model['inventory']['placements']}
    totals, marks = {}, {}
    for c in pair:
        for p, n in rows[c]['t']: totals[p] = totals.get(p, 0) + n
        for p, v in rows[c]['m']:
            if p in marks and marks[p] != v:
                return None
            marks[p] = v
    need(all(n <= model['capacity'] for n in totals.values()), 'PAIR_CAPACITY_LEGAL')
    out = copy.deepcopy(model)
    out['version'] += ':fixed:' + '+'.join(pair)
    out['roots'] = sorted(set(out['roots']) | set(totals))
    out['seed'] = dict(t=sorted([[p, n] for p, n in totals.items()]), m=sorted([[p, v] for p, v in marks.items()]))
    out['inventory']['placements'] = [r for r in out['inventory']['placements'] if r['id'] not in pair]
    need(out['pair_nogoods'] == [], 'PAIR_LABELER_NEVER_USES_LEARNED_FILTER')
    return out


def admitted_qualification():
    o = read('review/qualify-observer.json')
    i = read('review/qualify-invocation.json')
    s = read('data/qualify-started.json')
    r = read('data/qualify-result.json')
    need(type(o['native_exit_code']) is int and o['native_exit_code'] == 0 and
         o['status'] == 'TERMINAL' and o['guard_reason'] is o['observer_error'] is o['reap_error'] is None,
         'ACTUAL_CLEAN_QUALIFICATION_PROCESS')
    need(o['phase'] == i['phase'] == s['phase'] == 'qualify' and
         o['pid'] == i['pid'] == s['pid'] and i['status'] == 'COMPLETE' and
         i['frozen_postcheck'] == o['frozen_postcheck'] == 'FROZEN_BEFORE_SCIENTIFIC_IMPORTS', 'QUALIFICATION_CUSTODY')
    need(s['protocol'] == ref(PROTOCOL) and
         pin(local(o['log']['path'])) == {k: o['log'][k] for k in ('bytes', 'sha256')}, 'QUALIFICATION_PROTOCOL_LOG')
    need(i['result']['path'] == 'data/qualify-result.json' and i['result']['complete_json'] is True and
         pin(local(i['result']['path'])) == {k: i['result'][k] for k in ('bytes', 'sha256')} and
         r['status'] == 'QUALIFIED_LITERAL_MARKING_ENGINE_V3' and len(r['cases']) == 17 and
         len({x['id'] for x in r['cases']}) == 17 and len(r['controls']) == 11,
         'QUALIFICATION_RESULT_PIN')
    for row in r['cases']:
        need(row['status'] == 'QUALIFIED' and row['engine_calls'] == 1 and
             row['semantic_status'] == row['full_graph_status'] == row['paired_graph_status'] == 'VERIFIED',
             'QUALIFICATION_ALL_CASES')
        for expected in [*row['refs'].values(), row['oracle']]:
            need(expected['complete_json'] is True and
                 pin(local(expected['path'])) == {k: expected[k] for k in ('bytes', 'sha256')},
                 'QUALIFICATION_SAVED_ARTIFACT_PIN')
    for row in r['controls']:
        for expected in [v for v in row.values() if type(v) is dict and 'path' in v]:
            need(expected['complete_json'] is True and
                 pin(local(expected['path'])) == {k: expected[k] for k in ('bytes', 'sha256')},
                 'QUALIFICATION_CONTROL_PIN')


def pilot():
    admitted_qualification()
    mods = modules()
    model = read('input/pilot-model-v1.json')
    site = read('plan/marking-support-v1.json')['site']
    need(all(site != p for r in model['inventory']['placements'] for p, n in r['t']), 'MARK_ONLY_SITE')
    acq, raw, observed, certificate = run_engine('data/pilot/acquisition', model, mods)
    harvested = [w for w in certificate['dead_context_witnesses']
                 if len(w['context_preimage']['selected']) == 2 and not w['context_preimage']['excluded']]
    save('data/pilot/harvested-failures.json', dict(status='CONTEXTS_REQUIRE_FIXED_PAIR_CERTIFICATION', witnesses=harvested))
    catalog = pair_catalog(model)
    save('data/pilot/catalog.json', dict(status='ENUMERATED_UNLABELED', pairs=catalog))
    cids = sorted(r['id'] for r in model['inventory']['placements'])
    labels, runs, history = [], [], []
    learned, initial = stage('data/pilot/synthesis-000.json', lambda: mods['L'].synthesize(cids, [], site, **SYNTHESIS))
    need(learned['status'] == 'SOLVED' and learned['assigned_values'] == 0, 'INITIALLY_NO_MARKINGS')
    history.append(initial)
    for number, pair in enumerate(catalog, 1):
        fixed = fixed_pair(model, pair)
        need(fixed is not None, 'UNMARKED_PAIR_NO_MARK_CONFLICT')
        row, r, obs, c = run_engine('data/pilot/labels/%03d' % number, fixed, mods)
        label = 'POSITIVE' if r['status'] == 'SAT' else 'NEGATIVE'
        need(c['bounded_absence'] is (label == 'NEGATIVE'), 'CERTIFIED_PAIR_LABEL')
        labels.append(dict(pair=pair, label=label))
        runs.append(dict(pair=pair, label=label, run=row))
        save('data/pilot/labels-through-%03d.json' % number, labels)
        learned, lr = stage('data/pilot/synthesis-%03d.json' % number,
            lambda: mods['L'].synthesize(cids, labels, site, **SYNTHESIS))
        history.append(lr)
    need(learned['status'] == 'SOLVED' and learned['unresolved'] == 0 and
         all(s['matched'] is True for s in learned['score']), 'ALL_CATALOG_LABELS_FIT')
    pairs = sorted(r['pair'] for r in labels if r['label'] == 'NEGATIVE')
    supported = [w for w in harvested if [c for c, g in w['context_preimage']['selected']] in pairs]
    need(supported and pairs, 'DISCOVERED_FAILURE_CERTIFIED_AS_GLOBAL_FINITE_PAIR')
    marked = copy.deepcopy(model)
    marked['version'] += ':learned-literals-v1'
    assignments = {r['id']: r['m'] for r in learned['assignments']}
    need(set(assignments) == set(cids), 'SYNTHESIS_ALL_INVENTORY_IDENTITIES')
    for row in marked['inventory']['placements']: row['m'] = assignments[row['id']]
    marked_ref = save('data/pilot/learned-model.json', marked)
    mark_sha = sha(marked)
    save('data/pilot/learned-model-frozen-v1.json', dict(status='FROZEN_BEFORE_PRESERVATION_AND_SEARCH',
        model=marked_ref, canonical_model_sha256=mark_sha, labels=labels,
        marking_source='Actual synthesized output; no target assignment provided.', history=history))
    # This independent complete oracle has no output path to the learner.
    preservation, pr = stage('data/pilot/preservation.json.gz', lambda: mods['O'].verify(model, marked, pairs, **ORACLE))
    need(preservation['status'] == 'VERIFIED', 'FULL_FINITE_PRESERVATION_AND_FILTER_EQUIVALENCE')
    census = [dict(pair=r['pair'], label=r['extension_status'])
              for r in preservation['evidence']['meeting_pairs']]
    need(census == labels and [r['pair'] for r in census] == catalog,
         'INDEPENDENT_COMPLETE_CATALOG_AND_LABEL_JOIN_AFTER_FREEZE')
    filtered = copy.deepcopy(model)
    filtered['version'] += ':ordinary-pair-filter-v1'
    filtered['pair_nogoods'] = pairs
    lanes = []
    for lane, target in [('BASE', model), ('MARKS', marked), ('PAIR_FILTER', filtered)]:
        need(sha(read(marked_ref['path'])) == mark_sha and sha(marked) == mark_sha, 'LEARNED_MODEL_STAYS_FROZEN')
        row, r, obs, c = run_engine('data/pilot/lanes/' + lane, target, mods)
        row.update(lane=lane)
        lanes.append(row)
    # Literal pair replay: reject conflicting fixed seeds directly, otherwise
    # complete the fixed marked pair with the same point engine/checkers.
    replays = []
    for number, label in enumerate(labels, 1):
        fixed = fixed_pair(marked, label['pair'])
        if fixed is None:
            need(label['label'] == 'NEGATIVE', 'NO_POSITIVE_PAIR_MARK_CONFLICT')
            replay = dict(pair=label['pair'], status='REJECTED_BY_LITERAL_MARKING_AGREEMENT', engine_calls=0,
                          literal_assignments=[r for r in marked['inventory']['placements'] if r['id'] in label['pair']])
        else:
            row, r, obs, c = run_engine('data/pilot/marked-pair-replay/%03d' % number, fixed, mods)
            need(label['label'] == 'POSITIVE' and r['status'] == 'SAT', 'MARKED_POSITIVE_PAIR_REPLAY')
            replay = dict(pair=label['pair'], status='VERIFIED_POSITIVE_FIXED_PAIR', run=row, engine_calls=1)
        replays.append(replay)
        save('data/pilot/marked-pair-replay/%03d-summary.json' % number, replay)
    # Deliberately corrupt a positive pair as a preservation-checker control.
    positive = next(r['pair'] for r in labels if r['label'] == 'POSITIVE')
    corrupt = copy.deepcopy(marked)
    for row in corrupt['inventory']['placements']:
        if row['id'] in positive: row['m'] = [[site, str(positive.index(row['id']))]]
    save('data/pilot/preservation-control-input.json', corrupt)
    refusal, nr = stage('data/pilot/preservation-control-check.json.gz', lambda: mods['O'].verify(model, corrupt, pairs, **ORACLE))
    need(refusal['status'] == 'REJECTED', 'LOST_POSITIVE_SOLUTION_REJECTED')
    return dict(status='VERIFIED_FINITE_LITERAL_MARKING_LEARNING',
        acquisition=acq, failure_contexts=supported, catalog=catalog, labels=labels,
        label_runs=runs, synthesis_history=history, learned_model=marked_ref,
        marking_model_sha256=mark_sha, preservation=pr, lanes=lanes,
        marked_pair_replays=replays, preservation_control=nr,
        timing_scope='Fresh states in one warm process, fixed BASE/MARKS/PAIR_FILTER order. All acquisition, synthesis, preservation, assurance and output costs retained; no speed inference.',
        scope='One supplied finite anchored four-row mechanism test; no learned prototype, target transfer, RL, automated mathematical theorem, superiority or plane claim.')


def worker(phase):
    p = unchanged()
    need(phase in p['phases'], 'DECLARED_PHASE')
    if phase == 'pilot': admitted_qualification()
    save('data/' + phase + '-started.json', dict(phase=phase, pid=os.getpid(), protocol=ref(PROTOCOL)))
    started, result, result_ref = time.perf_counter(), None, None
    try:
        result = qualification() if phase == 'qualify' else pilot()
        result_ref = save('data/' + phase + '-result.json', result)
    finally:
        error = sys.exc_info()[0]
        post_error = None
        try: postcheck = unchanged()['status']
        except Exception as failure: postcheck, post_error = 'FAILED', str(failure)
        save('review/' + phase + '-invocation.json', dict(status='ERROR' if error or post_error else 'COMPLETE',
            phase=phase, pid=os.getpid(), scientific_status=result.get('status') if result else None,
            result=result_ref, seconds=time.perf_counter()-started, error_type=error.__name__ if error else None,
            frozen_postcheck=postcheck, postcheck_error=post_error,
            maxrss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            maxrss_units='bytes' if sys.platform == 'darwin' else 'KiB'))
        if post_error and error is None: raise RuntimeError('FROZEN_POSTCHECK:' + post_error)


def supervise(phase):
    p = unchanged()
    need(phase in p['phases'], 'DECLARED_PHASE')
    if phase == 'pilot': admitted_qualification()
    for name in ('data/' + phase + '-started.json', 'data/' + phase + '-result.json',
                 'review/' + phase + '-invocation.json', 'review/' + phase + '-observer.json',
                 'review/' + phase + '-native.log'):
        need(not local(name).exists(), 'PRESERVE_FIRST_ATTEMPT:' + name)
    log = local('review/' + phase + '-native.log')
    start = time.perf_counter()
    child = code = reason = error_text = reap_error = None
    peak, samples = 0, []
    def cpu_guard():
        resource.setrlimit(resource.RLIMIT_CPU, (GUARDS['cpu_seconds'], GUARDS['cpu_seconds']+1))
    with log.open('xb') as output:
        try:
            child = subprocess.Popen([sys.executable, '-I', '-S', '-B', str(Path(__file__).resolve()), '_worker', phase],
                cwd=ROOT, env={'PATH': '/usr/bin:/bin', 'LANG': 'C', 'PYTHONDONTWRITEBYTECODE': '1'},
                stdout=output, stderr=subprocess.STDOUT, start_new_session=True, preexec_fn=cpu_guard)
            while child.poll() is None:
                probe = subprocess.run(['/bin/ps', '-o', 'rss=', '-p', str(child.pid)], capture_output=True, text=True, timeout=5)
                if probe.returncode == 0 and probe.stdout.strip():
                    rss = int(probe.stdout.strip())*1024
                    if rss > peak: peak = rss; samples.append(dict(seconds=time.perf_counter()-start, rss_bytes=rss))
                    if rss > GUARDS['rss_bytes']: reason = 'RSS_POLL_BOUND'; break
                elif child.poll() is None: reason = 'RSS_PROBE_FAILED'; break
                if time.perf_counter()-start > GUARDS['wall_seconds']: reason = 'WALL_BOUND'; break
                time.sleep(.2)
        except BaseException as error:
            reason, error_text = 'OBSERVER_ERROR:' + type(error).__name__, str(error)
        finally:
            if child is not None:
                if reason and child.poll() is None:
                    try: os.killpg(child.pid, signal.SIGTERM)
                    except ProcessLookupError: pass
                    except OSError as error: error_text = str(error)
                    try: child.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        try: os.killpg(child.pid, signal.SIGKILL)
                        except ProcessLookupError: pass
                        except OSError as error: error_text = str(error)
                    except OSError as error: error_text = 'TERM_WAIT_ERROR:' + str(error)
                try: code = child.wait(timeout=5)
                except subprocess.TimeoutExpired: reap_error = 'NATIVE_EXIT_UNOBSERVED'
                except OSError as error: reap_error = 'NATIVE_WAIT_ERROR:' + str(error)
    post_error = None
    try: postcheck = unchanged()['status']
    except Exception as error: postcheck, post_error = 'FAILED', str(error)
    result = dict(status='TERMINAL' if code is not None else 'UNADMITTED_PROCESS', phase=phase,
        pid=child.pid if child else None, native_exit_code=code, guard_reason=reason,
        observer_error=error_text, reap_error=reap_error, seconds=time.perf_counter()-start,
        peak_observed_rss_bytes=peak, rss_samples=samples, log=ref(str(log.relative_to(ROOT))),
        frozen_postcheck=postcheck, postcheck_error=post_error,
        scope='One owned child; polled RSS, actual native exit. Never silently rerun.')
    save('review/' + phase + '-observer.json', result)
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('command', choices=('freeze', 'run', '_worker'))
    parser.add_argument('phase', nargs='?', choices=('qualify', 'pilot'))
    args = parser.parse_args()
    need((args.command == 'freeze') == (args.phase is None), 'COMMAND_PHASE')
    answer = freeze() if args.command == 'freeze' else supervise(args.phase) if args.command == 'run' else worker(args.phase)
    print(json.dumps(answer, sort_keys=True), flush=True)
    if args.command == 'run' and not (answer['status'] == 'TERMINAL' and
            type(answer['native_exit_code']) is int and answer['native_exit_code'] == 0 and
            answer['guard_reason'] is answer['observer_error'] is answer['reap_error'] is answer['postcheck_error'] is None and
            answer['frozen_postcheck'] == 'FROZEN_BEFORE_SCIENTIFIC_IMPORTS'):
        raise SystemExit(1)
