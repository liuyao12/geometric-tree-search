"""Finite anchored equality-mark synthesis, initially absent, from resolved labels.

No search engine, proof checker, oracle, expected bad pair or expected marking is
imported. One prospectively declared mark-only site and literal colors 0/1 are
the representation budget. Missing is represented by None, never literal zero.
"""
import itertools
import time


def synthesize(cids, labels, site, *, max_patterns=100000, max_work=10000000,
               wall_seconds=10.0):
    started = time.perf_counter()
    work = patterns = 0

    def tick(n=1):
        nonlocal work
        if work + n > max_work or time.perf_counter() - started > wall_seconds:
            raise TimeoutError('SYNTHESIS_RESOURCE_BOUND')
        work += n

    def out(status, **extra):
        return dict(schema='Finite-literal-mark-synthesis-v1', status=status,
                    site=site, patterns=patterns, work=work,
                    seconds=time.perf_counter() - started,
                    work_scope='Declared loop units; not Python instruction or full input/serialization cost.',
                    **extra)

    try:
        if not (type(cids) is list and 0 < len(cids) <= 12 and
                all(type(c) is str and c for c in cids) and
                cids == sorted(set(cids)) and type(site) is str and site and
                type(labels) is list and len(labels) <= 1000 and
                type(max_patterns) is int and max_patterns > 0 and
                type(max_work) is int and max_work > 0 and
                type(wall_seconds) in (float, int) and 0 < wall_seconds <= 60):
            raise ValueError('SYNTHESIS_DECLARATION')
        index = {c: i for i, c in enumerate(cids)}
        constraints, seen = [], set()
        for row in labels:
            tick()
            if not (type(row) is dict and set(row) == {'pair', 'label'} and
                    type(row['pair']) is list and len(row['pair']) == 2 and
                    all(type(c) is str and c in index for c in row['pair']) and
                    row['pair'] == sorted(set(row['pair'])) and
                    row['label'] in ('POSITIVE', 'NEGATIVE', 'UNKNOWN')):
                raise ValueError('SYNTHESIS_LABEL')
            pair = tuple(row['pair'])
            if pair in seen:
                raise ValueError('DUPLICATE_LABEL')
            seen.add(pair)
            if row['label'] != 'UNKNOWN':
                constraints.append((index[pair[0]], index[pair[1]], row['label']))
        best = best_key = None
        # Full enumeration makes the sparsity/lexical objective auditable.
        for pattern in itertools.product((None, '0', '1'), repeat=len(cids)):
            if patterns >= max_patterns:
                raise TimeoutError('SYNTHESIS_PATTERN_BOUND')
            patterns += 1
            tick(1 + len(pattern))
            valid = True
            for i, j, label in constraints:
                tick()
                conflict = pattern[i] is not None and pattern[j] is not None and pattern[i] != pattern[j]
                if conflict != (label == 'NEGATIVE'):
                    valid = False
                    break
            if valid:
                key = (sum(v is not None for v in pattern),
                       tuple(0 if v is None else 1 if v == '0' else 2 for v in pattern))
                if best_key is None or key < best_key:
                    best, best_key = pattern, key
        if best is None:
            tick(0)
            return out('UNREPRESENTABLE', assignments=None,
                       resolved=len(constraints), unresolved=len(labels)-len(constraints))
        assignments = []
        for c, v in zip(cids, best):
            tick()
            assignments.append(dict(id=c, m=[] if v is None else [[site, v]]))
        score = []
        for row in labels:
            tick()
            i, j = (index[c] for c in row['pair'])
            conflict = best[i] is not None and best[j] is not None and best[i] != best[j]
            score.append(dict(pair=list(row['pair']), label=row['label'],
                              rejected=conflict,
                              matched=None if row['label'] == 'UNKNOWN' else conflict == (row['label'] == 'NEGATIVE')))
        tick(0)
        return out('SOLVED', assignments=assignments, assigned_values=best_key[0],
                   assigned_sites=int(best_key[0] > 0), score=score,
                   resolved=len(constraints), unresolved=len(labels)-len(constraints),
                   objective='minimum assigned components, then absent/0/1 lexical vector',
                   scope='Complete finite supplied catalog fit only; preservation is an independent gate.')
    except TimeoutError as error:
        return out('UNKNOWN', reason=str(error), assignments=None)
    except (ValueError, TypeError) as error:
        return out('REJECTED', reason=str(error), assignments=None)
