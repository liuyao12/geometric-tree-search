Learned literal point markings from certified finite failures, 2026-11-03.

Download EVERY learned-literal-markings-evidence-v1-part-NNN.zip plus the
learned-literal-markings-evidence-manifest-v1.json. Each independent volume is
at most 44 MiB and contains the same ARCHIVE-file-manifest-v1.json. Extract all
volumes together. Every original current path present at the archive cut is
physically stored once, including identical bytes at distinct paths. Exact
uncompressed size/SHA256 and every CRC are verified. No alias or reconstruction
recipe substitutes for original bytes. Only generated package outputs cannot
archive themselves; receipts created after this cut remain later custody files.

The archive includes all current frozen Sources, input/reference/plan/review
files, actual raw outcomes and snapshots, full subset oracle evidence, pair
certificates, synthesis history, learned model, controls, logs, renderer/public
outputs and publication Sources/planning. The predecessor complete archive is
separately linked at semantic-certificates-evidence-v1.html; no predecessor file
count is claimed to be physically included in this current archive. All local
paths, logs and full task evidence are approved for this existing destination.

Serve the extracted directory and open report/learned-literal-markings-v1.html.
Both prospective phases have actual native exit zero and unchanged Source guards.
Seventeen qualification cases retain 143 actual graph snapshots, eleven distinct
controls and complete independent subset enumeration. The pilot acquired all
meeting-pair labels by unmarked search, started synthesis with absent values,
and froze its actual learned model before independent preservation. Every one
of 16 subsets, 8 capacity-legal states and 2 original covers was retained; literal
marking/filter compatibility, eligibility, domains and weighted edges agree.
Three fresh same-engine BASE/MARKS/PAIR_FILTER states keep the whole inventory.
Unknown/resource controls never become negative acquisition labels.

This is one supplied finite anchored mechanism, not geometric-prototype
transfer, a held-out theorem, RL, superiority over ordinary nogoods or a speed
result. Timings are warm-process fixed-order observations. The original failure
was found and certified before learning; the representation budget was supplied.
No universal Wang/FOL completeness, PA/Hilbert theorem, substitution rule or
whole-plane tiling is established. The overall research goal remains ACTIVE.
