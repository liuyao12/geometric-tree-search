"""Saved-byte/process/physical-ZIP publication gates; no scientific replay."""
import copy
import gzip
import hashlib
import json
from pathlib import Path,PurePosixPath
import zipfile

ROOT=Path(__file__).resolve().parents[1]
PREFIX='docs/research/gcts-rl-renewal/conditional-inventory/'
BASE_URL='https://liuyao12.github.io/geometric-tree-search/'
MANIFEST='learned-literal-markings-evidence-manifest-v1.json'
INTERNAL='ARCHIVE-file-manifest-v1.json'
PART_STEM='learned-literal-markings-evidence-v1-part-'
MAX_PART=44*1024*1024
PHASES=('qualify','pilot')
MAIN='learned-literal-markings-v1.html'
REPORT_DATA='report/learned-literal-markings-data-v1.json.gz'
REPORT_RECEIPT='report/build-receipt-v1.json'
REPORT_BUILDER='report/build_marking_report_v1.py'
DATA_SCHEMA='Learned-literal-markings-report-data-v1'
DATA_STATUS='PASS_SAVED_DATA_PROJECTION'
BUILD_SCHEMA='Learned-literal-markings-report-build-v1'
BUILD_STATUS='PASS_SAVED_DATA_AND_REPORT_BUILD'
ROOT_ADMISSION='review/root-publication-admission-v1.json'
SOURCE_ADMISSION='review/root-source-admission-v1.json'
READINESS_STATUSES={REPORT_RECEIPT:BUILD_STATUS,
    'review/report-independent-data-audit-v1.json':'PASS',
    'review/local-ui-qualification-v1.json':'PASS_LOCAL_UI',ROOT_ADMISSION:'PASS',
    SOURCE_ADMISSION:'PASS_SOURCE_REVIEW_BEFORE_FREEZE'}
READINESS=tuple(READINESS_STATUSES)
REVIEWED_DRIVER={'path':'source/run_marking_pilot_v1.py','bytes':32348,
    'sha256':'eeabd78f2f6816d32887af3ff22b0fb49aacd53a8ec0583840f50a5518a1d122'}
FROZEN_PROTOCOL={'path':'data/protocol-frozen-v1.json','bytes':5602,
    'sha256':'a5970ecd01355ade203bfe3a6331e27fa062e39d7c3a4e059c0205f48eb868b8'}
PREVIOUS_EVIDENCE_URL=BASE_URL+PREFIX+'semantic-certificates-evidence-v1.html'
PRIMARY_MASTER=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md')
BEGIN=b'<!-- LEARNED_LITERAL_MARKINGS_ARCHIVE_LINK -->'
END=b'<!-- /LEARNED_LITERAL_MARKINGS_ARCHIVE_LINK -->'

def wire(v):return (json.dumps(v,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')
def digest(raw):return hashlib.sha256(raw).hexdigest()
def stream_pin(stream):
    h=hashlib.sha256();size=0
    for block in iter(lambda:stream.read(1048576),b''):h.update(block);size+=len(block)
    return dict(bytes=size,sha256=h.hexdigest())
def pin(path):
    with path.open('rb') as f:return stream_pin(f)
def relative_name(value):
    assert type(value) is str and value and '\\' not in value and '\x00' not in value
    p=PurePosixPath(value)
    assert not p.is_absolute() and all(v not in ('','.','..') for v in p.parts) and p.as_posix()==value
    return value
def local(root,value):
    p=root/relative_name(value);assert root.resolve() in p.resolve().parents
    return p
def load(name):
    path=local(ROOT,name)
    with (gzip.open(path,'rb') if path.suffix=='.gz' else path.open('rb')) as f:raw=f.read(16777217)
    assert len(raw)<=16777216,'Saved JSON exceeds declared capture scope: '+name
    return json.loads(raw)
def exact(name,expected):
    assert wire(pin(local(ROOT,name)))==wire({k:expected[k] for k in ('bytes','sha256')}),name
def reference(name):return dict(path=name,**pin(local(ROOT,name)))
def checked(e):
    assert e.get('complete_json',True) is True;exact(e['path'],e);return load(e['path'])
def normalized_model(model):
    out=copy.deepcopy(model);out['roots'].sort()
    for k in ('t','m'):out['seed'][k].sort(key=lambda x:x[0])
    for row in out['inventory']['placements']:
        for k in ('t','m'):row[k].sort(key=lambda x:x[0])
    out['inventory']['placements'].sort(key=lambda x:x['id']);return out

def fixed_pair_association(original,pair,fixed):
    """Compare saved residual input with its declared fixed rows; no search."""
    rows={r['id']:r for r in original['inventory']['placements']};totals={};marks={}
    assert len(pair)==len(set(pair))==2 and original['seed']=={'t':[],'m':[]} and original['pair_nogoods']==[]
    for cid in pair:
        for p,n in rows[cid]['t']:totals[p]=totals.get(p,0)+n
        for p,v in rows[cid]['m']:
            assert p not in marks or marks[p]==v;marks[p]=v
    assert fixed['schema']==original['schema'] and fixed['capacity']==original['capacity']
    assert fixed['version']==original['version']+':fixed:'+'+'.join(pair) and fixed['pair_nogoods']==[]
    assert fixed['roots']==sorted(set(original['roots'])|set(totals))
    assert fixed['seed']=={'t':[[p,n] for p,n in sorted(totals.items())],'m':[[p,v] for p,v in sorted(marks.items())]}
    assert fixed['inventory']==dict(kind='EXPLICIT',placements=[r for r in original['inventory']['placements'] if r['id'] not in pair])

def verify_run(row):
    """Associate saved records only; do not reconstruct a graph or replay E/C/T."""
    assert row['engine_calls']==1 and row['semantic_status']==row['full_graph_status']==row['paired_graph_status']=='VERIFIED'
    refs=row['refs'];assert set(refs)=={'model','raw','observations','semantic','full_graphs','paired_graphs'}
    model=checked(refs['model']);raw=checked(refs['raw']);obs=checked(refs['observations'])
    c=checked(refs['semantic']);t=checked(refs['full_graphs']);g=checked(refs['paired_graphs'])
    assert raw['status']==row['raw_status'] and raw['status'] in ('SAT','UNSAT')
    assert c['status']==t['status']==g['status']=='VERIFIED' and c['run_status']==t['run_status']==raw['status']
    assert raw['model_sha256']==c['model_sha256']==t['model_sha256']==digest(wire(normalized_model(model)))
    assert c['bounded_absence'] is (raw['status']=='UNSAT') and c['event_coverage']=='COMPLETE'
    assert len(obs)==row['actual_snapshots']==raw['event_extent']['total']==len(raw['events'])==g['events_checked']==len(g['comparisons'])==t['counts']['observations_checked']
    assert wire([x['event'] for x in obs])==wire(raw['events'])
    assert wire(row['metrics'])==wire(raw['stats']) and raw['stats']['audit_calls']==len(obs)
    for actual,comparison in zip(obs,g['comparisons']):
        assert comparison['seq']==actual['event']['seq'] and comparison['equal'] is True
        assert comparison['actual_sha256']==comparison['reconstructed_sha256']==digest(wire(actual['state']))
    for key in ('entry','final','restored'):assert raw['state_hashes'][key]==digest(wire(raw[key+'_state']))
    assert wire(raw['entry_state'])==wire(raw['restored_state'])
    if raw['status']=='SAT':assert raw['selected']==sorted(x['id'] for x in raw['certificate']['placements'])
    else:assert raw['selected']==[] and raw['certificate'] is None
    return dict(raw_status=raw['status'],model_sha256=raw['model_sha256'],snapshots=len(obs),refs=refs),model,raw

def verify_science():
    q=load('data/qualify-result.json');p=load('data/pilot-result.json')
    assert q['status']=='QUALIFIED_LITERAL_MARKING_ENGINE_V3' and len(q['cases'])==17
    assert q['fresh_regular_engine_calls']==17 and q['invalid_engine_calls']==6 and q['resource_engine_calls']==1 and q['actual_snapshots']==143
    fixtures=load('input/qualification-cases-v1.json')['cases']+load('input/pair-qualification-v1.json')['cases']
    assert [x['id'] for x in q['cases']]==[x['id'] for x in fixtures] and len({x['id'] for x in q['cases']})==17
    qual=[]
    for row in q['cases']:
        assert row['status']=='QUALIFIED';run,model,raw=verify_run(row);o=checked(row['oracle'])
        assert o['status']=='EXHAUSTED' and o['subsets_coverage']=='COMPLETE' and o['exists'] is (raw['status']=='SAT')
        assert o['counts']['subsets_checked']==o['subsets_total']==1<<len(model['inventory']['placements'])
        assert o['model_sha256']==run['model_sha256']
        if raw['status']=='SAT':assert any(x['selected']==raw['selected'] for x in o['solutions'])
        qual.append(dict(id=row['id'],run=run,oracle=row['oracle']))
    assert sum(x['run']['snapshots'] for x in qual)==143
    expected_controls={'self':'REJECTED','unknown':'REJECTED','unsorted_inner':'REJECTED','duplicate':'REJECTED',
        'missing_key':'REJECTED','nonempty_indexed':'REJECTED','engine-resource-unknown':'UNKNOWN',
        'forbidden-forced':'REJECTED','forbidden-graph':'REJECTED','synthesis-resource':'UNKNOWN','oracle-resource':'UNKNOWN'}
    assert len(q['controls'])==11 and {x['id'] for x in q['controls']}==set(expected_controls)
    for row in q['controls']:
        answer=checked(row['receipt']);assert answer['status']==expected_controls[row['id']]
        if 'raw' in row:assert checked(row['raw'])['status']=='UNKNOWN'
        if answer['status']=='UNKNOWN' and 'bounded_absence' in answer:assert answer['bounded_absence'] is False
    assert p['status']=='VERIFIED_FINITE_LITERAL_MARKING_LEARNING'
    acquisition,base,raw=verify_run(p['acquisition']);assert raw['status']=='SAT' and base==load('input/pilot-model-v1.json')
    assert base['pair_nogoods']==[] and base['seed']=={'t':[],'m':[]} and all(x['m']==[] for x in base['inventory']['placements'])
    assert len(p['labels'])==len(p['label_runs'])==len(p['catalog'])==3 and [x['pair'] for x in p['labels']]==p['catalog']
    for label,row in zip(p['labels'],p['label_runs']):
        run,model,raw=verify_run(row['run']);assert row['pair']==label['pair'] and row['label']==label['label']
        assert label['label']==('POSITIVE' if raw['status']=='SAT' else 'NEGATIVE') and model['pair_nogoods']==[]
        fixed_pair_association(base,label['pair'],model)
    history=[checked(e) for e in p['synthesis_history']];assert len(history)==4
    assert all(x['status']=='SOLVED' for x in history) and history[0]['assigned_values']==0 and all(x['m']==[] for x in history[0]['assignments'])
    assert [x['resolved'] for x in history]==[0,1,2,3] and all(x['unresolved']==0 for x in history)
    assert all(s['matched'] is True for s in history[-1]['score'])
    marked=checked(p['learned_model']);frozen=load('data/pilot/learned-model-frozen-v1.json')
    assert frozen['status']=='FROZEN_BEFORE_PRESERVATION_AND_SEARCH' and frozen['model']==p['learned_model']
    assert wire(frozen['history'])==wire(p['synthesis_history']) and wire(frozen['labels'])==wire(p['labels'])
    assert digest(wire(marked))==p['marking_model_sha256']==frozen['canonical_model_sha256']
    assert {x['id']:x['m'] for x in marked['inventory']['placements']}=={x['id']:x['m'] for x in history[-1]['assignments']}
    assert marked['pair_nogoods']==[] and marked['seed']==base['seed']
    pairs=[x['pair'] for x in p['labels'] if x['label']=='NEGATIVE']
    o=checked(p['preservation']);assert o['schema']=='Finite-marking-preservation-receipt-v1' and o['status']=='VERIFIED'
    assert o['subsets_coverage']==o['meeting_pair_coverage']==o['nogood_extension_coverage']=='COMPLETE'
    assert o['counts']['subsets_checked']==o['subsets_total']==16 and len(o['evidence']['subsets'])==16
    assert o['counts']['base_capacity_legal_subsets']==o['counts']['eligibility_states_checked']==8
    for k in ('marking_equivalence_failures','eligibility_equivalence_failures','domain_equivalence_failures','edge_equivalence_failures'):assert o['counts'][k]==0
    assert o['verdict']['solution_sets_equal'] is o['verdict']['every_nogood_absent_from_original_covers'] is o['verdict']['literal_marking_equals_pair_filter_every_capacity_legal_subset'] is True
    assert o['verdict']['original_solutions']==o['verdict']['marked_solutions']==o['verdict']['direct_solutions']==2
    assert o['evidence']['base_solutions']==o['evidence']['marked_solutions']==o['evidence']['direct_solutions'] and len(o['evidence']['base_solutions'])==2
    assert o['bindings']['base_model_sha256']==digest(wire(normalized_model(base))) and o['bindings']['marked_model_sha256']==digest(wire(normalized_model(marked)))
    assert o['bindings']['pair_nogoods_sha256']==digest(wire(pairs))
    assert o['models']['base']==normalized_model(base) and o['models']['marked']==normalized_model(marked) and o['models']['pair_nogoods']==pairs
    assert [dict(pair=x['pair'],label=x['extension_status']) for x in o['evidence']['meeting_pairs']]==p['labels']
    assert [x['lane'] for x in p['lanes']]==['BASE','MARKS','PAIR_FILTER'];lanes=[]
    for row in p['lanes']:
        run,model,raw=verify_run(row);assert raw['status']=='SAT'
        if row['lane']=='BASE':assert model==base
        elif row['lane']=='MARKS':assert model==marked
        else:
            expected=copy.deepcopy(base);expected['version']+=':ordinary-pair-filter-v1';expected['pair_nogoods']=pairs;assert model==expected
        lanes.append(dict(lane=row['lane'],run=run))
    actual_contexts=checked(p['acquisition']['refs']['semantic'])['dead_context_witnesses']
    assert p['failure_contexts']
    for w in p['failure_contexts']:
        assert any(wire(w)==wire(actual) for actual in actual_contexts)
        assert not w['context_preimage']['excluded'] and len(w['context_preimage']['selected'])==2
        assert [c for c,g in w['context_preimage']['selected']] in pairs
    assert len(p['marked_pair_replays'])==3
    for replay,label in zip(p['marked_pair_replays'],p['labels']):
        assert replay['pair']==label['pair']
        if replay['engine_calls']==0:
            assert label['label']=='NEGATIVE' and replay['status']=='REJECTED_BY_LITERAL_MARKING_AGREEMENT'
            assert replay['literal_assignments']==[x for x in marked['inventory']['placements'] if x['id'] in label['pair']]
        else:
            assert replay['engine_calls']==1 and label['label']=='POSITIVE';run,model,raw=verify_run(replay['run']);assert raw['status']=='SAT'
            fixed_pair_association(marked,label['pair'],model)
    assert acquisition['snapshots']+sum(x['run']['actual_snapshots'] for x in p['label_runs'])+sum(x['actual_snapshots'] for x in p['lanes'])+sum(x.get('run',{}).get('actual_snapshots',0) for x in p['marked_pair_replays'])==43
    assert checked(p['preservation_control'])['status']=='REJECTED'
    return dict(qualification=dict(cases=17,snapshots=143,controls=11,runs=qual),
        pilot=dict(status=p['status'],labels=p['labels'],acquisition=acquisition,lanes=lanes,
            preservation=p['preservation'],learned_model=p['learned_model'],synthesis_history=p['synthesis_history'],
            subset_count=16,capacity_legal_states=8,original_covers=2,equivalence_failures=0),
        previous_archive_separately_linked=PREVIOUS_EVIDENCE_URL)

def verify_protocol(relative,context_root=''):
    value=load(relative);assert relative==FROZEN_PROTOCOL['path'] and context_root=='';exact(relative,FROZEN_PROTOCOL)
    assert value['schema']=='Learned-literal-marking-protocol-v1' and value['status']=='FROZEN_BEFORE_SCIENTIFIC_IMPORTS'
    assert local(ROOT,relative).read_bytes()==wire(value) and value['phases']==list(PHASES)
    admission=load(SOURCE_ADMISSION);assert admission['status']==READINESS_STATUSES[SOURCE_ADMISSION]
    names=set()
    for folder in ('source','reference','input','plan'):
        for p in (ROOT/folder).rglob('*'):
            assert not p.is_symlink()
            if p.is_file():assert p.suffix!='.pyc' and '__pycache__' not in p.parts;names.add(p.relative_to(ROOT).as_posix())
    names.add(SOURCE_ADMISSION)
    for e in admission['reviewed']:exact(e['path'],e);names.add(e['path'])
    current=[reference(n) for n in sorted(names)];assert wire(current)==wire(value['files'])
    indexed={e['path']:e for e in current};assert wire(indexed[REVIEWED_DRIVER['path']])==wire(REVIEWED_DRIVER)
    executable=value['runtime']['executable'];assert Path(executable['path']).is_absolute()
    assert wire(pin(Path(executable['path'])))==wire({k:executable[k] for k in ('bytes','sha256')})
    assert value['runtime']['isolated']==value['runtime']['no_site']==1 and value['runtime']['dont_write_bytecode'] is True
    assert type(value['runtime']['isolated']) is type(value['runtime']['no_site']) is int
    assert value['master']['path']==str(PRIMARY_MASTER);assert wire(pin(PRIMARY_MASTER))==wire({k:value['master'][k] for k in ('bytes','sha256')})
    assert wire(pin(PRIMARY_MASTER))==wire(pin(local(ROOT,'reference/basic-tiling-algorithm.md')))
    phases=[]
    for phase in PHASES:
        sname='data/'+phase+'-started.json';started=load(sname);assert started['phase']==phase and type(started['pid']) is int and started['pid']>0
        assert started['protocol']==reference(relative);refs={'started':reference(sname)}
        result_name='data/'+phase+'-result.json';result=load(result_name)
        for key in ('invocation','observer'):
            name='review/'+phase+'-'+key+'.json';v=load(name);assert v['phase']==phase and type(v['pid']) is int and v['pid']==started['pid']
            assert v['frozen_postcheck']==value['status'] and v['postcheck_error'] is None
            if key=='observer':
                assert v['status']=='TERMINAL' and type(v['native_exit_code']) is int and v['native_exit_code']==0
                assert v['guard_reason'] is v['observer_error'] is v['reap_error'] is None
                assert v['log']['path']=='review/'+phase+'-native.log';exact(v['log']['path'],v['log']);refs['log']=v['log']
            else:
                assert v['status']=='COMPLETE' and v['error_type'] is None and v['scientific_status']==result['status']
                assert v['result']['path']==result_name and v['result']['complete_json'] is True;exact(result_name,v['result'])
            refs[key]=reference(name)
        refs['result']=reference(result_name);phases.append(dict(phase=phase,execution_admitted=True,native_exit_code=0,receipts=refs))
    return dict(path=relative,context_root=context_root,schema=value['schema'],phases=phases,
        source_pin_count=len(current),reviewed_driver=REVIEWED_DRIVER,science=verify_science(),**pin(local(ROOT,relative)))

def verify_report():
    b=load(REPORT_RECEIPT);assert b['schema']==BUILD_SCHEMA and b['status']==BUILD_STATUS
    assert b['protocol']['path']==FROZEN_PROTOCOL['path'];exact(b['protocol']['path'],b['protocol'])
    assert b['renderer_source']['path']==REPORT_BUILDER;exact(REPORT_BUILDER,b['renderer_source'])
    for e in b['artifact_pins']:exact(e['path'],e)
    assert set(b['outputs'])=={'main','data'}
    main=b['outputs']['main'];data=b['outputs']['data'];assert main['path']=='report/'+MAIN and data['path']==REPORT_DATA
    exact(data['path'],data);payload=load(REPORT_DATA);assert payload['schema']==DATA_SCHEMA and payload['status']==DATA_STATUS
    assert wire(payload['protocol'])==wire(b['protocol']) and wire(payload['phase_custody'])==wire(b['phase_custody'])
    coverage=dict(qualification_cases=17,qualification_actual_graphs=143,qualification_controls=11,
        catalog_pairs=3,synthesis_calls=4,subsets=16,capacity_legal_subsets=8,original_covers=2,pilot_actual_graphs=43)
    assert wire(payload['coverage'])==wire(b['coverage'])==wire(coverage)
    p=load('data/pilot-result.json')
    assert payload['base']==load('input/pilot-model-v1.json') and payload['marked']==checked(p['learned_model'])
    assert payload['labels']==p['labels'] and payload['catalog']==p['catalog']
    assert wire(payload['preservation'])==wire(checked(p['preservation']))
    assert set(payload['phase_custody'])==set(PHASES)
    for phase,context in payload['phase_custody'].items():
        inv=load('review/'+phase+'-invocation.json');obs=load('review/'+phase+'-observer.json')
        assert context['execution_admitted'] is True and context['native_exit_code']==0 and context['pid']==inv['pid']==obs['pid']
        assert context['worker_seconds']==inv['seconds'] and context['observer_seconds']==obs['seconds']
        assert context['worker_highwater_rss_bytes']==inv['maxrss']*(1 if inv['maxrss_units']=='bytes' else 1024)
        assert context['peak_polled_rss_bytes']==obs['peak_observed_rss_bytes']
    snapshot=ROOT/'publication/rendered-before-archive-links-v1.html'
    original=snapshot if snapshot.exists() else local(ROOT,main['path']);assert wire(pin(original))==wire({k:main[k] for k in ('bytes','sha256')})
    current=local(ROOT,main['path']).read_bytes();before=original.read_bytes()
    if END in current:
        assert current.count(BEGIN)==current.count(END)==1
        left,tail=current.split(BEGIN);middle,right=tail.split(END);assert left+BEGIN+right==before
    else:assert current==before
    return dict(status=b['status'],data=dict(path=REPORT_DATA,schema=DATA_SCHEMA,**pin(local(ROOT,REPORT_DATA))),
        build_receipt=reference(REPORT_RECEIPT),renderer_source=b['renderer_source'],main_original=main)

def inventory_from_manifest(manifest):
    assert manifest['schema']=='Learned-literal-markings-physical-multipart-evidence-v1' and manifest['inventory_file']==INTERNAL
    core={k:v for k,v in manifest.items() if k not in ('inventory_sha256','inventory_schema','inventory_file')}
    core['schema']=manifest['inventory_schema']
    core['parts']=[dict(number=p['number'],name=p['name']) for p in manifest['parts']]
    assert core['schema']=='Learned-literal-markings-physical-evidence-inventory-v1' and digest(wire(core))==manifest['inventory_sha256']
    return core
def verify_archive(folder,manifest):
    core=inventory_from_manifest(manifest);entries=manifest['files'];by_path={e['path']:e for e in entries}
    assert len(by_path)==len(entries)==manifest['original_files'] and manifest['all_originals_physically_stored'] is True
    assert sum(e['bytes'] for e in entries)==manifest['original_bytes']
    for e in entries:
        relative_name(e['path']);assert type(e['part']) is int and 1<=e['part']<=len(manifest['parts'])
    parts=[];verified=set()
    for number,part in enumerate(manifest['parts'],1):
        assert part['number']==number and part['name']==PART_STEM+'%03d.zip'%number
        archive=local(folder,part['name']);actual=pin(archive)
        assert wire(actual)==wire({k:part[k] for k in ('bytes','sha256')}) and actual['bytes']<=MAX_PART and actual['bytes']<50*1024*1024
        expected={e['path'] for e in entries if e['part']==number}
        with zipfile.ZipFile(archive) as z:
            assert len(z.namelist())==len(set(z.namelist())) and set(z.namelist())==expected|{INTERNAL}
            assert z.read(INTERNAL)==wire(core) and z.testzip() is None
            for name in sorted(expected):
                e=by_path[name];assert name not in verified and z.getinfo(name).file_size==e['bytes']
                with z.open(name) as stream:p=stream_pin(stream)
                assert wire(p)==wire({k:e[k] for k in ('bytes','sha256')});verified.add(name)
        parts.append(dict(number=number,name=part['name'],**actual,CRC='PASS'))
    assert verified==set(by_path)
    return dict(status='PASS',original_files=len(entries),all_original_files_physically_stored=True,
        all_original_paths_byte_verified=True,all_CRC_verified=True,parts=parts)
