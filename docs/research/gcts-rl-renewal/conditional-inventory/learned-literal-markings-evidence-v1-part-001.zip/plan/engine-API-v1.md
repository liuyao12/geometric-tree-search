# Engine v3: Source-only pair-filter control

`source/growing_point_search_v3.py` is a minimal adaptation of the unchanged
preceding milestone's `reference/upstream/growing_point_search_v2.py`:
39,556 bytes, SHA256
`6e9687145ec2c86719266e07f7ddee4077d88a386c67152dec368657eae43cbb`.
The full diff is `review/engine-adaptation-v1.patch`. The copied master reference
was read before editing; SHA256
`c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9`.
No engine, model helper, solver or checker has been imported or executed.
Root and the independent reviewer must read the full Source before execution.

## Entry point and model

The entry point remains:

```python
solve(model, limits, *, enumerate_incident=None, order=None, audit=None)
```

The engine version is `IP-GROWING-POINT-SEARCH-v3`. The model schema is
`Z-growing-point-model-v2`, with exactly seven fields: the existing `schema`,
`version`, `capacity`, `roots`, `seed`, `inventory`, plus mandatory
`pair_nogoods`. BASE and MARKS supply `pair_nogoods=[]`; the engine never invents
pairs, learns them, or accepts a missing key as a default.

`pair_nogoods` is a list of two-element lists of native nonempty CID strings.
Each pair must have its smaller CID first, the outer list must be strictly
lexically increasing, and both distinct IDs must exist in the full EXPLICIT
inventory. Unknown IDs, self-pairs, duplicates, unsorted pairs, nonlists and
incorrect types raise the existing `InputError`. Normalization copies the
pair rows; callers' JSON is not mutated.

Nonempty pairs are EXPLICIT-only. The prior CERTIFIED_INCIDENT eager/indexed
interfaces remain available with mandatory empty pairs; nonempty pairs are
rejected for either provider mode before any pair-ID lookup. Their external
complete-universe obligation is unchanged. The pilot's independent checkers
may deliberately admit only EXPLICIT models, a narrower documented scope.

## Conventional filter semantics

A candidate is eligible exactly when it passes the old selection/exclusion,
positive-capacity and literal-marking checks, and none of its declared pair
neighbors is selected. This is an ordinary binary incompatibility filter.
The pair input alone is not evidence that it preserves the original problem;
that certificate and scope are caller-owned, separate gates.

The engine constructs an immutable `MappingProxyType` from each involved CID
to a sorted tuple of neighbors. It is copied from the normalized model before
search and is not branch state. Placement additionally refreshes those
neighbors, even when their positive/mark support does not meet the chosen row.
Every removed/restored eligibility and incidence uses the existing trail.
Exclusion does not select a CID and therefore needs no neighbor propagation.
Undo remains the unchanged uninterruptible inverse-delta routine; there are no
new rollback callbacks, mutable pair counters or stale neighbor caches.

The scheduler and `_search` body are unchanged: global dead, global forced,
then earliest generation with existing degree/key ties and complete fallback.
Pairs do not supply candidate lists, change the universe, reorder candidates,
or create an extra search strategy. Literal markings continue to use the
original point assignment/refcount/dependency machinery; MARKS performs no
runtime pair-nogood lookup beyond an empty index.

## Certificates, outputs and accounting

Before a positive certificate is emitted, the engine reconstructs chosen IDs
from its certificate rows and scans the original normalized pair list directly.
It rejects any selected forbidden pair independently of the neighbor index and
incremental eligibility. This is an internal consistency recomputation; an
independently authored checker remains required for scientific admission.

The result schema remains `Z-growing-point-search-result-v1`. Its top-level,
certificate, snapshot, event, provider-evidence and stats field sets remain
unchanged. No pair table is added to snapshots: the normalized model hash binds
the immutable index's source data. Consequently a consumer must retain and
validate the full v2 model to interpret a result; it cannot apply an old v1
checker while ignoring the new model field.

Pair validation, index construction, neighbor scans and neighbor refresh work
are charged to the existing cooperative meter. The seven limit fields and
sticky UNKNOWN/resource behavior are unchanged. Existing `work` includes this
additional cost. Existing `dependency_links` continues to count positive/mark
dependencies only; no new pair counter is inferred from that field. Graph edits
and legality checks use the old counters. Even empty-pair models have minor
schema/index/check accounting overhead, so old mixed work totals need not match
bit-for-bit; this is not a performance or equal-work claim.

## Required future qualification; not executed here

Root will prospectively migrate every old tiny fixture by explicitly changing
the model schema and adding empty pairs, preserving the original six field
values. Independent full graphs/events, semantic replay, terminal certificates
and exhaustive tiny solutions must agree, with nonsemantic version/hash/work
differences labeled. Pair controls must exercise remote noncontact removals,
multiple selected neighbors, restoration after failed branches, selected-once
capacity, global dead/forced/generation order, and final pair rejection.
Malformed/unknown/unsorted/duplicate pairs, nonempty indexed pairs and resource
interruption also need qualification. Mark controls must retain assigned zero
versus absence and far mark-only dependencies.

No supplied bad pair or marking assignment appears in this Source. Future
learned inputs must be obtained and admitted under the separately frozen pilot
protocol. Until those checks run, this is reviewed Source awaiting execution,
not an achieved conformance, preservation, learning or speed result.
