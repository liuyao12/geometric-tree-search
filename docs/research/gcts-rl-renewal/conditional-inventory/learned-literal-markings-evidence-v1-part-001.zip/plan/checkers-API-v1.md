# Independent model-v2 / engine-v3 checkers

Status: **SOURCE_ONLY_NOT_IMPORTED_OR_EXECUTED**. Root must review the full
Sources and prospective qualification before any scientific imports or calls.
The master copy at the previous semantic-assurance root was read in full,
SHA-256 `c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9`.
Current and previous published roots were not modified.

## Sources and exact baselines

| Current Source | Bytes | SHA-256 |
| --- | ---: | --- |
| `source/semantic_event_checker_v2.py` | 41439 | `5258610eb83b284593a0905c09c9a3e1f66d7892c9a98c4b7271ba1755b0609d` |
| `source/frontier_trace_checker_v2.py` | 28667 | `a0417e25f321c86d7d243bbf35fbc63e5ce0bc81faf8adbe0e4ec31e066d2331` |

The semantic baseline is the exact qualified previous
`source/semantic_event_checker_v1.py`, 39367 bytes, SHA-256
`6985af4d1f56789c1237522141b1d04815370566dd99cb22da6a048eb6bc0613`.
The full-observation baseline is the exact previous
`reference/upstream/frontier_trace_checker_v1.py`, 27040 bytes, SHA-256
`01f46bdf34b414c7470f75f1507f3e76bfefa739533fcc4b2fd121900378343f`.
Both were copied from the noncloud semantic-assurance root after byte checks.
The complete adaptation is `review/checkers-adaptation-v1.patch` (15282 bytes,
SHA-256 `ee325181861a0f30955aa7e0025246692573b541707fbec73d51911a054a9e5c`).
No engine, helper, native kernel, or other checker is imported by either Source.

## Public calls

```python
# Semantic events plus actual serialized endpoints; lexical-order profile.
C.verify_explicit_events(model, result, *, max_items, max_work, wall_seconds)

# Actual full callback observations; exhaustive graph re-enumeration.
T.verify(model, universe, observations, result,
         *, max_items=10000000, wall_seconds=30.0)
```

The semantic checker still exposes `Meter` and `Reader` for the separately
bounded qualification-only graph comparison. These are pinned private APIs;
derived snapshots must be compared with actual producer observations, never
submitted to another checker as fabricated observations.

## Exact model and result profile

Both checkers now require `schema='Z-growing-point-model-v2'`, the original six
model fields, and mandatory `pair_nogoods`. The pilot profile is **EXPLICIT
only**, including when the list is empty. Both full explicit inventories must
agree exactly in `T`. Provider inventories return unsupported/UNKNOWN rather
than acquiring an unqualified new scope. The producer may separately preserve
CERTIFIED support with an empty list; these two pilot checkers do not admit it.

`pair_nogoods` must be a list of two-element lists of literal, nonempty CID
strings. Each pair has its first CID strictly lexically before its second;
both IDs belong to the full explicit universe. The outer list is strictly
lexically increasing, hence sorted and unique. Missing fields, repeated IDs,
unknown IDs, reversed pairs, duplicate pairs, or nonnative values reject.
Existing positive-support, assigned-mark, root, capacity and exact native-type
checks remain unchanged.

The model hash includes the new schema and exact pair list. The expected raw
engine version is `IP-GROWING-POINT-SEARCH-v3`. The result schema remains
`Z-growing-point-search-result-v1`; its field set, event fields, snapshot fields,
certificate fields, and statistic names are unchanged. In particular,
`dependency_links` still counts registered positive and marking support only;
the extra immutable ordinary-filter index is charged as work, not relabeled as
marking support. The thirteen old fixture models must migrate explicitly to
model schema v2 with `pair_nogoods=[]`; old artifacts remain untouched.

## Independent pair semantics

A candidate is unavailable if a declared pair joins it to a currently selected
CID. Selected/excluded membership, full total compatibility and literal marking
agreement retain their previous meanings. Excluding a candidate does not
select it and therefore does not activate its pair conflicts. Pair constraints
are frozen/model-bound, not branch-local learned state.

`C` builds its own read-only-by-convention neighbor tuples from the validated
pair list, with metered construction. Its global legality predicate checks
selected neighbors. Selecting a CID refreshes every such neighbor in addition
to all candidates affected through positive or extended marking dependencies.
All eligibility/edge changes remain on the checker's own reversible trail, so
restoring a parent restores exactly those effects. The global scheduler,
generation convention, branch stack and failed-child provenance are unchanged.

`T` deliberately does not use that index. During full graph reconstruction it
scans the literal declared pair list for every candidate, using only its own
selected set. It therefore checks actual observed eligibility/domains/reverse
edges against exhaustive pair-aware legality. Both checkers independently scan
the original pair list again for a terminal selected certificate.

Both VERIFIED receipts add `pair_nogood_count` and
`pair_filter_scope='DECLARED_ORDINARY_FILTER_NOT_MARKING_AGREEMENT'`. Existing
semantic/full-observation reason and claim labels remain, with explicit scope
text that pair redundancy is not proved by these checkers.

## Preserved assurance and refusal behavior

`C` requires complete retained events/hash, a terminal SAT/UNSAT association,
actual exact entry/final/restored endpoints, exact positive selection and point
certificate, and native semantic statistic joins. It accepts reported audit
calls zero/full only as metadata on completed results; it receives no actual
intermediate observations. Partial rollback metadata may still be VERIFIED as
explicit PREFIX coverage after all retained rows and expected total are checked.
Raw UNKNOWN and event-prefix/resource refusals never certify absence.

`T` requires the actual complete callback stream, re-enumerated full graphs,
complete retained rollback/provider evidence according to the inherited API,
and terminal/result/endpoint joins. It preserves the inherited distinction
between an observed graph and a reconstructed semantic state. Resource limits
refuse rather than manufacture completeness. Existing input/string/key/depth
and work/wall guards are preserved; new pair loops are metered.

Failure provenance and bounded semantic dead-context witnesses are preserved.
Their model hash now also scopes the pair constraints. A filtered-lane failure
does not establish unfiltered failure or justify its own pair rule. Learning,
failure-certificate extraction, all-cover preservation, and equivalence to
literal point markings require Root's separate independent gates. These
checkers validate the **declared** filtered problem; they do not prove those
constraints redundant or discover learned marks.

## Prospective qualification obligations

In addition to the migrated thirteen cases, use fresh controls where the two
pair CIDs share no positive or marking support, so an omitted neighbor refresh
cannot hide behind existing dependencies. Cover selected/excluded distinction,
forced-domain effects, nested rollback, extended marking-only ports, and
malformed pair lists. Test baseline traces forged under a nonempty declared
pair list and pair-filter traces forged with stale observed domains. Independently
enumerate all candidate subsets outside E/C/T for any preservation claim.

No import, model construction, test, engine/checker/oracle call, or experiment
was performed in this Source handoff. AST parsing and direct byte/diff review
only do not constitute qualification or a performance result.
