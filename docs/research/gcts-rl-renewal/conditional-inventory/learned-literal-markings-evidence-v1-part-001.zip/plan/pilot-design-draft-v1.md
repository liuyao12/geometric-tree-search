# A smallest proposed literal-marking learning gate

**SOURCE-ONLY DRAFT; supplied analytic fixture, no execution or test results.**
Only this document is created in this new root. The published semantic-certificate
milestone and every earlier run remain immutable. No scientific helper, solver,
oracle, model builder or checker has been imported or called.

The master was read from `docs/basic-tiling-algorithm.md`, SHA256
`c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9`.
The inspected SQ13 declaration is in the preceding milestone's
`plan/semantic-qualification-cases-v1.json`, SHA256
`b896bc107b91544ac7f6b9c9ec1bd25e987cb3f508558f44c337c3ee3a2fada7`.
Its fixed-marking and ternary-expressivity notes supply analysis; they are not
learned constraints. This proposal follows the complete graph, global
dead/forced/generation order, literal-zero and exact-rollback requirements.

## SQ13 is a poor pair-pruning target

It would be incorrect to say SQ13 has no globally forbidden capacity-legal pair.
Besides its distinguished nonextendible triple, the four pairs
\(X_{b,i},X_{c,j}\) are capacity-legal and unextendible: together they saturate
\(p\), while every way to fill root \(a\) adds more positive contribution at
\(p\). A redundant marking could encode those pair conflicts.

They do not help the exact existing fixed-lexical search. Initially all three
root domains have degree \(3\); root \(a\) is selected first. Choosing \(X_A\)
already saturates \(p\), making every \(X_B,X_C\) capacity-illegal. Choosing
\(A\) leaves one unit there; subsequently choosing an \(X_B\) or \(X_C\)
saturates \(p\), so base capacity already removes the other family. Thus the
four extra conflicts eliminate no additional legal candidate at a reachable
prefix of that scheduler. All remaining capacity-legal pairs occur in complete
covers, including every pair of \(A,B,C\). Preserving all original solutions
therefore leaves no useful new pairwise marking prune along this search; fixed
equality markings still cannot directly forbid precisely \(A,B,C\).

This is an analytic statement about this finite inventory, roots and scheduler,
not a new executed all-pair census or a limitation of every context encoding.

## Proposed four-row unmarked input

Use capacity \(3\), exact integer units, roots \(a,b\), empty seed and initially
absent markings. For a concrete integer point domain take
\(a=(0,0)\), \(b=(2,0)\), \(p=(1,1)\). Identity is the only allowed transform;
each CID is selected at most once. Nonlisted contributions are zero.
Write \(u_c(r)\) for the listed integer units. The normalized master-reference
tile values are \(t_c(r)=u_c(r)/3\), and write \(U(r)\) for the sum of units.

| Placement | Positive point units |
| --- | --- |
| \(A\) | \(u_A(a)=3,\ u_A(p)=1\) |
| \(B\) | \(u_B(b)=3,\ u_B(p)=1\) |
| \(X\) | \(u_X(a)=3,\ u_X(p)=2\) |
| \(Y\) | \(u_Y(b)=3,\ u_Y(p)=2\) |

This is Root/oracle-supplied analytic input, not an automated discovery. The
generator receives only these rows, roots, inventory identities and bounds;
no selected solution, expected derivation or marking assignment is passed to
search. With deterministic CID order \(A<B<X<Y\), the predicted unmarked search
chooses \(A\), then \(B\). After \(A\), root \(b\) at generation \(0\) and
new point \(p\) at generation \(1\) each have domain \(\{B,Y\}\). No forced
move prevents the bad choice. Selecting \(B\) is capacity-legal but leaves
\(U(p)=2<3\) with an empty domain, since both selector roots are saturated.
This is a reachable remote residual failure, rather than direct overlap.

Each bad-pair member separately occurs in a full cover. Analytically the only
full covers use \(A,Y\) or \(B,X\); those observations are design checks, not
solver witness inputs. A later independent assignment oracle must enumerate
all \(2^4=16\) subsets and decide the actual complete solution sets.

## Acquire all labels, then synthesize and freeze

1. Freeze Source/runtime/master, full input universe and limits before any run.
   Run unmarked acquisition with the complete graph; retain the actual failed
   branch and semantic certificate. A parent-local exclusion is not yet a
   global pair nogood: its fixed context and any previous exclusions matter.
2. Enumerate the entire initially capacity-legal meeting-pair catalog. For this
   supplied input the predicted catalog is \(AB,AY,BX\). Use **all** resolved
   catalog labels, as master section 6 requires; reserve no pair-label holdout.
   Label each pair by a separate complete unmarked fixed-pair extension problem
   with original roots/inventory, the two fixed CIDs counted once, and all their
   exposed positive obligations activated. Preserve any resource refusal as
   unresolved. Bind every certificate to the full target, fixed pair, seed,
   inventory and activation semantics. Unknown labels impose no constraint.
3. Start the learner with every component absent. Give it one prospective
   mark-only site \(q=(1,3)\) and allowed component states absent, literal
   \(0\), literal \(1\). Exhaustively search the \(3^4\) assignment templates:
   positive labels require agreement, certified negatives require a conflict.
   Choose a canonical minimum-assignment solution; color renaming is immaterial.
   Do not hardcode which placements receive which values. If synthesis refuses
   or fails, retain the unmarked fallback and report that outcome.
4. Before activation, independently compare the **entire** marked and original
   finite solution sets over all subsets; label replay alone is not the general
   preservation argument. Require equality, unchanged positive rows/CIDs and
   literal marking semantics, including assigned zero versus absence. Freeze
   the admitted marking version before a fresh search; no mid-search learning.
   Also enumerate every base-capacity-legal partial subset and check that its
   literal marking compatibility equals the ordinary learned-clause test;
   reconstruct complete candidate domains at those states independently.

An anticipated two-assignment encoding would place opposite literals on the
bad pair at \(q\), leaving the alternatives absent. That is a supplied
expressibility check only. The actual learner output, label order, changes,
unresolved count, support size and preservation receipt must be saved. Any
result using a preloaded expected assignment fails the experiment.

## Controls, scope and falsification

Use three separately initialized searches: unmarked BASE, learned literal MARKS,
and ordinary PAIR-FILTER. The filter receives exactly the same certified binary
nogoods, never the target proof. It removes candidates through the same complete
frontier graph; it must not substitute a shortlist/provider-restricted universe.
Any necessary filter hook is a separately reviewed control extension and needs
independent domain/rollback qualification. No hidden representation advantage
from explicit versus indexed inventories is acceptable.

All lanes retain every base CID, the same target/seed, scheduler, lexical tie
order, node budget, wall/CPU/RSS and evidence/storage bounds. Charge acquisition,
synthesis/encoding, preservation checking, model setup and assurance separately
and in end-to-end totals. Compare common logical node/placement counts; mixed
work meters are not equal units. Keep engine UNKNOWNs and capture loss explicit.
An unresolved or unproved constraint falls back to BASE; marked failure is an
original negative only after complete preservation and search certification.
No sampled proposal is used to declare a base domain dead or forced.

The binary filter and literal layer contain the same deductive information.
Arbitrary per-CID ports demonstrate a **finite anchored proof-search adaptation**,
not a geometric or RL advantage. Prototype/transform-consistent reusable tile
markings, lattice-wide support and target transfer require separate design and
preservation proofs. No RL is needed for this first gate.

There is no held-out target in this minimum mechanism check and no held-out pair
split. All catalog labels are used. Future held-out targets must be separately
declared and frozen; a fixed-target negative does not transfer automatically
after changing roots, boundary, seed or inventory. Renamings/translations require
a verified whole-model action and are equivariance checks, not new structural
generalization. A later genuine structural test needs its own scope-admission
argument, not reused target-specific labels disguised as a holdout result.

Falsify the pilot if the bad pair is not reached by unmarked acquisition, its
negative certificate needs an unreported extra exclusion, any complete solution
is lost, any unresolved sample becomes negative, MARKS does not act through
literal assignments, or filter/marked domains disagree under equivalent clauses.
If both controls avoid the same failed branch, that establishes the mechanism;
it does not establish geometric benefit. Tiny timing may be dominated by setup.
Any speed claim requires a later prospectively frozen nontrivial cohort with
equal assurance and full costs. This document records no test result.
