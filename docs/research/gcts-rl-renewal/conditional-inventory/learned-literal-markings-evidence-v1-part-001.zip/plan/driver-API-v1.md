# Fresh finite literal-marking experiment

Status: **SOURCE_ONLY_PENDING_REVIEW_AND_FREEZE**. No scientific module has
been imported or run. The design is supplied analysis, not a discovered theorem.

`source/run_marking_pilot_v1.py` orchestrates the same E3 engine, independent
semantic checker C2, whole-snapshot re-enumerator T2, independent assignment
oracle O and label-only synthesizer L. Scientific imports occur inside an owned
worker only after an exact prospective freeze and Root source-review admission.

## Commands and custody

Run with the pinned Python executable and `-I -S -B`:

```text
source/run_marking_pilot_v1.py freeze
source/run_marking_pilot_v1.py run qualify
source/run_marking_pilot_v1.py run pilot
```

The `freeze` command imports only the driver's standard libraries. It records
every file under `source/`, `reference/`, `input/`, `plan/`, Root's admission and
all files pinned by that admission, the exact interpreter bytes/version/flags,
all helper/process/capture limits and the two phases. The current primary
master was freshly read and matches the exact local `c1327e5e` normative copy.
Both are byte-bound at freeze, and the current master is rechecked before and
after each phase. All prior milestones remain immutable. Runtime and frozen file set are
checked before and after each phase; no Source or frozen input may be changed.

Each phase owns one child, fresh output paths and an exclusive native log. It
refuses any previous started/result/invocation/observer/log path. The outer
guard sets CPU limits, polls only that child's RSS, enforces wall time, records
guard/reap errors and actual native exit, and reaps an owned killed child. An
observation timeout is not permission to restart. A failed process or scientific
gate retains its files and log and cannot silently rerun. Polled RSS is not an
instantaneous memory guarantee. Native zero and scientific acceptance are
separate requirements.

Before `pilot`, the actual qualification observer/invocation/started PID,
phase, protocol, native exit, frozen postchecks, native log and complete result
bytes must join. All seventeen qualified-case artifact pins and control pins
are rechecked; status strings alone are insufficient. No checker is rerun by
this custody check.

## Prospectively fixed limits

Every ordinary E3 call has wall three seconds, work one billion, nodes ten
thousand, events and rollback rows ten thousand each, candidate cap one
thousand and active-point cap one hundred twenty-eight. C2 has thirty seconds,
one hundred million items and ten billion work units. T2 has thirty seconds and
one hundred million items. O has ten seconds, sixteen candidates, at most
\(65{,}536\) subsets and one billion declared work units. The larger prospective
O cap preserves the old twelve-CID fixture's entire \(4{,}096\)-row evidence
table; no subset has been executed to tune the cap. L has ten seconds, one
hundred thousand patterns and ten million loop units. These meters differ and
are not common CPU instruction units.

Each owned process has wall \(1{,}200\) seconds, CPU \(900\) seconds and polled
RSS one GiB. Each saved JSON has a sixteen-MiB logical capture bound; overflow
retains a refusal prefix and prevents admission. Every raw engine result and
actual callback snapshot stream is saved before verification. Timing includes
separate helper call and serialization stages. Phase elapsed time includes
setup, qualification/acquisition, learning, preservation, assurance and I/O.

## Qualification phase

Thirteen prior model declarations are prospectively migrated by changing only
the model schema to v2 and explicitly adding empty `pair_nogoods`. Prior six
field values and required scheduler/graph observations are preserved. They are
known qualification fixtures, not a new held-out benchmark.

Four additional model-defined ordinary-pair controls exercise distant
noncontact elimination, multiple selected neighbors and rollback, complete
pair-filter exhaustion, and interaction with assigned literal zero at a
mark-only point. Their pair rules are qualification input, not learned or
claimed redundant. Each of the seventeen E3 problems is run exactly once with
actual graph callbacks; public C2, T2 and a separate private C2 Reader pass must
agree on every saved graph/event. O independently enumerates the entire finite
inventory and must agree on existence. Required observations are checked
against actual snapshots, not fabricated renderer graphs.

Eleven controls are declared: six malformed pair inputs must raise E3
`InputError`; a one-unit engine work refusal must remain raw/semantic unknown;
a changed forced CID must be rejected by C2; a self-consistent graph with a
forbidden CID reinserted must be rejected by T2; one-pattern synthesis and
one-subset oracle caps must remain unknown. All mutant inputs are saved before
the relevant call. There are seventeen ordinary, six malformed and one
resource-limited engine attempts. No successful control is called a theorem.

## Pilot information flow

The consumed input is only the four-row unmarked model and the declared
single mark-only site. The analytical expected covers, bad pair and marking
are in the design document but are not consumed by E3, the labeler or L.

1. A fresh unmarked acquisition is saved and independently checked. Record
   actual dead contexts having exactly two selected CIDs and no parent-local
   exclusions. They remain context witnesses until a separate fixed-pair
   extension certificate establishes finite global pair absence.
2. Enumerate every initially capacity-legal positive-support meeting pair.
   Every pair gets a separate unmarked fixed-pair E3/C2/T2/graph call. Its two
   rows become an explicitly summed fixed seed; those exact CIDs are removed
   from the remaining inventory, and all exposed positive points become
   roots. The original finite roots are also required. This is finite global
   extension, not a geometric corona or a plane claim. The labeler never uses
   provisional markings or learned pairs.
3. L starts with every component absent. Save the initial output and then a
   fresh synthesis after each label, using the whole accumulated catalog.
   Its only input is sorted CIDs, pairs with positive/negative labels, the
   declared site and bounds. L enumerates all absent/literal-zero/literal-one
   templates, minimizing assigned components then a canonical vector. It
   receives neither proof witnesses nor an expected marking. No catalog pair
   is withheld. Unknowns never become negative labels: a nonconclusive engine
   or assurance gate aborts the attempt after saving evidence and prevents
   marking activation; no silent retry occurs.
4. Freeze the actual synthesized model and its hash before O runs. O's full
   cover sets and pair census must never train or repair L. O must independently
   prove all original covers are preserved, every learned ordinary pair is
   absent from all original covers, and literal marks and the pair filter give
   equal compatibility, eligibility, domains and weighted edges at every
   base-capacity-legal partial subset. A refusal prevents activation.
   Only after that freeze, independently compare O's complete pair census and
   cover-based labels to the acquisition catalog and actual labels; a mismatch
   refuses admission and never repairs or retrains the learner.
5. Run separate fresh E3 states for BASE, MARKS and PAIR_FILTER. They share
   all positive rows, CIDs, roots, seed, candidate universe, scheduler, lexical
   ties, budgets and assurance. MARKS uses actual assigned point values and
   empty pairs; PAIR_FILTER uses empty original markings and the same certified
   binary information as ordinary pairs. Acquisition and the later BASE lane
   are distinct predeclared roles, not retries. All calls are in one warm
   process in fixed order; this is no cold-runtime or speed comparison.
6. Replay all catalog pairs with the learned marks. A fixed pair whose literal
   assignments disagree is rejected immediately by point-value agreement,
   with the actual pair rows saved and zero extra E3 calls. A compatible fixed
   marked pair receives a separate E3/C2/T2/graph completion check. Independent
   O covers the same literal compatibility. Deliberately force a positive
   labeled pair to disagree as a preservation-checker refusal control; this
   corrupted model is never used by the learner or any measured lane.

The anticipated successful four-row path would use nine pilot E3 calls: one
acquisition, three pair labels, three lane states and two compatible marked-pair
replays. That count is a declared expectation, not an observed result. Actual
calls, refusal paths, snapshots and costs remain authoritative saved evidence.

## Claim and remaining scope

A successful pilot would establish finite anchored literal-marking learning
and an exactly equivalent ordinary filter. It would not show an advantage over
that filter, discovery of a new mathematical theorem, a translation-equivariant
geometric tile marking, target transfer, a receptor-family compiler, RL, uniform
Wang/FOL completeness, a substitution rule or a whole-plane tiling. The fixed
equality-marking obstruction for a purely ternary failure remains separate.
The full research goal remains active.
