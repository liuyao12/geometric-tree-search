# Independent finite marking-preservation oracle

Status: **SOURCE_ONLY_PENDING_ROOT_REVIEW_AND_FREEZE**. No scientific module,
model constructor, engine, checker, learner, oracle or native kernel has been
imported or executed for this Source task. Only static parsing is authorized.
The primary CWD was avoided; the exact prior local master copy was read:
\(21{,}657\) bytes, SHA256
`c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9`.
Root will provide the new root's reference snapshot before the freeze.

Source: `source/marking_preservation_oracle_v1.py`, standard-library imports
`hashlib`, `json`, `math`, `time` only. No engine/checker/learner/model-helper
imports, witness input, expected solution or scheduler implementation.

```python
verify(base_model, marked_model, pair_nogoods, *,
       max_candidates=16, max_subsets=65536,
       wall_seconds=10, max_work=10000000)

enumerate_model(model, *,
                max_candidates=16, max_subsets=65536,
                wall_seconds=10, max_work=10000000)
```

Both APIs share independent normalization, complete point summation, literal
mark agreement, pair checking and positive-support reachability primitives.
Generic enumeration uses one model; preservation uses a joint subset pass to
compare the two representations without materializing three duplicate state
tables. The control is an ordinary pair filter over the unmarked base rows.

## Exact model profile

The model has precisely the old six fields plus mandatory `pair_nogoods`:

```text
schema: Z-growing-point-model-v2
version: nonempty string
capacity: positive native integer, at most 256 bits
roots: unique literal strings
seed: {t:[[point,integer_units],...], m:[[point,literal_string],...]}
inventory: {kind:EXPLICIT, placements:[{id,t,m},...]}
pair_nogoods: [[CID_a,CID_b],...]
```

Placements have distinct nonempty string IDs, nonempty positive support and
positive native integer units at most capacity. Seed units may be zero. Point
rows cannot duplicate a point. Markings are strings; a missing row is
unconstrained. An explicitly stored `"0"`, `""` or `"*"` is a literal assigned
value, never a wildcard. A free component is represented by omission.
Booleans/floats cannot impersonate capacity, units, limits or indices.

Every pair is a literal two-element list of distinct existing CIDs in strict
lexical order. The entire list is strictly sorted and duplicate-free. Malformed
or noncanonical pairs are rejected rather than silently repaired. Normalization
sorts point rows, roots and inventory IDs, and binds canonical sorted ASCII JSON
with a final LF. Version labels may differ between base and marked models;
each is included in its own bound hash.

`enumerate_model` permits ordinary seed/per-placement markings and nonempty
canonical model pair constraints. It is the independent qualification path for
the migrated tiny models and new pair controls. It returns `EXHAUSTED` only
after checking every subset, with Boolean `exists`, exact `solutions`, full
`subsets` and `counts`. `UNKNOWN` has `exists=null` and may retain actual prefix
evidence and a positive witness flag; it never asserts absence.

`verify` additionally enforces the pilot restriction: base seed and per-CID
markings are all empty; both model pair lists are empty; marked seed markings
remain empty; normalized capacities, roots, seed positive data, CIDs and every
per-CID positive contribution are identical. Only per-CID literal markings can
change. The separately passed pair list is the learned conventional control.

## Exhaustive assignment meaning

Let \(C\) be the integer capacity and \(u_c(p)\) the integer units stored in
the code's `t` rows. The master's normalized tile value is \(t_c(p)=u_c(p)/C\).
For each subset \(S\) of the fixed inventory, recompute integer totals from scratch

\[
U_S(p)=U_0(p)+\sum_{c\in S}u_c(p),\qquad
Q_S=R\cup\operatorname{supp}^{+}(U_0)
       \cup\bigcup_{c\in S}\operatorname{supp}^{+}(u_c).
\]

Nonroot seed zeros are retained totals but do not activate points. A complete
cover has \(U_S(p)=C\) everywhere in \(Q_S\), no overcapacity anywhere, consistent
literal markings and no contained forbidden pair. All selected placements must
be connected by an iterative positive-support contact order to roots or positive
seed. Final capacity and marking legality are monotone, so such an order gives
a legal attachment order; it is not the GCTS scheduling algorithm. Empty active
targets allow the empty solution. Unrooted extra islands are not solutions.

Every CID is used at most once. The mask indexes the lexically sorted
`candidate_ids`, so the full evidence has exactly \(2^N\) rows on completion.
No generation metadata or chronological selection order is invented.

For **every** base-capacity-legal subset, including unreachable or already
mark-inconsistent subsets, `verify` checks:

- Literal whole-family mark compatibility is equivalent to containing no
  forbidden pair.
- Every unselected candidate's whole positive support and complete extended
  marking support are checked independently. The marked eligible set equals
  the direct-filter eligible set.
- At every active point with residual capacity, the full candidate domains
  and their exact weighted incidences agree.

Eligibility means adjoining the candidate preserves the entire selected-family
constraint. An already incompatible family has no eligible extension under
either representation. There is no assumption that such a family is an actual
engine state. Candidates need not touch the frontier to be globally eligible;
only incident candidates appear in frontier domains. Common branch-local
exclusions can be subtracted from both equal graphs; the oracle does not check
the engine's exclusion/rollback implementation.

The exact rooted original, marked and direct-filter cover sets must be equal.
Every passed pair must occur in no original cover. These are separate gates:
matching local encodings cannot by itself establish preservation.

## Complete pair catalogue and saved evidence

After complete subset enumeration, `verify` separately enumerates all distinct
unordered pairs whose positive supports meet and whose combined positive data
with the original seed are capacity-legal. No marking or learned filter selects
that catalogue. Each pair is labeled `POSITIVE` if at least one complete
original cover contains it, otherwise `NEGATIVE`, with all corresponding saved
solution masks. This is finite global extension in the anchored inventory,
not a geometric corona, unrestricted growth or a learner label input.

The preservation receipt has `status=VERIFIED|REJECTED|UNKNOWN`, `reason`, actual
`counts`, `bindings`, normalized `models`, `candidate_ids`, `subsets_total`,
phase and separate subset/catalogue/nogood-extension coverage. Its `evidence`
contains every completed subset row, the exact original/marked/direct solution
lists, complete meeting-pair catalogue and all passed-pair cover checks.
Subset rows record selected CIDs, totals, active points, reachability, full
literal marking value/reference-count groups, constraint flags, solution flags,
global eligible sets, both frontier domain tables and both weighted edge tables.
For overcapacity subsets, domain fields are `null` and make no legality claim.

`VERIFIED` requires all equality, pair absence and domain/incidence gates to
pass. A completed counterexample returns `REJECTED` with the full enumeration
and failure counters. Malformed inputs are `REJECTED` without pretending full
coverage. Resource, depth, memory or time refusal is `UNKNOWN`, even when useful
prefix evidence or counterexamples were retained. A complete subset table with
an interrupted later pair-catalogue phase still yields overall `UNKNOWN`.

## Limits and use

Maximum supported candidate cap is sixteen and subset cap is \(65{,}536\).
Nonnegative native `max_work` and `max_subsets` allow explicit zero-budget
refusals; wall time must be finite, positive and at most sixty seconds. Generic
and preservation calls share these bounds. `verify` enumerates one joint mask
table, not three separately charged full enumerations.

Work charges input strings/keys, structural scans, fresh complete support and
constraint checks, output reservations and hashes. Long loops check time.
The conservative output-byte reservation is reported separately. Defaults do
not guarantee completion for every maximum-sized inventory. No partial table
is silently truncated and promoted to a preservation proof. The caller must
persist the entire actual receipt; write/capture caps remain a separate gate.

Preservation runs **after** the learner, pair control and marked-model freeze.
Its exhaustive solutions and pair labels must not train or repair that learner.
The pure API does not know when it is called; Root's driver/source custody must
enforce this direction of information flow. Generic qualification is a separate
frozen-model use. This oracle proves only the declared finite anchored inventory
claims, with no native theorem, geometric/symmetry transfer, infinite tiling,
new RL contribution or performance advantage.
