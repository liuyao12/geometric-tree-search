# Passive learned-marking report

Status: **SOURCE_ONLY_PENDING_ROOT_REVIEW**. No report build or scientific
module was executed during authoring. Source inspection and static parsing do
not substitute for Root's actual build, independent saved-data audit and UI
qualification. Frozen scientific/review pins remain immutable.

Source: `report/build_marking_report_v1.py`. Standard-library imports only;
no import of E3, C2, T2, synthesis, preservation oracle, driver or model helper.
Root runs it once with the exact frozen Python executable and `-I -S -B`.
It takes no external paths or supplied result/proof inputs. It writes exclusively
and refuses to replace earlier output.

## Passive gates

The builder enumerates the exact current frozen scientific file set using the
driver's four folders plus Root Source admission and every admitted review
reference. It verifies all byte pins, isolated runtime executable/version/flags,
current normative master and local copy. External runtime/master metadata stays
separate from the relative artifact ledger.

Both actual phase result/start/invocation/observer/log associations must match,
with strict native integer PID/exit fields, exit zero, clean owned guards,
unchanged postcheck, exact protocol ref and complete result capture. Every saved
ref in the qualification and pilot results is byte-bound. JSON/gzip reads are
bounded by the frozen capture limit; missing/refused data cannot be rendered as
success.

The builder checks literal saved-data associations, not point legality again:
actual event/snapshot sequence and hashes; C/T/G status/scope bindings; every
paired graph hash against the actual snapshot; saved endpoint hashes and
restored equality; selected certificate rows; exhaustive-oracle status and
subsets count; labels against their checked extension results; the unlabeled
catalogue; synthesis score prefixes and actual assignments; the pre-oracle
learned-model freeze; exact original/marked oracle models; full preservation
coverage, verdict, cover equality and post-freeze catalogue cross-check; lane
inputs and marked pair replays; rejected lost-positive-cover control. No
transition, learner, checker, kernel or oracle is replayed.
The C event hash and each dead context's model hash are joined explicitly.
Qualification IDs must equal both frozen input lists in order. Label/replay
array lengths are checked before pairing records; the filter model must equal
the literal base model with only its version label and pair list changed.

## Outputs

- `report/learned-literal-markings-v1.html`, main anchor `#reader`.
- `report/learned-literal-markings-data-v1.json.gz`, deterministic gzip.
- `report/build-receipt-v1.json`, archive/local gate only.

There is one public HTML page and one data file. No individual-download tree
or separate evidence page is generated. Complete original Sources, logs,
qualification records, raw events and checks belong in the approved physical
ZIP archive. Both archive insertion and publication are later Root actions.

Public data schema is `Learned-literal-markings-report-data-v1`, status
`PASS_SAVED_DATA_PROJECTION`. Top-level fields:

```text
base, marked, site, catalog, labels
acquisition
label_runs: [{pair,label,run}]
synthesis_history: [{ref,value}]
lanes: [{lane,model,raw_status,reason,stats,final_selected,final_selected_count,
         observations,semantic,full_graph_check,paired_graph_check,refs}]
failure_contexts, preservation, marked_pair_replays, preservation_control
qualification: {cases,controls}
coverage, costs, protocol, phase_custody, provenance, scope, projection
```

Run projections use the lane shape without `lane`. Observations are the complete
actual saved `{event,state}` arrays. Preservation is the complete saved receipt,
including all sixteen subset rows, exact solution masks and both domain/edge
tables. Qualification is compact counts and local pinned refs; no large
qualification tables are fabricated or copied into the interface.

The build receipt schema is `Learned-literal-markings-report-build-v1`, status
`PASS_SAVED_DATA_AND_REPORT_BUILD`, with `protocol`, `phase_custody`, `coverage`,
`costs`, `outputs` (exactly `main` and `data`), `renderer_source`, `artifact_pins`
and `scope`. Output/source/protocol refs are `{path,bytes,sha256}` relative to
this root. `artifact_pins` contains relative refs only. The receipt is not a
scientific replay or final publication admission.

## Reader semantics

The site was prospectively prescribed; only absence/assigned literal colors
were learned. The history displays the actual all-absent step and every later
complete-catalogue prefix fit over the full absent/zero/one template family.
No expected marking or oracle cover entered the learner. The interface shows
literal zero as blue, one as orange and missing components as a hatched absent
state; an absent component is never encoded as an assigned wildcard string.

The lane reader displays complete actual producer snapshots and event-to-English
translations. Integer positive values use \(u_c\), integer totals \(U\), capacity
\(C\), and normalized master values \(t_c=u_c/C\). Square cards denote abstract
anchored inventory objects, not geometric tile polygons. Placements in failed
branches count as placed events; final selected placements remain separate.

Costs retain worker high-water RSS separately from sparse observer polling;
the latter missed the pilot's true peak. Warm raw engine call times are shown
as single observations with fixed lane order. Learning, acquisition, assurance,
preservation and persistence costs belong to the pipeline; nested costs are
not added twice. Complete elimination-reason counters are unavailable, so only
the observed candidate removal and exact finite filter equivalence are claimed.

The reader states the limits: one identity-only finite EXPLICIT inventory, no
nonempty-provider qualification, reusable geometric prototype, target transfer,
RL, new mathematical theorem, infinite extension or distinct performance gain.
The seventeen qualification runs are fresh executions of thirteen prior
fixtures plus four new fixtures. All four pilot placements touch roots;
reachability is recorded, rather than claiming this pilot contains unreachable
subsets. Filter-lane placement explanations include ordinary pair-neighbor
dependency updates alongside positive and marking dependencies.

Archive insertion marker:
`<!-- LEARNED_LITERAL_MARKINGS_ARCHIVE_LINK -->`.
Existing public prefix remains `conditional-inventory`; predecessor reader is
`semantic-certificates-v1.html`. Root's separate publication admission, actual
UI/data checks and preserved unrelated remote content remain required.
