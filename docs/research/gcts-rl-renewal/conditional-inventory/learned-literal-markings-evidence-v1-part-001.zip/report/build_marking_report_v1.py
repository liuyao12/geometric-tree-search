"""Passive report assembler/renderer; import no scientific project modules.

Read actual saved JSON, exact byte pins and complete observed states only.
Never rerun E/C/T/O/L, a model helper, a transition or a scientific check.
Root reviews this Source before using the pinned isolated Python runtime.
"""
from collections import Counter
import gzip
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'report'
MASTER = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md')
LEDGER = {}
CACHE = {}
MAX_JSON = 16777216


def need(ok, why):
    if not ok:
        raise ValueError(why)


def wire(x):
    return (json.dumps(x,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')


def sha(x):
    return hashlib.sha256(wire(x)).hexdigest()


def same(a,b,why):
    need(wire(a)==wire(b),why)


def bytepin(p):
    h=hashlib.sha256();n=0
    with p.open('rb') as f:
        for block in iter(lambda:f.read(1048576),b''):
            h.update(block);n+=len(block)
    return dict(bytes=n,sha256=h.hexdigest())


def local(name):
    need(type(name) is str and bool(name),'LITERAL_PATH')
    p=Path(name)
    need(not p.is_absolute() and '..' not in p.parts,'RELATIVE_LOCAL_PATH')
    out=ROOT
    for part in p.parts:
        out=out/part;need(not out.is_symlink(),'NO_SYMLINK:'+name)
    need(out.resolve().is_relative_to(ROOT),'ROOT_PATH')
    return out


def pin(name):
    value=dict(path=name,**bytepin(local(name)));LEDGER[name]=value;return value


def read(name,reference=None):
    p=local(name);actual=pin(name)
    if reference is not None:
        same(actual,{k:reference[k] for k in ('path','bytes','sha256')},'EXACT_REF_BYTES:'+name)
        need(reference.get('complete_json',True) is True,'COMPLETE_CAPTURE:'+name)
    if name not in CACHE:
        with gzip.open(p,'rb') if p.suffix=='.gz' else p.open('rb') as f:
            b=f.read(MAX_JSON+1)
        need(len(b)<=MAX_JSON,'JSON_READ_BOUND:'+name)
        CACHE[name]=json.loads(b)
    return CACHE[name]


def checked(reference):
    return read(reference['path'],reference)


def check_nested_refs(x):
    if type(x) is dict:
        if {'path','bytes','sha256'}<=x.keys():
            need(type(x['path']) is str and not Path(x['path']).is_absolute(),'LOCAL_SAVED_REF')
            actual=pin(x['path']);same(actual,{k:x[k] for k in actual},'ALL_NESTED_REF_BYTES')
            need(x.get('complete_json',True) is True,'ALL_REF_CAPTURES_COMPLETE')
        else:
            for value in x.values():check_nested_refs(value)
    elif type(x) is list:
        for value in x:check_nested_refs(value)


def environment():
    protocol=read('data/protocol-frozen-v1.json')
    need(protocol['status']=='FROZEN_BEFORE_SCIENTIFIC_IMPORTS','PROSPECTIVE_FREEZE')
    admission=read('review/root-source-admission-v1.json')
    need(admission['status']=='PASS_SOURCE_REVIEW_BEFORE_FREEZE','SOURCE_ADMISSION')
    names={'review/root-source-admission-v1.json'}
    for folder in ('source','reference','input','plan'):
        for p in (ROOT/folder).rglob('*'):
            need(not p.is_symlink(),'NO_FROZEN_SYMLINK')
            if p.is_file():
                need(p.suffix!='.pyc' and '__pycache__' not in p.parts,'NO_BYTECODE')
                names.add(p.relative_to(ROOT).as_posix())
    for ref in admission['reviewed']:
        same(pin(ref['path']),{k:ref[k] for k in ('path','bytes','sha256')},'ADMITTED_REVIEW_BYTES')
        names.add(ref['path'])
    same([pin(n) for n in sorted(names)],protocol['files'],'EXACT_FROZEN_FILE_SET')
    executable=Path(sys.executable).resolve()
    runtime=dict(executable=dict(path=str(executable),**bytepin(executable)),version=sys.version,
                 isolated=sys.flags.isolated,no_site=sys.flags.no_site,dont_write_bytecode=sys.dont_write_bytecode)
    need(sys.flags.isolated==1 and sys.flags.no_site==1 and sys.dont_write_bytecode is True,'PINNED_ISOLATED_RUNTIME')
    same(runtime,protocol['runtime'],'RUNTIME_BYTES_VERSION_FLAGS')
    master=dict(path=str(MASTER),**bytepin(MASTER));same(master,protocol['master'],'CURRENT_MASTER')
    same(bytepin(local('reference/basic-tiling-algorithm.md')),{k:master[k] for k in ('bytes','sha256')},'LOCAL_MASTER_COPY')
    return protocol,dict(runtime=runtime,master=master,frozen_files=len(names))


def phase(name,protocol):
    result=read('data/'+name+'-result.json');started=read('data/'+name+'-started.json')
    invocation=read('review/'+name+'-invocation.json');observer=read('review/'+name+'-observer.json')
    same(started['protocol'],pin('data/protocol-frozen-v1.json'),'PHASE_PROTOCOL_BYTES')
    need(all(type(x['pid']) is int for x in (started,invocation,observer))
         and started['pid']==invocation['pid']==observer['pid'],'PHASE_PID')
    need(started['phase']==invocation['phase']==observer['phase']==name,'PHASE_CONTEXT')
    need(observer['status']=='TERMINAL' and type(observer['native_exit_code']) is int
         and observer['native_exit_code']==0 and invocation['status']=='COMPLETE'
         and invocation['error_type'] is None,'PHASE_NATIVE_ZERO')
    need(all(observer[k] is None for k in ('guard_reason','observer_error','reap_error','postcheck_error'))
         and invocation['postcheck_error'] is None,'PHASE_GUARDS')
    need(invocation['frozen_postcheck']==observer['frozen_postcheck']==protocol['status'],'POSTCHECK')
    need(invocation['scientific_status']==result['status'],'SCIENTIFIC_RESULT_JOIN')
    same(checked(invocation['result']),result,'EXACT_PHASE_RESULT')
    same(pin(observer['log']['path']),observer['log'],'NATIVE_LOG_BYTES')
    need(invocation['maxrss_units'] in ('bytes','KiB'),'WORKER_RSS_UNITS')
    return result,dict(native_exit_code=0,pid=observer['pid'],execution_admitted=True,
        worker_seconds=invocation['seconds'],observer_seconds=observer['seconds'],
        worker_highwater_rss_bytes=invocation['maxrss']*(1 if invocation['maxrss_units']=='bytes' else 1024),
        peak_polled_rss_bytes=observer['peak_observed_rss_bytes'],
        scope='Worker high-water and observer polling are distinct; a sparse poll can miss the real peak.')


def run_projection(row):
    value={k:checked(r) for k,r in row['refs'].items()}
    m,r,o,c,t,g=[value[k] for k in ('model','raw','observations','semantic','full_graphs','paired_graphs')]
    same(row['metrics'],r['stats'],'ACTUAL_STATS')
    need(r['status'] in ('SAT','UNSAT') and row['raw_status']==r['status'],'DEFINITE_RUN')
    need(c['status']==t['status']==g['status']=='VERIFIED','THREE_CHECKS')
    same({k:row[k] for k in ('semantic_status','full_graph_status','paired_graph_status','engine_calls')},
         dict(semantic_status=c['status'],full_graph_status=t['status'],paired_graph_status=g['status'],engine_calls=1),'RUN_ROW_STATUSES')
    need(c['run_status']==t['run_status']==r['status'],'CHECKED_RAW_STATUS')
    need(c['claim']==('SEMANTIC_COMPLETE_SAT_CERTIFICATE' if r['status']=='SAT' else 'SEMANTIC_COMPLETE_FINITE_EXHAUSTION')
         and c['bounded_absence'] is (r['status']=='UNSAT'),'SEMANTIC_SCOPE')
    need(c['event_coverage']=='COMPLETE' and c['model_sha256']==t['model_sha256']==r['model_sha256'],'MODEL_BINDINGS')
    same(c['event_sha256'],r['event_extent']['sha256'],'SEMANTIC_EVENT_STREAM_BINDING')
    same([x['event'] for x in o],r['events'],'ACTUAL_OBSERVED_EVENTS')
    same(dict(total=len(o),retained=len(o),sha256=hashlib.sha256(b''.join(wire(x['event']) for x in o)).hexdigest(),
              scope='BOUNDED_PREFIX_COMPLETE_EMITTED_STREAM_HASH'),r['event_extent'],'FULL_EVENT_EXTENT')
    same(row['actual_snapshots'],len(o),'OBSERVATION_COUNT')
    same(g['events_checked'],len(o),'PAIRED_COUNT');same(t['counts']['observations_checked'],len(o),'FULL_GRAPH_COUNT')
    need(len(g['comparisons'])==len(o),'ALL_PAIRED_ROWS')
    for actual,comparison in zip(o,g['comparisons']):
        need(comparison['equal'] is True and comparison['seq']==actual['event']['seq']
             and comparison['actual_sha256']==comparison['reconstructed_sha256']==sha(actual['state']),'PAIRED_ACTUAL_GRAPH_HASH')
    for w in c.get('dead_context_witnesses',[]):
        pre=w['context_preimage'];actual=o[w['dead_event']]
        need(actual['event']['kind']=='DEAD' and actual['event']['point']==pre['dead_point']
             and w['semantic_context_sha256']==sha(pre),'DEAD_CONTEXT_BYTES')
        same(pre['model_sha256'],r['model_sha256'],'DEAD_CONTEXT_MODEL_BINDING')
        for k in ('selected','excluded','Q'):same(pre[k],actual['state'][k],'DEAD_ACTUAL_'+k)
    for name in ('entry','final','restored'):
        same(sha(r[name+'_state']),r['state_hashes'][name],'SAVED_ENDPOINT_HASH')
    same(r['entry_state'],r['restored_state'],'SAVED_RESTORE_EQUALITY')
    if r['status']=='SAT':
        same(r['selected'],[x[0] for x in o[-1]['state']['selected']],'SAVED_SELECTED_CERTIFICATE')
        byid={x['id']:x for x in o[-1]['state']['placements']}
        same(r['certificate']['placements'],[byid[x] for x in r['selected']],'CERTIFICATE_LITERAL_ROWS')
    return dict(model=m,raw_status=r['status'],reason=r['reason'],stats=r['stats'],
        final_selected=r['selected'],final_selected_count=len(r['selected']),
        observations=o,semantic=c,full_graph_check={k:v for k,v in t.items() if k!='failure_provenance'},
        paired_graph_check={k:v for k,v in g.items() if k!='comparisons'},refs=row['refs'])


def assemble():
    protocol,external=environment();q,qprocess=phase('qualify',protocol);p,pprocess=phase('pilot',protocol)
    need(q['status']=='QUALIFIED_LITERAL_MARKING_ENGINE_V3' and p['status']=='VERIFIED_FINITE_LITERAL_MARKING_LEARNING','PHASE_ADMISSIONS')
    check_nested_refs(q);check_nested_refs(p)
    declared=(read('input/qualification-cases-v1.json')['cases']
              +read('input/pair-qualification-v1.json')['cases'])
    same([x['id'] for x in q['cases']],[x['id'] for x in declared],'EXACT_FROZEN_QUALIFICATION_IDS')
    qualified=[];graphs=0
    for row in q['cases']:
        need(row['status']=='QUALIFIED','QUALIFIED_CASE')
        run=run_projection(row);oracle=checked(row['oracle'])
        need(oracle['status']=='EXHAUSTED' and oracle['exists'] is (run['raw_status']=='SAT')
             and oracle['model_sha256']==run['semantic']['model_sha256'],'INDEPENDENT_EXISTENCE')
        same(oracle['counts']['subsets_checked'],oracle['subsets_total'],'COMPLETE_SUBSETS')
        graphs+=len(run['observations'])
        qualified.append(dict(id=row['id'],status='QUALIFIED',raw_status=run['raw_status'],
            snapshots=len(run['observations']),subsets=oracle['subsets_total'],refs=dict(row['refs'],oracle=row['oracle'])))
    need(len(qualified)==len({x['id'] for x in qualified})==17,'SEVENTEEN_FIXTURES')
    same(graphs,q['actual_snapshots'],'ACTUAL_QUALIFICATION_GRAPHS')
    need(graphs==143 and len(q['controls'])==11,'QUALIFICATION_COVERAGE')
    controls=[]
    for row in q['controls']:
        receipt=checked(row['receipt']);need(receipt['status'] in ('REJECTED','UNKNOWN'),'CONTROL_REFUSAL')
        if 'bounded_absence' in receipt:need(receipt['bounded_absence'] is False,'REFUSAL_NO_ABSENCE')
        controls.append(dict(id=row['id'],status=receipt['status'],reason=receipt.get('reason'),refs=row))
    same(dict(fresh_regular_engine_calls=17,invalid_engine_calls=6,resource_engine_calls=1),
         {k:q[k] for k in ('fresh_regular_engine_calls','invalid_engine_calls','resource_engine_calls')},'QUALIFICATION_CALLS')
    base=read('input/pilot-model-v1.json');site=read('plan/marking-support-v1.json')['site']
    need(all(site!=point for r in base['inventory']['placements'] for point,n in r['t']),'DECLARED_MARK_ONLY_SITE')
    acquisition=run_projection(p['acquisition']);same(acquisition['model'],base,'UNMARKED_ACQUISITION_INPUT')
    same(p['catalog'],[x['pair'] for x in p['labels']],'COMPLETE_LABEL_CATALOG')
    same([len(p[k]) for k in ('labels','label_runs','catalog')],[3,3,3],'COMPLETE_LABEL_ARRAY_LENGTHS')
    same(len(p['marked_pair_replays']),len(p['labels']),'COMPLETE_MARKED_REPLAY_ARRAY')
    catalog=read('data/pilot/catalog.json');same(catalog['pairs'],p['catalog'],'SAVED_UNLABELED_CATALOG')
    need(catalog['status']=='ENUMERATED_UNLABELED','UNLABELED_CATALOG_SCOPE')
    label_runs=[]
    for label,row in zip(p['labels'],p['label_runs']):
        same(row['pair'],label['pair'],'LABEL_PAIR_BINDING');same(row['label'],label['label'],'LABEL_BINDING')
        run=run_projection(row['run'])
        need(label['label']==('POSITIVE' if run['raw_status']=='SAT' else 'NEGATIVE'),'LABEL_FROM_CHECKED_EXTENSION')
        label_runs.append(dict(pair=label['pair'],label=label['label'],run=run))
    need(len(label_runs)==len(p['catalog'])==3,'THREE_CERTIFIED_PAIRS')
    histories=[]
    for i,ref in enumerate(p['synthesis_history']):
        h=checked(ref);need(h['status']=='SOLVED' and h['unresolved']==0,'SYNTHESIS_STATUS')
        same(h['resolved'],i,'LABEL_PREFIX_COUNT');same([dict(pair=x['pair'],label=x['label']) for x in h['score']],p['labels'][:i],'SYNTHESIS_PREFIX_SCORE')
        need(all(x['matched'] is True for x in h['score']),'RECORDED_ALL_LABELS_FIT')
        histories.append(dict(ref=ref,value=h))
    need(len(histories)==len(label_runs)+1 and histories[0]['value']['assigned_values']==0,'INITIAL_ALL_ABSENT')
    marked=checked(p['learned_model']);frozen=read('data/pilot/learned-model-frozen-v1.json')
    need(frozen['status']=='FROZEN_BEFORE_PRESERVATION_AND_SEARCH','LEARNED_MODEL_FREEZE')
    same(frozen['model'],p['learned_model'],'FROZEN_MODEL_REF');same(frozen['labels'],p['labels'],'FROZEN_LABELS')
    same(frozen['history'],p['synthesis_history'],'FROZEN_SYNTHESIS_HISTORY')
    same(sha(marked),p['marking_model_sha256'],'LEARNED_MODEL_SHA');same(sha(marked),frozen['canonical_model_sha256'],'FROZEN_MODEL_SHA')
    same([{k:r[k] for k in ('id','m')} for r in marked['inventory']['placements']],histories[-1]['value']['assignments'],'ACTUAL_SYNTHESIZED_MARKS')
    preservation=checked(p['preservation']);need(preservation['status']=='VERIFIED' and preservation['phase']=='COMPLETE','PRESERVATION_ADMISSION')
    need(preservation['subsets_coverage']==preservation['meeting_pair_coverage']==preservation['nogood_extension_coverage']=='COMPLETE','COMPLETE_ORACLE_EVIDENCE')
    same(preservation['models']['base'],base,'PRESERVATION_ORIGINAL_MODEL');same(preservation['models']['marked'],marked,'PRESERVATION_MARKED_MODEL')
    need(preservation['verdict']['solution_sets_equal'] is True and preservation['verdict']['every_nogood_absent_from_original_covers'] is True
         and preservation['verdict']['literal_marking_equals_pair_filter_every_capacity_legal_subset'] is True,'PRESERVATION_VERDICT')
    ev=preservation['evidence'];same(len(ev['subsets']),preservation['subsets_total'],'ALL_SUBSET_ROWS')
    same([x['mask'] for x in ev['subsets']],list(range(preservation['subsets_total'])),'COMPLETE_MASK_SEQUENCE')
    same(ev['base_solutions'],ev['marked_solutions'],'ORIGINAL_MARKED_COVERS');same(ev['base_solutions'],ev['direct_solutions'],'ORIGINAL_FILTER_COVERS')
    same([dict(pair=x['pair'],label=x['extension_status']) for x in ev['meeting_pairs']],p['labels'],'POST_FREEZE_ORACLE_CATALOG_CROSSCHECK')
    lanes=[]
    for row in p['lanes']:
        lanes.append(dict(lane=row['lane'],**run_projection(row)))
    same([x['lane'] for x in lanes],['BASE','MARKS','PAIR_FILTER'],'DECLARED_LANE_ORDER')
    same(lanes[0]['model'],base,'BASE_INPUT');same(lanes[1]['model'],marked,'MARKS_INPUT')
    same(lanes[2]['model']['pair_nogoods'],preservation['models']['pair_nogoods'],'FILTER_PAIR_BINDING')
    expected_filter=dict(base,version=lanes[2]['model']['version'],
                         pair_nogoods=preservation['models']['pair_nogoods'])
    same(lanes[2]['model'],expected_filter,'FILTER_CHANGES_ONLY_VERSION_AND_PAIR_NOGOODS')
    replays=[]
    for row,label in zip(p['marked_pair_replays'],p['labels']):
        same(row['pair'],label['pair'],'MARKED_PAIR_REPLAY_ID')
        if 'run' in row:
            run=run_projection(row['run']);need(label['label']=='POSITIVE' and run['raw_status']=='SAT','POSITIVE_LITERAL_REPLAY')
            replays.append(dict(pair=row['pair'],status=row['status'],run=run))
        else:
            need(label['label']=='NEGATIVE' and row['status']=='REJECTED_BY_LITERAL_MARKING_AGREEMENT'
                 and type(row['engine_calls']) is int and row['engine_calls']==0,'LITERAL_CONFLICT_REPLAY')
            same(row['literal_assignments'],[x for x in marked['inventory']['placements'] if x['id'] in row['pair']],'LITERAL_PAIR_MARK_ROWS')
            replays.append(row)
    corruption=checked(p['preservation_control']);need(corruption['status']=='REJECTED','LOST_COVER_CONTROL')
    for w in p['failure_contexts']:need(w in acquisition['semantic']['dead_context_witnesses'],'HARVESTED_CHECKED_CONTEXT')
    counts=dict(qualification_cases=len(qualified),qualification_actual_graphs=graphs,qualification_controls=len(controls),
        catalog_pairs=len(label_runs),synthesis_calls=len(histories),subsets=len(ev['subsets']),
        capacity_legal_subsets=sum(x['base_capacity_legal'] is True for x in ev['subsets']),original_covers=len(ev['base_solutions']))
    counts['pilot_actual_graphs']=(len(acquisition['observations'])+sum(len(x['run']['observations']) for x in label_runs)
        +sum(len(x['observations']) for x in lanes)+sum(len(x['run']['observations']) for x in replays if 'run' in x))
    costs=dict(qualification=qprocess,pilot=pprocess,
        synthesis_call_seconds=sum(x['ref']['call_seconds'] for x in histories),
        preservation_call_seconds=p['preservation']['call_seconds'],
        pair_label_engine_call_seconds=sum(x['run']['refs']['raw']['call_seconds'] for x in p['label_runs']),
        lane_engine_call_seconds={x['lane']:x['refs']['raw']['call_seconds'] for x in p['lanes']},
        scope=p['timing_scope'])
    return dict(schema='Learned-literal-markings-report-data-v1',status='PASS_SAVED_DATA_PROJECTION',
        base=base,marked=marked,site=site,catalog=p['catalog'],labels=p['labels'],
        acquisition=acquisition,label_runs=label_runs,synthesis_history=histories,lanes=lanes,
        failure_contexts=p['failure_contexts'],preservation=preservation,marked_pair_replays=replays,
        preservation_control=dict(status=corruption['status'],reason=corruption['reason'],ref=p['preservation_control']),
        qualification=dict(cases=qualified,controls=controls),coverage=counts,costs=costs,
        protocol=pin('data/protocol-frozen-v1.json'),phase_custody=dict(qualify=qprocess,pilot=pprocess),
        provenance=dict(current_external_custody=external,artifact_pins=list(LEDGER.values())),
        scope=p['scope'],projection='Complete pilot histories, labels, oracle subset table and actual lane snapshots; qualification uses counts/pins. No scientific helper executed by the report.')


PAGE=r'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Learning literal GCTS markings</title><style>
:root{--ink:#183239;--muted:#5a7076;--line:#d8e2de;--blue:#316dbe;--red:#c56138;--teal:#087c79;--purple:#7856aa}*{box-sizing:border-box}body{margin:0;background:#f3f6f2;color:var(--ink);font:16px/1.6 system-ui,-apple-system,sans-serif}main{max-width:1120px;margin:auto;padding:35px 24px 70px}nav{display:flex;gap:18px;flex-wrap:wrap;font-size:13px}a{color:#087c79}h1{font-size:clamp(37px,5.6vw,65px);line-height:1.05;letter-spacing:-.045em;margin:35px 0 18px}h2{font-size:26px;letter-spacing:-.025em;margin:0 0 12px}h3{font-size:17px}.eyebrow{text-transform:uppercase;letter-spacing:.14em;font-size:11px;color:var(--teal)}.lede{font-size:19px;max-width:860px;color:var(--muted)}section{margin:32px 0}.panel{background:white;padding:23px;border:1px solid var(--line);border-radius:15px;min-width:0}.grid{display:grid;grid-template-columns:1fr 1fr;gap:18px}.muted,small{color:var(--muted)}.note{background:#eef6f2;border-left:4px solid var(--teal);padding:12px 15px;border-radius:0 9px 9px 0}.controls{display:flex;gap:9px;align-items:center;flex-wrap:wrap;margin:12px 0}button,select{font:inherit;font-size:13px;border:1px solid #c7d7d1;border-radius:8px;padding:8px 11px;background:white;cursor:pointer}input[type=range]{flex:1;min-width:160px}.cards{display:flex;gap:12px;flex-wrap:wrap;margin:17px 0}.card{min-width:130px;flex:1;border:1px solid var(--line);border-radius:11px;padding:14px}.card b{font-size:23px}.square{border:2px solid var(--teal);border-radius:2px;padding:10px;min-height:96px;background:#f3faf6}.square.selected{border-color:var(--blue);background:#edf3ff}.square.off{opacity:.48}.port{height:16px;border:1px solid #b7c6c2;border-radius:3px;margin:8px 0}.p0{background:var(--blue)}.p1{background:var(--red)}.absent{background:repeating-linear-gradient(135deg,#fff,#fff 5px,#e4ebe7 5px,#e4ebe7 10px)}.legend{display:flex;gap:16px;flex-wrap:wrap;font-size:12px}.swatch{display:inline-block;width:18px;height:10px;margin-right:5px;border-radius:2px}.scroll{overflow:auto;max-width:100%}table{width:100%;border-collapse:collapse;font-size:13px}td,th{text-align:left;vertical-align:top;border-bottom:1px solid var(--line);padding:9px 7px;overflow-wrap:anywhere}th{font-size:11px;color:var(--muted);white-space:nowrap}code,pre{font:12px/1.5 ui-monospace,monospace}pre{background:#eef3ef;border-radius:8px;padding:13px;overflow:auto;max-width:100%}.math{display:block;overflow-x:auto;max-width:100%}.good{color:#24724c}.bad{color:#b1433b}.pill{display:inline-block;background:#edf2ef;padding:3px 7px;border-radius:5px;font-size:11px;margin:2px}.diagram{background:#fafcf9;border:1px solid var(--line);border-radius:11px;overflow:auto}.diagram svg{display:block;width:100%;height:auto;min-width:500px}.current{background:#edf6f0}.summary-stats{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin:25px 0}.summary-stats div{background:white;border:1px solid var(--line);border-radius:11px;padding:16px}.summary-stats b{display:block;font-size:27px}.summary-stats span{font-size:12px;color:var(--muted)}details{margin:13px 0}summary{cursor:pointer;font-size:13px;color:var(--muted)}#fatal{white-space:pre-wrap;color:#a33333}mjx-container{max-width:100%}mjx-container[display=true]{overflow:auto}@media(max-width:760px){main{padding:24px 13px}.grid{grid-template-columns:1fr}.summary-stats{grid-template-columns:repeat(2,1fr)}.panel{padding:17px}}
</style><script>window.MathJax={tex:{inlineMath:[['\\(','\\)']],displayMath:[['\\[','\\]']]},options:{skipHtmlTags:['script','style','pre','code']},startup:{ready(){MathJax.startup.defaultReady();window.__mathReady=MathJax.startup.promise;}}};</script><script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js"></script></head><body><main>
<nav><a href="semantic-certificates-v1.html">Previous semantic certificates</a><a href="#learning">Learning</a><a href="#reader">Search reader</a><a href="#preservation">Preservation</a><a href="#assessment">Assessment</a></nav><p class="eyebrow">GCTS research · finite literal marking pilot</p><h1>From a failed pair<br>to literal markings</h1><p class="lede">Initially every marking is absent. Certified unmarked extension tests drive a small synthesis problem; the resulting point values remove a failed branch through ordinary marking agreement.</p><p class="note">This is one supplied four-object anchored mechanism test. The learned markings preserve both exact covers and reproduce the ordinary pair filter's pruning. No distinct GCTS advantage, new theorem, reinforcement learning or geometric transfer is established.</p><div id="fatal"></div><div id="stats" class="summary-stats"></div>
<section id="learning" class="panel"><p class="eyebrow">Declared support, learned values</p><h2>One prescribed mark-only site</h2><p>The support site <code id="site"></code> was prospectively prescribed before labels. The learner discovers assignments, absence and literal colors, not the site's geometry or a reusable tile prototype. No expected marking was supplied. The site has no positive capacity contribution. The cards are identity-only anchored point-data inventory objects, not literal Wang polygons.</p><div class="controls"><label>Synthesis history <select id="history"></select></label><span id="history-score"></span></div><div class="legend"><span><i class="swatch p0"></i>assigned literal <code>"0"</code></span><span><i class="swatch p1"></i>assigned literal <code>"1"</code></span><span><i class="swatch absent"></i><code>*</code> shown for absence; no assigned row</span></div><div id="mark-cards" class="cards"></div><div id="history-label" class="note"></div><p class="muted">Zero is an assigned value. An absent component accepts either value. The objective was minimum assigned components, then the declared absent/zero/one lexical order, over the complete absent/zero/one template family. This is finite constraint synthesis, not a trained RL policy.</p><details><summary>Actual synthesis output</summary><pre id="synth-literal"></pre></details></section>
<section class="panel"><h2>Three actual pair certificates</h2><p>The complete initially capacity-legal meeting-pair catalogue was labeled by fresh unmarked searches. A harvested failed context alone was not treated as a reusable rule: its pair received a separate complete finite extension check.</p><div id="pair-table" class="scroll"></div><div id="pair-detail"></div></section>
<section id="reader" class="panel"><p class="eyebrow">Actual recorded events and producer snapshots</p><h2>Inspect the resulting search</h2><div class="controls"><label>Lane <select id="lane"></select></label><button id="prev">Previous</button><button id="next">Next</button><input id="step" type="range" min="0" value="0"><span id="counter"></span></div><div id="meaning" class="note"></div><div id="lane-cards" class="cards"></div><div id="active-mark"></div><div id="graph" class="diagram"></div><div class="grid"><div><h3>Point totals and generations</h3><div id="point-table" class="scroll"></div></div><div><h3>Complete current domains</h3><div id="domains"></div></div></div><h3>Event to English</h3><div id="events" class="scroll"></div><details><summary>Exact current snapshot</summary><pre id="literal-state"></pre></details><p class="muted">Every displayed intermediate graph is an actual saved producer observation. Independent semantic, full-graph and paired receiver checks admitted these finite runs; the reader does not replay those checks.</p></section>
<section id="preservation" class="panel"><p class="eyebrow">Independent exhaustive check after the learner freeze</p><h2>Every subset is inspectable</h2><p>The preservation oracle received the frozen models. Its complete covers and pair classifications never trained the learner. No candidate subset was omitted, including overcapacity subsets, and reachability was recorded. Every placement in this pilot touches a root. Domain equivalence applies to every base-capacity-legal partial set.</p><div id="covers"></div><div id="subset-table" class="scroll"></div><details><summary>Subset detail: literal assignments, eligibility and weighted domains</summary><label>Mask <select id="subset"></select></label><pre id="subset-detail"></pre></details><p>Within this finite inventory, the original, marked and ordinary-filter solution sets agree. Mark compatibility and pair-filter compatibility also agree on every capacity-legal partial set, as do candidate eligibility and weighted frontier incidence.</p><p class="muted">This certifies the declared anchored inventory only. It supplies no marking rule for an unrestricted geometric prototype, no infinite extension and no native mathematical proof.</p></section>
<section class="panel"><h2>Measured search changes</h2><div id="lane-table" class="scroll"></div><p class="note">The marking and pair-filter lanes use the same learned information and avoid the same failed branch. Their matching pruning is a mechanism demonstration, not evidence that geometric marking representation improves proof-search performance.</p><p class="muted">Placed-event counts include placements in failed branches; final accepted placements are reported separately. The engine does not expose complete elimination-reason counters for capacity, marking and pair rules, so no global cause totals are inferred.</p></section>
<section id="assessment" class="grid"><div class="panel"><h2>What this contributes</h2><p>Literal GCTS markings now do the candidate elimination in a checked learning loop: start unmarked, certify local finite extension outcomes, synthesize assignments, freeze them, independently prove finite preservation, then run the marked engine.</p><p>All resolved catalogue entries were used. There is no holdout or generalization claim here. Stronger receptor families and higher-order failures remain future encoding problems; they need their own preservation argument.</p></div><div class="panel"><h2>Cost and limits</h2><div id="costs"></div><p>Runs were single warm calls in fixed lane order. Acquisition, three pair labels, synthesis, exhaustive preservation, assurance and persistence cost belong to the pipeline. Tiny raw-search differences are not speed evidence.</p></div></section>
<section class="panel"><h2>Qualification and provenance</h2><div id="qualification"></div><p class="muted">Conformance scope: identity-only finite EXPLICIT inventories. Nonempty-provider qualification, cluster/RL actions, prototype or target transfer, and complete elimination-reason instrumentation are outside this milestone.</p><details><summary>Qualification controls and scopes</summary><div id="controls" class="scroll"></div></details><details><summary>Source, protocol and artifact byte pins</summary><pre id="provenance"></pre></details><p><a href="learned-literal-markings-data-v1.json.gz">Download the complete readable data projection</a>. The approved full archive below contains all original Sources, raw records, snapshots, logs and checks.</p></section>
<!-- LEARNED_LITERAL_MARKINGS_ARCHIVE_LINK -->
<footer class="muted">Finite exact point arithmetic uses integer units \(u_c\) with capacity \(C\); normalized master tile values are \(t_c=u_c/C\). No geometry predicate participates in these searches.</footer></main>
<script>
'use strict';const $=x=>document.getElementById(x),esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])),tex=x=>String(x).replace(/[\\{}_$%&#^~]/g,c=>'\\'+c),math=x=>'<span class="math">\\('+x+'\\)</span>';let D,L,step=0,mathQueue=Promise.resolve();const n=(x,d=3)=>Number(x).toLocaleString(undefined,{maximumFractionDigits:d});
function typeset(el){mathQueue=mathQueue.then(async()=>{while(!window.MathJax||!MathJax.typesetPromise)await new Promise(r=>setTimeout(r,25));await MathJax.startup.promise;if(el.isConnected){MathJax.typesetClear([el]);await MathJax.typesetPromise([el]);}}).catch(e=>{$('fatal').textContent='Math rendering error: '+e.message;});}
async function load(){const r=await fetch('learned-literal-markings-data-v1.json.gz');if(!r.ok)throw Error('Data HTTP '+r.status);const b=new Uint8Array(await r.arrayBuffer());if(b[0]===31&&b[1]===139)return JSON.parse(await new Response(new Blob([b]).stream().pipeThrough(new DecompressionStream('gzip'))).text());return JSON.parse(new TextDecoder().decode(b));}
function point(p){return p.split('@')[0];}function badge(v){return v==='0'?'p0':v==='1'?'p1':'absent';}function valueFor(row){const at=row.m.find(x=>x[0]===D.site);return at?at[1]:null;}
function card(row,value,state){const selected=state?.selected.some(x=>x[0]===row.id),eligible=!state||state.eligible.includes(row.id);return '<div class="card"><div class="square '+(selected?'selected':!eligible?'off':'')+'"><b>'+esc(row.id)+'</b>'+math(row.t.map(([p,u])=>'u(\\text{'+tex(point(p))+'})='+u).join(',\\quad '))+'<div class="port '+badge(value)+'"></div><small>'+esc(value===null?'* absent':JSON.stringify(value)+' assigned at q')+'</small></div></div>';}
function showHistory(){const i=+$('history').value,h=D.synthesis_history[i].value,rows=h.assignments.map(x=>({...D.base.inventory.placements.find(r=>r.id===x.id),m:x.m}));$('mark-cards').innerHTML=rows.map(r=>card(r,valueFor(r),null)).join('');$('history-score').textContent=h.assigned_values+' assigned components; '+h.resolved+' resolved labels; '+h.patterns+' templates examined';$('history-label').textContent=i===0?'No marking is known; all four components are absent.':'Latest certified pair: '+D.labels[i-1].pair.join(' + ')+' is '+D.labels[i-1].label+'. Every resolved label remains in the synthesis constraints.';$('synth-literal').textContent=JSON.stringify(h,null,2);typeset($('learning'));}
function meaning(e){const p=e.point?point(e.point):'',c=e.candidate||'';return ({READY:'Initialize every active obligation and the complete declared inventory.',BRANCH:'Branch at '+p+' on the complete domain ['+e.data.legal?.join(', ')+']; try its first candidate.',FORCED:'Global dead checks passed; '+p+' has one legal candidate, '+c+'.',PLACED:'Place '+c+' and update its complete positive, marking and declared pair-neighbor dependencies. Its growth generation is '+e.data.generation+'.',DEAD:'The complete legal domain at '+p+' is empty. This selected context cannot finish.',EXCLUDE:'Restore the failed parent and exclude '+c+' only in that parent context.',SOLUTION:'All active points have exact capacity and their assigned markings agree.',EXHAUSTED:'The exact declared finite inventory is exhausted.'})[e.kind]||e.kind;}
function graph(s){const ids=[...new Set(s.domains.flatMap(x=>x[1]))].sort(),ps=s.Q,dm=new Map(s.domains),tt=new Map(s.totals),height=Math.max(200,55+55*Math.max(ps.length,ids.length)),py=new Map(ps.map((x,i)=>[x[0],55+55*i])),cy=new Map(ids.map((x,i)=>[x,55+55*i]));let z='<svg viewBox="0 0 700 '+height+'" role="img" aria-label="Actual weighted point-candidate graph"><text x="20" y="23" font-size="12" fill="#5a7076">Active points: units, capacity, generation</text><text x="445" y="23" font-size="12" fill="#5a7076">Shared legal frontier candidates</text>';for(const [p,c,u]of s.forward)z+='<line x1="265" y1="'+py.get(p)+'" x2="450" y2="'+cy.get(c)+'" stroke="#83aaa3" stroke-width="'+(1+u)+'"/><text x="350" y="'+((py.get(p)+cy.get(c))/2-4)+'" font-size="12" fill="#426f66">'+u+'</text>';for(const [p,g]of ps){const y=py.get(p),dead=dm.has(p)&&!dm.get(p).length;z+='<rect x="12" y="'+(y-18)+'" width="253" height="36" rx="8" fill="'+(dead?'#ffe9e3':dm.has(p)?'#e9f6ef':'#eef1ed')+'" stroke="'+(dead?'#bc5439':'#80a69a')+'"/><text x="25" y="'+(y+4)+'" font-size="12">'+esc(point(p))+' : '+tt.get(p)+' units of '+L.model.capacity+'; generation '+g+(dead?' DEAD':'')+'</text>';}for(const c of ids){const y=cy.get(c);z+='<rect x="450" y="'+(y-18)+'" width="220" height="36" fill="#f2faf5" stroke="#087c79"/><text x="465" y="'+(y+4)+'" font-size="14">'+esc(c)+'</text>';}if(!ids.length)z+='<text x="450" y="65" font-size="12" fill="#5a7076">No legal frontier candidate</text>';return z+'</svg>';}
function showStep(){const o=L.observations[step],s=o.state,e=o.event;$('step').value=step;$('counter').textContent=(step+1)+' / '+L.observations.length;$('meaning').innerHTML='<b>'+esc(e.kind)+'</b> — '+esc(meaning(e));$('lane-cards').innerHTML=L.model.inventory.placements.map(r=>card(r,valueFor(r),s)).join('');$('active-mark').innerHTML='<p>Selected: '+(s.selected.map(([c,g])=>'<span class="pill">'+esc(c)+' · generation '+g+'</span>').join('')||'none')+' · Parent-local exclusions: '+(s.excluded.map(c=>'<span class="pill bad">'+esc(c)+'</span>').join('')||'none')+'</p>'+(s.marks.length?'<p>Actual active marking: '+s.marks.map(([p,v,c])=>'<span class="pill"><i class="swatch '+badge(v)+'"></i><code>'+esc(p)+' = '+esc(JSON.stringify(v))+'</code> · references '+c+'</span>').join('')+'</p>':'<p class="muted">No assigned active marking.</p>')+(L.model.pair_nogoods.length?'<p>Ordinary direct-filter constraint: '+L.model.pair_nogoods.map(p=>p.map(esc).join(' + ')).join('; ')+' forbidden.</p>':'');$('graph').innerHTML=graph(s);$('point-table').innerHTML='<table><thead><tr><th>Point</th><th>Units / capacity</th><th>Generation</th></tr></thead><tbody>'+s.Q.map(([p,g])=>'<tr><td><code>'+esc(p)+'</code></td><td>'+math('U(\\text{'+tex(point(p))+'})='+new Map(s.totals).get(p)+',\\quad C='+L.model.capacity)+'</td><td>'+g+'</td></tr>').join('')+'</tbody></table>';$('domains').innerHTML=s.domains.map(([p,c])=>'<p><b>'+esc(point(p))+'</b>: '+(c.length?c.map(x=>'<span class="pill">'+esc(x)+'</span>').join(''):'<b class="bad">empty</b>')+'</p>').join('')||'<p class="muted">No frontier remains.</p>';$('literal-state').textContent=JSON.stringify(s,null,2);$('events').innerHTML='<table><thead><tr><th>Event</th><th>Kind</th><th>English meaning</th></tr></thead><tbody>'+L.observations.map((x,i)=>'<tr class="'+(i===step?'current':'')+'"><td><button data-event="'+i+'">'+x.event.seq+'</button></td><td>'+esc(x.event.kind)+'</td><td>'+esc(meaning(x.event))+'</td></tr>').join('')+'</tbody></table>';for(const b of $('events').querySelectorAll('button'))b.onclick=()=>{step=+b.dataset.event;showStep();};typeset($('reader'));}
function showLane(){L=D.lanes.find(x=>x.lane===$('lane').value);step=0;$('step').max=L.observations.length-1;showStep();}
function pairDetail(i){const p=D.label_runs[i];$('pair-detail').innerHTML='<details open><summary>Actual '+p.pair.map(esc).join(' + ')+' extension: '+esc(p.run.raw_status)+'</summary><p>'+esc(p.run.semantic.claim)+'. This label belongs to the fixed finite original inventory; the learned marking was not active.</p><pre>'+esc(JSON.stringify({pair:p.pair,semantic:p.run.semantic,model:p.run.model},null,2))+'</pre></details>';}
function init(){const c=D.coverage;$('stats').innerHTML=[[c.catalog_pairs,'certified pair labels'],[D.synthesis_history.at(-1).value.assigned_values,'learned literal components'],[c.original_covers,'exact covers preserved'],[c.subsets,'subsets independently checked']].map(([a,b])=>'<div><b>'+a+'</b><span>'+b+'</span></div>').join('');$('site').textContent=D.site;$('history').innerHTML=D.synthesis_history.map((x,i)=>'<option value="'+i+'">'+(i?'After pair '+i:'Initially all absent')+'</option>').join('');$('history').value=D.synthesis_history.length-1;showHistory();$('history').onchange=showHistory;$('pair-table').innerHTML='<table><thead><tr><th>Pair</th><th>Unmarked outcome</th><th>Semantic certificate</th><th>Marked replay</th></tr></thead><tbody>'+D.label_runs.map((x,i)=>'<tr><td><button data-pair="'+i+'">'+x.pair.map(esc).join(' + ')+'</button></td><td>'+esc(x.label)+' · '+esc(x.run.raw_status)+'</td><td>'+esc(x.run.semantic.status)+' · '+x.run.observations.length+' actual events</td><td>'+esc(D.marked_pair_replays[i].status)+'</td></tr>').join('')+'</tbody></table>';for(const b of $('pair-table').querySelectorAll('button'))b.onclick=()=>pairDetail(+b.dataset.pair);pairDetail(0);$('lane').innerHTML=D.lanes.map(x=>'<option>'+x.lane+'</option>').join('');showLane();$('lane').onchange=showLane;$('step').oninput=()=>{step=+$('step').value;showStep();};$('prev').onclick=()=>{step=Math.max(0,step-1);showStep();};$('next').onclick=()=>{step=Math.min(L.observations.length-1,step+1);showStep();};const ev=D.preservation.evidence;$('covers').innerHTML='<p>All three representations have the same saved covers: '+ev.base_solutions.map(s=>'<span class="pill">{ '+s.selected.map(esc).join(', ')+' }</span>').join('')+'.</p>';$('subset-table').innerHTML='<table><thead><tr><th>Mask</th><th>Selected</th><th>Capacity legal</th><th>Marks / filter</th><th>Exact cover base / marks / filter</th></tr></thead><tbody>'+ev.subsets.map(s=>'<tr><td>'+s.mask+'</td><td>'+s.selected.map(esc).join(', ')+'</td><td>'+s.base_capacity_legal+'</td><td>'+s.literal_mark_compatible+' / '+s.pair_nogood_free+'</td><td>'+s.base_solution+' / '+s.marked_solution+' / '+s.direct_solution+'</td></tr>').join('')+'</tbody></table>';$('subset').innerHTML=ev.subsets.map(s=>'<option value="'+s.mask+'">'+s.mask+' · '+(s.selected.join(', ')||'empty')+'</option>').join('');const subset=()=>$('subset-detail').textContent=JSON.stringify(ev.subsets[+$('subset').value],null,2);$('subset').onchange=subset;subset();$('lane-table').innerHTML='<table><thead><tr><th>Lane</th><th>Result</th><th>Placed events / final selected</th><th>Branches</th><th>Backtracks</th><th>Events</th><th>Raw warm engine call, ms</th></tr></thead><tbody>'+D.lanes.map(x=>'<tr><td>'+esc(x.lane)+'</td><td>'+esc(x.raw_status)+'</td><td>'+x.stats.placements+' / '+x.final_selected_count+'</td><td>'+x.stats.branches+'</td><td>'+x.stats.backtracks+'</td><td>'+x.observations.length+'</td><td>'+n(D.costs.lane_engine_call_seconds[x.lane]*1000)+'</td></tr>').join('')+'</tbody></table>';const p=D.costs.pilot,q=D.costs.qualification;$('costs').innerHTML='<p>Pilot worker: <b>'+n(p.worker_seconds)+' s</b>; owned process observed: <b>'+n(p.observer_seconds)+' s</b>. Qualification worker: '+n(q.worker_seconds)+' s; observed: '+n(q.observer_seconds)+' s.</p><p>Worker high-water RSS: <b>'+n(p.worker_highwater_rss_bytes/1048576)+' MiB</b>. Sparse observer polling captured '+n(p.peak_polled_rss_bytes/1048576)+' MiB and missed the worker peak; this is not the memory usage estimate.</p><p>Nested synthesis calls: '+n(D.costs.synthesis_call_seconds*1000)+' ms; independent preservation call: '+n(D.costs.preservation_call_seconds*1000)+' ms. These are already inside the worker total and are not added to it.</p>';$('qualification').innerHTML='<p><b>'+c.qualification_cases+'</b> fresh qualification runs (13 prior fixtures plus 4 new fixtures), <b>'+c.qualification_actual_graphs+'</b> qualification plus <b>'+c.pilot_actual_graphs+'</b> pilot actual graph observations and <b>'+c.qualification_controls+'</b> corruption/resource controls passed the declared gates. Both actual owned phases terminated with native exit zero and unchanged frozen pins.</p><p>Preservation control: '+esc(D.preservation_control.status)+' when a positive cover was deliberately damaged.</p>';$('controls').innerHTML='<table>'+D.qualification.controls.map(x=>'<tr><td>'+esc(x.id)+'</td><td>'+esc(x.status)+'</td><td>'+esc(x.reason||'')+'</td></tr>').join('')+'</table>';$('provenance').textContent=JSON.stringify({protocol:D.protocol,phase_custody:D.phase_custody,coverage:D.coverage,scope:D.scope,artifact_pins:D.provenance.artifact_pins},null,2);typeset(document.querySelector('main'));}
load().then(d=>{D=d;init();}).catch(e=>{$('fatal').textContent='Actual saved report data could not be loaded: '+e.message;});
</script></body></html>'''


def write(name,data):
    p=OUT/name;p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('xb') as f:f.write(data)
    return dict(path=p.relative_to(ROOT).as_posix(),**bytepin(p))


def build():
    data=assemble()
    projected=write('learned-literal-markings-data-v1.json.gz',gzip.compress(wire(data),mtime=0))
    main=write('learned-literal-markings-v1.html',PAGE.encode('utf-8'))
    result=dict(schema='Learned-literal-markings-report-build-v1',status='PASS_SAVED_DATA_AND_REPORT_BUILD',
        protocol=data['protocol'],phase_custody=data['phase_custody'],coverage=data['coverage'],costs=data['costs'],
        outputs=dict(main=main,data=projected),renderer_source=dict(path=Path(__file__).relative_to(ROOT).as_posix(),**bytepin(Path(__file__))),
        artifact_pins=list(LEDGER.values()),scope='Passive exact saved-data joins/projection only. No scientific module, state transition, oracle, synthesis or kernel replay.')
    return write('build-receipt-v1.json',wire(result))


if __name__=='__main__':
    print(json.dumps(build(),sort_keys=True))
