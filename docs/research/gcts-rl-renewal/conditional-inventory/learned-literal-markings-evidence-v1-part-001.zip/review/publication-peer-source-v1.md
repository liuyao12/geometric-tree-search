# Learned-marking publication: independent Source review

Status: **PASS_SOURCE_REVIEW_PENDING_ROOT_PUBLICATION_EXECUTION_AND_LIVE_CHECKS**.

All five current Source bodies and the complete API were read. The prior
semantic-publication bodies were previously fully reviewed. Direct standard-
library byte/diff inspection independently confirms that the supplied complete
adaptation patch equals the exact diff from those immutable baselines. AST
parsing did not import or invoke a tool. No blocking defect or further Source
change is requested.

| File | Bytes | SHA-256 |
| --- | ---: | --- |
| `publication/evidence_common_v1.py` | 22702 | `631dbee037e0d85f8dbb412eaf602878622c2e381d980ee1d10bdb0ad92a4378` |
| `publication/package_publish_v1.py` | 14979 | `ff0d27768707b78d273c61f6035bb28ab8ab47199edf7d1fb937890107c4216c` |
| `publication/observe_github_v1.py` | 4738 | `aa2bd5394bb5bb469af8a1031244507e1e2c8ee08cd0a7f8c5cad4b43ce7f914` |
| `publication/verify_live_v1.py` | 5085 | `fea78427e2929e93df1ddd05154f7806a5e763ca829e12757bf8502b0ee6e84e` |
| `publication/complete_publication_v1.py` | 9789 | `edd28dddade7980239a9bfa2ada15a35573b5a3bafa617b27cd52ad3e5b8bb83` |
| `review/publication-adaptation-v1.patch` | 59937 | `e34c659992c10d70e004e45e539d9ba5943e6ad3b15b4991a0a4b19f9e958422` |
| `review/publication-API-v1.md` | 10642 | `c3b506eb710ba8d1b72ef289a7065ab7959534ad91be9415e1a3303bd9f1d7b4` |

The live verifier is byte-identical to its hardened preceding baseline. No
publication tool, network/Git operation, package, mirror, or scientific module
was executed by this reviewer. The earlier independent literal-data audit was
a separate explicitly authorized data-only operation and remains unchanged:
`review/report-independent-data-audit-v1.json`, 40165 bytes, SHA-256
`43891ea334449f559ef4d4c89f8095fd4e4c49bd7c0b638df9998dddd010b31f`.

## Current gates and scope

The common gate binds the authoritative frozen file list, reviewed driver,
Root Source admission, pinned executable and flags, current/local master, and
both actual phase/PID/protocol/result/log associations. Native zero, clean
guards, unchanged postcheck and complete result bytes are required. Saved
science checks remain literal/serialized associations: no engine, state
transition, checker, learner or preservation oracle is called.

The seventeen actual qualification runs, 143 snapshots and eleven controls
remain exact. Pilot acquisition, all three separate unmarked pair labels,
fixed seeds/residual inventories, four synthesis histories, learned model
freeze, complete sixteen-subset/eight-capacity-legal-state preservation, two
cover lists, all three lanes and marked-pair replays are joined to their saved
refs. Ordinary pair controls remain distinct from literal marking agreement.
The mandatory independent data audit, Root publication PASS and final local UI
are separate from the historical Source-review PASS.

The compact publication contains one main page, its gzip data, archive volumes
and manifest. There is no invented evidence page or download tree. The original
render is physically preserved before link injection and pinned to its build
receipt. `verify_report` accepts only the unique archive-marker replacement;
all bytes outside that block must equal the original. Thus the earlier audit's
main-page pin remains an honest pre-link observation, while final UI/live byte
checks bind the published linked page. Data stays byte-identical.

## Archive, Git and deployment closure

Every current original file at the cut is physically stored, including all
Sources, raw/actual observations, full subset evidence, unknown/refusal controls,
learning histories, logs, reviews and publication planning files. Only generated
`package/` outputs are excluded. No alias recipe substitutes for a path, and no
predecessor original count is reclaimed. The predecessor full archive remains
separately linked. Volumes reserve manifest/header space and then must satisfy
actual 44 MiB limits. Exact member sets, uncompressed bytes/SHA-256 values,
all CRCs and volume pins are verified before tree preparation.

The reviewed base is confirmed by an official read-only GET. An isolated bare
repository and task-owned index prepare one sole-parent commit. New-path
collisions refuse; the exact tree diff must be task additions and only the
permitted existing semantic-certificate backlink. No script pushes or stages
the primary checkout. Root's later normal push and remote observations remain
required.

The official observer binds remote main, exact commit/tree/sole parent and
the matching repository/main/head Pages success. The live tool checks every
prepared body with normal TLS, HTTPS-only redirects and HTTP/1.1, then verifies
every downloaded ZIP member and CRC. Failed observations/bodies cannot close
publication; prior receipts are retained.

Completion rejoins remote/Pages/live bytes/UI, unchanged archive-cut originals,
report/readiness/protocol and physical archive evidence. It collision-preflights
the primary research-run mirror, preserves every differing existing file by
refusing, copies only missing files and verifies each copy. The overall research
program stays ACTIVE. Warm fixed-order timings are not promoted to speed or
ATP superiority; no RL, new theorem, reusable geometric marking, held-out
transfer or infinite-domain claim is added by publication.

Actual packaging, public commit, Pages deployment, live/UI and mirror success
are not established by this Source review and must still be observed by Root.
