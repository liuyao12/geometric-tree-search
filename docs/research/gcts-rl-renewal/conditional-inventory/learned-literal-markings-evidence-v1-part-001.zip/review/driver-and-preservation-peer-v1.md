# Pilot driver and preservation oracle: independent Source review

Status: **PASS_SOURCE_REVIEW_PENDING_PROSPECTIVE_FREEZE_AND_EXECUTION**.
No scientific imports, engine/checker/oracle calls, model construction, tests,
or experiments were performed. No other author's Sources were edited. C2/T2
remain held at their previously handed-back pins.

## Final reviewed pins

| File | Bytes | SHA-256 |
| --- | ---: | --- |
| `source/run_marking_pilot_v1.py` | 31927 | `18a14be69c33485a341b7f082bd2067cca694332cc91376d5706ef61d7753d6a` |
| `plan/driver-API-v1.md` | 9294 | `ffd2f7c0a3a3368c76bc19425ff5a67fdab14c3c7ce0b18cc1051ff94889141f` |
| `source/marking_preservation_oracle_v1.py` | 26661 | `1b55ba046d4ba376e8b80c2eadf28b3a2bb8f9eee9dae1847c93de2dbf84d5c2` |
| `plan/preservation-API-v1.md` | 8946 | `edcc8cd131229e29c5fc2eb2d744299fffa3af040419395ab88bda00e90ebce6` |

The full draft driver body was read, followed by the final custody/resource/
evidence deltas and full driver API. The full preservation Source/API and all
four pair-qualification declarations were read. No blocking Source issue or
further requested change remains at these pins.

## Driver and phase custody

Scientific modules are dynamically loaded only after prospective freeze and
Root's pinned Source admission. The exact Source/reference/input/plan set,
reviewed files, local normative master copy, interpreter/flags and all limits
are checked before/after the owned child. The documented inability to reread
the primary checkout is not hidden behind a false current-master claim.
Outputs/logs are exclusive, phase attempts cannot silently repeat, and actual
native exit, guard, observer/reap and frozen postcheck remain separate.

The strengthened qualification gate uses this driver's actual started shape
with its protocol byte-ref. It joins phase/PID, native exit, source postcheck,
result path/bytes/complete capture, seventeen case identities, eleven controls,
and all saved case/control refs. KILL/wait errors are retained. A failed or
nonconclusive science/assurance call aborts after retaining evidence; it never
becomes a negative pair label or triggers an implicit retry.

Each ordinary engine result and actual callback stream is saved before public
semantic/full-graph checks and the separate private receiver comparison. The
paired comparison consumes actual E3 observations; it does not fabricate input
for T2. Migrated fixtures and the four new controls exercise remote pair-only
effects, multiple selected neighbors through rollback, finite exhaustion and
assigned zero at an extended marking port. The forbidden-candidate mutant in
the first pair fixture targets the forced state after its branch selection,
where the candidate is genuinely forbidden by the pair filter.

## Information flow and learned markings

Initial acquisition is unmarked, and meeting-pair enumeration uses only
positive supports/capacity. Pair classification converts the two fixed rows
to their summed seed, activates all fixed positive support, and removes the
same CIDs from the remaining inventory. The pilot enforces empty original seed
and empty markings/pairs, so no omitted prior contribution is overwritten.
The four declared rows already touch original roots; classification is finite
anchored extension, not an unrestricted geometric coroutine or transfer claim.

Every pair classification remains unmarked and independently assured. L sees
only sorted CIDs, the accumulated actual resolved labels, site and limits; it
receives no oracle solutions, selected proof or target assignment. Provisional
markings do not influence classification. Actual two-CID/no-exclusion dead
contexts are harvested separately and must match subsequently certified
negative pair labels before claiming a globally absent finite pair.

The actual learned model/ref/hash is saved as frozen before the independent
preservation call. Only afterwards is its complete pair census compared with
the acquired catalogue and labels. A mismatch refuses admission without
retraining or repair. All three final lanes use the same E3, scheduler,
positive inventory, limits and assurance; markings versus ordinary pairs are
the explicitly differing constraints. Model immutability is checked before
each lane. Fixed warm-process order and complete learning/assurance costs are
disclosed; no speed inference is justified.

Marked pair replay either records actual literal disagreement with no engine
call or completes the compatible fixed pair with the same assurance. A
deliberately corrupted positive pair tests the preservation checker, never the
learner or measured lane. Negative literal evidence is physically saved.

## Independent preservation argument

The oracle uses only standard libraries and no E/C/T/L import, incremental
graph, scheduler, supplied witness or expected solution. It independently
normalizes exact v2 explicit data and enumerates every candidate subset. Fresh
totals, assigned-value groups, declared pair membership, active support and
root reachability determine exact covers. Final legality is monotone, so a
positive-support reachability order gives a legal growing attachment order;
it does not certify the reference scheduler.

For each base-capacity-legal subset, including unreachable or already
constraint-invalid families, it compares literal whole-family compatibility,
candidate extension sets, every frontier domain and exact weighted incidence
with the ordinary pair predicate. In an already invalid family, whole-family
extension is deliberately impossible in both representations. This stronger
assignment-level convention is documented rather than presented as an
observed engine state. Common branch exclusions can be subtracted afterwards.

The original/marked/direct exact rooted solution sets must independently be
equal, and every passed nogood must be absent from all original covers. Thus
local encoding equivalence alone cannot establish preservation. A separately
enumerated complete meeting-pair census is saved only after subset enumeration.
Depth/work/subset/time/memory refusals preserve explicit prefix coverage and
remain UNKNOWN, even when a partial solution or counterexample was encountered.

The prospective one-billion oracle work cap is explicit; different engine,
checker, synthesis and oracle meters are not common instruction units. These
are Source conclusions only. Actual qualification, learned assignments,
preserved covers, graph effects, native process success and practical costs
remain unobserved until Root's frozen execution.
