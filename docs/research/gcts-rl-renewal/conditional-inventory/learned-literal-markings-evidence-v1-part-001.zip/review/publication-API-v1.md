# Learned literal-marking publication: Source-only handoff

These five `publication/` scripts adapt the exact previously reviewed semantic-
certificate publication tools in the immutable preceding milestone. Baseline
pins are listed below and the full adaptation is
`review/publication-adaptation-v1.patch`. No publication tool has been imported
or executed. Source editing, AST parsing and saved JSON/byte inspection are the
only work in this handoff. Root must read the full Sources before any planning,
packaging, network/Git, live verification or mirror operation. No scientific
helper, search, checker, learner or oracle is imported or replayed.

The existing repository/destination remains `liuyao12/geometric-tree-search`,
prefix `docs/research/gcts-rl-renewal/conditional-inventory/`. The expected base
at handoff is `035ebb6028deb76ecf2fd399639585907171cf42`; a fresh official GET
must still confirm the explicitly reviewed base immediately before commit
preparation. No force push, new public destination or audience change is used.

## Exact publication surface

Only one new reader and its compressed public data are published:

- `learned-literal-markings-v1.html`, with `#reader`.
- `learned-literal-markings-data-v1.json.gz`.
- `learned-literal-markings-evidence-v1-part-NNN.zip` and
  `learned-literal-markings-evidence-manifest-v1.json`.

There is no extra evidence HTML or individual-download directory. The sole
modified existing web path is `semantic-certificates-v1.html`, receiving one
backlink. All other assets must be new paths; collisions are refused. Every
prepared tree path must match that addition/sole-modification set. The marker
is `LEARNED_LITERAL_MARKINGS_ARCHIVE_LINK`. Its injected block also directly
links the predecessor's separate `semantic-certificates-evidence-v1.html` full
archive, without claiming its older files are stored in the current ZIPs.

## Saved science and process gates

`verify_protocol` checks the exact authoritative file list in the frozen
5602-byte protocol, SHA256
`a5970ecd01355ade203bfe3a6331e27fa062e39d7c3a4e059c0205f48eb868b8`.
The current count is 30; equality of the actual file/ref set is authoritative,
not an inherited older milestone count. It recreates the four-directory set
plus Root admission and every admission-ref path, checks all exact pins, the
reviewed driver, runtime executable/flags, current master and local master.
It requires both actual current phases, `qualify` and `pilot`, to join their
started/invocation/observer PID/phase/protocol, native exit zero, clean guard,
observer/reap/postcheck state, native log bytes, scientific status and complete
saved-result path/bytes. Original first attempts cannot silently rerun.

`verify_science` performs saved-data associations only:

- All 17 qualified runs, 143 actual snapshots and 11 controls remain present.
  Model/raw/observation/C2/T2/private-Reader refs are byte checked. Normalized
  serialized model hashes, exact retained-event/observation joins, every saved
  paired-graph hash, terminal status and exact restoration endpoints agree.
  Each independent subset result is EXHAUSTED over the complete declared
  subset count; a positive selection appears in its saved solution set.
- The controls retain eight REJECTED and three UNKNOWN outcomes. A raw work
  refusal stays UNKNOWN and never certifies absence.
- Acquisition is the exact unmarked original input. All three pair-label
  runs retain their own checked unmarked residual models and certificate
  status. Saved fixed seeds/residual inventories are associated with the
  exact fixed pair, counted once; this is a data-context join, not a new
  completion search.
- Four saved synthesis outputs start with absent components and end with a
  complete resolved catalog fit. The actual final assignments equal the
  learned model, which matches its saved pre-preservation freeze/hash. The
  harvested contexts occur in the actual acquisition semantic receipt and
  correspond to certified negative pairs without parent-local exclusions.
- The original preservation receipt is VERIFIED with complete 16-subset,
  eight-capacity-legal-state coverage, two equal original/marked/direct cover
  sets and zero compatibility/eligibility/domain/edge equivalence failures.
  Its model/pair hashes, stored normalized models and independent complete
  catalog labels join the actual acquired model/labels.
- BASE, MARKS and PAIR_FILTER are the actual three fresh shared-engine lanes,
  each SAT and C2/T2/private-Reader VERIFIED. Their models are respectively the
  original input, actual learned model and original input with the same
  certified ordinary pairs. Literal pair replays and lost-positive refusal
  remain distinct; actual pilot graph coverage totals 43 snapshots.

No subset, graph, engine state or oracle verdict is recomputed by publication.
Byte/JSON normalization and saved arithmetic/ref associations do not turn these
gates into new scientific replay or proof validity claims.

## Compact report and readiness

The passive renderer is exactly `report/build_marking_report_v1.py`. It writes
one main HTML, compressed public data and local `report/build-receipt-v1.json`.
Required schemas/statuses are:

- Public data: `Learned-literal-markings-report-data-v1`,
  `PASS_SAVED_DATA_PROJECTION`.
- Build receipt: `Learned-literal-markings-report-build-v1`,
  `PASS_SAVED_DATA_AND_REPORT_BUILD`.
- `review/report-independent-data-audit-v1.json`: `PASS`, the separate passive
  literal/pin/projection audit; it imports or reruns no scientific helper.
- `review/local-ui-qualification-v1.json`: `PASS_LOCAL_UI`, zero math errors,
  no body overflow or console entries, with the exact final main-page hash.
- `review/root-publication-admission-v1.json`: `PASS`, written by Root after
  independent report/content/UI readiness.
- `review/root-source-admission-v1.json`:
  `PASS_SOURCE_REVIEW_BEFORE_FREEZE`, an historical precondition which cannot
  replace final publication approval.

The report gate binds its protocol, renderer Source and every local artifact
pin, then exact main/data output paths and public-data schema/status. It does
not require a nonexistent separate summary or an extra evidence page.
Additional actual Root review receipts can be required via `--require-receipt`.

## Link planning and physical archive

After Source review, `package_publish_v1.py --prepare-links` only preserves the
original built HTML as `publication/rendered-before-archive-links-v1.html`,
writes the archive README/plan and injects archive links into the current main
page. It builds no ZIP, stages no Git and makes no network call. The preserved
original is byte-bound to the build receipt and is itself included physically
at the eventual archive cut. The report gate proves the current page differs
from that original only in its unique marker block. Final local UI must be
revalidated against the injected page. A changed volume count or page hash
requires link/UI review before packaging. Planning is refused after a package
or prepared commit exists.

The later package invocation accepts an explicitly reviewed 40-character base
and refuses existing package/prepared/index attempts. Every current original
file at the cut is physically stored: all frozen Sources/refs/inputs/plans,
raw/actual snapshots/receipts, full subset tables, controls, learning history,
models, logs, report Source/output/receipt, reviews and publication planning.
Only generated `package/` outputs are excluded because an archive cannot
include itself. Later-created deployment receipts remain later custody data.
No cut file may subsequently change, including publication metadata.

Every original path has its own physical ZIP member even if another file has
identical bytes. Each volume is at most 44 MiB and below the 50-MiB asset limit.
Every volume contains the same internal full manifest. Verification checks
exact member sets, every CRC, original uncompressed size/SHA256, part size/hash
and complete original-path coverage. No alias or reconstruction recipe stands
in for bytes. No prior 80-copy or older-original-count requirement is imposed
on this new milestone; predecessor archives remain separately linked.

## Isolated commit, live checks and completion

After physical archive verification, an official read-only GitHub GET confirms
remote main still equals the reviewed base. A local tree/commit uses only an
isolated bare repository/task index, with hooks disabled and one sole parent.
The exact diff must be additions except the one permitted semantic-certificate
backlink. This script never pushes or stages the primary checkout. Root's later
push must be normal/non-force; a moved remote base needs renewed review.

`observe_github_v1.py` uses bounded official GETs to verify remote main,
commit/tree/sole-parent and exact matching Pages repository/branch/head/completed
success. Replaced observations are retained. `verify_live_v1.py` is byte-for-byte
the previous hardened verifier: normal TLS, HTTPS-only redirects, HTTP/1.1 and
exact bytes for every prepared body, followed by all physical ZIP member/CRC
checks on downloaded parts.

`complete_publication_v1.py` requires remote/Pages/live bodies/archive/protocol,
report/readiness and local/live UI associations plus unchanged cut originals.
It collision-preflights the exact mirror at
`research-runs/gcts-learned-marking-pilot-20261103-v1` in the primary project:
existing files must be identical, only missing files are copied and every copy
is checked. Completion receipts are exclusive/idempotent, with no primary Git
staging. The overall research program remains ACTIVE.

## Baseline custody

The full diff is against these exact files in the immutable predecessor's
`publication/` directory:

| Baseline | Bytes | SHA256 |
| --- | ---: | --- |
| `evidence_common_v1.py` | 18200 | `d87fc5c22b5f8411f10d1cc10b6477533775e21fdab9690b882dfa83f340c736` |
| `package_publish_v1.py` | 15282 | `4c26df7beba5785817b50ab397e573b9984ade6ae31f71c0730963015c746e68` |
| `observe_github_v1.py` | 4736 | `b775a24f6d3cd93726d8786042b3b3fd4b63c531321b487b3334029733bcf5cf` |
| `verify_live_v1.py` | 5085 | `fea78427e2929e93df1ddd05154f7806a5e763ca829e12757bf8502b0ee6e84e` |
| `complete_publication_v1.py` | 10723 | `9ddcd191abbf3172fe5fe2e64574ef65e0b89cccf430d4bd3f1b1bc103211bff` |

This pipeline publishes one supplied finite anchored learning mechanism with
complete preservation and an equivalent conventional filter. It establishes no
geometric prototype transfer, held-out theorem, RL or speed advantage, broad
ATP superiority, universal Wang/FOL completeness or whole-plane tiling.
