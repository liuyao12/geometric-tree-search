# Independent checker and synthesis Source review

Status: **PASS_SOURCE_REVIEW; SYNTHESIS_RESOURCE_CLOSURE_READ**.
This is a full Source read and static byte/AST/diff review. No scientific module
was imported, no model constructed, and no engine/checker/oracle/synthesis/test
call was executed. E3 remains held unchanged.

## Exact scope and pins

| Source | Bytes | SHA256 |
| --- | ---: | --- |
| `reference/semantic_event_checker_v1.py` | 39367 | `6985af4d1f56789c1237522141b1d04815370566dd99cb22da6a048eb6bc0613` |
| `source/semantic_event_checker_v2.py` | 41439 | `5258610eb83b284593a0905c09c9a3e1f66d7892c9a98c4b7271ba1755b0609d` |
| `reference/frontier_trace_checker_v1.py` | 27040 | `01f46bdf34b414c7470f75f1507f3e76bfefa739533fcc4b2fd121900378343f` |
| `source/frontier_trace_checker_v2.py` | 28667 | `a0417e25f321c86d7d243bbf35fbc63e5ce0bc81faf8adbe0e4ec31e066d2331` |
| `source/learn_literal_markings_v1.py` | 4873 | `b6a8c254740bafa68e46397954706974eb232b6745f0d341b36cb6158580b12d` |
| `plan/checkers-API-v1.md` | 7593 | `bd3496defd1389168e52fb64647425a339aeab63c418ac7c4595eb152d8afdc5` |
| `review/checkers-adaptation-v1.patch` | 15282 | `ee325181861a0f30955aa7e0025246692573b541707fbec73d51911a054a9e5c` |

Both baselines match the exact preceding admitted Sources. The complete saved
patch equals an independently generated full unified diff against these local
copies; no unrecorded body change was found. All three new scientific Sources
parse as Python AST. Their full bodies, the complete adapter patch and API were
read. The engine pin remains 42192 bytes / SHA256
`85e55b2ae489dedd5eaae2f62d49498f47e91bf5a538159f6815e0b80767d8cc`.

## Checker findings

No logical blocker was found in either adapter.

Both require the seven-field model-v2 ABI and canonical native pair lists:
two distinct nonempty known explicit CIDs, inner lexical order and strict outer
lexical order. The normalized model hash includes those pairs. Their pilot
scope is deliberately EXPLICIT-only, including empty pairs; unsupported provider
models remain UNKNOWN. E3's separate empty-pair provider support is not thereby
qualified by these checkers.

The semantic checker constructs its own neighbor tuples from validated pairs.
Legality rejects a candidate linked to any selected CID; exclusion alone does
not activate a pair conflict. Selection refreshes every pair neighbor in
addition to positive and marking dependencies, including pairs without shared
support. Resulting eligibility/edge changes use its existing reversible trail.
The independent whole-snapshot checker instead scans the complete literal
pair list for each candidate on full re-enumeration, so it does not share the
producer/receiver neighbor-index assumption. Both scan the original pair list
again for a positive selected certificate.

Global dead/forced/earliest-generation decisions, selected-once contributions,
literal zero versus absence, far marking dependencies and failed-child context
remain intact. C's terminal event/hash/model/selection/statistic/endpoint joins
are unchanged; T consumes actual producer observations and compares complete
graphs. Retained rollback-prefix metadata is still a separate C coverage scope.
Neither a raw UNKNOWN nor a filtered finite failure becomes an unfiltered
absence theorem. `dependency_links` retains positive/mark support semantics;
pair work is separately metered without inventing a marking dependency count.

The receipts correctly identify the ordinary filter and leave pair redundancy,
learning provenance, model preservation, mathematical validity and process
admission to independent gates. Qualification still needs a pair whose CIDs
share no positive or marking support: the main four-row example shares its
residual point and cannot alone detect a missing remote-neighbor update.

## Synthesis findings

The finite search starts from no supplied assignment and enumerates all allowed
absent/literal-zero/literal-one vectors. Positive labels permit no conflict;
negative labels require two assigned different literals; UNKNOWN labels impose
no constraint. The objective chooses the minimum assigned component count and
then a canonical absent/zero/one vector. It returns no partial best pattern as
SOLVED after a pattern/work/time refusal. Its scope correctly stops at fitting
the supplied finite catalog; neither catalog completeness nor all-solution
preservation is inferred by this function.

No expected bad pair or expected marking is hardcoded. Outputs preserve the
distinction between missing assignments and literal zero. The driver must still
use every resolved catalog label, bind labels to admitted unmarked extension
certificates, retain unresolved cases, and independently gate full preservation
before any marked-search admission.

One small resource closure was sent to Root before freeze in the earlier
4648-byte Source, SHA256
`e200493ead48b56646fb0dc6c413529c9347a46fd1968e378aa09bd0af56d307`:
its final success path built
assignments and rescanned up to 1000 labels for score without a `tick` or final wall
gate, then return SOLVED. Thus post-enumeration work can cross the declared
deadline without becoming UNKNOWN, and its work is not included in the reported
meter. Charge assignment construction and each scoring row, then call a final
`tick` before SOLVED; a final gate before UNREPRESENTABLE is also appropriate.
This was a cooperative resource/accounting issue, not a fit/soundness defect for
the tiny prospective input. Root owns that Source; this review made no Source edit.

**Closure:** Root added a charged loop for assignment construction, a charge
for each score row, and `tick(0)` before both SOLVED and UNREPRESENTABLE returns.
The returned `work_scope` now explicitly declares loop units and excludes full
input/serialization cost. The final full learner body and that narrow change
were read and AST-parsed without importing it. The reported finding is closed;
the final exact pin is in the table above. The two checker Sources and E3 remain
unchanged at their reviewed pins.

No empirical qualification, learned-marking result or performance conclusion
is claimed here.
