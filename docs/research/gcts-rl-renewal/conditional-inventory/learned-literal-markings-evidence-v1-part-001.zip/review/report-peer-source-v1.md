# Learned-marking report: independent Source review

Status: **PASS_SOURCE_REVIEW_PENDING_ROOT_BUILD_AND_SAVED_DATA_AUDIT**.

The full held builder body was read, followed by the exact approved custody
and wording deltas and complete final API. Final pins:

| File | Bytes | SHA-256 |
| --- | ---: | --- |
| `report/build_marking_report_v1.py` | 43819 | `4fcca36498fe8b181c7ff648dbafdda10e55449627148a58892241f970189a04` |
| `report/report-API-v1.md` | 6691 | `7f7f22a54c3e7fb357e895fdf7d20f2c47640757d18e75e56c045af043f217ff` |

No remaining Source blocker or further change is requested. No builder,
scientific module, transition, checker, oracle, learner or driver was imported
or invoked, and no report was built during this review. Frozen paths remain
unchanged. Preliminary original JSON reads were data inspection only, not new
qualification; the independent completed-projection audit remains pending.

The builder passively binds the exact frozen file set, Root Source admission,
runtime/version/flags, current/local master and actual two-phase process
receipts. Actual native integer exit zero, phase/PID/protocol, guard and source
postcheck fields, complete result/log refs and nested artifact refs are joined.
No scientific helper is rerun.

Run projections preserve actual model, event/snapshot arrays, stats, endpoint
hashes, selected certificate rows and C/T/G associations. The final delta
explicitly binds C's event hash and every semantic dead-context model hash to
the raw result. Qualification identities match both frozen declaration lists.
Label/catalog/run lengths and marked-replay lengths are checked before zip;
the whole filter model must equal the literal base except version and declared
pair list. These avoid silently truncated or mismatched projections.

The synthesis history is joined to actual resolved-label prefixes and the
final literal assignments. The frozen model/hash and complete post-learning
oracle receipt are retained, including every subset and exact cover list.
Preservation evidence is not fed into the learner. Literal negative-pair
disagreement is separated from actual positive fixed-pair engine replays, and
the deliberately corrupted positive cover remains a refusal control.

The interface clearly separates the prescribed support site from learned
assignments, assigned zero from absence, and abstract inventory cards from
literal geometric tiles. Displayed search graphs are actual saved observations,
not reconstructed animation states. Failed placements versus final selected
placements are labeled separately. The finite ordinary-filter equivalence is
presented as a mechanism test, without distinct GCTS performance, RL, theorem
discovery or geometric transfer claims.

The final prose distinguishes seventeen fresh executions of thirteen prior
fixtures plus four new fixtures. It records reachability without inventing
unreachable subsets in this all-root-attached pilot, and placement explanations
include ordinary pair-neighbor dependencies. Whole worker/observer clocks and
high-water versus sparse-polled RSS remain distinct; tiny warm engine timings
are not used as acceleration evidence.

Only one public HTML page and one gzip data projection are emitted, with
exclusive writes and a local pinned build receipt. Full raw/source/archive
publication and actual UI qualification are separate Root gates. Source review
does not yet establish the final emitted page/data bytes or their literal
agreement with all saved originals; that audit follows Root's build.
