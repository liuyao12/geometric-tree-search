"""Pure byte/literal/projection audit; no scientific imports or state replay."""
from pathlib import Path
from collections import Counter
import gzip,hashlib,json,sys,time
ROOT=Path(__file__).resolve().parents[1]
LEDGER={};CHECKS=[];RUNS=[]
def wire(x):return (json.dumps(x,sort_keys=True,ensure_ascii=True,separators=(",",":"),allow_nan=False)+"\n").encode("ascii")
def need(ok,why):
 if not ok:raise ValueError(why)
 CHECKS.append(why)
def same(a,b,why):need(wire(a)==wire(b),why)
def path(name):
 p=Path(name);need(not p.is_absolute() and ".." not in p.parts,"LOCAL_PATH")
 out=ROOT
 for part in p.parts:
  out=out/part;need(not out.is_symlink(),"NO_SYMLINK")
 need(out.resolve().is_relative_to(ROOT),"WITHIN_ROOT");return out
ndef bp(p):
 h=hashlib.sha256();n=0
 with p.open("rb") as f:
  for b in iter(lambda:f.read(1048576),b""):n+=len(b);h.update(b)
 return dict(bytes=n,sha256=h.hexdigest())
def ref(name):
 x=dict(path=name,**bp(path(name)));LEDGER[name]=x;return x
CACHE={}
def read(name,expected=None):
 actual=ref(name)
 if expected is not None:
  same(actual,{k:expected[k] for k in ("path","bytes","sha256")},"REF_BYTES:"+name)
  need(expected.get("complete_json",True) is True,"COMPLETE_JSON:"+name)
 if name not in CACHE:
  p=path(name)
  with (gzip.open(p,"rb") if p.suffix==".gz" else p.open("rb")) as f:b=f.read(16777217)
  need(len(b)<=16777216,"READ_BOUND:"+name);CACHE[name]=json.loads(b)
 return CACHE[name]
def checked(r):return read(r["path"],r)
def nested(x):
 if type(x) is dict:
  if {"path","bytes","sha256"}<=x.keys():
   same(ref(x["path"]),{k:x[k] for k in ("path","bytes","sha256")},"NESTED_REF_BYTES")
   need(x.get("complete_json",True) is True,"NESTED_COMPLETE")
  else:
   for v in x.values():nested(v)
 elif type(x) is list:
  for v in x:nested(v)
def phase(name,p,projected):
 r=read("data/"+name+"-result.json");s=read("data/"+name+"-started.json");i=read("review/"+name+"-invocation.json");o=read("review/"+name+"-observer.json")
 same(s["protocol"],ref("data/protocol-frozen-v1.json"),"PHASE_PROTOCOL")
 need(s["phase"]==i["phase"]==o["phase"]==name,"PHASE_NAME")
 need(all(type(v["pid"]) is int for v in (s,i,o)) and s["pid"]==i["pid"]==o["pid"],"PHASE_PID")
 need(o["status"]=="TERMINAL" and type(o["native_exit_code"]) is int and o["native_exit_code"]==0 and i["status"]=="COMPLETE" and i["error_type"] is None,"ACTUAL_NATIVE_ZERO")
 need(all(o[k] is None for k in ("guard_reason","observer_error","reap_error","postcheck_error")) and i["postcheck_error"] is None,"CLEAN_OWNED_PROCESS")
 need(i["frozen_postcheck"]==o["frozen_postcheck"]==p["status"],"PHASE_SOURCE_GUARD")
 same(checked(i["result"]),r,"PHASE_RESULT_BYTES");need(i["scientific_status"]==r["status"],"SCIENCE_STATUS_JOIN")
 same(ref(o["log"]["path"]),o["log"],"PHASE_LOG_BYTES")
 high=i["maxrss"]*(1 if i["maxrss_units"]=="bytes" else 1024)
 expected=dict(native_exit_code=0,pid=o["pid"],execution_admitted=True,worker_seconds=i["seconds"],observer_seconds=o["seconds"],worker_highwater_rss_bytes=high,peak_polled_rss_bytes=o["peak_observed_rss_bytes"],scope="Worker high-water and observer polling are distinct; a sparse poll can miss the real peak.")
 same(projected,expected,"PHASE_PROJECTION_LITERAL");nested(r);return r

def run(original,projected,role):
 v={k:checked(x) for k,x in original["refs"].items()};raw=v["raw"];obs=v["observations"]
 expected=dict(model=v["model"],raw_status=raw["status"],reason=raw["reason"],stats=raw["stats"],final_selected=raw["selected"],final_selected_count=len(raw["selected"]),observations=obs,semantic=v["semantic"],full_graph_check={k:x for k,x in v["full_graphs"].items() if k!="failure_provenance"},paired_graph_check={k:x for k,x in v["paired_graphs"].items() if k!="comparisons"},refs=original["refs"])
 actual={k:x for k,x in projected.items() if k!="lane"};same(actual,expected,"EXACT_RUN_PROJECTION:"+role)
 same(original["metrics"],raw["stats"],"RAW_STAT_LITERAL")
 same([x["event"] for x in obs],raw["events"],"ACTUAL_EVENTS_LITERAL")
 need(v["semantic"]["status"]==v["full_graphs"]["status"]==v["paired_graphs"]["status"]=="VERIFIED","SAVED_ASSURANCE_STATUSES")
 same(raw["model_sha256"],v["semantic"]["model_sha256"],"SAVED_MODEL_BINDING")
 same(raw["event_extent"]["sha256"],v["semantic"]["event_sha256"],"SAVED_EVENT_BINDING")
 same(len(obs),original["actual_snapshots"],"RAW_OBSERVATION_COUNT")
 h=hashlib.sha256()
 for x in raw["events"]:h.update(wire(x))
 same(h.hexdigest(),raw["event_extent"]["sha256"],"SAVED_EVENT_STREAM_HASH")
 for name in ("entry","final","restored"):same(hashlib.sha256(wire(raw[name+"_state"])).hexdigest(),raw["state_hashes"][name],"ENDPOINT_HASH")
 same(raw["entry_state"],raw["restored_state"],"ENDPOINT_RESTORED_LITERAL")
 for actual,pair in zip(obs,v["paired_graphs"]["comparisons"]):
  same(hashlib.sha256(wire(actual["state"])).hexdigest(),pair["actual_sha256"],"SAVED_ACTUAL_SNAPSHOT_HASH")
  same(pair["actual_sha256"],pair["reconstructed_sha256"],"SAVED_PAIRED_HASH_EQUAL")
 RUNS.append(dict(role=role,raw_status=raw["status"],events=len(obs),final_selected=raw["selected"],branches=raw["stats"]["branches"],backtracks=raw["stats"]["backtracks"],placements=raw["stats"]["placements"]))
 return expected

def audit():
 build=read("report/build-receipt-v1.json");need(build["schema"]=="Learned-literal-markings-report-build-v1" and build["status"]=="PASS_SAVED_DATA_AND_REPORT_BUILD","BUILD_STATUS")
 need(bp(path("report/build-receipt-v1.json"))["sha256"]=="0d6c359f6a3e7371400296e303e84e8208253e74fedb01500a5174c5b976f3e1","ROOT_OBSERVED_BUILD_BYTES")
 for x in build["artifact_pins"]:same(ref(x["path"]),x,"BUILD_ARTIFACT_PIN")
 for x in build["outputs"].values():same(ref(x["path"]),x,"BUILD_OUTPUT_BYTES")
 same(ref(build["renderer_source"]["path"]),build["renderer_source"],"BUILDER_SOURCE_BYTES")
 d=checked(build["outputs"]["data"]);need(d["schema"]=="Learned-literal-markings-report-data-v1" and d["status"]=="PASS_SAVED_DATA_PROJECTION","DATA_STATUS")
 p=read("data/protocol-frozen-v1.json");need(p["status"]=="FROZEN_BEFORE_SCIENTIFIC_IMPORTS","FROZEN_PROTOCOL")
 admission=read("review/root-source-admission-v1.json");names={"review/root-source-admission-v1.json"}
 for folder in ("source","reference","input","plan"):
  for f in (ROOT/folder).rglob("*"):
   need(not f.is_symlink(),"FROZEN_NO_SYMLINK")
   if f.is_file():names.add(f.relative_to(ROOT).as_posix())
 for x in admission["reviewed"]:same(ref(x["path"]),x,"ADMISSION_REVIEW_PIN");names.add(x["path"])
 same([ref(x) for x in sorted(names)],p["files"],"EXACT_FROZEN_FILE_SET")
 same(bp(Path(p["runtime"]["executable"]["path"])),{k:p["runtime"]["executable"][k] for k in ("bytes","sha256")},"PINNED_RUNTIME_FILE")
 same(bp(Path(p["master"]["path"])),{k:p["master"][k] for k in ("bytes","sha256")},"CURRENT_MASTER_FILE")
 same(d["provenance"]["current_external_custody"]["runtime"],p["runtime"],"PROJECTED_RUNTIME_LITERAL")
 same(d["provenance"]["current_external_custody"]["master"],p["master"],"PROJECTED_MASTER_LITERAL")
 for x in d["provenance"]["artifact_pins"]:same(ref(x["path"]),x,"DATA_ARTIFACT_PIN")
 q=phase("qualify",p,d["phase_custody"]["qualify"]);pilot=phase("pilot",p,d["phase_custody"]["pilot"])
 same(build["phase_custody"],d["phase_custody"],"BUILD_PHASE_CUSTODY")
 declared=read("input/qualification-cases-v1.json")["cases"]+read("input/pair-qualification-v1.json")["cases"]
 same([x["id"] for x in q["cases"]],[x["id"] for x in declared],"DECLARED_QUALIFICATION_IDS")
 need(len(q["cases"])==len(d["qualification"]["cases"])==17,"QUALIFICATION_COUNT")
 graphs=0
 for orig,projection in zip(q["cases"],d["qualification"]["cases"]):
  v={k:checked(x) for k,x in orig["refs"].items()};o=checked(orig["oracle"]);obs=v["observations"]
  same(projection,dict(id=orig["id"],status="QUALIFIED",raw_status=v["raw"]["status"],snapshots=len(obs),subsets=o["subsets_total"],refs=dict(orig["refs"],oracle=orig["oracle"])),"QUALIFICATION_LITERAL_PROJECTION")
  need(orig["status"]=="QUALIFIED" and all(v[k]["status"]=="VERIFIED" for k in ("semantic","full_graphs","paired_graphs")) and o["status"]=="EXHAUSTED","QUALIFIED_SAVED_GATES")
  same([x["event"] for x in obs],v["raw"]["events"],"QUALIFICATION_ACTUAL_EVENTS")
  same(o["counts"]["subsets_checked"],o["subsets_total"],"QUALIFICATION_ORACLE_CENSUS")
  graphs+=len(obs)
 expected_controls=[]
 for x in q["controls"]:
  c=checked(x["receipt"]);expected_controls.append(dict(id=x["id"],status=c["status"],reason=c.get("reason"),refs=x))
 same(d["qualification"]["controls"],expected_controls,"CONTROL_LITERAL_PROJECTION")
 same(d["base"],read("input/pilot-model-v1.json"),"BASE_MODEL_LITERAL")
 same(d["site"],read("plan/marking-support-v1.json")["site"],"DECLARED_SITE_LITERAL")
 same(d["marked"],checked(pilot["learned_model"]),"MARKED_MODEL_LITERAL")
 same(d["catalog"],pilot["catalog"],"CATALOG_LITERAL");same(d["labels"],pilot["labels"],"LABEL_LITERAL")
 run(pilot["acquisition"],d["acquisition"],"acquisition")
 need(len(pilot["labels"])==len(pilot["label_runs"])==len(d["label_runs"])==3,"PAIR_RUNS_LENGTH")
 for orig,label,projection in zip(pilot["label_runs"],pilot["labels"],d["label_runs"]):
  same(projection["pair"],label["pair"],"PAIR_ID_LITERAL");same(projection["label"],label["label"],"PAIR_LABEL_LITERAL")
  run(orig["run"],projection["run"],"pair-"+"-".join(label["pair"]))
 need(len(d["synthesis_history"])==len(pilot["synthesis_history"])==4,"FOUR_SYNTHESIS_SNAPSHOTS")
 for actual,projection in zip(pilot["synthesis_history"],d["synthesis_history"]):same(projection,dict(ref=actual,value=checked(actual)),"SYNTHESIS_FULL_LITERAL")
 same(d["failure_contexts"],pilot["failure_contexts"],"HARVESTED_CONTEXT_LITERAL")
 same(d["preservation"],checked(pilot["preservation"]),"ALL_PRESERVATION_FIELDS_LITERAL")
 ev=d["preservation"]["evidence"];same([x["mask"] for x in ev["subsets"]],list(range(16)),"SIXTEEN_SAVED_SUBSET_ROWS")
 same(ev["base_solutions"],ev["marked_solutions"],"SAVED_COVER_LISTS_EQUAL");same(ev["base_solutions"],ev["direct_solutions"],"SAVED_DIRECT_COVER_LIST_EQUAL")
 for orig,projection in zip(pilot["lanes"],d["lanes"]):same(orig["lane"],projection["lane"],"LANE_ID");run(orig,projection,"lane-"+orig["lane"])
 same([x["lane"] for x in d["lanes"]],["BASE","MARKS","PAIR_FILTER"],"THREE_LANE_ORDER")
 need(len(pilot["marked_pair_replays"])==len(d["marked_pair_replays"])==3,"REPLAY_LENGTH")
 for orig,projection in zip(pilot["marked_pair_replays"],d["marked_pair_replays"]):
  if "run" in orig:
   same({k:x for k,x in projection.items() if k!="run"},{k:orig[k] for k in ("pair","status")},"POSITIVE_REPLAY_METADATA");run(orig["run"],projection["run"],"marked-replay-"+"-".join(orig["pair"]))
  else:same(projection,orig,"NEGATIVE_LITERAL_REPLAY")
 control=checked(pilot["preservation_control"]);same(d["preservation_control"],dict(status=control["status"],reason=control["reason"],ref=pilot["preservation_control"]),"PRESERVATION_REFUSAL_LITERAL")
 coverage=dict(qualification_cases=17,qualification_actual_graphs=graphs,qualification_controls=len(q["controls"]),catalog_pairs=3,synthesis_calls=4,subsets=16,capacity_legal_subsets=sum(x["base_capacity_legal"] is True for x in ev["subsets"]),original_covers=len(ev["base_solutions"]),pilot_actual_graphs=sum(x["events"] for x in RUNS))
 same(d["coverage"],coverage,"PROJECTED_COVERAGE_LITERAL");same(build["coverage"],coverage,"BUILD_COVERAGE_LITERAL")
 same(coverage,dict(qualification_cases=17,qualification_actual_graphs=143,qualification_controls=11,catalog_pairs=3,synthesis_calls=4,subsets=16,capacity_legal_subsets=8,original_covers=2,pilot_actual_graphs=43),"REPORTED_STUDY_COUNTS")
 costs=dict(qualification=d["phase_custody"]["qualify"],pilot=d["phase_custody"]["pilot"],synthesis_call_seconds=sum(x["call_seconds"] for x in pilot["synthesis_history"]),preservation_call_seconds=pilot["preservation"]["call_seconds"],pair_label_engine_call_seconds=sum(x["run"]["refs"]["raw"]["call_seconds"] for x in pilot["label_runs"]),lane_engine_call_seconds={x["lane"]:x["refs"]["raw"]["call_seconds"] for x in pilot["lanes"]},scope=pilot["timing_scope"])
 same(d["costs"],costs,"ACTUAL_RECORDED_COST_PROJECTION");same(build["costs"],costs,"BUILD_COST_PROJECTION")
 html=path(build["outputs"]["main"]["path"]).read_text()
 for literal in ("No distinct GCTS advantage","13 prior fixtures plus 4 new fixtures","Placed-event counts include placements in failed branches","Raw warm engine call, ms","No geometry predicate participates","LEARNED_LITERAL_MARKINGS_ARCHIVE_LINK"):
  need(literal in html,"HTML_SCOPE_LITERAL:"+literal)
 return dict(status="PASS",schema="Learned-marking-independent-literal-data-audit-v1",coverage=coverage,phase_pids={k:x["pid"] for k,x in d["phase_custody"].items()},runs=RUNS,learned_assignments=d["synthesis_history"][-1]["value"]["assignments"],saved_covers=ev["base_solutions"],costs=costs,build_receipt=ref("report/build-receipt-v1.json"),outputs=build["outputs"],frozen_files_checked=len(p["files"]),literal_checks=len(CHECKS),artifact_pins=list(LEDGER.values()),scientific_imports=False,scientific_calls=0,state_transitions_replayed=0,scope="Exact saved bytes/literals/projection and recorded counters/costs only; no revalidation of native point legality, preservation, synthesis, graph transitions or theorem truth. Main HTML pin is at audit cut before any later archive-link insertion.")
if __name__=="__main__":
 started=time.perf_counter()
 try:result=audit()
 except Exception as error:result=dict(status="FAIL",reason=type(error).__name__+":"+str(error),checks_completed=len(CHECKS),artifact_pins=list(LEDGER.values()),scientific_imports=False,scientific_calls=0,state_transitions_replayed=0)
 result.update(seconds=time.perf_counter()-started,auditor=dict(path=Path(__file__).relative_to(ROOT).as_posix(),**bp(Path(__file__))),auditor_runtime=dict(executable=sys.executable,version=sys.version))
 target=ROOT/"review/report-independent-data-audit-v1.json"
 with target.open("xb") as f:f.write(wire(result))
 print(json.dumps({k:result[k] for k in ("status","seconds")}|({"reason":result["reason"]} if "reason" in result else {"coverage":result["coverage"],"literal_checks":result["literal_checks"]})))
 raise SystemExit(0 if result["status"]=="PASS" else 1)
