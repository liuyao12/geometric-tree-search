# Independent driver and preservation-oracle Source closure

Status: **PASS_SOURCE_REVIEW_BEFORE_EXECUTION**. The full driver, independent
preservation oracle and both APIs were read. Final custody/master/cleanup
deltas were reread and current Python Sources AST-parsed. This reviewer ran no
scientific import, model construction, solver, engine, checker, oracle, learner,
test or experiment. Only this peer note was written for this task.

## Final pins

| Artifact | Bytes | SHA256 |
| --- | ---: | --- |
| `source/run_marking_pilot_v1.py` | 32348 | `eeabd78f2f6816d32887af3ff22b0fb49aacd53a8ec0583840f50a5518a1d122` |
| `plan/driver-API-v1.md` | 9295 | `93af2b8088826eb83f141fc02caa96454e086cf2c306995a41b535ef213bbcab` |
| `source/marking_preservation_oracle_v1.py` | 26661 | `1b55ba046d4ba376e8b80c2eadf28b3a2bb8f9eee9dae1847c93de2dbf84d5c2` |
| `plan/preservation-API-v1.md` | 9122 | `bc737fdfb26aac6c1d95148c2aa4f84314cce278301c624a396c769f45607864` |

E3, C2, T2 and final synthesis remain held at their earlier reviewed pins:
`85e55b2a…`, `5258610e…`, `a0417e25…`, `b6a8c254…`. Their prior independent
Source reviews are separate evidence; this review does not claim runtime
qualification. No logical or integration blocker remains in the inspected
driver/oracle scope.

## Driver custody and actual observations

Scientific imports occur only after the exact Root admission, prospective
Source/reference/input/plan/review-pin freeze, executable/flags and limits are
checked. The final protocol also pins the freshly matching current master and
local normative copy; both are checked at freeze and the current master is
rechecked before/after phases. Sources and input declarations cannot change
between qualification and pilot. Original attempt paths are exclusive and
refuse silent retries.

Every ordinary engine output and actual callback stream is saved before C2,
T2, private Reader or oracle assurance. T2 receives actual producer snapshots;
the extra private C2 Reader independently reconstructs and compares each state,
without fabricating observations for T2. The independently declared seventeen
qualification cases retain their expected existence/observation gates. Remote
pair controls have no shared positive/mark support, and include selected-pair,
rollback and literal-zero interactions.

The altered-graph control reinserts the forbidden CID consistently in eligible,
domain, forward, reverse and edge-count data, so rejection tests pair-aware full
legality rather than merely an internally broken graph shape. The altered event
control refreshes the ordinary event digest; malformed/resource attempts retain
their own distinct evidence and cannot become negative labels.

Before pilot, actual qualification started/invocation/observer phase and PID,
protocol ref, log bytes, result path/bytes/counts and every case/control artifact
pin are joined. The final three complete-JSON predicates cover the result and
all saved case/control refs. Qualification status alone cannot activate pilot.
The observer uses one owned process group, actual exit and bounded cleanup.
TERM/KILL OSErrors, the first TERM-wait OSError and final wait failures are
recorded rather than bypassing observer/postcheck persistence. The outer command
returns nonzero for unadmitted native/guard/observer/reap/postcheck outcomes.
Polled RSS is correctly described as observation, not an instantaneous bound.

## Label and learning information flow

The acquisition model is unmarked. Every capacity-legal meeting pair is formed
from positive rows alone. A fixed-pair problem sums the two rows into the seed,
activates their exposed support together with the original target, removes those
exact CIDs from the residual inventory and requires an empty ordinary-pair list.
It therefore counts fixed members once. No provisional marking or learned filter
feeds label acquisition.

The initial synthesis consumes no labels and must return no assigned components.
Each subsequent call consumes only accumulated actual certified pair labels,
inventory IDs, declared support and bounds. No selected proof, exhaustive cover
table, expected bad pair or expected marking is an argument. Every catalog pair
is used; no pair-label holdout is invented. A nonconclusive engine/assurance gate
preserves the failed attempt and prevents activation instead of making UNKNOWN
negative. The code does not silently retry or repair that attempt.

The actual synthesized model and hash are saved/frozen before preservation.
The complete oracle has no output path into the learner. Its independently
enumerated catalog and cover-derived labels are compared with acquisition only
after that freeze, as an admission gate. A mismatch refuses admission and cannot
trigger retraining. Context witnesses are not treated as global pair nogoods
until the separately checked fixed-target pair extension certifies them.

BASE, MARKS and PAIR_FILTER each call the same engine with a fresh state and the
same positive inventory/target/scheduler/ties/budgets. MARKS has empty pairs and
real point assignments; PAIR_FILTER has empty original markings and the learned
ordinary pairs. Literal-negative replay saves the actual two marked rows and
reports direct agreement rejection with zero extra engine calls. Compatible
positive marked pairs receive separate engine/assurance calls. The deliberate
lost-positive control never enters learning or a measured lane.

## Independent preservation logic

The oracle imports no engine, checker, learner, model helper or supplied witness.
It independently normalizes exact native rows and canonical pair lists. In
preservation mode the base is unmarked, both model pair lists and marked seed
markings must remain empty, and every positive row/CID/capacity/root/seed-total
is identical. Only per-CID marking rows can differ.

It enumerates every subset and recomputes integer totals, active obligations,
whole-family literal agreement, pair constraints and positive-support root
reachability. A full cover must be exact at every active point, capacity-legal
everywhere and rooted; disconnected extra islands do not become solutions.
The model uses each CID once. Reachability is not misrepresented as the GCTS
scheduler or generation proof.

All base-capacity-legal partial subsets, including unreachable or already
constraint-inconsistent ones, are checked for literal/filter agreement and
equal eligible sets, complete frontier domains and weighted edges. Whole-family
extension tests correctly leave no eligible extension for an already-invalid
marked/direct state. Original, marked and direct complete solution sets must
agree, and every learned pair must occur in no original full cover. Separate
complete pair-catalog and nogood-extension phases retain exact coverage/refusal
scope. No incomplete prefix can return VERIFIED preservation or absence.

The API now distinguishes stored integer units \(u_c\), integer totals \(U_S\),
capacity \(C\), and normalized master values \(t_c=u_c/C\). This was a
documentation-only correction; oracle arithmetic and Source pin are unchanged.

## Resource and result limits

The larger oracle work cap of one billion was set prospectively before any
execution, after static inspection identified the twelve-CID qualification
fixture's full \(4{,}096\) subset table. It retains all subsets, candidate and
wall bounds; it is not a retry or evidence of performance. Calls/serialization,
phase clocks and UNKNOWN/refusal paths remain distinct. The oracle reserves
full evidence output conservatively and returns explicit partial coverage on
resource refusal.

The driver correctly disclaims speed inference from fixed lane order in one
warm process. A successful future run would establish one finite anchored
mechanism and preservation/equivalence gates. It would not establish geometric
prototype reuse, a held-out target result, learned receptor transfer, RL benefit,
an automated mathematical theorem, superiority over ordinary nogoods or any
infinite-domain conclusion. The supplied design and actual learning execution
must remain distinguishable in the eventual report.
