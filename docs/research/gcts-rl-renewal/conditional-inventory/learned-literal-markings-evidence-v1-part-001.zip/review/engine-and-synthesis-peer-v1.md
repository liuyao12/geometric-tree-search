# Engine pair control and literal synthesis: independent Source review

Status: **PASS_SOURCE_REVIEW_PENDING_PROSPECTIVE_FREEZE_AND_QUALIFICATION**.
No scientific imports, model building, solver/checker/oracle call, test, or
experiment was performed. The checker-v2 Sources are held unchanged.

## Exact reviewed pins

| File | Bytes | SHA-256 |
| --- | ---: | --- |
| `source/growing_point_search_v3.py` | 42192 | `85e55b2ae489dedd5eaae2f62d49498f47e91bf5a538159f6815e0b80767d8cc` |
| `plan/engine-API-v1.md` | 5914 | `237e6727866800afd4189293a21df883bd5881f93b6a09d0571fa84150603256` |
| `review/engine-adaptation-v1.patch` | 5620 | `38e9293fb6acc81e1d4aca7edc9c79046e08a85d41f3da2423918535b41eabed` |
| `source/learn_literal_markings_v1.py` | 4648 | `e200493ead48b56646fb0dc6c413529c9347a46fd1968e378aa09bd0af56d307` |

The exact engine-v2 baseline is 39556 bytes, SHA-256
`6e9687145ec2c86719266e07f7ddee4077d88a386c67152dec368657eae43cbb`.
Its full body was reviewed during the prior semantic-assurance work. The whole
new adaptation and engine API were read, along with the full synthesis body.
Direct AST comparison, without import or invocation, confirms the engine's
function-name set is unchanged and only `_model`, `_State.__init__`,
`_State._legal`, `_State.place`, and `_State.certificate` differ. All scheduler,
event, propagation, snapshot, undo, provider, result and limit routines retain
the exact baseline function bodies. No blocking Source defect was found.

## Producer pair-control assessment

Model-v2 parsing requires the new mandatory pair list and preserves the old
six-field meanings. Each pair is native literal CID data, strictly internally
ordered, distinct, known in the full explicit universe, and strictly increasing
in the outer list. For provider inventories, nonempty pairs refuse before an
explicit-ID lookup, while empty pairs preserve the prior provider path.

The immutable neighbor mapping is built from copied normalized data. A
candidate fails ordinary-filter legality if a neighbor is selected. Selecting
a candidate adds all those neighbors to the affected refresh set, including
rows sharing no positive or marking support. Existing eligibility and graph
updates remain fully trailed; the immutable index itself is not branch state.
Exclusion does not select a candidate and correctly requires no neighbor
propagation. Undo restores the original selected/eligibility/incidence state
through the unchanged inverse trail.

The final positive certificate independently scans the original pair list
against chosen row IDs, rather than trusting only the index. Pair constraints
do not alter the complete inventory, tie-breaking, global dead/forced order,
generation convention, or fallback. Their cooperative work is charged while
the meaning of `dependency_links` remains positive/mark support only. Empty
pair models still have some new schema/index work; there is no bit-identical
work-count or speed claim.

The producer and API accurately label pairs as an ordinary declared filter,
separate from literal markings. They do not establish redundancy. Root's
separate preservation oracle must justify any original-model claim; a failure
obtained only after adding a pair filter cannot justify that same filter.

## Synthesis assessment

The synthesis routine has no scientific imports, expected bad pair, fixed CID,
or target assignment. The one site and binary literal colors are an explicit
representation budget. `None` represents absence, separately from assigned
zero. It enumerates the full finite assignment space within the declared caps,
tests every resolved label, and minimizes assigned components before its
absent/zero/one lexical tie order. Unknown labels impose no constraint and are
reported separately. A pattern/resource refusal does not return a partially
optimized assignment as SOLVED or declare unrepresentability.

A positive pair is required to agree wherever both components are assigned;
a negative pair requires two assigned unequal values. This matches literal
point agreement, not a runtime pair-scanner substitution. The output consists
of explicit per-CID marking rows. The caller still must validate provenance
of the resolved labels, apply those rows to the actual model, independently
prove preservation/equivalence, freeze the resulting model, and keep
provisional marks out of the unmarked classification search.

The complete-enumeration objective and preservation scope are stated honestly.
UNREPRESENTABLE means only the declared one-site/two-color budget; it is not a
general marking-expressivity theorem. The work counter primarily counts label,
pattern, and constraint checks, rather than complete literal input sorting and
output construction. This is not a logical blocker for the fixed tiny pilot;
measured whole-call/pipeline cost and owned process guards must remain visible,
and it should not be advertised as complete generic byte-work accounting.

Source review does not establish observed learned values, candidate removals,
rollback behavior, preserved cover sets, or acceleration. Migrated fixtures,
remote pair-dependency controls, independent all-subset preservation, malformed
input/resource controls and actual post-learning marked/filter runs remain
prospective qualification obligations.
