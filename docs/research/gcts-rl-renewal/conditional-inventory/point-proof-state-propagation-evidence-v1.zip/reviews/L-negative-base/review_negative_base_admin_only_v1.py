"""Final-case strict metadata/byte prospective review, no project execution."""
from pathlib import Path
import ast
import datetime
import hashlib
import json
import os
import re
import stat
import sys

OUT = Path('/private/tmp/gcts-L-negative-base-prospective-review-20261027-v1')
ACTIVE = Path('/private/tmp/gcts-state-propagation-20261027-active-v1')
ROOT = ACTIVE / 'root'
CASE = 'state-propagation-negative-base-v1-case-0'
PRIOR_CASES = ['state-propagation-api-v1-case-0', 'state-propagation-positive-base-v1-case-0', 'state-propagation-positive-state-v1-case-0', 'state-propagation-negative-state-v1-case-0']
MIRROR = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-state-propagation-20261027/custody-L/negative-base-prospective-review-v1')

def ref(path, size, digest):
    return {'path': str(path), 'bytes': size, 'sha256': digest}

def pin(path, body):
    return ref(path, len(body), hashlib.sha256(body).hexdigest())

def read_pinned(record):
    assert type(record) is dict and set(record) == {'path', 'bytes', 'sha256'}
    assert type(record['path']) is str and type(record['bytes']) is int and record['bytes'] > 0
    assert type(record['sha256']) is str and re.fullmatch('[0-9a-f]{64}', record['sha256'])
    body = Path(record['path']).read_bytes()
    assert pin(record['path'], body) == record
    return body

def unique(pairs):
    result = {}
    for key, value in pairs:
        assert key not in result
        result[key] = value
    return result

def bad_constant(value):
    raise ValueError(value)

def parse(body):
    return json.loads(body.decode('utf-8'), object_pairs_hook=unique, parse_constant=bad_constant)

def safe(path):
    p = Path(path)
    assert p.is_absolute() and str(p.resolve()) == str(p)
    for q in [p, *p.parents]:
        assert not q.is_symlink()
    s = p.stat()
    assert stat.S_ISREG(s.st_mode) and s.st_nlink == 1
    return {'bytes': s.st_size, 'canonical_regular_singlelink_nonsymlink': True}

def literals(body, wanted):
    tree = ast.parse(body.decode('utf-8'))
    result = {}
    for node in tree.body:
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id in wanted:
                    result[target.id] = ast.literal_eval(node.value)
    assert set(result) == set(wanted)
    return result, tree

def save(name, obj):
    body = (json.dumps(obj, sort_keys=True, indent=2, ensure_ascii=False, allow_nan=False) + '\n').encode()
    p = OUT / name
    with p.open('xb') as h:
        h.write(body); h.flush(); os.fsync(h.fileno())
    assert p.read_bytes() == body
    with (MIRROR / name).open('xb') as h:
        h.write(body); h.flush(); os.fsync(h.fileno())
    assert (MIRROR / name).read_bytes() == body
    return pin(p, body)

expect_pin = ref('/private/tmp/gcts-L-negative-base-prefreeze-20261027-v1/state-propagation-negative-base-prefrozen-prospective-requirements-v1.json', 10362, '57e4fe05f4243b0353d3bf6e84c41d445b57581146cdad6a9db1914e88d61283')
expect = parse(read_pinned(expect_pin))
plan_pin = ref(ROOT / (CASE + '-plan-v1.json'), 1967, 'c4d537fd49e1397046084daf564a90d6d235c99be0f4b720236825cba8e10f8d')
plan_body = read_pinned(plan_pin)
plan = parse(plan_body)
prior_pin = ref(ROOT / 'state-propagation-negative-state-v1-case-0-Root-complete-whole-actual-adoption-v1.json', 10722, '706b2050eba06f9eb60cadacca8f9da1a6e48f57f5e5c0782ace0296566cbe7c')
prior_opaque = read_pinned(prior_pin)
del prior_opaque
abi_pin = ref('/private/tmp/gcts-L-active-ABI-join-20261027-v1/state-propagation-once-plan-worker-terminal-ABI-v2.json', 14165, '557d4d28f2229e45c1fcf901379c97726b7da4fa1c2189d83b6e0340e28e03c1')
binding_pin = ref('/private/tmp/gcts-L-active-ABI-join-20261027-v1/state-propagation-active-runtime-ABI-complete-binding-inverse-static-join-v1.json', 21033, '7dbd85bad238677545136fc8a1668cba9408f24f797c327714aa08da48097431')
adoption_pin = ref(ROOT / 'state-propagation-active-five-role-Root-operational-Source-adoption-v1.json', 4925, '885d51ef0137dc50f7c8d66f6e2f1d0863be16e68424cd89f1511f1ba3bfce7b')
abi = parse(read_pinned(abi_pin)); binding = parse(read_pinned(binding_pin)); adoption = parse(read_pinned(adoption_pin))
assert type(plan) is dict and set(plan) == set(abi['plan']['exact6']) == {'schema', 'case_id', 'actual_dir', 'python', 'sources', 'limits'}
assert type(plan['schema']) is str and plan['schema'] == expect['strict_future_plan']['schema'] == abi['plan']['schema']
assert type(plan['case_id']) is str and plan['case_id'] == CASE == expect['future_case_id']
assert type(plan['actual_dir']) is str and plan['actual_dir'] == str(ACTIVE / 'actual' / CASE)
assert type(plan['limits']) is dict and set(plan['limits']) == set(expect['limits_exact7']) and all(type(v) is int for v in plan['limits'].values())
assert plan['limits'] == expect['limits_exact7'] == abi['plan']['limits_exact7']
assert plan['python'] == abi['plan']['python'] == adoption['D90_current_rawpin']
assert Path(plan['python']['path']) == Path(sys.executable) and sys.version_info[:3] == (3, 12, 14)
assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
read_pinned(plan['python']); runtime_fs = safe(plan['python']['path'])
assert type(plan['sources']) is dict and set(plan['sources']) == {'observer', 'worker', 'engine', 'compiler', 'oracle'}
assert plan['sources'] == expect['five_Source_pins_for_later_fresh_verification'] == adoption['all_five_Source_current_pins']
assert plan['sources'] == {r: v['current'] for r, v in binding['current_Source_roles'].items()}
bodies, paths = {}, {}
for role, record in sorted(plan['sources'].items()):
    assert record['path'] == abi['five_exact_active_roles'][role] and Path(record['path']).is_relative_to(ACTIVE) and record['bytes'] <= 2097152
    paths[role] = safe(record['path']); bodies[role] = read_pinned(record)
assert sum(r['bytes'] for r in plan['sources'].values()) == 175208
assert abi['observer_Source_path'] == plan['sources']['observer']['path'] and abi['engine_exact'] == plan['sources']['engine']
assert adoption['complete_public_ABI_fully_read'] == abi_pin and binding['review_passed'] and not binding['blockers']
plan_fs = safe(plan_pin['path'])
assert Path(plan_pin['path']).parent == ROOT and len(plan_body) <= 65536
worker, tree = literals(bodies['worker'], {'CASE_MAP', 'LIMITS', 'PYTHON', 'HISTORY_PARTITIONS', 'VERSION', 'PLAN_SCHEMA', 'RESULT_SCHEMA', 'TERMINAL_SCHEMA', 'RESULT_KEYS', 'TERMINAL_KEYS', 'CAPTURE_SITE', 'ELAPSED_ORIGIN', 'RSS_SCOPE', 'TERMINAL_TAIL'})
observer, _ = literals(bodies['observer'], {'CASE_MAP', 'LIMITS', 'PYTHON', 'CHUNK', 'METADATA_CAP', 'TERMINAL_CAP', 'CLOCK_ORIGINS'})
case_map = {v['case_id']: v['descriptor'] for v in abi['plan']['case_map_and_order']}
assert worker['CASE_MAP'] == observer['CASE_MAP'] == case_map and list(worker['CASE_MAP']) == list(observer['CASE_MAP']) == list(case_map)
assert case_map[CASE] == expect['descriptor'] == {'arm': 'BASELINE', 'lane': 'BENCHMARK', 'problem': 'PRIMARY_IMPOSSIBLE_FINAL'}
partition = worker['HISTORY_PARTITIONS']['PRIMARY_IMPOSSIBLE_FINAL']
assert partition == expect['zero_reference']['partition'] and sum(partition.values()) == 19683
assert worker['LIMITS'] == observer['LIMITS'] == plan['limits'] and worker['PYTHON'] == observer['PYTHON'] == plan['python']
assert worker['PLAN_SCHEMA'] == plan['schema'] and worker['RESULT_SCHEMA'] == abi['worker_result']['schema']
assert worker['RESULT_KEYS'] == abi['worker_result']['exact12'] and worker['TERMINAL_KEYS'] == abi['worker_terminal']['exact9']
assert worker['TERMINAL_SCHEMA'] == abi['worker_terminal']['schema'] and worker['VERSION'] == abi['worker_terminal']['version']
for name, key in [('CAPTURE_SITE', 'capture_site'), ('ELAPSED_ORIGIN', 'elapsed_origin'), ('RSS_SCOPE', 'rss_scope'), ('TERMINAL_TAIL', 'tail')]:
    assert worker[name] == abi['worker_terminal'][key]
assert observer['CHUNK'] == abi['caps']['CHUNK'] and observer['METADATA_CAP'] == abi['caps']['METADATA_CAP'] and observer['TERMINAL_CAP'] == abi['caps']['TERMINAL_CAP']
bench = next(n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef) and n.name == 'benchmark')
base = next(n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef) and n.name == 'base')
base_text = ast.get_source_segment(bodies['worker'].decode(), base)
assert '"#100#"' in base_text and '"#101#"' in base_text and 'wanted' in base_text
text = ast.get_source_segment(bodies['worker'].decode(), bench)
clauses = ['model, extension, erased, erasure = baseline, None, None, None', 'if descriptor["arm"] == "CERTIFIED_STATE":', 'histories["complete"] is True and histories["examined"] == 19683', 'self.audit_count <= 2000', 'engine = self.engine.Engine(model, audit=audit, budget=engine_budget)', 'result = engine.solve(node_limit=10000)', 'unknown = result["status"] == "UNKNOWN"', 'self.oracle.verify_solve_result(model, result, entry, final, expected, unknown)', 'self.oracle._same(final, entry, "negative or UNKNOWN whole restoration")', 'self.oracle._same(restored, entry, "entire explicit entry restoration")', '"observed": None, "matched": None, "evaluation": "NOT_APPLICABLE"', 'return "COMPLETE_ARM_RESULT", counts, evidence']
assert all(x in text for x in clauses)
authority = ROOT / (CASE + '-once-authority-v1.json'); stdout = ROOT / (CASE + '-outer-stdout-v1.bin'); stderr = ROOT / (CASE + '-outer-stderr-v1.bin')
consume = Path(str(authority) + '.CONSUMED.json')
absent = [authority, stdout, stderr, consume, Path(plan['actual_dir'])]
for p in absent:
    assert str(p.resolve()) == str(p) and not p.exists() and not p.is_symlink()
    for q in p.parents:
        assert not q.is_symlink()
actual_root = ACTIVE / 'actual'
assert actual_root.is_dir() and not actual_root.is_symlink() and sorted(p.name for p in actual_root.iterdir()) == sorted(PRIOR_CASES)
actual_names = {'CONSUMED.json', 'observer-receipt.json', 'observer-terminal.json', 'stderr.bin', 'stdout.bin', 'worker-result.json'}
census = []
for folder in sorted(actual_root.iterdir()):
    assert not folder.is_symlink() and {p.name for p in folder.iterdir()} == actual_names
    for p in sorted(folder.iterdir()):
        census.append({'path': str(p), 'bytes': safe(p)['bytes'], 'scope': 'prior_actual_STAT_ONLY'})
for p in sorted(ROOT.iterdir()):
    if p.name.endswith('.CONSUMED.json') or (p.name.endswith('.bin') and '-outer-' in p.name):
        assert any(p.name.startswith(c + '-') for c in PRIOR_CASES)
        census.append({'path': str(p), 'bytes': safe(p)['bytes'], 'scope': 'prior_Root_consume_caller_STAT_ONLY'})
assert len(census) == 36
named = sum(x['bytes'] for x in census)
assert named == 36868379 and named < 402653184
root_plans = sorted(p.name for p in ROOT.iterdir() if p.name.endswith('-plan-v1.json'))
assert root_plans == sorted(c + '-plan-v1.json' for c in PRIOR_CASES + [CASE])
argv = [plan['python']['path'], '-I', '-S', '-B', plan['sources']['observer']['path'], '--plan', plan_pin['path'], '--authority', str(authority)]
caller = 'set -C\nexec ' + ' '.join(argv) + ' > ' + str(stdout) + ' 2> ' + str(stderr)
assert ';' not in caller
for role, body in bodies.items():
    assert Path(plan['sources'][role]['path']).read_bytes() == body
assert Path(plan_pin['path']).read_bytes() == plan_body
read_pinned(plan['python'])
support = {
    'schema': 'L-state-propagation-negative-base-complete-prospective-support-v1', 'review_passed': True, 'blockers': [],
    'prefrozen_requirements': expect_pin, 'subject': plan_pin, 'complete_strict_parsed_plan': plan,
    'prior_negative_STATE_adoption_opaque_rawpin_verified_NOT_parsed': prior_pin,
    'prior_gate_basis': 'Direct Root assignment reports full negative STATE admission after B/Root whole review. Prior adoption costs/witness values not parsed; no prior actual body read/hash/parse or independent replay.',
    'Source_basis': {'operational_adoption': adoption_pin, 'public_ABI': abi_pin, 'complete_binding_inverse': binding_pin},
    'plan_path_metadata': plan_fs, 'fresh_current_five_Source_guards': plan['sources'], 'Source_path_metadata': paths, 'Source_total_bytes': 175208,
    'fresh_D90_raw_guard': plan['python'], 'runtime_path_metadata': runtime_fs, 'admin_runtime_flags': {'version': sys.version, 'isolated': sys.flags.isolated, 'no_site': sys.flags.no_site, 'no_bytecode': sys.dont_write_bytecode},
    'Source_plan_runtime_full_pre_post_unchanged': True, 'exact_descriptor': case_map[CASE], 'limits_exact7': plan['limits'], 'caps': expect['caps'],
    'worker_static_current_branch': {'Source': plan['sources']['worker'], 'base_lines': [base.lineno, base.end_lineno], 'benchmark_lines': [bench.lineno, bench.end_lineno], 'all_clauses_joined': clauses, 'context': expect['context'], 'history_partition_literal_NOT_executed': partition, 'null_and_conditional_evidence': expect['null_and_conditional_evidence']},
    'terminal_bindings': {'result_schema': worker['RESULT_SCHEMA'], 'result_exact12': worker['RESULT_KEYS'], 'terminal_schema': worker['TERMINAL_SCHEMA'], 'terminal_exact9': worker['TERMINAL_KEYS'], 'cost_exact6': abi['worker_terminal']['cost_exact6'], 'worker_version': worker['VERSION'], 'capture_site': worker['CAPTURE_SITE'], 'elapsed_origin': worker['ELAPSED_ORIGIN'], 'rss_scope': worker['RSS_SCOPE'], 'tail': worker['TERMINAL_TAIL']},
    'observer_clock_scope': observer['CLOCK_ORIGINS'], 'full36_STAT_ONLY_named_census': census, 'named_bytes': named, 'named_cap': 402653184, 'remaining_named_bytes': 402653184 - named,
    'new_fresh_paths_absent': [str(p) for p in absent], 'existing_plan_names_metadata_only': root_plans,
    'future_Root_caller_NEVER_EXECUTED_HERE': {'shell': '/bin/zsh', 'login': False, 'workdir': str(ACTIVE), 'literal_two_line_command': caller, 'combined_capture_bytes_cap': 1048576, 'yield_time_ms': 1000, 'requirements': 'Noclobber full raw captures, exec replaces shell, no additional Python capture parent/tee/echo/helper; full original tool response/sessionID and owned process terminal, no restart/liveprefix. Full outer/custody/terminal/result/log/guard/resource joins and separate scientific whole review.'},
    'scope': 'Complete focused exact final plan/fresh guards/public BASELINE branch/zero-reference/disposition/freshness/caller/caps. Only prior artifact stat extents; prior10722 adoption rawpin opaque. No actual/cost/witness/model/history/checker/helper/CLI/import/Source function/codeobject execution; no Source/plan/A6/capture/actual/stage/publication edits or creation.',
    'scientific_execution_authorized': False, 'A6_creation_authorized': False
}
support_pin = save('state-propagation-negative-base-complete-prospective-support-v1.json', support)
review = {
    'schema': 'L-state-propagation-negative-base-complete-independent-prospective-review-v1',
    'status': 'FOCUSED_COMPLETE_FINAL_PLAN_PROSPECTIVE_PASS_EXECUTION_NOT_AUTHORIZED', 'review_passed': True, 'blockers': [],
    'issued_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'subject': plan_pin, 'prefrozen_requirements': expect_pin, 'complete_support': support_pin,
    'prior_negative_STATE_adoption_opaque_pin_only': prior_pin, 'current_Source_operational_adoption': adoption_pin, 'current_public_ABI': abi_pin, 'whole_Source_binding': binding_pin,
    'all_final_plan_conditions': {'strict_plan': 'Entire1967bytes exactpin, strict duplicate/nonfinite/type/keyset JSON checks pass: exactly6 plan keys/rawpin3s, no extra control/descriptor or bool/float standin.', 'descriptor': case_map[CASE], 'context': expect['context'], 'actual_dir': plan['actual_dir'], 'Source_runtime': 'All5 complete active Source rawpins175208bytes and full D90 executable freshly verified before/after, canonical regular singlelink nonsymlink paths and exact Root/ABI associations.', 'limits': plan['limits'], 'caps': expect['caps'], 'prior_gate': 'Root admitted negative STATE. Prior10722 adoption fullrawpin verified opaque only, no cost/witness re-follow; old grants permanently spent.'},
    'BASELINE_no_STATE_recipe': expect['BASELINE_recipe'],
    'null_and_conditional_evidence': expect['null_and_conditional_evidence'],
    'closed_zero_reference': expect['zero_reference'],
    'full_global_event_context_pruning_restore': expect['full_event_context_rollback_evidence'],
    'EXHAUSTED_UNKNOWN_and_stop_rules': expect['status_rules'],
    'postactual_gates': ['Root full prospective/support adoption, independent complete wholeactual criteria ready; immediate fresh raw guards/named accounting/fresh paths and all B-C-L plus unrelated Root authoring/render/network work idle. C administrative preparer authoring must quiesce before final measurement; this reviewer attests only its own tools idle.', 'Only Root later creates/grants one fresh exact A6 authorizedtrue/int1/currentcase/currentwholeplan/currentobserver. Dual exclusive consumes/full readback precede one owned child; prior A6s cannot be reused.', 'Authoritative exec/session terminal and full original noclobber caller captures<=1MiB, full worker logs/result readback, exact canonical terminal9/cost6, owned wait/reap/groupgone/joined drains/census/8guards/resource gate complete. Result stays opaque to observer, admitted_result null; no receipt/prefix authority.', 'Independent whole actual review of actual BASELINE/full history zero-reference/all events/globaldead-forced-generation/context-pruning/full entry-final-restored associations and truthful costs. EXHAUSTED needs complete closed independent zero reference; UNKNOWN stays UNKNOWN and is not promoted by declared impossible boundary. Any semantic/custody/evidence/guard/resource inconsistency stops for whole disposition, no retry/cap increase/refit/arm replacement.'],
    'cost_scope': expect['cost_scope'], 'normal_transport_scope': expect['normal_transport'],
    'named_stat_only_accounting': {'files': 36, 'current_bytes': named, 'cap_bytes': 402653184, 'remaining_bytes': 402653184 - named, 'current_A6_consume_actual_captures_absent': True, 'meaning': 'Logical observed prior actualdir bodies+Root adjacent consumes+full caller extents only; docs/Source/plans/reviews/QA outside tally. No body read/hash/parse and no OSquota claim. Root rechecks before A6.'},
    'exact_future_caller': support['future_Root_caller_NEVER_EXECUTED_HERE'],
    'scope_reuse_and_goal': 'Current full Source/ABI/inverse/substantive peer reviews reused without scientific reexecution; current complete plan/raw guards independently checked. Explicit unavailable historical metadata boundaries retained; no fabricated recursive closure. Final case only, no new next plan/experiment/publication grant. No negative counter/time forecast, speed/fit/learning/RL/FOL/theorem/universal/infinite/novelty/full geometric conformance claim.',
    'prohibited_operations_performed': {'actual_cost_witness_body_intake': 0, 'Source_helper_model_fixture_checker_history_test_CLI_import_codeobject_execution': 0, 'Source_plan_A6_capture_actual_staging_publication_creation_or_edit': 0, 'network_oldplaceholder_retry': 0},
    'scientific_execution_authorized': False, 'A6_creation_authorized': False, 'publication_authorized': False,
    'final_state': 'TMP_FIRST_NEW_REPO_MIRROR_FROZEN; REVIEWER_TOOLS_TERMINAL_IDLE_AFTER_HANDOFF; NO SCIENTIFIC_PROCESS_STARTED.'
}
review_pin = save('state-propagation-negative-base-complete-independent-prospective-review-v1.json', review)
print(json.dumps({'review': review_pin, 'support': support_pin, 'prefreeze': expect_pin, 'named_STAT_ONLY_bytes': named, 'status': 'PASS_TERMINAL_IDLE_NO_EXECUTION_AUTHORITY'}, sort_keys=True))
