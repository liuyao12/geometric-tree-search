"""Complete focused prospective binding review; no project Source execution."""
from pathlib import Path
import ast
import datetime
import hashlib
import json
import os
import re
import stat
import sys

OUT = Path('/private/tmp/gcts-L-negative-state-prospective-review-20261027-v1')
ACTIVE = Path('/private/tmp/gcts-state-propagation-20261027-active-v1')
ROOT = ACTIVE / 'root'
CASE = 'state-propagation-negative-state-v1-case-0'
PRIOR_CASES = ['state-propagation-api-v1-case-0', 'state-propagation-positive-base-v1-case-0', 'state-propagation-positive-state-v1-case-0']
MIRROR = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-state-propagation-20261027/custody-L/negative-state-prospective-review-v1')

def ref(path, size, digest):
    return {'path': str(path), 'bytes': size, 'sha256': digest}

def rawpin(path, body):
    return ref(path, len(body), hashlib.sha256(body).hexdigest())

def pinned(record):
    assert type(record) is dict and set(record) == {'path', 'bytes', 'sha256'}
    assert type(record['path']) is str and type(record['bytes']) is int and record['bytes'] > 0
    assert type(record['sha256']) is str and re.fullmatch('[0-9a-f]{64}', record['sha256'])
    b = Path(record['path']).read_bytes()
    assert rawpin(record['path'], b) == record
    return b

def unique(pairs):
    result = {}
    for key, value in pairs:
        assert key not in result
        result[key] = value
    return result

def bad_constant(value):
    raise ValueError(value)

def parse(b):
    return json.loads(b.decode('utf-8'), object_pairs_hook=unique, parse_constant=bad_constant)

def safe(p):
    p = Path(p)
    assert p.is_absolute() and str(p.resolve()) == str(p)
    for q in [p, *p.parents]:
        assert not q.is_symlink()
    s = p.stat()
    assert stat.S_ISREG(s.st_mode) and s.st_nlink == 1
    return {'bytes': s.st_size, 'canonical_regular_singlelink_nonsymlink': True}

def literals(b, names):
    tree = ast.parse(b.decode('utf-8'))
    result = {}
    for n in tree.body:
        if isinstance(n, ast.Assign):
            for t in n.targets:
                if isinstance(t, ast.Name) and t.id in names:
                    result[t.id] = ast.literal_eval(n.value)
    assert set(result) == set(names)
    return result, tree

def save(name, obj):
    b = (json.dumps(obj, sort_keys=True, indent=2, ensure_ascii=False, allow_nan=False) + '\n').encode()
    p = OUT / name
    with p.open('xb') as h:
        h.write(b); h.flush(); os.fsync(h.fileno())
    assert p.read_bytes() == b
    with (MIRROR / name).open('xb') as h:
        h.write(b); h.flush(); os.fsync(h.fileno())
    assert (MIRROR / name).read_bytes() == b
    return rawpin(p, b)

expect_pin = ref('/private/tmp/gcts-L-negative-state-prefreeze-20261027-v1/state-propagation-negative-state-prefrozen-prospective-requirements-v1.json', 10334, '33a597143d1e84ade7453efab87bed2477772bf96f324af6d4a0ba8279e49c85')
expect = parse(pinned(expect_pin))
plan_pin = ref(ROOT / (CASE + '-plan-v1.json'), 1969, 'e65c361c6182a0f76607c310992f0d7a66a6490baf36c5ec8a09bed403d400e8')
plan_body = pinned(plan_pin)
plan = parse(plan_body)
prior_pin = ref(ROOT / 'state-propagation-positive-state-v1-case-0-Root-complete-whole-actual-adoption-v1.json', 10029, 'fdc26d348ea802fbdee12cf9e3e668bfdea5b46ebd2fa27798b1c55e502e8b0c')
prior_opaque = pinned(prior_pin)
del prior_opaque
abi_pin = ref('/private/tmp/gcts-L-active-ABI-join-20261027-v1/state-propagation-once-plan-worker-terminal-ABI-v2.json', 14165, '557d4d28f2229e45c1fcf901379c97726b7da4fa1c2189d83b6e0340e28e03c1')
binding_pin = ref('/private/tmp/gcts-L-active-ABI-join-20261027-v1/state-propagation-active-runtime-ABI-complete-binding-inverse-static-join-v1.json', 21033, '7dbd85bad238677545136fc8a1668cba9408f24f797c327714aa08da48097431')
adoption_pin = ref(ROOT / 'state-propagation-active-five-role-Root-operational-Source-adoption-v1.json', 4925, '885d51ef0137dc50f7c8d66f6e2f1d0863be16e68424cd89f1511f1ba3bfce7b')
abi = parse(pinned(abi_pin)); binding = parse(pinned(binding_pin)); adoption = parse(pinned(adoption_pin))
assert type(plan) is dict and set(plan) == set(abi['plan']['exact6']) == {'schema', 'case_id', 'actual_dir', 'python', 'sources', 'limits'}
assert type(plan['schema']) is str and plan['schema'] == expect['strict_future_plan']['schema'] == abi['plan']['schema']
assert type(plan['case_id']) is str and plan['case_id'] == CASE == expect['future_case_id']
assert type(plan['actual_dir']) is str and plan['actual_dir'] == str(ACTIVE / 'actual' / CASE)
assert type(plan['limits']) is dict and set(plan['limits']) == set(expect['limits_exact7']) and all(type(v) is int for v in plan['limits'].values())
assert plan['limits'] == expect['limits_exact7'] == abi['plan']['limits_exact7']
assert plan['python'] == abi['plan']['python'] == adoption['D90_current_rawpin']
assert Path(plan['python']['path']) == Path(sys.executable) and sys.version_info[:3] == (3, 12, 14)
assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
pinned(plan['python']); runtime_fs = safe(plan['python']['path'])
assert type(plan['sources']) is dict and set(plan['sources']) == {'observer', 'worker', 'engine', 'compiler', 'oracle'}
assert plan['sources'] == expect['required_current_Source_pins_for_future_fresh_verification'] == adoption['all_five_Source_current_pins']
assert plan['sources'] == {r: v['current'] for r, v in binding['current_Source_roles'].items()}
body_by_role, Source_paths = {}, {}
for role, record in sorted(plan['sources'].items()):
    assert record['path'] == abi['five_exact_active_roles'][role] and Path(record['path']).is_relative_to(ACTIVE)
    assert record['bytes'] <= 2097152
    Source_paths[role] = safe(record['path'])
    body_by_role[role] = pinned(record)
assert sum(x['bytes'] for x in plan['sources'].values()) == 175208
assert abi['observer_Source_path'] == plan['sources']['observer']['path'] and abi['engine_exact'] == plan['sources']['engine']
assert adoption['complete_public_ABI_fully_read'] == abi_pin and binding['review_passed'] and not binding['blockers']
plan_fs = safe(plan_pin['path'])
assert Path(plan_pin['path']).parent == ROOT and len(plan_body) <= 65536
worker, tree = literals(body_by_role['worker'], {'CASE_MAP', 'LIMITS', 'PYTHON', 'HISTORY_PARTITIONS', 'VERSION', 'PLAN_SCHEMA', 'RESULT_SCHEMA', 'TERMINAL_SCHEMA', 'RESULT_KEYS', 'TERMINAL_KEYS', 'CAPTURE_SITE', 'ELAPSED_ORIGIN', 'RSS_SCOPE', 'TERMINAL_TAIL'})
observer, _ = literals(body_by_role['observer'], {'CASE_MAP', 'LIMITS', 'PYTHON', 'CHUNK', 'METADATA_CAP', 'TERMINAL_CAP', 'CLOCK_ORIGINS'})
case_map = {v['case_id']: v['descriptor'] for v in abi['plan']['case_map_and_order']}
assert worker['CASE_MAP'] == observer['CASE_MAP'] == case_map and list(worker['CASE_MAP']) == list(observer['CASE_MAP']) == list(case_map)
assert case_map[CASE] == expect['descriptor'] == {'arm': 'CERTIFIED_STATE', 'lane': 'BENCHMARK', 'problem': 'PRIMARY_IMPOSSIBLE_FINAL'}
partition = worker['HISTORY_PARTITIONS']['PRIMARY_IMPOSSIBLE_FINAL']
assert partition == expect['complete_history_reference']['partition'] and sum(partition.values()) == 19683
assert worker['LIMITS'] == observer['LIMITS'] == plan['limits'] and worker['PYTHON'] == observer['PYTHON'] == plan['python']
assert worker['PLAN_SCHEMA'] == plan['schema'] and worker['RESULT_SCHEMA'] == abi['worker_result']['schema']
assert worker['RESULT_KEYS'] == abi['worker_result']['exact12'] and worker['TERMINAL_KEYS'] == abi['worker_terminal']['exact9']
assert worker['TERMINAL_SCHEMA'] == abi['worker_terminal']['schema'] and worker['VERSION'] == abi['worker_terminal']['version']
for name, key in [('CAPTURE_SITE', 'capture_site'), ('ELAPSED_ORIGIN', 'elapsed_origin'), ('RSS_SCOPE', 'rss_scope'), ('TERMINAL_TAIL', 'tail')]:
    assert worker[name] == abi['worker_terminal'][key]
assert observer['CHUNK'] == abi['caps']['CHUNK'] and observer['METADATA_CAP'] == abi['caps']['METADATA_CAP'] and observer['TERMINAL_CAP'] == abi['caps']['TERMINAL_CAP']
benchmark = next(n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef) and n.name == 'benchmark')
base = next(n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef) and n.name == 'base')
base_text = ast.get_source_segment(body_by_role['worker'].decode(), base)
assert '"#100#"' in base_text and '"#101#"' in base_text and 'wanted' in base_text
text = ast.get_source_segment(body_by_role['worker'].decode(), benchmark)
clauses = ['model = self.call("state_augment_model", bundle, baseline)', 'self.oracle_call("state_verify_extension", spec, bundle, baseline, model)', 'erased = self.call("state_erase_model", bundle, model)', 'self.oracle_call("state_verify_erasure", spec, bundle, model, erased)', 'histories["complete"] is True and histories["examined"] == 19683', 'self.audit_count <= 2000', 'engine = self.engine.Engine(model, audit=audit, budget=engine_budget)', 'result = engine.solve(node_limit=10000)', 'unknown = result["status"] == "UNKNOWN"', 'self.oracle.verify_solve_result(model, result, entry, final, expected, unknown)', 'self.oracle._same(final, entry, "negative or UNKNOWN whole restoration")', 'self.oracle._same(restored, entry, "entire explicit entry restoration")', '"observed": None, "matched": None, "evaluation": "NOT_APPLICABLE"', 'return "COMPLETE_ARM_RESULT", counts, evidence']
assert all(x in text for x in clauses)
authority = ROOT / (CASE + '-once-authority-v1.json')
stdout = ROOT / (CASE + '-outer-stdout-v1.bin')
stderr = ROOT / (CASE + '-outer-stderr-v1.bin')
consume = Path(str(authority) + '.CONSUMED.json')
absent = [authority, stdout, stderr, consume, Path(plan['actual_dir'])]
for p in absent:
    assert str(p.resolve()) == str(p) and not p.exists() and not p.is_symlink()
    for q in p.parents:
        assert not q.is_symlink()
actual_root = ACTIVE / 'actual'
assert actual_root.is_dir() and not actual_root.is_symlink()
assert sorted(p.name for p in actual_root.iterdir()) == sorted(PRIOR_CASES)
actual_names = {'CONSUMED.json', 'observer-receipt.json', 'observer-terminal.json', 'stderr.bin', 'stdout.bin', 'worker-result.json'}
census = []
for folder in sorted(actual_root.iterdir()):
    assert not folder.is_symlink() and {p.name for p in folder.iterdir()} == actual_names
    for p in sorted(folder.iterdir()):
        census.append({'path': str(p), 'bytes': safe(p)['bytes'], 'scope': 'prior_actual_STAT_ONLY'})
for p in sorted(ROOT.iterdir()):
    if p.name.endswith('.CONSUMED.json') or (p.name.endswith('.bin') and '-outer-' in p.name):
        assert any(p.name.startswith(c + '-') for c in PRIOR_CASES)
        census.append({'path': str(p), 'bytes': safe(p)['bytes'], 'scope': 'prior_Root_consume_caller_STAT_ONLY'})
assert len(census) == 27
named = sum(x['bytes'] for x in census)
assert named == 30181332 and named < 402653184
root_plan_names = sorted(p.name for p in ROOT.iterdir() if p.name.endswith('-plan-v1.json'))
assert root_plan_names == sorted(c + '-plan-v1.json' for c in PRIOR_CASES + [CASE])
argv = [plan['python']['path'], '-I', '-S', '-B', plan['sources']['observer']['path'], '--plan', plan_pin['path'], '--authority', str(authority)]
caller = 'set -C\nexec ' + ' '.join(argv) + ' > ' + str(stdout) + ' 2> ' + str(stderr)
assert ';' not in caller
for role, b in body_by_role.items():
    assert Path(plan['sources'][role]['path']).read_bytes() == b
assert Path(plan_pin['path']).read_bytes() == plan_body
pinned(plan['python'])
support = {
    'schema': 'L-state-propagation-negative-state-complete-prospective-support-v1', 'review_passed': True, 'blockers': [],
    'prefrozen_requirements': expect_pin, 'subject': plan_pin, 'complete_strict_parsed_plan': plan,
    'prior_positive_STATE_adoption_opaque_rawpin_verified_NOT_parsed': prior_pin,
    'prior_gate_basis': 'Root direct assignment reports full positive STATE admission after whole B/Root review. No prior adoption cost/witness values parsed, no prior actual bodies read/hashed/parsed, no independent replay or forecast revalidation.',
    'Source_basis': {'operational_Source_adoption': adoption_pin, 'public_ABI': abi_pin, 'complete_binding_inverse': binding_pin},
    'plan_path_metadata': plan_fs, 'fresh_current_five_Source_guards': plan['sources'], 'Source_path_metadata': Source_paths, 'Source_total_bytes': 175208,
    'fresh_D90_full_raw_guard': plan['python'], 'runtime_path_metadata': runtime_fs, 'admin_runtime_flags': {'version': sys.version, 'isolated': sys.flags.isolated, 'no_site': sys.flags.no_site, 'no_bytecode': sys.dont_write_bytecode},
    'all_Source_plan_runtime_full_pre_post_pins_unchanged': True,
    'exact_descriptor': case_map[CASE], 'limits_exact7': plan['limits'], 'all_other_caps': expect['other_caps'],
    'current_Source_history_partition_literal_NOT_executed': partition,
    'current_worker_static_branch_join': {'Source': plan['sources']['worker'], 'base_function_lines': [base.lineno, base.end_lineno], 'benchmark_function_lines': [benchmark.lineno, benchmark.end_lineno], 'complete_branch_clauses_joined': clauses, 'context': expect['future_context'], 'expected_empty_lists_future_obligations_not_observed': ['expected_base_solutions.solutions', 'augmented_expected_solution_checks'], 'no_negative_forecast': expect['negative_forecast']},
    'terminal_bindings': {'result_schema': worker['RESULT_SCHEMA'], 'result_exact12': worker['RESULT_KEYS'], 'terminal_schema': worker['TERMINAL_SCHEMA'], 'terminal_exact9': worker['TERMINAL_KEYS'], 'cost_exact6': abi['worker_terminal']['cost_exact6'], 'worker_version': worker['VERSION'], 'capture_site': worker['CAPTURE_SITE'], 'elapsed_origin': worker['ELAPSED_ORIGIN'], 'rss_scope': worker['RSS_SCOPE'], 'tail': worker['TERMINAL_TAIL']},
    'clock_scope': observer['CLOCK_ORIGINS'],
    'complete_stat_only27_named_census': census, 'named_bytes': named, 'cap_bytes': 402653184, 'remaining_named_bytes': 402653184 - named,
    'fresh_absent_paths': [str(p) for p in absent], 'existing_plan_names_metadata_only': root_plan_names,
    'future_Root_caller_NEVER_EXECUTED_HERE': {'shell': '/bin/zsh', 'login': False, 'workdir': str(ACTIVE), 'literal_two_line_command': caller, 'combined_caller_cap_bytes': 1048576, 'yield_time_ms': 1000, 'requirements': 'Noclobber complete raw captures; exec replaces shell, no extra Python/tee/echo/helper; retain original full tool response/sessionID, poll only owned handle until authoritative exit, no restart/liveprefix. Complete custody/terminal/log/result/guards/resources and separate whole actual review.'},
    'scope': 'Focused strict current plan, fresh full Source/runtime guards, adopted public ABI/current recipe/empty-reference/disposition/caller/freshness/caps. No project functions/model/history/checker/test/import/CLI/codeobject execution; no actual or prior cost/witness body intake. Prior10029 adoption is opaque rawpin only;27 artifact extents stat-only. No Source/plan/A6/capture/actual/staging/publication creation or edits.',
    'scientific_execution_authorized': False, 'A6_creation_authorized': False
}
support_pin = save('state-propagation-negative-state-complete-prospective-support-v1.json', support)
review = {
    'schema': 'L-state-propagation-negative-state-complete-independent-prospective-review-v1',
    'status': 'FOCUSED_COMPLETE_PROSPECTIVE_PASS_EXECUTION_NOT_AUTHORIZED', 'review_passed': True, 'blockers': [],
    'issued_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'subject': plan_pin, 'prefrozen_requirements': expect_pin, 'complete_support': support_pin,
    'prior_positive_STATE_adoption_opaque_pin_only': prior_pin, 'Source_operational_adoption': adoption_pin, 'public_ABI': abi_pin, 'whole_Source_binding': binding_pin,
    'all_current_plan_conditions': {'strict_plan': 'Entire1969bytes exactpin, whole strict duplicate/nonfinite/type/keyset JSON checks pass. Exactly6 keys, rawpin3s, no bool/float replacement or extra controls.', 'descriptor': case_map[CASE], 'context': expect['future_context'], 'fresh_actual': plan['actual_dir'], 'Source_runtime': 'All5 complete active Source pins175208bytes plus full D90 executable freshly verified before/after, canonical regular singlelink nonsymlink paths; exact current Root/ABI binding.', 'limits': plan['limits'], 'caps': expect['other_caps'], 'prior_gate': 'Root directly admitted positive STATE; exact10029 adoption verified opaque fullrawpin, no cost/witness parsing or referenced actual body intake. Prior authorities remain spent.'},
    'recipe_and_complete_evidence': expect['recipe'], 'complete_history_reference': expect['complete_history_reference'],
    'events_context_pruning_rollback': expect['all_events_context_pruning_rollback'],
    'empty_reference_precision': 'The current context must close all19683 histories with partition INITIAL18954/FINAL702/TRANSITION27/ACCEPTED0. Empty expected_base_solutions and zero per-expected-solution augmented checks are appropriate only after complete enumeration/association. Their emptiness is not positive full-solution verification or general pruning proof. Full STATE canonical extension/erasure and every ordinary event/snapshot/dependency/context/result/rollback check remain mandatory; no vacuous skip of these checks.',
    'status_and_stop': expect['status_disposition'],
    'no_negative_forecast': expect['negative_forecast'],
    'postactual_and_future_grant_gates': ['Root reads/adopts this complete prospective review/support and has independent whole-actual criteria ready. Root freshly rechecks exact Source/runtime/plan guards, all current absent paths/storage, prior spent grants and global B/C/L/unrelated Root idleness.', 'Only Root may then issue one fresh exact A6 authorizedtrue/int1/currentcase/currentwholeplan/currentobserver. Exclusive dual consume/readback before exactly one owned child; no retry/old grant or batch authority.', 'Authoritative exec/session terminal and full raw caller captures<=1MiB, full worker logs/result readback, canonical terminal9/cost6, wait/reap/groupgone/joined drains/census/8guards/observed resource bounds all required. Observer scientific result stays opaque and admitted_result null; no receipt/prefix alone admission.', 'Independent whole actual review must bind complete augmented model/context/zero history-reference/all events/snapshots/pruning/result and exact entry-final-restored rollback. EXHAUSTED requires closed full independent zero reference and normal evidence; UNKNOWN stays UNKNOWN. Any finite solution discrepancy or hard custody/resource/guard/evidence/semantic inconsistency stops cohort. No counter forecast, next-arm grant or performance claim.'],
    'resource_clock_terminal': expect['custody_terminal_costs'],
    'named_accounting': {'files_stat_only': 27, 'current_bytes': named, 'cap_bytes': 402653184, 'remaining_bytes': 402653184 - named, 'new_A6_consume_captures_actual_absent': True, 'scope': 'Observed logical file-body extents only: prior actualdirs+Root adjacent consumes+full caller captures. No prior body read/hash/parse, no OS quota claim. Root rechecks before A6.'},
    'exact_future_caller': support['future_Root_caller_NEVER_EXECUTED_HERE'],
    'scope_and_reuse': 'Reuse already adopted complete current Source/ABI/inverse and substantive B/C/L/Root review. New review independently checks complete plan/raw guards/public literals/current case; not broad algorithm retesting. Historical unavailable metadata boundaries remain explicit in Source binding; no recursive body closure claim. Negative BASELINE remains unplanned/UNRUN; no work or grant for it.',
    'prohibited_operations_performed': {'actual_cost_witness_body_intake': 0, 'model_helper_checker_history_Source_or_codeobject_execution': 0, 'Source_plan_A6_capture_actual_staging_edit_or_creation': 0, 'publication_network_or_old_placeholder_retry': 0},
    'scientific_execution_authorized': False, 'A6_creation_authorized': False, 'publication_authorized': False,
    'final_state': 'TMP_FIRST_NEW_REPO_MIRROR_FROZEN; REVIEWER_TOOLS_TERMINAL_IDLE_AFTER_HANDOFF; NO SCIENTIFIC_PROCESS_STARTED.'
}
review_pin = save('state-propagation-negative-state-complete-independent-prospective-review-v1.json', review)
print(json.dumps({'review': review_pin, 'support': support_pin, 'prefreeze': expect_pin, 'named_bytes_stat_only': named, 'status': 'PASS_TERMINAL_IDLE_NO_EXECUTION_AUTHORITY'}, sort_keys=True))
