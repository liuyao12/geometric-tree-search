"""Administrative byte/AST ABI join only. Never imports or executes project Source."""
from pathlib import Path
import ast
import copy
import datetime
import hashlib
import json
import os
import stat
import symtable
import sys

OUT = Path('/private/tmp/gcts-L-active-ABI-join-20261027-v1')
ACTIVE = Path('/private/tmp/gcts-state-propagation-20261027-active-v1')
OLD = '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-state-propagation-20261027'
MIRROR = Path(OLD) / 'custody-L/active-runtime-ABI-v2'
ALIAS = Path('/private/tmp/gcts-state-review-recovery-20261027-v2/research-runs/gcts-state-propagation-20261027')
PYTHON = {'path': '/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12', 'bytes': 18058560, 'sha256': 'd90bce0f5ac3aa40e2ee5900ad243bad0b2205ce17408278f088b34aed737840'}

def rawpin(path, body=None):
    p = Path(path)
    if body is None:
        body = p.read_bytes()
    return {'path': str(p), 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}

def pinned(path, size, digest):
    p = Path(path)
    body = p.read_bytes()
    assert len(body) == size and hashlib.sha256(body).hexdigest() == digest
    return body, rawpin(p, body)

def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=False, allow_nan=False) + '\n').encode()

def differences(a, b, pointer=''):
    if type(a) is not type(b):
        return [{'pointer': pointer, 'old': a, 'new': b}]
    if isinstance(a, dict):
        assert set(a) == set(b)
        return [d for k in a for d in differences(a[k], b[k], pointer + '/' + k)]
    if isinstance(a, list):
        assert len(a) == len(b)
        return [d for i, (x, y) in enumerate(zip(a, b)) for d in differences(x, y, pointer + '/' + str(i))]
    return [] if a == b else [{'pointer': pointer, 'old': a, 'new': b}]

def literals(tree):
    found = {}
    for node in tree.body:
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name):
                    try:
                        found[target.id] = ast.literal_eval(node.value)
                    except (ValueError, TypeError):
                        pass
    return found

def save(name, value):
    body = encoded(value)
    p = OUT / name
    with p.open('xb') as handle:
        handle.write(body)
        handle.flush()
        os.fsync(handle.fileno())
    assert p.read_bytes() == body
    return rawpin(p, body)

assert sys.version_info[:3] == (3, 12, 14)
assert sys.flags.isolated == 1 and sys.flags.no_site == 1 and sys.dont_write_bytecode
runtime_body, runtime_pin = pinned(**{'path': PYTHON['path'], 'size': PYTHON['bytes'], 'digest': PYTHON['sha256']})
del runtime_body
old_body, old_pin = pinned(ALIAS / 'custody-L/state-propagation-once-plan-worker-terminal-ABI-v1.json', 14529, '334d9ca6685f09225fd017f4f335b28cea4a526a2093ef465f33d17848eeac8d')
proposal_body, proposal_pin = pinned('/private/tmp/gcts-L-ABI-relocation-proposal-20261027-v1/state-propagation-public-ABI-path-only-successor-proposal-v1.json', 31480, '93671ad99510923c36c9cbedc082e3e1c44a1f2d45777aa35ab144c5c841776b')
contract_body, contract_pin = pinned('/private/tmp/gcts-state-review-recovery-20261027-v2/state-propagation-runtime-Source-relocation-contract-v1.json', 5332, '080c817305e48aba064449df712a22881f887ba965484cbc47a95434fa56d94a')
adoption_body, adoption_pin = pinned('/private/tmp/gcts-state-review-recovery-20261027-v2/state-propagation-five-role-Root-complete-Source-adoption-v1.json', 6613, '90aa4f164013a1b577f06f24806331ead85c30773359de6fa50f017bd732837b')
handoff_body, source_handoff_pin = pinned(ACTIVE / 'root/state-propagation-runtime-Source-five-role-handoff-v1.json', 5569, '7bda4fc8bfa5ec49296ee847b1e050255a00f557857326044f6f104b22504f5f')
old_abi = json.loads(old_body)
proposal = json.loads(proposal_body)
contract = json.loads(contract_body)
adoption = json.loads(adoption_body)
handoff = json.loads(handoff_body)
abi = copy.deepcopy(proposal['candidate_ABI_data'])
delta = differences(old_abi, abi)
assert len(delta) == 7
assert sorted(delta, key=lambda x: x['pointer']) == sorted(proposal['exact_seven_data_path_changes'], key=lambda x: x['pointer'])
assert str(ACTIVE) == handoff['active_study'] == proposal['proposed_active_study']
assert handoff['prior_whole_Source_adoption'] == adoption_pin
assert handoff['Source_contract'] == contract_pin
assert adoption['scientific_execution_authorized'] is False
assert handoff['scientific_execution_authorized'] is False
assert handoff['plan_authority_actual_created'] is False
assert abi['five_exact_active_roles'] == proposal['proposed_active_five_roles']
assert abi['observer_Source_path'] == abi['five_exact_active_roles']['observer']
assert abi['engine_exact'] == handoff['roles']['engine']['active']
restored = copy.deepcopy(abi)
for change in delta:
    parts = change['pointer'].split('/')[1:]
    parent = restored
    for key in parts[:-1]:
        parent = parent[key]
    assert parent[parts[-1]] == change['new']
    parent[parts[-1]] = change['old']
assert restored == old_abi and encoded(restored) == old_body
assert set(handoff['roles']) == {'observer', 'worker', 'engine', 'compiler', 'oracle'}
roles = {}
trees = {}
kept = {}
for role, record in sorted(handoff['roles'].items()):
    current = record['active']
    previous = record['original_alias']
    assert current['path'] == abi['five_exact_active_roles'][role]
    assert previous == adoption['current_raw_Source_aliases'][role]
    p = Path(current['path'])
    assert p.is_absolute() and str(p.resolve()) == str(p)
    for ancestor in [p, *p.parents]:
        assert not ancestor.is_symlink()
    info = p.stat()
    assert stat.S_ISREG(info.st_mode) and info.st_nlink == 1
    body, current_pin = pinned(p, current['bytes'], current['sha256'])
    prior, previous_pin = pinned(previous['path'], previous['bytes'], previous['sha256'])
    assert current_pin == current and previous_pin == previous
    count = {'observer': 1, 'worker': 2}.get(role, 0)
    assert prior.count(OLD.encode()) == count
    assert body.count(str(ACTIVE).encode()) == count
    assert body.count(OLD.encode()) == 0
    expected = prior.replace(OLD.encode(), str(ACTIVE).encode())
    inverse = body.replace(str(ACTIVE).encode(), OLD.encode())
    assert body == expected and inverse == prior
    tree = ast.parse(body.decode(), filename=str(p))
    prior_tree = ast.parse(prior.decode(), filename=previous['path'])
    inverse_tree = ast.parse(inverse.decode(), filename=previous['path'])
    full_ast_equal = ast.dump(inverse_tree, include_attributes=True) == ast.dump(prior_tree, include_attributes=True)
    assert full_ast_equal
    changed_nodes = []
    current_strings = [(n.lineno, n.col_offset, n.value) for n in ast.walk(tree) if isinstance(n, ast.Constant) and type(n.value) is str and str(ACTIVE) in n.value]
    for line, column, value in current_strings:
        owner = [n.name for n in tree.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.lineno <= line <= n.end_lineno]
        assert owner == [{'observer': 'preflight', 'worker': '_authenticate'}[role]]
        changed_nodes.append({'line': line, 'column': column, 'function': owner[0], 'old': value.replace(str(ACTIVE), OLD), 'new': value})
    assert len(changed_nodes) == count
    st = symtable.symtable(body.decode(), str(p), 'exec')
    code = compile(body, str(p), 'exec', dont_inherit=True, optimize=0)
    del code
    helper_names = [n.name for n in tree.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))]
    assert helper_names == [n.name for n in prior_tree.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))]
    roles[role] = {'current': current_pin, 'pre_relocation': previous_pin, 'relative_path': str(p.relative_to(ACTIVE)), 'changed_fixed_literal_count': count, 'literal_changes': changed_nodes, 'raw_forward_exact': True, 'raw_inverse_exact': True, 'whole_positioned_AST_inverse_exact': full_ast_equal, 'other_bytes_unchanged': True, 'top_level_helper_class_names_unchanged': helper_names, 'symbol_table_top_name': st.get_name(), 'unused_compile_passed_codeobject_discarded': True, 'current_positioned_AST_sha256': hashlib.sha256(ast.dump(tree, include_attributes=True).encode()).hexdigest(), 'pre_relocation_positioned_AST_sha256': hashlib.sha256(ast.dump(prior_tree, include_attributes=True).encode()).hexdigest()}
    trees[role] = tree
    kept[role] = body
obs = literals(trees['observer'])
worker = literals(trees['worker'])
assert obs['PYTHON'] == worker['PYTHON'] == abi['plan']['python'] == runtime_pin
assert obs['LIMITS'] == worker['LIMITS'] == abi['plan']['limits_exact7']
expected_cases = {x['case_id']: x['descriptor'] for x in abi['plan']['case_map_and_order']}
assert obs['CASE_MAP'] == worker['CASE_MAP'] == expected_cases
assert list(obs['CASE_MAP']) == list(worker['CASE_MAP']) == list(expected_cases)
assert worker['PLAN_SCHEMA'] == abi['plan']['schema']
assert worker['RESULT_SCHEMA'] == abi['worker_result']['schema']
assert worker['RESULT_KEYS'] == abi['worker_result']['exact12']
assert worker['TERMINAL_SCHEMA'] == abi['worker_terminal']['schema']
assert worker['TERMINAL_KEYS'] == abi['worker_terminal']['exact9']
assert worker['VERSION'] == abi['worker_terminal']['version']
for key, abi_key in [('CAPTURE_SITE', 'capture_site'), ('ELAPSED_ORIGIN', 'elapsed_origin'), ('RSS_SCOPE', 'rss_scope'), ('TERMINAL_TAIL', 'tail')]:
    assert worker[key] == abi['worker_terminal'][abi_key]
assert obs['CHUNK'] == abi['caps']['CHUNK'] and obs['METADATA_CAP'] == abi['caps']['METADATA_CAP'] and obs['TERMINAL_CAP'] == abi['caps']['TERMINAL_CAP']
cost_sets = [set(n.value for n in node.keys) for node in ast.walk(trees['worker']) if isinstance(node, ast.Dict) and all(isinstance(n, ast.Constant) and type(n.value) is str for n in node.keys)]
assert set(abi['worker_terminal']['cost_exact6']) in cost_sets
role_node = next(n.value for n in trees['observer'].body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'ROLE_PATHS' for t in n.targets))
relative = {}
for key, value in zip(role_node.keys, role_node.values):
    assert isinstance(value, ast.BinOp) and isinstance(value.op, ast.Div) and isinstance(value.left, ast.Name) and value.left.id == 'STUDY' and isinstance(value.right, ast.Constant)
    relative[ast.literal_eval(key)] = ast.literal_eval(value.right)
assert relative == proposal['relative_role_paths_unchanged']
for role, rel in relative.items():
    assert str(ACTIVE / rel) == roles[role]['current']['path']
assert not (ACTIVE / 'actual').exists()
for role, body in kept.items():
    assert Path(roles[role]['current']['path']).read_bytes() == body
abi_pin = save('state-propagation-once-plan-worker-terminal-ABI-v2.json', abi)
audit = {
    'schema': 'L-state-propagation-active-runtime-ABI-complete-binding-inverse-static-join-v1',
    'status': 'PASS_COMPLETE_PUBLIC_BINDING_ONLY_ALL_SCIENCE_UNRUN', 'review_passed': True, 'blockers': [],
    'issued_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'current_public_ABI': abi_pin, 'predecessor_ABI_exact_alias': old_pin,
    'predecessor_ABI_original_path_metadata_only': str(Path(OLD) / 'custody-L/state-propagation-once-plan-worker-terminal-ABI-v1.json'),
    'prefrozen_path_only_proposal': proposal_pin, 'relocation_contract': contract_pin,
    'Root_whole_pre_relocation_Source_adoption': adoption_pin, 'Root_actual_five_role_Source_handoff': source_handoff_pin,
    'current_Source_roles': roles, 'current_runtime_verified': runtime_pin,
    'protocol_data_exact_seven_path_only_changes': delta,
    'protocol_data_other_values_types_and_keysets_unchanged': True,
    'protocol_inverse_to_original_complete_14529_bytes': True,
    'public_ABI_metadata_precision': 'The ABI-v2 file preserves the entire predecessor ABI including its historical schema/status/operation-at-freeze statements, changing exactly seven path values. These inherited historical statements describe the original ABI freeze; this companion binding record is the current relocation disposition. Protocol wire schemas remain v1; current Source pins occur only in this binding and handoff. No additional protocol field or exclusion was introduced.',
    'direct_structural_joins': {'all_five_current_Source_paths_and_full_rawpins': True, 'observer_relative_five_role_paths': relative, 'exact_case_map_order': list(expected_cases), 'strict_plan6_A6_and_all_cap_and_cohort_rules': 'Entire ABI unchanged except seven paths; complete relocation inverse preserves reviewed implementation. No new plan/A6 created.', 'runtime_and_limits_observer_worker_ABI_exact': True, 'worker_result_exact12_terminal_exact9_cost_exact6_and_literals': True, 'observer_CLOCK_ORIGINS': obs['CLOCK_ORIGINS'], 'all_Source_pre_post_bytes_equal': True},
    'review_scope': 'Independent current path/rawpin/complete byte inverse/whole positioned-AST inverse and public ABI literal join. Not an independent fresh C scientific algorithm review; Root complete Source adoption and its cited complete peers remain the substantive Source authority. C Source trees were used mechanically for inverse and public interface literals, without scientific calls or algorithmic inference.',
    'historical_metadata_boundary': 'Original Root56125 Source contract remains an exact pinned association after earlier full reading; body unavailable. Original three L static/manual/clock bodies remain unavailable; exact Source/delta/patches/ABI/handoff and honest v2 successors retained. Original B support bodies were unavailable at L compiler review; B later reported exact reconstruction of seven bodies, not read or freshly joined here, with census still unavailable. No recursive historical body closure or new original-identity claim.',
    'remaining_separate_gates': ['B focused relocated worker two-literal review and C focused observer one-literal review, followed by Root whole operational Source adoption.', 'Each future strict exact case plan complete prospective review, fresh individual A6, caller full capture scope, all-peer quiescence and Root once grant. No cohort or batch grant.', 'After any future authorized invocation, authoritative process terminal/full logs/result-byte transport/resource/guard/census/worker-terminal checks and separate whole scientific review; no prefix promotion or retry.'],
    'resource_clock_scope_preserved': 'All inherited custody/capture/drain/group/reap/watchdog/consume/eight-postguard/resource/census/error algorithms preserved by raw inverse. No pre-Popen timer or cross-clock inequality. Worker main-entry excludes startup/imports; observer post-Popen-return window is not full process lifetime. Lifetime child/observer peaks+16MiB reserve remain observational, not simultaneous/process-tree/hard cap; worker post-sample and outer serialization tails unmeasured.',
    'freshness_observation': {'active_actual_directory_absent': True, 'plan_authority_consume_actual_created_by_this_task': 0},
    'operations': {'project_import_function_model_fixture_test_CLI_help_codeobject_execution': 0, 'scientific_result_or_actual_intake': 0, 'old_placeholder_or_failed_target_retry': 0, 'Source_edits_or_Source_copies': 0, 'plan_A6_consume_actual_creation': 0, 'network_UI_publication': 0, 'static_parses_symtables_unused_compiles_discarded': 5},
    'scientific_execution_authorized': False, 'publication_authorized': False,
    'Source_only_zero_scientific_invocations': True,
}
audit_pin = save('state-propagation-active-runtime-ABI-complete-binding-inverse-static-join-v1.json', audit)
handout = {
    'schema': 'L-state-propagation-active-runtime-public-ABI-complete-handoff-v2',
    'status': 'COMPLETE_INERT_PUBLIC_ABI_ACTUAL_FIVE_SOURCE_BINDING_PASS_PENDING_FOCUSED_PEERS_AND_ROOT_OPERATIONAL_ADOPTION',
    'review_passed': True, 'blockers': [], 'public_ABI': abi_pin, 'complete_binding_and_static_inverse': audit_pin,
    'Root_Source_handoff': source_handoff_pin, 'Root_prior_whole_Source_adoption': adoption_pin,
    'prefrozen_path_only_proposal': proposal_pin, 'relocation_contract': contract_pin,
    'five_current_Source_rawpins': {role: x['current'] for role, x in roles.items()},
    'exact_protocol_delta': 'Exactly seven path values vs original14529 ABI, zero other protocol changes. Original ABI full-byte inverse exact. Current Source pins are companion metadata, not extra wire fields.',
    'metadata_and_freshness_scope': audit['public_ABI_metadata_precision'],
    'historical_metadata_boundary': audit['historical_metadata_boundary'],
    'remaining_separate_gates': audit['remaining_separate_gates'],
    'scientific_execution_authorized': False, 'plan_A6_actual_created': False, 'all_science_unrun': True,
    'originals_and_all_five_Source_unchanged': True,
    'output_transport': 'Stable tmp outputs first, complete byte readback, then exclusive new repo mirror. No old frozen document or Source overwrite.',
    'final_state': 'Tools terminal/idle after administrative handoff; await separate Root operational adoption/exact future plan.'
}
handoff_pin = save('state-propagation-active-runtime-public-ABI-complete-handoff-v2.json', handout)
MIRROR.mkdir(parents=True, exist_ok=False)
for name in [Path(abi_pin['path']).name, Path(audit_pin['path']).name, Path(handoff_pin['path']).name]:
    body = (OUT / name).read_bytes()
    with (MIRROR / name).open('xb') as handle:
        handle.write(body)
        handle.flush()
        os.fsync(handle.fileno())
    assert (MIRROR / name).read_bytes() == body
print(json.dumps({'ABI': abi_pin, 'binding_static': audit_pin, 'handoff': handoff_pin, 'mirror_directory': str(MIRROR), 'Source_raw_bytes': sum(x['current']['bytes'] for x in roles.values()), 'final_state': 'TERMINAL_IDLE_NO_SCIENCE'}, sort_keys=True))
