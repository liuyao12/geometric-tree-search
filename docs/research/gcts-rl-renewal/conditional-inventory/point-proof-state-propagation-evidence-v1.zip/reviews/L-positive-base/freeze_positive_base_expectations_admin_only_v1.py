"""Freeze fresh second-case criteria before positive BASELINE plan body intake."""
from pathlib import Path
import datetime
import hashlib
import json
import os

OUT = Path('/private/tmp/gcts-L-positive-base-prospective-review-20261027-v1')
OLD = Path('/private/tmp/gcts-L-API-prospective-review-20261027-v1/state-propagation-first-API-plan-prefrozen-complete-prospective-expectations-v1.json')
body = OLD.read_bytes()
assert len(body) == 10775 and hashlib.sha256(body).hexdigest() == '0cfd9b480449e363c850757c753c69b03aa11ffd21674e9ab18113b7fdf759d1'
obj = json.loads(body)
active = '/private/tmp/gcts-state-propagation-20261027-active-v1'
case = 'state-propagation-positive-base-v1-case-0'
obj['schema'] = 'L-state-propagation-positive-base-plan-prefrozen-complete-prospective-expectations-v1'
obj['status'] = 'FRESH_FROZEN_BEFORE_SECOND_CASE_PLAN_BODY_INTAKE_NO_EXECUTION_AUTHORITY'
obj['issued_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
obj['predecessor_criteria_inherited_with_explicit_second_case_replacement'] = {'path': str(OLD), 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}
obj['future_subject_plan'] = {'path': active + '/root/' + case + '-plan-v1.json', 'bytes': 1967, 'sha256': '861f66ad188a91d0ad1b57e47d8632a1a564caf27886d29ab2db40403e187a65'}
obj['required_prior_API_complete_whole_actual_disposition'] = {'path': active + '/root/state-propagation-api-v1-case-0-Root-complete-whole-actual-adoption-v1.json', 'bytes': 7445, 'sha256': 'adc02e4d919cd1abc1d2be6e1e67b002f81838caaa8ec18b715ed82778ca317c'}
obj['prior_disposition_intake_boundary'] = 'Read full exact prior Root7445 adoption metadata only. Prior API result/controls/logs/receipts and other actual scientific bodies remain opaque and unread. For complete named storage accounting only, enumerate/stat exact active actual-directory files plus Root adjacent CONSUMED markers and full caller captures without reading/hash/parsing their bodies. Root reports prior named total11240595; independently compare full stat census. Prior first A6 permanently spent, never reused.'
obj['intake_order_and_boundary'] = 'Fresh criteria frozen before positive BASELINE plan body read/hash/parse/copy. Next read complete exact new plan, prior API disposition and current operational adoption. No project Source import/call/model/fixture/test/CLI/help or codeobject execution; no actual body semantics or old placeholder/failed target retry.'
obj['strict_plan']['case_id'] = case
obj['strict_plan']['descriptor_derived_from_fixed_Source_map_not_new_plan_field'] = {'arm': 'BASELINE', 'lane': 'BENCHMARK', 'problem': 'PRIMARY_ACCEPTED'}
obj['strict_plan']['actual_dir'] = active + '/actual/' + case
obj['strict_plan']['path_precision'] = 'Exact absent direct active/actual/currentcase_id, parent may exist only because admitted API case already present. Absolute canonical nonsymlink regular singlelink plan under exact active root; all existing parent components nonsymlink. No arbitrary external worker/output path, old alias or any prior API authority accepted.'
del obj['API_lane_recipe_and_census']
obj['BASELINE_benchmark_recipe_and_census'] = {
    'canonical_contexts': 1, 'compile_tableau_calls': 1, 'compile_wang_calls': 1,
    'state_augment_model_calls': 0, 'state_erase_model_calls': 0,
    'engine_instances': 1, 'solve_calls': 1, 'raw_history_examinations': 19683,
    'production_negative_cases': 0, 'independent_oracle_negative_cases': 0,
    'treatment_evidence': None, 'API_controls_evidence': None,
    'stable_audits': 'Complete retained every stable callback snapshot and independent checks against the actual BASELINE model, capped2000; callback count/capture scopes truthful, no clipping or STATE model substitution.',
    'snapshots_rollback_reference': 'Full before/after semantic snapshots, events, complete search result and independent generic result/reference/history checks retained, exact rollback/restoration proof obligation across the complete actual model. Histories/reference expected sets must not feed search policy or promote UNKNOWN. Exact audit arrays/snapshot/evidence associations belong to already adopted worker/oracle and later whole actual review.',
    'node_limit': 10000, 'single_history_domain_cap': 20000, 'stable_audits_cap': 2000,
    'scope': 'One fresh first benchmark process, primary accepted problem BASELINE only. No STATE treatment, API malformed controls, warmup/probe/retry/second Engine or crossarm runtime reuse. Declared API qualification stays separate; no expected BASELINE counters/time/outcome are preapproved.'
}
obj['once_authority_and_freshness'] = 'Current second-case A6 exact Root-state-propagation-once-authority-v1 and fields schema/authorized/uses/case_id/plan/observer remains absent; future exacttrue/int1/currentBASELINEcase/wholecurrentplan/currentobserver rawpins only. Prior API A6/Rootconsume/actualCONSUMED remain immutable permanently spent. Future observer exclusively consumes new Root adjacent A.CONSUMED plus fresh current actual/CONSUMED, fsync/full readback before exactly one owned Popen. No retry/replacement/old A6 reuse. No new Source/plan/A6/consume/actual created by this review.'
obj['terminal_and_scientific_admission'] = 'Require unchanged exact canonical full pretty terminal9/cost6<=16KiB and complete full raw result/log/readback/exit/guard/resource/census joins. Worker result schema exact12, benchmark status COMPLETE_ARM_RESULT, correct case/BASELINE descriptor; treatment and API_controls evidence exactNone. Complete actual BASELINE search/audit/history/snapshot/rollback/reference evidence needs independent whole actual review; observer result remains opaque and normal transport never scientific admission. Full clocks/callbacks retained, no extra exclusions.'
obj['outer_caller_join'] = 'Root same confirmed direct functions.exec_command /bin/zsh login=false workdir=activeStudy; literal two lines set -C then exec exact D90 -I -S -B activeobserver --plan root/' + case + '-plan-v1.json --authority root/' + case + '-once-authority-v1.json >root/' + case + '-outer-stdout-v1.bin 2>root/' + case + '-outer-stderr-v1.bin. Both captures and new A6 absent now. No semicolon/extra Python capture parent/tee/echo/Source call. Full original tool response/sessionID at yield1000, poll only owned handle until authoritative terminal, never restart or read live capture bodies. Full caller raw byte/terminal exit/outer+worker custody joins, combined captures<=1048576. Root alone may grant later.'
obj['cohort_and_named_cap'] = 'Second case only after full admitted API disposition. Fresh serial order API→positiveBASELINE→positiveSTATE→negativeSTATE→negativeBASELINE; later three benchmark plans/A6/actuals remain absent/UNRUN. Five nominal450/600/750s and320MiB result ceiling sums remain products, not whole cohort time/memory/OSquota. Named observed logical cap384MiB includes every actual-directory file plus Root adjacent consumes and full caller captures; current reported11240595 stat-check only. Source/docs/plans/reviews/publication/QA outside tally. API cost never pooled with benchmark. Hard evidence/custody/semantic/prediction failure stops cohort; no auto retry/cap increase. Complete independently verified honest engine UNKNOWN stays UNKNOWN and may advance only after separate whole normal custody/actual disposition; expected witness does not promote it.'
obj['quiescence_and_next_gate'] = 'Root fully reads/adopts this complete second-case prospective review, prior API full disposition and independent whole benchmark actual expectations, rechecks current guards/fresh exact A6/capture/actual paths and complete named tally, confirms all B/C/L/Root other workloads terminal/idle, then Root alone may grant one fresh second-case A6. No global idle attestation or execution permission issued by this review. End reviewer terminal/idle.'
obj['operations_before_freeze'] = {'subject_positive_BASELINE_plan_body_intake': 0, 'prior_API_actual_body_intake': 0, 'Source_or_scientific_execution': 0, 'Source_plan_A6_consume_actual_created': 0, 'network_UI_publication': 0}
new = (json.dumps(obj, sort_keys=True, indent=2, ensure_ascii=False, allow_nan=False) + '\n').encode()
p = OUT / 'state-propagation-positive-base-plan-prefrozen-complete-prospective-expectations-v1.json'
with p.open('xb') as handle:
    handle.write(new); handle.flush(); os.fsync(handle.fileno())
assert p.read_bytes() == new
mirror = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-state-propagation-20261027/custody-L/positive-base-prospective-review-v1')
mirror.mkdir(exist_ok=False)
with (mirror / p.name).open('xb') as handle:
    handle.write(new); handle.flush(); os.fsync(handle.fileno())
assert (mirror / p.name).read_bytes() == new
print(json.dumps({'path': str(p), 'bytes': len(new), 'sha256': hashlib.sha256(new).hexdigest(), 'plan_body_intake_before_freeze': 0}, sort_keys=True))
