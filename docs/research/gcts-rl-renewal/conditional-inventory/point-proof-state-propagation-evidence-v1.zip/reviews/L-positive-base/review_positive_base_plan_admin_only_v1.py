"""Second-case prospective strict metadata and raw Source review, not execution."""
from pathlib import Path
import ast
import datetime
import hashlib
import json
import os
import re
import stat
import sys

OUT = Path('/private/tmp/gcts-L-positive-base-prospective-review-20261027-v1')
ACTIVE = Path('/private/tmp/gcts-state-propagation-20261027-active-v1')
ROOT = ACTIVE / 'root'
MIRROR = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-state-propagation-20261027/custody-L/positive-base-prospective-review-v1')
CASE = 'state-propagation-positive-base-v1-case-0'
PRIOR = 'state-propagation-api-v1-case-0'

def pairs(values):
    result = {}
    for key, value in values:
        assert key not in result, 'duplicate key'
        result[key] = value
    return result

def bad_constant(value):
    raise ValueError('nonfinite administrative constant: ' + value)

def parse(body):
    return json.loads(body.decode('utf-8'), object_pairs_hook=pairs, parse_constant=bad_constant)

def pin(path, body):
    return {'path': str(path), 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}

def ref(path, size, digest):
    return {'path': str(path), 'bytes': size, 'sha256': digest}

def pinned(record):
    assert type(record) is dict and set(record) == {'path', 'bytes', 'sha256'}
    assert type(record['path']) is str and type(record['bytes']) is int and record['bytes'] > 0
    assert type(record['sha256']) is str and re.fullmatch('[0-9a-f]{64}', record['sha256'])
    body = Path(record['path']).read_bytes()
    assert pin(record['path'], body) == record
    return body

def safe(path):
    p = Path(path)
    assert p.is_absolute() and str(p.resolve()) == str(p)
    for item in [p, *p.parents]:
        assert not item.is_symlink()
    info = p.stat()
    assert stat.S_ISREG(info.st_mode) and info.st_nlink == 1
    return {'canonical_regular_singlelink_nonsymlink': True, 'bytes': info.st_size, 'mode': oct(stat.S_IMODE(info.st_mode))}

def literal_values(body, wanted):
    tree = ast.parse(body.decode('utf-8'))
    result = {}
    for node in tree.body:
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id in wanted:
                    result[target.id] = ast.literal_eval(node.value)
    assert set(result) == set(wanted)
    return result, tree

def save(name, value):
    body = (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=False, allow_nan=False) + '\n').encode()
    p = OUT / name
    with p.open('xb') as h:
        h.write(body); h.flush(); os.fsync(h.fileno())
    assert p.read_bytes() == body
    with (MIRROR / name).open('xb') as h:
        h.write(body); h.flush(); os.fsync(h.fileno())
    assert (MIRROR / name).read_bytes() == body
    return pin(p, body)

expect_pin = ref(OUT / 'state-propagation-positive-base-plan-prefrozen-complete-prospective-expectations-v1.json', 12908, '95323e9f8497a08f39bf3a836ef0b0d24da7ab8405ccf92f1e0c6dbe23dac04c')
expect = parse(pinned(expect_pin))
plan_pin = expect['future_subject_plan']
plan_body = pinned(plan_pin)
plan = parse(plan_body)
prior_pin = expect['required_prior_API_complete_whole_actual_disposition']
prior = parse(pinned(prior_pin))
adoption_pin = expect['required_Root_operational_Source_adoption']
adoption = parse(pinned(adoption_pin))
abi_pin = expect['current_public_ABI']
abi = parse(pinned(abi_pin))
binding_pin = expect['current_binding_inverse_static']
binding = parse(pinned(binding_pin))
handoff_pin = expect['current_handoff']
handoff = parse(pinned(handoff_pin))
assert prior['schema'] == 'Root-state-propagation-first-API-complete-whole-actual-adoption-v1'
assert prior['status'] == 'ADMITTED_COMPLETE_API_QUALIFICATION_PASS' and prior['case_id'] == PRIOR
assert prior['Source_A6'] == 'PERMANENTLY_CONSUMED_NO_RETRY'
assert prior['complete30negatives'] is True and prior['next_scientific_execution_authorized'] is False
assert prior['accepted_counts']['engine_instances'] == prior['accepted_counts']['solve_calls'] == prior['accepted_counts']['raw_history_examinations'] == 0
assert prior['B_complete_independent_review_fully_read_by_Root']['bytes'] == 40237
assert prior['Root_full_saved_data_relational_audit']['bytes'] == 4202
assert prior['normal_complete_transport']['bytes'] == 34810
assert 'positiveBASELINE' in prior['next_authorized']
plan_fs = safe(plan_pin['path'])
assert Path(plan_pin['path']).parent == ROOT and len(plan_body) <= 65536
assert type(plan) is dict and set(plan) == set(abi['plan']['exact6']) == {'schema', 'case_id', 'actual_dir', 'python', 'sources', 'limits'}
assert type(plan['schema']) is str and plan['schema'] == abi['plan']['schema'] == 'GCTS-state-propagation-once-plan-v1'
assert type(plan['case_id']) is str and plan['case_id'] == CASE
assert type(plan['actual_dir']) is str and plan['actual_dir'] == str(ACTIVE / 'actual' / CASE)
assert str(Path(plan['actual_dir']).resolve()) == plan['actual_dir']
for p in [Path(plan['actual_dir']), *Path(plan['actual_dir']).parents]:
    assert not p.is_symlink()
assert not Path(plan['actual_dir']).exists()
assert type(plan['limits']) is dict and set(plan['limits']) == set(expect['limits_exact7'])
assert all(type(v) is int for v in plan['limits'].values())
assert plan['limits'] == expect['limits_exact7'] == abi['plan']['limits_exact7']
assert plan['python'] == abi['plan']['python'] == adoption['D90_current_rawpin']
assert Path(plan['python']['path']) == Path(sys.executable)
assert sys.version_info[:3] == (3, 12, 14) and sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
pinned(plan['python'])
runtime_fs = safe(plan['python']['path'])
assert type(plan['sources']) is dict and set(plan['sources']) == {'observer', 'worker', 'engine', 'compiler', 'oracle'}
assert plan['sources'] == adoption['all_five_Source_current_pins'] == handoff['five_current_Source_rawpins']
assert plan['sources'] == {r: v['current'] for r, v in binding['current_Source_roles'].items()}
source_bodies, source_fs = {}, {}
for role, record in sorted(plan['sources'].items()):
    assert record['path'] == abi['five_exact_active_roles'][role] and Path(record['path']).is_relative_to(ACTIVE)
    assert record['bytes'] <= 2097152
    source_fs[role] = safe(record['path'])
    source_bodies[role] = pinned(record)
assert sum(v['bytes'] for v in plan['sources'].values()) == adoption['Source_footprint_bytes'] == 175208
assert abi['engine_exact'] == plan['sources']['engine'] and abi['observer_Source_path'] == plan['sources']['observer']['path']
assert adoption['complete_public_ABI_fully_read'] == abi_pin and adoption['L_complete_binding_handoff_fully_read'] == handoff_pin
assert adoption['Source_handoff'] == handoff['Root_Source_handoff'] and adoption['whole_original_Source_adoption'] == handoff['Root_prior_whole_Source_adoption']
assert adoption['Source_full_raw_positioned_AST_inverses'] and adoption['entire14529_ABI_raw_inverse'] and adoption['only_fixed_literals_worker2_observer1']
assert len(adoption['focused_peers_all_fully_read']) == 2 and binding['review_passed'] and not binding['blockers']
worker, tree = literal_values(source_bodies['worker'], {'CASE_MAP', 'LIMITS', 'PYTHON', 'VERSION', 'PLAN_SCHEMA', 'RESULT_SCHEMA', 'TERMINAL_SCHEMA', 'RESULT_KEYS', 'TERMINAL_KEYS', 'CAPTURE_SITE', 'ELAPSED_ORIGIN', 'RSS_SCOPE', 'TERMINAL_TAIL', 'PHASES'})
observer, _ = literal_values(source_bodies['observer'], {'CASE_MAP', 'LIMITS', 'PYTHON', 'CHUNK', 'METADATA_CAP', 'TERMINAL_CAP', 'CLOCK_ORIGINS'})
cases = {v['case_id']: v['descriptor'] for v in abi['plan']['case_map_and_order']}
assert worker['CASE_MAP'] == observer['CASE_MAP'] == cases and list(worker['CASE_MAP']) == list(observer['CASE_MAP']) == list(cases)
descriptor = cases[CASE]
assert descriptor == {'arm': 'BASELINE', 'lane': 'BENCHMARK', 'problem': 'PRIMARY_ACCEPTED'}
assert worker['LIMITS'] == observer['LIMITS'] == plan['limits'] and worker['PYTHON'] == observer['PYTHON'] == plan['python']
assert worker['PLAN_SCHEMA'] == plan['schema'] and worker['RESULT_SCHEMA'] == abi['worker_result']['schema']
assert worker['RESULT_KEYS'] == abi['worker_result']['exact12'] and worker['TERMINAL_KEYS'] == abi['worker_terminal']['exact9']
assert worker['TERMINAL_SCHEMA'] == abi['worker_terminal']['schema'] and worker['VERSION'] == abi['worker_terminal']['version']
for name, key in [('CAPTURE_SITE', 'capture_site'), ('ELAPSED_ORIGIN', 'elapsed_origin'), ('RSS_SCOPE', 'rss_scope'), ('TERMINAL_TAIL', 'tail')]:
    assert worker[name] == abi['worker_terminal'][key]
assert observer['CHUNK'] == abi['caps']['CHUNK'] and observer['METADATA_CAP'] == abi['caps']['METADATA_CAP'] and observer['TERMINAL_CAP'] == abi['caps']['TERMINAL_CAP']
bench = next(n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef) and n.name == 'benchmark')
bench_text = ast.get_source_segment(source_bodies['worker'].decode(), bench)
assert 'model, extension, erased, erasure = baseline, None, None, None' in bench_text
assert 'if descriptor["arm"] == "CERTIFIED_STATE":' in bench_text
assert 'histories["complete"] is True and histories["examined"] == 19683' in bench_text
assert 'engine = self.engine.Engine(model, audit=audit, budget=engine_budget)' in bench_text
assert 'result = engine.solve(node_limit=10000)' in bench_text
assert 'self.audit_count <= 2000' in bench_text
assert 'engine.rollback(checkpoint)' in bench_text and 'self.oracle._same(restored, entry, "entire explicit entry restoration")' in bench_text
assert 'return "COMPLETE_ARM_RESULT", counts, evidence' in bench_text
authority = ROOT / (CASE + '-once-authority-v1.json')
stdout = ROOT / (CASE + '-outer-stdout-v1.bin')
stderr = ROOT / (CASE + '-outer-stderr-v1.bin')
consume = Path(str(authority) + '.CONSUMED.json')
absent = [authority, stdout, stderr, consume, Path(plan['actual_dir'])]
for p in absent:
    assert not p.exists() and not p.is_symlink()
actual_parent = ACTIVE / 'actual'
assert actual_parent.is_dir() and not actual_parent.is_symlink()
assert sorted(p.name for p in actual_parent.iterdir()) == [PRIOR]
root_names = sorted(p.name for p in ROOT.iterdir())
assert sorted(n for n in root_names if n.endswith('-plan-v1.json')) == sorted([PRIOR + '-plan-v1.json', CASE + '-plan-v1.json'])
later = list(cases)[2:]
for later_case in later:
    for p in [ROOT / (later_case + '-plan-v1.json'), ROOT / (later_case + '-once-authority-v1.json'), actual_parent / later_case]:
        assert not p.exists() and not p.is_symlink()
named_files = []
for case_dir in sorted(actual_parent.iterdir()):
    assert case_dir.name == PRIOR and not case_dir.is_symlink()
    for path in sorted(case_dir.iterdir()):
        info = safe(path)
        named_files.append({'path': str(path), 'bytes': info['bytes'], 'scope': 'actual_directory_body_STAT_ONLY_NO_BODY_READ'})
prior_census = {'CONSUMED.json', 'observer-receipt.json', 'observer-terminal.json', 'stderr.bin', 'stdout.bin', 'worker-result.json'}
assert {Path(r['path']).name for r in named_files} == prior_census
for path in sorted(ROOT.iterdir()):
    if path.name.endswith('.CONSUMED.json') or (path.name.endswith('.bin') and '-outer-' in path.name):
        assert path.name.startswith(PRIOR + '-')
        info = safe(path)
        named_files.append({'path': str(path), 'bytes': info['bytes'], 'scope': 'Root_adjacent_consume_or_caller_body_STAT_ONLY_NO_BODY_READ'})
assert len(named_files) == 9
named_total = sum(r['bytes'] for r in named_files)
assert named_total == prior['named_attempt_artifact_bytes'] == 11240595
cap = expect['all_caps']['named_five_attempt_artifact_bytes']
assert cap == 402653184 and named_total < cap and cap - named_total == prior['remaining_named_attempt_cap_bytes']
argv = [plan['python']['path'], '-I', '-S', '-B', plan['sources']['observer']['path'], '--plan', plan_pin['path'], '--authority', str(authority)]
caller = 'set -C\nexec ' + ' '.join(argv) + ' > ' + str(stdout) + ' 2> ' + str(stderr)
assert ';' not in caller
for role, body in source_bodies.items():
    assert Path(plan['sources'][role]['path']).read_bytes() == body
assert Path(plan_pin['path']).read_bytes() == plan_body
pinned(plan['python'])
cost_scope = expect['resource_and_clock_scopes']
recipe = expect['BASELINE_benchmark_recipe_and_census']
branch_details = {
    'Source_only_not_observed': True, 'worker_Source': plan['sources']['worker'], 'benchmark_lines': [bench.lineno, bench.end_lineno],
    'BASELINE_nulls': ['evidence.extension_check', 'evidence.erased_model', 'evidence.erasure_check', 'costs.phases.treatment_construction_check', 'costs.phases.API_controls'],
    'BASELINE_empty_augmented_expected_checks': True,
    'one_fresh_engine_and_solve': 'One Engine(model=actual BASELINE,audit=complete callback,budget=bridge), one solve(node_limit10000). No STATE augment/erase or malformed controls in this lane.',
    'complete_history_and_audits': 'tableau_histories cap20000; complete==True/examined19683 and exact same-spec partition. Every stable callback retained with complete event/snapshot/metrics/independent snapshot/dependency/metric/search-exclusion checks, cap2000 raises before clipping. Full static dependencies retained and immutable-association checked.',
    'entry_result_rollback_reference': 'Full entry/checkpoint/final/result checked against actual BASELINE and whole reference expected sets. Accepted solution alone invokes independent point-result check and original production inverse with full input-detachment associations, then explicit rollback(checkpoint). Non-SAT/UNKNOWN must already restore final==entry. Every path checks full restored==entry and independent restored snapshot. Reference histories never feed Engine policy.',
    'conditional_decode': 'decode_tableau is exactly the adopted accepted-solution branch; do not assert one decode before outcome or require an expected witness to promote UNKNOWN.',
    'forecast': 'Positive STATE forecast remains NOT_APPLICABLE for BASELINE; no BASELINE counter/time/prediction result is preapproved.'
}
audit = {
    'schema': 'L-state-propagation-positive-base-plan-complete-prospective-raw-binding-audit-v1', 'status': 'COMPLETE_PROSPECTIVE_BINDING_PASS', 'review_passed': True, 'blockers': [],
    'prefrozen_expectations': expect_pin, 'entire_plan': plan_pin, 'complete_parsed_plan': plan,
    'prior_API_Root_whole_disposition': prior_pin, 'prior_disposition_verified': {'status': prior['status'], 'prior_A6': prior['Source_A6'], 'next_permission': prior['next_authorized'], 'next_execution_authorized': prior['next_scientific_execution_authorized'], 'B_complete_review_ref_METADATA_ONLY': prior['B_complete_independent_review_fully_read_by_Root'], 'Root_relational_audit_ref_METADATA_ONLY': prior['Root_full_saved_data_relational_audit'], 'transport_ref_METADATA_ONLY': prior['normal_complete_transport'], 'no_referenced_actual_bodies_followed': True},
    'current_operational_Source_adoption': adoption_pin, 'current_public_ABI': abi_pin, 'current_Source_binding_inverse': binding_pin, 'current_handoff': handoff_pin,
    'plan_six_fields_strict_types_full_JSON_verified': True, 'plan_path_metadata': plan_fs, 'all_five_complete_Source_rawpins': plan['sources'], 'Source_paths': source_fs, 'Source_total_bytes': 175208,
    'full_D90_rawpin': plan['python'], 'runtime_path_metadata': runtime_fs, 'current_admin_interpreter': {'version': sys.version, 'isolated': sys.flags.isolated, 'no_site': sys.flags.no_site, 'no_bytecode': sys.dont_write_bytecode},
    'full_Source_runtime_plan_pre_post_unchanged': True, 'exact_descriptor': descriptor, 'all_case_map_order_unchanged': list(cases),
    'declared_BASELINE_recipe_NOT_runtime_evidence': recipe, 'static_benchmark_join': branch_details,
    'limits_exact7': plan['limits'], 'all_caps': expect['all_caps'], 'result_schema12': {'schema': worker['RESULT_SCHEMA'], 'keys': worker['RESULT_KEYS']},
    'terminal_schema9_cost6': {'schema': worker['TERMINAL_SCHEMA'], 'keys': worker['TERMINAL_KEYS'], 'cost_keys': abi['worker_terminal']['cost_exact6'], 'worker_version': worker['VERSION'], 'capture_site': worker['CAPTURE_SITE'], 'elapsed_origin': worker['ELAPSED_ORIGIN'], 'rss_scope': worker['RSS_SCOPE'], 'tail': worker['TERMINAL_TAIL']},
    'observer_clock_scope': observer['CLOCK_ORIGINS'], 'resource_scope': cost_scope,
    'named_attempt_stat_only_census': named_files, 'named_total_bytes': named_total, 'named_cap_bytes': cap, 'remaining_named_bytes': cap - named_total,
    'storage_scope': 'Complete9 existing named file stat sizes only. Actual scientific/result/log/receipt/consume/caller bodies neither read nor hashed nor parsed. No hard filesystem quota or predicted future total claim. Source/docs/plans/reviews/QA/publication outside named384MiB tally. Recheck all named bodies before each future grant.',
    'current_fresh_paths_absent': [str(p) for p in absent], 'later_three_cases_absent_unplanned': later,
    'future_Root_caller': {'shell': '/bin/zsh', 'login': False, 'workdir': str(ACTIVE), 'literal_command_METADATA_ONLY_NEVER_EXECUTED_HERE': caller, 'caller_combined_capture_cap_bytes': 1048576, 'yield_time_ms': 1000, 'capture_parent': 'exec replaces shell; no Python parent, tee, echo, helper or additional Source call.', 'terminal_scope': 'Full original tool response/sessionID retained, poll only owned live handle, no restart/live-body intake; authoritative terminal/exit plus complete caller/stdout/stderr/outer/custody/result/guards/resource joins required.'},
    'guard_custody_scopes': expect['whole_custody_and_evidence'], 'historical_body_boundary': expect['provenance_and_gaps'],
    'review_reliance': 'Current full Root operational Source adoption and exact peer associations, existing L whole ABI/inverse/manual Source proof, plus this complete strict plan/current raw pins/public literal and benchmark branch join. No broad algorithm reimplementation or fresh scientific tests. Prior API accepted via exact full Root disposition, not independently revalidated here.',
    'operations': {'project_import_function_model_fixture_test_CLI_help_or_codeobject_execution': 0, 'actual_result_or_other_actual_body_read_hash_parse': 0, 'Source_plan_A6_consume_actual_creation_or_edit': 0, 'old_placeholder_retry': 0, 'network_UI_publication': 0, 'prior_actual_accounting': 'STAT_ONLY'},
    'scientific_execution_authorized': False, 'publication_authorized': False
}
audit_pin = save('state-propagation-positive-base-plan-complete-prospective-raw-binding-audit-v1.json', audit)
review = {
    'schema': 'L-state-propagation-positive-base-plan-complete-independent-prospective-review-v1', 'status': 'COMPLETE_PROSPECTIVE_PLAN_PASS_EXECUTION_NOT_AUTHORIZED', 'review_passed': True, 'blockers': [],
    'issued_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'subject': plan_pin, 'prefrozen_expectations': expect_pin, 'complete_supporting_audit': audit_pin,
    'prior_complete_API_adoption': prior_pin, 'current_Source_operational_adoption': adoption_pin, 'current_public_ABI': abi_pin, 'current_Source_binding_inverse': binding_pin,
    'all_six_plan_fields': {'schema': 'Exact v1 whole duplicate/nonfinite-rejecting strict JSON, no extra keys.', 'case_id': CASE + '; derived descriptor BENCHMARK/BASELINE/PRIMARY_ACCEPTED matches both Source maps and second serial order.', 'actual_dir': 'Exact current direct active/actual/case_id absent; admitted API sibling alone exists, all components nonsymlink.', 'python': 'Full exact current D90 executable rawpin, canonical regular singlelink path, CPython3.12.14 isolated/no_site/no-bytecode verified.', 'sources': 'Exactly175208 complete bytes across5 current active roles; all full rawpins match Root operational adoption/complete ABI binding and are unchanged after review.', 'limits': 'All7 exact integers and full Source/plan/A6/result/log/terminal/metadata/chunk/caller/named-cohort caps coherent; no extra field or bool/float substitution.'},
    'five_current_Source_rawpins': plan['sources'], 'limits': plan['limits'], 'caps': expect['all_caps'],
    'prior_API_gate': 'Full7445 Root adopted API disposition read/pinned: complete qualification admitted, Source_A6 permanently consumed/no retry, full B40237+Root4202+normaltransport34810 associations and next positiveBASELINE plan-only permission explicit. No prior actual evidence bodies read/followed. Current review does not independently recreate its scientific validation or pool its costs.',
    'BASELINE_recipe': recipe, 'complete_static_benchmark_branch_join': branch_details,
    'expected_result_and_scientific_review': 'Worker emits COMPLETE_ARM_RESULT envelope12, correct current descriptor and complete untouched evidence. Actual engine status may be FINITE_EXACT_SOLUTION or honest independently verified UNKNOWN; an unexpected semantic contradiction/exhaustion against accepted context is not silently promoted. No runtime status/count/time forecast is a grant condition or substituted witness. Full actual/audit/snapshot/history/reference/rollback/inverse and cost receipts require separate B/Root complete review after authoritative normal custody.',
    'normal_custody_and_terminal': 'Exactly one consumed-before-launch owned child; complete8 source/runtime/plan/A6 guard closure, inherited group/drain/wait/reap/no-prior-child/census/watchdog/error algorithms unchanged. Full original bounded logs, positive full opaque result readback and canonical complete terminal9/cost6 must join actual rc0/reaped/groupgone/drainscomplete/noissues and all guards/resources before normal transport. Observer never parses scientific result and never independently admits it. Result/receipt/prefix alone has no authority.',
    'resource_clock_scope': cost_scope,
    'named_storage_accounting': {'method': 'STAT_ONLY complete9 existing named files; no actual body intake', 'current_bytes': named_total, 'cap_bytes': cap, 'remaining_bytes': cap - named_total, 'full_census_in_audit': True, 'current_new_A6_consume_actual_captures_absent': True, 'future_scope': 'Root recomputes complete all attempt-directory body sizes plus adjacent consumed markers plus full caller captures before every later individual grant; docs/Source/reviews/QA/publication outside tally. Observational logical sum, no OSquota claim.'},
    'future_exact_caller': audit['future_Root_caller'],
    'remaining_separate_execution_gates': ['Root fully reads/adopts entire prospective review+support audit and confirms independent benchmark whole-actual expectations ready.', 'Root immediately rechecks unchanged full current Source/runtime/plan pins, exact absent new authority/adjacent consume/current actual/captures, prior authority permanently spent, complete named cap and caller capture ceilings.', 'All B/C/L tools/processes and unrelated Root metadata/render/network activity terminal/idle; this handoff attests only this reviewer tools idle, not global quiescence.', 'Root alone may then create/grant one strict fresh second-case A6 with exacttrue/int1/currentcase/wholeplan/currentobserver. This record grants no Source invocation or A6 creation.', 'After authorized once, authoritative exec/session terminal/full raw captures and whole transport/terminal/resource/guard/log/result joins plus independent complete actual review. No replay/probe/retry/cap increase/postfaultgetter/prefix salvage.'],
    'UNKNOWN_and_hard_failure': 'Honest complete independently verified UNKNOWN stays UNKNOWN, never promoted by expected positive trace; advancement requires complete valid normal custody/whole disposition. Hard guard/resource/custody/evidence/semantic or prediction inconsistency stops cohort, not a relabeled normal UNKNOWN. No auto retry or arm replacement.',
    'later_cases_and_aggregate': 'PositiveSTATE/negativeSTATE/negativeBASELINE remain UNRUN/unplanned with no A6/actual. Each later case needs complete prior disposition, own prospective review/fresh once and quiescence. Five nominal450/600/750s and320MiB result-ceiling products are sums, not whole cohort time/memory/OS storage guarantee. API costs separate; no speed/learning/RL/FOL/theorem/universal/infinite/novelty or full geometric conformance claim.',
    'historical_Source_metadata_boundary': expect['provenance_and_gaps'], 'scope_and_reliance': audit['review_reliance'], 'operations': audit['operations'],
    'scientific_execution_authorized': False, 'A6_creation_authorized': False, 'publication_authorized': False,
    'current_BASELINE_scientific_invocations': 0, 'final_state': 'COMPLETE_TMP_FIRST_NEW_REPO_MIRROR; REVIEWER_TOOLS_TERMINAL_IDLE_AFTER_HANDOFF; NO SCIENTIFIC_PROCESS_STARTED.'
}
review_pin = save('state-propagation-positive-base-plan-complete-independent-prospective-review-v1.json', review)
print(json.dumps({'review': review_pin, 'audit': audit_pin, 'expectations': expect_pin, 'named_bytes_stat_only': named_total, 'status': 'PASS_TERMINAL_IDLE_NO_EXECUTION_AUTHORITY'}, sort_keys=True))
