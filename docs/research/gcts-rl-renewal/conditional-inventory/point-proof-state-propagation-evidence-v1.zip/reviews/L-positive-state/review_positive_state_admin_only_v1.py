"""Fresh focused public-plan/Source-guard review; no project execution."""
from pathlib import Path
import ast
import datetime
import hashlib
import json
import os
import re
import stat
import sys

OUT = Path('/private/tmp/gcts-L-positive-state-prospective-review-20261027-v1')
ACTIVE = Path('/private/tmp/gcts-state-propagation-20261027-active-v1')
ROOT = ACTIVE / 'root'
CASE = 'state-propagation-positive-state-v1-case-0'
PRIOR_CASES = ['state-propagation-api-v1-case-0', 'state-propagation-positive-base-v1-case-0']
MIRROR = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-state-propagation-20261027/custody-L/positive-state-prospective-review-v1')

def rawpin(path, body):
    return {'path': str(path), 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}

def ref(path, size, digest):
    return {'path': str(path), 'bytes': size, 'sha256': digest}

def read_pinned(record):
    assert type(record) is dict and set(record) == {'path', 'bytes', 'sha256'}
    assert type(record['path']) is str and type(record['bytes']) is int and record['bytes'] > 0
    assert type(record['sha256']) is str and re.fullmatch('[0-9a-f]{64}', record['sha256'])
    body = Path(record['path']).read_bytes()
    assert rawpin(record['path'], body) == record
    return body

def no_duplicates(pairs):
    result = {}
    for key, value in pairs:
        assert key not in result
        result[key] = value
    return result

def reject_constant(value):
    raise ValueError(value)

def parse(body):
    return json.loads(body.decode('utf-8'), object_pairs_hook=no_duplicates, parse_constant=reject_constant)

def safe(path):
    p = Path(path)
    assert p.is_absolute() and str(p.resolve()) == str(p)
    for q in [p, *p.parents]:
        assert not q.is_symlink()
    info = p.stat()
    assert stat.S_ISREG(info.st_mode) and info.st_nlink == 1
    return {'bytes': info.st_size, 'canonical_regular_singlelink_nonsymlink': True}

def literal_subset(body, names):
    tree = ast.parse(body.decode('utf-8'))
    result = {}
    for node in tree.body:
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id in names:
                    result[target.id] = ast.literal_eval(node.value)
    assert set(result) == set(names)
    return result, tree

def save(name, obj):
    body = (json.dumps(obj, sort_keys=True, indent=2, ensure_ascii=False, allow_nan=False) + '\n').encode()
    p = OUT / name
    with p.open('xb') as h:
        h.write(body); h.flush(); os.fsync(h.fileno())
    assert p.read_bytes() == body
    with (MIRROR / name).open('xb') as h:
        h.write(body); h.flush(); os.fsync(h.fileno())
    assert (MIRROR / name).read_bytes() == body
    return rawpin(p, body)

expect_pin = ref(OUT / 'state-propagation-positive-state-prefrozen-prospective-expectations-v1.json', 7291, '3d572993d89af1e86104b35eabf8b88cf5349bf0ee717af71df50b31b5d33ea5')
expect = parse(read_pinned(expect_pin))
plan_pin = expect['subject']
plan_body = read_pinned(plan_pin)
plan = parse(plan_body)
prior_pin = expect['prior_positive_BASELINE_adoption_opaque_pin_only']
prior_opaque = read_pinned(prior_pin)
del prior_opaque
abi_pin = ref('/private/tmp/gcts-L-active-ABI-join-20261027-v1/state-propagation-once-plan-worker-terminal-ABI-v2.json', 14165, '557d4d28f2229e45c1fcf901379c97726b7da4fa1c2189d83b6e0340e28e03c1')
binding_pin = ref('/private/tmp/gcts-L-active-ABI-join-20261027-v1/state-propagation-active-runtime-ABI-complete-binding-inverse-static-join-v1.json', 21033, '7dbd85bad238677545136fc8a1668cba9408f24f797c327714aa08da48097431')
adoption_pin = ref(ROOT / 'state-propagation-active-five-role-Root-operational-Source-adoption-v1.json', 4925, '885d51ef0137dc50f7c8d66f6e2f1d0863be16e68424cd89f1511f1ba3bfce7b')
abi = parse(read_pinned(abi_pin))
binding = parse(read_pinned(binding_pin))
adoption = parse(read_pinned(adoption_pin))
assert type(plan) is dict and set(plan) == set(abi['plan']['exact6']) == {'schema', 'case_id', 'actual_dir', 'python', 'sources', 'limits'}
assert type(plan['schema']) is str and plan['schema'] == abi['plan']['schema']
assert type(plan['case_id']) is str and plan['case_id'] == CASE
assert type(plan['actual_dir']) is str and plan['actual_dir'] == str(ACTIVE / 'actual' / CASE)
assert type(plan['limits']) is dict and set(plan['limits']) == set(expect['limits_exact7']) and all(type(v) is int for v in plan['limits'].values())
assert plan['limits'] == expect['limits_exact7'] == abi['plan']['limits_exact7']
assert plan['python'] == abi['plan']['python'] == adoption['D90_current_rawpin']
assert Path(plan['python']['path']) == Path(sys.executable)
assert sys.version_info[:3] == (3, 12, 14) and sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
read_pinned(plan['python'])
runtime_safe = safe(plan['python']['path'])
assert type(plan['sources']) is dict and set(plan['sources']) == {'observer', 'worker', 'engine', 'compiler', 'oracle'}
assert plan['sources'] == adoption['all_five_Source_current_pins'] == {r: v['current'] for r, v in binding['current_Source_roles'].items()}
source_bodies, source_safe = {}, {}
for role, record in sorted(plan['sources'].items()):
    assert record['path'] == abi['five_exact_active_roles'][role] and record['bytes'] <= 2097152
    assert Path(record['path']).is_relative_to(ACTIVE)
    source_safe[role] = safe(record['path'])
    source_bodies[role] = read_pinned(record)
assert sum(r['bytes'] for r in plan['sources'].values()) == 175208
assert abi['observer_Source_path'] == plan['sources']['observer']['path'] and abi['engine_exact'] == plan['sources']['engine']
assert adoption['complete_public_ABI_fully_read'] == abi_pin and binding['review_passed'] and not binding['blockers']
plan_safe = safe(plan_pin['path'])
assert Path(plan_pin['path']).parent == ROOT and len(plan_body) <= 65536
worker, tree = literal_subset(source_bodies['worker'], {'CASE_MAP', 'LIMITS', 'PYTHON', 'STATE_PREDICTION', 'VERSION', 'PLAN_SCHEMA', 'RESULT_SCHEMA', 'TERMINAL_SCHEMA', 'RESULT_KEYS', 'TERMINAL_KEYS', 'CAPTURE_SITE', 'ELAPSED_ORIGIN', 'RSS_SCOPE', 'TERMINAL_TAIL'})
observer, _ = literal_subset(source_bodies['observer'], {'CASE_MAP', 'LIMITS', 'PYTHON', 'CHUNK', 'METADATA_CAP', 'TERMINAL_CAP', 'CLOCK_ORIGINS'})
case_map = {v['case_id']: v['descriptor'] for v in abi['plan']['case_map_and_order']}
assert worker['CASE_MAP'] == observer['CASE_MAP'] == case_map
assert list(worker['CASE_MAP']) == list(observer['CASE_MAP']) == list(case_map)
assert case_map[CASE] == expect['strict_plan']['descriptor'] == {'arm': 'CERTIFIED_STATE', 'lane': 'BENCHMARK', 'problem': 'PRIMARY_ACCEPTED'}
assert worker['STATE_PREDICTION'] == expect['forecast']
assert worker['LIMITS'] == observer['LIMITS'] == plan['limits'] and worker['PYTHON'] == observer['PYTHON'] == plan['python']
assert worker['PLAN_SCHEMA'] == plan['schema'] and worker['RESULT_SCHEMA'] == abi['worker_result']['schema']
assert worker['RESULT_KEYS'] == abi['worker_result']['exact12'] and worker['TERMINAL_KEYS'] == abi['worker_terminal']['exact9']
assert worker['TERMINAL_SCHEMA'] == abi['worker_terminal']['schema'] and worker['VERSION'] == abi['worker_terminal']['version']
for name, key in [('CAPTURE_SITE', 'capture_site'), ('ELAPSED_ORIGIN', 'elapsed_origin'), ('RSS_SCOPE', 'rss_scope'), ('TERMINAL_TAIL', 'tail')]:
    assert worker[name] == abi['worker_terminal'][key]
assert observer['CHUNK'] == abi['caps']['CHUNK'] and observer['METADATA_CAP'] == abi['caps']['METADATA_CAP'] and observer['TERMINAL_CAP'] == abi['caps']['TERMINAL_CAP']
benchmark = next(n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef) and n.name == 'benchmark')
text = ast.get_source_segment(source_bodies['worker'].decode('utf-8'), benchmark)
needles = ['model = self.call("state_augment_model", bundle, baseline)', 'self.oracle_call("state_verify_extension", spec, bundle, baseline, model)', 'erased = self.call("state_erase_model", bundle, model)', 'self.oracle_call("state_verify_erasure", spec, bundle, model, erased)', 'histories["complete"] is True and histories["examined"] == 19683', 'self.audit_count <= 2000', 'engine = self.engine.Engine(model, audit=audit, budget=engine_budget)', 'result = engine.solve(node_limit=10000)', 'self.oracle._same(restored, entry, "entire explicit entry restoration")', 'evaluation="MATCHED" if self.oracle.tableau_equal(observed, STATE_PREDICTION) else "MISMATCH"', 'prediction["evaluation"] = "NOT_EVALUATED_UNKNOWN"', 'return "COMPLETE_ARM_RESULT", counts, evidence']
assert all(v in text for v in needles)
new_authority = ROOT / (CASE + '-once-authority-v1.json')
new_stdout = ROOT / (CASE + '-outer-stdout-v1.bin')
new_stderr = ROOT / (CASE + '-outer-stderr-v1.bin')
new_consume = Path(str(new_authority) + '.CONSUMED.json')
fresh_absent = [new_authority, new_stdout, new_stderr, new_consume, Path(plan['actual_dir'])]
for p in fresh_absent:
    assert str(p.resolve()) == str(p)
    assert not p.exists() and not p.is_symlink()
    for q in p.parents:
        assert not q.is_symlink()
actual_root = ACTIVE / 'actual'
assert actual_root.is_dir() and not actual_root.is_symlink()
assert sorted(p.name for p in actual_root.iterdir()) == sorted(PRIOR_CASES)
census = []
allowed_actual_names = {'CONSUMED.json', 'observer-receipt.json', 'observer-terminal.json', 'stderr.bin', 'stdout.bin', 'worker-result.json'}
for folder in sorted(actual_root.iterdir()):
    assert not folder.is_symlink() and {p.name for p in folder.iterdir()} == allowed_actual_names
    for p in sorted(folder.iterdir()):
        census.append({'path': str(p), 'bytes': safe(p)['bytes'], 'scope': 'actual_extent_STAT_ONLY'})
for p in sorted(ROOT.iterdir()):
    if p.name.endswith('.CONSUMED.json') or (p.name.endswith('.bin') and '-outer-' in p.name):
        assert any(p.name.startswith(c + '-') for c in PRIOR_CASES)
        census.append({'path': str(p), 'bytes': safe(p)['bytes'], 'scope': 'Root_consume_or_fullcaller_extent_STAT_ONLY'})
assert len(census) == 18
named = sum(x['bytes'] for x in census)
assert named == 22198193 and named < 402653184
remaining = 402653184 - named
root_names = sorted(p.name for p in ROOT.iterdir())
assert sorted(n for n in root_names if n.endswith('-plan-v1.json')) == sorted(c + '-plan-v1.json' for c in PRIOR_CASES + [CASE])
argv = [plan['python']['path'], '-I', '-S', '-B', plan['sources']['observer']['path'], '--plan', plan_pin['path'], '--authority', str(new_authority)]
caller = 'set -C\nexec ' + ' '.join(argv) + ' > ' + str(new_stdout) + ' 2> ' + str(new_stderr)
assert ';' not in caller
for role, body in source_bodies.items():
    assert Path(plan['sources'][role]['path']).read_bytes() == body
assert Path(plan_pin['path']).read_bytes() == plan_body
read_pinned(plan['python'])
audit = {
    'schema': 'L-state-propagation-positive-state-complete-prospective-support-v1', 'review_passed': True, 'blockers': [],
    'prefrozen_expectations': expect_pin, 'subject': plan_pin, 'complete_parsed_strict_plan': plan,
    'prior_adoption_opaque_pin_verified_NOT_parsed': prior_pin,
    'prior_admitted_disposition_basis': 'Direct Root assignment: positive BASELINE admitted. No prior adoption costs/witness values parsed, no prior actual body read/hash/parse; no recreation of scientific validation.',
    'current_Root_operational_Source_adoption': adoption_pin, 'current_public_ABI': abi_pin, 'current_whole_Source_binding': binding_pin,
    'plan_path_metadata': plan_safe, 'five_current_raw_Source_guards': plan['sources'], 'Source_path_metadata': source_safe, 'Source_total_bytes': 175208,
    'runtime_raw_guard': plan['python'], 'runtime_path_metadata': runtime_safe,
    'admin_runtime': {'version': sys.version, 'isolated': sys.flags.isolated, 'no_site': sys.flags.no_site, 'dont_write_bytecode': sys.dont_write_bytecode},
    'all_current_Source_plan_runtime_full_pre_post_pins_unchanged': True,
    'exact_case_descriptor': case_map[CASE], 'seven_exact_typed_limits': plan['limits'], 'all_caps': expect['other_caps'],
    'adopted_worker_static_binding': {'Source': plan['sources']['worker'], 'benchmark_function_lines': [benchmark.lineno, benchmark.end_lineno], 'required_public_branch_clauses_joined': needles, 'prediction_exact_Source_literal_not_observation': worker['STATE_PREDICTION']},
    'terminal_public_binding': {'result_schema': worker['RESULT_SCHEMA'], 'result_keys': worker['RESULT_KEYS'], 'terminal_schema': worker['TERMINAL_SCHEMA'], 'terminal_keys': worker['TERMINAL_KEYS'], 'cost_keys': abi['worker_terminal']['cost_exact6'], 'worker_version': worker['VERSION'], 'capture_site': worker['CAPTURE_SITE'], 'elapsed_origin': worker['ELAPSED_ORIGIN'], 'rss_scope': worker['RSS_SCOPE'], 'tail': worker['TERMINAL_TAIL']},
    'observer_clock_origin_metadata': observer['CLOCK_ORIGINS'],
    'full_stat_only_named_census': census, 'named_bytes': named, 'named_cap_bytes': 402653184, 'remaining_named_bytes': remaining,
    'fresh_paths_absent': [str(p) for p in fresh_absent], 'all_created_plans_metadata_names': [n for n in root_names if n.endswith('-plan-v1.json')],
    'future_exact_caller_NEVER_EXECUTED_HERE': {'shell': '/bin/zsh', 'login': False, 'workdir': str(ACTIVE), 'two_line_command': caller, 'caller_combined_bytes_cap': 1048576, 'yield_time_ms': 1000, 'no_extra_capture_parent': True, 'requirements': 'Fresh noclobber raw captures; complete original tool response/sessionID and authoritative terminal exit; poll only owned handle, no restart/liveprefix. Full process/outer/worker/custody/log/result/guard/resource joins plus separate scientific review.'},
    'review_scope': 'Focused complete current plan/raw Source+runtime/public ABI/STATE branch and forecast/freshness/storage review, reusing already adopted complete substantive Source reviews. Prior actuals were statted only; prior BASELINE adoption was rawpin opaque only, not parsed/printed.',
    'operations': {'project_import_function_model_fixture_test_CLI_help_codeobject_execution': 0, 'actual_or_cost_or_witness_body_intake': 0, 'Source_plan_A6_consume_actual_creation_or_edit': 0, 'old_placeholder_retry': 0, 'network_UI_publication': 0},
    'scientific_execution_authorized': False, 'A6_creation_authorized': False
}
audit_pin = save('state-propagation-positive-state-complete-prospective-support-v1.json', audit)
review = {
    'schema': 'L-state-propagation-positive-state-complete-independent-prospective-review-v1',
    'status': 'FOCUSED_COMPLETE_PROSPECTIVE_PASS_EXECUTION_NOT_AUTHORIZED', 'review_passed': True, 'blockers': [],
    'issued_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'subject': plan_pin, 'prefrozen_expectations': expect_pin, 'complete_support': audit_pin,
    'prior_BASELINE_adoption_opaque_pin_only': prior_pin, 'current_Source_operational_adoption': adoption_pin, 'current_public_ABI': abi_pin, 'current_whole_Source_binding': binding_pin,
    'all_new_plan_specific_conditions': {'strict_plan6': 'Entire1969bytes exactpin and strict JSON duplicate/nonfinite/type/keyset checks passed; no extra descriptor/control field.', 'case_descriptor': case_map[CASE], 'fresh_actual_path': plan['actual_dir'], 'Source_guards': 'All5 exact active Sources/full175208bytes and D90 full executable pins freshly verified before/after; canonical regular singlelink nonsymlink paths; identical current ABI/Root adoption associations.', 'limits': plan['limits'], 'caps': expect['other_caps'], 'prior_gate': 'Root directly admitted positive BASELINE; exact8402 adoption fullrawpin verified opaque without parsing costs/witness. Prior authorities remain spent; current grant must be new.', 'recipe': expect['recipe']},
    'forecast_hypothesis_exact': worker['STATE_PREDICTION'],
    'strict_forecast_postactual_stop': expect['forecast_stop_rule'],
    'forecast_implementation_precision': 'Current worker records applicable/expected/observed/matched/evaluation and COMPLETE_ARM_RESULT even for MISMATCH; normal Source/transport success alone therefore cannot waive the strict Root cohort stop. Whole independent actual review must derive counters and selected counts from complete retained actuals and enforce mismatch stop. No postfault getter, result rewrite, retry or cap change. No forecast outcome is asserted here.',
    'postactual_gates': ['Root adoption of this whole prospective review/support; fresh guards/named storage/path check; independent whole-actual criteria ready and all peers/unrelated Root work idle; then Root alone one fresh strict A6.', 'One owned process and authoritative exec/session terminal, full noclobber caller stdout/stderr<=1MiB combined, full worker stdout/stderr/result-byte readback, exact canonical terminal9/cost6, wait/reap/groupgone/drain/census and all8guards/resources complete; no prefix authority.', 'Whole independent scientific review of actual augmented model/extension/erasure/detachment, whole19683history reference, every stable event/full snapshot/dependency/metric/exclusion/entry/final/restored rollback check, conditional accepted solution projection/inverse, truthful complete costs and strict forecast associations.', 'Any custody/evidence/guard/resource/semantic/prediction mismatch stops cohort. Honest UNKNOWN remains UNKNOWN, forecast not evaluated; no expected witness promotion, no automatic continuation. No negative-arm plan/grant or batch authority here.'],
    'resource_clock_scope': expect['resource_clock_terminal'],
    'named_storage_and_freshness': {'complete_stat_only_files': 18, 'current_named_bytes': named, 'cap_bytes': 402653184, 'remaining_bytes': remaining, 'new_authority_consume_actual_captures_absent': True, 'meaning': 'Logical observed file-body extents only; docs/Source/plans/reviews/QA outside tally, no OS diskquota claim. Root rechecks before new A6.'},
    'exact_future_caller': audit['future_exact_caller_NEVER_EXECUTED_HERE'],
    'history_and_goal_boundary': 'Current Source review and seven-path-only ABI binding retained, including explicit unavailable old metadata boundaries; no recursive historical closure claim. STATE is manually certified finite supplied-context treatment. No speed/fit/learning/RL/FOL/theorem/universal/infinite/novelty/full geometric-conformance result. API costs stay separate; later negative cases remain unplanned/UNRUN.',
    'operations': audit['operations'], 'scientific_execution_authorized': False, 'A6_creation_authorized': False, 'publication_authorized': False,
    'final_state': 'TMP_FIRST_AND_NEW_REPO_MIRROR_FROZEN; REVIEWER_TOOLS_TERMINAL_IDLE_AFTER_HANDOFF; NO SCIENTIFIC_PROCESS_STARTED.'
}
review_pin = save('state-propagation-positive-state-complete-independent-prospective-review-v1.json', review)
print(json.dumps({'review': review_pin, 'support': audit_pin, 'expectations': expect_pin, 'stat_only_named_bytes': named, 'status': 'PASS_TERMINAL_IDLE_NO_EXECUTION_AUTHORITY'}, sort_keys=True))
