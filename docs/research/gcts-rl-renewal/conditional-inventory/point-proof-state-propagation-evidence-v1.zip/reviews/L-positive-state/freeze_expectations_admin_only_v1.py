from pathlib import Path
import datetime
import hashlib
import json
import os

out = Path('/private/tmp/gcts-L-positive-state-prospective-review-20261027-v1')
active = '/private/tmp/gcts-state-propagation-20261027-active-v1'
case = 'state-propagation-positive-state-v1-case-0'
obj = {
    'schema': 'L-state-propagation-positive-state-prefrozen-prospective-expectations-v1',
    'status': 'FROZEN_BEFORE_CURRENT_PLAN_BODY_INTAKE',
    'issued_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'subject': {'path': active + '/root/' + case + '-plan-v1.json', 'bytes': 1969, 'sha256': 'ae80d9ebd54083d144710e2a0b985019c4b8af541a5ce11ae9dc9a3924ee96f5'},
    'prior_positive_BASELINE_adoption_opaque_pin_only': {'path': active + '/root/state-propagation-positive-base-v1-case-0-Root-complete-whole-actual-adoption-v1.json', 'bytes': 8402, 'sha256': 'b3e1d43b6e8ba5cfb1964f35f2d0f0b3f6bccc73081cffa0a1c0ef935c6ae2c4'},
    'prior_gate_basis': 'Root directly states positive BASELINE admitted. Its exact adoption may be checked as complete opaque raw bytes only; do not parse/print cost/witness values. Prior actuals may be enumerated/statted for complete named accounting only; no body read/hash/semantic parsing. API and BASELINE authorities permanently spent under their admitted dispositions.',
    'reuse_Source_basis': 'Complete current Root operational Source adoption4925/885d51... and L ABI14165/557d4... with companion binding21033/7dbd... remain substantive Source/strict protocol basis; exact5 active Source guards175208 bytes plus D90 must be freshly verified now. No scientific imports/functions/models/fixtures/tests/CLI/help/codeobject execution.',
    'strict_plan': {'schema': 'GCTS-state-propagation-once-plan-v1', 'exact6': ['schema', 'case_id', 'actual_dir', 'python', 'sources', 'limits'], 'case_id': case, 'descriptor': {'arm': 'CERTIFIED_STATE', 'lane': 'BENCHMARK', 'problem': 'PRIMARY_ACCEPTED'}, 'actual_dir': active + '/actual/' + case, 'types_paths': 'Full strict duplicate/nonfinite-rejecting JSON; exact types/keysets/rawpin3; positive exactint source sizes within2MiB and lowercase64hex. No bool/float replacement. Canonical regular singlelink nonsymlink plan and Source/runtime; current absent direct actual; all parents nonsymlink.'},
    'limits_exact7': {'worker_seconds': 90, 'custody_seconds': 120, 'observer_seconds': 150, 'memory_bytes': 1073741824, 'observer_reserve_bytes': 16777216, 'result_bytes': 67108864, 'log_bytes': 1048576},
    'other_caps': {'Source_each': 2097152, 'plan': 65536, 'authority': 16384, 'terminal': 16384, 'metadata': 131072, 'chunk': 65536, 'node_limit': 10000, 'histories_domain': 19683, 'history_cap': 20000, 'stable_audits_cap': 2000, 'caller_combined_bytes': 1048576, 'cohort_named_bytes': 402653184},
    'recipe': 'One canonical positive problem; compile_tableau1/compile_wang1; state_augment_model1/state_erase_model1 with complete canonical extension/erasure/detachment verification. One fresh Engine on ACTUAL augmented model, one solve. No API malformed controls or extra Engine/warmup/retry; API_controls phase null. Whole19683 histories/reference sets, all stable events/full snapshots/dependencies/metrics/exclusion checks and exact entry/final/restored rollback associations retained without clipping. On accepted solution complete augmented full-solution/projection and original inverse checks retained; expected witnesses never feed search or promote UNKNOWN.',
    'forecast': {'nodes': 21, 'forced_placements': 20, 'branch_decisions': 0, 'backtracks': 0, 'accepted_base_placements': 38, 'seed_placements': 18},
    'forecast_stop_rule': 'Forecast is Source-declared hypothesis, not actual result or preapproved timing. After authoritative normal custody, entire independent scientific review must check applicable/expected/observed/matched/evaluation associations against complete actual counters and selected placements. Any forecast mismatch is a strict Root cohort stop, retained as mismatch, no retry/refit/relabel/cap increase/witness promotion. Worker Source records rather than raises this mismatch; future Root whole-admission gate must enforce it. An honest UNKNOWN remains UNKNOWN with forecast NOT_EVALUATED_UNKNOWN, never called matched or proved; any continuation requires separate complete Root disposition, no automatic next grant.',
    'resource_clock_terminal': 'Exact unchanged result12/terminal9/cost6/canonical16KiB metadata bindings, positive full opaque result/log readback, owned process group/wait/reap/drain/census and complete8 pre/post guard closure required. Child lifetime peak + late observer SELF peak +16MiB reserve<=1GiB as observational sum, not simultaneous/process-tree/hard cap. Worker main-entry excludes startup/imports; observer post-Popen-return interval is not full lifetime. Post-readback worker resource samples precede final gate; callback count follows gate; encode/flush/shutdown and final outer tails unmeasured. No crossclock inequality.',
    'future_caller': 'Only Root later: functions.exec_command shell=/bin/zsh login=false workdir=activeStudy; exactly two lines set -C then exec D90 -I -S -B activeobserver --plan exact currentplan --authority root/' + case + '-once-authority-v1.json >root/' + case + '-outer-stdout-v1.bin 2>root/' + case + '-outer-stderr-v1.bin. No capture Python parent/tee/echo/additional calls; noclobber both absent, combined<=1MiB. Preserve original full tool response/sessionID yield1000, poll only owned process handle until authoritative exit, never restart or use live prefixes. Full captures/outer/custody/terminal/result/guards/resources and separate whole scientific review required.',
    'fresh_once_storage': 'Current A6/adjacent consume/current actual/captures must be absent, same five immutable Source paths and runtime current. Future exact A6 schema6 authorizedtrue/int1/currentcase/currentwholeplan/currentobserver, exclusive dual consume before one Popen; no reuse prior grants. Stat-only full prior9+9 named file census must equal22198193, below384MiB; actualdir bodies+Root adjacent consumes+caller captures only, no OS quota claim. Recheck before fresh grant.',
    'remaining_gates': 'Root complete prospective adoption, fresh guards/storage/fresh-path checks, independent whole-actual criteria ready, all B/C/L and unrelated Root activity idle, then Root alone may issue one new A6. No negative-arm plan/grant or batch authority. After actual, full authoritative process and scientific gates including strict forecast stop. Reviewer ends terminal/idle.',
    'scope': 'No actual costs/witness/body intake, no model/table evaluation, no Source/plan/A6/actual creation or edit, no protected/original placeholder reads, no publication/network. No speed/learning/RL/FOL/theorem/universal/infinite/novelty claim. Prior metadata loss boundaries preserved by reference to current Source adoption and L companion binding; no recursive history closure.',
    'before_freeze_plan_body_intake': 0, 'scientific_execution_authorized': False, 'A6_creation_authorized': False
}
b = (json.dumps(obj, sort_keys=True, indent=2, ensure_ascii=False, allow_nan=False) + '\n').encode()
p = out / 'state-propagation-positive-state-prefrozen-prospective-expectations-v1.json'
with p.open('xb') as h:
    h.write(b); h.flush(); os.fsync(h.fileno())
assert p.read_bytes() == b
m = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-state-propagation-20261027/custody-L/positive-state-prospective-review-v1')
m.mkdir(exist_ok=False)
with (m / p.name).open('xb') as h:
    h.write(b); h.flush(); os.fsync(h.fileno())
assert (m / p.name).read_bytes() == b
print(json.dumps({'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest(), 'plan_body_intake_before_freeze': 0}))
