"""Inert STATE API qualification and one-arm controller worker; separate once required."""

import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import re
import resource
import sys
import time
import traceback
import types

VERSION = 'GCTS-STATE-PROPAGATION-QUALIFICATION-v1'
PLAN_SCHEMA = 'GCTS-state-propagation-once-plan-v1'
RESULT_SCHEMA = 'GCTS-state-propagation-worker-result-v1'
TERMINAL_SCHEMA = 'GCTS-state-propagation-worker-terminal-v1'
PYTHON = {'path': '/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12', 'bytes': 18058560, 'sha256': 'd90bce0f5ac3aa40e2ee5900ad243bad0b2205ce17408278f088b34aed737840'}
LIMITS = {'custody_seconds': 120, 'log_bytes': 1048576, 'memory_bytes': 1073741824, 'observer_reserve_bytes': 16777216, 'observer_seconds': 150, 'result_bytes': 67108864, 'worker_seconds': 90}
CASE_MAP = {'state-propagation-api-v1-case-0': {'arm': 'API_ONLY', 'lane': 'API_QUALIFICATION', 'problem': 'PRIMARY_ACCEPTED'}, 'state-propagation-positive-base-v1-case-0': {'arm': 'BASELINE', 'lane': 'BENCHMARK', 'problem': 'PRIMARY_ACCEPTED'}, 'state-propagation-positive-state-v1-case-0': {'arm': 'CERTIFIED_STATE', 'lane': 'BENCHMARK', 'problem': 'PRIMARY_ACCEPTED'}, 'state-propagation-negative-state-v1-case-0': {'arm': 'CERTIFIED_STATE', 'lane': 'BENCHMARK', 'problem': 'PRIMARY_IMPOSSIBLE_FINAL'}, 'state-propagation-negative-base-v1-case-0': {'arm': 'BASELINE', 'lane': 'BENCHMARK', 'problem': 'PRIMARY_IMPOSSIBLE_FINAL'}}
AUGMENT_NEGATIVES = [['A01', 'bundle-extra', 'STATE_BUNDLE_CANONICAL', 'Add one extra top-level bundle field.'], ['A02', 'bundle-nested-width-float', 'STATE_BUNDLE_CANONICAL', 'Change canonical nested width from exact integer five to float five.'], ['A03', 'model-extra', 'STATE_MODEL_SHAPE', 'Add one extra top-level model field.'], ['A04', 'capacity-bool', 'STATE_MODEL_SHAPE', 'Replace capacity with True.'], ['A05', 'translation-bool', 'STATE_MODEL_SHAPE', 'Replace one coordinate of the designated ordinary placement translation with True.'], ['A06', 'original-WANG-value-integer-zero', 'STATE_MODEL_SHAPE', 'Replace an original WANG literal value with integer zero, not the string zero.'], ['A07', 'original-WANG-valid-string-corruption', 'STATE_BASELINE_CANONICAL', 'At raw ordinary C:#:#:# in cell(0,0), change north WANG literal S:# to S:0; all types remain valid.'], ['A08', 'required-point-missing', 'STATE_BASELINE_CANONICAL', 'Delete one required point; all remaining structure/types/uniqueness remain valid.'], ['A09', 'preexisting-STATE-literal-zero', 'STATE_NOT_FRESH', 'Append a distinct welltyped mark at point(1000,1000), channel STATE, literal string zero, to an ordinary record.'], ['A10', 'already-augmented', 'STATE_NOT_FRESH', 'Pass the complete canonical successful augmented model as augmentation input.'], ['A11', 'priority-bundle-shape-freshness', 'STATE_BUNDLE_CANONICAL', 'Combine bundle extra field, boolean capacity and the A09 STATE row.'], ['A12', 'priority-shape-freshness', 'STATE_MODEL_SHAPE', 'Combine boolean capacity and the A09 STATE row.'], ['A13', 'priority-freshness-association', 'STATE_NOT_FRESH', 'Combine A07 wrong original WANG literal and A09 welltyped STATE row.']]
ERASE_NEGATIVES = [['E01', 'bundle-extra', 'STATE_BUNDLE_CANONICAL', 'Add one extra top-level bundle field.'], ['E02', 'model-extra', 'STATE_MODEL_SHAPE', 'Add one extra top-level augmented-model field.'], ['E03', 'STATE-coordinate-float', 'STATE_MODEL_SHAPE', 'Change one STATE coordinate to its floating-point representation.'], ['E04', 'STATE-value-integer-zero', 'STATE_MODEL_SHAPE', 'Replace a STATE literal value with integer zero.'], ['E05', 'baseline-instead-of-augmented', 'STATE_AUGMENTED_CANONICAL', 'Pass the complete original baseline, with no STATE rows, to erasure.'], ['E06', 'missing-STATE-row', 'STATE_AUGMENTED_CANONICAL', 'Delete the first STATE row in canonical m order from raw C:#:#:# at cell(0,0).'], ['E07', 'wrong-STATE-literal', 'STATE_AUGMENTED_CANONICAL', 'In that same first STATE row replace literal # with literal string zero.'], ['E08', 'extra-STATE-on-collar', 'STATE_AUGMENTED_CANONICAL', 'Append a distinct welltyped STATE literal-string-zero row at point(1000,1000) to a fixed collar seed.'], ['E09', 'original-WANG-corruption', 'STATE_AUGMENTED_CANONICAL', 'Change the same original north WANG literal as A07 while keeping all expected STATE rows.'], ['E10', 'noncanonical-m-row-order', 'STATE_AUGMENTED_CANONICAL', 'Reverse the full m list of the designated eight-mark computation record; all rows and values are retained.'], ['E11', 'translation-association', 'STATE_AUGMENTED_CANONICAL', 'Change only one ordinary translation coordinate by two exact integer units; retain t/m/ID/type. This replaces the earlier optional second-context descriptor and needs no extra compile.'], ['E12', 'priority-bundle-shape-augmentation', 'STATE_BUNDLE_CANONICAL', 'Combine bad bundle extra field, boolean capacity and a wrong STATE literal.'], ['E13', 'priority-shape-augmentation', 'STATE_MODEL_SHAPE', 'Combine boolean capacity and missing STATE row.']]
API_COUNTS = {'additional_target_contexts': 0, 'canonical_contexts': 1, 'compile_tableau_calls': 1, 'compile_wang_calls': 1, 'engine_instances': 0, 'independent_oracle_negative_cases': 4, 'positive_augmentation_returns': 1, 'positive_erasure_returns': 1, 'production_decode_calls': 0, 'production_negative_cases': 26, 'raw_history_examinations': 0, 'solve_calls': 0, 'stable_engine_audits': 0, 'state_augment_model_calls': 14, 'state_erase_model_calls': 14}
HISTORY_PARTITIONS = {'PRIMARY_ACCEPTED': {'ACCEPTED': 1, 'FINAL': 702, 'INITIAL': 18954, 'TRANSITION': 26}, 'PRIMARY_IMPOSSIBLE_FINAL': {'ACCEPTED': 0, 'FINAL': 702, 'INITIAL': 18954, 'TRANSITION': 27}}
STATE_PREDICTION = {'accepted_base_placements': 38, 'backtracks': 0, 'branch_decisions': 0, 'forced_placements': 20, 'nodes': 21, 'seed_placements': 18}
RESULT_KEYS = ['schema', 'worker_version', 'case_id', 'case_descriptor', 'status', 'plan', 'sources', 'limits', 'counts', 'costs', 'evidence', 'limitations']
TERMINAL_KEYS = ['schema', 'worker_version', 'case_id', 'case_descriptor', 'status', 'plan', 'result', 'post_result_readback_costs', 'unmeasured_worker_tail']
CAPTURE_SITE = 'AFTER_FULL_RESULT_SERIALIZE_FSYNC_READBACK_SHA_AND_PRE_CAPTURE_BUDGET; RESOURCE_SAMPLES_PRECEDE_FINAL_BUDGET; CALLBACK_COUNT_FOLLOWS_FINAL_BUDGET'
ELAPSED_ORIGIN = 'WORKER_MAIN_ENTRY_MONOTONIC_BEFORE_ARGS_AUTH_LOAD_AFTER_STARTUP_IMPORTS'
RSS_SCOPE = 'DARWIN_RUSAGE_SELF_LIFETIME_MAXRSS_BYTES'
TERMINAL_TAIL = 'Post-resource-sample final budget, terminal construction/encoding/extent check/stdout write/flush and interpreter shutdown are outside the worker resource samples. Callback count follows the final gate; parent late custody observations are separate.'
PHASES = ['authentication_load', 'base_construction_check', 'treatment_construction_check', 'API_controls', 'histories_expected_sets', 'engine_setup', 'solve_with_audits', 'post_result_verification_restore', 'evidence_preparation']
LIMITATIONS = ['Supplied deterministic finite table only; no learned/RL/cluster/FOL/universal/infinite/novelty/generalacceleration claim.', 'Complete actual augmented graph and marking-only dependencies; allQroot0/ordinarygeneration1.', 'No malformed controls or crossarm runtime reuse in benchmarks; freshprocess is not OScachecold.', 'Full histories and expected witnesses do not promote UNKNOWN; raised resource/evidence errors are unadmitted.', 'Prediction mismatch retained in complete output; Root disposition decides cohort consistency.', 'Worker clock mainentry excludes ownstartup/imports; parent workclock starts afterPopenreturns. LifetimeRSS is not simultaneous/process-tree/hardcap; terminal tail explicitly unmeasured.']


class QualificationError(RuntimeError):
    """Reject whole qualification; no partial scientific admission."""


def _need(condition, message):
    if not condition:
        raise QualificationError(message)


def _copy(value):
    return json.loads(json.dumps(value, allow_nan=False, separators=(",", ":")))


def _no_duplicate_object(pairs):
    result = {}
    for key, value in pairs:
        _need(key not in result, "duplicate JSON object key")
        result[key] = value
    return result


def _pin_shape(pin):
    _need(type(pin) is dict and set(pin) == {"path", "bytes", "sha256"}, "rawpin shape")
    _need(type(pin["path"]) is str and Path(pin["path"]).is_absolute(), "rawpin absolute path")
    _need(type(pin["bytes"]) is int and pin["bytes"] >= 0, "rawpin byte count")
    _need(type(pin["sha256"]) is str and re.fullmatch("[0-9a-f]{64}", pin["sha256"]),
          "rawpin digest")


def _canonical_path(value, label, kind):
    _need(type(value) is str, label + " path string")
    path = Path(value)
    _need(path.is_absolute() and str(path) == value and os.path.normpath(value) == value,
          label + " canonical absolute path")
    for ancestor in (path, *path.parents):
        _need(not ancestor.is_symlink(), label + " nonsymlink ancestor chain")
    _need(str(path.resolve(strict=False)) == value, label + " resolved canonical path")
    if kind == "file":
        _need(path.is_file() and path.stat(follow_symlinks=False).st_nlink == 1,
              label + " single-link regular file")
    elif kind == "directory":
        _need(path.is_dir(), label + " directory")
    elif kind == "newfile":
        _need(not path.exists() and path.parent.is_dir(), label + " fresh file with owned parent")
    else:
        raise QualificationError("unknown canonical path kind")
    return path


def _load(pin, name):
    """Future main only: compile and execute these exact authenticated bytes."""
    authenticated = _check_pin(pin)
    code = compile(authenticated, pin["path"], "exec", dont_inherit=True, optimize=0)
    module = types.ModuleType(name)
    module.__file__ = pin["path"]
    module.__package__ = ""
    module.__loader__ = None
    module.__spec__ = None
    module.__cached__ = None
    sys.modules[name] = module
    exec(code, module.__dict__)
    return module


def _read_json(path):
    size = path.stat(follow_symlinks=False).st_size
    _need(size <= 65536, "administrative plan extent")
    with path.open("rb") as stream:
        raw = stream.read(65537)
    _need(len(raw) == size and len(raw) <= 65536, "complete bounded administrative plan")
    value = json.loads(raw.decode("utf-8"), object_pairs_hook=_no_duplicate_object,
                       parse_constant=lambda unused: (_ for _ in ()).throw(QualificationError("nonfinite JSON")))
    return value, {"path": str(path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def _check_pin(pin):
    _pin_shape(pin)
    path = _canonical_path(pin["path"], "pinned Source/runtime", "file")
    _need(path.stat(follow_symlinks=False).st_size == pin["bytes"], "pinned stat extent")
    with path.open("rb") as stream:
        data = stream.read(pin["bytes"] + 1)
    _need(len(data) == pin["bytes"] and hashlib.sha256(data).hexdigest() == pin["sha256"],
          "complete current rawpin mismatch: " + pin["path"])
    return data


def _authenticate(plan_path, result_path):
    _canonical_path(str(plan_path), "plan", "file")
    _canonical_path(str(result_path), "result", "newfile")
    study = Path(__file__).resolve().parent.parent
    _need(study == Path('/private/tmp/gcts-state-propagation-20261027-active-v1') and Path(__file__).resolve() == Path('/private/tmp/gcts-state-propagation-20261027-active-v1/independent-C/state_propagation_qualification_v1.py'), "fixed executing worker selfrole")
    _need(plan_path.is_relative_to(study / "root") and plan_path.suffix == ".json" and
          all(not part.startswith(".") for part in plan_path.relative_to(study).parts), "owned administrative plan")
    plan, plan_pin = _read_json(plan_path)
    _need(type(plan) is dict and set(plan) == {"schema", "case_id", "actual_dir", "python", "sources", "limits"},
          "strict plan6 fields")
    _need(type(plan["schema"]) is str and plan["schema"] == PLAN_SCHEMA, "plan schema")
    _need(type(plan["case_id"]) is str and re.fullmatch("[a-z0-9][a-z0-9_-]{0,63}", plan["case_id"]), "case ID")
    _need(plan["case_id"] in CASE_MAP, "exact fixed case map")
    actual = study / "actual" / plan["case_id"]
    _canonical_path(str(actual), "owned actual", "directory")
    _need(type(plan["actual_dir"]) is str and plan["actual_dir"] == str(actual) and
          result_path == actual / "worker-result.json", "owned actual/result association")
    _pin_shape(plan["python"])
    _need(plan["python"] == PYTHON and type(plan["limits"]) is dict and set(plan["limits"]) == set(LIMITS) and
          all(type(plan["limits"][key]) is int and plan["limits"][key] == value for key, value in LIMITS.items()),
          "D90 and exact limits7")
    _need(sys.executable == PYTHON["path"] and sys.platform == "darwin" and sys.flags.isolated == 1 and
          sys.flags.no_site == 1 and sys.flags.dont_write_bytecode == 1 and sys.flags.optimize == 0,
          "D90 isolated assertions-on invocation")
    _need(type(plan["sources"]) is dict and set(plan["sources"]) == {"observer", "worker", "engine", "compiler", "oracle"},
          "strict Sources5")
    expected_paths = {
        "observer": study / "custody-L/state_propagation_once_observer_v1.py", "worker": Path(__file__).resolve(),
        "engine": study / "implementation-B/finite_point_engine_v1.py",
        "compiler": study / "implementation-B/finite_local_table_tableau_state_v1.py",
        "oracle": study / "independent-C/state_propagation_independent_v1.py"}
    for role, path in expected_paths.items():
        _pin_shape(plan["sources"][role])
        _need(plan["sources"][role]["path"] == str(path) and 0 < plan["sources"][role]["bytes"] <= 2097152,
              "exact bounded role Source")
        _check_pin(plan["sources"][role])
    _check_pin(PYTHON)
    return plan, plan_pin


def _primary_table():
    """New Source-literal adopted input table; never evaluated during authoring."""
    return [
        ["#", "#", "#", "#"], ["#", "#", "0", "#"], ["#", "#", "1", "#"],
        ["#", "0", "#", "0"], ["#", "0", "0", "0"], ["#", "0", "1", "1"],
        ["#", "1", "#", "0"], ["#", "1", "0", "0"], ["#", "1", "1", "1"],
        ["0", "#", "#", "#"], ["0", "#", "0", "#"], ["0", "#", "1", "#"],
        ["0", "0", "#", "0"], ["0", "0", "0", "0"], ["0", "0", "1", "1"],
        ["0", "1", "#", "0"], ["0", "1", "0", "0"], ["0", "1", "1", "1"],
        ["1", "#", "#", "#"], ["1", "#", "0", "#"], ["1", "#", "1", "#"],
        ["1", "0", "#", "1"], ["1", "0", "0", "1"], ["1", "0", "1", "0"],
        ["1", "1", "#", "1"], ["1", "1", "0", "1"], ["1", "1", "1", "0"]]


def _spec(control):
    identity, width, steps, initial, final, unused_status, unused_nodes, unused_domain = control
    table = _primary_table()
    if identity == "alternate-supplied-table":
        for row in table:
            if row[:3] == ["#", "1", "#"]:
                row[3] = "1"
    return {"schema": "GCTS-supplied-local-table-spec-v1", "alphabet": ["#", "0", "1"],
            "transitions": table, "width": width, "steps": steps,
            "initial": list(initial), "final": list(final)}


def _reverse_dicts(value):
    if type(value) is dict:
        return {key: _reverse_dicts(value[key]) for key in reversed(value)}
    if type(value) is list:
        return [_reverse_dicts(item) for item in value]
    return value


def _mutable_ids(value):
    found = set()
    if type(value) in (dict, list, tuple):
        if type(value) in (dict, list):
            found.add(id(value))
        children = value.values() if type(value) is dict else value
        for child in children:
            found.update(_mutable_ids(child))
    return found


def _detachment(value, arguments):
    forbidden, seen = _mutable_ids(arguments), set()
    def visit(item):
        if type(item) not in (dict, list):
            return
        _need(id(item) not in seen and id(item) not in forbidden, "returned mutable alias")
        seen.add(id(item))
        for child in (item.values() if type(item) is dict else item):
            visit(child)
    visit(value)
    return {"mutable_containers": len(seen), "no_caller_alias": True, "no_internal_alias": True}


def _poison(value):
    if type(value) in (dict, list, tuple):
        children = list(value.values()) if type(value) is dict else list(value)
        for child in children:
            _poison(child)
        if type(value) in (dict, list):
            value.clear()


def _designated(model):
    identity = '["WANG","C:#:#:#",0,0]'
    return next(record for record in model["placements"] if record["id"] == identity)


def _north(record):
    return next(row for row in record["m"] if row[:3] == [0, -1, "WANG"])


def _first_state(record):
    return next(row for row in record["m"] if row[2] == "STATE")


def _bad_input(identity, bundle, baseline, augmented):
    b = _copy(bundle)
    model = _copy(baseline if identity.startswith("A") else augmented)
    if identity == "A10":
        model = _copy(augmented)
    if identity == "E05":
        model = _copy(baseline)
    record = _designated(model)
    if identity in ("A01", "A11", "E01", "E12"):
        b["EXTRA"] = True
    if identity == "A02":
        b["spec"]["width"] = 5.0
    if identity in ("A03", "E02"):
        model["EXTRA"] = True
    if identity in ("A04", "A11", "A12", "E12", "E13"):
        model["capacity"] = True
    if identity == "A05":
        record["translation"][0] = True
    if identity == "A06":
        _north(record)[3] = 0
    if identity in ("A07", "A13", "E09"):
        _north(record)[3] = "S:0"
    if identity == "A08":
        model["required"].pop(0)
    if identity in ("A09", "A11", "A12", "A13"):
        record["m"].append([1000, 1000, "STATE", "0"])
    if identity == "E03":
        _first_state(record)[0] = float(_first_state(record)[0])
    if identity == "E04":
        _first_state(record)[3] = 0
    if identity in ("E06", "E13"):
        record["m"].remove(_first_state(record))
    if identity in ("E07", "E12"):
        _first_state(record)[3] = "0"
    if identity == "E08":
        seed = next(row for row in model["placements"] if row["id"] == model["seeds"][0])
        seed["m"].append([1000, 1000, "STATE", "0"])
    if identity == "E10":
        record["m"].reverse()
    if identity == "E11":
        record["translation"][0] += 2
    return b, model


class _Run:
    def __init__(self, engine, compiler, oracle, began):
        self.engine, self.compiler, self.oracle, self.began = engine, compiler, oracle, began
        self.budget_calls = 0
        self.oracle_notifications = 0
        self.oracle_calls = {name: 0 for name in ("state_verify_extension", "state_verify_erasure", "state_verify_full_solution")}
        self.engine_budget_calls = 0
        self.audit_count = 0
        self.calls = {key: 0 for key in ("compile_tableau", "compile_wang", "state_augment_model",
                                        "state_erase_model", "decode_tableau", "Engine", "solve")}
        self.phases = {key: None for key in PHASES}
        self._phase = None

    def budget(self):
        self.budget_calls += 1
        _need(time.monotonic() - self.began < LIMITS["worker_seconds"], "worker cooperative time refusal")
        _need(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss + LIMITS["observer_reserve_bytes"]
              <= LIMITS["memory_bytes"], "worker cooperative self-highwater plus declared reserve refusal")

    def notify(self):
        self.oracle_notifications += 1
        self.budget()

    def start(self, name):
        _need(name in self.phases and self._phase is None, "phase start")
        self._phase = (name, time.monotonic(), self.budget_calls)

    def finish(self):
        self.budget()
        name, clock, callbacks = self._phase
        self.phases[name] = {"elapsed_seconds": time.monotonic() - clock,
                             "budget_callbacks": self.budget_calls - callbacks}
        self._phase = None

    def call(self, name, *arguments):
        self.budget()
        self.calls[name] += 1
        module = self.engine if name == "compile_wang" else self.compiler
        try:
            return getattr(module, name)(*arguments)
        finally:
            self.budget()

    def oracle_call(self, name, *arguments):
        before = self.oracle_notifications
        self.oracle_calls[name] += 1
        result = getattr(self.oracle, name)(*arguments, self.notify)
        wanted = {"state_verify_extension": 680, "state_verify_erasure": 682,
                  "state_verify_full_solution": 684}[name]
        _need(self.oracle_notifications - before == wanted, "valid oracle notification count")
        return result

    def reject(self, function, arguments, error_type, code):
        before = _copy(list(arguments))
        callbacks = self.budget_calls
        try:
            function(*arguments)
        except error_type as error:
            _need(type(error) is error_type and error.args == (code,) and str(error) == code,
                  "exact sole-code exception")
            self.oracle._same(list(arguments), before, "negative input unchanged")
            return {"input_before": before, "input_after": _copy(list(arguments)),
                    "expected_type": error_type.__name__, "expected_code": code,
                    "exception": {"type": type(error).__name__, "args": list(error.args), "message": str(error)},
                    "no_success_return": True, "input_unchanged": True,
                    "budget_callbacks": self.budget_calls - callbacks}
        raise QualificationError("invalid input accepted: " + code)

    def pure(self, name, bundle, model):
        arguments = (_reverse_dicts(bundle), _reverse_dicts(model))
        before = _copy(list(arguments))
        returned = self.call(name, *arguments)
        self.oracle._same(list(arguments), before, "positive input unchanged")
        aliases = _detachment(returned, arguments)
        retained = _copy(returned)
        _poison(arguments)
        self.oracle._same(returned, retained, "caller poison leaves output unchanged")
        poisoned = _copy(list(arguments))
        _poison(returned)
        self.oracle._same(list(arguments), poisoned, "output poison leaves caller unchanged")
        return retained, {"input_before": before, "input_after_poison": poisoned,
                          "output_after_poison": _copy(returned), "input_unchanged_before_poison": True,
                          "caller_to_output_detached": True, "output_to_caller_detached": True,
                          "container_identity_check": aliases}

    def base(self, descriptor):
        self.start("base_construction_check")
        wanted = "#101#" if descriptor["problem"] == "PRIMARY_ACCEPTED" else "#100#"
        spec = _spec((descriptor["problem"], 5, 2, "#100#", wanted, "unused", 10000, 19683))
        caller = _copy(spec)
        bundle = self.call("compile_tableau", caller)
        self.oracle._same(caller, spec, "compile leaves spec unchanged")
        baseline = self.call("compile_wang", bundle["palette"], bundle["region"], bundle["boundary"])
        check = self.oracle.tableau_verify_bundle_model(spec, bundle, baseline)
        self.finish()
        return spec, bundle, baseline, check

    def api(self, descriptor):
        spec, bundle, baseline, base_check = self.base(descriptor)
        self.start("API_controls")
        augmented, augment_purity = self.pure("state_augment_model", bundle, baseline)
        before = self.oracle_notifications
        extension = self.oracle_call("state_verify_extension", spec, bundle, baseline, augmented)
        _need(self.oracle_notifications - before == 680, "extension notification count")
        erased, erase_purity = self.pure("state_erase_model", bundle, augmented)
        before = self.oracle_notifications
        erasure = self.oracle_call("state_verify_erasure", spec, bundle, augmented, erased)
        _need(self.oracle_notifications - before == 682, "erasure notification count")
        production = []
        for identity, label, code, description in AUGMENT_NEGATIVES + ERASE_NEGATIVES:
            b, model = _bad_input(identity, bundle, baseline, augmented)
            entry = "state_augment_model" if identity.startswith("A") else "state_erase_model"
            record = self.reject(lambda *args: self.call(entry, *args), (b, model),
                                 self.compiler.StateMarkingError, code)
            production.append({"id": identity, "label": label, "entry": entry,
                               "description": description, "rejection": record})
        independent = []
        for identity in ("O01", "O02", "O03", "O04"):
            bad, bad_erased = _copy(augmented), _copy(erased)
            record = _designated(bad)
            if identity == "O01":
                record["m"].remove(_first_state(record))
            elif identity == "O02":
                _first_state(record)[3] = "0"
            elif identity == "O03":
                _first_state(record)[3] = 0
            else:
                raw = _designated(bad_erased)
                raw["m"].remove(_north(raw))
            if identity == "O04":
                function = self.oracle.state_verify_erasure
                arguments = (spec, bundle, augmented, bad_erased, self.notify)
                code = "STATE_ERASURE_INVALID"
            else:
                function = self.oracle.state_verify_extension
                arguments = (spec, bundle, baseline, bad, self.notify)
                code = "STATE_EXTENSION_INVALID"
            # Callback is not JSON data; keep complete data arguments separately.
            def invoke(*data):
                return function(*data, self.notify)
            rejected = self.reject(invoke, arguments[:-1], self.oracle.state_Error, code)
            independent.append({"id": identity, "rejection": rejected})
        self.finish()
        self.start("evidence_preparation")
        counts = dict(API_COUNTS)
        _need(self.calls == {"compile_tableau": 1, "compile_wang": 1, "state_augment_model": 14,
                             "state_erase_model": 14, "decode_tableau": 0, "Engine": 0, "solve": 0},
              "exact zero-Engine API direct census")
        _need(len(production) == 26 and len(independent) == 4, "negative census")
        evidence = {"spec": spec, "bundle": bundle, "baseline_model": baseline,
                    "augmented_model": augmented, "erased_model": erased, "baseline_check": base_check,
                    "extension_check": extension, "erasure_check": erasure,
                    "positive_purity": {"augmentation": augment_purity, "erasure": erase_purity},
                    "production_negatives": production, "oracle_negatives": independent}
        self.finish()
        return "API_QUALIFICATION_PASS", counts, evidence

    def benchmark(self, descriptor):
        spec, bundle, baseline, base_check = self.base(descriptor)
        model, extension, erased, erasure = baseline, None, None, None
        if descriptor["arm"] == "CERTIFIED_STATE":
            self.start("treatment_construction_check")
            model = self.call("state_augment_model", bundle, baseline)
            extension = self.oracle_call("state_verify_extension", spec, bundle, baseline, model)
            erased = self.call("state_erase_model", bundle, model)
            erasure = self.oracle_call("state_verify_erasure", spec, bundle, model, erased)
            self.finish()
        self.start("histories_expected_sets")
        histories = self.oracle.tableau_histories(spec, self.budget, 20000)
        _need(histories["complete"] is True and histories["examined"] == 19683, "entire raw history domain")
        partition = dict(histories["rejections"], ACCEPTED=len(histories["accepted"]))
        self.oracle._same(partition, HISTORY_PARTITIONS[descriptor["problem"]], "same-spec history partition")
        expected = self.oracle.tableau_expected_solutions(bundle, baseline, histories)
        augmented_expected = []
        if descriptor["arm"] == "CERTIFIED_STATE":
            for ids in expected["solutions"]:
                augmented_expected.append(self.oracle_call("state_verify_full_solution",
                    spec, bundle, baseline, model, ids))
        self.finish()
        events, previous, dependencies = [], {"metrics": None}, {"value": None}
        def engine_budget():
            self.engine_budget_calls += 1
            self.budget()
            return True
        def audit(engine, event):
            self.budget()
            self.audit_count += 1
            _need(self.audit_count <= 2000, "whole stable-audit cap; never truncate")
            _need(type(event) is dict and set(event) == {"kind", "data"} and type(event["kind"]) is str,
                  "stable event shape")
            snapshot = engine.snapshot()
            check = self.oracle.verify_snapshot(model, snapshot)
            dependency = self.oracle.verify_dependencies(model, engine.dependencies)
            if dependencies["value"] is None:
                dependencies["value"] = engine.dependencies
            else:
                self.oracle._same(engine.dependencies, dependencies["value"], "static full dependencies")
            metrics = engine.metrics
            metric_check = self.oracle.verify_metrics(metrics, snapshot, previous["metrics"])
            previous["metrics"] = _copy(metrics)
            kind, data = event["kind"], event["data"]
            fields = {"INITIALIZED": set(), "PLACED": {"id", "reason", "generation"},
                      "EXCLUDED": {"id", "reason"}, "ROLLED_BACK": {"checkpoint"},
                      "DECISION": {"kind", "point", "candidates"},
                      "SOLVE_RESULT": {"status", "nodes", "reason"}}
            _need(kind in fields and type(data) is dict and set(data) == fields[kind], "stable event exact fields")
            if kind == "DECISION":
                self.oracle._same(data, check["decision"], "global reference decision")
            elif kind == "PLACED":
                _need(type(data["id"]) is str and type(data["reason"]) is str and type(data["generation"]) is int
                      and snapshot["selected"][-1] == data["id"] and
                      [data["id"], data["generation"]] in snapshot["tile_generations"], "placed event state")
            elif kind == "EXCLUDED":
                _need(type(data["id"]) is str and type(data["reason"]) is str and data in snapshot["excluded"],
                      "excluded event state")
            elif kind == "ROLLED_BACK":
                _need(type(data["checkpoint"]) is int and data["checkpoint"] == snapshot["trail_size"], "rollback event")
            elif kind == "SOLVE_RESULT":
                _need(type(data["nodes"]) is int and data["nodes"] >= 0 and
                      data["status"] in ("FINITE_EXACT_SOLUTION", "EXHAUSTED_FINITE_SEARCH", "UNKNOWN") and
                      data["reason"] in ("SOLUTION", "EXHAUSTED", "NODE_LIMIT", "EXTERNAL_BUDGET"), "result event")
            exclusions = self.oracle.verify_contextual_exclusions(snapshot, expected["solutions"])
            events.append({"event": _copy(event), "snapshot": snapshot, "metrics": metrics,
                           "independent_snapshot": check, "dependency_check": dependency,
                           "metric_check": metric_check, "search_exclusion_check": exclusions})
            self.budget()
        self.start("engine_setup")
        self.calls["Engine"] += 1
        engine = self.engine.Engine(model, audit=audit, budget=engine_budget)
        _need(len(events) == 1 and events[0]["event"]["kind"] == "INITIALIZED", "initial audit")
        self.oracle._same(engine.model, self.oracle.canonical_model(model), "actual raw model")
        entry = engine.snapshot()
        checkpoint = engine.checkpoint()
        _need(type(checkpoint) is int and checkpoint == entry["trail_size"], "exact entry checkpoint")
        self.finish()
        self.start("solve_with_audits")
        self.calls["solve"] += 1
        result = engine.solve(node_limit=10000)
        self.finish()
        self.start("post_result_verification_restore")
        final = engine.snapshot()
        unknown = result["status"] == "UNKNOWN"
        result_check = self.oracle.verify_solve_result(model, result, entry, final, expected, unknown)
        _need(result["nodes"] <= 10000, "node ceiling")
        whole, inverse = None, None
        if result["status"] == "FINITE_EXACT_SOLUTION":
            if descriptor["arm"] == "CERTIFIED_STATE":
                whole = self.oracle_call("state_verify_full_solution", spec, bundle, baseline, model,
                                             result["selected"])
            else:
                whole = self.oracle.tableau_verify_point_result(spec, bundle, model, result["selected"])
            assignment = whole["assignment_for_production_inverse"]
            before_bundle, before_assignment = _copy(bundle), _copy(assignment)
            inverse = self.call("decode_tableau", bundle, assignment)
            self.oracle._same(bundle, before_bundle, "inverse bundle unchanged")
            self.oracle._same(assignment, before_assignment, "inverse assignment unchanged")
            self.oracle._same(inverse, whole["trace"], "full original trace inverse")
            engine.rollback(checkpoint)
        else:
            self.oracle._same(final, entry, "negative or UNKNOWN whole restoration")
        restored = engine.snapshot()
        self.oracle._same(restored, entry, "entire explicit entry restoration")
        restored_check = self.oracle.verify_snapshot(model, restored)
        prediction = {"applicable": descriptor["problem"] == "PRIMARY_ACCEPTED" and
                       descriptor["arm"] == "CERTIFIED_STATE", "expected": _copy(STATE_PREDICTION),
                      "observed": None, "matched": None, "evaluation": "NOT_APPLICABLE"}
        if prediction["applicable"]:
            if result["status"] == "FINITE_EXACT_SOLUTION":
                observed = {key: result["metrics"][key] for key in STATE_PREDICTION if key != "nodes"}
                observed["nodes"] = result["nodes"]
                prediction.update(observed=observed, matched=self.oracle.tableau_equal(observed, STATE_PREDICTION),
                                  evaluation="MATCHED" if self.oracle.tableau_equal(observed, STATE_PREDICTION) else "MISMATCH")
            else:
                prediction["evaluation"] = "NOT_EVALUATED_UNKNOWN"
        self.finish()
        self.start("evidence_preparation")
        counts = {"direct_calls": _copy(self.calls), "raw_history_examinations": histories["examined"],
                  "accepted_history_records": len(histories["accepted"]), "stable_engine_audits": self.audit_count,
                  "engine_status": result["status"], "production_negative_cases": 0,
                  "independent_oracle_negative_cases": 0}
        _need(self.calls["compile_tableau"] == self.calls["compile_wang"] == 1 and
              self.calls["Engine"] == self.calls["solve"] == 1 and
              self.calls["state_augment_model"] == self.calls["state_erase_model"] ==
              int(descriptor["arm"] == "CERTIFIED_STATE"), "one-arm direct census")
        evidence = {"spec": spec, "bundle": bundle, "baseline_model": baseline, "arm_model": model,
                    "baseline_check": base_check, "extension_check": extension, "erased_model": erased,
                    "erasure_check": erasure, "histories": histories, "history_partition": partition,
                    "expected_base_solutions": expected, "augmented_expected_solution_checks": augmented_expected,
                    "static_dependencies": dependencies["value"], "entry": entry, "entry_checkpoint": checkpoint,
                    "events": events, "solve_result": result, "solve_result_check": result_check,
                    "whole_solution_check": whole, "production_inverse": inverse, "final": final,
                    "restored": restored, "restored_snapshot_check": restored_check, "prediction": prediction}
        self.finish()
        return "COMPLETE_ARM_RESULT", counts, evidence


def main():
    began = time.monotonic()
    parser = argparse.ArgumentParser()
    parser.add_argument("--plan", required=True)
    parser.add_argument("--result", required=True)
    args = parser.parse_args()
    plan_path = _canonical_path(args.plan, "plan CLI", "file")
    result_path = _canonical_path(args.result, "result CLI", "newfile")
    plan, plan_pin = _authenticate(plan_path, result_path)
    oracle = _load(plan["sources"]["oracle"], "gcts_state_independent_pinned")
    compiler = _load(plan["sources"]["compiler"], "gcts_state_compiler_pinned")
    engine = _load(plan["sources"]["engine"], "gcts_state_engine_pinned")
    _need(engine.VERSION == "GCTS-FINITE-POINT-ENGINE-v1" and
          compiler.VERSION == "GCTS-SUPPLIED-LOCAL-TABLE-TABLEAU-v1" and
          compiler.STATE_VERSION == "GCTS-SUPPLIED-LOCAL-TABLE-STATE-v1" and
          oracle.VERSION == "GCTS-finite-point-independent-v2" and
          oracle.TABLEAU_VERSION == "GCTS-FINITE-TABLEAU-INDEPENDENT-v1" and
          oracle.STATE_VERSION == "GCTS-STATE-PROPAGATION-INDEPENDENT-v1", "exact role versions")
    run = _Run(engine, compiler, oracle, began)
    run.phases["authentication_load"] = {"elapsed_seconds": time.monotonic() - began, "budget_callbacks": 0}
    descriptor = _copy(CASE_MAP[plan["case_id"]])
    status, counts, evidence = run.api(descriptor) if descriptor["lane"] == "API_QUALIFICATION" else run.benchmark(descriptor)
    envelope = {"schema": RESULT_SCHEMA, "worker_version": VERSION, "case_id": plan["case_id"],
                "case_descriptor": descriptor, "status": status, "plan": plan_pin,
                "sources": plan["sources"], "limits": plan["limits"], "counts": counts,
                "costs": {"elapsed_seconds_before_serialization": time.monotonic() - began,
                          "self_lifetime_highwater_bytes_before_serialization": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                          "worker_budget_callbacks_before_serialization": run.budget_calls,
                          "oracle_notifications_before_serialization": run.oracle_notifications,
                          "positive_oracle_calls_before_serialization": run.oracle_calls,
                          "engine_budget_callbacks_before_serialization": run.engine_budget_calls,
                          "stable_audits": run.audit_count, "phases": run.phases,
                          "scope": "MAIN_ENTRY_AFTER_STARTUP_IMPORTS_BEFORE_ARGS_AUTH_LOAD; PRE_SERIALIZATION_SAMPLES"},
                "evidence": evidence, "limitations": LIMITATIONS}
    _need(set(envelope) == set(RESULT_KEYS), "exact result12")
    raw = json.dumps(envelope, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()+b"\n"
    _need(len(raw) <= LIMITS["result_bytes"], "whole result64MiB; no truncation")
    run.budget()
    for pin in plan["sources"].values():
        _check_pin(pin)
    _check_pin(PYTHON)
    _need(_read_json(plan_path)[1] == plan_pin, "whole plan postguard")
    with result_path.open("xb") as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    run.budget()
    with result_path.open("rb") as stream:
        saved = stream.read(LIMITS["result_bytes"] + 1)
    _need(saved == raw, "complete bounded result readback")
    result_pin = {"path": str(result_path), "bytes": len(raw), "sha256": hashlib.sha256(saved).hexdigest()}
    run.budget()
    elapsed = time.monotonic() - began
    peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    run.budget()
    _need(type(elapsed) is float and math.isfinite(elapsed) and 0 <= elapsed < LIMITS["worker_seconds"] and
          type(peak) is int and 0 <= peak <= LIMITS["memory_bytes"], "typed post-readback samples")
    terminal = {"schema": TERMINAL_SCHEMA, "worker_version": VERSION, "case_id": plan["case_id"],
                "case_descriptor": descriptor, "status": "NORMAL_WORKER_RESULT_WRITTEN", "plan": plan_pin,
                "result": result_pin, "post_result_readback_costs": {
                    "elapsed_seconds": elapsed, "self_lifetime_highwater_bytes": peak,
                    "worker_budget_callbacks_before_terminal_encoding": run.budget_calls,
                    "capture_site": CAPTURE_SITE, "elapsed_origin": ELAPSED_ORIGIN, "rss_scope": RSS_SCOPE},
                "unmeasured_worker_tail": TERMINAL_TAIL}
    encoded = (json.dumps(terminal, sort_keys=True, indent=2, allow_nan=False)+"\n").encode()
    _need(len(encoded) <= 16384 and set(terminal) == set(TERMINAL_KEYS), "whole terminal16KiB/exact9")
    sys.stdout.buffer.write(encoded)
    sys.stdout.buffer.flush()
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print(json.dumps({"schema": "GCTS-state-propagation-worker-error-v1", "type": type(error).__name__,
                          "error": str(error), "normal_result_admitted": False}), file=sys.stderr)
        traceback.print_exc(file=sys.stderr)
        raise SystemExit(2)
