"""Independent raw-point oracle; no engine or compiler import.

Source-only until a separately authorized bounded qualification actual.
All arithmetic uses exact integer capacity units; markings are literal strings.
"""

from itertools import combinations, product
import json


VERSION = "GCTS-finite-point-independent-v2"
MODEL_SCHEMA = "GCTS-finite-point-instance-v1"


class IndependentError(ValueError):
    """The raw input, evidence, or independently reconstructed claim is invalid."""


def _need(condition, message):
    if not condition:
        raise IndependentError(message)


def _keys(value, expected, label):
    _need(type(value) is dict and set(value) == set(expected), label + " fields")


def _integer(value, label):
    _need(type(value) is int, label + " integer")
    return value


def _point(value, label):
    _need(type(value) is list and len(value) == 2, label + " point")
    return (_integer(value[0], label), _integer(value[1], label))


def _string(value, label):
    _need(type(value) is str, label + " literal string")
    return value


def _decode(model):
    """Validate the raw model independently and return private exact indexes."""
    _keys(model, ("schema", "capacity", "required", "placements", "seeds"), "model")
    _string(model["schema"], "model schema")
    _need(model["schema"] == MODEL_SCHEMA, "model schema")
    capacity = _integer(model["capacity"], "capacity")
    _need(capacity > 0, "positive capacity")
    _need(type(model["required"]) is list, "required list")
    required = [_point(p, "required") for p in model["required"]]
    _need(len(set(required)) == len(required), "duplicate required point")
    q = set(required)
    _need(type(model["placements"]) is list, "placement list")
    placements = {}
    for record in model["placements"]:
        _keys(record, ("id", "type", "translation", "t", "m"), "placement")
        identity = _string(record["id"], "placement id")
        _need(identity not in placements, "duplicate placement id")
        _string(record["type"], "placement type")
        _point(record["translation"], "translation")
        _need(type(record["t"]) is list and len(record["t"]) > 0, "positive support")
        support = {}
        for row in record["t"]:
            _need(type(row) is list and len(row) == 3, "t row")
            p = (_integer(row[0], "t x"), _integer(row[1], "t y"))
            units = _integer(row[2], "t units")
            _need(0 < units <= capacity and p not in support, "t weight or duplicate")
            support[p] = units
        _need(type(record["m"]) is list, "mark list")
        markings = {}
        for row in record["m"]:
            _need(type(row) is list and len(row) == 4, "m row")
            slot = (_integer(row[0], "m x"), _integer(row[1], "m y"),
                    _string(row[2], "m channel"))
            value = _string(row[3], "m value")
            _need(slot not in markings, "duplicate m slot")
            markings[slot] = value
        placements[identity] = {"raw": record, "t": support, "m": markings}
    _need(type(model["seeds"]) is list, "seed list")
    seeds = [_string(identity, "seed id") for identity in model["seeds"]]
    _need(len(set(seeds)) == len(seeds), "duplicate seed")
    _need(set(seeds) <= set(placements), "unknown seed")
    for identity, placement in placements.items():
        _need(identity in seeds or any(p in q for p in placement["t"]),
              "ordinary placement does not touch Q")
    decoded = {"capacity": capacity, "required": required, "q": q,
               "placements": placements, "seeds": seeds}
    _accumulate(decoded, seeds)
    return decoded


def _accumulate(decoded, selected):
    """Raw recomputation over every support point, including outside Q."""
    _need(type(selected) is list, "selected list")
    _need(all(type(identity) is str for identity in selected), "selected string identities")
    _need(len(selected) == len(set(selected)), "duplicate selected identity")
    totals = {}
    marks = {}
    for identity in selected:
        _need(type(identity) is str and identity in decoded["placements"],
              "unknown selected identity")
        placement = decoded["placements"][identity]
        for point, units in placement["t"].items():
            totals[point] = totals.get(point, 0) + units
            _need(totals[point] <= decoded["capacity"], "selected capacity conflict")
        for slot, value in placement["m"].items():
            if slot in marks:
                _need(marks[slot][0] == value, "selected marking conflict")
                marks[slot][1] += 1
            else:
                marks[slot] = [value, 1]
    return totals, marks


def validate_model(model):
    """Return a finite census after complete independent input validation."""
    d = _decode(model)
    return {"placements": len(d["placements"]), "seeds": len(d["seeds"]),
            "required": len(d["required"]), "capacity": d["capacity"]}


def _available(decoded, totals, marks, identity):
    p = decoded["placements"][identity]
    capacity_bad = any(totals.get(point, 0) + units > decoded["capacity"]
                       for point, units in p["t"].items())
    marking_bad = any(slot in marks and marks[slot][0] != value
                      for slot, value in p["m"].items())
    return not capacity_bad and not marking_bad, capacity_bad, marking_bad


def reconstruct(model, selected_order, exclusions):
    """Reconstruct semantic state; public snapshot adaptation is below.

    exclusions is a dictionary mapping contextual excluded IDs to reason strings.
    It is an input describing current branch state, never treated as a proof of
    global redundancy or as an independent finite-exhaustion certificate.
    """
    d = _decode(model)
    _need(type(selected_order) is list, "selected order list")
    _need(selected_order[:len(d["seeds"])] == d["seeds"], "mandatory seed prefix")
    totals, marks = _accumulate(d, selected_order)
    _keys(exclusions, exclusions.keys() if type(exclusions) is dict else (), "exclusions")
    selected = set(selected_order)
    for identity, reason in exclusions.items():
        _need(type(identity) is str and identity in d["placements"] and
              identity not in selected and identity not in d["seeds"], "excluded identity")
        _string(reason, "exclusion reason")
    point_generation = {point: 0 for point in d["q"]}
    tile_generation = {}
    for identity in selected_order:
        support = d["placements"][identity]["t"]
        existing = [point_generation[p] for p in support if p in point_generation]
        _need(identity in d["seeds"] or existing, "disconnected nonroot placement")
        generation = 0 if identity in d["seeds"] else 1 + min(existing)
        tile_generation[identity] = generation
        for point in support:
            point_generation[point] = min(point_generation.get(point, generation), generation)
    frontier = sorted(point for point in d["q"] if totals.get(point, 0) < d["capacity"])
    all_candidates = {}
    forward = {point: [] for point in frontier}
    reverse = {}
    for identity in sorted(d["placements"]):
        legal, capacity_bad, marking_bad = _available(d, totals, marks, identity)
        usable = identity not in selected and identity not in exclusions and legal
        edges = [(point, units) for point, units in d["placements"][identity]["t"].items()
                 if point in forward] if usable else []
        all_candidates[identity] = {"selected": identity in selected,
                                    "excluded": identity in exclusions,
                                    "capacity_conflict": capacity_bad,
                                    "marking_conflict": marking_bad,
                                    "available": usable}
        if edges:
            reverse[identity] = sorted(edges)
            for point, units in edges:
                forward[point].append((identity, units))
    dependencies = {}
    for identity, placement in d["placements"].items():
        for point in set(placement["t"]) | {slot[:2] for slot in placement["m"]}:
            dependencies.setdefault(point, []).append(identity)
    return {"selected": list(selected_order), "exclusions": dict(exclusions),
            "totals": totals, "marks": marks, "point_generation": point_generation,
            "tile_generation": tile_generation, "frontier": frontier,
            "all_candidates": all_candidates, "forward": forward, "reverse": reverse,
            "dependencies": {p: sorted(ids) for p, ids in dependencies.items()}}


def reference_decision(frontier_rows):
    """Independent global-dead/global-forced/generation-first selector."""
    _need(type(frontier_rows) is list, "frontier rows")
    seen = set()
    rows = []
    for row in frontier_rows:
        _keys(row, ("point", "generation", "candidates"), "frontier selector row")
        point = _point(row["point"], "selector")
        _need(point not in seen, "duplicate selector point")
        seen.add(point)
        generation = _integer(row["generation"], "generation")
        _need(generation >= 0 and type(row["candidates"]) is list, "selector fields")
        candidates = row["candidates"]
        _need(all(type(c) is str for c in candidates) and len(set(candidates)) == len(candidates),
              "selector candidates")
        rows.append((point, generation, sorted(candidates)))
    if not rows:
        return {"kind": "SOLUTION", "point": None, "candidates": []}
    dead = [r for r in rows if not r[2]]
    forced = [r for r in rows if len(r[2]) == 1]
    if dead:
        chosen = min(dead, key=lambda r: r[0])
        kind = "DEAD"
    elif forced:
        chosen = min(forced, key=lambda r: r[0])
        kind = "FORCED"
    else:
        chosen = min(rows, key=lambda r: (r[1], len(r[2]), r[0]))
        kind = "BRANCH"
    return {"kind": kind, "point": list(chosen[0]), "candidates": chosen[2]}


def verify_solution(model, selected_ids):
    """Verify complete original-point semantics independently of graph state."""
    d = _decode(model)
    _need(type(selected_ids) is list and all(type(x) is str for x in selected_ids),
          "solution IDs")
    totals, marks = _accumulate(d, selected_ids)
    _need(set(d["seeds"]) <= set(selected_ids), "solution missing fixed seed")
    _need(all(totals.get(point, 0) == d["capacity"] for point in d["q"]),
          "incomplete required coverage")
    return {"selected": sorted(selected_ids), "required": len(d["q"]),
            "positive_points": len(totals), "mark_slots": len(marks), "exact": True}


def exhaustive_solutions(model, maximum_optional=16, budget=None):
    """Straight independent subset enumeration, with no engine decisions."""
    d = _decode(model)
    optional = sorted(set(d["placements"]) - set(d["seeds"]))
    _need(type(maximum_optional) is int and 0 <= maximum_optional <= 20,
          "exhaustive optional bound")
    _need(len(optional) <= maximum_optional, "exhaustive universe too large")
    solutions = []
    examined = 0
    for size in range(len(optional) + 1):
        for subset in combinations(optional, size):
            if budget is not None:
                budget()
            selected = list(d["seeds"]) + list(subset)
            examined += 1
            try:
                totals, unused_marks = _accumulate(d, selected)
            except IndependentError:
                continue
            if all(totals.get(p, 0) == d["capacity"] for p in d["q"]):
                solutions.append(sorted(selected))
    return {"solutions": sorted(solutions), "subsets_examined": examined,
            "optional_placements": len(optional), "complete": True}


def _same(actual, expected, label):
    """Type-exact JSON comparison; bool never equals an expected integer."""
    _need(type(actual) is type(expected), label + " type")
    if type(expected) is dict:
        _need(set(actual) == set(expected), label + " keys")
        for key in expected:
            _same(actual[key], expected[key], label + "/" + key)
    elif type(expected) is list:
        _need(len(actual) == len(expected), label + " length")
        for index, value in enumerate(expected):
            _same(actual[index], value, label + "/" + str(index))
    else:
        _need(actual == expected, label + " value")


def canonical_model(model):
    d = _decode(model)
    records = []
    for identity in sorted(d["placements"]):
        p = d["placements"][identity]
        raw = p["raw"]
        records.append({"id": identity, "type": raw["type"],
                        "translation": list(raw["translation"]),
                        "t": [[*point, units] for point, units in sorted(p["t"].items())],
                        "m": [[*slot, value] for slot, value in sorted(p["m"].items())]})
    return {"schema": MODEL_SCHEMA, "capacity": d["capacity"],
            "required": [list(p) for p in sorted(d["q"])],
            "placements": records, "seeds": list(d["seeds"])}


def verify_snapshot(model, snapshot):
    """Compare every public semantic field against a raw recomputation.

    trail_size is a typed opaque index; its exact restoration is checked by the
    worker's complete before/after snapshot equality, never a guessed formula.
    """
    fields = ("schema", "selected", "excluded", "totals", "markings",
              "point_generations", "tile_generations", "frontier", "candidate_rows",
              "active_candidates", "forward_incidence", "reverse_incidence", "trail_size")
    _keys(snapshot, fields, "snapshot")
    _need(type(snapshot["trail_size"]) is int and snapshot["trail_size"] >= 0,
          "opaque trail index")
    _need(type(snapshot["excluded"]) is list, "excluded rows")
    exclusions = {}
    for row in snapshot["excluded"]:
        _keys(row, ("id", "reason"), "excluded row")
        identity = _string(row["id"], "excluded id")
        _need(identity not in exclusions, "duplicate excluded identity")
        exclusions[identity] = _string(row["reason"], "excluded reason")
    d = _decode(model)
    state = reconstruct(model, snapshot["selected"], exclusions)
    static_points = d["q"] | {p for placement in d["placements"].values() for p in placement["t"]}
    frontier = [{"point": list(point), "generation": state["point_generation"][point],
                 "candidates": [identity for identity, unused in sorted(state["forward"][point])]}
                for point in state["frontier"]]
    candidates = []
    for identity in sorted(d["placements"]):
        p = d["placements"][identity]
        selected = identity in state["selected"]
        capacity_conflicts = [list(point) for point, units in sorted(p["t"].items())
                              if state["totals"].get(point, 0) + units > d["capacity"]]
        marking_conflicts = [list(slot) for slot, value in sorted(p["m"].items())
                             if slot in state["marks"] and state["marks"][slot][0] != value]
        candidates.append({"id": identity, "selected": selected, "excluded": identity in exclusions,
                           "legal": not selected and not capacity_conflicts and not marking_conflicts,
                           "active": identity in state["reverse"],
                           "capacity_conflicts": capacity_conflicts,
                           "marking_conflicts": marking_conflicts})
    expected = {
        "schema": "GCTS-finite-point-snapshot-v1", "selected": state["selected"],
        "excluded": [{"id": identity, "reason": exclusions[identity]} for identity in sorted(exclusions)],
        "totals": [[*point, state["totals"].get(point, 0)] for point in sorted(static_points)],
        "markings": [[*slot, value, refs] for slot, (value, refs) in sorted(state["marks"].items())],
        "point_generations": [[*point, generation] for point, generation in sorted(state["point_generation"].items())],
        "tile_generations": [[identity, state["tile_generation"][identity]] for identity in state["selected"]],
        "frontier": frontier, "candidate_rows": candidates,
        "active_candidates": sorted(state["reverse"]),
        "forward_incidence": [[*point, identity, units] for point in state["frontier"]
                              for identity, units in sorted(state["forward"][point])],
        "reverse_incidence": [{"id": identity, "points": [[*point, units] for point, units in state["reverse"][identity]]}
                              for identity in sorted(state["reverse"])],
        "trail_size": snapshot["trail_size"]}
    _same(snapshot, expected, "snapshot")
    return {"complete": True, "selected": len(state["selected"]), "frontier": len(frontier),
            "active_candidates": len(state["reverse"]), "edges": len(expected["forward_incidence"]),
            "decision": reference_decision(frontier)}


def verify_dependencies(model, dependencies):
    d = _decode(model)
    t_index = {}
    m_index = {}
    for identity, p in d["placements"].items():
        for point in p["t"]:
            t_index.setdefault(point, []).append(identity)
        for slot in p["m"]:
            m_index.setdefault(slot, []).append(identity)
    expected = {
        "t": [{"point": list(point), "placements": sorted(ids)} for point, ids in sorted(t_index.items())],
        "m": [{"point": list(slot[:2]), "channel": slot[2], "placements": sorted(ids)}
              for slot, ids in sorted(m_index.items())]}
    _same(dependencies, expected, "dependencies")
    return {"t_points": len(t_index), "m_slots": len(m_index), "complete": True}


def verify_metrics(metrics, snapshot, previous=None):
    counters = ("attempts", "accepted_base_placements", "seed_placements", "forced_placements",
                "branch_decisions", "backtracks", "max_frontier_points", "max_active_candidates", "max_edges")
    finals = ("final_frontier_points", "final_active_candidates", "final_edges")
    _keys(metrics, (*counters, "candidate_removals", *finals), "metrics")
    for key in (*counters, *finals):
        _need(type(metrics[key]) is int and metrics[key] >= 0, "nonnegative metric " + key)
    reasons = ("SELECTED", "EXCLUDED", "CAPACITY", "MARKING", "NO_FRONTIER")
    _keys(metrics["candidate_removals"], reasons, "removal reasons")
    for key in reasons:
        _need(type(metrics["candidate_removals"][key]) is int and metrics["candidate_removals"][key] >= 0,
              "removal count")
    _need(metrics["attempts"] >= metrics["accepted_base_placements"] >= metrics["seed_placements"],
          "accepted/attempt counts")
    _need(metrics["forced_placements"] <= metrics["accepted_base_placements"] - metrics["seed_placements"],
          "forced count")
    sizes = (len(snapshot["frontier"]), len(snapshot["active_candidates"]), len(snapshot["forward_incidence"]))
    for key, size in zip(finals, sizes):
        _need(metrics[key] == size, "current graph size")
    for key, size in zip(("max_frontier_points", "max_active_candidates", "max_edges"), sizes):
        _need(metrics[key] >= size, "graph maximum")
    if previous is not None:
        for key in counters:
            _need(metrics[key] >= previous[key], "cumulative metric rollback")
        for key in reasons:
            _need(metrics["candidate_removals"][key] >= previous["candidate_removals"][key],
                  "cumulative removal rollback")
    return {"typed": True, "graph_sizes": list(sizes), "cumulative": previous is not None}


def verify_contextual_exclusions(snapshot, solutions):
    """Tiny-domain soundness check for search-generated, not manual, exclusions."""
    selected = set(snapshot["selected"])
    excluded = {row["id"] for row in snapshot["excluded"]}
    for identity in excluded:
        other = excluded - {identity}
        _need(not any(selected | {identity} <= set(solution) and not (other & set(solution))
                      for solution in solutions), "search excluded an exact contextual completion")
    return {"checked": len(excluded), "scope": "CURRENT_SELECTED_AND_OTHER_CONTEXTUAL_EXCLUSIONS"}


def verify_solve_result(model, result, entry, final, exhaustive, expected_unknown=False):
    _keys(result, ("schema", "status", "reason", "nodes", "selected", "context", "model",
                   "solution_verified", "metrics"), "solve result")
    _same(result["schema"], "GCTS-finite-point-solve-result-v1", "solve schema")
    _same(result["model"], canonical_model(model), "solve model")
    _same(result["context"], {"selected": entry["selected"], "excluded": entry["excluded"]}, "entry context")
    _need(type(result["nodes"]) is int and result["nodes"] >= 0, "node count")
    _need(type(result["solution_verified"]) is bool, "solution flag")
    entry_selected = set(entry["selected"])
    entry_excluded = {row["id"] for row in entry["excluded"]}
    contextual_solutions = [solution for solution in exhaustive["solutions"]
                            if entry_selected <= set(solution) and not entry_excluded & set(solution)]
    status = result["status"]
    _need(status in ("FINITE_EXACT_SOLUTION", "EXHAUSTED_FINITE_SEARCH", "UNKNOWN"), "solve status")
    if status == "FINITE_EXACT_SOLUTION":
        _need(not expected_unknown and result["reason"] == "SOLUTION" and result["solution_verified"],
              "solution reason")
        verification = verify_solution(model, result["selected"])
        returned = set(result["selected"])
        _need(entry_selected <= returned, "solution drops entry selection")
        _need(not entry_excluded & returned, "solution uses entry exclusion")
        _same(result["selected"][:len(entry["selected"])], entry["selected"],
              "solution entry selection prefix")
        retained_entry_exclusions = [row for row in final["excluded"] if row["id"] in entry_excluded]
        _same(retained_entry_exclusions, entry["excluded"], "retained exact entry exclusions")
        _need(verification["selected"] in contextual_solutions, "solution not in contextual exhaustive set")
        _same(result["selected"], final["selected"], "retained solution state")
    else:
        _same(final, entry, "restored complete semantic state")
        _same(result["selected"], entry["selected"], "restored selected IDs")
        _need(not result["solution_verified"], "no solution flag on failure")
        if status == "UNKNOWN":
            _need(result["reason"] in ("NODE_LIMIT", "EXTERNAL_BUDGET"), "unknown reason")
        else:
            _need(not expected_unknown and result["reason"] == "EXHAUSTED" and
                  not contextual_solutions, "false finite exhaustion")
    if expected_unknown:
        _need(status == "UNKNOWN", "bounded refusal must stay unknown")
    elif contextual_solutions:
        _need(status == "FINITE_EXACT_SOLUTION", "missed tiny exact solution")
    else:
        _need(status == "EXHAUSTED_FINITE_SEARCH", "unresolved ordinary tiny control")
    verify_metrics(result["metrics"], final)
    return {"complete": True, "status": status, "exact_solution_count": len(contextual_solutions)}


def _wang_data(palette, region, boundary):
    _need(type(palette) is list and type(region) is list, "Wang lists")
    types = {}
    for row in palette:
        _keys(row, ("id", "N", "E", "S", "W"), "Wang palette")
        identity = _string(row["id"], "Wang id")
        _need(identity not in types, "duplicate Wang id")
        for direction in ("N", "E", "S", "W"):
            _string(row[direction], "Wang color")
        types[identity] = dict(row)
    cells = [_point(point, "Wang region") for point in region]
    _need(len(set(cells)) == len(cells), "duplicate Wang region cell")
    directions = {"N": (0, -1), "E": (1, 0), "S": (0, 1), "W": (-1, 0)}
    fixed = {}
    _need(boundary is None or type(boundary) is list, "Wang boundary list or None")
    for row in boundary if boundary is not None else []:
        _need(type(row) is list and len(row) == 4, "Wang boundary row")
        cell = (_integer(row[0], "boundary x"), _integer(row[1], "boundary y"))
        direction = _string(row[2], "boundary direction")
        color = _string(row[3], "boundary color")
        _need(cell in cells and direction in directions, "boundary cell/direction")
        dx, dy = directions[direction]
        _need((cell[0] + dx, cell[1] + dy) not in cells, "nonexposed boundary")
        edge = (*cell, direction)
        _need(edge not in fixed, "duplicate boundary edge")
        fixed[edge] = color
    return types, sorted(cells), directions, fixed


def validate_wang(palette, region, boundary):
    types, cells, unused_directions, fixed = _wang_data(palette, region, boundary)
    return {"palette": len(types), "region": len(cells), "fixed_edges": len(fixed)}


def _compact(value):
    return json.dumps(value, ensure_ascii=True, separators=(",", ":"))


def verify_wang_compilation(palette, region, boundary, model):
    """Independently rebuild every literal anchor/midpoint/collar record."""
    types, cells, directions, fixed = _wang_data(palette, region, boundary)
    records = []
    required = [[2 * x, 2 * y] for x, y in cells]
    for x, y in cells:
        for identity in sorted(types):
            row = types[identity]
            records.append({"id": _compact(["WANG", identity, x, y]),
                            "type": _compact(["WANG", identity]), "translation": [2 * x, 2 * y],
                            "t": [[2 * x, 2 * y, 1]],
                            "m": [[2 * x + dx, 2 * y + dy, "WANG", row[direction]]
                                  for direction, (dx, dy) in directions.items()]})
    collar = {}
    for (x, y, direction), color in fixed.items():
        dx, dy = directions[direction]
        collar.setdefault((x + dx, y + dy), []).append([-dx, -dy, color])
    expected_seed_ids = []
    multiple_inward = 0
    for (x, y), pattern in sorted(collar.items()):
        pattern.sort()
        multiple_inward += int(len(pattern) > 1)
        identity = _compact(["COLLAR", x, y])
        expected_seed_ids.append(identity)
        required.append([2 * x, 2 * y])
        records.append({"id": identity, "type": _compact(["COLLAR", pattern]),
                        "translation": [2 * x, 2 * y], "t": [[2 * x, 2 * y, 1]],
                        "m": [[2 * x + dx, 2 * y + dy, "WANG", color] for dx, dy, color in pattern]})
    _need(type(model) is dict, "Wang model object")
    _same(model.get("seeds"), expected_seed_ids, "complete coordinate-ordered collar seeds")
    expected = canonical_model({"schema": MODEL_SCHEMA, "capacity": 1,
                                "required": required, "placements": records,
                                "seeds": expected_seed_ids})
    _same(model, expected, "Wang compiled model")
    return {"exact": True, "ordinary": len(types) * len(cells), "collar_seeds": len(collar),
            "multiple_inward_seeds": multiple_inward,
            "seed_order_scope": "EXACT_LEXICOGRAPHIC_EXTERIOR_COORDINATE_ORDER"}


def _check_wang_assignment(types, cells, directions, fixed, assignment):
    opposite = {"N": "S", "E": "W", "S": "N", "W": "E"}
    _need(set(assignment) == set(cells), "Wang full cell assignment")
    for cell, identity in assignment.items():
        _need(identity in types, "Wang unknown palette label")
        for direction, (dx, dy) in directions.items():
            neighbor = (cell[0] + dx, cell[1] + dy)
            if neighbor in assignment:
                _need(types[identity][direction] == types[assignment[neighbor]][opposite[direction]],
                      "Wang interior color")
            edge = (*cell, direction)
            if edge in fixed:
                _need(types[identity][direction] == fixed[edge], "Wang fixed boundary color")
    return [{"point": list(point), "type": assignment[point]} for point in sorted(assignment)]


def verify_wang_solution(palette, region, boundary, model, selected_ids):
    verify_wang_compilation(palette, region, boundary, model)
    point_check = verify_solution(model, selected_ids)
    types, cells, directions, fixed = _wang_data(palette, region, boundary)
    assignment = {}
    seeds = set(model["seeds"])
    for identity in selected_ids:
        if identity in seeds:
            continue
        record = json.loads(identity)
        _need(type(record) is list and len(record) == 4 and record[0] == "WANG" and
              type(record[1]) is str and type(record[2]) is int and type(record[3]) is int,
              "Wang inverse identity")
        point = (record[2], record[3])
        _need(point not in assignment, "duplicate Wang cell")
        assignment[point] = record[1]
    return {"point_check": point_check,
            "assignment": _check_wang_assignment(types, cells, directions, fixed, assignment)}


def exhaustive_wang_solutions(palette, region, boundary, maximum_cells=10, budget=None):
    """A second independent enumeration over original Wang labels, not points."""
    types, cells, directions, fixed = _wang_data(palette, region, boundary)
    _need(type(maximum_cells) is int and len(cells) <= maximum_cells,
          "Wang independent enumeration size")
    count = len(types) ** len(cells)
    _need(count <= 4096, "Wang independent assignment cap")
    solutions = []
    examined = 0
    for labels in product(sorted(types), repeat=len(cells)):
        if budget is not None:
            budget()
        examined += 1
        try:
            assignment = _check_wang_assignment(types, cells, directions, fixed, dict(zip(cells, labels)))
        except IndependentError:
            continue
        solutions.append(assignment)
    return {"solutions": solutions, "assignments_examined": examined, "complete": True}


# Supplied-table append-only extension. The complete inherited prefix above is
# byte-identical, including VERSION, imports, globals and all point/Wang helpers.
TABLEAU_VERSION = "GCTS-FINITE-TABLEAU-INDEPENDENT-v1"


class tableau_Error(IndependentError):
    """Exact sole-message validation code for independent tableau checks."""


def tableau_require(condition, code):
    if not condition:
        raise tableau_Error(code)


def tableau_equal(actual, expected):
    """Recursively type-exact structure; dictionary ordering is immaterial."""
    if type(actual) is not type(expected):
        return False
    if type(expected) is dict:
        return (all(type(key) is str for key in actual) and set(actual) == set(expected)
                and all(tableau_equal(actual[key], expected[key]) for key in expected))
    if type(expected) is list:
        return len(actual) == len(expected) and all(tableau_equal(a, b) for a, b in zip(actual, expected))
    return actual == expected


def tableau_normalize_spec(spec):
    """Validate raw data in the public first-error order; no compiler use."""
    keys = {"schema", "alphabet", "transitions", "width", "steps", "initial", "final"}
    tableau_require(type(spec) is dict and all(type(key) is str for key in spec)
                    and set(spec) == keys and type(spec.get("schema")) is str
                    and spec["schema"] == "GCTS-supplied-local-table-spec-v1", "SPEC_SCHEMA")
    alphabet = ["#", "0", "1"]
    tableau_require(type(spec["alphabet"]) is list and
                    all(type(symbol) is str for symbol in spec["alphabet"]) and
                    spec["alphabet"] == alphabet, "SPEC_ALPHABET")
    rows = spec["transitions"]
    tableau_require(type(rows) is list and len(rows) == 27, "SPEC_TRANSITIONS")
    table = {}
    for row in rows:
        tableau_require(type(row) is list and len(row) == 4 and
                        all(type(symbol) is str and symbol in alphabet for symbol in row),
                        "SPEC_TRANSITIONS")
        triple = tuple(row[:3])
        tableau_require(triple not in table and (row[1] != "#" or row[3] == "#"),
                        "SPEC_TRANSITIONS")
        table[triple] = row[3]
    tableau_require(set(table) == set(product(alphabet, repeat=3)), "SPEC_TRANSITIONS")
    width, steps = spec["width"], spec["steps"]
    tableau_require(type(width) is int and 3 <= width <= 5 and
                    type(steps) is int and 0 <= steps <= 2, "SPEC_DIMENSIONS")
    for name in ("initial", "final"):
        word = spec[name]
        tableau_require(type(word) is list and len(word) == width and
                        all(type(symbol) is str and symbol in alphabet for symbol in word) and
                        word[0] == word[-1] == "#", "SPEC_WORDS")
    normalized = [[a, b, c, table[(a, b, c)]] for a in alphabet for b in alphabet for c in alphabet]
    return {"schema": "GCTS-supplied-local-table-spec-v1", "alphabet": list(alphabet),
            "transitions": normalized, "width": width, "steps": steps,
            "initial": list(spec["initial"]), "final": list(spec["final"])}


def tableau_expected_bundle(spec):
    """Independently construct the entire literal palette, rectangle and collar boundary."""
    normalized = tableau_normalize_spec(spec)
    alphabet = normalized["alphabet"]
    palette = []
    for a, b, c, output in normalized["transitions"]:
        palette.append({"id": "C:" + a + ":" + b + ":" + c,
                        "N": "S:" + b, "E": "P:" + b + ":" + c,
                        "S": "S:" + output, "W": "P:" + a + ":" + b})
    for symbol in alphabet:
        palette.append({"id": "I:" + symbol, "N": "I:" + symbol, "E": "ROW:TOP",
                        "S": "S:" + symbol, "W": "ROW:TOP"})
    for symbol in alphabet:
        palette.append({"id": "O:" + symbol, "N": "S:" + symbol, "E": "ROW:BOT",
                        "S": "O:" + symbol, "W": "ROW:BOT"})
    width, steps = normalized["width"], normalized["steps"]
    region = [[x, y] for y in range(steps + 2) for x in range(width)]
    boundary = [[x, 0, "N", "I:" + normalized["initial"][x]] for x in range(width)]
    boundary.extend([[x, steps + 1, "S", "O:" + normalized["final"][x]] for x in range(width)])
    for y in range(steps + 2):
        lateral = "ROW:TOP" if y == 0 else "ROW:BOT" if y == steps + 1 else "P:#:#"
        boundary.extend([[0, y, "W", lateral], [width - 1, y, "E", lateral]])
    return {"schema": "GCTS-supplied-local-table-tableau-v1", "spec": normalized,
            "palette": palette, "region": region, "boundary": boundary}


def tableau_canonical_bundle(bundle):
    try:
        tableau_require(type(bundle) is dict and all(type(key) is str for key in bundle)
                        and set(bundle) == {"schema", "spec", "palette", "region", "boundary"},
                        "BUNDLE_CANONICAL")
        expected = tableau_expected_bundle(bundle["spec"])
        tableau_require(tableau_equal(bundle, expected), "BUNDLE_CANONICAL")
    except (IndependentError, KeyError, TypeError, ValueError):
        raise tableau_Error("BUNDLE_CANONICAL") from None
    return expected


def tableau_verify_bundle_model(spec, bundle, model):
    expected = tableau_expected_bundle(spec)
    tableau_require(tableau_equal(bundle, expected), "BUNDLE_CANONICAL")
    point = verify_wang_compilation(expected["palette"], expected["region"], expected["boundary"], model)
    width, steps = expected["spec"]["width"], expected["spec"]["steps"]
    ordinary = 33 * width * (steps + 2)
    seeds = 2 * width + 2 * (steps + 2)
    _need(point["ordinary"] == ordinary and point["collar_seeds"] == seeds and
          len(model["placements"]) == ordinary + seeds and
          len(model["required"]) == width * (steps + 2) + seeds,
          "complete tableau point universe census")
    return {"complete": True, "palette_types": 33, "region_cells": width * (steps + 2),
            "ordinary_placements": ordinary, "collar_seeds": seeds,
            "required_points": len(model["required"]), "point_model": point}


def tableau_rows_valid(spec, rows):
    normalized = tableau_normalize_spec(spec)
    width, steps = normalized["width"], normalized["steps"]
    tableau_require(type(rows) is list and len(rows) == steps + 1, "TRACE")
    for word in rows:
        tableau_require(type(word) is list and len(word) == width and
                        all(type(s) is str and s in normalized["alphabet"] for s in word) and
                        word[0] == word[-1] == "#", "TRACE")
    tableau_require(rows[0] == normalized["initial"] and rows[-1] == normalized["final"], "TRACE")
    table = {tuple(row[:3]): row[3] for row in normalized["transitions"]}
    for t in range(steps):
        for x in range(width):
            triple = (rows[t][x - 1] if x else "#", rows[t][x],
                      rows[t][x + 1] if x + 1 < width else "#")
            tableau_require(rows[t + 1][x] == table[triple], "TRACE")
    return True


def tableau_histories(spec, budget=None, history_limit=20000):
    """Full raw guard-fixed history product, never a production recurrence walk."""
    normalized = tableau_normalize_spec(spec)
    width, steps = normalized["width"], normalized["steps"]
    free = [[t, x] for t in range(steps + 1) for x in range(1, width - 1)]
    domain = len(normalized["alphabet"]) ** len(free)
    tableau_require(type(history_limit) is int and 0 <= history_limit <= 20000 and domain <= history_limit,
                    "HISTORY_LIMIT")
    table = {tuple(row[:3]): row[3] for row in normalized["transitions"]}
    rejections = {"INITIAL": 0, "FINAL": 0, "TRANSITION": 0}
    accepted = []
    examined = 0
    callbacks = 0
    for values in product(normalized["alphabet"], repeat=len(free)):
        if examined % 64 == 0 and budget is not None:
            budget()
            callbacks += 1
        rows = [["#"] * width for unused in range(steps + 1)]
        for (t, x), value in zip(free, values):
            rows[t][x] = value
        examined += 1
        if rows[0] != normalized["initial"]:
            rejections["INITIAL"] += 1
            continue
        if rows[-1] != normalized["final"]:
            rejections["FINAL"] += 1
            continue
        valid = True
        for t in range(steps):
            for x in range(width):
                triple = (rows[t][x - 1] if x else "#", rows[t][x],
                          rows[t][x + 1] if x + 1 < width else "#")
                if rows[t + 1][x] != table[triple]:
                    valid = False
                    break
            if not valid:
                break
        if valid:
            accepted.append(rows)
        else:
            rejections["TRANSITION"] += 1
    if budget is not None:
        budget()
        callbacks += 1
    _need(examined == domain and sum(rejections.values()) + len(accepted) == domain,
          "complete raw history partition")
    return {"schema": "GCTS-finite-tableau-independent-histories-v1",
            "domain": {"alphabet": list(normalized["alphabet"]), "guards": "BOTH_ENDPOINTS_FIXED_HASH",
                       "free_positions": free, "declared_history_count": domain},
            "examined": examined, "rejections": rejections, "accepted": accepted,
            "complete": True, "budget_callbacks": callbacks}


def tableau_decode_assignment(bundle, assignment):
    expected = tableau_canonical_bundle(bundle)
    try:
        tableau_require(type(assignment) is list, "ASSIGNMENT")
        width, steps = expected["spec"]["width"], expected["spec"]["steps"]
        allowed = {tile["id"]: tile for tile in expected["palette"]}
        selected = {}
        for row in assignment:
            tableau_require(type(row) is list and len(row) == 3 and
                            type(row[0]) is int and type(row[1]) is int and type(row[2]) is str,
                            "ASSIGNMENT")
            point = (row[0], row[1])
            tableau_require(0 <= point[0] < width and 0 <= point[1] < steps + 2 and
                            point not in selected and row[2] in allowed, "ASSIGNMENT")
            selected[point] = row[2]
        tableau_require(len(selected) == width * (steps + 2), "ASSIGNMENT")
        types, cells, directions, fixed = _wang_data(expected["palette"], expected["region"], expected["boundary"])
        _check_wang_assignment(types, cells, directions, fixed, selected)
        rows = []
        for y in range(steps + 2):
            word = []
            for x in range(width):
                identity = selected[(x, y)]
                tile = allowed[identity]
                if y == 0:
                    tableau_require(identity.startswith("I:"), "ASSIGNMENT")
                    word.append(tile["S"][2:])
                elif y == steps + 1:
                    tableau_require(identity.startswith("O:"), "ASSIGNMENT")
                    word.append(tile["N"][2:])
                else:
                    tableau_require(identity.startswith("C:"), "ASSIGNMENT")
                    word.append(tile["S"][2:])
            if y <= steps:
                rows.append(word)
            else:
                tableau_require(word == rows[-1], "ASSIGNMENT")
        tableau_rows_valid(expected["spec"], rows)
        canonical = [[x, y, selected[(x, y)]] for x, y in expected["region"]]
    except (IndependentError, KeyError, TypeError, ValueError):
        raise tableau_Error("ASSIGNMENT") from None
    return {"schema": "GCTS-supplied-local-table-trace-v1", "rows": rows, "assignment": canonical}


def tableau_trace_assignment(bundle, rows):
    expected = tableau_canonical_bundle(bundle)
    tableau_rows_valid(expected["spec"], rows)
    width, steps = expected["spec"]["width"], expected["spec"]["steps"]
    assignment = []
    for y in range(steps + 2):
        for x in range(width):
            if y == 0:
                identity = "I:" + rows[0][x]
            elif y == steps + 1:
                identity = "O:" + rows[-1][x]
            else:
                previous = rows[y - 1]
                a = previous[x - 1] if x else "#"
                c = previous[x + 1] if x + 1 < width else "#"
                identity = "C:" + a + ":" + previous[x] + ":" + c
            assignment.append([x, y, identity])
    decoded = tableau_decode_assignment(expected, assignment)
    tableau_require(tableau_equal(decoded["rows"], rows), "TRACE")
    return assignment


def tableau_expected_solutions(bundle, model, histories):
    expected = tableau_canonical_bundle(bundle)
    tableau_verify_bundle_model(expected["spec"], expected, model)
    _need(histories["complete"] is True, "complete history evidence required")
    solutions = []
    traces = []
    for rows in histories["accepted"]:
        assignment = tableau_trace_assignment(expected, rows)
        identities = list(model["seeds"]) + [_compact(["WANG", identity, x, y])
                                             for x, y, identity in assignment]
        point = verify_solution(model, identities)
        wang = verify_wang_solution(expected["palette"], expected["region"], expected["boundary"], model, identities)
        inverse = tableau_decode_assignment(expected, assignment)
        traces.append({"rows": [list(word) for word in rows], "assignment": assignment,
                       "selected": identities, "point_check": point, "Wang_check": wang,
                       "trace_inverse": inverse})
        solutions.append(sorted(identities))
    _need(len({tuple(ids) for ids in solutions}) == len(solutions), "trace-to-point bijection identities")
    return {"schema": "GCTS-finite-tableau-independent-solutions-v1", "solutions": sorted(solutions),
            "traces": traces, "complete": True}


def tableau_verify_point_result(spec, bundle, model, selected_ids):
    tableau_verify_bundle_model(spec, bundle, model)
    wang = verify_wang_solution(bundle["palette"], bundle["region"], bundle["boundary"], model, selected_ids)
    assignment = [[row["point"][0], row["point"][1], row["type"]] for row in wang["assignment"]]
    trace = tableau_decode_assignment(bundle, assignment)
    return {"point_Wang": wang, "trace": trace, "assignment_for_production_inverse": assignment}

# Fresh STATE rules; the complete preceding current oracle is immutable.
STATE_VERSION = "GCTS-STATE-PROPAGATION-INDEPENDENT-v1"


class state_Error(IndependentError):
    """Exact caller-specific invalid-data code; never a budget notification."""


def _state_budget(budget):
    if budget is not None and not callable(budget):
        raise TypeError("STATE budget must be None or callable")


def _state_notify(budget):
    if budget is not None:
        budget()


def _state_data(code, function, *arguments):
    # Notifications are deliberately NEVER arguments/callees of this wrapper.
    try:
        return function(*arguments)
    except (IndependentError, tableau_Error) as error:
        raise state_Error(code) from error


def _state_copy(value):
    return json.loads(json.dumps(value, allow_nan=False, separators=(",", ":")))


def _state_project(model):
    result = _state_copy(model)
    for record in result["placements"]:
        record["m"] = [row for row in record["m"] if row[2] != "STATE"]
    return result


def _state_extension(spec, bundle, baseline_model, augmented_model, budget, code):
    """Shared full validator; callback failures stay outside all remapping."""
    _state_notify(budget)
    baseline_check = _state_data(code, tableau_verify_bundle_model,
                                spec, bundle, baseline_model)
    augmented_check = _state_data(code, validate_model, augmented_model)
    expected_bundle = _state_data(code, tableau_expected_bundle, spec)
    table = {tuple(row[:3]): row[3] for row in expected_bundle["spec"]["transitions"]}
    expected = _state_copy(baseline_model)
    added = []
    slots = set()
    for record in expected["placements"]:
        _state_notify(budget)
        identity = json.loads(record["id"])
        new_rows = []
        if identity[0] == "WANG":
            parts = identity[1].split(":")
            x, y = record["translation"]
            if parts[0] == "C":
                a, b, c = parts[1:]
                d = table[(a, b, c)]
                prototypes = [(-2, -1, a), (0, -1, b), (2, -1, c), (0, 1, d)]
            elif parts[0] == "I":
                prototypes = [(0, 1, parts[1])]
            elif parts[0] == "O":
                prototypes = [(0, -1, parts[1])]
            else:
                raise RuntimeError("canonical independent type invariant")
            new_rows = [[x + dx, y + dy, "STATE", value]
                        for dx, dy, value in prototypes]
        for row in sorted(new_rows, key=lambda row: tuple(row[:3])):
            added.append([record["id"], *row])
            slots.add(tuple(row[:3]))
        record["m"] = sorted(record["m"] + new_rows, key=lambda row: tuple(row[:3]))
    _state_data(code, _same, augmented_model, expected, "entire ordered STATE extension")
    # Whole expected equality proves the erasure identity without projecting a
    # selected solution before its actual augmented point check.
    receipt = {"schema": "GCTS-state-extension-check-v1", "complete": True,
               "baseline_check": baseline_check, "augmented_model_check": augmented_check,
               "expected_added_assignments": added,
               "STATE_slots": [list(slot) for slot in sorted(slots)],
               "added_STATE_rows": len(added), "static_STATE_slots": len(slots),
               "erasure_full_identity": True,
               "scope": "ALL_ORDERED_PLACEMENTS_WANG_T_Q_SEEDS_AND_FRESH_LITERAL_STATE"}
    _state_notify(budget)
    return receipt


def state_verify_extension(spec, bundle, baseline_model, augmented_model, budget=None):
    _state_budget(budget)
    return _state_extension(spec, bundle, baseline_model, augmented_model,
                            budget, "STATE_EXTENSION_INVALID")


def state_verify_erasure(spec, bundle, augmented_model, erased_model, budget=None):
    _state_budget(budget)
    _state_notify(budget)
    extension = _state_extension(spec, bundle, erased_model, augmented_model,
                                 budget, "STATE_ERASURE_INVALID")
    projected = _state_project(augmented_model)
    _state_data("STATE_ERASURE_INVALID", _same, erased_model, projected,
                "entire explicit erasure")
    receipt = {"schema": "GCTS-state-erasure-check-v1", "complete": True,
               "extension_check": extension, "erased_model_check": _state_copy(extension["baseline_check"]),
               "whole_erasure_identity": True}
    _state_notify(budget)
    return receipt


def state_verify_full_solution(spec, bundle, baseline_model, augmented_model,
                               selected_ids, budget=None):
    _state_budget(budget)
    _state_notify(budget)
    extension = _state_extension(spec, bundle, baseline_model, augmented_model,
                                 budget, "STATE_SOLUTION_INVALID")
    _state_notify(budget)
    point = _state_data("STATE_SOLUTION_INVALID", verify_solution,
                        augmented_model, selected_ids)
    projected = _state_project(augmented_model)
    _state_data("STATE_SOLUTION_INVALID", _same, projected, baseline_model,
                "full verified solution projection")
    _state_notify(budget)
    baseline = _state_data("STATE_SOLUTION_INVALID", tableau_verify_point_result,
                           spec, bundle, projected, selected_ids)
    receipt = {"schema": "GCTS-state-full-solution-check-v1", "complete": True,
               "extension_check": extension, "augmented_point_check": point,
               "baseline_point_Wang_trace_check": baseline,
               "assignment_for_production_inverse": _state_copy(baseline["assignment_for_production_inverse"]),
               "trace": _state_copy(baseline["trace"]), "whole_erasure_identity": True}
    _state_notify(budget)
    return receipt
