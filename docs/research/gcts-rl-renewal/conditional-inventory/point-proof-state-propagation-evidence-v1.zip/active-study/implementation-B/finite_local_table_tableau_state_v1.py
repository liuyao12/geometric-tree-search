"""Inert supplied-local-table compiler and complete Wang-assignment inverse.

No project import, IO, CLI, cache or top-level scientific work.  Calling these
definitions requires the separate reviewed runtime workflow.  Configuration
time is a tableau coordinate, not point-engine generation or placement order.
"""


VERSION = "GCTS-SUPPLIED-LOCAL-TABLE-TABLEAU-v1"
SPEC_SCHEMA = "GCTS-supplied-local-table-spec-v1"
BUNDLE_SCHEMA = "GCTS-supplied-local-table-tableau-v1"
TRACE_SCHEMA = "GCTS-supplied-local-table-trace-v1"
_ALPHABET = ("#", "0", "1")
_SPEC_KEYS = ("schema", "alphabet", "transitions", "width", "steps", "initial", "final")
_BUNDLE_KEYS = ("schema", "spec", "palette", "region", "boundary")


class TableauError(ValueError):
    """A rejected input; raised with one exact public error-code string."""


def _need(condition, code):
    if not condition:
        raise TableauError(code)


def _keys(value, expected):
    return (type(value) is dict and len(value) == len(expected)
            and all(type(key) is str for key in value)
            and set(value) == set(expected))


def _same_exact(actual, expected):
    """Mapping order is immaterial; value/container types and list order are not."""
    if type(actual) is not type(expected):
        return False
    if type(expected) is dict:
        return (_keys(actual, tuple(expected))
                and all(_same_exact(actual[key], expected[key]) for key in expected))
    if type(expected) is list:
        return (len(actual) == len(expected)
                and all(_same_exact(a, b) for a, b in zip(actual, expected)))
    return actual == expected


def _normalize_spec(spec):
    """Validate in the fixed public precedence and detach every mutable value."""
    _need(_keys(spec, _SPEC_KEYS), "SPEC_SCHEMA")
    _need(type(spec["schema"]) is str and spec["schema"] == SPEC_SCHEMA, "SPEC_SCHEMA")
    alphabet = spec["alphabet"]
    _need(type(alphabet) is list and len(alphabet) == 3
          and all(type(s) is str for s in alphabet)
          and alphabet == list(_ALPHABET), "SPEC_ALPHABET")
    transitions = spec["transitions"]
    _need(type(transitions) is list and len(transitions) == 27, "SPEC_TRANSITIONS")
    rule = {}
    for row in transitions:
        _need(type(row) is list and len(row) == 4
              and all(type(s) is str and s in _ALPHABET for s in row), "SPEC_TRANSITIONS")
        triple = tuple(row[:3])
        _need(triple not in rule, "SPEC_TRANSITIONS")
        _need(row[1] != "#" or row[3] == "#", "SPEC_TRANSITIONS")
        rule[triple] = row[3]
    # Twenty-seven distinct triples from a three-symbol cube exhaust that cube.
    canonical_transitions = [[a, b, c, rule[(a, b, c)]]
                             for a in _ALPHABET for b in _ALPHABET for c in _ALPHABET]
    width, steps = spec["width"], spec["steps"]
    _need(type(width) is int and 3 <= width <= 5
          and type(steps) is int and 0 <= steps <= 2, "SPEC_DIMENSIONS")
    for key in ("initial", "final"):
        word = spec[key]
        _need(type(word) is list and len(word) == width
              and all(type(s) is str and s in _ALPHABET for s in word)
              and word[0] == word[-1] == "#", "SPEC_WORDS")
    return {"schema": SPEC_SCHEMA, "alphabet": list(_ALPHABET),
            "transitions": canonical_transitions, "width": width, "steps": steps,
            "initial": list(spec["initial"]), "final": list(spec["final"])}


def _state(symbol):
    return "S:" + symbol


def _pair(left, right):
    return "P:" + left + ":" + right


def _computation_id(left, center, right):
    return "C:" + left + ":" + center + ":" + right


def _compile_normalized(spec):
    """Build the entire canonical palette and rectangle, without a shortlist."""
    palette = []
    for left, center, right, output in spec["transitions"]:
        palette.append({"id": _computation_id(left, center, right),
                        "N": _state(center), "E": _pair(center, right),
                        "S": _state(output), "W": _pair(left, center)})
    for symbol in _ALPHABET:
        palette.append({"id": "I:" + symbol, "N": "I:" + symbol,
                        "E": "ROW:TOP", "S": _state(symbol), "W": "ROW:TOP"})
    for symbol in _ALPHABET:
        palette.append({"id": "O:" + symbol, "N": _state(symbol),
                        "E": "ROW:BOT", "S": "O:" + symbol, "W": "ROW:BOT"})
    width, last = spec["width"], spec["steps"] + 1
    region = [[i, j] for j in range(last + 1) for i in range(width)]
    boundary = [[i, 0, "N", "I:" + spec["initial"][i]] for i in range(width)]
    boundary.extend([[i, last, "S", "O:" + spec["final"][i]] for i in range(width)])
    for j in range(last + 1):
        lateral = "ROW:TOP" if j == 0 else "ROW:BOT" if j == last else "P:#:#"
        boundary.append([0, j, "W", lateral])
        boundary.append([width - 1, j, "E", lateral])
    return {"schema": BUNDLE_SCHEMA, "spec": spec, "palette": palette,
            "region": region, "boundary": boundary}


def compile_tableau(spec):
    """Return detached canonical data; a wellformed impossible boundary compiles."""
    return _compile_normalized(_normalize_spec(spec))


def _canonical_bundle(bundle):
    """Map every malformed or noncanonical bundle to the single public code."""
    try:
        _need(_keys(bundle, _BUNDLE_KEYS), "BUNDLE_CANONICAL")
        _need(type(bundle["schema"]) is str and bundle["schema"] == BUNDLE_SCHEMA,
              "BUNDLE_CANONICAL")
        expected = _compile_normalized(_normalize_spec(bundle["spec"]))
    except TableauError:
        raise TableauError("BUNDLE_CANONICAL") from None
    _need(_same_exact(bundle, expected), "BUNDLE_CANONICAL")
    return expected


def _assignment_grid(assignment, palette, region, width, last):
    """Admit exactly one typed labeled placement per declared cell."""
    _need(type(assignment) is list and len(assignment) == len(region), "ASSIGNMENT")
    grid = {}
    for row in assignment:
        _need(type(row) is list and len(row) == 3, "ASSIGNMENT")
        x, y, identity = row
        _need(type(x) is int and type(y) is int and type(identity) is str,
              "ASSIGNMENT")
        _need(0 <= x < width and 0 <= y <= last and identity in palette,
              "ASSIGNMENT")
        _need((x, y) not in grid, "ASSIGNMENT")
        grid[(x, y)] = identity
    _need(set(grid) == {tuple(point) for point in region}, "ASSIGNMENT")
    return grid


def _check_colors(grid, palette, boundary, width, last):
    """Check every adjacency once and every exposed color explicitly."""
    for y in range(last + 1):
        for x in range(width):
            tile = palette[grid[(x, y)]]
            if x + 1 < width:
                _need(tile["E"] == palette[grid[(x + 1, y)]]["W"], "ASSIGNMENT")
            if y + 1 <= last:
                _need(tile["S"] == palette[grid[(x, y + 1)]]["N"], "ASSIGNMENT")
    for x, y, direction, color in boundary:
        _need(palette[grid[(x, y)]][direction] == color, "ASSIGNMENT")


def decode_tableau(bundle, assignment):
    """Validate the entire canonical Wang assignment and recover all time rows.

    This production inverse uses its own compiler reconstruction.  It is not
    the independent raw point/Wang/history qualification oracle.
    """
    canonical = _canonical_bundle(bundle)
    spec = canonical["spec"]
    width, steps, last = spec["width"], spec["steps"], spec["steps"] + 1
    palette = {row["id"]: row for row in canonical["palette"]}
    grid = _assignment_grid(assignment, palette, canonical["region"], width, last)
    triples = {_computation_id(a, b, c): (a, b, c) for a, b, c, unused in spec["transitions"]}
    rule = {(a, b, c): output for a, b, c, output in spec["transitions"]}
    input_caps = {"I:" + s: s for s in _ALPHABET}
    output_caps = {"O:" + s: s for s in _ALPHABET}
    for x, y in canonical["region"]:
        allowed = input_caps if y == 0 else output_caps if y == last else triples
        _need(grid[(x, y)] in allowed, "ASSIGNMENT")
    _check_colors(grid, palette, canonical["boundary"], width, last)
    rows = [[input_caps[grid[(x, 0)]] for x in range(width)]]
    _need(rows[0] == spec["initial"], "ASSIGNMENT")
    for t in range(steps):
        row_triples = [triples[grid[(x, t + 1)]] for x in range(width)]
        centers = [triple[1] for triple in row_triples]
        _need(centers == rows[-1] and centers[0] == centers[-1] == "#", "ASSIGNMENT")
        next_row = []
        for x, (left, center, right) in enumerate(row_triples):
            expected_left = "#" if x == 0 else centers[x - 1]
            expected_right = "#" if x + 1 == width else centers[x + 1]
            _need(left == expected_left and right == expected_right, "ASSIGNMENT")
            output = rule[(left, center, right)]
            tile = palette[grid[(x, t + 1)]]
            _need(tile["N"] == _state(center) and tile["S"] == _state(output), "ASSIGNMENT")
            next_row.append(output)
        _need(next_row[0] == next_row[-1] == "#", "ASSIGNMENT")
        rows.append(next_row)
    final_word = [output_caps[grid[(x, last)]] for x in range(width)]
    _need(rows[-1] == final_word == spec["final"], "ASSIGNMENT")
    return {"schema": TRACE_SCHEMA, "rows": rows,
            "assignment": [[x, y, grid[(x, y)]] for x, y in canonical["region"]]}


# Fresh STATE-channel construction; inherited compiler above remains exact.
import json as _state_json


STATE_VERSION = "GCTS-SUPPLIED-LOCAL-TABLE-STATE-v1"


class StateMarkingError(ValueError):
    """New API rejection with exactly one public code string."""


def _state_need(condition, code):
    if not condition:
        raise StateMarkingError(code)


def _state_bundle(bundle):
    """Validate the whole inherited canonical bundle before model intake."""
    try:
        return _canonical_bundle(bundle)
    except TableauError:
        raise StateMarkingError("STATE_BUNDLE_CANONICAL") from None


def _state_point(value):
    _state_need(type(value) is list and len(value) == 2
                and all(type(v) is int for v in value), "STATE_MODEL_SHAPE")
    return tuple(value)


def _state_model_shape(model):
    """Exact types and unique slots, deliberately without canonical ordering."""
    code = "STATE_MODEL_SHAPE"
    _state_need(_keys(model, ("schema", "capacity", "required", "placements", "seeds")), code)
    _state_need(type(model["schema"]) is str
                and model["schema"] == "GCTS-finite-point-instance-v1", code)
    capacity = model["capacity"]
    _state_need(type(capacity) is int and capacity > 0, code)
    _state_need(type(model["required"]) is list, code)
    required = set()
    for row in model["required"]:
        point = _state_point(row)
        _state_need(point not in required, code)
        required.add(point)
    _state_need(type(model["placements"]) is list, code)
    identities = set()
    for placement in model["placements"]:
        _state_need(_keys(placement, ("id", "type", "translation", "t", "m")), code)
        identity = placement["id"]
        _state_need(type(identity) is str and identity not in identities, code)
        identities.add(identity)
        _state_need(type(placement["type"]) is str, code)
        _state_point(placement["translation"])
        _state_need(type(placement["t"]) is list and len(placement["t"]) > 0, code)
        positive_points = set()
        for row in placement["t"]:
            _state_need(type(row) is list and len(row) == 3
                        and all(type(v) is int for v in row), code)
            point = (row[0], row[1])
            _state_need(point not in positive_points and 0 < row[2] <= capacity, code)
            positive_points.add(point)
        _state_need(type(placement["m"]) is list, code)
        marking_slots = set()
        for row in placement["m"]:
            _state_need(type(row) is list and len(row) == 4
                        and type(row[0]) is int and type(row[1]) is int
                        and type(row[2]) is str and type(row[3]) is str, code)
            slot = (row[0], row[1], row[2])
            _state_need(slot not in marking_slots, code)
            marking_slots.add(slot)
    _state_need(type(model["seeds"]) is list, code)
    seeds = set()
    for identity in model["seeds"]:
        _state_need(type(identity) is str and identity in identities and identity not in seeds, code)
        seeds.add(identity)


def _state_compact(value):
    return _state_json.dumps(value, ensure_ascii=True, separators=(",", ":"), allow_nan=False)


def _state_copy(value):
    """Detach every occurrence of a mutable container in private expected data."""
    if type(value) is dict:
        return {key: _state_copy(child) for key, child in value.items()}
    if type(value) is list:
        return [_state_copy(child) for child in value]
    return value


def _state_baseline_model(canonical):
    """Rebuild the complete canonical Wang point inventory without the engine."""
    palette = {row["id"]: row for row in canonical["palette"]}
    directions = {"N": (0, -1), "E": (1, 0), "S": (0, 1), "W": (-1, 0)}
    required = {(2 * x, 2 * y) for x, y in canonical["region"]}
    placements = []
    for x, y in canonical["region"]:
        for identity in sorted(palette):
            tile = palette[identity]
            markings = [[2 * x + dx, 2 * y + dy, "WANG", tile[direction]]
                        for direction, (dx, dy) in directions.items()]
            markings.sort(key=lambda row: (row[0], row[1], row[2]))
            placements.append({"id": _state_compact(["WANG", identity, x, y]),
                               "type": _state_compact(["WANG", identity]),
                               "translation": [2 * x, 2 * y],
                               "t": [[2 * x, 2 * y, 1]], "m": markings})
    collar = {}
    for x, y, direction, color in canonical["boundary"]:
        dx, dy = directions[direction]
        collar.setdefault((x + dx, y + dy), {})[(-dx, -dy)] = color
    seeds = []
    for x, y in sorted(collar):
        pattern = [[dx, dy, color] for (dx, dy), color in sorted(collar[(x, y)].items())]
        identity = _state_compact(["COLLAR", x, y])
        seeds.append(identity)
        required.add((2 * x, 2 * y))
        markings = [[2 * x + dx, 2 * y + dy, "WANG", color] for dx, dy, color in pattern]
        markings.sort(key=lambda row: (row[0], row[1], row[2]))
        placements.append({"id": identity, "type": _state_compact(["COLLAR", pattern]),
                           "translation": [2 * x, 2 * y],
                           "t": [[2 * x, 2 * y, 1]], "m": markings})
    return {"schema": "GCTS-finite-point-instance-v1", "capacity": 1,
            "required": [[x, y] for x, y in sorted(required)],
            "placements": sorted(placements, key=lambda row: row["id"]), "seeds": seeds}


def _state_augmented_model(canonical, baseline):
    """Decorate every ordinary type at every cell, retaining all original data."""
    prototypes = {}
    for left, center, right, output in canonical["spec"]["transitions"]:
        identity = _computation_id(left, center, right)
        prototypes[_state_compact(["WANG", identity])] = (
            (-2, -1, left), (0, -1, center), (2, -1, right), (0, 1, output))
    for symbol in _ALPHABET:
        prototypes[_state_compact(["WANG", "I:" + symbol])] = ((0, 1, symbol),)
        prototypes[_state_compact(["WANG", "O:" + symbol])] = ((0, -1, symbol),)
    result = _state_copy(baseline)
    seeds = set(baseline["seeds"])
    for placement in result["placements"]:
        if placement["id"] in seeds:
            continue
        x, y = placement["translation"]
        placement["m"].extend([[x + dx, y + dy, "STATE", value]
                               for dx, dy, value in prototypes[placement["type"]]])
        placement["m"].sort(key=lambda row: (row[0], row[1], row[2]))
    return result


def state_augment_model(bundle, canonical_baseline_model):
    """Canonical bundle, shape, freshness, then complete baseline association."""
    canonical = _state_bundle(bundle)
    _state_model_shape(canonical_baseline_model)
    _state_need(not any(row[2] == "STATE" for placement in canonical_baseline_model["placements"]
                        for row in placement["m"]), "STATE_NOT_FRESH")
    baseline = _state_baseline_model(canonical)
    _state_need(_same_exact(canonical_baseline_model, baseline), "STATE_BASELINE_CANONICAL")
    return _state_augmented_model(canonical, baseline)


def state_erase_model(bundle, canonical_augmented_model):
    """Validate the entire exact augmentation before returning its baseline."""
    canonical = _state_bundle(bundle)
    _state_model_shape(canonical_augmented_model)
    baseline = _state_baseline_model(canonical)
    augmented = _state_augmented_model(canonical, baseline)
    _state_need(_same_exact(canonical_augmented_model, augmented), "STATE_AUGMENTED_CANONICAL")
    return baseline
