"""Administrative joins of one closed saved case; no project imports or replay."""
import collections
import datetime
import hashlib
import json
from pathlib import Path

R = Path('/private/tmp/gcts-state-propagation-20261027-active-v1/root')
CASE = 'state-propagation-negative-base-v1-case-0'

def pin(p):
    p = Path(p)
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}

def pairs(items):
    out = {}
    for k, v in items:
        assert k not in out
        out[k] = v
    return out

a = json.loads((R / (CASE + '-Root-bounded-whole-actual-intake-authority-v1.json')).read_bytes())
rp = a['exact_current_body_pins']['worker-result.json']
assert pin(rp['path']) == rp
raw = Path(rp['path']).read_bytes()
x = json.loads(raw, object_pairs_hook=pairs, parse_constant=lambda z: (_ for _ in ()).throw(ValueError(z)))
assert raw == (json.dumps(x, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False) + '\n').encode()
census = collections.Counter()

def walk(v):
    census[type(v).__name__] += 1
    if type(v) is dict:
        for k, z in v.items():
            assert type(k) is str
            walk(z)
    elif type(v) is list:
        for z in v:
            walk(z)
    else:
        assert v is None or type(v) in (str, int, float, bool)

walk(x)
assert set(x) == {'schema', 'worker_version', 'case_id', 'case_descriptor', 'status', 'plan', 'sources', 'limits', 'counts', 'costs', 'evidence', 'limitations'}
assert x['case_id'] == CASE and x['sources'] == a['current_Source_pins']
assert x['plan'] == a['exact_current_body_pins']['plan'] and x['status'] == 'COMPLETE_ARM_RESULT'
e = x['evidence']
base, arm = e['baseline_model'], e['arm_model']
assert arm == base and e['extension_check'] is e['erased_model'] is e['erasure_check'] is None
assert set(base) == {'schema','capacity','placements','required','seeds'}
assert len(base['placements']) == 678 and len(base['required']) == 38 and len(base['seeds']) == 18
tdeps, mdeps = collections.defaultdict(list), collections.defaultdict(list)
for v in arm['placements']:
    assert set(v) == {'id','m','t','translation','type'}
    assert all(r[2] == 'WANG' for r in v['m'])
    for r in v['t']:
        tdeps[tuple(r[:2])].append(v['id'])
    for r in v['m']:
        mdeps[tuple(r[:3])].append(v['id'])
sd = e['static_dependencies']
assert {tuple(r['point']): r['placements'] for r in sd['t']} == {k: sorted(set(v)) for k,v in tdeps.items()}
assert {(r['point'][0],r['point'][1],r['channel']): r['placements'] for r in sd['m']} == {k: sorted(set(v)) for k,v in mdeps.items()}
assert len(tdeps) == 38 and len(mdeps) == 49 and sum(len(v['m']) for v in arm['placements']) == 2658
ids = [p['id'] for p in arm['placements']]
assert len(set(ids)) == 678
sk = {'active_candidates', 'candidate_rows', 'excluded', 'forward_incidence', 'frontier', 'markings', 'point_generations', 'reverse_incidence', 'schema', 'selected', 'tile_generations', 'totals', 'trail_size'}
snaps = [e['entry'], e['final'], e['restored']] + [z['snapshot'] for z in e['events']]
for s in snaps:
    assert set(s) == sk and [r['id'] for r in s['candidate_rows']] == ids
    assert [r['id'] for r in s['candidate_rows'] if r['active']] == s['active_candidates']
    assert sorted(r['id'] for r in s['candidate_rows'] if r['selected']) == sorted(s['selected'])
    assert [r['id'] for r in s['candidate_rows'] if r['excluded']] == [r['id'] for r in s['excluded']]
    assert all(set(r) == {'id','reason'} and r['reason'] == 'EXHAUSTED_CHILD' for r in s['excluded'])
    for r in s['candidate_rows']:
        assert set(r) == {'id', 'active', 'capacity_conflicts', 'excluded', 'legal', 'marking_conflicts', 'selected'}
        assert all(type(r[k]) is bool for k in ('active', 'excluded', 'legal', 'selected'))
    fwd = sorted(s['forward_incidence'])
    assert fwd == sorted([[q[0], q[1], r['id'], q[2]] for r in s['reverse_incidence'] for q in r['points']])
    assert fwd == sorted([[r['point'][0], r['point'][1], cid, 1] for r in s['frontier'] for cid in r['candidates']])
    assert len(s['point_generations']) == len(s['totals']) == 38
    assert len(s['tile_generations']) == len(s['selected'])
    assert all(len(r) == 5 and type(r[4]) is int and r[4] > 0 for r in s['markings'])
events = e['events']
assert len(events) == 69
kinds, decisions = collections.Counter(), collections.Counter()
previous = None
for i, z in enumerate(events):
    assert set(z) == {'dependency_check', 'event', 'independent_snapshot', 'metric_check', 'metrics', 'search_exclusion_check', 'snapshot'}
    s, m, ind, et = z['snapshot'], z['metrics'], z['independent_snapshot'], z['event']
    kinds[et['kind']] += 1
    assert z['dependency_check'] == {'complete': True, 'm_slots': 49, 't_points': 38}
    sizes = [len(s['frontier']), len(s['active_candidates']), len(s['forward_incidence'])]
    assert ind['complete'] is True and [ind[k] for k in ('frontier', 'active_candidates', 'edges', 'selected')] == sizes + [len(s['selected'])]
    assert z['metric_check']['typed'] is True and z['metric_check']['graph_sizes'] == sizes
    assert z['search_exclusion_check'] == {'checked': len(s['excluded']), 'scope': 'CURRENT_SELECTED_AND_OTHER_CONTEXTUAL_EXCLUSIONS'}
    assert [m[k] for k in ('final_frontier_points', 'final_active_candidates', 'final_edges')] == sizes
    if previous:
        assert all(m[k] >= previous[k] for k in ('accepted_base_placements', 'attempts', 'backtracks', 'branch_decisions', 'forced_placements', 'max_active_candidates', 'max_edges', 'max_frontier_points'))
    previous = m
    if et['kind'] == 'DECISION':
        assert et['data'] == ind['decision']
        decisions[et['data']['kind']] += 1
    if et['kind'] == 'PLACED':
        assert et['data']['reason'] in ['FORCED','BRANCH'] and et['data']['generation'] == 1
        assert s['selected'] == events[i-1]['snapshot']['selected'] + [et['data']['id']]
assert e['restored'] == e['final'] == e['entry'] == events[-1]['snapshot']
assert e['entry_checkpoint'] == 0 and events[-1]['event']['kind'] == 'SOLVE_RESULT'
sr, m = e['solve_result'], e['solve_result']['metrics']
assert sr['model'] == arm and sr['context'] == {'excluded': [], 'selected': e['entry']['selected']}
assert sr['status'] == 'EXHAUSTED_FINITE_SEARCH' and sr['reason'] == 'EXHAUSTED' and sr['solution_verified'] is False
assert sr['selected'] == e['entry']['selected'] and e['expected_base_solutions']['complete'] is True
assert e['expected_base_solutions']['solutions'] == e['expected_base_solutions']['traces'] == []
assert e['augmented_expected_solution_checks'] == [] and e['production_inverse'] is None and e['whole_solution_check'] is None
assert e['solve_result_check'] == {'complete': True, 'exact_solution_count': 0, 'status': 'EXHAUSTED_FINITE_SEARCH'}
expected = {'accepted_base_placements': 38, 'backtracks': 0, 'branch_decisions': 0, 'forced_placements': 20, 'nodes': 21, 'seed_placements': 18}
assert e['prediction'] == {'applicable': False, 'evaluation': 'NOT_APPLICABLE', 'expected': expected, 'matched': None, 'observed': None}
h = e['histories']
assert h['examined'] == 19683 and h['complete'] is True and h['accepted'] == []
assert e['history_partition'] == {'ACCEPTED': 0, 'FINAL': 702, 'INITIAL': 18954, 'TRANSITION': 27}
assert sum(e['history_partition'].values()) == 19683
assert e['spec']['initial'] == e['spec']['final'] == ['#','1','0','0','#']
c = x['costs']
assert c['phases']['API_controls'] is None and c['phases']['treatment_construction_check'] is None and sum(v is not None for v in c['phases'].values()) == 7
assert sum(v['budget_callbacks'] for v in c['phases'].values() if v is not None) == c['worker_budget_callbacks_before_serialization'] == 519
term = json.loads(Path(a['exact_current_body_pins']['stdout.bin']['path']).read_bytes())
assert term['post_result_readback_costs']['worker_budget_callbacks_before_terminal_encoding'] == 523
assert kinds == {'INITIALIZED':1,'DECISION':31,'PLACED':24,'ROLLED_BACK':6,'EXCLUDED':6,'SOLVE_RESULT':1}
assert decisions == {'FORCED':18,'BRANCH':6,'DEAD':7}
assert sr['nodes'] == 31 and m['forced_placements'] == 18 and m['branch_decisions'] == m['backtracks'] == 6
rollbacks=[]
for i,z in enumerate(events):
    if z['event']['kind'] == 'ROLLED_BACK':
        matches=[j for j in range(i) if events[j]['snapshot'] == z['snapshot']]
        assert matches
        rollbacks.append({'index':i,'checkpoint':z['event']['data']['checkpoint'],'whole13field_prior_event_matches':matches})
    if z['event']['kind'] == 'EXCLUDED':
        assert events[i-1]['event']['kind'] == 'ROLLED_BACK' and z['event']['data']['reason'] == 'EXHAUSTED_CHILD'
        assert z['snapshot']['selected'] == events[i-1]['snapshot']['selected']
        assert z['event']['data']['id'] in [r['id'] for r in z['snapshot']['excluded']]
assert len(rollbacks) == 6
out={'schema':'Root-state-propagation-negative-base-complete-saved-data-relational-audit-v1','issued_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'case_id':CASE,'status':'COMPLETE_CURRENT_SAVED_DATA_RELATIONAL_PASS_PENDING_B_WHOLE_REVIEW','whole_result':rp,'authority':pin(R/(CASE+'-Root-bounded-whole-actual-intake-authority-v1.json')),'all_json_values':dict(census),'total_json_values':sum(census.values()),'whole_baseline_arm_and_returned_model_identity':True,'STATE_assignments':0,'STATE_conditional_fields_null':True,'full_support_dependency_maps':{'t_points':len(tdeps),'m_slots':len(mdeps)},'complete_snapshot_occurrences':len(snaps),'candidate_rows_per_snapshot':678,'candidate_row_occurrences':len(snaps)*678,'all_full_forward_reverse_frontier_incidence_associations':True,'all_event_shapes_saved_reference_decisions_metric_sizes_and_cumulative_fields':True,'event_kinds':dict(kinds),'decision_kinds':dict(decisions),'all6whole13field_rollback_relations':rollbacks,'entire_entry_final_restored13fields_equal':True,'history_partition':e['history_partition'],'negative_conditionals_and_empty_expected_reference':'All correct; no positive full-solution receipt or inverse, emptyreference not general pruning proof','forecast':e['prediction'],'observed_nodes':sr['nodes'],'observed_metrics':m,'counts':x['counts'],'costs':c,'post_full_readback_costs':term['post_result_readback_costs'],'scope':'Complete saved JSON/type/key/equality/association/arithmetic joins only under current-case bounded authority. No project imports/helpers, legality/selector/history/compiler replay or new model. In-actual independent checks are authenticated execution evidence. Root separately handread all69eventpayloads/reference decisions including every failedbranch/six contextual exclusions/sixrollback states; finalSOLVE_RESULT internally restoredentry. No counter forecast or general pruning/speed claim. Wholecase independent B review and Root adoption remain required. Administrative v1 incorrectly treated the nonempty excluded vector as ID strings; actual published snapshot schema is id/reason records, as engine Source lines397 and552 show. A diagnostic set conversion also stopped on dict elements. Corrected only admin joins to record IDs and validated every exact id/reason field; no output artifact or scientific retry from those failures.','scientific_result_admitted_by_this_record':False,'new_scientific_execution_or_future_grant':False}
p=R/(CASE+'-Root-complete-saved-data-relational-audit-v1.json')
with p.open('xb') as f:
    f.write((json.dumps(out,indent=2,sort_keys=True,allow_nan=False)+'\n').encode())
print(json.dumps(pin(p)))
print(json.dumps({'events':dict(kinds),'decisions':dict(decisions),'nodes':sr['nodes'],'all_values':sum(census.values())}))
