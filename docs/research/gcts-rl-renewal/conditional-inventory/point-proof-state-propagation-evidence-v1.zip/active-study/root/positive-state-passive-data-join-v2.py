"""Administrative joins of one closed saved case; no project imports or replay."""
import collections
import datetime
import hashlib
import json
from pathlib import Path

R = Path('/private/tmp/gcts-state-propagation-20261027-active-v1/root')
CASE = 'state-propagation-positive-state-v1-case-0'

def pin(p):
    p = Path(p)
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}

def pairs(items):
    out = {}
    for k, v in items:
        assert k not in out
        out[k] = v
    return out

a = json.loads((R / (CASE + '-Root-bounded-whole-actual-intake-authority-v1.json')).read_bytes())
rp = a['exact_current_body_pins']['worker-result.json']
assert pin(rp['path']) == rp
raw = Path(rp['path']).read_bytes()
x = json.loads(raw, object_pairs_hook=pairs, parse_constant=lambda z: (_ for _ in ()).throw(ValueError(z)))
assert raw == (json.dumps(x, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False) + '\n').encode()
census = collections.Counter()

def walk(v):
    census[type(v).__name__] += 1
    if type(v) is dict:
        for k, z in v.items():
            assert type(k) is str
            walk(z)
    elif type(v) is list:
        for z in v:
            walk(z)
    else:
        assert v is None or type(v) in (str, int, float, bool)

walk(x)
assert set(x) == {'schema', 'worker_version', 'case_id', 'case_descriptor', 'status', 'plan', 'sources', 'limits', 'counts', 'costs', 'evidence', 'limitations'}
assert x['case_id'] == CASE and x['sources'] == a['current_Source_pins']
assert x['plan'] == a['exact_current_body_pins']['plan'] and x['status'] == 'COMPLETE_ARM_RESULT'
e = x['evidence']
base, arm = e['baseline_model'], e['arm_model']
assert e['erased_model'] == base
assert set(base) == set(arm) == {'schema', 'capacity', 'placements', 'required', 'seeds'}
assert all(base[k] == arm[k] for k in ('schema', 'capacity', 'required', 'seeds'))
assert len(base['placements']) == len(arm['placements']) == 678
assert len(base['required']) == 38 and len(base['seeds']) == 18
added, tdeps, mdeps = [], collections.defaultdict(list), collections.defaultdict(list)
for u, v in zip(base['placements'], arm['placements'], strict=True):
    assert set(u) == set(v) == {'id', 'm', 't', 'translation', 'type'}
    assert all(u[k] == v[k] for k in ('id', 't', 'translation', 'type'))
    assert [r for r in v['m'] if r[2] != 'STATE'] == u['m']
    assert not any(r[2] == 'STATE' for r in u['m'])
    sm = [r for r in v['m'] if r[2] == 'STATE']
    added.extend([[v['id'], *r] for r in sm])
    if v['id'] in base['seeds']:
        assert not sm
    for r in v['t']:
        tdeps[tuple(r[:2])].append(v['id'])
    for r in v['m']:
        mdeps[tuple(r[:3])].append(v['id'])
ext = e['extension_check']
assert len(added) == ext['added_STATE_rows'] == 2280
assert sorted(added) == ext['expected_added_assignments']
slots = sorted({tuple(r[1:4]) for r in added})
assert len(slots) == ext['static_STATE_slots'] == 33
assert [list(r) for r in slots] == ext['STATE_slots']
assert ext['complete'] is True and ext['erasure_full_identity'] is True
assert e['erasure_check']['extension_check'] == ext
assert e['erasure_check']['complete'] is True and e['erasure_check']['whole_erasure_identity'] is True
sd = e['static_dependencies']
assert {tuple(r['point']): r['placements'] for r in sd['t']} == {k: sorted(set(v)) for k, v in tdeps.items()}
assert {(r['point'][0], r['point'][1], r['channel']): r['placements'] for r in sd['m']} == {k: sorted(set(v)) for k, v in mdeps.items()}
ids = [p['id'] for p in arm['placements']]
assert len(set(ids)) == 678
sk = {'active_candidates', 'candidate_rows', 'excluded', 'forward_incidence', 'frontier', 'markings', 'point_generations', 'reverse_incidence', 'schema', 'selected', 'tile_generations', 'totals', 'trail_size'}
snaps = [e['entry'], e['final'], e['restored']] + [z['snapshot'] for z in e['events']]
for s in snaps:
    assert set(s) == sk and [r['id'] for r in s['candidate_rows']] == ids
    assert [r['id'] for r in s['candidate_rows'] if r['active']] == s['active_candidates']
    assert sorted(r['id'] for r in s['candidate_rows'] if r['selected']) == sorted(s['selected'])
    assert [r['id'] for r in s['candidate_rows'] if r['excluded']] == s['excluded']
    for r in s['candidate_rows']:
        assert set(r) == {'id', 'active', 'capacity_conflicts', 'excluded', 'legal', 'marking_conflicts', 'selected'}
        assert all(type(r[k]) is bool for k in ('active', 'excluded', 'legal', 'selected'))
    fwd = sorted(s['forward_incidence'])
    assert fwd == sorted([[q[0], q[1], r['id'], q[2]] for r in s['reverse_incidence'] for q in r['points']])
    assert fwd == sorted([[r['point'][0], r['point'][1], cid, 1] for r in s['frontier'] for cid in r['candidates']])
    assert len(s['point_generations']) == len(s['totals']) == 38
    assert len(s['tile_generations']) == len(s['selected'])
    assert all(len(r) == 5 and type(r[4]) is int and r[4] > 0 for r in s['markings'])
events = e['events']
assert len(events) == 44
kinds, decisions = collections.Counter(), collections.Counter()
previous = None
for i, z in enumerate(events):
    assert set(z) == {'dependency_check', 'event', 'independent_snapshot', 'metric_check', 'metrics', 'search_exclusion_check', 'snapshot'}
    s, m, ind, et = z['snapshot'], z['metrics'], z['independent_snapshot'], z['event']
    kinds[et['kind']] += 1
    assert z['dependency_check'] == {'complete': True, 'm_slots': 82, 't_points': 38}
    sizes = [len(s['frontier']), len(s['active_candidates']), len(s['forward_incidence'])]
    assert ind['complete'] is True and [ind[k] for k in ('frontier', 'active_candidates', 'edges', 'selected')] == sizes + [len(s['selected'])]
    assert z['metric_check']['typed'] is True and z['metric_check']['graph_sizes'] == sizes
    assert z['search_exclusion_check'] == {'checked': 0, 'scope': 'CURRENT_SELECTED_AND_OTHER_CONTEXTUAL_EXCLUSIONS'}
    assert [m[k] for k in ('final_frontier_points', 'final_active_candidates', 'final_edges')] == sizes
    if previous:
        assert all(m[k] >= previous[k] for k in ('accepted_base_placements', 'attempts', 'backtracks', 'branch_decisions', 'forced_placements', 'max_active_candidates', 'max_edges', 'max_frontier_points'))
    previous = m
    if et['kind'] == 'DECISION':
        assert et['data'] == ind['decision']
        decisions[et['data']['kind']] += 1
    if et['kind'] == 'PLACED':
        assert et['data']['reason'] == 'FORCED' and et['data']['generation'] == 1
        assert s['selected'] == events[i-1]['snapshot']['selected'] + [et['data']['id']]
assert e['restored'] == e['entry'] == events[-1]['snapshot'] and e['entry_checkpoint'] == 0
assert events[-1]['event'] == {'data': {'checkpoint': 0}, 'kind': 'ROLLED_BACK'}
sr, m = e['solve_result'], e['solve_result']['metrics']
assert sr['model'] == arm and sr['context'] == {'excluded': [], 'selected': e['entry']['selected']}
assert sr['status'] == 'FINITE_EXACT_SOLUTION' and sr['solution_verified'] is True
assert sr['selected'] == e['final']['selected'] and sorted(sr['selected']) == e['expected_base_solutions']['solutions'][0]
observed = {k: m[k] for k in ('accepted_base_placements', 'backtracks', 'branch_decisions', 'forced_placements', 'seed_placements')}
observed['nodes'] = sr['nodes']
expected = {'accepted_base_placements': 38, 'backtracks': 0, 'branch_decisions': 0, 'forced_placements': 20, 'nodes': 21, 'seed_placements': 18}
assert observed == expected
assert e['prediction'] == {'applicable': True, 'evaluation': 'MATCHED', 'expected': expected, 'matched': True, 'observed': observed}
h, w = e['histories'], e['whole_solution_check']
assert h['examined'] == 19683 and h['complete'] is True
assert e['history_partition'] == {'ACCEPTED': 1, 'FINAL': 702, 'INITIAL': 18954, 'TRANSITION': 26}
assert sum(e['history_partition'].values()) == 19683 and h['accepted'] == [e['production_inverse']['rows']]
assert w['extension_check'] == ext and w['complete'] is True and w['whole_erasure_identity'] is True
assert w['trace'] == e['production_inverse'] and w['baseline_point_Wang_trace_check']['trace'] == e['production_inverse']
assert w['augmented_point_check']['exact'] is True and w['augmented_point_check']['mark_slots'] == 68
assert w['augmented_point_check']['selected'] == sorted(sr['selected'])
assert e['augmented_expected_solution_checks'] == [w]
c = x['costs']
assert c['phases']['API_controls'] is None and sum(v is not None for v in c['phases'].values()) == 8
assert sum(v['budget_callbacks'] for v in c['phases'].values() if v is not None) == c['worker_budget_callbacks_before_serialization'] == 3187
term = json.loads(Path(a['exact_current_body_pins']['stdout.bin']['path']).read_bytes())
assert term['post_result_readback_costs']['worker_budget_callbacks_before_terminal_encoding'] == 3191
out = {'schema': 'Root-state-propagation-positive-state-complete-saved-data-relational-audit-v1', 'issued_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'case_id': CASE, 'status': 'COMPLETE_CURRENT_SAVED_DATA_RELATIONAL_PASS_PENDING_B_WHOLE_REVIEW', 'whole_result': rp, 'authority': pin(R / (CASE + '-Root-bounded-whole-actual-intake-authority-v1.json')), 'all_json_values': dict(census), 'total_json_values': sum(census.values()), 'complete_model_erasure_and_inventory_retention': True, 'STATE_added_rows': len(added), 'STATE_static_slots': len(slots), 'full_saved_extension_vector_and_nested_receipt_identity': True, 'full_support_dependency_maps': {'t_points': len(tdeps), 'm_slots': len(mdeps)}, 'complete_snapshot_occurrences': len(snaps), 'candidate_rows_per_snapshot': 678, 'candidate_row_occurrences': len(snaps)*678, 'all_full_forward_reverse_frontier_incidence_associations': True, 'all_event_shapes_saved_reference_decisions_metric_sizes_and_cumulative_fields': True, 'event_kinds': dict(kinds), 'decision_kinds': dict(decisions), 'entire_entry_restored13fields_equal': True, 'whole_augmented_solution_trace_expected_set_production_inverse_receipts_joined': True, 'forecast': e['prediction'], 'history_partition': e['history_partition'], 'counts': x['counts'], 'costs': c, 'post_full_readback_costs': term['post_result_readback_costs'], 'scope': 'Full saved JSON/type/key/equality/association/arithmetic joins under current-case bounded authority. No project imports/helpers, legality/selector/history/compiler replay or new model. In-actual independent checks are authenticated execution evidence. Full44event text handread separately. Initial output of nested receipt was truncated and not treated as complete review; first administrative audit requested nonexistent full_identity instead of published whole_erasure_identity, stopped without artifact, then corrected only that admin field. The first saved admin script used system Python without zip strict support and then a wrong list access to the saved expected-solutions wrapper; both stopped without any output artifact. Corrected only that saved-data access in v2 and used D90. No scientific retry.', 'scientific_result_admitted_by_this_record': False, 'new_scientific_execution_or_future_grant': False}
p = R / (CASE + '-Root-complete-saved-data-relational-audit-v1.json')
with p.open('xb') as f:
    f.write((json.dumps(out, indent=2, sort_keys=True, allow_nan=False) + '\n').encode())
print(json.dumps(pin(p)))
print(json.dumps({'events': dict(kinds), 'decisions': dict(decisions), 'forecast': observed, 'all_values': sum(census.values())}))
