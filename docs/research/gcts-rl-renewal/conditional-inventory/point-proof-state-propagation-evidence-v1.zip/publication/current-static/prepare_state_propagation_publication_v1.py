"""Inert administrative opaque packager; separate reviewed Root once required.

No project imports, scientific JSON parsing, network, subprocess or Git.  All
archive/summary bodies remain opaque. HTML parsing is Source-scaffold only.
"""
import argparse
import hashlib
from html.parser import HTMLParser
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import sys
import zipfile
import zlib

SELF = Path(__file__).resolve()
ROOT = SELF.parent
EXPECTED_SELF = Path("/private/tmp/gcts-state-publication-20261027-v1/root/prepare_state_propagation_publication_v1.py")
ROOT_STAGE = ROOT / "publication-state-propagation-v1"
PUBLISHER_STAGE = Path("/private/tmp/gcts-state-publication-20261027-v1/publisher-payload")
NAMES = ("point-proof-parallel-progress-v1.html", "point-proof-state-propagation-summary-v1.json",
         "point-proof-state-propagation-evidence-v1.zip")
PREFIX = "docs/research/gcts-rl-renewal/conditional-inventory/"
PYTHON = {"path": "/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12",
          "bytes": 18058560, "sha256": "d90bce0f5ac3aa40e2ee5900ad243bad0b2205ce17408278f088b34aed737840"}
BASELINE_BYTES = 191052
BASELINE_SHA256 = "d006ead3521749f50d9fcc841f2ba92c4e22e16b1dea7a0a58391f393b24583a"
BASELINE_BLOB = "ad7f76c7fc7c7e15992cc48bc344b57b12a12661"
ANCHOR = 4300
INSERTION_ID = "state-propagation-current"
ADMIN_CAP = 1048576
SOURCE_CAP = 2097152
BODY_CAP = 67108864
RAW_CAP = 134217728
MAX_MEMBERS = 1000


class Refusal(Exception):
    pass


def require(ok, message):
    if not ok:
        raise Refusal(message)


def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + "\n").encode("utf-8")


def strict_json(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, "duplicate administrative JSON key")
            result[key] = value
        return result
    def nonfinite(unused):
        raise Refusal("nonfinite administrative JSON")
    return json.loads(raw.decode("utf-8"), object_pairs_hook=pairs, parse_constant=nonfinite)


def canonical(value):
    require(type(value) is str and value, "exact absolute path string")
    p = Path(value)
    require(p.is_absolute() and str(p) == value and os.path.normpath(value) == value
            and p.resolve() == p and all(not q.is_symlink() for q in (p, *p.parents)),
            "canonical nonsymlink path required")
    return p


def regular(p):
    canonical(str(p))
    info = p.stat(follow_symlinks=False)
    require(stat.S_ISREG(info.st_mode) and info.st_nlink == 1, "single-link regular input")
    return info


def pin(p, raw):
    return {"path": str(p), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def read(p, cap):
    before = regular(p)
    require(before.st_size <= cap, "input extent cap")
    with p.open("rb") as stream:
        raw = stream.read(cap + 1)
    after = regular(p)
    require(len(raw) == before.st_size == after.st_size and len(raw) <= cap and
            (before.st_dev, before.st_ino, before.st_mtime_ns) ==
            (after.st_dev, after.st_ino, after.st_mtime_ns), "changed/incomplete input")
    return raw


def ref_shape(value, cap):
    require(type(value) is dict and set(value) == {"path", "bytes", "sha256"}, "rawref3")
    require(type(value["bytes"]) is int and 0 <= value["bytes"] <= cap and
            type(value["sha256"]) is str and re.fullmatch(r"[0-9a-f]{64}", value["sha256"]),
            "exact rawref extent/hash")
    p = canonical(value["path"])
    require(regular(p).st_size == value["bytes"], "rawref stat extent")
    return p


def ref_read(value, cap):
    p = ref_shape(value, cap)
    raw = read(p, cap)
    require(pin(p, raw) == value, "whole current rawref mismatch")
    return raw


def write_new(p, raw, cap):
    require(len(raw) <= cap, "output extent cap")
    canonical(str(p))
    fd = os.open(p, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, "wb") as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    require(read(p, cap) == raw, "exclusive output complete readback")
    return pin(p, raw)


def sync_directory(p):
    fd = os.open(p, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def archive_name(value):
    require(type(value) is str and value and "\\" not in value and ":" not in value and
            all(ord(ch) >= 32 and ord(ch) != 127 for ch in value), "safe ZIP name")
    p = PurePosixPath(value)
    require(not p.is_absolute() and p.as_posix() == value and
            all(part not in ("", ".", "..") and not part.startswith(".") for part in value.split("/")) and
            value != "catalogue.json" and not value.lower().endswith(".zip"), "safe unique regular ZIP member")
    return value


def runtime_guard():
    require(SELF == EXPECTED_SELF and sys.platform == "darwin" and sys.implementation.name == "cpython"
            and sys.version_info[:3] == (3, 12, 14) and __debug__ and sys.flags.optimize == 0
            and sys.flags.isolated and sys.flags.no_site and sys.flags.no_user_site
            and sys.flags.ignore_environment and sys.flags.safe_path and sys.dont_write_bytecode
            and Path(sys.executable).resolve() == Path(PYTHON["path"]), "fixed Source/D90 -I -S -B required")
    ref_read(PYTHON, PYTHON["bytes"])


class SourceScaffold(HTMLParser):
    def __init__(self, fragment=False):
        super().__init__(convert_charrefs=True)
        self.fragment = fragment
        self.ids = []
        self.sections = 0
        self.closed_sections = 0
        self.inside = False

    def handle_starttag(self, tag, attrs):
        if self.fragment:
            require(tag not in ("html", "head", "body", "script"), "fragment document shell/script forbidden")
            require(len({key for key, value in attrs}) == len(attrs), "duplicate fragment attribute")
            require(all(not key.lower().startswith("on") for key, value in attrs), "fragment script event forbidden")
            if tag == "section":
                require(self.sections == 0 and not self.inside and dict(attrs).get("id") == INSERTION_ID,
                        "exact one named insertion section")
                self.sections += 1
                self.inside = True
            else:
                require(self.inside, "fragment tag outside insertion section")
        for key, value in attrs:
            if key == "id":
                require(type(value) is str and value and value not in self.ids, "duplicate/empty Source ID")
                self.ids.append(value)

    def handle_startendtag(self, tag, attrs):
        require(not (self.fragment and tag == "section"), "insertion section cannot self-close")
        self.handle_starttag(tag, attrs)

    def handle_endtag(self, tag):
        if self.fragment:
            require(self.inside, "fragment closing tag outside section")
            if tag == "section":
                self.closed_sections += 1
                self.inside = False

    def handle_data(self, data):
        if self.fragment and not self.inside:
            require(not data.strip(), "fragment text outside section")

    def handle_decl(self, decl):
        require(not self.fragment, "fragment document declaration forbidden")

    def handle_pi(self, data):
        require(not self.fragment, "fragment processing instruction forbidden")


def report_bytes(baseline, fragment):
    require(len(baseline) == BASELINE_BYTES and hashlib.sha256(baseline).hexdigest() == BASELINE_SHA256,
            "exact historical baseline identity")
    require(hashlib.sha1(b"blob " + str(len(baseline)).encode() + b"\0" + baseline).hexdigest() == BASELINE_BLOB,
            "historical Git blob identity")
    openings = list(re.finditer(rb"<body(?:\s[^<>]*)?>", baseline, flags=re.IGNORECASE))
    require(len(openings) == 1 and openings[0].end() == ANCHOR, "sole exact body insertion anchor")
    old = SourceScaffold()
    old.feed(baseline.decode("utf-8"))
    old.close()
    added = SourceScaffold(True)
    added.feed(fragment.decode("utf-8"))
    added.close()
    require(added.sections == added.closed_sections == 1 and not added.inside and
            not set(old.ids) & set(added.ids), "complete insertion section/ID disjointness")
    result = baseline[:ANCHOR] + fragment + baseline[ANCHOR:]
    require(result[:ANCHOR] + result[ANCHOR + len(fragment):] == baseline and
            result[ANCHOR:ANCHOR + len(fragment)] == fragment, "whole baseline insertion inverse")
    return result, {"baseline_bytes": len(baseline), "fragment_bytes": len(fragment),
                    "anchor_byte": ANCHOR, "new_IDs": added.ids,
                    "baseline_full_inverse": True, "existing_assets_unchanged": True}


def preflight(manifest_arg, authority_arg):
    runtime_guard()
    mp, ap = canonical(manifest_arg), canonical(authority_arg)
    require(mp.parent == ap.parent == ROOT and mp.suffix == ap.suffix == ".json" and mp != ap,
            "distinct Root JSON manifest/authority")
    mr, ar = read(mp, ADMIN_CAP), read(ap, ADMIN_CAP)
    m, a = strict_json(mr), strict_json(ar)
    require(type(m) is dict and set(m) == {"schema", "baseline", "fragment", "summary", "archive",
            "anchor_byte", "baseline_git_blob", "insertion_id"}, "manifest exact8")
    require(m["schema"] == "Root-state-propagation-publication-input-manifest-v1" and
            type(m["anchor_byte"]) is int and m["anchor_byte"] == ANCHOR and
            m["baseline_git_blob"] == BASELINE_BLOB and m["insertion_id"] == INSERTION_ID,
            "fixed manifest values")
    require(type(a) is dict and set(a) == {"schema", "authorized", "uses", "manifest", "preparer",
            "python", "human_publication_authorization"}, "authority exact7")
    require(a["schema"] == "Root-state-propagation-publication-preparer-once-authority-v1" and
            a["authorized"] is True and type(a["uses"]) is int and a["uses"] == 1 and
            a["python"] == PYTHON, "exact authority values")
    require(a["manifest"] == pin(mp, mr), "whole manifest authority binding")
    ref_shape(a["manifest"], ADMIN_CAP)
    require(a["preparer"]["path"] == str(SELF), "own Source authority binding")
    own = ref_read(a["preparer"], SOURCE_CAP)
    ref_read(a["python"], PYTHON["bytes"])
    human = ref_read(a["human_publication_authorization"], ADMIN_CAP)
    ref_shape(m["baseline"], BODY_CAP)
    require(m["baseline"]["bytes"] == BASELINE_BYTES and m["baseline"]["sha256"] == BASELINE_SHA256,
            "hardpinned baseline rawref")
    ref_shape(m["fragment"], SOURCE_CAP)
    ref_shape(m["summary"], BODY_CAP)
    require(type(m["archive"]) is list and len(m["archive"]) + 1 <= MAX_MEMBERS, "explicit bounded archive list")
    seen_names, seen_paths, total = set(), set(), 0
    marker = Path(str(ap) + ".CONSUMED.json")
    for row in m["archive"]:
        require(type(row) is dict and set(row) == {"archive_path", "source"}, "archive row exact2")
        name = archive_name(row["archive_path"])
        p = ref_shape(row["source"], BODY_CAP)
        require(name not in seen_names and p not in seen_paths and p not in (mp, ap, marker)
                and p.suffix.lower() != ".zip", "unique explicit non-ZIP originals")
        seen_names.add(name)
        seen_paths.add(p)
        total += row["source"]["bytes"]
    require(total <= RAW_CAP, "raw archive total128MiB")
    for directory in (ROOT_STAGE, PUBLISHER_STAGE):
        canonical(str(directory))
        require(not directory.exists() and not directory.is_symlink(), "fresh staging directory")
        require(directory.parent.is_dir(), "owned existing staging parent")
    require(not marker.exists() and not marker.is_symlink(), "authority already consumed")
    return {"manifest": m, "authority": a, "manifest_path": mp, "authority_path": ap,
            "manifest_raw": mr, "authority_raw": ar, "own_raw": own, "human_raw": human,
            "marker": marker, "raw_archive_bytes": total}


class BoundedZIP(io.BytesIO):
    def write(self, data):
        require(self.tell() + len(data) <= BODY_CAP, "ZIP64MiB cap")
        return super().write(data)


def zip_info(name):
    info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
    info.create_system = 3
    info.external_attr = (stat.S_IFREG | 0o644) << 16
    info.compress_type = zipfile.ZIP_DEFLATED
    return info


def verify_archive(raw, originals, rows, catalogue_raw):
    expected_names = sorted([row["archive_path"] for row in rows] + ["catalogue.json"])
    with zipfile.ZipFile(io.BytesIO(raw), "r") as archive:
        require(archive.namelist() == expected_names and len(archive.infolist()) == len(rows) + 1 and
                archive.comment == b"" and archive.testzip() is None, "whole ZIP census/CRC")
        for info in archive.infolist():
            require(info.date_time == (1980, 1, 1, 0, 0, 0) and info.create_system == 3 and
                    info.external_attr == (stat.S_IFREG | 0o644) << 16 and
                    info.compress_type == zipfile.ZIP_DEFLATED and not info.flag_bits & 1 and
                    not info.is_dir() and info.extra == b"" and info.comment == b"", "deterministic ZIP metadata")
        require(archive.read("catalogue.json") == catalogue_raw, "whole catalogue byte readback")
        verified = []
        for row in rows:
            name = row["archive_path"]
            member = archive.read(name)
            current = ref_read(row["source"], BODY_CAP)
            info = archive.getinfo(name)
            require(member == originals[name] == current and len(member) == info.file_size == row["source"]["bytes"] and
                    hashlib.sha256(member).hexdigest() == row["source"]["sha256"] and
                    format(info.CRC, "08x") == row["CRC32"], "whole opaque input/member equality")
            verified.append({**row, "complete_original_member_byte_equality": True})
        return verified


def postguards(state):
    m, a = state["manifest"], state["authority"]
    require(read(state["manifest_path"], ADMIN_CAP) == state["manifest_raw"] and
            read(state["authority_path"], ADMIN_CAP) == state["authority_raw"] and
            ref_read(a["preparer"], SOURCE_CAP) == state["own_raw"] and
            ref_read(a["human_publication_authorization"], ADMIN_CAP) == state["human_raw"],
            "administrative/Source/human postguard")
    runtime_guard()
    for key, cap in (("baseline", BODY_CAP), ("fragment", SOURCE_CAP), ("summary", BODY_CAP)):
        ref_read(m[key], cap)
    for row in m["archive"]:
        ref_read(row["source"], BODY_CAP)


def prepare(manifest_arg, authority_arg):
    state = preflight(manifest_arg, authority_arg)
    m, a = state["manifest"], state["authority"]
    mpin = pin(state["manifest_path"], state["manifest_raw"])
    apin = pin(state["authority_path"], state["authority_raw"])
    consume = {"schema": "Root-state-propagation-publication-preparer-consumed-v1", "uses": 1,
               "authority": apin, "manifest": mpin, "preparer": a["preparer"], "python": PYTHON,
               "human_publication_authorization": a["human_publication_authorization"],
               "opaque_body_transport_started_at_consume": False, "scientific_execution": False}
    consume_pin = write_new(state["marker"], encoded(consume), ADMIN_CAP)
    sync_directory(state["marker"].parent)
    # First nonmetadata body reads and both output dirs occur only after consume.
    ROOT_STAGE.mkdir(mode=0o700)
    PUBLISHER_STAGE.mkdir(mode=0o700)
    originals, rows = {}, []
    for item in m["archive"]:
        body = ref_read(item["source"], BODY_CAP)
        originals[item["archive_path"]] = body
        rows.append({**item, "CRC32": format(zlib.crc32(body) & 0xffffffff, "08x")})
    baseline = ref_read(m["baseline"], BODY_CAP)
    fragment = ref_read(m["fragment"], SOURCE_CAP)
    summary = ref_read(m["summary"], BODY_CAP)
    report, report_check = report_bytes(baseline, fragment)
    catalogue = {"schema": "Root-state-propagation-publication-evidence-catalogue-v1",
                 "manifest": mpin, "administrative_manifest": m, "authority": apin,
                 "administrative_authority": a, "preparer": a["preparer"], "python": PYTHON,
                 "human_publication_authorization": a["human_publication_authorization"],
                 "members": rows, "original_member_count": len(rows),
                 "selected_evidence_boundary": "Exactly explicit ordered approved rawrefs only; no recursive historical closure, unlisted input, old ZIP clone or scientific semantic validation. Public inputs are not silently added to archive membership.",
                 "scientific_execution": False, "publication": False}
    catalogue_raw = encoded(catalogue)
    require(len(catalogue_raw) <= ADMIN_CAP, "catalogue admin1MiB")
    require(state["raw_archive_bytes"] + len(catalogue_raw) <= RAW_CAP, "total uncompressed ZIP128MiB")
    all_bodies = dict(originals)
    all_bodies["catalogue.json"] = catalogue_raw
    buffer = BoundedZIP()
    with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9, allowZip64=False) as archive:
        for name in sorted(all_bodies):
            archive.writestr(zip_info(name), all_bodies[name], compresslevel=9)
    archive_raw = buffer.getvalue()
    verified = verify_archive(archive_raw, originals, rows, catalogue_raw)
    postguards(state)
    bodies = (report, summary, archive_raw)
    files = []
    for name, body in zip(NAMES, bodies, strict=True):
        rp, pp = ROOT_STAGE / name, PUBLISHER_STAGE / name
        write_new(rp, body, BODY_CAP)
        write_new(pp, body, BODY_CAP)
        require(read(rp, BODY_CAP) == read(pp, BODY_CAP) == body, "complete payload twins")
        files.append({"path": PREFIX + name, "root_source": str(rp), "publisher_source": str(pp),
                      "bytes": len(body), "sha256": hashlib.sha256(body).hexdigest(),
                      "git_blob_sha1": hashlib.sha1(b"blob " + str(len(body)).encode() + b"\0" + body).hexdigest()})
    # Validate the actual written full ZIP, not only its construction buffer.
    written_archive = read(ROOT_STAGE / NAMES[2], BODY_CAP)
    require(verify_archive(written_archive, originals, rows, catalogue_raw) == verified,
            "written whole ZIP/input pair readback")
    require(read(ROOT_STAGE / NAMES[1], BODY_CAP) == summary and
            read(ROOT_STAGE / NAMES[0], BODY_CAP) == report and
            report[:ANCHOR] + report[ANCHOR + len(fragment):] == baseline, "full report/summary inverse readback")
    postguards(state)
    staging = {"schema": "Root-state-propagation-publication-three-path-staging-v1",
               "scientific_execution": False, "publication": False, "files": files,
               "manifest": mpin, "authority": apin, "consume": consume_pin,
               "preparer": a["preparer"], "python": PYTHON,
               "human_publication_authorization": a["human_publication_authorization"],
               "baseline": m["baseline"], "fragment": m["fragment"], "summary": m["summary"],
               "catalogue": {"bytes": len(catalogue_raw), "sha256": hashlib.sha256(catalogue_raw).hexdigest()},
               "original_member_count": len(rows), "archive_entries": len(rows) + 1,
               "raw_archive_bytes": state["raw_archive_bytes"],
               "uncompressed_archive_bytes": state["raw_archive_bytes"] + len(catalogue_raw),
               "complete_original_pairs": verified,
               "report_check": report_check, "all_postguards_matched": True,
               "all_opaque_input_pairs_and_CRC_verified": True,
               "scope": "Complete approved raw transport only; no scientific admission or publication."}
    staging_pin = write_new(ROOT_STAGE / "P2-staging.json", encoded(staging), ADMIN_CAP)
    require({p.name for p in ROOT_STAGE.iterdir()} == set(NAMES) | {"P2-staging.json"} and
            {p.name for p in PUBLISHER_STAGE.iterdir()} == set(NAMES), "exact Root4/publisher3 census")
    for directory in (ROOT_STAGE, PUBLISHER_STAGE):
        require(all(p.is_file() and not p.is_symlink() and regular(p).st_nlink == 1 for p in directory.iterdir()),
                "only regular payload files")
        sync_directory(directory)
    postguards(state)
    return {"schema": "Root-state-propagation-publication-preparer-terminal-v1",
            "status": "PREPARED_EXACT_THREE_PATHS_NOT_PUBLISHED", "preparer": a["preparer"],
            "python": PYTHON, "manifest": mpin, "authority": apin, "consume": consume_pin,
            "human_publication_authorization": a["human_publication_authorization"],
            "files": files, "staging": staging_pin,
            "catalogue": staging["catalogue"], "original_member_count": len(rows),
            "archive_entries": len(rows) + 1, "raw_archive_bytes": state["raw_archive_bytes"],
            "all_full_checks_passed": True, "scientific_execution": False,
            "scientific_admission": False, "publication": False,
            "scope": "Prepared bytes only; whole independent package/content/once review and separate publisher authority remain required."}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--authority", required=True)
    args = parser.parse_args()
    try:
        result = prepare(args.manifest, args.authority)
        output = encoded(result)
        require(len(output) <= ADMIN_CAP, "terminal admin1MiB")
        sys.stdout.buffer.write(output)
        sys.stdout.buffer.flush()
        return 0
    except BaseException as error:
        failure = {"schema": "Root-state-propagation-publication-preparer-terminal-v1",
                   "status": "FAILED_UNPUBLISHABLE_NO_AUTOMATIC_RETRY", "publication": False,
                   "scientific_execution": False, "scientific_admission": False,
                   "error": type(error).__name__ + ": " + str(error)[:2048],
                   "scope": "Consumed authority/partial outputs remain spent; no prefix promotion, retry or publication."}
        sys.stderr.buffer.write(encoded(failure))
        sys.stderr.buffer.flush()
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
