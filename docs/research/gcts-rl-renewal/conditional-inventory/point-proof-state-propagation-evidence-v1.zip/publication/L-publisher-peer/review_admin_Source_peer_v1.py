"""Independent administrative raw/AST review, never executes reviewed Source."""
from pathlib import Path
import ast
import builtins
import datetime
import hashlib
import json
import os
import re
import symtable
import sys

OUT = Path('/private/tmp/gcts-L-state-publisher-verifier-review-20261027-v1')
MIRROR = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-state-propagation-20261027/custody-L/publisher-verifier-Source-peer-v1')

def ref(path, size, digest):
    return {'path': str(path), 'bytes': size, 'sha256': digest}

def rawpin(path, body):
    return ref(path, len(body), hashlib.sha256(body).hexdigest())

def pinned(record):
    p = Path(record['path']); body = p.read_bytes()
    assert rawpin(p, body) == record
    return body

def pairs(values):
    result = {}
    for key, value in values:
        assert key not in result
        result[key] = value
    return result

def bad_constant(value):
    raise ValueError(value)

def parse(body):
    return json.loads(body.decode('utf-8'), object_pairs_hook=pairs, parse_constant=bad_constant)

def digest(value):
    return hashlib.sha256(value.encode()).hexdigest()

def dump(node, positioned=False):
    return ast.dump(node, include_attributes=positioned)

def callset(node):
    return sorted({ast.unparse(n.func) for n in ast.walk(node) if isinstance(n, ast.Call)})

def definitions(tree):
    result = {}
    def walk(body, prefix=''):
        for node in body:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                name = prefix + node.name
                result[name] = node
                walk(node.body, name + '.')
    walk(tree.body)
    return result

def imports(tree):
    return [dump(n) for n in ast.walk(tree) if isinstance(n, (ast.Import, ast.ImportFrom))]

def globals_unresolved(st):
    bound = {s.get_name() for s in st.get_symbols() if s.is_imported() or s.is_assigned() or s.is_namespace()}
    allowed = bound | set(dir(builtins)) | {'__name__', '__file__', '__debug__'}
    found = set()
    def visit(table):
        for s in table.get_symbols():
            if s.is_referenced() and s.is_global() and s.get_name() not in allowed:
                found.add(s.get_name())
        for child in table.get_children():
            visit(child)
    visit(st)
    return sorted(found)

def apply_unified(base, patch):
    old = base.decode().splitlines(keepends=True)
    lines = patch.decode().splitlines(keepends=True)
    assert lines[0].startswith('--- ') and lines[1].startswith('+++ ')
    out, cursor, i, hunks = [], 0, 2, 0
    while i < len(lines):
        m = re.fullmatch(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@.*\n', lines[i])
        assert m
        old_start, old_count, new_start, new_count = int(m[1]), int(m[2] or 1), int(m[3]), int(m[4] or 1)
        start = old_start - 1 if old_count else old_start
        assert cursor <= start <= len(old)
        out.extend(old[cursor:start]); cursor = start
        assert len(out) == (new_start - 1 if new_count else new_start)
        i += 1; consumed = added = 0
        while i < len(lines) and not lines[i].startswith('@@ '):
            kind, value = lines[i][0], lines[i][1:]
            assert kind in ' +-'
            if kind in ' -':
                assert cursor < len(old) and old[cursor] == value
                cursor += 1; consumed += 1
            if kind in ' +':
                out.append(value); added += 1
            i += 1
        assert consumed == old_count and added == new_count
        hunks += 1
    out.extend(old[cursor:])
    return ''.join(out).encode(), hunks

def save(name, obj):
    body = (json.dumps(obj, sort_keys=True, indent=2, ensure_ascii=False, allow_nan=False) + '\n').encode()
    p = OUT / name
    with p.open('xb') as h:
        h.write(body); h.flush(); os.fsync(h.fileno())
    assert p.read_bytes() == body
    with (MIRROR / name).open('xb') as h:
        h.write(body); h.flush(); os.fsync(h.fileno())
    assert (MIRROR / name).read_bytes() == body
    return rawpin(p, body)

expect_pin = ref(OUT / 'state-propagation-publisher-verifier-prefrozen-complete-Source-review-expectations-v1.json', 5073, '74979454398d6d3d0af503ae9a958853e60c53fe02fb18a78974301f0636e118')
expect = parse(pinned(expect_pin))
contract_pin = expect['contract']; contract = parse(pinned(contract_pin))
handoff_pin = expect['complete_C_handoff']; handoff = parse(pinned(handoff_pin))
assert handoff['contract'] == contract_pin
packet_bodies = {name: pinned(record) for name, record in handoff['complete_packet'].items()}
assert len(packet_bodies) == 8
strategy = parse(pinned(handoff['prefrozen_strategy']))
changes = parse(packet_bodies['exact_substitutions_inverse'])
manual = parse(packet_bodies['complete_manual'])
abi = parse(packet_bodies['public_ABI'])
author_static = parse(packet_bodies['static_all28helpers'])
assert changes['roles'] == abi['roles'] == manual['roles'] == handoff['roles']
assert changes['contract'] == strategy['contract'] == contract_pin
patch_keys = {'publisher_forward', 'publisher_inverse', 'verifier_forward', 'verifier_inverse'}
assert changes['patches'] == {k: v for k, v in handoff['complete_packet'].items() if k in patch_keys}
runtime = author_static['runtime']
assert runtime == {'path': '/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12', 'bytes': 18058560, 'sha256': 'd90bce0f5ac3aa40e2ee5900ad243bad0b2205ce17408278f088b34aed737840'}
pinned(runtime)
assert Path(sys.executable) == Path(runtime['path']) and sys.version_info[:3] == (3, 12, 14)
assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
role_audits = {}; trees = {}; Source_texts = {}; total_classes = total_occurrences = total_definitions = 0
for role, records in handoff['roles'].items():
    current = pinned(records['Source']); base = pinned(records['base'])
    new_text, old_text = current.decode(), base.decode()
    rows = changes['all_individual_substitutions'][role]
    forward = old_text
    for row in rows:
        assert forward.count(row['old']) == row['occurrences']
        forward = forward.replace(row['old'], row['new'])
    assert forward.encode() == current
    inverse = new_text
    for row in reversed(rows):
        assert inverse.count(row['new']) == row['occurrences']
        inverse = inverse.replace(row['new'], row['old'])
    assert inverse.encode() == base
    total_classes += len(rows); total_occurrences += sum(r['occurrences'] for r in rows)
    tree, base_tree, inverse_tree = ast.parse(new_text), ast.parse(old_text), ast.parse(inverse)
    assert dump(inverse_tree, True) == dump(base_tree, True)
    assert imports(tree) == imports(base_tree) and callset(tree) == callset(base_tree)
    forward_patch = packet_bodies[role + '_forward']; reverse_patch = packet_bodies[role + '_inverse']
    applied, forward_hunks = apply_unified(base, forward_patch)
    reversed_body, reverse_hunks = apply_unified(current, reverse_patch)
    assert applied == current and reversed_body == base
    defs = definitions(tree); old_defs = definitions(base_tree)
    assert set(defs) == set(old_defs)
    c_defs = {row['name']: row for row in author_static['all28_definition_fingerprints'][role]}
    walks = {row['helper']: row for row in manual['all28walks'] if row['role'] == role}
    assert set(defs) == set(c_defs) == set(walks)
    helper_rows = []
    for name, node in defs.items():
        old_node = old_defs[name]
        raw = ''.join(new_text.splitlines(keepends=True)[node.lineno-1:node.end_lineno]).encode()
        old_raw = ''.join(old_text.splitlines(keepends=True)[old_node.lineno-1:old_node.end_lineno]).encode()
        calls = callset(node)
        assert calls == callset(old_node)
        current_row = {'name': name, 'kind': type(node).__name__, 'line': node.lineno, 'end_line': node.end_lineno, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'base_sha256': hashlib.sha256(old_raw).hexdigest(), 'AST_sha256': digest(dump(node)), 'raw_unchanged': raw == old_raw, 'calls': calls}
        assert current_row == c_defs[name]
        assert walks[name]['line'] == node.lineno and walks[name]['end_line'] == node.end_lineno and walks[name]['raw_unchanged'] == (raw == old_raw)
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            assert dump(node.args) == dump(old_node.args)
        assert [dump(x) for x in node.decorator_list] == [dump(x) for x in old_node.decorator_list]
        helper_rows.append(current_row)
    total_definitions += len(helper_rows)
    st = symtable.symtable(new_text, records['Source']['path'], 'exec')
    bst = symtable.symtable(old_text, records['base']['path'], 'exec')
    assert globals_unresolved(st) == globals_unresolved(bst) == []
    for body, filename in [(current, records['Source']['path']), (base, records['base']['path'])]:
        obj = compile(body, filename, 'exec', dont_inherit=True, optimize=0)
        del obj
    assert digest(dump(base_tree)) == author_static['static'][role]['whole_base_AST_sha256']
    assert digest(dump(tree)) == author_static['static'][role]['whole_derived_AST_sha256']
    role_audits[role] = {'Source': records['Source'], 'base': records['base'], 'all_substitution_classes': rows, 'class_count': len(rows), 'occurrence_count': sum(r['occurrences'] for r in rows), 'whole_raw_forward_inverse_exact': True, 'whole_positioned_AST_inverse_exact': True, 'complete_forward_patch_applies': True, 'complete_reverse_patch_applies': True, 'forward_hunks': forward_hunks, 'reverse_hunks': reverse_hunks, 'all_helper_fingerprints_independently_match_C': helper_rows, 'all_manual_names_locators_and_preservation_flags_joined': True, 'imports_AST_unchanged': imports(tree), 'module_and_all_helper_callsets_unchanged': True, 'unresolved_globals': [], 'unused_compiles': 'Base and current code objects created then discarded, never executed.'}
    trees[role] = tree; Source_texts[role] = new_text
assert total_classes == 20 and total_occurrences == 21 and total_definitions == 28
assert len(role_audits['publisher']['all_helper_fingerprints_independently_match_C']) == 17
assert len(role_audits['verifier']['all_helper_fingerprints_independently_match_C']) == 11
assert len(manual['all28walks']) == 28
pub, ver = Source_texts['publisher'], Source_texts['verifier']
assert pub.index('consume = write(marker') < pub.index('before_head = head(')
assert pub.index('consume = write(marker') < pub.index('bodies = []')
assert '"force": False' in pub and 'and all(row["path"] not in before for row in files[1:])' in pub
assert 'ssl.create_default_context()' in ver and 'ProxyHandler({})' in ver and 'raw == local' in ver
assert 'response.read(CAP + 1)' in ver and 'need(read(PUB) == publication_raw' in ver
assert tuple(abi['NAMES']) == tuple(expect['public_names'])
assert abi['publisher']['baseline_blob'] == 'ad7f76c7fc7c7e15992cc48bc344b57b12a12661'
for role, records in handoff['roles'].items():
    assert Path(records['Source']['path']).read_text() == Source_texts[role]
    pinned(records['base'])
pinned(runtime)
support = {
    'schema': 'L-state-propagation-publisher-verifier-complete-independent-static-support-v1',
    'review_passed': True, 'blockers': [], 'prefrozen_expectations': expect_pin, 'contract': contract_pin, 'C_complete_handoff': handoff_pin,
    'all8_C_packet_rawpins_verified': handoff['complete_packet'], 'C_prefrozen_strategy_rawpin_verified': handoff['prefrozen_strategy'],
    'runtime_full_rawpin_verified': runtime, 'admin_runtime': {'version': sys.version, 'isolated': sys.flags.isolated, 'no_site': sys.flags.no_site, 'no_bytecode': sys.dont_write_bytecode},
    'complete_role_audits': role_audits, 'totals': {'substitution_classes': total_classes, 'substitution_occurrences': total_occurrences, 'helper_class_nested_definitions': total_definitions, 'unused_codeobjects_created_discarded_never_executed': 4, 'complete_patches_applied_in_memory': 4},
    'all4_Source_and_runtime_pre_post_rawpins_unchanged': True,
    'review_only_history': 'Initial administrative packet-key filter accidentally included exact_substitutions_inverse as a patch; assertion stopped before audit writes or reviewed Source execution. Corrected to the four exact patch keys. No Source or payload defect inferred and no input changed.',
    'independent_whole_Source_read': 'Both complete current and both complete recovered base texts read. Initial batched tool output truncated part of verifier/metadata; the missing verifier tail and full substitutions/strategy were explicitly reread before disposition. No missing Source content treated as read by prefix.',
    'complete_manual_walkthrough_and_ABI': 'Full C manual all28 walks/locators and current ABI read, all names/lines/raw preservation flags and Source refs independently joined. Independent semantic assessment in companion review. C author static all28 fingerprints/all raw bytes/import/callsets/whole AST hashes checked against new independent derivation.',
    'strict_scope': 'Administrative static byte/AST/symtable/unusedcompile only; no import or execution of either current/base Source, helper/CLI/help/test/codeobject, preparer, gh/Git/network/API, staging/payload/archive/scientific result/cost/witness/private data. No protected originals edited. Root own review is not used as independent proof.',
    'scientific_execution_authorized': False, 'publication_authorized': False
}
support_pin = save('state-propagation-publisher-verifier-complete-independent-static-support-v1.json', support)
walks = {
    'publisher': {
        'need': 'Fail-closed ValueError.', 'encode': 'Finite sorted/indented whole administrative UTF8 newline.',
        'parse': 'Duplicate/nonfinite rejection before admin interpretation.', 'parse.pairs': 'No duplicate key acceptance.', 'parse.nonfinite': 'Reject nonfinite constants.',
        'canonical': 'Exact absolute/normpath/resolved nonsymlink chain.', 'pin': 'Complete path/extent/SHA256 record.',
        'read': 'Bounded singlelink regular stable size/dev/inode/mtime full read.', 'ref': 'Exact rawpin3 type/size/hash association and full read.',
        'write': 'Exclusive O_NOFOLLOW durable full write/readback.', 'sync_dir': 'Directory fsync and finally fd close.',
        'api': 'One fixed gh api argv/cwd/timeout and full completed stdout/stderr receipt writes; no shell/localGit/retry. capture_output buffers before cap check, no hard RSS/stream bound; timeout may leave no new per-request completed response.',
        'sha': 'Exact40hex object IDs.', 'head': 'Fresh main/ref/commit type and ID.', 'leaves': 'Complete nontruncated unique recursive path map; compare every leaf mode/type/SHA.',
        'publish': 'Fixed Source/P2/D90; strictA8/Source/runtime/human/stage refs and exact3 ordered rows; exclusive consume+dir fsync before payload reads/network, full twins+Gitblob; fresh main/baseline and2absent targets,3blobPOST/treePOST/non-target equality/commitPOST/head race/nonforcePATCH/posthead; authority/stage/Source/D90 postguards/full terminal. No payload preapproval.',
        'main': 'Only authority CLI; no autoretry; failure rc2 explicitly warns mutation may have succeeded and requires read-only reconciliation.'
    },
    'verifier': {
        'need': 'Fail-closed ValueError.', 'encode': 'Whole finite pretty JSON.', 'parse': 'Strict duplicate/nonfinite parser.', 'parse.pairs': 'Reject duplicate keys.', 'parse.nonfinite': 'Reject nonfinite constants.',
        'read': 'Absolute nonsymlink singlelink bounded/stable whole input.', 'write': 'Exclusive durable full body save/readback.',
        'OnlyPagesHTTPS': 'Same HTTPS Pages origin redirect handler.', 'OnlyPagesHTTPS.redirect_request': 'Reject scheme/host departure; same-origin alternate path permitted, complete expected bytes still mandatory.',
        'verify': 'Fixed Source/flags/freshOUT and successPUB metadata, ordered3 paths/full local pins, direct normal defaultSSL hostname/certificate checking/noenvproxy, commitcachebuster/45sGET/status200/sameorigin/bounded full raw equality and saved hashes, finalPUB postguard. Depends on Root-authenticated receipt and exact3 root_source paths plus external Source/D90/human postguards.',
        'main': 'No application args; all3 full bodies or incomplete rc2; no write to remote or automatic retry.'
    }
}
assert sum(len(v) for v in walks.values()) == 28
review = {
    'schema': 'L-state-propagation-publisher-verifier-complete-independent-Source-review-v1',
    'status': 'COMPLETE_INDEPENDENT_NARROW_SOURCE_PASS_NO_INVOCATION_AUTHORITY', 'review_passed': True, 'blockers': [],
    'issued_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'prefrozen_expectations': expect_pin, 'contract': contract_pin, 'C_complete_handoff': handoff_pin, 'complete_independent_static_support': support_pin,
    'Sources': {r: row['Source'] for r, row in handoff['roles'].items()}, 'bases': {r: row['base'] for r, row in handoff['roles'].items()},
    'disposition': 'Entire2current+2base Sources and complete packet independently reviewed. All20 permitted substitution classes21occurrences reproduce complete bytes; all4 native patches apply exactly and both whole positionedAST inverses restore bases. All28 definitions/imports/callsets/signatures/decorators/manual/ABI/raw fingerprints joined. No new helper/control/API method/TLS behavior beyond contracted literals and REPO/STAGE expressions.',
    'independent_all28_helper_walks': walks,
    'publisher_contract_assessment': {'fixed_destination_and_public_names': abi['NAMES'], 'prefix': abi['prefix'], 'baseline': abi['publisher']['baseline_blob'], 'P2': abi['publisher']['P2'], 'STAGE': abi['publisher']['STAGE'], 'ROOT_STAGE': abi['publisher']['ROOT_STAGE'], 'OUT': abi['publisher']['OUT'], 'once': 'ExactA8 includes current human full archive consent rawref; fresh Root-adjacent consume and output directory. Exclusive durable marker before any network or payload body read, no reuse after failure.', 'remote': 'Fresh main and nontruncated fulltree; existing report exactad7blob/100644/blob and2new paths absent. All non-target leaves identical by mode/type/SHA, including protected reader via metadata only; directory tree SHAs change with insertion by design. Exactly3 targets, parent/head checks, forcefalse and posthead; no localGit or fourth protected-reader body fetch.', 'uncertain': 'Each mutating call only once in Source; failures stay spent and cannot imply no publication. Root read-only reconciliation of saved responses/remote ref required; no automatic new mutation.'},
    'verifier_contract_assessment': {'exact3_only': abi['NAMES'], 'normal_TLS': 'ssl.create_default_context and direct HTTPS with hostname/certificate checking and no env proxy; redirects and final response same fixed HTTPS origin,200. All3 complete bounded bytes equal exact current local payload/extent/SHA; no scientific decoder/archive parse.', 'receipt_and_path_trust': 'Verifier checks public target paths/schema/status/commit/full local pins but is NOT hostile-forged-receipt resistant and does not internally constrain root_source to approved stage. Root must authenticate exact complete publication terminal+authoritative outer exit0/A8consume/staging, three exact Root paths/pins BEFORE invocation.', 'external_guards': 'Verifier ownSource/D90 and publication/fullpayload/human authorization before/after remain external Root duties. Internal final PUB postguard is preserved; publisher rechecks authority/stage/self/D90 internally, human final postguard remains external. These are mandatory remaining gates, not newly claimed checks.'},
    'precision_and_nonblocking_limits': ['No hard API output-stream/RSS cap: subprocess capture_output completes or times out before receipt cap checks; full response files only when call returns. No atomic host/path-race transaction guarantee.', 'Same-origin redirect may select another path; full expected raw equality still required. TLS success does not substitute for Pages build or browser/math QA.', 'Human consent rawref verifies bytes and Root parent; substantive human full archive authorization/content/audience and exactA8 association are Root checks. No prior human1381 body followed or freshly pinned in this review.', 'Whole Source prefix/read truncation was explicitly corrected by complete remaining reads; no prefix-only acceptance.'],
    'mandatory_remaining_gates': ['Root fully adopts independent Source review; no payload or invocation approval here.', 'Separately freeze/read/adopt exact current content/summary/HTML/archive/catalogue/staging/Root-P2 twin closure and full human archive consent; C preparer is separate and was not inspected.', 'Fresh exactA8 currentSource/D90/staging/human/baseline bindings plus absent consume/output and remote guards, soleP2 authorized once. Preserve Source/runtime/receipt/payload/path/human postguards and full authoritative outer/captured request response terminal joins.', 'After sole publication: complete Pages/deployment success, normalTLS3wholebody verification with external receipt/path/Source/D90/human guards, then independent live browser/MathJax QA. No fourth protected-reader fetch or unrelated publication.'],
    'operations': {'current_base_Source_import_function_helper_CLI_help_test_or_codeobject_execution': 0, 'scientific_actual_cost_witness_or_archive_intake': 0, 'preparer_or_staging_payload_body_intake': 0, 'network_API_Git_publication_or_staging_execution': 0, 'protected_original_edits': 0, 'stdlib_AST_symtable_unusedcompile_only': True},
    'scientific_execution_authorized': False, 'publication_authorized': False,
    'final_state': 'TMP_FIRST_NEW_REPO_MIRROR_FROZEN; ALL_OWN_COMMANDS_TERMINAL_IDLE; NO SOURCE_INVOCATION.'
}
review_pin = save('state-propagation-publisher-verifier-complete-independent-Source-review-v1.json', review)
print(json.dumps({'review': review_pin, 'support': support_pin, 'prefreeze': expect_pin, 'status': 'PASS_TERMINAL_IDLE_NO_EXECUTION'}, sort_keys=True))
