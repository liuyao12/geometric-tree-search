from pathlib import Path
import datetime
import hashlib
import json
import os

obj = {
    'schema': 'L-state-propagation-publisher-verifier-prefrozen-complete-Source-review-expectations-v1',
    'status': 'FROZEN_BEFORE_TARGET_OR_BASE_SOURCE_INTAKE',
    'issued_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'contract': {'path': '/private/tmp/gcts-state-propagation-20261027-active-v1/root/state-propagation-P2-publisher-verifier-narrow-Source-contract-v1.json', 'bytes': 3418, 'sha256': 'e88b4f61da41b8dbe0e2edaf548fa5f81b252060e04100ec8f1ef4673462183b'},
    'complete_C_handoff': {'path': '/private/tmp/gcts-C-state-publisher-verifier-Source-20261027-v1/state-propagation-P2-publisher-verifier-complete-Source-handoff-v1.json', 'bytes': 4867, 'sha256': 'd7d4ef9b4ec1fb17031d1726481d27bc98dee2cada9086d3dcbce64d15ebe14f'},
    'intake_before_freeze': 'Full contract and complete administrative handoff read only; no target/base Source bodies or patches/manual/AST-support bodies read yet. No preparer or scientific actuals/costs/witnesses.',
    'complete_raw_scope': 'Read entire pinned publisher13771/base13757 and verifier6340/base6405, full8packet records plus prefrozen strategy. Independently verify complete rawpins and all20replacementclasses21occurrences, exactly13publisherclasses14occurrences+7verifierclasses7occurrences; all4complete forward/reverse patch byte applications and full positionedAST inverses. No filename-prefix/selected-helper acceptance.',
    'allowed_delta': 'Only fixed Source/tempRoot paths, explicit publisher REPO original repo and STAGE stable temp payload path expressions, state-propagation schema/path/publication message labels, three fixed public names and exact current baseline Gitblob ad7f76c7fc7c7e15992cc48bc344b57b12a12661. ROOT remains SELF.parent, P2 same isolated working directory/sole Git Data API publisher, same URL prefix and public audience. No other call/import/helper/control/bound/data-API or TLS behavior changes.',
    'helper_and_static_requirements': 'All28function/class/nested definitions17publisher+11verifier fully accounted, signatures/decorators/full raw+AST/inverse/import+callsets/sideeffect sites/manual walkthrough/publicABI joined independently. D90 -I-S-B CPython3.12.14 full executable pin18058560/d90bce...; AST/symtable/unusedcompile only, discard codeobjects and never execute them. No Source import, help/CLI/test/helper or network API execution.',
    'publisher_preflight_and_once': 'Exact schema/path/Source/runtime/receipt/Root gate/human full archive consent bindings, strict argument types/canonical nonsymlink/regular/nlink/bounds/exclusive fresh folders/output checks. Exclusive once consume with complete readback before first network, exact current Source/self pin and role paths, full approved package+staging+payload3twins/rawpins and all receipts/human postguards; not approval of future payload bodies or missing Root gates.',
    'remote_tree_mutation': 'Fresh authoritative main/full nontruncated tree, exact existing report baseline ad7blob and both new summary/archive leaves absent. Exactly3 allowed paths with proper mode/type, preserve EVERY nontarget mode/type/SHA and head/race check. Source/runtime/manifest/payload/human/authority postguards remain whole. One branch update force=false, full actual Git Data API request/response receipts, uncertain mutating outcome stops without retry or assumed success. No protected reader body request or unrelated leaf mutation; full tree preserves it by metadata.',
    'verifier_TLS': 'Only three exact ordered new-target bodies, normal TLS hostname/certificate checks, trusted fixed origin/path+redirect association/status/declared body bounds complete bytes and exact live size/SHA match payload expected; bounded freshness/cache policy and raw receipts preserved. No fourth protected-reader fetch, insecure TLS, response-prefix admission or automatic publish/retry. Pages/deployment/browser gates remain later Root actions.',
    'public_names': ['point-proof-parallel-progress-v1.html', 'point-proof-state-propagation-summary-v1.json', 'point-proof-state-propagation-evidence-v1.zip'],
    'independence': 'Root own4205 Source read/inverse is not peer substitute; B earlier review incomplete. This reviewer must finish whole independent Source/packet review; no C preparer Source intake. Prior human1381 authorization may be rawpin metadata only, never followed to scientific bodies.',
    'scope_and_remaining_gates': 'Review Source only. Even PASS grants no staging/package/preparer/publisher/verifier/network/publication execution. Separate Root full Source adoption, exact whole current content/archive/staging/human A8/once/remote guards, soleP2 invocation and Pages/TLS/browser verification later. No actual/cost/witness/old archive/private scientific body intake, no protected original edits.',
    'operations_before_freeze': {'target_or_base_Source_intake': 0, 'scientific_actual_cost_witness_intake': 0, 'project_or_admin_Source_helper_execution': 0, 'network_API_staging_publication': 0},
    'execution_authorized': False, 'publication_authorized': False
}
b = (json.dumps(obj, sort_keys=True, indent=2, ensure_ascii=False, allow_nan=False) + '\n').encode()
p = Path('/private/tmp/gcts-L-state-publisher-verifier-review-20261027-v1/state-propagation-publisher-verifier-prefrozen-complete-Source-review-expectations-v1.json')
with p.open('xb') as h:
    h.write(b); h.flush(); os.fsync(h.fileno())
assert p.read_bytes() == b
m = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-state-propagation-20261027/custody-L/publisher-verifier-Source-peer-v1')
m.mkdir(exist_ok=False)
with (m / p.name).open('xb') as h:
    h.write(b); h.flush(); os.fsync(h.fileno())
assert (m / p.name).read_bytes() == b
print(json.dumps({'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest(), 'Source_intake_before_freeze': 0}))
