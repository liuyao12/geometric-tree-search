"""Administrative text-only recovery driver. Never imports/executes observer code."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import os

T = Path('/private/tmp/gcts-L-observer-rebuild-20261027-v1')
S = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-state-propagation-20261027')
D = S / 'custody-L'
M = json.loads(Path('/private/tmp/gcts-state-review-recovery-20261027-v2/manifest.json').read_bytes())

def alias(original, size, digest):
    row = M['mapping'][str(original)]
    assert row['original'] == {'path': str(original), 'bytes': size, 'sha256': digest}
    p = Path(row['copy']['path'])
    b = p.read_bytes()
    assert len(b) == size and hashlib.sha256(b).hexdigest() == digest
    return b

abi = json.loads(alias(D/'state-propagation-once-plan-worker-terminal-ABI-v1.json', 14529,
    '334d9ca6685f09225fd017f4f335b28cea4a526a2093ef465f33d17848eeac8d'))
handoff = json.loads(alias(D/'state-propagation-once-observer-complete-Source-handoff-v1.json', 12124,
    '4b6655eb5ae1f9e895210615b6966db8e8df625960ec49f8c655a834ea8a8288'))
br = abi['recovered_observer_base']
warm = Path('/private/tmp/gcts-tableau-base-archive-recovery-20261027-v1/tableau_once_observer_v1.py')
bb = warm.read_bytes()
assert len(bb) == 30992 and hashlib.sha256(bb).hexdigest() == br['sha256']
base = bb.decode()
source = base
edits = []

def edit(label, old, new, count=1):
    global source
    assert source.count(old) == count, (label, source.count(old))
    source = source.replace(old, new)
    edits.append({'label': label, 'old': old, 'new': new, 'count': count})

oldrole = 'ROLE_PATHS = {\n    "observer": STUDY / "custody-L/tableau_once_observer_v1.py",\n    "worker": STUDY / "independent-C/finite_tableau_qualification_v1.py",\n    "engine": STUDY / "root/recovered-current-sources-v1/finite_point_engine_v1.py",\n    "compiler": STUDY / "implementation-B/finite_local_table_tableau_v1.py",\n    "oracle": STUDY / "independent-C/finite_tableau_independent_v1.py",\n}\n'
role = 'ROLE_PATHS = {\n' + ''.join('    ' + json.dumps(k) + ': STUDY / ' + json.dumps(str(Path(abi['five_exact_active_roles'][k]).relative_to(S))) + ',\n' for k in ['observer', 'worker', 'engine', 'compiler', 'oracle']) + '}\n'
case_map = {r['case_id']: r['descriptor'] for r in abi['plan']['case_map_and_order']}
clock = {
    'observer_elapsed_origin': 'Inside supervise after observer imports and argparse; those startup phases are excluded.',
    'observed_launch_to_wait_seconds': 'From AFTER Popen returns to AFTER owned wait; subprocess startup before Popen returns may be excluded. This is not complete process lifetime.',
    'worker_elapsed_origin': 'Worker main entry before args/auth/role loads, after interpreter and own module startup/imports.',
    'cross_clock_relation': 'No worker elapsed <= post-Popen-return interval invariant or clean startup subtraction is asserted.',
    'memory_and_tail': 'RSS is process lifetime highwater, separate from elapsed origins. Worker terminal samples precede final budget/terminal tail; final outer serialization/flush/shutdown is also unmeasured. Reserve is an allowance, not a proved bound.'
}
newrole = role + 'CASE_MAP = ' + json.dumps(case_map, indent=4) + '\nCLOCK_ORIGINS = ' + json.dumps(clock, indent=4) + '\n'
edit('five_fixed_roles_case_map_and_clock_disclosures', oldrole, newrole)
schemas = abi['observer_metadata']['schemas']
for old, new in [
    ('GCTS-finite-tableau-once-plan-v1', abi['plan']['schema']),
    ('Root-finite-tableau-once-authority-v1', abi['authority']['schema']),
    ('Root-finite-tableau-once-consumed-v1', schemas['consumed']),
    ('GCTS-finite-tableau-once-observer-custody-v1', schemas['custody']),
    ('GCTS-finite-tableau-once-observer-terminal-v1', schemas['terminal']),
    ('GCTS-finite-tableau-once-observer-outer-terminal-v1', schemas['outer']),
    ('GCTS-finite-tableau-once-observer-abort-v1', schemas['abort'])
]:
    edit('schema_' + old, '"' + old + '"', '"' + new + '"')
old = 'def preflight(plan_arg, authority_arg):\n    flags = runtime_flags()'
new = 'def preflight(plan_arg, authority_arg):\n    require(STUDY == Path(' + json.dumps(str(S)) + ')\n            and Path(__file__).resolve() == ROLE_PATHS["observer"],\n            "fixed new study and executing observer role required")\n    flags = runtime_flags()'
edit('fixed_study_and_executing_self_binding', old, new)
old = '            and re.fullmatch(r"[a-z0-9][a-z0-9_-]{0,63}", plan["case_id"]),\n            "plan schema/case identity")'
new = '            and re.fullmatch(r"[a-z0-9][a-z0-9_-]{0,63}", plan["case_id"])\n            and plan["case_id"] in CASE_MAP,\n            "plan schema/exact five-case identity")'
edit('strict_five_case_membership_before_consume', old, new)
helper = '''def validate_worker_terminal(path, case_id, expected_plan, expected_result):
    """Validate bounded administrative stdout only; result bytes stay opaque."""
    raw = small_read(path, TERMINAL_CAP)
    value = strict_json(raw)
    require(type(value) is dict and set(value) == {
        "schema", "worker_version", "case_id", "case_descriptor", "status",
        "plan", "result", "post_result_readback_costs", "unmeasured_worker_tail"},
        "worker terminal exact nine fields")
    require(type(value["schema"]) is str
            and value["schema"] == @SCHEMA@
            and type(value["worker_version"]) is str
            and value["worker_version"] == @VERSION@
            and type(value["status"]) is str
            and value["status"] == @STATUS@,
            "worker terminal schema/version/status")
    require(type(value["case_id"]) is str and value["case_id"] == case_id
            and case_id in CASE_MAP, "worker terminal exact case identity")
    descriptor = value["case_descriptor"]
    require(type(descriptor) is dict and set(descriptor) == {"lane", "problem", "arm"}
            and all(type(item) is str for item in descriptor.values())
            and descriptor == CASE_MAP[case_id], "worker terminal exact descriptor")
    pin_shape(value["plan"], Path(expected_plan["path"]))
    pin_shape(value["result"], Path(expected_result["path"]))
    require(value["plan"] == expected_plan, "worker terminal whole-plan binding")
    require(0 < value["result"]["bytes"] <= LIMITS["result_bytes"]
            and value["result"] == expected_result, "worker terminal complete result binding")
    costs = value["post_result_readback_costs"]
    require(type(costs) is dict and set(costs) == {
        "elapsed_seconds", "self_lifetime_highwater_bytes",
        "worker_budget_callbacks_before_terminal_encoding", "capture_site",
        "elapsed_origin", "rss_scope"}, "worker terminal exact six cost fields")
    require(type(costs["elapsed_seconds"]) is float
            and 0 <= costs["elapsed_seconds"] < LIMITS["worker_seconds"],
            "worker terminal post-readback elapsed exact finite float/bound")
    require(type(costs["self_lifetime_highwater_bytes"]) is int
            and 0 <= costs["self_lifetime_highwater_bytes"] <= LIMITS["memory_bytes"],
            "worker terminal SELF lifetime exact integer/bound")
    require(type(costs["worker_budget_callbacks_before_terminal_encoding"]) is int
            and costs["worker_budget_callbacks_before_terminal_encoding"] >= 0,
            "worker terminal callback count exact nonnegative integer")
    require(type(costs["capture_site"]) is str and costs["capture_site"] == @SITE@
            and type(costs["elapsed_origin"]) is str and costs["elapsed_origin"] == @ORIGIN@
            and type(costs["rss_scope"]) is str and costs["rss_scope"] == @RSS@
            and type(value["unmeasured_worker_tail"]) is str
            and value["unmeasured_worker_tail"] == @TAIL@,
            "worker terminal exact capture/origin/RSS/tail disclosures")
    require(raw == encode(value), "worker terminal complete canonical encoding")
    return {"validation_status": "VALIDATED", "rawpin": rawpin(path, raw),
            "metadata": value, "error": None}


'''
term = abi['worker_terminal']
for k, v in {'@SCHEMA@': term['schema'], '@VERSION@': term['version'], '@STATUS@': term['status'], '@SITE@': term['capture_site'], '@ORIGIN@': term['elapsed_origin'], '@RSS@': term['rss_scope'], '@TAIL@': term['tail']}.items():
    helper = helper.replace(k, json.dumps(v))
edit('one_bounded_administrative_terminal_validator', 'def preflight(plan_arg, authority_arg):', helper + 'def preflight(plan_arg, authority_arg):')
old = '        allowed = {"CONSUMED.json", "stdout.bin", "stderr.bin", "worker-result.json"}'
integration = '''        terminal_requirements = {
            "no_prior_issues": not issues,
            "worker_exit_zero": process is not None and process.returncode == 0,
            "child_reaped": child_reaped,
            "owned_group_gone": group_gone,
            "drain_threads_joined": all(not thread.is_alive() for thread in threads),
            "complete_stdout": logs.get("stdout", {}).get("complete_full_log") is True,
            "complete_stderr": logs.get("stderr", {}).get("complete_full_log") is True,
            "complete_nonempty_result": result is not None and result["bytes"] > 0,
        }
        worker_terminal = {
            "validation_status": "NOT_VALIDATED",
            "rawpin": logs.get("stdout", {}).get("rawpin"), "metadata": None,
            "error": "Incomplete normal transport prerequisites: " + ", ".join(
                name for name, ok in terminal_requirements.items() if not ok),
        }
        if all(terminal_requirements.values()):
            try:
                worker_terminal = validate_worker_terminal(
                    directory / "stdout.bin", plan["case_id"], guards["plan"], result)
            except Exception as error:
                worker_terminal.update({"validation_status": "VALIDATION_FAILED",
                                        "error": type(error).__name__ + ": " + str(error)[:2048]})
                issue("WORKER_TERMINAL", worker_terminal["error"])
        else:
            issue("WORKER_TERMINAL", worker_terminal["error"])
'''
edit('normal_terminal_validation_before_census_late_samples_and_postguards', old, integration + old)
edit('custody_terminal_validation_and_clock_metadata', '                  "actual_consumed": actual_consumed, "runtime_flags": flags,', '                  "actual_consumed": actual_consumed, "runtime_flags": flags,\n                  "worker_terminal": worker_terminal, "clock_origins": CLOCK_ORIGINS,')
edit('terminal_receipt_validation_and_clock_metadata', '                    "case_id": plan["case_id"], "custody_receipt": custody_pin,', '                    "case_id": plan["case_id"], "custody_receipt": custody_pin,\n                    "worker_terminal": worker_terminal, "clock_origins": CLOCK_ORIGINS,')
edit('outer_validation_and_clock_metadata', '                 "observer_exit_required": 0 if not issues else 2,', '                 "observer_exit_required": 0 if not issues else 2,\n                 "worker_terminal": worker_terminal, "clock_origins": CLOCK_ORIGINS,')

raw = source.encode()
expected = handoff['Source']
assert len(raw) == 38572 and hashlib.sha256(raw).hexdigest() == expected['sha256'] == 'dd6e19d1d9eda0347fa16a5b8113dc33272177abdad718e21a311c3f23b41830'
reverse = source
for e in reversed(edits):
    assert reverse.count(e['new']) == e['count']
    reverse = reverse.replace(e['new'], e['old'])
assert reverse.encode() == bb
assert ast.dump(ast.parse(reverse), include_attributes=True) == ast.dump(ast.parse(base), include_attributes=True)

mirror = D/'recovered-frozen-observer-v1'
mirror.mkdir(mode=0o700)
outputs = []

def publish_bytes(name, data, expected_original=None):
    p = T/name
    with p.open('xb') as f:
        f.write(data); f.flush(); os.fsync(f.fileno())
    assert p.read_bytes() == data
    cp = mirror/name
    with cp.open('xb') as f:
        f.write(data); f.flush(); os.fsync(f.fileno())
    assert cp.stat().st_size == len(data)
    row = {'stable_copy': {'path': str(p), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}, 'repo_mirror': {'path': str(cp), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}}
    if expected_original is not None:
        assert len(data) == expected_original['bytes'] and hashlib.sha256(data).hexdigest() == expected_original['sha256']
        row['original_identity_recovered'] = expected_original
    outputs.append(row)
    return expected_original if expected_original else row['stable_copy']

publish_bytes('state_propagation_once_observer_v1.py', raw, expected)
fraw = ''.join(difflib.unified_diff(base.splitlines(True), source.splitlines(True), fromfile=br['path'], tofile=expected['path'])).encode()
iraw = ''.join(difflib.unified_diff(source.splitlines(True), base.splitlines(True), fromfile=expected['path'], tofile=br['path'])).encode()
fref = publish_bytes('state-propagation-observer-from-recovered-base-v1.patch', fraw, handoff['complete_packet']['forward_patch'])
iref = publish_bytes('state-propagation-observer-to-recovered-base-v1.patch', iraw, handoff['complete_packet']['inverse_patch'])
delta = {'schema': 'L-state-propagation-observer-complete-allowed-delta-and-inverse-v1', 'Source': expected, 'base': br, 'contract': handoff['Source_contract'], 'edits_in_order': edits, 'forward_patch': fref, 'inverse_patch': iref, 'whole_complete_raw_inverse_equal': True, 'new_helpers': ['validate_worker_terminal'], 'unchanged_imports_caps_timers_and_algorithms': True, 'scientific_result_JSON_parse': False, 'Source_execution': False, 'plan_authority_actual_created': False}
delta_raw = (json.dumps(delta, indent=2, sort_keys=True) + '\n').encode()
publish_bytes('state-propagation-observer-complete-allowed-delta-and-inverse-v1.json', delta_raw, handoff['complete_packet']['whole_delta_inverse'])
manifest = {'schema': 'L-exact-frozen-observer-and-text-delta-recovery-v1', 'original_Source': expected, 'original_base': br, 'warm_base_copy': str(warm), 'method': 'Retained conversation authoring edit text applied to exact warm base and recovered ABI only; no observer code executed. Full frozen Source and three metadata/patch hashes matched exactly before publishing each alias.', 'outputs': outputs, 'whole_raw_and_positioned_AST_inverse': True, 'no_original_read_retry_or_overwrite': True, 'source_execution': False, 'scientific_functions_or_result_intake': False, 'remaining_original_support': 'Unavailable old static/manual/clock bodies require honest successor regeneration, no original identity claim without whole hash equality.'}
data = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
publish_bytes('recovery-manifest-v1.json', data)
print(json.dumps({'Source_exact': expected, 'recovery_manifest': {'path': str(T/'recovery-manifest-v1.json'), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}, 'outputs': outputs[:-1]}, indent=2))
