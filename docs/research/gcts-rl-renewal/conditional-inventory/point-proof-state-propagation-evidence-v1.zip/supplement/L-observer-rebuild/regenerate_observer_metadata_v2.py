"""Administrative AST/text metadata regeneration. Project code is never executed."""
from pathlib import Path
import ast
import datetime
import hashlib
import json
import os
import re
import symtable
import sys

T = Path('/private/tmp/gcts-L-observer-rebuild-20261027-v1')
S = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-state-propagation-20261027')
D = S/'custody-L'
mirror = D/'recovered-frozen-observer-v1'
M = json.loads(Path('/private/tmp/gcts-state-review-recovery-20261027-v2/manifest.json').read_bytes())

def pin(p, b):
    return {'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}

def mapped(original, size, digest):
    row = M['mapping'][str(original)]
    assert row['original'] == {'path': str(original), 'bytes': size, 'sha256': digest}
    p = Path(row['copy']['path'])
    b = p.read_bytes()
    assert pin(p, b) == row['copy']
    return b, row

ab, amap = mapped(D/'state-propagation-once-plan-worker-terminal-ABI-v1.json', 14529, '334d9ca6685f09225fd017f4f335b28cea4a526a2093ef465f33d17848eeac8d')
hb, hmap = mapped(D/'state-propagation-once-observer-complete-Source-handoff-v1.json', 12124, '4b6655eb5ae1f9e895210615b6966db8e8df625960ec49f8c655a834ea8a8288')
abi, oldhandoff = json.loads(ab), json.loads(hb)
sp = T/'state_propagation_once_observer_v1.py'
sb = sp.read_bytes()
assert len(sb) == 38572 and hashlib.sha256(sb).hexdigest() == oldhandoff['Source']['sha256']
bp = Path('/private/tmp/gcts-tableau-base-archive-recovery-20261027-v1/tableau_once_observer_v1.py')
bb = bp.read_bytes()
assert len(bb) == 30992 and hashlib.sha256(bb).hexdigest() == oldhandoff['recovered_complete_base']['sha256']
dp = T/'state-propagation-observer-complete-allowed-delta-and-inverse-v1.json'
db = dp.read_bytes()
assert len(db) == 14436 and hashlib.sha256(db).hexdigest() == '712d2562c8590f817a86a2abb2dd362295e1aa8e3ede36276751b18b17d3be5d'
delta = json.loads(db)
source, base = sb.decode(), bb.decode()
inverse = source
for row in reversed(delta['edits_in_order']):
    assert inverse.count(row['new']) == row['count']
    inverse = inverse.replace(row['new'], row['old'])
assert inverse.encode() == bb
bt, ct = ast.parse(base), ast.parse(source)
assert ast.dump(ast.parse(inverse), include_attributes=True) == ast.dump(bt, include_attributes=True)

def definitions(tree, text):
    rows = {}
    def walk(node, prefix=''):
        for n in ast.iter_child_nodes(node):
            if isinstance(n, (ast.FunctionDef, ast.ClassDef)):
                name = prefix+n.name
                b = ''.join(text.splitlines(True)[n.lineno-1:n.end_lineno]).encode()
                rows[name] = {'name': name, 'kind': type(n).__name__, 'line': n.lineno, 'end_line': n.end_lineno, 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest(), 'AST_sha256': hashlib.sha256(ast.dump(n, include_attributes=False).encode()).hexdigest(), '_raw': b}
                walk(n, name+'.')
            else:
                walk(n, prefix)
    walk(tree)
    return rows

olddefs, defs = definitions(bt, base), definitions(ct, source)
assert len(olddefs) == 34 and len(defs) == 35
fingerprints = []
for name, row in defs.items():
    r = {k:v for k,v in row.items() if k != '_raw'}
    r['raw_equal_base'] = name in olddefs and row['_raw'] == olddefs[name]['_raw']
    r['AST_equal_base'] = name in olddefs and row['AST_sha256'] == olddefs[name]['AST_sha256']
    fingerprints.append(r)
assert [r['name'] for r in fingerprints if r['name'] in olddefs and not r['raw_equal_base']] == ['preflight','supervise','main']
assert sum(r['raw_equal_base'] for r in fingerprints) == 31
for text, filename in [(base, oldhandoff['recovered_complete_base']['path']), (source, oldhandoff['Source']['path'])]:
    unused = compile(text, filename, 'exec', dont_inherit=True, optimize=0)
    del unused

def scope(t):
    return {'name':t.get_name(), 'type':t.get_type(), 'symbols':sorted(t.get_identifiers()), 'children':[scope(c) for c in t.get_children()]}

current_symbols = scope(symtable.symtable(source, oldhandoff['Source']['path'], 'exec'))
assert scope(symtable.symtable(base, oldhandoff['recovered_complete_base']['path'], 'exec')) == scope(symtable.symtable(inverse, oldhandoff['recovered_complete_base']['path'], 'exec'))
imports = [ast.get_source_segment(source,n) for n in ct.body if isinstance(n,(ast.Import,ast.ImportFrom))]
assert [ast.dump(n) for n in bt.body if isinstance(n,(ast.Import,ast.ImportFrom))] == [ast.dump(n) for n in ct.body if isinstance(n,(ast.Import,ast.ImportFrom))]
locators = {}
for token in ['def validate_worker_terminal','terminal_requirements =','allowed = {','sample("after_complete_output_readbacks")','post = {name: observe_guard','process = subprocess.Popen','launched = time.monotonic()','waited = time.monotonic()','child_observation = usage_record','late = sample(','final_self = usage_record','outer_raw = encode(outer)']:
    hits = [i for i,line in enumerate(source.splitlines(),1) if token in line]
    assert len(hits) == 1
    locators[token] = hits[0]
assert locators['terminal_requirements ='] < locators['allowed = {'] < locators['sample("after_complete_output_readbacks")'] < locators['post = {name: observe_guard']
assert source.count('started + 120') == base.count('started + 120') == 3

def patch(original, text):
    lines, ps = original.splitlines(True), text.splitlines(True)
    out, at, i = [], 0, 2
    assert ps[0].startswith('--- ') and ps[1].startswith('+++ ')
    while i < len(ps):
        m = re.fullmatch(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@\n', ps[i])
        assert m
        start, old, new = int(m[1])-1, int(m[2] or 1), int(m[4] or 1)
        assert at <= start
        out.extend(lines[at:start]); at=start; i+=1; oc=nc=0
        while i<len(ps) and not ps[i].startswith('@@ '):
            kind, v = ps[i][0], ps[i][1:]
            assert kind in ' +-'
            if kind in ' -':
                assert lines[at] == v
                at+=1; oc+=1
            if kind in ' +':
                out.append(v); nc+=1
            i+=1
        assert (oc,nc)==(old,new)
    out.extend(lines[at:])
    return ''.join(out)

for name, before, after in [('forward_patch',base,source),('inverse_patch',source,base)]:
    original = oldhandoff['complete_packet'][name]
    b = (T/Path(original['path']).name).read_bytes()
    assert len(b) == original['bytes'] and hashlib.sha256(b).hexdigest() == original['sha256']
    assert patch(before,b.decode()) == after

records = []
def publish(name, obj):
    b = (json.dumps(obj,indent=2,sort_keys=True)+'\n').encode()
    p = T/name
    with p.open('xb') as f:
        f.write(b);f.flush();os.fsync(f.fileno())
    assert p.read_bytes() == b
    cp = mirror/name
    with cp.open('xb') as f:
        f.write(b);f.flush();os.fsync(f.fileno())
    assert cp.stat().st_size == len(b)
    row = {'stable_copy':pin(p,b),'repo_mirror':pin(cp,b)}
    records.append(row)
    return row

unavailable = {k:oldhandoff['complete_packet'][k] for k in ['static_helpers_inverse','manual_all35','clock_guard_terminal']}
origin = {'Source_original':oldhandoff['Source'],'Source_exact_recovery_copy':pin(sp,sb),'base_original':oldhandoff['recovered_complete_base'],'base_exact_warm_copy':pin(bp,bb),'contract_original_pin':oldhandoff['Source_contract'],'contract_body_status':'Previously fully read; failed native copy is NOT an alias and is not reopened. Exact recovered ABI and prior complete contract reading supply the recorded interface.','original_three_support_bodies_unavailable':unavailable,'metadata_policy':'These are explicitly new successor metadata, not a rehash or byte-identity claim for unavailable originals.'}
stat = {'schema':'L-state-propagation-observer-recovered-complete-static-v2','issued_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'origin':origin,'checks_passed':True,'blockers':[],'all35_definition_fingerprints':fingerprints,'old_count':34,'current_count':35,'old31_raw_AST_identical':True,'only_old_changed':['preflight','supervise','main'],'new_helper':['validate_worker_terminal'],'whole_raw_and_positioned_AST_inverse':True,'whole_exact_forward_inverse_patch_application':True,'complete_current_symtable':current_symbols,'inverse_symtable_equal':True,'unused_compile':'Base and recovered exact frozen Source code objects created then discarded, never executed.','imports_unchanged':imports,'locators':locators,'all_limits_caps_and_3cleanup120_literals_unchanged':True,'operations':{'project_Source_import_or_function_or_codeobject_execution':0,'models_fixtures_tests_CLI_help_actual_result_or_old_archive_intake':0,'old_original_or_partial_target_reads':0,'plans_A6_actuals_network_publication':0},'runtime':{'path':sys.executable,'version':sys.version,'isolated':sys.flags.isolated,'no_site':sys.flags.no_site,'dont_write_bytecode':sys.dont_write_bytecode,'optimize':sys.flags.optimize}}
statrow = publish('state-propagation-observer-recovered-complete-static-v2.json',stat)
descriptions = {
 'Refusal':'Administrative fail-closed exception only.',
 'require':'Raise Refusal on a failed guard; no salvage.',
 'strict_json':'Full UTF8 administrative JSON; duplicate/nonfinite callbacks. Never parses scientific result bytes.',
 'strict_json.pairs':'Reject duplicate keys and return a complete object.',
 'strict_json.nonfinite':'Refuse NaN/Infinity literals; new elapsed bounds also reject numeric overflow.',
 'encode':'Inherited sorted indent2 allow_nanFalse UTF8 plus newline; terminal canonicalization reuses it.',
 'rawpin':'Complete provided-byte path/extent/SHA256 metadata only.',
 'absolute_path':'Exact nonempty absolute spelling without dot components.',
 'nonsymlink_chain':'Reject symlink in file or ancestor path.',
 'regular':'Single-link regular-file metadata after nonsymlink checks.',
 'administrative_path':'Safe owned Root .json path and regular metadata.',
 'small_read':'Cap+1 whole read with stable pre/post identity and full extent;16KiB terminal path only.',
 'pin_shape':'Exact typed rawpin3; no bool/float integer substitution; fixed path and cap when requested.',
 'observe_guard':'Complete streaming hash/stat comparison, fail-closed unmatched error record.',
 'write_new':'O_EXCL/O_NOFOLLOW durable write and full readback; no overwrite.',
 'fsync_directory':'Directory namespace fsync and fd close in finally.',
 'rss_bytes':'Inherited Darwin lifetime maxrss byte representation, not current RSS.',
 'usage_record':'Named supervise-origin elapsed and lifetime usage metadata.',
 'no_prior_children':'Require entire prior RUSAGE_CHILDREN tuple zero.',
 'kill_group':'Signal only owned child pgid; tolerate missing group.',
 'group_exists':'Owned group existence probe.',
 'Capture':'Unchanged full worker stdio accounting/drain/readback class.',
 'Capture.__init__':'Own log paths/counters/hash state/handles; no scientific object.',
 'Capture.open_logs':'Exclusive xb stdout.bin/stderr.bin creation.',
 'Capture.drain':'Drain through EOF; combined1MiB retention; overflow prefix explicitly incomplete, continue discard and fail.',
 'Capture.readback':'Require full EOF/noerror/seen==written plus whole stored hash; never admit prefix.',
 'result_readback':'Opaque complete bounded result file byte hash/stat; no JSON.',
 'runtime_flags':'Exact D90 Darwin CPython3.12.14 -I-S-B/assertions/optimize0 identity.',
 'validate_worker_terminal':'Only new helper: whole<=16KiB stdout metadata, exact9/cost6 types/literals/version/case/descriptor/status/plan/result, raw==encode; no scientific parse/counter/proof interpretation.',
 'preflight':'Inherited6-fieldplan/A6/8guard flow plus fixed newstudy/self, roles/schemas and exact5-case membership before consume.',
 'supervise':'Unchanged onePopen/two durable consumes/capture/monitor/reap/group/drain/fullreadback/census/8postguards/late resource gates. New metadata prerequisite/validator record before census, plus clock disclosures in custody/terminal/outer.',
 'supervise.issue':'Inherited deduplicated failure ledger, now also receives WORKER_TERMINAL.',
 'supervise.sample':'Inherited named SELF lifetime observations; origin unchanged.',
 'supervise.watchdog':'Inherited150sec fail-closed owned-group kill/os._exit124.',
 'main':'Inherited argparse and supervise/abort boundary; schema label only changed. No invocation/help performed.'
}
assert set(descriptions)==set(defs)
manual = {'schema':'L-state-propagation-observer-recovered-complete-helper-walk-v2','origin':origin,'ABI_original':oldhandoff['complete_packet']['ABI'],'ABI_exact_copy':amap['copy'],'current_static':statrow['stable_copy'],'all35_helpers':[{**r,'walk':descriptions[r['name']]} for r in fingerprints],'normal_terminal_prerequisites':['no prior issue','workerRc0','reaped child','owned group gone','joined drains','both complete full logs','positive whole own result pin'],'terminal_record_exact4':['validation_status','rawpin','metadata','error'],'failure_policy':'NOT_VALIDATED/VALIDATION_FAILED retains captured rawpin and precise reason, metadata null; WORKER_TERMINAL blocks normal outer. No partial-prefix result, stderr-empty gate or scientific getter.','immutability':'AllSource behavior is exact frozen38572/dd6e; unavailable old manual is not claimed byte-recovered. This new complete walk covers all35 helpers and module/global/main paths.','admission':'Both file receipts admitted_result null; outer scientific_admission false. Full caller terminal/exit0 and all transport/pin/resource/workerterminal gates plus separate scientific whole-case review required.','unchanged_globals':'Only ROLE_PATHS changed plus CASE_MAP/CLOCK_ORIGINS added; all caps/imports/timers and other base globals unchanged by original exact edit inverse.','no_science_or_authority':True}
manualrow = publish('state-propagation-observer-recovered-complete-helper-walk-v2.json',manual)
clock = {'schema':'L-state-propagation-observer-recovered-clock-guard-terminal-v2','origin':origin,'ABI_original':oldhandoff['complete_packet']['ABI'],'ABI_exact_copy':amap['copy'],'sites':locators,'worker_terminal_exact_unchanged_ABI':abi['worker_terminal'],'clock_precision':'Observer supervise entry excludes imports/argparse. Popen548 precedes launched553 AFTERreturn; waited592. Worker main-entry excludes interpreter/module startup. No cross-clock inequality. Worker clock/RSS samples precede final gate/callback count and terminal tail.','validation_order':'636 prerequisites/helper before662census,666 output readback sample and667 postguards. Parser/hash metadata work covered by later observer SELF captures.','late_observer':'695 after custody write/readback;720 after terminal write/readback;740 outer encode then flush/shutdown tail unmeasured.','resource_scope':'Waited child lifetime highwater +late observer SELF+16MiB allowance <=1GiB. No workerSELFdoublecount, exact simultaneous/tree peak, hardRSS or proved tail bound.','guard_scope':'Same5Sources+D90+plan+A6 full pre/post8. Worker Source guards before result writing retained separately; observer owns after-wait postguards.','caps_and_cases':abi['caps'],'external_cohort_gates':abi['cohort_external_gates'],'status':'Explicit new metadata successor; exact frozen Source unchanged and no Source execution.'}
clockrow = publish('state-propagation-observer-recovered-clock-guard-terminal-v2.json',clock)
exact = []
for k in ['Source','whole_delta_inverse','forward_patch','inverse_patch']:
    original = oldhandoff['complete_packet'][k]
    p = T/Path(original['path']).name
    b = p.read_bytes()
    assert len(b)==original['bytes'] and hashlib.sha256(b).hexdigest()==original['sha256']
    exact.append({'original':original,'exact_copy':pin(p,b)})
hand = {'schema':'L-state-propagation-observer-recovered-complete-Source-handoff-v2','status':'EXACT_FROZEN_SOURCE_WITH_HONEST_SUCCESSOR_METADATA_NO_EXECUTION','origin':origin,'exact_original_identity_recoveries':exact,'original_ABI_exact_copy':amap,'original_handoff_exact_copy':hmap,'successor_metadata':{'static':statrow,'all35_manual':manualrow,'clock_guard_terminal':clockrow},'interface':'No Source/strictplan6/A6/case-map/workerterminal9/cost6/literal/version/caps change. Only physical review aliases and metadata successor receipts.','preservation':'Whole30992 raw/positionedAST inverse, all35 spans,31old raw+AST unchanged, exactbothpatches and symtable/unusedcompile independently rebuilt from stablebytes. NewSource code never executed; inputs and originalfrozenfiles untouched.','unavailable_original_metadata':unavailable,'root_recovery_manifest':{'path':'/private/tmp/gcts-state-review-recovery-20261027-v2/manifest.json','bytes':47457,'sha256':'0c465f53630d702c397f02653b1c66a132996dd1bb7d1154b9ae5d4339f0a0c4'},'authoring_assets':[str(T/'reconstruct_observer_text_v1.py'),str(T/'regenerate_observer_metadata_v2.py')],'remaining':'C full current Source/ABI/helper review and Rootadoption; any later mechanical relocation strictly separate contract/rawinverse. No plan/A6/actual/scientific/publication grant.','operations':{'Source_or_project_function_or_codeobject_execution':0,'fixture_model_test_CLI_help_actual_or_result_intake':0,'original_or_failed_partial_target_read_retry':0,'plan_A6_consume_actual_network_publication':0},'output_policy':'Each output written/fsynced/read back FIRST to stable/tmp, then exclusive fresh repository mirror; no old overwrite.'}
handrow = publish('state-propagation-observer-recovered-complete-Source-handoff-v2.json',hand)
print(json.dumps({'handoff':handrow,'successor_metadata':records[:-1],'exact_Source_sha256':hashlib.sha256(sb).hexdigest(),'Source_execution':False},indent=2))
