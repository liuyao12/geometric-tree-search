"""Independent administrative Source/AST audit, never executes project code."""
from pathlib import Path
import ast
import builtins
import datetime
import difflib
import hashlib
import json
import os
import symtable
import sys

T=Path('/private/tmp/gcts-L-compiler-peer-review-20261027-v1')
S=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-state-propagation-20261027')
D=S/'custody-L'
mirror=D/'compiler-peer-review-recovery-v1'
mirror.mkdir(mode=0o700)
mp=Path('/private/tmp/gcts-state-review-recovery-20261027-v2/manifest.json')
mb=mp.read_bytes()
assert len(mb)==47457 and hashlib.sha256(mb).hexdigest()=='0c465f53630d702c397f02653b1c66a132996dd1bb7d1154b9ae5d4339f0a0c4'
M=json.loads(mb)

def pin(p,b):
    return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}

def alias(original):
    row=M['mapping'][str(original)]
    p=Path(row['copy']['path'])
    b=p.read_bytes()
    assert pin(p,b)==row['copy']
    assert row['original']['bytes']==len(b) and row['original']['sha256']==hashlib.sha256(b).hexdigest()
    return b,row

hb,hr=alias(S/'implementation-B/state-propagation-production-compiler-complete-Source-handoff-v1.json')
assert len(hb)==5661 and hashlib.sha256(hb).hexdigest()=='4708311027a43c33af868197529193d3573ce25f956a37d4aecbc075bc6a6f3e'
h=json.loads(hb)
sb,sr=alias(Path(h['subject']['path']))
assert len(sb)==16921 and hashlib.sha256(sb).hexdigest()=='a9008d0edeb3465f1af0e00319fc2fb1e139c9a918058b0d77931ecf3c67e940'
bp=Path('/private/tmp/gcts-tableau-base-archive-recovery-20261027-v1/finite_local_table_tableau_v1.py')
bb=bp.read_bytes()
assert len(bb)==9319 and hashlib.sha256(bb).hexdigest()==h['base']['sha256']=='37753b8faf9c655ce18edf1ed150645d829fb8c335119eea91303536af5d37e8'
eb,er=alias(D/'state-production-compiler-prefrozen-complete-Source-review-expectations-v1.json')
assert len(eb)==17911 and hashlib.sha256(eb).hexdigest()=='5c8baf949196ce163cdfab0a295b9ac31edd97396353002b168778d27608cd1c'
expect=json.loads(eb)
assert expect['subject_announced_only']==h['subject'] and expect['exact_recovered_prefix']==h['base']
engine,engine_alias=alias(Path(h['engine_unchanged']['path']))
assert len(engine)==28697 and hashlib.sha256(engine).hexdigest()=='ef8332761c5f5a8902ff122199f5938b65db90fe9bf46355e185926dccb6a897'
assert sb[:9319]==bb and len(sb[9319:])==7602
text,base=sb.decode(),bb.decode()
tree,bt,append=ast.parse(text),ast.parse(base),ast.parse(sb[9319:])
assert [ast.dump(x,include_attributes=True) for x in tree.body[:len(bt.body)]]==[ast.dump(x,include_attributes=True) for x in bt.body]
funcs={x.name:x for x in tree.body if isinstance(x,ast.FunctionDef)}
bfuncs={x.name:x for x in bt.body if isinstance(x,ast.FunctionDef)}
classes={x.name:x for x in tree.body if isinstance(x,ast.ClassDef)}
assert (len(funcs),len(bfuncs),len(classes))==(23,13,2)
records=[]
for name,n in funcs.items():
    raw=''.join(text.splitlines(True)[n.lineno-1:n.end_lineno]).encode()
    old=name in bfuncs
    if old:
        assert ast.dump(n,include_attributes=True)==ast.dump(bfuncs[name],include_attributes=True)
    records.append({'name':name,'line':n.lineno,'end_line':n.end_lineno,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'AST_sha256':hashlib.sha256(ast.dump(n).encode()).hexdigest(),'inherited_exact':old})
assert [type(x).__name__ for x in append.body]==['Import','Assign','ClassDef']+['FunctionDef']*10
assert len(append.body[0].names)==1 and append.body[0].names[0].name=='json' and append.body[0].names[0].asname=='_state_json'
new_names=['_state_json','STATE_VERSION','StateMarkingError']+[x.name for x in append.body if isinstance(x,ast.FunctionDef)]
old_names={x.name for x in bt.body if isinstance(x,(ast.FunctionDef,ast.ClassDef))}|{n.id for x in bt.body if isinstance(x,ast.Assign) for n in x.targets if isinstance(n,ast.Name)}
assert not old_names.intersection(new_names)
assert not any(isinstance(x,(ast.Global,ast.Nonlocal,ast.NamedExpr)) for x in ast.walk(append))
for name,n in classes.items():
    assert len(n.body)==1 and isinstance(n.body[0],ast.Expr) and isinstance(n.body[0].value,ast.Constant)
    assert len(n.bases)==1 and isinstance(n.bases[0],ast.Name) and n.bases[0].id=='ValueError'
closure=[]
for name,n in funcs.items():
    if name in bfuncs: continue
    named=sorted({x.func.id for x in ast.walk(n) if isinstance(x,ast.Call) and isinstance(x.func,ast.Name)})
    attrs=sorted({ast.unparse(x.func) for x in ast.walk(n) if isinstance(x,ast.Call) and isinstance(x.func,ast.Attribute)})
    assert not {'compile_tableau','decode_tableau','state_augment_model','state_erase_model','open','compile','exec','eval','getattr','setattr','__import__'}.intersection(named)
    closure.append({'name':name,'named_calls':named,'attribute_calls':attrs})
for public in ['state_augment_model','state_erase_model']:
    n=funcs[public]
    assert len(n.args.args)==2 and not n.args.defaults and n.args.vararg is None and n.args.kwarg is None and not n.decorator_list
for value,filename in [(base,h['base']['path']),(text,h['subject']['path'])]:
    unused=compile(value,filename,'exec',dont_inherit=True,optimize=0)
    del unused
symbols=symtable.symtable(text,h['subject']['path'],'exec')
known=set(symbols.get_identifiers())|set(dir(builtins))
unresolved=[]
def scan(t,path='module'):
    for x in t.get_symbols():
        if x.is_referenced() and x.is_global() and x.get_name() not in known:
            unresolved.append([path,x.get_name()])
    for child in t.get_children():scan(child,path+'/'+child.get_name())
scan(symbols)
assert unresolved==[]
def scope(t):
    return {'name':t.get_name(),'type':t.get_type(),'symbols':sorted(t.get_identifiers()),'children':[scope(c) for c in t.get_children()]}
derived={}
for key,a,b,fromp,top in [('forward_patch',base,text,h['base']['path'],h['subject']['path']),('inverse_patch',text,base,h['subject']['path'],h['base']['path'])]:
    raw=''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile=fromp,tofile=top)).encode()
    p=T/('independent-'+key+'-v1.patch')
    with p.open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
    assert p.read_bytes()==raw
    cp=mirror/p.name
    with cp.open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
    offered=h['metadata'][key]
    derived[key]={'derived_copy':pin(p,raw),'repo_mirror':pin(cp,raw),'offered_original_pin':offered,'full_bytes_hash_match_offered':len(raw)==offered['bytes'] and hashlib.sha256(raw).hexdigest()==offered['sha256']}
unavailable=[]
for k,r in h['metadata'].items():
    assert r['path'] not in M['mapping']
    unavailable.append({'role':k,'original':r,'status':'UNAVAILABLE_ORIGINAL_BODY_NOT_AN_ALIAS','historical_intake':'API/manual/prefix/static/census text was fully read before eviction; helper-fingerprint structure inspected. No current fresh raw body/hash join claimed. Offered patch bytes only if independently derived full hash matches.'})
rootpin=expect['Source_contract']
assert rootpin==h['contract']
notes={
 '_need':'Unchanged sole-code TableauError guard.',
 '_keys':'Exact dict and exact string fieldset, key insertion order ignored.',
 '_same_exact':'Recursive type-exact full equality and list order; no bool/int or tuple/list coercion.',
 '_normalize_spec':'Unchanged complete27-row spec normalization/detachment and five-stage error order.',
 '_state':'Unchanged S: symbol encoding.',
 '_pair':'Unchanged P: ordered pair encoding.',
 '_computation_id':'Unchanged C: triple ID encoding.',
 '_compile_normalized':'Unchanged full33palette/rectangle/all exposed boundaries.',
 'compile_tableau':'Unchanged public compiler; new APIs never call it.',
 '_canonical_bundle':'Unchanged entire type-exact canonical bundle reconstruction via private normalization/building, catches only TableauError.',
 '_assignment_grid':'Unchanged complete typed assignment validation.',
 '_check_colors':'Unchanged every internal/exposed color check.',
 'decode_tableau':'Unchanged whole inverse/row kinds/recurrence/ghost/guard/words; new APIs never call it.',
 '_state_need':'StateMarkingError(ValueError) with sole code; no details or scientific-result conversion.',
 '_state_bundle':'Bundle validation before model intake; maps only inherited TableauError to STATE_BUNDLE_CANONICAL.',
 '_state_point':'Exact two-int list, bool/float/subclass refused; private tuple for uniqueness only.',
 '_state_model_shape':'All exact five-field model/schema/positive-capacity and unique required/ID/t-slot/m-slot/seed-reference rules. Sorting, freshness, seed sums and whole association remain outside shape. Empty typed values allowed except nonempty t.',
 '_state_compact':'Only stdlib JSON ensure_ascii compact identities, no IO/cache.',
 '_state_copy':'Fresh dict/list per occurrence, immutable primitives only on private expected-data path; no memoized sharing.',
 '_state_baseline_model':'Reconstruct all33types at EVERY cell, exact compact ID/type/translation/unit t and WANG rows. Full grouped exterior collars/inward patterns; coordinate-order seeds, sorted required union/records/m. No engine import, row shortlist, trajectory, co-selection or summed candidate legality.',
 '_state_augmented_model':'Fresh copy of private baseline. All C four-row and I/O one-row STATE prototypes from raw supplied table/types, translated at every ordinary record including wrong-kind fringe. Skip canonical collar seed IDs only; sort m. Private baseline unmodified.',
 'state_augment_model':'Bundle then shape then ANY STATE anywhere then complete baseline equality, then fresh whole augmentation; no public recursion/compile.',
 'state_erase_model':'Bundle then shape then full expected augmented model equality BEFORE return. Fresh canonical baseline returned, never generic strip/projection-only admission.'
}
assert set(notes)==set(funcs)
def publish(name,obj):
    b=(json.dumps(obj,indent=2,sort_keys=True)+'\n').encode()
    p=T/name
    with p.open('xb') as f:f.write(b);f.flush();os.fsync(f.fileno())
    assert p.read_bytes()==b
    cp=mirror/name
    with cp.open('xb') as f:f.write(b);f.flush();os.fsync(f.fileno())
    assert cp.stat().st_size==len(b)
    return {'stable_copy':pin(p,b),'repo_mirror':pin(cp,b)}
audit={'schema':'L-state-production-compiler-recovered-complete-independent-static-audit-v2','issued_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'subject':h['subject'],'subject_exact_alias':sr,'warm_base':pin(bp,bb),'base_original':h['base'],'handoff_exact_alias':hr,'prefrozen_expectations_exact_alias':er,'Source_contract_pin_previously_fully_read':rootpin,'Source_contract_body_now_unavailable':True,'engine_exact_opaque_alias_checked':engine_alias,'checks_passed':True,'blockers':[],'raw9319_prefix_and_all_old_positioned_AST_equal':True,'suffix7602_sha256':hashlib.sha256(sb[9319:]).hexdigest(),'all23_function_fingerprints_and_static_walk':[{**r,'walk':notes[r['name']]} for r in records],'classes_doc_only_ValueError':['TableauError','StateMarkingError'],'new_bindings':new_names,'no_old_binding_global_nonlocal_namedexpr_rebound':True,'new_complete_call_closure':closure,'new_public_internal_invocations':0,'unresolved_globals':unresolved,'complete_current_symtable':scope(symbols),'unused_compile':'Base and new code objects created/discarded without execution.','independent_derived_patches':derived,'unavailable_original_B_supports':unavailable,'original_support_fresh_hash_closure_claimed':False,'operations':{'project_import_function_model_fixture_test_CLI_help_or_Source_codeobject_execution':0,'C_implementation_or_actual_result_intake':0,'old_original_or_failed_partial_target_retry':0,'plan_A6_actual_network_publication':0},'runtime':{'path':sys.executable,'version':sys.version,'isolated':sys.flags.isolated,'no_site':sys.flags.no_site,'dont_write_bytecode':sys.dont_write_bytecode,'optimize':sys.flags.optimize}}
ar=publish('state-production-compiler-recovered-complete-independent-static-audit-v2.json',audit)
review={'schema':'L-state-production-compiler-complete-independent-Source-review-v1','issued_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'decision':'PASS_COMPLETE_EXACT_SOURCE_WITH_ORIGINAL_SUPPORT_BODY_UNAVAILABILITY_EXPLICIT','review_passed':True,'component_Source_accepted':True,'blockers':[],'changes_requested':[],'subject':h['subject'],'subject_exact_alias':sr,'prefrozen_expectations_exact_alias':er,'complete_independent_static_audit':ar,'Source_contract':rootpin,'offered_handoff_exact_alias':hr,'coverage':'Entire16921-byte373-line Source including all13 inherited and10 new functions/two classes read before eviction and reauthenticated through exact alias. Full API13114/manual21399/prefix9027/static5408/census12424 text read before eviction. Eight current original support bodies remain unavailable, not fresh rawhash-joined; own current Source/AST/helper/call/prefix audit and full interface judgment replace no missing scientific evidence. No C internals used.',
 'preservation':'Complete first9319 rawbytes equal exact warm published baseline; entire inherited positioned module AST,13functions/class/globals unchanged. Append is only json as_state_json, STATE_VERSION, doc-only StateMarkingError and10 uniquely named functions; no hidden rebind/cache/IO/project import/top scientific call.',
 'canonical_model_builder':'Private whole-data reconstruction checks all33palette types at all region cells, exact compactIDs/types/translations/unit support/WANG rows, complete exterior-neighbor grouped collar IDs/types/inward marks, numeric coordinate seed ordering, sorted required union/records/m and five-field capacity1. No geometry predicate, intended-row/known-trace shortlist or treating candidates as co-selected. Equal-field comparison uses inherited recursive exact types/list order; dict key order immaterial.',
 'shape':'Source exactly implements Root common structural/uniqueness/known-seed gate. Capacity positive exactint, point/translation exact2intlists, t nonempty distinct positive exact3ints within declared capacity, m distinct point/channel exact4rows of int/int/str/str, unique IDs and valid unique seeds. It deliberately permits empty typed strings/lists where allowed and does not hide sorting/freshness/family association.',
 'augmentation':'STATE_BUNDLE_CANONICAL precedes STATE_MODEL_SHAPE; any exact STATE channel anywhere after shape yields STATE_NOT_FRESH before other baseline mismatch. Literal string0 assigned, numeric0/bool fails shape. Entire baseline equality required, then all C offsets and I/O cap prototypes at every ordinary placement, even wrong-kind fringe; no collar STATE/t/Q/ID/order/WANG changes.',
 'erasure':'Full canonical bundle and shape before full expected AUGMENTED equality. Every original field and every added STATE row/list order required before fresh baseline return. No generic channel stripping or projected-only acceptance.',
 'errors':'New doc-only ValueError subclass distinct from unchanged TableauError; _state_need sole-code strings. Only known inherited TableauError maps to new bundle code; programming/unexpected failures not disguised. Hand control-flow inspection covers A01-A13/E01-E13 and all precedence collisions without constructing mutated inputs or calling APIs.',
 'case_code_source_gates':{'A01_A02_A11':'bundle wrapper223-228','A03_A04_A05_A06_A12':'shape237-281 before freshness','A07_A08':'complete baseline equality362','A09_A10_A13':'all-mark STATE scan359-360 before baseline','E01_E12':'bundle first368','E02_E03_E04_E13':'shape first369','E05_E06_E07_E08_E09_E10_E11':'whole augmented equality372 before return373'},
 'detachment':'Caller arguments are only read/compared. Canonical reconstruction allocates fresh list/dict data; baseline builder independently allocates every coordinate/translation/t/m/list occurrence. Augmentation recursively copies each mutable occurrence before extend/sort, skipping only seed IDs; no memoization/shared mutable sublist. Erasure returns separately built baseline unmodified by expected augmentation. Global state immutable except stdlib module binding; no retained input/model cache.',
 'public_call_census':'Neither new API calls any new public API, old compile_tableau or decode_tableau. Shared private canonical/builders only, preserving declared API14augment/14erase from one success+13negatives each, one compile_tableau+one purecompile_wang preparatory context. Benchmark extra construction/erase remains in treatment; no hidden contexts/Engine/tests created by this review.',
 'limits_and_gaps':['All new runtime API error/purity/model/graph/result/fit checks remain UNRUN by this review. Syntax/static proof is not execution.','Production constructor generic over old admitted canonical widths/steps/tables; later runtime API context is only primaryW5T2, not runtime T0/alternate qualification.','Fresh STATE redundancy depends on adopted finite rectangle/channel/translation/collar context and independently checking whole encoded models; no learner/RL/FOL/universal/infinite/geometric/performance result.','Pure APIs have no internal budget callback; future global before/after guard does not promise arbitrary hostile-extent runtime fit.','Original B8 support bodies unavailable after complete text intake. Their declared hashes remain references, not verified current aliases; no failed target or placeholder retried. Root may regenerate honest support successors.'],
 'source_recovery_boundary':{'root_manifest':pin(mp,mb),'failed_reader_history':'Own session29188 first offeredSource reread stalled; interrupted terminal130 before auditwrite/science. Root bounded aliases then supplied; only successful mapping copies used.','new_output_policy':'Stable/tmp first, then new exclusive repo mirrors; all frozen originals preserved.','unavailable_supports':unavailable},
 'operations':{'project_Source_import_helper_function_model_fixture_API_call_CLI_help_test':0,'codeobject_execution':0,'C_implementation_intake':0,'scientific_actual_library_or_result_intake':0,'plan_A6_actual_network_publication':0,'old_original_or_partial_target_retry':0},'scientific_execution_authorized':False,'publication_authorized':False,'next':'Root full Source/peer adoption and any separately reviewed mechanical relocation before future exact plans/A6. No once/retry or Source change follows this PASS.','terminal_state':'Independent Source-only review complete, all administrative commands terminal; no scientific process started.'}
rr=publish('state-production-compiler-complete-independent-Source-review-v1.json',review)
print(json.dumps({'review':rr,'static_audit':ar,'derived_patches':derived,'review_passed':True,'Source_functions_executed':0},indent=2))
