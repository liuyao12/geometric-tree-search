"""Publication content metadata/HTML/math Source joins only; no scientific replay."""
from pathlib import Path
from html.parser import HTMLParser
import datetime
import hashlib
import json
import math
import os
import re
import xml.etree.ElementTree as ET

OUT = Path('/private/tmp/gcts-L-state-public-content-review-20261027-v1')
ROOT = Path('/private/tmp/gcts-state-publication-20261027-v1/root')
MIRROR = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-state-propagation-20261027/custody-L/public-content-review-v1')

def ref(path, size, digest):
    return {'path': str(path), 'bytes': size, 'sha256': digest}

def rawpin(path, body):
    return ref(path, len(body), hashlib.sha256(body).hexdigest())

def pinned(record):
    b = Path(record['path']).read_bytes()
    assert rawpin(record['path'], b) == record
    return b

def unique(pairs):
    result = {}
    for key, value in pairs:
        assert key not in result
        result[key] = value
    return result

def reject(value):
    raise ValueError(value)

def parse(b):
    return json.loads(b.decode('utf-8'), object_pairs_hook=unique, parse_constant=reject)

def save(name, obj):
    b = (json.dumps(obj, sort_keys=True, indent=2, ensure_ascii=False, allow_nan=False) + '\n').encode()
    p = OUT / name
    with p.open('xb') as h:
        h.write(b); h.flush(); os.fsync(h.fileno())
    assert p.read_bytes() == b
    with (MIRROR / name).open('xb') as h:
        h.write(b); h.flush(); os.fsync(h.fileno())
    assert (MIRROR / name).read_bytes() == b
    return rawpin(p, b)

class Inspect(HTMLParser):
    def __init__(self, strict=False):
        super().__init__(); self.ids = []; self.hrefs = []; self.tags = []; self.events = []; self.stack = []; self.strict = strict; self.table_rows = []; self.row = None; self.cell = None; self.clock_ancestors = None
    def handle_starttag(self, tag, attributes):
        attrs = dict(attributes); self.tags.append(tag)
        if 'id' in attrs:
            self.ids.append(attrs['id'])
        if attrs.get('id') == 'tableau-clock-correction':
            self.clock_ancestors = list(self.stack)
        if 'href' in attrs:
            self.hrefs.append(attrs['href'])
        self.events.extend((tag, k, v) for k, v in attributes if k.startswith('on'))
        if tag == 'tr': self.row = []
        if tag in ('td', 'th'): self.cell = ''
        if tag not in ('br', 'hr', 'meta', 'link', 'img', 'input'):
            self.stack.append(tag)
    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs); self.handle_endtag(tag)
    def handle_endtag(self, tag):
        if tag in ('td', 'th'):
            if self.row is not None: self.row.append(self.cell.strip())
            self.cell = None
        if tag == 'tr':
            self.table_rows.append(self.row); self.row = None
        if self.stack and self.stack[-1] == tag: self.stack.pop()
        elif self.strict: raise AssertionError(('unbalanced HTML', tag, self.stack))
    def handle_data(self, data):
        if self.cell is not None: self.cell += data

expect_pin = ref(OUT / 'state-propagation-public-content-prefrozen-review-criteria-v1.json', 3377, '34688d40e11c38f8554c17b9528e7586529237477f5f266450ed22ff99ea1513')
expect = parse(pinned(expect_pin))
facts_pin, v2_pin = expect['subjects']
facts_b = pinned(facts_pin); facts = parse(facts_b)
v2 = pinned(v2_pin)
v3_pin = ref(ROOT / 'state-propagation-public-report-fragment-v3.html', 12524, 'c06ca5be9ca76ab47ba1406728a3db931b1d1ac7e15bb4d9745bda10b5a737bc')
v3 = pinned(v3_pin); html = v3.decode()
old_phrase = b'with no engine or search call.'
new_phrase = b'without instantiating the search engine or calling <code>solve</code>. The pure <code>compile_wang</code> construction was included.'
assert v2.count(old_phrase) == 1 and v3.count(new_phrase) == 1
assert v2.replace(old_phrase, new_phrase) == v3 and v3.replace(new_phrase, old_phrase) == v2
boundary_pin = ref(ROOT / 'state-propagation-selected-evidence-boundary-v1.json', 4228, '21436a2330e6f5230ebf1ee1b27a5040221a9739fdd2ca697a99a7eefef300b2')
boundary = parse(pinned(boundary_pin))
base_pin = ref('/private/tmp/gcts-last-live-report-github-recovery-20261027-v1/point-proof-parallel-progress-v1.html', 191052, 'd006ead3521749f50d9fcc841f2ba92c4e22e16b1dea7a0a58391f393b24583a')
base = pinned(base_pin); base_text = base.decode()
math_manifest_path = Path('/private/tmp/gcts-tableau-base-archive-recovery-20261027-v1/reference-documents-v1/manifest.json')
math_manifest_b = math_manifest_path.read_bytes(); math_manifest = parse(math_manifest_b)
math_ref = math_manifest['files']['supplied-tableau-STATE-extended-marking-redundancy-mathematical-review-v1.json']
math_pin = {k: math_ref[k] for k in ('path', 'bytes', 'sha256')}
proof = parse(pinned(math_pin))
assert proof['decision'].startswith('The proposed fresh STATE channel preserves the ENTIRE')
adoptions = []
for record in facts['whole_case_adoptions']:
    adoptions.append(parse(pinned(record)))
assert len(adoptions) == 5 and [o['case_id'] for o in adoptions] == facts['exact_order']
assert all(o['Source_A6'] == 'PERMANENTLY_CONSUMED_NO_RETRY' for o in adoptions)
assert facts['status'] == 'ALL_FIVE_PREDECLARED_ONCE_ATTEMPTS_ADMITTED_COMPLETE'
api = adoptions[0]; api_f = facts['API_qualification']; api_counts = api['accepted_counts']
assert api['status'] == 'ADMITTED_COMPLETE_API_QUALIFICATION_PASS'
assert api_f['Engine_calls'] == api_counts['engine_instances'] == 0 and api_f['solve_calls'] == api_counts['solve_calls'] == 0
assert api_f['production_negative_cases'] == api_counts['production_negative_cases'] == 26
assert api_f['independent_negative_cases'] == api_counts['independent_oracle_negative_cases'] == 4
assert api_f['malformed_controls'] == 30 == 26 + 4
assert api_counts['compile_tableau_calls'] == api_counts['compile_wang_calls'] == 1
assert api_f['worker_pre_serialization_seconds'] == api['costs']['worker_pre_serialization_costs']['elapsed_seconds_before_serialization']
assert api_f['worker_post_full_readback_seconds'] == api['costs']['worker_post_full_readback_costs']['elapsed_seconds']
assert api_f['separate_from_benchmark_costs'] is True
row_joins = []
named_components = [api['named_attempt_artifact_bytes']]
for index, (row, adoption) in enumerate(zip(facts['rows'], adoptions[1:], strict=True)):
    assert row['case_id'] == adoption['case_id'] and row['whole_case_adoption'] == facts['whole_case_adoptions'][index + 1]
    assert row['whole_result_rawpin'] == adoption['whole_result']
    if index == 0:
        cost = adoption['costs']['worker_preserialization']; late = adoption['costs']['worker_after_full_result_readback']; resources = adoption['costs']
        counters = adoption['accepted_counters']; metrics = counters['final_solve_metrics']
        expected_scalars = {key: counters[key] for key in ['nodes', 'branch_decisions', 'backtracks', 'forced_placements', 'accepted_placements_cumulative', 'final_selected']}
        assert adoption['status'] == 'ADMITTED_COMPLETE_POSITIVE_BASELINE_RESULT'
        assert row['status'] == 'FINITE_EXACT_SOLUTION'
        status_precision = 'Positive baseline status translated from Root positive whole-result admission/counters; its adopted document has no duplicate raw engine_status field. No raw result body reopened.'
        named_components.append(adoption['named_attempt_artifact_bytes'])
    else:
        cost = adoption['costs']; late = adoption['post_full_readback_costs']; resources = adoption['clock_and_resource_scope']
        result = adoption['observed_result'] if index == 1 else adoption['current_finite_result']
        metrics = result['metrics'] if index == 1 else result['final_metrics'] if index == 2 else result['fullfinal_metrics']
        expected_scalars = {'nodes': result['nodes'], 'branch_decisions': metrics['branch_decisions'], 'backtracks': metrics['backtracks'], 'forced_placements': metrics['forced_placements'], 'accepted_placements_cumulative': metrics['accepted_base_placements'], 'final_selected': result['selected'] if index == 1 else result['returned_selected_count']}
        assert row['status'] == result['status'] == adoption['accepted_counts']['engine_status']
        assert adoption['accepted_counts']['raw_history_examinations'] == 19683
        assert adoption['accepted_counts']['direct_calls']['Engine'] == adoption['accepted_counts']['direct_calls']['solve'] == 1
        assert adoption['accepted_counts']['stable_engine_audits'] == cost['stable_audits']
        status_precision = 'Exact scalar engine status in current accepted metadata matches.'
        named_components.append(resources['current_named_artifact_bytes'])
    for key, value in expected_scalars.items(): assert row[key] == value
    assert row['full_costs'] == cost and row['full_post_readback_costs'] == late and row['resource_clock_scope'] == resources
    assert row['stable_audits'] == cost['stable_audits']
    assert row['solve_with_audits_seconds'] == cost['phases']['solve_with_audits']['elapsed_seconds']
    assert row['worker_pre_serialization_seconds'] == cost['elapsed_seconds_before_serialization']
    assert row['worker_post_full_readback_seconds'] == late['elapsed_seconds']
    assert row['worker_lifetime_peak_bytes'] == late['self_lifetime_highwater_bytes'] == resources['child_lifetime_highwater_bytes']
    assert cost['phases']['API_controls'] is None
    assert (cost['phases']['treatment_construction_check'] is None) == (row['arm'] == 'BASELINE')
    assert all(type(v['budget_callbacks']) is int and v['budget_callbacks'] >= 0 and math.isfinite(v['elapsed_seconds']) and v['elapsed_seconds'] >= 0 for v in cost['phases'].values() if v is not None)
    assert sum(v['budget_callbacks'] for v in cost['phases'].values() if v is not None) == cost['worker_budget_callbacks_before_serialization']
    assert late['worker_budget_callbacks_before_terminal_encoding'] == cost['worker_budget_callbacks_before_serialization'] + 4
    assert 0 <= cost['elapsed_seconds_before_serialization'] <= late['elapsed_seconds'] < 90
    allowance = resources.get('declared_allowance_bytes', resources.get('allowance_bytes'))
    summed = resources.get('sum_of_separate_maxima_plus_allowance_bytes', resources.get('sum_separate_maxima_plus_allowance_bytes'))
    assert allowance == 16777216
    assert summed == resources['child_lifetime_highwater_bytes'] + resources['late_observer_lifetime_highwater_bytes'] + allowance <= facts['limits']['memory_bytes']
    row_joins.append({'row': index, 'case_id': row['case_id'], 'all_scalar_counts_exact': expected_scalars, 'stable_audits': row['stable_audits'], 'full_pre_serialization_costs_all_phases_exact': True, 'full_post_readback_costs_all6_fields_exact': True, 'complete_resource_scope_exact': True, 'phase_budget_sum_and_4late_gates_match': True, 'RSS_sum_with_allowance_bytes': summed, 'status_association_precision': status_precision, 'worker_pre_seconds': row['worker_pre_serialization_seconds'], 'worker_late_seconds': row['worker_post_full_readback_seconds'], 'rounded_late_seconds': f'{row["worker_post_full_readback_seconds"]:.3f}'})
assert [row['context'] for row in facts['rows']] == ['PRIMARY_ACCEPTED', 'PRIMARY_ACCEPTED', 'PRIMARY_IMPOSSIBLE_FINAL', 'PRIMARY_IMPOSSIBLE_FINAL']
assert [row['arm'] for row in facts['rows']] == ['BASELINE', 'CERTIFIED_STATE', 'CERTIFIED_STATE', 'BASELINE']
assert sum(row['stable_audits'] for row in facts['rows']) == facts['benchmarks']['whole_stable_audits'] == 224
assert 4 * 19683 == facts['benchmarks']['raw_history_examinations_all4_arms'] == 78732
assert sum(named_components) == facts['benchmarks']['named_attempt_artifact_bytes'] == 47158150
assert named_components[-1] == 10289771 and facts['benchmarks']['named_cap_bytes'] == 402653184
assert facts['limits'] == {'worker_seconds': 90, 'custody_seconds': 120, 'observer_seconds': 150, 'memory_bytes': 1073741824, 'result_bytes': 67108864, 'log_bytes': 1048576, 'observer_reserve_bytes': 16777216}
assert adoptions[2]['strict_forecast']['matched'] is True and adoptions[2]['strict_forecast']['observed'] == adoptions[2]['strict_forecast']['expected']
model = facts['model']; model_evidence = api['accepted_model_evidence']; selected = adoptions[2]['observed_result']
for fact_key, adopted_key in [('STATE_static_slots', 'STATE_static_slots'), ('added_STATE_assignments', 'added_STATE_rows'), ('augmented_total_mark_assignments', 'augmented_m_rows'), ('baseline_WANG_assignments', 'baseline_m_rows'), ('collar_seeds', 'seeds'), ('total_placements', 'ordered_placements'), ('required_points', 'required')]: assert model[fact_key] == model_evidence[adopted_key]
assert model['region_cells'] == selected['assignment_cells'] == 20
assert model['selected_positive_STATE_assignments'] == selected['selected_STATE_assignments'] == 50 and model['selected_positive_STATE_slots'] == selected['selected_STATE_slots'] == 19
assert model['width'] == 5 and model['steps'] == 2 and model['palette_types'] == 33
assert model['ordinary_placements'] == 20 * 33 == 660 and model['total_placements'] == 660 + 18 == 678
assert 114 * 5 * (2 + 2) == model['added_STATE_assignments'] and (2 + 2) * (5 + 2) + 5 == model['STATE_static_slots']
bp = Inspect(); bp.feed(base_text)
fp = Inspect(strict=True); fp.feed(html)
assert not fp.stack and len(fp.ids) == len(set(fp.ids)) == 10 and len(bp.ids) == len(set(bp.ids)) == 48
assert not set(fp.ids).intersection(bp.ids) and not fp.events
assert not {'html', 'head', 'body', 'script', 'iframe', 'object', 'embed', 'sup', 'sub'}.intersection(fp.tags)
assert fp.hrefs == ['#finite-tableau-current', 'point-proof-state-propagation-summary-v1.json', 'point-proof-state-propagation-evidence-v1.zip']
assert 'finite-tableau-current' in bp.ids and 'details' not in fp.clock_ancestors
assert len(fp.table_rows) == 5 and all(len(row) == 8 for row in fp.table_rows)
for cells, row in zip(fp.table_rows[1:], facts['rows'], strict=True):
    assert [cells[i] for i in range(3, 7)] == ['\\(' + str(row[k]) + '\\)' for k in ['nodes', 'branch_decisions', 'backtracks', 'stable_audits']]
    assert cells[7] == '\\(' + f'{row["worker_post_full_readback_seconds"]:.3f}' + '\\,\\mathrm{s}\\)'
opens = html.count('\\('); closes = html.count('\\)')
assert opens == closes == 40 and html.count('\\[') == html.count('\\]') == 0
state = False
for token in re.findall(r'\\[()]', html):
    assert token == ('\\)' if state else '\\(')
    state = not state
assert not state
assert "inlineMath:[['\\\\(','\\\\)']]" in base_text and 'mathjax@3/es5/tex-chtml.js' in base_text
assert base.count(b'<body>') == 1
anchor = base.index(b'<body>') + len(b'<body>')
assert anchor == 4300
assembled_in_memory = base[:anchor] + v3 + base[anchor:]
assert assembled_in_memory[:anchor] + assembled_in_memory[anchor+len(v3):] == base
assert len(assembled_in_memory) == 203576
del assembled_in_memory
assert 'Worker launch to wait' in base_text and 'Complete observed worker lifetime' in base_text
assert '\\(4.37\\,\\mathrm{s}\\)' in html and 'after <code>Popen</code> returns' in html and 'must not be subtracted' in html
svg_text = re.search(r'<svg\b.*?</svg>', html, flags=re.S).group()
svg = ET.fromstring(svg_text)
groups = list(svg.iter('g'))
orange = next(g for g in groups if g.attrib.get('fill') == '#f59e0b' and g.attrib.get('stroke') == '#92400e')
points = {(int(c.attrib['cx']), int(c.attrib['cy'])) for c in orange.findall('circle')}
assert points == {(120,160), (240,160), (360,160), (240,280)}
assert all((x-240) % 60 == (y-220) % 60 == 0 for x,y in points)
offsets = sorted(((x-240)//60, (y-220)//60) for x,y in points)
assert offsets == [(-2,-1), (0,-1), (0,1), (2,-1)]
green = next(g for g in groups if g.attrib.get('fill') == 'white' and g.attrib.get('stroke') == '#047857')
green_points = {(int(c.attrib['cx']), int(c.attrib['cy'])) for c in green.findall('circle')}
assert green_points == {(240,160), (180,220), (300,220), (240,280)}
assert points.intersection(green_points) == {(240,160),(240,280)}
assert 'Schematic of the marking rule, not an observed search state.' in html and 'not additional matching rules' in html
assert len(boundary['historical_recovery_gaps']) == 3 and boundary['history_receipt_precision'].startswith('Each19683history enumeration retains its full seven-field')
assert 'not_recursive_history' in boundary and 'evidence-boundary record and catalogue' in html
assert pinned(facts_pin) == facts_b and pinned(v3_pin) == v3 and pinned(base_pin) == base
support = {
    'schema': 'L-state-propagation-public-content-complete-metadata-HTML-support-v1', 'review_passed': True, 'blockers': [],
    'criteria': expect_pin, 'facts': facts_pin, 'superseded_fragment_v2': v2_pin, 'current_fragment_v3': v3_pin, 'baseline_Source_scaffold_only': base_pin, 'selected_evidence_boundary': boundary_pin,
    'five_adoption_metadata_fullpins_parsed_ONLY': facts['whole_case_adoptions'], 'four_complete_row_joins': row_joins,
    'API_metadata_join': {'zero_Engine_instances': True, 'zero_solve': True, 'one_pure_compile_wang': True, 'malformed_controls': 30, 'production26_independent4': True, 'costs_separate': True},
    'aggregate_metadata_arithmetic': {'audits': 224, 'raw_history_examinations': 78732, 'named_components': named_components, 'named_total': 47158150},
    'model_metadata_and_paper_count_joins': model,
    'static_math_reference': math_pin, 'math_manifest_rawpin': rawpin(math_manifest_path, math_manifest_b),
    'math_scope': 'Agent-derived static complete-solution-set redundancy proof, not engine-discovered theorem. Current figure geometry and finite footprint counts compared on paper; no table/trajectory/model/checker execution or reconstruction.',
    'full_v3_delta': {'old': old_phrase.decode(), 'new': new_phrase.decode(), 'occurrences': 1, 'complete_v2_v3_forward_inverse_exact': True},
    'HTML_Source_checks': {'new_ids': fp.ids, 'baseline_ids_count': len(bp.ids), 'disjoint_unique': True, 'links': fp.hrefs, 'table_all32_cells_plus_headers_parsed': True, 'inline_LaTex_pairs': 40, 'display_LaTex_pairs': 0, 'forbidden_document_script_mathsupsub_tags': [], 'event_handlers': [], 'inherited_MathJax3_scaffold_compatible': True, 'one_body_insertion_anchor_byte': 4300, 'in_memory_prospective_insert_inverse_exact_baseline': True, 'prospective_full_bytes_without_writing_payload': 203576, 'clock_notice_outside_details': True},
    'review_only_history': 'An initial administrative assertion assumed insertion after main; observed baseline main closes at byte61819 while the intended body opening closes at4300. Corrected the reviewer anchor to body before any review/support writes. Full insert inverse then checked at4300; no content/payload changed and no scientific action occurred.',
    'SVG_exact_Source_geometry': {'viewBox': svg.attrib['viewBox'], 'scale_pixels_per_lattice_unit': 60, 'positive_support_center': [240,220], 'STATE_pixel_points': sorted(points), 'STATE_offsets': offsets, 'WANG_pixel_points': sorted(green_points), 'coincident_two_channels': sorted(points.intersection(green_points)), 'outside_current_square_points': [[120,160],[360,160]], 'outside_Q_paper_reason': 'All STATE slots even horizontal/odd vertical; all required positive anchors even/even. No new t-mass/coverage/frontier generation. Colors/lines schematic reader annotations; not actual or learned marking values.'},
    'archive_boundary_precision': 'Promises selected complete current5 outputs/Sources/reviews, not recursive project history. Seven-field history receipts retain counters/domain/accepted grids, not rejected-grid materialization; runtime purity identity checks not reestablished from JSON. Root56125/B12424/threeLoldmetadata exact-body gaps explicit. Manifest/catalogue inclusion and full payload/transport review remain future gates.',
    'operations': {'actual_result_log_model_referencewitness_library_corpus_body_intake': 0, 'scientific_replay_helper_Source_model_or_compiled_code_execution': 0, 'UI_renderer_network_staging_publication': 0, 'protected_original_edits': 0},
    'publication_authorized': False
}
support_pin = save('state-propagation-public-content-complete-metadata-HTML-support-v1.json', support)
review = {
    'schema': 'L-state-propagation-public-content-complete-independent-review-v1', 'status': 'COMPLETE_SOURCE_METADATA_CONTENT_PASS_CURRENT_V3_ONLY', 'review_passed': True, 'blockers': [],
    'issued_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'criteria': expect_pin, 'facts': facts_pin, 'current_fragment': v3_pin, 'superseded_fragment': v2_pin, 'complete_support': support_pin, 'baseline_Source_scaffold_only': base_pin, 'selected_evidence_boundary': boundary_pin,
    'resolved_substantive_precision_finding': {'v2': 'The phrase no engine or search call could incorrectly imply zero engine module calls, despite one pure compile_wang.', 'v3': 'Sole exact immutable replacement says no Engine instantiation/solve and explicitly includes pure compile_wang construction. Complete forward/reverse raw equality checked; no other content changed.'},
    'complete_facts_disposition': 'All5 whole-adoption administrative metadata documents read/pin/strict-JSON checked; four row counts and complete phase/post-readback/resource dictionaries match their respective adopted documents. All statuses, result rawpin associations, cumulative-vs-final placement distinctions, separate API30 controls and complete224audits/78732histories totals coherent. Positive BASELINE status is semantic label translation from Root admitted positive result, not a duplicate engine_status scalar in that one adoption. No actual body revalidation or scientific replay.',
    'cost_reporting': 'All four table elapsed values correctly round current late worker fields to3decimals. Full construction/validation/reference/audited-search/verification/evidence phases and result serialize/write/fsync/readback/hash included with correct main-entry clock; startup and terminal/outer tails excluded. Phase callback sums and four late gates coherent. RSS separate lifetime maxima+16MiB allowance checked, not simultaneous/process-tree/hard cap. API costs separate; no inferred startup subtraction, statistical speedup, practical/causal superiority or conventional-proof-search benefit.',
    'mathematical_and_visual_Source': 'Whole fragment including SVG/captions/disclosure/clock/archive note read. Exact STATE offsets(-2,-1),(0,-1),(2,-1),(0,1) and green WANG midpoint geometry use60px/latticeunit; preceding-row outputs align with current inputs. Outer points outside current square and all STATE slots outsideQ follow static even/odd proof. Coincident WANG/STATE circles remain separate channels; colors/dashed lines are reader annotations, no extra rules or observed/learned state. Hand-certified finite redundancy and full erasure/model preservation are scoped to canonical supplied tableau; no engine-discovered theorem, learning/RL/FOL/universal/infinite/geometric-generality claim.',
    'HTML_math_scaffold': 'Ten unique newIDs disjoint48baseline, all internal/download links coherent; forty balanced supported inlineLaTex pairs/no displays/no HTMLsup/sub/math substitutions. No html/head/body/script/event handler; style scoped to current section. Existing MathJax3 configuration supports delimiters. Single insertion immediately after body opening at byte4300 can preserve full191052baseline exactly; full in-memory inverse checked without writing report/staging. Source-only review makes no independent render/UI claim.',
    'clock_correction': 'Visible notice outside details links retained old tableau anchor and explicitly narrows unchanged4.37s label to afterPopenreturn through owned wait, excluding process creation/pre-return child work. Distinct worker/observer origins must not be subtracted; no previous evidence number or outcome edited or reanalysed.',
    'evidence_boundary': 'Full4228selected boundary record read; complete current5 output/Sources/reviews promise is bounded manifest selection, not recursive history/runtimebinary distribution. History receipts do not claim rejected-grid materialization; serialized purity values do not recreate live identity. Explicit historical unavailable bodies match known recovery boundaries; no failed placeholder follow or fabrication. Root must actually include boundary record+catalogue and full promised current files in later reviewed package.',
    'remaining_separate_gates': ['Root whole content adoption for exact currentfacts/v3/boundary.', 'Separately reviewed preparer/manifest/archive/catalogue/staging/full raw member/payload/Root-P2 twin closure and exact insertion inverse; this review is not archive or payload approval.', 'Root visual/math/narrow-screen QA and any required full human archive/A8/once/currentremote/Source/runtime/publication gates; no new destination or audience authorized.', 'After separately authorized sole publication, Pages completion/normalTLS3fullbody and live UI/math QA remain external.'],
    'scope_and_provenance': 'Current five admitted metadata docs plus static mathematical proof and baseline Source scaffold only. No prior actual output/log/model/referencewitness body, library/corpus or raw scientific artifact follow; no scientific helper/replay/model reconstruction. Broad GCTS+RL goal remains active/incomplete; substitution optional per current facts. No Source/payload/original edits.',
    'operations': support['operations'], 'publication_authorized': False, 'scientific_execution_authorized': False,
    'final_state': 'TMP_FIRST_NEW_REPO_MIRROR_CURRENT_V3_REVIEW_FROZEN; OWN_TOOLS_TERMINAL_IDLE; NO_RENDER_OR_PUBLICATION.'
}
review_pin = save('state-propagation-public-content-complete-independent-review-v1.json', review)
print(json.dumps({'review': review_pin, 'support': support_pin, 'current_fragment': v3_pin, 'status': 'PASS_CURRENT_V3_TERMINAL_IDLE'}, sort_keys=True))
