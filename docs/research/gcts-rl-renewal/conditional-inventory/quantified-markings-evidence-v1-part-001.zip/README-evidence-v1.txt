Quantified arithmetic markings: complete finite RF reduction and a blocked activation.

Download EVERY quantified-markings-evidence-v1-part-NNN.zip together with
quantified-markings-evidence-manifest-v1.json. Each volume is at most 44 MiB
and includes the same ARCHIVE-file-manifest-v1.json. Extract all volumes into
one directory. Every original current-run path at the archive cut is physically
stored once, including equal bytes at different paths. No alias, external
reference or reconstruction recipe substitutes for an original file. Every
member's exact size/SHA256 and CRC is checked before commit preparation.

All current Sources, input/reference/plan/review files, publication Sources and
planning receipts, raw results/events/endpoints, proofs from qualification,
native receipts, actual logs, UNKNOWN/refusal outcomes, report assets, local
paths and README are included. Only package/ generated outputs are excluded
from their own input cut. Publication index/commit/deployment/live receipts
created after the cut cannot be members of that earlier cut; they remain later
custody records. The prior milestone's full archive is separately linked from
learned-literal-markings-v1.html and is not claimed as physically included here.
The existing public destination and full archive, including local paths/logs,
are explicitly approved by the user. No new audience or destination is created.

Serve the extracted directory and open report/quantified-markings-v1.html.
The five executed scientific phases have clean actual native exit zero and
unchanged frozen Sources. Qualification covers 20 point cases, two fresh
logical proofs and nine controls; preparation retains 488 formulas, 245
native-checked ZERO definitions and all 49736 shared-slot candidate rows.
One fresh fixed-CID query has independently certified finite failure. Its
scope is the exact eight-slot finite inventory, not mathematical nonprovability.

Sparse synthesis/application returned data, but the independent activation
checker returned UNKNOWN at its unchanged work bound. Thus NO learned marking
was activated and NO BASE/MARKS/FILTER evaluation was performed. The dependent
evaluate command was blocked before its worker, with zero engine calls; its
outer exit one is retained separately from the five clean scientific workers.
There is no arithmetic target proof in this run. The two native proofs are
qualification statements, not the original research target. No speed result,
new theorem, RL gain, heldout transfer or universal finite Wang palette follows.
The larger research program remains ACTIVE.
