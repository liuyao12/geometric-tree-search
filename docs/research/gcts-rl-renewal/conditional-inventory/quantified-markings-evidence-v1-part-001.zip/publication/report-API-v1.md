# Passive quantified-marking report

`publication/build_quantified_report_v1.py` is a saved-data assembler and HTML
renderer. It imports only Python standard-library modules, and never imports,
replays or calls the engine, semantic/native checkers, bridge or synthesis code.
Source review and syntax checks precede its first execution by Root.

Run with the frozen executable and isolation flags:

```sh
/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12 -I -S -B publication/build_quantified_report_v1.py
```

The root is derived from `__file__`; all artifact references are relative to that
root. Physical relative files may not contain symlinks. Readable JSON is capped
at 128 MiB per artifact. Reads validate saved byte lengths and SHA-256 values;
frozen scientific file-set, current master and pinned isolated-runtime equality
are checked before assembly. External runtime/master pins remain separate from
the relative download ledger.

## Inputs and admission

The frozen protocol is `protocol/frozen-protocol-v1.json`. The six scientific
phase results and their actual start/invocation/observer/log records are read
from `data/<phase>/result.json` and `run/<phase>/`, respectively. A clean native
process does not imply scientific admission: the exact protocol-declared phase
status is separately required. PID, protocol, native exit, result/log byte pins,
scientific status and frozen postcheck associations are joined.

The following already-reviewed passive audit statuses are required:

- `review/passive-qualification-prepare-v1.json`:
  `PASS_SAVED_QUALIFICATION_AND_PREPARATION_ONLY`.
- `review/passive-transfer-outcomes-v1.json`:
  `PASS_SAVED_OUTCOMES_WITH_UNACTIVATED_RESOURCE_REFUSAL`.

The actual `review/evaluation-preflight-refusal-v1.json` is bound to the saved
UNKNOWN learn result and to the absence of an evaluation worker/result. Its
outer CLI exit is kept separate from native scientific process statuses.

## Public data

`report/quantified-markings-data-v1.json.gz` is deterministic gzip of canonical
ASCII JSON plus LF, schema `Quantified-markings-reader-data-v1`, status
`PASS_PASSIVE_SAVED_DATA_PROJECTION`. This status concerns saved-data projection,
not successful overlay admission. Main fields:

- `phases`: process status, scientific status, scientific admission, actual
  worker/observer intervals and high-water RSS, plus exact record references.
- `declaration`, `prepare`: original arithmetic statement, finite bounds,
  full-basis census, native ZERO-check count and original mandatory-mark counts.
- `acquisition`: actual UNKNOWN prefix and selected proposal; never a negative
  label. Event samples are the first/last retained payloads only.
- `label`: the fresh complete fixed-CID negative certificate, canonical binding,
  actual dead-context witness and exact witness-coverage metadata.
- `learning_candidate`: saved SOLVED synthesis and CONSTRUCTED_UNVERIFIED
  application, with candidate-list omission declared by this API. The full
  original CID list stays in its archive artifact. Actual extra assignment,
  seed assignment, counters, conditional-check receipt and frozen work cap are
  included. `activated` is false for the actual UNKNOWN resource refusal.
- `learning`: admitted overlay only, null in this run. A constructed candidate
  is not promoted into it.
- `evaluation_preflight`: actual BLOCKED_BEFORE_WORKER refusal and byte pin.
- `lanes`: actual admitted evaluation records only; empty in this run.
- `proofs`: native-checked actual selected certificates with exact ASTs,
  slot/reference mappings, literal selected rows and statement bindings. Only
  the two qualification proofs exist in this run. Display aliases map
  `qqualx/qqualP/qqualQ` to `x/P/Q`; the literal toggle and original AST preserve
  the actual names.
- `qualification`, `saved_data_audits`, `protocol`, `provenance`, `scope`:
  counts, audit references and artifact pins. No large-run intermediate-table
  observation is inferred from independently reconstructed semantic events.

The public projection omits complete huge universes, full phase raw records and
unneeded candidate-list copies. These original physical files remain in the
full approved archive, not replaced or rewritten. No scientific result is
derived from the projection's omitted information.

## Outputs and publication handoff

Outputs are exclusive: existing files cause refusal rather than replacement.

- Main: `report/quantified-markings-v1.html`.
- Data: `report/quantified-markings-data-v1.json.gz`.
- Build receipt: `report/build-receipt-v1.json`, schema
  `Quantified-markings-passive-build-v1`, status
  `PASS_PASSIVE_SAVED_DATA_AND_REPORT_BUILD`.

Receipt fields are `outputs:{main,data}`, `renderer_source`, `protocol`,
`phases`, `artifact_pins` and `scope`. Every output/ref uses
`{path,bytes,sha256}`. The receipt is archive-only. No separate evidence HTML or
individual-download directory is required. The main has `#reader` and
`#evidence`, and exactly one marker:

```html
<!-- QUANTIFIED_MARKINGS_ARCHIVE_LINK -->
```

The package author may preserve the original rendered HTML and insert the
archive block at this marker, binding that marker-only transformation before
final UI checks. Intended archive names are
`quantified-markings-evidence-v1-part-001.zip` and
`quantified-markings-evidence-manifest-v1.json`. The previous reader is
`learned-literal-markings-v1.html`, within the existing conditional-inventory
destination. Root owns all builds, UI admission, packaging and deployment.

No arithmetic target proof, activated learned pruning, three-lane comparison,
literal Wang search, new theorem, RL result or distinctive GCTS advantage is
claimed. Mathematical assertions are rendered with the established MathJax
startup and serialized typesetting queue; unknown/empty proof selections clear
the diagram and proof rows.
