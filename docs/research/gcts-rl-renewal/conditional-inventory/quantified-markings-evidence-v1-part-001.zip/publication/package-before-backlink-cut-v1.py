"""Passive exact-byte archive and isolated commit preparation; never pushes.

Source-only until Root reviews this complete file. No scientific imports,
helpers, replay, source edits, primary index or primary checkout writes.
Usage: pinned Python -I -S -B FILE --prepare-links; final UI/admission; FILE BASE.
"""
import argparse
import gzip
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import subprocess
import sys
import time
import zipfile
import zlib

ROOT = Path(__file__).resolve().parents[1]
GIT = '/private/tmp/gcts-history-publication-20261102-v1.git'
GH = '/Users/liuyao/bin/gh'
REPO = 'liuyao12/geometric-tree-search'
BASE = 'f8fb724a8d452d6ffdb547457adf6f7f02ebee72'
PREFIX = 'docs/research/gcts-rl-renewal/conditional-inventory/'
BASE_URL = 'https://liuyao12.github.io/geometric-tree-search/'
MAIN = 'quantified-markings-v1.html'
DATA = 'quantified-markings-data-v1.json.gz'
OLD = 'learned-literal-markings-v1.html'
MANIFEST = 'quantified-markings-evidence-manifest-v1.json'
PART_STEM = 'quantified-markings-evidence-v1-part-'
INTERNAL = 'ARCHIVE-file-manifest-v1.json'
BEGIN = b'<!-- QUANTIFIED_MARKINGS_ARCHIVE_LINK -->'
END = b'<!-- /QUANTIFIED_MARKINGS_ARCHIVE_LINK -->'
MAX_PART = 44 * 1024 * 1024
RESERVE = 2 * 1024 * 1024
CAPTURE = 128 * 1024 * 1024
PROTOCOL = 'protocol/frozen-protocol-v1.json'
BUILDER = 'publication/build_quantified_report_v1.py'
BUILD = 'report/build-receipt-v1.json'
ROOT_ADMISSION = 'publication/root-publication-admission-v1.json'
UI = 'publication/local-ui-v1.json'
QUAL_AUDIT = 'review/passive-qualification-prepare-v1.json'
TRANSFER_AUDIT = 'review/passive-transfer-outcomes-v1.json'
SOURCE_ADMISSION = 'review/root-source-admission-v1.json'
PRIMARY_MASTER = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md')
PHASE_STATUSES = dict(qualify='QUALIFIED', prepare='PREPARED',
                      acquire='ACQUIRED_PROPOSAL', label='LABELLED', learn='UNKNOWN')
PROTOCOL_PIN = dict(bytes=8696, sha256='9df2f56febcde7454b22bd2e87eff663c548c0e26a09dbe1c6fb17dff01282a4')
README = r'''Quantified arithmetic markings: complete finite RF reduction and a blocked activation.

Download EVERY quantified-markings-evidence-v1-part-NNN.zip together with
quantified-markings-evidence-manifest-v1.json. Each volume is at most 44 MiB
and includes the same ARCHIVE-file-manifest-v1.json. Extract all volumes into
one directory. Every original current-run path at the archive cut is physically
stored once, including equal bytes at different paths. No alias, external
reference or reconstruction recipe substitutes for an original file. Every
member's exact size/SHA256 and CRC is checked before commit preparation.

All current Sources, input/reference/plan/review files, publication Sources and
planning receipts, raw results/events/endpoints, proofs from qualification,
native receipts, actual logs, UNKNOWN/refusal outcomes, report assets, local
paths and README are included. Only package/ generated outputs are excluded
from their own input cut. Publication index/commit/deployment/live receipts
created after the cut cannot be members of that earlier cut; they remain later
custody records. The prior milestone's full archive is separately linked from
learned-literal-markings-v1.html and is not claimed as physically included here.
The existing public destination and full archive, including local paths/logs,
are explicitly approved by the user. No new audience or destination is created.

Serve the extracted directory and open report/quantified-markings-v1.html.
The five executed scientific phases have clean actual native exit zero and
unchanged frozen Sources. Qualification covers 20 point cases, two fresh
logical proofs and nine controls; preparation retains 488 formulas, 245
native-checked ZERO definitions and all 49736 shared-slot candidate rows.
One fresh fixed-CID query has independently certified finite failure. Its
scope is the exact eight-slot finite inventory, not mathematical nonprovability.

Sparse synthesis/application returned data, but the independent activation
checker returned UNKNOWN at its unchanged work bound. Thus NO learned marking
was activated and NO BASE/MARKS/FILTER evaluation was performed. The dependent
evaluate command was blocked before its worker, with zero engine calls; its
outer exit one is retained separately from the five clean scientific workers.
There is no arithmetic target proof in this run. The two native proofs are
qualification statements, not the original research target. No speed result,
new theorem, RL gain, heldout transfer or universal finite Wang palette follows.
The larger research program remains ACTIVE.
'''.encode('ascii')


def need(condition, reason):
    if not condition:
        raise AssertionError(reason)


def wire(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def stream_pin(stream):
    size, digest = 0, hashlib.sha256()
    for block in iter(lambda: stream.read(1048576), b''):
        size += len(block)
        digest.update(block)
    return dict(bytes=size, sha256=digest.hexdigest())


def pin(path):
    with path.open('rb') as stream:
        return stream_pin(stream)


def relative(name):
    need(type(name) is str and name and '\\' not in name and '\0' not in name, 'RELATIVE_PATH_TEXT')
    value = PurePosixPath(name)
    need(not value.is_absolute() and all(p not in ('', '.', '..') for p in value.parts)
         and value.as_posix() == name, 'CANONICAL_RELATIVE_PATH:' + name)
    return name


def local(name):
    path = ROOT / relative(name)
    need(not path.is_symlink() and path.resolve().is_relative_to(ROOT), 'TASK_CONTAINMENT:' + name)
    return path


def reference(name):
    return dict(path=name, **pin(local(name)))


def exact(reference_value):
    need(type(reference_value) is dict and {'path', 'bytes', 'sha256'} <= set(reference_value), 'FILE_REFERENCE')
    need(type(reference_value['bytes']) is int and reference_value['bytes'] >= 0, 'NATIVE_FILE_SIZE')
    need(reference_value.get('complete_json', True) is True, 'COMPLETE_REFERENCED_JSON')
    need(wire(pin(local(reference_value['path']))) == wire({k: reference_value[k] for k in ('bytes', 'sha256')}),
         'EXACT_FILE_BYTES:' + reference_value['path'])


def load(name):
    path = local(name)
    with (gzip.open(path, 'rb') if path.suffix == '.gz' else path.open('rb')) as stream:
        raw = stream.read(CAPTURE + 1)
    need(len(raw) <= CAPTURE, 'JSON_CAPTURE_LIMIT:' + name)
    return json.loads(raw)


def owned(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        need(not path.is_symlink() and path.read_bytes() == raw, 'PRESERVE_DIFFERENT_EXISTING_BYTES:' + str(path))
    else:
        with path.open('xb') as stream:
            stream.write(raw)


def refs_in(value, found=None):
    found = {} if found is None else found
    if type(value) is dict:
        if {'path', 'bytes', 'sha256'} <= set(value) and type(value['path']) is str and not value['path'].startswith('/'):
            exact(value)
            found[value['path']] = {k: value[k] for k in ('path', 'bytes', 'sha256')}
        for child in value.values():
            refs_in(child, found)
    elif type(value) is list:
        for child in value:
            refs_in(child, found)
    return found


def verify_protocol():
    need(wire(pin(local(PROTOCOL))) == wire(PROTOCOL_PIN), 'EXACT_FROZEN_PROTOCOL')
    protocol = load(PROTOCOL)
    need(protocol['schema'] == 'Quantified-marking-transfer-protocol-v1'
         and protocol['status'] == 'FROZEN_BEFORE_SCIENTIFIC_IMPORTS', 'FROZEN_PROTOCOL_SCHEMA_STATUS')
    need(local(PROTOCOL).read_bytes() == wire(protocol), 'CANONICAL_PROTOCOL_FILE')
    admission = load(SOURCE_ADMISSION)
    need(admission['status'] == 'PASS_SOURCE_REVIEW_BEFORE_FREEZE', 'HISTORICAL_SOURCE_ADMISSION')
    names = {SOURCE_ADMISSION}
    for folder in ('source', 'reference', 'input', 'plan'):
        for path in (ROOT / folder).rglob('*'):
            need(not path.is_symlink(), 'NO_FROZEN_SYMLINK')
            if path.is_file():
                need(path.suffix != '.pyc' and '__pycache__' not in path.parts, 'NO_FROZEN_BYTECODE')
                names.add(path.relative_to(ROOT).as_posix())
    for entry in admission['reviewed']:
        exact(entry)
        names.add(entry['path'])
    actual = [reference(name) for name in sorted(names)]
    need(wire(actual) == wire(protocol['files']) and len(actual) == 48, 'EXACT_COMPLETE_FROZEN_FILE_SET')
    executable = Path(sys.executable).resolve()
    runtime = dict(executable=dict(path=str(executable), **pin(executable)), version=sys.version,
                   isolated=sys.flags.isolated, no_site=sys.flags.no_site, dont_write_bytecode=sys.dont_write_bytecode)
    need(wire(runtime) == wire(protocol['runtime']) and sys.flags.isolated == sys.flags.no_site == 1
         and sys.dont_write_bytecode is True, 'PINNED_ISOLATED_RUNTIME')
    need(wire(dict(path=str(PRIMARY_MASTER), **pin(PRIMARY_MASTER))) == wire(protocol['master']), 'CURRENT_MASTER_BYTES')
    need(wire(pin(PRIMARY_MASTER)) == wire(pin(local('reference/basic-tiling-algorithm.md'))), 'MASTER_REFERENCE_COPY')
    phases = []
    for phase, expected in PHASE_STATUSES.items():
        started, invocation, observer = [load('run/' + phase + '/' + role + '.json')
                                         for role in ('started', 'invocation', 'observer')]
        result = load('data/' + phase + '/result.json')
        need(started['phase'] == invocation['phase'] == observer['phase'] == phase, 'EXACT_PHASE_ID:' + phase)
        need(all(type(x['pid']) is int and x['pid'] > 0 for x in (started, invocation, observer))
             and started['pid'] == invocation['pid'] == observer['pid'], 'NATIVE_PID_ASSOCIATION:' + phase)
        need(observer['status'] == 'TERMINAL' and type(observer['native_exit_code']) is int
             and observer['native_exit_code'] == 0 and invocation['status'] == 'COMPLETE'
             and invocation['error_type'] is None, 'ACTUAL_NATIVE_CLEAN:' + phase)
        need(all(observer[k] is None for k in ('guard_reason', 'observer_error', 'reap_error', 'postcheck_error'))
             and invocation['postcheck_error'] is None, 'NO_GUARD_OR_POSTCHECK_ERROR:' + phase)
        need(observer['frozen_postcheck'] == invocation['frozen_postcheck'] == protocol['status'], 'SOURCE_POSTCHECK:' + phase)
        need(wire(started['protocol']) == wire(reference(PROTOCOL)), 'STARTED_PROTOCOL:' + phase)
        need(invocation['result']['path'] == 'data/' + phase + '/result.json'
             and invocation['result']['complete_json'] is True, 'EXACT_COMPLETE_PHASE_RESULT:' + phase)
        exact(invocation['result'])
        need(observer['log']['path'] == 'run/' + phase + '/stdout.log', 'OWNED_LOG_PATH:' + phase)
        exact(observer['log'])
        need(invocation['scientific_status'] == result['status'] == expected, 'SCIENCE_STATUS_WITH_UNKNOWN_PRESERVED:' + phase)
        refs_in(result)
        phases.append(dict(phase=phase, pid=observer['pid'], native_exit_code=0,
                           scientific_status=expected, source_postcheck=observer['frozen_postcheck'],
                           observer_seconds=observer['seconds'], result=reference('data/' + phase + '/result.json')))
    need(not local('run/evaluate').exists() and not local('data/evaluate').exists(), 'NO_UNEXECUTED_EVALUATION_PROMOTION')
    refusal = load('review/evaluation-preflight-refusal-v1.json')
    need(refusal['status'] == 'BLOCKED_BEFORE_WORKER' and refusal['worker_started'] is False
         and type(refusal['engine_calls']) is int and refusal['engine_calls'] == 0
         and type(refusal['native_outer_exit_code']) is int and refusal['native_outer_exit_code'] == 1,
         'DEPENDENT_PREFLIGHT_FAILURE_RETAINED')
    return dict(protocol=reference(PROTOCOL), frozen_files=len(actual), phases=phases,
                evaluation='NOT_RUN_PRECONDITION_BLOCKED_BEFORE_WORKER', preflight=reference('review/evaluation-preflight-refusal-v1.json'))


def audit_gates():
    qual, outcomes = load(QUAL_AUDIT), load(TRANSFER_AUDIT)
    need(qual['schema'] == 'QMT-passive-qualification-prepare-audit-v1'
         and qual['status'] == 'PASS_SAVED_QUALIFICATION_AND_PREPARATION_ONLY', 'PASSIVE_QUAL_PREP_GATE')
    need(outcomes['schema'] == 'QMT-passive-transfer-outcomes-audit-v1'
         and outcomes['status'] == 'PASS_SAVED_OUTCOMES_WITH_UNACTIVATED_RESOURCE_REFUSAL', 'PASSIVE_TRANSFER_GATE')
    need(wire(qual['protocol']) == wire(reference(PROTOCOL)) == wire(outcomes['protocol']), 'AUDIT_PROTOCOL_ASSOCIATION')
    refs_in(qual)
    refs_in(outcomes)
    need(qual['preparation']['all_native_ZERO'] == 245 and qual['preparation']['census']['formulas'] == 488
         and qual['preparation']['census']['rows'] == 49736, 'ACTUAL_FULL_PREPARATION_COUNTS')
    failure, blocked = outcomes['certified_finite_failure'], outcomes['overlay_admission_refusal']
    need(failure['raw_status'] == 'UNSAT' and failure['semantic_status'] == 'VERIFIED'
         and failure['bounded_absence'] is True, 'SCOPED_CERTIFIED_SINGLE_CID_FAILURE')
    need(blocked['status'] == 'UNKNOWN' and blocked['reason'] == 'CHECKER_MAX_WORK'
         and type(blocked['work']) is int and blocked['work'] == 1035647437
         and blocked['activation_admitted'] is False, 'ACTUAL_UNACTIVATED_RESOURCE_REFUSAL')
    need(type(outcomes['arithmetic_target_proofs_observed']) is int and outcomes['arithmetic_target_proofs_observed'] == 0
         and outcomes['evaluation']['status'] == 'NOT_RUN' and outcomes['evaluation']['engine_calls'] == 0,
         'NO_TARGET_PROOF_OR_EVALUATION_CLAIM')
    need(not local('data/learn/marked-model.json.gz').exists()
         and not local('data/learn/control-model.json.gz').exists(), 'NO_POST_ADMISSION_MODELS')
    return [reference(QUAL_AUDIT), reference(TRANSFER_AUDIT)]


def collapsed_archive_region(raw):
    need(raw.count(BEGIN) == 1 and raw.count(END) <= 1, 'ONE_ARCHIVE_MARKER_REGION')
    if END not in raw:
        return raw
    left, tail = raw.split(BEGIN)
    _, right = tail.split(END)
    return left + BEGIN + right


def verify_report():
    receipt = load(BUILD)
    need(receipt['schema'] == 'Quantified-markings-passive-build-v1'
         and receipt['status'] == 'PASS_PASSIVE_SAVED_DATA_AND_REPORT_BUILD', 'PASSIVE_REPORT_BUILD')
    need(receipt['renderer_source']['path'] == BUILDER, 'EXACT_RENDERER_SOURCE')
    exact(receipt['renderer_source'])
    need(wire(receipt['protocol']) == wire(reference(PROTOCOL)), 'REPORT_FROZEN_PROTOCOL')
    for entry in receipt['artifact_pins']:
        exact(entry)
    need(set(receipt['outputs']) == {'main', 'data'}, 'ONLY_TWO_REPORT_OUTPUTS')
    main, data_ref = receipt['outputs']['main'], receipt['outputs']['data']
    need(main['path'] == 'report/' + MAIN and data_ref['path'] == 'report/' + DATA, 'EXACT_REPORT_PATHS')
    exact(data_ref)
    data = load(data_ref['path'])
    need(data['schema'] == 'Quantified-markings-reader-data-v1'
         and data['status'] == 'PASS_PASSIVE_SAVED_DATA_PROJECTION', 'PUBLIC_DATA_SCHEMA_STATUS')
    need(wire(data['protocol']) == wire(receipt['protocol'])
         and wire(data['phases']) == wire(receipt['phases']), 'REPORT_PROCESS_AND_PROTOCOL_PROJECTION')
    need(wire(data['provenance']['artifact_pins']) == wire(receipt['artifact_pins']), 'REPORT_ALL_ARTIFACT_PIN_ASSOCIATION')
    need(data['learning'] is None and data['lanes'] == [] and len(data['proofs']) == 2
         and all(x['kind'] == 'QUALIFICATION' and x['native_status'] == 'VERIFIED' for x in data['proofs']),
         'QUALIFICATION_PROOFS_ONLY_NO_ACTIVATION_OR_TARGET_PROOF')
    need(data['prepare']['census']['rows'] == 49736 and data['prepare']['census']['formulas'] == 488
         and data['prepare']['ZERO_checks'] == 245, 'FULL_RF_READER_COUNTS')
    need(data['label']['label'] == 'NEGATIVE' and data['label']['bounded_absence'] is True, 'READER_SCOPED_LABEL')
    phases = {x['name']: x for x in data['phases']}
    need(set(phases) == set(PHASE_STATUSES) | {'evaluate'}, 'ALL_SIX_READER_PHASE_POSITIONS')
    for phase, expected in PHASE_STATUSES.items():
        value = phases[phase]
        need(value['scientific_status'] == expected and value['process_clean'] is True
             and value['native_exit_code'] == 0 and value['admitted'] is (phase != 'learn'), 'EXACT_READER_PHASE_SCOPE:' + phase)
    need(phases['evaluate']['admitted'] is False and phases['evaluate']['native_exit_code'] is None, 'READER_UNRUN_EVALUATION')
    original = local('publication/rendered-before-archive-links-v1.html')
    before = original.read_bytes() if original.exists() else local(main['path']).read_bytes()
    need(wire(dict(bytes=len(before), sha256=sha(before))) == wire({k: main[k] for k in ('bytes', 'sha256')}), 'ORIGINAL_RENDERED_MAIN_PIN')
    current = local(main['path']).read_bytes()
    need(collapsed_archive_region(current) == collapsed_archive_region(before), 'ONLY_ARCHIVE_MARKER_REGION_CHANGED')
    return dict(build=reference(BUILD), renderer_source=receipt['renderer_source'],
                main_original=main, main_current=reference(main['path']), data=data_ref)


def final_readiness():
    protocol, audits, report = verify_protocol(), audit_gates(), verify_report()
    ui = load(UI)
    need(ui['status'] == 'PASS_LOCAL_UI' and type(ui['math_errors']) is int and ui['math_errors'] == 0
         and ui['body_overflow'] is False and ui['console'] == [], 'ACTUAL_FINAL_LOCAL_UI')
    need(ui.get('fatal', '') == '', 'NO_LOCAL_READER_FATAL_ERROR')
    need(ui['source']['path'] == 'report/' + MAIN, 'UI_MAIN_SOURCE')
    exact(ui['source'])
    assessment = load('review/root-research-assessment-v1.json')
    need(assessment['status'] == 'FINITE_PROGRESS_WITH_BLOCKED_ACTIVATION', 'SCOPED_ROOT_ASSESSMENT')
    root = load(ROOT_ADMISSION)
    need(root['status'] == 'PASS_REVIEWED_PUBLICATION_WITH_SCOPED_REFUSAL', 'ROOT_PUBLICATION_ADMISSION')
    bound = refs_in(root)
    required = {PROTOCOL, 'report/' + MAIN, 'report/' + DATA, BUILDER,
                'publication/package_quantified_v1.py', QUAL_AUDIT, TRANSFER_AUDIT, UI, BUILD}
    need(required <= set(bound), 'ROOT_ADMISSION_BINDS_FINAL_PUBLICATION_BYTES')
    return dict(protocol=protocol, audits=audits, report=report, local_ui=reference(UI),
                root_admission=reference(ROOT_ADMISSION), assessment=reference('review/root-research-assessment-v1.json'))


def original_files():
    files = []
    for path in sorted(ROOT.rglob('*')):
        name = path.relative_to(ROOT).as_posix()
        if name.split('/')[0] == 'package':
            continue
        need(not path.is_symlink(), 'NO_ARCHIVE_SYMLINK:' + name)
        if path.is_file():
            files.append(dict(path=relative(name), **pin(path)))
    need(INTERNAL not in {x['path'] for x in files}, 'NO_GENERATED_MANIFEST_COLLISION')
    return files


def estimate(path):
    compressor, count = zlib.compressobj(6, zlib.DEFLATED, -15), 0
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            count += len(compressor.compress(block))
    return count + len(compressor.flush())


def partition(files):
    groups, used = [[]], 0
    for entry in files:
        charge = estimate(local(entry['path'])) + 256 + 4 * len(entry['path'].encode('utf8'))
        need(charge <= MAX_PART - RESERVE, 'SINGLE_MEMBER_EXCEEDS_DECLARED_VOLUME_DESIGN:' + entry['path'])
        if groups[-1] and used + charge > MAX_PART - RESERVE:
            groups.append([])
            used = 0
        groups[-1].append(entry['path'])
        used += charge
    return groups


def part_names(count):
    return [PART_STEM + '%03d.zip' % i for i in range(1, count + 1)]


def set_links(names):
    links = ' · '.join('<a href="' + name + '">Evidence volume ' + str(i) + '</a>'
                       for i, name in enumerate(names, 1))
    block = BEGIN + ('<p>Full approved current-run archive: ' + links +
        ' · <a href="' + MANIFEST + '">Every original path and hash</a>. Download all volumes and extract together; '
        'all Source/raw/UNKNOWN/log paths are physically retained. '
        '<a href="' + OLD + '#reader">Prior milestone and its separate full archive</a>.</p>').encode('utf8') + END
    path = local('report/' + MAIN)
    raw = path.read_bytes()
    need(raw.count(BEGIN) == 1 and raw.count(END) <= 1, 'ONE_RENDERER_ARCHIVE_MARKER')
    if END in raw:
        left, tail = raw.split(BEGIN)
        _, right = tail.split(END)
        new = left + block + right
    else:
        new = raw.replace(BEGIN, block, 1)
    if raw != new:
        path.write_bytes(new)


def prepare_links():
    need(not local('package').exists() and not local('publication/prepared-v1.json').exists(), 'ARCHIVE_CUT_IMMUTABLE')
    verify_protocol()
    audit_gates()
    report = verify_report()
    original = local('publication/rendered-before-archive-links-v1.html')
    if not original.exists():
        owned(original, local('report/' + MAIN).read_bytes())
    exact(dict(path='publication/rendered-before-archive-links-v1.html',
               **{k: report['main_original'][k] for k in ('bytes', 'sha256')}))
    owned(local('README-evidence-v1.txt'), README)
    count = 1
    for iteration in range(16):
        names = part_names(count)
        set_links(names)
        groups = partition(original_files())
        print(json.dumps(dict(stage='ARCHIVE_PLAN', iteration=iteration, parts=len(groups))), flush=True)
        if len(groups) == count:
            break
        count = len(groups)
    else:
        raise AssertionError('ARCHIVE_VOLUME_PLAN_DID_NOT_STABILIZE')
    plan = dict(status='ARCHIVE_LINKS_PREPARED', parts=names,
                main=reference('report/' + MAIN), data=reference('report/' + DATA),
                scope='Planning only; final UI/admission must bind these bytes. Package refuses a changed part count.')
    # Replanning before a cut is explicit; preserve any earlier plan first.
    path = local('publication/archive-plan-v1.json')
    if path.exists() and path.read_bytes() != wire(plan):
        old = path.read_bytes()
        owned(local('publication/archive-plan-history-' + sha(old) + '.json'), old)
    path.write_bytes(wire(plan))
    print(json.dumps(dict(status=plan['status'], parts=names, next='Run final local UI and Root publication admission before packaging.')), flush=True)


def fresh_remote_base(expected):
    response = json.loads(subprocess.check_output([GH, 'api', '--hostname', 'github.com', '--method', 'GET',
        'repos/' + REPO + '/git/ref/heads/main'], timeout=50))
    need(response['ref'] == 'refs/heads/main' and response['object']['type'] == 'commit'
         and response['object']['sha'] == expected, 'FRESH_OFFICIAL_REMOTE_MAIN_CHANGED')
    value = dict(status='FRESH_REMOTE_BASE_CONFIRMED', repository=REPO, base=expected,
                 observed_epoch=time.time(), method='Official GitHub GET git/ref/heads/main', response=response)
    owned(local('publication/remote-base-at-prepare-v1.json'), wire(value))
    return value


def verify_archive(folder, manifest):
    core = {k: v for k, v in manifest.items() if k not in ('inventory_sha256', 'inventory_file', 'inventory_schema')}
    core['schema'] = manifest['inventory_schema']
    core['parts'] = [dict(number=p['number'], name=p['name']) for p in manifest['parts']]
    need(sha(wire(core)) == manifest['inventory_sha256'], 'INTERNAL_INVENTORY_HASH')
    entries = {e['path']: e for e in core['files']}
    need(len(entries) == len(core['files']) == core['original_files']
         and sum(e['bytes'] for e in entries.values()) == core['original_bytes'], 'ALL_ORIGINAL_PATHS_AND_BYTES')
    seen, parts = set(), []
    for number, part in enumerate(manifest['parts'], 1):
        need(part['number'] == number and part['name'] == PART_STEM + '%03d.zip' % number, 'CANONICAL_VOLUME_NAME')
        path = folder / relative(part['name'])
        actual = pin(path)
        need(wire(actual) == wire({k: part[k] for k in ('bytes', 'sha256')})
             and actual['bytes'] <= MAX_PART and actual['bytes'] < 50 * 1024 * 1024, 'VOLUME_BYTES_AND_CEILING')
        expected = {name for name, e in entries.items() if e['part'] == number}
        with zipfile.ZipFile(path) as archive:
            need(len(archive.namelist()) == len(set(archive.namelist()))
                 and set(archive.namelist()) == expected | {INTERNAL}, 'EXACT_VOLUME_MEMBER_SET')
            need(archive.read(INTERNAL) == wire(core) and archive.testzip() is None, 'EVERY_MEMBER_CRC_AND_INVENTORY')
            for name in sorted(expected):
                relative(name)
                entry = entries[name]
                need(name not in seen and archive.getinfo(name).file_size == entry['bytes'], 'PHYSICAL_ONCE_AND_EXACT_SIZE')
                with archive.open(name) as stream:
                    actual_member = stream_pin(stream)
                need(wire(actual_member) == wire({k: entry[k] for k in ('bytes', 'sha256')}), 'EXACT_UNCOMPRESSED_MEMBER:' + name)
                seen.add(name)
        parts.append(dict(number=number, name=part['name'], **actual, CRC='PASS'))
    need(seen == set(entries), 'EVERY_ORIGINAL_PHYSICALLY_VERIFIED')
    return dict(status='PASS', original_files=len(entries), parts=parts,
                all_original_paths_byte_verified=True, all_originals_physically_stored_once=True,
                all_CRC_verified=True, alias_deduplication=False)


def package(base):
    need(base == BASE, 'REVIEWED_BASE_REQUIRED')
    for name in ('package', 'publication/prepared-v1.json', 'publication/index-v1'):
        need(not local(name).exists(), 'PRESERVE_FIRST_PACKAGING_ATTEMPT:' + name)
    readiness = final_readiness()
    plan = load('publication/archive-plan-v1.json')
    need(plan['status'] == 'ARCHIVE_LINKS_PREPARED', 'LINK_PLAN_BEFORE_FINAL_UI')
    exact(plan['main'])
    exact(plan['data'])
    owned(local('README-evidence-v1.txt'), README)
    remote = fresh_remote_base(base)
    files = original_files()
    groups = partition(files)
    names = part_names(len(groups))
    need(names == plan['parts'], 'FINAL_FILES_CHANGED_VOLUME_COUNT_REPEAT_LINKS_AND_UI_BEFORE_CUT')
    current_main = local('report/' + MAIN).read_bytes()
    need(all(name.encode('ascii') in current_main for name in names)
         and MANIFEST.encode('ascii') in current_main, 'ALL_ARCHIVE_VOLUMES_LINKED')
    assignments = {name: number for number, group in enumerate(groups, 1) for name in group}
    entries = [dict(**entry, part=assignments[entry['path']]) for entry in files]
    core = dict(schema='Quantified-markings-physical-evidence-inventory-v1',
                original_files=len(entries), original_bytes=sum(e['bytes'] for e in entries), files=entries,
                parts=[dict(number=i, name=name) for i, name in enumerate(names, 1)],
                all_originals_physically_stored=True, alias_deduplication=False, readiness=readiness,
                previous_archive_separately_linked=BASE_URL + PREFIX + OLD,
                exclusions=['package/ generated archive outputs only; all other original paths present at the cut are physical members'],
                postcut_scope='Publication index, prepared commit, push, Pages and live receipts created after this cut are later custody records, not claimed inside their own prior archive.',
                generated_members=[INTERNAL])
    inventory = wire(core)
    need(len(zlib.compress(inventory, 6)) + 65536 < RESERVE, 'INVENTORY_HEADER_RESERVE')
    folder = local('package')
    folder.mkdir()
    parts = []
    for number, (name, group) in enumerate(zip(names, groups), 1):
        path = folder / name
        with zipfile.ZipFile(path, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
            for member in group:
                archive.write(local(member), member)
            archive.writestr(INTERNAL, inventory)
        value = pin(path)
        need(value['bytes'] <= MAX_PART and value['bytes'] < 50 * 1024 * 1024, 'ACTUAL_PHYSICAL_VOLUME_CEILING')
        parts.append(dict(number=number, name=name, **value))
        print(json.dumps(dict(stage='VOLUME_WRITTEN', part=number, **value)), flush=True)
    manifest = dict(core, schema='Quantified-markings-physical-multipart-evidence-v1',
                    inventory_schema=core['schema'], inventory_file=INTERNAL,
                    inventory_sha256=sha(inventory), parts=parts)
    owned(folder / MANIFEST, wire(manifest))
    verified = verify_archive(folder, manifest)
    owned(folder / 'archive-verification-v1.json', wire(verified))
    for entry in files:
        exact(entry)
    need(wire(original_files()) == wire(files), 'CUT_FILE_SET_AND_ALL_BYTES_UNCHANGED')
    # Read-only network observation is repeated immediately before local Git
    # preparation. It creates no new receipt, so it cannot change the cut.
    current = json.loads(subprocess.check_output([GH, 'api', '--hostname', 'github.com', '--method', 'GET',
        'repos/' + REPO + '/git/ref/heads/main'], timeout=50))
    need(current['ref'] == 'refs/heads/main' and current['object']['type'] == 'commit'
         and current['object']['sha'] == base, 'REMOTE_STILL_EXACT_BASE_BEFORE_COMMIT')
    env = {k: v for k, v in os.environ.items() if not k.startswith('GIT_')}
    env.update(GIT_INDEX_FILE=str(local('publication/index-v1')), GIT_NO_LAZY_FETCH='1',
               GIT_AUTHOR_NAME='Codex', GIT_AUTHOR_EMAIL='codex@openai.com',
               GIT_COMMITTER_NAME='Codex', GIT_COMMITTER_EMAIL='codex@openai.com')
    def git(*args, input=None):
        return subprocess.check_output(['git', '-c', 'core.hooksPath=/dev/null', '-c', 'gc.auto=0',
            '--git-dir=' + GIT, *args], env=env, input=input, timeout=180).decode().strip()
    need(git('rev-parse', '--is-bare-repository') == 'true'
         and git('cat-file', '-t', base) == 'commit', 'EXISTING_ISOLATED_BARE_GIT_AND_BASE')
    old = subprocess.check_output(['git', '--git-dir=' + GIT, 'show', base + ':' + PREFIX + OLD], env=env, timeout=180)
    need(old.count(b'</h1>') == 1 and MAIN.encode('ascii') not in old, 'ONLY_ORIGINAL_OLD_READER_BACKLINK')
    backlink = ('<p><a href="' + MAIN + '#reader">Continue: quantified arithmetic reduction, a certified finite CID failure, '
                'and the preserved resource refusal that blocked marking activation.</a></p>').encode('ascii')
    previous = local('publication/previous-report-with-backlink-v1.html')
    owned(previous, old.replace(b'</h1>', b'</h1>' + backlink, 1))
    sources = [(local('report/' + MAIN), PREFIX + MAIN), (local('report/' + DATA), PREFIX + DATA)]
    sources += [(folder / part['name'], PREFIX + part['name']) for part in parts]
    sources += [(folder / MANIFEST, PREFIX + MANIFEST), (previous, PREFIX + OLD)]
    need(len(sources) == len({target for path, target in sources}), 'UNIQUE_TASK_ASSET_PATHS')
    git('read-tree', base)
    assets = []
    for path, target in sources:
        if target != PREFIX + OLD:
            need(not git('ls-tree', '--full-name', base, '--', target), 'NEW_ASSET_COLLISION:' + target)
        value = pin(path)
        need(value['bytes'] < 50 * 1024 * 1024, 'GIT_ASSET_PHYSICAL_SIZE')
        raw = path.read_bytes()
        need(sha(raw) == value['sha256'], 'EXACT_ASSET_READ')
        blob = git('hash-object', '-w', '--stdin', input=raw)
        git('update-index', '--add', '--cacheinfo', '100644', blob, target)
        assets.append(dict(local=path.relative_to(ROOT).as_posix(), path=target, **value,
                           git_blob=blob, url=BASE_URL + target))
    tree = git('write-tree', '--missing-ok')
    commit = git('commit-tree', tree, '-p', base, '-m', 'Publish quantified arithmetic marking progress and scoped activation refusal')
    need(git('rev-list', '--parents', '-n', '1', commit).split() == [commit, base], 'EXACT_SOLE_PARENT')
    need(git('rev-parse', commit + '^{tree}') == tree, 'EXACT_PREPARED_TREE')
    diff = git('diff-tree', '--no-commit-id', '--no-renames', '--name-status', '-r', base, commit)
    changes = [row.split('\t') for row in diff.splitlines()]
    need(all(len(row) == 2 for row in changes) and len(changes) == len(assets)
         and {name for status, name in changes} == {entry['path'] for entry in assets}
         and all(status == ('M' if name == PREFIX + OLD else 'A') for status, name in changes),
         'TASK_ASSETS_AND_ONE_BACKLINK_ONLY')
    value = dict(status='PREPARED_TASK_ASSETS_ONLY', base=base, tree=tree, commit=commit, assets=assets, diff=diff,
                 archive_manifest='package/' + MANIFEST, archive_verification=verified,
                 remote_base_at_cut=remote, remote_base_before_commit=current,
                 readiness=readiness, primary_checkout_staged=False, pushed=False)
    owned(local('publication/prepared-v1.json'), wire(value))
    print(json.dumps(dict(status=value['status'], commit=commit, parent=base,
                          assets=len(assets), volumes=len(parts), original_files=len(files))), flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('base', nargs='?')
    parser.add_argument('--prepare-links', action='store_true')
    args = parser.parse_args()
    if args.prepare_links:
        need(args.base is None, 'PREPARE_LINKS_HAS_NO_COMMIT_BASE')
        prepare_links()
    else:
        need(args.base is not None, 'EXPLICIT_REVIEWED_COMMIT_BASE')
        package(args.base)


if __name__ == '__main__':
    main()
