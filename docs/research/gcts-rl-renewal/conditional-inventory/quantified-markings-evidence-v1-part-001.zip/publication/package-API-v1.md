# Quantified markings publication preparation

Status: `SOURCE_ONLY_PENDING_ROOT_REVIEW`. No script import, build, package,
scientific helper, Git command, network request or deployment has been executed
by this author. Only Source reading, editing, metadata hashing and AST parsing
were performed. The immutable prior pilot packager/common Sources were read as
references; this new script imports neither them nor any scientific module.

Held Source: `publication/package_quantified_v1.py`, 33,736 bytes, SHA256
`e92006f9fc203f01526589375fc15266ed80bd4185fc5dcd72a5e8b32eeabbfd`.
The prior held Source/API are preserved under
`publication/package-before-backlink-cut-v1.py` and
`publication/package-API-before-backlink-cut-v1.md`. The narrow move-only
`publication/package-backlink-cut-v1.patch` creates the changed old-reader asset
before the physical archive cut, so that exact changed asset is a member too.

## Dependencies and invocation

The script is self-contained and uses the Python standard library, local Git,
and the configured `/Users/liuyao/bin/gh` CLI for official read-only GitHub GETs.
It uses the existing isolated bare repository
`/private/tmp/gcts-history-publication-20261102-v1.git` and a new isolated index
under this run's `publication/`. It never stages the primary checkout, updates
its files/index, pushes, force-pushes, fetches or updates a Git ref.

Only Root may invoke it after reading the full Source. Use the frozen runtime:

```sh
/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12 -I -S -B publication/package_quantified_v1.py --prepare-links
```

Then validate the final local reader, save the UI receipt and Root publication
admission, and prepare the local commit:

```sh
/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12 -I -S -B publication/package_quantified_v1.py f8fb724a8d452d6ffdb547457adf6f7f02ebee72
```

These are documented commands, not executed actions. The exact parent is fixed
in Source. A changed official main must stop preparation for a separately
reviewed base. Git objects for the base and old reader must already be available
locally; lazy fetching is disabled.

## Passive gates

Both link planning and packaging verify the complete forty-eight-file frozen
set against the exact frozen protocol, reviewed Source receipts, current master
and pinned isolated runtime. They join actual phase IDs/PIDs, started protocol,
native exit zero, invocation/result/log bytes, scientific status, guards and
Source postchecks for all five executed phases. The first four have admitted
success statuses; `learn` retains scientific UNKNOWN despite native exit zero.
`evaluate` must have no worker or artifacts. The actual prerequisite refusal,
outer exit one and zero evaluation engine calls remain separate evidence.

Required passive audits are:

- `review/passive-qualification-prepare-v1.json`, schema
  `QMT-passive-qualification-prepare-audit-v1`, status
  `PASS_SAVED_QUALIFICATION_AND_PREPARATION_ONLY`.
- `review/passive-transfer-outcomes-v1.json`, schema
  `QMT-passive-transfer-outcomes-audit-v1`, status
  `PASS_SAVED_OUTCOMES_WITH_UNACTIVATED_RESOURCE_REFUSAL`.

Their physical refs/protocol bindings are checked. The script binds the actual
complete preparation counts and the certified finite CID failure, then preserves
the U-checker UNKNOWN/work refusal and absence of any activated model or target
proof. It performs no transition replay, model construction or logical checking.

The passive renderer gate is `report/build-receipt-v1.json`, schema
`Quantified-markings-passive-build-v1`, status
`PASS_PASSIVE_SAVED_DATA_AND_REPORT_BUILD`. Every recorded artifact pin and the
renderer Source are checked. Main/data paths, protocol, phase projection and
data artifact ledger must match. The report contains only the two qualification
proofs, no original arithmetic-target proof, no learned activation and no lanes.

Final packaging additionally requires:

- `publication/local-ui-v1.json`: `PASS_LOCAL_UI`, exact final main
  `source:{path,bytes,sha256}`, native integer `math_errors=0`,
  `body_overflow=false`, `console=[]`, and an empty `fatal` field when present.
- `review/root-research-assessment-v1.json`:
  `FINITE_PROGRESS_WITH_BLOCKED_ACTIVATION`.
- `publication/root-publication-admission-v1.json`:
  `PASS_REVIEWED_PUBLICATION_WITH_SCOPED_REFUSAL`. Its nested exact refs must bind
  the protocol, final main/data, renderer Source, this packager Source, both
  passive audits, local UI and build receipt. The script rechecks all refs.

These are exact saved-data associations, not an assertion that JSON alone
authenticates a scientific process. The owned actual process receipts and Root's
independent passive gates remain part of the evidence.

## Links and immutable archive cut

`--prepare-links` saves the exact original renderer HTML before changing only
the `QUANTIFIED_MARKINGS_ARCHIVE_LINK` comment region. It writes the README,
plans bounded ZIP volumes, inserts links to every volume and the manifest, and
saves `publication/archive-plan-v1.json`. Replanning before a cut preserves any
different earlier plan in a hash-named history file. Final UI must be repeated
if link bytes change. Packaging requires the planned final main/data bytes and
volume count to remain exact.

All original current-run files present at the cut are physically included
exactly once at their original relative paths. Equal bytes at different paths
are stored separately. No alias table or external-ref restoration substitutes
for them. This includes publication Sources/planning, all Source/input/raw/log/
UNKNOWN/refusal evidence, reports, reviews and local paths. The user explicitly
approved that full archive for the established public destination. Only
`package/` generated outputs are excluded from their own input cut. Index,
commit, push, Pages and live receipts created after that cut are later custody
records, never claimed to be inside their earlier archive. The prior pilot's
full archive is linked separately, not counted as physically included here.

ZIP names are `quantified-markings-evidence-v1-part-NNN.zip`; every volume is at
most \(44\) MiB and strictly below the GitHub \(50\) MiB file threshold. The
outer manifest is `quantified-markings-evidence-manifest-v1.json`. Each volume
contains the same `ARCHIVE-file-manifest-v1.json`, listing every original
path/size/SHA256 and its volume. All CRCs, member sets, original uncompressed
bytes/hashes, volume bytes and internal manifest bytes are verified. Original
file set and bytes are rechecked before Git preparation.

One oversized compressed member or changed final part count refuses the
declared design; it never omits a file or silently exceeds the ceiling. Failed
package outputs remain retained. A new scientific run, cap adjustment or archive
reconstruction is not part of this script.

## Git preparation and outputs

An official GitHub GET confirms exact main immediately before the cut; another
read-only GET checks it again before the local commit. Both use the configured
official `github.com` CLI endpoint and normal TLS. There is no network write.

The prepared tree adds only the new main/data, every archive volume and the
outer manifest under `docs/research/gcts-rl-renewal/conditional-inventory/`, and
modifies only the old `learned-literal-markings-v1.html` by adding one backlink
to the new `#reader`. `ls-tree` checks collisions without fetching missing
promisor blobs. An isolated index starts from the full base tree; the final
name/status diff must be exactly those additions plus that one modification.
The new commit's tree and sole parent are checked. Nothing is pushed.

`publication/prepared-v1.json` has status `PREPARED_TASK_ASSETS_ONLY`, exact
base/tree/commit, all local/live asset paths and hashes, diff, archive manifest
and verification, readiness and remote observations, `pushed=false` and
`primary_checkout_staged=false`. With \(n\) volumes there are \(n+4\) assets;
one volume gives five assets. Root must separately review/push the exact commit
and verify official remote/Pages/live asset bytes and UI before completion.

The research goal remains ACTIVE. This publication reports finite preparation
and one scoped failure with blocked activation; it does not report a completed
marking comparison, new arithmetic theorem, RL gain or fixed universal palette.
