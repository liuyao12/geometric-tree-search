"""Passive QMT saved-data reader. Never import scientific modules or replay.

Read frozen protocol/file/process pins and actual completed/refused phase
outputs. A missing/stopped phase is displayed, not replaced with a proof.
Root reviews Source before executing this assembler/renderer.
"""
import gzip
import hashlib
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'report'
PROTOCOL='protocol/frozen-protocol-v1.json'
PHASES=['qualify','prepare','acquire','label','learn','evaluate']
SEMANTIC=['statement','proof','slots','slot_to_native','native_to_slot','reference_mapping',
          'proof_dag','selected','selected_sha256','original_statement_sha256','scope']
LEDGER={};CACHE={};BOUND=134217728


def need(ok,why):
    if not ok:raise ValueError(why)


def wire(x):return (json.dumps(x,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')
def sha(x):return hashlib.sha256(wire(x)).hexdigest()
def same(a,b,why):need(wire(a)==wire(b),why)


def bytepin(p):
    h=hashlib.sha256();n=0
    with p.open('rb') as f:
        for block in iter(lambda:f.read(1048576),b''):h.update(block);n+=len(block)
    return dict(bytes=n,sha256=h.hexdigest())


def local(name):
    need(type(name) is str and bool(name),'RELATIVE_PATH');p=Path(name)
    need(not p.is_absolute() and '..' not in p.parts,'ROOT_PATH')
    out=ROOT
    for part in p.parts:out=out/part;need(not out.is_symlink(),'NO_SYMLINK')
    need(out.resolve().is_relative_to(ROOT),'ROOT_CONTAINMENT');return out


def pin(name):
    value=dict(path=name,**bytepin(local(name)));LEDGER[name]=value;return value


def read(name,reference=None):
    value=pin(name)
    if reference is not None:
        same(value,{k:reference[k] for k in ('path','bytes','sha256')},'EXACT_SAVED_BYTES:'+name)
        need(reference.get('complete_json',True) is True,'COMPLETE_SAVED_JSON')
    if name not in CACHE:
        p=local(name)
        with gzip.open(p,'rb') if p.suffix=='.gz' else p.open('rb') as f:b=f.read(BOUND+1)
        need(len(b)<=BOUND,'JSON_READ_BOUND');CACHE[name]=json.loads(b)
    return CACHE[name]


def checked(ref):return read(ref['path'],ref)


def refs_in(value):
    if type(value) is dict:
        if {'path','bytes','sha256'}<=value.keys():
            same(pin(value['path']),{k:value[k] for k in ('path','bytes','sha256')},'ALL_SAVED_REF_BYTES')
            need(value.get('complete_json',True) is True,'ALL_CAPTURE_REFS_COMPLETE')
        else:
            for v in value.values():refs_in(v)
    elif type(value) is list:
        for v in value:refs_in(v)


def environment():
    p=read(PROTOCOL);need(p['status']=='FROZEN_BEFORE_SCIENTIFIC_IMPORTS','FROZEN_PROTOCOL')
    a=read('review/root-source-admission-v1.json');need(a['status']=='PASS_SOURCE_REVIEW_BEFORE_FREEZE','SOURCE_ADMISSION')
    names={'review/root-source-admission-v1.json'}
    for folder in ('source','reference','input','plan'):
        for path in (ROOT/folder).rglob('*'):
            need(not path.is_symlink(),'NO_FROZEN_SYMLINK')
            if path.is_file():
                need(path.suffix!='.pyc' and '__pycache__' not in path.parts,'NO_BYTECODE')
                names.add(path.relative_to(ROOT).as_posix())
    for ref in a['reviewed']:
        same(pin(ref['path']),{k:ref[k] for k in ('path','bytes','sha256')},'REVIEW_PIN');names.add(ref['path'])
    same([pin(n) for n in sorted(names)],p['files'],'EXACT_FROZEN_SET')
    executable=Path(sys.executable).resolve()
    runtime=dict(executable=dict(path=str(executable),**bytepin(executable)),version=sys.version,
        isolated=sys.flags.isolated,no_site=sys.flags.no_site,dont_write_bytecode=sys.dont_write_bytecode)
    need(sys.flags.isolated==1 and sys.flags.no_site==1 and sys.dont_write_bytecode is True,'ISOLATED_PINNED_RUNTIME')
    same(runtime,p['runtime'],'CURRENT_RUNTIME')
    master=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md')
    same(dict(path=str(master),**bytepin(master)),p['master'],'CURRENT_MASTER')
    return p,dict(runtime=runtime,master=p['master'],frozen_files=len(names))


def phase(name,protocol):
    paths=dict(result='data/'+name+'/result.json',started='run/'+name+'/started.json',
        invocation='run/'+name+'/invocation.json',observer='run/'+name+'/observer.json')
    values={k:read(n) for k,n in paths.items() if local(n).exists()}
    result=values.get('result');s=values.get('started');i=values.get('invocation');o=values.get('observer')
    state='NOT_RUN' if not values else 'IN_PROGRESS_OR_INCOMPLETE'
    clean=False
    if s is not None:same(s['protocol'],pin(PROTOCOL),'STARTED_PROTOCOL');need(s['phase']==name,'STARTED_PHASE')
    if i is not None:need(i['phase']==name,'INVOCATION_PHASE')
    if o is not None:
        need(o['phase']==name,'OBSERVER_PHASE');same(o['log'],pin('run/'+name+'/stdout.log'),'OWNED_LOG_BYTES')
        state='FAILED_OR_STOPPED_PROCESS'
    if s is not None and i is not None and o is not None:
        need(all(type(x['pid']) is int and x['pid']>0 for x in (s,i,o)) and s['pid']==i['pid']==o['pid'],'PHASE_PID')
        if i.get('result') is not None:
            same(checked(i['result']),result,'EXACT_PHASE_RESULT_BYTES')
            need(i['scientific_status']==result['status'],'INVOCATION_SCIENCE_STATUS')
        clean=(o['status']=='TERMINAL' and type(o['native_exit_code']) is int and o['native_exit_code']==0
            and i['status']=='COMPLETE' and i['error_type'] is None
            and all(o[k] is None for k in ('guard_reason','observer_error','reap_error','postcheck_error'))
            and i['postcheck_error'] is None and i['frozen_postcheck']==o['frozen_postcheck']==protocol['status'])
        state='CLEAN_RECORDED_PHASE' if clean else 'FAILED_OR_STOPPED_PROCESS'
    if result is not None:refs_in(result)
    record=dict(name=name,process_status=state,native_exit_code=None if o is None else o['native_exit_code'],
        process_clean=clean,scientific_status=None if result is None else result['status'],
        worker_seconds=None if i is None else i['seconds'],observer_seconds=None if o is None else o['seconds'],
        worker_highwater_rss_bytes=None if i is None else i['maxrss']*(1 if i['maxrss_units']=='bytes' else 1024),
        guard_reason=None if o is None else o['guard_reason'],error=None if i is None else i['error_type'],
        refs={k:pin(n) for k,n in paths.items() if k in values})
    record['admitted']=clean and result is not None and result['status']==protocol['admitted_statuses'][name]
    return record,result


def event_sample(raw):
    events=raw.get('events',[]);indices=sorted(set(range(min(12,len(events))))|set(range(max(0,len(events)-12),len(events))))
    out=[]
    for index in indices:
        e=json.loads(wire(events[index]))
        if e['kind']=='BRANCH':
            d=e['data'];e['data']=dict(generation=d['generation'],legal_count=len(d['legal']),
                order_count=len(d['order']),first_candidate=d['order'][0])
        out.append(e)
    return dict(records=out,retained_payload_rows=len(events),emitted_total=raw['event_extent']['total'],
                scope='First/last retained event sample; last retained is not an omitted suffix. Full original domains and payloads remain in the archive.')


def engine_summary(refs):
    raw=checked(refs['raw']);c=checked(refs['semantic'])
    if c['status']=='VERIFIED':
        need(raw['status']==c['run_status'] and c['event_coverage']=='COMPLETE','SEMANTIC_RAW_JOIN')
        same(c['event_sha256'],raw['event_extent']['sha256'],'SEMANTIC_EVENT_BINDING')
        same(c['model_sha256'],raw['model_sha256'],'SEMANTIC_MODEL_BINDING')
        need(c['bounded_absence'] is (raw['status']=='UNSAT'),'EXACT_ABSENCE_SCOPE')
    else:need(c['bounded_absence'] is False,'NO_UNKNOWN_ABSENCE')
    return dict(raw_status=raw['status'],reason=raw['reason'],semantic_status=c['status'],
        semantic_reason=c['reason'],bounded_absence=c['bounded_absence'],stats=raw['stats'],
        event_extent=raw['event_extent'],rollback_extent=raw['rollback_extent'],sample=event_sample(raw),
        selected=raw['selected'],refs=refs,producer_intermediate_bookkeeping='NOT_OBSERVED_IN_LARGE_RUN')


def proof_record(identifier,kind,label,m,n,b,model,refs,catalogue,aliases):
    need(m['status']==n['status']=='UNVERIFIED_NATIVE_CERTIFICATE' and b['status']=='VERIFIED','ONLY_ADMITTED_PROOFS')
    for k in SEMANTIC:same(m[k],n[k],'TWO_NATIVE_PROJECTIONS:'+k)
    same(b['checked_lines'],len(m['proof']),'WHOLE_NATIVE_PROOF_COUNT')
    same(sha(m['statement']),m['original_statement_sha256'],'PROOF_ORIGINAL_STATEMENT')
    byid={x['id']:x for x in model['inventory']['placements']}
    need(all(cid in byid for cid in m['selected']),'SELECTED_LITERAL_ROWS')
    return dict(id=identifier,kind=kind,label=label,statement=m['statement'],proof=m['proof'],slots=m['slots'],
        native_to_slot=m['native_to_slot'],slot_to_native=m['slot_to_native'],reference_mapping=m['reference_mapping'],
        proof_dag=m['proof_dag'],selected_rows=[byid[c] for c in m['selected']],
        native_status=b['status'],aliases=aliases,scope=m['scope'],refs=refs,
        formula_lookup={str(x['formula_id']):catalogue['formulas'][x['formula_id']-1]
                        for x in m['slots'] if x['formula_id']>0})


def assemble():
    protocol,external=environment();phases=[];results={}
    for name in PHASES:
        record,value=phase(name,protocol);phases.append(record);results[name]=value
    admitted={x['name']:x['admitted'] for x in phases}
    declaration=read('input/arithmetic-declaration-v1.json')
    aliases={declaration['names'][k]:v for k,v in dict(S='S',add='add',x='x',zero='0').items()}
    proofs=[];qualification=None;prepared=None;model=None;prepare_info=None;acquisition=None;label_info=None;learning=None;lanes=[]
    if admitted['qualify']:
        q=results['qualify'];logical=[]
        for item in q['logical']:
            p=checked(item['refs']['prepared']);m=checked(item['refs']['decoded']);n=checked(item['refs']['independent_decoded']);b=checked(item['refs']['native'])
            proof=proof_record('qual-'+item['id'],'QUALIFICATION','Qualification only · '+item['id'],m,n,b,p['model'],item['refs'],p['catalogue'],{})
            proofs.append(proof);logical.append(dict(id=item['id'],kind=item['kind'],census=item['census'],native_lines=item['native_lines'],rules=item['rules'],oracle_status=item['oracle_status']))
        qualification=dict(counts=q['counts'],logical=logical,controls=q['controls'],scope=q['scope'])
    if admitted['prepare']:
        p=results['prepare'];prepared=checked(p['refs']['prepared']);model=checked(p['refs']['model'])
        same(sha(model),p['scope_sha256'],'PREPARED_ENGINE_SCOPE')
        same(prepared['binding'],p['prepared_binding'],'ORIGINAL_PREPARED_BINDING')
        prepare_info=dict(case_id=p['case_id'],slots=p['slots'],scope_sha256=p['scope_sha256'],
            census=p['census'],ZERO_checks=p['ZERO_checks'],costs=p['costs'],refs=p['refs'],
            mandatory_mark_rows=sum(len(r['m']) for r in model['inventory']['placements']),seed_mark_rows=len(model['seed']['m']))
    if results['acquire'] is not None and 'refs' in results['acquire'] and 'engine' in results['acquire']['refs']:
        a=results['acquire'];acquisition=dict(cid=a.get('cid'),scope_sha256=a.get('scope_sha256'),
            engine=engine_summary(a['refs']['engine']),admitted=admitted['acquire'],scope='Proposal only; no negative inference from a prefix.')
    if admitted['label']:
        l=results['label'];packet=checked(l['query_packets_ref']);binding=packet['binding']
        same(sha(packet['raw_result']),binding['raw_result_sha256'],'FIXED_QUERY_RAW_OBJECT')
        same(sha(packet['semantic_receipt']),binding['semantic_receipt_sha256'],'FIXED_QUERY_C_OBJECT')
        same(sha(packet['fixed_model']),binding['fixed_model_sha256'],'FIXED_QUERY_MODEL_OBJECT')
        same([binding],l['query_bindings'],'LABEL_RESULT_BINDINGS')
        same(l['labels'][0]['certificate_binding_sha256'],sha(binding),'LEARNER_LABEL_BINDING')
        c=packet['semantic_receipt']
        if packet['label']=='NEGATIVE':need(c['status']=='VERIFIED' and c['bounded_absence'] is True and c['event_coverage']=='COMPLETE','NEGATIVE_ONLY_SCOPED_EXHAUSTION')
        if packet['label']=='UNKNOWN':need(c['bounded_absence'] is False,'UNRESOLVED_NOT_NEGATIVE')
        label_info=dict(cid=packet['cid'],label=packet['label'],scope_sha256=packet['scope_sha256'],
            semantic_status=c['status'],semantic_reason=c['reason'],bounded_absence=c['bounded_absence'],
            binding=binding,event_extent=packet['raw_result']['event_extent'],refs=l['refs'],costs=l['costs'])
    if admitted['learn']:
        l=results['learn'];s=checked(l['refs']['synthesis']);u=checked(l['refs']['overlay_receipt'])
        need(u['status']=='VERIFIED_CONDITIONAL_ON_SCOPED_EXHAUSTION','ADMITTED_CONDITIONAL_OVERLAY')
        marked=checked(l['refs']['marked_model']);control=checked(l['refs']['control_model'])
        same(u['model_bindings'],dict(base=sha(model),marked=sha(marked),control=sha(control)),'EXACT_OVERLAY_LANE_BINDINGS')
        byid={x['id']:x for x in model['inventory']['placements']}
        learning=dict(synthesis=s,admission=u,preservation_basis=l['preservation_basis'],costs=l['costs'],refs=l['refs'],
            forbidden_rows=[byid[cid] for cid in s['forbidden_cids']],control_forbidden=control['unary_nogoods'])
    if admitted['evaluate']:
        e=results['evaluate']
        for item in e['lanes']:
            run=engine_summary(item['refs']);run.update(lane=item['lane'],admitted_status=item['admitted_status'],native_status=item['native_status'],
                native_proof_lines=item.get('native_proof_lines'),costs=item['costs'])
            lanes.append(run)
            if item['admitted_status']=='VERIFIED_NATIVE_POSITIVE':
                refs=item['native_refs'];m=checked(refs['adapter_decoded']);n=checked(refs['independent_decoded']);b=checked(refs['native_receipt'])
                same(checked(refs['native_proof']),m['proof'],'SAVED_WHOLE_NATIVE_PROOF')
                native_model=checked(item['refs']['model'])
                proof=proof_record('arith-'+item['lane'],'ARITHMETIC','Arithmetic target · '+item['lane'],m,n,b,native_model,refs,prepared['catalogue'],aliases)
                same(proof['statement'],declaration['problem'],'ACTUAL_TARGET_STATEMENT');proofs.insert(0,proof)
    # Capture stopped/refused helper outputs only through the actual phase record.
    # They remain archive-linked, not promoted into the admitted proof list.
    return dict(schema='Quantified-markings-reader-data-v1',status='PASS_PASSIVE_SAVED_DATA_PROJECTION',
        phases=phases,declaration=declaration,prepare=prepare_info,acquisition=acquisition,label=label_info,
        learning=learning,lanes=lanes,qualification=qualification,proofs=proofs,
        costs_scope='Phase worker/observer and helper intervals overlap. Large arithmetic has semantic events/endpoints only, no actual intermediate-map observation claim.',
        protocol=pin(PROTOCOL),provenance=dict(external=external,artifact_pins=list(LEDGER.values())),
        scope='Seen arithmetic statement, fresh complete finite RF/shared-slot model; mandatory formula markings retained, extra unary layer only. No fixed finite Wang palette, RL, new theorem or comparative advantage.')


PAGE=r'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Quantified proof search and extra markings</title><style>
:root{--ink:#18343b;--muted:#5d7179;--line:#dbe3df;--green:#167c70;--purple:#8059ad;--orange:#ba7730;--red:#bc4e48}*{box-sizing:border-box}body{margin:0;background:#f4f6f2;color:var(--ink);font:16px/1.6 system-ui,-apple-system,sans-serif}main{max-width:1190px;margin:auto;padding:35px 24px 70px}nav{display:flex;gap:18px;flex-wrap:wrap;font-size:13px}a{color:var(--green)}h1{font-size:clamp(35px,5.7vw,66px);line-height:1.07;letter-spacing:-.045em;margin:35px 0 20px}h2{font-size:26px;letter-spacing:-.025em;margin:0 0 12px}.eyebrow{text-transform:uppercase;letter-spacing:.14em;font-size:11px;color:var(--green)}.lede{font-size:19px;color:var(--muted);max-width:930px}section{margin:30px 0}.panel{background:#fff;border:1px solid var(--line);padding:23px;border-radius:15px;min-width:0}.grid{display:grid;grid-template-columns:1fr 1fr;gap:18px}.muted,small{color:var(--muted)}.note{border-left:4px solid var(--green);padding:12px 15px;background:#edf6f1;border-radius:0 8px 8px 0}.warning{border-color:var(--orange);background:#fff8ec}.tag{display:inline-block;background:#edf2ee;padding:3px 7px;border-radius:6px;font-size:11px;margin:2px;overflow-wrap:anywhere}.good{color:#28724e}.bad{color:var(--red)}.controls{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin:13px 0}select,button{font:inherit;font-size:13px;padding:8px 11px;border:1px solid #c5d4cc;border-radius:8px;background:white;max-width:100%}.scroll,.math{max-width:100%;overflow:auto}.math{display:block;padding:3px 0}table{width:100%;border-collapse:collapse;font-size:13px}th,td{padding:9px 8px;text-align:left;vertical-align:top;border-bottom:1px solid var(--line);overflow-wrap:anywhere}th{font-size:11px;color:var(--muted);white-space:nowrap}.proof{table-layout:fixed}.proof th:nth-child(1){width:5%}.proof th:nth-child(2){width:43%}.proof th:nth-child(3){width:31%}.proof th:nth-child(4){width:21%}.active{background:#eef6ef}code,pre{font:12px/1.5 ui-monospace,monospace}pre{background:#eff3ef;border-radius:8px;padding:13px;max-width:100%;overflow:auto}details{margin:12px 0}summary{font-size:13px;color:var(--muted);cursor:pointer}.cards{display:flex;gap:10px;flex-wrap:wrap}.tile{flex:1;min-width:135px;border:2px solid var(--green);border-radius:2px;padding:12px;background:#fafdf8}.stripe{height:13px;border-radius:2px;margin:7px 0}.port{background:var(--purple)}.guard0{background:#3e72b5}.guard1{background:#c85845}.absent{background:repeating-linear-gradient(135deg,#fff,#fff 4px,#dfe6e0 4px,#dfe6e0 8px)}.diagram{overflow:auto;border:1px solid var(--line);background:#fafdf8;border-radius:12px}.diagram svg{display:block;width:100%;height:auto;min-width:560px}#fatal{white-space:pre-wrap;color:var(--red)}mjx-container{max-width:100%}mjx-container[display=true]{overflow:auto}@media(max-width:800px){main{padding:24px 13px}.panel{padding:17px}.grid{grid-template-columns:1fr}.proof{min-width:680px}}
</style><script>window.MathJax={tex:{inlineMath:[['\\(','\\)']],displayMath:[['\\[','\\]']]},options:{skipHtmlTags:['script','style','pre','code']},startup:{ready(){MathJax.startup.defaultReady();window.__mathReady=MathJax.startup.promise;}}};</script><script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js"></script></head><body><main>
<nav><a href="learned-literal-markings-v1.html">Previous literal-marking pilot</a><a href="#phases">Actual phases</a><a href="#reader">Proof reader</a><a href="#overlay">Extra layer</a><a href="#assessment">Assessment</a></nav><p class="eyebrow">GCTS research · quantified finite proof model</p><h1>Testing extra markings<br>on quantified proof search</h1><p class="lede">The original formula and active-line markings remain mandatory. A separate fresh unary layer may reject a placement only after its complete fixed-CID extension query is independently certified impossible in the declared finite model.</p><div id="fatal"></div><div id="outcome" class="note"></div>
<section class="panel"><h2>The declared arithmetic statement</h2><div id="target"></div><p class="muted">This is a seen addition-zero/equality-congruence statement under a fresh namespace, with a prospective finite slot bound. It is not full Peano arithmetic or induction, and this representation is not a fixed finite universal Wang palette.</p><div id="basis"></div></section>
<section id="phases" class="panel"><h2>What actually completed</h2><div id="phase-table" class="scroll"></div><p class="muted">Scientific status, process completion and native proof admission are distinct. A missing/stopped phase does not borrow evidence from another run. UNKNOWN is never a negative label.</p></section>
<section id="reader" class="panel"><p class="eyebrow">Actual independently decoded, native-checked certificates</p><h2>Formula and English, line by line</h2><div class="controls"><select id="proof-select"></select><label><input id="literal" type="checkbox"> Literal symbol names</label></div><div id="proof-scope"></div><div id="proof-goal"></div><div id="slots" class="diagram"></div><div id="proof-table" class="scroll"></div><details><summary>Exact original proof and slot/reference maps</summary><pre id="proof-json"></pre></details><p class="muted">Each card is an anchored proof-slot owner with point markings, not a conventional geometric tile. Orange represents active-line values, purple formula IDs, and blue/red any extra guard assignment. Remote connectors are actual earlier-slot receptors. A proof line is the decoded logical assertion; it is not a NAND row or a universal Wang-grid row.</p></section>
<section id="overlay" class="panel"><h2>The extra marking layer</h2><div id="overlay-status"></div><div id="guard-cards" class="cards"></div><div id="label-detail"></div><p>The guard site is prospectively prescribed. Its location is not learned geometry. The learner receives scoped CID labels and binding hashes, with no old proof, expected CID or marking. No proved negative means both extra assignment arrays stay empty.</p><details><summary>Actual label, synthesis and conditional admission</summary><pre id="overlay-json"></pre></details></section>
<section class="panel"><h2>Matched searches, including unresolved outcomes</h2><div id="lanes" class="scroll"></div><details><summary>Retained event samples and exact assurance scope</summary><div id="samples"></div></details><p class="muted">Large runs retain semantic events and serialized endpoints; intermediate producer maps were not observed. Tiny qualification has separate actual graph observations. Placed-event counts include failed-branch placements; final selected counts are separate. Complete elimination-reason counters are unavailable.</p></section>
<section id="assessment" class="grid"><div class="panel"><h2>What can be concluded</h2><div id="assessment-data"></div><p>The ordinary filter contains exactly the same certified CID list as the added literal layer. Any matching pruning demonstrates an encoding of the same information. This study does not establish a distinct GCTS advantage, reinforcement learning, a new theorem, held-out transfer or geometric prototype learning.</p><p>Fixed-CID exhaustion is a finite scoped claim. It does not prove the mathematical goal false or unprovable without these formula and slot bounds.</p></div><div class="panel"><h2>Cost and evidence scope</h2><div id="costs"></div><p>Worker, observer and helper intervals overlap; they are not added as independent costs. The fixed warm lane order is not a comparative performance benchmark. Acquisition, labeling and assurance must be charged before judging learned pruning.</p></div></section>
<section class="panel"><h2>Qualification and exact provenance</h2><div id="qualification"></div><details><summary>Protocol, artifact pins and scope</summary><pre id="provenance"></pre></details><p><a href="quantified-markings-data-v1.json.gz">Download the readable data</a>. Full original Sources, raw records, refusals and logs are retained in the approved archive.</p></section>
<!-- QUANTIFIED_MARKINGS_ARCHIVE_LINK -->
</main><script>
'use strict';const $=x=>document.getElementById(x),esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])),tex=x=>String(x).replace(/[\\{}_$%&#^~]/g,c=>'\\'+c),math=x=>'<span class="math">\\('+x+'\\)</span>';let D,P,A={},literal=false,selectedLine=null,mathQueue=Promise.resolve();const num=x=>x==null?'not recorded':Number(x).toLocaleString(undefined,{maximumFractionDigits:4});
function typeset(el){mathQueue=mathQueue.then(async()=>{while(!window.MathJax||!MathJax.typesetPromise)await new Promise(r=>setTimeout(r,25));await MathJax.startup.promise;if(el.isConnected){MathJax.typesetClear([el]);await MathJax.typesetPromise([el]);}}).catch(e=>{$('fatal').textContent='Math error: '+e.message;});}
async function load(){const r=await fetch('quantified-markings-data-v1.json.gz');if(!r.ok)throw Error('Data HTTP '+r.status);const b=new Uint8Array(await r.arrayBuffer());if(b[0]===31&&b[1]===139)return JSON.parse(await new Response(new Blob([b]).stream().pipeThrough(new DecompressionStream('gzip'))).text());return JSON.parse(new TextDecoder().decode(b));}
function symbol(x){return literal?x:(A[x]??x);}function term(a){if(a[0]==='var')return tex(symbol(a[1]));const name=symbol(a[1]);if(!a[2].length)return name==='0'?'0':'\\operatorname{'+tex(name)+'}';return (name==='S'?'S':'\\operatorname{'+tex(name)+'}')+'('+a[2].map(term).join(',')+')';}
function formula(a){switch(a[0]){case'pred':return '\\operatorname{'+tex(symbol(a[1]))+'}'+(a[2].length?'('+a[2].map(term).join(',')+')':'');case'eq':return term(a[1])+'='+term(a[2]);case'imp':return '('+formula(a[1])+'\\Rightarrow '+formula(a[2])+')';case'and':case'or':return '('+formula(a[1])+(a[0]==='and'?'\\land ':'\\lor ')+formula(a[2])+')';case'not':return '\\neg '+formula(a[1]);case'all':return '\\forall '+tex(symbol(a[1]))+'\\,('+formula(a[2])+')';case'bot':return '\\bot';default:return '\\text{'+tex(JSON.stringify(a))+'}';}}
function reason(line){const n=x=>Number(x)+1;switch(line.rule){case'axiom':return 'Use the named hypothesis '+line.name+'.';case'refl':return 'A term equals itself.';case'instantiate':return 'Use universal instantiation at the recorded term; the displayed implication is the native schema.';case'eq_subst':return 'Use equality substitution in the recorded formula context.';case'distribute':return 'Use the quantified distribution schema with its checked side conditions.';case'tautology':return 'Use a propositional tautology.';case'mp':return 'From line '+n(line.antecedent)+' and its implication on line '+n(line.implication)+', infer the consequent.';case'generalize':return 'Generalize line '+n(line.source)+' over '+symbol(line.variable)+' under the closed hypothesis context.';default:return line.rule;}}
function refs(line){return line.rule==='mp'?[line.antecedent,line.implication]:line.rule==='generalize'?[line.source]:[];}
function slotDiagram(){if(!P)return '';const ss=P.slots,w=Math.max(600,ss.length*112),h=205,row=new Map(P.selected_rows.map(r=>[r.id,r]));let s='<svg viewBox="0 0 '+w+' '+h+'" role="img" aria-label="Actual selected slot owners and remote marking receptors"><defs><marker id="arrow" markerWidth="7" markerHeight="7" refX="6" refY="3" orient="auto"><path d="M0,0 L6,3 L0,6" fill="#ad9cc5"/></marker></defs>';for(const x of ss){const token=JSON.parse(x.cid);for(const earlier of token[3]){const x1=55+x.slot*112,x2=55+earlier*112;s+='<path d="M'+x1+',105 Q'+((x1+x2)/2)+','+(15+Math.abs(x1-x2)%50)+' '+x2+',105" fill="none" stroke="#b8a5d0" stroke-width="1.5" marker-end="url(#arrow)"/>';}}for(const x of ss){const xx=9+x.slot*112,selected=x.native_line_index_or_null===selectedLine,m=row.get(x.cid),extra=m.m.find(([p,v])=>p==='learned:unary:guard:v1');s+='<g data-slot="'+x.slot+'"><rect x="'+xx+'" y="105" width="94" height="89" rx="2" fill="'+(selected?'#e9f5ec':'#fafff7')+'" stroke="'+(selected?'#167c70':'#93afa0')+'" stroke-width="2"/><text x="'+(xx+8)+'" y="122" font-size="12">slot '+x.slot+' · '+JSON.parse(x.cid)[1]+'</text><rect x="'+(xx+8)+'" y="131" width="78" height="10" fill="'+(x.active?'#c18943':'#dde2d9')+'"/><rect x="'+(xx+8)+'" y="147" width="78" height="10" fill="hsl('+((x.formula_id*47)%360)+' 38% 65%)"/><text x="'+(xx+8)+'" y="174" font-size="10">active '+x.active+'; FID '+x.formula_id+'</text><rect x="'+(xx+8)+'" y="181" width="78" height="5" fill="'+(extra?(extra[1]==='0'?'#3e72b5':'#c85845'):'#e8ece5')+'"/></g>';}return s+'</svg>';}
function renderProof(){const id=$('proof-select').value;P=D.proofs.find(p=>p.id===id);selectedLine=null;if(!P){$('proof-scope').innerHTML='<p class="note warning">No admitted target or qualification proof is available in this snapshot.</p>';$('proof-goal').innerHTML='';$('proof-table').innerHTML='';$('slots').innerHTML='';$('proof-json').textContent='';return;}A=P.aliases;literal=$('literal').checked;$('proof-scope').innerHTML='<p class="note '+(P.kind==='QUALIFICATION'?'warning':'')+'"><b>'+esc(P.kind==='QUALIFICATION'?'Qualification proof only — not the arithmetic target':'Actual arithmetic-target proof')+'</b> · '+esc(P.label)+' · '+P.proof.length+' native-checked lines, '+P.slots.length+' slots.</p>';$('proof-goal').innerHTML=math(formula(P.statement.goal))+'<details><summary>Exact hypothesis context and display symbol map</summary><pre>'+esc(JSON.stringify({theory:P.statement.theory,display_aliases:P.aliases},null,2))+'</pre></details>';$('proof-table').innerHTML='<table class="proof"><thead><tr><th>Line</th><th>Decoded assertion</th><th>English meaning</th><th>Rule / references</th></tr></thead><tbody>'+P.proof.map((l,i)=>'<tr id="line-'+i+'"><td><button data-line="'+i+'">'+(i+1)+'</button></td><td>'+math(formula(l.formula))+'</td><td>'+esc(reason(l))+'</td><td><code>'+esc(l.rule)+'</code><br>'+refs(l).map(x=>'line '+(x+1)).join(', ')+'<br>slot '+P.native_to_slot[i]+'</td></tr>').join('')+'</tbody></table>';$('slots').innerHTML=slotDiagram();const choose=i=>{selectedLine=i;for(const tr of $('proof-table').querySelectorAll('tbody tr'))tr.classList.toggle('active',tr.id==='line-'+i);$('slots').innerHTML=slotDiagram();bindSlots();};const bindSlots=()=>{for(const g of $('slots').querySelectorAll('[data-slot]'))g.onclick=()=>{const i=P.slots.find(x=>x.slot===+g.dataset.slot).native_line_index_or_null;if(i!==null)choose(i);};};for(const b of $('proof-table').querySelectorAll('[data-line]'))b.onclick=()=>choose(+b.dataset.line);bindSlots();$('proof-json').textContent=JSON.stringify({proof:P.proof,slots:P.slots,reference_mapping:P.reference_mapping,proof_dag:P.proof_dag},null,2);typeset($('reader'));}
function init(){const targetProofs=D.proofs.filter(p=>p.kind==='ARITHMETIC'),last=D.phases.filter(p=>p.scientific_status!==null).at(-1);$('outcome').innerHTML=targetProofs.length?'<b>'+targetProofs.length+' admitted arithmetic lane proof(s).</b> Inspect the exact native assertions below.':'<b>No admitted arithmetic-target proof is available.</b> '+(last?'Latest recorded phase: '+esc(last.name)+' / '+esc(last.scientific_status)+'.':'No completed phase is recorded.')+' Any proof shown below is explicitly labeled qualification evidence.';A=Object.fromEntries(Object.entries(D.declaration.names).map(([k,v])=>[v,({S:'S',add:'add',x:'x',zero:'0'})[k]]));$('target').innerHTML='<p>Hypothesis '+math(formula(D.declaration.problem.theory.axioms[Object.keys(D.declaration.problem.theory.axioms)[0]]))+'</p><p>Goal '+math(formula(D.declaration.problem.goal))+'</p>';$('basis').innerHTML=D.prepare?'<p><b>'+D.prepare.census.formulas+'</b> original finite RF formulas; <b>'+D.prepare.census.rows+'</b> complete candidate rows; '+D.prepare.slots+' slots; '+D.prepare.ZERO_checks+' native ZERO checks. All mandatory formula/active markings remain.</p>':'<p class="muted">No admitted complete preparation yet; no smaller substitute palette is displayed.</p>';$('phase-table').innerHTML='<table><thead><tr><th>Phase</th><th>Scientific status</th><th>Process / native exit</th><th>Worker / observed seconds</th></tr></thead><tbody>'+D.phases.map(p=>'<tr><td>'+p.name+'</td><td>'+esc(p.scientific_status??'not run')+'</td><td>'+esc(p.process_status)+' / '+esc(p.native_exit_code??'not recorded')+'</td><td>'+num(p.worker_seconds)+' / '+num(p.observer_seconds)+'</td></tr>').join('')+'</tbody></table>';$('proof-select').innerHTML=D.proofs.map(p=>'<option value="'+esc(p.id)+'">'+esc(p.label)+'</option>').join('');if(targetProofs.length)$('proof-select').value=targetProofs[0].id;renderProof();$('proof-select').onchange=renderProof;$('literal').onchange=renderProof;const l=D.learning,lab=D.label;$('overlay-status').innerHTML=l?'<p>Conditional admission: <b>'+esc(l.admission.status)+'</b>. Forbidden CIDs: '+l.synthesis.forbidden_cids.length+'. '+(l.synthesis.forbidden_cids.length?'Only those receive the extra rejecting literal.':'The additional layer is the empty identity; no pruning is claimed.')+'</p>':'<p class="note warning">No admitted learned overlay is available. The original mandatory markings are not reclassified as newly learned values.</p>';$('guard-cards').innerHTML=l&&l.synthesis.forbidden_cids.length?'<div class="tile">Prescribed seed guard<div class="stripe guard0"></div><code>"0"</code></div>'+l.synthesis.extra_assignments.map(x=>'<div class="tile">Certified forbidden CID<div class="stripe guard1"></div><code>'+esc(x.id)+'</code><br>extra value <code>"1"</code></div>').join(''):'<div class="tile">Additional seed<div class="stripe absent"></div>absent</div><div class="tile">Additional CID components<div class="stripe absent"></div>absent</div>';$('label-detail').innerHTML=lab?'<p>Fresh fixed-CID label: <b>'+esc(lab.label)+'</b>; semantic check '+esc(lab.semantic_status)+'. '+(lab.bounded_absence?'Complete scoped finite exhaustion; this excludes the placement, not the mathematical statement.':'No negative claim follows from this record.')+'</p><code>'+esc(lab.cid)+'</code>':'<p class="muted">No admitted fixed-CID label is recorded.</p>';$('overlay-json').textContent=JSON.stringify({label:D.label,learning:D.learning},null,2);$('lanes').innerHTML=D.lanes.length?'<table><thead><tr><th>Lane</th><th>Raw / semantic</th><th>Admitted result</th><th>Placed / final selected</th><th>Branches / backtracks</th><th>Work</th></tr></thead><tbody>'+D.lanes.map(x=>'<tr><td>'+x.lane+'</td><td>'+esc(x.raw_status)+' / '+esc(x.semantic_status)+'</td><td>'+esc(x.admitted_status)+'</td><td>'+x.stats.placements+' / '+x.selected.length+'</td><td>'+x.stats.branches+' / '+x.stats.backtracks+'</td><td>'+num(x.stats.work)+'</td></tr>').join('')+'</tbody></table>':'<p class="muted">No admitted evaluation phase yet. Missing lanes are not zero-cost results.</p>';$('samples').innerHTML=D.lanes.map(x=>'<details><summary>'+esc(x.lane)+' · '+x.sample.retained_payload_rows+' retained of '+x.sample.emitted_total+' emitted events</summary><p>'+esc(x.sample.scope)+'</p><pre>'+esc(JSON.stringify(x.sample.records,null,2))+'</pre></details>').join('');$('assessment-data').innerHTML='<p>'+esc(D.scope)+'</p><p>Source and native evidence remain distinct: '+D.phases.filter(x=>x.admitted).length+' phases admitted, '+targetProofs.length+' actual target-positive proof records.</p>';$('costs').innerHTML='<p>Complete phase worker totals, with observed process totals separately:</p>'+D.phases.map(p=>'<p><b>'+p.name+'</b>: '+num(p.worker_seconds)+' s worker; '+num(p.observer_seconds)+' s observed; high-water RSS '+(p.worker_highwater_rss_bytes==null?'not recorded':num(p.worker_highwater_rss_bytes/1048576)+' MiB')+'.</p>').join('');$('qualification').innerHTML=D.qualification?'<p>'+D.qualification.counts.tiny_cases+' tiny model runs and '+D.qualification.counts.logical_cases+' logical qualifiers. Actual graphs: '+D.qualification.counts.actual_tiny_snapshots+' tiny plus '+D.qualification.counts.actual_logical_snapshots+' logical. Qualification proofs are selectable above; they are not arithmetic target results.</p>':'<p class="muted">No admitted qualification is available.</p>';$('provenance').textContent=JSON.stringify({protocol:D.protocol,phases:D.phases,scope:D.scope,artifact_pins:D.provenance.artifact_pins},null,2);typeset(document.querySelector('main'));}
load().then(x=>{D=x;init();}).catch(e=>{$('fatal').textContent='Actual saved data could not be loaded: '+e.message;});
</script></body></html>'''


def write(name,value):
    path=OUT/name;path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as f:f.write(value)
    return dict(path=path.relative_to(ROOT).as_posix(),**bytepin(path))


def build():
    data=assemble();j=write('quantified-markings-data-v1.json.gz',gzip.compress(wire(data),mtime=0))
    h=write('quantified-markings-v1.html',PAGE.encode('utf-8'))
    receipt=dict(schema='Quantified-markings-passive-build-v1',status='PASS_PASSIVE_SAVED_DATA_AND_REPORT_BUILD',
        outputs=dict(main=h,data=j),renderer_source=dict(path=Path(__file__).relative_to(ROOT).as_posix(),**bytepin(Path(__file__))),
        protocol=data['protocol'],phases=data['phases'],artifact_pins=list(LEDGER.values()),
        scope='Passive saved-data/hash/projection only. No scientific helper imports, native kernel, model construction, transition or rerun.')
    return write('build-receipt-v1.json',wire(receipt))


if __name__=='__main__':print(json.dumps(build(),sort_keys=True))
