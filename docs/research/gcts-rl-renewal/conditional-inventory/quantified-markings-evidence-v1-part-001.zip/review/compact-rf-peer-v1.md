# Compact shared-fact / full RF bridge: independent Source review

Status: **PASS_SOURCE_REVIEW_PENDING_EXECUTED_QUALIFICATION**. All four held
Source bodies, both full API notes and both complete differences were read.
This was direct text/byte inspection only: no scientific import, model
construction, compilation, decoding, checker invocation, search or test.
No other agent's file was edited.

Reviewed pins:

| File | Bytes | SHA256 |
| --- | ---: | --- |
| `source/shared_fact_model_v2.py` | 22603 | `27e500f93e56008c41c4b46491dbc0dd6af7b360500a38bfc0bdb4e9d6fb299d` |
| `source/rf_shared_bridge_v1.py` | 12111 | `a0468f24b0f1af380df444f3039af106c7fc9795991342a6de8c4aa501a78d30` |
| `plan/adapter-API-v1.md` | 13030 | `849734b29f4c07d8c62b3df6e13a32b772c46c094c05dfd3244bb0025ccdfcfc` |
| `review/adapter-diff-v1.patch` | 18934 | `7a738a4c303fbd675cd39e1e78052f9ad8bc61d45fed3d377a1509bfaa1a3ecc` |
| `source/shared_fact_checker_v2.py` | 34595 | `ae85c6bb9a123c6e7924cc7720f6adc8304029ea7a07843cc467100ab288b1c3` |
| `source/rf_shared_bridge_checker_v1.py` | 19638 | `72c2f518b1cedbc2c30f8438cdc347ea0a47a1f343e1b14899c1ba2584af9647` |
| `plan/checkers-API-v1.md` | 12609 | `7ed10a6f46970a96a3f7e0e19f838929c6e98c70104e0576d508e2151d0d9286` |
| `review/checkers-diff-v1.patch` | 30030 | `79e07a7d1d82bffdb056edbfdda45fc23bd699f6fa5e69d0610b70c6498caa83` |

The normative master and the relevant original RF compiler/checker variable,
hole and original-term construction were also consulted as local references.
The master pin remains `c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9`.

No blocking logical or current-profile ABI fault was found at these pins.

## Full basis and literal remapping

The producer bridge copies every supplied RF formula in its original sorted
registry, requires exact equality with the entire color list, and copies every
original primitive ZERO payload under its unchanged RF ID. Its only ID shift
is the uniform zero-based RF to positive shared FID mapping. Lexical ZERO-array
sorting does not rename an ID or turn a derived schema into an axiom.

Every structural implication and universal formula is scanned to regenerate
all original RF MP/GEN indices. The shared MP and GEN IDs/premises are shifted
uniformly and sorted by their declared ABI keys. The complete variable pool,
including the fresh hole, is retained. The independent bridge checker derives
the exact original variable-name pool and hole convention from the original
statement and declared terms, checks every formula/native-payload name against
it, and reconstructs the full catalogue, mapping, bindings and census.

The inspected RF profile permits explicit instantiation terms only from the
original fixed term pool, so omitting a separate scan of that subset does not
omit additional variable names. The fresh hole must not collide with an
original free or bound name. The independent bridge checker enforces that
exact convention.

There is no proof path, selected CID, old proof, lemma bank or target-specific
formula shortlist in the bridge. In particular, the Source preserves the
entire carrier when it contains the proposed larger formula count; this review
has not compiled the declaration or established an actual count such as
\(486\). Goal/term use inherent in the separately declared RF profile is not a
new bridge thinning step.

## Compact names and complete point universe

The compact ports and four-field CIDs are model-local. The whole logical
catalogue and bound remain in the versioned scope preimage, binding and model
version. Independent model reconstruction checks all of those outer fields
before accepting a selected compact CID. A bare compact CID is not globally
scoped; callers must not mix rows or certificates from different prepared
models. This limitation is explicit in both APIs.

For every slot the adapter emits every ZERO and PAD owner, every ordered pair
of earlier MP references and every earlier GEN reference. It omits only literal
self-conflicting MP demands. The distinct antecedent/implication FIDs make the
same-reference conflicts exact, not a heuristic exclusion. The full row census
is checked before allocation and again against generated rows.

The independent checker reconstructs rows separately, including every own and
remote premise mark, exact positive unit, active/formula seed receptor,
definition and padding row. Required centers include all slots, not only ones
touched by a found proof. A complete packet above its declared cap is rejected;
an upstream preparation refusal stays UNKNOWN. No cap silently yields an
admitted partial universe.

## Native projection and logical obligations

Both decoders require a complete selected point certificate from the admitted
whole universe, one owner per slot, all mandatory seed/mark agreements, strict
earlier active references and the unchanged final goal. PAD explicitly assigns
active/formula zero and conflicts with a consumer's active-one demand. Removing
PAD remaps references through ordered active slots; active rows need not be
contiguous. MP antecedent/implication order and GEN source/variable survive.
All native ZERO payloads and statement ASTs remain literal, with no alpha map,
proof compression or replacement by a supplied derivation.

These model/bridge decoders do **not** certify capture-free instantiation,
equality-substitution validity or primitive theorem truth themselves. That is
correctly left to the complete RF-profile and native ZERO gates, then a fresh
whole decoded proof/native-B gate. Closed original assumptions are checked,
which gives the uniform GEN side condition. Native B still remains required.
The independent generic checker must be called through `verify_model` for RF;
its ground-only `verify_basis`/`verify` deliberately refuse the richer profile.

## Independent coverage and resources

Neither independent checker imports the producer bridge, adapter, compiler,
search engine or kernel. The bridge checker reconstructs its representation;
the model checker reconstructs the complete row universe. Their successful
claims expressly leave RF generation-profile completeness, every native ZERO,
search conformance and final native proof validity to separate exact receipts.
The driver must join all those gates on the same declaration/core/profile,
catalogue, scope and model, and bind its later engine-v3 schema migration.

The original adapter difference is limited to compact naming/versioning and
prospective resource ceilings, not a changed proof calculus. Checker input
scans/serialization bounds charge literal strings and keys, use native typed
comparisons, and retain final cooperative checks. Model and bridge bounds are
different explicit resources; full definition and ZERO counts are not confused.
The work counters are not CPU instructions or matched search costs. Owned
process limits are still needed, and valid resource refusals remain UNKNOWN.

Executed qualification remains outstanding. This Source review establishes no
actual model count, found proof, learned-mark preservation, theorem, geometry
transfer, universal Wang construction or comparative search advantage.
