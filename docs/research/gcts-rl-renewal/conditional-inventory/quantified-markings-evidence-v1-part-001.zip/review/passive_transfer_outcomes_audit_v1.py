"""Transfer saved-data byte/custody joins only; no scientific helpers or replay."""
from pathlib import Path
from collections import Counter
import gzip
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
PINS = {}
CHECKS = 0


def need(ok, why):
    global CHECKS
    CHECKS += 1
    if not ok:
        raise ValueError(why)


def wire(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')


def sha(value):
    return hashlib.sha256(wire(value)).hexdigest()


def filepin(path):
    data = path.read_bytes()
    return dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def local(name):
    path = ROOT / name
    need(not path.is_symlink() and path.resolve().is_relative_to(ROOT), 'LOCAL_PATH:' + name)
    return path


def read(name):
    path = local(name)
    raw = path.read_bytes()
    PINS[name] = dict(path=name, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
    payload = gzip.decompress(raw) if path.suffix == '.gz' else raw
    value = json.loads(payload)
    need(type(value) in (dict, list), 'COMPLETE_JSON_OBJECT_OR_ARRAY:' + name)
    return value


def checkref(ref):
    name = ref['path']
    actual = filepin(local(name))
    need(type(ref['bytes']) is int and actual == {k: ref[k] for k in actual}, 'PHYSICAL_REF:' + name)
    PINS[name] = dict(path=name, **actual)
    if 'complete_json' in ref:
        need(ref['complete_json'] is True, 'CAPTURE_COMPLETE:' + name)
        raw = local(name).read_bytes()
        data = gzip.decompress(raw) if name.endswith('.gz') else raw
        value = json.loads(data)
        need(wire(value) == data and len(data) == ref['logical_json_bytes'], 'LOGICAL_REF:' + name)


def refs(value):
    if type(value) is dict:
        if {'path', 'bytes', 'sha256'} <= set(value) and not value['path'].startswith('/'):
            checkref(value)
        for child in value.values():
            refs(child)
    elif type(value) is list:
        for child in value:
            refs(child)


def normal(model):
    value = json.loads(wire(model))
    value['roots'].sort()
    for key in ('t', 'm'):
        value['seed'][key].sort()
    for row in value['inventory']['placements']:
        row['t'].sort()
        row['m'].sort()
    value['inventory']['placements'].sort(key=lambda r: r['id'])
    value['pair_nogoods'].sort()
    value['unary_nogoods'].sort()
    return value


def phase(name, accepted, protocol):
    result = read('data/' + name + '/result.json')
    s, i, o = [read('run/' + name + '/' + key + '.json')
               for key in ('started', 'invocation', 'observer')]
    need(s['phase'] == i['phase'] == o['phase'] == name, 'PHASE:' + name)
    need(all(type(x['pid']) is int and x['pid'] > 0 for x in (s, i, o))
         and s['pid'] == i['pid'] == o['pid'], 'NATIVE_PID:' + name)
    need(i['status'] == 'COMPLETE' and i['error_type'] is None and o['status'] == 'TERMINAL'
         and type(o['native_exit_code']) is int and o['native_exit_code'] == 0, 'NATIVE_CLEAN:' + name)
    need(all(o[k] is None for k in ('guard_reason', 'observer_error', 'reap_error', 'postcheck_error'))
         and i['postcheck_error'] is None, 'GUARDS:' + name)
    need(i['frozen_postcheck'] == o['frozen_postcheck'] == protocol['status'], 'SOURCE_POSTCHECK:' + name)
    checkref(s['protocol'])
    need(s['protocol']['path'] == 'protocol/frozen-protocol-v1.json', 'PROTOCOL_PATH:' + name)
    checkref(i['result'])
    need(i['result']['path'] == 'data/' + name + '/result.json'
         and result['status'] == i['scientific_status'] == accepted, 'SCIENTIFIC_RESULT:' + name)
    checkref(o['log'])
    need(o['log']['path'] == 'run/' + name + '/stdout.log', 'LOG_PATH:' + name)
    refs(result)
    return result, dict(phase=name, pid=o['pid'], native_exit_code=0,
        execution_admitted=True, scientific_status=result['status'], seconds=o['seconds'],
        sampled_peak_rss_bytes=o['peak_observed_rss_bytes'],
        native_highwater=i['maxrss'], native_highwater_units=i['maxrss_units'])


def logical_file_hash(name):
    h = hashlib.sha256(); size = 0
    path = local(name)
    with (gzip.open(path, 'rb') if path.suffix == '.gz' else path.open('rb')) as stream:
        for part in iter(lambda: stream.read(1048576), b''):
            h.update(part); size += len(part)
    return dict(sha256=h.hexdigest(), bytes=size)


def main():
    protocol = read('protocol/frozen-protocol-v1.json')
    for item in protocol['files']:
        checkref(item)
    for ref in (protocol['master'], protocol['runtime']['executable']):
        need(filepin(Path(ref['path'])) == {k: ref[k] for k in ('bytes','sha256')}, 'CURRENT_MASTER_RUNTIME')
    partial = read('review/passive-qualification-prepare-v1.json')
    need(partial['status'] == 'PASS_SAVED_QUALIFICATION_AND_PREPARATION_ONLY', 'PRIOR_PARTIAL_AUDIT')
    acquire, ac = phase('acquire', 'ACQUIRED_PROPOSAL', protocol)
    label, lc = phase('label', 'LABELLED', protocol)
    learn, uc = phase('learn', 'UNKNOWN', protocol)
    need(learn['status'] != protocol['admitted_statuses']['learn'], 'LEARN_NOT_SCIENTIFICALLY_ADMITTED')
    base = read('data/prepare/model.json.gz')
    scope = sha(base)
    need(scope == acquire['scope_sha256'] == label['scope_sha256'], 'ONE_ORIGINAL_BASE_SCOPE')
    ar = read(acquire['refs']['engine']['raw']['path'])
    c = read(acquire['refs']['engine']['semantic']['path'])
    need(ar['status'] == c['status'] == 'UNKNOWN' and c['bounded_absence'] is False
         and ar['selected'] == [] and ar['certificate'] is None, 'ACQUISITION_IS_ONLY_PREFIX')
    placed = next(e for e in ar['events'] if e['kind'] == 'PLACED')
    proposal = read(acquire['refs']['proposal']['path'])
    cid = acquire['cid']
    need(cid == placed['candidate'] == proposal['cid'] and placed == proposal['event']
         and proposal['raw_sha256'] == sha(ar) and proposal['scope_sha256'] == scope
         and proposal['label'] == 'NOT_A_FAILURE_LABEL', 'ACTUAL_FIRST_PLACED_PROPOSAL')
    acquisition_summary = dict(raw_status=ar['status'], raw_reason=ar['reason'],
        semantic_status=c['status'], events=len(ar['events']), candidate=cid,
        negative_label_from_prefix=False)
    del ar
    packet = read(label['query_packets_ref']['path'])
    fixed, raw, c, binding = [packet[k] for k in ('fixed_model','raw_result','semantic_receipt','binding')]
    need(packet['cid'] == cid and packet['label'] == 'NEGATIVE'
         and packet['scope_sha256'] == scope, 'FRESH_TYPED_NEGATIVE_PACKET')
    need(sha(fixed) == binding['fixed_model_sha256'] == raw['model_sha256'] == c['model_sha256']
         and binding['base_model_sha256'] == binding['scope_sha256'] == scope, 'FIXED_CONTEXT_BINDINGS')
    need(sha(raw) == binding['raw_result_sha256']
         == logical_file_hash(label['refs']['engine']['raw']['path'])['sha256']
         and sha(c) == binding['semantic_receipt_sha256']
         == logical_file_hash(label['refs']['engine']['semantic']['path'])['sha256'], 'FULL_PACKET_RAW_C_CONTENT_HASHES')
    need(sha(fixed) == logical_file_hash(label['refs']['engine']['model']['path'])['sha256'], 'FULL_FIXED_MODEL_OBJECT_ASSOCIATION')
    need(raw['status'] == 'UNSAT' and raw['reason'] == 'EXHAUSTED_DECLARED_FINITE_INVENTORY'
         and raw['selected'] == [] and raw['certificate'] is None
         and c['status'] == 'VERIFIED' and c['run_status'] == 'UNSAT'
         and c['claim'] == 'SEMANTIC_COMPLETE_FINITE_EXHAUSTION'
         and c['bounded_absence'] is True and c['event_coverage'] == 'COMPLETE', 'COMPLETE_SCOPED_ABSENCE_ONLY')
    h = hashlib.sha256()
    for j, e in enumerate(raw['events']):
        need(type(e['seq']) is int and e['seq'] == j, 'LABEL_EVENT_SEQUENCE'); h.update(wire(e))
    need(len(raw['events']) == raw['event_extent']['total'] == raw['event_extent']['retained']
         == c['counts']['decision_events_checked'] and h.hexdigest()
         == raw['event_extent']['sha256'] == c['event_sha256'], 'COMPLETE_SAVED_LABEL_EVENT_STREAM')
    need(raw['events'][-1]['kind'] == 'EXHAUSTED' and raw['entry_state'] == raw['restored_state'], 'LABEL_TERMINAL_RESTORATION')
    owner = next(r for r in base['inventory']['placements'] if r['id'] == cid)
    totals = dict(base['seed']['t']); marks = dict(base['seed']['m'])
    for p, v in owner['t']:
        totals[p] = totals.get(p,0) + v
    for p, v in owner['m']:
        need(p not in marks or marks[p] == v, 'FIXED_LITERAL_COMPATIBILITY'); marks[p] = v
    expected = dict(base, version=fixed['version'], roots=sorted(set(base['roots']) | {p for p,v in owner['t']}),
        seed=dict(t=sorted([[p,v] for p,v in totals.items()]),m=sorted([[p,v] for p,v in marks.items()])),
        inventory=dict(kind='EXPLICIT',placements=[r for r in base['inventory']['placements'] if r['id'] != cid]))
    need(fixed == expected and len(fixed['inventory']['placements']) == len(base['inventory']['placements'])-1,
         'EXACT_WHOLE_FIXED_CID_RESIDUAL_NO_THINNING')
    need(binding == label['query_bindings'][0] and label['labels'] == read(label['refs']['learner_labels']['path'])
         and label['labels'][0] == dict(cid=cid,status='NEGATIVE',scope_sha256=scope,
             certificate_binding_sha256=sha(binding)), 'EXACT_LEARNER_LABEL_ASSOCIATION')
    label_summary = dict(candidate=cid, raw_status='UNSAT', semantic_status='VERIFIED', bounded_absence=True,
        fixed_model_sha256=sha(fixed), raw_sha256=sha(raw), certificate_binding_sha256=sha(binding),
        events=len(raw['events']), fixed_inventory=len(fixed['inventory']['placements']),
        counts=c['counts'], scope='This exact fixed-CID extension in the frozen finite shared-slot inventory only.')
    del packet, fixed, raw, expected
    synth = read(learn['refs']['synthesis']['path'])
    overlay = read(learn['refs']['overlay']['path'])
    refused = read(learn['refs']['overlay_receipt']['path'])
    provenance = read(learn['refs']['provenance']['path'])
    need(synth['status'] == 'SOLVED' and overlay['status'] == 'CONSTRUCTED_UNVERIFIED_OVERLAY'
         and synth['labels'] == label['labels'] and synth['scope_sha256'] == scope
         and synth['forbidden_cids'] == [cid], 'ACTUAL_SPARSE_SYNTHESIS_CANDIDATE')
    need(provenance['label_phase']['result'] == label and provenance['label_phase']['observer']['pid'] == lc['pid']
         and provenance['label_phase']['observer']['native_exit_code'] == 0, 'PRIOR_NATIVE_LABEL_PROVENANCE')
    need(refused['status'] == learn['status'] == 'UNKNOWN' and refused['activation_admitted'] is False
         and refused['reason'] == learn['reason'] == 'CHECKER_MAX_WORK'
         and refused['work'] > protocol['limits']['scientific']['overlay']['max_work']
         and learn['stopped_stage'] == 'scoped_overlay_independent_admission', 'ACTUAL_FROZEN_RESOURCE_REFUSAL_NO_ACTIVATION')
    marked, control = overlay['marked_model'], overlay['control_model']
    need(len(marked['inventory']['placements']) == len(control['inventory']['placements'])
         == len(base['inventory']['placements']) == 49736, 'CONSTRUCTED_FULL_PALETTE')
    guard = synth['guard_point']
    points = set(base['roots'])
    for channel in ('t','m'):
        points.update(p for p,v in base['seed'][channel])
    for old, m, f in zip(base['inventory']['placements'], marked['inventory']['placements'], control['inventory']['placements']):
        points.update(p for p,v in old['t']+old['m'])
        need(old == f and old['id'] == m['id'] and old['t'] == m['t']
             and m['m'] == sorted(old['m'] + ([[guard,'1']] if old['id'] == cid else [])), 'CONSTRUCTED_OLD_T_M_PRESERVED')
    need(guard not in points and marked['seed']['t'] == base['seed']['t']
         and marked['seed']['m'] == sorted(base['seed']['m']+[[guard,'0']])
         and marked['pair_nogoods'] == marked['unary_nogoods'] == []
         and control['seed'] == base['seed'] and control['pair_nogoods'] == []
         and control['unary_nogoods'] == [cid], 'CONSTRUCTED_MARK_ONLY_SEED_AND_MATCHED_FILTER')
    need(not (ROOT/'data/learn/marked-model.json.gz').exists()
         and not (ROOT/'data/learn/control-model.json.gz').exists(), 'NO_SCIENTIFIC_ACTIVATION_OUTPUTS')
    preflight = read('review/evaluation-preflight-refusal-v1.json')
    need(preflight['status'] == 'BLOCKED_BEFORE_WORKER' and preflight['native_outer_exit_code'] == 1
         and preflight['worker_started'] is False and preflight['engine_calls'] == 0
         and preflight['learn_result_sha256'] == sha(learn)
         and not (ROOT/'run/evaluate').exists() and not (ROOT/'data/evaluate').exists(), 'ACTUAL_EVALUATION_PREFLIGHT_REFUSAL_NO_RUN')
    physical = []
    for folder in ('data/acquire','data/label','data/learn','data/engine/acquire-original-node1',
                   'data/engine/label-fixed-cid','run/acquire','run/label','run/learn'):
        for path in sorted((ROOT/folder).rglob('*')):
            if path.is_file():
                name=path.relative_to(ROOT).as_posix()
                physical.append(dict(path=name,**filepin(path)))
    output = dict(schema='QMT-passive-transfer-outcomes-audit-v1',
        status='PASS_SAVED_OUTCOMES_WITH_UNACTIVATED_RESOURCE_REFUSAL',check_count=CHECKS,
        protocol=PINS['protocol/frozen-protocol-v1.json'],current_frozen_files=len(protocol['files']),
        qualification_preparation_audit=PINS['review/passive-qualification-prepare-v1.json'],
        phase_custody=[ac,lc,dict(uc,scientific_admitted=False)],acquisition=acquisition_summary,
        certified_finite_failure=label_summary,
        synthesis=dict(status=synth['status'],forbidden_cids=synth['forbidden_cids'],counters=synth['counters']),
        constructed_overlay=dict(status=overlay['status'],old_t_m_and_full_palette_retained=True,
            full_inventory=49736,guard_point=guard,activation_admitted=False),
        overlay_admission_refusal=refused,evaluation=dict(status='NOT_RUN',preflight=preflight,
            lanes_executed=0,engine_calls=0),arithmetic_target_proofs_observed=0,
        scope='Passive saved-byte/process/census/content joins only. No search/compiler/native/oracle/checker/learner helper was imported or replayed. The scoped negative CID is certified separately; synthesis/application were not activated because independent overlay admission hit its unchanged frozen budget. No matched three-lane evaluation, full arithmetic proof, RL, speed or universality conclusion.',
        physical_files=physical,referenced_file_pins=[PINS[k] for k in sorted(PINS)])
    target=ROOT/'review/passive-transfer-outcomes-v1.json'
    with target.open('xb') as stream:
        stream.write(wire(output))
    print(json.dumps(dict(status=output['status'],checks=CHECKS,physical_files=len(physical),
        receipt=dict(path=str(target),**filepin(target)))))


if __name__ == '__main__':
    main()


