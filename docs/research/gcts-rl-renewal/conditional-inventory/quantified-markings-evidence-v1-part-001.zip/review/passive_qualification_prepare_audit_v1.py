"""Saved-data byte/census joins only; no scientific imports or helper calls."""
from pathlib import Path
from collections import Counter
import gzip
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
PINS = {}
CHECKS = 0


def need(ok, why):
    global CHECKS
    CHECKS += 1
    if not ok:
        raise ValueError(why)


def wire(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')


def sha(value):
    return hashlib.sha256(wire(value)).hexdigest()


def filepin(path):
    data = path.read_bytes()
    return dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def local(name):
    path = ROOT / name
    need(not path.is_symlink() and path.resolve().is_relative_to(ROOT), 'LOCAL_PATH:' + name)
    return path


def read(name):
    path = local(name)
    raw = path.read_bytes()
    PINS[name] = dict(path=name, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
    payload = gzip.decompress(raw) if path.suffix == '.gz' else raw
    value = json.loads(payload)
    need(type(value) in (dict, list), 'COMPLETE_JSON_OBJECT_OR_ARRAY:' + name)
    return value


def checkref(ref):
    name = ref['path']
    actual = filepin(local(name))
    need(type(ref['bytes']) is int and actual == {k: ref[k] for k in actual}, 'PHYSICAL_REF:' + name)
    PINS[name] = dict(path=name, **actual)
    if 'complete_json' in ref:
        need(ref['complete_json'] is True, 'CAPTURE_COMPLETE:' + name)
        raw = local(name).read_bytes()
        data = gzip.decompress(raw) if name.endswith('.gz') else raw
        value = json.loads(data)
        need(wire(value) == data and len(data) == ref['logical_json_bytes'], 'LOGICAL_REF:' + name)


def refs(value):
    if type(value) is dict:
        if {'path', 'bytes', 'sha256'} <= set(value) and not value['path'].startswith('/'):
            checkref(value)
        for child in value.values():
            refs(child)
    elif type(value) is list:
        for child in value:
            refs(child)


def normal(model):
    value = json.loads(wire(model))
    value['roots'].sort()
    for key in ('t', 'm'):
        value['seed'][key].sort()
    for row in value['inventory']['placements']:
        row['t'].sort()
        row['m'].sort()
    value['inventory']['placements'].sort(key=lambda r: r['id'])
    value['pair_nogoods'].sort()
    value['unary_nogoods'].sort()
    return value


def phase(name, accepted, protocol):
    result = read('data/' + name + '/result.json')
    s, i, o = [read('run/' + name + '/' + key + '.json')
               for key in ('started', 'invocation', 'observer')]
    need(s['phase'] == i['phase'] == o['phase'] == name, 'PHASE:' + name)
    need(all(type(x['pid']) is int and x['pid'] > 0 for x in (s, i, o))
         and s['pid'] == i['pid'] == o['pid'], 'NATIVE_PID:' + name)
    need(i['status'] == 'COMPLETE' and i['error_type'] is None and o['status'] == 'TERMINAL'
         and type(o['native_exit_code']) is int and o['native_exit_code'] == 0, 'NATIVE_CLEAN:' + name)
    need(all(o[k] is None for k in ('guard_reason', 'observer_error', 'reap_error', 'postcheck_error'))
         and i['postcheck_error'] is None, 'GUARDS:' + name)
    need(i['frozen_postcheck'] == o['frozen_postcheck'] == protocol['status'], 'SOURCE_POSTCHECK:' + name)
    checkref(s['protocol'])
    need(s['protocol']['path'] == 'protocol/frozen-protocol-v1.json', 'PROTOCOL_PATH:' + name)
    checkref(i['result'])
    need(i['result']['path'] == 'data/' + name + '/result.json'
         and result['status'] == i['scientific_status'] == accepted, 'SCIENTIFIC_RESULT:' + name)
    checkref(o['log'])
    need(o['log']['path'] == 'run/' + name + '/stdout.log', 'LOG_PATH:' + name)
    refs(result)
    return result, dict(phase=name, pid=o['pid'], native_exit_code=0,
        execution_admitted=True, scientific_status=result['status'], seconds=o['seconds'],
        sampled_peak_rss_bytes=o['peak_observed_rss_bytes'],
        native_highwater=i['maxrss'], native_highwater_units=i['maxrss_units'])


def graph_run(model, row):
    r = row['refs']
    raw, observations, c, t, g = [read(r[key]['path']) for key in
        ('raw', 'observations', 'semantic', 'full_graphs', 'paired_graphs')]
    bound = sha(normal(model))
    need(raw['model_sha256'] == c['model_sha256'] == t['model_sha256'] == bound, 'MODEL_CONTEXT')
    need(c['status'] == t['status'] == g['status'] == 'VERIFIED', 'EXISTING_GRAPH_RECEIPTS')
    n = len(raw['events'])
    need(n == raw['event_extent']['total'] == raw['event_extent']['retained'] == len(observations)
         == c['counts']['decision_events_checked'] == t['counts']['observations_checked']
         == g['events_checked'] == len(g['comparisons']), 'ACTUAL_GRAPH_CENSUS')
    h = hashlib.sha256()
    for j, (event, observed, compared) in enumerate(zip(raw['events'], observations, g['comparisons'])):
        need(type(event['seq']) is int and event['seq'] == j and event == observed['event'], 'EVENT_JOIN')
        h.update(wire(event))
        need(compared['equal'] is True and compared['actual_sha256'] == compared['reconstructed_sha256']
             == sha(observed['state']), 'SAVED_PAIRED_GRAPH_HASH')
    need(h.hexdigest() == raw['event_extent']['sha256'] == c['event_sha256'], 'EVENT_STREAM_HASH')
    for endpoint in ('entry', 'final', 'restored'):
        need(sha(raw[endpoint + '_state']) == raw['state_hashes'][endpoint], 'ENDPOINT_HASH')
    need(raw['entry_state'] == raw['restored_state'], 'EXACT_RESTORED_ENDPOINT')
    need(c['run_status'] == t['run_status'] == raw['status'] == row['raw_status'], 'RUN_STATUS')
    return raw, n


def main():
    protocol = read('protocol/frozen-protocol-v1.json')
    need(protocol['status'] == 'FROZEN_BEFORE_SCIENTIFIC_IMPORTS', 'FROZEN_PROTOCOL')
    frozen = {x['path']: x for x in protocol['files']}
    for item in protocol['files']:
        checkref(item)
    admission = read('review/root-source-admission-v1.json')
    need(admission['status'] == 'PASS_SOURCE_REVIEW_BEFORE_FREEZE', 'ROOT_SOURCE_ADMISSION')
    current = {p.relative_to(ROOT).as_posix() for folder in ('source', 'reference', 'input', 'plan')
               for p in (ROOT / folder).rglob('*') if p.is_file()}
    current.add('review/root-source-admission-v1.json')
    current.update(x['path'] for x in admission['reviewed'])
    need(current == set(frozen), 'EXACT_FROZEN_FILE_SET')
    for key in ('master',):
        r = protocol[key]
        need(filepin(Path(r['path'])) == {k: r[k] for k in ('bytes', 'sha256')}, 'CURRENT_MASTER')
    runtime = protocol['runtime']
    need(filepin(Path(runtime['executable']['path'])) == {k: runtime['executable'][k]
         for k in ('bytes', 'sha256')}, 'CURRENT_RUNTIME_BINARY')
    need(runtime['isolated'] == runtime['no_site'] == 1 and runtime['dont_write_bytecode'] is True,
         'DECLARED_RUNTIME_FLAGS')
    qualify, qc = phase('qualify', 'QUALIFIED', protocol)
    prepared_result, pc = phase('prepare', 'PREPARED', protocol)
    cases = read('input/qualification-cases-v1.json')['cases']
    need(len(cases) == len(qualify['cases']) == 20 and len(qualify['logical']) == 2, 'CASE_CENSUS')
    observations = subsets = 0
    outcomes = Counter()
    for declaration, row in zip(cases, qualify['cases']):
        need(declaration['id'] == row['id'] and row['status'] == 'QUALIFIED', 'CASE_ID_STATUS')
        raw, n = graph_run(declaration['model'], row)
        o = read(row['oracle']['path'])
        need(o['status'] == 'EXHAUSTED' and o['subsets_coverage'] == 'COMPLETE'
             and len(o['subsets']) == o['subsets_total'] == o['counts']['subsets_checked']
             == 1 << len(declaration['model']['inventory']['placements']), 'FULL_TINY_ORACLE')
        need(raw['status'] == declaration['expected']['raw_status'] and o['exists']
             is declaration['expected']['exists'] and o['exists'] is (raw['status'] == 'SAT'), 'EXPECTED_EXISTENCE')
        if raw['status'] == 'SAT':
            need(any(sorted(x['selected']) == raw['selected'] for x in o['solutions']), 'SAVED_SOLUTION_MEMBERSHIP')
        need([x['request'] for x in row['required_observations']]
             == declaration['expected'].get('required_observations', []), 'OBSERVATION_REQUEST_CENSUS')
        need(all(0 <= x['seq'] < n for x in row['required_observations']), 'OBSERVED_REQUEST_SEQUENCE')
        observations += n
        subsets += o['subsets_total']
        outcomes[raw['status']] += 1
    logic_rows = []
    logic_observations = logic_subsets = 0
    for row in qualify['logical']:
        r = row['refs']
        p = read(r['prepared']['path'])
        model = read(row['engine']['refs']['model']['path'])
        raw, n = graph_run(model, row['engine'])
        need(raw['status'] == 'SAT', 'LOGICAL_POSITIVE')
        m, d, b = [read(r[k]['path']) for k in ('decoded', 'independent_decoded', 'native')]
        for key in ('statement', 'proof', 'slots', 'slot_to_native', 'native_to_slot',
                    'reference_mapping', 'proof_dag', 'selected', 'selected_sha256', 'original_statement_sha256', 'scope'):
            need(m[key] == d[key], 'TWO_SAVED_DECODER_JOIN:' + key)
        need(m['selected'] == raw['selected'] and m['statement'] == p['statement']
             and b['status'] == 'VERIFIED' and b['checked_lines'] == len(m['proof']), 'LOGICAL_NATIVE_JOIN')
        need(read(r['model_check']['path'])['status'] == 'VERIFIED', 'LOGICAL_MODEL_GATE')
        for z in row['native_zeros']:
            check = read(z['receipt']['path'])
            need(check['status'] == 'VERIFIED' and check['checked_lines'] == 1, 'LOGICAL_ZERO_NATIVE')
        o = read(r['oracle']['path'])
        need(o['status'] == 'EXHAUSTED' and o['exists'] is True and len(o['subsets'])
             == o['subsets_total'] == o['counts']['subsets_checked'], 'LOGICAL_ORACLE_COMPLETE')
        need(any(sorted(x['selected']) == raw['selected'] for x in o['solutions']), 'LOGICAL_ORACLE_SELECTED')
        logic_observations += n
        logic_subsets += o['subsets_total']
        logic_rows.append(dict(id=row['id'], native_lines=len(m['proof']), rules=row['rules'],
            oracle_subsets=o['subsets_total'], actual_graphs=n, selected_pad_slots=row['selected_pad_slots']))
    controls = Counter()
    for row in qualify['controls']:
        if row['id'] == 'max-nodes-zero':
            raw = read(row['refs']['raw']['path']); c = read(row['refs']['semantic']['path'])
            need(raw['status'] == c['status'] == 'UNKNOWN' and c['bounded_absence'] is False
                 and raw['selected'] == [] and raw['certificate'] is None, 'RESOURCE_REFUSAL')
            controls['UNKNOWN'] += 1
        else:
            c = read(row['receipt']['path'])
            need(c['status'] == 'REJECTED', 'MALFORMED_OR_FORGED_REFUSAL')
            controls['REJECTED'] += 1
    need(len(qualify['controls']) == 9 and controls == dict(REJECTED=8, UNKNOWN=1), 'CONTROL_CENSUS')
    r = prepared_result['refs']
    decl, comp, gen, bridge, q, p, n, model, migration, zero = [read(r[k]['path']) for k in
        ('declaration', 'compiled', 'generation', 'bridge', 'bridge_receipt', 'prepared',
         'model_receipt', 'model', 'migration', 'zero_native_receipts')]
    rf = read(r['rf_receipt']['path'])
    need(decl == read('input/arithmetic-declaration-v1.json')
         and not {'proof', 'proofs', 'target_proof', 'witness', 'selected', 'bank', 'control_proof'} & set(decl), 'ORIGINAL_DECLARATION_NO_PROOF_INPUT')
    need(rf['status'] == q['status'] == n['status'] == 'VERIFIED' and bridge['status']
         == 'CATALOGUE_UNVERIFIED' and p['status'] == 'PREPARED_UNVERIFIED', 'ALL_PREPARATION_GATES')
    need(rf['declaration_sha256'] == sha(decl) and rf['compiled_core_sha256']
         == gen['compiled_core_sha256'] == sha({k:v for k,v in comp.items() if k not in ('costs','scope')}), 'RF_CORE_HASH_JOIN')
    need(len(zero) == len(comp['zero_instances']) == prepared_result['ZERO_checks'] == 245, 'ALL_245_ZERO_RECORDS')
    for native, evidence in zip(comp['zero_instances'], zero):
        need(native['id'] == evidence['id'] and native['formula_id'] == evidence['formula_id']
             and evidence['native_line_sha256'] == sha(native['line'])
             and evidence['receipt']['status'] == 'VERIFIED'
             and evidence['receipt']['checked_lines'] == 1, 'EXACT_ZERO_NATIVE_CONTENT_JOIN')
    cat = bridge['catalogue']
    need(cat['statement'] == decl['problem'] == p['statement'] and cat == p['catalogue'], 'ORIGINAL_FULL_STATEMENT_CATALOGUE')
    need(cat['formulas'] == comp['logical_basis']['formulas'] and cat['profile']['variables']
         == comp['logical_basis']['variables'] and comp['logical_basis']['hole'] in cat['profile']['variables'], 'ALL_FORMULAS_VARIABLES_HOLE')
    need(bridge['mapping']['formula_ids'] == [[i,i+1] for i in range(len(cat['formulas']))], 'ALL_FID_MAPPING')
    zeros = {z['id']:z['native'] for z in cat['zeros']}
    need(zeros == {z['id']:z['line'] for z in comp['zero_instances']}, 'ALL_ORIGINAL_ZERO_PAYLOADS')
    need(q['bindings'] == bridge['bindings'] and n['catalogue_sha256'] == sha(cat)
         == bridge['bindings']['catalogue_sha256'] and n['original_statement_sha256'] == sha(decl['problem']), 'FULL_BRIDGE_MODEL_BINDINGS')
    need(n['census'] == p['census'] == prepared_result['census'] and len(p['universe'])
         == len(model['inventory']['placements']) == 49736, 'COMPLETE_ROW_CENSUS')
    need(n['model_sha256'] == migration['prepared_model_sha256'] == sha(p['model'])
         and n['universe_sha256'] == sha(p['universe']) and model['inventory']['placements'] == p['universe'], 'FULL_MODEL_UNIVERSE_HASHES')
    need(p['binding'] == prepared_result['prepared_binding'] and sha(p['binding']['scope_preimage'])
         == p['binding']['scope'], 'ENTIRE_PREPARED_SCOPE')
    for key in ('capacity','roots','seed','inventory'):
        need(model[key] == p['model'][key], 'MIGRATION_ONLY:' + key)
    need(model['schema'] == 'Z-growing-point-model-v3' and model['pair_nogoods'] == model['unary_nogoods'] == []
         and model['version'] == p['model']['version'] + ':engine-v4'
         and sha(model) == migration['migrated_model_sha256'] == prepared_result['scope_sha256'], 'EXACT_ENGINE_SCHEMA_MIGRATION')
    physical = []
    for folder in ('data/qualify','data/engine/qualify','data/prepare','run/qualify','run/prepare'):
        for f in sorted((ROOT/folder).rglob('*')):
            if f.is_file():
                name = f.relative_to(ROOT).as_posix()
                if f.suffix in ('.json','.gz'):
                    read(name)
                physical.append(dict(path=name, **filepin(f)))
    output = dict(schema='QMT-passive-qualification-prepare-audit-v1', status='PASS_SAVED_QUALIFICATION_AND_PREPARATION_ONLY',
        check_count=CHECKS, protocol=PINS['protocol/frozen-protocol-v1.json'], frozen_files=len(frozen),
        current_runtime_binary=protocol['runtime']['executable'], current_master=protocol['master'],
        phase_custody=[qc,pc], qualification=dict(cases=20, tiny_outcomes=dict(outcomes),
            actual_tiny_snapshots=observations, actual_logical_snapshots=logic_observations,
            full_actual_snapshots=observations+logic_observations, tiny_oracle_subsets=subsets,
            logical_oracle_subsets=logic_subsets, controls=dict(controls), logical=logic_rows),
        preparation=dict(census=p['census'], all_native_ZERO=245,
            original_statement_sha256=sha(decl['problem']), compiled_core_sha256=gen['compiled_core_sha256'],
            catalogue_sha256=sha(cat), complete_universe_sha256=n['universe_sha256'],
            prepared_model_sha256=n['model_sha256'], engine_model_sha256=sha(model),
            all_original_formulas_variables_and_native_payloads_retained=True,
            graph_profile='Generic complete shared-slot universe; not ground-Horn-only admission.'),
        scope='Passive saved-byte/status/census/content association audit only; no compiler, model, engine, oracle, checker, classifier or native-kernel helper imported or replayed. No study-target proof or learned-layer outcome is admitted here.',
        not_read_or_admitted=['acquire','label','learn','evaluate'], physical_files=physical,
        referenced_file_pins=[PINS[k] for k in sorted(PINS)])
    target=ROOT/'review/passive-qualification-prepare-v1.json'
    with target.open('xb') as stream:
        stream.write(wire(output))
    print(json.dumps(dict(status=output['status'],checks=CHECKS,physical_files=len(physical),
        frozen_files=len(frozen),full_actual_snapshots=observations+logic_observations,
        receipt=dict(path=str(target),**filepin(target)))))


if __name__ == '__main__':
    main()
