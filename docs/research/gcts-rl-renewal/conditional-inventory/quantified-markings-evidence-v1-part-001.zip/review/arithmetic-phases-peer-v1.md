# Independent arithmetic-phase Source review

Status: **PASS_SOURCE_REVIEW_BEFORE_EXECUTION**. No blocking API or logical
orchestration defect was found. The complete current arithmetic phase Source
was read, with direct checks of the called RF, bridge, model, decoder, native
and overlay interfaces and the owning driver's `Context`/persistence/custody
interfaces. The separate integration peer owns the full driver review.
Only file reads, hashing and AST parsing occurred. No scientific module was
imported, compiled, constructed or called; no experiment or test was run.

The normative master remains the exact `c1327e5e…` reference already read and
bound in the preceding engine/overlay review. All past roots remain immutable.

## Held Source and data pins

| Path | Bytes | SHA256 |
|---|---:|---|
| `source/arithmetic_phases_v1.py` | 28287 | `5c55c3bb3dcd9b2c78c34bb8d9b1ee11c6ea7b4335ab0259a95b1ba614f8d55c` |
| `source/run_quantified_transfer_v1.py` (Context and custody interface) | 21723 | `dfbbcad4336c743e6dc5fbf9f08ce8efb4f47b55d9fdcb728586b1f3afc94bd4` |
| `input/arithmetic-declaration-v1.json` | 976 | `6dfe228aa4130914f01d4a96f4f344f23c84ad8ee91af78d55cca5ad5b72a626` |
| `source/shared_fact_model_v2.py` | 22603 | `27e500f93e56008c41c4b46491dbc0dd6af7b360500a38bfc0bdb4e9d6fb299d` |
| `source/shared_fact_checker_v2.py` | 34595 | `ae85c6bb9a123c6e7924cc7720f6adc8304029ea7a07843cc467100ab288b1c3` |
| `source/rf_shared_bridge_v1.py` | 12111 | `a0468f24b0f1af380df444f3039af106c7fc9795991342a6de8c4aa501a78d30` |
| `source/rf_shared_bridge_checker_v1.py` | 19638 | `72c2f518b1cedbc2c30f8438cdc347ea0a47a1f343e1b14899c1ba2584af9647` |
| `source/unary_overlay_v1.py` | 11265 | `0308a8af75cb4d1f4031f38f882e17650c4e5ab05c67bbe3b45e0c5434ff1870` |
| `source/unary_overlay_checker_v1.py` | 20252 | `e66c1cae5bc7930d5b2477104807699e755c7d14c87d5e4fcca185b4c73658c3` |
| `source/growing_point_search_v4.py` | 43151 | `9953582e09e4a800591953b341812082a5eb9d13afa6aa36a1104eb1f1b5ea22` |
| `source/semantic_event_checker_v3.py` | 42452 | `aa265dc6c611415390bf20d442a24924164c75ff7ea623b961976aa0a0b0348d` |
| `reference/finite_basis_v1.py` | 14044 | `97225dcffd98dd5386aeb560a2fc5634dfcc4606ff475a46536207768932a0dc` |
| `reference/rf_catalogue_checker_v1.py` | 20792 | `146df0b295c28c5ffe743f687e83fd5454ae5ab7915b5900f80b22d86a42d9ab` |
| `reference/independent_fol_checker_v1.py` | 21560 | `099454304f3a67c8ec49b1a3685c0dc0896662ae0bc26a18db9320d6cb3404b1` |

## Preparation and proof-carrier joins

Preparation reads the fresh namespaced original declaration with eight shared
proof slots. It does not read an archived proof, control proof, selected set,
lemma bank or previous prepared basis. The RF compiler's entire carrier and
generation object are saved before independent profile admission. The used
RF receipt fields actually exist: `declaration_sha256` uses the same canonical
ASCII JSON plus LF convention as `ctx.sha`, and `compiled_core_sha256` binds
the complete core excluding only the compiler's declared cost/scope fields.

Every original ZERO is passed, with its full native payload and original
theory, to native B as a one-line certificate of its own output formula. The
code requires VERIFIED and exactly one checked line. Positive ZERO receipts
are retained as a complete batch before advancing to the bridge; a refusal or
line-count error saves the partial batch before stopping. There is no claim
of a separately durable per-line file after each positive call.

The bridge and its independent checker retain every formula, existing ZERO,
MP, GEN and variable including the fresh hole. Their bindings are compared
exactly. The generic model checker is used for RF; the ground-Horn-only basis
gate is not misapplied. Its catalogue, statement and complete prepared-model
hashes join the actual bridge/prepared objects. The migration compares all
original capacity, roots, seed and entire inventory after adding only the
engine schema/version and empty ordinary-filter fields. Full prepared packets
remain available for both original decoders. No row shortlist is substituted
for the universe.

Each later phase authenticates the prior prepared/model file references and
recomputes the exact migration. Source-level phase prerequisites are supplied
by the owning driver, which joins actual prior PID/native exit, protocol,
Source/runtime postchecks, result bytes and logs before entering later phases.

## Acquisition, fixed-CID labels and activation

Acquisition runs the original model with the prospectively lower one-node
bound and takes only its first actual `PLACED` event as a proposal. It checks
that CID occurs exactly once in the full original inventory. A prefix UNKNOWN
is expressly not a failure label; no placement means acquisition remains
UNKNOWN and later activation cannot proceed.

The label phase starts a fresh fixed-CID residual query. It adds the entire
chosen positive contribution and mandatory marking support to the original
seed, retains every original root, activates all chosen positive support,
removes that CID exactly once and retains every other placement unchanged.
Original zero seed rows survive. Merging equal seed markings changes fresh
query reference counts without changing exact-cover existence; the separate
overlay contract makes that distinction explicit.

A negative label requires actual raw finite UNSAT and C3 VERIFIED, with
matching UNSAT run status, complete events, the precise finite-exhaustion claim
and `bounded_absence=true`. A positive label requires raw/C3 SAT, then unions
the fixed CID once with the residual selection and passes that original union
through both M/N decoders. All statement, line, slot, native-index, reference,
DAG, selected and scope fields must agree before a fresh whole native B check.
Native refusal stops the phase with its saved evidence; it does not forge a C3
UNKNOWN receipt. Raw/assurance UNKNOWN never supplies a negative restriction.

Learning waits for the prior completed clean LABEL worker. The owner-supplied
`make_provenance` checks that actual result and all physical query references;
U separately checks the complete supplied object/certificate associations.
The learner receives the entire sorted CID list and actual typed labels with
scope/binding hashes. It does not receive the target derivation, a prescribed
bad CID, expected color assignment or exhaustive solution table. U's exact
conditional status remains conditional on the separately admitted scoped
exhaustion and physical execution gates. A positive or unresolved label yields
the empty extra layer, rather than an invented pruning result.

## Matched evaluation and limits of this gate

BASE, MARKS and FILTER use fresh engine state, the same entire CID list and
the exact U-admitted bound models. The marked model retains all old formula,
activity and seed markings, adding only the fresh guard layer; FILTER uses
the corresponding ordinary immutable unary list. They do not import previous
selections or share a search cache. A positive evaluation is admitted only
after semantic assurance and the fresh original M/N/native-B pipeline. A
verified finite exhaustion has its actual bounded scope. Unknown or rejected
assurance/native results remain separately visible in each lane even though
the orchestration can finish recording all lanes.

The process is a fixed warm lane order, with preparation/acquisition/labeling/
learning/assurance costs distinct. This Source gate establishes neither speed
comparability nor learned/RL superiority. The statement is an addition-zero
and equality-congruence fragment with quantifiers, not full PA or induction.
The palette is finite generated formulas/CIDs, not one fixed universal Wang
tile set. One scoped unary query is not a complete pair-corona catalogue or
geometric marking-transfer theorem.

Actual successful qualification, complete certificates, proof lines, resource
outcomes and native execution remain to be observed after Root's freeze. This
review authorizes no science by itself and makes no claim that the proposed
CID will be negative or that any learned restriction will be found.
