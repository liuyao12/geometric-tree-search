# Independent engine, checker, tiny-oracle and unary-overlay Source review

Status: **PASS_SOURCE_REVIEW_WITH_RESOURCE_CLOSURES**.
This is a static Source assessment, not runtime qualification. The reviewer
read the entire current E4, C3, T3, O2, synthesis, independent overlay checker
and both API documents, compared E/C/T against the exact preserved baselines,
and regenerated the complete E/C/T patch byte for byte. Only direct file reads,
native JSON metadata, hashing, textual/AST comparison and AST parsing occurred.
No scientific Source was imported or executed; no model, proof, search result,
classification, native check or test was constructed or run.

## Exact reviewed inputs

| Path | Bytes | SHA256 |
|---|---:|---|
| `source/growing_point_search_v4.py` | 43151 | `9953582e09e4a800591953b341812082a5eb9d13afa6aa36a1104eb1f1b5ea22` |
| `source/semantic_event_checker_v3.py` | 42452 | `aa265dc6c611415390bf20d442a24924164c75ff7ea623b961976aa0a0b0348d` |
| `source/frontier_trace_checker_v3.py` | 29412 | `72fb15d434a9dad0704295388e9e735f28f3537b63abd2e17d22165e65c6e5ca` |
| `source/tiny_assignment_oracle_v2.py` | 14522 | `78ac92d60b8dc6290e68620bff92a380253a2a6667af7e254bf7cda9a98b49aa` |
| `source/unary_overlay_v1.py` | 11265 | `0308a8af75cb4d1f4031f38f882e17650c4e5ab05c67bbe3b45e0c5434ff1870` |
| `source/unary_overlay_checker_v1.py` after closure below | 20252 | `e66c1cae5bc7930d5b2477104807699e755c7d14c87d5e4fcca185b4c73658c3` |
| `plan/engine-API-v1.md` | 3236 | `cd7b977a30c961d29b7f8e5d12f32bd1d1aa3cbf815bd2dc439c34c2c4619be6` |
| `plan/overlay-API-v1.md` | 11707 | `6a2da5e6e8f9071e831c21222b9d9355189cbd409f3a3e1187a6fb60b45abc92` |
| `review/unary-engine-adaptation-v1.patch` | 17133 | `d189346edff478e7114bd6beb8744e6993f911dd44309b0366660b0fa0a9bc19` |

All thirteen entries in `plan/upstream-pins-v1.json` were independently
byte/hash matched. In particular, E3 is `85e55b2a…`, C2 `5258610e…`, T2
`a0417e25…`, the prior assignment/preservation oracle `1b55ba04…`, and the
normative master `c1327e5e…`. The E/C/T patch covers those three adapters;
O2 is a separately reviewed extraction of the prior generic enumerator with
strict schema/unary extensions, not the prior exhaustive-preservation call.

## Engine and independent graph/checker assessment

The schema has exactly the prior six model fields plus mandatory sorted,
unique, known-CID `pair_nogoods` and `unary_nogoods`. Nonempty ordinary filters
require EXPLICIT inventory. No unary CID is deleted from the declared inventory.
The engine's frozen unary membership set is built from bound model data; it
has no branch-local mutation requiring a new rollback record. The schema and
version include the filter list in the normal model hash.

Every registered row still participates in the original complete positive and
marking dependency data. The unary predicate is applied inside ordinary global
legality before the original pair and complete positive/marking compatibility
checks. Consequently a forbidden row is unavailable at every incident point,
including at initialization. Dynamic pair-neighbor refreshing remains intact
even for neighbors with no positive/marking overlap. Unary filtering needs no
additional dynamic refresh because its truth never changes during a search.
The final certificate scans the literal unary/pair lists independently of the
membership indexes before admitting a selected set.

The underlying scheduler and reversible trail were not changed by this adapter:
global dead points precede global singleton propagation; otherwise generation
precedes degree, then deterministic keys. The full forward/reverse graph stores
the actual contribution on every incidence. Shared selections, marking reference
counts, literal assigned `0`, remote marking-only conflicts, generation lowering,
local branch exclusions and complete restoration retain their original roles.
Cleanup remains uninterruptible and runs before foreign exceptions escape.

C3 independently constructs its own normalized model, unary membership,
dependencies, reversible state and full semantic domains. It checks every
decision against those domains, exact lexical order, placement generations,
implicit failed-child restoration/exclusion and complete endpoint associations.
It does not claim observation of intermediate producer tables. T3 separately
re-enumerates domains using a literal scan of declared unary and pair lists,
checks actual supplied snapshots and selected certificates, and rejects
nonexplicit inventory. Its unreachable legacy provider code does not admit
that unsupported profile. Neither checker proves that input filters are
redundant; the separate exhaustion/overlay gate must establish that.

O2 checks all bounded subsets independently of any scheduler or graph helper.
It recomputes seed/selected totals, literal marking families, pair/unary
constraints, positive-support root reachability and exact active coverage.
An already-invalid selected family gets no eligible extension. Zero seed rows
do not activate remote points, while explicit roots and positive seed do.
`EXHAUSTED` requires all subsets; resource refusal retains UNKNOWN. This is an
independent tiny-fixture oracle, never enumeration of the arithmetic palette.

## Overlay and conditional preservation assessment

The synthesis function receives only the full CID list, typed labels, scope and
evidence binding hashes. Resolved negatives alone obtain the prescribed sparse
guard assignment. UNKNOWN/positive and unconstrained CIDs remain absent. With
no negatives both additional arrays are empty. Structural `apply` retains every
original CID, positive row, marking and seed value, verifies guard freshness
against every original domain, and builds distinct literal-marked and ordinary
unary-control models. It never authenticates label truth.

The independent overlay checker reconstructs the fixed-CID residual context
using the entire chosen contribution and original seed, adds all chosen
positive support to roots, removes that CID exactly once, and retains all
other rows. It binds the full raw/C3 objects, complete event stream and terminal
scope, actual endpoint hashes and restoration, label bindings, and supplied
prior clean LABEL-phase process/protocol/source associations. UNKNOWN cannot
become a negative. Native positive evidence remains a separate caller gate.
The conditional preservation implication is coherent: an original exact cover
containing the fixed CID would induce a residual cover, contradicting a sound
complete fixed-context exhaustion certificate. The guard rejects precisely the
same forbidden CID list as the ordinary unary control while leaving old data
unchanged. A hash/status association alone is not physical execution evidence;
the returned obligations explicitly require the driver to authenticate bytes,
runtime, actual C3 execution, source custody and native proof/carrier joins.

This is a finite-inventory unary adaptation. It establishes no geometric
prototype symmetry, reusable marking transfer, complete pair-corona catalogue,
RL gain, uniform universal Wang tile set or unrestricted nonprovability.

## Resource findings and closure state

Two cooperative final-wall gaps were reported before any execution:

1. Overlay checker computed three large model hashes inside the final success
   return after its last budget check. The author preserved the old
   `e9fbdce3…` draft as `review/overlay-checker-pre-resource-fix-v1.py`, then
   precomputed `model_bindings` and placed `r.step()` after all three hashes.
   The exact two-line closure in `review/overlay-checker-resource-fix-v1.patch`
   was read and accepted. Current checker pin is the `e66c1cae…` entry above.
2. T3 inherits a similar return-time issue: `Checker.run()` computes final
   model/universe hashes after its last tick; public `verify()` currently lacks
   the C3-style post-run `meter.tick()`. Root was asked to add that prospective
   final wall gate, preserve the old draft, and supply its final Source/diff
   pin. This note is deliberately not final resource closure until that delta
   is reviewed. No logical algorithm change is requested.

The other reviewed Source paths retain cooperative guards and explicit UNKNOWN
refusals. This static assessment neither measures those guards nor replaces
the prospective tiny full-snapshot/semantic/oracle qualification or the owned
outer wall/CPU/RSS observer.

## Final prospective closure

Root preserved the prior T3 Source as
`review/frontier-trace-pre-resource-fix-v1.py` and added only `meter.tick()`
immediately after `checker.run()` in the public wrapper. This places the wall
gate after final model/universe hashing and before a successful result leaves
the checker. The exact one-line delta was read and AST parsed, with no import,
test or scientific execution. Final T3 is 29,433 bytes, SHA256
`db036ae49126270251ae90f85e0227577c42db07478dac618875fdc9c4c09389`.
The regenerated complete E/C/T patch is 17,681 bytes, SHA256
`f9f1570c824a2b3758ae48264358eee1aafd6c105d573c7cf8ab8e5d66dc35d9`.
All other final Source/API pins in
the table remain current. The earlier T3/patch entries are historical review
inputs, superseded by this closure. Both raised resource findings are closed;
no remaining Source blocker was found within the stated logical scope.
