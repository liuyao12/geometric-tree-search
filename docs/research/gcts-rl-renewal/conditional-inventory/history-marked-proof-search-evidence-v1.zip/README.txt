Complete selected prepublication evidence cut. MANIFEST.json maps each member to its original path, mode, length and SHA256.
All current declared Sources, all31 input carriers, both complete qualification/main physical file lists, admissions and selected report/QA evidence are included.
The archive does not contain the recovery session logs, private chat transcripts, unverified recovery candidates, platform runtime, bare Git repositories or a nested historical ZIP.
The earlier temporary qualification raw evidence was lost; remembered aggregate output is not a current proof certificate. Any included public-safe recovery provenance states that limitation.
Current proofs are from the separately executed persistent runs. Historical upstream packages are explicit external pins; current operative Sources and input carriers are vendored.
This ZIP cannot include its own post-build/readback or future deployment records. Later Git/Pages/TLS/live checks are a separate durable supplement.
No archived code executes during packaging. Reproduction needs fresh plans and fresh once authority; spent authorities must never be reused.

Root admitted the current persistent qualification, all60 main method positions, and the saved report content/QA before selection. This is an exact selected prepublication cut, not publication completion.
Both current native observations and every original physical file, all13 current Source roles, bootstrap, all declared metadata, all31 frozen input carriers, both plans and fresh spent once authorities are retained.
Current final independent Source/custody/math/content reviews, their available passive auditing Source and support, Root readbacks/admissions, actual rendered HTML/JSON and browser QA are selected explicitly.
Historical missing qualification case/proof artifacts remain unadmitted and are not reconstructed. Public recovered Source/provenance is the separate exact four-file subset only.
The main trace contains135 streams,1333 retained of131905 reported rows; only37 full sequence digests can be recomputed, and98 omitted suffixes remain unverified.
The current results show8/7/7/10 verified positive occurrences across unmarked/history-scan/history-indexed/matched-depth control. No RL, learned-marking, universal-proof-search, unbounded negative or comparative speed superiority claim is made.
All scientific execution authorities are spent. Packaging is passive; reproduction requires separately reviewed fresh plans and once authority. No archived Source executes during selection or packaging.
