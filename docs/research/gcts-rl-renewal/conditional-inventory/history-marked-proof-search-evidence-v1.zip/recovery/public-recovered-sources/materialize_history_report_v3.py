"""Passive projection of complete saved observations; never imports a prover."""
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path


def need(ok, reason):
    if not ok:
        raise RuntimeError(reason)


def raw(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')


def pin(path):
    data = Path(path).read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def read_ref(ref):
    data = Path(ref['path']).read_bytes()
    need(len(data) == ref['bytes'] and hashlib.sha256(data).hexdigest() == ref['sha256'], 'whole reference')
    return data


def artifact(ref):
    need(type(ref['raw_bytes']) is int and 0 <= ref['raw_bytes'] <= 67108864, 'raw extent')
    data = read_ref(ref['stored'])
    if ref['encoding'] == 'gzip-json':
        with gzip.GzipFile(fileobj=io.BytesIO(data), mode='rb') as stream:
            data = stream.read(ref['raw_bytes'] + 1)
    else:
        need(ref['encoding'] == 'json', 'encoding')
    need(len(data) == ref['raw_bytes'] and hashlib.sha256(data).hexdigest() == ref['raw_sha256'], 'whole raw artifact')
    return json.loads(data)


def main():
    parser = argparse.ArgumentParser()
    for key in ('observer', 'qualification', 'admission', 'out'):
        parser.add_argument('--' + key, required=True)
    args = parser.parse_args()
    observer = json.loads(Path(args.observer).read_bytes())
    need(observer['status'] == 'COMPLETE' and observer['returncode'] == 0
         and observer['both_streams_EOF'] and observer['group_gone'], 'complete observation')
    exp = artifact(observer['worker_terminal']['result'])['experiment']
    need(exp['status'] == 'COMPLETE' and len(exp['results']) == 15, 'all15')
    admission = json.loads(Path(args.admission).read_bytes())
    qualification = json.loads(Path(args.qualification).read_bytes())
    need(admission['status'] == qualification['status'] == 'ADMITTED', 'scientific gates')
    plan = json.loads(read_ref(observer['worker_terminal']['plan']))
    manifest = json.loads(read_ref(plan['metadata']['frozen_inputs']))
    inputs = {x['name']: x for x in manifest['inputs']}
    bank = artifact(inputs['current-bank-and-native-checks'])['result']['value']
    lanes = exp['design']['lanes']
    need(lanes == ['UNMARKED_INDEXED', 'HISTORY_SCAN', 'HISTORY_INDEXED', 'MATCHED_DEPTH_TREE_CONTROL'], 'four lanes')
    counts = {k: dict(verified=0, unknown=0, finite_exhausted=0, search_seconds=0.0,
                      candidate_registrations=0, provider_rows=0) for k in lanes}
    cases, source_refs = [], []
    for row in exp['results']:
        prep = artifact(inputs[row['id'] + '-whole-preparation'])
        case = {'id': row['id'], 'group': 'Arithmetic' if '-arith-' in row['id'] else
                'Typing' if '-typing-' in row['id'] else 'Incidence', 'depth': row['depth'],
                'problem': row['original'], 'lemma_bindings': prep['application']['lemma_bindings'], 'lanes': {}}
        for lane in lanes:
            compact = row['lanes'][lane]
            full = artifact(compact['ref'])
            need(compact['status'] == full['status'] and compact['verified'] is full['verified'], 'lane projection')
            yes, positive = full['verified'], full.get('positive', {})
            if yes:
                need(positive['verified'] and all(positive[k]['status'] == 'VERIFIED' for k in
                    ('tree_audit', 'lowering_audit', 'coarse_host_check', 'original_host_check')), 'positive proof checks')
                if lane.startswith('HISTORY_'):
                    need(positive['history_audit']['status'] == 'VERIFIED' and positive['normal_form']['path_normal'], 'history audit')
            assurance = lane == 'MATCHED_DEPTH_TREE_CONTROL' or full.get('factory_audit', {}).get('status') == 'VERIFIED'
            negative = full['status'] in ('UNSAT', 'NOT_DERIVABLE') and assurance
            counts[lane]['verified'] += int(yes)
            counts[lane]['finite_exhausted'] += int(negative)
            counts[lane]['unknown'] += int(not yes and not negative)
            counts[lane]['search_seconds'] += full['search_seconds']
            stats = (full.get('result') or {}).get('stats', {})
            for key in ('candidate_registrations', 'provider_rows'):
                counts[lane][key] += stats.get(key, 0)
            case['lanes'][lane] = {'status': full['status'], 'reason': full.get('reason'),
                'original_status': 'VERIFIED' if yes else 'UNKNOWN_FACTORY_AUDIT' if not assurance
                    else positive.get('reason', 'NO_CERTIFICATE'), 'seconds': full['search_seconds'],
                'coarse_proof': positive.get('coarse_proof', []) if yes else [],
                'original_proof': positive.get('original_proof', []) if yes else [],
                'tree': positive.get('actual_tree') if yes else None,
                'checks': {k: positive.get(k) for k in ('tree_audit', 'history_audit', 'coarse_host_check',
                    'original_host_check', 'lowering_audit', 'normal_form')},
                'lowering': positive.get('lowering') if yes else None,
                'source_ref': compact['ref'], 'stats': stats, 'provider': full.get('provider', {})}
            source_refs.append(compact['ref'])
        cases.append(case)
    for lane in lanes:
        need(sum(counts[lane][k] for k in ('verified', 'unknown', 'finite_exhausted')) == 15, 'complete tally')
    paired = [c for c in cases if all(c['lanes'][k]['original_proof'] for k in ('HISTORY_SCAN', 'HISTORY_INDEXED'))]
    for case in paired:
        a, b = (case['lanes'][k] for k in ('HISTORY_SCAN', 'HISTORY_INDEXED'))
        need(a['coarse_proof'] == b['coarse_proof'] and a['tree'] == b['tree'], 'same successful marked witness')
    baseline_detours = [c['id'] for c in cases if c['lanes']['UNMARKED_INDEXED']['original_proof']
        and not c['lanes']['UNMARKED_INDEXED']['checks']['normal_form']['path_normal']]
    findings = [f"Verified targets: unmarked indexed {counts[lanes[0]]['verified']}, history scan {counts[lanes[1]]['verified']}, history index {counts[lanes[2]]['verified']}, proof-tree control {counts[lanes[3]]['verified']}. All sixty positions are retained.",
        'Every displayed proof was discovered by its recorded search, independently reconstructed, expanded through the certified lemma bank, and checked in the original theory. No old target proof or manually written target derivation was a search input.',
        f'The two history implementations return identical marked trees on their {len(paired)} common successful targets. Unmarked and marked proof sets differ, with the stated bounded-existence theorem.',
        f'{len(baseline_detours)} successful unmarked proof trees contain a repeated literal formula along a path. These remain valid proofs; the history model chooses different witnesses.']
    costs = [f"New observer wall: {observer['whole_observer_seconds']:.3f} seconds; child lifetime peak RSS: {observer['wait4_peak_bytes']} bytes.",
        f"Reused catalogue preparation: {exp['design']['historical_preparation_seconds']:.3f} seconds; historical donor acquisition: {exp['design']['historical_donor_acquisition_seconds']:.3f} seconds. These are historical costs, separately disclosed.",
        f"Fresh shared bank checks: {exp['fresh_bank_check_seconds']:.4f} seconds. Independent factory/certificate/tree checks, lowering and positive host checks occur outside the search windows and remain in the raw evidence.",
        'One fixed-order observation, with implementation-dependent work caps as well as wall windows. Completed query counts have multiplicity; registrations include rollback re-registration. No missing stream suffix or unique-universe count is inferred.']
    for lane in lanes:
        c = counts[lane]
        costs.append(f"{lane}: {c['search_seconds']:.4f} seconds total cold search; {c['verified']} verified, {c['finite_exhausted']} finite-depth exhausted, {c['unknown']} unknown; {c['candidate_registrations']} cumulative candidate registrations, {c['provider_rows']} provider rows.")
    reader = {'counts': counts, 'cases': cases, 'bank': bank['lemmas'], 'findings': findings,
        'qualification_summary': qualification.get('summary', 'Independent tiny exhaustive qualification; exact scope and observations retained.'),
        'cost_notes': costs, 'assessment': [
            'This tests explicit marking-based normal-form pruning, not learning which logically valid proofs are failures. Finite exhausted marked search concerns the fixed catalogue and depth; it is not unrestricted unprovability.',
            'The direct and indexed history lanes share the same literal marked inventory. Their difference tests enumeration cost; comparison with unmarked GCTS tests a changed proof set with an existence theorem.',
            'The proof-tree control is a relevant conventional baseline. Curated known regression assertions, one timing observation and finite producer catalogues cannot establish a broad advantage over automated theorem provers.',
            'No RL policy is trained or used. Exact learned failure markings, adaptable connected cluster proposals, a fixed universal proof palette and substantial new mathematics remain open.'],
        'provenance': {'observer': pin(args.observer), 'qualification_admission': pin(args.qualification),
            'scientific_admission': pin(args.admission), 'plan': observer['worker_terminal']['plan'],
            'full_lane_records': source_refs, 'unmarked_valid_detour_cases': baseline_detours, 'scope': exp['scope']}}
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=False)
    data = {'schema': 'HNF-history-marked-proof-search-public-results-v1', 'reader': reader,
        'design': exp['design'], 'limits': exp['design']['limits'],
        'scope': 'Passive complete saved-data projection; raw originals retained in full archive.'}
    (out/'history-marked-proof-search-results-v1.json').write_bytes(raw(data))
    (out/'history-marked-proof-search-v1.html').write_bytes((Path(__file__).parent/'history-proof-reader-template-v4.html').read_bytes())
    print(json.dumps({'status': 'COMPLETE', 'counts': counts, 'files': [pin(p) for p in sorted(out.iterdir())]}, sort_keys=True))


if __name__ == '__main__':
    main()
