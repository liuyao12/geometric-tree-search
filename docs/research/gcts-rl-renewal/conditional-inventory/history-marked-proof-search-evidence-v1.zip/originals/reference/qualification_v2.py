"""Bounded independent qualification. Inert until the parent dispatches it.

Eight assertion-only fixtures; exhaustive inventories and complete rooted-tree
collections are supplied by the independent reference. No target proof scripts.
"""
import hashlib
import itertools
import json
import math
import time

VERSION = 'HN-REFERENCE-QUALIFICATION-20261102-v2'
ENGINE_LIMITS = dict(wall_seconds=10, max_work=10**9, max_nodes=10000, max_events=4096,
                     max_rollback_records=4096, max_candidates=10000, max_points=256)
FACTORY_LIMITS = dict(wall_seconds=10, max_work=10**9, max_depth=128, max_definitions=10000, max_proof_lines=64)
ORACLE_LIMITS = dict(wall_seconds=15, max_work=10**9, max_inventory=20000, max_trees=10000, max_depth=128, max_selected=64)
AUDIT_LIMITS = dict(wall_seconds=15, max_work=10**9, max_depth=128, max_items=200000)
HOST_LIMITS = dict(max_proof_lines=64, max_operations=10**8, max_depth=128)
LANES = ('UNMARKED_EXPLICIT', 'ANCESTOR_PAIR_EXPLICIT', 'HISTORY_SCAN', 'HISTORY_INDEXED')


class QualificationError(ValueError):
    pass


class Foreign(Exception):
    pass


def need(test, reason):
    if not test:
        raise QualificationError(reason)


def text(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(',', ':'), allow_nan=False)


def wire(value):
    return (text(value) + '\n').encode('ascii')


def sha(value):
    return hashlib.sha256(wire(value)).hexdigest()


def clone(value):
    return json.loads(text(value))


def fixtures():
    p, q, r, g = (['pred', n, []] for n in ('P', 'Q', 'R', 'G'))
    ax, ay = ['all', 'x', ['pred', 'P', [['var', 'x']]]], ['all', 'y', ['pred', 'P', [['var', 'y']]]]
    return [
        dict(id='zero-aliases-wrong-output', depth=0, predicates=dict(P=0, R=0), axioms=dict(p0=p, p1=p, r=r), goal=p),
        dict(id='unary-generalization', depth=1, predicates=dict(P=0), axioms=dict(p=p), goal=['all', 'x', p]),
        dict(id='binary-modus-ponens', depth=1, predicates=dict(P=0, Q=0, R=0), axioms=dict(p=p, pq=['imp', p, q], r=r), goal=q),
        dict(id='valid-detour-normalization', depth=1, predicates=dict(P=0), axioms=dict(p=p, pp=['imp', p, p]), goal=p),
        dict(id='cyclic-mp-no-base', depth=2, predicates=dict(P=0), axioms=dict(pp=['imp', p, p]), goal=p),
        dict(id='cyclic-generalization-no-base', depth=2, predicates=dict(P=0), axioms={'ap-p': ['imp', ['all', 'x', p], p]}, goal=['all', 'x', p]),
        dict(id='shared-curried-incomparable-branches', depth=3, predicates=dict(P=0, Q=0, R=0, G=0),
             axioms={'p': p, 'pq': ['imp', p, q], 'pr': ['imp', p, r], 'q-rg': ['imp', q, ['imp', r, g]]}, goal=g),
        dict(id='literal-binder-and-capture-distinction', depth=1, predicates=dict(P=1),
             axioms={'ax': ax, 'ay': ay, 'ay-ax': ['all', 'y', ['all', 'x', ['pred', 'P', [['var', 'y']]]]]}, goal=ax),
    ]


def compiled_fixture(fixture):
    f = clone(fixture); by_color = {}; todo = [f['goal']] + list(f['axioms'].values())
    while todo:
        x = todo.pop(); key = text(x)
        if key in by_color:
            continue
        by_color[key] = x
        if x[0] == 'imp':
            todo.extend(x[1:])
        if x[0] == 'all':
            todo.append(x[2])
    colors = sorted(by_color); forms = [by_color[k] for k in colors]; ids = {k: i for i, k in enumerate(colors)}
    zero = sorted([dict(rule='axiom', name=n, formula=x) for n, x in f['axioms'].items()], key=text)
    profile = dict(ui_rounds=0, bridge_arity=0, max_tautology_atoms=0)
    scope = 'SYNTHETIC_STRUCTURAL_NATIVE_AXIOM_FIXTURE_NOT_FULL_Y_GENERATION'
    c = dict(schema='V-interned-Hilbert8-basis-v1', version='V-INTERNED-FINITE-HILBERT8-v1',
        theory=dict(functions={}, predicates=f['predicates'], axioms=f['axioms']), goal=f['goal'], goal_id=ids[text(f['goal'])],
        profile=profile, logical_basis=dict(instantiation_terms=[], terms=[], variables=[], formulas=forms, colors=colors,
                                          templates=[], hole='__hn_fixture', stages=[]),
        zero_instances=[dict(id='i'+str(i), rule='axiom', formula_id=ids[text(x['formula'])], line=x) for i, x in enumerate(zero)],
        mp_index=[[i, ids[text(x[1])], ids[text(x[2])]] for i, x in enumerate(forms) if x[0] == 'imp'],
        gen_index=[[i, ids[text(x[2])], x[1]] for i, x in enumerate(forms) if x[0] == 'all'],
        costs=dict(work=0, seconds=0.0, terms=0, formulas=len(forms), instances=len(zero), candidates=0,
                   cache_hits=0, cache_misses=0, canonical_serializations=0, substitution_calls=0), scope=scope)
    generation = dict(schema='Y-goal-receptor-universe-v1', version='Y-GOAL-RECEPTOR-FAMILY-v1', profile=profile,
        compiled_core_sha256=sha({k:v for k,v in c.items() if k not in ('costs','scope')}), core_stages=[],
        core_assertions=[], goal_receptors=[], bridge_premises=[], scope=scope)
    return c, generation


def stream(rows, extent, full):
    need(type(rows) is list and len(rows) == extent['retained'] <= extent['total'], 'STREAM_EXTENT')
    complete = len(rows) == extent['total']
    need(not full or complete, 'TRUNCATED_NORMAL_STREAM')
    if complete:
        need(hashlib.sha256(b''.join(wire(r) for r in rows)).hexdigest() == extent['sha256'], 'FULL_STREAM_HASH')
    return complete


def schedule(event, state, before, seen, rows):
    kind, point, cid = event['kind'], event['point'], event['candidate']
    domains, gens = dict(state['domains']), dict(state['Q'])
    dead = [p for p, ds in domains.items() if not ds]; forced = [p for p, ds in domains.items() if len(ds) == 1]
    if kind in ('DEAD', 'FORCED', 'BRANCH'):
        need(point in domains and event['data']['generation'] == gens[point], 'EVENT_GENERATION')
        if kind == 'DEAD':
            need(point in dead, 'GLOBAL_DEAD')
        elif kind == 'FORCED':
            need(not dead and point == min(forced, key=lambda p:(gens[p],p)) and cid == domains[point][0], 'GLOBAL_FORCED')
        else:
            need(not dead and not forced and point == min(domains,key=lambda p:(gens[p],len(domains[p]),p))
                 and event['data']['legal'] == event['data']['order'] == domains[point], 'GENERATION_FIRST_LEX_BRANCH')
    elif kind == 'PLACED':
        need(before is not None and before['event']['kind'] in ('FORCED','BRANCH'), 'PLACE_PREDECESSOR')
        e, s = before['event'], before['state']; chosen = e['candidate'] if e['kind'] == 'FORCED' else e['data']['order'][0]
        need(cid == chosen and cid in rows, 'SCHEDULED_CID')
        g = 1 + min(dict(s['Q'])[p] for p,n in rows[cid]['t'] if p in dict(s['Q']))
        need(event['data']['generation'] == g and dict(state['selected']) == dict(s['selected']) | {cid:g}, 'PLACED_DELTA')
    elif kind == 'EXCLUDE':
        parents = [v['state'] for v in seen if v['event']['kind'] == 'BRANCH' and v['event']['data']['order'][0] == cid and v['state']['selected'] == state['selected']]
        need(parents, 'FAILED_CHILD_PARENT'); parent = parents[-1]
        need(all(parent[k] == state[k] for k in ('Q','totals','marks','selected','placements','loaded'))
             and state['excluded'] == sorted(set(parent['excluded']) | {cid}), 'EXACT_PARENT_RESTORE')
    else:
        need(kind in ('READY','SOLUTION','EXHAUSTED'), 'EVENT_KIND')
        if kind == 'SOLUTION':
            need(not domains, 'CLOSED_FRONTIER')


def comparison_join(v):
    for kind in ('old','history','pair'):
        xs = v[kind+'_trees']; need(v['counts'][kind] == len(xs) and v[kind+'_tree_hashes'] == [sha(x) for x in xs], 'TREE_COLLECTION_JOIN')
        need([text(x) for x in xs] == sorted(set(text(x) for x in xs)), 'TREE_COLLECTION_ORDER')
    projected = sorted([sorted(text(json.loads(cid)[:2]) for cid in x) for x in v['history_trees']], key=text)
    need(projected == v['pair_trees'] and bool(v['old_trees']) == bool(v['history_trees']) == bool(v['pair_trees']), 'COMPLETE_EXISTENCE_JOIN')
    old, hist = dict(zip(v['old_tree_hashes'],v['old_trees'])), dict(zip(v['history_tree_hashes'],v['history_trees']))
    need({r['old_sha256'] for r in v['normalizations']} == set(old) and len(v['normalizations']) == len(old), 'ALL_NORMALIZATIONS')
    for r in v['normalizations']:
        a,b = old[r['old_sha256']],hist[r['normal_sha256']]
        need(r['old_nodes'] == len(a) and r['normal_nodes'] == len(b) <= len(a)
             and r['old_height'] == max(len(json.loads(cid)[0]) for cid in a)
             and r['normal_height'] == max(len(json.loads(cid)[0]) for cid in b) <= r['old_height'], 'NORMALIZATION_BOUNDS')


def describe_join(compiled, point, universe, actual, identity):
    groups = {}
    for r in universe:
        if any(p == point for p,n in r['t']):
            s,d,h = json.loads(r['id']); key = text(['HN-history-arity-v1',s,len(r['t'])-1]); groups.setdefault(key,[]).append(r)
    families, td, md = [],set(),set()
    for key, rows in sorted(groups.items()):
        _,s,a = json.loads(key); ds=sorted({json.loads(r['id'])[1] for r in rows})
        ts=sorted({p for r in rows for p,n in r['t']}); ms=sorted({p for r in rows for p,v in r['m']})
        n=math.comb(len(compiled['logical_basis']['formulas'])-1,len(s)); need(len(rows)==n*len(ds),'STATIC_HISTORY_COUNT')
        families.append(dict(id=key,anchor=s,arity=a,definition_ids=ds,t_points=ts,m_points=ms,history_size=len(s),histories_per_definition=n,potential_count=len(rows)))
        td.update(ts);md.update(ms)
    expected=dict(point=point,inventory_identity=identity,complete=True,families=families,
                  dependencies=dict(t=sorted(td),m=sorted(md)),potential_count=sum(map(len,groups.values())),scope='COMPLETE_STATIC_HISTORY_OWN_AND_ALL_PARENT_ALIGNMENT_FAMILIES')
    need(actual==expected,'STATIC_DESCRIPTOR_EXACT');return dict(status='VERIFIED',expected=expected)


class Captured:
    incident_query_abi = 'IP-CURRENT-TM-INCIDENT-v1'
    def __init__(self,p,c,d,oracle,mode=None):
        self.provider,self.compiled,self.depth,self.oracle,self.mode=p,c,d,oracle,mode;self.records=[]
    def __call__(self,q,charge):
        if self.mode=='FOREIGN':raise Foreign('provider')
        if self.mode=='STICKY':
            try:charge(10**30)
            except Exception:pass
        before=clone(q);reply=self.provider(q,charge)
        check=self.oracle('verify_query',self.compiled,self.depth,before,reply,dict(ORACLE_LIMITS))
        need(check['status']=='VERIFIED','COMPLETE_QUERY');self.records.append(dict(query=before,reply=clone(reply),independent=check))
        if self.mode=='MUTATE':q.clear()
        if self.mode=='BAD-HASH':reply=clone(reply);reply['context_sha256']='x'+reply['context_sha256'][1:]
        return reply


def qualify(modules,emit,budget):
    started=time.perf_counter();calls={};current={};counts=dict(fixtures=8,normal_solves=0,tail_solves=0,host_checks=0,observations=0,captured_queries=0,direct_queries=0,describes=0,provider_snapshots=0,records=0)
    direct_work=0
    def charge(n=1):
        nonlocal direct_work
        need(type(n) is int and 0<=n<=10**9-direct_work,'DIRECT_WORK_REFUSAL')
        direct_work+=n;budget();need(time.perf_counter()-started<180,'QUALIFICATION_WALL')
    def call(role,name,*args,**kwargs):
        budget();need(time.perf_counter()-started<180,'QUALIFICATION_WALL');key=role+'.'+name;calls[key]=calls.get(key,0)+1
        v=getattr(modules[role],name)(*args,**kwargs);budget();return v
    def oracle(name,*args):return call('history_oracle',name,*args)
    def out(name,value):
        value.setdefault('native_certificates',[]);emit(name,value);counts['records']+=1;budget()
    def run(c,d,model,rows,provider=None,history=False,limits=None,audit_mode=None,order=None,normal=True):
        observations=[];table={r['id']:r for r in rows};current.update(model=model,observations=observations,query_captures=[] if provider is None else provider.records,actual_result=None)
        def state_check(s):
            return oracle('verify_state',c,d,model,s,dict(ORACLE_LIMITS)) if history else call('growth_audit','verify_state',model,s,universe=rows,limits=dict(AUDIT_LIMITS))
        def audit(e,s,charge):
            check=state_check(s);need(check['status']=='VERIFIED','EXHAUSTIVE_STATE');counts['observations']+=1
            observations.append(dict(event=clone(e),state=clone(s),independent=check))
            if audit_mode=='FOREIGN':raise Foreign('audit')
            if audit_mode=='MUTATE':e.clear();s.clear()
        answer=call('engine_indexed','solve',model,dict(ENGINE_LIMITS if limits is None else limits),enumerate_incident=provider,order=order,audit=audit)
        current['actual_result']=answer
        need(answer['status'] in ('SAT','UNSAT','UNKNOWN'),'STATUS')
        if answer['entry_state'] is not None:need(answer['entry_state']==answer['restored_state'],'WHOLE_ENTRY_RESTORE')
        for key in ('entry','final','restored'):
            s=answer[key+'_state']
            if s is not None:need(state_check(s)['status']=='VERIFIED' and answer['state_hashes'][key]==sha(s),'RETURNED_STATE')
            else:need(answer['state_hashes'][key] is None,'ABSENT_STATE_HASH')
        stream(answer['events'],answer['event_extent'],normal);stream(answer['rollback_records'],answer['rollback_extent'],normal)
        for i,v in enumerate(observations):schedule(v['event'],v['state'],None if i==0 else observations[i-1],observations[:i],table)
        need([v['event'] for v in observations[:len(answer['events'])]]==answer['events'][:len(observations)],'OBSERVED_EVENT_JOIN')
        captures=[] if provider is None else provider.records;counts['captured_queries']+=len(captures)
        ev=answer['provider_evidence']
        if normal:
            need(len(observations)==answer['event_extent']['total'],'ALL_OBSERVATIONS')
            need(ev['total']==ev['retained']==len(captures),'ALL_QUERY_CAPTURES')
            need(ev['records']==[dict(query=v['query'],reply=v['reply']) for v in captures],'QUERY_RECEIPT_JOIN')
        if not history:
            projected=dict(answer);projected.pop('provider_evidence');projected['version']='Z-GROWING-POINT-SEARCH-v1'
            check=call('growth_audit','verify_result',model,projected,universe=rows,observations=[dict(event=v['event'],state=v['state']) for v in observations],limits=dict(AUDIT_LIMITS))
            need(check['status']=='VERIFIED','EXPLICIT_RESULT')
        return dict(result=answer,observations=observations,query_captures=captures)
    def proof(c,d,lane,data):
        ans=data['result']
        if ans['status']!='SAT':return None
        hc=None
        if lane.startswith('HISTORY'):
            hc=oracle('verify_certificate',c,d,ans['selected'],ans['certificate'],dict(ORACLE_LIMITS));need(hc['status']=='VERIFIED','HISTORY_CERTIFICATE')
            dec=call('history_provider','decode',modules['adapter_indexed'],c,d,ans['selected'],dict(FACTORY_LIMITS))
            need(dec['status']=='UNVERIFIED_CERTIFICATE' and dec['base_selected']==hc['value']['projected_selected'],'HISTORY_DECODE')
            need(dec['tree']['histories']==hc['value']['histories'] and all(dec['tree'][k]==ans['certificate'][k] for k in ('placements','totals','marks')),'HISTORY_TREE_BINDINGS')
            selected,base=dec['base_selected'],dec['base_decoded']
        else:
            selected=ans['selected'];dec=call('adapter_indexed','decode',c,d,selected,dict(FACTORY_LIMITS));base=dec
            need(dec['status']=='UNVERIFIED_CERTIFICATE','EXPLICIT_DECODE')
        tree=call('growth_audit','verify_tree',c,d,selected,base,limits=dict(AUDIT_LIMITS));need(tree['status']=='VERIFIED' and tree['proof']==dec['proof'],'INDEPENDENT_TREE')
        host=call('fol_checker','check',c['theory'],dec['proof'],c['goal'],dict(HOST_LIMITS));need(host['status']=='VERIFIED','FRESH_HOST_CHECK');counts['host_checks']+=1
        return dict(history_certificate=hc,decoded=dec,independent_tree=tree,host_check=host,label=lane,problem=dict(theory=c['theory'],goal=c['goal']),proof=dec['proof'])
    prepared=[]
    try:
        for f in fixtures():
            current.clear();current['stage']=f['id'];c,g=compiled_fixture(f);d=f['depth'];before=sha([c,g])
            current.update(case=f,compiled=c,generation=g)
            inv=oracle('enumerate_inventory',c,d,dict(ORACLE_LIMITS));current['inventory']=clone(inv)
            comp=oracle('compare_bounded_trees',c,d,dict(ORACLE_LIMITS));current['complete_tree_comparison']=clone(comp)
            need(inv['status']==comp['status']=='COMPLETE','TINY_COLLECTIONS');iv,cv=inv['value'],comp['value'];comparison_join(cv)
            if f['id']=='valid-detour-normalization':need(cv['counts']['removed']>0,'VALID_DETOUR_REMOVED')
            lanes,ps,fs,native={},{},{},[]
            current.update(lanes=lanes,factories=fs,native_certificates=native)
            for lane in LANES:
                h=lane.startswith('HISTORY')
                if h:
                    mode='scan' if lane=='HISTORY_SCAN' else 'indexed';model,p,factory=call('history_provider','make_provider',modules['adapter_indexed'],c,g,d,dict(FACTORY_LIMITS),mode=mode)
                    current.update(active_lane=lane,model=clone(model),factory=clone(factory))
                    need(factory['status']=='COMPLETE','FACTORY');fc=oracle('verify_factory',c,g,d,model,factory,dict(ORACLE_LIMITS));need(fc['status']=='VERIFIED' and model==iv['certified_model'],'EXACT_FACTORY')
                    ps[lane]=p;fs[lane]=dict(receipt=factory,independent=fc);rows,trees=iv['placements'],cv['history_trees']
                    wrapped=Captured(p,c,d,oracle,'MUTATE' if f['id']=='binary-modus-ponens' and mode=='indexed' else None)
                else:
                    old=lane=='UNMARKED_EXPLICIT';model=iv['old_explicit_model' if old else 'pair_explicit_model'];rows=iv['old_placements' if old else 'pair_placements'];trees=cv['old_trees' if old else 'pair_trees'];wrapped=None
                data=run(c,d,model,rows,wrapped,h,audit_mode='MUTATE' if f['id']=='unary-generalization' and lane=='HISTORY_SCAN' else None)
                counts['normal_solves']+=1;ans=data['result'];need(ans['status'] in ('SAT','UNSAT') and (ans['status']=='SAT')==bool(trees),'COMPLETE_EXISTENCE')
                if ans['status']=='SAT':need(ans['selected'] in trees,'ACTUAL_TREE_IN_COMPLETE_COLLECTION')
                if h and f['id']=='valid-detour-normalization':need(ans['stats']['backtracks']>0 and ans['stats']['exclusions']>0,'REAL_FAILED_DETOUR')
                positive=proof(c,d,lane,data);lanes[lane]=dict(model=model,**data)
                if positive is not None:lanes[lane]['positive']=positive;native.append({k:positive[k] for k in ('label','problem','proof')})
            a,b=lanes['HISTORY_SCAN'],lanes['HISTORY_INDEXED'];need(a['model']==b['model'] and all(a['result'][k]==b['result'][k] for k in ('status','selected','certificate','events','event_extent')),'SCAN_INDEX_EQUIVALENCE')
            descriptors=[]
            for point in [''.join(v) for n in range(d+1) for v in itertools.product('01',repeat=n)]:
                pair=[]
                for lane in ('HISTORY_SCAN','HISTORY_INDEXED'):
                    actual=ps[lane].describe(point,charge);counts['describes']+=1;check=describe_join(c,point,iv['placements'],actual,model['inventory']['identity']);pair.append(dict(mode=lane,actual=actual,independent=check))
                need(pair[0]['actual']==pair[1]['actual'],'DESCRIBE_MODE_EQUALITY');descriptors.append(dict(point=point,modes=pair))
            snapshots={lane:ps[lane].snapshot() for lane in ps};counts['provider_snapshots']+=2
            for lane,s in snapshots.items():need(s['calls']==s['completed_packets']==len(lanes[lane]['query_captures']),'TELEMETRY_QUERY_BINDING')
            need(sha([c,g])==before,'INPUTS_UNCHANGED')
            record=dict(case=f,compiled=c,generation=g,inventory=inv,complete_tree_comparison=comp,factories=fs,lanes=lanes,descriptions=descriptors,provider_snapshots=snapshots,native_certificates=native)
            out('case-'+f['id'],record);prepared.append(dict(fixture=f,compiled=c,generation=g,depth=d,inv=iv,comp=cv,providers=ps,record=record))
        # Sixteen literal contexts, each checked in both implementations.
        binary,detour,binder=prepared[2],prepared[3],prepared[7];requests=[]
        def hp(s):return text(['HN-history-v1',s])
        def query(item,p,totals=None,marks=None):return dict(schema='IP-current-tm-incident-query-v1',inventory_identity=item['inv']['certified_model']['inventory']['identity'],point=p,capacity=2,totals=sorted(totals or []),marks=sorted(marks or []))
        for p in ('','0','1'):requests.append((binary,'unbound-'+(p or 'root'),query(binary,p)))
        for i,h in enumerate(('','[]','[ 0]','[false]','[0,0]','[9999]','null')):requests.append((binary,'invalid-'+str(i),query(binary,'0',marks=[[hp('0'),h]])))
        fid=binary['compiled']['goal_id'];seed=binary['inv']['certified_model']['seed']['m'];h=text([fid]);other=text([(fid+1)%len(binary['compiled']['logical_basis']['formulas'])])
        requests.extend([(binary,'children-agree',query(binary,'',[['',1]],seed+[[hp('0'),h],[hp('1'),h]])),(binary,'children-disagree',query(binary,'',[['',1]],seed+[[hp('0'),h],[hp('1'),other]])),(binary,'parent-full',query(binary,'0',[['',2]])),(binary,'parent-residual',query(binary,'0',[['',1]])),(binder,'literal-binders',query(binder,'0',marks=[[hp('0'),text([binder['compiled']['goal_id']])]])),(detour,'future-dead-parent-retained',query(detour,'',[['',1]],detour['inv']['certified_model']['seed']['m']))])
        directs=[]
        for item,label,q in requests:
            current.clear();current.update(stage='direct-'+label,query=q);pair=[]
            for lane in ('HISTORY_SCAN','HISTORY_INDEXED'):
                reply=item['providers'][lane](clone(q),charge);counts['direct_queries']+=1;current['actual_reply']=clone(reply)
                check=oracle('verify_query',item['compiled'],item['depth'],q,reply,dict(ORACLE_LIMITS));need(check['status']=='VERIFIED','DIRECT_COMPLETE_QUERY');pair.append(dict(mode=lane,reply=reply,independent=check))
            need(pair[0]['reply']==pair[1]['reply'],'DIRECT_MODE_EQUALITY')
            if label.startswith('invalid-') or label=='children-disagree':need(not pair[0]['reply']['placements'],'INVALID_HISTORY_EMPTY')
            if label=='future-dead-parent-retained':need(any(json.loads(json.loads(r['id'])[1])[0]=='mp' for r in pair[0]['reply']['placements']),'NO_HIDDEN_LOOKAHEAD')
            directs.append(dict(case=item['fixture']['id'],label=label,query=q,modes=pair))
        out('direct-complete-contexts',dict(queries=directs))
        item=prepared[0];lane=item['record']['lanes']['HISTORY_INDEXED'];mutants=[]
        for label,h in [('bool',[False]),('duplicate',[item['compiled']['goal_id']]*2),('own-output',[item['compiled']['goal_id']])]:
            cid=json.loads(lane['result']['selected'][0]);cid[2]=h;bad=[text(cid)];check=oracle('verify_certificate',item['compiled'],item['depth'],bad,lane['result']['certificate'],dict(ORACLE_LIMITS));need(check['status']=='REJECTED','MUTATED_CERTIFICATE')
            try:call('history_provider','decode',modules['adapter_indexed'],item['compiled'],item['depth'],bad,dict(FACTORY_LIMITS))
            except modules['history_provider'].InputError as e:decoder=dict(exception=type(e).__name__,message=str(e))
            else:raise QualificationError('MUTATED_DECODER_ACCEPTED')
            mutants.append(dict(label=label,selected=bad,independent=check,decoder=decoder))
        # Native JSON wire types are part of exactness, not Python numeric equality.
        for label,kind in [('certificate-boolean-t','bool-t'),('certificate-float-capacity','float-cap')]:
            bad=clone(lane['result']['certificate'])
            if kind=='bool-t':bad['placements'][0]['t'][0][1]=True
            else:bad['capacity']=2.0
            check=oracle('verify_certificate',item['compiled'],item['depth'],lane['result']['selected'],bad,dict(ORACLE_LIMITS))
            need(check['status']=='REJECTED','NATIVE_CERTIFICATE_TYPE');mutants.append(dict(label=label,certificate=bad,independent=check))
        factory=item['record']['factories']['HISTORY_INDEXED']['receipt']
        for label,kind in [('factory-float-capacity','float-cap'),('factory-wrong-seed','wrong-seed')]:
            bad=clone(lane['model'])
            if kind=='float-cap':bad['capacity']=2.0
            else:bad['seed']['m'][0][1]='wrong-literal'
            check=oracle('verify_factory',item['compiled'],item['generation'],item['depth'],bad,factory,dict(ORACLE_LIMITS))
            need(check['status']=='REJECTED','MUTATED_FACTORY');mutants.append(dict(label=label,model=bad,independent=check))
        for label,kind in [('state-float-total','float-total'),('state-omitted-domain','omit-domain')]:
            bad=clone(lane['result']['entry_state'])
            if kind=='float-total':bad['totals'][0][1]=1.0
            else:bad['domains'][0][1].pop()
            check=oracle('verify_state',item['compiled'],item['depth'],lane['model'],bad,dict(ORACLE_LIMITS))
            need(check['status']=='REJECTED','MUTATED_GRAPH');mutants.append(dict(label=label,state=bad,independent=check))
        entry=directs[1]
        for label,kind in [('query-numeric-complete','numeric-complete'),('query-omitted-contact','omit-contact')]:
            bad=clone(entry['modes'][0]['reply'])
            if kind=='numeric-complete':bad['complete']=1
            else:
                need(bad['placements'],'QUERY_CONTACT_AVAILABLE');bad['placements'].pop();bad['certificate']['compatible_count']=len(bad['placements'])
            check=oracle('verify_query',binary['compiled'],binary['depth'],entry['query'],bad,dict(ORACLE_LIMITS))
            need(check['status']=='REJECTED','MUTATED_QUERY');mutants.append(dict(label=label,query=entry['query'],reply=bad,independent=check))
        dec=call('history_provider','decode',modules['adapter_indexed'],item['compiled'],item['depth'],lane['result']['selected'],dict(FACTORY_LIMITS,max_proof_lines=0))
        need(dec['status']=='UNKNOWN' and dec['proof'] is None,'DECODE_REFUSAL');mutants.append(dict(label='decoder-zero-lines',result=dec))
        check=oracle('enumerate_inventory',item['compiled'],item['depth'],dict(ORACLE_LIMITS,max_inventory=0))
        need(check['status']=='UNKNOWN' and check['value'] is None,'ENUMERATION_REFUSAL');mutants.append(dict(label='oracle-zero-inventory',independent=check))
        for mode in ('scan','indexed'):
            mo,pr,receipt=call('history_provider','make_provider',modules['adapter_indexed'],item['compiled'],item['generation'],item['depth'],dict(FACTORY_LIMITS,max_work=0),mode=mode)
            need(mo is None and pr is None and receipt['status']=='UNKNOWN' and receipt['value'] is None,'FACTORY_REFUSAL');mutants.append(dict(label='factory-zero-'+mode,receipt=receipt))
        out('data-mutations-and-owned-factory-refusals',dict(controls=mutants))
        tails=[('nodes-zero',dict(ENGINE_LIMITS,max_nodes=0),None,None,None),('work-one',dict(ENGINE_LIMITS,max_work=1),None,None,None),('candidate-one',dict(ENGINE_LIMITS,max_candidates=1),None,None,None),('sticky-provider-refusal',dict(ENGINE_LIMITS),'STICKY',None,None),('bad-context-hash',dict(ENGINE_LIMITS),'BAD-HASH',None,'InventoryError'),('foreign-provider',dict(ENGINE_LIMITS),'FOREIGN',None,'Foreign'),('foreign-audit',dict(ENGINE_LIMITS),None,'FOREIGN','Foreign'),('foreign-order',dict(ENGINE_LIMITS),None,None,'Foreign')]
        for label,limits,pm,am,error in tails:
            current.clear();current['stage']='tail-'+label;p=Captured(item['providers']['HISTORY_INDEXED'],item['compiled'],item['depth'],oracle,pm);counts['tail_solves']+=1
            def order(request,charge):raise Foreign('order')
            try:
                actual=run(item['compiled'],item['depth'],item['inv']['certified_model'],item['inv']['placements'],p,True,limits,am,order if label=='foreign-order' else None,False)
            except Exception as e:
                expected=Foreign if error=='Foreign' else modules['engine_indexed'].InventoryError
                if error is None or not isinstance(e,expected):raise
                actual=dict(exception=dict(type=type(e).__name__,message=str(e)),observations=clone(current.get('observations',[])),query_captures=clone(p.records),post_throw_state=None)
                counts['captured_queries']+=len(p.records)
            else:need(error is None and actual['result']['status']=='UNKNOWN' and actual['result']['certificate'] is None,'OWNED_REFUSAL_UNKNOWN')
            out('tail-'+label,dict(limits=limits,actual=actual))
        need(all(counts[k]==n for k,n in dict(fixtures=8,normal_solves=32,tail_solves=8,host_checks=24,direct_queries=32,describes=84,provider_snapshots=16,records=18).items()),'CLOSED_CENSUS')
        return dict(schema='HN-independent-qualification-result-v1',version=VERSION,status='COMPLETE',counts=counts,calls=calls,seconds=time.perf_counter()-started,direct_charged_work=direct_work,
                    scope='Fresh exact tiny reference; no fresh C1, learned marking, RL, full Y-generation or main benchmark claim.')
    except Exception as e:
        emit('incomplete-qualification',dict(status='UNADMITTED',actual=clone(current),exception=dict(type=type(e).__name__,message=str(e)),native_certificates=[]))
        raise
