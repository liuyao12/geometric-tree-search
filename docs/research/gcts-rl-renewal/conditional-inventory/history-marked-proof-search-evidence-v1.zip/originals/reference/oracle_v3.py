"""Independent history-normal-form reference; no project imports or file I/O.

Structural factory/certificate audits work on the main catalogue. Exhaustive
inventory, state, query and tree checks deliberately have a tiny finite scope.
The logical kernel remains separate. Nothing executes at import time.
"""
import hashlib
import itertools
import json
import math
import time

VERSION = 'HN-INDEPENDENT-REFERENCE-20261102-v3'
HISTORY_VERSION = 'HN-HISTORY-PATH-NORMAL-FORM-v1'
TAG = 'HN-history-v1'
PAIR_TAG = 'HN-ancestor-pair-v1'
HISTORY_SCOPE = ('Explicit finite history path-normal-form marking over the audited closed global producer inventory. '
                 'Root-reachable only; bounded proof existence is preserved, not every proof/tiling or primitive-cost bound. '
                 'No learned failure marking, rank oracle, RL or runtime result.')


class Invalid(ValueError):
    pass


class Refusal(Exception):
    pass


def need(test, reason):
    if not test:
        raise Invalid(reason)


def text(value):
    return json.dumps(value, ensure_ascii=True, sort_keys=True, separators=(',', ':'), allow_nan=False)


def wire(value):
    return (text(value) + '\n').encode('ascii')


def same(a, b):
    return wire(a) == wire(b)


def sha(value):
    return hashlib.sha256(wire(value)).hexdigest()


class Meter:
    def __init__(self, limits):
        fields = {'wall_seconds', 'max_work', 'max_inventory', 'max_trees', 'max_depth', 'max_selected'}
        need(type(limits) is dict and set(limits) == fields, 'LIMIT_FIELDS')
        need(type(limits['wall_seconds']) in (int, float) and math.isfinite(limits['wall_seconds'])
             and 0 < limits['wall_seconds'] <= 60, 'WALL_LIMIT')
        for key in fields - {'wall_seconds'}:
            need(type(limits[key]) is int and 0 <= limits[key] <= 10**9, 'INTEGER_LIMIT')
        self.limits, self.started, self.work = dict(limits), time.perf_counter(), 0

    def tick(self, n=1):
        need(type(n) is int and n >= 0, 'CHARGE')
        if n > self.limits['max_work'] - self.work:
            raise Refusal('WORK_LIMIT')
        self.work += n
        if time.perf_counter() - self.started >= self.limits['wall_seconds']:
            raise Refusal('WALL_LIMIT')

    def copy(self, x, depth=0, active=None):
        self.tick()
        if depth > self.limits['max_depth']:
            raise Refusal('DEPTH_LIMIT')
        if x is None or type(x) is bool:
            return x
        if type(x) is str:
            self.tick(2 + 12 * len(x)); return x
        if type(x) is int:
            need(x.bit_length() <= 256, 'INTEGER_SIZE'); self.tick(3 + x.bit_length()); return x
        if type(x) is float:
            need(math.isfinite(x), 'FINITE_FLOAT'); self.tick(64); return x
        need(type(x) in (list, dict), 'NATIVE_JSON')
        active = set() if active is None else active
        need(id(x) not in active, 'JSON_CYCLE'); active.add(id(x))
        self.tick(2 + 2 * len(x))
        try:
            if type(x) is list:
                return [self.copy(v, depth + 1, active) for v in x]
            need(all(type(k) is str for k in x), 'NATIVE_KEYS')
            return {self.copy(k, depth + 1, active): self.copy(v, depth + 1, active) for k, v in x.items()}
        finally:
            active.remove(id(x))


def fields(value, names):
    need(type(value) is dict and set(value) == set(names), 'FIELDS')


def free_vars(f):
    def term(t):
        need(type(t) is list and t, 'TERM')
        if t[0] == 'var':
            need(len(t) == 2 and type(t[1]) is str, 'VAR'); return {t[1]}
        need(len(t) == 3 and t[0] == 'fun' and type(t[2]) is list, 'FUN')
        return set().union(*(term(x) for x in t[2]))
    need(type(f) is list and f, 'FORMULA')
    if f[0] == 'all':
        need(len(f) == 3 and type(f[1]) is str, 'ALL'); return free_vars(f[2]) - {f[1]}
    if f[0] in ('imp', 'and', 'or'):
        need(len(f) == 3, 'BINARY'); return free_vars(f[1]) | free_vars(f[2])
    if f[0] == 'not':
        need(len(f) == 2, 'NOT'); return free_vars(f[1])
    if f[0] == 'eq':
        need(len(f) == 3, 'EQ'); return term(f[1]) | term(f[2])
    if f[0] == 'pred':
        need(len(f) == 3 and type(f[2]) is list, 'PRED'); return set().union(*(term(t) for t in f[2]))
    need(f == ['bot'], 'CONNECTIVE'); return set()


def catalogue(compiled, depth, m):
    need(type(depth) is int and 0 <= depth <= 32, 'TREE_DEPTH')
    c = m.copy(compiled)
    fields(c, ('schema', 'version', 'theory', 'goal', 'goal_id', 'profile', 'logical_basis',
               'zero_instances', 'mp_index', 'gen_index', 'costs', 'scope'))
    need(c['schema'] == 'V-interned-Hilbert8-basis-v1' and c['version'] == 'V-INTERNED-FINITE-HILBERT8-v1', 'COMPILED')
    fields(c['logical_basis'], ('instantiation_terms','terms','variables','formulas','colors','templates','hole','stages'))
    fields(c['theory'], ('functions','predicates','axioms'))
    forms, colors = c['logical_basis']['formulas'], c['logical_basis']['colors']
    need(type(forms) is list and forms and type(colors) is list and len(forms) == len(colors), 'FORMULA_TABLE')
    need(colors == sorted(set(colors)) and colors == [text(f) for f in forms], 'LITERAL_COLORS')
    need(type(c['goal_id']) is int and 0 <= c['goal_id'] < len(forms) and same(forms[c['goal_id']], c['goal']), 'GOAL')
    for f in c['theory']['axioms'].values():
        m.tick(1 + len(text(f))); need(not free_vars(f), 'OPEN_THEORY')
    ids = {v: i for i, v in enumerate(colors)}
    mp, gen = [], []
    for i, f in enumerate(forms):
        m.tick(2 + len(colors[i])); free_vars(f)
        if f[0] == 'imp' and text(f[1]) in ids and text(f[2]) in ids:
            mp.append([i, ids[text(f[1])], ids[text(f[2])]])
        if f[0] == 'all' and text(f[2]) in ids:
            gen.append([i, ids[text(f[2])], f[1]])
    need(same(mp, c['mp_index']) and same(gen, c['gen_index']), 'COMPLETE_INDICES')
    defs = []
    for i, z in enumerate(c['zero_instances']):
        m.tick(); fields(z, ('id', 'rule', 'formula_id', 'line'))
        need(z['id'] == 'i' + str(i) and type(z['formula_id']) is int and 0 <= z['formula_id'] < len(forms), 'ZERO_ID')
        need(z['rule'] in ('axiom', 'instantiate', 'tautology', 'refl', 'eq_subst', 'distribute')
             and z['line']['rule'] == z['rule'] and same(z['line']['formula'], forms[z['formula_id']]), 'ZERO_BINDING')
        defs.append(dict(id=text(['zero', z['id']]), kind='ZERO', output=z['formula_id'], premises=[],
                         zero_id=z['id'], variable=None, native_rule=z['rule']))
    for head, a, out in mp:
        defs.append(dict(id=text(['mp', head, a, out]), kind='MP', output=out, premises=[a, head],
                         zero_id=None, variable=None, native_rule='mp'))
    for head, body, v in gen:
        defs.append(dict(id=text(['gen', head, body, v]), kind='GEN', output=head, premises=[body],
                         zero_id=None, variable=v, native_rule='generalize'))
    m.tick(1 + len(defs) * (1 + len(defs).bit_length()))
    if len(defs) > m.limits['max_inventory']:
        raise Refusal('INVENTORY_LIMIT')
    defs.sort(key=lambda d: d['id'])
    core = sha({k: v for k, v in c.items() if k not in ('costs', 'scope')})
    base = sha(dict(schema='Z-anchored-proof-inventory-identity-v1', version='Z-ANCHORED-PROOF-PRODUCER-v1',
                    compiled_core_sha256=core, depth=depth))
    identity = sha(dict(schema='HN-history-normal-form-inventory-v1', version=HISTORY_VERSION,
        compiled_core_sha256=core, depth=depth, history_point_tag=TAG,
        history_rule='SIZE_EQUALS_SITE_DEPTH_OUTPUT_ABSENT_CHILD_UNION',
        history_order='ASCENDING_LITERAL_FORMULA_ID', base_inventory_identity=base))
    cards = []
    for level in range(depth + 1):
        m.tick((level + 1) ** 2 * (len(forms).bit_length() + 1))
        v = math.comb(len(forms) - 1, level) if level < len(forms) else 0
        if v.bit_length() > 256:
            raise Refusal('HISTORY_COUNT_LIMIT')
        cards.append(v)
    m.tick(3 * len(defs) + 1)
    arities = [sum(len(d['premises']) == a for d in defs) for a in range(3)]
    maximum = 0
    for level in range(depth + 1):
        own = (arities[0] if level == depth else len(defs)) * cards[level]
        parent = sum(arities[1:]) * cards[level - 1] if level else 0
        maximum = max(maximum, own + parent)
        if (own + parent).bit_length() > 256:
            raise Refusal('HISTORY_COUNT_LIMIT')
    return dict(compiled=c, depth=depth, forms=forms, colors=colors, definitions=defs,
                by_id={d['id']: d for d in defs}, core=core, base_identity=base, identity=identity, cards=cards,
                max_incident_count=maximum)


def hp(site):
    return text([TAG, site])


def model(k):
    return dict(schema='Z-growing-point-model-v1', version=HISTORY_VERSION, capacity=2, roots=[''],
        seed=dict(t=[['', 1]], m=sorted([['', k['colors'][k['compiled']['goal_id']]], [hp(''), '[]']])),
        inventory=dict(kind='CERTIFIED_INCIDENT', identity=k['identity']))


def sites(depth):
    return [''.join(v) for n in range(depth + 1) for v in itertools.product('01', repeat=n)]


def row(k, site, d, history, m, mode='history'):
    m.tick(32 + 12 * (len(site) + len(d['id']) + len(history)))
    points = [site] + [site + str(i) for i in range(len(d['premises']))]
    marks = [[p, k['colors'][f]] for p, f in zip(points, [d['output']] + d['premises'])]
    if mode == 'history':
        marks += [[hp(p), text(history if i == 0 else sorted(history + [d['output']]))] for i, p in enumerate(points)]
    if mode == 'pair':
        marks += [[text([PAIR_TAG, site[:n], site, d['output']]), '1'] for n in range(len(site))]
        marks += [[text([PAIR_TAG, site, v, d['output']]), '0'] for v in sites(k['depth']) if v.startswith(site) and len(v) > len(site)]
    return dict(id=text([site, d['id'], history] if mode == 'history' else [site, d['id']]),
                t=sorted([[p, 1] for p in points]), m=sorted(marks))


def parse(k, cid, m):
    need(type(cid) is str and len(cid) <= 16384, 'CID'); m.tick(4 + 12 * len(cid))
    try:
        v = json.loads(cid)
    except (ValueError, RecursionError) as e:
        raise Invalid('CID_JSON') from e
    need(type(v) is list and len(v) == 3 and type(v[0]) is str and type(v[1]) is str and v[1] in k['by_id'], 'CID_SHAPE')
    s, did, h = v; d = k['by_id'][did]
    need(len(s) <= k['depth'] and all(c in '01' for c in s), 'SITE')
    need(type(h) is list and len(h) == len(s) and all(type(f) is int and 0 <= f < len(k['forms']) for f in h), 'HISTORY_TYPES')
    need(h == sorted(set(h)) and d['output'] not in h and text(v) == cid, 'HISTORY_CANONICAL')
    need(len(s) < k['depth'] or not d['premises'], 'BOUNDARY')
    return s, d, h


def reconstruct(k, selected, m, complete):
    need(type(selected) is list, 'SELECTED')
    if len(selected) > m.limits['max_selected']:
        raise Refusal('SELECTED_LIMIT')
    nodes = {}
    for cid in selected:
        s, d, h = parse(k, cid, m); need(s not in nodes, 'DUPLICATE_SITE'); nodes[s] = (cid, d, h)
    if complete or nodes:
        need('' in nodes and nodes[''][1]['output'] == k['compiled']['goal_id'], 'ROOT')
    for s, (cid, d, h) in nodes.items():
        m.tick(2 + len(s)); ancestors = []
        for n in range(len(s)):
            p, bit = s[:n], int(s[n]); need(p in nodes, 'ROOT_REACHABILITY')
            pd = nodes[p][1]; need(bit < len(pd['premises']), 'CHILD_ROLE'); ancestors.append(pd['output'])
        need(len(set(ancestors)) == len(ancestors) and h == sorted(ancestors), 'INDUCED_HISTORY')
        for i, f in enumerate(d['premises']):
            child = s + str(i)
            if complete:
                need(child in nodes, 'OPEN_PREMISE')
            if child in nodes:
                need(nodes[child][1]['output'] == f, 'PREMISE')
        if s:
            pd = nodes[s[:-1]][1]; need(pd['premises'][int(s[-1])] == d['output'], 'PARENT_BINDING')
    totals, marks = {'': 1}, {p: [v, 1] for p, v in model(k)['seed']['m']}
    placements, old, histories = [], [], []
    for s in sorted(nodes):
        cid, d, h = nodes[s]; r = row(k, s, d, h, m)
        placements.append(r); old.append(row(k, s, d, [], m, 'old')); histories.append([s, h])
        for p, n in r['t']:
            m.tick(); totals[p] = totals.get(p, 0) + n; need(totals[p] <= 2, 'OVERFILL')
        for p, v in r['m']:
            m.tick(2 + len(p) + len(v))
            if p in marks:
                need(marks[p][0] == v, 'MARK_CONFLICT'); marks[p][1] += 1
            else:
                marks[p] = [v, 1]
    if complete:
        need(all(n == 2 for n in totals.values()), 'INCOMPLETE')
    placements.sort(key=lambda x: x['id']); old.sort(key=lambda x: x['id'])
    cert = dict(capacity=2, roots=[''], seed=model(k)['seed'], placements=placements,
                totals=sorted([[p, n] for p, n in totals.items()]), marks=sorted([[p, v, n] for p, (v, n) in marks.items()]))
    projected = dict(cert, seed=dict(t=[['', 1]], m=[['', k['colors'][k['compiled']['goal_id']]]]), placements=old,
                     marks=[r for r in cert['marks'] if r[0] in totals])
    return dict(expected_certificate=cert, projected_selected=[r['id'] for r in old], projected_certificate=projected,
                histories=histories, identity=k['identity'], nodes=nodes, totals=totals, marks=marks)


def tiny(k):
    if len(k['forms']) > 8 or k['depth'] > 3 or len(k['definitions']) > 32:
        raise Refusal('TINY_SCOPE')


def inventory(k, m):
    tiny(k); ss = sites(k['depth']); m.tick(len(ss) * len(k['definitions']) + 1)
    old_count = sum(sum(len(s) < k['depth'] or not d['premises'] for d in k['definitions']) for s in ss)
    hist_count = sum(sum(len(s) < k['depth'] or not d['premises'] for d in k['definitions']) * k['cards'][len(s)] for s in ss)
    if hist_count + 2 * old_count > m.limits['max_inventory']:
        raise Refusal('INVENTORY_LIMIT')
    hist, old, pairs = [], [], []
    for s in ss:
        for d in k['definitions']:
            m.tick()
            if len(s) == k['depth'] and d['premises']:
                continue
            old.append(row(k, s, d, [], m, 'old')); pairs.append(row(k, s, d, [], m, 'pair'))
            for h in itertools.combinations([f for f in range(len(k['forms'])) if f != d['output']], len(s)):
                hist.append(row(k, s, d, list(h), m))
    for a in (hist, old, pairs):
        a.sort(key=lambda r: r['id'])
    need(len(hist) == hist_count and len(old) == old_count, 'ENUMERATION_COUNT')
    hm = model(k); he = dict(hm, inventory=dict(kind='EXPLICIT', placements=hist))
    om = dict(hm, version='HN-OLD-REFERENCE-v1', seed=dict(t=[['', 1]], m=[['', k['colors'][k['compiled']['goal_id']]]]),
              inventory=dict(kind='EXPLICIT', placements=old))
    pm = dict(om, version='HN-ANCESTOR-PAIR-REFERENCE-v1', inventory=dict(kind='EXPLICIT', placements=pairs))
    return dict(certified_model=hm, explicit_model=he, old_explicit_model=om, pair_explicit_model=pm,
                placements=hist, old_placements=old, pair_placements=pairs, definitions=k['definitions'],
                history_cardinalities=k['cards'], counts=dict(history=len(hist), old=len(old), pair=len(pairs), sites=len(ss)))


def compatible(r, totals, marks, m):
    m.tick(1 + len(r['t']) + len(r['m']))
    return all(totals.get(p, 0) + n <= 2 for p, n in r['t']) and all(p not in marks or marks[p] == v for p, v in r['m'])


def query_check(k, query, reply, m):
    q, actual = m.copy(query), m.copy(reply)
    fields(q, ('schema', 'inventory_identity', 'point', 'capacity', 'totals', 'marks'))
    need(q['schema'] == 'IP-current-tm-incident-query-v1' and q['inventory_identity'] == k['identity'] and type(q['capacity']) is int and q['capacity'] == 2, 'QUERY_BINDING')
    p = q['point']; need(type(p) is str and len(p) <= k['depth'] and all(x in '01' for x in p), 'QUERY_SITE')
    for key in ('totals', 'marks'):
        a = q[key]; need(type(a) is list and all(type(r) is list and len(r) == 2 and type(r[0]) is str for r in a), 'QUERY_ROWS')
        need([r[0] for r in a] == sorted(set(r[0] for r in a)), 'QUERY_ORDER')
        need(all((type(v) is int and 0 <= v <= 2) if key == 'totals' else type(v) is str for _, v in a), 'QUERY_VALUES')
    total, marks = dict(q['totals']), dict(q['marks']); potential, found = [], []
    for r in inventory(k, m)['placements']:
        m.tick()
        if any(x == p for x, n in r['t']):
            potential.append(r)
            if compatible(r, total, marks, m):
                found.append(r)
    expected = dict(point=p, context_sha256=sha(q), complete=True, placements=found,
        certificate=dict(scope='COMPLETE_CURRENT_TM_COMPATIBLE_INCIDENT_SET', potential_count=len(potential), compatible_count=len(found)))
    need(same(actual, expected), 'QUERY_COMPLETE_SET')
    return dict(expected_reply=expected, potential_count=len(potential), compatible_count=len(found), query_sha256=sha(q))


def state_check(k, model_value, snapshot, m):
    inv = inventory(k, m); s = m.copy(snapshot); model_value = m.copy(model_value)
    need(same(model_value, inv['certified_model']) or same(model_value, inv['explicit_model']), 'STATE_MODEL')
    fields(s, ('Q', 'totals', 'selected', 'marks', 'excluded', 'eligible', 'domains', 'forward', 'reverse', 'placements', 'loaded', 'dependencies', 'edge_count'))
    selected = []
    for cid, gen in s['selected']:
        site, _, _ = parse(k, cid, m); need(type(gen) is int and gen == len(site) + 1, 'TILE_GENERATION'); selected.append(cid)
    need(selected == sorted(set(selected)), 'SELECTED_ORDER')
    r = reconstruct(k, selected, m, False); total, mark_refs = r['totals'], r['marks']; marks = {p: v[0] for p, v in mark_refs.items()}
    need(same(s['Q'], [[p, len(p)] for p in sorted(total)]) and same(s['totals'], sorted([[p, n] for p, n in total.items()]))
         and same(s['marks'], sorted([[p, v, n] for p, (v, n) in mark_refs.items()])), 'POINT_VALUES')
    full, reg = {v['id']: v for v in inv['placements']}, {}
    for v in s['placements']:
        need(type(v) is dict and v.get('id') in full and v['id'] not in reg and same(v, full[v['id']]), 'REGISTERED_ROW'); reg[v['id']] = v
    need(list(reg) == sorted(reg) and all(v in reg for v in selected), 'REGISTRY')
    banned = s['excluded']; need(banned == sorted(set(banned)) and all(v in reg and v not in selected for v in banned), 'EXCLUSIONS')
    need(s['loaded'] == sorted(set(s['loaded'])) and all(p in total for p in s['loaded']), 'LOADED')
    eligible = sorted(cid for cid, v in reg.items() if cid not in selected and cid not in banned and compatible(v, total, marks, m))
    need(same(s['eligible'], eligible), 'ELIGIBILITY')
    deps = {'t': {}, 'm': {}}
    for cid, v in reg.items():
        for key in ('t', 'm'):
            for p, value in v[key]:
                deps[key].setdefault(p, []).append(cid)
    need(same(s['dependencies'], {key: [[p, sorted(cids)] for p, cids in sorted(tab.items())] for key, tab in deps.items()}), 'DEPENDENCIES')
    frontier = sorted(p for p, n in total.items() if n < 2); need(all(p in s['loaded'] for p in frontier), 'FRONTIER_NOT_LOADED')
    domains, forward, reverse = [], [], {}
    for p in frontier:
        ids = []
        for v in inv['placements']:
            if any(x == p for x, _ in v['t']) and v['id'] not in selected and v['id'] not in banned and compatible(v, total, marks, m):
                need(v['id'] in reg, 'HIDDEN_LEGAL_CONTACT'); ids.append(v['id'])
        domains.append([p, ids])
        for cid in ids:
            forward.append([p, cid, 1]); reverse.setdefault(cid, []).append([p, 1])
    for p in s['loaded']:
        for v in inv['placements']:
            if any(x == p for x, _ in v['t']) and compatible(v, total, marks, m):
                need(v['id'] in reg, 'LOADED_COMPATIBLE_OMISSION')
    need(same(s['domains'], domains) and same(s['forward'], forward) and same(s['reverse'], [[cid, ps] for cid, ps in sorted(reverse.items())])
         and type(s['edge_count']) is int and s['edge_count'] == len(forward), 'COMPLETE_GRAPH')
    return dict(state_sha256=sha(s), frontier_points=len(frontier), registered_candidates=len(reg), edge_count=len(forward), full_inventory_candidates=len(full))


def size(t):
    return 1 + sum(size(c) for c in t[1])


def height(t):
    return 0 if not t[1] else 1 + max(height(c) for c in t[1])


def tree_ids(k, t, m, mode):
    result = []
    def walk(t, s, h):
        d = k['by_id'][t[0]]; m.tick(2 + len(s))
        result.append(row(k, s, d, sorted(h), m, mode)['id'])
        for i, c in enumerate(t[1]):
            walk(c, s + str(i), h + [d['output']])
    walk(t, '', []); return sorted(result)


def is_normal(k, t, h=()):
    f = k['by_id'][t[0]]['output']; return f not in h and all(is_normal(k, c, h + (f,)) for c in t[1])


def compress(k, t, m):
    def find(node, path=(), seen=()):
        m.tick(); f = k['by_id'][node[0]]['output']
        for p, out in seen:
            if out == f:
                return p, node
        for i, c in enumerate(node[1]):
            answer = find(c, path + (i,), seen + ((path, f),))
            if answer is not None:
                return answer
    def replace(node, path, new):
        if not path:
            return new
        cs = list(node[1]); cs[path[0]] = replace(cs[path[0]], path[1:], new); return node[0], tuple(cs)
    steps = 0
    while True:
        repeat = find(t)
        if repeat is None:
            return t, steps
        n = size(t); t = replace(t, *repeat); need(size(t) < n, 'STRICT_COMPRESSION'); steps += 1


def tree_check(k, m):
    inv = inventory(k, m); previous = {i: set() for i in range(len(k['forms']))}
    for level in range(k['depth'] + 1):
        current = {i: set() for i in previous}; count = 0
        for d in k['definitions']:
            m.tick()
            if level == 0 and d['premises']:
                continue
            for cs in itertools.product(*(previous[f] for f in d['premises'])):
                m.tick(2 + len(cs)); t = d['id'], tuple(cs)
                if t in current[d['output']]:
                    continue
                if count >= m.limits['max_trees']:
                    raise Refusal('TREE_LIMIT')
                if size(t) > m.limits['max_selected']:
                    raise Refusal('SELECTED_LIMIT')
                current[d['output']].add(t); count += 1
        previous = current
    ts = sorted(previous[k['compiled']['goal_id']], key=lambda t: text(tree_ids(k, t, m, 'old')))
    old, hist, pairs, normalizations = [], [], [], []
    full = {r['id'] for r in inv['placements']}
    for t in ts:
        ids = tree_ids(k, t, m, 'old'); old.append(ids)
        total, marks = {'': 1}, {'': k['colors'][k['compiled']['goal_id']]}; legal = True
        for cid in ids:
            site, did = json.loads(cid); rr = row(k, site, k['by_id'][did], [], m, 'pair')
            if not compatible(rr, total, marks, m):
                legal = False; break
            for p, n in rr['t']:
                total[p] = total.get(p, 0) + n
            marks.update(rr['m'])
        need(legal == is_normal(k, t), 'PAIR_NORMAL_FORM')
        if legal:
            pairs.append(ids); hids = tree_ids(k, t, m, 'history')
            need(all(cid in full for cid in hids), 'STATIC_HISTORY_MEMBERSHIP'); reconstruct(k, hids, m, True); hist.append(hids)
    hist.sort(key=text); pairs.sort(key=text); hist_by_key = {text(v): v for v in hist}
    for t, ids in zip(ts, old):
        normal, steps = compress(k, t, m); hids = tree_ids(k, normal, m, 'history')
        need(text(hids) in hist_by_key and height(normal) <= height(t), 'NORMALIZATION_MEMBERSHIP')
        normalizations.append(dict(old_sha256=sha(ids), normal_sha256=sha(hids), steps=steps,
            old_nodes=size(t), normal_nodes=size(normal), old_height=height(t), normal_height=height(normal)))
    projected = sorted([sorted(text(json.loads(cid)[:2]) for cid in ids) for ids in hist], key=text)
    need(projected == pairs and bool(old) == bool(hist), 'EXISTENCE_EQUIVALENCE')
    return dict(old_trees=old, history_trees=hist, pair_trees=pairs,
        old_tree_hashes=[sha(v) for v in old], history_tree_hashes=[sha(v) for v in hist], pair_tree_hashes=[sha(v) for v in pairs],
        normalizations=normalizations, counts=dict(old=len(old), history=len(hist), pair=len(pairs), removed=len(old)-len(hist), normalizations=len(old)),
        existence_equivalent=True, all_old_normalizations_in_history=True, history_pair_sets_equal=True,
        scope='COMPLETE_DECLARED_TINY_BOUNDED_ORDERED_TREES_ONLY')


def run(limits, operation, status='VERIFIED'):
    m = None
    try:
        m = Meter(limits); value = operation(m); m.copy(value); m.tick(); reason = None
    except Refusal as e:
        status, reason, value = 'UNKNOWN', str(e), None
    except Invalid as e:
        status, reason, value = 'REJECTED', str(e), None
    return dict(schema='HN-independent-history-audit-v1', version=VERSION, status=status, reason=reason, value=value,
        costs=dict(work=0 if m is None else m.work, seconds=0.0 if m is None else time.perf_counter()-m.started),
        scope='Independent structural audit; fixed closed rooted producers. No logical-kernel, main witness-search or all-proof preservation claim.')


def verify_factory(compiled, generation, depth, supplied_model, receipt, limits):
    def check(m):
        k = catalogue(compiled, depth, m); g, r = m.copy(generation), m.copy(receipt); actual_model = m.copy(supplied_model)
        fields(g, ('schema','version','profile','compiled_core_sha256','core_stages','core_assertions','goal_receptors','bridge_premises','scope'))
        need(g['schema'] == 'Y-goal-receptor-universe-v1' and g['version'] == 'Y-GOAL-RECEPTOR-FAMILY-v1'
             and g['compiled_core_sha256'] == k['core'] and same(g['profile'], k['compiled']['profile']) and g['scope'] == k['compiled']['scope'], 'GENERATION')
        fields(r, ('schema', 'version', 'status', 'reason', 'value', 'costs'))
        if r['status'] == 'UNKNOWN':
            need(actual_model is None and r['value'] is None, 'PARTIAL_UNKNOWN'); raise Refusal('FACTORY_UNKNOWN')
        expected = dict(depth=depth, compiled_core_sha256=k['core'], identity=k['identity'], base_identity=k['base_identity'],
            definitions=k['definitions'], formula_count=len(k['forms']), potential_sites=2**(depth+1)-1,
            history_point_tag=TAG, history_cardinalities=k['cards'], scope=HISTORY_SCOPE)
        need(r['schema'] == 'HN-history-provider-result-v1' and r['version'] == HISTORY_VERSION and r['status'] == 'COMPLETE'
             and r['reason'] is None and same(r['value'], expected) and same(actual_model, model(k)), 'FACTORY_EXACT_MODEL')
        return dict(expected_model=model(k), expected_factory_value=expected, identity=k['identity'], base_identity=k['base_identity'],
                    definitions=k['definitions'], history_cardinalities=k['cards'], max_incident_count=k['max_incident_count'])
    return run(limits, check)


def verify_certificate(compiled, depth, selected, certificate, limits):
    def check(m):
        k = catalogue(compiled, depth, m); r = reconstruct(k, m.copy(selected), m, True)
        need(same(m.copy(certificate), r['expected_certificate']), 'EXACT_CERTIFICATE')
        return {key: r[key] for key in ('expected_certificate', 'projected_selected', 'projected_certificate', 'histories', 'identity')}
    return run(limits, check)


def enumerate_inventory(compiled, depth, limits):
    return run(limits, lambda m: inventory(catalogue(compiled, depth, m), m), 'COMPLETE')


def compare_bounded_trees(compiled, depth, limits):
    return run(limits, lambda m: tree_check(catalogue(compiled, depth, m), m), 'COMPLETE')


def verify_query(compiled, depth, query, reply, limits):
    return run(limits, lambda m: query_check(catalogue(compiled, depth, m), query, reply, m))


def verify_state(compiled, depth, supplied_model, snapshot, limits):
    return run(limits, lambda m: state_check(catalogue(compiled, depth, m), supplied_model, snapshot, m))
