"""Saved-data-only verification; no scientific module imports or replay."""
import gzip
import hashlib
import itertools
import json
from pathlib import Path

ROOT=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-history-normal-form-20261102-v1')


def wire(x):return (json.dumps(x,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')
def txt(x):return wire(x)[:-1].decode('ascii')
def sha(x):return hashlib.sha256(wire(x)).hexdigest()
def eq(a,b):return wire(a)==wire(b)
def require(ok,why):
    if not ok:raise AssertionError(why)
def pin(p):
    r=p.read_bytes();return dict(path=str(p),bytes=len(r),sha256=hashlib.sha256(r).hexdigest())
def stored(ref):
    p=Path(ref['path']);r=p.read_bytes();require(len(r)==ref['bytes'] and hashlib.sha256(r).hexdigest()==ref['sha256'],'stored raw hash');return r
def unpack(ref):
    r=stored(ref['stored']);r=gzip.decompress(r) if ref['encoding']=='gzip-json' else r
    require(len(r)==ref['raw_bytes'] and hashlib.sha256(r).hexdigest()==ref['raw_sha256'],'complete decompressed hash');return json.loads(r)
def hp(s):return txt(['HN-history-v1',s])
def make_defs(c):
    ds={}
    for z in c['zero_instances']:ds[txt(['zero',z['id']])]=(z['formula_id'],[],z['line'],None)
    for head,a,out in c['mp_index']:ds[txt(['mp',head,a,out])]=(out,[a,head],None,None)
    for head,body,v in c['gen_index']:ds[txt(['gen',head,body,v])]=(head,[body],None,v)
    return ds
def static_world(c,d,defs,mode):
    colors=c['logical_basis']['colors'];f=len(colors);ss=[''.join(x) for n in range(d+1) for x in itertools.product('01',repeat=n)];rows={}
    for s in ss:
        for did,(out,pre,zero,var) in defs.items():
            if len(s)==d and pre:continue
            histories=itertools.combinations([i for i in range(f) if i!=out],len(s)) if mode=='history' else [()]
            for hh in histories:
                h=list(hh);pts=[s]+[s+str(i) for i in range(len(pre))];ms=[[p,colors[i]] for p,i in zip(pts,[out]+pre)]
                if mode=='history':ms += [[hp(p),txt(h if j==0 else sorted(h+[out]))] for j,p in enumerate(pts)]
                elif mode=='pair':ms += [[txt(['HN-ancestor-pair-v1',s[:n],s,out]),'1'] for n in range(len(s))]+[[txt(['HN-ancestor-pair-v1',s,v,out]),'0'] for v in ss if len(v)>len(s) and v.startswith(s)]
                cid=txt([s,did,h] if mode=='history' else [s,did]);rows[cid]=dict(id=cid,t=sorted([[p,1] for p in pts]),m=sorted(ms))
    return dict(sorted(rows.items()))
def compatible(r,t,m):return all(t.get(p,0)+n<=2 for p,n in r['t']) and all(p not in m or m[p]==v for p,v in r['m'])
def selection(c,defs,world,selected,mode,complete=True):
    require(selected==sorted(set(selected)),'sorted distinct selectedIDs');nodes={}
    for cid in selected:
        require(cid in world,'selected static member');raw=json.loads(cid);s,did=raw[:2];require(s not in nodes,'one placement/site');nodes[s]=(cid,did,raw[2] if mode=='history' else None)
    if nodes or complete:require('' in nodes and defs[nodes[''][1]][0]==c['goal_id'],'root goal')
    for s,(cid,did,h) in nodes.items():
        out,pre,zero,var=defs[did]
        for n in range(len(s)):
            require(s[:n] in nodes,'root-connected selected tree');require(int(s[n])<len(defs[nodes[s[:n]][1]][1]),'declared parent bit')
        if s:require(defs[nodes[s[:-1]][1]][1][int(s[-1])]==out,'parent output binding')
        for i,fid in enumerate(pre):
            child=s+str(i)
            if complete:require(child in nodes,'closed premise')
            if child in nodes:require(defs[nodes[child][1]][0]==fid,'child formula')
        if mode=='history':
            ancestors=[defs[nodes[s[:n]][1]][0] for n in range(len(s))]
            require(len(set(ancestors))==len(ancestors) and eq(h,sorted(ancestors)) and out not in h,'literal induced history')
    return nodes
def expected_proof(c,defs,nodes):
    lines=[];indices={}
    def visit(s):
        cid,did,h=nodes[s];out,pre,zero,var=defs[did]
        for i in range(len(pre)):visit(s+str(i))
        if zero is not None:line=zero
        elif var is not None:line=dict(rule='generalize',formula=c['logical_basis']['formulas'][out],source=indices[s+'0'],variable=var)
        else:line=dict(rule='mp',formula=c['logical_basis']['formulas'][out],antecedent=indices[s+'0'],implication=indices[s+'1'])
        indices[s]=len(lines);lines.append(line)
    visit('');return lines,indices
def state_check(c,defs,model,world,state,mode):
    chosen=[cid for cid,g in state['selected']];nodes=selection(c,defs,world,chosen,mode,False)
    t=dict(model['seed']['t']);m={p:[v,1] for p,v in model['seed']['m']}
    for cid,g in state['selected']:
        require(type(g)is int and g==len(json.loads(cid)[0])+1,'tile generation')
        for p,n in world[cid]['t']:t[p]=t.get(p,0)+n
        for p,v in world[cid]['m']:
            if p in m:require(m[p][0]==v,'selected marking agreement');m[p][1]+=1
            else:m[p]=[v,1]
    require(eq(state['Q'],[[p,len(p)] for p in sorted(t)]) and eq(state['totals'],sorted([[p,n] for p,n in t.items()])) and eq(state['marks'],sorted([[p,v,n] for p,(v,n) in m.items()])),'actual T/M/Q/refcounts')
    marks={p:v[0] for p,v in m.items()};reg={}
    for r in state['placements']:require(r['id'] in world and r['id'] not in reg and eq(r,world[r['id']]),'registered full payload');reg[r['id']]=r
    require(list(reg)==sorted(reg) and set(chosen)<=set(reg),'registered selected/order');bans=state['excluded'];require(bans==sorted(set(bans)) and set(bans)<=set(reg)-set(chosen),'branch exclusions')
    eligible=sorted(cid for cid,r in reg.items() if cid not in chosen and cid not in bans and compatible(r,t,marks))
    require(eq(state['eligible'],eligible),'actual eligibility')
    deps={key:{} for key in ['t','m']}
    for cid,r in reg.items():
        for key in deps:
            for p,v in r[key]:deps[key].setdefault(p,[]).append(cid)
    require(eq(state['dependencies'],{k:[[p,sorted(ids)] for p,ids in sorted(tab.items())] for k,tab in deps.items()}),'all t/m dependencies including mark-only')
    require(state['loaded']==sorted(set(state['loaded'])) and set(state['loaded'])<=set(t),'loaded point set')
    domains=[];forward=[];reverse={};frontier=sorted(p for p,n in t.items() if n<2)
    for p in frontier:
        require(p in state['loaded'],'frontier exhausted')
        ids=[cid for cid,r in world.items() if any(x==p for x,n in r['t']) and cid not in chosen and cid not in bans and compatible(r,t,marks)]
        require(set(ids)<=set(reg),'no invisible legal candidate');domains.append([p,ids])
        for cid in ids:forward.append([p,cid,1]);reverse.setdefault(cid,[]).append([p,1])
    for p in state['loaded']:
        require(all(cid in reg for cid,r in world.items() if any(x==p for x,n in r['t']) and compatible(r,t,marks)),'loaded compatible completeness')
    require(eq(state['domains'],domains) and eq(state['forward'],forward) and eq(state['reverse'],[[cid,ps] for cid,ps in sorted(reverse.items())]) and type(state['edge_count'])is int and state['edge_count']==len(forward),'full weighted frontier graph')
def query_check(world,q,r):
    t,m=dict(q['totals']),dict(q['marks']);possible=[v for v in world.values() if any(p==q['point'] for p,n in v['t'])];good=[v for v in possible if compatible(v,t,m)]
    expected=dict(point=q['point'],context_sha256=sha(q),complete=True,placements=good,certificate=dict(scope='COMPLETE_CURRENT_TM_COMPATIBLE_INCIDENT_SET',potential_count=len(possible),compatible_count=len(good)))
    require(eq(r,expected),'actual complete query set/context/counts')
def stream(rows,e):
    require(len(rows)==e['retained']==e['total'],'complete tiny stream');require(hashlib.sha256(b''.join(wire(r) for r in rows)).hexdigest()==e['sha256'],'complete tiny stream hash')
def event_check(event,state,before,seen,world):
    k,p,cid=event['kind'],event['point'],event['candidate'];ds,gs=dict(state['domains']),dict(state['Q']);dead=[p for p in ds if not ds[p]];forced=[p for p in ds if len(ds[p])==1]
    if k=='DEAD':require(p in dead,'dead priority')
    elif k=='FORCED':require(not dead and p==min(forced,key=lambda p:(gs[p],p)) and cid==ds[p][0],'global forced priority')
    elif k=='BRANCH':require(not dead and not forced and p==min(ds,key=lambda p:(gs[p],len(ds[p]),p)) and event['data']['legal']==event['data']['order']==ds[p],'generation-first branch')
    elif k=='PLACED':
        e,s=before['event'],before['state'];want=e['candidate'] if e['kind']=='FORCED' else e['data']['order'][0];require(cid==want,'selected scheduler candidate')
        g=1+min(dict(s['Q'])[p] for p,n in world[cid]['t'] if p in dict(s['Q']));require(event['data']['generation']==g and eq(dict(state['selected']),dict(s['selected'])|{cid:g}),'placement generation/delta')
    elif k=='EXCLUDE':
        candidates=[v['state'] for v in seen if v['event']['kind']=='BRANCH' and v['event']['data']['order'][0]==cid and v['state']['selected']==state['selected']];require(candidates,'failed-child parent witness');old=candidates[-1]
        require(all(eq(old[key],state[key]) for key in ['Q','totals','marks','selected','placements','loaded']) and state['excluded']==sorted(set(old['excluded'])|{cid}),'whole failed-child restore and contextual ban')
    elif k=='SOLUTION':require(not ds,'all active deficits filled')
    else:require(k in ['READY','EXHAUSTED'],'known event')


def tree_shape(nodes,defs,s=''):
    cid,did,h=nodes[s]
    return [did,[tree_shape(nodes,defs,s+str(i)) for i in range(len(defs[did][1]))]]
def normalize_stored(t,defs):
    def find(node,path=(),seen=()):
        f=defs[node[0]][0]
        for p,out in seen:
            if out==f:return p,node
        for i,c in enumerate(node[1]):
            r=find(c,path+(i,),seen+((path,f),))
            if r is not None:return r
    def replace(node,path,new):
        if not path:return new
        cs=list(node[1]);cs[path[0]]=replace(cs[path[0]],path[1:],new);return [node[0],cs]
    steps=0
    while True:
        r=find(t)
        if r is None:return t,steps
        t=replace(t,*r);steps+=1

def descriptor(world,point,identity,formula_count):
    groups={}
    for rr in world.values():
        if any(p==point for p,n in rr['t']):
            site,did,h=json.loads(rr['id']);groups.setdefault(txt(['HN-history-arity-v1',site,len(rr['t'])-1]),[]).append(rr)
    fam=[];td=set();md=set()
    for key,rows in sorted(groups.items()):
        _,anchor,arity=json.loads(key);defs=sorted({json.loads(r['id'])[1] for r in rows});tp=sorted({p for r in rows for p,n in r['t']});mp=sorted({p for r in rows for p,v in r['m']});n=len(rows)//len(defs)
        fam.append(dict(id=key,anchor=anchor,arity=arity,definition_ids=defs,t_points=tp,m_points=mp,history_size=len(anchor),histories_per_definition=n,potential_count=len(rows)));td.update(tp);md.update(mp)
    return dict(point=point,inventory_identity=identity,complete=True,families=fam,dependencies=dict(t=sorted(td),m=sorted(md)),potential_count=sum(map(len,groups.values())),scope='COMPLETE_STATIC_HISTORY_OWN_AND_ALL_PARENT_ALIGNMENT_FAMILIES')

def main():
    observer_path=ROOT/'actual/qualification-001/observer-result.json';o=json.loads(observer_path.read_bytes());require(o['status']=='COMPLETE' and o['returncode']==0 and o['both_streams_EOF'] and o['group_gone'],'original complete observer')
    w=unpack(o['worker_terminal']['result']);records={a['name']:unpack(a) for a in w['artifacts']};stats=dict(fixtures=0,normal_solves=0,positive_occurrences=0,negative_occurrences=0,observed_images=0,returned_images=0,query_captures=0,direct_queries=0,static_describes=0,mutants=0,tails=0,coarse_lines=0)
    cases=[];world_by_case={};case_by_name={};tree_totals=dict(old=0,history=0,pair=0,removed=0,normalizations=0)
    for name,record in records.items():
        if not name.startswith('case-'):continue
        c,d=record['compiled'],record['case']['depth'];defs=make_defs(c);worlds={mode:static_world(c,d,defs,mode) for mode in ['old','pair','history']};world_by_case[record['case']['id']]=worlds['history'];case_by_name[record['case']['id']]=record;stats['fixtures']+=1
        iv,comp=record['inventory']['value'],record['complete_tree_comparison']['value'];require(record['inventory']['status']==record['complete_tree_comparison']['status']=='COMPLETE','fresh full reference receipts')
        for mode,key in [('old','old_placements'),('pair','pair_placements'),('history','placements')]:require(eq(iv[key],list(worlds[mode].values())),'full independent static inventory reconstruction')
        for key in tree_totals:tree_totals[key]+=comp['counts'][key]
        trees={};nodes_for_tree={}
        for mode,label in [('old','old'),('pair','pair'),('history','history')]:
            xs=comp[label+'_trees'];require([txt(v) for v in xs]==sorted(set(txt(v) for v in xs)) and comp[label+'_tree_hashes']==[sha(v) for v in xs] and len(xs)==comp['counts'][label],'complete collection hash/count/order')
            trees[mode]={sha(v):v for v in xs}
            for selected in xs:
                nodes=selection(c,defs,worlds[mode],selected,mode);nodes_for_tree[sha(selected)]=nodes
                # Check actual pair literal agreement separately from path history.
                if mode=='pair':
                    t={'':1};m={'':c['logical_basis']['colors'][c['goal_id']]}
                    for cid in selected:
                        rr=worlds[mode][cid];require(compatible(rr,t,m),'pair markings agree on complete tree')
                        for p,n in rr['t']:t[p]=t.get(p,0)+n
                        m.update(rr['m'])
        require(bool(trees['old'])==bool(trees['history'])==bool(trees['pair']),'bounded existence')
        require(sorted([sorted(txt(json.loads(cid)[:2]) for cid in x) for x in comp['history_trees']],key=txt)==comp['pair_trees'],'complete normal/pair projection')
        require({r['old_sha256'] for r in comp['normalizations']}==set(trees['old']),'all old trees normalized')
        for r in comp['normalizations']:
            a,b=trees['old'][r['old_sha256']],trees['history'][r['normal_sha256']];old_shape=tree_shape(nodes_for_tree[r['old_sha256']],defs);new_shape=tree_shape(nodes_for_tree[r['normal_sha256']],defs);normalized,steps=normalize_stored(old_shape,defs);require(eq(normalized,new_shape) and steps==r['steps'],'actual same-output subtree compression');require(r['old_nodes']==len(a) and r['normal_nodes']==len(b)<=len(a) and r['old_height']==max(len(json.loads(cid)[0]) for cid in a) and r['normal_height']==max(len(json.loads(cid)[0]) for cid in b)<=r['old_height'],'normalization size/depth map')
        for lane,data in record['lanes'].items():
            mode='history' if lane.startswith('HISTORY') else 'old' if lane=='UNMARKED_EXPLICIT' else 'pair';world=worlds[mode];result=data['result'];stats['normal_solves']+=1
            require((result['status']=='SAT')==bool(trees[mode]) and result['status'] in ['SAT','UNSAT'],'actual result/exhaustive reference')
            require(eq(result['entry_state'],result['restored_state']),'whole exact entry restoration')
            for key in ['entry','final','restored']:
                s=result[key+'_state'];state_check(c,defs,data['model'],world,s,mode);require(result['state_hashes'][key]==sha(s),'original state hash retained');stats['returned_images']+=1
            stream(result['events'],result['event_extent']);stream(result['rollback_records'],result['rollback_extent']);require([v['event'] for v in data['observations']]==result['events'],'all original observations')
            for i,v in enumerate(data['observations']):state_check(c,defs,data['model'],world,v['state'],mode);event_check(v['event'],v['state'],None if i==0 else data['observations'][i-1],data['observations'][:i],world);stats['observed_images']+=1
            for cap in data['query_captures']:query_check(world,cap['query'],cap['reply']);require(cap['independent']['status']=='VERIFIED','runtime independent query receipt');stats['query_captures']+=1
            require(result['provider_evidence']['records']==[dict(query=v['query'],reply=v['reply']) for v in data['query_captures']],'native complete query records');stream(result['provider_evidence']['records'],result['provider_evidence'])
            if result['status']=='SAT':
                stats['positive_occurrences']+=1;expected_cert=dict(capacity=2,roots=[''],seed=data['model']['seed'],placements=[world[cid] for cid in result['selected']],totals=result['final_state']['totals'],marks=result['final_state']['marks']);require(eq(result['certificate'],expected_cert),'exact current point certificate linked to actual final state');require(result['selected'] in comp[mode+'_trees'],'actual complete selection membership');pos=data['positive'];nodes=selection(c,defs,world,result['selected'],mode);proof,indices=expected_proof(c,defs,nodes)
                require(eq(pos['proof'],proof) and pos['host_check']['status']=='VERIFIED' and pos['host_check']['checked_lines']==len(proof) and pos['independent_tree']['status']=='VERIFIED','actual proof/postorder/fresh check associations');stats['coarse_lines']+=len(proof)
                require(eq(pos['problem'],dict(theory=c['theory'],goal=c['goal'])) and eq(proof[-1]['formula'],c['goal']),'actual closed theory/target')
                if mode=='history':require(pos['history_certificate']['status']=='VERIFIED' and eq(pos['history_certificate']['value']['expected_certificate'],result['certificate']),'actual history certificate assurance')
            else:stats['negative_occurrences']+=1;require(result['certificate'] is None and not result['selected'],'finite negative no certificate')
        a,b=record['lanes']['HISTORY_SCAN'],record['lanes']['HISTORY_INDEXED'];require(eq(a['model'],b['model']) and all(eq(a['result'][k],b['result'][k]) for k in ['status','selected','certificate','events','event_extent']),'same model/full event stream across lookup modes')
        for desc in record['descriptions']:
            require(eq(desc['modes'][0]['actual'],desc['modes'][1]['actual']),'same static descriptors');stats['static_describes']+=2
            for r in desc['modes']:require(r['independent']['status']=='VERIFIED' and eq(r['actual'],descriptor(worlds['history'],desc['point'],record['lanes']['HISTORY_INDEXED']['model']['inventory']['identity'],len(c['logical_basis']['formulas']))),'complete independently reconstructed static descriptors')
        cases.append(dict(id=record['case']['id'],inventory_counts=iv['counts'],tree_counts=comp['counts'],statuses={k:v['result']['status'] for k,v in record['lanes'].items()}))
    for row in records['direct-complete-contexts']['queries']:
        world=world_by_case[row['case']]
        for mode in row['modes']:query_check(world,row['query'],mode['reply']);require(mode['independent']['status']=='VERIFIED','direct query receipt');stats['direct_queries']+=1
    mutants=[]
    for row in records['data-mutations-and-owned-factory-refusals']['controls']:
        receipt=row.get('independent',row.get('receipt',row.get('result')));require(receipt['status']==('UNKNOWN' if row['label'] in ['decoder-zero-lines','oracle-zero-inventory','factory-zero-scan','factory-zero-indexed'] else 'REJECTED'),'mutation/refusal actual classification');mutants.append(dict(label=row['label'],status=receipt['status']));stats['mutants']+=1
    case=case_by_name['zero-aliases-wrong-output'];c=case['compiled'];defs=make_defs(c);world=world_by_case[case['case']['id']];model=case['lanes']['HISTORY_INDEXED']['model'];tails=[]
    for name,data in records.items():
        if not name.startswith('tail-'):continue
        stats['tails']+=1;actual=data['actual']
        for i,v in enumerate(actual['observations']):state_check(c,defs,model,world,v['state'],'history');event_check(v['event'],v['state'],None if i==0 else actual['observations'][i-1],actual['observations'][:i],world);stats['observed_images']+=1
        for cap in actual['query_captures']:query_check(world,cap['query'],cap['reply']);stats['query_captures']+=1
        if 'result' in actual:
            result=actual['result'];require(result['status']=='UNKNOWN' and result['certificate'] is None and not result['selected'],'owned refusal remains unknown');require(result['final_state'] is None,'no interrupted final image')
            for key in ['entry','restored']:
                s=result[key+'_state']
                if s is not None:state_check(c,defs,model,world,s,'history');require(result['state_hashes'][key]==sha(s),'returned unknown state hash');stats['returned_images']+=1
            if result['entry_state'] is not None:require(eq(result['entry_state'],result['restored_state']),'unknown exact unwind')
            tails.append(dict(id=name,status='UNKNOWN',reason=result['reason']))
        else:
            want='InventoryError' if name=='tail-bad-context-hash' else 'Foreign';require(actual['exception']['type']==want and actual['post_throw_state'] is None,'checked/foreign exception no fabricated postthrow state');tails.append(dict(id=name,exception=actual['exception']))
    require(stats['fixtures']==8 and stats['normal_solves']==32 and stats['positive_occurrences']==24 and stats['negative_occurrences']==8 and stats['observed_images']==269 and stats['query_captures']==59 and stats['direct_queries']==32 and stats['static_describes']==84 and stats['mutants']==15 and stats['tails']==8,'actual closed census')
    support=dict(schema='HN-passive-qualification-math-support-v2',status='PASS',observer=pin(observer_path),worker=o['worker_terminal']['result'],stats=stats,tree_totals=tree_totals,cases=cases,mutants=mutants,tails=tails,
        scope='All saved static inventories independently reconstructed; every selected stored tree, graph, query, literal static descriptor, point certificate, proof/postorder and receipt association checked; each recorded old-to-normal map reproduced by same-output subtree compression of the given proof, without proof search. No scientific Source function, new proof search, kernel or solver replay. Collection completeness uses the reviewed finite enumerator Source plus its actual COMPLETE returns; this pass validates all supplied members/maps, not a second proof-search implementation.')
    p=ROOT/'review/qualification001-passive-math-support-v2.json';p.write_bytes(json.dumps(support,sort_keys=True,indent=2).encode()+b'\n')
    receipt=dict(schema='HN-passive-qualification-math-review-v2',status='PASS',observer=pin(observer_path),support=pin(p),stats=stats,tree_totals=tree_totals,blockers=[],scientific_replays=0,scope=support['scope'])
    z=ROOT/'review/qualification001-passive-math-review-v2.json';z.write_bytes(json.dumps(receipt,sort_keys=True,indent=2).encode()+b'\n');print(json.dumps(dict(review=pin(z),support=pin(p),stats=stats,tree_totals=tree_totals)))


if __name__=='__main__':main()
