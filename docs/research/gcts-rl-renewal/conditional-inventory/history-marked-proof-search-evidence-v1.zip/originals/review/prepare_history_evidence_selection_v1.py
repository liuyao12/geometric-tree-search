"""Select and hash a finite evidence cut. No packaging or scientific execution."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import stat

RUN = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-history-normal-form-20261102-v1')
REC = RUN.parent / 'gcts-history-recovery-20261102-v1/public-recovered-sources'
GROUPS = ('sources', 'inputs', 'qualification', 'main', 'report', 'qa', 'recovery_provenance')


def raw(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True, indent=2, allow_nan=False) + '\n').encode('ascii')


def read(path):
    path = Path(path)
    assert path.is_absolute() and path.resolve() == path
    assert all(not p.is_symlink() for p in (path, *path.parents))
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode) and before.st_nlink == 1 and before.st_size <= 67108864
    data = path.read_bytes()
    after = path.lstat()
    assert (before.st_dev, before.st_ino, before.st_mtime_ns, before.st_size) == (after.st_dev, after.st_ino, after.st_mtime_ns, after.st_size)
    assert len(data) == before.st_size
    return data


def pin(path):
    data = read(path)
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def load(ref):
    assert type(ref) is dict and set(ref) == {'path', 'bytes', 'sha256'}
    assert type(ref['bytes']) is int and pin(Path(ref['path'])) == ref
    return json.loads(read(ref['path']))


def create(path, data):
    with path.open('xb') as stream:
        assert stream.write(data) == len(data)
    assert read(path) == data


def main():
    selected = {}

    def add(path, category, expected=None):
        path = Path(path)
        assert category in GROUPS
        assert path.is_relative_to(RUN) or path.is_relative_to(REC)
        assert '.git' not in path.parts and '.codex' not in path.parts and path.suffix != '.zip'
        value = pin(path)
        if expected is not None:
            assert value == expected
        if path in selected:
            assert selected[path]['source_ref'] == value
            return
        name = ('originals/' + str(path.relative_to(RUN))) if path.is_relative_to(RUN) else ('recovery/public-recovered-sources/' + path.name)
        assert all(32 <= ord(c) <= 126 for c in name)
        selected[path] = {'name': name, 'category': category, 'source_ref': value, 'public_safe': True}

    plan_refs, observer_refs = [], []
    source_set = None
    for stem, category in (('qualification', 'qualification'), ('study', 'main')):
        path = RUN / ('root/' + stem + '-once-plan-001.json')
        plan_ref = pin(path)
        plan_refs.append(plan_ref)
        plan = load(plan_ref)
        assert plan['schema'] == 'AA-growing-proof-search-once-plan-v1' and len(plan['sources']) == 13
        if source_set is None:
            source_set = (plan['sources'], plan['bootstrap'], plan['python'])
        else:
            assert source_set == (plan['sources'], plan['bootstrap'], plan['python'])
        add(path, category, plan_ref)
        for ref in plan['sources'].values():
            add(ref['path'], 'sources', ref)
        add(plan['bootstrap']['path'], 'sources', plan['bootstrap'])
        for name, ref in plan['metadata'].items():
            target = ('inputs' if name == 'frozen_inputs' else 'qualification' if name in ('qualification_admission', 'qualified_custody_peer', 'qualified_math_peer') else category if name == 'design' else 'sources')
            add(ref['path'], target, ref)
        inputs = load(plan['metadata']['frozen_inputs'])['inputs']
        assert len(inputs) == len({item['name'] for item in inputs}) == 31
        for item in inputs:
            add(item['stored']['path'], 'inputs', item['stored'])
        actual = Path(plan['actual_dir'])
        observer_path = actual / 'observer-result.json'
        observer_ref = pin(observer_path)
        observer_refs.append(observer_ref)
        observed = load(observer_ref)
        assert observed['status'] == 'COMPLETE' and observed['returncode'] == 0
        assert observed['wait_confirmed'] and observed['both_streams_EOF'] and observed['group_gone']
        assert observed['failure'] is None and not observed['cleanup_errors']
        assert observed['worker_terminal']['plan'] == plan_ref
        assert set(actual.iterdir()) == {Path(item['path']) for item in observed['files']} | {observer_path}
        add(observer_path, category, observer_ref)
        for ref in observed['files']:
            add(ref['path'], category, ref)
        marker = json.loads(read(actual / 'CONSUMED.json'))
        authority, spent = load(marker['authority']), load(marker['consumed'])
        assert authority['uses'] == 1 and authority['authorized'] is True and authority['plan'] == plan_ref
        assert spent['status'] == 'SPENT' and spent['plan'] == plan_ref
        for ref in (marker['authority'], marker['consumed']):
            add(ref['path'], category, ref)

    named = {
        'sources': ['root/Root-current-Source-adoption-v1.json', 'review/reference-Source-peer-v1.json', 'review/runner-main-Source-peer-v1.json'],
        'qualification': [
            'root/qualification-concrete-caller-001.json', 'root/qualification001-original-tool-exit-v1.json',
            'root/qualification001-Root-readback-v1.json', 'root/Root-qualification001-scientific-admission-v1.json',
            'review/qualification001-custody-review-v1.json', 'review/qualification001-custody-support-v1.json',
            'review/passive_qualification_custody_v2.py', 'review/qualification001-passive-math-review-v2.json',
            'review/qualification001-passive-math-support-v2.json', 'review/passive_math_review_v2.py'],
        'main': [
            'root/study-concrete-caller-001.json', 'root/study001-original-tool-exit-v1.json',
            'root/main001-Root-readback-v1.json', 'root/readback_main001_v1.py', 'root/main001-passive-metrics-v1.json',
            'root/Root-study001-scientific-admission-v1.json', 'review/main001-custody-review-v1.json',
            'review/main001-custody-support-v1.json', 'review/main001-retained-stream-scope-v1.json',
            'review/passive_main001_custody_v1.py', 'review/main001-passive-math-review-v2.json',
            'review/main001-passive-math-support-v2.json', 'review/passive_main_math_review_v2.py'],
        'report': [
            'report/materialize_history_report_v3.py', 'report/history-proof-reader-template-v1.html',
            'report/build_history_evidence_v1.py', 'report/archive-builder-API-v1.json',
            'report/report-current-handoff-v2.json', 'report/materializer2-to3-forward.patch',
            'report/review_rendered_data_v1.py', 'report/report-content-review-v1.json',
            'report/rendered-v1/history-marked-proof-search-v1.html',
            'report/rendered-v1/history-marked-proof-search-results-v1.json',
            'root/Root-report-content-admission-v1.json', 'review/prepare_history_evidence_selection_v1.py'],
        'qa': ['qa/browser-reader-qa-v1.json', 'qa/marked-typing-desktop-v1.png']}
    for category, names in named.items():
        for name in names:
            add(RUN / name, category)
    recovery = ('Source-recovery-provenance-v1.json', 'history_comparison_experiment_v3.py',
                'history_proof_provider_v3.py', 'materialize_history_report_v3.py')
    assert set(REC.iterdir()) == {REC / name for name in recovery}
    for name in recovery:
        add(REC / name, 'recovery_provenance')
    admissions = [pin(RUN / ('root/' + name)) for name in (
        'Root-qualification001-scientific-admission-v1.json', 'Root-study001-scientific-admission-v1.json',
        'Root-report-content-admission-v1.json')]
    assert all(load(ref)['status'] == 'ADMITTED' for ref in admissions)
    entries = sorted(selected.values(), key=lambda row: row['name'])
    groups = {group: [row['source_ref'] for row in entries if row['category'] == group] for group in GROUPS}
    assert all(groups.values()) and len({row['name'] for row in entries}) == len(entries)
    assert len([row for row in entries if row['source_ref']['path'].startswith(str(REC) + '/')]) == 4
    manifest = {
        'schema': 'HNF-closed-evidence-input-v1', 'status': 'ADMITTED_CLOSED_PREPUBLICATION_CUT',
        'cut_id': 'gcts-history-normal-form-20261102-v1-prepublication-cut-v1',
        'entries': entries, 'plans': plan_refs, 'observations': observer_refs, 'admissions': admissions,
        'required_groups': groups,
        'upstream': [{'name': 'indexed-proof-search-evidence-v1.zip',
            'url': 'https://liuyao12.github.io/geometric-tree-search/docs/research/gcts-rl-renewal/conditional-inventory/indexed-proof-search-evidence-v1.zip',
            'bytes': 5329968, 'sha256': '981d8e3901ddf7a55df2949bee9df2b281f826a8ffdf217c8e1fba125d571a93',
            'scope': 'Previously acquired and fully verified public upstream; external pin only, not nested in this cut. Exact operative Sources, bootstrap, metadata and all31 input carriers are selected individually.'}],
        'exclusions': [
            'Entire recovery directory except its four-file public-recovered-sources subset; all session/chat/filtered logs, indexes and unverified recovery candidates.',
            'Nested upstream ZIP, platform Python/runtime binary, bare Git repositories, caches and unrelated workspace files.',
            'Retired materials reconstruction/atomistic datasets, models and experiments.',
            'Superseded review/report/reference drafts not required by current execution plans or current final reviews.',
            'This input selection, generated member catalogue/README and post-build readback are generated/included by the builder as appropriate, not selected recursively.',
            'Future package admission, Git/Pages/TLS/live verification receipts: separate later durable supplement.'],
        'scope': [
            'Root admitted the current persistent qualification, all60 main method positions, and the saved report content/QA before selection. This is an exact selected prepublication cut, not publication completion.',
            'Both current native observations and every original physical file, all13 current Source roles, bootstrap, all declared metadata, all31 frozen input carriers, both plans and fresh spent once authorities are retained.',
            'Current final independent Source/custody/math/content reviews, their available passive auditing Source and support, Root readbacks/admissions, actual rendered HTML/JSON and browser QA are selected explicitly.',
            'Historical missing qualification case/proof artifacts remain unadmitted and are not reconstructed. Public recovered Source/provenance is the separate exact four-file subset only.',
            'The main trace contains135 streams,1333 retained of131905 reported rows; only37 full sequence digests can be recomputed, and98 omitted suffixes remain unverified.',
            'The current results show8/7/7/10 verified positive occurrences across unmarked/history-scan/history-indexed/matched-depth control. No RL, learned-marking, universal-proof-search, unbounded negative or comparative speed superiority claim is made.',
            'All scientific execution authorities are spent. Packaging is passive; reproduction requires separately reviewed fresh plans and once authority. No archived Source executes during selection or packaging.'],
        'pending': []}
    manifest_path = RUN / 'report/history-evidence-closed-input-v1.json'
    create(manifest_path, raw(manifest))
    counts = Counter(row['category'] for row in entries)
    listing = 'category\tbytes\tsha256\tarchive_member\toriginal_path\n' + ''.join(
        '\t'.join((row['category'], str(row['source_ref']['bytes']), row['source_ref']['sha256'], row['name'], row['source_ref']['path'])) + '\n'
        for row in entries)
    list_path = RUN / 'report/history-evidence-selected-files-v1.tsv'
    create(list_path, listing.encode('ascii'))
    summary = {'schema': 'HNF-explicit-evidence-selection-summary-v1', 'status': 'SELECTED_NOT_PACKAGED',
        'manifest': pin(manifest_path), 'selected_files': pin(list_path),
        'originals': len(entries), 'original_bytes': sum(row['source_ref']['bytes'] for row in entries),
        'category_counts': dict(sorted(counts.items())),
        'category_bytes': {g: sum(row['source_ref']['bytes'] for row in entries if row['category'] == g) for g in GROUPS},
        'qualification_physical_files': 23, 'main_physical_files': 173,
        'source_roles': 13, 'frozen_input_carriers': 31, 'public_recovery_files': 4,
        'all_original_refs_hashed': True, 'all_required_groups_nonempty': True,
        'root_admissions': admissions, 'packaging_runs': 0, 'scientific_calls': 0,
        'scope': 'Root requested exact closed selection after all three admissions. Root manifest review/build and every publication action remain separate.'}
    summary_path = RUN / 'report/history-evidence-selection-summary-v1.json'
    create(summary_path, raw(summary))
    print(json.dumps({'manifest': pin(manifest_path), 'selected_files': pin(list_path),
        'summary': pin(summary_path), 'originals': len(entries), 'original_bytes': summary['original_bytes'],
        'category_counts': dict(sorted(counts.items()))}, sort_keys=True))


if __name__ == '__main__':
    main()
