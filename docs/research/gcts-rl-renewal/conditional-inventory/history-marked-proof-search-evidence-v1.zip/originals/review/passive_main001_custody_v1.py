"""Passive complete saved-main custody and assurance joins; no scientific replay."""
from pathlib import Path
import gzip
import hashlib
import io
import json

ROOT=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-history-normal-form-20261102-v1')


def raw(x):return (json.dumps(x,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')
def sha(x):return hashlib.sha256(raw(x)).hexdigest()
def same(a,b):return raw(a)==raw(b)
def pin(p):
    z=p.read_bytes();return dict(path=str(p),bytes=len(z),sha256=hashlib.sha256(z).hexdigest())
def ref(r):
    p=Path(r['path']);assert p.is_file() and not p.is_symlink();z=p.read_bytes()
    assert len(z)==r['bytes'] and hashlib.sha256(z).hexdigest()==r['sha256'],str(p)
    return z
def artifact(a):
    n=a['raw_bytes'];assert type(n) is int and 0<=n<=67108864;z=ref(a['stored'])
    if a['encoding']=='gzip-json':
        with gzip.GzipFile(fileobj=io.BytesIO(z)) as f:r=f.read(n+1)
    else:assert a['encoding']=='json';r=z
    assert len(r)==n and hashlib.sha256(r).hexdigest()==a['raw_sha256']
    return json.loads(r)
def extent(rows,e,kind,totals):
    assert type(e['total']) is int and type(e['retained']) is int and len(rows)==e['retained']<=e['total']
    assert type(e['sha256']) is str and len(e['sha256'])==64
    complete=len(rows)==e['total']
    if complete:assert hashlib.sha256(b''.join(raw(x) for x in rows)).hexdigest()==e['sha256']
    totals[kind+'_total']+=e['total'];totals[kind+'_retained']+=len(rows);totals[kind+'_complete']+=int(complete)


def main():
    d=ROOT/'actual/study-001';op=d/'observer-result.json';o=json.loads(op.read_bytes())
    assert pin(op)['bytes']==53091 and pin(op)['sha256']=='1ebe3b931f0a389df44e2421083cd9b0de4b67a24d89450282d298d7084357aa'
    assert o['status']=='COMPLETE' and o['returncode']==0 and o['failure'] is None and not o['cleanup_errors']
    assert o['wait_confirmed'] and o['both_streams_EOF'] and o['group_gone'] and o['stdin_bytes_sent']==19359
    assert all(o['retained_streams_complete'].values())
    terminal=json.loads(ref(o['streams']['stdout']));assert same(terminal,o['worker_terminal']) and ref(o['streams']['stderr'])==b''
    for k in ('stdout','stderr'):assert o['observed_stream_bytes'][k]==o['streams'][k]['bytes']
    assert len(o['files'])==172 and len({x['path'] for x in o['files']})==172
    assert sorted(p.name for p in d.iterdir())==sorted([Path(x['path']).name for x in o['files']]+['observer-result.json'])
    for x in o['files']:ref(x)
    assert sum(x['bytes'] for x in o['files'])==o['stored_bytes']==4984644
    plan=json.loads(ref(terminal['plan']));assert Path(plan['actual_dir'])==d and len(plan['sources'])==13
    for r in list(plan['sources'].values())+list(plan['metadata'].values())+[plan['python'],plan['bootstrap']]:ref(r)
    assert plan['python']['sha256']=='0048df8bc66cbf4cc964f31eb89321e762902aeecf95dfbde306a36601d27034'
    gate=json.loads(ref(plan['metadata']['qualification_admission']));assert gate['status']=='ADMITTED'
    for role in ('engine_indexed','adapter_indexed','history_provider','history_oracle','qualifier'):assert gate['sources'][role]==plan['sources'][role]
    marker=json.loads((d/'CONSUMED.json').read_bytes());a=json.loads(ref(marker['authority']));c=json.loads(ref(marker['consumed']))
    assert a==dict(schema='AA-growing-proof-search-once-authority-v1',uses=1,authorized=True,plan=terminal['plan'],runner=plan['sources']['runner'],python=plan['python'])
    assert c==dict(authority=marker['authority'],plan=terminal['plan'],status='SPENT')
    original_path=ROOT/'root/study001-original-tool-exit-v1.json';original=json.loads(original_path.read_bytes())
    assert original['initial']['session_id']==90728 and original['intermediate_poll']['session_id']==90728 and original['terminal']['exit_code']==0
    assert original['authority']=='SPENT' and original['observer']==pin(op) and json.loads(original['terminal']['output'])==dict(status='COMPLETE',receipt=pin(op))
    manifest=json.loads(ref(plan['metadata']['frozen_inputs']));inputs={x['name']:x for x in manifest['inputs']};assert len(inputs)==31
    for x in inputs.values():artifact(x)
    worker=artifact(terminal['result']);assert worker['status']=='COMPLETE' and len(worker['artifacts'])==168
    assert worker['outer_public_calls']==terminal['public_calls']
    refs={x['name']:x for x in worker['artifacts']};assert len(refs)==168
    all_raw=terminal['result']['raw_bytes']
    for x in worker['artifacts']:artifact(x);all_raw+=x['raw_bytes']
    ex=worker['experiment'];design=ex['design'];assert ex['status']=='COMPLETE' and design['kind']=='history-main' and design['depth']==8 and design['search_seconds']==2
    assert [r['id'] for r in ex['results']]==design['case_order'] and len(ex['results'])==15 and len(set(design['case_order']))==15
    assert same(design,json.loads(ref(plan['metadata']['design'])))
    methods=['UNMARKED_INDEXED','HISTORY_SCAN','HISTORY_INDEXED','MATCHED_DEPTH_TREE_CONTROL'];assert design['lanes']==methods
    assert len(ex['fresh_bank_checks'])==4 and all(x['status']=='VERIFIED' for x in ex['fresh_bank_checks'])
    assert artifact(refs['fresh-bank-host-checks'])==ex['fresh_bank_checks']
    stats={m:dict(verified=0,SAT=0,UNSAT=0,UNKNOWN=0,DERIVABLE=0,NOT_DERIVABLE=0,seconds=0.,coarse_lines=0,original_lines=0,candidate_registrations=0,branches=0,backtracks=0) for m in methods}
    stream_totals={k+s:0 for k in ('events','rollbacks','queries') for s in ('_total','_retained','_complete')}
    assurance=dict(factories_complete=0,factories_verified=0,positive_occurrences=0,history_certificates=0,coarse_host=0,original_host=0,lowering=0,tree_checks=0,nonnull_images=0,exact_entry_restores=0,point_results=0,raw_search_records=0,positive_records=0,full_lane_records=0,case_records=0)
    case_rows=[];used=set(['fresh-bank-host-checks']);common_history=[]
    for case in ex['results']:
        assert set(case['lanes'])==set(methods);built=artifact(inputs[case['id']+'-whole-build']);prep=artifact(inputs[case['id']+'-whole-preparation'])
        assert built['status']==prep['status']=='COMPLETE' and prep['catalogue_audit']['status']==prep['zero_audit']['status']=='VERIFIED'
        assert sha(built['compiled'])==case['compiled_sha256']==prep['checkpoint']['raw_sha256'] and same(built['generation'],prep['generation'])
        assert same(case['original'],prep['original'])
        comparison=artifact(case['ref']);assert same(comparison,{k:v for k,v in case.items() if k!='ref'});used.add(case['ref']['name']);assurance['case_records']+=1
        fulls={};cr=dict(id=case['id'],lanes={})
        for mode in methods:
            compact=case['lanes'][mode];full=artifact(compact['ref']);fulls[mode]=full;used.add(compact['ref']['name']);assurance['full_lane_records']+=1
            for k in ('status','reason','search_seconds','verified'):assert same(compact[k],full[k])
            raw_search=artifact(full['raw_search_ref']);used.add(full['raw_search_ref']['name']);assurance['raw_search_records']+=1
            for k,v in raw_search.items():assert (v is False if k=='verified' else same(v,full[k]))
            s=stats[mode];s[full['status']]+=1;s['seconds']+=full['search_seconds'];s['verified']+=int(full['verified'])
            ans=full['result'];assert ans is not None and ans['status']==full['status']
            if mode!='MATCHED_DEPTH_TREE_CONTROL':
                assurance['point_results']+=1;factory=full['factory'];fa=full['factory_audit']
                assert factory['status']=='COMPLETE' and fa['status']=='VERIFIED';assurance['factories_complete']+=1;assurance['factories_verified']+=1
                assert same(full['model'],fa['value']['expected_model']) if mode.startswith('HISTORY') else True
                assert ans['model_sha256'] is None and ans['status']=='UNKNOWN' or ans['model_sha256']==sha(full['model'])
                if ans['entry_state'] is not None:
                    assert same(ans['entry_state'],ans['restored_state']);assurance['exact_entry_restores']+=1
                for key in ('entry','final','restored'):
                    state=ans[key+'_state'];assert ans['state_hashes'][key]==(None if state is None else sha(state));assurance['nonnull_images']+=int(state is not None)
                extent(ans['events'],ans['event_extent'],'events',stream_totals);extent(ans['rollback_records'],ans['rollback_extent'],'rollbacks',stream_totals)
                ev=ans['provider_evidence'];extent(ev['records'],ev,'queries',stream_totals)
                for rec in ev['records']:
                    assert rec['reply']['context_sha256']==sha(rec['query']) and rec['reply']['complete'] is True
                    assert rec['reply']['certificate']['compatible_count']==len(rec['reply']['placements'])
                for k in ('candidate_registrations','branches','backtracks'):s[k]+=ans['stats'][k]
                assert same(compact['stats'],ans['stats'])
                if ans['status']=='SAT':assert ans['selected'] and ans['certificate'] is not None
                else:assert ans['selected']==[] and ans['certificate'] is None
            if full['verified']:
                pos=full['positive'];pr=artifact(pos['ref']);used.add(pos['ref']['name']);assurance['positive_records']+=1
                assert same(pr,{k:v for k,v in pos.items() if k!='ref'}) and compact['positive_ref']==pos['ref'] and pos['verified'] is True
                assert pos['tree_audit']['status']==pos['coarse_host_check']['status']==pos['original_host_check']['status']==pos['lowering_audit']['status']=='VERIFIED'
                assert pos['lowering']['status']=='COMPLETE' and same(pos['tree_audit']['proof'],pos['decoded']['proof']) and same(pos['coarse_proof'],pos['decoded']['proof'])
                assert same(pos['original_proof'],pos['lowering']['value']['proof']) and same(pos['lowering']['value']['goal'],case['original']['goal'])
                assert same(pos['lowering']['value']['theory'],case['original']['theory']) and same(pos['decoded']['target'],case['original']['goal'])
                assert compact['coarse_lines']==len(pos['coarse_proof']) and compact['original_lines']==len(pos['original_proof'])
                s['coarse_lines']+=len(pos['coarse_proof']);s['original_lines']+=len(pos['original_proof'])
                for k in ('positive_occurrences','coarse_host','original_host','lowering','tree_checks'):assurance[k]+=1
                if mode.startswith('HISTORY'):
                    assert pos['history_audit']['status']=='VERIFIED' and pos['normal_form']['path_normal'] is True;assurance['history_certificates']+=1
                    assert same(pos['history_audit']['value']['expected_certificate'],ans['certificate'])
                    assert same(pos['history_audit']['value']['projected_selected'],pos['decoded']['tree']['selected'])
                    assert all(same(pos['actual_tree'][k],ans['certificate'][k]) for k in ('placements','totals','marks'))
                elif mode=='MATCHED_DEPTH_TREE_CONTROL':assert same(ans['proof'],pos['coarse_proof'])
                else:assert all(same(pos['actual_tree'][k],ans['certificate'][k]) for k in ('placements','totals','marks'))
            else:assert not full.get('positive',{}).get('verified',False)
            cr['lanes'][mode]=dict(status=full['status'],reason=full['reason'],verified=full['verified'],seconds=full['search_seconds'],coarse_lines=compact.get('coarse_lines'),original_lines=compact.get('original_lines'))
        assert same(fulls['HISTORY_SCAN']['model'],fulls['HISTORY_INDEXED']['model'])
        if all(fulls[m]['verified'] for m in ('HISTORY_SCAN','HISTORY_INDEXED')):
            a,b=(fulls[m]['positive'] for m in ('HISTORY_SCAN','HISTORY_INDEXED'));assert same(a['actual_tree'],b['actual_tree']) and same(a['coarse_proof'],b['coarse_proof']);common_history.append(case['id'])
        if fulls['MATCHED_DEPTH_TREE_CONTROL']['status']=='NOT_DERIVABLE':assert not any(fulls[m]['verified'] for m in methods[:-1])
        case_rows.append(cr)
    assert used==set(refs) and assurance['raw_search_records']==assurance['full_lane_records']==60 and assurance['positive_records']==32 and assurance['case_records']==15
    assert [stats[m]['verified'] for m in methods]==[8,7,7,10]
    assert [stats[m]['UNSAT'] for m in methods[:-1]]==[0,3,3] and stats[methods[-1]]['NOT_DERIVABLE']==5
    assert assurance['coarse_host']+assurance['original_host']+len(ex['fresh_bank_checks'])==terminal['public_calls']['fol_checker.check']==68
    out=dict(schema='HN-main001-complete-passive-custody-support-v1',status='PASS',observer=pin(op),original_exit=pin(original_path),physical_files=173,physical_stored_bytes=sum(p.stat().st_size for p in d.iterdir()),artifact_files=169,worker_artifacts=168,artifact_raw_bytes_including_worker=all_raw,input_carriers=31,source_roles=13,metadata_records=len(plan['metadata']),assurance=assurance,lanes=stats,stream_scope=stream_totals,common_identical_history_successes=common_history,cases=case_rows,scope='Passive custody/hash/stream extent and proof-assurance receipt joins only. Missing event/query suffixes are not inferred; no scientific helper, kernel or search replay.')
    q=ROOT/'review/main001-custody-support-v1.json'
    with q.open('xb') as f:f.write(raw(out))
    print(json.dumps(out,indent=2))


if __name__=='__main__':main()
