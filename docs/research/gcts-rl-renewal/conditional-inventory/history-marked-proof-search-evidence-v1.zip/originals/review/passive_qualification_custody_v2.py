"""Saved-data custody audit only; no project imports or scientific replay."""
from pathlib import Path
import gzip
import hashlib
import io
import json

ROOT = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-history-normal-form-20261102-v1')


def raw(v):
    return (json.dumps(v, sort_keys=True, ensure_ascii=True, separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')


def sha(v):
    return hashlib.sha256(raw(v)).hexdigest()


def pin(p):
    r=p.read_bytes(); return dict(path=str(p), bytes=len(r), sha256=hashlib.sha256(r).hexdigest())


def read_ref(ref):
    p=Path(ref['path']); assert p.is_file() and not p.is_symlink()
    r=p.read_bytes(); assert len(r)==ref['bytes'] and hashlib.sha256(r).hexdigest()==ref['sha256'], str(p)
    return r


def artifact(ref):
    n=ref['raw_bytes']; assert type(n) is int and 0 <= n <= 67108864
    r=read_ref(ref['stored'])
    if ref['encoding']=='gzip-json':
        with gzip.GzipFile(fileobj=io.BytesIO(r)) as f: data=f.read(n+1)
    else:
        assert ref['encoding']=='json'; data=r
    assert len(data)==n and hashlib.sha256(data).hexdigest()==ref['raw_sha256']
    return json.loads(data)


def extent(rows,e,full=True):
    assert len(rows)==e['retained'] <= e['total']
    if full: assert len(rows)==e['total']
    complete=len(rows)==e['total']
    if complete: assert hashlib.sha256(b''.join(raw(r) for r in rows)).hexdigest()==e['sha256']
    return complete


def main():
    d=ROOT/'actual/qualification-001'; op=d/'observer-result.json'; observer=json.loads(op.read_bytes())
    assert pin(op)['bytes']==8733 and pin(op)['sha256']=='2c8648377d01627a45b2287f9608744d88c2c0b77aa9725f0e14722c8d4e4b8f'
    assert observer['status']=='COMPLETE' and observer['returncode']==0 and observer['failure'] is None
    assert observer['wait_confirmed'] and observer['both_streams_EOF'] and observer['group_gone'] and not observer['cleanup_errors']
    assert all(observer['retained_streams_complete'].values()) and observer['stdin_bytes_sent']==19359
    terminal=json.loads(read_ref(observer['streams']['stdout'])); assert terminal==observer['worker_terminal']
    assert read_ref(observer['streams']['stderr'])==b''
    for k in ('stdout','stderr'): assert observer['observed_stream_bytes'][k]==observer['streams'][k]['bytes']
    files=observer['files']; assert len(files)==22 and len({x['path'] for x in files})==22
    assert sorted(p.name for p in d.iterdir())==sorted([Path(x['path']).name for x in files]+['observer-result.json'])
    for x in files: read_ref(x)
    assert sum(x['bytes'] for x in files)==observer['stored_bytes']==351861
    plan=json.loads(read_ref(terminal['plan']))
    assert Path(plan['actual_dir'])==d and len(plan['sources'])==13
    for ref in list(plan['sources'].values())+list(plan['metadata'].values())+[plan['python'],plan['bootstrap']]: read_ref(ref)
    assert plan['sources']['runner']['sha256']=='ab10bed8b5a0c3284b69a77d314d02678fb1a05558f9fb64428099e7435e52fb'
    assert plan['sources']['history_provider']['sha256']=='1a3e715b408c1f893e9d8d66bd77fc3d50d26706fc02d2c3f7e881ff0be494e2'
    assert plan['sources']['history_oracle']['sha256']=='0d417407fe9a2b9a2d63ec309c0922fae16e6b473677d6981d1363e123801ef6'
    assert plan['sources']['qualifier']['sha256']=='65a671d2bf3e88e5212f4a8dafa660c9e4822437232d02a7f3018f1be2d64f35'
    assert plan['python']['sha256']=='0048df8bc66cbf4cc964f31eb89321e762902aeecf95dfbde306a36601d27034'
    marker=json.loads((d/'CONSUMED.json').read_bytes()); authority=json.loads(read_ref(marker['authority'])); consumed=json.loads(read_ref(marker['consumed']))
    assert authority==dict(schema='AA-growing-proof-search-once-authority-v1', uses=1, authorized=True, plan=terminal['plan'],runner=plan['sources']['runner'],python=plan['python'])
    assert consumed==dict(authority=marker['authority'],plan=terminal['plan'],status='SPENT')
    original_path=ROOT/'root/qualification001-original-tool-exit-v1.json'; original=json.loads(original_path.read_bytes())
    assert original['authority']=='SPENT' and original['initial']['session_id']==15624 and original['terminal']['exit_code']==0
    assert original['observer']==pin(op) and json.loads(original['terminal']['output'])==dict(status='COMPLETE',receipt=pin(op))
    inputs=json.loads(read_ref(plan['metadata']['frozen_inputs']))['inputs']; assert len(inputs)==31
    input_raw=0
    for x in inputs:
        artifact(x);input_raw+=x['raw_bytes']
    worker=artifact(terminal['result']); assert worker['status']=='COMPLETE' and len(worker['artifacts'])==18
    assert worker['outer_public_calls']==dict(terminal['public_calls'])=={'experiment.run':1,'qualifier.qualify':1}
    ex=worker['experiment']; assert ex['status']=='COMPLETE'
    expected=dict(fixtures=8,normal_solves=32,tail_solves=8,host_checks=24,direct_queries=32,describes=84,provider_snapshots=16,records=18)
    for k,n in expected.items(): assert ex['counts'][k]==n
    objs={a['name']:artifact(a) for a in worker['artifacts']}
    fixed_cases=['zero-aliases-wrong-output','unary-generalization','binary-modus-ponens','valid-detour-normalization','cyclic-mp-no-base','cyclic-generalization-no-base','shared-curried-incomparable-branches','literal-binder-and-capture-distinction']
    fixed_tails=['nodes-zero','work-one','candidate-one','sticky-provider-refusal','bad-context-hash','foreign-provider','foreign-audit','foreign-order']
    assert list(objs)==['case-'+x for x in fixed_cases]+['direct-complete-contexts','data-mutations-and-owned-factory-refusals']+['tail-'+x for x in fixed_tails]
    result=dict(normal_sat=0,normal_unsat=0,host_checks=0,host_lines=0,normal_events=0,normal_rollbacks=0,
                observed_callbacks=0,returned_images=0,normal_queries=0,tail_queries=0,describes=0,snapshots=0,
                complete_event_streams=0,complete_rollback_streams=0,complete_query_streams=0,trees_old=0,trees_history=0,trees_pair=0)
    cases=[]
    for name,x in objs.items():
        if not name.startswith('case-'): continue
        case_counts=dict(id=x['case']['id'],old=x['complete_tree_comparison']['value']['counts']['old'],history=x['complete_tree_comparison']['value']['counts']['history'],pair=x['complete_tree_comparison']['value']['counts']['pair'])
        for k in ('old','history','pair'):result['trees_'+k]+=case_counts[k]
        cv=x['complete_tree_comparison'];assert cv['status']=='COMPLETE';cv=cv['value']
        for k in ('old','history','pair'):
            ts=cv[k+'_trees'];assert cv['counts'][k]==len(ts) and cv[k+'_tree_hashes']==[sha(v) for v in ts]
        assert len(cv['normalizations'])==len(cv['old_trees'])
        normal_ids=set(cv['history_tree_hashes']);old_ids=set(cv['old_tree_hashes'])
        assert {v['old_sha256'] for v in cv['normalizations']}==old_ids
        for v in cv['normalizations']: assert v['normal_sha256'] in normal_ids and v['normal_nodes']<=v['old_nodes'] and v['normal_height']<=v['old_height']
        assert x['inventory']['status']=='COMPLETE'
        for desc in x['descriptions']:
            assert len(desc['modes'])==2
            for v in desc['modes']: assert v['independent']['status']=='VERIFIED';result['describes']+=1
        assert len(x['provider_snapshots'])==2;result['snapshots']+=2
        for mode,lane in x['lanes'].items():
            a=lane['result']; assert a['status'] in ('SAT','UNSAT')
            result['normal_sat' if a['status']=='SAT' else 'normal_unsat']+=1
            assert a['entry_state']==a['restored_state'] and a['model_sha256']==sha(lane['model'])
            for key in ('entry','final','restored'):
                image=a[key+'_state'];assert image is not None and a['state_hashes'][key]==sha(image);result['returned_images']+=1
            assert extent(a['events'],a['event_extent']);result['complete_event_streams']+=1
            assert extent(a['rollback_records'],a['rollback_extent']);result['complete_rollback_streams']+=1
            result['normal_events']+=len(a['events']);result['normal_rollbacks']+=len(a['rollback_records'])
            obs=lane['observations'];assert [v['event'] for v in obs]==a['events'];result['observed_callbacks']+=len(obs)
            for v in obs: assert v['independent']['status']=='VERIFIED'
            ev=a['provider_evidence']; assert len(ev['records'])==ev['retained']==ev['total']==len(lane['query_captures'])
            assert hashlib.sha256(b''.join(raw(v) for v in ev['records'])).hexdigest()==ev['sha256'];result['complete_query_streams']+=1
            for v in lane['query_captures']: assert v['independent']['status']=='VERIFIED'
            assert ev['records']==[dict(query=v['query'],reply=v['reply']) for v in lane['query_captures']]
            result['normal_queries']+=len(ev['records'])
            if a['status']=='SAT':
                pos=lane['positive'];assert pos['host_check']['status']==pos['independent_tree']['status']=='VERIFIED'
                assert pos['proof']==pos['decoded']['proof'];result['host_checks']+=1;result['host_lines']+=len(pos['proof'])
                if mode.startswith('HISTORY'): assert pos['history_certificate']['status']=='VERIFIED'
        assert x['lanes']['HISTORY_SCAN']['result']['events']==x['lanes']['HISTORY_INDEXED']['result']['events']
        assert x['lanes']['HISTORY_SCAN']['result']['certificate']==x['lanes']['HISTORY_INDEXED']['result']['certificate']
        delivered=x['native_certificates'];assert len(delivered)==sum(l['result']['status']=='SAT' for l in x['lanes'].values())
        for v in delivered:assert v=={k:x['lanes'][v['label']]['positive'][k] for k in ('label','problem','proof')}
        cases.append(case_counts)
    direct=objs['direct-complete-contexts']['queries'];assert len(direct)==16
    for v in direct:
        assert len(v['modes'])==2
        for m in v['modes']:assert m['independent']['status']=='VERIFIED'
    mutants=objs['data-mutations-and-owned-factory-refusals']['controls'];assert len(mutants)==15
    mutant_statuses=[]
    for v in mutants:
        check=v.get('independent',v.get('receipt',v.get('result')));assert check['status'] in ('REJECTED','UNKNOWN')
        mutant_statuses.append(dict(label=v['label'],status=check['status']))
    for name,x in objs.items():
        if not name.startswith('tail-'):continue
        a=x['actual'];obs=a['observations'];result['observed_callbacks']+=len(obs)
        for v in obs:assert v['independent']['status']=='VERIFIED'
        result['tail_queries']+=len(a['query_captures'])
        if 'result' in a:
            v=a['result'];assert v['status']=='UNKNOWN' and v['certificate'] is None and v['selected']==[]
            assert extent(v['events'],v['event_extent']);result['complete_event_streams']+=1
            assert extent(v['rollback_records'],v['rollback_extent']);result['complete_rollback_streams']+=1
            for key in ('entry','final','restored'):
                image=v[key+'_state']; assert v['state_hashes'][key]==(None if image is None else sha(image))
                result['returned_images']+=int(image is not None)
            ev=v['provider_evidence'];assert len(ev['records'])==ev['retained']==ev['total']
            assert hashlib.sha256(b''.join(raw(r) for r in ev['records'])).hexdigest()==ev['sha256'];result['complete_query_streams']+=1
        else:assert a['post_throw_state'] is None and 'exception' in a
    assert len(cases)==8 and result['host_checks']==24 and result['normal_sat']==24 and result['normal_unsat']==8
    assert result['observed_callbacks']==ex['counts']['observations']==269
    assert result['normal_queries']+result['tail_queries']==ex['counts']['captured_queries']==59
    assert result['describes']==84 and result['snapshots']==16
    result.update(physical_files=23,physical_stored_bytes=sum(p.stat().st_size for p in d.iterdir()),artifacts=18,
                  input_carriers=31,input_raw_bytes=input_raw,source_roles=13,metadata_records=len(plan['metadata']),
                  observer=pin(op),original_exit=pin(original_path),cases=cases,mutants=mutant_statuses,
                  schema='HN-passive-qualification001-custody-support-v1',status='PASS',
                  scope='Passive raw custody/census/hash/stream/proof-receipt checks only. No scientific functions, kernel checks or search replay.')
    p=ROOT/'review/qualification001-custody-support-v1.json'
    with p.open('xb') as f:f.write(raw(result))
    print(json.dumps(result,indent=2))


if __name__=='__main__': main()
