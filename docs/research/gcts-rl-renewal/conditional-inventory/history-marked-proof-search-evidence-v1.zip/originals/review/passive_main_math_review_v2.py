"""Passive full main-cohort verification; no scientific imports or replay."""
import gzip
import hashlib
import json
import math
from pathlib import Path

ROOT=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-history-normal-form-20261102-v1')
HVERSION='HN-HISTORY-PATH-NORMAL-FORM-v1'
ZVERSION='Z-ANCHORED-PROOF-PRODUCER-v1'
LANES=['UNMARKED_INDEXED','HISTORY_SCAN','HISTORY_INDEXED','MATCHED_DEPTH_TREE_CONTROL']


def wire(x):return (json.dumps(x,ensure_ascii=True,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')
def txt(x):return wire(x)[:-1].decode('ascii')
def sha(x):return hashlib.sha256(wire(x)).hexdigest()
def eq(a,b):return wire(a)==wire(b)
def need(test,reason):
    if not test:raise AssertionError(reason)
def pin(p):
    z=p.read_bytes();return dict(path=str(p),bytes=len(z),sha256=hashlib.sha256(z).hexdigest())
def stored(r):
    z=Path(r['path']).read_bytes();need(len(z)==r['bytes'] and hashlib.sha256(z).hexdigest()==r['sha256'],'complete stored pin');return z
def unpack(r):
    z=stored(r['stored']);z=gzip.decompress(z) if r['encoding']=='gzip-json' else z
    need(len(z)==r['raw_bytes'] and hashlib.sha256(z).hexdigest()==r['raw_sha256'],'complete raw artifact pin');return json.loads(z)
def hp(s):return txt(['HN-history-v1',s])
def definitions(c):
    colors=c['logical_basis']['colors'];forms=c['logical_basis']['formulas'];need(colors==sorted(set(colors)) and colors==[txt(f) for f in forms],'literal formula catalogue')
    by={x:i for i,x in enumerate(colors)};mp=[];gen=[];ds={}
    for i,f in enumerate(forms):
        if f[0]=='imp' and txt(f[1]) in by and txt(f[2]) in by:mp.append([i,by[txt(f[1])],by[txt(f[2])]])
        if f[0]=='all' and txt(f[2]) in by:gen.append([i,by[txt(f[2])],f[1]])
    need(eq(mp,c['mp_index']) and eq(gen,c['gen_index']),'all fitting MP/GEN indices')
    for i,z in enumerate(c['zero_instances']):
        need(z['id']=='i'+str(i) and type(z['formula_id']) is int and eq(z['line']['formula'],forms[z['formula_id']]),'all zero aliases')
        ds[txt(['zero',z['id']])]=dict(id=txt(['zero',z['id']]),kind='ZERO',output=z['formula_id'],premises=[],zero_id=z['id'],variable=None,native_rule=z['rule'])
    for h,a,o in mp:ds[txt(['mp',h,a,o])]=dict(id=txt(['mp',h,a,o]),kind='MP',output=o,premises=[a,h],zero_id=None,variable=None,native_rule='mp')
    for h,b,v in gen:ds[txt(['gen',h,b,v])]=dict(id=txt(['gen',h,b,v]),kind='GEN',output=h,premises=[b],zero_id=None,variable=v,native_rule='generalize')
    return dict(sorted(ds.items()))
def identities(c,depth):
    core=sha({k:v for k,v in c.items() if k not in ['costs','scope']});base=sha(dict(schema='Z-anchored-proof-inventory-identity-v1',version=ZVERSION,compiled_core_sha256=core,depth=depth))
    hn=sha(dict(schema='HN-history-normal-form-inventory-v1',version=HVERSION,compiled_core_sha256=core,depth=depth,history_point_tag='HN-history-v1',history_rule='SIZE_EQUALS_SITE_DEPTH_OUTPUT_ABSENT_CHILD_UNION',history_order='ASCENDING_LITERAL_FORMULA_ID',base_inventory_identity=base))
    return core,base,hn
def expected_model(c,depth,history):
    core,base,hn=identities(c,depth);ms=[['',c['logical_basis']['colors'][c['goal_id']]]]
    if history:ms.append([hp(''),'[]'])
    return dict(schema='Z-growing-point-model-v1',version=HVERSION if history else ZVERSION,capacity=2,roots=[''],seed=dict(t=[['',1]],m=sorted(ms)),inventory=dict(kind='CERTIFIED_INCIDENT',identity=hn if history else base))
def placement(c,ds,depth,cid,history):
    v=json.loads(cid);need(type(v) is list and len(v)==(3 if history else 2) and txt(v)==cid,'canonical full CID');site,did=v[:2]
    need(type(site)is str and len(site)<=depth and all(x in '01' for x in site) and type(did)is str and did in ds,'site/rule ID')
    d=ds[did];need(len(site)<depth or not d['premises'],'finite depth boundary');h=v[2] if history else None
    if history:need(type(h)is list and len(h)==len(site) and all(type(f)is int and 0<=f<len(c['logical_basis']['formulas']) for f in h) and h==sorted(set(h)) and d['output'] not in h,'static native history parameter')
    ps=[site]+[site+str(i) for i in range(len(d['premises']))];ms=[[p,c['logical_basis']['colors'][f]] for p,f in zip(ps,[d['output']]+d['premises'])]
    if history:ms += [[hp(p),txt(h if i==0 else sorted(h+[d['output']]))] for i,p in enumerate(ps)]
    return dict(id=cid,t=sorted([[p,1] for p in ps]),m=sorted(ms))
def compat(r,t,m):return all(t.get(p,0)+n<=2 for p,n in r['t']) and all(p not in m or m[p]==v for p,v in r['m'])
def contacts(c,ds,depth,p,t,m,history):
    found={};potential=0;f=len(c['logical_basis']['formulas'])
    for anchor,parent in [(p,False)]+([(p[:-1],True)] if p else []):
        for did,d in ds.items():
            a=len(d['premises'])
            if len(anchor)==depth and a:continue
            if parent and int(p[-1])>=a:continue
            cards=math.comb(f-1,len(anchor)) if len(anchor)<f else 0
            potential += cards if history else 1
            ps=[anchor]+[anchor+str(i) for i in range(a)]
            if any(t.get(x,0)+1>2 for x in ps):continue
            if history:
                need(hp(anchor) in m,'actual reachable query has bound incoming H')
                h=json.loads(m[hp(anchor)])
                need(type(h)is list and len(h)==len(anchor) and all(type(x)is int and 0<=x<f for x in h) and h==sorted(set(h)) and txt(h)==m[hp(anchor)],'canonical reached history')
                if d['output'] in h:continue
                cid=txt([anchor,did,h])
            else:cid=txt([anchor,did])
            r=placement(c,ds,depth,cid,history)
            if compat(r,t,m):found[cid]=r
    return dict(sorted(found.items())),potential
def selected_nodes(c,ds,depth,selected,history,complete):
    need(selected==sorted(set(selected)),'sorted selected IDs');nodes={}
    for cid in selected:
        placement(c,ds,depth,cid,history);v=json.loads(cid);need(v[0] not in nodes,'one producer/site');nodes[v[0]]=(cid,ds[v[1]],v[2] if history else None)
    if nodes or complete:need('' in nodes and nodes[''][1]['output']==c['goal_id'],'root literal goal')
    for site,(cid,d,h) in nodes.items():
        outs=[]
        for n in range(len(site)):
            need(site[:n] in nodes,'root reachability');pd=nodes[site[:n]][1];need(int(site[n])<len(pd['premises']),'ordered parent role');outs.append(pd['output'])
        if site:need(nodes[site[:-1]][1]['premises'][int(site[-1])]==d['output'],'parent premise output')
        for i,f in enumerate(d['premises']):
            child=site+str(i)
            if complete:need(child in nodes,'closed premise')
            if child in nodes:need(nodes[child][1]['output']==f,'premise literal')
        if history:need(len(set(outs))==len(outs) and eq(h,sorted(outs)),'unique induced history')
    return nodes
def state(c,ds,depth,model,s,history):
    selected=[cid for cid,g in s['selected']];nodes=selected_nodes(c,ds,depth,selected,history,False);t=dict(model['seed']['t']);mr={p:[v,1] for p,v in model['seed']['m']}
    for cid,g in s['selected']:
        need(type(g)is int and g==len(json.loads(cid)[0])+1,'generation');r=placement(c,ds,depth,cid,history)
        for p,n in r['t']:t[p]=t.get(p,0)+n
        for p,v in r['m']:
            if p in mr:need(mr[p][0]==v,'selected agreement');mr[p][1]+=1
            else:mr[p]=[v,1]
    need(eq(s['Q'],[[p,len(p)] for p in sorted(t)]) and eq(s['totals'],sorted([[p,n] for p,n in t.items()])) and eq(s['marks'],sorted([[p,v,n] for p,(v,n) in mr.items()])),'actual Q/T/M/refcounts')
    marks={p:v[0] for p,v in mr.items()};reg={}
    for r in s['placements']:
        need(r['id'] not in reg and eq(r,placement(c,ds,depth,r['id'],history)),'literal registered payload');reg[r['id']]=r
    need(list(reg)==sorted(reg) and set(selected)<=set(reg),'registry order/selection');b=s['excluded'];need(b==sorted(set(b)) and set(b)<=set(reg)-set(selected),'context exclusions')
    need(eq(s['eligible'],sorted(cid for cid,r in reg.items() if cid not in selected and cid not in b and compat(r,t,marks))),'eligible full rows')
    deps={'t':{},'m':{}}
    for cid,r in reg.items():
        for key in deps:
            for p,v in r[key]:deps[key].setdefault(p,[]).append(cid)
    need(eq(s['dependencies'],{key:[[p,sorted(ids)] for p,ids in sorted(tab.items())] for key,tab in deps.items()}),'full remote t/m dependencies')
    need(s['loaded']==sorted(set(s['loaded'])) and set(s['loaded'])<=set(t),'loaded nodes');domains=[];fw=[];rev={}
    for p in sorted(p for p,n in t.items() if n<2):
        need(p in s['loaded'],'complete frontier load');rows,count=contacts(c,ds,depth,p,t,marks,history);ids=[cid for cid in rows if cid not in selected and cid not in b];need(set(ids)<=set(reg),'no unseen legal frontier candidate');domains.append([p,ids])
        for cid in ids:fw.append([p,cid,1]);rev.setdefault(cid,[]).append([p,1])
    for p in s['loaded']:
        if t[p]>=2:continue
        rows,count=contacts(c,ds,depth,p,t,marks,history);need(set(rows)<=set(reg),'all loaded compatible contacts registered')
    need(eq(s['domains'],domains) and eq(s['forward'],fw) and eq(s['reverse'],[[cid,ps] for cid,ps in sorted(rev.items())]) and type(s['edge_count'])is int and s['edge_count']==len(fw),'complete weighted global frontier graph')
def proof_from_nodes(c,nodes):
    lines=[];by={};zero={z['id']:z['line'] for z in c['zero_instances']}
    def walk(site):
        cid,d,h=nodes[site]
        for i in range(len(d['premises'])):walk(site+str(i))
        if d['kind']=='ZERO':line=zero[d['zero_id']]
        elif d['kind']=='GEN':line=dict(rule='generalize',formula=c['logical_basis']['formulas'][d['output']],source=by[site+'0'],variable=d['variable'])
        else:line=dict(rule='mp',formula=c['logical_basis']['formulas'][d['output']],antecedent=by[site+'0'],implication=by[site+'1'])
        by[site]=len(lines);lines.append(line)
    walk('');return lines,sorted([[s,i] for s,i in by.items()])
def extent(rows,e):
    need(type(e['total'])is int and type(e['retained'])is int and len(rows)==e['retained']<=e['total'] and type(e['sha256'])is str and len(e['sha256'])==64,'bounded native extent')
    full=e['retained']==e['total']
    if full:need(hashlib.sha256(b''.join(wire(v) for v in rows)).hexdigest()==e['sha256'],'complete emitted-stream digest')
    return full


def main():
    op=ROOT/'actual/study-001/observer-result.json';o=json.loads(op.read_bytes());need(o['status']=='COMPLETE' and o['returncode']==0 and o['both_streams_EOF'] and o['group_gone'],'whole original process')
    w=unpack(o['worker_terminal']['result']);e=w['experiment'];plan=json.loads(stored(o['worker_terminal']['plan']));inputs={v['name']:v for v in json.loads(stored(plan['metadata']['frozen_inputs']))['inputs']}
    need(e['status']=='COMPLETE' and len(e['results'])==15 and e['design']['depth']==8 and e['design']['search_seconds']==2,'fixed all15depth8budget')
    counts={l:dict(verified=0,finite_negative=0,unknown=0,seconds=0.0,registrations=0,provider_rows=0,branches=0,backtracks=0,forced=0) for l in LANES}
    stats=dict(factory_audits=0,history_factory_audits=0,positive_occurrences=0,history_positive_occurrences=0,coarse_lines=0,original_lines=0,returned_images=0,retained_queries=0,full_event_streams=0,full_rollback_streams=0,full_query_streams=0,retained_events=0,total_events=0,retained_rollbacks=0,total_rollbacks=0,total_queries=0)
    cases=[];common=0;control_neg=[];history_neg=[];base_detours=[]
    need(len(e['fresh_bank_checks'])==4 and all(v['status']=='VERIFIED' for v in e['fresh_bank_checks']),'four fresh bank host receipts')
    for row in e['results']:
        cid=row['id'];built,prep=unpack(inputs[cid+'-whole-build']),unpack(inputs[cid+'-whole-preparation']);c,g=built['compiled'],built['generation'];depth=8;ds=definitions(c);core,base,hn=identities(c,depth)
        need(sha(c)==row['compiled_sha256']==prep['checkpoint']['raw_sha256'] and eq(g,prep['generation']) and g['compiled_core_sha256']==core and eq(c['goal'],prep['original']['goal']),'fixed reused compiled/preparation/core/target')
        need(prep['catalogue_audit']['status']==prep['zero_audit']['status']=='VERIFIED','upstream catalogue assurance')
        full={};case=dict(id=cid,statuses={},normal_forms={},proof_lines={},reasons={})
        for lane in LANES:
            item=unpack(row['lanes'][lane]['ref']);full[lane]=item;need(eq(item['status'],row['lanes'][lane]['status']) and item['verified'] is row['lanes'][lane]['verified'],'complete compact/full association')
            counts[lane]['seconds']+=item['search_seconds'];case['statuses'][lane]=item['status'];case['reasons'][lane]=item.get('reason')
            yes=item['verified'];counts[lane]['verified' if yes else 'finite_negative' if item['status'] in ['UNSAT','NOT_DERIVABLE'] else 'unknown']+=1
            result=item['result'];hist=lane.startswith('HISTORY')
            if lane!='MATCHED_DEPTH_TREE_CONTROL':
                need(item['factory']['status']=='COMPLETE' and item['factory_audit']['status']=='VERIFIED','assured full factory');stats['factory_audits']+=1;stats['history_factory_audits']+=int(hist)
                model=expected_model(c,depth,hist);need(eq(item['model'],model),'exact percase model/inventory identity')
                fv=item['factory']['value'];need(fv['compiled_core_sha256']==core and fv['identity']==(hn if hist else base) and eq(fv['definitions'],list(ds.values())) and fv['formula_count']==len(c['logical_basis']['formulas']) and fv['potential_sites']==511,'full factory definitions/site counts')
                if hist:need(fv['base_identity']==base and fv['history_point_tag']=='HN-history-v1' and eq(fv['history_cardinalities'],[math.comb(len(c['logical_basis']['formulas'])-1,n) for n in range(9)]),'history combinatorial cards')
                need(result['model_sha256']==sha(model),'actual model hash')
                if result['entry_state'] is not None:need(eq(result['entry_state'],result['restored_state']) and result['state_hashes']['entry']==result['state_hashes']['restored'],'whole actual entry restoration')
                for key in ['entry','final','restored']:
                    s=result[key+'_state']
                    if s is not None:state(c,ds,depth,model,s,hist);need(result['state_hashes'][key]==sha(s),'original state hash');stats['returned_images']+=1
                    else:need(result['state_hashes'][key] is None,'no invented missing state')
                stats['full_event_streams']+=int(extent(result['events'],result['event_extent']));stats['retained_events']+=len(result['events']);stats['total_events']+=result['event_extent']['total']
                stats['full_rollback_streams']+=int(extent(result['rollback_records'],result['rollback_extent']));stats['retained_rollbacks']+=len(result['rollback_records']);stats['total_rollbacks']+=result['rollback_extent']['total']
                pe=result['provider_evidence'];stats['full_query_streams']+=int(extent(pe['records'],pe));stats['total_queries']+=pe['total']
                for r in pe['records']:
                    q,rp=r['query'],r['reply'];need(set(q)=={'schema','inventory_identity','point','capacity','totals','marks'} and q['schema']=='IP-current-tm-incident-query-v1' and q['inventory_identity']==model['inventory']['identity'] and type(q['capacity'])is int and q['capacity']==2,'query identity/capacity');need(all(type(p)is str and type(v)is int and 0<=v<=2 for p,v in q['totals']) and all(type(p)is str and type(v)is str for p,v in q['marks']) and all([p for p,v in q[k]]==sorted(set(p for p,v in q[k])) for k in ['totals','marks']),'native complete context wire');rows,n=contacts(c,ds,depth,q['point'],dict(q['totals']),dict(q['marks']),hist)
                    expected=dict(point=q['point'],context_sha256=sha(q),complete=True,placements=list(rows.values()),certificate=dict(scope='COMPLETE_CURRENT_TM_COMPATIBLE_INCIDENT_SET',potential_count=n,compatible_count=len(rows)))
                    need(eq(rp,expected),'retained query complete global T/M contacts/parent alignments');stats['retained_queries']+=1
                if item['status']=='SAT':need(result['certificate'] is not None and result['final_state'] is not None,'actual finite point certificate')
                else:need(result['certificate'] is None and not result['selected'],'no unknown/negative proof packet')
                for key in ['registrations','provider_rows','branches','backtracks','forced']:
                    src='candidate_registrations' if key=='registrations' else key;counts[lane][key]+=result['stats'][src]
            if yes:
                stats['positive_occurrences']+=1;stats['history_positive_occurrences']+=int(hist);p=item['positive'];need(p['verified'] and all(p[k]['status']=='VERIFIED' for k in ['tree_audit','coarse_host_check','original_host_check','lowering_audit']),'full positive chain checks')
                dec=p['decoded'];old=dec['tree']['selected'];nodes=selected_nodes(c,ds,depth,old,False,True);expected,site_lines=proof_from_nodes(c,nodes)
                need(eq(expected,p['coarse_proof']) and eq(dec['proof'],expected) and eq(p['tree_audit']['proof'],expected) and eq(dec['tree']['site_to_line'],site_lines),'actual selected postorder and independent coarse proof')
                need(eq(expected[-1]['formula'],c['goal']) and p['coarse_host_check']['checked_lines']==len(expected),'coarse target/fresh check line count')
                lower=p['lowering'];need(lower['status']=='COMPLETE' and eq(lower['value']['proof'],p['original_proof']) and eq(lower['value']['theory'],prep['original']['theory']) and eq(lower['value']['goal'],prep['original']['goal']),'exact original-theory lowering association')
                ld=p['lowering_audit']['details'];need(ld['proof_sha256']==sha(p['original_proof']) and ld['primitive_lines']==len(p['original_proof']) and ld['coarse_lines']==len(expected) and p['original_host_check']['checked_lines']==len(p['original_proof']),'independent lowered hash/line/check joins')
                need(eq(lower['value']['coarse_dependency_rows'],ld['coarse_dependency_rows']),'same checked dependency slice')
                if hist:
                    ha=p['history_audit'];need(ha['status']=='VERIFIED','history assurance');current=result['selected'];hnodes=selected_nodes(c,ds,depth,current,True,True)
                    need(eq(ha['value']['projected_selected'],old) and eq(ha['value']['expected_certificate'],result['certificate']) and ha['value']['identity']==hn,'actual H/ordinary projection')
                    old_cert=dict(capacity=2,roots=[''],seed=expected_model(c,depth,False)['seed'],placements=[placement(c,ds,depth,v,False) for v in old],totals=result['final_state']['totals'],marks=[v for v in result['final_state']['marks'] if v[0] in dict(result['final_state']['totals'])])
                    need(eq(ha['value']['projected_certificate'],old_cert) and all(eq(dec['tree'][k],old_cert[k]) for k in ['placements','totals','marks']),'entire projected old point certificate and decoded tree')
                    expected_hist=[[s,hnodes[s][2]] for s in sorted(hnodes)];need(eq(expected_hist,ha['value']['histories']),'unique history decoration')
                    tree=p['actual_tree'];need(eq(tree['selected'],current) and all(eq(tree[k],result['certificate'][k]) for k in ['placements','totals','marks']) and eq(tree['history_by_site'],{s:[c['logical_basis']['formulas'][f] for f in h] for s,h in expected_hist}),'all displayed actual H tile bindings/AST sets')
                elif lane=='MATCHED_DEPTH_TREE_CONTROL':need(eq(result['proof'],expected) and eq(result['details']['selected'],old),'control actual selected proof')
                else:need(eq(result['selected'],old),'unmarked actual selected proof')
                if lane!='MATCHED_DEPTH_TREE_CONTROL':
                    cert=dict(capacity=2,roots=[''],seed=item['model']['seed'],placements=[placement(c,ds,depth,v,hist) for v in result['selected']],totals=result['final_state']['totals'],marks=result['final_state']['marks']);need(eq(result['certificate'],cert),'point certificate bound to actual reconstructed final state')
                repeats=[[s[:n],s,d['output']] for s,(sc,d,h) in sorted(nodes.items()) for n in range(len(s)) if nodes[s[:n]][1]['output']==d['output']]
                need(eq(p['normal_form'],dict(path_normal=not repeats,ancestor_repeat_pairs=repeats)),'independent literal-repeat diagnostic')
                if hist:need(not repeats,'normal-form positive')
                if lane=='UNMARKED_INDEXED' and repeats:base_detours.append(cid)
                case['normal_forms'][lane]=not repeats;case['proof_lines'][lane]=[len(expected),len(p['original_proof'])];stats['coarse_lines']+=len(expected);stats['original_lines']+=len(p['original_proof'])
        if full['HISTORY_SCAN']['verified'] and full['HISTORY_INDEXED']['verified']:
            common+=1;a,b=full['HISTORY_SCAN']['positive'],full['HISTORY_INDEXED']['positive'];need(eq(a['actual_tree'],b['actual_tree']) and eq(a['coarse_proof'],b['coarse_proof']) and eq(a['original_proof'],b['original_proof']),'all common complete marked witnesses identical')
        if full['MATCHED_DEPTH_TREE_CONTROL']['status']=='NOT_DERIVABLE':
            control_neg.append(cid);need(not any(full[l]['verified'] for l in LANES if l!='MATCHED_DEPTH_TREE_CONTROL'),'no positive/control-negative contradiction')
        for l in ['HISTORY_SCAN','HISTORY_INDEXED']:
            if full[l]['status']=='UNSAT':history_neg.append([cid,l]);need(full['MATCHED_DEPTH_TREE_CONTROL']['status']=='NOT_DERIVABLE','bounded history negative agrees control')
        cases.append(case)
    need(stats['factory_audits']==45 and stats['positive_occurrences']==32 and stats['history_positive_occurrences']==14 and common==7,'whole main assurance census')
    need([counts[l]['verified'] for l in LANES]==[8,7,7,10] and [counts[l]['finite_negative'] for l in LANES]==[0,3,3,5] and [counts[l]['unknown'] for l in LANES]==[7,5,5,0],'all60 outcome positions')
    support=dict(schema='HN-main001-passive-math-support-v2',status='PASS',observer=pin(op),worker=o['worker_terminal']['result'],counts=counts,stats=stats,cases=cases,common_history_witnesses=common,control_finite_negatives=control_neg,history_finite_negatives=history_neg,unmarked_valid_detour_cases=base_detours,
        scope='Saved-data only. All45factory mathematical identities/definitions, every available returned actual state and retained complete query packet reconstructed symbolically from fixed compiled catalogue/current bound histories. All32coarse/original/lowering/check associations and14literal H certificates audited. All14H/old point certificate projections and native query field types additionally joined. No source helpers, proofcheckers, solvers, new target search or invisible trace suffix replay. Packet context is checked as recorded; no unexposed intermediate solver state is invented to bind it beyond the reviewed engine contract. Whole stream digests independently recomputed only when retained==total; other extents/hashes remain reported original commitments, not independently recovered suffixes. Catalogue preparation/zero audit are disclosed reused evidence. One budget-limited fixed-order study, no reliable speed or RL contribution claim.')
    p=ROOT/'review/main001-passive-math-support-v2.json';p.write_bytes(json.dumps(support,sort_keys=True,indent=2).encode()+b'\n')
    review=dict(schema='HN-main001-passive-math-review-v2',status='PASS',observer=pin(op),support=pin(p),stats=stats,verified_counts=[counts[l]['verified'] for l in LANES],finite_negative_counts=[counts[l]['finite_negative'] for l in LANES],unknown_counts=[counts[l]['unknown'] for l in LANES],common_history_witnesses=common,blockers=[],scientific_replays=0,scope=support['scope'])
    q=ROOT/'review/main001-passive-math-review-v2.json';q.write_bytes(json.dumps(review,sort_keys=True,indent=2).encode()+b'\n');print(json.dumps(dict(review=pin(q),support=pin(p),stats=stats,counts=counts)))


if __name__=='__main__':main()
