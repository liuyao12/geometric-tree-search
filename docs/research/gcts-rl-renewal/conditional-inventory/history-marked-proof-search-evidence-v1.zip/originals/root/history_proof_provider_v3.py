"""Inert history-normal-form producer. Exact old module is caller-injected.

Two lookup modes share one explicit marked model. No project imports, file IO,
solver, ancestry callback or implicit loader. Unbound history enumeration is finite
and charged, not promised scalable. All positive logical proofs remain unverified.
"""
import hashlib
import json
import math
import time

VERSION = 'HN-HISTORY-PATH-NORMAL-FORM-v1'
TAG = 'HN-history-v1'
QUERY_ABI = 'IP-CURRENT-TM-INCIDENT-v1'
SCOPE = ('Explicit finite history path-normal-form marking over the audited closed global producer inventory. '
         'Root-reachable only; bounded proof existence is preserved, not every proof/tiling or primitive-cost bound. '
         'No learned failure marking, rank oracle, RL or runtime result.')


class InputError(ValueError):
    pass


class _Stop(Exception):
    pass


def _need(ok, why):
    if not ok:
        raise InputError(why)


def _text(x):
    return json.dumps(x, ensure_ascii=True, sort_keys=True, separators=(',', ':'), allow_nan=False)


def _hp(site):
    return _text([TAG, site])


def _meter(base, limits):
    _need(base.VERSION == 'Z-ANCHORED-PROOF-PRODUCER-v1'
          and base._IndexedIncident.incident_query_abi == QUERY_ABI, 'BASE_ABI')
    try:
        return base._Meter(limits)
    except base.InputError as e:
        raise InputError('BASE_' + str(e)) from e


def _counts(formulas, depth, definitions, m):
    counts = []
    for level in range(depth + 1):
        m.tick((formulas.bit_length() + 1) * (level + 1) ** 2 + 1)
        value = math.comb(formulas - 1, level) if level < formulas else 0
        if value.bit_length() > 256:
            raise _Stop('HISTORY_COUNT_LIMIT')
        counts.append(value)
    m.tick(3 * len(definitions) + 1)
    arities = [sum(len(d[3]) == a for d in definitions) for a in range(3)]
    for level in range(depth + 1):
        own = (arities[0] if level == depth else sum(arities)) * counts[level]
        for child in (0, 1):
            parent = (sum(arities[1:]) if child == 0 else arities[2]) * counts[level - 1] if level else 0
            if (own + parent).bit_length() > 256:
                raise _Stop('HISTORY_COUNT_LIMIT')
    return tuple(counts)


def _identity(core, base_identity, depth, m):
    value = dict(schema='HN-history-normal-form-inventory-v1', version=VERSION,
                 compiled_core_sha256=core, depth=depth, history_point_tag=TAG,
                 history_rule='SIZE_EQUALS_SITE_DEPTH_OUTPUT_ABSENT_CHILD_UNION',
                 history_order='ASCENDING_LITERAL_FORMULA_ID', base_inventory_identity=base_identity)
    encoded = (_text(value) + '\n').encode('ascii'); m.tick(len(encoded) + 1)
    return hashlib.sha256(encoded).hexdigest()


def _placement(base, site, definition, history, colors, charge):
    charge(64 + 12 * len(history) * max(1, len(colors).bit_length()))
    row = base._placement(site, definition, colors, charge)
    row['id'] = _text([site, definition[0], list(history)])
    n = len(history) + 1
    charge(4 + n * (1 + n.bit_length()) * (1 + len(colors).bit_length()))
    next_history = sorted(history + (definition[2],))
    for i, point in enumerate([site] + [site + str(j) for j in range(len(definition[3]))]):
        charge(64 + 12 * (len(TAG) + len(point)))
        key, value = _hp(point), _text(list(history) if i == 0 else next_history)
        charge(8 + 12 * (len(key) + len(value)))
        row['m'].append([key, value])
    charge(2 + len(row['id']) + sum(len(p) for p, v in row['m']) * max(1, len(row['m']).bit_length()))
    row['m'].sort(key=lambda x: x[0])
    return row


def _combinations(formulas, size, omitted, reserve):
    """All combinations without an O(formulas) pool; depth <=32."""
    n = formulas - 1
    if size > n:
        return
    reserve((size + 1) * (1 + formulas.bit_length())); current = list(range(size))
    while True:
        reserve((size + 1) * (1 + formulas.bit_length()))
        yield tuple(j if j < omitted else j + 1 for j in current)
        k = size - 1
        while k >= 0 and current[k] == n - size + k:
            reserve(); k -= 1
        if k < 0:
            break
        current[k] += 1
        for j in range(k + 1, size):
            reserve(); current[j] = current[j - 1] + 1


_SUMS = ('potential_contacts', 'returned_contacts', 'definition_visits', 'ordinary_compatible_definitions',
         'history_excluded_definitions', 'history_conflict_definitions', 'history_parameters_tested',
         'history_tuples_constructed', 'history_literals_parsed', 'history_compatible_parameters',
         'capacity_pruned_contacts', 'lookup_work')
_MAXIMA = ('max_history_size', 'max_context_rows', 'max_literal_m_support')


class _Provider:
    incident_query_abi = QUERY_ABI
    __slots__ = ('_base', '_depth', '_identity', '_defs', '_colors', '_count', '_mode', '_groups',
                 '_index', '_calls', '_rows', '_work', '_seconds', '_describes', '_complete', '_stats')

    def __init__(self, base, depth, identity, definitions, colors, counts, mode, m):
        self._base, self._depth, self._identity = base, depth, identity
        self._defs, self._colors, self._count, self._mode = definitions, tuple(colors), counts, mode
        grouped = [[], [], []]
        for d in definitions:
            m.tick(); grouped[len(d[3])].append(d)
        self._groups = tuple(tuple(x) for x in grouped)
        self._index = tuple(base._IndexGroup(x, colors, m) for x in grouped) if mode == 'indexed' else None
        self._calls = self._rows = self._work = self._describes = self._complete = 0
        self._seconds = 0.0; self._stats = {k: 0 for k in _SUMS + _MAXIMA}

    @property
    def identity(self):
        return self._identity

    def _site(self, point, reserve):
        return self._base._IndexedIncident._site(self, point, reserve)

    def _families(self, point, reserve):
        rows = []
        for arity in range(3):
            reserve()
            if self._groups[arity] and self._count[len(point)] and (len(point) < self._depth or not arity):
                rows.append((point, arity))
        if point:
            for arity in ((1, 2) if point[-1] == '0' else (2,)):
                reserve()
                if self._groups[arity] and self._count[len(point) - 1]:
                    rows.append((point[:-1], arity))
        return rows

    def _ordinary(self, anchor, arity, marks, reserve, stats):
        start = self._work; points = [anchor] + [anchor + str(i) for i in range(arity)]
        rows, restrictions = self._groups[arity], []
        if self._index is not None:
            for role, point in enumerate(points):
                reserve(4 + len(point))
                if point in marks:
                    value = marks[point]; reserve(4 + 12 * len(value))
                    posting = self._index[arity].postings[role].get(value)
                    if posting is None:
                        stats['lookup_work'] += self._work - start
                        return []
                    restrictions.append(posting)
            ordinals = min(restrictions, key=len) if restrictions else range(len(rows))
        else:
            ordinals = range(len(rows))
        result = []
        for ordinal in ordinals:
            reserve(2 + len(points)); stats['definition_visits'] += 1
            d = rows[ordinal]
            if restrictions:
                good = all(ordinal in x for x in restrictions)
            else:
                values = (d[2],) + d[3]; good = True
                for p, f in zip(points, values):
                    reserve(4 + 12 * len(p))
                    if p in marks:
                        value, expected = marks[p], self._colors[f]
                        reserve(8 + 12 * (len(value) + len(expected)))
                        if value != expected:
                            good = False; break
            if good:
                result.append(d)
        stats['lookup_work'] += self._work - start
        stats['ordinary_compatible_definitions'] += len(result)
        return result

    def _history(self, site, marks, cache, reserve, stats):
        point = _hp(site); reserve(4 + 12 * len(point))
        if point not in marks:
            return False, None
        if point in cache:
            return True, cache[point]
        value = marks[point]; reserve(8 + 12 * len(value)); stats['history_literals_parsed'] += 1
        try:
            row = json.loads(value)
        except (ValueError, RecursionError):
            row = None
        reserve(4 + len(site) * (1 + len(site).bit_length()) * (1 + len(self._colors).bit_length()))
        valid = (type(row) is list and len(row) == len(site)
                 and all(type(i) is int and 0 <= i < len(self._colors) for i in row)
                 and row == sorted(set(row)) and _text(row) == value)
        if valid:
            reserve(len(row) + 1); row = tuple(row); stats['history_tuples_constructed'] += 1
            stats['max_history_size'] = max(stats['max_history_size'], len(row))
        else:
            row = None  # Literal mismatch, not a malformed transport query.
        cache[point] = row
        return True, row

    def _histories(self, anchor, arity, output, marks, cache, reserve, stats):
        own_bound, own = self._history(anchor, marks, cache, reserve, stats)
        children = []
        for i in range(arity):
            bound, value = self._history(anchor + str(i), marks, cache, reserve, stats)
            if bound:
                children.append(value)
        reserve(4 + len(children) + sum(len(x) for x in children if x is not None) * (1 + len(self._colors).bit_length()))
        if own_bound and own is None or any(x is None for x in children):
            stats['history_conflict_definitions'] += 1; return
        if children and any(x != children[0] for x in children[1:]):
            stats['history_conflict_definitions'] += 1; return
        child = children[0] if children else None
        if own_bound:
            reserve(4 + len(own) * (1 + len(self._colors).bit_length()))
            stats['history_parameters_tested'] += 1
            if output in own:
                stats['history_excluded_definitions'] += 1; return
            if child is not None:
                n = len(own) + 1
                reserve(4 + n * (1 + n.bit_length()) * (1 + len(self._colors).bit_length()))
                if tuple(sorted(own + (output,))) != child:
                    stats['history_conflict_definitions'] += 1; return
            yield own
        elif child is not None:
            reserve(4 + len(child) * (1 + len(self._colors).bit_length()))
            if output not in child:
                stats['history_conflict_definitions'] += 1; return
            reserve(len(child) + 1); value = tuple(x for x in child if x != output)
            stats['history_tuples_constructed'] += 1; stats['history_parameters_tested'] += 1
            yield value
        else:
            # Reserve the exact finite variant count before any unbound expansion.
            reserve(self._count[len(anchor)])
            for value in _combinations(len(self._colors), len(anchor), output, reserve):
                stats['history_parameters_tested'] += 1; stats['history_tuples_constructed'] += 1
                stats['max_history_size'] = max(stats['max_history_size'], len(value))
                yield value

    def __call__(self, query, charge):
        started = time.perf_counter(); self._calls += 1
        stats = {k: 0 for k in _SUMS + _MAXIMA}
        def reserve(n=1):
            charge(n); self._work += n
        try:
            point, totals, marks, context_hash = self._base._IndexedIncident._context(self, query, reserve)
            stats['max_context_rows'] = len(totals) + len(marks)
            result, cache = [], {}
            for anchor, arity in self._families(point, reserve):
                potential = len(self._groups[arity]) * self._count[len(anchor)]
                stats['potential_contacts'] += potential
                support = [anchor] + [anchor + str(i) for i in range(arity)]
                reserve(4 + sum(len(p) for p in support))
                if any(totals.get(p, 0) + 1 > 2 for p in support):
                    stats['capacity_pruned_contacts'] += potential; continue
                for d in self._ordinary(anchor, arity, marks, reserve, stats):
                    for history in self._histories(anchor, arity, d[2], marks, cache, reserve, stats):
                        row = _placement(self._base, anchor, d, history, self._colors, reserve)
                        stats['history_compatible_parameters'] += 1
                        stats['max_literal_m_support'] = max(stats['max_literal_m_support'], len(row['m']))
                        result.append(row)
            reserve(sum(len(r['id']) for r in result) * max(1, len(result).bit_length()) + 1)
            result.sort(key=lambda r: r['id']); stats['returned_contacts'] = len(result)
            for k in _SUMS:
                self._stats[k] += stats[k]
            for k in _MAXIMA:
                self._stats[k] = max(self._stats[k], stats[k])
            self._complete += 1; self._rows += len(result)
            return dict(point=point, context_sha256=context_hash, complete=True, placements=result,
                        certificate=dict(scope='COMPLETE_CURRENT_TM_COMPATIBLE_INCIDENT_SET',
                                         potential_count=stats['potential_contacts'], compatible_count=len(result)))
        except self._base.InputError as e:
            raise InputError('QUERY_' + str(e)) from e
        finally:
            self._seconds += time.perf_counter() - started

    def describe(self, point, charge):
        started = time.perf_counter(); self._describes += 1
        def reserve(n=1):
            charge(n); self._work += n
        try:
            point = self._site(point, reserve); rows = []; tdep = set(); mdep = set(); total = 0
            for anchor, arity in self._families(point, reserve):
                reserve(8 + len(self._groups[arity]))
                reserve(64 + 12 * len(anchor) + sum(len(d[0]) for d in self._groups[arity]))
                support = [anchor] + [anchor + str(i) for i in range(arity)]
                reserve(8 + sum(12 * (len(TAG) + len(p)) for p in support) * (1 + (2 * len(support)).bit_length()))
                marked = sorted(support + [_hp(p) for p in support])
                count = len(self._groups[arity]) * self._count[len(anchor)]; total += count
                rows.append(dict(id=_text(['HN-history-arity-v1', anchor, arity]), anchor=anchor, arity=arity,
                                 definition_ids=[d[0] for d in self._groups[arity]], t_points=sorted(support),
                                 m_points=marked, history_size=len(anchor),
                                 histories_per_definition=self._count[len(anchor)], potential_count=count))
                tdep.update(support); mdep.update(marked)
            reserve(1 + sum(len(r['id']) for r in rows) * max(1, len(rows).bit_length())
                    + sum(map(len, tdep)) * max(1, len(tdep).bit_length())
                    + sum(map(len, mdep)) * max(1, len(mdep).bit_length()))
            rows.sort(key=lambda r: r['id'])
            return dict(point=point, inventory_identity=self._identity, complete=True, families=rows,
                        dependencies=dict(t=sorted(tdep), m=sorted(mdep)), potential_count=total,
                        scope='COMPLETE_STATIC_HISTORY_OWN_AND_ALL_PARENT_ALIGNMENT_FAMILIES')
        except self._base.InputError as e:
            raise InputError('DESCRIBE_' + str(e)) from e
        finally:
            self._seconds += time.perf_counter() - started

    def snapshot(self):
        return dict(identity=self._identity, mode=self._mode, calls=self._calls, rows=self._rows,
                    charged_work=self._work, seconds=self._seconds, depth=self._depth,
                    incident_query_abi=QUERY_ABI, completed_packets=self._complete, describe_calls=self._describes,
                    index_rows=len(self._defs), index_postings=sum(x.memberships for x in self._index) if self._index else 0,
                    complete_packet_counts=dict(self._stats),
                    scope='Attempt/work/time cumulative across errors and rollback; other counts merge only complete packets, with per-query/per-definition multiplicity. Not unique universe, solver state or inferred suffix.')


def make_provider(base_module, compiled, generation, depth, limits, *, mode='indexed'):
    _need(type(mode) is str and mode in ('scan', 'indexed'), 'MODE')
    m = _meter(base_module, limits)
    try:
        _need(type(generation) is dict, 'GENERATION_REQUIRED')
        c, definitions, core, base_identity = base_module._prepare(compiled, generation, depth, m)
        counts = _counts(len(c['logical_basis']['formulas']), depth, definitions, m)
        identity = _identity(core, base_identity, depth, m)
        provider = _Provider(base_module, depth, identity, definitions, c['logical_basis']['colors'], counts, mode, m)
        m.tick(len(definitions) * 24 + 1)
        keys = ('id', 'kind', 'output', 'premises', 'zero_id', 'variable', 'native_rule')
        descriptions = [dict(zip(keys, (d[0], d[1], d[2], list(d[3]), d[4], d[5], d[6]))) for d in definitions]
        model = dict(schema='Z-growing-point-model-v1', version=VERSION, capacity=2, roots=[''],
                     seed=dict(t=[['', 1]], m=[['', c['logical_basis']['colors'][c['goal_id']]], [_hp(''), '[]']]),
                     inventory=dict(kind='CERTIFIED_INCIDENT', identity=identity))
        value = dict(depth=depth, compiled_core_sha256=core, identity=identity, base_identity=base_identity,
                     definitions=descriptions, formula_count=len(c['logical_basis']['formulas']),
                     potential_sites=(1 << (depth + 1)) - 1, history_point_tag=TAG,
                     history_cardinalities=list(counts), scope=SCOPE)
        m.tick()
        return model, provider, dict(schema='HN-history-provider-result-v1', version=VERSION,
                                    status='COMPLETE', reason=None, value=value, costs=m.costs())
    except (base_module._Stop, _Stop) as e:
        return None, None, dict(schema='HN-history-provider-result-v1', version=VERSION,
                               status='UNKNOWN', reason=str(e), value=None, costs=m.costs())
    except base_module.InputError as e:
        raise InputError('BASE_' + str(e)) from e


def decode(base_module, compiled, depth, selected, limits):
    m = _meter(base_module, limits)
    try:
        _need(type(selected) is list, 'SELECTED')
        if len(selected) > m.limits['max_proof_lines']:
            raise _Stop('PROOF_LINE_LIMIT')
        c, definitions, core, old_identity = base_module._prepare(compiled, None, depth, m)
        m.tick(4 + 3 * len(definitions) + len(selected))
        table = {d[0]: d for d in definitions}; sites = {}; base_selected = []
        for cid in selected:
            _need(type(cid) is str, 'CID'); m.tick(4 + 12 * len(cid))
            try:
                row = json.loads(cid)
            except (ValueError, RecursionError) as e:
                raise InputError('CID') from e
            _need(type(row) is list and len(row) == 3 and type(row[0]) is str
                  and type(row[1]) is str and row[1] in table, 'CID_SHAPE')
            site, did, history = row; d = table[did]
            _need(len(site) <= depth and all(x in '01' for x in site) and site not in sites, 'SITE')
            m.tick(4 + (len(site) + 1) * (1 + (len(site) + 1).bit_length()) * (1 + len(c['logical_basis']['formulas']).bit_length()))
            _need(type(history) is list and len(history) == len(site)
                  and all(type(i) is int and 0 <= i < len(c['logical_basis']['formulas']) for i in history)
                  and history == sorted(set(history)) and d[2] not in history, 'HISTORY')
            _need(_text(row) == cid, 'CANONICAL_CID')
            _need(len(site) < depth or not d[3], 'CHILD_OUTSIDE_DEPTH')
            sites[site] = (cid, d, tuple(history)); base_selected.append(_text([site, did]))
        _need('' in sites and sites[''][2] == (), 'ROOT_HISTORY')
        for site, (cid, d, history) in sites.items():
            n = len(history) + 1
            m.tick(4 + len(site) + n * (1 + n.bit_length()) * (1 + len(c['logical_basis']['formulas']).bit_length()))
            expected = tuple(sorted(history + (d[2],)))
            for i in range(len(d[3])):
                child = site + str(i)
                m.tick(8 + len(child) + len(expected) * (1 + len(c['logical_basis']['formulas']).bit_length()))
                _need(child in sites and sites[child][2] == expected, 'CHILD_HISTORY_UNION')
        m.tick(1 + sum(map(len, base_selected)) * max(1, len(base_selected).bit_length()))
        remaining = dict(m.limits); remaining['max_work'] -= m.work
        remaining['wall_seconds'] -= time.perf_counter() - m.started
        if remaining['wall_seconds'] <= 0:
            raise _Stop('WALL_LIMIT')
        base_selected.sort()
        ordinary = base_module.decode(c, depth, base_selected, remaining)
        m.tick(ordinary['costs']['work'])
        if ordinary['status'] == 'UNKNOWN':
            raise _Stop('BASE_DECODE_' + str(ordinary['reason']))
        _need(ordinary['status'] == 'UNVERIFIED_CERTIFICATE', 'BASE_DECODE_STATUS')
        colors = c['logical_basis']['colors']; placements = []
        m.tick(2 + len(sites) + sum(map(len, sites)) * max(1, len(sites).bit_length()))
        ordered = sorted(sites)
        for site in ordered:
            cid, d, history = sites[site]
            placements.append(_placement(base_module, site, d, history, colors, m.tick))
        m.tick(2 + sum(len(p['id']) for p in placements) * max(1, len(placements).bit_length())
               + sum(map(len, selected)) * max(1, len(selected).bit_length()))
        placements.sort(key=lambda p: p['id'])
        tree = dict(ordinary['tree']); tree['selected'] = sorted(selected); tree['placements'] = placements
        histories, extra_marks = [], []
        for site in ordered:
            history = sites[site][2]
            m.tick(64 + 12 * (len(TAG) + len(site)) + 12 * len(history) * (1 + len(colors).bit_length()))
            histories.append([site, list(history)])
            extra_marks.append([_hp(site), _text(list(history)), 2])
        all_marks = ordinary['tree']['marks'] + extra_marks
        m.tick(2 + sum(len(p) for p, v, n in all_marks) * max(1, len(all_marks).bit_length()))
        tree['histories'] = histories; tree['marks'] = sorted(all_marks, key=lambda r: r[0])
        m.tick(1 + len(placements) * max(1, len(placements).bit_length()))
        return dict(status='UNVERIFIED_CERTIFICATE', reason=None, proof=ordinary['proof'], target=ordinary['target'],
                    tree=tree, base_selected=base_selected, base_decoded=ordinary, costs=m.costs(), scope=SCOPE)
    except (base_module._Stop, _Stop) as e:
        return dict(status='UNKNOWN', reason=str(e), proof=None, target=None, tree=None,
                    base_selected=None, base_decoded=None, costs=m.costs(), scope=SCOPE)
    except base_module.InputError as e:
        raise InputError('BASE_' + str(e)) from e
