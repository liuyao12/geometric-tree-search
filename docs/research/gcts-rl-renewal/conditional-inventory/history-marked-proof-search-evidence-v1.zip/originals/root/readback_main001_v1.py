"""Root passive readback of existing bytes and assurance associations only."""
import gzip
import hashlib
import json
from pathlib import Path

R = Path(__file__).resolve().parents[1]


def pin(p):
    b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())


def read(ref):
    p = Path(ref['path'])
    assert pin(p) == ref
    return p.read_bytes()


def artifact(ref):
    b = read(ref['stored'])
    if ref['encoding'] == 'gzip-json':
        b = gzip.decompress(b)
    else:
        assert ref['encoding'] == 'json'
    assert len(b) == ref['raw_bytes']
    assert hashlib.sha256(b).hexdigest() == ref['raw_sha256']
    return json.loads(b)


o = json.loads((R/'actual/study-001/observer-result.json').read_bytes())
assert o['status'] == 'COMPLETE' and o['returncode'] == 0
assert all(o[x] for x in ('both_streams_EOF', 'group_gone', 'wait_confirmed'))
assert not o['cleanup_errors'] and o['failure'] is None
for ref in o['files']:
    read(ref)
assert len(list((R/'actual/study-001').iterdir())) == len(o['files']) + 1 == 173
w = artifact(o['worker_terminal']['result'])
for ref in w['artifacts']:
    artifact(ref)
e = w['experiment']
lanes = e['design']['lanes']
assert len(e['results']) == 15 and len(lanes) == 4
assert [c['id'] for c in e['results']] == e['design']['case_order']
totals = {k:dict(positive=0, finite_negative=0, unknown=0) for k in lanes}
coarse = original = positives = 0
for case in e['results']:
    assert set(case['lanes']) == set(lanes)
    for k in lanes:
        compact = case['lanes'][k]
        full = artifact(compact['ref'])
        assert full['status'] == compact['status'] and full['verified'] is compact['verified']
        if compact['verified']:
            p = artifact(compact['positive_ref'])
            assert p['verified'] is True
            for check in ('tree_audit', 'coarse_host_check', 'original_host_check'):
                assert p[check]['status'] == 'VERIFIED'
            assert p['lowering']['status'] == 'COMPLETE'
            if k.startswith('HISTORY_'):
                assert p['history_audit']['status'] == 'VERIFIED'
            assert len(p['coarse_proof']) == compact['coarse_lines']
            assert len(p['original_proof']) == compact['original_lines']
            coarse += len(p['coarse_proof'])
            original += len(p['original_proof'])
            positives += 1
            totals[k]['positive'] += 1
        elif compact['status'] in ('UNSAT', 'NOT_DERIVABLE'):
            totals[k]['finite_negative'] += 1
        else:
            assert compact['status'] == 'UNKNOWN'
            totals[k]['unknown'] += 1
assert [totals[k]['positive'] for k in lanes] == [8, 7, 7, 10]
assert [totals[k]['finite_negative'] for k in lanes] == [0, 3, 3, 5]
assert positives == 32 and coarse == 385 and original == 459
receipt = dict(schema='HNF-Root-main001-passive-readback-v1', status='PASS',
    observer=pin(R/'actual/study-001/observer-result.json'), script=pin(Path(__file__).resolve()),
    physical_files=173, emitted_artifacts=len(w['artifacts']), positions=60,
    all_file_and_artifact_hashes=True, positive_occurrences=positives,
    coarse_lines=coarse, original_lines=original, totals=totals,
    scope='Byte and recorded-assurance joins only. No solver, proof kernel or search replay. Independent mathematical review separately required.')
out = R/'root/main001-Root-readback-v1.json'
with out.open('x') as f:
    json.dump(receipt, f, sort_keys=True, indent=2)
    f.write('\n')
print(json.dumps(pin(out), sort_keys=True))
