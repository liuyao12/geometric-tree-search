"""Independent passive projection checks. No scientific modules are imported."""
import gzip
import hashlib
import io
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent
LANES = ('UNMARKED_INDEXED', 'HISTORY_SCAN', 'HISTORY_INDEXED', 'MATCHED_DEPTH_TREE_CONTROL')


def need(ok, why):
    if not ok:
        raise RuntimeError(why)


def compact(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(',', ':'), allow_nan=False)


def safe_numbers(value):
    if type(value) is int and not -(2 ** 53 - 1) <= value <= 2 ** 53 - 1:
        return str(value)
    if type(value) is list:
        return [safe_numbers(x) for x in value]
    if type(value) is dict:
        return {k: safe_numbers(v) for k, v in value.items()}
    return value


def ref(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def read_pin(pin):
    p = Path(pin['path'])
    need(p.is_absolute() and p.resolve() == p and p.is_relative_to(BASE), 'Task-owned referenced original')
    with p.open('rb') as stream:
        data = stream.read(pin['bytes'] + 1)
    need(len(data) == pin['bytes'] and hashlib.sha256(data).hexdigest() == pin['sha256'], 'Whole raw reference')
    return data


def record(pin):
    data = read_pin(pin['stored'])
    if pin['encoding'] == 'gzip-json':
        with gzip.GzipFile(fileobj=io.BytesIO(data)) as stream:
            data = stream.read(pin['raw_bytes'] + 1)
    else:
        need(pin['encoding'] == 'json', 'Declared encoding')
    need(len(data) == pin['raw_bytes'] and hashlib.sha256(data).hexdigest() == pin['raw_sha256'], 'Whole decoded artifact')
    return json.loads(data)


def proof_shape(proof, goal, check):
    need(proof and proof[-1]['formula'] == goal and check['status'] == 'VERIFIED'
         and check['checked_lines'] == len(proof), 'Actual target/check line count')
    for i, line in enumerate(proof):
        refs = [line['antecedent'], line['implication']] if line['rule'] == 'mp' else (
            [line['source']] if line['rule'] == 'generalize' else [])
        need(all(type(j) is int and 0 <= j < i for j in refs), 'Earlier proof premises')


def main():
    root = BASE/'root'
    actual = BASE/'actual/study-001'
    published = BASE/'report/rendered-v1'
    observer = json.loads((actual/'observer-result.json').read_bytes())
    need(observer['status'] == 'COMPLETE' and observer['returncode'] == 0
         and observer['both_streams_EOF'] and observer['group_gone'], 'Current complete process')
    worker = record(observer['worker_terminal']['result'])
    exp = worker['experiment']
    plan = json.loads(read_pin(observer['worker_terminal']['plan']))
    inputs = {x['name']: x for x in json.loads(read_pin(plan['metadata']['frozen_inputs']))['inputs']}
    doc = json.loads((published/'history-marked-proof-search-results-v1.json').read_bytes())
    reader = doc['reader']
    need(doc['design'] == safe_numbers(exp['design']) and tuple(exp['design']['lanes']) == LANES, 'Actual design')
    need([c['id'] for c in reader['cases']] == [c['id'] for c in exp['results']]
         == exp['design']['case_order'] and len(reader['cases']) == 15, 'All ordered cases')
    counts = {k: dict(verified=0, finite_exhausted=0, unknown=0, search_seconds=0.0) for k in LANES}
    details, positives, history_nodes, coarse_lines, original_lines, checked_tiles = [], 0, 0, 0, 0, 0
    traces = dict(streams=0, retained_rows=0, total_rows=0,
                  complete_digests_recomputed=0, streams_with_omitted_suffix=0)
    for native_case, public_case in zip(exp['results'], reader['cases']):
        cid = native_case['id']
        prep = record(inputs[cid + '-whole-preparation'])
        compiled = record(inputs[cid + '-whole-build'])['compiled']
        forms = compiled['logical_basis']['formulas']
        fids = {compact(f): i for i, f in enumerate(forms)}
        need(public_case['problem'] == safe_numbers(native_case['original'])
             and public_case['lemma_bindings'] == safe_numbers(prep['application']['lemma_bindings']), 'Original statement/axiom/import context')
        fulls = {}
        for lane in LANES:
            pointer = native_case['lanes'][lane]['ref']
            item = record(pointer); fulls[lane] = item
            view = public_case['lanes'][lane]
            need(view['source_ref'] == safe_numbers(pointer) and view['status'] == item['status']
                 and view['seconds'] == item['search_seconds'] and view['reason'] == item['reason'], 'Recorded lane/result/timing projection')
            need(view['stats'] == safe_numbers((item.get('result') or {}).get('stats', {}))
                 and view['provider'] == safe_numbers(item.get('provider', {})), 'Exact telemetry and integer encoding')
            positive = item.get('positive', {})
            yes = item['verified']
            assurance = lane == LANES[-1] or item['factory_audit']['status'] == 'VERIFIED'
            negative = item['status'] in ('UNSAT', 'NOT_DERIVABLE') and assurance
            counts[lane]['verified'] += int(yes)
            counts[lane]['finite_exhausted'] += int(negative)
            counts[lane]['unknown'] += int(not yes and not negative)
            counts[lane]['search_seconds'] += item['search_seconds']
            expected_status = 'VERIFIED' if yes else 'UNKNOWN_FACTORY_AUDIT' if not assurance else positive.get('reason', 'NO_CERTIFICATE')
            need(view['original_status'] == expected_status, 'Assurance status is separate from raw SAT')
            if lane != LANES[-1] and item.get('result') is not None:
                result = item['result']
                for rows, extent in [(result['events'], result['event_extent']),
                                     (result['rollback_records'], result['rollback_extent']),
                                     (result['provider_evidence']['records'], result['provider_evidence'])]:
                    need(len(rows) == extent['retained'] <= extent['total'], 'Actual saved prefix')
                    traces['streams'] += 1; traces['retained_rows'] += len(rows); traces['total_rows'] += extent['total']
                    if extent['total'] == len(rows):
                        hashed = hashlib.sha256()
                        for row in rows:
                            hashed.update((compact(row) + '\n').encode('ascii'))
                        need(hashed.hexdigest() == extent['sha256'], 'Complete original stream hash')
                        traces['complete_digests_recomputed'] += 1
                    else:
                        traces['streams_with_omitted_suffix'] += 1
            if not yes:
                need(view['coarse_proof'] == view['original_proof'] == [] and view['tree'] is None, 'No invented refused certificate')
                continue
            positives += 1
            need(assurance and all(positive[k]['status'] == 'VERIFIED' for k in
                ('tree_audit', 'lowering_audit', 'coarse_host_check', 'original_host_check')), 'Complete actual positive check chain')
            need(view['coarse_proof'] == positive['coarse_proof']
                 and view['original_proof'] == positive['original_proof']
                 and view['tree'] == safe_numbers(positive['actual_tree'])
                 and view['lowering'] == safe_numbers(positive['lowering']), 'Whole proofs/tree/lowering are actual')
            proof_shape(view['coarse_proof'], native_case['original']['goal'], positive['coarse_host_check'])
            proof_shape(view['original_proof'], native_case['original']['goal'], positive['original_host_check'])
            coarse_lines += len(view['coarse_proof']); original_lines += len(view['original_proof'])
            proof, tree = positive['coarse_proof'], positive['actual_tree']
            sites = dict(tree['site_to_line']); need(len(sites) == len(proof), 'Whole node-to-line map')
            outputs = {s: fids[compact(proof[i]['formula'])] for s, i in sites.items()}
            for tile in tree['placements']:
                site = json.loads(tile['id'])[0]; line = proof[sites[site]]; marks = dict(tile['m'])
                checked_tiles += 1
                children = [site + str(i) for i in range(2 if line['rule'] == 'mp' else 1 if line['rule'] == 'generalize' else 0)]
                need(sorted(tile['t']) == sorted([[s, 1] for s in [site] + children]), 'Literal half-capacity glyph support')
                for s in [site] + children:
                    need(marks[s] == compact(proof[sites[s]]['formula']), 'Formula marking matches actual displayed proof line')
                if lane.startswith('HISTORY_'):
                    need(positive['history_audit']['status'] == 'VERIFIED', 'Actual independent history check')
                    incoming = json.loads(tile['id'])[2]
                    expected = sorted(outputs[site[:i]] for i in range(len(site)))
                    need(incoming == expected and len(set(incoming)) == len(incoming)
                         and outputs[site] not in incoming, 'Literal proper-ancestor history')
                    need(tree['history_by_site'][site] == [forms[i] for i in incoming]
                         and marks[compact(['HN-history-v1', site])] == compact(incoming), 'Purple history uses actual AST and literal value')
                    for child in children:
                        need(marks[compact(['HN-history-v1', child])] == compact(sorted(incoming + [outputs[site]])), 'Actual outgoing child history')
                    history_nodes += 1
            details.append(dict(case=cid, lane=lane, coarse_lines=len(proof),
                                original_lines=len(positive['original_proof']), actual_tiles=len(tree['placements'])))
        a, b = fulls['HISTORY_SCAN'], fulls['HISTORY_INDEXED']
        if a['verified'] and b['verified']:
            need(a['positive']['actual_tree'] == b['positive']['actual_tree']
                 and a['positive']['coarse_proof'] == b['positive']['coarse_proof'], 'Paired current marked witnesses')
    for lane in LANES:
        for key, value in counts[lane].items():
            need(reader['counts'][lane][key] == value, 'Recomputed method totals')
    need(reader['provenance']['main_trace_census'] == traces, 'Public trace census')
    wording = ' '.join(reader['findings'] + reader['cost_notes'] + reader['assessment'])
    need('mixed coverage' in wording and 'earlier work-limit refusals' in wording
         and 'streams have omitted suffixes' in wording and 'fixed catalogue and depth bound' in wording,
         'Mixed outcome/resource/trace scope is visible')
    result = dict(schema='HNF-current-report-complete-passive-content-review-v1',
        status='PASS_SAVED_DATA_CONTENT', blockers=[], observer=ref(actual/'observer-result.json'),
        report_json=ref(published/'history-marked-proof-search-results-v1.json'),
        report_html=ref(published/'history-marked-proof-search-v1.html'),
        cases=15, positions=60, positive_proof_pairs=positives,
        coarse_lines=coarse_lines, original_lines=original_lines, actual_tile_bindings=checked_tiles,
        history_tile_bindings=history_nodes, counts=counts, main_trace_census=traces,
        positive_details=details,
        scope='Every saved projected case/result/proof/tree/history/telemetry/trace record compared with current originals. This is data projection validation, not a fresh logical kernel or search replay. Browser/MathJax/layout and archive admission are separate.',
        scientific_replays=0)
    destination = BASE/'report/report-content-review-v1.json'
    with destination.open('x') as stream:
        json.dump(result, stream, sort_keys=True, indent=2); stream.write('\n')
    print(json.dumps(ref(destination), sort_keys=True))


if __name__ == '__main__':
    main()
