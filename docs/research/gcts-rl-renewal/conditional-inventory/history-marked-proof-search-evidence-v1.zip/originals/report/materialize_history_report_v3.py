"""Passive complete-observation projection. No scientific imports or calls."""
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path

LANES = ('UNMARKED_INDEXED', 'HISTORY_SCAN', 'HISTORY_INDEXED', 'MATCHED_DEPTH_TREE_CONTROL')
JS_SAFE = (1 << 53) - 1


def need(ok, reason):
    if not ok:
        raise RuntimeError(reason)


def raw(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')


def text(value):
    return raw(value).decode('ascii').rstrip('\n')


def pin(path):
    data = Path(path).read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def read_ref(ref):
    need(type(ref) is dict and {'path', 'bytes', 'sha256'} <= set(ref), 'raw reference')
    need(type(ref['bytes']) is int and 0 <= ref['bytes'] <= 67108864, 'stored extent')
    with Path(ref['path']).open('rb') as stream:
        data = stream.read(ref['bytes'] + 1)
    need(len(data) == ref['bytes'] and hashlib.sha256(data).hexdigest() == ref['sha256'], 'whole raw reference')
    return data


def artifact(ref):
    need(type(ref['raw_bytes']) is int and 0 <= ref['raw_bytes'] <= 67108864, 'raw extent')
    data = read_ref(ref['stored'])
    if ref['encoding'] == 'gzip-json':
        with gzip.GzipFile(fileobj=io.BytesIO(data), mode='rb') as stream:
            data = stream.read(ref['raw_bytes'] + 1)
    else:
        need(ref['encoding'] == 'json', 'encoding')
    need(len(data) == ref['raw_bytes'] and hashlib.sha256(data).hexdigest() == ref['raw_sha256'], 'complete raw artifact')
    return json.loads(data)


def browser_numbers(value):
    """Do not round integer telemetry when JSON is consumed by JavaScript."""
    if type(value) is int and abs(value) > JS_SAFE:
        return str(value)
    if type(value) is list:
        return [browser_numbers(x) for x in value]
    if type(value) is dict:
        return {k: browser_numbers(x) for k, x in value.items()}
    return value


def trace_extent(records, extent, census):
    """Check the saved prefix extent; rehash only an actually complete stream."""
    need(type(records) is list and type(extent['total']) is int
         and type(extent['retained']) is int
         and 0 <= extent['retained'] <= extent['total']
         and len(records) == extent['retained'], 'saved trace prefix extent')
    census['streams'] += 1
    census['retained_rows'] += len(records)
    census['total_rows'] += extent['total']
    if extent['retained'] == extent['total']:
        digest = hashlib.sha256()
        for row in records:
            digest.update(raw(row))
        need(digest.hexdigest() == extent['sha256'], 'complete saved trace digest')
        census['complete_digests_recomputed'] += 1
    else:
        census['streams_with_omitted_suffix'] += 1


def checked_tree(positive, compiled, lane):
    tree = positive['actual_tree']
    proof = positive['coarse_proof']
    need(type(tree) is dict and tree['node_count'] == len(proof), 'actual tree')
    by_site = dict(tree['site_to_line'])
    need(len(by_site) == len(proof) and set(by_site.values()) == set(range(len(proof))), 'site-to-line bijection')
    placements = {p['id']: p for p in tree['placements']}
    need(len(placements) == len(proof) and sorted(placements) == sorted(tree['selected']), 'actual placement IDs')
    need(all(type(n) is int and n == 1 for p in placements.values() for site, n in p['t']),
         'half-capacity glyph matches actual unit contributions')
    if not lane.startswith('HISTORY_'):
        return tree
    need(positive['history_audit']['status'] == 'VERIFIED'
         and positive['normal_form']['path_normal'] is True, 'history assurance')
    forms = compiled['logical_basis']['formulas']
    formula_ids = {text(f): i for i, f in enumerate(forms)}
    display = {}
    for cid, row in placements.items():
        value = json.loads(cid)
        need(type(value) is list and len(value) == 3, 'history CID')
        site, definition, incoming = value
        need(site in by_site and type(incoming) is list and len(incoming) == len(site)
             and all(type(i) is int and 0 <= i < len(forms) for i in incoming)
             and incoming == sorted(set(incoming)), 'literal incoming history')
        line = proof[by_site[site]]
        out = formula_ids[text(line['formula'])]
        need(out not in incoming, 'own output absent')
        marks = dict(row['m'])
        need(marks[text(['HN-history-v1', site])] == text(incoming), 'actual incoming marking')
        expected = [forms[i] for i in incoming]
        need(tree['history_by_site'][site] == expected, 'displayed history AST binding')
        display[site] = expected
        children = [site + str(i) for i in range(2 if line['rule'] == 'mp' else 1 if line['rule'] == 'generalize' else 0)]
        need(sorted(p for p, n in row['t']) == sorted([site] + children), 'actual premise receptors')
        for child in children:
            need(child in by_site and marks[text(['HN-history-v1', child])] == text(sorted(incoming + [out])),
                 'actual outgoing history marking')
    need(display == tree['history_by_site'], 'all displayed history sites')
    return tree


def main():
    parser = argparse.ArgumentParser()
    for key in ('observer', 'qualification', 'admission', 'out'):
        parser.add_argument('--' + key, required=True)
    args = parser.parse_args()
    observer = json.loads(Path(args.observer).read_bytes())
    need(observer['status'] == 'COMPLETE' and observer['returncode'] == 0
         and observer['both_streams_EOF'] and observer['group_gone'], 'complete process evidence')
    exp = artifact(observer['worker_terminal']['result'])['experiment']
    admission = json.loads(Path(args.admission).read_bytes())
    qualification = json.loads(Path(args.qualification).read_bytes())
    need(admission['status'] == qualification['status'] == 'ADMITTED', 'current scientific admissions')
    plan = json.loads(read_ref(observer['worker_terminal']['plan']))
    manifest = json.loads(read_ref(plan['metadata']['frozen_inputs']))
    inputs = {x['name']: x for x in manifest['inputs']}
    bank = artifact(inputs['current-bank-and-native-checks'])['result']['value']
    design = exp['design']
    need(exp['status'] == 'COMPLETE' and tuple(design['lanes']) == LANES
         and design['depth'] == 8 and design['search_seconds'] == 2, 'fixed comparison')
    need(len(exp['results']) == 15 and [x['id'] for x in exp['results']] == design['case_order']
         and len(set(design['case_order'])) == 15, 'all fifteen frozen cases')
    counts = {k: dict(verified=0, unknown=0, finite_exhausted=0, search_seconds=0.0,
                      candidate_registrations=0, provider_rows=0, potential_contacts=0) for k in LANES}
    cases, source_refs = [], []
    traces = dict(streams=0, retained_rows=0, total_rows=0,
                  complete_digests_recomputed=0, streams_with_omitted_suffix=0)
    for row in exp['results']:
        prep = artifact(inputs[row['id'] + '-whole-preparation'])
        compiled = artifact(inputs[row['id'] + '-whole-build'])['compiled']
        case = {'id': row['id'], 'group': 'Arithmetic' if '-arith-' in row['id'] else
                'Typing' if '-typing-' in row['id'] else 'Incidence', 'depth': row['depth'],
                'problem': row['original'], 'lemma_bindings': prep['application']['lemma_bindings'], 'lanes': {}}
        for lane in LANES:
            compact = row['lanes'][lane]
            full = artifact(compact['ref'])
            need(compact['status'] == full['status'] and compact['verified'] is full['verified'], 'lane projection')
            yes, positive = full['verified'], full.get('positive', {})
            assurance = lane == 'MATCHED_DEPTH_TREE_CONTROL' or full.get('factory_audit', {}).get('status') == 'VERIFIED'
            tree = None
            if yes:
                need(positive['verified'] is True and assurance and all(positive[k]['status'] == 'VERIFIED'
                    for k in ('tree_audit', 'lowering_audit', 'coarse_host_check', 'original_host_check')), 'positive proof checks')
                tree = checked_tree(positive, compiled, lane)
            negative = full['status'] in ('UNSAT', 'NOT_DERIVABLE') and assurance
            counts[lane]['verified'] += int(yes)
            counts[lane]['finite_exhausted'] += int(negative)
            counts[lane]['unknown'] += int(not yes and not negative)
            counts[lane]['search_seconds'] += full['search_seconds']
            stats = (full.get('result') or {}).get('stats', {})
            for key in ('candidate_registrations', 'provider_rows'):
                counts[lane][key] += stats.get(key, 0)
            provider = full.get('provider', {})
            counts[lane]['potential_contacts'] += provider.get('complete_packet_counts', {}).get(
                'potential_contacts', provider.get('potential_rows', 0))
            result = full.get('result')
            if lane != 'MATCHED_DEPTH_TREE_CONTROL' and result is not None:
                trace_extent(result['events'], result['event_extent'], traces)
                trace_extent(result['rollback_records'], result['rollback_extent'], traces)
                trace_extent(result['provider_evidence']['records'], result['provider_evidence'], traces)
            case['lanes'][lane] = {'status': full['status'], 'reason': full.get('reason'),
                'original_status': 'VERIFIED' if yes else 'UNKNOWN_FACTORY_AUDIT' if not assurance
                    else positive.get('reason', 'NO_CERTIFICATE'), 'seconds': full['search_seconds'],
                'coarse_proof': positive.get('coarse_proof', []) if yes else [],
                'original_proof': positive.get('original_proof', []) if yes else [], 'tree': tree,
                'checks': {k: positive.get(k) for k in ('tree_audit', 'history_audit', 'coarse_host_check',
                    'original_host_check', 'lowering_audit', 'normal_form')},
                'lowering': positive.get('lowering') if yes else None,
                'source_ref': compact['ref'], 'stats': stats, 'provider': provider}
            source_refs.append(compact['ref'])
        cases.append(case)
    for lane in LANES:
        need(sum(counts[lane][k] for k in ('verified', 'unknown', 'finite_exhausted')) == 15, 'complete tally')
    paired = [c for c in cases if all(c['lanes'][k]['original_proof'] for k in ('HISTORY_SCAN', 'HISTORY_INDEXED'))]
    for case in paired:
        a, b = (case['lanes'][k] for k in ('HISTORY_SCAN', 'HISTORY_INDEXED'))
        need(a['coarse_proof'] == b['coarse_proof'] and a['tree'] == b['tree'], 'same successful marked tree')
    for case in cases:
        if case['lanes']['MATCHED_DEPTH_TREE_CONTROL']['status'] == 'NOT_DERIVABLE':
            need(not any(case['lanes'][k]['original_proof'] for k in LANES[:-1]), 'no verified contradiction with finite control negative')
    detours = [c['id'] for c in cases if c['lanes']['UNMARKED_INDEXED']['original_proof']
        and not c['lanes']['UNMARKED_INDEXED']['checks']['normal_form']['path_normal']]
    resolved = {k: counts[k]['verified'] + counts[k]['finite_exhausted'] for k in LANES}
    missed = [c['id'] for c in cases if c['lanes']['UNMARKED_INDEXED']['original_proof']
        and not c['lanes']['HISTORY_INDEXED']['original_proof']]
    new_negative = [c['id'] for c in cases
        if c['lanes']['HISTORY_INDEXED']['status'] == 'UNSAT'
        and c['lanes']['HISTORY_INDEXED']['original_status'] != 'UNKNOWN_FACTORY_AUDIT'
        and c['lanes']['UNMARKED_INDEXED']['status'] == 'UNKNOWN']
    findings = [f"Verified positive proofs: unmarked indexed {counts[LANES[0]]['verified']}, history scan {counts[LANES[1]]['verified']}, history index {counts[LANES[2]]['verified']}, proof-tree control {counts[LANES[3]]['verified']}. All sixty method positions are retained.",
        f"History scan and history index respectively resolved {resolved['HISTORY_SCAN']} and {resolved['HISTORY_INDEXED']} fixed finite cases, counting verified proofs and assured finite negative closures separately. Unmarked indexed resolved {resolved['UNMARKED_INDEXED']}; the proof-tree control resolved {resolved['MATCHED_DEPTH_TREE_CONTROL']}.",
        f"The history-index method closed {len(new_negative)} bounded negative cases left unknown by unmarked search, and missed {len(missed)} positive cases that unmarked search proved. This is a mixed coverage result; finite negatives concern only the fixed catalogue and depth bound.",
        'Every displayed proof comes from its recorded search, was independently reconstructed, expanded through the certified lemma bank, and checked in the original theory. No manually written target derivation was supplied to search.',
        f'The two history implementations have identical marked trees on their {len(paired)} common successful targets. The unmarked and marked proof sets differ, with the stated bounded-existence argument.',
        f'{len(detours)} successful unmarked trees contain a repeated literal formula on an ancestor path. They are valid proofs; the history model requires a different witness.']
    if missed:
        findings.append('Positive cases proved by unmarked search and missed by history-index search: ' + ', '.join(missed) + '.')
    if new_negative:
        findings.append('New finite negative closures by history-index search: ' + ', '.join(new_negative) + '.')
    costs = [f"New observer wall time: {observer['whole_observer_seconds']:.3f} seconds; child lifetime peak RSS: {observer['wait4_peak_bytes']} bytes.",
        f"Reused catalogue preparation: {design['historical_preparation_seconds']:.3f} seconds; historical donor acquisition: {design['historical_donor_acquisition_seconds']:.3f} seconds. These are disclosed historical costs.",
        f"Fresh shared bank checks: {exp['fresh_bank_check_seconds']:.4f} seconds. Factory/certificate/tree audits, lowering and positive host checks occur outside each cold search window; their complete returns remain in the archive.",
        'This is one fixed-order observation with implementation-dependent work caps and cooperative wall windows. Complete-query counts have multiplicity; candidate registrations include rollback re-registration. Missing stream suffixes are not reconstructed.',
        'Lower aggregate wall time or fewer registrations can reflect earlier work-limit refusals and fewer verified proofs. These totals are not an unqualified speed or efficiency win. Compare verified outcomes and refusal reasons before interpreting cost.',
        f"Saved main event, rollback and query traces retain {traces['retained_rows']} of {traces['total_rows']} rows across {traces['streams']} streams. Exactly {traces['complete_digests_recomputed']} complete-stream digests were independently recomputed; the other {traces['streams_with_omitted_suffix']} streams have omitted suffixes. Those suffixes are not reconstructed or claimed checked."]
    for lane in LANES:
        c = counts[lane]
        costs.append(f"{lane}: {c['search_seconds']:.4f} seconds total cold search; {c['verified']} verified, {c['finite_exhausted']} finite-depth exhausted, {c['unknown']} unknown; {c['candidate_registrations']} cumulative candidate registrations, {c['provider_rows']} provider rows.")
    common = [c for c in cases if all(c['lanes'][k]['original_proof'] for k in LANES[:3])]
    common_times = [sum(c['lanes'][k]['seconds'] for c in common) for k in LANES[:3]]
    costs.append(f"On the {len(common)} common positive point-search cases, total cold times were {common_times[0]:.4f} seconds unmarked, {common_times[1]:.4f} seconds history scan, and {common_times[2]:.4f} seconds history index. This single observation supports no reliable timing-superiority claim.")
    recovery = design.get('recovery_note')
    if recovery:
        costs.append(str(recovery))
    reader = {'counts': counts, 'cases': cases, 'bank': bank['lemmas'], 'findings': findings,
        'qualification_summary': qualification.get('summary', 'Independent tiny exhaustive qualification; exact scope and observations are retained in the archive.'),
        'cost_notes': costs, 'numeric_encoding': 'Public-projection integers outside the JavaScript safe range are exact decimal strings. Raw experiment records retain native JSON integer types.',
        'assessment': [
            'This tests explicit normal-form markings. They remove some valid proofs while preserving bounded proof existence under fixed closed context-independent producers. They are not learned failure markings.',
            'The direct and indexed history methods share one marked inventory. Their comparison tests enumeration cost; comparison with unmarked GCTS tests a changed proof set with an existence argument.',
            'The current finite producer catalogue also admits conventional memoized proof search. A geometric encoding alone establishes no complexity advantage. These known regression assertions and one timing observation cannot establish broad superiority over automated theorem provers.',
            'A lower aggregate search time can result from earlier resource refusals and fewer verified proofs. It is not a speedup unless comparable verified outcomes are reached. Positive proof coverage and finite negative closure are reported separately.',
            'No RL policy is trained or used. Learned failure markings, variable connected cluster proposals, one fixed universal proof palette, and substantial arithmetic and Hilbert geometry remain open.'],
        'provenance': {'observer': pin(args.observer), 'qualification_admission': pin(args.qualification),
            'scientific_admission': pin(args.admission), 'plan': observer['worker_terminal']['plan'],
            'full_lane_records': source_refs, 'unmarked_valid_detour_cases': detours,
            'history_missed_unmarked_positives': missed, 'new_history_bounded_negatives': new_negative,
            'resolved_finite_cases': resolved, 'main_trace_census': traces, 'scope': exp['scope']}}
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=False)
    data = {'schema': 'HNF-history-marked-proof-search-public-results-v1', 'reader': reader,
        'design': design, 'limits': design['limits'],
        'scope': 'Passive complete saved-data projection; raw originals remain in the full archive.'}
    (out/'history-marked-proof-search-results-v1.json').write_bytes(raw(browser_numbers(data)))
    (out/'history-marked-proof-search-v1.html').write_bytes((Path(__file__).parent/'history-proof-reader-template-v1.html').read_bytes())
    print(json.dumps({'status': 'COMPLETE', 'counts': browser_numbers(counts),
                      'files': [pin(p) for p in sorted(out.iterdir())]}, sort_keys=True))


if __name__ == '__main__':
    main()
