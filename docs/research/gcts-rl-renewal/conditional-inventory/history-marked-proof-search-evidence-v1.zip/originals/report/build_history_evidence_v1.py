"""Passive deterministic packaging of an explicitly closed public evidence cut.

No archived Source is imported, no directory is recursively selected, and no
recovery transcript is an eligible original. Only the declared file list is read.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import stat
import zipfile

RUN = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-history-normal-form-20261102-v1')
PUBLIC_RECOVERY = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-history-recovery-20261102-v1/public-recovered-sources')
ZIP_NAME = 'history-marked-proof-search-evidence-v1.zip'
FILE_CAP, ZIP_CAP, TOTAL_CAP, PLAN_CAP = 67108864, 67108864, 1073741824, 16777216
GROUPS = {'sources', 'inputs', 'qualification', 'main', 'report', 'qa', 'recovery_provenance'}
RESERVED = {'MANIFEST.json', 'README.txt', 'PACKAGING-INPUT.json'}
FORBIDDEN_PARTS = {'.codex', 'sessions', 'archived_sessions', 'thread-writer-locks',
                   'session-logs', 'recovery-logs', 'raw-session-logs',
                   'unverified-candidates', 'node_modules'}
FORBIDDEN_NAMES = {'owned-HNF-session-records.jsonl', 'owned-HNF-call-pairs.jsonl',
                   'call-pair-index-v1.json', 'record-index-v1.json', 'command-output-map-v1.json'}


def need(ok, reason):
    if not ok:
        raise ValueError(reason)


def raw(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True, indent=2,
                       allow_nan=False) + '\n').encode('ascii')


def parse(data):
    def pairs(rows):
        result = {}
        for key, value in rows:
            need(key not in result, 'Duplicate JSON key')
            result[key] = value
        return result
    return json.loads(data, object_pairs_hook=pairs,
                      parse_constant=lambda x: need(False, 'Non-finite JSON value'))


def pin(path, data):
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def canonical(path):
    need(type(path) is str, 'Literal absolute path')
    p = Path(path)
    need(p.is_absolute() and str(p) == path and p.resolve() == p
         and all(not q.is_symlink() for q in (p, *p.parents)), 'Canonical nonsymlink path')
    return p


def eligible(path):
    p = canonical(path)
    need(p.is_relative_to(RUN) or p.is_relative_to(PUBLIC_RECOVERY), 'Outside public original roots')
    need(not any(x in FORBIDDEN_PARTS or x == '.git' or x.endswith('.git') for x in p.parts),
         'Forbidden private/cache/repository original')
    need(p.name not in FORBIDDEN_NAMES and not p.name.startswith('rollout-')
         and p.suffix.lower() != '.zip', 'Transcript, recovery index or nested archive excluded')
    return p


def read(path, cap=FILE_CAP):
    p = canonical(str(path)); before = p.stat(follow_symlinks=False)
    need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1
         and 0 <= before.st_size <= cap, 'Bounded singleton regular file')
    with p.open('rb') as stream:
        data = stream.read(cap + 1)
    after = p.stat(follow_symlinks=False)
    need(len(data) == before.st_size == after.st_size and len(data) <= cap
         and (before.st_dev, before.st_ino, before.st_mtime_ns)
         == (after.st_dev, after.st_ino, after.st_mtime_ns), 'Original changed while reading')
    return data, stat.S_IMODE(before.st_mode)


def original(ref):
    need(type(ref) is dict and set(ref) == {'path', 'bytes', 'sha256'}
         and type(ref['bytes']) is int and 0 <= ref['bytes'] <= FILE_CAP
         and type(ref['sha256']) is str and len(ref['sha256']) == 64
         and all(c in '0123456789abcdef' for c in ref['sha256']), 'Exact typed reference')
    p = eligible(ref['path'])
    data, mode = read(p)
    need(pin(p, data) == ref, 'Full original length/SHA mismatch')
    return data, mode


def safe(name):
    need(type(name) is str and name and len(name.encode('utf-8')) <= 65535
         and not name.startswith('/') and '\\' not in name and ':' not in name
         and all(32 <= ord(c) <= 126 for c in name)
         and all(x not in ('', '.', '..') for x in name.split('/')), 'Safe relative member name')
    return name


def create(path, data):
    with path.open('xb') as stream:
        need(stream.write(data) == len(data), 'Short write')
        stream.flush(); os.fsync(stream.fileno())
    need(read(path, max(len(data), 1))[0] == data, 'Created-file readback')


class Capped:
    def __init__(self, stream):
        self.stream = stream
    def write(self, data):
        need(self.stream.tell() + len(data) <= ZIP_CAP, 'ZIP extent including final directory')
        count = self.stream.write(data); need(count == len(data), 'Short ZIP write'); return count
    def tell(self):
        return self.stream.tell()
    def seek(self, offset, whence=0):
        return self.stream.seek(offset, whence)
    def flush(self):
        return self.stream.flush()


def closure(plan, included):
    """Verify declared files include the current executable/data/actual-output closure."""
    def require(ref):
        original(ref)
        need(included.get(ref['path']) == ref, 'Required original absent from cut: ' + ref['path'])
        return ref
    need(type(plan['required_groups']) is dict and set(plan['required_groups']) == GROUPS, 'Exact coverage groups')
    for group, refs in plan['required_groups'].items():
        need(type(refs) is list and refs, 'Nonempty required coverage group: ' + group)
        for ref in refs:
            require(ref)
    need(type(plan['plans']) is list and len(plan['plans']) == 2
         and len({x['path'] for x in plan['plans']}) == 2, 'Distinct current qualification/main plans')
    plans, kinds = {}, set()
    for ref in plan['plans']:
        data = parse(original(require(ref))[0])
        need(data['schema'] == 'AA-growing-proof-search-once-plan-v1'
             and type(data['sources']) is dict and len(data['sources']) == 13, 'Current owned plan')
        for source in data['sources'].values():
            require(source)
        require(data['bootstrap'])
        for metadata in data['metadata'].values():
            require(metadata)
        kind = parse(original(data['metadata']['design'])[0])['kind']
        need(kind in ('qualification', 'history-main') and kind not in kinds, 'One qualification and one main design')
        kinds.add(kind)
        inputs = parse(original(data['metadata']['frozen_inputs'])[0])
        need(type(inputs['inputs']) is list and len(inputs['inputs']) == 31
             and len({x['name'] for x in inputs['inputs']}) == 31, 'Exactly all31 reused current inputs')
        for entry in inputs['inputs']:
            require(entry['stored'])
        plans[ref['path']] = (ref, data)
    need(kinds == {'qualification', 'history-main'}, 'Both current design kinds')
    qualified, main = [data for ref, data in plans.values()]
    need(qualified['sources'] == main['sources'] and qualified['bootstrap'] == main['bootstrap']
         and qualified['python'] == main['python'], 'Current main executes the exact qualified Source/runtime set')
    need(type(plan['observations']) is list and len(plan['observations']) == 2
         and len({x['path'] for x in plan['observations']}) == 2, 'Two current completed observations')
    observed_plans = set()
    for ref in plan['observations']:
        observed = parse(original(require(ref))[0])
        need(observed['status'] == 'COMPLETE' and observed['returncode'] == 0
             and observed['wait_confirmed'] and observed['both_streams_EOF']
             and observed['group_gone'] and observed['failure'] is None
             and not observed['cleanup_errors'], 'Complete current owned observation')
        current = observed['worker_terminal']['plan']
        need(current['path'] in plans and plans[current['path']][0] == current, 'Observed exact current plan')
        observed_plans.add(current['path'])
        files = observed['files']
        need(type(files) is list and files, 'Observed full physical file list')
        for item in files:
            require(item)
        require(observed['worker_terminal']['result']['stored'])
        consumes = [item for item in files if Path(item['path']).name == 'CONSUMED.json']
        need(len(consumes) == 1, 'One actual consume marker')
        marker = parse(original(consumes[0])[0])
        for key in ('authority', 'consumed'):
            require(marker[key])
        spent = parse(original(marker['consumed'])[0])
        authority = parse(original(marker['authority'])[0])
        need(spent['status'] == 'SPENT' and spent['plan'] == current
             and authority['uses'] == 1 and authority['authorized'] is True
             and authority['plan'] == current
             and authority['runner'] == plans[current['path']][1]['sources']['runner'],
             'Spent current once associations')
    need(observed_plans == set(plans), 'Each current plan has its completed observation')
    need(type(plan['admissions']) is list and len(plan['admissions']) >= 3, 'Qualification/main/content admissions')
    for ref in plan['admissions']:
        data = parse(original(require(ref))[0])
        need(data.get('status') == 'ADMITTED', 'Admitted current evidence')
    require(pin(Path(__file__).resolve(), read(Path(__file__).resolve())[0]))


def build(manifest_path, output):
    manifest_path, output = canonical(manifest_path), canonical(output)
    need(manifest_path.is_relative_to(RUN) and output.is_relative_to(RUN), 'Task-owned cut/output')
    plan_raw, plan_mode = read(manifest_path, PLAN_CAP); plan = parse(plan_raw)
    need(type(plan) is dict and set(plan) == {'schema', 'status', 'cut_id', 'entries', 'plans',
        'observations', 'admissions', 'required_groups', 'upstream', 'exclusions', 'scope', 'pending'}, 'Closed input schema')
    need(plan['schema'] == 'HNF-closed-evidence-input-v1'
         and plan['status'] == 'ADMITTED_CLOSED_PREPUBLICATION_CUT'
         and type(plan['cut_id']) is str and plan['cut_id'] and plan['pending'] == [], 'Admitted complete cut')
    need(type(plan['entries']) is list and 0 < len(plan['entries']) <= 10000
         and type(plan['scope']) is list and all(type(x) is str for x in plan['scope'])
         and type(plan['exclusions']) is list and type(plan['upstream']) is list, 'Typed cut scope')
    for upstream in plan['upstream']:
        need(type(upstream) is dict and set(upstream) == {'name', 'url', 'bytes', 'sha256', 'scope'}
             and all(type(upstream[k]) is str and upstream[k] for k in ('name', 'url', 'sha256', 'scope'))
             and upstream['url'].startswith('https://') and type(upstream['bytes']) is int
             and upstream['bytes'] >= 0 and len(upstream['sha256']) == 64
             and all(c in '0123456789abcdef' for c in upstream['sha256']), 'Pinned external upstream')
    entries, names, included, total = [], set(), {}, 0
    for entry in plan['entries']:
        need(type(entry) is dict and set(entry) == {'name', 'category', 'source_ref', 'public_safe'}
             and type(entry['category']) is str and entry['category'] and entry['public_safe'] is True, 'Explicit public-reviewed file')
        name = safe(entry['name']); ref = entry['source_ref']; data, mode = original(ref)
        need(name not in names and name not in RESERVED and ref['path'] not in included
             and ref['path'] != str(manifest_path) and not Path(ref['path']).is_relative_to(output), 'Unique nonrecursive original')
        names.add(name); included[ref['path']] = ref; total += len(data)
        need(total <= TOTAL_CAP, 'Aggregate original cap')
        entries.append(dict(entry, mode=mode))
    closure(plan, included)
    entries.append(dict(name='PACKAGING-INPUT.json', category='closed_input',
                        source_ref=pin(manifest_path, plan_raw), public_safe=True, mode=plan_mode))
    total += len(plan_raw); need(total <= TOTAL_CAP, 'Complete original aggregate cap')
    entries.sort(key=lambda e: e['name'])
    catalogue = dict(schema='HNF-complete-evidence-manifest-v1', cut_id=plan['cut_id'], entries=entries,
        originals=len(entries), original_bytes=total, plans=plan['plans'], observations=plan['observations'],
        admissions=plan['admissions'], required_groups=plan['required_groups'], upstream=plan['upstream'],
        exclusions=plan['exclusions'], scope=plan['scope'])
    catalogue_raw = raw(catalogue); need(len(catalogue_raw) <= PLAN_CAP, 'Generated manifest cap')
    readme = ('Complete selected prepublication evidence cut. MANIFEST.json maps each member to its original path, mode, length and SHA256.\n'
        'All current declared Sources, all31 input carriers, both complete qualification/main physical file lists, admissions and selected report/QA evidence are included.\n'
        'The archive does not contain the recovery session logs, private chat transcripts, unverified recovery candidates, platform runtime, bare Git repositories or a nested historical ZIP.\n'
        'The earlier temporary qualification raw evidence was lost; remembered aggregate output is not a current proof certificate. Any included public-safe recovery provenance states that limitation.\n'
        'Current proofs are from the separately executed persistent runs. Historical upstream packages are explicit external pins; current operative Sources and input carriers are vendored.\n'
        'This ZIP cannot include its own post-build/readback or future deployment records. Later Git/Pages/TLS/live checks are a separate durable supplement.\n'
        'No archived code executes during packaging. Reproduction needs fresh plans and fresh once authority; spent authorities must never be reused.\n\n'
        + '\n'.join(plan['scope']) + '\n').encode('utf-8')
    need(not output.exists() and output.parent.is_dir(), 'Fresh output directory')
    output.mkdir(mode=0o700)
    partial, final = output/(ZIP_NAME + '.partial'), output/ZIP_NAME
    try:
        with partial.open('xb') as stream:
            with zipfile.ZipFile(Capped(stream), 'w', compression=zipfile.ZIP_DEFLATED, allowZip64=False) as archive:
                generated = [dict(name='MANIFEST.json', body=catalogue_raw, mode=0o644),
                             dict(name='README.txt', body=readme, mode=0o644)]
                for entry in entries + generated:
                    data = entry['body'] if 'body' in entry else original(entry['source_ref'])[0]
                    info = zipfile.ZipInfo(entry['name'], (1980, 1, 1, 0, 0, 0))
                    info.create_system = 3; info.external_attr = (stat.S_IFREG | entry['mode']) << 16
                    archive.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
            stream.flush(); os.fsync(stream.fileno())
        checks = []
        with zipfile.ZipFile(partial) as archive:
            need(len(archive.infolist()) == len(entries) + 2
                 and len(set(archive.namelist())) == len(entries) + 2 and archive.testzip() is None, 'Whole ZIP count/CRC')
            for entry in entries:
                data, mode = original(entry['source_ref']); restored = archive.read(entry['name']); info = archive.getinfo(entry['name'])
                need(restored == data and mode == entry['mode']
                     and (info.external_attr >> 16) == (stat.S_IFREG | mode), 'Every whole member/mode readback')
                checks.append(dict(name=entry['name'], source_ref=entry['source_ref'],
                    bytes=len(restored), sha256=hashlib.sha256(restored).hexdigest(), CRC32=info.CRC))
            need(archive.read('MANIFEST.json') == catalogue_raw and archive.read('README.txt') == readme, 'Generated member readback')
        for entry in entries:
            need(original(entry['source_ref'])[1] == entry['mode'], 'All original postguards')
        os.link(partial, final); partial.unlink()
        create(output/'MANIFEST.json', catalogue_raw)
        data, _ = read(final, ZIP_CAP)
        receipt = dict(schema='HNF-complete-package-readback-v1', status='COMPLETE', archive=pin(final, data),
            manifest=pin(output/'MANIFEST.json', catalogue_raw), members=len(entries) + 2,
            originals=len(entries), original_bytes=total, all_CRCs=True,
            all_original_readbacks=checks, scope='Exact selected closed cut only; no future publication/live receipt or private recovery transcript.')
        create(output/'package-readback.json', raw(receipt))
        return receipt
    except Exception as error:
        create(output/'package-failure.json', raw(dict(status='INCOMPLETE_UNADMITTED',
            type=type(error).__name__, reason=str(error))))
        raise


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--manifest', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    print(json.dumps(build(args.manifest, args.output)['archive'], sort_keys=True))
