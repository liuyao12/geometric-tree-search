"""Archive complete fixed files by raw bytes; no scientific imports or replay."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'publication'


def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=True, allow_nan=False)+'\n').encode()


def pin(path):
    path = Path(path)
    body = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def main():
    # A closed snapshot: later publication/live-verification receipts are outside
    # this archive and never overwrite its Source or result evidence.
    excluded = {'principal-receptors-evidence.tar.gz', 'principal-receptors-manifest.json'}
    paths = []
    for path in sorted(ROOT.rglob('*')):
        if not path.is_file():
            continue
        if path.is_symlink():
            raise ValueError('no symbolic archive input')
        if '.partial' in path.name:
            raise ValueError('partial files excluded; no content parsed')
        relative = path.relative_to(ROOT)
        if relative.parts[:2] == ('publication', 'preview') or path.name in excluded:
            continue
        paths.append((str(relative), path))
    plan = json.loads((ROOT/'root/plan-mechanism-0-v1.json').read_bytes())
    omitted = []
    for row in plan['files']:
        path = Path(row['path'])
        assert pin(path) == {k:row[k] for k in ('path','bytes','sha256')}
        if path.is_relative_to(ROOT):
            continue
        if path == Path(plan['python']['path']):
            omitted.append(dict(**row, reason='Pinned interpreter identity only; runtime executable not redistributed.'))
            continue
        name = ('reference-masters/publisher-master.md' if 'publisher' in path.parts
                else 'reference-masters/primary-master.md') if path.name == 'basic-tiling-algorithm.md' else 'fixed-native/'+path.name
        paths.append((name, path))
    old = ROOT.parent/'gcts-learned-selector-proof-pilot-20261020'
    paths.append(('provenance/previous-entry-v13.py', old/'implementation-B/proof_search_pilot_v13.py'))
    paths.append(('provenance/previous-final-milestone.json', old/'root/Root-final-milestone-v1.json'))
    assert len({name for name,path in paths}) == len(paths)
    rows = [dict(archive_path=name, **pin(path)) for name,path in paths]
    snapshot = dict(schema='D16-complete-raw-evidence-snapshot-v1', files=rows,
                    omitted_runtime=omitted, partial_files_parsed=False,
                    scope='Exact current research Sources, fixed runtime copies, controls, complete actual/custody/review files and display drafts. No scientific function is imported or executed. Previous entry/milestone are provenance only; no old proof/library/policy adopted. Later publication receipts remain outside this closed snapshot.')
    snapshot_body = encoded(snapshot)
    archive = OUT/'principal-receptors-evidence.tar.gz'
    with archive.open('xb') as target:
        with gzip.GzipFile(fileobj=target, mode='wb', filename='', mtime=0, compresslevel=9) as compressed:
            with tarfile.open(fileobj=compressed, mode='w') as tar:
                def add(name, body):
                    info = tarfile.TarInfo(name)
                    info.size = len(body); info.mtime = 0; info.uid = info.gid = 0; info.mode = 0o644
                    tar.addfile(info, io.BytesIO(body))
                add('snapshot-manifest.json', snapshot_body)
                for row, (name,path) in zip(rows, paths):
                    body = path.read_bytes()
                    assert len(body) == row['bytes'] and hashlib.sha256(body).hexdigest() == row['sha256']
                    add(name, body)
    for row, (name,path) in zip(rows, paths):
        assert pin(path) == {k:row[k] for k in ('path','bytes','sha256')}
    final = dict(snapshot, archive=pin(archive), snapshot_manifest_sha256=hashlib.sha256(snapshot_body).hexdigest(),
                 snapshot_manifest_bytes=len(snapshot_body), regular_files=len(rows)+1,
                 uncompressed_source_bytes=sum(row['bytes'] for row in rows))
    manifest = OUT/'principal-receptors-manifest.json'
    with manifest.open('xb') as stream:
        stream.write(encoded(final))
    print(json.dumps(dict(archive=pin(archive), manifest=pin(manifest), source_files=len(rows),
                          raw_bytes=final['uncompressed_source_bytes'], scientific_calls=0)))


if __name__ == '__main__':
    main()
