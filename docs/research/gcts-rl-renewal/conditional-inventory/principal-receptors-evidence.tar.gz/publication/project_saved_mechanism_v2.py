"""Passive projection of complete saved JSON only; no research imports/calls."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]


def read(path):
    path = Path(path)
    if '.partial' in path.name:
        raise ValueError('partial files are never parsed or projected')
    return json.loads(path.read_bytes())


def pin(path):
    path = Path(path)
    body = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def main():
    actual = ROOT / 'actual/mechanism-0'
    result = read(actual / 'result.json')
    terminal = read(actual / 'terminal.json')
    observer = read(ROOT / 'actual/mechanism-0.observer/observer.json')
    assert result['status'] == 'COMPLETE' and observer['resource_candidate_accepted'] is True
    assert terminal['header_valid'] is True and terminal['process_exit_code'] == 0
    science = result['scientific_result']
    assert science['record_complete'] is True and science['stage_complete'] is True
    proofs, cells = [], []

    def project(title, scope, case, proof, members, target, status, packet=None):
        # Exact saved-row/key projection only, not a replay or proof check.
        lookup = {tuple(t['key']): t for t in case['model']['placements']}
        tiles = [lookup[tuple(k)] for k in members]
        assert len(tiles) == 2 * len(proof)
        for tile in tiles:
            slot, choice = tile['command_reference']
            assert case['model']['domains'][slot][choice] == proof[slot]
        ids = {value for tile in tiles for point, value in tile['marks'] if point[1] == 100}
        words = {str(index): dict(hex=case['model']['word_dictionary'][index],
                                 literal=json.loads(bytes.fromhex(case['model']['word_dictionary'][index])))
                 for index in sorted(ids)}
        proofs.append(dict(title=title, scope=scope, target=target, proof=proof,
                           tiles=tiles, words=words, status=status, packet=packet))

    for case in science['records']:
        assert case['proof_check']['native_proof_accepted'] is True
        project('Donor: ' + case['spec']['title'],
                'Fresh conventional search; Host, full original point region and Native accepted.',
                case, case['search']['proof'], case['search']['placements'], case['spec']['target'],
                case['proof_check']['status'])
    for case in science['contexts']:
        for row in case['cells']:
            cell = row['cell']
            cells.append(dict(title=case['spec']['title'], context_id=case['spec']['id'],
                              view=cell['view'], mode=cell['mode'], counts=row['counts'],
                              termination=row['pool']['termination'], refusals=row['pool']['refusals']))
            for witness in row['selected_witnesses']:
                assert witness['status'] == 'accepted'
                packet = row['pool']['packets'][witness['packet_ordinal']]
                project(case['spec']['title'] + ' · ' + cell['view'] + ' · ' + cell['mode']
                        + ' · packet ' + str(witness['packet_ordinal'] + 1),
                        ('Whole declared target: Host, full point region and fresh Native accepted.'
                         if witness['whole_target_certificate_accepted'] else
                         'Local packet: Host/trial point interface and fresh Native accepted for its own result; does not certify the complete declared target region.'),
                        case, packet['checked_primitive_proof'], packet['members'],
                        packet['result_formula'],
                        'WHOLE TARGET ACCEPTED' if witness['whole_target_certificate_accepted'] else 'LOCAL CERTIFICATE ACCEPTED',
                        packet)
    families = [dict(paired_unit_id=a['paired_unit_id'], atom=a, principal=b)
                for a, b in zip(science['libraries']['atom'], science['libraries']['principal'])]
    assert all(f['atom']['paired_unit_id'] == f['principal']['paired_unit_id'] for f in families)
    accepted = sum(c['counts']['Native_accepted'] for c in cells)
    whole = sum(c['counts']['whole_target_certificates'] for c in cells)
    controls = science['controls']
    counts = dict(word=len(controls['word']['controls']), encoding=len(controls['encoding']['controls']),
                  principal=controls['principal']['count'], corpus=controls['mechanism_corpus']['control_count'])
    evidence = dict(plan=pin(ROOT / 'root/plan-mechanism-0-v1.json'), result=pin(actual / 'result.json'),
                    terminal=pin(actual / 'terminal.json'), observer=pin(ROOT / 'actual/mechanism-0.observer/observer.json'),
                    control_counts=counts, observer_receipt=observer,
                    Native_requests_started=result['native_requests_started'], Native_complete_records=len(result['native_queries']))
    assessment = [
        'The principal full-library packet completed the atomic serial and opaque equality-formula targets. In those same contexts, the atom-name full library supplied a local one-step certificate but no whole-target packet. Both full libraries completed the constructor-preserving calibration. Neither abstraction completed the mismatched target; its separately authored finite valuation satisfies all hypotheses and falsifies that conclusion.',
        'All sixteen pools exhausted their declared finite source-occurrence enumeration within the fixed caps. There were three paired inventory entries and two principal structural shapes; no entries were coalesced. Four selected recipient witnesses certified whole target regions, while twelve certified only their own local results.',
        'This is a bounded packet-availability experiment. The donor proofs were searched; recipient proofs were obtained by the declared finite receptor-binding enumeration, not by a recipient GCTS or RL search.',
        'The full and one-step views retain the generic MP packet. Availability of a multi-step packet measures reusable packaging; the same consequence can still be reached by composing primitive steps.',
        'The type argument applies to a fixed finite MP graph and its explicit port sharing. Finite controls and independent inferencer agreement support this implementation; they do not constitute a mechanized general proof.',
        'No new RL training, matched search speedup, broad benchmark superiority, or physical universal Wang qualification is claimed. The previous learned-selector comparison did not show an RL-specific gain.'
    ]
    data = dict(schema='D16-passive-human-reader-projection-v1',
        summary='The single bounded mechanism actual completed. Both donor proofs were freshly searched and checked. All 16 recipient cells and their fixed selected witnesses are retained below.',
        stats=[dict(value=len(science['records']), label='fresh searched donor proofs'),
               dict(value=len(families), label='paired inventory entries'),
               dict(value=len(cells), label='fixed comparison cells'),
               dict(value=accepted, label='accepted local witness occurrences')],
        cells=cells, proofs=proofs, families=families, assessment=assessment,
        cost_prose=[
            'All acquisition, dual abstraction, independent verification, context compilation, binding, witness checking, serialization and process custody belong to this one cold actual. No earlier proof, library or policy was adopted.',
            'Observer elapsed sample: %.3f s; final observer gate: %.3f s. These are recorded observer samples, not exact tool end-to-end clocks.' % (observer['elapsed_seconds'], observer['final_observer_gate_seconds']),
            'Conservative whole memory bound: %.2f MiB. The actual started %d Native queries and retained %d complete records. Selected recipient witness occurrences: %d; whole-target certificate occurrences: %d. Repeated occurrences are not distinct new theorems.' % (observer['final_conservative_whole_peak_bytes']/1048576, result['native_requests_started'], len(result['native_queries']), accepted, whole),
            'Original ceilings: 160 s work, 180 s positive completion, 210 s custody, 225 s external fallback; 1 GiB whole memory, 128 MiB physical output, 512 Native starts and one billion Native steps per request. Pool cap: 16 packets and 20,000 validation checks per cell.',
            'The original and corrected reference verifiers both audited each of the six fresh models. This small corpus does not establish that the previously failing quantified setup now fits, and no verifier speed comparison was run.'
        ], evidence=evidence)
    output = ROOT / 'publication/principal-receptors-data-v2.json'
    with output.open('x') as stream:
        json.dump(data, stream, ensure_ascii=True, separators=(',', ':'), allow_nan=False)
        stream.write('\n')
    print(json.dumps(dict(output=pin(output), proof_views=len(proofs), paired_entries=len(families),
                          cells=len(cells), controls=counts, scientific_calls=0)))


if __name__ == '__main__':
    main()
