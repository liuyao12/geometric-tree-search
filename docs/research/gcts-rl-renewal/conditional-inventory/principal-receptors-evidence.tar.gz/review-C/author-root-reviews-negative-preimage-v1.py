"""Freeze read-only manual/AST Source findings; execute no offered functions."""
import ast
import hashlib
import json
from pathlib import Path

BASE = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
D = BASE/'research-runs/gcts-principal-receptor-families-20261021'
C = D/'review-C'
OLD = BASE/'research-runs/gcts-learned-selector-proof-pilot-20261020'

def pin(path):
    path = Path(path)
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

def parse(path):
    tree = ast.parse(Path(path).read_bytes(), filename=str(path))
    code = compile(tree, str(path), 'exec')
    del code
    return tree

def funcs(tree):
    return {node.name: ast.dump(node, include_attributes=False) for node in ast.walk(tree) if isinstance(node, ast.FunctionDef)}

def save(name, value):
    path = C/name
    assert not path.exists()
    path.write_text(json.dumps(value, indent=2, sort_keys=True)+'\n')
    return pin(path)

v1 = OLD/'runtime/word_point_reference_verifier_v1.py'
v2 = D/'root/word_point_reference_verifier_v2.py'
v3 = D/'root/word_point_reference_verifier_v3.py'
assert pin(v3)['sha256'] == '9c95d8722b9d3715c32de63cbec74f548eb63d878c82920b46dfe43e43522de4'
old, new = funcs(parse(v1)), funcs(parse(v3))
changed = [name for name in old if name not in new or old[name] != new[name]]
assert set(changed) == {'__init__', 'payload', 'verify_word_reference'}
assert set(new)-set(old) == {'_encode', 'run_encoding_diagnostics', 'external', 'nested_external'}
negative = C/'typed-word-subtree-encoding-Source-negative-v1.json'
encoder = dict(schema='typed-word-subtree-encoding-Source-review-v3', reviewer_identity='/root/recovered_batch_review', review_passed=True,
               source_only=True, scientific_calls=0, component_calls=0, fixtures_executed=0, partial_files_parsed=False, actual_execution_authorized=False,
               source=pin(v3), predecessor=pin(v2), inherited_reference=pin(v1), retained_negative=pin(negative),
               AST_unused_compile=True, inherited_changed_functions=changed,
               checks=[
                   dict(id='same-canonical-bytes', passed=True, detail='Under the declared fixed-input nonhostile audit, exact list/tuple delimiters, commas and exact string-key dictionary sort/escaping recursively match original canonical stdlib JSON bytes. Noncontainer/non-string-key cases defer to the original encoder. This is a manual induction, not an executed differential result.'),
                   dict(id='owner-and-cycle-scope', passed=True, detail='Successful container encodings retain actual owners strongly; identity hits check the same owner. Active identities are removed by finally on every success or failure. Mutation of cached containers during one audit remains outside the unchanged fixed-input contract; no general mutable-cache claim.'),
                   dict(id='negative-correction', passed=True, detail='Both new container recursion paths use explicit append loops, eliminating the callback generator and PEP479 conversion. Eight prospective nested ordinal3 callback controls cover list/dict and four exact sentinels, plus active cleanup. No controls were executed.'),
                   dict(id='unchanged-reference-semantics', passed=True, detail='Full old domain, dictionary, placement, dependency, overlay and48diagnostic functions remain byte-structure AST identical except constructor/payload and the descriptive final receipt. New v3 reference still must run alongside original v1 on the same fresh models, comparing all substantive receipt fields.'),
                   dict(id='qualification-limits', passed=True, detail='Conditional Source correctness only; new encoder controls and full original48 controls remain unrun. No memory reduction, timing, fit or theorem-search result follows from memoization Source.'),
               ], failed_checks=[], scope='Exact encoder successor and unchanged whole-word reference semantics only; not whole experiment or execution approval.')
encoder_pin = save('typed-word-subtree-encoding-Source-review-v3.json', encoder)

worker = D/'root/mechanism_worker_v1.py'
assert pin(worker)['sha256'] == '6ec57d3cde59669ecf6110241fc40c491009b70b08ab9136bfc807af9d4e924b'
wf = funcs(parse(worker)); of = funcs(parse(OLD/'root/selector_worker_v1.py'))
for name in ('raw_pin', 'canonical', 'write_complete'):
    assert wf[name] == of[name]
contract = D/'diagnostics-L/mechanism_corpus_contract_v1.py'
inputs = D/'diagnostics-L/mechanism-inputs-v1.json'
assert pin(contract)['sha256'] == '8c14e13bc539acdab3c24ad367949e4cbe5477bf661f850bdaba78a387a1f9c9'
assert pin(inputs)['sha256'] == 'c58d29127d3fc912c70b9de73dd1f4caed806a8b33542295cc6fc1257528bbaf'
parse(contract)
doc = json.loads(inputs.read_bytes())
assert len(doc['donors']) == 2 and len(doc['contexts']) == 4 and len(doc['protocol']['cells']) == 16
assert all('proof' not in row and 'route' not in row for row in doc['donors']+doc['contexts'])
review = dict(schema='typed-mechanism-worker-corpus-Source-review-v1', reviewer_identity='/root/recovered_batch_review', review_passed=True,
              source_only=True, scientific_calls=0, component_calls=0, fixtures_executed=0, partial_files_parsed=False, actual_execution_authorized=False,
              worker=pin(worker), inherited_worker=pin(OLD/'root/selector_worker_v1.py'), corpus_contract=pin(contract), input=pin(inputs), encoder_review=encoder_pin,
              AST_unused_compile=True,
              checks=[
                  dict(id='worker-before-science', passed=True, detail='Exact consumed plan/case/path precedes scientific imports. Source/input/runtime bytes are checked before work and after closure. Dispatch accepts only mechanism; no prior D15 library or policy intake is implemented.'),
                  dict(id='sticky-total-Native-ceiling', passed=True, detail='New RootRequestOracle checks genuine Root first, exact positive integer step limit at most1e9 and total started requests strictly below512 before increment/delegation. The aggregate ceiling covers compiler calls and entry calls; refusal sets the sticky Root fault. Counts are starts, not an assertion that every call returns.'),
                  dict(id='unchanged-failure-resource-boundary', passed=True, detail='Worker retains original first-fault dominance, owned Native close/reap, Source recheck, complete atomic result/header, callback/work/positive/custody/physical/memory gates. No failure prefix is admitted. Exact parent/observer/plan closure remains a later whole-offer review; fixed dependency scope is nonhostile, not a sandbox security theorem.'),
                  dict(id='statement-only-finite-corpus', passed=True, detail='Two authored statements supply fresh S0 donor searches, not proof routes. Four public mechanism contexts and16exact view/mode cells exercise original shape, atomic serial, opaque equality and missing-middle control. Format guard enforces literal signatures/closed terms, exact protocol/order and no proof fields;16prospective finite controls remain unrun.'),
                  dict(id='negative-and-scope', passed=True, detail='The declared negative valuation P=Q=true,R=S=false makes the three context axioms true and target false by direct propositional interpretation. It is external control evidence, never an extra search premise. This mechanism measures bounded context packet availability with graph=None; it is not a GCTS/RL search evaluation, broad held-out result, learned equality rule or speedup.'),
              ], failed_checks=[], scope='Exact Root worker and L mechanism corpus Source only. B entry/principal module/reference controls and final plan/closure/once grant remain separate barriers.')
worker_pin = save('typed-mechanism-worker-corpus-Source-review-v1.json', review)
print(json.dumps({'encoder_review': encoder_pin, 'worker_corpus_review': worker_pin}))
