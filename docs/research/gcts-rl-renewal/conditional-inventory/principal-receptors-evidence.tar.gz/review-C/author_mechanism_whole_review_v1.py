"""Passive raw-pin and unused-AST checks for the exact D16 mechanism offer."""
import ast
import hashlib
import json
import re
from pathlib import Path

BASE = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
D = BASE/'research-runs/gcts-principal-receptor-families-20261021'
C, R, B = D/'review-C', D/'root', D/'implementation-B'
OLD = BASE/'research-runs/gcts-learned-selector-proof-pilot-20261020'

def pin(path):
    path = Path(path)
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

def read(path):
    path = Path(path)
    assert '.partial' not in path.name
    return json.loads(path.read_bytes())

def parse(path):
    tree = ast.parse(Path(path).read_bytes(), filename=str(path))
    unused = compile(tree, str(path), 'exec')
    del unused
    return tree

def pins_in(value, found):
    if type(value) is dict:
        if set(value) == {'path', 'bytes', 'sha256'}:
            assert pin(value['path']) == value
            found[value['path']] = value
        else:
            for child in value.values():
                pins_in(child, found)
    elif type(value) is list:
        for child in value:
            pins_in(child, found)

plan_path = R/'plan-mechanism-0-v1.json'
assert pin(plan_path)['sha256'] == '665d35945fda003128774fc1a75f9f8fb3ea2cfcb72465b1313127ffa913c93e'
plan = read(plan_path)
assert len(plan['files']) == len({row['path'] for row in plan['files']}) == 90
asts = []
for row in plan['files']:
    assert pin(row['path']) == row
    if Path(row['path']).suffix == '.py':
        parse(row['path'])
        asts.append(row)
assert plan['stage'] == 'mechanism' and plan['case_id'] == 'mechanism-0'
assert plan['required_upstream_ids'] == plan['upstream_receipts'] == []
assert not Path(plan['actual_dir']).exists() and not Path(plan['actual_dir']+'.observer').exists()
assert not (R/'grant-mechanism-0-v1.json').exists()
protocol = read(plan['protocol']['path'])
assert pin(plan['protocol']['path']) == plan['protocol']
assert plan['protocol']['sha256'] == '36136e3c7fdaa824e371eddd56e7fc4346cdc5300f12da7043546c5815933a27'
assert plan['limits'] == protocol['limits'] and plan['experiment_limits'] == protocol['experiment_limits']
oldplan = read(OLD/'root/plan-eval-eval-sharing-01-seed-0-v1.json')
for key in ('limits', 'experiment_limits', 'modules', 'native', 'python'):
    assert plan[key] == oldplan[key]
assert pin(plan['runner_path'])['sha256'] == pin(OLD/'root/run_case_once_v3.py')['sha256']
assert pin(plan['observer_path'])['sha256'] == pin(OLD/'root/observe_case_once_v2.py')['sha256']
runtime_copies = []
for path in sorted((OLD/'runtime').glob('*.py')):
    copied = Path(plan['runtime_dir'])/path.name
    assert pin(copied)['sha256'] == pin(path)['sha256']
    runtime_copies.append(dict(source=pin(path), copy=pin(copied)))
assert len(runtime_copies) == 32
new_modules = [
    (B/'principal_receptor_families_v1.py', 'principal_receptor_families_v1.py'),
    (C/'principal_family_reference_v1.py', 'principal_family_reference_v1.py'),
    (D/'diagnostics-L/mechanism_corpus_contract_v1.py', 'mechanism_corpus_contract_v1.py'),
    (R/'word_point_reference_verifier_v3.py', 'word_point_reference_verifier_v3.py'),
]
for source, name in new_modules:
    assert pin(Path(plan['runtime_dir'])/name)['sha256'] == pin(source)['sha256']
assert len(list(Path(plan['runtime_dir']).glob('*.py'))) == 36
assert not (Path(plan['runtime_dir'])/'word_point_reference_verifier_v2.py').exists()

handoff_path = B/'handoff-v2.json'
handoff = read(handoff_path)
assert pin(handoff_path)['sha256'] == 'd7e297c8721ff0b672886b6ec60d37c7c4bdebb5e1736503a25a396475741294'
extra_pins = {}
for path in (handoff_path, B/'manifest-v2.json', B/'API-v1.json', B/'manual-conformance-v2.json',
             D/'diagnostics-L/handoff-v1.json', D/'diagnostics-L/API-v1.json'):
    pins_in(read(path), extra_pins)
entry_path = Path(plan['entry_path'])
assert pin(entry_path) == handoff['entry']
assert pin(B/'principal_receptor_families_v1.py') == handoff['principal_module']
def definitions(path):
    return {node.name: node for node in parse(path).body if isinstance(node, (ast.FunctionDef, ast.ClassDef))}
before = definitions(OLD/'implementation-B/proof_search_pilot_v13.py')
after = definitions(entry_path)
changed = [name for name in before if ast.dump(before[name], include_attributes=False) != ast.dump(after[name], include_attributes=False)]
added = [name for name in after if name not in before]
assert changed == handoff['changed_original_functions']
assert added == handoff['added_functions']
unchanged = [name for name in before if name not in changed]
assert len(unchanged) == 45
for name in ('ready_pool', 'search_points', 'search_points_selected', 'search_symbolic', 'search_symbolic_selected',
             '_bound_expansion', '_unify_checked', '_checked_key_skeleton', 'verify_region', 'host_check', '_finish_selector_proof'):
    assert name in unchanged
patch = Path(handoff['raw_patch']['path']).read_text().splitlines(keepends=True)
original = (OLD/'implementation-B/proof_search_pilot_v13.py').read_text().splitlines(keepends=True)
result, position, cursor = [], 0, 2
assert patch[0].startswith('--- ') and patch[1].startswith('+++ ')
while cursor < len(patch):
    match = re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@', patch[cursor])
    assert match
    start = int(match.group(1))-1
    assert start >= position
    result.extend(original[position:start]); position = start; cursor += 1
    while cursor < len(patch) and not patch[cursor].startswith('@@ '):
        line = patch[cursor]
        assert line[0] in ' +-'
        if line[0] in ' -':
            assert original[position] == line[1:]
            position += 1
        if line[0] in ' +':
            result.append(line[1:])
        cursor += 1
result.extend(original[position:])
assert ''.join(result).encode() == entry_path.read_bytes()
peer_path = D/'diagnostics-L/typed-independent-principal-reference-Source-review-v1.json'
peer = read(peer_path)
assert peer['review_passed']
assert pin(peer_path)['sha256'] == 'b01b4756550172d48d07c474dc7dcdb2601f58069118ea3b759221ba420cdfd9'
inputs = read(plan['input_path'])
assert len(inputs['donors']) == 2 and len(inputs['contexts']) == 4 and len(inputs['protocol']['cells']) == 16
assert [(row['view'], row['mode']) for row in inputs['protocol']['cells']].count(('full', 'principal')) == 4
assert inputs['protocol']['native_witness_target'] == 'actual packet result_formula'
assert plan['experiment_limits']['cluster_proposals'] == 16 and plan['experiment_limits']['cluster_binding_work'] == 20000
assert plan['experiment_limits']['compile_queries'] == 512 and plan['experiment_limits']['native_steps'] == 1000000000
module_tree = parse(B/'principal_receptor_families_v1.py')
module_functions = [node.name for node in module_tree.body if isinstance(node, ast.FunctionDef)]
manual_groups = [
    dict(functions=['Invalid.__init__', 'is_owned_error', '_need', '_copy', '_word', '_digest'], finding='Exact finite literal carriers and public-unowned errors; genuine callback precedes private classification, without a callback-catching wrapper. Canonical serialization and digest bind concrete witnesses; no Host/Native authority supplied.'),
    dict(functions=['_term', '_wire', '_walk', '_occurs', '_resolve'], finding='Only formula metas and free binary Imp terms. Variable chains retain cycle detection; occurs traverses through current bindings. Finite normal forms preserve shared variable equality. Deep/large resource refusal is not ill-typing or a mathematical completeness theorem for the implementation.'),
    dict(functions=['_graph', '_constraints'], finding='Exact row ordinals and prior int references reject proof cycles independently of type cycles; bool/float refs rejected. Fresh disjoint row/port variables preserve every repeated occurrence. Equations contain only graph-imposed Imp/port constraints, not target constructors.'),
    dict(functions=['_solve', '_replay'], finding='Only delete-identical, occurs-checked variable elimination and Imp decomposition. Replay consumes every equation/step and validates exact current terms. Unifier existence is not confused with principality by arbitrary specialization; most-general factorization is the separate manual argument.'),
    dict(functions=['_alpha', '_typing'], finding='Resolve globally, then normalize residual metas in fixed premise/conclusion/all-row order. All original-variable images, constraints/bindings/trace and row formulas retained. Object FOL binder spelling is not normalized.'),
    dict(functions=['infer_graph', '_logical_term', '_formula', '_extract', '_match', '_family', 'mine', 'verify'], finding='Exact formula first-use axiom quotient, named aliases and every concrete MP/target row are retained. Original donor factors uniformly through every principal row. Exact structural certificate is independently replayed and fully reconstructed; callers still supply fresh whole-theory Host/Native validation.'),
]
assert set(module_functions) == set(name for group in manual_groups for name in group['functions'] if '.' not in name)
checks = [
    ('exact-offer-and-raw-delta', 'Exact90 declared bodies, all nested handoff metadata pins, 45unchanged old top-level definitions / eight changed adapters / four additions, and literal raw patch reconstruction of entry128103B all reconcile. No offered Source was executed.'),
    ('principal-mathematics-and-module', 'Complete principal module read and function matrix checked against finite free-Imp equations, occurs/freshness/graph-sharing/alpha/witness obligations. Manual soundness and principal factorization are scoped to the fixed full DAG and old concrete-formula port quotient, not a new logical rule or all proofs.'),
    ('live-independent-comparison', 'Each fresh accepted actual fragment is sent to C independent infer_request. Production parameters/template, all six graph/type fields, concrete donor arguments and alias rows must agree, and full receipt retained. This is additional to the53hand-authored finite controls.'),
    ('paired-wrappers-and-class-members', 'Both factors retain one inventory entry per unchanged fresh atom class in the same order. Principal structures are not coalesced. Every class member must agree canonical template/parameters/DAG/structural identity. Exact verified structural_family stays inside a separate checked paired wrapper; principal.verify never receives its relabeled outer dictionary.'),
    ('concrete-proof-authority', 'Fresh S0 searched donors receive Host/full original point region/Native checks; eligible exact full/ancestor fragments receive fresh Host/Native before dual abstraction. Context packets bind actual licensed occurrences, expand through unchanged Host/existing primitive-key/full trial t/m checks, with no cut premise invention.'),
    ('fixed-mechanism-witnesses', 'All16 cells use the fixed empty-prefix graph=None availability diagnostic, not a Graph search/RL benchmark. Native schedule is original first packet plus first >=2MP exact-target packet, at most2/cell, no backfill. Actual packet conclusion is Native target, blocks=[]; a full-target certificate additionally requires exact full-row region. Unrequested and UNKNOWN remain unadmitted.'),
    ('references-and-control-peer', 'Corrected v3 and original v1 complete reference checks both run on every fresh donor/context model and compare all substantive fields. Old48word, new40encoder, C53principal and L16corpus controls remain prospectively unrun. L independently reviewed C author Source; this review does not self-admit its author controls.'),
    ('unchanged-search-contract', 'All symbolic/point searches, common pool, guard keys, generic MP, stable novelty, primitive fallback, global DEAD/FORCED/generation scheduling and rollback functions are unchanged. Mechanism does not invoke recipient point search or modify the candidate universe; old D15 policies/results/failures remain immutable.'),
    ('Root-and-runtime', 'Exact32old runtime modules, four new runtime copies, original parent/observer bytes and reviewed new mechanism worker. Worker sticky Root boundary globally caps512starts and <=1e9steps, including compiler calls. Plan retains600/2s cooperative local limits and160/180/210/225/1GiB/128MiB/9MiB/400m/log/result gates. Fit remains unmeasured.'),
    ('scope-and-once-barrier', 'One exact cold mechanism plan, zero upstream/adopted library or policy, no grant/actual present at review. Full original D15 six-case evaluation remains a future obligation. This receipt is not a grant, retry authority, matched RL evaluation, speedup, new theorem or old qualification rescue.'),
]
review = dict(schema='typed-principal-mechanism-whole-Source-plan-review-v1', reviewer_identity='/root/recovered_batch_review', review_passed=True,
              source_only=True, scientific_calls=0, component_calls=0, fixtures_executed=0, replays=0, partial_files_parsed=False,
              actual_execution_authorized=False, retry_authority=False, changed_bounds_authority=False,
              plan=pin(plan_path), protocol=plan['protocol'], B_handoff=pin(handoff_path), source_closure_pins=plan['files'],
              AST_unused_compile_pins=asts, old_runtime_raw_copies=runtime_copies,
              new_runtime_sources=[pin(path) for path, name in new_modules],
              additional_current_handoff_pin_joins=list(extra_pins.values()), source_delta=dict(unchanged=unchanged, changed=changed, added=added, raw_patch=handoff['raw_patch'], raw_patch_reconstructs_successor=True),
              principal_module_function_matrix=manual_groups,
              theory=pin(C/'principal-family-soundness-theory-v1.json'), reference_peer_review=pin(peer_path),
              encoder_negative=pin(C/'typed-word-subtree-encoding-Source-negative-v1.json'),
              corrected_encoder_review=pin(C/'typed-word-subtree-encoding-Source-review-v3.json'),
              worker_corpus_review=pin(C/'typed-mechanism-worker-corpus-Source-review-v1.json'),
              controls_status='ALL_UNRUN; no conformance/result/fit claim from Source review',
              future_staged_adapter='Source mode propagation was inspected, but this mechanism plan dispatches only run_mechanism. Any training/evaluation worker, phase exclusions, admitted cost chain, zero policies and exact per-mode plans need separate future reviews.',
              checks=[dict(id=identity, passed=True, detail=detail) for identity, detail in checks], failed_checks=[],
              scope='Exact prospective single mechanism Source/plan only. Root alone may issue a fresh one-use grant after the idle barrier. Finite runtime and later independent actual review remain required.',
              fit='UNMEASURED', tools_stopped_after_freeze=True)
destination = C/'typed-principal-mechanism-whole-Source-plan-review-v1.json'
assert not destination.exists()
destination.write_text(json.dumps(review, indent=2, sort_keys=True)+'\n')
print(json.dumps(dict(review=pin(destination), checks=len(checks), closure=len(plan['files']), AST_unused_compiles=len(asts))))
