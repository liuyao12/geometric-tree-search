"""Passive complete-file joins only. Never import or call offered science."""
from pathlib import Path
import collections
import hashlib
import json
import struct

D = Path(__file__).resolve().parents[1]
C = D / 'review-C'
A = D / 'actual/mechanism-0'
O = D / 'actual/mechanism-0.observer'

def pin(path):
    path = Path(path)
    body = path.read_bytes()
    return dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())

def load(path):
    path = Path(path)
    assert '.partial' not in path.name, 'Never parse a partial'
    return json.loads(path.read_bytes())

def wire(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False,
                      allow_nan=False).encode('utf8')

def digest(value):
    return hashlib.sha256(wire(value)).hexdigest()

def same(left, right):
    return wire(left) == wire(right)

def require(ok, description):
    if not ok:
        raise AssertionError(description)

checks = []
out = dict(schema='typed-principal-mechanism-actual-scientific-review-v1',
           reviewer_identity='/root/recovered_batch_review',
           review_passed=False, passive_saved_evidence_only=True, source_only=False,
           scientific_imports=0, scientific_calls=0, replays=0,
           fixtures_executed_by_reviewer=0, partial_files_parsed=False,
           actual_execution_authorized=False, retries_authorized=False,
           scope='Independent passive complete saved-record and reviewed-Source correspondence audit. '
                 'No mathematical checker, unifier, miner, compiler, State, Graph or scientific helper replay.')

def check(name, operation):
    try:
        evidence = operation()
        checks.append(dict(id=name, passed=True, evidence=evidence))
    except Exception as error:
        checks.append(dict(id=name, passed=False, error=type(error).__name__ + ': ' + str(error)))

plan_path = D / 'root/plan-mechanism-0-v1.json'
plan = load(plan_path)
result = load(A / 'result.json')
s = result['scientific_result']
header = load(A / 'worker-header.json')
terminal = load(A / 'terminal.json')
observer = load(O / 'observer.json')
grant_path = D / 'root/grant-mechanism-0-v1.json'
grant = load(grant_path)
consumed = load(A / 'CONSUMED.json')
tool_path = D / 'root/tool-terminal-receipt-v1.json'
tool = load(tool_path)
prior_path = C / 'typed-principal-mechanism-whole-Source-plan-review-v1.json'
prior = load(prior_path)
queries = result['native_queries']
stages = result['native_transport']['request_stages']
query_uses = collections.defaultdict(list)

def source_and_once():
    require(pin(plan_path)['sha256'] == '665d35945fda003128774fc1a75f9f8fb3ea2cfcb72465b1313127ffa913c93e', 'exact reviewed plan')
    require(pin(prior_path)['sha256'] == '25849b2a4c150c83343e6a5e71edfe3b5e4e78a90403c130d7cb7a8db15e8974' and prior['review_passed'], 'exact full independent Source review')
    require(len(plan['files']) == 90 and same(plan['files'], prior['source_closure_pins']), 'same 90 reviewed source rows')
    for row in plan['files']:
        require(same(pin(row['path']), row), 'unchanged exact source: ' + row['path'])
    require(grant['authorized'] is True and type(grant['uses']) is int and grant['uses'] == 1, 'fresh one-use grant')
    require(grant['plan_sha256'] == pin(plan_path)['sha256'] and same(grant['review'], pin(prior_path)), 'grant exact plan and review')
    barrier = load(grant['barrier']['path'])
    require(same(pin(grant['barrier']['path']), grant['barrier']), 'barrier raw pin')
    require(all(barrier[k] is True for k in ['B_tools_stopped','C_tools_stopped','L_tools_stopped','current_actual_directories_absent']), 'saved pre-actual idle barrier')
    require(consumed == dict(schema='proof-search-case-consumed-v1', case_id='mechanism-0', uses=1,
                            plan_sha256=pin(plan_path)['sha256'], grant_sha256=pin(grant_path)['sha256']), 'one exact consumed receipt')
    require(plan['stage'] == 'mechanism' and plan['required_upstream_ids'] == [] and plan['upstream_receipts'] == [], 'cold mechanism only; no old exports')
    out.update(plan=pin(plan_path), source_closure_pins=plan['files'], prior_full_Source_review=pin(prior_path),
               grant=pin(grant_path), barrier=grant['barrier'])
    return dict(source_rows=90, prior_review_reused_by_exact_hash=True, source_algorithm_reexecution=False,
                actual_population=1, consumed_uses=1, no_upstream_adoption=True)

check('exact Source closure, prior full review, cold once grant and barrier', source_and_once)

def custody_resources():
    files = sorted(p for root in (A, O) for p in root.rglob('*') if p.is_file())
    require(len(files) == 14 and not any('.partial' in p.name for p in files), '14 complete files; no partials')
    actual_pins = [pin(p) for p in files]
    result_pin = pin(A / 'result.json')
    require(same(header['result'], result_pin) and same(terminal['result'], result_pin), 'result/header/terminal pin join')
    require(same(terminal['header'], header), 'complete embedded header')
    require(result['status'] == header['status'] == 'COMPLETE', 'worker complete')
    require(result['source_unchanged'] is True and header['source_unchanged'] is True and terminal['sources_unchanged'] is True, 'saved before/after source guards')
    require(result['first_Root_fault'] is False and header['first_Root_fault'] is False and result['error'] is None, 'no saved Root first fault')
    require(terminal['header_valid'] and terminal['process_exit_code'] == observer['parent_exit_code'] == 0, 'worker and parent known zero')
    require(terminal['reason'] is None and terminal['errors'] == [] and observer['reason'] is None and observer['errors'] == [], 'no hidden custody errors')
    require(terminal['threads_terminal'] and terminal['final_custody_gate_passed'] and observer['resource_candidate_accepted'], 'all complete final gates')
    owner = load(A / 'owned-child.json')
    require(same(owner, observer['owned_child']) and owner['plan_sha256'] == pin(plan_path)['sha256'], 'same exact owned child')
    tr = result['native_transport']
    require(owner['child_pid'] == owner['child_pgid'] == tr['parent_pid'] == tr['parent_pgid'] == tr['native_pgid'], 'Native belongs to worker-owned process group')
    require(tr['closed'] and tr['all_reaped'] and tr['native_exit_code'] == tr['wait4_status'] == 0 and tr['cleanup_errors'] == [], 'Native closed/reaped normal zero')
    require(tr['termination_signals'] == [] and tr['stdout_eof'] and tr['stdout_pending_bytes'] == 0 and tr['stderr_complete'], 'clean Native pipes')
    require(tr['stderr_bytes'] == 0 and tr['stderr_hex'] == '' and tr['same_owned_process_group'], 'no Native stderr and exact ownership')
    for root, logs in [(A, terminal['logs']), (O, observer['logs'])]:
        for name, row in logs.items():
            require(row['eof'] and not row['overflow'] and row['stored'] == row['bytes'] == (root/(name+'.bin')).stat().st_size <= plan['limits']['log_bytes'], 'bounded complete ' + str(root/name))
    require(same(load(O/'stdout.bin'), terminal), 'observer captured complete parent stdout receipt')
    worker_stdout = load(A/'stdout.bin')
    require(worker_stdout['status'] == 'COMPLETE' and worker_stdout['callbacks'] == header['callbacks'], 'worker stdout boundary')
    require(tool['session_id'] == 92535 and tool['exit_code'] == 0, 'Root transcription of exact terminal tool return')
    summary = json.loads(tool['complete_output'])
    require(summary['resource_candidate_accepted'] and summary['parent_exit_code'] == 0 and summary['case_id'] == 'mechanism-0', 'complete observer printed summary')
    parent_bound = (terminal['parent_usage']['ru_maxrss'] + max(terminal['child_usage']['ru_maxrss'],header['python_peak_after_output_bytes'])
                    + header['native_peak_bytes'] + terminal['memory_terminal_output_reserve_bytes'])
    whole_bound = parent_bound + observer['final_observer_peak_bytes'] + observer['final_output_memory_reserve_bytes']
    require(parent_bound == terminal['conservative_combined_peak_bytes'] == 320323584, 'independent conservative parent sum')
    require(whole_bound == observer['conservative_whole_peak_bytes'] == observer['final_conservative_whole_peak_bytes'] == summary['conservative_whole_peak_bytes'] == 351404032 < plan['limits']['memory_bytes'], 'whole memory including two output reserves')
    require(result['callbacks'] == header['callbacks'] == 530252 <= plan['limits']['root_callbacks'], 'Root callback gate')
    require(result['elapsed_seconds'] < plan['limits']['work_seconds'] and header['seconds'] < plan['limits']['positive_seconds'], 'saved worker clocks')
    require(terminal['known_exit_seconds'] <= 180 and terminal['final_custody_gate_seconds'] <= 210 and observer['final_observer_gate_seconds'] <= 210 and summary['seconds'] <= 210, 'positive/custody/final output samples')
    total = sum(p['bytes'] for p in actual_pins)
    require(result_pin['bytes'] <= plan['limits']['result_bytes'] and total + plan['limits']['reserved_outer_bytes'] <= plan['limits']['physical_bytes'], 'all final physical files plus unchanged outer reserve')
    require(observer['stored_bytes_before_observer_receipt']+observer['receipt_allowance_bytes'] <= plan['limits']['physical_bytes'], 'observer receipt allowance')
    require(pin(A/'native/boundary-oracle')['sha256'] == pin(plan['native']['executable_path'])['sha256'], 'exact pinned Native executable copy')
    historical = D.parent/'gcts-learned-selector-proof-pilot-20261020/actual/acquire-0/native/code.bin'
    require(historical.exists() and pin(A/'native/code.bin')['sha256'] == pin(historical)['sha256'], 'same complete fixed Native program raw bytes as prior acquisition')
    code_header = struct.unpack('<6I',(A/'native/code.bin').read_bytes()[:24])
    require(code_header == (0x47544d32,92457,88986,0,1,2) and tr['ready'] == 'READY 92457 88986 0 1 2', 'fixed binary program header and Native READY join')
    require(pin(A/'native/input.bin')['sha256'] == queries[-1]['input_sha256'] and pin(A/'native/output.bin')['sha256'] == queries[-1]['output_sha256'], 'retained last Native raw input/output')
    require(struct.unpack('<3I',(A/'native/output.bin').read_bytes()[:12])[:2] == (0x47544d34,queries[-1]['result']['state']), 'last raw output state metadata')
    out.update(actual_file_pins=actual_pins, tool_terminal_transcription=pin(tool_path),
               resource_admitted=True, physical_final_actual_bytes=total,
               physical_with_unchanged_outer_reserve_bytes=total+plan['limits']['reserved_outer_bytes'],
               memory=dict(parent_conservative_bytes=parent_bound, whole_conservative_bytes=whole_bound),
               clock_samples=dict(worker_result_seconds=result['elapsed_seconds'], worker_header_seconds=header['seconds'],
                 parent_final_custody_gate_seconds=terminal['final_custody_gate_seconds'], observer_elapsed_sample=observer['elapsed_seconds'],
                 final_observer_gate_seconds=observer['final_observer_gate_seconds'], final_printed_summary_seconds=summary['seconds']),
               tool_transcription_scope='Root transcription is separate from independent complete on-disk custody. Clock samples are distinct boundaries, not exact launch-to-tool-end wall clock.')
    return dict(complete_files=14, memory_bytes=whole_bound, final_physical_bytes=total,
                Native_closed_and_reaped=True, no_partials=True, final_tool_exit=0)

check('complete process custody, raw output pins, owned group and all resource gates', custody_resources)

def native_records():
    require(len(queries) == len(stages) == result['native_requests_started'] == 70 <= 512, 'global Native start/completion guard')
    require(same(s['native_records'], queries), 'science retains every full raw owned query')
    joins = []
    for ordinal,(q,st) in enumerate(zip(queries,stages)):
        require(type(q['id']) is int and q['id'] == ordinal == st['ordinal'] == st['record_id'] and st['stage'] == 'COMPLETED', 'ordered Native stage/id completion')
        require(st['purpose'] == q['purpose'] and type(st['limit']) is int and st['limit'] == 1000000000, 'exact purpose and original per-query micro-step budget')
        require(q['query_target'] == 'fixed_assertion' and q['request']['protocol'] == 'gcts-fol-1' and q['request']['blocks'] == [], 'full fixed assertion protocol and no imported blocks')
        require(digest(q['request']) == q['request_sha256'] == st['request_sha256'], 'all literal request fields/digest')
        for name in ['input_sha256','output_sha256']:
            require(q[name] == st[name] and len(q[name]) == 64, 'raw binary digest stage join')
        require(q['result']['status'] in ['accepted','rejected'] and q['result']['state'] == (0 if q['result']['status']=='accepted' else 1), 'Native status and state')
        require(q['result']['start'] == 88986 and 0 <= q['result']['micro_steps'] <= st['limit'], 'unchanged micro-program entry and micro-step budget')
        joins.append(dict(id=ordinal, purpose=q['purpose'], status=q['result']['status'], limit=st['limit'], request_sha256=q['request_sha256'],
                          input_sha256=q['input_sha256'], output_sha256=q['output_sha256'], result_sha256=digest(q['result'])))
    census = dict(collections.Counter(q['result']['status'] for q in queries))
    require(census == {'accepted':32,'rejected':38}, 'exact Native status census')
    out.update(Native_query_joins=joins, Native_status_counts=census,
      Native_limit_scope='The query limit counts saved micro_steps. The much larger physical_steps report is a separate counter and is not mislabeled as that budget.',
      resolved_Root_message_erratum='Root corrected its informal all-70-accepted message. Exactly 70 records completed: 32 accepted, 38 rejected compiler candidates. No blanket logical acceptance is inferred.')
    return dict(total=70, accepted=32, rejected=38, unknown=0, incomplete=0)

check('every owned Native request/result, stage, digest, budget and full science copy', native_records)

def use(q, label, spec, proof=None, target=None):
    require(type(q['id']) is int and 0 <= q['id'] < len(queries) and same(q,queries[q['id']]), 'full owned Native record: '+label)
    require(same(q['request']['theory'],spec['theory']), 'exact Native theory: '+label)
    if proof is not None:
        require(same(q['request']['proof'],proof), 'exact full proof: '+label)
    if target is not None:
        require(same(q['request']['target'],target), 'exact actual target: '+label)
    query_uses[q['id']].append(label)

def controls():
    counts = dict(numeric=23, word=48, graph=22, encoding=40, principal=53, mechanism_corpus=16)
    rows = []
    for name,count in counts.items():
        receipt = s['controls'][name]
        require(receipt['complete'] is True and len(receipt['controls']) == count, 'complete '+name+' control count')
        require(len({x['id'] for x in receipt['controls']}) == count and all(x['status']=='PASSED' for x in receipt['controls']), 'each distinct '+name+' control passed')
        rows.append(dict(kind=name, count=count, ids=[x['id'] for x in receipt['controls']], receipt_sha256=digest(receipt)))
    require(s['controls']['word']['tiny_full_byte_pair_comparisons'] == 49, '49 authored byteword-pair controls distinct from 48 control rows')
    require(s['controls']['encoding']['canonical_values'] == 21 and s['controls']['encoding']['malformed_values'] == 7, 'encoder component counts')
    require(s['controls']['inherited']['status'] == 'complete' and s['controls']['inherited']['callback_identity_propagated'] and s['controls']['inherited']['global_dead_forced_generation_controls'], 'inherited Tiny diagnostics')
    require(same(s['controls']['inherited']['base_solutions'],s['controls']['inherited']['marked_solutions']), 'saved Tiny complete solution equality')
    require(all(x['complete'] for x in s['controls']['inherited']['full_domain_audits']), 'saved full Tiny audits')
    negative = next(x for x in s['controls']['mechanism_corpus']['controls'] if x['id']=='external-negative-valuation')
    require(negative['premise_values'] == [True,True,True] and negative['target_value'] is False and negative['valuation'] == dict(P=True,Q=True,R=False,S=False), 'external negative valuation receipt')
    out.update(control_counts=counts, controls_total=sum(counts.values()), control_receipt_joins=rows,
               finite_controls_scope='All 202 finite authored control rows returned PASSED in this one admitted job. They are not discovered donor routes, a proof of all implementations or a new theorem. The independent reference is separately peer-reviewed; this reviewer does not self-admit its author-written controls.',
               independent_reference_peer_review=pin(D/'diagnostics-L/typed-independent-principal-reference-Source-review-v1.json'))
    return dict(total=202, distinct_row_counts=counts, separate_Tiny_audits=len(s['controls']['inherited']['full_domain_audits']))

check('all finite controls returned, independent-reference peer boundary and negative valuation', controls)

model_maps = {}
def models():
    records = s['records']+s['contexts']
    expected = s['inputs']['donors']+s['inputs']['contexts']
    require(same(s['inputs'],load(plan['input_path'])) and len(records)==6, 'exact complete original 2+4 statement-only input')
    rows=[]
    for case,spec in zip(records,expected):
        require(same(case['spec'],spec), 'all original donor/context fields')
        comp=case['compiler']; model=case['model']; diff=case['word_reference_differential']
        require(comp['status']=='complete' and comp['theory_query'] in comp['queries'], 'complete fresh compiler')
        for index in comp['queries']:
            q=queries[index]; use(q,'compiler:'+spec['id'],spec)
            require(q['purpose'] in ['first_order_theory_admission','first_order_tautology','first_order_scheme'], 'compiler purpose')
        require(queries[comp['theory_query']]['result']['status']=='accepted', 'accepted exact theory intake')
        require(diff['complete'] and diff['old']['complete'] and diff['new']['complete'] and same(diff['new'],case['reference_check']), 'both actual reference gates')
        require(same({k:v for k,v in diff['old'].items() if k not in ['schema','storage_scope']},
                     {k:v for k,v in diff['new'].items() if k not in ['schema','storage_scope']}), 'all substantive v1/v3 reference fields')
        require(case['word_model_check']['complete'] and model['arity']==0 and model['mode_ids']=={} and model['word_terminator']==256, 'same empty-inventory aligned model')
        dictionary=model['word_dictionary']
        decoded=[json.loads(bytes.fromhex(x)) for x in dictionary]
        require(len(dictionary)==len(set(dictionary)) and all(wire(x).hex()==raw for x,raw in zip(decoded,dictionary)), 'every distinct full literal canonical word')
        require(same(decoded[0],spec['target']) and model['initial']['marks']==[[[4*(spec['length']-1),100],0]], 'target-first assigned ID zero')
        placement={tuple(p['key']):p for p in model['placements']}
        require(len(placement)==len(model['placements'])==case['reference_check']['accepted_placements'], 'all exact placement keys')
        incidence=collections.defaultdict(set)
        for key,p in placement.items():
            slot,index=p['command_reference']; cmd=model['domains'][slot][index]
            require(type(slot) is int and type(index) is int and slot==p['metadata']['slot']==key[0] and index==key[2], 'placement command/domain reference')
            marks={tuple(point):value for point,value in p['marks']}
            require(all(type(v) is int for v in marks.values()), 'exact integer marks')
            require(same(decoded[marks[(4*slot,100)]],cmd['formula']) and same(decoded[marks[(4*slot+1,100)]],cmd), 'full formula and command literal payload joins')
            require(marks[(4*slot+2,90)]==0, 'scalar mode zero retained')
            for row,formula in p['metadata']['requirements']:
                require(same(decoded[marks[(4*row,100)]],formula), 'complete literal guarded formula requirement')
            for point,_ in p['occupancy']+p['marks']:
                incidence[tuple(point)].add(key)
        stored={tuple(x['point']):{tuple(k) for k in x['keys']} for x in model['dependencies']}
        require(incidence==stored, 'complete literal stored t+m incidence join')
        model_maps[spec['id']]=(model,placement,decoded)
        rows.append(dict(case_id=spec['id'], placements=len(placement), complete_words=len(decoded), compiler_query_ids=comp['queries'],
                         reference_sha256=digest(case['reference_check']), model_sha256=digest(model), input_sha256=digest(spec)))
    out['six_fresh_model_reference_joins']=rows
    return dict(models=6, both_original_and_subtree_reference_ran=True, full_literal_wire_joins=True,
                scope='Saved complete model/word/reference field correspondence only; no candidate generator, Graph update, semantic solver or reference verifier replay.')

check('six fresh original models, dual full reference receipts and literal word/incidence bindings', models)

def selected_literal(case_id, members, proof):
    model,placement,decoded=model_maps[case_id]
    require(len({tuple(k) for k in members})==len(members), 'distinct saved selected keys')
    commands={}
    for key in members:
        p=placement[tuple(key)]; slot=p['metadata']['slot']; marks={tuple(x):v for x,v in p['marks']}
        command=decoded[marks[(4*slot+1,100)]]
        require(slot<len(proof) and same(command,proof[slot]) and same(decoded[marks[(4*slot,100)]],proof[slot]['formula']), 'selected key full command/formula belongs to exact proof row')
        if p['metadata']['kind']=='command': commands[slot]=command
    require(set(commands)==set(range(len(proof))), 'every proof row has a saved command placement')

def donors_fragments():
    require(s['acquisition_complete'] is True and len(s['certificates'])==5 and len(s['donor_outcomes'])==2, 'fresh complete donor acquisition')
    donor_rows=[]; eligible=[]
    for rec,outcome in zip(s['records'],s['donor_outcomes']):
        spec=rec['spec']; search=rec['search']; gate=rec['proof_check']; proof=search['proof']
        require(search['status']=='symbolic_proof_candidate' and not search['cluster_ordering'] and search['root_restored'], 'fresh conventional donor and exact rollback')
        require(search['metrics']['attempts']==len(proof)==spec['length'] and len([e for e in search['trace'] if e['event']=='extend'])==len(proof), 'actual full donor extension counts')
        require(gate['status']=='HOST_REGION_NATIVE_ACCEPTED' and gate['host_check']['accepted'] and gate['native_proof_accepted'] and gate['region']['complete'], 'saved three donor gates')
        require(gate['host_check']['rows']==len(proof) and same(gate['host_check']['target'],spec['target']) and gate['region']['decoded_rows']==len(proof), 'same donor gate proof/target')
        use(gate['native_record'],'whole_donor:'+spec['id'],spec,proof,spec['target'])
        selected_literal(spec['id'],search['placements'],proof)
        require(len(rec['candidates'])==len(proof)+1, 'whole plus every retained ancestor-root candidate')
        for i,cand in enumerate(rec['candidates']):
            require(cand['ordinal']==i and cand['kind']==('full' if i==0 else 'ancestor_closure'), 'complete candidate order')
            require(cand['source_row']==(None if i==0 else i-1), 'exact source row')
            require(cand['ancestry']==sorted(set(cand['ancestry'])), 'full ordered ancestry provenance')
            mapping={old:new for new,old in enumerate(cand['ancestry'])}
            copied=[]
            for old in cand['ancestry']:
                row=dict(proof[old])
                if row['rule']=='mp':
                    row['antecedent']=mapping[row['antecedent']];row['implication']=mapping[row['implication']]
                copied.append(row)
            require(same(copied,cand['proof']), 'literal ancestor row copy and reference renaming')
            if cand['eligible']:
                eligible.append((rec,cand))
                require(cand['reason']=='fresh_Host_and_Native_accepted' and cand['host_check']['accepted'], 'eligible fragment fresh Host')
            else:
                require(all(row['rule']=='axiom' for row in cand['proof']) and cand['family'] is None, 'only axiom-only candidates ineligible here')
        require(outcome['whole_native_accepted'] and outcome['retained_fragment_certificates']==sum(c['eligible'] for c in rec['candidates']), 'outcome exact fresh fragment census')
        donor_rows.append(dict(id=spec['id'], proof_rows=len(proof), attempts=search['metrics']['attempts'],
          Native_query=gate['native_record']['id'], proof_sha256=digest(proof), proof=proof,
          selected_placements=search['placements'], region=gate['region'], candidates=len(rec['candidates']),
          retained_fragments=outcome['retained_fragment_certificates'], root_restored=True))
    require(len(eligible)==5, 'five freshly retained fragments')
    fragment_rows=[]
    for n,(cert,(rec,cand)) in enumerate(zip(s['certificates'],eligible)):
        spec=rec['spec'];q=cert['native_record'];family=cert['families']['principal'];t=family['certificate']['typing'];ind=cert['principal_check']['independent']
        require(same(cert['spec'],spec) and same(cert['proof'],cand['proof']) and same(cert['target'],cand['target']), 'fragment exact candidate and case')
        require(same(cert['full_donor_proof'],rec['search']['proof']) and same(cert['full_donor_check'],rec['proof_check']), 'full donor provenance retained')
        use(q,'fragment:'+str(n),spec,cert['proof'],cert['target'])
        require(q['result']['status']=='accepted' and q['id']==cert['provenance']['native_query'] and q['request_sha256']==cert['provenance']['request_digest'], 'accepted exact fragment Native provenance')
        require(same(cert['family'],family) and same(cand['families'],cert['families']) and same(cand['principal_check'],cert['principal_check']), 'all fragment family/check aliases retain full values')
        require(cert['principal_check']['complete'] and ind['complete'], 'production replay and independent actual extraction completed')
        for field in ['graph','row_formulas','premises','conclusion','port_count','parameters']:
            require(same(t[field],ind[field]), 'live independent '+field+' correspondence')
        require(same(family['template'],ind['template']) and same(family['certificate']['donor_arguments'],ind['concrete_arguments']) and same(family['certificate']['port_occurrences'],ind['port_aliases']), 'live complete template/argument/alias joins')
        require(family['parameters']==t['parameters']==cert['principal_check']['parameters'] and family['id']==family['structural_id']==cert['principal_check']['structural_id'], 'unmodified structural identity')
        require(family['certificate']['request_sha256']==q['request_sha256'] and same(family['certificate']['provenance'],cert['provenance']), 'certificate original request/provenance')
        require(same(family['certificate']['concrete_row_formulas'],[x['formula'] for x in cert['proof']]), 'all concrete rows retained')
        fragment_rows.append(dict(certificate_ordinal=n, donor=spec['id'], provenance=cert['provenance'], proof_rows=len(cert['proof']),
          Native_query=q['id'], atom_id=cert['families']['atom']['id'], principal_structural_id=family['structural_id'],
          parameters=t['parameters'], graph=t['graph'], premises=t['premises'], conclusion=t['conclusion'],
          principal_check_sha256=digest(cert['principal_check']), native_request_sha256=q['request_sha256']))
    out.update(fresh_donor_proof_joins=donor_rows, fresh_fragment_typing_joins=fragment_rows)
    return dict(donors=2, whole_donor_rows=8, all_fragment_candidates=10, retained_fragment_occurrences=5,
      scope='Saved actual Host/Native and independent typing receipts are bound to all literal rows; reviewer does not rerun any proof, unification or extraction algorithm.')

check('fresh searched donor proofs, every fragment and live independent principal typing', donors_fragments)

def pairing():
    pair=s['pairing']; libs=s['libraries'];certs=s['certificates']
    require(pair['raw_certificates']==5 and pair['paired_units']==3 and pair['principal_structures']==2 and pair['no_principal_coalescence'], 'same old atom quotient and no principal dedup')
    require(len(libs['atom'])==len(libs['principal'])==len(pair['units'])==3, 'same number/order paired inventory units')
    covered=[];rows=[]
    for i,u in enumerate(pair['units']):
        member_indices=[x['certificate_ordinal'] for x in u['members']];covered+=member_indices
        require(member_indices==sorted(member_indices), 'first-use certificate order')
        for m in u['members']:
            cert=certs[m['certificate_ordinal']]
            require(same(m['provenance'],cert['provenance']) and cert['families']['atom']['id']==u['atom_structural_id']==u['paired_unit_id'], 'all exact atom-class members')
            exemplar=certs[member_indices[0]]['families']['principal'];family=cert['families']['principal']
            for field in ['parameters','template','structural_id']:
                require(same(exemplar[field],family[field]), 'all members principal identity ignoring concrete donor/provenance')
            require(same(exemplar['certificate']['typing']['graph'],family['certificate']['typing']['graph']), 'all member full graph')
        for mode in ['atom','principal']:
            wrap=libs[mode][i];raw=certs[member_indices[0]]['families'][mode];gate=u['wrapper_checks'][mode]
            require(same(wrap['structural_family'],raw), 'exact unmodified inner structural family')
            require(all(same(wrap[k],v) for k,v in raw.items() if k!='id'), 'every forwarded original field')
            require(wrap['id']==wrap['paired_unit_id']==u['paired_unit_id'] and wrap['source_certificate_ordinal']==member_indices[0] and wrap['abstraction_mode']==mode, 'outer paired identity kept separate')
            require(gate['complete'] and gate['source_certificate_ordinal']==member_indices[0] and gate['structural_id']==raw['id'], 'actual wrapper gate exact source')
            if mode=='principal':require(gate['principal_structural_check']['complete'] and gate['principal_structural_check']['structural_id']==raw['id'], 'actual exact inner principal verify receipt')
        rows.append(dict(paired_unit_id=u['paired_unit_id'], principal_structural_id=u['principal_structural_id'], certificate_ordinals=member_indices,
                         atom_parameters=libs['atom'][i]['parameters'], principal_parameters=libs['principal'][i]['parameters']))
    require(sorted(covered)==list(range(5)), 'no certificate omitted or duplicated across paired classes')
    out['paired_inventory_joins']=rows
    return dict(raw_certificates=5, atom_class_units_in_both_modes=3, principal_structures=2, principal_coalescence=False,
                generic_MP_already_available=True)

check('paired class multiplicity, all cross-member identities and exact structural inner wrappers', pairing)

def cells():
    ordered=[];rows=[];target_rows=[];packet_rows=[]
    for case in s['contexts']:
        spec=case['spec'];model,placements,decoded=model_maps[spec['id']]
        for ce in case['cells']:
            cell=ce['cell'];ordered.append(cell);lib=s['libraries'][cell['mode']]
            if cell['view']=='one_mp':lib=[f for f in lib if sum(x['rule']=='mp' for x in f['template']['proof'])==1]
            require(same(ce['paired_unit_ids'],[f['paired_unit_id'] for f in lib]), 'same paired unit order and exact one-MP restriction')
            packets=ce['pool']['packets'];pool=ce['pool']
            require(pool['complete'] and pool['termination']=='declared_occurrences_exhausted' and pool['validation_checks']==ce['validation_checks']<=plan['experiment_limits']['cluster_binding_work'], 'bounded ready pool complete')
            require(len(packets)<=16, 'original pool quota')
            require(all(x['kind']=='axiom' and same(x['formula'],spec['theory']['axioms'][x['name']]) for x in pool['source_occurrences']), 'all original licensed source occurrences')
            expected_selection={0:['first_packet']} if packets else {}
            for i,p in enumerate(packets):
                if sum(x['rule']=='mp' for x in p['checked_primitive_proof'])>=2 and same(p['result_formula'],spec['target']):
                    expected_selection.setdefault(i,[]).append('first_two_MP_declared_target_packet');break
            require(len(expected_selection)<=2 and [w['packet_ordinal'] for w in ce['selected_witnesses']]==list(expected_selection), 'fixed witness union without cherry-pick or backfill')
            distinct=len({wire(p['pending']) for p in packets})
            require(distinct==pool['distinct_primitive_continuations'], 'exact literal continuation classes')
            for i,p in enumerate(packets):
                require(p['pool_ordinal']==i and p['prefix_rows']==0 and same(p['commands'],p['checked_primitive_proof']), 'empty prefix and full primitive proof')
                require(p['family'] in ce['paired_unit_ids'] and p['host_check']['accepted'] and p['host_check']['rows']==len(p['commands']) and same(p['host_check']['target'],p['result_formula']), 'same family and actual Host target')
                require(all(b['kind']=='axiom' and same(b['formula'],spec['theory']['axioms'][b['name']]) for b in p['source_binding']), 'every receptor is an actual named axiom occurrence')
                selected_literal(spec['id'],p['members'],p['checked_primitive_proof'])
                require(same(p['members'],p['pending']), 'all empty-state packet members pending')
                pn=ce['packet_native'][i]
                require(pn['packet_ordinal']==i and pn['target_match']==same(p['result_formula'],spec['target']), 'per-packet exact target flag')
                whole=False
                if i in expected_selection:
                    require(pn['clauses']==expected_selection[i] and pn['status']=='accepted' and pn['native_limit']==1000000000, 'selected actual status and schedule reason')
                    q=pn['native_record']; use(q,'witness:'+spec['id']+':'+cell['view']+':'+cell['mode']+':'+str(i),spec,p['checked_primitive_proof'],p['result_formula'])
                    require(q['result']['status']=='accepted' and q['purpose']=='principal_mechanism_'+spec['id']+'_'+cell['view']+'_'+cell['mode']+'_'+str(i), 'selected exact owned purpose')
                    whole=same(p['result_formula'],spec['target']) and len(p['commands'])==spec['length']
                    require(pn['whole_target_certificate_accepted']==whole and (pn['whole_region'] is not None)==whole, 'local conclusion versus full target separated')
                    if whole:
                        region=pn['whole_region']
                        require(region['complete'] and region['decoded_rows']==spec['length'] and region['selected_placements']==region['required_points']==2*spec['length'], 'same full literal selected region and gate')
                        target_rows.append(dict(cell=cell,packet_ordinal=i,Native_query=q['id'],proof=p['checked_primitive_proof'],members=p['members'],region=region))
                    require(any(same(pn,w) for w in ce['selected_witnesses']), 'full selected witness alias')
                else:require(pn['status']=='NATIVE_UNREQUESTED' and pn['native_record'] is None and pn['clauses']==[], 'unrequested kept unadmitted')
                packet_rows.append(dict(cell=cell, packet_ordinal=i, paired_unit_id=p['family'], proof_rows=len(p['commands']),
                  MP_rows=sum(c['rule']=='mp' for c in p['commands']), result_formula=p['result_formula'],
                  full_target_certificate=whole, Native_status=pn['status'], Native_query=(pn.get('native_record') or {}).get('id'),
                  members=p['members'], source_binding=p['source_binding'], proof_sha256=digest(p['checked_primitive_proof'])))
            expected=dict(host_trial_packets=len(packets),distinct_primitive_continuations=distinct,selected_Native_witnesses=len(expected_selection),
              Native_accepted=len(expected_selection),Native_unknown=0,Native_unrequested=len(packets)-len(expected_selection),
              whole_target_certificates=sum(p['whole_target_certificate_accepted'] for p in ce['selected_witnesses']))
            require(same(ce['counts'],expected) and len(ce['packet_native'])==len(packets), 'all exact cell counts')
            if cell['view']=='one_mp':require(all(sum(x['rule']=='mp' for x in p['commands'])==1 for p in packets), 'one-MP audit view contains only generic single-step expansions')
            rows.append(dict(cell=cell,counts=expected,termination=pool['termination'],validation_checks=ce['validation_checks']))
    require(same(ordered,s['inputs']['protocol']['cells']) and len(rows)==16, 'all and only fixed 16 cells in preregistered order')
    require(len(packet_rows)==30 and len(target_rows)==4 and sum(x['counts']['Native_accepted'] for x in rows)==16 and sum(x['counts']['Native_unrequested'] for x in rows)==14, 'complete fixed mechanism population')
    require(all(not x['full_target_certificate'] for x in packet_rows if x['cell']['context_id']=='context-inconsistent-middle'), 'negative context has no certified full target')
    out.update(cell_counts=rows, packet_literal_joins=packet_rows, full_target_certificate_occurrences=target_rows)
    return dict(cells=16, Host_trial_packets=30, selected_Native_accepted=16, Native_unrequested=14,
                full_target_certificate_occurrences=4, full_target_context_statements=3, one_MP_full_target_certificates=0)

check('all 16 cells, actual receptor/member bindings and fixed selected witness proof scope', cells)

def classification():
    require(result['status']=='COMPLETE' and s['status']=='MECHANISM_RECORD_COMPLETE' and s['record_complete'] and s['stage_complete'], 'complete stage and record')
    require(s['export'] is None and s['resource_admitted'] is False and result['native_transport']['logical_proof_accepted'] is False, 'internal nonauthority flags retained; outer review gives scoped resource classification')
    require(result['old_qualification_reused'] is False and result['full_physical_Wang_claim'] is False, 'no old rescue or full physical claim')
    require(set(query_uses)==set(range(70)), 'all 70 Native records attached to exact scientific/compiler roles')
    require(all(len(x)==1 for x in query_uses.values()), 'each query occurrence assigned exactly once by role')
    out['Native_query_roles']=[dict(id=i,uses=query_uses[i]) for i in range(70)]
    out['permitted_conclusions']=[
      'One exact fresh mechanism job completed under all original resource gates. Both conventional S0 donor statements were freshly found and checked.',
      'Five fresh fragment certificate occurrences produced three unchanged atom-class paired units in both modes; the principal structures number two and were not coalesced.',
      'All 202 authored controls returned PASSED, including the independently authored 53 principal controls and full v1/v3 model differential checks on six fresh models.',
      'At the declared empty-prefix axiom interface the principal two-MP family supplied full serial packets in atomic and opaque-equality contexts where the retained atom-family pool supplied only local one-MP packets.',
      'Sixteen fixed selected packets were freshly Native accepted. Four occurrences also had the exact full target region: constructor atom and principal, atomic principal, opaque-equality principal. This is three authored context statements, not four new theorems.',
      'Generic MP remained available in both libraries and all one-MP audit views; the contrast is packet representation and depth at this interface, not absence of proof composition in the atom baseline.'
    ]
    out['remaining_gaps_and_prohibited_inferences']=[
      'This passive audit does not replay Host, Native, unification, reference controls or region verification. It joins complete saved actual receipts to independently reviewed Source and exact literal inputs.',
      'Finite control success does not mechanize the general principal-family theorem or prove every implementation behavior. Principality remains relative to the fixed full MP DAG and exact-formula port quotient; it is not a minimum-premise or all-proof claim.',
      'Only sixteen selected packets have fresh Native authority. Fourteen other Host/trial packets remain NATIVE_UNREQUESTED; no selected partial local conclusion certifies its whole context target.',
      'The contexts are public authored mechanism tests. Constructor calibration intentionally matches donor shape. This is not blind or family-held-out generalization, a learned equality rule, or a newly discovered theorem.',
      'No recipient point search, trained selector, RL update, six-method comparison, statistical speedup, useful GCTS advantage, general resource fit or memory-phase causality was measured here.',
      'The full six-case D15 evaluation population and earlier failed jobs remain unchanged future/historical obligations. No old G0/G1/full-VM qualification or grant is rescued or reused.',
      'Observer elapsed, final gate and printed summary are distinct sampled boundaries. The Root transcription of tool exit zero is separately identified, not presented as an independent OS wall-clock measurement.'
    ]
    return dict(record_complete=True, resource_admitted=True, general_theory_mechanized=False,
                recipient_GCTS_search=False, RL=False, proof_search_advantage_established=False,
                new_theorem_claim=False, next_actual_authority=False)

check('full role coverage and honest admitted-mechanism conclusions and gaps', classification)

out['reviewer_author_correction'] = dict(predecessor_negative=pin(C/'typed-principal-mechanism-actual-scientific-review-v1.json'), predecessor_script=pin(C/'audit_complete_mechanism_saved_v1.py'), correction="The passive audit author expected empty mode_ids as [] instead of its actual strict JSON dictionary {}. Corrected the metadata-only assertion. The three subsequent missing-model/role checks were cascading omissions. This is a reviewer-author error, not a scientific Source or actual defect; both preimages are retained unchanged.")
out['checks']=checks
out['failed_checks']=[x for x in checks if not x['passed']]
out['review_passed']=not out['failed_checks']
out['tools_stopped_after_freeze']=True
path=C/'passive-audit-author-draft-v2.json'
require(not path.exists(), 'Review is immutable; never overwrite')
path.write_text(json.dumps(out,sort_keys=True,ensure_ascii=True,allow_nan=False,indent=2)+'\n')
print(json.dumps(dict(review=pin(path), checks=len(checks), failed_checks=out['failed_checks'], review_passed=out['review_passed'])))
