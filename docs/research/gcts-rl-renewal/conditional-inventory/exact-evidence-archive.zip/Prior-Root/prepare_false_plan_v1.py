"""Saved raw/AST metadata only; no codec or worker module evaluation."""
from pathlib import Path
import ast,hashlib,json
D=Path(__file__).parent;S=Path('/private/tmp/gcts-exact-evidence-ROOT-source-20261019');L=Path('/private/tmp/gcts-exact-evidence-source-20261019');PEER=Path('/private/tmp/gcts-exact-evidence-peer-20261019')
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,v):
 assert not p.exists(),p;p.write_text(json.dumps(v,sort_keys=True,indent=2,allow_nan=False)+'\n');return pin(p)
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
sources={k:pin(p)for k,p in dict(encoder=L/'exact_evidence_table_v1.py',inverse=S/'independent_evidence_inverse_v2.py',worker=S/'qualify_exact_evidence_worker_v5.py',runner=S/'run_exact_evidence_once_v2.py',observer=S/'observe_exact_evidence_once_v2.py').items()}
imports=[]
for role,d in sources.items():
 p=Path(d['path']);text=p.read_text();tree=ast.parse(text);compile(text,str(p),'exec')
 for n in ast.walk(tree):
  if isinstance(n,ast.Import):imports.extend(dict(role=role,line=n.lineno,kind='import',name=a.name)for a in n.names)
  elif isinstance(n,ast.ImportFrom):imports.append(dict(role=role,line=n.lineno,kind='from',name=n.module,level=n.level))
contract=save(S/'Root-Source-contract-v1.json',dict(schema='ROOT-exact-evidence-Source-contract-v1',author_identity='/root',author_identities=['/root','/root/conventional_library'],source_only=True,scientific_calls=0,module_evaluations=0,compile_without_evaluation=5,
 current_sources=sources,import_census=imports,project_imports_except_declared_dynamic=[] ,dynamic_imports='Worker imports exactly pinned encoder and independent inverse via importlib.spec_from_file_location inside the single charged work window. All other imports are stdlib; no proof/Model/search/Native modules or opaque microcode.',
 Encoder_API=pin(L/'API-v1.json'),Encoder_Source_contract=pin(L/'Source-contract-v1.json'),independent_obligations=pin(PEER/'design-and-qualification-obligations-v1.json'),
 inverse_custody_negative_v1=pin(PEER/'typed-inverse-preliminary-Source-review-v1-negative.json'),inverse_v2_delta=pin(PEER/'typed-inverse-preliminary-Source-review-v2.json'),
 changes='New standalone ordinary-evidence engineering control. No existing proof/tiling Source modified, no status or authority reclassification. Frozen complete scientific outputs are data, never proof routes supplied to a new search.',
 owned_stream='Independent inverse captures recursively immutable typed nodes before yielding. Source-only reviewed fix; actual inter-yield mutation diagnostics still unexecuted. Initial input exclusive ownership and trusted pinned stdlib/runtime/OS remain assumptions.',
 mathematical_scope='No proof calculus or search changes; representation-only exact bytes cannot supply Model permission, schema inventory admission, pruning, new theorem, candidate count or proof acceptance.',
 memory_scope='Full ordinary raw input+parsed value+freeze live transient is charged. Parsed input released after freeze; public wire and validation copies remain charged. Inputs serial. Scientific-worker peak only, Native absent; outer/observer memory excluded. This is not current search-worker memory measurement.',
 conformance='Standalone data storage only: no point-domain, marking, graph, generation, branch, fallback or rollback implementation changes. Exact whole artifact inverse is finite data-fidelity evidence, not fresh engine conformance or logical proof replay.',
 static_findings_preserved=['Root draft raw loader originally authenticated a second read rather than the returned payload; corrected before any module execution.','Root fixture records originally aliased later-mutated input/wire; corrected to owned snapshots before any execution.','Root inverseV1 failed inter-yield wire custody; independent negative preserved and V2 captures immutable nodes.','Depth convention made explicit:512 encoder edges corresponds to513 inverse nodes; boundary fixtures remain prospective.'],
 limitations=['Scalar builtin JSON operations and the independent scalar scan have bounded-input/OS gating, not continuous per-character deadline interruption.','FrozenTable ordinary immutability is not a hostile-Python sandbox; object.__setattr__/private mutation is outside public API.','No speed, compression ratio or memory fit is assumed before an admitted actual.','A new encoded representation cannot retroactively pass the failed old128MiB JSON writer; both current expanded and encoded numeric caps required.']))
inputs=[]
for name,path in [('full-base-control','/private/tmp/gcts-mp-schema-shadow-ROOT-20261019/actual-v1/result.json'),('full-shadow-packets','/private/tmp/gcts-mp-schema-shadow-ROOT-20261019/actual-v1/schema-shadow-result.json'),('full-prior-case002','/private/tmp/gcts-schema-admission-ROOT-20261019/prior-case002-fixed-bulk-result.json')]:
 inputs.append(dict(id=name,input=pin(path),kind='complete_ordinary_saved_JSON'))
limits=dict(work_seconds=180,overall_seconds=210,memory_bytes=1073741824,result_bytes=134217728,expanded_bytes=134217728,stdout_bytes=4194304,stderr_bytes=4194304)
declaration=save(D/'declaration-v1.json',dict(schema='ROOT-exact-evidence-qualification-declaration-v1',author_identity='/root',source_only=True,scientific_calls=0,actual_execution_authorized=False,goal_complete=False,
 current_sources=sources,Root_Source_contract=contract,inputs=inputs,aggregate_whole_raw_input_bytes=sum(r['input']['bytes']for r in inputs),limits=limits,
 scope='One once-only representation qualification over three whole already saved ordinary artifacts, complete retained data, no clipping/reduction. Full base+full shadow are from earlier successful shadow control; full priorcase002 retains its original UNKNOWN inventory status. No proof is rerun and no absent failed case002 result is invented.',
 comparison='Encoder inverse and independent ordinary-data inverse both compare every emitted canonical body byte plus exact external newline to the whole raw original. Whole saved wire is reread and validated. Repeated references are fully expanded; raw hashing alone is not the equality check.',
 fixture_scope='Authored data fixtures only, not mathematical theorem searches: bool/int/floatzero/order/Unicode/assignedzero/missing, caller/wire/materialized/interyield mutation, malformedwire, cyclic containers, bounded expansion/depth/work and exact callback object identity.',
 resource_scope='Same numeric180/210/1GiB/128MiB gates, but specialized representation-only profile without Native/search/Model lifetimes. Every setup/import/parse/freeze/validation/inverse/custody/serialization/fixture and known worker exit is charged. Three inputs serial, old mutable parser input released after freeze. Do not compare this RAM with integrated search workers as a fair measured improvement.',
 output_scope='Aggregate3encoded table files+summary result <=128MiB AND aggregate fully expanded original canonical files <=128MiB, both counted with their external newlines. Per-codec semantic bounds retain declared domain/defaults; encoder512edge/inverse513node depth aligned. Any future change to old expanded JSON cap interpretation needs a declared separate profile.',
 trust='Five current Source modules independently reviewed by Control, with Library encoder and Root inverse/harness/launcher authorship. Same Control identity fills Source and plans roles; not two independent people. Pinned Python3.12 plus bundled stdlib/loader/OS conditional trusted, no whole-runtime formal proof.',
 no_new_logical_authority=True,new_RL_training=False,recursive_proposer_enabled=False,unimplemented_integration=True,
 baseline_failures=pin('/private/tmp/gcts-schema-admission-ROOT-20261019/ROOT-negative-evidence-audit-v1.json'),
 next_if_qualified='Use component only after a separately reviewed data-boundary integration and newly declared comparisons preserving complete original registry/Model/search. Current two output/RAM failures remain failed.'))
plan=dict(schema='exact-evidence-once-plan-v1',invocation_id='exact-evidence-whole-artifacts-ROOT-20261019-v1',actual_directory=str(D/'actual-v1'),python=pin('/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12'),**sources,inputs=inputs,limits=limits,declaration=declaration)
assert len(plan)==12 and not Path(plan['actual_directory']).exists()
subject=hashlib.sha256(canonical(plan)).hexdigest()
auth=save(D/'authorization-draft-v1.json',dict(schema='exact-evidence-once-authorization-v1',author_identity='/root',actual_execution_authorized=False,maximum_actual_invocations=0,subject_sha256=subject,review_roles={},scope='False prospective metadata only; no codec/module/worker execution authorized.'))
plan['authorization']=auth;pp=save(D/'plan-draft-v1.json',plan)
index=save(D/'prospective-index-v1.json',dict(schema='ROOT-exact-evidence-prospective-index-v1',author_identity='/root',source_only=True,scientific_calls=0,actual_execution_authorized=False,maximum_actual_invocations=0,subject_sha256=subject,subject={k:v for k,v in plan.items()if k!='authorization'},plan_draft=pp,authorization_draft=auth,declaration=declaration,Root_Source_contract=contract,current_sources=sources,original_complete_inputs=inputs))
print(json.dumps(dict(index=index,subject_sha256=subject,contract=contract,declaration=declaration,scientific_calls=0)))
