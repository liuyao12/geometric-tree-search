"""Publication from saved ordinary packets only; no encoder/inverse evaluation."""
from pathlib import Path
import hashlib, html, json, re, zipfile

D=Path(__file__).parent
P=Path('/private/tmp/gcts-split-controls-publish-20261015/docs/research/gcts-rl-renewal/conditional-inventory')
L=Path('/private/tmp/gcts-exact-evidence-source-20261019')
S=Path('/private/tmp/gcts-exact-evidence-ROOT-source-20261019')
C=Path('/private/tmp/gcts-exact-evidence-peer-20261019')
def load(p): return json.loads(Path(p).read_bytes())
def canonical(v): return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()+b'\n'
def pin(p):
    p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def publish(name,v):
    p=P/name;p.write_bytes(canonical(v));return pin(p)
def esc(s): return html.escape(str(s))
def math(s): return r'\('+str(s)+r'\)'
def mib(n): return math(f'{n/1048576:.2f}'+r'\,\mathrm{MiB}')

audit=load(D/'ROOT-final-audit-v5.json')
peer=load(C/'typed-second-qualification-saved-review-v5.json')
assert audit['saved_data_only']is True and audit['goal_complete']is False
assert peer['saved_data_only']is True
plan=load(D/'plan-authorized-v5.json');actual=Path(plan['actual_directory'])
terminal=load(D/'plan-authorized-v5-terminal-observation/terminal.json')
runner=load(actual/'runner-receipt.json')
ok=audit['representation_admitted']is True
packet=load(audit['result_or_failure']['path'])
rows=packet.get('complete_inputs',packet.get('completed_input_packets',[]))
fixtures=packet.get('fixtures',packet.get('completed_fixture_prefix',[]))
assert (len(rows)==3 and len(fixtures)==48 and terminal['terminal_gate_passed']is True)if ok else not terminal['terminal_gate_passed']
old=load(D/'ROOT-negative-audit-v1.json')
summary=dict(schema='published-exact-evidence-summary-v1',status='QUALIFIED_FINITE_REPRESENTATION'if ok else audit['status'],
    representation_admitted=ok,original_complete_input_count=3,completed_independent_input_packets=len(rows),completed_diagnostics=len(fixtures),
    whole_original_input_bytes=sum(x['input']['bytes']for x in plan['inputs']),encoded_complete_table_bytes=packet.get('aggregate_encoded_table_bytes'),
    encoded_table_prefix_bytes=packet.get('aggregate_encoded_table_prefix_bytes'),
    worker_peak_bytes=runner['worker_wait4_usage']['ru_maxrss'],terminal_seconds=terminal['runner_clock_seconds'],
    resource_admitted=audit['resource_admitted'],earlier_attempt=dict(status=old['status'],representation_admitted=False,terminal_seconds=old['failure_terminal_seconds'],worker_peak_bytes=old['worker_peak_bytes'],reached_context=old['reached_context']),
    mathematical_proof_accepted=False,new_target_theorem=False,Model_permission=False,schema_inventory_admission=False,Native_calls=0,search_calls=0,RL_training=False,
    callback_scope='Dispatch counts, not weighted logical work; no causal timing profile or matched proof-search speed claim.',
    conformance='Representation-only engineering control. No point values, markings, candidate graph, generation, scheduler, rollback or proof rules changed.',goal_complete=False)
publish('exact-evidence-summary.json',summary)
publish('exact-evidence-admission.json',audit)
publish('exact-evidence-peer-review.json',peer)
publish('exact-evidence-result.json',packet)

entries=[dict(label='Current whole-run outcome',packet=summary)]
entries.extend(dict(label='Complete input: '+r['id'],packet=r)for r in rows)
entries.extend(dict(label='Diagnostic: '+f['name'],packet=f)for f in fixtures)
entries.extend([dict(label='Current complete result or failure',packet=packet),dict(label='Current resource receipt',packet=runner),dict(label='Earlier attempt: UNKNOWN, preserved',packet=load(D/'actual-v4/worker-failure.json')),dict(label='Root saved-data audit',packet=audit),dict(label='Independent saved-data audit',packet=peer)])
typed=next((f for f in fixtures if f['name']=='typed_values_order_unicode_and_repeated_ports'),None)
full={r['id']:r for r in rows}
retained={Path(r['path']).name:r for r in packet.get('published_table_prefix',[])}
table_rows=[]
for x in plan['inputs']:
    r=full.get(x['id']);d=r['encoded']if r else retained.get(x['id']+'-table.json')
    table_rows.append('<tr><td>'+esc(x['id'])+'</td><td>'+math(format(x['input']['bytes'],','))+'</td><td>'+(math(format(d['bytes'],','))if d else 'Not retained')+'</td><td>'+(math(format(r['immutable_node_count'],','))if r else 'Not qualified')+'</td><td>'+('Every byte agrees'if r else 'Not returned')+'</td></tr>')
chart=''
if ok:
    ordinary=summary['whole_original_input_bytes'];encoded=summary['encoded_complete_table_bytes']
    chart='<div class="chart" role="img" aria-label="Complete original and typed table byte counts"><h3>Full data, two storage representations</h3>'
    for label,size,cls in [('Ordinary JSON',ordinary,''),('Typed tables',encoded,' compact')]:
        chart+='<div class="chart-row"><span>'+label+'</span><div class="track'+cls+'"><i style="width:'+str(round(100*size/max(ordinary,encoded),3))+'%"></i></div><span>'+mib(size)+'</span></div>'
    chart+='<p class="small">Aggregate whole files, each including its external newline. Table sum excludes the separately charged summary result. These are storage measurements, not search speed or memory improvements.</p></div>'
resource='<div class="table-wrap"><table><thead><tr><th>Variant</th><th>Whole input packets</th><th>Diagnostics</th><th>Observed terminal</th><th>Worker peak</th><th>Outcome</th></tr></thead><tbody>'
resource+='<tr><td>Original checkpoint dispatch</td><td>'+math(0)+'</td><td>'+math(0)+'</td><td>'+math('180.067'+r'\,\mathrm{s}')+'</td><td>'+mib(old['worker_peak_bytes'])+'</td><td>UNKNOWN at work deadline</td></tr>'
resource+='<tr><td>Weighted checkpoint dispatch</td><td>'+math(len(rows))+'</td><td>'+math(len(fixtures))+'</td><td>'+math(f"{terminal['runner_clock_seconds']:.3f}"+r'\,\mathrm{s}')+'</td><td>'+mib(summary['worker_peak_bytes'])+'</td><td>'+('Finite representation qualified'if ok else esc(audit['status']))+'</td></tr></tbody></table></div>'
resource+='<p>The first attempt stopped during the saved-table encoder inverse of the first input, before the independent inverse or diagnostics. Its retained table is unqualified and was not reused. The second attempt started from the same three whole originals under a fresh one-use subject. Only the encoder’s callback cadence changed; every structural rule and private quota, the independent inverse, worker and launchers stayed the same.</p><p>The new encoder schedules callback checks in weighted charge batches. Bulk checks occur before the existing character window is processed. This is neither a hard elapsed-time interruption guarantee nor a bound on actual processing between callbacks. Source custody checks still depend on callback count. The first run is censored by the deadline, so the pair does not establish a causal speedup.</p>'
lead=('All three complete saved artifacts return byte for byte through the independently authored inverse, and all forty-eight diagnostics pass within the declared standalone limits.'if ok else 'The checkpoint variant reaches the independent inverse, then stops at its work quota. Both attempts remain UNKNOWN; neither qualifies the representation.')
outcome=('Finite representation qualified; proof search is unchanged.'if ok else 'Independent checking reaches its work limit.')
detail=('The new run qualifies this finite storage boundary: typed sharing preserves every ordinary-data occurrence on these inputs. It does not validate all future inputs or activate the component in proof search.'if ok else 'The new run stops at the independent inverse’s declared work quota on the first artifact. No complete input packet or diagnostic returns. The table is retained as unqualified evidence; no logical or representation authority follows.')
next_step=('Integrate the qualified boundary into one complete proof-search control, preserving the original inventory, Model and proof rules. Then rerun the explicit schema-admission comparison under the original limits, counting construction, checking and reconstruction. The earlier two failures stay on record.'if ok else 'Review a bounded canonical-fragment reuse strategy for the independently authored inverse. It must retain whole-table validation and reachability, every ordered occurrence, exact expanded-byte charging and the original numeric limits. Fragment reuse changes the actual operations charged by the private work counter, so it needs an explicitly versioned accounting profile and cannot be described as passing the old inverse’s work-unit profile. Any implementation needs fresh review and full qualification. This remains a source-only proposal; no third run is admitted here.')
template=(D/'exact-evidence-template.html').read_text()
repl=dict(LEAD=lead,OUTCOME_TITLE=outcome,INPUT_COUNT='3',COMPLETE_COUNT=str(len(rows)),FIXTURE_COUNT=str(len(fixtures)),OUTCOME_DETAIL=detail,ARTIFACT_ROWS=''.join(table_rows),BYTE_CHART=chart,GRAPH_FALLBACK='<p>The repeated-reference diagram is available only after its actual diagnostic returns.</p>',RESOURCE_DETAIL=resource,NEXT_STEP=next_step,PACKETS=json.dumps(dict(entries=entries,typed_fixture=typed),sort_keys=True,ensure_ascii=False,allow_nan=False).replace('<','\\u003c'))
for k,v in repl.items():template=template.replace('@@'+k+'@@',v)
assert '@@'not in template
if not ok:
    template=template.replace('A small materialization test also checks that repeated references become distinct mutable containers when a caller requests ordinary data.','The unexecuted diagnostic suite also includes fresh mutable materialization of repeated references. No materialization diagnostic returned in either actual.')
    template=template.replace('Duplicate keys, malformed references and cycles are rejected.','The reviewed validation rules require rejection of duplicate keys, malformed references and cycles; their authored diagnostics remain unexecuted in these two runs.')
    template=template.replace('<div id="graphPanel"><p>The repeated-reference diagram is available only after its actual diagnostic returns.</p></div>','<div id="graphPanel"><div class="tracks"><article><h3>First attempt</h3><p>Reported stop: saved-table encoder inverse.</p><p>Global work deadline. Independent inverse and diagnostics not reached.</p></article><article><h3>Checkpoint variant</h3><p>Reported stop: independent saved-table inverse.</p><p>Private inverse work quota. No complete input packet or diagnostic.</p></article><article><h3>Required finish</h3><p>All three whole input packets, all forty-eight diagnostics and all outer gates.</p><p>Neither attempt reaches this state.</p></article></div></div>')

clock_note='<p>The table measures terminal time from the runner’s timestamp immediately after importing <code>time</code>. Runner interpreter startup and the outer observer’s prelude precede that gated epoch. The separately recorded observer-main interval is '+math(f"{(terminal['terminal_ns']-terminal['started_ns'])/1e9:.9f}"+r'\,\mathrm{s}')+'; it also excludes the observer’s own interpreter/module startup. Work and terminal admission use the declared runner epoch.</p>'
template=template.replace('<section id="resources"><h2>Count construction, checking and reconstruction</h2>','<section id="resources"><h2>Count construction, checking and reconstruction</h2>'+clock_note)
(P/'exact-evidence.html').write_text(template)
reader=P/'reader.html';s=reader.read_text();s=re.sub(r'<section id="exact-evidence">[\s\S]*?</section>','',s,count=1)
section='<section id="exact-evidence"><p class="eyebrow">19 OCTOBER 2026 · STANDALONE STORAGE CONTROL</p><h2>'+outcome+'</h2><p>'+lead+' The original timeout remains visible; this adds no theorem, RL training or search-speed claim. <a href="exact-evidence.html?v=20261019-ee1#outcome"><b>Read the qualification and costs</b></a> · <a href="exact-evidence.html?v=20261019-ee1#reader">Inspect complete saved packets</a>.</p></section>'
assert '<section id="schema-admission-pilot">'in s
reader.write_text(s.replace('<section id="schema-admission-pilot">',section+'<section id="schema-admission-pilot">',1))

files={}
for folder,label in [(D,'Root'),(S,'Root-Source'),(L,'Library-Source'),(C,'Control')]:
    for p in folder.rglob('*'):
        if p.is_file()and p.suffix in ('.json','.py','.html','.bin','.txt','.diff')and '__pycache__'not in p.parts:
            files[label+'/'+str(p.relative_to(folder))]=p
for item in plan['inputs']:files['whole-original-inputs/'+item['id']+'.json']=Path(item['input']['path'])
archive=P/'exact-evidence-archive.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6)as z:
    for name,p in sorted(files.items()):z.write(p,name)
    z.writestr('README.txt','Saved ordinary-data qualification evidence. No codec/inverse is evaluated by this archive. Absolute custody paths are historical. Reproduction requires a fresh reviewed bounded subject; consumed invocations cannot be retried. Original UNKNOWN and negative Source reviews are preserved. No new proof or schema permission is implied.\n')
manifest=dict(schema='published-exact-evidence-byte-manifest-v1',files=[dict(archive_name=n,**pin(p))for n,p in sorted(files.items())],archive=pin(archive),published=[pin(P/n)for n in ['exact-evidence.html','exact-evidence-summary.json','exact-evidence-admission.json','exact-evidence-peer-review.json','exact-evidence-result.json','reader.html']],saved_data_only=True,codec_or_inverse_calls=0,goal_complete=False)
publish('exact-evidence-manifest.json',manifest)
print(json.dumps(dict(status=summary['status'],archive=pin(archive),files=len(files),entries=len(entries),publication_files=7)))
