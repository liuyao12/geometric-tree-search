"""Saved raw metadata audit only; never import/evaluate encoder or inverse."""
from pathlib import Path
import hashlib,json,os,subprocess
D=Path(__file__).parent
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def load(p):return json.loads(Path(p).read_bytes())
def check(d):assert pin(d['path'])==d;return load(d['path'])
def save(p,v):assert not p.exists();p.write_text(json.dumps(v,sort_keys=True,indent=2,allow_nan=False)+'\n');return pin(p)
def sha(v):return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()
plan=load(D/'plan-authorized-v5.json');actual=Path(plan['actual_directory']);runner=load(actual/'runner-receipt.json');terminal=load(D/'plan-authorized-v5-terminal-observation/terminal.json')
for k in ['python','encoder','inverse','worker','runner','observer','declaration']:assert pin(plan[k]['path'])==plan[k]
for item in plan['inputs']:assert pin(item['input']['path'])==item['input']
auth=check(plan['authorization']);subject={k:v for k,v in plan.items()if k!='authorization'}
assert len(subject)==12 and sha(subject)==auth['subject_sha256']==runner['subject_sha256'];assert auth['actual_execution_authorized']is True and auth['maximum_actual_invocations']==1
for d in auth['review_roles'].values():check(d)
consumed=check(runner['consumed_marker']);assert consumed['consumed_before_Popen']is True and consumed['maximum_worker_launches']==runner['worker_launch_attempts']==1
assert runner['plan']==pin(D/'plan-authorized-v5.json')and terminal['runner_receipt']==pin(actual/'runner-receipt.json')
assert runner['worker_reaped']and runner['owned_group_absent']and runner['regular_logs_closed']
assert runner['worker_pid']==runner['owned_pgid'];pgid=runner['owned_pgid']
try:os.killpg(pgid,0)
except ProcessLookupError:absent=True
else:absent=False
assert absent
proc=subprocess.run(['/bin/ps','-axo','pid=,ppid=,pgid=,stat=,command='],capture_output=True,text=True,check=True)
hits=[x for x in proc.stdout.splitlines()if len(x.split(None,4))>=4 and(int(x.split(None,4)[0])in[runner['worker_pid'],terminal['runner_pid']]or int(x.split(None,4)[2])==pgid)]
assert not hits
closure=save(D/'ROOT-cohort-closure-v5.json',dict(schema='ROOT-exact-evidence-cohort-closure-v1',runner_pid=terminal['runner_pid'],worker_pid=runner['worker_pid'],owned_pgid=pgid,killpg_zero_absent=absent,ps_matching_rows=hits,regular_logs_closed=True,worker_reaped=True))
for name in ['stdout','stderr']:assert pin(actual/(name+'.bin'))==runner[name]and runner[name]['bytes']<=plan['limits'][name+'_bytes']
assert runner['limits']==plan['limits']
assert not list(actual.glob('*.partial'))
for name in ['POST_RECEIPT_DEADLINE_FAILURE.json','POST_RECEIPT_WORK_FAILURE.json']:assert not(actual/name).exists()
ok=terminal['terminal_gate_passed']is True
result_path=actual/('result.json'if ok else 'worker-failure.json'if(actual/'worker-failure.json').exists()else 'result.json'if(actual/'result.json').exists()else 'runner-receipt.json');result=load(result_path)
rows=result.get('complete_inputs',result.get('completed_input_packets',[]));fixtures=result.get('fixtures',result.get('completed_fixture_prefix',[]))
for r,item in zip(rows,plan['inputs']):
 assert r['id']==item['id']and r['input']==item['input']
 assert pin(r['encoded']['path'])==r['encoded']
 for key in ['input_baseline','encoder_inverse','saved_wire_encoder_inverse','independent_saved_wire_inverse']:
  assert r[key]==dict(bytes=item['input']['bytes'],sha256=item['input']['sha256'],whole_literal_equal=True)
 assert r['no_scientific_semantic_admission']is True and r['immutable_node_count']==sum(r['node_tag_counts'].values())and r['root_id']==r['immutable_node_count']-1
for f in fixtures:assert f['passed']is True
peak=runner['worker_wait4_usage']['ru_maxrss'];elapsed=terminal['runner_clock_seconds']
assert abs(elapsed-(terminal['terminal_ns']-runner['began_ns'])/1e9)<1e-9
if ok:
 assert terminal['runner_exit_code']==runner['worker_exit_code']==0 and runner['resource_candidate_accepted']and runner['representation_candidate']and not runner['errors']
 assert runner['worker_terminal_observed_ns']<runner['work_deadline_ns']and runner['closed_ns']<runner['work_deadline_ns']and terminal['terminal_ns']<runner['overall_deadline_ns']
 assert peak<=plan['limits']['memory_bytes']and len(rows)==3 and len(fixtures)==48
 assert [r['id']for r in rows]==[x['id']for x in plan['inputs']]
 header=check(runner['worker_receipt']);assert header['result']==pin(result_path)==runner['result']and header['work_completed_ns']<runner['work_deadline_ns']
 assert runner['aggregate_encoded_result_bytes']==sum(r['encoded']['bytes']for r in rows)+pin(result_path)['bytes']<=plan['limits']['result_bytes']
 assert result['aggregate_input_expanded_bytes']==sum(x['input']['bytes']for x in plan['inputs'])<=plan['limits']['expanded_bytes']
 assert result['aggregate_encoded_table_bytes']==sum(r['encoded']['bytes']for r in rows)
 for k in ['scientific_proof_replays','Native_calls','search_calls','Model_calls','opaque_Native_decodes']:assert result[k]==0
 for k in ['new_target_proof','Model_permission','schema_inventory_admission','goal_complete']:assert result[k]is False
else:
 assert not runner['resource_candidate_accepted']and not runner['representation_candidate']
 for r in result.get('published_table_prefix',[]):assert pin(r['path'])==r
 if result.get('schema')=='exact-evidence-worker-failure-v1':assert result['scientific_acceptance']is False and result['representation_accepted']is False
out=dict(schema='ROOT-exact-evidence-final-audit-v5',saved_data_only=True,raw_pin_and_saved_packet_audit_passed=True,representation_admitted=ok,resource_admitted=ok,
 status='QUALIFIED_FINITE_REPRESENTATION'if ok else result.get('status','FAILED_OUTER_RESOURCE_OR_TERMINAL'),whole_original_inputs_selected=3,completed_full_input_packets=len(rows),completed_diagnostics=len(fixtures),
 worker_peak_bytes=peak,terminal_seconds=elapsed,subject_sha256=sha(subject),plan=pin(D/'plan-authorized-v5.json'),result_or_failure=pin(result_path),runner=pin(actual/'runner-receipt.json'),terminal=pin(D/'plan-authorized-v5-terminal-observation/terminal.json'),cohort_closure=closure,
 prior_negative=pin(D/'ROOT-negative-audit-v1.json'),codec_or_inverse_calls=0,scientific_replays=0,Native_calls=0,Model_permission=False,proof_accepted=False,schema_inventory_admission=False,goal_complete=False,
 scope='Only finite ordinary-data representation is admitted if all saved tests and original standalone resource gates pass. No fresh inverses/decoding/proof replay in this audit. No integration, Model, pruning, theorem, RL or causal speed advantage follows. Original V1 UNKNOWN and prior matched pilot failures retained.')
print(json.dumps(save(D/'ROOT-final-audit-v5.json',out)))
