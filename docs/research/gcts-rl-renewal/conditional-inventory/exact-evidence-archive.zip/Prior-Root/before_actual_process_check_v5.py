from pathlib import Path
import json,os,subprocess
D=Path(__file__).parent
scan=subprocess.run(['/bin/ps','-axo','pid=,ppid=,pgid=,stat=,command='],capture_output=True,text=True,check=True)
terms=['qualify_exact_evidence_worker','run_exact_evidence_once','observe_exact_evidence_once']
hits=[x for x in scan.stdout.splitlines()if any(t in x for t in terms)and int(x.split(None,4)[0])!=os.getpid()]
assert not hits,hits
p=D/'ROOT-before-actual-process-check-v5.json';assert not p.exists();p.write_text(json.dumps(dict(schema='ROOT-exact-evidence-before-actual-process-check-v1',matching_owned_worker_runner_observer_rows=hits,all_agents_required_idle=True,actuals_started=0),sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(owned_processes_absent=True,actuals_started=0)))
