"""One raw metadata preflight only, no scientific module evaluation."""
from pathlib import Path
import hashlib,json,os,subprocess
D=Path(__file__).parent
idx=json.loads((D/'authorized-index-v3.json').read_bytes());found={}
def visit(x):
 if type(x)is dict:
  if set(x)=={'path','bytes','sha256'}:
   p=Path(x['path']);b=p.read_bytes();assert dict(path=str(p.resolve()),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())==x;found[x['path']]=x
  for v in x.values():visit(v)
 elif type(x)is list:
  for v in x:visit(v)
visit(idx)
plan=json.loads(Path(idx['plan']['path']).read_bytes());visit(plan)
auth=json.loads(Path(plan['authorization']['path']).read_bytes());visit(auth)
for d in auth['review_roles'].values():visit(json.loads(Path(d['path']).read_bytes()))
sub={k:v for k,v in plan.items()if k!='authorization'}
assert len(sub)==12 and sub==idx['subject']and hashlib.sha256(json.dumps(sub,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()==auth['subject_sha256']
assert auth['actual_execution_authorized']is True and auth['maximum_actual_invocations']==1
assert not Path(plan['actual_directory']).exists()and not(D/'plan-authorized-v3-terminal-observation').exists()
p=D/'ROOT-true-raw-preflight-v3.json';assert not p.exists();p.write_text(json.dumps(dict(schema='ROOT-exact-evidence-true-raw-preflight-v1',saved_data_only=True,codec_or_inverse_calls=0,actuals_started=0,pins=list(found.values()),subject_sha256=auth['subject_sha256']),sort_keys=True,indent=2)+'\n')
scan=subprocess.run(['/bin/ps','-axo','pid=,ppid=,pgid=,stat=,command='],capture_output=True,text=True,check=True)
terms=['qualify_exact_evidence_worker','run_exact_evidence_once','observe_exact_evidence_once','qualify_arena_worker','run_arena_once']
hits=[x for x in scan.stdout.splitlines()if any(t in x for t in terms)and int(x.split(None,4)[0])!=os.getpid()]
assert not hits,hits
p=D/'ROOT-before-actual-process-check-v3.json';assert not p.exists();p.write_text(json.dumps(dict(schema='ROOT-exact-evidence-before-actual-process-check-v1',matching_owned_worker_runner_observer_rows=hits,all_agents_required_idle=True,actuals_started=0),sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(raw_pin_count=len(found),subject_sha256=auth['subject_sha256'],fresh_subject=True,owned_processes_absent=True,actuals_started=0)))
