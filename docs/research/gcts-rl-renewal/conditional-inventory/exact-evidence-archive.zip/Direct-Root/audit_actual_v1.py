"""Saved ordinary metadata only; no scientific imports, inverses or replay."""
from pathlib import Path
import hashlib,json,os,subprocess
D=Path(__file__).parent
def load(p):return json.loads(Path(p).read_bytes())
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def check(d):assert pin(d['path'])==d;return load(d['path'])
def sha(v):return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()
def save(n,v):
 p=D/n;assert not p.exists();p.write_text(json.dumps(v,sort_keys=True,indent=2,allow_nan=False)+'\n');return pin(p)
plan=load(D/'plan-authorized-v1.json');actual=Path(plan['actual_directory'])
runner=load(actual/'runner-receipt.json');terminal=load(D/'plan-authorized-v1-terminal-observation/terminal.json')
declaration=check(plan['declaration'])
for k in ['python','encoder','inverse','worker','runner','observer']:assert pin(plan[k]['path'])==plan[k]
for d in declaration['auxiliary_sources'].values():assert pin(d['path'])==d
for r in plan['inputs']:assert pin(r['input']['path'])==r['input']
auth=check(plan['authorization']);subject={k:v for k,v in plan.items()if k!='authorization'}
assert len(subject)==12 and sha(subject)==auth['subject_sha256']==runner['subject_sha256']
assert auth['actual_execution_authorized']is True and auth['maximum_actual_invocations']==1
for d in auth['review_roles'].values():check(d)
consumed=check(runner['consumed_marker'])
assert consumed['consumed_before_Popen']is True and consumed['maximum_worker_launches']==runner['worker_launch_attempts']==1
assert runner['plan']==pin(D/'plan-authorized-v1.json')and terminal['runner_receipt']==pin(actual/'runner-receipt.json')
assert runner['worker_reaped']and runner['owned_group_absent']and runner['regular_logs_closed']
assert runner['worker_pid']==runner['owned_pgid'];pgid=runner['owned_pgid']
try:os.killpg(pgid,0)
except ProcessLookupError:absent=True
else:absent=False
assert absent
proc=subprocess.run(['/bin/ps','-axo','pid=,ppid=,pgid=,stat=,command='],capture_output=True,text=True,check=True)
hits=[x for x in proc.stdout.splitlines()if len(x.split(None,4))>=4 and(int(x.split(None,4)[0])in[runner['worker_pid'],terminal['runner_pid']]or int(x.split(None,4)[2])==pgid)]
assert not hits
closure=save('ROOT-cohort-closure-v1.json',dict(schema='ROOT-exact-evidence-cohort-closure-v1',runner_pid=terminal['runner_pid'],worker_pid=runner['worker_pid'],owned_pgid=pgid,killpg_zero_absent=absent,ps_matching_rows=hits,regular_logs_closed=True,worker_reaped=True))
for name in ['stdout','stderr']:assert pin(actual/(name+'.bin'))==runner[name]and runner[name]['bytes']<=plan['limits'][name+'_bytes']
assert runner['limits']==plan['limits']
partial_descriptors=[pin(p)for p in actual.glob('*.partial')]
post_receipt_markers=[pin(actual/n)for n in ['POST_RECEIPT_DEADLINE_FAILURE.json','POST_RECEIPT_WORK_FAILURE.json']if(actual/n).exists()]
ok=terminal['terminal_gate_passed']is True
result_path=actual/('result.json'if ok else 'worker-failure.json'if(actual/'worker-failure.json').exists()else 'result.json'if(actual/'result.json').exists()else 'runner-receipt.json')
result=load(result_path);rows=result.get('complete_inputs',result.get('completed_input_packets',[]));fixtures=result.get('fixtures',result.get('completed_fixture_prefix',[]))
expected=declaration['expected_fixture_names'];assert len(expected)==135 and len(set(expected))==127
assert [f['name']for f in fixtures]==expected[:len(fixtures)]
for i,f in enumerate(fixtures):
 if 71<=i<104:assert set(f)=={'schema','name','status','scope','observed','authority'}and f['schema']=='arena-finite-diagnostic-v1'and f['status']=='passed'and f['authority']is False
 else:assert f['passed']is True
for r,item in zip(rows,plan['inputs']):
 assert r['id']==item['id']and r['input']==item['input']and r['document_label']==item['id']
 assert pin(r['encoded']['path'])==r['encoded']
 for key in ['input_baseline','arena_canonical','independent_saved_wire_inverse']:assert r[key]==dict(bytes=item['input']['bytes'],sha256=item['input']['sha256'],whole_literal_equal=True)
 assert r['independent_saved_wire_inverse_complete']is True and r['no_scientific_semantic_admission']is True
 st=r['independent_document_statistics'];assert st['completed']and st['attempts']==1 and not st['closed_incomplete']
 assert st['body_bytes']==st['copied_body_bytes']==st['emitted_body_bytes']==item['input']['bytes']-1
 assert st['logical_file_bytes']==item['input']['bytes']and st['stream_value_occurrences']==st['logical_value_occurrences']
 assert st['chunks']==(st['body_bytes']+65535)//65536
peak=runner['worker_wait4_usage']['ru_maxrss'];elapsed=terminal['runner_clock_seconds']
assert abs(elapsed-(terminal['terminal_ns']-runner['began_ns'])/1e9)<1e-9
if ok:
 assert not partial_descriptors and not post_receipt_markers
 assert terminal['runner_exit_code']==runner['worker_exit_code']==0 and runner['resource_candidate_accepted']and runner['representation_candidate']and not runner['errors']
 assert runner['worker_terminal_observed_ns']<runner['work_deadline_ns']and runner['closed_ns']<runner['work_deadline_ns']and terminal['terminal_ns']<runner['overall_deadline_ns']
 assert peak<=plan['limits']['memory_bytes']and len(rows)==3 and len(fixtures)==135
 assert [r['id']for r in rows]==[r['id']for r in plan['inputs']]
 header=check(runner['worker_receipt']);assert header['result']==pin(result_path)==runner['result']and header['work_completed_ns']<runner['work_deadline_ns']
 assert len(result['encoded_forests'])==1 and result['encoded_forests']==header['tables']==runner['tables']
 forest=result['encoded_forests'][0];assert pin(forest['path'])==forest and all(r['encoded']==forest for r in rows)
 assert runner['aggregate_encoded_result_bytes']==forest['bytes']+pin(result_path)['bytes']<=plan['limits']['result_bytes']
 assert result['aggregate_input_expanded_bytes']==sum(r['input']['bytes']for r in plan['inputs'])<=plan['limits']['expanded_bytes']
 assert result['aggregate_encoded_table_bytes']==result['aggregate_encoded_forest_bytes']==forest['bytes']
 assert result['arena_limits']==declaration['arena_limits']and result['forest_inverse_limits']==declaration['forest_inverse_limits']
 assert result['expected_fixture_names']==expected and result['diagnostic_group_counts']==dict(retained=71,arena=33,forest=23,reconciliation=8)
 a=result['arena_statistics'];s=result['independent_inverse_statistics']
 assert a['lifecycle']=='SEALED'and a['roots']==3 and a['logical_document_bytes']==s['aggregate_document_bytes']==result['aggregate_input_expanded_bytes']
 assert a['physical_wire_bytes']==s['wire_canonical_bytes']==forest['bytes']and a['nodes']==s['validated_nodes']and a['edges']==s['validated_edges']
 assert s['prepared']and s['logical_documents']==s['catalogue_roots']==3
 assert s['attempted_operations']==sum(s['operations_by_kind'].values())<=result['forest_inverse_limits']['work']
 assert a['counters']['work']<=result['arena_limits']['work']
 assert s['cache_payload_bytes']<=result['forest_inverse_limits']['cache_bytes']and s['cache_entries']<=result['forest_inverse_limits']['cache_entries']
 assert s['aggregate_document_value_occurrences']==sum(r['independent_document_statistics']['logical_value_occurrences']for r in rows)
 assert result['current_Source']==dict({k:plan[k]for k in ['worker','encoder','inverse','runner','observer']},**declaration['auxiliary_sources'])
 for k in ['scientific_proof_replays','Native_calls','search_calls','Model_calls','opaque_Native_decodes']:assert result[k]==0
 for k in ['new_target_proof','Model_permission','schema_inventory_admission','goal_complete']:assert result[k]is False
else:
 # Outer terminal failure rejects even a retained inner candidate.
 for d in result.get('published_forests',[]):assert pin(d['path'])==d
 if result.get('schema')=='incremental-arena-worker-failure-v1':assert result['scientific_acceptance']is False and result['representation_accepted']is False
out=dict(schema='ROOT-direct-reconciliation-saved-audit-v1',saved_data_only=True,raw_pin_and_saved_packet_audit_passed=True,representation_admitted=ok,resource_admitted=ok,
 status='QUALIFIED_FINITE_DIRECT_RECONCILIATION'if ok else result.get('status','FAILED_OUTER_RESOURCE_OR_TERMINAL')if result.get('schema')=='incremental-arena-worker-failure-v1'else 'FAILED_OUTER_RESOURCE_OR_TERMINAL',whole_original_inputs_selected=3,completed_full_input_packets=len(rows),completed_diagnostics=len(fixtures),
 worker_peak_bytes=peak,terminal_seconds=elapsed,subject_sha256=sha(subject),plan=pin(D/'plan-authorized-v1.json'),result_or_failure=pin(result_path),runner=pin(actual/'runner-receipt.json'),terminal=pin(D/'plan-authorized-v1-terminal-observation/terminal.json'),cohort_closure=closure,
 prior_milestone=pin('/private/tmp/gcts-incremental-arena-ROOT-20261019/ROOT-final-milestone-v1.json'),partial_descriptors=partial_descriptors,post_receipt_markers=post_receipt_markers,retained_inner_candidate_flags=dict(resource=runner['resource_candidate_accepted'],representation=runner['representation_candidate']),codec_or_inverse_calls=0,scientific_replays=0,Native_calls=0,Model_permission=False,proof_accepted=False,schema_inventory_admission=False,goal_complete=False,
 scope='Finite ordinary-data arena/forest prerequisite only. Saved bytes/counters/receipts; no codec/inverse replay. Changed profile is not previous default20m/virtual-work qualification. No integrated memory benefit, search performance, theorem, GCTS/RL advantage or rescue of the unchanged old expanded-output failure follows.')
print(json.dumps(save('ROOT-final-audit-v1.json',out)))
