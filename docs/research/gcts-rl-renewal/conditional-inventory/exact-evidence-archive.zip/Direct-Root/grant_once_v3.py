"""Saved metadata-only adoption of one unchanged independently reviewed subject."""
from pathlib import Path
import hashlib,json
D=Path(__file__).parent;PEER=Path('/private/tmp/gcts-direct-reconcile-peer-20261019')
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def checked(d):
 assert pin(d['path'])==d
 return json.loads(Path(d['path']).read_bytes())
def save(p,v):
 assert not p.exists();p.write_text(json.dumps(v,sort_keys=True,indent=2,allow_nan=False)+'\n');return pin(p)
def sha(v):return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()
def contains(v,w):
 if v==w:return True
 if type(v)is dict:return any(contains(x,w)for x in v.values())
 if type(v)is list:return any(contains(x,w)for x in v)
 return False
idx=json.loads((D/'prospective-index-v3.json').read_bytes());plan=checked(idx['plan_draft']);old=checked(idx['authorization_draft']);subject={k:v for k,v in plan.items()if k!='authorization'}
assert len(subject)==12 and subject==idx['subject']and sha(subject)==idx['subject_sha256']==old['subject_sha256']
assert old['actual_execution_authorized']is False and old['maximum_actual_invocations']==0 and old['review_roles']=={}
roles=dict(Source=pin(PEER/'typed-components-Source-review-v3.json'),plans=pin(PEER/'typed-prospective-plan-review-v3.json'))
for role,d in roles.items():
 r=checked(d);assert r['reviewer_identity']=='/root/conventional_control_review'and r['source_only']is True and r['scientific_calls']==0 and r['scientific_acceptance']is False and r['actual_execution_authorized']is False
 if role=='Source':
  assert r['schema']=='exact-evidence-components-Source-review-v1'and r['source_review_passed']is True and r['author_identities']==['/root','/root/conventional_library']
  for k in ['encoder','inverse','worker','runner','observer']:assert contains(r,plan[k])
  for d in checked(plan['declaration'])['auxiliary_sources'].values():assert contains(r,d)
 else:
  assert r['schema']=='exact-evidence-prospective-plan-review-v1'and r['prospective_review_passed']is True and r['subject']==subject and r['subject_sha256']==sha(subject)and contains(r,plan['declaration'])
assert not Path(plan['actual_directory']).exists()and not(D/'plan-authorized-v3-terminal-observation').exists()
auth=dict(old,actual_execution_authorized=True,maximum_actual_invocations=1,review_roles=roles,scope='One unchanged reviewed12-field subject only. Representation-only one shared forest of complete three prior artifacts after all135 diagnostics; no solver/Native/Model/search calls. No consumed retry. Direct reconciliation parent-guardsv3 supplied-arena work400m covers main and inherited Library33/Root8 default arenas; tighter diagnostic/legacy limits and independent forest actual30m remain unchanged. Old200m, prior default20m and oldvirtualV3 are not passed. Global gates unchanged. Two roles share one reviewer identity; no additional reviewer implied.')
ap=save(D/'authorization-v3.json',auth);plan['authorization']=ap;assert {k:v for k,v in plan.items()if k!='authorization'}==subject
pp=save(D/'plan-authorized-v3.json',plan)
ip=save(D/'authorized-index-v3.json',dict(idx,actual_execution_authorized=True,maximum_actual_invocations=1,authorization=ap,plan=pp,review_roles=roles,actuals_started=0))
adopt=save(D/'ROOT-final-grant-adoption-v3.json',dict(schema='ROOT-exact-evidence-final-grant-adoption-v1',source_only=True,scientific_calls=0,actuals_started=0,subject_sha256=sha(subject),unchanged_subject=True,authorized_index=ip,old_false_index=pin(D/'prospective-index-v3.json'),review_roles=roles,goal_complete=False))
print(json.dumps(dict(plan=pp,index=ip,adoption=adopt,actuals_started=0,scientific_calls=0)))
