"""Eight prospective direct-second-read diagnostics; SOURCE ONLY until granted.

Only public arena APIs and passive counters are used. Caller-input mutation
probes deliberately inject faults beyond ordinary exclusive ownership; selected
refusals are not a universal temporal/concurrency guarantee. No proof authority.
"""
import json

VERSION='direct-reconciliation-qualification-fixtures-v1'
EXPECTED_RECONCILIATION_FIXTURES=(
 'reconciliation_full_typed_occurrences_no_reinterning',
 'reconciliation_between_reads_scalar_mutation_matrix',
 'reconciliation_between_reads_container_key_order_matrix',
 'reconciliation_between_reads_cycle_and_strict_type_matrix',
 'reconciliation_foreign_during_read_exception_identity_matrix',
 'reconciliation_foreign_completed_read_guard_identity_matrix',
 'reconciliation_second_read_callback_reentrancy',
 'reconciliation_second_read_owned_work_boundary',
)

class FixtureFailure(ValueError):pass
class FixtureMarker(Exception):pass
class ListSubclass(list):pass
class IntSubclass(int):pass

def _need(ok,message):
    if not ok:raise FixtureFailure(message)
def _body(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode('utf8')

def run_reconciliation_fixtures(am,limits,tick,guard,rows,context):
    """All work, probes and separately finite diagnostic arenas remain charged."""
    _need(type(limits)is dict and type(rows)is list and type(context)is dict,'owned finite fixture carriers')
    _need(callable(tick)and callable(guard),'external clock/Source callbacks')
    _need(am.VERSION=='exact-evidence-arena-v1'and am.IMPLEMENTATION_VERSION=='exact-evidence-arena-v2-direct-reconciliation','exact public ABI and Source successor')
    external_fault=[None];done=[]
    def external(callback):
        try:callback()
        except BaseException as error:
            if external_fault[0]is None:external_fault[0]=error
            raise
    def clean():
        if external_fault[0]is not None:raise external_fault[0]
    def checkpoint():external(tick);external(guard);clean()
    def new(control=None,changes=None):
        cap=dict(limits)
        if changes:
            for k,v in changes.items():
                _need(k in cap and type(v)is int and 0<v<=cap[k],'diagnostic caps only tighten')
                cap[k]=v
        holder={}
        def dispatch(which):
            external(tick if which=='check'else guard)
            if control is not None and control.get('armed')and 'arena'in holder:control['act'](holder['arena'],which)
        a=am.Arena(source_epoch='direct-e',semantic_epoch='direct-s',check=lambda:dispatch('check'),source_guard=lambda:dispatch('guard'),limits=cap)
        holder['arena']=a;return a
    def counters(a):return a.statistics()['counters']
    def ledger(a):
        s=a.statistics();return {k:s[k]for k in ('lifecycle','nodes','edges','roots','cache_entries','cache_bytes','documents','logical_document_bytes','physical_wire_bytes')}
    def delta(a,base,k):return counters(a).get(k,0)-base.get(k,0)
    def during(a,base):return delta(a,base,'reconciliation_begins')==1 and delta(a,base,'reconciliation_complete_reads')==0 and delta(a,base,'reconciliation_frames')>0
    def caught(action):
        try:action()
        except BaseException as error:clean();return error
        clean();raise FixtureFailure('expected refusal did not occur')
    def unchanged(a,before,work):
        _need(ledger(a)==before,'failed second read published committed capacity')
        _need(counters(a)['work']>work,'attempted work disappeared on rollback')
    def drain(stream):
        parts=[]
        while True:
            external(tick)
            try:b=next(stream)
            except StopIteration:
                clean();_need(stream.completed is True,'stream exhaustion without explicit completion');break
            _need(type(b)is bytes and 0<len(b)<=limits['chunk_bytes'],'bounded canonical bytes')
            parts.append(b)
        return b''.join(parts)
    def exact(a,h,v):
        stream=a.iter_canonical(h)
        try:b=drain(stream)
        finally:stream.close()
        _need(b==_body(v),'full literal fixture body mismatch');return len(b)
    def payload(tail):return {'buffer':[0]*2048,'last':tail}
    def seeded(control):
        a=new(control);h=a.capture({'stable':[1,'kept']},label='seed');return a,h
    def run(name,action,scope):
        context.update(stage='DIRECT_RECONCILIATION_FIXTURES',fixture=name)
        checkpoint();observation=action();checkpoint()
        rows.append(dict(schema='direct-reconciliation-finite-diagnostic-v1',name=name,passed=True,observed=observation,scope=scope,authority=False));done.append(name)

    def success():
        control={'armed':False};a=new(control);base=counters(a);snapshots={}
        def observe(a,which):
            c=counters(a)
            if which=='guard'and delta(a,base,'reconciliation_begins')==1 and delta(a,base,'reconciliation_complete_reads')==0 and 'begin'not in snapshots:snapshots['begin']=c
            if which=='guard'and delta(a,base,'reconciliation_complete_reads')==1 and 'complete'not in snapshots:snapshots['complete']=c
        control.update(armed=True,act=observe)
        value={'z':[None,False,True,0,1,-1,0.0,-0.0,1.5,'é\n\\"',{'k':[2,2]}],'a':[{'p':[1,False]},{'p':[1,False]}]}
        h=a.capture(value,label='success');control['armed']=False
        _need(set(snapshots)=={'begin','complete'},'both direct-read Source-guard boundaries observed')
        for k in ('intern_lookups','full_node_comparisons','summary_nodes','summary_edges','fragment_builds','fragment_built_bytes'):
            _need(snapshots['begin'].get(k,0)==snapshots['complete'].get(k,0),'second read rebuilt/interned nodes or cache')
        # Independent ordinary-value count; repeated containers count per use.
        stack=[value];occurrences=0
        while stack:
            external(tick);v=stack.pop();occurrences+=1
            if type(v)is list:stack.extend(v)
            elif type(v)is dict:stack.extend(v.values())
        _need(delta(a,base,'reconciliation_complete_reads')==1 and delta(a,base,'reconciliation_begins')==1,'exact one full second read')
        _need(delta(a,base,'reconciliation_edges')==occurrences-1,'every ordered/repeated child edge reconciled')
        body_bytes=exact(a,h,value);materialized=a.materialize(h)
        _need(_body(materialized)==_body(value),'fresh materialization lost typed/canonical value')
        _need(materialized['a'][0]is not materialized['a'][1],'repeated containers materialized with aliases')
        return dict(body_bytes=body_bytes,value_occurrences=occurrences,every_ordered_edge_checked=True,first_builder_counters=snapshots['begin'],completed_read_counters=snapshots['complete'],no_second_interning_or_cache_build=True)
    run(EXPECTED_RECONCILIATION_FIXTURES[0],success,'Finite whole typed/value/key/repeated-port reconciliation, owned counters and fresh materialization. No time or general correctness theorem.')

    def mutate_case(label,tail,mutation):
        control={'armed':False};a,h=seeded(control);value=payload(tail);base=counters(a);before=ledger(a);work=base['work'];fired=[False]
        def inject(a,which):
            if which=='guard'and delta(a,base,'reconciliation_begins')==1 and delta(a,base,'reconciliation_complete_reads')==0:
                control['armed']=False;fired[0]=True;mutation(value)
        control.update(armed=True,act=inject)
        try:error=caught(lambda:a.capture(value,label='changed'))
        finally:control['armed']=False
        _need(fired[0]and type(error)is am.ArenaDataError,'selected between-read change was not refused as exact data error')
        unchanged(a,before,work);_need(delta(a,base,'reconciliation_complete_reads')==0,'mismatched read incorrectly completed')
        exact(a,h,{'stable':[1,'kept']})
        return dict(case=label,changed_at_begin_guard=True,exact_data_refusal=True,committed_ledger_unchanged=True,attempted_counters=counters(a))
    def scalar_matrix():
        cases=[('null_to_false',None,False),('false_to_integer',False,0),('integer_to_true',1,True),('integer_to_float',0,0.0),('negative_to_positive_float_zero',-0.0,0.0),('different_integer',37,38),('different_unicode','é\n','e\n'),('lone_surrogate_replacement','alpha','\ud800')]
        return [mutate_case(name,old,lambda v,new=new:v.__setitem__('last',new))for name,old,new in cases]
    run(EXPECTED_RECONCILIATION_FIXTURES[1],scalar_matrix,'Adversarial caller-input changes at the begin guard after first capture and before any second-read frame; outside normal exclusive-owner mutation rules, no temporal seal claim.')

    def container_matrix():
        def key_swap(v):v['last']['c']=v['last'].pop('a')
        def key_type(v):v['last'][False]=v['last'].pop('a')
        cases=[('array_order',[1,2,1],lambda v:v['last'].reverse()),
            ('array_repeated_position',[1,1,2],lambda v:v['last'].__setitem__(0,2)),
            ('array_length',[0],lambda v:v['last'].append(1)),
            ('same_cardinality_different_key',{'a':0,'b':1},key_swap),
            ('nonstring_key',{'a':0},key_type),
            ('dictionary_length',{'a':0},lambda v:v['last'].__setitem__('b',1)),
            ('dictionary_value',{'a':0},lambda v:v['last'].__setitem__('a',1))]
        return [mutate_case(*case)for case in cases]
    run(EXPECTED_RECONCILIATION_FIXTURES[2],container_matrix,'Selected complete key-set/cardinality and ordered/repeated-array faults between reads; no mutation of owned arena backing.')

    def cycle_types():
        cases=[('list_cycle',[[]],lambda v:v['last'].__setitem__(0,v['last'])),
            ('object_cycle',{'a':{}},lambda v:v['last'].__setitem__('a',v['last'])),
            ('tuple_replaces_list',[0],lambda v:v.__setitem__('last',(0,))),
            ('list_subclass_replaces_builtin',[0],lambda v:v.__setitem__('last',ListSubclass([0]))),
            ('integer_subclass_replaces_builtin',1,lambda v:v.__setitem__('last',IntSubclass(1)))]
        return [mutate_case(*case)for case in cases]
    run(EXPECTED_RECONCILIATION_FIXTURES[3],cycle_types,'Selected cyclic-shaped and non-builtin replacement faults, not hostile reflection or concurrent mutation coverage.')

    def markers():return [FixtureMarker('custom'),RuntimeError('runtime'),ValueError('value'),StopIteration('stop'),GeneratorExit('generator'),SystemExit('system'),am.ArenaLimit('foreign')]
    def exception_matrix(completed):
        out=[]
        for marker in markers():
            checkpoint();control={'armed':False};a,h=seeded(control);base=counters(a);before=ledger(a);work=base['work'];fired=[False]
            def inject(a,which):
                match=(which=='guard'and delta(a,base,'reconciliation_complete_reads')==1)if completed else(which=='check'and during(a,base))
                if match:
                    control['armed']=False;fired[0]=True;raise marker
            control.update(armed=True,act=inject)
            try:error=caught(lambda:a.capture(payload([1,False,-0.0]),label='marker'))
            finally:control['armed']=False
            _need(fired[0]and error is marker,'exact delegated exception identity/origin lost')
            _need(not am.is_own_limit(error),'foreign marker mislabeled as owned quota')
            unchanged(a,before,work)
            _need(delta(a,base,'reconciliation_complete_reads')==(1 if completed else 0),'wrong exception boundary')
            exact(a,h,{'stable':[1,'kept']})
            out.append(dict(type=type(marker).__name__,same_exception_object=True,completed_read_before_fault=completed,committed_ledger_unchanged=True,attempted_counters=counters(a)))
        return out
    run(EXPECTED_RECONCILIATION_FIXTURES[4],lambda:exception_matrix(False),'Seven delegated marker types at a genuinely unfinished second-read callback; every global tick/guard fault remains latched and rethrown.')
    run(EXPECTED_RECONCILIATION_FIXTURES[5],lambda:exception_matrix(True),'Seven markers at the completed-read Source guard before root publication. Full-read telemetry does not admit capture.')

    def reentrancy():
        control={'armed':False};a,h=seeded(control);base=counters(a);stream=a.iter_canonical(h);refusals=[]
        def probe(a,which):
            if which!='guard'or delta(a,base,'reconciliation_begins')!=1 or delta(a,base,'reconciliation_complete_reads')!=0:return
            control['armed']=False
            actions=[('capture',lambda:a.capture(0,label='bad')),('compose',lambda:a.compose('array',[h],label='bad')),('seal',lambda:a.seal(['seed'])),('abort',lambda:a.abort()),('view',lambda:a.view(h)),('stream',lambda:a.iter_canonical(h)),('materialize',lambda:a.materialize(h)),('next',lambda:next(stream)),('close',lambda:stream.close())]
            for name,action in actions:
                error=caught(action);_need(am.is_own_reentrancy(error),'forbidden callback API did not refuse reentrancy');refusals.append(name)
        control.update(armed=True,act=probe)
        try:result=a.capture(payload([1,2]),label='accepted')
        finally:control['armed']=False
        _need(len(refusals)==9,'callback second-read probe not reached')
        try:_need(drain(stream)==_body({'stable':[1,'kept']}),'rejected callback changed prior stream')
        finally:stream.close()
        size=exact(a,result,payload([1,2]));return dict(refused=refusals,passive_statistics_readable=True,ordinary_capture_completed=True,body_bytes=size)
    run(EXPECTED_RECONCILIATION_FIXTURES[6],reentrancy,'Passive statistics only during second-read callbacks; prohibited calls leave the prior stream and successful outer transaction intact.')

    def owned_work():
        # Prospectively fixed one-probe/one-negative procedure. No retargeting.
        value=payload([1,False,-0.0]);control={'armed':False};a=new(control);base=counters(a);boundary=[]
        def observe(a,which):
            if which=='check'and during(a,base)and not boundary:boundary.append(a.statistics())
        control.update(armed=True,act=observe)
        try:h=a.capture(value,label='boundary')
        finally:control['armed']=False
        _need(len(boundary)==1,'no genuinely unfinished direct-read callback in fixed probe')
        w=boundary[0]['counters']['work'];cap=w+1;_need(0<cap<=limits['work'],'probe-derived negative cap must strictly tighten declared finite guard')
        exact(a,h,value);probe_final=a.statistics()
        negative_control={'armed':False};b=new(negative_control,{'work':cap});negative_base=counters(b);before=ledger(b);start=negative_base['work'];negative_boundary=[]
        def observe_negative(a,which):
            if which=='check'and during(a,negative_base)and not negative_boundary:negative_boundary.append(a.statistics())
        negative_control.update(armed=True,act=observe_negative)
        try:error=caught(lambda:b.capture(value,label='boundary'))
        finally:negative_control['armed']=False
        _need(am.is_own_limit(error)and error.reason=='work','tightened run did not hit real owned work limit')
        _need(during(b,negative_base)and delta(b,negative_base,'reconciliation_complete_reads')==0,'owned limit was outside unfinished direct read')
        _need(len(negative_boundary)==1 and negative_boundary[0]['counters']['work']==w,'fresh negative did not reach identical prospectively selected callback')
        _need(counters(b)['work']>cap,'work quota was not crossed');unchanged(b,before,start)
        return dict(procedure='one successful fixed probe; one fresh identical diagnostic arena with work=W+1; no retarget/reset',probe_callback=boundary[0],probe_final=probe_final,work_cap=cap,negative_callback=negative_boundary[0],negative_statistics=b.statistics(),owned_reason=error.reason,publication_rejected=True,main_arena_caps_unchanged=True)
    run(EXPECTED_RECONCILIATION_FIXTURES[7],owned_work,'Finite local boundary-test rule declared before grant. Probe and fresh negative costs share whole-worker time/peak; only a new separate diagnostic arena is tightened, never the main arena or global limits.')
    _need(done==list(EXPECTED_RECONCILIATION_FIXTURES),'all eight exact diagnostic names completed')
    clean()
