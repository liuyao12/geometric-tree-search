"""Raw publication/ZIP/ordinary JSON comparison only; no proof machinery."""
from pathlib import Path
import hashlib,json,re,zipfile
D=Path(__file__).parent
P=Path('/private/tmp/gcts-split-controls-publish-20261015/docs/research/gcts-rl-renewal/conditional-inventory')
def load(p):return json.loads(Path(p).read_bytes())
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
c=load(D/'publication-candidate-v2.json');assert len(c['files'])==9
for d in c['files']:assert pin(d['path'])==d
m=load(P/'exact-evidence-manifest.json');assert pin(m['archive']['path'])==m['archive']
for d in m['published']:assert pin(d['path'])==d
with zipfile.ZipFile(P/'exact-evidence-archive.zip')as z:
 assert len(z.namelist())==len(set(z.namelist()))==len(m['files'])+1
 for d in m['files']:
  b=z.read(d['archive_name']);assert len(b)==d['bytes']and hashlib.sha256(b).hexdigest()==d['sha256']
 assert 'README.txt'in z.namelist()
s=(P/'exact-evidence.html').read_text();start=s.index('const saved=')+len('const saved=');end=s.rindex(';\nconst esc=')
embedded=json.loads(s[start:end]);expected=load(D/'publication-viewer-expected-v2.json')
assert canonical(embedded['entries'])==canonical(expected['entries'])
assert len({r['label']for r in embedded['entries']})==len(embedded['entries'])
assert 'JSON.stringify(e.packet,null,2)'not in s and '.textContent=e.literal_json'in s
for e in embedded['entries']:assert e['literal_json']==json.dumps(e['packet'],sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)
summary=load(P/'exact-evidence-summary.json');audit=load(P/'exact-evidence-admission.json')
assert summary['status']==audit['status']
assert summary['completed_diagnostics']==audit['completed_diagnostics']==135
assert summary['completed_independent_input_packets']==audit['completed_full_input_packets']
assert summary['representation_admitted']==audit['representation_admitted']==summary['resource_admitted']
assert len(summary['trials'])==7 and summary['trials'][5]['representation_admitted']is False
assert summary['trials'][5]['arena_private_guard']==200000000 and summary['trials'][6]['arena_private_guard']==400000000
assert summary['prior_qualified_component']['representation_admitted']is True
assert '200,000,001'in s and '135'in s and 'StopIteration'in s and 'https://peps.python.org/pep-0479/'in s
assert 'tex-chtml.js'in s and '@@'not in s and '<sup'not in s and '<sub'not in s
assert s.count('id="outcome"')==1 and s.count('id="prior-outcome"')==1 and s.count('id="artifactSelect"')==1
strip=lambda x:re.sub(r'<section id="exact-evidence">[\s\S]*?</section>','',x,count=1)
assert strip((P/'reader.html').read_text())==strip((D/'prior-publication/reader.html').read_text())
out=dict(schema='ROOT-direct-reconciliation-publication-saved-audit-v2',saved_data_only=True,scientific_calls=0,codec_or_inverse_calls=0,
 publication_candidate=pin(D/'publication-candidate-v2.json'),publication_files=9,archive_members=len(m['files'])+1,all_archive_member_bytes_match=True,
 viewer_entries=len(embedded['entries']),all_embedded_packets_match_saved_expectation=True,all_literal_JSON_display_strings_match=True,negative_float_zero_and_numeric_types_preserved=True,reader_only_owned_section_changed=True,
 current_status=summary['status'],completed_diagnostics=135,complete_current_inputs=audit['completed_full_input_packets'],earlier_qualified_trial_retained=True,
 legacy_StopIteration_limitation_cited=True,math_renderer_retained=True,proof_search_advantage=False,goal_complete=False)
p=D/'ROOT-publication-saved-audit-v2.json';assert not p.exists();p.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps(pin(p)))
