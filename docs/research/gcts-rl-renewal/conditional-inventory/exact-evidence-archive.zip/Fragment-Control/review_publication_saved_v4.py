"""Static saved HTML/JSON/ZIP raw packaging only; never execute renderer/codecs."""
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlsplit,unquote
import hashlib,json,re,zipfile
D=Path('/private/tmp/gcts-fragment-inverse-ROOT-20261019');Q=Path('/private/tmp/gcts-fragment-inverse-peer-20261019')
OLD=Path('/private/tmp/gcts-exact-evidence-ROOT-20261019');P=Path('/private/tmp/gcts-split-controls-publish-20261015/docs/research/gcts-rl-renewal/conditional-inventory')
checks=[];pins={};member_checks=[];packet_checks=[]
def need(k,v):
    checks.append(dict(label=k,passed=bool(v)))
    if not v:raise AssertionError(k)
def raw(p):
    p=Path(p);b=p.read_bytes();d=dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b));pins[str(p)]=d;return d,b
def load(p):
    d,b=raw(p);return d,json.loads(b)
def save(n,v):
    p=Q/n
    if p.exists():raise AssertionError('preserve '+str(p))
    p.write_bytes(json.dumps(v,ensure_ascii=False,sort_keys=True,indent=2,allow_nan=False).encode()+b'\n');b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def canon(v):return json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
class Page(HTMLParser):
    def __init__(self):super().__init__();self.ids=[];self.hrefs=[];self.text=[];self.skip=0;self.rows=[];self.row=None;self.cell=None
    def handle_starttag(self,t,attrs):
        a=dict(attrs)
        if 'id'in a:self.ids.append(a['id'])
        if t=='a'and'href'in a:self.hrefs.append(a['href'])
        if t in ('script','style'):self.skip+=1
        if t=='tr':self.row=[]
        if t in ('td','th')and self.row is not None:self.cell=[]
    def handle_endtag(self,t):
        if t in ('script','style'):self.skip-=1
        if t in ('td','th')and self.row is not None:self.row.append(''.join(self.cell or[]));self.cell=None
        if t=='tr'and self.row is not None:self.rows.append(self.row);self.row=None
    def handle_data(self,s):
        if not self.skip:self.text.append(s)
        if self.cell is not None:self.cell.append(s)

candidatepin,candidate=load(D/'publication-candidate-v4.json')
need('exact final candidate pin',candidatepin==dict(path=str(D/'publication-candidate-v4.json'),sha256='ef4bcf031cf4ff39a855466d6bde61b5f1e450d7eeac84af1dda41e88db25b01',bytes=2629))
need('exact9 taskscope no scientific activity',len(candidate['files'])==9 and candidate['codec_or_inverse_calls']==candidate['scientific_calls']==0 and candidate['saved_data_only']is True and candidate['goal_complete']is False and candidate['overview_unchanged']is True and candidate['reader_only_owned_section_changed']is True)
for d in candidate['files']:need('candidate whole raw '+Path(d['path']).name,raw(d['path'])[0]==d and Path(d['path']).parent==P)
hp,hb=raw(P/'exact-evidence.html');s=hb.decode();page=Page();page.feed(s);visible=' '.join(page.text)
need('exact reviewed report',hp['sha256']=='90e57961d4563d7b7f474d41a90c74950abe4237d43fdd184ab91b210a261d55'and hp['bytes']==861650)
need('IDs unique no template tokens',len(page.ids)==len(set(page.ids))and'@@'not in s)
need('no invalid C0',not any(ord(c)<32 and c not in '\r\n\t'for c in s))
need('MathJax delimiters and mathcode convention',"mathjax@3/es5/tex-chtml.js"in s and visible.count(r'\(')==visible.count(r'\)')and visible.count(r'\[')==visible.count(r'\]'))
summarypin,summary=load(P/'exact-evidence-summary.json');ap,admission=load(P/'exact-evidence-admission.json');pp,publishedpeer=load(P/'exact-evidence-peer-review.json');qp,result=load(P/'exact-evidence-result.json');np,nextdesign=load(P/'exact-evidence-next-design.json')
rootpin,root=load(D/'ROOT-final-audit-v4.json');peerpin,peer=load(Q/'typed-fragment-qualification-saved-review-v4.json');rp,runner=load(D/'actual-v4/runner-receipt.json');origqp,originalresult=load(D/'actual-v4/result.json')
need('published Root/peer literal entire packets',admission==root and publishedpeer==peer)
need('published result full byte copy',qp['sha256']==origqp['sha256']and qp['bytes']==origqp['bytes']and result==originalresult)
need('summary positive finite3+71 only',summary['status']=='QUALIFIED_FINITE_REPRESENTATION'and summary['completed_independent_input_packets']==summary['original_complete_input_count']==3 and summary['completed_diagnostics']==71 and summary['representation_admitted']is True and summary['resource_admitted']is True)
need('summary actual/guard/counter units scope',summary['qualification_private_work']==30000000 and summary['default_private_work']==20000000 and summary['default20m_guard_pass']is False and summary['old_virtual_work_profile_pass']is False and summary['inverse_execution_profile']==result['inverse_execution_profile'])
need('summary exact bytes/current resources',summary['whole_original_input_bytes']==38397056==result['aggregate_input_expanded_bytes']and summary['encoded_complete_table_bytes']==15307028==result['aggregate_encoded_table_bytes']and summary['aggregate_encoded_and_result_bytes']==15574246==runner['aggregate_encoded_result_bytes']and summary['worker_peak_bytes']==696057856==runner['worker_peak_bytes']and summary['terminal_seconds']==107.351790584==root['terminal_seconds'])
for k in ['mathematical_proof_accepted','new_target_theorem','Model_permission','schema_inventory_admission','RL_training','goal_complete']:need('summary no additional authority '+k,summary[k]is False)
need('summary no Native/search calls',summary['Native_calls']==summary['search_calls']==0)
old1pin,old1=load(OLD/'ROOT-negative-audit-v1.json');old2pin,old2=load(OLD/'ROOT-final-audit-v5.json');old3pin,old3=load(D/'ROOT-final-audit-v3.json')
oldfailures=[load(OLD/'actual-v4/worker-failure.json')[1],load(OLD/'actual-v5/worker-failure.json')[1],load(D/'actual-v3/worker-failure.json')[1]]
need('all4 trial metadata joins exact',len(summary['trials'])==4 and [x['terminal_seconds']for x in summary['trials']]==[old1['failure_terminal_seconds'],old2['terminal_seconds'],old3['terminal_seconds'],root['terminal_seconds']]and[x['worker_peak_bytes']for x in summary['trials']]==[old1['worker_peak_bytes'],old2['worker_peak_bytes'],old3['worker_peak_bytes'],root['worker_peak_bytes']]and[x['complete_inputs']for x in summary['trials']]==[0,0,0,3]and[x['diagnostics']for x in summary['trials']]==[0,0,71,71]and[x['private_guard']for x in summary['trials']]==[20000000,20000000,20000000,30000000]and[x['representation_admitted']for x in summary['trials']]==[False,False,False,True])
seampin,seam=load('/private/tmp/gcts-fragment-inverse-library-20261019/integration-reconnaissance-v1.json');designpin,design=load('/private/tmp/gcts-exact-evidence-source-20261019/independent-inverse-next-design-v1.json')
need('whole nextdesign source packets',nextdesign['integration_reconnaissance']==seam and nextdesign['prior_fragment_design']==design and nextdesign['implementation_written']is False and nextdesign['status']=='PROPOSED_NOT_IMPLEMENTED_NOT_AUTHORIZED'and nextdesign['scientific_calls']==0)
need('seam scope no activated code',seam['implementation_written']is False and seam['activation_authorized']is False and seam['actual_execution_authorized']is False and seam['scientific_calls']==0)
start=s.index('const saved=')+len('const saved=');packets,end=json.JSONDecoder().raw_decode(s[start:])
need('JSON data bounded by exactJS delimiter',s[start+end:].startswith(';\nconst esc=')and'<'not in s[start:start+end])
expected=[dict(label='Whole-run outcome and all four trials',packet=summary)]
expected.extend(dict(label='Complete input: '+r['id'],packet=r)for r in result['complete_inputs'])
expected.extend(dict(label='Diagnostic: '+r['name'],packet=r)for r in result['fixtures'])
expected.extend([dict(label='Current complete qualification result',packet=result),dict(label='Current resource receipt',packet=runner),dict(label='Earlier original checkpoint trial: UNKNOWN',packet=oldfailures[0]),dict(label='Earlier batched encoder trial: UNKNOWN',packet=oldfailures[1]),dict(label='Fragment inverse with default guard: UNKNOWN',packet=oldfailures[2]),dict(label='Root saved-data audit',packet=root),dict(label='Independent saved-data audit',packet=peer),dict(label='Earlier retention seam: Source-only proposal',packet=seam)])
need('all83 viewer packets literal complete',len(packets['entries'])==len(expected)==83 and packets['entries']==expected)
for e in expected:packet_checks.append(dict(label=e['label'],canonical_packet_bytes=len(canon(e['packet'])),canonical_packet_sha256=hashlib.sha256(canon(e['packet'])).hexdigest(),whole_literal_equal=True))
need('typed diagnostic viewer matches actual record',packets['typed_fixture']==result['fixtures'][0])
js=s[start+end:]
need('viewer safe literal display no graph override',"document.querySelector('#packetBody').textContent=JSON.stringify(e.packet,null,2)"in js and'innerHTML'not in js and'#graphPanel'not in js)
frag=next(x for x in result['fixtures']if x['name']=='fragment_repeated_subtree_and_summary');fs=frag['statistics']
need('actual diagram exact literal wire roles',frag['wire']['nodes']==[['str','x\n\\"λ'],['int','7'],['array',[0,1]],['object',[['a',2],['b',2],['c',2]]]]and frag['wire']['root']==3)
need('diagram numeric joins',fs['validated_nodes']==4 and fs['validated_edges']==5 and fs['logical_occurrences_summary']==10 and fs['root_canonical_bytes']==61 and fs['cache_hits_stream']==3)
need('diagram labels actual/newfixture notlearned','Returned diagnostic'in visible and'fragment_repeated_subtree_and_summary'in visible and'not a Wang tiling or a discovered lemma'in visible and'Colors distinguish reference roles, not learned GCTS markings.'in visible)

want=[['Artifact','Ordinary bytes','Table bytes','Immutable nodes','Independent full inverse']]
for row in result['complete_inputs']:want.append([row['id'],r'\('+format(row['input']['bytes'],',')+r'\)',r'\('+format(row['encoded']['bytes'],',')+r'\)',r'\('+format(row['immutable_node_count'],',')+r'\)','Every byte agrees'])
want.append(['Trial','Private guard / units','Complete inputs','Diagnostics','Terminal','Worker peak','Outcome'])
for trial in summary['trials']:want.append([trial['label'],r'\('+format(trial['private_guard'],',')+r'\)'+trial['operation_profile'],r'\('+str(trial['complete_inputs'])+r'\)',r'\('+str(trial['diagnostics'])+r'\)',r'\('+f"{trial['terminal_seconds']:.3f}"+r'\,\mathrm{s}\)',r'\('+f"{trial['worker_peak_bytes']/1048576:.2f}"+r'\,\mathrm{MiB}\)',trial['status']])
need('all displayed artifact/trial table cells exact',page.rows==want)
for n in [4,5,10,61,3]:need('diagram metric in LaTex '+str(n),r'\('+str(n)+r'\)'in visible)
need('storage chart exact rounding',r'\(36.62\,\mathrm{MiB}\)'in visible and r'\(14.60\,\mathrm{MiB}\)'in visible and r'\(0.25\,\mathrm{MiB}\)'in visible and r'\(14.85\,\mathrm{MiB}\)'in visible and 'width:39.865%'in s and round(100*15307028/38397056,3)==39.865)
need('encoded and expanded chart scope','storage measurement, not search speed or integrated memory savings'in visible)
need('guard distinction near outcome andresources','default private guard failed in a separate retained trial'in visible and r'\(20,354,563\)'in visible and 'Only the separately declared'in visible and 'The inverse module’s default stays unchanged; no proof-search or Native budget changes.'in visible)
need('alltrial cost comparability caveat','inverse/accounting and diagnostic order changed'in visible and 'do not establish a causal speedup'in visible and 'A hit alone is not a measured net performance benefit.'in visible)
need('actual cache counters exacttext',r'\(2,265,677\)'in visible and r'\(54,402\)'in visible and r'\(1.70\,\mathrm{MiB}\)'in visible)
need('declared clockscope','timestamp immediately after importing'in visible and 'Runner interpreter startup and the outer observer prelude precede this gated epoch.'in visible and 'observer deadline is failure-only'in visible)
need('global caps LaTex exact',all(x in visible for x in [r'\(180\,\mathrm{s}\)',r'\(210\,\mathrm{s}\)',r'\(1\,\mathrm{GiB}\)',r'\(128\,\mathrm{MiB}\)']))
need('worker memory scope no pipelinegain','excludes the outer observer/controller'in visible and 'cannot establish a reduction in integrated GCTS memory.'in visible)
need('cache boundscaveat and finitecallbackscope',r'\(8.00\,\mathrm{MiB}\)'in visible and r'\(65,536\)'in visible and r'\(4,096\)'in visible and 'not every possible completion/fallback interruption'in visible and 'no continuous formal time seal'in visible)
need('one reviewer roles and conditionaltrust','Both Source and plan review roles use this one reviewer identity.'in visible and 'Initial exclusive ownership and the pinned Python/stdlib/OS remain trusted assumptions.'in visible)
need('new qualificationnotproof','result adds no theorem and does not activate the component in proof search.'in visible and 'The two output-and-RAM failures remain failed.'in visible and 'this storage control supplies no evidence of GCTS/RL superiority.'in visible)
need('multi-root future seam explicitunimplemented','new invocation-local multi-root evidence arena'in visible and 'cannot share nodes across packets'in visible and 'Source-only design, not an implemented memory fix.'in visible)
need('future guardnewprofile equitable','smaller wire bytes cannot make that same old expansion pass an unchanged guard.'in visible and 'new finite profile, applied equally to both fixed and symbolic methods.'in visible and 'Late final-output freezing alone would not remove earlier producer allocations.'in visible)

readerpin,rb=raw(P/'reader.html');reader=rb.decode();priorreader=(D/'prior-publication-44270a10'/'reader.html').read_text();pattern=r'<section id="exact-evidence">.*?</section>'
need('onlyowned readersection changed',len(re.findall(pattern,reader,re.S))==len(re.findall(pattern,priorreader,re.S))==1 and re.sub(pattern,'OWNED_EXACT_EVIDENCE_SECTION',reader,flags=re.S)==re.sub(pattern,'OWNED_EXACT_EVIDENCE_SECTION',priorreader,flags=re.S))
ownsection=re.search(pattern,reader,re.S).group();need('reader lead exactnew finiteguard scope','Three complete'in ownsection and'seventy-one'in ownsection and'explicitly changed private guard'in ownsection)
local=[]
for href in page.hrefs:
    u=urlsplit(href)
    if u.scheme or u.netloc:continue
    p=(P/unquote(u.path)).resolve()if u.path else P/'exact-evidence.html';need('local target exists '+href,p.is_file())
    if u.fragment:
        doc=Page();doc.feed(p.read_text());need('localfragment exists '+href,unquote(u.fragment)in doc.ids)
    local.append(dict(href=href,target=str(p)))
mp,manifest=load(P/'exact-evidence-manifest.json');zp,zb=raw(P/'exact-evidence-archive.zip')
need('exact current raw ZIP',zp==manifest['archive']==dict(path=str(P/'exact-evidence-archive.zip'),sha256='c4f8bf73d5ca1aa5a674f62f0fa6b3a98415f51e6b2ac946d9b83918827e2abc',bytes=7063507))
need('manifest365 rawmembers correct',len(manifest['files'])==365 and manifest['saved_data_only']is True and manifest['codec_or_inverse_calls']==0 and manifest['goal_complete']is False)
need('all current published objects pinned',len(manifest['published'])==7 and all(raw(x['path'])[0]==x for x in manifest['published']))
names=[x['archive_name']for x in manifest['files']]
need('safe unique raw archive names',len(set(names))==365 and all(not n.startswith('/')and'..'not in Path(n).parts for n in names))
need('no opaqueNativegzip/pyc',not any(n.endswith(('.gz','.gzip','.pyc'))for n in names))
need('binaryextension logs only',all(n.endswith(('/stdout.bin','/stderr.bin'))for n in names if n.endswith('.bin')))
with zipfile.ZipFile(P/'exact-evidence-archive.zip','r')as z:
    need('exact archive366members',len(z.namelist())==len(set(z.namelist()))==366 and set(z.namelist())==set(names)|{'README.txt'})
    for row in manifest['files']:
        data=z.read(row['archive_name']);originalpin,original=raw(row['path']);wanted={k:v for k,v in row.items()if k!='archive_name'}
        need('original whole pin '+row['archive_name'],originalpin==wanted)
        need('archived fullbyte equality '+row['archive_name'],data==original and len(data)==row['bytes']==z.getinfo(row['archive_name']).file_size and hashlib.sha256(data).hexdigest()==row['sha256'])
        member_checks.append(dict(archive_name=row['archive_name'],bytes=len(data),sha256=row['sha256'],whole_equal=True))
    need('archive README fresh authorization','fresh'in z.read('README.txt').decode().lower())
paths={row['path']for row in manifest['files']}
for trialroot,actual,observation in [(OLD,'actual-v4','plan-authorized-v4-terminal-observation'),(OLD,'actual-v5','plan-authorized-v5-terminal-observation'),(D,'actual-v3','plan-authorized-v3-terminal-observation'),(D,'actual-v4','plan-authorized-v4-terminal-observation')]:
    for folder in [trialroot/actual,trialroot/observation]:
        for file in folder.iterdir():need('four full closed histories '+str(file),str(file)in paths)
for row in result['complete_inputs']:need('all3 full original files archived '+row['id'],row['input']['path']in paths)
need('current Source/plan/reviews archived',all(d['path']in paths for d in peer['current_sources'].values())and peer['authorized_index']['path']in paths and rootpin['path']in paths and peerpin['path']in paths)

audit=save('publication-saved-audit-v4.json',dict(schema='fragment-inverse-publication-saved-audit-v1',saved_data_only=True,source_only=True,scientific_calls=0,codec_calls=0,inverse_replays=0,renderer_evaluations=0,module_evaluations=0,actual_execution_authorized=False,checks=checks,check_count=len(checks),mismatch_count=0,raw_pins=list(pins.values()),viewer_packets=packet_checks,table_cells=page.rows,local_links=local,archive_members=member_checks,packaging_scope='ZIP decompression only, followed by whole raw byte/hash equality. Encoded evidence tables and Native/scientific contents were never interpreted or inverted.'))
receipt=save('typed-publication-saved-review-v4.json',dict(schema='fragment-inverse-publication-saved-review-v1',publication_review_passed=True,human_report_review_passed=True,package_review_passed=True,author_identity='/root',reviewer_identity='/root/conventional_control_review',saved_data_only=True,source_only=True,scientific_calls=0,codec_calls=0,inverse_replays=0,renderer_evaluations=0,module_evaluations=0,scientific_acceptance=False,actual_execution_authorized=False,candidate=candidatepin,report=hp,reader=readerpin,summary=summarypin,published_Root_audit=ap,published_peer_review=pp,published_result=qp,next_design=np,archive=zp,manifest=mp,Root_original_audit=rootpin,independent_saved_audit=peerpin,all83_literal_viewer_packets=True,all365_manifest_members_plus_README=True,audit=audit,check_count=len(checks),mismatch_count=0,findings=[],conclusions=[
 'The exact current report and own reader section correctly present finite3input/71diagnostic qualification under30m, default20m and oldvirtual nonqualification, all three earlier UNKNOWNs and four distinct profiles. Every displayed table/chart/counter/diagram scalar joins to saved packets;83embedded viewer packets are complete literal matches.',
 'All9 publication candidate objects match raw pins;365 manifest members plus README comprise366 ZIP entries. Each whole archived member equals its retained original bytes/hash, including all3 whole inputs, all4 closed actual/observer histories, positive/negative Source/review/grant/resource artifacts. No opaqueNative gzip or code was decoded/evaluated.',
 'The report separates storage bytes from integrated memory/performance, precise Source-entry clocks/workerpeak scope, changed privateguard/units and finite callback tests from universal claims. No theorem/Model/schema/RL/GCTS, causal speedup or oldexpandedcap rescue is implied.',
 'The earlier multi-root retention seam remains an explicitly unimplemented Source-only proposal requiring a new common representation profile applied equally to both methods, full unchanged evidence/rules and fresh scientific admission. Current qualification supplies no integration authority.'
],release_conditions=[
 'Root must publish only these exact task-owned objects, verify protected overview/unrelatedwork preservation in the final deployment and verify live HTTP/browser/MathJax/selector/diagram behavior. This review is static, not rendered-browser evidence.',
 'Any subsequent report/reader/packet/archive/manifest mutation needs an exact bounded successor/delta review. This post-freeze review artifact is intentionally outside the ZIP; no recursive self-hash is required.'
],limitations=[
 'No renderer/JavaScript/Python target functions, codec/inverse/fixtures or scientific proof/Model/search/Native code was run. Ordinary saved JSON/HTML/statistics and ZIP container packaging only; encoded node tables were raw-hashed, not semantically decoded.',
 'Saved whole-literal-equality receipts rely conditionally on the pinned reviewed worker and prior saved-data audit; no new inverse replay or universal data-correctness proof. Root protected-overview flags and archive source history do not replace final task-only deployment/live checks.',
 'Control authored older scientific/control/outer Sources and current review obligations but none of the five current representation components or Root report. This reviews Root presentation and packaging independently; it does not self-cert inherited algorithms, kernel soundness or causal benchmark generalization.'
]))
handoff=save('publication-saved-peer-handoff-v4.json',dict(schema='fragment-inverse-publication-saved-handoff-v1',receipt=receipt,audit=audit,publication_review_passed=True,scientific_calls=0,actual_execution_authorized=False))
print(json.dumps(dict(receipt=receipt,audit=audit,handoff=handoff,check_count=len(checks)),sort_keys=True))
