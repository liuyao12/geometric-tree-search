"""Finite authored arena diagnostics. SOURCE ONLY; never run by its author.

Not a proof checker. Root must authenticate modules, own the once/deadline/RAM
profile, retain all71 prior diagnostics and all3 whole original inputs separately.
"""
import json
import math

VERSION='arena-qualification-fixtures-v1'
EXPECTED_ARENA_FIXTURES=(
 'cross_capture_typed_exact_dedup',
 'previous_handles_and_eager_path_after_append',
 'constructor_limits_owned',
 'captured_caller_mutation_isolation',
 'exported_carrier_mutation_isolation',
 'fresh_materialized_occurrences_and_calls',
 'compose_repeated_order_and_logical_ledger',
 'document_coverage_rejects_unused_catalogue',
 'missing_null_zero_false_typed_paths',
 'foreign_handle_and_public_constructor_rejected',
 'root_labels_invalid_duplicate_unicode',
 'cyclic_input_rejects_without_commit',
 'capture_precommit_fault_atomic_costs',
 'compose_precommit_fault_atomic_costs',
 'seal_precommit_fault_atomic_costs',
 'owned_capture_work_stop_atomic',
 'disabled_fragment_cache_full_stream',
 'partial_fragment_cache_full_stream',
 'metadata_size_and_unicode_guards',
 'active_abort_before_first_pull',
 'active_abort_midstream',
 'active_abort_after_last_chunk',
 'active_abort_after_complete',
 'sealed_abort_invalidates_reads_exports_streams',
 'close_incomplete_never_completes',
 'callbacks_statistics_only_reentrancy',
 'foreign_capture_exception_identity_matrix',
 'foreign_precommit_exception_identity_matrix',
 'foreign_stream_early_exception_identity_matrix',
 'foreign_stream_completion_exception_identity_matrix',
 'document_labels_exact_unique_and_seal_atomic',
 'invalid_compose_preserves_committed_state',
 'sealed_handles_views_streams_stable',
)

class FixtureFailure(ValueError):pass
class FixtureSentinel(Exception):pass

def _body(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode('utf8')
def _need(ok,message):
    if not ok:raise FixtureFailure(message)

def run_arena_fixtures(arena_module,limits,tick,guard,rows,context):
    """Append one completed diagnostic after each case, or propagate unchanged.

    Root tick/guard errors are latched before any expected-error classification.
    This function has no own timeout handler and never returns a PASS for a
    partial case. Tests use public APIs only, not backing-state/module mutations.
    """
    if type(rows) is not list or type(context) is not dict or type(limits) is not dict:
        raise TypeError('owned result prefix/context/full limit map required')
    if not callable(tick) or not callable(guard):raise TypeError('external charged callbacks required')
    _need(arena_module.VERSION=='exact-evidence-arena-v1','exact arena API version')
    external_fault=[None];completed=[]

    def external(callback):
        try:callback()
        except BaseException as error:
            if external_fault[0] is None:external_fault[0]=error
            raise
    def no_external_fault():
        if external_fault[0] is not None:raise external_fault[0]
    def checkpoint():
        external(tick);external(guard);no_external_fault()
    def new(changes=None,control=None,source_epoch='e',semantic_epoch='s'):
        cap=dict(limits)
        if changes:
            for k,v in changes.items():
                _need(k in cap and type(v) is int and v<=cap[k],'fixture limits may only tighten')
                cap[k]=v
        def check_callback():
            external(tick)
            if control is not None and control.get('check') is not None:control['check']()
        def guard_callback():
            external(guard)
            if control is not None and control.get('guard') is not None:control['guard']()
        return arena_module.Arena(source_epoch=source_epoch,semantic_epoch=semantic_epoch,
            check=check_callback,source_guard=guard_callback,limits=cap)
    def state(a):
        s=a.statistics()
        return {k:s[k] for k in ('lifecycle','nodes','edges','roots','cache_entries',
            'cache_bytes','documents','logical_document_bytes','physical_wire_bytes')}
    def unchanged(a,before,work_before):
        _need(state(a)==before,'failed transaction changed committed capacity/lifecycle')
        _need(a.statistics()['counters'].get('work',0)>=work_before,'attempted work rolled back')
    def caught(action):
        try:action()
        except BaseException as error:
            no_external_fault();return error
        no_external_fault();raise FixtureFailure('expected an exception')
    def data_error(action):
        e=caught(action);_need(type(e) is arena_module.ArenaDataError,'exact data refusal expected');return str(e)
    def lifecycle_error(action):
        e=caught(action)
        _need(type(e) is arena_module.LifecycleError and arena_module.is_own_lifecycle(e),'owned lifecycle refusal expected')
        return str(e)
    def own_limit(action):
        e=caught(action);_need(arena_module.is_own_limit(e),'owned arena limit expected');return e.reason
    def identical(action,sentinel):
        e=caught(action);_need(e is sentinel,'foreign exception object/origin replaced')
    def drain(stream):
        parts=[]
        while True:
            checkpoint()
            try:b=next(stream)
            except StopIteration:
                no_external_fault()
                _need(stream.completed is True,'loop exhaustion without owned completion')
                break
            _need(type(b) is bytes and 0<len(b)<=limits['chunk_bytes'],'finite builtin output chunks')
            parts.append(b)
        return b''.join(parts)
    def exact_stream(a,h,value,path=()):
        actual=drain(a.iter_canonical(h,path));expected=_body(value)
        _need(actual==expected,'full canonical fixture bytes mismatch');return len(actual)
    def run(name,action,scope):
        context.update(stage='ARENA_FIXTURES',fixture=name)
        checkpoint();observation=action();checkpoint()
        packet=dict(schema='arena-finite-diagnostic-v1',name=name,status='passed',
            scope=scope,observed=observation,authority=False)
        rows.append(packet);completed.append(name)

    def typed():
        a=new();vals=[True,1,0.0,-0.0,False,0,None,'é\n']
        hs=[a.capture(v,label='v'+str(i)) for i,v in enumerate(vals)]
        kinds=[a.view(h).kind for h in hs]
        _need(kinds==['bool','int','float','float','bool','int','null','str'],'typed value tags')
        _need(a.view(hs[2]).payload=='0.0' and a.view(hs[3]).payload=='-0.0','signed float lexical distinction')
        _need(len({a.view(h).node_id for h in hs})==len(hs),'typed scalar identity collision')
        before=a.statistics()['nodes'];h1=a.capture({'x':[True,1,-0.0]},label='same1')
        mid=a.statistics()['nodes'];h2=a.capture({'x':[True,1,-0.0]},label='same2')
        _need(mid>=before and a.statistics()['nodes']==mid,'equal cross-capture nodes not interned')
        _need(a.view(h1).node_id==a.view(h2).node_id,'equal full values have different node identity')
        for h,v in zip(hs,vals):exact_stream(a,h,v)
        return dict(kinds=kinds,unique_scalar_ids=len(hs),dedup_verified=True)
    run(EXPECTED_ARENA_FIXTURES[0],typed,'Finite typed scalar and equal-but-separately-constructed object cases; no universal value-domain claim.')

    def append_snapshot():
        a=new();h=a.capture({'p':[1,2]},label='first');path=['p'];stream=a.iter_canonical(h,path)
        view=a.view(h,path);path[0]='missing';a.capture({'later':3},label='later')
        _need(drain(stream)==b'[1,2]' and view.kind=='array','eager path/prior snapshot changed after append')
        return dict(previous_body_bytes=exact_stream(a,h,{'p':[1,2]}),snapshot_stable=True)
    run(EXPECTED_ARENA_FIXTURES[1],append_snapshot,'Eager API-call path snapshot and prior view/handle after append, not concurrency.')

    def limits_owned():
        cap=dict(limits)
        a=arena_module.Arena(source_epoch='e',semantic_epoch='s',check=lambda:external(tick),
            source_guard=lambda:external(guard),limits=cap)
        cap['nodes']=0;cap['chunk_bytes']=0;cap['depth']=0
        h=a.capture([[[1]]],label='owned');exact_stream(a,h,[[[1]]])
        return dict(external_limit_mutation_did_not_change_arena=True)
    run(EXPECTED_ARENA_FIXTURES[2],limits_owned,'Mutates caller limit dictionary after constructor; no backing/private arena limit mutation.')

    def caller_mutation():
        value={'x':[1,{'y':False}]};a=new();h=a.capture(value,label='v')
        value['x'][1]['y']=True;value['x'].append(9);value['extra']=0
        return dict(bytes=exact_stream(a,h,{'x':[1,{'y':False}]}),caller_alias_absent=True)
    run(EXPECTED_ARENA_FIXTURES[3],caller_mutation,'Actual caller container mutation after successful capture.')

    def wire_mutation():
        a=new();h=a.capture({'x':[1,1]},label='v');sealed=a.seal(['v'])
        wire=a.to_wire(sealed);pristine=_body(wire)
        wire['nodes'][0][0]='corrupt';wire['roots'].append(['fake',0]);wire['documents'].clear()
        _need(_body(a.to_wire(sealed))==pristine,'returned wire mutation changed arena')
        exact_stream(a,h,{'x':[1,1]});return dict(fresh_wire_repeat_equal=True)
    run(EXPECTED_ARENA_FIXTURES[4],wire_mutation,'Mutates the actually returned wire carrier, not a second copy.')

    def fresh_materialize():
        a=new();h=a.capture([{'x':[1]},{'x':[1]}],label='v')
        x=a.materialize(h);y=a.materialize(h)
        _need(x is not y and x[0] is not x[1] and x[0]['x'] is not x[1]['x'],'shared mutable materialization')
        x[0]['x'].append(2)
        _need(x[1]['x']==[1] and y==[{'x':[1]},{'x':[1]}],'per-occurrence/call mutation leaked')
        _need(a.materialize(h)==y,'later materialization poisoned')
        return dict(fresh_occurrences=True,fresh_calls=True)
    run(EXPECTED_ARENA_FIXTURES[5],fresh_materialize,'Fresh builtin list/dict occurrences for a repeated immutable node.')

    def compose_ledger():
        a=new();p=a.capture([1,2],label='p');q=a.capture('v',label='q')
        h=a.compose('array',[q,p,q],label='result');value=['v',[1,2],'v']
        hits=a.statistics()['counters'].get('fragment_hits',0)
        exact_stream(a,h,value)
        _need(a.statistics()['counters'].get('fragment_hits',0)-hits==1,'small complete root fragment path not exercised')
        sealed=a.seal(['result']);wire=a.to_wire(sealed);stats=a.statistics()
        _need(stats['logical_document_bytes']==len(_body(value))+1,'catalogue added duplicate logical budget')
        _need(stats['physical_wire_bytes']==len(_body(wire))+1,'whole physical newline ledger')
        _need(wire['roots']==[['p',a.view(p).node_id],['q',a.view(q).node_id],['result',a.view(h).node_id]],'catalogue order changed')
        return dict(logical_bytes=stats['logical_document_bytes'],physical_bytes=stats['physical_wire_bytes'],ordered_repeated_children=True,complete_fragment_hits=1)
    run(EXPECTED_ARENA_FIXTURES[6],compose_ledger,'All captures catalogued physically, one composed logical document; repeated child occurrence retained.')

    def coverage():
        a=new();p=a.capture(1,label='p');q=a.capture(2,label='q');before=state(a);w=a.statistics()['counters']['work']
        data_error(lambda:a.seal(['p']));unchanged(a,before,w)
        h=a.compose('array',[p,q],label='both');a.seal(['both'])
        return dict(unused_catalogue_rejected=True,complete_projection_bytes=exact_stream(a,h,[1,2]))
    run(EXPECTED_ARENA_FIXTURES[7],coverage,'Reject omitted committed root ID; no silent catalogue filtering.')

    def missing_paths():
        a=new();h=a.capture({'n':None,'z':0,'f':False,'a':[0]},label='v')
        _need(a.view(h,['absent']) is arena_module.MISSING,'missing not tagged')
        _need([a.view(h,[k]).kind for k in ('n','z','f')]==['null','int','bool'],'missing/null/zero/false conflated')
        _need(a.view(h,['a',0]).payload=='0','exact array index')
        for path in (['a',True],['a',-1],['a','0'],[False]):data_error(lambda path=path:a.view(h,path))
        return dict(missing_distinct=True,typed_index_refusals=4)
    run(EXPECTED_ARENA_FIXTURES[8],missing_paths,'Finite path typing/missing cases, not arbitrary path grammar proof.')

    def foreign_handles():
        a=new();b=new();h=a.capture(1,label='a')
        data_error(lambda:b.view(h));data_error(lambda:b.compose('array',[h],label='bad'))
        data_error(lambda:a.capture(h,label='notordinary'))
        e=caught(lambda:arena_module.RootHandle(a,0,'fabricated'))
        _need(type(e) is TypeError,'public root constructor accepted fabricated handle')
        a.abort();lifecycle_error(lambda:a.view(h))
        return dict(foreign_and_stale_rejected=True,public_constructor_rejected=True,provisional_handle_not_observable=True)
    run(EXPECTED_ARENA_FIXTURES[9],foreign_handles,'No private handle/token write; actual provisional backing exposure is Source-reviewed, not forged here.')

    def labels():
        a=new();h=a.capture(1,label='é');before=state(a);w=a.statistics()['counters']['work']
        for label in ('',0,'\ud800','é'):data_error(lambda label=label:a.capture(2,label=label))
        unchanged(a,before,w);_need(h.label=='é','Unicode label changed')
        return dict(refusals=4,nonascii_label_preserved=True)
    run(EXPECTED_ARENA_FIXTURES[10],labels,'Exact nonempty scalar Unicode labels and duplicate label refusal.')

    def cycles():
        a=new();a.capture(0,label='old');before=state(a);w=a.statistics()['counters']['work']
        cyclic=[];cyclic.append(cyclic);data_error(lambda:a.capture(cyclic,label='cycle'));unchanged(a,before,w)
        return dict(cycle_rejected=True,committed_state_unchanged=True)
    run(EXPECTED_ARENA_FIXTURES[11],cycles,'Public cyclic ordinary input, no private graph mutation.')

    def precommit(which,sentinel=None):
        control={};a=new(control=control);h=a.capture(0,label='old')
        before=state(a);work=a.statistics()['counters']['work'];calls=[0]
        fault=FixtureSentinel('precommit '+which) if sentinel is None else sentinel
        def at_guard():
            calls[0]+=1
            if calls[0]==2:raise fault
        control['guard']=at_guard
        action=(lambda:a.capture([1,2],label='new')) if which=='capture' else (lambda:a.compose('array',[h,h],label='new')) if which=='compose' else (lambda:a.seal(['old']))
        identical(action,fault);control['guard']=None;unchanged(a,before,work)
        _need(calls[0]==2,'did not reach second operation guard')
        exact_stream(a,h,0)
        return dict(second_guard_fault_exact=True,committed_state_unchanged=True,attempted_work_after=a.statistics()['counters']['work'])
    for index,which in ((12,'capture'),(13,'compose'),(14,'seal')):
        run(EXPECTED_ARENA_FIXTURES[index],lambda which=which:precommit(which),
            'Second operation guard targets current final prepublication guard; no frame/private state fixture or arbitrary allocation-failure claim.')

    def work_stop():
        a=new({'work':40});before=state(a);w=a.statistics()['counters']['work']
        reason=own_limit(lambda:a.capture(list(range(30)),label='large'));unchanged(a,before,w)
        _need(reason=='work' and a.statistics()['counters']['work']>w,'wrong private quota stop')
        return dict(reason=reason,attempted_work=a.statistics()['counters']['work'],committed_state_unchanged=True)
    run(EXPECTED_ARENA_FIXTURES[15],work_stop,'Tighter immutable constructor work limit; exhausted arena not retried or granted authority.')

    def cache_case(changes,partial):
        a=new(changes);value=[{'x':[1,2]},{'x':[1,2]}];h=a.capture(value,label='v')
        exact_stream(a,h,value);s=a.statistics()
        _need((s['cache_entries']>0) if partial else s['cache_entries']==0,'cache variant not exercised')
        if partial:_need(s['cache_entries']<=changes['cache_entries'],'cache entry ceiling exceeded')
        return dict(cache_entries=s['cache_entries'],cache_bytes=s['cache_bytes'],complete_fallback_bytes=True)
    run(EXPECTED_ARENA_FIXTURES[16],lambda:cache_case({'cache_bytes':0,'cache_entries':0},False),'Disabled optional fragments preserve full ordinary stream.')
    run(EXPECTED_ARENA_FIXTURES[17],lambda:cache_case({'cache_bytes':4,'cache_entries':1},True),'One small fragment fills cache; remaining structure uses full uncached traversal.')

    def metadata_guards():
        e=caught(lambda:new(source_epoch='\ud800'));_need(type(e) is arena_module.ArenaDataError,'epoch surrogate accepted')
        reason=own_limit(lambda:new({'scalar_bytes':3},source_epoch='long'))
        a=new({'scalar_bytes':3});before=state(a);w=a.statistics()['counters']['work']
        own_limit(lambda:a.capture(0,label='é'));unchanged(a,before,w)
        return dict(epoch_unicode_rejected=True,epoch_size_reason=reason,label_size_rejected=True)
    run(EXPECTED_ARENA_FIXTURES[18],metadata_guards,'Epoch/label scalar limits are part of charged metadata, not ignored headers.')

    def aborted(stage):
        a=new({'chunk_bytes':2});h=a.capture('abcdef',label='v');stream=a.iter_canonical(h)
        expected=_body('abcdef');parts=[]
        if stage=='mid':parts.append(next(stream))
        elif stage=='last':
            while sum(map(len,parts))<len(expected):parts.append(next(stream))
            _need(b''.join(parts)==expected and stream.completed is False,'last-chunk boundary not isolated')
        elif stage=='complete':_need(drain(stream)==expected,'complete pre-abort stream')
        a.abort();lifecycle_error(lambda:next(stream));lifecycle_error(lambda:a.view(h))
        _need(a.statistics()['lifecycle']=='ABORTED','abort state unavailable')
        return dict(boundary=stage,prefix_bytes=sum(map(len,parts)),history_completed=stream.completed,future_pulls_rejected=True)
    for index,stage in ((19,'before'),(20,'mid'),(21,'last'),(22,'complete')):
        run(EXPECTED_ARENA_FIXTURES[index],lambda stage=stage:aborted(stage),'Public abort invalidates live future accesses; previously completed bytes are historical only.')

    def sealed_abort():
        a=new();h=a.capture([1],label='v');stream=a.iter_canonical(h);sealed=a.seal(['v']);a.abort()
        lifecycle_error(lambda:next(stream));lifecycle_error(lambda:a.to_wire(sealed));lifecycle_error(lambda:a.view(h))
        _need(stream.completed is False,'aborted unstarted stream completed')
        return dict(sealed_abort_invalidates=True)
    run(EXPECTED_ARENA_FIXTURES[23],sealed_abort,'Abort after seal, not only ACTIVE lifecycle.')

    def close_prefix():
        a=new({'chunk_bytes':2});h=a.capture('abcdef',label='v');stream=a.iter_canonical(h)
        next(stream);stream.close();lifecycle_error(lambda:next(stream))
        _need(stream.completed is False,'close qualified prefix')
        return dict(closed_prefix_incomplete=True)
    run(EXPECTED_ARENA_FIXTURES[24],close_prefix,'Cleanup close invokes no own completion; only public stream state observed.')

    def reentrancy():
        total=0
        for channel in ('check','guard'):
            control={};a=new(control=control);h=a.capture(0,label='v');stream=a.iter_canonical(h)
            actions=[lambda:a.view(h),lambda:a.iter_canonical(h),lambda:a.materialize(h),
                lambda:a.capture(1,label='bad'),lambda:a.compose('array',[h],label='bad'),
                lambda:a.seal(['v']),lambda:a.to_wire(None),lambda:a.abort(),lambda:next(stream),lambda:stream.close()]
            for action in actions:
                fired=[False]
                def probe():
                    if fired[0]:return
                    fired[0]=True;snapshot=a.statistics();snapshot['counters']['fixture_mutation']=1
                    e=caught(action)
                    _need(type(e) is arena_module.ReentrancyError and arena_module.is_own_reentrancy(e),'callback operation did not reject reentrancy')
                control[channel]=probe;a.view(h);control[channel]=None
                _need(fired[0] and 'fixture_mutation' not in a.statistics()['counters'],'callback stats alias or missing probe')
                total+=1
            _need(drain(stream)==b'0','reentrancy refusal changed stream')
        return dict(channels=['check','guard'],rejected_operations=total,passive_stats_owned=True)
    run(EXPECTED_ARENA_FIXTURES[25],reentrancy,'Public charged read/write/export/abort/close recursion rejected; no private writes or nested Root callbacks.')

    def sentinels():
        return [FixtureSentinel('custom'),RuntimeError('runtime'),ValueError('value'),
                StopIteration('stop'),GeneratorExit('generator-exit'),SystemExit('system-exit')]
    def foreign_capture():
        observed=[]
        for fault in sentinels():
            control={};a=new(control=control);before=state(a);w=a.statistics()['counters']['work']
            def throw(fault=fault):raise fault
            control['check']=throw;identical(lambda:a.capture(1,label='bad'),fault)
            control['check']=None;unchanged(a,before,w);observed.append(type(fault).__name__)
        return dict(exact_identity=observed)
    run(EXPECTED_ARENA_FIXTURES[26],foreign_capture,'Foreign check exception objects, including exact StopIteration, not expected own quotas.')

    def foreign_precommit():
        observed=[]
        for fault in sentinels():precommit('capture',fault);observed.append(type(fault).__name__)
        return dict(exact_identity=observed,operation='capture second guard')
    run(EXPECTED_ARENA_FIXTURES[27],foreign_precommit,'Exact foreign guard objects at current prepublication callback boundary.')

    def stream_fault(late):
        observed=[]
        for fault in sentinels():
            control={};a=new(control=control);h=a.capture(0,label='v');stream=a.iter_canonical(h)
            if late:_need(next(stream)==b'0' and stream.completed is False,'small stream late boundary')
            calls=[0]
            def throw(fault=fault):
                calls[0]+=1
                if not late or calls[0]==2:raise fault
            control['guard']=throw
            # Explicit next catches the exact foreign StopIteration object;
            # for-loop termination alone would be insufficient evidence.
            identical(lambda:next(stream),fault);control['guard']=None
            _need(stream.completed is False,'foreign stream exception qualified completion')
            lifecycle_error(lambda:next(stream));observed.append(type(fault).__name__)
        return dict(exact_identity=observed,late_completion=late)
    run(EXPECTED_ARENA_FIXTURES[28],lambda:stream_fault(False),'Manual first pull; exact foreign objects and terminal failed stream.')
    run(EXPECTED_ARENA_FIXTURES[29],lambda:stream_fault(True),'Manual post-last-chunk completion pull; exact foreign object and no completion.')

    def document_labels():
        a=new();a.capture(0,label='v');before=state(a);w=a.statistics()['counters']['work']
        for labels in ([],['v','v'],['absent'],[False],['\ud800']):data_error(lambda labels=labels:a.seal(labels))
        unchanged(a,before,w);a.seal(['v']);return dict(rejected_documents=5,unchanged_before_valid_seal=True)
    run(EXPECTED_ARENA_FIXTURES[30],document_labels,'Complete nonempty exact document-label list; no output profile change.')

    def invalid_compose():
        a=new();h=a.capture(1,label='v');before=state(a);w=a.statistics()['counters']['work']
        for action in (lambda:a.compose('array',[h,object()],label='bad'),
                       lambda:a.compose('object',[('k',h),('k',h)],label='bad'),
                       lambda:a.compose('scalar',[h],label='bad')):data_error(action)
        unchanged(a,before,w);exact_stream(a,h,1)
        return dict(invalid_compositions=3,committed_state_unchanged=True)
    run(EXPECTED_ARENA_FIXTURES[31],invalid_compose,'Untrusted child/kind/duplicate-key proposals rejected without commit.')

    def sealed_stable():
        a=new();h=a.capture(0,label='x');q=a.capture(0,label='y');view=a.view(h);stream=a.iter_canonical(q)
        sealed=a.seal(['x','y']);_need(view.kind=='int' and drain(stream)==b'0','prior handles/views/stream invalid after seal')
        _need(a.statistics()['logical_document_bytes']==4,'distinct named equal documents not charged twice')
        lifecycle_error(lambda:a.capture(1,label='new'));lifecycle_error(lambda:a.compose('array',[h],label='new'));lifecycle_error(lambda:a.seal(['x']))
        wire=a.to_wire(sealed);_need(wire['documents']==['x','y'],'document order changed')
        return dict(equal_named_documents_charged_separately=True,sealed_writes_rejected=True)
    run(EXPECTED_ARENA_FIXTURES[32],sealed_stable,'SEALED reads remain valid before abort; physical catalogue is not an extra logical document.')

    checkpoint();_need(tuple(completed)==EXPECTED_ARENA_FIXTURES,'exact completed arena fixture order')
    context['fixture']=None
    return dict(schema='arena-finite-fixtures-return-v1',version=VERSION,
        completed=list(completed),count=len(completed),authority=False,
        coverage='Finite authored public-interface diagnostics only; no universal correctness, allocation-failure, hostile/private mutation, concurrency, pipeline or theorem claim.')

# Reviewer inert copied-Source text only; never evaluated.
