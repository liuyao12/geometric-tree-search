"""Retained HTML/JSON/raw ZIP packaging audit. Never imports any evidence component."""
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlsplit,unquote
import hashlib,json,re,subprocess,zipfile
R=Path('/private/tmp/gcts-incremental-arena-ROOT-20261019');O=Path('/private/tmp/gcts-incremental-arena-peer-20261019');P=Path('/private/tmp/gcts-split-controls-publish-20261015/docs/research/gcts-rl-renewal/conditional-inventory');PUB=P.parents[3]
def d(p):
 h=hashlib.sha256();size=0
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b);size+=len(b)
 return dict(path=str(p.resolve()),sha256=h.hexdigest(),bytes=size)
def load(p):return json.loads(Path(p).read_bytes())
def canonical(v):return json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode('utf8')
def saved(h):
 start=h.index('const saved=')+len('const saved=');obj,end=json.JSONDecoder().raw_decode(h[start:]);assert h[start+end:].startswith(';\nconst esc=');return obj
checks=[]
def need(n,v,e):
 assert v,(n,e);checks.append(dict(name=n,passed=True,evidence=e))
class Page(HTMLParser):
 def __init__(self):super().__init__(convert_charrefs=True);self.ids=[];self.links=[];self.assets=[];self.styles=[];self.visible=[];self.skip=0;self.table_depth=0;self.tables=[];self.current_table=None;self.in_row=False;self.row=[];self.cell=None;self.forbidden=[]
 def handle_starttag(self,t,a):
  a=dict(a)
  if 'id'in a:self.ids.append(a['id'])
  if t=='a'and 'href'in a:self.links.append(a['href'])
  if t=='link'and 'href'in a:self.assets.append(a['href'])
  if t=='script'and 'src'in a:self.assets.append(a['src'])
  if 'style'in a:self.styles.append(a['style'])
  if t in ['sup','sub']:self.forbidden.append(t)
  if t in ['script','style']:self.skip+=1
  if t=='table':self.current_table=[];self.tables.append(self.current_table)
  if t=='tr':self.row=[];self.in_row=True
  if t in ['td','th']and self.in_row:self.cell=[]
 def handle_endtag(self,t):
  if t in ['script','style']:self.skip-=1
  if t in ['td','th']and self.cell is not None:self.row.append(''.join(self.cell));self.cell=None
  if t=='tr'and self.in_row:
   if self.current_table is not None:self.current_table.append(self.row)
   self.in_row=False
  if t=='table':self.current_table=None
 def handle_data(self,s):
  if not self.skip:self.visible.append(s)
  if self.cell is not None:self.cell.append(s)
c=load(R/'publication-candidate-v1.json');m=load(P/'exact-evidence-manifest.json');rootpa=load(R/'ROOT-publication-saved-audit-v1.json')
need('frozen_candidate_pin',d(R/'publication-candidate-v1.json')==dict(path=str(R/'publication-candidate-v1.json'),sha256='04e8857bcba5ffb070dab3c2837256d72f8febd52232dc06293cfc0df48dbcef',bytes=2400),'Current immutable nine-file candidate.')
need('nine_task_files',len(c['files'])==9 and len({q['path']for q in c['files']})==9,'No unrelated publication asset added.')
for q in c['files']:need('candidate_'+Path(q['path']).name,d(Path(q['path']))==q,'Exact whole current task file SHA/size.')
need('viewer_expected_pin',d(Path(c['viewer_expected']['path']))==c['viewer_expected'],'Root expectation retained as additional comparison, not sole source authority.')
html=(P/'exact-evidence.html').read_text();oldhtml=(R/'prior-publication/exact-evidence.html').read_text();page=Page();page.feed(html);visible=''.join(page.visible);embedded=saved(html)['entries'];oldentries=saved(oldhtml)['entries'];expected=load(Path(c['viewer_expected']['path']))['entries']
need('viewer_exact_Root_expectation',canonical(embedded)==canonical(expected),'Whole typed canonical ordinary values, including booleans/int/float signedzero spellings; no inverse/codec call.')
need('219_unique_viewer_labels',len(embedded)==len({q['label']for q in embedded})==219,'All current and earlier packets retained.')
failure=load(R/'actual-v1/worker-failure.json');runner=load(R/'actual-v1/runner-receipt.json');terminal=load(R/'plan-authorized-v1-terminal-observation/terminal.json');summary=load(P/'exact-evidence-summary.json');ra=load(R/'ROOT-final-audit-v1.json');peer=load(O/'typed-arena-qualification-saved-review-v1.json');oldsummary=load(R/'prior-publication/exact-evidence-summary.json');decl=load(R/'declaration-v1.json');plan=load(R/'plan-authorized-v1.json');packet=load(R/'ten-Source-packet-v3.json');current_Source_review=load(O/'typed-components-Source-review-v3.json')
independently_expected=[dict(label='Current shared-arena outcome and all five trials',packet=summary)]
independently_expected.extend(dict(label='Current diagnostic: '+q['name'],packet=q)for q in failure['completed_fixture_prefix'])
independently_expected.extend([dict(label='Current complete result or failure',packet=failure),dict(label='Current resource receipt',packet=runner),dict(label='Current terminal observation',packet=terminal),dict(label='Current Root saved-data audit',packet=ra),dict(label='Current independent saved-data audit',packet=peer),dict(label='Legacy generator exception limitation: Source-only finding',packet=load(O/'legacy-generator-StopIteration-scope-gap-v1.json')),dict(label='Current arena and inverse contract',packet=load(R/'shared-contract-v5.json')),dict(label='Current Source review: no execution',packet=current_Source_review)])
independently_expected.extend(dict(label='Earlier trial — '+q['label'],packet=q['packet'])for q in oldentries)
need('full_viewer_independent_current_and_prior',len(independently_expected)==219,'127 current fixtures plus raw failure/resource/reviews and all83 earlier embedded entries.')
for n,(found,want)in enumerate(zip(embedded,independently_expected)):need('viewer_packet_'+str(n),canonical(found)==canonical(want),want['label'])
need('prior83_literal_preserved',len(oldentries)==83 and canonical(embedded[-83:])==canonical([dict(label='Earlier trial — '+q['label'],packet=q['packet'])for q in oldentries]),'Earlier positive+negative history unfiltered.')
need('summary_current_failure_values',summary['status']==failure['status']=='UNKNOWN_EVIDENCE_LIMIT'and summary['completed_independent_input_packets']==0 and summary['completed_diagnostics']==127 and summary['current_failure_context']==failure['reached_context']and summary['representation_admitted']is False and summary['resource_admitted']is False,'Current failed trial separated from earlier component qualification.')
need('current_summary_numerics',summary['terminal_seconds']==69.395769417==terminal['runner_clock_seconds']and summary['worker_peak_bytes']==643563520==runner['worker_wait4_usage']['ru_maxrss']and summary['whole_original_input_bytes']==38397056,'Exact retained timings/worker peak/full-selected raw byte sum.')
need('earlier_summary_preserved',canonical(summary['prior_qualified_component'])==canonical(oldsummary),'Whole old summary retained under explicit historical field.')
need('five_trials_exact',len(summary['trials'])==5 and canonical(summary['trials'][:4])==canonical(oldsummary['trials'])and summary['trials'][4]['complete_inputs']==0 and summary['trials'][4]['diagnostics']==127 and summary['trials'][4]['arena_private_guard']==200000000 and summary['trials'][4]['private_guard']==30000000 and summary['trials'][4]['representation_admitted']is False,'Same old4 plus one new distinct negative profile.')
need('exactly_one_earlier_qualification',sum(q['representation_admitted']is True for q in summary['trials'])==1 and summary['trials'][3]['id']=='fragments-30m'and summary['prior_qualified_component']['default20m_guard_pass']is False and summary['prior_qualified_component']['old_virtual_work_profile_pass']is False,'No promotion of current or old20m/virtual trials.')
need('old_measurement_table_literal',page.tables[0][1:]==[[q['id'],'\\('+f"{q['input']['bytes']:,}"+'\\)','\\('+f"{q['encoded']['bytes']:,}"+'\\)','\\('+f"{q['immutable_node_count']:,}"+'\\)','Every byte agrees']for q in load(R/'prior-publication/exact-evidence-result.json')['complete_inputs']],'Historical3 full artifact rows agree with retained qualified result.')
need('five_trial_table_count',len(page.tables[1])==6,'Header plus all five trials shown.')
for row,t in zip(page.tables[1][1:],summary['trials']):
 need('trial_display_'+t['id'],row[0]==t['label']and row[-1]==t['status']and row[2]=='\\('+str(t['complete_inputs'])+'\\)'and row[3]=='\\('+str(t['diagnostics'])+'\\)'and row[4]=='\\('+f"{t['terminal_seconds']:.3f}"+'\\,\\mathrm{s}\\)'and row[5]=='\\('+f"{t['worker_peak_bytes']/1048576:.2f}"+'\\,\\mathrm{MiB}\\)','Count/time/worker-only MiB display derived from literal saved trial.')
need('historical_chart_totals',oldsummary['whole_original_input_bytes']==38397056 and oldsummary['encoded_complete_table_bytes']==15307028 and oldsummary['aggregate_encoded_and_result_bytes']==15574246,'Displayed old storage sizes retain full result charge267218bytes.')
for text in ['36.62','14.60','0.25','14.85','613.75','69.396','200,000,001','200,000,000','20,354,563']:
 need('visible_number_'+text,text in visible,'Rendered-as-LaTeX visible text contains the correct saved number.')
need('typed_chart_bar_value',any('39.865%'in x for x in page.styles),'Old typed-table fraction15307028/38397056 formatted3decimals; no current forest storage value invented.')
need('whole_published_result_failure',(P/'exact-evidence-result.json').read_bytes()==(R/'actual-v1/worker-failure.json').read_bytes(),'Current complete failure download is byte-identical, no truncation.')
need('Root_audit_JSON_literal',canonical(load(P/'exact-evidence-admission.json'))==canonical(ra),'Published audit full object equal; JSON formatting may differ.')
need('peer_JSON_literal',canonical(load(P/'exact-evidence-peer-review.json'))==canonical(peer),'Published peer full object equal; raw original remains in archive.')
need('scope_current_no_proof',all(summary[k]is False for k in ['Model_permission','RL_training','new_target_theorem','mathematical_proof_accepted','schema_inventory_admission','goal_complete'])and summary['Native_calls']==summary['search_calls']==0,'No current proof/search/Model authority.')
need('legacy_scope_citation','https://docs.python.org/3.12/library/exceptions.html#StopIteration'in page.links and 'https://peps.python.org/pep-0479/'in page.links and summary['legacy_StopIteration_identity_tested']is False,'Official language references and finite old71 limitation explicit.')
need('current_failure_claims',all(t in visible for t in ['no capture committed','second literal-reconciliation pass','integer-conversion checkpoint','will not be retried','no physical forest or complete independent comparison returned']),'Current counter/traceback/zero-data scope accurate.')
need('no_causal_or_integrated_gain_claim',all(t in visible for t in ['not a measured reduction in live search memory','These four earlier measurements do not establish a causal speedup','No causal speedup or RAM reduction','performs no RL training','no production memory or proof-search advantage claim']),'Changed profiles and negative outcomes cannot support pipeline/geometric/RL benefit.')
need('profile_clock_scope',all(t in visible for t in ['Runner interpreter startup and the outer observer prelude precede this gated epoch','failure-only and grants no extra positive work','The measurement excludes the outer observer/controller','No Native process exists in this specialized profile']),'Worker-only peak and exact Source-entry epoch exclusions explicit.')
need('full_expanded_output_guard_preserved',all(t in visible for t in ['Compact bytes cannot rescue that same unchanged guard','new finite representation allowance must be explicit and equal for both methods','cannot be called success under the old full-JSON serialization guard']),'Storage profile qualification never bypasses old full expansion guard.')
need('safe_static_viewer','packetBody\').textContent=JSON.stringify' in html and 'o.textContent=r.label' in html and 'innerHTML'not in html,'Static Source read only; retained metadata is text, no proof evaluation or HTML packet execution.')
need('main_unique_ids',len(page.ids)==len(set(page.ids)),'All current report IDs unique.')
need('no_invalid_C0',not any(ord(c)<32 and c not in '\n\r\t'for c in html),'No accidental backspace/formfeed/etc from unescaped LaTeX.')
need('MathJax_retained','https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js'in page.assets and not page.forbidden and visible.count('\\(')==visible.count('\\)') and visible.count('\\[')==visible.count('\\]'),'Existing renderer; balanced visible LaTeX delimiters, no HTML sup/sub substitution. No browser/renderer run.')
# Exact reader-owned-section and old full snapshot pins.
priorpins=load(R/'prior-publication-pin-index.json')
for q in priorpins['files']:need('prior_snapshot_'+q['name'],d(R/'prior-publication'/q['name'])['sha256']==q['sha256']and d(R/'prior-publication'/q['name'])['bytes']==q['bytes'],'Frozen previous publication preimage retained.')
reader=(P/'reader.html').read_text();priorreader=(R/'prior-publication/reader.html').read_text();rx=r'<section id="exact-evidence">[\s\S]*?</section>'
need('reader_owned_section_only',len(re.findall(rx,reader))==len(re.findall(rx,priorreader))==1 and re.sub(rx,'',reader,count=1)==re.sub(rx,'',priorreader,count=1),'Every byte outside one task-owned section identical.')
owned=re.search(rx,reader).group(0);need('reader_current_negative_lead','remains unqualified'in owned and '\\(0\\)'in owned and '\\(127\\)'in owned and '69.396'in owned and '613.75'in owned,'Current reader lead does not inherit the old positive state.')
for href in page.links+page.assets:
 u=urlsplit(href)
 if u.scheme:continue
 target=(P/unquote(u.path)).resolve()if u.path else P/'exact-evidence.html'
 need('local_link_'+href,target.is_file(),'Current local target exists; external HTTP/Pages checks deferred to Root.')
 if u.fragment and target.suffix=='.html':
  targetpage=Page();targetpage.feed(target.read_text());need('local_anchor_'+href,unquote(u.fragment)in targetpage.ids,'Actual HTML ID present.')
need('archive_pin',m['archive']==next(q for q in c['files']if q['path'].endswith('exact-evidence-archive.zip'))==d(P/'exact-evidence-archive.zip'),'Frozen whole ZIP raw pin.')
for q in m['published']:need('manifest_published_'+Path(q['path']).name,d(Path(q['path']))==q,'Manifest published-object SHA exact.')
need('manifest569_raw_members',len(m['files'])==569 and len({q['archive_name']for q in m['files']})==569,'Full listed raw members, no duplicate or filtered subset.')
archive_results=[]
with zipfile.ZipFile(P/'exact-evidence-archive.zip')as z:
 names=z.namelist();need('archive570_members',len(names)==len(set(names))==570 and set(names)=={q['archive_name']for q in m['files']}|{'README.txt'},'569 manifest members plus oneREADME, no hidden/missing entries.')
 need('no_opaque_Native_payload_files',not any(n.endswith(('.gz','.pyc'))for n in names)and all(n.rsplit('/',1)[-1]in ['stdout.bin','stderr.bin']for n in names if n.endswith('.bin')),'No Native gzip decoding; binary members are ordinary logs only.')
 for q in m['files']:
  h=hashlib.sha256();size=0;equal=True
  with z.open(q['archive_name'])as f,Path(q['path']).open('rb')as original:
   while True:
    b=f.read(1048576);raw=original.read(1048576)
    if b!=raw:equal=False
    if not b and not raw:break
    h.update(b);size+=len(b)
  need('raw_ZIP_member_'+q['archive_name'],equal and size==q['bytes']and h.hexdigest()==q['sha256'],'Complete packaging decompression compared bytewise to full current original; no evidence codec/inverse or scientific interpretation.')
  archive_results.append(dict(archive_name=q['archive_name'],path=q['path'],bytes=size,sha256=h.hexdigest(),whole_raw_equal=equal))
 readme=z.read('README.txt').decode();need('README_scope','No integration, proof/search/RL or Model authority'in readme and 'fresh reproduction requires a new reviewed bounded once-only subject'in readme,'Whole README text scopes architecture rather than current success.')
listed={q['path']for q in m['files']}
for q in plan['inputs']:need('archive_whole_input_'+q['id'],q['input']['path']in listed,'Full original file, not a sample or failed table.')
for role,q in packet['sources'].items():need('archive_current_Source_'+role,q['path']in listed,'Complete10 runtime Source closure retained.')
for rel in ['actual-v1/CONSUMED.json','actual-v1/worker-failure.json','actual-v1/runner-receipt.json','actual-v1/stdout.bin','actual-v1/stderr.bin','plan-authorized-v1.json','authorization-v1.json','plan-authorized-v1-terminal-observation/CONSUMED.json','plan-authorized-v1-terminal-observation/terminal.json']:
 need('archive_current_'+rel,str(R/rel)in listed,'Full once plan/grant/current negative history retained.')
old_actuals=[Path('/private/tmp/gcts-exact-evidence-ROOT-20261019/actual-v4'),Path('/private/tmp/gcts-exact-evidence-ROOT-20261019/actual-v5'),Path('/private/tmp/gcts-fragment-inverse-ROOT-20261019/actual-v3'),Path('/private/tmp/gcts-fragment-inverse-ROOT-20261019/actual-v4')]
for a in old_actuals:
 for path in a.iterdir():
  if path.is_file():need('archive_history_'+str(path),str(path)in listed,'Entire existing earlier actual file retained, including failures and successful table/result/header.')
# The exact report/review artifact intentionally remains outside its own archive.
need('own_publication_receipt_not_in_archive',str(O/'typed-publication-saved-review-v1.json')not in listed,'No self-reference cycle; existing saved-data review is archived instead.')
status=subprocess.run(['git','status','--porcelain','-z'],cwd=PUB,capture_output=True,check=True).stdout.decode().split('\0');changed=[v[3:]for v in status if v]
expectedchanged=sorted(str(Path(q['path']).relative_to(PUB))for q in c['files'])
need('task_only_worktree_changes',sorted(changed)==expectedchanged,'Read-only git status lists exactly9 candidate files; master overview not changed.')
manual=[dict(id='CURRENT_VS_HISTORICAL',verdict='Current headline/reader/summary and fifth trial state UNKNOWN,0 full captures/independent inputs,0 mainforest and127 diagnostics. The earlier3-file/71 case, data-size table/chart and old4 outcomes are explicitly historical. No current successful packet/table is fabricated.'),dict(id='DIAGRAM_SCOPE',verdict='New three-root arena diagram is labeled reviewed architecture and not a measured live-search-memory reduction. Older4node/5ref/10occurrence/61byte/3hit diagram remains a returned earlier diagnostic, not Wang tiles or a learned marking.'),dict(id='SOURCE_EXCEPTION_LIMITATION',verdict='Official Python/PEP479 references support the rawSource legacy generator scope gap. The page preserves measured old finite results, limits broad all-exception language, and describes selected new manual callback cases without claiming every late/fallback path.'),dict(id='COST_AND_AUTHORITY',verdict='Weighted200m attempted arena units and new forest30m units, original global gates, wholeworker lifetimes and excluded prelude/parent RAM are disclosed. Time/RSS of this failed trial are observations, not resource admission or causal gain. No theorem, schema/Model permission, integration, GCTS/RL benefit or oldfailure rescue.'),dict(id='RELEASE_BOUNDARY',verdict='All9 concrete files/current local references and raw archive are static-reviewed. Root still owns exact task-only commit/deploy, HTTP/current-object hashes and live browser/MathJax validation. No public file edited by reviewer, no actual or component rerun.')]
audit=dict(schema='incremental-arena-publication-saved-audit-v1',saved_data_only=True,scientific_calls=0,module_evaluations=0,codec_calls=0,inverse_calls=0,fixture_calls=0,renderer_calls=0,JavaScript_execution=0,Native_opaque_decodes=0,publication_candidate=d(R/'publication-candidate-v1.json'),files=c['files'],viewer_entries=len(embedded),archive_members=570,manifest_raw_members=569,archive_raw_total_bytes=sum(q['bytes']for q in m['files']),archive_member_results=archive_results,checks=checks,checks_passed=len(checks),mismatch_count=0,manual_claim_review=manual,git_changed_files=changed)
out=O/'publication-saved-audit-v1.json';assert not out.exists();out.write_text(json.dumps(audit,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
review=dict(schema='incremental-arena-publication-saved-review-v1',publication_review_passed=True,human_report_review_passed=True,saved_data_only=True,scientific_calls=0,module_evaluations=0,codec_calls=0,inverse_calls=0,fixture_calls=0,renderer_calls=0,JavaScript_execution=0,Native_opaque_decodes=0,scientific_acceptance=False,actual_execution_authorized=False,author_identity='/root',reviewer_identity='/root/conventional_control_review',publication_candidate=d(R/'publication-candidate-v1.json'),publication_files=c['files'],Root_publication_audit=d(R/'ROOT-publication-saved-audit-v1.json'),prior_saved_data_review=d(O/'typed-arena-qualification-saved-review-v1.json'),audit=d(out),checks_passed=len(checks),mismatch_count=0,findings=[],viewer_entries=219,archive_members=570,raw_manifest_members=569,manual_claim_review=manual,math_scope='Visible numerical counts, units, clocks, boundaries and historical table/chart values use balanced established LaTeX/MathJax; no invalidC0 or HTMLsup/sub construction. Static/Source review only, no rendering execution or mathematical proof evaluation.',ancestry='Control authored Source/design/plans/delta and retained-data reviews of this protocol, and historical unrelated control/outer code. Root authored report and ran trial; Library authored arena+33fixtures. This independently checks Root presentation/package against retained evidence, not own Source certification or mathematical kernel soundness. Same Control Source/plans role identity remains explicit.',limitations=['ZIP decompression was ordinary packaging only and every569 member compared whole-byte to its original. No evidence table inverse, scientific/Native/Model/kernel/search/fixture call or opaqueNative gzip decoding occurred.','The mainworker failure has no complete capture/forest/result/header; archived Source/stat counters do not recover a whole input or prove a theorem. Current flags remain false.','The published peer JSON is a whole object-equivalent serialization of the original saved-data receipt; its original exact raw receipt is also archived. No claim that formatting bytes are identical was substituted.','No deployment/HTTP/browser/MathJax execution was performed here. Root must separately verify the exact9 task-only live objects and retained reader section after publishing.','This review receipt remains outside the frozen archive to avoid a self-hash cycle; no report/archive mutation is required by this receipt.'])
out=O/'typed-publication-saved-review-v1.json';assert not out.exists();out.write_text(json.dumps(review,ensure_ascii=False,sort_keys=True,indent=2)+'\n');print(json.dumps(d(out)));print('checks',len(checks));print(json.dumps(d(O/'publication-saved-audit-v1.json')))
