"""Invocation-local exact evidence forest. Source-only; no proof authority.

Exclusive ordinary-Python ownership, not a hostile-code sandbox. No scientific
imports. All logical streams are canonical JSON BODY only; caller adds one LF.
"""
import json
import math

VERSION='exact-evidence-arena-v1'
WIRE_SCHEMA='exact-evidence-forest-v1'
EXECUTION_PROFILE='invocation-total-transactional-arena-v1'
LIMIT_KEYS=frozenset(('cache_bytes','cache_entries','chunk_bytes','depth',
    'documents_expanded_bytes','edges','fragment_bytes','integer_digits',
    'materialized_bytes','materialized_occurrences','nodes','root_expanded_bytes',
    'roots','scalar_bytes','wire_bytes','work'))
_TOKEN=object()
_END=object()


class ArenaDataError(ValueError):pass
class LifecycleError(RuntimeError):
    def __init__(self,reason,*,_owner=None):
        self._owner=_owner;super().__init__(reason)
class ReentrancyError(RuntimeError):
    def __init__(self,reason,*,_owner=None):
        self._owner=_owner;super().__init__(reason)
class ArenaLimit(RuntimeError):
    def __init__(self,reason,counts=None,*,_owner=None):
        self.reason=reason;self.counts=dict(counts or {});self._owner=_owner
        super().__init__(reason)
def is_own_limit(error):return type(error) is ArenaLimit and error._owner is _TOKEN
def is_own_lifecycle(error):return type(error) is LifecycleError and error._owner is _TOKEN
def is_own_reentrancy(error):return type(error) is ReentrancyError and error._owner is _TOKEN


class _Immutable:
    __slots__=()
    def __setattr__(self,name,value):raise AttributeError('immutable evidence object')
    def __delattr__(self,name):raise AttributeError('immutable evidence object')

class _Missing(_Immutable):
    __slots__=()
    kind='missing'
    def __repr__(self):return 'MISSING'
MISSING=_Missing()

class RootHandle(_Immutable):
    __slots__=('_owner','_index','_label')
    def __init__(self,owner,index,label,*,_token=None):
        if _token is not _TOKEN:raise TypeError('Arena-created root handle required')
        object.__setattr__(self,'_owner',owner);object.__setattr__(self,'_index',index)
        object.__setattr__(self,'_label',label)
    @property
    def label(self):return self._label  # Historical immutable metadata, not authority.

class Sealed(_Immutable):
    __slots__=('_owner','_state')
    def __init__(self,owner,state,*,_token=None):
        if _token is not _TOKEN:raise TypeError('Arena-created sealed forest required')
        object.__setattr__(self,'_owner',owner);object.__setattr__(self,'_state',state)

class _State:
    """Never mutated after publication; all fields prepared before one assignment."""
    __slots__=('nodes','summaries','buckets','roots','labels','fragments','edges',
               'cache_bytes','documents','logical_bytes','wire_bytes')
    def __init__(self,nodes=(),summaries=(),buckets=None,roots=(),labels=None,
                 fragments=None,edges=0,cache_bytes=0,documents=(),logical_bytes=0,wire_bytes=0):
        self.nodes=nodes;self.summaries=summaries;self.buckets={} if buckets is None else buckets
        self.roots=roots;self.labels={} if labels is None else labels
        self.fragments={} if fragments is None else fragments;self.edges=edges
        self.cache_bytes=cache_bytes;self.documents=documents
        self.logical_bytes=logical_bytes;self.wire_bytes=wire_bytes

class _Transaction:
    __slots__=('nodes','summaries','buckets','roots','labels','fragments','edges','cache_bytes')
    def __init__(self,a):
        s=a._state
        # Full next-state bookkeeping copy is deliberately charged and measured.
        a._step('bookkeeping_items',2*len(s.nodes)+len(s.buckets)+2*len(s.roots)+len(s.fragments)+1)
        self.nodes=list(s.nodes);self.summaries=list(s.summaries);self.buckets=dict(s.buckets)
        self.roots=list(s.roots);self.labels=dict(s.labels);self.fragments=dict(s.fragments)
        self.edges=s.edges;self.cache_bytes=s.cache_bytes
    def prepared(self):
        return _State(tuple(self.nodes),tuple(self.summaries),self.buckets,tuple(self.roots),
                      self.labels,self.fragments,self.edges,self.cache_bytes)


class View(_Immutable):
    __slots__=('_owner','_state','_index')
    def __init__(self,a,s,i,*,_token=None):
        if _token is not _TOKEN:raise TypeError('Arena-created immutable view required')
        object.__setattr__(self,'_owner',a);object.__setattr__(self,'_state',s);object.__setattr__(self,'_index',i)
    def _read(self):
        self._owner._read();return self._state.nodes[self._index]
    @property
    def kind(self):return self._read()[0]
    @property
    def node_id(self):self._read();return self._index
    @property
    def payload(self):
        n=self._read();return None if n[0]=='null' else n[1]
    @property
    def keys(self):
        n=self._read()
        if n[0]!='object':return ()
        self._owner._step('view_key_copies',len(n[1]));result=tuple(k for k,i in n[1])
        self._owner._finish();return result
    @property
    def length(self):
        n=self._read();return len(n[1]) if n[0] in ('array','object') else 0
    @property
    def expanded_bytes(self):self._read();return self._state.summaries[self._index][0]
    @property
    def occurrences(self):self._read();return self._state.summaries[self._index][1]
    @property
    def depth(self):self._read();return self._state.summaries[self._index][2]


class _Cursor:
    """Non-generator token machine: delegated StopIteration is not rewritten."""
    __slots__=('a','s','stack','occurrences')
    def __init__(self,a,s,i):self.a=a;self.s=s;self.stack=[('value',i,0)];self.occurrences=0
    def token(self):
        a=self.a
        if not self.stack:return _END
        a._step('stream_frames');phase,i,pos=self.stack.pop();n=self.s.nodes[i];tag=n[0]
        if phase=='value':
            fragment=self.s.fragments.get(i)
            if fragment is not None:
                self.occurrences+=self.s.summaries[i][1];a._observe('fragment_hits',1)
                return fragment
            self.occurrences+=1
            if tag=='array':self.stack.append(('array',i,0));return b'['
            if tag=='object':self.stack.append(('object',i,0));return b'{'
            return a._scalar(n)
        if phase=='array':
            if pos==len(n[1]):return b']'
            self.stack.append(('array',i,pos+1));self.stack.append(('value',n[1][pos],0))
            return b',' if pos else b''
        if phase=='object':
            if pos==len(n[1]):return b'}'
            key,child=n[1][pos]
            self.stack.append(('object',i,pos+1));self.stack.append(('value',child,0))
            return (b',' if pos else b'')+a._string_bytes(key)+b':'
        raise ArenaDataError('internal cursor phase')

class _Stream:
    __slots__=('a','s','i','cursor','pending','token','offset','size','expected',
               '_completed','_closed','_failed')
    def __init__(self,a,s,i):
        self.a=a;self.s=s;self.i=i;self.cursor=_Cursor(a,s,i);self.pending=bytearray()
        self.token=b'';self.offset=0;self.size=0;self.expected=s.summaries[i]
        self._completed=False;self._closed=False;self._failed=False
    @property
    def completed(self):return self._completed  # Passive observation only.
    def __iter__(self):return self
    def close(self):
        # No callbacks, no completion authority and no release of arena state.
        if self.a._in_callback:raise ReentrancyError('callback cannot close a stream',_owner=_TOKEN)
        self._closed=True;self.cursor.stack.clear();self.pending.clear();self.token=b''
    def _pull(self):
        a=self.a;a._read()
        while True:
            if self.offset<len(self.token):
                take=min(a._limits['chunk_bytes']-len(self.pending),len(self.token)-self.offset)
                a._step('copy_chunks');a._observe('copied_bytes',take)
                self.pending.extend(self.token[self.offset:self.offset+take]);self.offset+=take
                if len(self.pending)==a._limits['chunk_bytes']:
                    raw=bytes(self.pending);self.pending.clear();a._alive();return raw
            else:
                token=self.cursor.token()
                if token is _END:
                    if self.size!=self.expected[0] or self.cursor.occurrences!=self.expected[1]:
                        raise ArenaDataError('complete stream size/occurrence disagreement')
                    if self.pending:
                        raw=bytes(self.pending);self.pending.clear();a._alive();return raw
                    a._finish();return _END
                a._step('emitted_tokens');self.size+=len(token)
                a._bound('root_expanded_bytes',self.size);a._observe('emitted_bytes',len(token))
                self.token=token;self.offset=0
    def __next__(self):
        self.a._public()
        if self._closed or self._failed:raise LifecycleError('closed/failed stream',_owner=_TOKEN)
        if self._completed:raise StopIteration
        try:
            value=self._pull()
            if value is _END:self.a._observe('completed_streams',1)
        except BaseException:
            self._failed=True;raise
        if value is _END:
            self._completed=True;raise StopIteration
        self.a._alive();return value


class Arena:
    __slots__=('_state','_lifecycle','_busy','_in_callback','_limits','_counts',
               '_until_check','_check','_guard','_source_epoch','_semantic_epoch')
    def __init__(self,*,source_epoch,semantic_epoch,check,source_guard,limits):
        if not callable(check) or not callable(source_guard):raise TypeError('current charged callbacks required')
        if type(limits) is not dict or set(limits)!=LIMIT_KEYS:raise ArenaDataError('all exact arena limit keys required')
        if any(type(v) is not int or (v<0 if k in ('cache_bytes','cache_entries') else v<=0) for k,v in limits.items()):
            raise ArenaDataError('strict finite integer arena limits')
        if limits['chunk_bytes']>65536:raise ArenaDataError('chunk_bytes at most65536')
        self._limits=dict(limits);self._counts={};self._until_check=0
        self._check=check;self._guard=source_guard;self._in_callback=False;self._busy=False
        self._lifecycle='ACTIVE';self._state=_State()
        self._source_epoch=source_epoch;self._semantic_epoch=semantic_epoch
        self._string_size(source_epoch);self._string_size(semantic_epoch);self._finish()

    def _public(self):
        if self._in_callback:raise ReentrancyError('only passive statistics allowed in callbacks',_owner=_TOKEN)
        self._alive()
    def _alive(self):
        if self._lifecycle=='ABORTED':raise LifecycleError('aborted arena',_owner=_TOKEN)
    def _invoke(self,callback):
        if self._in_callback:raise ReentrancyError('nested callback',_owner=_TOKEN)
        self._in_callback=True
        try:callback()
        finally:self._in_callback=False
    def _observe(self,kind,amount):self._counts[kind]=self._counts.get(kind,0)+amount
    def _step(self,kind='work',amount=1):
        # Attempted work is monotone, including failed transactions/callbacks.
        self._observe('work',amount)
        if kind!='work':self._observe(kind,amount)
        left=amount;remaining=self._until_check
        while remaining==0 or left>remaining:
            left-=remaining;self._invoke(self._check);remaining=1024
        self._until_check=remaining-left
        if self._counts['work']>self._limits['work']:self._stop('work')
    def _stop(self,reason):raise ArenaLimit(reason,self._counts,_owner=_TOKEN)
    def _bound(self,key,value):
        self._step('bound_checks')
        if value>self._limits[key]:self._stop(key)
    def _finish(self):
        self._public();self._invoke(self._guard);self._invoke(self._check);self._alive()
    def _read(self):self._public();self._step('read_operations');self._finish()
    def _start_write(self):
        self._public()
        if self._busy:raise ReentrancyError('writer transaction already active',_owner=_TOKEN)
        if self._lifecycle!='ACTIVE' or self._state.documents:raise LifecycleError('sealed arena is not writable',_owner=_TOKEN)
        self._busy=True

    def _string_size(self,value):
        if type(value) is not str:raise ArenaDataError('exact Unicode scalar string required')
        size=2
        for start in range(0,len(value),4096):
            part=value[start:start+4096];self._step('string_characters',len(part))
            for c in part:
                n=ord(c)
                if 0xD800<=n<=0xDFFF:raise ArenaDataError('lone Unicode surrogate')
                if c in ('"','\\','\b','\f','\n','\r','\t'):size+=2
                elif n<32:size+=6
                elif n<128:size+=1
                elif n<2048:size+=2
                elif n<65536:size+=3
                else:size+=4
            self._bound('scalar_bytes',size)
        self._bound('scalar_bytes',size);return size
    def _string_bytes(self,value):
        size=self._string_size(value);self._step('string_encodes')
        raw=json.dumps(value,ensure_ascii=False,allow_nan=False,separators=(',',':')).encode('utf8')
        if len(raw)!=size:raise ArenaDataError('canonical string size mismatch')
        return raw
    def _integer(self,value):
        if value.bit_length()>(3322*self._limits['integer_digits']+999)//1000:self._stop('integer_digits')
        self._step('integer_conversion')
        try:lex=str(value)
        except ValueError as error:raise ArenaDataError('interpreter integer conversion bound') from error
        self._valid_int(lex);return lex
    def _valid_int(self,lex):
        if type(lex) is not str or not lex:raise ArenaDataError('integer lexeme')
        digits=lex[1:] if lex[0]=='-' else lex
        self._bound('integer_digits',len(digits));self._step('integer_digits_scanned',len(digits))
        if not digits or any(c<'0' or c>'9' for c in digits) or (len(digits)>1 and digits[0]=='0') or lex=='-0':
            raise ArenaDataError('noncanonical integer lexeme')
    def _float(self,value):
        if type(value) is not float or not math.isfinite(value):raise ArenaDataError('finite builtin float')
        self._step('float_conversion');return json.dumps(value,allow_nan=False,separators=(',',':'))
    def _scalar(self,n):
        if n[0]=='null':return b'null'
        if n[0]=='bool':return b'true' if n[1] else b'false'
        if n[0] in ('int','float'):return n[1].encode('ascii')
        return self._string_bytes(n[1])
    def _refs(self,n):
        if n[0]=='array':return n[1]
        if n[0]=='object':return tuple(i for k,i in n[1])
        return ()
    def _summary(self,n,summaries,index):
        self._step('summary_nodes');tag=n[0];refs=self._refs(n)
        if tag=='null':size=4
        elif tag=='bool':size=4 if n[1] else 5
        elif tag=='str':size=self._string_size(n[1])
        elif tag in ('int','float'):size=len(n[1]);self._bound('scalar_bytes',size)
        elif tag in ('array','object'):
            size=2+max(0,len(refs)-1)
            if tag=='object':
                for key,child in n[1]:size+=self._string_size(key)+1
        else:raise ArenaDataError('unknown node kind')
        occ=1;depth=0
        for child in refs:
            self._step('summary_edges')
            if type(child) is not int or not 0<=child<index:raise ArenaDataError('strict prior integer reference')
            b,c,d=summaries[child];size+=b;occ+=c;depth=max(depth,d+1)
            self._bound('root_expanded_bytes',size);self._bound('depth',depth)
        if tag not in ('array','object'):self._bound('scalar_bytes',size)
        self._bound('root_expanded_bytes',size);self._bound('depth',depth)
        return size,occ,depth
    def _cache(self,t,i,n,summary):
        if summary[0]>self._limits['fragment_bytes'] or len(t.fragments)>=self._limits['cache_entries'] or t.cache_bytes+summary[0]>self._limits['cache_bytes']:return
        refs=self._refs(n)
        self._step('fragment_reference_checks',len(refs))
        if any(c not in t.fragments for c in refs):return
        self._step('fragment_builds')
        if n[0]=='array':raw=b'['+b','.join(t.fragments[c] for c in refs)+b']'
        elif n[0]=='object':
            parts=[]
            for k,c in n[1]:parts.append(self._string_bytes(k)+b':'+t.fragments[c])
            raw=b'{'+b','.join(parts)+b'}'
        else:raw=self._scalar(n)
        if len(raw)!=summary[0]:raise ArenaDataError('fragment exact byte mismatch')
        self._observe('fragment_built_bytes',len(raw));t.fragments[i]=raw;t.cache_bytes+=len(raw)
    def _intern(self,t,n):
        self._step('intern_lookups');key=hash(n)
        for i in t.buckets.get(key,()):
            self._step('full_node_comparisons')
            if t.nodes[i]==n:return i
        self._bound('nodes',len(t.nodes)+1);refs=self._refs(n)
        self._bound('edges',t.edges+len(refs));i=len(t.nodes)
        summary=self._summary(n,t.summaries,i)
        t.nodes.append(n);t.summaries.append(summary);t.edges+=len(refs)
        t.buckets[key]=t.buckets.get(key,())+(i,);self._cache(t,i,n,summary);return i
    def _capture_value(self,value,t):
        active=set();frames=[dict(value=value,phase=0,depth=0)];root=None
        def done(i):
            nonlocal root
            frames.pop()
            if frames:frames[-1]['refs'].append(i)
            else:root=i
        while frames:
            self._step('capture_frames');f=frames[-1]
            if not f['phase']:
                v=f['value'];kind=type(v);self._bound('depth',f['depth'])
                if v is None:done(self._intern(t,('null',)));continue
                if kind is bool:done(self._intern(t,('bool',v)));continue
                if kind is int:done(self._intern(t,('int',self._integer(v))));continue
                if kind is float:done(self._intern(t,('float',self._float(v))));continue
                if kind is str:self._string_size(v);done(self._intern(t,('str',v)));continue
                if kind not in (list,dict):raise ArenaDataError('ordinary builtin JSON only; handles are not values')
                self._bound('root_expanded_bytes',len(v)+2)
                identity=id(v)
                if identity in active:raise ArenaDataError('cyclic ordinary container')
                active.add(identity);keys=None
                if kind is dict:
                    keys=list(v)
                    for k in keys:self._string_size(k)
                    self._step('key_sort');keys.sort()
                f.update(phase=1,keys=keys,length=len(v),pos=0,refs=[],identity=identity)
            else:
                v=f['value'];pos=f['pos']
                if len(v)!=f['length']:raise ArenaDataError('input mutated during capture')
                if pos<f['length']:
                    if f['keys'] is None:child=v[pos]
                    else:
                        key=f['keys'][pos]
                        if key not in v:raise ArenaDataError('input key changed during capture')
                        child=v[key]
                    f['pos']+=1;frames.append(dict(value=child,phase=0,depth=f['depth']+1))
                else:
                    n=('array',tuple(f['refs'])) if f['keys'] is None else ('object',tuple(zip(f['keys'],f['refs'])))
                    active.remove(f['identity']);done(self._intern(t,n))
        return root
    def _label(self,label,t):
        self._string_size(label)
        if not label or label in t.labels:raise ArenaDataError('unique nonempty root label')
        self._bound('roots',len(t.roots)+1)
    def _commit_root(self,t,i,label):
        t.roots.append((label,i));t.labels[label]=i
        self._step('publication_bookkeeping',2*len(t.nodes)+len(t.roots))
        prepared=t.prepared();handle=RootHandle(self,i,label,_token=_TOKEN)
        self._finish()  # Every fallible operation precedes the one publication.
        self._state=prepared
        return handle
    def capture(self,value,*,label):
        self._start_write()
        try:
            self._finish();t=_Transaction(self);self._label(label,t)
            i=self._capture_value(value,t)
            # A second complete typed reconstruction is literal reconciliation,
            # not a digest or a caller boolean. Extra provisional nodes abort.
            if self._capture_value(value,t)!=i:raise ArenaDataError('whole input changed during capture')
            return self._commit_root(t,i,label)
        finally:self._busy=False
    def _handle(self,h):
        if type(h) is not RootHandle or h._owner is not self or self._state.labels.get(h._label)!=h._index:
            raise ArenaDataError('foreign/stale/provisional handle')
        return h._index
    def compose(self,kind,children,*,label):
        self._start_write()
        try:
            self._finish();t=_Transaction(self);self._label(label,t)
            if type(children) is not list:raise ArenaDataError('compose requires ordinary explicit child list')
            if kind=='array':
                refs=[]
                for h in children:self._step('compose_children');refs.append(self._handle(h))
                n=('array',tuple(refs))
                frozen=tuple(children)
            elif kind=='object':
                pairs=[];frozen=[];seen=set()
                for p in children:
                    self._step('compose_children')
                    if type(p) not in (list,tuple) or len(p)!=2:raise ArenaDataError('compose object pair')
                    k,h=p;self._string_size(k)
                    if k in seen:raise ArenaDataError('duplicate compose object key')
                    seen.add(k);pairs.append((k,self._handle(h)));frozen.append((k,h))
                self._step('compose_sort');pairs.sort();n=('object',tuple(pairs));frozen=tuple(frozen)
            else:raise ArenaDataError('compose array/object only')
            i=self._intern(t,n)
            self._step('compose_reconciliation',len(frozen)+1)
            current=tuple(children) if kind=='array' else tuple(tuple(p) for p in children)
            if current!=frozen:raise ArenaDataError('compose input changed')
            return self._commit_root(t,i,label)
        finally:self._busy=False
    def _resolve(self,h,path):
        self._public();self._step('path_resolutions');i=self._handle(h);s=self._state
        if type(path) not in (list,tuple):raise ArenaDataError('explicit path sequence')
        path=tuple(path)
        for p in path:
            if type(p) not in (str,int):raise ArenaDataError('exact path key/index excluding bool')
        for p in path:
            self._step('path_components');n=s.nodes[i]
            if n[0]=='array':
                if type(p) is not int or p<0:raise ArenaDataError('nonnegative exact array index')
                if p>=len(n[1]):return s,None
                i=n[1][p]
            elif n[0]=='object':
                self._string_size(p);found=None
                for k,c in n[1]:
                    self._step('path_object_keys')
                    if k==p:found=c;break
                if found is None:return s,None
                i=found
            else:return s,None
        return s,i
    def view(self,handle,path=()):
        s,i=self._resolve(handle,path);self._finish()
        return MISSING if i is None else View(self,s,i,_token=_TOKEN)
    def iter_canonical(self,handle,path=()):
        # Eager snapshot BEFORE returning a non-generator iterator.
        s,i=self._resolve(handle,path)
        if i is None:raise ArenaDataError('missing value has no canonical document')
        result=_Stream(self,s,i);self._finish();return result
    def materialize(self,handle,path=(),small_limits=None):
        s,i=self._resolve(handle,path)
        if i is None:raise ArenaDataError('missing value cannot materialize')
        limits=dict(bytes=self._limits['materialized_bytes'],occurrences=self._limits['materialized_occurrences'])
        if small_limits is not None:
            if type(small_limits) is not dict or set(small_limits)!=set(limits):raise ArenaDataError('exact small limits')
            if any(type(v) is not int or v<=0 or v>limits[k] for k,v in small_limits.items()):raise ArenaDataError('small limits may only tighten')
            limits=dict(small_limits)
        size,occ,depth=s.summaries[i]
        if size>limits['bytes'] or occ>limits['occurrences']:self._stop('small_materialization')
        holder=[None];stack=[(i,holder,0)];count=0
        while stack:
            self._step('materialized_values');j,parent,key=stack.pop();n=s.nodes[j];count+=1
            if n[0]=='array':
                value=[None]*len(n[1]);parent[key]=value
                for pos in range(len(n[1])-1,-1,-1):stack.append((n[1][pos],value,pos))
            elif n[0]=='object':
                value={k:None for k,c in n[1]};parent[key]=value
                for k,c in reversed(n[1]):stack.append((c,value,k))
            elif n[0]=='null':parent[key]=None
            elif n[0] in ('bool','str'):parent[key]=n[1]
            elif n[0]=='int':
                try:parent[key]=int(n[1])
                except ValueError as error:raise ArenaDataError('materialized integer conversion') from error
            else:parent[key]=float(n[1])
        if count!=occ:raise ArenaDataError('fresh occurrence count mismatch')
        self._finish();return holder[0]
    def _full_validate(self,s):
        self._string_size(self._source_epoch);self._string_size(self._semantic_epoch)
        self._bound('roots',len(s.roots));labels={}
        for label,i in s.roots:
            self._step('validation_roots');self._string_size(label)
            if not label or label in labels or type(i) is not int or not 0<=i<len(s.nodes):
                raise ArenaDataError('complete unique root catalogue')
            labels[label]=i
        if labels!=s.labels or len(s.nodes)!=len(s.summaries):raise ArenaDataError('complete root/summary ledger')
        summaries=[];buckets={};edges=0
        for i,n in enumerate(s.nodes):
            self._step('full_validation_nodes')
            if type(n) is not tuple or not n:raise ArenaDataError('immutable typed node')
            tag=n[0]
            if type(tag) is not str or len(n)!=(1 if tag=='null' else 2):raise ArenaDataError('exact node arity')
            if tag=='bool' and type(n[1]) is not bool:raise ArenaDataError('bool node')
            elif tag=='int':self._valid_int(n[1])
            elif tag=='float':
                if type(n[1]) is not str or len(n[1])>64:raise ArenaDataError('float lexeme')
                try:number=float(n[1])
                except (ValueError,OverflowError) as error:raise ArenaDataError('float parse') from error
                if self._float(number)!=n[1]:raise ArenaDataError('canonical finite float')
            elif tag=='str':self._string_size(n[1])
            elif tag in ('array','object'):
                if type(n[1]) is not tuple:raise ArenaDataError('immutable ordered references')
                if tag=='object':
                    previous=None
                    for p in n[1]:
                        self._step('validation_pairs')
                        if type(p) is not tuple or len(p)!=2:raise ArenaDataError('object pair')
                        self._string_size(p[0])
                        if previous is not None and p[0]<=previous:raise ArenaDataError('sorted unique exact keys')
                        previous=p[0]
            elif tag not in ('null','bool'):raise ArenaDataError('node tag')
            key=hash(n)
            for j in buckets.get(key,()):
                self._step('validation_equalities')
                if s.nodes[j]==n:raise ArenaDataError('duplicate full typed node')
            buckets[key]=buckets.get(key,())+(i,)
            summary=self._summary(n,summaries,i);summaries.append(summary)
            if summary!=s.summaries[i]:raise ArenaDataError('eager summary mismatch')
            edges+=len(self._refs(n));self._bound('edges',edges)
        self._bound('nodes',len(s.nodes))
        if edges!=s.edges:raise ArenaDataError('edge ledger mismatch')
    def _wire(self,s):
        nodes=[]
        for n in s.nodes:
            self._step('wire_nodes')
            self._step('wire_reference_copies',len(self._refs(n)))
            if n[0]=='null':nodes.append(['null'])
            elif n[0]=='array':nodes.append(['array',list(n[1])])
            elif n[0]=='object':nodes.append(['object',[[k,c] for k,c in n[1]]])
            else:nodes.append([n[0],n[1]])
        return dict(schema=WIRE_SCHEMA,version=VERSION,source_epoch=self._source_epoch,
            semantic_epoch=self._semantic_epoch,roots=[[k,i] for k,i in s.roots],
            documents=list(s.documents),nodes=nodes)
    def _wire_size(self,wire):
        total=1  # Sole external physical newline, absent from returned carrier.
        for part in json.JSONEncoder(sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).iterencode(wire):
            self._step('wire_json_parts');raw=part.encode('utf8');total+=len(raw)
            self._observe('wire_scanned_bytes',len(raw));self._bound('wire_bytes',total)
        return total
    def seal(self,documents):
        self._start_write()
        try:
            self._finish();s=self._state
            if not s.roots or type(documents) is not list or not documents:raise ArenaDataError('complete nonempty catalogue/documents')
            docs=[];seen=set();logical=0;todo=[]
            for label in documents:
                self._step('document_labels');self._string_size(label)
                if not label or label in seen or label not in s.labels:raise ArenaDataError('unique declared document root label')
                seen.add(label);docs.append(label);i=s.labels[label];todo.append(i)
                logical+=s.summaries[i][0]+1;self._bound('documents_expanded_bytes',logical)
            self._full_validate(s);reached=set()
            while todo:
                self._step('document_reachability');i=todo.pop()
                if i in reached:continue
                reached.add(i);todo.extend(self._refs(s.nodes[i]))
            if len(reached)!=len(s.nodes) or any(i not in reached for k,i in s.roots):
                raise ArenaDataError('documents must cover ALL catalogue roots and nodes')
            self._step('seal_bookkeeping',len(s.nodes)+len(s.roots)+1)
            prepared=_State(s.nodes,s.summaries,s.buckets,s.roots,s.labels,s.fragments,s.edges,
                            s.cache_bytes,tuple(docs),logical)
            wire=self._wire(prepared);prepared.wire_bytes=self._wire_size(wire)
            result=Sealed(self,prepared,_token=_TOKEN)
            if tuple(documents)!=tuple(docs):raise ArenaDataError('document input changed during seal')
            self._finish()
            # Single publication slot also represents the lifecycle transition:
            # the prepared state's nonempty documents make the arena SEALED.
            self._state=prepared
            return result
        finally:self._busy=False
    def to_wire(self,sealed):
        self._public();self._step('exports')
        if type(sealed) is not Sealed or sealed._owner is not self or sealed._state is not self._state or not self._state.documents:
            raise ArenaDataError('exact current sealed forest required')
        self._full_validate(self._state);wire=self._wire(self._state)
        if self._wire_size(wire)!=self._state.wire_bytes:raise ArenaDataError('whole physical byte ledger mismatch')
        self._finish();return wire
    def abort(self):
        self._public()
        if self._busy:raise ReentrancyError('cannot abort a transaction',_owner=_TOKEN)
        self._step('abort_operations');self._finish();self._lifecycle='ABORTED'
    def statistics(self):
        # Only permitted callback API; fixed field/counter dictionary, no nodes,
        # backing containers, callback or ownership token escapes.
        s=self._state
        return dict(lifecycle='ABORTED' if self._lifecycle=='ABORTED' else 'SEALED' if s.documents else 'ACTIVE',
            counters=dict(self._counts),nodes=len(s.nodes),edges=s.edges,roots=len(s.roots),
            cache_entries=len(s.fragments),cache_bytes=s.cache_bytes,documents=len(s.documents),
            logical_document_bytes=s.logical_bytes,physical_wire_bytes=s.wire_bytes,
            authority=False)

# Reviewer inert copied-Source text only; never evaluated.
