"""Reviewer raw Source/AST and inert copied-comment patches only; no component import."""
import ast,difflib,hashlib,json,subprocess
from pathlib import Path
BASE=Path('/private/tmp/gcts-incremental-arena-ROOT-20261019')
LIB=Path('/private/tmp/gcts-incremental-arena-library-20261019')
OUT=Path('/private/tmp/gcts-incremental-arena-peer-20261019')
FILES=dict(arena=LIB/'exact_evidence_arena_v1.py',inverse=BASE/'independent_forest_inverse_v6.py',worker=BASE/'qualify_arena_worker_v3.py',runner=BASE/'run_arena_once_v3.py',observer=Path('/private/tmp/gcts-exact-evidence-ROOT-source-20261019/observe_exact_evidence_once_v2.py'),legacy_encoder=Path('/private/tmp/gcts-exact-evidence-source-20261019/exact_evidence_table_v2.py'),legacy_inverse=Path('/private/tmp/gcts-fragment-inverse-ROOT-source-20261019/independent_evidence_inverse_v5.py'),legacy_fixture_worker=Path('/private/tmp/gcts-fragment-inverse-ROOT-source-20261019/qualify_exact_evidence_worker_v12.py'),arena_fixture_module=LIB/'arena_qualification_fixtures_v1.py',forest_fixture_module=BASE/'forest_qualification_fixtures_v3.py')
def d(p):
 b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def variable(tree,name):
 for n in tree.body:
  if isinstance(n,ast.Assign)and any(isinstance(q,ast.Name)and q.id==name for q in n.targets):return ast.literal_eval(n.value)
 raise AssertionError(name)
texts={k:p.read_text()for k,p in FILES.items()};trees={k:ast.parse(s,filename=str(FILES[k]))for k,s in texts.items()}
for k,t in trees.items():compile(t,str(FILES[k]),'exec',dont_inherit=True)
checks=[]
def record(name,value,evidence):
 assert value,name
 checks.append(dict(name=name,passed=True,evidence=evidence))
for k in FILES:
 record(k+'_parser_compile_only',True,'AST parsed and unused code object compiled, never executed. Imports: '+repr([ast.unparse(n)for n in ast.walk(trees[k])if isinstance(n,(ast.Import,ast.ImportFrom))]))
for k in ['arena','inverse','worker','runner','observer','arena_fixture_module','forest_fixture_module']:
 record(k+'_no_yield_functions',not any(isinstance(n,(ast.Yield,ast.YieldFrom))for n in ast.walk(trees[k])),'No generator-function Yield/YieldFrom node. Generator expressions without delegated marker calls remain ordinary stdlib/data traversal helpers.')
names=variable(trees['legacy_fixture_worker'],'EXPECTED_FIXTURES')+list(variable(trees['arena_fixture_module'],'EXPECTED_ARENA_FIXTURES'))+list(variable(trees['forest_fixture_module'],'EXPECTED_FOREST_FIXTURES'))
record('complete_unique_fixture_names',len(names)==127 and len(set(names))==127,'Literal71+33+23 names in preserved order; no fixture call.')
record('legacy_StopIteration_scope',not any('stopiteration'in n.lower()for n in names[:71]),'The old71 name set does not assert StopIteration propagation; separate scope-gap note preserves measured finite qualification.')
a=texts['arena'];i=texts['inverse'];w=texts['worker'];r=texts['runner'];f=texts['forest_fixture_module'];af=texts['arena_fixture_module']
patterns={
'arena_exact_full_limit_keys':('arena','set(limits)!=LIMIT_KEYS'),
'arena_strict_builtin_capture':('arena','if kind not in (list,dict):raise ArenaDataError'),
'arena_full_equality_interning':('arena','if t.nodes[i]==n:return i'),
'arena_second_capture_reconciliation':('arena','if self._capture_value(value,t)!=i:'),
'arena_atomic_publication_after_guards':('arena','self._finish()  # Every fallible operation precedes the one publication.\n        self._state=prepared'),
'arena_failed_writer_finally':('arena','finally:self._busy=False'),
'arena_same_owner_handles':('arena','h._owner is not self'),
'arena_ordered_repeated_compose':('arena',"for h in children:self._step('compose_children');refs.append(self._handle(h))"),
'arena_exact_path_bool_exclusion':('arena','if type(p) not in (str,int):'),
'arena_occurrence_materialization':('arena',"if count!=occ:raise ArenaDataError('fresh occurrence count mismatch')"),
'arena_complete_catalogue_coverage':('arena','if len(reached)!=len(s.nodes) or any(i not in reached for k,i in s.roots):'),
'arena_logical_document_LF_once':('arena',"logical+=s.summaries[i][0]+1;self._bound('documents_expanded_bytes',logical)"),
'arena_physical_LF_once':('arena','total=1  # Sole external physical newline, absent from returned carrier.'),
'arena_all_future_pull_lifecycle':('arena','self.a._public()\n        if self._closed or self._failed:'),
'arena_callback_reentrancy':('arena',"if self._in_callback:raise ReentrancyError('only passive statistics allowed in callbacks',_owner=_TOKEN)"),
'arena_abort_after_guards':('arena',"self._step('abort_operations');self._finish();self._lifecycle='ABORTED'"),
'arena_terminal_stream_after_error':('arena','self._failed=True;raise'),
'arena_completion_after_final_reconciliation':('arena',"a._finish();return _END"),
'inverse_exact_full_forest_fields':('inverse',"fields={'schema','version','source_epoch','semantic_epoch','roots','documents','nodes'}"),
'inverse_strict_prior_bool_exclusion':('inverse',"_need(type(ref)is int and 0<=ref<i,'strict prior integer reference')"),
'inverse_full_typed_uniqueness':('inverse',"_need(key not in typed,'duplicate complete typed node');typed.add(key)"),
'inverse_owned_immutable_nodes':('inverse','nodes=tuple(nodes);sizes=tuple(sizes);counts=tuple(counts);key_sizes=tuple(key_sizes)'),
'inverse_body_LF_ledger':('inverse','aggregate+=sizes[root]+1'),
'inverse_full_forest_physical_formula':('inverse','physical=2+6+sum(len(_token(k))+1+v for k,v in values.items())+1'),
'inverse_all_document_roots_reachability':('inverse',"_need(count>0,'node not covered by complete logical documents')"),
'inverse_catalogue_not_hidden':('inverse',"_need(all(uses[root]>0 for label,root in catalogue),'catalogue covered by document projection')"),
'inverse_final_occurrence_reconciliation':('inverse',"_need(self.row['stream_value_occurrences']==p._counts[self.root],'complete value occurrence reconciliation')"),
'inverse_no_generator_end_sentinel':('inverse','part=self.pieces.take()\n                if part is None:'),
'inverse_failed_stream_terminal':('inverse',"self.closed=True;self.row['closed_incomplete']=not self.row['completed']"),
'inverse_final_guard_before_completion':('inverse',"state.tick('document_completion');self.row['completed']=True"),
'inverse_callback_guard_owner':('inverse',"if self.in_callback:raise ForestReentrancyError('no charged inverse API from callback',_owner=_LIMIT_TOKEN)"),
'inverse_single_stream_attempt':('inverse',"_need(row['attempts']==0,'one independently checked stream per document')"),
'worker_exact_auxiliary_closure':('worker',"set(aux)=={'legacy_encoder','legacy_inverse','legacy_fixture_worker','arena_fixture_module','forest_fixture_module'}"),
'worker_all_fixture_names_before_inputs':('worker',"need([x['name']for x in fixture_rows]==expected and len(fixture_rows)==127"),
'worker_strict_Library_fixture_schema':('worker',"set(x)=={'schema','name','status','scope','observed','authority'}"),
'worker_one_shared_arena':('worker','arena=arena_module.Arena(source_epoch=source_epoch'),
'worker_arena_explicit_completion':('worker',"need(stream.completed,'arena explicit final completion required')"),
'worker_independent_explicit_completion':('worker',"need(stream.completed,'independent explicit final completion required')"),
'worker_main_forest_counted_once':('worker',"encoded=forest['bytes']"),
'worker_failure_prefix_retention':('worker','completed_input_packets=results,captured_input_prefix=capture_prefix,completed_fixture_prefix=fixture_rows,published_forests=forests'),
'worker_full_Source_guard':('worker',"for d in [runtime,*descriptors.values()]:need(pin(d['path'])==d"),
'runner_original_numeric_profile':('runner','work_seconds=180,overall_seconds=210,memory_bytes=1073741824,result_bytes=134217728,expanded_bytes=134217728,stdout_bytes=4194304,stderr_bytes=4194304'),
'runner_exact_true_max1_subject':('runner',"auth['maximum_actual_invocations']==1 and auth['subject_sha256']==subject_sha"),
'runner_full_twelve_fields':('runner',"need(len(subject)==12,'full twelve-field subject')"),
'runner_consumed_before_launch':('runner','consumed_before_Popen=True'),
'runner_strict_positive_exit':('runner',"need(process.returncode==0,'normal exact worker exit0')"),
'runner_exact_wait4':('runner','os.wait4(process.pid,os.WNOHANG)'),
'runner_permanent_reappearance_refusal':('runner',"need(absent or not group_seen_absent,'owned group reappeared; no unverified signal')"),
'runner_final_wholechecks_strict180':('runner',"need(NOW()<work,'positive final whole checks before180')"),
'runner_both_caps':('runner',"total<=LIMITS['result_bytes']and payload['aggregate_input_expanded_bytes']<=LIMITS['expanded_bytes']"),
'runner_memory_cap':('runner',"usage.ru_maxrss<=LIMITS['memory_bytes']"),
'runner_negative_flags_on_error':('runner',"result['resource_candidate_accepted']=False;result['representation_candidate']=False"),
'fixture_external_faults_not_expected_errors':('arena_fixture_module','no_external_fault();return error'),
'fixture_exact_foreign_StopIteration_manual_next':('arena_fixture_module','identical(lambda:next(stream),fault)'),
'fixture_forest_explicit_completion':('forest_fixture_module',"need(stream.completed,'exhaustion alone never qualifies')"),
'fixture_forest_callback_completion_marker':('forest_fixture_module',"obs.get('last_operation')=='document_completion'"),
}
for name,(role,pattern)in patterns.items():record(name,pattern in texts[role],pattern)
record('inverse_all_scalar_endpoints',"if tag not in ('array','object')and size>cap['scalar_bytes']:_stop('scalar bytes')" in i,'All non-container sizes, including null/true/false, use scalar cap before typed-node publication.')
record('inverse_metadata_not_logical_documents','def metrics(self,value,*,quoted=True,logical=False):' in i and "if logical and (escaped if quoted else width)>self.cap['expanded_bytes']" in i,'Metadata uses scalar+physical ledger; only node scalar/object-key contributions additionally use logical expansion bound.')
record('inverse_quoted_string_measure',"if (escaped if quoted else width)>self.cap['scalar_bytes']:_stop('scalar bytes')" in i,'Same quoted token measure as arena; numeric logical lexemes unquoted.')
record('new_scalar_endpoint_finite_obligations',all(q in f for q in ["(['null'],b'null',4)","(['bool',True],b'true',4)","(['bool',False],b'false',5)","expanded_bytes=5","scalar_bytes=7","scalar_bytes=8"]),'Declared Source fixture tests quoted boundary, scalar literals and separate metadata budget; no fixture executed.')

# Genuine inert patch applications to private copied Sources, never imported.
inert=[]
for role in ['arena','inverse','worker','runner','arena_fixture_module','forest_fixture_module']:
 folder=OUT/('inert-'+role+'-v3');folder.mkdir(exist_ok=False)
 b=FILES[role].read_text();variant=b+'\n# Reviewer inert copied-Source text only; never evaluated.\n'
 forward=''.join(difflib.unified_diff(b.splitlines(True),variant.splitlines(True),fromfile='subject.py',tofile='subject.py'))
 inverse=''.join(difflib.unified_diff(variant.splitlines(True),b.splitlines(True),fromfile='subject.py',tofile='subject.py'))
 (folder/'base.py').write_text(b);(folder/'variant.py').write_text(variant)
 (folder/'forward.patch').write_text(forward);(folder/'inverse.patch').write_text(inverse)
 for direction,start,patch,expected in [('forward',b,forward,variant),('inverse',variant,inverse,b)]:
  dest=folder/direction;dest.mkdir();(dest/'subject.py').write_text(start)
  result=subprocess.run(['/usr/bin/patch','-p0','--batch','--forward'],cwd=dest,input=patch,text=True,capture_output=True)
  assert result.returncode==0,(role,direction,result.stderr,result.stdout)
  assert (dest/'subject.py').read_text()==expected
  inert.append(dict(role=role,direction=direction,result=d(dest/'subject.py'),patch=d(folder/(direction+'.patch'))))
 record(role+'_inert_AST_preserved',ast.dump(ast.parse(b),include_attributes=False)==ast.dump(ast.parse(variant),include_attributes=False),'Actual private forward/inverse patch directions; Source AST identical.')
manual=[
 dict(id='PHYSICAL_CANONICAL_FORMULA',finding='Independently counted JSON punctuation: null8; bool9+literal; int8+quoted lexeme; float10+quoted lexeme; str8+quoted scalar; array12+ID digits+commas; object13+pair punctuation/key tokens/ID digits+commas; catalogue pairs3+quoted label+ID digits. Complete seven-field object adds braces,6commas,key/colon tokens and one LF. These agree with inverse formulas and arena full JSONEncoder scan.'),
 dict(id='LOGICAL_LEDGER_AND_REPEATED_PORTS',finding='Each named document charges root canonical body+one LF once, not each catalogue root. Both summary recurrences sum every ordered child reference and multiplicity; reverse union-document reachability forbids an omitted committed root/node. Distinct labels for equal values remain distinct documents.'),
 dict(id='FALLIBLE_BEFORE_PUBLICATION',finding='Capture/compose create transaction-local nodes, summaries, buckets, labels and fragments; final immutable state and handle creation precede guard and one _state assignment. Seal validates and builds full wire before the same one-slot publication. Failure counters stay on arena and are not refunded.'),
 dict(id='INDEPENDENT_INVERSE_NO_ARENA_HELPERS',finding='Forest Source imports json/math/re only. Its own lexical checks, physical-byte formula, size/occurrence/height recurrences, complete reverse coverage and byte/cache walks reconstruct from owned tuples without arena imports. This is unformalized Source reasoning, not a machine proof.'),
 dict(id='CUSTOM_STOPITERATION_BOUNDARY',finding='New core has no generator-function yield. Explicit _END/None internal end and final completion flags distinguish component completion from a foreign StopIteration swallowed by a consumer loop. Worker checks completed immediately after whole byte comparison; fixtures use manual next for exact marker identity.'),
 dict(id='LIMIT_COST_SCOPE',finding='New invocation-total200m arena and new forest30m default are different component work profiles from old per-call code. Full Source/runtime hashing, stdlib scans, copies and diagnostic instances are charged to wholeworker wall/peak; Source limits do not prove fit or hard callback latency.'),
 dict(id='MUTATION_AND_TRUST_BOUNDARY',finding='Owned nodes, refs, summaries, labels and cached bytes are immutable values after successful preparation. Export/materialization/statistics copies do not alias those values. This depends on exclusive ordinary-Python ownership/no caller writes to implementation backing attributes; not a hostile interpreter/OS sandbox or continuous formal Source seal.'),
]
audit=dict(schema='incremental-arena-reviewer-static-audit-v3',source_only=True,scientific_calls=0,module_evaluations=0,component_calls=0,fixture_calls=0,codec_calls=0,inverse_calls=0,sources={k:d(p)for k,p in FILES.items()},checks=checks,checks_passed=len(checks),mismatches=0,unused_compile_checks=len(FILES),real_inert_patch_directions=len(inert),inert=inert,manual_review=manual,fixture_names=names,open_scope_item=None)
p=OUT/'core-harness-static-audit-v3.json';p.write_text(json.dumps(audit,ensure_ascii=False,sort_keys=True,indent=2)+'\n');print(json.dumps(d(p)));print('checks',len(checks),'inert',len(inert))
