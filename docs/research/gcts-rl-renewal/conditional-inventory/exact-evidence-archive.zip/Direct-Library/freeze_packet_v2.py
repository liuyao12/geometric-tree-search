"""Narrow Source/metadata successor construction. No arena or fixture calls."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import subprocess

D=Path('/private/tmp/gcts-direct-reconcile-library-20261019')
P=D/'exact_evidence_arena_v2.py'
S=D/'exact_evidence_arena_v3.py'
V1=Path('/private/tmp/gcts-incremental-arena-library-20261019/exact_evidence_arena_v1.py')
F=Path('/private/tmp/gcts-incremental-arena-library-20261019/arena_qualification_fixtures_v1.py')
def pin(p):
    b=p.read_bytes()
    return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def save(name,obj):
    p=D/name;assert not p.exists(),str(p)
    p.write_text(json.dumps(obj,ensure_ascii=False,sort_keys=True,indent=2,allow_nan=False)+'\n')
    return pin(p)
def raw(src,n):return ''.join(src.splitlines(keepends=True)[n.lineno-1:n.end_lineno])
def dump(n):return ast.dump(n,include_attributes=False)
old=P.read_text();assert pin(P)['sha256']=='042502c21a8fb9b72b4b9b86cc75e2aae0b3beb43fba21dfa194717e4017cd86'
changes=[
 ("IMPLEMENTATION_VERSION='exact-evidence-arena-v2-direct-reconciliation'","IMPLEMENTATION_VERSION='exact-evidence-arena-v3-direct-reconciliation-parent-guards'"),
 ("EXECUTION_PROFILE='invocation-total-direct-reconciliation-v2'","EXECUTION_PROFILE='invocation-total-direct-reconciliation-parent-guards-v3'"),
 ("self._step('reconciliation_begins');self._finish()","self._step('reconciliation_begins')"),
 ("self._step('reconciliation_complete_reads');self._finish()","self._step('reconciliation_complete_reads')")]
new=old
for before,after in changes:assert new.count(before)==1;new=new.replace(before,after,1)
assert not S.exists();S.write_text(new)
a=ast.parse(old);b=ast.parse(new);checks=[]
def need(name,ok,evidence=None):
    checks.append(dict(name=name,passed=bool(ok),evidence=evidence));assert ok,name
am={n.name:n for n in a.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
bm={n.name:n for n in b.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
need('same public and private definitions',set(am)==set(bm))
retained=[]
for name,n in am.items():
    if name=='Arena':continue
    need('whole raw/AST retained '+name,raw(old,n)==raw(new,bm[name]) and dump(n)==dump(bm[name]))
    retained.append(name)
ac={n.name:n for n in am['Arena'].body if isinstance(n,ast.FunctionDef)}
bc={n.name:n for n in bm['Arena'].body if isinstance(n,ast.FunctionDef)}
need('same Arena methods',set(ac)==set(bc))
for name,n in ac.items():
    if name=='_reconcile_value':continue
    need('whole raw/AST retained Arena.'+name,raw(old,n)==raw(new,bc[name]) and dump(n)==dump(bc[name]))
    retained.append('Arena.'+name)
need('same every method signature',all(dump(ac[k].args)==dump(bc[k].args) for k in ac))
reverse=new
for before,after in changes:assert reverse.count(after)==1;reverse=reverse.replace(after,before,1)
need('entire raw inverse exact',reverse==old)
need('entire AST inverse exact',dump(ast.parse(reverse))==dump(a))
local=raw(new,bc['_reconcile_value'])
for before,after in changes[2:]:local=local.replace(after,before,1)
need('only two finish calls removed from comparator',local==raw(old,ac['_reconcile_value']))
attrs=lambda n:[x.func.attr for x in ast.walk(n) if isinstance(x,ast.Call) and isinstance(x.func,ast.Attribute)]
for name in ['_reconcile_value','_reconcile_text','_reconcile_keys']:
    need('no finish/guard added to '+name,'_finish' not in attrs(bc[name]) and '_guard' not in attrs(bc[name]))
need('capture initial finish retained raw',raw(new,bc['capture'])==raw(old,ac['capture']))
need('sole final commit retained raw',raw(new,bc['_commit_root'])==raw(old,ac['_commit_root']))
need('check cadence and quotas retained raw',raw(new,bc['_step'])==raw(old,ac['_step']))
need('guard invoker retained raw',raw(new,bc['_finish'])==raw(old,ac['_finish']))
need('markers remain charged',"self._step('reconciliation_begins')" in new and "self._step('reconciliation_complete_reads')" in new)
need('no new catch or generator',dump(bc['_reconcile_value']).count('ExceptHandler')==dump(ac['_reconcile_value']).count('ExceptHandler') and not any(isinstance(n,(ast.Yield,ast.YieldFrom)) for n in ast.walk(bc['_reconcile_value'])))
need('no new scalar memo/cache',set(ac)==set(bc) and local==raw(old,ac['_reconcile_value']) and raw(new,bc['__init__'])==raw(old,ac['__init__']))
# Confirm complete inheritance from original V1 apart from the prior, disclosed
# direct-comparison delta and implementation metadata. No target execution.
first=V1.read_text();at=ast.parse(first);v1arena=next(n for n in at.body if isinstance(n,ast.ClassDef) and n.name=='Arena')
v1methods={n.name:n for n in v1arena.body if isinstance(n,ast.FunctionDef)}
need('original first builder raw exact',raw(first,v1methods['_capture_value'])==raw(new,bc['_capture_value']))
need('original final prepublication guard raw exact',raw(first,v1methods['_commit_root'])==raw(new,bc['_commit_root']))
need('original initial capture finish unchanged',"self._finish();t=_Transaction(self);self._label(label,t)" in raw(new,bc['capture']))
need('old fixture explicitly targets second final guard',"if calls[0]==2:raise fault" in F.read_text() and 'Second operation guard targets current final prepublication guard' in F.read_text())
compile(new,str(S),'exec')
need('unused compile only',True)
fwd=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='exact_evidence_arena.py',tofile='exact_evidence_arena.py'))
rev=''.join(difflib.unified_diff(new.splitlines(True),old.splitlines(True),fromfile='exact_evidence_arena.py',tofile='exact_evidence_arena.py'))
(D/'source-forward-v2.patch').write_text(fwd);(D/'source-inverse-v2.patch').write_text(rev)
scratch=D/'inert-patch-v2';scratch.mkdir();target=scratch/'exact_evidence_arena.py';target.write_text(old)
for direction,patch,want in [('forward',D/'source-forward-v2.patch',new),('inverse',D/'source-inverse-v2.patch',old)]:
    r=subprocess.run(['patch','--batch','-s','-p0','-i',str(patch)],cwd=scratch,capture_output=True,text=True)
    need('actual inert '+direction,r.returncode==0 and target.read_text()==want,dict(returncode=r.returncode,stdout=r.stdout,stderr=r.stderr))
need('frozen immediate parent remains unchanged',pin(P)['sha256']=='042502c21a8fb9b72b4b9b86cc75e2aae0b3beb43fba21dfa194717e4017cd86')
need('original parent remains unchanged',pin(V1)['sha256']=='cf887ed9cb04866596a56a5d9261f93c84613eb3aede359223813bb644dccd09')
guard_policy={
 'capture_source_guards':'Exactly original capture initial _finish before the transaction, then original _commit_root final _finish after publication bookkeeping/preparation and before the sole _state assignment. No new Source guard in direct traversal.',
 'why':'Old unchanged33 precommit fixture counts operation guard#2 as final prepublication. Extra direct-pass guards made #2 the begin seam; removing only those additions restores the literal old coverage interpretation.',
 'clock_checks':'Every original _step/_bound and new precharged comparator step is unchanged. check callback cadence remains weighted1024 and original public completions. A progress marker need not itself invoke check if no quantum boundary is crossed.',
 'markers':'reconciliation_begins and reconciliation_complete_reads are charged monotone attempted-progress counters only. complete_reads can exist before failed final guard; it is not handle/publication/success authority.',
 'root_diagnostics':'Root may use passive counters at an ordinary check during unfinished direct read, with a sufficiently long earlier value and an unread later field, for selected adversarial carrier-mutation refusals. A real final-fault case additionally observes completed read plus current publication_bookkeeping delta before raising at the final guard. No test-only hooks or hostile-snapshot promise.',
 'exceptions':'No handler changes. Foreign check/guard errors preserve exact objects; failed capture leaves committed state unchanged and attempted costs monotone.'}
common=dict(author_identity='/root/conventional_library',source_only=True,component_calls=0,fixtures_executed=0,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False)
finding=save('guard-policy-finding-v1.json',dict(**common,schema='direct-reconciliation-parent-guard-coupling-finding-v1',
  status='SOURCE_ONLY_FINDING_RESOLVED_BY_NEW_SUCCESSOR',superseded_source=pin(P),successor_source=pin(S),fixture=pin(F),fixture_lines=[241,256],guard_policy=guard_policy,
  evidence='Raw old fixture counts only source_guard calls during operation and labels second operation guard final prepublication. The frozen V2 added _finish at direct entry and completion. No runtime fixture was executed to make this finding.',
  limitations='Control found the coupling and Root chose this repair; this is the author recording the disposition, not an independent own-Source review. Frozen prior objects remain intact.'))
api=json.loads((D/'API-v1.json').read_text())
api.update(schema='direct-reconciliation-arena-API-v2',source=pin(S),immediate_parent_source=pin(P),
 implementation_version='exact-evidence-arena-v3-direct-reconciliation-parent-guards',execution_profile='invocation-total-direct-reconciliation-parent-guards-v3',guard_policy=guard_policy)
dr=api['direct_reconciliation'];dr['counters']['reconciliation_begins']='One attempted direct second-read entry, charged through unchanged _step cadence; no new Source guard.'
dr['counters']['reconciliation_complete_reads']='One full occurrence walk finished, charged through unchanged _step cadence; original final commit guard/publication still pending.'
dr['diagnostic_seam']='Only passive statistics counters; no hooks. Markers are charged but do not add _finish/Source guard. Root unfinished-read probes use ordinary check cadence, final-fault probes additionally require current publication bookkeeping.'
api_pin=save('API-v2.json',api)
arg=save('Source-argument-v2.json',dict(**common,schema='direct-reconciliation-parent-guards-Source-argument-v1',source=pin(S),immediate_parent=pin(P),original_parent=pin(V1),finding=finding,guard_policy=guard_policy,
 retained_comparator_argument=pin(D/'Source-argument-v1.json'),
 retained_argument_scope='The exact typed direct-comparison/ownership/accounting argument remains; the prior sentence asserting newly added direct-entry/completion Source guards is superseded by this explicit original-parent guard policy.',
 argument=[
  'The comparator bodies differ only by removal of their two added _finish calls. The typed traversal, all scalar/key/ordered-edge comparisons, precharges, bounds, active cycle tracking, attempted markers and exception handler remain raw exact.',
  'No original Source guard is removed: original capture initial _finish and original _commit_root final _finish remain raw+AST exact, as do compose/seal/export/stream guards. No new unpublished-state read authority appears.',
  'All clock/work checkpoints continue through the unchanged _step weighted callback cadence. No counters/quotas reset or increase. Removing extra guards restores the old guard-number boundary; it does not skip either original guard.',
  'One _state publication remains after complete first build, complete direct second read, publication bookkeeping, prepared handle/state and final Source/check guard. Any earlier error returns no handle, preserves committed state and incurs monotone attempted cost.',
  'No dynamic test or proof of runtime fit is asserted. Unchanged127 diagnostics plus Root-owned new direct-read/finalguard cases and all3 whole original artifacts remain prospective.']))
audit=save('author-static-audit-v2.json',dict(**common,schema='direct-reconciliation-parent-guards-author-static-audit-v1',author_static_audit_passed=True,independent_review=False,source=pin(S),parent=pin(P),original_parent=pin(V1),
 check_count=len(checks),mismatches=0,checks=checks,retained_regions=retained,whole_raw_AST_inverse=True,inert_text_patch_directions=2,unused_compiles=1,
 forward=pin(D/'source-forward-v2.patch'),inverse=pin(D/'source-inverse-v2.patch'),scope='Only new guard-policy successor delta; prior106-check author audit retained separately, not relabeled independent.'))
delta=save('Source-delta-v2.json',dict(**common,schema='direct-reconciliation-parent-guards-Source-delta-v1',source=pin(S),parent=pin(P),
 replacements=[dict(before=x,after=y) for x,y in changes],forward=pin(D/'source-forward-v2.patch'),inverse=pin(D/'source-inverse-v2.patch'),whole_raw_AST_inverse=True,
 raw_AST_retained_regions=retained,guard_policy=guard_policy))
contract=json.loads((D/'Source-contract-v1.json').read_text())
contract.update(schema='direct-reconciliation-arena-Source-contract-v2',source=pin(S),sources={'exact_evidence_arena':pin(S)},immediate_parent_source=pin(P),
 API=api_pin,Source_argument=arg,Source_delta=delta,author_static_audit=audit,finding=finding,forward=pin(D/'source-forward-v2.patch'),inverse=pin(D/'source-inverse-v2.patch'),
 implementation_version='exact-evidence-arena-v3-direct-reconciliation-parent-guards',execution_profile='invocation-total-direct-reconciliation-parent-guards-v3',guard_policy=guard_policy,
 preserved_predecessor_contract=pin(D/'Source-contract-v1.json'))
contract['qualifications'].append('Root-owned check-callback carrier mutations during unfinished direct read and exact final prepublication fault using completed-read plus publication-bookkeeping observations; old127 Source packets unchanged.')
contract_pin=save('Source-contract-v2.json',contract)
handoff=save('handoff-v2.json',dict(**common,schema='direct-reconciliation-arena-handoff-v2',status='FROZEN_SOURCE_ONLY_UNTESTED_NOT_ACTIVATED',source=pin(S),source_contract=contract_pin,API=api_pin,Source_argument=arg,Source_delta=delta,author_static_audit=audit,finding=finding,
 immediate_parent_source=pin(P),original_parent_source=pin(V1),prior_handoff=pin(D/'handoff-v1.json'),
 implementation_version='exact-evidence-arena-v3-direct-reconciliation-parent-guards',execution_profile='invocation-total-direct-reconciliation-parent-guards-v3',public_API_and_wire_unchanged=True,
 checks=len(checks),unused_compiles=1,inert_patch_directions=2,
 scope='Only removal of two added direct-pass _finish calls, plus explicit new implementation/profile metadata. Markers/compares/caps/clock cadence remain exact. Original guards and old127 fixture scope restored. No execution/grant/report/old-artifact changes.'))
print(json.dumps(dict(source=pin(S),API=api_pin,contract=contract_pin,handoff=handoff,checks=len(checks),scientific_calls=0),sort_keys=True))
