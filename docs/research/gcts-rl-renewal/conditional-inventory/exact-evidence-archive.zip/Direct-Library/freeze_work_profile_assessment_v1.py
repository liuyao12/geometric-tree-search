"""Saved ordinary metadata and AST-only profile assessment. No component calls."""
import ast
import hashlib
import json
from pathlib import Path

D=Path('/private/tmp/gcts-direct-reconcile-ROOT-20261019')
O=Path('/private/tmp/gcts-direct-reconcile-library-20261019')
def pin(p):
    p=Path(p);b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def save(name,v):
    p=O/name;assert not p.exists();p.write_text(json.dumps(v,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n');return pin(p)
packet=json.loads((D/'eleven-Source-packet-v1.json').read_text())
decl=json.loads((D/'declaration-v1.json').read_text())
plan=json.loads((D/'plan-authorized-v1.json').read_text())
failure_path=D/'actual-v1/worker-failure.json';failure=json.loads(failure_path.read_text())
runner_path=D/'actual-v1/runner-receipt.json';runner=json.loads(runner_path.read_text())
terminal_path=D/'plan-authorized-v1-terminal-observation/terminal.json'
audit_path=D/'ROOT-final-audit-v2.json';root_audit=json.loads(audit_path.read_text())
checks=[]
def need(name,ok):checks.append(dict(name=name,passed=bool(ok)));assert ok,name
need('exact closed failure',(pin(failure_path)['sha256'],pin(failure_path)['bytes'])==('b9fb61b9a10f7f60d8d6ac8d66cccc004c4b73b7f76feee342b3980335ba5468',338233))
need('whole11 Source map',len(packet['sources'])==11)
literal_sites={};source_scan={}
for role,d in packet['sources'].items():
    need('current Source '+role,pin(d['path'])==d)
    source=Path(d['path']).read_text();tree=ast.parse(source)
    literal_sites[role]=[dict(line=n.lineno,value=n.value)for n in ast.walk(tree)if isinstance(n,ast.Constant)and type(n.value)is int and n.value in (200000000,400000000)]
    source_scan[role]=dict(source=d,numeric_sites=literal_sites[role])
need('only retained encoder has200m literal',[r for r,v in literal_sites.items()if v]==['legacy_encoder'] and literal_sites['legacy_encoder']==[dict(line=14,value=200000000)])
arena=Path(packet['sources']['encoder']['path']).read_text()
worker=Path(packet['sources']['worker']['path']).read_text()
fx=Path(packet['sources']['reconcile_fixture_module']['path']).read_text()
oldfx=Path(packet['sources']['arena_fixture_module']['path']).read_text()
need('arena strict explicit required positive work',"self._limits=dict(limits)" in arena and "self._counts['work']>self._limits['work']" in arena)
need('worker limits supplied not hardcoded200m',"arena_limits=declaration['arena_limits']" in worker and "arena_limits==declaration['shared_contract_limits']" in worker)
need('main Arena receives same full arena limits',"check=tick,source_guard=guard,limits=arena_limits" in worker)
need('Library33 receives same arena limits',"run_arena_fixtures(arena_module,arena_limits" in worker and "cap=dict(limits)" in oldfx)
need('Root8 receives same arena limits',"run_reconciliation_fixtures(arena_module,arena_limits" in worker and "cap=dict(limits)" in fx)
need('fixed40 and dynamicW+1 remain own tight negatives',"a=new({'work':40})" in oldfx and "cap=w+1;_need(0<cap<=limits['work']" in fx)
need('old declaration records200m bothrequiredplaces',decl['arena_limits']['work']==decl['shared_contract_limits']['work']==200000000)
need('global gates exact',plan['limits']==dict(work_seconds=180,overall_seconds=210,memory_bytes=1073741824,result_bytes=134217728,expanded_bytes=134217728,stdout_bytes=4194304,stderr_bytes=4194304))
need('forest inverse stays30m',decl['forest_inverse_limits']['work']==30000000)
need('failure ownedwork uncompleted',failure['status']=='UNKNOWN_EVIDENCE_LIMIT'and failure['reason']=='work'and failure['own_arena_limit']is True)
need('all135 diagnostics retained',len(failure['completed_fixture_prefix'])==135 and [r['name']for r in failure['completed_fixture_prefix']]==decl['expected_fixture_names'])
stats=failure['reached_context']['arena_statistics'];c=stats['counters']
need('work200mplusone and incomplete directpass',c['work']==200000001 and c['reconciliation_begins']==1 and c.get('reconciliation_complete_reads',0)==0)
need('no committed capacities',all(stats[k]==0 for k in ['nodes','edges','roots','cache_entries','cache_bytes','documents','logical_document_bytes','physical_wire_bytes']))
need('no completed prefixes/forest',all(not failure[k]for k in ['captured_input_prefix','completed_input_packets','published_forests']))
need('false resource/representation outcomes preserved',runner['resource_candidate_accepted']is False and runner['representation_candidate']is False and root_audit['resource_admitted']is False and root_audit['representation_admitted']is False)
need('stderr exact raw pin joins runner',pin(D/'actual-v1/stderr.bin')==runner['stderr'])
need('Source edge charge is direct failure line',"self._step('reconciliation_edges')" in arena.splitlines()[457] and 'line 458, in _reconcile_value' in (D/'actual-v1/stderr.bin').read_text())
n=c['intern_lookups'];e=c['reconciliation_edges']
common=dict(author_identity='/root/conventional_library',source_only=True,saved_data_only=True,scientific_calls=0,component_calls=0,fixtures_executed=0,scientific_replays=0,scientific_acceptance=False,actual_execution_authorized=False)
memo=save('work-profile-assessment-v1.json',dict(**common,schema='direct-reconciliation-work-profile-assessment-v1',status='SOURCE_SUPPORTED_NEW_GUARD_SCOPE_ONLY_NO_FIT_PREDICTION',
  conclusion='The same11 executable Sources accept a new explicit supplied-arena work400m profile without a code change. This raises one finite internal allowance, changes no validation/operation weights, and is not an old200m pass, optimization, speedup or unconsumed retry. Actual authorization and prospective/new-profile review remain Root/Control obligations.',
  ownership='Author wrote the arena/direct comparator, Library33 fixtures and older encoder/Model/adapter components. This is narrow parameter-flow and retained-metadata assessment, not independent own-Source certification or full resource/data admission. Control separately audits the negative/profile and independently reviewed the complete11Sources.',
  current_sources=packet['sources'],source_scan=source_scan,
  retained=dict(failure=pin(failure_path),stderr=pin(D/'actual-v1/stderr.bin'),runner=pin(runner_path),terminal=pin(terminal_path),Root_final_audit=pin(audit_path),consumed_plan=pin(D/'plan-authorized-v1.json'),old_declaration=pin(D/'declaration-v1.json'),old_shared_contract=pin(D/'shared-contract-v6.json'),old_Source_packet=pin(D/'eleven-Source-packet-v1.json')),
  observed=dict(status=failure['status'],reason=failure['reason'],stage=failure['reached_context']['stage'],input=failure['reached_context']['input'],work=c['work'],diagnostic_groups=135,committed_nodes=0,committed_edges=0,committed_roots=0,completed_captures=0,complete_input_packets=0,forests=0,
    first_builder_intern_lookups=n,direct_attempted_edges=e,direct_begins=1,direct_complete_reads=0,terminal_seconds=root_audit['terminal_seconds'],worker_peak_bytes=runner['worker_wait4_usage']['ru_maxrss'],worker_exit=runner['worker_exit_code'],resource_admitted=False,representation_admitted=False,
    interpretation='The measured67.844199375s and600375296B are whole-worker/terminal negative observations, including135diagnostics and incomplete first capture. Numeric time/peak below bounds never overrides work failure/exit1; no successful runtime, artifact or isolated phase timing is established.'),
  parameter_flow=[
    dict(role='encoder',lines=[198,208,222,231],fact='All finite limit keys are caller-supplied strict integers and copied once. _step uses limits[work], with no200m hardcoded ceiling.400m is a valid strict integer, but must be a new authenticated profile.'),
    dict(role='worker',lines=[74,88,98,106],fact='arena_limits comes from declaration; worker requires equality with shared_contract_limits, then passes that same complete mapping to Library33, Root8 and the one main arena. Both declaration maps must change together in a new frozen subject.'),
    dict(role='arena_fixture_module',lines=[76,89,258,263],fact='Default diagnostic arenas inherit the supplied arena work bound. The specific work40 case remains fixed and tighter. Changing supplied400m therefore is not literally a main-only change under unchanged harness.'),
    dict(role='reconcile_fixture_module',lines=[44,55,197,219],fact='Root8 default diagnostic arenas also inherit supplied400m; W+1 negative remains one fresh identical finite probe procedure, not a main-owner reset. Do not retarget/retry if it fails.'),
    dict(role='legacy_encoder',lines=[10,19],fact='Only executable200m numeric literal found is DEFAULT_LIMITS.max_work in the retained per-call encoder. It governs legacy diagnostics, not the new arena input limit; preserve it and all old71 behavior unchanged.'),
    dict(role='worker',lines=[74,85,125,140],fact='The independent forest work30m limit and all own diagnostic tightenings remain separate; a new arena400m allowance must not silently raise them.')],
  exact_future_delta=dict(arena_work_from=200000000,arena_work_to=400000000,field_locations=['new_declaration.arena_limits.work','new_declaration.shared_contract_limits.work','new_shared_contract.limits.work'],
    affects='ONE changed supplied-arena parameter, flowing to the main invocation and inherited local diagnostic arena defaults. All remaining arena keys, inverse30m, legacy limits, eleven raw Sources/135 names, complete3 original inputs/order, operation charges/callback cadence and global gates remain literal unchanged.',
    global_unchanged=plan['limits'],
    profile_metadata='Freeze fresh named400m declaration/shared contract/false+true once subjects/current scoped reviews and actual/terminal paths. Preserve200m objects and consumed marker. Old Source packets/contracts saying private caps unchanged describe their200m cohort only; retain as lineage, never relabel them400m. The Source execution-profile label alone is insufficient: full limit mapping/semantic epoch/new declaration distinguish the numeric profile.'),
  remaining_work=dict(
    Source_supported='At this first main capture, constructor/metadata scan has no intern calls; first builder returned before begins1; comparator has no _intern. Thus12334087 is the first tree logical value-occurrence count under the retained exclusive-owner Source argument, not a provisional or committed unique-node count.',
    expected_first_tree_edges=n-1,
    failed_attempted_edge_included=True,
    at_least_unfinished_first_tree_edge_descents=(n-1)-(e-1),
    explanation='The failing _step increments attempted reconciliation_edges before throwing, before its child lookup/frame push. With no earlier comparator failure, at mostE-1 descents completed. N-1 minusE-1 yields at least5010265 edge descents still needed for this first tree alone. This is an occurrence-accounting inference, not remaining work/time or a complete input reconstruction.',
    unknown='Per-phase work totals are not saved for the main first build; repeated values/keys/scalars have unequal costs. Remaining first-root reconciliation, commit, all3 projections/captures, full validation/seal/export, savedfile parse/independent30m inverse and final output still cost work/time/memory. Linear extrapolation from elapsed time or edge fraction is unjustified.400m may still fail; no fit or expected success asserted.'),
  qualification_obligations=[
    'Fresh prospective/final profile review and once grant; do not launch under consumed200m authorization or mutate old declarations/receipts.',
    'All135 diagnostics must rerun in original literal order, with unchanged success/failure criteria and all3 whole original raw inputs. No old provisional table/prefix cache exists or may be reused.',
    'One main arena across all3; no per-capture reset/reallocation to evade aggregate work. Retain all completed and failure prefixes honestly.',
    'Unchanged180s positive including knownworkerexit/full checks and210terminal;1GiB worker-only posthoc peak;128MiB fullphysical forest+result AND128MiB logicalbody expansions;4MiB each log. New private work allowance is not a global-profile relaxation or oldfailure rescue.',
    'Everybyte baseline/arena/savedfreshindependent inverse, complete catalogue/documents and stream completion remain mandatory. No shortened artifacts: exactly the original three input subjects.',
    'No mathematical/Model/search/GCTS/RL or integrated producer-memory benefit follows from this ordinary evidence component.'],
  check_count=len(checks),checks=checks,limitations=['No new actual, tests, component imports/calls, opaque decoding, fulloldinput decoding, algorithm edits or Root/publication mutations.','The5000000-scale remaining-edge fact cannot bound future work or predict resource fit.','This memo is not a grant or independent certification of own arena; it is explicit finite-profile compatibility advice.']))
handoff=save('work-profile-handoff-v1.json',dict(**common,schema='direct-reconciliation-work-profile-handoff-v1',memo=memo,negative_failure=pin(failure_path),sources=packet['sources'],checks=len(checks),
  disposition='Source-compatible400m supplied-arena guard profile, pending new Root/Control profile/plan/grant review. Legacy200m remains. Default local arena diagnostics inherit new supplied cap; tighter fixed cases/inverse30m remain. No fit/optimization claim; tools stopped.'))
print(json.dumps(dict(memo=memo,handoff=handoff,checks=len(checks)),sort_keys=True))
