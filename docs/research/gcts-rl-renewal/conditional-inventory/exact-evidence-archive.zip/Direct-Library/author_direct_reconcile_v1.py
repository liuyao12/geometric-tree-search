"""Source construction only: never imports/calls the authored arena."""
from pathlib import Path

D=Path('/private/tmp/gcts-direct-reconcile-library-20261019')
P=Path('/private/tmp/gcts-incremental-arena-library-20261019/exact_evidence_arena_v1.py')
old=P.read_text()
assert "EXECUTION_PROFILE='invocation-total-transactional-arena-v1'" in old
new=old.replace("EXECUTION_PROFILE='invocation-total-transactional-arena-v1'",
    "IMPLEMENTATION_VERSION='exact-evidence-arena-v2-direct-reconciliation'\n"
    "EXECUTION_PROFILE='invocation-total-direct-reconciliation-v2'",1)
anchor='    def _label(self,label,t):\n'
assert old.count(anchor)==1
addition='''    def _reconcile_text(self,value,expected):
        # Expected is an already-owned, fully validated exact scalar string.
        if type(value) is not str:raise ArenaDataError('whole input changed during capture')
        self._step('reconciliation_text_lengths')
        if len(value)!=len(expected):raise ArenaDataError('whole input changed during capture')
        for start in range(0,len(value),4096):
            width=min(4096,len(value)-start)
            self._step('reconciliation_text_copies',2*width)
            self._step('reconciliation_text_characters',width)
            self._step('reconciliation_equalities')
            if value[start:start+width]!=expected[start:start+width]:
                raise ArenaDataError('whole input changed during capture')
    def _reconcile_keys(self,value,pairs):
        # A temporary lookup over OWNED keys is not a caller value tree/cache.
        # Hashing only locates a candidate: full text equality still follows.
        self._step('reconciliation_lengths')
        if len(value)!=len(pairs):raise ArenaDataError('input keys changed during capture')
        owned={}
        for key,child in pairs:
            self._step('reconciliation_key_copies')
            self._step('reconciliation_key_characters',len(key))
            owned[key]=key
        for key in value:
            self._step('reconciliation_keys')
            if type(key) is not str:raise ArenaDataError('exact ordinary object keys required')
            self._step('reconciliation_key_characters',len(key))
            self._step('reconciliation_key_lookups')
            expected=owned.get(key,_END)
            if expected is _END:raise ArenaDataError('input keys changed during capture')
            self._reconcile_text(key,expected)
    def _reconcile_value(self,value,t,index):
        # Full second occurrence traversal, without a second owned tree,
        # hashing/interning, summaries or fragments. No identity/digest shortcut.
        self._step('reconciliation_begins');self._finish()
        active=set();frames=[dict(value=value,index=index,phase=0,depth=0)]
        while frames:
            self._step('reconciliation_frames');f=frames[-1]
            v=f['value'];n=t.nodes[f['index']];tag=n[0]
            if not f['phase']:
                kind=type(v);self._bound('depth',f['depth'])
                if tag=='null':
                    self._step('reconciliation_equalities')
                    if v is not None:raise ArenaDataError('whole input changed during capture')
                    frames.pop();continue
                if tag=='bool':
                    self._step('reconciliation_equalities')
                    if kind is not bool or v!=n[1]:raise ArenaDataError('whole input changed during capture')
                    frames.pop();continue
                if tag=='int':
                    if kind is not int:raise ArenaDataError('whole input changed during capture')
                    if v.bit_length()>(3322*self._limits['integer_digits']+999)//1000:self._stop('integer_digits')
                    self._step('integer_conversion')
                    try:lex=str(v)
                    except ValueError as error:raise ArenaDataError('interpreter integer conversion bound') from error
                    self._bound('integer_digits',len(lex)-(1 if lex[0]=='-' else 0))
                    self._bound('scalar_bytes',len(lex))
                    self._step('reconciliation_numeric_characters',len(lex))
                    self._step('reconciliation_equalities')
                    if lex!=n[1]:raise ArenaDataError('whole input changed during capture')
                    frames.pop();continue
                if tag=='float':
                    if kind is not float:raise ArenaDataError('whole input changed during capture')
                    lex=self._float(v);self._bound('scalar_bytes',len(lex))
                    self._step('reconciliation_numeric_characters',len(lex))
                    self._step('reconciliation_equalities')
                    if lex!=n[1]:raise ArenaDataError('whole input changed during capture')
                    frames.pop();continue
                if tag=='str':
                    self._reconcile_text(v,n[1]);frames.pop();continue
                if (tag=='array' and kind is not list) or (tag=='object' and kind is not dict):
                    raise ArenaDataError('whole input changed during capture')
                if tag not in ('array','object'):raise ArenaDataError('internal reconciliation tag')
                self._step('reconciliation_lengths')
                if len(v)!=len(n[1]):raise ArenaDataError('input length changed during capture')
                self._bound('root_expanded_bytes',len(v)+2)
                identity=id(v)
                if identity in active:raise ArenaDataError('cyclic ordinary container')
                active.add(identity)
                if tag=='object':self._reconcile_keys(v,n[1])
                f.update(phase=1,pos=0,identity=identity)
            else:
                self._step('reconciliation_lengths')
                if len(v)!=len(n[1]):raise ArenaDataError('input length changed during capture')
                pos=f['pos']
                if pos<len(n[1]):
                    self._step('reconciliation_edges')
                    if tag=='array':child=v[pos];expected=n[1][pos]
                    else:
                        key,expected=n[1][pos]
                        self._step('reconciliation_key_lookups',2)
                        self._step('reconciliation_key_characters',2*len(key))
                        if key not in v:raise ArenaDataError('input keys changed during capture')
                        child=v[key]
                    f['pos']+=1
                    frames.append(dict(value=child,index=expected,phase=0,depth=f['depth']+1))
                else:
                    if tag=='object':self._reconcile_keys(v,n[1])
                    active.remove(f['identity']);frames.pop()
        self._step('reconciliation_complete_reads');self._finish()
'''
new=new.replace(anchor,addition+anchor,1)
before="""            # A second complete typed reconstruction is literal reconciliation,
            # not a digest or a caller boolean. Extra provisional nodes abort.
            if self._capture_value(value,t)!=i:raise ArenaDataError('whole input changed during capture')
"""
after="""            # Full strict second read against the owned provisional root.
            self._reconcile_value(value,t,i)
"""
assert new.count(before)==1
new=new.replace(before,after,1)
out=D/'exact_evidence_arena_v2.py'
out.write_text(new)
