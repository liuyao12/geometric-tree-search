"""Metadata/AST/inert-text audit only. Never loads/calls the arena Source."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import subprocess

D=Path('/private/tmp/gcts-direct-reconcile-library-20261019')
P=Path('/private/tmp/gcts-incremental-arena-library-20261019/exact_evidence_arena_v1.py')
S=D/'exact_evidence_arena_v2.py'
C=Path('/private/tmp/gcts-incremental-arena-ROOT-20261019/shared-contract-v5.json')
MEMO=Path('/private/tmp/gcts-incremental-arena-library-20261019/capture-next-design-v1.json')
MASTER=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md')

def pin(p):
    b=p.read_bytes()
    return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def save(name,obj):
    p=D/name
    assert not p.exists(),str(p)
    p.write_text(json.dumps(obj,ensure_ascii=False,sort_keys=True,indent=2,allow_nan=False)+'\n')
    return pin(p)
def dump(n):return ast.dump(n,include_attributes=False)
def raw(source,n):return ''.join(source.splitlines(keepends=True)[n.lineno-1:n.end_lineno])

old=P.read_text();new=S.read_text();a=ast.parse(old);b=ast.parse(new)
checks=[]
def need(name,condition,evidence=None):
    checks.append(dict(name=name,passed=bool(condition),evidence=evidence))
    assert condition,name
need('parent exact frozen bytes',pin(P)['sha256']=='cf887ed9cb04866596a56a5d9261f93c84613eb3aede359223813bb644dccd09')
need('memo exact frozen bytes',pin(MEMO)['sha256']=='50b045b175d1abe09ccc378f23fb2655896ec036d9d70bc85f2fe9f4f2efebd2')
contract=json.loads(C.read_text())
need('current shared contract v5',contract['schema']=='ROOT-incremental-arena-shared-contract-v5')
need('same declared work',contract['limits']['work']==200000000)
need('same declared physical cap',contract['limits']['wire_bytes']==134217728)
need('same declared expanded cap',contract['limits']['documents_expanded_bytes']==134217728)
oa={n.name:n for n in a.body if isinstance(n,(ast.ClassDef,ast.FunctionDef))}
nb={n.name:n for n in b.body if isinstance(n,(ast.ClassDef,ast.FunctionDef))}
need('same top-level definitions',set(oa)==set(nb))
retained=[]
for name,n in oa.items():
    if name=='Arena':continue
    need('retained top-level '+name,raw(old,n)==raw(new,nb[name]) and dump(n)==dump(nb[name]))
    retained.append(dict(name=name,parent_lines=[n.lineno,n.end_lineno],successor_lines=[nb[name].lineno,nb[name].end_lineno]))
om={n.name:n for n in oa['Arena'].body if isinstance(n,ast.FunctionDef)}
nm={n.name:n for n in nb['Arena'].body if isinstance(n,ast.FunctionDef)}
added=['_reconcile_text','_reconcile_keys','_reconcile_value']
need('only three added private methods',set(nm)-set(om)==set(added) and not(set(om)-set(nm)))
for name,n in om.items():
    if name=='capture':continue
    need('retained Arena.'+name,raw(old,n)==raw(new,nm[name]) and dump(n)==dump(nm[name]))
    retained.append(dict(name='Arena.'+name,parent_lines=[n.lineno,n.end_lineno],successor_lines=[nm[name].lineno,nm[name].end_lineno]))
need('constructor and all public signatures unchanged',all(dump(om[k].args)==dump(nm[k].args) for k in om))
imports=lambda x:[dump(n) for n in x.body if isinstance(n,(ast.Import,ast.ImportFrom))]
need('only same json/math imports',imports(a)==imports(b))
assignments=lambda x:{n.targets[0].id:n for n in x.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name)}
ac=assignments(a);bc=assignments(b)
need('only implementation metadata added',set(bc)-set(ac)=={'IMPLEMENTATION_VERSION'})
for key in ac:
    if key!='EXECUTION_PROFILE':need('retained literal '+key,dump(ac[key])==dump(bc[key]))
need('explicit implementation version',ast.literal_eval(bc['IMPLEMENTATION_VERSION'].value)=='exact-evidence-arena-v2-direct-reconciliation')
need('explicit execution profile',ast.literal_eval(bc['EXECUTION_PROFILE'].value)=='invocation-total-direct-reconciliation-v2')
calls=lambda n:[x.func.attr for x in ast.walk(n) if isinstance(x,ast.Call) and isinstance(x.func,ast.Attribute)]
need('capture retains exactly one first builder',calls(nm['capture']).count('_capture_value')==1)
need('capture direct second read precedes unchanged commit',calls(nm['capture'])==['_start_write','_finish','_label','_capture_value','_reconcile_value','_commit_root'])
need('no new catch around delegated callbacks',not any(isinstance(n,ast.ExceptHandler) for k in added[:2] for n in ast.walk(nm[k])))
handlers=[n for n in ast.walk(nm['_reconcile_value']) if isinstance(n,ast.ExceptHandler)]
need('only local builtin str conversion handler',len(handlers)==1 and isinstance(handlers[0].type,ast.Name) and handlers[0].type.id=='ValueError')
tries=[n for n in ast.walk(nm['_reconcile_value']) if isinstance(n,ast.Try)]
need('no callback in conversion catch body',len(tries)==1 and ast.unparse(tries[0].body[0])=='lex = str(v)')
for key in added:
    attrs=calls(nm[key])
    need(key+' no rebuilding/intern/cache/summary/publication',not(set(attrs)&{'_intern','_capture_value','_summary','_cache','_commit_root','prepared'}))
    need(key+' no generator',not any(isinstance(n,(ast.Yield,ast.YieldFrom)) for n in ast.walk(nm[key])))
    need(key+' no owned attribute publication',not any(isinstance(n,(ast.Assign,ast.AnnAssign,ast.AugAssign)) and any(isinstance(t,ast.Attribute) for t in (n.targets if isinstance(n,ast.Assign) else [n.target])) for n in ast.walk(nm[key])))
need('text copies and comparisons precharged',"self._step('reconciliation_text_copies',2*width)\n            self._step('reconciliation_text_characters',width)\n            self._step('reconciliation_equalities')\n            if value[start:start+width]!=expected[start:start+width]" in new)
need('text windows at most4096',"for start in range(0,len(value),4096):\n            width=min(4096,len(value)-start)" in new)
need('every matched object key full text checked',"expected=owned.get(key,_END)\n            if expected is _END:raise ArenaDataError('input keys changed during capture')\n            self._reconcile_text(key,expected)" in new)
need('strict actual key types',"if type(key) is not str:raise ArenaDataError('exact ordinary object keys required')" in new)
need('all ordered children visited',"if pos<len(n[1]):" in raw(new,nm['_reconcile_value']) and "n[1][pos]" in raw(new,nm['_reconcile_value']))
need('cycle check and depth guard',"if identity in active:" in raw(new,nm['_reconcile_value']) and "self._bound('depth',f['depth'])" in raw(new,nm['_reconcile_value']))
need('container keyset checked at entry and exit',raw(new,nm['_reconcile_value']).count("self._reconcile_keys(v,n[1])")==2)
need('strict numeric kinds',"if kind is not int:" in raw(new,nm['_reconcile_value']) and "if kind is not float:" in raw(new,nm['_reconcile_value']))
need('integer bit/digit/scalar guards retained in comparison',all(x in raw(new,nm['_reconcile_value']) for x in ["v.bit_length()", "self._bound('integer_digits'", "self._bound('scalar_bytes'"]))
need('integer lexical scan actually removed from second pass', '_valid_int' not in calls(nm['_reconcile_value']))
need('float current canonical conversion retained','_float' in calls(nm['_reconcile_value']))
need('numeric equality precharged',raw(new,nm['_reconcile_value']).count("self._step('reconciliation_numeric_characters',len(lex))\n                    self._step('reconciliation_equalities')\n                    if lex!=n[1]")==2)
need('begin guard explicit',"self._step('reconciliation_begins');self._finish()" in new)
need('full-read completion guard explicit',"self._step('reconciliation_complete_reads');self._finish()" in new)

# An exact whole-source inverse removes only three private methods, the capture
# seam and the two execution-metadata changes. No authored target invocation.
inverse=new
for key in added:inverse=inverse.replace(raw(new,nm[key]),'',1)
inverse=inverse.replace(raw(new,nm['capture']),raw(old,om['capture']),1)
inverse=inverse.replace("IMPLEMENTATION_VERSION='exact-evidence-arena-v2-direct-reconciliation'\n",'',1)
inverse=inverse.replace("EXECUTION_PROFILE='invocation-total-direct-reconciliation-v2'","EXECUTION_PROFILE='invocation-total-transactional-arena-v1'",1)
need('whole raw inverse exact',inverse==old)
need('whole AST inverse exact',dump(ast.parse(inverse))==dump(a))
compile(new,str(S),'exec')  # The returned code object is discarded, never executed.
need('unused Source compile',True)
fwd=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='exact_evidence_arena.py',tofile='exact_evidence_arena.py'))
rev=''.join(difflib.unified_diff(new.splitlines(True),old.splitlines(True),fromfile='exact_evidence_arena.py',tofile='exact_evidence_arena.py'))
(D/'source-forward.patch').write_text(fwd);(D/'source-inverse.patch').write_text(rev)
scratch=D/'inert-patch';scratch.mkdir();target=scratch/'exact_evidence_arena.py';target.write_text(old)
for direction,patch,want in [('forward',D/'source-forward.patch',new),('inverse',D/'source-inverse.patch',old)]:
    result=subprocess.run(['patch','--batch','-s','-p0','-i',str(patch)],cwd=scratch,capture_output=True,text=True)
    need('actual inert text patch '+direction,result.returncode==0 and target.read_text()==want,dict(returncode=result.returncode,stdout=result.stdout,stderr=result.stderr))
need('old Source remains exact',pin(P)['sha256']=='cf887ed9cb04866596a56a5d9261f93c84613eb3aede359223813bb644dccd09')

counters={
 'reconciliation_begins':'One attempted direct second-read entry; charged before explicit _finish guard/check.',
 'reconciliation_complete_reads':'One full occurrence walk finished; charged before final _finish. This is not publication or operation success.',
 'reconciliation_frames':'Each explicit direct-walk frame dispatch; containers re-dispatch for each ordered child and completion.',
 'reconciliation_lengths':'Each actual container length comparison and object-key cardinality comparison.',
 'reconciliation_edges':'Every ordered array element or object child occurrence actually descended.',
 'reconciliation_equalities':'Each strict scalar/lexeme or bounded text-window comparison.',
 'reconciliation_text_lengths':'Each strict string/key length comparison.',
 'reconciliation_text_copies':'Conservative exact two-slice character-copy count before bounded text comparison.',
 'reconciliation_text_characters':'Worst-case characters compared, precharged before each <=4096-character text window.',
 'reconciliation_keys':'Every actual object key type/keyset visit, entry and exit.',
 'reconciliation_key_copies':'Every owned key inserted into the temporary candidate lookup, entry and exit. No caller value tree or persistent cache.',
 'reconciliation_key_lookups':'Every builtin exact dictionary lookup, with two for membership plus value fetch during child traversal.',
 'reconciliation_key_characters':'Conservative key character bounds precharged before owned-key hashing, candidate lookup and each caller lookup. Full text-window checking is additional.',
 'reconciliation_numeric_characters':'Full canonical integer/float lexeme comparison length, precharged before equality.'}
api=json.loads((P.parent/'API-v1.json').read_text())
api.update(schema='direct-reconciliation-arena-API-v1',source=pin(S),parent_source=pin(P),shared_contract=pin(C),
    implementation_version='exact-evidence-arena-v2-direct-reconciliation',execution_profile='invocation-total-direct-reconciliation-v2',
    direct_reconciliation=dict(private_methods={k:ast.unparse(nm[k].args) for k in added},public_signatures_changed=False,counters=counters,
      diagnostic_seam='Only passive statistics counters. No test-only hooks. Begin/full-read completion counters precede explicit Source/check guards; all failures leave committed state unchanged with attempted costs retained.',
      ownership='Second read compares the currently supplied ordinary tree occurrence by occurrence. It cannot prove a simultaneous snapshot under forbidden concurrent/adversarial mutation. Selected callback mutation refusals are future diagnostics outside normal exclusive-owner behavior.'),
    work='Same _step, weighted callback cadence, limits and old counter meanings. Direct comparison adds explicit precharged actual-operation counters. No old operation is executed without its old charge; redundant second node construction/interning/digit-validation is actually absent. Counts are not elapsed time or an old-trace equivalence claim.')
api_pin=save('API-v1.json',api)
argument=save('Source-argument-v1.json',dict(schema='direct-reconciliation-Source-argument-v1',author_identity='/root/conventional_library',source=pin(S),parent=pin(P),shared_contract=pin(C),memo=pin(MEMO),
  status='AUTHOR_ARGUMENT_SOURCE_ONLY_UNTESTED',source_only=True,scientific_calls=0,component_calls=0,fixtures_executed=0,scientific_acceptance=False,actual_execution_authorized=False,
  argument=[
    'First capture creates a valid owned typed DAG exactly as parent. No change to _capture_value/_intern/_summary/_cache, numeric/Unicode validation or limits.',
    'Induction over the second explicit occurrence stack: each scalar requires exact builtin type and exact value/validated canonical lexical equality; strings and keys compare every character in bounded windows, not hash/digest/identity. Int builtin decimal spelling plus complete equality to the valid stored spelling inherits canonical digit syntax; separate redundant digit rescanning is absent. Float retains parent finite canonical conversion and full spelling equality, including negative zero.',
    'Each container requires the expected exact list/dict kind and length. The active-path identity set detects cycles; identities are never positive equality witnesses. Repeated sibling objects and repeated node references are traversed per occurrence. Arrays visit each index in order. Object keys are exact strings; equal cardinality plus every actual key locating and fully comparing to a unique owned expected key establishes full literal keyset equality. Entry and exit repeat keyset checks. Child values use the stored canonical key order, with every ordered edge charged.',
    'Expected nodes have already passed original complete bounds. Positive full equality therefore preserves Unicode scalar restrictions, byte/root limits, integer syntax, ordered multiplicity and all expected summaries without building a second tree. Current depth/container lower-bound and integer preconversion/digit/scalar guards remain explicit. Unchanged _full_validate/seal/export still revalidate full node/edge/root/document/wire ledgers.',
    'The comparator only reads provisional nodes and updates invocation attempted counters. Temporary frames, active IDs and an ephemeral lookup over owned keys are local; none is published or retained as a cache. No node/summary/bucket/fragment/root mutation. Every fallible comparison/guard remains before the unchanged _commit_root sole _state assignment; capture finally restores busy without a callback.',
    'Foreign callback exceptions cross no new handler, generator or wrapper. The sole new narrow except surrounds only builtin str(v) for an exact int, with callbacks outside the try. Source guards occur before direct frames and after a complete walk, plus all original capture/final-commit guards. Error identity/lifecycle/streams/reentrancy are inherited unchanged.',
    'Exclusive ordinary-Python ownership remains essential: callback mutation and concurrent mutation are forbidden in normal use, and no finite repeated read guarantees a simultaneous snapshot against arbitrary adversarial time-dependent mutation. Future selected mutation diagnostics test refusals, not a hostile-code sandbox.'],
  accounting=dict(counters=counters,no_counter_or_quota_reset=True,no_cap_increase=True,old_methods_raw_exact=True,
      caveat='New actual-operation path and disclosed profile. A future positive cannot be described as old second-builder virtual-work trace equivalence; no gain/fit predicted.'),
  qualification='Retain all3 complete originals, original127 diagnostics and preserved negative actual. Root authors new targeted direct second-read mutations/error/quota diagnostics and independent full saved-forest bytewise inverse. No fixture or component execution by author. Same180/210,1GiB,128MiB physical AND expanded,200m work.'))
audit=save('author-static-audit-v1.json',dict(schema='direct-reconciliation-author-static-audit-v1',author_identity='/root/conventional_library',source=pin(S),parent=pin(P),shared_contract=pin(C),master=pin(MASTER),
  author_static_audit_passed=True,independent_review=False,source_only=True,scientific_calls=0,component_calls=0,fixtures_executed=0,scientific_acceptance=False,actual_execution_authorized=False,
  check_count=len(checks),mismatches=0,checks=checks,retained_regions=retained,new_regions={k:[nm[k].lineno,nm[k].end_lineno] for k in added},
  raw_ast_inverse=True,unused_compiles=1,inert_text_patch_directions=2,forward=pin(D/'source-forward.patch'),inverse=pin(D/'source-inverse.patch'),
  limitations=['Author audit of own successor, not independent Source certification.','No runtime cases, model generation, arena/codec/fixture calls, performance or fit measurements.','Numeric limits are caller supplied; future Root plan must authenticate exact unchanged values.','Stdlib builtin conversion/hash/equality/copy latency and nonhostile exclusive ownership remain conditional assumptions.']))
delta=save('Source-delta-v1.json',dict(schema='direct-reconciliation-Source-delta-v1',source=pin(S),parent=pin(P),forward=pin(D/'source-forward.patch'),inverse=pin(D/'source-inverse.patch'),whole_raw_inverse=True,whole_AST_inverse=True,
  retained_regions=retained,modified_regions=['IMPLEMENTATION_VERSION added','EXECUTION_PROFILE replaced','Arena.capture second _capture_value call replaced'],added_regions={k:[nm[k].lineno,nm[k].end_lineno] for k in added},
  scientific_calls=0,component_calls=0,actual_execution_authorized=False))
source_contract=save('Source-contract-v1.json',dict(schema='direct-reconciliation-arena-Source-contract-v1',author_identity='/root/conventional_library',status='FROZEN_SOURCE_ONLY_UNTESTED_NOT_ACTIVATED',source_only=True,
  source=pin(S),sources={'exact_evidence_arena':pin(S)},parent_source=pin(P),shared_contract=pin(C),API=api_pin,Source_argument=argument,Source_delta=delta,author_static_audit=audit,
  forward=pin(D/'source-forward.patch'),inverse=pin(D/'source-inverse.patch'),memo=pin(MEMO),master=pin(MASTER),
  wire=dict(schema='exact-evidence-forest-v1',version='exact-evidence-arena-v1',public_API_unchanged=True),
  implementation_version='exact-evidence-arena-v2-direct-reconciliation',execution_profile='invocation-total-direct-reconciliation-v2',
  caps=contract['limits'],profile=dict(positive_seconds=180,terminal_seconds=210,worker_memory_bytes=1073741824,physical_AND_expanded_bytes=134217728),
  component_calls=0,fixtures_executed=0,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,
  ancestry='Author wrote parent arena/fixtures, per-call encoder and earlier Model/registry/point components; this author audit is not independent own Source certification. Root independent inverse/harness and Control review remain separate.',
  qualifications=['All3 complete original inputs and all127 old diagnostics retained under newly reviewed once subject; no old failure recovery.','Root-authored targeted full second-read refusal and exact callback/quota/transaction diagnostics before actual grant.','Whole canonical bytewise independent saved-forest inverse plus explicit stream completion, all resource/Source/custody gates.','No successful runtime, reduced work, speed or memory result is asserted by this Source packet.'],
  review_ABI=dict(schema='direct-reconciliation-arena-typed-Source-review-v1',scope='exact-evidence-arena-direct-reconciliation-Source',required_fields=['source','sources','source_contract','author_identity','reviewer_identity','source_only','source_review_passed','scientific_calls','scientific_acceptance','actual_execution_authorized','findings'])))
handoff=save('handoff-v1.json',dict(schema='direct-reconciliation-arena-handoff-v1',author_identity='/root/conventional_library',status='FROZEN_SOURCE_ONLY_UNTESTED_NOT_ACTIVATED',source=pin(S),source_contract=source_contract,API=api_pin,
  Source_argument=argument,Source_delta=delta,author_static_audit=audit,parent_source=pin(P),shared_contract=pin(C),
  public_API_and_wire_unchanged=True,implementation_version='exact-evidence-arena-v2-direct-reconciliation',execution_profile='invocation-total-direct-reconciliation-v2',
  checks=len(checks),inert_patch_directions=2,unused_compiles=1,component_calls=0,fixtures_executed=0,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,
  scope='ONE successor: first builder exact; only second rebuild replaced by full strict typed ordered direct traversal. No extra scalar cache, limits/profile increase, reset, production integration, report change or grant.'))
print(json.dumps(dict(source=pin(S),handoff=handoff,contract=source_contract,API=api_pin,checks=len(checks),scientific_calls=0),sort_keys=True))
