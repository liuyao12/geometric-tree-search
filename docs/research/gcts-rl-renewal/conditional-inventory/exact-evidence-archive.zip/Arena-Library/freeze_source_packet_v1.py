"""Author Source/AST/unused-compile/inert-patch metadata. No arena calls."""
from pathlib import Path
import ast,difflib,hashlib,json,subprocess
D=Path('/private/tmp/gcts-incremental-arena-library-20261019')
S=D/'exact_evidence_arena_v1.py'
C=Path('/private/tmp/gcts-incremental-arena-ROOT-20261019/shared-contract-v3.json')
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def save(name,obj):
 p=D/name
 if p.exists():raise FileExistsError(str(p))
 p.write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n');return pin(p)
s=S.read_text();t=ast.parse(s,filename=str(S));compile(s,str(S),'exec',dont_inherit=True)
contract=json.loads(C.read_text());checks=[]
def ck(name,yes,scope):
 checks.append(dict(check=name,passed=bool(yes),scope=scope))
 if not yes:raise AssertionError(name)
ck('current_shared_contract',pin(C)['sha256']=='068cb432ad1b1d184f825fb61739826629355239523fbe048b2afeb71d75097d','Exact Root contractV3, not author-selected profile.')
ck('parse_compile_noeval',True,'AST and unused compile only; no Source imported or function/fixture called.')
ck('stdlib_only',[a.name for n in ast.walk(t) if isinstance(n,ast.Import) for a in n.names]==['json','math'],'No project/codec/inverse/Native/Model/compiler/renderer/search imports.')
ck('no_generator_functions',not any(isinstance(n,(ast.Yield,ast.YieldFrom)) for n in ast.walk(t)),'Custom _Cursor/_Stream, no PEP479 generator wrapper around delegated callbacks.')
classes={n.name:n for n in t.body if isinstance(n,ast.ClassDef)}
methods={n.name:n for n in classes['Arena'].body if isinstance(n,ast.FunctionDef)}
for name in ('capture','compose','view','iter_canonical','materialize','seal','to_wire','abort','statistics'):
 ck('public_method:'+name,name in methods,'Exact Arena method API; no integration.')
ck('required_limit_keys',set(ast.literal_eval(next(n.value for n in t.body if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='LIMIT_KEYS' for x in n.targets)).args[0]))==set(contract['limits']),'All17 caller-provided limit keys required; no hidden default or relaxation.')
ck('fresh_statistics','counters=dict(self._counts)' in s and 'authority=False' in s,'Fixed counter/size/lifecycle metadata, no node/backing/callback aliases.')
ck('private_own_limits',"type(error) is ArenaLimit and error._owner is _TOKEN" in s,'Foreign callback errors/limits not owned.')
ck('private_lifecycle_reentrancy',"type(error) is LifecycleError" in s and "type(error) is ReentrancyError" in s,'Private owner-token classification.')
ck('immutable_handles_views','class RootHandle(_Immutable)' in s and 'class View(_Immutable)' in s and 'class Sealed(_Immutable)' in s,'Ordinary Python immutable interface, no hostile private-write sandbox claim.')
ck('foreign_stale_handles',"type(h) is not RootHandle or h._owner is not self" in s,'Current committed label/ID map verified.')
ck('callback_passive_stats_only',"if self._in_callback:raise ReentrancyError" in s,'Charged public operations including close reject callback reentrancy; statistics does not call callbacks.')
ck('transaction_owned_next_state','self.nodes=list(s.nodes)' in s and 'self.buckets=dict(s.buckets)' in s and 'self.fragments=dict(s.fragments)' in s,'All changed containers copied; committed immutable nodes/tuple buckets stable.')
for name in ('capture','compose','seal'):
 raw=ast.get_source_segment(s,methods[name])
 ck('transaction_cleanup:'+name,'finally:self._busy=False' in raw,'Failure cleanup invokes no callbacks, exact error object reraised by normal unwinding.')
commit=ast.get_source_segment(s,methods['_commit_root'])
ck('root_publication_last',commit.index('self._finish()')<commit.index('self._state=prepared')<commit.index('return handle'),'No fallible callback/bookkeeping after sole committed-state assignment.')
seal=ast.get_source_segment(s,methods['seal'])
ck('seal_publication_last',seal.rfind('self._finish()')<seal.index('self._state=prepared')<seal.index('return result'),'Effective SEALED lifecycle from prepared nonempty documents; one publication slot.')
ck('sealed_write_rejection',"self._lifecycle!='ACTIVE' or self._state.documents" in s,'Abort valid from ACTIVE/SEALED, new writers rejected after seal.')
ck('whole_input_reconciliation',"if self._capture_value(value,t)!=i" in s,'Second complete typed reconstruction and full-equality interning, not a digest or caller bool.')
ck('eager_stream_snapshot',not any(isinstance(x,(ast.Yield,ast.YieldFrom)) for x in ast.walk(methods['iter_canonical'])) and 's,i=self._resolve(handle,path)' in ast.get_source_segment(s,methods['iter_canonical']),'Root/path resolution occurs at API call before iterator is returned.')
next_method=next(n for n in classes['_Stream'].body if isinstance(n,ast.FunctionDef) and n.name=='__next__')
next_raw=ast.get_source_segment(s,next_method)
ck('every_pull_lifecycle_first',next_raw.index('self.a._public()')<next_raw.index('if self._completed:raise StopIteration'),'Abort/reentrancy checked even after prior last chunk or successful completion.')
ck('stream_exact_foreign_error',"except BaseException:\n            self._failed=True;raise" in next_raw,'Foreign StopIteration/ValueError/RuntimeError propagate exact; stream cannot later qualify.')
ck('stream_completion_after_final_guard',"a._finish();return _END" in s and "self._completed=True;raise StopIteration" in next_raw,'Completion requires exhausted token machine, byte/occurrence check and final guard; caller must inspect completed flag.')
ck('stream_close_cleanup',"self._closed=True;self.cursor.stack.clear();self.pending.clear();self.token=b''" in s,'No callback, no completion from close; future pull lifecycle error.')
ck('complete_stream_accounting',"self.size!=self.expected[0] or self.cursor.occurrences!=self.expected[1]" in s,'Full bytes/multiplicity reconciliation; no prefix success.')
ck('small_fresh_materialization',"small limits may only tighten" in s and "value=[None]*len(n[1])" in s and "value={k:None for k,c in n[1]}" in s,'Fresh per occurrence/call; no mutable sharing.')
ck('bool_int_zero_float',"if kind is bool" in s and "if kind is int" in s and "self._float(number)!=n[1]" in s,'Typed nodes and exact canonical float lexical validation retain negative0.')
ck('scalar_unicode_metadata',"self._string_size(source_epoch);self._string_size(semantic_epoch)" in s and "self._string_size(label)" in s and "0xD800<=n<=0xDFFF" in s,'Epochs/root/document labels/keys and node strings bounded/scanned.')
ck('full_equality_intern',"if t.nodes[i]==n:return i" in s,'Hash only chooses candidate bucket; complete typed node equality decides.')
ck('summary_all_nodes',"self._bound('root_expanded_bytes',size);self._bound('depth',depth)" in s and "if tag not in ('array','object'):self._bound('scalar_bytes',size)" in s,'Every eager node including scalar/empty roots bounded before publication.')
ck('invocation_attempted_work',"self._observe('work',amount)" in s and "if self._counts['work']>self._limits['work']" in s,'Never reset at capture/compose/stream; failed work remains charged, counters observational.')
ck('weighted_cadence',"remaining=1024" in s and "while remaining==0 or left>remaining" in s,'At most1024 weighted units; upfront bulk callback scheduling, bounded4096-character windows.')
ck('bounded_chunks',"limits['chunk_bytes']>65536" in s and "take=min(a._limits['chunk_bytes']-len(self.pending)" in s,'Output copies/chunks bounded; external deadline remains necessary.')
ck('capacity_fallback',"t.cache_bytes+summary[0]>self._limits['cache_bytes']:return" in s,'Cache abstention keeps uncached ordinary traversal; does not prune data.')
ck('physical_logical_ledger',"logical+=s.summaries[i][0]+1" in s and "total=1  # Sole external physical newline" in s,'One newline per named logical document and one physical forest newline; body streams do not append newline.')
ck('all_catalogue_and_nodes_covered',"len(reached)!=len(s.nodes) or any(i not in reached for k,i in s.roots)" in s,'No caller catalogue filter or silent dropping of unused capture roots.')
ck('new_exact_forest_fields',"return dict(schema=WIRE_SCHEMA,version=VERSION,source_epoch=self._source_epoch," in s and "documents=list(s.documents),nodes=nodes)" in s,'Seven-field forest; fresh ordinary wire, full Source/semantic string epochs.')
# Narrow handlers contain only pure builtin conversion; no delegated callback.
for n in ast.walk(t):
 if isinstance(n,ast.Try) and n.handlers and not any(isinstance(h.type,ast.Name) and h.type.id=='BaseException' for h in n.handlers):
  calls=[x for b in n.body for x in ast.walk(b) if isinstance(x,ast.Call)]
  ck('pure_builtin_handler:'+str(n.lineno),all(isinstance(c.func,ast.Name) and c.func.id in ('str','float','int') for c in calls),'No callback placed inside caught conversion region.')
fp=D/'source-forward.patch';rp=D/'source-inverse.patch'
fp.write_text(''.join(difflib.unified_diff([],s.splitlines(True),fromfile=S.name,tofile=S.name)))
rp.write_text(''.join(difflib.unified_diff(s.splitlines(True),[],fromfile=S.name,tofile=S.name)))
w=D/'inert-patch';w.mkdir();q=w/S.name;q.write_text('')
f=subprocess.run(['patch','--batch','-F','0',q.name,str(fp)],cwd=w,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
ck('real_F0_forward',f.returncode==0 and q.read_bytes()==S.read_bytes(),'Inert scratch text only, no arena import/evaluation.')
r=subprocess.run(['patch','--batch','-F','0',q.name,str(rp)],cwd=w,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
ck('real_F0_inverse',r.returncode==0 and (not q.exists() or not q.read_bytes()),'Exact empty standalone preimage restored.')
common=dict(author_identity='/root/conventional_library',source_only=True,scientific_calls=0,component_calls=0,fixtures_executed=0,scientific_acceptance=False,actual_execution_authorized=False,status='FROZEN_SOURCE_ONLY_UNTESTED_NOT_ACTIVATED')
regions=[]
for n in ast.walk(t):
 if isinstance(n,(ast.FunctionDef,ast.ClassDef)):
  raw=ast.get_source_segment(s,n)
  regions.append(dict(name=n.name,line=n.lineno,end_line=n.end_lineno,raw_sha256=hashlib.sha256(raw.encode()).hexdigest(),AST_sha256=hashlib.sha256(ast.dump(n,include_attributes=False).encode()).hexdigest()))
audit=save('author-static-audit-v1.json',dict(common,schema='incremental-arena-author-static-audit-v1',source=pin(S),shared_contract=pin(C),checks=checks,check_count=len(checks),mismatches=0,regions=regions,forward=pin(fp),inverse=pin(rp),patch_stdout=[f.stdout,r.stdout],author_helper=pin(__file__),independent_Source_review=False))
api=save('API-v1.json',dict(common,schema='exact-evidence-arena-API-v1',source=pin(S),shared_contract=pin(C),version='exact-evidence-arena-v1',wire_schema='exact-evidence-forest-v1',execution_profile='invocation-total-transactional-arena-v1',
 signatures=dict(Arena='Arena(*,source_epoch,semantic_epoch,check,source_guard,limits)',capture='arena.capture(value,*,label)->RootHandle',compose='arena.compose(kind,children,*,label)->RootHandle; children exact list; object children list/tuple pairs',view='arena.view(handle,path=())->View or MISSING',iter_canonical='arena.iter_canonical(handle,path=())->custom BODY-only iterator; .completed mandatory after exhaustion',materialize='arena.materialize(handle,path=(),small_limits=None)->fresh small ordinary value',seal='arena.seal(documents)->Sealed; documents exact nonempty unique root-label list; complete internal catalogue used',to_wire='arena.to_wire(sealed)->fresh seven-field ordinary wire, no external newline',abort='arena.abort()->None; successful abort invalidates ACTIVE/SEALED future reads/pulls/exports',statistics='arena.statistics()->fresh passive bounded metadata, also inside callback/after abort',own_errors='is_own_limit/is_own_lifecycle/is_own_reentrancy(error)->bool'),
 limits=dict(required_keys=sorted(contract['limits']),current_prospective_values=contract['limits'],scope='Caller must supply every key. Root authenticates exact frozen profile. Module accepts other valid finite explicit limits but creates no grant or default allowance. Small limits keys bytes/occurrences may only tighten arena limits.'),
 views='View.kind,payload,node_id,expanded_bytes,occurrences,depth,keys,length are charged current-lifecycle reads. Payload for int/float is exact canonical lexical string; array/object payload is immutable typed references. Use materialize for fresh builtin values. MISSING is a distinct historical singleton. RootHandle.label is immutable historical metadata, never authority.',
 streams='Root/path owned eagerly at API call, no caller data after it. Every __next__ checks lifecycle/reentrancy; final pull reconciles full bytes/occurrences and guards before completed=True. Caller MUST require completed=True: a delegated StopIteration can terminate a for-loop without being ours. close is callback-free cleanup, does not qualify prefix. Any error makes stream terminal failed; no retry/salvage.',
 lifecycle='Effective state ACTIVE unless committed state.documents nonempty, then SEALED; _lifecycle ABORTED overrides both. Captures/compose/seal prepare independent next state and one _state assignment; no callbacks afterward. _busy is always restored without callbacks. Abort is itself charged/guarded; if it raises before completion it leaves lifecycle unchanged. Passive statistics always allowed.',
 ledger='Root summaries include body bytes/occurrences/depth. Seal charges each named document body+1LF once; catalogue is physical metadata only. All catalogue root IDs and all nodes must be reachable from union documents. Physical wire bytes include complete seven fields and1LF; returned wire and streams omit external newline. No duplicate labels/documents or reduced catalogue.',
 work='Invocation-total attempted work: per frame/node/ref/key/bound/read/token/part/copychunk; weighted character scans and copied bookkeeping item counts. Byte-copy/stream/fragment counters also reported. Weighted callback quantum1024 is upfront bulk scheduling, not elapsed-latency guarantee. Failed operations do not roll back work; committed capacity is separate.',
 errors='ArenaDataError(ValueError); ArenaLimit/LifecycleError/ReentrancyError with private own tokens. Every delegated exception, including StopIteration, preserves identity. Narrow builtin parse errors only wrapped as data errors. No pipeline/schema/Model/Native authority.',
 domain='Qualified strict builtin JSON domain, full typed equality, finite canonical float including negative0, scalar Unicode/no lone surrogates, object exact key order and ordered/repeated arrays. No RootHandle as captured value. Ordinary Python exclusive ownership, not hostile monkeypatch/concurrency protection.'))
argument=save('Source-argument-v1.json',dict(common,schema='incremental-arena-Source-argument-v1',source=pin(S),arguments=[
 'Typed exact-value induction: capture visits children before parents and interns complete immutable typed tuples; matching node IDs arise only after full tuple equality, never hash alone. Second whole typed traversal reconciles caller input. Compose refers only to committed same-arena roots; summaries preserve every repeated reference.',
 'Transactional publication: mutable next-state bookkeeping is prepared independently. All validation, limits, node/fragment construction, input comparisons, handle creation and final guards precede the single _state assignment. Normal Python MemoryError before publication leaves committed state intact; failed-attempt counters remain. Python/OS/hostile private mutation is not a formal isolation proof.',
 'Canonical inverse: cursor emits exact scalar JSON tokens, ordered array/object punctuation and child references. Cached fragments are built from the same exact independent typed children and checked by eager sizes. Every actual occurrence contributes full byte length and occurrence count; stream checks complete totals before completion.',
 'Lifecycle: public access rejects callback recursion and abort; sealed state rejects writers. Stream snapshot uses immutable committed state from call time; later appends cannot change it. Abort invalidates old streams/views. Close/failed/partial streams cannot complete. Foreign callback exceptions stay unhandled except bare cleanup/re-raise.',
 'Forest/ledger: seal independently rechecks typed uniqueness, scalar canonicality, prior refs, eager summaries, all metadata and whole document reachability. It uses all committed catalogue roots; logical documents and physical carrier/newline accounting are distinct. Representation never grants logical authority.'],unformalized_limits=['Source argument only, not independent mathematical/mechanized proof.','No arena/runtime fixture/performance qualification; all3whole inputs+71prior diagnostics and new arena tests still required under distinct reviewed subject.','Complete-next-state copies may increase transient memory and quadratic cumulative bookkeeping; no fit or improvement prediction.','Builtin hash/sort/JSON allocation latency and Python/stdlib/OS correctness remain conditional; hard external meter/deadlines needed.']))
source_contract=save('Source-contract-v1.json',dict(common,schema='incremental-arena-Source-contract-v1',source=pin(S),sources=dict(exact_evidence_arena=pin(S)),API=api,shared_contract=pin(C),author_static_audit=audit,Source_argument=argument,forward=pin(fp),inverse=pin(rp),
 ancestry=dict(qualified_encoder=pin('/private/tmp/gcts-exact-evidence-source-20261019/exact_evidence_table_v2.py'),memo=pin('/private/tmp/gcts-fragment-inverse-library-20261019/incremental-arena-API-memo-v1.json'),scope='New standalone Source derived from own encoder semantics/memo, not a raw-identical delegate. Author also wrote older registry/certifier/point/Model code; own static audit is not independent Source certification.'),
 review_ABI=dict(schema='incremental-arena-typed-Source-review-v1',scope='exact-evidence-arena-Source',required_fields=['source','sources','source_contract','author_identity','reviewer_identity','source_only','source_review_passed','scientific_calls','scientific_acceptance','actual_execution_authorized','findings']),
 qualification=['All3 original complete saved inputs and all71 prior diagnostics remain; Root supplies fresh independently authored forest inverse/harness and bounded once subjects. No current actual authorized.','New cross-capture equality, repeated ordered ports, compose/input mutation, failed transactions/MemoryError-before-publication, capacity/ownwork and monotone cost tests.','Foreign/stale/provisional handles, readonly views, exactbool indices, missing/null/0/false, seal coverage/root/doc duplicate/type/corruption, lifecycle and abort after seal.','Callback custom/RuntimeError/ValueError/StopIteration exact object identity at midstream AND completion; use explicit next() and require completed flag, not for-loop exhaustion alone. Callback charged read/write/stream/abort/close recursion rejects; statistics remains safe.','Eager iterator path/root snapshot, interyield input/append/abort mutation, close-before-complete, after-last-chunk abort, fresh materialization every occurrence/call.','Whole body bytewise equality with complete originals plus exactly1LF; all physical and logical budgets/cold work/closure/memory/current Source custody measured, both old negatives preserved.'],
 non_goals='No production registry/Model/search/Native/compiler/renderer changes, no new profile allowance, no proof or GCTS/RL advantage, no current report/publication edits. Existing exact dict/list consumers remain incompatible until a separately reviewed adapter.'))
handoff=save('handoff-v1.json',dict(common,schema='incremental-arena-library-handoff-v1',source=pin(S),sources=dict(exact_evidence_arena=pin(S)),source_contract=source_contract,API=api,shared_contract=pin(C),author_static_audit=audit,Source_argument=argument,static_checks=len(checks),inert_F0_directions=2,independent_Source_review='PENDING',summary='Standalone transactional multi-root exact evidence arena/views/streams/forest export, invocation-total work and separate physical/logical ledgers. Source-only/unexecuted; no integration or grants.'))
print(json.dumps(dict(source=pin(S),handoff=handoff,API=api,contract=source_contract,audit=audit,checks=len(checks)),indent=2))
