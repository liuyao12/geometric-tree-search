"""Independent raw/AST/inert-text review only; never imports Root components."""
from pathlib import Path
import ast,difflib,hashlib,json,subprocess
D=Path('/private/tmp/gcts-incremental-arena-library-20261019')
R=Path('/private/tmp/gcts-incremental-arena-ROOT-20261019')
W1=R/'qualify_arena_worker_v1.py';W2=R/'qualify_arena_worker_v2.py'
F=R/'forest_qualification_fixtures_v1.py';I=R/'independent_forest_inverse_v4.py'
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def save(name,obj):
 p=D/name
 if p.exists():raise FileExistsError(str(p))
 p.write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n');return pin(p)
old=W1.read_text();new=W2.read_text();f=F.read_text();trees={}
for p,s in ((W1,old),(W2,new),(F,f)):
 trees[p.name]=ast.parse(s,filename=str(p));compile(s,str(p),'exec',dont_inherit=True)
checks=[]
def ck(name,yes,scope):
 checks.append(dict(check=name,passed=bool(yes),scope=scope))
 if not yes:raise AssertionError(name)
ck('exact_W1_pin',pin(W1)['sha256']=='ddc2f0b2f3b59949bf79686f4bf222afaf172007c5efef37bd14a293262ce0bf','Historical unexecuted worker contains concrete join blocker.')
ck('exact_W2_pin',pin(W2)['sha256']=='a40bc72cf7df8716b89090e022b22bb2f4afa00f2b8750f0f1559b4f37d9b958','Root-owned narrow successor.')
ck('exact_Root_fixture_pin',pin(F)['sha256']=='033a160a89578077464cf0bb9a74ecfbbcfceed635d33e76ac4e474ec7cd9f25','Root-owned22 fixture module.')
ck('compile_without_eval',True,'Three raw Sources AST parsed and unused compiled; none imported/evaluated.')
names=ast.literal_eval(next(n.value for n in trees[F.name].body if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='EXPECTED_FOREST_FIXTURES' for x in n.targets)))
ck('Root_22_literal_unique',len(names)==len(set(names))==22,'No diagnostic result claims; current finite name inventory only.')
ck('W1_ABI_blocker_exact',"all(x['passed']is True for x in fixture_rows)" in old,'Library33 uses status=passed and no passed key; Root acknowledged and authored W2.')
ck('W2_group_counts',all(x in new for x in ("len(old_tests.EXPECTED_FIXTURES)==71","len(arena_tests.EXPECTED_ARENA_FIXTURES)==33","len(forest_tests.EXPECTED_FOREST_FIXTURES)==22","len(expected)==126")),'Old71 then Library33 then Root22 exact distinct combined order.')
ck('W2_legacy_Root_bool_join',"all(x['passed']is True for x in fixture_rows[:71]+fixture_rows[104:])" in new,'No status coercion/packet relabeling for old or Root cases.')
ck('W2_Library_exact_packet_join',"set(x)=={'schema','name','status','scope','observed','authority'}" in new and "x['status']=='passed'and x['authority']is False for x in fixture_rows[71:104]" in new,'Only Library public ABI inspected; no review of own fixture semantics.')
ck('W2_complete_return_join',"arena_return['count']==33" in new and "arena_return['completed']==list(arena_tests.EXPECTED_ARENA_FIXTURES)" in new,'Complete Library return bound without synthesizing missing rows.')
ck('W2_group_order_and_names',"[x['name']for x in fixture_rows]==expected and len(fixture_rows)==126" in new,'No omitted/duplicated/reordered diagnostic permitted.')
ck('Root_external_error_latch',"except BaseException as error:pending[0]=error;raise" in f and "if pending[0] is not None:raise pending[0]" in f,'External Root tick/deadline cannot count as expected malformed or sentinel outcome.')
ck('Root_manual_marker_identity',"expect(lambda:next(it),lambda e:e is marker)" in f and "expect(until_marker,lambda e:e is marker)" in f,'Explicit next for foreign StopIteration; exact identity rather than for-loop end.')
ck('Root_completion_required',"need(stream.completed,'exhaustion alone never qualifies')" in f and "need(not it.completed,'foreign exception never completed')" in f,'Normal drain and fault cases distinguish bytes/end from completion.')
ck('Root_late_marker_stage',"obs.get('last_operation')=='document_completion'" in f and "b''.join(pieces)==expected" in f,'Completion marker must happen after all expected body bytes; observer used only as test trigger.')
ck('Root_public_owned_observer_mutation',"obs.clear();obs.update(prepared=True,wire_canonical_bytes=-1)" in f and "snapshot['documents']['whole']['completed']=True" in f,'Mutates public observer/snapshot and actual input carrier, never inverse private backing.')
ck('Root_callback_read_reentrancy',"for operation in [lambda:q.documents,lambda:q.catalogue,lambda:q.iter_document('whole')]" in f and "expect(operation,inverse.is_own_reentrancy)" in f,'Passive statistics allowed, charged public reads/stream calls rejected without work inflation.')
ck('Root_full_literal_oracle',"bytes(out)==expected" in f and "wire_canonical_bytes']==len(canonical(w))+1" in f,'Independent small full values/physical canonical formula, not digest-only validation.')
ck('Root_multiplicity_oracle',"aggregate_document_value_occurrences']==7" in f and "aggregate_document_value_occurrences']==10" in f,'Declared object+two array occurrences and extra logical document count inspected arithmetically.')
ck('Root_cache_paths',"cache_capacity_fallbacks']>0" in f and "cache_entries']==(0 if offset==9 else 1)" in f,'Disabled/one-entry fallback receipts demanded, no performance inference.')
ck('Root_coverage_and_final_pull',"w['documents']=['pair']" in f and "last_chunk_without_final_pull_not_admitted=True" in f,'Unused catalogue reject; last bytes followed by close remain incomplete.')
main=next(n for n in trees[W2.name].body if isinstance(n,ast.FunctionDef) and n.name=='main')
arena_calls=[n for n in ast.walk(main) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Name) and n.func.value.id=='arena_module' and n.func.attr=='Arena']
ck('one_main_arena',len(arena_calls)==1 and new.index('arena=arena_module.Arena(')<new.index("for item in plan['inputs']:"),'One arena before whole-input loop; diagnostic arenas explicitly separate.')
ck('whole_original_not_subset',"original=raw(item['input'])" in new and "value=ordinary_load(original)" in new and "arena.capture(value,label=item['id'])" in new,'Full pinned raw file strictly parsed/captured, no slice/resampling/Model parse.')
ck('strict_json_keys_and_finite',"object_pairs_hook=strict_object,parse_constant=bad_constant" in new,'Duplicate raw keys and nonfinite constants rejected.')
ck('main_limits_not_reset',new.count('arena=arena_module.Arena(')==1 and "prepared=inverse.prepare_forest(decoded,tick,inverse_limits,statistics=statistics)" in new,'Single main arena and one prepared saved forest, no per-document inverse work reset.')
ck('exact_clock_profile',all(x in new for x in ('work=began+180000000000;overall=began+210000000000','memory_bytes=1073741824','result_bytes=134217728','expanded_bytes=134217728')),'Fixed Source-entry endpoints; final worker-exit/RAM gates external runner responsibilities.')
ck('full_header_literals_and_Source_cost',"source_epoch=canonical({k:raw(d).decode('utf8')for k,d in descriptors.items()}).decode('utf8')" in new and "wire['source_epoch']==source_epoch and wire['semantic_epoch']==semantic_epoch" in new,'Full guarded Source text/current input+limit/name metadata retained as ordinary literal epochs, no execution through carrier.')
ck('one_physical_forest',"forest=old_tests.streamed_file(actual/'complete-evidence-forest.json'" in new and "aggregate physical forest and result cap" in new,'One full forest + result metadata counted physically, not one forest per document.')
ck('logical_once_and_catalogue_complete',"expanded+=len(original)" in new and "arena_stats['logical_document_bytes']==expanded" in new and "wire['documents']==[r['id']for r in plan['inputs']]" in new,'Each full logical body+LF once; all3 capture labels bound to forest documents.')
ck('saved_wire_fresh_inverse',"decoded=ordinary_load(raw(forest))" in new and "prepared=inverse.prepare_forest(decoded" in new,'Fresh full saved physical carrier, not trusted encoder object or prefix.')
ck('main_both_completed_flags',"need(stream.completed,'arena explicit final completion required')" in new and "need(stream.completed,'independent explicit final completion required')" in new,'Bytes alone insufficient; final completion required independently.')
ck('full_independent_byte_and_occurrence',"copied_body_bytes']==stats['emitted_body_bytes']==len(original)-1" in new and "stats['stream_value_occurrences']==stats['logical_value_occurrences']" in new,'Full original body plus external LF comparison from old helper, exact independent counts joined.')
ck('results_only_after_complete_inverse',new.index('results.append(dict(captured')>new.index("need(stats['stream_value_occurrences']==stats['logical_value_occurrences']"),'No captured-only packet relabeled independently complete.')
ck('honest_failure_prefix',"completed_input_packets=results,captured_input_prefix=capture_prefix,completed_fixture_prefix=fixture_rows,published_forests=forests" in new and "representation_accepted=False" in new,'Every failure inactive; current stage/counters retained, in-progress capture not fabricated complete.')
ck('no_scientific_claims',"Native_calls=0,search_calls=0,Model_calls=0" in new and "No integrated producer/search RAM claim" in new,'Ordinary evidence component only; no theorem/search/GCTS/RL result.')
retained=[]
oldfunc={n.name:n for n in trees[W1.name].body if isinstance(n,ast.FunctionDef)}
for n in trees[W2.name].body:
 if isinstance(n,ast.FunctionDef) and n.name!='main':
  o=oldfunc[n.name]
  ck('unchanged_helper:'+n.name,ast.get_source_segment(old,o)==ast.get_source_segment(new,n) and ast.dump(o,include_attributes=False)==ast.dump(n,include_attributes=False),'Inherited exact helper; independently traced API use, not re-proving stdlib/OS.')
  retained.append(n.name)
patches=[];stdout=[]
for name,before,after in [('worker-v1-v2',old,new),('Root-forest-fixtures','',f)]:
 folder=D/('review-inert-'+name);folder.mkdir();target=folder/'component.py';target.write_text(before)
 fp=folder/'forward.patch';rp=folder/'inverse.patch'
 fp.write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=target.name,tofile=target.name)))
 rp.write_text(''.join(difflib.unified_diff(after.splitlines(True),before.splitlines(True),fromfile=target.name,tofile=target.name)))
 x=subprocess.run(['patch','--batch','-F','0',target.name,str(fp)],cwd=folder,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 ck('inert_F0_forward:'+name,x.returncode==0 and target.read_text()==after,'Actual scratch text patch only; no Root component calls.')
 y=subprocess.run(['patch','--batch','-F','0',target.name,str(rp)],cwd=folder,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 ck('inert_F0_inverse:'+name,y.returncode==0 and (target.read_text() if target.exists() else '')==before,'Exact text preimage restored.')
 patches.extend([pin(fp),pin(rp)]);stdout.extend([x.stdout,y.stdout])
common=dict(author_identity='/root',reviewer_identity='/root/conventional_library',source_only=True,scientific_calls=0,component_calls=0,fixtures_executed=0,scientific_acceptance=False,actual_execution_authorized=False)
negative=save('Root-fixture-worker-review-v1-negative.json',dict(common,schema='incremental-arena-Root-worker-Source-review-v1',source=pin(W1),source_review_passed=False,findings=[dict(id='W1-FIXTURE-PACKET-ABI',severity='BLOCKER',line=84,detail='Worker requires passed key on all126 packets, but Library33 frozen ABI has status=passed with no passed key. KeyError prevents the whole-input phase. Root authored W2; no RootSource edited by reviewer.')],status='HISTORICAL_UNEXECUTED_SOURCE_BLOCKED',scope='Root worker fixture join only; no own arena/fixture Source certification.'))
audit=save('Root-fixture-worker-review-audit-v2.json',dict(common,schema='incremental-arena-Root-fixture-worker-Source-audit-v2',checks=checks,check_count=len(checks),mismatches=0,sources=dict(worker=pin(W2),Root_fixtures=pin(F)),inverse_API_only=pin(I),retained_raw_AST_helpers=retained,patches=patches,patch_stdout=stdout,compile_noeval=3,author_helper=pin(__file__)))
review=save('Root-fixture-worker-review-v2.json',dict(common,schema='incremental-arena-Root-fixture-worker-typed-Source-review-v2',source=pin(W2),sources=dict(worker=pin(W2),Root_fixtures=pin(F)),source_review_passed=True,historical_negative=negative,current_audit=audit,inverse_API_only=pin(I),shared_contract=pin(R/'shared-contract-v3.json'),findings=[dict(id='W1-FIXTURE-PACKET-ABI',status='RESOLVED_IN_PRESERVED_W2',resolution='Strict71+33+22 exact order/count, original Library schema/status/authority, complete return join; no packet relabeling or weakened completeness.')],
 scope='Distinct review of Root-authored forest diagnostic module033a and workerW2a40b: fixture oracle/error origin/completion, whole-input/cost/custody/ledger and failure-prefix semantics. Not a review of Library-owned arena/Library33 fixture bodies, nor full independent-inverse soundness/outer/plan/grant review.',
 ancestry='Reviewer authored arena, Library33 fixtures, older encoder/registry/certifier/point/Model/driver ancestry. Author Root owns the current worker, forest fixtures and independent inverse. Shared wire/ABI coordination disclosed. Own components require Control genuine separate Source peer.',
 conditions=['Prospective/full final-grant review must bind exact3 original full raw inputs, all auxiliary current Sources and finite arena/inverse limits. Worker accepts plan.inputs and only finally requires3; Source review alone authenticates no selected input corpus.','Raw Source/import/runtime loader/stdlib/OS trust and actual worker-exit/180positive/210closure/1GiB/aggregate128MiB/log/group gates remain external Root responsibilities; no activation authorized.','captured_input_prefix means captures with completed encoder/body comparison. An in-progress capture/stream is not retained as a complete packet; failure context/arena counters show reached stage, no missing object recovery.','Legacy71 coverage does not include StopIteration; old finite results remain scoped. New explicit marker/completed tests are unexecuted Source, not runtime qualification.'],
 unperformed=['No module/fixture/arena/inverse/Native/Model/compiler/search/codec/renderer imported, called or replayed.','No current actual resource/data acceptance, no universal malformed/mutation/error/cost coverage, no memory/speed/proof advantage.','No complete new declaration/40subject/authorization/outerRunner review in this receipt.']))
print(json.dumps(dict(negative=negative,review=review,audit=audit,checks=len(checks),inert_F0_directions=4),indent=2))
