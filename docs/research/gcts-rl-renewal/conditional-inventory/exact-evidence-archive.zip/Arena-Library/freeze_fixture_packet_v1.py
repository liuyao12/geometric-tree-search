"""Source metadata/AST/unused compile/inert patches only; no fixtures run."""
from pathlib import Path
import ast,difflib,hashlib,json,subprocess
D=Path('/private/tmp/gcts-incremental-arena-library-20261019')
S=D/'arena_qualification_fixtures_v1.py'
A=D/'exact_evidence_arena_v1.py'
C=Path('/private/tmp/gcts-incremental-arena-ROOT-20261019/shared-contract-v3.json')
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def save(name,obj):
 p=D/name
 if p.exists():raise FileExistsError(str(p))
 p.write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n');return pin(p)
s=S.read_text();t=ast.parse(s,filename=str(S));compile(s,str(S),'exec',dont_inherit=True)
names=ast.literal_eval(next(n.value for n in t.body if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='EXPECTED_ARENA_FIXTURES' for x in n.targets)))
run=next(n for n in t.body if isinstance(n,ast.FunctionDef) and n.name=='run_arena_fixtures')
checks=[]
def ck(name,yes,scope):
 checks.append(dict(check=name,passed=bool(yes),scope=scope))
 if not yes:raise AssertionError(name)
ck('AST_compile_no_eval',True,'No fixture/module/arena/codec/inverse/Native evaluated or imported.')
ck('stdlib_json_math_only',[a.name for n in ast.walk(t) if isinstance(n,ast.Import) for a in n.names]==['json','math'],'No scientific imports.')
ck('exact_entry',[a.arg for a in run.args.args]==['arena_module','limits','tick','guard','rows','context'],'Six supplied module/config/callback/prefix/context inputs.')
ck('literal_33_distinct_names',type(names) is tuple and len(names)==33 and len(set(names))==33 and all(type(n) is str for n in names),'Finite declared inventory, not reported executed.')
ck('no_arena_private_backing_access',not any(isinstance(n,ast.Attribute) and n.attr.startswith('_') and n.attr!='__name__' for n in ast.walk(t)),'Only builtin exception type.__name__ metadata allowed; no arena private backing/token/limit/frame access.')
ck('root_callback_fault_latch','if external_fault[0] is None:external_fault[0]=error' in s and 'if external_fault[0] is not None:raise external_fault[0]' in s,'Root clock/Source faults cannot count as expected diagnostic errors.')
ck('classification_after_external_fault','no_external_fault();return error' in s,'Every generic expected-error helper checks Root fault origin before classification.')
ck('passed_packet_after_final_checkpoint','checkpoint();observation=action();checkpoint()' in s and s.index('checkpoint();observation=action();checkpoint()')<s.index('rows.append(packet)'),'Incomplete/exception case never appends a passed row.')
ck('owned_limits_construct_only',"cap=dict(limits)" in s and "fixture limits may only tighten" in s,'Overrides fixed at construction; caller-input mutation probe tests ownership, not private limit changes.')
ck('drain_completed_mandatory',"_need(stream.completed is True,'loop exhaustion without owned completion')" in s,'Normal StopIteration cannot substitute for completed flag.')
ck('foreign_stop_manual_next',"identical(lambda:next(stream),fault)" in s,'Foreign StopIteration matrix uses explicit next and exact object identity.')
ck('six_foreign_classes',all(x in s for x in ("FixtureSentinel('custom')","RuntimeError('runtime')","ValueError('value')","StopIteration('stop')","GeneratorExit('generator-exit')","SystemExit('system-exit')")),'Finite six-class sentinel set, not every Python BaseException proof.')
ck('all_four_error_boundaries',all(n in names for n in ('foreign_capture_exception_identity_matrix','foreign_precommit_exception_identity_matrix','foreign_stream_early_exception_identity_matrix','foreign_stream_completion_exception_identity_matrix')),'Capture/check, second guard/precommit, first and completion stream boundaries.')
ck('completed_remains_false_on_foreign',"_need(stream.completed is False,'foreign stream exception qualified completion')" in s,'Full prior bytes alone cannot qualify failed final callback.')
ck('actual_returned_wire_mutated',"wire['nodes'][0][0]='corrupt'" in s and "_body(a.to_wire(sealed))==pristine" in s,'Actual public returned carrier mutation, not mutation of a separate copy only.')
ck('actual_caller_and_materialized_mutation',"value['x'][1]['y']=True" in s and "x[0]['x'].append(2)" in s,'Owned caller/input and per-occurrence/call mutable isolation.')
ck('eager_snapshot_and_appends',"path[0]='missing';a.capture" in s,'Stream path snapshot captured before later path mutation and arena append.')
ck('physical_logical_newline_ledgers',"stats['logical_document_bytes']==len(_body(value))+1" in s and "stats['physical_wire_bytes']==len(_body(wire))+1" in s,'Complete named result counted once; catalogue physical only.')
ck('equal_documents_count_twice',"a.statistics()['logical_document_bytes']==4" in s,'Two distinct named0 documents each body+LF.')
ck('cache_disabled_partial_full',"{'cache_bytes':0,'cache_entries':0}" in s and "{'cache_bytes':4,'cache_entries':1}" in s and "complete_fragment_hits=1" in s,'Disabled, one-entry full/partial and normal complete-root cache paths declared.')
ck('all_abort_boundaries',all(n in names for n in ('active_abort_before_first_pull','active_abort_midstream','active_abort_after_last_chunk','active_abort_after_complete','sealed_abort_invalidates_reads_exports_streams')),'ACTIVE/SEALED and last-chunk/completed distinctions.')
ck('callback_both_channels_stats_close',"for channel in ('check','guard')" in s and "lambda:stream.close()" in s and "snapshot['counters']['fixture_mutation']=1" in s,'Both callbacks allow passive owned stats only; charged operations/close reject.')
ck('finite_no_universal_claim','no universal correctness, allocation-failure, hostile/private mutation, concurrency, pipeline or theorem claim' in s,'No unperformed runtime/universal coverage claim.')
ck('current_arena_pin',pin(A)['sha256']=='cf887ed9cb04866596a56a5d9261f93c84613eb3aede359223813bb644dccd09','Bound exact unexecuted arena Source; separate independent review needed.')
fp=D/'fixtures-forward.patch';rp=D/'fixtures-inverse.patch'
fp.write_text(''.join(difflib.unified_diff([],s.splitlines(True),fromfile=S.name,tofile=S.name)))
rp.write_text(''.join(difflib.unified_diff(s.splitlines(True),[],fromfile=S.name,tofile=S.name)))
w=D/'fixtures-inert-patch';w.mkdir();q=w/S.name;q.write_text('')
f=subprocess.run(['patch','--batch','-F','0',q.name,str(fp)],cwd=w,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
ck('real_F0_forward',f.returncode==0 and q.read_bytes()==S.read_bytes(),'Inert scratch text only.')
r=subprocess.run(['patch','--batch','-F','0',q.name,str(rp)],cwd=w,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
ck('real_F0_inverse',r.returncode==0 and (not q.exists() or not q.read_bytes()),'Exact empty preimage restored.')
common=dict(author_identity='/root/conventional_library',source_only=True,scientific_calls=0,component_calls=0,fixtures_executed=0,scientific_acceptance=False,actual_execution_authorized=False,status='FROZEN_SOURCE_ONLY_UNEXECUTED')
audit=save('fixtures-author-static-audit-v1.json',dict(common,schema='arena-fixtures-author-static-audit-v1',source=pin(S),arena_source=pin(A),checks=checks,check_count=len(checks),mismatches=0,forward=pin(fp),inverse=pin(rp),patch_stdout=[f.stdout,r.stdout],author_helper=pin(__file__),independent_Source_review=False,author_metadata_preflight='An initial overbroad AST assertion flagged builtin exception type.__name__ as private arena access. Metadata assertion narrowed to exempt that metadata attribute; fixture Source unchanged, no fixture evaluated, no earlier frozen packet.'))
api=save('fixtures-API-v1.json',dict(common,schema='arena-fixtures-API-v1',source=pin(S),entry='run_arena_fixtures(arena_module,limits,tick,guard,rows,context)',VERSION='arena-qualification-fixtures-v1',EXPECTED_ARENA_FIXTURES=list(names),count=len(names),passed_packet='One arena-finite-diagnostic-v1 packet after complete action and final Root tick+guard, fields name/status/scope/observed/authorityFalse. No packet on incomplete case.',return_packet='arena-finite-fixtures-return-v1 complete literal names/count/coverage/authorityFalse, only after all33.',exceptions='Any external Root tick/guard error latched/re-raised exact before expected-fixture classification. Unexpected errors propagate; no timeout/UNKNOWN salvage or loop-end-only completion.',contexts='context updated with stage=ARENA_FIXTURES and current fixture, None after complete; rows includes preceding old diagnostics untouched.',module_scope='Injected current arena module only; Root authenticates full Source/runtime/epochs. This module imports only stdlibjson/math.'))
contract=save('fixtures-Source-contract-v1.json',dict(common,schema='arena-fixtures-Source-contract-v1',source=pin(S),sources=dict(arena_fixtures=pin(S)),arena_source=pin(A),shared_contract=pin(C),API=api,author_static_audit=audit,forward=pin(fp),inverse=pin(rp),review_ABI=dict(schema='arena-fixtures-typed-Source-review-v1',scope='arena-qualification-fixtures-Source',required_fields=['source','sources','source_contract','author_identity','reviewer_identity','source_only','source_review_passed','scientific_calls','scientific_acceptance','actual_execution_authorized','findings']),
 preservation='Root retains all71 old diagnostics FIRST, these33 next, its separate independent forest malformed/callback cases, then all3 whole original inputs in ONE arena. No input subset, failed-table reuse, new allowance or actual authorized by this packet.',
 limits='Each diagnostic has a fresh arena with explicit complete base limits or fixed tighter/cache-disabled variants from Source. Caller-limit mutation is an ownership probe only. All work still charged to single outer original180/210/1GiB/128MiB encoded ANDexpanded profile; Source adds no clock or reset.',
 coverage_limits=['Source/AST/unused compile/inertF0 only; no fixture/arena call or reported diagnostic PASS.','Finite public-interface cases; no exhaustive arbitrary AST/value/exception/mutation coverage.','Public constructor refusal/foreign-owner/abort handles tested; actual provisional handle non-exposure relies on Source review, not forged private state.','No arbitrary MemoryError injection, hostile private writes, concurrency, new pipeline/Model/native proof/rollback claim.','Precommit/late completion targets current exact public guard call sequence, so incompatible successors need new reviewed Source fixture bindings.','Cache counters only show these finite declared paths; no runtime fit, compression, memory/speed or theorem advantage is inferred.','Author wrote arena and fixtures; independent Control Source review and Root independently authored inverse/harness remain mandatory.']))
handoff=save('fixtures-handoff-v1.json',dict(common,schema='arena-fixtures-library-handoff-v1',source=pin(S),sources=dict(arena_fixtures=pin(S)),source_contract=contract,API=api,author_static_audit=audit,arena_source=pin(A),shared_contract=pin(C),literal_fixture_names=list(names),fixture_count=len(names),static_checks=len(checks),inert_F0_directions=2,independent_Source_review='PENDING'))
print(json.dumps(dict(source=pin(S),handoff=handoff,API=api,contract=contract,audit=audit,checks=len(checks),fixtures=len(names)),indent=2))
