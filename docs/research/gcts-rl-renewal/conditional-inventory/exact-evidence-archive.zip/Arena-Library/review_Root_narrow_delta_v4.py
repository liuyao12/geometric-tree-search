"""Metadata-only narrow Source delta review. No fixture/component execution."""
from pathlib import Path
import ast,difflib,hashlib,json,subprocess
D=Path('/private/tmp/gcts-incremental-arena-library-20261019');R=Path('/private/tmp/gcts-incremental-arena-ROOT-20261019')
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def load(p):return json.loads(Path(p).read_text())
def save(n,v):
 p=D/n
 if p.exists():raise FileExistsError(str(p))
 p.write_text(json.dumps(v,sort_keys=True,indent=2)+'\n');return pin(p)
wp=R/'qualify_arena_worker_v2.py';wn=R/'qualify_arena_worker_v3.py'
fp=R/'forest_qualification_fixtures_v1.py';fn=R/'forest_qualification_fixtures_v2.py'
a=wp.read_text();b=wn.read_text();x=fp.read_text();y=fn.read_text()
checks=[]
def ck(n,v,s):
 checks.append(dict(check=n,passed=bool(v),scope=s))
 if not v:raise AssertionError(n)
ck('exact_workerW3',pin(wn)['sha256']=='9b03f1859e324ec9e3c8bd2636e57481fdd17b2e7ccf1245e31169f1c296d04a','Current Root successor Source.')
ck('exact_forestV2',pin(fn)['sha256']=='0ec9431cd9d9b362949a239f4e953176ca258af8aabcbec4d37d7e0a17a6a4e7','Current Root fixture Source.')
for p,s in ((wn,b),(fn,y)):
 ast.parse(s,filename=str(p));compile(s,str(p),'exec',dont_inherit=True)
ck('two_unused_compiles',True,'No Source/module/fixture/inverse/arena function executed.')
restored=b.replace("VERSION='incremental-arena-qualification-worker-v3-127-diagnostics'","VERSION='incremental-arena-qualification-worker-v2-strict-fixture-joins'").replace('len(forest_tests.EXPECTED_FOREST_FIXTURES)==23','len(forest_tests.EXPECTED_FOREST_FIXTURES)==22').replace('len(expected)==127','len(expected)==126').replace('len(fixture_rows)==127','len(fixture_rows)==126').replace('Root23 success booleans','Root22 success booleans').replace('dict(retained=71,arena=33,forest=23)','dict(retained=71,arena=33,forest=22)')
ck('whole_worker_raw_inverse',restored==a,'Only VERSION, declared127 total/Root23 counters and explanatory text changed.')
ck('whole_worker_AST_inverse',ast.dump(ast.parse(restored),include_attributes=False)==ast.dump(ast.parse(a),include_attributes=False),'Every main input/custody/limit/completion/guard/failure path inherited exactly.')
start=y.index('    enter(EXPECTED_FOREST_FIXTURES[22]);');end=y.index('    need([r[\'name\']for r in rows[-len(EXPECTED_FOREST_FIXTURES):]]',start)
added=y[start:end]
fr=(y[:start]+y[end:]).replace("'forest_completion_requires_final_pull','forest_scalar_token_measure_boundary')","'forest_completion_requires_final_pull')")
ck('whole_forest_raw_inverse',fr==x,'Old22 fixture function bodies/helpers/callback oracles raw exact.')
ck('whole_forest_AST_inverse',ast.dump(ast.parse(fr),include_attributes=False)==ast.dump(ast.parse(x),include_attributes=False),'New23rd case and literal name only.')
def names(s):
 t=ast.parse(s)
 return ast.literal_eval(next(n.value for n in t.body if isinstance(n,ast.Assign) and any(isinstance(q,ast.Name) and q.id=='EXPECTED_FOREST_FIXTURES' for q in n.targets)))
ck('names_append_one',names(y)[:-1]==names(x) and len(names(y))==23 and names(y)[-1]=='forest_scalar_token_measure_boundary','No prior diagnostic removed or renamed.')
ck('new_boundary_semantics',all(z in added for z in ("['str','\\n'*3]","dict(scalar_bytes=7)","e.reason=='scalar bytes'","dict(scalar_bytes=8)","raw_utf8_bytes=3,canonical_quoted_bytes=8")),'Three newline scalars:3 rawUTF8,2quotes+3*2 escaped bytes=8;7reject/8accept. All metadata e/s/rootlabel s have quoted size3.')
ck('new_case_complete_literal_oracle',"r=drain(p,'s',canonical('\\n'*3))" in added,'Full canonical body equality plus inherited drain completed flag, not mere status.')
ck('strict_schema_joins_retained',"set(x)=={'schema','name','status','scope','observed','authority'}" in b and "fixture_rows[71:104]" in b and "fixture_rows[:71]+fixture_rows[104:]" in b,'Original71/Library33/Root23 schemas remain distinct and strict.')
c3=R/'shared-contract-v3.json';c4=R/'shared-contract-v4.json'
ck('numeric_limits_unchanged',load(c3)['limits']==load(c4)['limits'],'Only scalar measurement semantics clarified, no numeric allowance raised.')
packet=R/'ten-Source-packet-v2.json';p=load(packet)
ck('packet_exact_current',pin(packet)['sha256'].startswith('10936f34') and pin(packet)['bytes']==13526,'Root current10Source metadata descriptor.')
for role,d in p['sources'].items():ck('raw_packet_source:'+role,pin(d['path'])==d,'Raw custody only; not own arena/fixtures or fullinverse Source certification.')
ck('packet_group_counts',p['fixture_group_counts']==dict(retained=71,arena=33,forest=23) and len(p['required_fixture_names'])==127,'Current complete127 names/counters.')
patches=[];outputs=[]
for label,old,new in [('worker-W2-W3',a,b),('forest-fixtures-V1-V2',x,y)]:
 w=D/('delta-review-inert-'+label);w.mkdir();q=w/'component.py';q.write_text(old)
 f=w/'forward.patch';r=w/'inverse.patch'
 f.write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=q.name,tofile=q.name)))
 r.write_text(''.join(difflib.unified_diff(new.splitlines(True),old.splitlines(True),fromfile=q.name,tofile=q.name)))
 z=subprocess.run(['patch','--batch','-F','0',q.name,str(f)],cwd=w,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 ck('actual_inert_forward:'+label,z.returncode==0 and q.read_text()==new,'Scratch Source text only.')
 zz=subprocess.run(['patch','--batch','-F','0',q.name,str(r)],cwd=w,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 ck('actual_inert_inverse:'+label,zz.returncode==0 and q.read_text()==old,'Exact oldSource restored without evaluating it.')
 patches.extend([pin(f),pin(r)]);outputs.extend([z.stdout,zz.stdout])
common=dict(author_identity='/root',reviewer_identity='/root/conventional_library',source_only=True,scientific_calls=0,component_calls=0,fixtures_executed=0,scientific_acceptance=False,actual_execution_authorized=False)
audit=save('Root-fixture-worker-delta-audit-v4.json',dict(common,schema='Root-fixture-worker-narrow-delta-audit-v4',checks=checks,check_count=len(checks),mismatches=0,patches=patches,patch_stdout=outputs,unused_compiles=2,author_helper=pin(__file__)))
review=save('Root-fixture-worker-delta-review-v4.json',dict(common,schema='incremental-arena-Root-fixture-worker-narrow-Source-review-v4',source_review_passed=True,source=pin(wn),sources=dict(worker=pin(wn),Root_fixtures=pin(fn)),baseline_review=pin(D/'Root-fixture-worker-review-v3.json'),current_packet=pin(packet),shared_contract=pin(c4),inverse_API_delta_only=p['sources']['inverse'],audit=audit,findings=[],
 scope='Narrow disjoint Root W2-to-W3/forestfixturesV1-toV2 delta only: old22 bodies exact, one quoted-scalar boundary case,127group joins, same complete3input/custody/resource/failure paths. InverseV5 consulted only for API scalar-measure boundary; Control independently reviews full10Source group.',
 ancestry='Library authored arena/Library33 fixtures and older adapters; no self-certification of those bodies. Root owns current worker/forestfixtures/inverse. Previous scoped Source conditions and unexecuted limitations remain.',
 limitations=['No fixture, arena, inverse or scientific code imported/evaluated. No runtime scalar-boundary result claimed.','Exact original3 raw inputs, full limits/Source/runtime bindings, outer/once/plan/grant/resource and actual acceptance remain separate reviews.','Known historic W1join blocker and oldinverse scalar mismatch remain preserved, unexecuted currentSource predecessors. No report/archive change or activation authorized.']))
print(json.dumps(dict(review=review,audit=audit,checks=len(checks),inert_F0_directions=4),indent=2))
