"""Retained metadata and raw Source design only; no component replay."""
from pathlib import Path
import hashlib,json
D=Path('/private/tmp/gcts-incremental-arena-library-20261019')
R=Path('/private/tmp/gcts-incremental-arena-ROOT-20261019')
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def load(p):return json.loads(Path(p).read_text())
def save(n,v):
 p=D/n
 if p.exists():raise FileExistsError(str(p))
 p.write_text(json.dumps(v,sort_keys=True,indent=2)+'\n');return pin(p)
failure=R/'actual-v1/worker-failure.json';runner=R/'actual-v1/runner-receipt.json'
stderr=R/'actual-v1/stderr.bin';terminal=R/'plan-authorized-v1-terminal-observation/terminal.json'
f=load(failure);rr=load(runner);term=load(terminal);trace=stderr.read_text()
s=D/'exact_evidence_arena_v1.py';source=s.read_text();st=f['reached_context']['arena_statistics'];c=st['counters']
assert pin(s)['sha256']=='cf887ed9cb04866596a56a5d9261f93c84613eb3aede359223813bb644dccd09'
assert f['status']=='UNKNOWN_EVIDENCE_LIMIT' and f['reason']=='work' and f['own_arena_limit'] is True
assert c['work']==200000001 and len(f['completed_fixture_prefix'])==127
assert len(f['completed_input_packets'])==len(f['captured_input_prefix'])==len(f['published_forests'])==0
assert st['nodes']==st['edges']==st['roots']==st['cache_bytes']==st['cache_entries']==0
assert 'line 390, in capture' in trace and "if self._capture_value(value,t)!=i" in trace and "self._step('integer_conversion')" in trace
assert pin(stderr)==rr['stderr'] and pin(runner)==term['runner_receipt']
assert rr['limits']['memory_bytes']==1073741824 and rr['limits']['work_seconds']==180 and rr['limits']['overall_seconds']==210
selected=('capture_frames','intern_lookups','full_node_comparisons','bound_checks','integer_conversion','integer_digits_scanned','summary_nodes')
common=dict(author_identity='/root/conventional_library',source_only=True,saved_data_only=True,scientific_calls=0,component_calls=0,fixtures_executed=0,scientific_replays=0,scientific_acceptance=False,actual_execution_authorized=False,status='PROPOSED_NOT_IMPLEMENTED_UNMEASURED')
note=save('capture-next-design-v1.json',dict(common,schema='incremental-arena-capture-next-design-v1',
 sources=dict(arena=pin(s),worker=pin(R/'qualify_arena_worker_v3.py')),
 retained=dict(failure=pin(failure),runner=pin(runner),stderr=pin(stderr),terminal=pin(terminal)),
 observed=dict(status=f['status'],reason=f['reason'],stage=f['reached_context']['stage'],input=f['reached_context']['input'],
    diagnostics=len(f['completed_fixture_prefix']),completed_input_packets=0,captured_input_prefix=0,published_forests=0,
    committed=st,terminal_seconds=term['runner_clock_seconds'],worker_peak_bytes=rr['worker_wait4_usage']['ru_maxrss'],
    resource_admitted=False,representation_admitted=False,
    interpretation='All127 saved diagnostic packets precede the failed main capture. None is a whole original-input qualification. Time/peak are whole-worker measurements including diagnostics, not isolated capture costs.'),
 direct_failure_site=dict(evidence='Ordinary retained stderr explicitly places the exception at capture line390, the SECOND _capture_value(value,t) reconciliation, then line345 integer path, line266 integer_conversion and line229 work guard.',
    source_lines=[266,345,387,390,391],consequence='The first provisional full-root build returned. Failure occurred before the second read completed and before _commit_root; no root/node/cache transaction was published. Provisional fragment_build_bytes8MiB is attempted temporary build traffic, not an8MiB committed cache or memory leak.',
    limits='Failure JSON has no pass index itself; this localization uses the exact stderr/source join, not reconstruction of a missing result. No current capture/forest/inverse artifact can be recovered or admitted.'),
 counter_analysis=dict(all_saved_counters=c,selected_work_shares={k:dict(count=c[k],fraction_of_recorded_work=c[k]/c['work']) for k in selected},
    intern_to_summary_ratio=c['intern_lookups']/c['summary_nodes'],
    full_comparison_to_lookup_ratio=c['full_node_comparisons']/c['intern_lookups'],
    integer_to_lookup_ratio=c['integer_conversion']/c['intern_lookups'],
    redundant_lower_bound_bytes=c['integer_digits_scanned']+c['integer_conversion']-1,
    original_loaded_bytes=f['aggregate_expanded_input_prefix_bytes'],
    interpretation='Counters are weighted Source work events, not CPU shares, allocations or independent counts of unique values. Summary_nodes80807 versus22428205 lookups and22347398 full comparisons is consistent with heavy exact reuse after repeated traversal; it is not a measured provisional-node census. Constructor/header scans and both capture reads share these counters. The digit-plus-minimum-separator bound also exceeds the original file size, but the direct stderr trace is the primary second-pass evidence. Root callback count17603269 covers the whole worker including127 diagnostics, not just this arena.'),
 Source_causes=[
    dict(lines=[339,370],fact='The iterative builder charges a frame on entry and each container child/exit iteration, including already-repeated values. Interning happens only after descendants have been revisited and a complete tuple assembled. Sharing reduces retained unique nodes; it does not memoize the occurrence walk.'),
    dict(lines=[264,275,345],fact='Each strict integer occurrence is converted to decimal and its digit text rescanned/bounded before _intern can find an existing typed node. Thirteen million integer_conversion calls and30million digit charges therefore include repeated immutable values. Their actual distinct-value distribution is unmeasured.'),
    dict(lines=[322,331],fact='Every rebuilt value performs bucket lookup and full tuple equality even during the second reconciliation against the same candidate root. Exact equality is essential; rebuilding/hash/interning a second owned tree is a more expensive way of establishing it than a direct read comparison.'),
    dict(lines=[243,258,342,356,288,307],fact='Per-frame depth checks, repeated string/key size scans and eager per-new-node summary bounds are real charged operations. New-node size/depth/reference checks must remain complete. Rechecking identical immutable strings by full equality may avoid rescanning their already-validated Unicode/escape properties.'),
    dict(lines=[308,321],fact='The8MiB fragment store is for canonical output bytes and does not skip capture traversal/canonical scalar construction. Raising fragment capacity or disabling a full cache alone does not remove the second complete builder pass.'),
    dict(lines=[383,392],fact='Second reconstruction intentionally enforces complete public-input custody; it cannot be deleted, replaced by digest/object identity or assumed from the first root. Transactional rollback correctly discarded unpublished nodes/roots after the owned limit. No hidden work reset is appropriate.')],
 recommendation=dict(name='DIRECT_TYPED_SECOND_READ_RECONCILIATION',scope='ONE prospective Source successor: keep the first builder, existing wire/schema/public API and node validation; replace only the second rebuilding/interner call with a complete ordered comparison against its already-owned immutable root. No implementation here.',
    algorithm=[
      'Walk the current ordinary input and expected immutable node together with an explicit bounded stack. Visit EVERY value/container/key/ordered child again. Enforce exact builtin types, lengths, full key set and strict ordered/repeated array positions. Track cycles/depth/current container-length consistency and reject mismatch; no subtree success from hash or object identity.',
      'For objects, compare the complete exact string-key set and cardinality to the stored canonical sorted keys, then traverse each expected key/current value. A second sort/new key tuple is unnecessary for equality, but every actual key must still have exact string type and match a previously validated key.',
      'For strict integers, preserve preconversion bit/digit bounds and canonical builtin conversion when needed, then full literal compare against the already-validated expected decimal string. A successful equality to that exact validated canonical lexeme establishes the same value/domain without rerunning the digit validator and interner on a newly constructed node. No Python bool/int coercion is permitted.',
      'For strings/bools/null, full exact typed equality to the validated immutable payload suffices; unequal or malformed data rejects. Float handling must explicitly preserve finite canonical lexical equality and signedzero; retain current conversion/validation until an equally strict reviewed comparison exists.',
      'Do not append nodes, summaries, buckets, cache or roots during this second comparison. Keep the original final source/epoch guards and sole publication point only after complete reconciliation. Failure preserves committed state and exact exception identity; attempted work/peak costs remain monotone.',
      'Optional later bounded typed-scalar memoization can avoid repeated conversion of equal immutable integers, but is not required for this first change. It would need full type/value equality, existing finite capacity/memory accounting and ordinary comparison fallback; never unbounded or hash-only identity. Do not combine that second feature before reviewing the direct comparator.'
    ],
    work_accounting='Keep200m and the existing per-event weighted charging model. Charge every actual reconciliation frame/depth/key/reference/full equality and every conversion/copy that remains. Existing counter meanings must stay literal: integer_conversion only when conversion executes, integer_digits_scanned only when a real digit scan executes, intern_lookups only when interning executes. New reconciliation comparison counters may be added transparently. Do not do the same old operations but stop charging them, call a bulk pass one unit, reset per phase, raise the limit, or claim a numerical-unit redefinition as speedup. This is an algorithmic removal of real tuple/hash/canonical-validation work, not removal of logical equality/custody.',
    soundness_obligation='By structural induction, a complete strict typed current-value comparison with the owned valid node tree establishes the same full canonical JSON value as the old second builder, including all keys, ordered/repeated references and negativezero. Positive equality inherits the expected node validation; mismatches refuse. A new independently reviewed Source argument must also show complete traversal, bounded stacks/work, cycle/mutation handling, unchanged final guards and atomic publication.',
    unknowns='No speed, work reduction, fit or memory result is measured. New comparison still traverses the entire ordinary value. First-pass capture, whole next-state copies, all3inputs, sealing/export, independent inverse and final artifacts remain; later phases may hit200m/180s/1GiB/128MiB even if this failed reconciliation becomes cheaper.'),
 future_gate=dict(no_actual_this_turn=True,required='New Source/independent review and freshly declared bounded subject only. Preserve all3 complete original files,127 current diagnostics and earlier negative actuals. Add targeted exact second-read mismatch/type/signedzero/Unicode/repeated-port and callback/precommit cases without supplying a proof route.',
    unchanged=dict(work=200000000,work_seconds=180,overall_seconds=210,memory_bytes=1073741824,physical_bytes=134217728,expanded_logical_bytes=134217728),
    acceptance='Must finish all originals with baseline/full arena/saved fresh independent forest bytewise reconstruction and explicit stream completion, plus all finite diagnostics and ordinary resource gates. An uncommitted provisional root or127diagnostic pass is not representation qualification. No proof/search/Model/Native/GCTS/RL claim follows.'),
 limitations=['This is Source/retained-metadata reasoning only; no component/fixture/replay, new Source implementation, cap change or current-report edit.','Not an independent certificate of own arena; Control Source and Root actual/retained audits remain separate.','Actual per-pass counts, allocation distribution and exclusive CPU cost are unavailable. The traceback localizes the pass, not its isolated timing.','The two prior schema output/RAM failures and prior evidence time/work failures remain immutable and nonadmitted.']))
handoff=save('capture-next-design-handoff-v1.json',dict(common,schema='arena-capture-next-design-handoff-v1',note=note,arena_source=pin(s),failure=pin(failure),stderr=pin(stderr),summary='Direct stderr proves second builder reconciliation work stop. Propose a full typed direct second read of the captured immutable root, retaining complete custody/transaction/quotas, not raising/resetting/redefining budget. Source-only/unimplemented, no new actual.'))
print(json.dumps(dict(note=note,handoff=handoff),indent=2))
