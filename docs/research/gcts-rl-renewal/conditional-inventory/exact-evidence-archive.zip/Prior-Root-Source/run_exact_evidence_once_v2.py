"""Exactly one representation worker; original numeric resource gates, no proof runtime."""
import time
NOW=time.monotonic_ns
BEGAN=NOW()
import errno
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys

VERSION='exact-evidence-once-runner-v1'
LIMITS=dict(work_seconds=180,overall_seconds=210,memory_bytes=1073741824,result_bytes=134217728,expanded_bytes=134217728,stdout_bytes=4194304,stderr_bytes=4194304)

def need(v,m):
    if not v:raise ValueError(m)

def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def descriptor(p,b):return dict(path=str(Path(p).resolve()),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def checked(d):
    b=Path(d['path']).read_bytes();need(descriptor(d['path'],b)==d,'exact raw descriptor');return b

def save_new(p,v):
    b=canonical(v)+b'\n';need(len(b)<=4194304,'bounded receipt');fd=os.open(str(p),os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
    with os.fdopen(fd,'wb')as f:f.write(b);f.flush();os.fsync(f.fileno())
    return descriptor(p,b)

def contains(v,w):
    if v==w:return True
    if type(v)is dict:return any(contains(x,w)for x in v.values())
    if type(v)is list:return any(contains(x,w)for x in v)
    return False

def group_absent(pgid):
    try:os.killpg(pgid,0)
    except ProcessLookupError:return True
    return False

def main(path):
    need(sys.platform=='darwin','declared Darwin ru_maxrss byte platform')
    p=Path(path).resolve();plan_raw=p.read_bytes();need(len(plan_raw)<=16777216,'finite plan');plan=json.loads(plan_raw)
    expected={'schema','invocation_id','actual_directory','python','worker','encoder','inverse','runner','observer','inputs','limits','declaration','authorization'}
    need(type(plan)is dict and set(plan)==expected and plan['schema']=='exact-evidence-once-plan-v1','exact plan schema/fields')
    need(plan['limits']==LIMITS,'original numeric gates')
    need(descriptor(__file__,Path(__file__).read_bytes())==plan['runner'],'exact runner Source')
    for k in ['python','worker','encoder','inverse','runner','observer','declaration']:checked(plan[k])
    need(type(plan['inputs'])is list and len(plan['inputs'])==3,'complete frozen three-input set')
    need([r['id']for r in plan['inputs']]==['full-base-control','full-shadow-packets','full-prior-case002'],'whole artifact order')
    need(len({r['input']['path']for r in plan['inputs']})==3,'distinct whole inputs')
    for r in plan['inputs']:
        need(set(r)=={'id','input','kind'}and r['kind']=='complete_ordinary_saved_JSON','input scope');checked(r['input'])
    need(sum(r['input']['bytes']for r in plan['inputs'])<=LIMITS['expanded_bytes'],'aggregate raw original cap')
    subject={k:v for k,v in plan.items()if k!='authorization'};need(len(subject)==12,'full twelve-field subject')
    subject_sha=hashlib.sha256(canonical(subject)).hexdigest();auth=json.loads(checked(plan['authorization']))
    need(auth['schema']=='exact-evidence-once-authorization-v1'and auth['author_identity']=='/root'and auth['actual_execution_authorized']is True and auth['maximum_actual_invocations']==1 and auth['subject_sha256']==subject_sha,'exact true max1 grant')
    need(set(auth['review_roles'])=={'Source','plans'},'two disclosed review roles')
    for role,receipt in auth['review_roles'].items():
        r=json.loads(checked(receipt));need(r['reviewer_identity']=='/root/conventional_control_review'and r['source_only']is True and r['scientific_calls']==0 and r['scientific_acceptance']is False and r['actual_execution_authorized']is False,'independent zero-execution review')
        if role=='Source':
            need(r['schema']=='exact-evidence-components-Source-review-v1'and r['source_review_passed']is True and r['author_identities']==['/root','/root/conventional_library'],'component Source scope')
            for k in ['worker','encoder','inverse','runner','observer']:need(contains(r,plan[k]),'complete reviewed '+k)
        else:
            need(r['schema']=='exact-evidence-prospective-plan-review-v1'and r['prospective_review_passed']is True and r['subject']==subject and r['subject_sha256']==subject_sha and contains(r,plan['declaration']),'exact prospective subject review')
    actual=Path(plan['actual_directory']);need(actual.is_absolute()and str(actual.resolve())==str(actual)and actual.parent.is_dir(),'canonical new actual location')
    actual.mkdir(mode=0o700);work=BEGAN+180000000000;overall=BEGAN+210000000000
    consumed=save_new(actual/'CONSUMED.json',dict(schema='exact-evidence-consumed-v1',invocation_id=plan['invocation_id'],plan=descriptor(p,plan_raw),subject_sha256=subject_sha,maximum_worker_launches=1,consumed_before_Popen=True,began_ns=BEGAN,work_deadline_ns=work,overall_deadline_ns=overall))
    result=dict(schema='exact-evidence-once-receipt-v1',version=VERSION,invocation_id=plan['invocation_id'],plan=descriptor(p,plan_raw),authorization=plan['authorization'],subject_sha256=subject_sha,consumed_marker=consumed,
        began_ns=BEGAN,work_deadline_ns=work,overall_deadline_ns=overall,limits=LIMITS,worker_launch_attempts=0,worker_pid=None,owned_pgid=None,worker_reaped=False,owned_group_absent=False,regular_logs_closed=False,
        resource_candidate_accepted=False,representation_candidate=False,scientific_acceptance=False,mathematical_proof_accepted=False,Model_permission=False,Native_calls=0,errors=[],signals=[])
    process=None;reaped=False;status=None;usage=None;group_seen_absent=False
    def owned_group_absent():
        nonlocal group_seen_absent
        absent=group_absent(process.pid)
        need(absent or not group_seen_absent,'owned group reappeared; no unverified signal')
        group_seen_absent=group_seen_absent or absent
        return absent
    def reap():
        nonlocal reaped,status,usage
        if reaped:return True
        got,st,ru=os.wait4(process.pid,os.WNOHANG)
        if got:
            status=st;usage=ru;reaped=True;process.returncode=os.waitstatus_to_exitcode(st)
            result['worker_terminal_observed_ns']=NOW()
        return reaped
    def terminate(sig):
        if not owned_group_absent():os.killpg(process.pid,sig);result['signals'].append(dict(signal=sig,sent_ns=NOW()))
    try:
        need(NOW()<work,'prelaunch within original work')
        command=[plan['python']['path'],'-I','-S','-B',plan['worker']['path'],str(p)]
        environment={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8','PYTHONHASHSEED':'0','PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1'}
        with (actual/'stdout.bin').open('xb')as out,(actual/'stderr.bin').open('xb')as err:
            result['worker_launch_attempts']=1
            process=subprocess.Popen(command,stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True,env=environment,cwd=str(actual))
            result.update(worker_pid=process.pid,owned_pgid=process.pid,command=command)
            while not reap():
                need(NOW()<work,'worker original work deadline')
                for name in ['stdout','stderr']:need((actual/(name+'.bin')).stat().st_size<=LIMITS[name+'_bytes'],'bounded '+name)
                time.sleep(.02)
        result['regular_logs_closed']=True
        need(process.returncode==0,'normal exact worker exit0')
        for name in ['stdout','stderr']:need((actual/(name+'.bin')).stat().st_size<=LIMITS[name+'_bytes'],'complete bounded '+name)
        need(owned_group_absent(),'owned group absent')
        result['owned_group_absent']=True
        need(NOW()<work,'positive known exit and checks before180')
        wp=actual/'worker-receipt.json';wraw=wp.read_bytes();need(len(wraw)<=4194304,'finite worker receipt');w=json.loads(wraw)
        need(w['schema']=='exact-evidence-qualification-worker-receipt-v1'and w['invocation_id']==plan['invocation_id']and w['plan']==descriptor(p,plan_raw),'exact worker header')
        need(w['began_ns']==BEGAN and w['work_deadline_ns']==work and w['overall_deadline_ns']==overall and w['work_completed_ns']<work and w['representation_qualification_candidate']is True,'worker timing/candidate')
        payload=json.loads(checked(w['result']));need(payload['status']=='REPRESENTATION_QUALIFICATION_CANDIDATE'and len(payload['complete_inputs'])==3 and all(f['passed']is True for f in payload['fixtures']),'complete retained candidate')
        need(payload['Native_calls']==payload['scientific_proof_replays']==payload['search_calls']==payload['Model_calls']==0 and payload['new_target_proof']is False and payload['Model_permission']is False and payload['schema_inventory_admission']is False,'no proof authority')
        need(w['tables']==[r['encoded']for r in payload['complete_inputs']],'whole table census')
        total=w['result']['bytes']
        for d in w['tables']:checked(d);total+=d['bytes']
        need(total<=LIMITS['result_bytes']and payload['aggregate_input_expanded_bytes']<=LIMITS['expanded_bytes'],'both aggregate encoded and expanded caps')
        need(usage.ru_maxrss<=LIMITS['memory_bytes'],'worker peak within1GiB')
        for k in ['python','worker','encoder','inverse','runner','observer','declaration']:checked(plan[k])
        for r in plan['inputs']:checked(r['input'])
        result.update(worker_receipt=descriptor(wp,wraw),result=w['result'],tables=w['tables'],aggregate_encoded_result_bytes=total,worker_peak_bytes=usage.ru_maxrss,resource_candidate_accepted=True,representation_candidate=True)
        need(NOW()<work,'positive final whole checks before180')
    except BaseException as error:
        result['errors'].append(dict(type=type(error).__name__,message=str(error)))
        if process is not None:
            try:
                reap()
                if not owned_group_absent():
                    terminate(signal.SIGTERM);until=min(overall,NOW()+1000000000)
                    while NOW()<until:
                        reap()
                        if owned_group_absent():break
                        time.sleep(.02)
                if not owned_group_absent():terminate(signal.SIGKILL)
                while NOW()<overall:
                    reap()
                    if reaped and owned_group_absent():break
                    time.sleep(.02)
                result['owned_group_absent']=owned_group_absent()
            except BaseException as cleanup:result['errors'].append(dict(type=type(cleanup).__name__,message=str(cleanup),cleanup=True))
        result['resource_candidate_accepted']=False;result['representation_candidate']=False
    finally:
        result['worker_reaped']=reaped
        if reaped:
            result['worker_exit_code']=process.returncode;result['worker_wait4_status']=status
            result['worker_wait4_usage']={k:getattr(usage,k)for k in ['ru_utime','ru_stime','ru_maxrss','ru_minflt','ru_majflt']}
        result['regular_logs_closed']=process is not None
        result['closed_ns']=NOW()
        for name in ['stdout','stderr']:
            f=actual/(name+'.bin')
            if f.exists():result[name]=descriptor(f,f.read_bytes())
        save_new(actual/'runner-receipt.json',result)
        if NOW()>=overall:save_new(actual/'POST_RECEIPT_DEADLINE_FAILURE.json',dict(admitted=False))
        if result['resource_candidate_accepted']and NOW()>=work:save_new(actual/'POST_RECEIPT_WORK_FAILURE.json',dict(admitted=False))
    print(json.dumps(dict(actual=str(actual),resource_candidate_accepted=result['resource_candidate_accepted'],representation_candidate=result['representation_candidate'])))
    return 0 if result['resource_candidate_accepted']and NOW()<work and NOW()<overall else 2

if __name__=='__main__':
    need(len(sys.argv)==2,'one exact plan path');raise SystemExit(main(sys.argv[1]))
