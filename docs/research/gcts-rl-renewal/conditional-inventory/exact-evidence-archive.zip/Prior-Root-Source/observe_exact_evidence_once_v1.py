"""External terminal observer only; no scientific imports."""
import time
NOW=time.monotonic_ns
import hashlib,json,os
from pathlib import Path
import subprocess,sys

def need(v,m):
    if not v:raise ValueError(m)
def pin(p,b):return dict(path=str(Path(p).resolve()),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,v):
    b=json.dumps(v,sort_keys=True,indent=2,allow_nan=False).encode()+b'\n';fd=os.open(str(p),os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
    with os.fdopen(fd,'wb')as f:f.write(b);f.flush();os.fsync(f.fileno())
def main(path):
    started=NOW();path=Path(path).resolve();raw=path.read_bytes();need(len(raw)<=16777216,'finite plan');plan=json.loads(raw)
    need(pin(__file__,Path(__file__).read_bytes())==plan['observer'],'exact observer')
    for role in ['python','runner']:
        d=plan[role];need(pin(d['path'],Path(d['path']).read_bytes())==d,'exact '+role)
    folder=path.parent/(path.stem+'-terminal-observation');folder.mkdir(mode=0o700)
    save(folder/'CONSUMED.json',dict(plan=pin(path,raw),maximum_runner_launches=1,started_ns=started))
    command=[plan['python']['path'],'-I','-S','-B',plan['runner']['path'],str(path)]
    result=dict(schema='exact-evidence-terminal-observation-v1',plan=pin(path,raw),started_ns=started,command=command,terminal_gate_passed=False,scientific_acceptance=False,mathematical_proof_accepted=False)
    with (folder/'stdout.bin').open('xb')as out,(folder/'stderr.bin').open('xb')as err:
        process=subprocess.Popen(command,stdin=subprocess.DEVNULL,stdout=out,stderr=err);result['runner_pid']=process.pid
        try:code=process.wait(timeout=225)
        except subprocess.TimeoutExpired:
            process.kill();process.wait(timeout=5);result.update(error='failure-only observer timeout; exact residual worker inspection required',runner_exit_code=process.returncode,terminal_ns=NOW());save(folder/'terminal.json',result);return 2
    terminal=NOW();result.update(runner_exit_code=code,terminal_ns=terminal)
    rp=Path(plan['actual_directory'])/'runner-receipt.json'
    if rp.is_file():
        b=rp.read_bytes();need(len(b)<=4194304,'finite final receipt');r=json.loads(b);result['runner_receipt']=pin(rp,b)
        result['runner_clock_seconds']=(terminal-r['began_ns'])/1e9
        result['terminal_gate_passed']=(code==0 and terminal<r['overall_deadline_ns']and r['plan']==pin(path,raw)and r['resource_candidate_accepted']is True and r['representation_candidate']is True and r['worker_reaped']is True and r['owned_group_absent']is True and r['regular_logs_closed']is True and r['worker_launch_attempts']==1 and not rp.with_name('POST_RECEIPT_DEADLINE_FAILURE.json').exists())
    save(folder/'terminal.json',result);print(json.dumps(dict(terminal=str(folder/'terminal.json'),terminal_gate_passed=result['terminal_gate_passed'])));return 0 if result['terminal_gate_passed']else 2
if __name__=='__main__':
    need(len(sys.argv)==2,'one exact plan path');raise SystemExit(main(sys.argv[1]))
