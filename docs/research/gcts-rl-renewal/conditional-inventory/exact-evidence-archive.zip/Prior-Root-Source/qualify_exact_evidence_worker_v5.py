"""Bounded representation-only qualification. Never import a proof/search runtime."""
import time
NOW=time.monotonic_ns
import gc
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys

VERSION='exact-evidence-qualification-worker-v1'
ENCODER_LIMITS=dict(max_depth=512)
INVERSE_LIMITS=dict(depth=513)  # Nodes on a path:512 edges in encoder convention.

def need(v,message):
    if not v:raise ValueError(message)

def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode('utf-8')
def pin(p):
    p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def raw(d):
    p=Path(d['path']);b=p.read_bytes();need(dict(path=str(p.resolve()),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())==d,'whole raw pin');return b

def strict_object(pairs):
    out={}
    for k,v in pairs:
        need(k not in out,'duplicate JSON object key');out[k]=v
    return out

def ordinary_load(b):
    return json.loads(b,object_pairs_hook=strict_object,parse_constant=lambda s:(_ for _ in ()).throw(ValueError('nonfinite JSON')))

def save_new(path,v):
    b=canonical(v)+b'\n';fd=os.open(str(path),os.O_CREAT|os.O_EXCL|os.O_WRONLY|os.O_NOFOLLOW,0o600)
    with os.fdopen(fd,'wb')as f:f.write(b);f.flush();os.fsync(f.fileno())
    return pin(path)

def streamed_file(path,value,tick,remaining):
    need(not path.exists(),'fresh output')
    temp=path.with_suffix('.partial');fd=os.open(str(temp),os.O_CREAT|os.O_EXCL|os.O_WRONLY|os.O_NOFOLLOW,0o600)
    encoder=json.JSONEncoder(sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False);n=0;buf=bytearray()
    try:
        with os.fdopen(fd,'wb')as stream:
            for part in encoder.iterencode(value):
                buf.extend(part.encode('utf-8'))
                if len(buf)>=65536:
                    tick();n+=len(buf);need(n<=remaining,'aggregate encoded byte cap');stream.write(buf);buf.clear()
            buf.extend(b'\n');n+=len(buf);need(n<=remaining,'aggregate encoded byte cap');stream.write(buf);stream.flush();os.fsync(stream.fileno())
        tick();os.link(temp,path);temp.unlink();return pin(path)
    finally:
        if temp.exists():temp.unlink()

def compare_stream(chunks,expected,tick):
    offset=0;digest=hashlib.sha256();view=memoryview(expected)
    for b in chunks:
        tick();need(type(b)is bytes and b,'nonempty bytes chunk')
        need(offset+len(b)<=len(expected)-1 and b==view[offset:offset+len(b)],'full literal inverse bytes')
        offset+=len(b);digest.update(b)
    need(expected[-1:]==b'\n'and offset==len(expected)-1,'complete inverse and one external newline')
    digest.update(b'\n');need(digest.hexdigest()==hashlib.sha256(expected).hexdigest(),'whole inverse hash')
    return dict(bytes=len(expected),sha256=digest.hexdigest(),whole_literal_equal=True)

def import_source(name,descriptor):
    raw(descriptor);spec=importlib.util.spec_from_file_location(name,descriptor['path']);module=importlib.util.module_from_spec(spec)
    sys.modules[name]=module;spec.loader.exec_module(module);return module

def run_fixtures(codec,inverse,tick):
    rows=[]
    def record(name,**v):rows.append(json.loads(canonical(dict(name=name,passed=True,**v))))
    def expanded(table):return b''.join(codec.iter_expanded_canonical(table,tick,ENCODER_LIMITS))
    shared={'port':[0,False,None,'\u03bb\n\\"']}
    value={'values':[None,False,True,0,-1,0.0,-0.0,1.5,1e20,'\u03bb\n\\"'],'ordered':[shared,shared],'missing':{},'assigned_zero':{'m':0}}
    expected=canonical(value);table=codec.freeze(value,tick,ENCODER_LIMITS);wire=codec.to_wire(table,tick,ENCODER_LIMITS)
    need(expanded(table)==expected,'typed fixture encoder inverse')
    need(b''.join(inverse.iter_inverse(wire,tick,INVERSE_LIMITS))==expected,'typed fixture independent inverse')
    need(canonical(codec.materialize(table,tick,ENCODER_LIMITS))==expected,'fresh small materialization exact canonical equality')
    record('typed_values_order_unicode_and_repeated_ports',input=value,wire=wire,canonical_utf8=expected.decode())
    try:table._root=0
    except AttributeError:record('ordinary_attribute_assignment_blocked')
    else:raise ValueError('ordinary frozen attribute assignment allowed')
    need(type(table.nodes)is tuple and all(type(n)is tuple for n in table.nodes),'immutable outer and typed nodes')
    need(['bool',False]in wire['nodes']and ['int','0']in wire['nodes']and ['float','0.0']in wire['nodes']and ['float','-0.0']in wire['nodes'],'typed nodes distinct')
    record('bool_int_and_signed_float_zero_distinct')
    value['ordered'][0]['port'].append('caller mutation');value['new']='caller field'
    need(expanded(table)==expected,'caller mutation isolated')
    wire['nodes'].append(['str','wire mutation']);need(expanded(table)==expected,'public wire mutation isolated')
    record('caller_and_wire_mutation_cannot_change_frozen')
    fresh1=codec.materialize(table,tick,ENCODER_LIMITS);fresh2=codec.materialize(table,tick,ENCODER_LIMITS)
    need(fresh1 is not fresh2 and fresh1['ordered'][0]is not fresh1['ordered'][1],'fresh occurrence materialization')
    fresh1['ordered'][0]['port'].append('returned mutation');need(fresh2['ordered'][0]['port']==fresh2['ordered'][1]['port']and fresh1['ordered'][0]['port']!=fresh1['ordered'][1]['port']and expanded(table)==expected,'return mutation isolation')
    record('fresh_materialization_each_occurrence_and_call')
    def packet(nodes,root=None):return dict(schema='exact-evidence-node-table-v1',version='exact-evidence-table-v1',nodes=nodes,root=len(nodes)-1 if root is None else root)
    bad=[('boolean_root',packet([['null']],True)),('forward_self_reference',packet([['array',[0]]])),('dangling_reference',packet([['array',[8]]])),
         ('boolean_reference',packet([['null'],['array',[False]]])),('duplicate_typed_node',packet([['null'],['null'],['array',[0,1]]])),
         ('unreachable_node',packet([['null'],['bool',False]])),('duplicate_object_key',packet([['null'],['object',[['a',0],['a',0]]]])),
         ('unsorted_object_keys',packet([['null'],['object',[['b',0],['a',0]]]])),('noncanonical_integer',packet([['int','-0']])),
         ('nonfinite_float',packet([['float','NaN']])),('integer_in_float_tag',packet([['float','1']])),('lone_surrogate',packet([['str','\ud800']])),
         ('unknown_tag',packet([['absent']])),('extra_top_field',dict(packet([['null']]),extra=False))]
    for name,b in bad:
        observed=[]
        try:codec.validate_wire(b,tick,ENCODER_LIMITS)
        except codec.EvidenceDataError:observed.append('encoder_rejected')
        try:list(inverse.iter_inverse(b,tick,INVERSE_LIMITS))
        except inverse.InverseDataError:observed.append('independent_rejected')
        need(observed==['encoder_rejected','independent_rejected'],'both malformed-wire rejections '+name)
        # Lone surrogates cannot enter an ordinary UTF-8 output packet.
        record(name,wire_ascii_json=json.dumps(b,ensure_ascii=True,sort_keys=True),observed=observed)
    cycle=[];cycle.append(cycle)
    try:codec.freeze(cycle,tick,ENCODER_LIMITS)
    except codec.EvidenceDataError:record('cyclic_caller_container_rejected')
    else:raise ValueError('cycle accepted')
    for label in ['encoder','independent']:
        between=packet([['str','x'*70000],['int','1'],['array',[0,1]]])
        original_between=json.loads(canonical(between));expected_between=canonical(['x'*70000,1])
        if label=='encoder':
            owned_between=codec.validate_wire(between,tick,ENCODER_LIMITS)
            stream_between=codec.iter_expanded_canonical(owned_between,tick,ENCODER_LIMITS)
        else:stream_between=inverse.iter_inverse(between,tick,INVERSE_LIMITS)
        first=next(stream_between);between['nodes'][1][1]='01'
        need(first+b''.join(stream_between)==expected_between,'owned stream after caller mutation '+label)
        record('inter_yield_mutation_'+label,input_wire=original_between,changed_node=1,new_payload='01',whole_original_canonical_sha256=hashlib.sha256(expected_between).hexdigest(),exact_original_stream_preserved=True)
    small=packet([['null']]+[['array',[i-1,i-1]]for i in range(1,17)])
    counts=[]
    for label,operation in [('encoder',lambda:b''.join(codec.iter_expanded_canonical(codec.validate_wire(small,tick,ENCODER_LIMITS),tick,dict(ENCODER_LIMITS,max_expanded_bytes=64)))),('independent',lambda:b''.join(inverse.iter_inverse(small,tick,dict(INVERSE_LIMITS,expanded_bytes=64))))]:
        try:operation()
        except (codec.EvidenceLimit,inverse.InverseLimit)as error:
            if label=='encoder':need(codec.is_own_limit(error),'own expansion limit')
            counts.append(label)
    need(counts==['encoder','independent'],'bounded full expansion limit')
    record('shared_DAG_expansion_cap',wire=small,expanded_byte_limit=64,observed=counts)
    depth_wire=packet([['null'],['array',[0]],['array',[1]],['array',[2]]])
    depth_table=codec.validate_wire(depth_wire,tick,dict(ENCODER_LIMITS,max_depth=3))
    need(b''.join(codec.iter_expanded_canonical(depth_table,tick,dict(ENCODER_LIMITS,max_depth=3)))==b'[[[null]]]'and b''.join(inverse.iter_inverse(depth_wire,tick,dict(INVERSE_LIMITS,depth=4)))==b'[[[null]]]','exact depth convention boundary')
    record('depth_boundary_acceptance',wire=depth_wire,encoder_edges=3,independent_nodes=4)
    for label,operation in [('encoder_depth',lambda:codec.validate_wire(depth_wire,tick,dict(ENCODER_LIMITS,max_depth=2))),('independent_depth',lambda:list(inverse.iter_inverse(depth_wire,tick,dict(INVERSE_LIMITS,depth=3)))),('encoder_work',lambda:codec.freeze(None,tick,dict(ENCODER_LIMITS,max_work=1))),('independent_work',lambda:list(inverse.iter_inverse(packet([['null']]),tick,dict(INVERSE_LIMITS,work=1))))]:
        try:operation()
        except (codec.EvidenceLimit,inverse.InverseLimit)as error:
            if label.startswith('encoder'):need(codec.is_own_limit(error),'owned bounded limit '+label)
            record(label+'_limit',limit_observed=True)
        else:raise ValueError('missing private bound '+label)
    class CallbackFailure(Exception):pass
    for label,operation in [('freeze',lambda cb:codec.freeze({'x':1},cb)),('validate',lambda cb:codec.validate_wire(packet([['null']]),cb)),('expand',lambda cb:list(codec.iter_expanded_canonical(table,cb))),('independent',lambda cb:list(inverse.iter_inverse(packet([['null']]),cb)))]:
        error=CallbackFailure(label)
        def callback():raise error
        try:operation(callback)
        except BaseException as caught:need(caught is error,'exact callback exception '+label)
        else:raise ValueError('callback swallowed '+label)
        record('exact_callback_'+label,exact_exception_object_propagated=True)
    foreign=codec.EvidenceLimit('foreign callback limit')
    need(not codec.is_own_limit(foreign),'foreign EvidenceLimit not own')
    def foreign_cb():raise foreign
    try:codec.freeze(None,foreign_cb)
    except BaseException as caught:need(caught is foreign and not codec.is_own_limit(caught),'foreign limit propagates')
    else:raise ValueError('foreign limit swallowed')
    record('foreign_limit_callback_identity')
    return rows

def main(plan_path):
    plan_path=Path(plan_path).resolve();plan=ordinary_load(plan_path.read_bytes());actual=Path(plan['actual_directory']);consumed=ordinary_load((actual/'CONSUMED.json').read_bytes())
    began=consumed['began_ns'];work=began+180000000000;overall=began+210000000000
    need(consumed['plan']==pin(plan_path)and consumed['invocation_id']==plan['invocation_id'],'exact consumed plan')
    need(consumed['work_deadline_ns']==work and consumed['overall_deadline_ns']==overall,'original clock deadlines')
    need(sys.platform=='darwin'and os.getpid()==os.getpgrp(),'declared platform and owned worker group')
    need(plan['limits']['work_seconds']==180 and plan['limits']['overall_seconds']==210 and plan['limits']['memory_bytes']==1073741824 and plan['limits']['result_bytes']==134217728 and plan['limits']['expanded_bytes']==134217728,'unchanged explicit qualification limits')
    need(raw(plan['worker'])==Path(__file__).read_bytes(),'exact worker Source')
    calls=0;guard_pins=[plan[k]for k in ['worker','encoder','inverse','python']]
    def guard():
        for d in guard_pins:need(pin(d['path'])==d,'current raw Source/runtime custody')
    def tick():
        nonlocal calls
        calls+=1;need(NOW()<work,'original work deadline')
        if calls%32768==0:guard()
    try:
        guard();tick();codec=import_source('qualified_exact_evidence_encoder',plan['encoder']);inverse=import_source('qualified_independent_evidence_inverse',plan['inverse'])
        results=[];encoded=0;expanded=0
        for item in plan['inputs']:
            tick();start=NOW();original=raw(item['input']);need(original[-1:]==b'\n','one canonical external newline')
            expanded+=len(original);need(expanded<=plan['limits']['expanded_bytes'],'aggregate expanded original size')
            value=ordinary_load(original)
            baseline=compare_stream((part.encode('utf-8')for part in json.JSONEncoder(sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).iterencode(value)),original,tick)
            froze=NOW();table=codec.freeze(value,tick,ENCODER_LIMITS);frozen_at=NOW();del value;gc.collect();tick()
            wire=codec.to_wire(table,tick,ENCODER_LIMITS);out=actual/(item['id']+'-table.json')
            descriptor=streamed_file(out,wire,tick,plan['limits']['result_bytes']-encoded);encoded+=descriptor['bytes']
            own=compare_stream(codec.iter_expanded_canonical(table,tick,ENCODER_LIMITS),original,tick)
            # Re-read the complete saved wire. The independent inverse imports no encoder code.
            decoded=ordinary_load(raw(descriptor));validated=codec.validate_wire(decoded,tick,ENCODER_LIMITS)
            reread=compare_stream(codec.iter_expanded_canonical(validated,tick,ENCODER_LIMITS),original,tick)
            independent=compare_stream(inverse.iter_inverse(decoded,tick,INVERSE_LIMITS),original,tick)
            tag_counts={}
            for node in decoded['nodes']:tag_counts[node[0]]=tag_counts.get(node[0],0)+1
            results.append(dict(id=item['id'],input=item['input'],encoded=descriptor,input_baseline=baseline,
                encoder_inverse=own,saved_wire_encoder_inverse=reread,independent_saved_wire_inverse=independent,
                immutable_node_count=len(decoded['nodes']),node_tag_counts=tag_counts,
                root_node=decoded['nodes'][decoded['root']],root_id=decoded['root'],
                freeze_seconds=(frozen_at-froze)/1e9,total_interval_seconds=(NOW()-start)/1e9,
                no_scientific_semantic_admission=True))
            del original,table,wire,decoded,validated;gc.collect();guard();tick()
        fixtures=run_fixtures(codec,inverse,tick);guard();tick()
        result=dict(schema='exact-evidence-qualification-result-v1',version=VERSION,invocation_id=plan['invocation_id'],
            representation_only=True,status='REPRESENTATION_QUALIFICATION_CANDIDATE',complete_inputs=results,fixtures=fixtures,
            callback_count=calls,aggregate_input_expanded_bytes=expanded,aggregate_encoded_table_bytes=encoded,
            current_Source=dict(encoder=plan['encoder'],independent_inverse=plan['inverse'],worker=plan['worker']),
            scientific_proof_replays=0,Native_calls=0,search_calls=0,Model_calls=0,opaque_Native_decodes=0,
            new_target_proof=False,Model_permission=False,schema_inventory_admission=False,goal_complete=False,
            scope='Whole prior ordinary data representation only. Mutable parsed input is released after freezing, and inputs processed serially. This is not integrated search-worker RAM or a recovery of either absent failed result.',
            expanded_budget_semantics='Both aggregate physical table+result bytes and fully expanded canonical input bytes must satisfy original numeric128MiB guard; no compact-wire-only profile claim.')
        result_descriptor=save_new(actual/'result.json',result);need(encoded+result_descriptor['bytes']<=plan['limits']['result_bytes'],'aggregate table and result bytes');tick();guard()
        save_new(actual/'worker-receipt.json',dict(schema='exact-evidence-qualification-worker-receipt-v1',
            invocation_id=plan['invocation_id'],plan=pin(plan_path),began_ns=began,work_deadline_ns=work,overall_deadline_ns=overall,
            result=result_descriptor,tables=[r['encoded']for r in results],work_completed_ns=NOW(),
            representation_qualification_candidate=True,scientific_acceptance=False,mathematical_proof_accepted=False,Model_permission=False))
        tick()
    except BaseException as error:
        # Diagnostics preserve failure; no result/receipt is admitted by existence alone.
        if not(actual/'worker-failure.json').exists():save_new(actual/'worker-failure.json',dict(schema='exact-evidence-worker-failure-v1',type=type(error).__name__,message=str(error),scientific_acceptance=False,representation_accepted=False))
        raise

if __name__=='__main__':
    need(len(sys.argv)==2,'one exact plan path');main(sys.argv[1])
