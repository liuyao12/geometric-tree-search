"""Independent ordinary-data inverse. No imports from the encoder or proof code."""
import json
import math
import re

VERSION='independent-evidence-inverse-v1'
SCHEMA='exact-evidence-node-table-v1'
WIRE_VERSION='exact-evidence-table-v1'
DEFAULT_LIMITS=dict(nodes=2000000,edges=8000000,depth=512,work=20000000,expanded_bytes=134217728,scalar_bytes=134217728)
class InverseDataError(ValueError):pass
class InverseLimit(RuntimeError):pass

def _limits(limits):
    result=dict(DEFAULT_LIMITS)
    if limits is not None:
        if type(limits)is not dict or not set(limits)<=set(result):raise InverseDataError('unknown limits')
        result.update(limits)
    if any(type(v)is not int or v<1 for v in result.values()):raise InverseDataError('positive exact integer limits')
    return result

def _scalar_text(value,limit):
    if type(value)is not str:raise InverseDataError('exact string')
    if any(0xD800<=ord(c)<=0xDFFF for c in value):raise InverseDataError('Unicode scalar string')
    encoded=value.encode('utf-8')
    if len(encoded)>limit:raise InverseLimit('scalar bytes')
    return value

def _token(value):
    return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode('utf-8')

def iter_inverse(wire,check,limits=None):
    """Validate the complete wire, then yield its exact canonical ordinary bytes."""
    cap=_limits(limits);work=0;edges=0
    def tick():
        nonlocal work
        check();work+=1
        if work>cap['work']:raise InverseLimit('work')
    tick()
    if type(wire)is not dict or set(wire)!={'schema','version','root','nodes'}:raise InverseDataError('exact wire fields')
    if wire['schema']!=SCHEMA or wire['version']!=WIRE_VERSION:raise InverseDataError('wire identity')
    nodes=wire['nodes'];root=wire['root']
    if type(nodes)is not list or not nodes:raise InverseDataError('nonempty node list')
    if len(nodes)>cap['nodes']:raise InverseLimit('node count')
    if type(root)is not int or root!=len(nodes)-1:raise InverseDataError('last exact integer root')
    heights=[];keys=set()
    for i,node in enumerate(nodes):
        tick()
        if type(node)is not list or not node or type(node[0])is not str:raise InverseDataError('node shape')
        tag=node[0];refs=[];key=None
        if tag=='null':
            if len(node)!=1:raise InverseDataError('null shape')
            key=('null',)
        else:
            if len(node)!=2:raise InverseDataError('two-field typed node')
            value=node[1]
            if tag=='bool':
                if type(value)is not bool:raise InverseDataError('bool type')
                key=(tag,value)
            elif tag=='int':
                value=_scalar_text(value,cap['scalar_bytes'])
                if re.fullmatch(r'(?:0|-[1-9][0-9]*|[1-9][0-9]*)',value) is None:raise InverseDataError('canonical integer lexeme')
                key=(tag,value)
            elif tag=='float':
                value=_scalar_text(value,cap['scalar_bytes'])
                try:number=json.loads(value)
                except (ValueError,RecursionError)as error:raise InverseDataError('float lexeme')from error
                if type(number)is not float or not math.isfinite(number)or _token(number).decode('utf-8')!=value:raise InverseDataError('finite canonical float lexeme')
                key=(tag,value)
            elif tag=='str':
                key=(tag,_scalar_text(value,cap['scalar_bytes']))
            elif tag=='array':
                if type(value)is not list:raise InverseDataError('array references')
                refs=value
                key=(tag,tuple(value))
            elif tag=='object':
                if type(value)is not list:raise InverseDataError('object pairs')
                names=[];pairs=[]
                for pair in value:
                    tick()
                    if type(pair)is not list or len(pair)!=2:raise InverseDataError('object pair')
                    name=_scalar_text(pair[0],cap['scalar_bytes']);names.append(name);refs.append(pair[1]);pairs.append((name,pair[1]))
                if names!=sorted(names)or len(set(names))!=len(names):raise InverseDataError('strict sorted unique object keys')
                key=(tag,tuple(pairs))
            else:raise InverseDataError('unknown tag')
        for ref in refs:
            tick();edges+=1
            if edges>cap['edges']:raise InverseLimit('edges')
            if type(ref)is not int or not 0<=ref<i:raise InverseDataError('strict prior exact integer reference')
        height=1+max((heights[r]for r in refs),default=0)
        if height>cap['depth']:raise InverseLimit('depth')
        heights.append(height)
        try:
            if key in keys:raise InverseDataError('duplicate complete typed node')
            keys.add(key)
        except TypeError as error:raise InverseDataError('malformed reference container')from error
    # Every table node must participate in the full root value.
    reached=set();todo=[root]
    while todo:
        tick();node_id=todo.pop()
        if node_id in reached:continue
        reached.add(node_id);node=nodes[node_id]
        if node[0]=='array':todo.extend(node[1])
        elif node[0]=='object':todo.extend(p[1]for p in node[1])
    if len(reached)!=len(nodes):raise InverseDataError('unreachable table node')
    # Iterative occurrence traversal; duplicate references expand completely.
    stack=[(root,-1)];pending=bytearray();size=0
    def emit(piece):
        nonlocal size
        tick();size+=len(piece)
        if size>cap['expanded_bytes']:raise InverseLimit('expanded bytes')
        pending.extend(piece)
    while stack:
        tick();node_id,index=stack[-1];node=nodes[node_id];tag=node[0]
        if tag not in ('array','object'):
            stack.pop()
            if tag=='null':emit(b'null')
            elif tag=='bool':emit(b'true'if node[1]else b'false')
            elif tag in ('int','float'):emit(node[1].encode('ascii'))
            else:emit(_token(node[1]))
        elif index==-1:
            emit(b'['if tag=='array'else b'{');stack[-1]=(node_id,0)
        elif index==len(node[1]):
            stack.pop();emit(b']'if tag=='array'else b'}')
        else:
            stack[-1]=(node_id,index+1)
            if index:emit(b',')
            if tag=='array':child=node[1][index]
            else:
                name,child=node[1][index];emit(_token(name));emit(b':')
            stack.append((child,-1))
        if len(pending)>=65536:
            yield bytes(pending);pending.clear()
    if pending:yield bytes(pending)
    tick()
