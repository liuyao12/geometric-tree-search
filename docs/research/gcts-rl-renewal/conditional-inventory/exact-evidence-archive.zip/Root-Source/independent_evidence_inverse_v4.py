"""Independent typed-table inverse; bounded fragments, no encoder/proof imports.

The v4 actual-operation work profile is NOT the v3 virtual token-walk profile.
Input/check/statistics ownership is exclusive; no hostile-Python sandbox claim.
"""
import json
import math
import re

VERSION='independent-evidence-inverse-v4-call-local-fragments'
EXECUTION_PROFILE='independent-evidence-fragments-actual-operations-v4'
SCHEMA='exact-evidence-node-table-v1'
WIRE_VERSION='exact-evidence-table-v1'
DEFAULT_LIMITS=dict(nodes=2000000,edges=8000000,depth=512,work=20000000,
    expanded_bytes=134217728,scalar_bytes=134217728,fragment_bytes=4096,
    cache_bytes=8388608,cache_entries=65536,chunk_bytes=65536)
class InverseDataError(ValueError):pass
_LIMIT_TOKEN=object()
class InverseLimit(RuntimeError):
    def __init__(self,reason,*,_owner=None):
        self.reason=reason;self._owner=_owner;super().__init__(reason)
def is_own_limit(error):
    return type(error)is InverseLimit and error._owner is _LIMIT_TOKEN
def _stop(reason):raise InverseLimit(reason,_owner=_LIMIT_TOKEN)
def _need(value,message):
    if not value:raise InverseDataError(message)
def _limits(limits):
    result=dict(DEFAULT_LIMITS)
    if limits is not None:
        _need(type(limits)is dict and not set(limits)-set(result),'known limits')
        result.update(limits)
    for name,value in result.items():
        _need(type(value)is int and value>=(0 if name in ('cache_bytes','cache_entries')else 1),'strict integer limits')
    for name in ['fragment_bytes','cache_bytes','cache_entries','chunk_bytes']:
        _need(result[name]<=DEFAULT_LIMITS[name],'bounded '+name)
    return result
def _token(value):
    return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode('utf-8')

def iter_inverse(wire,check,limits=None):
    return _iterate(wire,check,limits,None)
def iter_inverse_observed(wire,check,limits=None,*,statistics):
    """Same byte stream, with call-local counters copied to an owned empty dict."""
    _need(type(statistics)is dict and not statistics,'fresh ordinary statistics dict')
    return _iterate(wire,check,limits,statistics)

def _iterate(wire,check,limits,statistics):
    cap=_limits(limits)
    stats=dict(execution_profile=EXECUTION_PROFILE,phase='START',actual_operations=0,
        operations_by_kind={},scalar_characters_scanned=0,validated_nodes=0,
        validated_edges=0,logical_occurrences_summary=None,root_canonical_bytes=None,
        cache_attempts=0,cache_entries=0,cache_payload_bytes=0,
        cache_capacity_fallbacks=0,cache_ineligible_nodes=0,cache_hits_build=0,
        cache_hits_stream=0,build_copied_bytes=0,stream_copied_bytes=0,
        stream_logical_occurrences=0,stream_chunks=0,completed=False)
    def tick(kind):
        stats['last_operation']=kind
        if statistics is not None:
            statistics['phase']=stats['phase'];statistics['last_operation']=kind
        check()  # Exact delegated exceptions propagate; never converted to limits.
        stats['actual_operations']+=1
        ops=stats['operations_by_kind'];ops[kind]=ops.get(kind,0)+1
        if stats['actual_operations']>cap['work']:_stop('work')
    scanned=0
    def text_metrics(value,quoted=True):
        nonlocal scanned
        _need(type(value)is str,'exact string')
        utf8=0;token_bytes=2
        for start in range(0,len(value),4096):
            tick('scalar_scan_window')
            for c in value[start:start+4096]:
                n=ord(c);scanned+=1
                _need(not 0xD800<=n<=0xDFFF,'Unicode scalar string')
                width=1 if n<128 else 2 if n<2048 else 3 if n<65536 else 4
                utf8+=width
                token_bytes+=(2 if c in ('"','\\','\b','\f','\n','\r','\t')else 6 if n<32 else width)
            if utf8>cap['scalar_bytes']:_stop('scalar bytes')
            if (token_bytes if quoted else utf8)>cap['expanded_bytes']:_stop('expanded bytes')
        return utf8,token_bytes
    def tokenize(value,expected):
        tick('tokenize_begin');piece=_token(value);tick('tokenize_end')
        _need(len(piece)==expected,'independent token length reconciliation')
        return piece
    try:
        tick('initial');stats['phase']='VALIDATE_WHOLE_WIRE'
        _need(type(wire)is dict and set(wire)=={'schema','version','root','nodes'},'exact wire fields')
        _need(wire['schema']==SCHEMA and wire['version']==WIRE_VERSION,'wire identity')
        source_nodes=wire['nodes'];root=wire['root']
        _need(type(source_nodes)is list and bool(source_nodes),'nonempty node list')
        if len(source_nodes)>cap['nodes']:_stop('node count')
        _need(type(root)is int and root==len(source_nodes)-1,'last exact integer root')
        source_nodes=tuple(source_nodes);owned=[];heights=[];sizes=[];key_sizes=[];keys=set()
        for i,node in enumerate(source_nodes):
            tick('validate_node')
            _need(type(node)is list and bool(node)and type(node[0])is str,'node shape')
            tag=node[0];refs=[];key_lengths=();scalar_size=None
            if tag=='null':
                _need(len(node)==1,'null shape');key=('null',);scalar_size=4
            else:
                _need(len(node)==2,'two-field typed node');value=node[1]
                if tag=='bool':
                    _need(type(value)is bool,'bool type');key=(tag,value);scalar_size=4 if value else 5
                elif tag=='int':
                    raw_size,_=text_metrics(value,False);tick('integer_lexeme_begin')
                    _need(re.fullmatch(r'(?:0|-[1-9][0-9]*|[1-9][0-9]*)',value)is not None,'canonical integer lexeme')
                    tick('integer_lexeme_end');key=(tag,value);scalar_size=raw_size
                elif tag=='float':
                    raw_size,_=text_metrics(value,False);tick('float_parse_begin')
                    try:number=json.loads(value)
                    except (ValueError,RecursionError)as error:raise InverseDataError('float lexeme')from error
                    tick('float_parse_end')
                    _need(type(number)is float and math.isfinite(number),'finite float')
                    tick('float_canonical_begin');canonical=_token(number);tick('float_canonical_end')
                    _need(canonical.decode('utf-8')==value,'canonical float lexeme')
                    key=(tag,value);scalar_size=raw_size
                elif tag=='str':
                    _,scalar_size=text_metrics(value);key=(tag,value)
                elif tag=='array':
                    _need(type(value)is list,'array references')
                    if len(value)>cap['edges']-stats['validated_edges']:_stop('edges')
                    refs=tuple(value);key=(tag,refs)
                elif tag=='object':
                    _need(type(value)is list,'object pairs')
                    if len(value)>cap['edges']-stats['validated_edges']:_stop('edges')
                    pairs=[];lengths=[];previous=None
                    for pair in value:
                        tick('validate_pair')
                        _need(type(pair)is list and len(pair)==2,'object pair')
                        name,ref=pair;_,name_size=text_metrics(name)
                        _need(previous is None or previous<name,'strict sorted unique object keys')
                        previous=name;pairs.append((name,ref));lengths.append(name_size);refs.append(ref)
                    key=(tag,tuple(pairs));key_lengths=tuple(lengths)
                else:raise InverseDataError('unknown tag')
            height=1
            for ref in refs:
                tick('validate_edge');stats['validated_edges']+=1
                if stats['validated_edges']>cap['edges']:_stop('edges')
                _need(type(ref)is int and 0<=ref<i,'strict prior exact integer reference')
                height=max(height,1+heights[ref])
            if height>cap['depth']:_stop('depth')
            tick('typed_equality_begin')
            try:
                _need(key not in keys,'duplicate complete typed node');keys.add(key)
            except TypeError as error:raise InverseDataError('malformed reference container')from error
            tick('typed_equality_end');owned.append(key);heights.append(height)
            sizes.append(scalar_size);key_sizes.append(key_lengths);stats['validated_nodes']+=1
        nodes=tuple(owned);del source_nodes,owned,keys,node,wire
        # All future reads use recursively immutable owned nodes, never caller wire.
        stats['phase']='WHOLE_REACHABILITY_AND_MULTIPLICITY'
        uses=[0]*len(nodes);uses[root]=1;occurrence_sum=0;overflow=cap['expanded_bytes']+1
        for i in range(root,-1,-1):
            tick('reachability_node');count=uses[i]
            _need(count>0,'unreachable table node')
            occurrence_sum=min(overflow,occurrence_sum+count)
            node=nodes[i];refs=node[1]if node[0]=='array'else(p[1]for p in node[1])if node[0]=='object'else()
            for ref in refs:
                tick('reachability_edge');uses[ref]=min(overflow,uses[ref]+count)
        if occurrence_sum>=overflow:_stop('expanded bytes')
        stats['phase']='INDEPENDENT_EXPANDED_SUMMARIES';occurrences=[]
        for i,node in enumerate(nodes):
            tick('summary_node');tag=node[0];count=1
            if tag in ('array','object'):
                size=2+max(0,len(node[1])-1)
                for j,item in enumerate(node[1]):
                    tick('summary_edge');ref=item if tag=='array'else item[1]
                    size+=sizes[ref];count+=occurrences[ref]
                    if tag=='object':size+=key_sizes[i][j]+1
                    if size>cap['expanded_bytes']:_stop('expanded bytes')
                    if count>cap['expanded_bytes']:_stop('expanded bytes')
                sizes[i]=size
            occurrences.append(count)
        _need(occurrences[root]==occurrence_sum,'independent occurrence recurrences agree')
        stats['root_canonical_bytes']=sizes[root];stats['logical_occurrences_summary']=occurrences[root]
        stats['root_node_depth']=heights[root];del heights
        cache={}
        def pieces(node_id,phase):
            stack=[(node_id,-1)]
            while stack:
                tick(phase+'_walk_action');at,index=stack[-1];node=nodes[at];tag=node[0]
                if index==-1 and at in cache:
                    tick(phase+'_cache_hit');stack.pop();stats['cache_hits_'+phase]+=1
                    yield cache[at],occurrences[at]
                elif tag not in ('array','object'):
                    stack.pop()
                    if tag=='null':piece=b'null'
                    elif tag=='bool':piece=b'true'if node[1]else b'false'
                    elif tag in ('int','float'):
                        tick('ascii_token_begin');piece=node[1].encode('ascii');tick('ascii_token_end')
                    else:piece=tokenize(node[1],sizes[at])
                    yield piece,1
                elif index==-1:
                    stack[-1]=(at,0);yield(b'['if tag=='array'else b'{'),1
                elif index==len(node[1]):
                    stack.pop();yield(b']'if tag=='array'else b'}'),0
                else:
                    stack[-1]=(at,index+1)
                    if index:yield b',',0
                    if tag=='array':child=node[1][index]
                    else:
                        name,child=node[1][index]
                        yield tokenize(name,key_sizes[at][index]),0
                        yield b':',0
                    stack.append((child,-1))
        stats['phase']='BUILD_BOUNDED_CALL_LOCAL_FRAGMENTS'
        for i in range(len(nodes)):
            tick('cache_eligibility')
            if uses[i]<2 or sizes[i]>cap['fragment_bytes']:
                stats['cache_ineligible_nodes']+=1;continue
            stats['cache_attempts']+=1
            if len(cache)>=cap['cache_entries']or stats['cache_payload_bytes']+sizes[i]>cap['cache_bytes']:
                stats['cache_capacity_fallbacks']+=1;continue
            fragment=bytearray();values=0
            for piece,count in pieces(i,'build'):
                tick('build_copy');_need(len(fragment)+len(piece)<=sizes[i],'preallocation fragment bound')
                fragment.extend(piece);values+=count
                stats['build_copied_bytes']+=len(piece)
                _need(len(fragment)<=sizes[i]<=cap['fragment_bytes'],'bounded fragment build')
            _need(len(fragment)==sizes[i]and values==occurrences[i],'fragment length/value reconciliation')
            tick('freeze_fragment');cache[i]=bytes(fragment)
            stats['cache_payload_bytes']+=len(fragment);stats['cache_entries']=len(cache)
        stats['phase']='STREAM_EVERY_ORDINARY_OCCURRENCE';pending=bytearray()
        for piece,count in pieces(root,'stream'):
            view=memoryview(piece);offset=0
            while offset<len(view):
                tick('stream_copy_block');take=min(cap['chunk_bytes']-len(pending),len(view)-offset)
                size=stats['stream_copied_bytes']+take
                if size>cap['expanded_bytes']:_stop('expanded bytes')
                pending.extend(view[offset:offset+take]);offset+=take;stats['stream_copied_bytes']=size
                if len(pending)==cap['chunk_bytes']:
                    tick('yield_chunk');stats['stream_chunks']+=1;yield bytes(pending);pending.clear()
            stats['stream_logical_occurrences']+=count
        if pending:
            tick('yield_chunk');stats['stream_chunks']+=1;yield bytes(pending)
        _need(stats['stream_copied_bytes']==sizes[root],'complete stream size reconciliation')
        _need(stats['stream_logical_occurrences']==occurrences[root],'complete stream value reconciliation')
        tick('completion');stats['phase']='COMPLETE';stats['completed']=True
    finally:
        stats['scalar_characters_scanned']=scanned
        if statistics is not None:
            statistics.clear();statistics.update(stats)
