"""Bounded representation-only qualification. Never import a proof/search runtime."""
import time
NOW=time.monotonic_ns
import gc
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys

VERSION='exact-evidence-qualification-worker-v2-fragment-inverse'
ENCODER_LIMITS=dict(max_depth=512)
INVERSE_LIMITS=dict(depth=513)  # Nodes on a path:512 edges in encoder convention.
EXPECTED_FIXTURES=['typed_values_order_unicode_and_repeated_ports', 'ordinary_attribute_assignment_blocked', 'bool_int_and_signed_float_zero_distinct', 'caller_and_wire_mutation_cannot_change_frozen', 'fresh_materialization_each_occurrence_and_call', 'boolean_root', 'forward_self_reference', 'dangling_reference', 'boolean_reference', 'duplicate_typed_node', 'unreachable_node', 'duplicate_object_key', 'unsorted_object_keys', 'noncanonical_integer', 'nonfinite_float', 'integer_in_float_tag', 'lone_surrogate', 'unknown_tag', 'extra_top_field', 'cyclic_caller_container_rejected', 'inter_yield_mutation_encoder', 'inter_yield_mutation_independent', 'shared_DAG_expansion_cap', 'depth_boundary_acceptance', 'encoder_depth_limit', 'independent_depth_limit', 'encoder_work_limit', 'independent_work_limit', 'exact_callback_custom_freeze', 'exact_callback_custom_validate', 'exact_callback_custom_wire', 'exact_callback_custom_expand', 'exact_callback_custom_materialize', 'exact_callback_custom_independent', 'exact_callback_runtime_freeze', 'exact_callback_runtime_validate', 'exact_callback_runtime_wire', 'exact_callback_runtime_expand', 'exact_callback_runtime_materialize', 'exact_callback_runtime_independent', 'exact_callback_value_freeze', 'exact_callback_value_validate', 'exact_callback_value_wire', 'exact_callback_value_expand', 'exact_callback_value_materialize', 'exact_callback_value_independent', 'foreign_limit_callback_identity', 'foreign_inverse_limit_callback_identity', 'fragment_repeated_subtree_and_summary', 'fragment_disabled_payload', 'fragment_disabled_entries', 'fragment_small_threshold', 'fragment_partial_payload', 'fragment_partial_entries', 'fragment_large_uncached_scalar', 'fragment_escaped_keys_signed_zero', 'fragment_integer_exact_expanded_boundary', 'fragment_owned_work_limit_statistics', 'fragment_early_expanded_guard_modes', 'fragment_interyield_owned_input', 'fragment_closed_incomplete_statistics', 'fragment_observer_mutation_is_not_authority', 'fragment_exact_callback_mid_build_custom', 'fragment_exact_callback_after_first_chunk_custom', 'fragment_exact_callback_mid_build_runtime', 'fragment_exact_callback_after_first_chunk_runtime', 'fragment_exact_callback_mid_build_value', 'fragment_exact_callback_after_first_chunk_value', 'fragment_exact_callback_mid_build_foreign_inverse_limit', 'fragment_exact_callback_after_first_chunk_foreign_inverse_limit']
class WorkDeadline(RuntimeError):pass

def need(v,message):
    if not v:raise ValueError(message)

def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode('utf-8')
def pin(p):
    p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def raw(d):
    p=Path(d['path']);b=p.read_bytes();need(dict(path=str(p.resolve()),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())==d,'whole raw pin');return b

def strict_object(pairs):
    out={}
    for k,v in pairs:
        need(k not in out,'duplicate JSON object key');out[k]=v
    return out

def ordinary_load(b):
    return json.loads(b,object_pairs_hook=strict_object,parse_constant=lambda s:(_ for _ in ()).throw(ValueError('nonfinite JSON')))

def save_new(path,v):
    b=canonical(v)+b'\n';fd=os.open(str(path),os.O_CREAT|os.O_EXCL|os.O_WRONLY|os.O_NOFOLLOW,0o600)
    with os.fdopen(fd,'wb')as f:f.write(b);f.flush();os.fsync(f.fileno())
    return pin(path)

def streamed_file(path,value,tick,remaining):
    need(not path.exists(),'fresh output')
    temp=path.with_suffix('.partial');fd=os.open(str(temp),os.O_CREAT|os.O_EXCL|os.O_WRONLY|os.O_NOFOLLOW,0o600)
    encoder=json.JSONEncoder(sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False);n=0;buf=bytearray()
    try:
        with os.fdopen(fd,'wb')as stream:
            for part in encoder.iterencode(value):
                buf.extend(part.encode('utf-8'))
                if len(buf)>=65536:
                    tick();n+=len(buf);need(n<=remaining,'aggregate encoded byte cap');stream.write(buf);buf.clear()
            buf.extend(b'\n');n+=len(buf);need(n<=remaining,'aggregate encoded byte cap');stream.write(buf);stream.flush();os.fsync(stream.fileno())
        tick();os.link(temp,path);temp.unlink();return pin(path)
    finally:
        if temp.exists():temp.unlink()

def compare_stream(chunks,expected,tick):
    offset=0;digest=hashlib.sha256();view=memoryview(expected)
    for b in chunks:
        tick();need(type(b)is bytes and b,'nonempty bytes chunk')
        need(offset+len(b)<=len(expected)-1 and b==view[offset:offset+len(b)],'full literal inverse bytes')
        offset+=len(b);digest.update(b)
    need(expected[-1:]==b'\n'and offset==len(expected)-1,'complete inverse and one external newline')
    digest.update(b'\n');need(digest.hexdigest()==hashlib.sha256(expected).hexdigest(),'whole inverse hash')
    return dict(bytes=len(expected),sha256=digest.hexdigest(),whole_literal_equal=True)

def import_source(name,descriptor):
    raw(descriptor);spec=importlib.util.spec_from_file_location(name,descriptor['path']);module=importlib.util.module_from_spec(spec)
    sys.modules[name]=module;spec.loader.exec_module(module);return module

def run_fixtures(codec,inverse,tick,rows,context):
    def enter(name):context['fixture']=name
    def record(name,**v):rows.append(json.loads(canonical(dict(name=name,passed=True,**v))))
    def expanded(table):return b''.join(codec.iter_expanded_canonical(table,tick,ENCODER_LIMITS))
    enter('typed_values_order_unicode_and_repeated_ports')
    shared={'port':[0,False,None,'\u03bb\n\\"']}
    value={'values':[None,False,True,0,-1,0.0,-0.0,1.5,1e20,'\u03bb\n\\"'],'ordered':[shared,shared],'missing':{},'assigned_zero':{'m':0}}
    expected=canonical(value);table=codec.freeze(value,tick,ENCODER_LIMITS);wire=codec.to_wire(table,tick,ENCODER_LIMITS)
    need(expanded(table)==expected,'typed fixture encoder inverse')
    need(b''.join(inverse.iter_inverse(wire,tick,INVERSE_LIMITS))==expected,'typed fixture independent inverse')
    need(canonical(codec.materialize(table,tick,ENCODER_LIMITS))==expected,'fresh small materialization exact canonical equality')
    record('typed_values_order_unicode_and_repeated_ports',input=value,wire=wire,canonical_utf8=expected.decode())
    enter('ordinary_attribute_assignment_blocked')
    try:table._root=0
    except AttributeError:record('ordinary_attribute_assignment_blocked')
    else:raise ValueError('ordinary frozen attribute assignment allowed')
    need(type(table.nodes)is tuple and all(type(n)is tuple for n in table.nodes),'immutable outer and typed nodes')
    enter('bool_int_and_signed_float_zero_distinct')
    need(['bool',False]in wire['nodes']and ['int','0']in wire['nodes']and ['float','0.0']in wire['nodes']and ['float','-0.0']in wire['nodes'],'typed nodes distinct')
    record('bool_int_and_signed_float_zero_distinct')
    enter('caller_and_wire_mutation_cannot_change_frozen')
    value['ordered'][0]['port'].append('caller mutation');value['new']='caller field'
    need(expanded(table)==expected,'caller mutation isolated')
    wire['nodes'].append(['str','wire mutation']);need(expanded(table)==expected,'public wire mutation isolated')
    record('caller_and_wire_mutation_cannot_change_frozen')
    enter('fresh_materialization_each_occurrence_and_call')
    fresh1=codec.materialize(table,tick,ENCODER_LIMITS);fresh2=codec.materialize(table,tick,ENCODER_LIMITS)
    need(fresh1 is not fresh2 and fresh1['ordered'][0]is not fresh1['ordered'][1],'fresh occurrence materialization')
    fresh1['ordered'][0]['port'].append('returned mutation');need(fresh2['ordered'][0]['port']==fresh2['ordered'][1]['port']and fresh1['ordered'][0]['port']!=fresh1['ordered'][1]['port']and expanded(table)==expected,'return mutation isolation')
    record('fresh_materialization_each_occurrence_and_call')
    def packet(nodes,root=None):return dict(schema='exact-evidence-node-table-v1',version='exact-evidence-table-v1',nodes=nodes,root=len(nodes)-1 if root is None else root)
    bad=[('boolean_root',packet([['null']],True)),('forward_self_reference',packet([['array',[0]]])),('dangling_reference',packet([['array',[8]]])),
         ('boolean_reference',packet([['null'],['array',[False]]])),('duplicate_typed_node',packet([['null'],['null'],['array',[0,1]]])),
         ('unreachable_node',packet([['null'],['bool',False]])),('duplicate_object_key',packet([['null'],['object',[['a',0],['a',0]]]])),
         ('unsorted_object_keys',packet([['null'],['object',[['b',0],['a',0]]]])),('noncanonical_integer',packet([['int','-0']])),
         ('nonfinite_float',packet([['float','NaN']])),('integer_in_float_tag',packet([['float','1']])),('lone_surrogate',packet([['str','\ud800']])),
         ('unknown_tag',packet([['absent']])),('extra_top_field',dict(packet([['null']]),extra=False))]
    for name,b in bad:
        enter(name);observed=[]
        try:codec.validate_wire(b,tick,ENCODER_LIMITS)
        except codec.EvidenceDataError:observed.append('encoder_rejected')
        try:list(inverse.iter_inverse(b,tick,INVERSE_LIMITS))
        except inverse.InverseDataError:observed.append('independent_rejected')
        need(observed==['encoder_rejected','independent_rejected'],'both malformed-wire rejections '+name)
        # Lone surrogates cannot enter an ordinary UTF-8 output packet.
        record(name,wire_ascii_json=json.dumps(b,ensure_ascii=True,sort_keys=True),observed=observed)
    enter('cyclic_caller_container_rejected')
    cycle=[];cycle.append(cycle)
    try:codec.freeze(cycle,tick,ENCODER_LIMITS)
    except codec.EvidenceDataError:record('cyclic_caller_container_rejected')
    else:raise ValueError('cycle accepted')
    for label in ['encoder','independent']:
        enter('inter_yield_mutation_'+label)
        between=packet([['str','x'*70000],['int','1'],['array',[0,1]]])
        original_between=json.loads(canonical(between));expected_between=canonical(['x'*70000,1])
        if label=='encoder':
            owned_between=codec.validate_wire(between,tick,ENCODER_LIMITS)
            stream_between=codec.iter_expanded_canonical(owned_between,tick,ENCODER_LIMITS)
        else:stream_between=inverse.iter_inverse(between,tick,INVERSE_LIMITS)
        first=next(stream_between);between['nodes'][1][1]='01'
        need(first+b''.join(stream_between)==expected_between,'owned stream after caller mutation '+label)
        record('inter_yield_mutation_'+label,input_wire=original_between,changed_node=1,new_payload='01',whole_original_canonical_sha256=hashlib.sha256(expected_between).hexdigest(),exact_original_stream_preserved=True)
    enter('shared_DAG_expansion_cap')
    small=packet([['null']]+[['array',[i-1,i-1]]for i in range(1,17)])
    counts=[]
    for label,operation in [('encoder',lambda:b''.join(codec.iter_expanded_canonical(codec.validate_wire(small,tick,ENCODER_LIMITS),tick,dict(ENCODER_LIMITS,max_expanded_bytes=64)))),('independent',lambda:b''.join(inverse.iter_inverse(small,tick,dict(INVERSE_LIMITS,expanded_bytes=64))))]:
        try:operation()
        except (codec.EvidenceLimit,inverse.InverseLimit)as error:
            if label=='encoder':need(codec.is_own_limit(error),'own expansion limit')
            counts.append(label)
    need(counts==['encoder','independent'],'bounded full expansion limit')
    record('shared_DAG_expansion_cap',wire=small,expanded_byte_limit=64,observed=counts)
    enter('depth_boundary_acceptance')
    depth_wire=packet([['null'],['array',[0]],['array',[1]],['array',[2]]])
    depth_table=codec.validate_wire(depth_wire,tick,dict(ENCODER_LIMITS,max_depth=3))
    need(b''.join(codec.iter_expanded_canonical(depth_table,tick,dict(ENCODER_LIMITS,max_depth=3)))==b'[[[null]]]'and b''.join(inverse.iter_inverse(depth_wire,tick,dict(INVERSE_LIMITS,depth=4)))==b'[[[null]]]','exact depth convention boundary')
    record('depth_boundary_acceptance',wire=depth_wire,encoder_edges=3,independent_nodes=4)
    for label,operation in [('encoder_depth',lambda:codec.validate_wire(depth_wire,tick,dict(ENCODER_LIMITS,max_depth=2))),('independent_depth',lambda:list(inverse.iter_inverse(depth_wire,tick,dict(INVERSE_LIMITS,depth=3)))),('encoder_work',lambda:codec.freeze(None,tick,dict(ENCODER_LIMITS,max_work=1))),('independent_work',lambda:list(inverse.iter_inverse(packet([['null']]),tick,dict(INVERSE_LIMITS,work=1))))]:
        enter(label+'_limit')
        try:operation()
        except (codec.EvidenceLimit,inverse.InverseLimit)as error:
            if label.startswith('encoder'):need(codec.is_own_limit(error),'owned bounded limit '+label)
            record(label+'_limit',limit_observed=True)
        else:raise ValueError('missing private bound '+label)
    class CallbackFailure(Exception):pass
    operations=[('freeze',lambda cb:codec.freeze({'x':1},cb)),('validate',lambda cb:codec.validate_wire(packet([['null']]),cb)),('wire',lambda cb:codec.to_wire(table,cb)),('expand',lambda cb:list(codec.iter_expanded_canonical(table,cb))),('materialize',lambda cb:codec.materialize(table,cb)),('independent',lambda cb:list(inverse.iter_inverse(packet([['null']]),cb)))]
    for error_name,error_type in [('custom',CallbackFailure),('runtime',RuntimeError),('value',ValueError)]:
        for label,operation in operations:
            enter('exact_callback_'+error_name+'_'+label)
            error=error_type(label)
            def callback():raise error
            try:operation(callback)
            except BaseException as caught:need(caught is error,'exact callback exception '+error_name+' '+label)
            else:raise ValueError('callback swallowed '+label)
            record('exact_callback_'+error_name+'_'+label,exact_exception_object_propagated=True)
    enter('foreign_limit_callback_identity')
    foreign=codec.EvidenceLimit('foreign callback limit')
    need(not codec.is_own_limit(foreign),'foreign EvidenceLimit not own')
    def foreign_cb():raise foreign
    try:codec.freeze(None,foreign_cb)
    except BaseException as caught:need(caught is foreign and not codec.is_own_limit(caught),'foreign limit propagates')
    else:raise ValueError('foreign limit swallowed')
    record('foreign_limit_callback_identity')
    enter('foreign_inverse_limit_callback_identity')
    foreign_inverse=inverse.InverseLimit('foreign inverse callback limit')
    need(not inverse.is_own_limit(foreign_inverse),'foreign inverse limit not own')
    def foreign_inverse_cb():raise foreign_inverse
    try:list(inverse.iter_inverse(packet([['null']]),foreign_inverse_cb))
    except BaseException as caught:need(caught is foreign_inverse and not inverse.is_own_limit(caught),'foreign inverse limit propagates')
    else:raise ValueError('foreign inverse limit swallowed')
    record('foreign_inverse_limit_callback_identity')
    return rows

def run_fragment_fixtures(inverse,tick,rows,context):
    def enter(name):context.update(fixture=name,inverse_statistics={})
    def record(name,**v):rows.append(json.loads(canonical(dict(name=name,passed=True,**v))))
    def packet(nodes):return dict(schema='exact-evidence-node-table-v1',version='exact-evidence-table-v1',nodes=nodes,root=len(nodes)-1)
    def observed(wire,limits=None):
        stats={};context['inverse_statistics']=stats
        stream=inverse.iter_inverse_observed(wire,tick,dict(INVERSE_LIMITS,**(limits or{})),statistics=stats);blocks=[]
        try:
            for block in stream:
                tick();need(type(block)is bytes and 0<len(block)<=65536,'bounded fragment inverse chunks');blocks.append(block)
        finally:stream.close()
        return b''.join(blocks),stats,[len(b)for b in blocks]
    leaf='x\n\\"\u03bb';base={'a':[leaf,7],'b':[leaf,7],'c':[leaf,7]}
    base_wire=packet([['str',leaf],['int','7'],['array',[0,1]],['object',[['a',2],['b',2],['c',2]]]])
    expected=canonical(base)
    enter('fragment_repeated_subtree_and_summary');body,stats,chunks=observed(base_wire)
    need(body==expected and stats['completed']is True and stats['cache_hits_stream']>0 and stats['cache_entries']>0,'actual repeated fragment path')
    need(stats['root_canonical_bytes']==len(expected)==stats['stream_copied_bytes']and stats['logical_occurrences_summary']==stats['stream_logical_occurrences']==10,'fragment summaries reconciled')
    record('fragment_repeated_subtree_and_summary',input=base,wire=base_wire,statistics=stats,chunk_bytes=chunks)
    for name,limits in [('fragment_disabled_payload',dict(cache_bytes=0)),('fragment_disabled_entries',dict(cache_entries=0)),('fragment_small_threshold',dict(fragment_bytes=1)),('fragment_partial_payload',dict(cache_bytes=2)),('fragment_partial_entries',dict(cache_entries=1))]:
        enter(name);body,stats,chunks=observed(base_wire,limits)
        need(body==expected and stats['completed']is True,'ordinary fallback exact '+name)
        if name in ('fragment_disabled_payload','fragment_disabled_entries'):
            need(stats['cache_entries']==0 and stats['cache_capacity_fallbacks']>0 and stats['cache_hits_stream']==0,'disabled cache uses ordinary traversal')
        elif name=='fragment_small_threshold':need(stats['cache_ineligible_nodes']>0 and stats['cache_hits_stream']>0,'mixed ineligible/cache paths')
        else:need(stats['cache_capacity_fallbacks']>0 and stats['cache_entries']>0 and stats['cache_hits_stream']>0,'partial cache full fallback')
        record(name,limits=limits,statistics=stats,chunk_bytes=chunks)
    enter('fragment_large_uncached_scalar')
    long='x'*70000;long_wire=packet([['str',long],['int','1'],['array',[0,1]],['array',[2,2]]]);long_expected=canonical([[long,1],[long,1]])
    body,stats,chunks=observed(long_wire)
    need(body==long_expected and stats['cache_ineligible_nodes']>0 and stats['cache_hits_stream']>0 and len(chunks)>=3 and max(chunks)<=65536,'uncached large scalar and cached child coexist')
    record('fragment_large_uncached_scalar',wire=long_wire,statistics=stats,chunk_bytes=chunks,whole_canonical_sha256=hashlib.sha256(long_expected).hexdigest())
    enter('fragment_escaped_keys_signed_zero')
    name='"k"\n\\\u03bb';escaped_wire=packet([['float','-0.0'],['float','0.0'],['object',[[name,0],['z',1]]],['array',[2,2]]]);escaped_input=[{name:-0.0,'z':0.0},{name:-0.0,'z':0.0}]
    body,stats,chunks=observed(escaped_wire)
    need(body==canonical(escaped_input)and stats['cache_hits_stream']>0,'cached escaped keys and signed zero')
    record('fragment_escaped_keys_signed_zero',wire=escaped_wire,input=escaped_input,statistics=stats)
    enter('fragment_integer_exact_expanded_boundary')
    int_wire=packet([['int','1'*64]]);body,stats,chunks=observed(int_wire,dict(expanded_bytes=64,scalar_bytes=64,chunk_bytes=17))
    need(body==b'1'*64 and stats['completed']is True and chunks==[17,17,17,13],'integer body bound excludes nonexistent string quotes')
    record('fragment_integer_exact_expanded_boundary',wire=int_wire,statistics=stats,chunk_bytes=chunks)
    enter('fragment_owned_work_limit_statistics')
    try:observed(base_wire,dict(work=1))
    except inverse.InverseLimit as error:
        need(inverse.is_own_limit(error)and error.reason=='work'and context['inverse_statistics']['completed']is False,'owned work UNKNOWN retains counters')
        record('fragment_owned_work_limit_statistics',reason=error.reason,statistics=context['inverse_statistics'])
    else:raise ValueError('missing fragment private work limit')
    enter('fragment_early_expanded_guard_modes');guards=[]
    for limits in [dict(expanded_bytes=len(expected)-1),dict(expanded_bytes=len(expected)-1,cache_bytes=0)]:
        try:observed(base_wire,limits)
        except inverse.InverseLimit as error:
            need(inverse.is_own_limit(error)and error.reason=='expanded bytes'and context['inverse_statistics']['stream_copied_bytes']==0,'full-root guard before stream')
            guards.append(dict(limits=limits,reason=error.reason,statistics=json.loads(canonical(context['inverse_statistics']))))
        else:raise ValueError('missing early expanded guard')
    record('fragment_early_expanded_guard_modes',outcomes=guards)
    many_wire=packet([['str','x'*100],['array',[0]*8],['array',[1]*200]])
    many_original=json.loads(canonical(many_wire));many_expected=canonical([['x'*100]*8]*200)
    enter('fragment_interyield_owned_input');stats={};context['inverse_statistics']=stats
    stream=inverse.iter_inverse_observed(many_wire,tick,INVERSE_LIMITS,statistics=stats)
    try:
        first=next(stream);many_wire['nodes'][0][1]='changed';many_wire['nodes'][1][1]=[99]
        body=first+b''.join(stream)
    finally:stream.close()
    need(body==many_expected and stats['completed']is True and stats['cache_hits_stream']>0,'owned cached stream after input mutation')
    record('fragment_interyield_owned_input',input_wire=many_original,statistics=stats,whole_canonical_sha256=hashlib.sha256(many_expected).hexdigest())
    enter('fragment_closed_incomplete_statistics');stats={};context['inverse_statistics']=stats
    stream=inverse.iter_inverse_observed(many_original,tick,INVERSE_LIMITS,statistics=stats)
    first=next(stream);stream.close()
    need(len(first)==65536 and stats['completed']is False and stats['stream_chunks']==1,'closed prefix remains incomplete')
    record('fragment_closed_incomplete_statistics',statistics=stats,first_chunk_bytes=len(first))
    enter('fragment_observer_mutation_is_not_authority');stats={};context['inverse_statistics']=stats
    stream=inverse.iter_inverse_observed(many_original,tick,INVERSE_LIMITS,statistics=stats)
    try:
        first=next(stream);stats.clear();stats['phase']='spoofed by caller';body=first+b''.join(stream)
    finally:stream.close()
    need(body==many_expected and stats['completed']is True and stats['phase']=='COMPLETE','observer dict never controls stream')
    record('fragment_observer_mutation_is_not_authority',statistics=stats)
    class LateCallbackFailure(Exception):pass
    for error_name,error_type in [('custom',LateCallbackFailure),('runtime',RuntimeError),('value',ValueError),('foreign_inverse_limit',inverse.InverseLimit)]:
        for path in ['mid_build','after_first_chunk']:
            label='fragment_exact_callback_'+path+'_'+error_name;enter(label);stats={};context['inverse_statistics']=stats
            marker=error_type('delayed callback');reached=False;seen_cached_build=False;first_returned=False
            def delayed():
                nonlocal reached,seen_cached_build
                phase=stats.get('phase');operation=stats.get('last_operation')
                if phase=='BUILD_BOUNDED_CALL_LOCAL_FRAGMENTS'and operation=='build_cache_hit':seen_cached_build=True
                hit=(path=='mid_build'and seen_cached_build and operation=='build_copy')or(path=='after_first_chunk'and first_returned and phase=='STREAM_EVERY_ORDINARY_OCCURRENCE'and operation=='stream_copy_block')
                if hit:reached=True;raise marker
                tick()
            stream=inverse.iter_inverse_observed(base_wire if path=='mid_build'else many_original,delayed,INVERSE_LIMITS,statistics=stats)
            caught=None
            try:
                if path=='after_first_chunk':
                    first=next(stream);need(len(first)==65536,'first chunk genuinely returned');first_returned=True
                list(stream)
            except BaseException as error:caught=error
            finally:stream.close()
            need(reached and caught is marker and stats['completed']is False,'noninitial exact callback object and reached branch '+label)
            if path=='mid_build':need(stats['cache_entries']>0 and stats['cache_hits_build']>0,'cached build path actually reached')
            else:need(first_returned and stats['stream_chunks']>=1 and stats['stream_copied_bytes']>=65536,'stream continuation path actually reached')
            if error_name=='foreign_inverse_limit':need(not inverse.is_own_limit(caught),'foreign delayed inverse limit remains foreign')
            record(label,exact_exception_object_propagated=True,branch_genuinely_reached=True,statistics=stats)
    context.pop('inverse_statistics',None)
    return rows


def main(plan_path):
    plan_path=Path(plan_path).resolve();plan=ordinary_load(plan_path.read_bytes());actual=Path(plan['actual_directory']);consumed=ordinary_load((actual/'CONSUMED.json').read_bytes())
    began=consumed['began_ns'];work=began+180000000000;overall=began+210000000000
    need(consumed['plan']==pin(plan_path)and consumed['invocation_id']==plan['invocation_id'],'exact consumed plan')
    need(consumed['work_deadline_ns']==work and consumed['overall_deadline_ns']==overall,'original clock deadlines')
    need(sys.platform=='darwin'and os.getpid()==os.getpgrp(),'declared platform and owned worker group')
    need(plan['limits']['work_seconds']==180 and plan['limits']['overall_seconds']==210 and plan['limits']['memory_bytes']==1073741824 and plan['limits']['result_bytes']==134217728 and plan['limits']['expanded_bytes']==134217728,'unchanged explicit qualification limits')
    need(raw(plan['worker'])==Path(__file__).read_bytes(),'exact worker Source')
    calls=0;guard_pins=[plan[k]for k in ['worker','encoder','inverse','python']]
    def guard():
        for d in guard_pins:need(pin(d['path'])==d,'current raw Source/runtime custody')
    def tick():
        nonlocal calls
        calls+=1
        if NOW()>=work:raise WorkDeadline('original work deadline')
        if calls%32768==0:guard()
    codec=None;inverse=None;results=[];fixtures=[];created_tables=[];encoded=0;expanded=0
    context=dict(stage='INTAKE_SOURCE',input=None,fixture=None);result_descriptor=None
    try:
        guard();tick();codec=import_source('qualified_exact_evidence_encoder',plan['encoder']);inverse=import_source('qualified_independent_evidence_inverse',plan['inverse'])
        for item in plan['inputs']:
            context.pop('inverse_statistics',None);context.update(stage='LOAD_INPUT',input=item['id']);tick();start=NOW();original=raw(item['input']);need(original[-1:]==b'\n','one canonical external newline')
            expanded+=len(original);need(expanded<=plan['limits']['expanded_bytes'],'aggregate expanded original size')
            value=ordinary_load(original);context['stage']='VERIFY_ORDINARY_CANONICAL_INPUT'
            baseline=compare_stream((part.encode('utf-8')for part in json.JSONEncoder(sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).iterencode(value)),original,tick)
            context['stage']='FREEZE_FULL_INPUT';froze=NOW();table=codec.freeze(value,tick,ENCODER_LIMITS);frozen_at=NOW();del value;gc.collect();tick()
            context['stage']='ENCODE_FULL_TABLE';wire=codec.to_wire(table,tick,ENCODER_LIMITS);out=actual/(item['id']+'-table.json')
            descriptor=streamed_file(out,wire,tick,plan['limits']['result_bytes']-encoded);encoded+=descriptor['bytes'];created_tables.append(descriptor)
            context['stage']='ENCODER_FULL_INVERSE';own=compare_stream(codec.iter_expanded_canonical(table,tick,ENCODER_LIMITS),original,tick)
            # Re-read the complete saved wire. The independent inverse imports no encoder code.
            context['stage']='READ_FULL_SAVED_TABLE';decoded=ordinary_load(raw(descriptor))
            context['stage']='VALIDATE_FULL_SAVED_TABLE';validated=codec.validate_wire(decoded,tick,ENCODER_LIMITS)
            context['stage']='SAVED_TABLE_ENCODER_INVERSE';reread=compare_stream(codec.iter_expanded_canonical(validated,tick,ENCODER_LIMITS),original,tick)
            context['stage']='INDEPENDENT_FULL_SAVED_INVERSE';statistics={};context['inverse_statistics']=statistics
            stream=inverse.iter_inverse_observed(decoded,tick,INVERSE_LIMITS,statistics=statistics)
            try:independent=compare_stream(stream,original,tick)
            finally:stream.close()
            need(statistics['completed']is True and statistics['execution_profile']=='independent-evidence-fragments-actual-operations-v4','complete declared fragment inverse')
            tag_counts={}
            for node in decoded['nodes']:tag_counts[node[0]]=tag_counts.get(node[0],0)+1
            context['stage']='COMMIT_COMPLETED_INPUT_PACKET';results.append(dict(id=item['id'],input=item['input'],encoded=descriptor,input_baseline=baseline,
                encoder_inverse=own,saved_wire_encoder_inverse=reread,independent_saved_wire_inverse=independent,
                immutable_node_count=len(decoded['nodes']),node_tag_counts=tag_counts,independent_inverse_statistics=statistics,
                root_node=decoded['nodes'][decoded['root']],root_id=decoded['root'],
                freeze_seconds=(frozen_at-froze)/1e9,total_interval_seconds=(NOW()-start)/1e9,
                no_scientific_semantic_admission=True))
            del original,table,wire,decoded,validated;context.pop('inverse_statistics',None);gc.collect();guard();tick()
        context.update(stage='DATA_FIXTURES',input=None);run_fixtures(codec,inverse,tick,fixtures,context)
        context.update(stage='FRAGMENT_DATA_FIXTURES',input=None);run_fragment_fixtures(inverse,tick,fixtures,context)
        need([f['name']for f in fixtures]==EXPECTED_FIXTURES,'complete exact70diagnostic sequence');guard();tick()
        context.update(stage='WRITE_CANDIDATE_RESULT',fixture=None)
        result=dict(schema='exact-evidence-qualification-result-v1',version=VERSION,invocation_id=plan['invocation_id'],
            representation_only=True,status='REPRESENTATION_QUALIFICATION_CANDIDATE',complete_inputs=results,fixtures=fixtures,
            expected_fixture_names=EXPECTED_FIXTURES,inverse_execution_profile=inverse.EXECUTION_PROFILE,
            inverse_work_accounting='New actual-operation profile with numeric20m bound; not a pass under oldV3 virtual-token-walk work units.',
            inverse_private_limits=dict(inverse.DEFAULT_LIMITS,**INVERSE_LIMITS),
            callback_count_at_result_construction=calls,aggregate_input_expanded_bytes=expanded,aggregate_encoded_table_bytes=encoded,
            current_Source=dict(encoder=plan['encoder'],independent_inverse=plan['inverse'],worker=plan['worker']),
            scientific_proof_replays=0,Native_calls=0,search_calls=0,Model_calls=0,opaque_Native_decodes=0,
            new_target_proof=False,Model_permission=False,schema_inventory_admission=False,goal_complete=False,
            scope='Whole prior ordinary data representation only. Mutable parsed input is released after freezing, and inputs processed serially. This is not integrated search-worker RAM or a recovery of either absent failed result.',
            expanded_budget_semantics='Both aggregate physical table+result bytes and fully expanded canonical input bytes must satisfy original numeric128MiB guard; no compact-wire-only profile claim.')
        result_descriptor=save_new(actual/'result.json',result);need(encoded+result_descriptor['bytes']<=plan['limits']['result_bytes'],'aggregate table and result bytes');tick();guard()
        context['stage']='WRITE_WORKER_HEADER'
        save_new(actual/'worker-receipt.json',dict(schema='exact-evidence-qualification-worker-receipt-v1',
            invocation_id=plan['invocation_id'],plan=pin(plan_path),began_ns=began,work_deadline_ns=work,overall_deadline_ns=overall,
            result=result_descriptor,tables=[r['encoded']for r in results],work_completed_ns=NOW(),
            representation_qualification_candidate=True,scientific_acceptance=False,mathematical_proof_accepted=False,Model_permission=False))
        tick()
    except BaseException as error:
        # Diagnostics preserve failure; no result/receipt is admitted by existence alone.
        own_codec_limit=codec is not None and codec.is_own_limit(error)
        own_inverse_limit=inverse is not None and inverse.is_own_limit(error)
        disposition=('UNKNOWN_WORK_DEADLINE'if type(error)is WorkDeadline else 'UNKNOWN_EVIDENCE_LIMIT'if own_codec_limit or own_inverse_limit else 'FAILED_SOURCE_OR_RUNTIME')
        limit_packet=(dict(reason=error.reason,counts=error.counts,limits=error.limits)if own_codec_limit else dict(reason=str(error))if own_inverse_limit else None)
        if not(actual/'worker-failure.json').exists():save_new(actual/'worker-failure.json',dict(schema='exact-evidence-worker-failure-v1',status=disposition,type=type(error).__name__,message=str(error),own_codec_limit=own_codec_limit,own_inverse_limit=own_inverse_limit,limit=limit_packet,reached_context=context,completed_input_packets=results,completed_fixture_prefix=fixtures,published_table_prefix=created_tables,callback_count_at_failure=calls,aggregate_expanded_input_prefix_bytes=expanded,aggregate_encoded_table_prefix_bytes=encoded,published_result_candidate=result_descriptor,scientific_acceptance=False,representation_accepted=False))
        raise

if __name__=='__main__':
    need(len(sys.argv)==2,'one exact plan path');main(sys.argv[1])
