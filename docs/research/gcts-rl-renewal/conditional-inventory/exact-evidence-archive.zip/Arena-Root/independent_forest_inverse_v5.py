"""Independent bounded forest inverse, derived from Root's own inverse V5.

Imports no encoder, arena, proof runtime or scientific payload. The forest
profile is new; old per-call and default20m qualifications are not inherited.
Exclusive builtin input/callback ownership and pinned Python/OS are assumptions.
"""
import json
import math
import re

VERSION='independent-evidence-forest-inverse-v5-quoted-scalar-bound'
EXECUTION_PROFILE='independent-forest-actual-operations-v1'
SCHEMA='exact-evidence-forest-v1'
WIRE_VERSION='exact-evidence-arena-v1'
DEFAULT_LIMITS=dict(nodes=2000000,edges=8000000,roots=4096,depth=513,
    work=30000000,expanded_bytes=134217728,wire_bytes=134217728,
    scalar_bytes=16777216,integer_digits=4096,fragment_bytes=4096,
    cache_bytes=8388608,cache_entries=65536,chunk_bytes=65536)
_LIMIT_TOKEN=object()
_PREPARED_TOKEN=object()
class ForestDataError(ValueError):pass
class ForestLimit(RuntimeError):
    def __init__(self,reason,*,_owner=None):
        self.reason=reason;self._owner=_owner;super().__init__(reason)
class ForestReentrancyError(RuntimeError):
    def __init__(self,reason,*,_owner=None):
        self._owner=_owner;super().__init__(reason)
def is_own_reentrancy(error):
    return type(error)is ForestReentrancyError and error._owner is _LIMIT_TOKEN
def is_own_limit(error):
    return type(error)is ForestLimit and error._owner is _LIMIT_TOKEN
def _stop(reason):raise ForestLimit(reason,_owner=_LIMIT_TOKEN)
def _need(value,message):
    if not value:raise ForestDataError(message)
def _token(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode('utf-8')
def _limits(limits):
    cap=dict(DEFAULT_LIMITS)
    if limits is not None:
        _need(type(limits)is dict and not set(limits)-set(cap),'known inverse limits')
        cap.update(limits)
    for k,v in cap.items():
        _need(type(v)is int and v>=(0 if k in ('cache_bytes','cache_entries')else 1),'strict integer inverse limits')
    for k in ['cache_bytes','cache_entries','fragment_bytes','chunk_bytes']:
        _need(cap[k]<=DEFAULT_LIMITS[k],'bounded '+k)
    return cap

class _State:
    def __init__(self,check,cap,observer):
        _need(callable(check),'charged inverse check required')
        self.check=check;self.cap=cap;self.observer=observer;self.in_callback=False
        self.stats=dict(execution_profile=EXECUTION_PROFILE,phase='START',
            attempted_operations=0,operations_by_kind={},callback_dispatches=0,
            validated_nodes=0,validated_edges=0,scalar_characters_scanned=0,
            catalogue_roots=0,logical_documents=0,wire_canonical_bytes=None,
            aggregate_document_bytes=None,cache_entries=0,cache_payload_bytes=0,
            cache_attempts=0,cache_capacity_fallbacks=0,cache_ineligible_nodes=0,
            cache_hits_build=0,cache_hits_stream=0,build_copied_bytes=0,
            prepared=False,documents={})
    def gate(self):
        if self.in_callback:raise ForestReentrancyError('no charged inverse API from callback',_owner=_LIMIT_TOKEN)
    def tick(self,kind):
        self.gate();s=self.stats;s['last_operation']=kind
        s['attempted_operations']+=1
        s['operations_by_kind'][kind]=s['operations_by_kind'].get(kind,0)+1
        if self.observer is not None:
            self.observer['phase']=s['phase'];self.observer['last_operation']=kind
        if s['attempted_operations']>self.cap['work']:_stop('work')
        s['callback_dispatches']+=1;self.in_callback=True
        try:self.check()
        finally:self.in_callback=False
    def snapshot(self):
        s=dict(self.stats);s['operations_by_kind']=dict(self.stats['operations_by_kind'])
        s['documents']={k:dict(v)for k,v in self.stats['documents'].items()}
        return s
    def publish(self):
        if self.observer is not None:
            self.observer.clear();self.observer.update(self.snapshot())
    def publish_preserving_error(self):
        # No delegated operations here. Diagnostics cannot replace an active error.
        try:self.publish()
        except BaseException:pass
    def metrics(self,value,*,quoted=True):
        _need(type(value)is str,'exact Unicode scalar string')
        width=0;escaped=2
        for start in range(0,len(value),4096):
            self.tick('scalar_scan_window')
            for c in value[start:start+4096]:
                n=ord(c);self.stats['scalar_characters_scanned']+=1
                _need(not 0xD800<=n<=0xDFFF,'Unicode scalar value required')
                b=1 if n<128 else 2 if n<2048 else 3 if n<65536 else 4
                width+=b;escaped+=2 if c in ('"','\\','\b','\f','\n','\r','\t')else 6 if n<32 else b
            if (escaped if quoted else width)>self.cap['scalar_bytes']:_stop('scalar bytes')
            if (escaped if quoted else width)>self.cap['expanded_bytes']:_stop('expanded bytes')
        if (escaped if quoted else width)>self.cap['scalar_bytes']:_stop('scalar bytes')
        if (escaped if quoted else width)>self.cap['expanded_bytes']:_stop('expanded bytes')
        return width,escaped
    def tokenize(self,value,size):
        self.tick('tokenize_begin');b=_token(value);self.tick('tokenize_end')
        _need(len(b)==size,'independent token byte reconciliation');return b

class _Pieces:
    """Explicit token walk; None is internal end, never StopIteration."""
    def __init__(self,prepared,root,phase):
        self.prepared=prepared;self.stack=[(root,-1)];self.pending=[];self.phase=phase
    def take(self):
        p=self.prepared;state=p._state
        while self.pending or self.stack:
            state.tick(self.phase+'_walk_action')
            if self.pending:return self.pending.pop()
            at,index=self.stack[-1];node=p._nodes[at];tag=node[0]
            if index==-1 and at in p._cache:
                state.tick(self.phase+'_cache_hit');self.stack.pop();state.stats['cache_hits_'+self.phase]+=1
                return p._cache[at],p._counts[at]
            if tag not in ('array','object'):
                self.stack.pop()
                if tag=='null':piece=b'null'
                elif tag=='bool':piece=b'true'if node[1]else b'false'
                elif tag in ('int','float'):
                    state.tick('ascii_token_begin');piece=node[1].encode('ascii');state.tick('ascii_token_end')
                else:piece=state.tokenize(node[1],p._sizes[at])
                return piece,1
            if index==-1:
                self.stack[-1]=(at,0);return (b'['if tag=='array'else b'{'),1
            if index==len(node[1]):
                self.stack.pop();return (b']'if tag=='array'else b'}'),0
            self.stack[-1]=(at,index+1)
            prefix=[]
            if index:prefix.append((b',',0))
            if tag=='array':child=node[1][index]
            else:
                key,child=node[1][index]
                prefix.extend([(state.tokenize(key,p._key_sizes[at][index]),0),(b':',0)])
            self.stack.append((child,-1));self.pending.extend(reversed(prefix))
        return None

class _DocumentStream:
    """No generator frame: delegated StopIteration is preserved exactly.

    An outer for-loop may interpret it as exhaustion; completed stays false,
    and callers MUST independently require completed before admitting output.
    """
    def __init__(self,prepared,root,row):
        self.prepared=prepared;self.root=root;self.row=row;self.pieces=_Pieces(prepared,root,'stream')
        self.pending=bytearray();self.piece=None;self.offset=0;self.value_count=0;self.closed=False
    @property
    def completed(self):
        self.prepared._state.gate();return self.row['completed']
    def __iter__(self):return self
    def __next__(self):
        state=self.prepared._state;state.gate()
        if self.closed:raise StopIteration
        try:part=self._advance()
        except BaseException:
            self.closed=True;self.row['closed_incomplete']=not self.row['completed']
            state.publish_preserving_error();raise
        if part is None:
            self.closed=True;state.publish();raise StopIteration
        return part
    def _emit(self):
        state=self.prepared._state;state.tick('yield_chunk');chunk=bytes(self.pending)
        self.pending.clear();self.row['chunks']+=1;self.row['emitted_body_bytes']+=len(chunk)
        return chunk
    def _advance(self):
        p=self.prepared;state=p._state;state.stats['phase']='STREAM_DOCUMENT'
        while True:
            if self.piece is None:
                part=self.pieces.take()
                if part is None:
                    if self.pending:return self._emit()
                    _need(self.row['copied_body_bytes']==p._sizes[self.root],'complete body byte reconciliation')
                    _need(self.row['emitted_body_bytes']==p._sizes[self.root],'complete emitted byte reconciliation')
                    _need(self.row['stream_value_occurrences']==p._counts[self.root],'complete value occurrence reconciliation')
                    state.tick('document_completion');self.row['completed']=True
                    state.stats['phase']='DOCUMENT_COMPLETE';return None
                piece,self.value_count=part;self.piece=memoryview(piece);self.offset=0
            state.tick('stream_copy_block')
            take=min(state.cap['chunk_bytes']-len(self.pending),len(self.piece)-self.offset)
            _need(self.row['copied_body_bytes']+take<=p._sizes[self.root],'precopy document bound')
            self.pending.extend(self.piece[self.offset:self.offset+take]);self.offset+=take;self.row['copied_body_bytes']+=take
            if self.offset==len(self.piece):
                self.row['stream_value_occurrences']+=self.value_count;self.piece=None
            if len(self.pending)==state.cap['chunk_bytes']:return self._emit()
    def close(self):
        # Reject callback reentrancy; cleanup itself invokes no callbacks/snapshots.
        self.prepared._state.gate();self.closed=True
        if not self.row['completed']:self.row['closed_incomplete']=True
        self.pending.clear();self.piece=None

class PreparedForest:
    __slots__=('_nodes','_catalogue','_documents','_sizes','_counts','_key_sizes','_cache','_state')
    def __init__(self,nodes,catalogue,documents,sizes,counts,key_sizes,cache,state,*,_token=None):
        if _token is not _PREPARED_TOKEN:raise TypeError('use prepare_forest')
        for k,v in dict(_nodes=nodes,_catalogue=catalogue,_documents=documents,
            _sizes=sizes,_counts=counts,_key_sizes=key_sizes,_cache=cache,_state=state).items():
            object.__setattr__(self,k,v)
    def __setattr__(self,name,value):raise AttributeError('immutable prepared forest interface')
    def __delattr__(self,name):raise AttributeError('immutable prepared forest interface')
    @property
    def documents(self):
        self._state.gate();out=[]
        for label,root in self._documents:self._state.tick('document_label_read');out.append(label)
        return tuple(out)
    @property
    def catalogue(self):
        self._state.gate();self._state.tick('catalogue_read');return self._catalogue
    def statistics(self):return self._state.snapshot()
    def iter_document(self,label):
        # Resolve owned root eagerly; no caller wire is consulted by the iterator.
        state=self._state;state.gate();state.metrics(label);found=[]
        for name,root in self._documents:
            state.tick('document_lookup')
            if name==label:found.append(root)
        _need(len(found)==1,'declared document label')
        state.tick('document_stream_attempt');row=state.stats['documents'][label]
        _need(row['attempts']==0,'one independently checked stream per document')
        stream=_DocumentStream(self,found[0],row)
        row['attempts']+=1
        return stream

def prepare_forest(wire,check,limits=None,*,statistics=None):
    if statistics is not None:_need(type(statistics)is dict and not statistics,'fresh inverse observation dictionary')
    state=_State(check,_limits(limits),statistics);cap=state.cap;s=state.stats
    try:
        state.tick('initial');s['phase']='VALIDATE_COMPLETE_FOREST'
        fields={'schema','version','source_epoch','semantic_epoch','roots','documents','nodes'}
        _need(type(wire)is dict and set(wire)==fields,'exact forest fields')
        _need(wire['schema']==SCHEMA and wire['version']==WIRE_VERSION,'forest identity')
        epoch_sizes={k:state.metrics(wire[k])[1]for k in ['source_epoch','semantic_epoch']}
        raw_nodes=wire['nodes'];raw_roots=wire['roots'];raw_docs=wire['documents']
        _need(type(raw_nodes)is list and bool(raw_nodes),'nonempty complete node table')
        _need(type(raw_roots)is list and bool(raw_roots),'nonempty root catalogue')
        _need(type(raw_docs)is list and bool(raw_docs),'nonempty ordered logical document list')
        if len(raw_nodes)>cap['nodes']:_stop('nodes')
        if len(raw_roots)>cap['roots']or len(raw_docs)>cap['roots']:_stop('roots')
        nodes=[];heights=[];sizes=[];counts=[];key_sizes=[];typed=set();node_wire_total=0
        for i,node in enumerate(raw_nodes):
            state.tick('validate_node');_need(type(node)is list and bool(node)and type(node[0])is str,'typed node shape')
            tag=node[0];refs=[];lengths=();scalar=None;wire_size=None
            if tag=='null':
                _need(len(node)==1,'null arity');key=('null',);scalar=4;wire_size=8
            else:
                _need(len(node)==2,'typed node arity');value=node[1]
                if tag=='bool':
                    _need(type(value)is bool,'exact bool');key=(tag,value);scalar=4 if value else 5;wire_size=9+scalar
                elif tag=='int':
                    _need(type(value)is str,'integer string')
                    digits=len(value)-(1 if value.startswith('-')else 0)
                    if digits>cap['integer_digits']:_stop('integer digits')
                    scalar,quoted=state.metrics(value,quoted=False);state.tick('integer_lexeme_begin')
                    _need(re.fullmatch(r'(?:0|-[1-9][0-9]*|[1-9][0-9]*)',value)is not None,'canonical decimal integer')
                    state.tick('integer_lexeme_end');key=(tag,value);wire_size=8+quoted
                elif tag=='float':
                    _need(type(value)is str and len(value)<=64,'bounded float lexeme')
                    scalar,quoted=state.metrics(value,quoted=False);state.tick('float_parse_begin')
                    try:number=json.loads(value)
                    except (ValueError,RecursionError)as error:raise ForestDataError('float parse')from error
                    state.tick('float_parse_end');_need(type(number)is float and math.isfinite(number),'finite exact float')
                    state.tick('float_canonical_begin');text=_token(number).decode('utf-8');state.tick('float_canonical_end')
                    _need(text==value,'canonical float lexical identity');key=(tag,value);wire_size=10+quoted
                elif tag=='str':
                    _,scalar=state.metrics(value);key=(tag,value);wire_size=8+scalar
                elif tag=='array':
                    _need(type(value)is list,'array references')
                    if len(value)>cap['edges']-s['validated_edges']:_stop('edges')
                    refs=tuple(value);key=(tag,refs);wire_size=12+max(0,len(refs)-1)
                elif tag=='object':
                    _need(type(value)is list,'object pairs')
                    if len(value)>cap['edges']-s['validated_edges']:_stop('edges')
                    pairs=[];length_list=[];previous=None
                    for pair in value:
                        state.tick('validate_pair');_need(type(pair)is list and len(pair)==2,'object pair shape')
                        name,ref=pair;_,key_size=state.metrics(name)
                        _need(previous is None or previous<name,'unique sorted exact object keys')
                        previous=name;pairs.append((name,ref));refs.append(ref);length_list.append(key_size)
                    key=(tag,tuple(pairs));lengths=tuple(length_list);wire_size=13+max(0,len(refs)-1)
                else:raise ForestDataError('unknown typed node')
            height=1;occ=1
            if tag in ('array','object'):size=2+max(0,len(refs)-1)
            else:size=scalar
            for j,ref in enumerate(refs):
                state.tick('validate_edge');s['validated_edges']+=1
                _need(type(ref)is int and 0<=ref<i,'strict prior integer reference')
                state.tick('reference_wire_digits');digits=len(str(ref))
                wire_size+=digits+(3+lengths[j]if tag=='object'else 0)
                height=max(height,1+heights[ref]);size+=sizes[ref];occ+=counts[ref]
                if tag=='object':size+=lengths[j]+1
                if size>cap['expanded_bytes']or occ>cap['expanded_bytes']:_stop('expanded bytes')
            if height>cap['depth']:_stop('depth')
            if size>cap['expanded_bytes']or occ>cap['expanded_bytes']:_stop('expanded bytes')
            state.tick('typed_equality_begin')
            _need(key not in typed,'duplicate complete typed node');typed.add(key)
            state.tick('typed_equality_end');nodes.append(key);heights.append(height);sizes.append(size);counts.append(occ);key_sizes.append(lengths)
            node_wire_total+=wire_size;s['validated_nodes']+=1
            if node_wire_total>cap['wire_bytes']:_stop('wire bytes')
        nodes=tuple(nodes);sizes=tuple(sizes);counts=tuple(counts);key_sizes=tuple(key_sizes)
        catalogue=[];labels={};root_wire_total=0
        s['phase']='VALIDATE_ROOT_DOCUMENT_LEDGER'
        for pair in raw_roots:
            state.tick('catalogue_root');_need(type(pair)is list and len(pair)==2,'root pair shape')
            label,root=pair;_,length=state.metrics(label)
            _need(bool(label)and label not in labels,'nonempty unique exact root label')
            _need(type(root)is int and 0<=root<len(nodes),'strict root ID')
            state.tick('catalogue_reference_digits');root_wire_total+=3+length+len(str(root))
            catalogue.append((label,root));labels[label]=root
        documents=[];doc_names=set();doc_wire_total=0;aggregate=0;uses=[0]*len(nodes)
        for label in raw_docs:
            state.tick('logical_document');_,length=state.metrics(label)
            _need(label in labels and label not in doc_names,'unique declared root label for document')
            doc_names.add(label);root=labels[label];documents.append((label,root));doc_wire_total+=length
            aggregate+=sizes[root]+1
            if aggregate>cap['expanded_bytes']:_stop('aggregate document bytes')
            uses[root]+=1
            s['documents'][label]=dict(root_id=root,body_bytes=sizes[root],logical_file_bytes=sizes[root]+1,
                logical_value_occurrences=counts[root],node_height=heights[root],attempts=0,
                copied_body_bytes=0,emitted_body_bytes=0,stream_value_occurrences=0,chunks=0,completed=False,closed_incomplete=False)
        n=len(nodes);r=len(catalogue);d=len(documents)
        values=dict(source_epoch=epoch_sizes['source_epoch'],semantic_epoch=epoch_sizes['semantic_epoch'],
            schema=len(_token(SCHEMA)),version=len(_token(WIRE_VERSION)),
            nodes=2+max(0,n-1)+node_wire_total,roots=2+max(0,r-1)+root_wire_total,
            documents=2+max(0,d-1)+doc_wire_total)
        physical=2+6+sum(len(_token(k))+1+v for k,v in values.items())+1
        if physical>cap['wire_bytes']:_stop('wire bytes')
        s.update(catalogue_roots=r,logical_documents=d,wire_canonical_bytes=physical,aggregate_document_bytes=aggregate)
        del raw_nodes,raw_roots,raw_docs,wire,typed,labels,doc_names,epoch_sizes,heights
        s['phase']='COMPLETE_DOCUMENT_REACHABILITY_AND_MULTIPLICITY';overflow=cap['expanded_bytes']+1;sum_uses=0
        for i in range(len(nodes)-1,-1,-1):
            state.tick('reachability_node');count=uses[i];_need(count>0,'node not covered by complete logical documents')
            sum_uses=min(overflow,sum_uses+count)
            node=nodes[i];refs=node[1]if node[0]=='array'else(p[1]for p in node[1])if node[0]=='object'else()
            for ref in refs:
                state.tick('reachability_edge');uses[ref]=min(overflow,uses[ref]+count)
        expected=sum(counts[root]for label,root in documents)
        _need(sum_uses==expected and sum_uses<overflow,'independent occurrence recurrences reconcile')
        _need(all(uses[root]>0 for label,root in catalogue),'catalogue covered by document projection')
        s['aggregate_document_value_occurrences']=expected
        prepared=PreparedForest(nodes,tuple(catalogue),tuple(documents),sizes,counts,key_sizes,{},state,_token=_PREPARED_TOKEN)
        s['phase']='BUILD_BOUNDED_FOREST_FRAGMENTS'
        for i in range(len(nodes)):
            state.tick('cache_eligibility')
            if uses[i]<2 or sizes[i]>cap['fragment_bytes']:
                s['cache_ineligible_nodes']+=1;continue
            s['cache_attempts']+=1
            if len(prepared._cache)>=cap['cache_entries']or s['cache_payload_bytes']+sizes[i]>cap['cache_bytes']:
                s['cache_capacity_fallbacks']+=1;continue
            fragment=bytearray();values_count=0
            parts=_Pieces(prepared,i,'build')
            while True:
                part=parts.take()
                if part is None:break
                piece,count=part
                state.tick('build_copy');_need(len(fragment)+len(piece)<=sizes[i],'bounded fragment preallocation')
                fragment.extend(piece);values_count+=count;s['build_copied_bytes']+=len(piece)
            _need(len(fragment)==sizes[i]and values_count==counts[i],'fragment exact byte/value reconciliation')
            state.tick('freeze_fragment');prepared._cache[i]=bytes(fragment)
            s['cache_entries']=len(prepared._cache);s['cache_payload_bytes']+=sizes[i]
        state.tick('preparation_completion');s['prepared']=True;s['phase']='PREPARED_COMPLETE_FOREST'
    except BaseException:
        state.publish_preserving_error();raise
    state.publish();return prepared
