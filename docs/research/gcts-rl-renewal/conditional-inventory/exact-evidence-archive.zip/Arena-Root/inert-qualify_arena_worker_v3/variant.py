"""One prospective data-only arena qualification; no import-time work."""
import time
NOW=time.monotonic_ns
import gc
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys

VERSION='incremental-arena-qualification-worker-v3-127-diagnostics'
class WorkDeadline(RuntimeError):pass
def need(value,message):
    if not value:raise ValueError(message)
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode('utf8')
def pin(p):
    p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def raw(d):
    b=Path(d['path']).read_bytes();need(dict(path=str(Path(d['path']).resolve()),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())==d,'whole exact raw descriptor');return b
def strict_object(pairs):
    d={}
    for k,v in pairs:
        need(k not in d,'duplicate JSON object key');d[k]=v
    return d
def ordinary_load(b):
    def bad_constant(v):raise ValueError('finite JSON scalars required')
    return json.loads(b,object_pairs_hook=strict_object,parse_constant=bad_constant)
def save_new(p,v):
    b=canonical(v)+b'\n';fd=os.open(str(p),os.O_CREAT|os.O_EXCL|os.O_WRONLY|os.O_NOFOLLOW,0o600)
    with os.fdopen(fd,'wb')as f:f.write(b);f.flush();os.fsync(f.fileno())
    return pin(p)
def import_source(name,d):
    raw(d);spec=importlib.util.spec_from_file_location(name,d['path']);m=importlib.util.module_from_spec(spec)
    sys.modules[name]=m;spec.loader.exec_module(m);return m

def main(plan_path):
    plan_path=Path(plan_path).resolve();plan=ordinary_load(plan_path.read_bytes());actual=Path(plan['actual_directory'])
    consumed=ordinary_load((actual/'CONSUMED.json').read_bytes());began=consumed['began_ns']
    work=began+180000000000;overall=began+210000000000
    need(consumed['plan']==pin(plan_path)and consumed['invocation_id']==plan['invocation_id'],'consumed exact subject')
    need(consumed['work_deadline_ns']==work and consumed['overall_deadline_ns']==overall,'unchanged declared clock epoch')
    need(sys.platform=='darwin'and os.getpid()==os.getpgrp(),'declared owned Darwin worker')
    expected_limits=dict(work_seconds=180,overall_seconds=210,memory_bytes=1073741824,result_bytes=134217728,expanded_bytes=134217728,stdout_bytes=4194304,stderr_bytes=4194304)
    need(plan['limits']==expected_limits,'all original global numeric gates')
    need(raw(plan['worker'])==Path(__file__).read_bytes(),'current full worker Source')
    declaration=ordinary_load(raw(plan['declaration']))
    aux=declaration['auxiliary_sources']
    need(type(aux)is dict and set(aux)=={'legacy_encoder','legacy_inverse','legacy_fixture_worker','arena_fixture_module','forest_fixture_module'},'complete auxiliary Source set')
    descriptors={k:plan[k]for k in ['worker','encoder','inverse','runner','observer']};descriptors.update(aux)
    runtime=plan['python'];calls=0;deadline_error=[None]
    def guard():
        for d in [runtime,*descriptors.values()]:need(pin(d['path'])==d,'current raw Source/runtime custody')
    def tick():
        nonlocal calls
        calls+=1
        if NOW()>=work:
            error=WorkDeadline('original work deadline');deadline_error[0]=error;raise error
        if calls%32768==0:guard()
    fixture_rows=[];results=[];capture_prefix=[];forests=[];expanded=0;encoded=0;result_descriptor=None
    context=dict(stage='INTAKE_SOURCE',input=None,fixture=None);arena_module=None;inverse=None;arena=None;prepared=None
    try:
        guard();tick()
        arena_module=import_source('current_incremental_arena',plan['encoder'])
        inverse=import_source('current_independent_forest_inverse',plan['inverse'])
        old_codec=import_source('retained_percall_encoder',aux['legacy_encoder'])
        old_inverse=import_source('retained_percall_inverse',aux['legacy_inverse'])
        old_tests=import_source('retained_seventy_one_fixture_worker',aux['legacy_fixture_worker'])
        arena_tests=import_source('current_arena_fixtures',aux['arena_fixture_module'])
        forest_tests=import_source('current_forest_fixtures',aux['forest_fixture_module'])
        expected=list(old_tests.EXPECTED_FIXTURES)+list(arena_tests.EXPECTED_ARENA_FIXTURES)+list(forest_tests.EXPECTED_FOREST_FIXTURES)
        need(len(old_tests.EXPECTED_FIXTURES)==71 and len(arena_tests.EXPECTED_ARENA_FIXTURES)==33 and len(forest_tests.EXPECTED_FOREST_FIXTURES)==23 and len(expected)==127 and expected==declaration['expected_fixture_names']and len(set(expected))==len(expected),'whole declared fixture sequence')
        arena_limits=declaration['arena_limits'];inverse_limits=declaration['forest_inverse_limits']
        need(arena_limits==declaration['shared_contract_limits']and arena_limits['root_expanded_bytes']==arena_limits['documents_expanded_bytes']==arena_limits['wire_bytes']==134217728,'unchanged arena expansion/physical guards')
        need(inverse_limits['expanded_bytes']==inverse_limits['wire_bytes']==134217728,'unchanged inverse expansion/physical guards')
        context.update(stage='RETAINED_SEVENTY_ONE_DIAGNOSTICS')
        old_tests.run_fixtures(old_codec,old_inverse,tick,fixture_rows,context)
        old_tests.run_fragment_fixtures(old_inverse,tick,fixture_rows,context)
        need([x['name']for x in fixture_rows]==list(old_tests.EXPECTED_FIXTURES),'all retained71 diagnostics first')
        context.update(stage='NEW_ARENA_DIAGNOSTICS')
        arena_return=arena_tests.run_arena_fixtures(arena_module,arena_limits,tick,guard,fixture_rows,context)
        need(type(arena_return)is dict and arena_return['schema']=='arena-finite-fixtures-return-v1'and arena_return['count']==33 and arena_return['completed']==list(arena_tests.EXPECTED_ARENA_FIXTURES)and arena_return['authority']is False,'complete exact arena fixture return')
        context.update(stage='NEW_FOREST_DIAGNOSTICS')
        forest_tests.run_forest_fixtures(inverse,tick,fixture_rows,context)
        need([x['name']for x in fixture_rows]==expected and len(fixture_rows)==127,'all declared diagnostic names/order')
        need(all(x['passed']is True for x in fixture_rows[:71]+fixture_rows[104:]),'strict retained71 and Root23 success booleans')
        need(all(set(x)=={'schema','name','status','scope','observed','authority'}and x['schema']=='arena-finite-diagnostic-v1'and x['status']=='passed'and x['authority']is False for x in fixture_rows[71:104]),'strict Library33 original packet schema/status')
        guard();tick();gc.collect()
        # Full literal Sources are data in the new forest header. No source text
        # or old mathematical payload is evaluated through the evidence carrier.
        source_epoch=canonical({k:raw(d).decode('utf8')for k,d in descriptors.items()}).decode('utf8')
        semantic_epoch=canonical(dict(scope='ordinary data only',inputs=plan['inputs'],arena_limits=arena_limits,forest_inverse_limits=inverse_limits,fixture_names=expected)).decode('utf8')
        context.update(stage='NEW_SINGLE_INVOCATION_ARENA',fixture=None)
        arena=arena_module.Arena(source_epoch=source_epoch,semantic_epoch=semantic_epoch,check=tick,source_guard=guard,limits=arena_limits)
        handles=[]
        for item in plan['inputs']:
            context.update(stage='LOAD_COMPLETE_ORIGINAL',input=item['id']);tick();start=NOW();original=raw(item['input'])
            need(original[-1:]==b'\n','one external original LF');expanded+=len(original)
            need(expanded<=plan['limits']['expanded_bytes'],'aggregate original expanded cap')
            value=ordinary_load(original);context['stage']='VERIFY_COMPLETE_CANONICAL_ORIGINAL'
            baseline=old_tests.compare_stream((part.encode('utf8')for part in json.JSONEncoder(sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).iterencode(value)),original,tick)
            context['stage']='CAPTURE_COMPLETE_ORIGINAL';captured_at=NOW();handle=arena.capture(value,label=item['id']);capture_done=NOW();del value;gc.collect();tick()
            handles.append(handle);context['stage']='ARENA_FULL_LITERAL_BODY_STREAM';stream=arena.iter_canonical(handle)
            try:
                own=old_tests.compare_stream(stream,original,tick)
                need(stream.completed,'arena explicit final completion required')
            finally:stream.close()
            root=arena.view(handle).node_id
            capture_prefix.append(dict(id=item['id'],input=item['input'],input_baseline=baseline,arena_canonical=own,root_id=root,
                capture_seconds=(capture_done-captured_at)/1e9,capture_and_projection_seconds=(NOW()-start)/1e9,
                independent_saved_wire_inverse_complete=False,no_scientific_semantic_admission=True))
            del original;gc.collect();guard();tick()
        context.update(stage='SEAL_COMPLETE_FOREST',input=None)
        sealed=arena.seal([r['id']for r in plan['inputs']]);wire=arena.to_wire(sealed)
        need(wire['source_epoch']==source_epoch and wire['semantic_epoch']==semantic_epoch,'whole header literal epochs')
        need([name for name,root in wire['roots']]==[r['id']for r in plan['inputs']]and wire['documents']==[r['id']for r in plan['inputs']],'complete ordered catalogue and logical documents')
        context['stage']='WRITE_COMPLETE_FOREST'
        forest=old_tests.streamed_file(actual/'complete-evidence-forest.json',wire,tick,plan['limits']['result_bytes']);forests.append(forest);encoded=forest['bytes']
        arena_stats=arena.statistics();need(arena_stats['physical_wire_bytes']==encoded and arena_stats['logical_document_bytes']==expanded and arena_stats['lifecycle']=='SEALED','complete arena physical/logical ledger and current lifecycle')
        del wire;gc.collect();context['stage']='READ_COMPLETE_SAVED_FOREST'
        decoded=ordinary_load(raw(forest));statistics={};context['inverse_statistics']=statistics
        context['stage']='PREPARE_INDEPENDENT_COMPLETE_FOREST'
        prepared=inverse.prepare_forest(decoded,tick,inverse_limits,statistics=statistics);del decoded;gc.collect()
        need(prepared.documents==tuple(r['id']for r in plan['inputs']),'independent complete document order')
        st=prepared.statistics();need(st['prepared']and st['wire_canonical_bytes']==encoded and st['aggregate_document_bytes']==expanded,'independent physical/logical complete ledger')
        for item,captured in zip(plan['inputs'],capture_prefix):
            context.update(stage='INDEPENDENT_SAVED_WIRE_WHOLE_DOCUMENT',input=item['id']);original=raw(item['input']);stream=prepared.iter_document(item['id'])
            try:
                independent=old_tests.compare_stream(stream,original,tick)
                need(stream.completed,'independent explicit final completion required')
            finally:stream.close()
            stats=prepared.statistics()['documents'][item['id']]
            need(stats['completed']and stats['attempts']==1 and stats['copied_body_bytes']==stats['emitted_body_bytes']==len(original)-1,'complete independent document counters')
            need(stats['stream_value_occurrences']==stats['logical_value_occurrences'],'complete independent value multiplicity')
            results.append(dict(captured,document_label=item['id'],encoded=forest,independent_saved_wire_inverse=independent,
                independent_saved_wire_inverse_complete=True,independent_document_statistics=stats))
            del original;guard();tick()
        context.pop('inverse_statistics',None);context.update(stage='WRITE_CANDIDATE_RESULT',input=None)
        need(pin(forest['path'])==forest,'saved full forest unchanged after inverse')
        arena_stats=arena.statistics();inverse_stats=prepared.statistics()
        need(arena_stats['lifecycle']=='SEALED'and len(results)==3,'all original full routes and current ownership')
        result=dict(schema='incremental-arena-qualification-result-v1',version=VERSION,status='REPRESENTATION_QUALIFICATION_CANDIDATE',invocation_id=plan['invocation_id'],
            representation_only=True,complete_inputs=results,captured_input_prefix=capture_prefix,fixtures=fixture_rows,expected_fixture_names=expected,diagnostic_group_counts=dict(retained=71,arena=33,forest=23),arena_fixture_return=arena_return,
            encoded_forests=forests,aggregate_input_expanded_bytes=expanded,aggregate_encoded_table_bytes=encoded,aggregate_encoded_forest_bytes=encoded,
            arena_statistics=arena_stats,independent_inverse_statistics=inverse_stats,arena_limits=arena_limits,forest_inverse_limits=inverse_limits,
            arena_execution_profile=arena_module.EXECUTION_PROFILE,inverse_execution_profile=inverse.EXECUTION_PROFILE,
            callback_count_at_result_construction=calls,current_Source=descriptors,runtime=runtime,
            scientific_proof_replays=0,Native_calls=0,search_calls=0,Model_calls=0,opaque_Native_decodes=0,
            new_target_proof=False,Model_permission=False,schema_inventory_admission=False,goal_complete=False,
            scope='New arena/forest finite ordinary-data prerequisite only. One main arena retains all3complete originals with invocation-total quotas; every separately constructed diagnostic arena/inverse has prospectively finite local limits, while all constructor/fixture/parse/capture/guard/projection/inverse/output costs remain in original wholeworker time/peak. No integrated producer/search RAM claim.',
            retained_legacy_scope='All71previous fixtures rerun unchanged; they do not test StopIteration. Earlier finite3file/71fixture measurements remain valid for their tested scope; broad all-exception propagation is not inherited.',
            logical_ledger='Each of3declared logical documents full ordered expansion+one LF once. Catalogue is physical metadata; actual duplicate occurrences within documents remain expanded. One shared physical forest charged once plus result, each with sole LF.',
            mathematical_conformance='No t/m point data, graph, candidate generation, scheduler, rollback, logical rules, Model or Native gates changed or called.')
        result_descriptor=save_new(actual/'result.json',result);need(encoded+result_descriptor['bytes']<=plan['limits']['result_bytes'],'aggregate physical forest and result cap');tick();guard()
        save_new(actual/'worker-receipt.json',dict(schema='exact-evidence-qualification-worker-receipt-v1',invocation_id=plan['invocation_id'],plan=pin(plan_path),
            began_ns=began,work_deadline_ns=work,overall_deadline_ns=overall,result=result_descriptor,tables=forests,work_completed_ns=NOW(),
            representation_qualification_candidate=True,scientific_acceptance=False,mathematical_proof_accepted=False,Model_permission=False));tick()
    except BaseException as error:
        own_arena=arena_module is not None and arena_module.is_own_limit(error)
        own_inverse=inverse is not None and inverse.is_own_limit(error)
        status='UNKNOWN_WORK_DEADLINE'if deadline_error[0]is not None or type(error)is WorkDeadline else 'UNKNOWN_EVIDENCE_LIMIT'if own_arena or own_inverse else 'FAILED_SOURCE_OR_RUNTIME'
        if arena is not None:context['arena_statistics']=arena.statistics()
        if prepared is not None:context['inverse_statistics']=prepared.statistics()
        save_new(actual/'worker-failure.json',dict(schema='incremental-arena-worker-failure-v1',status=status,type=type(error).__name__,message=str(error),
            own_arena_limit=own_arena,own_inverse_limit=own_inverse,reason=error.reason if own_arena or own_inverse else None,
            external_deadline_observed=deadline_error[0]is not None,reached_context=context,
            completed_input_packets=results,captured_input_prefix=capture_prefix,completed_fixture_prefix=fixture_rows,published_forests=forests,
            aggregate_expanded_input_prefix_bytes=expanded,aggregate_encoded_forest_prefix_bytes=encoded,callback_count_at_failure=calls,
            published_result_candidate=result_descriptor,scientific_acceptance=False,representation_accepted=False))
        raise

if __name__=='__main__':
    need(len(sys.argv)==2,'one exact plan path');main(sys.argv[1])

# Source-only inert marker; no runtime expression.
