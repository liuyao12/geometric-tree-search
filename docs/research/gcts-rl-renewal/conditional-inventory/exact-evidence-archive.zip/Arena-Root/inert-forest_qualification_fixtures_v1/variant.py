"""Prospective finite tests only. No fixtures run at import time."""
import json

EXPECTED_FOREST_FIXTURES=(
 'forest_full_projection_and_ledgers','forest_multiple_document_multiplicity',
 'forest_typed_scalars','forest_malformed_matrix','forest_metadata_unicode_matrix',
 'forest_physical_bound','forest_aggregate_expansion_bound','forest_depth_boundary',
 'forest_integer_exact_boundary','forest_disabled_cache','forest_partial_cache',
 'forest_owned_work_limit','forest_wire_and_observer_mutation',
 'forest_closed_incomplete','forest_exact_callback_preparation_matrix',
 'forest_exact_callback_after_first_chunk_matrix','forest_exact_callback_completion_matrix',
 'forest_callback_reentrancy','forest_foreign_limit_not_owned',
 'forest_one_stream_per_document','forest_root_catalogue_coverage',
 'forest_completion_requires_final_pull')

def run_forest_fixtures(inverse,tick,rows,context):
    pending=[None]
    def need(v,m):
        if pending[0] is not None:raise pending[0]
        if not v:raise ValueError(m)
    def check():
        try:tick()
        except BaseException as error:pending[0]=error;raise
    def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode('utf8')
    def clone(v):return json.loads(canonical(v))
    def record(name,**packet):
        need(context['fixture']==name,'fixture context')
        rows.append(clone(dict(name=name,passed=True,**packet)))
    def enter(name):context['fixture']=name;check()
    def expect(call,predicate):
        try:call()
        except BaseException as error:
            if pending[0] is not None:raise pending[0]
            if not predicate(error):raise
            return error
        raise ValueError('expected test rejection absent')
    text='x\n\\"λ'
    value=dict(a=[text,7],b=[text,7])
    def base():
        return dict(schema='exact-evidence-forest-v1',version='exact-evidence-arena-v1',
            source_epoch='literal Source context',semantic_epoch='literal semantic context',
            roots=[['pair',2],['whole',3]],documents=['whole'],
            nodes=[['str',text],['int','7'],['array',[0,1]],['object',[['a',2],['b',2]]]])
    def drain(p,label,expected):
        stream=p.iter_document(label);out=bytearray()
        try:
            while True:
                try:chunk=next(stream)
                except StopIteration:break
                need(type(chunk)is bytes and bool(chunk),'nonempty exact body chunk');out.extend(chunk)
            need(stream.completed,'exhaustion alone never qualifies')
        finally:stream.close()
        need(bytes(out)==expected,'complete literal expected body')
        return dict(body_bytes=len(out),whole_literal_equal=True,completed=True)
    enter(EXPECTED_FOREST_FIXTURES[0]);w=base();p=inverse.prepare_forest(w,check);packet=drain(p,'whole',canonical(value));st=p.statistics()
    need(st['wire_canonical_bytes']==len(canonical(w))+1,'full physical forest byte formula')
    need(st['aggregate_document_bytes']==len(canonical(value))+1,'document ledger excludes catalogue sum')
    need(st['aggregate_document_value_occurrences']==7 and st['cache_hits_stream']==2,'independent whole recurrence/cache')
    record(context['fixture'],wire=w,expected=value,comparison=packet,statistics=st)

    enter(EXPECTED_FOREST_FIXTURES[1]);w=base();w['roots'].append(['second-document',2]);w['documents'].append('second-document');p=inverse.prepare_forest(w,check)
    a=drain(p,'whole',canonical(value));b=drain(p,'second-document',canonical([text,7]));st=p.statistics()
    need(st['aggregate_document_bytes']==len(canonical(value))+len(canonical([text,7]))+2,'two documents charge every occurrence and both LFs')
    need(st['aggregate_document_value_occurrences']==10,'multiple document root multiplicity')
    need(st['wire_canonical_bytes']==len(canonical(w))+1,'physical multiple-document size')
    record(context['fixture'],wire=w,comparisons=[a,b],statistics=st)

    enter(EXPECTED_FOREST_FIXTURES[2]);w=dict(schema='exact-evidence-forest-v1',version='exact-evidence-arena-v1',source_epoch='e',semantic_epoch='s',roots=[['typed',8]],documents=['typed'],nodes=[['null'],['bool',False],['bool',True],['int','0'],['int','1'],['float','0.0'],['float','-0.0'],['str','λ\t'],['array',list(range(8))]])
    p=inverse.prepare_forest(w,check);expected=[None,False,True,0,1,0.0,-0.0,'λ\t'];r=drain(p,'typed',canonical(expected));need(p.statistics()['wire_canonical_bytes']==len(canonical(w))+1,'alltag exact physical sizes');record(context['fixture'],wire=w,expected=expected,comparison=r,statistics=p.statistics())

    enter(EXPECTED_FOREST_FIXTURES[3]);cases=[]
    for label,change in [
        ('boolean_root',lambda q:q['roots'][0].__setitem__(1,True)),
        ('forward_ref',lambda q:q['nodes'][2][1].__setitem__(0,2)),
        ('dangling_ref',lambda q:q['nodes'][2][1].__setitem__(0,999)),
        ('boolean_ref',lambda q:q['nodes'][2][1].__setitem__(0,True)),
        ('duplicate_node',lambda q:q['nodes'].append(['str',text])),
        ('unreachable_node',lambda q:q['nodes'].append(['str','unused'])),
        ('duplicate_key',lambda q:q['nodes'][3].__setitem__(1,[['a',2],['a',2]])),
        ('unsorted_key',lambda q:q['nodes'][3].__setitem__(1,[['b',2],['a',2]])),
        ('noncanonical_integer',lambda q:q['nodes'][1].__setitem__(1,'07')),
        ('nonfinite_float',lambda q:q['nodes'].__setitem__(1,['float','NaN'])),
        ('unknown_tag',lambda q:q['nodes'][0].__setitem__(0,'unknown')),
        ('extra_field',lambda q:q.__setitem__('extra',0)),
        ('duplicate_root_label',lambda q:q['roots'][0].__setitem__(0,'whole')),
        ('unknown_document',lambda q:q.__setitem__('documents',['missing'])),
        ('duplicate_document',lambda q:q.__setitem__('documents',['whole','whole'])),
        ('uncovered_catalogue',lambda q:(q['nodes'].append(['str','unused']),q['roots'].append(['unused',4]))),
        ('negative_root',lambda q:q['roots'][0].__setitem__(1,-1)),
        ('empty_catalogue',lambda q:q.__setitem__('roots',[]))]:
        q=base();change(q);e=expect(lambda:inverse.prepare_forest(q,check),lambda e:type(e)is inverse.ForestDataError)
        cases.append(dict(case=label,type=type(e).__name__,rejected=True))
    record(context['fixture'],cases=cases)

    enter(EXPECTED_FOREST_FIXTURES[4]);cases=[]
    for field in ['source_epoch','semantic_epoch','root_label','document_label','object_key']:
        q=base()
        if field in ('source_epoch','semantic_epoch'):q[field]='\ud800'
        elif field=='root_label':q['roots'][0][0]='\ud800'
        elif field=='document_label':q['documents'][0]='\ud800'
        else:q['nodes'][3][1][0][0]='\ud800'
        e=expect(lambda:inverse.prepare_forest(q,check),lambda e:type(e)is inverse.ForestDataError);cases.append(dict(field=field,rejected=True,type=type(e).__name__))
    record(context['fixture'],cases=cases)

    enter(EXPECTED_FOREST_FIXTURES[5]);w=base();n=len(canonical(w))+1;e=expect(lambda:inverse.prepare_forest(w,check,dict(wire_bytes=n-1)),inverse.is_own_limit);need(e.reason=='wire bytes','precise physical guard');p=inverse.prepare_forest(w,check,dict(wire_bytes=n));r=drain(p,'whole',canonical(value));record(context['fixture'],exact_physical_bytes=n,rejected_one_below=True,accepted_exact=r)
    enter(EXPECTED_FOREST_FIXTURES[6]);w=base();n=len(canonical(value))+1;e=expect(lambda:inverse.prepare_forest(w,check,dict(expanded_bytes=n-1)),inverse.is_own_limit);need(e.reason=='aggregate document bytes','whole document LF included');p=inverse.prepare_forest(w,check,dict(expanded_bytes=n));record(context['fixture'],exact_logical_file_bytes=n,accepted_exact=drain(p,'whole',canonical(value)),rejected_one_below=True)
    enter(EXPECTED_FOREST_FIXTURES[7]);w=base();expect(lambda:inverse.prepare_forest(w,check,dict(depth=2)),inverse.is_own_limit);p=inverse.prepare_forest(w,check,dict(depth=3));record(context['fixture'],node_height=3,accepted_exact=drain(p,'whole',canonical(value)),rejected_one_below=True)
    enter(EXPECTED_FOREST_FIXTURES[8]);lex='1'*64;w=base();w.update(nodes=[['int',lex]],roots=[['integer',0]],documents=['integer']);p=inverse.prepare_forest(w,check,dict(integer_digits=64,expanded_bytes=65));r=drain(p,'integer',lex.encode());need(p.statistics()['aggregate_document_bytes']==65,'integer no quoted-byte overhead');record(context['fixture'],body_bytes=64,logical_file_bytes=65,comparison=r)
    for offset,limits in [(9,dict(cache_bytes=0)),(10,dict(cache_entries=1))]:
        enter(EXPECTED_FOREST_FIXTURES[offset]);p=inverse.prepare_forest(base(),check,limits);r=drain(p,'whole',canonical(value));st=p.statistics();need(st['cache_capacity_fallbacks']>0,'fallback actually exercised');need(st['cache_entries']==(0 if offset==9 else 1),'configured cache bound');record(context['fixture'],limits=limits,comparison=r,statistics=st)
    enter(EXPECTED_FOREST_FIXTURES[11]);obs={};e=expect(lambda:inverse.prepare_forest(base(),check,dict(work=1),statistics=obs),inverse.is_own_limit);need(e.reason=='work'and obs['attempted_operations']>1 and not obs['prepared'],'owned attempted work guard');record(context['fixture'],own_limit=True,statistics=obs)
    enter(EXPECTED_FOREST_FIXTURES[12]);w=base();obs={};p=inverse.prepare_forest(w,check,statistics=obs);w['nodes'][0][1]='changed';w['roots'].clear();w['documents'].clear();obs.clear();obs.update(prepared=True,wire_canonical_bytes=-1);snapshot=p.statistics();snapshot['documents']['whole']['completed']=True;snapshot['operations_by_kind'].clear();r=drain(p,'whole',canonical(value));need(p.documents==('whole',),'owned document names');record(context['fixture'],comparison=r,observer_not_authority=True,statistics=p.statistics())
    enter(EXPECTED_FOREST_FIXTURES[13]);p=inverse.prepare_forest(base(),check,dict(chunk_bytes=8));it=p.iter_document('whole');first=next(it);it.close();need(not it.completed and p.statistics()['documents']['whole']['closed_incomplete'],'close leaves incomplete');record(context['fixture'],first_chunk_bytes=len(first),completed=False,statistics=p.statistics())

    class CustomError(Exception):pass
    def markers():return [CustomError('custom'),RuntimeError('runtime'),ValueError('value'),StopIteration('sentinel'),GeneratorExit('exit-generator'),SystemExit('exit-system'),inverse.ForestLimit('foreign')]
    for number,mode in [(14,'preparation'),(15,'after_first_chunk'),(16,'completion')]:
        enter(EXPECTED_FOREST_FIXTURES[number]);events=[]
        for marker in markers():
            obs={};armed=[mode=='preparation'];pbox=[None]
            def callback():
                check()
                if armed[0]and(mode!='completion'or obs.get('last_operation')=='document_completion'):raise marker
            if mode=='preparation':
                expect(lambda:inverse.prepare_forest(base(),callback,statistics=obs),lambda e:e is marker)
                need(not obs['prepared'],'failed preparation not admitted');events.append(dict(type=type(marker).__name__,same_exception_object=True,prepared=False));continue
            q=base();expected=canonical(value)
            if mode=='after_first_chunk':
                long='x'*100;q.update(nodes=[['str',long]],roots=[['whole',0]],documents=['whole']);expected=canonical(long)
            p=inverse.prepare_forest(q,callback,dict(chunk_bytes=8),statistics=obs);pbox[0]=p;it=p.iter_document('whole');pieces=[]
            if mode=='after_first_chunk':pieces.append(next(it));armed[0]=True;expect(lambda:next(it),lambda e:e is marker)
            else:
                armed[0]=True
                def until_marker():
                    while True:pieces.append(next(it))
                expect(until_marker,lambda e:e is marker);need(b''.join(pieces)==expected,'completion exception occurs after all bytes')
            need(not it.completed,'foreign exception never completed');it.close();need(not p.statistics()['documents']['whole']['completed'],'saved incomplete status')
            events.append(dict(type=type(marker).__name__,same_exception_object=True,received_body_bytes=sum(map(len,pieces)),completed=False))
        record(context['fixture'],events=events)

    enter(EXPECTED_FOREST_FIXTURES[17]);box=[None];armed=[False];seen=[]
    def callback():
        check()
        if armed[0]:
            q=box[0]
            before=q.statistics()['attempted_operations']
            for operation in [lambda:q.documents,lambda:q.catalogue,lambda:q.iter_document('whole')]:
                expect(operation,inverse.is_own_reentrancy);seen.append(True)
            need(q.statistics()['attempted_operations']==before,'passive callback stats/no charged reentrant work')
    p=inverse.prepare_forest(base(),callback);box[0]=p;armed[0]=True;r=drain(p,'whole',canonical(value));need(bool(seen),'callback reentrancy reached');record(context['fixture'],comparison=r,reentrant_rejections=len(seen),statistics=p.statistics())
    enter(EXPECTED_FOREST_FIXTURES[18]);foreign=inverse.ForestLimit('foreign');need(not inverse.is_own_limit(foreign),'public foreign limit not owned');expect(lambda:inverse.prepare_forest(base(),lambda:(_ for _ in ()).throw(foreign)),lambda e:e is foreign);record(context['fixture'],foreign_not_owned=True,same_exception_object=True)
    enter(EXPECTED_FOREST_FIXTURES[19]);p=inverse.prepare_forest(base(),check);r=drain(p,'whole',canonical(value));before=p.statistics()['attempted_operations'];expect(lambda:p.iter_document('whole'),lambda e:type(e)is inverse.ForestDataError);need(p.statistics()['attempted_operations']>before,'failed API attempt work retained');record(context['fixture'],first_complete=r,second_stream_rejected=True,statistics=p.statistics())
    enter(EXPECTED_FOREST_FIXTURES[20]);w=base();w['documents']=['pair'];expect(lambda:inverse.prepare_forest(w,check),lambda e:type(e)is inverse.ForestDataError);record(context['fixture'],uncovered_catalogue_rejected=True,no_silent_drop=True)
    enter(EXPECTED_FOREST_FIXTURES[21]);p=inverse.prepare_forest(base(),check);it=p.iter_document('whole');body=next(it);need(body==canonical(value)and not it.completed,'last bytes alone are not completion');it.close();need(not it.completed,'close at last chunk remains incomplete');fresh=inverse.prepare_forest(base(),check);r=drain(fresh,'whole',canonical(value));record(context['fixture'],last_chunk_without_final_pull_not_admitted=True,fresh_complete=r,statistics=p.statistics())
    need([r['name']for r in rows[-len(EXPECTED_FOREST_FIXTURES):]]==list(EXPECTED_FOREST_FIXTURES),'complete declared forest fixture sequence')

# No runtime statement: inert Source review marker.
