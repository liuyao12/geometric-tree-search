"""Independent Root fixture/harness raw/AST review; never executes targets."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import subprocess

D=Path('/private/tmp/gcts-direct-reconcile-ROOT-20261019')
O=Path('/private/tmp/gcts-direct-reconcile-harness-peer-20261019')
P=Path('/private/tmp/gcts-incremental-arena-ROOT-20261019')
def pin(p):
    p=Path(p);b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def save(name,v):
    p=O/name;assert not p.exists();p.write_text(json.dumps(v,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n');return pin(p)
def dump(n):return ast.dump(n,include_attributes=False)
def raw(s,n):return ''.join(s.splitlines(keepends=True)[n.lineno-1:n.end_lineno])
names=['reconciliation_qualification_fixtures_v3.py','qualify_arena_worker_v4.py','run_arena_once_v4.py']
expected=[('2171099eef3ebd0f0f915115f4729f2aa3ff9abca61cf16274e149f3d00493d1',16386),('6cf5bbdb5dcfba18447efabadbae5612fbddd1e742d15c63066142372dd91220',16721),('245494c559bd419a70aee9666371c45c02ef6f14b12f3bd48d19d9a6c8b2e29f',12700)]
sources={n:pin(D/n)for n in names};text={n:(D/n).read_text()for n in names};trees={n:ast.parse(text[n])for n in names};checks=[]
def need(name,v,lines=None):
    checks.append(dict(name=name,passed=bool(v),lines=lines));assert v,name
for n,(sha,size) in zip(names,expected):need('exact Source '+n,(sources[n]['sha256'],sources[n]['bytes'])==(sha,size))
C=D/'shared-contract-v6.json';contract=json.loads(C.read_text())
need('exact shared contract',(pin(C)['sha256'],pin(C)['bytes'])==('0a851e22b89146e67036057f0a57c0264869bf2ca492d91eadc3d55f1847510d',13230))
ft=text[names[0]];wt=text[names[1]];rt=text[names[2]]
const=next(n for n in trees[names[0]].body if isinstance(n,ast.Assign)and isinstance(n.targets[0],ast.Name)and n.targets[0].id=='EXPECTED_RECONCILIATION_FIXTURES')
fixture_names=ast.literal_eval(const.value)
need('eight literal unique groups',type(fixture_names)is tuple and len(fixture_names)==len(set(fixture_names))==8,[10,19])
need('exact implementation ABI pin',"am.IMPLEMENTATION_VERSION=='exact-evidence-arena-v3-direct-reconciliation-parent-guards'" in ft,[34,34])
need('external callback BaseException latch',"except BaseException as error:\n            if external_fault[0]is None:external_fault[0]=error\n            raise" in ft,[35,43])
need('caught refuses to mask external error',"except BaseException as error:clean();return error" in ft,[61,64])
need('all groups append only after action and checkpoint',"checkpoint();observation=action();checkpoint()\n        rows.append" in ft,[86,89])
need('no authority in appended Root rows',"schema='direct-reconciliation-finite-diagnostic-v1'" in ft and 'authority=False));done.append(name)' in ft,[86,89])
need('strict local caps only tighten',"0<v<=cap[k]" in ft and "_need(k in cap and type(v)is int" in ft,[44,55])
need('normal drain checks explicit completion and external latch',"except StopIteration:\n                clean();_need(stream.completed is True" in ft,[68,82])
need('actual during phase requires frames',"delta(a,base,'reconciliation_begins')==1 and delta(a,base,'reconciliation_complete_reads')==0 and delta(a,base,'reconciliation_frames')>0" in ft,[60,60])
need('long buffer and unread tail bounded',"def payload(tail):return {'buffer':[0]*2048,'last':tail}" in ft and "delta(a,base,'reconciliation_edges')<len(value['buffer'])+1" in ft,[83,83])
need('mutations are public carrier only',"mutation(value)" in ft and "control['armed']=False;fired[0]=True;mutation(value)" in ft,[117,129])
need('failed mutation requires exact data error/incomplete read',"type(error)is am.ArenaDataError" in ft and "delta(a,base,'reconciliation_complete_reads')==0,'mismatched read incorrectly completed'" in ft,[124,129])
need('rollback ledger excludes monotone costs',"_need(ledger(a)==before" in ft and "_need(counters(a)['work']>work" in ft,[56,67])
need('no explicit arena/private handle backing access in fixture',not any(isinstance(n,ast.Attribute)and isinstance(n.value,ast.Name)and n.value.id in {'am','a','b','h','stream','result'}and n.attr.startswith('_') for n in ast.walk(trees[names[0]])))
need('typed/full body positive oracle',"b==_body(v)" in ft and "'negative_to_positive_float_zero'" in ft and "_body(materialized)==_body(value)" in ft,[98,133])
need('ordered repeated keys and strict classes tested as selected matrices',all(x in ft for x in ['array_repeated_position','same_cardinality_different_key','nonstring_key','list_cycle','object_cycle','ListSubclass([0])','IntSubclass(1)']),[135,155])
need('actual final boundary requires completed read and bookkeeping',"which=='guard'and delta(a,base,'reconciliation_complete_reads')==1 and delta(a,base,'publication_bookkeeping')>0" in ft,[158,178])
need('seven marker types include StopIteration/SystemExit/foreign quota',all(x in ft for x in ["FixtureMarker('custom')","RuntimeError('runtime')","ValueError('value')","StopIteration('stop')","GeneratorExit('generator')","SystemExit('system')","am.ArenaLimit('foreign')"]),[157,178])
need('callback objects checked by identity and nonowned classification',"error is marker" in ft and "not am.is_own_limit(error)" in ft,[167,175])
need('reentrancy nine public APIs includes next and close',"_need(len(refusals)==9" in ft and "('next',lambda:next(stream)),('close',lambda:stream.close())" in ft,[180,195])
need('one declared dynamic probe and W+1 rule',"cap=w+1;_need(0<cap<=limits['work']" in ft and "b=new(negative_control,{'work':cap})" in ft,[197,219])
need('tight negative same context/label/current input',"h=a.capture(value,label='boundary')" in ft and "b.capture(value,label='boundary')" in ft and "source_epoch='direct-e',semantic_epoch='direct-s'" in ft,[197,218])
need('negative validates same observed boundary no retarget',"negative_boundary[0]['counters']['work']==w" in ft and "during(b,negative_base)" in ft and "counters(b)['work']>cap" in ft,[214,218])
need('no retry/while calibration loop in quota group',not any(isinstance(n,(ast.While,ast.For)) for n in ast.walk(next(n for n in ast.walk(trees[names[0]])if isinstance(n,ast.FunctionDef)and n.name=='owned_work'))),[197,219])
need('whole eight order checked',"_need(done==list(EXPECTED_RECONCILIATION_FIXTURES)" in ft,[220,221])
need('no new evaluated data or scientific import in fixture',[n.names[0].name for n in trees[names[0]].body if isinstance(n,ast.Import)]==['json'])

need('worker preserved127 sequence before new8',"expected[:127]and len(fixture_rows)==127" in wt and "len(expected)==135" in wt,[72,89])
need('worker strict original Library33 packet schema',"all(set(x)=={'schema','name','status','scope','observed','authority'}" in wt and "fixture_rows[71:104]" in wt,[83,91])
need('worker strict71+Root31 passed bools',"all(x['passed']is True for x in fixture_rows[:71]+fixture_rows[104:])" in wt,[90,91])
need('one main Arena before full input loop',"arena=arena_module.Arena(" in wt and wt.index('arena=arena_module.Arena(')<wt.index("for item in plan['inputs']:") and wt.count('arena=arena_module.Arena(')==1,[97,106])
need('complete raw inputs and canonical baseline retained',"original=raw(item['input'])" in wt and "value=ordinary_load(original)" in wt and "baseline=old_tests.compare_stream" in wt,[100,106])
need('capture prefix only after full own canonical completion',"need(stream.completed,'arena explicit final completion required')" in wt and wt.index('capture_prefix.append')>wt.index("need(stream.completed,'arena explicit final completion required')"),[107,115])
need('one saved forest and fresh independent inverse',"forests.append(forest)" in wt and "decoded=ordinary_load(raw(forest))" in wt and "prepared=inverse.prepare_forest(decoded,tick,inverse_limits" in wt,[118,129])
need('full epochs and catalogue order joined',"wire['source_epoch']==source_epoch and wire['semantic_epoch']==semantic_epoch" in wt and "wire['documents']==[r['id']for r in plan['inputs']]" in wt,[95,120])
need('physical/logical ledgers once then every occurrence complete',"arena_stats['physical_wire_bytes']==encoded and arena_stats['logical_document_bytes']==expanded" in wt and "stats['stream_value_occurrences']==stats['logical_value_occurrences']" in wt,[122,140])
need('full independent byte comparisons plus completion',"independent=old_tests.compare_stream(stream,original,tick)" in wt and "need(stream.completed,'independent explicit final completion required')" in wt,[130,140])
need('failure saves inactive honest prefix and rethrows',all(x in wt for x in ["completed_input_packets=results,captured_input_prefix=capture_prefix,completed_fixture_prefix=fixture_rows,published_forests=forests","representation_accepted=False","published_result_candidate=result_descriptor"]),[162,174])
need('worker retained ownlimit/deadline distinctions',"'UNKNOWN_WORK_DEADLINE'" in wt and "'UNKNOWN_EVIDENCE_LIMIT'" in wt and "'FAILED_SOURCE_OR_RUNTIME'" in wt,[162,174])
need('worker all output and positive gates unchanged',"encoded+result_descriptor['bytes']<=plan['limits']['result_bytes']" in wt and "representation_qualification_candidate=True" in wt and "scientific_acceptance=False" in wt,[158,173])
need('runner same135 schema joins',"len(fixtures)==135" in rt and "all(f['passed']is True for f in fixtures[:71]+fixtures[104:])" in rt and "fixtures[71:104]" in rt,[110,114])
need('runner exact main three order',"['full-base-control','full-shadow-packets','full-prior-case002']" in rt,[49,54])
need('same global180/210/1GiB/both128MiB/4MiBlogs',"LIMITS=dict(work_seconds=180,overall_seconds=210,memory_bytes=1073741824,result_bytes=134217728,expanded_bytes=134217728,stdout_bytes=4194304,stderr_bytes=4194304)" in rt,[14,15])
need('strict positive after knownexit and final checks',"need(NOW()<work,'positive known exit and checks before180')" in rt and "need(NOW()<work,'positive final whole checks before180')" in rt,[102,125])
need('runner enforces sum forest+result and expanded',"total<=LIMITS['result_bytes']and payload['aggregate_input_expanded_bytes']<=LIMITS['expanded_bytes']" in rt,[115,121])
need('runner wait4 singleworker resource/reaping',"os.wait4(process.pid,os.WNOHANG)" in rt and "usage.ru_maxrss<=LIMITS['memory_bytes']" in rt,[79,86])
need('known group absence signals and no stale unverified signal',"need(absent or not group_seen_absent" in rt and "if not owned_group_absent():os.killpg" in rt,[73,88])
need('work and closure postreceipt markers remain',"POST_RECEIPT_DEADLINE_FAILURE.json" in rt and "POST_RECEIPT_WORK_FAILURE.json" in rt,[155,159])
need('same numerical arena contract',contract['limits']['work']==200000000 and contract['limits']['wire_bytes']==contract['limits']['documents_expanded_bytes']==134217728)
need('new fixture exact declared once-probe scope',contract['direct_reconciliation']['implementation']=='exact-evidence-arena-v3-direct-reconciliation-parent-guards' and 'W+1' in contract['direct_reconciliation']['dynamic_boundary'])

# Real byte patches into inert scratch copies, followed by exact inverse AST.
pairs=[(D/'reconciliation_qualification_fixtures_v2.py',D/names[0]),(P/'qualify_arena_worker_v3.py',D/names[1]),(P/'run_arena_once_v3.py',D/names[2])]
patches=[];retained=[]
for ordinal,(parent,child) in enumerate(pairs):
    ps=parent.read_text();cs=child.read_text();pt=ast.parse(ps);ct=ast.parse(cs)
    pd={n.name:n for n in pt.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))};cd={n.name:n for n in ct.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
    for name,n in pd.items():
        if name in cd and raw(ps,n)==raw(cs,cd[name]) and dump(n)==dump(cd[name]):retained.append(dict(subject=child.name,name=name,parent_lines=[n.lineno,n.end_lineno],current_lines=[cd[name].lineno,cd[name].end_lineno]))
    f=''.join(difflib.unified_diff(ps.splitlines(True),cs.splitlines(True),fromfile='subject.py',tofile='subject.py'))
    r=''.join(difflib.unified_diff(cs.splitlines(True),ps.splitlines(True),fromfile='subject.py',tofile='subject.py'))
    fp=O/(str(ordinal)+'-forward.patch');rp=O/(str(ordinal)+'-inverse.patch');fp.write_text(f);rp.write_text(r)
    scratch=O/('inert-'+str(ordinal));scratch.mkdir();target=scratch/'subject.py';target.write_text(ps)
    for direction,patch,want in [('forward',fp,cs),('inverse',rp,ps)]:
        result=subprocess.run(['patch','--batch','-s','-p0','-i',str(patch)],cwd=scratch,capture_output=True,text=True)
        need('actual inert '+child.name+' '+direction,result.returncode==0 and target.read_text()==want and dump(ast.parse(target.read_text()))==dump(ast.parse(want)))
    patches.append(dict(parent=pin(parent),source=pin(child),forward=pin(fp),inverse=pin(rp)))
    compile(cs,str(child),'exec')  # Discard the code object, never evaluate it.
    need('unused compile '+child.name,True)

# Explicitly certify only retained Root pipeline text/AST, not own arena body.
oldw=(P/'qualify_arena_worker_v3.py').read_text();oldr=(P/'run_arena_once_v3.py').read_text()
wstart='# Full literal Sources are data in the new forest header.'
wpart=wt[wt.index(wstart):]
oldpart=oldw[oldw.index(wstart):]
wpart=wpart.replace('diagnostic_group_counts=dict(retained=71,arena=33,forest=23,reconciliation=8)','diagnostic_group_counts=dict(retained=71,arena=33,forest=23)',1)
need('entire original one-arena full3/output/failure tail exact',wpart==oldpart)
need('runner whole outside disclosed version/fixture count delta exact',rt.replace("VERSION='direct-reconciliation-once-runner-v4-135-diagnostics'","VERSION='incremental-forest-once-runner-v3-127-diagnostics'",1).replace("diagnostic_group_counts']==dict(retained=71,arena=33,forest=23,reconciliation=8)and len(fixtures)==135","diagnostic_group_counts']==dict(retained=71,arena=33,forest=23)and len(fixtures)==127",1).replace('complete135 fixture census/order','complete127 fixture census/order',1).replace('strict old71 and Root31 fixture successes','strict old71 and Root23 fixture successes',1)==oldr)
need('fixtureV3 only metadata/ABI drift from withdrawnV2',ft.replace("VERSION='direct-reconciliation-qualification-fixtures-v3'","VERSION='direct-reconciliation-qualification-fixtures-v2'",1).replace("am.IMPLEMENTATION_VERSION=='exact-evidence-arena-v3-direct-reconciliation-parent-guards'","am.IMPLEMENTATION_VERSION=='exact-evidence-arena-v2-direct-reconciliation'",1)==(D/'reconciliation_qualification_fixtures_v2.py').read_text())

audit=save('audit-v1.json',dict(schema='direct-reconciliation-Root-fixture-harness-static-audit-v1',author_identity='/root',reviewer_identity='/root/conventional_library',source_only=True,scientific_calls=0,component_calls=0,fixtures_executed=0,scientific_acceptance=False,actual_execution_authorized=False,
 sources=sources,shared_contract=pin(C),checks=checks,check_count=len(checks),mismatches=0,retained_raw_AST_regions=retained,patches=patches,inert_patch_directions=6,unused_compiles=3))
receipt=save('typed-fixture-harness-Source-review-v1.json',dict(schema='direct-reconciliation-fixture-harness-typed-Source-review-v1',author_identity='/root',reviewer_identity='/root/conventional_library',source_only=True,source_review_passed=True,
 source=sources[names[1]],sources=sources,shared_contract=pin(C),audit=audit,checks=len(checks),mismatches=0,inert_patch_directions=6,unused_compiles=3,
 scientific_calls=0,component_calls=0,fixtures_executed=0,scientific_acceptance=False,actual_execution_authorized=False,
 scope='Independent Source-only review of Root targeted8 fixture groups, worker4 and once runner4 coupling. No certification of reviewer-authored arena/Library33, independent forest inverse, complete11Source closure, future plan/grant/observer/actual or mathematical semantics.',
 authorship_overlap='Reviewer authored arenaV1/direct-reconciliation successors and Library33 fixtures plus earlier adapters/Models. Root authored these reviewed fixtures/worker/runner. Their call interface is checked here; own arena body is explicitly excluded and remains subject to Control independent full11Source review.',
 findings=[dict(id='SCOPE1',severity='coverage_caveat',blocking=False,detail='No-second-intern runtime counter comparison spans the first observed unfinished CHECK callback to actual-final guard. It does not sample the unobserved initial direct-read prefix; broader absence is a separate full Source obligation, not a dynamic universal certificate.',lines=[91,114]),dict(id='SCOPE2',severity='coverage_caveat',blocking=False,detail='Callback timing and W+1 phase fit are assertions under fixed finite procedure. If not reached exactly, group fails; no retry/retarget is provided. Guard2 semantics are preserved by independently reviewed arena policy, not assumed from a receipt count.',lines=[197,219]),dict(id='SCOPE3',severity='coverage_caveat',blocking=False,detail='Adversarial ordinary carrier mutations deliberately violate normal exclusive ownership. The selected unread-tail refusals are not a simultaneous temporal/concurrent/hostile-code seal.',lines=[117,155])],
 limits=dict(global_work_seconds=180,terminal_seconds=210,worker_peak_bytes=1073741824,physical_forest_plus_result_bytes=134217728,expanded_logical_documents_bytes=134217728,stdout_bytes=4194304,stderr_bytes=4194304,main_arena_work=200000000,independent_inverse_work=30000000),
 retention='Old71+Library33+Root23 exact Sources precede Root8,135 diagnostic packets/groups. ONE main arena across all3 complete originals, no main-owner reset. Everybyte baseline/arena/fresh-saved-forest inverse and stream.completed remain required; partial results inactive.',
 caller_conditions=['Complete11Source independent review and exact declaration/Source/runtime/input pins must be joined prospectively and by final true grant.','Future Root subject fixes all3 raw originals/order and complete numeric limits; worker self-matching declaration is not an independent authenticator.','Worker-only Darwin wait4 highwater excludes parent/observer, is posthoc; source-entry180/210 excludes interpreter prelude. Outer observer/source/runtime/grants remain separate.','Normal UNKNOWN/failure must retain only completed packets/prefix plus actual context; no source-only pass or fixture count admits a representation.'],
 no_blocking_finding=True,no_runtime_fit_or_speed_claim=True))
handoff=save('handoff-v1.json',dict(schema='direct-reconciliation-fixture-harness-peer-handoff-v1',reviewer_identity='/root/conventional_library',source_review=receipt,audit=audit,sources=sources,shared_contract=pin(C),scientific_calls=0,component_calls=0,fixtures_executed=0,actual_execution_authorized=False))
print(json.dumps(dict(review=receipt,handoff=handoff,checks=len(checks),scientific_calls=0),sort_keys=True))
