"""Author metadata only: source text/AST/unused compile and inert text patches.

Never imports, evaluates or calls the evidence component or any fixture.
"""
from pathlib import Path
import ast,difflib,hashlib,json,subprocess

D=Path('/private/tmp/gcts-exact-evidence-source-20261019')
P=D/'exact_evidence_table_v1.py';S=D/'exact_evidence_table_v2.py'
PROFILE='exact-evidence-table-weighted-checkpoint-batch-v2'
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def save(name,value):
 p=D/name
 if p.exists():raise FileExistsError(str(p))
 p.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n');return pin(p)
old=P.read_text()
assert pin(P)['sha256']=='153c27aabd110926d716156cee064466d4de4a8ef21062ea0275002024be1e4f'
old_step="""    def step(self,kind='work',amount=1):
        self.check()  # No caller exception is caught/reclassified anywhere.
        if self.counts.get('work',0)+amount>self.limits['max_work']:
            self.stop('max_work')
        self.counts['work']=self.counts.get('work',0)+amount
        if kind!='work':self.counts[kind]=self.counts.get(kind,0)+amount
"""
new_step="""    def step(self,kind='work',amount=1):
        # Charge weighted units, not invocation count. A bulk charge crossing
        # several quanta delegates every crossed checkpoint before its work.
        # Keep the count commit atomic: interruption/own-quota retains the same
        # preceding counts as V1, never a partly committed character charge.
        left=amount;remaining=self._until_check
        while remaining==0 or left>remaining:
            left-=remaining
            self.check()  # Exact caller exceptions propagate unhandled.
            remaining=CHECKPOINT_QUANTUM
        remaining-=left
        if self.counts.get('work',0)+amount>self.limits['max_work']:
            self.stop('max_work')
        self.counts['work']=self.counts.get('work',0)+amount
        if kind!='work':self.counts[kind]=self.counts.get(kind,0)+amount
        self._until_check=remaining
"""
constants="EXECUTION_PROFILE='"+PROFILE+"'\nCHECKPOINT_QUANTUM=1024\n"
init_line="        self._until_check=0  # First logical charge checks immediately.\n"
anchor="        if self.limits['chunk_bytes']>65536:raise EvidenceDataError('chunk_bytes at most65536')\n"
assert old.count(old_step)==old.count(anchor)==1
new=old.replace("WIRE_SCHEMA='exact-evidence-node-table-v1'\n","WIRE_SCHEMA='exact-evidence-node-table-v1'\n"+constants,1)
new=new.replace(anchor,anchor+init_line,1).replace(old_step,new_step,1)
if S.exists():raise FileExistsError(str(S))
S.write_text(new)
before=ast.parse(old,filename=str(P));after=ast.parse(new,filename=str(S))
compile(new,str(S),'exec',dont_inherit=True)  # Deliberately never evaluated.
checks=[]
def ck(name,value,scope):
 checks.append(dict(check=name,passed=bool(value),scope=scope))
 if not value:raise AssertionError(name)
ck('AST_parse_unused_compile',True,'No target code object/module/function/fixture execution.')
restored=new.replace(constants,'',1).replace(init_line,'',1).replace(new_step,old_step,1)
ck('whole_raw_inverse',restored==old,'Exactly two constants plus _Work constructor bookkeeping and step cadence.')
ck('whole_AST_inverse',ast.dump(ast.parse(restored),include_attributes=False)==ast.dump(before,include_attributes=False),'No remaining algorithm change after exact inverse.')
regions=[]
for old_node,new_node in zip([n for n in before.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))],[n for n in after.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))]):
 ck('region_order:'+old_node.name,old_node.name==new_node.name,'No added/deleted public or private callable regions.')
 raw_old=ast.get_source_segment(old,old_node);raw_new=ast.get_source_segment(new,new_node)
 ast_equal=ast.dump(old_node,include_attributes=False)==ast.dump(new_node,include_attributes=False)
 if old_node.name!='_Work':ck('retained_raw_AST:'+old_node.name,raw_old==raw_new and ast_equal,'Every validation/traversal/serialization/materialization/ownership body unchanged.')
 regions.append(dict(name=old_node.name,raw_exact=raw_old==raw_new,AST_exact=ast_equal,old_line=old_node.lineno,new_line=new_node.lineno))
old_class=next(n for n in before.body if isinstance(n,ast.ClassDef) and n.name=='_Work')
new_class=next(n for n in after.body if isinstance(n,ast.ClassDef) and n.name=='_Work')
for name in ('bound','stop'):
 a=next(n for n in old_class.body if isinstance(n,ast.FunctionDef) and n.name==name)
 b=next(n for n in new_class.body if isinstance(n,ast.FunctionDef) and n.name==name)
 ck('unchanged_Work_'+name,ast.get_source_segment(old,a)==ast.get_source_segment(new,b),'Every owned bound/exception remains unchanged.')
unchanged_commit="""        if self.counts.get('work',0)+amount>self.limits['max_work']:
            self.stop('max_work')
        self.counts['work']=self.counts.get('work',0)+amount
        if kind!='work':self.counts[kind]=self.counts.get(kind,0)+amount
"""
ck('quota_and_counts_raw_exact',unchanged_commit in old_step and unchanged_commit in new_step,'Same max_work comparison, prior counts on stop and atomic successful amount/kind charge.')
ck('completion_checks_all_retained',old.count('check();return')==new.count('check();return') and old.count('\n    check()\n')==new.count('\n    check()\n'),'All original public completion checks retained in exact bodies; lazy generator completion still requires exhaustion.')
ck('bounded_scalar_windows_raw_exact',"range(0,len(value),4096)" in new and "w.step('string_characters',len(part))" in new,'Existing 4096-character window, weighted charge and scalar caps unchanged.')
ck('constant_assignment_only',constants in new and "VERSION='exact-evidence-table-v1'" in new and "WIRE_SCHEMA='exact-evidence-node-table-v1'" in new,'Wire identity unchanged; distinct execution profile and quantum literal.')
ck('no_new_handlers',sum(isinstance(n,ast.Try) for n in ast.walk(before))==sum(isinstance(n,ast.Try) for n in ast.walk(after)),'Callback exceptions remain outside all handlers.')
ck('cadence_local_before_commit',new_step.index('self.check()')<new_step.index("if self.counts.get")<new_step.index('self._until_check=remaining'),'No partial count commit on callback/own quota; schedule state commits only on successful step.')
ck('all_default_limits_AST_exact',ast.dump(next(n for n in before.body if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='DEFAULT_LIMITS' for x in n.targets)),include_attributes=False)==ast.dump(next(n for n in after.body if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='DEFAULT_LIMITS' for x in n.targets)),include_attributes=False),'No quota/size/depth/occurrence/chunk change.')
forward=D/'source-v1-to-v2-forward.patch';inverse=D/'source-v2-to-v1-inverse.patch'
forward.write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='component.py',tofile='component.py')))
inverse.write_text(''.join(difflib.unified_diff(new.splitlines(True),old.splitlines(True),fromfile='component.py',tofile='component.py')))
scratch=D/'inert-patch-v2';scratch.mkdir();q=scratch/'component.py';q.write_text(old)
f=subprocess.run(['patch','--batch','-F','0',q.name,str(forward)],cwd=scratch,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
ck('real_F0_forward',f.returncode==0 and q.read_bytes()==S.read_bytes(),'Inert scratch text only; exact V2 bytes.')
r=subprocess.run(['patch','--batch','-F','0',q.name,str(inverse)],cwd=scratch,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
ck('real_F0_inverse',r.returncode==0 and q.read_bytes()==P.read_bytes(),'Exact immutable V1 text restored; no source loaded/evaluated.')
common=dict(author_identity='/root/conventional_library',source_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,status='FROZEN_SOURCE_ONLY_UNTESTED_NOT_ACTIVATED')
audit=save('author-static-audit-v2.json',dict(common,schema='exact-evidence-author-static-audit-v2',source=pin(S),parent=pin(P),checks=checks,check_count=len(checks),mismatches=0,regions=regions,forward=pin(forward),inverse=pin(inverse),patch_stdout=[f.stdout,r.stdout],codec_functions_evaluated=0,fixtures_executed=0,independent_Source_review=False,authored_helper=pin(__file__)))
api=json.loads((D/'API-v1.json').read_text())
api.update(common,schema='exact-evidence-table-API-v2',source=pin(S),execution_profile=PROFILE,parent_API=pin(D/'API-v1.json'))
api['checkpoint_cadence']=dict(quantum=1024,unit='Weighted logical work amounts, not step invocation count.',first='First logical charge invokes callback immediately, before count commit or actual processing.',subsequent='At most1024 charged units between scheduled callbacks; a bulk amount crossing multiple quanta delegates every crossing before processing its existing bounded window.',counts='Successful step commits exactly the same full work/kind amount as V1. Callback exception or own max_work stop retains preceding logical counts; no partially committed bulk amount. Delegated callback invocation count intentionally differs.',completion='All original direct public completion callbacks remain. iter_expanded_canonical completion requires full exhaustion.',exception='No catches or conversions added; exact foreign callback exception object propagates.',scope='Cooperative Source/snapshot/deadline checks occur less frequently; this is not a hard elapsed-time or hostile mutation guarantee. Existing scalar4096-character windows/sort/hash/JSON builtins remain unchanged and require Root external deadline/memory enforcement.')
api_pin=save('API-v2.json',api)
contract=json.loads((D/'Source-contract-v1.json').read_text())
contract.update(common,schema='exact-evidence-table-Source-contract-v2',source=pin(S),sources=dict(exact_evidence_table=pin(S)),API=api_pin,author_static_audit=audit,parent_source=pin(P),parent_contract=pin(D/'Source-contract-v1.json'),execution_profile=PROFILE,execution_delta=api['checkpoint_cadence'],whole_raw_inverse=True,whole_AST_inverse=True,forward=pin(forward),inverse=pin(inverse))
contract['prior_qualification']='Root reports original V1 whole-artifact qualification stopped at180s UNKNOWN_WORK_DEADLINE during SAVED_TABLE_ENCODER_INVERSE, with0 completed input packets. That failure remains nonadmitted and immutable. This Source-only successor neither resumes/caches the old table nor establishes a performance result; any new actual must use fresh Source-bound subject and all original full3 inputs/48 fixtures under unchanged180/210/1GiB and both128MiB limits.'
contract['qualification_obligations']+=['New distinct Source review must confirm only callback cadence/bookkeeping changed; all original full3 inputs/48 fixture protocol remains required under a fresh bounded grant. No old partial table is a new input/cache.','Checkpoint quantum must be tested on weighted bulk charges and own quota failures; first/completion callback identity, RuntimeError/ValueError/foreign EvidenceLimit propagation and full UNKNOWN prefix retention remain required.','Report callback-invocation counts separately from unchanged logical-work counts and preserve all incomplete outcomes. No fit/speed/cause attribution from this static packet.']
contract['limitations']+=['Batched callbacks intentionally weaken frequency of runtime conditional Source/snapshot checks. Bulk charge crossings delegate upfront; bounded processing windows and synchronous builtins are unchanged. Hard outer enforcement remains necessary.','No V2 codec function/fixture was executed, including no author cadence simulation. Static raw/AST correspondence only.']
contract_pin=save('Source-contract-v2.json',contract)
handoff=save('handoff-v2.json',dict(common,schema='exact-evidence-source-handoff-v2',source=pin(S),sources=dict(exact_evidence_table=pin(S)),source_contract=contract_pin,API=api_pin,author_static_audit=audit,parent_source=pin(P),execution_profile=PROFILE,wire_version='exact-evidence-table-v1',wire_schema='exact-evidence-node-table-v1',static_check_count=len(checks),inert_F0_directions=2,codec_evaluations=0,fixtures_executed=0,independent_Source_review='PENDING',summary='Only weighted callback cadence and private bookkeeping changed; full validation/canonical output/counts/default quotas preserved. Standalone/inactive; original V1 timeout remains nonadmitted.'))
print(json.dumps(dict(source=pin(S),handoff=handoff,API=api_pin,contract=contract_pin,audit=audit,checks=len(checks)),indent=2))
