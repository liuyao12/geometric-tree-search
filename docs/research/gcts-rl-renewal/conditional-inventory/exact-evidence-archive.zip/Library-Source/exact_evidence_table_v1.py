"""Exact immutable JSON evidence DAG, not proof or Model authority.

Source-only, unexecuted component. No scientific imports. Canonical ordinary
JSON means ensure_ascii=False, sorted keys, compact separators, finite numbers;
a trailing newline is external. Whole raw input bytes remain separate evidence.
"""
import json
import math

VERSION='exact-evidence-table-v1'
WIRE_SCHEMA='exact-evidence-node-table-v1'
DEFAULT_LIMITS=dict(max_work=200000000,max_nodes=2000000,
    max_occurrences=20000000,max_depth=4096,
    max_expanded_bytes=134217728,max_wire_bytes=134217728,
    max_scalar_bytes=16777216,max_integer_digits=4096,
    max_materialized_occurrences=100000,max_materialized_bytes=4194304,
    chunk_bytes=65536)
_LIMIT_TOKEN=object()
_TABLE_TOKEN=object()


class EvidenceDataError(ValueError):
    """Malformed/noncanonical/out-of-domain ordinary data or wire."""


class EvidenceLimit(RuntimeError):
    """No successful artifact: finite owned evidence work/size limit."""
    def __init__(self,reason,counts=None,limits=None,*,_owner=None):
        self.reason=reason;self.counts=dict(counts or {});self.limits=dict(limits or {})
        self._owner=_owner
        super().__init__(reason)


def is_own_limit(error):
    return type(error) is EvidenceLimit and error._owner is _LIMIT_TOKEN


class FrozenTable:
    """Tuple-only owned nodes. Construct through freeze/validate_wire only.

    Public properties expose immutable builtin values, never mutable input
    containers. This is ordinary Python immutability, not a hostile-code sandbox.
    Every consumer still validates the complete table before using it.
    """
    __slots__=('_nodes','_root')
    def __init__(self,nodes,root,*,_token=None):
        if _token is not _TABLE_TOKEN:raise TypeError('use freeze or validate_wire')
        object.__setattr__(self,'_nodes',nodes);object.__setattr__(self,'_root',root)
    def __setattr__(self,name,value):
        raise AttributeError('immutable exact evidence table')
    def __delattr__(self,name):
        raise AttributeError('immutable exact evidence table')
    @property
    def nodes(self):return self._nodes
    @property
    def root(self):return self._root
    @property
    def node_count(self):return len(self._nodes)
    def __repr__(self):return 'FrozenTable(nodes='+str(len(self._nodes))+', root='+str(self._root)+')'


class _Work:
    def __init__(self,check,limits):
        if not callable(check):raise TypeError('charged evidence check required')
        self.check=check;self.limits=dict(DEFAULT_LIMITS);self.counts={}
        if limits is not None:
            if type(limits) is not dict or set(limits)-set(self.limits):
                raise EvidenceDataError('exact declared evidence limit keys')
            self.limits.update(limits)
        if any(type(v) is not int or v<=0 for v in self.limits.values()):
            raise EvidenceDataError('strict positive integer evidence limits')
        if self.limits['chunk_bytes']>65536:raise EvidenceDataError('chunk_bytes at most65536')
    def step(self,kind='work',amount=1):
        self.check()  # No caller exception is caught/reclassified anywhere.
        if self.counts.get('work',0)+amount>self.limits['max_work']:
            self.stop('max_work')
        self.counts['work']=self.counts.get('work',0)+amount
        if kind!='work':self.counts[kind]=self.counts.get(kind,0)+amount
    def bound(self,name,value):
        self.step('bound_checks')
        if value>self.limits[name]:self.stop(name)
    def stop(self,reason):
        raise EvidenceLimit(reason,self.counts,self.limits,_owner=_LIMIT_TOKEN)


def _string_size(value,w):
    """Exact canonical UTF8 JSON-string byte size; no lone surrogates."""
    if type(value) is not str:raise EvidenceDataError('exact Unicode scalar string')
    size=2
    # Count/check in bounded character windows before allocating encoded text.
    for start in range(0,len(value),4096):
        part=value[start:start+4096];w.step('string_characters',len(part))
        for ch in part:
            c=ord(ch)
            if 0xD800<=c<=0xDFFF:raise EvidenceDataError('lone surrogate outside scalar-string domain')
            if ch in ('"','\\','\b','\f','\n','\r','\t'):size+=2
            elif c<32:size+=6
            elif c<128:size+=1
            elif c<2048:size+=2
            elif c<65536:size+=3
            else:size+=4
        w.bound('max_scalar_bytes',size)
    w.bound('max_scalar_bytes',size)
    return size


def _string_bytes(value,w):
    size=_string_size(value,w)
    w.step('string_encoding')
    raw=json.dumps(value,ensure_ascii=False,allow_nan=False,separators=(',',':')).encode('utf8')
    w.step()
    if len(raw)!=size:raise EvidenceDataError('canonical string byte-size disagreement')
    return raw


def _int_lexeme(value,w):
    if type(value) is not int:raise EvidenceDataError('exact integer, not bool')
    # Avoid converting an unbounded integer before checking its bit-size proxy.
    if value.bit_length()>(3322*w.limits['max_integer_digits']+999)//1000:w.stop('max_integer_digits')
    w.step('integer_conversion')
    # Pure builtin conversion only; no callback is inside this local handler.
    try:text=str(value)
    except ValueError as error:raise EvidenceDataError('interpreter integer conversion limit') from error
    _validate_int(text,w)
    return text


def _validate_int(text,w):
    if type(text) is not str or not text:raise EvidenceDataError('integer decimal-string node')
    digits=text[1:] if text[0]=='-' else text
    w.bound('max_integer_digits',len(digits));w.step('integer_digits',len(digits))
    if (not digits or any(c<'0' or c>'9' for c in digits) or
            (len(digits)>1 and digits[0]=='0') or text=='-0'):
        raise EvidenceDataError('canonical signed integer decimal text')
    return len(text)


def _float_lexeme(value,w):
    if type(value) is not float or not math.isfinite(value):raise EvidenceDataError('finite exact Python float')
    w.step('float_conversion')
    return json.dumps(value,ensure_ascii=False,allow_nan=False,separators=(',',':'))


def _validate_float(text,w):
    if type(text) is not str or not text or len(text)>64:raise EvidenceDataError('finite canonical float lexeme')
    w.step('float_validation')
    # Pure builtin parse only, separated from every delegated check callback.
    try:value=float(text)
    except (ValueError,OverflowError) as error:raise EvidenceDataError('float lexeme parse') from error
    if not math.isfinite(value) or _float_lexeme(value,w)!=text:
        raise EvidenceDataError('canonical json.dumps float lexeme required')
    return len(text)


def _references(node):
    if node[0]=='array':return node[1]
    if node[0]=='object':return tuple(i for key,i in node[1])
    return ()


def _intern(node,nodes,buckets,w,reject_duplicate=False):
    """Hash narrows a bucket; full typed immutable node equality decides."""
    w.step('intern_lookups');key=hash(node);w.step()
    for previous in buckets.get(key,()):
        w.step('full_node_comparisons')
        if nodes[previous]==node:
            if reject_duplicate:raise EvidenceDataError('duplicate complete typed node')
            return previous
    w.bound('max_nodes',len(nodes)+1)
    index=len(nodes);nodes.append(node);buckets.setdefault(key,[]).append(index)
    return index


def _decode_node(raw,index,w,wire):
    outer=list if wire else tuple
    if type(raw) is not outer or not raw or type(raw[0]) is not str:
        raise EvidenceDataError('exact typed node container')
    kind=raw[0];w.step('typed_nodes')
    if kind=='null':
        if len(raw)!=1:raise EvidenceDataError('null node arity')
        return ('null',),4
    if len(raw)!=2:raise EvidenceDataError('typed node arity')
    value=raw[1]
    if kind=='bool':
        if type(value) is not bool:raise EvidenceDataError('strict bool node')
        return ('bool',value),4 if value else 5
    if kind=='int':return ('int',value),_validate_int(value,w)
    if kind=='float':return ('float',value),_validate_float(value,w)
    if kind=='str':return ('str',value),_string_size(value,w)
    if kind=='array':
        if type(value) is not outer:raise EvidenceDataError('array reference sequence')
        refs=[]
        for child in value:
            w.step('references')
            if type(child) is not int or not 0<=child<index:raise EvidenceDataError('strict prior integer array reference')
            refs.append(child)
        return ('array',tuple(refs)),None
    if kind=='object':
        if type(value) is not outer:raise EvidenceDataError('ordered exact object pairs')
        pairs=[];previous=None;key_sizes=[]
        for pair in value:
            w.step('object_pairs')
            if type(pair) is not outer or len(pair)!=2:raise EvidenceDataError('object pair arity')
            key,child=pair
            key_sizes.append(_string_size(key,w))
            if previous is not None and key<=previous:raise EvidenceDataError('unique object keys in exact Unicode order')
            if type(child) is not int or not 0<=child<index:raise EvidenceDataError('strict prior integer object reference')
            previous=key;pairs.append((key,child))
        return ('object',tuple(pairs)),key_sizes
    raise EvidenceDataError('unknown exact-evidence node tag')


def _validate_nodes(raw_nodes,root,w,wire):
    if type(raw_nodes) is not (list if wire else tuple) or not raw_nodes:
        raise EvidenceDataError('nonempty complete node table')
    w.bound('max_nodes',len(raw_nodes))
    if type(root) is not int or root!=len(raw_nodes)-1:raise EvidenceDataError('root must be final exact integer node ID')
    nodes=[];buckets={};sizes=[];occurrences=[];depths=[]
    for index,raw in enumerate(raw_nodes):
        node,scalar=_decode_node(raw,index,w,wire)
        _intern(node,nodes,buckets,w,reject_duplicate=True)
        refs=_references(node);size=scalar;occ=1;depth=0
        if node[0] in ('array','object'):
            size=2+max(0,len(refs)-1)
            if node[0]=='object':size+=sum(scalar)+len(refs)
            for child in refs:
                w.step('expanded_size_edges')
                size+=sizes[child];occ+=occurrences[child];depth=max(depth,1+depths[child])
                w.bound('max_expanded_bytes',size);w.bound('max_occurrences',occ)
            # Empty containers are values at depth0, as are scalars.
        if node[0] not in ('array','object'):w.bound('max_scalar_bytes',size)
        w.bound('max_expanded_bytes',size);w.bound('max_occurrences',occ);w.bound('max_depth',depth)
        sizes.append(size);occurrences.append(occ);depths.append(depth)
    seen=set();stack=[root]
    while stack:
        w.step('reachable_nodes');index=stack.pop()
        if index in seen:continue
        seen.add(index);stack.extend(_references(nodes[index]))
    if len(seen)!=len(nodes):raise EvidenceDataError('unreachable node in complete table')
    table=FrozenTable(tuple(nodes),root,_token=_TABLE_TOKEN)
    return table,dict(expanded_bytes=sizes[root],expanded_occurrences=occurrences[root],depth=depths[root])


def _validated(table,w):
    if type(table) is not FrozenTable:raise EvidenceDataError('owned FrozenTable required')
    return _validate_nodes(table.nodes,table.root,w,False)


def freeze(value,check,limits=None):
    """Own immutable DAG of strict ordinary JSON data; no caller mutation."""
    w=_Work(check,limits);nodes=[];buckets={};active=set();stack=[dict(value=value,depth=0,phase='value')]
    root=None;visits=0
    def finish(index):
        nonlocal root
        stack.pop()
        if stack:stack[-1]['refs'].append(index)
        else:root=index
    while stack:
        w.step('freeze_frames');frame=stack[-1]
        if frame['phase']=='value':
            visits+=1;w.bound('max_occurrences',visits);w.bound('max_depth',frame['depth'])
            current=frame['value'];kind=type(current)
            if current is None:finish(_intern(('null',),nodes,buckets,w));continue
            if kind is bool:finish(_intern(('bool',current),nodes,buckets,w));continue
            if kind is int:finish(_intern(('int',_int_lexeme(current,w)),nodes,buckets,w));continue
            if kind is float:finish(_intern(('float',_float_lexeme(current,w)),nodes,buckets,w));continue
            if kind is str:
                _string_size(current,w);finish(_intern(('str',current),nodes,buckets,w));continue
            if kind not in (list,dict):raise EvidenceDataError('ordinary builtin JSON value required')
            identity=id(current)
            if identity in active:raise EvidenceDataError('cyclic ordinary input container')
            active.add(identity)
            keys=None
            if kind is dict:
                keys=list(current)
                for key in keys:_string_size(key,w)
                w.step('object_key_sort');keys.sort();w.step()
            frame.update(phase='container',keys=keys,length=len(current),position=0,refs=[],identity=identity)
        else:
            current=frame['value'];position=frame['position']
            if len(current)!=frame['length']:raise EvidenceDataError('input container mutated during freeze')
            if position<frame['length']:
                if frame['keys'] is None:child=current[position]
                else:
                    key=frame['keys'][position]
                    if key not in current:raise EvidenceDataError('input object mutated during freeze')
                    child=current[key]
                frame['position']+=1;stack.append(dict(value=child,depth=frame['depth']+1,phase='value'))
            else:
                refs=frame['refs']
                node=('array',tuple(refs)) if frame['keys'] is None else ('object',tuple(zip(frame['keys'],refs)))
                active.remove(frame['identity']);finish(_intern(node,nodes,buckets,w))
    table,stats=_validate_nodes(tuple(nodes),root,w,False)
    check();return table


def _wire(table,w):
    nodes=[]
    for node in table.nodes:
        w.step('wire_nodes');kind=node[0]
        if kind=='null':nodes.append(['null'])
        elif kind=='array':nodes.append(['array',list(node[1])])
        elif kind=='object':nodes.append(['object',[[key,child] for key,child in node[1]]])
        else:nodes.append([kind,node[1]])
    return dict(schema=WIRE_SCHEMA,version=VERSION,root=table.root,nodes=nodes)


def _wire_size(wire,w):
    size=0
    encoder=json.JSONEncoder(sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
    for part in encoder.iterencode(wire):
        w.step('wire_json_parts');size+=len(part.encode('utf8'));w.bound('max_wire_bytes',size)
    return size


def to_wire(table,check,limits=None):
    """Fresh ordinary wire; mutating it cannot mutate the immutable table."""
    w=_Work(check,limits);owned,stats=_validated(table,w);wire=_wire(owned,w)
    _wire_size(wire,w);check();return wire


def validate_wire(wire,check,limits=None):
    """Strict whole wire validation; bounds never produce a partial table."""
    w=_Work(check,limits);w.step('wire_header')
    if (type(wire) is not dict or set(wire)!=set(('schema','version','root','nodes')) or
            wire['schema']!=WIRE_SCHEMA or wire['version']!=VERSION):
        raise EvidenceDataError('exact whole evidence wire header')
    table,stats=_validate_nodes(wire['nodes'],wire['root'],w,True)
    # Measure an owned wire reconstruction, not a caller-mutated source view.
    _wire_size(_wire(table,w),w);check();return table


def _scalar_bytes(node,w):
    kind=node[0]
    if kind=='null':return b'null'
    if kind=='bool':return b'true' if node[1] else b'false'
    if kind in ('int','float'):return node[1].encode('ascii')
    if kind=='str':return _string_bytes(node[1],w)
    raise EvidenceDataError('scalar token required')


def _expanded_tokens(table,w):
    """Bounded iterative occurrence traversal, with no recursive expansion."""
    stack=[('value',table.root,0)];visited=0
    while stack:
        w.step('expanded_frames');phase,index,position=stack.pop();node=table.nodes[index]
        if phase=='value':
            visited+=1;w.bound('max_occurrences',visited)
            if node[0]=='array':
                yield b'[';stack.append(('array',index,0))
            elif node[0]=='object':
                yield b'{';stack.append(('object',index,0))
            else:yield _scalar_bytes(node,w)
        elif phase=='array':
            refs=node[1]
            if position==len(refs):yield b']'
            else:
                if position:yield b','
                stack.append(('array',index,position+1));stack.append(('value',refs[position],0))
        else:
            pairs=node[1]
            if position==len(pairs):yield b'}'
            else:
                key,child=pairs[position]
                if position:yield b','
                yield _string_bytes(key,w);yield b':'
                stack.append(('object',index,position+1));stack.append(('value',child,0))


def iter_expanded_canonical(table,check,limits=None):
    """Yield complete canonical ordinary bytes only if caller exhausts iterator.

    A partial iterator is not a successful artifact. Root must charge/retain
    complete expansion size/SHA separately from encoded wire size/SHA.
    """
    w=_Work(check,limits);owned,stats=_validated(table,w);pending=bytearray();size=0
    for token in _expanded_tokens(owned,w):
        size+=len(token);w.bound('max_expanded_bytes',size);offset=0
        while offset<len(token):
            w.step('output_chunks');take=min(w.limits['chunk_bytes']-len(pending),len(token)-offset)
            pending.extend(token[offset:offset+take]);offset+=take
            if len(pending)==w.limits['chunk_bytes']:
                yield bytes(pending);pending.clear()
    if size!=stats['expanded_bytes']:raise EvidenceDataError('whole canonical inverse byte-size disagreement')
    if pending:yield bytes(pending)
    check()


def _materialized_scalar(node,w):
    kind=node[0]
    if kind=='null':return None
    if kind in ('bool','str'):return node[1]
    if kind=='int':
        w.step('materialize_integer')
        try:return int(node[1])
        except ValueError as error:raise EvidenceDataError('interpreter materialized integer limit') from error
    if kind=='float':
        w.step('materialize_float')
        try:return float(node[1])
        except (ValueError,OverflowError) as error:raise EvidenceDataError('materialized float parse') from error
    raise EvidenceDataError('materialized scalar tag')


def materialize(table,check,limits=None):
    """Small fresh ordinary value. Each shared reference gets fresh containers."""
    w=_Work(check,limits);owned,stats=_validated(table,w)
    w.bound('max_materialized_occurrences',stats['expanded_occurrences'])
    w.bound('max_materialized_bytes',stats['expanded_bytes'])
    holder=[None];stack=[(owned.root,holder,0)];count=0
    while stack:
        w.step('materialized_values');index,parent,key=stack.pop();node=owned.nodes[index]
        count+=1;w.bound('max_materialized_occurrences',count)
        if node[0]=='array':
            value=[None]*len(node[1]);parent[key]=value
            for i in range(len(node[1])-1,-1,-1):stack.append((node[1][i],value,i))
        elif node[0]=='object':
            value={k:None for k,i in node[1]};parent[key]=value
            for k,i in reversed(node[1]):stack.append((i,value,k))
        else:parent[key]=_materialized_scalar(node,w)
    if count!=stats['expanded_occurrences']:raise EvidenceDataError('whole fresh materialization occurrence disagreement')
    check();return holder[0]
