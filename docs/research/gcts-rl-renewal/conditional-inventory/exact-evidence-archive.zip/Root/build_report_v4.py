"""Publish saved ordinary-data packets only. No scientific module evaluation."""
from pathlib import Path
import hashlib,html,json,re,zipfile

D=Path(__file__).parent
OLD=Path('/private/tmp/gcts-exact-evidence-ROOT-20261019')
S=Path('/private/tmp/gcts-fragment-inverse-ROOT-source-20261019')
C=Path('/private/tmp/gcts-fragment-inverse-peer-20261019')
LIB=Path('/private/tmp/gcts-fragment-inverse-library-20261019')
P=Path('/private/tmp/gcts-split-controls-publish-20261015/docs/research/gcts-rl-renewal/conditional-inventory')
def load(p):return json.loads(Path(p).read_bytes())
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()+b'\n'
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def publish(n,v):
 p=P/n;p.write_bytes(canonical(v));return pin(p)
def esc(s):return html.escape(str(s))
def math(s):return r'\('+str(s)+r'\)'
def num(v):return math(format(v,','))
def mib(v):return math(f'{v/1048576:.2f}'+r'\,\mathrm{MiB}')
def sec(v):return math(f'{v:.3f}'+r'\,\mathrm{s}')

audit=load(D/'ROOT-final-audit-v4.json')
peer=load(C/'typed-fragment-qualification-saved-review-v4.json')
assert audit['representation_admitted']is True and audit['resource_admitted']is True
assert peer['saved_data_only']is True and peer['scientific_calls']==0
assert peer['mismatch_count']==0
plan=load(D/'plan-authorized-v4.json');actual=Path(plan['actual_directory'])
packet=load(actual/'result.json');runner=load(actual/'runner-receipt.json')
terminal=load(D/'plan-authorized-v4-terminal-observation/terminal.json')
rows=packet['complete_inputs'];fixtures=packet['fixtures']
assert len(rows)==3 and len(fixtures)==71 and all(x['passed']for x in fixtures)
assert terminal['terminal_gate_passed']and packet['inverse_private_limits']['work']==30000000
old1=load(OLD/'ROOT-negative-audit-v1.json');old2=load(OLD/'ROOT-final-audit-v5.json');old3=load(D/'ROOT-final-audit-v3.json')
trials=[
 dict(id='original-checkpoints',label='Original checkpoints; original inverse',status=old1['status'],terminal_seconds=old1['failure_terminal_seconds'],worker_peak_bytes=old1['worker_peak_bytes'],complete_inputs=0,diagnostics=0,representation_admitted=False,private_guard=20000000,operation_profile='original virtual walk',fixtures_first=False),
 dict(id='batched-encoder',label='Batched encoder; original inverse',status=old2['status'],terminal_seconds=old2['terminal_seconds'],worker_peak_bytes=old2['worker_peak_bytes'],complete_inputs=0,diagnostics=0,representation_admitted=False,private_guard=20000000,operation_profile='original virtual walk',fixtures_first=False),
 dict(id='fragments-20m',label='Fragment inverse; default guard',status=old3['status'],terminal_seconds=old3['terminal_seconds'],worker_peak_bytes=old3['worker_peak_bytes'],complete_inputs=0,diagnostics=71,representation_admitted=False,private_guard=20000000,operation_profile='actual operations v4',fixtures_first=True),
 dict(id='fragments-30m',label='Fragment inverse; explicit changed guard',status=audit['status'],terminal_seconds=audit['terminal_seconds'],worker_peak_bytes=audit['worker_peak_bytes'],complete_inputs=3,diagnostics=71,representation_admitted=True,private_guard=30000000,operation_profile='actual operations v4',fixtures_first=True)]
summary=dict(schema='published-exact-evidence-summary-v2',status=audit['status'],representation_admitted=True,resource_admitted=True,
 original_complete_input_count=3,completed_independent_input_packets=3,completed_diagnostics=71,whole_original_input_bytes=packet['aggregate_input_expanded_bytes'],
 encoded_complete_table_bytes=packet['aggregate_encoded_table_bytes'],aggregate_encoded_and_result_bytes=runner['aggregate_encoded_result_bytes'],
 worker_peak_bytes=audit['worker_peak_bytes'],terminal_seconds=audit['terminal_seconds'],trials=trials,
 inverse_execution_profile=packet['inverse_execution_profile'],qualification_private_work=30000000,default_private_work=20000000,default20m_guard_pass=False,old_virtual_work_profile_pass=False,
 mathematical_proof_accepted=False,new_target_theorem=False,Model_permission=False,schema_inventory_admission=False,Native_calls=0,search_calls=0,RL_training=False,
 conformance='Representation-only engineering control. No point values, markings, candidate graph, generation, scheduler, rollback or proof rules changed.',
 comparison_scope='Four distinct engineering trials; changed implementation/profile/order/guard prevent causal speedup claims. Both current trials run71 diagnostics first. No integrated-search RAM or proof-search advantage follows.',goal_complete=False)
design=dict(schema='published-exact-evidence-next-design-v2',status='PROPOSED_NOT_IMPLEMENTED_NOT_AUTHORIZED',
 prior_fragment_design=load('/private/tmp/gcts-exact-evidence-source-20261019/independent-inverse-next-design-v1.json'),
 current_component=dict(status=audit['status'],qualification_private_work=30000000,default20m_guard_pass=False),
 integration_reconnaissance=load(LIB/'integration-reconnaissance-v1.json'),
 next_decision='Use component qualification as a prerequisite only. A new invocation-local multi-root arena/packet capture API and consumer custody contract need separate Source review, a declared common representation profile and matched full fixed/symbolic pipeline measurements. Do not retry the old failed profile or remove evidence to fit.',
 scientific_calls=0,implementation_written=False,goal_complete=False)
publish('exact-evidence-summary.json',summary);publish('exact-evidence-admission.json',audit)
publish('exact-evidence-peer-review.json',peer);publish('exact-evidence-result.json',packet);publish('exact-evidence-next-design.json',design)

entries=[dict(label='Whole-run outcome and all four trials',packet=summary)]
entries.extend(dict(label='Complete input: '+r['id'],packet=r)for r in rows)
entries.extend(dict(label='Diagnostic: '+f['name'],packet=f)for f in fixtures)
entries.extend([
 dict(label='Current complete qualification result',packet=packet),dict(label='Current resource receipt',packet=runner),
 dict(label='Earlier original checkpoint trial: UNKNOWN',packet=load(OLD/'actual-v4/worker-failure.json')),
 dict(label='Earlier batched encoder trial: UNKNOWN',packet=load(OLD/'actual-v5/worker-failure.json')),
 dict(label='Fragment inverse with default guard: UNKNOWN',packet=load(D/'actual-v3/worker-failure.json')),
 dict(label='Root saved-data audit',packet=audit),dict(label='Independent saved-data audit',packet=peer),
 dict(label='Earlier retention seam: Source-only proposal',packet=design['integration_reconnaissance'])])
(D/'publication-viewer-expected-v4.json').write_bytes(canonical(dict(entries=entries)))
typed=next(f for f in fixtures if f['name']=='typed_values_order_unicode_and_repeated_ports')
fragment=next(f for f in fixtures if f['name']=='fragment_repeated_subtree_and_summary')
assert fragment['wire']['nodes'][3]==['object',[['a',2],['b',2],['c',2]]]
assert fragment['statistics']['cache_hits_stream']==3 and fragment['statistics']['completed']

table_rows=''.join('<tr><td>'+esc(r['id'])+'</td><td>'+num(r['input']['bytes'])+'</td><td>'+num(r['encoded']['bytes'])+'</td><td>'+num(r['immutable_node_count'])+'</td><td>Every byte agrees</td></tr>'for r in rows)
chart='<div class="chart" role="img" aria-label="Complete original and typed table byte counts"><h3>Full data, two storage representations</h3>'
for label,size,cls in [('Ordinary JSON',summary['whole_original_input_bytes'],''),('Typed tables',summary['encoded_complete_table_bytes'],' compact')]:
 chart+='<div class="chart-row"><span>'+label+'</span><div class="track'+cls+'"><i style="width:'+str(round(100*size/summary['whole_original_input_bytes'],3))+'%"></i></div><span>'+mib(size)+'</span></div>'
chart+='<p class="small">All three whole files, including each external newline. The '+mib(pin(actual/'result.json')['bytes'])+' result is charged separately; aggregate tables plus result are '+mib(summary['aggregate_encoded_and_result_bytes'])+'. This is a storage measurement, not search speed or integrated memory savings.</p></div>'

resource='<div class="table-wrap"><table><thead><tr><th>Trial</th><th>Private guard / units</th><th>Complete inputs</th><th>Diagnostics</th><th>Terminal</th><th>Worker peak</th><th>Outcome</th></tr></thead><tbody>'
for t in trials:
 resource+='<tr><td>'+esc(t['label'])+'</td><td>'+num(t['private_guard'])+'<br>'+esc(t['operation_profile'])+'</td><td>'+num(t['complete_inputs'])+'</td><td>'+num(t['diagnostics'])+'</td><td>'+sec(t['terminal_seconds'])+'</td><td>'+mib(t['worker_peak_bytes'])+'</td><td>'+esc(t['status'])+'</td></tr>'
resource+='</tbody></table></div><p>The first two trials ran whole inputs before diagnostics. Both fragment trials run the same full suite first, then all three original whole inputs. Every trial has a fresh once-only subject and starts from the original files; no failed output table or cache is reused.</p>'
resource+='<p>The fragment inverse uses a new explicit actual-operation accounting profile. The earlier inverse charged a virtual occurrence walk. These units are different. Within the new profile, the first whole input needs '+num(rows[0]['independent_inverse_statistics']['actual_operations'])+' charged operations. The default '+num(20000000)+' trial therefore remains UNKNOWN. Only the separately declared '+num(30000000)+' guard qualifies. The inverse module’s default stays unchanged; no proof-search or Native budget changes.</p>'
resource+='<p>The first timeout is censored, the inverse/accounting and diagnostic order changed, and the successful trial explicitly changes a private guard. These four measurements do not establish a causal speedup. The current first-input cache records '+num(rows[0]['independent_inverse_statistics']['cache_hits_stream'])+' stream hits, '+num(rows[0]['independent_inverse_statistics']['cache_entries'])+' entries and '+mib(rows[0]['independent_inverse_statistics']['cache_payload_bytes'])+' payload, all charged in the worker peak. A hit alone is not a measured net performance benefit.</p>'
resource+='<p>Terminal time starts at the runner’s timestamp immediately after importing <code>time</code>. Runner interpreter startup and the outer observer prelude precede this gated epoch. Positive work includes component imports, input setup, every diagnostic and known worker exit. The observer deadline is failure-only and grants no extra positive work.</p>'

lead='All three complete saved artifacts reconstruct byte for byte through an independently authored inverse, and all seventy-one diagnostics pass within the declared standalone limits, using an explicitly changed private operation guard.'
outcome='The tested evidence representation qualifies.'
detail='The successful trial validates this finite storage boundary under its declared configuration. The default private guard failed in a separate retained trial. This result adds no theorem and does not activate the component in proof search.'
next_step='The next engineering decision is earlier retention of completed packets, before repeated mutable snapshots accumulate. A new invocation-local multi-root evidence arena and an exact consumer interface would be needed; independently freezing each packet with today’s API cannot share nodes across packets. This is a Source-only design, not an implemented memory fix.'
template=(OLD/'exact-evidence-template.html').read_text()
for k,v in dict(LEAD=lead,OUTCOME_TITLE=outcome,INPUT_COUNT='3',COMPLETE_COUNT='3',FIXTURE_COUNT='71',OUTCOME_DETAIL=detail,ARTIFACT_ROWS=table_rows,BYTE_CHART=chart,GRAPH_FALLBACK='<p>The diagram below is drawn from the actual returned diagnostic.</p>',RESOURCE_DETAIL=resource,NEXT_STEP=next_step,PACKETS=json.dumps(dict(entries=entries,typed_fixture=typed),sort_keys=True,ensure_ascii=False,allow_nan=False).replace('<','\\u003c')).items():
 template=template.replace('@@'+k+'@@',v)
assert '@@'not in template
oldgraph=template.index('if(saved.typed_fixture)');template=template[:oldgraph]+'</script></body></html>\n'
graph='''<div class="fragment-diagram" role="img" aria-label="Actual diagnostic: three object keys refer to the same immutable array, then all three are copied into ordinary output"><div class="port-row"><div class="reference"><code>a</code><br>first object field</div><div class="reference"><code>b</code><br>second object field</div><div class="reference"><code>c</code><br>third object field</div></div><div class="down">↓　↓　↓</div><div class="shared"><b>One immutable array node</b><p>String child · integer child</p><p>One bounded canonical fragment, reused at each field</p></div><div class="down">↓　↓　↓</div><div class="port-row"><div class="reference">Full first occurrence<br>copied into output</div><div class="reference">Full second occurrence<br>copied into output</div><div class="reference">Full third occurrence<br>copied into output</div></div></div>'''
graph+='<p>Returned diagnostic <code>fragment_repeated_subtree_and_summary</code>: '+num(4)+' typed nodes, '+num(5)+' references, '+num(10)+' ordinary value occurrences, '+num(61)+' canonical body bytes and '+num(3)+' stream cache hits. The complete input, wire table and independent counters can be inspected in the selector.</p>'
template=template.replace('<div id="graphPanel"><p>The diagram below is drawn from the actual returned diagnostic.</p></div>','<div id="graphPanel">'+graph+'</div>')
template=template.replace('</style>', '.port-row{display:grid;grid-template-columns:repeat(3,1fr);gap:15px}.port-row .reference{border-color:#8659ad}.down{text-align:center;font-size:30px;color:#527b82;margin:8px}.fragment-diagram .shared p{margin:8px 0}.pipeline{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}.pipeline article{background:white;border-top:4px solid #46858b;padding:15px}.pipeline h3{font-size:17px}@media(max-width:750px){.port-row,.pipeline{grid-template-columns:1fr}.down{font-size:22px}}\n</style>')
mechanism='<div class="pipeline"><article><h3>Validate the whole table</h3><p>Types, canonical scalars, ordering, prior references, depth and typed uniqueness.</p></article><article><h3>Reconcile every use</h3><p>Complete reachability, use multiplicity, exact expanded bytes and value counts.</p></article><article><h3>Cache bounded fragments</h3><p>Repeated small values only; build from owned validated nodes. Capacity exhaustion falls back to ordinary streaming.</p></article><article><h3>Copy the whole output</h3><p>Every repeated occurrence is still emitted. Complete bytewise comparison and final counts must agree.</p></article></div>'
template=template.replace('<section id="mechanism"><h2>Equal values share storage; ordered uses stay separate</h2>','<section id="mechanism"><h2>Equal values share storage; ordered uses stay separate</h2>'+mechanism)
template=template.replace('<p>The finite domain is explicit:', '<p>The fragment payload is limited to '+mib(8388608)+' and '+num(65536)+' entries, with fragments no larger than '+num(4096)+' bytes and stream chunks no larger than '+num(65536)+' bytes. Cache payload bounds exclude Python object overhead; the full worker peak includes it. Callback tests cover cached construction and post-first-chunk copies, not every possible completion/fallback interruption. Bounded builtin scans/copies still rely on Python/OS latency assumptions; no continuous formal time seal is claimed.</p><p>The finite domain is explicit:')
template=template.replace('Implemented the immutable typed table, encoder, canonical inverse and small fresh materializer.','Implemented the immutable typed table, encoder, canonical inverse and small fresh materializer; examined the earlier packet-retention seam without changing it.')
template=template.replace('then independently audits the retained actual.','then independently audited the retained actual.')
template=template.replace('All unexecuted drafts remain in the archive.','Further Source review caught missing eager size checks for scalar/empty-container roots and a diagnostic catch that could mask an unrelated deadline exception; both were repaired before evaluation. The exact boundary, disabled/full/partial-cache fallbacks, mutation isolation and late callback identity are included in the seventy-one returned diagnostics. All unexecuted drafts and negative reviews remain in the archive.')
template=template.replace('<p>Storage sharing alone is not the hoped-for geometric or learned contribution.', '<p><a href="exact-evidence-next-design.json">Read the frozen next-design packet</a>. The failed matched pilot crossed the old fully expanded output guard; smaller wire bytes cannot make that same old expansion pass an unchanged guard. Any future expansion allowance or physical-storage interpretation must be declared as a new finite profile, applied equally to both fixed and symbolic methods. The same complete inventory, Model, search rules, trace and fresh proof checking must remain. Late final-output freezing alone would not remove earlier producer allocations.</p><p>Storage sharing alone is not the hoped-for geometric or learned contribution.')
template=template.replace('No turtle, Penrose, infinite tiling, universal Wang palette, full Peano arithmetic or Hilbert-geometry result is added.','No turtle, Penrose, infinite tiling, universal Wang palette, full Peano arithmetic or Hilbert-geometry result is added. The next scientific milestone remains a complete, fair proof-search comparison with checkable proof rows; this storage control supplies no evidence of GCTS/RL superiority.')
(P/'exact-evidence.html').write_text(template)
reader=P/'reader.html';s=reader.read_text();s=re.sub(r'<section id="exact-evidence">[\s\S]*?</section>','',s,count=1)
section='<section id="exact-evidence"><p class="eyebrow">19 OCTOBER 2026 · STANDALONE STORAGE CONTROL</p><h2>'+outcome+'</h2><p>Three complete artifacts reconstruct byte for byte and all seventy-one diagnostics pass under an explicitly changed private guard. All three earlier UNKNOWN trials remain visible. This adds no theorem, RL training or search-speed claim. <a href="exact-evidence.html?v=20261019-ee-fragments#outcome"><b>Read the qualification and costs</b></a> · <a href="exact-evidence.html?v=20261019-ee-fragments#reader">Inspect every returned packet</a>.</p></section>'
assert '<section id="schema-admission-pilot">'in s
reader.write_text(s.replace('<section id="schema-admission-pilot">',section+'<section id="schema-admission-pilot">',1))

files={}
folders=[(OLD,'Prior-Root'),(Path('/private/tmp/gcts-exact-evidence-ROOT-source-20261019'),'Prior-Root-Source'),(Path('/private/tmp/gcts-exact-evidence-source-20261019'),'Library-Source'),(Path('/private/tmp/gcts-exact-evidence-peer-20261019'),'Prior-Control'),(D,'Root'),(S,'Root-Source'),(C,'Control'),(LIB,'Library-Reconnaissance')]
for folder,label in folders:
 for p in folder.rglob('*'):
  if p.is_file()and p.suffix in ('.json','.py','.html','.bin','.txt','.diff')and '__pycache__'not in p.parts and not p.name.startswith(('publication-','live-','ROOT-final-milestone','verify_live','sync_primary')):
   files[label+'/'+str(p.relative_to(folder))]=p
for x in plan['inputs']:files['whole-original-inputs/'+x['id']+'.json']=Path(x['input']['path'])
archive=P/'exact-evidence-archive.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for name,p in sorted(files.items()):z.write(p,name)
 z.writestr('README.txt','Complete ordinary-data representation evidence. Three whole original inputs, four separately declared consumed trials, all current and rejected Sources, plans/reviews and saved results. No codec/inverse evaluated by archive creation; no opaque Native microcode. Old20m and old virtual-work profile remain unqualified. Only separately declared30m actual-operation configuration qualifies finite representation. No Model/schema/proof/RL/search authority follows. Absolute paths are historical custody references. Reproduction requires a fresh bounded reviewed subject; never reuse consumed invocations.\n')
manifest=dict(schema='published-exact-evidence-byte-manifest-v2',files=[dict(archive_name=n,**pin(p))for n,p in sorted(files.items())],archive=pin(archive),published=[pin(P/n)for n in ['exact-evidence.html','exact-evidence-summary.json','exact-evidence-admission.json','exact-evidence-peer-review.json','exact-evidence-result.json','exact-evidence-next-design.json','reader.html']],saved_data_only=True,codec_or_inverse_calls=0,goal_complete=False)
publish('exact-evidence-manifest.json',manifest)
print(json.dumps(dict(status=summary['status'],archive=pin(archive),archive_members=len(files)+1,viewer_entries=len(entries),publication_files=9)))
