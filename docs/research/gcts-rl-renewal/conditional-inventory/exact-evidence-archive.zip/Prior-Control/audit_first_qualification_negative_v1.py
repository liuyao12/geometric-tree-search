"""Saved ordinary metadata/raw hashes only. Never import or call the codec."""
import hashlib
import json
import stat
from pathlib import Path

D=Path('/private/tmp/gcts-exact-evidence-ROOT-20261019');O=Path('/private/tmp/gcts-exact-evidence-peer-20261019')
A=D/'actual-v4';T=D/'plan-authorized-v4-terminal-observation';checks=[];pins={}
def ck(n,v):
    checks.append(dict(check=n,passed=bool(v)))
    if not v:raise AssertionError(n)
def pin(p):
    b=Path(p).read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def get(d,n):
    p=Path(d['path']);s=p.lstat();ck(n+' canonicalregular',p==p.resolve()and stat.S_ISREG(s.st_mode)and not p.is_symlink());b=p.read_bytes();ck(n+' whole rawpin',pin(p)==d);pins[str(p)]=d;return json.loads(b)
def cur(p,n):
    d=pin(p);return get(d,n),d
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
idxd=dict(path=str(D/'authorized-index-v4.json'),sha256='5468ac74da6b5e673b2bd8eff8ae4d31fe1c8ce0dad8861af3ac774c3a0bdcc5',bytes=7419)
i=get(idxd,'trueindex');p=get(i['plan'],'exact plan');a=get(i['authorization'],'grant')
c,cd=cur(A/'CONSUMED.json','worker consumed');f,fd=cur(A/'worker-failure.json','failure');r,rd=cur(A/'runner-receipt.json','runner');t,td=cur(T/'terminal.json','terminal');oc,ocd=cur(T/'CONSUMED.json','observer consumed');cl,cld=cur(D/'ROOT-cohort-closure-v1.json','Root saved process closure')
s={k:v for k,v in p.items()if k!='authorization'};sha=hashlib.sha256(canonical(s)).hexdigest()
ck('exact12subject full equality',len(s)==12 and s==i['subject']and sha==i['subject_sha256']==a['subject_sha256']==c['subject_sha256']==r['subject_sha256']=='3881b98d1fe1572961a27e85ad73bbb366c68800af599ea475cbfbd0af995f3c')
ck('exact once linkage',p['authorization']==i['authorization']==r['authorization']and r['plan']==c['plan']==t['plan']==oc['plan']==i['plan']and r['consumed_marker']==cd and t['runner_receipt']==rd)
ck('true maxone and prePopen consumption',a['actual_execution_authorized']is True and type(a['maximum_actual_invocations'])is int and a['maximum_actual_invocations']==1 and c['consumed_before_Popen']is True and c['maximum_worker_launches']==r['worker_launch_attempts']==oc['maximum_runner_launches']==1)
ck('exact reviewroles',a['review_roles']==i['review_roles']and set(a['review_roles'])=={'Source','plans'})
for role,d in a['review_roles'].items():
    v=get(d,'review '+role);ck(role+' exact scoped PASS zero execution',v['reviewer_identity']=='/root/conventional_control_review'and v['source_only']is True and v['scientific_calls']==0 and v['scientific_acceptance']is False and v['actual_execution_authorized']is False and v['source_review_passed'if role=='Source'else'prospective_review_passed']is True)
for role,d in i['current_sources'].items():ck('current original Source '+role,p[role]==d and pin(d['path'])==d);pins[d['path']]=d
ck('all three rawinputs unchanged',all(pin(item['input']['path'])==item['input']for item in p['inputs']))
ck('original full limits',r['limits']==p['limits']==dict(expanded_bytes=134217728,memory_bytes=1073741824,overall_seconds=210,result_bytes=134217728,stderr_bytes=4194304,stdout_bytes=4194304,work_seconds=180))
ck('original absolute clock',c['began_ns']==r['began_ns']and c['work_deadline_ns']==r['work_deadline_ns']==r['began_ns']+180000000000 and c['overall_deadline_ns']==r['overall_deadline_ns']==r['began_ns']+210000000000)
ck('retained WorkDeadline UNKNOWN',f['schema']=='exact-evidence-worker-failure-v1'and f['status']=='UNKNOWN_WORK_DEADLINE'and f['type']=='WorkDeadline'and f['message']=='original work deadline'and f['own_codec_limit']is False and f['own_inverse_limit']is False and f['limit']is None)
ck('exact reached input/stage',f['reached_context']==dict(fixture=None,input='full-base-control',stage='SAVED_TABLE_ENCODER_INVERSE'))
ck('no completed wholeinput/fixture/result prefix',f['completed_input_packets']==[]and f['completed_fixture_prefix']==[]and f['published_result_candidate']is None and f['representation_accepted']is False and f['scientific_acceptance']is False)
ck('aggregate tick count retained (not semantic quota)',type(f['callback_count_at_failure'])is int and f['callback_count_at_failure']==368951118)
ck('exact expanded and encoded prefix bytes',f['aggregate_expanded_input_prefix_bytes']==p['inputs'][0]['input']['bytes']==36481858 and f['aggregate_encoded_table_prefix_bytes']==15096899 and len(f['published_table_prefix'])==1)
q=f['published_table_prefix'][0];ck('full raw encoded prefix pin only',q==dict(path=str(A/'full-base-control-table.json'),sha256='8f67f39b299e0dd2a250352ebdf864be79a0c0defbb83b181353938bf77012d7',bytes=15096899)and pin(q['path'])==q);pins[q['path']]=q
for filename in ('result.json','worker-receipt.json','full-shadow-packets-table.json','full-prior-case002-table.json'):ck('absent '+filename,not(A/filename).exists())
ck('no partial artifact',not list(A.glob('*.partial')))
ck('distinct worker signal and runner failure',r['worker_exit_code']==-15 and r['worker_wait4_status']==15 and r['worker_reaped']is True and t['runner_exit_code']==2 and r['worker_pid']!=t['runner_pid'])
ck('all candidate/authority flags false',all(r[k]is False for k in ('resource_candidate_accepted','representation_candidate','scientific_acceptance','mathematical_proof_accepted','Model_permission'))and t['terminal_gate_passed']is False and t['scientific_acceptance']is False)
ck('parent deadline SIGTERM exact metadata',len(r['signals'])==1 and r['signals'][0]['signal']==15 and r['work_deadline_ns']<=r['signals'][0]['sent_ns']<r['worker_terminal_observed_ns'])
ck('runner failure work endpoint',r['errors']==[dict(message='worker original work deadline',type='ValueError')])
ck('worker/group/runner known closed metadata',r['owned_pgid']==r['worker_pid']==64219 and t['runner_pid']==64218 and r['owned_group_absent']is True and r['regular_logs_closed']is True and r['worker_terminal_observed_ns']<=r['closed_ns']<=t['terminal_ns']<r['overall_deadline_ns'])
ck('Root saved processabsence agrees',cl['all_workers_and_owned_groups_closed']is True and cl['exact_pids']==[64218,64219]and cl['owned_group']==64219 and cl['regular_logs_closed']is True and cl['remaining_processes']==''and cl['scientific_calls']==0)
ck('exact failure time only',t['runner_clock_seconds']==(t['terminal_ns']-r['began_ns'])/1e9==180.067019208 and r['closed_ns']>r['work_deadline_ns'])
peak=r['worker_wait4_usage']['ru_maxrss'];ck('singleworker peak belowcap but not admission',peak==725008384 and peak<r['limits']['memory_bytes']and 'worker_peak_bytes'not in r and r['Native_calls']==0)
for name in ('stdout','stderr'):
    d=r[name];ck('full bounded log '+name,pin(d['path'])==d and d['bytes']<=r['limits'][name+'_bytes']);pins[d['path']]=d
ck('deadline traceback no stdout',(A/'stdout.bin').read_bytes()==b''and b'WorkDeadline'in(A/'stderr.bin').read_bytes())
ck('exact observer command',t['command']==[p['python']['path'],'-I','-S','-B',p['runner']['path'],str(D/'plan-authorized-v4.json')])
for filename in ('stdout.bin','stderr.bin'):d=pin(T/filename);pins[d['path']]=d
ck('observer captures runner false-candidate stdout',json.loads((T/'stdout.bin').read_bytes())==dict(actual=str(A),resource_candidate_accepted=False,representation_candidate=False)and (T/'stderr.bin').read_bytes()==b'')
ck('no late positive markers',not(A/'POST_RECEIPT_WORK_FAILURE.json').exists()and not(A/'POST_RECEIPT_DEADLINE_FAILURE.json').exists())
ck('complete actual file census no Nativefiles',{x.name for x in A.iterdir()}=={'CONSUMED.json','full-base-control-table.json','runner-receipt.json','stderr.bin','stdout.bin','worker-failure.json'})
rootd=dict(path=str(D/'ROOT-negative-audit-v1.json'),sha256='ce8fd8fee103cfaec4458f7b81679a0d3e0d3dc55d53c1d682d13a657c089bd1',bytes=2464);get(rootd,'Root separate negative audit raw reference')
def write(n,v):
    z=O/n
    with z.open('xb')as out:out.write((json.dumps(v,sort_keys=True,indent=2)+'\n').encode())
    return pin(z)
audit=write('first-qualification-saved-negative-audit-v1.json',dict(schema='exact-evidence-first-qualification-saved-negative-audit-v1',source_only=True,saved_data_only=True,scientific_calls=0,codec_calls=0,checks=checks,rawpins=list(pins.values()),full_failure=f,full_runner=r,full_observer=t))
review=write('typed-first-qualification-negative-review-v1.json',dict(schema='exact-evidence-first-qualification-saved-negative-review-v1',author_identity='/root',reviewer_identity='/root/conventional_control_review',negative_evidence_review_passed=True,source_only=True,saved_data_only=True,scientific_calls=0,codec_calls=0,scientific_acceptance=False,actual_execution_authorized=False,representation_accepted=False,resource_accepted=False,authorized_index=idxd,whole_failure_packet=fd,runner_receipt=rd,terminal_observation=td,consumed_marker=cd,observer_consumed=ocd,Root_saved_cohort_closure=cld,Root_separate_negative_audit=rootd,current_sources=i['current_sources'],subject_sha256=sha,retained_unqualified_table=q,failure_terminal_seconds=t['runner_clock_seconds'],worker_wait4_peak_bytes=peak,worker_wait4_peak_MiB=peak/1048576,Root_tick_callback_count_at_failure=f['callback_count_at_failure'],check_count=len(checks),mismatch_count=0,audit=audit,review_Source=pin(Path(__file__)),findings=[],conclusions=[
 'Exactly one granted subject3881b98d was consumed once. Currentfive original rawSource pins and allthree wholeinput pins remain exact. Saved observation agrees worker64219/group64219 and runner64218 absent. No Native child or new scientific output is declared in this standalone profile.',
 'Worker retained UNKNOWN_WORK_DEADLINE at SAVED_TABLE_ENCODER_INVERSE on firstfull-base-control. One whole-pinned15096899B table file survives, but no completed wholeinput packet, independent inverse, fixture or result/header is retained. It is an unqualified prefix, not a successful compression ratio or complete semantic-fidelity result.',
 'Worker wait4 reports SIGTERM(-15) after the parent180s endpoint; runnerexit2 and observerfalsegate are distinct. Internal WorkDeadline metadata survives but this is not a normal positive worker exit.180.067019208s is a failure terminal duration.',
 'Worker peak725008384B (691.421875MiB) is below1GiB, but work/normalexit/fullresult/inverse gates failed. Resource and representation are not admitted. Native is absent, so no fictitious separate CPP peak is added.',
 '368951118 is aggregate Root tick invocations, not weighted semantic work, unique nodes, instruction count or a measured causal explanation. A proposed checkpoint successor is a separate unexecuted profile change, with no fit/speed conclusion.'
 ],checkpoint_successor_obligations=[
 'Keep every canonical/type/ref/reachability/uniqueness/size/occurrence and private per-API work-quota check unchanged. Only delegated check cadence varies; retain first and public API completion checks and exact exceptions when invoked.',
 'Specify weighted work versus step calls: one4096character amount crosses multiple1024work quanta. Preserve or explicitly declare callback-before-quota/count-commit ordering; do not silently exceed the maximum interval.',
 'Same three wholeinputs, full inverses, savedwire reread,48fixed fixtures and aggregate encodedANDexpanded128MiB/180/210/1GiB gates. Fresh subject/paths/grant; this old table cannot seed/cachereuse the new qualification.',
 'A cadence change alters callback trace/cost and observation latency. It is not byte-identical execution or an all-late-callback/interleaving equivalence claim.'
 ],limitations=[
 'Raw retained JSON/hash/stat only. No codec/inverse/worker/fixture/Native/Model/search/scientific replay or execution. The encoded table was whole raw-hashed only, never decoded, materialized or inversely reconstructed.',
 'Negative evidence review PASS is not a representation success, proof result, pipeline memory improvement or correctness theorem. Missing failed scientific outputs remain missing and failed.',
 'Reached stage is Source-backed context only. No current completeinput packet exists; individual earlier return comparisons are not separately saved or re-certified from the table hash. Independent inverse and all48fixtures were not reached in this actual.',
 'Regular-file logs, saved process absence/reaping and Source guards are conditional retained observations. Pinned Python/bundled stdlib/OS, exclusiveownership and bounded builtin/blocking-operation trust remain. Outer/observer RAM and interpreter prelude are outside the inherited Source-entry singleworker scope.',
 'Reviewer authored older unrelated outer/driver/helper/symbolic/checker/benchmark components, not these current Root/Library fiveSources. This is savedfailure audit, not own algorithm certification. No retry, capraise, clipping, prefix salvage or actual activation is authorized.'
 ]))
handoff=write('first-qualification-negative-peer-handoff-v1.json',dict(schema='exact-evidence-first-qualification-negative-peer-handoff-v1',review=review,audit=audit,authorized_index=idxd,source_only=True,scientific_calls=0,codec_calls=0,actual_execution_authorized=False))
print(json.dumps(dict(review=review,audit=audit,handoff=handoff,checks=len(checks)),indent=2))
