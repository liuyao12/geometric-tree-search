"""Static HTML and literal saved JSON joins only. Never execute report JS/Python."""
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlsplit,unquote
import ast
import hashlib
import json
import re

D=Path('/private/tmp/gcts-exact-evidence-ROOT-20261019')
P=Path('/private/tmp/gcts-split-controls-publish-20261015/docs/research/gcts-rl-renewal/conditional-inventory')
Q=Path('/private/tmp/gcts-exact-evidence-peer-20261019')
checks=[];pins={}
def need(label,value):
    checks.append(dict(label=label,passed=bool(value)))
    if not value:raise AssertionError(label)
def raw(path):
    path=Path(path);b=path.read_bytes();d=dict(path=str(path),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b));pins[str(path)]=d;return d,b
def load(path):
    d,b=raw(path);return d,json.loads(b)
def save(name,value):
    p=Q/name
    if p.exists():raise AssertionError('preserve '+str(p))
    p.write_bytes(json.dumps(value,ensure_ascii=False,sort_keys=True,indent=2,allow_nan=False).encode()+b'\n')
    b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
class Page(HTMLParser):
    def __init__(self):
        super().__init__();self.ids=[];self.links=[];self.text=[];self.skip=0;self.rows=[];self.row=None;self.cell=None
    def handle_starttag(self,tag,attrs):
        a=dict(attrs)
        if 'id'in a:self.ids.append(a['id'])
        if tag=='a'and'href'in a:self.links.append(a['href'])
        if tag in ('script','style'):self.skip+=1
        if tag=='tr':self.row=[]
        if tag in ('td','th')and self.row is not None:self.cell=[]
    def handle_endtag(self,tag):
        if tag in ('script','style'):self.skip-=1
        if tag in ('td','th')and self.row is not None:
            self.row.append(''.join(self.cell or []));self.cell=None
        if tag=='tr'and self.row is not None:self.rows.append(self.row);self.row=None
    def handle_data(self,data):
        if not self.skip:self.text.append(data)
        if self.cell is not None:self.cell.append(data)

hp,hb=raw(P/'exact-evidence.html');s=hb.decode()
need('exact rendered report pin',hp==dict(path=str(P/'exact-evidence.html'),sha256='7939f8982493447aa879b361238c8447c1b9eede0fbeef4d60c48e43fe6b6842',bytes=31215))
page=Page();page.feed(s);text=' '.join(page.text)
need('HTML ID uniqueness',len(page.ids)==len(set(page.ids)))
need('no invalid C0 in report',not any(ord(c)<32 and c not in '\t\n\r'for c in s))
need('no unresolved report tokens','@@'not in s)
need('math renderer and established inline delimiters',"mathjax@3/es5/tex-chtml.js"in s and "inlineMath:[['\\\\(','\\\\)']]"in s)
visible=''.join(page.text)
need('visible inline LaTex pairs balanced',visible.count(r'\(')==visible.count(r'\)') and visible.count(r'\[')==visible.count(r'\]'))
need('no substituted math Unicode glyphs',not any(c in visible for c in '⇒∀∃∧∨≤≥∑'))
summarypin,summary=load(P/'exact-evidence-summary.json')
admitpin,admit=load(P/'exact-evidence-admission.json')
peerpin,peer=load(P/'exact-evidence-peer-review.json')
failurepin,failure=load(P/'exact-evidence-result.json')
rootpin,root=load(D/'ROOT-final-audit-v5.json')
ownpin,own=load(Q/'typed-second-qualification-saved-review-v5.json')
fp,f=load(D/'actual-v5'/'worker-failure.json');rp,r=load(D/'actual-v5'/'runner-receipt.json')
op,o=load(D/'actual-v4'/'worker-failure.json');oldpin,old=load(D/'ROOT-negative-audit-v1.json')
tp,t=load(D/'plan-authorized-v5-terminal-observation'/'terminal.json')
pp,plan=load(D/'plan-authorized-v5.json')
need('published Root audit literal complete',admit==root)
need('published independent audit literal complete',peer==own)
need('published full failure packet whole bytes',failurepin['sha256']==fp['sha256'] and failurepin['bytes']==fp['bytes'] and failure==f)
need('summary negative outcome exact',summary['status']==f['status']=='UNKNOWN_EVIDENCE_LIMIT' and summary['representation_admitted'] is False and summary['resource_admitted'] is False)
need('summary completed0 and whole selected3',summary['completed_independent_input_packets']==summary['completed_diagnostics']==0 and summary['original_complete_input_count']==3 and summary['whole_original_input_bytes']==sum(x['input']['bytes']for x in plan['inputs'])==38397056)
need('summary partial bytes distinct from complete',summary['encoded_complete_table_bytes'] is None and summary['encoded_table_prefix_bytes']==f['aggregate_encoded_table_prefix_bytes']==15096899)
need('summary current terminal/peak scalar joins',summary['terminal_seconds']==t['runner_clock_seconds']==112.052782959 and summary['worker_peak_bytes']==r['worker_wait4_usage']['ru_maxrss']==656310272)
need('summary earlier timeout exact',summary['earlier_attempt']==dict(status=old['status'],representation_admitted=False,terminal_seconds=old['failure_terminal_seconds'],worker_peak_bytes=old['worker_peak_bytes'],reached_context=old['reached_context']))
for key in ['mathematical_proof_accepted','new_target_theorem','Model_permission','schema_inventory_admission','RL_training','goal_complete']:
    need('summary no authority '+key,summary[key] is False)
need('summary no scientific calls',summary['Native_calls']==summary['search_calls']==0)

marker='const saved=';start=s.index(marker)+len(marker)
packets,end=json.JSONDecoder().raw_decode(s[start:])
need('embedded packet JSON terminated as data',s[start+end:].startswith(';\nconst esc='))
need('no unexecuted typed graph packet',packets['typed_fixture'] is None)
expected=[('Current whole-run outcome',summary),('Current complete result or failure',f),('Current resource receipt',r),('Earlier attempt: UNKNOWN, preserved',o),('Root saved-data audit',root),('Independent saved-data audit',own)]
need('six complete embedded entries exact',packets['entries']==[dict(label=label,packet=value)for label,value in expected])
need('viewer uses textContent only for packets',"document.querySelector('#packetBody').textContent=JSON.stringify(e.packet,null,2)"in s)
need('embedded JSON escapes HTML open characters','<'not in s[start:start+end])
need('no empirical diagram invented',packets['typed_fixture'] is None and 'Neither attempt reaches this state.'in text and 'No materialization diagnostic returned in either actual.'in text)
expected_rows=[
 ['Artifact','Ordinary bytes','Table bytes','Immutable nodes','Independent full inverse'],
 ['full-base-control',r'\(36,481,858\)',r'\(15,096,899\)','Not qualified','Not returned'],
 ['full-shadow-packets',r'\(1,547,291\)','Not retained','Not qualified','Not returned'],
 ['full-prior-case002',r'\(367,907\)','Not retained','Not qualified','Not returned'],
 ['Variant','Whole input packets','Diagnostics','Observed terminal','Worker peak','Outcome'],
 ['Original checkpoint dispatch',r'\(0\)',r'\(0\)',r'\(180.067\,\mathrm{s}\)',r'\(691.42\,\mathrm{MiB}\)','UNKNOWN at work deadline'],
 ['Weighted checkpoint dispatch',r'\(0\)',r'\(0\)',r'\(112.053\,\mathrm{s}\)',r'\(625.91\,\mathrm{MiB}\)','UNKNOWN_EVIDENCE_LIMIT']]
need('all displayed table cells exact',page.rows==expected_rows)
need('table roundings old/new raw metadata',f"{old['failure_terminal_seconds']:.3f}"=='180.067' and f"{old['worker_peak_bytes']/1048576:.2f}"=='691.42' and f"{summary['terminal_seconds']:.3f}"=='112.053' and f"{summary['worker_peak_bytes']/1048576:.2f}"=='625.91')
need('both terminal clocks precise and start scoped','timestamp immediately after importing'in text and 'Runner interpreter startup and the outer observer’s prelude precede that gated epoch.'in text and r'\(112.074238167\,\mathrm{s}\)'in text and 'excludes the observer’s own interpreter/module startup'in text)
need('observer main exact elapsed literal',(t['terminal_ns']-t['started_ns'])/1e9==112.074238167)
need('standalone profile numeric math exact',all(x in text for x in [r'\(180\,\mathrm{s}\)',r'\(210\,\mathrm{s}\)',r'\(1\,\mathrm{GiB}\)',r'\(128\,\mathrm{MiB}\)']))
need('RAM is standalone charged worker scope','excludes the outer observer/controller'in text and 'cannot establish a reduction in integrated GCTS memory'in text and 'No Native process exists in this specialized profile.'in text)
need('both caps and accounting distinction explicit','aggregate encoded outputs and expanded input data'in text and 'Any changed interpretation requires a clearly declared representation profile.'in text)
need('separate failures no qualification claim','Both attempts remain UNKNOWN; neither qualifies the representation.'in text and 'No complete input packet or diagnostic returns.'in text and 'table is retained as unqualified evidence'in text)
need('cadence and guard observation caveats','neither a hard elapsed-time interruption guarantee nor a bound on actual processing between callbacks'in text and 'Source custody checks still depend on callback count.'in text and 'pair does not establish a causal speedup'in text)
need('malformed fixtures explicitly unexecuted','their authored diagnostics remain unexecuted in these two runs'in text)
need('trust limits visible','Initial exclusive ownership and the pinned Python/stdlib/OS remain trusted assumptions.'in text)
need('same reviewer roles visible','Both Source and plan review roles use this one reviewer identity.'in text)
need('schema proof authority preserved','cannot activate the schema gate'in text and 'The two output-and-RAM failures remain failed.'in text and 'old acceptance is not reused as a new proof-search result'in text)
need('next design distinct profile not false old pass','Fragment reuse changes the actual operations charged by the private work counter'in text and 'cannot be described as passing the old inverse’s work-unit profile'in text and 'This remains a source-only proposal; no third run is admitted here.'in text)
need('no proof or RL advantage claims','does not qualify them.'in text and 'broader research goal remains active'in text)

readerpin,readerbytes=raw(P/'reader.html');reader=readerbytes.decode()
match=re.search(r'<section id="exact-evidence">.*?</section>',reader,re.S)
need('one own reader lead section',len(re.findall(r'<section id="exact-evidence">',reader))==1 and match is not None)
need('reader lead current negative scope','Both attempts remain UNKNOWN; neither qualifies the representation.'in match.group() and 'adds no theorem, RL training or search-speed claim'in match.group())
link_results=[]
for href in page.links:
    u=urlsplit(href)
    if u.scheme or u.netloc:continue
    target=(P/unquote(u.path)).resolve() if u.path else P/'exact-evidence.html'
    present=target.is_file();need('local target exists '+href,present)
    fragment_ok=True
    if u.fragment:
        parsed=Page();parsed.feed(target.read_text());fragment_ok=unquote(u.fragment)in parsed.ids;need('local fragment exists '+href,fragment_ok)
    link_results.append(dict(href=href,target=str(target),fragment_present=fragment_ok))

builderpin,builder=raw(D/'build_report_v2.py');tree=ast.parse(builder)
imports=[]
for node in ast.walk(tree):
    if isinstance(node,ast.Import):imports.extend(a.name for a in node.names)
    if isinstance(node,ast.ImportFrom):imports.append(node.module)
need('report builder imports only expected stdlib',set(imports)=={'pathlib','hashlib','html','json','re','zipfile'})
need('report builder no target import/evaluation',not any(isinstance(n,ast.Call)and isinstance(n.func,ast.Name)and n.func.id in {'eval','exec','__import__','compile'}for n in ast.walk(tree)))
manifestpin,manifest=load(P/'exact-evidence-manifest.json')
need('interim manifest binds main report',hp in manifest['published'])
need('interim manifest no scientific authority',manifest['saved_data_only'] is True and manifest['codec_or_inverse_calls']==0 and manifest['goal_complete'] is False)

audit=save('generated-report-scope-audit-v2.json',dict(schema='exact-evidence-report-scope-audit-v1',saved_data_only=True,source_only=True,scientific_calls=0,codec_calls=0,inverse_replays=0,renderer_evaluations=0,actual_execution_authorized=False,checks=checks,check_count=len(checks),mismatch_count=0,raw_pins=list(pins.values()),local_links=link_results,table_cells=page.rows,embedded_packet_labels=[x[0]for x in expected],archive_scope='Interim archive exists but its final contents/pin may change to add Source-only next design and final reviews; no final ZIP/member audit in this report-scope receipt.'))
receipt=save('typed-report-scope-review-v2.json',dict(schema='exact-evidence-human-report-scope-review-v1',report_scope_review_passed=True,human_report_review_passed=True,author_identity='/root',reviewer_identity='/root/conventional_control_review',saved_data_only=True,source_only=True,scientific_calls=0,codec_calls=0,inverse_replays=0,renderer_evaluations=0,module_evaluations=0,scientific_acceptance=False,actual_execution_authorized=False,report=hp,reader=readerpin,summary=summarypin,published_Root_audit=admitpin,published_peer_audit=peerpin,published_failure_packet=failurepin,Root_original_audit=rootpin,independent_saved_audit=ownpin,report_builder_Source=builderpin,interim_manifest=manifestpin,audit=audit,check_count=len(checks),mismatch_count=0,findings=[],corrected_preflight_finding='The earlier template omitted the clock epoch distinction. Final V2 explicitly defines runner Source entry, excludes its interpreter startup/observer prelude, separately states observer-main112.074238167s and excludes observer own startup. No numeric outcomes changed.',conclusions=[
 'The exact negative report and own reader section correctly show selected3/completed0/fixtures0, no graph from an unexecuted fixture, the first timeout and current private-inverse work UNKNOWN. All displayed byte/time/peak cells and all six embedded saved packets join literally to current evidence.',
 'The mechanism is described as reviewed Source with exclusive-owner/runtime caveats; absent materialization and malformed-wire diagnostics are explicitly unexecuted. Resource costs and clock scopes are accurate, neither attempt is qualified, and no proof/Model/schema/RL/GCTS or causal speed advantage is implied.',
 'The proposed fragment-reuse work remains unimplemented and requires a versioned actual-operation accounting profile, fresh review and qualification; it cannot retroactively pass the old inverse quota or weaken old expanded-byte guards.'
],release_conditions=[
 'Root must freeze the final Source-only design artifact, final archive/member manifest and all whole raw object pins after packaging, preserving both negative attempts and all three complete original input files; no missing failed output recovery or old table cache.',
 'Any final archive/manifest-only delta must leave reviewed main HTML, current own reader section and literal published packets unchanged, or request a bounded successor review. This receipt does not certify an as-yet-changing ZIP.',
 'Root remains responsible for final task-only publication, local navigation/full-object archive checks and live browser/HTTP/MathJax validation. Static review is not a rendered UI check.'
],limitations=[
 'No builder/renderer/JavaScript/codec/inverse/fixture or scientific module was executed. HTML parsing, literal JSON parsing of saved report packets, raw hashing and AST import inspection only. Encoded evidence tables and opaque Native data were not decoded.',
 'Control authored none of the five current exact-evidence components, but authored older scientific/control/outer Sources and both current Source/plans reviews. This reviews Root presentation and saved joins; it does not establish universal codec correctness, independent mathematical-kernel soundness or a fair pipeline benchmark.'
]))
handoff=save('report-scope-peer-handoff-v2.json',dict(schema='exact-evidence-report-scope-handoff-v1',receipt=receipt,audit=audit,report_scope_review_passed=True,scientific_calls=0,actual_execution_authorized=False))
print(json.dumps(dict(receipt=receipt,audit=audit,handoff=handoff,check_count=len(checks)),sort_keys=True))
