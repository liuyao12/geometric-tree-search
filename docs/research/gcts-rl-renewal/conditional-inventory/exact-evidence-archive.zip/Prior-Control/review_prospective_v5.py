"""Retained ordinary metadata / raw pin audit only. No target imports or calls."""
from pathlib import Path
import hashlib
import json
import os
import stat

D = Path('/private/tmp/gcts-exact-evidence-ROOT-20261019')
P = Path('/private/tmp/gcts-exact-evidence-peer-20261019')
checks = []
raw_pins = {}

def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()

def need(label, condition, detail=None):
    checks.append(dict(label=label, passed=bool(condition), detail=detail))
    if not condition:
        raise AssertionError(label)

def raw_descriptor(path):
    path = Path(path)
    before = path.stat()
    need('regular raw file: ' + str(path), stat.S_ISREG(before.st_mode))
    data = path.read_bytes()
    after = path.stat()
    signature = lambda s: (s.st_dev, s.st_ino, s.st_mode, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
    need('stable raw read: ' + str(path), signature(before) == signature(after) and len(data) == after.st_size)
    descriptor = dict(path=str(path), sha256=hashlib.sha256(data).hexdigest(), bytes=len(data))
    raw_pins[str(path)] = descriptor
    return descriptor, data

def pin(descriptor):
    need('descriptor shape: ' + descriptor['path'], set(descriptor) == {'path', 'sha256', 'bytes'} and type(descriptor['bytes']) is int and descriptor['bytes'] >= 0)
    actual, data = raw_descriptor(descriptor['path'])
    need('whole raw descriptor: ' + descriptor['path'], actual == descriptor)
    return data

def load(path):
    descriptor, data = raw_descriptor(path)
    return descriptor, json.loads(data)

def write(name, value):
    path = P / name
    if path.exists():
        raise AssertionError('peer output already exists: ' + name)
    path.write_bytes(json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False).encode() + b'\n')
    return dict(path=str(path), sha256=hashlib.sha256(path.read_bytes()).hexdigest(), bytes=path.stat().st_size)

index_descriptor, index = load(D / 'prospective-index-v5.json')
need('exact index pin', index_descriptor == dict(path=str(D/'prospective-index-v5.json'), sha256='247b12c718acfa5ec2ec5cfdf59054ddc1c167182ca06356fa7421d4428a1e9f', bytes=6502))
plan = json.loads(pin(index['plan_draft']))
auth = json.loads(pin(index['authorization_draft']))
declaration = json.loads(pin(index['declaration']))
contract = json.loads(pin(index['Root_Source_contract']))
source_descriptor, source_review = load(P / 'typed-components-Source-review-v5.json')
need('exact current component review pin', source_descriptor == dict(path=str(P/'typed-components-Source-review-v5.json'), sha256='ac59aec4aacb73c623e926c97011c35c3f23b52cda80eace368a1608b72cb574', bytes=6905))
old_index_descriptor, old_index = load(D / 'prospective-index-v4.json')
old_declaration = json.loads(pin(old_index['declaration']))
old_source_descriptor, old_source = load(P / 'typed-components-Source-review-v4.json')
negative_descriptor, negative = load(P / 'typed-first-qualification-negative-review-v1.json')

subject = {key: value for key, value in plan.items() if key != 'authorization'}
subject_fields = {'schema', 'invocation_id', 'actual_directory', 'python', 'worker', 'encoder', 'inverse', 'runner', 'observer', 'inputs', 'limits', 'declaration'}
need('exact full plan fields13', set(plan) == subject_fields | {'authorization'} and len(plan) == 13)
need('exact subject fields12', set(subject) == subject_fields and len(subject) == 12)
need('full literal subject matches index', subject == index['subject'])
subject_sha = hashlib.sha256(canonical(subject)).hexdigest()
need('exact canonical twelve-field subject hash', subject_sha == index['subject_sha256'] == 'e4c68e11882f9c4505f92874beb340c653f1b119c0f9468fadaf6b709a8ce4cd')
need('subject excludes authorization only', plan['authorization'] == index['authorization_draft'])
need('current declaration subject binding', subject['declaration'] == index['declaration'])
need('plan schema unchanged', subject['schema'] == 'exact-evidence-once-plan-v1' == old_index['subject']['schema'])
need('new exact invocation ID', subject['invocation_id'] == 'exact-evidence-whole-artifacts-ROOT-20261019-v5' and subject['invocation_id'] != old_index['subject']['invocation_id'])
need('new exact actual directory', subject['actual_directory'] == str(D/'actual-v5') and subject['actual_directory'] != old_index['subject']['actual_directory'])
need('false index author and scope', index['author_identity'] == '/root' and index['source_only'] is True and type(index['scientific_calls']) is int and index['scientific_calls'] == 0 and index['actual_execution_authorized'] is False and type(index['maximum_actual_invocations']) is int and index['maximum_actual_invocations'] == 0)
need('exact false auth fields7', set(auth) == {'schema','author_identity','actual_execution_authorized','maximum_actual_invocations','subject_sha256','review_roles','scope'})
need('false auth no launch permission', auth['schema'] == 'exact-evidence-once-authorization-v1' and auth['author_identity'] == '/root' and auth['actual_execution_authorized'] is False and type(auth['maximum_actual_invocations']) is int and auth['maximum_actual_invocations'] == 0 and auth['review_roles'] == {} and auth['subject_sha256'] == subject_sha)

limits = dict(work_seconds=180, overall_seconds=210, memory_bytes=1073741824, result_bytes=134217728, expanded_bytes=134217728, stdout_bytes=4194304, stderr_bytes=4194304)
need('exact numeric limits with strict integers', subject['limits'] == limits and all(type(v) is int for v in subject['limits'].values()))
need('numeric limits unchanged from V4', limits == old_index['subject']['limits'] == declaration['limits'] == old_declaration['limits'])
need('exact source role set5', set(index['current_sources']) == {'encoder','inverse','worker','runner','observer'})
need('all current Source maps agree', index['current_sources'] == declaration['current_sources'] == contract['current_sources'] == source_review['sources'])
for role, descriptor in index['current_sources'].items():
    need('plan Source binding: '+role, subject[role] == descriptor)
    pin(descriptor)
    need('four Root files unchanged: '+role, role == 'encoder' or descriptor == old_index['current_sources'][role])
need('only encoder Source descriptor changed', {k for k in index['current_sources'] if index['current_sources'][k] != old_index['current_sources'][k]} == {'encoder'})
need('Python unchanged', subject['python'] == old_index['subject']['python'])
pin(subject['python'])
need('exact current Source receipt schema/pass', source_review['schema'] == 'exact-evidence-components-Source-review-v1' and source_review['source_review_passed'] is True)
need('Source author/reviewer identities disclosed', source_review['author_identities'] == ['/root','/root/conventional_library'] and source_review['reviewer_identity'] == '/root/conventional_control_review')
need('Source receipt no execution authority', source_review['source_only'] is True and source_review['scientific_calls'] == 0 and source_review['scientific_acceptance'] is False and source_review['actual_execution_authorized'] is False)
need('current contract subject in Source review', source_review['source_contract'] == index['Root_Source_contract'])

need('all three whole inputs/order unchanged', subject['inputs'] == index['original_complete_inputs'] == declaration['inputs'] == old_index['original_complete_inputs'] == old_index['subject']['inputs'])
need('exact three original input IDs', [row['id'] for row in subject['inputs']] == ['full-base-control','full-shadow-packets','full-prior-case002'])
for row in subject['inputs']:
    need('complete ordinary data input kind: '+row['id'], set(row) == {'id','input','kind'} and row['kind'] == 'complete_ordinary_saved_JSON')
    pin(row['input'])
need('whole original aggregate bytes', sum(row['input']['bytes'] for row in subject['inputs']) == declaration['aggregate_whole_raw_input_bytes'] == 38397056 < limits['expanded_bytes'])
need('failed table is not an input/cache', all('actual-v4' not in row['input']['path'] and '-table.json' not in row['input']['path'] for row in subject['inputs']) and not any('cache' in k.lower() or 'resume' in k.lower() for k in plan))
need('subject deltas bounded to variant metadata and encoder', {k for k in subject if subject[k] != old_index['subject'][k]} == {'invocation_id','actual_directory','encoder','declaration'})

need('declaration and contract matching pin', declaration['Root_Source_contract'] == index['Root_Source_contract'])
need('declaration is explicitly Source only and unimplemented', declaration['source_only'] is True and declaration['scientific_calls'] == 0 and declaration['actual_execution_authorized'] is False and declaration['unimplemented_integration'] is True and declaration['no_new_logical_authority'] is True and declaration['goal_complete'] is False)
need('no RL or recursive proposal factor', declaration['new_RL_training'] is False and declaration['recursive_proposer_enabled'] is False)
need('same existing48 fixture declaration', '48fixtures' in declaration['variant'] and declaration['fixture_scope'] == old_declaration['fixture_scope'])
need('complete old timeout retained', declaration['prior_attempt'] == contract['prior_complete_qualification_negative'])
pin(declaration['prior_attempt'])
need('independent old timeout retained', contract['prior_independent_negative'] == negative_descriptor)
need('old timeout is not admitted', negative.get('scientific_acceptance') is False and negative.get('actual_execution_authorized') is False)
need('cadence-only profile exact', contract['encoder_execution_profile'] == 'exact-evidence-table-weighted-checkpoint-batch-v2')
need('weighted quantum and upfront bulk scope explicit', 'quantum1024' in contract['checkpoint_scope'] and 'upfront' in contract['checkpoint_scope'] and '4096-character' in contract['checkpoint_scope'])
need('no processing/elapsed callback bound claimed', 'not a bound on actual processing units or elapsed time' in contract['checkpoint_scope'])
need('Sourceguard frequency trust limit explicit', 'once per32768 callback invocations' in contract['checkpoint_scope'] and 'no continuous code-seal guarantee' in contract['checkpoint_scope'])
need('both numeric cap interpretations remain explicit', 'Aggregate3encoded table files+summary result <=128MiB' in declaration['output_scope'] and 'aggregate fully expanded original canonical files <=128MiB' in declaration['output_scope'])
need('same reviewer two-role disclosure', 'Same Control identity fills Source and plans roles; not two independent people.' in declaration['trust'])
need('standalone cost distinct from search pipeline', 'specialized representation-only profile without Native/search/Model lifetimes' in declaration['resource_scope'] and 'Do not compare this RAM with integrated search workers' in declaration['resource_scope'])
need('no speculative performance/fit premise', any('No speed, compression ratio or memory fit' in item for item in contract['limitations']))
for key in ['Encoder_API','Encoder_Source_contract','independent_obligations','inverse_custody_negative_v1','inverse_v2_delta','prior_complete_qualification_negative','prior_independent_negative']:
    pin(contract[key])

fresh_paths = [D/'actual-v5',D/'actual-v5'/'CONSUMED.json',D/'authorization-v5.json',D/'authorized-index-v5.json',D/'plan-authorized-v5.json',D/'plan-authorized-v5-terminal-observation',D/'plan-draft-v5-terminal-observation']
for path in fresh_paths:
    need('current fresh absence: '+str(path), not os.path.lexists(path))
need('prior actual remains separately retained', (D/'actual-v4').is_dir() and (D/'ROOT-negative-audit-v1.json').is_file())

audit = dict(schema='exact-evidence-prospective-raw-metadata-audit-v1', author_identity='/root', reviewer_identity='/root/conventional_control_review', source_only=True, scientific_calls=0, codec_calls=0, fixture_calls=0, module_evaluations=0, actual_execution_authorized=False, prospective_index=index_descriptor, subject=subject, subject_sha256=subject_sha, checks=checks, check_count=len(checks), mismatch_count=0, raw_pins=list(raw_pins.values()), raw_pin_count=len(raw_pins), fresh_absent_paths=[str(p) for p in fresh_paths], note='Input payloads were whole raw-hashed only; no scientific or codec decoding/evaluation. Existing V4 timeout remains non-admitted.')
audit_descriptor = write('prospective-raw-plan-audit-v5.json', audit)
receipt = dict(schema='exact-evidence-prospective-plan-review-v1', author_identity='/root', reviewer_identity='/root/conventional_control_review', prospective_review_passed=True, source_only=True, scientific_calls=0, scientific_acceptance=False, actual_execution_authorized=False, codec_calls=0, fixture_calls=0, module_evaluations=0, prospective_index=index_descriptor, plan_draft=index['plan_draft'], authorization_draft=index['authorization_draft'], declaration=index['declaration'], source_contract=index['Root_Source_contract'], Source_review=source_descriptor, sources=index['current_sources'], Python=subject['python'], complete_inputs=subject['inputs'], subject=subject, subject_field_count=12, subject_sha256=subject_sha, limits=limits, prior_negative=negative_descriptor, audit=audit_descriptor, check_count=len(checks), raw_pin_count=len(raw_pins), mismatch_count=0, findings=[], conclusions=[
    'The fresh V5 twelve-field subject and full false plan bind the current five exact Sources, unchanged pinned Python, all three original complete inputs/order and all numeric caps. Only invocation/path/declaration and encoder differ from V4; authorization is false/max0/empty roles.',
    'The encoder cadence is an explicitly different engineering variant. Weighted scheduled charges and upfront bulk callbacks do not bound actual processing or elapsed time; Root callback-count guard observation frequency changes. Four Root Sources and every structural/quota/completion body are separately Source-reviewed unchanged.',
    'The original timeout, incomplete table and failed representation/resource admission remain retained. No failed table or partial input is reused. Both encoded tables plus result and full expanded originals retain separate aggregate128MiB gates.',
    'This Source-only metadata receipt gives no execution or representation admission. Exact true/max1 grant binding current Source receipt and this full subject/declaration, a final delta/freshness review and all-agents-idle window remain prerequisites.'
], limitations=[
    'Only ordinary saved JSON metadata, raw file bytes and filesystem state were inspected. No codec/inverse/fixture/project/scientific/worker/runner/observer functions or input mathematical payloads were evaluated or replayed.',
    'Pinned Python, bundled stdlib/loader/OS, exclusive input/callback ownership and bounded-input scalar operations remain trusted. No formal continuous seal, hard callback latency, arbitrary hostile-object guarantee, memory fit or cleanup theorem is established.',
    'The same Control reviewer fills Source and plans roles; these are distinct scopes, not two independent people. Library and Root authored all five current Sources. Older Control-authored scientific/outer components are not imported or independently self-certified here.',
    'The standalone combined full-input qualification costs are not a full scientific pipeline comparison. No future integration permission, proof/Model/schema admission, new theorem, RL, geometry or causal speedup claim follows from this plan review.',
    'All three complete comparisons and all48 declared finite fixtures must actually complete under every profile gate before a positive representation qualification. Failure prefixes and published table existence do not substitute for completion; prospective tests do not establish universal correctness.'
])
receipt_descriptor = write('typed-prospective-plan-review-v5.json', receipt)
handoff = write('prospective-peer-handoff-v5.json', dict(schema='exact-evidence-prospective-peer-handoff-v1', receipt=receipt_descriptor, audit=audit_descriptor, prospective_review_passed=True, scientific_calls=0, scientific_acceptance=False, actual_execution_authorized=False))
print(json.dumps(dict(receipt=receipt_descriptor,audit=audit_descriptor,handoff=handoff,check_count=len(checks),raw_pin_count=len(raw_pins)),sort_keys=True))
