"""Saved ordinary metadata/raw bytes only; never import or call either codec."""
from pathlib import Path
import ast
import hashlib
import json
import os
import stat

D=Path('/private/tmp/gcts-exact-evidence-ROOT-20261019')
A=D/'actual-v5'
O=D/'plan-authorized-v5-terminal-observation'
P=Path('/private/tmp/gcts-exact-evidence-peer-20261019')
checks=[];pins={}
def need(label,condition,detail=None):
    checks.append(dict(label=label,passed=bool(condition),detail=detail))
    if not condition:raise AssertionError(label)
def canonical(value):return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def raw(path):
    path=Path(path);s=path.stat();need('regular file '+str(path),stat.S_ISREG(s.st_mode))
    b=path.read_bytes();t=path.stat()
    sig=lambda v:(v.st_dev,v.st_ino,v.st_mode,v.st_size,v.st_mtime_ns,v.st_ctime_ns)
    need('stable whole raw read '+str(path),sig(s)==sig(t) and len(b)==t.st_size)
    d=dict(path=str(path),bytes=len(b),sha256=hashlib.sha256(b).hexdigest());pins[str(path)]=d
    return d,b
def load(path):
    d,b=raw(path);return d,json.loads(b)
def checked(d):
    actual,b=raw(d['path']);need('whole pin '+d['path'],actual==d);return b
def save(name,value):
    path=P/name
    if path.exists():raise AssertionError('preserve existing '+str(path))
    path.write_bytes(json.dumps(value,ensure_ascii=False,sort_keys=True,indent=2,allow_nan=False).encode()+b'\n')
    b=path.read_bytes();return dict(path=str(path),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))

idxpin,idx=load(D/'authorized-index-v5.json')
need('authorized index exact pin',idxpin==dict(path=str(D/'authorized-index-v5.json'),sha256='9831690f7d94b6b4d506e39c3b5b33025906933e7036eb1a05fd3e45d9d3c49e',bytes=7420))
plan=json.loads(checked(idx['plan']));auth=json.loads(checked(idx['authorization']))
subject={k:v for k,v in plan.items() if k!='authorization'}
sha=hashlib.sha256(canonical(subject)).hexdigest()
need('exact full twelve-field current subject',len(subject)==12 and subject==idx['subject'] and sha==idx['subject_sha256']=='e4c68e11882f9c4505f92874beb340c653f1b119c0f9468fadaf6b709a8ce4cd')
need('true Root grant maxone',auth['author_identity']=='/root' and auth['actual_execution_authorized'] is True and type(auth['maximum_actual_invocations']) is int and auth['maximum_actual_invocations']==1 and auth['subject_sha256']==sha and plan['authorization']==idx['authorization'])
need('two current roles exactly',auth['review_roles']==idx['review_roles'] and set(auth['review_roles'])=={'Source','plans'})
reviews={role:json.loads(checked(d)) for role,d in auth['review_roles'].items()}
for role,r in reviews.items():
    need('review no execution authority '+role,r['source_only'] is True and r['scientific_calls']==0 and r['scientific_acceptance'] is False and r['actual_execution_authorized'] is False and r['reviewer_identity']=='/root/conventional_control_review')
need('current Source role exact fiveSubjects',reviews['Source']['source_review_passed'] is True and reviews['Source']['sources']==idx['current_sources'])
need('current plans role exact wholeSubject',reviews['plans']['prospective_review_passed'] is True and reviews['plans']['subject']==subject and reviews['plans']['subject_sha256']==sha and reviews['plans']['declaration']==subject['declaration'])
delta_pin,delta=load(P/'typed-final-grant-delta-review-v5.json')
need('final delta binds current index/subject',delta['final_grant_delta_review_passed'] is True and delta['authorized_index']==idxpin and delta['subject_sha256']==sha)

declaration=json.loads(checked(subject['declaration']))
contract=json.loads(checked(idx['Root_Source_contract']))
need('all current5 raw Sources match plan',idx['current_sources']==contract['current_sources']==declaration['current_sources'])
for role,d in idx['current_sources'].items():
    need('plan Source role '+role,subject[role]==d);checked(d)
checked(subject['python'])
need('complete original inputs unchanged',subject['inputs']==declaration['inputs']==idx['original_complete_inputs'] and [r['id']for r in subject['inputs']]==['full-base-control','full-shadow-packets','full-prior-case002'])
for row in subject['inputs']:checked(row['input'])
need('complete input aggregate exact',sum(r['input']['bytes']for r in subject['inputs'])==38397056==declaration['aggregate_whole_raw_input_bytes'])
limits=dict(work_seconds=180,overall_seconds=210,memory_bytes=1073741824,result_bytes=134217728,expanded_bytes=134217728,stdout_bytes=4194304,stderr_bytes=4194304)
need('original exact profile',plan['limits']==declaration['limits']==limits and all(type(v)is int for v in plan['limits'].values()))

cp,c=load(A/'CONSUMED.json');fp,f=load(A/'worker-failure.json');rp,r=load(A/'runner-receipt.json')
op,oc=load(O/'CONSUMED.json');tp,t=load(O/'terminal.json');clp,cl=load(D/'ROOT-cohort-closure-v5.json')
need('exact actual directory plan binding',str(A)==subject['actual_directory'])
need('single worker consumed matching plan/subject',c['schema']=='exact-evidence-consumed-v1' and c['plan']==idx['plan'] and c['subject_sha256']==sha and c['invocation_id']==plan['invocation_id'] and c['maximum_worker_launches']==1 and c['consumed_before_Popen'] is True)
need('single observer consumed sameplan',oc['maximum_runner_launches']==1 and oc['plan']==idx['plan'] and oc['started_ns']==t['started_ns'])
need('runner full current joins',r['schema']=='exact-evidence-once-receipt-v1' and r['plan']==idx['plan'] and r['authorization']==idx['authorization'] and r['subject_sha256']==sha and r['invocation_id']==plan['invocation_id'] and r['consumed_marker']==cp and r['limits']==limits)
need('runner command isolated exact pinned worker',r['command']==[subject['python']['path'],'-I','-S','-B',subject['worker']['path'],idx['plan']['path']])
need('observer command isolated exact pinned runner',t['command']==[subject['python']['path'],'-I','-S','-B',subject['runner']['path'],idx['plan']['path']])
need('observer exact runner receipt join',t['schema']=='exact-evidence-terminal-observation-v1' and t['plan']==idx['plan'] and t['runner_receipt']==rp)
need('exact Source-entry absolute clock',c['began_ns']==r['began_ns'] and c['work_deadline_ns']==r['work_deadline_ns']==r['began_ns']+180000000000 and c['overall_deadline_ns']==r['overall_deadline_ns']==r['began_ns']+210000000000)
need('clock chronology from observer through known worker exit',oc['started_ns']<=r['began_ns']<r['worker_terminal_observed_ns']<=r['closed_ns']<=t['terminal_ns']<r['work_deadline_ns']<r['overall_deadline_ns'])
terminal_seconds=(t['terminal_ns']-r['began_ns'])/1e9
need('failure terminal scalar exact',terminal_seconds==t['runner_clock_seconds']==112.052782959)
need('one launched and known reaped worker',r['worker_launch_attempts']==1 and r['worker_pid']==68119 and r['owned_pgid']==68119 and r['worker_reaped'] is True)
need('worker exit distinct from runner',r['worker_wait4_status']==256 and os.waitstatus_to_exitcode(r['worker_wait4_status'])==r['worker_exit_code']==1 and t['runner_exit_code']==2 and t['runner_pid']==68118)
need('no signals and groups/logs closed',r['signals']==[] and r['owned_group_absent'] is True and r['regular_logs_closed'] is True)
need('saved exact OS closure supports known group absence',cl['worker_pid']==r['worker_pid'] and cl['owned_pgid']==r['owned_pgid'] and cl['runner_pid']==t['runner_pid'] and cl['worker_reaped'] is True and cl['killpg_zero_absent'] is True and cl['regular_logs_closed'] is True and cl['ps_matching_rows']==[])
need('worker peak exact and individually below cap',type(r['worker_wait4_usage']['ru_maxrss'])is int and r['worker_wait4_usage']['ru_maxrss']==656310272<limits['memory_bytes'])
need('retained worker CPU metadata nonnegative',r['worker_wait4_usage']['ru_utime']==106.296405 and r['worker_wait4_usage']['ru_stime']==3.060166)
need('all resource and representation candidates false',r['resource_candidate_accepted'] is False and r['representation_candidate'] is False and t['terminal_gate_passed'] is False)
need('no logical authority flags',r['Native_calls']==0 and r['Model_permission'] is False and r['mathematical_proof_accepted'] is False and r['scientific_acceptance'] is False and t['scientific_acceptance'] is False and t['mathematical_proof_accepted'] is False)
need('runner failure origin normal-exit refusal',r['errors']==[dict(type='ValueError',message='normal exact worker exit0')])

need('exact owned inverse UNKNOWN failure',f['schema']=='exact-evidence-worker-failure-v1' and f['status']=='UNKNOWN_EVIDENCE_LIMIT' and f['type']=='InverseLimit' and f['own_inverse_limit'] is True and f['own_codec_limit'] is False and f['limit']=={'reason':'work'} and f['message']=='work')
need('failure firstinput independent fullsaved stage',f['reached_context']==dict(stage='INDEPENDENT_FULL_SAVED_INVERSE',input='full-base-control',fixture=None))
need('no completed whole inputs or fixtures or result',f['completed_input_packets']==[] and f['completed_fixture_prefix']==[] and f['published_result_candidate'] is None and f['representation_accepted'] is False and f['scientific_acceptance'] is False)
need('dispatch callback count literal not work metric',type(f['callback_count_at_failure'])is int and f['callback_count_at_failure']==37775805)
need('prefix counters exact',f['aggregate_encoded_table_prefix_bytes']==15096899 and f['aggregate_expanded_input_prefix_bytes']==36481858)
need('only one retained published table',len(f['published_table_prefix'])==1)
table=f['published_table_prefix'][0]
need('retained table exact whole pin',table==dict(path=str(A/'full-base-control-table.json'),sha256='8f67f39b299e0dd2a250352ebdf864be79a0c0defbb83b181353938bf77012d7',bytes=15096899))
checked(table) # Raw bytes/hash only. Deliberately do not parse this node table.
old_table_pin,_=raw(D/'actual-v4'/'full-base-control-table.json')
need('same table bytes digest across separately generated attempts',old_table_pin['sha256']==table['sha256'] and old_table_pin['bytes']==table['bytes'])
need('failed table not in new plan inputs',all(row['input']['path']!=table['path'] and 'actual-v4'not in row['input']['path'] for row in subject['inputs']))
need('actual file census complete',{p.name for p in A.iterdir()}=={'CONSUMED.json','full-base-control-table.json','runner-receipt.json','stderr.bin','stdout.bin','worker-failure.json'})
need('observer file census complete',{p.name for p in O.iterdir()}=={'CONSUMED.json','stderr.bin','stdout.bin','terminal.json'})
for name in ['result.json','worker-receipt.json','POST_RECEIPT_WORK_FAILURE.json','POST_RECEIPT_DEADLINE_FAILURE.json']:
    need('absent unreturned output/late marker '+name,not os.path.lexists(A/name))
for stream in ['stdout','stderr']:
    b=checked(r[stream]);need('bounded whole worker log '+stream,len(b)<=limits[stream+'_bytes'])
    if stream=='stderr':
        text=b.decode();need('saved traceback own inverse work stop',"independent_evidence_inverse_v3.py"in text and "InverseLimit: work"in text and "INDEPENDENT_FULL_SAVED_INVERSE"in text)
obsoutpin,obsout=raw(O/'stdout.bin');obserrpin,obserr=raw(O/'stderr.bin')
need('observer logs bounded and expected runner stdout',json.loads(obsout)==dict(actual=str(A),representation_candidate=False,resource_candidate_accepted=False) and obserr==b'' and len(obsout)<=limits['stdout_bytes'])

# Read the private static cap from Source AST only; never execute iter_inverse.
tree=ast.parse(Path(subject['inverse']['path']).read_text())
default=next(n.value for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name)and t.id=='DEFAULT_LIMITS'for t in n.targets))
need('inverse work cap unchanged Source literal',isinstance(default,ast.Call) and isinstance(default.func,ast.Name) and default.func.id=='dict' and next(k.value.value for k in default.keywords if k.arg=='work')==20000000)
need('worker only depth override leaves default work cap',b'INVERSE_LIMITS=dict(depth=513)'in Path(subject['worker']['path']).read_bytes())
rootpin,root=load(D/'ROOT-final-audit-v5.json')
need('Root audit exact pin',rootpin==dict(path=str(D/'ROOT-final-audit-v5.json'),sha256='bd93ebdae34833df8284a126ed5734c49dd9b4ca1531933205f4c61477aa8da1',bytes=2331))
need('separate Root conclusion consistent with independent joins',root['plan']==idx['plan'] and root['result_or_failure']==fp and root['runner']==rp and root['terminal']==tp and root['cohort_closure']==clp and root['subject_sha256']==sha and root['status']==f['status'] and root['terminal_seconds']==terminal_seconds and root['worker_peak_bytes']==r['worker_wait4_usage']['ru_maxrss'] and root['completed_diagnostics']==0 and root['completed_full_input_packets']==0 and root['representation_admitted'] is False and root['resource_admitted'] is False and root['proof_accepted'] is False and root['schema_inventory_admission'] is False and root['Model_permission'] is False)
prior_pin,prior=load(P/'typed-first-qualification-negative-review-v1.json')
need('prior timeout retained as non-admitted',prior['representation_accepted'] is False and prior['resource_accepted'] is False)

summary=dict(status=f['status'],reason='owned independent inverse private work quota',reached_context=f['reached_context'],completed_input_packets=0,completed_fixture_packets=0,published_unqualified_tables=1,callback_dispatches_at_failure=f['callback_count_at_failure'],inverse_private_work_cap_Source_literal=20000000,worker_exit_code=1,runner_exit_code=2,terminal_gate_passed=False,terminal_seconds_from_runner_Source_entry=terminal_seconds,observer_full_elapsed_seconds=(t['terminal_ns']-t['started_ns'])/1e9,worker_wait4_peak_bytes=r['worker_wait4_usage']['ru_maxrss'],worker_wait4_peak_MiB=r['worker_wait4_usage']['ru_maxrss']/1048576,worker_CPU_seconds=r['worker_wait4_usage']['ru_utime']+r['worker_wait4_usage']['ru_stime'],known_reaped=True,owned_group_absent=True,signals=[],representation_accepted=False,resource_accepted=False,scientific_acceptance=False)
audit=save('second-qualification-saved-audit-v5.json',dict(schema='exact-evidence-second-qualification-saved-audit-v1',saved_data_only=True,scientific_calls=0,codec_calls=0,inverse_replays=0,module_evaluations=0,actual_execution_authorized=False,checks=checks,check_count=len(checks),mismatch_count=0,raw_pins=list(pins.values()),summary=summary))
receipt=save('typed-second-qualification-saved-review-v5.json',dict(schema='exact-evidence-second-qualification-saved-review-v1',saved_evidence_review_passed=True,negative_evidence_review_passed=True,author_identity='/root',reviewer_identity='/root/conventional_control_review',saved_data_only=True,source_only=True,scientific_calls=0,codec_calls=0,inverse_replays=0,fixture_calls=0,module_evaluations=0,scientific_acceptance=False,actual_execution_authorized=False,representation_accepted=False,resource_accepted=False,authorized_index=idxpin,subject_sha256=sha,review_roles=auth['review_roles'],final_grant_delta=delta_pin,current_sources=idx['current_sources'],limits=limits,consumed_marker=cp,observer_consumed=op,whole_failure_packet=fp,runner_receipt=rp,terminal_observation=tp,Root_saved_cohort_closure=clp,Root_separate_saved_audit=rootpin,prior_negative=prior_pin,retained_unqualified_table=table,audit=audit,check_count=len(checks),mismatch_count=0,findings=[],summary=summary,conclusions=[
 'V5 was exactly once on the reviewed current subject. It stopped on a genuine owned independent-inverse work limit in the first full-base-control input, before a completed independent whole inverse, completed input packet or any fixture. Current Source literal leaves the independent work cap at20000000; saved failure does not expose its complete internal counter history.',
 'The retained table is whole raw-pinned and has the same size/digest as the older timeout artifact. It was not parsed, inverted or qualified by this audit and is not a new-input cache. No result.json or worker-receipt.json exists; no successful full qualification can be inferred from file existence or earlier reached stages.',
 'Worker exit1 and runner exit2 remain distinct; no signals were sent. Exact wait4, saved group-absence process observations and closed logs support terminal closure. Peak625.90625MiB and112.052782959s failure terminal are diagnostic resource observations, not positive resource/representation admission or proof timings.',
 'Both the earlier work-deadline attempt and this separate cadence variant remain non-admitted. The callback dispatch counts are not weighted work, unique data operations or evidence of a causal speed improvement. No scientific pipeline, schema inventory, Model, proof, pruning, RL or theorem authority is added.'
],limitations=[
 'Only saved ordinary metadata/logs and whole raw file hashes were inspected. Neither codec/inverse nor fixtures, Native/scientific modules, mathematical outputs, encoded node-table decoding, searches or proof checkers were executed/replayed.',
 'Current Source/Python raw pins match their plan descriptors at this audit; interrupted runs have no positive final endpoint/header receipt. Saved custody and exact OS closure observations are conditional on the reviewed runtime/OS/loader and exclusive-owner assumptions, not a continuous formal seal.',
 'Failure context and prefixes do not replace missing complete per-input comparisons or claim snapshots after every thrown operation. No independent full inverse result, complete input or finite fixture result is accepted.',
 'The single standalone worker peak excludes parent/observer memory and has no Native child. It is not a simultaneous live aggregate peak or fair full scientific-pipeline memory/speed measurement. No third actual, quota increase, retry or new implementation is authorized by this receipt.',
 'Control authored none of these five current components and independently reviewed Library/Root Source and Root-executed saved data. Older Control-authored scientific/control/outer ancestry remains separate; this is not independent mathematical-kernel soundness or universal codec correctness certification.'
]))
handoff=save('second-qualification-saved-peer-handoff-v5.json',dict(schema='exact-evidence-second-qualification-saved-handoff-v1',receipt=receipt,audit=audit,saved_data_only=True,scientific_calls=0,negative_evidence_review_passed=True,representation_accepted=False,resource_accepted=False,actual_execution_authorized=False))
print(json.dumps(dict(receipt=receipt,audit=audit,handoff=handoff,check_count=len(checks),summary=summary),sort_keys=True))
