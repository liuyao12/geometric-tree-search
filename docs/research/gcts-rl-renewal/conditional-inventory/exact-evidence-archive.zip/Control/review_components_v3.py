"""Static Source/AST/unused compile and inert text patches only. No target calls."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import subprocess

P=Path('/private/tmp/gcts-fragment-inverse-peer-20261019')
S=Path('/private/tmp/gcts-fragment-inverse-ROOT-source-20261019')
O=Path('/private/tmp/gcts-exact-evidence-ROOT-source-20261019')
checks=[];pins={};compiled=[];inert=[]
def need(label,value):
    checks.append(dict(label=label,passed=bool(value)))
    if not value:raise AssertionError(label)
def raw(path):
    path=Path(path);b=path.read_bytes();d=dict(path=str(path),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b));pins[str(path)]=d;return d,b
def load(path):
    d,b=raw(path);return d,json.loads(b)
def checked(d):
    a,b=raw(d['path']);need('whole raw pin '+d['path'],a==d);return b
def dumpast(s):return ast.dump(ast.parse(s),include_attributes=False)
def functions(s):
    return {n.name:(ast.get_source_segment(s,n),ast.dump(n,include_attributes=False))for n in ast.parse(s).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
def literal(s,name):
    n=next(n for n in ast.parse(s).body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id==name for t in n.targets))
    return ast.literal_eval(n.value)
def static_dict(s,name):
    n=next(n.value for n in ast.parse(s).body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id==name for t in n.targets))
    need('literal dict declaration '+name,isinstance(n,ast.Call)and isinstance(n.func,ast.Name)and n.func.id=='dict'and not n.args)
    return {k.arg:ast.literal_eval(k.value)for k in n.keywords}
def save(name,value):
    path=P/name
    if path.exists():raise AssertionError('preserve '+str(path))
    path.write_bytes(json.dumps(value,ensure_ascii=False,sort_keys=True,indent=2,allow_nan=False).encode()+b'\n')
    b=path.read_bytes();return dict(path=str(path),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))

cp,c=load(S/'Root-Source-contract-v3.json')
need('exact current contract',cp==dict(path=str(S/'Root-Source-contract-v3.json'),sha256='5101917e026e3f9a146efefd61327565c8ccb2c7e978f278c09803e0f4c472b7',bytes=13849))
sources=c['current_sources'];texts={role:checked(d).decode()for role,d in sources.items()}
need('five roles exact',set(sources)=={'encoder','inverse','worker','runner','observer'})
need('exact inverse pin',sources['inverse']==dict(path=str(S/'independent_evidence_inverse_v5.py'),sha256='218d380ebabac318d02057f2cddc3dd1aa12c8896eaddc0f28ca3908f521bb84',bytes=14033))
need('exact worker pin',sources['worker']==dict(path=str(S/'qualify_exact_evidence_worker_v11.py'),sha256='184bb9178572a474b0b9b1884cba71fab59ab3e5a63eca235509151e2ebc1c86',bytes=34251))
parentpin,parent=load('/private/tmp/gcts-exact-evidence-peer-20261019/typed-components-Source-review-v5.json')
for role in ['encoder','runner','observer']:need('retained exact reviewed component '+role,sources[role]==parent['sources'][role])
need('prior genuine conditional fiveSource pass',parent['source_review_passed'] is True and parent['source_only'] is True and parent['scientific_calls']==0)
imports=[]
for role,s in texts.items():
    tree=ast.parse(s)
    code=compile(tree,sources[role]['path'],'exec');del code
    compiled.append(dict(role=role,source=sources[role],code_evaluated=False))
    for n in ast.walk(tree):
        if isinstance(n,ast.Import):imports.extend(dict(role=role,line=n.lineno,name=a.name)for a in n.names)
        if isinstance(n,ast.ImportFrom):imports.append(dict(role=role,line=n.lineno,name=n.module))
    need('no eval/exec builtin '+role,not any(isinstance(n,ast.Call)and isinstance(n.func,ast.Name)and n.func.id in {'eval','exec','__import__'}for n in ast.walk(tree)))
need('whole AST stdlib import census exact',sorted(imports,key=lambda x:(x['role'],x['line'],x['name']))==sorted(c['import_census'],key=lambda x:(x['role'],x['line'],x['name'])))
need('inverse imports independent stdlib only',{x['name']for x in imports if x['role']=='inverse'}=={'json','math','re'})

iv=texts['inverse'];wv=texts['worker'];iv4=(S/'independent_evidence_inverse_v4.py').read_text();w9=(S/'qualify_exact_evidence_worker_v9.py').read_text();w10=(S/'qualify_exact_evidence_worker_v10.py').read_text();w8=(O/'qualify_exact_evidence_worker_v8.py').read_text()
normalized=iv.replace("VERSION='independent-evidence-inverse-v5-eager-bounds-call-local-fragments'","VERSION='independent-evidence-inverse-v4-call-local-fragments'").replace("            if sizes[i]>cap['expanded_bytes']:_stop('expanded bytes')\n",'')
need('inverse V1negative repair whole raw and AST only',normalized==iv4 and dumpast(normalized)==dumpast(iv4))
need('unchanged wire identity',literal(iv,'SCHEMA')=='exact-evidence-node-table-v1'and literal(iv,'WIRE_VERSION')=='exact-evidence-table-v1')
need('new operation profile explicit',literal(iv,'EXECUTION_PROFILE')=='independent-evidence-fragments-actual-operations-v4'and c['old_inverse_profile_pass'] is False)
caps=static_dict(iv,'DEFAULT_LIMITS')
need('unchanged numeric data/work limits and bounded optional cache',caps==dict(nodes=2000000,edges=8000000,depth=512,work=20000000,expanded_bytes=134217728,scalar_bytes=134217728,fragment_bytes=4096,cache_bytes=8388608,cache_entries=65536,chunk_bytes=65536))
need('worker depth convention unchanged',static_dict(wv,'ENCODER_LIMITS')==dict(max_depth=512)and static_dict(wv,'INVERSE_LIMITS')==dict(depth=513))
fn8=functions(w8);fnnew=functions(wv)
retained=[]
for name in fn8:
    if name=='main':continue
    need('old helper raw and AST retained '+name,fn8[name]==fnnew[name]);retained.append(name)
need('old helper count11 plus WorkDeadline class',len(retained)==12 and 'WorkDeadline'in retained)
names=literal(wv,'EXPECTED_FIXTURES');oldnames=literal(w9,'EXPECTED_FIXTURES')
need('all71 exact unique fixture names',len(names)==len(set(names))==71 and names[:48]==oldnames[:48] and len(names[48:])==23)
need('only added6case early boundary fixture to V9 names',[n for n in names if n not in oldnames]==['fragment_scalar_and_empty_container_early_bounds'])
v11normalized=wv.replace("VERSION='exact-evidence-qualification-worker-v4-fragment-inverse-caller-errors'","VERSION='exact-evidence-qualification-worker-v3-fragment-inverse-first-diagnostics'")
# The exact version literal is inspected below; normalize by the captured literal.
v11normalized=wv.replace('VERSION='+repr(literal(wv,'VERSION')),'VERSION='+repr(literal(w10,'VERSION')))
v11normalized=v11normalized.replace("            except BaseException as error:\n                if error is not marker:raise\n                caught=error","            except BaseException as error:caught=error")
need('worker V2negative repair whole raw and AST only',v11normalized==w10 and dumpast(v11normalized)==dumpast(w10))
main=fnnew['main'][0]
need('diagnostics FIRST then full original inputs',main.index("context.update(stage='DATA_FIXTURES'")<main.index("context.update(stage='FRAGMENT_DATA_FIXTURES'")<main.index("for item in plan['inputs']"))
need('71 exactsequence checked before inputs',main.index("need([f['name']for f in fixtures]==EXPECTED_FIXTURES,'complete exact71diagnostic sequence')")<main.index("for item in plan['inputs']"))
need('context reset for each original',"context.pop('inverse_statistics',None);context.update(stage='LOAD_INPUT',input=item['id'],fixture=None)"in main)
oldloop=next(n for n in ast.walk(ast.parse(functions(w9)['main'][0]))if isinstance(n,ast.For)and ast.get_source_segment(functions(w9)['main'][0],n.iter)=="plan['inputs']")
newloop=next(n for n in ast.walk(ast.parse(main))if isinstance(n,ast.For)and ast.get_source_segment(main,n.iter)=="plan['inputs']")
oldlooptext=ast.get_source_segment(functions(w9)['main'][0],oldloop)
newlooptext=ast.get_source_segment(main,newloop).replace("input=item['id'],fixture=None)","input=item['id'])")
need('full3input loop retained except context reset',oldlooptext==newlooptext)

properties=[
 ('strict complete wire/header/root','exact wire fields' in iv and "type(root)is int and root==len(source_nodes)-1"in iv),
 ('strict tags/scalars canonical types',all(s in iv for s in ["type(node[0])is str","type(value)is bool","canonical integer lexeme","canonical float lexeme","Unicode scalar string"])),
 ('full sorted keys and refs prior',"previous is None or previous<name"in iv and "type(ref)is int and 0<=ref<i"in iv),
 ('edge/depth/typednode checks',"stats['validated_edges']>cap['edges']"in iv and "height>cap['depth']"in iv and "duplicate complete typed node"in iv),
 ('owned immutable wire before cache',"nodes=tuple(owned);del source_nodes,owned,keys,node,wire"in iv),
 ('whole reverse reachability with ordered multiplicity',"_need(count>0,'unreachable table node')"in iv and "uses[ref]=min(overflow,uses[ref]+count)"in iv),
 ('overflow cannot admit saturated root',"if occurrence_sum>=overflow:_stop('expanded bytes')"in iv),
 ('independent length value recurrences',"size+=sizes[ref];count+=occurrences[ref]"in iv and "if tag=='object':size+=key_sizes[i][j]+1"in iv and "occurrences[root]==occurrence_sum"in iv),
 ('pernode eager scalar and empty-container size guard',"            if sizes[i]>cap['expanded_bytes']:_stop('expanded bytes')\n            occurrences.append(count)"in iv),
 ('UTF8 quoting length independent with bounded windows',"range(0,len(value),4096)"in iv and "token_bytes+=(2 if c in"in iv and "len(piece)==expected"in iv),
 ('repeated small node eligibility only',"uses[i]<2 or sizes[i]>cap['fragment_bytes']"in iv),
 ('capacity misses ordinary fallback not data discard',"stats['cache_capacity_fallbacks']+=1;continue"in iv),
 ('local immutable cache and fragment checks',"        cache={}"in iv and "cache[i]=bytes(fragment)"in iv and "len(fragment)==sizes[i]and values==occurrences[i]"in iv),
 ('bounded fragment preallocation',"len(fragment)+len(piece)<=sizes[i]"in iv),
 ('whole cached subtree occurrence contribution',"yield cache[at],occurrences[at]"in iv),
 ('fallback complete ordered object/array bytes',all(x in iv for x in ["if index:yield b',',0","yield tokenize(name,key_sizes[at][index]),0","yield b':',0","stack.append((child,-1))"])),
 ('bounded copied chunks with every byte cap',"take=min(cap['chunk_bytes']-len(pending),len(view)-offset)"in iv and "size=stats['stream_copied_bytes']+take"in iv and "if size>cap['expanded_bytes']:_stop('expanded bytes')"in iv),
 ('complete bytes occurrences and final callback',all(x in iv for x in ["stats['stream_copied_bytes']==sizes[root]","stats['stream_logical_occurrences']==occurrences[root]","tick('completion');stats['phase']='COMPLETE';stats['completed']=True"])),
 ('callback errors not caught by tick',"check()  # Exact delegated exceptions propagate"in iv and "if stats['actual_operations']>cap['work']:_stop('work')"in iv),
 ('owned limit private token',"type(error)is InverseLimit and error._owner is _LIMIT_TOKEN"in iv),
 ('observations not controlauthority',"statistics['phase']=stats['phase'];statistics['last_operation']=kind"in iv and "statistics.clear();statistics.update(stats)"in iv),
 ('cache payload not RAM guarantee','Payload cache cap excludes Python metadata/temporaries' in c['counter_scope']),
 ('whole full input bytecomparison nothashonly',"b==view[offset:offset+len(b)]"in wv and "offset==len(expected)-1"in wv),
 ('fullsaved wire reread and encoder revalidation',all(x in main for x in ["decoded=ordinary_load(raw(descriptor))","validated=codec.validate_wire(decoded,tick,ENCODER_LIMITS)","reread=compare_stream(codec.iter_expanded_canonical(validated,tick,ENCODER_LIMITS),original,tick)"])),
 ('observedgenerator closes before retained error',"try:independent=compare_stream(stream,original,tick)\n            finally:stream.close()"in main),
 ('completed perinput requires correct profile',"statistics['completed']is True and statistics['execution_profile']=='independent-evidence-fragments-actual-operations-v4'"in main),
 ('normalUNKNOWN owns exceptionorigin',"codec.is_own_limit(error)"in main and "inverse.is_own_limit(error)"in main and "type(error)is WorkDeadline"in main),
 ('all failure prefixes and current stats retained',all(x in main for x in ['reached_context=context','completed_input_packets=results','completed_fixture_prefix=fixtures','published_table_prefix=created_tables','published_result_candidate=result_descriptor'])),
 ('fullresult original caps and currentSource',"encoded+result_descriptor['bytes']<=plan['limits']['result_bytes']"in main and "expanded+=len(original)"in main),
 ('actualoperation oldprofile caveat emitted',"not a pass under oldV3 virtual-token-walk work units"in main),
 ('actual cache and mixed fallback fixtures assert paths',"stats['cache_hits_stream']>0"in fnnew['run_fragment_fixtures'][0] and "stats['cache_capacity_fallbacks']>0"in fnnew['run_fragment_fixtures'][0]),
 ('sixcase eager beforestream scope required',"context['inverse_statistics']['phase']=='INDEPENDENT_EXPANDED_SUMMARIES'"in wv and "all roots bounded before cache/stream"in wv),
 ('exact64unquoted integer boundary',"chunks==[17,17,17,13]"in wv and "integer body bound excludes nonexistent string quotes"in wv),
 ('noninitial delayed callback branch genuinely required',"need(reached and caught is marker and stats['completed']is False"in wv and "seen_cached_build"in wv and "first_returned"in wv),
 ('foreign callback faults reraised before fixturegate',"except BaseException as error:\n                if error is not marker:raise\n                caught=error"in wv),
 ('foreign sameclass limit remainsforeign',"not inverse.is_own_limit(caught)"in wv),
 ('current custody cadence disclosed','callback' in c['charge_table'] and "calls%32768==0:guard()"in main),
 ('Source profile global newfactor not silentoldpass',c['inverse_execution_profile']=='independent-evidence-fragments-actual-operations-v4' and c['old_inverse_profile_pass'] is False)
]
for label,value in properties:need(label,value)

# Genuine inert text patches: modify only VERSION in copied .raw.txt payloads.
for role in ['inverse','worker']:
    folder=P/('inert-v3-'+role);folder.mkdir(exist_ok=False)
    original=texts[role];oldversion=literal(original,'VERSION');changed=original.replace('VERSION='+repr(oldversion),'VERSION='+repr(oldversion+'-INERT-SOURCE-REVIEW'),1)
    need('inert version-only payload differs '+role,changed!=original)
    payload=folder/'payload.raw.txt';payload.write_text(original)
    for label,first,second in [('forward',original,changed),('reverse',changed,original)]:
        diff=folder/(label+'.diff');diff.write_text(''.join(difflib.unified_diff(first.splitlines(True),second.splitlines(True),fromfile='payload.raw.txt',tofile='payload.raw.txt')))
        result=subprocess.run(['/usr/bin/patch','-s','-p0','-i',str(diff)],cwd=folder,capture_output=True,text=True)
        need('actual inert patch '+role+' '+label,result.returncode==0 and payload.read_text()==second and dumpast(payload.read_text())==dumpast(second))
        inert.append(dict(role=role,direction=label,patch=raw(diff)[0],result_raw_sha256=hashlib.sha256(payload.read_bytes()).hexdigest(),target_functions_executed=False))
    need('inert restored original fullbytes '+role,payload.read_bytes()==original.encode())

obligationpin,_=load(P/'design-and-checking-obligations-v1.json')
negative1,_=load(P/'typed-components-Source-review-v1-negative.json');negative2,_=load(P/'typed-components-Source-review-v2-negative.json')
oldnegative1,_=load('/private/tmp/gcts-exact-evidence-peer-20261019/typed-first-qualification-negative-review-v1.json')
oldnegative2,_=load('/private/tmp/gcts-exact-evidence-peer-20261019/typed-second-qualification-saved-review-v5.json')
audit=save('five-Source-static-audit-v3.json',dict(schema='fragment-inverse-five-Source-static-audit-v1',source_only=True,scientific_calls=0,codec_calls=0,inverse_calls=0,fixture_calls=0,module_evaluations=0,scheduling_simulations=0,actual_execution_authorized=False,checks=checks,check_count=len(checks),mismatch_count=0,raw_pins=list(pins.values()),import_census=imports,retained_old_worker_functions=retained,expected_fixture_names=names,compile_without_evaluation=compiled,real_inert_patch_directions=inert,manual_review_scope='All inverseV5/workerV11 source paths, cache/summary/ordered-stream invariants and caller error/disposition coupling inspected. Compile produces discarded code objects only. No model, data inverse, fixture or input decoding performed.'))
receipt=save('typed-components-Source-review-v3.json',dict(schema='exact-evidence-components-Source-review-v1',source_review_passed=True,author_identities=['/root','/root/conventional_library'],reviewer_identity='/root/conventional_control_review',source_only=True,scientific_calls=0,codec_calls=0,inverse_calls=0,fixture_calls=0,module_evaluations=0,scientific_acceptance=False,actual_execution_authorized=False,sources=sources,source_contract=cp,independent_obligations=obligationpin,retained_component_review=parentpin,preserved_unexecuted_negatives=[negative1,negative2],preserved_actual_negatives=[oldnegative1,oldnegative2],execution_profile=c['inverse_execution_profile'],old_inverse_profile_pass=False,audit=audit,check_count=len(checks),mismatch_count=0,compile_without_evaluation=5,real_inert_patch_directions=4,expected_fixture_names=names,findings=[],conclusions=[
 'Full independent validation, owned immutable node capture, reverse reachability/multiplicity, independently reconciled canonical length/value summaries and bounded local fragments precede full ordinary output. Every cached occurrence is emitted; ineligible/full cache takes unchanged complete grammar fallback. Complete output bytes/value counts and completion callback are required.',
 'Unconditional per-node expanded bounds close the first unexecuted gap, including scalar/empty containers. Exact-object re-raise closes the delayed fixture error-origin gap. Both negative tuples remain preserved. The inverse numeric20m cap now counts newly declared actual-operation events and is not an oldV3 work-profile pass.',
 'All48 old diagnostic function code and eleven original worker helpers are raw/AST identical;23 new diagnostic names make71. Every diagnostic runs before all three original inputs. Positive worker completion still requires every71 name/status and all three complete full-byte comparisons plus original outer gates.',
 'Five sources compile without evaluation; four real inert patch directions restore full copied bytes/AST. Encoder and both launchers are exact retained reviewed bytes. No function, fixture, encoded table, Native or scientific module was evaluated.'
],limitations=[
 'Unformalized conditional Source review, not executed data qualification or universal codec correctness. Exact old48 tests and new23 are still prospective; actual saved admission must check all71 IDs/statuses and all3 complete inputs, not only generic launcher booleans.',
 'Finite delayed identity fixtures reach cached build and post-first-chunk stream copying. Completion/fallback exception propagation is reviewed directly in Source, not claimed dynamically tested at every possible late checkpoint. External WorkDeadline or unrelated errors are re-raised and retain their owner-origin disposition.',
 'Operation events count Source-level checks/windows/copies, not CPU instructions or old virtual subtree traversal. Scalar JSON/regex/hash/sort/tuple operations have bounded input and before/after checks, not hard continuous latency. Callback-count Sourceguard cadence and trusted Python/stdlib/OS/exclusive ownership remain conditional; no hostile-Python or formal continuous seal.',
 'Cache8MiB payload/65536entries/4096B fragments and64KiB chunks are optional storage bounds, not worker RAM limits. All setup/raw data/owned graph/cache/transients/fixtures/output/known exit remain charged under180/210/1GiB and BOTH128MiB aggregate byte gates. Cache may help nothing or add cost; no fit or causal speed claim.',
 'Observed statistics never control the inverse. Value counts describe complete pieces/summary contributions; an interrupted/closed stream is not a complete parsed output prefix or admitted result. Failed prefixes are retained without a promise of unreturned packet snapshots.',
 'Control authored none of these five current components; older own scientific/control/outer ancestry is disclosed, and retained component review is expressly relied on. This grants no Model/schema/Native/proof/RL/search/integration authority and authorizes no actual or grant.'
]))
handoff=save('Source-peer-handoff-v3.json',dict(schema='fragment-inverse-Source-peer-handoff-v1',receipt=receipt,audit=audit,source_review_passed=True,scientific_calls=0,actual_execution_authorized=False))
print(json.dumps(dict(receipt=receipt,audit=audit,handoff=handoff,check_count=len(checks)),sort_keys=True))
