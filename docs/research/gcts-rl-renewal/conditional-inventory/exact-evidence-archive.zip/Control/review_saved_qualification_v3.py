"""Saved ordinary packets/statistics and raw pin audit; no codec/inverse calls."""
from pathlib import Path
import ast
import hashlib
import json
import os

D=Path('/private/tmp/gcts-fragment-inverse-ROOT-20261019')
P=Path('/private/tmp/gcts-fragment-inverse-peer-20261019')
OLD=Path('/private/tmp/gcts-exact-evidence-ROOT-20261019')
A=D/'actual-v3';O=D/'plan-authorized-v3-terminal-observation'
checks=[];pins={}
def need(label,value):
    checks.append(dict(label=label,passed=bool(value)))
    if not value:raise AssertionError(label)
def canonical(v):return json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def raw(p):
    p=Path(p);s=p.stat();b=p.read_bytes();t=p.stat()
    sig=lambda x:(x.st_dev,x.st_ino,x.st_mode,x.st_size,x.st_mtime_ns,x.st_ctime_ns)
    need('stable raw read '+str(p),sig(s)==sig(t)and len(b)==t.st_size)
    d=dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b));pins[str(p)]=d;return d,b
def load(p):
    d,b=raw(p);return d,json.loads(b)
def checked(d):
    actual,b=raw(d['path']);need('whole raw descriptor '+d['path'],actual==d);return b
def save(name,v):
    p=P/name
    if p.exists():raise AssertionError('preserve '+str(p))
    p.write_bytes(json.dumps(v,ensure_ascii=False,sort_keys=True,indent=2,allow_nan=False).encode()+b'\n')
    b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))

ip,idx=load(D/'authorized-index-v3.json')
need('exact authorized index',ip==dict(path=str(D/'authorized-index-v3.json'),sha256='dc577c53f216af91363d668bf062892dbd08801f536d99168fbe8962690acd78',bytes=7454))
plan=json.loads(checked(idx['plan']));auth=json.loads(checked(idx['authorization']))
subject={k:v for k,v in plan.items()if k!='authorization'};sha=hashlib.sha256(canonical(subject)).hexdigest()
need('full12subject exact',len(subject)==12 and subject==idx['subject'] and sha==idx['subject_sha256']=='a11dadc9da79666d63d3aea4b574985901f4777e654dfc8c6a8131df966a4200')
need('Root true maxone whole grant',auth['author_identity']=='/root'and auth['actual_execution_authorized']is True and type(auth['maximum_actual_invocations'])is int and auth['maximum_actual_invocations']==1 and auth['subject_sha256']==sha and plan['authorization']==idx['authorization'])
need('same current two reviewscopes',set(auth['review_roles'])=={'Source','plans'} and auth['review_roles']==idx['review_roles'])
reviews={role:json.loads(checked(d))for role,d in auth['review_roles'].items()}
for role,r in reviews.items():need('scoped no actual authority '+role,r['reviewer_identity']=='/root/conventional_control_review'and r['source_only']is True and r['scientific_calls']==0 and r['scientific_acceptance']is False and r['actual_execution_authorized']is False)
need('current Source pass exact subjects',reviews['Source']['source_review_passed']is True and reviews['Source']['sources']==idx['current_sources'])
need('current plans pass exact fullsubject',reviews['plans']['prospective_review_passed']is True and reviews['plans']['subject']==subject and reviews['plans']['subject_sha256']==sha and reviews['plans']['declaration']==subject['declaration'])
dp,delta=load(P/'typed-final-grant-delta-review-v3.json')
need('exact final delta admitted metadata only',delta['final_grant_delta_review_passed']is True and delta['subject_sha256']==sha and delta['authorized_index']==ip)
decl=json.loads(checked(subject['declaration']));contract=json.loads(checked(idx['Root_Source_contract']))
need('sourceepoch maps equal',idx['current_sources']==decl['current_sources']==contract['current_sources'])
for role,d in idx['current_sources'].items():need('current full Source binding '+role,subject[role]==d);checked(d)
checked(subject['python'])
need('three exact original input subjects',subject['inputs']==idx['original_complete_inputs']==decl['inputs']and[x['id']for x in subject['inputs']]==['full-base-control','full-shadow-packets','full-prior-case002'])
for row in subject['inputs']:checked(row['input'])
need('whole original byte total',sum(x['input']['bytes']for x in subject['inputs'])==38397056==decl['aggregate_whole_raw_input_bytes'])
limits=dict(work_seconds=180,overall_seconds=210,memory_bytes=1073741824,result_bytes=134217728,expanded_bytes=134217728,stdout_bytes=4194304,stderr_bytes=4194304)
need('original full global caps',subject['limits']==decl['limits']==limits)

cp,c=load(A/'CONSUMED.json');fp,f=load(A/'worker-failure.json');rp,r=load(A/'runner-receipt.json');op,oc=load(O/'CONSUMED.json');tp,t=load(O/'terminal.json');clp,cl=load(D/'ROOT-cohort-closure-v3.json')
need('actual directory and one worker consumption',subject['actual_directory']==str(A)and c['plan']==idx['plan']and c['subject_sha256']==sha and c['invocation_id']==plan['invocation_id']and c['maximum_worker_launches']==1 and c['consumed_before_Popen']is True)
need('one observer consumption exactplan',oc['plan']==idx['plan']and oc['maximum_runner_launches']==1 and oc['started_ns']==t['started_ns'])
need('runner exact raw joins',r['plan']==idx['plan']and r['authorization']==idx['authorization']and r['subject_sha256']==sha and r['invocation_id']==plan['invocation_id']and r['consumed_marker']==cp and r['limits']==limits)
need('worker isolated command',[subject['python']['path'],'-I','-S','-B',subject['worker']['path'],idx['plan']['path']]==r['command'])
need('observer isolated runner command',[subject['python']['path'],'-I','-S','-B',subject['runner']['path'],idx['plan']['path']]==t['command'])
need('observer runner receipt wholepin',t['runner_receipt']==rp and t['plan']==idx['plan'])
need('180/210 absolute Sourceentry clocks',c['began_ns']==r['began_ns']and c['work_deadline_ns']==r['work_deadline_ns']==r['began_ns']+180000000000 and c['overall_deadline_ns']==r['overall_deadline_ns']==r['began_ns']+210000000000)
need('chronology through observed terminal',t['started_ns']<=r['began_ns']<r['worker_terminal_observed_ns']<=r['closed_ns']<=t['terminal_ns']<r['work_deadline_ns']<r['overall_deadline_ns'])
terminal=(t['terminal_ns']-r['began_ns'])/1e9
need('diagnostic terminal exact',terminal==t['runner_clock_seconds']==105.746632333)
need('exact once worker and reaped wait4',r['worker_launch_attempts']==1 and r['worker_pid']==r['owned_pgid']==78026 and r['worker_reaped']is True and r['worker_wait4_status']==256 and os.waitstatus_to_exitcode(r['worker_wait4_status'])==r['worker_exit_code']==1)
need('runner exit2 distinct fromworker1',t['runner_exit_code']==2 and t['runner_pid']==78025)
need('no signals; saved group/log closure',r['signals']==[]and r['owned_group_absent']is True and r['regular_logs_closed']is True)
need('exact OS closure corroboration',cl['worker_pid']==r['worker_pid']and cl['owned_pgid']==r['owned_pgid']and cl['runner_pid']==t['runner_pid']and cl['worker_reaped']is True and cl['killpg_zero_absent']is True and cl['regular_logs_closed']is True and cl['ps_matching_rows']==[])
peak=r['worker_wait4_usage']['ru_maxrss']
need('separate worker peak below cap but not admitted',type(peak)is int and peak==719568896<limits['memory_bytes'])
need('resource/representation/terminal false',r['resource_candidate_accepted']is False and r['representation_candidate']is False and t['terminal_gate_passed']is False)
need('no scientific authority',r['Native_calls']==0 and r['Model_permission']is False and r['mathematical_proof_accepted']is False and r['scientific_acceptance']is False and t['mathematical_proof_accepted']is False and t['scientific_acceptance']is False)
need('runner normal-exit refusal origin',r['errors']==[dict(type='ValueError',message='normal exact worker exit0')])
need('owned private work UNKNOWN',f['status']=='UNKNOWN_EVIDENCE_LIMIT'and f['type']=='InverseLimit'and f['own_inverse_limit']is True and f['own_codec_limit']is False and f['limit']=={'reason':'work'}and f['message']=='work')
context=f['reached_context'];stats=context['inverse_statistics']
need('first complete input stopped at independentstream',context['stage']=='INDEPENDENT_FULL_SAVED_INVERSE'and context['input']=='full-base-control'and context['fixture']is None and stats['phase']=='STREAM_EVERY_ORDINARY_OCCURRENCE')
need('not complete no candidate',stats['completed']is False and f['completed_input_packets']==[]and f['published_result_candidate']is None and f['representation_accepted']is False and f['scientific_acceptance']is False)
need('sourceprofile and exact privatework counter',stats['execution_profile']=='independent-evidence-fragments-actual-operations-v4'and stats['actual_operations']==20000001 and stats['last_operation']=='stream_copy_block'and contract['private_limits']['work']==20000000)
need('kind work sums full attempted operations',all(type(v)is int and v>=0 for v in stats['operations_by_kind'].values())and sum(stats['operations_by_kind'].values())==stats['actual_operations'])
need('complete root summary unqualified',stats['root_canonical_bytes']==36481857==subject['inputs'][0]['input']['bytes']-1 and stats['logical_occurrences_summary']==12334087 and stats['root_node_depth']==186<=513)
need('partial bytes/value counters not completion',stats['stream_copied_bytes']==35386779<stats['root_canonical_bytes']and stats['stream_logical_occurrences']==11928984<stats['logical_occurrences_summary']and stats['stream_chunks']==539)
need('stream cache work and node counts selfconsistent',stats['cache_hits_stream']==stats['operations_by_kind']['stream_cache_hit']==2197745 and stats['cache_hits_build']==stats['operations_by_kind']['build_cache_hit']==176437 and stats['validated_nodes']==stats['operations_by_kind']['validate_node']==stats['operations_by_kind']['summary_node']==stats['operations_by_kind']['reachability_node']==80807)
need('ordered edge summaries selfconsistent',stats['validated_edges']==stats['operations_by_kind']['validate_edge']==stats['operations_by_kind']['summary_edge']==stats['operations_by_kind']['reachability_edge']==2249737)
need('cache bounded selfconsistent',stats['cache_entries']==stats['cache_attempts']==stats['operations_by_kind']['freeze_fragment']==54402<=65536 and stats['cache_payload_bytes']==stats['build_copied_bytes']==1784403<=8388608 and stats['cache_capacity_fallbacks']==0 and stats['cache_ineligible_nodes']+stats['cache_attempts']==stats['validated_nodes'])
need('whole Root callback dispatch snapshot',f['callback_count_at_failure']==37787349)
need('prefix byte counters exact',f['aggregate_expanded_input_prefix_bytes']==36481858 and f['aggregate_encoded_table_prefix_bytes']==15096899)
need('only one table wholepin',f['published_table_prefix']==[dict(path=str(A/'full-base-control-table.json'),sha256='8f67f39b299e0dd2a250352ebdf864be79a0c0defbb83b181353938bf77012d7',bytes=15096899)])
checked(f['published_table_prefix'][0]) # Raw hash only; never parse the encoded table.
oldtable,_=raw(OLD/'actual-v5'/'full-base-control-table.json')
need('same unqualified table digest not cacheinput',oldtable['sha256']==f['published_table_prefix'][0]['sha256']and oldtable['bytes']==15096899 and all('-table.json'not in x['input']['path']for x in plan['inputs']))

# Literal retained diagnostics only; no fixture operation or inverse replay.
wt=ast.parse(Path(subject['worker']['path']).read_text())
expected=ast.literal_eval(next(n.value for n in wt.body if isinstance(n,ast.Assign)and any(isinstance(x,ast.Name)and x.id=='EXPECTED_FIXTURES'for x in n.targets)))
fixtures=f['completed_fixture_prefix'];byname={v['name']:v for v in fixtures}
need('all exact71 fixed names returned in order',len(expected)==len(fixtures)==len(byname)==71 and [v['name']for v in fixtures]==expected)
for value in fixtures:need('fixture returned true '+value['name'],value['passed']is True)
for name in expected[48:]:
    row=byname[name]
    if 'statistics'in row:
        st=row['statistics'];need('newfixture profile '+name,st['execution_profile']=='independent-evidence-fragments-actual-operations-v4')
        need('newfixture work counter exactsum '+name,sum(st['operations_by_kind'].values())==st['actual_operations'])
    if name.startswith('fragment_exact_callback_'):
        need('reached exact delayed callback '+name,row['exact_exception_object_propagated']is True and row['branch_genuinely_reached']is True and row['statistics']['completed']is False)
row=byname['fragment_scalar_and_empty_container_early_bounds']
need('all6 earlybound records returned',len(row['outcomes'])==6 and all(x['reason']=='expanded bytes'and x['statistics']['phase']=='INDEPENDENT_EXPANDED_SUMMARIES'and x['statistics']['stream_copied_bytes']==0 and x['statistics']['completed']is False for x in row['outcomes']))
need('owned limit fixture retainedcounter',byname['fragment_owned_work_limit_statistics']['reason']=='work'and byname['fragment_owned_work_limit_statistics']['statistics']['completed']is False)
need('earlyclosed fixture remainsincomplete',byname['fragment_closed_incomplete_statistics']['first_chunk_bytes']==65536 and byname['fragment_closed_incomplete_statistics']['statistics']['completed']is False)
need('observed dict not authority fixture completed',byname['fragment_observer_mutation_is_not_authority']['statistics']['completed']is True and byname['fragment_observer_mutation_is_not_authority']['statistics']['phase']=='COMPLETE')
need('cacheuse fixture actualhits',byname['fragment_repeated_subtree_and_summary']['statistics']['cache_hits_stream']>0 and byname['fragment_repeated_subtree_and_summary']['statistics']['completed']is True)
for name in ['fragment_disabled_payload','fragment_disabled_entries']:
    st=byname[name]['statistics'];need('full ordinaryfallback observed '+name,st['completed']is True and st['cache_entries']==0 and st['cache_hits_stream']==0 and st['cache_capacity_fallbacks']>0)

need('exact actual file census',{p.name for p in A.iterdir()}=={'CONSUMED.json','full-base-control-table.json','runner-receipt.json','stderr.bin','stdout.bin','worker-failure.json'})
need('exact observer file census',{p.name for p in O.iterdir()}=={'CONSUMED.json','terminal.json','stderr.bin','stdout.bin'})
for name in ['result.json','worker-receipt.json','POST_RECEIPT_WORK_FAILURE.json','POST_RECEIPT_DEADLINE_FAILURE.json']:need('no absent success/late marker '+name,not os.path.lexists(A/name))
for stream in ['stdout','stderr']:
    b=checked(r[stream]);need('whole bounded log '+stream,len(b)<=limits[stream+'_bytes'])
    if stream=='stderr':need('traceback exact owner work Source','independent_evidence_inverse_v5.py'in b.decode()and'InverseLimit: work'in b.decode())
_,obsout=raw(O/'stdout.bin');_,obserr=raw(O/'stderr.bin')
need('observer exact complete logs',json.loads(obsout)==dict(actual=str(A),representation_candidate=False,resource_candidate_accepted=False)and obserr==b'')
rootpin,root=load(D/'ROOT-final-audit-v3.json')
need('exact separate Root audit',rootpin==dict(path=str(D/'ROOT-final-audit-v3.json'),sha256='756996939225db43a9e34134e845e6519bc7ece2519be4511268b3661dc17415',bytes=2622))
need('Root conclusion matches own joins',root['plan']==idx['plan']and root['result_or_failure']==fp and root['runner']==rp and root['terminal']==tp and root['cohort_closure']==clp and root['subject_sha256']==sha and root['completed_diagnostics']==71 and root['completed_full_input_packets']==0 and root['worker_peak_bytes']==peak and root['terminal_seconds']==terminal and root['status']==f['status']and root['representation_admitted']is False and root['resource_admitted']is False and root['proof_accepted']is False and root['Model_permission']is False and root['schema_inventory_admission']is False)
prior1,_=load('/private/tmp/gcts-exact-evidence-peer-20261019/typed-first-qualification-negative-review-v1.json');prior2,_=load('/private/tmp/gcts-exact-evidence-peer-20261019/typed-second-qualification-saved-review-v5.json')
summary=dict(status=f['status'],own_limit_reason='work',inverse_execution_profile=stats['execution_profile'],private_work_cap=20000000,attempted_operation_counter=stats['actual_operations'],completed_diagnostics=71,completed_input_packets=0,stream_copied_bytes=stats['stream_copied_bytes'],root_canonical_bytes=stats['root_canonical_bytes'],internal_copied_bytes_short_of_root=stats['root_canonical_bytes']-stats['stream_copied_bytes'],stream_chunks=stats['stream_chunks'],stream_logical_occurrences=stats['stream_logical_occurrences'],root_logical_occurrences_summary=stats['logical_occurrences_summary'],callback_dispatches=f['callback_count_at_failure'],worker_exit_code=1,runner_exit_code=2,terminal_seconds_from_runner_Sourceentry=terminal,observer_main_seconds=(t['terminal_ns']-t['started_ns'])/1e9,worker_peak_bytes=peak,worker_peak_MiB=peak/1048576,worker_CPU_seconds=r['worker_wait4_usage']['ru_utime']+r['worker_wait4_usage']['ru_stime'],signals=[],known_reaped=True,owned_group_absent=True,logs_closed=True,representation_accepted=False,resource_accepted=False,scientific_acceptance=False)
audit=save('fragment-qualification-saved-audit-v3.json',dict(schema='fragment-inverse-qualification-saved-audit-v1',saved_data_only=True,source_only=True,scientific_calls=0,codec_calls=0,inverse_replays=0,fixture_calls=0,module_evaluations=0,actual_execution_authorized=False,checks=checks,check_count=len(checks),mismatch_count=0,raw_pins=list(pins.values()),summary=summary,fixture_names=expected))
receipt=save('typed-fragment-qualification-saved-review-v3.json',dict(schema='fragment-inverse-qualification-saved-review-v1',saved_evidence_review_passed=True,negative_evidence_review_passed=True,author_identity='/root',reviewer_identity='/root/conventional_control_review',saved_data_only=True,source_only=True,scientific_calls=0,codec_calls=0,inverse_replays=0,fixture_calls=0,module_evaluations=0,scientific_acceptance=False,actual_execution_authorized=False,representation_accepted=False,resource_accepted=False,authorized_index=ip,subject_sha256=sha,review_roles=auth['review_roles'],final_grant_delta=dp,current_sources=idx['current_sources'],limits=limits,consumed_marker=cp,observer_consumed=op,whole_failure_packet=fp,runner_receipt=rp,terminal_observation=tp,Root_saved_cohort_closure=clp,Root_separate_saved_audit=rootpin,prior_negatives=[prior1,prior2],retained_unqualified_table=f['published_table_prefix'][0],audit=audit,check_count=len(checks),mismatch_count=0,findings=[],summary=summary,conclusions=[
 'One exact reviewed subject ran once. All71 prospective diagnostics returned passed in the exact frozen order, with cache/fallback/early-bound/ownership and eight genuinely reached delayed-error witness records. These finite results do not constitute universal codec soundness.',
 'The first full original reached independent stream reconstruction and stopped on its owned work quota at attempted operation20000001. Internal copied35386779B is short of root36481857B; no complete input packet, candidate result or worker header exists. No partial representation is admitted.',
 'Worker1 and runner2 remain distinct; exact wait4, no signals, saved owned-group absence and full logs corroborate terminal closure. Diagnostic terminal105.746632333s and peak686.234375MiB are below individual global thresholds but do not override incomplete qualification/normal-exit requirements. Resource admission remains false.',
 'The retained table has the same whole raw hash as earlier independently generated unqualified tables and was not parsed/inverted by this audit or reused as a new input. Both previous UNKNOWNs and unexecuted Source negatives remain unchanged. No theorem, Native/Model/schema permission, integration, RL/GCTS or causal speed claim follows.'
],limitations=[
 'Retained ordinary JSON/logs/counters and raw file hashes only; no inverse/encoder/fixture/module/scientific functions, original proof evaluation or encoded-table/opaque Native decode. Statistically reported counters were checked internally and against pinned Source conventions, not regenerated by executing the algorithm.',
 'Copied bytes count internal stream work, including pending bytes not necessarily yielded/compared as complete chunks. There is no saved independent output prefix to re-verify; no claim that the entire copied count is a certified ordinary output or full original equality. Logical occurrence counters likewise describe complete emitted pieces, not a parsed partial document.',
 'Current Source/Python raw pins match the plan at audit time. Failure has no positive endpoint/header custody receipt; saved guards remain conditional on reviewed stdlib/loader/OS and exclusive-owner assumptions, not a formal continuous seal.',
 'All71 fixtures are finite authored implementation diagnostics, not a universal typing/interleaving/exception theorem. Delayed fixtures reach cached build/post-first-chunk copy only; not all possible completion/fallback timings.',
 'Worker-only Darwin highwater excludes outer/observer RAM and has no Native child. Both timing and peak are failed standalone qualification observations, not fair integrated scientific-pipeline speed/memory evidence.',
 'A proposed private30m safeguard would be an explicit changed qualification profile with new reviewed worker/contract/declaration/subject and one-use grant. This20m run staysUNKNOWN; no counter increase, retry, new actual or oldV3profile/default qualification is authorized here.',
 'Control authored none of these current five representation components, but authored older scientific/control/outer code and the current review obligations. This independently audits Root-executed retained evidence, not mathematical-kernel soundness or own Source authority.'
]))
handoff=save('fragment-qualification-saved-peer-handoff-v3.json',dict(schema='fragment-inverse-qualification-saved-handoff-v1',receipt=receipt,audit=audit,saved_data_only=True,scientific_calls=0,negative_evidence_review_passed=True,representation_accepted=False,resource_accepted=False,actual_execution_authorized=False))
print(json.dumps(dict(receipt=receipt,audit=audit,handoff=handoff,check_count=len(checks),summary=summary),sort_keys=True))
