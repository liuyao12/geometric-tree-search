"""Narrow saved grant metadata only; no launcher, codec or fixture calls."""
from pathlib import Path
import hashlib
import json
import os

D=Path('/private/tmp/gcts-fragment-inverse-ROOT-20261019')
P=Path('/private/tmp/gcts-fragment-inverse-peer-20261019')
checks=[]
pins={}
def canonical(value):
    return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def need(label,condition):
    checks.append(dict(label=label,passed=bool(condition)))
    if not condition:raise AssertionError(label)
def descriptor(path):
    path=Path(path);b=path.read_bytes()
    d=dict(path=str(path),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b));pins[str(path)]=d
    return d,b
def load(path):
    d,b=descriptor(path);return d,json.loads(b)
def checked(d):
    a,b=descriptor(d['path']);need('raw pin '+d['path'],a==d);return json.loads(b)
def save(name,value):
    path=P/name
    if path.exists():raise AssertionError('preserve existing '+str(path))
    path.write_bytes(json.dumps(value,ensure_ascii=False,sort_keys=True,indent=2,allow_nan=False).encode()+b'\n')
    return descriptor(path)[0]

idxpin,idx=load(D/'authorized-index-v3.json')
need('exact authorized index',idxpin==dict(path=str(D/'authorized-index-v3.json'),sha256='dc577c53f216af91363d668bf062892dbd08801f536d99168fbe8962690acd78',bytes=7454))
priorpin,prior=load(D/'prospective-index-v3.json')
plan=checked(idx['plan']);draft=checked(prior['plan_draft'])
auth=checked(idx['authorization']);draftauth=checked(prior['authorization_draft'])
adoptpin,adopt=load(D/'ROOT-final-grant-adoption-v3.json')
need('exact adoption',adoptpin==dict(path=str(D/'ROOT-final-grant-adoption-v3.json'),sha256='d648f1a76a2aaf942faea036f04b3a38747e5dacff971bbbb86f8c6eccfff7ca',bytes=1200))
need('exact authorized plan',idx['plan']==dict(path=str(D/'plan-authorized-v3.json'),sha256='74dade6b3654f586be2530f008c60449ff48ca1944ed73ae104c331d24d0a58c',bytes=3191))
need('only authorization descriptor differs in plan',set(plan)==set(draft) and [k for k in plan if plan[k]!=draft[k]]==['authorization'])
need('current plan auth binds whole grant',plan['authorization']==idx['authorization'])
subject={k:v for k,v in plan.items() if k!='authorization'}
need('same full subject12',len(subject)==12 and subject==prior['subject']==idx['subject']=={k:v for k,v in draft.items() if k!='authorization'})
sha=hashlib.sha256(canonical(subject)).hexdigest()
need('exact reviewed subject SHA',sha=='a11dadc9da79666d63d3aea4b574985901f4777e654dfc8c6a8131df966a4200'==idx['subject_sha256']==prior['subject_sha256']==auth['subject_sha256']==draftauth['subject_sha256'])
need('auth seven field shape unchanged',set(auth)==set(draftauth)=={'schema','author_identity','actual_execution_authorized','maximum_actual_invocations','subject_sha256','review_roles','scope'})
need('exact allowed auth delta',{k for k in auth if auth[k]!=draftauth[k]}=={'actual_execution_authorized','maximum_actual_invocations','review_roles','scope'})
need('false to true max0 to max1 strict',draftauth['actual_execution_authorized'] is False and auth['actual_execution_authorized'] is True and type(draftauth['maximum_actual_invocations']) is int and draftauth['maximum_actual_invocations']==0 and type(auth['maximum_actual_invocations']) is int and auth['maximum_actual_invocations']==1)
need('unchanged auth schema/Root identity',auth['schema']=='exact-evidence-once-authorization-v1'==draftauth['schema'] and auth['author_identity']=='/root'==draftauth['author_identity'])
need('two exact review roles',set(auth['review_roles'])=={'Source','plans'} and draftauth['review_roles']=={} and auth['review_roles']==idx['review_roles']==adopt['review_roles'])
expected={
 'Source':dict(path=str(P/'typed-components-Source-review-v3.json'),sha256='a4f863a62d7f53238ec6c27379349e66f3ba96d907d115e0d494e41dc262b099',bytes=9796),
 'plans':dict(path=str(P/'typed-prospective-plan-review-v3.json'),sha256='fa5163d9723c673e662b5862785178bbab64d278837dd8cf79773ab5dd6de468',bytes=10238)}
need('exact current review descriptors',auth['review_roles']==expected)
receipts={role:checked(d) for role,d in expected.items()}
for role,r in receipts.items():
    need('reviewer identity '+role,r['reviewer_identity']=='/root/conventional_control_review')
    need('Source only and nonauthorizing '+role,r['source_only'] is True and r['scientific_calls']==0 and r['scientific_acceptance'] is False and r['actual_execution_authorized'] is False)
need('Source role pass/schema/full current5 subjects',receipts['Source']['schema']=='exact-evidence-components-Source-review-v1' and receipts['Source']['source_review_passed'] is True and receipts['Source']['sources']==idx['current_sources']==prior['current_sources'])
need('Source author identities disclosed',receipts['Source']['author_identities']==['/root','/root/conventional_library'])
need('plans role pass/schema/exact full subject',receipts['plans']['schema']=='exact-evidence-prospective-plan-review-v1' and receipts['plans']['prospective_review_passed'] is True and receipts['plans']['subject']==subject and receipts['plans']['subject_sha256']==sha and receipts['plans']['declaration']==subject['declaration'])
need('plans receipt binds current Source review',receipts['plans']['Source_review']==expected['Source'])
need('single reviewer across two scopes explicit','Two roles share one reviewer identity' in auth['scope'])
changed={'actual_execution_authorized','maximum_actual_invocations'}
added={'actuals_started','authorization','plan','review_roles'}
need('authorized index only permitted added fields',set(idx)==set(prior)|added)
need('all inherited index fields unchanged except true/max1',all(idx[k]==prior[k] for k in prior if k not in changed))
need('index true/max1 with no started actual',idx['actual_execution_authorized'] is True and type(idx['maximum_actual_invocations']) is int and idx['maximum_actual_invocations']==1 and type(idx['actuals_started']) is int and idx['actuals_started']==0)
need('adoption exact current index/false index/subject',adopt['authorized_index']==idxpin and adopt['old_false_index']==priorpin and adopt['subject_sha256']==sha and adopt['unchanged_subject'] is True)
need('adoption no launch/science claim',adopt['actuals_started']==0 and adopt['source_only'] is True and adopt['scientific_calls']==0 and adopt['goal_complete'] is False)
need('inputs runtime source declaration limits literally unchanged',all(subject[k]==prior['subject'][k] for k in ['inputs','python','encoder','inverse','worker','runner','observer','declaration','limits']))
fresh=[Path(subject['actual_directory']),Path(subject['actual_directory'])/'CONSUMED.json',D/'plan-authorized-v3-terminal-observation',D/'plan-draft-v3-terminal-observation']
for path in fresh:need('fresh absent '+str(path),not os.path.lexists(path))
need('both prior UNKNOWNs retained separately',Path('/private/tmp/gcts-exact-evidence-ROOT-20261019/actual-v4/worker-failure.json').is_file() and Path('/private/tmp/gcts-exact-evidence-ROOT-20261019/actual-v5/worker-failure.json').is_file())

audit=save('final-grant-delta-audit-v3.json',dict(schema='exact-evidence-final-grant-delta-audit-v1',source_only=True,scientific_calls=0,codec_calls=0,fixture_calls=0,actual_execution_authorized=False,subject=subject,subject_sha256=sha,checks=checks,check_count=len(checks),mismatch_count=0,raw_pins=list(pins.values()),fresh_absent_paths=[str(p) for p in fresh]))
receipt=save('typed-final-grant-delta-review-v3.json',dict(schema='exact-evidence-final-grant-delta-review-v1',final_grant_delta_review_passed=True,author_identity='/root',reviewer_identity='/root/conventional_control_review',source_only=True,scientific_calls=0,codec_calls=0,fixture_calls=0,module_evaluations=0,scientific_acceptance=False,actual_execution_authorized=False,authorized_index=idxpin,prospective_index=priorpin,authorized_plan=idx['plan'],draft_plan=prior['plan_draft'],authorization=idx['authorization'],authorization_draft=prior['authorization_draft'],Root_adoption=adoptpin,review_roles=expected,subject=subject,subject_sha256=sha,current_sources=idx['current_sources'],declaration=idx['declaration'],audit=audit,check_count=len(checks),mismatch_count=0,findings=[],conclusions=['Only the plan authorization descriptor changed. The exact reviewed twelve-field subject, five Sources, Python, all three whole original inputs, paths/declaration and caps remain literal unchanged.','False/max0 became true/max1 with the current two whole-pinned Source/plans receipts. Both use the same disclosed reviewer identity; no extra independent person is implied.','The V3 actual/consumed/observer paths are absent at this review. Both earlier standalone UNKNOWNs stay retained and non-admitted. This metadata review itself does not launch or admit a qualification.'],limitations=['Narrow saved metadata delta/freshness only. No scientific/codec/inverse/fixture/worker/launcher functions were executed and no original mathematical payloads were decoded.','Current Source and prospective reviews remain conditional on their stated OS/stdlib/ownership/callback and full-completion limitations. No performance, fit, integration, logical authority or resource acceptance follows before a separately audited actual.'],next_action='All tools stopped after receipt delivery; remain idle until Root confirms authoritative timed terminal and cohort closure.'))
handoff=save('final-grant-delta-peer-handoff-v3.json',dict(schema='exact-evidence-final-delta-handoff-v1',receipt=receipt,audit=audit,final_grant_delta_review_passed=True,scientific_calls=0,actual_execution_authorized=False))
print(json.dumps(dict(receipt=receipt,audit=audit,handoff=handoff,check_count=len(checks)),sort_keys=True))
