"""Complete retained data/raw pin audit only. No codec/inverse/table decode."""
from pathlib import Path
import ast,hashlib,json,os
D=Path('/private/tmp/gcts-fragment-inverse-ROOT-20261019');P=Path('/private/tmp/gcts-fragment-inverse-peer-20261019')
A=D/'actual-v4';O=D/'plan-authorized-v4-terminal-observation'
checks=[];pins={};input_rows=[]
def need(k,v):
    checks.append(dict(label=k,passed=bool(v)))
    if not v:raise AssertionError(k)
def canonical(v):return json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def raw(p):
    p=Path(p);s=p.stat();b=p.read_bytes();t=p.stat();sig=lambda x:(x.st_dev,x.st_ino,x.st_mode,x.st_size,x.st_mtime_ns,x.st_ctime_ns)
    need('stable raw read '+str(p),sig(s)==sig(t)and len(b)==t.st_size)
    d=dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b));pins[str(p)]=d;return d,b
def load(p):
    d,b=raw(p);return d,json.loads(b)
def checked(d):
    a,b=raw(d['path']);need('whole raw pin '+d['path'],a==d);return b
def save(n,v):
    p=P/n
    if p.exists():raise AssertionError('preserve '+str(p))
    p.write_bytes(json.dumps(v,ensure_ascii=False,sort_keys=True,indent=2,allow_nan=False).encode()+b'\n');b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))

ip,idx=load(D/'authorized-index-v4.json');plan=json.loads(checked(idx['plan']));auth=json.loads(checked(idx['authorization']))
need('exact authorized index',ip==dict(path=str(D/'authorized-index-v4.json'),sha256='d155bf6bef26537ff18c28e55898d71a0758a030b7c814a817660af585f18cf5',bytes=7455))
subject={k:v for k,v in plan.items()if k!='authorization'};sha=hashlib.sha256(canonical(subject)).hexdigest()
need('full exact12field subject',len(subject)==12 and subject==idx['subject']and sha==idx['subject_sha256']=='88159323ac23ac743bd0788c072ed6f23f825ba0e8c220ea92285cad29509cff')
need('Root exact maxone grant',auth['author_identity']=='/root'and auth['actual_execution_authorized']is True and type(auth['maximum_actual_invocations'])is int and auth['maximum_actual_invocations']==1 and auth['subject_sha256']==sha and plan['authorization']==idx['authorization'])
need('two disclosed current reviewroles',set(auth['review_roles'])=={'Source','plans'}and auth['review_roles']==idx['review_roles'])
reviews={k:json.loads(checked(d))for k,d in auth['review_roles'].items()}
for k,v in reviews.items():need('scoped nonauthorizing peer '+k,v['reviewer_identity']=='/root/conventional_control_review'and v['source_only']is True and v['scientific_calls']==0 and v['scientific_acceptance']is False and v['actual_execution_authorized']is False)
need('current full5Source pass',reviews['Source']['source_review_passed']is True and reviews['Source']['sources']==idx['current_sources'])
need('current exact plans pass',reviews['plans']['prospective_review_passed']is True and reviews['plans']['subject']==subject and reviews['plans']['subject_sha256']==sha and reviews['plans']['declaration']==subject['declaration'])
need('both scopes guard30m/default20m distinct',reviews['Source']['qualification_private_work']==reviews['plans']['qualification_private_work']==30000000 and reviews['Source']['default_private_work']==reviews['plans']['default_private_work']==20000000 and reviews['Source']['default20m_guard_qualified']is False and reviews['plans']['old20m_guard_pass']is False)
dp,delta=load(P/'typed-final-grant-delta-review-v4.json');need('exact preceding delta',delta['final_grant_delta_review_passed']is True and delta['subject_sha256']==sha and delta['authorized_index']==ip)
decl=json.loads(checked(subject['declaration']));contract=json.loads(checked(idx['Root_Source_contract']))
need('current maps literal equal',idx['current_sources']==decl['current_sources']==contract['current_sources'])
for k,d in idx['current_sources'].items():need('full Source role '+k,subject[k]==d);checked(d)
checked(subject['python'])
need('all3 full original subjects',subject['inputs']==idx['original_complete_inputs']==decl['inputs']and[x['id']for x in subject['inputs']]==['full-base-control','full-shadow-packets','full-prior-case002'])
for row in subject['inputs']:need('original whole file newline '+row['id'],checked(row['input'])[-1:]==b'\n')
limits=dict(work_seconds=180,overall_seconds=210,memory_bytes=1073741824,result_bytes=134217728,expanded_bytes=134217728,stdout_bytes=4194304,stderr_bytes=4194304)
need('same original global numeric caps',plan['limits']==decl['limits']==limits)
need('declared profile qualification30m only',decl['inverse_qualification_work']==contract['qualification_private_work']==30000000 and decl['inverse_default_work']==contract['private_limits']['work_default']==20000000 and decl['old20m_guard_pass']is False and contract['old_inverse_profile_pass']is False)

cp,c=load(A/'CONSUMED.json');rp,r=load(A/'runner-receipt.json');wp,w=load(A/'worker-receipt.json');qp,q=load(A/'result.json');op,oc=load(O/'CONSUMED.json');tp,t=load(O/'terminal.json');clp,cl=load(D/'ROOT-cohort-closure-v4.json')
need('exact result whole raw pin',qp==dict(path=str(A/'result.json'),sha256='0a5f6f4100ffafa69f47bb563438fe7466fbe30291c416cfe7592083c98aa357',bytes=267218))
need('once consume binds reviewed subject',c['plan']==idx['plan']and c['subject_sha256']==sha and c['invocation_id']==plan['invocation_id']and c['maximum_worker_launches']==1 and c['consumed_before_Popen']is True)
need('one observer exact consumption',oc['maximum_runner_launches']==1 and oc['plan']==idx['plan']and oc['started_ns']==t['started_ns'])
need('full runner/current/header joins',r['plan']==w['plan']==t['plan']==idx['plan']and r['authorization']==idx['authorization']and r['consumed_marker']==cp and r['subject_sha256']==sha and r['invocation_id']==w['invocation_id']==q['invocation_id']==plan['invocation_id']and r['worker_receipt']==wp and r['result']==w['result']==qp and t['runner_receipt']==rp)
need('worker exact isolated command',r['command']==[subject['python']['path'],'-I','-S','-B',subject['worker']['path'],idx['plan']['path']])
need('observer exact isolated runner',t['command']==[subject['python']['path'],'-I','-S','-B',subject['runner']['path'],idx['plan']['path']])
need('original absolute Sourceentry deadlines',r['began_ns']==w['began_ns']==c['began_ns']and r['work_deadline_ns']==w['work_deadline_ns']==c['work_deadline_ns']==r['began_ns']+180000000000 and r['overall_deadline_ns']==w['overall_deadline_ns']==c['overall_deadline_ns']==r['began_ns']+210000000000)
need('all successful writing/knownexit/terminal beforework',t['started_ns']<=r['began_ns']<w['work_completed_ns']<=r['worker_terminal_observed_ns']<=r['closed_ns']<=t['terminal_ns']<r['work_deadline_ns']<r['overall_deadline_ns'])
terminal=(t['terminal_ns']-r['began_ns'])/1e9
need('exact Sourceentry terminal scalar',terminal==t['runner_clock_seconds']==107.351790584)
need('one exact worker known wait4exit0',r['worker_launch_attempts']==1 and r['worker_pid']==r['owned_pgid']==79673 and r['worker_reaped']is True and r['worker_wait4_status']==0 and os.waitstatus_to_exitcode(r['worker_wait4_status'])==r['worker_exit_code']==0)
need('runner normalexit0 distinct identity',t['runner_exit_code']==0 and t['runner_pid']==79672 and t['runner_pid']!=r['worker_pid'])
need('no signals/errors logs closed',r['signals']==[]and r['errors']==[]and r['regular_logs_closed']is True and r['owned_group_absent']is True)
need('saved exact OS process/group closure',cl['worker_pid']==r['worker_pid']and cl['owned_pgid']==r['owned_pgid']and cl['runner_pid']==t['runner_pid']and cl['worker_reaped']is True and cl['killpg_zero_absent']is True and cl['regular_logs_closed']is True and cl['ps_matching_rows']==[])
peak=r['worker_wait4_usage']['ru_maxrss'];need('full worker peak below1GiB',type(peak)is int and peak==r['worker_peak_bytes']==696057856<=limits['memory_bytes'])
need('all finite candidate gates true',r['representation_candidate']is True and r['resource_candidate_accepted']is True and w['representation_qualification_candidate']is True and t['terminal_gate_passed']is True)
need('recorded scientific flags false',r['Native_calls']==0 and r['scientific_acceptance']is False and r['mathematical_proof_accepted']is False and r['Model_permission']is False and w['scientific_acceptance']is False and w['mathematical_proof_accepted']is False and w['Model_permission']is False and t['scientific_acceptance']is False and t['mathematical_proof_accepted']is False)
for stream in ['stdout','stderr']:need('whole empty bounded worker log '+stream,checked(r[stream])==b''and r[stream]['bytes']<=limits[stream+'_bytes'])
_,obsout=raw(O/'stdout.bin');_,obserr=raw(O/'stderr.bin');need('whole observer logs',json.loads(obsout)==dict(actual=str(A),resource_candidate_accepted=True,representation_candidate=True)and obserr==b'')
need('complete candidate data-only result',q['status']=='REPRESENTATION_QUALIFICATION_CANDIDATE'and q['representation_only']is True and q['schema']=='exact-evidence-qualification-result-v1')
for key in ['scientific_proof_replays','Native_calls','search_calls','Model_calls','opaque_Native_decodes']:need('no scientific function '+key,q[key]==0)
for key in ['new_target_proof','Model_permission','schema_inventory_admission','goal_complete']:need('no mathematical authority '+key,q[key]is False)
need('current result Source records exact',q['current_Source']==dict(encoder=subject['encoder'],independent_inverse=subject['inverse'],worker=subject['worker']))
need('actual work profile and explicit30m guard',q['inverse_execution_profile']=='independent-evidence-fragments-actual-operations-v4'and q['inverse_private_limits']['work']==30000000 and q['inverse_private_limits']['depth']==513 and 'not a pass under default20m guard or oldV3'in q['inverse_work_accounting'])

wt=ast.parse(Path(subject['worker']['path']).read_text());expected=ast.literal_eval(next(n.value for n in wt.body if isinstance(n,ast.Assign)and any(isinstance(x,ast.Name)and x.id=='EXPECTED_FIXTURES'for x in n.targets)))
need('all71 complete fixed fixture IDs exactly',len(q['fixtures'])==len(set(expected))==71 and q['expected_fixture_names']==expected and[x['name']for x in q['fixtures']]==expected)
for row in q['fixtures']:need('fixture passed '+row['name'],row['passed']is True)
priorf=json.loads((D/'actual-v3'/'worker-failure.json').read_bytes())
need('all71 retained fixture packet literals equal prior20m',q['fixtures']==priorf['completed_fixture_prefix'])
need('complete3 original order',[row['id']for row in q['complete_inputs']]==[row['id']for row in plan['inputs']]and len(q['complete_inputs'])==3)
need('header/runner fulltablelists exact',r['tables']==w['tables']==[row['encoded']for row in q['complete_inputs']])
for row,original in zip(q['complete_inputs'],plan['inputs']):
    name=row['id'];need('wholeinput descriptor join '+name,row['input']==original['input'])
    want=dict(bytes=original['input']['bytes'],sha256=original['input']['sha256'],whole_literal_equal=True)
    for key in ['input_baseline','encoder_inverse','saved_wire_encoder_inverse','independent_saved_wire_inverse']:need('complete bytewise receipt join '+name+' '+key,row[key]==want)
    data=checked(row['encoded']);need('whole saved table externalnewline '+name,data[-1:]==b'\n') # Raw only: never json.loads node tables.
    st=row['independent_inverse_statistics'];ops=st['operations_by_kind']
    need('complete inverse profile '+name,st['completed']is True and st['phase']=='COMPLETE'and st['last_operation']=='completion'and st['execution_profile']==q['inverse_execution_profile'])
    need('complete work accounting '+name,all(type(v)is int and v>=0 for v in ops.values())and sum(ops.values())==st['actual_operations']<=30000000 and ops['completion']==1)
    need('complete bytes logical occurrences '+name,st['stream_copied_bytes']==st['root_canonical_bytes']==original['input']['bytes']-1 and st['stream_logical_occurrences']==st['logical_occurrences_summary'])
    need('chunk totals Sourceconsistent '+name,st['stream_chunks']==ops['yield_chunk']==(st['root_canonical_bytes']+65535)//65536)
    need('validated graph metadata '+name,st['validated_nodes']==row['immutable_node_count']==sum(row['node_tag_counts'].values())==ops['validate_node']==ops['summary_node']==ops['reachability_node']and row['root_id']==row['immutable_node_count']-1 and row['immutable_node_count']<=2000000 and st['root_node_depth']<=513)
    need('edge counters Sourceconsistent '+name,st['validated_edges']==ops['validate_edge']==ops['summary_edge']==ops['reachability_edge']<=8000000)
    need('cache totals Sourceconsistent '+name,st['cache_entries']==ops['freeze_fragment']<=65536 and st['cache_payload_bytes']==st['build_copied_bytes']<=8388608 and st['cache_hits_build']==ops['build_cache_hit']and st['cache_hits_stream']==ops['stream_cache_hit']and st['cache_attempts']+st['cache_ineligible_nodes']==st['validated_nodes'])
    need('no scientific semantic admission '+name,row['no_scientific_semantic_admission']is True)
    need('charged perinput intervals bounded '+name,0<=row['freeze_seconds']<=row['total_interval_seconds']<limits['work_seconds'])
    input_rows.append(dict(id=name,original_bytes=original['input']['bytes'],table_bytes=row['encoded']['bytes'],canonical_body_bytes=st['root_canonical_bytes'],work_operations=st['actual_operations'],logical_occurrences=st['logical_occurrences_summary'],nodes=st['validated_nodes'],edges=st['validated_edges'],cache_entries=st['cache_entries'],cache_payload_bytes=st['cache_payload_bytes'],cache_hits_stream=st['cache_hits_stream'],stream_chunks=st['stream_chunks'],four_complete_comparison_receipts=True))
need('exact recorded perinput operation totals',[x['work_operations']for x in input_rows]==[20354563,78135,73157])
need('cannot pass old20m by observed firstcount',input_rows[0]['work_operations']>20000000 and decl['old20m_guard_pass']is False)
need('tables physical total exact',sum(row['encoded']['bytes']for row in q['complete_inputs'])==q['aggregate_encoded_table_bytes']==15307028)
need('both whole expanded and encoded result gates',sum(x['input']['bytes']for x in plan['inputs'])==q['aggregate_input_expanded_bytes']==38397056<=limits['expanded_bytes']and q['aggregate_encoded_table_bytes']+qp['bytes']==r['aggregate_encoded_result_bytes']==15574246<=limits['result_bytes'])
need('sum completedinput intervals charged',sum(row['total_interval_seconds']for row in q['complete_inputs'])<terminal)
need('snapshot callback count exact',q['callback_count_at_result_construction']==38684724)
need('positive actual full file census',{p.name for p in A.iterdir()}=={'CONSUMED.json','full-base-control-table.json','full-shadow-packets-table.json','full-prior-case002-table.json','result.json','worker-receipt.json','runner-receipt.json','stdout.bin','stderr.bin'})
need('positive observer full file census',{p.name for p in O.iterdir()}=={'CONSUMED.json','terminal.json','stdout.bin','stderr.bin'})
for n in ['worker-failure.json','POST_RECEIPT_WORK_FAILURE.json','POST_RECEIPT_DEADLINE_FAILURE.json']:need('no failure/late marker '+n,not os.path.lexists(A/n))
rootpin,root=load(D/'ROOT-final-audit-v4.json');need('exact independent Root audit pin',rootpin==dict(path=str(D/'ROOT-final-audit-v4.json'),sha256='23f280f39caace502c17c5fd80add57e1cf083de19aa0fe3ab845a261ec38f48',bytes=2697))
need('Root conclusion consistent with own joins',root['plan']==idx['plan']and root['result_or_failure']==qp and root['runner']==rp and root['terminal']==tp and root['cohort_closure']==clp and root['subject_sha256']==sha and root['completed_diagnostics']==71 and root['completed_full_input_packets']==3 and root['qualification_private_work']==30000000 and root['default20m_guard_pass']is False and root['old_inverse_v3_work_profile_pass']is False and root['representation_admitted']is True and root['resource_admitted']is True and root['proof_accepted']is False and root['Model_permission']is False and root['schema_inventory_admission']is False and root['terminal_seconds']==terminal and root['worker_peak_bytes']==peak)
priorpin,prior=load(P/'typed-fragment-qualification-saved-review-v3.json');need('consumed20m stillUNKNOWN',prior['representation_accepted']is False and prior['resource_accepted']is False and prior['summary']['attempted_operation_counter']==20000001)
summary=dict(status='QUALIFIED_FINITE_REPRESENTATION_EXPLICIT_30M_GUARD',complete_inputs=3,completed_diagnostics=71,default_private_work=20000000,qualification_private_work=30000000,default20m_guard_pass=False,old_inverse_v3_work_profile_pass=False,whole_original_input_bytes=38397056,encoded_table_bytes=15307028,encoded_tables_plus_result_bytes=15574246,terminal_seconds_from_runner_Sourceentry=terminal,observer_main_seconds=(t['terminal_ns']-t['started_ns'])/1e9,worker_peak_bytes=peak,worker_peak_MiB=peak/1048576,worker_CPU_seconds=r['worker_wait4_usage']['ru_utime']+r['worker_wait4_usage']['ru_stime'],worker_exit_code=0,runner_exit_code=0,signals=[],known_reaped=True,owned_group_absent=True,logs_closed=True,finite_representation_accepted=True,standalone_resource_accepted=True,scientific_acceptance=False)
audit=save('fragment-qualification-saved-audit-v4.json',dict(schema='fragment-inverse-qualification-saved-audit-v1',saved_data_only=True,source_only=True,scientific_calls=0,codec_calls=0,inverse_replays=0,fixture_calls=0,module_evaluations=0,actual_execution_authorized=False,checks=checks,check_count=len(checks),mismatch_count=0,raw_pins=list(pins.values()),summary=summary,per_input_table=input_rows,fixture_names=expected))
receipt=save('typed-fragment-qualification-saved-review-v4.json',dict(schema='fragment-inverse-qualification-saved-review-v1',saved_evidence_review_passed=True,finite_representation_review_passed=True,author_identity='/root',reviewer_identity='/root/conventional_control_review',saved_data_only=True,source_only=True,scientific_calls=0,codec_calls=0,inverse_replays=0,fixture_calls=0,module_evaluations=0,scientific_acceptance=False,actual_execution_authorized=False,representation_accepted=True,resource_accepted=True,qualification_private_work=30000000,default20m_guard_pass=False,old_inverse_v3_work_profile_pass=False,authorized_index=ip,subject_sha256=sha,review_roles=auth['review_roles'],final_grant_delta=dp,current_sources=idx['current_sources'],limits=limits,consumed_marker=cp,observer_consumed=op,result=qp,worker_receipt=wp,runner_receipt=rp,terminal_observation=tp,Root_saved_cohort_closure=clp,Root_separate_saved_audit=rootpin,prior_consumed20m_negative=priorpin,audit=audit,check_count=len(checks),mismatch_count=0,findings=[],summary=summary,per_input_table=input_rows,conclusions=[
 'All71 exact ordered fixture packets returned passed and equal the previous20m run’s saved fixture packets. All3 complete originals have four complete bytewise-comparison receipts joined to their whole raw size/hash; every full saved table is raw-pinned. No codec/inverse was replayed by this audit.',
 'Independent completion/byte/value/cache/counter metadata is internally consistent under the explicit30m qualification guard. First-input work20354563 exceeds default20m; the default guard and oldV3virtual units remain unqualified and all earlier UNKNOWNs stay unchanged.',
 'Exactly one reviewed invocation completed with worker0/runner0, known exact wait4, no signals, full logs and saved owned-group absence. Full positive metadata, known exit and observed terminal precede180s; outer210s, standalone worker peak1GiB and both aggregate128MiB byte gates pass. This supports only the declared finite representation and standalone resource qualification.',
 'This does not activate any scientific pipeline, schema gate or Model, recover absent old failed results, establish new logical/proof/RL/search authority, prove universal codec correctness or demonstrate integrated-pipeline memory or causal speed advantage.'
],limitations=[
 'The audit compares saved ordinary packets/raw bytes/statistics; it never decodes encoded node tables or opaque Native data, executes fixtures, imports target code or regenerates inverse streams. Whole-literal-equality receipts are retained claims of the pinned reviewed worker and are joined completely to originals; this is not an independently replayed bytewise inverse proof.',
 'All71 authored fixtures are finite implementation checks with the declared build/post-first-chunk late-error scope. Source/OS/stdlib/loader/exclusive-owner assumptions and no continuous formal seal or hard builtin latency guarantee remain.',
 'The private guard was deliberately raised for this new engineering qualification only; same event units do not mean same guard profile. No old20m/default or virtualV3 pass, Native/search budget change, consumed retry or automatic default qualification is inferred.',
 'Darwin highwater is the one standalone worker peak, excludes parent/observer RAM and has no Native child. Source-entry work/terminal time excludes declared startup/prelude; observer-main elapsed is separate. These are not full scientific-pipeline or statistically matched performance measurements.',
 'Root’s saved OS closure observations are raw joined evidence; this audit does not re-signal/requery an absent process group. Any future integration still needs fresh common-profile Source/plan/grant and full scientific admission.',
 'Control authored none of the current five representation components but authored older scientific/control/outer code and review obligations. This is an independent retained-data review of Root execution, not independent mathematical-kernel soundness or own Source certification.'
]))
handoff=save('fragment-qualification-saved-peer-handoff-v4.json',dict(schema='fragment-inverse-qualification-saved-handoff-v1',receipt=receipt,audit=audit,saved_data_only=True,scientific_calls=0,finite_representation_accepted=True,standalone_resource_accepted=True,scientific_acceptance=False,actual_execution_authorized=False))
print(json.dumps(dict(receipt=receipt,audit=audit,handoff=handoff,check_count=len(checks),summary=summary),sort_keys=True))
