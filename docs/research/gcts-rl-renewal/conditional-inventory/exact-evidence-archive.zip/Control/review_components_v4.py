"""Narrow explicitly changed guard Source delta; unused compile/inert text only."""
from pathlib import Path
import ast,difflib,hashlib,json,subprocess
P=Path('/private/tmp/gcts-fragment-inverse-peer-20261019');S=Path('/private/tmp/gcts-fragment-inverse-ROOT-source-20261019')
checks=[];pins={}
def need(k,v):
    checks.append(dict(label=k,passed=bool(v)))
    if not v:raise AssertionError(k)
def raw(p):
    p=Path(p);b=p.read_bytes();d=dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b));pins[str(p)]=d;return d,b
def load(p):
    d,b=raw(p);return d,json.loads(b)
def checked(d):
    a,b=raw(d['path']);need('exact raw '+d['path'],a==d);return b
def adump(s):return ast.dump(ast.parse(s),include_attributes=False)
def funcs(s):return{n.name:(ast.get_source_segment(s,n),ast.dump(n,include_attributes=False))for n in ast.parse(s).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
def lit(s,k):return ast.literal_eval(next(n.value for n in ast.parse(s).body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id==k for t in n.targets)))
def save(n,v):
    p=P/n
    if p.exists():raise AssertionError('preserve '+str(p))
    p.write_bytes(json.dumps(v,ensure_ascii=False,sort_keys=True,indent=2,allow_nan=False).encode()+b'\n');b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
cp,c=load(S/'Root-Source-contract-v4.json');pp,parent=load(P/'typed-components-Source-review-v3.json');np,negative=load(P/'typed-fragment-qualification-saved-review-v3.json')
need('contract exact',cp==dict(path=str(S/'Root-Source-contract-v4.json'),sha256='40954e8ea1430c42ab7dc3bfd0d4916d69863e06a090177468f76fb50fe68a4d',bytes=16059))
need('parent conditional Source pass',parent['source_review_passed']is True and parent['source_only']is True and parent['scientific_calls']==0)
sources=c['current_sources'];texts={k:checked(d).decode()for k,d in sources.items()}
need('full5subjects',set(sources)=={'encoder','inverse','worker','runner','observer'})
need('worker exact current pin',sources['worker']==dict(path=str(S/'qualify_exact_evidence_worker_v12.py'),sha256='0102cf898297ae1355cba98daf836e815cc447bdd5233b9eaa93c36da2d80fab',bytes=34307))
for role in sources:
    if role!='worker':need('unchanged reviewed component '+role,sources[role]==parent['sources'][role])
old=checked(parent['sources']['worker']).decode();new=texts['worker']
need('version exact',lit(new,'VERSION')=='exact-evidence-qualification-worker-v5-explicit-30m-private-guard')
normalized=new.replace("VERSION='exact-evidence-qualification-worker-v5-explicit-30m-private-guard'","VERSION='exact-evidence-qualification-worker-v4-propagated-diagnostic-errors'").replace('INVERSE_LIMITS=dict(depth=513,work=30000000)','INVERSE_LIMITS=dict(depth=513)').replace('Same v4 actual-operation units with explicitly changed30m qualification guard; not a pass under default20m guard or oldV3 virtual-token-walk profile.','New actual-operation profile with numeric20m bound; not a pass under oldV3 virtual-token-walk work units.')
need('exact whole raw/AST3literal delta',normalized==old and adump(normalized)==adump(old))
oldfn=funcs(old);newfn=funcs(new);retained=[]
for name in oldfn:
    if name!='main':need('raw/AST unchanged callable '+name,oldfn[name]==newfn[name]);retained.append(name)
need('all71 fixture names/order exact',lit(new,'EXPECTED_FIXTURES')==lit(old,'EXPECTED_FIXTURES')==parent['expected_fixture_names']and len(lit(new,'EXPECTED_FIXTURES'))==71)
need('explicit worker override30m',"INVERSE_LIMITS=dict(depth=513,work=30000000)"in new)
need('unchanged module default20m',"depth=512,work=20000000"in texts['inverse'])
need('same actual-operation units',lit(texts['inverse'],'EXECUTION_PROFILE')==c['inverse_execution_profile']=='independent-evidence-fragments-actual-operations-v4')
need('contract distinguishes qualification/default',c['qualification_private_work']==30000000 and c['private_limits']['work_default']==20000000 and 'work'not in c['private_limits'])
need('current guard not claimed old pass',c['old_inverse_profile_pass']is False and 'cannot be called a pass of the20m guard'in c['charge_table']and 'not old-profile admission'in c['changed_private_guard'])
need('retained actual20m remainsunknown',negative['negative_evidence_review_passed']is True and negative['representation_accepted']is False and negative['resource_accepted']is False and negative['summary']['private_work_cap']==20000000)
need('same global caps/source invariants explicit','Global180/210/worker1GiB/encodedANDexpanded128MiB and all71+3 original cases retained.'in c['changed_private_guard'])
need('no inherited algorithms/data authority change',normalized==old and sources['inverse']==parent['sources']['inverse'])
need('new counter record exactoverride','inverse_private_limits=dict(inverse.DEFAULT_LIMITS,**INVERSE_LIMITS)'in new and 'not a pass under default20m guard or oldV3'in new)
compiled=[]
for role,s in texts.items():
    code=compile(ast.parse(s),sources[role]['path'],'exec');del code;compiled.append(dict(role=role,source=sources[role],evaluated=False))
folder=P/'inert-v4-worker-delta';folder.mkdir(exist_ok=False);payload=folder/'payload.raw.txt';payload.write_text(old);patches=[]
for label,a,b in [('forward',old,new),('reverse',new,old)]:
    p=folder/(label+'.diff');p.write_text(''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='payload.raw.txt',tofile='payload.raw.txt')))
    result=subprocess.run(['/usr/bin/patch','-s','-p0','-i',str(p)],cwd=folder,capture_output=True,text=True)
    need('real inert actual delta '+label,result.returncode==0 and payload.read_text()==b and adump(payload.read_text())==adump(b));patches.append(dict(direction=label,patch=raw(p)[0],whole_raw_and_AST_exact=True))
need('copied parent restored',payload.read_bytes()==old.encode())
audit=save('five-Source-delta-audit-v4.json',dict(schema='fragment-inverse-five-Source-delta-audit-v1',source_only=True,scientific_calls=0,codec_calls=0,inverse_calls=0,fixture_calls=0,module_evaluations=0,actual_execution_authorized=False,checks=checks,check_count=len(checks),mismatch_count=0,raw_pins=list(pins.values()),retained_callables=retained,compile_without_evaluation=compiled,real_inert_patch_directions=patches))
receipt=save('typed-components-Source-review-v4.json',dict(schema='exact-evidence-components-Source-review-v1',source_review_passed=True,author_identities=['/root','/root/conventional_library'],reviewer_identity='/root/conventional_control_review',source_only=True,scientific_calls=0,codec_calls=0,inverse_calls=0,fixture_calls=0,module_evaluations=0,scientific_acceptance=False,actual_execution_authorized=False,sources=sources,source_contract=cp,parent_full_Source_review=pp,prior_consumed20m_negative=np,execution_profile=c['inverse_execution_profile'],default_private_work=20000000,qualification_private_work=30000000,default20m_guard_qualified=False,old_inverse_profile_pass=False,audit=audit,check_count=len(checks),mismatch_count=0,compile_without_evaluation=5,real_inert_patch_directions=2,expected_fixture_names=lit(new,'EXPECTED_FIXTURES'),findings=[],conclusions=[
 'Whole raw/AST inverse restoration proves only workerVERSION, explicit qualification work override30m and its result-accounting description change. Every fixture/stream helper,71names/order and four other full components are exact retained reviewed Sources.',
 'This explicitly changes a private qualification safeguard while retaining v4 actual-operation units. Module default20m remains unchanged; the consumed20m run and earlier UNKNOWNs remain non-admitted. No default20m or old virtualV3 pass is claimed.',
 'Global180/210/1GiB/encodedANDexpanded128MiB and full71+3 requirements remain unchanged. Source review accepts only the disclosed implementation/profile delta, not effectiveness, fit, actual completion or any proof-search/Native budget change.'
],limitations=[
 'No module/function/fixture/codec/inverse/renderer or scientific payload was executed. Compile-only code objects were discarded; two real text patches operated on copied raw source files.',
 'Current full-component correctness/error/custody arguments rely on the genuine previous Source review and its explicit OS/stdlib/exclusive-owner/builtin-latency and finite delayed-fixture scope limitations. These remain in force; no continuous formal seal or universal codec theorem is added.',
 'The earlier obligation note froze20m for its original profile. This receipt explicitly reviews a separately authorized profile amendment to30m, not a claim that the original20m obligation was fulfilled. Both old numeric guard failures and all negative Source tuples remain retained.',
 'All71 diagnostics plus3wholeinputs and every unchanged global gate still need an exact fresh declaration/plan/grant and admitted actual. No retry, oldtable cache, Source activation, Model/schema/Native/proof/RL/GCTS or integration permission follows.'
]))
handoff=save('Source-peer-handoff-v4.json',dict(schema='fragment-inverse-Source-peer-handoff-v1',receipt=receipt,audit=audit,source_review_passed=True,scientific_calls=0,actual_execution_authorized=False))
print(json.dumps(dict(receipt=receipt,audit=audit,handoff=handoff,check_count=len(checks)),sort_keys=True))
