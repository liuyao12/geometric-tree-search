"""Fresh ordinary metadata and raw pins only; no representation functions."""
from pathlib import Path
import hashlib
import json
import os

D=Path('/private/tmp/gcts-fragment-inverse-ROOT-20261019')
P=Path('/private/tmp/gcts-fragment-inverse-peer-20261019')
OLD=Path('/private/tmp/gcts-exact-evidence-ROOT-20261019')
checks=[];pins={}
def need(label,value):
    checks.append(dict(label=label,passed=bool(value)))
    if not value:raise AssertionError(label)
def canonical(v):return json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def raw(p):
    p=Path(p);before=p.stat();b=p.read_bytes();after=p.stat()
    sig=lambda s:(s.st_dev,s.st_ino,s.st_mode,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
    need('stable raw read '+str(p),sig(before)==sig(after) and len(b)==after.st_size)
    d=dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b));pins[str(p)]=d;return d,b
def load(p):
    d,b=raw(p);return d,json.loads(b)
def checked(d):
    a,b=raw(d['path']);need('whole raw descriptor '+d['path'],a==d);return b
def save(name,value):
    p=P/name
    if p.exists():raise AssertionError('preserve '+str(p))
    p.write_bytes(json.dumps(value,ensure_ascii=False,sort_keys=True,indent=2,allow_nan=False).encode()+b'\n')
    b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))

ip,idx=load(D/'prospective-index-v3.json')
need('exact frozen index',ip==dict(path=str(D/'prospective-index-v3.json'),sha256='8eaa8413ebf4eead469f89432b531e82593e34313f426f8396788becd71a9cce',bytes=6528))
plan=json.loads(checked(idx['plan_draft']));auth=json.loads(checked(idx['authorization_draft']));decl=json.loads(checked(idx['declaration']));contract=json.loads(checked(idx['Root_Source_contract']))
sp,sr=load(P/'typed-components-Source-review-v3.json')
need('current exact Source review descriptor',sp==dict(path=str(P/'typed-components-Source-review-v3.json'),sha256='a4f863a62d7f53238ec6c27379349e66f3ba96d907d115e0d494e41dc262b099',bytes=9796))
subject={k:v for k,v in plan.items()if k!='authorization'}
fields={'schema','invocation_id','actual_directory','python','worker','encoder','inverse','runner','observer','inputs','limits','declaration'}
need('exact full13field plan and12field subject',set(plan)==fields|{'authorization'} and set(subject)==fields and len(subject)==12)
sha=hashlib.sha256(canonical(subject)).hexdigest()
need('full literal reviewed subject',subject==idx['subject'] and sha==idx['subject_sha256']=='a11dadc9da79666d63d3aea4b574985901f4777e654dfc8c6a8131df966a4200')
need('onlyauthorization excluded from subject',plan['authorization']==idx['authorization_draft'])
need('exact new iid/path/schema',subject['invocation_id']=='fragment-inverse-whole-artifacts-ROOT-20261019-v3' and subject['actual_directory']==str(D/'actual-v3') and subject['schema']=='exact-evidence-once-plan-v1')
need('false author/index flags',idx['author_identity']=='/root' and idx['source_only'] is True and idx['scientific_calls']==0 and idx['actual_execution_authorized'] is False and type(idx['maximum_actual_invocations'])is int and idx['maximum_actual_invocations']==0)
need('exact falseauth7fields',set(auth)=={'schema','author_identity','actual_execution_authorized','maximum_actual_invocations','subject_sha256','review_roles','scope'})
need('falseauthzero/emptyroles/exactsubject',auth['schema']=='exact-evidence-once-authorization-v1' and auth['author_identity']=='/root' and auth['actual_execution_authorized'] is False and type(auth['maximum_actual_invocations'])is int and auth['maximum_actual_invocations']==0 and auth['review_roles']=={} and auth['subject_sha256']==sha)
limits=dict(work_seconds=180,overall_seconds=210,memory_bytes=1073741824,result_bytes=134217728,expanded_bytes=134217728,stdout_bytes=4194304,stderr_bytes=4194304)
need('exact full original numeric caps',subject['limits']==decl['limits']==limits and all(type(v)is int for v in subject['limits'].values()))
need('exact declaration full descriptor',idx['declaration']==subject['declaration']==dict(path=str(D/'declaration-v3.json'),sha256='57526ae19fdb7023b7168f55896719c50a0ccfd6d77a9a85fbb4c44854b9b07e',bytes=8560))
need('Source/contract/declaration maps literal equal',idx['current_sources']==decl['current_sources']==contract['current_sources']==sr['sources'])
need('exact5Source roles',set(idx['current_sources'])=={'encoder','inverse','worker','runner','observer'})
for role,descriptor in idx['current_sources'].items():
    need('plan exact current Source '+role,subject[role]==descriptor);checked(descriptor)
need('Source receipt exact conditional ABI',sr['schema']=='exact-evidence-components-Source-review-v1' and sr['source_review_passed'] is True and sr['source_only'] is True and sr['scientific_calls']==0 and sr['scientific_acceptance'] is False and sr['actual_execution_authorized'] is False)
need('Source author/reviewer identity',sr['author_identities']==['/root','/root/conventional_library'] and sr['reviewer_identity']=='/root/conventional_control_review')
need('Source receipt binds full current contract',sr['source_contract']==idx['Root_Source_contract']==decl['Root_Source_contract'])
_,prior=load(OLD/'prospective-index-v5.json')
need('encoder runner observer and Python unchanged from prior cohort',all(subject[k]==prior['subject'][k]for k in ['encoder','runner','observer','python']))
checked(subject['python'])
need('whole original3 input order unchanged',subject['inputs']==idx['original_complete_inputs']==decl['inputs']==prior['subject']['inputs'])
need('exact complete input IDs',[x['id']for x in subject['inputs']]==['full-base-control','full-shadow-packets','full-prior-case002'])
for row in subject['inputs']:
    need('complete ordinary-data subject '+row['id'],set(row)=={'id','kind','input'} and row['kind']=='complete_ordinary_saved_JSON');checked(row['input'])
need('complete original raw byte sum',sum(x['input']['bytes']for x in subject['inputs'])==decl['aggregate_whole_raw_input_bytes']==38397056<limits['expanded_bytes'])
need('no failedtable/cache input',all('-table.json'not in x['input']['path'] and str(OLD/'actual-v4')not in x['input']['path'] and str(OLD/'actual-v5')not in x['input']['path']for x in subject['inputs'])and not any('cache'in k.lower()or'resume'in k.lower()for k in plan))
need('new workprofile same numeric20m explicit','NEW actual-operation units'in decl['work_profile'] and 'cannot be called oldV3work-profile admission'in decl['work_profile'] and contract['private_limits']['work']==20000000 and contract['old_inverse_profile_pass'] is False)
need('new optional cache bounds do not replace RAM','Cachepayload is not totalRAM.'in decl['encoded_and_expanded'] and contract['private_limits']['cache_bytes']==8388608 and contract['private_limits']['cache_entries']==65536 and contract['private_limits']['fragment_bytes']==4096)
need('two aggregate caps explicit','All3encoded tables plus candidate result jointly<=128MiB AND aggregate3fully expanded raw original canonical files<=128MiB'in decl['encoded_and_expanded'])
need('Source-only nonauthorizing declaration',decl['author_identity']=='/root' and decl['source_only'] is True and decl['scientific_calls']==0 and decl['actual_execution_authorized'] is False and decl['unimplemented_integration'] is True and decl['no_new_logical_authority'] is True and decl['goal_complete'] is False and decl['RL_training'] is False and decl['recursive_proposer_enabled'] is False)
need('diagnosticsfirst all71 plus3 stillrequired','All71diagnostics precede all3whole originals.'in decl['fixture_order'] and 'Full positive admission still requires every test/input and original global gates.'in decl['fixture_order'] and 'no causal speed claim'in decl['fixture_order'])
need('all old48 and23 additions prospectively named','All48old diagnostics retain exact raw function and sequence.'in decl['diagnostics'] and 'Append23cache-specific diagnostics'in decl['diagnostics'] and len(sr['expected_fixture_names'])==71)
need('precise Sourceentry clock and exclusions','runner timestamp after importing time'in decl['resource_scope'] and 'Interpreter startup/observer prelude excluded'in decl['resource_scope'] and 'observer225s is failure-only'in decl['resource_scope'])
need('same reviewer two scopes explicit','One distinct Control reviewer fills Source and plans roles; not two reviewers.'in decl['trust'])
need('old outputs cannotbe silentlyrescued','original over128MiB full ordinary result cannot pass its unchanged expanded cap'in decl['mathematical_scope'])
need('no future integration or performance assumption','Finalwriter-only freeze is too late'in decl['integration'] and 'No such activation here.'in decl['integration'])
for key in ['first_standalone_negative','second_standalone_negative','prior_standalone_milestone','baseline_failures','integration_reconnaissance']:checked(decl[key])
need('both prior negatives retained',decl['first_standalone_negative']['sha256']=='ce8fd8fee103cfaec4458f7b81679a0d3e0d3dc55d53c1d682d13a657c089bd1' and decl['second_standalone_negative']['sha256']=='bd93ebdae34833df8284a126ed5734c49dd9b4ca1531933205f4c61477aa8da1')
need('unexecuted negative Source tuples preserved',len(sr['preserved_unexecuted_negatives'])==2 and all(json.loads(checked(d))['source_review_passed']is False for d in sr['preserved_unexecuted_negatives']))
fresh=[]
for version in [1,2,3]:
    fresh.extend([D/('actual-v'+str(version)),D/('actual-v'+str(version))/'CONSUMED.json',D/('plan-authorized-v'+str(version)+'-terminal-observation'),D/('plan-draft-v'+str(version)+'-terminal-observation')])
fresh.extend([D/'authorization-v3.json',D/'plan-authorized-v3.json',D/'authorized-index-v3.json'])
for p in fresh:need('fresh absent '+str(p),not os.path.lexists(p))
need('older measured failures remain elsewhere',(OLD/'actual-v4'/'worker-failure.json').is_file()and(OLD/'actual-v5'/'worker-failure.json').is_file())

audit=save('prospective-raw-plan-audit-v3.json',dict(schema='fragment-inverse-prospective-raw-plan-audit-v1',source_only=True,scientific_calls=0,codec_calls=0,inverse_calls=0,fixture_calls=0,module_evaluations=0,actual_execution_authorized=False,checks=checks,check_count=len(checks),mismatch_count=0,raw_pins=list(pins.values()),subject=subject,subject_sha256=sha,fresh_absent_paths=[str(p)for p in fresh]))
receipt=save('typed-prospective-plan-review-v3.json',dict(schema='exact-evidence-prospective-plan-review-v1',prospective_review_passed=True,author_identity='/root',reviewer_identity='/root/conventional_control_review',source_only=True,scientific_calls=0,codec_calls=0,inverse_calls=0,fixture_calls=0,module_evaluations=0,scientific_acceptance=False,actual_execution_authorized=False,prospective_index=ip,plan_draft=idx['plan_draft'],authorization_draft=idx['authorization_draft'],declaration=idx['declaration'],source_contract=idx['Root_Source_contract'],Source_review=sp,sources=idx['current_sources'],Python=subject['python'],complete_inputs=subject['inputs'],subject=subject,subject_field_count=12,subject_sha256=sha,limits=limits,audit=audit,check_count=len(checks),mismatch_count=0,findings=[],conclusions=[
 'The exact fresh12field subject and13field plan bind current inverseV5/workerV11 plus unchanged encoderV2/launchers/Python, every original complete input/order and unchanged global numeric gates. False/max0/emptyroles grants no actual permission; all current/newer draft actual/observer paths are absent.',
 'All71 diagnostics run before the three complete originals, and positive qualification still needs every71 name/status plus all3 whole bytewise input comparisons and original known-exit/terminal/worker-peak/encodedANDexpanded gates. Old48 function remains exact; no failed table/cache is input.',
 'Numeric20m now has explicitly different actual-operation accounting and does not qualify oldV3work units. Both earlier measured UNKNOWNs and both unexecuted negative Source tuples are preserved. No future scientific integration, old128MiB rescue, causal speed or logical authority is implied.',
 'The same Control identity holds distinct Source/plans scopes, not two reviewers. This is Root metadata composition review, separate from current Source argument and future saved-data/OS admission. A true maxone exactsubject grant plus narrow final delta/freshness and idle timing gate is still required.'
],limitations=[
 'Ordinary metadata JSON and whole raw file hashes only. No inverse/codec/fixture/module/scientific/launcher functions or original mathematical payloads were evaluated/replayed or encoded tables decoded.',
 'Pinned Python/bundled stdlib/loader/OS, exclusive input/callback ownership and bounded builtin operation latency caveats remain. No formal continuous seal, process-cleanup theorem, cache effectiveness, memory fit or performance is established by Source/plan PASS.',
 'Finite delayed callback tests cover cached build and post-first-chunk copies; not all possible late/fallback/completion timing. Direct Source propagation applies conditionally; later retained audit must check actual complete71+3 and exact wholeinput/rawresource receipts.',
 'Standalone complete data qualification charges rawinput, all fixtures/constructors/caches/inverses/transients and excludes observer/controller memory/startup according to the explicit epoch. It is not fair integrated-search RAM/speed evidence or Model/schema/Native/proof/RL/search permission.'
]))
handoff=save('prospective-peer-handoff-v3.json',dict(schema='fragment-inverse-prospective-peer-handoff-v1',receipt=receipt,audit=audit,prospective_review_passed=True,scientific_calls=0,actual_execution_authorized=False))
print(json.dumps(dict(receipt=receipt,audit=audit,handoff=handoff,check_count=len(checks)),sort_keys=True))
