"""Retained ordinary JSON/hash/Source-line audit; no component calls or input decode."""
import ast,hashlib,json
from pathlib import Path
D=Path('/private/tmp/gcts-direct-reconcile-ROOT-20261019');A=D/'actual-v1';O=Path('/private/tmp/gcts-direct-reconcile-peer-20261019');checks=[]
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def desc(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def load(p):return json.loads(Path(p).read_bytes())
def ok(n,v,e=None):
 checks.append(dict(name=n,passed=bool(v),evidence=e))
 if not v:raise AssertionError(n)
def checked(d):ok('rawpin:'+d['path'],desc(d['path'])==d);return d
pins={
 D/'ROOT-final-audit-v2.json':('ef3a53f2d40c942e0f47c7aaa3700ec07b2f5da7ff55fac5e11b5312f093a560',2517),
 D/'ROOT-cohort-closure-v2.json':('430df7e6e8533fe0518953a52a6e2de727bcc7f1394be5210e9146123c67f28d',237),
 A/'worker-failure.json':('b9fb61b9a10f7f60d8d6ac8d66cccc004c4b73b7f76feee342b3980335ba5468',338233),
 A/'runner-receipt.json':('652ab9ef7fa90e26feed8bb55742bb2db2f85e188c56b7dcac1ea3d6302250dd',2369),
 D/'plan-authorized-v1-terminal-observation'/'terminal.json':('cb9a2fa4f0b3b24a6a45d49425cb7baf9f3af0df0413c4a68a8af5ab0f2983e6',1051)}
for p,(sha,size)in pins.items():ok('given_pin:'+p.name,desc(p)==dict(path=str(p),bytes=size,sha256=sha))
idx=load(D/'authorized-index-v1.json');plan=load(idx['plan']['path']);auth=load(idx['authorization']['path']);decl=load(idx['declaration']['path']);fail=load(A/'worker-failure.json');runner=load(A/'runner-receipt.json');terminal=load(D/'plan-authorized-v1-terminal-observation'/'terminal.json');cohort=load(D/'ROOT-cohort-closure-v2.json');root=load(D/'ROOT-final-audit-v2.json');consume=load(A/'CONSUMED.json');oc=load(D/'plan-authorized-v1-terminal-observation'/'CONSUMED.json')
for d in [idx['plan'],idx['authorization'],idx['declaration'],idx['source_packet'],runner['consumed_marker'],terminal['runner_receipt'],runner['stdout'],runner['stderr'],*auth['review_roles'].values()]:checked(d)
for k,d in idx['current_sources'].items():checked(d)
checked(plan['python'])
for item in plan['inputs']:checked(item['input'])
subject={k:v for k,v in plan.items()if k!='authorization'};sha=hashlib.sha256(canonical(subject)).hexdigest()
ok('exact_reviewed_subject',sha==idx['subject_sha256']==auth['subject_sha256']==consume['subject_sha256']==runner['subject_sha256']=='92934ba0c82880c05dad0890953463d16b3580c4c0cc98047e7e7fb126c0bcf7')
ok('all_plan_joins',runner['plan']==consume['plan']==terminal['plan']==oc['plan']==idx['plan'])
ok('max1_consumed_before_Popen',auth['actual_execution_authorized']is True and auth['maximum_actual_invocations']==1 and consume['maximum_worker_launches']==1 and consume['consumed_before_Popen']is True and oc['maximum_runner_launches']==1 and runner['worker_launch_attempts']==1)
ok('invocation_join',consume['invocation_id']==runner['invocation_id']==plan['invocation_id'])
ok('auth_roles_same_current_pair',auth['review_roles']==idx['review_roles']and set(auth['review_roles'])=={'Source','plans'})
for role,d in auth['review_roles'].items():
 v=load(d['path']);ok('review_role_zeroexec:'+role,v['reviewer_identity']=='/root/conventional_control_review'and v['scientific_calls']==0 and v['source_only']is True and v['scientific_acceptance']is False and v['actual_execution_authorized']is False)
 ok('full11_review_scope:'+role,v['sources']==idx['current_sources'])
ok('Source_review_pass',load(auth['review_roles']['Source']['path'])['source_review_passed']is True)
ok('plans_review_subject',load(auth['review_roles']['plans']['path'])['subject']==subject)
limits=dict(work_seconds=180,overall_seconds=210,memory_bytes=1073741824,result_bytes=134217728,expanded_bytes=134217728,stdout_bytes=4194304,stderr_bytes=4194304)
ok('original_global_limits',plan['limits']==runner['limits']==decl['global_limits']==limits)
ok('exact_clock_origin_and_deadlines',consume['began_ns']==runner['began_ns']and consume['work_deadline_ns']==runner['work_deadline_ns']==runner['began_ns']+180000000000 and consume['overall_deadline_ns']==runner['overall_deadline_ns']==runner['began_ns']+210000000000)
ok('observer_plan_consumption_prelaunch',oc['started_ns']==terminal['started_ns']and terminal['started_ns']<runner['began_ns']<runner['worker_terminal_observed_ns']<=runner['closed_ns']<terminal['terminal_ns'])
ok('exact_worker_argv',runner['command']==[plan['python']['path'],'-I','-S','-B',plan['worker']['path'],str(D/'plan-authorized-v1.json')])
ok('exact_runner_argv',terminal['command']==[plan['python']['path'],'-I','-S','-B',plan['runner']['path'],str(D/'plan-authorized-v1.json')])
ok('negative_exit_codes_distinct',runner['worker_exit_code']==1 and runner['worker_wait4_status']==256 and terminal['runner_exit_code']==2)
ok('exact_PIDs_and_groups_join',cohort['worker_pid']==runner['worker_pid']==runner['owned_pgid']==cohort['owned_pgid']==11907 and cohort['runner_pid']==terminal['runner_pid']==11906)
ok('known_reap_closed_logs_groups',runner['worker_reaped']is True and runner['regular_logs_closed']is True and runner['owned_group_absent']is True and cohort['worker_reaped']is True and cohort['killpg_zero_absent']is True and cohort['regular_logs_closed']is True and cohort['ps_matching_rows']==[])
ok('no_signals',runner['signals']==[])
ok('failure_not_admitted_flags',runner['resource_candidate_accepted']is False and runner['representation_candidate']is False and terminal['terminal_gate_passed']is False and fail['representation_accepted']is False and fail['scientific_acceptance']is False)
ok('worker_unknown_ownwork_only',fail['status']=='UNKNOWN_EVIDENCE_LIMIT'and fail['type']=='ArenaLimit'and fail['message']==fail['reason']=='work'and fail['own_arena_limit']is True and fail['own_inverse_limit']is False and fail['external_deadline_observed']is False)
ok('negative_runner_origin',runner['errors']==[dict(type='ValueError',message='normal exact worker exit0')])
ctx=fail['reached_context'];stats=ctx['arena_statistics'];counts=stats['counters']
ok('exact_failure_stage',ctx['stage']=='CAPTURE_COMPLETE_ORIGINAL'and ctx['input']=='full-base-control'and ctx['fixture']is None)
ok('main_work_overflow_one',decl['arena_limits']['work']==200000000 and counts['work']==200000001)
ok('started_incomplete_direct_read',counts['reconciliation_begins']==1 and counts.get('reconciliation_complete_reads',0)==0 and counts['reconciliation_frames']>0 and counts['reconciliation_edges']==7323822)
ok('first_builder_counts',counts['intern_lookups']==12334087 and counts['capture_frames']==29336378 and counts['summary_nodes']==80807 and counts['summary_edges']==2249737)
ok('attempted_charge_sum',sum(v for k,v in counts.items()if k not in {'work','fragment_built_bytes'})==counts['work'])
ok('no_committed_capacity',stats['lifecycle']=='ACTIVE'and all(stats[k]==0 for k in ['nodes','edges','roots','cache_entries','cache_bytes','documents','logical_document_bytes','physical_wire_bytes']))
ok('provisional_cache_not_committed',counts['fragment_built_bytes']==8388608 and stats['cache_bytes']==0 and stats['cache_entries']==0)
ok('no_input_forests_candidate',fail['captured_input_prefix']==fail['completed_input_packets']==fail['published_forests']==[]and fail['published_result_candidate']is None and fail['aggregate_encoded_forest_prefix_bytes']==0 and fail['aggregate_expanded_input_prefix_bytes']==36481858)
ok('worker_global_callback_not_main_only',fail['callback_count_at_failure']==17607292)
rows=fail['completed_fixture_prefix'];expected=decl['expected_fixture_names']
ok('135_exact_names_once',len(rows)==len(expected)==len(set(expected))==135 and [r['name']for r in rows]==expected)
for i,row in enumerate(rows):
 if 71<=i<104:ok('fixture_exact_status:'+row['name'],set(row)=={'schema','name','status','scope','observed','authority'}and row['schema']=='arena-finite-diagnostic-v1'and row['status']=='passed'and row['authority']is False)
 else:ok('fixture_strict_passed:'+row['name'],row['passed']is True)
 if i>=127:ok('reconcile_packet_scope:'+row['name'],set(row)=={'schema','name','passed','scope','observed','authority'}and row['schema']=='direct-reconciliation-finite-diagnostic-v1'and row['authority']is False)
# Independent consistency checks of the saved new finite packet content, never re-execute diagnostics.
s=rows[127]['observed'];begin=s['first_builder_counters'];end=s['completed_read_counters']
ok('typed_case_observed_incomplete_to_final',begin['reconciliation_begins']==1 and begin.get('reconciliation_complete_reads',0)==0 and begin['reconciliation_frames']>0 and end['reconciliation_complete_reads']==1 and end['publication_bookkeeping']>0)
for k in ['intern_lookups','full_node_comparisons','summary_nodes','summary_edges','fragment_builds','fragment_built_bytes']:ok('case1_finite_interval_no_rebuild:'+k,begin[k]==end[k])
ok('case1_full_edge_multiplicity',s['every_ordered_edge_checked']is True and end['reconciliation_edges']==s['value_occurrences']-1==2073 and s['body_bytes']==4211 and s['no_second_interning_or_cache_build']is True)
for i,n in [(128,8),(129,7),(130,5)]:
 obs=rows[i]['observed'];ok('mutation_matrix_size:'+str(i),len(obs)==n)
 for j,p in enumerate(obs):
  ok('mutation_retained_refusal:'+str(i)+':'+str(j),p['changed_during_read_before_tail']is True and p['exact_data_refusal']is True and p['committed_ledger_unchanged']is True and p['attempted_counters']['reconciliation_begins']==2 and p['attempted_counters']['reconciliation_complete_reads']==1)
marker_names=['FixtureMarker','RuntimeError','ValueError','StopIteration','GeneratorExit','SystemExit','ArenaLimit']
for i,completed in [(131,False),(132,True)]:
 obs=rows[i]['observed'];ok('foreign_marker_order:'+str(i),[p['type']for p in obs]==marker_names)
 for p in obs:ok('foreign_retained_identity:'+str(i)+':'+p['type'],p['same_exception_object']is True and p['committed_ledger_unchanged']is True and p['completed_read_before_fault']is completed and p['attempted_counters']['reconciliation_begins']==2 and p['attempted_counters']['reconciliation_complete_reads']==(2 if completed else 1))
ok('nine_forbidden_callback_operations',rows[133]['observed']['refused']==['capture','compose','seal','abort','view','stream','materialize','next','close']and rows[133]['observed']['ordinary_capture_completed']is True and rows[133]['observed']['passive_statistics_readable']is True)
b=rows[134]['observed'];pc=b['probe_callback'];nc=b['negative_callback'];ns=b['negative_statistics'];pf=b['probe_final']
ok('one_probe_same_callback',pc==nc and b['work_cap']==pc['counters']['work']+1==23554 and b['owned_reason']=='work'and b['publication_rejected']is True and b['main_arena_caps_unchanged']is True)
ok('tight_negative_real_overflow',ns['counters']['work']==23555>b['work_cap']and ns['counters']['reconciliation_begins']==1 and ns['counters'].get('reconciliation_complete_reads',0)==0 and ns['counters']['reconciliation_frames']>0 and all(ns[k]==0 for k in ['nodes','edges','roots','cache_entries','cache_bytes','documents','logical_document_bytes','physical_wire_bytes']))
ok('fixed_positive_probe_completes',pf['counters']['reconciliation_complete_reads']==1 and pf['roots']==1 and pf['nodes']==7)
stderr=(A/'stderr.bin').read_text();source=Path(idx['current_sources']['encoder']['path']).read_text();tree=ast.parse(source)
ok('stack_pin_stage_matches_Source',"line 458, in _reconcile_value"in stderr and "self._step('reconciliation_edges')"in stderr and source.splitlines()[457].strip()=="self._step('reconciliation_edges')"and "line 489, in capture"in stderr and source.splitlines()[488].strip()=='self._reconcile_value(value,t,i)')
ok('comparator_no_interner_Source',not any(isinstance(n,ast.Call)and isinstance(n.func,ast.Attribute)and n.func.attr=='_intern'for node in ast.walk(tree)if isinstance(node,ast.FunctionDef)and node.name=='_reconcile_value'for n in ast.walk(node)))
absent=[A/'result.json',A/'worker-receipt.json',A/'complete-evidence-forest.json',A/'POST_RECEIPT_DEADLINE_FAILURE.json',A/'POST_RECEIPT_WORK_FAILURE.json']
for p in absent:ok('absent_output:'+p.name,not p.exists()and not p.is_symlink())
ok('only_expected_actual_files',{p.name for p in A.iterdir()}=={'CONSUMED.json','stdout.bin','stderr.bin','worker-failure.json','runner-receipt.json'})
ok('logs_within4MiB',runner['stdout']['bytes']==0 and runner['stderr']['bytes']==1512 and runner['stderr']['bytes']<4194304)
terminal_seconds=(terminal['terminal_ns']-runner['began_ns'])/1e9;observer_seconds=(terminal['terminal_ns']-terminal['started_ns'])/1e9;peak=runner['worker_wait4_usage']['ru_maxrss']
ok('terminal_exact_time',terminal_seconds==terminal['runner_clock_seconds']==67.844199375)
ok('numeric_wall_and_peak_fit_only',terminal['terminal_ns']<runner['work_deadline_ns']<runner['overall_deadline_ns']and peak==600375296<1073741824)
ok('Root_audit_consistent_negative',root['raw_pin_and_saved_packet_audit_passed']is True and root['status']==fail['status']and root['completed_diagnostics']==135 and root['completed_full_input_packets']==0 and root['representation_admitted']is False and root['resource_admitted']is False and root['terminal_seconds']==terminal_seconds and root['worker_peak_bytes']==peak and root['cohort_closure']==desc(D/'ROOT-cohort-closure-v2.json'))
metrics=dict(status=fail['status'],completed_diagnostics=135,captured_inputs=0,completed_inputs=0,forests=0,result_present=False,header_present=False,main_work=counts['work'],main_work_cap=decl['arena_limits']['work'],reconciliation_begins=counts['reconciliation_begins'],reconciliation_complete_reads=counts.get('reconciliation_complete_reads',0),reconciliation_edges=counts['reconciliation_edges'],first_builder_intern_lookups=counts['intern_lookups'],terminal_seconds=terminal_seconds,observer_main_seconds=observer_seconds,worker_peak_bytes=peak,worker_peak_MiB=peak/1048576,worker_exit=runner['worker_exit_code'],runner_exit=terminal['runner_exit_code'],representation_admitted=False,resource_admitted=False)
def write(p,v):p.write_text(json.dumps(v,sort_keys=True,indent=2,ensure_ascii=False)+'\n')
audit=dict(schema='direct-reconciliation-saved-negative-audit-v1',saved_data_only=True,scientific_calls=0,component_calls=0,codec_calls=0,inverse_calls=0,fixture_calls=0,checks=checks,checks_passed=len(checks),mismatch_count=0,metrics=metrics,all135_fixtures=rows,main_statistics=stats)
write(O/'direct-reconciliation-saved-negative-audit-v1.json',audit)
review=dict(schema='direct-reconciliation-saved-evidence-review-v1',saved_data_only=True,saved_evidence_review_passed=True,data_review_passed=True,reviewer_identity='/root/conventional_control_review',author_identity='/root',source_only=False,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,module_evaluations=0,component_calls=0,fixture_calls=0,codec_calls=0,inverse_calls=0,scientific_replays=0,proof_accepted=False,representation_admitted=False,resource_admitted=False,Model_permission=False,schema_inventory_admission=False,findings=[],mismatch_count=0,checks_passed=len(checks),metrics=metrics,subject_sha256=sha,plan=idx['plan'],authorization=idx['authorization'],review_roles=auth['review_roles'],source_packet=idx['source_packet'],current_original_Sources_postterminal=idx['current_sources'],declaration=idx['declaration'],worker_failure=desc(A/'worker-failure.json'),runner_receipt=desc(A/'runner-receipt.json'),terminal_receipt=desc(D/'plan-authorized-v1-terminal-observation'/'terminal.json'),worker_consumed=desc(A/'CONSUMED.json'),observer_consumed=desc(D/'plan-authorized-v1-terminal-observation'/'CONSUMED.json'),stdout=runner['stdout'],stderr=runner['stderr'],Root_audit=desc(D/'ROOT-final-audit-v2.json'),cohort_closure=desc(D/'ROOT-cohort-closure-v2.json'),audit=desc(O/'direct-reconciliation-saved-negative-audit-v1.json'),interpretation=['All135 exact ordered finite diagnostic packets passed their declared mixed-ABI success gates. The eight new groups contain selected fulltyped/mutation/exception/reentrancy/owned-quota evidence; they are not universal correctness or arbitrary temporal-seal claims.','The first main capture entered direct reconciliation and stopped on its next edge charge at200000001. First builder attemptedintern telemetry is12334087; current Source contains no comparator interner call. There is no completed capture, full input packet, forest, result or header, and no schema/Model/proof or representation authority.','Committed capacity is still empty. Provisional first-builder summaries/fragments and observed partial directread counters are attempted telemetry, not a committed forest/cache or whole-data equality proof. Counters aggregate shared operations and do not isolate phase timing.','Worker1, runner2 and false observer gate are consistent with a retained negative. Numerically fitting wall and peak values do not override failed positive exit/output gates. No signals were sent; exact-child wait4, closed logs and saved groupabsence evidence join current IDs.','Root metadata helperV1 stale127 assertion and correctedV2 audit are posthoc saved-data handling only, not a scientific rerun or retry. The consumed actual remains UNKNOWN.'],limitations=['Audit used only saved ordinary packets/raw Source/bytes/statistics. No codec, inverse, fixture or scientific function/module was imported or evaluated, and no opaque Native content decoded.','Current original11 Source hashes and runtime were rechecked after terminal; failed actual has no result/header/sourceepoch/owned copies. This is not a continuous formal invocation integrity seal.','Case1 snapshot interval begins at first during-read callback, already after some direct operations. The no-reinterning prefix conclusion relies on separate Source argument; historical first_builder_counters is not isolated first-pass timing.','Marker identity and failure classification are retained finite-fixture assertions with literal packet consistency checks, not reconstructed execution. Process absence is the joined saved Root OS observation, not an independently rerun live ps test.','Clock is Source-entry work/terminal, worker-only Darwin highwater. Interpreter/observer prelude and outer/controller RAM plus syscall/C-builtin timing assumptions remain disclosed.','No causal speed/RAM, RL/GCTS, proof-search or pipeline savings inference follows; old200m UNKNOWN and prior failures remain nonadmitted.'])
write(O/'typed-direct-reconciliation-saved-review-v1.json',review)
print(json.dumps(dict(review=desc(O/'typed-direct-reconciliation-saved-review-v1.json'),audit=desc(O/'direct-reconciliation-saved-negative-audit-v1.json'),checks=len(checks),metrics=metrics),indent=2))
