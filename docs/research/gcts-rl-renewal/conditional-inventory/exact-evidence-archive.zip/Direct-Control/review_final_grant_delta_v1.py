"""Narrow saved grant delta / raw hash / fresh path check; no target evaluation."""
import hashlib,json
from pathlib import Path
D=Path('/private/tmp/gcts-direct-reconcile-ROOT-20261019');O=Path('/private/tmp/gcts-direct-reconcile-peer-20261019');checks=[]
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def desc(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def load(p):return json.loads(Path(p).read_bytes())
def ok(n,v,e=None):
 checks.append(dict(name=n,passed=bool(v),evidence=e))
 if not v:raise AssertionError(n)
def checked(d):ok('rawpin:'+d['path'],desc(d['path'])==d);return d
expectedpins={
 'plan-authorized-v1.json':('45ec51556d2beed3b38c773db2b121dc52494cfe8e2cff951c38ef64593e619b',3162),
 'authorized-index-v1.json':('326fb313d296cea7cf0bf5dd1d91c60a94fb82e9f4c6568e48ce4072167eadf6',7785),
 'ROOT-final-grant-adoption-v1.json':('9b907573698976c032c6d387d1052c03674f61511cd71a2dafa05fc47df5c6ce',1201)}
for name,(sha,size)in expectedpins.items():ok('requested_pin:'+name,desc(D/name)==dict(path=str(D/name),bytes=size,sha256=sha))
idx=load(D/'authorized-index-v1.json');oldidx=load(D/'prospective-index-v1.json');plan=load(D/'plan-authorized-v1.json');draft=load(D/'plan-draft-v1.json');adoption=load(D/'ROOT-final-grant-adoption-v1.json')
for k in ['plan','authorization','plan_draft','authorization_draft','declaration','source_packet']:checked(idx[k])
auth=load(idx['authorization']['path']);olda=load(idx['authorization_draft']['path']);decl=load(idx['declaration']['path']);packet=load(idx['source_packet']['path'])
subject={k:v for k,v in plan.items()if k!='authorization'};sha=hashlib.sha256(canonical(subject)).hexdigest()
ok('exact12_unchanged_subject',len(subject)==12 and subject=={k:v for k,v in draft.items()if k!='authorization'}==idx['subject']==oldidx['subject'])
ok('exact_subject_sha',sha==idx['subject_sha256']==oldidx['subject_sha256']==auth['subject_sha256']==olda['subject_sha256']==adoption['subject_sha256']=='92934ba0c82880c05dad0890953463d16b3580c4c0cc98047e7e7fb126c0bcf7')
ok('only_plan_auth_descriptor_changed',set(plan)==set(draft)and [k for k in draft if draft[k]!=plan[k]]==['authorization']and plan['authorization']==idx['authorization']and draft['authorization']==idx['authorization_draft'])
ok('true_max1_successor',auth['actual_execution_authorized']is True and auth['maximum_actual_invocations']==1 and olda['actual_execution_authorized']is False and olda['maximum_actual_invocations']==0 and olda['review_roles']=={})
ok('auth_original_fields_preserved',all(auth[k]==olda[k]for k in ['author_identity','schema','subject_sha256']))
ok('auth_only_permitted_fields',set(auth)==set(olda)|{'scope'}and set(auth['review_roles'])=={'Source','plans'})
ok('auth_scope_explicit',all(s in auth['scope']for s in ['One unchanged reviewed12-field subject only','all135 diagnostics','no solver/Native/Model/search calls','No consumed retry','Two roles share one reviewer identity']))
ok('index_true_max1_no_actual',idx['actual_execution_authorized']is True and idx['maximum_actual_invocations']==1 and idx['actuals_started']==0 and adoption['actuals_started']==0)
ok('current_all11_maps_unchanged',idx['current_sources']==oldidx['current_sources']==packet['sources']and len(idx['current_sources'])==11)
for name,d in idx['current_sources'].items():checked(d)
for d in [plan['python'],*(r['input']for r in plan['inputs'])]:checked(d)
ok('declaration_Source_caps_unchanged',idx['declaration']==oldidx['declaration']==plan['declaration']and decl['arena_limits']==decl['shared_contract_limits']and decl['arena_limits']['work']==200000000 and decl['forest_inverse_limits']['work']==30000000)
ok('all135_full3_unchanged',decl['expected_fixture_names']==packet['expected_fixture_names']and len(decl['expected_fixture_names'])==135 and decl['diagnostic_group_counts']==dict(retained=71,arena=33,forest=23,reconciliation=8)and plan['inputs']==draft['inputs']and len(plan['inputs'])==3)
ok('unchanged_global_caps',plan['limits']==decl['global_limits']==dict(work_seconds=180,overall_seconds=210,memory_bytes=1073741824,result_bytes=134217728,expanded_bytes=134217728,stdout_bytes=4194304,stderr_bytes=4194304))
ok('profile_explicit',decl['new_profile'].startswith('invocation-total-direct-reconciliation-parent-guards-v3, unchanged numeric200m.'))
ok('role_descriptors_agree',auth['review_roles']==idx['review_roles']==adoption['review_roles'])
roles={}
expectedroles={'Source':('d4333b1793eebc360b220a5f50dc5211e0fd71976c454e8e5bc20bf37a227f00',17978),'plans':('b85958075c39a26ccab535255a9e4d444e216bf11a013d33f3edaf89f42170d9',19033)}
for role,d in auth['review_roles'].items():
 checked(d);ok('exact_review:'+role,(d['sha256'],d['bytes'])==expectedroles[role]);v=load(d['path']);roles[role]=v
 ok('zero_execution_reviewer:'+role,v['reviewer_identity']=='/root/conventional_control_review'and v['source_only']is True and v['scientific_calls']==0 and v['scientific_acceptance']is False and v['actual_execution_authorized']is False)
 ok('full_eleven_scope:'+role,v['sources']==idx['current_sources'])
sr=roles['Source'];pr=roles['plans']
ok('Source_schema_pass_authorship',sr['schema']=='exact-evidence-components-Source-review-v1'and sr['source_review_passed']is True and sr['author_identities']==['/root','/root/conventional_library'])
ok('plan_schema_pass_literal_subject',pr['schema']=='exact-evidence-prospective-plan-review-v1'and pr['prospective_review_passed']is True and pr['subject']==subject and pr['subject_sha256']==sha and pr['declaration']==plan['declaration'])
ok('full_aux_and_names_scope',pr['auxiliary_sources']==decl['auxiliary_sources']and pr['expected_fixture_names']==decl['expected_fixture_names']and sr['expected_fixture_names']==decl['expected_fixture_names'])
ok('one_disclosed_reviewer_two_roles',len({v['reviewer_identity']for v in roles.values()})==1 and len(roles)==2)
ok('adoption_current_bindings',adoption['authorized_index']==desc(D/'authorized-index-v1.json')and adoption['old_false_index']==desc(D/'prospective-index-v1.json')and adoption['unchanged_subject']is True and adoption['scientific_calls']==0)
absent=[Path(plan['actual_directory']),D/'plan-authorized-v1-terminal-observation',D/'plan-draft-v1-terminal-observation']
for p in absent:ok('fresh_path_absent:'+str(p),not p.exists()and not p.is_symlink())
ok('fresh_once_marker_absent',not(Path(plan['actual_directory'])/'CONSUMED.json').exists())
ok('fresh_observer_marker_absent',not(D/'plan-authorized-v1-terminal-observation'/'CONSUMED.json').exists())
ok('canonical_fresh_actual_parent',str(Path(plan['actual_directory']).resolve())==plan['actual_directory']and Path(plan['actual_directory']).parent.is_dir())
def write(p,v):p.write_text(json.dumps(v,sort_keys=True,indent=2,ensure_ascii=False)+'\n')
audit=dict(schema='direct-reconciliation-final-grant-delta-audit-v1',saved_metadata_only=True,scientific_calls=0,checks=checks,checks_passed=len(checks),mismatch_count=0,subject_sha256=sha)
write(O/'final-grant-delta-audit-v1.json',audit)
review=dict(schema='exact-evidence-final-grant-delta-review-v1',reviewer_identity='/root/conventional_control_review',author_identity='/root',final_grant_delta_review_passed=True,grant_delta_review_passed=True,saved_metadata_only=True,source_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,module_evaluations=0,fixture_calls=0,codec_calls=0,inverse_calls=0,authorized_index=desc(D/'authorized-index-v1.json'),authorized_plan=idx['plan'],authorization=idx['authorization'],old_false_index=desc(D/'prospective-index-v1.json'),plan_draft=idx['plan_draft'],authorization_draft=idx['authorization_draft'],adoption=desc(D/'ROOT-final-grant-adoption-v1.json'),declaration=idx['declaration'],source_packet=idx['source_packet'],sources=idx['current_sources'],review_roles=auth['review_roles'],subject=subject,subject_sha256=sha,checks_passed=len(checks),mismatch_count=0,findings=[],audit=desc(O/'final-grant-delta-audit-v1.json'),reviewer_count=1,review_role_count=2,fresh_absent_paths=[str(p)for p in absent],disclosure='Source and prospective plan roles are two scoped receipts from the same disclosed Control reviewer. Control authored none of the exact current11 Sources or Root grant metadata; historical Control component/design/review ancestry remains in the Source receipt. No claim of two independent people or own-source certification.',limitations=['Only saved true-grant delta, raw current descriptors and fresh path absence were reviewed; no new Source semantics certification or dynamic qualification.','No component, fixture, codec, inverse, Native or scientific function/module was imported or evaluated. Full original inputs were hashed as raw bytes only.','The receipt grants no execution by this reviewer. Root retains exactly one reviewed subject grant, process/freshness preflight and activation responsibility; any failure or UNKNOWN remains retained without retry.'],next_action='Stop all tools and remain idle until Root confirms authoritative actual terminal and cohort closure.')
write(O/'typed-final-grant-delta-review-v1.json',review)
print(json.dumps(dict(review=desc(O/'typed-final-grant-delta-review-v1.json'),audit=desc(O/'final-grant-delta-audit-v1.json'),checks=len(checks)),indent=2))
