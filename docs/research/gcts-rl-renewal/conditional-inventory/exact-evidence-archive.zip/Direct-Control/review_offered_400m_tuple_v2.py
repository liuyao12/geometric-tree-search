"""Offered immutable400m metadata/Source-scope audit only. No component calls."""
import ast,hashlib,json
from pathlib import Path
D=Path('/private/tmp/gcts-direct-reconcile-ROOT-20261019');O=Path('/private/tmp/gcts-direct-reconcile-peer-20261019');checks=[]
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def desc(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def load(p):return json.loads(Path(p).read_bytes())
def ok(n,v):
 checks.append(dict(name=n,passed=bool(v)))
 if not v:raise AssertionError(n)
def checked(d):ok('rawpin:'+d['path'],desc(d['path'])==d)
expected={
 'shared-contract-v7.json':('b64e77d24a57bd99b69215c3e46a7a2102c5e5b4f63488c650570e54a50b73bb',14068),
 'eleven-Source-packet-v2.json':('65f524664f1f996f105c40aadbf5163b597806057da78b0f96fd10a12ab112a7',11104),
 'prospective-index-v2.json':('534f596e1c35d5710d19cbb04faa517a6e11048e3977d8fca3e9aee5706bd8e2',6995),
 'declaration-v2.json':('a682770b5ae1b203f7396c4695959edd5ff16f8d879f9ae8f3d0eee5851826de',12995)}
for n,(sha,size)in expected.items():ok('offered_pin:'+n,desc(D/n)==dict(path=str(D/n),bytes=size,sha256=sha))
s=load(D/'shared-contract-v7.json');pkt=load(D/'eleven-Source-packet-v2.json');idx=load(D/'prospective-index-v2.json');decl=load(D/'declaration-v2.json');olddecl=load(D/'declaration-v1.json');oldpkt=load(D/'eleven-Source-packet-v1.json');oldreview=load(O/'typed-components-Source-review-v1.json')
for k in ['plan_draft','authorization_draft','declaration','source_packet']:checked(idx[k])
plan=load(idx['plan_draft']['path']);auth=load(idx['authorization_draft']['path'])
ok('full11_code_pins_unchanged',pkt['sources']==idx['current_sources']==oldpkt['sources']==oldreview['sources']and len(pkt['sources'])==11)
for d in pkt['sources'].values():checked(d)
ok('literal135_same_names',pkt['expected_fixture_names']==decl['expected_fixture_names']==oldpkt['expected_fixture_names']and len(set(pkt['expected_fixture_names']))==135)
ok('all_exact_group_counts',pkt['fixture_counts']==decl['diagnostic_group_counts']==dict(retained=71,arena=33,forest=23,reconciliation=8))
ok('only_arena_numeric_work_changes',decl['arena_limits']==dict(olddecl['arena_limits'],work=400000000)==decl['shared_contract_limits']==s['limits'])
ok('forest_inverse_and_global_limits_unchanged',decl['forest_inverse_limits']==olddecl['forest_inverse_limits']and decl['global_limits']==olddecl['global_limits']==plan['limits'])
ok('exact_same6_aux',decl['auxiliary_sources']==olddecl['auxiliary_sources'])
ok('same3_complete_originals',plan['inputs']==load(D/'plan-authorized-v1.json')['inputs'])
for r in plan['inputs']:checked(r['input'])
checked(plan['python'])
ok('scope_includes_default_diagnostics',all(t in decl['new_profile']for t in ['Library33/Root8 defaultdiagnostic arenas','one mainarena','Foreստinverse30m'.replace('ստ','st')])and 'not just mainarena'in decl['changed_profile_scope'])
ok('old_negative_retained',decl['prior_failed_audit']==desc(D/'ROOT-final-audit-v2.json')and decl['prior_failed_subject']==desc(D/'plan-authorized-v1.json')and 'UNKNOWNwork200000001 retained'in decl['old_outcomes'])
ok('no_old200m_or_causal_claim',s['changed_profile_justification']['old200m_pass']is False and s['changed_profile_justification']['fit_promise']is False and 'not an improvement or retroactivepass'in s['changed_profile_justification']['reason'])
ok('all_current_contract_links',pkt['shared_contract']==decl['shared_contract']==desc(D/'shared-contract-v7.json')and decl['current_eleven_Source_packet']==idx['source_packet'])
ok('source_mechanism_marker_separate',s['direct_reconciliation']['execution_profile']=='invocation-total-direct-reconciliation-parent-guards-v3'and 'No accounting event/weight/code changes'in decl['new_profile'])
subject={k:v for k,v in plan.items()if k!='authorization'};sha=hashlib.sha256(canonical(subject)).hexdigest()
ok('literal12_subject_hash',len(subject)==12 and subject==idx['subject']and sha==idx['subject_sha256']==auth['subject_sha256']=='e14329454fdf5c0061d2b3a84451557b8bf80ce1308423d17260e3395090349b')
ok('false_max0_emptyroles',auth['actual_execution_authorized']is False and auth['maximum_actual_invocations']==0 and auth['review_roles']=={}and idx['actuals_started']==0 and idx['maximum_actual_invocations']==0)
ok('new_iid_and_actual',subject['invocation_id'].endswith('v2-explicit400m')and subject['actual_directory']==str(D/'actual-v2'))
for p in [D/'actual-v2',D/'plan-authorized-v2-terminal-observation',D/'plan-draft-v2-terminal-observation',D/'plan-authorized-v2.json',D/'authorization-v2.json',D/'authorized-index-v2.json']:ok('fresh_absence:'+p.name,not p.exists()and not p.is_symlink())
# Static limit-parameterization argument: no code is evaluated.
a=Path(pkt['sources']['encoder']['path']).read_text();w=Path(pkt['sources']['worker']['path']).read_text();f=Path(pkt['sources']['reconcile_fixture_module']['path']).read_text()
ok('dynamic_owned_work_gate',"self._counts['work']>self._limits['work']"in a)
ok('worker_supplied_equal_limitmaps',"arena_limits==declaration['shared_contract_limits']"in w and 'limits=arena_limits'in w)
ok('diagnostic_tightening_remains_parent_relative',"0<v<=cap[k]"in f and "0<cap<=limits['work']"in f)
ok('no_hardcoded_200m_operative_new_sources',all('200000000'not in t for t in [a,w,f]))
findings=[
 dict(id='CURRENT_PRIVATE_ALLOWANCE_DENIED',path='shared-contract-v7.json.scientific_scope',severity='blocking_scope_metadata',observed=s['scientific_scope'],problem="The inherited phrase 'no profile allowance increase' contradicts the current explicit200m→400m private allowance change.",required='State no increase to the original global wall/memory/byte/log limits; explicitly acknowledge the supplied-arena private work allowance increase.'),
 dict(id='LIMIT_PARAGRAPH_STALE_NUMERIC_AND_CENSUS_SCOPE',path='shared-contract-v7.json.limit_semantics',severity='blocking_scope_metadata',observed=s['limit_semantics'],problem="The paragraph still says 'All numeric caps unchanged' and calls127 a 'new' or unchanged total without identifying it as the retained historical subgroup. Current private work changes and current total is135.",required='Qualify numeric caps as unchanged except supplied-arena work200m→400m; label127 as retained historical71+33+23 subgroup and current total135 with8reconciliation groups. Keep exact old Source/packet scope strings immutable as historical evidence.')]
for finding in findings:checks.append(dict(name='current_scope_consistency:'+finding['id'],passed=False,expected_negative=True))
audit=dict(schema='direct-reconciliation-offered400m-metadata-audit-v2',source_only=True,scientific_calls=0,component_calls=0,checks=checks,checks_passed=sum(x['passed']for x in checks),mismatch_count=2,findings=findings,subject=subject,subject_sha256=sha)
def write(p,v):p.write_text(json.dumps(v,sort_keys=True,indent=2,ensure_ascii=False)+'\n')
write(O/'offered-400m-tuple-audit-v2-negative.json',audit)
base=dict(author_identities=['/root','/root/conventional_library'],author_identity='/root',reviewer_identity='/root/conventional_control_review',source_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,module_evaluations=0,component_calls=0,fixture_calls=0,codec_calls=0,inverse_calls=0,findings=findings,mismatch_count=2,sources=pkt['sources'],source_packet=desc(D/'eleven-Source-packet-v2.json'),shared_contract=desc(D/'shared-contract-v7.json'),declaration=desc(D/'declaration-v2.json'),prior_Source_review=desc(O/'typed-components-Source-review-v1.json'),prior_saved_negative=desc(O/'typed-direct-reconciliation-saved-review-v1.json'),audit=desc(O/'offered-400m-tuple-audit-v2-negative.json'),code_scope_extension_supported_conditionally=True,explanation='No executable Source defect found in this unchanged-code allowance extension. Offered current contract has contradictory scope text; preserve the offered tuple and correct metadata with fresh descriptors/subjects before a current Source/plan PASS. Only these two field-level corrections were found in the complete stale-scope pass.',limitations=['Raw/AST and saved metadata only; no module, component, fixture, codec, inverse or scientific evaluation.','A finite400m caller limit is Source-compatible under unchanged implementation units, but no dynamic fit/qualification or old200m pass is established.','Same reviewer fills two distinct roles explicitly; no extra independent reviewer or own-source certification is claimed.'])
write(O/'typed-components-Source-review-v2-negative.json',dict(base,schema='exact-evidence-components-Source-review-v1',source_review_passed=False))
write(O/'typed-prospective-plan-review-v2-negative.json',dict(base,schema='exact-evidence-prospective-plan-review-v1',prospective_review_passed=False,prospective_index=desc(D/'prospective-index-v2.json'),plan_draft=idx['plan_draft'],authorization_draft=idx['authorization_draft'],subject=subject,subject_sha256=sha))
print(json.dumps(dict(source_negative=desc(O/'typed-components-Source-review-v2-negative.json'),plans_negative=desc(O/'typed-prospective-plan-review-v2-negative.json'),audit=desc(O/'offered-400m-tuple-audit-v2-negative.json'),checks_passed=sum(x['passed']for x in checks),findings=2),indent=2))
