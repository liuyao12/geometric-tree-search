"""Ordinary saved HTML/JSON/ZIP/raw byte review. Never runs display JS or evidence code."""
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlsplit,unquote
import hashlib,json,math,re,subprocess,zipfile
D=Path('/private/tmp/gcts-direct-reconcile-ROOT-20261019');O=Path('/private/tmp/gcts-direct-reconcile-peer-20261019');P=Path('/private/tmp/gcts-split-controls-publish-20261015/docs/research/gcts-rl-renewal/conditional-inventory');PUB=P.parents[3];checks=[]
def desc(p):
 p=Path(p).resolve();h=hashlib.sha256();size=0
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b);size+=len(b)
 return dict(path=str(p),bytes=size,sha256=h.hexdigest())
def load(p):return json.loads(Path(p).read_bytes())
def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def ok(n,v,e=None):
 checks.append(dict(name=n,passed=bool(v),evidence=e))
 if not v:raise AssertionError(n)
def saved(s):
 start=s.index('const saved=')+len('const saved=');v,end=json.JSONDecoder().raw_decode(s[start:]);assert s[start+end:].startswith(';\nconst esc=');return v['entries']
class Page(HTMLParser):
 def __init__(self):super().__init__(convert_charrefs=True);self.ids=[];self.links=[];self.assets=[];self.visible=[];self.skip=0;self.tables=[];self.current=None;self.row=None;self.cell=None;self.forbidden=[];self.styles=[]
 def handle_starttag(self,t,a):
  a=dict(a)
  if 'id'in a:self.ids.append(a['id'])
  if t=='a'and'href'in a:self.links.append(a['href'])
  if t in ['script','link']and ('src'in a or'href'in a):self.assets.append(a.get('src',a.get('href')))
  if 'style'in a:self.styles.append(a['style'])
  if t in ['sup','sub']:self.forbidden.append(t)
  if t in ['script','style']:self.skip+=1
  if t=='table':self.current=[];self.tables.append(self.current)
  if t=='tr':self.row=[]
  if t in ['td','th']and self.row is not None:self.cell=[]
 def handle_endtag(self,t):
  if t in ['script','style']:self.skip-=1
  if t in ['td','th']and self.cell is not None:self.row.append(''.join(self.cell));self.cell=None
  if t=='tr'and self.row is not None:
   if self.current is not None:self.current.append(self.row)
   self.row=None
  if t=='table':self.current=None
 def handle_data(self,s):
  if not self.skip:self.visible.append(s)
  if self.cell is not None:self.cell.append(s)
cp=D/'publication-candidate-v1.json';c=load(cp);m=load(P/'exact-evidence-manifest.json');rp=D/'ROOT-publication-saved-audit-v1.json'
ok('candidate_exact_pin',desc(cp)==dict(path=str(cp),bytes=2416,sha256='72695595ccc529ac1597b5d40e93e64b2a87adbfab349e1c0a7246e6bded02b0'))
ok('Root_publication_audit_pin',desc(rp)==dict(path=str(rp),bytes=917,sha256='dd568b4c85b8ca444b7e4231734ac2a2923aba396ca8e3d90e6e2320b9e118ae'))
ok('exact9_task_files',len(c['files'])==len({x['path']for x in c['files']})==9)
for d in c['files']:ok('whole_candidate_pin:'+Path(d['path']).name,desc(d['path'])==d)
ok('expected_packet_file_pin',desc(c['viewer_expected']['path'])==c['viewer_expected'])
s=(P/'exact-evidence.html').read_text();entries=saved(s);page=Page();page.feed(s);visible=''.join(page.visible)
ok('all506_unique_labels',len(entries)==len({x['label']for x in entries})==506)
ok('Root_expected_whole_packets',canon(entries)==canon(load(c['viewer_expected']['path'])['entries']))
summary=load(P/'exact-evidence-summary.json');priorentries=saved((D/'prior-publication'/'exact-evidence.html').read_text())
want=[dict(label='Current direct-reconciliation outcome and all seven trials',packet=summary)]
for label,actual,audit,peer in [('Prior direct read: supplied200m',D/'actual-v1',D/'ROOT-final-audit-v2.json',O/'typed-direct-reconciliation-saved-review-v1.json'),('Current direct read: supplied400m',D/'actual-v2',D/'ROOT-final-audit-v5.json',O/'typed-direct-reconciliation-saved-review-v2.json')]:
 result=load(actual/('result.json'if(actual/'result.json').exists()else'worker-failure.json'))
 want.extend(dict(label=label+' complete input: '+x['id'],packet=x)for x in result.get('complete_inputs',result.get('completed_input_packets',[])))
 want.extend(dict(label=label+' diagnostic: '+x['name'],packet=x)for x in result.get('fixtures',result.get('completed_fixture_prefix',[])))
 want.extend([dict(label=label+' complete result or failure',packet=result),dict(label=label+' Root saved audit',packet=load(audit)),dict(label=label+' independent saved audit',packet=load(peer)),dict(label=label+' resource receipt',packet=load(actual/'runner-receipt.json'))])
want.extend([dict(label='Current observed terminal',packet=load(D/'plan-authorized-v4-terminal-observation'/'terminal.json')),dict(label='Current explicit400m shared contract',packet=load(D/'shared-contract-v9.json')),dict(label='Current Source-scope review',packet=load(O/'typed-components-Source-review-v4.json')),dict(label='Independent fixture/harness Source review; sampled-interval caveat',packet=load('/private/tmp/gcts-direct-reconcile-harness-peer-20261019/typed-fixture-harness-Source-review-v1.json')),dict(label='Separate work-allowance design assessment',packet=load(O/'private-400m-profile-design-assessment-v1.json'))])
want.extend(dict(label='Earlier report — '+x['label'],packet=x['packet'])for x in priorentries)
ok('independent_all506_packet_census',len(want)==506)
for i,(a,b)in enumerate(zip(entries,want)):ok('literal_embedded_packet:'+str(i),canon(a)==canon(b),b['label'])
ok('all219prior_exact_preserved',len(priorentries)==219 and canon(entries[-219:])==canon([dict(label='Earlier report — '+x['label'],packet=x['packet'])for x in priorentries]))
current=load(D/'actual-v2'/'result.json');runner=load(D/'actual-v2'/'runner-receipt.json');terminal=load(D/'plan-authorized-v4-terminal-observation'/'terminal.json');admission=load(D/'ROOT-final-audit-v5.json');peer=load(O/'typed-direct-reconciliation-saved-review-v2.json');oldsummary=load(D/'prior-publication'/'exact-evidence-summary.json');oldpositive=load('/private/tmp/gcts-fragment-inverse-ROOT-20261019/actual-v4/result.json')
ok('published_whole_result_bytes',(P/'exact-evidence-result.json').read_bytes()==(D/'actual-v2'/'result.json').read_bytes())
ok('published_whole_Root_audit_object',canon(load(P/'exact-evidence-admission.json'))==canon(admission))
ok('published_whole_peer_object',canon(load(P/'exact-evidence-peer-review.json'))==canon(peer))
ok('literal_vs_audited_status_separate',summary['literal_worker_status']==current['status']=='REPRESENTATION_QUALIFICATION_CANDIDATE'and summary['status']==admission['status']=='QUALIFIED_FINITE_DIRECT_RECONCILIATION')
ok('exact_current_counts_limits',summary['completed_diagnostics']==135 and summary['completed_independent_input_packets']==3 and summary['original_complete_input_count']==3 and summary['representation_admitted']is True and summary['resource_admitted']is True)
ok('exact_current_time_peak_bytes',summary['terminal_seconds']==terminal['runner_clock_seconds']==130.757204416 and summary['worker_peak_bytes']==runner['worker_peak_bytes']==612253696 and summary['whole_original_input_bytes']==38397056)
ok('seven_trials_oldfive_literal',len(summary['trials'])==7 and canon(summary['trials'][:5])==canon(oldsummary['trials']))
for i,(guard,auditpath)in enumerate([(200000000,D/'ROOT-final-audit-v2.json'),(400000000,D/'ROOT-final-audit-v5.json')]):
 t=summary['trials'][5+i];a=load(auditpath)
 ok('direct_trial_literal:'+str(guard),t['arena_private_guard']==guard and t['private_guard']==30000000 and t['diagnostics']==135 and t['complete_inputs']==a['completed_full_input_packets']and t['terminal_seconds']==a['terminal_seconds']and t['worker_peak_bytes']==a['worker_peak_bytes']and t['status']==a['status']and t['representation_admitted']is a['representation_admitted'])
ok('prior_qualified_component_preserved',canon(summary['prior_qualified_component'])==canon(oldsummary['prior_qualified_component']))
ok('old200m_remains_UNKNOWN',summary['trials'][5]['status']=='UNKNOWN_EVIDENCE_LIMIT'and summary['trials'][5]['complete_inputs']==0 and summary['trials'][5]['representation_admitted']is False)
ok('no_scientific_promotion',all(summary[k]is False for k in ['Model_permission','RL_training','new_target_theorem','mathematical_proof_accepted','schema_inventory_admission','goal_complete'])and summary['Native_calls']==summary['search_calls']==0)
ok('historical_measurement_table',page.tables[0][1:]==[[x['id'],r'\('+f"{x['input']['bytes']:,}"+r'\)',r'\('+f"{x['encoded']['bytes']:,}"+r'\)',r'\('+f"{x['immutable_node_count']:,}"+r'\)','Every byte agrees']for x in oldpositive['complete_inputs']])
ok('trial_table_all7_rows',len(page.tables[1])==8)
for row,t in zip(page.tables[1][1:],summary['trials']):ok('display_trial:'+t['id'],row[0]==t['label']and row[-1]==t['status']and row[2]==r'\('+str(t['complete_inputs'])+r'\)'and row[3]==r'\('+str(t['diagnostics'])+r'\)'and row[4]==r'\('+f"{t['terminal_seconds']:.3f}"+r'\,\mathrm{s}\)'and row[5]==r'\('+f"{t['worker_peak_bytes']/1048576:.2f}"+r'\,\mathrm{MiB}\)')
for text in ['389,303,254','400,000,000','22,985,978','30,000,000','38,397,056','15,488,381','15,847,153','130.757','583.89','200,000,001','67.844','572.56','20,354,563']:ok('visible_correct_scalar:'+text,text in visible)
ok('historical_chart_scope_and_bytes',all(x in visible for x in ['Earlier single-artifact component: retained qualification','36.62','14.60','0.25','14.85'])and oldpositive['aggregate_encoded_table_bytes']==15307028)
ok('allowance_change_no_oldprofile_admission',all(x in visible for x in ['including inherited diagnostic-arena defaults','Raising a private guard does not establish a speedup or retroactively admit the failed profile','All seven rows retain full-job metrics','no causal speed or memory advantage follows']))
ok('new_success_finite_and_counter_limits',all(x in visible for x in ['finite qualification under the explicitly supplied','These finite measurements provide no larger-input scaling guarantee','The original matched proof-search pipeline failures remain failed']))
ok('old_generic_scope_limits',all(x in visible for x in ['not a measured reduction in live search memory','not an isolated first-pass census or timing','do not establish a concurrent temporal seal','broad all-exception propagation','The measurement excludes the outer observer/controller'])or 'a general claim of preserving every callback exception unchanged was too broad'in visible)
ok('counter_interval_scope_precise',all(x in visible for x in ['first observed callback interval','unobserved prefix of the second read','also relies on independent Source inspection','not an isolated first-pass census or timing']))
ok('clock_limits_authority_honest',all(x in visible for x in ['Runner interpreter startup and the outer observer prelude precede this gated epoch','failure-only and grants no extra positive work','No Native process exists in this specialized profile','cannot be called success under the old full-JSON serialization guard','No new theorem, learned marking, RL training, production integration or proof-search advantage is established']))
ok('legacy_official_links','https://docs.python.org/3.12/library/exceptions.html#StopIteration'in page.links and 'https://peps.python.org/pep-0479/'in page.links and summary['legacy_StopIteration_identity_tested']is False)
ok('unique_ids_and_noC0',len(page.ids)==len(set(page.ids))and not any(ord(ch)<32 and ch not in '\r\n\t'for ch in s))
ok('LaTeX_renderer_preserved','https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js'in page.assets and not page.forbidden and visible.count(r'\(')==visible.count(r'\)')and visible.count(r'\[')==visible.count(r'\]'))
reader=(P/'reader.html').read_text();priorreader=(D/'prior-publication'/'reader.html').read_text();rx=r'<section id="exact-evidence">[\s\S]*?</section>'
ok('reader_only_owned_section_changes',len(re.findall(rx,reader))==len(re.findall(rx,priorreader))==1 and re.sub(rx,'',reader,count=1)==re.sub(rx,'',priorreader,count=1))
owned=re.search(rx,reader).group(0);ok('reader_current_qualified400m_numbers',all(x in owned for x in ['qualifies for these finite artifacts','400,000,000',r'\(3\)',r'\(135\)','130.757','583.89','adds no theorem or proof-search advantage']))
for q in load(D/'prior-publication-pin-index.json')['files']:ok('whole_prior_snapshot:'+q['name'],desc(D/'prior-publication'/q['name'])['sha256']==q['sha256']and desc(D/'prior-publication'/q['name'])['bytes']==q['bytes'])
for href in page.links+page.assets:
 u=urlsplit(href)
 if u.scheme:continue
 target=(P/unquote(u.path)).resolve()if u.path else P/'exact-evidence.html'
 ok('local_target:'+href,target.is_file())
 if u.fragment and target.suffix=='.html':
  p=Page();p.feed(target.read_text());ok('local_anchor:'+href,unquote(u.fragment)in p.ids)
# Manifest and whole raw archive: packaging decompression only.
ok('whole_archive_pin',desc(P/'exact-evidence-archive.zip')==m['archive']==next(x for x in c['files']if x['path'].endswith('archive.zip'))and m['archive']['sha256']=='9a2a2d55a2d93c7072a0a4d13e53dec593a0238b395f08689d7c0cea0d6974f0'and m['archive']['bytes']==9562527)
ok('all746_manifest_names_unique',len(m['files'])==len({x['archive_name']for x in m['files']})==746)
for q in m['published']:ok('manifest_published:'+Path(q['path']).name,desc(q['path'])==q)
member_results=[]
with zipfile.ZipFile(P/'exact-evidence-archive.zip')as z:
 archive_names=z.namelist();ok('all747_members_exact',len(archive_names)==len(set(archive_names))==747 and set(archive_names)=={x['archive_name']for x in m['files']}|{'README.txt'})
 ok('no_opaque_compressed_Native_or_pyc',not any(n.endswith(('.gz','.zip','.pyc'))for n in archive_names)and all(n.rsplit('/',1)[-1]in ['stdout.bin','stderr.bin']for n in archive_names if n.endswith('.bin')))
 for q in m['files']:
  h=hashlib.sha256();size=0;equal=True
  with z.open(q['archive_name'])as stream,Path(q['path']).open('rb')as original:
   while True:
    b=stream.read(1048576);raw=original.read(1048576)
    if b!=raw:equal=False
    if not b and not raw:break
    h.update(b);size+=len(b)
  ok('whole_raw_ZIP_member:'+q['archive_name'],equal and size==q['bytes']and h.hexdigest()==q['sha256'])
  member_results.append(dict(archive_name=q['archive_name'],path=q['path'],bytes=size,sha256=h.hexdigest(),whole_equal=equal))
 readme=z.read('README.txt').decode();ok('README_current_scope',all(x in readme for x in ['seven separate closed trials','supplied200m and explicit400m distinguished','Fresh reproduction requires a new reviewed finite once-only subject','No integrated search, GCTS/RL advantage, theorem, Model or schema authority']))
listed={q['path']for q in m['files']}
for x in load(D/'plan-authorized-v4.json')['inputs']:ok('archive_full_original:'+x['id'],x['input']['path']in listed)
for k,d in load(D/'eleven-Source-packet-v4.json')['sources'].items():ok('archive_complete11_Source:'+k,d['path']in listed)
actuals=[Path('/private/tmp/gcts-exact-evidence-ROOT-20261019/actual-v4'),Path('/private/tmp/gcts-exact-evidence-ROOT-20261019/actual-v5'),Path('/private/tmp/gcts-fragment-inverse-ROOT-20261019/actual-v3'),Path('/private/tmp/gcts-fragment-inverse-ROOT-20261019/actual-v4'),Path('/private/tmp/gcts-incremental-arena-ROOT-20261019/actual-v1'),D/'actual-v1',D/'actual-v2']
for a in actuals:
 for p in a.iterdir():
  if p.is_file():ok('archive_whole_actual:'+str(p),str(p)in listed)
for name in ['plan-authorized-v1.json','authorization-v1.json','plan-authorized-v4.json','authorization-v4.json','declaration-v1.json','declaration-v2.json','declaration-v4.json','shared-contract-v7.json','shared-contract-v9.json']:
 ok('archive_preserved_once_or_scope:'+name,str(D/name)in listed)
for base in ['plan-authorized-v1-terminal-observation','plan-authorized-v4-terminal-observation']:
 for n in ['CONSUMED.json','terminal.json','stdout.bin','stderr.bin']:ok('archive_observer:'+base+'/'+n,str(D/base/n)in listed)
nextdata=load(P/'exact-evidence-next-design.json');ok('next_design_current_exact',nextdata['current_eleven_Source_packet']==load(D/'eleven-Source-packet-v4.json')and nextdata['shared_contract']==load(D/'shared-contract-v9.json')and nextdata['scope_assessment']==load(O/'private-400m-profile-design-assessment-v1.json')and nextdata['library_profile_assessment']==load('/private/tmp/gcts-direct-reconcile-library-20261019/work-profile-assessment-v1.json')and nextdata['retained_previous_design']==load(D/'prior-publication'/'exact-evidence-next-design.json')and nextdata['integrated']is False and nextdata['integrated_memory_saving_measured']is False)
status=subprocess.run(['git','status','--porcelain','-z'],cwd=PUB,capture_output=True,check=True).stdout.decode().split('\0');changed=[x[3:]for x in status if x]
ok('only9_task_worktree_changes',sorted(changed)==sorted(str(Path(x['path']).relative_to(PUB))for x in c['files']))
# Concrete display-only finding. Detect saved signed zeros without evaluating JS.
zeros=[]
for entry in entries:
 stack=[(entry['packet'],[])]
 while stack:
  value,path=stack.pop()
  if isinstance(value,dict):stack.extend((v,path+[k])for k,v in value.items())
  elif isinstance(value,list):stack.extend((v,path+[i])for i,v in enumerate(value))
  elif type(value)is float and value==0 and math.copysign(1,value)<0:zeros.append(dict(label=entry['label'],path=path))
ok('display_loss_path_concrete',len(zeros)==33 and "textContent=JSON.stringify"in s)
findings=[dict(id='JS_NUMBER_RESTRINGIFICATION_LOSES_LITERAL_TYPES',severity='blocking_display_fidelity',component='exact-evidence.html packet preformatted viewer',cause='Saved packet is parsed as JavaScript numbers, then JSON.stringify(packet,null,2) generates the displayed text. Signed numeric float zero displays as0; integral-float spelling such as0.0 is also collapsed. Raw embedded/downloaded JSON remains exact.',negative_zero_occurrences=33,examples=zeros[:4],required='Generate a complete pretty JSON text string for each packet directly from the retained saved Python JSON serialization and display that string with textContent. Keep parsed packet only for graph metadata. Independently compare all506 text strings with the corresponding exact saved packet serialization, including-0.0/integral floats/large integer lexemes; preserve candidatev1 and issue new frozen report/manifest/archive pins. No actual or qualification rerun is required.')]
checks.append(dict(name='viewer_display_literal_numeric_fidelity',passed=False,expected_negative=True,evidence=findings[0]))
audit=dict(schema='direct-reconciliation-publication-static-audit-v1-negative',saved_data_only=True,scientific_calls=0,module_evaluations=0,codec_calls=0,inverse_calls=0,fixture_calls=0,renderer_calls=0,JavaScript_execution=0,Native_opaque_decodes=0,publication_candidate=desc(cp),files=c['files'],viewer_entries=506,manifest_members=746,archive_members=747,archive_member_results=member_results,checks=checks,checks_passed=sum(x['passed']for x in checks),mismatch_count=1,findings=findings,negative_float_zero_paths=zeros,git_changed_files=changed)
write=lambda p,v:p.write_text(json.dumps(v,sort_keys=True,indent=2,ensure_ascii=False)+'\n')
write(O/'publication-saved-audit-v1-negative.json',audit)
review=dict(schema='direct-reconciliation-publication-saved-review-v1',publication_review_passed=False,human_report_review_passed=False,saved_data_only=True,scientific_calls=0,module_evaluations=0,codec_calls=0,inverse_calls=0,fixture_calls=0,renderer_calls=0,JavaScript_execution=0,Native_opaque_decodes=0,scientific_acceptance=False,actual_execution_authorized=False,author_identity='/root',reviewer_identity='/root/conventional_control_review',publication_candidate=desc(cp),publication_files=c['files'],Root_publication_audit=desc(rp),current_saved_data_review=desc(O/'typed-direct-reconciliation-saved-review-v2.json'),audit=desc(O/'publication-saved-audit-v1-negative.json'),checks_passed=sum(x['passed']for x in checks),mismatch_count=1,findings=findings,viewer_entries=506,prior_entries_retained=219,archive_members=747,raw_manifest_members=746,remaining_claims_and_bindings_passed=True,disposition='Only this inherited packet text-display defect was found. All506 embedded JSON objects and all746 listed raw ZIP members plusREADME match; current/historical claims/counts/units/caps/authority/nav/math/reader scope otherwise pass. Await display-only successor; no scientific data defect or qualification revocation.',ancestry='Control authored reviews/designs and historical unrelated components but not current Root report or exact eleven data Sources. This is independent presentation/package inspection, not own Source certification, codec replay or mathematical checking. Prior reviewed artifacts remain historical, current audit outsideZIP avoids self-reference.',limitations=['Static Source/retained bytes only, no JavaScript/browser/renderer or component calls. Signed-zero loss is determined from the viewer Source numeric conversion semantics and concrete saved numeric values, not a live rendering run.','ZIP decompression is ordinary packaging only. Raw originals, Source files and all seven actual histories were compared; no opaqueNative codec or typed-node inverse was evaluated.','After successor review Root still owns exact task-only publication, HTTP/objecthash and live browser/MathJax checks. No Root/generated/public asset was edited by reviewer.'])
write(O/'typed-publication-saved-review-v1-negative.json',review)
print(json.dumps(dict(review=desc(O/'typed-publication-saved-review-v1-negative.json'),audit=desc(O/'publication-saved-audit-v1-negative.json'),passed_checks=sum(x['passed']for x in checks),findings=1),indent=2))
