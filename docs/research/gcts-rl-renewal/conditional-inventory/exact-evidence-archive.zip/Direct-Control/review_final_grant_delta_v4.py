"""Only saved grant metadata/raw current Source pins and fresh path checks."""
import hashlib,json
from pathlib import Path
D=Path('/private/tmp/gcts-direct-reconcile-ROOT-20261019');O=Path('/private/tmp/gcts-direct-reconcile-peer-20261019');checks=[]
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def desc(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def load(p):return json.loads(Path(p).read_bytes())
def ok(n,v):
 checks.append(dict(name=n,passed=bool(v)))
 if not v:raise AssertionError(n)
def pin(d):ok('rawpin:'+d['path'],desc(d['path'])==d)
for name,sha,size in [('plan-authorized-v4.json','ea3e308e3c2b5cdcb14fa94c071927bca213b9bbc43e1ea25df6a474c15e0b4d',3175),('authorized-index-v4.json','eee1bb1e175410cd8b06866cf48edd783ab469600a8740c8fa53c38063b851e9',8124),('ROOT-final-grant-adoption-v4.json','e097b5a6e61473eb46c560e211db81d6a1b74243095d951752cb2bf1a8c8bd04',1201)]:ok('given_pin:'+name,desc(D/name)==dict(path=str(D/name),bytes=size,sha256=sha))
idx=load(D/'authorized-index-v4.json');oldidx=load(D/'prospective-index-v4.json');adopt=load(D/'ROOT-final-grant-adoption-v4.json');plan=load(D/'plan-authorized-v4.json');draft=load(D/'plan-draft-v4.json')
for k in ['plan','authorization','plan_draft','authorization_draft','declaration','source_packet']:pin(idx[k])
auth=load(idx['authorization']['path']);olda=load(idx['authorization_draft']['path']);decl=load(idx['declaration']['path']);packet=load(idx['source_packet']['path'])
subject={k:v for k,v in plan.items()if k!='authorization'};sha=hashlib.sha256(canonical(subject)).hexdigest()
ok('exact12_subject_preserved',len(subject)==12 and subject=={k:v for k,v in draft.items()if k!='authorization'}==oldidx['subject']==idx['subject'])
ok('exact_subject_sha',sha==idx['subject_sha256']==auth['subject_sha256']==olda['subject_sha256']==adopt['subject_sha256']=='60a537c48d75d4aaa350fb8c24d83531b0bffff1f0d9dbdebf5df51f61d28bfb')
ok('only_plan_auth_descriptor_change',set(plan)==set(draft)and [k for k in plan if plan[k]!=draft[k]]==['authorization']and plan['authorization']==idx['authorization']and draft['authorization']==idx['authorization_draft'])
ok('false0_empty_to_true1',olda['actual_execution_authorized']is False and olda['maximum_actual_invocations']==0 and olda['review_roles']=={}and auth['actual_execution_authorized']is True and auth['maximum_actual_invocations']==1)
ok('auth_original_bindings_exact',all(auth[k]==olda[k]for k in ['schema','author_identity','subject_sha256'])and set(auth)==set(olda)|{'scope'})
ok('only_two_roles_same_disclosed_reviewer',set(auth['review_roles'])=={'Source','plans'}and 'Two roles share one reviewer identity'in auth['scope'])
ok('scope_correct400m_fullclosure',all(t in auth['scope']for t in ['all135 diagnostics','supplied-arena work400m covers main and inherited Library33/Root8 default arenas','independent forest actual30m remain unchanged','Old200m, prior default20m and oldvirtualV3 are not passed','Global gates unchanged','No consumed retry']))
ok('index_one_fresh_actual',idx['actuals_started']==0 and idx['actual_execution_authorized']is True and idx['maximum_actual_invocations']==1 and adopt['actuals_started']==0)
ok('review_descriptors_agree',idx['review_roles']==auth['review_roles']==adopt['review_roles'])
roles={};expected={'Source':('df0e5ab8cb2b278cdf4f878a2207ff3c949eaf6c1300cfff8ef0f7f8f7080033',15788),'plans':('6deb67057041296b17deabdd61777ea185fdf29d375bfdafdd62420da1c645a6',18257)}
for role,d in auth['review_roles'].items():
 pin(d);ok('exact_review:'+role,(d['sha256'],d['bytes'])==expected[role]);v=load(d['path']);roles[role]=v
 ok('role_review_scope:'+role,v['reviewer_identity']=='/root/conventional_control_review'and v['source_only']is True and v['scientific_calls']==0 and v['scientific_acceptance']is False and v['actual_execution_authorized']is False and v['sources']==idx['current_sources'])
ok('Source_schema_pass',roles['Source']['schema']=='exact-evidence-components-Source-review-v1'and roles['Source']['source_review_passed']is True and roles['Source']['author_identities']==['/root','/root/conventional_library'])
ok('plans_schema_pass_subject',roles['plans']['schema']=='exact-evidence-prospective-plan-review-v1'and roles['plans']['prospective_review_passed']is True and roles['plans']['subject']==subject and roles['plans']['subject_sha256']==sha and roles['plans']['declaration']==idx['declaration'])
ok('full11_current_maps',idx['current_sources']==oldidx['current_sources']==packet['sources']and len(packet['sources'])==11)
for d in packet['sources'].values():pin(d)
ok('scope400m_and_other_caps_unchanged',decl['arena_limits']==decl['shared_contract_limits']==roles['Source']['private_caps']==roles['plans']['arena_limits']and decl['arena_limits']['work']==400000000 and decl['forest_inverse_limits']['work']==30000000)
ok('all135_and3_originals_unchanged',roles['plans']['expected_fixture_names']==decl['expected_fixture_names']==packet['expected_fixture_names']and len(decl['expected_fixture_names'])==135 and len(plan['inputs'])==3 and plan['inputs']==draft['inputs'])
ok('original_globals_unchanged',plan['limits']==decl['global_limits']==dict(work_seconds=180,overall_seconds=210,memory_bytes=1073741824,result_bytes=134217728,expanded_bytes=134217728,stdout_bytes=4194304,stderr_bytes=4194304))
ok('old200m_failure_retained',(D/'actual-v1'/'CONSUMED.json').is_file()and plan['actual_directory']==str(D/'actual-v2'))
ok('adoption_binds_exact_indices',adopt['authorized_index']==desc(D/'authorized-index-v4.json')and adopt['old_false_index']==desc(D/'prospective-index-v4.json')and adopt['unchanged_subject']is True and adopt['scientific_calls']==0)
absences=[D/'actual-v2',D/'plan-authorized-v4-terminal-observation',D/'plan-draft-v4-terminal-observation']
for p in absences:ok('fresh_absence:'+p.name,not p.exists()and not p.is_symlink())
ok('fresh_consume_absent',not(D/'actual-v2'/'CONSUMED.json').exists()and not(D/'plan-authorized-v4-terminal-observation'/'CONSUMED.json').exists())
ok('actual_canonical_parent',str(Path(plan['actual_directory']).resolve())==plan['actual_directory']and Path(plan['actual_directory']).parent.is_dir())
def write(p,v):p.write_text(json.dumps(v,sort_keys=True,indent=2,ensure_ascii=False)+'\n')
audit=dict(schema='direct-reconciliation400m-final-grant-delta-audit-v4',saved_metadata_only=True,scientific_calls=0,checks=checks,checks_passed=len(checks),mismatch_count=0)
write(O/'final-grant-delta-audit-v4.json',audit)
review=dict(schema='exact-evidence-final-grant-delta-review-v1',reviewer_identity='/root/conventional_control_review',author_identity='/root',final_grant_delta_review_passed=True,grant_delta_review_passed=True,saved_metadata_only=True,source_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,module_evaluations=0,component_calls=0,fixture_calls=0,codec_calls=0,inverse_calls=0,authorized_index=desc(D/'authorized-index-v4.json'),authorized_plan=idx['plan'],authorization=idx['authorization'],old_false_index=desc(D/'prospective-index-v4.json'),plan_draft=idx['plan_draft'],authorization_draft=idx['authorization_draft'],adoption=desc(D/'ROOT-final-grant-adoption-v4.json'),source_packet=idx['source_packet'],declaration=idx['declaration'],sources=packet['sources'],review_roles=auth['review_roles'],subject=subject,subject_sha256=sha,checks_passed=len(checks),mismatch_count=0,findings=[],audit=desc(O/'final-grant-delta-audit-v4.json'),fresh_absent_paths=[str(p)for p in absences],reviewer_count=1,review_role_count=2,disclosure='Two scoped Source/plans receipts share the same explicitly named Control reviewer. Control authored none of these exact current11 Sources or Root plan/grant metadata; historical other-component/design/review ancestry is retained. No extra reviewer or own-source certification is implied.',scope='Authorization-descriptor-only successor of exact reviewed60a537c4…12-field subject for supplied-arena400m main/default diagnostic contexts; all11 Sources/135groups/3originals/other private/global limits unchanged. Old200m consumed failure remains immutable.',limitations=['Narrow metadata/rawpins/freshness review only. No new Source-body or dynamic qualification claim, no component/fixture/codec/inverse calls and no input data decoding.','This review itself does not launch or authorize execution by Control. Root retains fresh raw/process preflight and exactly-one activation responsibility; failure/UNKNOWN must be retained without consumed retry.'],next_action='Stop all tools and remain idle until Root confirms authoritative terminal and cohort closure.')
write(O/'typed-final-grant-delta-review-v4.json',review)
print(json.dumps(dict(review=desc(O/'typed-final-grant-delta-review-v4.json'),audit=desc(O/'final-grant-delta-audit-v4.json'),checks=len(checks)),indent=2))
