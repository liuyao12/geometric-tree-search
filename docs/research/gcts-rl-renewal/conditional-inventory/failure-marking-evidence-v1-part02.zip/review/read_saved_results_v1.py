"""Read saved JSON only; no scientific module imports or checker replay."""
import collections
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT/'data'
def text(x):
    return json.dumps(x,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)
def wire(x):return (text(x)+'\n').encode('ascii')
def sha(x):return hashlib.sha256(wire(x)).hexdigest()
def read(p):
    with (gzip.open(p,'rt') if p.suffix=='.gz' else p.open()) as f:return json.load(f)
def pin(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return dict(path=str(p.relative_to(ROOT)),bytes=p.stat().st_size,sha256=h.hexdigest())

class Stream:
    """Use the stdlib decoder one top-level field/result at a time."""
    def __init__(self,f):self.f=f;self.buf='';self.eof=False;self.decoder=json.JSONDecoder()
    def fill(self):
        chunk=self.f.read(1048576)
        if chunk:self.buf+=chunk
        else:self.eof=True
    def ws(self):
        while True:
            self.buf=self.buf.lstrip()
            if self.buf or self.eof:return
            self.fill()
    def take(self,char):
        self.ws();assert self.buf.startswith(char),(char,self.buf[:30]);self.buf=self.buf[len(char):]
    def peek(self):self.ws();return self.buf[:1]
    def value(self):
        self.ws()
        while True:
            try:value,end=self.decoder.raw_decode(self.buf)
            except json.JSONDecodeError:
                if self.eof:raise
                self.fill();continue
            if end==len(self.buf) and not self.eof:self.fill();continue
            if end<len(self.buf) and self.buf[end] not in ' \t\r\n,:}]':
                if self.eof:raise ValueError('JSON value boundary')
                self.fill();continue
            self.buf=self.buf[end:];return value

cohort=read(DATA/'cohort-frozen-v1.json');cases={c['id']:c for c in cohort['cases']}
lanes=cohort['protocol']['lanes'];H=cohort['protocol']['depth']
metrics={lane:collections.Counter() for lane in lanes};matrix={};selected_by={};scopes={};defs={};acquisitions={};classification=collections.Counter();assurance=collections.Counter();preparation_seconds=acquisition_seconds=learning_seconds=0.
for cid in cases:
    prep=read(DATA/'prepared'/(cid+'.json.gz'));a=read(DATA/'markings'/(cid+'.json.gz'));c=prep['compiled'];acquisitions[cid]=a
    assert prep['status']=='PREPARED' and prep['factory_check']['status']=='VERIFIED'
    assert all(z['status']=='VERIFIED' for z in prep['zero_checks']);assurance['native_zero_checks']+=len(prep['zero_checks'])
    preparation_seconds+=prep['seconds'];acquisition_seconds+=a['seconds'];learning_seconds+=a['learned']['seconds']
    payload=dict(schema='FM-native-producer-scope-v1',depth_semantics='FM-rooted-tree-height-v1',compiled_schema=c['schema'],compiled_version=c['version'],theory=c['theory'],registry=dict(formulas=c['logical_basis']['formulas'],colors=c['logical_basis']['colors']),zero_instances=c['zero_instances'],mp_index=c['mp_index'],gen_index=c['gen_index'])
    scope=sha(payload);scopes[cid]=scope;cert=a['learned']['certificate'];receipt=a['absence_check'];assert receipt['status']==a['model_check']['status']=='VERIFIED'
    assert scope==cert['scope_sha256']==receipt['scope_sha256']==a['model_check']['scope_sha256']
    assert receipt['certificate_sha256']==sha(cert)
    labels=a['learned']['classifications'];assert [(x['fid'],x['remaining']) for x in labels]==[tuple(x) for x in a['learned']['requests']]
    assert cert['requests']==[[x['fid'],x['remaining']] for x in labels if x['status']=='ABSENT']==receipt['negative_requests']
    assert receipt['checked_node_count']==len(cert['nodes']) and receipt['request_count']==len(cert['requests'])
    assert receipt['checked_nodes']==[list(x) for x in sorted((n['fid'],n['remaining']) for n in cert['nodes'])]
    assert receipt['blockers_checked']==sum(len(n['blockers']) for n in cert['nodes'])
    classified={(x['fid'],x['remaining']):x['status'] for x in labels};assert len(classified)==len(labels)
    positives=a['positive_checks'];assert {(x['fid'],x['remaining']) for x in positives}=={k for k,v in classified.items() if v=='PROVED'}
    for x in positives:
        assert x['tree_check']['status']==x['host_check']['status']=='VERIFIED'
        assert x['tree_check']['proof'][-1]['formula']==c['logical_basis']['formulas'][x['fid']]
    seed=[['',c['logical_basis']['colors'][c['goal_id']]]]+[[text(['FM-port-v1',scope,f,r]),'0'] for f,r in cert['requests']]
    assert a['mark_model']['seed']==dict(t=[['',1]],m=sorted(seed))
    assert a['model_check']['model_sha256']==sha(a['mark_model'])
    identity=json.loads(a['mark_model']['inventory']['identity']);core=sha({k:v for k,v in c.items() if k not in ('costs','scope')})
    base=sha(dict(schema='Z-anchored-proof-inventory-identity-v1',version=a['mark_model']['version'],compiled_core_sha256=core,depth=H))
    assert identity==['FM-provider-v1',base,'MARKS',sha(cert['requests']),scope]
    classification.update(x['status'] for x in labels);assurance['absence_certificates']+=1;assurance['mark_model_checks']+=1;assurance['positive_classification_checks']+=len(positives);assurance['negative_evidence_nodes']+=len(cert['nodes'])
    d={text(['zero',z['id']]):(z['formula_id'],[]) for z in c['zero_instances']}
    d.update({text(['mp',p,x,o]):(o,[x,p]) for p,x,o in c['mp_index']});d.update({text(['gen',p,b,v]):(p,[b]) for p,b,v in c['gen_index']});defs[cid]=d

seen=set();metadata={}
def consume(row):
    cid,lane,a=row['case'],row['lane'],row['answer'];key=(cid,lane);assert cid in cases and lane in lanes and key not in seen;seen.add(key)
    disk=gzip.decompress((DATA/'evaluation'/(cid+'--'+lane+'.json.gz')).read_bytes());assert hashlib.sha256(disk).digest()==hashlib.sha256(wire(row)).digest()
    raw=read(DATA/'raw-answers'/(cid+'--'+lane+'.json.gz'));assert sha(raw)==sha({k:a[k] for k in raw});assurance['exact_raw_answer_joins']+=1
    m=metrics[lane];m['positions']+=1;m[a['status']]+=1;matrix.setdefault(cid,{})[lane]=a['status'];checked='checked' in a;m['checked']+=checked
    for name in ('search_seconds','assurance_seconds','checked_search_seconds','accounted_reused_preparation_seconds','accounted_reused_mark_acquisition_seconds','accounted_pipeline_seconds'):m[name]+=a.get(name,0)
    assert abs(a['checked_search_seconds']-a['search_seconds']-a['assurance_seconds'])<1e-9
    assert abs(a['accounted_pipeline_seconds']-a['checked_search_seconds']-a['accounted_reused_preparation_seconds']-a['accounted_reused_mark_acquisition_seconds'])<1e-9
    assert abs(a['accounted_reused_mark_acquisition_seconds']-(acquisitions[cid]['seconds'] if lane.startswith(('MARKED_','FILTER_')) else 0))<1e-9
    if a['status']=='UNKNOWN':m['UNKNOWN:'+str(a.get('reason'))]+=1;assert not a['selected']
    m['outside_search_window']+=not a['within_search_window']
    if checked:
        ch=a['checked'];assert ch['tree_check']['status']==ch['host_check']['status']=='VERIFIED'
        assert set(ch['tree']['selected'])==set(a['selected']);m['proof_lines']+=len(ch['proof']);m['checked_within_window']+=a['within_search_window'];selected_by[key]=a['selected']
        if lane.startswith(('MARKED_','FILTER_')):
            negative={tuple(x) for x in acquisitions[cid]['learned']['certificate']['requests']}
            for value in a['selected']:
                site,did=json.loads(value)
                for f in defs[cid][did][1]:assert (f,H-len(site)-1) not in negative
    records=a.get('guidance',{}).get('proposals',[]);fchecks=a['family_checks'];dchecks=a['decorated_family_checks'];assert len(records)==len(fchecks)
    assert len(dchecks)==(len(records) if lane.startswith(('MARKED_','FILTER_')) else 0)
    for p,r in zip(records,fchecks):assert r['status']==r['base']['status']=='VERIFIED' and r['family_id']==p['family']
    for r in dchecks:assert r['status']=='VERIFIED' and r['scope_sha256']==scopes[cid]
    m['family_checks']+=len(fchecks);m['decorated_family_checks']+=len(dchecks)
    qchecks=a['sampled_query_checks'];m['query_checks']+=len(qchecks)
    if lane.startswith('MARKED_'):
        ev=a.get('provider_evidence',{});packets=ev.get('records',[]);chosen=packets[:1]+(packets[-1:] if len(packets)>1 else []);assert len(chosen)==len(qchecks)
        m['completed_queries']+=ev.get('total',0);m['retained_queries']+=len(packets)
        for packet,r in zip(chosen,qchecks):
            assert r['status']=='VERIFIED' and r['scope_sha256']==scopes[cid]
            assert r['context_sha256']==packet['reply']['context_sha256']==sha(packet['query'])
            assert r['potential_count']==packet['reply']['certificate']['potential_count'] and r['compatible_count']==len(packet['reply']['placements'])
            querymarks=dict(packet['query']['marks']);assert all(querymarks.get(p)==v for p,v in acquisitions[cid]['mark_model']['seed']['m'])
        if checked:
            r=a['marked_solution_check'];assert r['status']=='VERIFIED' and r['scope_sha256']==scopes[cid] and r['model_sha256']==sha(acquisitions[cid]['mark_model']);m['marked_solution_checks']+=1
    else:assert not qchecks
    provider=a.get('provider',{});m['provider_mark_rejection_checks']+=provider.get('removed_by_mark_agreement',0);m['provider_table_rejection_checks']+=provider.get('removed_by_table_lookup',0);m['wrapper_through_charged_work']+=provider.get('charged_adapter_work',0)

with gzip.open(DATA/'results-v1.json.gz','rt') as f:
    stream=Stream(f);stream.take('{')
    while True:
        key=stream.value();stream.take(':')
        if key=='results':
            stream.take('[')
            if stream.peek()!=']':
                while True:
                    consume(stream.value())
                    if stream.peek()!=',':break
                    stream.take(',')
            stream.take(']')
        else:metadata[key]=stream.value()
        if stream.peek()!=',':break
        stream.take(',')
    stream.take('}');assert stream.peek()=='' and stream.eof
assert seen=={(cid,lane) for cid in cases for lane in lanes}
assert metadata['schema']=='FM-failure-marking-study-v1' and sha(metadata['cohort'])==sha(cohort)
assert len(metadata['acquisitions'])==len(cases)
for x in metadata['acquisitions']:
    a=acquisitions[x['case']];assert sha(x['learned'])==sha(a['learned']) and sha(x['absence_check'])==sha(a['absence_check'])
for cid,states in matrix.items():
    for lane,status in states.items():
        if status in ('SAT','DERIVABLE'):assert states['DP_CONTROL'] not in ('UNSAT','NOT_DERIVABLE')
        if status in ('UNSAT','NOT_DERIVABLE'):assert states['DP_CONTROL'] not in ('SAT','DERIVABLE')
comparisons={}
for name,base,marked in [('lexical','BASE_LEXICAL_GCTS','MARKED_LEXICAL_GCTS'),('heuristic','BASE_HEURISTIC_GCTS','MARKED_HEURISTIC_GCTS'),('shape','BASE_RL_SHAPE_GCTS','MARKED_RL_SHAPE_GCTS'),('direct_filter','FILTER_HEURISTIC_GCTS','MARKED_HEURISTIC_GCTS')]:
    comparisons[name]=dict(base=base,marked=marked,marked_only_checked=[c for c in cases if (c,marked) in selected_by and (c,base) not in selected_by],base_only_checked=[c for c in cases if (c,base) in selected_by and (c,marked) not in selected_by],identical_checked_selections=sum(selected_by[c,base]==selected_by[c,marked] for c in cases if (c,base) in selected_by and (c,marked) in selected_by),common_checked=sum((c,base) in selected_by and (c,marked) in selected_by for c in cases))
example=read(ROOT/'review/reconstructed-mark-exclusion-v1.json')
out=dict(schema='FM-independent-finished-results-review-v1',status='PASS_SAVED_COMPLETE_STUDY',scope='Stdlib-only saved-data arithmetic, hashes, receipt associations and explicitly labeled candidate reconstruction. No scientific Source import/execution, checker replay, proof search or rerun.',inputs=[pin(DATA/'results-v1.json.gz'),pin(DATA/'cohort-frozen-v1.json')],coverage=dict(cases=len(cases),lanes=len(lanes),positions=len(seen),raw_answers_joined=assurance['exact_raw_answer_joins']),classification=dict(requested=sum(classification.values()),statuses=dict(classification),activated_negative_requests=classification['ABSENT'],internal_negative_evidence_nodes=assurance['negative_evidence_nodes'],meaning='All requested resolved labels are used; internal certificate DAG nodes are evidence lemmas, not extra requested samples. No holdout or universal-failure claim.'),assurance=dict(assurance),metrics={k:dict(v) for k,v in metrics.items()},case_statuses=matrix,comparisons=comparisons,costs=dict(observed_common_preparation_seconds=preparation_seconds,observed_shared_acquisition_seconds=acquisition_seconds,classification_subphase_seconds=learning_seconds,reported_total_seconds_before_final_summary_export=metadata['total_seconds'],prior_policy_training_seconds_reused=metadata['trained_policy'].get('seconds'),scope='Lane accounted_pipeline_seconds repeats measured shared preparation/acquisition as an estimate; it is not a repeated cold trial. Per-lane assurance is included. Earlier policy/bank acquisition is reused rather than newly trained. Wrapper-through work includes base work and provider rejection counters may include partial attempts/repeated candidates.'),mark_exclusion_example=dict(reference=pin(ROOT/'review/reconstructed-mark-exclusion-v1.json'),case=example['case'],lane=example['lane'],retained_query_index=example['retained_query_index'],query_point=example['query_point'],candidate_cid=example['candidate_cid'],H=H,remaining=example['remaining'],conflicts=example['conflicts'],scope='Candidate reconstructed from declared native definitions and an actual query; never claimed observed selected or returned. Ordinary t/m checks pass; added global ports alone conflict with seeded certified zeros.'),interpretation='Exact bounded unary failure tabling represented by literal m-values. This establishes neither new joint/dynamic geometric constraints nor Turtle learning. Outcome/cost differences from one timed run do not establish GCTS or ATP superiority. Main query audits cover only explicit first/last retained samples, not full large graphs.')
legacy_path=ROOT/'review/tiny-exhaustive-graph-audit-v1.json'
legacy=read(legacy_path)
out['assurance_totals']=dict(checked_proofs=sum(m['checked'] for m in metrics.values()),family_receipts=sum(m['family_checks'] for m in metrics.values()),decorated_partial_receipts=sum(m['decorated_family_checks'] for m in metrics.values()),marked_solution_receipts=sum(m.get('marked_solution_checks',0) for m in metrics.values()),sampled_query_receipts=sum(m['query_checks'] for m in metrics.values()))
out['conformance_limits']=dict(legacy_full_graph_audit=dict(reference=pin(legacy_path),status=legacy['receipt']['status'],reason=legacy['receipt']['reason'],intended_observations=legacy['observations'],declared_universe_size=legacy['universe_size'],coordinator_diagnosis='Unsupported legacy growing-result/eager-contact ABI versus the indexed-IP evidence format.',assessment='No successful complete independent intermediate Q/C/scheduler/rollback audit is established by this REJECTED receipt. Its scope text describes the intended audit, not a VERIFIED result. It does not demonstrate that the separately verified native proofs or complete marked solution checks are invalid.'),covered='Complete tiny incident packets per qualification; main first/last retained query samples; selected marked t/m solutions; current native proof and family receipts. Full main intermediate-graph conformance remains open.')
target=ROOT/'review/results-independent-review-v1.json';target.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(output=pin(target),coverage=out['coverage'],classification=out['classification'],metrics=out['metrics'],comparisons=comparisons,costs=out['costs']),sort_keys=True))
