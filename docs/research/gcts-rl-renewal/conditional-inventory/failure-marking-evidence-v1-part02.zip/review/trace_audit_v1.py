"""Post-run independent exhaustive tiny frontier/scheduler/rollback audit."""
import gzip
import json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'source'),str(ROOT/'reference')]
from proof_core_v1 import load_modules,AUDIT,write,text
from marked_point_checker_v1 import Checker

def main():
    raw=json.loads(gzip.decompress((ROOT/'qualification-run-v1/qualification-result.json.gz').read_bytes()))
    c,H=raw['compiled'],raw['depth'];cert=raw['learned']['certificate']
    checker=Checker(c,H,cert['scope_sha256'],cert['requests']);universe=[]
    for depth in range(H+1):
        for number in range(1<<depth):
            site=format(number,'0%db'%depth) if depth else ''
            for did,(output,premises) in checker.defs.items():
                if premises and depth==H:continue
                universe.append(checker.placement(text([site,did])))
    modules=load_modules();answer=raw['answers']['MARKS']
    receipt=modules['growing_proof_verifier_v2'].verify_result(answer['model'],answer['result'],
        universe=universe,observations=answer['audit'],limits=AUDIT)
    write(ROOT/'review/tiny-exhaustive-graph-audit-v1.json',dict(receipt=receipt,universe_size=len(universe),
        observations=len(answer['audit']),scope='Every retained tiny event/state checked against the independently rebuilt complete finite decorated placement universe, including global scheduling and exact rollback. No scientific search replay.'))
    print(json.dumps(dict(status=receipt['status'],reason=receipt.get('reason'),universe_size=len(universe),observations=len(answer['audit']))))

if __name__=='__main__':main()
