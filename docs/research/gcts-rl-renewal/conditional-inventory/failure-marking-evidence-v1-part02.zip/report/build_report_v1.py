"""Passive FM reader: saved JSON only, no scientific imports or re-execution."""
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def text(x):
    return json.dumps(x, sort_keys=True, ensure_ascii=True, separators=(',', ':'), allow_nan=False)


def load(path):
    b = path.read_bytes()
    return json.loads(gzip.decompress(b) if path.suffix == '.gz' else b), dict(path=str(path), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())


def checked(a):
    c = a.get('checked')
    if c and (c['host_check']['status'] != 'VERIFIED' or c['tree_check']['status'] != 'VERIFIED'):
        raise ValueError('Unverified displayed certificate')
    return bool(c)


def build():
    raw, ref = load(ROOT / 'data/results-v1.json.gz')
    if raw['schema'] != 'FM-failure-marking-study-v1':
        raise ValueError('Unexpected completed study schema')
    frozen = raw['cohort']; lanes = frozen['protocol']['lanes']; cases = frozen['cases']
    if len(cases) != 16 or len(lanes) != 9:
        raise ValueError('Expected sixteen targets and nine methods')
    counts = {k: dict(verified=0, finite=0, unknown=0, search=0., assurance=0., accounted_estimate=0., timed=0,
                     branches=0,forced=0,backtracks=0,registered=0,max_graph_edges=0,mark_contacts_removed=0,table_contacts_removed=0) for k in lanes}
    index, rows, readers = {}, [], []
    priority = ['MARKED_HEURISTIC_GCTS', 'MARKED_RL_SHAPE_GCTS', 'MARKED_LEXICAL_GCTS', 'DP_CONTROL', 'MEMO_CLUSTER_DFS_CONTROL']
    for row in raw['results']:
        cid, lane, a = row['case'], row['lane'], row['answer']
        if (cid, lane) in index or lane not in counts:
            raise ValueError('Duplicate/unexpected method position')
        index[cid, lane] = a
        kind = 'verified' if checked(a) else 'finite' if a['status'] in ('UNSAT', 'NOT_DERIVABLE') else 'unknown'
        if a['status'] in ('SAT', 'DERIVABLE') and kind != 'verified':
            raise ValueError('Positive lacks independent checks')
        c = counts[lane]; c[kind] += 1
        for source, target in [('search_seconds', 'search'), ('assurance_seconds', 'assurance'), ('accounted_pipeline_seconds', 'accounted_estimate')]:
            c[target] += a.get(source, 0.)
        c['timed'] += 'search_seconds' in a
        s=a.get('stats',{});p=a.get('provider',{})
        for source,target in [('branches','branches'),('forced','forced'),('backtracks','backtracks'),('candidate_registrations','registered')]:
            c[target]+=s.get(source,0)
        c['max_graph_edges']=max(c['max_graph_edges'],s.get('peak_edges',0))
        c['mark_contacts_removed']+=p.get('removed_by_mark_agreement',0)
        c['table_contacts_removed']+=p.get('removed_by_table_lookup',0)
        rows.append(dict(case=cid, lane=lane, status=a['status'], kind=kind,
            seconds=a.get('search_seconds'), assurance=a.get('assurance_seconds'),
            reason=a.get('reason') or a.get('control', {}).get('reason') or a.get('preparation', {}).get('refusal', {}).get('reason')))
    if set(index) != {(c['id'], k) for c in cases for k in lanes}:
        raise ValueError('Incomplete results; do not fabricate outcomes')
    demos = []
    for case in cases:
        cid = case['id']; proof = None
        for lane in priority + [k for k in lanes if k not in priority]:
            a = index[cid, lane]
            if checked(a):
                c = a['checked']
                if c['proof'][-1]['formula'] != case['problem']['goal']:
                    raise ValueError('Displayed goal mismatch')
                proof = dict(lane=lane, lines=c['proof'], checks=dict(host=c['host_check'], tree=c['tree_check']))
                break
        readers.append(dict(case=case, proof=proof))
        mark_path = ROOT / 'data/markings' / (cid + '.json.gz')
        if not mark_path.is_file():
            continue  # Preparation UNKNOWN remains in the results table.
        m, mref = load(mark_path); learned = m['learned']; cert = learned['certificate']
        if m['absence_check']['status'] != 'VERIFIED' or m['model_check']['status'] != 'VERIFIED':
            raise ValueError('Failure marks lack independent certification')
        labels = {s: sum(c['status'] == s for c in learned['classifications']) for s in ('ABSENT', 'PROVED', 'UNKNOWN')}
        if not cert['requests']:
            demos.append(dict(case=cid, labels=labels, requests=m['requested_count'], nodes=len(cert['nodes']), source=mref,
                              classification_seconds=learned['seconds'], acquisition_seconds=m['seconds']))
            continue
        prep, _ = load(ROOT / 'data/prepared' / (cid + '.json.gz')); c = prep['compiled']; forms = c['logical_basis']['formulas']
        defs = []
        for z in c['zero_instances']:
            defs.append(dict(id=text(['zero', z['id']]), output=z['formula_id'], premises=[]))
        for h, a, out in c['mp_index']:
            defs.append(dict(id=text(['mp', h, a, out]), output=out, premises=[a, h]))
        for h, b, v in c['gen_index']:
            defs.append(dict(id=text(['gen', h, b, v]), output=h, premises=[b]))
        table = {d['id']: d for d in defs}; nodes = {(n['fid'], n['remaining']): n for n in cert['nodes']}
        consuming, contexts = {}, []
        for d in defs:
            for premise in set(d['premises']):
                consuming.setdefault(premise, []).append(d)
        for lane in lanes:
            if not lane.startswith('MARKED_'):
                continue
            a = index[cid, lane]; evidence = a.get('provider_evidence', a.get('provider_queries', {})); recs = evidence.get('records', [])
            for record in ([recs[0], recs[-1]] if len(recs) > 1 else recs):
                query = record['query']
                contexts.append((lane, query, dict(query['marks']), dict(query['totals'])))

        def annotated_request(pair):
            fid, remaining = pair
            port = text(['FM-port-v1', cert['scope_sha256'], fid, remaining])
            annotations = []
            for lane, query, marks, totals in contexts:
                point = query['point']
                if marks.get(port) != '0':
                    continue
                for site in dict.fromkeys([point, point[:-1]]):
                    if len(site) != frozen['protocol']['depth'] - remaining - 1:
                        continue
                    if any(a['site'] == site for a in annotations):
                        continue  # Never depict duplicate records as distinct tree addresses.
                    for d in consuming.get(fid, []):
                        support = [site] + [site + str(i) for i in range(len(d['premises']))]
                        values = [d['output']] + d['premises']
                        if point not in support or any(totals.get(p, 0) + 1 > 2 for p in support):
                            continue
                        if any(p in marks and marks[p] != c['logical_basis']['colors'][v] for p, v in zip(support, values)):
                            continue
                        annotations.append(dict(site=site, cid=text([site, d['id']]), definition=d['id'], lane=lane,
                            query_point=point, query_seed_value='0', placement_request='1',
                            scope='Native base candidate reconstructed at a recorded query address; not claimed returned or selected.'))
                        if len(annotations) == 2:
                            return annotations
                        break
            return annotations

        # Prefer a genuinely recorded-query annotation; within that class choose
        # the most blockers. If none match, retain the largest schematic node.
        ranked = sorted(cert['requests'], key=lambda p: (-len(nodes[tuple(p)]['blockers']), p[0], p[1]))
        pair, annotations = ranked[0], []
        for candidate in ranked:
            found = annotated_request(candidate)
            if found:
                pair, annotations = candidate, found
                break
        fid, remaining = pair; node = nodes[fid, remaining]
        port = text(['FM-port-v1', cert['scope_sha256'], fid, remaining])
        if dict(m['mark_model']['seed']['m']).get(port) != '0':
            raise ValueError('Displayed negative port is not literally seeded zero')
        consumers = consuming.get(fid, [])
        blockers = [dict(definition=did, failed_child=i,
            dependency=None if i is None else [table[did]['premises'][i], remaining - 1]) for did, i in node['blockers']]
        demos.append(dict(case=cid, labels=labels, requests=m['requested_count'], nodes=len(cert['nodes']), source=mref,
            classification_seconds=learned['seconds'], acquisition_seconds=m['seconds'],
            selection='recorded-query-compatible consumer, then most blockers' if annotations else 'most blockers; schematic fallback only',
            fid=fid, remaining=remaining, formula=forms[fid], port=port, seed='0', scope=cert['scope_sha256'],
            blockers=blockers, consumer=annotations[0]['definition'] if annotations else consumers[0]['id'] if consumers else None,
            annotations=annotations[:2],
            absence_receipt=m['absence_check'], model_receipt=m['model_check']))
    demos.sort(key=lambda d: (bool(d.get('annotations')), len(d.get('blockers', []))), reverse=True)
    qpath = ROOT / 'qualification-run-v1/completion.json'
    qualification, qref = load(qpath) if qpath.is_file() else ({'status': 'NOT_RECORDED'}, None)
    data = dict(schema='FM-passive-reader-summary-v1', input=ref, lanes=lanes, counts=counts, rows=rows,
        readers=readers, markings=demos, qualification=qualification, qualification_source=qref,
        costs=dict(total=raw['total_seconds'], preparation=sum(p['seconds'] for p in raw['preparation']),
            classification_search=sum(a['learned']['seconds'] for a in raw['acquisitions']),
            acquisition=sum(a['seconds'] for a in raw['acquisitions']), search=sum(c['search'] for c in counts.values()),
            assurance=sum(c['assurance'] for c in counts.values())), protocol=frozen['protocol'],
        preparation=raw['preparation'], environment=raw['environment'], pins=frozen['pins'])
    encoded = text(data)
    out = ROOT / 'report'
    with (out / 'results-summary-v1.json').open('x') as f:
        f.write(encoded + '\n')
    with (out / 'failure-markings-v1.html').open('x') as f:
        f.write(HTML.replace('__DATA__', encoded.replace('<', '\\u003c').replace('&', '\\u0026')))
    print(text(dict(status='MATERIALIZED', positions=len(rows), output=str(out))))


HTML = r'''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Certified failure markings · GCTS</title>
<script>window.MathJax={tex:{inlineMath:[['\\(','\\)']],displayMath:[['\\[','\\]']]}};</script><script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-svg.js"></script>
<style>:root{font:16px/1.6 system-ui,sans-serif;color:#203443;background:#f1f5f7}*{box-sizing:border-box}body{margin:0}main{max-width:1280px;margin:auto;padding:32px 24px 70px}h1{font-size:clamp(32px,5vw,50px);line-height:1.12;max-width:24ch}h2{font-size:24px}a{color:#14658a}.panel{background:white;border:1px solid #d5e0e7;border-radius:12px;padding:23px;margin:22px 0;min-width:0}.scope{border-left:5px solid #bb852b;background:#fffdf6}.muted{color:#546e7e}.scroll,.formula{overflow-x:auto;max-width:100%}.formula{padding:5px 0;overflow-y:hidden}table{border-collapse:collapse;width:100%;font-size:12px}td,th{padding:9px;text-align:left;vertical-align:top;border-bottom:1px solid #dae5ec}th{background:#edf4f7}.tag{font:700 11px ui-monospace,monospace;padding:4px;border-radius:4px;background:#fff0cf;display:inline-block}.verified{background:#dcefe3}.finite{background:#eee5f5}select,button{font:inherit;padding:7px;border:1px solid #a5bbc8;border-radius:5px;background:white;max-width:100%}button{cursor:pointer}.controls{display:flex;gap:13px;flex-wrap:wrap;align-items:end}label{display:flex;flex-direction:column;gap:5px;font-weight:650}.line{border-top:1px solid #dae4eb;padding:16px 0}.line p{color:#526c7b}.mark-flow{display:grid;grid-template-columns:1fr 70px 1fr;gap:12px;align-items:center}.port{padding:20px;border:3px solid #b35060;border-radius:10px;background:#fff3f4;overflow-wrap:anywhere}.request{border-color:#3d83b5;background:#eff7ff}.arrow{font-size:30px;text-align:center;color:#8553a1}.badge0{color:#a7324d;font-weight:750}.badge1{color:#286ba3;font-weight:750}code,pre{font:12px/1.5 ui-monospace,monospace;overflow-wrap:anywhere}pre{white-space:pre-wrap;background:#eff4f7;padding:13px;border-radius:6px}details{margin:15px 0}summary{cursor:pointer;font-weight:650}.empty{border:1px dashed #a8bfce;padding:16px}.costs{display:flex;gap:12px;flex-wrap:wrap}.costs>div{padding:12px;background:#edf5f8;border-radius:7px}.costs strong{display:block;font-size:20px}mjx-container{max-width:100%}@media(max-width:700px){main{padding:20px 12px}.panel{padding:15px}.mark-flow{grid-template-columns:1fr}.arrow{transform:rotate(90deg)}}</style><main>
<p class="muted">GCTS research · certified unary failures as point marks</p><h1>Can certified failure markings improve the next search?</h1><p>Bounded native producer searches supply proof-backed absence certificates. Their failures become literal mark-only constraints before subsequent search; every unresolved classification remains unknown.</p><p><a href="receptor-families-v1.html">Previous receptor-family study</a> · <a href="failure-marking-evidence-v1.html">Evidence and full records</a> · <a href="failure-marking-results-summary-v1.json">Reader data</a></p>
<section class="panel"><h2>Recorded outcome</h2><p id="headline"></p><div id="coverage" class="scroll"></div></section>
<section class="panel scope"><h2>What these markings mean</h2><p>This is certified unary failure tabling represented by literal point markings. A key names one literal formula, remaining proof height and fixed theory/basis scope. It is not Turtle pair-corona inference, a learned dynamic joint constraint or an unrestricted nonprovability result. Only requested certified absences receive seed marks; internal negative DAG nodes are supporting evidence.</p><p>Storing and reusing subgoal results is established in tabled logic programming; see the <a href="https://xsb.sourceforge.net/shadow_site/manual1/node31.html">official XSB manual on tabling</a>. Our unary failed-port table is an encoding comparison, not an invention of memoization or a claim to reproduce full XSB/SLG semantics. E, Vampire and XSB were not run; no standard ATP comparison is made.</p><p>The ordinary engine compares assigned marking values and keeps complete primitive domains. The direct-table filter uses the same certificates as a conventional comparator. The frozen RF family bank and shape policy are reused; there is no new RL training.</p><p>The point model uses bounded binary proof addresses. Each rule and the root seed contribute one half of capacity at their declared positive points. Failure ports carry marking data only and are outside the filling target. This is a specialized reduction in proof space, not a homogeneous plane tile set.</p><p>These runs search semantic point-proof trees. The preceding fixed-palette circuit remains a separate encoding backend: no new literal Wang-grid search or raw-NAND compilation is claimed here.</p></section>
<section class="panel"><h2>Search mechanics</h2><p>Point-engine totals across the cohort, including budget-stopped prefixes. Lower totals alone do not establish acceleration. The graph column is the maximum over cases. Rejected contacts count repeated provider encounters, not distinct candidate identities. Conventional DFS and DP use different bookkeeping; their node counts are retained in the archive.</p><div id="telemetry" class="scroll"></div></section><section class="panel"><h2>All sixteen cases and nine methods</h2><div id="results" class="scroll"></div></section>
<section class="panel" id="markings"><h2>One actual certified failure</h2><label>Saved marking case<select id="mark-case"></select></label><p id="mark-info"></p><div id="failure-formula" class="formula"></div><div class="mark-flow"><div class="port"><strong>Fixed seed · <span class="badge0">value 0</span></strong><pre id="literal-port"></pre><p>No proof in the declared producer basis fits this height.</p></div><div class="arrow">←</div><div class="port request"><strong>Producer premise · <span class="badge1">value 1</span></strong><p>Every instance needing this premise at the same remaining height requests the same global port. The unequal assigned values exclude that instance.</p><code id="consumer"></code></div></div><p class="muted">The diagram is a schematic of the fixed adapter. Candidate annotations below use actual saved query contexts; an excluded native candidate can be reconstructed even though it is absent from the marked reply. Reconstruction is labeled and is not a claim that the candidate was returned or selected.</p><div id="annotations"></div><details><summary>Every producer blocker for this certificate node</summary><div id="blockers" class="scroll"></div></details><details><summary>Literal independent receipts and selected certificate node</summary><pre id="mark-json"></pre></details></section>
<section class="panel scope"><h2>Preservation proposition · human metatheory</h2><p>Fix a context-free finite producer grammar, rooted proof-height bound \(H\), and independently certified absence keys \(N\). At producer site \(s\), decorate each premise \(F\) with value \(1\) at key \((F,H-|s|-1)\), and seed keys in \(N\) with value \(0\). This preserves exactly the complete rooted proof placement sets under projection.</p><p>A complete original proof supplies each required premise subtree within the stated remaining height, so it cannot request an absent key. All added placement values are \(1\), hence agree with one another, and occupancy is unchanged. Conversely, projecting a decorated proof removes only the added marks and leaves a valid original proof. Partial states need not be preserved: eliminating their impossible extensions is the intended pruning.</p><p>The keys are scoped to context-free literal syntax, theory, basis and depth semantics. This is a human argument about the encoding, separate from the example proofs discovered automatically.</p></section>
<section class="panel" id="reader"><h2>A newly found checked proof</h2><label>Target<select id="proof-case"></select></label><p id="proof-info"></p><div id="goal" class="formula"></div><button id="download">Download exact native proof</button><div id="proof"></div><p class="muted">Display names reverse each recorded renaming; literal downloads preserve the original ASTs. Square/grid tilings are not inferred from these proof lines.</p></section>
<section class="panel"><h2>Costs and assurance scope</h2><div id="costs" class="costs"></div><p>The one-second classification limit applies only to the bounded search. Total acquisition also includes independent positive-proof, absence-certificate and mark-model checking; its measured cost can be much larger. Classification search is a component of acquisition, not an additional cost. Preparation and post-search assurance are measured separately.</p><p>Cold-equivalent pipeline sums reuse observed preparation/acquisition costs: they are accounted estimates, not repeated cold trials. No new RL training occurs. Charged adapter work includes base-provider work, rather than measuring adapter overhead alone.</p><p>Large-run assurance samples first and last <em>retained</em> marked-query records, which may differ from the last emitted query when retention is truncated. It does not reconstruct every intermediate graph. Tiny qualification has separate broader checks. Every negative remains finite-basis/height scoped.</p><p id="qualification"></p><details><summary>Budget, learning counts and provenance</summary><pre id="provenance"></pre></details></section>
<script type="application/json" id="data">__DATA__</script><script>
'use strict';const D=JSON.parse(document.getElementById('data').textContent),$=id=>document.getElementById(id),esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])),sec=n=>typeof n==='number'?n.toFixed(3)+' s':'not recorded',json=x=>JSON.stringify(x,null,2);let C=null,P=null,queue=Promise.resolve();function math(nodes){queue=queue.then(async()=>{if(window.MathJax?.typesetPromise){await MathJax.startup.promise;await MathJax.typesetPromise(nodes);}}).catch(e=>console.warn(e));}function alias(s,k){const m=C?.case?.renaming?.[k]||{};return Object.keys(m).find(n=>m[n]===s)||s;}function nm(s,k){return '\\mathrm{'+String(alias(s,k)).replace(/[\\{}_#$%&]/g,c=>'\\'+c)+'}';}function term(t){if(t[0]==='var')return nm(t[1],'variable');const n=alias(t[1],'function');if(n==='zero'&&!t[2].length)return '0';if(n==='add')return '\\left('+term(t[2][0])+'+'+term(t[2][1])+'\\right)';return nm(t[1],'function')+(t[2].length?'('+t[2].map(term).join(',')+')':'');}function op(f){const s=form(f);return f[0]==='all'?'('+s+')':s;}function form(f){switch(f[0]){case'eq':return term(f[1])+'='+term(f[2]);case'pred':return nm(f[1],'predicate')+(f[2].length?'('+f[2].map(term).join(',')+')':'');case'all':return '\\forall '+nm(f[1],'variable')+'.\\;'+form(f[2]);case'not':return '\\neg('+form(f[1])+')';case'bot':return '\\bot';default:return '('+op(f[1])+({imp:'\\rightarrow',and:'\\land',or:'\\lor'}[f[0]])+op(f[2])+')';}}function english(l){switch(l.rule){case'axiom':return 'Use supplied closed hypothesis '+alias(l.name,'axiom')+'.';case'instantiate':return 'Instantiate the universal formula with the stated capture-free term.';case'mp':return 'From line '+(l.antecedent+1)+' and implication line '+(l.implication+1)+', infer the consequent.';case'generalize':return 'Generalize line '+(l.source+1)+' over the stated variable; theory assumptions are closed.';case'refl':return 'A term equals itself.';case'eq_subst':return 'Substitute equal terms in the same formula context.';default:return 'Use '+l.rule+'.';}}
function showMark(){const m=D.markings[Number($('mark-case').value)];C=D.readers.find(r=>r.case.id===m.case);$('mark-info').textContent=m.case+': '+m.labels.ABSENT+' requested absences, '+m.labels.PROVED+' witnessed positives, '+m.labels.UNKNOWN+' unknowns; '+m.nodes+' supporting negative DAG nodes.';$('failure-formula').textContent=m.formula?'Literal FID '+m.fid+', remaining height '+m.remaining+': \\('+form(m.formula)+'\\)':'No queried certified absence is available.';$('literal-port').textContent=m.port||'No zero port';$('consumer').textContent=m.consumer||'No consuming producer in this basis';$('annotations').replaceChildren();for(const a of m.annotations||[]){const p=document.createElement('pre');p.textContent=json(a);$('annotations').appendChild(p);}if(!m.annotations?.length)$('annotations').innerHTML='<p class="empty">No matching first/last saved query annotation selected. The adapter diagram remains schematic.</p>';const t=document.createElement('table');t.innerHTML='<thead><tr><th>Every producer</th><th>Blocker</th><th>Required negative child</th></tr></thead><tbody></tbody>';for(const b of m.blockers||[]){const tr=document.createElement('tr');tr.innerHTML='<td><code>'+esc(b.definition)+'</code></td><td>'+esc(b.failed_child===null?'nonleaf at zero remaining height':'premise index '+b.failed_child)+'</td><td><code>'+esc(json(b.dependency))+'</code></td>';t.tBodies[0].appendChild(tr);}$('blockers').replaceChildren(t);$('mark-json').textContent=json(m);math([$('failure-formula')]);}
function showProof(){C=D.readers.find(r=>r.case.id===$('proof-case').value);P=C.proof;$('proof-info').textContent=P?'Actual independently checked proof found by '+P.lane+'.':'No checked proof selected under the recorded resource limits.';$('goal').textContent='\\['+form(C.case.problem.goal)+'\\]';$('proof').replaceChildren();$('download').disabled=!P;if(P)P.lines.forEach((l,i)=>{const d=document.createElement('div');d.className='line';d.innerHTML='<strong>Line '+(i+1)+' · '+esc(l.rule)+'</strong><div class="formula"></div><p></p>';d.querySelector('.formula').textContent='\\('+form(l.formula)+'\\)';d.querySelector('p').textContent=english(l);$('proof').appendChild(d);});math([$('goal'),$('proof')]);}
function fill(){const b=D.counts.BASE_HEURISTIC_GCTS,m=D.counts.MARKED_HEURISTIC_GCTS,f=D.counts.FILTER_HEURISTIC_GCTS;$('headline').textContent='The frozen RL policy found '+D.counts.BASE_RL_SHAPE_GCTS.verified+' checked proofs without failure marks and '+D.counts.MARKED_RL_SHAPE_GCTS.verified+' with them; lexical search rose from '+D.counts.BASE_LEXICAL_GCTS.verified+' to '+D.counts.MARKED_LEXICAL_GCTS.verified+'. The heuristic found '+b.verified+' without marks and '+m.verified+' with them; direct lookup found '+f.verified+', and dynamic programming found '+D.counts.DP_CONTROL.verified+'. This limited coverage gain is not a total-cost speedup: acquisition took '+sec(D.costs.acquisition)+' across the cohort, including independent checking. These are single-run measurements, not evidence of general superiority.';const t=document.createElement('table');t.innerHTML='<thead><tr><th>Method</th><th>Verified</th><th>Finite closure</th><th>Unknown</th><th>Prepared search</th><th>Assurance</th><th>Reused-cost estimate</th></tr></thead><tbody></tbody>';for(const k of D.lanes){const c=D.counts[k],r=document.createElement('tr');r.innerHTML='<td>'+esc(k)+'</td><td>'+c.verified+'</td><td>'+c.finite+'</td><td>'+c.unknown+'</td><td>'+sec(c.search)+'</td><td>'+sec(c.assurance)+'</td><td>'+sec(c.accounted_estimate)+'</td>';t.tBodies[0].appendChild(r);}$('coverage').appendChild(t);const tt=document.createElement('table');tt.innerHTML='<tr><th>Point method</th><th>Branches</th><th>Forced</th><th>Backtracks</th><th>Registrations</th><th>Max graph edges</th><th>Mark contacts rejected</th><th>Table contacts rejected</th></tr>';for(const k of D.lanes.filter(k=>!k.endsWith('CONTROL'))){const c=D.counts[k],r=document.createElement('tr');r.innerHTML='<td>'+esc(k)+'</td>'+[c.branches,c.forced,c.backtracks,c.registered,c.max_graph_edges,c.mark_contacts_removed,c.table_contacts_removed].map(v=>'<td>'+v+'</td>').join('');tt.appendChild(r);}$('telemetry').appendChild(tt);const all=document.createElement('table');all.innerHTML='<thead><tr><th>Target</th>'+D.lanes.map(k=>'<th>'+esc(k)+'</th>').join('')+'</tr></thead><tbody></tbody>';for(const r of D.readers){const tr=document.createElement('tr');tr.innerHTML='<td>'+esc(r.case.id)+'</td>'+D.lanes.map(k=>{const a=D.rows.find(x=>x.case===r.case.id&&x.lane===k);return '<td><span class="tag '+a.kind+'">'+esc(a.status)+'</span><br>'+sec(a.seconds)+(a.reason?'<br>'+esc(a.reason):'')+'</td>';}).join('');all.tBodies[0].appendChild(tr);const o=document.createElement('option');o.value=r.case.id;o.textContent=r.case.id;$('proof-case').appendChild(o);}$('results').appendChild(all);D.markings.forEach((m,i)=>{const o=document.createElement('option');o.value=i;o.textContent=m.case;$('mark-case').appendChild(o);});for(const[k,v]of Object.entries(D.costs)){const d=document.createElement('div');d.innerHTML='<strong>'+sec(v)+'</strong>'+esc(k);$('costs').appendChild(d);}$('qualification').textContent='Separate qualification: '+D.qualification.status+'. Exact receipts are linked in the evidence.';$('provenance').textContent=json({input:D.input,protocol:D.protocol,preparation:D.preparation,marking_counts:D.markings.map(m=>({case:m.case,labels:m.labels,requested:m.requests,nodes:m.nodes,source:m.source})),qualification:D.qualification,qualification_source:D.qualification_source,environment:D.environment,pins:D.pins});if(D.markings.length)showMark();const p=D.readers.find(r=>r.proof)||D.readers[0];$('proof-case').value=p.case.id;showProof();}
$('mark-case').onchange=showMark;$('proof-case').onchange=showProof;$('download').onclick=()=>{if(!P)return;const c=D.readers.find(r=>r.case.id===$('proof-case').value).case,u=URL.createObjectURL(new Blob([json({case:c.id,lane:P.lane,theory:c.problem.theory,goal:c.problem.goal,proof:P.lines,checks:P.checks})+'\n'],{type:'application/json'})),a=document.createElement('a');a.href=u;a.download=c.id+'-proof.json';a.click();setTimeout(()=>URL.revokeObjectURL(u),1000);};fill();
</script></main></html>'''


if __name__ == '__main__':
    build()
