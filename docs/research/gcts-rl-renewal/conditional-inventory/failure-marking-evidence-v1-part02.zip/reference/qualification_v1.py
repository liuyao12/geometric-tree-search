"""Separate finite failure-marking qualification; Source-only until Root runs.

No cohort, held-out cases, imported failure table or policy is read. Exhaustive
tree enumeration is a deliberately tiny fixture, not the prospective search.
"""
import argparse
import copy
import hashlib
import itertools
import json
from pathlib import Path
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'source'),str(ROOT/'reference')]
import proof_core_v1 as core
from finite_basis_v1 import compile_case
import failure_markings_v1 as fm
import failure_certificate_checker_v1 as absence
from marked_point_checker_v1 import Checker


def fixture():
    c=['fun','qualification_c',[]]
    atom=lambda name:['pred',name,[c]]
    p,q,u,g=[atom(name) for name in ('P','Q','U','G')]
    return {'id':'FM-qualification-only-ground-Horn-v1','split':'qualification-only',
            'problem':{'theory':{'functions':{'qualification_c':0},
               'predicates':{name:1 for name in ('P','Q','U','G')},
               'axioms':{'fact_P':p,'P_to_Q':['imp',p,q],'Q_to_G':['imp',q,g],
                         'U_to_G':['imp',u,g],'U_cycle':['imp',u,u],'Q_cycle':['imp',q,q]}},'goal':g},
            'terms':[c],'profile':{'ui_rounds':0,'max_terms':8,'max_templates':32,'max_definitions':8000},
            'scope':'Declared independent finite API fixture only; no supplied derivation, prospective example or learned inventory.'}


def flag(point):
    try:
        value=json.loads(point)
    except (ValueError,TypeError):
        return False
    return type(value) is list and len(value)==4 and value[0]=='FM-port-v1'


def project(state):
    result=copy.deepcopy(state)
    result['marks']=[row for row in result['marks'] if not flag(row[0])]
    result['dependencies']['m']=[row for row in result['dependencies']['m'] if not flag(row[0])]
    for row in result['placements']:
        row['m']=[pair for pair in row['m'] if not flag(pair[0])]
    return result


def exact_tiling(rows,model):
    """Independent literal t sums/m agreement; assigned '0' is never absent."""
    totals=dict(model['seed']['t']);marks=dict(model['seed']['m']);points=set(model['roots']);seen=set()
    for row in rows:
        if row['id'] in seen:return False
        seen.add(row['id'])
        for point,units in row['t']:
            totals[point]=totals.get(point,0)+units;points.add(point)
            if totals[point]>model['capacity']:return False
        for point,value in row['m']:
            if point in marks and marks[point]!=value:return False
            marks[point]=value
    return all(totals.get(point,0)==model['capacity'] for point in points)


def all_trees(cat,fid,remaining,site=''):
    """All native producers, all child products, no first-witness pruning."""
    result=[]
    for definition in cat.by_out.get(fid,[]):
        children=definition['premises']
        if children and remaining==0:continue
        choices=[all_trees(cat,child,remaining-1,site+str(i)) for i,child in enumerate(children)]
        for product in itertools.product(*choices):
            selected=[core.text([site,definition['id']])]
            for subtree in product:selected+=subtree
            result.append(sorted(selected))
            assert len(result)<=10000,'Fixture enumeration resource bound; no partial preservation claim.'
    return result


def run(output=None):
    output=Path(output) if output is not None else ROOT/'qualification-run-v1'
    output.mkdir(parents=True,exist_ok=False)
    paths=[ROOT/'source'/name for name in ('proof_core_v1.py','finite_basis_v1.py','failure_markings_v1.py')]
    paths += [ROOT/'reference'/name for name in ('qualification_v1.py','failure_certificate_checker_v1.py','marked_point_checker_v1.py')]
    paths += [ROOT/'upstream'/name for name in core.PINS]
    def pins():
        return [{'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in paths]
    before=pins();started=time.perf_counter()
    try:
        case=fixture();core.write(output/'declared-fixture.json',case)
        modules=core.load_modules();compiled,generation=compile_case(case);H=3
        model,base,factory,cat=core.make_catalogue(modules,compiled,generation,H)
        zero_checks=[modules['independent_fol_checker_v1'].check(compiled['theory'],[z['line']],z['line']['formula'],core.CHECK) for z in compiled['zero_instances']]
        assert all(check['status']=='VERIFIED' for check in zero_checks)
        factory_check=modules['growing_proof_verifier_v2'].verify_factory(compiled,generation,H,model,factory,limits=core.AUDIT)
        assert factory_check['status']=='VERIFIED',factory_check
        requests=[[fid,r] for fid in range(len(cat.forms)) for r in range(H+1)]
        learned=fm.learn(cat,requests,seconds=15.)
        assert len(learned['classifications'])==len(requests)
        assert all(row['status'] in ('PROVED','ABSENT') for row in learned['classifications']),learned
        certificate=learned['certificate'];checked=absence.verify(compiled,certificate)
        assert checked['status']=='VERIFIED',checked
        assert certificate['scope_sha256']==absence.scope_sha256(compiled)==core.sha(fm.scope_payload(compiled))
        expected_negative=[[row['fid'],row['remaining']] for row in learned['classifications'] if row['status']=='ABSENT']
        assert checked['negative_requests']==certificate['requests']==expected_negative
        assert checked['checked_nodes']==sorted([[row['fid'],row['remaining']] for row in certificate['nodes']])
        assert certificate['requests'] and certificate['nodes']
        core.write(output/'classified-and-checked.json.gz',dict(compiled=compiled,generation=generation,
                   zero_checks=zero_checks,factory_check=factory_check,learned=learned,certificate_check=checked))
        # No marked model is created before independent certificate admission.
        marked_cat=fm.MarkedCatalogue(compiled,factory['value']['definitions'],H,certificate)
        wrapped=fm.Provider(base,model,marked_cat,'MARKS');marked_model=wrapped.model
        point=Checker(compiled,H,certificate['scope_sha256'],certificate['requests'])
        model_check=point.check_model(marked_model);assert model_check['status']=='VERIFIED',model_check
        expected_flags={fm.port(certificate['scope_sha256'],f,r):'0' for f,r in expected_negative}
        assert {p:v for p,v in marked_model['seed']['m'] if flag(p)}==expected_flags
        originals=all_trees(cat,compiled['goal_id'],H)
        assert len(originals)==len({tuple(ids) for ids in originals})>1
        preserved=[];literal_records=[]
        for selected in originals:
            rows=[cat.placement(*cat.decode_id(cid)) for cid in selected]
            marked_rows=[marked_cat.placement(*cat.decode_id(cid)) for cid in selected]
            base_ok=exact_tiling(rows,model);marked_ok=exact_tiling(marked_rows,marked_model)
            assert base_ok and marked_ok
            assurance=point.verify_solution(marked_model,selected)
            assert assurance['status']=='VERIFIED',assurance
            native=core.check_positive(modules,compiled,H,selected)
            preserved.append(selected)
            literal_records.append(dict(selected=selected,base_exact=base_ok,marked_exact=marked_ok,
                                        marked_check=assurance,native=native))
        assert {tuple(ids) for ids in originals}=={tuple(ids) for ids in preserved}
        answers={};traces={};point_checks={}
        for lane in ('UNMARKED','MARKS','FILTER'):
            m,p,f,c=core.make_catalogue(modules,compiled,generation,H)
            if lane!='UNMARKED':
                decorated=fm.MarkedCatalogue(compiled,f['value']['definitions'],H,certificate)
                p=fm.Provider(p,m,decorated,lane);m=p.model
            snapshots=[]
            def audit(event,state,charge):
                charge(1);snapshots.append(dict(event=copy.deepcopy(event),state=copy.deepcopy(state)))
            limits=dict(wall_seconds=20,max_work=1000000000,max_nodes=10000,
                        max_events=10000,max_rollback_records=10000,max_candidates=5000,max_points=2000)
            answer=modules['growing_point_search_v2'].solve(m,limits,enumerate_incident=p,audit=audit)
            raw_ref=core.write(output/(lane+'-raw.json.gz'),dict(model=m,result=answer,audit=snapshots))
            assert answer['status']=='SAT' and answer['entry_state']==answer['restored_state'],answer
            assert answer['event_extent']['retained']==answer['event_extent']['total']==len(snapshots)
            evidence=answer['provider_evidence']
            assert evidence['retained']==evidence['total']==len(evidence['records'])
            for kind,rows,extent in [('events',answer['events'],answer['event_extent']),
                                     ('queries',evidence['records'],evidence),
                                     ('rollbacks',answer['rollback_records'],answer['rollback_extent'])]:
                assert extent['retained']==extent['total']==len(rows)
                assert hashlib.sha256(b''.join(core.wire(row) for row in rows)).hexdigest()==extent['sha256']
            native=core.check_positive(modules,compiled,H,answer['selected'])
            assert tuple(sorted(answer['selected'])) in {tuple(ids) for ids in originals}
            if lane=='MARKS':
                local=Checker(compiled,H,certificate['scope_sha256'],certificate['requests'])
                mc=local.check_model(m);assert mc['status']=='VERIFIED'
                queries=[local.verify_query(row['query'],row['reply']) for row in evidence['records']]
                partials=[local.verify_partial(m,[cid for cid,generation in row['state']['selected']],[]) for row in snapshots]
                solution=local.verify_solution(m,answer['selected'])
                assert all(row['status']=='VERIFIED' for row in queries+partials+[solution])
                point_checks=dict(model=mc,queries=queries,partials=partials,solution=solution)
            answers[lane]=dict(raw_ref=raw_ref,model=m,result=answer,audit=snapshots,native=native)
            traces[lane]=[dict(event=row['event'],state=project(row['state'])) for row in snapshots]
        assert core.text(traces['MARKS'])==core.text(traces['FILTER'])
        assert answers['MARKS']['result']['selected']==answers['FILTER']['result']['selected']
        negative_mutants=[]
        def bad_certificate(name,mutant):
            result=absence.verify(compiled,mutant);assert result['status']=='REJECTED',(name,result)
            negative_mutants.append(dict(name=name,certificate=mutant,receipt=result))
        bad=copy.deepcopy(certificate);bad['scope_sha256']='0'*64;bad_certificate('wrong-scope',bad)
        bad=copy.deepcopy(certificate);next(node for node in bad['nodes'] if node['blockers'])['blockers'].pop();bad_certificate('omitted-producer',bad)
        zero=next(definition for definition in cat.defs.values() if not definition['premises'])
        node=dict(fid=zero['output'],remaining=0,blockers=[[d['id'],None] for d in cat.by_out[zero['output']]])
        bad=dict(version=certificate['version'],scope_sha256=certificate['scope_sha256'],requests=[[zero['output'],0]],nodes=[node]);bad_certificate('true-ZERO-claim',bad)
        bad=copy.deepcopy(certificate);bad['nodes'][0]['remaining']=True;bad_certificate('boolean-depth',bad)
        bad=copy.deepcopy(certificate);bad['nodes'][0]['remaining']=-1;bad_certificate('negative-depth',bad)
        parent=next(node for node in certificate['nodes'] if node['remaining']>0 and node['blockers'])
        did,index=parent['blockers'][0];dependency=[cat.defs[did]['premises'][index],parent['remaining']-1]
        bad=copy.deepcopy(certificate);bad['nodes']=[n for n in bad['nodes'] if [n['fid'],n['remaining']]!=dependency]
        bad['requests']=[pair for pair in bad['requests'] if pair!=dependency];bad_certificate('missing-lower-dependency',bad)
        bad=copy.deepcopy(certificate);next(node for node in bad['nodes'] if node['remaining']>0 and node['blockers'])['blockers'][0][1]=2
        bad_certificate('corrupt-premise-index',bad)
        marking_mutants=[]
        def bad_model(name,mutant):
            local=Checker(compiled,H,certificate['scope_sha256'],certificate['requests'])
            result=local.check_model(mutant);assert result['status']=='REJECTED',(name,result)
            marking_mutants.append(dict(name=name,model=mutant,receipt=result))
        bad=copy.deepcopy(marked_model);idx=next(i for i,pair in enumerate(bad['seed']['m']) if flag(pair[0]));bad['seed']['m'].pop(idx)
        bad_model('missing-negative-seed',bad)
        bad=copy.deepcopy(marked_model);next(pair for pair in bad['seed']['m'] if flag(pair[0]))[1]='1';bad_model('wrong-negative-seed-value',bad)
        local=Checker(compiled,H,certificate['scope_sha256'],certificate['requests']);assert local.check_model(answers['MARKS']['model'])['status']=='VERIFIED'
        packet=next(row for row in answers['MARKS']['result']['provider_evidence']['records'] if any(flag(p) for placed in row['reply']['placements'] for p,v in placed['m']))
        def bad_packet(name,change):
            reply=copy.deepcopy(packet['reply'])
            row=next(placed for placed in reply['placements'] if any(flag(p) for p,v in placed['m']))
            idx=next(i for i,(p,v) in enumerate(row['m']) if flag(p));change(row,idx);row['m'].sort(key=lambda item:item[0])
            result=local.verify_query(packet['query'],reply);assert result['status']=='REJECTED',(name,result)
            marking_mutants.append(dict(name=name,query=packet['query'],reply=reply,receipt=result))
        bad_packet('missing-premise-flag',lambda row,i:row['m'].pop(i))
        bad_packet('wrong-premise-flag-value',lambda row,i:row['m'][i].__setitem__(1,'foreign-value'))
        bad_packet('literal-zero-is-assigned-not-wildcard',lambda row,i:row['m'][i].__setitem__(1,'0'))
        def wrong_remaining(row,i):
            parsed=json.loads(row['m'][i][0]);parsed[3]=(parsed[3]+1)%(H+1);row['m'][i][0]=core.text(parsed)
        bad_packet('wrong-remaining-premise-port',wrong_remaining)
        after=pins();assert before==after
        result=dict(schema='FM-separate-qualification-v1',status='PASS',case=case,depth=H,
            compiled=compiled,generation=generation,zero_checks=zero_checks,factory_check=factory_check,
            learned=learned,certificate_check=checked,model_check=model_check,enumeration=literal_records,
            answers=answers,point_checks=point_checks,negative_certificate_mutants=negative_mutants,
            marking_mutants=marking_mutants,source_before=before,source_after=after,
            summary=dict(queried_pairs=len(requests),negative_requests=len(expected_negative),
                checked_negative_nodes=len(checked['checked_nodes']),enumerated_proofs=len(originals),
                all_selected_sets_preserved=True,engine_SAT_lanes=3,MARKS_FILTER_traces_equal=True,
                completed_MARKS_queries=len(point_checks['queries']),checked_partial_states=len(point_checks['partials']),
                negative_mutants=len(negative_mutants),marking_mutants=len(marking_mutants)),
            seconds=time.perf_counter()-started,
            scope='Tiny exhaustive qualification only. No cohort, held-out case, policy or imported failure table; no prospective performance or unbounded proof claim.')
        ref=core.write(output/'qualification-result.json.gz',result)
        core.write(output/'completion.json',dict(status='PASS',result=ref,summary=result['summary'],seconds=result['seconds']))
        return ref
    except Exception as error:
        core.write(output/'failure.json',dict(status='FAILED_OR_UNKNOWN_NOT_ADMITTED',type=type(error).__name__,
                   reason=str(error),source_before=before,source_after=pins(),seconds=time.perf_counter()-started))
        raise


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--out',type=Path,default=None)
    print(json.dumps(run(parser.parse_args().out),sort_keys=True))
