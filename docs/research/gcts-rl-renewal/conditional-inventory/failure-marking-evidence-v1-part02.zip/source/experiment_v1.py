"""Frozen fresh-cohort failure-marking experiment; no execution on import."""
import copy
import hashlib
import json
from pathlib import Path
import platform
import sys
import time
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'reference'))
from proof_core_v1 import *
from finite_basis_v1 import compile_case,BasisLimit
from cases_v1 import cohort
from family_policy_v1 import Policy,dfs_control
from failure_markings_v1 import requests,learn,expand,MarkedCatalogue,Provider,scope_payload
from failure_certificate_checker_v1 import verify as verify_absence
from receptor_family_checker_v1 import verify as verify_family
from marked_point_checker_v1 import Checker

DEPTH=12;SECONDS=1.5;LEARN_SECONDS=1.
LANES=['BASE_LEXICAL_GCTS','BASE_HEURISTIC_GCTS','BASE_RL_SHAPE_GCTS',
       'MARKED_LEXICAL_GCTS','MARKED_HEURISTIC_GCTS','MARKED_RL_SHAPE_GCTS',
       'FILTER_HEURISTIC_GCTS','MEMO_CLUSTER_DFS_CONTROL','DP_CONTROL']
ENGINE=dict(wall_seconds=SECONDS,max_work=1000000000,max_nodes=1000000,
            max_events=1024,max_rollback_records=256,max_candidates=50000,max_points=4000)
CONTROL=dict(wall_seconds=SECONDS,max_depth=256,max_items=20000000,
             max_proof_lines=4096,max_states=200000,max_work=1000000000)

def emit(kind,**value):print(text(dict(kind=kind,**value)),flush=True)
def pins():
    paths=[p for folder in ('source','reference','upstream') for p in sorted((ROOT/folder).glob('*.py')) if p.name!='qualification_v1.py']
    paths += [ROOT/'upstream/library-frozen-v1.json',ROOT/'upstream/RL_SHAPE_GCTS-weights-frozen-v1.json']
    return {str(p.relative_to(ROOT)):dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in paths}

def freeze():
    d=cohort();d['protocol']=dict(depth=DEPTH,seconds=SECONDS,learning_seconds=LEARN_SECONDS,lanes=LANES,
        request_selection='For every case, collect all goal-backward-reachable FIDs and static premise-occurrence frequencies over every producer. Select first24 by descending frequency thenFID; query each at remaining depths0..3. Save requests before classification.',
        marks='Literal global mark-only ports canonicalJSON([FM-port-v1,scopeHash,FID,remaining]). Every producer requests value1 for each premise at H-siteDepth-1; only independently certified requested failures receive fixed seed value0. Values are strings, missing unconstrained. Markings frozen before each subsequent search.',
        meanings='Proved redundant constraints for the declared finite proof grammar/bound. Not unbounded first-order nonprovability, Turtle pair-corona learning, or a newly learned physical Wang tile set.',
        policy='Reuse prior frozen128-family bank and shape-only policy; no new policy training or donor proofs. Same matcher/pool and selected trained weights in base/marked lanes; fixed heuristic and direct-table comparator retained.',
        comparator='FILTER_HEURISTIC uses exact same checked failure requests as direct table lookup in the same point engine, with the same marked-compatible proposal pool. MEMO_CLUSTER_DFS is a conventional fresh memoized cluster solver; DP complete for this finite basis/depth.',
        costs='Common basis and all native-zero/factory audits observed once percase; classification/certificate/model checks once percase and reused across marked/filter lanes. Search recreates fresh provider and matcher. Post-search proof/family/query checks separately timed. Cold-equivalent sums are accounted estimates from reused observations, not repeated cold trials.',
        query_assurance='All completed indexed queries in tiny qualification; first and last retained marked query per held-out marked run are independently exhaustively re-enumerated. No claim of recomputing every large intermediate graph.',
        engine_limits=ENGINE,control_limits=CONTROL,scope='Single sequential native run; no standard-ATP or statistical superiority claim.')
    d['pins']=pins();write(ROOT/'data/cohort-frozen-v1.json',d);emit('FROZEN',sha256=sha(d),cases=len(d['cases']))

def prepare(modules,case):
    start=time.perf_counter()
    try:c,g=compile_case(case)
    except BasisLimit as e:return dict(status='UNKNOWN_PREPARATION',refusal=e.receipt(),seconds=time.perf_counter()-start)
    model,provider,factory,cat=make_catalogue(modules,c,g,DEPTH)
    receipt=modules['growing_proof_verifier_v2'].verify_factory(c,g,DEPTH,model,factory,limits=AUDIT);assert receipt['status']=='VERIFIED',receipt
    zero_checks=[]
    for z in c['zero_instances']:
        r=modules['independent_fol_checker_v1'].check(c['theory'],[z['line']],z['line']['formula'],CHECK)
        assert r['status']=='VERIFIED',(z,r);zero_checks.append(r)
    result=dict(status='PREPARED',compiled=c,generation=g,factory_check=receipt,zero_checks=zero_checks,seconds=time.perf_counter()-start)
    write(ROOT/'data/prepared'/(case['id']+'.json.gz'),result)
    emit('PREPARED',case=case['id'],definitions=c['profile']['definition_count'],seconds=result['seconds'])
    return result

def acquire(modules,case,prep):
    start=time.perf_counter();c,g=prep['compiled'],prep['generation'];model,base,factory,cat=make_catalogue(modules,c,g,DEPTH)
    pairs=requests(cat);write(ROOT/'data/requests'/(case['id']+'.json'),dict(scope_sha256=sha(scope_payload(c)),requests=pairs,selection='static syntax only, before labels'))
    learned=learn(cat,pairs,LEARN_SECONDS);cert=learned['certificate'];checked=verify_absence(c,cert)
    assert checked['status']=='VERIFIED',checked
    positives=[]
    for q in learned['classifications']:
        if q['status']!='PROVED':continue
        local=copy.copy(c);local['goal_id']=q['fid'];local['goal']=c['logical_basis']['formulas'][q['fid']]
        selected=sorted(expand(cat,q['tree']))
        tree=modules['growing_proof_verifier_v2'].verify_tree(local,q['remaining'],selected,limits=AUDIT)
        assert tree['status']=='VERIFIED',tree
        logic=modules['independent_fol_checker_v1'].check(c['theory'],tree['proof'],local['goal'],CHECK);assert logic['status']=='VERIFIED',logic
        positives.append(dict(fid=q['fid'],remaining=q['remaining'],tree_check=tree,host_check=logic))
    markedcat=MarkedCatalogue(c,factory['value']['definitions'],DEPTH,cert);wrapped=Provider(base,model,markedcat,'MARKS')
    checker=Checker(c,DEPTH,cert['scope_sha256'],cert['requests']);model_check=checker.check_model(wrapped.model)
    assert model_check['status']=='VERIFIED',model_check
    result=dict(learned=learned,absence_check=checked,positive_checks=positives,mark_model=wrapped.model,model_check=model_check,
                seconds=time.perf_counter()-start,requested_count=len(pairs),seed_failure_ports=len(cert['requests']))
    write(ROOT/'data/markings'/(case['id']+'.json.gz'),result)
    emit('MARKING_FROZEN',case=case['id'],requested=len(pairs),negatives=len(cert['requests']),positives=len(positives),seconds=result['seconds'])
    return result

def assure(modules,c,answer,library,markedcat,marked_model):
    start=time.perf_counter();by_id={f['id']:f for f in library};checks=[];decorated_checks=[]
    checker=None
    if markedcat:
        # The FILTER proposal validator uses the same marked-compatible pool.
        if marked_model is None:
            marked_model=dict(schema='Z-growing-point-model-v1',version='FM-proposal-assurance-v1',capacity=2,roots=[''],
                seed=dict(t=[['',1]],m=[[p,v] for p,v in sorted({**markedcat.seed_marks,'':markedcat.colors[c['goal_id']]}.items())]),
                inventory=dict(kind='CERTIFIED_INCIDENT',identity='FM-filter-proposal-assurance'))
        checker=Checker(c,DEPTH,markedcat.scope,markedcat.negative_requests)
        r=checker.check_model(marked_model);assert r['status']=='VERIFIED',r
    if answer['status'] in ('SAT','DERIVABLE'):answer['checked']=check_positive(modules,c,DEPTH,answer['selected'])
    for p in answer.get('guidance',{}).get('proposals',[]):
        if checker:
            r=checker.verify_partial(marked_model,p['selected_before'],p['proposal']['placements']);assert r['status']=='VERIFIED',r;decorated_checks.append(r)
        proposal=markedcat.project(p['proposal']) if markedcat else p['proposal']
        r=verify_family(c,DEPTH,p['selected_before'],by_id[p['family']],proposal);assert r['status']=='VERIFIED',r;checks.append(r)
    answer['family_checks']=checks;answer['decorated_family_checks']=decorated_checks;query_checks=[]
    if markedcat and not marked_model['inventory']['identity'].startswith('FM-filter-proposal-assurance'):
        # A bounded sample is explicit; no silent full-graph conformance claim.
        evidence=answer.get('provider_evidence',answer.get('provider_queries',{}))
        records=evidence.get('records',[])
        chosen=([records[0]] if records else [])+([records[-1]] if len(records)>1 else [])
        for record in chosen:
            r=checker.verify_query(record['query'],record['reply']);assert r['status']=='VERIFIED',r;query_checks.append(r)
        if 'checked' in answer:
            r=checker.verify_solution(marked_model,answer['selected']);assert r['status']=='VERIFIED',r;answer['marked_solution_check']=r
    answer['sampled_query_checks']=query_checks;answer['assurance_seconds']=time.perf_counter()-start
    answer['checked_search_seconds']=answer['search_seconds']+answer['assurance_seconds']
    return answer

def run(modules,case,prep,acquisition,lane,library,weights):
    c,g=prep['compiled'],prep['generation'];start=time.perf_counter();policy=None;markedcat=None;markedmodel=None
    if lane=='DP_CONTROL':
        r=modules['growing_proof_verifier_v2'].tree_control(c,DEPTH,CONTROL)
        answer=dict(status=r['status'],selected=(r.get('details') or {}).get('selected',[]),stats=r['costs'],control=r)
    else:
        model,provider,factory,cat=make_catalogue(modules,c,g,DEPTH)
        if lane.startswith(('MARKED_','FILTER_')):
            markedcat=MarkedCatalogue(c,factory['value']['definitions'],DEPTH,acquisition['learned']['certificate']);cat=markedcat
            provider=Provider(provider,model,cat,'MARKS' if lane.startswith('MARKED_') else 'FILTER');model=provider.model
            if lane.startswith('MARKED_'):markedmodel=model
        remaining=SECONDS-(time.perf_counter()-start)
        if lane=='MEMO_CLUSTER_DFS_CONTROL':
            answer=dfs_control(cat,library,weights,max(0,remaining));answer['guidance']=dict(proposals=answer.pop('proposals'))
        else:
            if 'LEXICAL' not in lane:
                mode='heuristic' if 'HEURISTIC' in lane else 'greedy'
                policy=Policy(cat,library,weights,mode,case['seed']+17,shape_only='RL_SHAPE' in lane)
            if remaining<=0:answer=dict(status='UNKNOWN',reason='INDEX_EXHAUSTED_SEARCH_WINDOW',selected=[],stats={})
            else:answer=modules['growing_point_search_v2'].solve(model,dict(ENGINE,wall_seconds=remaining),enumerate_incident=provider,order=policy,audit=policy.audit if policy else None)
            answer['provider']=provider.snapshot()
            if policy:answer['guidance']=policy.finish(answer['selected'])
            if 'entry_state' in answer:assert answer['entry_state']==answer['restored_state']
    answer['search_seconds']=time.perf_counter()-start;answer['allowed_seconds']=SECONDS
    # Preserve every completed search before any fallible post-search assurance.
    write(ROOT/'data/raw-answers'/(case['id']+'--'+lane+'.json.gz'),answer)
    answer=assure(modules,c,answer,library,markedcat,markedmodel)
    answer['accounted_reused_preparation_seconds']=prep['seconds']
    answer['accounted_reused_mark_acquisition_seconds']=acquisition['seconds'] if lane.startswith(('MARKED_','FILTER_')) else 0.
    answer['accounted_pipeline_seconds']=answer['checked_search_seconds']+prep['seconds']+answer['accounted_reused_mark_acquisition_seconds']
    answer['within_search_window']=answer['search_seconds']<=SECONDS
    return answer

def execute():
    frozen=json.loads((ROOT/'data/cohort-frozen-v1.json').read_text());assert frozen['pins']==pins(),'Source changed after freeze'
    modules=load_modules();library=json.loads((ROOT/'upstream/library-frozen-v1.json').read_text())
    trained=json.loads((ROOT/'upstream/RL_SHAPE_GCTS-weights-frozen-v1.json').read_text());weights=trained['weights'];assert len(weights)==len(library)+16
    start=time.perf_counter();prepared={};acquired={};results=[]
    for case in frozen['cases']:
        prep=prepare(modules,case);prepared[case['id']]=prep
        if prep['status']=='PREPARED':acquired[case['id']]=acquire(modules,case,prep)
    for case in frozen['cases']:
        prep=prepared[case['id']]
        for lane in LANES:
            if prep['status']!='PREPARED':answer=dict(status='UNKNOWN_PREPARATION',selected=[],preparation=prep)
            else:answer=run(modules,case,prep,acquired[case['id']],lane,library,weights)
            record=dict(case=case['id'],lane=lane,answer=answer);results.append(record)
            write(ROOT/'data/evaluation'/(case['id']+'--'+lane+'.json.gz'),record)
            emit('TEST',case=case['id'],lane=lane,status=answer['status'],seconds=answer.get('search_seconds'))
    summary=dict(schema='FM-failure-marking-study-v1',cohort=frozen,library=library,trained_policy=trained,results=results,
        preparation=[dict(case=c['id'],status=prepared[c['id']]['status'],seconds=prepared[c['id']]['seconds'],costs=prepared[c['id']].get('compiled',{}).get('costs')) for c in frozen['cases']],
        acquisitions=[dict(case=c['id'],seconds=acquired[c['id']]['seconds'],learned=acquired[c['id']]['learned'],absence_check=acquired[c['id']]['absence_check']) for c in frozen['cases'] if c['id'] in acquired],
        total_seconds=time.perf_counter()-start,environment=dict(python=sys.version,executable=sys.executable,platform=platform.platform()))
    write(ROOT/'data/results-v1.json.gz',summary);emit('COMPLETE',seconds=summary['total_seconds'])

if __name__=='__main__':
    if sys.argv[1:]==['freeze']:freeze()
    elif sys.argv[1:]==['run']:execute()
    else:raise SystemExit('Choose freeze or run')
