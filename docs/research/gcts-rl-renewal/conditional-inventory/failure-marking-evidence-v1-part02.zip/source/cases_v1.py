"""FM-v1 fresh declarative test cohort. No proofs, labels or search execution.

Save cohort() before any basis compilation, classification or search. Reuse of
the RF frozen bank/shape weights is an external driver action; no RL trains here.
Only standard-library data construction; no archived Source imports.
"""
import copy
import random

VERSION = 'FM-fresh-declarative-cohort-v1'


def var(name):
    return ['var', name]


def fun(name, *args):
    return ['fun', name, list(args)]


def power(name, term, depth):
    for _ in range(depth):
        term = fun(name, term)
    return term


def word(names, term):
    """names is outer-to-inner, e.g. ['m','n'] denotes m(n(term))."""
    for name in reversed(names):
        term = fun(name, term)
    return term


def _vars(ast):
    tag = ast[0]
    if tag == 'var':
        return {ast[1]}
    if tag in ('fun', 'pred'):
        return set().union(*(_vars(c) for c in ast[2]))
    if tag == 'all':
        return {ast[1]} | _vars(ast[2])
    if tag in ('eq', 'imp', 'and', 'or'):
        return _vars(ast[1]) | _vars(ast[2])
    return _vars(ast[1]) if tag == 'not' else set()


def _rename(case):
    case = copy.deepcopy(case)
    renaming_seed = case['seed'] ^ 0x6B39FA
    rng = random.Random(renaming_seed)
    theory = case['problem']['theory']
    all_ast = list(theory['axioms'].values()) + [case['problem']['goal']] + case['terms']
    variable_names = sorted(set().union(*(_vars(f) for f in all_ast)))
    stem = 'fm%x_' % case['seed']

    def mapping(names, kind):
        names = sorted(names)
        values = rng.sample(range(13 * len(names) + 1), len(names))
        return {name: stem + kind + str(index) for name, index in zip(names, values)}

    maps = dict(function=mapping(theory['functions'], 'f'),
                predicate=mapping(theory['predicates'], 'p'),
                variable=mapping(variable_names, 'v'), axiom=mapping(theory['axioms'], 'a'))

    def change(ast):
        tag = ast[0]
        if tag == 'var':
            return ['var', maps['variable'][ast[1]]]
        if tag in ('fun', 'pred'):
            kind = 'function' if tag == 'fun' else 'predicate'
            return [tag, maps[kind][ast[1]], [change(c) for c in ast[2]]]
        if tag == 'all':
            return ['all', maps['variable'][ast[1]], change(ast[2])]
        if tag in ('eq', 'imp', 'and', 'or'):
            return [tag, change(ast[1]), change(ast[2])]
        return ['not', change(ast[1])] if tag == 'not' else ['bot']

    renamed = dict(functions={maps['function'][name]: arity for name, arity in theory['functions'].items()},
                   predicates={maps['predicate'][name]: arity for name, arity in theory['predicates'].items()},
                   axioms={maps['axiom'][name]: change(f) for name, f in theory['axioms'].items()})
    case['problem'] = dict(theory=renamed, goal=change(case['problem']['goal']))
    case['terms'] = [change(t) for t in case['terms']]
    if 'instantiation_terms' in case:
        case['instantiation_terms'] = [change(t) for t in case['instantiation_terms']]
    case['renaming_seed'], case['renaming'] = renaming_seed, maps
    case['generation'] = 'Fresh declarative case fixed before compilation, labels or search; no target derivation, planted proof path or outcome supplied.'
    return case


def _profile(rounds, **extra):
    return dict(ui_rounds=rounds, max_terms=20, max_templates=32,
                max_definitions=8000, original_eq_context_snapshot=True, **extra)


def _horn(ordinal):
    seed = 2106110300 + ordinal * 10007
    rng = random.Random(seed)
    quantified = ordinal >= 4
    size = [10, 12, 15, 18, 11, 13, 16, 17][ordinal]
    base = var('x') if quantified else fun('c')
    term = lambda depth: power('f', base, depth)
    pred = lambda i, depth: ['pred', 'P' + str(i), [term(depth)]]
    close = lambda formula: ['all', 'x', formula] if quantified else formula
    facts = rng.sample(range(size), 3)
    axioms = {'fact' + str(j): close(pred(i, rng.randrange(5))) for j, i in enumerate(facts)}
    for j in range(2 * size + 3):
        left, right = rng.sample(range(size), 2)
        a, b = rng.randrange(5), rng.randrange(5)
        formula = ['imp', pred(left, a), pred(right, b)]
        if rng.random() < .3:
            other, depth = rng.randrange(size), rng.randrange(5)
            formula = ['imp', pred(left, a), ['imp', pred(other, depth), pred(right, b)]]
        axioms['rule' + str(j)] = close(formula)
    goal_choices = [i for i in range(size) if i not in facts]
    goal_predicate, goal_depth = rng.choice(goal_choices), rng.randrange(5)
    functions = {'f': 1} if quantified else {'f': 1, 'c': 0}
    return _rename(dict(id='test-fm-horn-' + ('forall-' if quantified else 'ground-') + str(ordinal),
        split='test', kind='quantified Horn' if quantified else 'ground Horn', seed=seed,
        quantified=quantified, max_term=4,
        profile=_profile(1 if quantified else 0,
            family='quantified-Horn' if quantified else 'ground-Horn',
            signature_predicates=size, predicate_arity=1, original_term_depth=4,
            sampled_goal_depth=goal_depth, sampled_fact_predicates=facts,
            sampled_rule_count=2 * size + 3,
            sampling='Random facts, rule edges/term depths and non-fact goal; no planted derivation.'),
        problem=dict(theory=dict(functions=functions,
            predicates={'P' + str(i): 1 for i in range(size)}, axioms=axioms),
            goal=close(pred(goal_predicate, goal_depth))),
        terms=[term(depth) for depth in range(5)]))


def _pa(ordinal, d, k):
    seed = 2206110300 + ordinal * 10007
    x, zero = var('x'), fun('zero')
    shifted = power('S', x, k)
    left = power('S', fun('add', shifted, zero), d)
    right = power('S', x, d + k)
    theory = dict(functions={'zero': 0, 'S': 1, 'add': 2}, predicates={},
        axioms={'add_zero': ['all', 'x', ['eq', fun('add', x, zero), x]]})
    return _rename(dict(id='test-fm-pa-d%d-k%d' % (d, k), split='test',
        kind='addition-zero and equality congruence', seed=seed, quantified=True,
        profile=_profile(1, family='PA-addition-zero-fragment', congruence_depth=d, shift=k,
            static_original_term_count=2 * d + k + 4,
            static_original_eq_contexts=2 * (d + k) + 8,
            static_size_scope='Analytic source-syntax counts, not compilation or truth labels.',
            full_PA=False, induction=False),
        problem=dict(theory=theory, goal=['all', 'x', ['eq', left, right]]), terms=[]))


def _incidence(ordinal, names):
    seed = 2306110300 + ordinal * 10007
    a, b, ell, emm = [fun(n) for n in ('a', 'b', 'ell', 'emm')]
    l, r = var('l'), var('r')
    on = lambda point, line: ['pred', 'On', [point, line]]

    def conjunction(items):
        result = items[-1]
        for item in reversed(items[:-1]):
            result = ['and', item, result]
        return result

    def common(u, v):
        return conjunction([['not', ['eq', a, b]], on(a, u), on(b, u), on(a, v), on(b, v)])

    theory = dict(functions={'a': 0, 'b': 0, 'ell': 0, 'emm': 0, 'm': 1, 'n': 1},
        predicates={'On': 2}, axioms={
            'incidence_uniqueness_ab': ['all', 'l', ['all', 'r', ['imp', common(l, r), ['eq', l, r]]]],
            'given_common_points': common(ell, emm)})
    return _rename(dict(id='test-fm-incidence-' + '-'.join(names), split='test',
        kind='symbolic incidence and two-function word congruence', seed=seed, quantified=True,
        profile=_profile(2, family='one-sorted-incidence-fragment',
            function_word=list(names), word_order='outer-to-inner', word_length=len(names),
            UI_subset='ell/emm constants only', full_Hilbert_geometry=False,
            interpretation='The same uninterpreted function word is applied to both named lines.'),
        problem=dict(theory=theory, goal=['eq', word(names, ell), word(names, emm)]),
        terms=[ell, emm], instantiation_terms=[ell, emm]))


def make_cases():
    values = [_horn(i) for i in range(8)]
    values += [_pa(i, d, k) for i, (d, k) in enumerate([(2, 6), (2, 7), (3, 6), (3, 7)])]
    values += [_incidence(i, names) for i, names in enumerate([
        ['m', 'n'], ['n', 'm'], ['m', 'n', 'm'], ['n', 'm', 'n', 'm']])]
    return values


def cases():
    return make_cases()


def cohort():
    values = make_cases()
    design = dict(schema='FM-prospective-cohort-design-v1', version=VERSION,
        training_cases=0, test_cases=16, case_order=[case['id'] for case in values],
        limits=dict(max_definitions=8000, max_terms=20, max_templates=32),
        resource_revision='Prospective original-context cap32 accommodates all PA source contexts24..28. No context or definition is truncated; any remaining preparation refusal is UNKNOWN.',
        split='Eight fresh Horn systems (four ground/four quantified), four new PA congruence targets d2..3/k6..7, four symbolic incidence targets using fresh two-function words.',
        horn_scope='All predicate arities1; signatures10..18. Ground systems use closed constant c, quantified systems use x with closed universal axioms; fixed terms are f^0..4 of that base.',
        reuse='Externally reuse the RF frozen128-family bank and shape-policy weights; no new donor discovery or RL training. The external driver must pin those artifacts.',
        freshness='Seeds2106110300/2206110300/2306110300 plus ordinal10007 are distinct from RF seeds. Independent literal renamings are recorded. No logical labels or target proofs supplied.',
        structural_overlap='The requested words m(n(.)) and n(m(.)) are isomorphic under swapping the two unary function names. Independent literal names do not establish disjoint proof cores.',
        basis='Unchanged generic RF original-term/original-EQ-context semantics; complete pair instantiation under the fixed output-term filter. UI terms ell/emm only for incidence.',
        freeze='Save the complete returned cohort before any compilation, native classification, failure-mark learning or search.',
        scope='Finite addition-zero and one-sorted symbolic incidence fragments; no full PA/Hilbert formalization, unrestricted nonprovability or search advantage assumed.')
    return dict(schema='FM-declarative-cohort-v1', design=design, cases=values)
