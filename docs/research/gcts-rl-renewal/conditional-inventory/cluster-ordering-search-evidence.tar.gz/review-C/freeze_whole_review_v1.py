"""Reviewer metadata only. Never imports or calls offered research Sources."""
from pathlib import Path
import ast
import hashlib
import json

BASE = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
D = BASE / 'research-runs/gcts-ordering-proof-pilot-20261020'
OLD = BASE / 'research-runs/gcts-cutoff-proof-pilot-20261020'
R = D / 'root'
OUT = D / 'review-C'

def pin(path):
    p = Path(path).resolve()
    assert '.partial' not in p.name
    raw = p.read_bytes()
    return dict(path=str(p), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

def load(path):
    p = Path(path)
    assert p.suffix == '.json' and '.partial' not in p.name
    return json.loads(p.read_bytes())

offer_path = R / 'prospective-whole-offer-v1.json'
offer = load(offer_path)
assert pin(offer_path)['sha256'] == '36ed81b32ea85efcdce840542bcaba1bb81a3a57b1727732f0fc51f14e8bc648'
assert pin(offer_path)['bytes'] == 22011
assert len(offer['files']) == 43 and len(offer['plans']) == 3
assert len({r['path'] for r in offer['files']}) == 43
for row in offer['files'] + offer['plans'] + [offer['protocol']] + offer['normative_references']:
    assert pin(row['path']) == row
for key in ['scientific_calls', 'new_actuals', 'new_grants', 'old_grants_remaining']:
    assert offer[key] == 0
assert offer['expected_case_jobs'] == 3 and offer['expected_explicit_arm_outcomes'] == 18
assert [r['sha256'] for r in offer['normative_references']] == [
    'c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9',
    'ca6ee206287bf18b69f88a35d30968312499567755f347a819af4cf49743e7d4']
assert offer['python']['sha256'] == 'b6ea0c2a9bfce48dbf181a53f1ca4f0562d40658b85bf47258e2a88d8f9e3933'

api_path = D / 'implementation-B/API-v1.json'
api = load(api_path)
policy = load(offer['ordering_policy']['path'])
protocol = load(offer['protocol']['path'])
assert pin(api['entry']['path']) == api['entry']
assert api['entry']['sha256'] == '9c734a91f77c6714d0ed7201dbefcf4e263603a2007261b2667a0ef5b47136a8'
assert offer['ordering_policy'] == api['policy'] == protocol['ordering_policy']
assert offer['ordering_policy']['sha256'] == '57ee2d9d253fd8d6cb30c54a2c8bdfda8ce76be99d02b019390cd7948f5025db'
assert offer['superseded_acquisition'] == policy['superseded_acquisition_document'] == protocol['superseded_acquisition']
assert offer['superseded_acquisition']['sha256'] == '7d55cdd85d44228bed4e452b8bdf82f29ea6275284540b32eeb1ae957871d928'
assert protocol['explicit_override'] == policy['explicit_override']
assert set(protocol['explicit_override']) == {'scope', 'specialization', 'freeze', 'literal_input'}
assert protocol['normative_references'] == offer['normative_references']
assert policy['registry']['native_registry_required_for_ordering'] is False

runtime = sorted((D / 'runtime').glob('*.py'))
custodians = [R / n for n in ['case_worker_v1.py', 'run_case_once_v3.py', 'observe_case_once_v2.py', 'independent_countermodel_v1.py']]
assert len(runtime) == 28
source_paths = runtime + [Path(api['entry']['path'])] + custodians
assert len(source_paths) == 33
assert {r['path'] for r in offer['source_AST_checks']} == {str(p) for p in source_paths}
assert all(r['AST_and_unused_compile'] is True for r in offer['source_AST_checks'])
ast_pins = []
for p in source_paths:
    parsed = ast.parse(p.read_bytes(), filename=str(p))
    compile(parsed, str(p), 'exec')
    ast_pins.append(pin(p))

baseline_path = R / 'baseline-copy-pins-v1.json'
baseline = load(baseline_path)
assert len(baseline['files']) == 32
expected_copies = runtime + custodians
assert {r['target'] for r in baseline['files']} == {str(p) for p in expected_copies}
for row in baseline['files']:
    before = Path(row['source'])
    after = Path(row['target'])
    assert before.is_relative_to(OLD) and after.is_relative_to(D)
    assert before.relative_to(OLD) == after.relative_to(D)
    assert before.read_bytes() == after.read_bytes()
    assert pin(before)['sha256'] == pin(after)['sha256'] == row['sha256']
    assert pin(before)['bytes'] == pin(after)['bytes'] == row['bytes']
for field in ['model_source', 'verifier_source']:
    assert pin(api[field]['path']) == api[field]
    assert (D / 'runtime' / Path(api[field]['path']).name).read_bytes() == Path(api[field]['path']).read_bytes()

corpus = load(api['corpus']['path'])
assert pin(api['corpus']['path']) == api['corpus'] == protocol['input'] == policy['logical_corpus']
assert api['corpus']['sha256'] == '2f206ef004c4d723f862ee36f08355816c5264a5809340be9787331d82d33cd6'
assert [s['length'] for s in corpus['tests']] == [14, 13, 14]
assert [s['length'] for s in corpus['training']] == [3, 5, 5]
old_protocol = load(OLD / 'root/protocol-v1.json')
assert protocol['limits'] == old_protocol['limits']
assert protocol['scientific_limits'] == old_protocol['scientific_limits'] == api['limits']
entry_tree = ast.parse(Path(api['entry']['path']).read_bytes())
limits_node = next(n.value for n in entry_tree.body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'LIMITS' for t in n.targets))
assert isinstance(limits_node, ast.Call) and isinstance(limits_node.func, ast.Name) and limits_node.func.id == 'dict'
assert {k.arg: ast.literal_eval(k.value) for k in limits_node.keywords} == protocol['scientific_limits']
expected_closure = set(map(str, source_paths)) | {
    str(api_path), str(D / 'implementation-B/handoff-v1.json'),
    offer['ordering_policy']['path'], offer['superseded_acquisition']['path'],
    api['corpus']['path'], offer['python']['path']}
native_rows = [r for r in offer['files'] if '/recovered/and-support/' in r['path']]
assert len(native_rows) == 4
expected_closure |= {r['path'] for r in native_rows}
assert {r['path'] for r in offer['files']} == expected_closure

plan_documents = []
for row, spec in zip(offer['plans'], corpus['tests'], strict=True):
    p = load(row['path'])
    old_plan = load(OLD / 'root' / Path(row['path']).name)
    assert p['case_id'] == spec['id']
    assert p['schema'] == 'proof-search-case-once-plan-v1'
    assert p['experiment'] == 'context-checked-primitive-ordering-v1'
    assert p['files'] == offer['files']
    assert p['protocol'] == offer['protocol']
    assert p['ordering_policy'] == offer['ordering_policy']
    assert p['superseded_acquisition'] == offer['superseded_acquisition']
    assert p['limits'] == protocol['limits'] == old_plan['limits']
    assert p['experiment_limits'] == protocol['scientific_limits'] == old_plan['experiment_limits']
    assert p['modules'] == api['roles'] == old_plan['modules']
    assert p['native'] == old_plan['native']
    assert p['python'] == offer['python'] == old_plan['python']
    assert p['input_path'] == api['corpus']['path'] == old_plan['input_path']
    assert p['runtime_dir'] == str(D / 'runtime')
    assert p['entry_path'] == api['entry']['path']
    for field, name in [('runner_path', 'run_case_once_v3.py'), ('observer_path', 'observe_case_once_v2.py'), ('worker_path', 'case_worker_v1.py'), ('control_path', 'independent_countermodel_v1.py')]:
        assert p[field] == str(R / name)
    assert p['actual_dir'] == str(D / 'actual' / spec['id'])
    assert not Path(p['actual_dir']).exists() and not Path(p['actual_dir'] + '.observer').exists()
    assert 'fresh reviewed Root once grant required' in p['authority']
    plan_documents.append(p)
assert not list(R.glob('grant-*.json')) and not (R / 'Root-preflight-v1.json').exists()

source_review_path = OUT / 'typed-scientific-delta-Source-review-v1.json'
source_review = load(source_review_path)
assert pin(source_review_path)['sha256'] == '3ab3ffa3db815cb30f69e080f09d0ebe5319f80282197a5aa2e5cf4da9d5ac94'
assert source_review['review_passed'] is True and source_review['failed_checks'] == 0
assert source_review['entry'] == api['entry'] and source_review['ordering_policy'] == offer['ordering_policy']
L_source_path = D / 'verification-L/typed-ordering-only-policy-Source-review-v1.json'
L_source = load(L_source_path)
assert pin(L_source_path)['sha256'] == '93c9844cf8002f3e0f5c106b95905dca80f8645b9277366ea040a8e8a2f644c4'
assert L_source['review_passed'] is True
inherited_path = OLD / 'review-C/typed-whole-prospective-Source-review-v1.json'
assert pin(inherited_path)['sha256'] == '8d3eb5979477f9422375f110c30a3d9b3e408a4a3808dca83cbaf8c8de85522f'
assert load(inherited_path)['review_passed'] is True
original_L = BASE / 'research-runs/gcts-word-point-proof-pilot-20261020/verification-L/handoff-v1.json'
assert pin(original_L)['sha256'] == '5cfa4cc5ed78ff1f762040c6c394375a87165c11416bebded0ce2233a97386c2'

checks = [
    dict(id='exact-whole-closure-and-pinned-parser', passed=True, finding='All43 offered file pins, three plan pins, protocol and both normative master pins independently revalidated. Exact33 Source files were AST parsed and unused compiled under pinned CPython; no offered Source was imported or executed. Closure is the unchanged32 runtime/custodian copies plus v9 entry/API/B handoff and explicit policy/acquisition/input/runtime/Native assets.'),
    dict(id='unchanged-runtime-custodian-and-verifier-composition', passed=True, finding='All28 runtime Sources and four custodians equal their corresponding D10 raw bodies. The frozen API model/verifier pins equal copied runtime bodies. Reuse of prior Source/manual word-reduction, scheduler, complete dependency, rollback, cutoff and fixed nonhostile custodian judgments is scoped to those exact bodies; it is not a new runtime or full-VM qualification.'),
    dict(id='conditional-scientific-review-obligation-discharged', passed=True, finding='Exact C3ab3ffa3 and L93c9844c conditional Source reviews bind v9 and57ee policy. The present protocol/three plans now join those exact pins and inherited7d55 acquisition. specialization/freeze and equivalent ground-validation-before-use wording are explicitly superseded only for untrusted primitive preferences; donor/essential Native acquisition, frozen library, actual-context Host proposal checks and final primitive proof gates remain.'),
    dict(id='registry-authority-preferences-and-completion-distinct', passed=True, finding='The reviewed Source and explicit protocol preserve actual Native registry query/status/cost. UNKNOWN remains unadmitted with old usable=[], separate ordering_instances merely eligible. Rejected/unrecognized/Root/foreign faults remain hard. Context-checked suggestions reorder complete primitive alternatives without a new inference interface, block row, pruning certificate or proof-length shortcut; final Host/full region/Native blocks=[] remain required. Completion means this new bounded ordering protocol, not registry acceptance, solved targets or advantage.'),
    dict(id='three-fresh-full-cold-cases-and-fairness', passed=True, finding='Exact three plans retain full original corpus,14/13/14 bounds, fresh3/5/5 donors, immutable six-arm configurations and per-case relative schedules. All18 searched/explicit outcomes and final proof checks are needed for full comparison; no old library/result/prefix/grant is adopted. Additional proposal checks and searches remain charged. D10 prerequisite differs, so historical rows cannot establish same-policy causal/statistical speedup.'),
    dict(id='unchanged-quotas-cooperative-clock-and-resource-gates', passed=True, finding='All outer and scientific limits equal D10 and literal v9 LIMITS:600 attempts/cooperative2s with Graph/setup/audits/context checks charged, two full domain audits, Native1e9, unchanged marking/cluster bounds,160work/180positive/210custody/225independent fallback,1GiB/128MiB including9MiBreserve and400m callbacks. No fit guarantee, hard2s claim or HWM causality is inferred. Full outputs, resource gates, waited Native/worker exits and tool/observer joins determine future admission.'),
    dict(id='truthful-observations-and-retained-research-boundaries', passed=True, finding='Eligibility, successful proposal packets and selected point packets remain distinct; symbolic activation and realized-choice counts stay unavailable=None. Zero may be cutoff/no returned proposal rather than exhaustive nonapplicability. Full cold setup and nested clocks must be reported honestly. Scope remains aligned complete-word Native/point adaptation, no trainedRL, physical universal Wang/fullVM, PA/Hilbert program completion or proof-search superiority claim.'),
    dict(id='no-actual-grant-and-independent-Root-barrier', passed=True, finding='Three actual/observer directories and fresh grant/preflight files were absent at freeze; offered counts are zero. This review issues no execution authority and does not assume a future L whole-plan PASS. Root must separately collect the required independent whole-plan receipt, issue exact fresh once grants, observe all tools idle and alone run the sequential jobs. Previous policies/skips/failures/grants remain unchanged; partials are never parsed or admitted.')
]
receipt = dict(
    schema='typed-context-checked-ordering-whole-prospective-Source-review-v1',
    reviewer_identity='/root/recovered_batch_review', review_passed=True,
    status='PASS_EXACT_WHOLE_SOURCE_PLAN_PREFLIGHT_SEPARATE_L_REVIEW_AND_ROOT_ONCE_GRANTS_REQUIRED',
    source_only=True, scientific_calls=0, component_calls=0, logical_replays=0,
    actual_execution_authorized=False, grant_authority=False, actual_resource_accepted=False,
    check_count=len(checks), failed_checks=0, checks=checks,
    whole_offer=pin(offer_path), protocol=offer['protocol'], plans=offer['plans'],
    complete_input_pins=offer['files'], normative_references=offer['normative_references'],
    AST_unused_compile_count=len(ast_pins), Source_AST_pins=ast_pins,
    unchanged_runtime_Source_count=28, unchanged_custodian_Source_count=4,
    exact_D10_copy_manifest=pin(baseline_path),
    scientific_delta_review=pin(source_review_path), separate_L_Source_review=pin(L_source_path),
    inherited_D10_C_whole_review=pin(inherited_path), original_D8_L_verifier_handoff=pin(original_L),
    ordering_policy=offer['ordering_policy'], superseded_acquisition=offer['superseded_acquisition'],
    metadata_authors=[pin(R/'prepare_case_plans_v1.py'), pin(R/'authorize_cases_v1.py')],
    metadata_author_scope='Read as nonhostile authoring-only metadata. Neither helper was executed by this reviewer; no grant issued. Root exact review collection/idle barrier remains separate.',
    separate_D11_L_whole_review_required=True, L_whole_PASS_not_assumed=True,
    fit='UNMEASURED', new_actuals=0, new_grants=0, old_grants_remaining=0,
    partial_policy='No partial content opened, parsed, projected or admitted.',
    manual_scope='Conditional independent Source/manual/preflight review, not mechanized soundness or actual qualification.',
    tools_stopped=True)
target = OUT / 'typed-whole-prospective-Source-review-v1.json'
with target.open('x') as stream:
    json.dump(receipt, stream, indent=2)
    stream.write('\n')
print(json.dumps(dict(review=pin(target), checks=len(checks), failed_checks=0)))
