"""Source-only policy/delta review metadata. No research imports, calls or replay."""
import ast
import difflib
import hashlib
import json
from pathlib import Path

BASE=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
D=BASE/'research-runs/gcts-ordering-proof-pilot-20261020'
OLD=BASE/'research-runs/gcts-cutoff-proof-pilot-20261020'


def pin(path):
    p=Path(path);assert '.partial' not in p.name
    b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())


def read(path):
    p=Path(path);assert p.suffix=='.json' and '.partial' not in p.name
    return json.loads(p.read_bytes())


def pins(obj):
    if type(obj)is dict:
        if {'path','bytes','sha256'}<=obj.keys():yield obj
        else:
            for child in obj.values():yield from pins(child)
    elif type(obj)is list:
        for child in obj:yield from pins(child)


def tree(path):
    t=ast.parse(Path(path).read_bytes(),filename=str(path))
    unused_code=compile(t,str(path),'exec');del unused_code
    return t


def dump(value):return ast.dump(value,include_attributes=False)


hpath=D/'implementation-B/handoff-v1.json';h=read(hpath);artifacts={}
for filename in ['handoff-v1.json','manifest-v1.json','API-v1.json','ordering-policy-v1.json','manual-policy-scope-v1.json','AST-diff-v1.json']:
    path=D/'implementation-B'/filename
    for row in pins(read(path)):
        actual=pin(row['path']);assert actual=={k:row[k] for k in ('path','bytes','sha256')}
        artifacts[actual['path']]=actual
    artifacts[str(path)]=pin(path)
entry=Path(h['entry']['path']);predecessor=OLD/'implementation-B/proof_search_pilot_v8.py'
assert pin(entry)['sha256']=='9c734a91f77c6714d0ed7201dbefcf4e263603a2007261b2667a0ef5b47136a8'
before=predecessor.read_text();after=entry.read_text();ta=tree(predecessor);tb=tree(entry)
ma={n.name:n for n in ta.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
mb={n.name:n for n in tb.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
assert ma.keys()==mb.keys()
changed=sorted(n for n in ma if dump(ma[n])!=dump(mb[n]))
assert changed==['_ground_clusters','run_pilot'] and len(ma)-2==27
inverse=after
for name in changed:
    new_text=ast.get_source_segment(after,mb[name]);old_text=ast.get_source_segment(before,ma[name])
    assert inverse.count(new_text)==1
    inverse=inverse.replace(new_text,old_text,1)
inverse=inverse.replace("VERSION = 'native-point-matched-proof-search-pilot-v9-ordering-only-clusters'","VERSION = 'native-point-matched-proof-search-pilot-v8-owned-point-cutoff'",1)
assert inverse==before
patch=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=str(predecessor),tofile=str(entry)))
assert patch==Path(h['patch']['path']).read_text()
old_ground=ma['_ground_clusters'];new_ground=mb['_ground_clusters']
assert len(old_ground.body)==len(new_ground.body)
assert [dump(n) for n in old_ground.body[1:-1]]==[dump(n) for n in new_ground.body[1:-1]]
old_return={k.arg:k.value for k in old_ground.body[-1].value.keywords}
new_return={k.arg:k.value for k in new_ground.body[-1].value.keywords}
for name in ['instances','admission_query','native_status','status','usable','binding_work']:
    assert dump(old_return[name])==dump(new_return[name])
assert dump(new_return['ordering_instances'])==dump(ast.Name(id='instances',ctx=ast.Load()))
assert dump(new_return['registry_native_admitted'])==dump(ast.Name(id='accepted',ctx=ast.Load()))
assert new_return['ordering_hints_enabled'].value is True
assert new_return['usage'].value=='CONTEXT_CHECKED_PRIMITIVE_ORDERING_ONLY'
def nested_compile_case(fn):return next(n for n in ast.walk(fn) if isinstance(n,ast.FunctionDef) and n.name=='compile_case')
assert dump(nested_compile_case(ma['run_pilot']))==dump(nested_compile_case(mb['run_pilot']))
proof_test=dump(ast.parse("search['proof'] is not None",mode='eval').body)
def proof_gate(fn):return [n for n in ast.walk(fn) if isinstance(n,ast.If) and dump(n.test)==proof_test]
assert len(proof_gate(ma['run_pilot']))==len(proof_gate(mb['run_pilot']))==2
assert [dump(n) for n in proof_gate(ma['run_pilot'])]==[dump(n) for n in proof_gate(mb['run_pilot'])]
assert 'SKIPPED_UNKNOWN_PREREQUISITE' not in ast.get_source_segment(after,mb['run_pilot'])
api=read(D/'implementation-B/API-v1.json');oldapi=read(OLD/'implementation-B/API-v1.json')
assert api['roles']==oldapi['roles'] and api['limits']==oldapi['limits'] and api['corpus']==oldapi['corpus']
policy_path=D/'implementation-B/ordering-policy-v1.json';policy=read(policy_path)
assert policy['id']=='CONTEXT_CHECKED_PRIMITIVE_ORDERING_ONLY_V1'
assert policy['usage']=='CONTEXT_CHECKED_PRIMITIVE_ORDERING_ONLY'
acquisition=Path(policy['superseded_acquisition_document']['path'])
assert pin(acquisition)['sha256']=='7d55cdd85d44228bed4e452b8bdf82f29ea6275284540b32eeb1ae957871d928'
master=BASE/'research-runs/gcts-batch-20261020/publisher/docs/basic-tiling-algorithm.md'
assert pin(master)['sha256']=='ca6ee206287bf18b69f88a35d30968312499567755f347a819af4cf49743e7d4'
prior=OLD/'review-C/typed-owned-cutoff-actual-scientific-review-v1.json'
assert read(prior)['review_passed'] is True
checks=[
 ('exact-two-function-Source-delta','All frozen handoff/API/policy/manual/manifest and dependency pins match; v8/v9 exact Source inverse and full raw patch reproduce. Only _ground_clusters and run_pilot ASTs differ;27 other functions/classes, every search/contextual expansion/point hint/guard/certificate/verifier and Budget remain identical. AST/unused compile only, no offered scientific function imported or called.'),
 ('actual-registry-status-cost-and-fault-preservation','Ground-generation/query/status/fault body before final return is AST-identical apart from docstring. Original exact query,1e9 Native budget, actual result/status and full cost remain. Native accepted alone sets registry_native_admitted; old status/usable fields retain accepted-only meaning. Known bounded UNKNOWN remains unknown with usable=[], while rejected/unrecognized/Root/transport/foreign faults still refuse before returning proposals.'),
 ('untrusted-ordering-versus-inference-authority','Distinct ordering_instances carries the same bounded syntactic bodies for preferences and ordering_hints_enabled denotes only eligibility. No Native registry authority, new axiom, block grammar, pruning rule, proof-length shortcut or forced-singleton claim follows. run_pilot separately validates role/status metadata; registry_native_admitted may stay false while the ordering-only protocol runs. registered_inference_used stays false; completion metadata expressly excludes registered-inference qualification.'),
 ('unchanged-contextual-expansion-checks','_expand resolves every premise receptor to actual earlier rows or named case axioms, remaps primitive references, rejects block primitives/overlength and freshly Host-checks the actual prefix plus expansion. Missing/inapplicable or unsuccessful valid proposals abstain without deleting fallback. Point hints map exact existing command/guard keys, enumerate bounded guard combinations and check whole trial legality. These helpers are unchanged; no theorem is accepted merely because a template exists.'),
 ('complete-domains-scheduler-and-primitive-fallback','Point search still performs global DEAD/FORCED/earliest-generation selection before optional preferences and places one legal primitive at a time. It verifies sorted alternatives equal all current legal keys. Symbolic search still computes legal primitive guards and reorders only those candidates with complete fallback. Candidate absence/proposal failure is never a pruning certificate. Existing markings, exact rollback, initial audits and owned-cutoff cleanup remain unchanged.'),
 ('independent-final-proof-gates-and-no-block-inventory','Nested compile_case AST is identical: empty inventory,arity0,familiesFalse and no block rows. Exact final proof-gate If AST is identical: fresh case Host check, full finite point/decode verification and Native default blocks=[]; actual rejection faults and Native UNKNOWN stays candidate-only/incomplete. Donor/essential Native checks and frozen family library remain unchanged. Any proposed ordering therefore leaves the original acceptance obligations intact.'),
 ('explicit-new-policy-and-required-Root-override','Exact57ee2d9d… policy pins the old7d55cdd8… acquisition document and explicitly overrides its Native-specialization/freeze-before-target prerequisites ONLY for untrusted ordering templates. Donor/family checks, frozen pre-search bodies and per-use contextual Host checks remain. Literal corpus already says ordering hints and stays unchanged. Fresh Root protocol and exact plans must join this policy/hash and override; this Source receipt does not review or adopt any not-yet-offered plan, issue a grant or relabel D10 skips/results.'),
 ('honest-observations-costs-completion-and-open-results','New observation fields distinguish disabled/empty/no recorded successful proposal/recorded successful packets. Existing point activation counter is selected proposal packets, not executed clusters; symbolic activation and realised primitive-choice counts remain None. A zero recorded count may reflect cutoff before scanning or before returned packets. All old costs/clocks/quotas/order and full cold setup remain; extra searched arms and Host proposal costs may change resource outcomes. scientific_complete is bounded six-arm ordering-protocol coverage with final candidate checks, not Native registry completion, useful transfer, speedup, trainedRL or full research goal completion. Fit and actual proposal use remain unmeasured.'),
]
review=dict(schema='typed-context-checked-ordering-scientific-delta-Source-review-v1',reviewer_identity='/root/recovered_batch_review',review_passed=True,status='PASS_CONDITIONAL_ORDERING_ONLY_SOURCE_DELTA_FRESH_ROOT_PROTOCOL_AND_PLAN_REVIEW_REQUIRED',source_only=True,scientific_calls=0,component_calls=0,logical_replays=0,whole_plan_reviewed=False,actual_execution_authorized=False,actual_resource_accepted=False,grant_authority=False,check_count=len(checks),failed_checks=0,checks=[dict(id=i,passed=True,finding=f) for i,f in checks],entry=pin(entry),predecessor=pin(predecessor),patch=pin(h['patch']['path']),implementation_handoff=pin(hpath),ordering_policy=pin(policy_path),superseded_companion_acquisition=pin(acquisition),artifacts=list(artifacts.values()),master=pin(master),changed_functions=changed,unchanged_function_class_AST_count=27,unchanged_function_classes=sorted(set(ma)-set(changed)),nested_compile_case_AST_identical=True,final_candidate_proof_gate_AST_identical=True,registry_generation_query_status_body_AST_identical=True,D10_historical_actual_review=pin(prior),manual_scope='Independent conditional Source/manual trust argument, not mechanized soundness, runtime conformance, full-VM qualification, benchmark advantage or resource prediction.',required_future_Root_joins=['Exact new policy and companion-clause override in fresh Root protocol/plan.','Full literal corpus and unchanged roles/Source/runtime/quotas/gates/Native inputs.','Independent L and whole-plan reviews, new once grants and all-agent idle barrier before Root alone executes.','Complete new outputs and resource/scientific admission; previous failed and skipped records remain unchanged.'],new_actuals=0,new_grants=0,fit='UNMEASURED',partial_policy='No partial content opened, projected or admitted.',tools_stopped=True)
target=D/'review-C/typed-scientific-delta-Source-review-v1.json';assert not target.exists()
review['review_author_correction']=dict(preimage=pin(D/'review-C/review-author-proof-gate-selector-preimage-v1.py'),finding='Initial reviewer selector expected one search-proof If but the actual Source has two: donor and recipient. The metadata assertion refused before receipt creation. Corrected review compares both complete If ASTs, which are identical v8/v9. No offered Source or artifact was changed and no earlier PASS existed.')
target.write_text(json.dumps(review,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(pin(target),indent=2))
