"""Package complete saved bytes and one isolated reader insertion; no science calls."""
from pathlib import Path
import hashlib,io,json,subprocess,tarfile

B=Path(__file__).resolve().parent.parent
D10=B.parent/'gcts-cutoff-proof-pilot-20261020'
D9=B.parent/'gcts-proof-memory-pilot-20261020'
D8=B.parent/'gcts-word-point-proof-pilot-20261020'
D5=B.parent/'gcts-proof-search-pilot-20261020'
P=B.parent/'gcts-batch-20261020/publisher'
D=P/'docs/research/gcts-rl-renewal/conditional-inventory'
OUT=B/'publication'
PREFIX='cluster-ordering-search'

def sha(raw):return hashlib.sha256(raw).hexdigest()
def pin(path):
    raw=path.read_bytes();return dict(file=path.name,bytes=len(raw),sha256=sha(raw))
def read(path):
    assert '.partial' not in path.name
    return json.loads(path.read_bytes())
def save(path,value):path.write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')

summary=read(B/'root/passive-actual-assessment-v1.json')
assert summary['resource_admitted_case_jobs']==3 and summary['resource_rejected_case_jobs']==0
assert summary['admitted_point_placement_attempts']==205 and summary['admitted_complete_point_domain_audits']==24
reviews=[(B/'review-C/typed-ordering-only-actual-scientific-review-v1.json',PREFIX+'-review-C.json'),
         (B/'verification-L/typed-ordering-only-resource-custody-review-v1.json',PREFIX+'-review-L.json')]
for source,name in reviews:
    review=read(source);assert review['review_passed'] and all(x['passed'] for x in review['checks'])
    (OUT/name).write_bytes(source.read_bytes())

reader=D/'reader.html';before=reader.read_bytes()
assert sha(before)=='97a58fbc063ff8b629393cdf21fe1d08436e3cded8b0237b1287ee06dd669b8c'
insert=('<section id="cluster-ordering-update" class="panel"><h2>First complete cluster comparison: the present heuristic does not help</h2>'
        '<p><a href="cluster-ordering-search.html#ordering">Read the cluster-ordering experiment</a>. '
        'All eighteen bounded searches return in three resource-admitted jobs. Symbolic hints change ordering but lose the first proof found by the conventional control; point cluster arms produce no successful proposals. '
        'Inspect the trace diagnosis, the fourteen-line conventional proof, its colored point markings, and the full reviewed evidence.</p></section>\n').encode()
offset=before.index(b'<section id="proof-cutoff-update"')
after=before[:offset]+insert+before[offset:]
assert after.replace(insert,b'',1)==before
(B/'root/reader-before-publication.html').write_bytes(before)
reader.write_bytes(after)
delta=dict(schema='cluster-ordering-reader-exact-insertion-v1',path=str(reader),offset=offset,
           inserted_bytes=len(insert),inserted_text=insert.decode(),
           before=dict(bytes=len(before),sha256=sha(before)),after=dict(bytes=len(after),sha256=sha(after)),
           deleting_exact_insertion_recovers_prior_body=True)
save(B/'root/reader-publication-delta-v1.json',delta)

excluded={'archive-scan-v1.json','Root-final-milestone-v1.json','Root-next-stage-handoff-v1.json',
          'ordering-hint-next-assessment-v1.json'}
paths={p for p in B.rglob('*') if p.is_file() and 'publication' not in p.relative_to(B).parts
       and 'publication-C' not in p.relative_to(B).parts and p.name not in excluded}
offer=read(B/'root/prospective-whole-offer-v1.json');omitted=[]
for row in offer['files']:
    path=Path(row['path'])
    if path==Path(offer['python']['path']):
        omitted.append(dict(pin=row,reason='Pinned isolated trusted CPython binary not redistributed; all research Sources and Native assets are included.'))
    else:paths.add(path)
paths.update([D10/'implementation-B/proof_search_pilot_v8.py',D10/'implementation-B/API-v1.json',
              D10/'root/protocol-v1.json',D10/'root/passive-actual-assessment-v1.json',
              D9/'implementation-B/proof_search_pilot_v7.py',D9/'implementation-B/API-v1.json',
              D9/'implementation-B/handoff-v1.json',D9/'implementation-B/cutoff-retention-next-assessment-v1.json',
              D9/'root/protocol-v1.json',D9/'root/passive-actual-assessment-v1.json',
              D8/'implementation-B/word_point_model_v1.py',D8/'verification-L/word_point_reference_verifier_v1.py',
              D8/'verification-L/API-v1.json',D8/'verification-L/handoff-v1.json',
              D8/'verification-L/manual-correspondence-v1.json',D8/'verification-L/declarative-diagnostic-bank-v1.json',
              P/'docs/basic-tiling-algorithm.md'])
records=[];bodies=[];partials=[]
for path in sorted(paths):
    assert not path.is_symlink()
    if path.is_relative_to(B):name=path.relative_to(B).as_posix()
    elif path.is_relative_to(D10):name='dependencies/D10/'+path.relative_to(D10).as_posix()
    elif path.is_relative_to(D9):name='dependencies/D9/'+path.relative_to(D9).as_posix()
    elif path.is_relative_to(D8):name='dependencies/D8/'+path.relative_to(D8).as_posix()
    elif path.is_relative_to(D5):name='dependencies/D5/'+path.relative_to(D5).as_posix()
    elif path==P/'docs/basic-tiling-algorithm.md':name='reference/basic-tiling-algorithm.md'
    else:raise ValueError('undeclared archive path '+str(path))
    raw=path.read_bytes();row=dict(file=name,bytes=len(raw),sha256=sha(raw))
    if '.partial' in path.name:partials.append(row)
    else:records.append(row);bodies.append((name,raw))
manifest=dict(schema='cluster-ordering-search-evidence-archive-v1',files=records,
              partial_raw_metadata_only=partials,omitted_trusted_runtime=omitted,
              actual_case_attempts=3,resource_admitted_case_attempts=3,resource_rejected_case_attempts=0,
              complete_actual_and_observer_files=42,observed_searches=18,observed_cluster_skips=0,
              admitted_searches=18,admitted_cluster_skips=0,admitted_point_placements=205,admitted_point_audits=24,
              qualified_recipient_certificates=1,recipient_engine='S0 conventional symbolic control',
              new_theorem_or_point_proof=False,scientific_comparison_complete=True,scientific_calls_during_packaging=0,
              reproduction='Consumed grants cannot be reused. Reproduction requires new paths, exact reviewed Source/plans and fresh one-use grants. Full fixed-dependency Sources and all complete case evidence are included; trusted Python binary is explicitly omitted.',
              scope='All three fresh D11 jobs pass whole admission and all18 bounded arms return under the declared ordering-only policy. Registry admission remains UNKNOWN and usable empty; no new block is registered. Previous D10 skipped arms and D9 failures retain their policies and classification. The qualified S0 proof repeats the conventional result. D8 L handoff is inherited verifier provenance, included separately. B outcome-next-assessment is explicitly posthoc passive trace diagnosis, not a prospective trial or new actual. Publication-only review remains outside this scientific snapshot.')
mb=(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode()
archive=OUT/(PREFIX+'-evidence.tar.gz')
assert not archive.exists()
with tarfile.open(archive,'w:gz',compresslevel=9) as stream:
    for name,raw in bodies+[('MANIFEST.json',mb)]:
        item=tarfile.TarInfo(name);item.size=len(raw);item.mode=0o644;item.mtime=0
        stream.addfile(item,io.BytesIO(raw))
with tarfile.open(archive,'r:gz') as stream:
    assert len(stream.getmembers())==len(records)+1
    for row in records:
        raw=stream.extractfile(row['file']).read()
        assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
    assert stream.extractfile('MANIFEST.json').read()==mb
scan=dict(schema='cluster-ordering-archive-complete-byte-scan-v1',archive=pin(archive),members=len(records)+1,
          payload_bytes=sum(row['bytes'] for row in records),all_members_byte_checked=True,
          partial_raw_metadata_only=partials,omitted_trusted_runtime=omitted)
save(B/'root/archive-scan-v1.json',scan)
for path in sorted(OUT.glob(PREFIX+'*')):(D/path.name).write_bytes(path.read_bytes())
owned=sorted(p for p in D.glob(PREFIX+'*') if p.name!=PREFIX+'-manifest.json')+[reader]
assert len(owned)==7
parent=subprocess.check_output(['git','rev-parse','HEAD'],cwd=P,text=True).strip()
public=dict(schema='cluster-ordering-search-publication-manifest-v1',source_parent_commit=parent,
            files=[pin(p) for p in owned],archive_scan=scan,reader_delta=delta,
            conclusion='Three fresh resource-admitted jobs;205 placements/24 audits/144 word controls. All18 bounded searches returned, zero skips. SC80 packets and72 literal order changes lose the first S0 proof; point cluster arms0 proposals. One repeated conventional S0 certificate; no new theorem, point proof or GCTS/RL advantage.')
save(D/(PREFIX+'-manifest.json'),public)
print(json.dumps(scan))
