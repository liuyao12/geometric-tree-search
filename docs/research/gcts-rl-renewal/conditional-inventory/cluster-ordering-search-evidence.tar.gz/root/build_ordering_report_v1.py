"""Passive complete saved-JSON joins and literal word display decoding only."""
from pathlib import Path
import hashlib,json
B=Path(__file__).resolve().parent.parent
D5=B.parent/'gcts-proof-search-pilot-20261020'
OUT=B/'publication'
OUT.mkdir(exist_ok=True)
def pin(path):
    p=Path(path);assert '.partial' not in p.name
    raw=p.read_bytes();return dict(path=str(p.resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def read(path):
    assert '.partial' not in Path(path).name
    return json.loads(Path(path).read_bytes())
def save(path,value):path.write_text(json.dumps(value,sort_keys=True,ensure_ascii=True,allow_nan=False,indent=2)+'\n')
corpus=read(D5/'corpus-L/pilot-inputs-v2.json')
cases=[];proofs=[];donors=[];tiles=[];totals=[];pointrows=[];ordering=[]
for spec in corpus['tests']:
    folder=B/'actual'/spec['id'];path=folder/('result.json' if (folder/'result.json').exists() else 'failure.json');d=read(path)
    s=d['scientific_result'];c=s['tests'][0]
    header=read(folder/'worker-header.json');terminal=read(folder/'terminal.json')
    observer=read(Path(str(folder)+'.observer/observer.json'))
    assert header['result']==pin(path)
    if terminal['result'] is not None:assert terminal['result']==pin(path)
    admitted=bool(d['status']==header['status']=='COMPLETE' and terminal['process_exit_code']==observer['parent_exit_code']==0 and observer['resource_candidate_accepted'])
    assert s['job_record_complete']
    assert c['spec']==spec and [a['id'] for a in c['arms']]==corpus['protocol']['arm_order'][spec['id']]
    assert s['diagnostics']['status']=='complete' and s['word_reference_diagnostics']['complete']
    assert len(s['word_reference_diagnostics']['controls'])==48
    assert all(x['status']=='PASSED' for x in s['word_reference_diagnostics']['controls'])
    assert c['reference_check']['complete'] and c['word_model_check']['complete']
    packet=c['model'];assert packet['schema']=='pilot-aligned-whole-word-point-model-v1'
    bykey={tuple(p['key']):p for p in packet['placements']}
    def tile(chosen,label,certificate=None):
        if not admitted:label='NONADMITTED — '+label
        words=[]
        for point,value in chosen['marks']:
            if point[1]==100:
                raw=bytes.fromhex(packet['word_dictionary'][value])
                words.append(dict(point=point,word_id=value,payload_hex=raw.hex(),literal_value=json.loads(raw),terminator=packet['word_terminator']))
        ref=chosen['command_reference']; command=packet['domains'][ref[0]][ref[1]]
        aux=[x['auxiliary'] for x in c['markings']['certificates'] if x['auxiliary']['placement']==chosen['key']]
        tiles.append(dict(label=label,scope=('WHOLE CASE NOT ADMITTED — diagnostic saved artifact. ' if not admitted else 'Resource-admitted case. ')+'Exact word-port candidate from '+spec['id']+'. Fixed positional translation roles; no rotation or reflection. High-level reduced point carrier; not a physical nearest-neighbor Wang tile.',whole_job_admitted=admitted,case_id=spec['id'],key=chosen['key'],occupancy=chosen['occupancy'],marks=chosen['marks'],word_occurrences=words,auxiliary=aux,command=command,metadata=chosen['metadata'],certificate=certificate,description='Colored bands distinguish full command words, full formula words and scalar mode/exclusion values. Every displayed ID and payload is decoded literally from the complete saved case dictionary.'))
        return len(tiles)-1
    arms=[];accepted=[];checker_candidates=[];searched=0;skipped=0;casepoints=[]
    for a in c['arms']:
        if a['execution_status']=='SKIPPED_UNKNOWN_PREREQUISITE':
            skipped+=1;assert a['search'] is None and a['native_proof_accepted'] is None
            arms.append(dict(id=a['id'],outcome='SKIPPED — cluster admission unknown',attempts=None,forced_branches='—',aux_removals=None,cluster_proposals=None,times='—',status=a['execution_status']));continue
        assert a['execution_status']=='SEARCH_RETURNED';searched+=1
        search=a['search'];m=search['metrics'];attempts=m.get('attempts',0)
        if a['method']=='point':
            placements=sum(x['event']=='place' for x in search['trace'])
            assert attempts==placements and search['root_restored']
            assert all(x['complete'] for x in search['domain_audits'])
            point=dict(case_id=spec['id'],arm=a['id'],attempts=attempts,nodes=m.get('nodes',0),placed_events=placements,completed_domain_audits=len(search['domain_audits']),initial_audit=search['domain_audits'][0] if search['domain_audits'] else None,forced_decisions=m.get('forced',0),branch_decisions=m.get('branch',0),backtracks=m.get('backtracks',0),initial_auxiliary_removal_witnesses=m['initial_auxiliary_removed_incidences'],auxiliary_removal_incidences_total=m['auxiliary_removed_incidences_total'],search_seconds=a['timings']['search_seconds'],root_restored=True,status=search['status'])
            point['whole_job_admitted']=admitted
            pointrows.append(point);casepoints.append(point)
        ok=a['native_proof_accepted'] is True
        outcome='PROOF ACCEPTED — Host, point region, Native' if ok and admitted else 'CHECKERS ACCEPTED — whole job NOT ADMITTED' if ok else search['status']
        if not admitted and not ok:outcome='NOT ADMITTED — observed '+outcome
        arms.append(dict(id=a['id'],outcome=outcome,attempts=attempts,forced_branches=str(m.get('forced',0))+' / '+str(m.get('branch',0)) if a['method']=='point' else 'Not applicable',aux_removals=m.get('auxiliary_removed_incidences_total') if a['method']=='point' else None,cluster_proposals=m.get('cluster_proposals',0),times=f'{a["timings"]["search_seconds"]:.6f} / {a["timings"]["full_arm_seconds"]:.6f} s',status=a['execution_status']))
        if a['cluster_enabled']:
            obs=a['ordering_observations'];assert obs['enabled'] and c['clusters']['ordering_hints_enabled']
            decisions=[e for e in search['trace'] if e['event']=='decision']
            changed=sum(e['original_candidates']!=e['ordered_candidates'] for e in decisions) if a['method']=='symbolic' else None
            ordering.append(dict(case_id=spec['id'],title=spec['title'],arm=a['id'],instances=obs['available_instances'],successful_proposals=obs['successful_proposals'],point_activated_packets=obs['point_activated_proposal_packets'],symbolic_order_changes=changed,attempts=attempts,status=search['status'],scope=obs['scope']))
        if search['proof'] is not None:
            assert ok and a['host_check']['accepted'] and a['region']['complete']
            assert a['proof_verification_status']=='HOST_REGION_NATIVE_ACCEPTED'
            q=s['native_records'][a['native_query']]
            assert q['result']['status']=='accepted' and q['request']['proof']==search['proof'] and q['request']['theory']==spec['theory'] and q['request']['target']==spec['target']
            rows=[]
            for row,command in enumerate(search['proof']):
                selected=[bykey[tuple(k)] for k in search['placements'] if k[0]==row]
                assert len(selected)==2 and {p['metadata']['kind'] for p in selected}=={'command','guard'}
                selected.sort(key=lambda p:p['key'][1])
                indices=[tile(p,spec['title']+' — '+a['id']+' recorded proof row '+str(row+1)+' '+p['metadata']['kind']) for p in selected]
                assert all(tiles[i]['command']==command for i in indices)
                rows.append(dict(row=row+1,command=command,tile_indices=indices))
            engine='conventional symbolic control' if a['method']=='symbolic' else 'point Graph search'
            status='Automatically discovered by '+a['id']+' '+engine+'. Exact Host, full finite point-region and Native checks returned accepted. No RL policy was used.'
            if not admitted:status='NOT ADMITTED: the whole case failed its memory gate. This saved S0 observation has accepted Host/point-region/Native checker records, but is not an admitted D10 result. The earlier byte-point experiment independently admitted its S0 proof.'
            proofs.append(dict(title=('Recipient — ' if admitted else 'NONADMITTED observation — ')+spec['title']+' ('+a['id']+')',spec=spec,proof=search['proof'],status=status,source=pin(path),arm=a['id'],query_id=q['id'],whole_job_admitted=admitted,tile_rows=rows,search_seconds=a['timings']['search_seconds'],full_arm_seconds=a['timings']['full_arm_seconds']))
            candidate=dict(arm=a['id'],rows=len(search['proof']),query=q['id'],search_seconds=a['timings']['search_seconds'],full_arm_seconds=a['timings']['full_arm_seconds'])
            checker_candidates.append(candidate)
            if admitted:accepted.append(candidate)
    take_donors=admitted and not donors
    for t in s['training']:
        assert t['acquired']
        assert s['native_records'][t['native_query']]['result']['status']==s['native_records'][t['essential_native_query']]['result']['status']=='accepted'
        if take_donors:donors.append(dict(title='Admitted-case donor — '+t['spec']['title'],spec=t['spec'],proof=t['search']['proof'],status='Automatically searched elementary donor from the resource-admitted case; Host/region and whole/essential Native accepted. Ordering-only hints require actual-context Host checks; final proofs retain full primitive checking.',source=pin(path),tile_rows=[]))
    cert=c['markings']['certificates'][0]
    tile(bykey[tuple(cert['auxiliary']['placement'])],spec['title']+' — certified excluded trial',cert)
    tile(next(p for p in packet['placements'] if p['metadata']['kind']=='guard' and p['metadata']['requirements']),spec['title']+' — earlier-row receptor guard')
    ground=s['native_records'][c['clusters']['admission_query']]
    total=dict(case_id=spec['id'],observer_seconds=observer['elapsed_seconds'],whole_peak_bytes=observer['final_conservative_whole_peak_bytes'],worker_peak_bytes=d['python_peak_bytes'],native_peak_bytes=d['native_peak_bytes'],known_exit_seconds=terminal['known_exit_seconds'],full_shared_setup_seconds=c['full_shared_setup_seconds'],compile_and_model_seconds=c['compile_and_model_seconds'],word_model_seconds=c['word_model_seconds'],training_and_acquisition_seconds=s['training_and_acquisition_seconds'],marking_seconds=c['markings']['compile_and_verification_seconds'],ground_query_seconds=ground['seconds'],ground_instances=len(c['clusters']['instances']),ground_native_status=ground['result']['status'],native_queries=len(s['native_records']),searches_returned=searched,skipped_cluster_arms=skipped,accepted_recipient_proofs=accepted,checker_accepted_candidates=checker_candidates,point_attempts=sum(x['attempts'] for x in casepoints),point_domain_audits=sum(x['completed_domain_audits'] for x in casepoints),certified_exclusions=len(c['markings']['certificates']),dictionary_words=len(packet['word_dictionary']),model_placements=len(packet['placements']),resource_candidate_accepted=admitted,scientific_complete=bool(admitted and s['scientific_complete']),result=pin(path),terminal=pin(folder/'terminal.json'),observer=pin(Path(str(folder)+'.observer/observer.json')))
    total['display_peak_bytes']=total['whole_peak_bytes'] if total['whole_peak_bytes'] is not None else total['worker_peak_bytes']+total['native_peak_bytes']
    total['memory_label']=('Whole peak: ' if total['whole_peak_bytes'] is not None else 'Worker+Native lower bound: ')+f'{total["display_peak_bytes"]/1048576:.1f} MiB'
    total['job_admission_label']='Whole job resource-admitted' if admitted else 'WHOLE JOB NOT ADMITTED — memory gate'
    total['point_status']=str(total['point_attempts'])+' point placements; '+str(total['point_domain_audits'])+' complete audits'
    p00=next(x for x in casepoints if x['arm']=='P00');p10=next(x for x in casepoints if x['arm']=='P10')
    assert p00['initial_audit']['frontier_points']==p10['initial_audit']['frontier_points']
    total['initial_audit_incidence_difference']=p00['initial_audit']['incidences']-p10['initial_audit']['incidences']
    assert total['initial_audit_incidence_difference']==12
    totals.append(total)
    costs=[f'Cold donor discovery/check/mining: {s["training_and_acquisition_seconds"]:.6f} s. Full shared setup: {c["full_shared_setup_seconds"]:.6f} s. Compilation/model/reduction: {c["compile_and_model_seconds"]:.6f} s; artifact encoding/check: {c["word_model_seconds"]:.6f} s; markings/check: {total["marking_seconds"]:.6f} s. These clocks contain nested work and must not be added as disjoint.',f'Ground registry: {len(c["clusters"]["instances"])} instances; Native status {ground["result"]["status"]}; {ground["seconds"]:.6f} s. Its full cost remains charged. The registry remains UNKNOWN; ordering instances are eligible under the new declared policy, without registering an inference block.',f'Whole observer: {observer["elapsed_seconds"]:.6f} s. {total["memory_label"]}. Admission: {total["job_admission_label"]}. Includes outputs and custody, not merely theorem-search latency.','The original cooperative two-second local deadline is retained, including Graph construction/snapshots/audits. Operations and cleanup can overshoot checkpoints. No timer was moved to create this result.','For per-method allocation, S0 needs no unused donor library or auxiliary marking acquisition; P10 includes its marking costs. Conventional symbolic proof search does not intrinsically need the shared point-model reporting setup.','The raw grounding-work counter can reach20,003 at the20,000 cooperative threshold through recursive unwind checks; no unification follows the threshold.']
    notes=[f'{x["arm"]}: {x["attempts"]} actual placement events, {x["completed_domain_audits"]} completed exhaustive Graph audits, {x["forced_decisions"]} forced decisions, {x["branch_decisions"]} branch decisions; exact initial state/Graph restoration returned.' for x in casepoints]
    notes.append('Initial auxiliary witnesses are collected by a separate full alignment scan. Audit counts refer to actual completed Graph-domain/incidence/scheduler checks; witness counts alone are not an audited before/after domain difference. All certified failures remain first-row conditions, not learned multiscale abstractions.')
    notes.insert(0,total['job_admission_label']+' — search observations for '+spec['title']+'.')
    cases.append(dict(title=spec['title'],spec=spec,outcome=total['job_admission_label']+'. '+str(len(accepted))+' admitted recipient proof(s); '+str(searched)+' recorded searches and '+str(skipped)+' skipped cluster arms.',failure=('The complete attempt failed its memory gate. Its returned search/certificate observations are not admitted comparison results. ' if not admitted else '')+'All six bounded arms returned. A returned search is distinct from a solved theorem; an unsuccessful bounded search does not establish theorem falsity.',metrics=[f'Whole job: {total["observer_seconds"]:.3f} s',total['memory_label'],('Admitted: ' if admitted else 'Nonadmitted observation: ')+total['point_status'],f'Admitted proofs: {len(accepted)}'],arms=arms,control=d['independent_external_controls'],cost_notes=costs,marking_notes=notes))
proofs+=donors
summary=dict(schema='Root-passive-cluster-ordering-search-assessment-v1',cases=totals,point_searches=pointrows,new_actual_case_jobs=len(totals),remaining_once_grants=0,searches_returned=sum(x['searches_returned'] for x in totals),cluster_arms_skipped=sum(x['skipped_cluster_arms'] for x in totals),accepted_recipient_proofs=sum(len(x['accepted_recipient_proofs']) for x in totals),point_placement_attempts=sum(x['attempts'] for x in pointrows),complete_point_domain_audits=sum(x['completed_domain_audits'] for x in pointrows),word_reference_controls_per_case=48,scientific_complete=all(x['scientific_complete'] for x in totals),whole_goal_complete=False,trained_RL=False,partial_files_parsed=False,scientific_calls=0,scope='Passive complete saved-file joins and literal word-dictionary display decoding; no scientific Source execution/replay. Aggregate observation counts include any explicitly NONADMITTED failed attempts; separate admitted counts follow.')
summary.update(resource_admitted_case_jobs=sum(x['resource_candidate_accepted'] for x in totals),resource_rejected_case_jobs=sum(not x['resource_candidate_accepted'] for x in totals),admitted_searches_returned=sum(x['searches_returned'] for x in totals if x['resource_candidate_accepted']),admitted_cluster_arms_skipped=sum(x['skipped_cluster_arms'] for x in totals if x['resource_candidate_accepted']),admitted_point_placement_attempts=sum(x['attempts'] for x in pointrows if x['whole_job_admitted']),admitted_complete_point_domain_audits=sum(x['completed_domain_audits'] for x in pointrows if x['whole_job_admitted']),checker_accepted_candidates_in_nonadmitted_jobs=sum(len(x['checker_accepted_candidates']) for x in totals if not x['resource_candidate_accepted']))
save(B/'root/passive-actual-assessment-v1.json',summary)
prior_path=B.parent/'gcts-cutoff-proof-pilot-20261020/root/passive-actual-assessment-v1.json'
prior=read(prior_path);prior_by_id={row['case_id']:row for row in prior['cases']}
comparison=[]
for row in totals:
    older=prior_by_id[row['case_id']]
    comparison.append(dict(case_id=row['case_id'],title=next(c['title'] for c in cases if c['spec']['id']==row['case_id']),previous_admitted=older['resource_candidate_accepted'],current_admitted=row['resource_candidate_accepted'],previous_whole_peak_bytes=older['whole_peak_bytes'],current_whole_peak_bytes=row['whole_peak_bytes'],previous_point_placements=older['point_attempts'],current_point_placements=row['point_attempts'],previous_source=older['result'],current_source=row['result']))
assert summary['accepted_recipient_proofs']==1 and totals[0]['accepted_recipient_proofs'][0]['arm']=='S0' and totals[0]['accepted_recipient_proofs'][0]['rows']==14
assert len(pointrows)==12 and all(p['status']=='unknown_search_budget' for p in pointrows)
admitted=[x for x in totals if x['resource_candidate_accepted']]
rejected=[x for x in totals if not x['resource_candidate_accepted']]
assert summary['searches_returned']==18 and summary['cluster_arms_skipped']==0
assert summary['admitted_point_placement_attempts']==205 and summary['admitted_complete_point_domain_audits']==24
assert len(ordering)==9 and sum(o['successful_proposals'] for o in ordering)==80
assert sum(o['symbolic_order_changes'] or 0 for o in ordering)==72
summary.update(ordering_only_policy=True,registered_ground_blocks=False,successful_ordering_proposals=80,literal_symbolic_order_changes=72)
save(B/'root/passive-actual-assessment-v1.json',summary)
headline="All 18 searches returned. The current cluster heuristic did not help."
conclusion="Three fresh jobs pass the resource gates. The conventional control finds the first target in 14 extensions; cluster-guided symbolic search reaches 600 without a proof. Symbolic hints changed ordering at 72 decisions. Point cluster arms produced no successful proposals. No new theorem or GCTS/RL advantage is established."
assessment=[
    'The new experiment separates ordering preferences from registered inference blocks. All ground-registry queries remain Native UNKNOWN, registry_native_admitted stays false, and usable stays empty. Seven, eleven and seven grounded instances become eligible only as context-checked primitive ordering hints. This policy does not change old skipped arms or failed runs.',
    'The 80 successful symbolic proposal packets changed candidate ordering at 72 recorded decisions. These are trace-derived ordering counts, not measurements of realized cluster execution. On the first positive target, SC fails at 600 primitive extensions while S0 succeeds at 14. Repeated already-derived conclusions are a concrete weakness in the current preference rule.',
    'All twelve point arms returned budget UNKNOWN, with 205 placement events and 24 exhaustive domain audits in total. The six cluster-enabled point arms recorded no successful proposal or activation. Completed empty-proposal calls can be examined passively; unlogged cutoff work remains unknown. No phase timing establishes an audit bottleneck.',
    'The 144 returned word-reference controls and full model correspondence checks belong to resource-admitted jobs. Markings remove twelve initial candidate incidences in both paired comparisons per case. They are shallow certified first-row exclusions, not learned multiscale proof abstractions.',
    'The first conventional recipient certificate repeats an earlier result. The three elementary donor proofs were searched anew in each cold job and used to freeze the inventory. No human proof route was supplied. No reinforcement-learning policy was trained.',
    'The historical comparison changes the policy and number of executed point arms: two per case previously, four now. Aggregate placements and whole-job peaks therefore do not measure equivalent workloads or demonstrate speedup. Within this new cohort all six methods share the same statement, primitive grammar and declared local budgets.',
    'Next, measure the proposal funnel explicitly and evaluate a general novelty-aware cluster preference against the unchanged primitive control. A heuristic repair must be tested in a fresh reviewed experiment; it cannot improve this frozen result retrospectively.',
    'The program remains active: practical boundary tiling, hierarchical receptor and lemma inventories, trained proposals, automated arithmetic and symbolic Hilbert geometry, and honest conventional benchmarks. Physical universal Wang qualification and Turtle/Penrose plane constructions remain unfinished.'
]
report=dict(schema='cluster-ordering-search-report-v1',headline=headline,conclusion=conclusion,proof_scope='The recipient certificate was found by the conventional S0 search. Its fourteen rows are linked to exact command and guard candidates, with formula and English readings. The three elementary donor proofs follow from the first admitted cold job. All shown certificates have accepted primitive checks; none demonstrates a new GCTS-discovered theorem.',cases=cases,proofs=proofs,tiles=tiles,actual_summary=summary,comparison=comparison,comparison_source=pin(prior_path),ordering=ordering,assessment=assessment,review_summary='Exact Source and whole-plan reviews preceded three fresh serial cold jobs. Independent scientific and custody reviews pass all complete records under the new ordering-only policy. Registry UNKNOWN, final proof checking, bounded search completion and resource admission remain separate. No scientific replay occurred outside actuals.')

next_path=B/'implementation-B/ordering-outcome-next-assessment-v1.json'
report['next_assessment']=read(next_path)
report['next_assessment_source']=pin(next_path)
report['ordering_diagnostic_text']='Passive joins of 53 completed empty point-proposal events show that the first premise of every eligible instance is absent from the actual contiguous proof prefix and named hypotheses. The unchanged expansion condition therefore rejects these calls at their first receptor. The point prefix keeps repeating a universal axiom rather than assembling the diverse premises needed by the inventory. This diagnosis does not cover an unlogged interrupted call.'

def prose_spacing(value):
    if type(value) is str:
        for old,new in [('and14','and 14'),('made4','made 4'),('and10','and 10'),('totalling89','totalling 89'),('and12','and 12'),('Only14','Only 14'),('and4','and 4'),('to1,','to 1,'),('the1GiB','the 1 GiB'),('peak1,','peak 1,'),('at860,','at 860,'),('the14-line','the 14-line'),('has12','has 12'),('show12','show 12'),('The48','The 48'),('reach20,','reach 20,'),('the20,','the 20,'),('returned65','returned 65'),('and8','and 8'),('made65','made 65'),('job,99','job, 99'),('is1,','is 1,'),('above1GiB','above 1 GiB'),('checker-accepted14','checker-accepted 14'),('at882,','at 882,'),('at880,','at 880,'),('from860,','from 860,'),('to880,','to 880,'),('remove12','remove 12'),('The48','The 48')]:value=value.replace(old,new)
        return value
    if type(value) is list:return [prose_spacing(x) for x in value]
    if type(value) is dict:return {k:prose_spacing(v) for k,v in value.items()}
    return value
save(OUT/'cluster-ordering-search-data.json',prose_spacing(report))
save(OUT/'cluster-ordering-search-engineering.json',dict(schema='cluster-ordering-search-method-v1',protocol=read(B/'root/protocol-v1.json'),assessment=summary,verification_scope='Independent full model reduction/occurrence checks and actual returned tiny controls; literal evidence-owner joins; unchanged primitive Host/full-region/final Native gates. C/L subsequent reviews are passive joins and Source arguments.',partial_files_parsed=False,scientific_calls=0))
print(json.dumps(dict(assessment=pin(B/'root/passive-actual-assessment-v1.json'),proofs=len(proofs),tiles=len(tiles),point_attempts=summary['point_placement_attempts'],audits=summary['complete_point_domain_audits'])))
