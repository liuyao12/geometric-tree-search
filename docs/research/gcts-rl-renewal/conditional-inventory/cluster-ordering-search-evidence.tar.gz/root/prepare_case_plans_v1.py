"""Metadata and AST/unused compile only; no scientific imports or calls."""
from pathlib import Path
import ast, hashlib, json, sys

B=Path(__file__).resolve().parent.parent
D10=B.parent/'gcts-cutoff-proof-pilot-20261020'
D5=B.parent/'gcts-proof-search-pilot-20261020'
RUNTIME=B/'runtime'
PYTHON=Path('/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12').resolve()
NATIVE=D5/'implementation-B/recovered/and-support'

def pin(path):
    p=Path(path).resolve(); assert '.partial' not in p.name
    body=p.read_bytes()
    return dict(path=str(p),bytes=len(body),sha256=hashlib.sha256(body).hexdigest())

def save(path,value):
    with path.open('x') as stream:
        json.dump(value,stream,sort_keys=True,indent=2); stream.write('\n')

api_path=Path(sys.argv[1]).resolve()
handoff_path=Path(sys.argv[2]).resolve()
api=json.loads(api_path.read_bytes())
entry=Path(api['entry']['path']); assert pin(entry)==api['entry']
for field in ['model_source','verifier_source']:
    source=Path(api[field]['path']); assert pin(source)==api[field]
    assert (RUNTIME/source.name).read_bytes()==source.read_bytes()
baseline=json.loads((B/'root/baseline-copy-pins-v1.json').read_bytes())
for row in baseline['files']:
    assert pin(row['source'])['sha256']==row['sha256']
    assert pin(row['target'])['sha256']==row['sha256']
assert len(baseline['files'])==32
assert len(list(RUNTIME.glob('*.py')))==28
assert json.loads(handoff_path.read_bytes())
old_api=json.loads((D10/'implementation-B/API-v1.json').read_bytes())
assert api['roles']==dict(old_api['roles'],model='word_point_model_v1')
corpus=D5/'corpus-L/pilot-inputs-v2.json'
assert pin(corpus)['sha256']=='2f206ef004c4d723f862ee36f08355816c5264a5809340be9787331d82d33cd6'
doc=json.loads(corpus.read_bytes()); assert [s['length'] for s in doc['tests']]==[14,13,14]
tree=ast.parse(entry.read_bytes(),filename=str(entry))
node=next(n.value for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='LIMITS' for t in n.targets))
assert isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id=='dict'
scientific={k.arg:ast.literal_eval(k.value) for k in node.keywords}
assert scientific==json.loads((D10/'root/protocol-v1.json').read_bytes())['scientific_limits']
native=dict(template_path=str(NATIVE/'fixed-native-inputs/proof-boundary-001.json'),micro_path=str(NATIVE/'fixed-native-inputs/proof-boundary-microcode-001.json.gz'),executable_path=str(NATIVE/'Native-runtime/boundary-oracle-v2'))
sources=sorted(RUNTIME.glob('*.py'))+[entry]+[B/'root'/n for n in ['observe_case_once_v2.py','run_case_once_v3.py','case_worker_v1.py','independent_countermodel_v1.py']]
checks=[]
for p in sources:
    parsed=ast.parse(p.read_bytes(),filename=str(p)); compile(parsed,str(p),'exec')
    checks.append(dict(path=str(p),AST_and_unused_compile=True))
policy_path=Path(api['policy']['path']); assert pin(policy_path)==api['policy']
policy=json.loads(policy_path.read_bytes())
assert policy['id']=='CONTEXT_CHECKED_PRIMITIVE_ORDERING_ONLY_V1'
assert policy['usage']=='CONTEXT_CHECKED_PRIMITIVE_ORDERING_ONLY'
assert policy['logical_corpus']==pin(corpus)
acquisition=Path(policy['superseded_acquisition_document']['path'])
assert pin(acquisition)==policy['superseded_acquisition_document']
assert policy['registry']['native_registry_required_for_ordering'] is False
assert all(policy['explicit_override'][k] for k in ['scope','specialization','freeze','literal_input'])
master_paths=[B.parent.parent/'docs/basic-tiling-algorithm.md',B.parent/'gcts-batch-20261020/publisher/docs/basic-tiling-algorithm.md']
master_refs=[pin(p) for p in master_paths]
assert [p['sha256'] for p in master_refs]==['c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9','ca6ee206287bf18b69f88a35d30968312499567755f347a819af4cf49743e7d4']
files=sources+[api_path,handoff_path,policy_path,acquisition,corpus,PYTHON,NATIVE/'Native-runtime/boundary_oracle.cpp']+[Path(p) for p in native.values()]
rows=[pin(p) for p in sorted(set(files))]
limits=dict(positive_seconds=180,custody_seconds=210,observer_fallback_seconds=225,work_seconds=160,memory_bytes=1073741824,physical_bytes=134217728,reserved_outer_bytes=9437184,log_bytes=4194304,root_callbacks=400000000,result_bytes=50331648)
assert len(rows)==43 and len(sources)==33
protocol=dict(schema='context-checked-primitive-ordering-protocol-v1',status='FROZEN_REQUIRES_FRESH_WHOLE_PLAN_REVIEWS_AND_ONCE_GRANTS',input=pin(corpus),limits=limits,scientific_limits=scientific,
    ordering_policy=pin(policy_path),superseded_acquisition=pin(acquisition),explicit_override=policy['explicit_override'],normative_references=master_refs,
    change='Only the Native ground-registry prerequisite for primitive ordering preferences changes. Original bounded syntactic instances may reach unchanged contextual hint functions after accepted or declared bounded UNKNOWN. New fields separate registry admission from ordering eligibility. Only _ground_clusters/run_pilot and VERSION differ from D10.',
    overridden_requirements='The prior acquisition specialization, successful-ground-validation-before-targets freeze clause, and equivalent ground-validation-before-use wording are superseded ONLY for untrusted ordering templates. Donor/essential Host-region-Native acquisition gates and family freeze remain. No inference block/interface is admitted or passed to the compiler; all literal statements/theories/schedules remain unchanged.',
    prerequisites='The original Native registry query/status/cost remain. accepted gives registry_native_admitted=true and old usable=instances; only unknown_step_budget/unknown_space_budget may give unadmitted registry with old usable=[] but separate ordering_instances. Rejected/unrecognized statuses and Root/transport/foreign faults remain hard faults. SC/P01/P11 run the same bounded instances through original actual-context Host expansion and exact existing primitive key/guard checks.',
    unchanged='All original corpus/theories/signatures,3fresh cold3-5-5donors,14-13-14primitive bounds, exact candidate identities, empty no-block inventory, word reduction, t/m roots/boundary, full frontier/dependencies/generations/global scheduler/rollback, six-arm order,2s clock/all quotas/all audits and final proof gates. v8 owned point-cutoff cleanup and parent-domain view remain.',
    soundness='Preferences can only reorder complete original primitive alternatives. Forced/dead decisions remain authoritative, no candidate is removed by a cluster. Found primitive proofs still require exact Host, full finite point-region and fresh final Native blocks=[] acceptance. Native proof UNKNOWN remains candidate-only. Registry UNKNOWN is never relabeled accepted.',
    completion='job_record_complete means six explicit records. all_six_searched/scientific_complete mean this new bounded ordering comparison and its required final candidate gates, never registered-inference qualification, all targets solved or any advantage. Whole resource/custody acceptance remains separate; any actual fault/unreached arm prevents complete comparison.',
    observations='Record existing successful proposal packets, point selected/activated packets, explicit zero/abstention and unavailable symbolic activation/realized-choice counts=None. An enabled flag is eligibility only, not evidence of actual use. Saved point traces may support separately labeled passive realization joins; no fabricated metric or new search instrumentation.',
    execution='Three fresh sequential full cold case jobs with all agents idle during timed actuals. Same full input; no supplied proof route, old library/result/prefix/grant adoption, easier target or outcome-dependent retry. Fresh exact whole Source/plan reviews and once grants required.',
    costs='All cold donor search/mining/checking, compilation/model/reference checks, literal wire encoding, markings, unchanged UNKNOWN registry query, all six searches/context checks/final proofs, output/custody remain charged once per case. Nested clocks are not disjoint. No free inventory for cluster arms; no point setup intrinsically needed by a conventional symbolic baseline.',
    search_time='Original cooperative2s/600 attempts includes Graph construction/snapshots/initial audits and hint checking. Operations/cleanup may overshoot checkpoints. No timer/audit/attempt/ordering-function tuning. More arms may exceed old resource fit; no fit prediction.',
    baseline_scope='Same matched conventional primitive control, not strongest ATP. D10 historical development runs have a different cluster prerequisite, so not a same-policy causal/statistical speedup comparator. Compare within the fresh six-arm cohort with all cost and unit differences visible.',
    source='All28 runtime and4 custodian Sources are byte-identical D10. New v9/API/B handoff/policy and inherited acquisition document make43closure rows. Original D8 L handoff remains separate verifier provenance. Conditional C/L delta reviews do not replace whole-plan reviews.',
    observer='Unchanged fixed-dependency nonhostile custodian:160work/180positive/210custody/225independent fallback,1GiB/128MiB including9MiBreserve,400mcallbacks/log/result bounds. Live census non-atomic, final census after known child exit; not hostile sandbox or OSreal-time guarantee.',
    scope='Reachable aligned complete-word Native/point adaptation, not arbitrary shifted/partial byte assignments or a physical nearest-neighbor universal Wang qualification. No trainedRL, fullPA/Hilbertgeometry, practical Turtle/Penrose coverage/substitution, general proof-search superiority or wholeprogram completion.',
    partial_rule='Every.partial raw length/hash only; never parse/project/reconstruct/admit.',old_grants_remaining=0,new_actuals=0,new_grants=0)
protocol_path=B/'root/protocol-v1.json';save(protocol_path,protocol)
plans=[]
for spec in doc['tests']:
    case=spec['id'];actual=B/'actual'/case
    assert not actual.exists() and not Path(str(actual)+'.observer').exists()
    plan=dict(schema='proof-search-case-once-plan-v1',experiment='context-checked-primitive-ordering-v1',case_id=case,actual_dir=str(actual),runtime_dir=str(RUNTIME),runner_path=str(B/'root/run_case_once_v3.py'),observer_path=str(B/'root/observe_case_once_v2.py'),worker_path=str(B/'root/case_worker_v1.py'),entry_path=str(entry),control_path=str(B/'root/independent_countermodel_v1.py'),input_path=str(corpus),modules=api['roles'],native=native,python=pin(PYTHON),files=rows,limits=limits,experiment_limits=scientific,protocol=pin(protocol_path),ordering_policy=pin(policy_path),superseded_acquisition=pin(acquisition),authority='No execution from plan; exact fresh reviewed Root once grant required.',trusted_runtime='Pinned isolated CPython/fixed research Sources, reproducible nonhostile case; no wholeOS/adversarial guarantee.',old_qualifications='All old policies/skips/failures/grants remain immutable. No rescue or prefix adoption.')
    path=B/'root'/('plan-'+case+'-v1.json');save(path,plan);plans.append(pin(path))
offer=dict(schema='context-checked-primitive-ordering-whole-offer-v1',plans=plans,files=rows,protocol=pin(protocol_path),ordering_policy=pin(policy_path),superseded_acquisition=pin(acquisition),normative_references=master_refs,python=pin(PYTHON),source_AST_checks=checks,expected_case_jobs=3,expected_explicit_arm_outcomes=18,scientific_calls=0,new_actuals=0,new_grants=0,old_grants_remaining=0,resource_fit='UNMEASURED; actual whole admission decisive.',readiness='PENDING_FRESH_WHOLE_SOURCE_PLAN_REVIEWS_AND_ROOT_ONCE_GRANTS')
save(B/'root/prospective-whole-offer-v1.json',offer)
print(json.dumps(dict(offer=pin(B/'root/prospective-whole-offer-v1.json'),plans=plans,files=len(rows),Source_AST_checks=len(checks),new_actuals=0,new_grants=0)))
