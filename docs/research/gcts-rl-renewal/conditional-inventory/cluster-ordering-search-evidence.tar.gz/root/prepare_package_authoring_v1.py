"""Author metadata-only packaging code from established template."""
from pathlib import Path
B=Path(__file__).resolve().parent.parent
s=(B.parent/'gcts-cutoff-proof-pilot-20261020/root/package_cutoff_report_v1.py').read_text()
s=s.replace("D9=B.parent/'gcts-proof-memory-pilot-20261020'","D10=B.parent/'gcts-cutoff-proof-pilot-20261020'\nD9=B.parent/'gcts-proof-memory-pilot-20261020'")
s=s.replace("PREFIX='proof-cutoff-search'","PREFIX='cluster-ordering-search'")
s=s.replace("==112","==205").replace("==12","==24")
s=s.replace('typed-owned-cutoff-actual-scientific-review','typed-ordering-only-actual-scientific-review').replace('typed-owned-cutoff-resource-custody-review','typed-ordering-only-resource-custody-review')
s=s.replace('057807e0ae64e3f6a1d95fd0596eaeed894d407d2e69b565b58756db0e14c018','97a58fbc063ff8b629393cdf21fe1d08436e3cded8b0237b1287ee06dd669b8c')
a=s.index("insert=(");z=s.index("offset=",a)
s=s[:a]+'''insert=('<section id="cluster-ordering-update" class="panel"><h2>First complete cluster comparison: the present heuristic does not help</h2>'
        '<p><a href="cluster-ordering-search.html#ordering">Read the cluster-ordering experiment</a>. '
        'All eighteen bounded searches return in three resource-admitted jobs. Symbolic hints change ordering but lose the first proof found by the conventional control; point cluster arms produce no successful proposals. '
        'Inspect the trace diagnosis, the fourteen-line conventional proof, its colored point markings, and the full reviewed evidence.</p></section>\\n').encode()
''' +s[z:]
s=s.replace("before.index(b'<section id=\"proof-memory-update\"')","before.index(b'<section id=\"proof-cutoff-update\"')")
s=s.replace("'ordering-hint-next-assessment-v1.json'","'ordering-hint-next-assessment-v1.json'")
s=s.replace("paths.update([D9/", "paths.update([D10/'implementation-B/proof_search_pilot_v8.py',D10/'implementation-B/API-v1.json',\n              D10/'root/protocol-v1.json',D10/'root/passive-actual-assessment-v1.json',\n              D9/")
s=s.replace("elif path.is_relative_to(D9):", "elif path.is_relative_to(D10):name='dependencies/D10/'+path.relative_to(D10).as_posix()\n    elif path.is_relative_to(D9):")
s=s.replace('observed_searches=9,observed_cluster_skips=9','observed_searches=18,observed_cluster_skips=0').replace('admitted_searches=9,admitted_cluster_skips=9,admitted_point_placements=112,admitted_point_audits=12','admitted_searches=18,admitted_cluster_skips=0,admitted_point_placements=205,admitted_point_audits=24').replace('scientific_comparison_complete=False','scientific_comparison_complete=True')
s=s.replace('All three fresh D10 jobs pass whole admission. Previous failed D9 jobs remain failed; their assessment is historical context. The qualified S0 proof repeats the earlier conventional proof. Original D8 L handoff is inherited verifier provenance, outside current41-file execution closure but included here separately. Unexecuted ordering-policy assessment and publication-only review are outside this scientific snapshot.','All three fresh D11 jobs pass whole admission and all18 bounded arms return under the declared ordering-only policy. Registry admission remains UNKNOWN and usable empty; no new block is registered. Previous D10 skipped arms and D9 failures retain their policies and classification. The qualified S0 proof repeats the conventional result. D8 L handoff is inherited verifier provenance, included separately. B outcome-next-assessment is explicitly posthoc passive trace diagnosis, not a prospective trial or new actual. Publication-only review remains outside this scientific snapshot.')
s=s.replace('Three fresh resource-admitted jobs;112qualified placements/12audits/144wordcontrols. One repeated conventionalS0 certificate, no point proof or GCTS/RL advantage;9searches+9skips, incomplete6armcomparison.','Three fresh resource-admitted jobs;205 placements/24 audits/144 word controls. All18 bounded searches returned, zero skips. SC80 packets and72 literal order changes lose the first S0 proof; point cluster arms0 proposals. One repeated conventional S0 certificate; no new theorem, point proof or GCTS/RL advantage.')
s=s.replace('proof-cutoff-','cluster-ordering-')
s=s.replace("before.index(b'<section id=\"cluster-ordering-update\"')","before.index(b'<section id=\"proof-cutoff-update\"')")
(B/'root/package_ordering_report_v1.py').write_text(s)
