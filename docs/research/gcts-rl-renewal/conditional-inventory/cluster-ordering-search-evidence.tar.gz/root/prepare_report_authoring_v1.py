"""Author passive report builder from established template. Does not import research code."""
from pathlib import Path
B=Path(__file__).resolve().parent.parent
prior=B.parent/'gcts-cutoff-proof-pilot-20261020'
s=(prior/'root/build_cutoff_report_v1.py').read_text()
s=s.replace('proof-cutoff-search','cluster-ordering-search').replace("len(pointrows)==6","len(pointrows)==12")
s=s.replace("cases=[];proofs=[];donors=[];tiles=[];totals=[];pointrows=[]","cases=[];proofs=[];donors=[];tiles=[];totals=[];pointrows=[];ordering=[]")
s=s.replace("        if search['proof'] is not None:","""        if a['cluster_enabled']:
            obs=a['ordering_observations'];assert obs['enabled'] and c['clusters']['ordering_hints_enabled']
            decisions=[e for e in search['trace'] if e['event']=='decision']
            changed=sum(e['original_candidates']!=e['ordered_candidates'] for e in decisions) if a['method']=='symbolic' else None
            ordering.append(dict(case_id=spec['id'],title=spec['title'],arm=a['id'],instances=obs['available_instances'],successful_proposals=obs['successful_proposals'],point_activated_packets=obs['point_activated_proposal_packets'],symbolic_order_changes=changed,attempts=attempts,status=search['status'],scope=obs['scope']))
        if search['proof'] is not None:""")
s=s.replace("Cluster-dependent recipient arms require separate admission.","Ordering-only hints require actual-context Host checks; final proofs retain full primitive checking.")
s=s.replace("Its full cost remains charged even when cluster arms are skipped.","Its full cost remains charged. The registry remains UNKNOWN; ordering instances are eligible under the new declared policy, without registering an inference block.")
s=s.replace("'Skipped cluster arms prevent a complete six-arm comparison. An unsuccessful bounded search does not establish theorem falsity.'","'All six bounded arms returned. A returned search is distinct from a solved theorem; an unsuccessful bounded search does not establish theorem falsity.'")
s=s.replace("prior_path=B.parent/'gcts-proof-memory-pilot-20261020/root/passive-actual-assessment-v1.json'","prior_path=B.parent/'gcts-cutoff-proof-pilot-20261020/root/passive-actual-assessment-v1.json'")
start=s.index('headline=f"')
end=s.index('\ndef prose_spacing',start)
s=s[:start]+'''assert summary['searches_returned']==18 and summary['cluster_arms_skipped']==0
assert summary['admitted_point_placement_attempts']==205 and summary['admitted_complete_point_domain_audits']==24
assert len(ordering)==9 and sum(o['successful_proposals'] for o in ordering)==80
assert sum(o['symbolic_order_changes'] or 0 for o in ordering)==72
summary.update(ordering_only_policy=True,registered_ground_blocks=False,successful_ordering_proposals=80,literal_symbolic_order_changes=72)
save(B/'root/passive-actual-assessment-v1.json',summary)
headline="All 18 searches returned. The current cluster heuristic did not help."
conclusion="Three fresh jobs pass the resource gates. The conventional control finds the first target in 14 extensions; cluster-guided symbolic search reaches 600 without a proof. Symbolic hints changed ordering at 72 decisions. Point cluster arms produced no successful proposals. No new theorem or GCTS/RL advantage is established."
assessment=[
    'The new experiment separates ordering preferences from registered inference blocks. All ground-registry queries remain Native UNKNOWN, registry_native_admitted stays false, and usable stays empty. Seven, eleven and seven grounded instances become eligible only as context-checked primitive ordering hints. This policy does not change old skipped arms or failed runs.',
    'The 80 successful symbolic proposal packets changed candidate ordering at 72 recorded decisions. These are trace-derived ordering counts, not measurements of realized cluster execution. On the first positive target, SC fails at 600 primitive extensions while S0 succeeds at 14. Repeated already-derived conclusions are a concrete weakness in the current preference rule.',
    'All twelve point arms returned budget UNKNOWN, with 205 placement events and 24 exhaustive domain audits in total. The six cluster-enabled point arms recorded no successful proposal or activation. Completed empty-proposal calls can be examined passively; unlogged cutoff work remains unknown. No phase timing establishes an audit bottleneck.',
    'The 144 returned word-reference controls and full model correspondence checks belong to resource-admitted jobs. Markings remove twelve initial candidate incidences in both paired comparisons per case. They are shallow certified first-row exclusions, not learned multiscale proof abstractions.',
    'The first conventional recipient certificate repeats an earlier result. The three elementary donor proofs were searched anew in each cold job and used to freeze the inventory. No human proof route was supplied. No reinforcement-learning policy was trained.',
    'The historical comparison changes the policy and number of executed point arms: two per case previously, four now. Aggregate placements and whole-job peaks therefore do not measure equivalent workloads or demonstrate speedup. Within this new cohort all six methods share the same statement, primitive grammar and declared local budgets.',
    'Next, measure the proposal funnel explicitly and evaluate a general novelty-aware cluster preference against the unchanged primitive control. A heuristic repair must be tested in a fresh reviewed experiment; it cannot improve this frozen result retrospectively.',
    'The program remains active: practical boundary tiling, hierarchical receptor and lemma inventories, trained proposals, automated arithmetic and symbolic Hilbert geometry, and honest conventional benchmarks. Physical universal Wang qualification and Turtle/Penrose plane constructions remain unfinished.'
]
report=dict(schema='cluster-ordering-search-report-v1',headline=headline,conclusion=conclusion,proof_scope='The recipient certificate was found by the conventional S0 search. Its fourteen rows are linked to exact command and guard candidates, with formula and English readings. The three elementary donor proofs follow from the first admitted cold job. All shown certificates have accepted primitive checks; none demonstrates a new GCTS-discovered theorem.',cases=cases,proofs=proofs,tiles=tiles,actual_summary=summary,comparison=comparison,comparison_source=pin(prior_path),ordering=ordering,assessment=assessment,review_summary='Exact Source and whole-plan reviews preceded three fresh serial cold jobs. Independent scientific and custody reviews pass all complete records under the new ordering-only policy. Registry UNKNOWN, final proof checking, bounded search completion and resource admission remain separate. No scientific replay occurred outside actuals.')
''' +s[end:]
s=s.replace("def prose_spacing(value):","next_path=B/'implementation-B/ordering-outcome-next-assessment-v1.json'\nreport['next_assessment']=read(next_path)\nreport['next_assessment_source']=pin(next_path)\nreport['ordering_diagnostic_text']='Passive joins of 53 completed empty point-proposal events show that the first premise of every eligible instance is absent from the actual contiguous proof prefix and named hypotheses. The unchanged expansion condition therefore rejects these calls at their first receptor. The point prefix keeps repeating a universal axiom rather than assembling the diverse premises needed by the inventory. This diagnosis does not cover an unlogged interrupted call.'\n\ndef prose_spacing(value):")

(B/'root/build_ordering_report_v1.py').write_text(s)
