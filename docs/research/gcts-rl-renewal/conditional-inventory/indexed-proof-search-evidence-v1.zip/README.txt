Complete prepublication evidence cut. MANIFEST.json maps every member to its original path/mode/bytes/SHA.
All explicit originals, including failed study001 and admitted qualification/main002, are retained without replay.
All six reused scientific Sources are included; original paths are provenance, not required external Source availability.
Reproduction requires a fresh reviewed loader/plan/authority; spent grants must never be rerun.
The prior Z public evidence ZIP is an external exact-pinned upstream dependency, not recursively bundled.
Platform runtimes, bare Git repositories, payload twins, this ZIP and later publication/TLS/Pages/live receipts are outside the cut.
Generated MANIFEST/README and this ZIP cannot hash themselves; PACKAGING-INPUT preserves the exact closed input.

All current operative Sources, complete current qualification31files, failed001all5availablefiles, admitted002all88files, current API/peers/reviews, actual finalreportHTML+JSON, all90localUIchecks/navigation/screenshot and direct current dependencies.
Main actual outcomes:eager5verified10unknown,indexed8verified7unknown,control9verified5finiteNOT1unknown. All22successful coarse/original certificate pairs are included. No RL, freshC1, unseen theorem, universal palette/fullPA/Hilbert or plane-tiling claim.
Raw scientific carriers and actual proof data are byte-identical originals. Generated manifest and README selfexclude; no lossy summary substitutes for any listed current original.
Prefix scopes remain explicit: main218of51174event bodies,417of8679rollback bodies,120of25390query records; hashes do not recreate unavailable suffixes.
Original paths are provenance. Fresh replay must map included sources/inputs to local paths and use a new reviewed loader/plan/authority; spent grants must not be reused.
