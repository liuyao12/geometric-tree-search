"""Independent finite contact oracle and bounded qualification; inert Source only.

No project imports or top-level calls. Context filtering is an implementation of
one unchanged finite inventory, not a logical producer restriction. The injected
old growing audit receives a disclosed expanded CHECK COPY, never altered actual
records: omitted potential contacts may be added only when presently t/m-illegal.
"""
import hashlib
import json
import math
import time

VERSION = 'IP-INDEPENDENT-CONTACT-AUDIT-v1'
QUERY_ABI = 'IP-CURRENT-TM-INCIDENT-v1'
AUDIT_LIMITS = dict(wall_seconds=15, max_work=100000000, max_depth=128, max_items=200000)
ENGINE_LIMITS = dict(wall_seconds=2, max_work=20000000, max_nodes=10000,
                     max_events=4096, max_rollback_records=4096,
                     max_candidates=1000, max_points=64)
FACTORY_LIMITS = dict(wall_seconds=5, max_work=100000000, max_depth=128,
                      max_definitions=10000, max_proof_lines=64)
CHECK_LIMITS = dict(max_proof_lines=64, max_operations=100000000, max_depth=128)


class Rejected(ValueError):
    pass


class _Stop(Exception):
    pass


class _Foreign(Exception):
    pass


def _need(condition, reason):
    if not condition:
        raise Rejected(reason)


class _Meter:
    def __init__(self, limits=None, budget=None):
        x = AUDIT_LIMITS if limits is None else limits
        _need(type(x) is dict and set(x) == set(AUDIT_LIMITS), 'LIMIT_FIELDS')
        w = x['wall_seconds']
        _need(type(w) in (int, float) and math.isfinite(w) and 0 < w <= 60, 'LIMIT_WALL')
        for k in ('max_work', 'max_depth', 'max_items'):
            _need(type(x[k]) is int and 0 <= x[k] <= 1000000000, 'LIMIT_INTEGER')
        self.limits = dict(x)
        self.started = time.perf_counter()
        self.work = 0
        self.budget = budget

    def tick(self, n=1, depth=0):
        _need(type(n) is int and n >= 0, 'CHARGE')
        if self.budget is not None:
            self.budget()
        if depth > self.limits['max_depth']:
            raise _Stop('MAX_DEPTH')
        if n > self.limits['max_work'] - self.work:
            raise _Stop('MAX_WORK')
        if time.perf_counter() - self.started >= self.limits['wall_seconds']:
            raise _Stop('WALL_SECONDS')
        self.work += n

    def size(self, n):
        self.tick(n + 1)
        if n > self.limits['max_items']:
            raise _Stop('MAX_ITEMS')

    def costs(self):
        return dict(work=self.work, seconds=time.perf_counter() - self.started)


def _copy(x, m, depth=0, active=None):
    m.tick(1, depth)
    if type(x) is str:
        m.tick(2 + 12 * len(x), depth)
        return x
    if x is None or type(x) is bool:
        m.tick(5, depth)
        return x
    if type(x) is int:
        _need(x.bit_length() <= 256, 'JSON_INT')
        m.tick(80, depth)
        return x
    if type(x) is float:
        _need(math.isfinite(x), 'JSON_FLOAT')
        m.tick(128, depth)
        return x
    _need(type(x) in (list, dict), 'JSON_TYPE')
    if active is None:
        active = set()
    _need(id(x) not in active, 'JSON_CYCLE')
    m.size(len(x))
    m.tick(2 + 2 * len(x), depth)
    active.add(id(x))
    try:
        if type(x) is list:
            return [_copy(v, m, depth + 1, active) for v in x]
        _need(all(type(k) is str for k in x), 'JSON_KEY')
        return {_copy(k, m, depth + 1, active): _copy(v, m, depth + 1, active)
                for k, v in x.items()}
    finally:
        active.remove(id(x))


def _text(x):
    return json.dumps(x, ensure_ascii=True, sort_keys=True,
                      separators=(',', ':'), allow_nan=False)


def _wire(x):
    return (_text(x) + '\n').encode('ascii')


def _sha(x):
    return hashlib.sha256(_wire(x)).hexdigest()


def _fields(x, names):
    _need(type(x) is dict and len(x) == len(names) and set(x) == set(names)
          and all(type(k) is str for k in x), 'FIELDS')


def _rows(rows, marking=False, capacity=None, seed=False):
    _need(type(rows) is list, 'ROWS')
    seen = set()
    for row in rows:
        _need(type(row) is list and len(row) == 2 and type(row[0]) is str
              and row[0] not in seen, 'ROW')
        seen.add(row[0])
        if marking:
            _need(type(row[1]) is str, 'MARK_LITERAL')
        else:
            _need(type(row[1]) is int and (0 if seed else 1) <= row[1] <= capacity,
                  'CAPACITY_INTEGER')
    return sorted(rows, key=lambda r: r[0])


def _inventory(model, universe, m):
    model = _copy(model, m)
    universe = _copy(universe, m)
    _fields(model, ('schema', 'version', 'capacity', 'roots', 'seed', 'inventory'))
    _need(model['schema'] == 'Z-growing-point-model-v1'
          and type(model['version']) is str and model['version'], 'MODEL')
    cap = model['capacity']
    _need(type(cap) is int and cap >= 1, 'CAPACITY')
    _need(type(model['roots']) is list and all(type(p) is str for p in model['roots'])
          and len(set(model['roots'])) == len(model['roots']), 'ROOTS')
    model['roots'].sort()
    _fields(model['seed'], ('t', 'm'))
    model['seed']['t'] = _rows(model['seed']['t'], capacity=cap, seed=True)
    model['seed']['m'] = _rows(model['seed']['m'], marking=True)
    _need(type(universe) is list, 'UNIVERSE')
    table = {}
    for row in universe:
        m.tick()
        _fields(row, ('id', 't', 'm'))
        cid = row['id']
        _need(type(cid) is str and cid and cid not in table, 'CID')
        row['t'] = _rows(row['t'], capacity=cap)
        row['m'] = _rows(row['m'], marking=True)
        _need(row['t'], 'POSITIVE_SUPPORT')
        table[cid] = row
    inv = model['inventory']
    _need(type(inv) is dict, 'INVENTORY')
    if inv.get('kind') == 'EXPLICIT':
        _fields(inv, ('kind', 'placements'))
        _need(_text(sorted(inv['placements'], key=lambda r: r['id']))
              == _text([table[k] for k in sorted(table)]), 'EXPLICIT_UNIVERSE')
        inv['placements'] = [table[k] for k in sorted(table)]
    else:
        _fields(inv, ('kind', 'identity'))
        _need(inv['kind'] == 'CERTIFIED_INCIDENT' and type(inv['identity']) is str
              and inv['identity'], 'INCIDENT_IDENTITY')
    return model, table


def _compatible(row, cap, totals, marks, charge):
    for p, n in row['t']:
        charge()
        if totals.get(p, 0) + n > cap:
            return False
    for p, v in row['m']:
        charge()
        if p in marks and marks[p] != v:
            return False
    return True


def _query(model, universe, query, reply, m):
    _need(model['inventory']['kind'] == 'CERTIFIED_INCIDENT', 'QUERY_MODEL_KIND')
    query = _copy(query, m)
    reply = _copy(reply, m)
    _fields(query, ('schema', 'inventory_identity', 'point', 'capacity', 'totals', 'marks'))
    _need(query['schema'] == 'IP-current-tm-incident-query-v1'
          and query['inventory_identity'] == model['inventory']['identity']
          and type(query['point']) is str and type(query['capacity']) is int
          and query['capacity'] == model['capacity'], 'QUERY_BINDING')
    totals = _rows(query['totals'], capacity=model['capacity'], seed=True)
    marks = _rows(query['marks'], marking=True)
    _need(totals == query['totals'] and marks == query['marks'], 'SORTED_QUERY')
    t, a = dict(totals), dict(marks)
    potential = []
    compatible = []
    for cid in sorted(universe):
        row = universe[cid]
        m.tick(1 + len(row['t']))
        if any(p == query['point'] for p, n in row['t']):
            potential.append(cid)
            if _compatible(row, model['capacity'], t, a, m.tick):
                compatible.append(row)
    _fields(reply, ('point', 'context_sha256', 'complete', 'placements', 'certificate'))
    _need(reply['point'] == query['point'] and reply['context_sha256'] == _sha(query)
          and reply['complete'] is True, 'REPLY_CONTEXT')
    cert = reply['certificate']
    _fields(cert, ('scope', 'potential_count', 'compatible_count'))
    _need(cert['scope'] == 'COMPLETE_CURRENT_TM_COMPATIBLE_INCIDENT_SET'
          and type(cert['potential_count']) is int and cert['potential_count'] == len(potential)
          and type(cert['compatible_count']) is int and cert['compatible_count'] == len(compatible),
          'QUERY_COUNTS')
    _need(type(reply['placements']) is list and all(type(r) is dict and type(r.get('id')) is str
              for r in reply['placements']), 'REPLY_PLACEMENTS')
    ids = [r['id'] for r in reply['placements']]
    _need(len(set(ids)) == len(ids)
          and _text(sorted(reply['placements'], key=lambda r: r['id'])) == _text(compatible),
          'WHOLE_COMPATIBLE_INCIDENT_SET')
    return dict(context_sha256=_sha(query), potential_ids=potential,
                compatible_ids=[r['id'] for r in compatible])


def _receipt(status, reason, details, m):
    return dict(schema='IP-independent-contact-audit-v1', version=VERSION,
                status=status, reason=reason, details=details, costs=m.costs(),
                scope='Complete declared finite inventory/context only; no logical zero-schema or unrestricted proof claim.')


def verify_query(model, universe, query, reply, *, limits=None):
    m = _Meter(limits)
    try:
        model, table = _inventory(model, universe, m)
        details = _query(model, table, query, reply, m)
        m.tick()
        return _receipt('VERIFIED', None, details, m)
    except _Stop as e:
        return _receipt('UNKNOWN', str(e), None, m)
    except Rejected as e:
        return _receipt('REJECTED', str(e), None, m)


def _projection(model, table, actual, m):
    """Audit actual registry, add only t/m-impossible hidden rows to CHECK COPY."""
    state = _copy(actual, m)
    _fields(state, ('Q', 'totals', 'selected', 'marks', 'excluded', 'eligible', 'domains',
                    'forward', 'reverse', 'placements', 'loaded', 'dependencies', 'edge_count'))
    _need(type(state['placements']) is list and type(state['loaded']) is list, 'STATE_LISTS')
    _need(state['loaded'] == sorted(set(state['loaded']))
          and all(type(p) is str for p in state['loaded']), 'LOADED')
    actual_known = {}
    for row in state['placements']:
        m.tick()
        _need(type(row) is dict and row.get('id') in table, 'REGISTERED_ID')
        cid = row['id']
        _need(cid not in actual_known and _text(row) == _text(table[cid]), 'REGISTERED_PAYLOAD')
        actual_known[cid] = row
    _need(list(actual_known) == sorted(actual_known), 'REGISTERED_ORDER')
    _fields(state['dependencies'], ('t', 'm'))
    expected_dependencies = {}
    for channel in ('t', 'm'):
        inv = {}
        for cid, row in actual_known.items():
            for p, value in row[channel]:
                m.tick()
                inv.setdefault(p, []).append(cid)
        expected_dependencies[channel] = [[p, sorted(inv[p])] for p in sorted(inv)]
    _need(state['dependencies'] == expected_dependencies, 'ACTUAL_REGISTERED_DEPENDENCIES')
    totals = dict(_rows(state['totals'], capacity=model['capacity'], seed=True))
    marks = {}
    _need(type(state['marks']) is list, 'STATE_MARKS')
    for row in state['marks']:
        _need(type(row) is list and len(row) == 3 and type(row[0]) is str
              and type(row[1]) is str and type(row[2]) is int and row[2] >= 1
              and row[0] not in marks, 'STATE_MARK_REFCOUNT')
        marks[row[0]] = row[1]
    loaded = set(state['loaded'])
    full = {}
    for cid, row in table.items():
        m.tick(1 + len(row['t']))
        if model['inventory']['kind'] == 'EXPLICIT' or any(p in loaded for p, n in row['t']):
            full[cid] = row
    _need(set(actual_known) <= set(full), 'REGISTERED_TOUCHES_EXHAUSTED_POINT')
    if model['inventory']['kind'] == 'EXPLICIT':
        _need(set(actual_known) == set(full), 'WHOLE_EXPLICIT_REGISTRY')
    hidden = []
    for cid in sorted(set(full) - set(actual_known)):
        _need(not _compatible(table[cid], model['capacity'], totals, marks, m.tick),
              'HIDDEN_CURRENTLY_COMPATIBLE_CONTACT')
        hidden.append(cid)
    state['placements'] = [full[cid] for cid in sorted(full)]
    dep = {}
    for channel in ('t', 'm'):
        inv = {}
        for cid, row in full.items():
            for p, value in row[channel]:
                m.tick(); inv.setdefault(p, []).append(cid)
        dep[channel] = [[p, sorted(inv[p])] for p in sorted(inv)]
    state['dependencies'] = dep
    return state, hidden


def verify_state(growth_audit, model, universe, state, *, limits=None):
    m = _Meter(limits)
    try:
        normal, table = _inventory(model, universe, m)
        expanded, hidden = _projection(normal, table, state, m)
        checked = growth_audit.verify_state(normal, expanded, universe=universe,
                                            limits=dict(m.limits))
        if checked['status'] == 'UNKNOWN':
            raise _Stop('INHERITED_STATE_AUDIT_' + str(checked['reason']))
        _need(checked['status'] == 'VERIFIED', 'INHERITED_STATE_REJECTED')
        return _receipt('VERIFIED', None,
                        dict(actual_state_sha256=_sha(state), expanded_check_sha256=_sha(expanded),
                             hidden_currently_illegal_ids=hidden, inherited=checked), m)
    except _Stop as e:
        return _receipt('UNKNOWN', str(e), None, m)
    except Rejected as e:
        return _receipt('REJECTED', str(e), None, m)


def _proof_inventory(compiled, depth, m):
    """Small complete structural oracle; zero logical truth remains external."""
    c = _copy(compiled, m)
    _need(type(depth) is int and 0 <= depth <= 8, 'ORACLE_DEPTH')
    forms = c['logical_basis']['formulas']
    colors = c['logical_basis']['colors']
    _need(type(forms) is list and colors == [_text(f) for f in forms]
          and colors == sorted(set(colors)), 'FORMULA_COLOR_BIJECTION')
    by = {v: i for i, v in enumerate(colors)}
    definitions = []
    for i, z in enumerate(c['zero_instances']):
        _need(z['id'] == 'i' + str(i) and type(z['formula_id']) is int
              and 0 <= z['formula_id'] < len(forms)
              and z['line']['formula'] == forms[z['formula_id']], 'ZERO_BINDING')
        definitions.append(dict(id=_text(['zero', z['id']]), kind='ZERO', output=z['formula_id'],
                                premises=[], zero_id=z['id'], variable=None, native_rule=z['rule']))
    mp, gen = [], []
    for fid, f in enumerate(forms):
        m.tick()
        if f[0] == 'imp' and _text(f[1]) in by and _text(f[2]) in by:
            a, out = by[_text(f[1])], by[_text(f[2])]
            mp.append([fid, a, out])
            definitions.append(dict(id=_text(['mp', fid, a, out]), kind='MP', output=out,
                                    premises=[a, fid], zero_id=None, variable=None, native_rule='mp'))
        if f[0] == 'all' and _text(f[2]) in by:
            body = by[_text(f[2])]
            gen.append([fid, body, f[1]])
            definitions.append(dict(id=_text(['gen', fid, body, f[1]]), kind='GEN', output=fid,
                                    premises=[body], zero_id=None, variable=f[1], native_rule='generalize'))
    _need(mp == c['mp_index'] and gen == c['gen_index'], 'COMPLETE_MP_GEN')
    definitions.sort(key=lambda d: d['id'])
    sites = ['']
    for level in range(depth):
        m.size(len(sites) + (1 << (level + 1)))
        sites.extend(format(i, '0' + str(level + 1) + 'b') for i in range(1 << (level + 1)))
    m.size(len(sites) * len(definitions))
    placements = []
    for site in sites:
        for d in definitions:
            m.tick()
            if len(site) == depth and d['premises']:
                continue
            supports = [site] + [site + str(i) for i in range(len(d['premises']))]
            fids = [d['output']] + d['premises']
            placements.append(dict(id=_text([site, d['id']]), t=[[p, 1] for p in supports],
                                   m=[[p, colors[f]] for p, f in zip(supports, fids)]))
    placements.sort(key=lambda p: p['id'])
    return definitions, sorted(sites), placements


def verify_description(compiled, depth, identity, point, description, *, limits=None):
    m = _Meter(limits)
    try:
        defs, sites, placements = _proof_inventory(compiled, depth, m)
        _need(point in sites and type(identity) is str, 'DESCRIBE_POINT')
        d = _copy(description, m)
        _fields(d, ('point', 'inventory_identity', 'complete', 'families',
                    'dependencies', 'potential_count', 'scope'))
        families = []
        anchors = [point] + ([point[:-1]] if point else [])
        for anchor in anchors:
            for arity in range(3):
                ids = [x['id'] for x in defs if len(x['premises']) == arity
                       and (len(anchor) < depth or arity == 0)
                       and (anchor == point or (arity >= 1 and point[-1] == '0')
                            or (arity == 2 and point[-1] == '1'))]
                if ids:
                    supports = [anchor] + [anchor + str(i) for i in range(arity)]
                    families.append(dict(anchor=anchor, arity=arity,
                                         id=_text(['IP-arity-family-v1', anchor, arity]),
                                         definition_ids=ids, t_points=supports, m_points=list(supports)))
        families.sort(key=lambda f: f['id'])
        deps = sorted({p for f in families for p in f['t_points']})
        expected = dict(point=point, inventory_identity=identity, complete=True,
                        families=families, dependencies=dict(t=deps, m=list(deps)),
                        potential_count=sum(len(f['definition_ids']) for f in families),
                        scope='COMPLETE_STATIC_OWN_AND_ALL_PARENT_ALIGNMENT_FAMILIES')
        _need(_text(d) == _text(expected), 'COMPLETE_STATIC_FAMILIES')
        actual_ids = [x['id'] for x in placements if any(p == point for p, n in x['t'])]
        _need(len(actual_ids) == d['potential_count'], 'STATIC_POINT_CARDINALITY')
        return _receipt('VERIFIED', None, dict(potential_ids=actual_ids, families=expected), m)
    except _Stop as e:
        return _receipt('UNKNOWN', str(e), None, m)
    except Rejected as e:
        return _receipt('REJECTED', str(e), None, m)


def _literal_models():
    def c(cid, t, marks=None):
        return dict(id=cid, t=t, m=[] if marks is None else marks)
    def f(name, roots, seed, rows, cap=2, marks=None):
        return name, dict(schema='Z-growing-point-model-v1', version='IP-TINY-' + name,
                          capacity=cap, roots=roots, seed=dict(t=seed, m=[] if marks is None else marks),
                          inventory=dict(kind='EXPLICIT', placements=rows))
    return [
        f('half-root', ['r'], [['r', 1]], [c('a', [['r', 1]])]),
        f('shared-forced', ['p', 'q'], [['p', 1], ['q', 1]], [c('a', [['p', 1], ['q', 1]])]),
        f('thirds-shared', ['p', 'q'], [['p', 1], ['q', 1]],
          [c('a', [['p', 1], ['q', 1]]), c('b', [['p', 1], ['q', 1]])], 3),
        f('fractional-residual-dead', ['p'], [['p', 1]], [c('a', [['p', 1]])], 3),
        f('capacity-four-selected-filter', ['p'], [['p', 1]],
          [c('a', [['p', 1]]), c('b', [['p', 2]]), c('c', [['p', 1]])], 4),
        f('remote-mark', ['p', 'q'], [['p', 1], ['q', 1]],
          [c('a0', [['p', 1]], [['remote', '0']]), c('a1', [['p', 1]], [['remote', '1']]),
           c('b0', [['q', 1]], [['remote', '0']]), c('b1', [['q', 1]], [['remote', '1']])]),
        f('absent-versus-zero', ['p'], [['p', 1]],
          [c('a', [['p', 1]], [['remote', '0']]), c('b', [['p', 1]])], marks=[['remote', '1']]),
        f('late-dead-before-forced', ['r', 'u'], [['r', 1], ['u', 1]],
          [c('a', [['r', 1], ['x', 1]]), c('b', [['u', 1]])]),
        f('forced-before-generation', ['r', 'u'], [['r', 1], ['u', 1]],
          [c('a', [['r', 1], ['x', 1]]), c('b', [['u', 1]]), c('c', [['u', 1]]), c('d', [['x', 1]])]),
        f('generation-before-degree', ['r', 'u'], [['r', 1], ['u', 1]],
          [c('a', [['r', 1], ['x', 1]]), c('b', [['u', 1]]), c('c', [['u', 1]]), c('d', [['u', 1]]),
           c('e', [['x', 1]]), c('f', [['x', 1]])]),
        f('bad-first-restore', ['r'], [['r', 1]], [c('a', [['r', 1], ['x', 1]]), c('b', [['r', 1]])]),
        f('parent-positive-contacts', ['r'], [['r', 1]], [c('a', [['r', 1], ['x', 1]]), c('b', [['x', 1]])]),
    ]


def _tiny_catalogue(axioms, goal):
    """A declared structural zero-axiom fixture; no full Y grammar claim."""
    pool = {}
    todo = [goal] + list(axioms.values())
    while todo:
        f = todo.pop()
        k = _text(f)
        if k in pool:
            continue
        pool[k] = f
        if f[0] == 'imp':
            todo.extend(f[1:])
        elif f[0] == 'all':
            todo.append(f[2])
    colors = sorted(pool)
    forms = [pool[k] for k in colors]
    by = {k: i for i, k in enumerate(colors)}
    lines = sorted([dict(rule='axiom', name=n, formula=f) for n, f in axioms.items()], key=_text)
    zeros = [dict(id='i' + str(i), rule='axiom', formula_id=by[_text(l['formula'])], line=l)
             for i, l in enumerate(lines)]
    profile = dict(ui_rounds=0, bridge_arity=0, max_tautology_atoms=0)
    c = dict(schema='V-interned-Hilbert8-basis-v1', version='V-INTERNED-FINITE-HILBERT8-v1',
             theory=dict(functions={}, predicates=dict(P=0, Q=0, R=0), axioms=axioms),
             goal=goal, goal_id=by[_text(goal)], profile=profile,
             logical_basis=dict(instantiation_terms=[], terms=[], variables=[], formulas=forms,
                                colors=colors, templates=[], hole='__ip_fixture', stages=[]),
             zero_instances=zeros,
             mp_index=[[i, by[_text(f[1])], by[_text(f[2])]] for i, f in enumerate(forms) if f[0] == 'imp'],
             gen_index=[[i, by[_text(f[2])], f[1]] for i, f in enumerate(forms) if f[0] == 'all'],
             costs=dict(work=0, seconds=0.0, terms=0, formulas=len(forms), instances=len(zeros),
                        candidates=0, cache_hits=0, cache_misses=0, canonical_serializations=0, substitution_calls=0),
             scope='SYNTHETIC_STRUCTURAL_NATIVE_AXIOM_FIXTURE_NOT_FULL_Y_GENERATION')
    g = dict(schema='Y-goal-receptor-universe-v1', version='Y-GOAL-RECEPTOR-FAMILY-v1',
             profile=profile, compiled_core_sha256=_sha({k: v for k, v in c.items() if k not in ('costs', 'scope')}),
             core_stages=[], core_assertions=[], goal_receptors=[], bridge_premises=[], scope=c['scope'])
    return c, g


def _brute(model, table, m):
    ids = sorted(table)
    _need(len(ids) <= 14, 'BRUTE_DECLARED_MAX14')
    m.size(1 << len(ids))
    out = []
    for bits in range(1 << len(ids)):
        m.tick(1 + len(ids))
        chosen = [ids[i] for i in range(len(ids)) if bits & (1 << i)]
        totals = dict(model['seed']['t'])
        marks = dict(model['seed']['m'])
        active = set(model['roots']) | {p for p, n in model['seed']['t'] if n}
        good = True
        for cid in chosen:
            row = table[cid]
            m.tick(1 + len(row['t']) + len(row['m']))
            for p, n in row['t']:
                totals[p] = totals.get(p, 0) + n
                if totals[p] > model['capacity']:
                    good = False
            for p, v in row['m']:
                if p in marks and marks[p] != v:
                    good = False
                marks[p] = v
        if not good:
            continue
        pending = set(chosen)
        while pending:
            m.tick(1 + sum(len(table[cid]['t']) for cid in pending))
            ready = [cid for cid in sorted(pending) if any(p in active for p, n in table[cid]['t'])]
            if not ready:
                break
            for cid in ready:
                pending.remove(cid)
                active.update(p for p, n in table[cid]['t'])
        if not pending and all(totals.get(p, 0) == model['capacity'] for p in active):
            out.append(chosen)
    return out


def verify_result(growth_audit, model, universe, result, observations, *, limits=None):
    m = _Meter(limits)
    try:
        normal, table = _inventory(model, universe, m)
        actual = _copy(result, m)
        seen = _copy(observations, m)
        _need(type(seen) is list, 'OBSERVATIONS')
        projected = _copy(actual, m)
        evidence = projected.pop('provider_evidence', None)
        indexed = actual.get('version') == 'IP-GROWING-POINT-SEARCH-v2'
        _need(indexed or actual.get('version') == 'Z-GROWING-POINT-SEARCH-v1', 'RESULT_VERSION')
        _need(indexed == (evidence is not None), 'RESULT_EVIDENCE_VERSION')
        _need(actual.get('schema') == 'Z-growing-point-search-result-v1', 'RESULT_SCHEMA')
        projected['version'] = 'Z-GROWING-POINT-SEARCH-v1'
        contexts = []
        for key in ('entry', 'final', 'restored'):
            state = actual[key + '_state']
            supplied = actual['state_hashes'][key]
            if state is None:
                _need(supplied is None and actual['status'] == 'UNKNOWN', 'ABSENT_IMAGE_HASH')
            else:
                _need(type(supplied) is str and supplied == _sha(state), 'ORIGINAL_IMAGE_HASH')
                state_copy, hidden = _projection(normal, table, state, m)
                projected[key + '_state'] = state_copy
                projected['state_hashes'][key] = _sha(state_copy)
                contexts.append(state)
        projected_seen = []
        for row in seen:
            _fields(row, ('event', 'state'))
            state_copy, hidden = _projection(normal, table, row['state'], m)
            projected_seen.append(dict(event=row['event'], state=state_copy))
            contexts.append(row['state'])
        inherited = growth_audit.verify_result(normal, projected, universe=universe,
                                               observations=projected_seen, limits=dict(m.limits))
        if inherited['status'] == 'UNKNOWN':
            raise _Stop('INHERITED_RESULT_AUDIT_' + str(inherited['reason']))
        _need(inherited['status'] == 'VERIFIED', 'INHERITED_RESULT_REJECTED')
        evidence_details = None
        if indexed:
            _fields(evidence, ('mode', 'total', 'retained', 'sha256', 'scope', 'records', 'costs'))
            _need(evidence['mode'] in ('UNINITIALIZED', 'EXPLICIT', 'EAGER_ALL_POTENTIAL',
                                      'INDEXED_CURRENT_TM_COMPATIBLE'), 'EVIDENCE_MODE')
            _need(type(evidence['records']) is list and type(evidence['total']) is int
                  and type(evidence['retained']) is int and 0 <= evidence['retained'] <= evidence['total']
                  and len(evidence['records']) == evidence['retained']
                  and evidence['retained'] <= actual['limits']['max_events']
                  and evidence['scope'] == 'BOUNDED_PREFIX_OF_COMPLETED_VALIDATED_INDEX_QUERIES',
                  'EVIDENCE_EXTENT')
            costs = evidence['costs']
            _fields(costs, ('query_attempts', 'query_work', 'query_seconds', 'receipt_work',
                            'potential_contacts', 'returned_contacts', 'context_values'))
            for key, value in costs.items():
                if key == 'query_seconds':
                    _need(type(value) in (int, float) and math.isfinite(value) and value >= 0, 'QUERY_SECONDS')
                else:
                    _need(type(value) is int and value >= 0, 'QUERY_COST_INTEGER')
            _need(costs['query_attempts'] >= evidence['total']
                  and costs['query_work'] <= actual['stats']['work']
                  and costs['receipt_work'] <= actual['stats']['work'], 'QUERY_COST_SCOPE')
            stream = hashlib.sha256()
            sums = dict(potential_contacts=0, returned_contacts=0, context_values=0)
            unjoined = []
            for i, record in enumerate(evidence['records']):
                _fields(record, ('query', 'reply'))
                _query(normal, table, record['query'], record['reply'], m)
                stream.update(_wire(record))
                sums['potential_contacts'] += record['reply']['certificate']['potential_count']
                sums['returned_contacts'] += record['reply']['certificate']['compatible_count']
                sums['context_values'] += len(record['query']['totals']) + len(record['query']['marks'])
                q = record['query']
                matches = [s for s in contexts if s['totals'] == q['totals']
                           and [[p, v] for p, v, refs in s['marks']] == q['marks']
                           and q['point'] in dict(s['Q'])]
                if not matches:
                    unjoined.append(i)
            if evidence['total'] == evidence['retained']:
                _need(stream.hexdigest() == evidence['sha256'], 'COMPLETE_QUERY_STREAM_HASH')
            else:
                _need(type(evidence['sha256']) is str
                      and len(evidence['sha256']) == 64, 'PREFIX_QUERY_HASH')
            for key in sums:
                _need(costs[key] >= sums[key], 'QUERY_COST_PREFIX_LOWER_BOUND')
                if actual['status'] != 'UNKNOWN' and evidence['total'] == evidence['retained']:
                    _need(costs[key] == sums[key], 'COMPLETE_QUERY_COST_SUM')
            if actual['status'] != 'UNKNOWN':
                _need(not unjoined, 'AUTHORITATIVE_QUERY_CONTEXT_JOIN')
            if evidence['mode'] != 'INDEXED_CURRENT_TM_COMPATIBLE':
                _need(evidence['total'] == 0 and costs['query_attempts'] == 0, 'NONINDEXED_NO_QUERY_RECORDS')
            evidence_details = dict(total=evidence['total'], retained=evidence['retained'],
                                    whole_retained=evidence['total'] == evidence['retained'],
                                    context_join_unobserved_indices=unjoined,
                                    prefix_scope='Owned UNKNOWN may stop after query validation before a completed event image; unmatched query contexts are not invented states.')
        return _receipt('VERIFIED', None, dict(inherited=inherited, provider_evidence=evidence_details,
                                               original_images_and_hashes_preserved=True,
                                               observations=len(seen)), m)
    except _Stop as e:
        return _receipt('UNKNOWN', str(e), None, m)
    except Rejected as e:
        return _receipt('REJECTED', str(e), None, m)


class _ContextProvider:
    incident_query_abi = QUERY_ABI

    def __init__(self, model, universe):
        self.model = model
        self.rows = sorted(universe, key=lambda r: r['id'])
        self.records = []
        self.mode = None

    def __call__(self, query, charge):
        charge(1 + len(self.rows) + len(query['totals']) + len(query['marks']))
        if self.mode == 'FOREIGN':
            raise _Foreign('query callback')
        if self.mode == 'STICKY':
            try:
                charge(1000000000000000000)
            except Exception:
                pass
        before = json.loads(_text(query))
        totals, marks = dict(query['totals']), dict(query['marks'])
        potential, rows = 0, []
        for row in self.rows:
            charge(1 + len(row['t']))
            if any(p == query['point'] for p, n in row['t']):
                potential += 1
                if _compatible(row, query['capacity'], totals, marks, charge):
                    rows.append(row)
        charge(1 + len(_text(query)) + sum(len(_text(r)) for r in rows))
        reply = dict(point=query['point'], context_sha256=_sha(query), complete=True,
                     placements=json.loads(_text(rows)),
                     certificate=dict(scope='COMPLETE_CURRENT_TM_COMPATIBLE_INCIDENT_SET',
                                      potential_count=potential, compatible_count=len(rows)))
        if self.mode == 'BAD-HASH':
            h = reply['context_sha256']
            reply['context_sha256'] = ('0' if h[0] != '0' else '1') + h[1:]
        self.records.append(dict(query=before, reply=json.loads(_text(reply))))
        if self.mode == 'MUTATE-QUERY':
            query.clear()  # Detached callback input only; authoritative engine query must survive.
        return reply


class _CapturedProvider:
    incident_query_abi = QUERY_ABI

    def __init__(self, actual, model, universe):
        self.actual, self.model, self.universe = actual, model, universe
        self.records = []

    def __call__(self, query, charge):
        before = json.loads(_text(query))
        reply = self.actual(query, charge)
        checked = verify_query(self.model, self.universe, before, reply)
        _need(checked['status'] == 'VERIFIED', 'ACTUAL_INDEX_QUERY_FAILED_INDEPENDENT_CHECK')
        _need([r['id'] for r in reply['placements']]
              == sorted(r['id'] for r in reply['placements']), 'ADAPTER_PROMISED_LEXICAL_ORDER')
        self.records.append(dict(query=before, reply=json.loads(_text(reply)), audit=checked))
        return reply


class _EagerProvider:
    def __init__(self, rows):
        self.rows = rows

    def __call__(self, point, charge):
        charge(1 + len(self.rows))
        rows = []
        for row in self.rows:
            charge(1 + len(row['t']) + len(row['m']))
            if any(p == point for p, n in row['t']):
                rows.append(row)
        return dict(point=point, complete=True, placements=json.loads(_text(rows)))


def qualify(modules, emit, budget):
    """Closed 16 paired cases, nine refusals/faults and one data-only record."""
    started = time.perf_counter()
    _need(type(modules) is dict and callable(emit) and callable(budget), 'QUALIFY_CALLER')
    for key in ('engine_eager', 'adapter_eager', 'engine_indexed', 'adapter_indexed',
                'growth_audit', 'fol_checker'):
        _need(key in modules, 'MODULE_' + key)
    m = _Meter(dict(wall_seconds=60, max_work=1000000000, max_depth=128, max_items=200000), budget)
    calls = {}
    records = []
    names = []
    observations_total = 0
    captured_query_total = 0
    native_total = 0

    def call(role, name, *args, **kwargs):
        budget()
        key = role + '.' + name
        calls[key] = calls.get(key, 0) + 1
        answer = getattr(modules[role], name)(*args, **kwargs)
        budget()
        return answer

    def out(name, data):
        _need(name not in names and all(c.isascii() and (c.isalnum() or c in '-.') for c in name), 'EMIT_NAME')
        data.setdefault('native_certificates', [])
        names.append(name)
        records.append(data)
        emit(name, data)
        budget()

    def normal_model(name, explicit):
        row = json.loads(_text(explicit))
        rows = row['inventory']['placements']
        identity = _sha(dict(schema='IP-tiny-inventory-v1', placements=sorted(rows, key=lambda r: r['id'])))
        row['inventory'] = dict(kind='CERTIFIED_INCIDENT', identity=identity)
        return row, rows

    def run(model, universe, role, provider, limits=None, order=None, audit_mode=None, fault_observations=None):
        nonlocal observations_total, captured_query_total
        obs = [] if fault_observations is None else fault_observations
        def audit(event, state, charge):
            nonlocal observations_total
            check = verify_state(modules['growth_audit'], model, universe, state)
            _need(check['status'] == 'VERIFIED', 'OBSERVED_GRAPH_REJECTED')
            observations_total += 1
            obs.append(dict(event=json.loads(_text(event)), state=json.loads(_text(state))))
            if audit_mode == 'FOREIGN':
                raise _Foreign('audit callback')
        lim = dict(ENGINE_LIMITS if limits is None else limits)
        before = _sha(model)
        result = call(role, 'solve', model, lim, enumerate_incident=provider, order=order, audit=audit)
        _need(_sha(model) == before, 'MODEL_MUTATED')
        check = verify_result(modules['growth_audit'], model, universe, result, obs)
        _need(check['status'] == 'VERIFIED', 'WHOLE_RESULT_REJECTED')
        captures = getattr(provider, 'records', [])
        captured_query_total += len(captures)
        if result['status'] != 'UNKNOWN' and role == 'engine_indexed':
            e = result['provider_evidence']
            _need(e['total'] == e['retained'] == len(captures), 'NORMAL_FULL_QUERY_RETENTION')
            for actual, saved in zip(captures, e['records']):
                _need(_text(dict(query=actual['query'], reply=actual['reply'])) == _text(saved), 'QUERY_CAPTURE_JOIN')
        return dict(result=result, observations=obs, query_captures=captures, independent=check)

    def pair(name, model, universe, indexed_provider, eager_provider, extra=None, compiled=None, depth=None):
        nonlocal native_total
        normal, table = _inventory(model, universe, m)
        solutions = _brute(normal, table, m)
        indexed = run(model, universe, 'engine_indexed', indexed_provider)
        eager = run(model, universe, 'engine_eager', eager_provider)
        for lane in (indexed, eager):
            result = lane['result']
            _need(result['status'] != 'UNKNOWN', 'TINY_NORMAL_REFUSAL')
            _need((result['status'] == 'SAT') == bool(solutions), 'COMPLETE_TINY_SOLUTION_EXISTENCE')
            if result['status'] == 'SAT':
                _need(result['selected'] in solutions, 'ACTUAL_WITNESS_IN_COMPLETE_SET')
        # Both lexical schedulers use unchanged candidate IDs and complete graph.
        # Raw cache/registration counts and timings are deliberately not equalized.
        _need(indexed['result']['status'] == eager['result']['status']
              and indexed['result']['selected'] == eager['result']['selected'], 'SAME_INVENTORY_LEXICAL_RESULT')
        for lane in (indexed, eager):
            if name == 'bad-first-restore':
                _need(lane['result']['stats']['backtracks'] > 0
                      and lane['result']['stats']['exclusions'] > 0, 'REAL_FAILED_CHILD_REQUIRED')
        data = dict(case=name, model=model, universe=universe, complete_subset_count=1 << len(table),
                    all_root_reachable_solutions=solutions, indexed=indexed, eager=eager,
                    extra={} if extra is None else extra, native_certificates=[])
        if compiled is not None:
            for label, lane, adapter in [('indexed', indexed, 'adapter_indexed'), ('eager', eager, 'adapter_eager')]:
                if lane['result']['status'] != 'SAT':
                    continue
                decoded = call(adapter, 'decode', compiled, depth, lane['result']['selected'], dict(FACTORY_LIMITS))
                _need(decoded['status'] == 'UNVERIFIED_CERTIFICATE', 'DECODE_TINY_POSITIVE')
                tree = call('growth_audit', 'verify_tree', compiled, depth,
                            lane['result']['selected'], decoded)
                _need(tree['status'] == 'VERIFIED', 'WHOLE_ROOTED_TREE_CHECK')
                checked = call('fol_checker', 'check', compiled['theory'], decoded['proof'], compiled['goal'], dict(CHECK_LIMITS))
                _need(checked['status'] == 'VERIFIED', 'ACTUAL_HOST_FOL_TINY_CHECK')
                data[label + '_proof'] = dict(decoded=decoded, independent_tree=tree, host_FOL=checked)
                data['native_certificates'].append(dict(label=label, problem=dict(theory=compiled['theory'], goal=compiled['goal']), proof=decoded['proof']))
                native_total += 1
        out(name, data)

    # Generic capacities use an independently authored context provider through
    # the NEW path. The eager control has the identical certified-inventory model.
    generic = _literal_models()
    _need(len(generic) == 12, 'FIXED_GENERIC_COUNT')
    for name, explicit in generic:
        model, universe = normal_model(name, explicit)
        provider = _ContextProvider(model, universe)
        if name == 'capacity-four-selected-filter':
            provider.mode = 'MUTATE-QUERY'
        pair(name, model, universe, provider, _EagerProvider(universe),
             extra=dict(detached_query_mutation=provider.mode == 'MUTATE-QUERY'))

    p = ['pred', 'P', []]
    q = ['pred', 'Q', []]
    r = ['pred', 'R', []]
    fixtures = [
        ('proof-zero-alias-wrong-output', dict(q0=q, q1=q, wrong=r), q, 0),
        ('proof-unary', dict(p=p), ['all', 'x', p], 1),
        ('proof-binary-all-parent', dict(p=p, pq=['imp', p, q], wrong=r), q, 1),
        ('proof-missing-premise', dict(p=p, wrong=r), q, 1),
    ]
    for name, axioms, goal, depth in fixtures:
        compiled, generation = _tiny_catalogue(axioms, goal)
        # The negative MP fixture explicitly declares its missing implication
        # as an available formula, not a zero witness; structural indices remain complete.
        if name == 'proof-missing-premise':
            compiled, generation = _tiny_catalogue(axioms, ['imp', p, q])
            compiled['goal'] = q
            compiled['goal_id'] = compiled['logical_basis']['colors'].index(_text(q))
            generation['compiled_core_sha256'] = _sha({k: v for k, v in compiled.items() if k not in ('costs', 'scope')})
        definitions, sites, universe = _proof_inventory(compiled, depth, m)
        before_factory_inputs = _sha([compiled, generation])
        model_i, provider_i, receipt_i = call('adapter_indexed', 'make_provider', compiled, generation, depth, dict(FACTORY_LIMITS))
        model_e, provider_e, receipt_e = call('adapter_eager', 'make_provider', compiled, generation, depth, dict(FACTORY_LIMITS))
        _need(_sha([compiled, generation]) == before_factory_inputs, 'FACTORY_MUTATED_INPUT')
        _need(receipt_i['status'] == receipt_e['status'] == 'COMPLETE'
              and _text(model_i) == _text(model_e), 'FACTORY_SAME_MODEL')
        _need(receipt_i['value']['definitions'] == definitions
              and receipt_e['value']['definitions'] == definitions, 'FULL_DEFINITION_BIJECTION')
        fi = call('growth_audit', 'verify_factory', compiled, generation, depth, model_i, receipt_i)
        fe = call('growth_audit', 'verify_factory', compiled, generation, depth, model_e, receipt_e)
        _need(fi['status'] == fe['status'] == 'VERIFIED', 'UNCHANGED_FACTORY_ENVELOPE')
        described = []
        for point in sites:
            # This is charged qualification/index validation, outside timed main search.
            calls['adapter_indexed.describe'] = calls.get('adapter_indexed.describe', 0) + 1
            description = provider_i.describe(point, m.tick)
            checked = verify_description(compiled, depth, model_i['inventory']['identity'], point, description)
            _need(checked['status'] == 'VERIFIED', 'STATIC_ALL_PARENT_FAMILY_REJECTED')
            described.append(dict(point=point, description=description, independent=checked))
        captured = _CapturedProvider(provider_i, model_i, universe)
        pair(name, model_i, universe, captured, provider_e,
             extra=dict(compiled=compiled, generation=generation, factory_indexed=receipt_i,
                        factory_eager=receipt_e, audited_factory_indexed=fi, audited_factory_eager=fe,
                        descriptions=described), compiled=compiled, depth=depth)

    # Five owned refusals and four checked/foreign faults. No post-throw state is fabricated.
    base_model, base_rows = normal_model('special-base', generic[10][1])
    faults = [
        ('refusal-nodes', dict(ENGINE_LIMITS, max_nodes=0), None, None, None, 'UNKNOWN'),
        ('refusal-work', dict(ENGINE_LIMITS, max_work=1), None, None, None, 'UNKNOWN'),
        ('refusal-candidates', dict(ENGINE_LIMITS, max_candidates=1), None, None, None, 'UNKNOWN'),
        ('refusal-sticky-charge', dict(ENGINE_LIMITS), 'STICKY', None, None, 'UNKNOWN'),
        ('fault-query-foreign', dict(ENGINE_LIMITS), 'FOREIGN', None, None, _Foreign),
        ('fault-order-foreign', dict(ENGINE_LIMITS), None, 'FOREIGN', None, _Foreign),
        ('fault-audit-foreign', dict(ENGINE_LIMITS), None, None, 'FOREIGN', _Foreign),
        ('fault-context-binding', dict(ENGINE_LIMITS), 'BAD-HASH', None, None, modules['engine_indexed'].InventoryError),
        ('refusal-point-growth', dict(ENGINE_LIMITS, max_points=1), None, None, None, 'UNKNOWN'),
    ]
    for name, limits, provider_mode, order_mode, audit_mode, expected in faults:
        provider = _ContextProvider(base_model, base_rows)
        provider.mode = provider_mode
        def ordering(request, charge):
            if order_mode == 'FOREIGN':
                raise _Foreign('order callback')
            return []
        fault_observations = []
        try:
            answer = run(base_model, base_rows, 'engine_indexed', provider, limits,
                         ordering if order_mode else None, audit_mode, fault_observations)
        except Exception as e:
            captured_query_total += len(provider.records)
            _need(isinstance(expected, type) and type(e) is expected, 'UNEXPECTED_CALLBACK_FAILURE')
            out(name, dict(model=base_model, universe=base_rows, limits=limits,
                           expected_exception=expected.__name__, actual_exception=type(e).__name__,
                           message=str(e), no_post_exception_state_claim=True,
                           observations=fault_observations, query_captures=provider.records))
        else:
            _need(expected == 'UNKNOWN' and answer['result']['status'] == 'UNKNOWN', 'OWNED_REFUSAL_STATUS')
            out(name, dict(model=base_model, universe=base_rows, limits=limits, answer=answer))

    # Data-only isolated forgeries; no new engine/factory/solver calls.
    sample = records[0]
    packet = sample['indexed']['query_captures'][0]
    mutations = []
    for label in ('stale-hash', 'missing-contact', 'boolean-count'):
        forged = json.loads(_text(packet['reply']))
        if label == 'stale-hash':
            h = forged['context_sha256']
            forged['context_sha256'] = ('0' if h[0] != '0' else '1') + h[1:]
        elif label == 'missing-contact':
            forged['placements'] = []
            forged['certificate']['compatible_count'] = 0
        else:
            forged['certificate']['potential_count'] = True
        checked = verify_query(sample['model'], sample['universe'], packet['query'], forged)
        _need(checked['status'] == 'REJECTED', 'DATA_FORGERY_ACCEPTED')
        mutations.append(dict(label=label, query=packet['query'], forged=forged, independent=checked))
    forged_state = json.loads(_text(sample['indexed']['result']['entry_state']))
    forged_state['domains'][0][1] = []
    checked = verify_state(modules['growth_audit'], sample['model'], sample['universe'], forged_state)
    _need(checked['status'] == 'REJECTED', 'FORGED_EMPTY_DOMAIN_ACCEPTED')
    mutations.append(dict(label='false-dead-domain', forged=forged_state, independent=checked))
    out('data-only-query-graph-negatives', dict(mutations=mutations))
    fixed = {'engine_eager.solve': 16, 'engine_indexed.solve': 25,
             'adapter_eager.make_provider': 4, 'adapter_indexed.make_provider': 4,
             'adapter_eager.decode': 3, 'adapter_indexed.decode': 3,
             'growth_audit.verify_factory': 8, 'growth_audit.verify_tree': 6,
             'fol_checker.check': 6, 'adapter_indexed.describe': 10}
    _need(calls == fixed and len(names) == 26 and native_total == 6, 'EXACT_QUALIFICATION_CENSUS')
    m.tick()
    return dict(status='COMPLETE', version=VERSION, records=len(names), emitted_names=names,
                counts=calls, inherited_audit_counts=dict(verify_state=observations_total + 1, verify_result=37),
                native_certificates=native_total, observations=observations_total,
                captured_queries=captured_query_total, seconds=time.perf_counter() - started,
                scope='All finite tiny cases and fixed refusals/faults retained. Six actual host-FOL checks; no fresh native-C1/VM. Native-certificate lists are proof delivery records, not an assertion of another native execution.')
