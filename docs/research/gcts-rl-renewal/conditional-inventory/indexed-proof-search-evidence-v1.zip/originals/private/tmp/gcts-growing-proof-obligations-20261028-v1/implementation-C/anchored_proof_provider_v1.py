"""Inert finite Y-catalogue to anchored half-capacity proof-tree producer.

No project imports, IO, search, theorem-specific scripts or logical kernel.
Current independent catalogue/zero audits are required before activation.
"""
import hashlib
import json
import math
import time

VERSION = 'Z-ANCHORED-PROOF-PRODUCER-v1'
SCOPE = ('Finite anchored binary proof trees from the exact audited Y inventory. '
         'Integer capacity2 represents halves. No fixed Wang palette, infinite '
         'tiling, unrestricted FOL, sharing-as-one-node or RL claim. Logical '
         'zero witnesses and positive coarse/original proofs require independent kernels.')


class InputError(ValueError):
    pass


class _Stop(Exception):
    pass


def _fields(x, names):
    if (type(x) is not dict or len(x) != len(names)
            or any(type(k) is not str for k in x) or set(x) != set(names)):
        raise InputError('FIELDS')


def _limits(x):
    maxima = {'max_work': 1000000000, 'max_depth': 256,
              'max_definitions': 200000, 'max_proof_lines': 4096}
    _fields(x, tuple(maxima) + ('wall_seconds',))
    w = x['wall_seconds']
    if type(w) not in (int, float) or not 0 < w <= 60 or not math.isfinite(w):
        raise InputError('WALL')
    for k, maximum in maxima.items():
        if type(x[k]) is not int or not 0 <= x[k] <= maximum:
            raise InputError('LIMIT')
    return dict(x)


class _Meter:
    def __init__(self, limits):
        self.limits = _limits(limits)
        self.started = time.perf_counter()
        self.work = 0

    def tick(self, units=1, depth=0):
        if depth > self.limits['max_depth']:
            raise _Stop('DEPTH_LIMIT')
        if units > self.limits['max_work'] - self.work:
            raise _Stop('WORK_LIMIT')
        self.work += units
        if time.perf_counter() - self.started >= self.limits['wall_seconds']:
            raise _Stop('WALL_LIMIT')

    def costs(self):
        return {'work': self.work, 'seconds': time.perf_counter() - self.started,
                'scope': 'Own validation/copy/hash/index/output work; cooperative, not an OS quota.'}


def _copy(x, m, depth=0, active=None):
    m.tick(1, depth)
    if active is None:
        active = set()
    if type(x) is str:
        m.tick(2 + 12 * len(x), depth)
        return x
    if x is None or type(x) is bool:
        m.tick(5, depth)
        return x
    if type(x) is int:
        m.tick(2 + x.bit_length(), depth)
        return x
    if type(x) is float and math.isfinite(x):
        m.tick(128, depth)
        return x
    if type(x) not in (list, dict):
        raise InputError('JSON_TYPE')
    if id(x) in active:
        raise InputError('CYCLE')
    m.tick(2 * len(x) + 2, depth)
    active.add(id(x))
    try:
        if type(x) is list:
            return [_copy(v, m, depth + 1, active) for v in x]
        if any(type(k) is not str for k in x):
            raise InputError('KEY')
        return {_copy(k, m, depth + 1, active): _copy(v, m, depth + 1, active)
                for k, v in x.items()}
    finally:
        active.remove(id(x))


def _text(x):
    return json.dumps(x, sort_keys=True, ensure_ascii=True, separators=(',', ':'), allow_nan=False)


def _hash(x, m):
    # The detached copy reserved full JSON scalar/container extent before allocation.
    try:
        raw = (_text(x) + '\n').encode('ascii')
    except (ValueError, OverflowError) as error:
        raise _Stop('SERIALIZATION_LIMIT') from error
    m.tick(len(raw))
    return hashlib.sha256(raw).hexdigest()


def _name(x, m):
    if type(x) is not str or not 1 <= len(x) <= 64:
        raise InputError('NAME')
    m.tick(len(x) + 1)
    if any(ord(c) < 32 or ord(c) > 126 for c in x):
        raise InputError('NAME_ASCII')
    return x


def _term(t, signature, m, depth):
    m.tick(1, depth)
    if type(t) is not list or not t or type(t[0]) is not str:
        raise InputError('TERM')
    if t[0] == 'var' and len(t) == 2:
        return {_name(t[1], m)}
    if t[0] != 'fun' or len(t) != 3:
        raise InputError('TERM_SHAPE')
    name = _name(t[1], m)
    if type(t[2]) is not list or name not in signature or len(t[2]) != signature[name]:
        raise InputError('FUNCTION_ARITY')
    found = set()
    for child in t[2]:
        names = _term(child, signature, m, depth + 1)
        m.tick(len(names)); found.update(names)
    return found


def _form(f, functions, predicates, m, depth=0):
    m.tick(1, depth)
    if type(f) is not list or not f or type(f[0]) is not str:
        raise InputError('FORMULA')
    tag = f[0]
    if tag == 'bot' and len(f) == 1:
        return set()
    if tag == 'eq' and len(f) == 3:
        return _term(f[1], functions, m, depth + 1) | _term(f[2], functions, m, depth + 1)
    if tag == 'pred' and len(f) == 3:
        name = _name(f[1], m)
        if type(f[2]) is not list or name not in predicates or len(f[2]) != predicates[name]:
            raise InputError('PREDICATE_ARITY')
        found = set()
        for t in f[2]:
            found.update(_term(t, functions, m, depth + 1))
        return found
    if tag == 'all' and len(f) == 3:
        variable = _name(f[1], m)
        return _form(f[2], functions, predicates, m, depth + 1) - {variable}
    if tag == 'not' and len(f) == 2:
        return _form(f[1], functions, predicates, m, depth + 1)
    if tag in ('imp', 'and', 'or') and len(f) == 3:
        return (_form(f[1], functions, predicates, m, depth + 1)
                | _form(f[2], functions, predicates, m, depth + 1))
    raise InputError('FORMULA_SHAPE')


def _prepare(compiled, generation, depth, m):
    if type(depth) is not int or not 0 <= depth <= 32:
        raise InputError('TREE_DEPTH')
    c = _copy(compiled, m)
    _fields(c, ('schema', 'version', 'theory', 'goal', 'goal_id', 'profile', 'logical_basis',
                'zero_instances', 'mp_index', 'gen_index', 'costs', 'scope'))
    if c['schema'] != 'V-interned-Hilbert8-basis-v1' or c['version'] != 'V-INTERNED-FINITE-HILBERT8-v1':
        raise InputError('Y_COMPILED_IDENTITY')
    if any(type(c[k]) is not list for k in ('zero_instances', 'mp_index', 'gen_index')):
        raise InputError('INDEX_LISTS')
    if sum(len(c[k]) for k in ('zero_instances', 'mp_index', 'gen_index')) > m.limits['max_definitions']:
        raise _Stop('DEFINITION_LIMIT')
    theory = c['theory']; _fields(theory, ('functions', 'predicates', 'axioms'))
    for sig in (theory['functions'], theory['predicates']):
        if type(sig) is not dict:
            raise InputError('SIGNATURE')
        for key, arity in sig.items():
            _name(key, m)
            if type(arity) is not int or arity < 0:
                raise InputError('ARITY')
    if type(theory['axioms']) is not dict:
        raise InputError('AXIOMS')
    fn, pr = theory['functions'], theory['predicates']
    for key, f in theory['axioms'].items():
        _name(key, m)
        if _form(f, fn, pr, m):
            raise InputError('OPEN_THEORY_AXIOM')
    basis = c['logical_basis']
    _fields(basis, ('instantiation_terms', 'terms', 'variables', 'formulas', 'colors', 'templates', 'hole', 'stages'))
    forms, colors = basis['formulas'], basis['colors']
    if type(forms) is not list or type(colors) is not list or len(forms) != len(colors):
        raise InputError('FORMULAS_COLORS')
    if type(c['goal_id']) is not int or not 0 <= c['goal_id'] < len(forms):
        raise InputError('GOAL_ID')
    for i, f in enumerate(forms):
        _form(f, fn, pr, m)
        m.tick(2 + len(colors[i]) if type(colors[i]) is str else 1)
        if type(colors[i]) is not str or _text(f) != colors[i]:
            raise InputError('LITERAL_COLOR')
    m.tick(sum(len(s) for s in colors) * max(1, len(colors).bit_length()))
    if colors != sorted(colors) or len(set(colors)) != len(colors) or forms[c['goal_id']] != c['goal']:
        raise InputError('FORMULA_ORDER_OR_GOAL')
    by_color = {s: i for i, s in enumerate(colors)}
    mp, gen = [], []
    for i, f in enumerate(forms):
        m.tick()
        if f[0] == 'imp':
            a, out = by_color.get(_text(f[1])), by_color.get(_text(f[2]))
            if a is not None and out is not None:
                mp.append([i, a, out])
        if f[0] == 'all':
            body = by_color.get(_text(f[2]))
            if body is not None:
                gen.append([i, body, f[1]])
    if _text(mp) != _text(c['mp_index']) or _text(gen) != _text(c['gen_index']):
        raise InputError('COMPLETE_TYPED_MP_GEN')
    zeros = c['zero_instances']
    if type(zeros) is not list:
        raise InputError('ZEROS')
    count = len(zeros) + len(mp) + len(gen)
    if count > m.limits['max_definitions']:
        raise _Stop('DEFINITION_LIMIT')
    definitions = []
    allowed = {'axiom', 'instantiate', 'refl', 'tautology', 'eq_subst', 'distribute'}
    for i, z in enumerate(zeros):
        m.tick(); _fields(z, ('id', 'rule', 'formula_id', 'line'))
        fid = z['formula_id']; line = z['line']
        if (z['id'] != 'i' + str(i) or type(z['rule']) is not str or z['rule'] not in allowed
                or type(fid) is not int or not 0 <= fid < len(forms) or type(line) is not dict
                or line.get('rule') != z['rule'] or line.get('formula') != forms[fid]):
            raise InputError('ZERO_BINDING')
        identity = _text(['zero', z['id']])
        definitions.append((identity, 'ZERO', fid, (), z['id'], None, z['rule']))
    for head, a, out in mp:
        m.tick(); definitions.append((_text(['mp', head, a, out]), 'MP', out, (a, head), None, None, 'mp'))
    for head, body, variable in gen:
        m.tick(); definitions.append((_text(['gen', head, body, variable]), 'GEN', head, (body,), None, variable, 'generalize'))
    m.tick(sum(len(d[0]) for d in definitions) * max(1, count.bit_length()))
    definitions.sort(key=lambda d: d[0])
    core = {k: v for k, v in c.items() if k not in ('costs', 'scope')}
    core_hash = _hash(core, m)
    if generation is not None:
        g = _copy(generation, m)
        _fields(g, ('schema', 'version', 'profile', 'compiled_core_sha256', 'core_stages',
                    'core_assertions', 'goal_receptors', 'bridge_premises', 'scope'))
        if (g['schema'] != 'Y-goal-receptor-universe-v1' or g['version'] != 'Y-GOAL-RECEPTOR-FAMILY-v1'
                or g['compiled_core_sha256'] != core_hash or _text(g['profile']) != _text(c['profile'])
                or g['scope'] != c['scope']):
            raise InputError('GENERATION_BINDING')
    preimage = {'schema': 'Z-anchored-proof-inventory-identity-v1', 'version': VERSION,
                'compiled_core_sha256': core_hash, 'depth': depth}
    return c, tuple(definitions), core_hash, _hash(preimage, m)


def _placement(site, definition, colors, charge):
    identity, kind, out, premises, zero, variable, rule = definition
    charge(32 + 12 * (len(site) + len(identity)) + sum(len(colors[p]) for p in (out,) + premises))
    cid = _text([site, identity])
    t = [[site, 1]]; marks = [[site, colors[out]]]
    for i, fid in enumerate(premises):
        charge(8 + len(site))
        child = site + str(i)
        t.append([child, 1]); marks.append([child, colors[fid]])
    return {'id': cid, 't': t, 'm': marks}


class _Incident:
    __slots__ = ('_identity', '_depth', '_defs', '_colors', '_left', '_right', '_calls', '_rows', '_work', '_seconds')

    def __init__(self, identity, depth, definitions, colors):
        self._identity, self._depth = identity, depth
        self._defs, self._colors = definitions, tuple(colors)
        self._left = tuple(d for d in definitions if len(d[3]) >= 1)
        self._right = tuple(d for d in definitions if len(d[3]) == 2)
        self._calls = self._rows = self._work = 0
        self._seconds = 0.0

    @property
    def identity(self):
        return self._identity

    def __call__(self, point, charge):
        started = time.perf_counter(); self._calls += 1
        def reserve(units=1):
            charge(units)
            self._work += units
        try:
            reserve(1)
            if type(point) is not str or len(point) > self._depth:
                raise InputError('SITE')
            reserve(len(point) + 1)
            if any(c not in '01' for c in point):
                raise InputError('SITE')
            reserve(len(self._defs) + 1)
            result = [_placement(point, d, self._colors, reserve) for d in self._defs
                      if len(point) < self._depth or not d[3]]
            if point:
                parent = point[:-1]
                definitions = self._left if point[-1] == '0' else self._right
                reserve(len(definitions) + 1)
                result.extend(_placement(parent, d, self._colors, reserve) for d in definitions)
            reserve(sum(len(p['id']) for p in result) * max(1, len(result).bit_length()) + 1)
            result.sort(key=lambda p: p['id'])
            self._rows += len(result)
            return {'point': point, 'complete': True, 'placements': result}
        finally:
            self._seconds += time.perf_counter() - started

    def snapshot(self):
        return {'identity': self._identity, 'calls': self._calls, 'rows': self._rows,
                'charged_work': self._work, 'seconds': self._seconds, 'depth': self._depth,
                'scope': 'Cumulative provider cost telemetry, not trailed solver state. Complete packets only; foreign/owned engine-charge exceptions propagate.'}


def make_provider(compiled, generation, depth, limits):
    m = _Meter(limits)
    try:
        if type(generation) is not dict:
            raise InputError('GENERATION_REQUIRED')
        m.tick(); c, definitions, core_hash, identity = _prepare(compiled, generation, depth, m)
        m.tick(len(definitions) * 24 + len(c['logical_basis']['colors']) + 1)
        provider = _Incident(identity, depth, definitions, c['logical_basis']['colors'])
        model = {'schema': 'Z-growing-point-model-v1', 'version': VERSION, 'capacity': 2,
                 'roots': [''], 'seed': {'t': [['', 1]], 'm': [['', c['logical_basis']['colors'][c['goal_id']]]]},
                 'inventory': {'kind': 'CERTIFIED_INCIDENT', 'identity': identity}}
        keys = ('id', 'kind', 'output', 'premises', 'zero_id', 'variable', 'native_rule')
        descriptions = [dict(zip(keys, (d[0], d[1], d[2], list(d[3]), d[4], d[5], d[6]))) for d in definitions]
        value = {'depth': depth, 'compiled_core_sha256': core_hash, 'identity': identity,
                 'definitions': descriptions, 'formula_count': len(c['logical_basis']['formulas']),
                 'potential_sites': (1 << (depth + 1)) - 1, 'scope': SCOPE}
        m.tick()
        return model, provider, {'schema': 'Z-anchored-proof-provider-result-v1', 'version': VERSION,
                'status': 'COMPLETE', 'reason': None, 'value': value, 'costs': m.costs()}
    except _Stop as error:
        return None, None, {'schema': 'Z-anchored-proof-provider-result-v1', 'version': VERSION,
                'status': 'UNKNOWN', 'reason': str(error), 'value': None, 'costs': m.costs()}


def decode(compiled, depth, selected, limits):
    m = _Meter(limits)
    try:
        m.tick()
        if type(selected) is not list:
            raise InputError('SELECTED')
        if len(selected) > m.limits['max_proof_lines']:
            raise _Stop('PROOF_LINE_LIMIT')
        c, definitions, core_hash, identity = _prepare(compiled, None, depth, m)
        forms, colors = c['logical_basis']['formulas'], c['logical_basis']['colors']
        m.tick(len(definitions) + len(selected))
        table = {d[0]: d for d in definitions}; sites = {}
        for cid in selected:
            if type(cid) is not str or len(cid) > 1024:
                raise InputError('PLACEMENT_ID')
            m.tick(len(cid) + 1)
            try:
                row = json.loads(cid)
            except (ValueError, RecursionError) as error:
                raise InputError('PLACEMENT_ID') from error
            if (type(row) is not list or len(row) != 2 or type(row[0]) is not str
                    or type(row[1]) is not str or row[1] not in table or _text(row) != cid):
                raise InputError('PLACEMENT_ID')
            site = row[0]; definition = table[row[1]]
            if len(site) > depth or any(x not in '01' for x in site) or site in sites:
                raise InputError('SITE_OR_DUPLICATE')
            if len(site) == depth and definition[3]:
                raise InputError('CHILD_OUTSIDE_DEPTH')
            sites[site] = (cid, definition)
        if '' not in sites or sites[''][1][2] != c['goal_id']:
            raise InputError('ROOT_GOAL')
        proof, lines, visited = [], {}, set()
        pending = [('', False)]
        zero = {z['id']: z['line'] for z in c['zero_instances']}
        while pending:
            site, ready = pending.pop(); m.tick()
            if site not in sites:
                raise InputError('UNFILLED_PREMISE')
            cid, d = sites[site]
            children = [site + str(i) for i in range(len(d[3]))]
            if not ready:
                for i, child in enumerate(children):
                    if child not in sites or sites[child][1][2] != d[3][i]:
                        raise InputError('PREMISE_MARK_MISMATCH')
                pending.append((site, True))
                pending.extend((child, False) for child in reversed(children))
                continue
            if d[1] == 'ZERO':
                line = _copy(zero[d[4]], m)
            elif d[1] == 'MP':
                line = {'rule': 'mp', 'formula': _copy(forms[d[2]], m),
                        'antecedent': lines[children[0]], 'implication': lines[children[1]]}
            else:
                line = {'rule': 'generalize', 'formula': _copy(forms[d[2]], m),
                        'source': lines[children[0]], 'variable': d[5]}
            lines[site] = len(proof); proof.append(line); visited.add(site)
        if visited != set(sites) or len(proof) != len(selected):
            raise InputError('DISCONNECTED_OR_EXTRA_SELECTION')
        m.tick(len(sites) * max(1, len(sites).bit_length()))
        ordered = sorted(sites)
        placements = [_placement(site, sites[site][1], colors, m.tick) for site in ordered]
        m.tick(sum(len(p['id']) for p in placements) * max(1, len(placements).bit_length()))
        placements.sort(key=lambda p: p['id'])
        tree = {'root': '', 'max_depth': depth, 'selected': sorted(selected),
                'site_to_line': [[site, lines[site]] for site in ordered], 'node_count': len(proof),
                'max_used_depth': max(map(len, ordered)), 'placements': placements,
                'totals': [[site, 2] for site in ordered],
                'marks': [[site, colors[sites[site][1][2]], 2] for site in ordered]}
        return {'status': 'UNVERIFIED_CERTIFICATE', 'reason': None, 'proof': proof,
                'target': _copy(c['goal'], m), 'tree': tree, 'costs': m.costs(), 'scope': SCOPE}
    except _Stop as error:
        return {'status': 'UNKNOWN', 'reason': str(error), 'proof': None, 'target': None,
                'tree': None, 'costs': m.costs(), 'scope': SCOPE}
