import ast,symtable,pathlib,json,hashlib
D=pathlib.Path('/private/tmp/gcts-indexed-producers-20261028-v1/implementation-L');P=D/'indexed_contact_verifier_v1.py'
s=P.read_text();t=ast.parse(s);sy=symtable.symtable(s,str(P),'exec')
def ref(p):
 a=p.read_bytes();return dict(path=str(p),bytes=len(a),sha256=hashlib.sha256(a).hexdigest())
def put(n,d):
 p=D/n;assert not p.exists();p.write_text(json.dumps(d,sort_keys=True,ensure_ascii=True,indent=2)+'\n');return ref(p)
units=[]
for n in ast.walk(t):
 if isinstance(n,(ast.FunctionDef,ast.ClassDef)):
  raw=''.join(s.splitlines(keepends=True)[n.lineno-1:n.end_lineno])
  units.append(dict(name=n.name,kind=type(n).__name__,start=n.lineno,end=n.end_lineno,
                    signature=ast.unparse(n.args) if isinstance(n,ast.FunctionDef) else None,
                    raw_sha256=hashlib.sha256(raw.encode()).hexdigest(),
                    calls=sorted({ast.unparse(c.func) for c in ast.walk(n) if isinstance(c,ast.Call)})))
def scopes(q):
 return [dict(name=q.get_name(),type=q.get_type(),line=q.get_lineno(),identifiers=sorted(q.get_identifiers()))]+[r for c in q.get_children() for r in scopes(c)]
SS=scopes(sy)
static=put('IP-independent-contact-complete-static-v1.json',dict(schema='IP-independent-contact-complete-static-v1',source=ref(P),named_units=len(units),scopes=len(SS),all_units=sorted(units,key=lambda x:x['start']),all_symtable_scopes=SS,activity='ast.parse and symtable only; no codeobject/Source/helper execution. No new B/C implementation body intake before this freeze.'))
B=pathlib.Path('/private/tmp/gcts-indexed-producers-20261028-v1/implementation-B/indexed-growing-point-complete-public-ABI-v1.json');C=pathlib.Path('/private/tmp/gcts-indexed-producers-20261028-v1/implementation-C/indexed-anchored-provider-complete-effective-public-ABI-v1.json')
old=pathlib.Path('/private/tmp/gcts-growing-proof-obligations-20261028-v1/implementation-L/growing_proof_verifier_v2.py')
fixed={'engine_eager.solve':16,'engine_indexed.solve':25,'adapter_eager.make_provider':4,'adapter_indexed.make_provider':4,'adapter_eager.decode':3,'adapter_indexed.decode':3,'growth_audit.verify_factory':8,'growth_audit.verify_tree':6,'fol_checker.check':6,'adapter_indexed.describe':10}
abi=put('IP-independent-contact-complete-public-ABI-v1.json',dict(
 schema='IP-independent-contact-complete-public-ABI-v1',status='FROZEN_INERT_SOURCE_ONLY',version='IP-INDEPENDENT-CONTACT-AUDIT-v1',source=ref(P),
 entries={
 'verify_query':'verify_query(model, universe, query, reply, *, limits=None) -> receipt7',
 'verify_description':'verify_description(compiled, depth, identity, point, description, *, limits=None) -> receipt7; tiny explicit all-sites oracle maxdepth8 and item cap, not a large-main projection guarantee',
 'verify_state':'verify_state(growth_audit, model, universe, state, *, limits=None) -> receipt7',
 'verify_result':'verify_result(growth_audit, model, universe, result, observations, *, limits=None) -> receipt7; accepts unchanged Z17 or current IP18, checks original hashes then disclosed check-copy projection',
 'qualify':'qualify(modules, emit, budget) -> COMPLETE return below'},
 receipt_exact7=['schema','version','status','reason','details','costs','scope'],receipt_statuses=['VERIFIED','REJECTED','UNKNOWN'],
 receipt_policy='Only Rejected input/semantic failures become REJECTED; own bounded resource _Stop becomes UNKNOWN with details null; unexpected or injected foreign errors propagate.',
 audit_limits_exact4={'wall_seconds':15,'max_work':100000000,'max_depth':128,'max_items':200000},
 audit_limit_language='wall native finite number in(0,60]; other fields native nonnegative integers<=1b. Public guards/copies and output reservations bounded cooperatively; no hardware quota.',
 engine_limits_exact7={'wall_seconds':2,'max_work':20000000,'max_nodes':10000,'max_events':4096,'max_rollback_records':4096,'max_candidates':1000,'max_points':64},
 factory_decode_limits_exact5={'wall_seconds':5,'max_work':100000000,'max_depth':128,'max_definitions':10000,'max_proof_lines':64},
 host_FOL_limits_exact3={'max_proof_lines':64,'max_operations':100000000,'max_depth':128},
 qualifier_own_limits={'wall_seconds':60,'max_work':1000000000,'max_depth':128,'max_items':200000},
 query_semantics='Exact public query6/reply5. Full actual totals inclstored0 and all assigned marks. Oracle enumerates all static incident t supports then exact GLOBAL capacity/mark predicate, with no selected/excluded removal. Generic reply unique member order may differ; C adapter separately required full-CID lexical order. Distinct aliases retained.',
 static_description='Independent full definition/CID/site expansion from declared structural zero records plus complete formula-derived MP/GEN indexes; exact own/parent nonempty arity families and static dependency unions. Zero logical truth/Y grammar remain upstream Source/audit and host-FOL antecedents.',
 graph_projection={'original':'All original state13 fields and full original hash independently bound. Registered rows must be exact static identities; every actual registered t/m dependency checked; no hidden currently compatible loaded contact permitted.',
 'check_copy':'Add only omitted potential contacts touching loaded points that are currently globally t/m-illegal, then recompute ONLY placement/dependency fields. All values/Q/selected/excluded/eligible/domains/weighted edges/events/certificates stay unchanged. Rehash copy only for inherited auditor, never presented as original.',
 'inherited':'Old growth_audit independently reconstructs complete graph, scheduler, generation, rooted certificate and exact restore using this expanded eager view.',
 'prefix':'Complete normal query/evidence/observation streams required in tiny controls. UNKNOWN may contain an unmatched query after validation before a completed image; list unjoined indices without inventing final/post-throw state.'},
 qualifier_modules={'required':['engine_eager','adapter_eager','engine_indexed','adapter_indexed','growth_audit','fol_checker'],'other_Root_keys':'Accepted but unused; no hidden module or loader.'},
 emit_signature='emit(name, JSON) with safe unique alnum/hyphen/period name; complete originals; native_certificates always present (possiblyempty).',
 emissions={'count':26,'normal_pairs':16,'generic_pairs':12,'proof_pairs':4,'special_records':9,'data_only_negative_records':1,
 'generic_names':['half-root','shared-forced','thirds-shared','fractional-residual-dead','capacity-four-selected-filter','remote-mark','absent-versus-zero','late-dead-before-forced','forced-before-generation','generation-before-degree','bad-first-restore','parent-positive-contacts'],
 'proof_names':['proof-zero-alias-wrong-output','proof-unary','proof-binary-all-parent','proof-missing-premise'],
 'special_names':['refusal-nodes','refusal-work','refusal-candidates','refusal-sticky-charge','fault-query-foreign','fault-order-foreign','fault-audit-foreign','fault-context-binding','refusal-point-growth'],
 'data_only_name':'data-only-query-graph-negatives',
 'normal_fields':'case,model,universe,complete_subset_count,all_root_reachable_solutions,indexed,eager,extra,native_certificates; positives add indexed_proof/eager_proof. Each lane result/observations/query_captures/independent full.',
 'proof_extra':'compiled,generation,both raw factories,both independent factory audits, every site description and independent audit.',
 'fault_fields':'model,universe,limits,expected_exception,actual_exception,message,no_post_exception_state_claim, all completed pre-throw observations/query captures,native_certificates[].',
 'refusal_fields':'model,universe,limits,answer full, native_certificates[].',
 'data_negative_fields':'mutations of stale context hash, missingcontact, boolean count, false emptydomain; each forged packet/image and REJECTED receipt; no engine calls.',
 'native_certificates':'Each exact {label,problem:{theory,goal},proof}, generated only from actual searched positive decoded tree and actual independent host-FOL VERIFIED. Three proof fixtures positive in two lanes =>six records; no new native-C1 is claimed.'},
 fixed_subject_calls=fixed,
 dynamic_audit_calls={'growth_audit.verify_state':'one per actual independently audited callback observation, including completed pre-foreign snapshots, plus one data-only state forgery; reported as observations+1','growth_audit.verify_result':37,'indexed_context_queries':'actual callbacks; full bodies retained, engine receipt prefix/full hash joined; no predicted fixed number','engine_audit_callbacks':'all completed delivered images retained, including pre-foreign ones','charge_and_budget':'callback charges are part of engine query budgets; own verification callbacks counted in search wall, independently bounded; outer budget called around subject calls/emissions and private oracle ticks.'},
 return_fields=['status','version','records','emitted_names','counts','inherited_audit_counts','native_certificates','observations','captured_queries','seconds','scope'],
 return_status='COMPLETE only after exact 26/41/6 and fixed calls gate; mismatch or tiny UNKNOWN aborts qualification, no prefix PASS.',
 exhaustive_scope='Each normal finite inventory has<=14 distinct placements; preflight all2^N subsets<=16384, no truncation. Enumerate all legal rooted-growth exact subsets, compare both actual lexical witnesses/statuses to the complete set. Does not claim engines enumerate all solutions or disconnected completed packings are proofs.',
 mutations_and_resources='Capacity4 normal case also clears detached callback query after correct response construction. Five owned UNKNOWN controls and four foreign/checked exception controls use same fixed base. Actual failed child/exclusion asserted. No post-throw graph fabricated. No main logical outcomes/proofs fed into qualification.',
 dependencies={'master':ref(pathlib.Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md')),'engine_public_API':ref(B),'adapter_public_API':ref(C),'inherited_independent_growth_audit':ref(old)},
 independence='New B/C implementation bodies not read/imported/hashed by L before independent Source freeze. Only public metadata and fully read old Z Sources used. No subject/helper/model/fixture/kernel execution.'
))
manual=put('IP-independent-contact-complete-review-memo-v1.json',dict(
 schema='IP-independent-contact-complete-review-memo-v1',source=ref(P),status='SOURCE_ONLY_NOT_RUNTIME_QUALIFIED',
 proof=[
 'The static universe is unchanged. For a fixed context, each incident row is retained iff all t contributions fit and all assigned m overlaps agree. Own/parent grouping and sparse posting acceleration are implementation choices; direct all-row oracle makes no index assumption.',
 'A forward state extension never reduces totals or weakens assigned marks. An omitted capacity or literal mismatch therefore cannot become compatible. A loaded-point certificate remains sound through such extensions; its observations alone do not justify any rule weakening.',
 'Rollback restores discoveries, loaded flags and dependency buckets together with totals/marks. A certificate loaded under a descendant context cannot survive into an ancestor context. Registered candidates are globally refreshed on all t/m support changes.',
 'The actual legal graph depends only on currently compatible, unselected, nonexcluded rows. Adding a currently incompatible omitted row to a check copy changes only potential registry/dependencies, not the actual eligible graph or scheduler. Thus the inherited eager auditor can check the unchanged semantic state after this explicitly disclosed expansion. Original hashes are separately checked.',
 'Complete subset enumeration of small positive integer inventories yields all exact root-reachable active solutions. Selection is a set of distinct CIDs; aliases are not merged. Connectivity is required: arbitrary disconnected zero-alias packings are not admitted.',
 'Actual query records are independently full-set checked and joined to complete normal callback-image contexts. Resource-tail queries without an emitted snapshot remain explicit unmatched prefix observations; they are not used to synthesize missing state.',
 'Actual selected proof trees are decoded independently by both provider versions, checked by inherited tree verifier and host FOL kernel. Zero-schema logical truth and the full Y catalogue grammar are not reimplemented in this structural qualifier.'
 ],
 material_risks=[
 'A complete flag/count is not self-certifying; external Source proof and whole tiny qualification are prerequisites.',
 'Same indexed/eager mathematical graph does not require identical discovered caches, memory/work costs or candidate-cap refusal point.',
 'No inventory/rule weakening is supported under stale loaded certificates. Such changes require new scope/version and invalidation proof.',
 'Main broad graphs are Source-proved and independently checked at returned selected certificates; tiny complete observations do not establish a full main intermediate-state replay.',
 'Independent Source peer and fresh Root current intake/closed once are still required. All project functions remain unrun.'
 ],
 static=static,public_API=abi,scope='Regression engineering of the same finite depth/inventory only; no RL, theorem novelty, universal FOL or performance outcome claimed.'))
hand=put('IP-independent-contact-complete-inert-Source-handoff-v1.json',dict(schema='IP-independent-contact-complete-inert-Source-handoff-v1',status='FROZEN_INERT_COMPLETE_SOURCE_READY_FOR_PEER',source=ref(P),public_API=abi,review_memo=manual,full_static=static,prefrozen_requirements=ref(D/'IP-independent-prefrozen-requirements-v1.json'),counts=dict(named_units=len(units),scopes=len(SS),records=26,solves=41,host_FOL_checks=6),subject_calls=0,new_B_C_body_intake=0,scope='No runtime authority. Source/API/codeobjects not executed; AST/symtable only. Main caller and all future outputs require fresh Root adoption.'))
print(json.dumps(dict(source=ref(P),API=abi,memo=manual,static=static,handoff=hand,units=len(units),scopes=len(SS)),sort_keys=True))
