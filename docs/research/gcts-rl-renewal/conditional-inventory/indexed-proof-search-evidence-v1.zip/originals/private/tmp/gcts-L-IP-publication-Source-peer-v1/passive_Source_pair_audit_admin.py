import pathlib,json,hashlib,ast,symtable,re
D=pathlib.Path('/private/tmp/gcts-L-IP-publication-Source-peer-v1');IP=pathlib.Path('/private/tmp/gcts-indexed-producers-20261028-v1');B=IP/'implementation-B';Z=pathlib.Path('/private/tmp/gcts-growing-proof-obligations-20261028-v1')
def ref(p):
 a=p.read_bytes();return dict(path=str(p),bytes=len(a),sha256=hashlib.sha256(a).hexdigest())
def put(n,v):
 p=D/n;assert not p.exists();p.write_text(json.dumps(v,ensure_ascii=True,sort_keys=True,indent=2)+'\n');return ref(p)
def guard(v):assert ref(pathlib.Path(v['path']))==v
H=json.loads((B/'IP-publication-normal-TLS-complete-inert-Source-handoff-v1.json').read_bytes())
for key in ['effective_API','complete_literal_preservation']:guard(H[key])
for q in H['Sources'].values():guard(q)
for q in H['patches']:guard(q)
def apply_patch(original,patch):
 before=original.splitlines(keepends=True);lines=patch.splitlines(keepends=True);out=[];pos=0;i=2
 while i<len(lines):
  mt=re.fullmatch(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@.*\n?',lines[i]);assert mt,lines[i]
  old_start=int(mt[1])-1;old_count=1 if mt[2] is None else int(mt[2]);new_count=1 if mt[4] is None else int(mt[4]);assert old_start>=pos
  out.extend(before[pos:old_start]);pos=old_start;i+=1;oc=nc=0
  while i<len(lines) and not lines[i].startswith('@@ '):
   line=lines[i];assert line and line[0] in ' +-';body=line[1:]
   if line[0] in ' -':assert before[pos]==body;pos+=1;oc+=1
   if line[0] in ' +':out.append(body);nc+=1
   i+=1
  assert (oc,nc)==(old_count,new_count)
 out.extend(before[pos:]);return ''.join(out)
def scope_rows(q):return [dict(name=q.get_name(),kind=q.get_type(),line=q.get_lineno())]+[r for c in q.get_children() for r in scope_rows(c)]
reports=[]
for kind,oldname,newname,prefix in [('publisher','publish_growing_proof_search_git_v1.py','publish_indexed_proof_search_git_v1.py','publisher'),('TLS','verify_growing_proof_search_live_v1.py','verify_indexed_proof_search_live_v1.py','TLS')]:
 oldp=Z/'root'/oldname;newp=B/newname;old=oldp.read_text();new=newp.read_text()
 fwd=(B/(prefix+'-Z1-to-IP1-forward.patch')).read_text();inv=(B/(prefix+'-Z1-to-IP1-inverse.patch')).read_text()
 assert apply_patch(old,fwd)==new and apply_patch(new,inv)==old
 a=ast.parse(old);b=ast.parse(new);aa=list(ast.walk(a));bb=list(ast.walk(b));assert len(aa)==len(bb)
 literal=[]
 for x,y in zip(aa,bb):
  assert type(x) is type(y)
  if isinstance(x,ast.Constant) and x.value!=y.value:
   assert type(x.value) is type(y.value) and type(x.value) in (str,bytes)
   literal.append(dict(line=y.lineno,before=repr(x.value),after=repr(y.value)))
   y.value=x.value
 assert ast.dump(a,include_attributes=False)==ast.dump(b,include_attributes=False)
 def units(t,s):
  out=[]
  for n in ast.walk(t):
   if isinstance(n,(ast.ClassDef,ast.FunctionDef)):
    out.append(dict(name=n.name,line=n.lineno,end=n.end_lineno,kind=type(n).__name__,signature=ast.unparse(n.args) if isinstance(n,ast.FunctionDef) else None,calls=sorted({ast.unparse(c.func) for c in ast.walk(n) if isinstance(c,ast.Call)})))
  return sorted(out,key=lambda x:x['line'])
 u=units(ast.parse(new),new);old_u=units(ast.parse(old),old);assert u==old_u
 ss=scope_rows(symtable.symtable(new,str(newp),'exec'));os=scope_rows(symtable.symtable(old,str(oldp),'exec'));assert ss==os
 reports.append(dict(kind=kind,ancestor=ref(oldp),current=ref(newp),full_raw_forward_inverse_exact=True,entire_nonliteral_AST_equal=True,all_literal_changes=sorted(literal,key=lambda x:x['line']),all_named_units=u,all_symbol_scopes=ss))
assert sum(len(r['all_named_units']) for r in reports)==55 and sum(len(r['all_symbol_scopes']) for r in reports)==68
p=B/'publish_indexed_proof_search_git_v1.py';s=p.read_text();t=B/'verify_indexed_proof_search_live_v1.py';st=t.read_text()
# Standard pathlib semantics only, not Source execution.
assert IP/'root'/'/private/tmp/gcts-indexed-producers-20261028-v1/implementation-B/publish_indexed_proof_search_git_v1.py'==p
assert IP/'implementation-B/verify_indexed_proof_search_live_v1.py'==t
assert "EXPECTED_PARENT = '31f16a535b6cc41aa05429b0f36e77ea873d6a4d'" in s and "EXPECTED_TREE = '20c8cd969ba9e37551b1a18e6928f524aa010a5a'" in s
for name in ['indexed-proof-search-v1.html','indexed-proof-search-results-v1.json','indexed-proof-search-evidence-v1.zip']:assert name in s and name in st
support=put('IP-publication-TLS-complete-independent-Source-support-v1.json',dict(schema='IP-publication-TLS-complete-independent-Source-support-v1',status='PASS',handoff=ref(B/'IP-publication-normal-TLS-complete-inert-Source-handoff-v1.json'),API=H['effective_API'],literal_preservation=H['complete_literal_preservation'],reports=reports,all_named_units=55,all_symbol_scopes=68,source_or_helper_execution=0,patch_application='Independent stdlib text-hunk application, both complete directions; no patch/Git/Source CLI invocation.'))
review=put('IP-publication-TLS-complete-independent-Source-review-v1.json',dict(
 schema='IP-publication-TLS-complete-independent-Source-review-v1',status='PASS_SOURCE_ONLY',blockers=[],Sources=H['Sources'],API=H['effective_API'],handoff=ref(B/'IP-publication-normal-TLS-complete-inert-Source-handoff-v1.json'),support=support,
 full_coverage='Inherited complete whole-body reading of both frozen Z Git/TLS Sources and their complete saved actual evidence audits. Every current literal delta and all four patches/effective API/preservation record read; independent full raw forward/inverse and nonliteral AST/signature/call/scope equality verified for all55 named units/68 scopes.',
 changed_bindings=['New IP root, stages, bare repository, output directories, current implementation-B Source self paths, exact three indexed-proof-search siblings and new schemas/operational versions.','Fixed expected parent31f16a535b6cc41aa05429b0f36e77ea873d6a4d and tree20c8cd969ba9e37551b1a18e6928f524aa010a5a match admitted prior Z publication. Prospective oldleaf21405 is metadata; Source computes complete actual baseline leaf map.','Publisher SELF_PATH uses an absolute right Path operand, which correctly resolves to the current implementation-B Source. TLS current Source and publication terminal schemas agree with the publisher. No Source path redirects to an old phase.'],
 inherited_guards=['Closed exact plan9/three payload rows and typed current A6six; complete Source/D90/344bootstrap/fixedcwd/exclusivecaptures plus current pre/post raw guards. Once marker fsync precedes network; fresh owned output/bare only, failure writes require owned mkdir. All old authorities remain spent.','Same23-command/94-record closed Git sequence, exactly one ordinary nonforce push, fixed HTTPS credential helper and environment/config cleanup, no main checkout/index/settings changes. Complete before/after NUL leaf maps preserve every old mode/type/SHA; three new raw blob hashes/sizes and exact single-parent commit/race/posthead remain mandatory.','Same normal TLS three full-body requests/eight files with default certificate+hostname verification, exact same-origin final URL/commit query, HTTP200/EOF/allContentLengths/SHA/Gitblob/twin equality. No redirect/retry/certificate bypass/archive decoder.','All body/aggregate/count/socket/command/wall/cleanup caps and owned wait/group cleanup unchanged. Cooperative sampled limits and cleanup tails are not hard OS lifetime/memory/disk quotas.'],
 prerequisites=['Current whole scientific cohort, final reader/content/full archive must be admitted and exact three twins frozen before publication authority.','Fresh official current head/tree must match; inherit or verify no-empty-baseline-tree precondition. Any head race fails spent, no automatic adapting/retry.','Root exact concrete plan/A6/caller/current Source/runtime/bootstrap/payload pins and original exit/full captures then whole saved Git review required. Same-commit Pages success precedes separately fresh normal TLS authority/full saved bodies/live UI.'],
 scope='No payload, plan, authority, publication or TLS execution grant created by this Source peer. Existing user full-archive consent applies only to the task-approved exact deliverables at the established destination; original science/proofs not reexecuted. Final concrete caller/data review remains separate.',
 activity=dict(Git_network_publisher_TLS_Source_helpers_scientific_calls=0,evidence_mutations=0,writes='Separate review/support only; tools idle after receipt.')))
print(json.dumps(dict(review=review,support=support),sort_keys=True))
