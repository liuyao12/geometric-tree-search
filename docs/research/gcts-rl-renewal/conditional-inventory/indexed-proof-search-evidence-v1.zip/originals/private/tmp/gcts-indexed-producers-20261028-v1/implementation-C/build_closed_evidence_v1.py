"""Passive deterministic ZIP assembly. No archived Source is imported or run."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import stat
import zipfile

ZIP_NAME = 'indexed-producer-proof-search-evidence-v1.zip'
FILE_CAP, ZIP_CAP, TOTAL_CAP, PLAN_CAP = 67108864, 67108864, 1073741824, 16777216
LEGACY = {'adapter_eager': (19166, '34cb1d0d7690858ac677e9aa4fda24416edf0e9425ce0303ed7410acb42a5fff'),
          'engine_eager': (32015, '42bda4fdfe2fc949d6e2d9872a2cdada5b03dba376a084aed2f82489a3ad07bf'),
          'growth_audit': (69970, '6286d6b151d460e6ee0b97983fd9f081168a6d76256a33c3e0f9ead0ffae3aa1'),
          'inventory': (45197, '5f9c82c6ce3c8d492d598030cbe6705928a7c996781ee232d083589318dfcf0b'),
          'bank_verifier': (23303, '0882bd40237f425768fc6ee86b417c7bd273f40f39c366caae3efc82e6c9dc9f'),
          'fol_checker': (21560, '099454304f3a67c8ec49b1a3685c0dc0896662ae0bc26a18db9320d6cb3404b1')}
UPSTREAM = {'url': 'https://liuyao12.github.io/geometric-tree-search/docs/research/gcts-rl-renewal/conditional-inventory/growing-proof-search-evidence-v1.zip',
            'bytes': 6584859, 'sha256': 'da282124331caa95bc09a620917ae812862a9b4f02afca1227497c751cb5637b'}
RUNTIME = '/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12'
BOOTSTRAP = (344, 'f0fb00e11e4d22c78467a2182f4f1e980578d5ec064c3fb3031c6c8dad345b62')


def need(ok, why):
    if not ok:
        raise ValueError(why)


def raw(x):
    return (json.dumps(x, sort_keys=True, ensure_ascii=True, indent=2, allow_nan=False) + '\n').encode('ascii')


def parse(b):
    def pairs(rows):
        out = {}
        for k, v in rows:
            need(k not in out, 'duplicate JSON key')
            out[k] = v
        return out
    return json.loads(b, object_pairs_hook=pairs, parse_constant=lambda x: need(False, 'nonfinite JSON'))


def pin(p, b):
    return {'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}


def path(x):
    need(type(x) is str, 'literal path')
    p = Path(x)
    need(p.is_absolute() and str(p) == x and p.resolve() == p
         and all(not q.is_symlink() for q in (p, *p.parents)), 'canonical absolute nonsymlink path')
    return p


def read(p, cap=FILE_CAP):
    p = path(str(p)); a = p.stat(follow_symlinks=False)
    need(stat.S_ISREG(a.st_mode) and a.st_nlink == 1 and 0 <= a.st_size <= cap, 'bounded regular original')
    with p.open('rb') as f:
        b = f.read(cap + 1)
    z = p.stat(follow_symlinks=False)
    need(len(b) == a.st_size == z.st_size and len(b) <= cap
         and (a.st_dev, a.st_ino, a.st_mtime_ns) == (z.st_dev, z.st_ino, z.st_mtime_ns), 'changed original')
    return b, stat.S_IMODE(a.st_mode)


def original(ref):
    need(type(ref) is dict and set(ref) == {'path', 'bytes', 'sha256'}
         and type(ref['bytes']) is int and 0 <= ref['bytes'] <= FILE_CAP
         and type(ref['sha256']) is str and len(ref['sha256']) == 64
         and all(c in '0123456789abcdef' for c in ref['sha256']), 'typed rawref3')
    b, mode = read(path(ref['path']))
    need(pin(ref['path'], b) == ref, 'whole original bytes/SHA')
    return b, mode


def safe(n):
    need(type(n) is str and n and len(n.encode('utf-8')) <= 65535 and not n.startswith('/')
         and all(32 <= ord(c) <= 126 for c in n) and '\\' not in n and ':' not in n
         and all(x not in ('', '.', '..') for x in n.split('/')), 'safe member')
    return n


def create(p, b):
    with p.open('xb') as f:
        need(f.write(b) == len(b), 'short write'); f.flush(); os.fsync(f.fileno())
    need(read(p, max(len(b), 1))[0] == b, 'created readback')


class Capped:
    def __init__(self, f): self.f = f
    def write(self, b):
        need(self.f.tell() + len(b) <= ZIP_CAP, 'ZIP extent before write including close')
        n = self.f.write(b); need(n == len(b), 'short ZIP write'); return n
    def tell(self): return self.f.tell()
    def seek(self, n, how=0): return self.f.seek(n, how)
    def flush(self): return self.f.flush()


def build(manifest_path, output):
    manifest_path, output = path(manifest_path), path(output)
    plan_raw, plan_mode = read(manifest_path, PLAN_CAP); p = parse(plan_raw)
    need(type(p) is dict and set(p) == {'schema', 'status', 'cut_id', 'entries', 'admissions',
         'legacy_sources', 'upstream', 'exclusions', 'scope', 'pending'}, 'exact closed manifest10')
    need(p['schema'] == 'AA-closed-evidence-input-v1' and p['status'] == 'ADMITTED_CLOSED_PREPUBLICATION_CUT'
         and type(p['cut_id']) is str and p['cut_id'] and p['pending'] == [], 'admitted closed cut only')
    need(type(p['entries']) is list and len(p['entries']) <= 10000 and type(p['admissions']) is list
         and len(p['admissions']) >= 2 and type(p['scope']) is list and all(type(x) is str for x in p['scope'])
         and type(p['exclusions']) is list and type(p['upstream']) is dict
         and type(p['upstream'].get('bytes')) is int and p['upstream'] == UPSTREAM
         and type(p['legacy_sources']) is dict and set(p['legacy_sources']) == set(LEGACY), 'scope/dependencies')
    entries, names, origins, total = [], set(), set(), 0
    for e in p['entries']:
        need(type(e) is dict and set(e) == {'name', 'category', 'source_ref'}
             and type(e['category']) is str and e['category'], 'entry3')
        n = safe(e['name']); ref = e['source_ref']; b, mode = original(ref)
        need(n not in names and n not in ('MANIFEST.json', 'README.txt', 'PACKAGING-INPUT.json')
             and ref['path'] not in origins and ref['path'] != str(manifest_path), 'unique nonrecursive original')
        need(not path(ref['path']).is_relative_to(output), 'output/input cycle')
        need(ref['path'] != RUNTIME and not any(x == '.git' or x.endswith('.git')
             for x in Path(ref['path']).parts), 'runtime/bare repository excluded')
        names.add(n); origins.add(ref['path']); total += len(b)
        need(total <= TOTAL_CAP, 'original aggregate cap')
        entries.append(dict(e, mode=mode))
    by_path = {e['source_ref']['path']: e['source_ref'] for e in entries}
    for ref in p['admissions']:
        original(ref); need(by_path.get(ref['path']) == ref, 'included science/content admission')
    for role, ref in p['legacy_sources'].items():
        original(ref); need((ref['bytes'], ref['sha256']) == LEGACY[role]
                            and by_path.get(ref['path']) == ref, 'included exact legacy Source: ' + role)
    need(any((x['bytes'], x['sha256']) == BOOTSTRAP for x in by_path.values()), 'included exact bootstrap')
    entries.append(dict(name='PACKAGING-INPUT.json', category='closed_input',
                        source_ref=pin(manifest_path, plan_raw), mode=plan_mode))
    total += len(plan_raw); need(total <= TOTAL_CAP, 'complete original aggregate')
    entries.sort(key=lambda e: e['name'])
    catalogue = dict(schema='AA-complete-evidence-manifest-v1', cut_id=p['cut_id'], entries=entries,
                     originals=len(entries), original_bytes=total, admissions=p['admissions'],
                     legacy_sources=p['legacy_sources'], upstream=p['upstream'], exclusions=p['exclusions'], scope=p['scope'])
    catalogue_raw = raw(catalogue); need(len(catalogue_raw) <= PLAN_CAP, 'manifest cap')
    readme = ('Complete prepublication evidence cut. MANIFEST.json maps every member to its original path/mode/bytes/SHA.\n'
              'All explicit originals, including failed study001 and admitted qualification/main002, are retained without replay.\n'
              'All six reused scientific Sources are included; original paths are provenance, not required external Source availability.\n'
              'Reproduction requires a fresh reviewed loader/plan/authority; spent grants must never be rerun.\n'
              'The prior Z public evidence ZIP is an external exact-pinned upstream dependency, not recursively bundled.\n'
              'Platform runtimes, bare Git repositories, payload twins, this ZIP and later publication/TLS/Pages/live receipts are outside the cut.\n'
              'Generated MANIFEST/README and this ZIP cannot hash themselves; PACKAGING-INPUT preserves the exact closed input.\n\n'
              + '\n'.join(p['scope']) + '\n').encode('utf-8')
    need(not output.exists() and output.parent.is_dir(), 'fresh output directory')
    output.mkdir(mode=0o700)  # Failure here owns no directory and writes no error record.
    partial, final = output / (ZIP_NAME + '.partial'), output / ZIP_NAME
    try:
        with partial.open('xb') as f:
            with zipfile.ZipFile(Capped(f), 'w', compression=zipfile.ZIP_DEFLATED, allowZip64=False) as z:
                for e in entries + [dict(name='MANIFEST.json', body=catalogue_raw, mode=0o644), dict(name='README.txt', body=readme, mode=0o644)]:
                    b = e['body'] if 'body' in e else original(e['source_ref'])[0]
                    info = zipfile.ZipInfo(e['name'], (1980, 1, 1, 0, 0, 0)); info.create_system = 3
                    info.external_attr = (stat.S_IFREG | e['mode']) << 16
                    z.writestr(info, b, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
            f.flush(); os.fsync(f.fileno())
        checks = []
        with zipfile.ZipFile(partial) as z:
            need(len(z.infolist()) == len(entries) + 2 and z.testzip() is None
                 and len(set(z.namelist())) == len(entries) + 2, 'whole ZIP count/CRC')
            for e in entries:
                b, mode = original(e['source_ref']); restored = z.read(e['name']); info = z.getinfo(e['name'])
                need(b == restored and mode == e['mode'] and (info.external_attr >> 16) == (stat.S_IFREG | mode), 'every member raw/mode readback')
                checks.append(dict(name=e['name'], source_ref=e['source_ref'], bytes=len(restored), sha256=hashlib.sha256(restored).hexdigest(), CRC32=info.CRC))
            need(z.read('MANIFEST.json') == catalogue_raw and z.read('README.txt') == readme, 'generated full readback')
        for e in entries:
            need(original(e['source_ref'])[1] == e['mode'], 'all original postguards')
        os.link(partial, final); partial.unlink()
        fd = os.open(output, os.O_RDONLY | os.O_DIRECTORY)
        try: os.fsync(fd)
        finally: os.close(fd)
        create(output / 'MANIFEST.json', catalogue_raw)
        b, _ = read(final, ZIP_CAP)
        receipt = dict(schema='AA-complete-package-readback-v1', status='COMPLETE', archive=pin(final, b),
                       manifest=pin(output / 'MANIFEST.json', catalogue_raw), members=len(entries) + 2,
                       originals=len(entries), original_bytes=total, all_original_readbacks=checks, all_CRCs=True, upstream=UPSTREAM)
        create(output / 'package-readback.json', raw(receipt)); return receipt
    except Exception as e:
        create(output / 'package-failure.json', raw(dict(status='INCOMPLETE_UNADMITTED', type=type(e).__name__, reason=str(e))))
        raise


if __name__ == '__main__':
    a = argparse.ArgumentParser(); a.add_argument('--manifest', required=True); a.add_argument('--output', required=True)
    x = a.parse_args(); print(json.dumps(build(x.manifest, x.output)['archive'], sort_keys=True))
