"""Inert fresh-once Git-transport publisher; exact three approved new leaves.

All earlier publication grants stay spent. This separate Source uses only a new
isolated bare repository and normal HTTPS Git transport. No science imports,
primary checkout/index writes, old blob reads, force push or automatic retry.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import selectors
import signal
import stat
import subprocess
import sys
import time
import traceback

VERSION = 'IP-INDEXED-PROOF-SEARCH-GIT-PUBLISHER-v1'
STUDY = Path('/private/tmp/gcts-indexed-producers-20261028-v1')
ROOT = STUDY / 'root'
SELF_PATH = ROOT / '/private/tmp/gcts-indexed-producers-20261028-v1/implementation-B/publish_indexed_proof_search_git_v1.py'
REPO = ROOT / 'isolated-indexed-proof-search-git-v1.git'
ROOT_STAGE = ROOT / 'publication-indexed-proof-search-v1'
PUBLISHER_STAGE = STUDY / 'publisher-indexed-proof-search-payload'
OUT = ROOT / 'publication-indexed-proof-search-git-v1'
REPOSITORY = 'liuyao12/geometric-tree-search'
REMOTE = 'https://github.com/' + REPOSITORY + '.git'
GIT = '/usr/bin/git'
GIT_PREFIX = 'docs/research/gcts-rl-renewal/conditional-inventory/'
NAMES = ('indexed-proof-search-v1.html',
         'indexed-proof-search-results-v1.json',
         'indexed-proof-search-evidence-v1.zip')
PAYLOAD_CAPS = (1048576, 8388608, 67108864)
EXPECTED_PARENT = '31f16a535b6cc41aa05429b0f36e77ea873d6a4d'
EXPECTED_TREE = '20c8cd969ba9e37551b1a18e6928f524aa010a5a'
PYTHON = {'path': '/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12',
          'bytes': 18058560, 'sha256': 'd90bce0f5ac3aa40e2ee5900ad243bad0b2205ce17408278f088b34aed737840'}
ADMIN_CAP = 1048576
REQUEST_CAP = 100663296
RESPONSE_CAP = 16777216
STDERR_CAP = 1048576
OUTPUT_CAP = 268435456
OUTPUT_COUNT = 128
REPOSITORY_CAP = 268435456
COMMAND_SECONDS = 240
PUBLISHER_SECONDS = 1200
CLEANUP_SECONDS = 5
EXPECTED_COMMANDS = 23
AUTHORIZATION_SCOPE = 'PUBLIC_FULL_TASK_EVIDENCE_AT_EXISTING_GITHUB_PAGES_DESTINATION'


class PublicationFailure(Exception):
    pass


def need(condition, message):
    if not condition:
        raise PublicationFailure(message)


def encode(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')


def parse(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            need(key not in result, 'duplicate JSON key')
            result[key] = value
        return result
    def nonfinite(value):
        raise PublicationFailure('nonfinite JSON constant')
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=nonfinite)


def fields(value, names, label):
    need(type(value) is dict and all(type(k) is str for k in value)
         and set(value) == set(names), label)


def sha256(raw):
    return hashlib.sha256(raw).hexdigest()


def git_sha(value):
    need(type(value) is str and re.fullmatch('[0-9a-f]{40}', value) is not None,
         'exact Git SHA1')
    return value


def blob_sha(raw):
    return hashlib.sha1(b'blob ' + str(len(raw)).encode('ascii') + b'\0' + raw).hexdigest()


def canonical(value):
    need(type(value) is str, 'path string')
    p = Path(value)
    need(p.is_absolute() and str(p) == value and os.path.normpath(value) == value
         and all(not q.is_symlink() for q in (p, *p.parents)) and p.resolve() == p,
         'absolute canonical nonsymlink path')
    return p


def pin(path, raw):
    return {'path': str(path), 'bytes': len(raw), 'sha256': sha256(raw)}


def read(path, cap):
    path = canonical(str(path))
    before = path.stat(follow_symlinks=False)
    need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1
         and 0 <= before.st_size <= cap, 'bounded single-link regular file')
    with path.open('rb') as handle:
        raw = handle.read(cap + 1)
    after = path.stat(follow_symlinks=False)
    need(len(raw) <= cap and len(raw) == before.st_size == after.st_size
         and (before.st_dev, before.st_ino, before.st_mtime_ns)
         == (after.st_dev, after.st_ino, after.st_mtime_ns), 'changed or incomplete file')
    return raw


def rawref(value, cap):
    fields(value, ('path', 'bytes', 'sha256'), 'rawref exact3')
    need(type(value['bytes']) is int and 0 <= value['bytes'] <= cap
         and type(value['sha256']) is str
         and re.fullmatch('[0-9a-f]{64}', value['sha256']) is not None, 'rawref types/cap')
    raw = read(canonical(value['path']), cap)
    need(encode(pin(value['path'], raw)) == encode(value), 'complete rawref identity')
    return raw


def sync_dir(path):
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def fresh(path):
    canonical(str(path))
    need(not path.exists() and not path.is_symlink(), 'fresh path required')


def create(path, raw, cap):
    need(type(raw) is bytes and len(raw) <= cap, 'bounded output body')
    canonical(str(path))
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'wb') as handle:
        handle.write(raw)
        handle.flush()
        os.fsync(handle.fileno())
    need(read(path, cap) == raw, 'exclusive full output readback')
    return pin(path, raw)


def admin(path):
    path = canonical(path)
    need(path.parent == ROOT and path.suffix == '.json' and not path.name.startswith('.'),
         'Root administrative JSON path')
    raw = read(path, ADMIN_CAP)
    return parse(raw), pin(path, raw)


def plan_read(path):
    plan, ref = admin(path)
    fields(plan, ('schema', 'repository', 'branch', 'expected_parent', 'expected_tree',
                  'root_stage', 'publisher_stage', 'files', 'human_authorization'), 'plan exact9')
    need(plan['schema'] == 'IP-indexed-proof-search-Git-plan-v1'
         and plan['repository'] == REPOSITORY and plan['branch'] == 'main'
         and plan['expected_parent'] == EXPECTED_PARENT
         and plan['expected_tree'] == EXPECTED_TREE, 'fixed repository/main/parent/tree')
    need(plan['root_stage'] == str(ROOT_STAGE)
         and plan['publisher_stage'] == str(PUBLISHER_STAGE), 'fixed twin staging directories')
    rows = plan['files']
    need(type(rows) is list and len(rows) == 3, 'three ordered payloads')
    for row, name, cap in zip(rows, NAMES, PAYLOAD_CAPS, strict=True):
        fields(row, ('path', 'root_source', 'publisher_source', 'git_blob_sha1'), 'payload row exact4')
        need(row['path'] == GIT_PREFIX + name, 'exact approved target order')
        for key, directory in (('root_source', ROOT_STAGE), ('publisher_source', PUBLISHER_STAGE)):
            r = row[key]
            fields(r, ('path', 'bytes', 'sha256'), 'payload rawref exact3')
            need(r['path'] == str(directory / name) and type(r['bytes']) is int
                 and 0 < r['bytes'] <= cap and type(r['sha256']) is str
                 and re.fullmatch('[0-9a-f]{64}', r['sha256']) is not None, 'fixed payload path/type/cap')
        need(row['root_source']['bytes'] == row['publisher_source']['bytes']
             and row['root_source']['sha256'] == row['publisher_source']['sha256'], 'declared twin identities')
        git_sha(row['git_blob_sha1'])
    human = plan['human_authorization']
    fields(human, ('quote', 'date', 'scope'), 'human authorization exact3')
    need(type(human['quote']) is str and 1 <= len(human['quote']) <= 16384
         and type(human['date']) is str and re.fullmatch('[0-9]{4}-[0-9]{2}-[0-9]{2}', human['date']) is not None
         and human['scope'] == AUTHORIZATION_SCOPE, 'literal existing full-archive authorization')
    return plan, ref


def local_guards(plan, plan_ref, authority_ref, publisher_ref):
    rawref(plan_ref, ADMIN_CAP)
    rawref(authority_ref, ADMIN_CAP)
    rawref(publisher_ref, ADMIN_CAP)
    rawref(PYTHON, PYTHON['bytes'])
    bodies = []
    for directory in (ROOT_STAGE, PUBLISHER_STAGE):
        canonical(str(directory))
        need(directory.is_dir(), 'staging directory')
        need({p.name for p in directory.iterdir()} == set(NAMES), 'exact three-body staging census')
    for row, cap in zip(plan['files'], PAYLOAD_CAPS, strict=True):
        root_raw = rawref(row['root_source'], cap)
        p2_raw = rawref(row['publisher_source'], cap)
        need(root_raw == p2_raw and blob_sha(root_raw) == row['git_blob_sha1'],
             'full twin and Git blob identities')
        bodies.append(root_raw)
    return bodies


def group_exists(pgid):
    try:
        os.killpg(pgid, 0)
        return True
    except ProcessLookupError:
        return False


class Session:
    def __init__(self, started):
        self.started = started
        self.calls = 0
        self.push_dispatched = False
        self.files = []

    def wall(self):
        need(time.monotonic() - self.started <= PUBLISHER_SECONDS,
             'publisher main-entry cooperative wall ceiling')

    def save(self, name, raw, cap):
        need(re.fullmatch('[a-z0-9][a-z0-9_.-]*', name) is not None, 'receipt basename')
        paths = list(OUT.iterdir())
        need(len(paths) + 1 <= OUTPUT_COUNT, 'receipt count cap')
        need(sum(p.stat().st_size for p in paths) + len(raw) <= OUTPUT_CAP, 'receipt aggregate cap')
        result = create(OUT / name, raw, cap)
        self.files.append(result)
        return result

    def census(self):
        need({p.name for p in OUT.iterdir()} == {Path(r['path']).name for r in self.files}, 'exact named receipt census')
        need(len(self.files) <= OUTPUT_COUNT and sum(r['bytes'] for r in self.files) <= OUTPUT_CAP, 'whole receipt caps')
        for r in self.files:
            rawref(r, REQUEST_CAP)
        return list(self.files)

    def command(self, label, argv, body=None):
        self.wall()
        need(re.fullmatch('[a-z0-9][a-z0-9_-]*', label) is not None, 'command label')
        need(type(argv) is list and argv[:len(git_args())] == git_args()
             and self.calls < EXPECTED_COMMANDS, 'closed fixed Git argv/count')
        need(body is None or type(body) is bytes, 'raw command stdin')
        request = b'' if body is None else body
        need(len(request) <= REQUEST_CAP, 'command stdin cap')
        request_ref = self.save(label + '-request.bin', request, REQUEST_CAP)
        totals = {'stdout': 0, 'stderr': 0}
        buffers = {'stdout': bytearray(), 'stderr': bytearray()}
        eof = {'stdout': False, 'stderr': False}
        caps = {'stdout': RESPONSE_CAP, 'stderr': STDERR_CAP}
        sent, events, fault = 0, [], None
        cleanup_errors = []
        process, selector = None, None
        command_started = time.monotonic()
        last_repo_sample = 0.0
        self.calls += 1
        if label == '22-push':
            need(not self.push_dispatched, 'sole push dispatch')
            self.push_dispatched = True
        try:
            selector = selectors.DefaultSelector()
            process = subprocess.Popen(argv, cwd=ROOT, env=git_environment(), stdin=subprocess.PIPE if body is not None else subprocess.DEVNULL,
                                       stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
            for kind, stream in (('stdout', process.stdout), ('stderr', process.stderr)):
                os.set_blocking(stream.fileno(), False)
                selector.register(stream, selectors.EVENT_READ, kind)
            if body is not None:
                os.set_blocking(process.stdin.fileno(), False)
                selector.register(process.stdin, selectors.EVENT_WRITE, 'stdin')
            while True:
                need(time.monotonic() - command_started <= COMMAND_SECONDS, 'Git command wall ceiling')
                if time.monotonic() - last_repo_sample >= 0.5:
                    repository_extent()
                    last_repo_sample = time.monotonic()
                self.wall()
                for key, _ in selector.select(timeout=0.05):
                    kind = key.data
                    if kind == 'stdin':
                        try:
                            count = os.write(key.fileobj.fileno(), request[sent:sent + 65536])
                        except BlockingIOError:
                            continue
                        sent += count
                        if sent == len(request):
                            selector.unregister(key.fileobj)
                            key.fileobj.close()
                    else:
                        try:
                            chunk = os.read(key.fileobj.fileno(), 65536)
                        except BlockingIOError:
                            continue
                        if not chunk:
                            eof[kind] = True
                            selector.unregister(key.fileobj)
                            key.fileobj.close()
                        else:
                            totals[kind] += len(chunk)
                            room = max(0, caps[kind] - len(buffers[kind]))
                            buffers[kind].extend(chunk[:room])
                            need(totals[kind] <= caps[kind], 'Git command response/stderr byte cap')
                code = process.poll()
                if code is not None and not selector.get_map():
                    need(not group_exists(process.pid), 'Git descendant process group remains')
                    break
        except Exception as error:
            fault = {'exception_type': type(error).__name__, 'message': str(error)}
        finally:
            try:
                if process is not None:
                    try:
                        if process.poll() is None or group_exists(process.pid):
                            for sig in (signal.SIGTERM, signal.SIGKILL):
                                try:
                                    os.killpg(process.pid, sig)
                                    events.append({'signal': int(sig), 'delivered': True})
                                except ProcessLookupError:
                                    events.append({'signal': int(sig), 'delivered': False})
                                except Exception as error:
                                    cleanup_errors.append({'site': 'group signal', 'type': type(error).__name__, 'message': str(error)})
                            try:
                                process.kill()
                            except ProcessLookupError:
                                pass
                            except Exception as error:
                                cleanup_errors.append({'site': 'owned child kill', 'type': type(error).__name__, 'message': str(error)})
                    except Exception as error:
                        cleanup_errors.append({'site': 'cleanup observation', 'type': type(error).__name__, 'message': str(error)})
                    finally:
                        try:
                            process.wait(timeout=CLEANUP_SECONDS)
                        except Exception as error:
                            cleanup_errors.append({'site': 'owned wait', 'type': type(error).__name__, 'message': str(error)})
            finally:
                if process is not None:
                    for stream in (process.stdin, process.stdout, process.stderr):
                        if stream is not None and not stream.closed:
                            try:
                                stream.close()
                            except Exception as error:
                                cleanup_errors.append({'site': 'pipe close', 'type': type(error).__name__, 'message': str(error)})
                if selector is not None:
                    try:
                        selector.close()
                    except Exception as error:
                        cleanup_errors.append({'site': 'selector close', 'type': type(error).__name__, 'message': str(error)})
        if cleanup_errors and fault is None:
            fault = {'exception_type': 'CleanupFailure', 'message': 'owned Git cleanup failed; no retry'}
        stdout, stderr = bytes(buffers['stdout']), bytes(buffers['stderr'])
        stdout_ref = self.save(label + '-stdout.bin', stdout, RESPONSE_CAP)
        stderr_ref = self.save(label + '-stderr.bin', stderr, STDERR_CAP)
        rc = None if process is None else process.returncode
        transport = {'schema': 'IP-indexed-proof-search-Git-transport-v1',
                     'argv': argv, 'cwd': str(ROOT), 'request': request_ref,
                     'request_bytes_sent': sent if body is not None else 0,
                     'stdout': stdout_ref, 'stderr': stderr_ref, 'observed_stream_totals': totals,
                     'EOF': eof, 'returncode': rc, 'fault': fault, 'cleanup_signals': events, 'cleanup_errors': cleanup_errors,
                     'elapsed_command_entry_seconds': time.monotonic() - command_started,
                     'process_group_gone': process is None or not group_exists(process.pid),
                     'scope': 'Full bodies only if normal cap/EOF/return gates pass; failure prefixes are unadmitted. No automatic retry.'}
        self.save(label + '-transport.json', encode(transport), ADMIN_CAP)
        need(fault is None and rc == 0 and all(eof.values())
             and (body is None or sent == len(request)) and transport['process_group_gone'],
             'Git command failed or uncertain; stop spent attempt without retry')
        repository_extent()
        return stdout


def git_args(*args):
    return [GIT, '-c', 'credential.helper=', '-c',
            'credential.helper=!/Users/liuyao/bin/gh auth git-credential',
            '-c', 'credential.interactive=never', '-c', 'http.sslVerify=true',
            '-c', 'http.followRedirects=false', '-c', 'core.hooksPath=/dev/null',
            '-c', 'commit.gpgsign=false', '-c', 'maintenance.auto=false', '-c', 'gc.auto=0',
            '-c', 'remote.origin.url=' + REMOTE,
            '-c', 'remote.origin.promisor=true',
            '-c', 'remote.origin.partialclonefilter=blob:none', '-C', str(REPO), *args]


def git_environment():
    env = dict(os.environ)
    for key in list(env):
        if (key.startswith('GIT_') or key in ('GH_DEBUG', 'GH_FORCE_TTY', 'GCM_TRACE')):
            del env[key]
    env.update(GIT_CONFIG_NOSYSTEM='1', GIT_CONFIG_GLOBAL='/dev/null',
               GIT_TERMINAL_PROMPT='0', GIT_ASKPASS='/usr/bin/false',
               GCM_INTERACTIVE='never', GH_PROMPT_DISABLED='1', GIT_NO_LAZY_FETCH='1',
               GIT_INDEX_FILE=str(REPO / 'owned.index'),
               GIT_AUTHOR_NAME='GCTS Research Publisher',
               GIT_AUTHOR_EMAIL='gcts-research@users.noreply.github.com',
               GIT_COMMITTER_NAME='GCTS Research Publisher',
               GIT_COMMITTER_EMAIL='gcts-research@users.noreply.github.com')
    return env


def repository_extent():
    total = 0
    for directory, subdirs, names in os.walk(REPO, followlinks=False):
        for name in subdirs:
            need(not (Path(directory) / name).is_symlink(), 'owned repository directory symlink')
        for name in names:
            path = Path(directory) / name
            status = path.stat(follow_symlinks=False)
            need(stat.S_ISREG(status.st_mode), 'owned repository regular file')
            total += status.st_size
            need(total <= REPOSITORY_CAP, 'sampled isolated repository byte ceiling')
    return total


def remote_head(session, label):
    output = session.command(label, git_args('ls-remote', '--refs', REMOTE, 'refs/heads/main'))
    rows = output.decode('ascii').splitlines()
    need(len(rows) == 1, 'one remote main ref')
    parts = rows[0].split('\t')
    need(len(parts) == 2 and parts[1] == 'refs/heads/main', 'literal remote main')
    return git_sha(parts[0])


def object_id(raw):
    value = raw.decode('ascii').strip()
    git_sha(value)
    need(raw == (value + '\n').encode('ascii'), 'one complete object ID')
    return value


def leaf_map(raw):
    need(raw.endswith(b'\0'), 'complete NUL tree listing')
    result = {}
    for entry in raw[:-1].split(b'\0'):
        header, path_bytes = entry.split(b'\t', 1)
        mode, kind, sha = header.decode('ascii').split(' ')
        path = path_bytes.decode('utf-8')
        need(path and not path.startswith('/') and path not in result
             and all(p not in ('', '.', '..') for p in path.split('/')), 'safe unique leaf path')
        need((kind == 'blob' and mode in ('100644', '100755', '120000'))
             or (kind == 'commit' and mode == '160000'), 'exact leaf mode/type')
        result[path] = {'mode': mode, 'type': kind, 'sha': git_sha(sha)}
    return result


def publish(plan_arg, authority_arg, started, ownership):
    need(Path(__file__) == SELF_PATH and Path.cwd() == ROOT, 'current Source and Root cwd')
    need(sys.executable == PYTHON['path'] and sys.platform == 'darwin'
         and sys.version_info[:3] == (3, 12, 14) and sys.flags.isolated == 1
         and sys.flags.no_site == 1 and sys.flags.optimize == 0 and sys.dont_write_bytecode,
         'D90 -I -S -B required')
    plan, plan_ref = plan_read(plan_arg)
    authority, authority_ref = admin(authority_arg)
    fields(authority, ('schema', 'authorized', 'uses', 'plan', 'publisher', 'python'), 'authority exact6')
    publisher_ref = authority['publisher']
    need(publisher_ref['path'] == str(SELF_PATH), 'current Git publisher Source')
    rawref(publisher_ref, ADMIN_CAP)
    expected = {'schema': 'IP-indexed-proof-search-Git-once-authority-v1',
                'authorized': True, 'uses': 1, 'plan': plan_ref, 'publisher': publisher_ref, 'python': PYTHON}
    need(encode(authority) == encode(expected), 'whole typed authority/plan/runtime binding')
    rawref(PYTHON, PYTHON['bytes'])
    marker = Path(authority_ref['path'] + '.CONSUMED.json')
    for path in (marker, OUT, REPO):
        fresh(path)
    consumed_ref = create(marker, encode({'schema': 'IP-indexed-proof-search-Git-consumed-v1',
        'uses': 1, 'authority': authority_ref, 'plan': plan_ref, 'publisher': publisher_ref,
        'meaning': 'permanently spent before any repository construction or network command; no automatic retry'}), ADMIN_CAP)
    sync_dir(ROOT)
    OUT.mkdir(mode=0o700)
    ownership['out'] = True
    REPO.mkdir(mode=0o700)
    sync_dir(ROOT)
    session = Session(started)
    bodies = local_guards(plan, plan_ref, authority_ref, publisher_ref)
    session.save('preflight.json', encode({'plan': plan_ref, 'authority': authority_ref,
        'publisher': publisher_ref, 'python': PYTHON, 'consumed': consumed_ref,
        'targets': plan['files'], 'parent': EXPECTED_PARENT, 'tree': EXPECTED_TREE,
        'isolated_repository': str(REPO), 'remote': REMOTE,
        'scope': 'Fresh task-owned bare repository. No primary checkout, index, P2 repository or old publisher authority used.'}), ADMIN_CAP)
    need(remote_head(session, '01-head-before') == EXPECTED_PARENT, 'remote main moved; stop spent')
    session.command('02-init', git_args('init', '--bare', '--object-format=sha1', '.'))
    session.command('03-fetch', git_args('fetch', '--depth=1', '--filter=blob:none', '--no-tags',
        '--no-write-fetch-head', 'origin', EXPECTED_PARENT + ':refs/heads/adopted-base'))
    parent = object_id(session.command('04-parent', git_args('rev-parse', '--verify', 'refs/heads/adopted-base^{commit}')))
    tree = object_id(session.command('05-base-tree', git_args('rev-parse', '--verify', EXPECTED_PARENT + '^{tree}')))
    need(parent == EXPECTED_PARENT and tree == EXPECTED_TREE, 'exact fetched parent/tree')
    before = leaf_map(session.command('06-tree-before', git_args('ls-tree', '-r', '-z', '--full-tree', tree)))
    targets = {row['path'] for row in plan['files']}
    need(all(path not in before for path in targets), 'exact three new targets absent')
    for i, (row, body) in enumerate(zip(plan['files'], bodies, strict=True)):
        sha = object_id(session.command('07-blob-' + str(i), git_args('hash-object', '-w', '--stdin'), body))
        need(sha == row['git_blob_sha1'], 'new local blob hash')
        size = session.command('08-size-' + str(i), git_args('cat-file', '-s', sha))
        need(size == (str(len(body)) + '\n').encode('ascii'), 'new-only blob size')
    session.command('09-read-tree', git_args('read-tree', tree))
    for i, row in enumerate(plan['files']):
        session.command('10-index-' + str(i), git_args('update-index', '--add', '--cacheinfo',
            '100644', row['git_blob_sha1'], row['path']))
    new_tree = object_id(session.command('11-write-tree', git_args('write-tree', '--missing-ok')))
    after = leaf_map(session.command('12-tree-after', git_args('ls-tree', '-r', '-z', '--full-tree', new_tree)))
    need({k: v for k, v in before.items() if k not in targets}
         == {k: v for k, v in after.items() if k not in targets}, 'every nontarget leaf mode/type/SHA preserved')
    need(len(after) == len(before) + 3, 'exact three new leaves')
    for row in plan['files']:
        need(after.get(row['path']) == {'mode': '100644', 'type': 'blob', 'sha': row['git_blob_sha1']},
             'exact target leaf')
    new_commit = object_id(session.command('13-commit', git_args('commit-tree', new_tree, '-p', EXPECTED_PARENT),
        b'Publish indexed proof search results and full evidence\n'))
    commit_body = session.command('14-commit-body', git_args('cat-file', '-p', new_commit))
    header = commit_body.split(b'\n\n', 1)[0].decode('utf-8').splitlines()
    need([x[5:] for x in header if x.startswith('tree ')] == [new_tree]
         and [x[7:] for x in header if x.startswith('parent ')] == [EXPECTED_PARENT], 'exact single parent/newtree')
    need(remote_head(session, '21-head-race') == EXPECTED_PARENT, 'pre-push head race; stop without push')
    session.command('22-push', git_args('push', '--porcelain', '--no-verify', REMOTE, new_commit + ':refs/heads/main'))
    need(remote_head(session, '23-head-after') == new_commit, 'post-push head mismatch; reconcile read-only separately')
    need(session.calls == EXPECTED_COMMANDS and session.push_dispatched, 'exact23commands/onepush')
    need(local_guards(plan, plan_ref, authority_ref, publisher_ref) == bodies, 'full local postguards')
    rawref(consumed_ref, ADMIN_CAP)
    session.wall()
    terminal = {'schema': 'IP-indexed-proof-search-Git-terminal-v1',
        'status': 'EXACT_THREE_NEW_PATHS_COMMITTED_LIVE_CHECK_PENDING', 'version': VERSION,
        'plan': plan_ref, 'authority': authority_ref, 'consumed': consumed_ref,
        'publisher': publisher_ref, 'python': PYTHON, 'commit': new_commit, 'parent': EXPECTED_PARENT,
        'before_tree': tree, 'after_tree': new_tree, 'files': plan['files'],
        'all_nontarget_leaves_preserved': True, 'nontarget_leaf_count': len(before),
        'git_commands': session.calls, 'push_dispatches': 1, 'isolated_repository': str(REPO),
        'sampled_final_repository_bytes': repository_extent(), 'all_prior_receipts': session.census(),
        'main_entry_elapsed_seconds_before_terminal': time.monotonic() - started,
        'scope': 'One new nonforce Git publication attempt, not a reuse of any earlier authority. Full leaf maps have mode/type/SHA but no old blob sizes or reads. New3blob hashes+sizes checked. Normal Git HTTPS credential helper, no credential values retained. No hard whole-lifetime or disk quota; original exit/full captures and distinct normalTLS+Pages verification remain mandatory.'}
    terminal_ref = session.save('terminal.json', encode(terminal), ADMIN_CAP)
    session.census()
    session.wall()
    return {'schema': 'IP-indexed-proof-search-Git-outer-v1', 'status': terminal['status'],
            'commit': new_commit, 'terminal': terminal_ref, 'requires_authoritative_exit_zero': True}


def main():
    started = time.monotonic()
    parser = argparse.ArgumentParser()
    parser.add_argument('--plan', required=True)
    parser.add_argument('--authority', required=True)
    args = parser.parse_args()
    ownership = {'out': False}
    try:
        result = publish(args.plan, args.authority, started, ownership)
        sys.stdout.buffer.write(encode(result))
        sys.stdout.buffer.flush()
        return 0
    except Exception as error:
        failure = {'schema': 'IP-indexed-proof-search-Git-failure-v1',
            'status': 'UNADMITTED_NO_AUTOMATIC_RETRY', 'exception_type': type(error).__name__, 'message': str(error),
            'scope': 'Any existing grant marker remains permanently spent; remote push may be uncertain. Preserve all outputs/repository, no automatic retry; reconcile with separate read-only evidence.'}
        try:
            if ownership['out'] and OUT.is_dir() and not OUT.is_symlink():
                paths = list(OUT.iterdir())
                raw = encode(failure)
                need(len(paths) + 1 <= OUTPUT_COUNT and sum(p.stat().st_size for p in paths) + len(raw) <= OUTPUT_CAP,
                     'failure receipt reserve')
                create(OUT / 'failure.json', raw, ADMIN_CAP)
        except Exception:
            pass
        traceback.print_exc(file=sys.stderr)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
