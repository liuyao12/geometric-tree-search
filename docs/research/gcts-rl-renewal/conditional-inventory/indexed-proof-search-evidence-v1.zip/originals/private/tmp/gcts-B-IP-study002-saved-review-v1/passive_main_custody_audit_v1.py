"""Bounded saved JSON/gzip/rawhash joins; never imports scientific Sources."""
from pathlib import Path
import json,gzip,hashlib,stat
from collections import Counter
R=Path('/private/tmp/gcts-indexed-producers-20261028-v1');OUT=Path('/private/tmp/gcts-B-IP-study002-saved-review-v1')
def sha(b):return hashlib.sha256(b).hexdigest()
def wire(x):return (json.dumps(x,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')
def parse(b):
 def pairs(xs):
  d={}
  for k,v in xs:assert k not in d;d[k]=v
  return d
 def bad(x):raise ValueError('nonfinite')
 return json.loads(b,object_pairs_hook=pairs,parse_constant=bad)
def ref(p):
 p=Path(p);a=p.stat(follow_symlinks=False);assert p.resolve()==p and not p.is_symlink() and stat.S_ISREG(a.st_mode) and a.st_nlink==1
 b=p.read_bytes();c=p.stat(follow_symlinks=False);assert (a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns)==(c.st_dev,c.st_ino,c.st_size,c.st_mtime_ns) and len(b)==a.st_size
 return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
checked={}
def rr(x):
 assert type(x)is dict and set(x)=={'path','bytes','sha256'} and type(x['bytes'])is int
 r=ref(x['path']);assert r==x;checked[x['path']]=r;return Path(x['path']).read_bytes()
def refs(x):
 if type(x)is dict:
  if set(x)=={'path','bytes','sha256'}:yield x
  else:
   for v in x.values():yield from refs(v)
 elif type(x)is list:
  for v in x:yield from refs(v)
def descriptor(d):
 b=rr(d['stored']);raw=gzip.decompress(b) if d['encoding']=='gzip-json' else b
 assert d['encoding']in('json','gzip-json') and len(raw)==d['raw_bytes'] and sha(raw)==d['raw_sha256'];x=parse(raw);assert wire(x)==raw
 return x

def custody(n,complete):
 d=R/'actual'/('study-'+n);root=R/'root';physical=[ref(p) for p in sorted(d.iterdir())];o=parse((d/'observer-result.json').read_bytes());pfile=root/('study-once-plan-'+n+'.json');plan=parse(pfile.read_bytes());pr=ref(pfile)
 files={r['path']:r for r in o['files']};assert set(files)=={v['path'] for v in physical if not v['path'].endswith('/observer-result.json')}
 for x in files.values():rr(x)
 assert sum(x['bytes']for x in files.values())==o['stored_bytes'];assert o['both_streams_EOF']and o['wait_confirmed']and o['group_gone'] and o['failure']is None and o['cleanup_errors']==[]
 for label in ['stdout','stderr']:assert len(rr(o['streams'][label]))==o['observed_stream_bytes'][label] and o['retained_streams_complete'][label]is True
 assert o['status']==('COMPLETE' if complete else 'UNADMITTED') and o['returncode']==(0 if complete else 1)
 for x in refs(plan):rr(x)
 a_path=root/('study-once-authority-'+n+'.json');a=parse(a_path.read_bytes());a_ref=ref(a_path);spent_path=Path(str(a_path)+'.CONSUMED.json');spent=parse(spent_path.read_bytes());consumed=parse((d/'CONSUMED.json').read_bytes())
 assert a['authorized']is True and type(a['uses'])is int and a['uses']==1 and a['plan']==pr and a['runner']==plan['sources']['runner'] and a['python']==plan['python']
 assert spent=={'authority':a_ref,'plan':pr,'status':'SPENT'} and consumed=={'authority':a_ref,'consumed':ref(spent_path)}
 sr=plan['sources']['runner'];cmd=[plan['python']['path'],'-I','-S','-B',plan['bootstrap']['path'],sr['path'],str(sr['bytes']),sr['sha256'],'--mode','worker','--plan',str(pfile)]
 assert o['command']==cmd and o['stdin_bytes_sent']==sr['bytes'] and plan['actual_dir']==str(d)
 caller_path=root/('study-'+n+'.caller.sh');caller=caller_path.read_text();assert 'set -eu\n'in caller and 'set -C\n'in caller and 'umask 077\n'in caller and '$('not in caller and '`'not in caller
 expected='exec '+' '.join(cmd[:-4]+['--mode','observer','--plan',str(pfile),'--authority',str(a_path)])+' < '+sr['path']+' > '+str(root/('study-'+n+'.outer-stdout.bin'))+' 2> '+str(root/('study-'+n+'.outer-stderr.bin'));assert expected in caller
 original_path=root/('study-'+n+'.original-tool-exit-v1.json');original=parse(original_path.read_bytes());assert original['native_exit']==(0 if complete else 1)
 for x in refs(original):rr(x)
 outer=parse((root/('study-'+n+'.outer-stdout.bin')).read_bytes());assert outer=={'receipt':ref(d/'observer-result.json'),'status':o['status']} and (root/('study-'+n+'.outer-stderr.bin')).read_bytes()==b''
 assert o['whole_observer_seconds']<plan['limits']['observer_seconds'] and o['wait4_peak_bytes']<plan['limits']['rss_bytes'] and len(physical)<plan['limits']['max_files'] and sum(v['bytes']for v in physical)<plan['limits']['total_bytes']
 for v in physical:assert v['bytes']<=plan['limits']['file_bytes']
 if complete:
  t=parse((d/'stdout.bin').read_bytes());assert t==o['worker_terminal'] and t['status']=='COMPLETE' and t['plan']==pr
  worker=descriptor(t['result']);assert worker['outer_public_calls']==t['public_calls'] and worker['status']=='COMPLETE'
 else:
  assert o['worker_terminal']is None and (d/'stdout.bin').read_bytes()==b'' and len(physical)==5
  assert 'RuntimeError: artifact name' in (d/'stderr.bin').read_text();worker=None
 return {'physical':physical,'observer':ref(d/'observer-result.json'),'original_exit':ref(original_path),'original':original,'plan':pr,'authority':a_ref,'Root_spent':ref(spent_path),'actual_consumed':ref(d/'CONSUMED.json'),'caller':ref(caller_path),'status':o['status'],'process':{k:o[k]for k in ['returncode','wait_confirmed','group_gone','both_streams_EOF','observed_stream_bytes','whole_observer_seconds','wait4_peak_bytes','cleanup_errors']}},plan,worker,o

def main():
 cur,plan,w,o=custody('002',True);fail,p1,_,fo=custody('001',False);assert len(cur['physical'])==88
 assert cur['original']['initial_chunk']=='03bfac'and cur['original']['terminal_chunk']=='429b17'and cur['original']['session_id']==8570
 assert plan['limits']==p1['limits'] and plan['metadata']['frozen_inputs']==p1['metadata']['frozen_inputs']
 assert {k:v for k,v in plan['sources'].items()if k not in('runner','experiment')}=={k:v for k,v in p1['sources'].items()if k not in('runner','experiment')}
 frozen=parse(rr(plan['metadata']['frozen_inputs']));assert len(frozen['inputs'])==31
 builds={};preps={};input_rows=[]
 for desc in frozen['inputs']:
  x=descriptor(desc);rr(desc['original_stored']);assert desc['original_stored']['bytes']==desc['stored']['bytes'] and desc['original_stored']['sha256']==desc['stored']['sha256']
  input_rows.append(desc)
  if desc['name'].endswith('-whole-build'):builds[desc['name'][:-12]]=x
  elif desc['name'].endswith('-whole-preparation'):preps[desc['name'][:-18]]=x
 assert len(builds)==len(preps)==15
 raw_by_path={};artifacts=[];point_rows=[];host_records=[];state_hashes=0;full_event_streams=full_rollback_streams=full_query_streams=0;events_retained=events_total=rollback_retained=rollback_total=queries_retained=queries_total=0
 for desc in w['artifacts']:
  obj=descriptor(desc);artifacts.append(desc)
  for x in refs(obj):rr(x)
  path=desc['stored']['path']
  if isinstance(obj,dict)and isinstance(obj.get('result'),dict)and obj['result'].get('schema')=='Z-growing-point-search-result-v1':
   res=obj['result'];assert res['model_sha256']==sha(wire(obj['model'])) and obj['status']==res['status'] and obj['reason']==res['reason'];assert obj['factory']['status']=='COMPLETE'and obj['factory_audit']['status']=='VERIFIED'
   for label,key in [('entry','entry_state'),('final','final_state'),('restored','restored_state')]:
    if res[key]is not None:assert res['state_hashes'][label]==sha(wire(res[key]));state_hashes+=1
   if res['entry_state']is not None:assert res['entry_state']==res['restored_state']and res['state_hashes']['entry']==res['state_hashes']['restored']
   if res['status']=='UNKNOWN':assert res['selected']==[]and res['certificate']is None and res['final_state']is None
   for rk,ek,cap in [('events','event_extent',8),('rollback_records','rollback_extent',32)]:
    rows=res[rk];ex=res[ek];assert ex['retained']==len(rows)<=cap and ex['total']>=len(rows)
    if ex['total']==len(rows):
     assert ex['sha256']==sha(b''.join(wire(v)for v in rows))
     if rk=='events':full_event_streams+=1
     else:full_rollback_streams+=1
   assert res['event_extent']['total']==res['stats']['events_total']and res['rollback_extent']['total']==res['stats']['rollbacks_total']
   events_retained+=len(res['events']);events_total+=res['event_extent']['total'];rollback_retained+=len(res['rollback_records']);rollback_total+=res['rollback_extent']['total']
   if 'provider_evidence'in res:
    q=res['provider_evidence'];assert q['retained']==len(q['records'])<=8 and q['total']>=q['retained'];queries_retained+=q['retained'];queries_total+=q['total']
    for rec in q['records']:assert rec['reply']['context_sha256']==sha(wire(rec['query']))
    if q['total']==q['retained']:assert q['sha256']==sha(b''.join(wire(v)for v in q['records']));full_query_streams+=1
   point_rows.append({'artifact':desc['name'],'status':res['status'],'reason':res['reason'],'state_hashes':res['state_hashes'],'event_extent':res['event_extent'],'rollback_extent':res['rollback_extent'],'provider_query_extent':{k:v for k,v in res.get('provider_evidence',{}).items()if k not in('records','costs')},'model_sha256':res['model_sha256'],'elapsed_seconds':res['stats']['elapsed_seconds'],'limits':res['limits']})
   # Retain the small summary associations, not another huge cached-state copy.
   obj=dict(obj,result={'status':res['status'],'reason':res['reason'],'stats':res['stats'],'selected':res['selected']})
  if isinstance(obj,dict)and desc['name'].endswith('-positive'):
   assert obj['verified']is True and obj['decoded']['status']=='UNVERIFIED_CERTIFICATE' and obj['tree_audit']['status']=='VERIFIED'and obj['lowering_audit']['status']=='VERIFIED'and obj['lowering']['status']=='COMPLETE'
   assert obj['decoded']['proof']==obj['coarse_proof']and obj['lowering']['value']['proof']==obj['original_proof']
   for label,pk in [('coarse_host_check','coarse_proof'),('original_host_check','original_proof')]:
    h=obj[label];assert h['status']=='VERIFIED' and h['checked_lines']==len(obj[pk])and sum(h['rule_counts'].values())==len(obj[pk]);host_records.append({'artifact':desc['name'],'kind':label,'lines':len(obj[pk]),'proof_sha256':sha(wire(obj[pk])),'receipt':h})
  raw_by_path[path]=obj
 assert len(artifacts)==83 and len(point_rows)==30 and len(host_records)==44
 e=w['experiment'];assert e['status']=='COMPLETE'and len(e['results'])==15;assert e['design']['depth']==8 and e['design']['search_seconds']==2
 checks=raw_by_path[str(R/'actual/study-002/fresh-bank-host-checks.json')];assert checks==e['fresh_bank_checks']and len(checks)==4 and all(x['status']=='VERIFIED'for x in checks)
 failed_bank=parse((R/'actual/study-001/fresh-bank-host-checks.json').read_bytes());assert len(failed_bank)==4 and all(x['status']=='VERIFIED'for x in failed_bank)
 summaries=[];outcomes={lane:Counter()for lane in e['design']['lanes']};positives=0
 for case in e['results']:
  cid=case['id'];assert cid in builds and cid in preps and case['compiled_sha256']==sha(wire(builds[cid]['compiled'])) and case['original']==preps[cid]['original']
  comp=raw_by_path[case['ref']['stored']['path']];assert comp=={k:v for k,v in case.items()if k!='ref'}
  assert set(case['lanes'])==set(e['design']['lanes'])
  for lane,item in case['lanes'].items():
   obj=raw_by_path[item['ref']['stored']['path']];assert obj['status']==item['status']and obj['reason']==item['reason']and obj['verified']==item['verified']and obj['search_seconds']==item['search_seconds'];outcomes[lane][item['status']]+=1
   if lane!='MATCHED_DEPTH_TREE_CONTROL':assert obj['result']['stats']==item['stats']
   if item['verified']:
    positives+=1;p=raw_by_path[item['positive_ref']['stored']['path']];assert obj['positive']==dict(p,ref=item['positive_ref'])
    assert item['coarse_lines']==len(p['coarse_proof'])and item['original_lines']==len(p['original_proof'])and p['decoded']['target']==builds[cid]['compiled']['goal']
    assert {'theory':p['lowering']['value']['theory'],'goal':p['lowering']['value']['goal']}==case['original']
   summaries.append({'id':cid,'lane':lane,'status':item['status'],'verified':item['verified'],'reason':item['reason'],'search_seconds':item['search_seconds'],'ref':item['ref']})
 assert [x['id']for x in e['results']]==e['design']['case_order'] and positives==22 and len(summaries)==45
 calls=o['worker_terminal']['public_calls'];assert calls==w['outer_public_calls']and calls['fol_checker.check']==48 and calls['engine_eager.solve']==calls['engine_indexed.solve']==calls['growth_audit.tree_control']==15 and calls['inventory.lower_proof']==22
 assert dict(outcomes['EAGER_POINT_LEX'])=={'SAT':5,'UNKNOWN':10}and dict(outcomes['INDEXED_POINT_LEX'])=={'SAT':8,'UNKNOWN':7}and dict(outcomes['MATCHED_DEPTH_TREE_CONTROL'])=={'DERIVABLE':9,'NOT_DERIVABLE':5,'UNKNOWN':1}
 support={'schema':'IP-study002-complete-passive-custody-support-v1','current':cur,'failed001':fail,'all_direct_current_checked_rawrefs':list(checked.values()),'frozen31_inputs':input_rows,'artifact83_descriptors':artifacts,'all45_positions':summaries,'point30_binding_extents':point_rows,'fresh44_positive_host_receipts':host_records,'fresh4_bank_host_receipts':checks,'failed0014_saved_bank_host_receipts':failed_bank,'counters':{'current_physical':88,'current_stored_bytes':sum(x['bytes']for x in cur['physical']),'failed001_physical':5,'failed001_stored_bytes':sum(x['bytes']for x in fail['physical']),'emitted_artifacts':83,'emitted_stored_bytes':sum(x['stored']['bytes']for x in artifacts),'emitted_raw_bytes':sum(x['raw_bytes']for x in artifacts),'worker_raw_bytes':o['worker_terminal']['result']['raw_bytes'],'all_artifact_raw_including_worker':sum(x['raw_bytes']for x in artifacts)+o['worker_terminal']['result']['raw_bytes'],'Sources':len(plan['sources']),'metadata':len(plan['metadata']),'frozen_inputs':31,'all_positions':45,'point_answers':30,'verified_positives':22,'fresh_host_checks002':48,'positive_host_checks':44,'bank_host_checks':4,'positive_checked_lines':sum(x['lines']for x in host_records),'bank_checked_lines':sum(x['checked_lines']for x in checks),'state_hashes':state_hashes,'event_retained':events_retained,'event_total':events_total,'rollback_retained':rollback_retained,'rollback_total':rollback_total,'queries_retained':queries_retained,'queries_total':queries_total,'full_event_hashes_recomputed':full_event_streams,'full_rollback_hashes_recomputed':full_rollback_streams,'full_query_hashes_recomputed':full_query_streams,'max_point_elapsed_seconds':max(x['elapsed_seconds']for x in point_rows),'new_C1_VM_calls':0},'outcomes':{k:dict(v)for k,v in outcomes.items()},'calls':calls,'scope':'Bounded current direct custody/bytes/hash/certificate-delivery joins only. Historical inputs exactly reused and disclosed. No historical recursive corpus or scientific Source/helper/model/VM/kernel replay. Prefixes not silently completed; failed001 stays UNADMITTED.'}
 p=OUT/'IP-study002-complete-passive-custody-support-v1.json';assert not p.exists();p.write_text(json.dumps(support,sort_keys=True,indent=2)+'\n');print(json.dumps({'support':ref(p),'counters':support['counters'],'outcomes':support['outcomes'],'status':'PASS_COMPLETE_SAVED_CUSTODY'},sort_keys=True))

if __name__=='__main__':main()
