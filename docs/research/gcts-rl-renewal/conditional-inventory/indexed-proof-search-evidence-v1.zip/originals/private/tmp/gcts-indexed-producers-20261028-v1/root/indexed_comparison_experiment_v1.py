"""Reused-catalogue regression comparison; inert until invoked by owned runner.

Search receives the current compiled inventory and assertion, never an old target
proof. Each lane is retained, including refusals. No training or RL is performed.
"""
import gzip
import hashlib
import io
import json
import time


def _need(ok, why):
    if not ok:
        raise RuntimeError(why)


def _raw(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')


def _sha(value):
    return hashlib.sha256(_raw(value)).hexdigest()


def _compact(item):
    answer = {k: item[k] for k in ('status', 'reason', 'search_seconds', 'verified', 'ref')}
    result = item.get('result')
    if result is not None and 'stats' in result:
        answer['stats'] = result['stats']
    if item.get('positive', {}).get('verified'):
        answer['coarse_lines'] = len(item['positive']['coarse_proof'])
        answer['original_lines'] = len(item['positive']['original_proof'])
        answer['positive_ref'] = item['positive']['ref']
    return answer


def run(modules, context, emit, budget, call):
    started = time.perf_counter()
    design = json.loads(context['metadata']['design'])
    if design['kind'] == 'qualification':
        return call('qualifier', 'qualify', modules, emit, budget)
    _need(design['kind'] == 'main' and design['depth'] == 8
          and design['search_seconds'] == 2, 'frozen comparison design')
    prerequisite = json.loads(context['metadata']['qualification_admission'])
    _need(prerequisite['status'] == 'ADMITTED'
          and all(prerequisite['sources'][role] == context['plan']['sources'][role]
                  for role in ('engine_indexed', 'adapter_indexed', 'qualifier')),
          'separate admitted qualification of these exact Sources')
    lim = design['limits']
    case_order = design['case_order']
    _need(len(case_order) == 15 and len(set(case_order)) == 15, 'all15 retained')

    def unpack(name):
        budget()
        row = context['input_refs'][name]
        stored = context['input_bytes'][name]
        _need(type(row['raw_bytes']) is int and 0 <= row['raw_bytes'] <= 67108864,
              'typed raw input extent before decompression')
        if row['encoding'] == 'gzip-json':
            with gzip.GzipFile(fileobj=io.BytesIO(stored), mode='rb') as stream:
                raw = stream.read(row['raw_bytes'] + 1)
        else:
            _need(row['encoding'] == 'json', 'declared lossless encoding')
            raw = stored
        _need(len(raw) == row['raw_bytes'] and len(raw) <= 67108864
              and hashlib.sha256(raw).hexdigest() == row['raw_sha256'],
              'complete reused input raw association')
        value = json.loads(raw)
        budget()
        return value

    bank_record = unpack('current-bank-and-native-checks')
    _need(bank_record['result']['status'] == 'COMPLETE'
          and bank_record['audit']['status'] == 'VERIFIED', 'admitted acquired bank')
    bank = bank_record['result']['value']
    bank_sha = _sha(bank)
    bank_checks = []
    t = time.perf_counter()
    for lemma in bank['lemmas']:
        theory = dict(lemma['signature'], axioms=lemma['required_axioms'])
        answer = call('fol_checker', 'check', theory, lemma['proof'], lemma['goal'], lim['checker'])
        _need(answer['status'] == 'VERIFIED', 'fresh bank proof check')
        bank_checks.append(answer)
    fresh_bank_check_seconds = time.perf_counter() - t
    emit('fresh-bank-host-checks', bank_checks)

    def positive(label, prep, compiled, selected, engine_result=None, control_result=None):
        t = time.perf_counter()
        decoded = call('adapter_eager', 'decode', compiled, design['depth'], selected, lim['decode'])
        out = {'verified': False, 'decoded': decoded}
        if decoded['status'] == 'UNKNOWN':
            out['reason'] = 'UNKNOWN_DECODE'
            return out
        _need(decoded['status'] == 'UNVERIFIED_CERTIFICATE', 'decoder return')
        audit = call('growth_audit', 'verify_tree', compiled, design['depth'], selected,
                     decoded, limits=lim['growth_audit'])
        out['tree_audit'] = audit
        _need(audit['status'] in ('VERIFIED', 'UNKNOWN'), 'independent tree audit')
        if audit['status'] != 'VERIFIED':
            out['reason'] = 'UNKNOWN_TREE_AUDIT'
            return out
        _need(_raw(audit['proof']) == _raw(decoded['proof'])
              and decoded['target'] == prep['original']['goal'], 'actual target/postorder')
        if engine_result is not None:
            tree = decoded['tree']
            cert = {'capacity': 2, 'roots': [''], 'seed': {
                't': [['', 1]], 'm': [['', compiled['logical_basis']['colors'][compiled['goal_id']]]]},
                'placements': tree['placements'], 'totals': tree['totals'], 'marks': tree['marks']}
            _need(_raw(engine_result['certificate']) == _raw(cert), 'actual point certificate')
        if control_result is not None:
            _need(_raw(control_result['proof']) == _raw(decoded['proof']), 'actual control proof')
        coarse = call('fol_checker', 'check', prep['problem']['theory'], decoded['proof'],
                      prep['original']['goal'], lim['checker'])
        out['coarse_host_check'] = coarse
        _need(coarse['status'] != 'REJECTED', 'coarse proof rejected')
        if coarse['status'] != 'VERIFIED':
            out['reason'] = 'UNKNOWN_COARSE_CHECK'
            return out
        lowering = call('inventory', 'lower_proof', prep['original']['theory'], bank,
                        prep['application'], decoded['proof'], lim['lower'])
        out['lowering'] = lowering
        if lowering['status'] != 'COMPLETE':
            _need(lowering['status'] == 'UNKNOWN', 'lowering result')
            out['reason'] = 'UNKNOWN_LOWERING'
            return out
        lower_audit = call('bank_verifier', 'verify_lowering', prep['original']['theory'], bank,
                           prep['application'], decoded['proof'], lowering['value'],
                           limits=lim['bank_verifier'])
        out['lowering_audit'] = lower_audit
        _need(lower_audit['status'] in ('VERIFIED', 'UNKNOWN'), 'independent lowering audit')
        if lower_audit['status'] != 'VERIFIED':
            out['reason'] = 'UNKNOWN_LOWERING_AUDIT'
            return out
        original = lowering['value']
        _need(original['theory'] == prep['original']['theory']
              and original['goal'] == prep['original']['goal'], 'exact original theory/goal')
        check = call('fol_checker', 'check', original['theory'], original['proof'],
                     original['goal'], lim['checker'])
        out['original_host_check'] = check
        _need(check['status'] != 'REJECTED', 'original proof rejected')
        out.update(verified=check['status'] == 'VERIFIED',
                   reason=None if check['status'] == 'VERIFIED' else 'UNKNOWN_ORIGINAL_CHECK',
                   coarse_proof=decoded['proof'], original_proof=original['proof'],
                   verification_seconds=time.perf_counter() - t)
        out['ref'] = emit(label + '-positive', out)
        return out

    rows = []
    for cid in case_order:
        t = time.perf_counter()
        built, prep = unpack(cid + '-whole-build'), unpack(cid + '-whole-preparation')
        _need(built['status'] == prep['status'] == 'COMPLETE'
              and prep['catalogue_audit']['status'] == 'VERIFIED'
              and prep['zero_audit']['status'] == 'VERIFIED', 'complete historical catalogue gates')
        compiled, generation = built['compiled'], built['generation']
        compiled_sha = _sha(compiled)
        _need(compiled_sha == prep['checkpoint']['raw_sha256']
              and generation == prep['generation'], 'exact same compiled inventory')
        load_seconds = time.perf_counter() - t
        row = {'id': cid, 'original': prep['original'], 'compiled_sha256': compiled_sha,
               'depth': design['depth'], 'reused_input_load_seconds': load_seconds, 'lanes': {}}
        for lane, adapter, engine in (
                ('EAGER_POINT_LEX', 'adapter_eager', 'engine_eager'),
                ('INDEXED_POINT_LEX', 'adapter_indexed', 'engine_indexed')):
            t = time.perf_counter()
            model, provider, factory = call(adapter, 'make_provider', compiled, generation,
                design['depth'], dict(lim['factory'], wall_seconds=design['search_seconds']))
            factory_seconds = time.perf_counter() - t
            item = {'status': 'UNKNOWN', 'reason': 'FACTORY_WINDOW', 'factory': factory,
                    'model': model, 'factory_seconds': factory_seconds, 'verified': False, 'result': None}
            _need(factory['status'] in ('COMPLETE', 'UNKNOWN'), 'factory return')
            if factory['status'] == 'COMPLETE':
                remaining = design['search_seconds'] - (time.perf_counter() - t)
                if remaining > 0:
                    answer = call(engine, 'solve', model, dict(lim['point'], wall_seconds=remaining),
                                  enumerate_incident=provider)
                    item.update(result=answer, status=answer['status'], reason=answer['reason'])
                item['provider'] = provider.snapshot()
            item['search_seconds'] = time.perf_counter() - t
            if factory['status'] == 'COMPLETE':
                t = time.perf_counter()
                audit = call('growth_audit', 'verify_factory', compiled, generation,
                    design['depth'], model, factory, limits=lim['growth_audit'])
                item.update(factory_audit=audit, factory_audit_seconds=time.perf_counter() - t)
                _need(audit['status'] in ('VERIFIED', 'UNKNOWN'), 'independent unchanged inventory audit')
                if item['result'] is not None:
                    answer = item['result']
                    _need(answer['status'] in ('SAT', 'UNSAT', 'UNKNOWN'), 'point result status')
                    if answer['entry_state'] is not None:
                        _need(answer['entry_state'] == answer['restored_state']
                              and answer['state_hashes']['entry'] == answer['state_hashes']['restored'],
                              'complete exact entry restoration')
                    if answer['status'] == 'SAT' and audit['status'] == 'VERIFIED':
                        item['positive'] = positive(cid + '-' + lane, prep, compiled,
                                                    answer['selected'], engine_result=answer)
                        item['verified'] = item['positive']['verified']
            _need(_sha(compiled) == compiled_sha, 'point preserved shared input')
            item['ref'] = emit(cid + '-' + lane, item)
            row['lanes'][lane] = _compact(item)
        t = time.perf_counter()
        control = call('growth_audit', 'tree_control', compiled, design['depth'], lim['control'])
        item = {'status': control['status'], 'reason': control['reason'], 'result': control,
                'search_seconds': time.perf_counter() - t, 'verified': False}
        _need(control['status'] in ('DERIVABLE', 'NOT_DERIVABLE', 'UNKNOWN'), 'control result')
        if control['status'] == 'DERIVABLE':
            item['positive'] = positive(cid + '-CONTROL', prep, compiled,
                control['details']['selected'], control_result=control)
            item['verified'] = item['positive']['verified']
        item['ref'] = emit(cid + '-MATCHED_DEPTH_TREE_CONTROL', item)
        row['lanes']['MATCHED_DEPTH_TREE_CONTROL'] = _compact(item)
        _need(_sha(compiled) == compiled_sha and _sha(bank) == bank_sha, 'whole input postguards')
        row['ref'] = emit(cid + '-comparison', row)
        rows.append(row)
        budget()
    return {'schema': 'AA-indexed-producer-comparison-result-v1', 'status': 'COMPLETE',
            'design': design, 'fresh_bank_checks': bank_checks,
            'fresh_bank_check_seconds': fresh_bank_check_seconds, 'results': rows,
            'seconds': time.perf_counter() - started,
            'scope': 'All15 same saved audited Z catalogues,45 positions, same depth8 and2s cold factory+search per lane. '
                     'Reused preparation disclosed, independent factory/tree/lowering and fresh coarse/original host checks. '
                     'No fresh C1 execution, RL, unseen target, universal palette, fullPA or fullHilbert claim.'}
