"""Independent finite anchored proof-tree checker and matched-depth control.

Inert library: stdlib only, no IO, project imports or top-level calls. Catalogue
generation and zero-schema logical truth are separate declared obligations.
"""
import hashlib
import itertools
import json
import math
import time

VERSION = 'Z-INDEPENDENT-GROWING-PROOF-VERIFIER-v2'
VERIFY_LIMITS = dict(wall_seconds=15, max_work=100000000, max_depth=128, max_items=200000)
CONTROL_LIMITS = dict(wall_seconds=2, max_work=100000000, max_depth=128,
                      max_items=200000, max_states=200000, max_proof_lines=64)
ZERO_FIELDS = {
    'axiom': {'rule', 'formula', 'name'},
    'tautology': {'rule', 'formula'}, 'refl': {'rule', 'formula'},
    'instantiate': {'rule', 'formula', 'universal', 'term'},
    'distribute': {'rule', 'formula', 'variable', 'antecedent', 'consequent'},
    'eq_subst': {'rule', 'formula', 'variable', 'template', 'left', 'right'},
}
SCOPE = ('Exact finite anchored binary proof-tree adaptation, integer capacity 2 '
         'and root seed 1. Complete structural MP/GEN/zero identities are checked; '
         'the declared catalogue and non-axiom zero logical truth additionally need '
         'current independent catalogue/schema assurance. All positive native '
         'proofs need unchanged C1 and independent B, and original-theory lowering '
         'when lemmas are imported. No infinite tiling, fixed translation palette, '
         'unrestricted FOL negative or equality of tree/DAG/primitive bounds.')


class InputError(ValueError):
    pass


class BudgetExceeded(Exception):
    pass


def _need(ok, message):
    if not ok:
        raise InputError(message)


def _fields(value, keys):
    _need(type(value) is dict and len(value) == len(keys), 'record cardinality')
    _need(all(type(k) is str for k in value) and set(value) == set(keys), 'record keys')


class _Meter:
    def __init__(self, limits, defaults):
        self.start = time.perf_counter()
        limits = dict(defaults) if limits is None else limits
        _fields(limits, defaults)
        wall = limits['wall_seconds']
        _need(type(wall) in (int, float) and 0 < wall <= 60
              and math.isfinite(wall), 'wall limit')
        _need(all(type(v) is int and 0 <= v <= 1000000000000
                  for k, v in limits.items() if k != 'wall_seconds'), 'integer limits')
        self.limits = dict(limits)
        self.work = 0
        self.hook = None

    def tick(self, n=1):
        if n > self.limits['max_work'] - self.work:
            raise BudgetExceeded('WORK')
        if self.hook is not None:
            self.hook(n)
        self.work += n
        if time.perf_counter() - self.start > self.limits['wall_seconds']:
            raise BudgetExceeded('WALL')

    def size(self, n):
        self.tick(n)
        if n > self.limits['max_items']:
            raise BudgetExceeded('ITEMS')

    def costs(self):
        return {'work': self.work, 'seconds': time.perf_counter() - self.start,
                'scope': 'Own validation/copy/index/search/proof/return preparation; caller serialization excluded. Cooperative, no OS quota.'}


def _copy(value, m, depth=0):
    m.tick()
    if depth > m.limits['max_depth']:
        raise BudgetExceeded('DEPTH')
    if value is None or type(value) is bool:
        m.tick(5)
        return value
    if type(value) is int:
        _need(value.bit_length() <= 256, 'integer width')
        m.tick(80)
        return value
    if type(value) is str:
        m.tick(2 + 12 * len(value))
        return value
    if type(value) is list:
        m.size(len(value))
        return [_copy(x, m, depth + 1) for x in value]
    if type(value) is dict:
        m.size(len(value))
        _need(all(type(k) is str for k in value), 'native string keys')
        return {_copy(k, m, depth + 1): _copy(v, m, depth + 1)
                for k, v in value.items()}
    raise InputError('native JSON value')


def _key(value, m):
    detached = _copy(value, m)
    m.tick(1)
    return json.dumps(detached, ensure_ascii=True, sort_keys=True, separators=(',', ':'))


def _name(value):
    return type(value) is str and 1 <= len(value) <= 64 and all(32 <= ord(c) <= 126 for c in value)


def _term(value, theory, m, depth=0):
    m.tick()
    if depth > m.limits['max_depth']:
        raise BudgetExceeded('DEPTH')
    _need(type(value) is list and len(value) in (2, 3), 'term array')
    if value[0] == 'var':
        _need(len(value) == 2 and _name(value[1]), 'variable term')
        return {value[1]}
    _need(len(value) == 3 and value[0] == 'fun' and _name(value[1])
          and value[1] in theory['functions'] and type(value[2]) is list
          and len(value[2]) == theory['functions'][value[1]], 'function term')
    out = set()
    for item in value[2]:
        out.update(_term(item, theory, m, depth + 1))
    return out


def _formula(value, theory, m, depth=0):
    m.tick()
    if depth > m.limits['max_depth']:
        raise BudgetExceeded('DEPTH')
    _need(type(value) is list and len(value) in (1, 2, 3), 'formula array')
    tag = value[0]
    _need(type(tag) is str, 'formula tag')
    if tag == 'bot':
        _need(len(value) == 1, 'bottom')
        return set()
    if tag == 'eq':
        _need(len(value) == 3, 'equality')
        return _term(value[1], theory, m, depth + 1) | _term(value[2], theory, m, depth + 1)
    if tag == 'pred':
        _need(len(value) == 3 and _name(value[1]) and value[1] in theory['predicates']
              and type(value[2]) is list and len(value[2]) == theory['predicates'][value[1]], 'predicate')
        out = set()
        for item in value[2]:
            out.update(_term(item, theory, m, depth + 1))
        return out
    if tag == 'all':
        _need(len(value) == 3 and _name(value[1]), 'universal')
        return _formula(value[2], theory, m, depth + 1) - {value[1]}
    if tag == 'not':
        _need(len(value) == 2, 'negation')
        return _formula(value[1], theory, m, depth + 1)
    _need(tag in ('and', 'or', 'imp') and len(value) == 3, 'connective')
    return _formula(value[1], theory, m, depth + 1) | _formula(value[2], theory, m, depth + 1)


def _catalogue(compiled, m):
    _fields(compiled, {'schema', 'version', 'theory', 'goal', 'goal_id', 'profile',
                      'logical_basis', 'zero_instances', 'mp_index', 'gen_index', 'costs', 'scope'})
    _need(compiled['schema'] == 'V-interned-Hilbert8-basis-v1'
          and compiled['version'] == 'V-INTERNED-FINITE-HILBERT8-v1', 'compiled carrier')
    theory = _copy(compiled['theory'], m)
    _fields(theory, {'functions', 'predicates', 'axioms'})
    for key in ('functions', 'predicates'):
        _need(type(theory[key]) is dict, 'signature')
        for name, arity in theory[key].items():
            m.tick()
            _need(_name(name) and type(arity) is int and 0 <= arity <= 64, 'signature item')
    _need(type(theory['axioms']) is dict, 'axiom map')
    for name, formula in theory['axioms'].items():
        _need(_name(name) and not _formula(formula, theory, m), 'closed named axiom')
    basis = compiled['logical_basis']
    _fields(basis, {'instantiation_terms', 'terms', 'variables', 'formulas', 'colors', 'templates', 'hole', 'stages'})
    _need(type(basis['formulas']) is list and type(basis['colors']) is list, 'formula/color lists')
    m.size(len(basis['formulas']))
    forms = _copy(basis['formulas'], m)
    colors = []
    for formula in forms:
        _formula(formula, theory, m)
        colors.append(_key(formula, m))
    m.tick(len(colors) * max(1, len(colors).bit_length()))
    _need(colors == sorted(set(colors)) and basis['colors'] == colors, 'canonical injective colors')
    index = {value: i for i, value in enumerate(colors)}
    goal = _copy(compiled['goal'], m)
    _formula(goal, theory, m)
    goal_key = _key(goal, m)
    _need(type(compiled['goal_id']) is int and goal_key in index
          and compiled['goal_id'] == index[goal_key], 'goal ID')
    _need(type(compiled['zero_instances']) is list, 'zero list')
    m.size(len(compiled['zero_instances']))
    zero = _copy(compiled['zero_instances'], m)
    definitions = {}
    previous = None
    for i, row in enumerate(zero):
        _fields(row, {'id', 'rule', 'formula_id', 'line'})
        _need(row['id'] == 'i' + str(i) and type(row['id']) is str
              and type(row['rule']) is str and row['rule'] in ZERO_FIELDS, 'zero identity')
        _fields(row['line'], ZERO_FIELDS[row['rule']])
        _need(row['line']['rule'] == row['rule'] and type(row['formula_id']) is int
              and 0 <= row['formula_id'] < len(forms), 'zero fields')
        _need(_key(row['line']['formula'], m) == colors[row['formula_id']], 'zero output')
        image = _key(row['line'], m)
        _need(previous is None or previous < image, 'full-payload zero order')
        previous = image
        if row['rule'] == 'axiom':
            name = row['line']['name']
            _need(type(name) is str and name in theory['axioms']
                  and _key(theory['axioms'][name], m) == colors[row['formula_id']], 'given axiom')
        definitions[_key(['zero', row['id']], m)] = (row['formula_id'], [], row['line'], 'ZERO')
    mp = []
    gen = []
    for i, formula in enumerate(forms):
        m.tick()
        if formula[0] == 'imp':
            a, b = _key(formula[1], m), _key(formula[2], m)
            _need(a in index and b in index, 'implication subformula closure')
            mp.append([i, index[a], index[b]])
            definitions[_key(['mp', i, index[a], index[b]], m)] = (index[b], [index[a], i], None, 'MP')
        elif formula[0] == 'all':
            body = _key(formula[2], m)
            _need(body in index, 'universal body closure')
            gen.append([i, index[body], formula[1]])
            definitions[_key(['gen', i, index[body], formula[1]], m)] = (i, [index[body]], formula[1], 'GEN')
    _need(type(compiled['mp_index']) is list and type(compiled['gen_index']) is list
          and _key(compiled['mp_index'], m) == _key(mp, m)
          and _key(compiled['gen_index'], m) == _key(gen, m), 'complete native MP/GEN indices')
    m.tick(len(definitions) * max(1, len(definitions).bit_length()))
    ordered = sorted(definitions)
    return dict(theory=theory, forms=forms, colors=colors, goal=compiled['goal_id'],
                definitions=definitions, ordered=ordered)


def _depth(depth):
    _need(type(depth) is int and 0 <= depth <= 32, 'finite binary depth')


def _site(site, depth):
    _need(type(site) is str and len(site) <= depth and all(c in '01' for c in site), 'binary site')


def _cid(site, definition, m):
    return _key([site, definition], m)


def _binding(data, depth, site, definition, m):
    _site(site, depth)
    _need(type(definition) is str and definition in data['definitions'], 'definition ID')
    output, premises, _, _ = data['definitions'][definition]
    _need(not premises or len(site) < depth, 'premise outside finite domain')
    m.tick(len(premises) + 1)
    sites = [site] + [site + str(i) for i in range(len(premises))]
    values = [output] + premises
    return {'id': _cid(site, definition, m),
            't': [[point, 1] for point in sorted(sites)],
            'm': [[point, data['colors'][value]] for point, value in sorted(zip(sites, values))]}


def _selected(data, depth, selected, m):
    _need(type(selected) is list and all(type(cid) is str for cid in selected), 'selected IDs')
    m.size(len(selected))
    _need(len(set(selected)) == len(selected), 'unique selected identities')
    anchors = {}
    bindings = []
    for cid in selected:
        m.tick(len(cid) + 1)
        try:
            pair = json.loads(cid)
        except (ValueError, TypeError):
            raise InputError('candidate ID JSON')
        _need(type(pair) is list and len(pair) == 2 and type(pair[0]) is str
              and type(pair[1]) is str and cid == _cid(pair[0], pair[1], m), 'canonical candidate ID')
        site, definition = pair
        _need(site not in anchors, 'one producer at each anchor')
        binding = _binding(data, depth, site, definition, m)
        anchors[site] = definition
        bindings.append(binding)
    totals = {'': 1}
    marks = {'': [data['colors'][data['goal']], 1]}
    active = {''}
    for binding in bindings:
        for point, units in binding['t']:
            m.tick()
            if point not in active and len(active) >= m.limits['max_items']:
                raise BudgetExceeded('ITEMS')
            active.add(point)
            totals[point] = totals.get(point, 0) + units
            _need(totals[point] <= 2, 'full positive support capacity')
        for point, value in binding['m']:
            m.tick()
            _need(point not in marks or marks[point][0] == value, 'whole marking agreement')
            if point not in marks:
                marks[point] = [value, 0]
            marks[point][1] += 1
    _need(set(anchors) == active and all(totals.get(p, 0) == 2 for p in active), 'exact active closure')
    # Explicit traversal supplies connectedness, fixed children and finite postorder.
    order = []
    stack = [('', False)]
    visited = set()
    while stack:
        m.tick()
        site, done = stack.pop()
        if done:
            order.append(site)
            continue
        _need(site in anchors and site not in visited, 'root-connected acyclic producers')
        visited.add(site)
        _, premises, _, _ = data['definitions'][anchors[site]]
        stack.append((site, True))
        for i in range(len(premises) - 1, -1, -1):
            stack.append((site + str(i), False))
    _need(visited == set(anchors), 'no disconnected selected component')
    proof = []
    rowmap = {}
    for site in order:
        m.tick()
        definition = anchors[site]
        output, premises, payload, kind = data['definitions'][definition]
        if kind == 'ZERO':
            line = _copy(payload, m)
        elif kind == 'MP':
            a, b = rowmap[site + '0'], rowmap[site + '1']
            _need(proof[b]['formula'] == ['imp', proof[a]['formula'], data['forms'][output]], 'actual earlier MP')
            line = {'rule': 'mp', 'formula': _copy(data['forms'][output], m), 'antecedent': a, 'implication': b}
        else:
            source = rowmap[site + '0']
            _need(data['forms'][output] == ['all', payload, proof[source]['formula']], 'actual earlier GEN')
            line = {'rule': 'generalize', 'formula': _copy(data['forms'][output], m), 'variable': payload, 'source': source}
        rowmap[site] = len(proof)
        proof.append(line)
    _need(proof and proof[-1]['formula'] == data['forms'][data['goal']], 'root goal is final native line')
    m.tick(len(bindings) * max(1, len(bindings).bit_length()) + len(active) * max(1, len(active).bit_length()))
    details = {'candidate_bindings': sorted(bindings, key=lambda r: r['id']),
               'active': sorted(active), 'totals': [[p, totals[p]] for p in sorted(active)],
               'marks': [[p] + marks[p] for p in sorted(marks)],
               'postorder_sites': order, 'site_to_line': [[p, rowmap[p]] for p in sorted(rowmap)],
               'tree_nodes': len(proof), 'maximum_site_depth': max(map(len, active)),
               'zero_schema_truth': 'EXTERNAL_CURRENT_CATALOGUE_SCHEMA_AND_NATIVE_OBLIGATION'}
    return proof, details


def _receipt(status, reason, proof, details, m):
    return {'schema': 'Z-independent-growing-proof-result-v1', 'version': VERSION,
            'status': status, 'reason': reason, 'proof': proof, 'details': details,
            'costs': m.costs(), 'scope': SCOPE}


def verify_tree(compiled, depth, selected, decoded=None, *, limits=None):
    """Reconstruct the whole actual tree, t/m and postorder proof independently."""
    m = _Meter(limits, VERIFY_LIMITS)
    try:
        _depth(depth)
        data = _catalogue(compiled, m)
        proof, details = _selected(data, depth, selected, m)
        if decoded is not None:
            _fields(decoded, {'status', 'reason', 'proof', 'target', 'tree', 'costs', 'scope'})
            tree = {'root': '', 'max_depth': depth, 'selected': sorted(selected),
                    'site_to_line': details['site_to_line'], 'node_count': len(proof),
                    'max_used_depth': details['maximum_site_depth'],
                    'placements': details['candidate_bindings'], 'totals': details['totals'],
                    'marks': details['marks']}
            _need(decoded['status'] == 'UNVERIFIED_CERTIFICATE' and decoded['reason'] is None
                  and _key(decoded['proof'], m) == _key(proof, m)
                  and _key(decoded['target'], m) == _key(data['forms'][data['goal']], m)
                  and _key(decoded['tree'], m) == _key(tree, m), 'complete decoder tree/postorder proof')
        m.tick()
        return _receipt('VERIFIED', None, proof, details, m)
    except BudgetExceeded as exc:
        return _receipt('UNKNOWN', str(exc), None, None, m)
    except InputError as exc:
        return _receipt('REJECTED', str(exc), None, None, m)


def _sha(value, m):
    image = _key(value, m) + '\n'
    m.tick(len(image))
    return hashlib.sha256(image.encode('ascii')).hexdigest()


def verify_factory(compiled, generation, depth, model, factory_receipt, *, limits=None):
    """Independently bind the complete structural inventory and exact model wire."""
    m = _Meter(limits, VERIFY_LIMITS)
    try:
        _depth(depth)
        data = _catalogue(compiled, m)
        _fields(generation, {'schema', 'version', 'profile', 'compiled_core_sha256', 'core_stages',
                            'core_assertions', 'goal_receptors', 'bridge_premises', 'scope'})
        core = {k: v for k, v in compiled.items() if k not in ('costs', 'scope')}
        digest = _sha(core, m)
        _need(generation['schema'] == 'Y-goal-receptor-universe-v1'
              and generation['version'] == 'Y-GOAL-RECEPTOR-FAMILY-v1'
              and generation['compiled_core_sha256'] == digest
              and _key(generation['profile'], m) == _key(compiled['profile'], m)
              and _key(generation['scope'], m) == _key(compiled['scope'], m), 'current Y generation binding')
        identity = _sha({'schema': 'Z-anchored-proof-inventory-identity-v1',
                         'version': 'Z-ANCHORED-PROOF-PRODUCER-v1',
                         'compiled_core_sha256': digest, 'depth': depth}, m)
        expected = {'schema': 'Z-growing-point-model-v1', 'version': 'Z-ANCHORED-PROOF-PRODUCER-v1',
                    'capacity': 2, 'roots': [''], 'seed': {'t': [['', 1]],
                    'm': [['', data['colors'][data['goal']]]]},
                    'inventory': {'kind': 'CERTIFIED_INCIDENT', 'identity': identity}}
        _need(_key(model, m) == _key(expected, m), 'factory complete seed/model/identity')
        _fields(factory_receipt, {'schema', 'version', 'status', 'reason', 'value', 'costs'})
        _need(factory_receipt['status'] == 'COMPLETE' and factory_receipt['reason'] is None
              and factory_receipt['schema'] == 'Z-anchored-proof-provider-result-v1'
              and factory_receipt['version'] == 'Z-ANCHORED-PROOF-PRODUCER-v1', 'whole factory return')
        value = factory_receipt['value']
        _fields(value, {'depth', 'compiled_core_sha256', 'identity', 'definitions', 'formula_count', 'potential_sites', 'scope'})
        definitions = []
        for identity_id in data['ordered']:
            m.tick()
            output, premises, payload, kind = data['definitions'][identity_id]
            native = payload['rule'] if kind == 'ZERO' else ('mp' if kind == 'MP' else 'generalize')
            zero_id = json.loads(identity_id)[1] if kind == 'ZERO' else None
            definitions.append({'id': identity_id, 'kind': kind, 'output': output,
                                'premises': list(premises), 'zero_id': zero_id,
                                'variable': payload if kind == 'GEN' else None, 'native_rule': native})
        _need(type(value['depth']) is int and value['depth'] == depth
              and value['compiled_core_sha256'] == digest and value['identity'] == identity
              and type(value['formula_count']) is int and value['formula_count'] == len(data['forms'])
              and type(value['potential_sites']) is int and value['potential_sites'] == (1 << (depth + 1)) - 1
              and _key(value['definitions'], m) == _key(definitions, m), 'entire native producer descriptor')
        m.tick()
        return _receipt('VERIFIED', None, None, {'identity': identity, 'definitions': len(definitions),
                        'catalogue_generation_truth': 'EXTERNAL_CURRENT_Y_AUDIT_AND_NATIVE_SCHEMA_GATE'}, m)
    except BudgetExceeded as exc:
        return _receipt('UNKNOWN', str(exc), None, None, m)
    except InputError as exc:
        return _receipt('REJECTED', str(exc), None, None, m)


def verify_incident(compiled, depth, point, packet, *, limits=None):
    """Check every own/parent positive alignment; no legality shortcut at a parent."""
    m = _Meter(limits, VERIFY_LIMITS)
    try:
        _depth(depth)
        _site(point, depth)
        data = _catalogue(compiled, m)
        _fields(packet, {'point', 'complete', 'placements'})
        _need(packet['point'] == point and packet['complete'] is True
              and type(packet['placements']) is list, 'incident packet')
        expected = []
        number = 0
        for definition in data['ordered']:
            m.tick()
            premises = data['definitions'][definition][1]
            number += int(not premises or len(point) < depth)
            number += int(bool(point) and int(point[-1]) < len(premises))
        m.size(number)
        for definition in data['ordered']:
            m.tick()
            _, premises, _, _ = data['definitions'][definition]
            if not premises or len(point) < depth:
                expected.append(_binding(data, depth, point, definition, m))
            if point and int(point[-1]) < len(premises):
                expected.append(_binding(data, depth, point[:-1], definition, m))
        m.size(len(expected))
        m.tick(len(expected) * max(1, len(expected).bit_length()))
        expected.sort(key=lambda r: r['id'])
        supplied = _copy(packet['placements'], m)
        _need(all(type(row) is dict and type(row.get('id')) is str for row in supplied), 'placement rows')
        m.tick(len(supplied) * max(1, len(supplied).bit_length()))
        supplied.sort(key=lambda r: r['id'])
        _need(_key(supplied, m) == _key(expected, m), 'entire incident inventory including parent contacts')
        m.tick()
        return _receipt('VERIFIED', None, None, {'point': point, 'placements': expected}, m)
    except BudgetExceeded as exc:
        return _receipt('UNKNOWN', str(exc), None, None, m)
    except InputError as exc:
        return _receipt('REJECTED', str(exc), None, None, m)


def tree_control(compiled, depth, limits=None):
    """Complete producer DP; shared memo work never discounts expanded tree cost."""
    m = _Meter(limits, CONTROL_LIMITS)
    try:
        _depth(depth)
        data = _catalogue(compiled, m)
        by_output = [[] for _ in data['forms']]
        for definition in data['ordered']:
            m.tick()
            by_output[data['definitions'][definition][0]].append(definition)
        memo = {}

        def minimum(formula, remaining):
            m.tick()
            key = (formula, remaining)
            if key in memo:
                return memo[key]
            if len(memo) >= m.limits['max_states']:
                raise BudgetExceeded('STATES')
            # Reserve an in-progress key before descending; depth strictly decreases.
            memo[key] = None
            best = None
            for definition in by_output[formula]:
                m.tick()
                _, premises, _, _ = data['definitions'][definition]
                if premises and remaining == 0:
                    continue
                size = 1
                possible = True
                for premise in premises:
                    child = minimum(premise, remaining - 1)
                    if child is None:
                        possible = False
                        break
                    size += child[0]
                if possible and (best is None or (size, definition) < best):
                    best = (size, definition)
            memo[key] = best
            return best

        best = minimum(data['goal'], depth)
        if best is None:
            m.tick()
            return _receipt('NOT_DERIVABLE', 'EXHAUSTED_DECLARED_FINITE_DEPTH_INVENTORY', None,
                            {'depth': depth, 'states': len(memo), 'minimum_tree_nodes': None}, m)
        if best[0] > m.limits['max_proof_lines']:
            raise BudgetExceeded('PROOF_OUTPUT_LIMIT')
        m.size(best[0])
        selected = []
        stack = [('', data['goal'], depth)]
        while stack:
            m.tick()
            site, formula, remaining = stack.pop()
            definition = memo[(formula, remaining)][1]
            selected.append(_cid(site, definition, m))
            premises = data['definitions'][definition][1]
            for i in range(len(premises) - 1, -1, -1):
                stack.append((site + str(i), premises[i], remaining - 1))
        proof, details = _selected(data, depth, selected, m)
        _need(len(proof) == best[0], 'minimum expanded tree reconstruction')
        details.update({'depth': depth, 'states': len(memo), 'minimum_tree_nodes': best[0],
                        'selected': sorted(selected), 'sharing': 'Memoized search work only; each tree occurrence emitted separately.'})
        m.tick()
        return _receipt('DERIVABLE', None, proof, details, m)
    except BudgetExceeded as exc:
        return _receipt('UNKNOWN', str(exc), None, None, m)
    except InputError as exc:
        return _receipt('REJECTED', str(exc), None, None, m)


def _strings(value, m):
    _need(type(value) is list, 'string list')
    m.size(len(value))
    _need(all(type(v) is str for v in value), 'literal strings')
    m.tick(len(value) * max(1, len(value).bit_length()))
    _need(value == sorted(set(value)), 'sorted unique strings')
    return value


def _rows(value, capacity, markings, m, seed=False):
    _need(type(value) is list, 'point-value rows')
    m.size(len(value))
    out = {}
    for row in value:
        m.tick()
        _need(type(row) is list and len(row) == 2 and type(row[0]) is str
              and row[0] not in out, 'unique point row')
        if markings:
            _need(type(row[1]) is str, 'literal marking value')
        else:
            _need(type(row[1]) is int and (0 if seed else 1) <= row[1] <= capacity
                  and row[1].bit_length() <= 256, 'exact unit contribution')
        out[row[0]] = row[1]
    m.tick(len(out) * max(1, len(out).bit_length()))
    return [[p, out[p]] for p in sorted(out)]


def _placement(value, capacity, m):
    _fields(value, {'id', 't', 'm'})
    _need(type(value['id']) is str and value['id'], 'placement identity')
    t = _rows(value['t'], capacity, False, m)
    _need(t, 'nonempty positive support')
    return {'id': value['id'], 't': t, 'm': _rows(value['m'], capacity, True, m)}


def _placements(value, capacity, m):
    _need(type(value) is list, 'placement list')
    m.size(len(value))
    rows = [_placement(row, capacity, m) for row in value]
    m.tick(len(rows) * max(1, len(rows).bit_length()))
    rows.sort(key=lambda row: row['id'])
    _need(len({row['id'] for row in rows}) == len(rows), 'unique global placement identities')
    return rows


def _model(model, universe, m):
    _fields(model, {'schema', 'version', 'capacity', 'roots', 'seed', 'inventory'})
    model = _copy(model, m)
    _need(model['schema'] == 'Z-growing-point-model-v1' and type(model['version']) is str
          and model['version'], 'growing model identity')
    cap = model['capacity']
    _need(type(cap) is int and 1 <= cap and cap.bit_length() <= 256, 'positive exact capacity')
    _need(type(model['roots']) is list and all(type(p) is str for p in model['roots']), 'roots')
    m.size(len(model['roots']))
    _need(len(set(model['roots'])) == len(model['roots']), 'unique roots')
    m.tick(len(model['roots']) * max(1, len(model['roots']).bit_length()))
    model['roots'].sort()
    _fields(model['seed'], {'t', 'm'})
    model['seed'] = {'t': _rows(model['seed']['t'], cap, False, m, True),
                     'm': _rows(model['seed']['m'], cap, True, m)}
    inv = model['inventory']
    _need(type(inv) is dict and type(inv.get('kind')) is str, 'inventory')
    if inv['kind'] == 'EXPLICIT':
        _fields(inv, {'kind', 'placements'})
        allrows = _placements(inv['placements'], cap, m)
        model['inventory'] = {'kind': 'EXPLICIT', 'placements': allrows}
        if universe is not None:
            _need(_key(_placements(universe, cap, m), m) == _key(allrows, m), 'explicit universe binding')
    else:
        _fields(inv, {'kind', 'identity'})
        _need(inv['kind'] == 'CERTIFIED_INCIDENT' and type(inv['identity']) is str
              and inv['identity'], 'certified incident identity')
        _need(universe is not None, 'independent complete finite universe required for graph audit')
        allrows = _placements(universe, cap, m)
    return model, {row['id']: row for row in allrows}


def _values(model, universe, selected, m):
    q = set(model['roots'])
    totals = dict(model['seed']['t'])
    q.update(p for p, n in model['seed']['t'] if n > 0)
    marks = {p: [v, 1] for p, v in model['seed']['m']}
    generations = {p: 0 for p in q}
    for cid, tile_generation in selected:
        m.tick()
        _need(type(cid) is str and cid in universe and type(tile_generation) is int
              and 1 <= tile_generation and tile_generation.bit_length() <= 256, 'selected identity/generation')
        row = universe[cid]
        for p, n in row['t']:
            m.tick()
            if p not in q and len(q) >= m.limits['max_items']:
                raise BudgetExceeded('ITEMS')
            q.add(p)
            totals[p] = totals.get(p, 0) + n
            _need(totals[p] <= model['capacity'], 'selected global capacity')
            generations[p] = min(generations.get(p, tile_generation), tile_generation)
        for p, v in row['m']:
            m.tick()
            _need(p not in marks or marks[p][0] == v, 'selected global marking agreement')
            if p not in marks:
                marks[p] = [v, 0]
            marks[p][1] += 1
    m.size(len(q))
    m.size(len(marks))
    return q, totals, marks, generations


def _legal(row, cap, totals, marks, m):
    for p, n in row['t']:
        m.tick()
        if n > cap - totals.get(p, 0):
            return False
    for p, v in row['m']:
        m.tick()
        if p in marks and marks[p][0] != v:
            return False
    return True


def _state(model, universe, state, m):
    _fields(state, {'Q', 'totals', 'selected', 'marks', 'excluded', 'eligible',
                    'domains', 'forward', 'reverse', 'placements', 'loaded', 'dependencies', 'edge_count'})
    state = _copy(state, m)
    _need(type(state['selected']) is list, 'selected generation rows')
    selected = []
    for row in state['selected']:
        _need(type(row) is list and len(row) == 2, 'selected pair')
        selected.append(row)
    _need(all(type(row[0]) is str for row in selected)
          and [r[0] for r in selected] == sorted(set(r[0] for r in selected)), 'selected ID order')
    q, totals, marks, generations = _values(model, universe, selected, m)
    registered = _placements(state['placements'], model['capacity'], m)
    _need(all(row['id'] in universe and _key(row, m) == _key(universe[row['id']], m)
              for row in registered), 'actual registered inventory rows')
    known = {row['id']: row for row in registered}
    _need(all(cid in known for cid, _ in selected), 'selected registered')
    excluded = _strings(state['excluded'], m)
    _need(all(cid in known for cid in excluded) and not set(excluded).intersection(cid for cid, _ in selected), 'context exclusions')
    loaded = _strings(state['loaded'], m)
    frontier = sorted(p for p in q if totals.get(p, 0) < model['capacity'])
    _need(set(frontier) <= set(loaded) <= q, 'all frontier enumeration exhausted in active Q')
    if model['inventory']['kind'] == 'EXPLICIT':
        _need(set(known) == set(universe), 'whole explicit inventory registered')
    else:
        expected_known = set()
        for cid, row in universe.items():
            m.tick(len(row['t']))
            if any(p in loaded for p, _ in row['t']):
                expected_known.add(cid)
        _need(set(known) == expected_known, 'complete every loaded potential contact')
    selected_ids = {cid for cid, _ in selected}
    eligible = sorted(cid for cid, row in known.items() if cid not in selected_ids
                      and cid not in excluded and _legal(row, model['capacity'], totals, marks, m))
    domains = []
    forward = []
    reverse = {}
    for p in frontier:
        ids = []
        for cid in eligible:
            m.tick(len(known[cid]['t']))
            units = dict(known[cid]['t']).get(p, 0)
            if units:
                if len(forward) >= m.limits['max_items']:
                    raise BudgetExceeded('ITEMS')
                ids.append(cid)
                forward.append([p, cid, units])
                reverse.setdefault(cid, []).append([p, units])
        domains.append([p, ids])
    m.size(len(forward))
    dependencies = {}
    for channel in ('t', 'm'):
        inverse = {}
        for cid, placement in known.items():
            for point, _ in placement[channel]:
                m.tick()
                inverse.setdefault(point, []).append(cid)
        dependencies[channel] = [[p, sorted(inverse[p])] for p in sorted(inverse)]
    expected = {'Q': [[p, generations[p]] for p in sorted(q)],
                'totals': [[p, totals.get(p, 0)] for p in sorted(q | set(totals))], 'selected': selected,
                'marks': [[p] + marks[p] for p in sorted(marks)], 'excluded': excluded,
                'eligible': eligible, 'domains': domains, 'forward': forward,
                'reverse': [[cid, reverse[cid]] for cid in sorted(reverse)],
                'placements': registered, 'loaded': loaded,
                'dependencies': dependencies, 'edge_count': len(forward)}
    _need(_key(state, m) == _key(expected, m), 'complete independent point/candidate graph and values')
    return expected


def verify_state(model, state, *, universe=None, limits=None):
    """Full tiny graph audit; incident mode requires independently complete universe."""
    m = _Meter(limits, VERIFY_LIMITS)
    try:
        normal, allrows = _model(model, universe, m)
        expected = _state(normal, allrows, state, m)
        m.tick()
        return _receipt('VERIFIED', None, None, {'state_sha256': _sha(expected, m),
                        'frontier': len(expected['domains']), 'edges': len(expected['forward'])}, m)
    except BudgetExceeded as exc:
        return _receipt('UNKNOWN', str(exc), None, None, m)
    except InputError as exc:
        return _receipt('REJECTED', str(exc), None, None, m)


def _certificate(model, universe, ids, m):
    ids = _strings(ids, m)
    _need(all(cid in universe for cid in ids), 'certificate inventory')
    # Generation does not enter the t/m certificate. Connectivity is checked separately.
    q, totals, marks, _ = _values(model, universe, [[cid, 1] for cid in ids], m)
    _need(all(totals.get(p, 0) == model['capacity'] for p in q), 'all activated deficits closed')
    reachable = set(model['roots']) | {p for p, n in model['seed']['t'] if n > 0}
    pending = set(ids)
    while pending:
        m.tick()
        added = []
        for cid in sorted(pending):
            m.tick(len(universe[cid]['t']))
            if any(p in reachable for p, _ in universe[cid]['t']):
                reachable.update(p for p, _ in universe[cid]['t'])
                added.append(cid)
        _need(added, 'no disconnected selected component')
        pending.difference_update(added)
    return {'capacity': model['capacity'], 'roots': model['roots'], 'seed': model['seed'],
            'placements': [universe[cid] for cid in ids],
            'totals': [[p, totals.get(p, 0)] for p in sorted(q)],
            'marks': [[p] + marks[p] for p in sorted(marks)]}


def _event(event, state, m):
    _fields(event, {'seq', 'kind', 'point', 'candidate', 'data'})
    _need(type(event['seq']) is int and event['seq'] >= 0
          and type(event['kind']) is str and type(event['data']) is dict, 'event header')
    domains = dict(state['domains'])
    generations = dict(state['Q'])
    kind, point, cid = event['kind'], event['point'], event['candidate']
    _need(point is None or type(point) is str, 'event point')
    _need(cid is None or type(cid) is str, 'event candidate')
    if kind in ('DEAD', 'FORCED', 'BRANCH'):
        _need(point in domains and type(event['data'].get('generation')) is int
              and event['data']['generation'] == generations[point], 'scheduler point/generation')
        dead = [p for p in domains if not domains[p]]
        forced = [p for p in domains if len(domains[p]) == 1]
        if kind == 'DEAD':
            _fields(event['data'], {'generation'})
            _need(point in dead and cid is None, 'global dead')
        elif kind == 'FORCED':
            _fields(event['data'], {'generation'})
            _need(not dead and forced and point == min(forced, key=lambda p: (generations[p], p))
                  and cid == domains[point][0], 'global forced before any branch')
        else:
            _fields(event['data'], {'generation', 'legal', 'order'})
            legal = domains[point]
            ordering = event['data']['order']
            _need(not dead and not forced and domains
                  and point == min(domains, key=lambda p: (generations[p], len(domains[p]), p))
                  and _key(event['data']['legal'], m) == _key(legal, m)
                  and type(ordering) is list and all(type(c) is str for c in ordering)
                  and len(ordering) == len(legal) and set(ordering) == set(legal)
                  and cid is None, 'generation-first complete branch')
    elif kind == 'PLACED':
        _fields(event['data'], {'generation', 'forced'})
        _need(type(event['data']['forced']) is bool and type(event['data']['generation']) is int
              and cid in dict(state['selected']) and dict(state['selected'])[cid] == event['data']['generation'], 'completed placement')
    elif kind == 'EXCLUDE':
        _fields(event['data'], set())
        _need(cid in state['excluded'], 'current-context exclusion')
    elif kind in ('READY', 'SOLUTION', 'EXHAUSTED'):
        _fields(event['data'], set())
        if kind == 'SOLUTION':
            _need(not domains, 'solution has no active deficit')
    else:
        raise InputError('event kind')


def verify_result(model, result, *, universe=None, observations=None, limits=None):
    """Full returned images plus optional complete external event/state observations."""
    m = _Meter(limits, VERIFY_LIMITS)
    try:
        normal, allrows = _model(model, universe, m)
        _fields(result, {'schema', 'version', 'status', 'reason', 'model_sha256', 'selected',
                         'certificate', 'entry_state', 'final_state', 'restored_state', 'state_hashes',
                         'events', 'event_extent', 'rollback_records', 'rollback_extent', 'stats', 'limits'})
        _need(result['schema'] == 'Z-growing-point-search-result-v1'
              and result['version'] == 'Z-GROWING-POINT-SEARCH-v1'
              and result['status'] in ('SAT', 'UNSAT', 'UNKNOWN'), 'result identity/status')
        status = result['status']
        statkeys = {'work', 'nodes', 'placements', 'forced', 'branches', 'dead_ends', 'backtracks',
                    'exclusions', 'legality_checks', 'candidate_registrations', 'provider_calls',
                    'provider_rows', 'edge_additions', 'edge_removals', 'dependency_links',
                    'peak_frontier', 'peak_Q', 'peak_candidates', 'peak_edges', 'peak_trail',
                    'events_total', 'rollbacks_total', 'rollback_edits', 'audit_calls',
                    'ordering_calls', 'elapsed_seconds', 'cleanup_seconds'}
        _fields(result['stats'], statkeys)
        for key, value in result['stats'].items():
            _need(type(value) in (int, float) and math.isfinite(value) and value >= 0
                  if key.endswith('_seconds') else type(value) is int and value >= 0, 'stat type')
        _fields(result['limits'], {'wall_seconds', 'max_work', 'max_nodes', 'max_events',
                                  'max_rollback_records', 'max_candidates', 'max_points'})
        digest = _sha(normal, m)
        _need(result['model_sha256'] == digest or (status == 'UNKNOWN' and result['model_sha256'] is None), 'normalized model hash')
        _fields(result['state_hashes'], {'entry', 'final', 'restored'})
        for key in ('entry', 'final', 'restored'):
            state = result[key + '_state']
            supplied = result['state_hashes'][key]
            if state is None:
                _need(supplied is None and status == 'UNKNOWN', 'missing image only resource refusal')
            else:
                _state(normal, allrows, state, m)
                _need(type(supplied) is str and supplied == _sha(state, m), 'full state hash')
        if result['entry_state'] is not None:
            _need(not result['entry_state']['selected'] and not result['entry_state']['excluded']
                  and _key(result['entry_state'], m) == _key(result['restored_state'], m), 'exact full entry restoration')
        else:
            _need(result['restored_state'] is None, 'no invented pre-entry restored state')
        if status == 'SAT':
            expected = _certificate(normal, allrows, result['selected'], m)
            _need(result['reason'] == 'FINITE_ACTIVE_OBLIGATIONS_EXACT'
                  and _key(result['certificate'], m) == _key(expected, m)
                  and [r[0] for r in result['final_state']['selected']] == result['selected']
                  and not result['final_state']['domains'], 'whole SAT certificate')
        else:
            _need(result['selected'] == [] and result['certificate'] is None, 'nonpositive has no certificate')
            if status == 'UNKNOWN':
                _need(result['final_state'] is None, 'no stale interrupted final image')
            else:
                _need(result['reason'] == 'EXHAUSTED_DECLARED_FINITE_INVENTORY', 'finite exhausted reason')
        for name, body in (('event', result['events']), ('rollback', result['rollback_records'])):
            extent = result[name + '_extent']
            _fields(extent, {'total', 'retained', 'sha256', 'scope'})
            _need(type(body) is list and type(extent['total']) is int and type(extent['retained']) is int
                  and 0 <= extent['retained'] <= extent['total'] and len(body) == extent['retained']
                  and extent['scope'] == 'BOUNDED_PREFIX_COMPLETE_EMITTED_STREAM_HASH'
                  and type(extent['sha256']) is str and len(extent['sha256']) == 64, 'stream extent')
            if len(body) == extent['total']:
                stream = hashlib.sha256()
                for row in body:
                    image = _key(row, m) + '\n'
                    m.tick(len(image))
                    stream.update(image.encode('ascii'))
                _need(stream.hexdigest() == extent['sha256'], 'complete retained stream hash')
        for row in result['rollback_records']:
            _fields(row, {'reason', 'from_trail', 'to_trail', 'undone', 'selected_before', 'selected_after'})
            _need(row['reason'] in ('FAILED_CHILD', 'FINAL_RESTORE')
                  and all(type(v) is int and v >= 0 for k, v in row.items() if k != 'reason')
                  and row['from_trail'] - row['to_trail'] == row['undone']
                  and row['selected_after'] <= row['selected_before'], 'inverse trail receipt')
        count = 0
        if observations is not None:
            _need(type(observations) is list, 'observations list')
            m.size(len(observations))
            for i, row in enumerate(observations):
                _fields(row, {'event', 'state'})
                _need(row['event']['seq'] == i, 'observed event sequence')
                state = _state(normal, allrows, row['state'], m)
                _event(row['event'], state, m)
                if row['event']['kind'] == 'PLACED':
                    _need(i > 0, 'placement needs scheduler predecessor')
                    previous = observations[i - 1]
                    _need(previous['event']['kind'] in ('FORCED', 'BRANCH'), 'placement scheduler predecessor')
                    chosen = (previous['event']['candidate'] if previous['event']['kind'] == 'FORCED'
                              else previous['event']['data']['order'][0])
                    _need(chosen == row['event']['candidate'], 'placed selected by actual scheduler')
                    cid = row['event']['candidate']
                    old = previous['state']
                    oldq = dict(old['Q'])
                    touching = [oldq[p] for p, _ in allrows[cid]['t'] if p in oldq]
                    _need(touching and row['event']['data']['generation'] == 1 + min(touching)
                          and dict(state['selected']) == dict(old['selected']) | {cid: 1 + min(touching)}, 'actual placed generation and selected delta')
                if row['event']['kind'] == 'EXCLUDE':
                    cid = row['event']['candidate']
                    m.tick(i)
                    parents = [prior for prior in observations[:i]
                               if prior['event']['kind'] == 'BRANCH' and prior['event']['data']['order'][0] == cid
                               and prior['state']['selected'] == state['selected']]
                    _need(parents, 'failed child exclusion has actual parent branch')
                    parent = parents[-1]['state']
                    for key in ('Q', 'totals', 'selected', 'marks', 'placements', 'loaded'):
                        _need(_key(parent[key], m) == _key(state[key], m), 'failed child restores parent '+key)
                    _need(state['excluded'] == sorted(set(parent['excluded']) | {cid}), 'exclusion scoped only to restored parent')
                count += 1
            _need(count <= result['event_extent']['total']
                  and (status == 'UNKNOWN' or count == result['event_extent']['total']), 'honest complete normal observation stream')
            _need(_key([r['event'] for r in observations[:len(result['events'])]], m)
                  == _key(result['events'][:count], m), 'retained event/observer join')
        _need(result['stats']['events_total'] == result['event_extent']['total']
              and result['stats']['rollbacks_total'] == result['rollback_extent']['total'], 'stream/stat counts')
        m.tick()
        return _receipt('VERIFIED', None, None, {'status': status, 'observations': count,
                        'normal_restore': result['entry_state'] is not None,
                        'negative_scope': 'Finite declared active-growth inventory only; provider completeness remains external.'}, m)
    except BudgetExceeded as exc:
        return _receipt('UNKNOWN', str(exc), None, None, m)
    except InputError as exc:
        return _receipt('REJECTED', str(exc), None, None, m)


ENGINE_LIMITS = dict(wall_seconds=2, max_work=20000000, max_nodes=10000,
                     max_events=10000, max_rollback_records=10000,
                     max_candidates=1000, max_points=1000)
ADAPTER_LIMITS = dict(wall_seconds=5, max_work=100000000, max_depth=128,
                      max_definitions=10000, max_proof_lines=64)
QUALIFY_LIMITS = dict(wall_seconds=60, max_work=1000000000, max_depth=128, max_items=200000)


class _Foreign(Exception):
    pass


def _literal_models():
    def c(cid, t, marks=None):
        return {'id': cid, 't': t, 'm': [] if marks is None else marks}

    def model(name, roots, seed_t, placements, cap=2, seed_m=None):
        return name, {'schema': 'Z-growing-point-model-v1', 'version': 'Z-TINY-' + name,
                      'capacity': cap, 'roots': roots,
                      'seed': {'t': seed_t, 'm': [] if seed_m is None else seed_m},
                      'inventory': {'kind': 'EXPLICIT', 'placements': placements}}

    return [
        model('empty', [], [], []),
        model('seed-complete-zero-dormant', ['r'], [['r', 2], ['z', 0]], [], seed_m=[['remote', '0']]),
        model('half-root', ['r'], [['r', 1]], [c('a', [['r', 1]])]),
        model('shared-forced', ['p', 'q'], [['p', 1], ['q', 1]], [c('a', [['p', 1], ['q', 1]])]),
        model('thirds-shared', ['p', 'q'], [['p', 1], ['q', 1]],
              [c('a', [['p', 1], ['q', 1]]), c('b', [['p', 1], ['q', 1]])], 3),
        model('fractional-residual-dead', ['p'], [['p', 1]], [c('a', [['p', 1]])], 3),
        model('remote-mark', ['p', 'q'], [['p', 1], ['q', 1]],
              [c('a0', [['p', 1]], [['remote', '0']]), c('a1', [['p', 1]], [['remote', '1']]),
               c('b0', [['q', 1]], [['remote', '0']]), c('b1', [['q', 1]], [['remote', '1']])]),
        model('absent-versus-zero', ['p'], [['p', 1]],
              [c('a', [['p', 1]], [['remote', '0']]), c('b', [['p', 1]])], seed_m=[['remote', '1']]),
        model('equal-mark-refcounts', ['p', 'q'], [['p', 1], ['q', 1]],
              [c('a', [['p', 1]], [['remote', '0']]), c('b', [['q', 1]], [['remote', '0']])]),
        model('late-dead-before-forced', ['r', 'u'], [['r', 1], ['u', 1]],
              [c('a', [['r', 1], ['x', 1]]), c('b', [['u', 1]])]),
        model('forced-before-generation', ['r', 'u'], [['r', 1], ['u', 1]],
              [c('a', [['r', 1], ['x', 1]]), c('b', [['u', 1]]),
               c('c', [['u', 1]]), c('d', [['x', 1]])]),
        model('generation-before-degree', ['r', 'u'], [['r', 1], ['u', 1]],
              [c('a', [['r', 1], ['x', 1]]), c('b', [['u', 1]]), c('c', [['u', 1]]),
               c('d', [['u', 1]]), c('e', [['x', 1]]), c('f', [['x', 1]])]),
        model('bad-first-restore', ['r'], [['r', 1]],
              [c('a', [['r', 1], ['x', 1]]), c('b', [['r', 1]])]),
        model('dormant-component', ['r'], [['r', 1]],
              [c('a', [['r', 1]]), c('b', [['island', 1]]), c('c', [['island', 1]])]),
        model('parent-positive-contacts', ['r'], [['r', 1]],
              [c('a', [['r', 1], ['x', 1]]), c('b', [['x', 1]])]),
        model('eligible-without-frontier', ['r'], [['r', 1]],
              [c('a', [['r', 1]]), c('b', [['z', 1]], [['remote', '0']])]),
        model('seed-zero-activated', ['r'], [['r', 1], ['x', 0]],
              [c('a', [['r', 1], ['x', 1]]), c('b', [['x', 1]])]),
    ]


def _brute(model, universe, m):
    normal, allrows = _model(model, universe, m)
    ids = sorted(allrows)
    _need(len(ids) <= 16, 'complete tiny product cap')
    m.tick(1 << len(ids))
    solutions = []
    for mask in range(1 << len(ids)):
        selected = [cid for i, cid in enumerate(ids) if mask & (1 << i)]
        try:
            _certificate(normal, allrows, selected, m)
        except InputError:
            continue
        solutions.append(selected)
    return solutions


def _tiny_catalogue(axioms, goal, m):
    """Literal structural fixtures, not a claim to regenerate the Y zero grammar."""
    theory = {'functions': {}, 'predicates': {'G': 0, 'P': 0, 'Q': 0}, 'axioms': axioms}
    pool = {}
    todo = [goal] + list(axioms.values())
    while todo:
        m.tick()
        value = todo.pop()
        image = _key(value, m)
        if image in pool:
            continue
        pool[image] = value
        if value[0] in ('imp', 'and', 'or'):
            todo.extend(value[1:])
        elif value[0] == 'all':
            todo.append(value[2])
        elif value[0] == 'not':
            todo.append(value[1])
    colors = sorted(pool)
    forms = [pool[key] for key in colors]
    index = {key: i for i, key in enumerate(colors)}
    lines = [{'rule': 'axiom', 'name': name, 'formula': value} for name, value in axioms.items()]
    lines.sort(key=lambda line: _key(line, m))
    zero = [{'id': 'i' + str(i), 'rule': 'axiom', 'formula_id': index[_key(line['formula'], m)], 'line': line}
            for i, line in enumerate(lines)]
    mp = []
    gen = []
    for i, formula in enumerate(forms):
        if formula[0] == 'imp':
            mp.append([i, index[_key(formula[1], m)], index[_key(formula[2], m)]])
        elif formula[0] == 'all':
            gen.append([i, index[_key(formula[2], m)], formula[1]])
    profile = {'ui_rounds': 0, 'bridge_arity': 0, 'max_tautology_atoms': 0}
    compiled = {'schema': 'V-interned-Hilbert8-basis-v1', 'version': 'V-INTERNED-FINITE-HILBERT8-v1',
                'theory': theory, 'goal': goal, 'goal_id': index[_key(goal, m)], 'profile': profile,
                'logical_basis': {'instantiation_terms': [], 'terms': [], 'variables': [],
                                  'formulas': forms, 'colors': colors, 'templates': [],
                                  'hole': '__z_literal_fixture', 'stages': []},
                'zero_instances': zero, 'mp_index': mp, 'gen_index': gen,
                'costs': {'work': 0, 'seconds': 0.0, 'terms': 0, 'formulas': len(forms),
                          'instances': len(zero), 'candidates': 0, 'cache_hits': 0, 'cache_misses': 0,
                          'canonical_serializations': 0, 'substitution_calls': 0},
                'scope': 'SYNTHETIC_STRUCTURAL_NATIVE_AXIOM_FIXTURE_NOT_FULL_Y_GENERATION'}
    generation = {'schema': 'Y-goal-receptor-universe-v1', 'version': 'Y-GOAL-RECEPTOR-FAMILY-v1',
                  'profile': profile, 'compiled_core_sha256': _sha({k: v for k, v in compiled.items()
                                       if k not in ('costs', 'scope')}, m),
                  'core_stages': [], 'core_assertions': [], 'goal_receptors': [], 'bridge_premises': [],
                  'scope': compiled['scope']}
    return compiled, generation


def qualify(engine, adapter, emit):
    """Closed 40-solve / 41-record qualification, invoked only by a fresh owned once."""
    m = _Meter(QUALIFY_LIMITS, QUALIFY_LIMITS)
    counts = {'engine.solve': 0, 'adapter.make_provider': 0, 'adapter.decode': 0,
              'tree_control': 0, 'emissions': 0, 'native_certificates': 0,
              'full_observations': 0}
    names = []
    models = _literal_models()
    completed = []

    def send(name, data):
        m.tick()
        _need(type(name) is str and name not in names, 'unique emission')
        names.append(name)
        counts['emissions'] += 1
        counts['native_certificates'] += len(data['native_certificates'])
        emit(name, data)
        m.tick()

    def run(name, model, universe=None, provider=None, ordering=None, mutate=False, limits=None, brute=True):
        normal, allrows = _model(model, universe, m)
        observations = []

        def audit(event, state, charge):
            old = m.hook
            m.hook = charge
            try:
                _state(normal, allrows, state, m)
                _event(event, state, m)
                observations.append({'event': _copy(event, m), 'state': _copy(state, m)})
                if mutate:
                    event.clear()
                    state.clear()
            finally:
                m.hook = old
            return False

        counts['engine.solve'] += 1
        answer = engine.solve(model, dict(ENGINE_LIMITS) if limits is None else limits,
                              enumerate_incident=provider, order=ordering, audit=audit)
        checked = verify_result(model, answer, universe=universe, observations=observations)
        _need(checked['status'] == 'VERIFIED', 'full returned result audit: ' + str(checked['reason']))
        if ordering is None:
            _need(all(row['event']['data']['order'] == row['event']['data']['legal']
                      for row in observations if row['event']['kind'] == 'BRANCH'), 'complete literal lexical fallback')
        solutions = _brute(model, universe, m) if brute else None
        if brute and answer['status'] != 'UNKNOWN':
            _need((answer['status'] == 'SAT') == bool(solutions)
                  and (answer['status'] != 'SAT' or answer['selected'] in solutions), 'complete tiny subset existence/witness equality')
        counts['full_observations'] += len(observations)
        data = {'model': model, 'universe': universe, 'result': answer,
                'observations': observations, 'independent': checked,
                'all_subset_solutions': solutions, 'native_certificates': []}
        completed.append(data)
        if name is not None:
            send(name, data)
        return data

    for name, model in models:
        record = run('generic-' + name, model)
        events = [row['event'] for row in record['observations']]
        if name == 'shared-forced':
            _need(record['result']['stats']['placements'] == 1
                  and record['result']['stats']['forced'] == 1, 'shared forced candidate selected once')
        if name == 'fractional-residual-dead':
            _need(any(e['kind'] == 'FORCED' for e in events)
                  and any(e['kind'] == 'DEAD' and e['point'] == 'p' for e in events), 'residual singleton actually exposed dead')
        if name == 'late-dead-before-forced':
            _need(any(e['kind'] == 'DEAD' and e['point'] == 'x' for e in events)
                  and not any(e['kind'] == 'PLACED' and e['candidate'] == 'b' for e in events), 'late global dead before other forced')
        if name == 'forced-before-generation':
            indices = [i for i, e in enumerate(events) if e['kind'] == 'FORCED' and e['point'] == 'x']
            branches = [i for i, e in enumerate(events) if e['kind'] == 'BRANCH']
            _need(indices and branches and indices[0] < branches[0], 'later forced before earlier generation branch')
        if name == 'generation-before-degree':
            branches = [e for e in events if e['kind'] == 'BRANCH']
            _need(branches and branches[0]['point'] == 'u' and len(branches[0]['data']['legal']) == 3, 'earlier generation outranks smaller later degree')
        if name == 'bad-first-restore':
            _need(record['result']['stats']['backtracks'] >= 1 and record['result']['stats']['exclusions'] >= 1
                  and any(e['kind'] == 'EXCLUDE' and e['candidate'] == 'a' for e in events), 'actual failed child restored/excluded')

    def provider_for(rows):
        def provider(point, charge):
            old = m.hook
            m.hook = charge
            try:
                m.tick(len(rows))
                answer = []
                for row in rows:
                    m.tick(len(row['t']))
                    if any(p == point for p, _ in row['t']):
                        answer.append(_copy(row, m))
                answer.sort(key=lambda row: row['id'])
                return {'point': point, 'complete': True, 'placements': answer}
            finally:
                m.hook = old
        return provider

    for index in (4, 12, 14):
        name, source = models[index]
        model = _copy(source, m)
        universe = model['inventory']['placements']
        model['inventory'] = {'kind': 'CERTIFIED_INCIDENT', 'identity': 'Z-LITERAL-' + name}
        run('incident-' + name, model, universe, provider_for(universe))

    branch_model = models[12][1]
    requests = []

    def preference(request, charge):
        charge(len(request['legal']) + 1)
        requests.append(_copy(request, m))
        choice = request['legal'][-1]
        request.clear()
        return [choice]

    run('order-detached-complete-fallback', branch_model, ordering=preference)
    run('audit-false-and-detached-mutation', branch_model, mutate=True)

    def expect_error(name, model, error, provider=None, ordering=None, audit=None):
        counts['engine.solve'] += 1
        try:
            engine.solve(model, dict(ENGINE_LIMITS), enumerate_incident=provider,
                         order=ordering, audit=audit)
        except error as exc:
            send(name, {'model': model, 'exception_class': type(exc).__name__,
                        'exception_message': str(exc), 'post_exception_state': None,
                        'scope': 'Foreign/error cleanup is Source-reviewed; no post-throw snapshot invented.',
                        'native_certificates': []})
        else:
            raise AssertionError('expected error ' + name)

    expect_error('ordering-invalid-duplicates', branch_model, engine.OrderingError,
                 ordering=lambda request, charge: request['legal'][:1] * 2)

    def foreign(*args):
        raise _Foreign('Z-declared-foreign-control')

    expect_error('ordering-foreign', branch_model, _Foreign, ordering=foreign)
    expect_error('audit-foreign', branch_model, _Foreign, audit=foreign)
    incident = _copy(models[2][1], m)
    incident_rows = incident['inventory']['placements']
    incident['inventory'] = {'kind': 'CERTIFIED_INCIDENT', 'identity': 'Z-LITERAL-ERRORS'}
    expect_error('provider-foreign', incident, _Foreign, provider=foreign)
    expect_error('provider-incomplete-flag', incident, engine.InventoryError,
                 provider=lambda point, charge: {'point': point, 'complete': False, 'placements': []})

    for name, patch, model in [
            ('nodes-zero', {'max_nodes': 0}, branch_model),
            ('work-preparation', {'max_work': 1}, branch_model),
            ('point-growth', {'max_points': 1}, models[14][1]),
            ('candidate-preparation', {'max_candidates': 1}, branch_model)]:
        limits = dict(ENGINE_LIMITS)
        limits.update(patch)
        data = run(None, model, limits=limits, brute=False)
        _need(data['result']['status'] == 'UNKNOWN', 'owned cap must UNKNOWN')
        send('resource-' + name, data)

    def sticky(point, charge):
        try:
            charge(ENGINE_LIMITS['max_work'] + 1)
        except Exception:
            pass
        return {'point': point, 'complete': True, 'placements': _copy(incident_rows, m)}

    data = run(None, incident, incident_rows, sticky, brute=False)
    _need(data['result']['status'] == 'UNKNOWN', 'swallowed owned refusal remains sticky')
    send('resource-sticky-provider', data)

    for name, change in [('boolean-capacity', 'capacity'), ('duplicate-root', 'root'),
                         ('boolean-t', 't'), ('inconsistent-internal-m', 'm')]:
        bad = _copy(models[2][1], m)
        if change == 'capacity':
            bad['capacity'] = True
        elif change == 'root':
            bad['roots'].append('r')
        elif change == 't':
            bad['inventory']['placements'][0]['t'][0][1] = True
        else:
            bad['inventory']['placements'][0]['m'] = [['remote', '0'], ['remote', '1']]
        expect_error('malformed-' + name, bad, engine.InputError)

    P, Q, G = ['pred', 'P', []], ['pred', 'Q', []], ['pred', 'G', []]
    tiny = [('zero-aliases', {'p0': P, 'p1': P}, P, 0),
            ('unary-generalize', {'p': P}, ['all', 'x', P], 1),
            ('binary-mp', {'p': P, 'pq': ['imp', P, Q]}, Q, 1),
            ('duplicated-subtree', {'p': P, 'pq': ['imp', P, Q],
                                     'qqg': ['imp', Q, ['imp', Q, G]]}, G, 3)]
    tree_records = []
    for name, axioms, goal, depth in tiny:
        compiled, generation = _tiny_catalogue(axioms, goal, m)
        counts['adapter.make_provider'] += 1
        model, provider, factory = adapter.make_provider(compiled, generation, depth, dict(ADAPTER_LIMITS))
        checked = verify_factory(compiled, generation, depth, model, factory)
        _need(checked['status'] == 'VERIFIED', 'complete independent adapter factory')
        data = _catalogue(compiled, m)
        sites = [''.join(bits) for level in range(depth + 1) for bits in itertools.product('01', repeat=level)]
        universe = []
        packets = []
        for point in sites:
            m.tick()
            packet = provider(point, m.tick)
            checked_packet = verify_incident(compiled, depth, point, packet)
            _need(checked_packet['status'] == 'VERIFIED', 'all own/parent contacts')
            packets.append({'point': point, 'packet': packet, 'independent': checked_packet})
            for definition in data['ordered']:
                if not data['definitions'][definition][1] or len(point) < depth:
                    universe.append(_binding(data, depth, point, definition, m))
        record = run(None, model, universe, provider, brute=False)
        _need(record['result']['status'] == 'SAT', 'tiny rooted proof exists')
        counts['adapter.decode'] += 1
        decoded = adapter.decode(compiled, depth, record['result']['selected'], dict(ADAPTER_LIMITS))
        selected_check = verify_tree(compiled, depth, record['result']['selected'], decoded)
        _need(selected_check['status'] == 'VERIFIED', 'whole point tree proof')
        counts['tree_control'] += 1
        control = tree_control(compiled, depth)
        _need(control['status'] == 'DERIVABLE', 'matched-depth complete control')
        control_check = verify_tree(compiled, depth, control['details']['selected'])
        _need(control_check['status'] == 'VERIFIED', 'whole independently searched control tree')
        if name == 'duplicated-subtree':
            _need(control['details']['minimum_tree_nodes'] == 9, 'expanded duplicate-subtree cost')
        problem = {'theory': compiled['theory'], 'goal': goal}
        record.update({'compiled': compiled, 'generation': generation, 'depth': depth, 'factory': factory,
                       'factory_audit': checked, 'all_site_packets': packets,
                       'decoded': decoded, 'selected_audit': selected_check, 'control': control,
                       'control_audit': control_check,
                       'fixture_scope': 'Literal synthetic structural catalogue; not a full Y zero-generation test.',
                       'native_certificates': [{'label': name + '-point', 'problem': problem, 'proof': selected_check['proof']},
                                               {'label': name + '-control', 'problem': problem, 'proof': control['proof']}]})
        send('tree-' + name, record)
        tree_records.append(record)

    exemplar = tree_records[2]
    mutations = []
    graph = completed[6]
    for kind in ('edge-count', 'remote-dependency', 'assigned-zero', 'boolean-total', 'root-generation', 'eligible'):
        original = graph['result']['final_state'] if kind == 'assigned-zero' else graph['result']['entry_state']
        badstate = _copy(original, m)
        if kind == 'edge-count':
            badstate['edge_count'] += 1
        elif kind == 'remote-dependency':
            badstate['dependencies']['m'] = []
        elif kind == 'assigned-zero':
            badstate['marks'][0][1] = ''
        elif kind == 'boolean-total':
            badstate['totals'][0][1] = True
        elif kind == 'root-generation':
            badstate['Q'][0][1] = 1
        else:
            badstate['eligible'].pop()
        answer = verify_state(graph['model'], badstate)
        _need(answer['status'] == 'REJECTED', 'full raw graph mutation rejected')
        mutations.append({'kind': kind, 'state': badstate, 'receipt': answer})
    for kind in ('missing-child', 'duplicate-producer', 'disconnected', 'wrong-definition'):
        bad = list(exemplar['result']['selected'])
        if kind == 'missing-child':
            bad.pop()
        elif kind == 'duplicate-producer':
            bad.append(bad[0])
        elif kind == 'disconnected':
            site, definition = json.loads(bad[0])
            bad[0] = _cid('1' + site, definition, m)
        else:
            site, _ = json.loads(bad[0])
            bad[0] = _cid(site, '["zero","i999"]', m)
        answer = verify_tree(exemplar['compiled'], exemplar['depth'], bad)
        _need(answer['status'] == 'REJECTED', 'selected tree forgery rejected')
        mutations.append({'kind': kind, 'selected': bad, 'receipt': answer})
    bad = _copy(exemplar['all_site_packets'][0]['packet'], m)
    bad['placements'].pop()
    answer = verify_incident(exemplar['compiled'], exemplar['depth'], '', bad)
    _need(answer['status'] == 'REJECTED', 'complete inventory mutation')
    mutations.append({'kind': 'missing-contact', 'packet': bad, 'receipt': answer})
    for name, limits in [('work-zero', dict(CONTROL_LIMITS, max_work=0)),
                         ('proof-output-zero', dict(CONTROL_LIMITS, max_proof_lines=0))]:
        answer = tree_control(exemplar['compiled'], exemplar['depth'], limits)
        counts['tree_control'] += 1
        _need(answer['status'] == 'UNKNOWN' and answer['proof'] is None, 'control resource UNKNOWN')
        mutations.append({'kind': name, 'receipt': answer})
    _need(tree_control(exemplar['compiled'], 0)['status'] == 'NOT_DERIVABLE', 'finite depth boundary, not unrestricted negative')
    counts['tree_control'] += 1
    send('data-forgeries-and-control-bounds', {'records': mutations, 'order_requests': requests,
                                             'native_certificates': []})
    _need(counts['engine.solve'] == 40 and counts['emissions'] == 41
          and counts['native_certificates'] == 8 and counts['adapter.make_provider'] == 4
          and counts['adapter.decode'] == 4 and counts['tree_control'] == 7, 'closed call/emission census')
    return {'status': 'PASS', 'version': VERSION, 'counts': counts, 'records': names,
            'costs': m.costs(), 'scope': SCOPE}
