import pathlib,json,gzip,hashlib,collections
IP=pathlib.Path('/private/tmp/gcts-indexed-producers-20261028-v1');R=IP/'root';O=R/'report-output-001';A=IP/'actual/study-002';D=pathlib.Path('/private/tmp/gcts-L-IP-final-reader-content-peer-v1')
def txt(x):return json.dumps(x,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)
def sha(x):return hashlib.sha256((txt(x)+'\n').encode()).hexdigest()
def ref(p):
 p=pathlib.Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def load(p):return json.loads(pathlib.Path(p).read_bytes())
def guard(x):assert ref(x['path'])==x;return pathlib.Path(x['path']).read_bytes()
def artifact(x):
 b=guard(x['stored']);b=gzip.decompress(b) if x['encoding']=='gzip-json' else b;assert len(b)==x['raw_bytes'] and hashlib.sha256(b).hexdigest()==x['raw_sha256'];return json.loads(b)
def put(n,v):
 p=D/n;assert not p.exists();p.write_text(json.dumps(v,sort_keys=True,ensure_ascii=True,indent=2)+'\n');return ref(p)
H=O/'indexed-proof-search-v1.html';J=O/'indexed-proof-search-results-v1.json';report=load(J);reader=report['reader'];ob=load(A/'observer-result.json');worker=artifact(ob['worker_terminal']['result']);exp=worker['experiment'];plan=load(ob['worker_terminal']['plan']['path']);manifest=load(plan['metadata']['frozen_inputs']['path']);inputs={z['name']:z for z in manifest['inputs']};all83={z['name']:artifact(z) for z in worker['artifacts']}
assert len(all83)==83 and len(reader['cases'])==15 and report['design']==exp['design'] and report['limits']==exp['design']['limits']
assert H.read_bytes()==(R/'indexed-proof-reader-template-v2.html').read_bytes()
assert ref(H)['sha256']=='aa60a242e906a3bec7f05ef87681fe4ef7fbe0024350805667cc8103a547d6bc' and ref(J)['sha256']=='7fd47b990a9037209fdd59b658717b5e5d3ec40644313216c44e407cd1b010ec'
prov=reader['provenance'];assert prov['observer']==ref(A/'observer-result.json') and prov['plan']==ob['worker_terminal']['plan'] and prov['scope']==exp['scope']
for k in ['observer','plan','qualification_admission','scientific_admission']:guard(prov[k])
assert load(prov['scientific_admission']['path'])['status']==load(prov['qualification_admission']['path'])['status']=='ADMITTED'
qqual=load(prov['qualification_admission']['path']);assert all(qqual['sources'][k]==plan['sources'][k] for k in ['engine_indexed','adapter_indexed','qualifier'])
bankrec=artifact(inputs['current-bank-and-native-checks']);bank=bankrec['result']['value'];assert reader['bank']==bank['lemmas'];lemmas={x['name']:x for x in bank['lemmas']}
counts={l:dict(verified=0,unknown=0,finite_exhausted=0,search_seconds=0.0,candidate_registrations=0,provider_rows=0,potential_rows=0,omitted_rows=0) for l in exp['design']['lanes']}
case_support=[];bindings=[];sources=[];proofs=collections.Counter();common=[]
for case,row in zip(reader['cases'],exp['results']):
 cid=row['id'];prep=artifact(inputs[cid+'-whole-preparation']);assert case['id']==cid and case['problem']==row['original']==prep['original'] and case['depth']==row['depth']==8 and case['lemma_bindings']==prep['application']['lemma_bindings']
 assert case['group']==('Arithmetic' if '-arith-' in cid else 'Typing' if '-typing-' in cid else 'Incidence')
 per=[]
 for lane,compact in row['lanes'].items():
  full=artifact(compact['ref']);v=case['lanes'][lane];sources.append(compact['ref']);yes=full['verified'];p=full.get('positive',{});assurance=lane=='MATCHED_DEPTH_TREE_CONTROL' or full.get('factory_audit',{}).get('status')=='VERIFIED'
  expected=dict(status=full['status'],reason=full.get('reason'),original_status='VERIFIED' if yes else 'UNKNOWN_FACTORY_AUDIT' if not assurance else p.get('reason','NO_CERTIFICATE'),seconds=full['search_seconds'],coarse_proof=p.get('coarse_proof',[]) if yes else [],original_proof=p.get('original_proof',[]) if yes else [],tree=p.get('decoded',{}).get('tree') if yes else None,checks={k:p.get(k) for k in ['tree_audit','coarse_host_check','original_host_check','lowering_audit']},lowering=p.get('lowering') if yes else None,source_ref=compact['ref'],stats=(full.get('result') or {}).get('stats',{}),provider=full.get('provider',{}))
  assert v==expected
  c=counts[lane];negative=full['status'] in ['UNSAT','NOT_DERIVABLE'] and assurance;c['verified']+=int(yes);c['finite_exhausted']+=int(negative);c['unknown']+=int(not yes and not negative);c['search_seconds']+=full['search_seconds']
  for k in ['candidate_registrations','provider_rows']:c[k]+=v['stats'].get(k,0)
  for k in ['potential_rows','omitted_rows']:c[k]+=v['provider'].get(k,0)
  per.append(dict(lane=lane,status=v['status'],original_status=v['original_status'],seconds=v['seconds'],coarse_lines=len(v['coarse_proof']),original_lines=len(v['original_proof']),source=compact['ref']))
  if yes:
   assert all(v['checks'][k]['status']=='VERIFIED' for k in v['checks'])
   assert artifact(p['ref'])=={k:z for k,z in p.items() if k!='ref'}
   assert v['coarse_proof']==v['checks']['tree_audit']['proof'] and v['original_proof']==v['lowering']['value']['proof']
   assert v['coarse_proof'][-1]['formula']==v['original_proof'][-1]['formula']==case['problem']['goal']
   tree=v['tree'];cp=v['coarse_proof'];by=dict(tree['site_to_line']);assert len(cp)==tree['node_count']==len(tree['placements']) and by['']==len(cp)-1
   assert tree['placements']==v['checks']['tree_audit']['details']['candidate_bindings'] and tree['site_to_line']==v['checks']['tree_audit']['details']['site_to_line']
   for pl in tree['placements']:
    site,di=json.loads(pl['id']);line=cp[by[site]];mm=dict(pl['m']);assert json.loads(mm[site])==line['formula'] and all(n==1 and pt in mm for pt,n in pl['t'])
    if line['rule']=='mp':assert by[site+'0']==line['antecedent'] and by[site+'1']==line['implication']
    if line['rule']=='generalize':assert by[site+'0']==line['source']
    imported=line['rule']=='axiom' and line.get('name') in {z['name'] for z in case['lemma_bindings']}
    if imported:assert line['formula']==lemmas[line['name']]['goal']
    bindings.append(dict(case=cid,lane=lane,site=site,line=by[site],id=pl['id'],t=pl['t'],m=pl['m'],formula_sha256=sha(line['formula']),actual_imported_axiom=imported,view='GCTS_ACTUAL' if lane!='MATCHED_DEPTH_TREE_CONTROL' else 'CONTROL_ALLOWED_REALIZATION'))
   proofs['positive_pairs']+=1;proofs['coarse_lines']+=len(cp);proofs['original_lines']+=len(v['original_proof']);proofs['actual_point_nodes' if lane!='MATCHED_DEPTH_TREE_CONTROL' else 'control_realized_nodes']+=len(cp)
  else:assert v['coarse_proof']==v['original_proof']==[] and v['tree'] is None
 ce=case['lanes']['EAGER_POINT_LEX'];ci=case['lanes']['INDEXED_POINT_LEX']
 if ce['original_proof']:
  assert ci['coarse_proof']==ce['coarse_proof'] and ci['original_proof']==ce['original_proof'] and ci['tree']==ce['tree'];common.append(dict(case=cid,eager_seconds=ce['seconds'],indexed_seconds=ci['seconds']))
 case_support.append(dict(case=cid,group=case['group'],goal=case['problem']['goal'],lemma_bindings=case['lemma_bindings'],lanes=per))
assert counts==reader['counts'] and prov['full_lane_records']==sources and len(sources)==45 and len(common)==5
assert proofs==dict(positive_pairs=22,coarse_lines=255,original_lines=309,actual_point_nodes=179,control_realized_nodes=76)
assert len(bindings)==255
ea=sum(v['eager_seconds'] for v in common);ix=sum(v['indexed_seconds'] for v in common);assert abs(ea-1.5636566240282264)<1e-12 and abs(ix-0.27096020901808515)<1e-12
common_note=f"On the {len(common)} targets verified by both point engines, the selected coarse proofs are identical. Their total cold factory+search times are {ea:.4f} seconds eager and {ix:.4f} seconds indexed. This is one fixed-order regression run, not a repeated timing study."
assert common_note in reader['cost_notes']
failure=prov['failed_attempt'];guard(failure['original_exit']);guard(failure['observer']);fo=load(failure['observer']['path']);assert fo['status']=='UNADMITTED' and fo['returncode']==1
failure_note=f"An initial attempt stopped at an artifact-filename guard before the first whole lane was saved. It is unadmitted and retained separately: {fo['whole_observer_seconds']:.4f} seconds, peak {fo['wait4_peak_bytes']} bytes. The reporting-label fix changes no search inventory or budgets; all 45 positions above belong to the later complete attempt."
assert failure_note in reader['cost_notes']
assert f"New observer wall time: {ob['whole_observer_seconds']:.3f} seconds; fresh child peak RSS: {ob['wait4_peak_bytes']} bytes." in reader['cost_notes']
for lane,v in counts.items():
 note=f"{lane}: total cold search {v['search_seconds']:.4f} seconds, {v['verified']} verified, {v['finite_exhausted']} finite-depth exhausted, {v['unknown']} unknown; {v['candidate_registrations']} candidate registrations and {v['provider_rows']} returned provider rows."
 assert note in reader['cost_notes']
expected_findings=[f"Indexed GCTS verified 8 targets; unchanged eager GCTS verified 5; the matched proof-tree control verified 9. All 45 method positions are retained.", 'Each displayed successful proof was reconstructed independently, expanded through the certified lemma bank, and checked in the original theory. No hand-written target proof was fed to search.', 'These are the same fifteen previously studied regression assertions. This experiment changes enumeration cost, not the logical inventory or theorem difficulty.']
capcase=reader['cases'][-1];ci=capcase['lanes']['INDEXED_POINT_LEX'];cc=capcase['lanes']['MATCHED_DEPTH_TREE_CONTROL'];assert ci['original_status']=='VERIFIED' and cc['status']=='UNKNOWN' and cc['reason']=='WALL'
expected_findings.append(f"On {capcase['id']}, indexed GCTS finished in {ci['seconds']:.4f} seconds while the control stopped unknown in {cc['seconds']:.4f} seconds. Both are near the nominal two-second boundary; this isolated budget win does not establish reliable superiority.")
assert expected_findings==reader['findings']
html=H.read_text();old=(R/'indexed-proof-reader-template-v1.html').read_text()
# All script/style/proof-renderer behavior is inherited exactly. The only T2 addition is caps prose.
assert html[html.rindex('<script>'):]==old[old.rindex('<script>'):]
assert 'Reported search times include cleanup tails, which can exceed the nominal cooperative window' in html
for phrase in ['10{,}000','50{,}000','1{,}024','10^9','not logical restrictions','not a wall-time-only experiment','Native C1 checks belong to the earlier admitted experiment','finite-depth control negative does not establish unrestricted nonprovability','no invented base placement IDs','it was not found by GCTS']:
 assert phrase in html
caps=report['limits']['point'];assert (caps['max_candidates'],caps['max_nodes'],caps['max_points'],caps['max_work'])==(10000,50000,1024,1000000000)
assert 'Full first-order expressiveness in a single fixed tile set and useful learned hierarchies remain open.' in reader['assessment'][-1]
mathref=pathlib.Path('/private/tmp/gcts-L-IP-study002-mathematical-review-v1/IP-study002-complete-independent-passive-mathematical-review-v1.json');assert load(mathref)['status']=='PASS'
support=put('IP-final-reader-complete-independent-passive-content-support-v1.json',dict(schema='IP-final-reader-complete-independent-passive-content-support-v1',status='PASS',HTML=ref(H),results=ref(J),materializer=ref(R/'materialize_indexed_report_v3.py'),template=ref(R/'indexed-proof-reader-template-v2.html'),root_admission=prov['scientific_admission'],inherited_whole_mathematical_review=ref(mathref),all_15_case_and_45_lane_joins=case_support,all_255_tile_site_mark_bindings=bindings,all_45_full_lane_sources=sources,counts=counts,proof_counts=dict(proofs),common5=common,common_eager_seconds=ea,common_indexed_seconds=ix,qualification_summary=reader['qualification_summary'],findings=reader['findings'],cost_notes=reader['cost_notes'],failed_attempt=failure,scope='All final projected values/fullproofs/sitebindings compared with complete admitted saved records. No renderer, JS, scientific Source/helper, prover or kernel executed. Browser QA remains Root-owned.'))
review=put('IP-final-reader-complete-independent-passive-content-review-v1.json',dict(schema='IP-final-reader-complete-independent-passive-content-review-v1',status='PASS',blockers=[],HTML=ref(H),results=ref(J),support=support,materializer=ref(R/'materialize_indexed_report_v3.py'),template=ref(R/'indexed-proof-reader-template-v2.html'),scientific_admission=prov['scientific_admission'],
 complete_projection=dict(cases=15,method_positions=45,positive_coarse_original_pairs=22,actual_GCTS_point_views=13,actual_GCTS_point_nodes=179,control_realization_views=9,control_realization_nodes=76,all_tile_site_mark_bindings=255,coarse_proof_lines=255,original_overlay_lines=309),
 checks=['All45rawlane/fullpositive refs re-read and full stored/raw hashes joined. Every case/theory/goal/depth/eligiblelemma binding, rawstatus/reason, assurance status, cost, stats, provider telemetry and all four actual checks match exactly; no nonpositive tree/proof is invented.','All255selected/realized producer rows, literal CIDs, sites, half-capacity t rows, full literal m colors, tree postorder and MP/GEN premise ports exactly bind actual saved decoder/tree certificates. Imported green glyphs are determined only by actual imported axiom rows and eligible exact lemma names.','Every one of255coarse and309original proof lines is exact saved data. Original views are explicitly logical overlays without invented base-placement IDs. Point vs conventional-control realization attribution is explicit.','All outcome and cumulative cost tables exactly cover15perlane. Eager5/indexed8/control9verified,7indexedMAX_WORK and other unresolved/finite outcomes remain intact. Raw design and actual resource limits are present in JSON; LaTeX caps paragraph matches10kregistered/50knodes/1024points/1bwork and explains operational rather than semantic restrictions.','Five common GCTS proofs and trees are byte-identical, with exact shared-case cold sums1.5636566240282264s eager versus0.27096020901808515s indexed. The prose labels this fixed-order single regression observation, while full-cohort totals12.8465s indexed/11.7319s eager/6.0623s control are also disclosed.','Capture-sensitive indexed1.9891sSAT versus control2.0121sWALL is labelled an isolated near-budget difference, not reliable superiority. Five finite-depth negatives are never stated as original-theory nonprovability.','Failed001native1/cause/cost/provenance remain separately UNADMITTED. Main002alone supplies the displayed45positions. Reused catalogue57.3463s/donor61.1110s and new62.7545s/410845184B observer costs are separately attributed.','Current fresh coarse/original host checks are distinguished from historical C1. No new C1,RL,theorem novelty,fullPA/Hilbert,universal Wang-palette or broad prover-superiority claim appears.','Complete inherited HTML/CSS/JS formula/English/LaTeX rendering reviewed; direct quantified operands retain whole grouping and GEN English variable math. Template2changes only caps prose; actual saved HTML equals that template byte-for-byte. Rooted growth and immutable-index monotonicity/rollback conditions are explicit.','Complete current observer/plan/admission/failure provenance pins match; both qualification and scientific admissions are ADMITTED and bind actual current modules.'],
 limitations=['This is final saved content/data review, not browser execution or a new scientific/nativekernel validation. Root owns final MathJax/layout/premise navigation UI checks.','Main trace prefixes remain prefixes, not a reconstructed full transition history. Full source originals remain archive-linked.','The mathematical result remains a finite fixed-depth known-regression engineering comparison; strong control has greater whole-cohort coverage and lower total search time.'],
 activity=dict(renderer_or_JS_calls=0,project_Source_helper_kernel_replay=0,network_Git_calls=0,evidence_mutations=0,writes='Only separate passive review/support; tools idle after receipt.')))
print(json.dumps(dict(review=review,support=support,proof_counts=dict(proofs),common_sums=[ea,ix]),sort_keys=True))
