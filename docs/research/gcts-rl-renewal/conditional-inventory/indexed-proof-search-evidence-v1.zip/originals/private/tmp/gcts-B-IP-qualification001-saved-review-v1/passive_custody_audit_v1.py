"""Saved bytes/JSON/gzip/hash joins only. No project imports or replay."""
from pathlib import Path
import gzip
import hashlib
import json
import stat
from collections import Counter

R=Path('/private/tmp/gcts-indexed-producers-20261028-v1')
D=R/'actual/qualification-001'
OUT=Path('/private/tmp/gcts-B-IP-qualification001-saved-review-v1')


def canonical(x):return (json.dumps(x,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')
def sha(b):return hashlib.sha256(b).hexdigest()
def parse(b):
 def pairs(xs):
  d={}
  for k,v in xs:
   assert k not in d;d[k]=v
  return d
 def bad(x):raise ValueError('nonfinite')
 return json.loads(b,object_pairs_hook=pairs,parse_constant=bad)
def ref(p):
 p=Path(p);assert p.resolve()==p and not p.is_symlink();s=p.stat(follow_symlinks=False);assert stat.S_ISREG(s.st_mode) and s.st_nlink==1
 b=p.read_bytes();a=p.stat(follow_symlinks=False);assert (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)==(a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns) and len(b)==s.st_size
 return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
checked={}
def checkref(x):
 assert set(x)=={'path','bytes','sha256'} and type(x['path'])is str and type(x['bytes'])is int and type(x['sha256'])is str
 r=ref(x['path']);assert r==x;checked[x['path']]=r
 return Path(x['path']).read_bytes()
def refs(x):
 if type(x)is dict:
  if set(x)=={'path','bytes','sha256'}:yield x
  else:
   for v in x.values():yield from refs(v)
 elif type(x)is list:
  for v in x:yield from refs(v)

def main():
 obs=parse((D/'observer-result.json').read_bytes());worker=parse((D/'worker-result.json').read_bytes());plan_path=R/'root/qualification-once-plan-001.json';plan=parse(plan_path.read_bytes());planref=ref(plan_path)
 physical=[ref(p) for p in sorted(D.iterdir())];assert len(physical)==31
 assert sum(v['bytes'] for v in physical)==428193
 observed={v['path']:v for v in obs['files']};assert len(observed)==30 and set(observed)=={v['path'] for v in physical if not v['path'].endswith('/observer-result.json')}
 for r in observed.values():checkref(r)
 assert sum(v['bytes'] for v in observed.values())==obs['stored_bytes']==419937
 assert obs['status']=='COMPLETE' and obs['returncode']==0 and obs['failure']is None and obs['cleanup_errors']==[]
 assert obs['both_streams_EOF']is True and obs['wait_confirmed']is True and obs['group_gone']is True
 assert obs['retained_streams_complete']=={'stdout':True,'stderr':True}
 for label in ['stdout','stderr']:
  raw=checkref(obs['streams'][label]);assert len(raw)==obs['observed_stream_bytes'][label]
 assert obs['observed_stream_bytes']=={'stdout':698,'stderr':0}
 terminal=parse((D/'stdout.bin').read_bytes());assert terminal==obs['worker_terminal'] and terminal['status']=='COMPLETE' and terminal['plan']==planref
 assert terminal['result']['stored']==ref(D/'worker-result.json') and terminal['public_calls']=={'experiment.run':1,'qualifier.qualify':1}
 assert worker['status']=='COMPLETE' and worker['outer_public_calls']==terminal['public_calls']
 for q in refs(plan):checkref(q)
 assert len(plan['sources'])==11 and len(plan['metadata'])==14
 assert obs['stdin_bytes_sent']==plan['sources']['runner']['bytes']==19236
 command=[plan['python']['path'],'-I','-S','-B',plan['bootstrap']['path'],plan['sources']['runner']['path'],'19236',plan['sources']['runner']['sha256'],'--mode','worker','--plan',str(plan_path)]
 assert obs['command']==command and plan['actual_dir']==str(D)
 assert obs['whole_observer_seconds']<plan['limits']['observer_seconds'] and terminal['elapsed_seconds']<plan['limits']['worker_seconds'] and obs['wait4_peak_bytes']<plan['limits']['rss_bytes']
 assert len(physical)<plan['limits']['max_files'] and sum(v['bytes'] for v in physical)<plan['limits']['total_bytes'] and max(v['bytes'] for v in physical)<plan['limits']['file_bytes']
 authority_path=R/'root/qualification-once-authority-001.json';a=parse(authority_path.read_bytes());aref=ref(authority_path);spent_path=Path(str(authority_path)+'.CONSUMED.json');spent=parse(spent_path.read_bytes());consumed=parse((D/'CONSUMED.json').read_bytes())
 assert a['authorized']is True and type(a['uses'])is int and a['uses']==1 and a['plan']==planref and a['runner']==plan['sources']['runner'] and a['python']==plan['python']
 assert spent=={'authority':aref,'plan':planref,'status':'SPENT'} and consumed=={'authority':aref,'consumed':ref(spent_path)}
 original_path=R/'root/qualification-001.original-tool-exit-v1.json';original=parse(original_path.read_bytes());assert original['native_exit']==0 and original['chunk_id']=='3ff603' and original['original_call']=='/bin/sh '+str(R/'root/qualification-001.caller.sh')
 for v in refs(original):checkref(v)
 outer=parse((R/'root/qualification-001.outer-stdout.bin').read_bytes());assert outer=={'receipt':ref(D/'observer-result.json'),'status':'COMPLETE'} and (R/'root/qualification-001.outer-stderr.bin').read_bytes()==b''
 caller_path=R/'root/qualification-001.caller.sh';caller=caller_path.read_text();assert 'set -C\n' in caller and 'set -eu\n' in caller and 'umask 077\n' in caller and '$(' not in caller and '`' not in caller
 expected='exec '+' '.join(command[:-4]+['--mode','observer','--plan',str(plan_path),'--authority',str(authority_path)])+' < '+plan['sources']['runner']['path']+' > '+str(R/'root/qualification-001.outer-stdout.bin')+' 2> '+str(R/'root/qualification-001.outer-stderr.bin')
 assert expected in caller
 adopt_path=R/'root/Root-qualification001-concrete-caller-adoption-v1.json';adopt=parse(adopt_path.read_bytes())
 for v in refs(adopt):checkref(v)
 arts=[];objects=[];results=[];observations=[];captured=[];native=[];faults=[];mutation_count=0
 for desc in worker['artifacts']:
  stored=checkref(desc['stored']);raw=gzip.decompress(stored) if desc['encoding']=='gzip-json' else stored
  assert desc['encoding'] in ('gzip-json','json') and len(raw)==desc['raw_bytes'] and sha(raw)==desc['raw_sha256']
  obj=parse(raw);assert canonical(obj)==raw;objects.append(obj)
  for v in refs(obj):checkref(v)
  arts.append({'descriptor':desc,'raw_canonical_JSON':True})
  for lane in ('indexed','eager'):
   if lane in obj:
    v=obj[lane];assert v['independent']['status']=='VERIFIED';results.append((desc['name']+'/'+lane,v['result']))
    observations.extend(v['observations']);captured.extend(v['query_captures'])
   proofkey=lane+'_proof'
   if proofkey in obj:
    p=obj[proofkey];assert p['host_FOL']['status']=='VERIFIED' and p['host_FOL']['checked_lines']==len(p['decoded']['proof']) and sum(p['host_FOL']['rule_counts'].values())==len(p['decoded']['proof'])
    assert p['decoded']['tree']['selected']==obj[lane]['result']['selected']
  if 'answer' in obj:
   v=obj['answer'];assert v['independent']['status']=='VERIFIED';results.append((desc['name'],v['result']));observations.extend(v['observations']);captured.extend(v['query_captures'])
  if 'observations' in obj:observations.extend(obj['observations'])
  if 'query_captures' in obj:captured.extend(obj['query_captures'])
  if 'actual_exception' in obj:
   assert obj['actual_exception']==obj['expected_exception'] and obj['no_post_exception_state_claim']is True;faults.append({'case':desc['name'],'exception':obj['actual_exception']})
  if 'mutations' in obj:
   mutation_count=len(obj['mutations']);assert all(v['independent']['status']=='REJECTED' for v in obj['mutations'])
  for cert in obj['native_certificates']:
   p=obj[cert['label']+'_proof'];assert cert['proof']==p['decoded']['proof'] and cert['problem']['goal']==p['decoded']['target'];native.append({'case':desc['name'],'label':cert['label'],'proof_sha256':sha(canonical(cert['proof'])),'problem_sha256':sha(canonical(cert['problem'])),'lines':len(cert['proof']),'host_receipt':p['host_FOL']})
 assert len(arts)==26 and len(results)==37 and len(faults)==4 and len(observations)==191 and len(captured)==38 and len(native)==6
 assert worker['experiment']['counts']['engine_indexed.solve']==25 and worker['experiment']['counts']['engine_eager.solve']==16 and worker['experiment']['counts']['fol_checker.check']==6
 assert worker['experiment']['records']==26 and worker['experiment']['observations']==191 and worker['experiment']['captured_queries']==38 and worker['experiment']['native_certificates']==6
 assert worker['experiment']['emitted_names']==[v['name'] for v in worker['artifacts']]
 answer_rows=[];state_hash_count=0;event_rows=rollback_rows=query_rows=0
 for name,res in results:
  assert res['schema']=='Z-growing-point-search-result-v1'
  for label,key in [('entry','entry_state'),('final','final_state'),('restored','restored_state')]:
   if res[key]is not None:assert res['state_hashes'][label]==sha(canonical(res[key]));state_hash_count+=1
  if res['entry_state']is not None:assert res['restored_state']==res['entry_state'] and res['state_hashes']['restored']==res['state_hashes']['entry']
  if res['status']=='UNKNOWN':assert res['selected']==[] and res['certificate']is None and res['final_state']is None
  for rows_key,extent_key in [('events','event_extent'),('rollback_records','rollback_extent')]:
   rows=res[rows_key];ex=res[extent_key];assert ex['retained']==len(rows) and ex['total']==len(rows)
   assert ex['sha256']==sha(b''.join(canonical(v) for v in rows))
  event_rows+=len(res['events']);rollback_rows+=len(res['rollback_records'])
  if 'provider_evidence'in res:
   pe=res['provider_evidence'];assert pe['total']==pe['retained']==len(pe['records']) and pe['sha256']==sha(b''.join(canonical(v) for v in pe['records']))
   for q in pe['records']:assert q['reply']['context_sha256']==sha(canonical(q['query']))
   query_rows+=len(pe['records'])
  answer_rows.append({'case_lane':name,'status':res['status'],'reason':res['reason'],'result_sha256':sha(canonical(res)),'state_hashes':res['state_hashes'],'events':len(res['events']),'rollbacks':len(res['rollback_records'])})
 support={'schema':'IP-Q001-independent-passive-custody-support-v1','physical_files':physical,'all_observer_manifest_files':list(observed.values()),'artifacts':arts,'all_checked_rawrefs':list(checked.values()),'answer_bindings':answer_rows,'observation_state_hashes':[sha(canonical(v['state'])) for v in observations],'native_host_proof_bindings':native,'faults':faults,'data_mutations':mutation_count,'plan':ref(plan_path),'authority':aref,'Root_spent':ref(spent_path),'actual_consumed':ref(D/'CONSUMED.json'),'caller':ref(caller_path),'Root_caller_adoption':ref(adopt_path),'original_exit':ref(original_path),'outer_stdout':ref(R/'root/qualification-001.outer-stdout.bin'),'outer_stderr':ref(R/'root/qualification-001.outer-stderr.bin'),'observer':ref(D/'observer-result.json'),'worker':ref(D/'worker-result.json'),'counters':{'physical_files':len(physical),'physical_stored_bytes':sum(v['bytes'] for v in physical),'observer_prefinal_files':len(observed),'observer_prefinal_stored_bytes':obs['stored_bytes'],'emitted_artifacts':len(arts),'emitted_raw_bytes':sum(v['descriptor']['raw_bytes'] for v in arts),'all_artifact_raw_including_worker':sum(v['descriptor']['raw_bytes'] for v in arts)+ref(D/'worker-result.json')['bytes'],'returned_answers':len(results),'fault_solves':len(faults),'all_solve_calls':41,'result_statuses':dict(Counter(v['status'] for _,v in results)),'complete_observations':len(observations),'captured_queries_including_expected_fault':len(captured),'validated_query_evidence_records':query_rows,'result_state_hashes':state_hash_count,'complete_event_rows':event_rows,'complete_rollback_rows':rollback_rows,'host_FOL_checks':len(native),'host_checked_lines':sum(v['lines'] for v in native),'new_native_C1_VM_calls':0},'process':{k:obs[k] for k in ['returncode','wait_confirmed','group_gone','both_streams_EOF','whole_observer_seconds','wait4_peak_bytes','cleanup_errors']},'scope':'Entire qualification saved data custody and structural binding only. No model/graph arithmetic proof or kernel replay; complementary independent L mathematical review required. Fault cases expressly have no post-exception state image claim.'}
 p=OUT/'IP-qualification001-complete-passive-custody-support-v1.json';assert not p.exists();p.write_text(json.dumps(support,sort_keys=True,indent=2)+'\n')
 print(json.dumps({'support':ref(p),'counters':support['counters'],'status':'PASS_COMPLETE_PASSIVE_CUSTODY'},sort_keys=True))


if __name__=='__main__':main()
