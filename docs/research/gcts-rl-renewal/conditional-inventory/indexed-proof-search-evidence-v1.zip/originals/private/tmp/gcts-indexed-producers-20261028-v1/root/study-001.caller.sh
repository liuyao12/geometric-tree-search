#!/bin/sh
set -eu
set -C
umask 077
exec /Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12 -I -S -B /private/tmp/gcts-cluster-receptors-20261027-v2/root/authenticated-source-bootstrap-v1.py /private/tmp/gcts-indexed-producers-20261028-v1/root/indexed_proof_study_once_v1.py 19236 e91266d0eb9f9b97b5ed452779958cf492599b1c1bab260ce4c03d2f91bdec2b --mode observer --plan /private/tmp/gcts-indexed-producers-20261028-v1/root/study-once-plan-001.json --authority /private/tmp/gcts-indexed-producers-20261028-v1/root/study-once-authority-001.json < /private/tmp/gcts-indexed-producers-20261028-v1/root/indexed_proof_study_once_v1.py > /private/tmp/gcts-indexed-producers-20261028-v1/root/study-001.outer-stdout.bin 2> /private/tmp/gcts-indexed-producers-20261028-v1/root/study-001.outer-stderr.bin
