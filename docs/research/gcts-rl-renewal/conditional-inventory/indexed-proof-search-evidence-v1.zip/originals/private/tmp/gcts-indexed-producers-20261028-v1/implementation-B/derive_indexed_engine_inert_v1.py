"""Administrative Source derivation only; never imports/evaluates the engine."""
from pathlib import Path
import difflib
old=Path('/private/tmp/gcts-growing-proof-obligations-20261028-v1/implementation-B/growing_point_search_v1.py')
new=Path('/private/tmp/gcts-indexed-producers-20261028-v1/implementation-B/growing_point_search_v2.py')
s=old.read_text()
s=s.replace("VERSION = 'Z-GROWING-POINT-SEARCH-v1'", "VERSION = 'IP-GROWING-POINT-SEARCH-v2'\nINDEXED_ABI = 'IP-CURRENT-TM-INCIDENT-v1'")
s=s.replace('        self.capacity = model[\'capacity\']\n', '''        self.capacity = model['capacity']
        declared = None if provider is None else getattr(provider, 'incident_query_abi', None)
        _need(declared is None or type(declared) is str and declared == INDEXED_ABI,
              'supported provider incident_query_abi')
        _need(declared is None or model['inventory']['kind'] == 'CERTIFIED_INCIDENT',
              'indexed provider requires certified incident inventory')
        self.indexed = declared is not None
        self.query_records = []
        self.query_count = 0
        self.query_hash = hashlib.sha256()
        self.index_costs = {'query_attempts': 0, 'query_work': 0,
                            'query_seconds': 0.0, 'receipt_work': 0,
                            'potential_contacts': 0, 'returned_contacts': 0,
                            'context_values': 0}
''')
a='''    def _legal(self, row):
        self.stats['legality_checks'] += 1
        self.meter.tick(1 + len(row['t']) + len(row['m']))
        if row['id'] in self.selected or row['id'] in self.excluded:
            return False
        for point, units in row['t']:
            if self.totals.get(point, 0) + units > self.capacity:
                return False
        for point, value in row['m']:
            if point in self.marks and self.marks[point][0] != value:
                return False
        return True
'''
b='''    def _compatible(self, row):
        # Pure t/m predicate. Callers reserve work before traversing supports.
        for point, units in row['t']:
            if self.totals.get(point, 0) + units > self.capacity:
                return False
        for point, value in row['m']:
            if point in self.marks and self.marks[point][0] != value:
                return False
        return True

    def _legal(self, row):
        self.stats['legality_checks'] += 1
        self.meter.tick(1 + len(row['t']) + len(row['m']))
        if row['id'] in self.selected or row['id'] in self.excluded:
            return False
        return self._compatible(row)
'''
assert s.count(a)==1;s=s.replace(a,b)
anchor='    def _load(self, point):\n'
insert='''    def _indexed_reply(self, point):
        """Validate a complete context-compatible query, before certifying load.

        The provider's unseen completeness is an external Source/qualification
        obligation. A true flag/count is not itself a proof of that obligation.
        """
        meter = self.meter
        before_work, before_time = meter.work, time.perf_counter()
        self.index_costs['query_attempts'] += 1
        try:
            count = len(self.totals) + len(self.marks)
            meter.tick(2 + count * (1 + count.bit_length()))
            query = {'schema': 'IP-current-tm-incident-query-v1',
                     'inventory_identity': self.model['inventory']['identity'],
                     'point': point, 'capacity': self.capacity,
                     'totals': [[p, n] for p, n in sorted(self.totals.items())],
                     'marks': [[p, v] for p, (v, n) in sorted(self.marks.items())]}
            encoded_query = _wire(query, meter)
            expected_hash = hashlib.sha256(encoded_query).hexdigest()
            # Callback receives a detached copy; retained query cannot be mutated.
            reply = self.provider(json.loads(encoded_query), meter.tick)
            meter.tick()  # swallowed owned refusal stays sticky
            _fields(reply, ('point', 'context_sha256', 'complete', 'placements',
                            'certificate'), meter, InventoryError)
            _need(_string(reply['point'], meter, error=InventoryError) == point,
                  'indexed response point binding', InventoryError)
            _need(_string(reply['context_sha256'], meter, error=InventoryError)
                  == expected_hash, 'indexed response context binding', InventoryError)
            _need(reply['complete'] is True and type(reply['placements']) is list,
                  'complete indexed response', InventoryError)
            cert = reply['certificate']
            _fields(cert, ('scope', 'potential_count', 'compatible_count'), meter,
                    InventoryError)
            _need(type(cert['scope']) is str
                  and cert['scope'] == 'COMPLETE_CURRENT_TM_COMPATIBLE_INCIDENT_SET'
                  and _integer(cert['potential_count'])
                  and _integer(cert['compatible_count'])
                  and cert['compatible_count'] == len(reply['placements'])
                  and cert['potential_count'] >= cert['compatible_count'],
                  'indexed exact contact-count certificate', InventoryError)
            meter.tick(2 + len(reply['placements']))
            if len(reply['placements']) > meter.limits['max_candidates']:
                meter.stop('MAX_CANDIDATES')
            rows, seen = [], set()
            for value in reply['placements']:
                row = _placement(value, self.capacity, meter, InventoryError)
                meter.tick(1 + len(row['t']) + len(row['m']))
                _need(row['id'] not in seen
                      and any(p == point for p, units in row['t'])
                      and self._compatible(row),
                      'unique incident globally t/m-compatible row', InventoryError)
                seen.add(row['id'])
                rows.append(row)
            normalized = {'point': point, 'context_sha256': expected_hash,
                          'complete': True, 'placements': rows,
                          'certificate': {'scope': cert['scope'],
                                          'potential_count': cert['potential_count'],
                                          'compatible_count': cert['compatible_count']}}
            self.index_costs['potential_contacts'] += cert['potential_count']
            self.index_costs['returned_contacts'] += len(rows)
            self.index_costs['context_values'] += count
        finally:
            self.index_costs['query_work'] += meter.work - before_work
            self.index_costs['query_seconds'] += time.perf_counter() - before_time
        record = {'query': query, 'reply': normalized}
        before_receipt = meter.work
        try:
            encoded = _wire(record, meter)
        finally:
            self.index_costs['receipt_work'] += meter.work - before_receipt
        self.query_hash.update(encoded)
        self.query_count += 1
        if len(self.query_records) < meter.limits['max_events']:
            self.query_records.append(record)
        return rows

    def provider_evidence(self):
        mode = ('EXPLICIT' if self.model['inventory']['kind'] == 'EXPLICIT' else
                'INDEXED_CURRENT_TM_COMPATIBLE' if self.indexed else
                'EAGER_ALL_POTENTIAL')
        return {'mode': mode, 'total': self.query_count,
                'retained': len(self.query_records),
                'sha256': self.query_hash.hexdigest(),
                'scope': 'BOUNDED_PREFIX_OF_COMPLETED_VALIDATED_INDEX_QUERIES',
                'records': list(self.query_records), 'costs': dict(self.index_costs)}

'''
assert s.count(anchor)==1;s=s.replace(anchor,insert+anchor)
a='''            reply = self.provider(point, self.meter.tick)
            self.meter.tick()  # refusal remains sticky if callback swallowed it
            _fields(reply, ('point', 'complete', 'placements'), self.meter, InventoryError)
            response_point = _string(reply['point'], self.meter, error=InventoryError)
            _need(response_point == point
                  and reply['complete'] is True and type(reply['placements']) is list,
                  'complete state-independent incident response', InventoryError)
            count = len(reply['placements'])
            self.meter.tick(2 + count)
            seen = set()
            for value in reply['placements']:
                row = _placement(value, self.capacity, self.meter, InventoryError)
                self.meter.tick(1 + len(row['t']))
                _need(any(p == point for p, units in row['t']) and row['id'] not in seen,
                      'unique incident placement required', InventoryError)
                seen.add(row['id'])
                self.stats['provider_rows'] += 1
                self._register(row)
            self.meter.tick(1 + len(seen) + len(self.tdep.get(point, ())))
            _need(seen == self.tdep.get(point, set()),
                  'provider omitted already known incident placement', InventoryError)
'''
b='''            if self.indexed:
                rows = self._indexed_reply(point)
                seen = set()
                for row in rows:
                    self.meter.tick(1 + len(row['t']))
                    seen.add(row['id'])
                    self.stats['provider_rows'] += 1
                    self._register(row)
                known = set()
                self.meter.tick(1 + len(self.tdep.get(point, ())))
                for cid in self.tdep.get(point, ()):
                    row = self.placements[cid]
                    self.meter.tick(1 + len(row['t']) + len(row['m']))
                    if self._compatible(row):
                        known.add(cid)
                _need(seen == known, 'indexed provider omitted known compatible contact',
                      InventoryError)
            else:
                reply = self.provider(point, self.meter.tick)
                self.meter.tick()  # refusal remains sticky if callback swallowed it
                _fields(reply, ('point', 'complete', 'placements'), self.meter, InventoryError)
                response_point = _string(reply['point'], self.meter, error=InventoryError)
                _need(response_point == point
                      and reply['complete'] is True and type(reply['placements']) is list,
                      'complete state-independent incident response', InventoryError)
                count = len(reply['placements'])
                self.meter.tick(2 + count)
                seen = set()
                for value in reply['placements']:
                    row = _placement(value, self.capacity, self.meter, InventoryError)
                    self.meter.tick(1 + len(row['t']))
                    _need(any(p == point for p, units in row['t']) and row['id'] not in seen,
                          'unique incident placement required', InventoryError)
                    seen.add(row['id'])
                    self.stats['provider_rows'] += 1
                    self._register(row)
                self.meter.tick(1 + len(seen) + len(self.tdep.get(point, ())))
                _need(seen == self.tdep.get(point, set()),
                      'provider omitted already known incident placement', InventoryError)
'''
assert s.count(a)==1;s=s.replace(a,b)
a="            'stats': stats, 'limits': limits}\n"
b="""            'stats': stats, 'limits': limits,
            'provider_evidence': (state.provider_evidence() if state is not None else
                {'mode': 'UNINITIALIZED', 'total': 0, 'retained': 0,
                 'sha256': hashlib.sha256().hexdigest(),
                 'scope': 'BOUNDED_PREFIX_OF_COMPLETED_VALIDATED_INDEX_QUERIES',
                 'records': [], 'costs': {'query_attempts': 0, 'query_work': 0,
                 'query_seconds': 0.0, 'receipt_work': 0, 'potential_contacts': 0,
                 'returned_contacts': 0, 'context_values': 0}})}
"""
assert s.count(a)==1;s=s.replace(a,b)
s=s.replace('A certified incident provider enumerates ALL potential contacts, not legal ones.\nIts completeness is an external Source/qualification obligation, never proved by\nits complete flag. All actual filtering is exact capacity/literal-mark checking.', 'An eager provider enumerates all potential contacts; an indexed provider may\nreturn the complete current t/m-compatible contact set. Unseen completeness is\nan external Source/qualification obligation, never proved by a complete flag.\nForward-monotone incompatibility plus trailed discovery/exhaustion makes the\nindexed omission safe. Selection and branch exclusions stay in the base engine.')
assert not new.exists();new.write_text(s)
for name,a,b in [('growing-engine-Z1-to-IP2-forward.patch',old.read_text(),s),('growing-engine-Z1-to-IP2-inverse.patch',s,old.read_text())]:
 (new.parent/name).write_text(''.join(difflib.unified_diff(a.splitlines(keepends=True),b.splitlines(keepends=True),fromfile='ancestor' if 'forward' in name else 'successor',tofile='successor' if 'forward' in name else 'ancestor')))
print('Source only written; no engine helper/module execution.')
