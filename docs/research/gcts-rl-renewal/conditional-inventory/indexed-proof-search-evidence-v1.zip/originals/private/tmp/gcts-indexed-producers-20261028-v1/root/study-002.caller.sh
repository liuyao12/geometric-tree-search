#!/bin/sh
set -eu
set -C
umask 077
exec /Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12 -I -S -B /private/tmp/gcts-cluster-receptors-20261027-v2/root/authenticated-source-bootstrap-v1.py /private/tmp/gcts-indexed-producers-20261028-v1/root/indexed_proof_study_once_v2.py 19267 6efc1f55f685d4318de81c69d41ed2472872c521f266cf1dd0fc4405f76907f5 --mode observer --plan /private/tmp/gcts-indexed-producers-20261028-v1/root/study-once-plan-002.json --authority /private/tmp/gcts-indexed-producers-20261028-v1/root/study-once-authority-002.json < /private/tmp/gcts-indexed-producers-20261028-v1/root/indexed_proof_study_once_v2.py > /private/tmp/gcts-indexed-producers-20261028-v1/root/study-002.outer-stdout.bin 2> /private/tmp/gcts-indexed-producers-20261028-v1/root/study-002.outer-stderr.bin
