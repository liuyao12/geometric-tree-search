"""Passive saved-data report writer. No scientific imports or executions."""
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path


def need(ok, why):
    if not ok:
        raise RuntimeError(why)


def raw(x):
    return (json.dumps(x, sort_keys=True, ensure_ascii=True,
                       separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')


def read_ref(ref):
    p = Path(ref['path'])
    b = p.read_bytes()
    need(len(b) == ref['bytes'] and hashlib.sha256(b).hexdigest() == ref['sha256'], 'raw reference')
    return b


def load_artifact(ref):
    need(type(ref['raw_bytes']) is int and 0 <= ref['raw_bytes'] <= 67108864, 'bounded raw extent')
    b = read_ref(ref['stored'])
    if ref['encoding'] == 'gzip-json':
        with gzip.GzipFile(fileobj=io.BytesIO(b), mode='rb') as f:
            b = f.read(ref['raw_bytes'] + 1)
    else:
        need(ref['encoding'] == 'json', 'encoding')
    need(len(b) == ref['raw_bytes'] and hashlib.sha256(b).hexdigest() == ref['raw_sha256'], 'complete raw artifact')
    return json.loads(b)


def pin(p):
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--observer', required=True)
    ap.add_argument('--qualification', required=True)
    ap.add_argument('--admission', required=True)
    ap.add_argument('--out', required=True)
    args = ap.parse_args()
    root = Path(__file__).parent
    observer = json.loads(Path(args.observer).read_bytes())
    need(observer['status'] == 'COMPLETE' and observer['returncode'] == 0
         and observer['both_streams_EOF'] and observer['group_gone'], 'complete owned observation')
    worker = load_artifact(observer['worker_terminal']['result'])
    exp = worker['experiment']
    need(exp['status'] == 'COMPLETE' and len(exp['results']) == 15, 'all comparisons')
    admission = json.loads(Path(args.admission).read_bytes())
    need(admission['status'] == 'ADMITTED', 'Root scientific admission required')
    qualification = json.loads(Path(args.qualification).read_bytes())
    need(qualification['status'] == 'ADMITTED', 'qualified exact Sources')
    plan = json.loads(read_ref(observer['worker_terminal']['plan']))
    manifest = json.loads(read_ref(plan['metadata']['frozen_inputs']))
    inputs = {row['name']: row for row in manifest['inputs']}
    bank = load_artifact(inputs['current-bank-and-native-checks'])['result']['value']
    lanes = exp['design']['lanes']
    counts = {lane: {'verified': 0, 'unknown': 0, 'finite_exhausted': 0,
                     'search_seconds': 0.0, 'candidate_registrations': 0,
                     'provider_rows': 0, 'potential_rows': 0, 'omitted_rows': 0} for lane in lanes}
    cases = []
    source_refs = []
    for row in exp['results']:
        prep = load_artifact(inputs[row['id'] + '-whole-preparation'])
        case = {'id': row['id'], 'group': 'Arithmetic' if '-arith-' in row['id'] else
                'Typing' if '-typing-' in row['id'] else 'Incidence',
                'depth': row['depth'], 'problem': row['original'],
                'lemma_bindings': prep['application']['lemma_bindings'], 'lanes': {}}
        for lane in lanes:
            compact = row['lanes'][lane]
            full = load_artifact(compact['ref'])
            need(compact['status'] == full['status'] and compact['verified'] is full['verified'], 'lane projection')
            yes = full['verified']
            positive = full.get('positive', {})
            if yes:
                need(positive['verified'] and positive['tree_audit']['status'] == 'VERIFIED'
                     and positive['lowering_audit']['status'] == 'VERIFIED'
                     and positive['coarse_host_check']['status'] == 'VERIFIED'
                     and positive['original_host_check']['status'] == 'VERIFIED', 'actual positive checks')
            actual_status = full['status']
            counts[lane]['verified'] += int(yes)
            negative = actual_status in ('UNSAT', 'NOT_DERIVABLE')
            assurance = lane == 'MATCHED_DEPTH_TREE_CONTROL' or full.get('factory_audit', {}).get('status') == 'VERIFIED'
            negative = negative and assurance
            counts[lane]['finite_exhausted'] += int(negative)
            counts[lane]['unknown'] += int(not yes and not negative)
            counts[lane]['search_seconds'] += full['search_seconds']
            stats = (full.get('result') or {}).get('stats', {})
            for k in ('candidate_registrations', 'provider_rows'):
                counts[lane][k] += stats.get(k, 0)
            provider = full.get('provider', {})
            for k in ('potential_rows', 'omitted_rows'):
                counts[lane][k] += provider.get(k, 0)
            case['lanes'][lane] = {
                'status': actual_status, 'reason': full.get('reason'),
                'original_status': 'VERIFIED' if yes else 'UNKNOWN_FACTORY_AUDIT' if not assurance
                    else positive.get('reason', 'NO_CERTIFICATE'),
                'seconds': full['search_seconds'],
                'coarse_proof': positive.get('coarse_proof', []) if yes else [],
                'original_proof': positive.get('original_proof', []) if yes else [],
                'tree': positive.get('decoded', {}).get('tree') if yes else None,
                'checks': {k: positive.get(k) for k in ('tree_audit', 'coarse_host_check', 'original_host_check', 'lowering_audit')},
                'lowering': positive.get('lowering') if yes else None,
                'source_ref': compact['ref'], 'stats': stats, 'provider': provider}
            source_refs.append(compact['ref'])
        cases.append(case)
    for lane in lanes:
        need(sum(counts[lane][k] for k in ('verified', 'unknown', 'finite_exhausted')) == 15, 'complete tally')
    e, i, c = (counts[x]['verified'] for x in lanes)
    findings = [f'Indexed GCTS verified {i} targets; unchanged eager GCTS verified {e}; the matched proof-tree control verified {c}. All 45 method positions are retained.',
                'Each displayed successful proof was reconstructed independently, expanded through the certified lemma bank, and checked in the original theory. No hand-written target proof was fed to search.',
                'These are the same fifteen previously studied regression assertions. This experiment changes enumeration cost, not the logical inventory or theorem difficulty.']
    cost_notes = [f"New observer wall time: {observer['whole_observer_seconds']:.3f} seconds; fresh child peak RSS: {observer['wait4_peak_bytes']} bytes.",
                  f"Inherited catalogue preparation: {exp['design']['historical_preparation_seconds']:.3f} seconds; historical donor acquisition: {exp['design']['historical_donor_acquisition_seconds']:.3f} seconds. Both are disclosed reused costs, not fresh work hidden in the two-second comparison.",
                  f"Fresh shared bank host checks: {exp['fresh_bank_check_seconds']:.4f} seconds. Tree/factory checks, lowering and positive proof checking occur outside each search window; their complete original returns remain in the archive."]
    failed_attempt = None
    if 'failed_main001_original' in plan['metadata']:
        failure_ref = plan['metadata']['failed_main001_original']
        failure_exit = json.loads(read_ref(failure_ref))
        failure_observer = json.loads(read_ref(failure_exit['observer']))
        need(failure_exit['status'] == 'UNADMITTED' and failure_observer['status'] == 'UNADMITTED', 'failed attempt remains unadmitted')
        failed_attempt = {'original_exit': failure_ref, 'observer': failure_exit['observer'], 'cause': failure_exit['cause']}
        cost_notes.append(f"An initial attempt stopped at an artifact-filename guard before the first whole lane was saved. It is unadmitted and retained separately: {failure_observer['whole_observer_seconds']:.4f} seconds, peak {failure_observer['wait4_peak_bytes']} bytes. The reporting-label fix changes no search inventory or budgets; all 45 positions above belong to the later complete attempt.")
    for lane in lanes:
        x = counts[lane]
        cost_notes.append(f"{lane}: total cold search {x['search_seconds']:.4f} seconds, {x['verified']} verified, {x['finite_exhausted']} finite-depth exhausted, {x['unknown']} unknown; {x['candidate_registrations']} candidate registrations and {x['provider_rows']} returned provider rows.")
    reader = {'counts': counts, 'cases': cases, 'bank': bank['lemmas'], 'findings': findings,
              'qualification_summary': qualification.get('summary', 'Separate exhaustive tiny qualification admitted; inspect the complete receipt and raw observations in the evidence archive.'),
              'cost_notes': cost_notes,
              'assessment': ['The exact index removes materialization overhead by using the same problem-defining marking equalities earlier. It does not discover a new marking, a learned cluster family or an RL policy.',
                             'The conventional control searches producers by output formula and remaining depth. This single finite regression comparison does not establish a broad advantage over automated theorem provers.',
                             'Rooted proof-tree reachability is required; arbitrary disconnected point packings are not proof certificates. Full first-order expressiveness in a single fixed tile set and useful learned hierarchies remain open.'],
              'provenance': {'observer': pin(Path(args.observer)), 'qualification_admission': pin(Path(args.qualification)),
                             'scientific_admission': pin(Path(args.admission)), 'plan': observer['worker_terminal']['plan'],
                             'full_lane_records': source_refs, 'failed_attempt': failed_attempt, 'scope': exp['scope']}}
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=False)
    data = {'schema': 'AA-indexed-proof-search-public-results-v1', 'reader': reader,
            'scope': 'Passive complete saved-data projection; raw originals preserved in the full archive.'}
    (out/'indexed-proof-search-results-v1.json').write_bytes(raw(data))
    (out/'indexed-proof-search-v1.html').write_bytes((root/'indexed-proof-reader-template-v1.html').read_bytes())
    print(json.dumps({'status': 'COMPLETE', 'counts': counts, 'files': [pin(p) for p in sorted(out.iterdir())]}, sort_keys=True))


if __name__ == '__main__':
    main()
