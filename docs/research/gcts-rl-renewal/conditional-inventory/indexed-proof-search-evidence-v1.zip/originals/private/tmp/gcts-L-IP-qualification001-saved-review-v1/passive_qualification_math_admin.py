import pathlib,json,gzip,hashlib,itertools,collections,stat,re,shlex
IP=pathlib.Path('/private/tmp/gcts-indexed-producers-20261028-v1');R=IP/'root';A=IP/'actual/qualification-001';D=pathlib.Path('/private/tmp/gcts-L-IP-qualification001-saved-review-v1')
def canon(x):return json.dumps(x,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)
def wire(x):return (canon(x)+'\n').encode()
def sha(x):return hashlib.sha256(wire(x)).hexdigest()
def rd(p):
 p=pathlib.Path(p);s=p.stat();assert stat.S_ISREG(s.st_mode) and s.st_nlink==1 and not any(q.is_symlink() for q in (p,*p.parents));b=p.read_bytes();assert len(b)==s.st_size;return b
def ref(p):
 b=rd(p);return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def load(p):return json.loads(rd(p))
def guard(x):assert ref(x['path'])==x;return rd(x['path'])
def artifact(x):
 b=guard(x['stored']);b=gzip.decompress(b) if x['encoding']=='gzip-json' else b
 assert x['encoding'] in ['gzip-json','json'] and len(b)==x['raw_bytes'] and hashlib.sha256(b).hexdigest()==x['raw_sha256']
 return json.loads(b)
def save(n,x):
 p=D/n;assert not p.exists();p.write_text(json.dumps(x,sort_keys=True,ensure_ascii=True,indent=2)+'\n');return ref(p)
ob=load(A/'observer-result.json');w=artifact(ob['worker_terminal']['result']);x=w['experiment'];p=load(ob['worker_terminal']['plan']['path'])
assert ob['status']==w['status']==ob['worker_terminal']['status']=='COMPLETE' and ob['returncode']==0 and ob['both_streams_EOF'] and ob['group_gone'] and ob['wait_confirmed'] and ob['failure'] is None and ob['cleanup_errors']==[]
assert x['status']=='COMPLETE' and x['records']==26 and x['native_certificates']==6 and x['observations']==191 and x['captured_queries']==38
assert len(w['artifacts'])==26 and [z['name'] for z in w['artifacts']]==x['emitted_names']
records={z['name']:artifact(z) for z in w['artifacts']};assert len(records)==26
for q in ob['files']:guard(q)
assert {str(q) for q in A.iterdir()}=={z['path'] for z in ob['files']}|{str(A/'observer-result.json')}
assert len(ob['files'])==30 and len(list(A.iterdir()))==31 and sum(z['bytes'] for z in ob['files'])==ob['stored_bytes']
assert ob['stdin_bytes_sent']==p['sources']['runner']['bytes']==19236 and ob['wait4_peak_bytes']<=p['limits']['rss_bytes']
for group in ['sources','metadata']:
 for v in p[group].values():guard(v)
for k in ['bootstrap','python']:guard(p[k])
auth=load(R/'qualification-once-authority-001.json');cons=load(R/'qualification-once-authority-001.json.CONSUMED.json');inner=load(A/'CONSUMED.json')
assert auth==dict(schema='AA-growing-proof-search-once-authority-v1',authorized=True,uses=1,plan=ob['worker_terminal']['plan'],runner=p['sources']['runner'],python=p['python'])
assert cons['status']=='SPENT' and cons['authority']==ref(R/'qualification-once-authority-001.json') and cons['plan']==ob['worker_terminal']['plan']
assert inner['authority']==ref(R/'qualification-once-authority-001.json') and inner['consumed']==ref(R/'qualification-once-authority-001.json.CONSUMED.json')
original=load(R/'qualification-001.original-tool-exit-v1.json');assert original['native_exit']==0 and original['chunk_id']=='3ff603'
for k in ['stdout','stderr']:guard(original[k])
assert rd(original['stderr']['path'])==b'' and load(original['stdout']['path'])['receipt']==ref(A/'observer-result.json')
assert ob['streams']['stdout']['bytes']==ob['observed_stream_bytes']['stdout'] and ob['streams']['stderr']['bytes']==0
for z in ob['streams'].values():guard(z)
assert ob['retained_streams_complete']==dict(stdout=True,stderr=True)
caller=rd(R/'qualification-001.caller.sh').decode();assert 'set -C' in caller and '-I -S -B' in caller and str(p['sources']['runner']['path']) in caller
assert original['original_call']=='/bin/sh '+str(R/'qualification-001.caller.sh')
full_file_refs=[ref(z) for z in sorted(A.iterdir())]
counts=collections.Counter();state_summaries=[];query_summaries=[];pair_summaries=[];proof_summaries=[];fault_summaries=[]

def compatible(row,capacity,totals,marks):
 return all(totals.get(pt,0)+n<=capacity for pt,n in row['t']) and all(pt not in marks or marks[pt]==v for pt,v in row['m'])

def state_check(model,universe,s,where):
 tab={r['id']:r for r in universe};assert len(tab)==len(universe)
 selected=dict(s['selected']);assert len(selected)==len(s['selected']) and s['selected']==sorted(s['selected'])
 total=dict(model['seed']['t']);mr={pt:[v,1] for pt,v in model['seed']['m']};active=set(model['roots'])|{pt for pt,n in model['seed']['t'] if n};gens={pt:0 for pt in active}
 for cid,g in s['selected']:
  assert type(g) is int and g>=1 and cid in tab
  for pt,n in tab[cid]['t']:
   total[pt]=total.get(pt,0)+n;active.add(pt);gens[pt]=min(gens.get(pt,g),g)
  for pt,v in tab[cid]['m']:
   if pt in mr:assert mr[pt][0]==v;mr[pt][1]+=1
   else:mr[pt]=[v,1]
 assert all(0<=v<=model['capacity'] for v in total.values())
 assert s['Q']==[[pt,gens[pt]] for pt in sorted(active)] and s['totals']==[[pt,total.get(pt,0)] for pt in sorted(active|set(total))]
 assert s['marks']==[[pt,*mr[pt]] for pt in sorted(mr)]
 marks={pt:v[0] for pt,v in mr.items()};excluded=set(s['excluded']);assert len(excluded)==len(s['excluded']) and not (set(selected)&excluded)
 known={r['id']:r for r in s['placements']};assert list(known)==sorted(known) and all(r==tab[cid] for cid,r in known.items()) and set(selected)|excluded<=set(known)
 global_legal={cid for cid,row in tab.items() if cid not in selected and cid not in excluded and compatible(row,model['capacity'],total,marks)}
 assert s['eligible']==sorted(global_legal&set(known))
 frontier=sorted(pt for pt in active if total.get(pt,0)<model['capacity']);assert set(frontier)<=set(s['loaded'])<=active
 domains=[[pt,sorted(cid for cid in global_legal if pt in dict(tab[cid]['t']))] for pt in frontier]
 fwd=[[pt,cid,dict(tab[cid]['t'])[pt]] for pt,ids in domains for cid in ids];rev={}
 for pt,cid,n in fwd:rev.setdefault(cid,[]).append([pt,n])
 assert s['domains']==domains and s['forward']==fwd and s['reverse']==[[cid,rev[cid]] for cid in sorted(rev)] and s['edge_count']==len(fwd)
 deps={}
 for ch in ['t','m']:
  d={}
  for cid,row in known.items():
   for pt,_ in row[ch]:d.setdefault(pt,[]).append(cid)
  deps[ch]=[[pt,sorted(d[pt])] for pt in sorted(d)]
 assert s['dependencies']==deps
 touched={cid for cid,row in tab.items() if any(pt in s['loaded'] for pt,n in row['t'])}
 assert set(known)<=touched
 hidden=sorted(touched-set(known));assert all(not compatible(tab[cid],model['capacity'],total,marks) for cid in hidden)
 expanded=json.loads(canon(s));expanded['placements']=[tab[cid] for cid in sorted(touched)]
 for ch in ['t','m']:
  d={}
  for cid in sorted(touched):
   for pt,_ in tab[cid][ch]:d.setdefault(pt,[]).append(cid)
  expanded['dependencies'][ch]=[[pt,sorted(d[pt])] for pt in sorted(d)]
 for k in set(s)-{'placements','dependencies'}:assert expanded[k]==s[k]
 counts['state_images']+=1;counts['hidden_illegal_rows_across_images']+=len(hidden)
 state_summaries.append(dict(where=where,actual_sha256=sha(s),expanded_check_sha256=sha(expanded),hidden_illegal_ids=hidden,frontier=len(frontier),edges=len(fwd)))
 return domains

def query_check(model,universe,record,where,valid=True):
 q,r=record['query'],record['reply'];assert q['schema']=='IP-current-tm-incident-query-v1' and q['inventory_identity']==model['inventory']['identity'] and q['capacity']==model['capacity']
 assert q['totals']==sorted(q['totals']) and q['marks']==sorted(q['marks']);t=dict(q['totals']);m=dict(q['marks'])
 potential=sorted([v for v in universe if q['point'] in dict(v['t'])],key=lambda v:v['id'])
 expected=[v for v in potential if compatible(v,model['capacity'],t,m)]
 semantic=(r['point']==q['point'] and r['context_sha256']==sha(q) and r['complete'] is True and r['certificate']==dict(scope='COMPLETE_CURRENT_TM_COMPATIBLE_INCIDENT_SET',potential_count=len(potential),compatible_count=len(expected)) and sorted(r['placements'],key=lambda v:v['id'])==expected)
 assert semantic is valid
 counts['query_captures_checked']+=1
 query_summaries.append(dict(where=where,valid=valid,context_sha256=sha(q),potential=len(potential),compatible=len(expected),potential_ids=[v['id'] for v in potential],compatible_ids=[v['id'] for v in expected]))

def result_check(model,universe,rec,where):
 r=rec['result'];obs=rec['observations'];assert rec['independent']['status']=='VERIFIED'
 assert r['status'] in ['SAT','UNSAT','UNKNOWN'];counts['returned_'+r['status']]+=1
 for k in ['entry','final','restored']:
  s=r[k+'_state'];h=r['state_hashes'][k]
  if s is None:assert h is None and r['status']=='UNKNOWN'
  else:assert h==sha(s);state_check(model,universe,s,where+'/'+k);counts['actual_state_hashes']+=1
 if r['entry_state'] is not None:assert r['entry_state']==r['restored_state'] and r['state_hashes']['entry']==r['state_hashes']['restored'];counts['exact_final_restores']+=1
 if r['status']!='SAT':assert r['selected']==[] and r['certificate'] is None
 if r['status']=='UNKNOWN':assert r['final_state'] is None
 if r['status']=='SAT':
  f=r['final_state'];tab={v['id']:v for v in universe};assert r['selected']==[z[0] for z in f['selected']] and f['domains']==[]
  cert=dict(capacity=model['capacity'],roots=sorted(model['roots']),seed=model['seed'],placements=[tab[cid] for cid in r['selected']],totals=[[pt,dict(f['totals']).get(pt,0)] for pt,g in f['Q']],marks=f['marks']);assert r['certificate']==cert
 for name in ['event','rollback']:
  stream=r['events' if name=='event' else 'rollback_records'];extent=r[name+'_extent'];assert len(stream)==extent['retained']==extent['total']
  assert hashlib.sha256(b''.join(wire(z) for z in stream)).hexdigest()==extent['sha256'];counts[name+'_rows']+=len(stream)
 assert [z['event'] for z in obs]==r['events'][:len(obs)]
 if r['status']!='UNKNOWN':assert len(obs)==len(r['events'])
 for i,z in enumerate(obs):
  e,s=z['event'],z['state'];assert e['seq']==i;dom=dict(state_check(model,universe,s,where+'/observation'+str(i)));g=dict(s['Q']);kind=e['kind'];point=e['point'];cid=e['candidate']
  dead=[pt for pt,v in dom.items() if not v];forced=[pt for pt,v in dom.items() if len(v)==1]
  if kind=='DEAD':assert point==min(dead,key=lambda pt:(g[pt],pt)) and cid is None
  if kind=='FORCED':assert not dead and point==min(forced,key=lambda pt:(g[pt],pt)) and cid==dom[point][0]
  if kind=='BRANCH':assert not dead and not forced and point==min(dom,key=lambda pt:(g[pt],len(dom[pt]),pt)) and e['data']['legal']==dom[point] and e['data']['order']==dom[point] and cid is None
  if kind=='PLACED':
   pre=obs[i-1];assert pre['event']['kind'] in ['FORCED','BRANCH'];chosen=pre['event']['candidate'] if pre['event']['kind']=='FORCED' else pre['event']['data']['order'][0];assert cid==chosen
   prevgen=dict(pre['state']['Q']);tab={v['id']:v for v in universe};newgen=1+min(prevgen[pt] for pt,n in tab[cid]['t'] if pt in prevgen);assert e['data']['generation']==newgen and dict(s['selected'])==dict(pre['state']['selected'])|{cid:newgen}
  if kind=='EXCLUDE':
   parents=[v for v in obs[:i] if v['event']['kind']=='BRANCH' and v['event']['data']['order'][0]==cid and v['state']['selected']==s['selected']];assert parents;par=parents[-1]['state']
   for key in ['Q','totals','selected','marks','placements','loaded','dependencies']:assert par[key]==s[key]
   assert s['excluded']==sorted(set(par['excluded'])|{cid});counts['scoped_failed_child_exclusions']+=1
  counts['observation_'+kind]+=1
 for rb in r['rollback_records']:assert rb['undone']==rb['from_trail']-rb['to_trail'] and rb['selected_after']<=rb['selected_before']
 if 'provider_evidence' in r:
  ev=r['provider_evidence'];assert ev['total']==ev['retained']==len(ev['records']) and hashlib.sha256(b''.join(wire(v) for v in ev['records'])).hexdigest()==ev['sha256']
  for j,v in enumerate(ev['records']):query_check(model,universe,v,where+'/engine-query'+str(j));counts['engine_query_records']+=1
 for j,v in enumerate(rec.get('query_captures',[])):query_check(model,universe,v,where+'/captured'+str(j));counts['retained_query_captures']+=1

# Independent combinations/sums/connectedness proof over the SAVED declared inventory.
for name,d in records.items():
 if 'indexed' not in d:continue
 model,U=d['model'],d['universe'];ids=[z['id'] for z in U];tab={z['id']:z for z in U};assert len(ids)<=14 and d['complete_subset_count']==2**len(ids)
 exact=[]
 for n in range(len(ids)+1):
  for subset in itertools.combinations(sorted(ids),n):
   counts['complete_subsets_checked']+=1;t=dict(model['seed']['t']);vals={};ok=True
   for pt,v in model['seed']['m']:vals[pt]={v}
   for cid in subset:
    for pt,v in tab[cid]['t']:t[pt]=t.get(pt,0)+v
    for pt,v in tab[cid]['m']:vals.setdefault(pt,set()).add(v)
   if any(v>model['capacity'] for v in t.values()) or any(len(v)>1 for v in vals.values()):continue
   active=set(model['roots'])|{pt for pt,v in model['seed']['t'] if v};left=set(subset)
   while True:
    touching={cid for cid in left if active&set(dict(tab[cid]['t']))}
    if not touching:break
    active|={pt for cid in touching for pt,v in tab[cid]['t']};left-=touching
   if not left and all(t.get(pt,0)==model['capacity'] for pt in active):exact.append(list(subset))
 exact.sort();assert exact==sorted(d['all_root_reachable_solutions'])
 for lane in ['indexed','eager']:
  result_check(model,U,d[lane],name+'/'+lane);rr=d[lane]['result'];assert (rr['status']=='SAT')==bool(exact)
  if rr['status']=='SAT':assert rr['selected'] in exact
 a,b=d['indexed'],d['eager'];assert a['result']['status']==b['result']['status'] and a['result']['selected']==b['result']['selected']
 assert [v['event'] for v in a['observations']]==[v['event'] for v in b['observations']]
 for aa,bb in zip(a['observations'],b['observations']):
  for key in set(aa['state'])-{'placements','dependencies'}:assert aa['state'][key]==bb['state'][key]
 pair_summaries.append(dict(case=name,placements=len(U),subsets=2**len(U),solutions=len(exact),status=a['result']['status'],eager_registered=a['result']['stats']['candidate_registrations'],indexed_registered=a['result']['stats']['candidate_registrations'],eager_final_registry=len(b['result']['final_state']['placements']),indexed_final_registry=len(a['result']['final_state']['placements'])))
 if name=='bad-first-restore':assert a['result']['stats']['backtracks']>0 and a['result']['stats']['exclusions']>0
 if name.startswith('proof-'):
  c=d['extra']['compiled'];g=d['extra']['generation'];depth=d['extra']['factory_indexed']['value']['depth'];core={k:v for k,v in c.items() if k not in ['costs','scope']};assert sha(core)==g['compiled_core_sha256']
  assert d['extra']['factory_indexed']['value']==d['extra']['factory_eager']['value'] and d['extra']['audited_factory_indexed']['status']==d['extra']['audited_factory_eager']['status']=='VERIFIED'
  defs=d['extra']['factory_indexed']['value']['definitions'];full=[];sites=['']+[format(i,'0'+str(n)+'b') for n in range(1,depth+1) for i in range(2**n)]
  colors=c['logical_basis']['colors'];assert colors==[canon(f) for f in c['logical_basis']['formulas']]
  for site in sites:
   for dd in defs:
    if len(site)==depth and dd['premises']:continue
    pp=[site]+[site+str(j) for j in range(len(dd['premises']))];ff=[dd['output']]+dd['premises'];full.append(dict(id=canon([site,dd['id']]),t=[[pt,1] for pt in pp],m=[[pt,colors[fid]] for pt,fid in zip(pp,ff)]))
  assert sorted(full,key=lambda v:v['id'])==U
  for desc in d['extra']['descriptions']:
   raw=desc['description'];point=desc['point'];assert desc['independent']['status']=='VERIFIED' and raw['potential_count']==sum(point in dict(z['t']) for z in U)
   fam=raw['families'];family_ids=[canon([anchor,di]) for f in fam for anchor in [f['anchor']] for di in f['definition_ids']]
   assert sorted(family_ids)==sorted(z['id'] for z in U if point in dict(z['t']))
   supp=sorted({pt for f in fam for pt in f['t_points']});assert raw['dependencies']==dict(t=supp,m=supp)
   counts['full_static_site_descriptions']+=1
  for lane in ['indexed','eager']:
   if d[lane]['result']['status']!='SAT':continue
   z=d[lane+'_proof'];dec=z['decoded'];tree=dec['tree'];proof=dec['proof'];host=z['host_FOL'];assert z['independent_tree']['status']=='VERIFIED' and host['status']=='VERIFIED' and host['checked_lines']==len(proof)
   assert tree['selected']==d[lane]['result']['selected'] and tree['placements']==d[lane]['result']['certificate']['placements'] and tree['totals']==d[lane]['result']['certificate']['totals'] and tree['marks']==d[lane]['result']['certificate']['marks']
   assert len(proof)==len(tree['placements'])==tree['node_count'] and proof[-1]['formula']==c['goal']
   bysite=dict(tree['site_to_line']);assert bysite['']==len(proof)-1
   for cid in tree['selected']:
    site,di=json.loads(cid);dd=next(z for z in defs if z['id']==di);line=proof[bysite[site]];assert line['formula']==c['logical_basis']['formulas'][dd['output']]
    if dd['kind']=='ZERO':assert line==next(z['line'] for z in c['zero_instances'] if z['id']==dd['zero_id']) and line['formula']==c['theory']['axioms'][line['name']]
    elif dd['kind']=='GEN':assert line['rule']=='generalize' and line['source']==bysite[site+'0'] and line['variable']==dd['variable'] and line['formula']==['all',line['variable'],proof[line['source']]['formula']]
    else:assert line['rule']=='mp' and line['antecedent']==bysite[site+'0'] and line['implication']==bysite[site+'1'] and proof[line['implication']]['formula']==['imp',proof[line['antecedent']]['formula'],line['formula']]
   delivered=next(z for z in d['native_certificates'] if z['label']==lane);assert delivered==dict(label=lane,problem=dict(theory=c['theory'],goal=c['goal']),proof=proof)
   counts['fresh_host_proof_checks']+=1;counts['actual_proof_lines']+=len(proof)
   for rule,n in host['rule_counts'].items():counts['host_rule_'+rule]+=n
   proof_summaries.append(dict(case=name,lane=lane,lines=len(proof),selected=tree['selected'],postorder=tree['site_to_line'],host_status=host['status'],proof=proof))
 else:assert d['native_certificates']==[]

for name,d in records.items():
 if 'indexed' in d or name=='data-only-query-graph-negatives':continue
 if 'answer' in d:
  result_check(d['model'],d['universe'],d['answer'],name);rr=d['answer']['result'];assert rr['status']=='UNKNOWN'
  fault_summaries.append(dict(case=name,status='UNKNOWN',reason=rr['reason'],entry_present=rr['entry_state'] is not None))
 else:
  assert d['actual_exception']==d['expected_exception'] and d['no_post_exception_state_claim'] is True
  assert d['actual_exception']==('InventoryError' if name=='fault-context-binding' else '_Foreign')
  for i,z in enumerate(d.get('observations',[])):state_check(d['model'],d['universe'],z['state'],name+'/pre-throw'+str(i));counts['prethrow_observations']+=1
  for i,z in enumerate(d['query_captures']):query_check(d['model'],d['universe'],z,name+'/captured'+str(i),valid=name!='fault-context-binding');counts['retained_query_captures']+=1
  fault_summaries.append(dict(case=name,exception=d['actual_exception'],message=d['message'],prethrow_observations=len(d.get('observations',[])),postthrow_image_claim=False))
 assert d['native_certificates']==[]
mut=records['data-only-query-graph-negatives']['mutations'];assert len(mut)==4 and all(v['independent']['status']=='REJECTED' for v in mut)
for v in mut:
 if v['label']=='stale-hash':assert v['forged']['context_sha256']!=sha(v['query'])
 if v['label']=='missing-contact':assert v['forged']['placements']==[] and v['independent']['reason']=='QUERY_COUNTS'
 if v['label']=='boolean-count':assert type(v['forged']['certificate']['potential_count']) is bool
 if v['label']=='false-dead-domain':assert v['forged']['domains']==[['r',[]]] and v['forged']['forward']==[['r','a',1]]
assert sum(1 for d in records.values() if 'indexed' in d)==16
assert counts['fresh_host_proof_checks']==6 and counts['retained_query_captures']==38
assert sum(v for k,v in counts.items() if k.startswith('observation_'))+counts['prethrow_observations']==191
assert counts['returned_SAT']+counts['returned_UNSAT']+counts['returned_UNKNOWN']==37 and len(fault_summaries)==9
assert x['inherited_audit_counts']==dict(verify_result=37,verify_state=192)
support=save('IP-qualification001-complete-independent-passive-mathematical-support-v1.json',dict(schema='IP-qualification001-complete-independent-passive-mathematical-support-v1',status='PASS',counts=dict(counts),all_physical_files=full_file_refs,observer=ref(A/'observer-result.json'),worker=ref(A/'worker-result.json'),plan=ob['worker_terminal']['plan'],actual_original_exit=ref(R/'qualification-001.original-tool-exit-v1.json'),all_pairs=pair_summaries,all_image_original_and_expanded_hashes=state_summaries,all_query_set_details=query_summaries,all_six_proof_transcriptions=proof_summaries,all_nine_refusal_faults=fault_summaries,data_only_negatives=mut,scope='Independent passive sums/set comparisons and complete saved finite subset arithmetic only; no project/qualifier/engine/verifier/FOL/VM replay.'))
review=save('IP-qualification001-complete-independent-passive-mathematical-review-v1.json',dict(schema='IP-qualification001-complete-independent-passive-mathematical-review-v1',status='PASS',blockers=[],support=support,observer=ref(A/'observer-result.json'),worker=ref(A/'worker-result.json'),original_exit=ref(R/'qualification-001.original-tool-exit-v1.json'),
 complete_counts=dict(records=26,solves=41,returned_results=37,expected_faults=4,normal_eager_indexed_pairs=16,completed_observations=191,captured_queries=38,fresh_host_checks=6,proof_lines=counts['actual_proof_lines'],complete_saved_subsets=counts['complete_subsets_checked'],returned_image_hashes=counts['actual_state_hashes']),
 mathematical_checks=['All sixteen saved complete tiny solution sets independently reconstructed by combinations, exact integer t sums, literal marking agreement and root-reachable active closure; no truncated products. Both actual lexical witnesses/statuses belong to the full set, and every paired event/current graph agrees despite differing registries.','Every returned nonnull image and all191 completed observation images independently reconstructed from seed+selected rows. All Q/generations, totals, mark refcounts, exclusions, eligible registered IDs, complete global frontier domains, weighted forward/reverse incidence and actual registered t/m dependencies match.','All omitted potential loaded contacts are independently t/m-illegal in their actual context. Check-copy additions change only registry/dependencies; actual hashes are recomputed separately and never replaced by expanded hashes. Full parent and wrong-output static contacts remain in independently expanded finite inventory.','Every retained query and complete engine query stream is independently full-set/count/context-hash checked; one deliberate invalid context hash is correctly refused. Candidate selected/exclusion tests stay engine-side. Capacity-four detached query clearing leaves the actual logical state and bound authoritative records intact.','Global dead precedes forced, forced precedes generation-tied branching, and earlier generation precedes smaller later domains in every actual observed decision. Real bad-first failures restore parent discovery/load/dependencies and scope exclusions exactly; all final complete entry/restored images match.','Complete event, rollback and provider-query streams and original state hashes are recomputed from saved canonical records. Owned UNKNOWN and foreign fault records retain their actual prefixes with no fabricated postthrow graph.','All four proof factories have the same old semantic model/definition identity; all ten per-site family descriptions cover exact own+all-parent members. Six actual decoded zero/GEN/MP proof trees and host-FOL VERIFIED receipts match whole selected t/m certificates, theorem inputs and postorder refs. Twelve proof lines read directly; no kernel rerun.','All five resource refusals are UNKNOWN, all four expected foreign/checked failures stay failures, and all four isolated data-only forgeries are actually REJECTED. All26fixed records are retained.'],
 custody='All31 physical files and26 stored/raw artifact associations fully read/hashed; current11Sources14metadata, D90/bootstrap/typedplan/A6/consume/currentcaller/original3ff603native0 and complete worker/observerEOF/wait/group joined. B independently covers the full ownership scope.',
 limits=['This is finite tiny Source/index regression qualification, not a main-search or unrestricted logical completeness result. Only declared structural zero axioms are used, with actual host checking; no fresh native-C1/VM execution.','Hidden-contact nonrevival still relies on Source-proved monotone forward totals/marks and exact rollback for general unseen inventories. No rule weakening is qualified.','Foreign cleanup is Source-proved and whole owned-process completion observed; no post-exception internal graph is fabricated.','No performance or broad theorem-prover advantage follows from this subsecond instrumented qualification. Main comparison and saved output admission remain separate.'],
 activity=dict(project_function_import_or_replay=0,network_Git_VM_calls=0,evidence_changes=0,writes='Separate passive support/review only; tools idle after receipt.')))
print(json.dumps(dict(review=review,support=support,counts=dict(counts)),sort_keys=True))
