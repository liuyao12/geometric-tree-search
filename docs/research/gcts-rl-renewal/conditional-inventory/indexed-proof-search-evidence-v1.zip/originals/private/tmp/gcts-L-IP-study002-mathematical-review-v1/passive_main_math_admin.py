import pathlib,json,gzip,hashlib,collections,stat,math
IP=pathlib.Path('/private/tmp/gcts-indexed-producers-20261028-v1');R=IP/'root';A=IP/'actual/study-002';D=pathlib.Path('/private/tmp/gcts-L-IP-study002-mathematical-review-v1')
def text(x):return json.dumps(x,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)
def wire(x):return (text(x)+'\n').encode()
def sha(x):return hashlib.sha256(wire(x)).hexdigest()
def rd(p):
 p=pathlib.Path(p);s=p.stat();assert stat.S_ISREG(s.st_mode) and s.st_nlink==1 and not any(q.is_symlink() for q in (p,*p.parents));b=p.read_bytes();assert len(b)==s.st_size;return b
def ref(p):
 b=rd(p);return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def guard(x):assert ref(x['path'])==x;return rd(x['path'])
def obj(p):return json.loads(rd(p))
def artifact(x):
 b=guard(x['stored']);b=gzip.decompress(b) if x['encoding']=='gzip-json' else b;assert len(b)==x['raw_bytes'] and hashlib.sha256(b).hexdigest()==x['raw_sha256'];return json.loads(b)
def save(n,x):
 p=D/n;assert not p.exists();p.write_text(json.dumps(x,sort_keys=True,ensure_ascii=True,indent=2)+'\n');return ref(p)
O=obj(A/'observer-result.json');W=artifact(O['worker_terminal']['result']);E=W['experiment'];P=obj(O['worker_terminal']['plan']['path'])
assert O['status']==W['status']==E['status']=='COMPLETE' and O['returncode']==0 and O['wait_confirmed'] and O['both_streams_EOF'] and O['group_gone'] and O['cleanup_errors']==[] and O['failure'] is None
assert len(W['artifacts'])==83 and len(E['results'])==15 and E['design']['depth']==8 and E['design']['search_seconds']==2
assert E['design']['case_order']==[v['id'] for v in E['results']]
all_art={a['name']:artifact(a) for a in W['artifacts']};assert len(all_art)==83
for q in O['files']:guard(q)
assert {str(p) for p in A.iterdir()}=={q['path'] for q in O['files']}|{str(A/'observer-result.json')}
for group in ['sources','metadata']:
 for q in P[group].values():guard(q)
for key in ['bootstrap','python']:guard(P[key])
orig=obj(R/'study-002.original-tool-exit-v1.json');assert orig['native_exit']==0
for key in ['stdout','stderr']:guard(orig[key])
assert rd(orig['stderr']['path'])==b''
assert obj(orig['stdout']['path'])['receipt']==ref(A/'observer-result.json')
planref=O['worker_terminal']['plan'];auth=obj(R/'study-once-authority-002.json');cons=obj(R/'study-once-authority-002.json.CONSUMED.json')
assert auth['plan']==planref and auth['runner']==P['sources']['runner'] and auth['python']==P['python'] and auth['authorized'] is True and type(auth['uses']) is int and auth['uses']==1
assert cons['status']=='SPENT' and cons['authority']==ref(R/'study-once-authority-002.json') and cons['plan']==planref
Q=obj(P['metadata']['qualification_admission']['path']);assert Q['status']=='ADMITTED'
for k in ['engine_indexed','adapter_indexed','qualifier']:assert Q['sources'][k]==P['sources'][k]
F=obj(P['metadata']['frozen_inputs']['path']);inputs={x['name']:x for x in F['inputs']};assert len(inputs)==31
frozen={k:artifact(v) for k,v in inputs.items()}
bankrec=frozen['current-bank-and-native-checks'];bank=bankrec['result']['value'];assert bankrec['result']['status']=='COMPLETE' and bankrec['audit']['status']=='VERIFIED' and len(bank['lemmas'])==4
assert sha({k:bank[k] for k in ['schema','version','donors','lemmas']})==bank['bank_sha256']
L={v['id']:v for v in bank['lemmas']};names={v['name']:v for v in bank['lemmas']}
assert len(E['fresh_bank_checks'])==4 and all(v['status']=='VERIFIED' for v in E['fresh_bank_checks'])
C=collections.Counter();cost=collections.defaultdict(float);rows=[];images=[];proofs=[];negative=[];extents=[];querysets=[]
LANES=['EAGER_POINT_LEX','INDEXED_POINT_LEX','MATCHED_DEPTH_TREE_CONTROL'];assert E['design']['lanes']==LANES

def definitions(c):
 forms=c['logical_basis']['formulas'];colors=c['logical_basis']['colors'];assert colors==[text(f) for f in forms] and colors==sorted(set(colors));by={s:i for i,s in enumerate(colors)}
 dd={};mp=[];gen=[]
 for i,z in enumerate(c['zero_instances']):
  assert z['id']=='i'+str(i) and z['line']['formula']==forms[z['formula_id']];dd[text(['zero',z['id']])]=dict(out=z['formula_id'],prem=[],kind='ZERO',zero=z['id'])
 for i,f in enumerate(forms):
  if f[0]=='imp' and text(f[1]) in by and text(f[2]) in by:
   a,b=by[text(f[1])],by[text(f[2])];mp.append([i,a,b]);dd[text(['mp',i,a,b])]=dict(out=b,prem=[a,i],kind='MP')
  if f[0]=='all' and text(f[2]) in by:
   b=by[text(f[2])];gen.append([i,b,f[1]]);dd[text(['gen',i,b,f[1]])]=dict(out=i,prem=[b],kind='GEN',variable=f[1])
 assert mp==c['mp_index'] and gen==c['gen_index'];return dd

def placement(site,di,dd,colors):
 d=dd[di];pts=[site]+[site+str(j) for j in range(len(d['prem']))];fids=[d['out']]+d['prem'];return dict(id=text([site,di]),t=[[p,1] for p in pts],m=[[p,colors[f]] for p,f in zip(pts,fids)])

def boundary(c,dd,model,s,where):
 selected=dict(s['selected']);cap=model['capacity'];total=dict(model['seed']['t']);marks={p:[v,1] for p,v in model['seed']['m']};active=set(model['roots'])|{p for p,n in model['seed']['t'] if n};generation={p:0 for p in active};colors=c['logical_basis']['colors']
 actual={v['id']:v for v in s['placements']}
 for cid,row in actual.items():
  site,di=json.loads(cid);assert len(site)<=8 and all(z in '01' for z in site) and (len(site)<8 or not dd[di]['prem']);assert row==placement(site,di,dd,colors)
 for cid,g in s['selected']:
  site,di=json.loads(cid);assert g==len(site)+1 and cid in actual
  for p,n in actual[cid]['t']:total[p]=total.get(p,0)+n;active.add(p);generation[p]=min(generation.get(p,g),g)
  for p,v in actual[cid]['m']:
   if p in marks:assert marks[p][0]==v;marks[p][1]+=1
   else:marks[p]=[v,1]
 assert s['Q']==[[p,generation[p]] for p in sorted(active)] and s['totals']==[[p,total.get(p,0)] for p in sorted(active|set(total))] and all(n<=cap for n in total.values()) and s['marks']==[[p,*marks[p]] for p in sorted(marks)]
 def compatible(row):return all(total.get(p,0)+n<=cap for p,n in row['t']) and all(p not in marks or marks[p][0]==v for p,v in row['m'])
 selected_ids=set(selected);excluded=set(s['excluded']);assert not(selected_ids&excluded) and selected_ids|excluded<=set(actual)
 eligible=sorted(cid for cid,row in actual.items() if cid not in selected_ids and cid not in excluded and compatible(row));assert s['eligible']==eligible
 frontier=sorted(p for p in active if total.get(p,0)<cap);assert set(frontier)<=set(s['loaded'])<=active
 expected=[];fw=[];rv={};potential_counts={}
 for p in frontier:
  candidates={}
  for anchor in [p]+([p[:-1]] if p else []):
   for di,d in dd.items():
    if len(anchor)==8 and d['prem']:continue
    role=anchor==p or (p[-1:]=='0' and len(d['prem'])>=1) or (p[-1:]=='1' and len(d['prem'])==2)
    if not role:continue
    row=placement(anchor,di,dd,colors);candidates[row['id']]=row
  potential_counts[p]=len(candidates)
  ids=sorted(cid for cid,row in candidates.items() if cid not in selected_ids and cid not in excluded and compatible(row))
  assert set(ids)<=set(actual);expected.append([p,ids])
  for cid in ids:fw.append([p,cid,1]);rv.setdefault(cid,[]).append([p,1])
 assert expected==s['domains'] and fw==s['forward'] and [[cid,rv[cid]] for cid in sorted(rv)]==s['reverse'] and len(fw)==s['edge_count']
 deps={}
 for ch in ['t','m']:
  inv={}
  for cid,row in actual.items():
   for p,v in row[ch]:inv.setdefault(p,[]).append(cid)
  deps[ch]=[[p,sorted(inv[p])] for p in sorted(inv)]
 assert s['dependencies']==deps
 C['boundary_images']+=1;images.append(dict(where=where,sha256=sha(s),active=len(active),registered=len(actual),frontier=len(frontier),edges=len(fw),potential_frontier_counts=potential_counts))

for row in E['results']:
 cid=row['id'];built=frozen[cid+'-whole-build'];prep=frozen[cid+'-whole-preparation'];c=built['compiled'];g=built['generation'];dd=definitions(c);colors=c['logical_basis']['colors']
 assert built['status']==prep['status']=='COMPLETE' and prep['catalogue_audit']['status']==prep['zero_audit']['status']=='VERIFIED'
 assert sha(c)==prep['checkpoint']['raw_sha256']==row['compiled_sha256'] and g==prep['generation']
 core=sha({k:v for k,v in c.items() if k not in ['costs','scope']});assert core==g['compiled_core_sha256']
 app=prep['application'];original=prep['original'];assert app['bank_sha256']==bank['bank_sha256'] and app['original_theory_sha256']==sha(original['theory']) and row['original']==original
 eligible=[]
 for lid,l in sorted(L.items()):
  ax=all(original['theory']['axioms'].get(n)==f for n,f in l['required_axioms'].items());sig=all(original['theory'][part].get(n)==arity for part in ['functions','predicates'] for n,arity in l['signature'][part].items())
  if ax and sig:eligible.append(dict(lemma_id=lid,name=l['name']))
 assert app['lemma_bindings']==eligible
 extended=json.loads(text(original['theory']));extended['axioms'].update({L[v['lemma_id']]['name']:L[v['lemma_id']]['goal'] for v in eligible});assert app['theory']==extended==c['theory']==prep['problem']['theory'] and c['goal']==original['goal']
 current={};rr=dict(case=cid,goal=original['goal'],formula_count=len(colors),definitions=len(dd),eligible_lemmas=[v['lemma_id'] for v in eligible],lanes={})
 for lane in LANES:
  compact=row['lanes'][lane];full=artifact(compact['ref']);current[lane]=full;assert full['status']==compact['status'] and full['verified'] is compact['verified'] and full['reason']==compact['reason']
  C[(lane,full['status'])]+=1;cost[(lane,'cold_search_seconds')]+=full['search_seconds']
  rr['lanes'][lane]=dict(status=full['status'],reason=full['reason'],verified=full['verified'],search_seconds=full['search_seconds'])
  if lane!='MATCHED_DEPTH_TREE_CONTROL':
   assert full['factory']['status']=='COMPLETE' and full['factory_audit']['status']=='VERIFIED';value=full['factory']['value'];model=full['model'];assert value['compiled_core_sha256']==core and value['depth']==8 and value['potential_sites']==511
   assert value['identity']==sha(dict(schema='Z-anchored-proof-inventory-identity-v1',version='Z-ANCHORED-PROOF-PRODUCER-v1',compiled_core_sha256=core,depth=8))==model['inventory']['identity']
   assert model==dict(schema='Z-growing-point-model-v1',version='Z-ANCHORED-PROOF-PRODUCER-v1',capacity=2,roots=[''],seed=dict(t=[['',1]],m=[['',colors[c['goal_id']]]]),inventory=dict(kind='CERTIFIED_INCIDENT',identity=value['identity']))
   expected_defs=[]
   for di,v in sorted(dd.items()):expected_defs.append(dict(id=di,kind=v['kind'],output=v['out'],premises=v['prem'],zero_id=v.get('zero'),variable=v.get('variable'),native_rule=next(z['rule'] for z in c['zero_instances'] if z['id']==v['zero']) if v['kind']=='ZERO' else 'mp' if v['kind']=='MP' else 'generalize'))
   assert value['definitions']==expected_defs
   result=full['result'];assert result['status']==full['status'] and result['reason']==full['reason']
   for key in ['entry','final','restored']:
    state=result[key+'_state'];h=result['state_hashes'][key]
    if state is None:assert h is None and result['status']=='UNKNOWN'
    else:assert sha(state)==h;boundary(c,dd,model,state,cid+'/'+lane+'/'+key);C['original_image_hashes']+=1
   if result['entry_state'] is not None:assert result['entry_state']==result['restored_state'] and result['state_hashes']['entry']==result['state_hashes']['restored'];C['entry_restores']+=1
   if result['status']!='SAT':assert result['selected']==[] and result['certificate'] is None and result['final_state'] is None
   for stream,ek in [('events','event'),('rollback_records','rollback')]:
    ex=result[ek+'_extent'];body=result[stream];assert len(body)==ex['retained']<=ex['total'];C[ek+'_retained']+=len(body);C[ek+'_total']+=ex['total']
    if ex['retained']==ex['total']:assert hashlib.sha256(b''.join(wire(v) for v in body)).hexdigest()==ex['sha256'];C[ek+'_full_hashes']+=1
    extents.append(dict(case=cid,lane=lane,stream=ek,total=ex['total'],retained=ex['retained'],complete=ex['total']==ex['retained']))
   for k in ['factory_seconds','factory_audit_seconds']:cost[(lane,k)]+=full[k]
   for k in ['candidate_registrations','provider_rows','work','branches','placements','backtracks']:cost[(lane,k)]+=result['stats'][k]
   if lane=='INDEXED_POINT_LEX':
    ev=result['provider_evidence'];assert ev['retained']==len(ev['records'])<=ev['total'];C['query_total']+=ev['total'];C['query_retained']+=ev['retained']
    if ev['retained']==ev['total']:assert hashlib.sha256(b''.join(wire(v) for v in ev['records'])).hexdigest()==ev['sha256'];C['query_full_hashes']+=1
    for qi,record in enumerate(ev['records']):
     q,r=record['query'],record['reply'];assert sha(q)==r['context_sha256'] and q['inventory_identity']==value['identity']
     t=dict(q['totals']);m=dict(q['marks']);point=q['point'];rows=[];alln=0
     for anchor in [point]+([point[:-1]] if point else []):
      for di,v in dd.items():
       if len(anchor)==8 and v['prem']:continue
       if not(anchor==point or point[-1:]=='0' and len(v['prem'])>=1 or point[-1:]=='1' and len(v['prem'])==2):continue
       alln+=1;candidate=placement(anchor,di,dd,colors)
       if all(t.get(p,0)+n<=2 for p,n in candidate['t']) and all(p not in m or m[p]==mv for p,mv in candidate['m']):rows.append(candidate)
     rows.sort(key=lambda v:v['id']);assert rows==r['placements'] and r['certificate']['potential_count']==alln and r['certificate']['compatible_count']==len(rows) and r['complete'] is True
     querysets.append(dict(case=cid,retained_index=qi,potential=alln,compatible=len(rows),context_sha256=sha(q)))
    for k in ['potential_rows','omitted_rows','rows']:cost[(lane,k)]+=full['provider'][k]
  if full['verified']:
   pos=full['positive'];assert artifact(pos['ref'])=={k:v for k,v in pos.items() if k!='ref'}
   assert pos['verified'] and all(pos[k]['status']=='VERIFIED' for k in ['tree_audit','lowering_audit','coarse_host_check','original_host_check'])
   dec=pos['decoded'];cp=pos['coarse_proof'];op=pos['original_proof'];tree=dec['tree'];assert dec['status']=='UNVERIFIED_CERTIFICATE' and dec['proof']==cp and dec['target']==c['goal'] and tree['node_count']==len(cp)
   assert pos['tree_audit']['proof']==cp and pos['tree_audit']['details']['candidate_bindings']==tree['placements'] and pos['tree_audit']['details']['site_to_line']==tree['site_to_line']
   by=dict(tree['site_to_line']);assert by['']==len(cp)-1 and cp[-1]['formula']==op[-1]['formula']==original['goal']
   allsites=set(by);assert allsites=={json.loads(cid0)[0] for cid0 in tree['selected']};assert tree['max_used_depth']==max(map(len,allsites))<=8
   for selected in tree['selected']:
    site,di=json.loads(selected);v=dd[di];line=cp[by[site]];assert tree['placements'][tree['selected'].index(selected)]==placement(site,di,dd,colors)
    assert line['formula']==c['logical_basis']['formulas'][v['out']]
    for j,fid in enumerate(v['prem']):assert site+str(j) in by and by[site+str(j)]<by[site] and cp[by[site+str(j)]]['formula']==c['logical_basis']['formulas'][fid]
    if v['kind']=='ZERO':assert line==next(z['line'] for z in c['zero_instances'] if z['id']==v['zero'])
    if v['kind']=='MP':assert line['antecedent']==by[site+'0'] and line['implication']==by[site+'1'] and cp[line['implication']]['formula']==['imp',cp[line['antecedent']]['formula'],line['formula']]
    if v['kind']=='GEN':assert line['source']==by[site+'0'] and line['variable']==v['variable'] and line['formula']==['all',line['variable'],cp[line['source']]['formula']]
   total=collections.Counter(dict(model['seed']['t'])) if lane!='MATCHED_DEPTH_TREE_CONTROL' else collections.Counter({'':1});marks={}
   for pl in tree['placements']:
    for pt,n in pl['t']:total[pt]+=n
    for pt,mv in pl['m']:marks.setdefault(pt,set()).add(mv)
   assert all(total[site]==2 and len(marks[site])==1 for site in allsites) and tree['totals']==[[site,2] for site in sorted(allsites)]
   if lane!='MATCHED_DEPTH_TREE_CONTROL':assert full['result']['selected']==tree['selected'] and full['result']['certificate']['placements']==tree['placements'] and full['result']['certificate']['totals']==tree['totals'] and full['result']['certificate']['marks']==tree['marks']
   else:assert full['result']['proof']==cp and full['result']['details']['selected']==tree['selected'] and full['result']['details']['minimum_tree_nodes']==len(cp)
   low=pos['lowering'];lv=low['value'];assert low['status']=='COMPLETE' and lv['proof']==op and lv['theory']==original['theory'] and lv['goal']==original['goal']
   assert len(lv['coarse_to_primitive'])==len(cp) and pos['lowering_audit']['details']['proof_sha256']==sha(op)
   for i,j in enumerate(lv['coarse_to_primitive']):
    if j is not None:assert type(j) is int and 0<=j<len(op) and cp[i]['formula']==op[j]['formula']
   used=[]
   for ex in lv['lemma_expansions']:
    lemma=L[ex['lemma_id']];cr=ex['coarse_row'];assert cp[cr]['rule']=='axiom' and cp[cr]['name']==lemma['name'] and cp[cr]['formula']==lemma['goal'] and len(ex['primitive_rows'])==len(lemma['proof']);used.append(ex['lemma_id'])
    for j,k in enumerate(ex['primitive_rows']):
     if k is not None:assert lemma['proof'][j]['formula']==op[k]['formula']
   primitive_axioms=sorted({line['name'] for line in op if line['rule']=='axiom'})
   for line in op:
    if line['rule']=='axiom':assert line['formula']==original['theory']['axioms'][line['name']]
   for kind,proof in [('coarse',cp),('original',op)]:
    host=pos[kind+'_host_check'];assert host['status']=='VERIFIED' and host['checked_lines']==len(proof) and host['limits']==E['design']['limits']['checker']
    assert host['rule_counts']==dict(collections.Counter(line['rule'] for line in proof))|{k:0 for k in host['rule_counts'] if k not in {line['rule'] for line in proof}}
    C['host_checks']+=1
   C['positive_chains']+=1;C['coarse_lines']+=len(cp);C['original_lines']+=len(op);cost[(lane,'positive_verification_seconds')]+=pos['verification_seconds']
   rr['lanes'][lane].update(coarse_lines=len(cp),original_lines=len(op),primitive_axioms=primitive_axioms,imported_lemma_ids=used)
   proofs.append(dict(case=cid,lane=lane,coarse_sha256=sha(cp),original_sha256=sha(op),coarse_lines=len(cp),original_lines=len(op),maximum_depth=tree['max_used_depth'],selected=tree['selected'],primitive_axioms=primitive_axioms,lemma_expansions=lv['lemma_expansions'],coarse_to_primitive=lv['coarse_to_primitive'],coarse_proof=cp,original_proof=op))
 if current[LANES[0]]['verified']:
  a,b=current[LANES[0]]['positive'],current[LANES[1]]['positive'];assert current[LANES[1]]['verified'] and a['decoded']['tree']==b['decoded']['tree'] and a['coarse_proof']==b['coarse_proof'] and a['original_proof']==b['original_proof'];C['same_common_GCTS_trees_and_proofs']+=1
 assert current[LANES[1]]['status']!='SAT' or current[LANES[2]]['status']!='NOT_DERIVABLE'
 assert current[LANES[0]]['factory']['value']==current[LANES[1]]['factory']['value'] and current[LANES[0]]['model']==current[LANES[1]]['model']
 if current[LANES[2]]['status']=='NOT_DERIVABLE':
  # Independent finite producer-tree recurrence on the saved complete catalogue;
  # only certify the FIVE actual negative outcomes, never resolve censored lanes.
  inf=None;prev=[None]*len(colors)
  for z in c['zero_instances']:prev[z['formula_id']]=1
  tables=[prev]
  for depth in range(1,9):
   nxt=list(tables[0])
   for v in dd.values():
    if v['prem'] and all(prev[fid] is not None for fid in v['prem']):
     n=1+sum(prev[fid] for fid in v['prem']);out=v['out'];nxt[out]=n if nxt[out] is None else min(nxt[out],n)
   tables.append(nxt);prev=nxt
  assert all(t[c['goal_id']] is None for t in tables)
  negative.append(dict(case=cid,formulas=len(colors),definitions=len(dd),depth=8,goal_minimum_by_depth=[t[c['goal_id']] for t in tables],full_table_sha256=sha(tables),full_table_entries=sum(len(t) for t in tables),scope='Exact declared finite producer catalogue/depth only; no original-theory/unrestricted negative.'))
 rows.append(rr)
assert C['positive_chains']==22 and C['same_common_GCTS_trees_and_proofs']==5 and len(negative)==5 and C['host_checks']==44
assert W['outer_public_calls']['fol_checker.check']==48 and O['worker_terminal']['public_calls']==W['outer_public_calls']
assert C[('EAGER_POINT_LEX','SAT')]==5 and C[('EAGER_POINT_LEX','UNKNOWN')]==10 and C[('INDEXED_POINT_LEX','SAT')]==8 and C[('INDEXED_POINT_LEX','UNKNOWN')]==7 and C[('MATCHED_DEPTH_TREE_CONTROL','DERIVABLE')]==9 and C[('MATCHED_DEPTH_TREE_CONTROL','NOT_DERIVABLE')]==5 and C[('MATCHED_DEPTH_TREE_CONTROL','UNKNOWN')]==1
failed_ref=P['metadata']['failed_main001_original'];failed=json.loads(guard(failed_ref));assert failed['status']=='UNADMITTED' and failed['native_exit']==1;failed_ob=json.loads(guard(failed['observer']));assert failed_ob['status']=='UNADMITTED' and len(failed_ob['files'])==4
for q in failed_ob['files']:guard(q)
qsummary={str(k):v for k,v in C.items()};costsummary={str(k):v for k,v in cost.items()}
support=save('IP-study002-complete-independent-passive-mathematical-support-v1.json',dict(schema='IP-study002-complete-independent-passive-mathematical-support-v1',status='PASS',observer=ref(A/'observer-result.json'),worker=O['worker_terminal']['result'],original_exit=ref(R/'study-002.original-tool-exit-v1.json'),all_83_artifacts=W['artifacts'],all_case_associations=rows,all_actual_boundary_images=images,all_22_positive_chains=proofs,all_five_actual_finite_negative_checks=negative,all_retained_index_query_sets=querysets,all_event_and_rollback_extents=extents,counts=qsummary,costs=costsummary,failed001=dict(original=failed_ref,observer=failed['observer'],status='UNADMITTED',whole_observer_seconds=failed_ob['whole_observer_seconds'],peak_bytes=failed_ob['wait4_peak_bytes']),scope='Passive complete saved bytes/arithmetic/direct certificate bindings only; no project helper/kernel/search/VM/qualifier re-execution. Actual censored outcomes never promoted.'))
review=save('IP-study002-complete-independent-passive-mathematical-review-v1.json',dict(schema='IP-study002-complete-independent-passive-mathematical-review-v1',status='PASS',blockers=[],support=support,observer=ref(A/'observer-result.json'),original_exit=ref(R/'study-002.original-tool-exit-v1.json'),
 cohort=dict(cases=15,method_positions=45,artifacts=83,positive_chains=22,fresh_coarse_original_host_checks=44,fresh_bank_host_checks=4,fresh_C1_checks=0,eager=dict(verified=5,unknown=10),indexed=dict(verified=8,unknown=7),matched_depth_control=dict(verified=9,finite_not_derivable=5,unknown=1)),
 mathematical_findings=['All fifteen reused compiled/generation/preparation inputs remain exact, with the same complete formula/zero/MP/GEN inventory, model identity/depth8 and eligible four-lemma-bank extension. All30factories COMPLETE and independently VERIFIED; no hidden producer or parent-contact removal.','All actual nonnull point boundary images independently reconstructed for full root-active closure, exact t/m and refcounts, generations, current globally legal domains, weighted incidence and registered dependencies. Main per-change states are not available and are not synthesized.','All22actual positive selected/realized proof trees match CIDs, site roles, postorder references, point certificates, target formula, coarse/primitive mappings and bank expansion records. All44fresh coarse/original host checks plus4bank host checks are retained VERIFIED. No new Native C1 execution occurred.','The five common eager/indexed successes have exactly identical full selected trees and coarse/original proofs. Indexed additionally certifies right-two, successor-wrapped-two-ones and capture-sensitive incidence; all are known regression goals rather than novel theorems.','No indexed SAT contradicts any of the five actual finite-depth control negatives. The five negative min-expanded-tree recurrences were independently checked on the saved finite catalogues through depth8; only that conditional finite model is negative.','Every point refusal is UNKNOWN: eager8MAX_CANDIDATES+2WALL; indexed7MAX_WORK. The control capture-sensitive position is WALL UNKNOWN, preserved rather than converted to a failed theorem or to the auditor-computed result.','Retained event/rollback/query prefixes are honestly scoped. Full stream hashes are recomputed only for complete retained streams; no missing suffix or original post-budget final state is invented.'],
 cost_assessment=dict(eager_cold_search_seconds=cost[('EAGER_POINT_LEX','cold_search_seconds')],indexed_cold_search_seconds=cost[('INDEXED_POINT_LEX','cold_search_seconds')],control_cold_search_seconds=cost[('MATCHED_DEPTH_TREE_CONTROL','cold_search_seconds')],historical_preparation_seconds=E['design']['historical_preparation_seconds'],historical_donor_seconds=E['design']['historical_donor_acquisition_seconds'],fresh_bank_host_seconds=E['fresh_bank_check_seconds'],experiment_seconds=E['seconds'],observer_seconds=O['whole_observer_seconds'],fresh_child_peak_bytes=O['wait4_peak_bytes'],interpretation='Exact index reduces incompatible payload materialization and reaches more point certificates within registered-candidate caps. It does not reduce aggregate cold search time over all15positions in this run: indexed12.8465s versus eager11.7319s, while the control totals6.0623s and verifies9goals. Per-lane factory construction is inside these windows; independent factory/tree/lowering/host proof checks are outside and separately retained. Nested provider/engine timings are not added again.'),
 isolated_boundary_case=dict(case='heldout-incidence-capture-sensitive-specialization',indexed='SAT,1.9891482499951962seconds,13coarse/18original lines',control='WALL UNKNOWN,2.012091540993424seconds',scope='One isolated finite-budget completion difference, not broad superiority, unrestricted completeness or theorem novelty.'),
 assurance_limits=['These are the same finite regression catalogues; no RL, new learned markings, unseen-target claim, full PA/Hilbert geometry, universal Wang palette or unrestricted FOL result.','The minimum-expanded-tree control and GCTS can differ in primitive proof length. Nested typing remains point12coarse→6original versus control4→9; no primitive-cost optimality is implied.','Current coarse/original proof assurance is fresh independent host checking and Source-reviewed certified lowering; historical C1 evidence is labelled historical.','Main graph assurance is qualified Source plus returned boundary images and independently verified certificates; tiny full observation qualification is not a full main transition trace.','Failed001native1/allfiveavailablefiles/cost remain separately UNADMITTED. Only reporting filename/actual-directory identity changed before a fresh authorized002; no failed-prefix pooling or outcome-based scientific tuning.'],
 activity=dict(project_or_source_function_calls=0,kernel_or_VM_replay=0,network_Git_calls=0,evidence_changes=0,writes='Separate passive review/support only; tools idle after receipt.')))
print(json.dumps(dict(review=review,support=support,counts=qsummary,costs=costsummary),sort_keys=True))
