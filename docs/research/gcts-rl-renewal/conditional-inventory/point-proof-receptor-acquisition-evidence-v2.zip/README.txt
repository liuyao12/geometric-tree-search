Notation-only successor. Five counts now use LaTeX. All scientific bytes preserved; no research execution.
