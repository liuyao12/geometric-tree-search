"""Independent finite graph-copy controls; call only in a reviewed Root actual.

The reference enumerates literal candidate support against a separate replayed
point state. It never uses Graph update/decision, Model alignment/dependencies,
or State legality to derive the expected answer. No fixture runs on import.
"""

from collections import Counter

VERSION = 'literal-graph-copy-reference-controls-v1'

FIXTURES = {
    'fractions': {
        'roots': (((0, 0), 0), ((4, 0), 0)), 'totals': (), 'marks': (),
        'allowed': ((0, 0), (4, 0)),
        'candidates': (
            ((0,), (((0, 0), 6),), ()),
            ((1,), (((0, 0), 6),), ()),
            ((2,), (((0, 0), 12),), ()),
            ((3,), (((4, 0), 6),), ()),
            ((4,), (((4, 0), 6),), ()),
            ((5,), (((4, 0), 12),), ())),
    },
    'shared-support': {
        'roots': (((0, 0), 0), ((4, 0), 0)), 'totals': (), 'marks': (),
        'allowed': ((0, 0), (4, 0)),
        'candidates': (
            ((0,), (((0, 0), 6), ((4, 0), 6)), ()),
            ((1,), (((0, 0), 12),), ()),
            ((2,), (((4, 0), 12),), ()),
            ((3,), (((0, 0), 6),), ()),
            ((4,), (((4, 0), 6),), ())),
    },
    'growth': {
        'roots': (((0, 0), 3),), 'totals': (), 'marks': (), 'allowed': None,
        'candidates': (
            ((0,), (((0, 0), 6), ((4, 0), 6)), ()),
            ((1,), (((0, 0), 6),), ()),
            ((2,), (((4, 0), 6),), ()),
            ((3,), (((8, 0), 12),), ()),
            ((4,), (((4, 0), 12),), ())),
    },
    'distant-mark': {
        'roots': (((0, 0), 0), ((4, 0), 0)), 'totals': (), 'marks': (),
        'allowed': ((0, 0), (4, 0)),
        'candidates': (
            ((0,), (((0, 0), 12),), (((90, 90), 0),)),
            ((1,), (((0, 0), 12),), (((90, 90), 1),)),
            ((2,), (((4, 0), 12),), (((90, 90), 0),)),
            ((3,), (((4, 0), 12),), (((90, 90), 1),)),
            ((4,), (((4, 0), 12),), ())),
    },
    'explicit-zero': {
        'roots': (((0, 0), 0), ((4, 0), 0)),
        'totals': (((0, 0), 0),), 'marks': (((90, 90), 0),),
        'allowed': ((0, 0), (4, 0)),
        'candidates': (
            ((0,), (((0, 0), 12),), (((90, 90), 0),)),
            ((1,), (((0, 0), 12),), (((90, 90), 1),)),
            ((2,), (((4, 0), 12),), (((90, 90), 0),)),
            ((3,), (((4, 0), 12),), (((90, 90), 1),)),
            ((4,), (((4, 0), 12),), ())),
    },
    'dead-forced': {
        'roots': (((0, 0), 0), ((4, 0), 9)), 'totals': (), 'marks': (),
        'allowed': ((0, 0), (4, 0)),
        'candidates': (((0,), (((0, 0), 12),), ()),),
    },
    'forced-branch': {
        'roots': (((0, 0), 0), ((4, 0), 9)), 'totals': (), 'marks': (),
        'allowed': ((0, 0), (4, 0)),
        'candidates': (
            ((0,), (((0, 0), 12),), ()),
            ((1,), (((0, 0), 12),), ()),
            ((2,), (((0, 0), 12),), ()),
            ((3,), (((4, 0), 12),), ())),
    },
    'generation-first': {
        'roots': (((0, 0), 0), ((4, 0), 1)), 'totals': (), 'marks': (),
        'allowed': ((0, 0), (4, 0)),
        'candidates': (
            ((0,), (((0, 0), 12),), ()),
            ((1,), (((0, 0), 12),), ()),
            ((2,), (((0, 0), 12),), ()),
            ((3,), (((4, 0), 12),), ()),
            ((4,), (((4, 0), 12),), ())),
    },
    'generation-tie': {
        'roots': (((0, 0), 1), ((4, 0), 1)), 'totals': (), 'marks': (),
        'allowed': ((0, 0), (4, 0)),
        'candidates': (
            ((0,), (((0, 0), 12),), ()),
            ((1,), (((0, 0), 12),), ()),
            ((2,), (((0, 0), 12),), ()),
            ((3,), (((4, 0), 12),), ()),
            ((4,), (((4, 0), 12),), ())),
    },
    'empty': {'roots': (), 'totals': (), 'marks': (), 'allowed': (),
              'candidates': ()},
}

CONTROLS = (
    {'id': 'top-dictionaries-private', 'fixture': 'fractions',
     'actions': (('copy', 'r', 'left'), ('copy', 'r', 'right'))},
    {'id': 'child-domain-detaches', 'fixture': 'fractions',
     'actions': (('copy', 'r', 'left'), ('place', 'left', (0,), False))},
    {'id': 'parent-updates-after-copy', 'fixture': 'fractions',
     'actions': (('copy', 'r', 'left'), ('copy', 'left', 'grand'),
                 ('place', 'r', (0,), False), ('update', 'r', 'all'))},
    {'id': 'siblings-and-grandchild-diverge', 'fixture': 'fractions',
     'actions': (('copy', 'r', 'left'), ('copy', 'r', 'right'),
                 ('place', 'left', (0,), False), ('copy', 'left', 'grand'),
                 ('place', 'right', (2,), False), ('place', 'grand', (3,), False),
                 ('place', 'left', (3,), False))},
    {'id': 'later-shared-domain-detaches-again', 'fixture': 'fractions',
     'actions': (('copy', 'r', 'left'), ('place', 'left', (0,), False),
                 ('copy', 'left', 'grand'), ('place', 'left', (3,), False),
                 ('update', 'left', 'empty'), ('update', 'left', 'all'))},
    {'id': 'fractional-capacity-and-empty', 'fixture': 'fractions',
     'actions': (('copy', 'r', 'left'), ('place', 'left', (0,), False),
                 ('place', 'left', (1,), False), ('place', 'left', (3,), False),
                 ('place', 'left', (4,), False)),
     'final_anchor': ('empty', None, ())},
    {'id': 'completed-root-multiple-support-edge', 'fixture': 'shared-support',
     'actions': (('copy', 'r', 'left'), ('copy', 'r', 'right'),
                 ('place', 'left', (1,), False), ('copy', 'right', 'grand'),
                 ('place', 'r', (2,), False), ('place', 'grand', (0,), False),
                 ('update', 'left', 'all'))},
    {'id': 'new-frontier-and-generation', 'fixture': 'growth',
     'actions': (('copy', 'r', 'left'), ('place', 'left', (0,), False),
                 ('place', 'left', (1,), False), ('place', 'left', (2,), False))},
    {'id': 'disconnected-and-seed-generations', 'fixture': 'growth',
     'actions': (('copy', 'r', 'left'), ('copy', 'r', 'right'),
                 ('place', 'left', (3,), False), ('place', 'right', (0,), True))},
    {'id': 'mark-only-distant-zero-one', 'fixture': 'distant-mark',
     'actions': (('copy', 'r', 'left'), ('copy', 'r', 'right'),
                 ('place', 'left', (0,), False), ('place', 'right', (1,), False))},
    {'id': 'explicit-zero-is-not-absent', 'fixture': 'explicit-zero',
     'initial_anchor': ('forced', (0, 0), ((0,),)),
     'actions': (('copy', 'r', 'left'), ('place', 'left', (0,), False))},
    {'id': 'boundary-release-restores-existing-domain-members', 'fixture': 'explicit-zero',
     'actions': (('copy', 'r', 'left'), ('boundary-mark', 'left', (90, 90), None),
                 ('copy', 'left', 'grand'), ('boundary-mark', 'left', (90, 90), 1),
                 ('update', 'left', 'all'))},
    {'id': 'global-dead-beats-forced', 'fixture': 'dead-forced',
     'initial_anchor': ('dead', (4, 0), ()), 'actions': ()},
    {'id': 'global-forced-beats-early-branch', 'fixture': 'forced-branch',
     'initial_anchor': ('forced', (4, 0), ((3,),)), 'actions': ()},
    {'id': 'generation-beats-smaller-degree', 'fixture': 'generation-first',
     'initial_anchor': ('branch', (0, 0), ((0,), (1,), (2,))), 'actions': ()},
    {'id': 'degree-breaks-generation-tie', 'fixture': 'generation-tie',
     'initial_anchor': ('branch', (4, 0), ((3,), (4,))), 'actions': ()},
    {'id': 'empty-copy-repeat-update', 'fixture': 'empty',
     'initial_anchor': ('empty', None, ()),
     'actions': (('copy', 'r', 'left'), ('update', 'left', 'empty'))},
    {'id': 'RuntimeError-identity-parent-safe', 'fixture': 'shared-support',
     'actions': (('copy', 'r', 'left'), ('copy', 'r', 'right'),
                 ('fault-update', 'left', (1,), 'RuntimeError'))},
    {'id': 'ValueError-identity-parent-safe', 'fixture': 'shared-support',
     'actions': (('copy', 'r', 'left'), ('copy', 'r', 'right'),
                 ('fault-update', 'left', (1,), 'ValueError'))},
    {'id': 'StopIteration-identity-parent-safe', 'fixture': 'shared-support',
     'actions': (('copy', 'r', 'left'), ('copy', 'r', 'right'),
                 ('fault-update', 'left', (1,), 'StopIteration'))},
    {'id': 'missing-inverse-edge-detected', 'fixture': 'shared-support',
     'corruption': 'missing-edge', 'actions': ()},
    {'id': 'missing-forward-member-detected', 'fixture': 'shared-support',
     'corruption': 'missing-domain', 'actions': ()},
)


def _need(condition, message):
    if not condition:
        raise AssertionError(message)


def _plain(value, check):
    check()
    if value is None or type(value) in (str, int, bool):
        return value
    if type(value) in (list, tuple):
        out = []
        for item in value:
            out.append(_plain(item, check))
        return out
    if type(value) is dict:
        out = {}
        for key, item in value.items():
            _need(type(key) is str, 'ordinary JSON field name')
            out[key] = _plain(item, check)
        return out
    raise AssertionError('nonliteral control evidence')


def _point(value):
    _need(type(value) is tuple and len(value) == 2,
          'tiny exact point pair')
    _need(all(type(x) is int for x in value), 'integer point, never bool')


def _key(value):
    _need(type(value) is tuple and len(value) == 1 and type(value[0]) is int,
          'literal tiny candidate key')


def _map_rows(mapping, check):
    _need(type(mapping) is dict, 'private ordinary state dictionary')
    rows = []
    for point, value in sorted(mapping.items()):
        check(); _point(point)
        _need(type(value) is int, 'exact state integer, never bool')
        rows.append([list(point), value])
    return rows


def _state_view(state, check):
    check()
    _need(set(state.__dict__) == {'totals', 'marks', 'generations', 'roots',
          'selected', 'order', 'tile_generations', 'allowed_points'},
          'all State fields included')
    _need(type(state.selected) is set and type(state.order) is list and
          type(state.tile_generations) is list, 'complete State sequence fields')
    for key in state.selected:
        check(); _key(key)
    for key in state.order:
        check(); _key(key)
    _need(all(type(x) is int for x in state.tile_generations),
          'exact tile generations')
    allowed = state.allowed_points
    _need(allowed is None or type(allowed) is frozenset, 'immutable allowed set')
    if allowed is not None:
        for point in allowed:
            check(); _point(point)
    return {'totals': _map_rows(state.totals, check),
            'marks': _map_rows(state.marks, check),
            'generations': _map_rows(state.generations, check),
            'roots': _map_rows(state.roots, check),
            'selected': _plain(sorted(state.selected), check),
            'order': _plain(state.order, check),
            'tile_generations': list(state.tile_generations),
            'allowed_points': None if allowed is None else _plain(sorted(allowed), check)}


def _graph_view(graph, check):
    check(); _need(type(graph.domains) is dict and type(graph.edges) is dict,
                   'ordinary top-level Graph dictionaries')
    domains = []; edges = []
    for point, keys in sorted(graph.domains.items()):
        check(); _point(point); _need(type(keys) is set, 'domain set')
        for key in keys:
            check(); _key(key)
        domains.append([list(point), _plain(sorted(keys), check)])
    for key, points in sorted(graph.edges.items()):
        check(); _key(key); _need(type(points) is set, 'edge set')
        for point in points:
            check(); _point(point)
        edges.append([list(key), _plain(sorted(points), check)])
    return {'domains': domains, 'edges': edges}


class _TinyModel:
    def __init__(self, fixture, points, check):
        self.check = check; self.fail = None; self.cache = {}
        self.dependencies = {}; self.metrics = Counter()
        for key, occupancy, marks in fixture['candidates']:
            check(); _key(key)
            self.cache[key] = points.Placement(key, occupancy, marks, ())
            for point, unused in occupancy + marks:
                check(); self.dependencies.setdefault(point, set()).add(key)

    def placement(self, key):
        self.check()
        if self.fail is not None:
            raise self.fail
        return self.cache[key]

    def alignments(self, point):
        self.check(); out = []
        for key, candidate in self.cache.items():
            self.check()
            if any(p == point for p, unused in candidate.occupancy):
                out.append(key)
        return tuple(out)


def _records(fixture, check):
    records = {}
    for key, occupancy, marks in fixture['candidates']:
        check(); _key(key); _need(key not in records, 'unique literal candidates')
        _need(occupancy and len(dict(occupancy)) == len(occupancy),
              'nonempty distinct positive t-support')
        _need(len(dict(marks)) == len(marks), 'single assigned marking at each point')
        for point, value in occupancy:
            check(); _point(point)
            _need(type(value) is int and 0 < value <= 12, 'literal positive t-units')
        for point, value in marks:
            check(); _point(point); _need(type(value) is int, 'literal scalar m')
        records[key] = (occupancy, marks)
    return records


def _allowed(record, reference):
    occupancy, marks = record
    if reference['allowed'] is not None:
        if any(point not in reference['allowed'] for point, unused in occupancy):
            return False
    if any(reference['totals'].get(point, 0) + value > 12
           for point, value in occupancy):
        return False
    return all(point not in reference['marks'] or reference['marks'][point] == value
               for point, value in marks)


def _reference(fixture, history, check):
    """Replay literal placements, then enumerate every literal candidate afresh."""
    check(); records = _records(fixture, check)
    roots = dict(fixture['roots'])
    ref = {'totals': dict(fixture['totals']), 'marks': dict(fixture['marks']),
           'generations': roots.copy(), 'roots': roots, 'selected': set(),
           'order': [], 'tile_generations': [],
           'allowed': None if fixture['allowed'] is None else set(fixture['allowed'])}
    for key, seed in history:
        check(); _need(key not in ref['selected'] and _allowed(records[key], ref),
                       'reference history is a legal literal partial tiling')
        occupancy, marks = records[key]
        incident = []
        for point, unused in occupancy:
            check()
            if point in ref['generations']:
                incident.append(ref['generations'][point])
        generation = 0 if seed or not incident else min(incident) + 1
        for point, value in occupancy:
            check(); ref['totals'][point] = ref['totals'].get(point, 0) + value
            old = ref['generations'].get(point, generation)
            root = ref['roots'].get(point, generation)
            ref['generations'][point] = min(old, generation, root)
        for point, value in marks:
            check(); ref['marks'][point] = value
        ref['selected'].add(key); ref['order'].append(key)
        ref['tile_generations'].append(generation)
    frontier = set()
    for point in set(ref['totals']) | set(ref['roots']):
        check()
        if ref['totals'].get(point, 0) < 12:
            frontier.add(point)
    domains = {point: set() for point in frontier}; edges = {}
    for key, record in records.items():
        check()
        if key in ref['selected'] or not _allowed(record, ref):
            continue
        support = set()
        for point, unused in record[0]:
            check()
            if point in frontier:
                support.add(point); domains[point].add(key)
        if support:
            edges[key] = support
    dead = sorted(point for point in frontier if not domains[point])
    forced = sorted(point for point in frontier if len(domains[point]) == 1)
    if dead:
        decision = ('dead', dead[0], ())
    elif forced:
        point = forced[0]; decision = ('forced', point, tuple(sorted(domains[point])))
    elif not frontier:
        decision = ('empty', None, ())
    else:
        point = min(frontier, key=lambda p: (ref['generations'].get(p, ref['roots'].get(p, 0)),
                                            len(domains[p]), p))
        decision = ('branch', point, tuple(sorted(domains[point])))
    state_view = {'totals': _map_rows(ref['totals'], check),
                  'marks': _map_rows(ref['marks'], check),
                  'generations': _map_rows(ref['generations'], check),
                  'roots': _map_rows(ref['roots'], check),
                  'selected': _plain(sorted(ref['selected']), check),
                  'order': _plain(ref['order'], check),
                  'tile_generations': ref['tile_generations'],
                  'allowed_points': None if ref['allowed'] is None else _plain(sorted(ref['allowed']), check)}
    graph_view = {'domains': [[list(p), _plain(sorted(domains[p]), check)] for p in sorted(domains)],
                  'edges': [[list(k), _plain(sorted(edges[k]), check)] for k in sorted(edges)]}
    fingerprint = (tuple((p, tuple(sorted(domains[p]))) for p in sorted(domains)),
                   tuple((k, tuple(sorted(edges[k]))) for k in sorted(edges)))
    return state_view, graph_view, decision, fingerprint


def _audit(fixture, node, check, mismatch=None):
    check(); fixture = node.get('reference_fixture', fixture)
    expected_state, expected_graph, decision, fingerprint = _reference(fixture, node['history'], check)
    actual_state = _state_view(node['state'], check)
    actual_graph = _graph_view(node['graph'], check)
    if actual_state != expected_state or actual_graph != expected_graph:
        if mismatch is not None:
            raise mismatch
        raise AssertionError('full independent tiny state/domain/inverse-edge mismatch')
    check(); actual_decision = node['graph'].decision(node['state']); check()
    _need(_plain(actual_decision, check) == _plain(decision, check), 'literal scheduler correspondence')
    _need(node['graph'].fingerprint() == fingerprint, 'complete independent graph fingerprint')
    return {'state': actual_state, 'graph': actual_graph, 'decision': _plain(decision, check)}


def _initial(points, fixture, check):
    check(); roots = dict(fixture['roots'])
    state = points.State(totals=dict(fixture['totals']), marks=dict(fixture['marks']),
                         generations=roots.copy(), roots=roots.copy(),
                         allowed_points=None if fixture['allowed'] is None else frozenset(fixture['allowed']))
    return state


def _all_changed(fixture, check):
    changed = set()
    for unused, occupancy, marks in fixture['candidates']:
        check()
        for point, unused_value in occupancy + marks:
            check(); changed.add(point)
    return changed


def _record(nodes, fixture, snapshots, check):
    references = {}
    for name, node in nodes.items():
        check()
        if node.get('faulted'):
            continue
        value = _audit(fixture, node, check)
        found = None
        for index, prior in enumerate(snapshots):
            check()
            if value == prior:
                found = index; break
        if found is None:
            found = len(snapshots); snapshots.append(value)
        references[name] = found
    return references


def run_graph_copy_controls(points, *, check):
    """Finite controls and full literal evidence; no experiment authority here."""
    check(); _need(type(points.CAPACITY) is int and points.CAPACITY == 12,
                   'declared integer point capacity')
    _need(len(CONTROLS) == 22 and len(FIXTURES) == 10, 'frozen finite control bank')
    results = []; checkpoints = 0
    def tick():
        nonlocal checkpoints
        check(); checkpoints += 1
    for control in CONTROLS:
        tick(); fixture = FIXTURES[control['fixture']]
        original_fixture = _plain(fixture, tick)
        model = _TinyModel(fixture, points, tick); state = _initial(points, fixture, tick)
        graph = points.Graph(model, state); tick()
        nodes = {'r': {'state': state, 'graph': graph, 'history': []}}
        snapshots = []; events = []
        initial_refs = _record(nodes, fixture, snapshots, tick)
        if 'initial_anchor' in control:
            expected = _plain(control['initial_anchor'], tick)
            _need(snapshots[initial_refs['r']]['decision'] == expected,
                  'independently authored initial decision anchor')
        for action in control['actions']:
            tick(); op, name = action[:2]; node = nodes[name]
            _need(not node.get('faulted'), 'never resume or rescue a faulted graph')
            event = {'action': _plain(action, tick)}
            if op == 'copy':
                destination = action[2]; _need(destination not in nodes, 'new snapshot name')
                child_state = node['state'].copy(); child_graph = node['graph'].copy(); tick()
                _need(child_graph is not node['graph'] and child_graph.domains is not node['graph'].domains
                      and child_graph.edges is not node['graph'].edges, 'private top dictionaries')
                shared_domains = shared_edges = 0
                for point, values in node['graph'].domains.items():
                    tick(); shared_domains += int(child_graph.domains[point] is values)
                for key, values in node['graph'].edges.items():
                    tick(); shared_edges += int(child_graph.edges[key] is values)
                event['observed_shared_nested_sets'] = {'domains': shared_domains, 'edges': shared_edges}
                nodes[destination] = {'state': child_state, 'graph': child_graph,
                                      'history': list(node['history']),
                                      'reference_fixture': dict(node.get('reference_fixture', fixture))}
            elif op in ('place', 'fault-update'):
                key = action[2]; seed = action[3] if op == 'place' else False
                reference_fixture = node.get('reference_fixture', fixture)
                _reference(reference_fixture, node['history'] + [(key, seed)], tick)
                candidate = model.cache[key]
                changed = node['state'].place(candidate, seed=seed); tick()
                expected_changed = {p for p, unused in candidate.occupancy + candidate.marks}
                _need(changed == expected_changed, 'complete t/m change notification')
                node['history'].append((key, seed))
                if op == 'place':
                    node['graph'].update(model, node['state'], changed); tick()
                else:
                    error_type = {'RuntimeError': RuntimeError, 'ValueError': ValueError,
                                  'StopIteration': StopIteration}[action[3]]
                    sentinel = error_type('exact owned tiny injected callback identity')
                    model.fail = sentinel; received = None
                    try:
                        node['graph'].update(model, node['state'], changed)
                    except BaseException as error:
                        if error is not sentinel:
                            raise
                        received = error
                    finally:
                        model.fail = None
                    tick(); _need(received is sentinel, 'exact foreign callback identity propagated')
                    node['faulted'] = True
                    expected_state = _reference(reference_fixture, node['history'], tick)[0]
                    _need(_state_view(node['state'], tick) == expected_state, 'faulted child full state retained')
                    event['expected_callback_identity_propagated'] = True
                    event['faulted_child_not_resumed_or_admitted'] = True
                    event['faulted_child_diagnostic_only'] = {
                        'state': _state_view(node['state'], tick),
                        'graph': _graph_view(node['graph'], tick), 'graph_complete': False}
            elif op == 'update':
                changed = set() if action[2] == 'empty' else _all_changed(fixture, tick)
                node['graph'].update(model, node['state'], changed); tick()
            elif op == 'boundary-mark':
                # Explicit alternative boundary input, with no selected tiles.
                # This exercises old-domain additions without changing search.
                point, value = action[2:]
                _need(not node['history'] and not node['state'].selected,
                      'boundary-context control has no placed prefix')
                _point(point); _need(value is None or type(value) is int, 'literal boundary m')
                reference_fixture = dict(node.get('reference_fixture', fixture))
                expected_marks = dict(reference_fixture['marks'])
                if value is None:
                    del expected_marks[point]
                    node['state'].marks.pop(point)
                else:
                    expected_marks[point] = value
                    node['state'].marks[point] = value
                reference_fixture['marks'] = tuple(sorted(expected_marks.items()))
                node['reference_fixture'] = reference_fixture
                node['graph'].update(model, node['state'], {point}); tick()
                event['declared_alternative_boundary_marks'] = _map_rows(expected_marks, tick)
            else:
                raise AssertionError('finite declared operation only')
            event['full_reference_equal_nodes'] = _record(nodes, fixture, snapshots, tick)
            events.append(event)
        if 'final_anchor' in control:
            _need(_audit(fixture, nodes['left'], tick)['decision'] == _plain(control['final_anchor'], tick),
                  'independently authored final scheduler anchor')
        if 'corruption' in control:
            tick(); sentinel = AssertionError('exact owned correspondence-negative sentinel')
            if control['corruption'] == 'missing-edge':
                graph.edges[(0,)] = graph.edges[(0,)] - {(0, 0)}
            else:
                graph.domains[(0, 0)] = graph.domains[(0, 0)] - {(0,)}
            received = None
            try:
                _audit(fixture, nodes['r'], tick, mismatch=sentinel)
            except BaseException as error:
                if error is not sentinel:
                    raise
                received = error
            tick(); _need(received is sentinel, 'deliberate missing incidence rejected')
            events.append({'deliberate_fresh_graph_corruption_detected': control['corruption'],
                           'invalid_graph_not_admitted': True})
        _need(_plain(fixture, tick) == original_fixture, 'literal fixture remains unchanged')
        results.append({'id': control['id'], 'fixture': control['fixture'],
                        'status': 'PASSED', 'complete': True,
                        'initial_nodes': initial_refs, 'snapshots': snapshots, 'events': events,
                        'model_metrics': dict(model.metrics)})
    check()
    return {'schema': VERSION, 'status': 'PASSED', 'complete': True,
            'control_count': len(results), 'fixture_count': len(FIXTURES),
            'fixtures': _plain(FIXTURES, tick), 'controls': results,
            'control_checkpoints': checkpoints,
            'scope': 'Finite independent literal point-state/domain/inverse-edge/scheduler and snapshot-isolation controls. '
                     'Synthetic errors and corruptions are declared negative diagnostics only. '
                     'No proof-search result, general COW theorem, fit estimate or phase profile. '
                     'All costs belong to the fresh Root case; external nested-set mutation after sharing is excluded.'}
