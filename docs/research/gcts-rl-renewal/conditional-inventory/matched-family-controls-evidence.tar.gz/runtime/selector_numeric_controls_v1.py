"""Independent literal numeric controls; no functions run on import.

All calls, including synthetic episodes, belong only inside a fresh reviewed
Root actual. Diagnostic rewards/weights below are never training inputs,
Native proof observations or exported policies. No evaluation formula occurs.
"""
import copy

ZERO = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
PACKET = [1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
ABSTAIN = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0]
TRAINING_IDS = ['numeric-00', 'numeric-01', 'numeric-02', 'numeric-03',
                'numeric-04', 'numeric-05', 'numeric-06', 'numeric-07',
                'numeric-08', 'numeric-09', 'numeric-10', 'numeric-11']

# Independent literal first two CPython Random(0) draws. No RNG runs here.
DECISION_0 = {'mode': 'rl', 'weights': ZERO,
              'features': [PACKET, ABSTAIN],
              'probabilities': [0.5, 0.5], 'scores': [0.0, 0.0],
              'draw': 0.8444218515250481, 'choice': 1}
DECISION_1 = {'mode': 'rl', 'weights': ZERO,
              'features': [PACKET, ABSTAIN],
              'probabilities': [0.5, 0.5], 'scores': [0.0, 0.0],
              'draw': 0.7579544029403025, 'choice': 1}


class NumericControlError(ValueError):
    pass


def _need(condition, message):
    if not condition:
        raise NumericControlError(message)


def _near(actual, expected, check):
    check()
    if type(expected) is list:
        _need(type(actual) is list and len(actual) == len(expected), 'numeric vector shape')
        for left, right in zip(actual, expected):
            _near(left, right, check)
    else:
        _need(type(actual) is float and type(expected) is float and
              abs(actual - expected) <= 1e-12, 'independent literal numeric value')


class _Draw:
    def __init__(self, value, check):
        self.value = value
        self.calls = 0
        self.check = check

    def random(self):
        self.check()
        self.calls += 1
        return self.value


def _episode(decisions, *, accepted=False, progress=0.0, attempts=0, validation=0):
    return dict(index=0, problem_id=TRAINING_IDS[0], decisions=copy.deepcopy(decisions),
                reward_components=dict(native_accepted=accepted,
                    max_live_root_fraction=progress, attempts=attempts,
                    validation_checks=validation))


def run_numeric_controls(selector, *, check):
    check()
    results = []
    initial = selector.initial_policy(check=check)
    _need(set(initial) == {'schema', 'weights', 'baseline', 'episodes', 'history'}
          and initial['episodes'] == 0 and initial['history'] == [], 'zero initial ledger')
    _near(initial['weights'], ZERO, check)
    _near(initial['baseline'], 0.0, check)
    checked = selector.verify_policy(initial, TRAINING_IDS, check=check)
    _need(checked['complete'] is True and checked['episodes'] == 0, 'initial policy replay')
    results.append(dict(id='zero-initial-policy', status='PASSED', actual=copy.deepcopy(initial)))

    for name, weights, rows, expected in [
        ('two-action-softmax', ZERO, [PACKET, ABSTAIN], [0.5, 0.5]),
        ('translated-equal-softmax', [2.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 2.0],
         [PACKET, ABSTAIN], [0.5, 0.5]),
        ('duplicate-features-preserve-actions', ZERO, [PACKET, PACKET, ABSTAIN],
         [0.3333333333333333, 0.3333333333333333, 0.3333333333333333]),
        ('sole-abstain-softmax', ZERO, [ABSTAIN], [1.0])]:
        check()
        actual = selector.probabilities(copy.deepcopy(weights), copy.deepcopy(rows), check=check)
        _near(actual, expected, check)
        results.append(dict(id=name, status='PASSED', expected=expected, actual=actual))

    for name, mode, rows, draw, expected_choice, expected_calls in [
        ('fixed-first-no-draw', 'fixed', [PACKET, ABSTAIN], 0.5, 0, 0),
        ('fixed-sole-abstain-no-draw', 'fixed', [ABSTAIN], 0.5, 0, 0),
        ('uniform-low-endpoint', 'uniform', [PACKET, ABSTAIN], 0.0, 0, 1),
        ('uniform-high-endpoint', 'uniform', [PACKET, ABSTAIN], 0.999999999999, 1, 1),
        ('rl-high-endpoint', 'rl', [PACKET, ABSTAIN], 0.999999999999, 1, 1)]:
        check()
        rng = _Draw(draw, check)
        actual = selector.choose(mode, list(ZERO), copy.deepcopy(rows), rng, check=check)
        _need(type(actual['choice']) is int and actual['choice'] == expected_choice
              and rng.calls == expected_calls, 'literal action and RNG use')
        if mode == 'fixed':
            _need(actual['draw'] is None, 'fixed policy makes no random draw')
        results.append(dict(id=name, status='PASSED', expected_choice=expected_choice,
                            random_calls=rng.calls, actual=actual))

    scenarios = [
        ('one-abstain-score-gradient', [DECISION_0], 0.0, True,
         [-0.025, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.025], 0.1),
        # Both literal draws choose ABSTAIN. Gradients SUM to (-1,...,+1).
        # Averaging would incorrectly produce (-.025,...,+.025), and fails.
        ('two-decisions-use-sum-not-mean', [DECISION_0, DECISION_1], 0.0, True,
         [-0.05, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.05], 0.1),
        ('pre-update-baseline-controls-advantage', [DECISION_0], 0.5, False,
         [0.0125, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, -0.0125], 0.45),
        ('no-decisions-zero-gradient', [], 0.0, True,
         [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0], 0.1)]
    for name, decisions, baseline, accepted, expected_weights, expected_baseline in scenarios:
        check()
        prior = copy.deepcopy(initial)
        prior['baseline'] = baseline
        original = copy.deepcopy(prior)
        actual = selector.update_policy(prior, _episode(decisions, accepted=accepted), check=check)
        _near(actual['weights'], expected_weights, check)
        _near(actual['baseline'], expected_baseline, check)
        _need(prior == original and actual['episodes'] == 1 and len(actual['history']) == 1,
              'immutable caller ledger and one completed synthetic episode')
        if baseline == 0.0:
            verification = selector.verify_policy(actual, TRAINING_IDS, check=check)
            _need(verification['complete'] is True and verification['episodes'] == 1,
                  'full zero-origin ledger check')
        results.append(dict(id=name, status='PASSED', expected_weights=expected_weights,
                            expected_baseline=expected_baseline, actual=actual,
                            scope='Synthetic one-step numeric control; not actual training or Native acceptance.'))

    actual_reward = selector.reward(dict(native_accepted=False,
        max_live_root_fraction=1.0, attempts=600, validation_checks=20000), check=check)
    _near(actual_reward, 0.03, check)
    results.append(dict(id='reward-components-and-costs', status='PASSED',
                        expected=0.03, actual=actual_reward))

    for name in ('bool-weight-refused', 'empty-action-array-refused',
                 'missing-abstain-refused', 'illegal-choice-refused',
                 'altered-draw-refused', 'unexplained-baseline-refused'):
        check()
        refused = False
        try:
            if name == 'bool-weight-refused':
                bad = list(ZERO); bad[0] = False
                selector.probabilities(bad, [list(PACKET), list(ABSTAIN)], check=check)
            elif name == 'empty-action-array-refused':
                selector.probabilities(list(ZERO), [], check=check)
            elif name == 'missing-abstain-refused':
                selector.probabilities(list(ZERO), [list(PACKET)], check=check)
            elif name in ('illegal-choice-refused', 'altered-draw-refused'):
                bad = copy.deepcopy(DECISION_0)
                if name == 'illegal-choice-refused': bad['choice'] = 2
                else: bad['draw'] = 0.0
                selector.update_policy(copy.deepcopy(initial), _episode([bad]), check=check)
            else:
                bad = copy.deepcopy(initial); bad['baseline'] = 0.5
                selector.verify_policy(bad, TRAINING_IDS, check=check)
        except BaseException as error:
            if not selector.is_owned_error(error):
                raise
            refused = True
        _need(refused, 'exact owned selector refusal required')
        results.append(dict(id=name, status='PASSED', owned_selector_refusal=True))

    # Genuine Root check dominates injection; catches accept only exact object.
    for name, sentinel in [
        ('foreign-runtimeerror-identity', RuntimeError('numeric diagnostic foreign error')),
        ('foreign-selectorerror-identity', selector.SelectorError('public class, foreign owner'))]:
        check()
        _need(not selector.is_owned_error(sentinel), 'diagnostic error is foreign')
        def inject():
            check()
            raise sentinel
        observed = False
        try:
            selector.probabilities(list(ZERO), [list(PACKET), list(ABSTAIN)], check=inject)
        except BaseException as error:
            if error is not sentinel:
                raise
            observed = True
        _need(observed, 'exact foreign callback identity escaped')
        results.append(dict(id=name, status='PASSED', exact_identity_propagated=True))

    _need(len(results) == 23, 'complete literal numeric control population')
    check()
    return dict(schema='selector-independent-numeric-controls-v1', status='PASSED',
                complete=True, control_count=23, controls=results,
                scope='Independent literal synthetic numeric controls only. No evaluation formulas, theorem proof, trained-policy qualification or semantic packet-uniqueness claim. Duplicate feature rows remain distinct actions. Execution occurs only inside a reviewed actual; this receipt is not trained-policy qualification.')
