"""Declared synthetic setup regression, executed only inside a reviewed actual.

No import of the word model or either scientific verifier occurs here. Root's
fixed closure supplies those modules. The literal fixture is a reduction
control, never an acquired donor, proof route, Native admission or search case.
"""
import json

VERSION = 'same-model-original-v1-production-v3-calibration-v1'
OLD_VERSION = 'aligned-complete-word-reference-verifier-v1'
NEW_VERSION = 'aligned-complete-word-reference-verifier-v3-subtree-json'
MODEL_VERSION = 'aligned-whole-word-point-model-v1'
_OWNER = object()


class SetupMismatch(ValueError):
    def __init__(self, message, owner=None):
        super().__init__(message)
        self.owner = owner


def _need(ok, message, check):
    check()
    if not ok:
        raise SetupMismatch(message, _OWNER)


def _canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=False, allow_nan=False).encode('utf8')


def _fixture():
    # Author-written shared containers deliberately exercise nested reuse.
    # These declarations do not certify that a Native compiler was invoked.
    p = ['pred', 'P', []]
    q = ['pred', 'Q', []]
    implication = ['imp', p, q]
    spec = dict(id='D17-authored-same-model-reference-control',
                title='Synthetic three-row reduction calibration only',
                theory=dict(functions={}, predicates={'P': 0, 'Q': 0},
                            axioms={'p': p, 'pq': implication}, schemas=[]),
                target=q, length=3, instantiation_rounds=2)
    catalog = dict(schema='quantified-initial-binder-syntax-catalog-v1',
                   producer_version='quantified-initial-binder-receptors-v1',
                   term_policy='TARGET_FREE_SUBTERMS_UNION_ALL_INITIAL_BINDER_VARIABLES_V1',
                   root_context='CLOSED_THEORY_AXIOMS_NO_OPEN_ROOT_ASSUMPTIONS',
                   rounds=2, basis=[implication, p, q], variables=[], schemes=[])
    compiled = dict(status='complete', catalog=catalog, basis=catalog['basis'],
                    variables=[], tautologies=[], admitted_schemes=[])
    inventory = dict(status='native_accepted', definitions=[], interfaces=[], native_blocks=[])
    return spec, compiled, inventory


def run_reference_setup_control(word_module, legacy_reference, production_reference, *, check):
    """Compare both FULL verifier receipts on one exact same synthetic model.

    No callback or scientific exception is caught or reclassified. Every Root
    or foreign fault escapes with its original identity. This bounded control
    is separate from fresh production-model v3 verification and all 48 word
    controls; it never stands in for those gates.
    """
    check()
    _need(word_module.VERSION == MODEL_VERSION
          and legacy_reference.VERSION == OLD_VERSION
          and production_reference.VERSION == NEW_VERSION,
          'exact model and two separately pinned reference versions', check)
    spec, compiled, inventory = _fixture()
    declared = _canonical(dict(spec=spec, compiled=compiled, inventory=inventory))
    model = word_module.Model(spec, compiled, inventory, arity=0, families=False, check=check)
    before = _canonical(word_module.evidence_view(model, check))
    old = legacy_reference.verify_word_reference(spec, compiled, inventory, model, check=check)
    new = production_reference.verify_word_reference(spec, compiled, inventory, model, check=check)
    _need(type(old) is dict and type(new) is dict
          and old.get('complete') is True and new.get('complete') is True,
          'two complete same-model reduction receipts', check)
    _need(old.get('schema') == 'aligned-complete-word-reference-v1'
          and new.get('schema') == 'aligned-complete-word-reference-v3',
          'exact declared reference receipt schemas', check)
    left = {}
    right = {}
    for key, value in old.items():
        check()
        if key not in ('schema', 'storage_scope'):
            left[key] = value
    for key, value in new.items():
        check()
        if key not in ('schema', 'storage_scope'):
            right[key] = value
    _need(_canonical(left) == _canonical(right),
          'all substantive receipt fields equal, with strict JSON types', check)
    after = _canonical(word_module.evidence_view(model, check))
    _need(before == after, 'same full model evidence before and after both audits', check)
    _need(declared == _canonical(dict(spec=spec, compiled=compiled, inventory=inventory)),
          'same literal fixture after construction and both audits', check)
    check()
    return dict(schema='same-model-original-v1-production-v3-setup-control-v1',
                complete=True, status='PASSED', control_count=1,
                original_version=OLD_VERSION, production_version=NEW_VERSION,
                fixture_kind='HAND_AUTHORED_REDUCTION_CONTROL_NOT_ACQUIRED_DONOR',
                fixture=json.loads(declared), model_evidence=json.loads(before),
                original=old, production=new,
                omitted_from_comparison=['schema', 'storage_scope'],
                full_model_value_unchanged=True,
                scope='One declared tiny full-model differential. No Native or Host proof '
                      'admission, generated donor, recipient search, theorem, performance '
                      'comparison or universal verifier equivalence claim. Every fresh '
                      'production model still requires its own complete v3 reduction gate; '
                      'all 48 word and 40 encoder controls remain separate actual obligations.')
