"""Aligned whole-word point carrier for the unchanged primitive proof pilot.

This is a new explicit point carrier, not the old byte-point representation.
Canonical JSON payloads followed by integer256 agree at an aligned byte column
iff their complete payloads are equal. A frozen bijective literal dictionary
therefore represents each complete word by one exact integer at its port.
Only states reachable from the complete-word boundary by complete placements
are related; shifted columns and arbitrary partial byte assignments are outside
this reduction. No proof rule, candidate, scheduler or search budget changes.
"""
import collections
from collections.abc import Mapping
import math
import time
from certificate_boundary_search import canonical
from quantified_receptors_v1 import domains, CATALOG_SCHEMA, VERSION as COMPILER_VERSION, TERM_POLICY, ROOT_CONTEXT
from semantic_receptor_points import Model as Factored, center, mode_point
from turtle import CAPACITY, Placement, State

VERSION = 'aligned-whole-word-point-model-v1'
SCHEMA = 'pilot-aligned-whole-word-point-model-v1'
REDUCTION_SCOPE = 'Complete aligned canonical JSON words plus256 at fixed formula/command columns; reachable boundary-and-placement states only. No shifted or arbitrary partial-byte states; Native/point adaptation, not physical Wang or old G0/G1 acceptance.'
DECLARATIONS = dict(
    dictionary='Tuple-index exact integer IDs; full canonical JSON payload bytes followed by explicit integer terminator256; ID0 is assigned, absence is unconstrained.',
    word_port='formula(slot)=(4slot,100); command(slot)=(4slot+1,100); one ID for the entire aligned word.',
    scalar='mode(slot)=(4slot+2,90), value0; auxiliary negative-x points retain their original scalar values.',
    dependencies='Complete t/m support point to frozenset of all original candidate keys; each lookup is repeatable.',
    transformations='Original fixed positional translated placements only; no rotated, shifted or partial-word placements.',
    scope=REDUCTION_SCOPE)


def need(ok, message):
    if not ok:
        raise ValueError(message)


def word_port(slot, channel):
    need(type(slot) is int and slot >= 0 and channel in ('formula', 'command'), 'exact aligned word port')
    return (4 * slot + (1 if channel == 'command' else 0), 100)


def merge(entries):
    """Exact small point-value union; absent differs from assigned integer0."""
    out = {}
    for point, value in entries:
        need(type(point) is tuple and len(point) == 2 and all(type(x) is int for x in point)
             and type(value) is int, 'strict integer point and assigned value')
        if point in out and out[point] != value:
            return None
        out[point] = value
    return tuple(sorted(out.items()))


class Model(Factored):
    def __init__(self, spec, compiled, inventory, arity=0, families=False, *, check):
        check()
        need(type(arity) is int and arity == 0 and families is False and
             inventory == dict(status='native_accepted', definitions=[], interfaces=[], native_blocks=[]),
             'exact empty-inventory primitive pilot profile')
        need(compiled.get('catalog', {}).get('schema') == CATALOG_SCHEMA and
             compiled['catalog'].get('producer_version') == COMPILER_VERSION and
             compiled['catalog'].get('term_policy') == TERM_POLICY and
             compiled['catalog'].get('root_context') == ROOT_CONTEXT,
             'wrong quantified compiler catalog or root scope')
        need(compiled['status'] == 'complete', 'unfinished compiler admission is not authority')
        self.spec = spec; self.compiled = compiled; self.inventory = inventory
        self.arity = 0; self.families_enabled = False; self.interfaces = []
        self.required_interface_arity = 0; self.arity_policy = 'EXPLICIT_COVERS_ALL_ADMITTED_INTERFACES'
        self.mode = {}; self.mode_names = {}; self.metrics = collections.Counter()
        self.dependencies = collections.defaultdict(set); self.cache = {}; self.align_cache = {}
        self.metadata = {}; self.conflicts = []; self.domains = []; self._check = check
        self.word_terminator = 256; self.word_dictionary = []; self._word_ids = {}
        self._target_word_id = self._word_id(spec['target'])
        began = time.perf_counter()
        tauts = {canonical(f) for f in compiled['tautologies']}
        schemes = {canonical(c) for c in compiled['admitted_schemes']}
        for j in range(spec['length']):
            check()
            for role in range(2):
                self.align_cache[center(j, role)] = []
            rows = domains(spec, compiled['catalog'], j)
            rows.sort(key=lambda c: (c['rule'], canonical(c['formula']), canonical(c)))
            self.domains.append(rows)
            for k, command in enumerate(rows):
                check(); formula = command['formula']; rule = command['rule']
                entries = self.assignment(j, 'command', command) + self.assignment(j, 'formula', formula) + [(mode_point(j), 0)]
                self.add((j, 0, k, 0), entries, command, [], 'command')
                req = []
                if rule == 'mp':
                    for variant, implication in enumerate(compiled['basis']):
                        check()
                        if implication[0] == 'imp' and implication[2] == formula:
                            wanted = [(command['antecedent'], implication[1]), (command['implication'], implication)]
                            all_entries = entries + [pair for source, f in wanted for pair in self.assignment(source, 'formula', f)]
                            self.add((j, 1, k, variant), all_entries, command, wanted, 'guard')
                    continue
                if rule == 'axiom':
                    valid = spec['theory']['axioms'][command['name']] == formula
                elif rule == 'refl':
                    valid = formula[0] == 'eq' and formula[1] == formula[2]
                elif rule == 'tautology':
                    valid = canonical(formula) in tauts
                elif rule == 'generalize':
                    valid = formula[0] == 'all' and formula[1] == command['variable']
                    if valid:
                        req = [(command['source'], formula[2])]
                else:
                    valid = canonical(command) in schemes
                if valid:
                    all_entries = entries + [pair for source, f in req for pair in self.assignment(source, 'formula', f)]
                    self.add((j, 1, k, 0), all_entries, command, req, 'guard')
        for point in self.align_cache:
            check(); self.align_cache[point] = tuple(self.align_cache[point])
        for point in self.dependencies:
            check(); self.dependencies[point] = frozenset(self.dependencies[point])
        self.dependencies = dict(self.dependencies)
        self.word_dictionary = tuple(self.word_dictionary); self._word_ids = None
        self.compile_seconds = time.perf_counter() - began
        check()

    def _word_id(self, value):
        self._check()
        need(self._word_ids is not None, 'frozen word dictionary is construction-only')
        payload = canonical(value)
        need(type(payload) is bytes, 'exact canonical byte payload')
        if payload not in self._word_ids:
            self._word_ids[payload] = len(self.word_dictionary)
            self.word_dictionary.append(payload)
        return self._word_ids[payload]

    def assignment(self, slot, channel, value):
        return [(word_port(slot, channel), self._word_id(value))]

    def add(self, key, entries, command, requirements, kind, **extra):
        self._check(); marks = merge(entries)
        if marks is None:
            self.conflicts.append(dict(key=key, reason='internally unequal markings')); return
        need(key not in self.cache, 'duplicate placement')
        root = center(key[0], key[1])
        tile = Placement(key, ((root, CAPACITY),), marks, ())
        self.cache[key] = tile
        self.metadata[key] = dict(slot=key[0], kind=kind, command=command, requirements=requirements, **extra)
        self.align_cache[root].append(key)
        for point, unused in tile.occupancy + tile.marks:
            self.dependencies[point].add(key)

    def initial(self):
        roots = {point: 0 for point in self.align_cache}
        return State(marks={word_port(self.spec['length'] - 1, 'formula'): self._target_word_id},
                     generations=roots.copy(), roots=roots.copy(), allowed_points=frozenset(roots))

    def record(self):
        return evidence_view(self, self._check)


class OverlayCache(Mapping):
    def __init__(self, base, replacements):
        self.base = base; self.replacements = replacements
    def __getitem__(self, key):
        return self.replacements[key] if key in self.replacements else self.base[key]
    def __iter__(self):
        return iter(self.base)
    def __len__(self):
        return len(self.base)


class OverlayDependencies:
    def __init__(self, base, extra):
        self.base = base; self.extra = extra
    def get(self, point, default=()):
        prior = self.base.get(point, ())
        added = self.extra.get(point, ())
        if added:
            need(not prior, 'fresh auxiliary support disjoint from base')
            return added
        return prior if prior else default
    def __contains__(self, point):
        return bool(self.get(point))


class MarkedModel:
    def __init__(self, base, packet, points):
        self.base = base; self.packet = packet; replacements = {}; extra = {}; self.initial_auxiliary = {}
        for field in ('align_cache', 'metadata', 'domains', 'spec', 'compiled', 'inventory', 'arity', 'mode', 'interfaces'):
            setattr(self, field, getattr(base, field))
        self.metrics = collections.Counter()
        for certificate in packet['certificates']:
            a = certificate['auxiliary']; key = a['placement']; point = a['point']
            need(point not in base.dependencies and point not in base.initial().marks and
                 point not in self.initial_auxiliary, 'fresh auxiliary mark-only coordinate')
            need(type(point) is tuple and len(point) == 2 and all(type(v) is int for v in point)
                 and point[0] == -100, 'declared auxiliary coordinate domain')
            need(type(a['placement_value']) is int and type(a['initial_value']) is int, 'exact auxiliary assigned values')
            old = replacements.get(key, base.placement(key))
            marks = merge(((point, a['placement_value']),) + old.marks)
            need(marks is not None, 'compatible explicit auxiliary overlay')
            replacements[key] = Placement(old.key, old.occupancy, marks, old.vertices)
            extra.setdefault(point, set()).add(key); self.initial_auxiliary[point] = a['initial_value']
        self.cache = OverlayCache(base.cache, replacements)
        self.dependencies = OverlayDependencies(base.dependencies, {p: frozenset(keys) for p, keys in extra.items()})
    def placement(self, key):
        return self.cache[key]
    def alignments(self, point):
        return self.align_cache[point]
    def initial(self):
        state = self.base.initial(); state.marks.update(self.initial_auxiliary); return state
    def decode(self, keys):
        return self.base.decode(keys)


def _wire(value):
    if type(value) in (tuple, list):
        return [_wire(v) for v in value]
    if type(value) is dict:
        return {k: _wire(v) for k, v in value.items()}
    return value


def _same(left, right, check):
    stack = [(left, right)]
    while stack:
        check(); a, b = stack.pop()
        if type(b) in (tuple, list):
            if type(a) is not list or len(a) != len(b):
                return False
            stack.extend(zip(a, b))
        elif type(b) is dict:
            if type(a) is not dict or set(a) != set(b):
                return False
            stack.extend((a[k], b[k]) for k in b)
        elif type(a) is not type(b) or a != b:
            return False
    return True


def _initial_value(model):
    state = model.initial()
    return dict(totals=sorted(state.totals.items()), marks=sorted(state.marks.items()),
                generations=sorted(state.generations.items()), roots=sorted(state.roots.items()),
                selected=sorted(state.selected), order=state.order, tile_generations=state.tile_generations,
                allowed_points=sorted(state.allowed_points))


def evidence_view(model, check):
    rows = []
    for key in sorted(model.cache):
        check(); tile = model.cache[key]; metadata = dict(model.metadata[key]); command = metadata.pop('command')
        need(command is not None and command == model.domains[key[0]][key[2]], 'exact primitive command owner')
        rows.append(dict(key=list(key), occupancy=_wire(tile.occupancy), marks=_wire(tile.marks),
                         vertices=_wire(tile.vertices), metadata=_wire(metadata), command_reference=[key[0], key[2]]))
    return dict(schema=SCHEMA, word_dictionary=[raw.hex() for raw in model.word_dictionary],
                word_terminator=model.word_terminator, placements=rows, domains=model.domains,
                alignments=[dict(point=list(p), keys=[list(k) for k in ks]) for p, ks in sorted(model.align_cache.items())],
                dependencies=[dict(point=list(p), keys=[list(k) for k in sorted(keys)]) for p, keys in sorted(model.dependencies.items())],
                conflicts=_wire(model.conflicts), arity=model.arity, mode_ids=model.mode,
                initial=_wire(_initial_value(model)), base_compile_seconds=model.compile_seconds,
                declarations=dict(DECLARATIONS))


def verify_evidence(packet, model, check):
    """Independent full literal wire-to-actual Model reconciliation (not hashes)."""
    fields = {'schema', 'word_dictionary', 'word_terminator', 'placements', 'domains', 'alignments',
              'dependencies', 'conflicts', 'arity', 'mode_ids', 'initial', 'base_compile_seconds', 'declarations'}
    need(type(packet) is dict and set(packet) == fields and packet['schema'] == SCHEMA, 'exact word evidence fields')
    need(type(model.word_dictionary) is tuple and type(packet['word_dictionary']) is list and
         len(packet['word_dictionary']) == len(model.word_dictionary), 'whole immutable dictionary population')
    seen = set()
    for text, raw in zip(packet['word_dictionary'], model.word_dictionary):
        check(); need(type(raw) is bytes and raw not in seen and type(text) is str and text == raw.hex(), 'exact bijective full dictionary payload')
        seen.add(raw)
    need(type(packet['word_terminator']) is int and packet['word_terminator'] == model.word_terminator == 256,
         'explicit exact integer terminator')
    need(type(packet['placements']) is list and len(packet['placements']) == len(model.cache), 'whole original placement population')
    for row, key in zip(packet['placements'], sorted(model.cache)):
        check(); tile = model.cache[key]; metadata = dict(model.metadata[key]); command = metadata.pop('command')
        need(type(row) is dict and set(row) == {'key', 'occupancy', 'marks', 'vertices', 'metadata', 'command_reference'}, 'exact placement row')
        need(_same(row['key'], key, check) and _same(row['occupancy'], tile.occupancy, check) and
             _same(row['marks'], tile.marks, check) and _same(row['vertices'], tile.vertices, check) and
             _same(row['metadata'], metadata, check), 'full literal placement/t/port-value/metadata')
        need(_same(row['command_reference'], [key[0], key[2]], check) and command is not None and
             _same(packet['domains'][key[0]][key[2]], command, check), 'strict command owner reference')
    need(_same(packet['domains'], model.domains, check) and _same(packet['conflicts'], model.conflicts, check) and
         type(packet['arity']) is int and packet['arity'] == 0 and _same(packet['mode_ids'], model.mode, check), 'full primitive domain/interface data')
    need(type(packet['alignments']) is list and len(packet['alignments']) == len(model.align_cache), 'whole alignment population')
    for row, point in zip(packet['alignments'], sorted(model.align_cache)):
        check(); need(type(row) is dict and set(row) == {'point', 'keys'} and
                      _same(row['point'], point, check) and _same(row['keys'], model.align_cache[point], check), 'whole ordered alignment domain')
    need(type(packet['dependencies']) is list and len(packet['dependencies']) == len(model.dependencies), 'whole dependency population')
    for row, point in zip(packet['dependencies'], sorted(model.dependencies)):
        check(); need(type(row) is dict and set(row) == {'point', 'keys'} and
                      _same(row['point'], point, check) and _same(row['keys'], sorted(model.dependencies[point]), check), 'whole exact inverse support dependency')
    need(_same(packet['initial'], _initial_value(model), check), 'complete boundary and generation state')
    need(type(packet['base_compile_seconds']) is float and math.isfinite(packet['base_compile_seconds']) and
         packet['base_compile_seconds'] >= 0 and packet['base_compile_seconds'] == model.compile_seconds, 'actual Model construction time')
    need(_same(packet['declarations'], DECLARATIONS, check), 'every emitted reduction declaration')
    return dict(complete=True, placements=len(model.cache), dictionary_words=len(model.word_dictionary),
                dependencies=len(model.dependencies), scope='Full exact word evidence/actual owner correspondence; L separately verifies old byte construction reduction.')
