"""Literal D16 input/format controls; calls belong only inside a Root actual.

This module does not search, mine, unify, compile or check a proof.  The finite
valuation is an external negative control, not a search-exhaustion certificate.
"""
import copy

SCHEMA = 'gcts-principal-receptor-mechanism-inputs-v1'
DONOR_IDS = ('donor-constructor-chain', 'donor-generic-application')
CONTEXT_IDS = ('context-constructor-calibration', 'context-atomic-serial',
               'context-opaque-equality', 'context-inconsistent-middle')
PROTOCOL = {
    'abstraction_modes': ['atom', 'principal'],
    'audit_views': ['full', 'one_mp'],
    'cells': [
        {'context_id': 'context-constructor-calibration', 'view': 'full', 'mode': 'atom'},
        {'context_id': 'context-constructor-calibration', 'view': 'full', 'mode': 'principal'},
        {'context_id': 'context-constructor-calibration', 'view': 'one_mp', 'mode': 'principal'},
        {'context_id': 'context-constructor-calibration', 'view': 'one_mp', 'mode': 'atom'},
        {'context_id': 'context-atomic-serial', 'view': 'full', 'mode': 'principal'},
        {'context_id': 'context-atomic-serial', 'view': 'full', 'mode': 'atom'},
        {'context_id': 'context-atomic-serial', 'view': 'one_mp', 'mode': 'atom'},
        {'context_id': 'context-atomic-serial', 'view': 'one_mp', 'mode': 'principal'},
        {'context_id': 'context-opaque-equality', 'view': 'full', 'mode': 'atom'},
        {'context_id': 'context-opaque-equality', 'view': 'full', 'mode': 'principal'},
        {'context_id': 'context-opaque-equality', 'view': 'one_mp', 'mode': 'principal'},
        {'context_id': 'context-opaque-equality', 'view': 'one_mp', 'mode': 'atom'},
        {'context_id': 'context-inconsistent-middle', 'view': 'full', 'mode': 'principal'},
        {'context_id': 'context-inconsistent-middle', 'view': 'full', 'mode': 'atom'},
        {'context_id': 'context-inconsistent-middle', 'view': 'one_mp', 'mode': 'atom'},
        {'context_id': 'context-inconsistent-middle', 'view': 'one_mp', 'mode': 'principal'},
    ],
    'pairing': 'one entry per fresh atom-template class in both modes; preserve all members and multiplicity; no principal structural coalescing',
    'premise_ports': 'exact concrete formula equality, first use; retain named aliases and every row provenance',
    'binding_scope': 'empty primitive prefix; all licensed named axiom occurrences; graph=None; exact trial base placements and Host checks',
    'native_witness_selection': 'union of first packet and first packet with at least two MP commands concluding the exact declared target; original pool order; maximum two per cell',
    'native_witness_target': 'actual packet result_formula',
    'native_witness_failure': 'no resampling or backfill; preserve UNKNOWN; rejected validated witness is a fault',
    'reference_factor': 'same new common verifier in every compared cell; preserve original verifier as separate differential control',
    'scope': 'one bounded mechanism actual; no RL training, open receptor cuts, new deduplication, target proof routes or speedup claim',
}
CONTROL_IDS = ('valid-format', 'unexpected-proof-field', 'bool-row-bound',
               'free-variable', 'undeclared-predicate', 'arity-mismatch',
               'nonempty-schemas', 'duplicate-id', 'protocol-order-mutation',
               'missing-context', 'missing-donor', 'coalescing-policy-mutation',
               'external-negative-valuation', 'foreign-runtimeerror',
               'foreign-valueerror', 'foreign-formaterror')
_OWNER = object()


class CorpusFormatError(ValueError):
    def __init__(self, message, owner=None):
        super().__init__(message)
        self.owner = owner


def is_owned_error(error):
    return type(error) is CorpusFormatError and error.owner is _OWNER


def need(value, message):
    if not value:
        raise CorpusFormatError(message, _OWNER)


def _name(value, check):
    check()
    need(type(value) is str and 0 < len(value) <= 128, 'bounded literal name')


def _signature(value, check):
    check(); need(type(value) is dict, 'literal signature')
    for name, arity in value.items():
        _name(name, check)
        need(type(arity) is int and 0 <= arity <= 2, 'exact small nonnegative arity')


def _term(value, theory, check):
    check(); need(type(value) is list and len(value) == 3 and value[0] == 'fun', 'closed function term')
    name, arguments = value[1:]
    need(type(name) is str and name in theory['functions'] and type(arguments) is list,
         'declared function and literal arguments')
    need(len(arguments) == theory['functions'][name], 'function arity')
    for argument in arguments:
        _term(argument, theory, check)


def _formula(value, theory, check):
    check(); need(type(value) is list and len(value) == 3, 'mechanism formula constructor')
    tag = value[0]
    if tag == 'pred':
        need(type(value[1]) is str and value[1] in theory['predicates'] and type(value[2]) is list,
             'declared predicate and literal arguments')
        need(len(value[2]) == theory['predicates'][value[1]], 'predicate arity')
        for argument in value[2]:
            _term(argument, theory, check)
    elif tag == 'eq':
        _term(value[1], theory, check); _term(value[2], theory, check)
    else:
        need(tag == 'imp', 'only closed pred/eq/imp in this input corpus')
        _formula(value[1], theory, check); _formula(value[2], theory, check)


def _spec(spec, check):
    check(); need(type(spec) is dict and set(spec) == {'id', 'title', 'theory', 'target', 'length',
                 'instantiation_rounds', 'scope'}, 'exact statement-only spec; no proof/routes')
    for field in ('id', 'title', 'scope'):
        _name(spec[field], check) if field == 'id' else need(type(spec[field]) is str, 'literal prose')
    need(type(spec['length']) is int and 1 <= spec['length'] <= 5, 'expanded primitive row bound')
    need(type(spec['instantiation_rounds']) is int and spec['instantiation_rounds'] == 2, 'fixed compiler rounds')
    theory = spec['theory']
    need(type(theory) is dict and set(theory) == {'functions', 'predicates', 'axioms', 'schemas'}, 'exact theory')
    _signature(theory['functions'], check); _signature(theory['predicates'], check)
    need(type(theory['schemas']) is list and not theory['schemas'], 'no extra schema license')
    need(type(theory['axioms']) is dict and 1 <= len(theory['axioms']) <= 3, 'bounded explicit axiom licenses')
    for name, formula in theory['axioms'].items():
        _name(name, check); _formula(formula, theory, check)
    _formula(spec['target'], theory, check)


def validate_document(document, *, check):
    check(); need(type(document) is dict and set(document) == {'schema', 'id', 'donors', 'contexts', 'protocol'},
                  'exact mechanism document')
    need(document['schema'] == SCHEMA, 'mechanism schema'); _name(document['id'], check)
    need(type(document['donors']) is list and len(document['donors']) == 2, 'both fresh donor statements')
    need(type(document['contexts']) is list and len(document['contexts']) == 4, 'all four fixed contexts')
    seen = set()
    for population, expected in ((document['donors'], DONOR_IDS), (document['contexts'], CONTEXT_IDS)):
        ids = []
        for spec in population:
            _spec(spec, check); need(spec['id'] not in seen, 'distinct statement IDs')
            seen.add(spec['id']); ids.append(spec['id'])
        need(tuple(ids) == expected, 'fixed literal statement order')
    need(type(document['protocol']) is dict and document['protocol'] == PROTOCOL, 'fixed declared mechanism protocol')
    check()
    return dict(schema='D16-mechanism-format-receipt-v1', complete=True, donors=2, contexts=4,
                scope='Format/signature/closedness and literal protocol only; no theorem or search claim.')


def _truth(formula, valuation, check):
    check()
    if formula[0] == 'pred':
        need(not formula[2] and formula[1] in valuation, 'external nullary valuation domain')
        return valuation[formula[1]]
    need(formula[0] == 'imp', 'external valuation is propositional only')
    left = _truth(formula[1], valuation, check); right = _truth(formula[2], valuation, check)
    return not left or right


def run_contract_controls(document, *, check):
    check(); validate_document(document, check=check)
    results = [dict(id='valid-format', status='PASSED')]
    for recipe in CONTROL_IDS[1:12]:
        check(); altered = copy.deepcopy(document)
        if recipe == 'unexpected-proof-field': altered['donors'][0]['proof'] = []
        elif recipe == 'bool-row-bound': altered['donors'][0]['length'] = True
        elif recipe == 'free-variable': altered['contexts'][2]['target'] = ['eq', ['var', 'x'], ['fun', 'a', []]]
        elif recipe == 'undeclared-predicate': altered['contexts'][0]['target'] = ['pred', 'UNLICENSED', []]
        elif recipe == 'arity-mismatch': altered['contexts'][0]['theory']['predicates']['S'] = 1
        elif recipe == 'nonempty-schemas': altered['donors'][0]['theory']['schemas'] = ['extra']
        elif recipe == 'duplicate-id': altered['donors'][1]['id'] = altered['donors'][0]['id']
        elif recipe == 'protocol-order-mutation': altered['protocol']['abstraction_modes'].reverse()
        elif recipe == 'missing-context': altered['contexts'].pop()
        elif recipe == 'missing-donor': altered['donors'].pop()
        else: altered['protocol']['pairing'] = 'coalesce principal structural identities'
        refused = False
        try:
            validate_document(altered, check=check)
        except CorpusFormatError as error:
            check()
            if not is_owned_error(error):
                raise
            refused = True
        need(refused, 'malformed input must be refused: '+recipe)
        results.append(dict(id=recipe, status='PASSED', refused=True))
    check(); negative = document['contexts'][3]
    valuation = {'P': True, 'Q': True, 'R': False, 'S': False}; premise_values = []
    for formula in negative['theory']['axioms'].values():
        premise_values.append(_truth(formula, valuation, check))
    target_value = _truth(negative['target'], valuation, check)
    need(all(premise_values) and target_value is False, 'external finite countermodel')
    results.append(dict(id='external-negative-valuation', status='PASSED', valuation=valuation,
                        premise_values=premise_values, target_value=target_value,
                        scope='External manual finite interpretation; not a bounded-search negative.'))
    for recipe, exception in (('foreign-runtimeerror', RuntimeError('external')),
                              ('foreign-valueerror', ValueError('external')),
                              ('foreign-formaterror', CorpusFormatError('external'))):
        check()
        def interrupt():
            check(); raise exception
        caught = None
        try:
            validate_document(document, check=interrupt)
        except BaseException as error:
            caught = error
        check(); need(caught is exception, 'exact foreign callback identity')
        results.append(dict(id=recipe, status='PASSED', identity_preserved=True))
    need(tuple(row['id'] for row in results) == CONTROL_IDS, 'complete ordered control population')
    check()
    return dict(schema='D16-mechanism-corpus-controls-v1', status='PASSED', complete=True,
                control_count=16, controls=results,
                scope='Finite format/callback/external-valuation controls only; execute only in a reviewed Root actual.')
