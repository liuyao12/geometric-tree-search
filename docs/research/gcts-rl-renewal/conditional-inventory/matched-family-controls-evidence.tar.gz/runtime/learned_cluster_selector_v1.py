"""Small reward-trained selector. No fixture or scientific call runs on import.

Packets remain untrusted ordering proposals. This module never answers a proof
query, changes a candidate domain, or receives a family/theorem identifier as a
feature. All calls belong inside a separately reviewed Root actual.
"""
import copy
import math
import random

VERSION = 'linear-cluster-selector-v1'
FEATURES = ('packet_bias', 'pending_fraction', 'premise_reuse_fraction',
            'new_root_fraction', 'novel_conclusion', 'point_pending_fraction',
            'target_conclusion', 'validation_fraction', 'abstain_bias')
LEARNING_RATE = 0.05
BASELINE_DECAY = 0.9
BASELINE_RATE = 0.1
TEMPERATURE = 1.0
_ERROR_OWNER = object()


class SelectorError(ValueError):
    def __init__(self, message, owner=None):
        super().__init__(message)
        self._selector_owner = owner


def is_owned_error(error):
    return type(error) is SelectorError and error._selector_owner is _ERROR_OWNER


def need(condition, message):
    if not condition:
        raise SelectorError(message, _ERROR_OWNER)


def same(left, right, check):
    check()
    if type(left) is not type(right):
        return False
    if type(left) is list:
        if len(left) != len(right):
            return False
        for a, b in zip(left, right):
            if not same(a, b, check):
                return False
        return True
    if type(left) is dict:
        if set(left) != set(right):
            return False
        for key in left:
            check()
            if not same(left[key], right[key], check):
                return False
        return True
    if type(left) is float:
        return math.isfinite(left) and left.hex() == right.hex()
    need(left is None or type(left) in (str, int, bool), 'literal numeric ledger value')
    return left == right


def _number(value, check):
    check()
    need(type(value) is float and math.isfinite(value), 'finite exact float')


def _weights(weights, check):
    check(); need(type(weights) is list and len(weights) == 9, 'nine weights')
    for value in weights:
        _number(value, check)


def _rows(rows, check):
    check(); need(type(rows) is list and 1 <= len(rows) <= 17, 'bounded actions plus ABSTAIN')
    for row in rows:
        check(); need(type(row) is list and len(row) == 9, 'nine generic features')
        for value in row:
            _number(value, check)
            need(0.0 <= value <= 1.0, 'bounded generic feature')
    need(rows[-1] == [0.0] * 8 + [1.0], 'last action is ABSTAIN')
    for row in rows[:-1]:
        check(); need(row[0] == 1.0 and row[-1] == 0.0, 'packet feature namespace')


def initial_policy(*, check):
    check()
    return dict(schema=VERSION, weights=[0.0] * 9, baseline=0.0,
                episodes=0, history=[])


def probabilities(weights, feature_rows, *, check):
    _weights(weights, check); _rows(feature_rows, check)
    scores = []
    for row in feature_rows:
        check(); value = 0.0
        for coefficient, feature in zip(weights, row):
            check(); value += coefficient * feature
        _number(value, check); scores.append(value / TEMPERATURE)
    top = max(scores); exponentials = []; total = 0.0
    for score in scores:
        check(); value = math.exp(score - top)
        _number(value, check); exponentials.append(value); total += value
    need(math.isfinite(total) and total > 0.0, 'positive softmax normalizer')
    result = []
    for value in exponentials:
        check(); result.append(value / total)
    check(); return result


def _select(probability, draw, check):
    _number(draw, check); need(0.0 <= draw < 1.0, 'unit random draw')
    total = 0.0
    for index, value in enumerate(probability):
        check(); total += value
        if draw < total:
            return index
    # The final endpoint absorbs floating point summation roundoff only.
    return len(probability) - 1


def choose(mode, weights, feature_rows, rng, *, check):
    _weights(weights, check); _rows(feature_rows, check)
    need(mode in ('fixed', 'uniform', 'rl'), 'declared selector mode')
    scores = []
    for row in feature_rows:
        check(); value = 0.0
        for coefficient, feature in zip(weights, row):
            check(); value += coefficient * feature
        _number(value, check); scores.append(value)
    if mode == 'fixed':
        choice = 0; draw = None
        probability = [float(index == choice) for index in range(len(feature_rows))]
    else:
        probability = (probabilities(weights, feature_rows, check=check) if mode == 'rl'
                       else [1.0 / len(feature_rows)] * len(feature_rows))
        check(); draw = rng.random(); choice = _select(probability, draw, check)
    check()
    return dict(mode=mode, weights=list(weights), features=copy.deepcopy(feature_rows),
                probabilities=probability, scores=scores, draw=draw, choice=choice)


def reward(components, *, check):
    check(); need(type(components) is dict and set(components) ==
                  {'native_accepted', 'max_live_root_fraction', 'attempts', 'validation_checks'},
                  'complete reward components')
    need(type(components['native_accepted']) is bool, 'terminal checker acceptance flag')
    progress = components['max_live_root_fraction']; _number(progress, check)
    need(0.0 <= progress <= 1.0, 'maximum LIVE root progress, never cumulative placements')
    for name in ('attempts', 'validation_checks'):
        check(); need(type(components[name]) is int and components[name] >= 0,
                      'nonnegative actual work counter')
    need(components['attempts'] <= 600, 'original primitive extension bound')
    value = (float(components['native_accepted']) + 0.05 * progress
             - 0.01 * components['attempts'] / 600
             - 0.01 * components['validation_checks'] / 20000)
    _number(value, check); return value


def _episode_update(policy, episode, check):
    check(); need(type(policy) is dict and set(policy) ==
                  {'schema', 'weights', 'baseline', 'episodes', 'history'}, 'exact policy fields')
    need(policy['schema'] == VERSION, 'policy version')
    _weights(policy['weights'], check); _number(policy['baseline'], check)
    need(type(policy['episodes']) is int and policy['episodes'] >= 0
         and type(policy['history']) is list and len(policy['history']) == policy['episodes'],
         'policy history length')
    need(type(episode) is dict and set(episode) ==
         {'index', 'problem_id', 'decisions', 'reward_components'}, 'exact episode fields')
    need(type(episode['index']) is int and episode['index'] == policy['episodes']
         and type(episode['problem_id']) is str, 'global episode continuation')
    need(type(episode['decisions']) is list and len(episode['decisions']) <= 601,
         'bounded complete action ledger')
    expected_rng = random.Random(episode['index']); gradient = [0.0] * 9
    for decision in episode['decisions']:
        check(); need(type(decision) is dict and set(decision) ==
            {'mode', 'weights', 'features', 'probabilities', 'scores', 'draw', 'choice'},
            'complete action record')
        need(decision['mode'] == 'rl' and decision['weights'] == policy['weights'],
             'training actions use pre-episode policy')
        rows = decision['features']; _rows(rows, check)
        expected = choose('rl', policy['weights'], rows, expected_rng, check=check)
        need(same(decision, expected, check), 'complete softmax, draw and selected action correspondence')
        selected = decision['choice']; need(type(selected) is int and 0 <= selected < len(rows),
                                            'selected action index')
        for coordinate in range(9):
            check(); mean = 0.0
            for probability, row in zip(decision['probabilities'], rows):
                check(); mean += probability * row[coordinate]
            gradient[coordinate] += rows[selected][coordinate] - mean
    # Terminal episode-reward REINFORCE uses the sum of trajectory scores.
    # An empty action trajectory has the zero gradient.
    value = reward(episode['reward_components'], check=check)
    advantage = value - policy['baseline']; post = []
    for old, value_gradient in zip(policy['weights'], gradient):
        check(); value_weight = old + LEARNING_RATE * advantage * value_gradient
        _number(value_weight, check); post.append(value_weight)
    baseline = BASELINE_DECAY * policy['baseline'] + BASELINE_RATE * value
    _number(baseline, check)
    return dict(pre_weights=list(policy['weights']), pre_baseline=policy['baseline'],
                reward=value, gradient=gradient, advantage=advantage,
                post_weights=post, post_baseline=baseline)


def update_policy(policy, episode, *, check):
    update = _episode_update(policy, episode, check)
    result = copy.deepcopy(policy)
    result['history'].append(dict(episode=copy.deepcopy(episode), update=update))
    result['episodes'] += 1; result['weights'] = list(update['post_weights'])
    result['baseline'] = update['post_baseline']; check(); return result


def verify_policy(policy, training_ids, *, check):
    check(); need(type(training_ids) is list and len(training_ids) == 12
                  and len(set(training_ids)) == 12, 'ordered training-only problem IDs')
    need(type(policy) is dict and type(policy.get('history')) is list
         and len(policy['history']) <= 24, 'complete bounded training ledger')
    expected = initial_policy(check=check); changed = 0
    for index, item in enumerate(policy['history']):
        check(); need(type(item) is dict and set(item) == {'episode', 'update'},
                      'complete stored update')
        episode = item['episode']
        need(episode['index'] == index and episode['problem_id'] == training_ids[index % 12],
             'exact two-pass training schedule')
        actual_update = _episode_update(expected, episode, check)
        need(same(item['update'], actual_update, check), 'stored reward/gradient/prebaseline/update values')
        changed += actual_update['pre_weights'] != actual_update['post_weights']
        expected = update_policy(expected, episode, check=check)
    need(same(policy, expected, check), 'full policy, weights and EMA from zero initialization')
    check(); return dict(complete=True, episodes=expected['episodes'],
                        nonzero_weight_updates=changed, weights=list(expected['weights']),
                        baseline=expected['baseline'],
                        scope='Numeric ledger verification; live feature provenance remains bound to admitted phase records.')
