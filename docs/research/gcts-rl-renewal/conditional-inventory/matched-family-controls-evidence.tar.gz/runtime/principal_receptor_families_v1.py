"""Finite axiom/MP-DAG principal formula typing; ordering proposals only.

No Host, Native, search, old miner or executable proof is imported.  Call only
inside a fresh reviewed actual.  ``check`` is the caller's genuine cost/fault
callback and is never caught.  Publicly constructed Invalid is not owned.
"""
import hashlib
import json

VERSION = 'principal-axiom-MP-receptor-families-v1'
SCHEMA = 'principal-axiom-MP-family-v1'
PORT_POLICY = 'EXACT_DONOR_FORMULA_FIRST_USE_QUOTIENT_V1'
_OWNER = object()


class Invalid(ValueError):
    def __init__(self, message):
        super().__init__(message)
        self._owner = None


def is_owned_error(error):
    return type(error) is Invalid and error._owner is _OWNER


def _need(condition, message, check):
    check()
    if not condition:
        error = Invalid(message)
        error._owner = _OWNER
        raise error


def _copy(value, check):
    check()
    if type(value) is list:
        return [_copy(v, check) for v in value]
    if type(value) is dict:
        result = {}
        for key, item in value.items():
            _need(type(key) is str, 'ordinary string-key certificate', check)
            result[key] = _copy(item, check)
        return result
    _need(value is None or type(value) in (str, int, bool), 'strict JSON certificate scalar', check)
    return value


def _word(value, check):
    copied = _copy(value, check)
    result = json.dumps(copied, sort_keys=True, separators=(',', ':'),
                        ensure_ascii=False, allow_nan=False)
    check()
    return result


def _digest(value, check):
    encoded = _word(value, check).encode('utf-8')
    check()
    return hashlib.sha256(encoded).hexdigest()


def _term(value, check, maximum):
    check()
    _need(type(value) is list and value, 'finite formula type term', check)
    if len(value) == 2 and value[0] == 'meta':
        _need(type(value[1]) is int and 0 <= value[1] < maximum,
              'exact finite formula variable', check)
        return ('meta', value[1])
    _need(len(value) == 3 and value[0] == 'imp', 'only free Imp type constructor', check)
    return ('imp', _term(value[1], check, maximum), _term(value[2], check, maximum))


def _wire(term, check):
    check()
    if term[0] == 'meta':
        return ['meta', term[1]]
    return ['imp', _wire(term[1], check), _wire(term[2], check)]


def _walk(term, bindings, check):
    seen = set()
    while term[0] == 'meta' and term[1] in bindings:
        check()
        _need(term[1] not in seen, 'finite acyclic substitution chain', check)
        seen.add(term[1]); term = bindings[term[1]]
    return term


def _occurs(variable, term, bindings, check):
    stack = [term]
    while stack:
        check(); current = _walk(stack.pop(), bindings, check)
        if current[0] == 'meta':
            if current[1] == variable:
                return True
        else:
            stack.append(current[2]); stack.append(current[1])
    return False


def _resolve(term, bindings, check):
    current = _walk(term, bindings, check)
    if current[0] == 'meta':
        return current
    return ('imp', _resolve(current[1], bindings, check),
            _resolve(current[2], bindings, check))


def _graph(nodes, port_count, check):
    _need(type(nodes) is list and nodes and type(port_count) is int and
          0 <= port_count <= len(nodes), 'finite ordered graph and exact port count', check)
    used = set(); copied = []
    for row, node in enumerate(nodes):
        check(); _need(type(node) is dict and type(node.get('row')) is int and
                       node['row'] == row, 'exact graph row ordinal', check)
        if node.get('kind') == 'port':
            _need(set(node) == {'row', 'kind', 'port'} and type(node['port']) is int
                  and 0 <= node['port'] < port_count, 'declared exact receptor port', check)
            used.add(node['port'])
        else:
            _need(set(node) == {'row', 'kind', 'antecedent', 'implication'} and
                  node['kind'] == 'mp', 'only port or MP graph node', check)
            for name in ('antecedent', 'implication'):
                _need(type(node[name]) is int and 0 <= node[name] < row,
                      'strictly earlier exact MP reference', check)
        copied.append(_copy(node, check))
    _need(used == set(range(port_count)), 'every declared port occurs', check)
    return copied


def _constraints(nodes, ports, check):
    result = []; size = len(nodes)
    for row, node in enumerate(nodes):
        check()
        if node['kind'] == 'port':
            left = ('meta', row); right = ('meta', size + node['port'])
        else:
            left = ('meta', node['implication'])
            right = ('imp', ('meta', node['antecedent']), ('meta', row))
        result.append((left, right))
    return result


def _solve(equations, check):
    pending = list(reversed(equations)); bindings = {}; trace = []
    while pending:
        check(); left, right = pending.pop()
        left = _walk(left, bindings, check); right = _walk(right, bindings, check)
        event = dict(left=_wire(left, check), right=_wire(right, check), rule=None)
        if left == right:
            event['rule'] = 'same'
        elif left[0] == 'meta':
            _need(not _occurs(left[1], right, bindings, check), 'occurs check: no finite type', check)
            bindings[left[1]] = right; event['rule'] = 'bind_left'
        elif right[0] == 'meta':
            _need(not _occurs(right[1], left, bindings, check), 'occurs check: no finite type', check)
            bindings[right[1]] = left; event['rule'] = 'bind_right'
        else:
            event['rule'] = 'decompose'
            pending.append((left[2], right[2])); pending.append((left[1], right[1]))
        trace.append(event)
    return bindings, trace


def _replay(equations, trace, variables, check):
    """Check every elementary MGU step, not just that final types unify."""
    _need(type(trace) is list, 'complete finite unification trace', check)
    pending = list(reversed(equations)); bindings = {}
    for event in trace:
        check(); _need(pending and type(event) is dict and set(event) == {'left', 'right', 'rule'},
                       'one trace step per pending equation', check)
        a, b = pending.pop(); left = _walk(a, bindings, check); right = _walk(b, bindings, check)
        _need(_term(event['left'], check, variables) == left and
              _term(event['right'], check, variables) == right, 'exact trace equation after dereferencing', check)
        rule = event['rule']
        if rule == 'same':
            _need(left == right, 'valid identical-equation deletion', check)
        elif rule == 'bind_left':
            _need(left != right and left[0] == 'meta' and
                  not _occurs(left[1], right, bindings, check), 'valid finite left variable elimination', check)
            bindings[left[1]] = right
        elif rule == 'bind_right':
            _need(left != right and left[0] != 'meta' and right[0] == 'meta' and
                  not _occurs(right[1], left, bindings, check), 'valid finite right variable elimination', check)
            bindings[right[1]] = left
        else:
            _need(rule == 'decompose' and left != right and left[0] == right[0] == 'imp',
                  'valid free Imp decomposition', check)
            pending.append((left[2], right[2])); pending.append((left[1], right[1]))
    _need(not pending, 'unification trace exhausts every equation', check)
    return bindings


def _alpha(term, renaming, meta_order, check):
    check()
    if term[0] == 'meta':
        if term[1] not in renaming:
            renaming[term[1]] = len(renaming); meta_order.append(term[1])
        return ['meta', renaming[term[1]]]
    return ['imp', _alpha(term[1], renaming, meta_order, check),
            _alpha(term[2], renaming, meta_order, check)]


def _typing(nodes, ports, equations, bindings, trace, check):
    size = len(nodes); raw = [_resolve(('meta', i), bindings, check) for i in range(size + ports)]
    renaming = {}; meta_order = []
    premises = [_alpha(raw[size+p], renaming, meta_order, check) for p in range(ports)]
    conclusion = _alpha(raw[size-1], renaming, meta_order, check)
    rows = [_alpha(raw[i], renaming, meta_order, check) for i in range(size)]
    solved = [_alpha(term, renaming, meta_order, check) for term in raw]
    ordered_bindings = []
    for variable in sorted(bindings):
        check(); ordered_bindings.append(dict(variable=variable, value=_wire(bindings[variable], check)))
    return dict(graph=_copy(nodes, check), port_count=ports,
                constraints=[dict(left=_wire(a, check), right=_wire(b, check)) for a, b in equations],
                unification_trace=_copy(trace, check), bindings=ordered_bindings,
                row_formulas=rows, premises=premises, conclusion=conclusion,
                solved_variables=solved, parameters=len(renaming), meta_order=meta_order)


def infer_graph(nodes, port_count, *, check):
    """Infer the fixed graph/quotient's MGU. Port-only graphs are permitted here."""
    graph = _graph(nodes, port_count, check); equations = _constraints(graph, port_count, check)
    bindings, trace = _solve(equations, check)
    return _typing(graph, port_count, equations, bindings, trace, check)


def _logical_term(term, functions, check):
    _need(type(term) is list, 'literal object-language term', check)
    if len(term) == 2 and term[0] == 'var':
        _need(type(term[1]) is str, 'variable name', check); return
    _need(len(term) == 3 and term[0] == 'fun' and type(term[1]) is str and type(term[2]) is list,
          'finite function term', check)
    _need(term[1] in functions and type(functions[term[1]]) is int and
          functions[term[1]] == len(term[2]), 'declared function arity', check)
    for child in term[2]:
        _logical_term(child, functions, check)


def _formula(formula, functions, predicates, check):
    _need(type(formula) is list and formula, 'finite literal object formula', check)
    kind = formula[0]
    if kind == 'pred':
        _need(len(formula) == 3 and type(formula[1]) is str and type(formula[2]) is list and
              formula[1] in predicates and type(predicates[formula[1]]) is int and
              predicates[formula[1]] == len(formula[2]), 'declared predicate arity', check)
        for term in formula[2]:
            _logical_term(term, functions, check)
    elif kind == 'eq':
        _need(len(formula) == 3, 'equality formula', check)
        _logical_term(formula[1], functions, check); _logical_term(formula[2], functions, check)
    elif kind == 'all':
        _need(len(formula) == 3 and type(formula[1]) is str, 'literal binder name', check)
        _formula(formula[2], functions, predicates, check)
    elif kind in ('imp', 'and', 'or'):
        _need(len(formula) == 3, 'binary formula constructor', check)
        _formula(formula[1], functions, predicates, check); _formula(formula[2], functions, predicates, check)
    elif kind == 'not':
        _need(len(formula) == 2, 'negation formula', check)
        _formula(formula[1], functions, predicates, check)
    else:
        _need(formula == ['bot'], 'supported object-language formula', check)


def _extract(request, check):
    _need(type(request) is dict and set(request) == {'protocol', 'theory', 'blocks', 'proof', 'target'} and
          request['protocol'] == 'gcts-fol-1' and request['blocks'] == [], 'flat literal proof request', check)
    theory = request['theory']
    _need(type(theory) is dict and set(theory) == {'functions', 'predicates', 'axioms', 'schemas'} and
          theory['schemas'] == [] and all(type(theory[k]) is dict for k in ('functions', 'predicates', 'axioms')),
          'declared finite first-order theory without schemas', check)
    proof = request['proof']; _need(type(proof) is list and proof, 'nonempty literal proof', check)
    nodes = []; ports = []; aliases = []; by_formula = {}; rows = []; has_MP = False
    for row, command in enumerate(proof):
        check(); _need(type(command) is dict and 'formula' in command, 'literal primitive command', check)
        formula = command['formula']; _formula(formula, theory['functions'], theory['predicates'], check)
        if command.get('rule') == 'axiom':
            _need(set(command) == {'rule', 'formula', 'name'} and type(command['name']) is str and
                  command['name'] in theory['axioms'] and theory['axioms'][command['name']] == formula,
                  'exact licensed named axiom', check)
            word = _word(formula, check)
            if word not in by_formula:
                by_formula[word] = len(ports); ports.append(_copy(formula, check)); aliases.append([])
            port = by_formula[word]; aliases[port].append(dict(row=row, name=command['name']))
            nodes.append(dict(row=row, kind='port', port=port))
        else:
            _need(set(command) == {'rule', 'formula', 'antecedent', 'implication'} and command['rule'] == 'mp',
                  'only exact axiom/MP fragment commands', check)
            for key in ('antecedent', 'implication'):
                _need(type(command[key]) is int and 0 <= command[key] < row, 'exact prior concrete reference', check)
            a = command['antecedent']; i = command['implication']
            _need(rows[i] == ['imp', rows[a], formula], 'concrete MP equality', check)
            nodes.append(dict(row=row, kind='mp', antecedent=a, implication=i)); has_MP = True
        rows.append(_copy(formula, check))
    _need(has_MP and request['target'] == rows[-1], 'target is last row and at least one MP', check)
    return nodes, ports, aliases, rows


def _match(pattern, formula, binding, check):
    check()
    if pattern[0] == 'meta':
        variable = pattern[1]
        if variable in binding:
            _need(binding[variable] == formula, 'one exact concrete formula per meta', check)
        else:
            binding[variable] = _copy(formula, check)
        return
    _need(type(formula) is list and len(formula) == 3 and formula[0] == 'imp',
          'concrete Imp instantiation', check)
    _match(pattern[1], formula[1], binding, check); _match(pattern[2], formula[2], binding, check)


def _family(request, provenance, typing, ports, aliases, rows, check):
    binding = {}
    for pattern, formula in zip(typing['premises'], ports):
        _match(pattern, formula, binding, check)
    for pattern, formula in zip(typing['row_formulas'], rows):
        _match(pattern, formula, binding, check)
    _need(set(binding) == set(range(typing['parameters'])), 'complete concrete donor substitution', check)
    converted = []
    for node, formula in zip(typing['graph'], typing['row_formulas']):
        check()
        if node['kind'] == 'port':
            converted.append(dict(rule='assumption', formula=_copy(formula, check), index=node['port']))
        else:
            converted.append(dict(rule='mp', formula=_copy(formula, check),
                                  antecedent=node['antecedent'], implication=node['implication']))
    template = dict(premises=_copy(typing['premises'], check),
                    conclusion=_copy(typing['conclusion'], check), proof=converted)
    identity = _digest(dict(parameters=typing['parameters'], template=template), check)
    certificate = dict(schema=SCHEMA, port_policy=PORT_POLICY,
        request_sha256=_digest(request, check), provenance=_copy(provenance, check),
        typing=_copy(typing, check), concrete_ports=_copy(ports, check),
        port_occurrences=_copy(aliases, check), concrete_row_formulas=_copy(rows, check),
        donor_arguments=[_copy(binding[i], check) for i in range(typing['parameters'])],
        inference_scope='Principal only for this finite fixed axiom/MP DAG and exact-formula port quotient; no open cuts, object-binder alpha conversion, universalized Native rule or cross-family deduplication.')
    return dict(id=identity, structural_id=identity, parameters=typing['parameters'], template=template,
                dependencies=[], provenance=_copy(provenance, check), certificate=certificate,
                scope='Principal finite MP-DAG template; context-checked primitive ordering proposal only.')


def mine(request, provenance, *, check):
    """Extract after caller's fresh Host/Native checks; never supplies those gates."""
    nodes, ports, aliases, rows = _extract(request, check)
    typing = infer_graph(nodes, len(ports), check=check)
    return _family(request, provenance, typing, ports, aliases, rows, check)


def verify(request, family, *, check):
    """Replay elementary finite-unification derivation and every donor row."""
    _need(type(family) is dict and 'certificate' in family and type(family['certificate']) is dict,
          'complete principal family certificate', check)
    certificate = family['certificate']; typing = certificate.get('typing')
    _need(type(typing) is dict and 'unification_trace' in typing and 'provenance' in family,
          'complete derivation and provenance', check)
    nodes, ports, aliases, rows = _extract(request, check)
    graph = _graph(nodes, len(ports), check); equations = _constraints(graph, len(ports), check)
    bindings = _replay(equations, typing['unification_trace'], len(nodes)+len(ports), check)
    replayed = _typing(graph, len(ports), equations, bindings, typing['unification_trace'], check)
    _need(_word(replayed, check) == _word(typing, check), 'all typing/canonicalization fields reproduced', check)
    expected = _family(request, family['provenance'], replayed, ports, aliases, rows, check)
    _need(_word(expected, check) == _word(family, check), 'all family/provenance/concrete witness fields reproduced', check)
    return dict(complete=True, rows=len(rows), ports=len(ports), parameters=typing['parameters'],
                unification_steps=len(typing['unification_trace']), structural_id=family['structural_id'],
                port_policy=PORT_POLICY, scope='Finite elementary-MGU replay and exact donor witness; not Host/Native acceptance or proof of implementation correctness.')
