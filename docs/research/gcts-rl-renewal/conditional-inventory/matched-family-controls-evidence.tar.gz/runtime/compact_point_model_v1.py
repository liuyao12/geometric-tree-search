"""Exact single-owner storage for the unchanged finite Native/point pilot.

Packed words preserve every original byte coordinate/value, including256.
Dependencies index support intervals, not one candidate membership per byte.
No proof oracle, primitive pruning, scheduler or logical rule is added here.
"""
import collections
from collections.abc import Mapping, Set
import itertools
import math
import time
from quantified_family_points_v2 import Model as OriginalModel
from native_receptor_points import merge
from semantic_receptor_points import center
from turtle import Placement

VERSION = 'compact-literal-point-model-v1'
SCHEMA = 'pilot-single-owner-segmented-point-model-v1'


def need(ok, message):
    if not ok:
        raise ValueError(message)


class PairSequence:
    __slots__ = ('left', 'right')
    def __init__(self, left, right):
        object.__setattr__(self, 'left', left); object.__setattr__(self, 'right', right)
    def __setattr__(self, name, value):
        raise AttributeError('immutable point sequence')
    def __iter__(self):
        yield from self.left; yield from self.right
    def __len__(self):
        return len(self.left) + len(self.right)
    def __add__(self, other):
        return PairSequence(self, other)
    def __radd__(self, other):
        return PairSequence(other, self)


class Occupancy(tuple):
    __slots__ = ()
    def __add__(self, other):
        return PairSequence(self, other)


class SegmentMarks:
    __slots__ = ('store', 'sequence_id')
    def __init__(self, store, sequence_id):
        object.__setattr__(self, 'store', store); object.__setattr__(self, 'sequence_id', sequence_id)
    def __setattr__(self, name, value):
        raise AttributeError('immutable segmented marks')
    def __iter__(self):
        for segment_id in self.store.sequences[self.sequence_id]:
            x, y, payload_id = self.store.segments[segment_id]
            payload = self.store.payloads[payload_id]
            for offset in range(0, len(payload), 2):
                yield ((x, y + offset // 2), payload[offset] + 256 * payload[offset + 1])
    def __len__(self):
        return sum(len(self.store.payloads[self.store.segments[s][2]]) // 2
                   for s in self.store.sequences[self.sequence_id])
    def __add__(self, other):
        return PairSequence(self, other)
    def __radd__(self, other):
        return PairSequence(other, self)


class Store:
    def __init__(self, check):
        self.check = check; self.payloads = []; self.segments = []; self.sequences = []
        self._payload_index = {}; self._segment_index = {}; self._sequence_index = {}; self.frozen = False
    def _segment(self, x, y, values):
        packed = bytearray()
        for value in values:
            need(type(value) is int and 0 <= value <= 256, 'exact pilot byte/terminator m value')
            packed.extend((value & 255, value >> 8))
        payload = bytes(packed)
        if payload not in self._payload_index:
            self._payload_index[payload] = len(self.payloads); self.payloads.append(payload)
        p = self._payload_index[payload]; segment = (x, y, p)
        if segment not in self._segment_index:
            self._segment_index[segment] = len(self.segments); self.segments.append(segment)
        return self._segment_index[segment]
    def add(self, merged):
        need(not self.frozen, 'construction-only literal store'); self.check()
        ids = []; x = None; y = None; values = []
        for index, (point, value) in enumerate(merged):
            if index % 128 == 0:
                self.check()
            need(type(point) is tuple and len(point) == 2 and all(type(v) is int for v in point),
                 'exact two-integer pilot coordinate')
            px, py = point
            if values and (px != x or py != y + len(values)):
                ids.append(self._segment(x, y, values)); values = []
            if not values:
                x, y = px, py
            values.append(value)
        if values:
            ids.append(self._segment(x, y, values))
        sequence = tuple(ids)
        if sequence not in self._sequence_index:
            i = len(self.sequences); self._sequence_index[sequence] = i
            self.sequences.append(sequence)
        return SegmentMarks(self, self._sequence_index[sequence])
    def freeze(self):
        self.check(); self.payloads = tuple(self.payloads); self.segments = tuple(self.segments)
        self.sequences = tuple(self.sequences)
        self._payload_index = None; self._segment_index = None; self._sequence_index = None; self.frozen = True


class DependencySet(Set):
    """Fresh repeatable set view; covering groups are pairwise key-disjoint."""
    __slots__ = ('groups',)
    def __init__(self, groups):
        values = tuple(groups)
        need(all(type(group) is frozenset for group in values), 'immutable exact dependency groups')
        object.__setattr__(self, 'groups', values)
    def __setattr__(self, name, value):
        raise AttributeError('immutable dependency set view')
    def __contains__(self, key):
        return any(key in group for group in self.groups)
    def __len__(self):
        return sum(map(len, self.groups))
    def __iter__(self):
        return itertools.chain.from_iterable(self.groups)


class Dependencies:
    """Each group is a complete support interval and a set of candidate keys."""
    def __init__(self, check):
        self.check = check; self._groups = {}; self._by_x = None; self.frozen = False
    def add(self, interval, key):
        need(not self.frozen, 'construction-only dependencies')
        self._groups.setdefault(interval, set()).add(key)
    def freeze(self):
        by_x = collections.defaultdict(list)
        for interval in self._groups:
            self.check(); self._groups[interval] = frozenset(self._groups[interval])
            by_x[interval[0]].append(interval)
        self._by_x = {x: tuple(sorted(rows)) for x, rows in by_x.items()}; self.frozen = True
    def get(self, point, default=()):
        need(self.frozen, 'completed dependency admission')
        need(type(point) is tuple and len(point) == 2 and all(type(v) is int for v in point),
             'exact dependency point')
        x, y = point; groups = []
        for interval in self._by_x.get(x, ()):
            self.check(); unused, start, length = interval
            if start <= y < start + length:
                groups.append(self._groups[interval])
        return DependencySet(groups) if groups else default
    def __contains__(self, point):
        return bool(self.get(point))
    def reference_audit_lookup_index(self):
        need(self.frozen, 'completed lookup index')
        rows = []
        for x in sorted(self._by_x):
            self.check(); rows.append((x, self._by_x[x]))
        return tuple(rows)
    def reference_audit_terms(self):
        need(self.frozen, 'completed dependency groups')
        rows = []
        for interval in sorted(self._groups):
            self.check(); rows.append((*interval, self._groups[interval]))
        return tuple(rows)


class Model(OriginalModel):
    def __init__(self, spec, compiled, inventory, arity=0, families=False, *, check):
        need(arity == 0 and families is False and not inventory['definitions'] and
             not inventory['interfaces'] and not inventory['native_blocks'], 'exact primitive pilot profile')
        self._compact_check = check; self.mark_store = Store(check)
        super().__init__(spec, compiled, inventory, arity=arity, families=families)
        self.mark_store.freeze(); self.dependencies.freeze(); check()
    def add(self, key, entries, command, requirements, kind, **extra):
        self._compact_check()
        if not isinstance(self.dependencies, Dependencies):
            self.dependencies = Dependencies(self._compact_check)
        merged = merge(entries)
        if merged is None:
            self.conflicts.append(dict(key=key, reason='internally unequal markings')); return
        need(key not in self.cache, 'duplicate placement')
        marks = self.mark_store.add(merged); root = center(key[0], key[1])
        self.cache[key] = Placement(key, Occupancy(((root, 12),)), marks, ())
        self.metadata[key] = dict(slot=key[0], kind=kind, command=command, requirements=requirements, **extra)
        self.align_cache[root].append(key); intervals = [(root[0], root[1], 1)]
        for sid in self.mark_store.sequences[marks.sequence_id]:
            x, y, pid = self.mark_store.segments[sid]
            intervals.append((x, y, len(self.mark_store.payloads[pid]) // 2))
        ordered = sorted(intervals)
        need(all(a[0] != b[0] or a[1] + a[2] <= b[1] for a, b in zip(ordered, ordered[1:])),
             'per-candidate disjoint complete support intervals')
        for interval in intervals:
            self.dependencies.add(interval, key)


class OverlayCache(Mapping):
    def __init__(self, base, replacements):
        self.base = base; self.replacements = replacements
    def __getitem__(self, key):
        return self.replacements[key] if key in self.replacements else self.base[key]
    def __iter__(self):
        return iter(self.base)
    def __len__(self):
        return len(self.base)


class OverlayDependencies:
    def __init__(self, base, extra):
        self.base = base; self.extra = extra
    def get(self, point, default=()):
        prior = self.base.get(point, ())
        added = self.extra.get(point, ())
        if added:
            need(not prior, 'fresh overlay support is disjoint from base')
            return DependencySet((frozenset(added),))
        if prior:
            return prior if isinstance(prior, DependencySet) else DependencySet((frozenset(prior),))
        return default
    def __contains__(self, point):
        return bool(self.get(point))


class MarkedModel:
    def __init__(self, base, packet, points):
        self.base = base; self.packet = packet; replacements = {}; extra = {}; self.initial_auxiliary = {}
        for field in ('align_cache','metadata','domains','spec','compiled','inventory','arity','mode','interfaces'):
            setattr(self, field, getattr(base, field))
        self.metrics = collections.Counter()
        for c in packet['certificates']:
            a = c['auxiliary']; key = a['placement']; point = a['point']
            need(point not in base.dependencies and point not in base.initial().marks and
                 point not in self.initial_auxiliary, 'fresh auxiliary mark-only coordinate')
            old = replacements.get(key, base.placement(key))
            # Fresh negative-x points precede every nonnegative base coordinate.
            need(point[0] == -100, 'declared auxiliary coordinate domain')
            marks = PairSequence(((point, a['placement_value']),), old.marks)
            replacements[key] = Placement(old.key, Occupancy(old.occupancy), marks, old.vertices)
            extra.setdefault(point, set()).add(key); self.initial_auxiliary[point] = a['initial_value']
        self.cache = OverlayCache(base.cache, replacements)
        self.dependencies = OverlayDependencies(base.dependencies, extra)
    def placement(self, key):
        return self.cache[key]
    def alignments(self, point):
        return self.align_cache[point]
    def initial(self):
        state = self.base.initial(); state.marks.update(self.initial_auxiliary); return state
    def decode(self, keys):
        return self.base.decode(keys)


def _wire(value):
    if type(value) in (tuple, list) or isinstance(value, Occupancy):
        return [_wire(v) for v in value]
    if type(value) is dict:
        return {k: _wire(v) for k, v in value.items()}
    return value


def evidence_view(model, check):
    """Only small references/metadata are copied; no mark pair/reverse maps."""
    store = model.mark_store; rows = []
    for key in sorted(model.cache):
        check(); tile = model.cache[key]; metadata = dict(model.metadata[key]); command = metadata.pop('command')
        need(command is not None and command == model.domains[key[0]][key[2]], 'exact primitive command owner')
        rows.append(dict(key=list(key), occupancy=_wire(tile.occupancy), marking_sequence=tile.marks.sequence_id,
                         vertices=_wire(tile.vertices), metadata=_wire(metadata), command_reference=[key[0], key[2]]))
    state = model.initial()
    return dict(schema=SCHEMA, payloads=[p.hex() for p in store.payloads],
        segments=[list(s) for s in store.segments], sequences=[list(s) for s in store.sequences],
        placements=rows, domains=model.domains,
        alignments=[dict(point=list(p), keys=[list(k) for k in ks]) for p, ks in sorted(model.align_cache.items())],
        conflicts=_wire(model.conflicts), arity=model.arity, mode_ids=model.mode,
        initial=_wire(dict(totals=sorted(state.totals.items()), marks=sorted(state.marks.items()),
                          generations=sorted(state.generations.items()), roots=sorted(state.roots.items()),
                          selected=sorted(state.selected), order=state.order, tile_generations=state.tile_generations,
                          allowed_points=sorted(state.allowed_points))),
        base_compile_seconds=model.compile_seconds,
        declarations=dict(packing='unsigned16 little endian; exact0..256',
                          coordinate='segment(x,y0,payload): pair((x,y0+i),value[i])',
                          sequence='ordered segment refs decode sorted unique point/value support',
                          dependencies='complete t/mark support interval groups; exact fresh repeatable set view lookup',
                          transformations='original fixed positional translated placements only',
                          scope='new Native/point carrier; no old G0/G1/fullWang/RL acceptance'))


def _same(left, right, check):
    stack = [(left, right)]
    while stack:
        check(); a, b = stack.pop()
        if type(b) in (list, tuple) or isinstance(b, Occupancy):
            if type(a) is not list or len(a) != len(b):
                return False
            stack.extend(zip(a, b))
        elif type(b) is dict:
            if type(a) is not dict or set(a) != set(b):
                return False
            stack.extend((a[k], b[k]) for k in b)
        elif type(a) is not type(b) or a != b:
            return False
    return True


def verify_evidence(packet, model, check):
    """Full wire->actual owner reconciliation; L independently checks old values."""
    expected_fields = {'schema','payloads','segments','sequences','placements','domains','alignments',
                       'conflicts','arity','mode_ids','initial','base_compile_seconds','declarations'}
    need(type(packet) is dict and set(packet) == expected_fields and packet['schema'] == SCHEMA, 'exact compact evidence fields')
    store = model.mark_store
    need(type(packet['payloads']) is list and len(packet['payloads']) == len(store.payloads), 'whole literal payload population')
    for text, raw in zip(packet['payloads'], store.payloads):
        check(); need(type(text) is str and text == raw.hex(), 'exact full payload bytes')
        need(len(raw) % 2 == 0 and all(raw[i] + 256 * raw[i+1] <= 256 for i in range(0,len(raw),2)), 'pilot uint16 domain')
    need(_same(packet['segments'], store.segments, check) and _same(packet['sequences'], store.sequences, check), 'whole ordered segment/sequence references')
    need(type(packet['placements']) is list and len(packet['placements']) == len(model.cache), 'whole placement population')
    for row, key in zip(packet['placements'], sorted(model.cache)):
        check(); tile = model.cache[key]; metadata = dict(model.metadata[key]); command = metadata.pop('command')
        need(type(row) is dict and set(row) == {'key','occupancy','marking_sequence','vertices','metadata','command_reference'}, 'exact placement row')
        need(_same(row['key'], key, check) and _same(row['occupancy'], tile.occupancy, check) and
             _same(row['vertices'], tile.vertices, check) and _same(row['metadata'], metadata, check), 'full literal placement metadata/t')
        need(type(row['marking_sequence']) is int and row['marking_sequence'] == tile.marks.sequence_id, 'actual complete m sequence reference')
        need(_same(row['command_reference'], [key[0],key[2]], check) and command is not None and
             _same(packet['domains'][key[0]][key[2]], command, check), 'exact command reference')
    need(_same(packet['domains'], model.domains, check) and _same(packet['conflicts'], model.conflicts, check) and
         type(packet['arity']) is int and packet['arity'] == 0 and _same(packet['mode_ids'], model.mode, check), 'full primitive domain/interface data')
    need(_same(packet['alignments'], [dict(point=p,keys=ks) for p,ks in sorted(model.align_cache.items())], check), 'complete ordered alignment domains')
    state = model.initial(); expected_initial = dict(totals=sorted(state.totals.items()), marks=sorted(state.marks.items()),
        generations=sorted(state.generations.items()), roots=sorted(state.roots.items()), selected=sorted(state.selected),
        order=state.order, tile_generations=state.tile_generations, allowed_points=sorted(state.allowed_points))
    need(_same(packet['initial'], expected_initial, check), 'complete exact boundary state')
    need(type(packet['base_compile_seconds']) is float and math.isfinite(packet['base_compile_seconds']) and
         packet['base_compile_seconds'] >= 0 and packet['base_compile_seconds'] == model.compile_seconds, 'actual construction timing')
    declarations = dict(packing='unsigned16 little endian; exact0..256',
        coordinate='segment(x,y0,payload): pair((x,y0+i),value[i])',
        sequence='ordered segment refs decode sorted unique point/value support',
        dependencies='complete t/mark support interval groups; exact fresh repeatable set view lookup',
        transformations='original fixed positional translated placements only',
        scope='new Native/point carrier; no old G0/G1/fullWang/RL acceptance')
    need(_same(packet['declarations'], declarations, check), 'all carrier declarations')
    return dict(complete=True, placements=len(model.cache), payloads=len(store.payloads),
                segments=len(store.segments), sequences=len(store.sequences), scope='full exact wire/actual owner join')
