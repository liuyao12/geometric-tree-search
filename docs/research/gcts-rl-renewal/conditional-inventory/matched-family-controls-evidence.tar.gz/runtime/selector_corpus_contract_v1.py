"""Prospective corpus-format and finite-interpretation controls only.

No file access, evaluation literals, proof routes, policy weights or imports of
the scientific engine. These functions may run only inside a fresh reviewed
Root actual. Source authoring/AST inspection does not execute these controls.
"""
import copy

# Exact literal companion to control-inputs-v1.json; no evaluation formulas.
CONTROL_DOCUMENT = {'format_negatives': ['wrong-schema',
                      'extra-proof-top',
                      'wrong-training-count',
                      'duplicate-id',
                      'length-bool',
                      'length-zero',
                      'instantiation-bool',
                      'unknown-predicate',
                      'arity-bool',
                      'predicate-arity',
                      'free-variable',
                      'unknown-function',
                      'nonempty-schemas',
                      'extra-proof-case',
                      'bad-formula-tag',
                      'training-quantifier-refused'],
 'schema': 'gcts-selector-corpus-controls-v1',
 'scope': 'Six independent tiny manually supplied interpretations and sixteen format refusals. '
          'These are not evaluation literals, donor proofs, learned labels or supplied to a proof '
          'proposer. All controls are UNRUN until a fresh reviewed actual. UNKNOWN search outcomes '
          'are never converted into countermodels.',
 'semantic_controls': [{'expected_axioms': [True],
                        'expected_target': False,
                        'id': 'external-propositional-countermodel',
                        'license': 'A manually supplied finite countermodel control; never a '
                                   'proof-search label or training/evaluation theorem.',
                        'model': {'domain': [0], 'functions': {}, 'predicates': {'U': [], 'V': []}},
                        'target': ['pred', 'V', []],
                        'theory': {'axioms': {'c0': ['imp', ['pred', 'U', []], ['pred', 'V', []]]},
                                   'functions': {},
                                   'predicates': {'U': 0, 'V': 0},
                                   'schemas': []}},
                       {'expected_axioms': [True],
                        'expected_target': False,
                        'id': 'external-quantified-countermodel',
                        'license': 'External all-false unary interpretation; quantified '
                                   'implication alone does not supply its antecedent.',
                        'model': {'domain': [0],
                                  'functions': {'d': [[[], 0]]},
                                  'predicates': {'U': [], 'V': []}},
                        'target': ['pred', 'V', [['fun', 'd', []]]],
                        'theory': {'axioms': {'c0': ['all',
                                                     'z',
                                                     ['imp',
                                                      ['pred', 'U', [['var', 'z']]],
                                                      ['pred', 'V', [['var', 'z']]]]]},
                                   'functions': {'d': 0},
                                   'predicates': {'U': 1, 'V': 1},
                                   'schemas': []}},
                       {'expected_axioms': [True],
                        'expected_target': False,
                        'id': 'external-equality-countermodel',
                        'license': 'External two-element interpretation with distinct constants; '
                                   'identity is interpreted as exact domain equality.',
                        'model': {'domain': [0, 1],
                                  'functions': {'d': [[[], 0]], 'e': [[[], 1]]},
                                  'predicates': {}},
                        'target': ['eq', ['fun', 'd', []], ['fun', 'e', []]],
                        'theory': {'axioms': {'c0': ['eq', ['fun', 'd', []], ['fun', 'd', []]]},
                                   'functions': {'d': 0, 'e': 0},
                                   'predicates': {},
                                   'schemas': []}},
                       {'expected_axioms': [True, True],
                        'expected_target': True,
                        'id': 'external-propositional-positive-interpretation',
                        'license': 'One satisfying interpretation, not proof that the conclusion '
                                   'holds in every interpretation.',
                        'model': {'domain': [0],
                                  'functions': {},
                                  'predicates': {'U': [[]], 'V': [[]]}},
                        'target': ['pred', 'V', []],
                        'theory': {'axioms': {'c0': ['pred', 'U', []],
                                              'c1': ['imp', ['pred', 'U', []], ['pred', 'V', []]]},
                                   'functions': {},
                                   'predicates': {'U': 0, 'V': 0},
                                   'schemas': []}},
                       {'expected_axioms': [True],
                        'expected_target': True,
                        'id': 'external-quantified-positive-interpretation',
                        'license': 'Two-element universal-truth control; no formula is an acquired '
                                   'lemma or search hint.',
                        'model': {'domain': [0, 1],
                                  'functions': {'d': [[[], 0]]},
                                  'predicates': {'U': [[0], [1]]}},
                        'target': ['pred', 'U', [['fun', 'd', []]]],
                        'theory': {'axioms': {'c0': ['all', 'z', ['pred', 'U', [['var', 'z']]]]},
                                   'functions': {'d': 0},
                                   'predicates': {'U': 1},
                                   'schemas': []}},
                       {'expected_axioms': [True],
                        'expected_target': True,
                        'id': 'external-congruence-positive-interpretation',
                        'license': 'One finite function interpretation; checks evaluator '
                                   'composition only, not a theorem proof.',
                        'model': {'domain': [0],
                                  'functions': {'d': [[[], 0]], 'e': [[[], 0]], 'k': [[[0], 0]]},
                                  'predicates': {}},
                        'target': ['eq',
                                   ['fun', 'k', [['fun', 'd', []]]],
                                   ['fun', 'k', [['fun', 'e', []]]]],
                        'theory': {'axioms': {'c0': ['eq', ['fun', 'd', []], ['fun', 'e', []]]},
                                   'functions': {'d': 0, 'e': 0, 'k': 1},
                                   'predicates': {},
                                   'schemas': []}}]}

_OWNER = object()


class CorpusContractError(ValueError):
    def __init__(self, message, owner=None):
        super().__init__(message)
        self.owner = owner


def _need(value, message):
    if not value:
        raise CorpusContractError(message, _OWNER)


def _name(value):
    return type(value) is str and bool(value)


def _term(value, functions, bound, check):
    check()
    _need(type(value) is list and len(value) in (2, 3), 'term shape')
    if value[0] == 'var':
        _need(len(value) == 2 and _name(value[1]) and value[1] in bound,
              'closed root formula requires a bound variable')
        return
    _need(len(value) == 3 and value[0] == 'fun' and _name(value[1])
          and value[1] in functions and type(value[2]) is list,
          'declared function term')
    _need(len(value[2]) == functions[value[1]], 'function arity')
    for argument in value[2]:
        _term(argument, functions, bound, check)


def _formula(value, functions, predicates, bound, check):
    check()
    _need(type(value) is list and bool(value) and type(value[0]) is str,
          'formula shape')
    tag = value[0]
    if tag == 'bot':
        _need(len(value) == 1, 'bottom arity')
    elif tag == 'pred':
        _need(len(value) == 3 and _name(value[1]) and value[1] in predicates
              and type(value[2]) is list, 'declared predicate')
        _need(len(value[2]) == predicates[value[1]], 'predicate arity')
        for argument in value[2]:
            _term(argument, functions, bound, check)
    elif tag == 'eq':
        _need(len(value) == 3, 'equality arity')
        _term(value[1], functions, bound, check)
        _term(value[2], functions, bound, check)
    elif tag == 'all':
        _need(len(value) == 3 and _name(value[1]), 'universal binder')
        _formula(value[2], functions, predicates, bound | {value[1]}, check)
    elif tag == 'not':
        _need(len(value) == 2, 'negation arity')
        _formula(value[1], functions, predicates, bound, check)
    else:
        _need(tag in ('imp', 'and', 'or') and len(value) == 3,
              'supported connective and arity')
        _formula(value[1], functions, predicates, bound, check)
        _formula(value[2], functions, predicates, bound, check)


def _theory(theory, check):
    check()
    _need(type(theory) is dict and set(theory) ==
          {'functions', 'predicates', 'axioms', 'schemas'}, 'exact theory fields')
    _need(type(theory['functions']) is dict and
          type(theory['predicates']) is dict and
          type(theory['axioms']) is dict and
          type(theory['schemas']) is list and not theory['schemas'],
          'literal signature, axioms and empty schemas')
    for signature in (theory['functions'], theory['predicates']):
        for name, arity in signature.items():
            check()
            _need(_name(name) and type(arity) is int and 0 <= arity <= 2,
                  'fixed exact-int arity')
    for name, formula in theory['axioms'].items():
        check()
        _need(_name(name), 'axiom name')
        _formula(formula, theory['functions'], theory['predicates'], set(), check)


def _nullary_implication(value, check):
    check()
    _need(type(value) is list and bool(value), 'nullary implication formula')
    if value[0] == 'pred':
        _need(len(value) == 3 and value[2] == [], 'nullary atom')
        return
    _need(value[0] == 'imp' and len(value) == 3,
          'training has only nullary atoms and implication')
    _nullary_implication(value[1], check)
    _nullary_implication(value[2], check)


def _case(spec, training, check):
    check()
    _need(type(spec) is dict and set(spec) ==
          {'id', 'title', 'theory', 'target', 'length',
           'instantiation_rounds', 'scope'}, 'exact statement-only case fields')
    _need(all(_name(spec[key]) for key in ('id', 'title', 'scope')),
          'literal case descriptions')
    _need(type(spec['length']) is int and 1 <= spec['length'] <= 15,
          'exact primitive row bound')
    _need(type(spec['instantiation_rounds']) is int and
          spec['instantiation_rounds'] == 2, 'fixed two UI rounds')
    _theory(spec['theory'], check)
    if training:
        _need(not spec['theory']['functions'] and
              all(arity == 0 for arity in spec['theory']['predicates'].values()),
              'nullary training signature only')
        for formula in spec['theory']['axioms'].values():
            _nullary_implication(formula, check)
        _nullary_implication(spec['target'], check)
    _formula(spec['target'], spec['theory']['functions'],
             spec['theory']['predicates'], set(), check)


def _cases(document, key, count, schema, check):
    check()
    _need(type(document) is dict and set(document) ==
          {'schema', 'id', key, 'protocol'}, 'exact phase document fields')
    _need(document['schema'] == schema and _name(document['id']),
          'phase schema')
    _need(type(document[key]) is list and len(document[key]) == count,
          'complete phase population')
    seen = set()
    for spec in document[key]:
        check()
        _case(spec, key == 'training', check)
        _need(spec['id'] not in seen, 'distinct full case IDs')
        seen.add(spec['id'])
    _need(type(document['protocol']) is dict and
          document['protocol'].get('actual_execution_authorized') is False,
          'data is not an execution grant')
    return [spec['id'] for spec in document[key]]


def validate_training_document(document, *, check):
    ids = _cases(document, 'training', 12,
                 'gcts-selector-training-inputs-v1', check)
    protocol = document['protocol']
    _need(set(protocol) == {'training_seed', 'episodes_per_problem',
          'episode_order', 'input_scope', 'row_bounds_scope',
          'expected_outcomes', 'actual_execution_authorized'},
          'training metadata excludes evaluation/weights/routes')
    _need(type(protocol['training_seed']) is int and protocol['training_seed'] == 0
          and type(protocol['episodes_per_problem']) is int
          and protocol['episodes_per_problem'] == 2
          and protocol['episode_order'] == 'two complete passes of training manifest order',
          'frozen training seed and two-pass schedule')
    _need([spec['length'] for spec in document['training']] == [3]*4 + [5]*8,
          'balanced fixed training profiles')
    check()
    return dict(schema='selector-training-corpus-format-v1', complete=True,
                cases=12, case_ids=ids, statement_only=True,
                scope='Signature/closed-formula/format license only; no proof or satisfiability validation.')


def validate_evaluation_document(document, *, check):
    ids = _cases(document, 'evaluation', 6,
                 'gcts-selector-evaluation-inputs-v1', check)
    protocol = document['protocol']
    _need(set(protocol) == {'evaluation_seeds', 'arm_order', 'intake',
          'split_label', 'actual_execution_authorized'}, 'evaluation metadata fields')
    _need(type(protocol['evaluation_seeds']) is list and
          len(protocol['evaluation_seeds']) == 2 and
          all(type(seed) is int for seed in protocol['evaluation_seeds']) and
          protocol['evaluation_seeds'] == [0, 1], 'two declared evaluation seeds')
    _need(type(protocol['arm_order']) is dict and set(protocol['arm_order']) == set(ids),
          'all evaluation schedules')
    methods = {'S0', 'SH', 'P0', 'PH', 'PU', 'PR'}
    for case_id in ids:
        check()
        orders = protocol['arm_order'][case_id]
        _need(type(orders) is dict and set(orders) == {'0', '1'}, 'seed schedule fields')
        for order in orders.values():
            check()
            _need(type(order) is list and len(order) == 6 and
                  all(type(item) is str for item in order) and set(order) == methods,
                  'complete six-method order')
    _need([spec['length'] for spec in document['evaluation']] == [12, 15, 11, 11, 9, 11],
          'exact evaluation primitive profiles')
    check()
    return dict(schema='selector-evaluation-corpus-format-v1', complete=True,
                cases=6, case_ids=ids, seeds=[0, 1], statement_only=True,
                scope='Called after separate Root policy/library freeze; this function cannot enforce filesystem intake isolation.')


def _tuples(domain, arity, check):
    values = [()]
    for unused in range(arity):
        check()
        following = []
        for prefix in values:
            for value in domain:
                check()
                following.append(prefix + (value,))
        values = following
    return values


def _interpretation(theory, model, check):
    _theory(theory, check)
    _need(type(model) is dict and set(model) == {'domain', 'functions', 'predicates'},
          'finite interpretation fields')
    domain = model['domain']
    _need(type(domain) is list and 1 <= len(domain) <= 2 and
          all(type(value) is int for value in domain) and len(set(domain)) == len(domain),
          'one or two exact domain elements')
    _need(type(model['functions']) is dict and type(model['predicates']) is dict and
          set(model['functions']) == set(theory['functions']) and
          set(model['predicates']) == set(theory['predicates']), 'total signature interpretation')
    functions = {}
    predicates = {}
    for name, arity in theory['functions'].items():
        check()
        table = model['functions'][name]
        _need(type(table) is list, 'function table')
        rows = {}
        for row in table:
            check()
            _need(type(row) is list and len(row) == 2 and type(row[0]) is list and
                  len(row[0]) == arity and all(type(v) is int and v in domain for v in row[0])
                  and type(row[1]) is int and row[1] in domain, 'function table row')
            key = tuple(row[0])
            _need(key not in rows, 'unique function argument row')
            rows[key] = row[1]
        _need(set(rows) == set(_tuples(domain, arity, check)), 'complete function table')
        functions[name] = rows
    for name, arity in theory['predicates'].items():
        check()
        extension = model['predicates'][name]
        _need(type(extension) is list, 'predicate extension')
        rows = set()
        for row in extension:
            check()
            _need(type(row) is list and len(row) == arity and
                  all(type(v) is int and v in domain for v in row), 'predicate tuple')
            key = tuple(row)
            _need(key not in rows, 'unique predicate tuple')
            rows.add(key)
        predicates[name] = rows
    return domain, functions, predicates


def _term_value(term, env, functions, check):
    check()
    if term[0] == 'var':
        return env[term[1]]
    arguments = []
    for argument in term[2]:
        arguments.append(_term_value(argument, env, functions, check))
    return functions[term[1]][tuple(arguments)]


def _truth(formula, env, domain, functions, predicates, check):
    check()
    tag = formula[0]
    if tag == 'bot':
        return False
    if tag == 'pred':
        arguments = []
        for term in formula[2]:
            arguments.append(_term_value(term, env, functions, check))
        return tuple(arguments) in predicates[formula[1]]
    if tag == 'eq':
        return (_term_value(formula[1], env, functions, check) ==
                _term_value(formula[2], env, functions, check))
    if tag == 'all':
        truths = []
        for element in domain:
            check()
            local = dict(env)
            local[formula[1]] = element
            truths.append(_truth(formula[2], local, domain, functions, predicates, check))
        return all(truths)
    if tag == 'not':
        return not _truth(formula[1], env, domain, functions, predicates, check)
    left = _truth(formula[1], env, domain, functions, predicates, check)
    right = _truth(formula[2], env, domain, functions, predicates, check)
    if tag == 'imp':
        return not left or right
    return left and right if tag == 'and' else left or right


def _mutation(document, recipe):
    # Diagnostic-only independent changes; never a search/corpus generator.
    bad = copy.deepcopy(document)
    first = bad['training'][0]
    if recipe == 'wrong-schema': bad['schema'] = 'other'
    elif recipe == 'extra-proof-top': bad['proof'] = []
    elif recipe == 'wrong-training-count': bad['training'].pop()
    elif recipe == 'duplicate-id': bad['training'][1]['id'] = first['id']
    elif recipe == 'length-bool': first['length'] = True
    elif recipe == 'length-zero': first['length'] = 0
    elif recipe == 'instantiation-bool': first['instantiation_rounds'] = True
    elif recipe == 'unknown-predicate': first['target'] = ['pred', 'UNDECLARED', []]
    elif recipe == 'arity-bool': first['theory']['predicates']['A'] = False
    elif recipe == 'predicate-arity': first['target'] = ['pred', 'A', [['var', 'x']]]
    elif recipe == 'free-variable': first['target'] = ['eq', ['var', 'x'], ['var', 'x']]
    elif recipe == 'unknown-function': first['target'] = ['eq', ['fun', 'UNDECLARED', []], ['fun', 'UNDECLARED', []]]
    elif recipe == 'nonempty-schemas': first['theory']['schemas'] = ['unlicensed']
    elif recipe == 'extra-proof-case': first['proof'] = []
    elif recipe == 'bad-formula-tag': first['target'] = ['unknown']
    elif recipe == 'training-quantifier-refused': first['target'] = ['all', 'x', ['pred', 'A', []]]
    else: _need(False, 'unknown declared format control')
    return bad


def run_corpus_controls(training_document, controls_document=None, *, check):
    check()
    if controls_document is None:
        controls_document = CONTROL_DOCUMENT
    positive = validate_training_document(training_document, check=check)
    _need(type(controls_document) is dict and set(controls_document) ==
          {'schema', 'format_negatives', 'semantic_controls', 'scope'}, 'control document fields')
    _need(controls_document['schema'] == 'gcts-selector-corpus-controls-v1', 'control schema')
    recipes = controls_document['format_negatives']
    _need(type(recipes) is list and len(recipes) == 16 and
          all(type(recipe) is str for recipe in recipes) and len(set(recipes)) == 16,
          'sixteen distinct format controls')
    results = [dict(id='valid-training-format', status='PASSED', complete=True,
                    actual=positive)]
    for recipe in recipes:
        check()
        refused = False
        try:
            validate_training_document(_mutation(training_document, recipe), check=check)
        except CorpusContractError as error:
            if error.owner is not _OWNER:
                raise
            refused = True
        _need(refused, 'malformed corpus was not refused')
        results.append(dict(id=recipe, status='PASSED', complete=True,
                            owned_format_refusal=True))
    semantics = controls_document['semantic_controls']
    _need(type(semantics) is list and len(semantics) == 6, 'six tiny interpretations')
    seen = set()
    for case in semantics:
        check()
        _need(type(case) is dict and set(case) ==
              {'id', 'theory', 'target', 'model', 'expected_axioms',
               'expected_target', 'license'}, 'semantic control fields')
        _need(_name(case['id']) and case['id'] not in seen, 'semantic control identity')
        seen.add(case['id'])
        domain, functions, predicates = _interpretation(case['theory'], case['model'], check)
        _formula(case['target'], case['theory']['functions'], case['theory']['predicates'], set(), check)
        truths = []
        for formula in case['theory']['axioms'].values():
            truths.append(_truth(formula, {}, domain, functions, predicates, check))
        target = _truth(case['target'], {}, domain, functions, predicates, check)
        _need(type(case['expected_axioms']) is list and
              all(type(v) is bool for v in case['expected_axioms']) and
              type(case['expected_target']) is bool and
              truths == case['expected_axioms'] and target is case['expected_target'],
              'finite interpretation expectation')
        _need(all(truths), 'control interpretation satisfies all premises')
        results.append(dict(id=case['id'], status='PASSED', complete=True,
                            axiom_truths=truths, target_truth=target,
                            manually_supplied_interpretation=True,
                            supplied_to_proof_search=False,
                            scope='External interpretation control only; not a searched proof or automatic model finding.'))
    check()
    return dict(schema='selector-corpus-controls-receipt-v1', complete=True,
                status='PASSED', controls=results, control_count=23,
                scope='Only callable in a future reviewed Root actual; no evaluation file or policy data is read. All work charged to the current whole job. Format/finite-interpretation controls do not prove theorem search completeness.')
