"""Independent finite principal-MP reference and HAND-AUTHORED CONTROLS ONLY.

No training donor, search route, or accepted library is supplied by this file.
All functions are unexecuted until a separately reviewed Root actual invokes
them. Eager whole-equation substitution deliberately differs from a mutable
term-cell/union-find production implementation. Finite controls are not a
mechanized proof of the general theorem.
"""
import copy

VERSION = 'independent-principal-MP-reference-v1'
MAX_UNITS = 200000
_OWNER = object()


class ReferenceError(Exception):
    def __init__(self, code, message, *, owner=None):
        super().__init__(message)
        self.code = code
        self.owner = owner


def is_owned_error(error):
    return type(error) is ReferenceError and error.owner is _OWNER


class _Work:
    def __init__(self, check):
        self.check = check
        self.units = 0

    def tick(self):
        # The genuine caller callback always precedes private classification.
        self.check()
        self.units += 1
        if self.units > MAX_UNITS:
            raise ReferenceError('REFERENCE_QUOTA', 'finite reference unit bound', owner=_OWNER)


def _need(condition, message, code='INVALID_GRAPH'):
    if not condition:
        raise ReferenceError(code, message, owner=_OWNER)


def _variable(index):
    return ('variable', index)


def _arrow(left, right):
    return ('arrow', left, right)


def _occurs(variable, term, work, depth=0):
    work.tick()
    if depth > 256:
        raise ReferenceError('REFERENCE_QUOTA', 'finite reference depth', owner=_OWNER)
    if term[0] == 'variable':
        return term[1] == variable
    if _occurs(variable, term[1], work, depth+1):
        return True
    return _occurs(variable, term[2], work, depth+1)


def _replace(variable, replacement, term, work, depth=0):
    work.tick()
    if depth > 256:
        raise ReferenceError('REFERENCE_QUOTA', 'finite reference depth', owner=_OWNER)
    if term[0] == 'variable':
        return replacement if term[1] == variable else term
    left = _replace(variable, replacement, term[1], work, depth+1)
    right = _replace(variable, replacement, term[2], work, depth+1)
    return _arrow(left, right)


def infer_graph(nodes, port_count, *, check):
    """Infer the fixed full ordered graph, preserving all declared port aliases.

    Strict graph API: exact list of exact dictionaries. Port rows have
    row/kind/port; MP rows have row/kind/antecedent/implication. Every declared
    port is used. Only strictly earlier row references are legal. An unused
    proof row can remain and contributes its constraints; no minimality claim.
    """
    work = _Work(check)
    work.tick()
    _need(type(nodes) is list and 1 <= len(nodes) <= 64, 'one to sixty-four control graph rows')
    _need(type(port_count) is int and 1 <= port_count <= len(nodes), 'exact positive port count')
    used, equations = set(), []
    count = len(nodes)
    for row, node in enumerate(nodes):
        work.tick()
        _need(type(node) is dict and type(node.get('row')) is int and node['row'] == row,
              'exact consecutive row identity')
        if node.get('kind') == 'port':
            _need(set(node) == {'row', 'kind', 'port'}, 'exact port row fields')
            port = node['port']
            _need(type(port) is int and 0 <= port < port_count, 'exact port reference')
            used.add(port)
            equations.append((_variable(row), _variable(count+port)))
        else:
            _need(node.get('kind') == 'mp' and set(node) == {'row', 'kind', 'antecedent', 'implication'},
                  'only exact port or MP rows')
            a, i = node['antecedent'], node['implication']
            _need(type(a) is int and type(i) is int and 0 <= a < row and 0 <= i < row,
                  'strictly prior exact integer MP references')
            equations.append((_variable(i), _arrow(_variable(a), _variable(row))))
    _need(used == set(range(port_count)), 'every declared port must occur')
    # Eliminate each variable globally in every remaining equation and every
    # original variable image. No mutable node cells or production helper.
    pending = list(equations)
    images = [_variable(index) for index in range(count+port_count)]
    eliminations = []
    while pending:
        work.tick()
        left, right = pending.pop(0)
        if left == right:
            continue
        if left[0] == 'variable' or right[0] == 'variable':
            if left[0] != 'variable':
                left, right = right, left
            variable = left[1]
            _need(not _occurs(variable, right, work), 'finite occurs check failed', 'OCCURS_CHECK')
            next_pending = []
            for one, two in pending:
                work.tick()
                next_pending.append((_replace(variable, right, one, work),
                                     _replace(variable, right, two, work)))
            pending = next_pending
            next_images = []
            for image in images:
                work.tick()
                next_images.append(_replace(variable, right, image, work))
            images = next_images
            eliminations.append(variable)
        else:
            _need(left[0] == right[0] == 'arrow', 'free constructor clash', 'TYPE_CLASH')
            pending = [(left[1], right[1]), (left[2], right[2])] + pending
    alpha = {}

    def emit(term):
        work.tick()
        if term[0] == 'variable':
            variable = term[1]
            if variable not in alpha:
                alpha[variable] = len(alpha)
            return ['meta', alpha[variable]]
        return ['imp', emit(term[1]), emit(term[2])]

    premises = []
    for port in range(port_count):
        premises.append(emit(images[count+port]))
    conclusion = emit(images[count-1])
    row_formulas = []
    for row in range(count):
        row_formulas.append(emit(images[row]))
    return dict(schema=VERSION, complete=True, premises=premises, conclusion=conclusion,
                row_formulas=row_formulas, parameters=len(alpha), graph=copy.deepcopy(nodes),
                port_count=port_count, units=work.units, eliminated_variables=eliminations,
                scope='Fixed finite full graph and declared port sharing only; no theorem-search or minimality claim.')


def _formula(value, work, depth=0):
    """Syntactic finite FOL carrier, not a common-kernel proof-rule checker.

    Symbol licensing/closed-theory conditions remain concrete Host/Native
    duties. These controls use declared well-formed signatures throughout.
    """
    work.tick()
    _need(depth <= 128 and type(value) is list and value and type(value[0]) is str,
          'finite literal formula', 'INVALID_DONOR')
    tag = value[0]
    if tag == 'bot':
        _need(len(value) == 1, 'bottom arity', 'INVALID_DONOR')
    elif tag == 'pred':
        _need(len(value) == 3 and type(value[1]) is str and type(value[2]) is list,
              'predicate carrier', 'INVALID_DONOR')
        for term in value[2]:
            _term(term, work, depth+1)
    elif tag == 'eq':
        _need(len(value) == 3, 'equality arity', 'INVALID_DONOR')
        _term(value[1], work, depth+1)
        _term(value[2], work, depth+1)
    elif tag == 'all':
        _need(len(value) == 3 and type(value[1]) is str, 'universal carrier', 'INVALID_DONOR')
        _formula(value[2], work, depth+1)
    elif tag == 'not':
        _need(len(value) == 2, 'negation arity', 'INVALID_DONOR')
        _formula(value[1], work, depth+1)
    else:
        _need(tag in ('imp', 'and', 'or') and len(value) == 3, 'known binary formula', 'INVALID_DONOR')
        _formula(value[1], work, depth+1)
        _formula(value[2], work, depth+1)


def _term(value, work, depth):
    work.tick()
    _need(depth <= 128 and type(value) is list and value, 'finite literal term', 'INVALID_DONOR')
    if value[0] == 'var':
        _need(len(value) == 2 and type(value[1]) is str, 'variable carrier', 'INVALID_DONOR')
    else:
        _need(len(value) == 3 and value[0] == 'fun' and type(value[1]) is str and type(value[2]) is list,
              'function carrier', 'INVALID_DONOR')
        for child in value[2]:
            _term(child, work, depth+1)


def infer_request(request, *, check):
    """Independent literal donor extraction with the OLD formula-port quotient.

    Requires exact original named axiom formulas and local MP equations. It
    does not replace the full Host/Native theory validator. Different axiom
    names with equal whole formulas explicitly share the first-use port.
    """
    work = _Work(check)
    work.tick()
    _need(type(request) is dict and set(request) == {'protocol', 'theory', 'blocks', 'proof', 'target'},
          'exact control request fields', 'INVALID_DONOR')
    _need(request['protocol'] == 'gcts-fol-1' and request['blocks'] == [], 'no imported blocks', 'INVALID_DONOR')
    theory, proof = request['theory'], request['proof']
    _need(type(theory) is dict and type(theory.get('axioms')) is dict, 'literal axiom map', 'INVALID_DONOR')
    _need(type(proof) is list and 1 <= len(proof) <= 64, 'bounded literal proof', 'INVALID_DONOR')
    graph, ports, aliases, formulas = [], [], [], []
    mp_count = 0
    for row, command in enumerate(proof):
        work.tick()
        _need(type(command) is dict and 'formula' in command, 'literal command', 'INVALID_DONOR')
        formula = command['formula']
        _formula(formula, work)
        if command.get('rule') == 'axiom':
            _need(set(command) == {'rule', 'name', 'formula'} and type(command['name']) is str,
                  'exact axiom fields', 'INVALID_DONOR')
            _need(command['name'] in theory['axioms'] and formula == theory['axioms'][command['name']],
                  'exact licensed named axiom', 'INVALID_DONOR')
            found = None
            for index, old in enumerate(ports):
                work.tick()
                if old == formula:
                    found = index
                    break
            if found is None:
                found = len(ports)
                ports.append(copy.deepcopy(formula))
                aliases.append([])
            aliases[found].append(dict(row=row, name=command['name']))
            graph.append(dict(row=row, kind='port', port=found))
        else:
            _need(command.get('rule') == 'mp' and set(command) == {'rule', 'formula', 'antecedent', 'implication'},
                  'only exact axiom or MP controls', 'INVALID_DONOR')
            a, i = command['antecedent'], command['implication']
            _need(type(a) is int and type(i) is int and 0 <= a < row and 0 <= i < row,
                  'strict donor references', 'INVALID_DONOR')
            _need(formulas[i] == ['imp', formulas[a], formula], 'exact donor MP equation', 'INVALID_DONOR')
            graph.append(dict(row=row, kind='mp', antecedent=a, implication=i))
            mp_count += 1
        formulas.append(copy.deepcopy(formula))
    _formula(request['target'], work)
    _need(formulas[-1] == request['target'] and mp_count > 0, 'final target and at least one MP', 'INVALID_DONOR')
    typed = infer_graph(graph, len(ports), check=check)
    arguments = {}

    def join(pattern, concrete):
        work.tick()
        if pattern[0] == 'meta':
            index = pattern[1]
            if index in arguments:
                _need(arguments[index] == concrete, 'one shared concrete meta instance', 'INVALID_DONOR')
            else:
                arguments[index] = copy.deepcopy(concrete)
        else:
            _need(type(concrete) is list and len(concrete) == 3 and concrete[0] == 'imp',
                  'required implication constructor', 'INVALID_DONOR')
            join(pattern[1], concrete[1])
            join(pattern[2], concrete[2])

    for pattern, concrete in zip(typed['premises'], ports):
        join(pattern, concrete)
    for pattern, concrete in zip(typed['row_formulas'], formulas):
        join(pattern, concrete)
    _need(set(arguments) == set(range(typed['parameters'])), 'complete donor factorization', 'INVALID_DONOR')
    converted = []
    for node, formula in zip(graph, typed['row_formulas']):
        if node['kind'] == 'port':
            converted.append(dict(rule='assumption', index=node['port'], formula=formula))
        else:
            converted.append(dict(rule='mp', antecedent=node['antecedent'], implication=node['implication'], formula=formula))
    typed.update(template=dict(premises=typed['premises'], conclusion=typed['conclusion'], proof=converted),
                 concrete_arguments=[arguments[index] for index in range(typed['parameters'])], port_aliases=aliases)
    return typed


def _control_requests():
    """Hand-authored finite verifier controls, NEVER acquisition/search routes."""
    a, b, c = ['pred', 'A', []], ['pred', 'B', []], ['pred', 'C', []]
    requests = []
    for label, formulas, steps in (
        ('generic-MP', [a, ['imp', a, b]], [(0, 1, b)]),
        ('generic-serial', [a, ['imp', a, b], ['imp', b, c]], [(0, 1, b), (3, 2, c)]),
        ('generic-curried', [a, b, ['imp', a, ['imp', b, c]]], [(0, 2, ['imp', b, c]), (1, 3, c)]),
        ('shared-antecedent', [a, ['imp', a, ['imp', a, b]]], [(0, 1, ['imp', a, b]), (0, 2, b)]),
    ):
        proof, axioms = [], {}
        for index, formula in enumerate(formulas):
            name = 'control'+str(index)
            axioms[name] = copy.deepcopy(formula)
            proof.append(dict(rule='axiom', name=name, formula=copy.deepcopy(formula)))
        for antecedent, implication, formula in steps:
            proof.append(dict(rule='mp', antecedent=antecedent, implication=implication, formula=copy.deepcopy(formula)))
        requests.append((label, dict(protocol='gcts-fol-1', theory=dict(functions={}, predicates=dict(A=0, B=0, C=0), axioms=axioms, schemas=[]), blocks=[], proof=proof, target=copy.deepcopy(proof[-1]['formula']))))
    # Whole formulas are opaque meta instances; neither quantifier inference nor
    # equality inference is performed here. The implication axiom is explicit.
    x = ['var', 'x']
    q = ['all', 'x', ['pred', 'P', [x]]]
    e = ['eq', ['fun', 'f', [['fun', 'a', []]]], ['fun', 'a', []]]
    whole = dict(protocol='gcts-fol-1', theory=dict(functions={'a': 0, 'f': 1}, predicates={'P': 1}, axioms={'u': q, 'i': ['imp', q, e]}, schemas=[]), blocks=[], proof=[dict(rule='axiom', name='u', formula=q), dict(rule='axiom', name='i', formula=['imp', q, e]), dict(rule='mp', antecedent=0, implication=1, formula=e)], target=e)
    requests.append(('opaque-quantifier-equality', whole))
    alias = copy.deepcopy(requests[0][1])
    alias['theory']['axioms']['alias'] = copy.deepcopy(a)
    alias['proof'].insert(1, dict(rule='axiom', name='alias', formula=copy.deepcopy(a)))
    alias['proof'][-1]['antecedent'] = 1
    alias['proof'][-1]['implication'] = 2
    requests.append(('equal-formula-named-alias', alias))
    equal_atoms = copy.deepcopy(requests[0][1])
    equal_atoms['theory']['axioms']['control1'] = ['imp', copy.deepcopy(a), copy.deepcopy(a)]
    equal_atoms['proof'][1]['formula'] = copy.deepcopy(equal_atoms['theory']['axioms']['control1'])
    equal_atoms['proof'][2]['formula'] = copy.deepcopy(a)
    equal_atoms['target'] = copy.deepcopy(a)
    requests.append(('incidental-equal-atoms-erased', equal_atoms))
    return requests


def run_principal_reference_controls(module, *, check):
    """Future-actual only. Exercises public B graph/mine/verify APIs.

    Frozen Source must be independently reviewed before this routine runs.
    No reference quota/foreign callback fault is translated into ill typing.
    """
    controls = []
    graphs = [
        ('identity-port', [dict(row=0, kind='port', port=0)], 1),
        ('MP', [dict(row=0, kind='port', port=0), dict(row=1, kind='port', port=1), dict(row=2, kind='mp', antecedent=1, implication=0)], 2),
        ('serial', [dict(row=0, kind='port', port=0), dict(row=1, kind='port', port=1), dict(row=2, kind='port', port=2), dict(row=3, kind='mp', antecedent=0, implication=1), dict(row=4, kind='mp', antecedent=3, implication=2)], 3),
        ('curried', [dict(row=0, kind='port', port=0), dict(row=1, kind='port', port=1), dict(row=2, kind='port', port=2), dict(row=3, kind='mp', antecedent=0, implication=2), dict(row=4, kind='mp', antecedent=1, implication=3)], 3),
        ('shared-row', [dict(row=0, kind='port', port=0), dict(row=1, kind='port', port=1), dict(row=2, kind='mp', antecedent=0, implication=1), dict(row=3, kind='mp', antecedent=0, implication=2)], 2),
        ('repeated-port', [dict(row=0, kind='port', port=0), dict(row=1, kind='port', port=0), dict(row=2, kind='port', port=1), dict(row=3, kind='mp', antecedent=0, implication=2), dict(row=4, kind='mp', antecedent=1, implication=2)], 2),
        ('unused-retained-port', [dict(row=0, kind='port', port=0), dict(row=1, kind='port', port=1)], 2),
    ]
    a, b, c = ['meta', 0], ['meta', 1], ['meta', 2]
    literal_expected = {
        'identity-port': ([a], a, 1),
        'MP': ([['imp', a, b], a], b, 2),
        'serial': ([a, ['imp', a, b], ['imp', b, c]], c, 3),
        'curried': ([a, b, ['imp', a, ['imp', b, c]]], c, 3),
        'shared-row': ([a, ['imp', a, ['imp', a, b]]], b, 2),
        'repeated-port': ([a, ['imp', a, b]], b, 2),
        'unused-retained-port': ([a, b], b, 2),
    }
    for label, nodes, count in graphs:
        check()
        expected = infer_graph(nodes, count, check=check)
        _need((expected['premises'], expected['conclusion'], expected['parameters']) == literal_expected[label],
              'independent hand-derived principal interface', 'CONTROL_MISMATCH')
        actual = module.infer_graph(copy.deepcopy(nodes), count, check=check)
        for key in ('premises', 'row_formulas', 'conclusion', 'parameters'):
            _need(actual[key] == expected[key], 'production/reference graph '+key, 'CONTROL_MISMATCH')
        controls.append(dict(id='graph-'+label, status='PASSED', graph=nodes, port_count=count, expected=expected, actual=actual))
    base = graphs[1][1]
    bad = [
        ('direct-occurs', [dict(row=0, kind='port', port=0), dict(row=1, kind='mp', antecedent=0, implication=0)], 1),
        ('indirect-occurs', [dict(row=0, kind='port', port=0), dict(row=1, kind='port', port=1), dict(row=2, kind='mp', antecedent=1, implication=0), dict(row=3, kind='mp', antecedent=0, implication=2)], 2),
        ('same-port-occurs', [dict(row=0, kind='port', port=0), dict(row=1, kind='port', port=0), dict(row=2, kind='mp', antecedent=0, implication=1)], 1),
        ('self-cycle', [dict(row=0, kind='port', port=0), dict(row=1, kind='mp', antecedent=0, implication=1)], 1),
        ('forward-cycle', [dict(row=0, kind='port', port=0), dict(row=1, kind='mp', antecedent=2, implication=0), dict(row=2, kind='mp', antecedent=0, implication=1)], 1),
        ('bool-reference', [dict(row=0, kind='port', port=0), dict(row=1, kind='mp', antecedent=False, implication=0)], 1),
        ('float-reference', [dict(row=0, kind='port', port=0), dict(row=1, kind='mp', antecedent=0.0, implication=0)], 1),
        ('negative-reference', [dict(row=0, kind='port', port=0), dict(row=1, kind='mp', antecedent=-1, implication=0)], 1),
        ('bool-port', [dict(row=0, kind='port', port=False)], 1),
        ('bool-count', [dict(row=0, kind='port', port=0)], True),
        ('unused-declared-port', [dict(row=0, kind='port', port=0)], 2),
        ('extra-row-key', [dict(row=0, kind='port', port=0, hidden=True)], 1),
        ('wrong-row-identity', [dict(row=1, kind='port', port=0)], 1),
        ('foreign-rule', [dict(row=0, kind='port', port=0), dict(row=1, kind='cut', source=0)], 1),
    ]
    for label, nodes, count in bad:
        check()
        reference_error = None
        try:
            infer_graph(nodes, count, check=check)
        except ReferenceError as error:
            if not is_owned_error(error) or error.code == 'REFERENCE_QUOTA':
                raise
            reference_error = error
        _need(reference_error is not None, 'invalid graph accepted by reference', 'CONTROL_MISMATCH')
        production_error = None
        try:
            module.infer_graph(copy.deepcopy(nodes), count, check=check)
        except Exception as error:
            if not module.is_owned_error(error):
                raise
            production_error = error
        _need(production_error is not None, 'invalid graph accepted by production', 'CONTROL_MISMATCH')
        controls.append(dict(id='refuse-'+label, status='PASSED', graph=nodes, port_count=count, reference_code=reference_error.code, actual_error=type(production_error).__name__))
    requests = _control_requests()
    for label, request in requests:
        check()
        original = copy.deepcopy(request)
        expected = infer_request(request, check=check)
        family = module.mine(request, dict(kind='HAND_AUTHORED_CONTROL', id=label), check=check)
        _need(request == original, 'control request mutation', 'CONTROL_MISMATCH')
        _need(family['parameters'] == expected['parameters'] and family['template'] == expected['template'],
              'complete independent donor family correspondence', 'CONTROL_MISMATCH')
        receipt = module.verify(request, family, check=check)
        _need(receipt['complete'], 'production certificate verification', 'CONTROL_MISMATCH')
        controls.append(dict(id='donor-control-'+label, status='PASSED', request=original,
                             expected=expected, family=family, verification=receipt))
    source_request = copy.deepcopy(requests[0][1])
    invalid_requests = []
    for label in ('bool-reference', 'float-reference', 'negative-reference', 'self-reference',
                  'unknown-axiom', 'wrong-axiom-formula', 'wrong-MP-formula', 'wrong-target',
                  'imported-block', 'open-assumption', 'extra-command-key', 'schema-enabled'):
        request = copy.deepcopy(source_request)
        if label == 'bool-reference':
            request['proof'][-1]['antecedent'] = False
        elif label == 'float-reference':
            request['proof'][-1]['antecedent'] = 0.0
        elif label == 'negative-reference':
            request['proof'][-1]['antecedent'] = -1
        elif label == 'self-reference':
            request['proof'][-1]['implication'] = 2
        elif label == 'unknown-axiom':
            request['proof'][0]['name'] = 'not-licensed'
        elif label == 'wrong-axiom-formula':
            request['proof'][0]['formula'] = ['bot']
        elif label == 'wrong-MP-formula':
            request['proof'][-1]['formula'] = ['bot']
        elif label == 'wrong-target':
            request['target'] = ['bot']
        elif label == 'imported-block':
            request['blocks'] = [dict(name='untrusted')]
        elif label == 'open-assumption':
            request['proof'][0] = dict(rule='assumption', index=0, formula=copy.deepcopy(source_request['proof'][0]['formula']))
        elif label == 'extra-command-key':
            request['proof'][0]['hidden'] = True
        else:
            request['theory']['schemas'] = ['unreviewed']
        invalid_requests.append((label, request))
    for label, request in invalid_requests:
        check()
        caught = None
        try:
            module.mine(request, dict(kind='HAND_AUTHORED_NEGATIVE_CONTROL', id=label), check=check)
        except Exception as error:
            if not module.is_owned_error(error):
                raise
            caught = error
        _need(caught is not None, 'malformed donor accepted', 'CONTROL_MISMATCH')
        controls.append(dict(id='donor-refuse-'+label, status='PASSED', request=request,
                             actual_error=type(caught).__name__))
    valid = module.mine(copy.deepcopy(source_request), dict(kind='HAND_AUTHORED_TAMPER_BASE'), check=check)
    for label in ('missing-trace', 'empty-trace', 'extra-trace-step', 'wrong-trace-rule',
                  'wrong-constraint', 'wrong-solved-row', 'wrong-donor-argument',
                  'wrong-provenance', 'wrong-structural-id', 'wrong-template-conclusion'):
        check()
        changed = copy.deepcopy(valid)
        typing = changed['certificate']['typing']
        if label == 'missing-trace':
            del typing['unification_trace']
        elif label == 'empty-trace':
            typing['unification_trace'] = []
        elif label == 'extra-trace-step':
            typing['unification_trace'].append(copy.deepcopy(typing['unification_trace'][-1]))
        elif label == 'wrong-trace-rule':
            typing['unification_trace'][0]['rule'] = 'invented'
        elif label == 'wrong-constraint':
            typing['constraints'][0]['left'] = ['meta', 999]
        elif label == 'wrong-solved-row':
            typing['row_formulas'][0] = ['meta', 999]
        elif label == 'wrong-donor-argument':
            changed['certificate']['donor_arguments'][0] = ['bot']
        elif label == 'wrong-provenance':
            changed['provenance'] = dict(kind='unjoined')
        elif label == 'wrong-structural-id':
            changed['structural_id'] = 'not-the-identity'
        else:
            changed['template']['conclusion'] = ['meta', 999]
        caught = None
        try:
            module.verify(copy.deepcopy(source_request), changed, check=check)
        except Exception as error:
            if not module.is_owned_error(error):
                raise
            caught = error
        _need(caught is not None, 'tampered certificate accepted', 'CONTROL_MISMATCH')
        controls.append(dict(id='certificate-refuse-'+label, status='PASSED',
                             tampered_family=changed, actual_error=type(caught).__name__))
    # A callback impostor of the public production class has no private owner.
    for label, sentinel in (('ValueError', ValueError('foreign-control')),
                            ('StopIteration', StopIteration('foreign-control')),
                            ('public-Invalid-impostor', module.Invalid('foreign-control'))):
        def callback():
            check()
            raise sentinel
        caught = None
        try:
            module.infer_graph(copy.deepcopy(base), 2, check=callback)
        except Exception as error:
            caught = error
        _need(caught is sentinel, 'exact foreign callback identity', 'CONTROL_MISMATCH')
        controls.append(dict(id='foreign-'+label, status='PASSED', exact_identity_preserved=True))
    check()
    return dict(schema=VERSION, complete=True, controls=controls, count=len(controls),
                source_scope='Hand-authored graph/donor controls only; no discovered proof or training route.',
                reference_scope='Eager finite substitution, strict graph and literal MP donor validation; not a full FOL kernel or a proof of all instances.')
