"""D17 statement-only corpus format controls; future Root-actual calls only.

No proof, route, family, weight, evaluation formula, file access or scientific
import is supplied here.  Synthetic format controls are not theorem inputs.
"""
import copy

ACQUISITION_SCHEMA = 'gcts-principal-family-search-acquisition-inputs-v1'
EVALUATION_SCHEMA = 'gcts-principal-family-search-evaluation-inputs-v1'
ACQUISITION_ID = 'D17-fresh-paired-family-acquisition-v1'
EVALUATION_ID = 'D17-public-authored-recipient-search-evaluation-v1'
DONOR_IDS = ('donor-constructor-chain', 'donor-generic-application')
CASE_IDS = ('eval-sharing-01', 'eval-sharing-02', 'eval-quantified-01',
            'eval-quantified-02', 'eval-equality-01', 'eval-equality-02',
            'context-atomic-serial', 'context-opaque-equality')
ROW_BOUNDS = {'donor-constructor-chain': 5, 'donor-generic-application': 3,
              'eval-sharing-01': 12, 'eval-sharing-02': 15,
              'eval-quantified-01': 11, 'eval-quantified-02': 11,
              'eval-equality-01': 9, 'eval-equality-02': 11,
              'context-atomic-serial': 5, 'context-opaque-equality': 5}
METHODS = ('S0', 'P0', 'PA', 'PP')
ACQUISITION_PROTOCOL = {
    'abstraction_modes': ['atom', 'principal'],
    'pairing_policy': 'UNCHANGED_ATOM_TEMPLATE_CLASSES_NO_PRINCIPAL_COALESCENCE_V1',
    'premise_port_policy': 'EXACT_DONOR_FORMULA_FIRST_USE_QUOTIENT_V1',
    'fresh_acquisition': True,
    'policy_training': False,
    'authority': 'Fresh searched donors and exact Host/full-region/Native checked fragments only; no old actual export or supplied proof adoption.',
}
ARM_ORDER = {
    'eval-sharing-01': {'0': ['S0', 'P0', 'PA', 'PP'], '1': ['PP', 'PA', 'P0', 'S0']},
    'eval-sharing-02': {'0': ['P0', 'PA', 'PP', 'S0'], '1': ['S0', 'PP', 'PA', 'P0']},
    'eval-quantified-01': {'0': ['PA', 'PP', 'S0', 'P0'], '1': ['P0', 'S0', 'PP', 'PA']},
    'eval-quantified-02': {'0': ['PP', 'S0', 'P0', 'PA'], '1': ['PA', 'P0', 'S0', 'PP']},
    'eval-equality-01': {'0': ['S0', 'P0', 'PA', 'PP'], '1': ['PP', 'PA', 'P0', 'S0']},
    'eval-equality-02': {'0': ['P0', 'PA', 'PP', 'S0'], '1': ['S0', 'PP', 'PA', 'P0']},
    'context-atomic-serial': {'0': ['PA', 'PP', 'S0', 'P0'], '1': ['P0', 'S0', 'PP', 'PA']},
    'context-opaque-equality': {'0': ['PP', 'S0', 'P0', 'PA'], '1': ['PA', 'P0', 'S0', 'PP']},
}
EVALUATION_PROTOCOL = {
    'evaluation_seeds': [0, 1],
    'methods': ['S0', 'P0', 'PA', 'PP'],
    'arm_order': ARM_ORDER,
    'seed_scope': 'Fixed deterministic selectors; seeds label counterbalanced method order, not independent stochastic replications.',
    'intake': 'Only after independent whole admission and seal of the complete fresh D17 acquisition; no old D15/D16 actual export or partial adoption.',
    'split_label': 'Public authored development and compositional/operator transfer, not blind and not family-held-out.',
    'policy_training': False,
}
CONTROL_IDS = (
    'acquisition-format', 'synthetic-evaluation-format', 'unexpected-proof-field',
    'bool-row-bound', 'free-axiom-variable', 'unknown-function', 'function-arity',
    'unknown-predicate', 'predicate-arity', 'unknown-formula-tag',
    'negative-signature-arity', 'bool-signature-arity', 'nonempty-schemas',
    'duplicate-donor-id', 'missing-donor', 'acquisition-policy-mutation',
    'missing-evaluation-case', 'evaluation-bound-mutation',
    'evaluation-arm-order-mutation', 'evaluation-bool-seed',
    'foreign-RuntimeError', 'foreign-ValueError', 'foreign-StopIteration',
    'foreign-CorpusFormatError',
)
_OWNER = object()


class CorpusFormatError(ValueError):
    def __init__(self, message, owner=None):
        super().__init__(message)
        self.owner = owner


def is_owned_error(error):
    return type(error) is CorpusFormatError and error.owner is _OWNER


def need(value, message):
    if not value:
        raise CorpusFormatError(message, _OWNER)


def _same(left, right, check):
    check()
    if type(left) is not type(right):
        return False
    if type(left) is list:
        if len(left) != len(right):
            return False
        for a, b in zip(left, right):
            if not _same(a, b, check):
                return False
        return True
    if type(left) is dict:
        if set(left) != set(right):
            return False
        for key in left:
            if not _same(left[key], right[key], check):
                return False
        return True
    return left == right


def _name(value, check):
    check()
    need(type(value) is str and 0 < len(value) <= 128, 'bounded literal name')


def _signature(value, check):
    check(); need(type(value) is dict, 'literal signature map')
    for name, arity in value.items():
        _name(name, check)
        need(type(arity) is int and 0 <= arity <= 2, 'exact finite arity')


def _term(value, theory, bound, check, depth=0):
    check(); need(depth <= 64 and type(value) is list and value, 'finite literal term')
    if value[0] == 'var':
        need(len(value) == 2 and type(value[1]) is str and value[1] in bound,
             'no free variable in licensed closed axiom/target')
        return
    need(len(value) == 3 and value[0] == 'fun' and type(value[1]) is str
         and value[1] in theory['functions'] and type(value[2]) is list,
         'declared function term')
    need(len(value[2]) == theory['functions'][value[1]], 'function arity')
    for item in value[2]:
        _term(item, theory, bound, check, depth+1)


def _formula(value, theory, bound, check, depth=0):
    check(); need(depth <= 64 and type(value) is list and value
                  and type(value[0]) is str, 'finite literal formula')
    tag = value[0]
    if tag == 'bot':
        need(len(value) == 1, 'bottom arity')
    elif tag == 'pred':
        need(len(value) == 3 and type(value[1]) is str and value[1] in theory['predicates']
             and type(value[2]) is list, 'declared predicate')
        need(len(value[2]) == theory['predicates'][value[1]], 'predicate arity')
        for item in value[2]:
            _term(item, theory, bound, check, depth+1)
    elif tag == 'eq':
        need(len(value) == 3, 'equality arity')
        _term(value[1], theory, bound, check, depth+1)
        _term(value[2], theory, bound, check, depth+1)
    elif tag == 'all':
        need(len(value) == 3, 'universal arity'); _name(value[1], check)
        _formula(value[2], theory, bound | {value[1]}, check, depth+1)
    elif tag == 'not':
        need(len(value) == 2, 'negation arity')
        _formula(value[1], theory, bound, check, depth+1)
    else:
        need(tag in ('imp', 'and', 'or') and len(value) == 3, 'known binary formula')
        _formula(value[1], theory, bound, check, depth+1)
        _formula(value[2], theory, bound, check, depth+1)


def _spec(spec, check):
    check(); need(type(spec) is dict and set(spec) ==
                  {'id', 'title', 'theory', 'target', 'length', 'instantiation_rounds', 'scope'},
                  'exact statement-only spec; no proof/route/library/weights')
    _name(spec['id'], check)
    need(spec['id'] in ROW_BOUNDS and type(spec['title']) is str and type(spec['scope']) is str,
         'declared statement identity and literal prose')
    need(type(spec['length']) is int and spec['length'] == ROW_BOUNDS[spec['id']],
         'unchanged expanded primitive row bound')
    need(type(spec['instantiation_rounds']) is int and spec['instantiation_rounds'] == 2,
         'unchanged compiler rounds')
    theory = spec['theory']
    need(type(theory) is dict and set(theory) == {'functions', 'predicates', 'axioms', 'schemas'},
         'exact signature/theory license')
    _signature(theory['functions'], check); _signature(theory['predicates'], check)
    need(type(theory['schemas']) is list and not theory['schemas'], 'no added schema license')
    need(type(theory['axioms']) is dict and 1 <= len(theory['axioms']) <= 6,
         'finite explicitly licensed named axioms')
    for name, formula in theory['axioms'].items():
        _name(name, check); _formula(formula, theory, set(), check)
    _formula(spec['target'], theory, set(), check)


def _document(document, schema, identity, field, ids, protocol, check):
    check(); need(type(document) is dict and set(document) == {'schema', 'id', field, 'protocol'},
                  'exact physical phase document')
    need(document['schema'] == schema and document['id'] == identity, 'fixed phase schema/identity')
    population = document[field]
    need(type(population) is list and len(population) == len(ids), 'complete fixed population')
    actual_ids = []
    for spec in population:
        _spec(spec, check); actual_ids.append(spec['id'])
    need(tuple(actual_ids) == ids, 'complete ordered statement identities')
    need(_same(document['protocol'], protocol, check), 'exact typed phase policy and arm orders')
    check()
    return dict(schema='D17-principal-search-format-receipt-v1', complete=True,
                phase=field, statement_ids=actual_ids,
                scope='Format/signature/closedness/protocol only; raw plan pins freeze actual formulas. Not a proof kernel or search result.')


def validate_acquisition(document, *, check):
    return _document(document, ACQUISITION_SCHEMA, ACQUISITION_ID, 'donors', DONOR_IDS,
                     ACQUISITION_PROTOCOL, check)


def validate_evaluation(document, *, check):
    return _document(document, EVALUATION_SCHEMA, EVALUATION_ID, 'evaluation', CASE_IDS,
                     EVALUATION_PROTOCOL, check)


def run_contract_controls(acquisition_document, *, check):
    check(); validate_acquisition(acquisition_document, check=check)
    results = [dict(id='acquisition-format', status='PASSED')]
    # Shape-only synthetic carrier built from acquisition syntax, never a real
    # evaluation formula or an accepted theorem input. No file access occurs.
    synthetic = dict(schema=EVALUATION_SCHEMA, id=EVALUATION_ID, evaluation=[],
                     protocol=copy.deepcopy(EVALUATION_PROTOCOL))
    for ident in CASE_IDS:
        check(); spec = copy.deepcopy(acquisition_document['donors'][0])
        spec.update(id=ident, length=ROW_BOUNDS[ident],
                    scope='SYNTHETIC_FORMAT_CONTROL_ONLY; never a scientific target.')
        synthetic['evaluation'].append(spec)
    validate_evaluation(synthetic, check=check)
    results.append(dict(id='synthetic-evaluation-format', status='PASSED',
                        scope='Synthetic shape carrier only; no evaluation formula read.'))
    for recipe in CONTROL_IDS[2:20]:
        check(); evaluation_case = recipe.startswith('evaluation-') or recipe == 'missing-evaluation-case'
        altered = copy.deepcopy(synthetic if evaluation_case else acquisition_document)
        field = 'evaluation' if evaluation_case else 'donors'
        spec = altered[field][0]
        if recipe == 'unexpected-proof-field': spec['proof'] = []
        elif recipe == 'bool-row-bound': spec['length'] = True
        elif recipe == 'free-axiom-variable': spec['theory']['axioms']['a0'] = ['eq', ['var', 'x'], ['var', 'x']]
        elif recipe == 'unknown-function': spec['target'] = ['eq', ['fun', 'UNLICENSED', []], ['fun', 'UNLICENSED', []]]
        elif recipe == 'function-arity':
            spec['theory']['functions']['f'] = 1
            spec['target'] = ['eq', ['fun', 'f', []], ['fun', 'f', []]]
        elif recipe == 'unknown-predicate': spec['target'] = ['pred', 'UNLICENSED', []]
        elif recipe == 'predicate-arity': spec['theory']['predicates']['X'] = 1
        elif recipe == 'unknown-formula-tag': spec['target'] = ['invented', ['bot'], ['bot']]
        elif recipe == 'negative-signature-arity': spec['theory']['functions']['f'] = -1
        elif recipe == 'bool-signature-arity': spec['theory']['functions']['f'] = False
        elif recipe == 'nonempty-schemas': spec['theory']['schemas'] = ['unlicensed']
        elif recipe == 'duplicate-donor-id': altered['donors'][1]['id'] = altered['donors'][0]['id']
        elif recipe == 'missing-donor': altered['donors'].pop()
        elif recipe == 'acquisition-policy-mutation': altered['protocol']['pairing_policy'] = 'COALESCE_PRINCIPAL_STRUCTURES'
        elif recipe == 'missing-evaluation-case': altered['evaluation'].pop()
        elif recipe == 'evaluation-bound-mutation': spec['length'] += 1
        elif recipe == 'evaluation-arm-order-mutation': altered['protocol']['arm_order'][CASE_IDS[0]]['0'].reverse()
        else: altered['protocol']['evaluation_seeds'][0] = False
        caught = None
        try:
            if evaluation_case: validate_evaluation(altered, check=check)
            else: validate_acquisition(altered, check=check)
        except CorpusFormatError as error:
            check()
            if not is_owned_error(error):
                raise
            caught = error
        need(caught is not None, 'owned malformed-format refusal '+recipe)
        results.append(dict(id=recipe, status='PASSED', refused=True))
    for label, sentinel in (('foreign-RuntimeError', RuntimeError('external')),
                            ('foreign-ValueError', ValueError('external')),
                            ('foreign-StopIteration', StopIteration('external')),
                            ('foreign-CorpusFormatError', CorpusFormatError('external'))):
        check()
        def interrupt():
            check(); raise sentinel
        caught = None
        try:
            validate_acquisition(acquisition_document, check=interrupt)
        except BaseException as error:
            caught = error
        check(); need(caught is sentinel, 'exact foreign callback identity')
        results.append(dict(id=label, status='PASSED', exact_identity_preserved=True))
    ids = []
    for result in results:
        check(); ids.append(result['id'])
    need(tuple(ids) == CONTROL_IDS, 'complete fixed format-control population')
    check()
    return dict(schema='D17-principal-search-corpus-controls-v1', complete=True,
                count=24, controls=results,
                scope='Finite format/callback controls only; synthetic evaluation carrier contains no actual evaluation formulas. Calls belong only inside a reviewed Root actual.')
