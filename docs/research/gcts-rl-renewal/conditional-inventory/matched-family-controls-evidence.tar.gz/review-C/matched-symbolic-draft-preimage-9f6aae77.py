"""Independent tiny SP controls; hand-authored diagnostics, not search donors.

The guarded sentinel exposes only the declared symbolic read interface. Actual
pool/search functions are called only when Root runs a fully reviewed actual.
"""
import copy

VERSION='D18-independent-matched-symbolic-controls-v1'


def _need(value,message):
    if not value:
        raise ValueError('independent matched-symbolic control: '+message)


class _Model:
    __slots__=('spec','compiled','domains')
    def __init__(self,spec,compiled,domains):
        self.spec=spec;self.compiled=compiled;self.domains=domains
    def __getattr__(self,name):
        raise AssertionError('point or undeclared model access in symbolic control: '+name)


def _fixture():
    p=['pred','P',[]];q=['pred','Q',[]];imp=['imp',p,q]
    axp=dict(rule='axiom',name='p',formula=p)
    axpq=dict(rule='axiom',name='pq',formula=imp)
    mp=dict(rule='mp',antecedent=0,implication=1,formula=q)
    badmp=dict(rule='mp',antecedent=1,implication=0,formula=q)
    spec=dict(id='CONTROL_ONLY_NOT_DONOR',title='Synthetic matched symbolic interface control',
        length=3,instantiation_rounds=2,target=q,
        theory=dict(functions={},predicates={'P':0,'Q':0},axioms={'p':p,'pq':imp},schemas=[]))
    compiled=dict(status='complete',basis=[p,q,imp],variables=[],tautologies=[],admitted_schemes=[])
    domains=[[copy.deepcopy(axp),copy.deepcopy(axpq)],
             [copy.deepcopy(axp),copy.deepcopy(axpq)],
             [copy.deepcopy(mp),copy.deepcopy(badmp)]]
    m0=['meta',0];m1=['meta',1]
    family=dict(id='CONTROL_GENERIC_MP_NOT_ACQUIRED',parameters=2,dependencies=[],
        template=dict(premises=[m0,['imp',m0,m1]],conclusion=m1,
            proof=[dict(rule='assumption',index=0,formula=m0),
                   dict(rule='assumption',index=1,formula=['imp',m0,m1]),
                   dict(rule='mp',antecedent=0,implication=1,formula=m1)]))
    return _Model(spec,compiled,domains),family,[axp,axpq,mp]


def run_symbolic_controls(pilot_module,modules,*,check):
    check()
    controls=[]
    limits=dict(pilot_module.LIMITS)
    _need(limits['search_attempts']==600 and limits['search_seconds']==2.0,
          'controls do not silently change actual scientific quotas')
    def call(model,prefix,library):
        check()
        before=copy.deepcopy((model.spec,model.compiled,model.domains,prefix,library))
        work={'completed':0}
        answer=pilot_module.symbolic_ready_pool(model,prefix,library,modules,check,limits,work)
        check()
        _need(before==(model.spec,model.compiled,model.domains,prefix,library),'read-only symbolic input')
        _need(answer['complete'] is True,'complete bounded prefix before preference')
        _need(answer['scheduler_context']=='CHRONOLOGICAL_SYMBOLIC_PREFIX_NO_POINT_LEGALITY',
              'symbolic scope is explicit')
        _need(answer['validation_checks']<=limits['cluster_binding_work'],'declared work prefix')
        _need(len(answer['packets'])<=limits['cluster_proposals'],'declared proposal prefix')
        return answer
    model,family,proof=_fixture()
    for identity,prefix,expected_commands in [
            ('named-axioms-no-point-interface',[],proof),
            ('actual-first-prefix-occurrence',[proof[0]],proof[1:]),
            ('both-actual-prefix-occurrences',proof[:2],proof[2:])]:
        pool=call(model,copy.deepcopy(prefix),[copy.deepcopy(family)])
        matched=[p for p in pool['packets'] if p['commands']==expected_commands]
        _need(matched,identity+' literal ordinary expansion retained')
        for packet in matched:
            _need(packet['checked_primitive_proof']==prefix+expected_commands,'exact primitive prefix append')
            _need(packet['host_check']['accepted'] is True,'genuine Host context check')
            _need(packet['prefix_rows']==len(prefix),'actual prefix count')
            last=packet['members'][-1]
            _need(last==[2,1,0,2],'MP guard variant belongs to implication basis index2, not result index1')
            _need('newly_satisfied_roots' not in packet,'no point progress fact in symbolic packet')
        controls.append(dict(id=identity,status='PASSED',pool=pool))
    pool=call(model,copy.deepcopy(proof),[copy.deepcopy(family)])
    _need(pool['packets']==[],'saturated conclusion abstains, not repeated macro')
    controls.append(dict(id='saturated-prefix-no-packet',status='PASSED',pool=pool))
    missing,_,_=_fixture();del missing.spec['theory']['axioms']['p']
    pool=call(missing,[],[copy.deepcopy(family)])
    _need(pool['packets']==[],'missing first receptor is not fabricated')
    controls.append(dict(id='missing-receptor-no-packet',status='PASSED',pool=pool))
    twin=copy.deepcopy(family);twin['id']='CONTROL_DUPLICATE_TEMPLATE_DISTINCT_UNIT'
    pool=call(model,[],[copy.deepcopy(family),twin])
    _need({p['family'] for p in pool['packets']}=={family['id'],twin['id']},
          'distinct paired units survive equal templates')
    controls.append(dict(id='equal-template-distinct-family-units',status='PASSED',pool=pool))
    alias,_,_=_fixture();alias.spec['theory']['axioms']['p_alias']=copy.deepcopy(proof[0]['formula'])
    for row in alias.domains[:2]:row.append(dict(rule='axiom',name='p_alias',formula=copy.deepcopy(proof[0]['formula'])))
    pool=call(alias,[],[copy.deepcopy(family)])
    names={source['name'] for p in pool['packets'] for source in p['source_binding'] if source['kind']=='axiom'}
    _need({'p','p_alias'}<=names,'distinct named same-formula source occurrences retained')
    controls.append(dict(id='equal-formula-named-occurrences',status='PASSED',pool=pool))
    absent_guard,_,_=_fixture();absent_guard.compiled['basis']=copy.deepcopy(absent_guard.compiled['basis'][:2])
    pool=call(absent_guard,[],[copy.deepcopy(family)])
    _need(pool['packets']==[],'absent original implication guard blocks proposal only')
    controls.append(dict(id='missing-original-guard-no-packet',status='PASSED',pool=pool))
    # The second call has a library with no available receptor. Both must retain
    # the same full ordinary fallback; neither may require point Model methods.
    unavailable=copy.deepcopy(family)
    unavailable['template']['premises']=[['pred','Z',[]]]
    unavailable['parameters']=0
    for identity,library in [('empty-library-primitive-fallback',[]),
                             ('no-applicable-library-primitive-fallback',[unavailable])]:
        search=pilot_module.search_symbolic_principal(model,library,modules,check,limits)
        check()
        _need(search['status']=='symbolic_proof_candidate' and search['proof'] is not None,
              'ordinary finite control remains searchable')
        _need(search['proof'][-1]['formula']==model.spec['target'],'literal target reached in tiny control')
        _need(search['root_restored'] is True,'search reports exact original restoration')
        for event in search['trace']:
            if event['event']=='decision':
                _need(sorted(event['ordered_candidates'])==sorted(event['original_candidates']),
                      'complete multiplicity-preserving ordinary fallback')
        controls.append(dict(id=identity,status='PASSED',search=search))
    for exception_type in (RuntimeError,ValueError,StopIteration):
        sentinel=exception_type('independent foreign callback sentinel')
        def explode():
            raise sentinel
        try:
            pilot_module.symbolic_ready_pool(model,[],[copy.deepcopy(family)],modules,explode,limits,{'completed':0})
        except BaseException as caught:
            _need(caught is sentinel,'foreign callback exact identity')
        else:
            raise ValueError('foreign callback was swallowed')
        check()
        controls.append(dict(id='foreign-'+exception_type.__name__,status='PASSED',exact_identity_propagated=True))
    check()
    return dict(schema=VERSION,complete=True,controls=controls,count=len(controls),
        scope='Thirteen hand-authored synthetic symbolic interface/fallback/fault controls only. '
              'No acquired donor, evaluation route, target proof admission, universal completeness '
              'or speed/fit claim. The sentinel forbids point APIs; real final proofs still require '
              'fresh whole-region/Host/Native gates inside their own actual.')
