"""Hand-authored Native diagnostics, never donors, acquired lemmas or proof routes.

No import or function execution is authorized by this Source file itself. Root
may call run_native_batch_controls only inside an exact reviewed fresh actual.
All requests count against the genuine invocation-wide Native/work/output caps.
"""
import copy

VERSION = 'D18-independent-zero-read-Native-controls-v1'


def _need(value, message):
    if not value:
        raise ValueError('independent Native batch control: '+message)


def run_native_batch_controls(oracle, *, check, limit=1000000000):
    check()
    _need(type(limit) is int and limit == 1000000000, 'unchanged exact per-query ceiling')
    p=['pred','P',[]]
    a=['fun','a',[]];b=['fun','b',[]];x=['var','x'];z=['var','z']
    rx=['pred','R',[x]];ra=['pred','R',[a]];rb=['pred','R',[b]]
    universal=['all','x',rx]
    taut=dict(rule='tautology',formula=['imp',p,p])
    ui=dict(rule='instantiate',universal=universal,term=a,formula=['imp',universal,ra])
    eq=dict(rule='eq_subst',variable='z',template=['pred','R',[z]],left=a,right=b,
            formula=['imp',['eq',a,b],['imp',ra,rb]])
    false_taut=dict(rule='tautology',formula=p)
    false_ui=dict(rule='instantiate',universal=universal,term=a,formula=ra)
    # An MP command reads prior rows; it is outside the batching whitelist even
    # though ordinary recipient proofs may legitimately contain MP.
    self_read=dict(rule='mp',antecedent=0,implication=0,formula=p)
    theory=dict(functions={'a':0,'b':0},predicates={'P':0,'R':1},axioms={},schemas=[])
    fixtures=[
        ('valid-tautology-UI-EQ-licences',[taut,ui,eq],eq['formula'],'accepted'),
        ('invalid-first-valid-last-target',[false_taut,taut],taut['formula'],'rejected'),
        ('invalid-middle-valid-last-target',[taut,false_ui,eq],eq['formula'],'rejected'),
        ('duplicate-valid-licences',[ui,ui,eq,eq],eq['formula'],'accepted'),
        ('empty-proof-is-not-batch-authority',[],taut['formula'],'rejected'),
        ('self-reading-MP-is-not-zero-read',[self_read,taut],taut['formula'],'rejected'),
    ]
    rows=[]
    for identity,proof,target,expected in fixtures:
        check()
        request=dict(protocol='gcts-fol-1',theory=copy.deepcopy(theory),blocks=[],
                     proof=copy.deepcopy(proof),target=copy.deepcopy(target))
        frozen=copy.deepcopy(request)
        record=oracle.request(request,limit,'D18_independent_control_'+identity)
        check()
        _need(request==frozen and record['request']==frozen, 'literal request preserved')
        qid=record['id']
        _need(type(qid) is int and qid >= 0 and oracle.records[qid] is record,
              'current actual Native record owner, not a supplied acceptance flag')
        _need(record['result']['status']==expected,
              identity+' returned '+str(record['result']['status'])+', expected '+expected)
        rows.append(dict(id=identity,status='PASSED',expected_native_status=expected,
                         native_record=copy.deepcopy(record)))
    check()
    return dict(schema=VERSION,complete=True,controls=rows,count=len(rows),
        scope='Six hand-authored diagnostic requests inside the fresh acquisition actual only. '
              'Not acquired donor proofs, recipient search, a general Native correctness proof or fit guarantee. '
              'UNKNOWN fails this finite qualification; it never rejects a batch member. '
              'All Native starts and elapsed/output/resource costs remain charged to the actual.')
