"""C's stdlib-only saved-value inspection; imports no experiment Source.

Not a proof checker, model constructor, search, replay, or offered passive helper.
"""
import pathlib, json, hashlib, collections
BASE=pathlib.Path(__file__).resolve().parents[3]
D=BASE/'research-runs/gcts-matched-family-controls-20261021'; R=D/'root'; C=D/'review-C'
inputs={}; errors=[]; counts=collections.Counter(); nc=collections.Counter(); cases=[]; joins=[]
def ck(b,m):
    if not b: errors.append(m)
def digest(x):
    return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()
def pin(p):
    p=pathlib.Path(p).resolve(); raw=p.read_bytes()
    v=dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()); inputs[str(p)]=v; return v
def verify(v):
    ck(pin(v['path'])=={k:v[k] for k in ('path','bytes','sha256')},'changed pin '+v['path'])
def read(p):
    p=pathlib.Path(p); ck('.partial' not in p.name,'partial attempted'); pin(p); return json.loads(p.read_bytes())
def recpins(x):
    if isinstance(x,dict):
        if {'path','bytes','sha256'}<=x.keys(): verify(x)
        else:
            for v in x.values(): recpins(v)
    elif isinstance(x,list):
        for v in x: recpins(v)
def permutation(a,b):
    return collections.Counter(map(digest,a))==collections.Counter(map(digest,b))
prepath=C/'typed-matched-family-exact16-evaluation-plan-review-v1.json'; pre=read(prepath)
ck(pre['review_passed'] is True,'preflight'); recpins(pre['inputs'])
index=read(R/'materialized-evaluation-plans-v1.json'); G=read(R/'evaluation16-grants-v1.json')
bar=read(R/'serial-barrier-evaluation16-v1.json'); TT=read(R/'evaluation16-tool-terminal-transcription-v1.json')
recpins(G); recpins(bar); tr={v['stage_id']:v for v in TT['rows']}
gr={read(v['path'])['plan_sha256']:v for v in G['grants']}
ck(len(index['plans'])==len(G['grants'])==len(TT['rows'])==16,'population')
ck(bar['execution_order']==[read(x['path'])['case_id'] for x in index['plans']],'serial order')
ei=read(D/'diagnostics-L/evaluation-inputs-v1.json'); specs={v['id']:v for v in ei['evaluation']}
orders=ei['protocol']['arm_order']; methods=ei['protocol']['methods']
acq=read(D/'actual/acquire-0/result.json')['scientific_result']; aq={q['id']:q for q in acq['native_records']}
seal=read(R/'seals/acquire-0-v1.json'); admission=read(R/'admission/acquire-0-v1.json')
acqreview=read(C/'typed-matched-family-acquisition-actual-scientific-review-v1.json'); recpins(seal); recpins(admission)
ck(acqreview['review_passed'] and admission['admitted'],'acquisition admitted')
libs=digest(acq['libraries']); totals={a:collections.Counter() for a in methods}; modelplacements=0
firstplan=read(index['plans'][0]['path'])
for pp in index['plans']:
    verify(pp); p=read(pp['path']); sid=p['case_id']; tag=sid+': '
    cid=sid[5:].rsplit('-seed',1)[0]; seed=int(sid.rsplit('-seed',1)[1]); order=orders[cid][str(seed)]; spec=specs[cid]
    for v in p['files']: verify(v)
    ck(len(p['files'])==len({v['path'] for v in p['files']})==141,tag+'141 sources')
    ck(p['limits']==firstplan['limits'] and p['experiment_limits']==firstplan['experiment_limits'],tag+'caps')
    A=pathlib.Path(p['actual_dir']); O=A.with_name(sid+'.observer'); ok=(A/'result.json').is_file()
    f=A/('result.json' if ok else 'failure.json'); w=read(f); h=read(A/'worker-header.json'); t=read(A/'terminal.json')
    o=read(O/'observer.json'); co=read(A/'CONSUMED.json'); owner=read(A/'owned-child.json'); gp=gr[pp['sha256']]; grant=read(gp['path'])
    census=[]
    for root in (A,O):
        for path in sorted(root.rglob('*')):
            if path.is_file():
                census.append(pin(path)); ck('.partial' not in path.name,tag+'partial exists')
    physical=sum(v['bytes'] for v in census)
    ck(physical<p['limits']['physical_bytes'],tag+'physical'); ck(h['result']==pin(f),tag+'header body')
    ck(t['header']==h and o['owned_child']==owner,tag+'header owner joins')
    ck(co['uses']==grant['uses']==1 and co['grant_sha256']==gp['sha256'] and co['plan_sha256']==pp['sha256'] and grant['authorized'],tag+'once grant')
    ck(grant['C_review']==pin(prepath) and owner['plan_sha256']==pp['sha256'] and owner['child_pid']==owner['child_pgid'],tag+'plan authority')
    ck(w['case_id']==h['case_id']==t['case_id']==o['case_id']==co['case_id']==sid,tag+'case identities')
    ck(w['source_unchanged'] and h['source_unchanged'] and t['sources_unchanged'],tag+'Source unchanged')
    ck(w['callbacks']==h['callbacks'] and w['callbacks']<=p['limits']['root_callbacks'] and w['native_requests_started']<=512,tag+'work/query caps')
    ck(t['threads_terminal'] and t['errors']==o['errors']==[],tag+'cleanup errors')
    ck(t['final_custody_gate_passed'] and t['final_custody_gate_seconds']<210 and o['final_observer_gate_seconds']<210 and o['fallback_trigger_seconds'] is None,tag+'custody clocks')
    for carrier,root in ((t,A),(o,O)):
        for n,v in carrier['logs'].items():
            ck(v['eof'] and not v['overflow'] and v['bytes']==v['stored']==(root/(n+'.bin')).stat().st_size and v['bytes']<=p['limits']['log_bytes'],tag+'log '+n)
    nt=w['native_transport']; stages=nt['request_stages']; sci=w['scientific_result']; led=w['guard_compilations'][0]
    ck(len(w['guard_compilations'])==1,tag+'one guard ledger')
    ck(nt['closed'] and nt['all_reaped'] and nt['cleanup_errors']==[] and nt['same_owned_process_group'] and nt['native_pgid']==owner['child_pgid'],tag+'Native ownership/closure')
    ck(nt['stdout_eof'] and nt['stdout_pending_bytes']==0 and nt['stderr_complete'] and nt['stderr_bytes']==0 and h['native_closed_and_reaped'],tag+'Native EOF')
    ck(w['native_peak_bytes']==nt['native_high_water_bytes']==nt['wait4_usage']['ru_maxrss'],tag+'Native HWM')
    tool=tr[sid]; ts=json.loads(tool['output']); ck(tool['exit_code']==(0 if ok else 2) and ts['resource_candidate_accepted']==ok and ts['case_id']==sid,tag+'Root tool transcription')
    records=sci['native_records'] if sci is not None else led['query_records']; qs={q['id']:q for q in records}
    ck(records==w['native_queries'] and len(records)==nt['complete_records'] and len(stages)==w['native_requests_started'],tag+'Native census')
    ck([q['id'] for q in records]==list(range(len(records))),tag+'Native ordinal sequence')
    for q in records:
        st=stages[q['id']]; req=q['request']; ck(q['request_sha256']==digest(req),tag+'full request SHA')
        ck(st['stage']=='COMPLETED' and st['record_id']==q['id'] and st['limit']==10**9 and st['purpose']==q['purpose'],tag+'current completed query')
        for k in ('request_sha256','input_sha256','output_sha256'): ck(st[k]==q[k] and len(q[k])==64,tag+'Native digest '+k)
        ck(req['protocol']=='gcts-fol-1' and req['blocks']==[],tag+'Native grammar/no blocks'); nc[q['result']['status']]+=1
        joins.append(dict(stage_id=sid,query=q['id'],purpose=q['purpose'],status=q['result']['status'],limit=st['limit'],**{k:q[k] for k in ('request_sha256','input_sha256','output_sha256')}))
    extra=int(sid=='eval-eval-quantified-02-seed1'); ck(len(stages)==len(records)+extra,tag+'pending exact')
    counts['native_complete']+=len(records); counts['native_starts']+=len(stages)
    last=stages[-1]; ck(pin(A/'native/input.bin')['sha256']==last['input_sha256'],tag+'last raw input')
    if last['stage']=='COMPLETED': ck(pin(A/'native/output.bin')['sha256']==last['output_sha256'],tag+'last raw output')
    else: ck(last['stage']=='SENT' and not (A/'native/output.bin').exists() and last['purpose']=='fixed_family_evaluation_eval-quantified-02_SP',tag+'unreturned final request')
    ck(led['complete'] and led['status']=='complete' and led['active_query'] is None and led['unresolved']==0,tag+'complete guard evidence')
    ck(led['queries']==[q['id'] for q in led['query_records']] and led['query_records']==records[:len(led['query_records'])],tag+'compiler owned prefix')
    members=led['members']; ck([m['ordinal'] for m in members]==list(range(len(members))) and led['resolved']==len(members),tag+'all guard members')
    ck(qs[led['theory_query']]['result']['status']=='accepted',tag+'theory admission')
    for b in led['batches']:
        q=qs[b['query_id']]; proof=q['request']['proof']
        ck(b['status']==q['result']['status'] and b['query_record_ordinal']==q['id'] and 0<b['stop']-b['start']<=4,tag+'batch interval')
        ck(proof==[m['command'] for m in members[b['start']:b['stop']]] and q['request']['target']==proof[-1]['formula'] and q['request']['theory']==spec['theory'],tag+'batch full row/request')
    for m in members:
        q=qs[m['native_query']]; ck(m['status']==q['result']['status'] and q['request']['proof'][m['native_row']]==m['command'],tag+'member query row')
        ck(m['status']=='accepted' or (m['status']=='rejected' and len(q['request']['proof'])==1 and m['resolution_kind']=='singleton_rejection'),tag+'no rejected parent pruning/UNKNOWN')
    row=dict(stage_id=sid,case_id=cid,seed=seed,plan=pp,result=pin(f) if ok else None,failure=None if ok else pin(f),worker_output=pin(f),header=pin(A/'worker-header.json'),terminal=pin(A/'terminal.json'),observer=pin(O/'observer.json'),grant=gp,consumed=pin(A/'CONSUMED.json'),owner=pin(A/'owned-child.json'),complete_file_census=census,physical_actual_bytes=physical,resource_admitted=ok,scientific_qualified=ok,stage_complete=ok,admitted=ok,admission_emitted=False,method_order=order,worker_status=w['status'],worker_error=w['error'],native_complete=len(records),native_started=len(stages),native_status_counts=dict(collections.Counter(q['result']['status'] for q in records)),uncompleted_native_stage=last if extra else None,whole_peak_bytes=o['final_conservative_whole_peak_bytes'],observer_elapsed_ledger_sample=o['elapsed_seconds'],final_observer_gate_seconds=o['final_observer_gate_seconds'],tool_transcription_row=tool,guard_evidence_summary=dict(complete=led['complete'],members=len(members),accepted=sum(m['status']=='accepted' for m in members),rejected=sum(m['status']=='rejected' for m in members),queries=len(led['query_records']),active_query=led['active_query']),arms=[])
    if not ok:
        ck(sci is None and w['status']=='FAILED_CASE_NOT_ADMITTED' and w['first_Root_fault'] and w['error']['type']=='RootBudget' and w['error']['message']=='absolute case work deadline',tag+'whole work failure')
        ck(t['process_exit_code']==o['parent_exit_code']==2 and not o['resource_candidate_accepted'] and not t['header_valid'] and t['result'] is None,tag+'no failed admission')
        ck(nt['native_exit_code']==-15 and nt['termination_signals']==[15] and o['final_conservative_whole_peak_bytes'] is None,tag+'failed controlled cleanup')
        ck(('search_points_selected' if seed==0 else '_finish_selector_proof') in w['error']['traceback'],tag+'recipient failure phase')
        row['failure_phase_diagnostic']='recipient point search / auxiliary-removal scan' if seed==0 else 'final SP Native proof-check request, unreturned SENT query'
        row['resource_scope']='Whole job work failure after complete compilation; scientific_result is null. No earlier arm is recovered.'
        row.update(controls=None,model=None,cumulative_costs=None)
        for a in order: row['arms'].append(dict(id=a,status='UNAVAILABLE_WHOLE_JOB_WORK_FAILURE',search_returned=False,proof_accepted=None,proof_status=None,proof_rows=None,attempts=None,domain_audits=None,search_seconds=None,full_arm_seconds=None,resource_admitted=False,scientific_qualified=False,stage_complete=False,admitted=False))
        counts['unavailable']+=6; counts['whole_job_work_failures']+=1
    else:
        ck(w['status']==h['status']=='COMPLETE' and w['error'] is None and not w['first_Root_fault'],tag+'worker complete')
        ck(t['header_valid'] and t['process_exit_code']==o['parent_exit_code']==0 and o['resource_candidate_accepted'],tag+'resource accepted')
        ck(nt['native_exit_code']==0 and nt['termination_signals']==[] and t['result']==pin(f),tag+'normal terminal')
        combined=t['parent_usage']['ru_maxrss']+max(t['child_usage']['ru_maxrss'],h['python_peak_after_output_bytes'])+h['native_peak_bytes']+9437184
        whole=combined+o['final_observer_peak_bytes']+9437184
        ck(combined==t['conservative_combined_peak_bytes'] and whole==o['final_conservative_whole_peak_bytes'] and whole<p['limits']['memory_bytes'],tag+'HWM plus reserves')
        ck(w['elapsed_seconds']<180 and h['seconds']<180,tag+'positive bound')
        ck(sci['stage_complete'] and sci['job_record_complete'] and sci['all_six_searched'] and sci['stage_id']==sid and sci['evaluation_seed']==seed and sci['resource_admitted'] is False,tag+'science scope')
        ck(len(sci['records'])==1,tag+'one case'); case=sci['records'][0]
        ck(case['spec']==spec and [a['id'] for a in case['arms']]==order,tag+'exact spec/order')
        ck(sci['libraries']==acq['libraries'] and digest(sci['libraries'])==libs,tag+'fresh library equality')
        ac=sci['acquisition_check']; ck(ac['complete'] and ac['qualified'] and ac['donors']==2 and ac['certificates']==5 and ac['pairing']==acq['pairing'],tag+'fresh acquisition reconstruction')
        for v in ac['Native_evidence']:
            q=aq[v['query']]; ck(q['result']['status']=='accepted' and v['request_sha256']==q['request_sha256'] and v['result_sha256']==digest(q['result']),tag+'certified Native evidence reuse')
        ck(sci['export']['acquisition_export_sha256']==digest(acq['export']) and sci['export']['libraries_sha256']==libs,tag+'export identity')
        cc=sci['cumulative_costs']; ck(cc['stage_ids']==['acquire-0'] and cc['receipts']==[seal] and cc['whole_seconds']==seal['whole_seconds'] and cc['current_entry_seconds']==sci['seconds'] and cc['current_whole_seconds'] is None,tag+'cost identity')
        ck(case['compiler']['guard_evidence']==led and case['guard_acquisition_check']['complete'] and case['guard_acquisition_check']['carrier_verified'] and case['guard_acquisition_check']['original_members']==len(members),tag+'guard carrier equality')
        controlrows={}
        for n,expect in [('numeric',23),('word',48),('graph',22),('encoding',40),('principal',53),('matched_symbolic',13)]:
            v=sci['controls'][n]; rr=v['controls']; ck(v['complete'] and len(rr)==expect and all(x['status']=='PASSED' for x in rr),tag+'controls '+n); controlrows[n]=dict(count=len(rr),sha256=digest(v))
        ck(all(sci['controls'][n] is None for n in ('corpus','guard_resolver','native_batch','guard_differential','reference_setup_calibration')),tag+'acquisition-only controls not recounted')
        ck(sci['controls']['inherited']['status']=='complete',tag+'inherited control'); counts['qualified_control_rows']+=199
        model=case['model']; ck(case['reference_check']['complete'] and case['word_model_check']['complete'] and model['word_terminator']==256,tag+'model gates')
        ck(case['word_reference_differential']['performed_on_this_model'] is False,tag+'production v3 scope')
        words=[]
        for hx in model['word_dictionary']:
            raw=bytes.fromhex(hx); v=json.loads(raw); ck(json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()==raw,tag+'canonical complete words'); words.append(v)
        ck(words[0]==spec['target'] and model['initial']['marks']==[[[4*(spec['length']-1),100],0]],tag+'target ID0')
        placements={tuple(x['key']):x for x in model['placements']}; ck(len(placements)==len(model['placements']),tag+'unique keys')
        mmaps={k:{tuple(pt):v for pt,v in x['marks']} for k,x in placements.items()}; dep=collections.defaultdict(set)
        for k,x in placements.items():
            ck(x['command_reference']==[k[0],k[2]],tag+'command reference'); cmd=model['domains'][k[0]][k[2]]; mm=mmaps[k]
            ck(words[mm[(4*k[0]+1,100)]]==cmd and words[mm[(4*k[0],100)]]==cmd['formula'] and mm[(4*k[0]+2,90)]==0,tag+'literal command/formula/mode word')
            for r,formula in x['metadata']['requirements']: ck(words[mm[(4*r,100)]]==formula,tag+'guard requirement')
            for pt,v in x['marks']:
                ck(type(v) is int and ((pt[1]==100 and 0<=v<len(words)) or (pt[1]==90 and v==0)),tag+'strict word/scalar ID'); dep[tuple(pt)].add(k)
            for pt,v in x['occupancy']: dep[tuple(pt)].add(k)
        ck({tuple(x['point']):{tuple(k) for k in x['keys']} for x in model['dependencies']}==dict(dep),tag+'complete literal inverse incidence'); modelplacements+=len(placements)
        marks=case['marking']; certs=marks['markings']['certificates']; ck(marks['marking_certificate_check']['complete'] and marks['marking_certificate_check']['certificates']==len(certs)==12 and marks['marked_extension_check']['complete'],tag+'marking gates')
        align={tuple(x['point']):{tuple(k) for k in x['keys']} for x in model['alignments']}
        for cert in certs:
            a=cert['auxiliary']; ck(a['initial_value']==1 and a['placement_value']==0 and a['point'][0]==-100 and len(cert['trial'])==1 and a['placement']==cert['trial'][0],tag+'auxiliary conflict values')
            ck({tuple(x['key']) for x in cert['all_candidates']}==align[tuple(cert['exhausted_root'])],tag+'certificate full original root domain')
            assigned={tuple(pt):v for pt,v in model['initial']['marks']}; assigned.update(mmaps[tuple(cert['trial'][0])])
            for z in cert['all_candidates']:
                wi=z['witness']; pt=tuple(wi['point']); ck(wi['kind']=='marking' and assigned[pt]==wi['assigned_value'] and mmaps[tuple(z['key'])][pt]==wi['candidate_value'] and wi['assigned_value']!=wi['candidate_value'],tag+'literal conflict witness values')
        by={a['id']:a for a in case['arms']}
        for arm in case['arms']:
            aid=arm['id']; se=arm['search']; pc=arm['proof_check']; trace=se['trace']; point=aid not in ('S0','SP'); attempts=se['metrics']['attempts']
            ck(arm['execution_status']=='SEARCH_RETURNED' and se['root_restored'],tag+'returned/restored '+aid)
            ck(arm['certified_markings']==(aid in ('PM','PML')) and arm['cluster_ordering']==(aid in ('SP','PL','PML')),tag+'factor '+aid)
            ck(attempts==sum(e['event']==('place' if point else 'extend') for e in trace),tag+'attempt trace '+aid)
            audit=se.get('domain_audits',[]); ck(len(audit)==(2 if point else 0) and all(v['complete'] for v in audit),tag+'first-two audits '+aid)
            orders_n=pools_n=0; prefix=[]; stack=[]; repeated=preferred_repeated=0
            for i,e in enumerate(trace):
                if e['event']=='decision' and not point:
                    ck(permutation(e['original_candidates'],e['ordered_candidates']),tag+'symbolic full fallback permutation'); orders_n+=1
                    if aid=='SP' and e['pool'] is not None: ck(e['pool']['complete'] and e['pool']['scheduler_context']=='CHRONOLOGICAL_SYMBOLIC_PREFIX_NO_POINT_LEGALITY',tag+'SP nonpoint pool')
                if e['event']=='order' and point:
                    dec=trace[e['decision']]; ck(dec['event']=='decision' and permutation(dec['original_alternatives'],e['alternatives']),tag+'point full fallback permutation')
                    ck(dec['kind']!='forced' or dec['original_alternatives']==e['alternatives'],tag+'forced unchanged'); orders_n+=1
                if e['event']=='place': ck(tuple(e['key']) in placements,tag+'existing placed key')
                if e['event']=='selector_pool':
                    ck(e['pool']['complete'] and e['action']['mode']=='fixed' and e['action']['weights']==[0.0]*9,tag+'point fixed pool'); pools_n+=1
                if e['event']=='extend' and not point:
                    dec=trace[e['decision']]; ck([e['skeleton'],e['variant']] in dec['ordered_candidates'],tag+'symbolic domain pair')
                    cmd=model['domains'][dec['row']][e['skeleton']]; ck((dec['row'],1,e['skeleton'],e['variant']) in placements,tag+'symbolic distinct guard key')
                    rep=cmd['formula'] in [x['formula'] for x in prefix]; repeated+=rep; preferred_repeated+=bool(rep and e.get('preferred'))
                    stack.append((e['decision'],prefix[:])); prefix.append(cmd)
                if e['event']=='return' and not point:
                    ck(bool(stack) and stack[-1][0]==e['decision'],tag+'symbolic return LIFO'); prefix=stack.pop()[1]
            if point:
                counts['point_placements']+=attempts; counts['domain_audits']+=len(audit)
                ck(len(se['initial_auxiliary_removals'])==(12 if arm['certified_markings'] else 0),tag+'initial auxiliary incidence '+aid)
            found=pc['status']=='HOST_REGION_NATIVE_ACCEPTED'; ck(found==(se['proof'] is not None),tag+'proof carrier '+aid)
            if found:
                q=pc['native_record']; ck(qs[q['id']]==q and q['purpose']=='fixed_family_evaluation_'+cid+'_'+aid and q['result']['status']=='accepted',tag+'fresh target Native '+aid)
                ck(q['request']==dict(protocol='gcts-fol-1',theory=spec['theory'],blocks=[],proof=se['proof'],target=spec['target']),tag+'complete target proof request '+aid)
                ck(pc['native_proof_accepted'] and pc['host_check']['accepted'] and pc['host_check']['rows']==len(se['proof']) and pc['host_check']['target']==spec['target'] and pc['region']['complete'] and pc['region']['decoded_rows']==len(se['proof']),tag+'three proof gates '+aid)
                ck(len(se['placements'])==2*len(se['proof']),tag+'command and guard per row')
                for rownum,cmd in enumerate(se['proof']):
                    kp=sorted((k for k in se['placements'] if k[0]==rownum),key=lambda k:k[1]); ck([k[:2] for k in kp]==[[rownum,0],[rownum,1]],tag+'selected row roles')
                    ck(all(model['domains'][k[0]][k[2]]==cmd and tuple(k) in placements for k in kp),tag+'selected command literal proof join')
                counts['proof_occurrences']+=1
            else: ck(pc['status']=='NO_PROOF_CANDIDATE' and se['proof'] is None,tag+'UNKNOWN is not negative proof')
            ar=dict(id=aid,engine=arm['engine'],status='HOST_REGION_NATIVE_ACCEPTED' if found else 'UNKNOWN',proof_status=pc['status'],search_status=se['status'],search_returned=True,proof_accepted=found,proof_rows=len(se['proof']) if found else None,proof_sha256=digest(se['proof']) if found else None,native_query=pc['native_record']['id'] if found else None,native_request_sha256=pc['native_record']['request_sha256'] if found else None,region=pc.get('region'),attempts=attempts,attempt_unit=se['attempt_unit'],domain_audits=len(audit),search_seconds=se['seconds'],full_arm_seconds=arm['full_arm_seconds'],trace_sha256=digest(trace),trace_order_permutations=orders_n,selector_pools=pools_n,packet_proposals=se['metrics'].get('cluster_proposals',0),initial_auxiliary_removals=len(se.get('initial_auxiliary_removals',[])) if point else None,repeated_formula_extensions=repeated if not point else None,preferred_repeated_formula_extensions=preferred_repeated if not point else None,resource_admitted=True,scientific_qualified=True,stage_complete=True,admitted=True)
            row['arms'].append(ar); totals[aid]['returned']+=1; totals[aid]['accepted' if found else 'UNKNOWN']+=1; totals[aid]['attempts']+=attempts; counts['searched']+=1
        for a,b in (('Pbase','PM'),('PL','PML')):
            if cid!='eval-equality-02': ck(by[a]['search']['proof']==by[b]['search']['proof'] and by[a]['search']['metrics']['attempts']==by[b]['search']['metrics']['attempts'],tag+'marking pair exact completed path '+a)
        row.update(controls=controlrows,model=dict(sha256=digest(model),placements=len(placements),dictionary_words=len(words),dependency_memberships=sum(len(x['keys']) for x in model['dependencies']),reference_check=case['reference_check'],word_model_check=case['word_model_check'],word_reference_differential=case['word_reference_differential'],marking_certificates=len(certs),shared_setup_seconds=case['shared_setup_seconds'],compile_and_model_seconds=case['compile_and_model_seconds'],word_model_seconds=case['word_model_seconds'],marking_clocks={k:v for k,v in marks.items() if k!='markings'},cost_scope=case['cost_scope']),cumulative_costs=cc,export_sha256=digest(sci['export']),resource_scope='Complete whole job independently eligible; UNKNOWN is a search outcome, not custody failure.')
        counts['qualified_jobs']+=1
    cases.append(row)
ck(counts['searched']==84 and counts['proof_occurrences']==74 and counts['unavailable']==12 and counts['qualified_jobs']==14,'aggregate outcome counts')
ck(counts['point_placements']==1717 and counts['domain_audits']==112 and counts['qualified_control_rows']==2786,'point/audit/control counts')
ck(counts['native_complete']==772 and counts['native_starts']==773 and nc=={'accepted':144,'rejected':628},'Native counts')
summary=dict(errors=errors[:30],error_count=len(errors),error_types=dict(collections.Counter(x.split(': ',1)[-1] for x in errors)),counts=dict(counts),native_status_counts=dict(nc),actual_complete_files=sum(len(x['complete_file_census']) for x in cases),input_pin_count=len(inputs),per_method={k:dict(v) for k,v in totals.items()},word_placement_literal_comparisons=modelplacements,observer_eval_seconds=sum(x['observer_elapsed_ledger_sample'] for x in cases))
print(json.dumps(summary,indent=2))
if not errors:
    out=dict(cases=cases,aggregate=dict(counts),native_status_counts=dict(nc),per_method={k:dict(v) for k,v in totals.items()},Native_complete_request_joins=joins,exact_input_pins=sorted(inputs.values(),key=lambda x:x['path']),actual_complete_files=summary['actual_complete_files'],actual_physical_bytes=sum(x['physical_actual_bytes'] for x in cases),word_placement_literal_comparisons=modelplacements,observer_eval_seconds=summary['observer_eval_seconds'],common_library_sha256=libs,scope='Independent stdlib complete saved JSON/value/hash inspection only. No experiment Source import, offered helper invocation, model/Graph/checker execution or proof replay.')
    path=C/'final16-independent-literal-joins-v1.json'
    if path.exists(): raise ValueError('immutable output already exists')
    path.write_text(json.dumps(out,indent=2,sort_keys=True,ensure_ascii=False)+'\n'); print('SUPPORT',json.dumps(pin(path)))
