"""Independent scripted orchestration controls. No actual Native acceptance.

All commands/statuses here are explicit synthetic controls, never donors or
observed proofs. Production resolver calls are permitted only in a future exact
Root-reviewed actual. Real Native controls are a separate Source module.
"""
import copy
import hashlib
import json

VERSION='D18-independent-zero-read-resolver-controls-v2'


def _need(value,message):
    if not value:
        raise ValueError('independent zero-read resolver control: '+message)


def _sha(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()


class _Oracle:
    def __init__(self,statuses,foreign=None):
        self.statuses=list(statuses);self.calls=[];self.foreign=foreign
    def request(self,request,limit,purpose):
        if self.foreign is not None:
            raise self.foreign
        ordinal=len(self.calls)
        _need(ordinal<len(self.statuses),'unexpected extra scripted query')
        row=dict(id=100+ordinal,request=copy.deepcopy(request),query_target='fixed_assertion',
            request_sha256=_sha(request),input_sha256='a'*64,output_sha256='b'*64,
            result=dict(status=self.statuses[ordinal]),seconds=0.0,purpose=purpose)
        self.calls.append(dict(request=copy.deepcopy(request),limit=limit,purpose=purpose,record=row))
        return row
    @property
    def records(self):
        raise AssertionError('resolver must retain returned records, not treat a supplied global list as proof')


def _rows():
    a=['fun','a',[]];b=['fun','b',[]];x=['var','x'];z=['var','z']
    ra=['pred','R',[a]];rb=['pred','R',[b]];u=['all','x',['pred','R',[x]]]
    commands=[dict(rule='instantiate',universal=u,term=a,formula=['imp',u,ra]),
              dict(rule='instantiate',universal=u,term=b,formula=['imp',u,rb]),
              dict(rule='eq_subst',variable='z',template=['pred','R',[z]],left=a,right=b,
                   formula=['imp',['eq',a,b],['imp',ra,rb]]),
              dict(rule='eq_subst',variable='z',template=['pred','R',[z]],left=b,right=a,
                   formula=['imp',['eq',b,a],['imp',rb,ra]])]
    return [dict(ordinal=i,purpose='first_order_scheme',command=c) for i,c in enumerate(commands)]


def run_resolver_controls(module,*,check):
    check();controls=[]
    theory=dict(functions={'a':0,'b':0},predicates={'P':0,'R':1},axioms={},schemas=[])
    def call(identity,rows,statuses,expected_status,expected_members,queries=512):
        check();before=copy.deepcopy((theory,rows));oracle=_Oracle(statuses)
        result=module.resolve_zero_read(theory,rows,oracle,limit=1000000000,queries=queries,check=check)
        check();_need((theory,rows)==before,'read-only caller inputs')
        _need(result['status']==expected_status,identity+' complete/incomplete status')
        _need([r['status'] for r in result['members']]==expected_members,identity+' per-occurrence status')
        _need(len(oracle.calls)==len(statuses)==len(result['query_records']),identity+' exact charged call count')
        _need(result['queries']==[r['id'] for r in result['query_records']],'nonzero current query IDs retained literally')
        _need(result['theory_query']==100,'seed identity')
        _need(result['resolved']==sum(s!='unresolved' for s in expected_members),'resolved count')
        _need(result['unresolved']==expected_members.count('unresolved'),'unresolved count')
        _need(result['complete'] is (expected_status=='complete'),'only complete compilation gets complete flag')
        _need(result['limits']['batch_rows']==4,'prospective fixed chunk4 policy')
        _need(result.get('active_query') is None,'no active query on returned carrier')
        records={r['id']:r for r in result['query_records']}
        for i,(candidate,member) in enumerate(zip(rows,result['members'])):
            _need(member['ordinal']==i and member['purpose']==candidate['purpose'] and member['command']==candidate['command'],
                  'complete original occurrence/candidate mapping')
            if member['status']=='unresolved':
                _need(member['native_query'] is member['native_row'] is member['resolution_kind'] is None,'no authority from unresolved batch')
            else:
                record=records[member['native_query']]
                _need(record['request']['proof'][member['native_row']]==candidate['command'],'exact Native batch row mapping')
                if member['status']=='rejected':
                    _need(record['result']['status']=='rejected' and len(record['request']['proof'])==1,
                          'rejection authority comes only from a singleton')
                else:_need(record['result']['status']=='accepted','acceptance requires complete accepted batch')
        for query in oracle.calls:
            _need(query['limit']==1000000000,'unchanged step ceiling')
            request=query['request']
            _need(request['protocol']=='gcts-fol-1' and request['blocks']==[] and request['theory']==theory,'same complete request context')
            _need(request['proof'] and request['target']==request['proof'][-1]['formula'],'nonempty proof/last target')
        controls.append(dict(id=identity,status='PASSED',result=result,scripted_calls=oracle.calls,
            evidence_scope='SCRIPTED_ORACLE_ORCHESTRATION_ONLY_NOT_NATIVE_PROOF'))
        return result
    rows=_rows()
    r=call('all-four-scheme-members-accepted',rows,['accepted','accepted'],'complete',['accepted']*4)
    _need([(b['start'],b['stop']) for b in r['batches']]==[(0,4)],'fixed contiguous batch')
    repeated=copy.deepcopy(rows)
    for row in repeated:row['command']=copy.deepcopy(rows[0]['command'])
    r=call('duplicate-occurrences-not-collapsed',repeated,['accepted','accepted'],'complete',['accepted']*4)
    _need([m['native_row'] for m in r['members']]==[0,1,2,3],'duplicate occurrence rows distinct')
    r=call('rejected-parent-does-not-reject-members',rows,['accepted','rejected','accepted','accepted'],'complete',['accepted']*4)
    _need([(b['start'],b['stop']) for b in r['batches']]==[(0,4),(0,2),(2,4)],'contiguous left-first split')
    r=call('one-singleton-rejected-siblings-preserved',rows,
        ['accepted','rejected','accepted','rejected','rejected','accepted'],'complete',
        ['accepted','accepted','rejected','accepted'])
    _need([(b['start'],b['stop']) for b in r['batches']]==[(0,4),(0,2),(2,4),(2,3),(3,4)],'exact split tree')
    call('UNKNOWN-parent-stays-unresolved',rows,['accepted','unknown_step_budget'],
         'unknown_native_compilation',['unresolved']*4)
    call('UNKNOWN-child-preserves-resolved-prefix-only',rows,['accepted','rejected','accepted','unknown_space_budget'],
         'unknown_native_compilation',['accepted','accepted','unresolved','unresolved'])
    call('local-cap-counts-seed-and-rejected-parent',rows,['accepted','rejected'],
         'unknown_compile_budget',['unresolved']*4,queries=2)
    call('theory-rejection-does-not-resolve-candidates',rows,['rejected'],
         'unknown_or_rejected_theory',['unresolved']*4)
    call('empty-candidate-list-seed-only-not-empty-Native-proof',[],['accepted'],'complete',[])
    p=['pred','P',[]]
    mixed=[dict(ordinal=0,purpose='first_order_tautology',command=dict(rule='tautology',formula=['imp',p,p])),
           dict(ordinal=1,purpose='first_order_tautology',command=dict(rule='tautology',formula=p))]
    for row in copy.deepcopy(rows):row['ordinal']=len(mixed);mixed.append(row)
    r=call('tautologies-singleton-schemes-batched',mixed,['accepted','accepted','rejected','accepted'],
         'complete',['accepted','rejected']+['accepted']*4)
    _need([(b['start'],b['stop']) for b in r['batches']]==[(0,1),(1,2),(2,6)],'no mixed/reordered member grouping')
    malformed=[]
    row=copy.deepcopy(rows[0]);row['ordinal']=True;malformed.append(('bool-member-ordinal',[row]))
    row=copy.deepcopy(rows[0]);row['command']['source']=0;malformed.append(('extra-context-field',[row]))
    row=copy.deepcopy(rows[0]);row['command']=dict(rule='mp',formula=p,antecedent=0,implication=0)
    malformed.append(('reading-MP-prohibited',[row]))
    for identity,bad in malformed:
        oracle=_Oracle([])
        try:module.resolve_zero_read(theory,bad,oracle,check=check)
        except BaseException as error:
            check()
            if not module.is_owned_error(error):
                raise
        else:raise ValueError('malformed resolver control accepted')
        _need(oracle.calls==[],'intake refusal precedes any Native query')
        controls.append(dict(id=identity,status='PASSED',Native_calls=0))
    for exception_type in (RuntimeError,ValueError,StopIteration):
        sentinel=exception_type('independent resolver foreign callback')
        def explode():raise sentinel
        try:module.resolve_zero_read(theory,rows,_Oracle([]),check=explode)
        except BaseException as error:_need(error is sentinel,'callback exact identity')
        else:raise ValueError('foreign callback swallowed')
        check();controls.append(dict(id='foreign-callback-'+exception_type.__name__,status='PASSED',exact_identity_propagated=True))
    sentinel=module.GuardAcquisitionError('public constructor impostor')
    try:module.resolve_zero_read(theory,rows,_Oracle([],foreign=sentinel),check=check)
    except BaseException as error:_need(error is sentinel and not module.is_owned_error(error),'oracle public-impostor identity')
    else:raise ValueError('foreign oracle error swallowed')
    controls.append(dict(id='foreign-oracle-public-impostor',status='PASSED',exact_identity_propagated=True))
    check()
    return dict(schema=VERSION,complete=True,count=len(controls),controls=controls,
        scope='Seventeen explicit scripted scheduling/intake/fault controls, not Native admissions, acquired proofs or recipient routes. '
              'Real Native mixed-batch diagnostics and old/batch full-model differentials remain separate acquisition-only obligations. '
              'No production function is called outside a fully reviewed Root actual.')
