def symbolic_ready_pool(model, prefix, library, modules, check, limits, work_counter):
    """Bounded contextual pool using ONLY ordinary chronological proof guards.

    Reads spec/compiled/domains, never Graph, State, placement, alignment,
    point values, candidate capacity or auxiliary failure exclusions.
    """
    helper = modules['symbolic']; spec = model.spec; compiled = model.compiled
    available = []
    for row, command in enumerate(prefix):
        check(); available.append(dict(kind='prefix',row=row,formula=command['formula']))
    for name, formula in sorted(spec['theory']['axioms'].items()):
        check(); available.append(dict(kind='axiom',name=name,formula=formula))
    result = dict(schema='symbolic-context-occurrence-ready-pool-v1',packets=[],complete=False,
        coverage='deterministic bounded prefix, not exhaustive all bindings',termination=None,
        scheduler_context='CHRONOLOGICAL_SYMBOLIC_PREFIX_NO_POINT_LEGALITY',
        validation_checks=0,inspected_bindings=0,refusals=collections.Counter(),
        source_occurrences=copy.deepcopy(available))
    stop = _ReadyPoolLimit('owned symbolic pool work/quota guard')
    def tick():
        check()
        if result['validation_checks'] >= limits['cluster_binding_work']:
            result['termination'] = 'work_prefix'; raise stop
        result['validation_checks'] += 1; work_counter['completed'] += 1
    basis_index = {}; tauts = set(); schemes = set()
    def admit(family,binding,sources):
        tick(); result['inspected_bindings'] += 1
        if len(binding) != family['parameters']:
            result['refusals']['unbound_parameter_abstention'] += 1; return
        arguments = [binding[index] for index in range(family['parameters'])]
        expansion, refusal = _bound_expansion(family,arguments,sources,prefix,spec,modules['host'],tick)
        if refusal is not None:
            result['refusals'][refusal] += 1; return
        trial_prefix = list(prefix); members = []
        for command in expansion['commands']:
            tick(); row = len(trial_prefix); matches = []
            if row >= spec['length']:
                result['refusals']['no_exact_symbolic_command'] += 1; return
            for index, candidate in enumerate(model.domains[row]):
                tick()
                if candidate == command:
                    matches.append(index)
            if len(matches) != 1:
                result['refusals']['no_exact_symbolic_command'] += 1; return
            if command['rule'] == 'axiom':
                variant = (0 if spec['theory']['axioms'][command['name']] == command['formula'] else None)
            else:
                variant = helper._primitive_guard(command,trial_prefix,basis_index,tauts,schemes)
            tick()
            if variant is None:
                result['refusals']['symbolic_primitive_guard_refused'] += 1; return
            need(type(variant) is int and variant >= 0, 'exact original symbolic guard variant')
            index = matches[0]; members.extend(((row,0,index,0),(row,1,index,variant)))
            trial_prefix.append(command)
        result['packets'].append(dict(expansion,members=members,pending=members,
            pool_ordinal=len(result['packets']),validation_checks_at_admission=result['validation_checks'],
            legality_scope='Host and existing chronological symbolic primitive guards only; no point/Graph/auxiliary-marking legality.'))
        if len(result['packets']) >= limits['cluster_proposals']:
            result['termination'] = 'packet_quota'; raise stop
    def bind(family,port,binding,sources):
        tick(); premises = family['template']['premises']
        if port == len(premises):
            admit(family,binding,sources); return
        for source in available:
            tick(); joined = _unify_checked(premises[port],source['formula'],binding,tick)
            if joined is not None:
                bind(family,port+1,joined,sources+[source])
    try:
        for index, formula in enumerate(compiled['basis']):
            tick(); basis_index[helper._json(formula)] = index
        for formula in compiled['tautologies']:
            tick(); tauts.add(helper._json(formula))
        for command in compiled['admitted_schemes']:
            tick(); schemes.add(helper._json(command))
        for family in library:
            tick(); bind(family,0,{},[])
        result['termination'] = 'declared_occurrences_exhausted'
    except _ReadyPoolLimit as error:
        if error is not stop:
            raise
    finally:
        stop.__traceback__ = None; bind = None; admit = None; tick = None
    result['complete'] = True; result['refusals'] = dict(result['refusals'])
    result['pool_size_class'] = '0' if not result['packets'] else '1' if len(result['packets']) == 1 else '2+'
    continuations = set()
    for packet in result['packets']:
        check(); continuations.add(tuple(packet['members']))
    result['distinct_primitive_continuations'] = len(continuations)
    result['continuation_size_class'] = '0' if not continuations else '1' if len(continuations) == 1 else '2+'
    check(); return result


def search_symbolic_principal(model, library, modules, check, limits):
    """Same S0 primitive prefix grammar/order, plus fixed symbolic packet preference.

    This search does not read any point-legal state or auxiliary marking. A
    returned proof is independently embedded/checked in the full region later.
    """
    began = time.perf_counter(); budget = _Budget(check,limits); helper = modules['symbolic']
    compiled = model.compiled; spec = model.spec
    basis_index = {helper._json(f):i for i,f in enumerate(compiled['basis'])}
    tauts = {helper._json(f) for f in compiled['tautologies']}; schemes = {helper._json(c) for c in compiled['admitted_schemes']}
    distances = {}; path = []; selected = []; trace = []; metrics = collections.Counter(); found = None
    work = {'completed':0}
    def visit(hint=None):
        nonlocal found
        budget.check(); row = len(path); metrics['nodes'] += 1
        if row == spec['length']:
            found = (copy.deepcopy(path),list(selected)); return True
        candidates = []
        for index, command in enumerate(model.domains[row]):
            budget.check(); metrics['skeleton_tests'] += 1
            variant = (0 if spec['theory']['axioms'][command['name']] == command['formula'] else None
                       ) if command['rule'] == 'axiom' else helper._primitive_guard(command,path,basis_index,tauts,schemes)
            if variant is not None:
                candidates.append((index,variant,command))
        available = {word(command['formula']) for command in path}
        candidates.sort(key=lambda item:(word(item[2]['formula']) in available,
            distances.get(helper._json(item[2]['formula']),len(distances)+1),item[0]))
        active = hint
        if active is not None and (not active['commands'] or active['prefix_rows'] != row):
            active = None
        pool = None
        if active is None:
            pool = symbolic_ready_pool(model,path,library,modules,budget.check,limits,work)
            active = pool['packets'][0] if pool['packets'] else None
            metrics['cluster_proposals'] += len(pool['packets'])
            metrics['pool_'+pool['pool_size_class']] += 1
            metrics['continuations_'+pool['continuation_size_class']] += 1
            metrics['selected_packets'] += int(active is not None)
        preferred = active['commands'][0] if active is not None else None
        ordered = [item for item in candidates if item[2] == preferred]+[item for item in candidates if item[2] != preferred]
        need(sorted((i,v) for i,v,c in ordered) == sorted((i,v) for i,v,c in candidates), 'complete symbolic candidate multiplicity/fallback')
        metrics['effective_order_changes'] += ordered != candidates
        ordinal = len(trace); trace.append(dict(event='decision',row=row,
            original_candidates=[[i,v] for i,v,c in candidates],ordered_candidates=[[i,v] for i,v,c in ordered],
            pool=pool,preferred_command=preferred,selection='fixed_first_packet_or_abstain'))
        for index, variant, command in ordered:
            budget.extend(); metrics['attempts'] += 1
            trace.append(dict(event='extend',decision=ordinal,skeleton=index,variant=variant,preferred=command == preferred))
            path.append(command); selected.extend(((row,0,index,0),(row,1,index,variant)))
            next_hint = (dict(active,prefix_rows=row+1,commands=active['commands'][1:])
                         if active is not None and command == preferred else None)
            try:
                if visit(next_hint):
                    trace.append(dict(event='return',decision=ordinal,skeleton=index,result=True)); return True
                trace.append(dict(event='return',decision=ordinal,skeleton=index,result=False)); metrics['backtracks'] += 1
            finally:
                del selected[-2:]; path.pop()
        return False
    status = 'unknown_search_budget'
    try:
        dependencies = helper._backward_distances(compiled['basis'],compiled['variables'],[],budget)
        distances = helper._distances_from_target(spec['target'],dependencies,budget)
        complete = visit(); status = 'symbolic_proof_candidate' if complete else 'exhausted_finite_symbolic_grammar'
    except _Cutoff as error:
        if error is not budget.stop:
            raise
        trace.append(dict(event='cutoff',attempts=budget.attempts)); budget.stop.__traceback__ = None
    visit = None; need(not path and not selected, 'exact symbolic prefix rollback')
    return dict(status=status,proof=None if found is None else found[0],placements=[] if found is None else found[1],
        trace=trace,metrics=dict(metrics),validation_checks=work['completed'],seconds=time.perf_counter()-began,
        attempt_unit='primitive proof-row extension',root_restored=True,cluster_ordering=True,
        strategy='S0 chronological symbolic grammar/novelty/backward order plus bounded context-Host/symbolic-guard checked principal preference; no point legality')
