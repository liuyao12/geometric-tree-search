"""Passive D18 display projection; ordinary complete saved JSON only.

No research module is imported, replayed or called. This reader is not a checker
or admission authority. Root executes it only after reviewing the exact Source.
"""
from pathlib import Path
import argparse
import copy
import hashlib
import json

SCHEMA = 'D18-matched-family-controls-passive-reader-v1'
METHODS = ('S0', 'SP', 'Pbase', 'PM', 'PL', 'PML')
ADMISSION_SCHEMA = 'D18-Root-whole-admission-v1'


def read(path):
    path = Path(path)
    if any('.partial' in part for part in path.parts):
        raise ValueError('partial files are raw-only and never displayed as results')
    return json.loads(path.read_bytes())


def optional(path):
    return read(path) if Path(path).is_file() else None


def pin(path):
    path = Path(path); body = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def require(value, message):
    if not value:
        raise ValueError(message)


def key(value):
    require(type(value) is list and len(value) == 4 and all(type(x) is int for x in value), 'literal four-int placement key')
    return tuple(value)


def admission(root, identity, result_path):
    path = root/'root/admission'/(identity+'-v1.json')
    row = optional(path)
    if row is None:
        return dict(status='PENDING_ADMISSION', admitted=False, resource_admitted=None,
                    scientific_qualified=None, stage_complete=None, receipt=None)
    require(row['schema'] == ADMISSION_SCHEMA and row['stage_id'] == identity,
            'exact Root-owned admission receipt schema/stage')
    for name in ('admitted','resource_admitted','scientific_qualified','stage_complete'):
        require(type(row[name]) is bool, 'exact admission booleans')
    gates = all(row[name] is True for name in ('admitted','resource_admitted','scientific_qualified','stage_complete'))
    if gates:
        require(result_path is not None and result_path.name == 'result.json' and row['result'] == pin(result_path),
                'all admitted display counts bind the complete current result bytes')
    return dict(status='WHOLE_ADMITTED' if gates else 'NOT_WHOLE_ADMITTED', admitted=gates,
                resource_admitted=row['resource_admitted'], scientific_qualified=row['scientific_qualified'],
                stage_complete=row['stage_complete'], receipt=dict(pin=pin(path),plan=row['plan'],result=row['result'],C_review=row['C_review'],
                             reasons=row.get('reasons'),details_scope='Full receipt/details remain in the raw archive.'))


def job(root, identity):
    directory = root/'actual'/identity
    paths = [p for p in (directory/'result.json',directory/'failure.json') if p.is_file()]
    require(len(paths) <= 1, 'one complete result or failure, never an ambiguous retry')
    result_path = paths[0] if paths else None
    worker = read(result_path) if result_path else None
    if worker is not None:
        require(worker['case_id'] == identity, 'complete result case identity')
    files = {}
    for name, path in [('result',result_path),('header',directory/'worker-header.json'),
                       ('terminal',directory/'terminal.json'),
                       ('observer',root/'actual'/(identity+'.observer')/'observer.json')]:
        if path is not None and path.is_file():
            files[name] = dict(pin=pin(path),value=read(path))
    accepted = admission(root,identity,result_path)
    return dict(stage_id=identity, worker=worker, files=files, admission=accepted,
                result_path=result_path, executed=worker is not None,
                science=None if worker is None else worker.get('scientific_result'))


def failure_phase(worker, science):
    """Classify only the preserved complete failure stack, never lost state."""
    if worker is None or science is not None or worker.get('error') is None:
        return None
    error = worker['error']; stack = error.get('traceback','')
    if (error.get('message') == 'absolute case work deadline'
            and 'in _compile_selector_case' in stack and 'in compile_guards' in stack
            and 'in _read_line' in stack):
        return dict(code='SHARED_COMPILER_NATIVE_SETUP_DEADLINE',before_arm_dispatch=True,
            evidence='Complete saved failure stack: _compile_selector_case -> compile_guards -> Native reply wait; absolute work deadline.',
            scope='Recipient shared setup precedes model return and all six arm dispatches in the frozen driver. No scientific_result is reconstructed; no time or memory phase attribution.')
    if any('in '+name in stack for name in ('_compile_selector_case','_case_evidence','_mark_selector_model')):
        return dict(code='SHARED_SETUP_FAILED_BEFORE_ARM_DISPATCH',before_arm_dispatch=True,
            evidence='Complete saved failure stack names a frozen shared setup function before arm dispatch.',
            scope='No scientific_result/model/search is reconstructed. Exact inner cause and retained guard ledger remain separately inspectable; no phase cost or memory attribution.')
    return dict(code='NO_RETURNED_SCIENTIFIC_RECORD',before_arm_dispatch=False,
        evidence='Complete saved worker failure; inspect exact error/stage records.',
        scope='The saved record does not identify a returned arm outcome. No proof or state is reconstructed.')


def point_trace(search):
    """Join only literal saved order/place/selector_pool records, no replay.

    A preferred placement event is narrower than cluster execution. No claim is
    made that an entire proposed expansion completed or caused a goal proof.
    """
    orders = {}; selected = []; pools = []; preferred_events = []
    trace = search['trace']
    for index, event in enumerate(trace):
        if event['event'] == 'order':
            require(event['decision'] not in orders, 'one saved primitive order per decision')
            orders[event['decision']] = (index,event)
        elif event['event'] == 'selector_pool':
            pool = event['pool']; action = event['action']; choice = action['choice']
            require(pool['complete'] is True and type(choice) is int
                    and 0 <= choice <= len(pool['packets']), 'complete returned pool and literal action')
            pools.append(dict(trace_index=index,decision=event['decision'],packet_count=len(pool['packets']),
                distinct_continuations=pool['distinct_primitive_continuations'],termination=pool['termination'],
                inspected_bindings=pool['inspected_bindings'],validation_checks=pool['validation_checks'],
                pool_size_class=pool['pool_size_class'],continuation_size_class=pool['continuation_size_class'],
                action_choice=choice,abstained=choice==len(pool['packets'])))
            if choice < len(pool['packets']):
                packet = pool['packets'][choice]
                selected.append(dict(trace_index=index,decision=event['decision'],packet_ordinal=choice,
                    family=packet['family'],arguments=packet['arguments'],source_binding=packet['source_binding'],
                    prefix_rows=packet['prefix_rows'],result_formula=packet['result_formula'],
                    commands=packet['commands'],pending=packet['pending'],members=packet['members'],
                    source_path='search.trace[%d].pool.packets[%d]'%(index,choice),
                    immediate_preferred_placement_trace_indices=[],whole_cluster_completion=None,
                    scope='Selected context-Host/trial-checked ordering packet, not a new inference or completed macro.'))
        elif event['event'] == 'place':
            require(event['decision'] in orders, 'saved place refers to a prior saved order')
            order_index, order = orders[event['decision']]
            candidate = key(event['key']); preferred = {key(k) for k in order['preferred']}
            if candidate in preferred:
                preferred_events.append(dict(trace_index=index,order_trace_index=order_index,
                    decision=event['decision'],key=event['key']))
                for packet in selected:
                    if packet['decision'] == event['decision'] and candidate in {key(k) for k in packet['pending']}:
                        packet['immediate_preferred_placement_trace_indices'].append(index)
    return dict(pools=pools,selected_packets=selected,preferred_placement_events=preferred_events,
        completed_pool_calls=len(pools),returned_pool_packets=sum(p['packet_count'] for p in pools),
        selected_packet_count=len(selected),preferred_placement_count=len(preferred_events),
        pools_with_competing_continuations=sum(p['distinct_continuations'] >= 2 for p in pools),
        whole_cluster_completion_count=None,
        scope='Exact literal saved event joins only. Selected packet, preferred placement (which may later be rolled back), completed expansion and accepted target proof are distinct. Calls interrupted before their trace append are unavailable, never counted as empty pools.')


def symbolic_trace(search):
    """Literal conventional SP preference events; no point legality or replay."""
    pools=[]; selected=[]; preferences=[]; decisions={}
    for index,event in enumerate(search['trace']):
        if event['event']=='decision':
            decisions[index]=event
            pool=event.get('pool')
            if pool is not None:
                require(pool['complete'] is True,'only a complete returned symbolic pool')
                packets=pool['packets']
                pools.append(dict(trace_index=index,row=event['row'],packet_count=len(packets),
                    distinct_continuations=pool['distinct_primitive_continuations'],
                    termination=pool['termination'],inspected_bindings=pool['inspected_bindings'],
                    validation_checks=pool['validation_checks'],pool_size_class=pool['pool_size_class'],
                    continuation_size_class=pool['continuation_size_class']))
                if packets:
                    packet=packets[0]
                    require(event['preferred_command']==packet['commands'][0], 'fixed first saved symbolic preference')
                    selected.append(dict(trace_index=index,row=event['row'],packet_ordinal=0,
                        family=packet['family'],arguments=packet['arguments'],source_binding=packet['source_binding'],
                        prefix_rows=packet['prefix_rows'],result_formula=packet['result_formula'],
                        commands=packet['commands'],members=packet['members'],
                        source_path='search.trace[%d].pool.packets[0]'%index,whole_cluster_completion=None))
        elif event['event']=='extend' and event['preferred'] is True:
            decision=decisions[event['decision']]
            require([event['skeleton'],event['variant']] in decision['ordered_candidates'],
                    'saved preferred ordinary row is a listed candidate')
            preferences.append(dict(trace_index=index,decision=event['decision'],row=decision['row'],
                skeleton=event['skeleton'],variant=event['variant'],command=decision['preferred_command']))
    return dict(pools=pools,selected_packets=selected,preferred_row_extension_events=preferences,
        completed_pool_calls=len(pools),returned_pool_packets=sum(p['packet_count'] for p in pools),
        selected_packet_count=len(selected),preferred_row_extension_count=len(preferences),
        preferred_placement_count=None,pools_with_competing_continuations=sum(p['distinct_continuations']>=2 for p in pools),
        whole_cluster_completion_count=None,engine='symbolic',
        scope='Saved completed pool/decision/ordinary extend event joins only. A preferred row extension is not a point placement, successful subtree, completed cluster or accepted target proof. No point State/Graph/auxiliary legality is inferred.')


def proof_view(title, case, search, checks, method, job_admission, source):
    proof = search.get('proof')
    if proof is None:
        return None
    require(type(proof) is list and proof, 'nonempty returned primitive proof')
    placements = search['placements']; require(len(placements) == 2*len(proof), 'saved command/guard pair per primitive row')
    model = case['model']; lookup = {key(t['key']):t for t in model['placements']}
    require(len(lookup) == len(model['placements']), 'full saved placement keys unique')
    auxiliaries = []
    if method in ('PM','PML'):
        auxiliaries = [dict(c['auxiliary'],certificate_id=c['id'],exhausted_root=c['exhausted_root'],
                           support_witness_count=len(c['all_candidates']))
                       for c in case['marking']['markings']['certificates']]
    overlay = {}
    for assignment in auxiliaries:
        overlay.setdefault(key(assignment['placement']),[]).append([assignment['point'],assignment['placement_value']])
    tiles = []; word_ids = set()
    for value in placements:
        k = key(value); tile = copy.deepcopy(lookup[k]); slot, choice = tile['command_reference']
        require(type(slot) is int and type(choice) is int and 0 <= slot < len(proof)
                and model['domains'][slot][choice] == proof[slot], 'literal selected tile to exact proof-row join')
        tile['auxiliary_overlay'] = overlay.get(k,[])
        if tile['auxiliary_overlay']:
            by_point = {tuple(p):v for p,v in tile['marks']}
            for point, assigned in tile['auxiliary_overlay']:
                require(tuple(point) not in by_point or by_point[tuple(point)] == assigned, 'literal compatible auxiliary overlay')
                by_point[tuple(point)] = assigned
            tile['marks'] = [[list(p),v] for p,v in sorted(by_point.items())]
        for point, value in tile['marks']:
            if point[1] == 100:
                require(type(value) is int and 0 <= value < len(model['word_dictionary']), 'exact selected whole-word ID')
                word_ids.add(value)
        tiles.append(tile)
    words = {}
    for index in sorted(word_ids):
        literal = model['word_dictionary'][index]
        words[str(index)] = dict(hex=literal,literal=json.loads(bytes.fromhex(literal).decode('utf8')))
    native_accepted = checks.get('native_proof_accepted') is True
    if native_accepted:
        require(checks['status'] == 'HOST_REGION_NATIVE_ACCEPTED'
                and checks['host_check']['accepted'] is True and checks['region']['complete'] is True
                and checks['native_record']['result']['status'] == 'accepted'
                and checks['native_record']['request']['proof'] == proof
                and checks['native_record']['request']['blocks'] == [], 'literal final gate observations')
    return dict(title=title,target=case['spec']['target'],spec=case['spec'],proof=proof,tiles=tiles,words=words,
        word_terminator=model['word_terminator'],method=method,proof_check=checks,
        admitted_proof=job_admission['admitted'] and native_accepted,
        scope=('WHOLE-ADMITTED PRIMITIVE PROOF' if job_admission['admitted'] and native_accepted else
               'SAVED CANDIDATE / DIAGNOSTIC OBSERVATION; NOT AN ADMITTED TARGET PROOF'),
        words_scope='Only full words referenced by these selected tiles are projected here; complete original models/dictionaries and all trace events remain in the raw archive.',
        fixed_auxiliary_initial=[dict(point=a['point'],value=a['initial_value'],excluded_placement=a['placement'],
            excluded_placement_value=a['placement_value'],certificate_id=a['certificate_id'],
            exhausted_root=a['exhausted_root'],support_witness_count=a['support_witness_count']) for a in auxiliaries],
        source=source)


def project(root):
    root = Path(root).resolve()
    acquisition_input = root/'diagnostics-L/acquisition-inputs-v1.json'
    evaluation_input = root/'diagnostics-L/evaluation-inputs-v1.json'
    acquisition_doc = read(acquisition_input); document = read(evaluation_input)
    acquire = job(root,'acquire-0'); proofs = []; slots = []; jobs = []; families = []
    acq_science = acquire['science']
    if acq_science is not None:
        for index, case in enumerate(acq_science.get('records',[])):
            view = proof_view('Donor · '+case['spec']['title'],case,case['search'],case['proof_check'],'DONOR',
                acquire['admission'],dict(stage_id='acquire-0',path='scientific_result.records[%d]'%index))
            if view is not None:
                proofs.append(view)
        libraries = acq_science.get('libraries',{'atom':[],'principal':[]})
        require(len(libraries['atom']) == len(libraries['principal']), 'paired library multiplicity')
        for atom, principal in zip(libraries['atom'],libraries['principal']):
            require(atom['paired_unit_id'] == principal['paired_unit_id'], 'paired inventory unit identity')
            families.append(dict(paired_unit_id=atom['paired_unit_id'],atom=atom,principal=principal))
    all_jobs = [acquire]
    for spec in document['evaluation']:
        for seed in document['protocol']['evaluation_seeds']:
            identity = 'eval-'+spec['id']+'-seed'+str(seed); current = job(root,identity); all_jobs.append(current)
            science = current['science']; case = None; phase = failure_phase(current['worker'],science)
            if science is not None and science.get('records'):
                require(len(science['records']) == 1 and science['records'][0]['spec'] == spec, 'one exact returned evaluation case')
                case = science['records'][0]
            actual_arms = {} if case is None else {a['id']:a for a in case.get('arms',[])}
            require(len(actual_arms) == (0 if case is None else len(case.get('arms',[]))), 'no collapsed method occurrence')
            require(set(actual_arms) <= set(METHODS), 'only declared fixed methods')
            order = document['protocol']['arm_order'][spec['id']][str(seed)]
            require(len(order)==6 and set(order)==set(METHODS), 'complete declared six-arm schedule')
            for position, method in enumerate(order):
                arm = actual_arms.get(method)
                if arm is not None:
                    observed = arm['search']; status = arm['execution_status']
                    if not current['admission']['admitted']:
                        status = 'RAW_'+status+'_NOT_WHOLE_ADMITTED'
                    joined = (symbolic_trace(observed) if method == 'SP' else
                              point_trace(observed) if method in ('Pbase','PM','PL','PML') else None)
                    view = proof_view(spec['title']+' · order '+str(seed)+' · '+method,case,observed,arm['proof_check'],method,
                        current['admission'],dict(stage_id=identity,path='scientific_result.records[0].arms[%d]'%case['arms'].index(arm)))
                    proof_index = None
                    if view is not None:
                        proof_index = len(proofs); proofs.append(view)
                    row = dict(stage_id=identity,case_id=spec['id'],title=spec['title'],target=spec['target'],seed=seed,
                        method=method,order_position=position+1,execution_status=status,returned=True,
                        admission=current['admission'],search_status=observed['status'],proof_status=arm['proof_check']['status'],
                        native_proof_observed=arm['proof_check']['native_proof_accepted'],
                        admitted_proof=current['admission']['admitted'] and arm['proof_check']['native_proof_accepted'] is True,
                        metrics=observed['metrics'],attempt_unit=observed['attempt_unit'],search_seconds=observed['seconds'],
                        full_arm_seconds=arm['full_arm_seconds'],proof_view_index=proof_index,
                        domain_audits=len(observed.get('domain_audits',[])),trace_joins=joined,
                        shared_setup_seconds=case['shared_setup_seconds'],failure_phase=phase,
                        engine=arm['engine'],certified_markings=arm['certified_markings'],cluster_ordering=arm['cluster_ordering'])
                else:
                    if current['executed']:
                        status = ('NOT_RUN_SHARED_SETUP_FAILED' if phase is not None
                                  and phase['before_arm_dispatch'] is True else
                                  'NO_RETURNED_SEARCH_RECORD_JOB_FAILED_OR_INCOMPLETE')
                    elif acquire['executed'] and (acq_science is None or acq_science.get('stage_complete') is not True
                            or acquire['admission']['status'] == 'NOT_WHOLE_ADMITTED'):
                        status = 'NOT_RUN_ACQUISITION_GATE'
                    else:
                        status = 'NOT_STARTED_PENDING'
                    row = dict(stage_id=identity,case_id=spec['id'],title=spec['title'],target=spec['target'],seed=seed,
                        method=method,order_position=position+1,execution_status=status,returned=False,
                        admission=current['admission'],search_status=None,proof_status=None,native_proof_observed=None,
                        admitted_proof=False,metrics=None,attempt_unit=None,search_seconds=None,full_arm_seconds=None,
                        proof_view_index=None,domain_audits=None,trace_joins=None,shared_setup_seconds=None,failure_phase=phase,
                        engine='symbolic' if method in ('S0','SP') else 'point',
                        certified_markings=method in ('PM','PML'),cluster_ordering=method in ('SP','PL','PML'))
                slots.append(row)
            worker = current['worker']
            jobs.append(dict(stage_id=identity,executed=current['executed'],admission=current['admission'],
                worker_status=None if worker is None else worker['status'],error=None if worker is None else worker['error'],
                failure_phase=phase,
                worker_stages=[] if worker is None else worker['stages'],
                stage_complete=None if science is None else science.get('stage_complete'),
                file_pins={name:item['pin'] for name,item in current['files'].items()},
                resource_receipts={name:item['value'] for name,item in current['files'].items() if name != 'result'},
                shared_setup_seconds=None if case is None else case['shared_setup_seconds'],
                marking_clocks=None if case is None else {k:case['marking'][k] for k in
                    ('seconds','construction_seconds','certificate_verification_seconds','overlay_construction_seconds','extension_verification_seconds','clock_scope')},
                cost_scope=None if case is None else case['cost_scope'],
                guard_compilation_progress=[] if worker is None else [dict(schema=g.get('schema'),
                    status=g.get('status'),complete=g.get('complete'),resolved=g.get('resolved'),unresolved=g.get('unresolved'),
                    queries=g.get('queries'),member_count=len(g.get('members',[])),active_query=g.get('active_query'),
                    source_path='guard_compilations[%d]'%i) for i,g in enumerate(worker.get('guard_compilations',[]))]))
    require(len(slots)==96, 'all96 planned slots preserved')
    summary=[]
    for method in METHODS:
        rows=[r for r in slots if r['method']==method]
        summary.append(dict(method=method,planned=16,returned=sum(r['returned'] for r in rows),
            whole_admitted_searches=sum(r['returned'] and r['admission']['admitted'] for r in rows),
            admitted_proofs=sum(r['admitted_proof'] for r in rows),
            raw_native_accepted=sum(r['native_proof_observed'] is True for r in rows),
            returned_search_unknown=sum(r['returned'] and r['search_status']=='unknown_search_budget' for r in rows),
            missing_returned_searches=sum(not r['returned'] for r in rows),
            returned_pool_packets=sum(r['trace_joins']['returned_pool_packets'] for r in rows if r['trace_joins'] is not None),
            selected_packets=sum(r['trace_joins']['selected_packet_count'] for r in rows if r['trace_joins'] is not None),
            preferred_placement_events=sum(r['trace_joins']['preferred_placement_count'] for r in rows if r['trace_joins'] is not None and r['engine']=='point'),
            preferred_row_extensions=sum(r['trace_joins']['preferred_row_extension_count'] for r in rows if r['trace_joins'] is not None and r['engine']=='symbolic'),
            engine='symbolic' if method in ('S0','SP') else 'point'))
    costs=[]
    for current in all_jobs:
        observer=current['files'].get('observer')
        if observer is not None:
            value=observer['value']; require(type(value['elapsed_seconds']) in (int,float), 'recorded observer sample')
            costs.append(dict(stage_id=current['stage_id'],elapsed_seconds=value['elapsed_seconds'],
                final_observer_gate_seconds=value.get('final_observer_gate_seconds'),
                whole_peak_bytes=value.get('final_conservative_whole_peak_bytes'),
                admission_status=current['admission']['status'],observer=observer['pin']))
    acquisition_terminal = acquire['executed'] and 'terminal' in acquire['files']
    require(acquisition_terminal,'complete terminal acquisition record required; no prototype outcomes')
    acquisition_gate = acquire['admission']['admitted'] and acq_science is not None and acq_science.get('stage_complete') is True
    if acquisition_gate:
        require(all(current['executed'] and 'terminal' in current['files'] for current in all_jobs),
                'complete terminal evaluation cohort required after acquisition admission')
    else:
        require(not any(current['executed'] for current in all_jobs[1:]),
                'evaluation must not execute without whole-admitted acquisition')
    returned=sum(r['returned'] for r in slots)
    accepted=sum(r['admitted_proof'] for r in slots)
    unknown=sum(r['returned'] and r['search_status']=='unknown_search_budget' for r in slots)
    missing=sum(not r['returned'] for r in slots)
    assessment=[
        '%d of 96 planned method records returned; %d target-proof occurrences pass the displayed whole-admission and saved final proof gates. %d returned searches are bounded UNKNOWN, and %d planned method slots have no returned search. Missing records are not rejected theorems.'%(returned,accepted,unknown,missing),
        'S0 versus SP compares ordinary chronological symbolic search without/with the same fresh principal-family preferences. Pbase/PM/PL/PML form the point library/auxiliary-failure-marking controls. All retain problem-defining word and structure marks.',
        'Point placements and symbolic proof-row extensions are different units. A library packet, selected preference, ordinary extension/placement, completed cluster and accepted target proof are distinct; whole-cluster completion is not inferred by this display.',
        'All six methods share actual point/compiler/reference/evidence setup and one certified auxiliary packet construction/verification in each recipient job. Per-arm clocks are marginal search plus final checks, not standalone cold solvers. Marking-off arms do not avoid that common measured construction cost.',
        'Fresh acquisition is charged once. Observer job samples, common setup, marking enclosing/sub-stage clocks, search and full-arm clocks overlap and must not be added or subtracted to invent disjoint phase costs.',
        'This uses fixed selection, with no trained RL policy. The authored public cases and two mirrored order labels do not establish blind generalization, stochastic replication, state-of-the-art performance or a broad GCTS-specific advantage. The common scheme-batched setup also precludes cross-D17 timing attribution.'
    ]
    return dict(schema=SCHEMA,summary=('Complete saved matched-control outcomes are shown below.' if acquisition_gate else 'The acquisition gate did not admit an evaluation cohort; every not-launched planned method slot remains visible.')+' All 96 slots and Root admission gates are explicit.',
        assessment=assessment,corpus=dict(acquisition=acquisition_doc,evaluation=document,pins=[pin(acquisition_input),pin(evaluation_input)]),
        slots=slots,method_summary=summary,proofs=proofs,families=families,jobs=jobs,
        acquisition=dict(executed=acquire['executed'],admission=acquire['admission'],
            file_pins={name:item['pin'] for name,item in acquire['files'].items()},
            resource_receipts={name:item['value'] for name,item in acquire['files'].items() if name!='result'},
            status=None if acq_science is None else acq_science.get('status'),
            error=None if acquire['worker'] is None else acquire['worker'].get('error'),
            donor_outcomes=[] if acq_science is None else acq_science.get('donor_outcomes',[]),
            all_profile_fragments_accepted=None if acq_science is None else acq_science.get('all_profile_fragments_accepted'),
            pairing=None if acq_science is None else acq_science.get('pairing'),
            evaluation_gate=acquisition_gate),
        cost_samples=dict(unique_job_samples=costs,unique_stage_count=len(costs),
            acquisition_observer_seconds=sum(c['elapsed_seconds'] for c in costs if c['stage_id']=='acquire-0'),
            evaluation_observer_seconds=sum(c['elapsed_seconds'] for c in costs if c['stage_id']!='acquire-0'),
            total_observer_seconds=sum(c['elapsed_seconds'] for c in costs),
            scope='Each observed job sample counted once, including failed jobs. Acquisition shared once across the study, not16times. Observer samples precede final receipt output and are not exact tool end-to-end clocks. Shared setup, marking stages, search, full-arm, entry and observer samples overlap; never sum enclosing and enclosed clocks.'),
        assessment_scope='Fixed principal reuse and point2x2 auxiliary-mark/library controls. No RL training, blind-generalization or SOTA claim. All methods share compiler/point evidence/marking setup: marginal clocks are not standalone cold solver comparisons. All proofs need separate whole admission plus saved final Host/fullpointregion/fresh Native blocks=[]. No cross-study setup-speed attribution.',
        raw_evidence_scope='Complete saved JSON projection only, never proof/State/Graph replay or new admission. Full raw models/domains/marking witnesses/query records/guard ledgers/trace events/custody remain in the archive.')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--study-root',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args(); data=project(args.study_root)
    with args.output.open('x') as stream:
        json.dump(data,stream,ensure_ascii=True,separators=(',',':'),allow_nan=False);stream.write('\n')
    print(json.dumps(dict(output=pin(args.output),slots=len(data['slots']),proof_views=len(data['proofs']),scientific_calls=0)))


if __name__=='__main__':
    main()
