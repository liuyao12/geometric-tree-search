from pathlib import Path
import ast
R=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs')
B=R/'gcts-matched-family-controls-20261021/implementation-B'
old=R/'gcts-principal-family-search-20261021/implementation-B/proof_search_pilot_v16.py'
s=old.read_text().replace("import hashlib\n", "import hashlib\nimport sys\n",1)
s=s.replace('import principal_search_corpus_contract_v1 as fixed_corpus_reference', 'import matched_family_corpus_contract_v1 as fixed_corpus_reference')
s=s.replace('import reference_setup_calibration_v1 as setup_calibration', 'import reference_setup_calibration_v1 as setup_calibration\nimport matched_symbolic_reference_controls_v2 as matched_symbolic_reference\nimport zero_read_native_reference_controls_v1 as zero_read_native_reference\nimport zero_read_resolver_reference_controls_v2 as guard_resolver_reference\nimport guard_batch_differential_controls_v1 as guard_differential_reference\nimport quantified_receptors_v1 as legacy_guard_compiler')
s=s.replace("VERSION = 'native-word-point-principal-family-search-pilot-v16'", "VERSION = 'native-word-point-matched-family-controls-pilot-v17'")
s=s.replace('D17 v16 adds a fixed recipient-search stage, not RL training.', 'D18 v17 adds matched conventional principal reuse and point marking/library controls, not RL training.')
a=s.index('def _compile_selector_case(');b=s.index('\ndef _case_evidence(',a)
part=s[a:b].replace("limit=limits['native_steps'], queries=limits['compile_queries'])", "limit=limits['native_steps'], queries=limits['compile_queries'], check=check)")
part=part.replace("    inventory = _empty_inventory()", "    guard_check = modules['compiler'].verify_guard_evidence(spec,compiled,oracle.records,check=check)\n    need(guard_check['complete'] is True, 'complete accepted Native batch/singleton member evidence')\n    inventory = _empty_inventory()")
part=part.replace("    model.reference_receipt =", "    model.guard_acquisition_check = guard_check\n    model.guard_acquisition_version = modules['compiler'].GUARD_ACQUISITION_VERSION\n    model.reference_receipt =",1)
s=s[:a]+part+s[b:]
a=s.index('def _case_evidence(');b=s.index('\ndef _mark_selector_model(',a)
part=s[a:b].replace('reference_check=model.reference_receipt, word_reference_differential=model.reference_differential,', 'reference_check=model.reference_receipt, word_reference_differential=model.reference_differential,\n                guard_acquisition_check=model.guard_acquisition_check,\n                guard_acquisition_version=model.guard_acquisition_version,')
s=s[:a]+part+s[b:]
s0="""    began = time.perf_counter(); packet = compile_markings(model, check, limits)
    certificate = verify_markings(model, packet, check)
    marked = _MarkedModel(model, packet, modules['points'])
    extension = reference.verify_marked_extension(model, marked, packet, check=check)
    return marked, dict(markings=packet, marking_certificate_check=certificate,
                        marked_extension_check=extension, seconds=time.perf_counter()-began)"""
s1="""    began = time.perf_counter(); stage_started = time.perf_counter()
    packet = compile_markings(model, check, limits)
    construction_seconds = time.perf_counter()-stage_started; stage_started = time.perf_counter()
    certificate = verify_markings(model, packet, check)
    certificate_verification_seconds = time.perf_counter()-stage_started; stage_started = time.perf_counter()
    marked = _MarkedModel(model, packet, modules['points'])
    overlay_construction_seconds = time.perf_counter()-stage_started; stage_started = time.perf_counter()
    extension = reference.verify_marked_extension(model, marked, packet, check=check)
    extension_verification_seconds = time.perf_counter()-stage_started
    return marked, dict(markings=packet, marking_certificate_check=certificate,
                        marked_extension_check=extension, seconds=time.perf_counter()-began,
                        construction_seconds=construction_seconds,
                        certificate_verification_seconds=certificate_verification_seconds,
                        overlay_construction_seconds=overlay_construction_seconds,
                        extension_verification_seconds=extension_verification_seconds,
                        clock_scope='Four sequential stage brackets within this enclosing marking clock; common setup, not per-arm cost. Do not sum enclosing and enclosed clocks.')"""
assert s0 in s;s=s.replace(s0,s1,1)
s=s.replace("FIXED_STAGE_SCHEMA = 'gcts-principal-family-search-stage-export-v2'", "FIXED_STAGE_SCHEMA = 'gcts-matched-family-controls-stage-export-v1'")
s=s.replace("FIXED_METHODS = ('S0', 'P0', 'PA', 'PP')", "FIXED_METHODS = ('S0', 'SP', 'Pbase', 'PM', 'PL', 'PML')")
a=s.index('def _fixed_controls(');b=s.index('\ndef _fixed_fragment_resolution(',a)
part=s[a:b].replace('def _fixed_controls(stage, document, modules, check, limits):', 'def _fixed_controls(stage, document, modules, oracle, check, limits):')
part=part.replace('corpus=None, reference_setup_calibration=None)', "corpus=None, reference_setup_calibration=None, native_batch=None, guard_resolver=None, guard_differential=None,\n        matched_symbolic=matched_symbolic_reference.run_symbolic_controls(sys.modules[__name__],modules,check=check))")
part=part.replace("    if stage == 'acquire':", "    if stage == 'acquire':\n        result['guard_resolver'] = guard_resolver_reference.run_resolver_controls(modules['compiler'],check=check)\n        need(result['guard_resolver']['complete'] is True, 'complete scripted guard resolver controls; not Native authority')\n        result['guard_differential'] = guard_differential_reference.run_guard_differential_controls(\n            modules['compiler'],legacy_guard_compiler,word_points,reference,oracle,check=check)\n        need(result['guard_differential']['complete'] is True, 'complete tiny original/batch compiler and full Model differentials')\n        result['native_batch'] = zero_read_native_reference.run_native_batch_controls(oracle,check=check,limit=limits['native_steps'])\n        need(result['native_batch']['complete'] is True, 'complete actual zero-read Native controls')",1)
s=s[:a]+part+s[b:]
a=s.index('def run_fixed_stage(')
part=s[a:]
part=part.replace('D17 fresh acquisition or fixed recipient search;', 'D18 fresh acquisition or matched fixed recipient search;')
part=part.replace("scope='Fresh fixed atom/principal recipient-search comparison in the Native/word-point adaptation; no RL training, physical Wang acceptance or universal proof-search claim.'", "scope='Fresh matched conventional-principal and point2x2 library/auxiliary-failure-marking comparison in the Native/word-point adaptation; no RL training, physical Wang acceptance or broad proof-search claim.'")
part=part.replace('_fixed_controls(stage,active_doc,modules,check,limits)', '_fixed_controls(stage,active_doc,modules,oracle,check,limits)')
part=part.replace('Only this fresh complete D17 two-donor acquisition; no old D16 result/export adoption.', 'Only this fresh complete D18 two-donor acquisition; no prior proof/library/export adoption.')
part=part.replace('every D17 arm','every D18 arm')
part=part.replace("Setup differs from D15/D16; no direct end-to-end speed attribution.", "Common batch-compiler/setup differs from D17 and earlier; no direct cross-study timing speed attribution.")
part=part.replace("case['shared_setup_seconds'] = time.perf_counter()-setup_started", "case['shared_setup_seconds'] = time.perf_counter()-setup_started\n        case['cost_scope'] = 'All six methods share point compilation/representation and one certified auxiliary packet construction+verification. Arm search/full-arm clocks are marginal search+final checks, not standalone cold solver costs. Report common job/acquisition once; do not subtract overlapping clocks.'")
part=part.replace("need(len(order) == 4 and set(order) == set(FIXED_METHODS), 'complete four-method order')", "need(len(order) == 6 and set(order) == set(FIXED_METHODS), 'complete six-method matched order')")
part=part.replace("active = model if method == 'S0' else marked", "active = marked if method in ('PM','PML') else model")
old_dispatch="""            if method == 'S0':
                search = search_symbolic(active,[],False,modules,check,limits)
            elif method == 'P0':
                search = search_points(active,[],False,modules,check,limits)
            else:
                mode = 'atom' if method == 'PA' else 'principal'
                search = search_points_selected(active,libraries[mode],'fixed',untrained_interface,seed,modules,check,limits)
            entry = dict(id=method,search=search,certified_markings=method != 'S0',
                cluster_ordering=method in ('PA','PP'),execution_status='SEARCH_RETURNED',
                abstraction_mode={'PA':'atom','PP':'principal'}.get(method),
                selection_scope='deterministic fixed first context-validated packet; no learned policy' if method in ('PA','PP') else 'no cluster library')
"""
new_dispatch="""            if method == 'S0':
                search = search_symbolic(active,[],False,modules,check,limits)
            elif method == 'SP':
                search = search_symbolic_principal(active,libraries['principal'],modules,check,limits)
            elif method in ('Pbase','PM'):
                search = search_points(active,[],False,modules,check,limits)
            else:
                search = search_points_selected(active,libraries['principal'],'fixed',untrained_interface,seed,modules,check,limits)
            entry = dict(id=method,search=search,certified_markings=method in ('PM','PML'),
                problem_defining_word_structure_marks=True,engine='symbolic' if method in ('S0','SP') else 'point',
                cluster_ordering=method in ('SP','PL','PML'),execution_status='SEARCH_RETURNED',
                abstraction_mode='principal' if method in ('SP','PL','PML') else None,
                selection_scope='deterministic fixed first context-validated packet; no learned policy' if method in ('SP','PL','PML') else 'no cluster library')
"""
assert old_dispatch in part;part=part.replace(old_dispatch,new_dispatch)
part=part.replace('all_four_searched=True','all_six_searched=True').replace('EVALUATION_FOUR_METHOD_RECORD','EVALUATION_SIX_METHOD_RECORD')
s=s[:a]+part
# Add only the new purely symbolic control; do not change inherited S0/point code.
s+='\n\n'+(B/'symbolic_controls_addition_v1.fragment.py').read_text()
ta=ast.parse(old.read_text());tb=ast.parse(s)
fa={x.name:ast.dump(x,include_attributes=False) for x in ta.body if isinstance(x,(ast.FunctionDef,ast.ClassDef))}
fb={x.name:ast.dump(x,include_attributes=False) for x in tb.body if isinstance(x,(ast.FunctionDef,ast.ClassDef))}
changed=[n for n in fa if fa[n]!=fb[n]]
assert changed==['_compile_selector_case','_case_evidence','_mark_selector_model','_fixed_controls','run_fixed_stage'],changed
assert [n for n in fb if n not in fa]==['symbolic_ready_pool','search_symbolic_principal']
compile(s,str(B/'proof_search_pilot_v17.py'),'exec')
(B/'proof_search_pilot_v17.py').write_text(s)
print(changed)
