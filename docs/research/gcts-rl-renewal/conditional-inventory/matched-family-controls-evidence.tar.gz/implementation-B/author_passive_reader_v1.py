from pathlib import Path
import ast
R=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs')
P=R/'gcts-principal-family-search-20261021/implementation-B'; B=R/'gcts-matched-family-controls-20261021/implementation-B'
s=(P/'project_saved_principal_search_v2.py').read_text()
s=s.replace('Passive D17 display projection','Passive D18 display projection').replace("'D17-principal-family-search-passive-reader-v2'","'D18-matched-family-controls-passive-reader-v1'").replace("METHODS = ('S0', 'P0', 'PA', 'PP')","METHODS = ('S0', 'SP', 'Pbase', 'PM', 'PL', 'PML')").replace("'D17-Root-whole-admission-v1'","'D18-Root-whole-admission-v1'")
s=s.replace('all four arm dispatches','all six arm dispatches')
s=s.replace("return dict(code='SHARED_COMPILER_NATIVE_SETUP_DEADLINE',", "return dict(code='SHARED_COMPILER_NATIVE_SETUP_DEADLINE',before_arm_dispatch=True,")
s=s.replace("    return dict(code='NO_RETURNED_SCIENTIFIC_RECORD',", "    if any('in '+name in stack for name in ('_compile_selector_case','_case_evidence','_mark_selector_model')):\n        return dict(code='SHARED_SETUP_FAILED_BEFORE_ARM_DISPATCH',before_arm_dispatch=True,\n            evidence='Complete saved failure stack names a frozen shared setup function before arm dispatch.',\n            scope='No scientific_result/model/search is reconstructed. Exact inner cause and retained guard ledger remain separately inspectable; no phase cost or memory attribution.')\n    return dict(code='NO_RETURNED_SCIENTIFIC_RECORD',before_arm_dispatch=False,")
s=s.replace("if method != 'S0' and method != 'DONOR':","if method in ('PM','PML'):")
a=s.index('\ndef proof_view(')
symbolic='''
def symbolic_trace(search):
    """Literal conventional SP preference events; no point legality or replay."""
    pools=[]; selected=[]; preferences=[]; decisions={}
    for index,event in enumerate(search['trace']):
        if event['event']=='decision':
            decisions[index]=event
            pool=event.get('pool')
            if pool is not None:
                require(pool['complete'] is True,'only a complete returned symbolic pool')
                packets=pool['packets']
                pools.append(dict(trace_index=index,row=event['row'],packet_count=len(packets),
                    distinct_continuations=pool['distinct_primitive_continuations'],
                    termination=pool['termination'],inspected_bindings=pool['inspected_bindings'],
                    validation_checks=pool['validation_checks'],pool_size_class=pool['pool_size_class'],
                    continuation_size_class=pool['continuation_size_class']))
                if packets:
                    packet=packets[0]
                    require(event['preferred_command']==packet['commands'][0], 'fixed first saved symbolic preference')
                    selected.append(dict(trace_index=index,row=event['row'],packet_ordinal=0,
                        family=packet['family'],arguments=packet['arguments'],source_binding=packet['source_binding'],
                        prefix_rows=packet['prefix_rows'],result_formula=packet['result_formula'],
                        commands=packet['commands'],members=packet['members'],
                        source_path='search.trace[%d].pool.packets[0]'%index,whole_cluster_completion=None))
        elif event['event']=='extend' and event['preferred'] is True:
            decision=decisions[event['decision']]
            require([event['skeleton'],event['variant']] in decision['ordered_candidates'],
                    'saved preferred ordinary row is a listed candidate')
            preferences.append(dict(trace_index=index,decision=event['decision'],row=decision['row'],
                skeleton=event['skeleton'],variant=event['variant'],command=decision['preferred_command']))
    return dict(pools=pools,selected_packets=selected,preferred_row_extension_events=preferences,
        completed_pool_calls=len(pools),returned_pool_packets=sum(p['packet_count'] for p in pools),
        selected_packet_count=len(selected),preferred_row_extension_count=len(preferences),
        preferred_placement_count=None,pools_with_competing_continuations=sum(p['distinct_continuations']>=2 for p in pools),
        whole_cluster_completion_count=None,engine='symbolic',
        scope='Saved completed pool/decision/ordinary extend event joins only. A preferred row extension is not a point placement, successful subtree, completed cluster or accepted target proof. No point State/Graph/auxiliary legality is inferred.')

'''
s=s[:a]+symbolic+s[a:]
s=s.replace("joined = point_trace(observed) if method != 'S0' else None", "joined = (symbolic_trace(observed) if method == 'SP' else\n                              point_trace(observed) if method in ('Pbase','PM','PL','PML') else None)")
s=s.replace("require(len(order)==4 and set(order)==set(METHODS), 'complete declared four-arm schedule')", "require(len(order)==6 and set(order)==set(METHODS), 'complete declared six-arm schedule')")
s=s.replace("shared_setup_seconds=case['shared_setup_seconds'],failure_phase=phase)", "shared_setup_seconds=case['shared_setup_seconds'],failure_phase=phase,\n                        engine=arm['engine'],certified_markings=arm['certified_markings'],cluster_ordering=arm['cluster_ordering'])")
s=s.replace("proof_view_index=None,domain_audits=None,trace_joins=None,shared_setup_seconds=None,failure_phase=phase)", "proof_view_index=None,domain_audits=None,trace_joins=None,shared_setup_seconds=None,failure_phase=phase,\n                        engine='symbolic' if method in ('S0','SP') else 'point',\n                        certified_markings=method in ('PM','PML'),cluster_ordering=method in ('SP','PL','PML'))")
s=s.replace("shared_setup_seconds=None if case is None else case['shared_setup_seconds']))", "shared_setup_seconds=None if case is None else case['shared_setup_seconds'],\n                marking_clocks=None if case is None else {k:case['marking'][k] for k in\n                    ('seconds','construction_seconds','certificate_verification_seconds','overlay_construction_seconds','extension_verification_seconds','clock_scope')},\n                cost_scope=None if case is None else case['cost_scope'],\n                guard_compilation_progress=[] if worker is None else [dict(schema=g.get('schema'),\n                    status=g.get('status'),complete=g.get('complete'),resolved=g.get('resolved'),unresolved=g.get('unresolved'),\n                    queries=g.get('queries'),member_count=len(g.get('members',[])),active_query=g.get('active_query'),\n                    source_path='guard_compilations[%d]'%i) for i,g in enumerate(worker.get('guard_compilations',[]))]))")
s=s.replace("require(len(slots)==64, 'all64 planned slots preserved')", "require(len(slots)==96, 'all96 planned slots preserved')")
s=s.replace("and phase['code'] == 'SHARED_COMPILER_NATIVE_SETUP_DEADLINE'", "and phase['before_arm_dispatch'] is True")
s=s.replace("preferred_placement_events=sum(r['trace_joins']['preferred_placement_count'] for r in rows if r['trace_joins'] is not None)))", "preferred_placement_events=sum(r['trace_joins']['preferred_placement_count'] for r in rows if r['trace_joins'] is not None and r['engine']=='point'),\n            preferred_row_extensions=sum(r['trace_joins']['preferred_row_extension_count'] for r in rows if r['trace_joins'] is not None and r['engine']=='symbolic'),\n            engine='symbolic' if method in ('S0','SP') else 'point'))")
a=s.index("    require(all(current['executed']");b=s.index("\n\ndef main():",a)
s=s[:a]+'''    acquisition_terminal = acquire['executed'] and 'terminal' in acquire['files']
    require(acquisition_terminal,'complete terminal acquisition record required; no prototype outcomes')
    acquisition_gate = acquire['admission']['admitted'] and acq_science is not None and acq_science.get('stage_complete') is True
    if acquisition_gate:
        require(all(current['executed'] and 'terminal' in current['files'] for current in all_jobs),
                'complete terminal evaluation cohort required after acquisition admission')
    else:
        require(not any(current['executed'] for current in all_jobs[1:]),
                'evaluation must not execute without whole-admitted acquisition')
    returned=sum(r['returned'] for r in slots)
    accepted=sum(r['admitted_proof'] for r in slots)
    unknown=sum(r['returned'] and r['search_status']=='unknown_search_budget' for r in slots)
    missing=sum(not r['returned'] for r in slots)
    assessment=[
        '%d of 96 planned method records returned; %d target-proof occurrences pass the displayed whole-admission and saved final proof gates. %d returned searches are bounded UNKNOWN, and %d planned method slots have no returned search. Missing records are not rejected theorems.'%(returned,accepted,unknown,missing),
        'S0 versus SP compares ordinary chronological symbolic search without/with the same fresh principal-family preferences. Pbase/PM/PL/PML form the point library/auxiliary-failure-marking controls. All retain problem-defining word and structure marks.',
        'Point placements and symbolic proof-row extensions are different units. A library packet, selected preference, ordinary extension/placement, completed cluster and accepted target proof are distinct; whole-cluster completion is not inferred by this display.',
        'All six methods share actual point/compiler/reference/evidence setup and one certified auxiliary packet construction/verification in each recipient job. Per-arm clocks are marginal search plus final checks, not standalone cold solvers. Marking-off arms do not avoid that common measured construction cost.',
        'Fresh acquisition is charged once. Observer job samples, common setup, marking enclosing/sub-stage clocks, search and full-arm clocks overlap and must not be added or subtracted to invent disjoint phase costs.',
        'This uses fixed selection, with no trained RL policy. The authored public cases and two mirrored order labels do not establish blind generalization, stochastic replication, state-of-the-art performance or a broad GCTS-specific advantage. The common scheme-batched setup also precludes cross-D17 timing attribution.'
    ]
    return dict(schema=SCHEMA,summary=('Complete saved matched-control outcomes are shown below.' if acquisition_gate else 'The acquisition gate did not admit an evaluation cohort; every not-launched planned method slot remains visible.')+' All 96 slots and Root admission gates are explicit.',
        assessment=assessment,corpus=dict(acquisition=acquisition_doc,evaluation=document,pins=[pin(acquisition_input),pin(evaluation_input)]),
        slots=slots,method_summary=summary,proofs=proofs,families=families,jobs=jobs,
        acquisition=dict(executed=acquire['executed'],admission=acquire['admission'],
            file_pins={name:item['pin'] for name,item in acquire['files'].items()},
            resource_receipts={name:item['value'] for name,item in acquire['files'].items() if name!='result'},
            status=None if acq_science is None else acq_science.get('status'),
            error=None if acquire['worker'] is None else acquire['worker'].get('error'),
            donor_outcomes=[] if acq_science is None else acq_science.get('donor_outcomes',[]),
            all_profile_fragments_accepted=None if acq_science is None else acq_science.get('all_profile_fragments_accepted'),
            pairing=None if acq_science is None else acq_science.get('pairing'),
            evaluation_gate=acquisition_gate),
        cost_samples=dict(unique_job_samples=costs,unique_stage_count=len(costs),
            acquisition_observer_seconds=sum(c['elapsed_seconds'] for c in costs if c['stage_id']=='acquire-0'),
            evaluation_observer_seconds=sum(c['elapsed_seconds'] for c in costs if c['stage_id']!='acquire-0'),
            total_observer_seconds=sum(c['elapsed_seconds'] for c in costs),
            scope='Each observed job sample counted once, including failed jobs. Acquisition shared once across the study, not16times. Observer samples precede final receipt output and are not exact tool end-to-end clocks. Shared setup, marking stages, search, full-arm, entry and observer samples overlap; never sum enclosing and enclosed clocks.'),
        assessment_scope='Fixed principal reuse and point2x2 auxiliary-mark/library controls. No RL training, blind-generalization or SOTA claim. All methods share compiler/point evidence/marking setup: marginal clocks are not standalone cold solver comparisons. All proofs need separate whole admission plus saved final Host/fullpointregion/fresh Native blocks=[]. No cross-study setup-speed attribution.',
        raw_evidence_scope='Complete saved JSON projection only, never proof/State/Graph replay or new admission. Full raw models/domains/marking witnesses/query records/guard ledgers/trace events/custody remain in the archive.')
'''+s[b:]
compile(s,str(B/'project_saved_matched_controls_v1.py'),'exec');ast.parse(s)
(B/'project_saved_matched_controls_v1.py').write_text(s)
h=(P/'principal-family-search-template-v2.html').read_text()
h=h.replace('Fixed principal-family proof search','Matched family and marking controls').replace('D17 · fixed selection','D18 · matched controls').replace('Do principal receptor families help recipient proof search?','What do cluster reuse and failure markings contribute?')
h=h.replace('This comparison gives the same freshly acquired proof clusters two interfaces, then uses each interface in recipient search. Selection is fixed and deterministic. There is no RL training in this study.','This comparison separates conventional principal-family reuse from point search, and crosses point-library ordering with certified auxiliary failure markings. Selection is fixed and deterministic. No RL policy is trained.')
h=h.replace('Four methods, one primitive proof system','Six methods, one primitive proof system')
a=h.index('<div class="panel"><p><strong>S0:');b=h.index('<h2>What the saved comparison found',a)
h=h[:a]+'''<div class="panel"><p><strong>S0:</strong> conventional symbolic search, no library. <strong>SP:</strong> the same chronological symbolic grammar with principal-family preferences; it does not consult point legality. All final candidates receive the same full proof gates.</p><div class="scroll"><table><thead><tr><th>Point method</th><th>Library ordering off</th><th>Principal library ordering on</th></tr></thead><tbody><tr><th>Auxiliary failure marks off</th><td>Pbase</td><td>PL</td></tr><tr><th>Certified auxiliary failure marks on</th><td>PM</td><td>PML</td></tr></tbody></table></div><p>Problem-defining word and structure markings stay in every point arm. The point graph retains global dead-end and forced-move priority, then earliest-generation branching. A checked cluster only orders existing primitive alternatives at the selected point; all primitive alternatives and exact rollback remain. Fixed selection is not a new inference rule.</p><p>All methods share common point/compiler/reference/evidence setup and one auxiliary packet construction. Per-arm clocks measure marginal search and final checks, not standalone cold solver cost. Symbolic row extensions and point placements are different units.</p></div>
'''+h[b:]
h=h.replace('All 64 planned','All 96 planned').replace('across its four methods','across its six methods')
h=h.replace('Paired family interfaces','Fresh principal-family inventory').replace('Fresh conventional donor searches and accepted primitive fragments supply both abstractions.','Fresh conventional donor searches and accepted primitive fragments supply the principal library. Paired atom views are retained as acquisition provenance, not a D18 experimental factor.')
h=h.replace('These assignments are shared by all point methods.','These assignments are active only in PM and PML; all other methods retain the base problem marks.')
h=h.replace('A returned pool, a selected packet, a preferred primitive placement (which may later be rolled back), a completed cluster expansion and an accepted target proof are different events.','A returned pool, a selected packet, a preferred symbolic row extension or point placement (which may later be rolled back), a completed cluster expansion and an accepted target proof are different events.')
h=h.replace('Read a returned proof line by line','Read a returned proof line by line').replace('translated positions.','translated positions, without rotation.')
h=h.replace('principal-family-search-data.json','matched-family-controls-data.json').replace('principal-family-search-evidence.tar.gz','matched-family-controls-evidence.tar.gz').replace('principal-family-search-manifest.json','matched-family-controls-manifest.json')
h=h.replace('r.method!==\'S0\'','r.method!==\'S0\'')
h=h.replace("j.selected_packet_count+' selected packets; '+j.preferred_placement_count+' preferred placement events'", "j.selected_packet_count+' selected packets; '+(r.engine==='symbolic'?j.preferred_row_extension_count+' preferred row extensions':j.preferred_placement_count+' preferred placement events')")
h=h.replace('No returned point trace','No returned library preference trace')
h=h.replace("[[64,'planned search slots']", "[[96,'planned search slots']")
h=h.replace("d.cost_samples.scope)+'</p><details>", "d.cost_samples.scope)+'</p><h3>Common marking brackets</h3><p>Construction, certificate verification, overlay construction and extension verification are sequential brackets nested in the enclosing marking/shared setup clocks. Never add enclosing and enclosed values.</p><div class=\"scroll\"><table><thead><tr><th>Job</th><th>Construct</th><th>Certificate</th><th>Overlay</th><th>Extension check</th><th>Enclosing marking</th><th>Shared setup</th></tr></thead><tbody>'+d.jobs.map(j=>'<tr><td>'+esc(j.stage_id)+'</td><td>'+num(j.marking_clocks?.construction_seconds)+'</td><td>'+num(j.marking_clocks?.certificate_verification_seconds)+'</td><td>'+num(j.marking_clocks?.overlay_construction_seconds)+'</td><td>'+num(j.marking_clocks?.extension_verification_seconds)+'</td><td>'+num(j.marking_clocks?.seconds)+'</td><td>'+num(j.shared_setup_seconds)+'</td></tr>').join('')+'</tbody></table></div><details>")
# No JS is executed by this authoring script.
(B/'matched-family-controls-template-v1.html').write_text(h)
print('Authored passive Source only:',len(s.encode()),len(h.encode()))
