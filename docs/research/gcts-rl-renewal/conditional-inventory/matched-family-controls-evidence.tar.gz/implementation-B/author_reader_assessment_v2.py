from pathlib import Path
import ast
B=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-matched-family-controls-20261021/implementation-B')
old=B/'project_saved_matched_controls_v1.py';s=old.read_text()
s=s.replace('Passive D18 display projection; ordinary complete saved JSON only.','Passive D18 display projection v2; ordinary complete saved JSON only. Assessment is derived only at projection time.')
a=s.index('\ndef project(root):')
addition='''
def matched_assessment(slots, method_summary, jobs):
    """Passive matched comparisons; no search, replay or prespecified outcome."""
    by_method={r['method']:r for r in method_summary}
    rows={(r['case_id'],r['seed'],r['method']):r for r in slots}
    case_order=list(dict.fromkeys(r['case_id'] for r in slots))
    labels=list(dict.fromkeys(r['seed'] for r in slots))
    pairs=[(identity,label) for identity in case_order for label in labels]
    def coverage(method):
        return {(r['case_id'],r['seed']) for r in slots if r['method']==method and r['admitted_proof']}
    def successes(left,right):
        result=[]
        for identity,label in pairs:
            a=rows[(identity,label,left)];b=rows[(identity,label,right)]
            if a['admitted_proof'] and b['admitted_proof']:
                assert a['engine']==b['engine']=='point'
                assert a['attempt_unit']==b['attempt_unit']
                x=a['metrics']['attempts'];y=b['metrics']['attempts']
                assert type(x) is type(y) is int
                result.append(dict(case_id=identity,title=a['title'],order=label,left=x,right=y))
        return result
    paragraphs=[]
    paragraphs.append('Conventional matched control: S0 has %d admitted proof occurrences and SP has %d, each out of 16 planned slots (%d and %d returned respectively). Counts refer to case/order occurrences, not distinct theorems.'%(by_method['S0']['admitted_proofs'],by_method['SP']['admitted_proofs'],by_method['S0']['returned'],by_method['SP']['returned']))
    missed=[]
    for identity,label in pairs:
        baseline=rows[(identity,label,'S0')];preferred=rows[(identity,label,'SP')]
        if baseline['admitted_proof'] and preferred['returned'] and preferred['admission']['admitted'] and preferred['search_status']=='unknown_search_budget':
            missed.append('%s [order %d]'%(baseline['title'],label))
    if missed:
        paragraphs.append('At matched whole-admitted slots, S0 accepted while SP returned bounded UNKNOWN for: '+ '; '.join(missed)+'. This is a negative observation for the added fixed library preference in conventional search under these budgets; it is not a theorem impossibility or a causal timing profile.')
    else:
        paragraphs.append('No matched whole-admitted slot has an accepted S0 proof together with a returned bounded-UNKNOWN SP record. Inspect all unavailable or unresolved slots separately.')
    for off,on in (('Pbase','PM'),('PL','PML')):
        both=successes(off,on);equal=sum(r['left']==r['right'] for r in both)
        fewer=sum(r['right']<r['left'] for r in both);more=sum(r['right']>r['left'] for r in both)
        same_coverage=coverage(off)==coverage(on)
        paragraphs.append('Auxiliary marking contrast %s versus %s: admitted coverage is %d versus %d of 16 planned slots; %s. Among %d matched successful point searches, marking-on takes fewer placements in %d, more in %d and the same count in %d%s. Word/control problem marks stay in both arms.'%(off,on,len(coverage(off)),len(coverage(on)),('the exact accepted case/order sets coincide' if same_coverage else 'the accepted case/order sets differ'),len(both),fewer,more,equal,(' (all matched successful counts tie)' if both and equal==len(both) else '')))
    for off,on in (('Pbase','PL'),('PM','PML')):
        both=successes(off,on);gains=[r for r in both if r['right']<r['left']]
        losses=[r for r in both if r['right']>r['left']]
        details=['%s [order %d]: %d to %d'%(r['title'],r['order'],r['left'],r['right']) for r in gains]
        paragraphs.append('Point library contrast %s versus %s: admitted proof occurrences %d versus %d. Matched successful placement reductions%s; matched placement increases %d. These are within-point counts; a preferred packet is not a new inference, completed cluster or unique solved theorem.'%(off,on,len(coverage(off)),len(coverage(on)),(': '+ '; '.join(details) if details else ': none observed'),len(losses)))
    point_coverage=set().union(*(coverage(m) for m in ('Pbase','PM','PL','PML')))
    unique=point_coverage-coverage('S0')
    paragraphs.append(('No point method admits a case/order target beyond S0 in this cohort.' if not unique else '%d case/order targets are admitted by a point method beyond S0; this is a local result, not broad superiority.'%len(unique))+' The matched study does not establish a GCTS-specific, RL, blind-generalization or state-of-the-art advantage; no RL training occurs.')
    for current in jobs:
        if current['worker_status'] is None or current['stage_complete'] is not None:
            continue
        ledgers=current['guard_compilation_progress']
        for ledger in ledgers:
            if ledger['complete'] is True and ledger['status']=='complete':
                error=current['error'] or {};stack=error.get('traceback','')
                frames=[name for name in ('search_points_selected','_aux_removals','_finish_selector_proof','_read_line') if 'in '+name in stack]
                counts=ledger['member_status_counts']
                phase_scope=('The saved stack names a search or final-check stage, rather than compiler setup.' if any(name in frames for name in ('search_points_selected','_finish_selector_proof')) else 'Ledger completion alone does not identify the later failure phase.')
                paragraphs.append('Failed job %s has no returned scientific record, while its saved diagnostic compiler ledger is complete: %d members, %d accepted, %d rejected, %d unresolved, %d complete query records. Saved error-stack functions include %s. %s These complete failure-record observations do not reconstruct any arm outcome or salvage a proof.'%(current['stage_id'],ledger['member_count'],counts['accepted'],counts['rejected'],counts['unresolved'],ledger['complete_query_records'],(', '.join(frames) if frames else 'no classified later-stage function'),phase_scope))
    return paragraphs

'''
s=s[:a]+addition+s[a:]
s=s.replace("source_path='guard_compilations[%d]'%i) for i,g in enumerate(worker.get('guard_compilations',[]))]))", "source_path='guard_compilations[%d]'%i,complete_query_records=len(g.get('query_records',[])),\n                    member_status_counts={status:sum(m.get('status')==status for m in g.get('members',[]))\n                        for status in ('accepted','rejected','unresolved')})\n                    for i,g in enumerate(worker.get('guard_compilations',[]))]))")
s=s.replace("    return dict(schema=SCHEMA,summary=", "    assessment.extend(matched_assessment(slots,summary,jobs))\n    return dict(schema=SCHEMA,summary=",1)
old_tree=ast.parse(old.read_text());new_tree=ast.parse(s);compile(s,str(B/'project_saved_matched_controls_v2.py'),'exec')
a={n.name:ast.dump(n,include_attributes=False) for n in old_tree.body if isinstance(n,ast.FunctionDef)}
b={n.name:ast.dump(n,include_attributes=False) for n in new_tree.body if isinstance(n,ast.FunctionDef)}
assert [n for n in a if a[n]!=b[n]]==['project']
assert [n for n in b if n not in a]==['matched_assessment']
assert not [n for n in a if n not in b]
(B/'project_saved_matched_controls_v2.py').write_text(s)
print('Authored assessment-only passive successor, bytes',len(s.encode()))
