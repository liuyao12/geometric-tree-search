"""Raw Source and declarative JSON authoring only; no scientific imports."""
from pathlib import Path
import ast
import hashlib
import json

ROOT = Path(__file__).resolve().parent
STUDY = ROOT.parent
REPO = STUDY.parent.parent
OLD = REPO/'research-runs/gcts-principal-family-search-20261021/root'


def pin(path):
    p = Path(path).resolve()
    body = p.read_bytes()
    return dict(path=str(p), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def read(path):
    return json.loads(Path(path).read_bytes())


def write(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')


def main():
    old_protocol = read(OLD/'protocol-v1.json')
    proposal = read(STUDY/'diagnostics-L/protocol-proposal-v1.json')
    api = read(STUDY/'implementation-B/API-v1.json')
    assert old_protocol['limits'] == proposal['limits']
    assert old_protocol['experiment_limits'] == proposal['experiment_limits'] == api['limits']
    protocol = dict(old_protocol)
    protocol.update(
        schema='D18-Root-matched-family-controls-protocol-v1',
        corpus_protocol=pin(STUDY/'diagnostics-L/protocol-proposal-v1.json'),
        job_recipes=proposal['job_recipes'], population=proposal['population'],
        methods=proposal['methods'], scheduling=proposal['scheduling'],
        experiment_factor=proposal['factor_scope'],
        guard_acquisition=proposal['guard_acquisition'],
        reporting=proposal['reporting'],
        common_setup=api['cost'],
        controls=api['control_scope'],
        phase_intake=proposal['phase_separation'],
        unused_registry='Uniformly omit unused diagnostic ground registry. Every final target still requires fresh Host, complete finite region and Native blocks=[]. No cross-study cold speedup claim.',
        authority=proposal['final_proof_gates']+' Exact t/m and all complete graph/rollback/scheduling/fallback rules remain. SP uses ordinary symbolic guards only.',
        historical_setup=api['manual'] if 'manual' in api else pin(STUDY/'diagnostics-L/historical-setup-observation-v1.json'),
        source_offers=dict(B=pin(STUDY/'implementation-B/handoff-v1.json'),
                           L=pin(STUDY/'diagnostics-L/handoff-v2.json'),
                           C=pin(STUDY/'review-C/independent-controls-handoff-v2.json')),
        upstream_seal=old_protocol['upstream_seal'].replace('fresh acquisition','fresh D18 acquisition'),
    )
    write(ROOT/'protocol-v1.json', protocol)
    copied = []
    for row in api['runtime_additions']:
        assert pin(row['path']) == row
        source = Path(row['path'])
        target = STUDY/'runtime'/source.name
        body = source.read_bytes()
        ast.parse(body, filename=str(source))
        compile(body, str(source), 'exec')  # Unused code object only.
        with target.open('xb') as stream:
            stream.write(body)
        copied.append(dict(source=row, copy=pin(target)))
    assert len(copied) == 6
    assert len(list((STUDY/'runtime').glob('*.py'))) == 44
    write(ROOT/'runtime-additions-raw-copy-v1.json', dict(
        schema='D18-Root-runtime-additions-Source-only-v1', raw_copies=copied,
        inherited_runtime_count=38, added_runtime_count=6, runtime_count=44,
        scientific_imports=0, scientific_calls=0,
        scope='Raw checked copies and stdlib AST/unused compile only. Peer and whole review remain required.'))
    predecessor = OLD/'materialize_plans_v3.py'
    source = predecessor.read_text()
    start = source.index('    previous = read(')
    stop = source.index('    records = []', start)
    source = source[:start] + '''    previous = read(PREVIOUS/'root/plans/acquire-0-v2.json')
    protocol = read(ROOT/'protocol-v1.json')
    l_protocol = STUDY/'diagnostics-L/protocol-proposal-v1.json'
    if protocol['corpus_protocol'] != pin(l_protocol):
        raise ValueError('frozen corpus protocol')
    manifest = read(STUDY/'implementation-B/manifest-v1.json')
    api = read(STUDY/'implementation-B/API-v1.json')
    helper = read(helper_handoff)
    paths = set(STUDY.joinpath('runtime').glob('*.py'))
    if len(paths) != 44:
        raise ValueError('exact full 44-module inherited/new runtime')
    for row in manifest['files'] + manifest['dependencies'] + helper['files']:
        if pin(row['path']) != row:
            raise ValueError('frozen Source offer changed')
        paths.add(Path(row['path']))
    # Include frozen Source metadata but never either phase's input body here.
    for folder in ('diagnostics-L', 'review-C'):
        for path in STUDY.joinpath(folder).rglob('*'):
            if path.is_file() and path.suffix in ('.py', '.json', '.patch'):
                if path.name not in ('acquisition-inputs-v1.json', 'evaluation-inputs-v1.json'):
                    paths.add(path)
    relatives = [
        'root/protocol-v1.json', 'root/materialize_plans_v1.py', 'root/seal_acquisition_v1.py',
        'root/author_plan_composition_v1.py', 'root/fixed_family_worker_v2.py',
        'root/run_fixed_family_once_v1.py', 'root/observe_fixed_family_once_v1.py',
        'root/inherited-raw-copies-v1.json', 'root/runtime-additions-raw-copy-v1.json',
        'root/custody-Source-composition-v1.json', 'root/continuation-contract-v1.json',
        'root/worker-diagnostic-carrier-Source-v1.json', 'root/passive-sealer-Source-lineage-v1.json',
        'root/plan-materializer-Source-lineage-v1.json',
        'implementation-B/handoff-v1.json', 'implementation-B/manifest-v1.json',
    ]
    paths.update(STUDY/p for p in relatives)
    paths.add(Path(helper_handoff).resolve())
    paths.add(REPO/'docs/basic-tiling-algorithm.md')
    paths.add(REPO/'research-runs/gcts-batch-20261020/publisher/docs/basic-tiling-algorithm.md')
    paths.add(Path(previous['python']['path']))
    paths.update(Path(v) for v in previous['native'].values())
    paths.add(Path(previous['native']['executable_path']).with_name('boundary_oracle.cpp'))
    forbidden = {
        str((STUDY/'diagnostics-L/acquisition-inputs-v1.json').resolve()),
        str((STUDY/'diagnostics-L/evaluation-inputs-v1.json').resolve()),
    }
    if any(str(p.resolve()) in forbidden or '.partial' in p.name for p in paths):
        raise ValueError('phase input or partial in common Source closure')
    common = [pin(p) for p in sorted(paths)]
    for name in ('inherited-raw-copies-v1.json', 'runtime-additions-raw-copy-v1.json'):
        for row in read(ROOT/name)['raw_copies']:
            if pin(row['copy']['path']) != row['copy'] or pin(row['source']['path']) != row['source']:
                raise ValueError('frozen full runtime copy/source changed')
''' + source[stop:]
    substitutions = {
        "PREVIOUS = REPO/'research-runs/gcts-principal-receptor-families-20261021'": "PREVIOUS = REPO/'research-runs/gcts-principal-family-search-20261021'",
        "experiment='D17-fixed-paired-principal-family-search-v1'": "experiment='D18-matched-family-controls-v1'",
        "modules=previous['modules']": "modules=api['roles']",
        "implementation-B/proof_search_pilot_v16.py": "implementation-B/proof_search_pilot_v17.py",
        "root/fixed_family_worker_v1.py": "root/fixed_family_worker_v2.py",
        "ROOT/'fixed_family_worker_v1.py'": "ROOT/'fixed_family_worker_v2.py'",
        "Fresh D17 only.": "Fresh D18 only.",
        "stage_id+'-v2.json'": "stage_id+'-v1.json'",
        "plan-family-v2.json": "plan-family-v1.json",
        "D17-Root-plan-family-v2": "D18-Root-plan-family-v1",
        "acquire-0-v2.json": "acquire-0-v1.json",
        "D17-Root-whole-admission-v1": "D18-Root-whole-admission-v1",
        "fresh D17": "fresh D18",
        "row['stage_id']+'-v2.json'": "row['stage_id']+'-v1.json'",
        "materialized-evaluation-plans-v2.json": "materialized-evaluation-plans-v1.json",
        "D17-eval-materialization-v1": "D18-eval-materialization-v1",
    }
    for before, after in substitutions.items():
        source = source.replace(before, after)
    # The structural predecessor is the unchanged D17 v2 plan, not a D18 plan.
    source = source.replace("previous = read(PREVIOUS/'root/plans/acquire-0-v1.json')",
                            "previous = read(PREVIOUS/'root/plans/acquire-0-v2.json')")
    target = ROOT/'materialize_plans_v1.py'
    ast.parse(source, filename=str(target))
    compile(source, str(target), 'exec')
    with target.open('x') as stream:
        stream.write(source)
    write(ROOT/'plan-materializer-Source-lineage-v1.json', dict(
        schema='D18-Root-plan-materializer-Source-lineage-v1', predecessor=pin(predecessor),
        successor=pin(target), author=pin(__file__), scientific_calls=0,
        delta=['D18 labels/files and44 runtime Source modules',
               'B frozen roles select batched guard compiler; worker v2 ordinary diagnostic ledger',
               'Current phase-separated Source closure and helper/peer reviews',
               'Same complete acquisition admission/seal and sixteen nonexecutable evaluation templates',
               'All inherited global/time/resource/proof limits unchanged'],
        status='SOURCE_ONLY_PENDING_INDEPENDENT_REVIEW_NO_GRANT'))
    print(json.dumps(dict(protocol=pin(ROOT/'protocol-v1.json'), materializer=pin(target),
                          runtime=pin(ROOT/'runtime-additions-raw-copy-v1.json'))))


if __name__ == '__main__':
    main()
