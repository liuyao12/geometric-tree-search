"""Root passive exact-result admission after independent complete actual review."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]


def pin(path):
    path = Path(path).resolve()
    assert '.partial' not in path.name
    body = path.read_bytes()
    return dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def read(path):
    path = Path(path)
    assert '.partial' not in path.name
    return json.loads(path.read_bytes())


def write(path, value):
    body = (json.dumps(value, indent=2, sort_keys=True, allow_nan=False)+'\n').encode()
    path = Path(path)
    if path.exists():
        assert path.read_bytes() == body, 'existing admission must be byte-identical'
        return
    with path.open('xb') as stream:
        stream.write(body)


def main():
    review_path = ROOT/'review-C/typed-matched-family-final16-evaluation-actual-review-v1.json'
    review_pin = pin(review_path)
    assert review_pin['bytes'] == 560330
    assert review_pin['sha256'] == '21b54893c275a1c39bd1627ff33ea515b46e1c1114c2faac5324f6ccdf8a42c0'
    review = read(review_path)
    assert review['review_passed'] is True and review['failed_checks'] == []
    assert len(review['checks']) == 14 and all(c['passed'] is True for c in review['checks'])
    assert review['scientific_calls'] == review['scientific_imports'] == review['offered_helper_calls'] == 0
    assert review['scientific_replay'] is False
    assert type(review['partial_files_parsed']) is int and review['partial_files_parsed'] == 0
    assert review['admission_or_seal_emitted'] is False
    assert review['whole_study_complete'] is False
    for row in review['exact_input_pins']:
        assert pin(row['path']) == row
    manifest = read(ROOT/'root/materialized-evaluation-plans-v1.json')
    assert [c['plan'] for c in review['cases']] == manifest['plans']
    admitted = accepted = unknown = unavailable = 0
    receipts = []
    for case in review['cases']:
        for row in case['complete_file_census']:
            assert pin(row['path']) == row
        stage_id = case['stage_id']
        target = ROOT/('root/admission/'+stage_id+'-v1.json')
        flags = {k: case[k] for k in ('resource_admitted','scientific_qualified','stage_complete','admitted')}
        assert all(type(value) is bool for value in flags.values())
        header = read(case['header']['path'])
        terminal = read(case['terminal']['path'])
        observer = read(case['observer']['path'])
        assert terminal['threads_terminal'] is True
        assert header['native_closed_and_reaped'] is True
        assert observer['parent_exit_code'] == terminal['process_exit_code']
        if flags['admitted']:
            assert all(flags.values())
            assert observer['resource_candidate_accepted'] is True
            assert terminal['header_valid'] is True
            assert header['first_Root_fault'] is False
            assert case['failure'] is None and case['result'] is not None
            result = read(case['result']['path'])
            science = result['scientific_result']
            assert result['status'] == 'COMPLETE' and result['error'] is None
            assert science['stage_complete'] is True and science['all_six_searched'] is True
            arms = science['records'][0]['arms']
            assert [a['id'] for a in arms] == case['method_order']
            for arm, checked in zip(arms, case['arms']):
                status = arm['proof_check']['status']
                assert status == checked['proof_status']
                if checked['proof_accepted']:
                    assert status == 'HOST_REGION_NATIVE_ACCEPTED'
                    assert arm['proof_check']['host_check']['accepted'] is True
                    assert arm['proof_check']['native_proof_accepted'] is True
                    assert arm['proof_check']['native_record']['request']['blocks'] == []
                    accepted += 1
                else:
                    assert status == 'NO_PROOF_CANDIDATE'
                    assert arm['search']['status'] == 'unknown_search_budget'
                    unknown += 1
            admitted += 1
        else:
            assert not any(flags.values())
            assert case['result'] is None and case['failure'] is not None
            failure = read(case['failure']['path'])
            assert failure['scientific_result'] is None
            assert failure['error']['type'] == 'RootBudget'
            assert failure['error']['message'] == 'absolute case work deadline'
            assert observer['resource_candidate_accepted'] is False
            assert len(case['arms']) == 6
            assert [a['id'] for a in case['arms']] == case['method_order']
            assert all(a['search_returned'] is False and a['proof_accepted'] is None
                       and a['resource_admitted'] is False and a['scientific_qualified'] is False
                       and a['status'] == 'UNAVAILABLE_WHOLE_JOB_WORK_FAILURE'
                       for a in case['arms'])
            unavailable += 6
        receipt = dict(schema='D18-Root-whole-admission-v1',
                       stage_id=stage_id, stage='evaluate', **flags,
                       plan=case['plan'], result=case['result'],
                       header=case['header'],
                       terminal=case['terminal'], observer=case['observer'],
                       C_review=review_pin,
                       whole_seconds=case['observer_elapsed_ledger_sample'],
                       whole_peak_bytes=case['whole_peak_bytes'],
                       scope='Root per-case custody admission after independent complete actual review and exact current pin joins. UNKNOWN is a completed bounded search, never an impossibility proof. Whole-job failure has null result authority, with complete compiler ledgers diagnostic only. No scientific replay, new inference rule or prior-artifact adoption.')
        if case['failure'] is not None:
            receipt['failure'] = case['failure']
        write(target, receipt)
        receipts.append(pin(target))
    assert (admitted, accepted, unknown, unavailable) == (14, 74, 10, 12)
    summary = dict(qualified_jobs=admitted, failed_jobs=2, planned_slots=96,
                   returned_searches=84, accepted_proof_occurrences=accepted,
                   bounded_search_UNKNOWN=unknown, unavailable_whole_job_slots=unavailable)
    write(ROOT/'root/evaluation16-admissions-v1.json', dict(
        schema='D18-Root-evaluation16-admission-index-v1', C_review=review_pin,
        admissions=receipts, summary=summary, whole_study_complete=False,
        scientific_calls=0, partial_files_parsed=False,
        scope='Per-case admission only. Full research program and complete-cohort success remain unachieved; all sixteen attempts and ninety-six slots are retained.'))
    print(json.dumps(summary))


if __name__ == '__main__':
    main()
