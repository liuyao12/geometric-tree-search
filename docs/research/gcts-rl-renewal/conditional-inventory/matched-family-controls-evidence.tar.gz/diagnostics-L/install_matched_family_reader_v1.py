"""Prospective literal D18 website copy/insertion; explicit Root decision only.

Publication guard, not a proof/resource checker or an autonomous approval.
No science, Git, network, primary reader/index or .gcts-active access.
"""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT.parents[1]
DEST = REPO/'research-runs/gcts-batch-20261020/publisher/docs/research/gcts-rl-renewal/conditional-inventory'
TARGET = DEST/'reader.html'
OUT = ROOT/'publication'
BEFORE_BYTES = 119355
BEFORE_SHA = '215b507f180e02cd831f08e9d38808109066d7a262e6ddc5e237c86ea36587bf'
NAMES = ('matched-family-controls.html','matched-family-controls-data.json',
         'matched-family-controls-evidence.tar.gz','matched-family-controls-manifest.json')
GATES = ('admitted','resource_admitted','scientific_qualified','stage_complete')
PROTOCOL_SHA = '1de5f53f61145c7b6d8448230d713bbc802fb8d71c3654c416effe6990345409'


def pin(path):
    path=Path(path).resolve();digest=hashlib.sha256();count=0
    with path.open('rb') as stream:
        while True:
            body=stream.read(1048576)
            if not body:break
            count+=len(body);digest.update(body)
    return dict(path=str(path),bytes=count,sha256=digest.hexdigest())


def complete(path):
    path=Path(path)
    assert '.partial' not in str(path) and not path.is_symlink()
    return json.loads(path.read_bytes())


def admission(identity,display):
    path=ROOT/'root/admission'/(identity+'-v1.json')
    if not path.exists():
        assert display['receipt'] is None and display['admitted'] is False
        assert display['status']=='PENDING_ADMISSION'
        return False,None
    row=complete(path)
    assert row['schema']=='D18-Root-whole-admission-v1' and row['stage_id']==identity
    assert all(type(row[k]) is bool for k in GATES)
    for name in ('plan','header','terminal','observer','C_review'):
        assert pin(row[name]['path'])==row[name]
    gates=all(row[k] is True for k in GATES)
    assert display['status']==('WHOLE_ADMITTED' if gates else 'NOT_WHOLE_ADMITTED')
    assert display['admitted'] is gates
    for name in GATES[1:]:assert display[name] is row[name]
    receipt=display['receipt']
    assert receipt['pin']==pin(path) and receipt['plan']==row['plan'] and receipt['result']==row['result']
    assert receipt['C_review']==row['C_review']
    if gates:
        result=ROOT/'actual'/identity/'result.json'
        assert row['result']==pin(result)
    elif row['result'] is not None:
        assert pin(row['result']['path'])==row['result']
    if 'failure' in row:assert pin(row['failure']['path'])==row['failure']
    return gates,pin(path)


def copy_exact(source,destination,expected):
    assert not source.is_symlink() and pin(source)==expected
    target_pin=dict(expected,path=str(destination.resolve()))
    if destination.exists():
        assert not destination.is_symlink() and pin(destination)==target_pin
    else:
        # Exclusive new name; an interrupted copy is never a completed receipt.
        # No .partial is renamed, repaired, parsed or admitted.
        with source.open('rb') as reader,destination.open('xb') as writer:
            while True:
                block=reader.read(1048576)
                if not block:break
                writer.write(block)
    assert pin(destination)==target_pin
    return target_pin


def main():
    assert DEST.is_dir() and not TARGET.is_symlink()
    receipt_path=ROOT/'root/matched-reader-installation-v1.json'
    assert not receipt_path.exists()
    before=TARGET.read_bytes()
    assert len(before)==BEFORE_BYTES and hashlib.sha256(before).hexdigest()==BEFORE_SHA
    preimage=ROOT/'root/matched-parent-reader-before-v1.html'
    assert preimage.is_file() and not preimage.is_symlink() and preimage.read_bytes()==before
    protocol_path=ROOT/'diagnostics-L/protocol-proposal-v1.json'
    assert pin(protocol_path)['sha256']==PROTOCOL_SHA
    protocol=complete(protocol_path);expected={}
    for job in protocol['job_recipes']:
        if job['stage']=='evaluate':
            for position,method in enumerate(job['arm_order']):
                key=(job['stage_id'],method)
                assert key not in expected
                expected[key]=(job['case_id'],job['seed'],position+1)
    assert len(expected)==96
    data=complete(OUT/'matched-family-controls-data.json')
    assert len(data['slots'])==96
    found=set();admissions={};counts=dict(planned=96,returned=0,admitted_proofs=0,unreturned=0)
    for slot in data['slots']:
        key=(slot['stage_id'],slot['method'])
        assert key in expected and key not in found;found.add(key)
        assert (slot['case_id'],slot['seed'],slot['order_position'])==expected[key]
        assert type(slot['returned']) is bool and type(slot['admitted_proof']) is bool
        admitted,receipt=admission(slot['stage_id'],slot['admission'])
        if receipt is not None:admissions[slot['stage_id']]=receipt
        if slot['admitted_proof']:
            assert admitted and slot['returned'] and slot['native_proof_observed'] is True
            assert slot['proof_status']=='HOST_REGION_NATIVE_ACCEPTED'
        if not slot['returned']:
            assert slot['admitted_proof'] is False and slot['search_status'] is None
            assert slot['proof_status'] is None
            counts['unreturned']+=1
        else:counts['returned']+=1
        counts['admitted_proofs']+=slot['admitted_proof']
    assert found==set(expected)
    acq_gate,acq_receipt=admission('acquire-0',data['acquisition']['admission'])
    if acq_receipt is not None:admissions['acquire-0']=acq_receipt
    assert data['acquisition']['evaluation_gate'] is acq_gate
    # No forecast of17executions, successes, UNKNOWN or not-dispatched counts.
    # Root's final independent publication decision remains outside this guard.
    manifest_path=OUT/'matched-family-controls-manifest.json';manifest=complete(manifest_path)
    assert manifest['schema']=='D18-complete-raw-evidence-snapshot-v1'
    assert manifest['all_members_raw_verified'] is True and manifest['partial_files_parsed'] is False
    rows={row['archive_path']:row for row in manifest['files']}
    assert len(rows)==len(manifest['files'])
    sources={}
    for name in NAMES:
        source=OUT/name;actual=pin(source)
        if name.endswith('-manifest.json'):expected_pin=actual
        elif name.endswith('-evidence.tar.gz'):expected_pin=manifest['archive']
        else:
            row=rows['publication/'+name]
            expected_pin={k:row[k] for k in ('path','bytes','sha256')}
        assert actual==expected_pin;sources[name]=actual
    section_path=ROOT/'diagnostics-L/matched-family-reader-section-v1.html'
    section=section_path.read_bytes().rstrip(b'\n')+b'\n'
    anchor=b'<section id="principal-family-search-update"'
    assert before.count(anchor)==1 and b'id="matched-family-controls-update"' not in before
    after=before.replace(anchor,section+anchor,1)
    assert after.replace(section,b'',1)==before
    copied={name:copy_exact(OUT/name,DEST/name,sources[name]) for name in NAMES}
    # The only overwrite in the Publisher is this exact literal known reader.
    TARGET.write_bytes(after)
    assert TARGET.read_bytes()==after
    receipt=dict(schema='D18-single-reader-prefix-installation-v1',
        before=dict(bytes=len(before),sha256=hashlib.sha256(before).hexdigest()),
        preimage=pin(preimage),section=pin(section_path),after=pin(TARGET),copied=copied,
        exact_inverse_matches_previous_reader=True,display_counts=counts,admissions=admissions,
        scope='Explicit Root-invoked publication guard and raw copy only, not independent scientific admission. Public writes are exactly four task prefix files and one literal allowed conditional-reader insertion. All previous119355 reader bytes preserved. No primary reader/index/.gcts-active, Git, network, science or partial decoding. Later live verification separate.')
    with receipt_path.open('x') as stream:json.dump(receipt,stream,indent=2,sort_keys=True);stream.write('\n')
    print(json.dumps(receipt))


if __name__=='__main__':main()
