"""Prospective literal D18 website copy/insertion v2; Root decision only.

Publication guard, not a proof/resource checker or an autonomous approval.
No science, Git, network, primary reader/index or .gcts-active access.
"""
from pathlib import Path
import copy
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT.parents[1]
DEST = REPO/'research-runs/gcts-batch-20261020/publisher/docs/research/gcts-rl-renewal/conditional-inventory'
TARGET = DEST/'reader.html'
OUT = ROOT/'publication'
BEFORE_BYTES = 119355
BEFORE_SHA = '215b507f180e02cd831f08e9d38808109066d7a262e6ddc5e237c86ea36587bf'
NAMES = ('matched-family-controls.html','matched-family-controls-data.json',
         'matched-family-controls-evidence.tar.gz','matched-family-controls-manifest.json')
GATES = ('admitted','resource_admitted','scientific_qualified','stage_complete')
PROTOCOL_SHA = '1de5f53f61145c7b6d8448230d713bbc802fb8d71c3654c416effe6990345409'
INPUTS = {
    'acquire': ('acquisition-inputs-v1.json', '8b1f4cd3e5f54d4e15869febe6b566f7bae9adddd463d2e531c431951ffb1d16'),
    'evaluate': ('evaluation-inputs-v1.json', 'df554ba25b1684ef116191bf547566c7a55e920afb514c3bb4d5f58f1c138c40')}
METHODS = ('S0','SP','Pbase','PM','PL','PML')


def same(left,right):
    """Full literal JSON equality, including bool/int and list/container types."""
    if type(left) is not type(right):return False
    if type(left) is dict:
        return set(left)==set(right) and all(same(left[k],right[k]) for k in left)
    if type(left) is list:
        return len(left)==len(right) and all(same(a,b) for a,b in zip(left,right))
    if type(left) is float:return left.hex()==right.hex()
    assert left is None or type(left) in (str,int,bool)
    return left==right


def pin(path):
    path=Path(path).resolve();digest=hashlib.sha256();count=0
    with path.open('rb') as stream:
        while True:
            body=stream.read(1048576)
            if not body:break
            count+=len(body);digest.update(body)
    return dict(path=str(path),bytes=count,sha256=digest.hexdigest())


def complete(path):
    path=Path(path)
    assert '.partial' not in str(path) and not path.is_symlink()
    return json.loads(path.read_bytes())


def digest(value):
    body=json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode('utf8')
    return hashlib.sha256(body).hexdigest()


def admission(identity,display):
    path=ROOT/'root/admission'/(identity+'-v1.json')
    if not path.exists():
        assert display['receipt'] is None and display['admitted'] is False
        assert display['status']=='PENDING_ADMISSION'
        assert all(display[k] is None for k in GATES[1:])
        return False,None,None
    row=complete(path)
    assert row['schema']=='D18-Root-whole-admission-v1' and row['stage_id']==identity
    assert all(type(row[k]) is bool for k in GATES)
    for name in ('plan','header','terminal','observer','C_review'):
        assert pin(row[name]['path'])==row[name]
    gates=all(row[k] is True for k in GATES)
    assert display['status']==('WHOLE_ADMITTED' if gates else 'NOT_WHOLE_ADMITTED')
    assert display['admitted'] is gates
    for name in GATES[1:]:assert display[name] is row[name]
    receipt=display['receipt']
    assert receipt['pin']==pin(path) and receipt['plan']==row['plan'] and receipt['result']==row['result']
    assert receipt['C_review']==row['C_review']
    if gates:
        result=ROOT/'actual'/identity/'result.json'
        assert row['result']==pin(result)
    elif row['result'] is not None:
        assert pin(row['result']['path'])==row['result']
    if 'failure' in row:assert pin(row['failure']['path'])==row['failure']
    return gates,pin(path),row


def load_job(identity,stage,document,display,protocol):
    """Read one complete current carrier, never a partial or a lost-state repair."""
    admitted,receipt,row=admission(identity,display)
    directory=ROOT/'actual'/identity
    paths=[p for p in (directory/'result.json',directory/'failure.json') if p.is_file()]
    assert len(paths)<=1
    path=paths[0] if paths else None
    worker=complete(path) if path is not None else None
    science=None if worker is None else worker.get('scientific_result')
    plan_path=ROOT/'root/plans'/(identity+'-v1.json')
    plan=None
    if row is not None or worker is not None:
        assert plan_path.is_file() and not plan_path.is_symlink()
        if row is not None:assert same(row['plan'],pin(plan_path)) and row['stage']==stage
        plan=complete(plan_path)
        assert plan['schema']=='proof-search-case-once-plan-v1'
        assert plan['experiment']=='D18-matched-family-controls-v1'
        assert plan['case_id']==identity and plan['stage']==stage
        assert Path(plan['actual_dir']).resolve()==directory.resolve()
        input_path=ROOT/'diagnostics-L'/INPUTS[stage][0]
        assert Path(plan['input_path']).resolve()==input_path.resolve()
        assert any(same(p,pin(input_path)) for p in plan['files'])
        assert same(plan['experiment_limits'],protocol['experiment_limits'])
    if worker is not None:
        assert worker['schema']=='proof-search-case-worker-v1'
        assert worker['case_id']==identity and worker['stage']==stage
        if row is not None:
            if path.name=='result.json':assert same(row['result'],pin(path))
            elif row.get('failure') is not None:assert same(row['failure'],pin(path))
        if science is not None:
            assert type(science) is dict and science['stage']==stage and science['stage_id']==identity
            assert same(science['inputs'],document) and same(science['limits'],protocol['experiment_limits'])
        if admitted:
            assert path.name=='result.json' and worker['status']=='COMPLETE' and worker['error'] is None
            assert worker['source_unchanged'] is True and worker['first_Root_fault'] is False
            assert science is not None and science['stage_complete'] is True and science['job_record_complete'] is True
    else:assert not admitted
    return dict(identity=identity,stage=stage,worker=worker,science=science,plan=plan,
                admitted=admitted,receipt=receipt,admission_row=row,path=path)


def final_observation(current,spec,search,checks):
    """Literal saved gate/current-query join; no Host, region or Native replay."""
    assert type(checks['native_proof_accepted']) is bool
    assert type(checks['native_limit']) is int and checks['native_limit']==1000000000
    proof=search['proof']
    if proof is None:
        assert checks['status']=='NO_PROOF_CANDIDATE' and checks['native_proof_accepted'] is False
        assert checks['host_check'] is checks['region'] is checks['native_record'] is None
        return False
    assert type(proof) is list and proof and all(type(c) is dict and c['rule'] not in ('block','assumption') for c in proof)
    assert same(proof[-1]['formula'],spec['target'])
    placements=search['placements']
    assert type(placements) is list and len(placements)==2*len(proof)
    host=checks['host_check'];region=checks['region'];query=checks['native_record']
    assert host['accepted'] is True and type(host['rows']) is int and host['rows']==len(proof)
    assert same(host['target'],spec['target']) and region['complete'] is True
    assert type(region['decoded_rows']) is int and region['decoded_rows']==len(proof)
    assert type(region['selected_placements']) is int and region['selected_placements']==len(placements)
    worker=current['worker'];science=current['science']
    assert worker is not None and science is not None
    queries=worker['native_queries']; stages=worker['native_transport']['request_stages']
    assert type(query['id']) is int and 0<=query['id']<len(queries)
    index=query['id'];assert same(query,queries[index]) and same(query,science['native_records'][index])
    stage=stages[index]
    assert type(stage['ordinal']) is type(stage['record_id']) is int
    assert stage['ordinal']==stage['record_id']==index and stage['stage']=='COMPLETED'
    assert type(stage['limit']) is int and stage['limit']==checks['native_limit']
    for field in ('purpose','request_sha256','input_sha256','output_sha256'):
        assert same(query[field],stage[field])
    request=dict(protocol='gcts-fol-1',theory=spec['theory'],blocks=[],proof=proof,target=spec['target'])
    assert same(query['request'],request) and query['request_sha256']==digest(request)
    assert query['query_target']=='fixed_assertion'
    accepted=query['result']['status']=='accepted'
    assert query['result']['status'] in ('accepted','unknown_step_budget','unknown_space_budget')
    assert checks['native_proof_accepted'] is accepted
    assert checks['status']==('HOST_REGION_NATIVE_ACCEPTED' if accepted else 'HOST_REGION_ACCEPTED_NATIVE_UNKNOWN')
    return accepted


def join_view(data,used,index,current,case,search,checks,method,source,accepted):
    """Bind each displayed proof body/source and selected card to saved literals."""
    assert type(index) is int and 0<=index<len(data['proofs']) and index not in used
    used.add(index);view=data['proofs'][index];proof=search['proof'];model=case['model']
    for field,expected in (('spec',case['spec']),('target',case['spec']['target']),('proof',proof),
                           ('method',method),('proof_check',checks),('source',source)):
        assert same(view[field],expected)
    whole=current['admitted'] and accepted
    assert view['admitted_proof'] is whole
    assert view['scope']==('WHOLE-ADMITTED PRIMITIVE PROOF' if whole else
        'SAVED CANDIDATE / DIAGNOSTIC OBSERVATION; NOT AN ADMITTED TARGET PROOF')
    assert type(model['word_terminator']) is int and model['word_terminator']==256
    assert type(view['word_terminator']) is int and view['word_terminator']==256
    lookup={tuple(t['key']):t for t in model['placements']}
    assert len(lookup)==len(model['placements'])
    auxiliary=[]
    if method in ('PM','PML'):
        for certificate in case['marking']['markings']['certificates']:
            row=dict(certificate['auxiliary'],certificate_id=certificate['id'],
                     exhausted_root=certificate['exhausted_root'],support_witness_count=len(certificate['all_candidates']))
            auxiliary.append(row)
    overlay={}
    for row in auxiliary:overlay.setdefault(tuple(row['placement']),[]).append([row['point'],row['placement_value']])
    fixed=[dict(point=a['point'],value=a['initial_value'],excluded_placement=a['placement'],
                excluded_placement_value=a['placement_value'],certificate_id=a['certificate_id'],
                exhausted_root=a['exhausted_root'],support_witness_count=a['support_witness_count']) for a in auxiliary]
    assert same(view['fixed_auxiliary_initial'],fixed)
    tiles=[];word_ids=set();selected=set()
    for key in search['placements']:
        assert type(key) is list and len(key)==4 and all(type(x) is int for x in key)
        k=tuple(key);assert k in lookup and k not in selected;selected.add(k)
        tile=copy.deepcopy(lookup[k]);slot,choice=tile['command_reference']
        assert type(slot) is type(choice) is int and 0<=slot<len(proof)
        assert same(model['domains'][slot][choice],proof[slot])
        tile['auxiliary_overlay']=overlay.get(k,[])
        if tile['auxiliary_overlay']:
            by_point={tuple(p):v for p,v in tile['marks']}
            for point,value in tile['auxiliary_overlay']:
                assert tuple(point) not in by_point or same(by_point[tuple(point)],value)
                by_point[tuple(point)]=value
            tile['marks']=[[list(p),v] for p,v in sorted(by_point.items())]
        for point,value in tile['marks']:
            if point[1]==100:
                assert type(value) is int and 0<=value<len(model['word_dictionary'])
                word_ids.add(value)
        tiles.append(tile)
    assert same(view['tiles'],tiles) and set(view['words'])=={str(i) for i in word_ids}
    for identifier in word_ids:
        literal=model['word_dictionary'][identifier];word=view['words'][str(identifier)]
        assert word['hex']==literal
        assert same(word['literal'],json.loads(bytes.fromhex(literal).decode('utf8')))


def join_slots(data,protocol,documents):
    """Full96slot carrier check, independent of displayed self-asserted flags."""
    assert same(data['corpus']['acquisition'],documents['acquire'])
    assert same(data['corpus']['evaluation'],documents['evaluate'])
    assert same(data['corpus']['pins'],[pin(ROOT/'diagnostics-L'/INPUTS[s][0]) for s in ('acquire','evaluate')])
    slots=data['slots'];assert type(slots) is list and len(slots)==96
    by_key={};views_used=set();admissions={}
    for slot in slots:
        k=(slot['stage_id'],slot['method']);assert k not in by_key;by_key[k]=slot
    acquire=load_job('acquire-0','acquire',documents['acquire'],data['acquisition']['admission'],protocol)
    if acquire['receipt'] is not None:admissions['acquire-0']=acquire['receipt']
    gate=acquire['admitted'] and acquire['science'] is not None and acquire['science']['stage_complete'] is True
    assert data['acquisition']['executed'] is (acquire['worker'] is not None)
    assert data['acquisition']['evaluation_gate'] is gate
    donor_records=[] if acquire['science'] is None else acquire['science'].get('records',[])
    assert len(donor_records)<=len(documents['acquire']['donors'])
    for index,case in enumerate(donor_records):
        assert same(case['spec'],documents['acquire']['donors'][index])
        search=case['search'];checks=case['proof_check']
        accepted=final_observation(acquire,case['spec'],search,checks)
        if search['proof'] is not None:
            matches=[i for i,v in enumerate(data['proofs']) if same(v['source'],
                dict(stage_id='acquire-0',path='scientific_result.records[%d]'%index))]
            assert len(matches)==1
            join_view(data,views_used,matches[0],acquire,case,search,checks,'DONOR',
                dict(stage_id='acquire-0',path='scientific_result.records[%d]'%index),accepted)
    expected=set();counts=dict(planned=96,returned=0,admitted_proofs=0,unreturned=0)
    specs={s['id']:s for s in documents['evaluate']['evaluation']}
    assert len(specs)==8
    for recipe in protocol['job_recipes']:
        if recipe['stage']!='evaluate':continue
        identity=recipe['stage_id'];spec=specs[recipe['case_id']];seed=recipe['seed'];order=recipe['arm_order']
        assert type(seed) is int and seed in (0,1)
        assert identity=='eval-'+spec['id']+'-seed'+str(seed)
        assert same(order,documents['evaluate']['protocol']['arm_order'][spec['id']][str(seed)])
        assert len(order)==6 and set(order)==set(METHODS)
        display=by_key[(identity,order[0])]['admission']
        current=load_job(identity,'evaluate',documents['evaluate'],display,protocol)
        if current['receipt'] is not None:admissions[identity]=current['receipt']
        science=current['science'];case=None
        if science is not None:
            assert type(science['evaluation_seed']) is int and science['evaluation_seed']==seed
            records=science['records'];assert type(records) is list and len(records)<=1
            if records:
                case=records[0];assert same(case['spec'],spec)
        arms=[] if case is None else case.get('arms',[])
        assert type(arms) is list and len(arms)<=6
        assert same([a['id'] for a in arms],order[:len(arms)])
        if current['admitted']:assert len(arms)==6
        for position,method in enumerate(order):
            k=(identity,method);assert k in by_key and k not in expected;expected.add(k);slot=by_key[k]
            assert same(slot['admission'],display)
            for field,value in (('case_id',spec['id']),('title',spec['title']),('target',spec['target']),
                                ('seed',seed),('order_position',position+1)):
                assert same(slot[field],value)
            assert type(slot['returned']) is bool and type(slot['admitted_proof']) is bool
            for field,value in (('engine','symbolic' if method in ('S0','SP') else 'point'),
                                ('certified_markings',method in ('PM','PML')),('cluster_ordering',method in ('SP','PL','PML'))):
                assert same(slot[field],value)
            if position>=len(arms):
                assert slot['returned'] is slot['admitted_proof'] is False
                for field in ('search_status','proof_status','native_proof_observed','metrics','attempt_unit',
                              'search_seconds','full_arm_seconds','proof_view_index','domain_audits','trace_joins','shared_setup_seconds'):
                    assert slot[field] is None
                assert slot['execution_status'] in ('NOT_RUN_SHARED_SETUP_FAILED',
                    'NO_RETURNED_SEARCH_RECORD_JOB_FAILED_OR_INCOMPLETE','NOT_RUN_ACQUISITION_GATE','NOT_STARTED_PENDING')
                if current['worker'] is not None:assert slot['execution_status'] in (
                    'NOT_RUN_SHARED_SETUP_FAILED','NO_RETURNED_SEARCH_RECORD_JOB_FAILED_OR_INCOMPLETE')
                elif acquire['worker'] is not None and not gate:assert slot['execution_status']=='NOT_RUN_ACQUISITION_GATE'
                else:assert slot['execution_status']=='NOT_STARTED_PENDING'
                counts['unreturned']+=1;continue
            arm=arms[position];search=arm['search'];checks=arm['proof_check']
            assert slot['returned'] is True
            assert slot['execution_status']==(arm['execution_status'] if current['admitted'] else
                'RAW_'+arm['execution_status']+'_NOT_WHOLE_ADMITTED')
            for field,value in (('search_status',search['status']),('proof_status',checks['status']),
                                ('native_proof_observed',checks['native_proof_accepted']),('metrics',search['metrics']),
                                ('attempt_unit',search['attempt_unit']),('search_seconds',search['seconds']),
                                ('full_arm_seconds',arm['full_arm_seconds']),('domain_audits',len(search.get('domain_audits',[]))),
                                ('shared_setup_seconds',case['shared_setup_seconds'])):
                assert same(slot[field],value)
            accepted=final_observation(current,spec,search,checks)
            assert slot['admitted_proof'] is (current['admitted'] and accepted)
            if search['proof'] is None:assert slot['proof_view_index'] is None
            else:join_view(data,views_used,slot['proof_view_index'],current,case,search,checks,method,
                dict(stage_id=identity,path='scientific_result.records[0].arms[%d]'%position),accepted)
            counts['returned']+=1;counts['admitted_proofs']+=slot['admitted_proof']
    assert set(by_key)==expected and len(expected)==96 and views_used==set(range(len(data['proofs'])))
    summary={r['method']:r for r in data['method_summary']}
    assert len(summary)==len(data['method_summary'])==6 and set(summary)==set(METHODS)
    for method in METHODS:
        rows=[r for r in slots if r['method']==method];assert len(rows)==16
        values=dict(planned=16,returned=sum(r['returned'] for r in rows),
            whole_admitted_searches=sum(r['returned'] and r['admission']['admitted'] for r in rows),
            admitted_proofs=sum(r['admitted_proof'] for r in rows),
            raw_native_accepted=sum(r['native_proof_observed'] is True for r in rows),
            returned_search_unknown=sum(r['returned'] and r['search_status']=='unknown_search_budget' for r in rows),
            missing_returned_searches=sum(not r['returned'] for r in rows))
        for field,value in values.items():assert same(summary[method][field],value)
    return counts,admissions


def copy_exact(source,destination,expected):
    assert not source.is_symlink() and pin(source)==expected
    target_pin=dict(expected,path=str(destination.resolve()))
    if destination.exists():
        assert not destination.is_symlink() and pin(destination)==target_pin
    else:
        # Exclusive new name; an interrupted copy is never a completed receipt.
        # No .partial is renamed, repaired, parsed or admitted.
        with source.open('rb') as reader,destination.open('xb') as writer:
            while True:
                block=reader.read(1048576)
                if not block:break
                writer.write(block)
    assert pin(destination)==target_pin
    return target_pin


def main():
    if not __debug__:raise RuntimeError('literal publication guards require assertions enabled')
    assert DEST.is_dir() and not TARGET.is_symlink()
    receipt_path=ROOT/'root/matched-reader-installation-v2.json'
    assert not receipt_path.exists()
    before=TARGET.read_bytes()
    assert len(before)==BEFORE_BYTES and hashlib.sha256(before).hexdigest()==BEFORE_SHA
    preimage=ROOT/'root/matched-parent-reader-before-v1.html'
    assert preimage.is_file() and not preimage.is_symlink() and preimage.read_bytes()==before
    protocol_path=ROOT/'diagnostics-L/protocol-proposal-v1.json'
    assert pin(protocol_path)['sha256']==PROTOCOL_SHA
    protocol=complete(protocol_path);documents={}
    for stage,(name,sha) in INPUTS.items():
        path=ROOT/'diagnostics-L'/name
        assert pin(path)['sha256']==sha
        documents[stage]=complete(path)
    data=complete(OUT/'matched-family-controls-data.json')
    assert data['schema']=='D18-matched-family-controls-passive-reader-v1'
    counts,admissions=join_slots(data,protocol,documents)
    # No forecast of17executions, successes, UNKNOWN or not-dispatched counts.
    # Root's final independent publication decision remains outside this guard.
    manifest_path=OUT/'matched-family-controls-manifest.json';manifest=complete(manifest_path)
    assert manifest['schema']=='D18-complete-raw-evidence-snapshot-v1'
    assert manifest['all_members_raw_verified'] is True and manifest['partial_files_parsed'] is False
    rows={row['archive_path']:row for row in manifest['files']}
    assert len(rows)==len(manifest['files'])
    sources={}
    for name in NAMES:
        source=OUT/name;actual=pin(source)
        if name.endswith('-manifest.json'):expected_pin=actual
        elif name.endswith('-evidence.tar.gz'):expected_pin=manifest['archive']
        else:
            row=rows['publication/'+name]
            expected_pin={k:row[k] for k in ('path','bytes','sha256')}
        assert actual==expected_pin;sources[name]=actual
    section_path=ROOT/'diagnostics-L/matched-family-reader-section-v1.html'
    section=section_path.read_bytes().rstrip(b'\n')+b'\n'
    anchor=b'<section id="principal-family-search-update"'
    assert before.count(anchor)==1 and b'id="matched-family-controls-update"' not in before
    after=before.replace(anchor,section+anchor,1)
    assert after.replace(section,b'',1)==before
    copied={name:copy_exact(OUT/name,DEST/name,sources[name]) for name in NAMES}
    # The only overwrite in the Publisher is this exact literal known reader.
    TARGET.write_bytes(after)
    assert TARGET.read_bytes()==after
    receipt=dict(schema='D18-single-reader-prefix-installation-v2',
        before=dict(bytes=len(before),sha256=hashlib.sha256(before).hexdigest()),
        preimage=pin(preimage),section=pin(section_path),after=pin(TARGET),copied=copied,
        exact_inverse_matches_previous_reader=True,display_counts=counts,admissions=admissions,
        literal_complete_result_slot_and_proof_joins=True,
        scope='Explicit Root-invoked literal complete-result/display publication guard and raw copy only, not independent scientific admission. Every returned slot/proof source binds its saved current arm; admitted display proofs also require current Root four gates plus exact saved Host/fullregion/current Native request-stage acceptance. All96 planned slots remain, including missing/failed/UNKNOWN. Public writes are exactly four task prefix files and one literal allowed conditional-reader insertion. All previous119355 reader bytes preserved. No primary reader/index/.gcts-active, Git, network, scientific Source import, checker/Graph/State/Native replay or partial decoding. Narrative/trace scientific interpretation and later live verification remain separate Root/peer decisions.')
    with receipt_path.open('x') as stream:json.dump(receipt,stream,indent=2,sort_keys=True);stream.write('\n')
    print(json.dumps(receipt))


if __name__=='__main__':main()
