"""Prospective closed D18 raw archive; Root invocation after final review only.

No scientific imports/calls, extraction, Git, network or partial decoding.
Writes task-owned preimage/archive/manifest only, never the Publisher.
"""
from pathlib import Path, PurePosixPath
import gzip
import hashlib
import io
import json
import tarfile

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT.parents[1]
OUT = ROOT/'publication'
PARENT = REPO/'research-runs/gcts-batch-20261020/publisher/docs/research/gcts-rl-renewal/conditional-inventory/reader.html'
PARENT_BYTES = 119355
PARENT_SHA = '215b507f180e02cd831f08e9d38808109066d7a262e6ddc5e237c86ea36587bf'


def encoded(value):
    return (json.dumps(value,sort_keys=True,indent=2,ensure_ascii=True,allow_nan=False)+'\n').encode()


def pin(path):
    path=Path(path).resolve();digest=hashlib.sha256();count=0
    with path.open('rb') as stream:
        while True:
            body=stream.read(1048576)
            if not body:break
            count+=len(body);digest.update(body)
    return dict(path=str(path),bytes=count,sha256=digest.hexdigest())


def main():
    # This existing allowed conditional reader is a known public preimage, not
    # the primary research reader/index. Preserve it before collecting roots.
    assert OUT.is_dir() and not PARENT.is_symlink()
    parent=PARENT.read_bytes()
    assert len(parent)==PARENT_BYTES and hashlib.sha256(parent).hexdigest()==PARENT_SHA
    preimage=ROOT/'root/matched-parent-reader-before-v1.html'
    if preimage.exists():
        assert not preimage.is_symlink() and preimage.read_bytes()==parent
    else:
        with preimage.open('xb') as stream:stream.write(parent)
    paths={}
    for folder in ('root','runtime','implementation-B','diagnostics-L','review-C','actual'):
        for path in sorted((ROOT/folder).rglob('*')):
            if path.is_symlink():raise ValueError('no symbolic archive input')
            if path.is_file():paths[str(path.relative_to(ROOT))]=path
    for name in ('matched-family-controls-data.json','matched-family-controls.html'):
        path=OUT/name
        assert path.is_file() and not path.is_symlink()
        paths['publication/'+name]=path
    # Complete Root plans and retained templates are metadata. Nothing in an
    # actual, compiler catalog, Native program or partial body is interpreted.
    external={};interpreter=None;plan_paths=[]
    for path in sorted((ROOT/'root/plans').glob('*.json')):
        assert '.partial' not in path.name and not path.is_symlink()
        plan=json.loads(path.read_bytes())
        assert plan['schema'] in ('proof-search-case-once-plan-v1','proof-search-case-once-template-v1')
        assert plan['experiment']=='D18-matched-family-controls-v1'
        assert interpreter is None or interpreter==plan['python']
        interpreter=plan['python'];plan_paths.append(str(path))
        for row in plan['files']:
            assert pin(row['path'])=={k:row[k] for k in ('path','bytes','sha256')}
            source=Path(row['path'])
            if not source.is_relative_to(ROOT):external[str(source)]=row
    assert plan_paths and interpreter is not None
    omitted=[]
    for row in external.values():
        path=Path(row['path'])
        if row==interpreter:
            omitted.append(dict(**row,reason='Pinned isolated interpreter identity only; executable is not redistributed.'))
            continue
        assert path.is_relative_to(REPO) and not path.is_symlink()
        name='declared-dependencies/'+str(path.relative_to(REPO))
        assert name not in paths;paths[name]=path
    assert len(omitted)==1
    pairs=sorted(paths.items())
    for name,path in pairs:
        assert not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts
        assert not path.is_symlink()
    rows=[dict(archive_path=name,raw_partial_opaque=('.partial' in path.name),**pin(path)) for name,path in pairs]
    snapshot=dict(schema='D18-complete-raw-evidence-snapshot-v1',files=rows,omitted_runtime=omitted,
        plan_paths=plan_paths,raw_partial_files=sum(row['raw_partial_opaque'] for row in rows),
        partial_files_parsed=False,scientific_calls=0,
        scope='Closed task-owned Source/data/plans/templates/grants/complete actuals/failures/reviews/Root admissions and all exact declared plan dependencies, plus the passive display and exact previous allowed parent reader. Partials, if any, are opaque raw bytes only. Historical dependencies are provenance, never old result/library adoption. Later insertion/publication/live receipts remain outside this snapshot.')
    manifest_body=encoded(snapshot);archive=OUT/'matched-family-controls-evidence.tar.gz'
    with archive.open('xb') as target:
        with gzip.GzipFile(fileobj=target,mode='wb',filename='',mtime=0,compresslevel=9) as compressed:
            with tarfile.open(fileobj=compressed,mode='w') as tar:
                def add(name,body):
                    info=tarfile.TarInfo(name);info.size=len(body)
                    info.mtime=info.uid=info.gid=0;info.mode=0o644
                    tar.addfile(info,io.BytesIO(body))
                add('snapshot-manifest.json',manifest_body)
                for row,(name,path) in zip(rows,pairs):
                    body=path.read_bytes()
                    assert len(body)==row['bytes'] and hashlib.sha256(body).hexdigest()==row['sha256']
                    add(name,body)
    for row,(_,path) in zip(rows,pairs):
        assert pin(path)=={k:row[k] for k in ('path','bytes','sha256')}
    expected={'snapshot-manifest.json':(len(manifest_body),hashlib.sha256(manifest_body).hexdigest())}
    expected.update({row['archive_path']:(row['bytes'],row['sha256']) for row in rows})
    seen=set()
    with tarfile.open(archive,'r|gz') as tar:
        for member in tar:
            assert member.isfile() and member.name not in seen and member.name in expected
            seen.add(member.name);stream=tar.extractfile(member);digest=hashlib.sha256();count=0
            while True:
                body=stream.read(1048576)
                if not body:break
                count+=len(body);digest.update(body)
            assert (count,digest.hexdigest())==expected[member.name]
    assert seen==set(expected)
    final=dict(snapshot,archive=pin(archive),regular_files=len(expected),
        uncompressed_source_bytes=sum(row['bytes'] for row in rows),
        snapshot_manifest_bytes=len(manifest_body),snapshot_manifest_sha256=hashlib.sha256(manifest_body).hexdigest(),
        all_members_raw_verified=True)
    destination=OUT/'matched-family-controls-manifest.json'
    with destination.open('xb') as stream:stream.write(encoded(final))
    print(json.dumps(dict(archive=pin(archive),manifest=pin(destination),regular_files=len(expected),
                         raw_partial_files=snapshot['raw_partial_files'],scientific_calls=0)))


if __name__=='__main__':main()
