"""Prospective D18 zero-read Native guard acquisition; Root actual calls only.

The grammar/catalog/domains/Model are the unchanged inherited implementation.
Only the way literal guards acquire Native authority changes.  No command that
reads a proved row or opens an assumption is allowed in a batch.  A rejected
multirow request supplies no member rejection: it is split through singletons.
Any Native UNKNOWN or local request exhaustion leaves compilation incomplete.
"""
import hashlib
import json
import math
import time
import quantified_receptors_v1 as inherited

VERSION = inherited.VERSION
CATALOG_SCHEMA = inherited.CATALOG_SCHEMA
TERM_POLICY = inherited.TERM_POLICY
ROOT_CONTEXT = inherited.ROOT_CONTEXT
INSTANTIATION_ROUNDS = inherited.INSTANTIATION_ROUNDS
syntax = inherited.syntax
domains = inherited.domains
Model = inherited.Model
GUARD_ACQUISITION_VERSION = 'native-zero-read-guard-batches-v1'
RESOLUTION_SCHEMA = 'gcts-zero-read-guard-resolution-v1'
BATCH_ROWS = 4
MAX_NATIVE_STEPS = 1000000000
MAX_LOCAL_QUERIES = 512
NATIVE_STATUSES = ('accepted', 'rejected', 'unknown_step_budget', 'unknown_space_budget')
ZERO_READ_FIELDS = {
    'tautology': {'rule', 'formula'},
    'instantiate': {'rule', 'formula', 'universal', 'term'},
    'eq_subst': {'rule', 'formula', 'variable', 'template', 'left', 'right'},
}
RECORD_FIELDS = {'id', 'request', 'query_target', 'request_sha256', 'input_sha256',
                 'output_sha256', 'result', 'seconds', 'purpose'}
_OWNER = object()


class GuardAcquisitionError(ValueError):
    def __init__(self, message, owner=None):
        super().__init__(message)
        self.owner = owner


def is_owned_error(error):
    return type(error) is GuardAcquisitionError and error.owner is _OWNER


def need(value, message):
    if not value:
        raise GuardAcquisitionError(message, _OWNER)


def _literal(value, check):
    check()
    if type(value) is list:
        result = []
        for item in value:
            result.append(_literal(item, check))
        return result
    if type(value) is dict:
        result = {}
        for key, item in value.items():
            check(); need(type(key) is str, 'ordinary string key')
            result[key] = _literal(item, check)
        return result
    need(value is None or type(value) in (str, int, bool, float), 'ordinary literal evidence')
    need(type(value) is not float or math.isfinite(value), 'finite evidence scalar')
    return value


def _same(left, right, check):
    check()
    if type(left) is not type(right):
        return False
    if type(left) is list:
        if len(left) != len(right):
            return False
        for a, b in zip(left, right):
            if not _same(a, b, check):
                return False
        return True
    if type(left) is dict:
        if set(left) != set(right):
            return False
        for key in left:
            if not _same(left[key], right[key], check):
                return False
        return True
    return left == right


def _digest(value, check):
    body = json.dumps(_literal(value, check), sort_keys=True, separators=(',', ':'),
                      ensure_ascii=False, allow_nan=False).encode('utf-8')
    check()
    return hashlib.sha256(body).hexdigest()


def _limits(limit, queries, check):
    check()
    need(type(limit) is int and 0 < limit <= MAX_NATIVE_STEPS, 'fixed Native per-query step ceiling')
    need(type(queries) is int and 1 <= queries <= MAX_LOCAL_QUERIES, 'local query cap within unchanged global ceiling')


def _candidates(candidates, check):
    check(); need(type(candidates) is list, 'literal ordered candidate rows')
    copied = []
    for i, row in enumerate(candidates):
        check()
        need(type(row) is dict and set(row) == {'ordinal', 'purpose', 'command'}, 'exact candidate carrier')
        need(type(row['ordinal']) is int and row['ordinal'] == i, 'complete original ordinal sequence')
        c = row['command']
        need(type(c) is dict and type(c.get('rule')) is str and c['rule'] in ZERO_READ_FIELDS,
             'only the three zero-read Native rules')
        need(set(c) == ZERO_READ_FIELDS[c['rule']], 'exact zero-read fields; no row references/context')
        purpose = 'first_order_tautology' if c['rule'] == 'tautology' else 'first_order_scheme'
        need(type(row['purpose']) is str and row['purpose'] == purpose, 'original member purpose')
        copied.append(_literal(row, check))
    return copied


def candidate_rows(catalog, *, check):
    """Original singleton compiler order, with no outcome-based prefilter."""
    check(); rows = []
    for formula in catalog['basis']:
        check(); rows.append(dict(ordinal=len(rows), purpose='first_order_tautology',
                                 command=dict(rule='tautology', formula=_literal(formula, check))))
    for command in catalog['schemes']:
        check(); rows.append(dict(ordinal=len(rows), purpose='first_order_scheme',
                                 command=_literal(command, check)))
    return _candidates(rows, check)


def _request(theory, commands, check):
    check(); need(type(theory) is dict and type(commands) is list and commands, 'nonempty finite literal request')
    return dict(protocol='gcts-fol-1', theory=_literal(theory, check), blocks=[],
                proof=_literal(commands, check), target=_literal(commands[-1]['formula'], check))


def _record(record, request, purpose, check):
    check(); need(type(record) is dict and set(record) == RECORD_FIELDS, 'whole original Native record')
    need(type(record['id']) is int and record['id'] >= 0 and record['query_target'] == 'fixed_assertion',
         'current exact Native record identity')
    need(type(record['purpose']) is str and record['purpose'] == purpose
         and _same(record['request'], request, check), 'whole literal request/purpose binding')
    need(record['request_sha256'] == _digest(request, check), 'canonical full request digest')
    for field in ('input_sha256', 'output_sha256'):
        check(); value = record[field]
        need(type(value) is str and len(value) == 64 and all(c in '0123456789abcdef' for c in value),
             'complete Native byte-evidence digest')
    need(type(record['result']) is dict and type(record['result'].get('status')) is str
         and record['result']['status'] in NATIVE_STATUSES, 'declared Native outcome; no normalization')
    return _literal(record, check)


def resolve_zero_read(theory, candidates, oracle, limit=MAX_NATIVE_STEPS,
                      queries=MAX_LOCAL_QUERIES, *, check, progress=None):
    """Fixed chunk/split resolver; synthetic-control entry, never a proof kernel.

    The Root oracle independently enforces its GLOBAL starts and step ceilings.
    This local cap includes the theory seed and every rejected/internal batch.
    Callback/foreign/Root exceptions are never caught or normalized here.
    """
    check(); _limits(limit, queries, check); rows = _candidates(candidates, check)
    began = time.perf_counter(); original_theory = _literal(theory, check)
    members = []
    for row in rows:
        check(); members.append(dict(**row, status='unresolved', native_query=None,
                                     native_row=None, resolution_kind=None))
    result = dict(schema=RESOLUTION_SCHEMA, guard_acquisition_version=GUARD_ACQUISITION_VERSION,
                  status='unknown_compile_budget', complete=False, theory_query=None,
                  queries=[], query_records=[], batches=[], members=members,
                  resolved=0, unresolved=len(members), seconds=0.0, active_query=None,
                  limits=dict(batch_rows=BATCH_ROWS, native_steps=limit, queries=queries,
                              global_starts_authority='unchanged Root oracle, all calls charged'))
    if progress is not None:
        need(type(progress) is dict, 'ordinary live Root diagnostic ledger')
        progress.clear(); progress.update(result); result = progress
    def submit(commands, purpose):
        check()
        request = _request(original_theory, commands, check)
        result['active_query'] = dict(purpose=purpose, request=request, returned_record=None)
        q = oracle.request(request, limit, purpose)
        result['active_query']['returned_record'] = q
        check(); q = _record(q, request, purpose, check)
        need(q['id'] not in result['queries'], 'unique current query IDs')
        result['queries'].append(q['id']); result['query_records'].append(q)
        result['active_query'] = None
        return q
    seed = dict(rule='tautology', formula=['imp', ['bot'], ['bot']])
    q = submit([seed], 'first_order_theory_admission'); result['theory_query'] = q['id']
    if q['result']['status'] != 'accepted':
        result['status'] = 'unknown_or_rejected_theory'
    else:
        pending = []
        start = 0
        while start < len(rows):
            check(); stop = start+1
            if rows[start]['purpose'] == 'first_order_scheme':
                while stop < len(rows) and stop-start < BATCH_ROWS:
                    check()
                    if rows[stop]['purpose'] != 'first_order_scheme': break
                    stop += 1
            pending.append((start, stop, None)); start = stop
        pending.reverse()
        while pending:
            check()
            if len(result['queries']) >= queries:
                result['status'] = 'unknown_compile_budget'; break
            start, stop, parent = pending.pop(); commands = []
            for i in range(start, stop):
                check(); commands.append(rows[i]['command'])
            q = submit(commands, 'first_order_zero_read_batch'); status = q['result']['status']
            index = len(result['batches'])
            result['batches'].append(dict(index=index, parent=parent, start=start, stop=stop,
                query_id=q['id'], query_record_ordinal=len(result['query_records'])-1, status=status))
            if status == 'accepted':
                for local, i in enumerate(range(start, stop)):
                    check(); members[i].update(status='accepted', native_query=q['id'],
                        native_row=local, resolution_kind='accepted_zero_read_batch')
            elif status == 'rejected':
                if stop-start == 1:
                    members[start].update(status='rejected', native_query=q['id'],
                        native_row=0, resolution_kind='singleton_rejection')
                else:
                    middle = start+(stop-start)//2
                    pending.append((middle, stop, index)); pending.append((start, middle, index))
            else:
                result['status'] = 'unknown_native_compilation'; break
        else:
            result['status'] = 'complete'; result['complete'] = True
    for member in members:
        check()
        if member['status'] != 'unresolved': result['resolved'] += 1
    result['unresolved'] = len(members)-result['resolved']
    need(_same(theory, original_theory, check) and _same(candidates, rows, check), 'caller inputs unchanged')
    check(); result['seconds'] = time.perf_counter()-began
    return result


def compile_guards(spec, oracle, limit=MAX_NATIVE_STEPS, queries=MAX_LOCAL_QUERIES, *, check):
    check()
    need(type(getattr(oracle, 'guard_compilations', None)) is list, 'Root-owned live guard ledger list')
    live = dict(schema=RESOLUTION_SCHEMA, guard_acquisition_version=GUARD_ACQUISITION_VERSION,
                status='PREPARING_SYNTAX', complete=False, members=[], active_query=None)
    oracle.guard_compilations.append(live)
    _limits(limit, queries, check); began = time.perf_counter()
    catalog = syntax(spec); check()
    evidence = resolve_zero_read(spec['theory'], candidate_rows(catalog, check=check), oracle,
                                 limit=limit, queries=queries, check=check, progress=live)
    compiled = dict(status=evidence['status'], catalog=catalog, queries=list(evidence['queries']),
                    theory_query=evidence['theory_query'], seconds=time.perf_counter()-began,
                    guard_acquisition_version=GUARD_ACQUISITION_VERSION, guard_evidence=evidence)
    if evidence['complete']:
        tautologies = []; schemes = []
        for member in evidence['members']:
            check()
            if member['status'] == 'accepted':
                if member['purpose'] == 'first_order_tautology':
                    tautologies.append(_literal(member['command']['formula'], check))
                else: schemes.append(_literal(member['command'], check))
        compiled.update(basis=catalog['basis'], variables=catalog['variables'],
                        tautologies=tautologies, admitted_schemes=schemes)
    check(); compiled['seconds'] = time.perf_counter()-began
    return compiled


def verify_guard_evidence(spec, compiled, oracle_records, *, check):
    """Full literal/current-owner and deterministic resolution joins; no query.

    This verifies the batch licence carrier, not the Native implementation.
    Complete=False is preserved and never confers eligible-set/Model authority.
    """
    check(); catalog = syntax(spec); check()
    need(_same(compiled['catalog'], catalog, check), 'unchanged complete syntax catalog')
    rows = candidate_rows(catalog, check=check); e = compiled['guard_evidence']
    need(type(e) is dict and set(e) == {'schema','guard_acquisition_version','status','complete',
         'theory_query','queries','query_records','batches','members','resolved','unresolved','seconds','limits','active_query'},
         'whole exact resolution evidence carrier')
    need(e['schema'] == RESOLUTION_SCHEMA and e['guard_acquisition_version'] == GUARD_ACQUISITION_VERSION
         and compiled['guard_acquisition_version'] == GUARD_ACQUISITION_VERSION
         and e['active_query'] is None, 'separate acquisition identity and no incomplete active query adoption')
    cap = e['limits']; _limits(cap['native_steps'], cap['queries'], check)
    need(set(cap) == {'batch_rows','native_steps','queries','global_starts_authority'} and
         type(cap['batch_rows']) is int and cap['batch_rows'] == BATCH_ROWS and
         cap['global_starts_authority'] == 'unchanged Root oracle, all calls charged', 'fixed orchestration limits')
    need(type(oracle_records) is list and type(e['query_records']) is list
         and 1 <= len(e['query_records']) <= cap['queries'], 'nonempty bounded retained full query records')
    owners = {}
    for q in oracle_records:
        check(); need(type(q) is dict and type(q.get('id')) is int and q['id'] not in owners,
                      'unique actual owner record IDs')
        owners[q['id']] = q
    ids = []
    for q in e['query_records']:
        check(); need(type(q) is dict and type(q.get('id')) is int and q['id'] in owners
                      and _same(q, owners[q['id']], check), 'exact whole record in current owned stream')
        ids.append(q['id'])
    need(len(set(ids)) == len(ids) and _same(e['queries'], ids, check)
         and _same(compiled['queries'], ids, check), 'all and only local query IDs retained')
    seed = dict(rule='tautology', formula=['imp', ['bot'], ['bot']])
    first = _record(e['query_records'][0], _request(spec['theory'], [seed], check),
                    'first_order_theory_admission', check)
    need(type(e['theory_query']) is int and e['theory_query'] == first['id'] == compiled['theory_query'],
         'singleton theory seed retained first')
    expected = []
    for row in rows:
        check(); expected.append(dict(**row, status='unresolved', native_query=None,
                                      native_row=None, resolution_kind=None))
    query_cursor = 1; batch_cursor = 0; status = 'unknown_or_rejected_theory'
    if first['result']['status'] == 'accepted':
        todo = []
        start = 0
        while start < len(rows):
            check(); end = start+1
            if rows[start]['purpose'] == 'first_order_scheme':
                while end < min(start+BATCH_ROWS, len(rows)):
                    check()
                    if rows[end]['purpose'] != 'first_order_scheme': break
                    end += 1
            todo.append((start, end, None)); start = end
        todo.reverse(); status = 'complete'
        while todo:
            check()
            if query_cursor == cap['queries']:
                status = 'unknown_compile_budget'; break
            start, stop, parent = todo.pop()
            need(query_cursor < len(e['query_records']) and batch_cursor < len(e['batches']),
                 'no unexplained omitted eligible batch')
            commands = []
            for i in range(start, stop):
                check(); commands.append(rows[i]['command'])
            q = _record(e['query_records'][query_cursor], _request(spec['theory'], commands, check),
                        'first_order_zero_read_batch', check)
            outcome = q['result']['status']
            shape = dict(index=batch_cursor, parent=parent, start=start, stop=stop,
                query_id=q['id'], query_record_ordinal=query_cursor, status=outcome)
            need(_same(e['batches'][batch_cursor], shape, check), 'complete exact contiguous split trace')
            parent_index = batch_cursor; query_cursor += 1; batch_cursor += 1
            if outcome == 'accepted':
                for local, ordinal in enumerate(range(start, stop)):
                    check(); expected[ordinal].update(status='accepted', native_query=q['id'],
                        native_row=local, resolution_kind='accepted_zero_read_batch')
            elif outcome == 'rejected':
                if stop-start == 1:
                    expected[start].update(status='rejected', native_query=q['id'], native_row=0,
                                           resolution_kind='singleton_rejection')
                else:
                    middle = (start+stop)//2
                    todo.append((middle, stop, parent_index)); todo.append((start, middle, parent_index))
            else:
                status = 'unknown_native_compilation'; break
    need(query_cursor == len(e['query_records']) and batch_cursor == len(e['batches']),
         'no extra, adopted, hidden or post-UNKNOWN Native batch')
    complete = status == 'complete'; resolved = 0; tautologies = []; schemes = []
    for member in expected:
        check()
        if member['status'] != 'unresolved': resolved += 1
        if member['status'] == 'accepted':
            if member['purpose'] == 'first_order_tautology': tautologies.append(member['command']['formula'])
            else: schemes.append(member['command'])
    need(_same(e['members'], expected, check) and type(e['complete']) is bool and e['complete'] is complete
         and type(e['resolved']) is int and e['resolved'] == resolved and type(e['unresolved']) is int
         and e['unresolved'] == len(expected)-resolved and e['status'] == status and compiled['status'] == status,
         'every original candidate fully resolved or explicitly unresolved; no parent rejection laundering')
    if complete:
        need(_same(compiled['basis'], catalog['basis'], check) and
             _same(compiled['variables'], catalog['variables'], check) and
             _same(compiled['tautologies'], tautologies, check) and
             _same(compiled['admitted_schemes'], schemes, check), 'exact ordered admitted guard set')
    else:
        need(not any(k in compiled for k in ('basis','variables','tautologies','admitted_schemes')),
             'incomplete compilation has no usable eligible-set carrier')
    check()
    return dict(schema='D18-complete-guard-licence-join-v1', complete=complete, carrier_verified=True,
                guard_acquisition_version=GUARD_ACQUISITION_VERSION, status=status,
                original_members=len(rows), resolved=resolved, unresolved=len(rows)-resolved,
                accepted=len(tautologies)+len(schemes), rejected=resolved-len(tautologies)-len(schemes),
                native_queries=len(ids), theory_query=first['id'],
                scope='Exact current owned full Native batch/request/row joins. Accepted zero-read batches certify each literal member under the fixed checker; rejected multirow parents reject no member. UNKNOWN/budget leaves no usable guard set. No Native replay or stronger physical Wang/equivalence claim.')
