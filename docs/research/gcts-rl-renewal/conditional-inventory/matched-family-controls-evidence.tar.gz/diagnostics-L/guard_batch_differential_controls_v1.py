"""Two declared tiny old/batched compiler + full-model differentials.

Source only until a fresh reviewed acquisition actual.  The literals below are
diagnostic statements, not donor/evaluation proofs or a theorem-search route.
All Native calls, both compilers, both full tiny models and reference checks
are inside that actual's unchanged global clocks/start/memory/output limits.
"""
import copy
import time

FIXTURES = [
    dict(id='tiny-nontautological-basis', title='Rejected basis formula stays absent',
         theory=dict(functions={}, predicates={'P': 0}, axioms={'p': ['pred', 'P', []]}, schemas=[]),
         target=['pred', 'P', []], length=1, instantiation_rounds=2,
         scope='Synthetic complete-model differential, not a benchmark recipient.'),
    dict(id='tiny-UI-and-equality-licences', title='UI and EQ acquire the identical guard set',
         theory=dict(functions={'a': 0}, predicates={'P': 1}, axioms={
             'u': ['all', 'x', ['pred', 'P', [['var', 'x']]]],
             'e': ['eq', ['fun', 'a', []], ['fun', 'a', []]]}, schemas=[]),
         target=['pred', 'P', [['fun', 'a', []]]], length=2, instantiation_rounds=2,
         scope='Synthetic UI/EQ signature/catalog differential; no proof search or supplied proof.'),
]
CONTROL_IDS = ('tiny-nontautological-basis', 'tiny-UI-and-equality-licences')
_OWNER = object()


class DifferentialControlError(ValueError):
    def __init__(self, message, owner=None):
        super().__init__(message); self.owner = owner


def is_owned_error(error):
    return type(error) is DifferentialControlError and error.owner is _OWNER


def need(value, message):
    if not value: raise DifferentialControlError(message, _OWNER)


def _same(left, right, check):
    check()
    if type(left) is not type(right): return False
    if type(left) is list:
        if len(left) != len(right): return False
        for a, b in zip(left, right):
            if not _same(a, b, check): return False
        return True
    if type(left) is dict:
        if set(left) != set(right): return False
        for key in left:
            if not _same(left[key], right[key], check): return False
        return True
    return left == right


def run_guard_differential_controls(batch_module, legacy_module, word_module,
                                   reference, oracle, *, check):
    check(); began = time.perf_counter(); original = copy.deepcopy(FIXTURES); outcomes = []
    for fixture in FIXTURES:
        check(); spec = copy.deepcopy(fixture); before = copy.deepcopy(spec)
        old = legacy_module.compile_guards(spec, oracle, limit=1000000000, queries=512)
        check(); need(old['status'] == 'complete', 'legacy tiny compilation must be fully resolved')
        new = batch_module.compile_guards(spec, oracle, limit=1000000000, queries=512, check=check)
        check(); need(new['status'] == 'complete', 'batch tiny compilation must be fully resolved')
        licences = batch_module.verify_guard_evidence(spec, new, oracle.records, check=check)
        need(licences['complete'] is True, 'full current owned batch/member licence check')
        for field in ('catalog', 'basis', 'variables', 'tautologies', 'admitted_schemes'):
            check(); need(_same(old[field], new[field], check), 'full ordered original compiler field '+field)
        # Independently retain every old singleton decision in original order.
        owners = {}
        for record in oracle.records:
            check(); need(type(record['id']) is int and record['id'] not in owners, 'unique live Native owners')
            owners[record['id']] = record
        wanted = [dict(rule='tautology', formula=['imp', ['bot'], ['bot']])]
        purposes = ['first_order_theory_admission']
        for formula in old['catalog']['basis']:
            check(); wanted.append(dict(rule='tautology', formula=formula)); purposes.append('first_order_tautology')
        for command in old['catalog']['schemes']:
            check(); wanted.append(command); purposes.append('first_order_scheme')
        need(len(old['queries']) == len(wanted), 'complete original singleton population')
        old_records = []
        for query, command, purpose in zip(old['queries'], wanted, purposes):
            check(); need(type(query) is int and query in owners, 'old singleton current owned record')
            record = owners[query]
            request = dict(protocol='gcts-fol-1', theory=spec['theory'], blocks=[],
                           proof=[command], target=command['formula'])
            need(_same(record['request'], request, check) and record['purpose'] == purpose
                 and record['result']['status'] in ('accepted', 'rejected'), 'literal old singleton authority')
            old_records.append(copy.deepcopy(record))
        inventory = dict(status='native_accepted', definitions=[], interfaces=[], native_blocks=[])
        left = word_module.Model(spec, old, inventory, check=check)
        left_reference = reference.verify_word_reference(spec, old, inventory, left, check=check)
        left_packet = word_module.evidence_view(left, check)
        left_owner = word_module.verify_evidence(left_packet, left, check)
        right = word_module.Model(spec, new, inventory, check=check)
        right_reference = reference.verify_word_reference(spec, new, inventory, right, check=check)
        right_packet = word_module.evidence_view(right, check)
        right_owner = word_module.verify_evidence(right_packet, right, check)
        need(left_reference['complete'] is True and right_reference['complete'] is True
             and left_owner['complete'] is True and right_owner['complete'] is True,
             'both complete tiny model owners and independent original reduction gates')
        fields = set(left_packet)
        need(fields == set(right_packet) and 'base_compile_seconds' in fields, 'same complete model evidence schema')
        for field in sorted(fields-{'base_compile_seconds'}):
            check(); need(_same(left_packet[field], right_packet[field], check),
                          'full model differential including domain/key/value/metadata/boundary/dependency '+field)
        if spec['id'] == 'tiny-nontautological-basis':
            need(new['tautologies'] == [] and new['admitted_schemes'] == [], 'rejected basis not admitted')
        else:
            rules = set()
            for command in new['admitted_schemes']:
                check(); rules.add(command['rule'])
            need('instantiate' in rules and 'eq_subst' in rules, 'actual UI and EQ licence coverage')
        need(_same(spec, before, check), 'diagnostic statement unchanged')
        outcomes.append(dict(id=spec['id'], status='PASSED', fixture=copy.deepcopy(spec),
            old_compiled=old, batch_compiled=new, old_owned_records=old_records,
            batch_licence_check=licences, original_model=left_packet, batch_model=right_packet,
            old_reference=left_reference, batch_reference=right_reference,
            old_owner_check=left_owner, batch_owner_check=right_owner,
            ignored_fields=['base_compile_seconds'],
            scope='Complete ordered admitted-set and full tiny Model carrier equality; timing differs and is retained, not asserted equal. No proof-search, new theorem, arbitrary catalog equivalence or runtime-fit claim.'))
        del left, right
    need(_same(FIXTURES, original, check), 'literal diagnostic population unchanged')
    need(tuple(row['id'] for row in outcomes) == CONTROL_IDS, 'both declared differential fixtures complete')
    check()
    return dict(schema='D18-guard-batching-native-model-differentials-v1', complete=True,
                count=2, controls=outcomes, seconds=time.perf_counter()-began,
                scope='Two finite diagnostics run only inside a fresh reviewed whole acquisition. Every old and new Native start/model/reference cost charged to original caps. No extra actual, outside probe, cache adoption, or performance prediction.')
