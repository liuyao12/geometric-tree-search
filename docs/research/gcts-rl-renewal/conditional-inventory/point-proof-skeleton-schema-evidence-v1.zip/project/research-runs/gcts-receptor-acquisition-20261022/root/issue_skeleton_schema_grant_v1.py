"""Issue one reviewed case grant; metadata only, no scientific invocation."""
from pathlib import Path
import argparse
import hashlib
import json

ROOT = Path(__file__).resolve().parent
CASE = 'admitted-library-skeleton-schema-feasibility-v1-case-0'


def pin(path):
    body = Path(path).read_bytes()
    return dict(path=str(Path(path).resolve()), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--acceptance', required=True)
    args = parser.parse_args()
    accepted = json.loads(Path(args.acceptance).read_bytes())
    assert accepted['approved_for_one_case'] is True
    assert accepted['issuer_source'] == pin(__file__)
    for name in ('plan', 'whole_review', 'idle_barrier'):
        row = accepted[name]
        assert pin(row['path']) == row
    plan_path = ROOT / 'plans' / (CASE + '.json')
    assert accepted['plan'] == pin(plan_path)
    plan = json.loads(plan_path.read_bytes())
    assert plan['case_id'] == CASE and plan['profile'] == 'skeleton-schema-whole-feasibility-v1'
    assert not Path(plan['actual_dir']).exists()
    assert not Path(plan['actual_dir'] + '.observer').exists()
    idle = json.loads(Path(accepted['idle_barrier']['path']).read_bytes())
    assert idle['all_other_task_agents_tools_idle'] is True
    data = {plan['input_authority']['library_result']['path']}
    data.update(row['query']['path'] for row in plan['input_authority']['context_queries'])
    for record in plan['files']:
        assert record['path'] not in data
        assert pin(record['path']) == record
    grant = dict(schema='Root-skeleton-schema-once-grant-v1', authorized=True, uses=1,
        review_passed=True, case_id=CASE, plan_sha256=accepted['plan']['sha256'],
        runner_sha256=pin(plan['runner_path'])['sha256'],
        Root_acceptance=pin(args.acceptance), whole_review=accepted['whole_review'],
        idle_barrier=accepted['idle_barrier'], scientific_invocations=0,
        scope='One new bounded full case; no retry, old actual replay or prefix admission.')
    output = ROOT / 'grants' / (CASE + '.json')
    with output.open('x') as stream:
        json.dump(grant, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')
    print(json.dumps(pin(output)))


if __name__ == '__main__':
    main()
