"""Inert synthetic controls. No research input, module discovery or private hooks."""
import hashlib
import json

VERSION = 'FPC-RECEPTOR-SKELETON-SCHEMA-INDEPENDENT-BANK-v1'
SCHEMA = 'FPC-receptor-skeleton-schema-independent-controls-v1'
POPULATION = 'skeleton_schema6'
CONTROL_IDS = ('schema-equations', 'accidental-equality-removal', 'ordered-node-source-identity', 'detached-specialization', 'invalid-input', 'first-fault-dependency')
SCOPE = 'Synthetic public fixed-skeleton inference controls only; no donor, transfer, library, principal-schema, GCTS or RL admission.'
LIMITS = ['No valid cyclic proof skeleton or public unifier hook: occurs-check rejection is Source-review-only.', 'Selected first-callback and public dependency faults only; no all-cutoff/native-allocation claim.', 'No compiler, original proof checker, consumer, primitive fallback transaction or final-root-use path is exercised.']
RESULT_FIELDS = ('schema', 'version', 'complete', 'accepted', 'library_admitted', 'method', 'source_family', 'family', 'specialization', 'source_associations', 'input_guards', 'output_guards', 'costs', 'scope')
COST_FIELDS = ('successful_callbacks', 'copy_visits', 'comparison_visits', 'fresh_metavariables', 'unification_pairs', 'dereference_steps', 'occurs_visits', 'resolved_term_visits', 'normalization_visits', 'specialization_pairs', 'equation_checks', 'source_backprojection_checks', 'public_input_guard_calls', 'public_output_guard_calls', 'canonical_bytes')


class SkeletonControlError(Exception):
    pass


def _need(test, message):
    if not test:
        raise SkeletonControlError(message)


class _Call:
    def __init__(self, check):
        _need(callable(check), 'check callable')
        self.check, self.callbacks, self.first = check, 0, None

    def tick(self):
        if self.first is not None:
            raise self.first
        try:
            self.check()
        except BaseException as error:
            self.first = error
            raise
        self.callbacks += 1


def _copy(value, call):
    call.tick()
    if type(value) is dict:
        return {key: _copy(part, call) for key, part in value.items()}
    if type(value) in (list, tuple):
        return [_copy(part, call) for part in value]
    _need(value is None or type(value) in (str, int, bool), 'finite synthetic scalar')
    return value


def _containers(value, call, active=None):
    call.tick()
    if type(value) not in (dict, list, tuple):
        _need(value is None or type(value) in (str,int,bool), 'plain return scalar')
        return set()
    if type(value) is dict:
        _need(all(type(k) is str for k in value), 'plain return keys')
    active = set() if active is None else active
    identity = id(value)
    _need(identity not in active, 'acyclic detached return')
    active.add(identity)
    result = {identity}.union(*(_containers(v, call, active) for v in (value.values() if type(value) is dict else value)))
    active.remove(identity)
    return result


def _same(a, b, call):
    call.tick()
    if type(a) is not type(b): return False
    if type(b) is dict: return set(a)==set(b) and all(_same(a[k],v,call) for k,v in b.items())
    if type(b) is list: return len(a)==len(b) and all(_same(x,y,call) for x,y in zip(a,b))
    return a==b


def _i(a, b):
    return ['imp', a, b]


def _n(a):
    return ['not', a]


def _p(index):
    return ['param', index]


def _logical(tag, witness):
    a, b = witness[:2]
    if tag == 0:
        return _i(a, _i(b, a))
    if tag == 1:
        c = witness[2]
        return _i(_i(a, _i(b, c)), _i(_i(a, b), _i(a, c)))
    _need(tag == 2, 'H1/H2/H3 only')
    return _i(_i(_n(b), _n(a)), _i(a, b))


def _ln(index, tag, witness):
    return dict(local_id=index, rule_tag=1, subtag=tag, formula_pattern=_logical(tag, witness), witness_pattern=witness, references=[])


def _ref(kind, index):
    return dict(kind=kind, id=index)


def _mp(index, formula, left, right):
    return dict(local_id=index, rule_tag=3, subtag=None, formula_pattern=formula, witness_pattern=None, references=[left, right])


def _family(nodes, boundary, parameters, call, two_sources=False):
    ports = [dict(boundary_id=i, formula_pattern=f) for i, f in enumerate(boundary)]
    params = [dict(id=i, sort='Formula') for i in range(parameters)]
    key = dict(parameters=params, root_local_id=len(nodes)-1, internal_nodes=nodes, boundary_nodes=ports)
    canonical = json.dumps(key, sort_keys=True, ensure_ascii=True, separators=(',', ':'), allow_nan=False).encode()
    sources = []
    for donor in range(2 if two_sources else 1):
        call.tick()
        sources.append(dict(donor_id='synthetic'+str(donor), root_source_row=10+3*(len(nodes)-1), source_to_local=[[10+3*i, i] for i in range(len(nodes))], boundary_source_to_port=[[i, i] for i in range(len(ports))], source_bindings=[dict(parameter_id=i, formula=['pred', (i+donor)%4, []]) for i in range(parameters)]))
    return dict(family_key=_copy(key, call), family_id=hashlib.sha256(canonical).hexdigest(), parameters=params, root_local_id=len(nodes)-1, internal_nodes=nodes, boundary_nodes=ports, source_occurrences=sources, distinct_base_nodes=len(nodes), size_band='SMALL_2_4' if len(nodes)<5 else 'LARGE_5_8', validation_provenance=list(range(len(sources))))


def _fixture(name, call):
    a, b, c, e = (_p(i) for i in range(4))
    it = lambda i: _ref('internal', i)
    if name in ('closed-generic', 'closed-accidental', 'two-sources'):
        old_b = b if name == 'closed-generic' else _i(a, a)
        old = [_ln(0, 0, [a, old_b]), _ln(1, 1, [a, old_b, a]), _mp(2, _i(_i(a, old_b), _i(a, a)), it(0), it(1))]
        new = [_ln(0, 0, [a, b]), _ln(1, 1, [a, b, a]), _mp(2, _i(_i(a, b), _i(a, a)), it(0), it(1))]
        return _family(old, [], 2 if name == 'closed-generic' else 1, call, name == 'two-sources'), dict(nodes=new, boundary=[], parameters=2, images=[a, b if name == 'closed-generic' else _i(a, a)])
    if name == 'conditional':
        old_b = _i(a, a)
        old_h2 = _i(_i(a, _i(old_b, a)), _i(_i(a, old_b), _i(a, a)))
        old = [_ln(0, 0, [a, old_b]), _mp(1, _i(_i(a, old_b), _i(a, a)), it(0), _ref('boundary', 0))]
        new = [_ln(0, 0, [a, b]), _mp(1, c, it(0), _ref('boundary', 0))]
        return _family(old, [old_h2], 1, call), dict(nodes=new, boundary=[_i(_i(a, _i(b, a)), c)], parameters=3, images=[a, old_b, _i(_i(a, old_b), _i(a, a))])
    if name == 'H3':
        old = [_ln(0, 2, [a, a]), _mp(1, _i(a, a), _ref('boundary', 0), it(0))]
        new = [_ln(0, 2, [b, a]), _mp(1, _i(b, a), _ref('boundary', 0), it(0))]
        return _family(old, [_i(_n(a), _n(a))], 1, call), dict(nodes=new, boundary=[_i(_n(a), _n(b))], parameters=2, images=[a, a])
    f = _i(a, _i(a, a))
    if name == 'shared':
        old = [_ln(0, 0, [a, a]), _ln(1, 0, [f, f]), _mp(2, _i(f, f), it(0), it(1)), _mp(3, f, it(0), it(2))]
        g = _i(a, _i(b, a))
        new = [_ln(0, 0, [a, b]), _ln(1, 0, [g, g]), _mp(2, _i(g, g), it(0), it(1)), _mp(3, g, it(0), it(2))]
        return _family(old, [], 1, call), dict(nodes=new, boundary=[], parameters=2, images=[a, a])
    _need(name == 'duplicated', 'fixture name')
    old = [_ln(0, 0, [a, a]), _ln(1, 0, [a, a]), _ln(2, 0, [f, f]), _mp(3, _i(f, f), it(0), it(2)), _mp(4, f, it(1), it(3))]
    g, h = _i(a, _i(b, a)), _i(c, _i(e, c))
    new = [_ln(0, 0, [a, b]), _ln(1, 0, [c, e]), _ln(2, 0, [g, h]), _mp(3, _i(h, g), it(0), it(2)), _mp(4, g, it(1), it(3))]
    return _family(old, [], 1, call), dict(nodes=new, boundary=[], parameters=4, images=[a, a, a, a])


def _subst(pattern, images, call):
    call.tick()
    if pattern[0] == 'param':
        return _copy(images[pattern[1]], call)
    return [pattern[0]] + [_subst(x, images, call) for x in pattern[1:]]


def _ids(pattern):
    if pattern[0] == 'param':
        return {pattern[1]}
    return set().union(*(_ids(x) for x in pattern[1:]))


def _audit_guard(guard, occurrence, family, index, call):
    _need(set(guard)=={'occurrence_index','match_result'} and type(guard['occurrence_index']) is int and guard['occurrence_index']==index, 'guard carrier/order')
    z = guard['match_result']
    _need(set(z)=={'matched','bindings','residual_parameters'} and z['matched'] is True, 'real positive guard')
    used = _ids(family['internal_nodes'][family['root_local_id']]['formula_pattern'])
    for port in family['boundary_nodes']:
        used |= _ids(port['formula_pattern'])
    expected = [x for x in occurrence['source_bindings'] if x['parameter_id'] in used]
    residual = [x for x in family['parameters'] if x['id'] not in used]
    _need(_same(z['bindings'],expected,call) and _same(z['residual_parameters'],residual,call), 'guard full binding/residual')


def _audit(out, old, expected, callbacks, call):
    _need(type(out) is dict and set(out)==set(RESULT_FIELDS), 'fourteen result fields')
    _need(out['schema']=='FPC-receptor-skeleton-schema-candidate-v1' and out['version']=='FPC-RECEPTOR-SKELETON-SCHEMA-v1', 'candidate identity')
    _need(out['complete'] is True and out['accepted'] is False and out['library_admitted'] is False, 'candidate flags')
    _need(out['method']=='fixed-proof-skeleton-first-order-unification-v1' and out['scope']=='Ordinary fixed-skeleton schema inference candidate only; no proof, usable library, contextual use, principal-schema theorem, transfer, GCTS or RL admission.', 'method/scope')
    _need(_same(out['source_family'],old,call) and not (_containers(out,call)&_containers(old,call)), 'detached original')
    f = out['family']
    _need(set(f)==set(old) and _same(f['internal_nodes'],expected['nodes'],call), 'literal generalized nodes')
    _need(_same(f['boundary_nodes'],[dict(boundary_id=i, formula_pattern=p) for i,p in enumerate(expected['boundary'])],call), 'literal boundary')
    _need(_same(f['parameters'],[dict(id=i, sort='Formula') for i in range(expected['parameters'])],call), 'independent parameters')
    _need(_same(out['specialization'],[dict(parameter_id=i, source_pattern=p) for i,p in enumerate(expected['images'])],call), 'literal specialization')
    for key in ('root_local_id','distinct_base_nodes','size_band','validation_provenance'):
        _need(_same(f[key],old[key],call), 'preserved '+key)
    key = {k:f[k] for k in ('parameters','root_local_id','internal_nodes','boundary_nodes')}
    _need(_same(f['family_key'],key,call), 'complete structural key')
    raw = json.dumps(key,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode()
    _need(f['family_id']==hashlib.sha256(raw).hexdigest(), 'display hash')
    for n in f['internal_nodes']:
        call.tick()
        if n['rule_tag']==1:
            _need(n['formula_pattern']==_logical(n['subtag'],n['witness_pattern']) and n['references']==[], 'generic logical equation')
        else:
            terms = [f['internal_nodes'][r['id']]['formula_pattern'] if r['kind']=='internal' else f['boundary_nodes'][r['id']]['formula_pattern'] for r in n['references']]
            _need(terms[1]==_i(terms[0],n['formula_pattern']) and n['witness_pattern'] is None, 'ordered generic MP')
    for collection in ('boundary_nodes','internal_nodes'):
        for new, original in zip(f[collection],old[collection]):
            _need(_subst(new['formula_pattern'],expected['images'],call)==original['formula_pattern'], 'every formula specializes')
            if collection=='internal_nodes':
                _need(new['references']==original['references'], 'ordered identity preserved')
                witness = None if new['witness_pattern'] is None else [_subst(p,expected['images'],call) for p in new['witness_pattern']]
                _need(witness==original['witness_pattern'], 'every witness specializes')
    count = len(old['source_occurrences'])
    _need(len(f['source_occurrences'])==len(out['source_associations'])==len(out['input_guards'])==len(out['output_guards'])==count, 'all occurrences retained')
    for i,(src,dst,assoc) in enumerate(zip(old['source_occurrences'],f['source_occurrences'],out['source_associations'])):
        images = [x['formula'] for x in src['source_bindings']]
        composed = [dict(parameter_id=j,formula=_subst(p,images,call)) for j,p in enumerate(expected['images'])]
        _need(_same(dst,dict(src,source_bindings=composed),call), 'complete composed occurrence')
        sm = {local:source for source,local in src['source_to_local']}
        bm = {port:source for source,port in src['boundary_source_to_port']}
        checks = []
        for n in f['internal_nodes']:
            refs = [dict(position=j,kind=z['kind'],id=z['id'],source_row=(sm if z['kind']=='internal' else bm)[z['id']]) for j,z in enumerate(n['references'])]
            checks.append(dict(local_id=n['local_id'],source_row=sm[n['local_id']],formula_equal=True,witness_equal=True,reference_checks=refs))
        wanted = dict(occurrence_index=i,donor_id=src['donor_id'],root_source_row=src['root_source_row'],source_to_local=src['source_to_local'],boundary_source_to_port=src['boundary_source_to_port'],original_source_bindings=src['source_bindings'],generalized_source_bindings=composed,boundary_checks=[dict(boundary_id=j,source_row=bm[j],formula_equal=True) for j in range(len(bm))],internal_checks=checks)
        _need(_same(assoc,wanted,call), 'complete source/backreference association')
        for collection in ('boundary_nodes','internal_nodes'):
            for n,o in zip(f[collection],old[collection]):
                _need(_subst(n['formula_pattern'],[x['formula'] for x in composed],call)==_subst(o['formula_pattern'],images,call), 'composed formula backprojection')
                if collection=='internal_nodes' and n['witness_pattern'] is not None:
                    _need([_subst(p,[x['formula'] for x in composed],call) for p in n['witness_pattern']]==[_subst(p,images,call) for p in o['witness_pattern']], 'composed witness backprojection')
        _audit_guard(out['input_guards'][i],src,old,i,call)
        _audit_guard(out['output_guards'][i],dst,f,i,call)
    _need(set(out['costs'])==set(COST_FIELDS) and all(type(v) is int and v>=0 for v in out['costs'].values()), 'fifteen normal counters')
    _need(out['costs']['successful_callbacks']==callbacks and out['costs']['public_input_guard_calls']==count and out['costs']['public_output_guard_calls']==count, 'observed callback/guard transport')
    _need(out['costs']['canonical_bytes']==len(raw), 'canonical-byte census')


def _normal(subject, instance, name, call):
    old, expected = _fixture(name, call)
    before = _copy(old, call)
    start = call.callbacks
    out = subject.infer_schematic_family(old, instance=instance, check=call.tick)
    callbacks = call.callbacks-start
    _need(old==before, 'input unchanged')
    _need(not (_containers(out,call)&_containers(old,call)), 'no caller-container aliases')
    _audit(out, before, expected, callbacks, call)
    return old, expected, out


def _owned_invalid(subject, instance, value, call, check_override=False):
    error = None
    try:
        subject.infer_schematic_family(value,instance=instance,check=None if check_override else call.tick)
    except BaseException as caught:
        if call.first is not None:
            raise call.first
        error = caught
    _need(type(error) is subject.SchemaInputError and subject.is_owned_error(error), 'owned normal refusal')
    _need(type(error.path) is tuple and all(type(x) is str or type(x) is int and x>=0 for x in error.path), 'public refusal path')
    _need(error.code in ('INVALID_INPUT','INVALID_FAMILY','INCONSISTENT_SKELETON','INVALID_SPECIALIZATION','INVALID_DEPENDENCY'), 'closed refusal code')
    if check_override:
        _need(error.path==('check',), 'invalid-check singleton')
    return error


class _Dependency:
    VERSION = 'FPC-RECEPTOR-INSTANCE-SERVICE-v2'

    def __init__(self, real, call, error, target):
        self.real,self.call,self.error,self.target = real,call,error,target
        self.calls,self.after,self.after_checks,self.raised = 0,0,0,False

    def check(self):
        if self.raised:
            self.after_checks += 1
            raise self.error
        self.call.tick()

    def match_receptor(self,*args,**kwargs):
        if self.raised:
            self.after += 1
            raise self.error
        self.call.tick()
        self.calls += 1
        if self.calls==self.target:
            self.raised=True
            raise self.error
        return self.real.match_receptor(*args,**kwargs)


def run_bank(modules, *, check):
    call = _Call(check)
    call.tick()
    _need(type(modules) is dict and set(modules)=={'schema','instance'}, 'exact public module pair')
    subject,instance = modules['schema'],modules['instance']
    _need(subject.VERSION=='FPC-RECEPTOR-SKELETON-SCHEMA-v1' and instance.VERSION=='FPC-RECEPTOR-INSTANCE-SERVICE-v2', 'module versions')
    rows = []
    for group,names in ((CONTROL_IDS[0],('closed-generic','H3')),(CONTROL_IDS[1],('closed-accidental','conditional')),(CONTROL_IDS[2],('shared','duplicated','two-sources'))):
        observations=[]
        for name in names:
            old,expected,out = _normal(subject,instance,name,call)
            observations.append(dict(locator=group+'/'+name,input=old,expected=expected,result=out))
        rows.append(dict(id=group,passed=True,observations=observations))
    old,expected,out = _normal(subject,instance,'closed-accidental',call)
    snapshot = _copy(out,call)
    out['family']['source_occurrences'][0]['donor_id']='mutated-output'
    out['source_family']['source_occurrences'][0]['donor_id']='mutated-source-copy'
    _need(old['source_occurrences'][0]['donor_id']=='synthetic0', 'mutation stays detached')
    start=call.callbacks
    fresh=subject.infer_schematic_family(old,instance=instance,check=call.tick)
    callbacks=call.callbacks-start
    _audit(fresh,old,expected,callbacks,call)
    _need(not (_containers(fresh,call)&_containers(out,call)), 'no cross-call containers')
    _need({k:v for k,v in fresh.items() if k!='costs'}=={k:v for k,v in snapshot.items() if k!='costs'}, 'fresh independent semantic output')
    rows.append(dict(id=CONTROL_IDS[3],passed=True,observations=[dict(locator='detached-specialization/repeat',result=snapshot,mutated_result=out,fresh_result=fresh)]))
    invalid=[]
    _need(not subject.is_owned_error(subject.SchemaInputError('public construction')), 'constructor unowned')
    for label,value,override in (('none',None,False),('empty',{},False),('invalid-check',None,True)):
        e=_owned_invalid(subject,instance,value,call,override)
        invalid.append(dict(locator='invalid-input/'+label,code=e.code,path=list(e.path)))
        if override: retained=e
    cyclic={};cyclic['cycle']=cyclic
    e=_owned_invalid(subject,instance,cyclic,call)
    invalid.append(dict(locator='invalid-input/carrier-cycle',code=e.code,path=list(e.path)))
    rows.append(dict(id=CONTROL_IDS[4],passed=True,observations=invalid))
    faults=[]
    old,_ = _fixture('two-sources',call)
    for name,e in (('StopIteration',StopIteration('intentional')),('same-class',subject.SchemaInputError('intentional')),('retained-owned',retained)):
        state=dict(raised=False,after=0,calls=0)
        def probe():
            if state['raised']:
                state['after']+=1
                raise e
            call.tick();state['calls']+=1;state['raised']=True
            raise e
        dependency=_Dependency(instance,call,e,1)
        caught=None
        try:
            subject.infer_schematic_family(old,instance=dependency,check=probe)
        except BaseException as error:
            if call.first is not None: raise call.first
            caught=error
        _need(caught is e and state['calls']==1 and state['after']==0 and dependency.calls==0, 'first callback identity/no later work')
        faults.append(dict(locator='first-fault-dependency/callback/'+name,identical=True,callback_calls=state['calls'],postfault_callback_attempts=state['after'],dependency_calls=dependency.calls))
        for phase,target in (('first-input',1),('first-output',3)):
            dependency=_Dependency(instance,call,e,target)
            caught=None
            try:
                subject.infer_schematic_family(old,instance=dependency,check=dependency.check)
            except BaseException as error:
                if call.first is not None: raise call.first
                caught=error
            _need(caught is e and dependency.calls==target and dependency.after==0 and dependency.after_checks==0, 'public dependency first identity')
            faults.append(dict(locator='first-fault-dependency/'+phase+'/'+name,identical=True,public_dependency_calls=dependency.calls,postfault_dependency_attempts=dependency.after,postfault_check_attempts=dependency.after_checks))
    rows.append(dict(id=CONTROL_IDS[5],passed=True,observations=faults))
    call.tick()
    return dict(schema=SCHEMA,version=VERSION,population=POPULATION,complete=True,control_ids=list(CONTROL_IDS),controls=rows,counts=dict(groups=6,passed=6,failed=0),scope=SCOPE,coverage_limits=list(LIMITS))
