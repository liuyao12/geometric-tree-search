"""Inert generic Formula-schema inference from one fixed primitive proof skeleton.

Only the supplied public instance2 matcher is a project dependency. No target,
proof loader, search, checker, encoder, filesystem or policy getter is used.
"""
import hashlib
import json
import math
from types import MappingProxyType

VERSION = 'FPC-RECEPTOR-SKELETON-SCHEMA-v1'
_INSTANCE_VERSION = 'FPC-RECEPTOR-INSTANCE-SERVICE-v2'
_METHOD = 'fixed-proof-skeleton-first-order-unification-v1'
_OWNER = object()
_FAMILY_FIELDS = ('family_key', 'family_id', 'parameters', 'root_local_id',
    'internal_nodes', 'boundary_nodes', 'source_occurrences', 'distinct_base_nodes',
    'size_band', 'validation_provenance')
_NODE_FIELDS = ('local_id', 'rule_tag', 'subtag', 'formula_pattern',
    'witness_pattern', 'references')
_COST_FIELDS = ('successful_callbacks', 'copy_visits', 'comparison_visits',
    'fresh_metavariables', 'unification_pairs', 'dereference_steps', 'occurs_visits',
    'resolved_term_visits', 'normalization_visits', 'specialization_pairs',
    'equation_checks', 'source_backprojection_checks', 'public_input_guard_calls',
    'public_output_guard_calls', 'canonical_bytes')


class SchemaInputError(ValueError):
    """Public message construction is unowned; private per-call mint only."""


def is_owned_error(error):
    return (type(error) is SchemaInputError and
            getattr(error, '_owner', None) is _OWNER and
            getattr(error, '_call_token', None) is not None)


class _Call:
    def __init__(self, check):
        self.check, self.first, self.token = check, None, object()
        self.costs = {name: 0 for name in _COST_FIELDS}

    def abort(self, error):
        if self.first is None:
            self.first = error
        raise self.first

    def fault(self):
        if self.first is not None:
            raise self.first

    def tick(self, counter=None):
        self.fault()
        try:
            self.check()
        except BaseException as error:
            self.abort(error)
        self.costs['successful_callbacks'] += 1
        if counter is not None:
            self.costs[counter] += 1

    def fail(self, code, path, message):
        self.fault()
        error = SchemaInputError(message)
        error.code, error.path = code, path
        error._owner, error._call_token = _OWNER, self.token
        self.abort(error)

    def need(self, condition, path, message, code='INVALID_INPUT'):
        self.tick()
        if not condition:
            self.fail(code, path, message)

    def helper(self, function, *args, **kwargs):
        self.tick()
        try:
            value = function(*args, **kwargs)
        except BaseException as error:
            self.abort(error)
        self.tick()
        return value


def _nat(value):
    return type(value) is int and value >= 0


def _keys(value, names, c, path):
    c.need(type(value) is dict or type(value) is MappingProxyType,
           path, 'ordinary mapping required')
    c.need(len(value) == len(names), path, 'exact object fields required')
    for key in value:
        c.need(type(key) is str, path, 'exact string keys before lookup')
    for name in names:
        c.need(name in value, path, 'exact object fields required')


def _array(value, c, path):
    c.need(type(value) is list or type(value) is tuple,
           path, 'ordinary ordered vector required')
    return value


def _copy(value, c, frozen):
    pending, values, active = [('visit', value)], [], set()
    while pending:
        c.tick('copy_visits')
        task = pending.pop()
        if task[0] == 'visit':
            item = task[1]
            kind = type(item)
            if item is None or kind is bool or kind is int or kind is str:
                values.append(item)
            elif kind is float:
                c.need(math.isfinite(item), ('family',), 'finite diagnostic float required')
                values.append(item)
            else:
                mapping = kind is dict or kind is MappingProxyType
                c.need(mapping or kind is list or kind is tuple,
                       ('family',), 'exact ordinary carrier required')
                identity = id(item)
                c.need(identity not in active, ('family',), 'acyclic carrier required')
                active.add(identity)
                keys = []
                if mapping:
                    for key in item:
                        c.need(type(key) is str, ('family',), 'exact string keys')
                        keys.append(key)
                pending.append(('finish', mapping, keys, len(item), identity))
                if mapping:
                    for key in reversed(keys):
                        c.tick('copy_visits')
                        pending.append(('visit', item[key]))
                else:
                    for child in reversed(item):
                        c.tick('copy_visits')
                        pending.append(('visit', child))
        else:
            _, mapping, keys, count, identity = task
            children = values[-count:] if count else []
            if count:
                del values[-count:]
            if mapping:
                result = {}
                for key, child in zip(keys, children):
                    c.tick('copy_visits')
                    result[key] = child
                values.append(MappingProxyType(result) if frozen else result)
            else:
                values.append(tuple(children) if frozen else list(children))
            active.remove(identity)
    c.need(len(values) == 1, ('family',), 'one complete owned value')
    return values[0]


def _equal(left, right, c):
    pending = [(left, right)]
    while pending:
        c.tick('comparison_visits')
        a, b = pending.pop()
        ak, bk = type(a), type(b)
        aa, ba = ak is list or ak is tuple, bk is list or bk is tuple
        am = ak is dict or ak is MappingProxyType
        bm = bk is dict or bk is MappingProxyType
        if aa or ba:
            if not (aa and ba and len(a) == len(b)):
                return False
            for index in range(len(a) - 1, -1, -1):
                c.tick('comparison_visits')
                pending.append((a[index], b[index]))
        elif am or bm:
            if not (am and bm and len(a) == len(b)):
                return False
            for key in a:
                c.tick('comparison_visits')
                if key not in b:
                    return False
                pending.append((a[key], b[key]))
        elif ak is not bk:
            return False
        elif ak is str:
            if len(a) != len(b):
                return False
            for offset in range(0, len(a), 65536):
                c.tick('comparison_visits')
                if a[offset:offset + 65536] != b[offset:offset + 65536]:
                    return False
        elif a != b:
            return False
    return True


def _pattern(pattern, count, c):
    pending = [pattern]
    while pending:
        c.tick()
        node = _array(pending.pop(), c, ('family', 'pattern'))
        c.need(bool(node) and type(node[0]) is str,
               ('family', 'pattern'), 'Formula pattern constructor')
        if node[0] == 'param':
            c.need(len(node) == 2 and _nat(node[1]) and node[1] < count,
                   ('family', 'pattern'), 'declared Formula parameter')
        elif node[0] == 'not':
            c.need(len(node) == 2, ('family', 'pattern'), 'negation arity')
            pending.append(node[1])
        elif node[0] == 'imp':
            c.need(len(node) == 3, ('family', 'pattern'), 'implication arity')
            pending.append(node[2])
            pending.append(node[1])
        else:
            c.fail('INVALID_FAMILY', ('family', 'pattern'), 'param/not/imp only')


def _binding_images(rows, count, c, path):
    _array(rows, c, path)
    c.need(len(rows) == count, path, 'complete ordered binding')
    images = {}
    for index, row in enumerate(rows):
        c.tick()
        _keys(row, ('parameter_id', 'formula'), c, path)
        c.need(type(row['parameter_id']) is int and row['parameter_id'] == index,
               path, 'contiguous strict parameter IDs')
        images[index] = row['formula']
    return images


def _shape(family, c):
    _keys(family, _FAMILY_FIELDS, c, ('family',))
    params = _array(family['parameters'], c, ('family', 'parameters'))
    for index, row in enumerate(params):
        _keys(row, ('id', 'sort'), c, ('family', 'parameters'))
        c.need(type(row['id']) is int and row['id'] == index
               and type(row['sort']) is str and row['sort'] == 'Formula',
               ('family', 'parameters'), 'ordered Formula parameters')
    nodes = _array(family['internal_nodes'], c, ('family', 'internal_nodes'))
    boundary = _array(family['boundary_nodes'], c, ('family', 'boundary_nodes'))
    c.need(2 <= len(nodes) <= 8 and len(boundary) <= 4,
           ('family',), 'original node/port bounds', 'INVALID_FAMILY')
    c.need(type(family['root_local_id']) is int and family['root_local_id'] == len(nodes) - 1,
           ('family',), 'source-order root', 'INVALID_FAMILY')
    for index, row in enumerate(boundary):
        _keys(row, ('boundary_id', 'formula_pattern'), c, ('family', 'boundary_nodes'))
        c.need(type(row['boundary_id']) is int and row['boundary_id'] == index,
               ('family', 'boundary_nodes'), 'ordered boundary IDs')
        _pattern(row['formula_pattern'], len(params), c)
    for index, row in enumerate(nodes):
        _keys(row, _NODE_FIELDS, c, ('family', 'internal_nodes'))
        c.need(type(row['local_id']) is int and row['local_id'] == index,
               ('family', 'internal_nodes'), 'ordered local IDs')
        _pattern(row['formula_pattern'], len(params), c)
        refs = _array(row['references'], c, ('family', 'references'))
        for ref in refs:
            _keys(ref, ('kind', 'id'), c, ('family', 'references'))
            c.need(type(ref['kind']) is str and _nat(ref['id']),
                   ('family', 'references'), 'typed strict reference')
            c.need((ref['kind'] == 'internal' and ref['id'] < index) or
                   (ref['kind'] == 'boundary' and ref['id'] < len(boundary)),
                   ('family', 'references'), 'ordered backward reference')
        if type(row['rule_tag']) is int and row['rule_tag'] == 1:
            c.need(type(row['subtag']) is int and 0 <= row['subtag'] <= 2 and not refs,
                   ('family', 'internal_nodes'), 'H1/H2/H3 without references')
            witness = _array(row['witness_pattern'], c, ('family', 'witness_pattern'))
            c.need(len(witness) == (3 if row['subtag'] == 1 else 2),
                   ('family', 'witness_pattern'), 'ordered witness arity')
            for pattern in witness:
                _pattern(pattern, len(params), c)
        else:
            c.need(type(row['rule_tag']) is int and row['rule_tag'] == 3
                   and row['subtag'] is None and row['witness_pattern'] is None and len(refs) == 2,
                   ('family', 'internal_nodes'), 'ordered MP with null subtag/witness')
    occurrences = _array(family['source_occurrences'], c, ('family', 'source_occurrences'))
    c.need(1 <= len(occurrences) <= 2, ('family',), 'original occurrence bound')
    for occurrence in occurrences:
        _keys(occurrence, ('donor_id', 'root_source_row', 'source_to_local',
               'boundary_source_to_port', 'source_bindings'), c, ('family', 'source_occurrences'))
        _binding_images(occurrence['source_bindings'], len(params), c, ('source_occurrences',))
    return nodes, boundary, occurrences


def _substitute(pattern, images, c):
    pending, values = [('visit', pattern)], []
    while pending:
        c.tick()
        action, node = pending.pop()
        if action == 'visit':
            if node[0] == 'param':
                values.append(images[node[1]])
            elif node[0] == 'not':
                pending.append(('not', None))
                pending.append(('visit', node[1]))
            else:
                pending.append(('imp', None))
                pending.append(('visit', node[2]))
                pending.append(('visit', node[1]))
        elif action == 'not':
            values.append(('not', values.pop()))
        else:
            right, left = values.pop(), values.pop()
            values.append(('imp', left, right))
    c.need(len(values) == 1, ('specialization',), 'complete simultaneous substitution')
    return values[0]


def _guard(family, images, matcher, c, occurrence_index, role):
    inputs = []
    for row in family['boundary_nodes']:
        c.tick()
        inputs.append(_substitute(row['formula_pattern'], images, c))
    output = _substitute(family['internal_nodes'][family['root_local_id']]['formula_pattern'], images, c)
    raw = c.helper(matcher, _copy(family, c, False),
                   input_formulas=_copy(inputs, c, False), output_formula=_copy(output, c, False),
                   check=c.tick)
    answer = _copy(raw, c, True)
    path = ('dependency', role, occurrence_index)
    _keys(answer, ('matched', 'bindings', 'residual_parameters'), c, path)
    c.need(answer['matched'] is True, path, 'constructed complete source specialization must match',
           'INVALID_DEPENDENCY')
    supplied = _array(answer['bindings'], c, path)
    seen, previous = set(), -1
    for row in supplied:
        c.tick()
        _keys(row, ('parameter_id', 'formula'), c, path)
        index = row['parameter_id']
        c.need(_nat(index) and previous < index < len(family['parameters']),
               path, 'ordered public matcher binding', 'INVALID_DEPENDENCY')
        c.need(_equal(row['formula'], images[index], c), path,
               'public binding equals complete supplied source image', 'INVALID_DEPENDENCY')
        previous = index
        seen.add(index)
    residual = _array(answer['residual_parameters'], c, path)
    expected = []
    for parameter in family['parameters']:
        c.tick()
        if parameter['id'] not in seen:
            expected.append(parameter)
    c.need(_equal(residual, expected, c), path,
           'exact ordered public residual complement', 'INVALID_DEPENDENCY')
    c.costs['public_' + role + '_guard_calls'] += 1
    return dict(occurrence_index=occurrence_index, match_result=answer)


def _logical(tag, witness, c):
    c.tick()
    if tag == 0:
        a, b = witness
        return ('imp', a, ('imp', b, a))
    if tag == 1:
        a, b, d = witness
        return ('imp', ('imp', a, ('imp', b, d)),
                ('imp', ('imp', a, b), ('imp', a, d)))
    a, b = witness
    return ('imp', ('imp', ('not', b), ('not', a)), ('imp', a, b))


def _deref(term, substitutions, c):
    while term[0] == 'v' and term[1] in substitutions:
        c.tick('dereference_steps')
        term = substitutions[term[1]]
    return term


def _occurs(variable, term, substitutions, c):
    pending = [term]
    while pending:
        c.tick('occurs_visits')
        node = _deref(pending.pop(), substitutions, c)
        if node[0] == 'v':
            if node[1] == variable:
                return True
        elif node[0] == 'not':
            pending.append(node[1])
        else:
            pending.append(node[2])
            pending.append(node[1])
    return False


def _unify(left, right, substitutions, c):
    pending = [(left, right)]
    while pending:
        c.tick('unification_pairs')
        a, b = pending.pop()
        a, b = _deref(a, substitutions, c), _deref(b, substitutions, c)
        if a[0] == 'v':
            if b[0] == 'v' and a[1] == b[1]:
                continue
            c.need(not _occurs(a[1], b, substitutions, c), ('skeleton',),
                   'finite Formula terms require occurs check', 'INCONSISTENT_SKELETON')
            substitutions[a[1]] = b
        elif b[0] == 'v':
            c.need(not _occurs(b[1], a, substitutions, c), ('skeleton',),
                   'finite Formula terms require occurs check', 'INCONSISTENT_SKELETON')
            substitutions[b[1]] = a
        else:
            c.need(a[0] == b[0] and len(a) == len(b), ('skeleton',),
                   'rigid Formula constructor/arity agreement', 'INCONSISTENT_SKELETON')
            for index in range(len(a) - 1, 0, -1):
                c.tick()
                pending.append((a[index], b[index]))


def _resolve(term, substitutions, c):
    pending, values = [('visit', term)], []
    while pending:
        c.tick('resolved_term_visits')
        action, node = pending.pop()
        if action == 'visit':
            node = _deref(node, substitutions, c)
            if node[0] == 'v':
                values.append(node)
            elif node[0] == 'not':
                pending.append(('not', None))
                pending.append(('visit', node[1]))
            else:
                pending.append(('imp', None))
                pending.append(('visit', node[2]))
                pending.append(('visit', node[1]))
        elif action == 'not':
            values.append(('not', values.pop()))
        else:
            right, left = values.pop(), values.pop()
            values.append(('imp', left, right))
    c.need(len(values) == 1, ('skeleton',), 'one fully resolved Formula term')
    return values[0]


def _normalize(term, substitutions, names, c):
    resolved = _resolve(term, substitutions, c)
    pending, values = [('visit', resolved)], []
    while pending:
        c.tick('normalization_visits')
        action, node = pending.pop()
        if action == 'visit':
            if node[0] == 'v':
                variable = node[1]
                if variable not in names:
                    names[variable] = len(names)
                values.append(('param', names[variable]))
            elif node[0] == 'not':
                pending.append(('not', None))
                pending.append(('visit', node[1]))
            else:
                pending.append(('imp', None))
                pending.append(('visit', node[2]))
                pending.append(('visit', node[1]))
        elif action == 'not':
            values.append(('not', values.pop()))
        else:
            right, left = values.pop(), values.pop()
            values.append(('imp', left, right))
    c.need(len(values) == 1, ('skeleton',), 'one normalized Formula pattern')
    return values[0]


def _infer(nodes, boundary, c):
    terms, witness_terms, boundary_terms, substitutions = [], [], [], {}
    next_variable = 0
    for _ in boundary:
        c.tick('fresh_metavariables')
        boundary_terms.append(('v', next_variable))
        next_variable += 1
    for node in nodes:
        c.tick()
        if node['rule_tag'] == 1:
            witness = []
            for _ in node['witness_pattern']:
                c.tick('fresh_metavariables')
                witness.append(('v', next_variable))
                next_variable += 1
            term = _logical(node['subtag'], witness, c)
            witness_terms.append(witness)
        else:
            c.tick('fresh_metavariables')
            term = ('v', next_variable)
            next_variable += 1
            references = []
            for ref in node['references']:
                c.tick()
                references.append((terms if ref['kind'] == 'internal' else boundary_terms)[ref['id']])
            _unify(references[1], ('imp', references[0], term), substitutions, c)
            witness_terms.append(None)
        terms.append(term)
    # Compose every variable substitution, including variables hidden by a link.
    for variable in range(next_variable):
        c.tick()
        _resolve(('v', variable), substitutions, c)
    names, new_boundary, new_nodes = {}, [], []
    for index, term in enumerate(boundary_terms):
        c.tick()
        new_boundary.append(dict(boundary_id=index,
            formula_pattern=_normalize(term, substitutions, names, c)))
    for index, node in enumerate(nodes):
        c.tick()
        formula = _normalize(terms[index], substitutions, names, c)
        witness = None
        if witness_terms[index] is not None:
            witness = []
            for term in witness_terms[index]:
                c.tick()
                witness.append(_normalize(term, substitutions, names, c))
        new_nodes.append(dict(local_id=index, rule_tag=node['rule_tag'], subtag=node['subtag'],
            formula_pattern=formula, witness_pattern=witness, references=node['references']))
    parameters = []
    for index in range(len(names)):
        c.tick()
        parameters.append(dict(id=index, sort='Formula'))
    return parameters, new_boundary, new_nodes


def _check_equations(nodes, boundary, c):
    for node in nodes:
        c.tick('equation_checks')
        if node['rule_tag'] == 1:
            expected = _logical(node['subtag'], node['witness_pattern'], c)
        else:
            formulas = []
            for ref in node['references']:
                c.tick()
                formulas.append((nodes if ref['kind'] == 'internal' else boundary)[ref['id']]['formula_pattern'])
            c.need(_equal(formulas[1], ('imp', formulas[0], node['formula_pattern']), c),
                   ('skeleton', node['local_id']), 'independent ordered MP equation', 'INCONSISTENT_SKELETON')
            continue
        c.need(_equal(expected, node['formula_pattern'], c), ('skeleton', node['local_id']),
               'independent generic logical equation', 'INCONSISTENT_SKELETON')


def _specialize(pattern, original, images, c):
    pending = [(pattern, original)]
    while pending:
        c.tick('specialization_pairs')
        new, old = pending.pop()
        if new[0] == 'param':
            index = new[1]
            if index in images:
                c.need(_equal(images[index], old, c), ('specialization', index),
                       'one exact original-pattern image per generalized parameter', 'INVALID_SPECIALIZATION')
            else:
                images[index] = old
        else:
            c.need(old[0] == new[0] and len(old) == len(new), ('specialization',),
                   'rigid specialization constructor agreement', 'INVALID_SPECIALIZATION')
            for index in range(len(new) - 1, 0, -1):
                c.tick()
                pending.append((new[index], old[index]))


def _patterns(family, c):
    patterns = []
    for row in family['boundary_nodes']:
        c.tick()
        patterns.append(row['formula_pattern'])
    for row in family['internal_nodes']:
        c.tick()
        patterns.append(row['formula_pattern'])
        if row['witness_pattern'] is not None:
            for pattern in row['witness_pattern']:
                c.tick()
                patterns.append(pattern)
    return patterns


def _specialization(generalized, original, c):
    new_patterns, old_patterns = _patterns(generalized, c), _patterns(original, c)
    c.need(len(new_patterns) == len(old_patterns), ('specialization',), 'complete same-skeleton patterns')
    images = {}
    for new, old in zip(new_patterns, old_patterns):
        c.tick()
        _specialize(new, old, images, c)
    c.need(len(images) == len(generalized['parameters']), ('specialization',),
           'every generalized parameter specialized', 'INVALID_SPECIALIZATION')
    for new, old in zip(new_patterns, old_patterns):
        c.tick()
        c.need(_equal(_substitute(new, images, c), old, c), ('specialization',),
               'complete independent original-pattern backprojection', 'INVALID_SPECIALIZATION')
    answer = []
    for index in range(len(generalized['parameters'])):
        c.tick()
        answer.append(dict(parameter_id=index, source_pattern=images[index]))
    return images, answer


def _source_occurrences(generalized, original, specialization, c):
    occurrences, associations = [], []
    for occurrence_index, old in enumerate(original['source_occurrences']):
        c.tick()
        old_images = _binding_images(old['source_bindings'], len(original['parameters']), c,
                                     ('source_occurrences', occurrence_index))
        new_images, binding = {}, []
        for index in range(len(generalized['parameters'])):
            c.tick()
            formula = _substitute(specialization[index], old_images, c)
            new_images[index] = formula
            binding.append(dict(parameter_id=index, formula=formula))
        occurrence = dict(donor_id=old['donor_id'], root_source_row=old['root_source_row'],
            source_to_local=old['source_to_local'], boundary_source_to_port=old['boundary_source_to_port'],
            source_bindings=binding)
        boundary_checks, internal_checks = [], []
        for before, after in zip(original['boundary_nodes'], generalized['boundary_nodes']):
            c.tick('source_backprojection_checks')
            index = before['boundary_id']
            c.need(index == after['boundary_id'] and
                   _equal(_substitute(before['formula_pattern'], old_images, c),
                          _substitute(after['formula_pattern'], new_images, c), c),
                   ('source_occurrences', occurrence_index, 'boundary', index),
                   'every source boundary formula backprojects', 'INVALID_SPECIALIZATION')
            boundary_checks.append(dict(boundary_id=index,
                source_row=old['boundary_source_to_port'][index][0], formula_equal=True))
        for before, after in zip(original['internal_nodes'], generalized['internal_nodes']):
            c.tick('source_backprojection_checks')
            index = before['local_id']
            c.need(index == after['local_id'] and before['rule_tag'] == after['rule_tag']
                   and before['subtag'] == after['subtag'] and
                   _equal(before['references'], after['references'], c),
                   ('source_occurrences', occurrence_index, 'internal', index), 'unchanged typed topology')
            c.need(_equal(_substitute(before['formula_pattern'], old_images, c),
                          _substitute(after['formula_pattern'], new_images, c), c),
                   ('source_occurrences', occurrence_index, 'internal', index),
                   'every source internal formula backprojects', 'INVALID_SPECIALIZATION')
            if before['witness_pattern'] is None:
                c.need(after['witness_pattern'] is None, ('source_occurrences',), 'MP null witness preserved')
            else:
                c.need(len(before['witness_pattern']) == len(after['witness_pattern']),
                       ('source_occurrences',), 'ordered logical witness arity preserved')
                for left, right in zip(before['witness_pattern'], after['witness_pattern']):
                    c.tick('source_backprojection_checks')
                    c.need(_equal(_substitute(left, old_images, c), _substitute(right, new_images, c), c),
                           ('source_occurrences', occurrence_index, 'internal', index),
                           'every source logical witness backprojects', 'INVALID_SPECIALIZATION')
            reference_checks = []
            for position, ref in enumerate(before['references']):
                c.tick('source_backprojection_checks')
                mapping = old['source_to_local'] if ref['kind'] == 'internal' else old['boundary_source_to_port']
                reference_checks.append(dict(position=position, kind=ref['kind'], id=ref['id'],
                    source_row=mapping[ref['id']][0]))
            internal_checks.append(dict(local_id=index, source_row=old['source_to_local'][index][0],
                formula_equal=True, witness_equal=True, reference_checks=reference_checks))
        occurrences.append(occurrence)
        associations.append(dict(occurrence_index=occurrence_index, donor_id=old['donor_id'],
            root_source_row=old['root_source_row'], source_to_local=old['source_to_local'],
            boundary_source_to_port=old['boundary_source_to_port'], original_source_bindings=old['source_bindings'],
            generalized_source_bindings=binding, boundary_checks=boundary_checks, internal_checks=internal_checks))
    return occurrences, associations


def _canonical_id(key, c):
    value = _copy(key, c, False)
    c.tick()
    encoder = json.JSONEncoder(sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False)
    digest = hashlib.sha256()
    for chunk in encoder.iterencode(value):
        c.tick()
        for offset in range(0, len(chunk), 65536):
            c.tick()
            raw = chunk[offset:offset + 65536].encode('ascii')
            digest.update(raw)
            c.costs['canonical_bytes'] += len(raw)
    c.tick()
    return digest.hexdigest()


def infer_schematic_family(family, *, instance, check):
    c = _Call(check)
    try:
        if not callable(check):
            c.fail('INVALID_INPUT', ('check',), 'genuine check callable required')
        c.tick()
        original = _copy(family, c, True)
        nodes, boundary, occurrences = _shape(original, c)
        c.tick()
        actual_version = getattr(instance, 'VERSION', None)
        c.need(type(actual_version) is str and actual_version == _INSTANCE_VERSION,
               ('instance',), 'exact public instance-service VERSION', 'INVALID_DEPENDENCY')
        c.tick()
        matcher = getattr(instance, 'match_receptor', None)
        c.need(callable(matcher), ('instance',), 'public matcher callable', 'INVALID_DEPENDENCY')
        input_guards = []
        for index, occurrence in enumerate(occurrences):
            c.tick()
            images = _binding_images(occurrence['source_bindings'], len(original['parameters']), c,
                                     ('source_occurrences', index))
            input_guards.append(_guard(original, images, matcher, c, index, 'input'))
        parameters, new_boundary, new_nodes = _infer(nodes, boundary, c)
        _check_equations(new_nodes, new_boundary, c)
        key = dict(parameters=parameters, root_local_id=original['root_local_id'],
                   internal_nodes=new_nodes, boundary_nodes=new_boundary)
        generalized = dict(family_key=key, family_id=_canonical_id(key, c),
            parameters=parameters, root_local_id=original['root_local_id'], internal_nodes=new_nodes,
            boundary_nodes=new_boundary, source_occurrences=[], distinct_base_nodes=original['distinct_base_nodes'],
            size_band=original['size_band'], validation_provenance=original['validation_provenance'])
        images, specialization = _specialization(generalized, original, c)
        new_occurrences, source_associations = _source_occurrences(generalized, original, images, c)
        generalized['source_occurrences'] = new_occurrences
        output_guards = []
        for index, occurrence in enumerate(new_occurrences):
            c.tick()
            complete_images = _binding_images(occurrence['source_bindings'], len(parameters), c,
                                              ('source_occurrences', index))
            output_guards.append(_guard(generalized, complete_images, matcher, c, index, 'output'))
        result = dict(schema='FPC-receptor-skeleton-schema-candidate-v1', version=VERSION,
            complete=True, accepted=False, library_admitted=False, method=_METHOD,
            source_family=original, family=generalized, specialization=specialization,
            source_associations=source_associations, input_guards=input_guards, output_guards=output_guards,
            costs={}, scope='Ordinary fixed-skeleton schema inference candidate only; no proof, usable library, contextual use, principal-schema theorem, transfer, GCTS or RL admission.')
        answer = _copy(result, c, False)
        # All counters are read only after the detached output copy is complete.
        c.tick()
        for name in _COST_FIELDS:
            answer['costs'][name] = c.costs[name]
        return answer
    except BaseException as error:
        c.abort(error)
