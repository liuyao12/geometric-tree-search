"""Source-only administrative metadata; never read research data bodies."""
from pathlib import Path
import argparse
import hashlib
import json

ROOT = Path(__file__).resolve().parent
STUDY = ROOT.parent
REPO = STUDY.parents[1]
CONTRACT = ROOT / 'skeleton-schema-whole-feasibility-Source-CONTRACT-v1.json'
HANDOFF = STUDY / 'implementation-B/receptor-skeleton-schema-worker-Source-handoff-v1.json'
EXPECTATIONS = STUDY / 'diagnostics-L/skeleton-schema-whole-feasibility-independent-expectations-v1.json'
PAPER = STUDY / 'review-C/typed-skeleton-schema-whole-feasibility-paper-review-v1.json'
BANK_HANDOFF = STUDY / 'diagnostics-L/receptor-skeleton-schema6-independent-bank-Source-handoff-v1.json'
PROTOCOL = ROOT / 'skeleton-schema-feasibility-protocol-v1.json'
CASE = 'admitted-library-skeleton-schema-feasibility-v1-case-0'
PLAN = ROOT / 'plans' / (CASE + '.json')
ROLES = ('checker', 'builders', 'reference', 'instance', 'tiny_encoder', 'schema', 'schema_bank')


def pin(path):
    path = Path(path)
    body = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def read(path):
    return json.loads(Path(path).read_bytes())


def emit(path, value):
    body = (json.dumps(value, indent=2, sort_keys=True, ensure_ascii=True, allow_nan=False) + '\n').encode()
    with path.open('xb') as stream:
        stream.write(body)
    assert path.read_bytes() == body
    return pin(path)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--acceptance', required=True)
    args = parser.parse_args()
    accepted = read(args.acceptance)
    assert accepted['worker_Source_accepted'] is True
    assert accepted['metadata_helpers_Source_accepted'] is True
    assert accepted['preparer_source'] == pin(__file__)
    for name in ('worker_review', 'helper_review'):
        record = accepted[name]
        assert pin(record['path']) == record
    contract, handoff, bank = read(CONTRACT), read(HANDOFF), read(BANK_HANDOFF)
    assert contract['case_id'] == CASE
    assert accepted['worker_source'] == handoff['Source'] == pin(contract['worker_Source'])
    assert accepted['worker_handoff'] == pin(HANDOFF)
    modules = contract['runtime_modules']
    assert tuple(modules) == ROLES
    for row in modules.values():
        assert pin(row['path']) == row
    authority = contract['input_authority']
    data_paths = {authority['library_result']['path']}
    data_paths.update(row['query']['path'] for row in authority['context_queries'])
    # Only named Source/metadata paths are dereferenced here. Input data pins
    # above are copied literally, never read, hashed, globbed or followed.
    names = [CONTRACT, HANDOFF, EXPECTATIONS, PAPER, BANK_HANDOFF,
             Path(__file__).resolve(), ROOT / 'issue_skeleton_schema_grant_v1.py',
             REPO / 'AGENTS.md', REPO / 'docs/basic-tiling-algorithm.md',
             STUDY / 'implementation-B/receptor-skeleton-schema-API-v1.json',
             STUDY / 'implementation-B/receptor-skeleton-schema-cost-and-fault-manual-v1.json',
             STUDY / 'implementation-B/receptor-skeleton-schema-static-v1.json',
             STUDY / 'implementation-B/receptor-skeleton-schema-dependency-offer-v1.json',
             STUDY / 'implementation-B/receptor-skeleton-schema-Source-handoff-v1.json',
             STUDY / 'implementation-B/receptor-family-and-instance-API-v2.json',
             STUDY / 'review-C/typed-receptor-skeleton-schema-complete-component-Source-review-v1.json',
             STUDY / 'review-C/typed-receptor-skeleton-schema6-independent-bank-complete-Source-review-v1.json',
             ROOT / 'receptor-library-extract-0-Root-complete-whole-admission-v1.json',
             STUDY / 'review-C/typed-receptor-library-extract-0-complete-whole-actual-review-v1.json',
             Path(args.acceptance).resolve()]
    records = list(modules.values()) + [contract['runner'], contract['observer'], contract['python']]
    records += contract['Source_components']
    records += [handoff[k] for k in ('Source', 'API', 'manual', 'static', 'dependency_offer', 'Source_authority')]
    records += [accepted[k] for k in ('worker_review', 'helper_review')]
    names += [Path(row['path']) for row in records]
    unique = {}
    for path in names:
        absolute = str(Path(path).resolve())
        assert absolute not in data_paths
        unique[absolute] = pin(path)
    for row in records:
        assert unique[row['path']] == row
    ids = bank['public_API']['return']['control_ids']
    assert len(ids) == 6
    population = dict(population='skeleton_schema6', control_ids=ids, groups=6,
                      bank_role='schema_bank', subject_role=['schema', 'instance'],
                      scope=bank['public_API']['return']['scope'])
    protocol = dict(schema='Root-FPC-skeleton-schema-feasibility-protocol-v1',
        experiment=contract['experiment'], limits=contract['limits'], module_pins=modules,
        control_populations=[population], job_recipes=[dict(case_id=CASE, stage='schema')],
        metadata=dict(profile='skeleton-schema-whole-feasibility-v1', input_authority=authority,
                      Source_components=contract['Source_components'],
                      reference_integer_policy=['FPC-original-json-integer-policy-v1', 4300]))
    protocol_pin = emit(PROTOCOL, protocol)
    unique[protocol_pin['path']] = protocol_pin
    actual = STUDY / 'actual' / CASE
    assert not actual.exists() and not Path(str(actual) + '.observer').exists()
    plan = dict(schema='proof-search-case-once-plan-v1', case_id=CASE, stage='schema',
        experiment=contract['experiment'], actual_dir=str(actual), worker_path=contract['worker_Source'],
        runner_path=contract['runner']['path'], python=contract['python'],
        files=list(unique.values()), limits=contract['limits'], protocol=protocol_pin,
        profile='skeleton-schema-whole-feasibility-v1', module_pins=modules,
        input_authority=authority, Source_components=contract['Source_components'])
    plan_pin = emit(PLAN, plan)
    receipt = dict(schema='Root-skeleton-schema-study-preparation-v1',
        status='PREPARED_METADATA_NO_GRANT_NO_SCIENTIFIC_EXECUTION',
        plan=plan_pin, protocol=protocol_pin, acceptance=pin(args.acceptance),
        Source_guard_count=len(unique), separate_data_pins=sorted(data_paths),
        data_bodies_read_or_hashed=False, scientific_imports_or_calls=0,
        scope='New seven-role/six-group component and admitted-library profile only; no prior cohort rerun.')
    print(json.dumps(emit(ROOT / 'skeleton-schema-study-preparation-v1.json', receipt)))


if __name__ == '__main__':
    main()
