"""Administrative archive/publication continuation after direct human approval."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent
STUDY = ROOT.parent
REPO = STUDY.parents[1]
P2 = ROOT.parents[1] / 'gcts-batch-20261020/publisher-recovery-6338a77'
CASE = STUDY / 'actual/admitted-library-skeleton-schema-feasibility-v1-case-0'
PRIOR_STAGE = ROOT / 'publication-skeleton-schema-v1'
STAGE = ROOT / 'publication-skeleton-schema-v2'
PAYLOAD = P2 / 'publication-payload-skeleton-schema-v2'
PREFIX = 'docs/research/gcts-rl-renewal/conditional-inventory/'
NAMES = ('point-proof-parallel-progress-v1.html', 'point-proof-skeleton-schema-public-summary-v1.json',
         'point-proof-receptor-library-evidence-v1.zip', 'point-proof-skeleton-schema-evidence-v1.zip')


def raw(path):
    path = Path(path)
    assert path.is_absolute() and path.resolve() == path and path.is_file()
    assert not path.is_symlink() and '.partial' not in path.name
    return path.read_bytes()


def pin(path):
    body = raw(path)
    return dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def js(value):
    return (json.dumps(value, indent=2, ensure_ascii=True, allow_nan=False) + '\n').encode()


def write(path, body):
    with path.open('xb') as stream:
        stream.write(body)
    assert path.read_bytes() == body


def main():
    auth_path = ROOT / 'full-evidence-archive-direct-user-publication-authorization-v1.json'
    authorization = json.loads(raw(auth_path))
    assert authorization['direct_human_answer'] == 'Approve publishing the full archive'
    admission_path = ROOT / 'skeleton-schema-case-0-Root-complete-whole-admission-v1.json'
    admission = json.loads(raw(admission_path))
    assert admission['finite_schema_observation_admitted'] is True
    assert admission['result'] == pin(CASE / 'result.json')
    review_path = Path(admission['complete_C_review']['path'])
    assert admission['complete_C_review'] == pin(review_path)
    assert json.loads(raw(review_path))['review_passed'] is True
    plan_path = ROOT / 'plans' / (CASE.name + '.json')
    plan = json.loads(raw(plan_path))
    audit_path = ROOT / 'skeleton-schema-case-0-Root-passive-whole-audit-v1.json'
    assert admission['passive_audit'] == pin(audit_path)
    audit = json.loads(raw(audit_path))
    prior = Path(authorization['authorized_prior_archive']['path'])
    assert authorization['authorized_prior_archive'] == pin(prior)
    prior_body = raw(prior)
    with zipfile.ZipFile(prior) as bundle:
        old_catalog = json.loads(bundle.read('catalog.json'))
        assert len(bundle.namelist()) == len(set(bundle.namelist())) == len(old_catalog['members']) + 1
        for row in old_catalog['members']:
            body = bundle.read(row['member'])
            assert len(body) == row['bytes'] and hashlib.sha256(body).hexdigest() == row['sha256']
    members, external = {}, []

    def include(path, role, expected=None):
        path = Path(path)
        body = raw(path)
        ref = dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())
        if expected is not None:
            assert ref == {key: expected[key] for key in ('path', 'bytes', 'sha256')}
        try:
            name = 'project/' + path.relative_to(REPO).as_posix()
        except ValueError:
            assert ref == plan['python']
            external.append(dict(role=role, **ref, supplied_separately=True))
            return
        assert not any(part in ('.git', '.aws', '.ssh') for part in path.parts)
        assert path.suffix in ('.py', '.json', '.md', '.bin', '.zip')
        if name in members:
            assert members[name]['ref'] == ref
        else:
            members[name] = dict(role=role, ref=ref, body=body)

    for row in plan['files']:
        include(row['path'], 'exact-current-project-Source-or-metadata-guard', row)
    for row in audit['file_census']:
        include(row['path'], 'complete-current-original-actual-or-observer', row)
    extra = [auth_path, admission_path, review_path, audit_path, plan_path, Path(admission['display_assessment']['path']),
        ROOT / 'grants' / (CASE.name + '.json'), ROOT / 'skeleton-schema-case-0-Root-once-acceptance-v1.json',
        ROOT / 'skeleton-schema-case-0-Root-idle-barrier-v1.json',
        STUDY / 'review-C/typed-skeleton-schema-complete-whole-prospective-review-v1.json',
        ROOT / 'skeleton-schema-study-preparation-v1.json',
        ROOT / 'skeleton-schema-prospective-metadata-Root-passive-audit-v1.json',
        STUDY / 'implementation-B/contextual-library-consumer-and-matched-baseline-DESIGN-v1.json',
        ROOT / 'full-evidence-archive-direct-user-publication-authorization-v1.json',
        ROOT / 'prepare_skeleton_schema_publication_v1.py', Path(__file__).resolve(),
        ROOT / 'publish_skeleton_schema_api_v2.py', ROOT / 'verify_skeleton_schema_live_v2.py', prior]
    for path in extra:
        include(path, 'explicit-current-admission-provenance-or-authorized-prior-archive')
    catalog = dict(schema='Root-skeleton-schema-complete-evidence-catalog-v1',
        issued_utc=datetime.now(timezone.utc).isoformat(), case_id=CASE.name,
        Root_admission=pin(admission_path), complete_C_review=pin(review_path),
        direct_human_archive_authorization=pin(auth_path),
        members=[dict(member=name, role=row['role'], **row['ref']) for name, row in sorted(members.items())],
        external_runtime=external, nested_prior_archive=pin(prior), scientific_replay=False,
        scope='All current40 project guards except externally supplied Python, all25 original actual/observer files, explicit complete admission/review/display/authorization/provenance, and unchanged prior full643-member archive with its donor/cohort evidence. Raw original bodies; no scientific replay.')
    STAGE.mkdir()
    PAYLOAD.mkdir()
    archive_path = STAGE / NAMES[3]
    with zipfile.ZipFile(archive_path, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
        for name, body in [('catalog.json', js(catalog))] + [(name, row['body']) for name, row in sorted(members.items())]:
            info = zipfile.ZipInfo(name, (2026, 10, 24, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            bundle.writestr(info, body, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    with zipfile.ZipFile(archive_path) as bundle:
        assert set(bundle.namelist()) == set(members) | {'catalog.json'}
        for name, row in members.items():
            assert bundle.read(name) == row['body']
    summary = json.loads(raw(PRIOR_STAGE / NAMES[1]))
    summary['evidence_archives'] = [
        dict(name=NAMES[2], bytes=len(prior_body), sha256=hashlib.sha256(prior_body).hexdigest(), scope='Original complete receptor-library evidence with nested prior donor/cohort evidence.'),
        dict(name=NAMES[3], bytes=archive_path.stat().st_size, sha256=pin(archive_path)['sha256'], members=len(members)+1,
             scope='Complete current schema-feasibility evidence plus the unchanged prior archive. External pinned runtime must be supplied separately.')]
    summary['publication_scope'] = 'Readable report, public formulas/aggregate results, and directly user-approved complete evidence archives including Source snapshots, original certificates, logs, reviews and local file paths.'
    page = raw(PRIOR_STAGE / NAMES[0]).decode()
    a = page.index('The closed schema still contains the proper tautology ')
    b = page.index(', which', a)
    page = page[:a] + r'The closed schema still contains the proper tautology \(A\to A\)' + page[b:]
    old_caption = 'Only readable mathematical rows and aggregate observations are published here. New raw evidence, Sources, certificate bytes, execution logs and internal reviews remain local. Earlier milestones below are preserved as dated history.'
    new_caption = ('The complete evidence archives are now public following direct user approval. They contain Source snapshots, original proof certificates, execution logs, complete reviews and local provenance paths. '
        'Download <a href="' + NAMES[3] + '">the complete current schema evidence</a> or <a href="' + NAMES[2] + '">the earlier complete receptor-library evidence</a>. '
        'The current archive includes the earlier archive; both identify the external pinned Python runtime, which is supplied separately. Exact archive sizes and SHA-256 identities are in the public summary. Earlier milestones below retain their historical publication status.')
    assert page.count(old_caption) == 1
    page = page.replace(old_caption, new_caption, 1)
    assert not any(ord(c) < 32 and c not in '\n\t' for c in page)
    assert page.endswith(raw(ROOT / 'publication-transfer-audit-v1' / NAMES[0]).decode().split('<body><main>',1)[1])
    bodies = (page.encode(), js(summary), prior_body, raw(archive_path))
    rows = []
    for name, body in zip(NAMES, bodies):
        if name != NAMES[3]:
            write(STAGE / name, body)
        write(PAYLOAD / name, body)
        rows.append(dict(path=PREFIX + name, root_source=str(STAGE/name), publisher_source=str(PAYLOAD/name),
            bytes=len(body), sha256=hashlib.sha256(body).hexdigest(),
            git_blob_sha1=hashlib.sha1(b'blob ' + str(len(body)).encode() + b'\0' + body).hexdigest()))
    staging = dict(schema='Root-skeleton-schema-four-path-staging-v2', scientific_execution=False,
        admission=pin(admission_path), direct_human_archive_authorization=pin(auth_path),
        old_live_baseline=pin(ROOT / 'publication-transfer-audit-v1' / NAMES[0]),
        prior_unpublished_staging=pin(PRIOR_STAGE / 'P2-staging.json'), files=rows,
        archive_member_count=len(members)+1, archive_members_verified=True,
        prior_archive_members_verified=len(old_catalog['members']), external_runtime=external,
        privacy='Explicit human approval covers the raw research evidence and local provenance. Only the declared task artifacts are included; external runtime is omitted.')
    write(STAGE / 'P2-staging.json', js(staging))
    print(json.dumps(pin(STAGE / 'P2-staging.json')))


if __name__ == '__main__':
    main()
