"""Administrative display of an admitted saved result; no scientific calls."""
from pathlib import Path
import hashlib
import html
import json

ROOT = Path(__file__).resolve().parent
STUDY = ROOT.parent
P2 = ROOT.parents[1] / 'gcts-batch-20261020/publisher-recovery-6338a77'
CASE = STUDY / 'actual/admitted-library-skeleton-schema-feasibility-v1-case-0'
BASE = ROOT / 'publication-transfer-audit-v1/point-proof-parallel-progress-v1.html'
STAGE = ROOT / 'publication-skeleton-schema-v1'
PAYLOAD = P2 / 'publication-payload-skeleton-schema-v1'
PREFIX = 'docs/research/gcts-rl-renewal/conditional-inventory/'
NAMES = ('point-proof-parallel-progress-v1.html', 'point-proof-skeleton-schema-public-summary-v1.json')


def pin(path):
    body = path.read_bytes()
    return dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def write(path, body):
    with path.open('xb') as stream:
        stream.write(body)
    assert path.read_bytes() == body


def js(value):
    return (json.dumps(value, indent=2, ensure_ascii=True, allow_nan=False) + '\n').encode()


def formula(node):
    tag = node[0]
    if tag == 'param':
        return 'ABC'[node[1]]
    if tag == 'pred' and node[2] == []:
        return 'P_{' + str(node[1]) + '}'
    if tag == 'not':
        return r'\neg\bigl(' + formula(node[1]) + r'\bigr)'
    if tag == 'imp':
        return r'\bigl(' + formula(node[1]) + r'\to ' + formula(node[2]) + r'\bigr)'
    raise ValueError('Display supports only this admitted propositional result')


def math(value):
    return r'\(' + html.escape(value) + r'\)'


def main():
    admission_path = ROOT / 'skeleton-schema-case-0-Root-complete-whole-admission-v1.json'
    admission = json.loads(admission_path.read_bytes())
    assert admission['finite_schema_observation_admitted'] is True
    assert admission['result'] == pin(CASE / 'result.json')
    result = json.loads((CASE / 'result.json').read_bytes())
    audit_path = ROOT / 'skeleton-schema-case-0-Root-passive-whole-audit-v1.json'
    assert admission['passive_audit'] == pin(audit_path)
    audit = json.loads(audit_path.read_bytes())
    assert audit['result'] == admission['result']
    metrics, counts = audit['metrics'], audit['counts']
    displays = []
    for group, exercise in zip(result['scientific_result']['generalized_groups'], result['generic_exercise_results']):
        assert group['group_index'] == exercise['group_index']
        family = group['family']
        actual = exercise['instance']['expansion_rows']
        rows = []
        for index, row in enumerate(actual):
            boundary = row['origin_kind'] == 'boundary'
            source = family['boundary_nodes' if boundary else 'internal_nodes'][row['origin_id']]
            rule = 'Hypothesis' if boundary else ('H1' if row['rule_tag'] == 1 and row['subtag'] == 0 else 'H2' if row['rule_tag'] == 1 else 'Modus ponens')
            references = [value + 1 for value in row['references']]
            words = ('Assume the required boundary formula.' if boundary else
                     'Use an instance of the first implication axiom.' if rule == 'H1' else
                     'Use an instance of the second implication axiom.' if rule == 'H2' else
                     'Apply the implication in line ' + str(references[1]) + ' to line ' + str(references[0]) + '.')
            rows.append(dict(line=index + 1, role='boundary' if boundary else 'axiom' if row['rule_tag'] == 1 else 'inference',
                             schematic_latex=formula(source['formula_pattern']), actual_latex=formula(row['formula']),
                             rule=rule, reference_lines=references, English=words))
        displays.append(dict(group=group['group_index'], source_family_indices=group['input_family_indices'],
                             parameters=len(family['parameters']), boundary_ports=len(family['boundary_nodes']),
                             source_occurrences=len(family['source_occurrences']), rows=rows))
    summary = dict(schema='GCTS-proof-skeleton-schema-public-summary-v1', date='2026-10-24',
        classification='Finite schema-inference observation independently reviewed and admitted.',
        counts={key: counts[key] for key in ('scoped_bank_groups','bank_observations','inference_calls','source_instances','generic_instances','exact_key_groups','instance_physical_rows')},
        metrics=metrics, schemas=displays, old_four_family_inventory_unchanged=True,
        holdout_loaded=False, holdout_searched=False, contextual_use=False,
        novelty='Ordinary fixed-proof-structure unification and reusable schema infrastructure; no GCTS/RL search advantage established.',
        limits=['Two generic examples are schema exercises, not solutions of fresh benchmark goals.',
                'Boundary assumptions must have earlier proofs before contextual use.',
                'No proof of most-generality; occurs-check rejection is Source-review-only in this bank.',
                'No new arithmetic or Hilbert geometry result; no finite universal Wang palette.',
                'Prior donor acquisition and library extraction costs are separate; this is no matched speed comparison.'],
        next='Broaden inventory acquisition and implement a shared contextual obligation interface with ordinary lemma reuse as an equally informed control, primitive fallback and checked final-root use.',
        publication_scope='Readable formulas and aggregate observations only. Raw Sources, proof bytes, logs, internal reviews and new raw archive remain local.')
    cards = ''
    for display in displays:
        table = ''
        for row in display['rows']:
            refs = ', '.join(math(str(x)) for x in row['reference_lines'])
            table += '<tr><td>' + math(str(row['line'])) + '</td><td><span class="schema-role ' + row['role'] + '">' + row['rule'] + '</span>' + ('<br>Lines ' + refs if refs else '') + '</td><td>' + math(row['schematic_latex']) + '</td><td>' + html.escape(row['English']) + '</td></tr>'
        actual = ''.join('<li>' + math(row['actual_latex']) + ' — ' + row['rule'] + '</li>' for row in display['rows'])
        title = 'Conditional cluster' if display['boundary_ports'] else 'Closed lemma'
        inputs = ', '.join(math('F_{' + str(x) + '}') for x in display['source_family_indices'])
        cards += '<article class="fragment"><h3>' + title + '</h3><p>Sources ' + inputs + '; ' + math(str(display['parameters'])) + ' formula parameters; ' + math(str(display['boundary_ports'])) + ' boundary ports.</p><div class="schema-scroll"><table><thead><tr><th>Line</th><th>Rule</th><th>Parameterized formula</th><th>English</th></tr></thead><tbody>' + table + '</tbody></table></div><details><summary>Actual checked independent-atom instance</summary><p>Parameter indices map to distinct nullary predicates in the original signature. These lines come from the saved expansion rows, with original byte pairs checked by both validators.</p><ol>' + actual + '</ol></details></article>'
    panel = r'''<style>.schema-scroll{overflow-x:auto}.schema-scroll table{min-width:820px}.schema-role{display:inline-block;padding:3px 7px;border-radius:4px;font-size:13px;font-weight:700}.schema-role.boundary{background:#d8eee8;color:#155d53}.schema-role.axiom{background:#ece3f5;color:#62418a}.schema-role.inference{background:#ffebcd;color:#84501c}.schema-map{display:flex;gap:16px;flex-wrap:wrap;align-items:center;margin:20px 0}.schema-map>div{border:1px solid var(--rule);border-radius:8px;background:#edf4f1;padding:16px;flex:1;min-width:240px}</style>
<section class="panel" id="skeleton-schema-current"><p class="status">Current result · whole schema-feasibility attempt admitted · 24 October 2026 UTC</p>
<h1>Four source fragments become two checked proof schemas</h1>
<p>The program has now executed fixed-proof-skeleton inference on all four admitted fragments. It introduced fresh formula parameters, solved the primitive inference constraints and checked every specialization back to its original source. Two exact structural schemas emerged. All six scoped independent control groups passed, and every original and generic instance was checked by both original validators. Independent whole-evidence review and Root admission are complete.</p>
<div class="schema-map" role="img" aria-label="Original families zero and two yield a conditional cluster; families one and three yield a closed lemma"><div>\(F_0,F_2\) \(\longrightarrow\) conditional cluster<br>\((A\to(B\to A))\to C\ \vdash C\)</div><div>\(F_1,F_3\) \(\longrightarrow\) closed lemma<br>\(\vdash (A\to B)\to(A\to A)\)</div></div>
<p>This is a finite observed generalization result. The formulas were produced by inference from the admitted structures; the manual expectations in the earlier audit were not supplied as theorem targets or proof scripts to the worker. The two generic examples exercise the schemas with independent atoms. They do not solve new benchmark goals.</p>
<h2>Read each cluster line by line</h2><p>The parameterized lines below are decoded from the saved schema patterns. Teal marks a boundary hypothesis, purple an axiom instance and amber an inference. These colors explain roles; they are not learned GCTS markings. References use human-readable line numbers starting at one. Open each instance to inspect the actual checked formulas.</p>'''
    panel += cards
    panel += '<h2>Measured whole attempt</h2><div class="grid"><article class="card"><h3>Original specializations</h3><span class="fact">' + math(str(counts['source_instances'])) + '</span><p>Every admitted source occurrence retained and checked.</p></article><article class="card"><h3>Generic instances</h3><span class="fact">' + math(str(counts['generic_instances'])) + '</span><p>One per exact-key group; three physical primitive rows each.</p></article><article class="card"><h3>Complete observer time</h3><span class="fact">' + math(f"{metrics['observer_elapsed_seconds']:.3f}\\,\\mathrm{{s}}") + '</span><p>Setup, tests, data intake, inference, compilation, checks, output and custody.</p></article></div>'
    panel += '<p>The conservative whole peak was ' + math(str(metrics['conservative_whole_peak_bytes']) + r'\,\mathrm{bytes}') + '. The full result, separate bank and every exported original byte body used ' + math(str(metrics['shared_positive_bytes']) + r'\,\mathrm{bytes}') + ' of the unchanged ' + math(str(metrics['shared_positive_cap_bytes']) + r'\,\mathrm{bytes}') + ' positive-output allowance. Earlier donor acquisition and library extraction costs remain separate. This timing is a feasibility measurement, not a speedup comparison.</p>'
    panel += r'''<div class="notice"><strong>Useful schemas are not yet useful search.</strong> The closed schema still contains the proper tautology (A	o A), which the frozen evaluation input excludes from goal/subformula matching. The conditional schema requires an earlier proof of its boundary; treating that boundary as free would assume the difficult part. The evaluation target remains unopened and unsearched.</div>
<h2>What this contributes, and the next test</h2><p>This establishes a working bridge from acquired proof fragments to parameterized clusters, with source provenance and primitive expansions. Fixed-skeleton unification is ordinary symbolic infrastructure, closely related to condensed detachment and principal-type methods. No most-generality theorem, GCTS marking benefit, trained RL benefit or new arithmetic/Hilbert geometry theorem is claimed.</p><p>The next search experiment needs a broader declared inventory policy and a shared contextual obligation interface. An ordinary lemma-reuse control must receive the same information, keep primitive fallback and show how each used cluster contributes to a complete checked final proof. Costs of acquisition, matching, expansion and verification must remain visible.</p>
<p><a href="point-proof-skeleton-schema-public-summary-v1.json">Public schema formulas and aggregate observations</a> · <a href="#transfer-audit-current">Earlier transfer obstruction and literature</a> · <a href="#receptor-library-current">Original admitted inventory</a></p><p class="caption">Only readable mathematical rows and aggregate observations are published here. New raw evidence, Sources, certificate bytes, execution logs and internal reviews remain local. Earlier milestones below are preserved as dated history.</p></section><p class="notice"><strong>Historical audit below.</strong> Its unexecuted status describes the earlier checkpoint; the current completed schema result is above.</p>'''
    before = BASE.read_bytes()
    assert len(before) == 40818 and hashlib.sha256(before).hexdigest() == '01f202c31b314d06138a3945c0875775aec9de700c30cb4c6f3350437c0621b7'
    added = panel.encode()
    for body in (added, js(summary)):
        for private in (b'/Users/', b'/private/', b'/home/', b'file://', b'traceback', b'PID'):
            assert private not in body
    anchor = b'<body><main>'
    assert before.count(anchor) == 1
    page = before.replace(anchor, anchor + added, 1)
    assert page.replace(added, b'', 1) == before
    STAGE.mkdir()
    PAYLOAD.mkdir()
    rows = []
    for name, body in zip(NAMES, (page, js(summary))):
        for folder in (STAGE, PAYLOAD):
            write(folder / name, body)
        rows.append(dict(path=PREFIX + name, root_source=str(STAGE/name), publisher_source=str(PAYLOAD/name),
                         bytes=len(body), sha256=hashlib.sha256(body).hexdigest(),
                         git_blob_sha1=hashlib.sha1(b'blob ' + str(len(body)).encode() + b'\0' + body).hexdigest()))
    staging = dict(schema='Root-skeleton-schema-two-path-staging-v1', scientific_execution=False,
                   historical_base=pin(BASE), admission=pin(admission_path), files=rows,
                   privacy='Exactly readable HTML and aggregate/formula JSON; no raw or internal records.')
    write(STAGE/'P2-staging.json', js(staging))
    print(json.dumps(pin(STAGE/'P2-staging.json')))


if __name__ == '__main__':
    main()
