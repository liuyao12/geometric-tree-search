"""Root-only -I -S -B bootstrap for the exact passive D21 evaluator.

This adds one reviewed sibling directory only after all three passive Sources
match their pins. Admission/request semantics remain in the reviewed evaluator.
"""
import argparse
import hashlib
from pathlib import Path
import sys

VERSION = 'D21-isolated-passive-evaluation-bootstrap-v1'
STUDY = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-conditional-selector-main-20261021')
IMPLEMENTATION = STUDY / 'implementation-B'
SOURCES = (
    ('admit_conditional_stage_v2.py', 41986, 'bc54a888d14222b038477776f10f71416e913282b72b628dc78a6183f5b6be20'),
    ('conditional_passive_phase_support_v1.py', 19500, '09123b0b15e4d92eb2f1b09d8e66384499c210d68b51aeafc26320ad430523ea'),
    ('admit_conditional_evaluation_v1.py', 13931, '36219227df7eea2bfd9760d825eef415ad88e1f196126f1a5aa0fcde0857c52b'),
)


def main():
    if not (sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode):
        raise ValueError('Root must use the pinned Python with -I -S -B')
    if IMPLEMENTATION != IMPLEMENTATION.resolve() or not IMPLEMENTATION.is_dir():
        raise ValueError('canonical exact current implementation directory only')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--request', required=True)
    arguments = parser.parse_args()
    request = Path(arguments.request)
    if not (request.is_absolute() and request.parent == STUDY / 'root'
            and request == request.resolve() and request.is_file() and not request.is_symlink()
            and '.partial' not in request.name):
        raise ValueError('one canonical complete current Root request path')
    names = []
    for filename, size, sha256 in SOURCES:
        path = IMPLEMENTATION / filename
        if not (path.is_file() and not path.is_symlink() and path == path.resolve()):
            raise ValueError('canonical reviewed passive Source only')
        body = path.read_bytes()
        if len(body) != size or hashlib.sha256(body).hexdigest() != sha256:
            raise ValueError('reviewed passive Source changed: ' + filename)
        name = path.stem
        if name in sys.modules:
            raise ValueError('passive module must not be preloaded: ' + name)
        names.append(name)
    sys.path.insert(0, str(IMPLEMENTATION))
    import admit_conditional_evaluation_v1 as admit
    for name in names:
        if Path(sys.modules[name].__file__).resolve() != IMPLEMENTATION / (name + '.py'):
            raise ValueError('passive import origin differs')
    admit.main(request)


if __name__ == '__main__':
    main()
