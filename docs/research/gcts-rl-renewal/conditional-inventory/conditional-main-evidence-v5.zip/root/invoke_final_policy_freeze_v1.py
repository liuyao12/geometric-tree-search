"""Exact isolated passive final-policy audit bootstrap. No scientific imports."""
from pathlib import Path
import hashlib
import sys

STUDY = Path(__file__).resolve().parents[1]
IMPLEMENTATION = STUDY / 'implementation-B'
PINS = {
    'admit_conditional_stage_v2.py': 'bc54a888d14222b038477776f10f71416e913282b72b628dc78a6183f5b6be20',
    'conditional_passive_phase_support_v1.py': '09123b0b15e4d92eb2f1b09d8e66384499c210d68b51aeafc26320ad430523ea',
    'freeze_conditional_policies_v1.py': '9118fe9ad8feb12eb407972683cca99ae3b017aa8543e20d392c89ba4b811822',
}
for name, expected in PINS.items():
    source = IMPLEMENTATION / name
    assert source.is_file() and not source.is_symlink()
    assert hashlib.sha256(source.read_bytes()).hexdigest() == expected
sys.path.insert(0, str(IMPLEMENTATION))
import freeze_conditional_policies_v1 as component
component.main(STUDY / 'root/final-policy-freeze-request-v1.json')
