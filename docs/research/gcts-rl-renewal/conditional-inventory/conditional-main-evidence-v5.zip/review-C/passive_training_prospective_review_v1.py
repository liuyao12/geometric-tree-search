"""Exact saved Source/plan/custody joins only; no subject invocation or plan materialization."""
import argparse
import hashlib
import json
from pathlib import Path
S=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-conditional-selector-main-20261021');R=S/'root';C=S/'review-C';checked={}
parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--stage-id',required=True);parser.add_argument('--plan-sha256',required=True);parser.add_argument('--receipt-name',required=True);args=parser.parse_args()
assert args.stage_id in ['train-'+str(i) for i in range(3,8)] and len(args.plan_sha256)==64 and Path(args.receipt_name).name==args.receipt_name and args.receipt_name.endswith('.json')
STAGE=args.stage_id;SHARD=int(STAGE.split('-')[1]);PRIOR_EPISODES=2*SHARD;EXPECTED_GUARDS=49+6*(SHARD+2)
def need(v,msg):
    if not v:raise ValueError(msg)
def wire(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def same(a,b):return wire(a)==wire(b)
def pin(p):
    p=Path(p);need(p.is_absolute() and p.resolve()==p and p.is_file() and not p.is_symlink() and '.partial' not in p.name,'canonical ordinary complete body')
    b=p.read_bytes();q=dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
    if str(p) in checked:need(checked[str(p)]==q,'stable repeated pin')
    checked[str(p)]=q;return q
def verify(q):need(set(q)=={'path','bytes','sha256'} and type(q['bytes']) is int and pin(q['path'])==q,'current fullpin');return q
def load(q):
    if isinstance(q,(str,Path)):q=pin(q)
    verify(q);return json.loads(Path(q['path']).read_bytes())
def passed(q):
    d=load(q);need(d['review_passed'] is True and d['checks'] and all(x['passed'] is True for x in d['checks']) and d['failures']==[],'independent allpassed receipt');return d
plan_pin=pin(R/'plans'/(STAGE+'-v1.json'));need(plan_pin['sha256']==args.plan_sha256,'exact offered current plan')
plan=load(plan_pin);template_pin=verify(plan['template']);template=load(template_pin)
family_pin=pin(R/'materialized-main-templates-v1.json');family=load(family_pin)
need(family_pin['sha256']=='0f98e742106ab355bb7e672019b4e616a36b7cbbb3f30a28ce8c71e6212de232' and template_pin in family['templates'],'exact originally frozen template family')
protocol=load(plan['protocol']);closure_pin=pin(R/'main-source-closure-v1.json');closure=load(closure_pin)
need(plan['protocol']['sha256']=='c04ff4523941d5552b6ffee42f73d8a5c189191ea1004b82fc28d0122b3e7422' and closure_pin['sha256']=='bcdb2ea7f67be78eb1d01882cefed5ab55e4a9aad3bb49fc4b99b7b91bf19a88','same frozen protocol/commonclosure')
recipe=next(x for x in protocol['job_recipes'] if x['stage_id']==STAGE);need(same(plan['Root_recipe'],recipe) and same(template['Root_recipe'],recipe),'entire original recipe')
need(plan['case_id']==STAGE and plan['stage']=='train' and plan['schema']=='proof-search-case-once-plan-v1' and template['schema']=='proof-search-case-once-template-v1','typed fourthtrainingidentity')
need(recipe['manifest_indices']==[2*(SHARD%4),2*(SHARD%4)+1] and recipe['pass_index']==SHARD//4,'original manifest/full13rowbounds')
document=load(protocol['phase_inputs']['train'])
shard_document=document['protocol']['shards'][SHARD]
need(shard_document['stage_id']==STAGE and shard_document['manifest_indices']==recipe['manifest_indices'] and shard_document['pass']==recipe['pass_index'],'exact physical shard recipe')
expected_descriptors=shard_document['episodes']
need(recipe['exact_rows']==[document['training'][i]['length'] for i in recipe['manifest_indices']],'unaltered complete target row bounds')
need(same(recipe['episodes'],expected_descriptors),'exact four SthenP descriptors and literal seeds')
ids=['acquire-0','acquire-1']+['train-'+str(i) for i in range(SHARD)];need(recipe['required_upstream_ids']==plan['required_upstream_ids']==ids,'all5orderedpredecessors')
common=closure['common_source'];need(len(common)==47 and closure['runtime_modules']==35,'47common35runtime')
phase_pin=protocol['phase_inputs']['train'];document=load(phase_pin)
need(plan['input_path']==phase_pin['path'] and template['files']==common+[phase_pin],'only current complete physicaltrain input')
need(plan['limits']==protocol['limits'] and plan['experiment_limits']==protocol['experiment_limits'],'all original caps')
need(plan['limits']==dict(custody_seconds=210,log_bytes=4194304,memory_bytes=1073741824,observer_fallback_seconds=225,physical_bytes=134217728,positive_seconds=180,reserved_outer_bytes=9437184,result_bytes=50331648,root_callbacks=400000000,work_seconds=160),'original outerresourcecaps')
need(plan['experiment_limits']==dict(cluster_binding_work=20000,cluster_instances=12,cluster_proposals=16,compile_queries=512,domain_audits=2,marking_certificates=12,marking_proposals=48,marking_work=200000,native_steps=1000000000,search_attempts=600,search_seconds=2.0),'original allsearch/local/marking/nativecaps')
for key in ('entry_path','worker_path','runner_path','runtime_dir','python','native'):
    need(same(plan[key],closure[key]),'same active runtime ABI '+key)
need(plan['modules']==closure['role_mapping'],'same rolemapping')
base_source_review_pin=pin(C/'typed-whole-prospective-initial-acquisition-Source-plan-review-v1.json');passed(base_source_review_pin)
previous_preflight_pin=pin(C/'typed-fourth-training-whole-prospective-Source-plan-review-v1.json');passed(previous_preflight_pin)
sealer_source_review_pin=pin(C/'typed-passive-stage-sealing-component-Source-review-v2.json');ss=passed(sealer_source_review_pin)
need(pin(S/'implementation-B/admit_conditional_stage_v2.py')['sha256']=='bc54a888d14222b038477776f10f71416e913282b72b628dc78a6183f5b6be20','reviewedpositivev2sealerunchanged')
expected_files=[dict(q) for q in template['files']]+[template_pin];receipts=[];chain=[];current_exports={};current_seconds=0.0;prior_policies=None
fields={'stage_id','stage','resource_admitted','stage_complete','plan','result','header','terminal','observer','export_sha256','whole_seconds','whole_peak_bytes','prior_cost_receipts'}
for identity in ids:
    seal_pin=pin(R/'seals'/(identity+'-v1.json'));seal=load(seal_pin);admission_pin=pin(R/'admission'/(identity+'-v1.json'));admission=load(admission_pin)
    need(set(seal)==fields and seal['stage_id']==identity and seal['stage']==('acquire' if identity.startswith('acquire') else 'train') and seal['resource_admitted'] is True and seal['stage_complete'] is True and seal['prior_cost_receipts']==[],'strict current direct13fieldseal')
    need(admission['stage_id']==identity and admission['protocol']==plan['protocol'] and all(admission[k] is True for k in ('admitted','resource_admitted','scientific_qualified','stage_complete')),'current4gateRootadmission')
    for k in fields-{'prior_cost_receipts'}:need(same(seal[k],admission[k]),'same seal/admissionfield '+k)
    c=passed(admission['C_actual_review']);need(c['schema']=='D21-C-conditional-stage-actual-review-v1' and c['Root_admission_issued'] is False and type(c['partial_files_parsed']) is int and c['partial_files_parsed']==0,'independent actualABI')
    for key in ('plan','result','header','terminal','observer'):
        verify(seal[key]);need(c[key]==seal[key],'sameC/custodycomponent');expected_files.append(seal[key])
    expected_files.append(seal_pin);receipts.append(seal_pin)
    prior_plan=load(seal['plan']);need(c['input_pins']==sorted(prior_plan['files'],key=lambda q:q['path']),'exact prior Cguardset')
    for q in c['input_pins']:verify(q)
    need(len(c['complete_actual_file_census'])==14 and admission['complete_actual_file_census']==c['complete_actual_file_census'],'exact priorfull14census')
    for q in c['complete_actual_file_census']:verify(q)
    packet=load(seal['result']);science=packet['scientific_result'];observer=load(seal['observer'])
    need(packet['status']=='COMPLETE' and packet['error'] is None and packet['source_unchanged'] is True and science['stage_complete'] is True and science['job_record_complete'] is True and science['stage_id']==identity and same(science['native_records'],packet['native_queries']),'current complete qualified savedscience')
    need(hashlib.sha256(wire(science['export'])).hexdigest()==seal['export_sha256']==c['export_sha256'],'whole currentexportdigest')
    need(seal['whole_seconds']==observer['elapsed_seconds']==c['whole_seconds'] and seal['whole_peak_bytes']==observer['final_conservative_whole_peak_bytes']==c['whole_peak_bytes'],'literal direct observercost/peak')
    current_seconds+=seal['whole_seconds'];current_exports[identity]=science['export']
    needed=next(r for r in protocol['job_recipes'] if r['stage_id']==identity)['required_upstream_ids']
    need(admission['prior_admissions']==[x['Root_admission'] for x in chain if x['stage_id'] in needed],'complete ordered Rootchain')
    if identity.startswith('train'):
        for engine in ('symbolic','point'):
            policy=science['policies'][engine];need(same(policy,science['export']['policies'][engine]),'same checkedlive/exportpolicy')
            if prior_policies is not None:need(same(policy['history'][:len(prior_policies[engine]['history'])],prior_policies[engine]['history']),'exact immutable olderhistoryprefix')
        prior_policies=science['policies']
    chain.append(dict(stage_id=identity,seal=seal_pin,Root_admission=admission_pin,C_actual_review=admission['C_actual_review'],result=seal['result'],export_sha256=seal['export_sha256'],whole_seconds=seal['whole_seconds'],whole_peak_bytes=seal['whole_peak_bytes']))
need(plan['upstream_receipts']==receipts and plan['files']==expected_files and len(plan['files'])==EXPECTED_GUARDS and len({q['path'] for q in plan['files']})==EXPECTED_GUARDS,'exact materialized79fileorder/all5seals')
for q in plan['files']:verify(q)
expected_plan=dict(template);expected_plan.update(schema='proof-search-case-once-plan-v1',files=expected_files,upstream_receipts=receipts,template=template_pin,scope='Fresh exact one-use whole plan only, requiring independent exact prospective review and Root grant. Every prescribed current predecessor is sealed; no prefix salvage or historical adoption.')
need(same(plan,expected_plan),'wholeplanliteraltemplatecomposition')
latest=current_exports['train-'+str(SHARD-1)];need(len(latest['episode_bindings'])==4*SHARD,'complete12globalbindings')
need([x['global_ordinal'] for x in latest['episode_bindings']]==list(range(4*SHARD)),'original0..11prefixbindings')
for engine in ('symbolic','point'):need(latest['policies'][engine]['engine']==engine and latest['policies'][engine]['episodes']==PRIOR_EPISODES and len(latest['policies'][engine]['history'])==PRIOR_EPISODES,'current6episodesperengine')
need(latest['prior_policy_export_sha256']==chain[-2]['export_sha256'],'latestbundlejoinscurrenttrain1')
need(same(latest['acquisition_exports'],[chain[0]['export_sha256'],chain[1]['export_sha256']]),'bothfreshdonoridentity')
child_paths={q['path'] for q in plan['files']}
need(protocol['phase_inputs']['evaluate']['path'] not in child_paths and protocol['phase_inputs']['acquire']['path'] not in child_paths and not any('/review-C/' in x or '/publication/' in x or 'domain' in Path(x).name or 'report-state' in x or 'reader-request' in x for x in child_paths),'no new heldout/report/domain/fullreviewbodyinchildclosure')
for path in (S/'actual'/STAGE,S/'actual'/(STAGE+'.observer'),R/'grants'/(STAGE+'-v1.json'),R/'admission'/(STAGE+'-v1.json'),R/'seals'/(STAGE+'-v1.json')):need(not path.exists(),'futureownedoutputs/grantabsent')
for q in tuple(checked.values()):need(pin(q['path'])==q,'finalstablecurrentSourcesandchain')

checks=[
 ('exact-plan-frozen-template-and-current-guards',f'Exact {STAGE} plan joins its original frozen template family and complete protocol recipe. All {EXPECTED_GUARDS} ordered guards are current: 47 common Sources, one full physical training input, its own template and six component/seal guards for each of {len(ids)} prescribed predecessors. Whole plan equals only the reviewed materialization additions.'),
 ('complete-current-Root-seal-C-custody-chain',f'All {len(ids)} ordered current Root admissions retain four true gates, strict 13-field seals, shared five components, independent C actual receipts, full 14-file censuses, Source guards, canonical exports and direct observer samples. The latest issued admission/seal joins the complete prior actual. No missing, historical or shortened predecessor and no prefix salvage.'),
 ('original-four-episodes-and-policy-prefix',f'Original manifest indices {recipe["manifest_indices"]}, pass {recipe["pass_index"]}, full row bounds {recipe["exact_rows"]} and four S-then-P descriptors {expected_descriptors} match the frozen protocol and full physical training document. Latest bundle holds all {4*SHARD} earlier global bindings and {PRIOR_EPISODES} episodes per engine with exact older history prefixes, heads, prior-bundle and both fresh-donor hashes. No numeric/RNG/policy replay or outcome forecast.'),
 ('unchanged-active-Source-ABI-caps-and-phase-privacy','Current entry, worker, 35 runtime modules, role mapping, Native identities, custodians, protocol, materializer and positive v2 sealer reuse independent Source reviews by raw equality. Original 600-attempt/2-second local, 512-query/1e9-step Native and 160/180/210/225-second whole gates plus memory/output/log/callback/reserve bounds remain. Current child guards exclude report, evaluation, domain and full C-review bodies.'),
 ('prospective-only-before-new-Root-barrier-and-grant',f'{STAGE} actual/observer/grant/admission/seal paths are absent. All current controls, Host/full-region/Native proof checks, Root snapshots, pools and history qualifications must occur inside a future once actual, followed by a separate exact actual review. C issues no grant, admission, fit claim, retry, reduced population or future evaluation authority. Fresh all-peer/browser/network/preview tools-idle barrier is required before Root grants execution.')]
ordinal={3:'fourth',4:'fifth',5:'sixth',6:'seventh',7:'eighth'}[SHARD]
receipt=dict(schema='D21-C-'+ordinal+'-training-whole-prospective-Source-plan-review-v1',review_passed=True,plan=plan_pin,template=template_pin,template_family=family_pin,protocol=plan['protocol'],Source_closure=closure_pin,initial_whole_Source_review=base_source_review_pin,previous_whole_prospective_review=previous_preflight_pin,positive_sealer_Source_review=sealer_source_review_pin,guard_count=EXPECTED_GUARDS,common_guard_count=47,current_phase_inputs=1,input_pins=sorted(plan['files'],key=lambda q:q['path']),required_upstream_ids=ids,upstream=chain,episode_descriptors=expected_descriptors,limits=plan['limits'],experiment_limits=plan['experiment_limits'],prior_policy_episodes_per_engine=PRIOR_EPISODES,prior_global_episode_bindings=4*SHARD,unique_prior_direct_observer_sample_seconds=current_seconds,checks=[dict(id=k,passed=True,finding=v) for k,v in checks],failures=[],scientific_calls=0,helper_invocations=0,materializer_invocations=0,subject_replays=0,grants_issued=0,Root_admission_issued=False,partial_files_parsed=0,scope='Prospective exact current whole plan only. No actual execution, fit prediction, current stage admission or future train/evaluation/retry authority. Root must coordinate a fresh idle barrier and one-use grant.',review_program=pin(Path(__file__).resolve()),predecessor_review_program=pin(C/'passive_fourth_training_prospective_review_v1.py'),review_parameters=dict(stage_id=STAGE,plan_sha256=args.plan_sha256,receipt_name=args.receipt_name),tools_idle_after_freeze=True)
output=C/args.receipt_name
with output.open('xb') as f:f.write((json.dumps(receipt,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode())
print(json.dumps(pin(output)))
