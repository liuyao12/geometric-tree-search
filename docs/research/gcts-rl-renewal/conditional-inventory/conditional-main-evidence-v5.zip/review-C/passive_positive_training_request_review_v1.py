"""Reusable C-owned exact saved-JSON positive-request joins; never invokes the sealer."""
import argparse
import hashlib
import json
from pathlib import Path
S=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-conditional-selector-main-20261021');R=S/'root';C=S/'review-C';checked={}
a=argparse.ArgumentParser(description=__doc__);a.add_argument('--stage-id',required=True);a.add_argument('--request-sha256',required=True);a.add_argument('--receipt-name',required=True);args=a.parse_args()
assert args.stage_id in ['train-'+str(i) for i in range(3,8)] and len(args.request_sha256)==64 and Path(args.receipt_name).name==args.receipt_name and args.receipt_name.endswith('.json')
def need(v,msg):
    if not v:raise ValueError(msg)
def wire(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def same(x,y):return wire(x)==wire(y)
def digest(v):return hashlib.sha256(wire(v)).hexdigest()
def pin(p):
    p=Path(p);need(p.is_absolute() and p.resolve()==p and p.is_file() and not p.is_symlink() and '.partial' not in p.name,'ordinary complete rawbody')
    b=p.read_bytes();q=dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
    if str(p) in checked:need(checked[str(p)]==q,'stablecurrentpin')
    checked[str(p)]=q;return q
def verify(q):need(set(q)=={'path','bytes','sha256'} and type(q['bytes']) is int and pin(q['path'])==q,'strictcurrentpin');return q
def load(q):
    if isinstance(q,(str,Path)):q=pin(q)
    verify(q);return json.loads(Path(q['path']).read_bytes())
def passed(q):
    d=load(q);need(d['review_passed'] is True and d['checks'] and all(x['passed'] is True for x in d['checks']) and d['failures']==[],'completeallpassedCreceipt');return d
identity=args.stage_id;shard=int(identity.split('-')[1]);request_pin=pin(R/'sealing-requests'/(identity+'-v1.json'));need(request_pin['sha256']==args.request_sha256,'exactofferedrequest')
request=load(request_pin);need(set(request)=={'schema','protocol','plan','result','header','terminal','observer','C_actual_review','upstream'} and request['schema']=='D21-passive-stage-admission-request-v1','exactninekeyv2request')
source_pin=pin(S/'implementation-B/admit_conditional_stage_v2.py');api_pin=pin(S/'implementation-B/passive-stage-sealing-executable-API-v2.json');source_review_pin=pin(C/'typed-passive-stage-sealing-component-Source-review-v2.json');passed(source_review_pin)
need(source_pin['sha256']=='bc54a888d14222b038477776f10f71416e913282b72b628dc78a6183f5b6be20' and api_pin['sha256']=='38147530934808c780f8501e5fbd55b0a8c094c93ba31ea004e54c1108cecde9' and source_review_pin['sha256']=='40b266341bf550ae5a441ff06edc77f9e896cfd0ba8751dba624b6306c6c40dd','reviewedv2Source/APIunchanged')
plan=load(request['plan']);review=passed(request['C_actual_review']);packet=load(request['result']);science=packet['scientific_result'];export=science['export'];observer=load(request['observer']);load(request['header']);load(request['terminal']);protocol=load(request['protocol'])
need(plan['case_id']==identity and plan['stage']=='train' and plan['protocol']==request['protocol']==review['protocol'] and request['protocol']['sha256']=='c04ff4523941d5552b6ffee42f73d8a5c189191ea1004b82fc28d0122b3e7422','currentstageprotocol')
need(review['schema']=='D21-C-conditional-stage-actual-review-v1' and review['stage_id']==identity and all(review[k] is True for k in ('review_passed','resource_admitted','scientific_qualified','stage_complete')) and review['Root_admission_issued'] is False and type(review['partial_files_parsed']) is int and review['partial_files_parsed']==0,'completepositiveCactualABI')
for k in ('plan','result','header','terminal','observer'):verify(request[k]);need(request[k]==review[k],'exactrequest/Ccomponent '+k)
need(review['input_pins']==sorted(plan['files'],key=lambda q:q['path']) and len(plan['files'])==49+6*(shard+2),'exactcurrentSourceguardset')
for q in plan['files']:verify(q)
census=review['complete_actual_file_census'];need(len(census)==14,'full14census')
for q in census:verify(q)
actual_paths=sorted(str(p) for directory in (S/'actual'/identity,S/'actual'/(identity+'.observer')) for p in directory.rglob('*') if p.is_file())
need([q['path'] for q in census]==actual_paths,'completecurrentphysicalcensus')
need(packet['status']=='COMPLETE' and packet['error'] is None and packet['source_unchanged'] is True and science['stage_id']==identity and science['stage_complete'] is True and science['job_record_complete'] is True and digest(export)==review['export_sha256'],'samecompletecheckedexport')
need(review['whole_seconds']==observer['elapsed_seconds'] and review['whole_peak_bytes']==observer['final_conservative_whole_peak_bytes'],'literalobservercost/peak')
need(export['policies']==science['policies'] and len(export['episode_bindings'])==4*(shard+1) and export['episode_bindings']==science['episode_bindings'],'allcurrentbindingsandheads')
required=['acquire-0','acquire-1']+['train-'+str(i) for i in range(shard)];need(plan['required_upstream_ids']==required and len(request['upstream'])==len(required),'allorderedprerequisites')
receipts=[];exports=[];admissions=[];seconds=0.0;seal_fields={'stage_id','stage','resource_admitted','stage_complete','plan','result','header','terminal','observer','export_sha256','whole_seconds','whole_peak_bytes','prior_cost_receipts'}
for name,pair,declared in zip(required,request['upstream'],plan['upstream_receipts'],strict=True):
    need(set(pair)=={'admission','seal'} and pair['seal']==declared and pair['admission']['path']==str(R/'admission'/(name+'-v1.json')),'exactorderedpair')
    seal=load(pair['seal']);admission=load(pair['admission']);need(set(seal)==seal_fields and seal['stage_id']==admission['stage_id']==name and seal['prior_cost_receipts']==[],'currentstrict13fieldseal')
    need(admission['protocol']==request['protocol'] and all(admission[k] is True for k in ('admitted','resource_admitted','scientific_qualified','stage_complete')),'positiveRootpredecessorgates')
    for k in seal_fields-{'prior_cost_receipts'}:need(same(seal[k],admission[k]),'directsharedsealfield '+k)
    previous=passed(admission['C_actual_review']);need(all(previous[k] is True for k in ('resource_admitted','scientific_qualified','stage_complete')),'independentpriorqualification')
    for k in ('plan','result','header','terminal','observer'):verify(seal[k]);need(previous[k]==seal[k],'priorfivecomponents')
    old=load(seal['result']);oldexport=old['scientific_result']['export'];need(digest(oldexport)==seal['export_sha256']==previous['export_sha256'],'currentpriorexport')
    need(seal['whole_seconds']==load(seal['observer'])['elapsed_seconds']==previous['whole_seconds'],'samepriorobservercost')
    receipts.append(seal);exports.append(oldexport);admissions.append(pair['admission']);seconds+=seal['whole_seconds']
need(science['cumulative_costs']['receipts']==export['cost_receipts']==receipts and science['cumulative_costs']['stage_ids']==required and same(science['cumulative_costs']['whole_seconds'],seconds),'directSourceorderedcostfold')
need(export['acquisition_exports']==[digest(v) for v in exports[:2]] and export['prior_policy_export_sha256']==digest(exports[-1]),'freshdonorsandlatestpolicybundle')
need(export['episode_bindings'][:4*shard]==exports[-1]['episode_bindings'],'immutableearlierbindings')
for engine in ('symbolic','point'):
    policy=export['policies'][engine];need(policy['episodes']==len(policy['history'])==2*(shard+1) and policy['history'][:2*shard]==exports[-1]['policies'][engine]['history'],'fullpriorhistoryandcurrent2append')
child={q['path'] for q in plan['files']};need(protocol['phase_inputs']['evaluate']['path'] not in child and not any('/review-C/' in p or '/publication/' in p or 'domain' in Path(p).name for p in child),'no forbiddenreport/eval/domainbodyinchildguard')
for p in (R/'admission'/(identity+'-v1.json'),R/'seals'/(identity+'-v1.json')):need(not p.exists(),'exclusiveRootoutputsabsent')
for q in tuple(checked.values()):need(pin(q['path'])==q,'finalstablecurrentinputs')
checks=[dict(id='exact-current-v2-Source-API-and-request',passed=True,finding='The reviewed v2 helper, API and Source PASS remain exact. This current nine-key request binds the fixed protocol, original plan, five exact actual components and current independent C receipt. No helper substitution or invocation.'),dict(id='complete-current-C-stage-gates-guards-and-census',passed=True,finding=f'Current C receipt has all four positive gates, nonempty passed checks, no failures, exactly {len(plan["files"])} sorted plan-file guards, full 14-file current census, integer-zero partial parsing and no C-issued Root admission. All component hashes, complete export digest, exact observer sample and conservative peak join.'),dict(id='all-ordered-current-predecessor-and-policy-bindings',passed=True,finding=f'All {len(required)} original ordered predecessor pairs retain positive Root admissions, strict 13-field seals, current C components and export identities. Current policies preserve {2*shard} episodes per engine and all {4*shard} earlier bindings, append two actual updates each, and export {2*(shard+1)} per engine/{4*(shard+1)} bindings. Both fresh donor identities and the latest policy bundle match; no shortened or historical adoption.'),dict(id='direct-cost-fold-and-physical-phase-boundary',passed=True,finding=f'Current science and export carry all {len(receipts)} direct predecessor receipts in original order. Exact Source 0.0 += observer-cost accumulation is retained without duplicate nested costs. Current physical training input and active Source closure remain exact; report, evaluation, domain and full C-review bodies stay outside child guards. No numeric/RNG/Graph or scientific replay.'),dict(id='exclusive-output-and-limited-prospective-authority',passed=True,finding='Current stage Root admission and seal paths are absent. This receipt qualifies only the exact passive request; Root alone may invoke the reviewed sealer once. C issues no admission, grant, later plan or retry authority.')]
receipt=dict(schema='D21-C-positive-'+('fourth' if shard==3 else 'training-shard')+'-training-sealer-request-review-v1',stage_id=identity,stage='train',review_passed=True,request=request_pin,protocol=request['protocol'],plan=request['plan'],result=request['result'],C_actual_review=request['C_actual_review'],sealer_Source=source_pin,sealer_API=api_pin,sealer_Source_review=source_review_pin,upstream=request['upstream'],Source_guard_count=len(plan['files']),complete_actual_census_count=14,export_sha256=review['export_sha256'],prior_policy_export_sha256=export['prior_policy_export_sha256'],ordered_predecessor_observer_sample_seconds=seconds,whole_seconds=review['whole_seconds'],whole_peak_bytes=review['whole_peak_bytes'],checks=checks,failures=[],Root_admission_issued=False,grants_issued=0,helper_invocations=0,scientific_calls=0,scientific_imports=0,subject_replays=0,partial_files_parsed=0,scope='Independent prospective exact positive current training request review only. Prior actual and Source qualification are reused by exact raw equality; no sealer/scientific replay. Root alone owns exclusive admission/seal; later plans/grants/actuals remain separate.',review_program=pin(Path(__file__).resolve()),tools_idle_after_freeze=True)
output=C/args.receipt_name
with output.open('xb') as f:f.write((json.dumps(receipt,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode())
print(json.dumps(pin(output)))
