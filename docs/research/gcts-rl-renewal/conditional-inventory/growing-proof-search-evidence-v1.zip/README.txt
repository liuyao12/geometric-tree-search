Z growing proof search: COMPLETE ORIGINAL EVIDENCE

Extract this independent normal DEFLATE ZIP with standard tools.
MANIFEST.json maps every original archive member to its absolute source path, full byte extent and SHA256.
PACKAGING-INPUT.json is the exact frozen Root-admitted input cut.
Scientific JSON/gzip/Source/certificates/logs are preserved as original bytes; no science is rerun.
Qualification and main study are distinct complete attempts with all refusals and failure controls retained.
Platform runtime binaries and prior full archives are not bundled; external dependencies have explicit links/pins.
Future Git repositories, publication/TLS/Pages/browser receipts, payload twins and this ZIP are excluded to avoid cycles.

Complete Z qualification-001 and study-001 physical originals, including raw gzip carriers, full proof/check receipts, logs, owned custody and every retained refusal/failure control.
All Z current, historical negative and unrun Source variants/APIs/diffs/contracts, immutable master, plans, spent grants/consumes, original outer captures and current adoptions present at the recorded cut.
Current main fifteen Source roles and fifty metadata refs are pinned individually; complete qualification closure, six original W donor raw proofs and the exact 344-byte bootstrap are included.
Complete exact named Z independent peer/support directories and direct named inherited Source/manual/adoption packets are included. Original absolute paths remain in the manifest; archive member names are unique safe relative paths.
Prior entire Y evidence archive and platform runtime binaries are external pinned dependencies, not recursively bundled. No project functions are imported or executed.
Final package preparation will use a fresh external output directory, full DEFLATE CRC and original byte/SHA readback for every member. No summary replaces a raw original. ZIP cap is 64 MiB; a larger result is a refusal, never an omitted subset.
Final whole main scientific and reader-content Root admissions are included; output-002 HTML/results/projection receipt and all older renderer/template/output variants are preserved. Full local QA76 plus focused7 and both screenshots are included.
The whole final mathematical and final reader-content independent peer directories and all packager Source/API/handoff/static/prospective records available before this final manifest are included. This exact final manifest is added by the builder as PACKAGING-INPUT.json. Later assembly captures/readback/package-peer/adoption records remain outside this self-excluding archive cut.
