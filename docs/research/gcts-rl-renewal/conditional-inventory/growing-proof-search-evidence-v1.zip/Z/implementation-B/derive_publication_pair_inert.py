"""Literal administrative Source derivation and static metadata only."""
from pathlib import Path
import ast,symtable,hashlib,json,difflib
Z=Path('/private/tmp/gcts-growing-proof-obligations-20261028-v1');Y=Path('/private/tmp/gcts-receptor-family-generation-20261028-v1');O=Z/'implementation-B';R=Z/'root'
H=lambda b:hashlib.sha256(b).hexdigest()
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':H(b)}
results=[]
for kind,oldname,newname,oldbytes,oldsha in [
 ('publisher','publish_receptor_family_proof_search_git_v3.py','publish_growing_proof_search_git_v1.py',29317,'a786d5661d8e4276493285ded4b02da5d6a65249bbb4090ce58597df3fe3a96c'),
 ('TLS','verify_receptor_family_proof_search_live_v3.py','verify_growing_proof_search_live_v1.py',14338,'23ceee8e85a500f2d375a3775ed17b0332254c98a8a383e5531cb0eeaed3d5bf')]:
 oldp=Y/'root'/oldname;newp=R/newname;a=oldp.read_text();assert pin(oldp)['bytes']==oldbytes and pin(oldp)['sha256']==oldsha;assert not newp.exists();x=a;reps=[]
 def replace(before,after):
  global x
  n=x.count(before)
  assert n>0,(kind,before)
  x=x.replace(before,after);reps.append({'before':before,'after':after,'occurrences':n})
 replace(str(Y),str(Z))
 replace(oldname,newname)
 replace('receptor-family-proof-search','growing-proof-search')
 if kind=='publisher':
  replace('RECEPTOR-FAMILY-PROOF-SEARCH-GIT-PUBLISHER-v3','Z-GROWING-PROOF-SEARCH-GIT-PUBLISHER-v1')
  replace('isolated-publication-git-v1.git','isolated-growing-proof-search-git-v1.git')
  replace('de2eb75a462a0964ba0fe5de4569198d5618af0e','72874f77c0cad6ad31c55f1165c5908f91615ff3')
  replace('eefd5c92cca02218044ec0af0338004b5713f7a0','0d8b2317696fd794c5d371cb861f9459c935a161')
  replace('Publish receptor-family proof search results and full evidence','Publish growing proof search results and full evidence')
  replace('The failed Git Data API grant stays spent.','All earlier publication grants stay spent.')
  replace('not a replay of the failed API authority','not a reuse of any earlier authority')
 else:replace('RECEPTOR-FAMILY-PROOF-SEARCH-LIVE-TLS-v3','Z-GROWING-PROOF-SEARCH-LIVE-TLS-v1')
 # Exact full schema tokens retain a unique invertible mapping.
 schema_values=sorted({n.value for n in ast.walk(ast.parse(x))if isinstance(n,ast.Constant)and type(n.value)is str and n.value.startswith(('Root-growing-proof-search-','C-growing-proof-search-'))})
 for value in schema_values:
  after='Z-growing-proof-search-'+value.split('growing-proof-search-',1)[1]
  replace(value,after)
 newp.write_text(x);inverse=x
 for row in reversed(reps):
  assert inverse.count(row['after'])==row['occurrences'];inverse=inverse.replace(row['after'],row['before'])
 assert inverse==a
 oldtree=ast.parse(a,str(oldp));newtree=ast.parse(x,str(newp));sym=symtable.symtable(x,str(newp),'exec');unused=compile(x,str(newp),'exec');del unused
 assert ast.dump(ast.parse(inverse),include_attributes=True)==ast.dump(oldtree,include_attributes=True)
 fp=O/(kind+'-Y3-to-Z1-forward.patch');ip=O/(kind+'-Y3-to-Z1-inverse.patch')
 fp.write_text(''.join(difflib.unified_diff(a.splitlines(True),x.splitlines(True),fromfile=str(oldp),tofile=str(newp))))
 ip.write_text(''.join(difflib.unified_diff(x.splitlines(True),a.splitlines(True),fromfile=str(newp),tofile=str(oldp))))
 units=[]
 def call(n):
  if isinstance(n,ast.Name):return n.id
  if isinstance(n,ast.Attribute):return call(n.value)+'.'+n.attr
  return ast.unparse(n)
 def walk(n,path):
  for c in ast.iter_child_nodes(n):
   if isinstance(c,(ast.FunctionDef,ast.ClassDef)):
    name=path+'.'+c.name if path else c.name;raw='\n'.join(x.splitlines()[c.lineno-1:c.end_lineno]).encode();units.append({'name':name,'line':c.lineno,'end':c.end_lineno,'raw_no_final_LF_sha256':H(raw),'plain_AST_sha256':H(ast.dump(c,include_attributes=False).encode()),'signature':ast.unparse(c.args)if isinstance(c,ast.FunctionDef)else None,'calls':sorted({call(k.func)for k in ast.walk(c)if isinstance(k,ast.Call)})});walk(c,name)
   else:walk(c,path)
 walk(newtree,'');scopes=[]
 def table(t,path):
  entries=[]
  for n in sorted(t.get_identifiers()):
   v=t.lookup(n);entries.append({'name':n,'parameter':v.is_parameter(),'referenced':v.is_referenced(),'assigned':v.is_assigned(),'global':v.is_global(),'local':v.is_local(),'free':v.is_free(),'nonlocal':v.is_nonlocal(),'imported':v.is_imported()})
  raw=(json.dumps(entries,sort_keys=True,indent=2,allow_nan=False)+'\n').encode();scopes.append({'path':path,'kind':t.get_type(),'line':t.get_lineno(),'identifiers':len(entries),'complete_symbol_entry_sha256':H(raw)})
  for i,c in enumerate(t.get_children()):table(c,path+'/'+c.get_name()+':'+str(c.get_lineno())+':'+str(i))
 table(sym,'module')
 results.append({'kind':kind,'ancestor':pin(oldp),'Source':pin(newp),'exact_literal_replacements':reps,'forward':pin(fp),'inverse':pin(ip),'whole_raw_inverse_exact':True,'whole_positioned_AST_inverse_exact':True,'current_AST_sha256':H(ast.dump(newtree,include_attributes=False).encode()),'all_units':units,'all_symbol_scopes':scopes,'lines':len(x.splitlines()),'static_checks':{'parse':'PASS','symtable':'PASS','unused_compile_no_execution':'PASS'}})
p=O/'Z-Git-publication-normal-TLS-complete-literal-static-preservation-v1.json';body={'schema':'Z-Git-publication-normal-TLS-complete-literal-static-preservation-v1','pairs':results,'activity':{'Git_network_publisher_TLS_Source_scientific_functions':0,'Source_module_import_execution':0,'fixtures_probes_models':0,'ancestor_Source_edits':0},'scope':'All changes are explicitly listed invertible literal replacements. No callable behavior/caps/control flow changed. Source authoring/static operations only.'};p.write_bytes((json.dumps(body,sort_keys=True,indent=2,allow_nan=False)+'\n').encode());print(json.dumps({'Sources':[v['Source']for v in results],'static':pin(p),'units':[len(v['all_units'])for v in results],'scopes':[len(v['all_symbol_scopes'])for v in results]},sort_keys=True))
