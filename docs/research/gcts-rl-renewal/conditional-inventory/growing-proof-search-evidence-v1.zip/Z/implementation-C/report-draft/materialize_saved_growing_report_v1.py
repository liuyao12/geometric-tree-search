"""Passive saved-record projection only. Never import or call a scientific module."""
import argparse
from collections import Counter
import gzip
import hashlib
import io
import json
from pathlib import Path

ROOT = Path('/private/tmp/gcts-growing-proof-obligations-20261028-v1')
VERSION = 'Z-SAVED-GROWING-REPORT-v1'
LANES = ('GROWTH_POINT_LEX', 'MATCHED_DEPTH_TREE_CONTROL')
BODY_CAP = 67108864
HTML_CAP = 1048576
JSON_CAP = 8388608
MAIN_PIN = (79637, '03a60a6d78ddaa89b6089027f8d0fad0c9a30fef020d8249f6e252caa4adf55b')
MAIN_RAW = (518631, '6983f6f0fdf5525069176db76797a6557c667389fb9a586b3d4b1f2175f5b4d3')


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def raw(value):
    return (json.dumps(value, ensure_ascii=True, sort_keys=True, separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')


def sha(body):
    return hashlib.sha256(body).hexdigest()


class Saved:
    def __init__(self):
        self.reads = {}

    def body(self, path, pin=None, actual=False):
        path = Path(path)
        require(path.is_absolute() and path.resolve().is_relative_to(ROOT.resolve()), 'read outside explicit Z root')
        if actual:
            require(path.resolve().is_relative_to((ROOT / 'actual').resolve()), 'artifact outside actual root')
        require(path.stat().st_size <= BODY_CAP, 'stored input body cap')
        body = path.read_bytes()
        ref = {'path': str(path), 'bytes': len(body), 'sha256': sha(body)}
        if pin is not None:
            require((ref['bytes'], ref['sha256']) == pin, 'input pin mismatch: ' + str(path))
        prior = self.reads.get(str(path))
        require(prior is None or prior == ref, 'input changed between reads')
        self.reads[str(path)] = ref
        return body

    def artifact(self, ref):
        require(type(ref) is dict and set(ref) == {'name', 'stored', 'encoding', 'raw_bytes', 'raw_sha256'}, 'artifact descriptor shape')
        stored = ref['stored']
        require(type(stored) is dict and set(stored) == {'path', 'bytes', 'sha256'}, 'rawref shape')
        body = self.body(stored['path'], (stored['bytes'], stored['sha256']), actual=True)
        if ref['encoding'] == 'gzip-json':
            with gzip.GzipFile(fileobj=io.BytesIO(body), mode='rb') as stream:
                decoded = stream.read(BODY_CAP + 1)
        else:
            require(ref['encoding'] == 'json', 'artifact encoding')
            decoded = body
        require(len(decoded) <= BODY_CAP and (len(decoded), sha(decoded)) == (ref['raw_bytes'], ref['raw_sha256']), 'raw artifact pin')
        value = json.loads(decoded)
        require(raw(value) == decoded, 'noncanonical artifact JSON')
        return value

    def document(self, path):
        return json.loads(self.body(path))

    def postcheck(self):
        for path, ref in self.reads.items():
            body = Path(path).read_bytes()
            require((len(body), sha(body)) == (ref['bytes'], ref['sha256']), 'post-render source change')


def same(left, right, reason):
    require(raw(left) == raw(right), reason)


def native(saved, receipt, proof, theory, goal):
    require(receipt['status'] == 'VERIFIED', 'unverified native summary')
    full = saved.artifact(receipt['receipt_ref'])
    require(full['status'] == 'VERIFIED' and type(full['native']['value']) is int and full['native']['value'] == 1, 'native acceptance association')
    require(full['independent']['status'] == 'VERIFIED', 'independent kernel association')
    same(full['proof'], proof, 'native proof mismatch')
    same(full['theory'], theory, 'native theory mismatch')
    same(full['goal'], goal, 'native goal mismatch')
    return receipt


def proof_tree(tree, proof):
    """Only project and cross-join actual saved tree fields; no prover or decoder."""
    require(type(tree) is dict and len(tree['site_to_line']) == len(proof) == len(tree['placements']), 'saved tree extent')
    require(sorted(i for _, i in tree['site_to_line']) == list(range(len(proof))), 'saved site/line bijection')
    require(sorted(p['id'] for p in tree['placements']) == tree['selected'], 'saved selected placement join')
    by_site = dict(tree['site_to_line'])
    require('' in by_site and by_site[''] == len(proof) - 1, 'saved root final line')
    for placement in tree['placements']:
        site = json.loads(placement['id'])[0]
        require(site in by_site, 'saved anchor/site join')
        marks = dict(placement['m'])
        same(json.loads(marks[site]), proof[by_site[site]]['formula'], 'saved marking/formula join')
    return tree


def control_tree(depth, selected, details, proof):
    return proof_tree({'root': '', 'max_depth': depth, 'selected': selected,
                       'site_to_line': details['site_to_line'], 'node_count': details['tree_nodes'],
                       'max_used_depth': details['maximum_site_depth'], 'placements': details['candidate_bindings'],
                       'totals': details['totals'], 'marks': details['marks']}, proof)


def project_lane(saved, summary, preparation, original, depth):
    row = saved.artifact(summary['ref'])
    for key in ('id', 'lane', 'status', 'verified', 'original_status'):
        same(row[key], summary[key], 'summary/full lane association')
    out = {'status': row['status'], 'original_status': row['original_status'], 'verified': row['verified'],
           'seconds': row.get('search_seconds'), 'reason': row.get('reason') or (row.get('result') or {}).get('reason'),
           'source_ref': summary['ref'], 'coarse_proof': [], 'original_proof': [], 'tree': None,
           'statistics': summary.get('statistics'), 'event_extent': summary.get('event_extent'),
           'rollback_extent': summary.get('rollback_extent'), 'provider': summary.get('provider'),
           'factory_seconds': row.get('factory_seconds'), 'factory_audit_seconds': row.get('factory_audit_seconds'),
           'tree_audit_decode_seconds': row.get('tree_audit_decode_seconds'),
           'checkpoint_load_seconds': row['checkpoint_load_seconds'],
           'checks': {'factory': row.get('factory_audit'), 'tree': row.get('tree_audit')}, 'lowering': None}
    if not row['verified']:
        require(row.get('positive') is None or not row['positive'].get('verified', False), 'hidden positive record')
        out['unverified_decoded_ref_scope'] = 'Raw SAT/DERIVABLE without all verification gates is not displayed as a certificate.'
        return out
    positive = row['positive']
    require(positive['verified'] and positive['original_status'] == 'VERIFIED', 'positive original gate')
    coarse, original_proof = positive['coarse_proof'], positive['original_proof']
    decoded = row['decoded']
    same(decoded['proof'], coarse, 'decode/coarse proof join')
    require(decoded['status'] == 'UNVERIFIED_CERTIFICATE' and row['tree_audit']['status'] == 'VERIFIED', 'selected tree audit gate')
    same(row['tree_audit']['proof'], coarse, 'tree audit proof join')
    tree = proof_tree(decoded['tree'], coarse)
    selected = row['result']['selected'] if row['lane'] == LANES[0] else row['result']['details']['selected']
    same(selected, tree['selected'], 'actual point/control selected join')
    extended = preparation['application']['theory']
    native(saved, positive['coarse_check'], coarse, extended, original['goal'])
    native(saved, positive['original_check'], original_proof, original['theory'], original['goal'])
    require(positive['lowering']['status'] == 'COMPLETE' and positive['lowering_audit']['status'] == 'VERIFIED', 'lowering gate')
    same(positive['lowering']['value']['proof'], original_proof, 'lowered original proof join')
    same(coarse[-1]['formula'], original['goal'], 'coarse goal')
    same(original_proof[-1]['formula'], original['goal'], 'original goal')
    out.update(coarse_proof=coarse, original_proof=original_proof, tree=tree,
               checks={**out['checks'], 'coarse': positive['coarse_check'], 'original': positive['original_check']},
               lowering={'value': positive['lowering']['value'], 'audit': positive['lowering_audit'],
                         'seconds': positive['lowering_seconds'], 'source_ref': positive.get('ref')})
    return out


def qualification(saved, worker):
    experiment = worker['experiment']
    full = saved.artifact(experiment['qualification_ref'])
    require(full['result']['status'] == 'PASS' and full['result']['counts']['emissions'] == 41, 'qualification whole cohort')
    cases = []
    checks = {(x['case'], x['label']): x['check'] for x in full['native_checks']}
    for item in full['records']:
        record = saved.artifact(item['ref'])
        certificates = record.get('native_certificates', [])
        if not certificates:
            continue
        require(len(certificates) == 2, 'qualification pair extent')
        lanes = {}
        for index, cert in enumerate(certificates):
            proof, problem = cert['proof'], cert['problem']
            check = native(saved, checks[(item['id'], cert['label'])], proof, problem['theory'], problem['goal'])
            if index == 0:
                same(record['decoded']['proof'], proof, 'qualification point decode')
                tree = proof_tree(record['decoded']['tree'], proof)
                same(record['result']['selected'], tree['selected'], 'qualification actual point selection')
                status = record['result']['status']
            else:
                same(record['control']['proof'], proof, 'qualification control proof')
                tree = control_tree(record['depth'], record['control']['details']['selected'], record['control_audit']['details'], proof)
                status = record['control']['status']
            lanes[LANES[index]] = {'status': status, 'original_status': 'VERIFIED', 'verified': True,
                                  'coarse_proof': proof, 'original_proof': proof, 'tree': tree,
                                  'source_ref': item['ref'], 'checks': {'native': check}, 'lowering': None,
                                  'reason': None, 'seconds': None}
        cases.append({'id': item['id'], 'qualification': True, 'group': 'Qualification',
                      'purpose': record['fixture_scope'], 'problem': certificates[0]['problem'],
                      'depth': record['depth'], 'lemma_bindings': [], 'lanes': lanes})
    require(len(cases) == 4 and sorted(len(c['lanes'][LANES[0]]['coarse_proof']) for c in cases) == [1, 2, 3, 9], 'qualification four proof extents')
    return cases, {'counts': full['result']['counts'], 'scope': full['result']['scope'],
                   'native_memo': experiment['native_memo'], 'source_ref': experiment['qualification_ref']}


def build(saved, admission_path):
    main_body = saved.body(ROOT / 'actual/study-001/worker-result.json.gz', MAIN_PIN, actual=True)
    main_raw = gzip.decompress(main_body)
    require((len(main_raw), sha(main_raw)) == MAIN_RAW, 'main raw worker pin')
    worker = json.loads(main_raw)
    require(worker['status'] == 'COMPLETE' and worker['experiment']['status'] == 'COMPLETE', 'whole worker completion')
    experiment = worker['experiment']
    qworker = saved.document(ROOT / 'actual/qualification-001/worker-result.json')
    qcases, qsummary = qualification(saved, qworker)
    observer = saved.document(ROOT / 'actual/study-001/observer-result.json')
    require(observer['status'] == 'COMPLETE' and observer['returncode'] == 0, 'owned observer completion')
    admission = None if admission_path is None else saved.document(admission_path)
    bank_record = saved.artifact(experiment['bank_ref'])
    require(bank_record['audit']['status'] == 'VERIFIED' and bank_record['result']['status'] == 'COMPLETE', 'bank gate')
    bank = bank_record['result']['value']['lemmas']
    require(len(bank) == 4, 'bank extent')
    preparations = {p['id']: p for p in experiment['preparations']}
    cases = []
    for result in experiment['results']:
        prep = saved.artifact(result['preparation_ref'])
        same(prep, {k: v for k, v in preparations[result['id']].items() if k != 'preparation_ref'}, 'full preparation association')
        require(set(result['lanes']) == set(LANES), 'two complete lane positions')
        group = 'Arithmetic' if 'arith-' in result['id'] else 'Typing' if 'typing-' in result['id'] else 'Incidence'
        case = {'id': result['id'], 'qualification': False, 'group': group,
                'problem': result['original'], 'depth': result['depth'],
                'preparation_status': prep['status'], 'preparation_seconds': prep['preparation_seconds'],
                'build_seconds': prep.get('build_seconds'), 'build_costs': prep.get('build_costs'),
                'catalogue_audit_seconds': prep.get('catalogue_audit_seconds'), 'zero_audit_seconds': prep.get('zero_audit_seconds'),
                'checkpoint_load_seconds': result['shared_checkpoint_load_seconds'], 'preparation_ref': result['preparation_ref'],
                'lemma_bindings': prep.get('application', {}).get('lemma_bindings', []), 'lanes': {}}
        for lane in LANES:
            case['lanes'][lane] = project_lane(saved, result['lanes'][lane], prep, result['original'], result['depth'])
        cases.append(case)
    require(len(cases) == len(preparations) == 15 and len({c['id'] for c in cases}) == 15, 'all fifteen cases')
    counts = {lane: dict(Counter(c['lanes'][lane]['status'] for c in cases)) for lane in LANES}
    positives = sum(c['lanes'][lane]['verified'] for c in cases for lane in LANES)
    prep_seconds = sum(p['preparation_seconds'] for p in preparations.values())
    build_seconds = sum(p.get('build_seconds', 0) for p in preparations.values())
    main_memo = {k: v for k, v in experiment['native_memo'].items() if k != 'requests'}
    cost = {'observer_seconds': observer['whole_observer_seconds'], 'worker_terminal': observer['worker_terminal'],
            'experiment_seconds': experiment['seconds'], 'peak_rss_bytes': observer['wait4_peak_bytes'],
            'shared_preparation_seconds': prep_seconds, 'raw_build_seconds_nested_in_preparation': build_seconds,
            'shared_checkpoint_load_seconds': sum(c['checkpoint_load_seconds'] for c in cases),
            'native_preparation_seconds': experiment['native_preparation_seconds'], 'native_memo': main_memo,
            'historical_donor_acquisition_seconds': experiment['historical_acquisition_seconds']}
    scope = 'Saved data projection only; no scientific module imports, rule execution, solver, VM or checker replay. Whole raw records remain archive-linked. Admission is external.'
    provenance = {'admission_status': 'PENDING' if admission is None else 'ROOT_ADMISSION_SUPPLIED',
                  'main_admission': admission, 'qualification_prerequisite': experiment['qualification_prerequisite'],
                  'main_worker': saved.reads[str(ROOT / 'actual/study-001/worker-result.json.gz')],
                  'qualification': qsummary, 'archive_cut': 'PREPUBLICATION; archive self, later administrative/live receipts excluded and retained separately',
                  'scope': scope}
    findings = [f"All fifteen current catalogues completed. Across the thirty main positions, GCTS returned {counts[LANES[0]].get('SAT', 0)} verified point proofs and {counts[LANES[0]].get('UNKNOWN', 0)} resource unknowns. The matched-depth control returned {counts[LANES[1]].get('DERIVABLE', 0)} verified proofs and {counts[LANES[1]].get('NOT_DERIVABLE', 0)} finite-inventory, finite-depth negatives.",
                'The five GCTS successes comprise three former training assertions and two former heldout assertions. No policy is trained here. The control finds every point-positive assertion in this cohort and five further certificates.',
                'For nested-function typing, the actual GCTS tree has twelve coarse lines and lowers to six original lines. The control has four coarse lines and lowers to nine. Minimum coarse tree size does not minimize the later primitive expansion.']
    assessment = ['The new contribution is a qualified growing-obligation interface and checked search certificates in that model, not an advantage over goal-directed proof search. Complete provider contacts, markings and frontier decisions are explicit; the point engine still spends substantial work registering alternatives that the formula-directed control handles compactly.',
                  'Finite depth and the declared goal-dependent formula inventory limit both searches. A control negative cannot establish unrestricted first-order nonprovability. The same certified four-lemma bank is shared by both methods, so this experiment does not isolate a lemma-acquisition benefit.',
                  'The old Y assertions provide regression and transfer evidence. Changed model, depth and preparation costs prevent an apples-to-old-row timing claim. Receptor-family cluster execution and learning in the growing model remain future work.']
    cost_notes = [f"The original observer wall time was {cost['observer_seconds']:.6f} seconds; the experiment field was {experiment['seconds']:.6f} seconds. Fresh-child peak RSS was {cost['peak_rss_bytes']:,} bytes.",
                  f"Shared current preparation across fifteen assertions took {prep_seconds:.6f} seconds. Raw catalogue build time was {build_seconds:.6f} seconds inside that preparation, not a separate additive wall total. Independent generation/schema audits, extension and checkpoint work are included in preparation.",
                  f"Main native verification used {main_memo['request_count']} requests, {main_memo['executions']} fresh executions and {main_memo['hits']} exact within-run memo hits; unique execution time was {main_memo['execution_seconds']:.6f} seconds. Checking and lowering happen after the two-second search windows. Historical donor acquisition ({experiment['historical_acquisition_seconds']:.6f} seconds) is additional and is not free.",
                  'A single shared checkpoint is loaded per case; its cost is recorded once although both lane records reference it. Per-lane factory auditing, tree/decode verification and lemma lowering are retained separately. These nested timers must not be summed as independent walls.',
                  'Of the ten point unknowns, eight hit MAX_CANDIDATES, one MAX_WORK and one WALL_SECONDS. Every outcome is retained. The two-second windows are cooperative; validation, cleanup and serialization can exceed them.']
    reader = {'findings': findings, 'assessment': assessment, 'cost_notes': cost_notes,
              'qualification_summary': 'Whole qualification: forty solves, forty-one retained records, 161 full observations, eight native requests (four fresh executions plus four exact memo hits). The four proof pairs have one, two, three and nine lines.',
              'bank': bank, 'provenance': provenance, 'cases': qcases + cases}
    return {'schema': 'Z-growing-proof-search-public-results-v1', 'status': 'DRAFT_PENDING_ADMISSION' if admission is None else 'ROOT_ADMISSION_SUPPLIED',
            'renderer_version': VERSION, 'reader': reader, 'main_counts': counts, 'main_positive_pairs': positives,
            'costs': cost, 'design': experiment['design'], 'limits': experiment['limits'],
            'qualification': qsummary, 'scope': scope}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True)
    parser.add_argument('--template', required=True)
    parser.add_argument('--admission')
    args = parser.parse_args()
    saved = Saved()
    source = Path(__file__).resolve()
    source_body = saved.body(source)
    template_body = saved.body(args.template)
    require(len(template_body) <= HTML_CAP, 'HTML cap')
    output = Path(args.output)
    require(output.is_absolute() and output.resolve().is_relative_to((ROOT / 'implementation-C/report-draft').resolve()), 'new owned draft output required')
    require(not output.exists(), 'output must be fresh')
    result = build(saved, args.admission)
    result['provenance_sources'] = list(saved.reads.values())
    result_body = raw(result)
    require(len(result_body) <= JSON_CAP, 'JSON cap; refuse rather than omit')
    saved.postcheck()
    output.mkdir()
    files = []
    for name, body in [('growing-proof-search-v1.html', template_body), ('growing-proof-search-results-v1.json', result_body)]:
        target = output / name
        with target.open('xb') as stream:
            stream.write(body)
        require(target.read_bytes() == body, 'output readback')
        files.append({'path': str(target), 'bytes': len(body), 'sha256': sha(body)})
    saved.postcheck()
    receipt = {'schema': 'Z-passive-reader-projection-receipt-v1', 'status': 'COMPLETE',
               'source': {'path': str(source), 'bytes': len(source_body), 'sha256': sha(source_body)},
               'files': files, 'inputs': list(saved.reads.values()), 'counts': result['main_counts'],
               'positive_pairs': result['main_positive_pairs'], 'scope': result['scope']}
    receipt_body = raw(receipt)
    with (output / 'reader-projection-receipt-v1.json').open('xb') as stream:
        stream.write(receipt_body)
    print(json.dumps({'status': 'COMPLETE', 'files': files, 'receipt_bytes': len(receipt_body)}, sort_keys=True))


if __name__ == '__main__':
    main()
