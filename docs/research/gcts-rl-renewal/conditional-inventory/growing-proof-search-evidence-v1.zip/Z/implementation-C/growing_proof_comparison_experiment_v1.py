"""Inert Z growing-proof comparison. No loader, IO, or target proof scripts.

The separate owned runner supplies pinned modules, metadata and six raw donors.
Only _read_donors/_Native are reused from admitted X; X.run is never invoked.
"""
import gzip
import hashlib
import io
import json
import time

VERSION = 'Z-GROWING-PROOF-COMPARISON-EXPERIMENT-v1'


def _need(ok, reason):
    if not ok:
        raise RuntimeError(reason)


def _raw(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')


def _sha(value):
    return hashlib.sha256(_raw(value)).hexdigest()


def _copy(value):
    return json.loads(_raw(value))


def _complete(receipt, reason):
    _need(receipt['status'] == 'COMPLETE' and receipt['value'] is not None, reason)
    return receipt['value']


def _compact(row):
    answer = {k: v for k, v in row.items() if k not in ('result', 'positive', 'decoded', 'tree_audit', 'model', 'factory', 'factory_audit')}
    if row.get('result') is not None:
        answer['statistics'] = row['result'].get('stats', row['result'].get('costs'))
        answer['raw_reason'] = row['result'].get('reason')
        answer['event_extent'] = row['result'].get('event_extent')
        answer['rollback_extent'] = row['result'].get('rollback_extent')
    if row.get('positive') is not None:
        answer['positive_ref'] = row['positive']['ref']
        answer['coarse_lines'] = len(row['positive']['coarse_proof'])
        answer['original_lines'] = len(row['positive'].get('original_proof', []))
    return answer


def run(modules, context, emit, budget, call):
    started = time.perf_counter()
    _need(type(context) is dict and set(context) == {'plan', 'sources', 'metadata', 'donor_stored'}, 'exact main context')
    names = ('cases', 'design', 'experiment_limits', 'donor_manifest', 'donor_admission')
    cases, design, limits, donor_manifest, donor_admission = (json.loads(context['metadata'][k]) for k in names)
    _need(design['schema'] == 'Z-prospective-growing-main-design-v1' and design['depth'] == 8
          and design['search_seconds'] == 2 and len(cases) == 15 and len(design['case_order']) == 15
          and set(design['case_order']) == set(cases) and len(set(design['case_order'])) == 15
          and design['lane_order'] == ['GROWTH_POINT_LEX', 'MATCHED_DEPTH_TREE_CONTROL']
          and design['generation_profile'] == {'ui_rounds': 2, 'bridge_arity': 2, 'max_tautology_atoms': 12}, 'closed same-inventory depth comparison')
    _need(len(context['metadata']['cases']) == design['cases']['bytes']
          and hashlib.sha256(context['metadata']['cases']).hexdigest() == design['cases']['sha256'], 'unchanged15assertion inputs')
    prerequisite = json.loads(context['metadata']['qualification_prerequisite'])
    _need(set(prerequisite) == {'schema', 'status', 'sources', 'admission'}
          and prerequisite['schema'] == 'Z-main-qualified-components-prerequisite-v1'
          and prerequisite['status'] == 'ADMITTED_COMPLETE_QUALIFICATION'
          and _raw(prerequisite['sources']) == _raw({k: context['plan']['sources'][k] for k in ('engine', 'adapter', 'growth_audit')})
          and _raw(prerequisite['admission']) == _raw(context['plan']['metadata']['qualification_admission']), 'current components previously qualified')
    admitted = json.loads(context['metadata']['qualification_admission'])
    _need(type(admitted) is dict and type(admitted.get('status')) is str
          and admitted['status'].startswith('ADMITTED'), 'whole qualified prerequisite, no prefix')
    input_image = _raw(cases)

    def charge(units):
        _need(type(units) is int and units >= 0, 'logical charge units')
        budget()

    def transform(role, name, *args, **kwargs):
        kwargs.setdefault('charge', charge)
        return call(role, name, *args, **kwargs)

    donors, donor_join = call('native_bridge', '_read_donors', context, donor_manifest, donor_admission, budget)
    donor_image = _raw(donors)
    emit('original-six-donor-associations', {'donors': donors, 'joins': donor_join, 'admission': donor_admission})
    before = time.perf_counter()
    program = call('tree_machine', 'Compiler', context['sources']['real_parser'].decode('utf-8')).declaration()
    call('tree_machine', 'validate', program)
    program_ref = emit('fixed-native-program', program)
    native_preparation_seconds = time.perf_counter() - before
    native = call('native_bridge', '_Native', context['sources'], limits, program, emit, budget, call)
    bank_return = transform('inventory', 'build_bank', donors, limits['bank'])
    bank = _complete(bank_return, 'complete unchanged primitive bank')
    _need(len(bank['donors']) == 6 and len(bank['lemmas']) == 4, 'same acquired information')
    bank_check = transform('bank_verifier', 'verify_bank', donors, bank, limits=limits['bank_verifier'])
    _need(bank_check['status'] == 'VERIFIED', 'complete bank provenance reconstruction')
    bank_native = []
    for i, lemma in enumerate(bank['lemmas']):
        theory = dict(_copy(lemma['signature']), axioms=_copy(lemma['required_axioms']))
        bank_native.append(native.check('bank-lemma-' + str(i), {'theory': theory, 'goal': lemma['goal']}, lemma['proof']))
    bank_ref = emit('current-bank-and-native-checks', {'result': bank_return, 'audit': bank_check, 'native': bank_native})
    bank_image = _raw(bank)

    zero_checks = []
    def logical_check(theory, proof, target, checker_limits):
        """Host B8 only; large zero batches never enter the byte/C1 parser."""
        budget()
        _need(_raw(checker_limits) == _raw(limits['zero_checker']), 'separate closed zero-schema B8 limits')
        before = time.perf_counter()
        receipt = call('fol_checker', 'check', theory, proof, target, checker_limits)
        record = {'theory': theory, 'proof': proof, 'target': target, 'limits': checker_limits,
                  'receipt': receipt, 'seconds': time.perf_counter() - before,
                  'scope': 'Independent semantic audit of every emitted zero; not a searched target proof or C1 run.'}
        ref = emit('zero-schema-batch-' + str(len(zero_checks)), record)
        zero_checks.append({'ref': ref, 'lines': len(proof), 'status': receipt['status'], 'seconds': record['seconds']})
        return receipt


    # Bounded in-memory current-wire checkpoints. No historical model cache or IO.
    packed_total = 0
    prepared = {}
    preparation_summaries = []
    for identity in design['case_order']:
        budget()
        given = cases[identity]
        before = time.perf_counter()
        item = {'id': identity, 'original': given, 'depth': design['depth'],
                'status': 'UNKNOWN_EXTENSION'}
        extension = transform('inventory', 'extend_theory', given['theory'], bank, limits['extend'])
        item['extension'] = extension
        if extension['status'] == 'COMPLETE':
            application = extension['value']
            audit = transform('bank_verifier', 'verify_extension', given['theory'], bank, application,
                              limits=limits['bank_verifier'])
            item.update(application=application, extension_audit=audit, status='UNKNOWN_EXTENSION_AUDIT')
            _need(audit['status'] in ('VERIFIED', 'UNKNOWN'), 'same eligible extension independently checked')
            if audit['status'] == 'VERIFIED':
                problem = {'theory': application['theory'], 'goal': given['goal'], 'profile': design['generation_profile']}
                item.update(application=application, extension_audit=audit, problem=problem, status='UNKNOWN_BUILD')
                t = time.perf_counter()
                built = call('compiler', 'build_basis', problem['theory'], problem['goal'], problem['profile'], limits['basis'])
                item.update(build_seconds=time.perf_counter() - t,
                            build_ref=emit(identity + '-whole-build', built),
                            build_status=built['status'], build_reason=built['reason'],
                            build_costs=built['costs'], build_optimization=built['optimization'])
                if built['status'] == 'COMPLETE':
                    compiled, generation = built['compiled'], built['generation']
                    _need(generation is not None and generation['profile'] == problem['profile'], 'complete Y generation metadata')
                    core = {k: v for k, v in compiled.items() if k not in ('costs', 'scope')}
                    _need(_sha(core) == generation['compiled_core_sha256'], 'actual semantic-core generation binding')
                    t = time.perf_counter()
                    audit = call('catalogue_audit', 'verify_compiled', problem, compiled, generation, limits=limits['audit'])
                    item.update(catalogue_audit=audit, catalogue_audit_seconds=time.perf_counter() - t,
                                generation=generation, status='UNKNOWN_AUDIT')
                    _need(audit['status'] in ('VERIFIED', 'UNKNOWN'), 'invalid catalogue aborts whole study')
                    if audit['status'] == 'VERIFIED':
                        t = time.perf_counter()
                        semantic = call('catalogue_audit', 'verify_zero_schemas', problem, compiled, logical_check,
                                        limits['zero_checker'], limits=limits['audit'])
                        item.update(zero_audit=semantic, zero_audit_seconds=time.perf_counter() - t)
                        _need(semantic['status'] in ('VERIFIED', 'UNKNOWN'), 'invalid zero schema aborts whole study')
                        if semantic['status'] == 'VERIFIED':
                            t = time.perf_counter(); raw = _raw(compiled); packed = None
                            item['status'] = 'UNKNOWN_CHECKPOINT'
                            if len(raw) <= limits['checkpoint']['max_raw_bytes']:
                                packed = gzip.compress(raw, mtime=0)
                                if (len(packed) <= limits['checkpoint']['max_packed_bytes']
                                        and packed_total + len(packed) <= limits['checkpoint']['max_total_packed_bytes']):
                                    packed_total += len(packed)
                                    item['_packed'] = packed
                                    item['checkpoint'] = {'raw_bytes': len(raw), 'raw_sha256': hashlib.sha256(raw).hexdigest(),
                                        'packed_bytes': len(packed), 'packed_sha256': hashlib.sha256(packed).hexdigest(),
                                        'problem_sha256': _sha(problem), 'generation_sha256': _sha(generation)}
                                    item['status'] = 'COMPLETE'
                            item['checkpoint_seconds'] = time.perf_counter() - t
                            del raw, packed
                    del compiled, core
                else:
                    _need(built['status'] == 'UNKNOWN' and built['compiled'] is None and built['generation'] is None,
                          'no partial generator prefix')
                del built
        else:
            _need(extension['status'] == 'UNKNOWN' and extension['value'] is None, 'owned extension refusal only')
        item['preparation_seconds'] = time.perf_counter() - before
        summary = {k: v for k, v in item.items() if k != '_packed'}
        item['preparation_ref'] = emit(identity + '-whole-preparation', summary)
        prepared[identity] = item
        preparation_summaries.append(dict(summary, preparation_ref=item['preparation_ref']))
        budget()
    _need(len(prepared) == 15, 'all compile/audit attempts before main comparisons')

    def restore(item):
        if item['status'] != 'COMPLETE': return None, 0.0
        t = time.perf_counter(); budget(); expected = item['checkpoint']; packed = item['_packed']
        _need(len(packed) == expected['packed_bytes'] and hashlib.sha256(packed).hexdigest() == expected['packed_sha256']
              and _sha(item['problem']) == expected['problem_sha256']
              and _sha(item['generation']) == expected['generation_sha256'], 'immutable current checkpoint scope')
        with gzip.GzipFile(fileobj=io.BytesIO(packed), mode='rb') as stream:
            raw = stream.read(expected['raw_bytes'] + 1)
        _need(len(raw) == expected['raw_bytes'] and hashlib.sha256(raw).hexdigest() == expected['raw_sha256'],
              'full bounded checkpoint decode')
        compiled = json.loads(raw); budget()
        return compiled, time.perf_counter() - t

    def positive(identity, item, proof):
        coarse = native.check(identity + '-coarse', item['problem'], proof)
        t = time.perf_counter()
        lower = transform('inventory', 'lower_proof', item['original']['theory'], bank, item['application'], proof, limits['lower'])
        result = {'coarse_proof': proof, 'coarse_check': coarse, 'lowering': lower,
                  'lowering_seconds': time.perf_counter() - t, 'verified': False, 'original_status': 'UNKNOWN_LOWERING'}
        if lower['status'] == 'COMPLETE':
            value = lower['value']
            audit = transform('bank_verifier', 'verify_lowering', item['original']['theory'], bank,
                              item['application'], proof, value, limits=limits['bank_verifier'])
            result['lowering_audit'] = audit
            _need(audit['status'] in ('VERIFIED', 'UNKNOWN'), 'invalid lowering aborts whole study')
            if audit['status'] == 'VERIFIED':
                _need(value['theory'] == item['original']['theory']
                      and value['goal'] == item['original']['goal'], 'exact original target binding')
                original = native.check(identity + '-original', item['original'], value['proof'])
                result.update(verified=True, original_status='VERIFIED', original_proof=value['proof'],
                              original_check=original)
            else:
                result['original_status'] = 'UNKNOWN_LOWERING_AUDIT'
        else:
            _need(lower['status'] == 'UNKNOWN' and lower['value'] is None, 'owned expansion refusal only')
        result['ref'] = emit(identity + '-whole-positive', result)
        return result

    def check_positive(identity, item, compiled, selected, row):
        t = time.perf_counter()
        decoded = call('adapter', 'decode', compiled, item['depth'], selected, limits['decode'])
        row['decoded'] = decoded
        _need(decoded['status'] in ('UNVERIFIED_CERTIFICATE', 'UNKNOWN'), 'owned decode result')
        audit = call('growth_audit', 'verify_tree', compiled, item['depth'], selected,
                     decoded if decoded['status'] == 'UNVERIFIED_CERTIFICATE' else None, limits=limits['growth_audit'])
        row.update(tree_audit=audit, tree_audit_decode_seconds=time.perf_counter() - t)
        _need(audit['status'] in ('VERIFIED', 'UNKNOWN'), 'invalid selected tree aborts whole cohort')
        if decoded['status'] == 'UNKNOWN':
            _need(decoded['proof'] is None and decoded['tree'] is None, 'no decoder prefix')
            row['original_status'] = 'UNKNOWN_DECODE'
            return
        if audit['status'] == 'UNKNOWN':
            row['original_status'] = 'UNKNOWN_TREE_AUDIT'
            return
        _need(_raw(audit['proof']) == _raw(decoded['proof'])
              and _raw(decoded['target']) == _raw(item['original']['goal']), 'independent postorder proof and target')
        if row['lane'] == 'GROWTH_POINT_LEX':
            tree = decoded['tree']; model = row['model']
            certificate = {'capacity': 2, 'roots': model['roots'], 'seed': model['seed'],
                           'placements': tree['placements'], 'totals': tree['totals'], 'marks': tree['marks']}
            _need(_raw(row['result']['certificate']) == _raw(certificate), 'actual point certificate equals independent rooted tree')
            if row['factory_audit']['status'] == 'UNKNOWN':
                row['original_status'] = 'UNKNOWN_FACTORY_AUDIT'
                return
        else:
            _need(_raw(row['result']['proof']) == _raw(decoded['proof']), 'control actual duplicated tree proof')
        row['positive'] = positive(identity, item, decoded['proof'])
        row['verified'] = row['positive']['verified']
        row['original_status'] = row['positive']['original_status']

    def point(identity, item, compiled, load_seconds):
        row = {'id': identity, 'lane': 'GROWTH_POINT_LEX', 'status': 'NOT_RUN_' + item['status'],
               'verified': False, 'original_status': 'NO_CERTIFICATE', 'preparation_ref': item['preparation_ref'],
               'checkpoint_load_seconds': load_seconds, 'scope': 'Qualified parametric complete incident inventory; full main graph state-by-state independent enumeration is not performed. Positive selected trees are independently audited and kernel checked.'}
        if compiled is None:
            return row
        before = time.perf_counter()
        factory_limits = dict(limits['factory'], wall_seconds=design['search_seconds'])
        model, provider, factory = call('adapter', 'make_provider', compiled, item['generation'], item['depth'], factory_limits)
        factory_seconds = time.perf_counter() - before
        row.update(model=model, factory=factory, factory_seconds=factory_seconds, status='UNKNOWN', reason='COLD_FACTORY_WINDOW', result=None)
        _need(factory['status'] in ('COMPLETE', 'UNKNOWN'), 'owned complete factory result')
        if factory['status'] == 'UNKNOWN':
            _need(model is None and provider is None and factory['value'] is None, 'no partial provider')
            row['reason'] = 'FACTORY_' + str(factory['reason'])
        else:
            remaining = design['search_seconds'] - (time.perf_counter() - before)
            if remaining > 0:
                engine_limits = dict(limits['point'], wall_seconds=remaining)
                answer = call('engine', 'solve', model, engine_limits, enumerate_incident=provider)
                _need(answer['status'] in ('SAT', 'UNSAT', 'UNKNOWN'), 'actual growing point status')
                row.update(result=answer, status=answer['status'], reason=answer['reason'])
            row['provider'] = provider.snapshot()
        row['search_seconds'] = time.perf_counter() - before
        if factory['status'] == 'COMPLETE':
            t = time.perf_counter()
            audit = call('growth_audit', 'verify_factory', compiled, item['generation'], item['depth'], model, factory,
                         limits=limits['growth_audit'])
            _need(audit['status'] in ('VERIFIED', 'UNKNOWN'), 'invalid factory aborts whole cohort')
            row.update(factory_audit=audit, factory_audit_seconds=time.perf_counter() - t)
        if row['result'] is not None:
            answer = row['result']
            if answer['model_sha256'] is not None:
                _need(answer['model_sha256'] == _sha(model), 'actual normalized model binding')
            if answer['entry_state'] is not None:
                _need(_raw(answer['entry_state']) == _raw(answer['restored_state'])
                      and _sha(answer['entry_state']) == answer['state_hashes']['entry']
                      == answer['state_hashes']['restored'], 'complete actual growth state restoration')
            if answer['status'] != 'SAT':
                _need(answer['selected'] == [] and answer['certificate'] is None, 'no nonpositive certificate')
            if answer['status'] == 'UNKNOWN':
                _need(answer['final_state'] is None, 'no invented interrupted final image')
            if answer['status'] == 'SAT':
                check_positive(identity, item, compiled, answer['selected'], row)
        _need(_sha(compiled) == item['checkpoint']['raw_sha256'], 'point preserves current compiled wire')
        row['ref'] = emit(identity + '-whole-point', row)
        return row

    def control(identity, item, compiled, load_seconds):
        row = {'id': identity, 'lane': 'MATCHED_DEPTH_TREE_CONTROL', 'status': 'NOT_RUN_' + item['status'],
               'verified': False, 'original_status': 'NO_CERTIFICATE', 'preparation_ref': item['preparation_ref'],
               'checkpoint_load_seconds': load_seconds}
        if compiled is None:
            return row
        before = time.perf_counter()
        answer = call('growth_audit', 'tree_control', compiled, item['depth'], limits['control'])
        row.update(result=answer, status=answer['status'], search_seconds=time.perf_counter() - before)
        _need(answer['status'] in ('DERIVABLE', 'NOT_DERIVABLE', 'UNKNOWN'), 'honest matched-depth tree control')
        if answer['status'] == 'DERIVABLE':
            check_positive(identity, item, compiled, answer['details']['selected'], row)
        _need(_sha(compiled) == item['checkpoint']['raw_sha256'], 'control preserves same compiled wire')
        row['ref'] = emit(identity + '-whole-control', row)
        return row

    results = []
    for case_id in design['case_order']:
        budget(); item = prepared[case_id]
        compiled, load_seconds = restore(item)
        # Fixed point-then-control order declared before any actual call.
        gcts = point(case_id + '-growth-point', item, compiled, load_seconds)
        baseline = control(case_id + '-tree-control', item, compiled, load_seconds)
        row = {'id': case_id, 'original': item['original'], 'depth': item['depth'],
               'preparation_ref': item['preparation_ref'], 'shared_checkpoint_load_seconds': load_seconds,
               'lanes': {'GROWTH_POINT_LEX': _compact(gcts), 'MATCHED_DEPTH_TREE_CONTROL': _compact(baseline)}}
        row['ref'] = emit(case_id + '-whole-comparison', row)
        results.append(row)
        del compiled
    _need(len(results) == 15 and _raw(cases) == input_image and _raw(donors) == donor_image
          and _raw(bank) == bank_image and _sha(program) == native.identity['program'], 'whole main postguards')
    return {'schema': 'Z-growing-proof-comparison-experiment-v1', 'version': VERSION, 'status': 'COMPLETE',
            'design': design, 'limits': limits, 'qualification_prerequisite': prerequisite,
            'historical_acquisition_seconds': donor_admission['acquisition_seconds'], 'donor_custody': donor_join,
            'native_program': program_ref, 'native_preparation_seconds': native_preparation_seconds,
            'bank_ref': bank_ref, 'zero_schema_checks': zero_checks, 'preparations': preparation_summaries,
            'checkpoint_total_packed_bytes': packed_total, 'results': results,
            'native_memo': {'requests': native.requests, 'request_count': len(native.requests), 'hits': native.hits,
                            'executions': len(native.cache), 'execution_seconds': native.execution_seconds},
            'seconds': time.perf_counter() - started,
            'scope': 'All15 exact Y regression assertions and same current audited catalogue/eligible bank. '
                     'Root-seeded active-frontier anchored depth8 growth versus same-inventory minimum-expanded-tree DP. '
                     'Cold factory+engine share2s; independent control own cold prepare+DP2s. '
                     'Shared bank/Ycompile/audit/zero/checkpoint and later tree/native/lowering costs separate but retained. '
                     'No giant full V_D main universe or per-change independent graph enumeration. '
                     'All actual returns retained; output cap failure invalidates wholeattempt, no projection. '
                     'Proof-output/primitive64 refusal unknown, not an additional semantic tree-node cap. '
                     'No training/RL/old rowmatcher, expected advantage, globally unseen, unrestricted FOL or fixed Wang claim.'}
