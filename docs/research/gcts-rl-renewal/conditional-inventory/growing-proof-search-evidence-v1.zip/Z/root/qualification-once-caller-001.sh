set -C
/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12 -I -S -B -c 'import hashlib,sys
p,n,h=sys.argv[1:4]
n=int(n)
b=sys.stdin.buffer.read(n+1)
if len(b)!=n or hashlib.sha256(b).hexdigest()!=h:
    raise SystemExit('"'"'authenticated Source body mismatch'"'"')
sys.argv=[p]+sys.argv[4:]
g={'"'"'__name__'"'"':'"'"'__main__'"'"','"'"'__file__'"'"':p,'"'"'__package__'"'"':None,'"'"'__cached__'"'"':None,'"'"'__builtins__'"'"':__builtins__}
exec(compile(b,p,'"'"'exec'"'"'),g)
' /private/tmp/gcts-growing-proof-obligations-20261028-v1/root/growing_point_qualification_once_v1.py 18546 1b66da061d1ac70f72102ba24fe8decc73c0edf18155d9f0a7d0446b5720e727 --mode observer --plan /private/tmp/gcts-growing-proof-obligations-20261028-v1/root/qualification-once-plan-001.json --authority /private/tmp/gcts-growing-proof-obligations-20261028-v1/root/qualification-once-A6-001.json < /private/tmp/gcts-growing-proof-obligations-20261028-v1/root/growing_point_qualification_once_v1.py > /private/tmp/gcts-growing-proof-obligations-20261028-v1/root/qualification-once-001.outer.stdout.bin 2> /private/tmp/gcts-growing-proof-obligations-20261028-v1/root/qualification-once-001.outer.stderr.bin
