"""Closed Z tiny growing-point qualification; inert until fresh owned once.

No IO, loader, historical proofs, models, policy, or benchmark target answers.
All positive tiny point/control certificates pass actual C1 and independent B.
"""
import hashlib
import json
import time

VERSION = 'Z-GROWING-POINT-QUALIFICATION-EXPERIMENT-v2'


def need(ok, reason):
    if not ok:
        raise RuntimeError(reason)


def raw(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')


def sha(value):
    return hashlib.sha256(raw(value)).hexdigest()


def run(modules, context, emit, budget, call):
    started = time.perf_counter()
    need(type(context) is dict and set(context) == {'plan', 'sources', 'metadata', 'donor_stored'},
         'exact qualification context')
    need(context['donor_stored'] == {}, 'no historical donor or target proof input')
    metadata = context['metadata']
    design = json.loads(metadata['design'])
    limits = json.loads(metadata['experiment_limits'])
    need(design['schema'] == 'Z-prospective-growing-qualification-design-v1'
         and design['expected_emissions'] == 41
         and design['expected_engine_solve_calls'] == 40
         and design['expected_factory_calls'] == 4
         and design['expected_decode_calls'] == 4
         and design['expected_tree_control_calls'] == 7
         and design['expected_native_requests'] == 8, 'closed prefrozen call census')
    need(set(limits) == {'native', 'codec', 'carrier', 'checker'}, 'fixed native profile4')
    input_image = raw(design)
    before = time.perf_counter()
    program = call('tree_machine', 'Compiler', context['sources']['real_parser'].decode('utf-8')).declaration()
    call('tree_machine', 'validate', program)
    program_ref = emit('qualification-fixed-native-program', program)
    program_image = raw(program)
    native_preparation_seconds = time.perf_counter() - before
    native = call('native_bridge', '_Native', context['sources'], limits, program, emit, budget, call)
    records, checks, names, certificate_names = [], [], set(), set()
    full_observations = 0

    def collect(name, record):
        nonlocal full_observations
        budget()
        need(type(name) is str and name and name.isascii()
             and all(c.isalnum() or c == '-' for c in name)
             and name not in names, 'unique safe whole qualification record')
        names.add(name)
        need(type(record) is dict and type(record.get('native_certificates')) is list,
             'every record explicitly lists native certificates')
        if 'observations' in record:
            need(type(record['observations']) is list, 'full observation list')
            full_observations += len(record['observations'])
        image = raw(record)
        ref = emit('qualification-' + name, record)
        records.append({'id': name, 'ref': ref})
        for item in record['native_certificates']:
            need(type(item) is dict and set(item) == {'label', 'problem', 'proof'}
                 and type(item['label']) is str and bool(item['label'])
                 and type(item['problem']) is dict and set(item['problem']) == {'theory', 'goal'}
                 and type(item['proof']) is list, 'actual tiny certificate exact3')
            label = item['label'].replace('_', '-')
            need(label.isascii() and all(c.isalnum() or c == '-' for c in label), 'safe certificate label')
            identity = 'qualification-' + name + '-' + label
            need(identity not in certificate_names, 'unique native check identity')
            certificate_names.add(identity)
            check = native.check(identity, item['problem'], item['proof'])
            need(check['status'] == 'VERIFIED', 'complete actual native C1 and independent B')
            checks.append({'case': name, 'label': item['label'], 'check': check})
        need(raw(record) == image, 'whole qualification record not mutated by checks')
        budget()

    result = call('growth_audit', 'qualify', modules['engine'], modules['adapter'], collect)
    need(type(result) is dict and result.get('status') == 'PASS', 'entire closed qualification PASS')
    expected = dict(design['expected_counts'], full_observations=full_observations)
    need(type(result.get('counts')) is dict and raw(result['counts']) == raw(expected)
         and result.get('records') == [r['id'] for r in records],
         'whole type-exact runtime call/observation/emission census')
    need(len(records) == design['expected_emissions']
         and len(checks) == design['expected_native_requests'], 'no successful prefix or omitted native proof')
    need(raw(program) == program_image and raw(design) == input_image, 'current program/design postguard')
    summary = {'result': result, 'records': records, 'native_checks': checks}
    qualification_ref = emit('complete-growing-qualification', summary)
    return {'schema': 'Z-growing-qualification-experiment-v1', 'version': VERSION,
            'status': 'COMPLETE', 'qualification_ref': qualification_ref,
            'qualification': result, 'record_count': len(records), 'native_check_requests': len(checks),
            'native_program': program_ref, 'native_preparation_seconds': native_preparation_seconds,
            'native_memo': {'requests': native.requests, 'executions': len(native.cache),
                            'hits': native.hits, 'unique_execution_seconds': native.execution_seconds},
            'seconds': time.perf_counter() - started,
            'scope': 'Only closed tiny qualification. Every actual point/control tiny positive checked by C1 and host B. '
                     'Generic graph checks and proof/producer interpretation are independently reconstructed. '
                     'No benchmark search, training, historical answers, new-theorem or full-conformance claim.'}
