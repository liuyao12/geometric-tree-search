set -C
/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12 -I -S -B -c 'import hashlib,sys
p,n,h=sys.argv[1:4]
n=int(n)
b=sys.stdin.buffer.read(n+1)
if len(b)!=n or hashlib.sha256(b).hexdigest()!=h:
    raise SystemExit('"'"'authenticated Source body mismatch'"'"')
sys.argv=[p]+sys.argv[4:]
g={'"'"'__name__'"'"':'"'"'__main__'"'"','"'"'__file__'"'"':p,'"'"'__package__'"'"':None,'"'"'__cached__'"'"':None,'"'"'__builtins__'"'"':__builtins__}
exec(compile(b,p,'"'"'exec'"'"'),g)
' /private/tmp/gcts-growing-proof-obligations-20261028-v1/root/growing_proof_study_once_v1.py 19495 e5db8bd835aa445adcfb9c9c70db00f42de4b18f56ecaa49a640f059cc0c5c16 --mode observer --plan /private/tmp/gcts-growing-proof-obligations-20261028-v1/root/study-once-plan-001.json --authority /private/tmp/gcts-growing-proof-obligations-20261028-v1/root/study-once-A6-001.json < /private/tmp/gcts-growing-proof-obligations-20261028-v1/root/growing_proof_study_once_v1.py > /private/tmp/gcts-growing-proof-obligations-20261028-v1/root/study-once-001.outer.stdout.bin 2> /private/tmp/gcts-growing-proof-obligations-20261028-v1/root/study-once-001.outer.stderr.bin
