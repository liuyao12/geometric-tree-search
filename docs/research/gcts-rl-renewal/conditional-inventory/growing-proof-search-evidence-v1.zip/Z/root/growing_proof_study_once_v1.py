"""Closed Z growing-proof-search worker and owned observer. Inert until a fresh exact once grant.

Only pinned retained Source bytes execute. All outcomes and complete proof
checks are retained. The supervisor owns one child, its streams and wait4;
timeouts/refusals never become mathematical negatives. No network or Git.
"""
import argparse
import gzip
import hashlib
import json
import os
from pathlib import Path
import resource
import selectors
import signal
import subprocess
import sys
import time
import types

ROOT = Path('/private/tmp/gcts-growing-proof-obligations-20261028-v1')
PYTHON = '/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12'
ROLES = {'runner', 'experiment', 'compiler', 'catalogue_audit', 'engine', 'adapter', 'growth_audit', 'inventory', 'bank_verifier', 'native_bridge', 'tree_machine', 'real_parser', 'codec', 'carrier', 'fol_checker'}


def require(ok, reason):
    if not ok:
        raise RuntimeError(reason)


def raw_json(value):
    return (json.dumps(value, ensure_ascii=True, sort_keys=True,
                       separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')


def raw_ref(path, raw):
    return {'path': str(path), 'bytes': len(raw),
            'sha256': hashlib.sha256(raw).hexdigest()}


def read_ref(ref, maximum=1048576):
    require(type(ref) is dict and set(ref) == {'path', 'bytes', 'sha256'}, 'raw ref')
    path = Path(ref['path'])
    require(path.is_absolute() and not path.is_symlink(), 'regular absolute path')
    require(type(ref['bytes']) is int and 0 <= ref['bytes'] <= maximum, 'raw length bound')
    with path.open('rb') as f:
        data = f.read(ref['bytes'] + 1)
    observed = raw_ref(path, data)
    require(observed == ref, 'whole raw association: ' + json.dumps(
            {'expected': ref, 'observed': observed}, sort_keys=True))
    return data


def put(path, raw):
    with path.open('xb') as f:
        f.write(raw)
        f.flush()
        os.fsync(f.fileno())
    require(path.read_bytes() == raw, 'whole written bytes')
    return raw_ref(path, raw)


def check_authority(raw, plan_path, plan_raw, plan):
    authority = json.loads(raw)
    expected = {'schema': 'Z-growing-proof-search-once-authority-v1', 'uses': 1,
                'authorized': True, 'plan': raw_ref(plan_path, plan_raw),
                'runner': plan['sources']['runner'], 'python': plan['python']}
    require(type(authority) is dict and len(authority) == 6
            and type(authority.get('uses')) is int
            and type(authority.get('authorized')) is bool
            and authority == expected, 'exact typed Root once')
    return expected


def load_plan(path):
    raw = Path(path).read_bytes()
    plan = json.loads(raw)
    require(set(plan) == {'schema', 'sources', 'metadata', 'python', 'bootstrap',
                          'actual_dir', 'limits'}, 'exact plan')
    require(plan['schema'] == 'Z-growing-proof-search-once-plan-v1', 'plan schema')
    require(set(plan['sources']) == ROLES, 'closed Source roles')
    require(Path(plan['actual_dir']) == ROOT / 'actual' / 'study-001', 'owned output')
    require(plan['sources']['runner']['path'] == __file__, 'runner location')
    require(sys.executable == PYTHON and sys.flags.isolated and sys.flags.no_site
            and sys.dont_write_bytecode, 'isolated D90')
    require(plan['limits'] == {'worker_seconds': 1200, 'observer_seconds': 1230,
            'rss_bytes': 1073741824, 'file_bytes': 67108864,
            'total_bytes': 1073741824, 'max_files': 768,
            'stream_bytes': 1048576}, 'fixed process and artifact profile')
    retained = {k: read_ref(v) for k, v in plan['sources'].items()}
    metadata = {k: read_ref(v) for k, v in plan['metadata'].items()}
    read_ref(plan['python'], 33554432)
    read_ref(plan['bootstrap'])
    return plan, raw, retained, metadata


def worker(plan_path):
    started = time.perf_counter()
    plan, plan_raw, sources, metadata = load_plan(plan_path)
    directory = Path(plan['actual_dir'])
    marker_path = directory / 'CONSUMED.json'
    marker_raw = marker_path.read_bytes()
    marker = json.loads(marker_raw)
    authority_raw = read_ref(marker['authority'])
    check_authority(authority_raw, plan_path, plan_raw, plan)
    consume_raw = read_ref(marker['consumed'])
    require(json.loads(consume_raw) == {'authority': marker['authority'],
            'plan': raw_ref(plan_path, plan_raw), 'status': 'SPENT'}, 'worker once joins')
    artifacts, total_bytes, calls = [], 0, {}

    def budget():
        require(time.perf_counter() - started < 1200, 'whole worker sampled wall')
        require(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss <= 1073741824,
                'whole worker sampled RSS bytes on Darwin')

    def emit(name, data):
        nonlocal total_bytes
        budget()
        require(type(name) is str and name and name.isascii()
                and all(c.isalnum() or c in '-.' for c in name), 'artifact name')
        require(len(artifacts) < 760, 'artifact count')
        raw = raw_json(data)
        require(len(raw) <= 67108864, 'full artifact raw cap')
        compressed = len(raw) > 65536
        stored = gzip.compress(raw, mtime=0) if compressed else raw
        total_bytes += len(stored)
        require(len(stored) <= 67108864 and total_bytes <= 1040187392,
                'whole artifact stored cap')
        ref = put(directory / (name + ('.json.gz' if compressed else '.json')), stored)
        require((gzip.decompress(stored) if compressed else stored) == raw,
                'lossless complete artifact')
        answer = {'name': name, 'stored': ref, 'encoding': 'gzip-json' if compressed else 'json',
                  'raw_bytes': len(raw), 'raw_sha256': hashlib.sha256(raw).hexdigest()}
        artifacts.append(answer)
        return answer

    donor_manifest = json.loads(metadata['donor_manifest'])
    require(donor_manifest['schema'] == 'X-six-original-W-donor-raw-source-manifest-v1'
            and type(donor_manifest['donors']) is list and len(donor_manifest['donors']) == 6,
            'closed six-donor raw manifest')
    donor_stored, donor_refs = {}, {}
    donor_total = 0
    for row in donor_manifest['donors']:
        budget()
        require(type(row['id']) is str and row['id'] not in donor_stored, 'unique donor identity')
        require(type(row['uncompressed_bytes']) is int and 0 < row['uncompressed_bytes'] <= 67108864,
                'donor decoded extent')
        raw = read_ref(row['source_ref'], 67108864)
        donor_total += len(raw)
        require(donor_total <= 67108864, 'six-donor aggregate compressed bound')
        donor_stored[row['id']] = raw
        donor_refs[row['id']] = row['source_ref']
    modules = {}
    for role in sorted(ROLES - {'runner', 'real_parser'}):
        budget()
        module = types.ModuleType('Z_' + role)
        module.__file__ = plan['sources'][role]['path']
        exec(compile(sources[role], module.__file__, 'exec', dont_inherit=True), module.__dict__)
        modules[role] = module

    def call(role, name, *args, **kwargs):
        budget()
        key = role + '.' + name
        calls[key] = calls.get(key, 0) + 1
        require(calls[key] <= 512, 'public outer entry cap')
        value = getattr(modules[role], name)(*args, **kwargs)
        budget()
        return value

    context = {'plan': plan, 'sources': sources, 'metadata': metadata, 'donor_stored': donor_stored}
    experiment = call('experiment', 'run', modules, context, emit, budget, call)
    require(type(experiment) is dict and experiment.get('status') == 'COMPLETE',
            'complete closed experiment')
    result = {'schema': 'Z-growing-proof-search-study-v1', 'status': 'COMPLETE',
              'experiment': experiment, 'outer_public_calls': dict(calls), 'artifacts': list(artifacts),
              'scope': 'Complete bounded growing-proof-search cohort. Exact stored sources/data and six original donors authenticated. '
                       'One owned child with complete output capture and mandatory wait/group/EOF confirmation. '
                       'No scientific result is admitted merely by this custody envelope; independent saved-data review remains required.'}
    result_ref = emit('worker-result', result)
    for role, ref in plan['sources'].items():
        require(read_ref(ref) == sources[role], 'post Source guard')
    for role, ref in plan['metadata'].items():
        require(read_ref(ref) == metadata[role], 'post data guard')
    for name, ref in donor_refs.items():
        require(read_ref(ref, 67108864) == donor_stored[name], 'post original donor guard')
    read_ref(plan['python'], 33554432); read_ref(plan['bootstrap'])
    require(Path(plan_path).read_bytes() == plan_raw, 'post plan guard')
    require(marker_path.read_bytes() == marker_raw, 'post marker guard')
    require(read_ref(marker['authority']) == authority_raw, 'post authority guard')
    require(read_ref(marker['consumed']) == consume_raw, 'post consumed guard')
    budget()
    sys.stdout.buffer.write(raw_json({'status': 'COMPLETE', 'result': result_ref,
        'plan': raw_ref(plan_path, plan_raw), 'public_calls': calls,
        'elapsed_seconds': time.perf_counter() - started,
        'self_lifetime_peak_bytes': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}))
    sys.stdout.buffer.flush()
    return 0


def observer(plan_path, authority_path):
    started = time.perf_counter()
    plan, plan_raw, sources, metadata = load_plan(plan_path)
    authority_raw = Path(authority_path).read_bytes()
    check_authority(authority_raw, plan_path, plan_raw, plan)
    directory = Path(plan['actual_dir'])
    require(not directory.exists() and not directory.is_symlink(), 'fresh output directory')
    consumed = Path(str(authority_path) + '.CONSUMED.json')
    consume_raw = raw_json({'authority': raw_ref(authority_path, authority_raw),
                            'plan': raw_ref(plan_path, plan_raw), 'status': 'SPENT'})
    put(consumed, consume_raw)
    directory.mkdir(parents=True)
    marker_raw = raw_json({'authority': raw_ref(authority_path, authority_raw),
                           'consumed': raw_ref(consumed, consume_raw)})
    put(directory / 'CONSUMED.json', marker_raw)
    command = [PYTHON, '-I', '-S', '-B', plan['bootstrap']['path'],
               plan['sources']['runner']['path'], str(len(sources['runner'])),
               plan['sources']['runner']['sha256'], '--mode', 'worker', '--plan', str(plan_path)]
    captured = {'stdout': bytearray(), 'stderr': bytearray()}
    observed_bytes = {'stdout': 0, 'stderr': 0}
    eof = {'stdout': False, 'stderr': False}
    child = selector = None
    wait_status = usage = None
    failure = cleanup_deadline = None
    cleanup_errors = []
    sent = 0
    group_gone = False

    def kill_owned():
        if child is not None:
            try:
                os.killpg(child.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            except OSError as error:
                cleanup_errors.append({'stage': 'killpg', 'type': type(error).__name__,
                                       'errno': error.errno})

    def fault(reason):
        nonlocal failure, cleanup_deadline
        if failure is None:
            failure = reason
            cleanup_deadline = time.perf_counter() + 5
            kill_owned()

    def observe_wait_and_group():
        nonlocal wait_status, usage, group_gone
        if child is None:
            return
        if wait_status is None:
            pid, status, ru = os.wait4(child.pid, os.WNOHANG)
            if pid:
                wait_status, usage = status, ru
                child.returncode = os.waitstatus_to_exitcode(status)
        if wait_status is not None:
            try:
                os.killpg(child.pid, 0)
                group_gone = False
            except ProcessLookupError:
                group_gone = True

    def pump_events():
        nonlocal sent
        for key, _ in selector.select(timeout=0.05):
            if key.data == 'stdin':
                if failure is not None:
                    selector.unregister(key.fileobj); key.fileobj.close()
                    continue
                try:
                    count = os.write(key.fileobj.fileno(), sources['runner'][sent:sent + 65536])
                    sent += count
                    if sent == len(sources['runner']):
                        selector.unregister(key.fileobj); key.fileobj.close()
                except BrokenPipeError:
                    selector.unregister(key.fileobj); key.fileobj.close()
                    fault('INCOMPLETE_STDIN_BROKEN_PIPE')
                continue
            block = os.read(key.fileobj.fileno(), 65536)
            if not block:
                eof[key.data] = True
                selector.unregister(key.fileobj); key.fileobj.close()
            else:
                observed_bytes[key.data] += len(block)
                room = max(0, 1048576 - len(captured[key.data]))
                captured[key.data].extend(block[:room])
                if observed_bytes[key.data] > 1048576:
                    fault('STREAM_CAP_PREFIX_RETAINED')

    try:
        # Every post-spawn setup operation is protected. Retained Source stdin
        # is written nonblocking under the same observer deadline as capture.
        child = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE, cwd=ROOT / 'root', start_new_session=True)
        selector = selectors.DefaultSelector()
        for name, stream, mode in [('stdin', child.stdin, selectors.EVENT_WRITE),
                                  ('stdout', child.stdout, selectors.EVENT_READ),
                                  ('stderr', child.stderr, selectors.EVENT_READ)]:
            os.set_blocking(stream.fileno(), False)
            selector.register(stream, mode, name)
        while True:
            if failure is None and time.perf_counter() - started >= 1230:
                fault('OBSERVER_WALL_TIMEOUT')
            if cleanup_deadline is not None and time.perf_counter() >= cleanup_deadline:
                break
            pump_events()
            observe_wait_and_group()
            if wait_status is not None and all(eof.values()) and group_gone:
                break
            if wait_status is not None and not group_gone:
                fault('OWNED_DESCENDANT_GROUP_REMAINS')
    except BaseException as error:
        fault('OBSERVER_HOST_' + type(error).__name__)
    finally:
        confirmed = child is not None and wait_status is not None and all(eof.values()) and group_gone
        if child is not None and not confirmed:
            fault('UNCONFIRMED_OWNED_PROCESS_OR_STREAM')
            # No blocking wait is used, even after SIGKILL. Any unconfirmed
            # ownership is explicit evidence and cannot be admitted COMPLETE.
            while time.perf_counter() < cleanup_deadline:
                try:
                    if selector is not None:
                        pump_events()
                    else:
                        time.sleep(0.01)
                    observe_wait_and_group()
                    if wait_status is not None and all(eof.values()) and group_gone:
                        break
                except BaseException as error:
                    cleanup_errors.append({'stage': 'bounded-cleanup', 'type': type(error).__name__})
                    break
        if selector is not None:
            selector.close()
        if child is not None:
            for stream in (child.stdin, child.stdout, child.stderr):
                if stream is not None:
                    stream.close()
    streams = {k: put(directory / (k + '.bin'), bytes(v)) for k, v in captured.items()}
    terminal = None
    confirmed = child is not None and wait_status is not None and all(eof.values()) and group_gone
    if (confirmed and child.returncode == 0 and not failure and not captured['stderr']
            and sent == len(sources['runner'])):
        terminal = json.loads(captured['stdout'])
        require(terminal['status'] == 'COMPLETE', 'whole worker terminal')
        read_ref(terminal['result']['stored'], 67108864)
    files, total = [], 0
    for p in sorted(directory.iterdir()):
        require(p.is_file() and not p.is_symlink(), 'closed regular output')
        raw = p.read_bytes(); total += len(raw)
        require(len(raw) <= 67108864 and total <= 1073741824, 'whole readback ceilings')
        files.append(raw_ref(p, raw))
    require(len(files) <= 767, 'whole output count')
    for role, ref in plan['sources'].items():
        require(read_ref(ref) == sources[role], 'observer post Source guard')
    for role, ref in plan['metadata'].items():
        require(read_ref(ref) == metadata[role], 'observer post data guard')
    read_ref(plan['python'], 33554432); read_ref(plan['bootstrap'])
    require(Path(plan_path).read_bytes() == plan_raw, 'observer post plan guard')
    require(Path(authority_path).read_bytes() == authority_raw, 'observer post authority guard')
    require(consumed.read_bytes() == consume_raw, 'observer post consumed guard')
    require((directory / 'CONSUMED.json').read_bytes() == marker_raw, 'observer post marker guard')
    outcome = {'schema': 'Z-owned-growing-proof-search-observer-result-v1',
               'status': 'COMPLETE' if terminal is not None else 'UNADMITTED',
               'child_pid': None if child is None else child.pid, 'command': command,
               'returncode': None if child is None else child.returncode,
               'failure': failure, 'cleanup_errors': cleanup_errors,
               'wait_confirmed': wait_status is not None, 'both_streams_EOF': all(eof.values()),
               'group_gone': group_gone, 'stdin_bytes_sent': sent,
               'observed_stream_bytes': observed_bytes, 'retained_streams_complete':
                   {k: observed_bytes[k] == len(captured[k]) for k in captured},
               'streams': streams, 'worker_terminal': terminal, 'files': files,
               'stored_bytes': total, 'wait4_peak_bytes': None if usage is None else usage.ru_maxrss,
               'whole_observer_seconds': time.perf_counter() - started,
               'scope': 'One fresh child. wait4 lifetime RSS on Darwin; no hard RAM quota. '
                        'Owned nonblocking wait/drain with1230s sampled deadline and5s cleanup. '
                        'OS spawn, final readback/serialization tail are not an OS hard whole-lifetime '
                        'quota. Unconfirmed process, streams or group forbid COMPLETE.'}
    receipt = put(directory / 'observer-result.json', raw_json(outcome))
    sys.stdout.buffer.write(raw_json({'status': outcome['status'], 'receipt': receipt}))
    sys.stdout.buffer.flush()
    return 0 if terminal is not None else 1


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', choices=('worker', 'observer'), required=True)
    parser.add_argument('--plan', required=True)
    parser.add_argument('--authority')
    args = parser.parse_args()
    if args.mode == 'worker':
        require(args.authority is None, 'worker has no authority path')
        return worker(args.plan)
    require(args.authority is not None, 'observer needs once authority')
    return observer(args.plan, args.authority)


if __name__ == '__main__':
    raise SystemExit(main())
