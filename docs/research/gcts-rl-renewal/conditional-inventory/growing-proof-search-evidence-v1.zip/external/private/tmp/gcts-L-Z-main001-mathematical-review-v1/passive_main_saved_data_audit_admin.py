"""Independent administrative saved-data/hash/finite-table arithmetic only."""
import collections,gzip,hashlib,itertools,json,math,pathlib
R=pathlib.Path('/private/tmp/gcts-growing-proof-obligations-20261028-v1');A=R/'actual/study-001';O=pathlib.Path('/private/tmp/gcts-L-Z-main001-mathematical-review-v1')
def raw(x):return (json.dumps(x,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')
def key(x):return raw(x)[:-1].decode('ascii')
def h(x):return hashlib.sha256(x).hexdigest()
def pairdict(rows):
 d={}
 for k,v in rows:assert k not in d;d[k]=v
 return d
def strict(b):
 def bad(x):raise AssertionError('nonfinite '+x)
 return json.loads(b,object_pairs_hook=pairdict,parse_constant=bad)
def equal(x,y):assert raw(x)==raw(y),(x,y)
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':h(b)}
def guard(rr):
 p=pathlib.Path(rr['path']);b=p.read_bytes();assert len(b)==rr['bytes']and h(b)==rr['sha256']and not p.is_symlink();return b
def load(p):
 b=p.read_bytes();return strict(gzip.decompress(b)if p.suffix=='.gz'else b)
observer=load(A/'observer-result.json');worker=load(A/'worker-result.json.gz');experiment=worker['experiment'];artifacts={};rawtotal=0
for d in worker['artifacts']+[observer['worker_terminal']['result']]:
 stored=guard(d['stored']);body=stored if d['encoding']=='json'else gzip.decompress(stored);assert len(body)==d['raw_bytes']and h(body)==d['raw_sha256'];v=strict(body);assert body==raw(v)and d['name']not in artifacts;artifacts[d['name']]=(d,v);rawtotal+=len(body)
def get(rr):
 guard(rr['stored']);d,v=artifacts[rr['name']];equal(d,rr);return v
assert len(list(A.iterdir()))==143and len(artifacts)==139and len(worker['artifacts'])==138
for rr in observer['files']:guard(rr)
assert len(observer['files'])==142and {pathlib.Path(x['path']).name for x in observer['files']}=={p.name for p in A.iterdir()if p.name!='observer-result.json'}
assert observer['status']=='COMPLETE'and observer['returncode']==0and observer['failure']is None and observer['cleanup_errors']==[]and all(observer[k]is True for k in ('both_streams_EOF','wait_confirmed','group_gone'))
planpath=pathlib.Path(observer['worker_terminal']['plan']['path']);plan=strict(guard(observer['worker_terminal']['plan']));inputpins=[]
for group in ('sources','metadata'):
 for name,rr in plan[group].items():guard(rr);inputpins.append({'role':group+'.'+name,**rr})
for name in ('python','bootstrap'):guard(plan[name]);inputpins.append({'role':name,**plan[name]})
assert len(plan['sources'])==15
cases=strict(guard(plan['metadata']['cases']));design=strict(guard(plan['metadata']['design']));limits=strict(guard(plan['metadata']['experiment_limits']));assert len(cases)==15and design['depth']==8and len(experiment['results'])==15
assert [x['id']for x in experiment['results']]==design['case_order'];assert all(p['status']=='COMPLETE'for p in experiment['preparations'])
originalexit=R/'root/study-once-001.original-tool-exit-v1.json';original=load(originalexit);assert original['original_terminal']['chunk_id']=='da4edf'and original['original_terminal']['exit_code']==0
bankrecord=get(experiment['bank_ref']);bank=bankrecord['result']['value'];assert len(bank['donors'])==6and len(bank['lemmas'])==4and bankrecord['audit']['status']=='VERIFIED';bankhash=h(raw({k:bank[k]for k in ('schema','version','donors','lemmas')}));assert bankhash==bank['bank_sha256'];lemma_byid={x['id']:x for x in bank['lemmas']}
# Public semantic-core bindings and all actual zero payload/index/data associations.
compiled_bycase={};preparation_support=[];zero_total=0;zero_rules=collections.Counter()
def structural_catalogue(c):
 fs=c['logical_basis']['formulas'];cs=[key(f)for f in fs];assert cs==c['logical_basis']['colors']==sorted(set(cs));index={s:i for i,s in enumerate(cs)};assert c['goal_id']==index[key(c['goal'])];mp=[];gen=[];defs={}
 for i,z in enumerate(c['zero_instances']):
  assert z['id']=='i'+str(i)and z['rule']==z['line']['rule'];assert type(z['formula_id'])is int and key(z['line']['formula'])==cs[z['formula_id']]
  did=key(['zero',z['id']]);defs[did]={'id':did,'kind':'ZERO','output':z['formula_id'],'premises':[],'zero_id':z['id'],'variable':None,'native_rule':z['rule']}
 assert [key(z['line'])for z in c['zero_instances']]==sorted(set(key(z['line'])for z in c['zero_instances']))
 for i,f in enumerate(fs):
  if f[0]=='imp':
   a,b=index[key(f[1])],index[key(f[2])];mp.append([i,a,b]);did=key(['mp',i,a,b]);defs[did]={'id':did,'kind':'MP','output':b,'premises':[a,i],'zero_id':None,'variable':None,'native_rule':'mp'}
  elif f[0]=='all':
   a=index[key(f[2])];gen.append([i,a,f[1]]);did=key(['gen',i,a,f[1]]);defs[did]={'id':did,'kind':'GEN','output':i,'premises':[a],'zero_id':None,'variable':f[1],'native_rule':'generalize'}
  elif f[0]=='not':assert key(f[1])in index
  elif f[0]in('and','or'):assert key(f[1])in index and key(f[2])in index
 equal(mp,c['mp_index']);equal(gen,c['gen_index']);return fs,cs,defs
for prep,zero in zip(experiment['preparations'],experiment['zero_schema_checks']):
 cid=prep['id'];equal(prep['original'],cases[cid]);assert prep['depth']==8and prep['extension_audit']['status']=='VERIFIED'
 app=prep['application'];assert app['bank_sha256']==bankhash and app['original_theory_sha256']==h(raw(cases[cid]['theory']))
 equal(app['theory']['functions'],cases[cid]['theory']['functions']);equal(app['theory']['predicates'],cases[cid]['theory']['predicates']);assert set(app['theory']['axioms'])==set(cases[cid]['theory']['axioms'])|set(x['name']for x in app['lemma_bindings'])
 for name,value in cases[cid]['theory']['axioms'].items():equal(app['theory']['axioms'][name],value)
 for binding in app['lemma_bindings']:
  lemma=lemma_byid[binding['lemma_id']];equal(app['theory']['axioms'][binding['name']],lemma['goal'])
  for name,value in lemma['required_axioms'].items():equal(cases[cid]['theory']['axioms'][name],value)
  for kind in ('functions','predicates'):
   for name,arity in lemma['signature'][kind].items():assert cases[cid]['theory'][kind][name]==arity
 built=get(prep['build_ref']);assert built['status']=='COMPLETE';c=built['compiled'];compiled_bycase[cid]=c;generation=built['generation'];equal(c['theory'],app['theory']);equal(c['goal'],cases[cid]['goal']);equal(c['profile'],design['generation_profile']);equal(generation,prep['generation'])
 corehash=h(raw({k:v for k,v in c.items()if k not in ('costs','scope')}));assert corehash==generation['compiled_core_sha256']==prep['catalogue_audit']['details']['compiled_core_sha256'];fs,cs,defs=structural_catalogue(c)
 stages=c['logical_basis']['stages'];assert [x['stage']for x in stages]==['INPUT','UI1','UI2','EQUALITY','DISTRIBUTION','PROPOSITIONAL','EXPORT'];assert all(stages[i]['formula_count']<=stages[i+1]['formula_count']and stages[i]['instance_count']<=stages[i+1]['instance_count']for i in range(len(stages)-1));assert stages[-1]['formula_count']==len(fs)and stages[-1]['instance_count']==len(c['zero_instances'])
 for name in ('core_assertions','goal_receptors','bridge_premises'):
  ids=generation[name];assert ids==sorted(set(ids))and all(type(x)is int and 0<=x<len(fs)for x in ids)
 assert generation['core_assertions']==generation['core_stages'][-1]['formula_ids'];assert c['goal_id']in generation['goal_receptors']
 for row in generation['core_stages']:assert row['formula_ids']==sorted(set(row['formula_ids']))and all(type(x)is int and 0<=x<len(fs)for x in row['formula_ids'])
 batch=get(zero['ref']);equal(batch['theory'],c['theory']);equal(batch['proof'],[z['line']for z in c['zero_instances']]);assert batch['receipt']['status']=='VERIFIED'and batch['receipt']['checked_lines']==len(c['zero_instances']);equal(batch['limits'],limits['zero_checker']);assert prep['catalogue_audit']['status']==prep['zero_audit']['status']=='VERIFIED';equal(prep['zero_audit']['details']['checker'],batch['receipt'])
 assert prep['checkpoint']['raw_sha256']==h(raw(c))and prep['checkpoint']['raw_bytes']==len(raw(c));equal(prep['problem'],{'theory':c['theory'],'goal':c['goal'],'profile':c['profile']})
 zero_total+=len(c['zero_instances']);zero_rules.update(z['rule']for z in c['zero_instances'])
 preparation_support.append({'id':cid,'formulas':len(fs),'zeros':len(c['zero_instances']),'zero_rule_counts':dict(collections.Counter(z['rule']for z in c['zero_instances'])),'MP':len(c['mp_index']),'GEN':len(c['gen_index']),'definitions':len(defs),'generation_core_sha256':corehash,'generation_stages':stages,'eligible_lemma_ids':[x['lemma_id']for x in app['lemma_bindings']],'original_axiom_names':sorted(cases[cid]['theory']['axioms']),'statuses':[prep[k]['status']for k in ('extension_audit','catalogue_audit','zero_audit')],'costs':{k:prep[k]for k in ('preparation_seconds','build_seconds','catalogue_audit_seconds','zero_audit_seconds','checkpoint_seconds')},'zero_batch_ref':zero['ref']})
# Literal producer/point-tree reconstruction from recorded CIDs; no adapter call.
def decorated_binding(cs,defs,D,site,did):
 assert type(site)is str and len(site)<=D and all(x in'01'for x in site);d=defs[did];ps=d['premises'];assert not ps or len(site)<D
 sites=[site]+[site+str(i)for i in range(len(ps))];values=[d['output']]+ps
 return {'id':key([site,did]),'t':[[p,1]for p in sorted(sites)],'m':[[p,cs[x]]for p,x in sorted(zip(sites,values))]}
def tree_certificate(c,D,selected):
 fs,cs,defs=structural_catalogue(c);assert selected==sorted(set(selected));anchors={};placements=[]
 for cid in selected:
  site,did=strict(cid.encode());assert cid==key([site,did])and site not in anchors;anchors[site]=did;placements.append(decorated_binding(cs,defs,D,site,did))
 assert ''in anchors and defs[anchors['']]['output']==c['goal_id'];seen=set();post=[];stack=[('',False)]
 while stack:
  p,done=stack.pop()
  if done:post.append(p);continue
  assert p in anchors and p not in seen;seen.add(p);stack.append((p,True));ps=defs[anchors[p]]['premises']
  for i in reversed(range(len(ps))):
   child=p+str(i);assert child in anchors and defs[anchors[child]]['output']==ps[i];stack.append((child,False))
 assert set(anchors)==seen
 proof=[];mapping={};zeros={z['id']:z for z in c['zero_instances']}
 for p in post:
  d=defs[anchors[p]]
  if d['kind']=='ZERO':line=zeros[d['zero_id']]['line']
  elif d['kind']=='MP':line={'rule':'mp','formula':fs[d['output']],'antecedent':mapping[p+'0'],'implication':mapping[p+'1']}
  else:line={'rule':'generalize','formula':fs[d['output']],'source':mapping[p+'0'],'variable':d['variable']}
  mapping[p]=len(proof);proof.append(line)
 totals={'':1};marks={'':[cs[c['goal_id']],1]}
 for row in placements:
  for p,n in row['t']:totals[p]=totals.get(p,0)+n
  for p,v in row['m']:
   if p in marks:assert marks[p][0]==v
   else:marks[p]=[v,0]
   marks[p][1]+=1
 assert set(totals)==set(anchors)and all(x==2 for x in totals.values())and all(x[1]==2 for x in marks.values())
 tree={'root':'','max_depth':D,'selected':selected,'site_to_line':[[p,mapping[p]]for p in sorted(mapping)],'node_count':len(proof),'max_used_depth':max(map(len,anchors)),'placements':sorted(placements,key=lambda r:r['id']),'totals':[[p,n]for p,n in sorted(totals.items())],'marks':[[p]+v for p,v in sorted(marks.items())]}
 return proof,tree,defs
# Direct algebraic recurrence on saved finite producer tables. This computes only
# level annotations and does not call/replay a project search/control routine.
def depth_annotations(c,D):
 n=len(c['logical_basis']['formulas']);base=[None]*n
 for z in c['zero_instances']:base[z['formula_id']]=1
 tables=[base]
 for d in range(1,D+1):
  prev=tables[-1];now=base[:]
  for head,a,out in c['mp_index']:
   if prev[a]is not None and prev[head]is not None:
    value=1+prev[a]+prev[head]
    if now[out]is None or value<now[out]:now[out]=value
  for head,body,var in c['gen_index']:
   if prev[body]is not None:
    value=1+prev[body]
    if now[head]is None or value<now[head]:now[head]=value
  tables.append(now)
 return tables

def dependency_rows(proof):
 seen=set();todo=[len(proof)-1]
 while todo:
  i=todo.pop()
  if i in seen:continue
  assert type(i)is int and 0<=i<len(proof);seen.add(i);line=proof[i]
  if line['rule']=='mp':
   assert type(line['antecedent'])is int and type(line['implication'])is int and 0<=line['antecedent']<i and 0<=line['implication']<i;todo.extend([line['antecedent'],line['implication']]);equal(proof[line['implication']]['formula'],['imp',proof[line['antecedent']]['formula'],line['formula']])
  elif line['rule']=='generalize':assert type(line['source'])is int and 0<=line['source']<i;todo.append(line['source']);equal(line['formula'],['all',line['variable'],proof[line['source']]['formula']])
 return sorted(seen)

def checked_proof_fields(theory,goal,proof,permitted_zero):
 used=dependency_rows(proof);assert used==list(range(len(proof)));equal(proof[-1]['formula'],goal)
 for line in proof:
  if line['rule']=='axiom':assert line['name']in theory['axioms'];equal(line['formula'],theory['axioms'][line['name']])
  elif line['rule']not in ('mp','generalize'):assert key(line)in permitted_zero
 return sorted({line['name']for line in proof if line['rule']=='axiom'})

def observed_graph(c,D,model,s):
 fs,cs,defs=structural_catalogue(c);known={row['id']:row for row in s['placements']};assert len(known)==len(s['placements'])
 for cid,row in known.items():site,did=strict(cid.encode());equal(row,decorated_binding(cs,defs,D,site,did))
 loaded=s['loaded'];expectedids=set()
 for p in loaded:
  for did,d in defs.items():
   if not d['premises']or len(p)<D:expectedids.add(key([p,did]))
   if p and int(p[-1])<len(d['premises']):expectedids.add(key([p[:-1],did]))
 assert set(known)==expectedids
 sel=pairdict(s['selected']);q={''};totals={'':1};marks={'':[cs[c['goal_id']],1]};gens={'':0}
 for cid,g in sel.items():
  site,_=strict(cid.encode());assert g==len(site)+1
  for p,n in known[cid]['t']:q.add(p);totals[p]=totals.get(p,0)+n;gens[p]=min(gens.get(p,g),g)
  for p,v in known[cid]['m']:
   if p in marks:assert marks[p][0]==v
   else:marks[p]=[v,0]
   marks[p][1]+=1
 assert all(n<=2 for n in totals.values())and set(loaded)<=q
 excluded=s['excluded'];eligible=[]
 for cid,row in sorted(known.items()):
  if cid in sel or cid in excluded:continue
  if any(totals.get(p,0)+n>2 for p,n in row['t']):continue
  if any(p in marks and marks[p][0]!=v for p,v in row['m']):continue
  eligible.append(cid)
 frontier=sorted(p for p in q if totals[p]<2);assert set(frontier)<=set(loaded);domains=[];forward=[];reverse=collections.defaultdict(list)
 for p in frontier:
  choices=[]
  for cid in eligible:
   n=pairdict(known[cid]['t']).get(p,0)
   if n:choices.append(cid);forward.append([p,cid,n]);reverse[cid].append([p,n])
  domains.append([p,choices])
 deps={}
 for kind in ('t','m'):
  inverse=collections.defaultdict(list)
  for cid,row in sorted(known.items()):
   for p,_ in row[kind]:inverse[p].append(cid)
  deps[kind]=[[p,v]for p,v in sorted(inverse.items())]
 expected={'Q':[[p,gens[p]]for p in sorted(q)],'totals':[[p,n]for p,n in sorted(totals.items())],'selected':[[cid,sel[cid]]for cid in sorted(sel)],'marks':[[p]+v for p,v in sorted(marks.items())],'excluded':excluded,'eligible':eligible,'domains':domains,'forward':forward,'reverse':[[cid,reverse[cid]]for cid in sorted(reverse)],'placements':[known[cid]for cid in sorted(known)],'loaded':loaded,'dependencies':deps,'edge_count':len(forward)}
 equal(s,expected)
 return {'Q':len(q),'frontier':len(frontier),'registered':len(known),'edges':len(forward),'sha256':h(raw(s))}

cases_support=[];negatives=[];positives=[];states_checked=0;events_retained=events_total=rollbacks_retained=rollbacks_total=0;full_event_hashes=full_rollback_hashes=0;point_reasons=collections.Counter();transcript=[];all_zero_permitted={key(line)for lem in bank['lemmas']for line in lem['proof']if line['rule']not in ('mp','generalize')};proof_requests=[]
# LaTeX is presentation of saved ASTs, not logical normalization or proof synthesis.
def texname(x):return r'\mathrm{'+x.replace('\\',r'\backslash ').replace('_',r'\_').replace('{',r'\{').replace('}',r'\}')+'}'
def term(x):
 if x[0]=='var':return texname(x[1])
 return texname(x[1])+(r'\!\left('+','.join(term(a)for a in x[2])+r'\right)'if x[2]else'')
def formula(f):
 tag=f[0]
 if tag=='bot':return r'\bot'
 if tag=='eq':return r'\left('+term(f[1])+'='+term(f[2])+r'\right)'
 if tag=='pred':return texname(f[1])+(r'\!\left('+','.join(term(a)for a in f[2])+r'\right)'if f[2]else'')
 if tag=='all':return r'\forall '+texname(f[1])+r'\,\left('+formula(f[2])+r'\right)'
 if tag=='not':return r'\neg\left('+formula(f[1])+r'\right)'
 return r'\left('+formula(f[1])+{'imp':r'\to','and':r'\land','or':r'\lor'}[tag]+formula(f[2])+r'\right)'
def proof_lines(label,proof):
 out=['### '+label,'']
 for i,line in enumerate(proof):
  rule=line['rule'];note=rule
  if rule=='axiom':note+=' `'+line['name']+'`'
  if rule=='mp':note+=' '+str(line['antecedent']+1)+', '+str(line['implication']+1)
  if rule=='generalize':note+=' '+str(line['source']+1)+r', variable \('+texname(line['variable'])+r'\)'
  if rule=='instantiate':note+=r', term \('+term(line['term'])+r'\)'
  if rule=='eq_subst':note+=r', left \('+term(line['left'])+r'\), right \('+term(line['right'])+r'\)'
  out.append(str(i+1)+'. '+note+r': \('+formula(line['formula'])+r'\)')
 out.append('');return out
for comparison in experiment['results']:
 cid=comparison['id'];prep=next(x for x in experiment['preparations']if x['id']==cid);c=compiled_bycase[cid];fs,cs,defs=structural_catalogue(c);tables=depth_annotations(c,8);goal_costs=[row[c['goal_id']]for row in tables];source_lanes={};checked_zero={key(z['line'])for z in c['zero_instances']}
 for lane,compact in comparison['lanes'].items():
  row=get(compact['ref']);answer=row['result'];assert compact['status']==row['status']==answer['status'];assert row['verified']==compact['verified'];source_lanes[lane]=row
  if lane=='GROWTH_POINT_LEX':
   assert row['factory_audit']['status']=='VERIFIED';value=row['factory']['value'];equal(value['definitions'],[defs[d]for d in sorted(defs)]);assert value['compiled_core_sha256']==prep['generation']['compiled_core_sha256'];model=row['model'];assert model['capacity']==2 and model['roots']==['']and model['seed']=={'t':[['',1]],'m':[['',cs[c['goal_id']]]]}
   if answer['model_sha256']is not None:assert answer['model_sha256']==h(raw(model))
   image_summaries=[]
   for name in ('entry','final','restored'):
    s=answer[name+'_state'];hh=answer['state_hashes'][name]
    if s is None:assert hh is None and answer['status']=='UNKNOWN'
    else:assert hh==h(raw(s));image_summaries.append({'kind':name,**observed_graph(c,8,model,s)});states_checked+=1
   if answer['entry_state']is not None:equal(answer['entry_state'],answer['restored_state'])
   if answer['status']=='UNKNOWN':point_reasons[answer['reason']]+=1;assert answer['final_state']is None and answer['selected']==[]and answer['certificate']is None
   for keyname in ('event','rollback'):
    body=answer['events']if keyname=='event'else answer['rollback_records'];extent=answer[keyname+'_extent'];assert len(body)==extent['retained']<=extent['total']
    if keyname=='event':events_retained+=len(body);events_total+=extent['total']
    else:rollbacks_retained+=len(body);rollbacks_total+=extent['total']
    if len(body)==extent['total']:
     assert extent['sha256']==h(b''.join(raw(x)for x in body))
     if keyname=='event':full_event_hashes+=1
     else:full_rollback_hashes+=1
   row['_passive_images']=image_summaries
  else:
   if answer['status']=='DERIVABLE':assert goal_costs[8]==answer['details']['minimum_tree_nodes']==len(answer['proof'])
   else:
    assert answer['status']=='NOT_DERIVABLE'and answer['reason']=='EXHAUSTED_DECLARED_FINITE_DEPTH_INVENTORY'and goal_costs[8]is None and answer['proof']is None
    negatives.append({'id':cid,'goal_id':c['goal_id'],'goal':c['goal'],'formulas':len(fs),'goal_minimum_nodes_by_depth':goal_costs,'complete_minimum_node_tables':tables,'scope':'Only this complete saved finite producer catalogue and depth8; not original/unrestricted nonprovability.'})
  if row['verified']:
   assert answer['status']in('SAT','DERIVABLE');selected=answer['selected']if lane=='GROWTH_POINT_LEX'else answer['details']['selected'];proof,tree,_=tree_certificate(c,8,selected);equal(row['decoded']['proof'],proof);equal(row['decoded']['tree'],tree);equal(row['tree_audit']['proof'],proof);assert row['tree_audit']['status']=='VERIFIED'
   if lane=='GROWTH_POINT_LEX':equal(answer['certificate'],{'capacity':2,'roots':row['model']['roots'],'seed':row['model']['seed'],'placements':tree['placements'],'totals':tree['totals'],'marks':tree['marks']})
   else:equal(answer['proof'],proof)
   pos=get(compact['positive_ref']);equal(pos['coarse_proof'],proof);assert pos['verified']is True and pos['original_status']=='VERIFIED'and pos['lowering']['status']=='COMPLETE'and pos['lowering_audit']['status']=='VERIFIED';lower=pos['lowering']['value'];equal(lower['theory'],cases[cid]['theory']);equal(lower['goal'],cases[cid]['goal']);equal(lower['proof'],pos['original_proof']);assert len(lower['proof'])<=64
   coarse_axioms=checked_proof_fields(prep['application']['theory'],c['goal'],proof,checked_zero);original_axioms=checked_proof_fields(cases[cid]['theory'],c['goal'],lower['proof'],checked_zero|all_zero_permitted)
   equal(lower['coarse_dependency_rows'],dependency_rows(proof));assert len(lower['coarse_to_primitive'])==len(proof)
   for i,j in enumerate(lower['coarse_to_primitive']):
    if j is not None:assert type(j)is int and 0<=j<len(lower['proof']);equal(proof[i]['formula'],lower['proof'][j]['formula'])
   expansions=[]
   for x in lower['lemma_expansions']:
    lemma=lemma_byid[x['lemma_id']];assert len(x['primitive_rows'])==len(lemma['proof']);assert proof[x['coarse_row']]['name']==x['lemma_id']
    for k,j in enumerate(x['primitive_rows']):
     if j is not None:assert type(j)is int and 0<=j<len(lower['proof']);equal(lemma['proof'][k]['formula'],lower['proof'][j]['formula'])
    expansions.append({'coarse_row':x['coarse_row'],'lemma_id':x['lemma_id'],'reused':x['reused'],'surviving_primitive_rows':[j for j in x['primitive_rows']if j is not None]})
   item={'case':cid,'lane':lane,'goal':c['goal'],'coarse_nodes':len(proof),'used_depth':tree['max_used_depth'],'original_lines':len(lower['proof']),'coarse_axioms':coarse_axioms,'original_axioms':original_axioms,'lemma_expansions':expansions,'coarse_rules':dict(collections.Counter(x['rule']for x in proof)),'original_rules':dict(collections.Counter(x['rule']for x in lower['proof'])),'point_or_control_raw_ref':compact['ref'],'positive_ref':compact['positive_ref'],'native_coarse':pos['coarse_check'],'native_original':pos['original_check']};positives.append(item)
   for level,problem,pf,check in [('coarse',prep['problem'],proof,pos['coarse_check']),('original',cases[cid],lower['proof'],pos['original_check'])]:proof_requests.append({'id':row['id']+'-'+level,'theory':problem['theory'],'goal':problem['goal'],'proof':pf,'check':check})
   transcript+=['## '+cid+' / '+lane,'',r'Goal: \('+formula(c['goal'])+r'\)','']+proof_lines('Actual coarse tree',proof)+proof_lines('Actual original-theory proof',lower['proof'])
 cases_support.append({'id':cid,'goal':c['goal'],'minimum_coarse_tree_nodes_by_depth':goal_costs,'lanes':{lane:{'status':v['status'],'verified':v['verified'],'original_status':v['original_status'],'search_seconds':v['search_seconds'],'factory_seconds':v.get('factory_seconds'),'factory_audit_seconds':v.get('factory_audit_seconds'),'available_images':v.get('_passive_images',[]),'result_reason':v['result'].get('reason'),'stats_or_costs':v['result'].get('stats',v['result'].get('costs')),'provider':v.get('provider'),'tree_audit_decode_seconds':v.get('tree_audit_decode_seconds')}for lane,v in source_lanes.items()}})
assert len(positives)==15and len(negatives)==5and point_reasons=={'MAX_CANDIDATES':8,'MAX_WORK':1,'WALL_SECONDS':1}
assert states_checked==33and(events_retained,events_total,rollbacks_retained,rollbacks_total)==(98,4084,101,524)and(full_event_hashes,full_rollback_hashes)==(4,14)
# Every current native-key association and full saved byte/heap bridge is checked.
program=get(experiment['native_program']);native_identity={'sources':{k:plan['sources'][k]['sha256']for k in ('tree_machine','codec','carrier','fol_checker','real_parser')},'program':h(raw(program)),'limits':{k:limits[k]for k in ('native','codec','carrier','checker')}}
requests=[]
for i,lemma in enumerate(bank['lemmas']):requests.append({'id':'bank-lemma-'+str(i),'theory':dict(lemma['signature'],axioms=lemma['required_axioms']),'goal':lemma['goal'],'proof':lemma['proof'],'check':bankrecord['native'][i]})
requests+=proof_requests;assert len(requests)==34
native_support=[];seen={};native_lines_total=0;native_steps_total=0;native_bytes_total=0
for expected,actual in zip(requests,experiment['native_memo']['requests']):
 answer=expected['check'];assert actual['request_id']==expected['id'];equal({k:v for k,v in actual.items()if k!='request_id'},answer);assert answer['status']=='VERIFIED'
 digest=h(raw({'identity':native_identity,'theory':expected['theory'],'goal':expected['goal'],'proof':expected['proof']}));assert digest==answer['key_sha256'];record=get(answer['receipt_ref']);equal(record['theory'],expected['theory']);equal(record['goal'],expected['goal']);equal(record['proof'],expected['proof']);equal(record['decoding']['proof'],expected['proof'])
 assert record['status']=='VERIFIED'and record['native']['status']=='accepted'and type(record['native']['value'])is int and record['native']['value']==1 and record['independent']['status']=='VERIFIED'and record['independent']['checked_lines']==len(expected['proof'])
 stream=bytes.fromhex(record['encoding']['stream_hex']);assert record['encoding']['proof']is None and record['decoding']['stream_hex']is None;assert record['encoding']['status']==record['decoding']['status']=='COMPLETE'and record['decoding']['offset']==record['decoding']['counts']['bytes_read']==len(stream)
 equal(record['encoding']['limits'],limits['codec']);equal(record['decoding']['limits'],limits['codec']);equal(record['independent']['limits'],limits['checker']);assert len(expected['proof'])<=64
 value=record['carrier']['value'];base=value['nodes'];initial=record['initial_nodes'];final=record['final_heap'];assert base[:value['program_prefix_nodes']]==program['nodes']and value['program_sha256']==h(raw(program)[:-1])and value['trusted_prefix_sha256']==h(raw(base[:value['trusted_prefix_nodes']])[:-1])
 equal(value['known']['theory'],dict(expected['theory'],schemas=[]));equal(value['known']['target'],expected['goal']);assert value['known']['theory_sha256']==h(raw(value['known']['theory'])[:-1])and value['known']['target_sha256']==h(raw(value['known']['target'])[:-1])
 assert final[:len(initial)]==initial and len(base)==len(initial)and record['native']['heap_nodes']==len(final)
 for heap in (initial,final):
  assert len(set(map(tuple,heap)))==len(heap)
  for i,pair in enumerate(heap):assert type(pair)is list and len(pair)==2and all(type(x)is int and 0<=x<257+i for x in pair)
 assert len(value['byte_rows'])==value['byte_count']==len(stream)and len(set(value['marker_ids']))==len(stream)and min(value['marker_ids'])>=257+value['trusted_prefix_nodes']
 chosen=[list(x)for x in base]
 for i,row in enumerate(value['byte_rows']):
  assert row['byte_index']==i and row['node_id']==row['node_index']+257 and row['marker_id']==value['marker_ids'][i];assert base[row['node_index']]==[row['head_placeholder'],row['marker_id']];assert row['domain']=={'all_values_allowed':True,'minimum':0,'maximum':255};chosen[row['node_index']][0]=stream[i]
 equal(chosen,initial);assert record['choice']['status']=='VERIFIED'and record['choice']['byte_values']==list(stream)
 def word(node):
  values=[]
  while node!=256:
   assert 257<=node<=len(initial)+256;left,node=initial[node-257];values.append(left)
  return values
 assert word(value['input_node'])==[value['theory_node'],value['target_node'],value['stream_node']]and word(value['stream_node'])==[row['node_id']for row in value['byte_rows']]
 if answer['cache_hit']:assert digest in seen;equal(answer['receipt_ref'],seen[digest]['receipt_ref'])
 else:
  assert digest not in seen;seen[digest]=answer;native_lines_total+=len(expected['proof']);native_bytes_total+=len(stream);native_steps_total+=record['native']['steps']
 native_support.append({'id':expected['id'],'key_sha256':digest,'cache_hit':answer['cache_hit'],'proof_lines':len(expected['proof']),'proof_bytes':len(stream),'native_steps':record['native']['steps'],'receipt_ref':answer['receipt_ref'],'initial_nodes':len(initial),'final_nodes':len(final),'native_status':'accepted_int1','independent_status':'VERIFIED'})
assert len(seen)==30 and sum(x['cache_hit']for x in native_support)==4
assert experiment['native_memo']['executions']==30 and experiment['native_memo']['hits']==4and experiment['native_memo']['request_count']==34
assert math.isclose(experiment['native_memo']['execution_seconds'],sum(x['first_execution_seconds']for x in seen.values()),rel_tol=0,abs_tol=1e-9)
# Whole named comparisons bind their projected summaries to complete raw lane files.
assert len({p['case']for p in positives})==10
costs={'shared_preparations_seconds':sum(p['preparation_seconds']for p in experiment['preparations']),'raw_basis_build_seconds':sum(p['build_seconds']for p in experiment['preparations']),'independent_catalogue_seconds':sum(p['catalogue_audit_seconds']for p in experiment['preparations']),'independent_zero_wrapper_seconds':sum(p['zero_audit_seconds']for p in experiment['preparations']),'zero_host_batch_seconds':sum(x['seconds']for x in experiment['zero_schema_checks']),'checkpoint_pack_seconds':sum(p['checkpoint_seconds']for p in experiment['preparations']),'shared_checkpoint_load_seconds':sum(x['shared_checkpoint_load_seconds']for x in experiment['results']),'point_search_seconds':sum(x['lanes']['GROWTH_POINT_LEX']['search_seconds']for x in cases_support),'control_search_seconds':sum(x['lanes']['MATCHED_DEPTH_TREE_CONTROL']['search_seconds']for x in cases_support),'point_factory_seconds':sum(x['lanes']['GROWTH_POINT_LEX']['factory_seconds']for x in cases_support),'point_factory_audit_seconds':sum(x['lanes']['GROWTH_POINT_LEX']['factory_audit_seconds']for x in cases_support),'positive_tree_audit_decode_seconds':sum(v['tree_audit_decode_seconds']or 0 for x in cases_support for v in x['lanes'].values()),'unique_native_execution_seconds':experiment['native_memo']['execution_seconds'],'historical_W_donor_acquisition_seconds':experiment['historical_acquisition_seconds'],'native_program_preparation_seconds':experiment['native_preparation_seconds'],'experiment_seconds':experiment['seconds'],'worker_seconds':observer['worker_terminal']['elapsed_seconds'],'observer_seconds':observer['whole_observer_seconds'],'wait4_peak_bytes':observer['wait4_peak_bytes']}
transcript_path=O/'Z-study001-all-searched-positive-proofs-LaTeX-transcription-v1.md';transcript_path.write_text('# Saved Z main positive certificates\n\nAll formulas are literal presentations of saved ASTs. These are actual point/control certificates, not supplied search hints. Coarse proof trees and original-theory lowered proofs have different bounds/costs. No kernel or search replay.\n\n'+'\n'.join(transcript))
support={'schema':'Z-study001-complete-independent-passive-mathematical-support-v1','observer':pin(A/'observer-result.json'),'worker':pin(A/'worker-result.json.gz'),'original_tool_exit':pin(originalexit),'plan':pin(planpath),'all_current_inputs':inputpins,'all_actual_raw_file_pins':observer['files'],'artifact_count_including_worker':len(artifacts),'artifact_raw_bytes':rawtotal,'physical_files':143,'physical_stored_bytes':sum(p.stat().st_size for p in A.iterdir()),'catalogues':preparation_support,'zero_batches':15,'all_zero_lines':zero_total,'all_zero_rules':dict(zero_rules),'all15_cases':cases_support,'all5_finite_negative_depth_tables':negatives,'all15_searched_positives':positives,'all34_native_bindings':native_support,'available_point_state_images':states_checked,'event_prefix':{'retained':events_retained,'total':events_total,'full_stream_hashes_recomputed':full_event_hashes},'rollback_prefix':{'retained':rollbacks_retained,'total':rollbacks_total,'full_stream_hashes_recomputed':full_rollback_hashes},'native_unique':{'requests':34,'executions':30,'hits':4,'proof_lines':native_lines_total,'proof_bytes':native_bytes_total,'steps':native_steps_total},'costs':costs,'all_positive_transcription':pin(transcript_path),'scope':['Saved-data arithmetic only; no project import/helper/solver/control/model/VM/codec/checker invocation.','Complete finite min-node annotations are arithmetic over every saved zero/MP/GEN index at depths0..8, not project-control replay or a new proof search. Five target costs remain infinite at8. No unrestricted/original negative.','Full generation and zero semantics combine Source-reviewed independent-Y reconstruction and actual all-zero hostB receipts with complete saved payload/index/hash bindings; no substitution/truth-table kernel replay.','Main no per-change independent full graphs: all33 returned boundary images checked from actual loaded inventory and declared producers; event8/rollback32 bodies are only prefixes except explicitly complete streams.','All positives are current searched tree certificates, independently connected/postordered/t/m checked and linked to complete coarse/original native bridges. Original primitive lowerer may share exact formulas even when coarse tree duplicates them.']}
sp=O/'Z-study001-complete-independent-passive-mathematical-support-v1.json';sp.write_text(json.dumps(support,sort_keys=True,ensure_ascii=True,indent=2)+'\n')
print(json.dumps({'status':'PASS','support':pin(sp),'transcription':pin(transcript_path),'catalogue_zero_lines':zero_total,'zero_rules':dict(zero_rules),'positive_occurrences':len(positives),'distinct_goals':len({p['case']for p in positives}),'available_images':states_checked,'native':support['native_unique'],'costs':costs,'point_unknown_reasons':dict(point_reasons)},indent=2))
