from pathlib import Path
import ast,symtable,hashlib,json
D=Path('/private/tmp/gcts-growing-proof-obligations-20261028-v1/implementation-C');O=Path(__file__).parent;p=D/'anchored_proof_provider_v1.py';b=p.read_bytes();s=b.decode();H=lambda b:hashlib.sha256(b).hexdigest()
def pin(p):
 z=p.read_bytes();return {'path':str(p),'bytes':len(z),'sha256':H(z)}
assert len(b)==19166 and H(b)=='34cb1d0d7690858ac677e9aa4fda24416edf0e9425ce0303ed7410acb42a5fff'
hp=D/'Z-anchored-proof-provider-complete-inert-Source-handoff-v1.json';h=json.loads(hp.read_bytes());joins=[]
for key,val in h.items():
 if isinstance(val,dict)and set(val)=={'path','bytes','sha256'}:
  assert pin(Path(val['path']))==val;joins.append({'role':key,'ref':val})
api=json.loads((D/'Z-anchored-proof-provider-complete-public-ABI-v1.json').read_bytes());ann=api['exact_nested_annex'];assert pin(Path(ann['path']))==ann
assert pin(Path(api['current_engine_public_ABI']['path']))==api['current_engine_public_ABI']
t=ast.parse(s,str(p));st=symtable.symtable(s,str(p),'exec');unused=compile(s,str(p),'exec');del unused
units=[]
def cname(n):
 if isinstance(n,ast.Name):return n.id
 if isinstance(n,ast.Attribute):return cname(n.value)+'.'+n.attr
 return ast.unparse(n)
def walk(n,path):
 for c in ast.iter_child_nodes(n):
  if isinstance(c,(ast.FunctionDef,ast.ClassDef)):
   name=path+'.'+c.name if path else c.name
   raw='\n'.join(s.splitlines()[c.lineno-1:c.end_lineno]).encode();units.append({'name':name,'line':c.lineno,'end':c.end_lineno,'raw_sha256':H(raw),'AST_sha256':H(ast.dump(c,include_attributes=False).encode()),'signature':ast.unparse(c.args)if isinstance(c,ast.FunctionDef)else None,'calls':sorted({cname(k.func)for k in ast.walk(c)if isinstance(k,ast.Call)})})
   walk(c,name)
  else:walk(c,path)
walk(t,'')
provided=json.loads((D/'Z-anchored-proof-provider-complete-static-v1.json').read_bytes());assert len(units)==24==provided['named_units']
for a,z in zip(units,provided['helpers']):
 for k in ('name','line','end'):assert a[k]==z[k]
scopes=[]
def rec(q,path):
 e=[]
 for n in sorted(q.get_identifiers()):
  z=q.lookup(n);e.append({'name':n,'parameter':z.is_parameter(),'referenced':z.is_referenced(),'assigned':z.is_assigned(),'global':z.is_global(),'local':z.is_local(),'free':z.is_free(),'nonlocal':z.is_nonlocal(),'imported':z.is_imported()})
 z=(json.dumps(e,sort_keys=True,indent=2,allow_nan=False)+'\n').encode();scopes.append({'path':path,'line':q.get_lineno(),'kind':q.get_type(),'identifiers':len(e),'all_symbol_flags_sha256':H(z)})
 for i,c in enumerate(q.get_children()):rec(c,path+'/'+c.get_name()+':'+str(c.get_lineno())+':'+str(i))
rec(st,'module');assert len(scopes)==44==provided['scopes']
body={'schema':'Z-anchored-provider-independent-static-support-v1','Source':pin(p),'handoff':pin(hp),'all_handoff_rawref_joins':joins,'API_exact_annex':ann,'current_B_API':api['current_engine_public_ABI'],'fingerprint_recipe':'Independent raw unit is LF-joined Source lines lineno..end_lineno with no finalLF; AST is ast.dump(node,include_attributes=False).encode(). Producer unit fingerprint convention is not assumed; whole rawSource and all unit names/positions are exactjoined.','AST_sha256':H(ast.dump(t,include_attributes=False).encode()),'positioned_AST_sha256':H(ast.dump(t,include_attributes=True).encode()),'lines':len(s.splitlines()),'all_units':units,'all_symbol_scopes':scopes,'imports':[ast.unparse(n)for n in t.body if isinstance(n,(ast.Import,ast.ImportFrom))],'checks':{'all24_unit_positions_equal_producer_static':True,'all24_callsets_independently_derived':True,'all44_symbol_scopes':True,'AST_parse':'PASS','symtable':'PASS','unused_compile':'PASS','subject_functions_imports_fixtures_probes_calls':0}}
q=O/'Z-anchored-provider-complete-independent-static-support-v1.json';q.write_bytes((json.dumps(body,sort_keys=True,indent=2,allow_nan=False)+'\n').encode());print(json.dumps({'Source':pin(p),'support':pin(q),'units':len(units),'scopes':len(scopes)},sort_keys=True))
