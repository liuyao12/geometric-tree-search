"""Saved bytes/JSON/gzip/hash/association arithmetic only; no project imports."""
from pathlib import Path
import gzip,hashlib,json,shlex,re,collections,math
Z=Path('/private/tmp/gcts-growing-proof-obligations-20261028-v1');R=Z/'root';D=Z/'actual/study-001';O=Path(__file__).parent
H=lambda b:hashlib.sha256(b).hexdigest()
def wire(v):return (json.dumps(v,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')
def pairs(rows):
 d={}
 for k,v in rows:assert k not in d;d[k]=v
 return d
def parse(b):return json.loads(b,object_pairs_hook=pairs,parse_constant=lambda z:(_ for _ in ()).throw(ValueError(z)))
def stable(p):
 p=Path(p);assert p.is_absolute()and p.resolve()==p and p.is_file()and not p.is_symlink();a=p.stat();b=p.read_bytes();c=p.stat();assert a.st_nlink==1 and(a.st_ino,a.st_mtime_ns,a.st_size)==(c.st_ino,c.st_mtime_ns,len(b));return b
def pin(p,b=None):
 if b is None:b=stable(p)
 return {'path':str(p),'bytes':len(b),'sha256':H(b)}
def read(r):assert type(r)is dict and set(r)=={'path','bytes','sha256'}and type(r['bytes'])is int;raw=stable(r['path']);assert pin(r['path'],raw)==r;return raw
def doc(p):return parse(stable(p))
def same(a,b):assert wire(a)==wire(b)
pp=R/'study-once-plan-001.json';pr=pin(pp);plan=doc(pp);assert pr['bytes']==18532 and pr['sha256']=='65712862453a74e26cea265fab4ecb81c6a2146cbb03bdc8670d11a961d898d1';assert len(plan['sources'])==15 and len(plan['metadata'])==50
for ref in list(plan['sources'].values())+list(plan['metadata'].values())+[plan['python'],plan['bootstrap']]:read(ref)
same(plan['limits'],{'worker_seconds':1200,'observer_seconds':1230,'rss_bytes':1073741824,'file_bytes':67108864,'total_bytes':1073741824,'max_files':768,'stream_bytes':1048576})
obs=doc(D/'observer-result.json');assert pin(D/'observer-result.json')['sha256']=='b3b5db92ed9215f3ff8b7fa1962788e6f9bbbe3d1d7f042499e6b432613a3aa0';assert obs['schema']=='Z-owned-growing-proof-search-observer-result-v1'and obs['status']=='COMPLETE'and type(obs['returncode'])is int and obs['returncode']==0 and obs['failure']is None and obs['cleanup_errors']==[] and all(obs[k]is True for k in ('both_streams_EOF','group_gone','wait_confirmed'))and all(obs['retained_streams_complete'].values())
assert obs['stdin_bytes_sent']==19495 and obs['whole_observer_seconds']<1230 and obs['wait4_peak_bytes']<=1073741824
physical=sorted(D.iterdir());assert len(physical)==143 and len(obs['files'])==142
for ref in obs['files']:assert Path(ref['path']).parent==D;read(ref)
assert {p.name for p in physical}=={Path(r['path']).name for r in obs['files']}|{'observer-result.json'};assert sum(r['bytes']for r in obs['files'])==obs['stored_bytes']<1073741824
wt=parse(read(obs['streams']['stdout']));assert read(obs['streams']['stderr'])==b'';same(wt,obs['worker_terminal']);assert wt['status']=='COMPLETE'and wt['plan']==pr and wt['elapsed_seconds']<1200
assert obs['observed_stream_bytes']=={'stdout':obs['streams']['stdout']['bytes'],'stderr':0}
assert obs['command']==[plan['python']['path'],'-I','-S','-B',plan['bootstrap']['path'],plan['sources']['runner']['path'],'19495',plan['sources']['runner']['sha256'],'--mode','worker','--plan',str(pp)]
ap=R/'study-once-A6-001.json';ar=pin(ap);a=doc(ap);same(a,{'schema':'Z-growing-proof-search-once-authority-v1','uses':1,'authorized':True,'plan':pr,'runner':plan['sources']['runner'],'python':plan['python']});assert type(a['uses'])is int and type(a['authorized'])is bool
cp=Path(str(ap)+'.CONSUMED.json');cr=pin(cp);same(doc(cp),{'authority':ar,'plan':pr,'status':'SPENT'});same(doc(D/'CONSUMED.json'),{'authority':ar,'consumed':cr})
same(doc(R/'study-once-001.outer.stdout.bin'),{'status':'COMPLETE','receipt':pin(D/'observer-result.json')});assert stable(R/'study-once-001.outer.stderr.bin')==b''
toolp=R/'study-once-001.original-tool-exit-v1.json';tool=doc(toolp);assert pin(toolp)['sha256']=='6352103c8d206d9108c0af0741aeb7962fd14bbcd304b1f2de04100a6a7ec53c';assert tool['invocation']['chunk_id']=='542057'and tool['invocation']['session_id']==tool['original_terminal']['session_id']==28013 and tool['original_terminal']['chunk_id']=='da4edf'and type(tool['original_terminal']['exit_code'])is int and tool['original_terminal']['exit_code']==0 and tool['original_terminal']['output']==''
caller=stable(R/'study-once-caller-001.sh').decode();first,body=caller.split('\n',1);assert first=='set -C';assert shlex.split(body)==[plan['python']['path'],'-I','-S','-B','-c',read(plan['bootstrap']).decode(),plan['sources']['runner']['path'],'19495',plan['sources']['runner']['sha256'],'--mode','observer','--plan',str(pp),'--authority',str(ap),'<',plan['sources']['runner']['path'],'>',str(R/'study-once-001.outer.stdout.bin'),'2>',str(R/'study-once-001.outer.stderr.bin')]
assert tool['invocation']['cmd']=='/bin/zsh -f '+str(R/'study-once-caller-001.sh')and tool['invocation']['login']is False and tool['invocation']['cwd']==str(R)
ca=doc(R/'Z-Root-concrete-main-caller-adoption-v1.json');same(ca['plan'],pr)
for k in ('caller','complete_Source_adoption','independent_plan_preflight'):read(ca[k])
# Artifact readbacks stream one at a time; retain only descriptors and small summaries.
descriptors={};rawtotal=storedtotal=0;compressed=0

def artifact(desc,register=False):
 global rawtotal,storedtotal,compressed
 assert set(desc)=={'name','stored','encoding','raw_bytes','raw_sha256'}and type(desc['raw_bytes'])is int;stored=read(desc['stored']);assert Path(desc['stored']['path']).parent==D
 raw=gzip.decompress(stored)if desc['encoding']=='gzip-json'else stored;assert desc['encoding']in('json','gzip-json')and len(raw)==desc['raw_bytes']and H(raw)==desc['raw_sha256'];assert (len(raw)>65536)==(desc['encoding']=='gzip-json')and len(raw)<=67108864 and len(stored)<=67108864
 value=parse(raw);assert wire(value)==raw
 if register:
  assert desc['name']not in descriptors;descriptors[desc['name']]=desc;rawtotal+=len(raw);storedtotal+=len(stored);compressed+=int(desc['encoding']=='gzip-json')
 return value
worker=artifact(wt['result'],True);assert worker['schema']=='Z-growing-proof-search-study-v1'and worker['status']=='COMPLETE'and len(worker['artifacts'])==138
for desc in worker['artifacts']:artifact(desc,True)
assert len(descriptors)==139 and storedtotal<1040187392;assert {Path(x['stored']['path']).name for x in descriptors.values()}|{'CONSUMED.json','stdout.bin','stderr.bin','observer-result.json'}=={p.name for p in physical}
def named(name):return artifact(descriptors[name])
e=worker['experiment'];assert e['status']=='COMPLETE'and e['schema']=='Z-growing-proof-comparison-experiment-v1';design=parse(read(plan['metadata']['design']));limits=parse(read(plan['metadata']['experiment_limits']));cases=parse(read(plan['metadata']['cases']));same(e['design'],design);same(e['limits'],limits);assert len(e['results'])==len(e['preparations'])==15 and [r['id']for r in e['results']]==[r['id']for r in e['preparations']]==design['case_order'];same(e['qualification_prerequisite'],parse(read(plan['metadata']['qualification_prerequisite'])))
# Full original donor rawbytes and detached source problem/proof associations.
manifest=parse(read(plan['metadata']['donor_manifest']));donor_joins=[];donorbytes=0
for row,j in zip(manifest['donors'],e['donor_custody']):
 b=read(row['source_ref']);donorbytes+=len(b);raw=gzip.decompress(b);assert len(raw)==row['uncompressed_bytes']==j['raw_bytes']and H(raw)==row['uncompressed_sha256']==j['raw_sha256'];v=parse(raw);assert set(v)==set(row['keys']);assert v['status']=='VERIFIED'and v['native']['status']=='accepted'and type(v['native']['value'])is int and v['native']['value']==1 and v['independent']['status']=='VERIFIED'
 assert row['id']==j['id']==j['association']['id'];same(row['source_ref'],j['source_ref']);same(row['source_ref'],j['association']['source_ref'])
 for field in ('theory','goal','proof'):assert H(wire(v[field]))==j['association'][field+'_sha256']
 donor_joins.append({'id':row['id'],'stored':row['source_ref'],'raw_bytes':len(raw),'raw_sha256':H(raw)})
assert len(donor_joins)==6 and donorbytes==304900
program=artifact(e['native_program']);bankrec=artifact(e['bank_ref']);bank=bankrec['result']['value'];assert bankrec['result']['status']=='COMPLETE'and bankrec['audit']['status']=='VERIFIED'and len(bank['donors'])==6 and len(bank['lemmas'])==4
expected_checks=[]
for i,(lemma,check)in enumerate(zip(bank['lemmas'],bankrec['native'])):expected_checks.append(('bank-lemma-'+str(i),{'theory':dict(lemma['signature'],axioms=lemma['required_axioms']),'goal':lemma['goal']},lemma['proof'],check))
# Complete actual preparation/checkpoint/build/zero/30position bindings.
prep_joins=[];position_joins=[];zero_lines=0;point_status=collections.Counter();point_reason=collections.Counter();control_status=collections.Counter();images=events_retained=rollbacks_retained=0;complete_events=complete_rollbacks=0;full_event_total=full_rollback_total=0
prefixes=[];max_search=0.0

def state_image(s):
 assert set(s)=={'Q','totals','selected','marks','excluded','eligible','domains','forward','reverse','placements','loaded','dependencies','edge_count'};assert s['edge_count']==len(s['forward'])==sum(len(rows)for cid,rows in s['reverse']);assert sorted(s['forward'])==sorted([[p,cid,n]for cid,rows in s['reverse']for p,n in rows]);assert sum(len(ids)for p,ids in s['domains'])==s['edge_count']
for prep,comparison in zip(e['preparations'],e['results']):
 cid=prep['id'];assert prep['status']=='COMPLETE'and comparison['id']==cid and comparison['depth']==8;same(comparison['original'],cases[cid]);same(prep['original'],cases[cid]);savedprep=artifact(prep['preparation_ref']);same(savedprep,{k:v for k,v in prep.items()if k!='preparation_ref'});assert prep['extension']['status']=='COMPLETE'and prep['extension_audit']['status']=='VERIFIED'and prep['catalogue_audit']['status']=='VERIFIED'and prep['zero_audit']['status']=='VERIFIED'
 build=artifact(prep['build_ref']);assert build['status']=='COMPLETE';compiled=build['compiled'];generation=build['generation'];same(generation,prep['generation']);same(compiled['theory'],prep['problem']['theory']);same(compiled['goal'],cases[cid]['goal']);same(compiled['profile'],design['generation_profile']);core={k:v for k,v in compiled.items()if k not in ('costs','scope')};core_sha=H(wire(core));assert core_sha==generation['compiled_core_sha256']==prep['catalogue_audit']['details']['compiled_core_sha256'];ck=prep['checkpoint'];raw=wire(compiled);assert len(raw)==ck['raw_bytes']and H(raw)==ck['raw_sha256']and H(wire(prep['problem']))==ck['problem_sha256']and H(wire(generation))==ck['generation_sha256'];assert ck['raw_bytes']<=limits['checkpoint']['max_raw_bytes']and ck['packed_bytes']<=limits['checkpoint']['max_packed_bytes']
 savedcomp=artifact(comparison['ref']);same(savedcomp,{k:v for k,v in comparison.items()if k!='ref'});same(comparison['preparation_ref'],prep['preparation_ref'])
 for lane in design['lane_order']:
  summary=comparison['lanes'][lane];row=artifact(summary['ref']);assert row['lane']==lane and row['status']==summary['status']and row['verified']==summary['verified']and row['original_status']==summary['original_status'];same(row['preparation_ref'],prep['preparation_ref']);assert row['checkpoint_load_seconds']==comparison['shared_checkpoint_load_seconds'];res=row['result'];assert res['status']==row['status']
  if lane=='GROWTH_POINT_LEX':
   point_status[row['status']]+=1;point_reason[row['reason']]+=1;max_search=max(max_search,row['search_seconds']);assert row['factory']['status']=='COMPLETE'and row['factory_audit']['status']=='VERIFIED';assert row['model']['inventory']['identity']==row['factory']['value']['identity']==row['provider']['identity'];assert row['factory']['value']['compiled_core_sha256']==core_sha
   assert res['model_sha256']is None or res['model_sha256']==H(wire(row['model']))
   for key in ('entry','final','restored'):
    image=res[key+'_state'];h=res['state_hashes'][key]
    if image is None:assert h is None
    else:state_image(image);assert H(wire(image))==h;images+=1
   if res['entry_state']is not None:same(res['entry_state'],res['restored_state']);assert res['state_hashes']['entry']==res['state_hashes']['restored']
   if res['status']=='UNKNOWN':assert res['final_state']is None and res['certificate']is None and res['selected']==[]
   for kind,body in [('event',res['events']),('rollback',res['rollback_records'])]:
    ext=res[kind+'_extent'];assert ext['scope']=='BOUNDED_PREFIX_COMPLETE_EMITTED_STREAM_HASH'and type(ext['total'])is int and type(ext['retained'])is int and ext['retained']==len(body)<=ext['total']and re.fullmatch('[0-9a-f]{64}',ext['sha256']);prefixsha=H(b''.join(wire(r)for r in body))
    if len(body)==ext['total']:assert prefixsha==ext['sha256']
    if kind=='event':
     assert all(r['seq']==i for i,r in enumerate(body));events_retained+=len(body);full_event_total+=ext['total'];complete_events+=int(len(body)==ext['total']);assert res['stats']['events_total']==ext['total']
    else:
     rollbacks_retained+=len(body);full_rollback_total+=ext['total'];complete_rollbacks+=int(len(body)==ext['total']);assert res['stats']['rollbacks_total']==ext['total']
     for r in body:assert r['from_trail']-r['to_trail']==r['undone']and r['selected_after']<=r['selected_before']
    prefixes.append({'id':row['id'],'stream':kind,'full_extent':ext,'retained_prefix_sha256':prefixsha,'full_digest_recomputed':len(body)==ext['total']})
   assert res['stats']['work']<=res['limits']['max_work']and res['stats']['nodes']<=res['limits']['max_nodes']and res['stats']['peak_candidates']<=res['limits']['max_candidates']and res['stats']['peak_Q']<=res['limits']['max_points']
  else:control_status[row['status']]+=1
  positive=(row['status']=='SAT'if lane=='GROWTH_POINT_LEX'else row['status']=='DERIVABLE')
  if positive:
   assert row['verified']is True and row['original_status']=='VERIFIED'and row['tree_audit']['status']=='VERIFIED'and row['decoded']['status']=='UNVERIFIED_CERTIFICATE';same(row['tree_audit']['proof'],row['decoded']['proof']);same(row['decoded']['target'],cases[cid]['goal']);pos=row['positive'];same(pos['coarse_proof'],row['decoded']['proof']);same(artifact(pos['ref']),{k:v for k,v in pos.items()if k!='ref'});same(summary['positive_ref'],pos['ref']);assert summary['coarse_lines']==len(pos['coarse_proof'])and summary['original_lines']==len(pos['original_proof'])
   assert pos['lowering']['status']=='COMPLETE'and pos['lowering_audit']['status']=='VERIFIED';low=pos['lowering']['value'];same(low['theory'],cases[cid]['theory']);same(low['goal'],cases[cid]['goal']);same(low['proof'],pos['original_proof']);assert len(pos['coarse_proof'])<=64 and len(pos['original_proof'])<=64
   if lane=='GROWTH_POINT_LEX':
    tr=row['decoded']['tree'];same(res['certificate'],{'capacity':2,'roots':row['model']['roots'],'seed':row['model']['seed'],'placements':tr['placements'],'totals':tr['totals'],'marks':tr['marks']});same(res['selected'],tr['selected'])
   else:same(res['proof'],pos['coarse_proof']);same(res['details']['selected'],row['decoded']['tree']['selected'])
   expected_checks.append((row['id']+'-coarse',prep['problem'],pos['coarse_proof'],pos['coarse_check']));expected_checks.append((row['id']+'-original',cases[cid],pos['original_proof'],pos['original_check']))
  else:assert row['verified']is False and 'positive'not in row
  position_joins.append({'case':cid,'lane':lane,'status':row['status'],'original_status':row['original_status'],'verified':row['verified'],'ref':summary['ref'],'search_seconds':row['search_seconds']})
 prep_joins.append({'id':cid,'ref':prep['preparation_ref'],'build':prep['build_ref'],'compiled_sha256':H(raw),'core_sha256':core_sha,'checkpoint':ck,'status':prep['status']})
 del compiled,build,raw,row
assert len(position_joins)==30 and point_status=={'SAT':5,'UNKNOWN':10}and control_status=={'DERIVABLE':10,'NOT_DERIVABLE':5};assert len(expected_checks)==34
assert sum(p['checkpoint']['packed_bytes']for p in e['preparations'])==e['checkpoint_total_packed_bytes']<=limits['checkpoint']['max_total_packed_bytes']
for desc in e['zero_schema_checks']:
 v=artifact(desc['ref']);assert v['receipt']['status']==desc['status']=='VERIFIED'and len(v['proof'])==desc['lines']==v['receipt']['checked_lines'];same(v['limits'],limits['zero_checker']);zero_lines+=len(v['proof'])
assert len(e['zero_schema_checks'])==15
# Current-run whole Native memo keys and all30 full codec/carrier/kernel receipt bodies.
identity={'sources':{k:plan['sources'][k]['sha256']for k in ('tree_machine','codec','carrier','fol_checker','real_parser')},'program':H(wire(program)),'limits':{k:limits[k]for k in ('native','codec','carrier','checker')}}
memo=e['native_memo'];assert memo['request_count']==len(memo['requests'])==34 and memo['executions']==30 and memo['hits']==4;seen={};native_rows=[]
for (identity_id,problem,proof,check),req in zip(expected_checks,memo['requests']):
 same(req,dict(check,request_id=identity_id));key=H(wire({'identity':identity,'theory':problem['theory'],'goal':problem['goal'],'proof':proof}));assert req['key_sha256']==key and req['status']=='VERIFIED';nr=artifact(req['receipt_ref']);same(nr['theory'],problem['theory']);same(nr['goal'],problem['goal']);same(nr['proof'],proof);same(nr['decoding']['proof'],proof);assert nr['status']=='VERIFIED'and nr['decoding']['status']=='COMPLETE'and nr['encoding']['status']=='COMPLETE'and nr['choice']['status']=='VERIFIED'and nr['native']['status']=='accepted'and type(nr['native']['value'])is int and nr['native']['value']==1 and nr['independent']['status']=='VERIFIED'and nr['independent']['checked_lines']==len(proof)==req['proof_lines']<=64 and req['native_steps']==nr['native']['steps']
 stream=bytes.fromhex(nr['encoding']['stream_hex']);assert len(stream)==req['proof_bytes']and nr['choice']['byte_values']==list(stream);cv=nr['carrier']['value'];base=cv['nodes'];initial=nr['initial_nodes'];assert len(base)==len(initial);chosen={v['node_index']:stream[v['byte_index']]for v in cv['byte_rows']}
 for i,(a,b)in enumerate(zip(base,initial)):assert(b==[chosen[i]]+a[1:]if i in chosen else a==b)
 assert nr['final_heap'][:len(initial)]==initial
 if key in seen:assert req['cache_hit']is True;same(req['receipt_ref'],seen[key]['receipt_ref'])
 else:
  assert req['cache_hit']is False;seen[key]=req;native_rows.append({'key':key,'first_request':identity_id,'ref':req['receipt_ref'],'lines':len(proof),'bytes':len(stream),'steps':req['native_steps']})
assert len(seen)==30 and abs(sum(v['first_execution_seconds']for v in seen.values())-memo['execution_seconds'])<1e-9
calls=worker['outer_public_calls'];same(calls,wt['public_calls']);assert sum(calls.values())==427 and max(calls.values())<=512 and calls['engine.solve']==15 and calls['compiler.build_basis']==15 and calls['growth_audit.tree_control']==15 and calls['fol_checker.check']==45
support={'schema':'Z-study001-complete-independent-passive-custody-support-v1','status':'PASS_COMPLETE_CURRENT_MAIN_SAVED_ASSOCIATIONS','original_tool':pin(toolp),'outer_stdout':pin(R/'study-once-001.outer.stdout.bin'),'outer_stderr':pin(R/'study-once-001.outer.stderr.bin'),'observer':pin(D/'observer-result.json'),'worker_result':wt['result'],'plan':pr,'all15Sources':plan['sources'],'all50metadata':plan['metadata'],'python':plan['python'],'bootstrap':plan['bootstrap'],'A6':ar,'consume':cr,'Root_concrete_adoption':pin(R/'Z-Root-concrete-main-caller-adoption-v1.json'),'all143files':[pin(p)for p in physical],'physical_bytes':sum(p.stat().st_size for p in physical),'all139artifact_descriptors':list(descriptors.values()),'artifact_raw_bytes':rawtotal,'artifact_stored_bytes':storedtotal,'gzip_artifacts':compressed,'donors':donor_joins,'donor_stored_bytes':donorbytes,'all15preparations':prep_joins,'all30positions':position_joins,'point_status':dict(point_status),'point_reason':dict(point_reason),'control_status':dict(control_status),'all_point_state_images_hashed':images,'retained_event_rows':events_retained,'retained_rollback_rows':rollbacks_retained,'full_event_extents_total':full_event_total,'full_rollback_extents_total':full_rollback_total,'complete_event_streams_recomputed':complete_events,'complete_rollback_streams_recomputed':complete_rollbacks,'all30stream_prefix_audits':prefixes,'native_request_count':34,'native_executions':30,'native_hits':4,'all30unique_native':native_rows,'unique_native_lines':sum(v['lines']for v in native_rows),'unique_native_bytes':sum(v['bytes']for v in native_rows),'unique_native_steps':sum(v['steps']for v in native_rows),'zero_schema_batches':15,'zero_schema_lines':zero_lines,'all_outer_calls':calls,'outer_calls_total':427,'clock_RSS':{'observer_seconds':obs['whole_observer_seconds'],'worker_seconds':wt['elapsed_seconds'],'peak_bytes':obs['wait4_peak_bytes'],'max_point_search_seconds':max_search},'activity':{'project_Source_function_or_helper_calls':0,'VM_checker_compiler_solver_codec_fixture_replays':0,'network':0,'original_Source_actual_or_metadata_mutations':0}}
p=O/'Z-study001-complete-passive-custody-support-v1.json';p.write_bytes((json.dumps(support,sort_keys=True,indent=2,allow_nan=False)+'\n').encode());print(json.dumps({'support':pin(p),'physical_bytes':support['physical_bytes'],'artifact_raw_bytes':rawtotal,'stored_bytes':storedtotal,'gzip':compressed,'images':images,'events_retained':events_retained,'event_total':full_event_total,'rollbacks_retained':rollbacks_retained,'rollback_total':full_rollback_total,'full_event_streams':complete_events,'full_rollback_streams':complete_rollbacks,'unique_native_lines':support['unique_native_lines'],'unique_native_bytes':support['unique_native_bytes'],'unique_native_steps':support['unique_native_steps'],'zero_lines':zero_lines},sort_keys=True))
