import json,hashlib,pathlib
Z=pathlib.Path('/private/tmp/gcts-growing-proof-obligations-20261028-v1')
B=Z/'implementation-C/report-draft'
O=pathlib.Path('/private/tmp/gcts-L-Z-reader-content-peer-v1')
def raw(p):return pathlib.Path(p).read_bytes()
def ref(p):
 p=pathlib.Path(p);a=raw(p);return {'path':str(p),'bytes':len(a),'sha256':hashlib.sha256(a).hexdigest()}
def load(p):return json.loads(raw(p))
def wire(x):return (json.dumps(x,ensure_ascii=True,sort_keys=True,separators=(',',':'))+'\n').encode()
def put(name,x):
 p=O/name
 assert not p.exists(),str(p)
 p.write_bytes((json.dumps(x,ensure_ascii=True,sort_keys=True,indent=2)+'\n').encode())
 return ref(p)
def guard(r):
 a=ref(r['path']);assert a==r,(a,r);return a
old=B/'output-001';new=B/'output-002'
a=load(old/'growing-proof-search-results-v1.json');b=load(new/'growing-proof-search-results-v1.json')
assert set(a)==set(b)
assert [k for k in a if a[k]!=b[k]]==['provenance_sources']
aa={k:v for k,v in a.items() if k!='provenance_sources'};bb={k:v for k,v in b.items() if k!='provenance_sources'}
assert wire(aa)==wire(bb)
p=a['provenance_sources'];q=b['provenance_sources'];assert len(p)==len(q)==124
changed=[{'previous':x,'current':y} for x,y in zip(p,q) if x!=y]
assert len(changed)==1
assert changed[0]['previous']['path']==str(B/'growing-proof-reader-template-v2.html')
assert changed[0]['current']['path']==str(B/'growing-proof-reader-template-v3.html')
checked=[guard(x) for x in q]
html=ref(new/'growing-proof-search-v1.html');results=ref(new/'growing-proof-search-results-v1.json');projection=ref(new/'reader-projection-receipt-v1.json')
assert html['bytes']==25230 and html['sha256']=='95dd9872cb29288a878ef81487f48691d29293504b84d363d60fafe0deb7bd6b'
assert results['bytes']==775432 and results['sha256']=='de84990edfcc2a06c26329b4d07c0bb1fc368392986711fa3908b6226b059670'
assert raw(new/'growing-proof-search-v1.html')==raw(B/'growing-proof-reader-template-v3.html')
pr=load(projection['path']);assert pr['inputs']==q and pr['files']==[html,results] and pr['status']=='COMPLETE' and pr['positive_pairs']==15
assert pr['counts']=={'GROWTH_POINT_LEX':{'SAT':5,'UNKNOWN':10},'MATCHED_DEPTH_TREE_CONTROL':{'DERIVABLE':10,'NOT_DERIVABLE':5}}
for f in pr['files']:guard(f)
qa76=Z/'root/local-reader-all76-UI-checks-v1.json';qa7=Z/'root/local-reader-template3-focused-UI-v1.json'
u=load(qa76);v=load(qa7)
assert u['status']==v['status']=='PASS' and len(u['checks'])==76 and len(v['checks'])==7
for c in v['checks']:
 assert c['errors']==0 and c['overflow'] is False and c['formulaYHidden'] is True and c['greenFrames']==c['greenRows']
qa_binding=Z/'root/Z-Root-final-reader-local-QA-and-projection-binding-v1.json';qb=load(qa_binding)
assert qb['status']=='PASS_PRESENTATION_PENDING_FINAL_CONTENT_PEER'
prior_support=O/'Z-reader-complete-independent-passive-projection-support-v1.json';ps=load(prior_support)
assert ps['status']=='PASS' and ps['cases']==19 and ps['method_positions']==38 and len(ps['all_actual_and_realized_tile_bindings'])==176
assert ps['displayed_proof_lines']=={'coarse':176,'original_overlay':242}
delta=O/'Z-reader-template3-independent-passive-presentation-delta-v1.json'
admission=Z/'root/Z-Root-whole-growing-main-scientific-admission-v1.json'
support={
 'schema':'Z-reader-final-output002-independent-passive-binding-support-v1','status':'PASS','blockers':[],
 'final_HTML':html,'final_results':results,'final_projection_receipt':projection,
 'renderer':guard(pr['source']),'template3':ref(B/'growing-proof-reader-template-v3.html'),
 'all_final_124_source_guards':checked,'source_guard_count':len(checked),
 'only_results_field_changed':'provenance_sources','only_changed_source_ref':changed[0],
 'all_nonprovenance_results_fields_exactly_preserved':True,
 'nonprovenance_canonical_SHA256':hashlib.sha256(wire(bb)).hexdigest(),
 'final_HTML_exact_template3':True,'projection_output_files_and_inputs_exact':True,
 'inherited_complete_projection_support':ref(prior_support),'independent_template3_delta':ref(delta),
 'root_scientific_admission':ref(admission),'root_final_QA_binding':ref(qa_binding),
 'browser_QA':{'owner':'Root','inherited_template2_all_views':ref(qa76),'inherited_views':76,'final_template3_focused_views':ref(qa7),'final_views':7,'focused_checks':v['checks'],'final_screenshot':ref(Z/'root/local-reader-final-proof-view-v1.png'),'L_screenshot_visual_inspection':True,'L_browser_or_JS_execution':False,'scope':'Root desktop QA; no mobile or independent all-76-template3 browser claim.'},
 'scope':'Only standard-library saved bytes/JSON/hash comparisons and the previously completed passive full renderer/template/data review. No scientific helper, solver, VM, codec, checker, renderer or JS was executed by L. Actual and published-source inputs unchanged.'}
sr=put('Z-reader-final-output002-independent-passive-binding-support-v1.json',support)
review={
 'schema':'Z-reader-complete-independent-final-content-review-v1','status':'PASS','blockers':[],
 'final_outputs':{'HTML':html,'results':results,'projection_receipt':projection},
 'support':{'complete_projection':ref(prior_support),'template3_presentation_delta':ref(delta),'final_output002_binding':sr},
 'scientific_authority':{'whole_main_Root_admission':ref(admission),'role':'Passive review of the already admitted complete run; no new scientific authority or replay.'},
 'complete_data_projection':{
  'cases':19,'method_positions':38,'main_cases':15,'qualification_cases':4,'main_positive_coarse_original_pairs':15,'qualification_positive_proof_views':8,
  'all_tile_site_t_m_bindings':176,'actual_point_views':9,'actual_point_selected_nodes':81,'control_realization_views':14,'control_realization_nodes':95,
  'coarse_displayed_proof_lines':176,'original_overlay_displayed_proof_lines':242,
  'checks':['All cases, both method positions, outcomes, reasons, raw outputs, bounds, costs, independent audits, native checks and provenance were compared against complete saved records.','All selected placement IDs, sites, producer definitions, premise edges, postorder proof rows, site-to-line maps, unit supports, capacity-two totals, literal formula marks and mark refcounts match the saved actual decoder results.','Original-theory overlays match actual lowered native certificates and carry no invented point placement IDs.','All 124 final source refs were independently full-read, size/SHA256 checked and joined to the final projection receipt.','Output-002 science/proof/results equal output-001 in every field except the one template provenance replacement. The complete earlier data review therefore applies without a semantic delta.']},
 'mathematical_and_English_review':[
  'Entire renderer Source and template2 HTML/JS/CSS/prose were read; the complete template3 presentation delta was independently checked in both raw patch directions. No renderer or JavaScript execution was used.',
  'Formula output uses LaTeX with the existing MathJax renderer; direct quantified operands are parenthesized as whole operands of implication, conjunction or disjunction. Negation and binder scope preserve the recorded AST, including capture-avoiding fresh0 names.',
  'GIVEN, MP, generalization, universal instantiation, equality substitution, reflexivity, propositional tautology and distribution descriptions agree with recorded rule fields. English generalization variables are typeset with LaTeX.',
  'Site diagrams distinguish actual GCTS placements from allowed realizations of independently returned control trees. Primitive original-theory views are logical overlays, not claimed base tilings.',
  'Root-seeded frontier-growth reachability is explicitly required; arbitrary disconnected completed packings are not asserted equivalent to rooted proofs. Square glyphs are display conventions, without a geometric Wang-palette claim.',
  'The imported-lemma set is computed from actual application bindings. Template3 passes that same set to SVG rendering, and only actual imported axiom nodes receive the matching green frame and fill.'
 ],
 'outcomes_and_claim_scope':{
  'point':{'SAT':5,'UNKNOWN':10},'matched_depth_control':{'DERIVABLE':10,'NOT_DERIVABLE':5},
  'unknowns':'All ten point resource refusals retained, with eight MAX_CANDIDATES, one MAX_WORK and one WALL; none is recast as a negative theorem result.',
  'finite_negatives':'Control negatives concern the declared finite catalogue and depth-eight producer-tree model only, not original-theory nonprovability or unrestricted first-order logic.',
  'attribution':'All fifteen inputs are known Y regression assertions. Arithmetic proofs use the stated finite addition-axiom fragment, without induction or full-PA claims; incidence results use the stated incidence-axiom fragment, without full Hilbert-geometry claims.',
  'comparison':'No GCTS superiority, runtime advantage, RL contribution or theorem novelty is asserted. The matched-depth control resolves more goals and is faster in this run. Shared preparation, per-lane search and certificate/native costs are disclosed separately; nested timings are not summed as independent costs.',
  'different_objectives':'The nested-typing example faithfully reports point twelve coarse rows lowering to six primitive rows versus control four coarse rows lowering to nine; the control minimizes expanded coarse-tree size, not primitive proof cost.',
  'trace_scope':'Main event and rollback retained prefixes are labelled; no missing suffix or full intermediate-state audit is fabricated. Invoked native refusal remains whole-attempt failure, distinct from ordinary per-lane owned UNKNOWN.'},
 'final_presentation_and_QA':{
  'template3_exact_HTML':True,'presentation_changes_only':['Green SVG frame/fill for actual imported-lemma nodes, matching row glyphs.','Formula padding and hidden vertical overflow while retaining horizontal scrolling.'],
  'Root_QA_binding':ref(qa_binding),'inherited_template2_browser_views':76,'focused_final_template3_browser_views':7,
  'L_visual_check':'Final saved screenshot independently viewed; imported green frames, square glyphs, premise links, quantifier grouping, MathJax English variable and absence of tiny vertical formula bars agree with the recorded presentation correction.',
  'limits':'Root owns browser QA. L did not execute JS or the browser. No mobile viewport claim or repeated all-76-template3 browser sweep is made.'},
 'method_and_integrity':{'passive_only':True,'project_imports_or_helper_calls':0,'renderer_executions_by_L':0,'scientific_replays':0,'JS_or_network_calls':0,'science_or_input_mutations':0,'writes':'Only separate administrative review/support files in the L review directory.','completion':'All requested content and final-byte bindings complete; tools idle after receipt.'}}
rr=put('Z-reader-complete-independent-final-content-review-v1.json',review)
print(json.dumps({'receipt':rr,'final_binding_support':sr,'inherited_projection_support':ref(prior_support),'template_delta':ref(delta)},sort_keys=True))
