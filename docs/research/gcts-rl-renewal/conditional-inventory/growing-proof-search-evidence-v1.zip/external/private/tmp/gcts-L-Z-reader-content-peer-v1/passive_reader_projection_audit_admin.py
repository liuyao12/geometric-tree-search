"""Read-only data/source projection comparison; no renderer/JS/project replay."""
import collections,gzip,hashlib,json,pathlib
R=pathlib.Path('/private/tmp/gcts-growing-proof-obligations-20261028-v1');C=R/'implementation-C/report-draft';P=C/'output-001';O=pathlib.Path('/private/tmp/gcts-L-Z-reader-content-peer-v1');A=R/'actual/study-001';Q=R/'actual/qualification-001'
def raw(x):return (json.dumps(x,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')
def h(x):return hashlib.sha256(x).hexdigest()
def pairs(rows):
 d={}
 for k,v in rows:assert k not in d;d[k]=v
 return d
def load(p):
 b=p.read_bytes();return json.loads(gzip.decompress(b)if p.suffix=='.gz'else b,object_pairs_hook=pairs)
def eq(x,y):assert raw(x)==raw(y),(x,y)
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':h(b)}
def guard(rr):
 p=pathlib.Path(rr['path']);assert not p.is_symlink();b=p.read_bytes();assert len(b)==rr['bytes']and h(b)==rr['sha256'];return b
def artifact(rr):
 b=guard(rr['stored']);b=b if rr['encoding']=='json'else gzip.decompress(b);assert len(b)==rr['raw_bytes']and h(b)==rr['raw_sha256'];v=json.loads(b,object_pairs_hook=pairs);assert raw(v)==b;return v
html=P/'growing-proof-search-v1.html';data=P/'growing-proof-search-results-v1.json';receipt=P/'reader-projection-receipt-v1.json';report=load(data);projection=load(receipt)
assert pin(html)['bytes']==25074 and pin(html)['sha256']=='f105a608ec83cc7a8edfeee43feb701436b2635fa8454c9b22a2162c6f6ea4bf';assert pin(data)['bytes']==775432 and pin(data)['sha256']=='64668a2e038ee7f412c96a33ca556b799bc3130fcac3917e83c8b4177be9ee9d'
for rr in projection['files']+projection['inputs']:guard(rr)
eq(report['provenance_sources'],projection['inputs']);assert html.read_bytes()==(C/'growing-proof-reader-template-v2.html').read_bytes();assert report['status']=='ROOT_ADMISSION_SUPPLIED'
admission=load(R/'root/Z-Root-whole-growing-main-scientific-admission-v1.json');eq(report['reader']['provenance']['main_admission'],admission);assert admission['status']=='ADMITTED_COMPLETE_CURRENT_MAIN_COMPARISON'
w=load(A/'worker-result.json.gz');main=w['experiment'];qworker=load(Q/'worker-result.json');qual=artifact(qworker['experiment']['qualification_ref']);byq={x['id']:(x,artifact(x['ref']))for x in qual['records']};qchecks={(x['case'],x['label']):x['check']for x in qual['native_checks']};by_main={x['id']:x for x in main['results']};preps={x['id']:x for x in main['preparations']};bank=artifact(main['bank_ref'])['result']['value']['lemmas'];eq(report['reader']['bank'],bank);eq(report['design'],main['design']);eq(report['limits'],main['limits']);eq(report['main_counts'],projection['counts']);assert report['main_positive_pairs']==projection['positive_pairs']==15
views=[];bindings=[];coarse_lines=original_lines=0;point_nodes=control_nodes=0;main_positives=0;qviews=0
for case in report['reader']['cases']:
 cid=case['id'];assert set(case['lanes'])=={'GROWTH_POINT_LEX','MATCHED_DEPTH_TREE_CONTROL'}
 if case['qualification']:
  source,qr=byq[cid];certs=qr['native_certificates'];assert len(certs)==2and case['depth']==qr['depth'];eq(case['problem'],certs[0]['problem']);assert case['group']=='Qualification'and case['lemma_bindings']==[]
 else:
  compare=by_main[cid];prep=preps[cid];eq(case['problem'],compare['original']);assert case['depth']==8and case['preparation_status']==prep['status']=='COMPLETE';eq(case['lemma_bindings'],prep['application']['lemma_bindings']);eq(case['preparation_ref'],compare['preparation_ref'])
  for k in ('preparation_seconds','build_seconds','build_costs','catalogue_audit_seconds','zero_audit_seconds'):eq(case[k],prep[k])
  assert case['checkpoint_load_seconds']==compare['shared_checkpoint_load_seconds']
 for index,lane in enumerate(('GROWTH_POINT_LEX','MATCHED_DEPTH_TREE_CONTROL')):
  view=case['lanes'][lane]
  if case['qualification']:
   cert=certs[index];proof=cert['proof'];eq(view['source_ref'],source['ref']);eq(view['coarse_proof'],proof);eq(view['original_proof'],proof);eq(view['checks']['native'],qchecks[(cid,cert['label'])]);assert view['lowering']is None and view['verified']is True and view['original_status']=='VERIFIED'
   if index==0:tree=qr['decoded']['tree'];assert view['status']==qr['result']['status']=='SAT';eq(tree['selected'],qr['result']['selected'])
   else:
    d=qr['control_audit']['details'];tree={'root':'','max_depth':qr['depth'],'selected':qr['control']['details']['selected'],'site_to_line':d['site_to_line'],'node_count':d['tree_nodes'],'max_used_depth':d['maximum_site_depth'],'placements':d['candidate_bindings'],'totals':d['totals'],'marks':d['marks']};assert view['status']==qr['control']['status']=='DERIVABLE'
   qviews+=1
  else:
   compact=compare['lanes'][lane];full=artifact(compact['ref']);eq(view['source_ref'],compact['ref']);assert view['status']==full['status']and view['original_status']==full['original_status']and view['verified']==full['verified'];assert view['seconds']==full['search_seconds'];eq(view['statistics'],compact['statistics']);eq(view['event_extent'],compact.get('event_extent'));eq(view['rollback_extent'],compact.get('rollback_extent'));eq(view['provider'],compact.get('provider'))
   for k in ('factory_seconds','factory_audit_seconds','tree_audit_decode_seconds'):eq(view[k],full.get(k))
   eq(view['checkpoint_load_seconds'],full['checkpoint_load_seconds']);eq(view['checks']['factory'],full.get('factory_audit'));eq(view['checks']['tree'],full.get('tree_audit'));assert view['reason']==(full.get('reason')or full['result'].get('reason'))
   if full['verified']:
    pos=full['positive'];proof=pos['coarse_proof'];eq(view['coarse_proof'],proof);eq(view['original_proof'],pos['original_proof']);eq(view['checks']['coarse'],pos['coarse_check']);eq(view['checks']['original'],pos['original_check']);eq(view['lowering'],{'value':pos['lowering']['value'],'audit':pos['lowering_audit'],'seconds':pos['lowering_seconds'],'source_ref':pos.get('ref')});tree=full['decoded']['tree'];main_positives+=1
   else:
    assert view['coarse_proof']==view['original_proof']==[]and view['tree']is None and view['lowering']is None
    views.append({'case':cid,'lane':lane,'status':view['status'],'proofs':False,'reason':view['reason']});continue
  eq(view['tree'],tree);proof=view['coarse_proof'];mapping=pairs(tree['site_to_line']);assert sorted(mapping.values())==list(range(len(proof)))and mapping['']==len(proof)-1;assert tree['selected']==sorted(x['id']for x in tree['placements']);assert len(tree['placements'])==tree['node_count']==len(proof)
  for tile in tree['placements']:
   site,definition=json.loads(tile['id']);line=proof[mapping[site]];expected_sites=[site]+([site+'0',site+'1']if line['rule']=='mp'else[site+'0']if line['rule']=='generalize'else[]);assert tile['t']==[[p,1]for p in sorted(expected_sites)]
   marks=pairs(tile['m']);eq(json.loads(marks[site]),line['formula'])
   if line['rule']=='mp':assert mapping[site+'0']==line['antecedent']and mapping[site+'1']==line['implication']
   elif line['rule']=='generalize':assert mapping[site+'0']==line['source']
   assert set(marks)==set(expected_sites)
   for p,value in tile['m']:eq(json.loads(value),proof[mapping[p]]['formula'])
   bindings.append({'case':cid,'lane':lane,'site':site,'line':mapping[site],'id':tile['id'],'t':tile['t'],'m':tile['m']})
  assert tree['totals']==[[p,2]for p in sorted(mapping)]and all(row[2]==2 for row in tree['marks']);assert tree['max_used_depth']==max(map(len,mapping))<=case['depth']
  if lane=='GROWTH_POINT_LEX':point_nodes+=len(proof)
  else:control_nodes+=len(proof)
  coarse_lines+=len(view['coarse_proof']);original_lines+=len(view['original_proof']);views.append({'case':cid,'lane':lane,'status':view['status'],'proofs':True,'coarse_lines':len(proof),'original_lines':len(view['original_proof']),'nodes':tree['node_count'],'used_depth':tree['max_used_depth'],'source_ref':view['source_ref']})
assert len(report['reader']['cases'])==19 and len(views)==38and qviews==8and main_positives==15and len(bindings)==176and point_nodes==81and control_nodes==95and coarse_lines==176and original_lines==242
# Every projected cost is the recorded quantity, with nested scopes left intact.
cost=report['costs'];ob=load(A/'observer-result.json');assert cost['observer_seconds']==ob['whole_observer_seconds']and cost['peak_rss_bytes']==ob['wait4_peak_bytes'];eq(cost['worker_terminal'],ob['worker_terminal']);assert cost['experiment_seconds']==main['seconds']and cost['native_preparation_seconds']==main['native_preparation_seconds']and cost['historical_donor_acquisition_seconds']==main['historical_acquisition_seconds'];eq(cost['native_memo'],{k:v for k,v in main['native_memo'].items()if k!='requests'});assert cost['shared_preparation_seconds']==sum(x['preparation_seconds']for x in main['preparations'])and cost['raw_build_seconds_nested_in_preparation']==sum(x['build_seconds']for x in main['preparations'])and cost['shared_checkpoint_load_seconds']==sum(x['shared_checkpoint_load_seconds']for x in main['results'])
qsummary=report['qualification'];eq(qsummary,report['reader']['provenance']['qualification']);eq(qsummary['counts'],qual['result']['counts']);eq(qsummary['native_memo'],qworker['experiment']['native_memo']);eq(qsummary['source_ref'],qworker['experiment']['qualification_ref'])
metadata={'schema':'Z-reader-complete-independent-passive-projection-support-v1','status':'PASS','HTML2':pin(html),'results':pin(data),'projection_receipt':pin(receipt),'all_guarded_projection_sources':projection['inputs'],'root_scientific_admission':pin(R/'root/Z-Root-whole-growing-main-scientific-admission-v1.json'),'cases':19,'method_positions':38,'all_method_views':views,'all_actual_and_realized_tile_bindings':bindings,'tile_counts':{'actual_point_views':9,'actual_point_nodes':81,'control_realization_views':14,'control_realization_nodes':95,'all_nodes':176},'displayed_proof_lines':{'coarse':176,'original_overlay':242},'main_positive_pairs':15,'qualification_proof_views':8,'scope':'All projected raw values/certificates/counts/costs joined to admitted saved source records. No renderer, JS, scientific helper, solver, VM, codec or checker executed. HTML2 reviewed in full; final presentation delta will be bound separately.'}
p=O/'Z-reader-complete-independent-passive-projection-support-v1.json';p.write_text(json.dumps(metadata,sort_keys=True,ensure_ascii=True,indent=2)+'\n');print(json.dumps({'support':pin(p),'counts':metadata['tile_counts']},indent=2))
