"""Passive saved JSON/gzip/hash/arithmetic associations; no project imports."""
from pathlib import Path
import gzip,hashlib,json,math,shlex,collections
Z=Path('/private/tmp/gcts-growing-proof-obligations-20261028-v1');R=Z/'root';D=Z/'actual/qualification-001';O=Path(__file__).parent
H=lambda b:hashlib.sha256(b).hexdigest()
def wire(x):return (json.dumps(x,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')
def pairs(rows):
 d={}
 for k,v in rows:assert k not in d;d[k]=v
 return d
def parse(b):return json.loads(b,object_pairs_hook=pairs,parse_constant=lambda v:(_ for _ in ()).throw(ValueError(v)))
def stable(p):
 p=Path(p);assert p.is_absolute()and p.resolve()==p and p.is_file()and not p.is_symlink();a=p.stat();b=p.read_bytes();c=p.stat();assert (a.st_ino,a.st_mtime_ns,a.st_size)==(c.st_ino,c.st_mtime_ns,len(b));assert a.st_nlink==1;return b
def pin(p,b=None):
 if b is None:b=stable(p)
 return {'path':str(p),'bytes':len(b),'sha256':H(b)}
def read(ref):assert type(ref)is dict and set(ref)=={'path','bytes','sha256'}and type(ref['bytes'])is int;raw=stable(ref['path']);assert pin(ref['path'],raw)==ref;return raw
def doc(p):return parse(stable(p))
def same(a,b):assert wire(a)==wire(b)
pp=R/'qualification-once-plan-001.json';pb=stable(pp);plan=parse(pb);pr=pin(pp,pb);assert len(pb)==11340 and pr['sha256']=='cb01e7fc22dc3b0e4e1590533d4d425555d4b71d76adfe26c7aca83a5aa4ff05';assert set(plan)=={'schema','sources','metadata','python','bootstrap','actual_dir','limits'}and len(plan['sources'])==11 and len(plan['metadata'])==28
for ref in list(plan['sources'].values())+list(plan['metadata'].values())+[plan['python'],plan['bootstrap']]:read(ref)
same(plan['limits'],{'worker_seconds':600,'observer_seconds':630,'rss_bytes':1073741824,'file_bytes':67108864,'total_bytes':1073741824,'max_files':768,'stream_bytes':1048576})
obs=doc(D/'observer-result.json');assert pin(D/'observer-result.json')['sha256']=='a8bba1babd29a567d46e52090419be7a28ed6d82cedfd670a4005c1bc0377677'
assert obs['schema']=='Z-owned-growing-point-qualification-observer-result-v1'and obs['status']=='COMPLETE'and type(obs['returncode'])is int and obs['returncode']==0 and obs['failure']is None and obs['cleanup_errors']==[]
assert all(obs[k]is True for k in ('both_streams_EOF','group_gone','wait_confirmed'))and all(obs['retained_streams_complete'].values())and obs['stdin_bytes_sent']==plan['sources']['runner']['bytes'];assert obs['whole_observer_seconds']<630 and obs['wait4_peak_bytes']<1073741824
files=sorted(D.iterdir());assert len(files)==52 and len(obs['files'])==51
for ref in obs['files']:assert Path(ref['path']).parent==D;read(ref)
assert {p.name for p in files}=={Path(ref['path']).name for ref in obs['files']}|{'observer-result.json'};assert sum(x['bytes']for x in obs['files'])==obs['stored_bytes'];assert sum(p.stat().st_size for p in files)<1073741824
wt=parse(read(obs['streams']['stdout']));assert read(obs['streams']['stderr'])==b'';same(wt,obs['worker_terminal']);assert wt['status']=='COMPLETE'and wt['plan']==pr and wt['elapsed_seconds']<600 and wt['self_lifetime_peak_bytes']<1073741824
assert obs['observed_stream_bytes']=={'stdout':obs['streams']['stdout']['bytes'],'stderr':0}
expectedcmd=[plan['python']['path'],'-I','-S','-B',plan['bootstrap']['path'],plan['sources']['runner']['path'],str(plan['sources']['runner']['bytes']),plan['sources']['runner']['sha256'],'--mode','worker','--plan',str(pp)];assert obs['command']==expectedcmd
ap=R/'qualification-once-A6-001.json';ar=pin(ap);authority=doc(ap);same(authority,{'schema':'Z-growing-point-qualification-once-authority-v1','uses':1,'authorized':True,'plan':pr,'runner':plan['sources']['runner'],'python':plan['python']});assert type(authority['uses'])is int and type(authority['authorized'])is bool
cp=Path(str(ap)+'.CONSUMED.json');cr=pin(cp);same(doc(cp),{'authority':ar,'plan':pr,'status':'SPENT'});same(doc(D/'CONSUMED.json'),{'authority':ar,'consumed':cr})
outer=doc(R/'qualification-once-001.outer.stdout.bin');assert stable(R/'qualification-once-001.outer.stderr.bin')==b'';same(outer,{'status':'COMPLETE','receipt':pin(D/'observer-result.json')})
toolp=R/'qualification-once-001.original-tool-exit-v1.json';tool=doc(toolp);assert pin(toolp)['sha256']=='687da587b828ad5b3b3ca68eb6be91451af924b66b2c84d34bc788a9fd96d5eb';assert tool['original_response']['chunk_id']=='4c9a92'and type(tool['original_response']['exit_code'])is int and tool['original_response']['exit_code']==0 and tool['original_session_id']is None and tool['original_response']['output']==''
caller=stable(R/'qualification-once-caller-001.sh').decode();first,body=caller.split('\n',1);assert first=='set -C';argv=shlex.split(body);bootstrap=read(plan['bootstrap']).decode();assert argv==[plan['python']['path'],'-I','-S','-B','-c',bootstrap,plan['sources']['runner']['path'],str(plan['sources']['runner']['bytes']),plan['sources']['runner']['sha256'],'--mode','observer','--plan',str(pp),'--authority',str(ap),'<',plan['sources']['runner']['path'],'>',str(R/'qualification-once-001.outer.stdout.bin'),'2>',str(R/'qualification-once-001.outer.stderr.bin')]
assert tool['tool_request']['cmd']=='/bin/zsh -f '+str(R/'qualification-once-caller-001.sh')and tool['tool_request']['login']is False and tool['tool_request']['workdir']==str(R)
adopt=doc(R/'Z-Root-concrete-qualification-caller-adoption-v1.json');same(adopt['plan'],pr);read(adopt['caller']);read(adopt['complete_Source_API_adoption']);read(adopt['independent_preflight'])
artifacts={};artifact_refs={};rawtotal=0;storedtotal=0
def artifact(desc):
 global rawtotal,storedtotal
 assert set(desc)=={'name','stored','encoding','raw_bytes','raw_sha256'}and type(desc['raw_bytes'])is int
 stored=read(desc['stored']);assert Path(desc['stored']['path']).parent==D
 raw=gzip.decompress(stored)if desc['encoding']=='gzip-json'else stored;assert desc['encoding']in('json','gzip-json')and len(raw)==desc['raw_bytes']and H(raw)==desc['raw_sha256'];assert (len(raw)>65536)==(desc['encoding']=='gzip-json');assert len(raw)<=67108864 and len(stored)<=67108864
 val=parse(raw);assert wire(val)==raw
 if desc['name']not in artifacts:artifacts[desc['name']]=val;artifact_refs[desc['name']]=desc;rawtotal+=len(raw);storedtotal+=len(stored)
 else:same(artifact_refs[desc['name']],desc)
 return val
worker=artifact(wt['result']);assert worker['status']=='COMPLETE'and worker['schema']=='Z-growing-point-qualification-study-v1';assert len(worker['artifacts'])==47
for desc in worker['artifacts']:artifact(desc)
assert len(artifacts)==48 and storedtotal<1040187392
assert {Path(x['stored']['path']).name for x in artifact_refs.values()}|{'CONSUMED.json','stdout.bin','stderr.bin','observer-result.json'}=={p.name for p in files}
exp=worker['experiment'];assert exp['status']=='COMPLETE'and exp['native_check_requests']==8 and exp['record_count']==41
summary=artifact(exp['qualification_ref']);program=artifact(exp['native_program']);same(summary['result'],exp['qualification']);qual=exp['qualification'];assert qual['status']=='PASS';assert len(summary['records'])==41 and len(summary['native_checks'])==8
records=[]
for row in summary['records']:records.append((row['id'],artifact(row['ref'])))
assert [k for k,v in records]==qual['records']and len(set(qual['records']))==41
counts={'adapter.decode':4,'adapter.make_provider':4,'emissions':41,'engine.solve':40,'native_certificates':8,'tree_control':7,'full_observations':sum(len(v.get('observations',[]))for k,v in records)};same(qual['counts'],counts);assert counts['full_observations']==161
same(worker['outer_public_calls'],wt['public_calls']);assert sum(wt['public_calls'].values())==33;assert wt['public_calls']=={'carrier.build_carrier':4,'carrier.verify_carrier_choice':4,'codec.decode':4,'codec.encode':4,'experiment.run':1,'fol_checker.check':4,'growth_audit.qualify':1,'native_bridge._Native':1,'tree_machine.Compiler':1,'tree_machine.Heap':4,'tree_machine.run':4,'tree_machine.validate':1}
# Literal saved-state and complete stream checks, not engine replay.
images=0;observation_images=0;status_counts=collections.Counter();rollback_rows=0;event_rows=0;result_rows=[]
def state(s,model):
 assert set(s)=={'Q','totals','selected','marks','excluded','eligible','domains','forward','reverse','placements','loaded','dependencies','edge_count'}
 rows={r['id']:r for r in s['placements']};assert len(rows)==len(s['placements']);assert s['edge_count']==len(s['forward'])==sum(len(v)for cid,v in s['reverse'])
 assert sorted(s['forward'])==sorted([[p,cid,n]for cid,vals in s['reverse']for p,n in vals]);assert sorted(s['forward'])==sorted([[p,cid,dict(rows[cid]['t'])[p]]for p,ids in s['domains']for cid in ids])
 for channel in ('t','m'):
  dep={}
  for cid,row in rows.items():
   for p,v in row[channel]:dep.setdefault(p,[]).append(cid)
  same(s['dependencies'][channel],[[p,sorted(ids)]for p,ids in sorted(dep.items())])
 cap=model['capacity'];totals=dict(model['seed']['t']);q=set(model['roots'])|{p for p,n in model['seed']['t']if n};marks={p:[v,1]for p,v in model['seed']['m']};gens={p:0 for p in q}
 for cid,g in s['selected']:
  assert cid in rows and type(g)is int and g>=1
  for p,n in rows[cid]['t']:q.add(p);totals[p]=totals.get(p,0)+n;gens[p]=min(gens.get(p,g),g);assert totals[p]<=cap
  for p,v in rows[cid]['m']:
   if p not in marks:marks[p]=[v,0]
   assert marks[p][0]==v;marks[p][1]+=1
 same(s['Q'],[[p,gens[p]]for p in sorted(q)]);same(s['totals'],[[p,totals.get(p,0)]for p in sorted(q|set(totals))]);same(s['marks'],[[p]+v for p,v in sorted(marks.items())]);assert set(dict(s['domains']))=={p for p in q if totals.get(p,0)<cap};assert set(s['loaded'])<=q
for name,row in records:
 assert type(row['native_certificates'])is list
 if 'result'not in row:continue
 res=row['result'];model=row['model'];status_counts[res['status']]+=1
 for key in ('entry','final','restored'):
  x=res[key+'_state'];h=res['state_hashes'][key]
  if x is None:assert h is None
  else:state(x,model);images+=1;assert H(wire(x))==h
 if res['entry_state']is not None:same(res['entry_state'],res['restored_state'])
 else:assert res['restored_state']is None
 if res['status']=='UNKNOWN':assert res['final_state']is None and res['certificate']is None
 for prefix in ('event','rollback'):
  body=res['events']if prefix=='event'else res['rollback_records'];ext=res[prefix+'_extent'];assert ext['retained']==len(body)==ext['total'];assert H(b''.join(wire(r)for r in body))==ext['sha256'];assert res['stats']['events_total'if prefix=='event'else'rollbacks_total']==len(body)
 obsrows=row['observations'];assert [v['event']for v in obsrows]==res['events']
 for i,x in enumerate(obsrows):assert x['event']['seq']==i;state(x['state'],model);observation_images+=1
 for rb in res['rollback_records']:assert rb['from_trail']-rb['to_trail']==rb['undone']and rb['selected_after']<=rb['selected_before']
 rollback_rows+=len(res['rollback_records']);event_rows+=len(res['events']);assert row['independent']['status']=='VERIFIED'
 result_rows.append({'id':name,'status':res['status'],'events':len(res['events']),'rollback_records':len(res['rollback_records']),'state_hashes':res['state_hashes']})
assert sum(status_counts.values())==31 and observation_images==161
# Saved whole native receipts and full memo identity/binding; no proof codec/kernel calls.
lim=parse(read(plan['metadata']['experiment_limits']));identity={'sources':{k:plan['sources'][k]['sha256']for k in ('tree_machine','codec','carrier','fol_checker','real_parser')},'program':H(wire(program)),'limits':lim}
certs=[]
for name,row in records:
 for item in row['native_certificates']:certs.append((name,item))
assert len(certs)==8;memo=exp['native_memo'];assert memo['executions']==4 and memo['hits']==4 and len(memo['requests'])==8
seen={};native_info=[]
for (case,item),checkrow,req in zip(certs,summary['native_checks'],memo['requests']):
 assert checkrow['case']==case and checkrow['label']==item['label'];check=checkrow['check'];same(req,dict(check,request_id='qualification-'+case+'-'+item['label'].replace('_','-')))
 key=H(wire({'identity':identity,'theory':item['problem']['theory'],'goal':item['problem']['goal'],'proof':item['proof']}));assert req['key_sha256']==key and req['status']=='VERIFIED';nr=artifact(req['receipt_ref']);same(nr['theory'],item['problem']['theory']);same(nr['goal'],item['problem']['goal']);same(nr['proof'],item['proof']);same(nr['decoding']['proof'],item['proof']);assert nr['status']=='VERIFIED'and nr['decoding']['status']=='COMPLETE'and nr['encoding']['status']=='COMPLETE'and nr['choice']['status']=='VERIFIED'
 assert nr['native']['status']=='accepted'and type(nr['native']['value'])is int and nr['native']['value']==1 and nr['independent']['status']=='VERIFIED'and nr['independent']['checked_lines']==len(item['proof'])==req['proof_lines'];assert req['native_steps']==nr['native']['steps']
 stream=bytes.fromhex(nr['encoding']['stream_hex']);assert len(stream)==req['proof_bytes']and nr['choice']['byte_values']==list(stream)
 cv=nr['carrier']['value'];base=cv['nodes'];initial=nr['initial_nodes'];assert len(base)==len(initial);chosen={r['node_index']:stream[r['byte_index']]for r in cv['byte_rows']}
 for i,(a,b)in enumerate(zip(base,initial)):assert (b==[chosen[i]]+a[1:]if i in chosen else a==b)
 assert nr['final_heap'][:len(initial)]==initial
 if key in seen:assert req['cache_hit']is True;same(req['receipt_ref'],seen[key]['receipt_ref'])
 else:
  assert req['cache_hit']is False;seen[key]=req;native_info.append({'key_sha256':key,'receipt':req['receipt_ref'],'lines':len(item['proof']),'proof_bytes':len(stream),'native_steps':req['native_steps'],'status':'VERIFIED'})
assert len(seen)==4;assert abs(sum(x['first_execution_seconds']for x in seen.values())-memo['unique_execution_seconds'])<1e-9
for v in memo['requests']:assert v['cache_hit']in (True,False)
# Every physical byte, complete artifact descriptor and native reference is pinned above.
support={'schema':'Z-qualification001-complete-passive-custody-support-v1','status':'PASS_ALL_COMPLETE_SAVED_ASSOCIATIONS','original_tool':pin(toolp),'outer_stdout':pin(R/'qualification-once-001.outer.stdout.bin'),'outer_stderr':pin(R/'qualification-once-001.outer.stderr.bin'),'observer':pin(D/'observer-result.json'),'worker_result':wt['result'],'plan':pr,'all11Sources':plan['sources'],'all28metadata':plan['metadata'],'python':plan['python'],'bootstrap':plan['bootstrap'],'A6':ar,'consume':cr,'concrete_Root_adoption':pin(R/'Z-Root-concrete-qualification-caller-adoption-v1.json'),'all52physical_files':[pin(p)for p in files],'total_physical_bytes':sum(p.stat().st_size for p in files),'all48artifact_descriptors':list(artifact_refs.values()),'artifact_raw_bytes':rawtotal,'artifact_stored_bytes':storedtotal,'actual_closed_counts':counts,'outer_public_calls':wt['public_calls'],'engine_result_status_counts':dict(status_counts),'complete_result_images_hashed':images,'all_observation_images':observation_images,'all_event_rows_full_digest_recomputed':event_rows,'all_rollback_rows_full_digest_recomputed':rollback_rows,'all31result_joins':result_rows,'native8requests4executions4hits':native_info,'unique_native_lines':sum(x['lines']for x in native_info),'unique_proof_bytes':sum(x['proof_bytes']for x in native_info),'unique_native_steps':sum(x['native_steps']for x in native_info),'clock_and_rss':{'observer_seconds':obs['whole_observer_seconds'],'worker_seconds':wt['elapsed_seconds'],'child_lifetime_peak_bytes':obs['wait4_peak_bytes']},'activity':{'project_Source_or_helper_calls':0,'scientific_fixture_search_VM_codec_checker_replays':0,'network':0,'original_files_mutated':0}}
p=O/'Z-qualification001-complete-passive-custody-support-v1.json';p.write_bytes((json.dumps(support,sort_keys=True,indent=2,allow_nan=False)+'\n').encode());print(json.dumps({'support':pin(p),'physical_files':len(files),'physical_bytes':support['total_physical_bytes'],'artifact_raw_bytes':rawtotal,'counts':counts,'images':images,'events':event_rows,'rollbacks':rollback_rows,'statuses':dict(status_counts),'unique_lines':support['unique_native_lines'],'unique_bytes':support['unique_proof_bytes'],'unique_steps':support['unique_native_steps']},sort_keys=True))
