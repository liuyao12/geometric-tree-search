"""Passive targeted inventory only; never imports project Source or writes a ZIP."""
import hashlib
import json
import os
from pathlib import Path
import stat

Z = Path('/private/tmp/gcts-growing-proof-obligations-20261028-v1')
OWN = Path('/private/tmp/gcts-B-Z-package-v1')
PEERS = [
'/private/tmp/gcts-B-Z-anchored-provider-Source-peer-v1',
'/private/tmp/gcts-B-Z-independent-verifier-Source-peer-v1',
'/private/tmp/gcts-B-Z-main-prospective-v1',
'/private/tmp/gcts-B-Z-owned-main-runner-Source-peer-v1',
'/private/tmp/gcts-B-Z-qualification-prospective-v1',
'/private/tmp/gcts-B-Z-qualification001-saved-review-v1',
'/private/tmp/gcts-B-Z-study001-saved-review-v1',
'/private/tmp/gcts-L-Z-engine-Source-peer-v1',
'/private/tmp/gcts-L-Z-main-experiment-Source-peer-v1',
'/private/tmp/gcts-L-Z-main001-mathematical-review-v1',
'/private/tmp/gcts-L-Z-qualification001-saved-review-v1']
EXCLUDED_PREFIXES = [
Z/'root/isolated-growing-proof-search-git-v1.git',
Z/'root/publication-growing-proof-search-git-v1',
Z/'root/growing-proof-search-live-TLS-verification-v1',
Z/'publisher-growing-proof-search-payload']
EXCLUDED_NAMES = {str(Z/'root/publication-growing-proof-search-v1/growing-proof-search-evidence-v1.zip')}
OWN_INPUTS = ['build_complete_evidence_v1.py', 'collect_prospective_inputs_v1.py',
              'Z-complete-evidence-packager-public-ABI-v1.json', 'ARCHIVE-SCOPE.txt']


def need(ok, why):
    if not ok:
        raise ValueError(why)


def wire(v):
    return (json.dumps(v, sort_keys=True, ensure_ascii=True, indent=2, allow_nan=False)+'\n').encode('ascii')


def read(p):
    p = Path(p)
    need(p.is_absolute() and p.resolve()==p and all(not q.is_symlink() for q in (p,*p.parents)), 'canonical path')
    a=p.stat(follow_symlinks=False)
    need(stat.S_ISREG(a.st_mode) and a.st_nlink==1 and a.st_size<=67108864, 'bounded regular singlelink')
    b=p.read_bytes(); c=p.stat(follow_symlinks=False)
    need((a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns)==(c.st_dev,c.st_ino,c.st_size,c.st_mtime_ns) and len(b)==a.st_size, 'stable complete bytes')
    return b


def pin(p):
    b=read(p)
    return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}


def refs(v):
    if type(v) is dict:
        if set(v)=={'path','bytes','sha256'}:
            yield v
        else:
            for x in v.values():
                yield from refs(x)
    elif type(v) is list:
        for x in v:
            yield from refs(x)


def excluded(p):
    return str(p) in EXCLUDED_NAMES or any(p==q or q in p.parents for q in EXCLUDED_PREFIXES)


def main():
    entries={}; reasons={}; excluded_actual=[]; inheritance_decisions=[]
    def add(p, category, expected=None):
        p=Path(p)
        need(not excluded(p), 'explicitly excluded input')
        r=pin(p)
        if expected is not None:
            need(r==expected, 'pinned Source/metadata/donor mismatch '+str(p))
        name='Z/'+str(p.relative_to(Z)) if Z in p.parents else 'external/'+str(p)[1:]
        if str(p) not in entries:
            entries[str(p)]={'archive_name':name,'category':category,'source_ref':r}
        reasons.setdefault(str(p),set()).add(category)
    def tree(root, category):
        root=Path(root)
        need(root.is_dir() and root.resolve()==root, 'exact named directory')
        for current, dirs, files in os.walk(root, followlinks=False):
            here=Path(current)
            keep=[]
            for name in sorted(dirs):
                p=here/name
                if excluded(p):
                    excluded_actual.append(str(p));continue
                need(not p.is_symlink() and p.is_dir(), 'nonsymlink inventory directory')
                keep.append(name)
            dirs[:]=keep
            for name in sorted(files):
                p=here/name
                if excluded(p):
                    excluded_actual.append(str(p));continue
                need(not p.is_symlink(), 'symlink within inventory')
                add(p,category)
    tree(Z,'complete_Z_originals_at_prospective_cut')
    for root in PEERS: tree(root,'complete_named_independent_Z_peer_directory')
    plans={}
    for n in ('qualification-once-plan-001.json','study-once-plan-001.json'):
        p=Z/'root'/n; d=json.loads(read(p)); plans[n]=d
        for role,r in d['sources'].items():add(r['path'],'current_closed_Source:'+n+':'+role,r)
        for role,r in d['metadata'].items():add(r['path'],'current_closed_metadata:'+n+':'+role,r)
        add(d['bootstrap']['path'],'exact344byte_authenticated_bootstrap',d['bootstrap'])
    main_plan=plans['study-once-plan-001.json']
    donor_manifest=main_plan['metadata']['donor_manifest']
    dm=json.loads(read(donor_manifest['path']))
    donor_rows=[]
    for r in refs(dm):
        if '/actual/study-002/' in r['path']:
            add(r['path'],'six_original_W_raw_donor_proofs',r);donor_rows.append(r)
    need(len({r['path'] for r in donor_rows})==6,'all six donor originals')
    inheritance_json=[
        Z/'root/Z-Root-owned-main-runner-inert-derivation-v1.json',
        Z/'root/Z-Root-owned-qualification-runner-inert-derivation-v1.json',
        Z/'implementation-B/Z-Git-publication-normal-TLS-complete-inert-Source-handoff-v1.json',
        Z/'implementation-B/Z-Git-publication-normal-TLS-complete-public-ABI-v1.json',
        Path('/private/tmp/gcts-B-Z-owned-main-runner-Source-peer-v1/Z-owned-main-runner-complete-independent-Source-peer-v1.json')]
    # Exact one-hop inheritance packet from the Source-bearing references.
    # Does not recursively pull historical runs or every older archive.
    for p in inheritance_json:
        for r in refs(json.loads(read(p))):
            q=Path(r['path'])
            if '/actual/' in str(q) or q.suffix=='.zip' or q==Path(main_plan['python']['path']):
                inheritance_decisions.append({'ref':r,'decision':'external_historical_or_runtime_not_recursive'})
            else:
                add(q,'exact_used_Source_inheritance_reference',r)
                inheritance_decisions.append({'ref':r,'decision':'included'})
    # Include manuals/static/support directly named in the selected current
    # handoffs and peer receipts. Stop after this single metadata hop.
    selected=list(entries.values())
    for entry in selected:
        p=Path(entry['source_ref']['path'])
        if p.suffix!='.json' or '/actual/' in str(p):continue
        if not ('handoff' in p.name.lower() or 'peer-review' in p.name or 'Source-peer' in p.name):continue
        for r in refs(json.loads(read(p))):
            q=Path(r['path'])
            if q.suffix in ('.py','.tree','.patch','.json','.md','.txt','.html') and '/actual/' not in str(q) and not excluded(q):
                # Runtime/native or historical metadata references are pinned
                # individually; never walk their parent directories.
                add(q,'direct_named_handoff_peer_Source_manual_or_support',r)
    for name in OWN_INPUTS:add(OWN/name,'current_inert_packager_Source_or_API')
    scope=[
      'Complete Z qualification-001 and study-001 physical originals, including raw gzip carriers, full proof/check receipts, logs, owned custody and every retained refusal/failure control.',
      'All Z current, historical negative and unrun Source variants/APIs/diffs/contracts, immutable master, plans, spent grants/consumes, original outer captures and current adoptions present at the recorded cut.',
      'Current main fifteen Source roles and fifty metadata refs are pinned individually; complete qualification closure, six original W donor raw proofs and the exact 344-byte bootstrap are included.',
      'Complete exact named Z independent peer/support directories and direct named inherited Source/manual/adoption packets are included. Original absolute paths remain in the manifest; archive member names are unique safe relative paths.',
      'Prior entire Y evidence archive and platform runtime binaries are external pinned dependencies, not recursively bundled. No project functions are imported or executed.',
      'This prospective cut is not admitted or executable: final main scientific admission, reader Source/template/API, final HTML/results, QA, content admission and final package audit are pending.',
      'Final package preparation will use a fresh external output directory, full DEFLATE CRC and original byte/SHA readback for every member. No summary replaces a raw original. ZIP cap is 64 MiB; a larger result is a refusal, never an omitted subset.'
    ]
    dependencies=[
      {'kind':'prior_complete_Y_archive','url':'https://liuyao12.github.io/geometric-tree-search/docs/research/gcts-rl-renewal/conditional-inventory/receptor-family-proof-search-evidence-v1.zip','bytes':46437152,'sha256':'3586dae6d8612f43de6859a9792f1a6a5c5827e2b0b671aa3ae35458b5441165','scope':'Historical full Y evidence only; all operative current Z Sources and raw donors are separately bundled.'},
      {'kind':'trusted_platform_python_runtime','source_ref':main_plan['python'],'vendored':False,'scope':'Binary pinned by both owned scientific plans; stdlib and OS runtime are toolchain dependencies.'}]
    exclusions=[{'path_prefix':str(p),'reason':'Future owned Git repository/publication/TLS output or duplicate payload twin; outside prepublication archive cut'} for p in EXCLUDED_PREFIXES]
    exclusions += [{'path':p,'reason':'Self ZIP/final packaging output excluded to avoid circular byte/hash references'} for p in sorted(EXCLUDED_NAMES)]
    exclusions += [{'scope':'Later publication/TLS/Pages/live browser receipts and later package-peer/adoption records','reason':'Durable outside this archive preparation cut; cannot include future/self-referential records.'}, {'scope':'Platform D90/Git binaries, entire older run/publication directories and historical full evidence ZIPs','reason':'Explicit external toolchain/history dependency; only current operative refs and used Source ancestry are included.'}]
    manifest={'schema':'Z-complete-evidence-closed-input-manifest-v1','status':'PROSPECTIVE_CURRENT_INPUTS_PENDING_FINAL_CUT','cut_id':'Z-prospective-package-current-inputs-v1','entries':sorted(entries.values(),key=lambda r:r['archive_name']),'external_dependencies':dependencies,'exclusions':exclusions,'root_admissions':[], 'scope':scope,
      'pending_final':['Root whole-main scientific admission and final L mathematical peer/support if not present at this cut','Final reader Source/template/Source API and admitted HTML/results files','Final local UI QA/screenshots, current content admission and exact late Root cut additions','Root freezes final admitted cut; independent final complete package audit follows ZIP construction']}
    for name,value in [('prospective-closed-input-manifest-v1.json',manifest),('prospective-input-census-v1.json',{'schema':'Z-prospective-package-input-census-v1','status':'PROSPECTIVE_NOT_A_PACKAGE','entries':len(entries),'original_bytes':sum(r['source_ref']['bytes'] for r in entries.values()),'categories':{c:sum(1 for p in reasons if c in reasons[p]) for c in sorted({q for s in reasons.values() for q in s})},'all_source_reasons':{p:sorted(v) for p,v in sorted(reasons.items())},'main_roles':main_plan['sources'],'main_metadata':main_plan['metadata'],'six_donors':donor_rows,'exact_peer_directories':PEERS,'explicit_excluded_existing_files':excluded_actual,'inheritance_decisions':inheritance_decisions,'zip_created':False,'scientific_calls':0})]:
        p=OWN/name;need(not p.exists(),'immutable output exists');p.write_bytes(wire(value))
    print(json.dumps({'manifest':pin(OWN/'prospective-closed-input-manifest-v1.json'),'census':pin(OWN/'prospective-input-census-v1.json'),'entries':len(entries),'original_bytes':sum(r['source_ref']['bytes'] for r in entries.values()),'zip_created':False},sort_keys=True))


if __name__=='__main__':
    main()
