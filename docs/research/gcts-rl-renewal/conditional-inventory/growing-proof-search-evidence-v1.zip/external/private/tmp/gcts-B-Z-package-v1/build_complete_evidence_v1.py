"""Inert, deterministic, complete-original ZIP builder. Stdlib only.

A prospective manifest cannot execute this builder. Root must supply a final
admitted cut with no pending inputs. Does not import any archived Source.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import zipfile

VERSION = 'Z-COMPLETE-EVIDENCE-PACKAGER-v1'
ZIP_NAME = 'growing-proof-search-evidence-v1.zip'
ZIP_CAP = 67108864
SOURCE_CAP = 67108864
TOTAL_CAP = 1073741824
MANIFEST_CAP = 16777216
RESERVED = ('MANIFEST.json', 'README.txt', 'PACKAGING-INPUT.json')


class PackageError(ValueError):
    pass


def need(ok, reason):
    if not ok:
        raise PackageError(reason)


def encoded(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True, indent=2,
                       allow_nan=False) + '\n').encode('ascii')


def parse(raw):
    def pairs(rows):
        value = {}
        for key, item in rows:
            need(key not in value, 'duplicate JSON key')
            value[key] = item
        return value
    def nonfinite(value):
        raise PackageError('nonfinite JSON')
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=nonfinite)


def canonical(value):
    need(type(value) is str, 'literal path')
    p = Path(value)
    need(p.is_absolute() and str(p) == value and p.resolve() == p
         and all(not q.is_symlink() for q in (p, *p.parents)), 'canonical nonsymlink absolute path')
    return p


def read_file(path, cap):
    p = canonical(str(path))
    before = p.stat(follow_symlinks=False)
    need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1
         and 0 <= before.st_size <= cap, 'bounded single-link regular original')
    with p.open('rb') as handle:
        body = handle.read(cap + 1)
    after = p.stat(follow_symlinks=False)
    need(len(body) == before.st_size == after.st_size and len(body) <= cap
         and (before.st_dev, before.st_ino, before.st_mtime_ns)
         == (after.st_dev, after.st_ino, after.st_mtime_ns), 'changed/incomplete original')
    return body, stat.S_IMODE(before.st_mode)


def pin(path, body):
    return {'path': str(path), 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}


def rawref(value, cap=SOURCE_CAP):
    need(type(value) is dict and set(value) == {'path', 'bytes', 'sha256'}
         and type(value['bytes']) is int and 0 <= value['bytes'] <= cap
         and type(value['sha256']) is str
         and re.fullmatch('[0-9a-f]{64}', value['sha256']) is not None, 'typed rawref3')
    body, mode = read_file(canonical(value['path']), cap)
    need(pin(value['path'], body) == value, 'full original rawref mismatch')
    return body, mode


def safe_name(value):
    need(type(value) is str and value and len(value.encode('utf-8')) <= 65535
         and not value.startswith('/') and '\\' not in value and ':' not in value
         and all(q not in ('', '.', '..') for q in value.split('/')), 'safe unique relative member path')
    return value


def create(path, raw):
    canonical(str(path))
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'wb') as handle:
        handle.write(raw)
        handle.flush()
        os.fsync(handle.fileno())
    need(read_file(path, len(raw))[0] == raw, 'full created metadata readback')
    return pin(path, raw)


class _CappedWriter:
    """Checks the complete ZIP extent BEFORE every write, including close tail."""
    def __init__(self, handle):
        self.handle = handle
        self.extent = 0

    def write(self, raw):
        end = self.handle.tell() + len(raw)
        need(end <= ZIP_CAP, 'ZIP64MiB stored extent limit')
        count = self.handle.write(raw)
        need(count == len(raw), 'short ZIP write')
        self.extent = max(self.extent, end)
        return count

    def tell(self):
        return self.handle.tell()

    def seek(self, offset, whence=0):
        return self.handle.seek(offset, whence)

    def flush(self):
        return self.handle.flush()


def zip_member(archive, name, raw, mode):
    info = zipfile.ZipInfo(safe_name(name), date_time=(1980, 1, 1, 0, 0, 0))
    info.create_system = 3
    info.external_attr = ((stat.S_IFREG | mode) & 0xffff) << 16
    info.compress_type = zipfile.ZIP_DEFLATED
    archive.writestr(info, raw, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)


def build_package(manifest_path, output_dir):
    """Build only a final admitted closed input cut; never stage/publish it."""
    manifest_path = canonical(manifest_path)
    raw_manifest, manifest_mode = read_file(manifest_path, MANIFEST_CAP)
    manifest = parse(raw_manifest)
    need(type(manifest) is dict and set(manifest) == {
        'schema', 'status', 'cut_id', 'entries', 'external_dependencies',
        'exclusions', 'root_admissions', 'scope', 'pending_final'}, 'exact manifest9')
    need(manifest['schema'] == 'Z-complete-evidence-closed-input-manifest-v1'
         and manifest['status'] == 'FROZEN_ADMITTED_COMPLETE_PACKAGE_CUT'
         and type(manifest['cut_id']) is str and manifest['cut_id']
         and manifest['pending_final'] == [], 'final Root-admitted closed cut only')
    need(type(manifest['entries']) is list and len(manifest['entries']) <= 10000
         and type(manifest['external_dependencies']) is list
         and type(manifest['exclusions']) is list and type(manifest['scope']) is list
         and all(type(x) is str for x in manifest['scope'])
         and type(manifest['root_admissions']) is list and len(manifest['root_admissions']) >= 2,
         'typed closed sources/scope/admissions')
    entries, names, paths, total = [], set(), set(), 0
    for value in manifest['entries']:
        need(type(value) is dict and set(value) == {'archive_name', 'category', 'source_ref'}
             and type(value['category']) is str and value['category'], 'input entry3')
        name = safe_name(value['archive_name'])
        need(name not in names and name not in RESERVED, 'duplicate/reserved member')
        body, mode = rawref(value['source_ref'])
        path = value['source_ref']['path']
        need(path not in paths and path != str(manifest_path), 'duplicate/self input origin')
        total += len(body)
        need(total <= TOTAL_CAP, 'original aggregate1GiB')
        names.add(name)
        paths.add(path)
        entries.append(dict(value, original_mode=mode))
    for ref in manifest['root_admissions']:
        rawref(ref)
        need(ref['path'] in paths, 'Root admission must be an included original')
    # Preserve the exact frozen input manifest too; its self-excluding generated
    # archive manifest records this extra original without a circular self-hash.
    input_ref = pin(manifest_path, raw_manifest)
    entries.append({'archive_name': 'PACKAGING-INPUT.json', 'category': 'frozen_packaging_input',
                    'source_ref': input_ref, 'original_mode': manifest_mode})
    total += len(raw_manifest)
    need(total <= TOTAL_CAP, 'complete original aggregate')
    entries.sort(key=lambda row: row['archive_name'])
    output_dir = canonical(output_dir)
    need(not output_dir.exists() and not output_dir.is_symlink(), 'fresh owned output directory')
    need(output_dir.parent.is_dir(), 'output parent exists')
    need(all(not (str(Path(p)).startswith(str(output_dir) + '/') or p == str(output_dir))
             for p in paths), 'no output/input cycle')
    output_dir.mkdir(mode=0o700)
    partial = output_dir / (ZIP_NAME + '.partial')
    final = output_dir / ZIP_NAME
    catalogue = {'schema': 'Z-complete-evidence-archive-manifest-v1', 'version': VERSION,
                 'cut_id': manifest['cut_id'], 'input_manifest': input_ref,
                 'origin_count': len(entries), 'origin_bytes': total,
                 'originals': entries, 'external_dependencies': manifest['external_dependencies'],
                 'exclusions': manifest['exclusions'], 'root_admissions': manifest['root_admissions'],
                 'scope': manifest['scope'],
                 'self_exclusion': 'MANIFEST.json and README.txt are generated metadata, not originals; neither contains this ZIP hash. All later publication/TLS/Pages/live receipts remain outside the cut.'}
    catalogue_raw = encoded(catalogue)
    need(len(catalogue_raw) <= MANIFEST_CAP, 'manifest extent')
    readme = ('Z growing proof search: COMPLETE ORIGINAL EVIDENCE\n\n'
              'Extract this independent normal DEFLATE ZIP with standard tools.\n'
              'MANIFEST.json maps every original archive member to its absolute source path, full byte extent and SHA256.\n'
              'PACKAGING-INPUT.json is the exact frozen Root-admitted input cut.\n'
              'Scientific JSON/gzip/Source/certificates/logs are preserved as original bytes; no science is rerun.\n'
              'Qualification and main study are distinct complete attempts with all refusals and failure controls retained.\n'
              'Platform runtime binaries and prior full archives are not bundled; external dependencies have explicit links/pins.\n'
              'Future Git repositories, publication/TLS/Pages/browser receipts, payload twins and this ZIP are excluded to avoid cycles.\n\n'
              + '\n'.join(manifest['scope']) + '\n').encode('utf-8')
    try:
        with partial.open('xb') as handle:
            capped = _CappedWriter(handle)
            with zipfile.ZipFile(capped, mode='w', compression=zipfile.ZIP_DEFLATED,
                                 compresslevel=9, allowZip64=False) as archive:
                for entry in entries:
                    body, mode = rawref(entry['source_ref'], MANIFEST_CAP if entry['archive_name'] == 'PACKAGING-INPUT.json' else SOURCE_CAP)
                    need(mode == entry['original_mode'], 'original mode changed')
                    zip_member(archive, entry['archive_name'], body, mode)
                zip_member(archive, 'MANIFEST.json', catalogue_raw, 0o644)
                zip_member(archive, 'README.txt', readme, 0o644)
            handle.flush()
            os.fsync(handle.fileno())
        need(partial.stat().st_size <= ZIP_CAP, 'final ZIP extent')
        checks = []
        with zipfile.ZipFile(partial, 'r') as archive:
            infos = archive.infolist()
            need(len(infos) == len(entries) + 2 and len({z.filename for z in infos}) == len(infos), 'exact member census')
            need(archive.testzip() is None, 'all ZIP CRCs')
            for info in infos:
                safe_name(info.filename)
                need(not info.is_dir() and info.compress_type == zipfile.ZIP_DEFLATED, 'normal independent DEFLATE members')
            for entry in entries:
                body, mode = rawref(entry['source_ref'], MANIFEST_CAP if entry['archive_name'] == 'PACKAGING-INPUT.json' else SOURCE_CAP)
                restored = archive.read(entry['archive_name'])
                need(restored == body and len(restored) == entry['source_ref']['bytes']
                     and hashlib.sha256(restored).hexdigest() == entry['source_ref']['sha256'], 'every member/original full raw readback')
                checks.append({'archive_name': entry['archive_name'], 'source_ref': entry['source_ref'],
                               'member_bytes': len(restored), 'member_sha256': hashlib.sha256(restored).hexdigest()})
            need(archive.read('MANIFEST.json') == catalogue_raw and archive.read('README.txt') == readme,
                 'complete generated metadata readback')
        # Final name is made visible only after every original+CRC passed.
        need(not final.exists(), 'no overwrite final ZIP')
        os.link(partial, final)
        partial.unlink()
        fd = os.open(output_dir, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)
        archive_body, _ = read_file(final, ZIP_CAP)
        create(output_dir / 'MANIFEST.json', catalogue_raw)
        receipt = {'schema': 'Z-complete-evidence-package-readback-v1', 'version': VERSION,
                   'status': 'COMPLETE_ALL_ORIGINAL_MEMBERS_CRC_AND_RAW_READBACK',
                   'archive': pin(final, archive_body), 'manifest': pin(output_dir / 'MANIFEST.json', catalogue_raw),
                   'input_manifest': input_ref, 'original_count': len(entries), 'original_bytes': total,
                   'member_count': len(entries) + 2, 'all_CRCs': True, 'all_original_readbacks': checks,
                   'science_or_network_calls': 0}
        return create(output_dir / 'package-readback.json', encoded(receipt))
    except Exception as error:
        # Retain any partial ZIP; never return a successful package on a prefix.
        create(output_dir / 'package-failure.json', encoded({'schema': 'Z-complete-evidence-package-failure-v1',
               'status': 'INCOMPLETE_NO_PACKAGE_ADMISSION', 'type': type(error).__name__, 'message': str(error)}))
        raise


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--manifest', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    result = build_package(args.manifest, args.output)
    print(json.dumps(result, sort_keys=True))


if __name__ == '__main__':
    main()
