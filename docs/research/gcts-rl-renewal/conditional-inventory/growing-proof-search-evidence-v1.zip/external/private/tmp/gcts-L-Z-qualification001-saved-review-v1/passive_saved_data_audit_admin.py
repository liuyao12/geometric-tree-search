"""Administrative standard-library checks of already saved Z001 data only."""
import collections,gzip,hashlib,itertools,json,math,pathlib,stat
R=pathlib.Path('/private/tmp/gcts-growing-proof-obligations-20261028-v1');A=R/'actual/qualification-001';O=pathlib.Path('/private/tmp/gcts-L-Z-qualification001-saved-review-v1')
def raw(x):return (json.dumps(x,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')
def key(x):return raw(x)[:-1].decode('ascii')
def h(x):return hashlib.sha256(x).hexdigest()
def ref(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':h(b)}
def pairs(rows):
 d={}
 for k,v in rows:assert k not in d;d[k]=v
 return d
def strict(b):
 def unique(rows):return pairs(rows)
 def bad(x):raise AssertionError('nonfinite '+x)
 return json.loads(b,object_pairs_hook=unique,parse_constant=bad)
def exact(x,y):assert raw(x)==raw(y),(x,y)
def guard(rr):
 assert set(rr)=={'path','bytes','sha256'} and type(rr['path'])is str and type(rr['bytes'])is int and rr['bytes']>=0
 p=pathlib.Path(rr['path']);assert p.is_file() and not p.is_symlink();b=p.read_bytes();assert len(b)==rr['bytes'] and h(b)==rr['sha256'];return b
obs=strict((A/'observer-result.json').read_bytes());worker=strict((A/'worker-result.json').read_bytes());summary=strict((A/'complete-growing-qualification.json').read_bytes());plan=strict((R/'root/qualification-once-plan-001.json').read_bytes())
assert len(list(A.iterdir()))==52 and len(obs['files'])==51
pins=[]
for rr in obs['files']:guard(rr);pins.append(rr)
assert {pathlib.Path(x['path']).name for x in obs['files']}=={p.name for p in A.iterdir()if p.name!='observer-result.json'}
assert sum(x['bytes']for x in obs['files'])==obs['stored_bytes']==538209
artifacts={};rawtotal=0
for descriptor in worker['artifacts']+[obs['worker_terminal']['result']]:
 stored=guard(descriptor['stored']);body=gzip.decompress(stored)if descriptor['encoding']=='json-gzip'else stored
 # Current runner spelling is json.gz for packed bodies.
 if descriptor['encoding']not in ('json','json-gzip'):
  assert descriptor['encoding']=='gzip-json';body=gzip.decompress(stored)
 assert len(body)==descriptor['raw_bytes'] and h(body)==descriptor['raw_sha256'];value=strict(body);assert raw(value)==body
 assert descriptor['name'] not in artifacts;artifacts[descriptor['name']]=(descriptor,value);rawtotal+=len(body)
assert len(artifacts)==48
inputpins=[]
for collection in ('sources','metadata'):
 for name,rr in plan[collection].items():guard(rr);inputpins.append({'role':collection+'.'+name,**rr})
for name in ('python','bootstrap'):guard(plan[name]);inputpins.append({'role':name,**plan[name]})
assert len(plan['sources'])==11 and len(plan['metadata'])==28
pr=ref(R/'root/qualification-once-plan-001.json');authpath=R/'root/qualification-once-A6-001.json';authority=strict(authpath.read_bytes());spentpath=pathlib.Path(str(authpath)+'.CONSUMED.json');spent=strict(spentpath.read_bytes());marker=strict((A/'CONSUMED.json').read_bytes())
assert set(authority)=={'schema','authorized','uses','plan','runner','python'} and authority['authorized']is True and type(authority['uses'])is int and authority['uses']==1
exact(authority['plan'],pr);exact(authority['runner'],plan['sources']['runner']);exact(authority['python'],plan['python']);exact(spent,{'authority':ref(authpath),'plan':pr,'status':'SPENT'});exact(marker,{'authority':ref(authpath),'consumed':ref(spentpath)})
outer=strict((R/'root/qualification-once-001.outer.stdout.bin').read_bytes());assert outer['status']=='COMPLETE';guard(outer['receipt']);exact(outer['receipt'],ref(A/'observer-result.json'));assert not (R/'root/qualification-once-001.outer.stderr.bin').read_bytes()
tool=strict((R/'root/qualification-once-001.original-tool-exit-v1.json').read_bytes());assert tool['original_response']['chunk_id']=='4c9a92'and tool['original_response']['exit_code']==0 and tool['original_session_id']is None
assert obs['status']=='COMPLETE' and obs['returncode']==0 and obs['failure']is None and obs['cleanup_errors']==[] and all(obs[k]is True for k in ('both_streams_EOF','wait_confirmed','group_gone'))
assert obs['stdin_bytes_sent']==18546 and obs['wait4_peak_bytes']==55066624<=plan['limits']['rss_bytes'] and obs['worker_terminal']['status']=='COMPLETE'
exact(obs['worker_terminal']['plan'],pr);assert not (A/'stderr.bin').read_bytes();exact(strict((A/'stdout.bin').read_bytes()),obs['worker_terminal'])
q=summary['result'];assert q['status']=='PASS'and q['version']=='Z-INDEPENDENT-GROWING-PROOF-VERIFIER-v2';records=[]
for row in summary['records']:
 d,v=artifacts['qualification-'+row['id']];exact(d,row['ref']);records.append((row['id'],v))
assert len(records)==41 and [n for n,_ in records]==q['records'];exact(q,worker['experiment']['qualification'])
assert q['counts']=={'adapter.decode':4,'adapter.make_provider':4,'emissions':41,'engine.solve':40,'full_observations':161,'native_certificates':8,'tree_control':7}
# Raw-data-only occupancy/mark reconstruction from each recorded model and selection.
def occupancy(model,universe,ids):
 cap=model['capacity'];assert type(cap)is int and cap>0
 rows={r['id']:r for r in universe};assert len(rows)==len(universe)
 qset=set(model['roots']);totals=pairs(model['seed']['t']);qset.update(p for p,n in totals.items()if n>0);marks={p:[v,1]for p,v in model['seed']['m']}
 for cid in ids:
  assert cid in rows
  for p,n in rows[cid]['t']:assert type(n)is int and 0<n<=cap;qset.add(p);totals[p]=totals.get(p,0)+n
  for p,v in rows[cid]['m']:
   assert type(v)is str
   if p in marks:assert marks[p][0]==v
   else:marks[p]=[v,0]
   marks[p][1]+=1
 assert all(totals.get(p,0)<=cap for p in qset)
 return qset,totals,marks

def certificate_data(model,universe,ids):
 assert ids==sorted(set(ids));rows={r['id']:r for r in universe};qset,totals,marks=occupancy(model,universe,ids)
 assert all(totals.get(p,0)==model['capacity']for p in qset)
 reached=set(model['roots'])|{p for p,n in model['seed']['t']if n>0};pending=set(ids)
 while pending:
  found={cid for cid in pending if any(p in reached for p,_ in rows[cid]['t'])};assert found
  for cid in found:reached.update(p for p,_ in rows[cid]['t'])
  pending-=found
 return {'capacity':model['capacity'],'roots':sorted(model['roots']),'seed':model['seed'],'placements':[rows[cid]for cid in ids],'totals':[[p,totals.get(p,0)]for p in sorted(qset)],'marks':[[p]+marks[p]for p in sorted(marks)]}

def image_graph_data(model,universe,s):
 assert set(s)=={'Q','totals','selected','marks','excluded','eligible','domains','forward','reverse','placements','loaded','dependencies','edge_count'}
 u={r['id']:r for r in universe};known={r['id']:r for r in s['placements']};assert len(known)==len(s['placements'])and all(k in u and raw(v)==raw(u[k])for k,v in known.items())
 selected=pairs(s['selected']);assert all(type(g)is int and g>0 for g in selected.values());qset,t,marks=occupancy(model,universe,selected)
 gens={p:0 for p in model['roots']};gens.update({p:0 for p,n in model['seed']['t']if n>0})
 for cid,g in selected.items():
  for p,_ in u[cid]['t']:gens[p]=min(gens.get(p,g),g)
 loaded=s['loaded'];assert loaded==sorted(set(loaded))and set(loaded)<=qset
 frontier=sorted(p for p in qset if t.get(p,0)<model['capacity']);assert set(frontier)<=set(loaded)
 if model['inventory']['kind']=='EXPLICIT':assert set(known)==set(u)
 else:assert set(known)=={cid for cid,row in u.items()if any(p in loaded for p,_ in row['t'])}
 excluded=s['excluded'];assert excluded==sorted(set(excluded))and set(excluded)<=set(known)and not set(excluded)&set(selected)
 eligible=[]
 for cid,row in sorted(known.items()):
  if cid in selected or cid in excluded:continue
  if any(t.get(p,0)+n>model['capacity']for p,n in row['t']):continue
  if any(p in marks and marks[p][0]!=v for p,v in row['m']):continue
  eligible.append(cid)
 ds=[];fw=[];rev=collections.defaultdict(list)
 for p in frontier:
  choices=[]
  for cid in eligible:
   units=pairs(known[cid]['t']).get(p,0)
   if units:choices.append(cid);fw.append([p,cid,units]);rev[cid].append([p,units])
  ds.append([p,choices])
 deps={}
 for kind in ('t','m'):
  inverse=collections.defaultdict(list)
  for cid,row in sorted(known.items()):
   for p,_ in row[kind]:inverse[p].append(cid)
  deps[kind]=[[p,v]for p,v in sorted(inverse.items())]
 expected={'Q':[[p,gens[p]]for p in sorted(qset)],'totals':[[p,t.get(p,0)]for p in sorted(qset|set(t))],'selected':[[cid,selected[cid]]for cid in sorted(selected)],'marks':[[p]+marks[p]for p in sorted(marks)],'excluded':excluded,'eligible':eligible,'domains':ds,'forward':fw,'reverse':[[cid,rev[cid]]for cid in sorted(rev)],'placements':[known[cid]for cid in sorted(known)],'loaded':loaded,'dependencies':deps,'edge_count':len(fw)}
 exact(s,expected);return expected

def event_boundary(event,state):
 assert set(event)=={'seq','kind','point','candidate','data'}and type(event['seq'])is int
 dom=pairs(state['domains']);gens=pairs(state['Q']);kind=event['kind'];p=event['point'];cid=event['candidate'];d=event['data']
 dead=[x for x,v in dom.items()if not v];forced=[x for x,v in dom.items()if len(v)==1]
 if kind=='DEAD':assert p==min(dead,key=lambda x:(gens[x],x))and cid is None
 if kind=='FORCED':assert not dead and p==min(forced,key=lambda x:(gens[x],x))and cid==dom[p][0]
 if kind=='BRANCH':assert not dead and not forced and p==min(dom,key=lambda x:(gens[x],len(dom[x]),x))and cid is None and d['legal']==dom[p]and sorted(d['order'])==dom[p]and len(d['order'])==len(dom[p])
 if kind in ('DEAD','FORCED','BRANCH'):assert type(d['generation'])is int and d['generation']==gens[p]
 if kind=='SOLUTION':assert not dom
 if kind=='EXCLUDE':assert cid in state['excluded']
 if kind=='PLACED':assert cid in pairs(state['selected'])and pairs(state['selected'])[cid]==d['generation']and type(d['forced'])is bool

case_support=[];image_count=0;observation_count=0;assignment_count=0;solution_count=0;result_status=collections.Counter();errors=[];all_native=[];byname=dict(records);rollback_count=0
for name,v in records:
 all_native += [(name,item)for item in v['native_certificates']]
 if 'exception_class'in v:
  errors.append({'id':name,'class':v['exception_class'],'message':v['exception_message']});assert v['post_exception_state']is None;continue
 if 'result'not in v:continue
 answer=v['result'];model=v['model'];universe=v['universe']if v['universe']is not None else model['inventory']['placements'];result_status[answer['status']]+=1
 assert answer['model_sha256']is None or answer['model_sha256']==h(raw(model));assert answer['schema']=='Z-growing-point-search-result-v1'and answer['version']=='Z-GROWING-POINT-SEARCH-v1'
 states=[]
 for field in ('entry','final','restored'):
  s=answer[field+'_state'];hh=answer['state_hashes'][field]
  if s is None:assert hh is None and answer['status']=='UNKNOWN'
  else:image_graph_data(model,universe,s);assert hh==h(raw(s));states.append({'kind':field,'sha256':hh});image_count+=1
 if answer['entry_state']is not None:exact(answer['entry_state'],answer['restored_state'])
 if answer['status']=='SAT':exact(certificate_data(model,universe,answer['selected']),answer['certificate'])
 else:assert answer['selected']==[]and answer['certificate']is None
 if answer['status']=='UNKNOWN':assert answer['final_state']is None
 for body,extent in ((answer['events'],answer['event_extent']),(answer['rollback_records'],answer['rollback_extent'])):
  assert extent['total']==extent['retained']==len(body);assert extent['sha256']==h(b''.join(raw(x)for x in body))
 rollback_count+=len(answer['rollback_records'])
 for row in answer['rollback_records']:assert row['from_trail']-row['to_trail']==row['undone']and row['selected_before']>=row['selected_after']
 histories=v['observations'];assert len(histories)<=len(answer['events'])and(answer['status']=='UNKNOWN'or len(histories)==len(answer['events']))
 history_support=[]
 for i,item in enumerate(histories):
  e,s=item['event'],item['state'];exact(e,answer['events'][i]);assert e['seq']==i;image_graph_data(model,universe,s);event_boundary(e,s)
  if e['kind']=='PLACED':
   prev=histories[i-1];pe=prev['event'];old=prev['state'];choice=pe['candidate']if pe['kind']=='FORCED'else pe['data']['order'][0];assert e['candidate']==choice
   row=next(x for x in universe if x['id']==choice);og=pairs(old['Q']);g=1+min(og[p]for p,_ in row['t']if p in og);assert e['data']['generation']==g;exact(pairs(s['selected']),dict(pairs(old['selected']),**{})|{choice:g})
  if e['kind']=='EXCLUDE':
   parents=[x['state']for x in histories[:i]if x['event']['kind']=='BRANCH'and x['event']['data']['order'][0]==e['candidate']and x['state']['selected']==s['selected']];assert parents;parent=parents[-1]
   for k in ('Q','totals','selected','marks','placements','loaded'):exact(parent[k],s[k])
   assert s['excluded']==sorted(set(parent['excluded'])|{e['candidate']})
  history_support.append({'seq':i,'kind':e['kind'],'point':e['point'],'candidate':e['candidate'],'Q':len(s['Q']),'frontier':len(s['domains']),'edges':s['edge_count'],'state_sha256':h(raw(s))})
 observation_count+=len(histories)
 solutions=v['all_subset_solutions'];product=None
 if solutions is not None:
  ids=sorted(row['id']for row in universe);assert len(ids)<=16;computed=[]
  for mask in range(1<<len(ids)):
   chosen=[cid for i,cid in enumerate(ids)if mask>>i&1]
   try:certificate_data(model,universe,chosen)
   except AssertionError:continue
   computed.append(chosen)
  exact(solutions,computed);assignment_count+=1<<len(ids);solution_count+=len(computed);product=1<<len(ids)
  assert (answer['status']=='SAT')==bool(solutions)
  if answer['status']=='SAT':assert answer['selected']in solutions
 case_support.append({'id':name,'status':answer['status'],'reason':answer['reason'],'states':states,'observations':history_support,'all_assignments_checked':product,'all_solutions':solutions,'selected':answer['selected'],'rollback_records':answer['rollback_records']})
assert result_status=={'SAT':24,'UNSAT':2,'UNKNOWN':5}and len(errors)==9and image_count==82and observation_count==161and rollback_count==31
assert len(all_native)==8
# Actual controlled scheduler precedence and fallback evidence, not aggregate flags.
def events(name):return [x['event']for x in byname[name]['observations']]
late=events('generic-late-dead-before-forced');assert any(e['kind']=='DEAD'and e['point']=='x'for e in late)and not any(e['kind']=='PLACED'and e['candidate']=='b'for e in late)
f=events('generic-forced-before-generation');assert next(i for i,e in enumerate(f)if e['kind']=='FORCED'and e['point']=='x')<next(i for i,e in enumerate(f)if e['kind']=='BRANCH')
b=next(e for e in events('generic-generation-before-degree')if e['kind']=='BRANCH');assert b['point']=='u'and len(b['data']['legal'])==3
assert byname['generic-shared-forced']['result']['stats']['placements']==1
assert byname['generic-thirds-shared']['result']['selected']==['a','b']
assert byname['generic-absent-versus-zero']['result']['selected']==['b']
assert byname['generic-equal-mark-refcounts']['result']['certificate']['marks']==[['remote','0',2]]
assert byname['generic-dormant-component']['result']['selected']==['a']
assert byname['generic-eligible-without-frontier']['result']['final_state']['eligible']==['b']
for k in ('events','entry_state','final_state','restored_state'):exact(byname['generic-bad-first-restore']['result'][k],byname['audit-false-and-detached-mutation']['result'][k])
assert any(e['kind']=='EXCLUDE'and e['candidate']=='a'for e in events('generic-bad-first-restore'))
preference=next(e for e in events('order-detached-complete-fallback')if e['kind']=='BRANCH');assert preference['data']['legal']==['a','b']and preference['data']['order']==['b','a']
error_expected={'ordering-invalid-duplicates':'OrderingError','ordering-foreign':'_Foreign','audit-foreign':'_Foreign','provider-foreign':'_Foreign','provider-incomplete-flag':'InventoryError','malformed-boolean-capacity':'InputError','malformed-duplicate-root':'InputError','malformed-boolean-t':'InputError','malformed-inconsistent-internal-m':'InputError'}
assert {x['id']:x['class']for x in errors}==error_expected
unknowns=[{'id':name,'reason':v['result']['reason'],'entry_present':v['result']['entry_state']is not None,'observations':len(v['observations'])}for name,v in records if 'result'in v and v['result']['status']=='UNKNOWN']
assert {x['reason']for x in unknowns}=={'MAX_NODES','MAX_WORK','MAX_POINTS','MAX_CANDIDATES'}
# The finite tree catalogue is reconstructed from the saved literal native arrays.
def catalogue_data(c):
 forms=c['logical_basis']['formulas'];colors=[key(x)for x in forms];assert colors==c['logical_basis']['colors']==sorted(set(colors));idx={x:i for i,x in enumerate(colors)};defs={};mp=[];gen=[]
 for i,z in enumerate(c['zero_instances']):
  assert z['id']=='i'+str(i)and z['rule']==z['line']['rule']=='axiom';assert z['line']['formula']==c['theory']['axioms'][z['line']['name']]==forms[z['formula_id']]
  did=key(['zero',z['id']]);defs[did]={'id':did,'kind':'ZERO','output':z['formula_id'],'premises':[],'zero_id':z['id'],'variable':None,'native_rule':'axiom'}
 for i,x in enumerate(forms):
  if x[0]=='imp':
   a,b=idx[key(x[1])],idx[key(x[2])];mp.append([i,a,b]);did=key(['mp',i,a,b]);defs[did]={'id':did,'kind':'MP','output':b,'premises':[a,i],'zero_id':None,'variable':None,'native_rule':'mp'}
  if x[0]=='all':
   body=idx[key(x[2])];gen.append([i,body,x[1]]);did=key(['gen',i,body,x[1]]);defs[did]={'id':did,'kind':'GEN','output':i,'premises':[body],'zero_id':None,'variable':x[1],'native_rule':'generalize'}
 exact(mp,c['mp_index']);exact(gen,c['gen_index']);assert c['goal_id']==idx[key(c['goal'])];return forms,colors,defs

def binding_data(colors,defs,depth,site,did):
 assert type(site)is str and len(site)<=depth and all(x in'01'for x in site);d=defs[did];ps=d['premises'];assert not ps or len(site)<depth
 sites=[site]+[site+str(i)for i in range(len(ps))];vals=[d['output']]+ps
 return {'id':key([site,did]),'t':[[p,1]for p in sorted(sites)],'m':[[p,colors[x]]for p,x in sorted(zip(sites,vals))]}

def tree_data(c,depth,selected):
 forms,colors,defs=catalogue_data(c);anchors={};bindings=[]
 assert selected==sorted(set(selected))
 for cid in selected:
  site,did=strict(cid.encode());assert key([site,did])==cid and site not in anchors
  bindings.append(binding_data(colors,defs,depth,site,did));anchors[site]=did
 assert ''in anchors and defs[anchors['']]['output']==c['goal_id'];post=[];seen=set();stack=[('',False)]
 while stack:
  p,done=stack.pop()
  if done:post.append(p);continue
  assert p in anchors and p not in seen;seen.add(p);d=defs[anchors[p]];stack.append((p,True))
  for i in reversed(range(len(d['premises']))):
   ch=p+str(i);assert ch in anchors and defs[anchors[ch]]['output']==d['premises'][i];stack.append((ch,False))
 assert seen==set(anchors)
 proof=[];mapping={};zero={z['id']:z for z in c['zero_instances']}
 for p in post:
  d=defs[anchors[p]]
  if d['kind']=='ZERO':line=zero[d['zero_id']]['line']
  elif d['kind']=='GEN':line={'rule':'generalize','formula':forms[d['output']],'variable':d['variable'],'source':mapping[p+'0']}
  else:line={'rule':'mp','formula':forms[d['output']],'antecedent':mapping[p+'0'],'implication':mapping[p+'1']}
  mapping[p]=len(proof);proof.append(line)
 totals={'':1};marks={'':[colors[c['goal_id']],1]}
 for row in bindings:
  for p,n in row['t']:totals[p]=totals.get(p,0)+n
  for p,x in row['m']:
   if p in marks:assert marks[p][0]==x
   else:marks[p]=[x,0]
   marks[p][1]+=1
 assert set(totals)==set(anchors)and all(n==2 for n in totals.values())and all(x[1]==2 for x in marks.values())
 tree={'root':'','max_depth':depth,'selected':selected,'site_to_line':[[p,mapping[p]]for p in sorted(mapping)],'node_count':len(proof),'max_used_depth':max(map(len,anchors)),'placements':sorted(bindings,key=lambda x:x['id']),'totals':[[p,n]for p,n in sorted(totals.items())],'marks':[[p]+x for p,x in sorted(marks.items())]}
 return proof,tree

def native_lines_data(theory,goal,proof):
 for i,line in enumerate(proof):
  rule=line['rule']
  if rule=='axiom':assert set(line)=={'rule','name','formula'}and line['name']in theory['axioms'];exact(line['formula'],theory['axioms'][line['name']])
  elif rule=='mp':
   a,b=line['antecedent'],line['implication'];assert type(a)is int and type(b)is int and 0<=a<i and 0<=b<i;exact(proof[b]['formula'],['imp',proof[a]['formula'],line['formula']])
  elif rule=='generalize':
   p=line['source'];assert type(p)is int and 0<=p<i;exact(line['formula'],['all',line['variable'],proof[p]['formula']])
  else:raise AssertionError('not a declared tiny rule')
 exact(proof[-1]['formula'],goal)

trees=[];provider_rows=0
for name,v in records:
 if not name.startswith('tree-'):continue
 c=v['compiled'];depth=v['depth'];forms,colors,defs=catalogue_data(c);core={k:x for k,x in c.items()if k not in ('costs','scope')};corehash=h(raw(core));assert v['generation']['compiled_core_sha256']==corehash and v['generation']['scope']==c['scope']
 identity=h(raw({'schema':'Z-anchored-proof-inventory-identity-v1','version':'Z-ANCHORED-PROOF-PRODUCER-v1','compiled_core_sha256':corehash,'depth':depth}));assert v['factory']['value']['identity']==identity==v['model']['inventory']['identity'];exact(v['factory']['value']['definitions'],[defs[d]for d in sorted(defs)])
 sites=[''.join(x)for n in range(depth+1)for x in itertools.product('01',repeat=n)];assert [p['point']for p in v['all_site_packets']]==sites
 universe=[]
 for p in sites:
  for did,d in sorted(defs.items()):
   if not d['premises']or len(p)<depth:universe.append(binding_data(colors,defs,depth,p,did))
 exact(sorted(universe,key=lambda x:x['id']),sorted(v['universe'],key=lambda x:x['id']))
 for item in v['all_site_packets']:
  p=item['point'];expected=[row for row in universe if any(q==p for q,_ in row['t'])];packet=item['packet'];assert packet['point']==p and packet['complete']is True;exact(packet['placements'],sorted(expected,key=lambda x:x['id']));provider_rows+=len(expected)
 proof,tree=tree_data(c,depth,v['result']['selected']);exact(v['decoded']['proof'],proof);exact(v['decoded']['tree'],tree);exact(v['selected_audit']['proof'],proof);assert v['decoded']['status']=='UNVERIFIED_CERTIFICATE'
 cp,ctree=tree_data(c,depth,v['control']['details']['selected']);exact(cp,v['control']['proof']);assert v['control']['details']['minimum_tree_nodes']==len(cp);native_lines_data(c['theory'],c['goal'],proof);native_lines_data(c['theory'],c['goal'],cp)
 for item in v['native_certificates']:native_lines_data(item['problem']['theory'],item['problem']['goal'],item['proof'])
 for cid,g in v['result']['final_state']['selected']:assert g==len(strict(cid.encode())[0])+1
 assert v['result']['final_state']['Q']==[[p,len(p)]for p in sorted(pairs(v['decoded']['tree']['totals']))]
 trees.append({'id':name,'depth':depth,'definitions':len(defs),'site_packets':len(sites),'all_potential_placements':len(universe),'selected_nodes':len(proof),'control_nodes':len(cp),'used_depth':tree['max_used_depth'],'postorder_sites':v['selected_audit']['details']['postorder_sites'],'proof':proof,'control_proof':cp,'point_control_identical':raw(proof)==raw(cp),'scope':v['fixture_scope']})
assert [x['selected_nodes']for x in trees]==[1,2,3,9]
dup=byname['tree-duplicated-subtree'];assert dup['decoded']['tree']['node_count']==9
# Every nonzero intermediate used to derive G has one producer here: Q from P/PQ,
# Q->G from Q/QQG; hence two distinct Q-subtrees cost3 each, total1+3+(1+3+1)=9.
forms,colors,defs=catalogue_data(dup['compiled']);byout=collections.defaultdict(list)
for d in defs.values():byout[d['output']].append(d)
G=dup['compiled']['goal_id'];root=byout[G];assert len(root)==1 and root[0]['kind']=='MP';Q,QG=root[0]['premises'];assert len(byout[Q])==1and len(byout[QG])==1and byout[QG][0]['premises'][0]==Q;assert 1+3+(1+3+1)==9
# Mutation/error data are inspected directly; no project verifier is replayed.
mutation_support=[];badrecord=byname['data-forgeries-and-control-bounds'];graph=byname['generic-remote-mark']
for row in badrecord['records']:
 kind=row['kind'];receipt=row['receipt'];assert receipt['proof']is None
 if 'state'in row:
  try:image_graph_data(graph['model'],graph['model']['inventory']['placements'],row['state'])
  except AssertionError:pass
  else:raise AssertionError('forged state accepted '+kind)
  assert receipt['status']=='REJECTED'
 elif 'selected'in row:
  try:tree_data(byname['tree-binary-mp']['compiled'],1,row['selected'])
  except (AssertionError,KeyError):pass
  else:raise AssertionError('forged tree accepted '+kind)
  assert receipt['status']=='REJECTED'
 elif 'packet'in row:
  assert len(row['packet']['placements'])<len(byname['tree-binary-mp']['all_site_packets'][0]['packet']['placements']);assert receipt['status']=='REJECTED'
 else:assert kind in ('work-zero','proof-output-zero')and receipt['status']=='UNKNOWN'and receipt['reason']in ('WORK','PROOF_OUTPUT_LIMIT')
 mutation_support.append({'kind':kind,'status':receipt['status'],'reason':receipt['reason']})
assert len(mutation_support)==13
# Seventh tree_control call is the Source-asserted depth0 negative; no raw receipt
# was emitted. Its recorded binary-MP catalogue has no zero with output goal,
# so the finite depth0 absence follows immediately from the complete zero list.
binary=byname['tree-binary-mp'];assert not any(z['formula_id']==binary['compiled']['goal_id']for z in binary['compiled']['zero_instances'])
# Current-run memo binds full source/program/limit/theory/goal/proof byte identity.
program=artifacts['qualification-fixed-native-program'][1];limits=strict(guard(plan['metadata']['experiment_limits']));native_identity={'sources':{k:plan['sources'][k]['sha256']for k in ('tree_machine','codec','carrier','fol_checker','real_parser')},'program':h(raw(program)),'limits':limits}
native_support=[];misses={};native_rules=collections.Counter();native_steps=0;native_bytes=0;native_line_count=0
for (name,item),checkrow in zip(all_native,summary['native_checks']):
 assert checkrow['case']==name and checkrow['label']==item['label'];answer=checkrow['check'];digest=h(raw({'identity':native_identity,'theory':item['problem']['theory'],'goal':item['problem']['goal'],'proof':item['proof']}));assert answer['key_sha256']==digest and answer['status']=='VERIFIED'
 physical=artifacts[answer['receipt_ref']['name']][1];exact(physical['theory'],item['problem']['theory']);exact(physical['goal'],item['problem']['goal']);exact(physical['proof'],item['proof']);assert physical['encoding']['proof'] is None;exact(physical['decoding']['proof'],item['proof']);assert physical['decoding']['stream_hex'] is None
 stream=bytes.fromhex(physical['encoding']['stream_hex']);assert physical['decoding']['offset']==len(stream)==physical['decoding']['counts']['bytes_read'];assert physical['encoding']['status']==physical['decoding']['status']=='COMPLETE'and answer['proof_bytes']==len(stream)and answer['proof_lines']==len(item['proof'])
 assert physical['status']=='VERIFIED'and physical['native']['status']=='accepted'and type(physical['native']['value'])is int and physical['native']['value']==1 and physical['independent']['status']=='VERIFIED'and physical['independent']['checked_lines']==len(item['proof'])
 assert physical['independent']['limits']==limits['checker']and physical['encoding']['limits']==limits['codec']and physical['decoding']['limits']==limits['codec']
 value=physical['carrier']['value'];base=value['nodes'];initial=physical['initial_nodes'];final=physical['final_heap'];assert value['program_sha256']==h(raw(program)[:-1])and base[:value['program_prefix_nodes']]==program['nodes'];assert value['trusted_prefix_sha256']==h(raw(base[:value['trusted_prefix_nodes']])[:-1])
 exact(value['known']['theory'],dict(item['problem']['theory'],schemas=[]));exact(value['known']['target'],item['problem']['goal']);assert value['known']['theory_sha256']==h(raw(value['known']['theory'])[:-1])and value['known']['target_sha256']==h(raw(value['known']['target'])[:-1])
 assert len(base)==len(initial)and final[:len(initial)]==initial and physical['native']['heap_nodes']==len(final)
 for heap in (initial,final):
  assert len({tuple(pair)for pair in heap})==len(heap)
  for i,pair in enumerate(heap):assert type(pair)is list and len(pair)==2and all(type(x)is int and 0<=x<257+i for x in pair)
 chosen=[list(x)for x in base];rows=value['byte_rows'];assert len(rows)==len(stream)==value['byte_count'];assert len(set(value['marker_ids']))==len(stream)and min(value['marker_ids'])>=257+value['trusted_prefix_nodes']
 for i,row in enumerate(rows):
  assert row['byte_index']==i and row['node_id']==row['node_index']+257 and row['marker_id']==value['marker_ids'][i];assert row['domain']=={'all_values_allowed':True,'minimum':0,'maximum':255};assert base[row['node_index']]==[row['head_placeholder'],row['marker_id']];chosen[row['node_index']][0]=stream[i]
 exact(chosen,initial);assert physical['choice']['status']=='VERIFIED'and physical['choice']['byte_values']==list(stream)
 def word(node):
  heads=[]
  while node!=256:
   assert 257<=node<=256+len(initial);left,node=initial[node-257];heads.append(left)
  return heads
 assert word(value['input_node'])==[value['theory_node'],value['target_node'],value['stream_node']];assert word(value['stream_node'])==[row['node_id']for row in rows]
 if answer['cache_hit']:
  assert digest in misses;exact(answer['receipt_ref'],misses[digest]['receipt_ref'])
 else:
  assert digest not in misses;misses[digest]=answer;native_steps+=physical['native']['steps'];native_bytes+=len(stream);native_line_count+=len(item['proof']);native_rules.update(line['rule']for line in item['proof'])
 native_support.append({'case':name,'label':item['label'],'key_sha256':digest,'cache_hit':answer['cache_hit'],'proof_lines':len(item['proof']),'proof_bytes':len(stream),'receipt':answer['receipt_ref'],'initial_nodes':len(initial),'final_nodes':len(final),'native_steps':physical['native']['steps'],'native_value':1,'independent_status':'VERIFIED'})
assert len(misses)==4and sum(x['cache_hit']for x in native_support)==4and native_steps==335837and native_bytes==197and native_line_count==15
memo=worker['experiment']['native_memo'];assert memo['executions']==4and memo['hits']==4and len(memo['requests'])==8;assert math.isclose(memo['unique_execution_seconds'],sum(x['first_execution_seconds']for x in misses.values()),rel_tol=0,abs_tol=1e-12)
for req,check in zip(memo['requests'],summary['native_checks']):
 assert req['request_id']=='qualification-'+check['case']+'-'+check['label'];exact({k:v for k,v in req.items()if k!='request_id'},check['check'])
assert sum(len(v.get('observations',[]))for _,v in records)==161
support={'schema':'Z-qualification001-independent-complete-passive-data-support-v1','actual_raw_pins':pins,'current_input_pins':inputpins,'plan':pr,'authority':ref(authpath),'consumed':ref(spentpath),'marker':ref(A/'CONSUMED.json'),'original_tool_exit':ref(R/'root/qualification-once-001.original-tool-exit-v1.json'),'observer':ref(A/'observer-result.json'),'artifact_count_including_worker':len(artifacts),'artifact_raw_bytes':rawtotal,'physical_files':52,'physical_bytes':sum(p.stat().st_size for p in A.iterdir()),'result_statuses':dict(result_status),'expected_errors':errors,'all_cases':case_support,'returned_images':image_count,'all_audit_images':observation_count,'full_rollback_rows':rollback_count,'all_independent_tiny_assignments':assignment_count,'all_independent_tiny_solutions':solution_count,'unknowns':unknowns,'all_provider_contact_rows':provider_rows,'trees':trees,'mutations':mutation_support,'native':native_support,'native_unique':{'executions':4,'hits':4,'lines':native_line_count,'bytes':native_bytes,'steps':native_steps,'rules':dict(native_rules)},'costs':{'observer_seconds':obs['whole_observer_seconds'],'worker_seconds':obs['worker_terminal']['elapsed_seconds'],'experiment_seconds':worker['experiment']['seconds'],'qualification_seconds':q['costs']['seconds'],'native_preparation_seconds':worker['experiment']['native_preparation_seconds'],'unique_native_seconds':memo['unique_execution_seconds'],'wait4_peak_bytes':obs['wait4_peak_bytes']},'limitations':['Root-seeded frontier reachability is necessary; arbitrary disconnected exact zero-alias packings are excluded, not disproved by raw t/m alone.','All normal tiny graphs full; foreign callback exceptions export no post-throw state, so cleanup there remains Source-reviewed rather than a fabricated runtime snapshot.','One seventh tree_control depth0 negative has no separately emitted raw control receipt; its PASS assertion is Source-bound and its no-zero-goal depth0 statement is independently confirmed directly from saved complete literal catalogue. Four positive and two UNKNOWN control results are fully retained.','Synthetic structural catalogues test axiom/MP/GEN trees only; they do not claim complete Y generation/native other-five-rule qualification, main targets, benchmark speedup, infinite extension or unrestricted logic negative.','No project/source helper/model/search/VM/codec/checker replay; only standard-library file/JSON/gzip/hash and saved-field integer/graph/certificate checks.']}
p=O/'Z-qualification001-complete-independent-passive-data-support-v1.json';p.write_text(json.dumps(support,sort_keys=True,ensure_ascii=True,indent=2)+'\n')
print(json.dumps({'support':ref(p),'status':'PASS','assignments':assignment_count,'solutions':solution_count,'provider_rows':provider_rows,'images':image_count,'observations':observation_count,'physical_bytes':support['physical_bytes'],'artifact_raw_bytes':rawtotal,'native_unique':support['native_unique']},indent=2))
