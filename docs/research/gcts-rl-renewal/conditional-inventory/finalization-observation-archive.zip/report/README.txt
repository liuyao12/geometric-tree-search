Finite observation-helper qualification, 2026-10-19.
Raw Sources/JSON and consumed actual records; no production scientific replay.
The executable helpers depend on external pinned Python/OS/stdlib.
Only the six named Sources are evaluated in the archived helper-only worker.
Production dependency pins in driver/cold are inert for this scope.
Old Sources and failed reviews remain historical; latest exact Sources and grants are identified in the summary.
Archived grants cannot authorize another run.
