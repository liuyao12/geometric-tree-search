"""Correct frozen helper wrapper coupling; Source-only, no evaluation."""
from pathlib import Path
import hashlib
import json

D=Path('/private/tmp/gcts-finalization-instrumentation-ROOT-20261019')
worker=(D/'qualify_finalization_worker_v1.py').read_text()
worker=worker.replace("VERSION='finalization-instrumentation-helper-worker-v1'","VERSION='finalization-instrumentation-helper-worker-v2'")
a="""    try:
        driver=load(plan['driver'],'_owned_finalization_qualification_driver')"""
b="""    driver=None;cold=None;harness=None;guard=None;original_clock=None;qualification=None
    qualification_stage='load_sources'
    try:
        driver=load(plan['driver'],'_owned_finalization_qualification_driver')"""
assert worker.count(a)==1;worker=worker.replace(a,b,1)
worker=worker.replace("        qualification=harness.qualify(driver,cold,checkpoint)\n", "        qualification_stage='qualify_helpers'\n        qualification=harness.qualify(driver,cold,checkpoint)\n        qualification_stage='verify_complete_return'\n",1)
worker=worker.replace("        result=save_new(actual/'result.json',payload)", "        qualification_stage='serialize_complete_result'\n        result=save_new(actual/'result.json',payload)",1)
a="""    except BaseException as error:
        try:save_new(actual/'worker-failure.json',dict(schema='finalization-helper-qualification-failure-v1',
            error_type=type(error).__name__,message=str(error)[:4096],
            scientific_acceptance=False,mathematical_proof_accepted=False),cap=1048576)
        except BaseException:pass
        raise"""
b="""    except BaseException as error:
        # Failure-only metadata checks do not invoke a target action again or
        # replace the active original error. Cold clock restoration is checked,
        # never repaired into a qualification success.
        binding_check=dict(attempted=guard is not None,passed=None,error_type=None)
        if guard is not None:
            try:guard();binding_check['passed']=True
            except BaseException as metadata_error:
                binding_check.update(passed=False,error_type=type(metadata_error).__name__)
        clock_restored=None if cold is None or original_clock is None else cold._NOW_NS is original_clock
        try:
            prefix=getattr(error,'qualification_prefix',None)
            if prefix is not None:
                need(type(prefix)is dict and len(canonical(prefix))<=131072,
                     'bounded ordinary failed/unfinished helper prefix')
            if qualification is not None:
                need(type(qualification)is dict and len(canonical(qualification))<=131072,
                     'bounded returned nonadmitted helper packet')
            save_new(actual/'worker-failure.json',dict(schema='finalization-helper-qualification-failure-v2',
                status='FAILED_OR_UNFINISHED',authority=False,full_pipeline_qualified=False,
                error_type=type(error).__name__,message=str(error)[:4096],
                qualification_stage=qualification_stage,completed_prefix=prefix,
                returned_nonadmitted_packet=qualification,clock_slot_restored=clock_restored,
                helper_callable_binding_check=binding_check,
                scientific_acceptance=False,mathematical_proof_accepted=False),cap=1048576)
        except BaseException as metadata_error:
            try:
                if not (actual/'worker-failure.json').exists():
                    save_new(actual/'worker-failure.json',dict(schema='finalization-helper-qualification-failure-v2',
                        status='FAILED_OR_UNFINISHED',authority=False,full_pipeline_qualified=False,
                        error_type=type(error).__name__,diagnostics_status='UNAVAILABLE',
                        metadata_error_type=type(metadata_error).__name__,
                        scientific_acceptance=False,mathematical_proof_accepted=False),cap=1048576)
            except BaseException:pass
        raise"""
assert worker.count(a)==1;worker=worker.replace(a,b,1)
wp=D/'qualify_finalization_worker_v2.py';compile(worker,str(wp),'exec');wp.write_text(worker)
runner=(D/'run_finalization_helpers_once_v1.py').read_text()
runner=runner.replace("VERSION='finalization-instrumentation-once-runner-v1'","VERSION='finalization-instrumentation-once-runner-v2'")
a="for k in ['worker','harness','driver','runner','observer']:need(contains(r,plan[k]),'complete reviewed '+k)"
b="for k in ['worker','harness','driver','cold','runner','observer']:need(contains(r,plan[k]),'complete reviewed '+k)"
assert runner.count(a)==1;runner=runner.replace(a,b,1)
rp=D/'run_finalization_helpers_once_v2.py';compile(runner,str(rp),'exec');rp.write_text(runner)
observer=(D/'observe_finalization_helpers_once_v1.py').read_text()
observer=observer.replace('finalization-instrumentation-final-terminal-observer-v1','finalization-instrumentation-final-terminal-observer-v2')
observer=observer.replace('f5e5ceab7d13eafb6a24e2bd3c9facbf66f094009cebaed4dc79ae11e7c1c4d1',hashlib.sha256(runner.encode()).hexdigest())
op=D/'observe_finalization_helpers_once_v2.py';compile(observer,str(op),'exec');op.write_text(observer)
def pin(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
v=dict(schema='finalization-helper-wrapper-Source-correction-v1',sources=[pin(wp),pin(rp),pin(op)],
    parents=[pin(D/'qualify_finalization_worker_v1.py'),pin(D/'run_finalization_helpers_once_v1.py'),pin(D/'observe_finalization_helpers_once_v1.py')],
    fixes=['Require all six executed Sources including cold in independent Source-review role.',
           'Retain bounded unexpected/unfinished harness prefix or returned nonadmitted packet as diagnostics only.',
           'Check callable bindings and exact clock identity on failure without rerunning target actions or masking active error.'],
    scientific_calls=0,module_imports=0,unused_compilations=3,actual_execution_authorized=False,
    caveat='No runtime/source pass is inherited. Prefix carrier requires separately reviewed harnessV2 and all new plan/review/once gates.')
p=D/'helper-wrapper-correction-v1.json';p.write_text(json.dumps(v,sort_keys=True,indent=2)+'\n');print(json.dumps(v,sort_keys=True,indent=2))
