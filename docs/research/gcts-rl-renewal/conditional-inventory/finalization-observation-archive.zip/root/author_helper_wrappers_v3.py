"""Add finite reached prefix-carrier controls; Source-only, no helper calls."""
from pathlib import Path
import hashlib
import json

D=Path('/private/tmp/gcts-finalization-instrumentation-ROOT-20261019')
s=(D/'qualify_finalization_worker_v3.py').read_text()
s=s.replace("VERSION='finalization-instrumentation-helper-worker-v3'","VERSION='finalization-instrumentation-helper-worker-v4'")
a="""        qualification_stage='qualify_helpers'
        qualification=harness.qualify(driver,cold,checkpoint)
        qualification_stage='verify_complete_return'
"""
b="""        qualification_stage='qualify_helpers'
        normal_checkpoint_count=0
        def counted_checkpoint():
            nonlocal normal_checkpoint_count
            checkpoint();normal_checkpoint_count+=1
        qualification=harness.qualify(driver,cold,counted_checkpoint)
        qualification_stage='verify_complete_return'
"""
assert s.count(a)==1;s=s.replace(a,b,1)
a="""        for role in ('python','worker','harness','driver','cold','runner','observer','declaration'):
            checked(plan[role]);checkpoint()
        payload=dict("""
b="""        # A complete normal helper call is followed by three explicitly
        # bounded interruptions of the same metadata-only harness. The source
        # marker must be reached after a real work-clock check; an earlier real
        # deadline is never mistaken for the planned foreign exception.
        need(declaration['maximum_helper_qualification_calls']==4 and normal_checkpoint_count>=5,
             'one normal and three declared interrupted helper calls')
        control_specs=[('initial_checkpoint',1,RuntimeError,0,None,'initial_checkpoint'),
            ('after_first_completed_group',4,ValueError,1,names[1],'fixture_before_checkpoint'),
            ('final_checkpoint',normal_checkpoint_count,StopIteration,len(names),None,'result_final_checkpoint')]
        need([row[0]for row in control_specs]==declaration['expected_prefix_control_names'],
             'exact three prefix control declarations')
        prefix_fault_checks=[];prefix_copies=[]
        for label,target,kind,completed,active,stage_name in control_specs:
            qualification_stage='prefix_control:'+label
            marker_error=kind('planned finite prefix interruption:'+label)
            control_calls=0
            def interrupted_checkpoint():
                nonlocal control_calls
                checkpoint();control_calls+=1
                if control_calls==target:raise marker_error
            try:
                harness.qualify(driver,cold,interrupted_checkpoint)
            except BaseException as observed:
                if observed is not marker_error:raise
                need(control_calls==target,'planned prefix checkpoint actually reached')
                prefix=getattr(observed,'qualification_prefix',None)
                need(type(prefix)is dict and prefix['schema']=='finalization-instrumentation-helper-prefix-v1'and
                     prefix['status']=='FAILED_OR_UNFINISHED'and prefix['authority']is False and
                     prefix['full_pipeline_qualified']is False and prefix['full_qualification_completed']is False and
                     prefix['complete_prefix_retained']is True and
                     prefix['completed_fixture_count']==completed and prefix['active_fixture']==active and
                     prefix['stage']==stage_name and
                     [row['name']for row in prefix['completed_diagnostics']]==names[:completed]and
                     len(canonical(prefix))<=131072,'exact detached bounded unfinished prefix')
                guard();need(cold._NOW_NS is original_clock,'clock restored on planned prefix failure')
                prefix_fault_checks.append(dict(name=label,status='passed',mathematical_authority=False,
                    checkpoint_ordinal=target,checkpoint_calls=control_calls,
                    exception_type=kind.__name__,exact_exception_identity=True,
                    clock_slot_restored=True,helper_callable_bindings_unchanged=True,
                    prefix=prefix))
                prefix_copies.append((prefix,canonical(prefix)))
            else:
                raise ValueError('planned prefix interruption did not occur')
        need(all(canonical(value)==raw for value,raw in prefix_copies),
             'retained prefixes remain detached across later helper calls')
        checkpoint();guard();need(cold._NOW_NS is original_clock and not denied,'final finite control custody')
        for role in ('python','worker','harness','driver','cold','runner','observer','declaration'):
            checked(plan[role]);checkpoint()
        payload=dict("""
assert s.count(a)==1;s=s.replace(a,b,1)
s=s.replace("invocation_id=plan['invocation_id'],plan=pin(plan_path,plan_raw),qualification=qualification,",
            "invocation_id=plan['invocation_id'],plan=pin(plan_path,plan_raw),qualification=qualification,\n            helper_qualification_calls=4,normal_checkpoint_calls=normal_checkpoint_count,\n            prefix_fault_checks=prefix_fault_checks,retained_prefixes_detached=True,",1)
s=s.replace("instrumentation_qualification_candidate=True,full_pipeline_qualified=False,",
            "instrumentation_qualification_candidate=True,helper_qualification_calls=4,full_pipeline_qualified=False,",1)
worker=D/'qualify_finalization_worker_v4.py';compile(s,str(worker),'exec');worker.write_text(s)
r=(D/'run_finalization_helpers_once_v2.py').read_text()
r=r.replace("VERSION='finalization-instrumentation-once-runner-v2'","VERSION='finalization-instrumentation-once-runner-v3'")
a="""        need(payload['Native_calls']==payload['Model_calls']==payload['search_calls']==payload['mathematical_proof_replays']==payload['opaque_Native_decodes']==0 and payload['scientific_acceptance']is False and payload['new_theorem']is False,'no proof authority')"""
b=a+"""
        need(w['helper_qualification_calls']==payload['helper_qualification_calls']==declaration['maximum_helper_qualification_calls']==4,
             'one normal plus three bounded interrupted helper calls')
        controls=payload['prefix_fault_checks']
        need([row['name']for row in controls]==declaration['expected_prefix_control_names']and len(controls)==3 and
             all(row['status']=='passed'and row['mathematical_authority']is False and
                 row['exact_exception_identity']is True and row['clock_slot_restored']is True and
                 row['helper_callable_bindings_unchanged']is True for row in controls)and
             payload['retained_prefixes_detached']is True,'complete planned prefix-carrier controls')"""
assert r.count(a)==1;r=r.replace(a,b,1)
runner=D/'run_finalization_helpers_once_v3.py';compile(r,str(runner),'exec');runner.write_text(r)
o=(D/'observe_finalization_helpers_once_v2.py').read_text()
o=o.replace('finalization-instrumentation-final-terminal-observer-v2','finalization-instrumentation-final-terminal-observer-v3')
o=o.replace('312c085ac25306d2c88e5c45cd608b9d7db131de3dbee6ac2f170c5ec838485b',hashlib.sha256(r.encode()).hexdigest())
observer=D/'observe_finalization_helpers_once_v3.py';compile(o,str(observer),'exec');observer.write_text(o)
def pin(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
v=dict(schema='finalization-helper-prefix-control-Source-v1',sources=[pin(worker),pin(runner),pin(observer)],
    maximum_worker_invocations=1,maximum_helper_qualification_calls=4,
    prefix_controls=['initial_checkpoint','after_first_completed_group','final_checkpoint'],
    limits_unchanged=True,scientific_calls=0,module_imports=0,unused_compilations=3,actual_execution_authorized=False,
    scope='New metadata-only carrier controls; exact reached foreign marker,0/1/27 completed-prefix rows, restored clock and callable identities. No production proof/coldmain/inverse calls, no full pipeline authority.')
p=D/'helper-prefix-control-Source-v1.json';p.write_text(json.dumps(v,sort_keys=True,indent=2)+'\n');print(json.dumps(v,sort_keys=True,indent=2))
