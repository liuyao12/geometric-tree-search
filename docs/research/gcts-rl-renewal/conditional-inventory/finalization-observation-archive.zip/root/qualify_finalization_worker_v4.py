"""One reviewed finite helper qualification. No production proof runtime."""
import time
NOW=time.monotonic_ns
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import types

VERSION='finalization-instrumentation-helper-worker-v4'
LIMITS=dict(work_seconds=180,overall_seconds=210,memory_bytes=1073741824,
    result_bytes=134217728,expanded_bytes=134217728,stdout_bytes=4194304,stderr_bytes=4194304)

def need(value,message):
    if not value:raise ValueError(message)

def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()

def pin(path,raw):
    return dict(path=str(Path(path).resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())

def checked(row):
    raw=Path(row['path']).read_bytes()
    need(pin(row['path'],raw)==row,'exact whole raw Source/input descriptor')
    return raw

def save_new(path,value,cap=4194304):
    raw=canonical(value)+b'\n';need(len(raw)<=cap,'bounded complete ordinary qualification metadata')
    fd=os.open(str(path),os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
    with os.fdopen(fd,'wb')as stream:
        stream.write(raw);stream.flush();os.fsync(stream.fileno())
    return pin(path,raw)

def load(row,name):
    checked(row)
    spec=importlib.util.spec_from_file_location(name,row['path'])
    need(spec is not None and spec.loader is not None,'explicit owned Source loader')
    module=importlib.util.module_from_spec(spec)
    sys.modules[name]=module
    spec.loader.exec_module(module)
    need(Path(module.__file__).resolve()==Path(row['path']).resolve(),'exact loaded module origin')
    return module

def callable_snapshot(modules):
    functions=[];bindings=[]
    def function(owner,name,value):
        if isinstance(value,types.FunctionType):
            bindings.append((owner,name,value))
            functions.append((value,value.__code__,value.__globals__,value.__defaults__,value.__kwdefaults__))
    for module in modules:
        for name,value in vars(module).items():
            function(module,name,value)
            if isinstance(value,type)and value.__module__==module.__name__:
                bindings.append((module,name,value))
                for member,method in vars(value).items():
                    function(value,member,method)
    def verify():
        for owner,name,value in bindings:
            need(vars(owner).get(name)is value,'helper callable/class binding unchanged after finite fixtures')
        for value,code,namespace,defaults,kwdefaults in functions:
            need(value.__code__ is code and value.__globals__ is namespace and
                value.__defaults__ is defaults and value.__kwdefaults__ is kwdefaults,
                'helper code/globals/default identities unchanged')
    return verify

def main(path):
    need(sys.platform=='darwin'and sys.flags.isolated and sys.flags.no_site and
         sys.dont_write_bytecode,'declared isolated Darwin -I -S -B worker')
    plan_path=Path(path).resolve();plan_raw=plan_path.read_bytes();need(len(plan_raw)<=16777216,'finite once plan')
    plan=json.loads(plan_raw)
    need(set(plan)=={'schema','invocation_id','actual_directory','python','worker','harness',
        'driver','runner','observer','inputs','limits','cold','declaration','authorization'}and
        plan['schema']=='ROOT-finalization-helper-once-plan-v1','exact reviewed helper plan')
    need(plan['limits']==LIMITS and plan['inputs']==[],'unchanged numeric limits and no historical/scientific inputs')
    need(Path(sys.executable).resolve()==Path(plan['python']['path']).resolve(),'pinned Python')
    need(pin(__file__,Path(__file__).read_bytes())==plan['worker'],'exact qualification worker Source')
    actual=Path(plan['actual_directory']);need(actual==actual.resolve()==Path.cwd(),'exact fresh actual directory')
    marker=json.loads((actual/'CONSUMED.json').read_bytes())
    need(marker['schema']=='finalization-instrumentation-consumed-v1'and
         marker['invocation_id']==plan['invocation_id']and marker['plan']==pin(plan_path,plan_raw)and
         marker['maximum_worker_launches']==1 and marker['consumed_before_Popen']is True,
         'exclusive external once consumption before worker')
    began=marker['began_ns'];work=marker['work_deadline_ns'];overall=marker['overall_deadline_ns']
    need(work==began+180000000000 and overall==began+210000000000,'absolute original180/210 deadlines')
    def checkpoint():need(NOW()<work,'all finite helper work and positive metadata within180')
    checkpoint()
    for role in ('python','worker','harness','driver','cold','runner','observer','declaration'):
        checked(plan[role]);checkpoint()
    declaration=json.loads(checked(plan['declaration']))
    need(declaration['profile']=='owned-finalization-phase-instrumented-v1'and
         declaration['full_pipeline_qualified']is False,'explicit bounded helper-only declaration')
    denied=[]
    def audit(event,args):
        if event in ('subprocess.Popen','os.fork','os.posix_spawn','os.system','socket.connect',
                     'socket.bind','ctypes.dlopen'):
            denied.append(event)
            raise RuntimeError('production process/network/dlopen is forbidden in finite helper qualification')
    sys.addaudithook(audit)
    driver=None;cold=None;harness=None;guard=None;original_clock=None;qualification=None
    qualification_stage='load_sources'
    try:
        driver=load(plan['driver'],'_owned_finalization_qualification_driver')
        cold=load(plan['cold'],'_owned_finalization_qualification_cold')
        harness=load(plan['harness'],'_owned_finalization_qualification_harness')
        checkpoint()
        guard=callable_snapshot((driver,cold,harness));original_clock=cold._NOW_NS
        need(driver.OWNED_FINALIZATION_PROFILE==cold.FINALIZATION_PROFILE==declaration['profile'],
             'exact new helper profile')
        names=list(harness.FIXTURE_NAMES)
        need(names==declaration['expected_fixture_names']and len(names)==len(set(names)),
             'complete ordered independent-declaration fixture census')
        qualification_stage='qualify_helpers'
        normal_checkpoint_count=0
        def counted_checkpoint():
            nonlocal normal_checkpoint_count
            checkpoint();normal_checkpoint_count+=1
        qualification=harness.qualify(driver,cold,counted_checkpoint)
        qualification_stage='verify_complete_return'
        checkpoint();guard()
        need(cold._NOW_NS is original_clock,'intentional fake clock slot restored exactly')
        need(not denied,'no attempted production process/network/dlopen')
        need(qualification['schema']=='finalization-instrumentation-helper-qualification-v1'and
             qualification['status']=='FINITE_INSTRUMENTATION_HELPERS_QUALIFIED'and
             qualification['authority']is False and qualification['full_pipeline_qualified']is False,
             'finite helper-only successful result')
        diagnostics=qualification['diagnostics']
        need([row['name']for row in diagnostics]==names and all(row['status']=='passed'and
             row['mathematical_authority']is False for row in diagnostics),'all declared finite diagnostic packets')
        # A complete normal helper call is followed by three explicitly
        # bounded interruptions of the same metadata-only harness. The source
        # marker must be reached after a real work-clock check; an earlier real
        # deadline is never mistaken for the planned foreign exception.
        need(declaration['maximum_helper_qualification_calls']==4 and normal_checkpoint_count>=5,
             'one normal and three declared interrupted helper calls')
        control_specs=[('initial_checkpoint',1,RuntimeError,0,None,'initial_checkpoint'),
            ('after_first_completed_group',4,ValueError,1,names[1],'fixture_before_checkpoint'),
            ('final_checkpoint',normal_checkpoint_count,StopIteration,len(names),None,'result_final_checkpoint')]
        need([row[0]for row in control_specs]==declaration['expected_prefix_control_names'],
             'exact three prefix control declarations')
        prefix_fault_checks=[];prefix_copies=[]
        for label,target,kind,completed,active,stage_name in control_specs:
            qualification_stage='prefix_control:'+label
            marker_error=kind('planned finite prefix interruption:'+label)
            control_calls=0
            def interrupted_checkpoint():
                nonlocal control_calls
                checkpoint();control_calls+=1
                if control_calls==target:raise marker_error
            try:
                harness.qualify(driver,cold,interrupted_checkpoint)
            except BaseException as observed:
                if observed is not marker_error:raise
                need(control_calls==target,'planned prefix checkpoint actually reached')
                prefix=getattr(observed,'qualification_prefix',None)
                need(type(prefix)is dict and prefix['schema']=='finalization-instrumentation-helper-prefix-v1'and
                     prefix['status']=='FAILED_OR_UNFINISHED'and prefix['authority']is False and
                     prefix['full_pipeline_qualified']is False and prefix['full_qualification_completed']is False and
                     prefix['complete_prefix_retained']is True and
                     prefix['completed_fixture_count']==completed and prefix['active_fixture']==active and
                     prefix['stage']==stage_name and
                     [row['name']for row in prefix['completed_diagnostics']]==names[:completed]and
                     len(canonical(prefix))<=131072,'exact detached bounded unfinished prefix')
                guard();need(cold._NOW_NS is original_clock,'clock restored on planned prefix failure')
                prefix_fault_checks.append(dict(name=label,status='passed',mathematical_authority=False,
                    checkpoint_ordinal=target,checkpoint_calls=control_calls,
                    exception_type=kind.__name__,exact_exception_identity=True,
                    clock_slot_restored=True,helper_callable_bindings_unchanged=True,
                    prefix=prefix))
                prefix_copies.append((prefix,canonical(prefix)))
            else:
                raise ValueError('planned prefix interruption did not occur')
        need(all(canonical(value)==raw for value,raw in prefix_copies),
             'retained prefixes remain detached across later helper calls')
        checkpoint();guard();need(cold._NOW_NS is original_clock and not denied,'final finite control custody')
        for role in ('python','worker','harness','driver','cold','runner','observer','declaration'):
            checked(plan[role]);checkpoint()
        payload=dict(schema='finalization-instrumentation-qualification-result-v1',version=VERSION,
            invocation_id=plan['invocation_id'],plan=pin(plan_path,plan_raw),qualification=qualification,
            helper_qualification_calls=4,normal_checkpoint_calls=normal_checkpoint_count,
            prefix_fault_checks=prefix_fault_checks,retained_prefixes_detached=True,
            Native_calls=0,Model_calls=0,search_calls=0,mathematical_proof_replays=0,opaque_Native_decodes=0,
            scientific_acceptance=False,new_theorem=False,denied_runtime_events=denied,
            clock_slot_restored=True,helper_callable_bindings_unchanged=True,
            scope='Only Source-reviewed new observation helpers with fake boundary/action/passive Store. No production driver/cold main, point model, Native, inverse or historical proof calls. Raw Sources and function/default bindings rechecked; trusted exclusive ownership during finite fixtures, not an adversarial memory sandbox or universal soundness proof.')
        qualification_stage='serialize_complete_result'
        result=save_new(actual/'result.json',payload)
        checkpoint()
        header=dict(schema='finalization-instrumentation-qualification-worker-receipt-v1',
            invocation_id=plan['invocation_id'],plan=pin(plan_path,plan_raw),began_ns=began,
            work_deadline_ns=work,overall_deadline_ns=overall,work_completed_ns=NOW(),result=result,
            logical_result_bytes=result['bytes'],outer_metadata_reservation=9437184,
            instrumentation_qualification_candidate=True,helper_qualification_calls=4,full_pipeline_qualified=False,
            mathematical_proof_accepted=False,scientific_acceptance=False,Native_calls=0)
        save_new(actual/'worker-receipt.json',header)
        checkpoint()
    except BaseException as error:
        # Failure-only metadata checks do not invoke a target action again or
        # replace the active original error. Cold clock restoration is checked,
        # never repaired into a qualification success.
        binding_check=dict(attempted=guard is not None,passed=None,error_type=None)
        if guard is not None:
            try:guard();binding_check['passed']=True
            except BaseException as metadata_error:
                binding_check.update(passed=False,error_type=type(metadata_error).__name__)
        clock_restored=None;clock_check_error_type=None
        if cold is not None and original_clock is not None:
            try:clock_restored=cold._NOW_NS is original_clock
            except BaseException as metadata_error:clock_check_error_type=type(metadata_error).__name__
        try:
            prefix=getattr(error,'qualification_prefix',None)
            if prefix is not None:
                need(type(prefix)is dict and len(canonical(prefix))<=131072,
                     'bounded ordinary failed/unfinished helper prefix')
            if qualification is not None:
                need(type(qualification)is dict and len(canonical(qualification))<=131072,
                     'bounded returned nonadmitted helper packet')
            save_new(actual/'worker-failure.json',dict(schema='finalization-helper-qualification-failure-v2',
                status='FAILED_OR_UNFINISHED',authority=False,full_pipeline_qualified=False,
                error_type=type(error).__name__,message=str(error)[:4096],
                qualification_stage=qualification_stage,completed_prefix=prefix,
                returned_nonadmitted_packet=qualification,clock_slot_restored=clock_restored,
                clock_check_error_type=clock_check_error_type,
                helper_callable_binding_check=binding_check,
                scientific_acceptance=False,mathematical_proof_accepted=False),cap=1048576)
        except BaseException as metadata_error:
            try:
                if not (actual/'worker-failure.json').exists():
                    save_new(actual/'worker-failure.json',dict(schema='finalization-helper-qualification-failure-v2',
                        status='FAILED_OR_UNFINISHED',authority=False,full_pipeline_qualified=False,
                        error_type=type(error).__name__,diagnostics_status='UNAVAILABLE',
                        metadata_error_type=type(metadata_error).__name__,
                        scientific_acceptance=False,mathematical_proof_accepted=False),cap=1048576)
            except BaseException:pass
        raise
    return 0

if __name__=='__main__':
    need(len(sys.argv)==2,'one reviewed plan path')
    raise SystemExit(main(sys.argv[1]))
