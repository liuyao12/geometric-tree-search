"""Raw Source authoring and unused compilation only. No component evaluation."""
from pathlib import Path
import ast
import hashlib
import json

D = Path('/private/tmp/gcts-finalization-instrumentation-ROOT-20261019')
PARENT = Path('/private/tmp/gcts-owned-evidence-integration-ROOT-20261019/owned_evidence_receiver_driver_v4.py')
OUT = D / 'owned_evidence_receiver_driver_v5.py'
old = PARENT.read_bytes()
assert len(old) == 114308 and hashlib.sha256(old).hexdigest() == '4850f66edeeb73033979ab5860ca745d5936eb3455bbef3eba10e5ba0c5ff62c'
s = old.decode()

def replace(a, b):
    global s
    assert s.count(a) == 1, a[:150]
    s = s.replace(a, b, 1)

replace("OWNED_VERSION='semantic-family-owned-evidence-driver-v1'", "OWNED_VERSION='semantic-family-owned-evidence-driver-v2-instrumented'")
marker = 'class OwnedEvidenceIncomplete(DriverDataError):pass\n'
addition = '''
OWNED_FINALIZATION_PROFILE='owned-finalization-phase-instrumented-v1'
OWNED_FINALIZATION_PHASES=frozenset(('oracle_close','transport_receipt_copy',
    'native_records_copy','final_assemble','final_seal','final_wire',
    'forest_atomic_write','ordinary_atomic_stream_write','final_full_boundary_check'))
OWNED_FINALIZATION_SNAPSHOTS=frozenset(('before_final_assemble','after_final_assemble',
    'after_final_seal','after_final_wire','after_forest_atomic_write',
    'after_ordinary_atomic_stream_write','after_final_full_boundary_check'))
OWNED_FINALIZATION_BYTES=65536

class _OwnedFinalizationObservation:
    """Bounded out-of-band diagnostics, never a proof or storage root.

    Calls wrap exactly one original action. Additional clock observations and
    passive statistics are charged to the same invocation. On an action or
    diagnostic failure the original exception object is re-raised; observing
    its failure cannot replace it. No caller callback is bypassed or batched.
    """
    def __init__(self,boundary):
        self._boundary=boundary;self._phases=[];self._snapshots=[];self._completed=False
    def record(self):
        value=dict(schema='owned-finalization-observation-v1',
            profile=OWNED_FINALIZATION_PROFILE,authority=False,
            mathematical_authority=False,resource_authority=False,
            completed=self._completed,clock='caller absolute monotonic seconds',
            phases=self._phases,passive_statistics=self._snapshots,
            scope='Additional bounded observation costs included; no scientific result or evidence-root fields are added. Exact callback dispatch origins and public/completion categories are not measured here.')
        raw=_json(value)
        if len(raw)>OWNED_FINALIZATION_BYTES:raise DriverDataError('bounded finalization observation exceeds64KiB')
        return json.loads(raw)
    def attach(self,error):
        try:error.owned_finalization_observation=self.record()
        except BaseException as metadata_error:
            try:error.add_note('finalization diagnostic unavailable: '+type(metadata_error).__name__)
            except BaseException:pass
    def call(self,phase,action):
        if phase not in OWNED_FINALIZATION_PHASES or len(self._phases)>=16:
            raise DriverDataError('finite declared finalization phases only')
        row=dict(phase=phase,started_monotonic=None,returned_monotonic=None,
            action_returned=False,completed=False,error_type=None,failure_observed_monotonic=None,
            failure_clock_error_type=None)
        self._phases.append(row)
        try:
            row['started_monotonic']=self._boundary.observe()
            result=action()
            row['action_returned']=True
            row['returned_monotonic']=self._boundary.observe()
            row['completed']=True
            return result
        except BaseException as error:
            row['error_type']=type(error).__name__
            try:row['failure_observed_monotonic']=self._boundary.observe()
            except BaseException as metadata_error:
                row['failure_clock_error_type']=type(metadata_error).__name__
            self.attach(error)
            raise
    def snapshot(self,label,store):
        if label not in OWNED_FINALIZATION_SNAPSHOTS or len(self._snapshots)>=8:
            raise DriverDataError('finite declared passive snapshots only')
        # The pinned Store.statistics API is passive; it invokes no guard,
        # inverse, canonical stream or operation-producing method.
        row=dict(label=label,observed_monotonic=self._boundary.observe(),statistics=store.statistics())
        raw=_json(row)
        if len(raw)>8192:raise DriverDataError('bounded passive finalization snapshot exceeds8KiB')
        self._snapshots.append(json.loads(raw))
    def complete(self):
        self._completed=True
        return self.record()
'''
replace(marker, marker + addition)

a = '''def _owned_atomic_output(path,result,store,boundary):
    # No rewrite/fallback after final-root construction: all roots stay covered.
    reference=store.assemble(result,label='receiver:complete-legacy-result');sealed=store.seal(reference);wire=store.wire(sealed)
    forest=_atomic_output(Path(path).with_name('evidence-forest.json'),wire,boundary)
    del wire
    output=_atomic_owned_stream(path,store,reference,boundary)
    if forest['bytes']+output['bytes']>OUTPUT_CAP_BYTES:raise OutputCapExceeded('aggregate forest+logical output exceeds128MiB')
    boundary.check(full=True)
    return output,forest,store.statistics()
'''
b = '''def _owned_atomic_output(path,result,store,boundary,observation):
    # No rewrite/fallback after final-root construction: all roots stay covered.
    observation.snapshot('before_final_assemble',store)
    reference=observation.call('final_assemble',lambda:store.assemble(result,label='receiver:complete-legacy-result'))
    observation.snapshot('after_final_assemble',store)
    sealed=observation.call('final_seal',lambda:store.seal(reference))
    observation.snapshot('after_final_seal',store)
    wire=observation.call('final_wire',lambda:store.wire(sealed))
    observation.snapshot('after_final_wire',store)
    forest=observation.call('forest_atomic_write',lambda:_atomic_output(Path(path).with_name('evidence-forest.json'),wire,boundary))
    observation.snapshot('after_forest_atomic_write',store)
    del wire
    output=observation.call('ordinary_atomic_stream_write',lambda:_atomic_owned_stream(path,store,reference,boundary))
    observation.snapshot('after_ordinary_atomic_stream_write',store)
    if forest['bytes']+output['bytes']>OUTPUT_CAP_BYTES:raise OutputCapExceeded('aggregate forest+logical output exceeds128MiB')
    observation.call('final_full_boundary_check',lambda:boundary.check(full=True))
    observation.snapshot('after_final_full_boundary_check',store)
    return output,forest,store.statistics()
'''
replace(a, b)

# Restrict every subsequent change to the explicitly owned entry point.
before, owned = s.split('def run_receiver_owned(', 1)
assert owned.count("version=OWNED_VERSION") == 2
owned = owned.replace("    result = dict(schema=RESULT_SCHEMA, version=OWNED_VERSION", "    observation = _OwnedFinalizationObservation(boundary)\n    result = dict(schema=RESULT_SCHEMA, version=OWNED_VERSION", 1)
owned = owned.replace('    except BaseException as primary:\n        if store is not None:', '    except BaseException as primary:\n        observation.attach(primary)\n        if store is not None:', 1)
owned = owned.replace('''            oracle.close()
            result['transport_receipt'] = _owned(oracle.transport_receipt())
            result['records'] = _owned(oracle.records)''', '''            observation.call('oracle_close',oracle.close)
            result['transport_receipt'] = observation.call('transport_receipt_copy',lambda:_owned(oracle.transport_receipt()))
            result['records'] = observation.call('native_records_copy',lambda:_owned(oracle.records))''', 1)
owned = owned.replace('''            raise failure
        try:
            descriptor,forest_descriptor,evidence_statistics=_owned_atomic_output(output_path,result,store,boundary)
        except BaseException as primary:
            try:primary.owned_evidence_statistics=store.statistics()''', '''            observation.attach(failure)
            raise failure
        try:
            descriptor,forest_descriptor,evidence_statistics=_owned_atomic_output(output_path,result,store,boundary,observation)
        except BaseException as primary:
            observation.attach(primary)
            try:primary.owned_evidence_statistics=store.statistics()''', 1)
owned = owned.replace('''                    independent_saved_forest_inverse_required=True,ROOT_resource_accepted=False,''', '''                    finalization_observation=observation.complete(),
                    independent_saved_forest_inverse_required=True,ROOT_resource_accepted=False,''', 1)
s = before + 'def run_receiver_owned(' + owned

compile(s,str(OUT),'exec')  # Never execute the code object.
old_tree=ast.parse(old.decode());new_tree=ast.parse(s)
old_defs={n.name:ast.dump(n,include_attributes=False) for n in old_tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
new_defs={n.name:ast.dump(n,include_attributes=False) for n in new_tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
changed=[name for name in old_defs if old_defs[name]!=new_defs[name]]
assert changed==['_owned_atomic_output','run_receiver_owned'],changed
assert s.split("OWNED_VERSION=",1)[0]==old.decode().split("OWNED_VERSION=",1)[0]
OUT.write_text(s)
def pin(p):
    raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
receipt=dict(schema='owned-finalization-driver-Source-authoring-v1',parent=pin(PARENT),successor=pin(OUT),
    changed_existing_definitions=changed,unchanged_existing_definition_count=len(old_defs)-len(changed),
    historical_prefix_exact=True,new_definitions=sorted(set(new_defs)-set(old_defs)),
    profile='owned-finalization-phase-instrumented-v1',instrumentation_only=True,
    execution_authorized=False,module_imports=0,scientific_calls=0,unused_compilations=1,
    limitations=['No runtime/fault/operation-count qualification; requires independent review and a fresh bounded subject.',
        'Additional clock observations and passive statistics/JSON copies have real cost; no time-fit or speedup predicted.',
        'Totals of actual checkpoint origins/public/completion dispatches are not measured by this driver.',
        'Historical math/validation/helper bodies remain exact; owned finalization intentionally changes wrapper structure and driver result version.'])
p=D/'driver-Source-authoring-v1.json';p.write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n')
print(json.dumps(receipt,sort_keys=True,indent=2))
