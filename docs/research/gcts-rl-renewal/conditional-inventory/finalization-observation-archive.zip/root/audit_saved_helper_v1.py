"""Root saved JSON/raw-byte join only. No qualifier/target import or replay."""
from pathlib import Path
import hashlib,json,os,stat
D=Path('/private/tmp/gcts-finalization-instrumentation-ROOT-20261019')
C=Path('/private/tmp/gcts-finalization-instrumentation-peer-20261019')
def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def pin(p):
 b=p.read_bytes();return dict(path=str(p.resolve()),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
checks=[]
def check(label,ok):
 checks.append(dict(check=label,passed=bool(ok)))
def descriptor(desc,label):check(label,pin(Path(desc['path']))==desc)
def load(p):return json.loads(p.read_bytes())
plan=load(D/'plan-authorized-v1.json');pp=pin(D/'plan-authorized-v1.json')
A=Path(plan['actual_directory']);O=D/'plan-authorized-v1-terminal-observation'
rr=load(A/'runner-receipt.json');wh=load(A/'worker-receipt.json');q=load(A/'result.json');term=load(O/'terminal.json');cons=load(A/'CONSUMED.json')
decl=load(Path(plan['declaration']['path']));auth=load(Path(plan['authorization']['path']))
subject={k:v for k,v in plan.items()if k!='authorization'};sh=hashlib.sha256(canon(subject)).hexdigest()
check('same thirteen-field subject',len(subject)==13 and sh==rr['subject_sha256']==auth['subject_sha256']==cons['subject_sha256']=='cdc3b27b58d3852abf0f674f8eb0d97ce79871cba500a386b19e2ae193411965')
for role in ('python','worker','harness','driver','cold','runner','observer','declaration','authorization'):descriptor(plan[role],'whole postterminal '+role)
descriptor(decl['trusted_startup_stdlib_ctypes'],'whole postterminal startup ctypes')
descriptor(decl['master'],'whole unchanged master')
for role,desc in auth['review_roles'].items():
 descriptor(desc,'whole current independent '+role+' review');v=load(Path(desc['path']))
 check('independent zeroexec '+role,v['reviewer_identity']=='/root/conventional_control_review'and v['source_only']is True and v['scientific_calls']==0 and v['scientific_acceptance']is False)
 check('current review PASS '+role,v['source_review_passed'if role=='Source'else'prospective_review_passed']is True)
 if role=='plans':check('prospective complete same subject',v['subject']==subject and v['subject_sha256']==sh)
check('true max1 grant',auth['actual_execution_authorized']is True and auth['maximum_actual_invocations']==1 and auth['author_identity']=='/root')
check('empty proof/scientific inputs',plan['inputs']==[])
for label,v in [('runner',rr),('header',wh),('result',q),('terminal',term),('consumed',cons)]:check('exact plan '+label,v['plan']==pp)
check('one consumed worker',cons['maximum_worker_launches']==rr['worker_launch_attempts']==1 and cons['consumed_before_Popen']is True)
for desc,label in [(rr['consumed_marker'],'consumed marker'),(rr['worker_receipt'],'worker receipt'),(rr['result'],'complete result'),(term['runner_receipt'],'runner receipt')]:descriptor(desc,'whole '+label)
check('same full result descriptor',rr['result']==wh['result']==pin(A/'result.json'))
check('original all numeric caps',plan['limits']==rr['limits']==decl['limits']==dict(work_seconds=180,overall_seconds=210,memory_bytes=1073741824,result_bytes=134217728,expanded_bytes=134217728,stdout_bytes=4194304,stderr_bytes=4194304))
check('same epoch and absolute deadlines',rr['began_ns']==wh['began_ns']==cons['began_ns']and rr['work_deadline_ns']==wh['work_deadline_ns']==cons['work_deadline_ns']==rr['began_ns']+180000000000 and rr['overall_deadline_ns']==wh['overall_deadline_ns']==cons['overall_deadline_ns']==rr['began_ns']+210000000000)
check('all positive worker/outer checks before180',rr['began_ns']<wh['work_completed_ns']<rr['worker_terminal_observed_ns']<=rr['closed_ns']<rr['work_deadline_ns'])
check('known successful terminal before210',rr['closed_ns']<term['terminal_observed_ns']<rr['overall_deadline_ns']and term['runner_exit_code']==0 and term['terminal_gate_passed']is True)
check('correct same312 time difference',term['runner_clock_elapsed_seconds']==(term['terminal_observed_ns']-rr['began_ns'])/1e9)
check('worker successful known reaped',rr['worker_reaped']is True and rr['worker_exit_code']==0 and rr['worker_wait4_status']==0)
check('group absent in receipt',rr['owned_group_absent']is True and rr['owned_pgid']==rr['worker_pid'])
try:os.killpg(rr['owned_pgid'],0)
except ProcessLookupError:absent=True
else:absent=False
check('group independently absent after terminal',absent)
check('successful runner candidate only',rr['resource_candidate_accepted']is True and rr['instrumentation_candidate']is True and rr['errors']==[]and rr['signals']==[])
check('no expired result marker',not (A/'POST_RECEIPT_WORK_FAILURE.json').exists()and not (A/'POST_RECEIPT_DEADLINE_FAILURE.json').exists()and not (A/'worker-failure.json').exists())
check('header helper candidate only',wh['instrumentation_qualification_candidate']is True and wh['full_pipeline_qualified']is False and wh['scientific_acceptance']is False and wh['mathematical_proof_accepted']is False)
check('four exact helper calls',q['helper_qualification_calls']==wh['helper_qualification_calls']==decl['maximum_helper_qualification_calls']==4)
check('normal checkpoint census57',q['normal_checkpoint_calls']==decl['expected_normal_checkpoint_calls']==57)
normal=q['qualification'];rows=normal['diagnostics'];names=decl['expected_fixture_names']
check('normal schema/status/non-authority',normal['schema']=='finalization-instrumentation-helper-qualification-v1'and normal['status']=='FINITE_INSTRUMENTATION_HELPERS_QUALIFIED'and normal['authority']is False and normal['full_pipeline_qualified']is False and normal['mathematical_authority']is False and normal['resource_authority']is False)
check('27 ordered unique complete groups',[r['name']for r in rows]==normal['expected_fixture_names']==names and len(set(names))==27)
for row in rows:check('normal passed '+row['name'],row['status']=='passed'and row['mathematical_authority']is False and type(row['details'])is dict)
check('normal exact source pins',normal['source_pins']=={k:plan[k]for k in ('driver','cold')})
controls=q['prefix_fault_checks'];check('three exact prefix controls',[r['name']for r in controls]==decl['expected_prefix_control_names']and len(controls)==3)
for row,spec in zip(controls,decl['prefix_controls']):
 label=row['name'];prefix=row['prefix'];count=spec['completed_fixture_count']
 check('reached planned '+label,row['status']=='passed'and row['checkpoint_ordinal']==row['checkpoint_calls']==spec['checkpoint_ordinal']and row['exception_type']==spec['exception_type'])
 check('original exception/bindings '+label,row['exact_exception_identity']is True and row['clock_slot_restored']is True and row['helper_callable_bindings_unchanged']is True)
 check('unfinished status '+label,prefix['schema']=='finalization-instrumentation-helper-prefix-v1'and prefix['status']=='FAILED_OR_UNFINISHED'and prefix['authority']is False and prefix['full_pipeline_qualified']is False and prefix['full_qualification_completed']is False and prefix['complete_prefix_retained']is True)
 check('exact completed prefix '+label,prefix['completed_fixture_count']==count and prefix['completed_diagnostics']==rows[:count]and prefix['expected_fixture_names']==names)
 check('exact interruption location '+label,prefix['stage']==spec['stage']and prefix['active_fixture']==spec['active_fixture'])
 check('bounded detached prefix '+label,len(canon(prefix))<=131072 and q['retained_prefixes_detached']is True)
check('normal restored clock and shallow bindings',q['clock_slot_restored']is True and q['helper_callable_bindings_unchanged']is True and normal['mock_slot']['restored']is True)
for k in ('Native_calls','Model_calls','search_calls','mathematical_proof_replays','opaque_Native_decodes'):check('no '+k,q[k]==0)
check('no science/new theorem authority',q['scientific_acceptance']is False and q['new_theorem']is False and rr['scientific_acceptance']is False and rr['mathematical_proof_accepted']is False and term['scientific_acceptance']is False and term['ROOT_resource_accepted']is False)
check('finite audit no denied attempts',q['denied_runtime_events']==[])
check('Darwin worker highwater within1GiB',rr['worker_peak_bytes']==rr['worker_wait4_usage']['ru_maxrss']==51986432 and rr['worker_peak_bytes']<=plan['limits']['memory_bytes'])
check('complete ordinary output ledger',rr['logical_result_bytes']==wh['logical_result_bytes']==rr['result']['bytes']==22999 and rr['logical_result_bytes']<=plan['limits']['expanded_bytes'])
all_files=[]
for folder in (A,O):
 for path in sorted(folder.iterdir()):
  st=path.lstat();check('regular ordinary '+str(path.relative_to(D)),stat.S_ISREG(st.st_mode)and not path.is_symlink());all_files.append(pin(path))
actual_bytes=sum(p.stat().st_size for p in A.iterdir());observer_bytes=sum(p.stat().st_size for p in O.iterdir())
check('exact physical ledger before runner',actual_bytes-(A/'runner-receipt.json').stat().st_size==rr['physical_before_runner_receipt']==24457)
check('reserved outer9MiB',wh['outer_metadata_reservation']==9437184 and rr['conservative_physical_bytes']==rr['physical_before_runner_receipt']+9437184)
check('actual outer metadata fits reservations',(A/'runner-receipt.json').stat().st_size<=8388608 and observer_bytes<=1048576)
check('complete physical actual+outer within128MiB',actual_bytes+observer_bytes<=rr['conservative_physical_bytes']<=plan['limits']['result_bytes'])
for label in ('stdout','stderr'):
 descriptor(rr[label],'whole worker '+label+' EOF')
 check('all captured '+label+' logs<=4MiB',(A/(label+'.bin')).stat().st_size<=4194304 and (O/(label+'.bin')).stat().st_size<=4194304)
check('regular logs closed',rr['regular_logs_closed']is True)
bad=[r for r in checks if not r['passed']]
v=dict(schema='ROOT-finalization-helper-saved-audit-v1',saved_data_only=True,scientific_calls=0,fixture_replays=0,proof_decodes=0,
 all_checks_passed=not bad,check_count=len(checks),mismatch_count=len(bad),checks=checks,
 finite_helper_qualification_adopted=not bad,full_pipeline_qualified=False,scientific_acceptance=False,new_theorem=False,goal_complete=False,
 physical_actual_bytes=actual_bytes,physical_observer_bytes=observer_bytes,conservative_physical_bytes=rr['conservative_physical_bytes'],logical_result_bytes=rr['logical_result_bytes'],worker_highwater_bytes=rr['worker_peak_bytes'],
 terminal_seconds=term['runner_clock_elapsed_seconds'],helper_calls=4,normal_groups=27,normal_checkpoint_calls=57,retained_prefix_counts=[r['prefix']['completed_fixture_count']for r in controls],
 peer_group_independently_absent=absent,plan=pp,result=pin(A/'result.json'),all_actual_files=all_files,
 limitations=['Finite fake-interface helper behavior only; no full driver/cold retention or real evidence cost measured.','Source-backed some detail declarations are not independent dynamic operation-origin counts.','Trusted raw Sources/runtime/exclusive ownership; shallow binding/default/code checks, finite denylist.','Synthetic intervals and nested phases are not disjoint real performance costs.','Outer/observer RAM excluded; highwater posthoc, not a continuous RSS limit; standalone allpositive180 stronger than full pipeline later210.'])
p=D/'ROOT-saved-actual-audit-v1.json'
with p.open('x')as f:json.dump(v,f,sort_keys=True,indent=2);f.write('\n')
print(json.dumps(dict(**pin(p),checks=len(checks),mismatches=len(bad),terminal_seconds=v['terminal_seconds'],worker_peak_bytes=v['worker_highwater_bytes']),sort_keys=True))
if bad:print(json.dumps(bad,indent=2));raise SystemExit(2)
closure=dict(schema='ROOT-finalization-helper-cohort-closure-v1',plan=pp,audit=pin(p),terminal=pin(O/'terminal.json'),worker_reaped=True,owned_group_absent=absent,regular_logs_closed=True,observer_and_runner_exec_exit_code=0,once_consumed=True,retry=False,release_peers_for_saved_metadata_review=True,scientific_acceptance=False)
p=D/'ROOT-cohort-closure-v1.json'
with p.open('x')as f:json.dump(closure,f,sort_keys=True,indent=2);f.write('\n')
print(json.dumps(pin(p),sort_keys=True))
