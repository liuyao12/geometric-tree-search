"""Raw Source/JSON successor only: resolve reviewed stdlib startup conflict."""
from pathlib import Path
import ast
import hashlib
import json

D=Path('/private/tmp/gcts-finalization-instrumentation-ROOT-20261019')
C=Path('/private/tmp/gcts-finalization-instrumentation-peer-20261019')
def pin(p):
    b=p.read_bytes();return dict(path=str(p.resolve()),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def write(p,v):
    with p.open('x')as f:json.dump(v,f,sort_keys=True,indent=2,allow_nan=False);f.write('\n')
    return pin(p)

old=D/'qualify_finalization_worker_v5.py'
assert pin(old)['sha256']=='56fa29726a48dd0e4c16c041c68e1eedea3fc92530bd8385af0df4bc0a224275'
raw=old.read_text()
needle="    denied=[]\n    def audit(event,args):\n"
replacement="""    # This trusted bundled stdlib import initializes pythonapi=PyDLL(None).
    # Keep it inside charged startup and before the later target/fixture
    # dlopen denial; the exact dependency is declared and raw-checked.
    startup=declaration['trusted_startup_stdlib_ctypes']
    checked(startup);checkpoint()
    import ctypes
    need(Path(ctypes.__file__).resolve()==Path(startup['path']).resolve(),
         'reviewed bundled ctypes startup origin')
    checked(startup);checkpoint()
    denied=[]
    def audit(event,args):
"""
assert raw.count(needle)==1
successor=raw.replace("VERSION='finalization-instrumentation-helper-worker-v5'","VERSION='finalization-instrumentation-helper-worker-v6'").replace(needle,replacement)
target=D/'qualify_finalization_worker_v6.py'
with target.open('x')as f:f.write(successor)
ast.parse(successor);compile(successor,str(target),'exec')  # unused code object
dependency=pin(Path('/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/lib/python3.12/ctypes/__init__.py'))
assert dependency['sha256']=='e048845f8f5c14a5fc873526a27da4a19d4eed25ab2f2a01fa6e0b79faca78d0'and dependency['bytes']==18268
builder=(D/'build_false_helper_plan_v1.py').read_text()
builder=builder.replace('qualify_finalization_worker_v5.py','qualify_finalization_worker_v6.py')
builder=builder.replace("decl=write(D/'helper-qualification-declaration-v1.json',declaration)","""declaration['trusted_startup_stdlib_ctypes']=pin(Path('/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/lib/python3.12/ctypes/__init__.py'))
declaration['startup_scope']='Within the charged worker startup, raw-check and import only the reviewed bundled ctypes before installing the finite audit denylist. This initializes stdlib pythonapi=PyDLL(None); it is not a project Native/Model call. Later target/fixture dlopen remains denied. Dependency source reviewed statically; no out-of-window import.'
decl=write(D/'helper-qualification-declaration-v2.json',declaration)""")
for a,b in [('actual-helper-v1','actual-helper-v2'),('finalization-helper-ROOT-20261019-v1','finalization-helper-ROOT-20261019-v2'),('authorization-false-v1.json','authorization-false-v2.json'),('plan-false-v1.json','plan-false-v2.json'),('false-helper-plan-manifest-v1.json','false-helper-plan-manifest-v2.json')]:
    builder=builder.replace(a,b)
builder_path=D/'build_false_helper_plan_v2.py'
with builder_path.open('x')as f:f.write(builder)
ast.parse(builder);compile(builder,str(builder_path),'exec')
negative=pin(C/'typed-components-Source-review-v2-negative.json')
plan_negative=pin(C/'typed-prospective-plan-review-v1-negative.json')
record=write(D/'ROOT-helper-startup-correction-v1.json',dict(schema='ROOT-helper-startup-correction-v1',
    Source_negative=negative,plan_negative=plan_negative,superseded_premature_PASS=pin(C/'typed-components-Source-review-v1.json'),
    parent_worker=pin(old),successor_worker=pin(target),trusted_startup_stdlib_ctypes=dependency,
    successor_plan_builder=pin(builder_path),Source_evaluations=0,fixture_calls=0,scientific_calls=0,
    actual_execution_authorized=False,disposition='Adopt dependency-coupling negative; previous PASS is not current. Preserve rejected Sources and false plan. Narrow explicit charged stdlib preload only, later denylist unchanged. Await exact successor Source/prospective review.'))
print(json.dumps(record,sort_keys=True));print(json.dumps(pin(target),sort_keys=True))
