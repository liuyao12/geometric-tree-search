"""Freeze a non-executable prospective helper plan from raw/AST metadata only."""
from pathlib import Path
import ast
import hashlib
import json

D=Path('/private/tmp/gcts-finalization-instrumentation-ROOT-20261019')
L=Path('/private/tmp/gcts-finalization-instrumentation-library-20261019')
C=Path('/private/tmp/gcts-finalization-instrumentation-peer-20261019')

def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def pin(p):
 b=p.read_bytes();return dict(path=str(p.resolve()),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def write(p,v):
 assert not p.exists(),p
 p.write_text(json.dumps(v,sort_keys=True,indent=2)+'\n');return pin(p)

sources=dict(worker=pin(D/'qualify_finalization_worker_v5.py'),
    harness=pin(L/'qualify_finalization_harness_v2.py'),
    driver=pin(D/'owned_evidence_receiver_driver_v6.py'),
    cold=pin(L/'owned_evidence_cold_v6.py'),
    runner=pin(D/'run_finalization_helpers_once_v3.py'),
    observer=pin(D/'observe_finalization_helpers_once_v3.py'))
tree=ast.parse(Path(sources['harness']['path']).read_bytes())
literal={}
for node in tree.body:
 if isinstance(node,ast.Assign)and len(node.targets)==1 and isinstance(node.targets[0],ast.Name)and node.targets[0].id in ('FIXTURE_NAMES','SOURCE_PINS'):
  literal[node.targets[0].id]=ast.literal_eval(node.value)
names=list(literal['FIXTURE_NAMES']);assert len(names)==len(set(names))==27
assert literal['SOURCE_PINS']=={role:sources[role]for role in ('driver','cold')}
master=pin(Path('/private/tmp/gcts-cadence-integration-ROOT-20261019/basic-tiling-algorithm-HEAD.md'))
assert master['sha256']=='ca6ee206287bf18b69f88a35d30968312499567755f347a819af4cf49743e7d4'and master['bytes']==36240
limits=dict(work_seconds=180,overall_seconds=210,memory_bytes=1073741824,
    result_bytes=134217728,expanded_bytes=134217728,stdout_bytes=4194304,stderr_bytes=4194304)
prefix_names=['initial_checkpoint','after_first_completed_group','final_checkpoint']
declaration=dict(schema='finalization-instrumentation-helper-declaration-v1',
    author_identity='/root',profile='owned-finalization-phase-instrumented-v1',
    source_only=True,actual_execution_authorized=False,full_pipeline_qualified=False,
    expected_fixture_names=names,expected_normal_checkpoint_calls=57,
    maximum_helper_qualification_calls=4,maximum_worker_invocations=1,
    expected_prefix_control_names=prefix_names,
    prefix_controls=[dict(name=prefix_names[0],checkpoint_ordinal=1,exception_type='RuntimeError',completed_fixture_count=0,active_fixture=None,stage='initial_checkpoint'),
        dict(name=prefix_names[1],checkpoint_ordinal=4,exception_type='ValueError',completed_fixture_count=1,active_fixture=names[1],stage='fixture_before_checkpoint'),
        dict(name=prefix_names[2],checkpoint_ordinal=57,exception_type='StopIteration',completed_fixture_count=27,active_fixture=None,stage='result_final_checkpoint')],
    sources=sources,master=master,limits=limits,
    helper_target_scope=['driver._OwnedFinalizationObservation','cold.new_cold_observation',
        'cold.cold_phase_begin','cold.cold_phase_end','cold.cold_phase_failure','cold.cold_count',
        'cold.cold_guard_finished','cold.cold_observation_snapshot','cold.bounded_driver_diagnostics',
        'cold.cold_failure_diagnostics'],
    forbidden_targets=['driver.run_receiver_owned','driver._owned_atomic_output','cold.main',
        'cold.verify_saved_evidence','real Arena/Store/inverse/Model/search/Native','historical proof/forest decode or replay'],
    synthetic_interfaces='Fake boundary clocks, fake actions, passive fake Store.statistics. Sole temporary module slot cold._NOW_NS, restored in finally and checked after normal and interrupted calls.',
    proof_authority=False,scientific_acceptance=False,
    clock_scope='Standalone helper-only profile: all positive work and outer full checks/known worker exit before180s; complete external terminal before210s. Observer225s is failure cleanup only. Source-entry epoch excludes observer/Python prelude. No full-pipeline timing equivalence.',
    resource_scope='Posthoc Darwin worker wait4 highwater <=1GiB; no Native. Complete ordinary helper output and physical files+9MiB outer reservations <=128MiB; each captured log<=4MiB. No continuous RSS enforcement; outer/observer RSS excluded.',
    custody_scope='Exact raw Source pins and module/code/default identities checked before/after; reviewed Source with trusted exclusive ownership. No adversarial in-memory sandbox or universal soundness proof.',
    result_scope='Finite helper diagnostic result only, including three explicitly unfinished prefix packets. No new mathematical theorem, full pipeline/callback cadence/ownership/inverse/point qualification or performance claim. Old consumed actuals remain unchanged.',
    pending='Independent complete six-Source review, prospective-plan review, Root exact max-one grant and final freshness delta. This declaration authorizes no import or call.')
decl=write(D/'helper-qualification-declaration-v1.json',declaration)
python=pin(Path('/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12'))
assert python['sha256']=='21a9986bad1dbbcd813a252b19b4263fc0755ed2dbf8632c83e5d6117a12f319'and python['bytes']==18058560
actual=D/'actual-helper-v1';assert not actual.exists()
subject=dict(schema='ROOT-finalization-helper-once-plan-v1',
    invocation_id='finalization-helper-ROOT-20261019-v1',actual_directory=str(actual),python=python,
    **sources,inputs=[],limits=limits,declaration=decl)
assert len(subject)==13
subject_sha=hashlib.sha256(canonical(subject)).hexdigest()
authorization=dict(schema='ROOT-finalization-helper-once-authorization-v1',author_identity='/root',
    actual_execution_authorized=False,maximum_actual_invocations=1,subject_sha256=subject_sha,
    review_roles=dict(Source=None,plans=None),scientific_acceptance=False,
    scope='Non-executable prospective binding only; any eventual true grant must bind both current independent review roles and this full thirteen-field subject.')
auth=write(D/'authorization-false-v1.json',authorization)
plan=dict(subject,authorization=auth);p=write(D/'plan-false-v1.json',plan)
record=dict(schema='ROOT-finalization-helper-false-plan-manifest-v1',plan=p,
    authorization=auth,declaration=decl,subject=subject,subject_sha256=subject_sha,
    sources=sources,fixture_names_AST_literal_only=True,
    Source_evaluations=0,fixture_calls=0,scientific_calls=0,actual_execution_authorized=False)
out=write(D/'false-helper-plan-manifest-v1.json',record)
print(json.dumps(out,sort_keys=True));print(json.dumps(dict(plan=p,subject_sha256=subject_sha),sort_keys=True))
