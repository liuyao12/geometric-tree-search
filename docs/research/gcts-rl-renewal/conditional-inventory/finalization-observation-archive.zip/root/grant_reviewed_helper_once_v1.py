"""Root adopts exact independent metadata scopes; no component evaluation."""
from pathlib import Path
import hashlib,json
D=Path('/private/tmp/gcts-finalization-instrumentation-ROOT-20261019')
C=Path('/private/tmp/gcts-finalization-instrumentation-peer-20261019')
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def write(name,v):
 p=D/name
 with p.open('x')as f:json.dump(v,f,sort_keys=True,indent=2,allow_nan=False);f.write('\n')
 return pin(p)
plan=json.loads((D/'plan-false-v2.json').read_bytes());subject={k:v for k,v in plan.items()if k!='authorization'}
digest=hashlib.sha256(canonical(subject)).hexdigest()
assert len(subject)==13 and digest=='cdc3b27b58d3852abf0f674f8eb0d97ce79871cba500a386b19e2ae193411965'
assert not Path(subject['actual_directory']).exists()and not (D/'plan-authorized-v1-terminal-observation').exists()
for k in ('python','worker','harness','driver','cold','runner','observer','declaration'):assert pin(plan[k]['path'])==plan[k]
assert plan['inputs']==[]
decl=json.loads(Path(plan['declaration']['path']).read_bytes())
assert pin(decl['trusted_startup_stdlib_ctypes']['path'])==decl['trusted_startup_stdlib_ctypes']
assert decl['expected_normal_checkpoint_calls']==57 and decl['maximum_helper_qualification_calls']==4
assert decl['maximum_worker_invocations']==1 and len(decl['expected_fixture_names'])==27
assert [p['checkpoint_ordinal']for p in decl['prefix_controls']]==[1,4,57]
assert pin(decl['master']['path'])==decl['master']
assert plan['limits']==decl['limits']==dict(work_seconds=180,overall_seconds=210,memory_bytes=1073741824,result_bytes=134217728,expanded_bytes=134217728,stdout_bytes=4194304,stderr_bytes=4194304)
false_auth=json.loads(Path(plan['authorization']['path']).read_bytes())
assert pin(plan['authorization']['path'])==plan['authorization']
assert false_auth['actual_execution_authorized']is False and false_auth['subject_sha256']==digest and false_auth['review_roles']==dict(Source=None,plans=None)
review_paths=dict(Source=C/'typed-components-Source-review-v3.json',plans=C/'typed-prospective-plan-review-v2.json')
expected=dict(Source=('b62e7c100be5effc60948e8453c6d590d12a1a0d8dcc0d5613671113cdee0f9b',15549),plans=('5bd127e4920553a501e96f40e1f0396e861bf2aabd03b3f99b2c3e2dd735f2a0',8273))
reviews={}
for role,path in review_paths.items():
 desc=pin(path);assert (desc['sha256'],desc['bytes'])==expected[role]
 v=json.loads(path.read_bytes());assert v['reviewer_identity']=='/root/conventional_control_review'
 assert v['source_only']is True and v['scientific_calls']==0 and v['actual_execution_authorized']is False and v['scientific_acceptance']is False
 if role=='Source':
  assert v['schema']=='finalization-instrumentation-qualification-components-Source-review-v1'and v['source_review_passed']is True
  assert v['author_identities']==['/root','/root/conventional_library']
  assert v['sources']=={k:plan[k]for k in ('worker','harness','driver','cold','runner','observer')}
  assert v['startup_stdlib']==decl['trusted_startup_stdlib_ctypes']and v['current_declaration']==plan['declaration']
 else:
  assert v['schema']=='finalization-instrumentation-qualification-prospective-plan-review-v1'and v['prospective_review_passed']is True
  assert v['subject']==subject and v['subject_sha256']==digest and v['declaration']==plan['declaration']
 reviews[role]=desc
adoption=write('ROOT-scope-adoption-v1.json',dict(schema='ROOT-finalization-helper-scope-adoption-v1',author_identity='/root',subject=subject,subject_sha256=digest,reviews=reviews,
 disposition='Adopt exact corrected six-Source/dependency and prospective-plan scopes for one helper-only qualification. Premature cdbe PASS is superseded, never adopted. Existing rejected Source/plans remain immutable.',
 role_disclosure='Root authors driver and wrappers and coordinates; Library authors cold and harness; Control reviews both Source and plan roles, with historical helper/outer algorithm authorship disclosed. No fresh independent kernel or own-code certification follows.',
 scope='27 normal finite fake-interface helper groups; three reached prefix interruptions1/4/57; four calls in one worker. Explicit charged trusted bundled ctypes startup; later denylist unchanged. Empty scientific inputs. No driver/cold main, actual inverse/Arena/Store/Model/search/Native/proof replay.',
 trust_scope='Raw pins, exact origin and shallow function/class/code/globals/default identity checks under trusted exclusive ownership. Finite audit list, not universal sandbox/runtime closure or arbitrary callback coverage.',
 limits=plan['limits'],positive_outer_checks_before_seconds=180,external_terminal_before_seconds=210,observer_failure_cleanup_seconds=225,
 scientific_acceptance=False,new_theorem=False,full_pipeline_qualified=False,goal_complete=False,
 unresolved=['Observed finite helper diagnostic result and interruption retention','Actual known exit, whole custody and resource checks','Later fresh full pipeline measurement under unchanged complete proof gates','Held-out theorem benchmarks, GCTS marking and RL contributions']))
auth=write('authorization-true-v1.json',dict(schema='ROOT-finalization-helper-once-authorization-v1',author_identity='/root',actual_execution_authorized=True,maximum_actual_invocations=1,
 subject_sha256=digest,review_roles=reviews,ROOT_scope_adoption=adoption,
 scope='Exactly one fresh helper-only worker, four maximum harness calls as declared. No unchanged retry, other component/fixture execution or production/scientific call. Final independent delta/freshness review and peer tool quiescence precede launch.'))
plan['authorization']=auth;assert {k:v for k,v in plan.items()if k!='authorization'}==subject
print(json.dumps(write('plan-authorized-v1.json',plan),sort_keys=True));print(json.dumps(auth,sort_keys=True))
