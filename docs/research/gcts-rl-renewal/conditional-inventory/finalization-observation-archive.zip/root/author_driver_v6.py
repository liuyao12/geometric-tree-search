"""Correct the independently rejected V5 Source; never evaluate components."""
from pathlib import Path
import ast
import hashlib
import json

D=Path('/private/tmp/gcts-finalization-instrumentation-ROOT-20261019')
parent=D/'owned_evidence_receiver_driver_v5.py'
out=D/'owned_evidence_receiver_driver_v6.py'
raw=parent.read_bytes()
assert len(raw)==119296 and hashlib.sha256(raw).hexdigest()=='c5e6c472056512fa08cc50cf0324175db446119e22901afe414b3f0edc3c3d54'
s=raw.decode()
prefix,tail=s.split("OWNED_VERSION=",1)
tail=tail.replace('observation.', 'finalization_observation.')
tail=tail.replace('def _owned_atomic_output(path,result,store,boundary,observation):',
                  'def _owned_atomic_output(path,result,store,boundary,finalization_observation):')
tail=tail.replace('    observation = _OwnedFinalizationObservation(boundary)',
                  '    finalization_observation = _OwnedFinalizationObservation(boundary)')
tail=tail.replace('_owned_atomic_output(output_path,result,store,boundary,observation)',
                  '_owned_atomic_output(output_path,result,store,boundary,finalization_observation)')
s=prefix+'OWNED_VERSION='+tail
a="""        except BaseException as metadata_error:
            try:error.add_note('finalization diagnostic unavailable: '+type(metadata_error).__name__)
            except BaseException:pass
    def call(self,phase,action):"""
b="""        except BaseException as metadata_error:
            # Failure of the diagnostic itself cannot recover a scientific
            # result or replace the original active exception. The marker is
            # explicitly unavailable, never a complete or truncated ledger.
            try:error.owned_finalization_observation=dict(
                schema='owned-finalization-observation-unavailable-v1',
                profile=OWNED_FINALIZATION_PROFILE,authority=False,
                mathematical_authority=False,resource_authority=False,
                status='UNAVAILABLE',metadata_error_type=type(metadata_error).__name__,
                phase_count=len(self._phases),snapshot_count=len(self._snapshots),
                complete_ledger_retained=False)
            except BaseException:pass
            try:error.add_note('finalization diagnostic unavailable: '+type(metadata_error).__name__)
            except BaseException:pass
    def call(self,phase,action):"""
assert s.count(a)==1
s=s.replace(a,b,1)
before,owned=s.split('def run_receiver_owned(',1)
else_marker='''    else:
        closure_started = boundary.observe()
'''
assert owned.count(else_marker)==1
lead,final=owned.split(else_marker,1)
final='        closure_started = boundary.observe()\n'+final
assert final.endswith("                    transport_receipt=result.get('transport_receipt'))\n")
indented=''.join('    '+line if line.strip() else line for line in final.splitlines(keepends=True))
owned=lead+'    else:\n        try:\n'+indented+'''        except BaseException as primary:
            # Attachment only: no scientific cleanup, oracle close, validation
            # or phase action is repeated on this path.
            finalization_observation.attach(primary)
            raise
'''
s=before+'def run_receiver_owned('+owned
assert s.count("observation = stage('essential_ancestry'")==2
assert s.count('    finalization_observation = _OwnedFinalizationObservation(boundary)')==1
assert 'observation.attach(' not in s.replace('finalization_observation.attach(', '')
compile(s,str(out),'exec')  # Unused code object only.
out.write_text(s)
def pin(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
tree5=ast.parse(raw.decode());tree6=ast.parse(s)
defs=lambda tree:{node.name:ast.dump(node,include_attributes=False) for node in tree.body if isinstance(node,(ast.FunctionDef,ast.ClassDef))}
d5,d6=defs(tree5),defs(tree6)
changed=[name for name in d5 if d5[name]!=d6[name]]
assert changed==['_OwnedFinalizationObservation','_owned_atomic_output','run_receiver_owned'],changed
legacy=Path('/private/tmp/gcts-owned-evidence-integration-ROOT-20261019/owned_evidence_receiver_driver_v4.py')
assert s.split("OWNED_VERSION=",1)[0]==legacy.read_text().split("OWNED_VERSION=",1)[0]
v=dict(schema='owned-finalization-driver-Source-correction-v1',rejected_parent=pin(parent),successor=pin(out),
      changed_definitions_from_rejected_v5=changed,historical_prefix_exact=True,
      fixes=['Unique ledger name cannot collide with the unchanged proof-observation variable.',
             'Attachment-only catch covers all post-scientific finalization and receipt seams without retry/cleanup calls.',
             'If full diagnostic serialization fails, only a small UNAVAILABLE nonauthority marker is attempted; the active original exception remains.'],
      no_new_evaluation_or_replay=True,scientific_calls=0,module_imports=0,unused_compilations=1,
      limitations=['No runtime qualification. Additional clock/statistics work is not free; no time fit or performance claim.',
                   'Complete diagnostics can be unavailable on metadata/record cap failure; marker counts are diagnostic only.'])
p=D/'driver-Source-correction-v1.json';p.write_text(json.dumps(v,sort_keys=True,indent=2)+'\n')
print(json.dumps(v,sort_keys=True,indent=2))
