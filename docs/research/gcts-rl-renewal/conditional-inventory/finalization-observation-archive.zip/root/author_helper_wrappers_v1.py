"""Raw bounded-wrapper Source derivation. No component calls or imports."""
from pathlib import Path
import hashlib
import json

D=Path('/private/tmp/gcts-finalization-instrumentation-ROOT-20261019')
OLD=Path('/private/tmp/gcts-inverse-cadence-ROOT-20261019')
s=(OLD/'run_inverse_once_v3.py').read_text()
def replace(a,b):
 global s
 assert s.count(a)==1,a[:160]
 s=s.replace(a,b,1)
replace('Exactly one inverse qualification worker; unchanged global gates, no proof runtime.',
        'Exactly one finite instrumentation-helper worker; unchanged global numeric gates, no proof runtime.')
s=s.replace("VERSION='inverse-cadence-once-runner-v3'", "VERSION='finalization-instrumentation-once-runner-v1'")
s=s.replace("'inverse'", "'driver'").replace("'reference'", "'cold'")
s=s.replace('ROOT-inverse-cadence-once-plan-v1','ROOT-finalization-helper-once-plan-v1')
s=s.replace('ROOT-inverse-cadence-once-authorization-v1','ROOT-finalization-helper-once-authorization-v1')
s=s.replace('inverse-cadence-qualification-components-Source-review-v1','finalization-instrumentation-qualification-components-Source-review-v1')
s=s.replace('inverse-cadence-qualification-prospective-plan-review-v1','finalization-instrumentation-qualification-prospective-plan-review-v1')
s=s.replace('inverse-cadence-consumed-v1','finalization-instrumentation-consumed-v1')
s=s.replace('inverse-cadence-once-receipt-v1','finalization-instrumentation-once-receipt-v1')
s=s.replace('inverse-cadence-qualification-worker-receipt-v3','finalization-instrumentation-qualification-worker-receipt-v1')
s=s.replace('inverse-cadence-qualification-result-v1','finalization-instrumentation-qualification-result-v1')
s=s.replace('representation_candidate','instrumentation_candidate').replace('representation_qualification_candidate','instrumentation_qualification_candidate')
a="""    need(type(plan['inputs'])is list and len(plan['inputs'])==2,'complete frozen two-input set')
    need([r['mode']for r in plan['inputs']]==['fixed','symbolic'],'whole artifact order')
    for r in plan['inputs']:
        need(set(r)=={'mode','forest','result'},'input scope')
        checked(r['forest']);checked(r['result'])
    need(sum(r['result']['bytes']for r in plan['inputs'])<=LIMITS['expanded_bytes'],'aggregate logical original cap')"""
b="""    need(type(plan['inputs'])is list and plan['inputs']==[],
         'no historical artifacts, proof data or scientific fixtures in helper qualification')"""
replace(a,b)
a="""        need(q['status']=='FINITE_REPRESENTATION_QUALIFIED'and len(q['whole_inputs'])==2,'complete retained candidate')
        need([r['mode']for r in q['whole_inputs']]==['fixed','symbolic'],'two whole input order')"""
b="""        need(q['schema']=='finalization-instrumentation-helper-qualification-v1'and
             q['status']=='FINITE_INSTRUMENTATION_HELPERS_QUALIFIED'and
             q['full_pipeline_qualified']is False and q['authority']is False,
             'finite helper-only candidate; no full pipeline authority')"""
replace(a,b)
replace("        need(sum(r['reconstructed_complete_file_bytes']for r in q['whole_inputs'])==sum(r['result']['bytes']for r in plan['inputs'])==w['logical_result_bytes']<=LIMITS['expanded_bytes'],'full expanded logical ledger')",
        "        need(w['logical_result_bytes']==w['result']['bytes']<=LIMITS['expanded_bytes'],'complete ordinary helper-result logical ledger')")
replace("        for r in plan['inputs']:checked(r['forest']);checked(r['result'])\n",'')
replace("logical_result_bytes=sum(r['reconstructed_complete_file_bytes']for r in q['whole_inputs'])", "logical_result_bytes=w['logical_result_bytes']")
compile(s,str(D/'run_finalization_helpers_once_v1.py'),'exec')
(D/'run_finalization_helpers_once_v1.py').write_text(s)
rs=(OLD/'observe_inverse_once_v3.py').read_text()
rs=rs.replace('inverse-cadence-final-terminal-observer-v3','finalization-instrumentation-final-terminal-observer-v1')
rs=rs.replace('ROOT-inverse-cadence-once-plan-v1','ROOT-finalization-helper-once-plan-v1')
rs=rs.replace('adaptive-group-final-terminal-observation-v1','finalization-instrumentation-final-terminal-observation-v1')
rs=rs.replace('representation_candidate','instrumentation_candidate')
rs=rs.replace('ea37fe7513227faf556fa5000046a964b89b7d5fd6fd22a6262ba43efd39152e',hashlib.sha256(s.encode()).hexdigest())
rs=rs.replace('Standalone inverse-only final outer terminal/group/regular-log gate.', 'Standalone finite instrumentation-helper final outer terminal/group/regular-log gate.')
compile(rs,str(D/'observe_finalization_helpers_once_v1.py'),'exec')
(D/'observe_finalization_helpers_once_v1.py').write_text(rs)
def pin(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
v=dict(schema='finalization-helper-outer-authoring-v1',parents=[pin(OLD/'run_inverse_once_v3.py'),pin(OLD/'observe_inverse_once_v3.py')],
    sources=[pin(D/'run_finalization_helpers_once_v1.py'),pin(D/'observe_finalization_helpers_once_v1.py')],
    only_new_scope='Finite new metadata helpers with fake clock/action/passive Store; no proof/Model/search/inverse/Native or historical inputs.',
    caps_and_consumption_and_process_lifecycle_inherited=True,
    clock_scope='Standalone helper profile retains positive known worker exit and all outer positive checks before180s; final terminal before210s; observer225s failure-only. This is stronger than the full-pipeline outer210s profile.',
    operation_or_callback_cadence_qualification=False,scientific_calls=0,module_imports=0,unused_compilations=2,
    execution_authorized=False,remaining='Independent Source/plan reviews and true once grant; worker and harness not yet bound in any executable plan.')
p=D/'helper-outer-Source-authoring-v1.json';p.write_text(json.dumps(v,sort_keys=True,indent=2)+'\n');print(json.dumps(v,sort_keys=True,indent=2))
