"""Finite helper-only qualification; authored without importing or calling targets.

Only a separately reviewed once-worker may call qualify. Fake boundary clocks,
actions and passive statistics replace the external interfaces. This does not
exercise a proof pipeline, an inverse, an Arena, a callback schedule, or search.
The sole temporary target-module assignment is cold._NOW_NS, restored in finally.
No target code object, default, class, constant or other callable is changed.
"""
import json

VERSION = 'finalization-instrumentation-helper-qualification-source-v1'
RESULT_SCHEMA = 'finalization-instrumentation-helper-qualification-v1'
RESULT_BYTES = 131072
PROFILE = 'owned-finalization-phase-instrumented-v1'
FIXTURE_NAMES = (
    'driver_normal_call_and_detached_record',
    'driver_nested_phase_intervals',
    'driver_action_foreign_exception_identity',
    'driver_entry_clock_foreign_exception_identity',
    'driver_return_clock_error_after_action',
    'driver_failure_clock_preserves_primary_error',
    'driver_passive_snapshot_detachment',
    'driver_snapshot_foreign_exception_identity',
    'driver_declared_names_refuse_unknown',
    'driver_sixteen_phase_cap',
    'driver_eight_snapshot_cap',
    'driver_eight_KiB_snapshot_cap',
    'driver_sixtyfour_KiB_record_and_unavailable_marker',
    'driver_complete_record_detachment',
    'cold_nested_open_and_returned_phases',
    'cold_thirtytwo_row_and_unknown_name_limits',
    'cold_counter_guard_timing_snapshot_cutoff',
    'cold_clock_faults_are_best_effort',
    'cold_twohundredfiftysix_KiB_observation_cap',
    'cold_late_failure_retains_driver_receipt_and_statistics',
    'cold_error_attributes_retained_without_receipt',
    'cold_malformed_or_oversized_driver_metadata_fallback',
    'cold_malformed_observation_metadata_fallback',
    'cold_active_error_identity_with_both_fallbacks',
    'cold_malformed_phase_and_counter_best_effort',
    'cold_driver_unavailable_marker_remains_unavailable',
    'cold_failure_clock_cannot_replace_active_error',
)
SOURCE_PINS = {
    'driver': {
        'path': '/private/tmp/gcts-finalization-instrumentation-ROOT-20261019/owned_evidence_receiver_driver_v6.py',
        'sha256': 'e8ff0690472140e510f8ffab383be8c22791da6b27ef0a27fda013ea48e5f5cf',
        'bytes': 120766},
    'cold': {
        'path': '/private/tmp/gcts-finalization-instrumentation-library-20261019/owned_evidence_cold_v6.py',
        'sha256': 'e1101723f559ae2dfecc030470a3e6e9e79c71b10c416c2bcdfc8f2f5b101d43',
        'bytes': 72712},
}


class QualificationFailure(AssertionError):
    pass


def _need(condition, message):
    if not condition:
        raise QualificationFailure(message)


def _canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=False, allow_nan=False).encode('utf8')


def _raise(error):
    raise error


def _exact(action, error):
    try:
        action()
    except BaseException as observed:
        if observed is not error:
            raise
        return observed
    raise QualificationFailure('expected the exact foreign exception object')


def _own(action, expected_type):
    try:
        action()
    except BaseException as observed:
        if type(observed) is not expected_type:
            raise
        return type(observed).__name__
    raise QualificationFailure('expected the declared own metadata refusal')


class _Boundary:
    def __init__(self, faults=None):
        self.calls = 0
        self.faults = {} if faults is None else dict(faults)

    def observe(self):
        self.calls += 1
        if self.calls in self.faults:
            raise self.faults[self.calls]
        return float(self.calls)


class _PassiveStore:
    def __init__(self, value, error=None):
        self.value = value
        self.error = error
        self.calls = 0

    def statistics(self):
        self.calls += 1
        if self.error is not None:
            raise self.error
        return self.value


class _Clock:
    def __init__(self, value=1000, error=None):
        self.value = value
        self.error = error
        self.calls = 0

    def __call__(self):
        self.calls += 1
        if self.error is not None:
            raise self.error
        return self.value


def qualify(driver, cold, checkpoint):
    """Run finite metadata-helper cases inside the caller's charged once-window.

    Authentication, import custody, absolute deadline, worker RSS and output/log
    limits belong to the reviewed outer worker. checkpoint is invoked before and
    after every group and is never caught. No proof success can be returned here.
    Fake clock values are diagnostic fixtures, never runtime measurements.
    """
    checkpoint()
    _need(driver.OWNED_VERSION == 'semantic-family-owned-evidence-driver-v2-instrumented',
          'current instrumented driver ABI')
    _need(cold.VERSION == 'owned-evidence-intake-cold-v6-instrumented', 'current cold ABI')
    _need(driver.OWNED_FINALIZATION_PROFILE == cold.FINALIZATION_PROFILE == PROFILE,
          'exact shared observation profile')
    _need(driver.OWNED_FINALIZATION_BYTES == 65536 and cold.COLD_OBSERVATION_BYTES == 262144,
          'original metadata caps')
    original_clock = cold._NOW_NS
    diagnostics = []
    retained = {}

    def run(name, action):
        _need(name == FIXTURE_NAMES[len(diagnostics)], 'exact declared case order')
        checkpoint()
        details = action()
        _need(type(details) is dict, 'ordinary details')
        checkpoint()
        diagnostics.append(dict(name=name, status='passed', mathematical_authority=False,
                                details=details))

    def observation(boundary=None):
        return driver._OwnedFinalizationObservation(_Boundary() if boundary is None else boundary)

    def clock(value=1000, error=None):
        fake = _Clock(value, error)
        cold._NOW_NS = fake
        return fake

    def driver_normal():
        boundary = _Boundary()
        obj = observation(boundary)
        token = object()
        _need(obj.call('oracle_close', lambda: token) is token, 'action result identity')
        first = obj.record()
        row = first['phases'][0]
        _need(row['action_returned'] is True and row['completed'] is True and
              row['started_monotonic'] == 1.0 and row['returned_monotonic'] == 2.0,
              'normal reached action and both clock points')
        first['phases'][0]['phase'] = 'caller mutation'
        _need(obj.record()['phases'][0]['phase'] == 'oracle_close', 'record detachment')
        return dict(targets=['call', 'record'], clock_calls=boundary.calls, action_calls=1)

    def driver_nested():
        obj = observation()
        token = object()
        _need(obj.call('final_assemble', lambda: obj.call('final_seal', lambda: token)) is token,
              'nested action returned')
        rows = obj.record()['phases']
        _need([r['phase'] for r in rows] == ['final_assemble', 'final_seal'] and
              all(r['completed'] is True for r in rows) and
              rows[0]['started_monotonic'] < rows[1]['started_monotonic'] <
              rows[1]['returned_monotonic'] < rows[0]['returned_monotonic'],
              'nested intervals observed; they overlap')
        return dict(targets=['call', 'record'], rows=2, overlapping_intervals=True,
                    disjoint_cost_sum_asserted=False)

    def driver_action_errors():
        reached = []
        for cls in (RuntimeError, ValueError, StopIteration):
            error = cls('foreign action')
            obj = observation()
            _exact(lambda: obj.call('final_wire', lambda: _raise(error)), error)
            record = error.owned_finalization_observation
            row = record['phases'][0]
            _need(row['action_returned'] is False and row['completed'] is False and
                  row['error_type'] == cls.__name__ and record['completed'] is False,
                  'active action error retained without completion')
            reached.append(cls.__name__)
        return dict(targets=['call', 'attach'], exact_error_classes=reached)

    def driver_entry_errors():
        reached = []
        for cls in (RuntimeError, ValueError, StopIteration):
            error = cls('foreign initial clock')
            boundary = _Boundary({1: error})
            obj = observation(boundary)
            calls = []
            _exact(lambda: obj.call('final_seal', lambda: calls.append('action')), error)
            row = error.owned_finalization_observation['phases'][0]
            _need(calls == [] and row['started_monotonic'] is None and
                  row['action_returned'] is False, 'action not entered')
            reached.append(cls.__name__)
        return dict(targets=['call', 'attach'], checkpoint='initial observe', exact_error_classes=reached)

    def driver_return_error():
        reached = []
        for cls in (RuntimeError, ValueError, StopIteration):
            error = cls('foreign returned clock')
            obj = observation(_Boundary({2: error}))
            calls = []
            _exact(lambda: obj.call('final_wire', lambda: calls.append('returned')), error)
            row = error.owned_finalization_observation['phases'][0]
            _need(calls == ['returned'] and row['action_returned'] is True and
                  row['completed'] is False and row['returned_monotonic'] is None,
                  'returned action distinguished from complete observation')
            reached.append(cls.__name__)
        return dict(targets=['call', 'attach'], checkpoint='post action observe', exact_error_classes=reached)

    def driver_failure_clock():
        reached = []
        for cls in (RuntimeError, ValueError, StopIteration):
            primary = cls('active action')
            metadata = StopIteration('secondary diagnostic clock')
            obj = observation(_Boundary({2: metadata}))
            _exact(lambda: obj.call('forest_atomic_write', lambda: _raise(primary)), primary)
            row = primary.owned_finalization_observation['phases'][0]
            _need(row['error_type'] == cls.__name__ and
                  row['failure_observed_monotonic'] is None and
                  row['failure_clock_error_type'] == 'StopIteration', 'secondary error only metadata')
            reached.append(cls.__name__)
        return dict(targets=['call', 'attach'], exact_primary_classes=reached,
                    failure_clock_error='StopIteration')

    def driver_snapshot():
        value = {'nested': {'count': 7}}
        store = _PassiveStore(value)
        obj = observation()
        obj.snapshot('before_final_assemble', store)
        value['nested']['count'] = 99
        record = obj.record()
        _need(store.calls == 1 and record['passive_statistics'][0]['statistics']['nested']['count'] == 7,
              'snapshot copied passive Store value')
        record['passive_statistics'][0]['statistics']['nested']['count'] = 100
        _need(obj.record()['passive_statistics'][0]['statistics']['nested']['count'] == 7,
              'returned record also detached')
        return dict(targets=['snapshot', 'record'], passive_statistics_calls=1,
                    storage_operations_calls=0)

    def driver_snapshot_errors():
        reached = []
        for cls in (RuntimeError, ValueError, StopIteration):
            for site in ('clock', 'statistics'):
                error = cls('foreign snapshot')
                boundary = _Boundary({1: error}) if site == 'clock' else _Boundary()
                store = _PassiveStore({}, error if site == 'statistics' else None)
                obj = observation(boundary)
                _exact(lambda: obj.snapshot('after_final_wire', store), error)
                _need(obj.record()['passive_statistics'] == [], 'no snapshot published on failure')
                reached.append(cls.__name__ + ':' + site)
        return dict(targets=['snapshot', 'record'], reached_fault_sites=reached)

    def driver_names():
        obj = observation()
        _own(lambda: obj.call('undeclared phase', lambda: None), driver.DriverDataError)
        store = _PassiveStore({})
        _own(lambda: obj.snapshot('undeclared snapshot', store), driver.DriverDataError)
        record = obj.record()
        _need(record['phases'] == record['passive_statistics'] == [] and store.calls == 0,
              'unknown names rejected before action/statistics')
        return dict(targets=['call', 'snapshot'], refused_names=2)

    def driver_phase_cap():
        obj = observation()
        for unused in range(16):
            obj.call('oracle_close', lambda: None)
        _own(lambda: obj.call('oracle_close', lambda: _raise(AssertionError('must not run'))),
             driver.DriverDataError)
        _need(len(obj.record()['phases']) == 16, 'no seventeenth row')
        return dict(targets=['call'], accepted_rows=16, refused_row=17)

    def driver_snapshot_cap():
        obj = observation()
        store = _PassiveStore({})
        for unused in range(8):
            obj.snapshot('after_final_seal', store)
        _own(lambda: obj.snapshot('after_final_seal', store), driver.DriverDataError)
        _need(len(obj.record()['passive_statistics']) == 8 and store.calls == 8, 'ninth not observed')
        return dict(targets=['snapshot'], accepted_snapshots=8, refused_snapshot=9)

    def driver_snapshot_bytes():
        obj = observation()
        _own(lambda: obj.snapshot('after_final_seal', _PassiveStore({'blob': 'x' * 8192})),
             driver.DriverDataError)
        _need(obj.record()['passive_statistics'] == [], 'oversized snapshot not appended')
        return dict(targets=['snapshot'], cap_bytes=8192, refused_payload_string_bytes=8192)

    def driver_record_cap():
        boundary = _Boundary()
        obj = observation(boundary)
        for unused in range(8):
            row = dict(label='before_final_assemble', observed_monotonic=float(boundary.calls + 1),
                       statistics={'blob': ''})
            payload = 'x' * (8192 - len(_canonical(row)))
            row['statistics']['blob'] = payload
            _need(len(_canonical(row)) == 8192, 'bounded exact eight KiB fixture row')
            obj.snapshot('before_final_assemble', _PassiveStore({'blob': payload}))
        _own(obj.record, driver.DriverDataError)
        primary = RuntimeError('active error with oversized diagnostic')
        _exact(lambda: obj.call('final_wire', lambda: _raise(primary)), primary)
        marker = primary.owned_finalization_observation
        _need(marker['schema'] == 'owned-finalization-observation-unavailable-v1' and
              marker['status'] == 'UNAVAILABLE' and marker['authority'] is False and
              marker['complete_ledger_retained'] is False and marker['snapshot_count'] == 8 and
              marker['phase_count'] == 1, 'unavailable marker instead of truncated complete record')
        retained['unavailable'] = json.loads(_canonical(marker))
        return dict(targets=['snapshot', 'record', 'call', 'attach'], snapshot_rows=8,
                    each_snapshot_bytes=8192, record_cap_bytes=65536,
                    exact_primary_identity=True, marker=marker)

    def driver_complete():
        obj = observation()
        obj.call('final_full_boundary_check', lambda: None)
        result = obj.complete()
        _need(result['completed'] is True and result['authority'] is False, 'normal complete diagnostic only')
        result['phases'].clear()
        _need(len(obj.record()['phases']) == 1, 'complete return detached')
        retained['driver_complete'] = obj.record()
        return dict(targets=['complete', 'record'], scientific_authority=False)

    def cold_nested():
        clock()
        obs = cold.new_cold_observation()
        cold.cold_phase_begin(obs, 'driver_run', 10)
        cold.cold_phase_begin(obs, 'driver_return_custody', 11)
        cold.cold_phase_end(obs, 'driver_return_custody', 12)
        cold.cold_phase_begin(obs, 'independent_prepare', 13)
        primary = RuntimeError('late metadata-only failure')
        cold.cold_phase_failure(obs, primary)
        rows = cold.cold_observation_snapshot(obs)['phases']
        _need([r['state'] for r in rows] == ['OPEN_AT_FAILURE', 'RETURNED', 'OPEN_AT_FAILURE'] and
              rows[1]['returned_ns'] == 12 and rows[1]['error_type'] is None and
              rows[0]['returned_ns'] is None and rows[2]['returned_ns'] is None,
              'returned and still-open phases distinct')
        _need(len(rows) == 3 and 'overlap' in obs['scope'], 'no fabricated unstarted phases')
        return dict(targets=['new_cold_observation', 'cold_phase_begin', 'cold_phase_end',
                             'cold_phase_failure', 'cold_observation_snapshot'],
                    returned_rows=1, open_at_failure_rows=2, unstarted_rows_fabricated=0,
                    intervals_may_overlap=True)

    def cold_rows():
        clock()
        obs = cold.new_cold_observation()
        for i in range(32):
            cold.cold_phase_begin(obs, 'driver_run', i)
        cold.cold_phase_begin(obs, 'driver_run', 33)
        _need(len(obs['phases']) == 32 and obs['truncated'] is True, 'finite row refusal')
        other = cold.new_cold_observation()
        cold.cold_phase_begin(other, 'unknown', 1)
        _need(other['truncated'] is True and other['phases'] == [], 'unknown name not represented')
        return dict(targets=['cold_phase_begin'], retained_rows=32, refused_row=33,
                    unknown_name_refused=True)

    def cold_counts():
        clock(1000)
        obs = cold.new_cold_observation()
        for unused in range(2):
            cold.cold_count(obs, 'overall_tick_invocations')
            cold.cold_count(obs, 'source_guard_invocations')
        cold.cold_guard_finished(obs, 900, False)
        cold.cold_guard_finished(obs, 800, True)
        snap = cold.cold_observation_snapshot(obs)
        _need(snap['counts'] == dict(overall_tick_invocations=2, source_guard_invocations=2,
              source_guard_completed=1, source_guard_failed=1, source_guard_timed_intervals=2,
              source_guard_elapsed_ns=300), 'exact fake aggregate counters')
        cold.cold_count(obs, 'overall_tick_invocations')
        cold.cold_phase_begin(obs, 'final_result_checks', 1001)
        _need(snap['counts']['overall_tick_invocations'] == 2 and snap['phases'] == [] and
              snap['snapshot_cutoff_ns'] == 1000 and 'Excludes later' in snap['snapshot_scope'],
              'cutoff and detachment explicit')
        snap['counts']['source_guard_invocations'] = 100
        _need(obs['counts']['source_guard_invocations'] == 2, 'snapshot cannot mutate live metadata')
        before = obs['counts']['source_guard_timed_intervals']
        cold.cold_guard_finished(obs, 1100, False)
        _need(obs['counts']['source_guard_timed_intervals'] == before and obs['diagnostic_errors'] >= 1,
              'negative elapsed interval not fabricated')
        return dict(targets=['cold_count', 'cold_guard_finished', 'cold_observation_snapshot'],
                    aggregate_counters_only=True, fake_elapsed_ns=300,
                    callback_origin_categories_measured=False, later_work_excluded=True,
                    overlapping_intervals_not_summed_as_disjoint=True)

    def cold_clock_errors():
        reached = []
        for cls in (RuntimeError, ValueError, StopIteration):
            error = cls('cold diagnostic clock')
            clock(error=error)
            obs = cold.new_cold_observation()
            cold.cold_phase_begin(obs, 'driver_run')
            cold.cold_phase_end(obs, 'driver_run')
            snap = cold.cold_observation_snapshot(obs)
            _need(snap['snapshot_cutoff_ns'] is None and obs['diagnostic_errors'] == 3 and
                  snap['phases'][0]['started_ns'] is None and snap['phases'][0]['returned_ns'] is None,
                  'clock unavailable is explicit metadata')
            reached.append(cls.__name__)
        for bad in (True, -1, 'not an integer'):
            clock(bad)
            obs = cold.new_cold_observation()
            _need(cold.cold_observation_snapshot(obs)['snapshot_cutoff_ns'] is None and
                  obs['diagnostic_errors'] == 1, 'strict diagnostic ns domain')
        return dict(targets=['cold_phase_begin', 'cold_phase_end', 'cold_observation_snapshot'],
                    intentionally_suppressed_diagnostic_classes=reached, invalid_clock_values=3)

    def cold_bytes():
        clock()
        obs = cold.new_cold_observation()
        obs['inverse_statistics'] = {'padding': 'x' * 262144}
        _own(lambda: cold.cold_observation_snapshot(obs), cold.ColdError)
        returned = cold.cold_failure_diagnostics(obs, None, RuntimeError('active'))
        _need(returned['cold_observation']['status'] == 'UNAVAILABLE' and
              returned['cold_observation']['complete_ledger_retained'] is False,
              'cap fallback never a complete ledger')
        return dict(targets=['cold_observation_snapshot', 'cold_failure_diagnostics'], cap_bytes=262144)

    def cold_late():
        clock()
        receipt = dict(finalization_observation=retained['driver_complete'],
                       evidence_statistics={'attempted': 77, 'nested': [1, 2]}, output={'complete': True})
        obs = cold.new_cold_observation()
        cold.cold_phase_begin(obs, 'independent_prepare', 1)
        primary = ValueError('later inverse stand-in; inverse is never called')
        cold.cold_phase_failure(obs, primary)
        output = cold.cold_failure_diagnostics(obs, receipt, primary)
        _need(_canonical(output['driver']['driver_output_receipt']) == _canonical(receipt) and
              output['driver']['evidence_statistics']['attempted'] == 77 and
              output['driver']['finalization_observation']['completed'] is True,
              'completed driver packet survives later failure')
        receipt['evidence_statistics']['nested'].append(99)
        _need(output['driver']['evidence_statistics']['nested'] == [1, 2], 'late retention detached')
        output['driver']['driver_output_receipt']['output']['complete'] = False
        _need(receipt['output']['complete'] is True, 'returned retention cannot mutate receipt')
        return dict(targets=['cold_phase_failure', 'bounded_driver_diagnostics', 'cold_failure_diagnostics'],
                    retained_complete_driver_receipt=True, later_failure_rescued=False)

    def cold_attrs():
        clock()
        error = RuntimeError('before driver return')
        error.owned_finalization_observation = retained['driver_complete']
        error.owned_evidence_statistics = {'attempted': 9}
        output = cold.bounded_driver_diagnostics(None, error)
        _need(output['driver_output_receipt'] is None and
              output['evidence_statistics'] == {'attempted': 9}, 'exact attributes without fabricated receipt')
        error.owned_evidence_statistics['attempted'] = 10
        _need(output['evidence_statistics']['attempted'] == 9, 'attribute snapshot detached')
        return dict(targets=['bounded_driver_diagnostics'], driver_receipt_fabricated=False)

    def cold_bad_driver():
        clock()
        markers = []
        for receipt in (42, {'bad': object()}, {'padding': 'x' * 262144}):
            output = cold.cold_failure_diagnostics(cold.new_cold_observation(), receipt, RuntimeError('active'))
            marker = output['driver']['finalization_observation']
            _need(marker['status'] == 'UNAVAILABLE' and marker['complete_ledger_retained'] is False and
                  output['driver']['driver_output_receipt'] is None,
                  'malformed/oversized driver metadata not promoted')
            markers.append(marker['metadata_error_type'])
        return dict(targets=['bounded_driver_diagnostics', 'cold_failure_diagnostics'], cases=3,
                    metadata_error_types=markers)

    def cold_bad_observation():
        clock()
        markers = []
        for obs in (None, {'phases': [object()]}):
            output = cold.cold_failure_diagnostics(obs, None, RuntimeError('active'))
            marker = output['cold_observation']
            _need(marker['status'] == 'UNAVAILABLE' and marker['authority'] is False and
                  marker['complete_ledger_retained'] is False, 'malformed cold metadata unavailable')
            markers.append(marker['metadata_error_type'])
        return dict(targets=['cold_failure_diagnostics'], cases=2, metadata_error_types=markers)

    def cold_active_both():
        clock()
        reached = []
        for cls in (RuntimeError, ValueError, StopIteration):
            primary = cls('active error with malformed metadata')
            def action():
                try:
                    raise primary
                except BaseException as active:
                    output = cold.cold_failure_diagnostics(None, 42, active)
                    _need(output['driver']['finalization_observation']['status'] == 'UNAVAILABLE' and
                          output['cold_observation']['status'] == 'UNAVAILABLE', 'both fallbacks reached')
                    raise
            _exact(action, primary)
            reached.append(cls.__name__)
        return dict(targets=['cold_failure_diagnostics'], exact_active_error_classes=reached)

    def cold_bad_counts():
        clock()
        obs = cold.new_cold_observation()
        cold.cold_count(obs, 'undeclared counter')
        cold.cold_phase_end(obs, 'driver_run')
        cold.cold_phase_begin({'phases': None, 'diagnostic_errors': 0}, 'driver_run', 1)
        cold.cold_count(None, 'overall_tick_invocations')
        cold.cold_guard_finished(None, 1, False)
        cold.cold_phase_begin(None, 'driver_run')
        cold.cold_phase_end(None, 'driver_run')
        cold.cold_phase_failure(None, RuntimeError('active'))
        _need(obs['diagnostic_errors'] == 2 and obs['counts']['overall_tick_invocations'] == 0,
              'unknown counter/missing phase do not invent values')
        return dict(targets=['cold_count', 'cold_phase_begin', 'cold_phase_end',
                             'cold_guard_finished', 'cold_phase_failure'],
                    explicit_diagnostic_errors=2, absent_metadata_best_effort=True)

    def cold_marker():
        clock()
        marker = retained['unavailable']
        output = cold.bounded_driver_diagnostics({'finalization_observation': marker,
                                                 'evidence_statistics': None})
        _need(_canonical(output['finalization_observation']) == _canonical(marker) and
              output['finalization_observation']['complete_ledger_retained'] is False and
              output['finalization_observation']['status'] == 'UNAVAILABLE',
              'unavailable marker retained literally, never relabeled complete')
        return dict(targets=['bounded_driver_diagnostics'], unavailable_marker_preserved=True,
                    normal_pipeline_acceptance_tested=False)

    def cold_failure_clock():
        reached = []
        for cls in (RuntimeError, ValueError, StopIteration):
            primary = cls('active error')
            clock(error=StopIteration('diagnostic clock only'))
            obs = cold.new_cold_observation()
            cold.cold_phase_begin(obs, 'driver_run', 1)
            def action():
                try:
                    raise primary
                except BaseException as active:
                    cold.cold_phase_failure(obs, active)
                    output = cold.cold_failure_diagnostics(obs, None, active)
                    row = output['cold_observation']['phases'][0]
                    _need(row['state'] == 'OPEN_AT_FAILURE' and row['opened_at_failure_ns'] is None and
                          output['cold_observation']['snapshot_cutoff_ns'] is None,
                          'unavailable diagnostic clocks not substituted for primary failure')
                    raise
            _exact(action, primary)
            reached.append(cls.__name__)
        return dict(targets=['cold_phase_failure', 'cold_failure_diagnostics'],
                    exact_active_error_classes=reached, diagnostic_clock='StopIteration')

    cases = (
        driver_normal, driver_nested, driver_action_errors, driver_entry_errors,
        driver_return_error, driver_failure_clock, driver_snapshot,
        driver_snapshot_errors, driver_names, driver_phase_cap, driver_snapshot_cap,
        driver_snapshot_bytes, driver_record_cap, driver_complete, cold_nested,
        cold_rows, cold_counts, cold_clock_errors, cold_bytes, cold_late,
        cold_attrs, cold_bad_driver, cold_bad_observation, cold_active_both,
        cold_bad_counts, cold_marker, cold_failure_clock)
    try:
        _need(len(cases) == len(FIXTURE_NAMES) == 27, 'exact finite declared group count')
        for name, action in zip(FIXTURE_NAMES, cases):
            run(name, action)
    finally:
        cold._NOW_NS = original_clock
    _need(cold._NOW_NS is original_clock, 'sole mock slot restored exactly')
    checkpoint()
    result = dict(schema=RESULT_SCHEMA, status='FINITE_INSTRUMENTATION_HELPERS_QUALIFIED',
        authority=False, mathematical_authority=False, resource_authority=False,
        full_pipeline_qualified=False, diagnostics=diagnostics,
        expected_fixture_names=list(FIXTURE_NAMES), source_pins=json.loads(_canonical(SOURCE_PINS)),
        mock_slot=dict(name='cold._NOW_NS', restored=True,
                       code_defaults_or_callable_body_mutations=False),
        limits=dict(fixture_groups=27, driver_phase_rows=16, driver_snapshots=8,
                    driver_snapshot_bytes=8192, driver_record_bytes=65536,
                    cold_phase_rows=32, cold_metadata_bytes=262144, result_bytes=RESULT_BYTES),
        limitations=[
            'Finite fake-boundary/passive-statistics helper checks only; Source authentication is outer-worker responsibility.',
            'No run_receiver_owned, _owned_atomic_output, cold main, saved-evidence verifier, real Store/Arena/inverse/Model/search/Native call.',
            'No full-pipeline retention, resource fit, real clock/callback cadence, proof validity or speed qualification.',
            'Cold best-effort metadata helpers are not general metadata-schema validators.',
            'All fake timing intervals are synthetic and overlapping phases are not additive costs.',
            'Clock restoration on externally interrupted failure is a finally obligation additionally checked by the outer worker.'])
    _need(len(_canonical(result)) <= RESULT_BYTES, 'bounded complete ordinary helper result')
    checkpoint()
    return result
