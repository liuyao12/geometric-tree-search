"""Raw Source/AST and ordinary metadata only; no component import or execution."""
import ast
import hashlib
import json
from pathlib import Path

L = Path('/private/tmp/gcts-finalization-instrumentation-library-20261019')
R = Path('/private/tmp/gcts-finalization-instrumentation-ROOT-20261019')
P = Path('/private/tmp/gcts-cadence-integration-ROOT-20261019')
OLD = Path('/private/tmp/gcts-cadence-integration-library-20261019')


def pin(path):
    path = Path(path).resolve()
    raw = path.read_bytes()
    return dict(path=str(path), sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw))


def read(path):
    return json.loads(Path(path).read_bytes())


def save(name, value):
    path = L / name
    if path.exists():
        raise ValueError('frozen design already exists')
    path.write_text(json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False,
                               allow_nan=False) + '\n')
    return pin(path)


driver = R / 'owned_evidence_receiver_driver_v6.py'
cold = L / 'owned_evidence_cold_v6.py'
runner = P / 'owned_evidence_once_runner_v2.py'
observer = P / 'observe_owned_evidence_runner_v2.py'
oldclosure = read(P / 'runtime-closure-v1.json')
declaration = read(P / 'case-declaration-v1.json')
worker = read(P / 'plans-v1/worker-plans/cadence-integration-001-fixed-ROOT-20261019-v1.json')
once = read(P / 'plans-v1/once-plans/cadence-integration-001-fixed-ROOT-20261019-v1.json')
master = pin(P / 'basic-tiling-algorithm-HEAD.md')
if master['sha256'] != 'ca6ee206287bf18b69f88a35d30968312499567755f347a819af4cf49743e7d4':
    raise ValueError('current master pin changed')
if pin(driver)['sha256'] != 'e8ff0690472140e510f8ffab383be8c22791da6b27ef0a27fda013ea48e5f5cf':
    raise ValueError('driver pin changed')
if pin(cold)['sha256'] != 'e1101723f559ae2dfecc030470a3e6e9e79c71b10c416c2bcdfc8f2f5b101d43':
    raise ValueError('cold pin changed')
if len(oldclosure['project_sources']) != 22 or len(oldclosure['materialized_aliases']) != 28:
    raise ValueError('parent complete alias counts')

# Only syntax and literal import descriptors are compared; no Source is loaded.
def imports(path):
    tree = ast.parse(Path(path).read_bytes(), filename=str(path))
    return [ast.dump(n, include_attributes=False) for n in ast.walk(tree)
            if isinstance(n, (ast.Import, ast.ImportFrom))]

imports_exact = dict(
    driver=imports(driver) == imports(worker['components']['receiver_driver']['path']),
    cold=imports(cold) == imports(OLD / 'owned_evidence_cold_v4.py'))
if not all(imports_exact.values()):
    raise ValueError('new import inventory needs wider review')

def cite(path, start, end, claim):
    return dict(Source=pin(path), first_line=start, last_line=end, claim=claim,
                evidence_kind='raw Source inspection; no function call')

planned_aliases = dict(oldclosure['materialized_aliases'])
planned_aliases['semantic_receiver_driver'] = pin(driver)
planned_components = dict(oldclosure['additional_nonseed_components'])
planned_components['receiver_driver'] = pin(driver)
source_reviews = {
    'driver': pin('/private/tmp/gcts-finalization-instrumentation-peer-20261019/typed-driver-Source-review-v2.json'),
    'cold': pin('/private/tmp/gcts-finalization-instrumentation-peer-20261019/typed-cold-Source-review-v1.json'),
    'helper_packet': pin(L / 'qualification-handoff-v2.json'),
    'helper_current_source_group': pin('/private/tmp/gcts-finalization-instrumentation-peer-20261019/typed-components-Source-review-v3.json'),
}

memo = dict(
    schema='instrumented-finalization-full-pipeline-next-design-v1',
    author_identity='/root/conventional_library', source_only=True,
    design_status='PROPOSED_UNIMPLEMENTED_UNMEASURED',
    actual_execution_authorized=False, future_execution_authorized=False,
    scientific_acceptance=False, scientific_calls=0, component_calls=0,
    fixture_calls=0, codec_inverse_Native_calls=0,
    purpose='One fresh full original001 fixed/symbolic matched pair to observe finalization under the unchanged complete pipeline profile; no new carrier benchmark or performance optimization.',
    ancestry=dict(
        author_overlap='Author wrote coldV6, helper harness, prior cold/driver adapters and Model/bridge/point/certifier Sources. This memo is design reconnaissance, not independent certification of own Sources or the new full pipeline.',
        independent_Source_reviews=source_reviews,
        helper_actual='Parent reports one closed helper-only actual:27 normal groups plus3 reached interruption prefixes0/1/27, four harness calls. Its saved data is independently audited by Control; this memo does not independently replay/audit it.',
        helper_saved_audit=pin(R / 'ROOT-saved-actual-audit-v1.json'),
        helper_scope='Fake interfaces/new metadata helpers only; no run_receiver_owned/cold main/real inverse/Native/Model/search calls. No full-pipeline, real timing, memory-fit, output-fit or proof admission follows.'),
    master=master,
    parents=dict(
        declaration=pin(P / 'case-declaration-v1.json'), runtime_closure=pin(P / 'runtime-closure-v1.json'),
        false_manifest=pin(P / 'false-plan-manifest-v1.json'),
        previous_negative_admission=pin(P / 'ROOT-saved-actual-audit-v1.json'),
        runner=pin(runner), observer=pin(observer),
        cold=pin(OLD / 'owned_evidence_cold_v4.py'),
        cold_master_addendum=pin(OLD / 'current-master-addendum-handoff-v1.json')),
    current_components=dict(driver=pin(driver), cold=pin(cold),
        cold_handoff=pin(L / 'handoff-v1.json'), evidence_profile=pin(OLD / 'EVIDENCE_PROFILE-v4.json')),
    minimal_binding_changes=[
        dict(where='Both fresh worker plans and runtime closure',
             action='Replace receiver_driver4850f66e/114308 by exact e8ff0690/120766. Replace cold02a0e8f7/62809 by exact e1101723/72712. No scientific role, native input, Model, registry, evidence component or library substitution.',
             proposed_component_map=planned_components),
        dict(where='New integration declaration',
             action='Preserve existing comparison schema. Add mandatory finalization_profile literal owned-finalization-phase-instrumented-v1, as already required by coldV6. Bind new complete closure and current Source/helper review prerequisites. Keep exact original assertion capsule and selected receiver, full profile and both arms. No extra route/hint input.',
             new_required_field=dict(finalization_profile='owned-finalization-phase-instrumented-v1'),
             unchanged_worker_fields=sorted(worker), unchanged_once_fields=sorted(once)),
        dict(where='New closure metadata',
             action='Refresh cold and receiver_driver descriptors, current review provenance, original/owned materialized maps and raw/AST census line/pin metadata. Do not copy stale old Source descriptors or imply imports are new. Existing scientific/evidence maps stay byte-pinned.',
             old_new_import_AST_equal=imports_exact,
             full_proposed_materialized_aliases=planned_aliases,
             alias_count_before_schema=28, separately_imported_schema_modules=1,
             unchanged_project_sources=oldclosure['project_sources'],
             unchanged_evidence_sources=oldclosure['evidence_sources'],
             unchanged_schema_sources=oldclosure['schema_sources']),
        dict(where='Narrow outer Source successor',
             action='At minimum update runner own VERSION/current COLD_PIN and observer own VERSION/current runner raw pin; preserve existing guard/process/reaping/EOF/highwater/whole-output checks. Current runner already authenticates full closure/component/worker/declaration maps. The reviewed cold enforces finalization_profile and completed normal driver diagnostic. New profile-aware retained-data admission must join both new observation packets to the raw worker/driver receipt.',
             no_new_scientific_calls=True,
             optional_small_metadata_gate='If Root wants explicit redundant outer enforcement, add only declared finalization_profile and normal observation schema/profile/authority/completed equality joins, with exact current driver version. This is separately reviewable metadata-only Source delta, not permission to skip the existing cold checks or rerun any component.'),
        dict(where='Fresh IDs/paths/subjects/reviews/grants',
             action='Use new two invocation IDs, absent actual directories and absent terminal-observation folders, fresh false plans and max-one subjects. Bind current independent component/outer/prospective scopes and all minimum raw subjects; final true grant delta and Root adoption only after review. Do not modify or reuse old consumed subjects, outputs or helper grant. All agents idle during serial measured windows.')],
    required_epoch_and_return_custody=dict(
        existing_schema='semantic-family-receiver-source-epoch-v6-explicit-schema-admission',
        profile_transitive_binding='Existing source_epoch.result_representation.integration_declaration raw descriptor authenticates the exact new finalization_profile; no additional scientific epoch field or Source change is required.',
        driver_version='semantic-family-owned-evidence-driver-v2-instrumented',
        cold_version='owned-evidence-intake-cold-v6-instrumented',
        version_note='The existing scientific result version string and Source/run-path epochs change to current identities. No new diagnostic fields enter scientific final result/evidence roots. Do not claim old/new whole raw JSON bytes identical.',
        ordinary_result='Retain complete ordinary result.json BODY plus exactly one LF; no filtering to observation-only output.',
        forest='Retain full forest and freshly independent whole inverse stream/full byte comparison, old Reader full canonical reconstruction, full point region and current Native ledger/final proof gates. No extra inverse call is needed for observations.',
        normal_driver_packet=dict(schema='owned-finalization-observation-v1',
            profile='owned-finalization-phase-instrumented-v1', completed=True,
            authority=False, mathematical_authority=False, resource_authority=False),
        normal_cold_packet=dict(schema='owned-cold-phase-observation-v1',
            profile='owned-finalization-phase-instrumented-v1',
            authority=False, mathematical_authority=False, resource_authority=False),
        joins=['Exact worker receipt invocation/worker-plan/cold/Python/receiver/mode/source epoch and original deadlines.',
               'Header finalization_observation equals the retained driver_output_receipt.finalization_observation literal canonical preimage; never a substitute for proof or resource gates.',
               'Header cold_observation is a fresh detached snapshot, not live counter backing. Retain snapshot_cutoff_ns/snapshot_scope and all partial inverse statistics actually available.',
               'Current Source callable seals include the new driver observation class and cold helpers under the same complete28+schema1 custody. No new harness alias/import or helper replay in the proof pair.']),
    common_pair=dict(
        receiver_id='prospective-fol-20261018-001',
        original_assertion_capsule=worker['declaration'],
        exact_selected_receiver=declaration['selected_receiver'],
        modes=['fixed', 'symbolic'], one_fresh_actual_per_mode=True,
        prospective_order='fixed then symbolic unless Root declares a different fixed order before any run; never change after traces',
        common=dict(search_ordering='and_support', inventory_certification_mode='schema_then_native',
                    result_reader='interned', model_storage='literal_interned',
                    complete_historical_formula_family_templates=4,
                    original_case001_complete_ground_definitions=10,
                    proof_rows=12, syntax_UI_rounds=2),
        no_helper_replay='Do not append the four helper qualification invocations to production proof work. Existing cold five adapter diagnostic groups/eight Stores remain exactly as previously declared.',
        pass_fail='Each arm needs the complete original Native/schema/Model/point/evidence/old-reader/source/worker-exit/resource/terminal gates independently. Observation visibility is the added research datum; unavailable/failure outcomes remain failures or UNKNOWN, never assumed pipeline success.',
        comparison='One familiar development control with two distinct search methods. No ordinary-storage arm, randomized replication, blind theorem gain, causal speedup, learner or GCTS/RL advantage claim.'),
    unchanged_caps_and_cost_scope=dict(
        work_seconds=180, overall_seconds=210, separate_worker_plus_Native_highwater_bytes=1073741824,
        highwater_policy='Conservative Darwin worker wait4 highwater plus separately reaped Native highwater; not whole process-group live RAM enforcement or parent/observer heap.',
        encoded_and_expanded_result_bytes=134217728, each_log_bytes=4194304,
        driver_diagnostic_record_bytes=65536, driver_snapshot_bytes=8192,
        driver_phase_rows=16, driver_snapshot_rows=8,
        cold_diagnostic_bytes=262144, cold_phase_rows=32,
        failure_metadata_bytes=1048576,
        old_outer_metadata_reservations=dict(final_runner=8388608, all_observer_metadata=1048576),
        complete_physical_budget='ordinary result+forest+all current actual-root JSON including expanded worker receipt, plus conservative final-runner/observer reservations, within128MiB; new diagnostic copies/serialization are included.',
        profile_unchanged=declaration['limits'],
        evidence_profile_unchanged=declaration['evidence_profile'],
        clock='Parent Source-entry epoch inherited: positive scientific work, all saved inverse/Reader/point/ledger checks and result/worker-header serialization plus known worker exit strictly before180. Subsequent full outer metadata/source/runtime/highwater/log/EOF/group and external observer terminal before210. Observer/interpreter prelude separately recorded, not silently included in worker Source-entry epoch.',
        no_stopped_clock='All extra observation clock reads, snapshots, copies, output/canonicalization and retained-data checks consume the same actual wall/memory/output allowances. No budget renewal at driver return, inverse preparation, partial failure or helper prerequisite.'),
    observation_interpretation=dict(
        driver='Absolute caller monotonic seconds; action_returned and completed distinguish action result from successful post-action diagnostic. Failure-observed time can be unavailable; unavailable marker is not a complete normal packet.',
        cold='Absolute Source-entry monotonic nanoseconds; RETURNED, IN_PROGRESS and OPEN_AT_FAILURE are different. Missing/unstarted rows remain absent and None timestamps are not durations.',
        overlap='driver_run encloses driver finalization, saved_forest_full_comparison encloses independent_prepare and independent_stream_and_compare, and source_guard intervals can lie inside those stages. Never add enclosing and enclosed intervals as disjoint costs.',
        old_decode_seconds='Inherited result_reading.decode_seconds starts before complete forest verification and therefore includes the inverse interval. Label as the inherited combined interval, not pure JSON decoding. New named subphases refine that view without changing old field semantics.',
        cutoff='cold_observation.snapshot_cutoff_ns limits counts and rows to that detached snapshot. Later final guards, fixed-point ledger/receipt serialization, cleanup and worker exit are outside it. It is not a full-window invocation count.',
        counter_scope='overall_tick_invocations/source_guard_invocations/completed/failed/timed_intervals/elapsed_ns are cold-local aggregate counters only. Do not infer Arena/adapter callback dispatch counts, public/completion checkpoints, mathematical operation counts or disjoint guard costs.',
        store_statistics='Only passive existing Store.statistics snapshots; no guard, stream, inverse or scientific replay. Counters are observations, not independent resource/Native authority.',
        units='Keep float driver seconds and cold integer nanoseconds labeled; any conversion for display is presentation arithmetic with ordinary precision limitations, not a new exact custody predicate.'),
    retained_failure_policy=dict(
        no_rescue='Any late inverse/Reader/point/source/deadline/output/resource failure preserves the exact original error and unsuccessful status; an earlier Native candidate or complete driver packet does not admit a proof or retry.',
        driver='On action/clock/metadata failure, same error carries best-effort owned_finalization_observation; unavailable marker explicitly has complete_ledger_retained false and no authority.',
        cold='Keep existing bounded worker-failure schema with owned_finalization_observation, owned_evidence_statistics, driver_returned_receipt, cold_observation, diagnostic_output_prefixes, stage_intervals and Native cleanup metadata. Preserve each actual available item; missing is unavailable, not reconstructed after the window.',
        downstream='If outer rejects before reading a normal worker header, preserve any raw failure file/logs by descriptor as diagnostic custody without importing components or retrospectively probing/filling missing telemetry. Runner/observer failure booleans and nulls remain literal.',
        no_masking='Best-effort observation timestamps/copy/serialization cannot replace the active exception. No partial normal header, no late rewritten result or evidence forest, no cap increase.'),
    required_prelaunch_checks=[
        'Current-master/ownSource ancestry and distinct exact component reviews adopted; helper-only pass kept separately scoped.',
        'New complete declaration+28-alias/schema1 closure and both exact false worker/once subjects independently reviewed; fixed native/Python/Z3/program/Model/registry/library/profile unchanged.',
        'Any new outer Source delta independently raw/AST/compile reviewed, no inherited pass for changed pins/body.',
        'Fresh true max-one grants change only allowed authorization metadata, exact current subjects and role containment verified; old consumed subjects remain immutable.',
        'Absent new actual/terminal paths and all peers idle before each Root-only sequential launch. No execution authorization supplied by this memo.'],
    evidence=[
        cite(cold, 285, 398, 'Bounded detached cold metadata helpers and unavailable failure fallbacks.'),
        cite(cold, 718, 772, 'Original overall/source-guard body plus local observation; mandatory finalization_profile declaration join.'),
        cite(cold, 907, 928, 'Existing epoch binds declaration and current evidence/inverse headers without new scientific input fields.'),
        cite(cold, 946, 960, 'Same run_receiver_owned call and immediate driver-return/custody phase boundaries.'),
        cite(cold, 1064, 1116, 'Normal driver completion metadata, detached cutoff snapshot, whole physical ledger and final guards/header serialization.'),
        cite(cold, 1117, 1153, 'Late failure retains returned diagnostics/partial statistics without masking or retry.'),
        cite(driver, 1422, 1509, 'Current instrumented driver version, bounded observation class, passive snapshots and unavailable marker.'),
        cite(driver, 1553, 1570, 'Same final assemble/seal/wire/write/full-boundary actions wrapped with observations; no new root datum.'),
        cite(runner, 162, 205, 'Existing complete28+schema1 intake, exact pair subject/declaration/profile joins.'),
        cite(runner, 371, 440, 'Whole worker/result/forest custody, complete inverse metadata, physical output and epoch joins.'),
        cite(runner, 480, 495, 'Original separate highwater/positive180 and complete210 outer gates.'),
        cite(observer, 36, 88, 'Observer final terminal uses inherited Source-entry endpoint; prelude is separately labeled.')],
    limitations=['Source-only design, not a new implementation or grant; no target Source edited.',
                 'Only exact raw Source/AST/import comparison and ordinary metadata descriptors used here; no fixture/component/proof/inverse replay.',
                 'Own authored instrumentation is not independently certified by this memo; distinct scoped Source reviews are dependencies.',
                 'Instrumentation can change cost and even whether the unchanged profile finishes. No fit, speed, memory-saving or causal benefit prediction.',
                 'Earlier failed full-pipeline pairs and their full diagnostic artifacts remain nonadmitted and immutable.'])

memo_pin = save('next-full-pipeline-integration-design-v1.json', memo)
handoff = save('next-full-pipeline-integration-design-handoff-v1.json', dict(
    schema='instrumented-finalization-integration-design-handoff-v1',
    author_identity='/root/conventional_library', source_only=True,
    status='PROPOSED_UNIMPLEMENTED_UNMEASURED', actual_execution_authorized=False,
    future_execution_authorized=False, scientific_acceptance=False, scientific_calls=0,
    component_fixture_inverse_Native_calls=0, memo=memo_pin,
    author_script=pin(__file__), current_cold=pin(cold), current_driver=pin(driver),
    parent_wrapper=pin(runner), parent_observer=pin(observer),
    remaining='Root-owned fresh closure/declaration/outer/subjects, independent reviews, exact max-once grants and later all-idle actuals. No Source changes or execution in this task.'))
print(json.dumps(dict(memo=memo_pin, handoff=handoff)))
