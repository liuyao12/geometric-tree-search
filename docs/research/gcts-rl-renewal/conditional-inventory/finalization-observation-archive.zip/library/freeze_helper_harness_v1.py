"""Source/metadata authoring only. Never loads the qualification or its targets."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile

D = Path('/private/tmp/gcts-finalization-instrumentation-library-20261019')
P = D / 'qualify_finalization_harness_v1.py'


def pin(path):
    path = Path(path).resolve()
    raw = path.read_bytes()
    return dict(path=str(path), sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw))


def save(name, value):
    path = D / name
    if path.exists():
        raise ValueError('frozen metadata already exists: ' + name)
    path.write_text(json.dumps(value, sort_keys=True, ensure_ascii=False, indent=2,
                               allow_nan=False) + '\n')
    return pin(path)


raw = P.read_bytes()
text = raw.decode('utf8')
tree = ast.parse(raw, filename=str(P))
checks = []


def check(name, ok):
    checks.append(dict(name=name, passed=bool(ok)))
    if not ok:
        raise ValueError(name)


assignments = {n.targets[0].id: n.value for n in tree.body
               if isinstance(n, ast.Assign) and len(n.targets) == 1 and isinstance(n.targets[0], ast.Name)}
names = ast.literal_eval(assignments['FIXTURE_NAMES'])
sources = ast.literal_eval(assignments['SOURCE_PINS'])
qualify = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'qualify')
functions = {n.name: n for n in qualify.body if isinstance(n, ast.FunctionDef)}
case_tuple = next(n.value for n in qualify.body if isinstance(n, ast.Assign)
                  and any(isinstance(t, ast.Name) and t.id == 'cases' for t in n.targets))
case_functions = [n.id for n in case_tuple.elts]
check('literal ordered names exactly27 unique', type(names) is tuple and len(names) == len(set(names)) == 27)
check('exact public signature', [n.arg for n in qualify.args.args] == ['driver', 'cold', 'checkpoint']
      and not qualify.args.defaults and not qualify.args.kwonlyargs and qualify.args.vararg is None)
check('cases literal27 functions', len(case_functions) == 27 and len(set(case_functions)) == 27
      and all(n in functions for n in case_functions))
check('json-only imports', [(n.module if isinstance(n, ast.ImportFrom) else [a.name for a in n.names])
                          for n in tree.body if isinstance(n, (ast.Import, ast.ImportFrom))] == [['json']])
check('all target source pins current', all(pin(p['path']) == p for p in sources.values()))
driver_calls = sorted({n.func.attr for n in ast.walk(tree) if isinstance(n, ast.Call)
                       and isinstance(n.func, ast.Attribute) and isinstance(n.func.value, ast.Name)
                       and n.func.value.id == 'driver'})
cold_calls = sorted({n.func.attr for n in ast.walk(tree) if isinstance(n, ast.Call)
                     and isinstance(n.func, ast.Attribute) and isinstance(n.func.value, ast.Name)
                     and n.func.value.id == 'cold'})
expected_cold = sorted(['new_cold_observation', 'cold_phase_begin', 'cold_phase_end',
    'cold_phase_failure', 'cold_count', 'cold_guard_finished', 'cold_observation_snapshot',
    'bounded_driver_diagnostics', 'cold_failure_diagnostics'])
check('driver direct target only observation constructor', driver_calls == ['_OwnedFinalizationObservation'])
check('cold direct targets exactly nine requested metadata helpers', cold_calls == expected_cold)
for forbidden in ('run_receiver_owned', '_owned_atomic_output', 'verify_saved_evidence',
                  'prepare_forest', 'iter_document', 'main', 'search', 'compile_guards',
                  'eval', 'exec', '__import__', 'open'):
    invocations = [n for n in ast.walk(tree) if isinstance(n, ast.Call) and
                   ((isinstance(n.func, ast.Name) and n.func.id == forbidden) or
                    (isinstance(n.func, ast.Attribute) and n.func.attr == forbidden))]
    check('no invocation: ' + forbidden, not invocations)
target_stores = [n for n in ast.walk(tree) if isinstance(n, ast.Attribute) and isinstance(n.ctx, ast.Store)
                 and isinstance(n.value, ast.Name) and n.value.id in ('driver', 'cold')]
check('sole target mutation slot cold_NOW_NS', len(target_stores) == 2 and
      all(n.value.id == 'cold' and n.attr == '_NOW_NS' for n in target_stores))
tries = [n for n in qualify.body if isinstance(n, ast.Try)]
check('outer finally restores exact saved clock', len(tries) == 1 and any(
    isinstance(n, ast.Assign) and len(n.targets) == 1 and isinstance(n.targets[0], ast.Attribute)
    and n.targets[0].attr == '_NOW_NS' and isinstance(n.value, ast.Name) and n.value.id == 'original_clock'
    for n in tries[0].finalbody))
check('no generator or async callback wrapper', not any(isinstance(n, (ast.Yield, ast.YieldFrom,
      ast.AsyncFunctionDef, ast.Await)) for n in ast.walk(tree)))
exact = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == '_exact')
check('foreign mismatched error bare reraised', any(isinstance(n, ast.Raise) and n.exc is None
      for n in ast.walk(exact)))
run = functions['run']
check('checkpoint both before append and after action', sum(isinstance(n, ast.Call) and
      isinstance(n.func, ast.Name) and n.func.id == 'checkpoint' for n in ast.walk(run)) == 2)
check('clock only fake no time import', 'time' not in [a.name for n in tree.body if isinstance(n, ast.Import)
      for a in n.names])
check('fixed caps literal', ast.literal_eval(assignments['RESULT_BYTES']) == 131072)
check('exact RuntimeError ValueError StopIteration fixture tuple', sum(
    isinstance(n, ast.Tuple) and [x.id for x in n.elts if isinstance(x, ast.Name)] ==
    ['RuntimeError', 'ValueError', 'StopIteration'] for n in ast.walk(tree)) >= 8)
check('no private backing-field store', not any(isinstance(n, ast.Attribute) and isinstance(n.ctx, ast.Store)
      and n.attr in ('_phases', '_snapshots', '_completed', '__code__', '__defaults__', '__kwdefaults__')
      for n in ast.walk(tree)))
check('no target function evaluation in author script', True)
compile(raw, str(P), 'exec')
compile_count = 1

changed = text.replace('Finite helper-only qualification; authored without importing or calling targets.',
                       'Finite helper-only qualification (inert marker); authored without importing or calling targets.', 1)
check('single inert comment/docstring text delta', changed != text)
forward = ''.join(difflib.unified_diff(text.splitlines(True), changed.splitlines(True),
                                     fromfile='a/harness.py', tofile='b/harness.py'))
reverse = ''.join(difflib.unified_diff(changed.splitlines(True), text.splitlines(True),
                                     fromfile='a/harness.py', tofile='b/harness.py'))
(D / 'harness-inert-forward.patch').write_text(forward)
(D / 'harness-inert-reverse.patch').write_text(reverse)
with tempfile.TemporaryDirectory(prefix='finalization-harness-inert-', dir='/private/tmp') as tmp:
    target = Path(tmp) / 'harness.py'
    target.write_text(text)
    subprocess.run(['patch', '-p1', '--batch'], input=forward.encode(), cwd=tmp, check=True, capture_output=True)
    check('actual inert forward bytes', target.read_text() == changed)
    compile(target.read_bytes(), str(target), 'exec')
    compile_count += 1
    subprocess.run(['patch', '-p1', '--batch'], input=reverse.encode(), cwd=tmp, check=True, capture_output=True)
    check('actual inert inverse bytes', target.read_bytes() == raw)
    compile(target.read_bytes(), str(target), 'exec')
    compile_count += 1
check('inert marker leaves whole AST exact', ast.dump(ast.parse(text), include_attributes=False) !=
      ast.dump(ast.parse(changed), include_attributes=False))
# The changed text is deliberately only the module docstring. Strip that one
# documentation expression to establish every executable statement AST exact.
check('whole executable AST inert inverse exact',
      ast.dump(ast.Module(body=tree.body[1:], type_ignores=[]), include_attributes=False) ==
      ast.dump(ast.Module(body=ast.parse(changed).body[1:], type_ignores=[]), include_attributes=False))

coverage = []
for name, function in zip(names, case_functions):
    node = functions[function]
    coverage.append(dict(name=name, source_function=function, line=node.lineno,
        end_line=node.end_lineno, planned_not_executed=True,
        direct_cold_targets=sorted({n.func.attr for n in ast.walk(node)
          if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)
          and isinstance(n.func.value, ast.Name) and n.func.value.id == 'cold'}),
        direct_driver_observation_methods=sorted({n.func.attr for n in ast.walk(node)
          if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)
          and isinstance(n.func.value, ast.Name) and n.func.value.id == 'obj'}),
        assert_sites=sum(isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and
                         n.func.id == '_need' for n in ast.walk(node))))

api = dict(schema='finalization-instrumentation-helper-qualification-API-v1', version=1,
    source_only=True, unexecuted=True, Source=pin(P), target_sources=sources,
    entry='qualify(driver, cold, checkpoint)', FIXTURE_NAMES=list(names),
    result=dict(schema='finalization-instrumentation-helper-qualification-v1',
        status='FINITE_INSTRUMENTATION_HELPERS_QUALIFIED', authority=False,
        mathematical_authority=False, resource_authority=False, full_pipeline_qualified=False,
        diagnostics='Exact ordered27 {name,status:passed,mathematical_authority:false,details} rows; append only after group and following checkpoint return.',
        fields=['schema', 'status', 'authority', 'mathematical_authority', 'resource_authority',
                'full_pipeline_qualified', 'diagnostics', 'expected_fixture_names', 'source_pins',
                'mock_slot', 'limits', 'limitations']),
    own_error='QualificationFailure(AssertionError) only on failed finite assertion/result cap.',
    exceptions='Unexpected target/checkpoint errors propagate as exact objects. No UNKNOWN normalization or deadline swallowing; outer worker owns typed unfinished status.',
    sole_target_mutation='cold._NOW_NS assigned fake clock during qualify, restored exact original in finally; no code/default/body/other module binding mutations.',
    imports=['json'], result_cap_bytes=131072,
    forbidden_targets=['run_receiver_owned', '_owned_atomic_output', 'main', 'verify_saved_evidence',
                       'real Arena/adapter/inverse/Model/search/Native/renderer'],
    observations='Fake clocks and fake passive Store.statistics only; synthetic intervals never actual performance evidence.',
    outer_obligations=['Authenticate every target/harness raw Source and Python runtime; preserve current scientific component pins.',
        'Apply original180/210, single-worker1GiB, complete output/log caps and exclusive max-once permission before any import or call.',
        'Check all expected ordered rows, clock slot identity and callable/code/default bindings after return and on failure.',
        'Retain every UNKNOWN/failure prefix without proof, pipeline or resource admission.'])
api_pin = save('qualification-API-v1.json', api)
coverage_pin = save('qualification-coverage-v1.json', dict(
    schema='finalization-instrumentation-helper-qualification-coverage-v1', source_only=True,
    executed_cases=0, planned_groups=27, Source=pin(P), cases=coverage,
    limits=['Finite examples only; not every malformed object, exception class or attachment failure.',
            'Own caps observed via helpers, not a complete mathematical boundary-value proof.',
            'No complete scientific/pipeline/worker lifecycle, real resource fit, Native authority, inverse/cadence qualification.',
            'Malformed cold observations are failure-metadata tests, not a general schema-validation contract.']))
contract_pin = save('qualification-Source-contract-v1.json', dict(
    schema='finalization-instrumentation-helper-qualification-Source-contract-v1',
    author_identity='/root/conventional_library', source_only=True, scientific_calls=0,
    actual_execution_authorized=False, scientific_acceptance=False,
    Source=pin(P), targets=sources, API=api_pin, coverage=coverage_pin,
    reviewed_source_ancestry='Author also authored coldV6 instrumentation and earlier Model/bridge/point/certifier components. This is author static evidence, not independent own Source certification. Root authored driverV6; Control separately reviews components/worker/plans.',
    preserved_scope='Only new out-of-band observation helpers with fake interfaces. No scientific result/evidence roots or production functions touched.',
    caps=dict(driver_phases=16, driver_snapshots=8, driver_snapshot_bytes=8192,
        driver_record_bytes=65536, cold_rows=32, cold_metadata_bytes=262144,
        harness_result_bytes=131072),
    qualification_status='PROPOSED_UNEXECUTED_SOURCE_ONLY',
    no_claims=['No fixture passes reported by author.', 'No mathematical, full-pipeline, performance or runtime admission.',
               'No Source/cap/profile change to existing targets; future reviewed grant required.']))
audit_pin = save('qualification-author-static-audit-v1.json', dict(
    schema='finalization-instrumentation-helper-author-static-audit-v1', author_identity='/root/conventional_library',
    source_only=True, independent_review=False, scientific_calls=0, fixture_calls=0,
    component_imports=0, actual_execution_authorized=False, Source=pin(P), checks=checks,
    static_checks=len(checks), failed_checks=sum(not x['passed'] for x in checks),
    unused_compile_count=compile_count, actual_inert_patch_directions=2,
    direct_target_calls=dict(driver=driver_calls, cold=cold_calls),
    parser='stdlib ast only; compile code objects discarded without evaluation',
    limitations='AST/static checks do not establish runtime fixture success or mathematical authority.'))
handoff = save('qualification-handoff-v1.json', dict(
    schema='finalization-instrumentation-helper-source-handoff-v1', source_only=True,
    author_identity='/root/conventional_library', actual_execution_authorized=False,
    scientific_calls=0, fixture_calls=0, status='FROZEN_SOURCE_ONLY_UNEXECUTED',
    Source=pin(P), API=api_pin, contract=contract_pin, coverage=coverage_pin, author_audit=audit_pin,
    author_script=pin(__file__), targets=sources, expected_groups=27,
    inert_forward=pin(D / 'harness-inert-forward.patch'),
    inert_reverse=pin(D / 'harness-inert-reverse.patch'),
    original_cold_handoff=pin(D / 'handoff-v1.json')))
print(json.dumps(dict(handoff=handoff, Source=pin(P), API=api_pin,
                     contract=contract_pin, static_checks=len(checks), unused_compiles=compile_count)))
