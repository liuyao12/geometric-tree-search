"""Author static Source metadata, AST and inert patches only."""
from pathlib import Path
import ast
import copy
import difflib
import hashlib
import json
import subprocess

D=Path(__file__).parent
P=Path('/private/tmp/gcts-cadence-integration-library-20261019/owned_evidence_cold_v4.py')
S=D/'owned_evidence_cold_v6.py'
DR=Path('/private/tmp/gcts-finalization-instrumentation-ROOT-20261019/owned_evidence_receiver_driver_v6.py')
M=Path('/private/tmp/gcts-cadence-integration-ROOT-20261019/basic-tiling-algorithm-HEAD.md')
PROFILE=Path('/private/tmp/gcts-cadence-integration-library-20261019/EVIDENCE_PROFILE-v4.json')
def pin(p):
    b=Path(p).read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def save(name,value):
    p=D/name;assert not p.exists(),name
    p.write_text(json.dumps(value,indent=2,ensure_ascii=False,allow_nan=False)+'\n');return pin(p)
old=P.read_text();new=S.read_text();a=ast.parse(old);b=ast.parse(new)
checks=[]
def check(name,condition,detail):
    assert condition,name
    checks.append(dict(name=name,passed=True,method='raw Source/AST/metadata only',detail=detail))
check('exact_parent',pin(P)['sha256']=='02a0e8f708b0c4928630b8eb7a7956ad9cde9341e658fd0b1528c3159b267377','Parent Source unchanged.')
check('exact_current',pin(S)['sha256']=='e1101723f559ae2dfecc030470a3e6e9e79c71b10c416c2bcdfc8f2f5b101d43','Current coldV6.')
check('exact_current_driver',pin(DR)['sha256']=='e8ff0690472140e510f8ffab383be8c22791da6b27ef0a27fda013ea48e5f5cf','Root driverV6 only, held V5 not active.')
check('current_master',pin(M)['sha256']=='ca6ee206287bf18b69f88a35d30968312499567755f347a819af4cf49743e7d4','Current36240-byte master reread fully; no learner changes.')
oldf={n.name:n for n in a.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
newf={n.name:n for n in b.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
retained=[]
for name,n in oldf.items():
    if name in ('main','verify_saved_evidence'):continue
    m=newf[name];raw_equal=ast.get_source_segment(old,n)==ast.get_source_segment(new,m)
    ast_equal=ast.dump(n,include_attributes=False)==ast.dump(m,include_attributes=False)
    check('retained_'+name,raw_equal and ast_equal,'Whole parent body raw+AST exact.')
    retained.append(dict(name=name,raw_equal=True,AST_equal=True,parent_line=n.lineno,current_line=m.lineno))
oldassign={n.targets[0].id:n for n in a.body if isinstance(n,ast.Assign)and isinstance(n.targets[0],ast.Name)}
newassign={n.targets[0].id:n for n in b.body if isinstance(n,ast.Assign)and isinstance(n.targets[0],ast.Name)}
for name,n in oldassign.items():
    if name in ('VERSION','RECEIVER_DRIVER_SOURCE'):continue
    check('same_binding_'+name,ast.get_source_segment(old,n)==ast.get_source_segment(new,newassign[name]),'Whole old constant retained, including every evidence Source/version/profile/cap.')
check('unchanged_evidence_profile',pin(PROFILE)['sha256']=='3a78d1d75a77f9d1aec11f531b9b2e88bfe920901aabdf691270cfbe2a906ee8','Full evidence profile unchanged; separate finalization_profile declaration added.')
check('no_new_component',"len(names)==28"in new and "len(loaded)==28 and len(schema_loaded)==1"in new,'Same28 early aliases +schema1; no observer module or injected callback.')
check('normal_driver_envelope',"driver_observation['schema']=='owned-finalization-observation-v1'"in new and "driver_observation['completed']is True"in new,'Unavailable marker cannot satisfy normal complete receipt.')
check('retained_receipt_on_failure',"driver_returned_receipt=retained_diagnostics['driver_output_receipt']"in new,'Receipt diagnostics remain after later inverse/reader/point error.')
check('active_inverse_observer',"if observation is not None:observation['inverse_statistics']=observed"in new,'Same existing inverse observation survives partial errors; no extra inverse call.')

# Project away only inserted metadata statements in the inverse verifier and
# remove its new optional ordinary observation parameter.
class StripMetadata(ast.NodeTransformer):
    def visit_Expr(self,node):
        if isinstance(node.value,ast.Call)and isinstance(node.value.func,ast.Name)and node.value.func.id in('cold_phase_begin','cold_phase_end'):
            return None
        return self.generic_visit(node)
    def visit_If(self,node):
        if isinstance(node.test,ast.Compare)and isinstance(node.test.left,ast.Name)and node.test.left.id=='observation':
            return None
        return self.generic_visit(node)
vf=copy.deepcopy(newf['verify_saved_evidence']);vf=StripMetadata().visit(vf)
vf.args.args=vf.args.args[:-1];vf.args.defaults=[]
check('inverse_verifier_AST_projection',ast.dump(vf,include_attributes=False)==ast.dump(oldf['verify_saved_evidence'],include_attributes=False),
      'All old check calls, byte/occurrence equations, public API calls/order and return retained after deleting metadata insertions.')
def calls(node):
    return [ast.dump(n,include_attributes=False)for n in ast.walk(node)if isinstance(n,ast.Call)and
            isinstance(n.func,ast.Attribute)and (n.func.attr in('prepare_forest','iter_document','statistics','close'))]
check('exact_inverse_calls',calls(oldf['verify_saved_evidence'])==calls(newf['verify_saved_evidence']),
      'No new prepare/stream/statistics/cleanup invocation.')
oldmain=oldf['main'];newmain=newf['main']
oldguard=next(n for n in oldmain.body if isinstance(n,ast.FunctionDef)and n.name=='source_guard')
newguard=next(n for n in newmain.body if isinstance(n,ast.FunctionDef)and n.name=='source_guard')
tryguard=next(n for n in newguard.body if isinstance(n,ast.Try))
check('guard_body_AST_exact',ast.dump(ast.Module(body=oldguard.body,type_ignores=[]),include_attributes=False)==
      ast.dump(ast.Module(body=tryguard.body,type_ignores=[]),include_attributes=False),
      'Same complete raw-file/callable/Z3 guard body inside nondelegating timing envelope.')
def targetcalls(node):
    out=[]
    for n in ast.walk(node):
        if isinstance(n,ast.Call)and isinstance(n.func,ast.Attribute)and n.func.attr in(
                'run_receiver_owned','decode_result','write_micro','make_request_oracle_factory','transport_receipt','close'):
            out.append(ast.dump(n,include_attributes=False))
    return out
check('scientific_main_calls_exact',targetcalls(oldmain)==targetcalls(newmain),
      'All old original driver/decoder/Native encode/broker/transport/cleanup calls and arguments remain exact.')
check('tick_body_preserved',"cold_count(cold_observation,'overall_tick_invocations')\n        need(_NOW_NS()<overall_ns,'original total closure deadline')"in new,
      'Counter addition only; no callback suppression/coalescing or changed deadline predicate.')
check('snapshot_detached',"return json.loads(raw)"in ast.get_source_segment(new,newf['cold_observation_snapshot']),
      'Header owns fresh canonical-roundtripped ordinary snapshot; no live counter alias.')
check('snapshot_cutoff',"Excludes later final guards, ledger/receipt serialization, cleanup and worker exit."in new,
      'Saved counters have a cutoff, not through-exit totals.')
check('metadata_bounded',"COLD_OBSERVATION_BYTES = 262144"in new and "len(observation['phases'])>=32"in new,
      'Finite phase count and normal snapshot cap below old failure1MiB/global128MiB.')
check('guard_failure_identity',"cold_guard_finished(cold_observation,guard_started,True)\n            raise"in new,
      'Metadata helpers suppress their own errors; original guard BaseException is bare-reraised.')
check('failure_marker_preserved',"schema='owned-finalization-observation-unavailable-v1'"in new and "complete_ledger_retained=False"in new,
      'Missing/cap/serialization diagnostics are explicit unavailable metadata, never complete normal packet.')
check('note_identity_safe',"except BaseException:pass\n        raise"in new,
      'Even error.add_note failure cannot replace the active original exception.')
check('no_new_scientific_root',"cold_observation=observation_snapshot,finalization_observation=driver_observation"in new,
      'Observations appear only in worker header/failure metadata, not result_data or Arena.assemble input.')
check('unchanged_ledger_call',"finalize_output_ledger(actual,header,result_pin,forest_pin,evidence_tick)"in new,
      'All new observation bytes remain in old complete physical ledger; original encoded/logical caps retained.')

patches=[]
for label,parent in [('parent-v4',P),('held-draft-v5',D/'owned_evidence_cold_v5.py')]:
    start=parent.read_text()
    for direction,before,after in [('forward',start,new),('inverse',new,start)]:
        patch=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='cold.py',tofile='cold.py'))
        file=D/(label+'-'+direction+'.patch');assert not file.exists();file.write_text(patch)
        scratch=D/'inert-patch'/label/direction;scratch.mkdir(parents=True);(scratch/'cold.py').write_text(before)
        proc=subprocess.run(['/usr/bin/patch','--batch','-p0','-i',str(file)],cwd=scratch,capture_output=True,text=True)
        assert proc.returncode==0,(proc.stdout,proc.stderr)
        got=(scratch/'cold.py').read_text();assert got==after
        ast.parse(got);compile(got,str(scratch/'cold.py'),'exec')
        patches.append(dict(label=label,direction=direction,patch=pin(file),result=pin(scratch/'cold.py'),
            actual_inert_patch_applied=True,whole_bytes_equal=True,unused_compile=True,target_calls=0))
compile(new,str(S),'exec')
source=pin(S)
api=save('API-v1.json',dict(schema='owned-finalization-cold-instrumentation-API-v1',source=source,
    VERSION='owned-evidence-intake-cold-v6-instrumented',entry='main(argv)',old_entry_API_unchanged=True,
    exact_driver=pin(DR),expected_driver_version='semantic-family-owned-evidence-driver-v2-instrumented',
    profile='owned-finalization-phase-instrumented-v1',new_integration_declaration_field='finalization_profile',
    evidence_profile_unchanged=pin(PROFILE),base_aliases=28,separate_schema_aliases=1,
    helpers=dict(new_cold_observation='()->fresh ordinary metadata record',
        cold_phase_begin='(observation,name,stamp=None)->None; bounded best effort',
        cold_phase_end='(observation,name,stamp=None)->None; bounded best effort',
        cold_phase_failure='(observation,error)->None; open rows explicitly OPEN_AT_FAILURE',
        cold_count='(observation,name)->None; existing local helper invocation counts only',
        cold_guard_finished='(observation,started,failed)->None; aggregate existing guard duration',
        cold_observation_snapshot='(observation)->fresh<=256KiB ordinary snapshot; explicit cutoff; no backing alias',
        bounded_driver_diagnostics='(receipt,error=None)->fresh<=256KiB existing ordinary diagnostics, no component call',
        cold_failure_diagnostics='(observation,receipt,error)->fresh bounded ordinary driver+cold metadata or explicit unavailable markers',
        verify_saved_evidence='(inverse,wire,forest_pin,result_raw,epoch,check,observation=None)->old full verification record; optional ordinary observation reuses existing inverse statistics dictionary'),
    new_header_fields=['cold_observation','finalization_observation'],
    failure_fields=['owned_evidence_statistics','owned_finalization_observation','driver_returned_receipt','cold_observation'],
    cold_observation_schema='owned-cold-phase-observation-v1',cold_phase_limit=32,cold_snapshot_bytes=262144,
    scope='Header/failure counters are detached snapshots through snapshot_cutoff_ns; not complete through final guard/serialization/cleanup/exit. Nested intervals overlap. No Arena/adapter dispatch-origin inference.',
    constraints=['Observation records must be factory-created ordinary metadata; explicit stamp arguments are internal absolute monotonic ns.',
        'Root owns exact module/Source/declaration/plan/grant/current independent review. Helpers grant no mathematical or resource authority.',
        'No helper is executed during Source authoring; future component-only or full-pipeline diagnostics require a new bounded grant.']))
argument=save('Source-argument-v1.json',dict(schema='owned-finalization-cold-author-argument-v1',source=source,parent=pin(P),
    master=pin(M),master_read_in_full=True,author_identity='/root/conventional_library',retained_regions=retained,
    preserved=['all original component calls/arguments/order and original28+schema1 import/callable seals',
        'all mathematical inventory/Model/point/Native and old full canonical checks','all Source/public/completion callback opportunities and error identities',
        'strict180/210,worker+Native1GiB,encoded+expanded128MiB,logs4MiB,400m/400m/30m caps'],
    changed=['current driver Source/version binding','ordinary declaration finalization_profile guard','new inline passive phase/counter/snapshot metadata',
        'optional inverse observation dictionary with no extra calls','best-effort bounded failure metadata retention/notes'],
    conformance_gaps=['Author static retention is not independent runtime proof of scheduler or rollback conformance.',
        'Observational clock/statistics/copy/JSON costs alter wall/peak and are charged; no performance or fit prediction.',
        'Counts identify only cold overall_tick/source_guard calls; no caller-origin/public/completion attribution is inferred.',
        'Header cutoff excludes subsequent own serialization/guards/exit. In-progress/missing/failed timestamps are not durations.',
        'Current master marking-learning/corona/exclusion provisions introduce no learner change here. Symbolic chronology remains specialized.',
        'No target, fixture, codec, inverse, Model, Native or search Source/function is imported/evaluated during authoring.'],
    ancestry='Author of parent cold, arena/registry and older Model/point work; no independent self-Source certification. Root driver and Control distinct review are separate.'))
fixtures=save('proposed-cold-fault-cases-v1.json',dict(schema='owned-finalization-cold-proposed-finite-faults-v1',source=source,
    status='SOURCE_DESIGN_ONLY_UNEXECUTED',cases=[
        'Factory phases remain explicit unstarted/in-progress; start/end supplied stamps and failure mark do not invent return times.',
        'Detached snapshot does not change after counters/original phase dictionaries mutate; fixed-point header serialization remains stable.',
        'Driver complete receipt+stats survive a later exact injected inverse prepare/stream/old-reader/point exception.',
        'Same original inverse observer gains partial dictionary without an extra prepare/stream/statistics call.',
        'Driver unavailable marker/cap failure remains unavailable in failure metadata and cannot satisfy normal completed observation gate.',
        'Exact RuntimeError/ValueError/StopIteration/earlier own deadline identities survive metadata snapshot and add_note failures; private stop classification is not class-only.',
        'Bad/oversized observation serialization gives explicit bounded unavailable marker on an active primary error; primary error object unchanged.',
        'Source guard failure retains exact identity and failed count; aggregate clock duration records only finite retained intervals.',
        'Additional observation bytes are included before physical cap and no diagnostics enter any Arena root or logical scientific result.',
        'Source-only comparison shows no callback batching, suppressed public/completion check, hidden quota reset or new component alias.'],
    limitations='These are proposed finite qualification obligations, not executed cases or a universal all-exceptions certificate.'))
contract=save('Source-contract-v1.json',dict(schema='owned-finalization-cold-instrumentation-Source-contract-v1',source=source,sources=[source],
    author_identity='/root/conventional_library',parent=pin(P),held_draft=pin(D/'owned_evidence_cold_v5.py'),
    current_driver=pin(DR),master=pin(M),API=api,argument=argument,proposed_faults=fixtures,
    evidence_profile_unchanged=pin(PROFILE),source_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,
    review_ABI=dict(schema='owned-finalization-cold-instrumentation-typed-Source-review-v1',reviewer_must_be_distinct=True,
        required_fields=['schema','source','sources','source_contract','author_identity','reviewer_identity','source_only','source_review_passed',
            'scientific_calls','scientific_acceptance','actual_execution_authorized','findings','limitations']),
    pending='Distinct Source/finite-oracle review, Root current closure/declaration/outer/plans/grants; no execution requested or authorized here.'))
audit=save('author-static-audit-v1.json',dict(schema='owned-finalization-cold-author-static-audit-v1',source=source,parent=pin(P),
    author_identity='/root/conventional_library',independent=False,checks=checks,check_count=len(checks),mismatches=0,
    retained_regions=retained,inert_patches=patches,unused_compiles=5,target_imports=0,target_functions_called=0,
    fixture_calls=0,scientific_calls=0,actual_execution_authorized=False))
delta=save('Source-delta-v1.json',dict(schema='owned-finalization-cold-delta-v1',source=source,parent=pin(P),
    transforms=[pin(D/'author-transform-v1.json'),pin(D/'author-transform-v2.json')],
    held_draft_never_executed=True,inert_patches=patches,retained_regions=retained,
    prior_frozen_sources_changed=False,scientific_calls=0))
handoff=save('handoff-v1.json',dict(schema='owned-finalization-cold-author-handoff-v1',source=source,sources=[source],
    author_identity='/root/conventional_library',source_contract=contract,API=api,argument=argument,proposed_fault_cases=fixtures,
    author_static_audit=audit,delta=delta,parent=pin(P),current_driver=pin(DR),master=pin(M),
    source_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,
    status='FROZEN_SOURCE_ONLY_NOT_RUNTIME_QUALIFIED'))
print(json.dumps(dict(source=source,handoff=handoff,API=api,contract=contract,checks=len(checks),retained_regions=len(retained))))
