"""Metadata-only Source construction. No scientific module is evaluated."""
from pathlib import Path
import ast
import hashlib
import json

D=Path(__file__).parent
P=Path('/private/tmp/gcts-cadence-integration-library-20261019/owned_evidence_cold_v4.py')
M=Path('/private/tmp/gcts-cadence-integration-ROOT-20261019/basic-tiling-algorithm-HEAD.md')
DR=Path('/private/tmp/gcts-finalization-instrumentation-ROOT-20261019/owned_evidence_receiver_driver_v5.py')
def pin(p):
    b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
assert pin(P)['sha256']=='02a0e8f708b0c4928630b8eb7a7956ad9cde9341e658fd0b1528c3159b267377'
assert pin(M)['sha256']=='ca6ee206287bf18b69f88a35d30968312499567755f347a819af4cf49743e7d4'
assert pin(DR)==dict(path=str(DR),sha256='c5e6c472056512fa08cc50cf0324175db446119e22901afe414b3f0edc3c3d54',bytes=119296)
old=P.read_text();s=old;changes=[]
def change(before,after,label):
    global s
    assert s.count(before)==1,(label,s.count(before))
    s=s.replace(before,after,1);changes.append(dict(label=label,old=before,new=after))
tree=ast.parse(old)
node=next(n for n in tree.body if isinstance(n,ast.Assign)and isinstance(n.targets[0],ast.Name)and n.targets[0].id=='RECEIVER_DRIVER_SOURCE')
change(ast.get_source_segment(old,node),'RECEIVER_DRIVER_SOURCE = '+repr(pin(DR)),'new independently reviewed driver binding')
change("VERSION = 'owned-evidence-intake-cold-v4'","VERSION = 'owned-evidence-intake-cold-v5-instrumented'",'new cold implementation profile')
constants='''
FINALIZATION_PROFILE = 'owned-finalization-phase-instrumented-v1'
COLD_OBSERVATION_BYTES = 262144
COLD_OBSERVATION_PHASES = (
    'owned-adapter-boundary-diagnostics','driver_run','driver_return_custody',
    'ordinary_result_raw_read','forest_raw_read','forest_JSON_parse',
    'saved_forest_full_comparison','independent_prepare','independent_stream_and_compare',
    'old_result_decode','old_canonical_roundtrip','whole_point_verification',
    'current_native_ledger_join','final_result_checks')

'''
change('\n\nclass ColdError(ValueError):',constants+'\nclass ColdError(ValueError):','bounded out-of-band cold observation constants')
helpers='''
def new_cold_observation():
    """Ordinary metadata only. No observations enter scientific result roots."""
    return dict(schema='owned-cold-phase-observation-v1',profile=FINALIZATION_PROFILE,
        authority=False,mathematical_authority=False,resource_authority=False,
        clock='absolute Source-entry monotonic nanoseconds',phases=[],
        counts=dict(overall_tick_invocations=0,source_guard_invocations=0,
                    source_guard_completed=0,source_guard_failed=0,
                    source_guard_timed_intervals=0,source_guard_elapsed_ns=0),
        diagnostic_errors=0,truncated=False,inverse_statistics=None,
        scope='Local cold callback counts only; no Arena/adapter dispatch-origin or public/completion inference. Nested phases/guard intervals overlap and must not be summed as disjoint costs.')


def _diagnostic_error(observation):
    try:observation['diagnostic_errors']+=1
    except BaseException:pass


def _diagnostic_clock(observation):
    try:
        value=_NOW_NS()
        if type(value)is not int or value<0:raise ValueError('diagnostic clock')
        return value
    except BaseException:
        _diagnostic_error(observation);return None


def cold_phase_begin(observation,name,stamp=None):
    if observation is None:return
    try:
        if name not in COLD_OBSERVATION_PHASES or len(observation['phases'])>=32:
            observation['truncated']=True;return
        if stamp is None:stamp=_diagnostic_clock(observation)
        observation['phases'].append(dict(phase=name,started_ns=stamp,returned_ns=None,
            state='IN_PROGRESS',error_type=None,opened_at_failure_ns=None))
    except BaseException:_diagnostic_error(observation)


def cold_phase_end(observation,name,stamp=None):
    if observation is None:return
    try:
        row=next(r for r in reversed(observation['phases'])if r['phase']==name and r['state']=='IN_PROGRESS')
        if stamp is None:stamp=_diagnostic_clock(observation)
        row['returned_ns']=stamp;row['state']='RETURNED'
    except BaseException:_diagnostic_error(observation)


def cold_phase_failure(observation,error):
    """Best effort, never a replacement for the active primary exception."""
    if observation is None:return
    try:
        stamp=_diagnostic_clock(observation)
        for row in observation['phases']:
            if row['state']=='IN_PROGRESS':
                row['state']='OPEN_AT_FAILURE';row['error_type']=type(error).__name__
                row['opened_at_failure_ns']=stamp
    except BaseException:_diagnostic_error(observation)


def cold_count(observation,name):
    try:observation['counts'][name]+=1
    except BaseException:_diagnostic_error(observation)


def cold_guard_finished(observation,started,failed):
    try:
        cold_count(observation,'source_guard_failed'if failed else'source_guard_completed')
        ended=_diagnostic_clock(observation)
        if started is not None and ended is not None and ended>=started:
            observation['counts']['source_guard_elapsed_ns']+=ended-started
            observation['counts']['source_guard_timed_intervals']+=1
        else:_diagnostic_error(observation)
    except BaseException:_diagnostic_error(observation)


def cold_observation_snapshot(observation):
    """Fresh bounded ordinary snapshot; no live counter alias in a header."""
    value=dict(observation)
    value['snapshot_cutoff_ns']=_diagnostic_clock(observation)
    value['snapshot_scope']='Through this snapshot only. Excludes later final guards, ledger/receipt serialization, cleanup and worker exit.'
    raw=canonical(value)
    need(len(raw)<=COLD_OBSERVATION_BYTES,'bounded cold observation256KiB')
    return json.loads(raw)


def bounded_driver_diagnostics(receipt,error=None):
    """No Store or inverse call; retains only existing ordinary diagnostics."""
    if receipt is not None:
        value=dict(finalization_observation=receipt.get('finalization_observation'),
            evidence_statistics=receipt.get('evidence_statistics'),
            driver_output_receipt=receipt)
    else:
        value=dict(finalization_observation=getattr(error,'owned_finalization_observation',None),
            evidence_statistics=getattr(error,'owned_evidence_statistics',None),driver_output_receipt=None)
    raw=canonical(value)
    need(len(raw)<=262144,'bounded retained driver diagnostics256KiB')
    return json.loads(raw)


'''
change('def verify_saved_evidence(inverse, wire, forest_pin, result_raw, epoch, check):',helpers+'def verify_saved_evidence(inverse, wire, forest_pin, result_raw, epoch, check, observation=None):','ordinary observation helpers and optional inverse observation API')
change('    started=_NOW_NS();observed={}\n    prepared=inverse.prepare_forest(wire,check,limits=dict(INVERSE_LIMITS),statistics=observed)',
'''    started=_NOW_NS();observed={}
    if observation is not None:observation['inverse_statistics']=observed
    cold_phase_begin(observation,'independent_prepare')
    prepared=inverse.prepare_forest(wire,check,limits=dict(INVERSE_LIMITS),statistics=observed)
    cold_phase_end(observation,'independent_prepare')''','reuse same original inverse observer with partial retention')
change("    source=prepared.iter_document(EVIDENCE_DOCUMENT);offset=0", "    cold_phase_begin(observation,'independent_stream_and_compare')\n    source=prepared.iter_document(EVIDENCE_DOCUMENT);offset=0",'separate inverse prepare/stream phases')
change('    check();stats=prepared.statistics()',"    cold_phase_end(observation,'independent_stream_and_compare')\n    check();stats=prepared.statistics()",'existing passive final inverse call unchanged')

change('    stages=[];oracle_box=[];module_guards=[];source_pins=[];artifact_pins=[]',
       '    stages=[];oracle_box=[];module_guards=[];source_pins=[];artifact_pins=[]\n    cold_observation=new_cold_observation();receipt=None','invocation-local ordinary observation and receipt retention')
change("    def overall_tick():\n        need(_NOW_NS()<overall_ns,'original total closure deadline')",
       "    def overall_tick():\n        cold_count(cold_observation,'overall_tick_invocations')\n        need(_NOW_NS()<overall_ns,'original total closure deadline')",'count existing total tick calls without new callbacks')
change("        overall_tick();start=_NOW_NS();value=action();end=_NOW_NS()",'''        overall_tick();start=_NOW_NS()
        if label=='owned-adapter-boundary-diagnostics':cold_phase_begin(cold_observation,label,stamp=start)
        value=action();end=_NOW_NS()
        if label=='owned-adapter-boundary-diagnostics':cold_phase_end(cold_observation,label,stamp=end)''','retain existing adapter diagnostic stage endpoints')
# Preserve the exact guard body inside a new nondelegating measurement envelope.
g_start=s.index('    def source_guard():\n',s.index('def main(argv):'))
g_end=s.index('\n    result_pin=None',g_start)
guard=s[g_start:g_end]
body=guard.split('\n',1)[1]
indented='\n'.join('    '+line if line else line for line in body.split('\n'))
guard_new="""    def source_guard():
        cold_count(cold_observation,'source_guard_invocations')
        guard_started=_diagnostic_clock(cold_observation)
        try:
"""+indented+"""
        except BaseException:
            cold_guard_finished(cold_observation,guard_started,True)
            raise
        else:
            cold_guard_finished(cold_observation,guard_started,False)
"""
change(guard,guard_new,'measure original full guard body, preserve same exact exception')
change("        binding=next((r for r in integration['schedule']", "        need(integration['finalization_profile']==FINALIZATION_PROFILE,\n             'explicit out-of-band instrumented finalization profile')\n        binding=next((r for r in integration['schedule']",'new explicit declaration diagnostic profile')
change("        receipt=loaded['semantic_receiver_driver'].run_receiver_owned", "        cold_phase_begin(cold_observation,'driver_run')\n        receipt=loaded['semantic_receiver_driver'].run_receiver_owned",'driver call start only')
change('        returned=_NOW_NS();source_guard();full_artifacts();checked=_NOW_NS()',
'''        returned=_NOW_NS();cold_phase_end(cold_observation,'driver_run',stamp=returned)
        cold_phase_begin(cold_observation,'driver_return_custody')
        source_guard();full_artifacts();checked=_NOW_NS()
        cold_phase_end(cold_observation,'driver_return_custody',stamp=checked)''','retain original driver return timestamp and original custody sequence')
change("receipt['version']=='semantic-family-owned-evidence-driver-v1'", "receipt['version']=='semantic-family-owned-evidence-driver-v2-instrumented'",'current exact driver receipt version')
change("        result_raw=raw_file(result_pin)\n        reading_started=", "        cold_phase_begin(cold_observation,'ordinary_result_raw_read')\n        result_raw=raw_file(result_pin)\n        cold_phase_end(cold_observation,'ordinary_result_raw_read')\n        reading_started=",'result raw read phase')
change("        forest_raw=raw_file(forest_pin)\n        forest_wire=json.loads(forest_raw)",
'''        cold_phase_begin(cold_observation,'forest_raw_read')
        forest_raw=raw_file(forest_pin)
        cold_phase_end(cold_observation,'forest_raw_read')
        cold_phase_begin(cold_observation,'forest_JSON_parse')
        forest_wire=json.loads(forest_raw)
        cold_phase_end(cold_observation,'forest_JSON_parse')''','separate forest raw read and ordinary JSON parse')
change("        evidence_verification=verify_saved_evidence(loaded[EVIDENCE_ALIASES['inverse']],forest_wire,\n            forest_pin,result_raw,epoch,evidence_tick)",
'''        cold_phase_begin(cold_observation,'saved_forest_full_comparison')
        evidence_verification=verify_saved_evidence(loaded[EVIDENCE_ALIASES['inverse']],forest_wire,
            forest_pin,result_raw,epoch,evidence_tick,observation=cold_observation)
        cold_phase_end(cold_observation,'saved_forest_full_comparison')''','optional ordinary observer, same inverse API operations')
change("        if plan['result_reader']=='builtin':\n            result_data=", "        cold_phase_begin(cold_observation,'old_result_decode')\n        if plan['result_reader']=='builtin':\n            result_data=",'old result decoder start')
change('        decoded_ns=_NOW_NS()\n        literal=verify_literal_result(result_data,result_raw,reader_tick)\n        reading_completed=_NOW_NS();source_guard()',
'''        decoded_ns=_NOW_NS();cold_phase_end(cold_observation,'old_result_decode',stamp=decoded_ns)
        cold_phase_begin(cold_observation,'old_canonical_roundtrip')
        literal=verify_literal_result(result_data,result_raw,reader_tick)
        reading_completed=_NOW_NS();cold_phase_end(cold_observation,'old_canonical_roundtrip',stamp=reading_completed)
        source_guard()''','old decoder/roundtrip calls and original timestamps preserved')
change("        region_check=(verify_raw_region(result_data,work_ns)", "        cold_phase_begin(cold_observation,'whole_point_verification')\n        region_check=(verify_raw_region(result_data,work_ns)",'whole point start')
change("                      else dict(status='NOT_CHECKED_NO_NATIVE_PROOF'))\n        source_guard()", "                      else dict(status='NOT_CHECKED_NO_NATIVE_PROOF'))\n        cold_phase_end(cold_observation,'whole_point_verification')\n        source_guard()",'whole point return no extra verifier')
change("        need(canonical(result_data['records'])==canonical(oracle_box[0].records),", "        cold_phase_begin(cold_observation,'current_native_ledger_join')\n        need(canonical(result_data['records'])==canonical(oracle_box[0].records),",'current complete Native ledger phase')
change("             'complete current Native ledger after driver closure')\n        register=", "             'complete current Native ledger after driver closure')\n        cold_phase_end(cold_observation,'current_native_ledger_join')\n        cold_phase_begin(cold_observation,'final_result_checks')\n        register=",'ledger end and full current permission checks start')
change("        origins=[]\n        for name,module", "        cold_phase_end(cold_observation,'final_result_checks')\n        retained_diagnostics=bounded_driver_diagnostics(receipt)\n        driver_observation=retained_diagnostics['finalization_observation']\n        need(type(driver_observation)is dict and driver_observation['schema']=='owned-finalization-observation-v1' and\n             driver_observation['profile']==FINALIZATION_PROFILE and driver_observation['authority']is False,\n             'exact out-of-band driver diagnostics, never authority')\n        observation_snapshot=cold_observation_snapshot(cold_observation)\n        origins=[]\n        for name,module",'owned bounded snapshot before later header/ledger/serialization costs')
change('            evidence_verification=evidence_verification,evidence_profile=EVIDENCE_PROFILE,',
       '            evidence_verification=evidence_verification,evidence_profile=EVIDENCE_PROFILE,\n            cold_observation=observation_snapshot,finalization_observation=driver_observation,','normal header detached observations counted by old ledger')
change("    except BaseException as error:\n        transport=getattr(error,'native_transport_receipt',None)", "    except BaseException as error:\n        cold_phase_failure(cold_observation,error)\n        transport=getattr(error,'native_transport_receipt',None)",'failure phase snapshot before cleanup no primary masking')
change("            prefixes=failure_output_prefixes(actual,overall_tick)\n            failure=dict", "            prefixes=failure_output_prefixes(actual,overall_tick)\n            retained_diagnostics=bounded_driver_diagnostics(receipt,error)\n            observation_snapshot=cold_observation_snapshot(cold_observation)\n            failure=dict",'failure-safe retained receipt/stats and active inverse snapshot')
change("                owned_evidence_statistics=getattr(error,'owned_evidence_statistics',None),", "                owned_evidence_statistics=retained_diagnostics['evidence_statistics'],\n                owned_finalization_observation=retained_diagnostics['finalization_observation'],\n                driver_returned_receipt=retained_diagnostics['driver_output_receipt'],\n                cold_observation=observation_snapshot,",'retain returned out-of-band diagnostics through later inverse/reader/point failure')

out=D/'owned_evidence_cold_v5.py';assert not out.exists()
ast.parse(s);compile(s,str(out),'exec');out.write_text(s)
(D/'author-transform-v1.json').write_text(json.dumps(dict(schema='owned-finalization-cold-author-transform-v1',
    source=pin(out),parent=pin(P),changes=changes,scientific_calls=0),indent=2)+'\n')
print(json.dumps(pin(out)))
