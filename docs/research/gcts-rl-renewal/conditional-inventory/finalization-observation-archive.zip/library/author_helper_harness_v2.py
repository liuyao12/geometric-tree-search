"""Raw-text/AST/metadata authoring only; never imports or calls any component."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile

D = Path('/private/tmp/gcts-finalization-instrumentation-library-20261019')
parent = D / 'qualify_finalization_harness_v1.py'
out = D / 'qualify_finalization_harness_v2.py'
old = parent.read_text()
new = old


def replace(before, after):
    global new
    if new.count(before) != 1:
        raise ValueError('nonunique raw preimage: ' + before[:80])
    new = new.replace(before, after, 1)


replace("VERSION = 'finalization-instrumentation-helper-qualification-source-v1'",
        "VERSION = 'finalization-instrumentation-helper-qualification-source-v2-prefix'")
prefix = '''def _attach_qualification_prefix(error, progress):
    """Best effort only; never replace, swallow or normalize an active error."""
    try:
        value = dict(schema='finalization-instrumentation-helper-prefix-v1',
            status='FAILED_OR_UNFINISHED', authority=False,
            mathematical_authority=False, resource_authority=False,
            full_pipeline_qualified=False, full_qualification_completed=False,
            complete_prefix_retained=True,
            completed_diagnostics=progress['diagnostics'],
            completed_fixture_count=len(progress['diagnostics']),
            active_fixture=progress['active_fixture'], stage=progress['stage'],
            expected_fixture_names=list(FIXTURE_NAMES))
        raw = _canonical(value)
        if len(raw) > RESULT_BYTES:
            raise QualificationFailure('complete qualification prefix exceeds131072 bytes')
        error.qualification_prefix = json.loads(raw)
    except BaseException as metadata_error:
        try:
            marker = dict(schema='finalization-instrumentation-helper-prefix-unavailable-v1',
                status='UNAVAILABLE', authority=False, mathematical_authority=False,
                resource_authority=False, full_pipeline_qualified=False,
                full_qualification_completed=False, complete_prefix_retained=False,
                completed_fixture_count=len(progress['diagnostics']),
                active_fixture=progress['active_fixture'], stage=progress['stage'],
                metadata_error_type=type(metadata_error).__name__[:128])
            raw = _canonical(marker)
            if len(raw) <= RESULT_BYTES:
                error.qualification_prefix = json.loads(raw)
        except BaseException:
            pass


def qualify(driver, cold, checkpoint):
    """Attach a bounded detached failure prefix, then rethrow the exact error.

    Checkpoint errors are not swallowed or normalized. The attachment-only
    catch covers initial, per-case and final checkpoints. It invokes no target
    helper or checkpoint. The internal original clock-restoration finally is
    retained; an unavailable prefix marker is never a qualification result.
    """
    progress = dict(diagnostics=[], active_fixture=None, stage='initial_checkpoint')
    try:
        return _qualify(driver, cold, checkpoint, progress)
    except BaseException as error:
        _attach_qualification_prefix(error, progress)
        raise


def _qualify(driver, cold, checkpoint, progress):
'''
replace('def qualify(driver, cold, checkpoint):\n', prefix)
replace('after every group and is never caught. No proof success can be returned here.',
        'after every group; errors are not swallowed or normalized. An attachment-only\n'
        '    outer catch rethrows the exact object. No proof success can be returned here.')
replace('    checkpoint()\n    _need(driver.OWNED_VERSION',
        "    checkpoint()\n    progress['stage'] = 'initial_validation'\n    _need(driver.OWNED_VERSION")
replace('    diagnostics = []\n    retained = {}',
        "    diagnostics = progress['diagnostics']\n    retained = {}")
replace('''    def run(name, action):
        _need(name == FIXTURE_NAMES[len(diagnostics)], 'exact declared case order')
        checkpoint()
        details = action()
        _need(type(details) is dict, 'ordinary details')
        checkpoint()
        diagnostics.append(dict(name=name, status='passed', mathematical_authority=False,
                                details=details))
''', '''    def run(name, action):
        progress['active_fixture'] = name
        progress['stage'] = 'fixture_before_checkpoint'
        _need(name == FIXTURE_NAMES[len(diagnostics)], 'exact declared case order')
        checkpoint()
        progress['stage'] = 'fixture_action'
        details = action()
        _need(type(details) is dict, 'ordinary details')
        progress['stage'] = 'fixture_after_checkpoint'
        checkpoint()
        diagnostics.append(dict(name=name, status='passed', mathematical_authority=False,
                                details=details))
        progress['active_fixture'] = None
        progress['stage'] = 'between_fixtures'
''')
replace("    _need(cold._NOW_NS is original_clock, 'sole mock slot restored exactly')\n    checkpoint()\n    result = dict",
        "    _need(cold._NOW_NS is original_clock, 'sole mock slot restored exactly')\n"
        "    progress['stage'] = 'final_checkpoint_after_clock_restore'\n    checkpoint()\n"
        "    progress['stage'] = 'result_construction'\n    result = dict")
replace("    _need(len(_canonical(result)) <= RESULT_BYTES, 'bounded complete ordinary helper result')\n"
        "    checkpoint()\n    return result\n",
        "    _need(len(_canonical(result)) <= RESULT_BYTES, 'bounded complete ordinary helper result')\n"
        "    progress['stage'] = 'result_final_checkpoint'\n    checkpoint()\n"
        "    progress['stage'] = 'returned'\n    return result\n")
if out.exists():
    raise ValueError('frozen V2 Source already exists')
out.write_text(new)


def pin(path):
    path = Path(path).resolve()
    raw = path.read_bytes()
    return dict(path=str(path), sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw))


def save(name, value):
    path = D / name
    if path.exists():
        raise ValueError('frozen metadata already exists: ' + name)
    path.write_text(json.dumps(value, sort_keys=True, ensure_ascii=False,
                               indent=2, allow_nan=False) + '\n')
    return pin(path)


oldtree = ast.parse(old)
newtree = ast.parse(new)
oldfunc = next(n for n in oldtree.body if isinstance(n, ast.FunctionDef) and n.name == 'qualify')
newfunc = next(n for n in newtree.body if isinstance(n, ast.FunctionDef) and n.name == '_qualify')
oldnested = {n.name: n for n in oldfunc.body if isinstance(n, ast.FunctionDef)}
newnested = {n.name: n for n in newfunc.body if isinstance(n, ast.FunctionDef)}
checks = []


def check(name, ok):
    checks.append(dict(name=name, passed=bool(ok)))
    if not ok:
        raise ValueError(name)


def dump(node):
    return ast.dump(node, include_attributes=False)


for name in oldnested:
    if name != 'run':
        check('unchanged complete fixture/helper AST: ' + name, dump(oldnested[name]) == dump(newnested[name]))
old_by_name = {n.name: n for n in oldtree.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}
new_by_name = {n.name: n for n in newtree.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}
for name in old_by_name:
    if name != 'qualify':
        check('unchanged inherited top-level definition AST: ' + name,
              dump(old_by_name[name]) == dump(new_by_name[name]))


class Project(ast.NodeTransformer):
    def visit_Assign(self, node):
        # Pure invocation-local progress writes are the only added body actions.
        if any(isinstance(t, ast.Subscript) and isinstance(t.value, ast.Name)
               and t.value.id == 'progress' for t in node.targets):
            return None
        if len(node.targets) == 1 and isinstance(node.targets[0], ast.Name) and node.targets[0].id == 'diagnostics':
            node.value = ast.List(elts=[], ctx=ast.Load())
        return self.generic_visit(node)


projected = Project().visit(ast.parse(new))
projection = next(n for n in projected.body if isinstance(n, ast.FunctionDef) and n.name == '_qualify')
projection.name = 'qualify'
projection.args.args.pop()
# Ignore only the changed explanatory function docstring.
projection.body[0] = oldfunc.body[0]
check('whole original qualify executable AST recovered by metadata projection', dump(projection) == dump(oldfunc))
oldnames = next(ast.literal_eval(n.value) for n in oldtree.body if isinstance(n, ast.Assign)
               and any(isinstance(t, ast.Name) and t.id == 'FIXTURE_NAMES' for t in n.targets))
newnames = next(ast.literal_eval(n.value) for n in newtree.body if isinstance(n, ast.Assign)
               and any(isinstance(t, ast.Name) and t.id == 'FIXTURE_NAMES' for t in n.targets))
check('same exact27 literal fixture names', oldnames == newnames and len(newnames) == len(set(newnames)) == 27)
old_calls = [dump(n) for n in ast.walk(oldfunc) if isinstance(n, ast.Call) and
             isinstance(n.func, ast.Name) and n.func.id == 'checkpoint']
new_calls = [dump(n) for n in ast.walk(newfunc) if isinstance(n, ast.Call) and
             isinstance(n.func, ast.Name) and n.func.id == 'checkpoint']
check('all original checkpoint sites exact no added dispatch', old_calls == new_calls)
old_finally = next(n.finalbody for n in oldfunc.body if isinstance(n, ast.Try))
new_finally = next(n.finalbody for n in newfunc.body if isinstance(n, ast.Try))
check('clock-restoration finally exact AST', dump(ast.Module(body=old_finally, type_ignores=[])) ==
      dump(ast.Module(body=new_finally, type_ignores=[])))
wrapper = new_by_name['qualify']
check('public signature unchanged', [n.arg for n in wrapper.args.args] == ['driver', 'cold', 'checkpoint'])
check('attachment-only wrapper exact bare reraise', any(isinstance(n, ast.Raise) and n.exc is None
      for n in ast.walk(wrapper)))
check('wrapper has no target/helper/checkpoint calls', sorted(n.func.id for n in ast.walk(wrapper)
      if isinstance(n, ast.Call) and isinstance(n.func, ast.Name)) ==
      ['_attach_qualification_prefix', '_qualify', 'dict'])
check('attachment has no target/helper/checkpoint calls', not any(isinstance(n, ast.Call) and
      ((isinstance(n.func, ast.Name) and n.func.id in ('checkpoint', '_qualify', 'qualify')) or
       (isinstance(n.func, ast.Attribute) and isinstance(n.func.value, ast.Name) and n.func.value.id in ('driver', 'cold')))
      for n in ast.walk(new_by_name['_attach_qualification_prefix'])))
check('all existing target-call ASTs unchanged',
      [dump(n) for n in ast.walk(oldfunc) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)
       and isinstance(n.func.value, ast.Name) and n.func.value.id in ('driver', 'cold')] ==
      [dump(n) for n in ast.walk(newfunc) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)
       and isinstance(n.func.value, ast.Name) and n.func.value.id in ('driver', 'cold')])
check('parent frozen raw pin exact', pin(parent)['sha256'] == 'd1291c030dc0b031b0d8440521bf5ce9bbee5ddf0e3c17bf6b7f4e7a7a20472d')
compile(out.read_bytes(), str(out), 'exec')
compiles = 1
forward = ''.join(difflib.unified_diff(old.splitlines(True), new.splitlines(True), fromfile='a/harness.py', tofile='b/harness.py'))
reverse = ''.join(difflib.unified_diff(new.splitlines(True), old.splitlines(True), fromfile='a/harness.py', tofile='b/harness.py'))
(D / 'harness-v1-to-v2.patch').write_text(forward)
(D / 'harness-v2-to-v1.patch').write_text(reverse)
with tempfile.TemporaryDirectory(prefix='finalization-prefix-inert-', dir='/private/tmp') as tmp:
    p = Path(tmp) / 'harness.py'
    p.write_text(old)
    subprocess.run(['patch', '-p1', '--batch'], input=forward.encode(), cwd=tmp, capture_output=True, check=True)
    check('actual inert forward exactV2', p.read_bytes() == out.read_bytes())
    compile(p.read_bytes(), str(p), 'exec');compiles += 1
    subprocess.run(['patch', '-p1', '--batch'], input=reverse.encode(), cwd=tmp, capture_output=True, check=True)
    check('actual inert inverse exactV1', p.read_bytes() == parent.read_bytes())
    compile(p.read_bytes(), str(p), 'exec');compiles += 1

api = json.loads((D / 'qualification-API-v1.json').read_bytes())
api.update(schema='finalization-instrumentation-helper-qualification-API-v2', version=2,
           Source=pin(out), unexecuted=True)
api['exceptions'] = ('No checkpoint/foreign error is swallowed or normalized. Attachment-only BaseException catch covers '
    'initial/per-fixture/final checkpoints, adds detached bounded qualification_prefix best effort, and bare reraises exact object; '
    'no target helper or checkpoint is called by attachment. Outer worker owns unfinished status/retention.')
api['failure_prefix'] = dict(attribute='qualification_prefix', cap_bytes=131072,
    schema='finalization-instrumentation-helper-prefix-v1', status='FAILED_OR_UNFINISHED',
    authority=False, mathematical_authority=False, resource_authority=False,
    full_pipeline_qualified=False, full_qualification_completed=False,
    fields=['schema', 'status', 'authority', 'mathematical_authority', 'resource_authority',
            'full_pipeline_qualified', 'full_qualification_completed', 'complete_prefix_retained',
            'completed_diagnostics', 'completed_fixture_count', 'active_fixture', 'stage', 'expected_fixture_names'],
    stages=['initial_checkpoint', 'initial_validation', 'fixture_before_checkpoint', 'fixture_action',
            'fixture_after_checkpoint', 'between_fixtures', 'final_checkpoint_after_clock_restore',
            'result_construction', 'result_final_checkpoint', 'returned'],
    semantics='Rows append only after action assertions AND its following checkpoint return; an active after-checkpoint failure never publishes that row as passed.',
    unavailable=dict(schema='finalization-instrumentation-helper-prefix-unavailable-v1', status='UNAVAILABLE',
        complete_prefix_retained=False, full_qualification_completed=False,
        detail='Small bounded own marker on metadata/cap/attachment failure, best effort; no partialsuccess or authority.'))
api['outer_obligations'].append('Retain error.qualification_prefix or unavailable marker on every failure, at bounded diagnostic-only1MiB; preserve primary exception and Source/clock checks as best effort without masking it.')
api_pin = save('qualification-API-v2.json', api)
contract_pin = save('qualification-Source-contract-v2.json', dict(
    schema='finalization-instrumentation-helper-qualification-Source-contract-v2',
    author_identity='/root/conventional_library', source_only=True, scientific_calls=0,
    fixture_calls=0, actual_execution_authorized=False, scientific_acceptance=False,
    Source=pin(out), parent=pin(parent), parent_handoff=pin(D / 'qualification-handoff-v1.json'),
    API=api_pin, target_sources=api['target_sources'],
    change_scope='Invocation-local progress metadata + detached bounded attachment-only failure prefix. Public ABI/normal result/27fixture bodies/target calls/all checkpoint sites/clock-finally exact preserved.',
    caps=dict(prefix_bytes=131072, normal_result_bytes=131072),
    limitations=['No runtime/fault/fixture qualification performed; no V1 positive Source verdict inherited.',
        'Best-effort attachment may fail on a nonassignable/custom exception; original exact exception always escapes.',
        'Metadata costs counted by later whole once protocol; prefix does not authorize any success/proof.',
        'Author wrote cold/helper harness; this is not independent own Source certification.'],
    qualification_status='FROZEN_SOURCE_ONLY_UNEXECUTED'))
audit_pin = save('qualification-author-static-audit-v2.json', dict(
    schema='finalization-instrumentation-helper-author-static-audit-v2',
    author_identity='/root/conventional_library', source_only=True, independent_review=False,
    scientific_calls=0, fixture_calls=0, component_imports=0, actual_execution_authorized=False,
    Source=pin(out), parent=pin(parent), checks=checks, static_checks=len(checks),
    mismatches=0, unused_compiles=compiles, actual_inert_patch_directions=2,
    evidence='Every existing nested fixture/helper except run exact AST. Full _qualify residual projects exactly to V1. Full target/checkpoint call ASTs and clock-restoration finally unchanged.'))
delta_pin = save('qualification-delta-v2.json', dict(
    schema='finalization-instrumentation-helper-prefix-Source-delta-v1', source_only=True,
    parent=pin(parent), Source=pin(out),
    forward=pin(D / 'harness-v1-to-v2.patch'), reverse=pin(D / 'harness-v2-to-v1.patch'),
    new_definitions=['_attach_qualification_prefix', 'qualify attachment-only wrapper'],
    renamed_original='qualify -> _qualify with invocation-local progress argument',
    no_added_target_or_checkpoint_calls=True, normal_result_unchanged=True,
    parent_coverage_matrix=pin(D / 'qualification-coverage-v1.json')))
handoff = save('qualification-handoff-v2.json', dict(
    schema='finalization-instrumentation-helper-source-handoff-v2', source_only=True,
    author_identity='/root/conventional_library', actual_execution_authorized=False,
    scientific_calls=0, fixture_calls=0, status='FROZEN_SOURCE_ONLY_UNEXECUTED',
    Source=pin(out), API=api_pin, contract=contract_pin, author_audit=audit_pin, delta=delta_pin,
    author_script=pin(__file__), targets=api['target_sources'], expected_groups=27,
    parent_handoff=pin(D / 'qualification-handoff-v1.json'),
    current_coverage='Same exact27 unexecuted action bodies; inherited matrix named above, prefix wrapper is Source-only pending independent review/qualification.'))
print(json.dumps(dict(handoff=handoff, Source=pin(out), API=api_pin, contract=contract_pin,
                     static_checks=len(checks), unused_compiles=compiles)))
