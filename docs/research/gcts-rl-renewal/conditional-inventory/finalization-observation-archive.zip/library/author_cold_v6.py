"""Preserved Source successor, metadata construction only; no target calls."""
from pathlib import Path
import ast
import hashlib
import json

D=Path(__file__).parent;P=D/'owned_evidence_cold_v5.py'
DR=Path('/private/tmp/gcts-finalization-instrumentation-ROOT-20261019/owned_evidence_receiver_driver_v6.py')
def pin(p):
    b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
assert pin(P)['sha256']=='f7b2b4127418cbb06709b8e1d5d59c95e56345d64a2b80fdca749e89f6c23635'
assert pin(DR)==dict(path=str(DR),sha256='e8ff0690472140e510f8ffab383be8c22791da6b27ef0a27fda013ea48e5f5cf',bytes=120766)
s=P.read_text();tree=ast.parse(s);changes=[]
def change(old,new,label):
    global s
    assert s.count(old)==1,(label,s.count(old))
    s=s.replace(old,new,1);changes.append(dict(label=label,old=old,new=new))
n=next(n for n in tree.body if isinstance(n,ast.Assign)and isinstance(n.targets[0],ast.Name)and n.targets[0].id=='RECEIVER_DRIVER_SOURCE')
change(ast.get_source_segment(s,n),'RECEIVER_DRIVER_SOURCE = '+repr(pin(DR)),'exact current driverV6, rejected V5 never used')
change("VERSION = 'owned-evidence-intake-cold-v5-instrumented'","VERSION = 'owned-evidence-intake-cold-v6-instrumented'",'explicit Source successor')
change("    value=dict(observation)\n    value['snapshot_cutoff_ns']=_diagnostic_clock(observation)",
       "    cutoff=_diagnostic_clock(observation)\n    value=dict(observation)\n    value['snapshot_cutoff_ns']=cutoff",'snapshot includes any timestamp-error count before detaching')
change("driver_observation['profile']==FINALIZATION_PROFILE and driver_observation['authority']is False,",
       "driver_observation['profile']==FINALIZATION_PROFILE and driver_observation['authority']is False and\n             driver_observation['completed']is True,",'normal packet must be complete; explicit unavailable marker is not complete')
helper='''
def cold_failure_diagnostics(observation,receipt,error):
    """Independent bounded fallbacks; never replace an active primary error."""
    try:driver=bounded_driver_diagnostics(receipt,error)
    except BaseException as metadata_error:
        marker=dict(schema='owned-finalization-observation-unavailable-v1',status='UNAVAILABLE',
            profile=FINALIZATION_PROFILE,authority=False,complete_ledger_retained=False,
            metadata_error_type=type(metadata_error).__name__)
        driver=dict(finalization_observation=marker,evidence_statistics=None,driver_output_receipt=None)
    try:cold=cold_observation_snapshot(observation)
    except BaseException as metadata_error:
        cold=dict(schema='owned-cold-phase-observation-unavailable-v1',status='UNAVAILABLE',
            profile=FINALIZATION_PROFILE,authority=False,complete_ledger_retained=False,
            metadata_error_type=type(metadata_error).__name__)
    return dict(driver=driver,cold_observation=cold)


'''
change('def verify_saved_evidence(inverse, wire, forest_pin, result_raw, epoch, check, observation=None):',
       helper+'def verify_saved_evidence(inverse, wire, forest_pin, result_raw, epoch, check, observation=None):',
       'failure metadata remains bounded even if a diagnostic snapshot fails')
change('            retained_diagnostics=bounded_driver_diagnostics(receipt,error)\n            observation_snapshot=cold_observation_snapshot(cold_observation)',
       "            failure_diagnostics=cold_failure_diagnostics(cold_observation,receipt,error)\n            retained_diagnostics=failure_diagnostics['driver']\n            observation_snapshot=failure_diagnostics['cold_observation']",'snapshot/cap failure cannot discard basic error packet')
change("            if hasattr(error,'add_note'):\n                error.add_note('bounded failure metadata unavailable: '+type(metadata_error).__name__)",
       "            try:\n                if hasattr(error,'add_note'):\n                    error.add_note('bounded failure metadata unavailable: '+type(metadata_error).__name__)\n            except BaseException:pass",'diagnostic note attachment cannot replace original exception')
out=D/'owned_evidence_cold_v6.py';assert not out.exists();ast.parse(s);compile(s,str(out),'exec');out.write_text(s)
(D/'author-transform-v2.json').write_text(json.dumps(dict(schema='owned-finalization-cold-author-transform-v2',parent=pin(P),source=pin(out),changes=changes,scientific_calls=0),indent=2)+'\n')
print(json.dumps(pin(out)))
