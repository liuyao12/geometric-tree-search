from pathlib import Path
import ast,hashlib,json
C=Path('/private/tmp/gcts-finalization-instrumentation-peer-20261019');D=Path('/private/tmp/gcts-finalization-instrumentation-ROOT-20261019')
def ds(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def rd(p):return json.loads(Path(p).read_bytes())
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def const(p,n):
 t=ast.parse(Path(p).read_text());return ast.literal_eval(next(x.value for x in t.body if isinstance(x,ast.Assign)and any(isinstance(z,ast.Name)and z.id==n for z in x.targets)))
checks=[]
def ck(n,v):checks.append(dict(check=n,passed=bool(v)))
m=rd(D/'false-helper-plan-manifest-v1.json');p=rd(m['plan']['path']);decl=rd(p['declaration']['path']);auth=rd(p['authorization']['path']);source=rd(C/'typed-components-Source-review-v1.json')
ck('whole offered false manifest',ds(D/'false-helper-plan-manifest-v1.json')['sha256']=='5fbdf7b1042112ffdb79b07de0fb98d0ca92184ef3645edc6389380005080e77')
ck('whole offered false plan',ds(m['plan']['path'])==m['plan']and m['plan']['sha256']=='ffc9cae2e6af04fa42b39f77c5a129ddbb507560f5cf44a3806f0be5988499d8'and m['plan']['bytes']==2551)
for role in ['declaration','authorization']:
 ck('whole current '+role,ds(p[role]['path'])==p[role]==m[role])
for role,d in m['sources'].items():
 ck('raw full Source '+role,ds(d['path'])==d==p[role]==source['sources'][role]==decl['sources'][role])
ck('whole pinned Python bytes only',ds(p['python']['path'])==p['python'])
ck('current master raw',ds(decl['master']['path'])==decl['master']==source['current_master'])
expected={'schema','invocation_id','actual_directory','python','worker','harness','driver','runner','observer','inputs','limits','cold','declaration','authorization'}
ck('exact14 planfields',set(p)==expected and p['schema']=='ROOT-finalization-helper-once-plan-v1')
subject={k:v for k,v in p.items()if k!='authorization'};sha=hashlib.sha256(canonical(subject)).hexdigest()
ck('full13 literal subject',len(subject)==13 and subject==m['subject'])
ck('subjectSHA current alljoins',sha==m['subject_sha256']==auth['subject_sha256']=='501c682448c532677101f3b6060b69ad0b85fabf219295f6aee6f3bd859259b3')
ck('falseauthorization explicit inactive',auth['actual_execution_authorized']is False and auth['scientific_acceptance']is False and auth['author_identity']=='/root'and auth['schema']=='ROOT-finalization-helper-once-authorization-v1')
ck('false one-launch upperbound no scoped receipt yet',auth['maximum_actual_invocations']==1 and auth['review_roles']=={'Source':None,'plans':None})
ck('no historical/scientific inputs',p['inputs']==[])
want=dict(work_seconds=180,overall_seconds=210,memory_bytes=1073741824,result_bytes=134217728,expanded_bytes=134217728,stdout_bytes=4194304,stderr_bytes=4194304)
ck('unchanged numeric limits',p['limits']==decl['limits']==want)
names=list(const(p['harness']['path'],'FIXTURE_NAMES'))
ck('all27 declared names exact',decl['expected_fixture_names']==names and len(names)==len(set(names))==27)
ck('normal57 max4 one worker',decl['expected_normal_checkpoint_calls']==57 and decl['maximum_helper_qualification_calls']==4 and decl['maximum_worker_invocations']==1)
wantcontrols=[dict(name='initial_checkpoint',checkpoint_ordinal=1,exception_type='RuntimeError',completed_fixture_count=0,active_fixture=None,stage='initial_checkpoint'),dict(name='after_first_completed_group',checkpoint_ordinal=4,exception_type='ValueError',completed_fixture_count=1,active_fixture=names[1],stage='fixture_before_checkpoint'),dict(name='final_checkpoint',checkpoint_ordinal=57,exception_type='StopIteration',completed_fixture_count=27,active_fixture=None,stage='result_final_checkpoint')]
ck('exact3 finite prefix controls',decl['prefix_controls']==wantcontrols and decl['expected_prefix_control_names']==[x['name']for x in wantcontrols])
ck('standalone exact clocks and resource exclusions',all(x in decl['clock_scope']for x in ['before180s','before210s','225s','excludes observer/Python prelude'])and all(x in decl['resource_scope']for x in ['Posthoc Darwin','No continuous RSS','outer/observer RSS excluded']))
ck('nonauthority and current profile',decl['profile']=='owned-finalization-phase-instrumented-v1'and decl['full_pipeline_qualified']is False and decl['proof_authority']is False and decl['actual_execution_authorized']is False)
for key in ['run_receiver_owned','_owned_atomic_output','verify_saved_evidence','real Arena/Store/inverse/Model/search/Native']:
 ck('forbidden target scope '+key,any(key in x for x in decl['forbidden_targets']))
actual=Path(p['actual_directory']);futureplan=D/'plan-authorized-v1.json';obs=D/'plan-authorized-v1-terminal-observation'
ck('canonical actual path',actual.is_absolute()and actual==actual.resolve()and actual.parent==D)
for label,path in [('actual',actual),('actual marker',actual/'CONSUMED.json'),('future authorized plan',futureplan),('future observer',obs),('observer marker',obs/'CONSUMED.json'),('trueauthorization',D/'authorization-true-v1.json')]:
 ck('fresh absent '+label,not path.exists())

# Source/stdlib evidence only, never importing ctypes or any reviewed module.
w=Path(p['worker']['path']).read_text();cold=Path(p['cold']['path']).read_text()
ctypes_path=Path('/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/lib/python3.12/ctypes/__init__.py');ct=ctypes_path.read_text()
ck('deny hook before current cold import',w.index('sys.addaudithook(audit)')<w.index("cold=load(plan['cold']")and "'ctypes.dlopen'"in w and "raise RuntimeError('production process/network/dlopen"in w)
ck('cold top-level ctypes import',any(isinstance(n,ast.Import)and any(x.name=='ctypes'for x in n.names)for n in ast.parse(cold).body))
ck('no explicit worker ctypes preload','import ctypes'not in w)
ck('bundled ctypes default pythonAPI opens self','pythonapi = PyDLL(None)'in ct and 'self._handle = _dlopen(self._name, mode)'in ct and 'class PyDLL(CDLL)'in ct and 'except OSError:\n        pythonapi = None'in ct)
assert all(x['passed']for x in checks),[x for x in checks if not x['passed']]
finding=dict(id='I1',severity='blocking',title='Audit denial conflicts with fresh stdlib ctypes import required by executed cold module',worker=p['worker'],cold=p['cold'],stdlib_Source=ds(ctypes_path),
 evidence=['Worker adds audit hook before load(driver)/load(cold); denied event ctypes.dlopen appends the event then raises RuntimeError.','Cold has top-level import ctypes. Bundled ctypes initializes pythonapi=PyDLL(None) on nonWindows/nonCygwin; inherited CDLL constructor calls _dlopen(self._name,mode) when handle is None. The initialization catches OSError only.','Official Python3.12 ctypes documentation states that library loading raises ctypes.dlopen audit event.'],
 official_documentation='https://docs.python.org/3.12/library/ctypes.html#ctypes.LibraryLoader',
 consequence='Under the declared fresh isolated startup where ctypes has not been preloaded, cold import is refused before helper qualification. Current worker does not explicitly establish a safe preload. No runtime failure is claimed; this is a raw Source/dependency custody blocker.',
 correction='Keep old Sources/plan immutable. Explicitly preload only required trusted bundled ctypes during charged worker startup before installing the process/network/dlopen denial hook, or otherwise narrowly resolve this exact stdlib import conflict while keeping later arbitrary target/fixture dlopen denied. Bind repaired worker in fresh Source/plan subjects; no cap change or runtime test is authorized by this finding.')
audit=dict(schema='finalization-helper-plan-and-import-independent-negative-audit-v1',source_only=True,scientific_calls=0,component_calls=0,fixture_calls=0,module_imports=0,checks=checks,check_count=len(checks),static_mismatch_count=0,source_blocker_count=1,findings=[finding],plan=m['plan'],declaration=p['declaration'],authorization=p['authorization'],subject=subject,subject_sha256=sha,raw_current_sources=m['sources'],stdlib_Source=ds(ctypes_path),superseded_premature_components_review=ds(C/'typed-components-Source-review-v1.json'))
ap=C/'helper-plan-and-import-negative-audit-v1.json';assert not ap.exists();ap.write_text(json.dumps(audit,sort_keys=True,indent=2)+'\n')
shared=dict(author_identities=['/root','/root/conventional_library'],reviewer_identity='/root/conventional_control_review',source_only=True,scientific_calls=0,component_calls=0,fixture_calls=0,module_imports=0,Native_calls=0,Model_calls=0,codec_replays=0,inverse_replays=0,renderer_calls=0,scientific_acceptance=False,actual_execution_authorized=False,mismatch_count=1,findings=[finding],audit=ds(ap),raw_static_check_count=len(checks),static_mismatch_count=0)
neg=dict(shared,schema='finalization-instrumentation-qualification-components-Source-review-v1',source_review_passed=False,required_subjects=list(m['sources'].values()),sources=m['sources'],supersedes=ds(C/'typed-components-Source-review-v1.json'),scope='Corrective independent Source/dependency review. Earlier cdbe receipt was premature because its six-Source body review omitted this executed stdlib initialization coupling. It remains immutable historical evidence and MUST NOT be adopted as current PASS. Driver/cold individual instrumentation reviews remain scoped; no component/runtime actions were executed.',authorship_disclosure='Root authored wrappers/driver, Library cold/harness; Control authored historical outer/control algorithms, not this worker or ctypes initialization. This is not an own-code certificate.',tools_stopped_pending_successor=True)
np=C/'typed-components-Source-review-v2-negative.json';assert not np.exists();np.write_text(json.dumps(neg,sort_keys=True,indent=2)+'\n')
pr=dict(shared,schema='finalization-instrumentation-qualification-prospective-plan-review-v1',prospective_review_passed=False,author_identity='/root',subject=subject,subject_sha256=sha,declaration=p['declaration'],false_plan=m['plan'],authorization=p['authorization'],false_manifest=ds(D/'false-helper-plan-manifest-v1.json'),components_negative_review=ds(np),freshness=dict(actual_absent=True,authorized_plan_absent=True,observer_directory_absent=True,true_authorization_absent=True),scope='Separate saved ordinary metadata review of exact thirteen-field false subject. Metadata, full pins, names, controls and fresh paths match, but the subject binds the rejected worker and therefore cannot receive a prospective PASS or grant. False authorization remains inactive with maximum1 upper bound and null roles; no actual was launched.',tools_stopped_pending_successor=True)
pp=C/'typed-prospective-plan-review-v1-negative.json';assert not pp.exists();pp.write_text(json.dumps(pr,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(components_negative=ds(np),prospective_negative=ds(pp),audit=ds(ap),checks=len(checks),blockers=1),indent=2))
