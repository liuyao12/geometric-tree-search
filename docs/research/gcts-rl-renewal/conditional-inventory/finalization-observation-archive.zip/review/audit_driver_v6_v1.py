from pathlib import Path
import ast,copy,json,hashlib,difflib
C=Path('/private/tmp/gcts-finalization-instrumentation-peer-20261019');D=Path('/private/tmp/gcts-finalization-instrumentation-ROOT-20261019');P=Path('/private/tmp/gcts-owned-evidence-integration-ROOT-20261019/owned_evidence_receiver_driver_v4.py');V5=D/'owned_evidence_receiver_driver_v5.py';N=D/'owned_evidence_receiver_driver_v6.py'
def ds(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def regions(s):return {n.name:n for n in ast.parse(s).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
def d(n):return ast.dump(n,include_attributes=False)
def isledger(n,method):return isinstance(n,ast.Call)and isinstance(n.func,ast.Attribute)and isinstance(n.func.value,ast.Name)and n.func.value.id=='finalization_observation'and n.func.attr==method
s=N.read_text();old=P.read_text();v5=V5.read_text();nr=regions(s);pr=regions(old);r5=regions(v5);checks=[]
def ck(n,v):checks.append(dict(check=n,passed=bool(v)))
ck('current offered whole raw driver',ds(N)==dict(path=str(N),sha256='e8ff0690472140e510f8ffab383be8c22791da6b27ef0a27fda013ea48e5f5cf',bytes=120766))
ck('parent raw pin',ds(P)['sha256']=='4850f66edeeb73033979ab5860ca745d5936eb3455bbef3eba10e5ba0c5ff62c')
ck('historical whole prefix exact',s.split('OWNED_VERSION=',1)[0]==old.split('OWNED_VERSION=',1)[0])
changed={n for n in pr if d(pr[n])!=d(nr[n]) or ast.get_source_segment(s,nr[n])!=ast.get_source_segment(old,pr[n])};ck('only same two changed historical definitions',changed=={'_owned_atomic_output','run_receiver_owned'})
for n in sorted(set(pr)-changed):ck('retained historical raw/AST '+n,d(pr[n])==d(nr[n]) and ast.get_source_segment(s,nr[n])==ast.get_source_segment(old,pr[n]))
ck('only declared class added',set(nr)-set(pr)=={'_OwnedFinalizationObservation'})
ck('V5 to V6 only exact three declared changed definitions',{n for n in r5 if d(r5[n])!=d(nr[n]) or ast.get_source_segment(v5,r5[n])!=ast.get_source_segment(s,nr[n])}=={'_OwnedFinalizationObservation','_owned_atomic_output','run_receiver_owned'})
class RemoveObservationalDelta(ast.NodeTransformer):
 def visit_Expr(self,n):
  if isledger(n.value,'attach')or isledger(n.value,'snapshot'):return None
  return self.generic_visit(n)
 def visit_Assign(self,n):
  if any(isinstance(t,ast.Name)and t.id=='finalization_observation'for t in n.targets):return None
  return self.generic_visit(n)
 def visit_FunctionDef(self,n):
  if n.name=='_owned_atomic_output':n.args.args=[x for x in n.args.args if x.arg!='finalization_observation']
  return self.generic_visit(n)
 def visit_Call(self,n):
  if isledger(n,'call'):
   assert len(n.args)==2 and not n.keywords
   action=n.args[1]
   return self.visit(action.body if isinstance(action,ast.Lambda)else ast.Call(func=copy.deepcopy(action),args=[],keywords=[]))
  if isinstance(n.func,ast.Name)and n.func.id=='_owned_atomic_output':n.args=[x for x in n.args if not(isinstance(x,ast.Name)and x.id=='finalization_observation')]
  if isinstance(n.func,ast.Name)and n.func.id=='dict':n.keywords=[x for x in n.keywords if x.arg!='finalization_observation']
  return self.generic_visit(n)
 def visit_Try(self,n):
  # Exactly the new attachment-only wrapper; never strip other cleanup/handlers.
  if len(n.handlers)==1 and not n.orelse and not n.finalbody:
   h=n.handlers[0]
   if isinstance(h.type,ast.Name)and h.type.id=='BaseException'and h.name=='primary'and len(h.body)==2 and isinstance(h.body[0],ast.Expr)and isledger(h.body[0].value,'attach')and isinstance(h.body[1],ast.Raise)and h.body[1].exc is None:
    return [self.visit(x)for x in n.body]
  return self.generic_visit(n)
for name in ['_owned_atomic_output','run_receiver_owned']:
 normal=RemoveObservationalDelta().visit(copy.deepcopy(nr[name]));ck('all original action AST/order retained after exact observation removal '+name,d(normal)==d(pr[name]))
# Corrected lexical binding leaves the historical proof-observation assignments intact.
def proof_assignments(t):
 return [ast.get_source_segment(t,n)for n in ast.walk(ast.parse(t))if isinstance(n,ast.Assign)and any(isinstance(x,ast.Name)and x.id=='observation'for x in n.targets)and isinstance(n.value,ast.Call)and isinstance(n.value.func,ast.Name)and n.value.func.id=='stage'and n.value.args and isinstance(n.value.args[0],ast.Constant)and n.value.args[0].value=='essential_ancestry']
ck('both exact old proof-observation assignments unchanged',proof_assignments(s)==proof_assignments(old) and len(proof_assignments(s))==2)
fn=nr['run_receiver_owned'];ledger_assign=[x for x in ast.walk(fn)if isinstance(x,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='finalization_observation'for t in x.targets)]
ck('unique ledger binding exactly once',len(ledger_assign)==1 and isinstance(ledger_assign[0].value,ast.Call)and isinstance(ledger_assign[0].value.func,ast.Name)and ledger_assign[0].value.func.id=='_OwnedFinalizationObservation')
outer=next(x for x in fn.body if isinstance(x,ast.Try)and x.orelse);wrap=outer.orelse[0];ck('whole post-scientific else one protected wrapper',len(outer.orelse)==1 and isinstance(wrap,ast.Try)and len(wrap.handlers)==1 and not wrap.orelse and not wrap.finalbody)
h=wrap.handlers[0];ck('new catch attaches only then bare-reraises',isinstance(h.type,ast.Name)and h.type.id=='BaseException'and h.name=='primary'and len(h.body)==2 and isinstance(h.body[0],ast.Expr)and isledger(h.body[0].value,'attach')and isinstance(h.body[1],ast.Raise)and h.body[1].exc is None)
ck('catch adds no oracle close/validation/cleanup calls',sum(isinstance(x,ast.Call)for x in ast.walk(h))==1)
ck('final receipt complete is protected',any(isledger(x,'complete')for x in ast.walk(wrap)) and any(isinstance(x,ast.Return)for x in wrap.body))
ledger=nr['_OwnedFinalizationObservation'];methods={x.name:x for x in ledger.body if isinstance(x,ast.FunctionDef)}
ck('non-generator exact callback path',not any(isinstance(x,(ast.Yield,ast.YieldFrom))for x in ast.walk(ledger)))
ck('record full JSON own copy and finite byte cap',all(q in ast.get_source_segment(s,methods['record'])for q in ['raw=_json(value)','len(raw)>OWNED_FINALIZATION_BYTES','return json.loads(raw)']))
ck('action call exactly once',sum(isinstance(x,ast.Call)and isinstance(x.func,ast.Name)and x.func.id=='action'for x in ast.walk(methods['call']))==1)
ck('record no callback or component action',not any(isinstance(x,ast.Call)and isinstance(x.func,ast.Attribute)and x.func.attr in ['check','guard','observe','statistics','canonical','prepare_forest']for x in ast.walk(methods['record'])))
attach=ast.get_source_segment(s,methods['attach']);ck('record failure explicit unavailable no authority marker',all(q in attach for q in ["status='UNAVAILABLE'","complete_ledger_retained=False","authority=False","mathematical_authority=False","resource_authority=False","phase_count=len(self._phases)","snapshot_count=len(self._snapshots)","except BaseException:pass"]))
ck('passive snapshots only statistics/new clocks',all(q in ast.get_source_segment(s,methods['snapshot'])for q in ['store.statistics()','self._boundary.observe()','len(raw)>8192','self._snapshots.append(json.loads(raw))']))
for name in ['OWNED_ARENA_LIMITS','OWNED_ADAPTER_LIMITS','OUTPUT_CAP_BYTES','OWNED_REGISTRY_PIN','OWNED_ADAPTER_PIN','OWNED_ARENA_PIN','OWNED_JOIN_PIN']:
 def literal(t):return next(d(x.value)for x in ast.parse(t).body if isinstance(x,ast.Assign)and any(isinstance(z,ast.Name)and z.id==name for z in x.targets))
 ck('unchanged literal cap/dependency '+name,literal(s)==literal(old))
ck('no extra imports',[d(x)for x in ast.parse(s).body if isinstance(x,(ast.Import,ast.ImportFrom))]==[d(x)for x in ast.parse(old).body if isinstance(x,(ast.Import,ast.ImportFrom))])
nd=list(difflib.ndiff(v5.splitlines(True),s.splitlines(True)));ck('actual inert V5 V6 forward/reverse',''.join(difflib.restore(nd,1))==v5 and ''.join(difflib.restore(nd,2))==s);(C/'driver-v5-v6-independent-inert-diff.txt').write_text(''.join(nd))
compile(s,str(N),'exec');ck('unused compile only',True)
failures=[x for x in checks if not x['passed']];a=dict(schema='finalization-driver-independent-Source-audit-v2',source_only=True,scientific_calls=0,component_calls=0,fixture_calls=0,module_imports=0,actual_execution_authorized=False,check_count=len(checks),mismatch_count=len(failures),checks=checks,findings=failures,inert_forward_reverse_directions=2,unused_compiles=1,source=ds(N),parent=ds(P),rejected_V5=ds(V5))
p=C/'driver-v6-Source-audit-v1.json';assert not p.exists();p.write_text(json.dumps(a,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(audit=ds(p),checks=len(checks),mismatches=len(failures),findings=failures),indent=2))
