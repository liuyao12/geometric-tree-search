from pathlib import Path
import json,hashlib,ast,copy
C=Path('/private/tmp/gcts-finalization-instrumentation-peer-20261019');L=Path('/private/tmp/gcts-finalization-instrumentation-library-20261019')
def ds(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def rd(p):return json.loads(Path(p).read_bytes())
def dump(n):return ast.dump(n,include_attributes=False)
def regions(s):return {n.name:n for n in ast.parse(s).body if isinstance(n,(ast.ClassDef,ast.FunctionDef))}
def const(s,name):return ast.literal_eval(next(n.value for n in ast.parse(s).body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id==name for t in n.targets)))
h=rd(L/'handoff-v1.json');co=rd(L/'Source-contract-v1.json');api=rd(L/'API-v1.json');delta=rd(L/'Source-delta-v1.json');s=Path(h['source']['path']).read_text();old=Path(h['parent']['path']).read_text();nr=regions(s);pr=regions(old);checks=[]
def ck(n,v):checks.append(dict(check=n,passed=bool(v)))
ck('frozen offered handoff full pin',ds(L/'handoff-v1.json')==dict(path=str(L/'handoff-v1.json'),sha256='25de12ec5ed247c05fa38eb4915113de3fbf79e5f8ab9f974e115eabb4dcacf2',bytes=2800))
for k in ['source','source_contract','API','argument','proposed_fault_cases','author_static_audit','delta','parent','current_driver','master']:ck('whole pinned packet '+k,ds(h[k]['path'])==h[k])
ck('all current Source descriptors literal agree',h['source']==co['source']==api['source']==delta['source'] and h['parent']==co['parent']==delta['parent'])
ck('current driver full pin/Source pass exact',h['current_driver']==const(s,'RECEIVER_DRIVER_SOURCE')==rd(C/'typed-driver-Source-review-v2.json')['source'] and rd(C/'typed-driver-Source-review-v2.json')['source_review_passed']is True)
changed={n for n in pr if dump(pr[n])!=dump(nr[n]) or ast.get_source_segment(old,pr[n])!=ast.get_source_segment(s,nr[n])};ck('only main and independent verifier existing bodies changed',changed=={'main','verify_saved_evidence'})
for n in sorted(set(pr)-changed):ck('retained original helper raw/AST '+n,dump(pr[n])==dump(nr[n]) and ast.get_source_segment(old,pr[n])==ast.get_source_segment(s,nr[n]))
ck('thirteen original helper regions retained',len(set(pr)-changed)==13)
ck('no import additions or observer module',[dump(n)for n in ast.parse(s).body if isinstance(n,(ast.Import,ast.ImportFrom))]==[dump(n)for n in ast.parse(old).body if isinstance(n,(ast.Import,ast.ImportFrom))])
oldassign={t.id:n.value for n in ast.parse(old).body if isinstance(n,ast.Assign)for t in n.targets if isinstance(t,ast.Name)};newassign={t.id:n.value for n in ast.parse(s).body if isinstance(n,ast.Assign)for t in n.targets if isinstance(t,ast.Name)}
for n,v in oldassign.items():
 if n not in ['VERSION','RECEIVER_DRIVER_SOURCE']:ck('unchanged existing top literal/computed declaration '+n,dump(v)==dump(newassign[n]))
ck('explicit new observation profile and detached caps',const(s,'FINALIZATION_PROFILE')=='owned-finalization-phase-instrumented-v1' and const(s,'COLD_OBSERVATION_BYTES')==262144 and len(const(s,'COLD_OBSERVATION_PHASES'))==14)
ck('new ABI helper names complete',set(nr)-set(pr)=={'new_cold_observation','_diagnostic_error','_diagnostic_clock','cold_phase_begin','cold_phase_end','cold_phase_failure','cold_count','cold_guard_finished','cold_observation_snapshot','bounded_driver_diagnostics','cold_failure_diagnostics'})
# Apply literal author transforms, not any reviewed function or generated module.
for tr in ['author-transform-v1.json','author-transform-v2.json']:
 t=rd(L/tr);base=Path(t['parent']['path']).read_text();wanted=Path(t['source']['path']).read_text();forward=base;reverse=wanted
 for change in t['changes']:
  ck('unique declared old patch anchor '+tr+'/'+change['label'],forward.count(change['old'])==1);forward=forward.replace(change['old'],change['new'],1)
 for change in reversed(t['changes']):
  ck('unique declared new patch anchor '+tr+'/'+change['label'],reverse.count(change['new'])==1);reverse=reverse.replace(change['new'],change['old'],1)
 ck('actual whole inert forward '+tr,forward==wanted);ck('actual whole inert reverse '+tr,reverse==base)
# Remove only added metadata from independent verifier; all original calls/guards remain exact.
class StripVerifierObservations(ast.NodeTransformer):
 def visit_FunctionDef(self,n):
  if n.name=='verify_saved_evidence':n.args.args=[x for x in n.args.args if x.arg!='observation'];n.args.defaults=[]
  return self.generic_visit(n)
 def visit_Expr(self,n):
  if isinstance(n.value,ast.Call)and isinstance(n.value.func,ast.Name)and n.value.func.id in ['cold_phase_begin','cold_phase_end']:return None
  return self.generic_visit(n)
 def visit_If(self,n):
  if dump(n.test)==dump(ast.parse('observation is not None',mode='eval').body):return None
  return self.generic_visit(n)
normal=StripVerifierObservations().visit(copy.deepcopy(nr['verify_saved_evidence']));ck('all original verifier AST/action/guard/completion order restored',dump(normal)==dump(pr['verify_saved_evidence']))
main=nr['main'];oldmain=pr['main'];nested={n.name:n for n in main.body if isinstance(n,ast.FunctionDef)};oldnested={n.name:n for n in oldmain.body if isinstance(n,ast.FunctionDef)}
for n in oldnested:
 if n not in ['stage','overall_tick','source_guard']:ck('unchanged nested active helper '+n,dump(nested[n])==dump(oldnested[n]))
ck('overall_tick only prefixed passive count',dump(ast.Module(body=nested['overall_tick'].body[1:],type_ignores=[]))==dump(ast.Module(body=oldnested['overall_tick'].body,type_ignores=[])))
g=nested['source_guard'];wrapped=g.body[2];ck('source guard exact original body inside timing wrapper',isinstance(wrapped,ast.Try)and dump(ast.Module(body=wrapped.body,type_ignores=[]))==dump(ast.Module(body=oldnested['source_guard'].body,type_ignores=[])))
ck('source guard failed path bare raises active object',len(wrapped.handlers)==1 and len(wrapped.handlers[0].body)==2 and isinstance(wrapped.handlers[0].body[-1],ast.Raise)and wrapped.handlers[0].body[-1].exc is None)
ck('no new callback cadence source declarations',const(s,'EVIDENCE_SOURCES')==const(old,'EVIDENCE_SOURCES') and const(s,'INVERSE_LIMITS')==const(old,'INVERSE_LIMITS') and const(s,'INVERSE_VERSION')==const(old,'INVERSE_VERSION') and const(s,'INVERSE_PROFILE')==const(old,'INVERSE_PROFILE'))
# Exact original external component operations by complete call AST, excluding only new optional metadata argument.
def component_calls(fn):
 values=[]
 for n in ast.walk(fn):
  if isinstance(n,ast.Call):
   head=ast.unparse(n.func)
   if any(x in head for x in ['run_receiver_owned','decode_result','verify_raw_region','verify_literal_result','verify_saved_evidence','verify_saved','finalize_output_ledger','failure_output_prefixes']):
    z=copy.deepcopy(n);z.keywords=[k for k in z.keywords if k.arg!='observation'];values.append(dump(z))
 return sorted(values)
ck('all existing full component/point/reader/ledger call ASTs unchanged',component_calls(main)==component_calls(oldmain))
for name in set(nr)-set(pr):ck('new metadata helper non-generator '+name,not any(isinstance(n,(ast.Yield,ast.YieldFrom))for n in ast.walk(nr[name])))
for name in ['new_cold_observation','cold_observation_snapshot','bounded_driver_diagnostics','cold_failure_diagnostics']:
 text=ast.get_source_segment(s,nr[name]);ck('ordinary metadata helper no component operations '+name,not any(w in text for w in ['prepare_forest(','iter_document(','run_receiver_owned(','decode_result(','verify_raw_region(','oracle.request(','store.statistics(']))
ck('snapshot cutoff and own detached JSON',all(t in ast.get_source_segment(s,nr['cold_observation_snapshot'])for t in ["value['snapshot_cutoff_ns']=cutoff","Excludes later final guards","len(raw)<=COLD_OBSERVATION_BYTES","return json.loads(raw)"]))
ck('driver receipt on success or original error attributes on failure',all(t in ast.get_source_segment(s,nr['bounded_driver_diagnostics'])for t in ["driver_output_receipt=receipt","getattr(error,'owned_finalization_observation',None)","getattr(error,'owned_evidence_statistics',None)","len(raw)<=262144","return json.loads(raw)"]))
ck('failure serializers have independent unavailable fallbacks',ast.get_source_segment(s,nr['cold_failure_diagnostics']).count('except BaseException as metadata_error:')==2 and "status='UNAVAILABLE'"in ast.get_source_segment(s,nr['cold_failure_diagnostics']))
ck('active inverse observer dictionary retained without replay',"observation['inverse_statistics']=observed"in ast.get_source_segment(s,nr['verify_saved_evidence'])and sum(isinstance(n,ast.Call)and isinstance(n.func,ast.Attribute)and n.func.attr=='prepare_forest'for n in ast.walk(nr['verify_saved_evidence']))==1)
ck('phase bound and open-at-failure semantics',"len(observation['phases'])>=32"in ast.get_source_segment(s,nr['cold_phase_begin'])and "row['state']='OPEN_AT_FAILURE'"in ast.get_source_segment(s,nr['cold_phase_failure']))
ck('bounded original failure packet and primary rethrow',"len(canonical(failure))+1<=1048576"in ast.get_source_segment(s,main)and isinstance(next(n for n in main.body if isinstance(n,ast.Try)).handlers[0].body[-1],ast.Raise))
ck('profile coupling and normal observation never unavailable accepted',all(t in ast.get_source_segment(s,main)for t in ["integration['finalization_profile']==FINALIZATION_PROFILE","driver_observation['completed']is True","driver_observation['authority']is False"]))
ck('proposed faults are unexecuted source design only',rd(L/'proposed-cold-fault-cases-v1.json')['status']=='SOURCE_DESIGN_ONLY_UNEXECUTED')
compile(s,h['source']['path'],'exec');ck('unused current Source compile only',True)
f=[x for x in checks if not x['passed']];a=dict(schema='owned-finalization-cold-independent-Source-audit-v1',source_only=True,scientific_calls=0,component_calls=0,fixture_calls=0,module_imports=0,actual_execution_authorized=False,check_count=len(checks),mismatch_count=len(f),checks=checks,findings=f,source=h['source'],parent=h['parent'],handoff=ds(L/'handoff-v1.json'),inert_forward_reverse_directions=4,unused_compiles=1)
p=C/'cold-v6-Source-audit-v1.json';assert not p.exists();p.write_text(json.dumps(a,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(audit=ds(p),checks=len(checks),mismatches=len(f),findings=f),indent=2))
