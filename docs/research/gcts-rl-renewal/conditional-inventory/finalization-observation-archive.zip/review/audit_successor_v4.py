from pathlib import Path
import ast,difflib,hashlib,json
C=Path('/private/tmp/gcts-finalization-instrumentation-peer-20261019');D=Path('/private/tmp/gcts-finalization-instrumentation-ROOT-20261019')
def ds(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def rd(p):return json.loads(Path(p).read_bytes())
def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def regs(s):return {n.name:n for n in ast.parse(s).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
def dump(n):return ast.dump(n,include_attributes=False)
checks=[]
def ck(n,v):checks.append(dict(check=n,passed=bool(v)))
old=rd(C/'typed-components-Source-review-v1.json');neg=rd(C/'typed-components-Source-review-v2-negative.json');m=rd(D/'false-helper-plan-manifest-v2.json');decl=rd(m['declaration']['path']);worker=m['sources']['worker'];s=Path(worker['path']).read_text();prior=Path(old['sources']['worker']['path']).read_text();st=decl['trusted_startup_stdlib_ctypes'];ct=Path(st['path']).read_text()
ck('exact workerV6 raw',ds(worker['path'])==worker and worker['sha256']=='3751bb6ee1e9bc69b698c52deac2c5479ba97f6ba24f203cb242718db56ddee8'and worker['bytes']==15924)
startup="""    # This trusted bundled stdlib import initializes pythonapi=PyDLL(None).
    # Keep it inside charged startup and before the later target/fixture
    # dlopen denial; the exact dependency is declared and raw-checked.
    startup=declaration['trusted_startup_stdlib_ctypes']
    checked(startup);checkpoint()
    import ctypes
    need(Path(ctypes.__file__).resolve()==Path(startup['path']).resolve(),
         'reviewed bundled ctypes startup origin')
    checked(startup);checkpoint()
"""
ck('literal repair block exactly once',s.count(startup)==1)
restored=s.replace(startup,'',1).replace("VERSION='finalization-instrumentation-helper-worker-v6'","VERSION='finalization-instrumentation-helper-worker-v5'",1)
ck('entire V6 reverse normalizes V5 exact',restored==prior)
ck('entire V6 forward exact',prior.replace("VERSION='finalization-instrumentation-helper-worker-v5'","VERSION='finalization-instrumentation-helper-worker-v6'",1).replace('    denied=[]\n',startup+'    denied=[]\n',1)==s)
nd=list(difflib.ndiff(prior.splitlines(True),s.splitlines(True)))
ck('actual inert forward',''.join(difflib.restore(nd,2))==s);ck('actual inert reverse',''.join(difflib.restore(nd,1))==prior)
dp=C/'helper-worker-v5-v6-independent-inert-diff.txt';assert not dp.exists() or dp.read_text()==''.join(nd);dp.write_text(''.join(nd))
for name,node in regs(prior).items():
 if name!='main':ck('retained raw/AST worker helper '+name,dump(regs(s)[name])==dump(node)and ast.get_source_segment(s,regs(s)[name])==ast.get_source_segment(prior,node))
for role,row in m['sources'].items():
 ck('all6 current whole raw '+role,ds(row['path'])==row)
 if role!='worker':ck('exact unchanged already-reviewed '+role,row==old['sources'][role])
 compile(Path(row['path']).read_text(),row['path'],'exec');ck('unused current compile '+role,True)
ck('exact declared bundled ctypes raw',ds(st['path'])==st and st['sha256']=='e048845f8f5c14a5fc873526a27da4a19d4eed25ab2f2a01fa6e0b79faca78d0'and st['bytes']==18268)
ck('whole source no project imports',all(not isinstance(n,ast.ImportFrom)or n.module in ['_ctypes','struct','types','ctypes._endian']for n in ast.parse(ct).body if isinstance(n,ast.ImportFrom)))
ck('raw bundled startup branch known',all(x in ct for x in ['pythonapi = PyDLL(None)','class PyDLL(CDLL)','self._handle = _dlopen(self._name, mode)','except OSError:\n        pythonapi = None']))
ck('startup within absolute charged180',s.index('def checkpoint():need(NOW()<work')<s.index("startup=declaration['trusted_startup_stdlib_ctypes']")and s.index('checked(startup);checkpoint()')<s.index('    import ctypes'))
ck('preload then origin then rawrecheck then denyhook',s.index('    import ctypes')<s.index('Path(ctypes.__file__).resolve()')<s.rindex('checked(startup);checkpoint()')<s.index('sys.addaudithook(audit)')<s.index("cold=load(plan['cold']"))
ck('denylist still exact unchanged',"'socket.bind','ctypes.dlopen'"in s and "raise RuntimeError('production process/network/dlopen is forbidden in finite helper qualification')"in s)
ck('no new target/helper/control actions by repair',restored==prior)
ck('decl explicit startup within charged window','Within the charged worker startup'in decl['startup_scope']and 'Later target/fixture dlopen remains denied'in decl['startup_scope']and 'no out-of-window import'in decl['startup_scope'])
ck('Root adoption explicitly rejects prematurePASS',rd(D/'ROOT-helper-startup-correction-v1.json')['Source_negative']==ds(C/'typed-components-Source-review-v2-negative.json')and rd(D/'ROOT-helper-startup-correction-v1.json')['superseded_premature_PASS']==ds(C/'typed-components-Source-review-v1.json'))
assert all(x['passed']for x in checks),[x for x in checks if not x['passed']]
sa=dict(schema='finalization-helper-repaired-startup-independent-Source-audit-v1',source_only=True,scientific_calls=0,module_imports=0,component_calls=0,fixture_calls=0,checks=checks,check_count=len(checks),mismatch_count=0,findings=[],source_subjects=m['sources'],startup_stdlib=st,inert_forward_reverse_directions=2,inert_diff=ds(dp),unused_compiles=6,retained_body_check_audit=old['audit'],retained_body_checks=151,corrected_negative=ds(C/'typed-components-Source-review-v2-negative.json'))
sap=C/'helper-startup-successor-Source-audit-v1.json';assert not sap.exists() or sap.read_text()==json.dumps(sa,sort_keys=True,indent=2)+'\n';sap.write_text(json.dumps(sa,sort_keys=True,indent=2)+'\n')
sr=dict(old);sr.update(sources=m['sources'],required_subjects=list(m['sources'].values()),audit=ds(sap),check_count=len(checks),retained_body_check_count=151,source_review_passed=True,findings=[],mismatch_count=0,inert_forward_reverse_directions=2,unused_compiles=6,startup_stdlib=st,scope='Current independent repaired six-Source Source/dependency verdict. Reuses exact retained-body mechanical checks and scoped driver/cold deltas, not the premature earlier PASS. WorkerV6 is V5 plus only explicit charged trusted bundled ctypes preload/raw origin checks before unchanged later audit denial. No module/helper/fixture/function was executed; no runtime or grant follows.',corrected_negative_reviews=old['corrected_negative_reviews']+[ds(C/'typed-components-Source-review-v2-negative.json')],supersedes_negative=ds(C/'typed-components-Source-review-v2-negative.json'),rejected_premature_review=ds(C/'typed-components-Source-review-v1.json'),Root_correction=ds(D/'ROOT-helper-startup-correction-v1.json'),retained_body_check_audit=old['audit'],current_declaration=m['declaration'])
sr['limitations']=old['limitations']+['The explicit trusted bundled ctypes preload initializes stdlib pythonapi before installing the finite audit hook and is fully charged to original work time. Its whole Python module Source is pinned/raw-checked before and after preload with exact module origin. Other bundled stdlib/C-extension loading remains a trusted runtime dependency, not an all-stdlib binary/callable seal. Later target/fixture ctypes.dlopen remains denied. This startup fix has not been run.']
sr['Source_backed_conclusions']=[x.replace('WorkerV5','WorkerV6')for x in old['Source_backed_conclusions']]+['The executed dependency conflict I1 is closed by an explicit raw-pinned bundled ctypes preload inside charged worker startup, before the unchanged audit denial and cold import. No blanket dlopen exception or scientific entry point is enabled.']
sr['tools_stopped_pending_separate_plan_review']=True
srp=C/'typed-components-Source-review-v3.json';assert not srp.exists() or srp.read_text()==json.dumps(sr,sort_keys=True,indent=2)+'\n';srp.write_text(json.dumps(sr,sort_keys=True,indent=2)+'\n')

# Distinct ordinary metadata prospective subject review follows Source verdict.
pc=[]
def pk(n,v):pc.append(dict(check=n,passed=bool(v)))
p=rd(m['plan']['path']);a=rd(m['authorization']['path']);sub={k:v for k,v in p.items()if k!='authorization'};sha=hashlib.sha256(canon(sub)).hexdigest();oldp=rd(D/'plan-false-v1.json');oldd=rd(D/'helper-qualification-declaration-v1.json')
pk('offered whole manifest pin',ds(D/'false-helper-plan-manifest-v2.json')['sha256']=='87f29588b829a6810b22ec2a173b1c1ef0c51066ec0bcbd98cdbe03838be44de')
pk('offered whole plan pin',ds(m['plan']['path'])==m['plan']and m['plan']['sha256']=='08cb849ced6402af68116f833bd5ef0d90fd4b82b57e1d909fa7368c952a204e'and m['plan']['bytes']==2551)
for key in ['declaration','authorization']:
 pk('whole '+key+' descriptor',ds(m[key]['path'])==m[key]==p[key])
for role,row in m['sources'].items():pk('current6 Source+declaration+PASS raw '+role,ds(row['path'])==row==p[role]==decl['sources'][role]==sr['sources'][role])
pk('pinned Python whole bytes only',ds(p['python']['path'])==p['python']==oldp['python'])
pk('master current same',ds(decl['master']['path'])==decl['master']==oldd['master'])
pk('stdlib current whole+decl Source-bound',ds(st['path'])==st==sr['startup_stdlib'])
expected={'schema','invocation_id','actual_directory','python','worker','harness','driver','runner','observer','inputs','limits','cold','declaration','authorization'}
pk('exact14 fields',set(p)==expected)
pk('full13literal',len(sub)==13 and sub==m['subject'])
pk('full13subjectSHA',sha==m['subject_sha256']==a['subject_sha256']=='cdc3b27b58d3852abf0f674f8eb0d97ce79871cba500a386b19e2ae193411965')
pk('exact successor plan changes only5metadatafields',{k for k in p if p[k]!=oldp[k]}=={'invocation_id','actual_directory','worker','declaration','authorization'})
pk('fresh V2 invocation/path',p['invocation_id']=='finalization-helper-ROOT-20261019-v2'and p['actual_directory']==str(D/'actual-helper-v2'))
pk('new declaration onlyworker+startup scope',set(decl)==set(oldd)|{'trusted_startup_stdlib_ctypes','startup_scope'}and {k for k in oldd if decl[k]!=oldd[k]}=={'sources'})
pk('same5 declarationSources',all(decl['sources'][k]==oldd['sources'][k]for k in decl['sources']if k!='worker'))
pk('inactive falseauthorization one upperbound',a['actual_execution_authorized']is False and a['maximum_actual_invocations']==1 and a['review_roles']=={'Source':None,'plans':None}and a['author_identity']=='/root'and a['scientific_acceptance']is False)
pk('same exact empty scientific inputs',p['inputs']==oldp['inputs']==[])
pk('all limits unchanged',p['limits']==oldp['limits']==decl['limits']==oldd['limits'])
for key in ['profile','expected_fixture_names','expected_normal_checkpoint_calls','maximum_helper_qualification_calls','maximum_worker_invocations','prefix_controls','expected_prefix_control_names','helper_target_scope','forbidden_targets','clock_scope','custody_scope','resource_scope','result_scope','full_pipeline_qualified','proof_authority']:
 pk('exact retained declaration '+key,decl[key]==oldd[key])
pk('27 names57 and4calls',len(decl['expected_fixture_names'])==27 and decl['expected_normal_checkpoint_calls']==57 and decl['maximum_helper_qualification_calls']==4)
pk('strict1/4/57 with0/1/27 rows',[x['checkpoint_ordinal']for x in decl['prefix_controls']]==[1,4,57]and [x['completed_fixture_count']for x in decl['prefix_controls']]==[0,1,27])
for label,path in [('old rejected actual',D/'actual-helper-v1'),('current actual',D/'actual-helper-v2'),('current actual consumed',D/'actual-helper-v2'/'CONSUMED.json'),('current authorized plan',D/'plan-authorized-v2.json'),('current observer',D/'plan-authorized-v2-terminal-observation'),('current observer consumed',D/'plan-authorized-v2-terminal-observation'/'CONSUMED.json'),('current truegrant',D/'authorization-true-v2.json')]:
 pk('fresh absent '+label,not path.exists())
assert all(x['passed']for x in pc),[x for x in pc if not x['passed']]
pa=dict(schema='finalization-helper-prospective-independent-audit-v2',source_only=True,scientific_calls=0,module_imports=0,component_calls=0,fixture_calls=0,checks=pc,check_count=len(pc),mismatch_count=0,findings=[],plan=m['plan'],subject=sub,subject_sha256=sha,declaration=m['declaration'],authorization=m['authorization'],Source_review=ds(srp))
pap=C/'helper-prospective-plan-audit-v2.json';assert not pap.exists();pap.write_text(json.dumps(pa,sort_keys=True,indent=2)+'\n')
pr=dict(schema='finalization-instrumentation-qualification-prospective-plan-review-v1',prospective_review_passed=True,author_identity='/root',reviewer_identity='/root/conventional_control_review',source_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,module_imports=0,component_calls=0,fixture_calls=0,codec_replays=0,inverse_replays=0,Native_calls=0,Model_calls=0,renderer_calls=0,mismatch_count=0,findings=[],subject=sub,subject_sha256=sha,declaration=m['declaration'],false_plan=m['plan'],authorization=m['authorization'],false_manifest=ds(D/'false-helper-plan-manifest-v2.json'),Source_review=ds(srp),audit=ds(pap),check_count=len(pc),startup_stdlib=st,corrected_negative=ds(C/'typed-prospective-plan-review-v1-negative.json'),scope='Distinct exact ordinary false-plan/declaration/raw Source/Python dependency-pin review only, following repaired current Source PASS. All13subject fields,27 names,57 normal checkpoint calls,3 interrupted controls, maximum4helper calls in1worker, empty inputs, unchanged caps and freshV2 paths are bound. False authorization is inactive with maximum1 upper bound/null roles. No grant, actual or finite runtime qualification is supplied.',limitations=sr['limitations'],authorship_disclosure='Root authored this metadata. Control reviewed current Source and plans in two explicitly disclosed roles with one reviewer identity; Root must separately adopt scopes/ancestry. Historical Control own algorithm overlap does not become new own-code certification.',tools_stopped_pending_true_grant_delta=True)
prp=C/'typed-prospective-plan-review-v2.json';assert not prp.exists();prp.write_text(json.dumps(pr,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(Source_review=ds(srp),Source_audit=ds(sap),Source_checks=len(checks),plan_review=ds(prp),plan_audit=ds(pap),plan_checks=len(pc),mismatch_count=0),indent=2))
