"""Passive explicit-file packaging only; imports no experimental Source."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent
PUB = ROOT.parent / 'publication'


def pin(path):
    path = Path(path)
    if path.is_symlink() or not path.is_file() or path.resolve() != path:
        raise ValueError('canonical ordinary file required')
    body = path.read_bytes()
    return dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def body(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True, allow_nan=False,
                       indent=2) + '\n').encode('ascii')


def main():
    source = ROOT / 'fpc-h1-publication-inventory-v1.json'
    inventory = json.loads(source.read_bytes())
    rows = list(inventory['selected_files'])
    rows.append(dict(**pin(source), archive_path='PUBLICATION-INVENTORY.json',
                     role='exact_nonrecursive_publication_inventory'))
    names = [row['archive_path'] for row in rows]
    if len(names) != len(set(names)) or any(
            name.startswith('/') or '..' in Path(name).parts for name in names):
        raise ValueError('unique safe explicit archive member names required')
    snapshot = dict(schema='FPC-H1-qualification-evidence-manifest-v1',
        raw_files=rows, raw_file_count=len(rows),
        raw_bytes=sum(row['bytes'] for row in rows),
        omitted_runtime=inventory['omitted_runtime'],
        qualification=inventory['qualification'],
        scope=inventory['scope'])
    snapshot_body = body(snapshot)
    archive = PUB / 'fpc-h1-qualification-evidence-v1.zip'
    manifest = PUB / 'fpc-h1-qualification-manifest-v1.json'
    if archive.exists() or manifest.exists():
        raise ValueError('exclusive new outputs required')
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED,
                         compresslevel=6) as output:
        for row in rows:
            path = Path(row['path'])
            if pin(path) != {key: row[key] for key in ('path', 'bytes', 'sha256')}:
                raise ValueError('changed selected raw body: ' + str(path))
            info = zipfile.ZipInfo(row['archive_path'], (2026, 10, 22, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            output.writestr(info, path.read_bytes())
        info = zipfile.ZipInfo('MANIFEST.json', (2026, 10, 22, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        output.writestr(info, snapshot_body)
    for row in rows:
        if pin(Path(row['path'])) != {key: row[key] for key in ('path', 'bytes', 'sha256')}:
            raise ValueError('changed source during packaging')
    sidecar = dict(snapshot,
        embedded_manifest_bytes=len(snapshot_body),
        embedded_manifest_sha256=hashlib.sha256(snapshot_body).hexdigest(),
        archive=pin(archive))
    with manifest.open('xb') as output:
        output.write(body(sidecar))
    print(json.dumps(dict(archive=pin(archive), manifest=pin(manifest),
                          raw_file_count=len(rows), zip_members=len(rows)+1)))


if __name__ == '__main__':
    main()
