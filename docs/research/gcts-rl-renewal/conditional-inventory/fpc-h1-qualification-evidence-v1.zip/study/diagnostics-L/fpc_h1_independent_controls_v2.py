"""UNRUN independent finite FPC-H1 qualification recipes.

No subject/reference imports. Declarative formulas and expected answers below
were authored before reading the subject checker. The small encoder is invoked
only by run_reference_controls inside a future exact reviewed Root actual.
No expected inference/formula is constructed by a checker or schema builder.
"""

VERSION = "FPC-H1-independent-controls-v2"

# Mathematical declarations: v variable; f function; p predicate; A forall;
# E exists; > implication; ! negation; & and | the fixed abbreviations.
P, Q, R = ("p", 0), ("p", 1), ("p", 2)
X, Y, Z = ("v", 0), ("v", 1), ("v", 2)
C = ("f", 0)
UX, UY, UC = ("p", 3, X), ("p", 3, Y), ("p", 3, C)
RXY, RYY, RZY = ("p", 4, X, Y), ("p", 4, Y, Y), ("p", 4, Z, Y)
SIGNATURE = ((0, 1), (0, 0, 0, 1, 2))
H1 = (">", P, (">", Q, P))
H2 = (">", (">", P, (">", Q, R)), (">", (">", P, Q), (">", P, R)))
H3 = (">", (">", ("!", Q), ("!", P)), (">", P, Q))
Q1 = (">", ("A", 0, UX), UC)
Q2 = (">", ("A", 0, (">", UX, Q)), (">", ("A", 0, UX), ("A", 0, Q)))
Q3 = (">", P, ("A", 0, P))
E1 = ("=", C, C)
E2 = (">", ("=", C, Y), (">", UC, UY))
IND_EQ = (">", ("&", ("=", C, C), ("A", 0, (">", ("=", X, X), ("=", ("f", 1, X), ("f", 1, X))))), ("A", 0, ("=", X, X)))
IND_PARAM = ("A", 1, (">", ("&", ("=", C, Y), ("A", 0, (">", ("=", X, Y), ("=", ("f", 1, X), Y)))), ("A", 0, ("=", X, Y))))
IND_ABSENT = ("A", 1, (">", ("&", ("=", Y, Y), ("A", 0, (">", ("=", Y, Y), ("=", Y, Y)))), ("A", 0, ("=", Y, Y))))
IND_TWO = ("A", 1, ("A", 2, (">", ("&", ("=", C, ("f", 2, Y, Z)), ("A", 0, (">", ("=", X, ("f", 2, Y, Z)), ("=", ("f", 1, X), ("f", 2, Y, Z))))), ("A", 0, ("=", X, ("f", 2, Y, Z))))))

# Positive inference recipes. Every displayed final row is a literal formula.
# recipe = id, expected status, query overrides, tuple of row records.
# row record = formula, rule name, witness tag (or None), exact payload.
CERTIFICATE_CASES = (
    ("H1-literal", "VALID_DERIVATION", {}, ((H1, "logical", 0, (P, Q)),)),
    ("H2-literal", "VALID_DERIVATION", {}, ((H2, "logical", 1, (P, Q, R)),)),
    ("H3-literal", "VALID_DERIVATION", {}, ((H3, "logical", 2, (P, Q)),)),
    ("Q1-closed-instance", "VALID_DERIVATION", {"mode": 0}, ((Q1, "logical", 3, (UX, 0, C)),)),
    ("Q2-distribution", "VALID_DERIVATION", {}, ((Q2, "logical", 4, (UX, Q, 0)),)),
    ("Q3-fresh", "VALID_DERIVATION", {}, ((Q3, "logical", 5, (P, 0)),)),
    ("E1-reflexivity", "VALID_DERIVATION", {}, ((E1, "logical", 6, (C,)),)),
    ("E1-multibyte-variable", "VALID_DERIVATION", {}, ((("=", ("v", 128), ("v", 128)), "logical", 6, (("v", 128),)),)),
    ("E2-both-free-for", "VALID_DERIVATION", {}, ((E2, "logical", 7, (UX, 0, C, Y)),)),
    ("HYP-index-one-duplicate", "VALID_DERIVATION", {"hypotheses": (P, P)}, ((P, "hyp", None, (1,)),)),
    ("MP-exact-order", "VALID_DERIVATION", {"hypotheses": (P, (">", P, Q))}, ((P, "hyp", None, (0,)), ((">", P, Q), "hyp", None, (1,)), (Q, "mp", None, (0, 1)))),
    ("GEN-global-fresh", "VALID_DERIVATION", {"hypotheses": (P,)}, ((P, "hyp", None, (0,)), (("A", 0, P), "gen", None, (0, 0)))),
    ("finite-theory-duplicate-index", "VALID_DERIVATION", {"theory": (P, P)}, ((P, "theory", 0, (1,)),)),
    ("unused-valid-prefix", "VALID_DERIVATION", {}, ((H1, "logical", 0, (P, Q)), (E1, "logical", 6, (C,)))),
    ("Q1-bound-shadow-noop", "VALID_DERIVATION", {}, (((">", ("A", 0, ("A", 0, UX)), ("A", 0, UX)), "logical", 3, (("A", 0, UX), 0, Y)),)),
    ("Q1-vacuous-under-capturing-binder", "VALID_DERIVATION", {}, (((">", ("A", 0, ("A", 1, UY)), ("A", 1, UY)), "logical", 3, (("A", 1, UY), 0, Y)),)),
    ("Q1-no-recursive-replacement", "VALID_DERIVATION", {}, (((">", ("A", 0, UX), ("p", 3, ("f", 1, X))), "logical", 3, (UX, 0, ("f", 1, X))),)),
    ("H1-wrong-association", "INVALID_CERTIFICATE", {}, (((">", (">", P, Q), P), "logical", 0, (P, Q)),)),
    ("HYP-outside", "INVALID_CERTIFICATE", {}, ((P, "hyp", None, (0,)),)),
    ("HYP-mismatched-row", "INVALID_CERTIFICATE", {"hypotheses": (Q,)}, ((P, "hyp", None, (0,)),)),
    ("MP-self-ref", "INVALID_CERTIFICATE", {}, ((P, "mp", None, (0, 0)),)),
    ("MP-forward-ref", "INVALID_CERTIFICATE", {"hypotheses": (P,)}, ((P, "mp", None, (1, 1)), (P, "hyp", None, (0,)))),
    ("MP-swapped-operands", "INVALID_CERTIFICATE", {"hypotheses": (P, (">", P, Q))}, ((P, "hyp", None, (0,)), ((">", P, Q), "hyp", None, (1,)), (Q, "mp", None, (1, 0)))),
    ("GEN-self-ref", "INVALID_CERTIFICATE", {}, ((("A", 0, P), "gen", None, (0, 0)),)),
    ("GEN-used-hypothesis-forbids", "INVALID_CERTIFICATE", {"hypotheses": (UX,)}, ((UX, "hyp", None, (0,)), (("A", 0, UX), "gen", None, (0, 0)))),
    ("GEN-unused-hypothesis-forbids", "INVALID_CERTIFICATE", {"hypotheses": (P, UX)}, ((P, "hyp", None, (0,)), (("A", 0, P), "gen", None, (0, 0)))),
    ("GEN-other-variable-allowed", "VALID_DERIVATION", {"hypotheses": (UX,)}, ((UX, "hyp", None, (0,)), (("A", 1, UX), "gen", None, (0, 1)))),
    ("Q3-free-variable-refusal", "INVALID_CERTIFICATE", {}, (((">", UX, ("A", 0, UX)), "logical", 5, (UX, 0)),)),
    ("Q1-exists-capture", "INVALID_CERTIFICATE", {}, (((">", ("A", 0, ("E", 1, RXY)), ("E", 1, RYY)), "logical", 3, (("E", 1, RXY), 0, Y)),)),
    ("E2-first-side-capture", "INVALID_CERTIFICATE", {}, (((">", ("=", Y, Z), (">", ("A", 1, RYY), ("A", 1, RZY))), "logical", 7, (("A", 1, RXY), 0, Y, Z)),)),
    ("E2-second-side-capture", "INVALID_CERTIFICATE", {}, (((">", ("=", Z, Y), (">", ("A", 1, RZY), ("A", 1, RYY))), "logical", 7, (("A", 1, RXY), 0, Z, Y)),)),
    ("final-goal-not-earlier", "INVALID_CERTIFICATE", {"goal": H1}, ((H1, "logical", 0, (P, Q)), (E1, "logical", 6, (C,)))),
    ("known-theory-wrong-profile", "INVALID_CERTIFICATE", {}, ((E1, "theory", 1, (0,)),)),
    ("finite-table-index-outside", "INVALID_CERTIFICATE", {"theory": (P,)}, ((P, "theory", 0, (1,)),)),
    ("PA-induction-closed", "VALID_DERIVATION", {"signature": ((0, 1, 2, 2), ()), "profile": 1, "mode": 0}, ((IND_EQ, "theory", 2, (("=", X, X), 0, ())),)),
    ("PA-induction-one-parameter", "VALID_DERIVATION", {"signature": ((0, 1, 2, 2), ()), "profile": 1, "mode": 0}, ((IND_PARAM, "theory", 2, (("=", X, Y), 0, (1,))),)),
    ("PA-induction-variable-absent", "VALID_DERIVATION", {"signature": ((0, 1, 2, 2), ()), "profile": 1, "mode": 0}, ((IND_ABSENT, "theory", 2, (("=", Y, Y), 0, (1,))),)),
    ("PA-induction-ascending-two-parameters", "VALID_DERIVATION", {"signature": ((0, 1, 2, 2), ()), "profile": 1, "mode": 0}, ((IND_TWO, "theory", 2, (("=", X, ("f", 2, Y, Z)), 0, (1, 2))),)),
    ("PA-induction-unsorted-two-parameters", "INVALID_CERTIFICATE", {"signature": ((0, 1, 2, 2), ()), "profile": 1}, ((IND_TWO, "theory", 2, (("=", X, ("f", 2, Y, Z)), 0, (2, 1))),)),
    ("PA-induction-missing-parameter", "INVALID_CERTIFICATE", {"signature": ((0, 1, 2, 2), ()), "profile": 1}, ((IND_PARAM, "theory", 2, (("=", X, Y), 0, ())),)),
    ("PA-induction-duplicate-parameter", "INVALID_CERTIFICATE", {"signature": ((0, 1, 2, 2), ()), "profile": 1}, ((IND_PARAM, "theory", 2, (("=", X, Y), 0, (1, 1))),)),
    ("PA-induction-extra-parameter", "INVALID_CERTIFICATE", {"signature": ((0, 1, 2, 2), ()), "profile": 1}, ((IND_EQ, "theory", 2, (("=", X, X), 0, (0,))),)),
    ("query-open-finite-axiom", "MALFORMED_INPUT", {"theory": (UX,)}, ((H1, "logical", 0, (P, Q)),)),
    ("query-theorem-hypothesis", "MALFORMED_INPUT", {"mode": 0, "hypotheses": (P,)}, ((P, "hyp", None, (0,)),)),
    ("query-theorem-open-goal", "MALFORMED_INPUT", {"mode": 0}, ((("=", X, X), "logical", 6, (X,)),)),
    ("query-PA-wrong-signature", "MALFORMED_INPUT", {"profile": 1}, ((E1, "logical", 6, (C,)),)),
    ("query-incidence-wrong-signature", "MALFORMED_INPUT", {"profile": 2}, ((E1, "logical", 6, (C,)),)),
)

# Wire anchors are manually written, not emitted by the encoder at authorship.
# Signature []/[0], profile finite, no theory/Gamma, consequence goal P.
ANCHOR_QUERY = "46 50 43 31 01 01 00 01 00 00 00 00 00 00 00"
# The positive anchor supplies the nullary P as Gamma[0] and exact goal.
RAW_CASES = (
    ("raw-HYP-positive", "46 50 43 31 01 01 00 01 00 00 00 01 00 00 00 00 00 00", "46 50 50 31 01 00 00 00 00 00", "VALID_DERIVATION"),
    ("raw-zero-rows", ANCHOR_QUERY, "4650503100", "MALFORMED_INPUT"),
    ("raw-wrong-cert-magic", ANCHOR_QUERY, "4650503200", "MALFORMED_INPUT"),
    ("raw-overlong-row-count", ANCHOR_QUERY, "465050318100", "MALFORMED_INPUT"),
    ("raw-unterminated-query-natural", "4650433180", "4650503100", "MALFORMED_INPUT"),
    ("raw-wrong-query-version", "46 50 43 31 02 01 00 01 00 00 00 00 00 00 00", "4650503100", "MALFORMED_INPUT"),
    ("raw-query-trailing-byte", ANCHOR_QUERY + "00", "4650503100", "MALFORMED_INPUT"),
    ("raw-unknown-rule", ANCHOR_QUERY, "465050310100000009", "MALFORMED_INPUT"),
    ("raw-unknown-logical-tag", ANCHOR_QUERY, "46505031010000000108", "MALFORMED_INPUT"),
    ("raw-unknown-theory-tag", ANCHOR_QUERY, "46505031010000000204", "MALFORMED_INPUT"),
    ("raw-bad-arity-before-semantics", ANCHOR_QUERY, "465050310100000100000000", "MALFORMED_INPUT"),
    ("raw-syntax-after-invalid-row", ANCHOR_QUERY, "4650503102000000000005", "MALFORMED_INPUT"),
    ("raw-PA-empty-payload", "46 50 43 31 01 01 04 00 01 02 02 00 01 00 01 01 00 00 01 00 00", "46 50 50 31 01 01 01 00 00 01 00 00 01 06 01 00 00", "VALID_DERIVATION"),
    ("raw-PA-extra-zero-payload", "46 50 43 31 01 01 04 00 01 02 02 00 01 00 00 01 01 00 00 01 00 00", "46 50 50 31 01 01 01 00 00 01 00 00 01 06 01 00 00", "MALFORMED_INPUT"),
    ("raw-canonical-variable128", "46 50 43 31 01 01 00 00 00 00 00 01 00 80 01 00 80 01", "46 50 50 31 01 01 00 80 01 00 80 01 01 06 00 80 01", "VALID_DERIVATION"),
    ("raw-unknown-formula-tag", ANCHOR_QUERY, "46 50 50 31 01 05 00", "MALFORMED_INPUT"),
    ("raw-witness-unknown-predicate", ANCHOR_QUERY, "46 50 50 31 01 00 00 00 01 00 00 01 00 00 00 00", "MALFORMED_INPUT"),
)

# Binding expectations use flat token literals rather than the formula codec.
BINDING_CASES = (
    ("FV-free-and-bound", (">", UX, ("A", 0, UX)), Y, 0, (0,), (1,), True,
     (("imp",), ("pred", 3, 1), ("var", 1), ("all", 0), ("pred", 3, 1), ("var", 0))),
    ("FV-shadowed-twice", ("A", 0, ("A", 0, UX)), Y, 0, (), (1,), True,
     (("all", 0), ("all", 0), ("pred", 3, 1), ("var", 0))),
    ("FV-scope-restored-after-shadow", (">", ("A", 0, UX), UX), Y, 0, (0,), (1,), True,
     (("imp",), ("all", 0), ("pred", 3, 1), ("var", 0), ("pred", 3, 1), ("var", 1))),
    ("free-for-vacuous", ("A", 1, UY), Y, 0, (), (1,), True,
     (("all", 1), ("pred", 3, 1), ("var", 1))),
    ("free-for-capture", ("A", 1, RXY), Y, 0, (0,), (1,), False, None),
    ("free-for-exists-capture", ("E", 1, RXY), Y, 0, (0,), (1,), False, None),
    ("free-for-closed-term", ("A", 1, RXY), C, 0, (0,), (), True,
     (("all", 1), ("pred", 4, 2), ("fun", 0, 0), ("var", 1))),
    ("substitute-not-recursive", UX, ("f", 1, X), 0, (0,), (0,), True,
     (("pred", 3, 1), ("fun", 1, 1), ("var", 0))),
    ("substitute-free-leaf-only", (">", UX, ("A", 0, UX)), ("f", 1, X), 0, (0,), (0,), True,
     (("imp",), ("pred", 3, 1), ("fun", 1, 1), ("var", 0), ("all", 0), ("pred", 3, 1), ("var", 0))),
    ("same-ID-bound-no-capture", ("A", 0, ("A", 1, RXY)), Y, 0, (), (1,), True,
     (("all", 0), ("all", 1), ("pred", 4, 2), ("var", 0), ("var", 1))),
)


# Literal mathematical table declarations, raw-copied from this author's
# independent reference declaration, not from B core ASTs/builders/checker.
# Table positive tests share that specification; independent manual peer
# inspection is required to address correlated transcription errors.
PA_SENTENCES = (
    ("A", 0, ("!", ("=", ("f", 1, ("v", 0)), ("f", 0)))),
    ("A", 0, ("A", 1, (">", ("=", ("f", 1, ("v", 0)), ("f", 1, ("v", 1))), ("=", ("v", 0), ("v", 1))))),
    ("A", 0, ("=", ("f", 2, ("v", 0), ("f", 0)), ("v", 0))),
    ("A", 0, ("A", 1, ("=", ("f", 2, ("v", 0), ("f", 1, ("v", 1))), ("f", 1, ("f", 2, ("v", 0), ("v", 1)))))),
    ("A", 0, ("=", ("f", 3, ("v", 0), ("f", 0)), ("f", 0))),
    ("A", 0, ("A", 1, ("=", ("f", 3, ("v", 0), ("f", 1, ("v", 1))), ("f", 2, ("f", 3, ("v", 0), ("v", 1)), ("v", 0))))),
)
INCIDENCE_SENTENCES = (
    ("A", 5, ("&", ("|", ("p", 0, ("v", 5)), ("p", 1, ("v", 5))), ("!", ("&", ("p", 0, ("v", 5)), ("p", 1, ("v", 5)))))),
    ("A", 0, ("A", 3, (">", ("p", 2, ("v", 0), ("v", 3)), ("&", ("p", 0, ("v", 0)), ("p", 1, ("v", 3)))))),
    ("A", 0, ("A", 1, (">", ("&", ("p", 0, ("v", 0)), ("&", ("p", 0, ("v", 1)), ("!", ("=", ("v", 0), ("v", 1))))), ("E", 3, ("&", ("p", 1, ("v", 3)), ("&", ("p", 2, ("v", 0), ("v", 3)), ("p", 2, ("v", 1), ("v", 3)))))))),
    ("A", 0, ("A", 1, ("A", 3, ("A", 4, (">", ("&", ("p", 0, ("v", 0)), ("&", ("p", 0, ("v", 1)), ("&", ("!", ("=", ("v", 0), ("v", 1))), ("&", ("p", 1, ("v", 3)), ("&", ("p", 1, ("v", 4)), ("&", ("p", 2, ("v", 0), ("v", 3)), ("&", ("p", 2, ("v", 1), ("v", 3)), ("&", ("p", 2, ("v", 0), ("v", 4)), ("p", 2, ("v", 1), ("v", 4)))))))))), ("=", ("v", 3), ("v", 4))))))),
    ("A", 3, (">", ("p", 1, ("v", 3)), ("E", 0, ("E", 1, ("&", ("p", 0, ("v", 0)), ("&", ("p", 0, ("v", 1)), ("&", ("!", ("=", ("v", 0), ("v", 1))), ("&", ("p", 2, ("v", 0), ("v", 3)), ("p", 2, ("v", 1), ("v", 3)))))))))),
    ("E", 0, ("E", 1, ("E", 2, ("&", ("p", 0, ("v", 0)), ("&", ("p", 0, ("v", 1)), ("&", ("p", 0, ("v", 2)), ("&", ("!", ("=", ("v", 0), ("v", 1))), ("&", ("!", ("=", ("v", 0), ("v", 2))), ("&", ("!", ("=", ("v", 1), ("v", 2))), ("!", ("E", 3, ("&", ("p", 1, ("v", 3)), ("&", ("p", 2, ("v", 0), ("v", 3)), ("&", ("p", 2, ("v", 1), ("v", 3)), ("p", 2, ("v", 2), ("v", 3)))))))))))))))),
)


def _need(condition, message):
    if not condition:
        raise AssertionError(message)


def _natural(value, check):
    # Serialization only; it does not compute expected statuses or formulae.
    _need(type(value) is int and value >= 0, "fixture natural")
    result = bytearray()
    while True:
        check()
        quotient, digit = divmod(value, 128)
        result.append(digit | (128 if quotient else 0))
        if not quotient:
            return bytes(result)
        value = quotient


def _formula_bytes(formula, check):
    output, todo = bytearray(), [formula]
    while todo:
        check()
        node = todo.pop()
        tag = node[0]
        if tag == "&":
            todo.append(("!", (">", node[1], ("!", node[2]))))
        elif tag == "|":
            todo.append((">", ("!", node[1]), node[2]))
        elif tag == "E":
            todo.append(("!", ("A", node[1], ("!", node[2]))))
        elif tag in ("v", "f", "p"):
            output.extend(_natural({"v": 0, "f": 1, "p": 0}[tag], check))
            output.extend(_natural(node[1], check))
            if tag != "v":
                output.extend(_natural(len(node) - 2, check))
                for child in reversed(node[2:]):
                    check()
                    todo.append(child)
        elif tag == "A":
            output.extend(_natural(4, check))
            output.extend(_natural(node[1], check))
            todo.append(node[2])
        else:
            output.extend(_natural({"=": 1, "!": 2, ">": 3}[tag], check))
            for child in reversed(node[1:]):
                check()
                todo.append(child)
    return bytes(output)


def _serialize_recipe(overrides, rows, check):
    signature = overrides.get("signature", SIGNATURE)
    profile = overrides.get("profile", 0)
    query = bytearray(b"FPC1")
    query.extend(_natural(1, check))
    query.extend(_natural(overrides.get("mode", 1), check))
    for arities in signature:
        check()
        query.extend(_natural(len(arities), check))
        for arity in arities:
            check()
            query.extend(_natural(arity, check))
    query.extend(_natural(profile, check))
    if profile == 0:
        theory = overrides.get("theory", ())
        query.extend(_natural(len(theory), check))
        for formula in theory:
            check()
            query.extend(_formula_bytes(formula, check))
    hypotheses = overrides.get("hypotheses", ())
    query.extend(_natural(len(hypotheses), check))
    for formula in hypotheses:
        check()
        query.extend(_formula_bytes(formula, check))
    query.extend(_formula_bytes(overrides.get("goal", rows[-1][0]), check))
    certificate = bytearray(b"FPP1")
    certificate.extend(_natural(len(rows), check))
    logical_fields = (("F", "F"), ("F", "F", "F"), ("F", "F"),
                      ("F", "N", "T"), ("F", "F", "N"), ("F", "N"),
                      ("T",), ("F", "N", "T", "T"))
    for formula, rule, witness, payload in rows:
        check()
        certificate.extend(_formula_bytes(formula, check))
        certificate.extend(_natural({"hyp": 0, "logical": 1, "theory": 2, "mp": 3, "gen": 4}[rule], check))
        if rule in ("logical", "theory"):
            certificate.extend(_natural(witness, check))
        if rule == "logical":
            for field, value in zip(logical_fields[witness], payload):
                check()
                certificate.extend(_natural(value, check) if field == "N" else _formula_bytes(value, check))
        elif rule == "theory" and witness == 2:
            certificate.extend(_formula_bytes(payload[0], check))
            certificate.extend(_natural(payload[1], check))
            certificate.extend(_natural(len(payload[2]), check))
            for variable in payload[2]:
                check()
                certificate.extend(_natural(variable, check))
        else:
            for value in payload:
                check()
                certificate.extend(_natural(value, check))
    return bytes(query), bytes(certificate)


def _envelope(query, certificate, check):
    return b"FPI1" + _natural(len(query), check) + query + _natural(len(certificate), check) + certificate + b"END1"


def _fault_control(function, arguments, sentinel, threshold, check):
    calls, caught = [0], False
    second = RuntimeError("second scripted callback fault must not replace first")

    def fault():
        check()
        calls[0] += 1
        if calls[0] == threshold:
            raise sentinel
        if calls[0] == threshold + 1:
            raise second

    try:
        function(*arguments, check=fault)
    except BaseException as error:
        # Identity first: a genuine unexpected callback E must escape before
        # any subsequent check could replace it with another callback F.
        if error is not sentinel:
            raise
        caught = True
    check()
    _need(caught, "callback fault not reached/propagated")
    _need(calls[0] == threshold, "continued after callback fault")
    return dict(reached_callback=threshold, identity_preserved=True, calls=calls[0])


def _retained_invoke(reference, entry, query, certificate, envelope, formula, term, callback):
    if entry == "certificate":
        return reference.reference_check_certificate(query, certificate, check=callback)
    if entry == "envelope":
        return reference.reference_check_envelope(envelope, check=callback)
    return reference.inspect_binding(formula, term, 0, *SIGNATURE, check=callback)


def _retained_owned_controls(reference, query, certificate, check):
    """Three fixed groups; sweep every baseline callback of each tiny public API.

    The baseline is a hand-authored valid H1/UX-to-UY observation, not a schema
    answer generator. Each baseline must complete within the declared 1024
    callback ceiling; otherwise the entire bank fails, with no skipped suffix.
    """
    envelope = _envelope(query, certificate, check)
    formula, term = _formula_bytes(UX, check), _formula_bytes(Y, check)
    rows = []
    for entry in ("certificate", "envelope", "binding"):
        check()
        retained = None
        try:
            # A genuine refusal obtained through a public API, no token
            # forging/private call. Its owner belongs to this earlier call.
            reference.inspect_binding(b"", b"", -1, (), (), check=check)
        except BaseException as error:
            if not reference.is_owned_error(error):
                raise
            retained = error
        check()
        _need(retained is not None, "missing genuine retained owned refusal")
        original = (retained.status, retained.component, retained.reason, retained.row)
        baseline = [0]

        def count_baseline():
            check()
            baseline[0] += 1
            _need(baseline[0] <= 1024, "retained regression baseline callback ceiling")

        result = _retained_invoke(reference, entry, query, certificate, envelope, formula, term, count_baseline)
        if entry == "binding":
            _need(result == dict(formula_free_variables=[0], term_free_variables=[1], free_for=True,
                                 substituted_prefix_tokens=(("pred", 3, 1), ("var", 1))), "binding regression baseline")
        else:
            _need(result["status"] == "VALID_DERIVATION", "retained regression baseline status")
        _need(0 < baseline[0] <= 1024, "retained regression empty baseline")
        positions = []
        for threshold in range(1, baseline[0] + 1):
            check()
            calls, caught = [0], False
            later = RuntimeError("later callback F cannot replace retained first E")

            def fault():
                check()
                calls[0] += 1
                if calls[0] == threshold:
                    raise retained
                if calls[0] > threshold:
                    raise later

            try:
                _retained_invoke(reference, entry, query, certificate, envelope, formula, term, fault)
            except BaseException as error:
                if error is not retained:
                    raise
                caught = True
            check()
            _need(caught and calls[0] == threshold, "retained first fault swallowed/replaced/continued")
            _need((retained.status, retained.component, retained.reason, retained.row) == original,
                  "retained owned refusal metadata mutated")
            positions.append(dict(callback_ordinal=threshold, identical_first_fault=True,
                                  retained_attributes_unchanged=True, no_later_callback=True))
        rows.append(dict(id="retained-owned-" + entry + "-every-callback", passed=True,
                         expected="IDENTICAL_RETAINED_FIRST_EXCEPTION_NO_MUTATION",
                         baseline_callbacks=baseline[0], declared_callback_ceiling=1024,
                         fault_positions=positions,
                         scope="Every callback on this tiny public path, including certificate inference/receipt and nested envelope-to-certificate calls; no proof qualification."))
    return rows


def run_reference_controls(subject, reference, *, subject_refusal_type, check):
    """Actual-only. Subject and reference supplied by a future exact Root worker."""
    receipts = []
    for case_id, expected, overrides, rows in CERTIFICATE_CASES:
        check()
        query, certificate = _serialize_recipe(overrides, rows, check)
        pair = []
        for role, function in (("subject", subject.check_certificate), ("reference", reference.reference_check_certificate)):
            check()
            observed = function(query, certificate, check=check)
            _need(observed["status"] == expected, case_id + ": " + role)
            pair.append(dict(role=role, receipt=observed))
        receipts.append(dict(id=case_id, expected=expected, query_hex=query.hex(), certificate_hex=certificate.hex(), receipts=pair, passed=True))
    for case_id, query_hex, certificate_hex, expected in RAW_CASES:
        check()
        query, certificate = bytes.fromhex(query_hex), bytes.fromhex(certificate_hex)
        pair = []
        for role, function in (("subject", subject.check_certificate), ("reference", reference.reference_check_certificate)):
            check()
            observed = function(query, certificate, check=check)
            _need(observed["status"] == expected, case_id + ": " + role)
            pair.append(dict(role=role, receipt=observed))
        receipts.append(dict(id=case_id, expected=expected, query_hex=query_hex, certificate_hex=certificate_hex, receipts=pair, passed=True))
    # All twelve fixed table literals, with their declared binder IDs and exact
    # right-associated abbreviations. Never call a subject table/builder here.
    for profile, signature, name, sentences, witness in (
            (1, ((0, 1, 2, 2), ()), "PA", PA_SENTENCES, 1),
            (2, ((), (1, 1, 2)), "HI", INCIDENCE_SENTENCES, 3)):
        for index, formula in enumerate(sentences):
            check()
            case_id = name + "-table-" + str(index)
            query, certificate = _serialize_recipe(dict(signature=signature, profile=profile, mode=0),
                                                  ((formula, "theory", witness, (index,)),), check)
            pair = []
            for role, function in (("subject", subject.check_certificate), ("reference", reference.reference_check_certificate)):
                check()
                observed = function(query, certificate, check=check)
                _need(observed["status"] == "VALID_DERIVATION", case_id + ": " + role)
                pair.append(dict(role=role, receipt=observed))
            receipts.append(dict(id=case_id, expected="VALID_DERIVATION", query_hex=query.hex(), certificate_hex=certificate.hex(), receipts=pair, passed=True))
        # The row is syntactically valid and closed; index six is semantic.
        query, certificate = _serialize_recipe(dict(signature=signature, profile=profile, mode=0),
                                              ((sentences[0], "theory", witness, (6,)),), check)
        pair = []
        for role, function in (("subject", subject.check_certificate), ("reference", reference.reference_check_certificate)):
            check()
            observed = function(query, certificate, check=check)
            _need(observed["status"] == "INVALID_CERTIFICATE", name + " index six: " + role)
            pair.append(dict(role=role, receipt=observed))
        receipts.append(dict(id=name + "-table-outside", expected="INVALID_CERTIFICATE", query_hex=query.hex(), certificate_hex=certificate.hex(), receipts=pair, passed=True))
    for case_id, formula, term, variable, fvs, tvs, permitted, tokens in BINDING_CASES:
        check()
        formula_bytes, term_bytes = _formula_bytes(formula, check), _formula_bytes(term, check)
        observed = reference.inspect_binding(formula_bytes, term_bytes, variable, *SIGNATURE, check=check)
        expected = dict(formula_free_variables=list(fvs), term_free_variables=list(tvs), free_for=permitted, substituted_prefix_tokens=tokens)
        _need(observed == expected, case_id)
        receipts.append(dict(id=case_id, expected=expected, observed=observed, formula_hex=formula_bytes.hex(), term_hex=term_bytes.hex(), passed=True))
    # Envelope tests use a fixed valid H1 recipe; no inference is synthesized.
    query, certificate = _serialize_recipe({}, ((H1, "logical", 0, (P, Q)),), check)
    good = _envelope(query, certificate, check)
    envelope_cases = (("envelope-valid", good, "VALID_DERIVATION"),
                      ("envelope-extra-EOF", good + b"\x00", "MALFORMED_INPUT"),
                      ("envelope-wrong-trailer", good[:-4] + b"END2", "MALFORMED_INPUT"),
                      ("envelope-truncated", good[:-1], "MALFORMED_INPUT"),
                      ("envelope-slice-local-EOF", _envelope(query + b"\x00", certificate, check), "MALFORMED_INPUT"),
                      ("envelope-wrapper-priority", b"FPI1\x00\x00END2", "MALFORMED_INPUT"))
    for case_id, body, expected in envelope_cases:
        check()
        pair = []
        for role, function in (("subject", subject.check_envelope), ("reference", reference.reference_check_envelope)):
            check()
            observed = function(body, check=check)
            _need(observed["status"] == expected, case_id + ": " + role)
            pair.append(dict(role=role, receipt=observed))
        receipts.append(dict(id=case_id, expected=expected, envelope_hex=body.hex(), receipts=pair, passed=True))
    for role, function in (("subject", subject.check_certificate), ("reference", reference.reference_check_certificate)):
        for label, bad_query, bad_certificate in (
                ("bytearray-query", bytearray(query), certificate),
                ("bytearray-certificate", query, bytearray(certificate)),
                ("string-query", "FPC1", certificate),
                ("bool-certificate", query, False)):
            check()
            observed = function(bad_query, bad_certificate, check=check)
            _need(observed["status"] == "MALFORMED_INPUT", role + " intake " + label)
            receipts.append(dict(id="intake-" + role + "-" + label, expected="MALFORMED_INPUT", receipt=observed, passed=True))
    _need(isinstance(subject_refusal_type, type) and issubclass(subject_refusal_type, BaseException), "subject public refusal class")
    for role, certificate_function, envelope_function, refusal_type in (
            ("subject", subject.check_certificate, subject.check_envelope, subject_refusal_type),
            ("reference", reference.reference_check_certificate, reference.reference_check_envelope, reference.ReferenceRefusal)):
        for label, exception_type in (("ValueError", ValueError), ("RuntimeError", RuntimeError),
                                      ("StopIteration", StopIteration), ("same-public-class-unowned", refusal_type)):
            for threshold in (1, 2, 7):
                check()
                sentinel = exception_type("unowned one-shot callback sentinel")
                observed = _fault_control(certificate_function, (query, certificate), sentinel, threshold, check)
                receipts.append(dict(id="foreign-" + role + "-" + label + "-" + str(threshold), expected="IDENTICAL_EXCEPTION", observed=observed, passed=True))
            check()
            sentinel = exception_type("unowned envelope callback sentinel")
            observed = _fault_control(envelope_function, (good,), sentinel, 2, check)
            receipts.append(dict(id="foreign-envelope-" + role + "-" + label, expected="IDENTICAL_EXCEPTION", observed=observed, passed=True))
    # The original 134 recipes/expectations and their order remain exact.
    receipts.extend(_retained_owned_controls(reference, query, certificate, check))
    return dict(schema=VERSION, status="COMPLETE", controls=receipts,
                control_count=len(receipts), original_control_count=134,
                added_retained_owned_groups=3, complete=True,
                scope="Finite hand-authored checker qualification fixtures; no searched theorem, formal soundness/completeness or machine certificate.")
