"""Source-only offer: future Root-reviewed bounded finite-byte checker qualification.

Only a consumed once plan may enter main. No worker/subject/bank has been run
while authoring this Source. This is not proof search or a security sandbox.
"""
from pathlib import Path
import hashlib
import importlib.util
import json
import math
import os
import resource
import sys
import time
import traceback

VERSION = 'FPC-H1-qualification-worker-v1'
CASE_ID = 'qualify-fpc-h1-0'
EXPERIMENT = 'FPC-H1-finite-byte-qualification-v1'
SUBJECT = (31557, '140a9c4b7a6a18c4c20aa4294a0f3fa90f65fe319adbf47a22125170f32b2ef7')
REFERENCE = (24681, 'ecda2a10feb69e5aed6ae34dc6c2123dbbc3297ab5c0a431861d628e9cd4334a')
BANK = (30818, 'ea20ce491d27d1768473ff113706e70a8100d509e54166d79e908c0a77332978')
CAPS = dict(work_seconds=160, positive_seconds=180, custody_seconds=210,
            observer_fallback_seconds=225, memory_bytes=1073741824,
            physical_bytes=134217728, result_bytes=50331648,
            log_bytes=4194304, reserved_outer_bytes=9437184,
            root_callbacks=400000000)


CONTROL_IDS = (
    'H1-literal',
    'H2-literal',
    'H3-literal',
    'Q1-closed-instance',
    'Q2-distribution',
    'Q3-fresh',
    'E1-reflexivity',
    'E1-multibyte-variable',
    'E2-both-free-for',
    'HYP-index-one-duplicate',
    'MP-exact-order',
    'GEN-global-fresh',
    'finite-theory-duplicate-index',
    'unused-valid-prefix',
    'Q1-bound-shadow-noop',
    'Q1-vacuous-under-capturing-binder',
    'Q1-no-recursive-replacement',
    'H1-wrong-association',
    'HYP-outside',
    'HYP-mismatched-row',
    'MP-self-ref',
    'MP-forward-ref',
    'MP-swapped-operands',
    'GEN-self-ref',
    'GEN-used-hypothesis-forbids',
    'GEN-unused-hypothesis-forbids',
    'GEN-other-variable-allowed',
    'Q3-free-variable-refusal',
    'Q1-exists-capture',
    'E2-first-side-capture',
    'E2-second-side-capture',
    'final-goal-not-earlier',
    'known-theory-wrong-profile',
    'finite-table-index-outside',
    'PA-induction-closed',
    'PA-induction-one-parameter',
    'PA-induction-variable-absent',
    'PA-induction-ascending-two-parameters',
    'PA-induction-unsorted-two-parameters',
    'PA-induction-missing-parameter',
    'PA-induction-duplicate-parameter',
    'PA-induction-extra-parameter',
    'query-open-finite-axiom',
    'query-theorem-hypothesis',
    'query-theorem-open-goal',
    'query-PA-wrong-signature',
    'query-incidence-wrong-signature',
    'raw-HYP-positive',
    'raw-zero-rows',
    'raw-wrong-cert-magic',
    'raw-overlong-row-count',
    'raw-unterminated-query-natural',
    'raw-wrong-query-version',
    'raw-query-trailing-byte',
    'raw-unknown-rule',
    'raw-unknown-logical-tag',
    'raw-unknown-theory-tag',
    'raw-bad-arity-before-semantics',
    'raw-syntax-after-invalid-row',
    'raw-PA-empty-payload',
    'raw-PA-extra-zero-payload',
    'raw-canonical-variable128',
    'raw-unknown-formula-tag',
    'raw-witness-unknown-predicate',
    'PA-table-0',
    'PA-table-1',
    'PA-table-2',
    'PA-table-3',
    'PA-table-4',
    'PA-table-5',
    'PA-table-outside',
    'HI-table-0',
    'HI-table-1',
    'HI-table-2',
    'HI-table-3',
    'HI-table-4',
    'HI-table-5',
    'HI-table-outside',
    'FV-free-and-bound',
    'FV-shadowed-twice',
    'FV-scope-restored-after-shadow',
    'free-for-vacuous',
    'free-for-capture',
    'free-for-exists-capture',
    'free-for-closed-term',
    'substitute-not-recursive',
    'substitute-free-leaf-only',
    'same-ID-bound-no-capture',
    'envelope-valid',
    'envelope-extra-EOF',
    'envelope-wrong-trailer',
    'envelope-truncated',
    'envelope-slice-local-EOF',
    'envelope-wrapper-priority',
    'intake-subject-bytearray-query',
    'intake-subject-bytearray-certificate',
    'intake-subject-string-query',
    'intake-subject-bool-certificate',
    'intake-reference-bytearray-query',
    'intake-reference-bytearray-certificate',
    'intake-reference-string-query',
    'intake-reference-bool-certificate',
    'foreign-subject-ValueError-1',
    'foreign-subject-ValueError-2',
    'foreign-subject-ValueError-7',
    'foreign-envelope-subject-ValueError',
    'foreign-subject-RuntimeError-1',
    'foreign-subject-RuntimeError-2',
    'foreign-subject-RuntimeError-7',
    'foreign-envelope-subject-RuntimeError',
    'foreign-subject-StopIteration-1',
    'foreign-subject-StopIteration-2',
    'foreign-subject-StopIteration-7',
    'foreign-envelope-subject-StopIteration',
    'foreign-subject-same-public-class-unowned-1',
    'foreign-subject-same-public-class-unowned-2',
    'foreign-subject-same-public-class-unowned-7',
    'foreign-envelope-subject-same-public-class-unowned',
    'foreign-reference-ValueError-1',
    'foreign-reference-ValueError-2',
    'foreign-reference-ValueError-7',
    'foreign-envelope-reference-ValueError',
    'foreign-reference-RuntimeError-1',
    'foreign-reference-RuntimeError-2',
    'foreign-reference-RuntimeError-7',
    'foreign-envelope-reference-RuntimeError',
    'foreign-reference-StopIteration-1',
    'foreign-reference-StopIteration-2',
    'foreign-reference-StopIteration-7',
    'foreign-envelope-reference-StopIteration',
    'foreign-reference-same-public-class-unowned-1',
    'foreign-reference-same-public-class-unowned-2',
    'foreign-reference-same-public-class-unowned-7',
    'foreign-envelope-reference-same-public-class-unowned',
    'retained-owned-certificate-every-callback',
    'retained-owned-envelope-every-callback',
    'retained-owned-binding-every-callback',
)


class RootBudget(RuntimeError):
    """Only the worker's genuine cumulative Root checkpoint creates this."""


def raw_pin(path):
    path = Path(path)
    if not path.is_absolute() or path.is_symlink() or path.resolve() != path or not path.is_file():
        raise ValueError('canonical ordinary complete raw file required')
    if '.partial' in path.name:
        raise ValueError('partial bodies are never read by this worker')
    body = path.read_bytes()
    return dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def pin_fields(row):
    if not (type(row) is dict and {'path', 'bytes', 'sha256'} <= set(row)
            and type(row['path']) is str and type(row['bytes']) is int
            and row['bytes'] >= 0 and type(row['sha256']) is str
            and len(row['sha256']) == 64
            and all(c in '0123456789abcdef' for c in row['sha256'])):
        raise ValueError('typed raw pin required')
    return {key: row[key] for key in ('path', 'bytes', 'sha256')}


def serialize(value, cap):
    body = (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       allow_nan=False, separators=(',', ':')) + '\n').encode()
    if len(body) > cap:
        raise RootBudget('complete output byte ceiling; no truncation')
    return body


def write_body(path, body):
    if path.exists():
        raise ValueError('exclusive complete output required')
    temporary = path.with_name(path.name + '.partial')
    with temporary.open('xb') as stream:
        stream.write(body)
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)


def load_exact(row, name, check):
    """No sys.path extension or arbitrary plan-selected module imports."""
    check()
    if name in sys.modules or raw_pin(row['path']) != pin_fields(row):
        raise ValueError('fresh exact module bytes and unused owned module name')
    spec = importlib.util.spec_from_file_location(name, row['path'])
    if spec is None or spec.loader is None:
        raise ValueError('ordinary Python Source loader required')
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    check()
    if Path(module.__file__).resolve() != Path(row['path']) or raw_pin(row['path']) != pin_fields(row):
        raise ValueError('exact imported module origin and stable Source')
    return module


def main(plan_path, actual_dir, root_start):
    # The generic custodian passes its genuine monotonic start. Every import,
    # declaration/JSON decode, raw hash, bank operation and output allocation
    # below is inside that already-running outer clock.
    if not (sys.platform == 'darwin' and sys.flags.isolated
            and sys.flags.no_site and sys.dont_write_bytecode
            and os.getpid() == os.getpgrp()
            and type(root_start) is float and math.isfinite(root_start)
            and 0 <= root_start <= time.monotonic()):
        raise ValueError('isolated Darwin owned child and genuine parent start required')
    began = root_start
    directory = Path(actual_dir)
    plan_path = Path(plan_path)
    plan_pin = raw_pin(plan_path)
    plan_body = plan_path.read_bytes()
    if len(plan_body) != plan_pin['bytes'] or hashlib.sha256(plan_body).hexdigest() != plan_pin['sha256']:
        raise ValueError('stable exact complete plan bytes')
    plan = json.loads(plan_body)
    del plan_body
    if not (directory.is_absolute() and directory.resolve() == directory
            and not directory.is_symlink() and directory.is_dir()
            and plan['schema'] == 'proof-search-case-once-plan-v1'
            and plan['case_id'] == CASE_ID and plan['stage'] == 'qualify'
            and plan['experiment'] == EXPERIMENT and plan['required_upstream_ids'] == []
            and plan['actual_dir'] == str(directory)
            and Path(plan['worker_path']) == Path(__file__).resolve()):
        raise ValueError('exact consumed qualification plan and owned directory')
    limits = plan['limits']
    if not all(type(limits.get(key)) is int and limits[key] == value for key, value in CAPS.items()):
        raise ValueError('all unchanged original ceilings required')
    resource.setrlimit(resource.RLIMIT_FSIZE, (CAPS['physical_bytes'], CAPS['physical_bytes']))
    consumed = json.loads((directory/'CONSUMED.json').read_bytes())
    if not (consumed['schema'] == 'proof-search-case-consumed-v1'
            and consumed['plan_sha256'] == plan_pin['sha256']
            and consumed['case_id'] == CASE_ID
            and type(consumed['uses']) is int and consumed['uses'] == 1):
        raise ValueError('fresh exact once-plan consumption required')
    state = dict(stage='PIN_INTAKE', callbacks=0, first_fault=None, stages=[], versions={})
    primary = None
    qualification = None
    source_unchanged = False
    guards = []

    def check():
        if state['first_fault'] is not None:
            raise state['first_fault']
        state['callbacks'] += 1
        fault = None
        if state['callbacks'] > CAPS['root_callbacks']:
            fault = RootBudget('cumulative Root callback ceiling')
        elif time.monotonic()-began >= CAPS['work_seconds']:
            fault = RootBudget('absolute qualification work deadline')
        elif resource.getrusage(resource.RUSAGE_SELF).ru_maxrss >= CAPS['memory_bytes']:
            fault = RootBudget('strict Python high-water memory ceiling')
        if fault is not None:
            state['first_fault'] = fault
            raise fault

    def verify_files(cooperative):
        for row in guards:
            if cooperative:
                check()
            if raw_pin(row['path']) != row:
                raise ValueError('changed declared Source/input: ' + row['path'])

    def stage(name, operation):
        check()
        state['stage'] = name
        item = dict(name=name, began=time.monotonic()-began, status='STARTED')
        state['stages'].append(item)
        answer = operation()
        check()
        item.update(status='COMPLETED', seconds=time.monotonic()-began-item['began'])
        return answer

    try:
        check()
        if type(plan['files']) is not list or not plan['files']:
            raise ValueError('closed nonempty Source/metadata guard list required')
        guards = [pin_fields(row) for row in plan['files']]
        if len({row['path'] for row in guards}) != len(guards):
            raise ValueError('unique declared raw Source/metadata paths')
        by_path = {row['path']: row for row in guards}
        if not (type(plan['module_pins']) is dict and set(plan['module_pins']) == {'subject', 'reference', 'bank'}):
            raise ValueError('only exact checker, independent reference and bank module roles')
        modules = {role: pin_fields(row) for role, row in plan['module_pins'].items()}
        for role, expected in (('subject', SUBJECT), ('reference', REFERENCE), ('bank', BANK)):
            row = modules[role]
            if (row['bytes'], row['sha256']) != expected or by_path.get(row['path']) != row:
                raise ValueError('frozen checker/reference/bank Source identity and guard membership')
        for row in (pin_fields(plan['protocol']), pin_fields(plan['python'])):
            if by_path.get(row['path']) != row:
                raise ValueError('protocol and Python pin belong to closed plan guards')
        own = raw_pin(Path(__file__).resolve())
        if by_path.get(own['path']) != own or raw_pin(Path(sys.executable).resolve()) != pin_fields(plan['python']):
            raise ValueError('current worker and exact isolated Python runtime required')
        # This child binds protocol bytes, not prospective Root grant authority.
        # Exact protocol semantics/closure and grant are separate peer/Root gates.
        verify_files(True)
        subject = stage('IMPORT exact frozen byte checker', lambda: load_exact(
            modules['subject'], 'owned_fpc_h1_subject_v1', check))
        reference = stage('IMPORT exact independent reference', lambda: load_exact(
            modules['reference'], 'owned_fpc_h1_reference_v2', check))
        bank = stage('IMPORT exact independent bank', lambda: load_exact(
            modules['bank'], 'owned_fpc_h1_bank_v2', check))
        state['versions'] = dict(subject=subject.VERSION, reference=reference.VERSION, bank=bank.VERSION)
        if state['versions'] != dict(subject='FPC-H1-BYTE-CHECKER-v1',
                reference='FPC-H1-independent-flat-reference-v2', bank='FPC-H1-independent-controls-v2'):
            raise ValueError('exact declared three component versions required')
        qualification = stage('RUN all137 finite-byte controls', lambda:
            bank.run_reference_controls(subject, reference,
                subject_refusal_type=subject.InvalidWitness, check=check))
        check()
        if not (type(qualification) is dict
                and qualification.get('schema') == 'FPC-H1-independent-controls-v2'
                and qualification.get('status') == 'COMPLETE'
                and qualification.get('complete') is True
                and type(qualification.get('control_count')) is int and qualification['control_count'] == 137
                and type(qualification.get('original_control_count')) is int and qualification['original_control_count'] == 134
                and type(qualification.get('added_retained_owned_groups')) is int and qualification['added_retained_owned_groups'] == 3
                and type(qualification.get('controls')) is list
                and [row['id'] for row in qualification['controls']] == list(CONTROL_IDS)
                and len(qualification['controls']) == 137
                and all(type(row) is dict and row.get('passed') is True for row in qualification['controls'])):
            raise ValueError('complete exact all137 ordered bank receipt required; no prefix admission')
        check()
    except BaseException as error:
        primary = state['first_fault'] if state['first_fault'] is not None else error
    finally:
        try:
            # Failure cleanup hashes remain inside whole custody. A latched
            # callback is never cleared to obtain a positive receipt.
            verify_files(primary is None)
            source_unchanged = bool(guards)
        except BaseException as error:
            source_unchanged = False
            if primary is None:
                primary = state['first_fault'] if state['first_fault'] is not None else error

    def receipt():
        return dict(schema='proof-search-case-worker-v1', case_id=CASE_ID,
            stage='qualify', worker_version=VERSION,
            status='COMPLETE' if primary is None else 'FAILED_CASE_NOT_ADMITTED',
            stages=state['stages'], callbacks=state['callbacks'],
            elapsed_seconds=time.monotonic()-began, source_unchanged=source_unchanged,
            python_peak_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            native_peak_bytes=0, native_requests_started=0, native_queries=[],
            native_transport=dict(closed=True, all_reaped=True, native_exit_code=0,
                native_high_water_bytes=0, subprocesses_started=0,
                scope='VACUOUS: no Native imports, tables, oracle or subprocesses exist in this worker'),
            guard_compilations=[], work_snapshots=[],
            qualification_complete=primary is None,
            qualification_result=qualification if primary is None else None,
            scientific_result=None, independent_external_controls=None,
            error=None if primary is None else dict(type=type(primary).__name__, message=str(primary),
                traceback=''.join(traceback.format_exception(primary))),
            first_Root_fault=state['first_fault'] is not None,
            old_qualification_reused=False, component_versions=state['versions'],
            full_FOL_correctness_or_completeness_claim=False, fixed_verifier_machine_or_palette=False,
            scope='Finite-byte checker qualification fixtures only; check_certificate/check_envelope and '
                  'reference binding/fault paths covered by this137bank. Subject standalone decode APIs '
                  'remain Source-reviewed only. No discovered theorem/proof search, Graph, GCTS, RL, '
                  'full FOL correctness/completeness, machine/palette or utility claim')

    try:
        if primary is None:
            check()
        body = serialize(receipt(), CAPS['result_bytes'])
        if primary is None:
            check()  # Includes full result serialization in the160-second work gate.
    except BaseException as error:
        if primary is None:
            if type(error) is RootBudget and state['first_fault'] is None:
                state['first_fault'] = error
            primary = state['first_fault'] if state['first_fault'] is not None else error
        body = serialize(receipt(), CAPS['result_bytes'])
    result_path = directory/('result.json' if primary is None else 'failure.json')
    write_body(result_path, body)
    del body
    result_pin = raw_pin(result_path)
    header = dict(schema='proof-search-case-worker-header-v1', case_id=CASE_ID,
        status='COMPLETE' if primary is None else 'FAILED_CASE_NOT_ADMITTED',
        callbacks=state['callbacks'], seconds=time.monotonic()-began,
        python_peak_after_output_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        native_peak_bytes=0, source_unchanged=source_unchanged,
        native_closed_and_reaped=True, first_Root_fault=state['first_fault'] is not None,
        result=result_pin, native_scope='VACUOUS_NO_NATIVE_SUBPROCESS')
    write_body(directory/'worker-header.json', serialize(header, 4194304))
    # Result/header are provisional custody bodies. Only the unchanged parent,
    # external observer and independent complete-result review can admit them.
    print(json.dumps(dict(case_id=CASE_ID, status=header['status'], callbacks=state['callbacks'],
                          seconds=time.monotonic()-began)))
    return 0 if (primary is None and source_unchanged
                 and time.monotonic()-began < CAPS['positive_seconds']
                 and resource.getrusage(resource.RUSAGE_SELF).ru_maxrss < CAPS['memory_bytes']) else 2


if __name__ == '__main__':
    if len(sys.argv) != 4:
        raise SystemExit('usage: fpc_h1_qualification_worker_v1.py PLAN ACTUAL_DIR ROOT_START')
    raise SystemExit(main(sys.argv[1], sys.argv[2], float(sys.argv[3])))
