Failure-marking proof-search experiment,2026-11-03.
The prospective16-case cohort and Source hashes were saved before compilation,
classification, failure-mark acquisition or testing. Data retain all144method
positions, including preparation/resource refusals. No new RL training occurred:
the prior128-family bank and shape-policy weights were reused with byte pins.
Data include every raw answer before post-search assurance, final answers,
bounded absence DAGs, positive classification proofs, native proof trees,
independent logical/family/marked-point checks, and unknowns/failed searches.
No human-written target proof was supplied. Every accepted proof expands into
primitive rules under its own current hypotheses.

Global mark-only ports receive fixed string value0 only for independently
certified requested failures. Every producer assigns string value1 to its
premise obligation ports. This is certified unary failure tabling as actual
markings, not Turtle pair-corona learning or dynamic joint-constraint discovery.
The FILTER comparator uses the same certified table directly; DP and fresh
memoized cluster DFS remain controls. Complete finite proof placement sets are
preserved under the stated grammar/bound. The tiny exhaustive qualification
checks all proofs and all completed marked queries; heldout packet assurance
samples only the first/last retained query records, as disclosed in the report.

Reproduce in a FRESH copy of this directory, excluding data/,execution logs,
package/ and publication/ generated outputs. Python3.12 stdlib only. Add source/
to sys.path and run experiment_v1.py freeze,then run. Qualification has a separate
reference/qualification_v1.py entry point. Do not overwrite this evidence copy.
The observed pinned runtime path is recorded in data/results-v1.json.gz.
Preparation, acquisition, prepared search and post-search assurance costs are
separate. Acquisition is observed once percase and reused; accounted cold sums
are estimates from reused observations, not repeated cold trials. A single
sequential experiment does not establish broad speed superiority. These runs
search semantic point-proof trees; no literal Wang grid or new NAND compilation.

The user expressly approved publication of full task-owned Sources, raw proof
certificates, execution logs and local paths to the existing public Pages site.
No unrelated checkout changes or retired materials research are included.
This archive cut excludes package/ generated outputs and publication/ later
deployment receipts to avoid recursive archives. All original files in the cut
are partitioned across ordinary ZIPs; extract every part to one directory.
