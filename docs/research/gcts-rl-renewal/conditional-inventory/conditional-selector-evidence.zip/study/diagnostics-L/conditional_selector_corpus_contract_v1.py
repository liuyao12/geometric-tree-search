"""D19 statement format/input-family controls; Root-actual calls only.

No file access, scientific imports, proof routes, policy weights or actual new
held-out/domain statement bodies. Constants below are phase metadata only.
The Horn classifier describes input-theory structure, not proof validity.
"""
import copy

ACQUISITION_SCHEMA = 'gcts-conditional-selector-acquisition-inputs-v1'
ACQUISITION_ID = 'D19-fresh-conditional-family-acquisition-v1'
ACQUISITION_IDS = ('donor-long-serial-01', 'donor-derived-join-01')
ACQUISITION_PROTOCOL = {'abstraction_modes': ['atom', 'principal'],
 'authority': 'Both fresh complete donor acquisitions and every eligible profile fragment '
              'must be admitted before any training. No prior proof/library/policy, '
              'unresolved-fragment or shortened-library adoption.',
 'fresh_acquisition': True,
 'pairing_policy': 'UNCHANGED_ATOM_TEMPLATE_CLASSES_NO_PRINCIPAL_COALESCENCE_V1',
 'premise_port_policy': 'EXACT_DONOR_FORMULA_FIRST_USE_QUOTIENT_V1',
 'shards': [{'donor_ids': ['donor-long-serial-01'],
             'donor_indices': [0],
             'stage_id': 'acquire-0'},
            {'donor_ids': ['donor-derived-join-01'],
             'donor_indices': [1],
             'stage_id': 'acquire-1'}]}
TRAINING_SCHEMA = 'gcts-conditional-selector-training-inputs-v1'
TRAINING_ID = 'D19-contextual-selector-training-v1'
TRAINING_IDS = ('train-path-01', 'train-path-02', 'train-path-03', 'train-direct-01', 'train-join-01', 'train-join-02', 'train-join-03', 'train-join-04')
TRAINING_PROTOCOL = {'engines': ['symbolic', 'point'],
 'episode_order': 'Two cases per shard, each symbolic then point; each engine sees '
                  'manifest0..7twice. One model at a time, common setup charged once per job.',
 'episodes_per_engine': 16,
 'intake': 'No evaluation/domain/split/proposal/newheldout-review bodies may be read or '
           'raw-pinned by training worker. Only this physical training statement document and '
           'admitted acquisition/policy chain.',
 'passes': 2,
 'policy_initialization': 'Separate exactzero gate/continuation weights and EMA baselines for '
                          'each engine; no D15policy adoption. Every qualified global bundle '
                          'continues both full histories.',
 'row_semantics': 'Exact expanded primitive certificate rows; valid repeats/filler remain, no '
                  'shortest-proof claim. Supplied-goal item is utility control only.',
 'shards': [{'episodes': [{'engine': 'symbolic',
                           'global_ordinal': 0,
                           'index': 0,
                           'problem_id': 'train-path-01',
                           'seed': 0},
                          {'engine': 'point',
                           'global_ordinal': 1,
                           'index': 0,
                           'problem_id': 'train-path-01',
                           'seed': 10000},
                          {'engine': 'symbolic',
                           'global_ordinal': 2,
                           'index': 1,
                           'problem_id': 'train-path-02',
                           'seed': 1},
                          {'engine': 'point',
                           'global_ordinal': 3,
                           'index': 1,
                           'problem_id': 'train-path-02',
                           'seed': 10001}],
             'manifest_indices': [0, 1],
             'pass': 0,
             'stage_id': 'train-0'},
            {'episodes': [{'engine': 'symbolic',
                           'global_ordinal': 4,
                           'index': 2,
                           'problem_id': 'train-path-03',
                           'seed': 2},
                          {'engine': 'point',
                           'global_ordinal': 5,
                           'index': 2,
                           'problem_id': 'train-path-03',
                           'seed': 10002},
                          {'engine': 'symbolic',
                           'global_ordinal': 6,
                           'index': 3,
                           'problem_id': 'train-direct-01',
                           'seed': 3},
                          {'engine': 'point',
                           'global_ordinal': 7,
                           'index': 3,
                           'problem_id': 'train-direct-01',
                           'seed': 10003}],
             'manifest_indices': [2, 3],
             'pass': 0,
             'stage_id': 'train-1'},
            {'episodes': [{'engine': 'symbolic',
                           'global_ordinal': 8,
                           'index': 4,
                           'problem_id': 'train-join-01',
                           'seed': 4},
                          {'engine': 'point',
                           'global_ordinal': 9,
                           'index': 4,
                           'problem_id': 'train-join-01',
                           'seed': 10004},
                          {'engine': 'symbolic',
                           'global_ordinal': 10,
                           'index': 5,
                           'problem_id': 'train-join-02',
                           'seed': 5},
                          {'engine': 'point',
                           'global_ordinal': 11,
                           'index': 5,
                           'problem_id': 'train-join-02',
                           'seed': 10005}],
             'manifest_indices': [4, 5],
             'pass': 0,
             'stage_id': 'train-2'},
            {'episodes': [{'engine': 'symbolic',
                           'global_ordinal': 12,
                           'index': 6,
                           'problem_id': 'train-join-03',
                           'seed': 6},
                          {'engine': 'point',
                           'global_ordinal': 13,
                           'index': 6,
                           'problem_id': 'train-join-03',
                           'seed': 10006},
                          {'engine': 'symbolic',
                           'global_ordinal': 14,
                           'index': 7,
                           'problem_id': 'train-join-04',
                           'seed': 7},
                          {'engine': 'point',
                           'global_ordinal': 15,
                           'index': 7,
                           'problem_id': 'train-join-04',
                           'seed': 10007}],
             'manifest_indices': [6, 7],
             'pass': 0,
             'stage_id': 'train-3'},
            {'episodes': [{'engine': 'symbolic',
                           'global_ordinal': 16,
                           'index': 8,
                           'problem_id': 'train-path-01',
                           'seed': 8},
                          {'engine': 'point',
                           'global_ordinal': 17,
                           'index': 8,
                           'problem_id': 'train-path-01',
                           'seed': 10008},
                          {'engine': 'symbolic',
                           'global_ordinal': 18,
                           'index': 9,
                           'problem_id': 'train-path-02',
                           'seed': 9},
                          {'engine': 'point',
                           'global_ordinal': 19,
                           'index': 9,
                           'problem_id': 'train-path-02',
                           'seed': 10009}],
             'manifest_indices': [0, 1],
             'pass': 1,
             'stage_id': 'train-4'},
            {'episodes': [{'engine': 'symbolic',
                           'global_ordinal': 20,
                           'index': 10,
                           'problem_id': 'train-path-03',
                           'seed': 10},
                          {'engine': 'point',
                           'global_ordinal': 21,
                           'index': 10,
                           'problem_id': 'train-path-03',
                           'seed': 10010},
                          {'engine': 'symbolic',
                           'global_ordinal': 22,
                           'index': 11,
                           'problem_id': 'train-direct-01',
                           'seed': 11},
                          {'engine': 'point',
                           'global_ordinal': 23,
                           'index': 11,
                           'problem_id': 'train-direct-01',
                           'seed': 10011}],
             'manifest_indices': [2, 3],
             'pass': 1,
             'stage_id': 'train-5'},
            {'episodes': [{'engine': 'symbolic',
                           'global_ordinal': 24,
                           'index': 12,
                           'problem_id': 'train-join-01',
                           'seed': 12},
                          {'engine': 'point',
                           'global_ordinal': 25,
                           'index': 12,
                           'problem_id': 'train-join-01',
                           'seed': 10012},
                          {'engine': 'symbolic',
                           'global_ordinal': 26,
                           'index': 13,
                           'problem_id': 'train-join-02',
                           'seed': 13},
                          {'engine': 'point',
                           'global_ordinal': 27,
                           'index': 13,
                           'problem_id': 'train-join-02',
                           'seed': 10013}],
             'manifest_indices': [4, 5],
             'pass': 1,
             'stage_id': 'train-6'},
            {'episodes': [{'engine': 'symbolic',
                           'global_ordinal': 28,
                           'index': 14,
                           'problem_id': 'train-join-03',
                           'seed': 14},
                          {'engine': 'point',
                           'global_ordinal': 29,
                           'index': 14,
                           'problem_id': 'train-join-03',
                           'seed': 10014},
                          {'engine': 'symbolic',
                           'global_ordinal': 30,
                           'index': 15,
                           'problem_id': 'train-join-04',
                           'seed': 15},
                          {'engine': 'point',
                           'global_ordinal': 31,
                           'index': 15,
                           'problem_id': 'train-join-04',
                           'seed': 10015}],
             'manifest_indices': [6, 7],
             'pass': 1,
             'stage_id': 'train-7'}],
 'total_episodes': 32,
 'training_ids': ['train-path-01',
                  'train-path-02',
                  'train-path-03',
                  'train-direct-01',
                  'train-join-01',
                  'train-join-02',
                  'train-join-03',
                  'train-join-04']}
EVALUATION_SCHEMA = 'gcts-conditional-selector-evaluation-inputs-v1'
EVALUATION_ID = 'D19-public-authored-input-structure-evaluation-v1'
EVALUATION_IDS = ('eval-sharing-01', 'eval-sharing-02', 'eval-quantified-01', 'eval-quantified-02', 'eval-equality-01', 'eval-equality-02', 'context-atomic-serial', 'context-opaque-equality', 'holdout-alternative-01', 'holdout-alternative-02', 'holdout-cycle-01', 'holdout-cycle-02')
EVALUATION_PROTOCOL = {'arm_order': {'context-atomic-serial': {'0': ['PU', 'PR', 'S0', 'SF', 'SU', 'SR', 'P0', 'PF'],
                                         '1': ['PF',
                                               'P0',
                                               'SR',
                                               'SU',
                                               'SF',
                                               'S0',
                                               'PR',
                                               'PU']},
               'context-opaque-equality': {'0': ['PR',
                                                 'S0',
                                                 'SF',
                                                 'SU',
                                                 'SR',
                                                 'P0',
                                                 'PF',
                                                 'PU'],
                                           '1': ['PU',
                                                 'PF',
                                                 'P0',
                                                 'SR',
                                                 'SU',
                                                 'SF',
                                                 'S0',
                                                 'PR']},
               'eval-equality-01': {'0': ['P0', 'PF', 'PU', 'PR', 'S0', 'SF', 'SU', 'SR'],
                                    '1': ['SR', 'SU', 'SF', 'S0', 'PR', 'PU', 'PF', 'P0']},
               'eval-equality-02': {'0': ['PF', 'PU', 'PR', 'S0', 'SF', 'SU', 'SR', 'P0'],
                                    '1': ['P0', 'SR', 'SU', 'SF', 'S0', 'PR', 'PU', 'PF']},
               'eval-quantified-01': {'0': ['SU', 'SR', 'P0', 'PF', 'PU', 'PR', 'S0', 'SF'],
                                      '1': ['SF', 'S0', 'PR', 'PU', 'PF', 'P0', 'SR', 'SU']},
               'eval-quantified-02': {'0': ['SR', 'P0', 'PF', 'PU', 'PR', 'S0', 'SF', 'SU'],
                                      '1': ['SU', 'SF', 'S0', 'PR', 'PU', 'PF', 'P0', 'SR']},
               'eval-sharing-01': {'0': ['S0', 'SF', 'SU', 'SR', 'P0', 'PF', 'PU', 'PR'],
                                   '1': ['PR', 'PU', 'PF', 'P0', 'SR', 'SU', 'SF', 'S0']},
               'eval-sharing-02': {'0': ['SF', 'SU', 'SR', 'P0', 'PF', 'PU', 'PR', 'S0'],
                                   '1': ['S0', 'PR', 'PU', 'PF', 'P0', 'SR', 'SU', 'SF']},
               'holdout-alternative-01': {'0': ['S0',
                                                'SF',
                                                'SU',
                                                'SR',
                                                'P0',
                                                'PF',
                                                'PU',
                                                'PR'],
                                          '1': ['PR',
                                                'PU',
                                                'PF',
                                                'P0',
                                                'SR',
                                                'SU',
                                                'SF',
                                                'S0']},
               'holdout-alternative-02': {'0': ['SU',
                                                'SR',
                                                'P0',
                                                'PF',
                                                'PU',
                                                'PR',
                                                'S0',
                                                'SF'],
                                          '1': ['SF',
                                                'S0',
                                                'PR',
                                                'PU',
                                                'PF',
                                                'P0',
                                                'SR',
                                                'SU']},
               'holdout-cycle-01': {'0': ['P0', 'PF', 'PU', 'PR', 'S0', 'SF', 'SU', 'SR'],
                                    '1': ['SR', 'SU', 'SF', 'S0', 'PR', 'PU', 'PF', 'P0']},
               'holdout-cycle-02': {'0': ['PU', 'PR', 'S0', 'SF', 'SU', 'SR', 'P0', 'PF'],
                                    '1': ['PF', 'P0', 'SR', 'SU', 'SF', 'S0', 'PR', 'PU']}},
 'case_strata': {'context-atomic-serial': 'EXPOSED_D18_REGRESSION',
                 'context-opaque-equality': 'EXPOSED_D18_REGRESSION',
                 'eval-equality-01': 'EXPOSED_D18_REGRESSION',
                 'eval-equality-02': 'EXPOSED_D18_REGRESSION',
                 'eval-quantified-01': 'EXPOSED_D18_REGRESSION',
                 'eval-quantified-02': 'EXPOSED_D18_REGRESSION',
                 'eval-sharing-01': 'EXPOSED_D18_REGRESSION',
                 'eval-sharing-02': 'EXPOSED_D18_REGRESSION',
                 'holdout-alternative-01': 'HELD_OUT_ALTERNATIVE_PRODUCER_DAG',
                 'holdout-alternative-02': 'HELD_OUT_ALTERNATIVE_PRODUCER_DAG',
                 'holdout-cycle-01': 'HELD_OUT_TARGET_RELEVANT_CYCLIC_INPUT',
                 'holdout-cycle-02': 'HELD_OUT_TARGET_RELEVANT_CYCLIC_INPUT'},
 'evaluation_seeds': [0, 1],
 'intake': 'Only after both fresh donor acquisitions and all8trainingbundle seals, frozen '
           'common inventory and both complete16episode policies. No evalupdates, '
           'earlierproof/library/policy adoption or lost-prefix rescue.',
 'marking_scope': 'Same freshly certified auxiliary failure markings in ALL four point '
                  'methods; all retain problemdefining word/structure marks. This isolates '
                  'selection, not a new marking effect.',
 'methods': ['S0', 'SF', 'SU', 'SR', 'P0', 'PF', 'PU', 'PR'],
 'rng_seeds': {'context-atomic-serial': {'0': {'point': 16000, 'symbolic': 6000},
                                         '1': {'point': 16001, 'symbolic': 6001}},
               'context-opaque-equality': {'0': {'point': 17000, 'symbolic': 7000},
                                           '1': {'point': 17001, 'symbolic': 7001}},
               'eval-equality-01': {'0': {'point': 14000, 'symbolic': 4000},
                                    '1': {'point': 14001, 'symbolic': 4001}},
               'eval-equality-02': {'0': {'point': 15000, 'symbolic': 5000},
                                    '1': {'point': 15001, 'symbolic': 5001}},
               'eval-quantified-01': {'0': {'point': 12000, 'symbolic': 2000},
                                      '1': {'point': 12001, 'symbolic': 2001}},
               'eval-quantified-02': {'0': {'point': 13000, 'symbolic': 3000},
                                      '1': {'point': 13001, 'symbolic': 3001}},
               'eval-sharing-01': {'0': {'point': 10000, 'symbolic': 0},
                                   '1': {'point': 10001, 'symbolic': 1}},
               'eval-sharing-02': {'0': {'point': 11000, 'symbolic': 1000},
                                   '1': {'point': 11001, 'symbolic': 1001}},
               'holdout-alternative-01': {'0': {'point': 18000, 'symbolic': 8000},
                                          '1': {'point': 18001, 'symbolic': 8001}},
               'holdout-alternative-02': {'0': {'point': 19000, 'symbolic': 9000},
                                          '1': {'point': 19001, 'symbolic': 9001}},
               'holdout-cycle-01': {'0': {'point': 20000, 'symbolic': 10000},
                                    '1': {'point': 20001, 'symbolic': 10001}},
               'holdout-cycle-02': {'0': {'point': 21000, 'symbolic': 11000},
                                    '1': {'point': 21001, 'symbolic': 11001}}},
 'row_semantics': 'Unchanged exact primitive certificate-row counts and every fallback, '
                  'including repeats/filler; no shortest-proof claim.',
 'seed_scope': 'Fixed paired order/RNG labels; streams independent of methodposition. F '
               'deterministic, Uequalszero-R distribution at both heads; U/R reset to same '
               'percase/engine/label seed. Not independent stochastic replicas.',
 'split_scope': 'Eight exact D18exposed regressions +four held-out input-theory structures '
                'relativeD19training. No blind/all-proof DAG/principal-family disjointness; '
                'genericMP/proper-subproof overlap intended.'}
DOMAIN_SCHEMA = 'gcts-conditional-selector-domain-probes-v1'
DOMAIN_ID = 'D19-separate-arithmetic-incidence-qualification-v1'
DOMAIN_IDS = ('arith-zero-direct-instantiation-control', 'arith-zero-congruence-fragment', 'hilbert-ground-incidence-uniqueness-fragment')
DOMAIN_PROTOCOL = {'inventory': False,
 'methods': ['S0', 'P0'],
 'policy': False,
 'scope': 'Separate closed-fragment grammar/proof qualification only. Retain hard arithmetic '
          'congruence at bound9 regardless direct-control outcome; no full '
          'PA/induction/Hilbert geometry or easier-goal rescue. These proofs never feed '
          'acquisition/training/policy. Exact fresh Root plans required.',
 'stage_ids': ['qualify-arith-zero-direct-instantiation-control',
               'qualify-arith-zero-congruence-fragment',
               'qualify-hilbert-ground-incidence-uniqueness-fragment'],
 'upstream_feed': False}
ROW_BOUNDS = {'donor-long-serial-01': 7,
 'donor-derived-join-01': 7,
 'train-path-01': 9,
 'train-path-02': 11,
 'train-path-03': 9,
 'train-direct-01': 9,
 'train-join-01': 11,
 'train-join-02': 11,
 'train-join-03': 13,
 'train-join-04': 13,
 'eval-sharing-01': 12,
 'eval-sharing-02': 15,
 'eval-quantified-01': 11,
 'eval-quantified-02': 11,
 'eval-equality-01': 9,
 'eval-equality-02': 11,
 'context-atomic-serial': 5,
 'context-opaque-equality': 5,
 'holdout-alternative-01': 15,
 'holdout-alternative-02': 15,
 'holdout-cycle-01': 13,
 'holdout-cycle-02': 15,
 'arith-zero-direct-instantiation-control': 9,
 'arith-zero-congruence-fragment': 9,
 'hilbert-ground-incidence-uniqueness-fragment': 15}

_OWNER = object()

class CorpusFormatError(ValueError):
    def __init__(self, message, owner=None):
        super().__init__(message)
        self.owner = owner


def is_owned_error(error):
    return type(error) is CorpusFormatError and error.owner is _OWNER


def need(value, message):
    if not value:
        raise CorpusFormatError(message, _OWNER)


def _same(left, right, check):
    check()
    if type(left) is not type(right):
        return False
    if type(left) is list:
        if len(left) != len(right):
            return False
        for a, b in zip(left, right):
            if not _same(a, b, check):
                return False
        return True
    if type(left) is dict:
        if set(left) != set(right):
            return False
        for key in left:
            if not _same(left[key], right[key], check):
                return False
        return True
    return left == right


def _name(value, check):
    check()
    need(type(value) is str and 0 < len(value) <= 128, 'bounded literal name')


def _signature(value, check):
    check(); need(type(value) is dict, 'literal signature map')
    for name, arity in value.items():
        _name(name, check)
        need(type(arity) is int and 0 <= arity <= 2, 'exact finite arity')


def _term(value, theory, bound, check, depth=0):
    check(); need(depth <= 64 and type(value) is list and value, 'finite literal term')
    if value[0] == 'var':
        need(len(value) == 2 and type(value[1]) is str and value[1] in bound,
             'no free variable in licensed closed axiom/target')
        return
    need(len(value) == 3 and value[0] == 'fun' and type(value[1]) is str
         and value[1] in theory['functions'] and type(value[2]) is list,
         'declared function term')
    need(len(value[2]) == theory['functions'][value[1]], 'function arity')
    for item in value[2]:
        _term(item, theory, bound, check, depth+1)


def _formula(value, theory, bound, check, depth=0):
    check(); need(depth <= 64 and type(value) is list and value
                  and type(value[0]) is str, 'finite literal formula')
    tag = value[0]
    if tag == 'bot':
        need(len(value) == 1, 'bottom arity')
    elif tag == 'pred':
        need(len(value) == 3 and type(value[1]) is str and value[1] in theory['predicates']
             and type(value[2]) is list, 'declared predicate')
        need(len(value[2]) == theory['predicates'][value[1]], 'predicate arity')
        for item in value[2]:
            _term(item, theory, bound, check, depth+1)
    elif tag == 'eq':
        need(len(value) == 3, 'equality arity')
        _term(value[1], theory, bound, check, depth+1)
        _term(value[2], theory, bound, check, depth+1)
    elif tag == 'all':
        need(len(value) == 3, 'universal arity'); _name(value[1], check)
        _formula(value[2], theory, bound | {value[1]}, check, depth+1)
    elif tag == 'not':
        need(len(value) == 2, 'negation arity')
        _formula(value[1], theory, bound, check, depth+1)
    else:
        need(tag in ('imp', 'and', 'or') and len(value) == 3, 'known binary formula')
        _formula(value[1], theory, bound, check, depth+1)
        _formula(value[2], theory, bound, check, depth+1)


def _spec(spec, check):
    check(); need(type(spec) is dict and set(spec) ==
        {'id','title','theory','target','length','instantiation_rounds','scope'},
        'statement-only spec; no proof, route, policy or expected action')
    _name(spec['id'],check)
    need(spec['id'] in ROW_BOUNDS and type(spec['title']) is str and type(spec['scope']) is str,
         'declared statement identity and literal prose')
    need(type(spec['length']) is int and spec['length']==ROW_BOUNDS[spec['id']],
         'exact expanded primitive certificate row count; repeats remain legal')
    need(type(spec['instantiation_rounds']) is int and spec['instantiation_rounds']==2,
         'unchanged two-pass catalog')
    theory=spec['theory']
    need(type(theory) is dict and set(theory)=={'functions','predicates','axioms','schemas'},
         'explicit finite signature and axiom licence')
    _signature(theory['functions'],check);_signature(theory['predicates'],check)
    need(type(theory['schemas']) is list and not theory['schemas'],'no induction/schema adoption')
    need(type(theory['axioms']) is dict and 1<=len(theory['axioms'])<=9,'declared finite axiom list')
    for name,formula in theory['axioms'].items():
        _name(name,check);_formula(formula,theory,set(),check)
    _formula(spec['target'],theory,set(),check)


def _atom(formula, check):
    check();need(type(formula) is list and len(formula)==3 and formula[0]=='pred'
        and type(formula[1]) is str and type(formula[2]) is list and not formula[2],
        'positive nullary Horn atom only; no opaque compound leaf')
    return formula[1]


def classify_input(spec, *, check):
    """Finite Horn INPUT graph; never a theorem/shortest-proof classifier.

    Grounding is least Horn closure requiring ALL premises, not ordinary
    directed reachability. SCCs are relevant only in grounded target ancestors.
    """
    check();theory=spec['theory']
    need(theory['functions']=={} and not theory['schemas'],'pure nullary Horn signature')
    for name,arity in theory['predicates'].items():
        check();need(type(name) is str and type(arity) is int and arity==0,'nullary predicates')
    target=_atom(spec['target'],check);seeds=set();rules=[];seen_rules=set();nodes={target}
    for name,formula in theory['axioms'].items():
        check();body=[];cursor=formula
        while type(cursor) is list and len(cursor)==3 and cursor[0]=='imp':
            body.append(_atom(cursor[1],check));cursor=cursor[2]
        head=_atom(cursor,check);nodes.add(head)
        for atom in body:
            check();nodes.add(atom)
        need(len(set(body))==len(body),'no repeated antecedent in a fresh Horn clause')
        if not body:
            need(head not in seeds,'no duplicate fact');seeds.add(head)
        else:
            identity=(tuple(sorted(body)),head)
            need(identity not in seen_rules,'no duplicate producer clause, including body permutations')
            seen_rules.add(identity);rules.append(dict(axiom=name,body=body,head=head))
    need(len(nodes)<=16 and nodes<=set(theory['predicates']),'bounded declared graph atoms')
    grounded=set(seeds);changed=True
    while changed:
        check();changed=False
        for rule in rules:
            check();ready=True
            for atom in rule['body']:
                check()
                if atom not in grounded:ready=False
            if ready and rule['head'] not in grounded:
                grounded.add(rule['head']);changed=True
    ancestors={target};changed=True
    while changed:
        check();changed=False
        for rule in rules:
            check()
            if rule['head'] in ancestors:
                for atom in rule['body']:
                    check()
                    if atom not in ancestors:ancestors.add(atom);changed=True
    relevant=grounded & ancestors;edges=set();whole_edges=set();producers={};whole_producers={}
    for rule in rules:
        check();whole_producers[rule['head']]=whole_producers.get(rule['head'],0)+1
        all_relevant=rule['head'] in relevant
        for atom in rule['body']:
            check();whole_edges.add((atom,rule['head']))
            if atom not in relevant:all_relevant=False
        if all_relevant:
            producers[rule['head']]=producers.get(rule['head'],0)+1
            for atom in rule['body']:
                check();edges.add((atom,rule['head']))
    # Explicit finite transitive closures; no callback-bearing generators.
    reaches={a:set() for a in nodes};whole_reaches={a:set() for a in nodes}
    for a,b in edges:check();reaches[a].add(b)
    for a,b in whole_edges:check();whole_reaches[a].add(b)
    for relation in (reaches,whole_reaches):
        changed=True
        while changed:
            check();changed=False
            for a in sorted(nodes):
                check();extension=set(relation[a])
                for b in sorted(relation[a]):check();extension.update(relation[b])
                if extension!=relation[a]:relation[a]=extension;changed=True
    cyclic=[];whole_cyclic=[]
    for a in sorted(nodes):
        check()
        if a in reaches[a]:cyclic.append(a)
        if a in whole_reaches[a]:whole_cyclic.append(a)
    groups=[];remaining=set(cyclic)
    while remaining:
        check();a=min(remaining);group=[]
        for b in sorted(remaining):
            check()
            if b in reaches[a] and a in reaches[b]:group.append(b)
        groups.append(group);remaining.difference_update(group)
    # A self-loop also makes a cyclic input, but fresh heldout requires size>=2.
    category=('TARGET_UNGROUNDED' if target not in grounded else
              'TARGET_RELEVANT_CYCLIC_INPUT' if cyclic else
              'ALTERNATIVE_PRODUCER_DAG' if any(v>=2 for v in producers.values()) else
              'ACYCLIC_SINGLE_PRODUCER')
    check();return dict(schema='D19-Horn-input-structure-v1',category=category,
        target=target,seeds=sorted(seeds),rules=rules,grounded=sorted(grounded),
        target_ancestors=sorted(ancestors),relevant=sorted(relevant),
        edges=[list(e) for e in sorted(edges)],producer_counts=producers,
        cyclic_components=groups,whole_cyclic_atoms=whole_cyclic,
        whole_producer_counts=whole_producers,
        scope='Input theory hypergraph only. Finite proofs remain DAGs; MP/proper-subproof overlap allowed. No proof, validity, minimal route or blind-family claim.')


def _document(document, schema, identity, field, ids, protocol, check):
    check();need(type(document) is dict and set(document)=={'schema','id',field,'protocol'},
                 'exact physically separate phase input')
    need(document['schema']==schema and document['id']==identity,'fixed phase schema/identity')
    specs=document[field];need(type(specs) is list and len(specs)==len(ids),'full fixed population')
    actual=[];families=[]
    for spec in specs:
        _spec(spec,check);actual.append(spec['id'])
        if field in ('donors','training') or spec['id'].startswith('holdout-'):
            family=classify_input(spec,check=check);families.append(dict(id=spec['id'],structure=family))
            expected=('ALTERNATIVE_PRODUCER_DAG' if spec['id'].startswith('holdout-alternative-') else
                      'TARGET_RELEVANT_CYCLIC_INPUT' if spec['id'].startswith('holdout-cycle-') else
                      'ACYCLIC_SINGLE_PRODUCER')
            need(family['category']==expected,'prospectively declared input-structure stratum')
            if expected=='ACYCLIC_SINGLE_PRODUCER':
                need(not family['whole_cyclic_atoms'] and all(v<=1 for v in family['whole_producer_counts'].values()),
                     'whole fresh donor/training theory single-producer and acyclic')
            if expected=='TARGET_RELEVANT_CYCLIC_INPUT':
                need(any(len(group)>=2 for group in family['cyclic_components']),
                     'nontrivial grounded target-relevant cycle; not irrelevant decoration')
    need(tuple(actual)==ids,'ordered complete statement identities')
    need(_same(document['protocol'],protocol,check),'exact typed schedule/seeds/phase semantics')
    check();return dict(schema='D19-corpus-format-and-input-structure-v1',complete=True,
        phase=field,statement_ids=actual,input_structures=families,
        scope='Signature/closedness/format/schedule and input-structure only. Raw plan pins freeze actual formulas; no theorem validity, proof search, novelty advantage or execution grant.')


def validate_acquisition(document, *, check):
    return _document(document,ACQUISITION_SCHEMA,ACQUISITION_ID,'donors',ACQUISITION_IDS,ACQUISITION_PROTOCOL,check)


def validate_training(document, *, check):
    return _document(document,TRAINING_SCHEMA,TRAINING_ID,'training',TRAINING_IDS,TRAINING_PROTOCOL,check)


def validate_evaluation(document, *, check):
    return _document(document,EVALUATION_SCHEMA,EVALUATION_ID,'evaluation',EVALUATION_IDS,EVALUATION_PROTOCOL,check)


def validate_domain_probes(document, *, check):
    return _document(document,DOMAIN_SCHEMA,DOMAIN_ID,'probes',DOMAIN_IDS,DOMAIN_PROTOCOL,check)


FORMAT_CONTROL_IDS=('valid-training','unexpected-proof','bool-bound','free-axiom-variable',
    'unknown-function','function-arity','unknown-predicate','predicate-arity','unknown-formula',
    'bool-signature-arity','nonempty-schemas','missing-training','duplicate-training-id',
    'training-engine-order','training-seed','training-shard-case-order')
GRAPH_CONTROL_IDS=('linear','alternative','cycle','irrelevant-cycle','ungrounded-curried',
    'grounded-curried','duplicate-fact','duplicate-clause','duplicate-body-permutation','repeated-body','not-Horn')
FOREIGN_CONTROL_IDS=('foreign-RuntimeError','foreign-ValueError','foreign-StopIteration','foreign-CorpusFormatError')


def run_contract_controls(training_document, *, check):
    """Actual-only format + independent tiny INPUT-graph controls, no eval body."""
    check();validate_training(training_document,check=check)
    results=[dict(id='valid-training',status='PASSED')]
    for recipe in FORMAT_CONTROL_IDS[1:]:
        check();altered=copy.deepcopy(training_document);spec=altered['training'][0]
        if recipe=='unexpected-proof':spec['proof']=[]
        elif recipe=='bool-bound':spec['length']=True
        elif recipe=='free-axiom-variable':spec['theory']['axioms']['a0']=['eq',['var','x'],['var','x']]
        elif recipe=='unknown-function':spec['target']=['eq',['fun','BAD',[]],['fun','BAD',[]]]
        elif recipe=='function-arity':
            spec['theory']['functions']['bad']=1;spec['target']=['eq',['fun','bad',[]],['fun','bad',[]]]
        elif recipe=='unknown-predicate':spec['target']=['pred','UNDECLARED',[]]
        elif recipe=='predicate-arity':spec['theory']['predicates']['P']=1
        elif recipe=='unknown-formula':spec['target']=['bad',['bot']]
        elif recipe=='bool-signature-arity':spec['theory']['functions']['bad']=False
        elif recipe=='nonempty-schemas':spec['theory']['schemas']=['unlicensed']
        elif recipe=='missing-training':altered['training'].pop()
        elif recipe=='duplicate-training-id':altered['training'][1]['id']=altered['training'][0]['id']
        elif recipe=='training-engine-order':altered['protocol']['shards'][0]['episodes'].reverse()
        elif recipe=='training-seed':altered['protocol']['shards'][0]['episodes'][0]['seed']=False
        else:altered['protocol']['shards'][0]['manifest_indices'].reverse()
        caught=None
        try:validate_training(altered,check=check)
        except CorpusFormatError as error:
            check()
            if not is_owned_error(error):raise
            caught=error
        need(caught is not None,'owned malformed-format refusal');results.append(dict(id=recipe,status='PASSED',refused=True))
    # Independent three-atom controls, never actual heldout/probe statements.
    P=['pred','p',[]];Q=['pred','q',[]];R=['pred','r',[]]
    fixtures=[
      ('linear',[P,['imp',P,Q],['imp',Q,R]],R,'ACYCLIC_SINGLE_PRODUCER',['p','q','r']),
      ('alternative',[P,Q,['imp',P,R],['imp',Q,R]],R,'ALTERNATIVE_PRODUCER_DAG',['p','q','r']),
      ('cycle',[P,['imp',P,Q],['imp',Q,P]],Q,'TARGET_RELEVANT_CYCLIC_INPUT',['p','q']),
      ('irrelevant-cycle',[R,P,['imp',P,Q],['imp',Q,P]],R,'ACYCLIC_SINGLE_PRODUCER',['p','q','r']),
      ('ungrounded-curried',[P,['imp',P,['imp',Q,R]]],R,'TARGET_UNGROUNDED',['p']),
      ('grounded-curried',[P,Q,['imp',P,['imp',Q,R]]],R,'ACYCLIC_SINGLE_PRODUCER',['p','q','r'])]
    base=None
    for ident,axioms,target,category,grounded in fixtures:
        check();tiny=dict(theory=dict(functions={},predicates={'p':0,'q':0,'r':0},
            schemas=[],axioms={str(i):a for i,a in enumerate(axioms)}),target=target)
        receipt=classify_input(tiny,check=check)
        need(receipt['category']==category and receipt['grounded']==grounded,'literal independent Horn classification')
        if ident=='irrelevant-cycle':need(receipt['relevant']==['r'],'irrelevant SCC excluded')
        if ident=='ungrounded-curried':need(receipt['relevant']==[],'ALL-premise least closure')
        if ident=='linear':base=copy.deepcopy(tiny)
        results.append(dict(id=ident,status='PASSED',fixture=tiny,actual=receipt,
                            expected=dict(category=category,grounded=grounded)))
    for recipe in GRAPH_CONTROL_IDS[6:]:
        check();tiny=copy.deepcopy(base)
        if recipe=='duplicate-fact':tiny['theory']['axioms']['extra']=P
        elif recipe=='duplicate-clause':tiny['theory']['axioms']['extra']=['imp',P,Q]
        elif recipe=='duplicate-body-permutation':
            tiny['theory']['axioms']['extra']=['imp',P,['imp',Q,R]]
            tiny['theory']['axioms']['more']=['imp',Q,['imp',P,R]]
        elif recipe=='repeated-body':tiny['theory']['axioms']['extra']=['imp',P,['imp',P,R]]
        else:tiny['theory']['axioms']['extra']=['not',P]
        caught=None
        try:classify_input(tiny,check=check)
        except CorpusFormatError as error:
            check()
            if not is_owned_error(error):raise
            caught=error
        need(caught is not None,'owned non-Horn/duplicate refusal');results.append(dict(id=recipe,status='PASSED',refused=True,fixture=tiny))
    for ident,sentinel in zip(FOREIGN_CONTROL_IDS,(RuntimeError('external'),ValueError('external'),StopIteration('external'),CorpusFormatError('external'))):
        check();ticks=[0]
        def interrupt():
            check();ticks[0]+=1
            if ticks[0]==6:raise sentinel
        caught=None
        try:classify_input(base,check=interrupt)
        except BaseException as error:caught=error
        check();need(caught is sentinel,'exact nested callback identity, including same-public-class foreign')
        results.append(dict(id=ident,status='PASSED',exact_identity_preserved=True,callback_ordinal=6))
    ids=[]
    for result in results:check();ids.append(result['id'])
    need(tuple(ids)==FORMAT_CONTROL_IDS+GRAPH_CONTROL_IDS+FOREIGN_CONTROL_IDS,'all finite controls retained')
    check();return dict(schema='D19-corpus-contract-controls-v1',complete=True,count=31,controls=results,
        scope='Sixteen format,eleven independent tiny Horn-input graph andfour foreign callback controls. Actual-only in training stages, never supplied theorem targets or runtime Native proof checks. No evaluation/domain bodies read.')
