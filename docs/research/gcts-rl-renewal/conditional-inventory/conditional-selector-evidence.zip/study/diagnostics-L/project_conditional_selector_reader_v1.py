"""Passive closed D19 report; Root invocation only after independent review.

No scientific import, checker, miner, learner, model or admission helper runs.
This projection is for the preserved two acquisitions plus failed train0 cohort.
It cannot adopt an unadmitted packet or silently turn a missing slot into UNKNOWN.
"""
from pathlib import Path
import copy
import hashlib
import json

STUDY = Path(__file__).resolve().parents[1]
PROTOCOL_SHA = 'ae4daf42c3d5099da479690cc083e5c05a2422fc165cb64818a2a28a3a469136'
DISPOSITION_SHA = 'dd3abc8591373216c011b050ed35e297c0368407460915ee5594eb7eb618d03f'
ROOT_SCHEMA = 'D19-Root-conditional-stage-admission-v1'
GATES = ('admitted','resource_admitted','scientific_qualified','stage_complete')


def need(condition, message):
    if not condition:
        raise ValueError(message)


def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()


class Saved:
    def __init__(self):
        self.inputs = {}

    def pin(self,path):
        path = Path(path).resolve()
        need('.partial' not in path.name,'partial bodies are never opened by the reader projection')
        body = path.read_bytes()
        row = dict(path=str(path),bytes=len(body),sha256=hashlib.sha256(body).hexdigest())
        if str(path) in self.inputs:
            need(self.inputs[str(path)] == row,'complete input changed during projection')
        self.inputs[str(path)] = row
        return row

    def read(self,path):
        row = self.pin(path); body = Path(row['path']).read_bytes()
        need(hashlib.sha256(body).hexdigest() == row['sha256'],'stable complete JSON read')
        return json.loads(body)

    def declared(self,row,expected=None):
        need(type(row) is dict and set(row) == {'path','bytes','sha256'},'complete raw pin')
        if expected is not None:
            need(row['path'] == str(Path(expected).resolve()),'exact current study path')
        need(self.pin(row['path']) == row,'changed declared complete bytes')
        return self.read(row['path'])

    def stable(self):
        for row in tuple(self.inputs.values()):
            need(self.pin(row['path']) == row,'final complete raw stability')


def current_job(saved,recipe):
    identity = recipe['stage_id']; directory = STUDY/'actual'/identity
    path = STUDY/'root/admission'/(identity+'-v1.json')
    need(path.is_file(),'closed cohort requires exact attempted-job Root decision')
    decision = saved.read(path)
    need(decision['schema'] == ROOT_SCHEMA and decision['stage_id'] == identity
         and decision['stage'] == recipe['stage'],'exact current Root stage decision')
    need(all(type(decision[key]) is bool for key in GATES),'typed Root whole-stage gates')
    plan = saved.declared(decision['plan'],STUDY/'root/plans'/(identity+'-v1.json'))
    need(plan['Root_recipe'] == recipe and plan['case_id'] == identity,'exact attempted recipe')
    need(plan['protocol']['sha256'] == PROTOCOL_SHA,'same frozen main protocol')
    for key,target in (('header',directory/'worker-header.json'),('terminal',directory/'terminal.json'),
                       ('observer',STUDY/'actual'/(identity+'.observer')/'observer.json')):
        saved.declared(decision[key],target)
    saved.declared(decision['C_review'])
    if decision['admitted']:
        need(all(decision[key] is True for key in GATES),'all four true gates for an admitted job')
        packet = saved.declared(decision['result'],directory/'result.json')
        need(packet['status'] == 'COMPLETE' and packet['error'] is None
             and packet['source_unchanged'] is True,'complete current admitted worker')
        science = packet['scientific_result']
        need(type(science) is dict and science['job_record_complete'] is True
             and science['stage_complete'] is True,'complete current admitted scientific packet')
        state = 'ADMITTED_ACQUISITION'
    else:
        need(all(decision[key] is False for key in GATES),'closed failure has four explicit false gates')
        need(decision.get('result') is None and type(decision.get('failure')) is dict,
             'active complete failure pin, no accepted result')
        packet = saved.declared(decision['failure'],directory/'failure.json')
        need(identity == 'train-0' and packet['status'] == 'FAILED_CASE_NOT_ADMITTED'
             and packet['scientific_result'] is None and packet['native_requests_started'] == 0
             and packet['work_snapshots'] == [] and packet['first_Root_fault'] is False,
             'exact preserved pretraining control failure, no returned episode to salvage')
        need(packet['error']['type'] == 'CorpusFormatError'
             and packet['error']['message'] == 'ALL-premise least closure',
             'exact complete failure classification')
        science = None; state = 'WHOLE_JOB_FAILED_CONTROL_EXPECTATION'
    observer = saved.read(decision['observer']['path'])
    return dict(stage_id=identity,stage=recipe['stage'],state=state,
        admission=decision,admission_source=saved.pin(path),plan=decision['plan'],
        packet_source=decision['result'] if decision['admitted'] else decision['failure'],
        observer_sample_seconds=observer['elapsed_seconds'],
        whole_peak_bytes=observer['final_conservative_whole_peak_bytes'],
        worker_status=packet['status'],Native_started=packet['native_requests_started'],
        callbacks=packet['callbacks'],error=packet['error'],science=science,packet=packet)


def proof_view(saved,job,case):
    """Join selected primitive cards to the current encoded owner, not replay it."""
    science = job['science']; spec = case['spec']; search = case['search']; gate = case['proof_check']
    proof = search['proof']
    need(job['admission']['admitted'] is True and proof is not None
         and gate['status'] == 'HOST_REGION_NATIVE_ACCEPTED'
         and gate['native_proof_accepted'] is True and gate['host_check']['accepted'] is True
         and gate['region']['complete'] is True,'all saved donor proof gates')
    query = gate['native_record']
    need(query['result']['status'] == 'accepted' and query['request']['blocks'] == []
         and query['request']['proof'] == proof and query['request']['target'] == spec['target']
         and query['request']['theory'] == spec['theory'],'exact saved accepted proof request')
    need(sum(row == query for row in job['packet']['native_queries']) == 1,'unique current owned Native record')
    need(science['native_records'] == job['packet']['native_queries'],'same current Native record list')
    need(len(proof) == spec['length'] == 7 and len(search['placements']) == 14,
         'all original fixed-length donor rows and command/guard placements')
    model = case['model']; lookup = {tuple(row['key']):row for row in model['placements']}
    need(len(lookup) == len(model['placements']),'unique current encoded keys')
    tiles = []; ids = set()
    for key in search['placements']:
        need(type(key) is list and len(key) == 4 and all(type(v) is int for v in key),'exact saved selected key')
        tile = copy.deepcopy(lookup[tuple(key)])
        row,index = tile['command_reference']
        need(model['domains'][row][index] == proof[row],'selected card original primitive command')
        for point,value in tile['marks']:
            if point[1] == 100:
                need(type(value) is int and 0 <= value < len(model['word_dictionary']),
                     'strict complete-word ID, including zero')
                ids.add(value)
        tiles.append(tile)
    need(type(model['word_terminator']) is int and model['word_terminator'] == 256,'explicit terminator')
    words = {}
    for identity in sorted(ids):
        raw = model['word_dictionary'][identity]
        words[str(identity)] = dict(hex=raw,literal=json.loads(bytes.fromhex(raw).decode('utf-8')))
    return dict(id=spec['id'],stage_id=job['stage_id'],method='S0',title=spec['title'],
        spec=spec,proof=proof,target=spec['target'],tiles=tiles,words=words,word_terminator=256,
        proof_check=gate,admitted_proof=True,source=job['packet_source'],
        scope='Fresh conventional S0 searched donor certificate. All seven primitive rows and fourteen original selected command/guard placements retained. Translation-only aligned word-point cards; no physical Wang, learned or recipient-search proof claim.')


def main():
    saved = Saved(); protocol_path = STUDY/'root/protocol-v1.json'
    protocol = saved.read(protocol_path)
    need(saved.pin(protocol_path)['sha256'] == PROTOCOL_SHA,'exact frozen main population')
    need(protocol['population']['whole_jobs'] == 34 and protocol['population']['evaluation_slots'] == 192,
         'complete original study denominator')
    disposition_path = STUDY/'root/Root-closed-main-population-disposition-v1.json'
    disposition = saved.read(disposition_path)
    need(saved.pin(disposition_path)['sha256'] == DISPOSITION_SHA
         and disposition['current_frozen_study_closed'] is True,
         'exact independently reviewed Root closed population')
    saved.declared(disposition['C_failure_review'])
    saved.declared(disposition['C_full_population_disposition'])
    negative_path = STUDY/'diagnostics-L/typed-training-corpus-control-complete-failure-Source-negative-v1.json'
    negative = saved.read(negative_path)
    documents = {}
    for phase in ('acquire','train','evaluate'):
        documents[phase] = saved.declared(protocol['phase_inputs'][phase])
    recipes = protocol['job_recipes']; need(len(recipes) == 34,'all declared jobs')
    need(len(disposition['jobs']) == 34,'all closed population status rows')
    disposition_rows = {row['stage_id']:row for row in disposition['jobs']}
    need(len(disposition_rows) == 34,'unique Root disposition identities')
    attempted = {}
    for recipe in recipes:
        if recipe['stage_id'] in ('acquire-0','acquire-1','train-0'):
            attempted[recipe['stage_id']] = current_job(saved,recipe)
    need(set(attempted) == {'acquire-0','acquire-1','train-0'},'three preserved once actuals')
    need(attempted['acquire-0']['admission']['admitted'] is True
         and attempted['acquire-1']['admission']['admitted'] is True
         and attempted['train-0']['admission']['admitted'] is False,
         'two admitted acquisitions and one independently rejected whole training attempt')
    jobs = []; training = []; evaluation = []; proofs = []; inventory = []
    Native_statuses = {}; Native_completed = 0
    for recipe in recipes:
        identity = recipe['stage_id']; stage = recipe['stage']
        closed = disposition_rows[identity]
        need(closed['stage'] == stage and closed['required_upstream_ids'] == recipe['required_upstream_ids'],
             'literal closed status recipe and dependency match')
        if identity in attempted:
            job = attempted[identity]; public = {key:value for key,value in job.items() if key not in ('packet','science')}
            public['complete_record_returned'] = job['science'] is not None
            need(closed['admission'] == job['admission_source'],'same exact Root decision in closed disposition')
            need(closed['status'] == ('ROOT_ADMITTED' if stage == 'acquire' else 'WHOLE_JOB_FAILED_BEFORE_TRAINING'),
                 'exact attempted-job closed status')
            jobs.append(public)
            for query in job['packet']['native_queries']:
                status = query['result']['status'];Native_statuses[status] = Native_statuses.get(status,0)+1
                Native_completed += 1
            if stage == 'acquire':
                science = job['science']; case = science['records'][0]
                expected = documents['acquire']['donors'][recipe['donor_indices'][0]]
                need(case['spec'] == expected,'literal declared searched donor')
                proofs.append(proof_view(saved,job,case))
                need(len(science['certificates']) == 4 and science['pairing']['paired_units'] == 3,
                     'current saved acquisition census, not historical forecast')
                inventory.append(dict(stage_id=identity,donor_id=case['spec']['id'],
                    pairing=science['pairing'],libraries=science['libraries'],
                    certificates=science['certificates'],source=job['packet_source'],
                    scope='Per-donor admitted exports only. No merged inventory was reconstructed or admitted because training controls failed first.'))
        else:
            need(closed['status'] == 'UNAVAILABLE_REQUIRED_STAGE' and closed['admission'] is None,
                 'unavailable is Root closed disposition, not projected search failure')
            need('train-0' in recipe['required_upstream_ids'],'all remaining declared jobs depend on rejected train0')
            need(not (STUDY/'actual'/identity).exists()
                 and not (STUDY/'actual'/(identity+'.observer')).exists(),
                 'dependent job was not executed; no hidden record adoption')
            need(not (STUDY/'root/admission'/(identity+'-v1.json')).exists(),
                 'no fabricated missing-job admission')
            jobs.append(dict(stage_id=identity,stage=stage,state='UNAVAILABLE_REQUIRED_STAGE',
                failed_required_stage='train-0',recipe=recipe,admission=None,packet_source=None,
                observer_sample_seconds=None,whole_peak_bytes=None,complete_record_returned=False))
        if stage == 'train':
            for descriptor in recipe['episodes']:
                training.append(dict(descriptor=descriptor,stage_id=identity,returned=False,
                    search_status=None,proof_status=None,admitted_proof=False,updates=0,
                    state=('UNAVAILABLE_CONTROL_FAILURE' if identity == 'train-0' else 'UNAVAILABLE_REQUIRED_STAGE')))
        elif stage == 'evaluate':
            for source_index,method in enumerate(recipe['method_order']):
                evaluation.append(dict(stage_id=identity,case_id=recipe['case_id'],
                    order_label=recipe['order_label'],stratum=recipe['stratum'],method=method,
                    source_index=source_index,rng_seeds=recipe['rng_seeds'],returned=False,
                    state='UNAVAILABLE_REQUIRED_STAGE',search_status=None,proof_status=None,
                    admitted_proof=False,attempts=None,attempt_unit=None,
                    selector_decisions=None,pool_continuations=None,selector_order_changes=None,
                    marginal_seconds=None,proof_view_index=None))
    need(len(jobs) == 34 and len(training) == 32 and len(evaluation) == 192 and len(proofs) == 2,
         'full visible job/training/evaluation/proof populations')
    need(Native_completed == 100 and Native_statuses == {'accepted':50,'rejected':50},
         'complete current Native census, deliberate rejects preserved')
    paired = set(); principal = set()
    for exported in inventory:
        for unit in exported['pairing']['units']:
            paired.add(unit['paired_unit_id']);principal.add(unit['principal_structural_id'])
    total = sum(row['observer_sample_seconds'] for row in jobs if row['observer_sample_seconds'] is not None)
    need(total == disposition['unique_three_actual_observer_samples_seconds'],'same unique cold observer samples')
    output = dict(schema='D19-passive-conditional-selector-closed-study-reader-v1',
        summary=dict(planned_jobs=34,attempted_jobs=3,admitted_acquisitions=2,
            failed_train_jobs=1,dependent_unavailable_jobs=31,training_episode_slots=32,
            training_episodes_executed=0,policy_updates=0,evaluation_slots=192,
            evaluation_slots_executed=0,evaluation_UNKNOWN=0,donor_proofs=2,
            donor_primitive_rows=14,selected_tiles=28,profile_certificate_occurrences=8,
            per_donor_paired_unit_occurrences=6,literal_paired_ID_census=len(paired),
            literal_principal_ID_census=len(principal),Native_completed=100,Native_statuses=Native_statuses),
        protocol=protocol,documents=documents,jobs=jobs,training=training,evaluation=evaluation,
        proofs=proofs,inventory=inventory,total_unique_observer_sample_seconds=total,
        closed_population=disposition,closed_population_source=saved.pin(disposition_path),
        failure_Source_negative=negative,failure_Source_negative_pin=saved.pin(negative_path),
        failure_explanation=dict(kind='CONTROL_EXPECTATION_INCONSISTENCY',
            message='The saved failure reports CorpusFormatError("ALL-premise least closure") before any episode. Manual Source reasoning identifies an inconsistent literal expectation: relevant=[] was expected, but the declared grounded-intersection definition gives [p]. This is not a saved local classifier receipt. The classifier correctly leaves the target ungrounded. This is an authored control expectation failure, not a failed theorem, search UNKNOWN or exhausted resource ceiling.',
            no_repair_or_retry=True,no_admitted_policy=True,no_learned_comparison=True),
        cost_scope='Each of the three attempted cold jobs counted once, including the failed training setup. Observer elapsed is a before-final-receipt sample, not tool end-to-end. Entry/setup/search/Native/output/custody clocks overlap and are not summed as disjoint phases.',
        scope='Complete saved JSON/raw pin projection only. No proof, family, learner, numeric, compiler, Graph or Native replay and no new admission. Domain results never feed this learner. All original failed, planned and unavailable outcomes retained; no learned/RL/GCTS benefit conclusion is available.',
        scientific_imports=0,scientific_calls=0,partial_files_parsed=0)
    saved.stable(); output['input_pins'] = list(saved.inputs.values())
    destination = STUDY/'publication/conditional-selector-data.json'
    with destination.open('x') as stream:
        json.dump(output,stream,ensure_ascii=True,sort_keys=True,indent=2,allow_nan=False);stream.write('\n')
    print(json.dumps(dict(path=str(destination),bytes=destination.stat().st_size,
                         sha256=hashlib.sha256(destination.read_bytes()).hexdigest())))


if __name__ == '__main__':
    main()
