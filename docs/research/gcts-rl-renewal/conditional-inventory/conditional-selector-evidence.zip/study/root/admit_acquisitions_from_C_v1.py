"""Root-only passive acquisition admission after exact independent C review.

No scientific imports, inference, policy arithmetic, or saved-checker replay.
The independent actual review supplies scientific qualification. This author
joins the complete immutable custody/export carriers and writes the strict
current-stage seal last. It never admits training or repairs an interrupted run.
"""
from pathlib import Path
import hashlib
import json
import sys

STUDY = Path(__file__).resolve().parents[1]
CAPS = dict(work_seconds=160, positive_seconds=180, custody_seconds=210,
    observer_fallback_seconds=225, memory_bytes=1073741824,
    physical_bytes=134217728, result_bytes=50331648, log_bytes=4194304,
    reserved_outer_bytes=9437184, root_callbacks=400000000)
SEAL_FIELDS = {'stage_id','stage','resource_admitted','stage_complete',
    'plan','result','header','terminal','observer','export_sha256',
    'whole_seconds','whole_peak_bytes','prior_cost_receipts'}


def wire(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,
        allow_nan=False).encode('utf-8')


def pin(path):
    path = Path(path).resolve()
    body = path.read_bytes()
    return dict(path=str(path),bytes=len(body),sha256=hashlib.sha256(body).hexdigest())


def read(path):
    path = Path(path)
    assert '.partial' not in path.name and not path.is_symlink()
    return json.loads(path.read_bytes())


def main(identity, review_path):
    assert identity in ('acquire-0','acquire-1')
    review_path = Path(review_path).resolve()
    assert review_path.is_relative_to(STUDY/'review-C')
    components = dict(plan=STUDY/'root/plans'/(identity+'-v1.json'),
        result=STUDY/'actual'/identity/'result.json',
        header=STUDY/'actual'/identity/'worker-header.json',
        terminal=STUDY/'actual'/identity/'terminal.json',
        observer=STUDY/'actual'/(identity+'.observer')/'observer.json')
    pins = {key:pin(path) for key,path in components.items()}
    plan,result,header,terminal,observer = (read(components[key])
        for key in ('plan','result','header','terminal','observer'))
    review = read(review_path)
    assert review['schema']=='D19-C-conditional-stage-actual-review-v1'
    assert review['stage_id']==identity and review['stage']=='acquire'
    assert review['failures']==[] and review['Root_admission_issued'] is False
    assert type(review['partial_files_parsed']) is int and review['partial_files_parsed']==0
    for key in ('review_passed','resource_admitted','scientific_qualified','stage_complete'):
        assert review[key] is True
    assert review['checks'] and all(row['passed'] is True for row in review['checks'])
    for key,row in pins.items(): assert review[key]==row
    assert plan['case_id']==identity and plan['stage']=='acquire'
    assert plan['limits']==CAPS and plan['required_upstream_ids']==plan['upstream_receipts']==[]
    assert len(plan['files'])==49
    for row in plan['files']: assert pin(row['path'])==row
    assert all(value['case_id']==identity for value in (result,header,terminal,observer))
    assert result['status']==header['status']=='COMPLETE'
    assert result['error'] is None and result['first_Root_fault'] is False
    assert result['source_unchanged'] is header['source_unchanged'] is True
    assert header['native_closed_and_reaped'] is True and header['first_Root_fault'] is False
    assert header['result']==terminal['result']==pins['result'] and terminal['header']==header
    assert terminal['header_valid'] is terminal['sources_unchanged'] is terminal['threads_terminal'] is True
    assert terminal['process_exit_code']==observer['parent_exit_code']==0
    assert terminal['reason'] is observer['reason'] is None
    assert terminal['errors']==observer['errors']==[]
    assert terminal['final_custody_gate_passed'] is observer['resource_candidate_accepted'] is True
    assert terminal['known_exit_seconds']<=CAPS['positive_seconds']
    assert observer['fallback_trigger_seconds'] is None
    assert observer['owned_child']['plan_sha256']==pins['plan']['sha256']
    assert type(observer['final_conservative_whole_peak_bytes']) is int
    assert observer['final_conservative_whole_peak_bytes']<CAPS['memory_bytes']
    assert observer['final_observer_gate_seconds']<=CAPS['custody_seconds']
    for log in list(terminal['logs'].values())+list(observer['logs'].values()):
        assert log['eof'] is True and log['overflow'] is False
    science = result['scientific_result']
    assert science['stage_id']==identity and science['stage']=='acquire'
    assert science['job_record_complete'] is science['stage_complete'] is science['qualified'] is True
    assert science['all_profile_fragments_accepted'] is True
    assert science['resource_admitted'] is False and science['export']['qualified'] is True
    assert science['native_records']==result['native_queries']
    export_sha = hashlib.sha256(wire(science['export'])).hexdigest()
    assert review['export_sha256']==export_sha
    assert wire(review['whole_seconds'])==wire(observer['elapsed_seconds'])
    assert review['whole_peak_bytes']==observer['final_conservative_whole_peak_bytes']
    census=[]
    for directory in (STUDY/'actual'/identity,STUDY/'actual'/(identity+'.observer')):
        assert directory.is_dir() and not directory.is_symlink()
        for path in sorted(directory.rglob('*')):
            assert not path.is_symlink()
            if path.is_file(): census.append(pin(path))  # Opaque partials: raw pin only.
    census.sort(key=lambda row:row['path'])
    assert census==review['complete_actual_file_census']
    assert sum(row['bytes'] for row in census)<=CAPS['physical_bytes']
    seen=set()
    for row in review['input_pins']:
        assert row['path'] not in seen and pin(row['path'])==row
        seen.add(row['path'])
    assert all(row['path'] in seen for row in pins.values())
    seal_path=STUDY/'root/seals'/(identity+'-v1.json')
    admission_path=STUDY/'root/admission'/(identity+'-v1.json')
    assert not seal_path.exists() and not admission_path.exists()
    envelope=dict(stage_id=identity,stage='acquire',resource_admitted=True,
        stage_complete=True,**pins,export_sha256=export_sha,
        whole_seconds=observer['elapsed_seconds'],
        whole_peak_bytes=observer['final_conservative_whole_peak_bytes'],prior_cost_receipts=[])
    assert set(envelope)==SEAL_FIELDS
    seal_body=(json.dumps(envelope,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode()
    seal_pin=dict(path=str(seal_path),bytes=len(seal_body),sha256=hashlib.sha256(seal_body).hexdigest())
    admission=dict(schema='D19-Root-conditional-stage-admission-v1',stage_id=identity,
        stage='acquire',admitted=True,resource_admitted=True,scientific_qualified=True,
        stage_complete=True,**pins,C_review=pin(review_path),helper=pin(__file__),
        export_sha256=export_sha,seal=seal_pin,protocol=plan['protocol'],
        whole_seconds=envelope['whole_seconds'],whole_peak_bytes=envelope['whole_peak_bytes'],
        complete_actual_file_census=census,scientific_calls=0,scientific_imports=0,
        scientific_replays=0,numeric_policy_replays=0,partial_files_parsed=0,
        scope='Root passive custody/export admission after independent complete actual C PASS. Scientific authority remains the exact reviewed execution and C receipt; this author does no proof/family/checker replay. No training admission or earlier result adoption.',
        cost_scope='whole_seconds uses the frozen observer.elapsed_seconds sample; final observer gate and stdout times are separate, later observations.')
    # Recheck every reviewed raw body before the exclusive writes.
    for row in review['input_pins']+list(pins.values()): assert pin(row['path'])==row
    (STUDY/'root/admission').mkdir(exist_ok=True)
    (STUDY/'root/seals').mkdir(exist_ok=True)
    with admission_path.open('xb') as stream:
        stream.write((json.dumps(admission,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode())
    with seal_path.open('xb') as stream: stream.write(seal_body)
    assert pin(seal_path)==seal_pin
    print(json.dumps(dict(admission=pin(admission_path),seal=seal_pin,scientific_calls=0)))


if __name__=='__main__':
    assert len(sys.argv)==3
    main(sys.argv[1],sys.argv[2])
