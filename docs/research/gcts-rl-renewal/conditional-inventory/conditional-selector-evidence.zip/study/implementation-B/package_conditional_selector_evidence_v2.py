"""Pure-passive closed-main D19 ZIP author; Root only after exact peer review.

Inputs are an explicit reviewed publication inventory plus exact protocol,
Source closure, all34templates, and the three terminal main actuals. No research
imports/calls, extraction, primary reader/index access, or whole-study scan.
Opaque partials are copied/hashed as raw bytes and are never JSON parsed.
"""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import stat
import zipfile

VERSION = 'D19-closed-main-conditional-selector-evidence-packager-v2'
STUDY = Path(__file__).resolve().parents[1]
REPO = STUDY.parents[1]
OUTPUT = STUDY/'publication'
PROTOCOL_SHA = 'ae4daf42c3d5099da479690cc083e5c05a2422fc165cb64818a2a28a3a469136'
ACTUAL_IDS = ('acquire-0','acquire-1','train-0')
SEAL_FIELDS = {'stage_id','stage','resource_admitted','stage_complete','plan','result','header',
    'terminal','observer','export_sha256','whole_seconds','whole_peak_bytes','prior_cost_receipts'}
REQUIRED_ROLES = {'closed_population_disposition','C_train_failure_review','B_failure_assessment',
    'L_failure_assessment','negative_predecessor_Source','negative_predecessor_review',
    'current_acquisition_author_Source','current_acquisition_author_review','projector_Source',
    'template_Source','reader_data_review'}


def need(value,message):
    if not value:
        raise ValueError(message)


def encoded(value):
    return (json.dumps(value,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode('utf-8')


def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode('utf-8')


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def regular(path):
    path = Path(path)
    need(path.is_absolute() and path.is_file() and not path.is_symlink() and path == path.resolve(),
         'canonical absolute regular file, no symlink or path alias')
    return path


def pin(path):
    path = regular(path); h = hashlib.sha256(); length = 0
    with path.open('rb') as stream:
        for body in iter(lambda:stream.read(1048576),b''):
            h.update(body); length += len(body)
    return dict(path=str(path),bytes=length,sha256=h.hexdigest())


def verify(row):
    need(type(row) is dict and set(row) == {'path','bytes','sha256'} and type(row['bytes']) is int
         and row['bytes'] >= 0 and type(row['sha256']) is str and len(row['sha256']) == 64,
         'exact declared raw pin')
    need(pin(row['path']) == row,'current body differs from frozen raw pin')
    return Path(row['path'])


def read(path):
    path = regular(path)
    need('.partial' not in path.name,'partial JSON must never be parsed')
    return json.loads(path.read_bytes())


def relative_member(name):
    need(type(name) is str and name and '\\' not in name and '\x00' not in name,'ordinary portable ZIP member')
    path = PurePosixPath(name)
    need(not path.is_absolute() and str(path) == name and all(p not in ('','.','..') for p in path.parts),
         'safe exact relative ZIP member, no extraction traversal')
    return name


def main(inventory_path):
    inventory_path = regular(inventory_path)
    need(inventory_path.is_relative_to(STUDY/'root'),'Root-owned explicit main publication inventory')
    inventory_pin = pin(inventory_path); inventory = read(inventory_path)
    need(inventory['schema'] == 'D19-conditional-main-publication-inventory-v1','exact reviewed inclusion inventory')
    need(type(inventory['files']) is list and inventory['files'],'explicit additional main Sources/reviews/metadata')
    roles = {row['role'] for row in inventory['files']}
    need(REQUIRED_ROLES <= roles,'missing required failure/disposition/negative/current-author/display Source reviews')
    disposition_rows = [row for row in inventory['files'] if row['role'] == 'closed_population_disposition']
    need(len(disposition_rows) == 1,'one exact Root closed-population disposition')
    disposition_pin = {key:disposition_rows[0][key] for key in ('path','bytes','sha256')}
    disposition = read(verify(disposition_pin))
    authority_path = verify(inventory['publication_authority']); authority = read(authority_path)
    need(authority_path.is_relative_to(STUDY/'root') and authority['publication_authorized'] is True
         and authority['scientific_calls'] == 0,'separate reviewed Root passive publication authority')
    reader = verify(inventory['reader']); data = verify(inventory['data'])
    need(reader == OUTPUT/'conditional-selector.html' and data == OUTPUT/'conditional-selector-data.json',
         'two exact standalone new-prefix passive reader bodies')
    protocol_path = STUDY/'root/protocol-v1.json'; protocol_pin = pin(protocol_path); protocol = read(protocol_path)
    need(protocol_pin['sha256'] == PROTOCOL_SHA and protocol['experiment'] == 'D19-conditional-family-selector-v1',
         'immutable main protocol, not separate domain track')
    recipes = protocol['job_recipes']; ids = [row['stage_id'] for row in recipes]
    need(len(recipes) == 34 and len(set(ids)) == 34 and ids[:2] == ['acquire-0','acquire-1']
         and len([r for r in recipes if r['stage'] == 'train']) == 8
         and len([r for r in recipes if r['stage'] == 'evaluate']) == 24, 'full original closed main denominator')
    need(disposition['schema'] == 'D19-Root-closed-main-population-disposition-v1'
         and disposition['current_frozen_study_closed'] is disposition['no_retry_or_prefix_salvage'] is True
         and disposition['learned_policy_available'] is disposition['GCTS_RL_advantage_established'] is False,
         'closed negative study, no learned policy or advantage')
    expected_counts = dict(planned_jobs=34,attempted_jobs=3,admitted_acquisitions=2,failed_training_jobs=1,
        unrun_dependent_jobs=31,unrun_training_jobs=7,unrun_evaluation_jobs=24,
        planned_training_episodes=32,returned_training_episodes=0,planned_evaluation_slots=192,
        returned_evaluation_slots=0,unavailable_evaluation_slots=192)
    need(disposition['counts'] == expected_counts and len(disposition['jobs']) == 34,
         'all34 jobs/32episodes/192slots retain the exact closed disposition')
    for recipe,row in zip(recipes,disposition['jobs']):
        sid = recipe['stage_id']; expected_status = ('ROOT_ADMITTED' if sid.startswith('acquire-') else
            'WHOLE_JOB_FAILED_BEFORE_TRAINING' if sid == 'train-0' else 'UNAVAILABLE_REQUIRED_STAGE')
        need(row['stage_id'] == sid and row['stage'] == recipe['stage']
             and row['required_upstream_ids'] == recipe['required_upstream_ids'] and row['status'] == expected_status,
             'every original recipe has exact attempted/unavailable status')
        if sid in ACTUAL_IDS:
            need(verify(row['admission']) == STUDY/'root/admission'/(sid+'-v1.json'), 'exact current Root disposition admission pin')
        else:
            need(row['admission'] is None,'unrun stage has no fabricated admission')
    closure_path = STUDY/'root/main-source-closure-v1.json'; closure = read(closure_path)
    template_index_path = STUDY/'root/materialized-main-templates-v1.json'; template_index = read(template_index_path)
    need(len(template_index['templates']) == 34 and template_index['protocol'] == protocol_pin,
         'exact original34-template materialization index')
    template_pins = {row['path']:row for row in template_index['templates']}
    need(len(template_pins) == 34,'unique original template paths')
    common = closure['common_source']; external = {row['path']:row for row in common if not Path(row['path']).is_relative_to(STUDY)}
    runtime_paths = closure['runtime_module_paths']
    need(len(runtime_paths) == 35 and len(set(runtime_paths)) == 35,'exact active runtime closure, not entire inherited runtime directory')
    python_path = str(verify(closure['python']))
    native_exec = str(Path(closure['native']['executable_path']))
    selected = {}; omitted = {}; role_map = {}; input_pins = {}

    def register(path,role,allow_external=False):
        path = regular(path); row = pin(path); identity = str(path)
        need(identity not in omitted, 'pin-only runtime identity cannot also be an archived body')
        need(not any(part in ('.git','.aws','.env','.gcts-active','node_modules','__pycache__') for part in path.parts),
             'forbidden unrelated/private/cache path')
        if path.is_relative_to(STUDY):
            rel = path.relative_to(STUDY)
            need(rel.parts[0] in ('root','implementation-B','diagnostics-L','review-C','runtime','actual','publication'),
                 'explicit task-owned main path only')
            need(not any('domain' in part.lower() for part in rel.parts),'separate domain study excluded')
            need(not any(part in ('live-domain-download-v2','preimages') for part in rel.parts),
                 'arbitrary drafts/history excluded; named negative predecessors use explicit non-preimage files')
            need(path.name != 'admit_seal_conditional_stage_v1.py' and not path.name.startswith('passive-sealer-'),
                 'unused unreviewed generic training sealer is not an executed/admission/publication dependency')
            if rel.parts[0] == 'publication':
                need(path in (reader,data),'no generic publication scan/archive/self-cycle')
            member = relative_member('study/'+rel.as_posix())
        else:
            need(allow_external and identity in external and path.is_relative_to(REPO), 'outside dependency must be exact declared plan Source')
            member = relative_member('declared-dependencies/'+path.relative_to(REPO).as_posix())
        if path.suffix.lower() in ('.zip','.tar') or path.name.endswith(('.tar.gz','.tgz')):
            raise ValueError('archive outputs/history archives excluded')
        need(member != 'snapshot-manifest.json','reserved embedded manifest name')
        if identity in selected:
            need(selected[identity]['archive_path'] == member and selected[identity]['sha256'] == row['sha256'], 'duplicate input alias changed')
        else:
            selected[identity] = dict(row,archive_path=member,opaque_partial=('.partial' in path.name))
        input_pins[identity] = row; role_map.setdefault(identity,set()).add(role)

    def omit(row,reason):
        need(row['path'] not in selected, 'an archived body cannot also be declared omitted pin-only')
        verify(row); input_pins[row['path']] = row
        omitted[row['path']] = dict(row,reason=reason)

    for row in common:
        verify(row)
        if row['path'] in (python_path,native_exec):
            omit(row,'Pinned isolated Python or declared Native executable; executable body is not redistributed.')
        else:
            register(row['path'],'exact_active_common_Source',allow_external=True)
    for path in runtime_paths:
        need(Path(path).is_relative_to(STUDY/'runtime') and any(row['path'] == path for row in common),
             'every active runtime filename is an exact closed common Source pin')
    for row in protocol['phase_inputs'].values():
        register(verify(row),'full_prospective_phase_input')
    for path,role in ((protocol_path,'closed_main_protocol'),(closure_path,'active_Source_closure'),
        (template_index_path,'all34_template_index'),
        (STUDY/'root/materialize_conditional_plans_v1.py','reviewed_plan_materializer_Source'),
        (inventory_path,'explicit_publication_inventory'),(authority_path,'Root_publication_authority'),
        (Path(__file__).resolve(),'reviewed_packager_Source'),(reader,'standalone_reader'),(data,'standalone_reader_data')):
        register(path,role)
    for recipe in recipes:
        sid = recipe['stage_id']; path = STUDY/'root/templates'/(sid+'-v1.json'); template = read(path)
        need(str(path) in template_pins,'every planned template appears in frozen original index')
        verify(template_pins[str(path)])
        need(template['case_id'] == sid and template['stage'] == recipe['stage'] and template['Root_recipe'] == recipe,
             'all34 original templates bind exact protocol recipes')
        register(path,'planned_template')
        if sid not in ACTUAL_IDS:
            need(not (STUDY/'actual'/sid).exists() and not (STUDY/'actual'/(sid+'.observer')).exists(),
                 'closed cohort unexpectedly contains a later main actual')
    actual_summary = []; direct_costs = []; native_statuses = []
    for sid in ACTUAL_IDS:
        plan_path = STUDY/'root/plans'/(sid+'-v1.json'); plan = read(plan_path)
        need(plan['case_id'] == sid and plan['stage'] == ('acquire' if sid.startswith('acquire-') else 'train'),
             'one of exactly three once main actual plans')
        register(plan_path,'executed_once_plan')
        for row in plan['files']:
            verify(row)
            if row['path'] in (python_path,native_exec):
                omit(row,'Pinned isolated Python or declared Native executable, not redistributed.')
            else:
                register(row['path'],'executed_plan_Source_or_phase',allow_external=True)
        directory = STUDY/'actual'/sid; observer_dir = STUDY/'actual'/(sid+'.observer')
        consumed = read(directory/'CONSUMED.json')
        grants = []
        for grant_path in sorted((STUDY/'root/grants').glob(sid+'-grant-*.json')):
            if pin(grant_path)['sha256'] == consumed['grant_sha256']:
                grants.append(grant_path)
        need(len(grants) == 1,'exact consumed grant body per once actual')
        register(grants[0],'consumed_once_grant')
        for folder in (directory,observer_dir):
            need(folder.is_dir() and not folder.is_symlink(),'three complete actual and external observer directories')
            for path in sorted(folder.rglob('*')):
                need(not path.is_symlink(),'no links in actual closure')
                if not path.is_file():
                    continue
                row = pin(path)
                if path.parent.name == 'native' and path.name in ('boundary-oracle','code.bin'):
                    omit(row,'Exact actual Native executable or generated runtime table retained as raw pin only.')
                else:
                    register(path,'complete_actual_raw_custody_or_opaque_partial')
        observer_path = observer_dir/'observer.json'; observer = read(observer_path)
        admission_path = STUDY/'root/admission'/(sid+'-v1.json'); admission = read(admission_path)
        need(admission['schema'] == 'D19-Root-conditional-stage-admission-v1' and admission['stage_id'] == sid,
             'separate current Root admission for every terminal main actual, including failed train0')
        register(admission_path,'Root_whole_admission')
        register(verify(admission['C_review']),'independent_actual_review')
        if sid.startswith('acquire-'):
            register(verify(admission['helper']),'Root_passive_admission_author_Source')
            result_path = directory/'result.json'; result = read(result_path)
            need(admission['admitted'] is admission['resource_admitted'] is admission['scientific_qualified'] is admission['stage_complete'] is True,
                 'two exact whole-admitted fresh acquisitions')
            seal_path = STUDY/'root/seals'/(sid+'-v1.json'); seal = read(seal_path)
            need(set(seal) == SEAL_FIELDS and seal['stage_id'] == sid and seal['stage'] == 'acquire'
                 and seal['prior_cost_receipts'] == [] and seal['resource_admitted'] is seal['stage_complete'] is True
                 and seal['export_sha256'] == digest(result['scientific_result']['export'])
                 and result['scientific_result']['stage_complete'] is True, 'strict current two-acquisition direct seals/export digest')
            register(seal_path,'Root_acquisition_seal')
            status = 'ADMITTED_ACQUISITION'
        else:
            result_path = directory/'failure.json'; result = read(result_path)
            need(admission['admitted'] is admission['resource_admitted'] is admission['scientific_qualified'] is admission['stage_complete'] is False
                 and result['status'] == 'FAILED_CASE_NOT_ADMITTED' and result['scientific_result'] is None
                 and result['error']['type'] == 'CorpusFormatError'
                 and result['error']['message'] == 'ALL-premise least closure'
                 and result['native_requests_started'] == 0 and result['native_queries'] == [] and result['work_snapshots'] == [],
                 'original complete failed training body; no policy/prefix/Native/episode salvage')
            need(not (directory/'result.json').exists() and not (STUDY/'root/seals/train-0-v1.json').exists(),
                 'failed training cannot have a completed result or seal')
            status = 'FAILED_ONCE_NO_POLICY'
        actual_summary.append(dict(stage_id=sid,status=status,record=pin(result_path),Root_admission=pin(admission_path),
            observer=pin(observer_path),whole_seconds_sample=observer['elapsed_seconds'],
            whole_peak_bytes=observer['final_conservative_whole_peak_bytes']))
        direct_costs.append(observer['elapsed_seconds'])
        native_statuses.extend(row['result']['status'] for row in result['native_queries'])
    need(disposition['Native_completed'] == len(native_statuses)
         and disposition['Native_accepted'] == native_statuses.count('accepted')
         and disposition['Native_deliberate_control_compiler_rejected'] == native_statuses.count('rejected')
         and disposition['Native_unknown'] == sum(status.startswith('unknown') for status in native_statuses)
         and disposition['unique_three_actual_observer_samples_seconds'] == sum(direct_costs),
         'saved current Native status census and three unique direct cost samples')
    for row in inventory['files']:
        need(type(row) is dict and set(row) == {'path','bytes','sha256','role'} and type(row['role']) is str,
             'explicit uniquely role-labeled publication input row')
        raw = {key:row[key] for key in ('path','bytes','sha256')}; verify(raw)
        need(Path(row['path']).is_relative_to(STUDY), 'additional reviews/negatives/display must be task-owned')
        register(row['path'],row['role'])
    # Pin-only omission identity is never a substitute for a missing proof,
    # policy, result, reader body, or mathematical Source dependency.
    rows = []
    for identity,row in sorted(selected.items(),key=lambda pair:pair[1]['archive_path']):
        row = dict(row,roles=sorted(role_map[identity])); rows.append(row)
    need(set(selected).isdisjoint(omitted), 'selected body and pin-only omitted identities must be disjoint')
    names = [row['archive_path'] for row in rows]
    need(len(names) == len(set(names)),'unique safe relative member names')
    omitted_rows = [omitted[key] for key in sorted(omitted)]
    remaining = [sid for sid in ids if sid not in ACTUAL_IDS]
    snapshot = dict(schema='D19-closed-main-conditional-selector-snapshot-v1',packager=pin(Path(__file__).resolve()),
        inventory=inventory_pin,publication_authority=pin(authority_path),files=rows,omitted_runtime=omitted_rows,
        reader=pin(reader),data=pin(data),protocol=protocol_pin,actuals=actual_summary,
        population=dict(planned_jobs=34,executed_once_jobs=3,admitted_acquisitions=2,failed_training_jobs=1,
            unavailable_required_stage_jobs=31,unrun_training_jobs=7,unrun_evaluation_jobs=24,
            unavailable_stage_ids=remaining,planned_training_episodes=32,returned_training_episodes=0,
            trained_policy_exports=0,planned_evaluation_slots=192,returned_evaluation_slots=0,unavailable_evaluation_slots=192),
        unique_observer_seconds_sample_sum=sum(direct_costs),
        cost_scope='Three unique before-final-observer-receipt samples, including failure; not exact tool end-to-end and not a sum of overlapping nested clocks.',
        input_deduplication='Canonical absolute input path once, with all role references retained. Equal content at distinct original paths remains distinct logical evidence.',
        source_scope='Exact35active runtime modules/current Source closure,both normative masters,all34templates,three once actuals,two seals,three Root admissions and explicit reviewed main negatives/display. Fixed program JSON/microcode retained. Executables/generated Native tables are exact pins only. No domain run or unrelated draft/worktree body.',
        reference_scope='Arbitrary historical pin references inside archived documents are not recursively copied. Present members and explicitly omitted runtime dependencies are listed completely; this is the closed current-main snapshot.',
        qualification='Two donor acquisitions admitted; training-control failure prevents every learned policy/evaluation. No learning comparison, GCTS/RL gain or recovered successful prefix is claimed.',
        later_scope='Later installation/deployment/live checks and archive external manifest are outside this closed snapshot.',
        scientific_imports=0,scientific_calls=0,scientific_replays=0,partial_files_parsed=0)
    manifest_body = encoded(snapshot); archive = OUTPUT/'conditional-selector-evidence.zip'; dest = OUTPUT/'conditional-selector-evidence-manifest.json'
    need(not archive.exists() and not dest.exists(),'immutable publication targets already exist')
    OUTPUT.mkdir(exist_ok=True)
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9,allowZip64=True) as bundle:
        def info(name):
            z = zipfile.ZipInfo(relative_member(name),date_time=(1980,1,1,0,0,0))
            z.create_system = 3; z.external_attr = (stat.S_IFREG|0o644)<<16
            z.compress_type = zipfile.ZIP_DEFLATED; z.comment = b''; z.extra = b''
            return z
        bundle.writestr(info('snapshot-manifest.json'),manifest_body,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
        for row in rows:
            h = hashlib.sha256(); length = 0
            with regular(row['path']).open('rb') as source,bundle.open(info(row['archive_path']),'w') as target:
                for body in iter(lambda:source.read(1048576),b''):
                    h.update(body); length += len(body); target.write(body)
            need((length,h.hexdigest()) == (row['bytes'],row['sha256']),'input changed while streaming archive member')
    expected = {row['archive_path']:(row['bytes'],row['sha256']) for row in rows}
    expected['snapshot-manifest.json'] = (len(manifest_body),hashlib.sha256(manifest_body).hexdigest())
    seen = set()
    with zipfile.ZipFile(archive,'r') as bundle:
        for member in bundle.infolist():
            name = relative_member(member.filename)
            need(name in expected and name not in seen and not member.is_dir()
                 and stat.S_IFMT(member.external_attr>>16) == stat.S_IFREG
                 and member.date_time == (1980,1,1,0,0,0), 'ordinary deterministic ZIP member only')
            seen.add(name); h = hashlib.sha256(); length = 0
            with bundle.open(member,'r') as stream:
                for body in iter(lambda:stream.read(1048576),b''):
                    h.update(body); length += len(body)
            need((length,h.hexdigest()) == expected[name],'raw ZIP member hash/length verification')
    need(seen == set(expected),'all and only declared members, no links or extraction')
    for row in input_pins.values():
        verify(row)
    final = dict(snapshot,archive=pin(archive),all_members_raw_verified=True,
        raw_file_members=len(rows),regular_members_including_snapshot=len(seen),
        uncompressed_file_bytes=sum(row['bytes'] for row in rows),
        embedded_snapshot=dict(bytes=len(manifest_body),sha256=hashlib.sha256(manifest_body).hexdigest()))
    with dest.open('xb') as stream:
        stream.write(encoded(final))
    print(json.dumps(dict(archive=pin(archive),manifest=pin(dest),raw_files=len(rows),omitted_runtime=len(omitted_rows)),sort_keys=True))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--inventory',required=True)
    arguments = parser.parse_args()
    main(str(Path(arguments.inventory).resolve()))
