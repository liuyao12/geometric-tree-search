"""Freeze reviewer-owned ordinary JSON from the completed raw-only audit."""
import hashlib
import json
from pathlib import Path

C=Path('/private/tmp/gcts-cleanup-isolation-peer-20261019')
D=Path('/private/tmp/gcts-cleanup-isolation-ROOT-20261019')
P=Path('/private/tmp/gcts-direct-projection-review-20261019')
def descriptor(p):
    p=Path(p);b=p.read_bytes();return dict(path=str(p.resolve()),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def read(p):return json.loads(Path(p).read_bytes())
def save(name,o):
    p=C/name
    raw=(json.dumps(o,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode()
    with p.open('xb')as f:f.write(raw)
    return descriptor(p)
audit_pin=descriptor(C/'cleanup-false-bundle-raw-audit-v2.json')
a=read(audit_pin['path'])
assert a['check_count']==423 and a['mismatch_count']==0 and all(c['passed']for c in a['checks'])
m=read(a['manifest']['path']);d=read(a['declaration']['path']);cl=read(a['runtime_closure']['path'])
hd=read(a['harness_declaration']['path'])
old=read(a['prior_reviews']['components']['path'])
v7=read(a['prior_reviews']['runner_v7']['path'])
common=dict(reviewer_identity='/root/conventional_control_review',source_only=True,
    scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,
    component_imports=0,component_calls=0,helper_calls=0,fixture_calls=0,
    Native_calls=0,Model_calls=0,Reader_calls=0,inverse_calls=0,search_calls=0,
    opaque_decodes=0,process_launches=0,process_probes=0,
    full_pipeline_qualified=False,mathematical_proof_admitted=False,
    check_count=423,mismatch_count=0,audit=audit_pin,findings=[],
    current_master=a['current_master'],cohort='cleanup-isolation-v1')
ancestry=dict(
    prior_components=a['prior_reviews']['components'],prior_outer=a['prior_reviews']['outer'],
    prior_prospective=a['prior_reviews']['prospective'],
    current_runner_interim=a['prior_reviews']['runner_v7'],
    preserved_v5_negative=a['prior_reviews']['runner_v5_negative'],
    preserved_v6_negative=a['prior_reviews']['runner_v6_negative'],
    saved_V2_negative=a['prior_reviews']['saved_V2'],saved_V3_outcomes=a['prior_reviews']['saved_V3'])
authorship=[
    'One reviewer, /root/conventional_control_review, fills all three disclosed scopes; these are not three independent reviewer identities.',
    'Control authored historical symbolic/AND-helper/outer/protocol ancestors and earlier metadata reviews, including preserved missed descriptor and registration-coupling findings. Current Arena, adapter, harness and worker are separately authored; current cleanup runner changes are authored by Root. This review does not independently recertify Control own historical algorithms.',
    'Unchanged components are carried forward from the genuine exact V3b Source review after fresh whole-byte pin/AST checks. New cleanup implementation is carried forward from the separately completed v7 Source review and its actual inert forward/reverse proof; current bundle review checks full metadata coupling, not new runtime qualification.'
]
limits=dict(positive_worker_result_full_read_and_known_exit_monotonic_seconds=180,
    later_outer_custody_resource_terminal_seconds=210,observer_failure_watchdog_seconds=225,
    worker_highwater_bytes=1073741824,physical_all_outputs_plus_reserve_bytes=134217728,
    complete_logical_outputs_and_result_bytes=134217728,stdout_bytes=4194304,stderr_bytes=4194304,
    worker_receipt_bytes=4194304,runner_metadata_bytes=8388608,observer_folder_bytes=1048576,
    reserved_outer_metadata_bytes=9437184,Root_registration_bound=512,
    aggregate_arena_work=400000000,aggregate_adapter_operations=400000000,
    direct_Arena_qualification_limit_exceptions='Only declared tight negative probes; no replacement of invocation/global limits.',
    inverse_context_ceiling_unused=30000000,Native_calls=0,inverse_calls=0)
limitations=[
    'This is raw Source/AST/ordinary-metadata review only. Eight target Sources were parsed and compiled into unused code objects, never imported or executed. All eight complete input preimages were raw-hashed only; no Reader, Model, Native, inverse, proof engine, fixture, helper or process probe was called.',
    'Pinned interpreter/direct stdlib entry bytes, builtin/frozen/transitive stdlib and OS loader/process semantics remain trusted. Worker raw exec loading plus postload callable/code/globals/default identities is not a formal continuous integrity seal or a hostile-code sandbox.',
    'No current cleanup-isolation subject has been launched by this review. Prospective constraints and Source PASS do not imply successful runtime, cleanup permissions, deadlines, fit, helper qualification or permission to launch. A separately issued Root grant and exact later delta/freshness review are required.',
    'Same original positive180 and later outer210 gates remain. Observer225 is failure cleanup fallback, never extra admission time. Epoch begins at runner Source entry, excluding observer/interpreter startup; these are monotonic elapsed windows, not CPU-second limits.',
    'Conditional OS operations, blocking raw-file reads and allocation/diagnostic failures cannot be guaranteed to return within the cooperative bounds from Source alone. Mandatory missing/UNAVAILABLE diagnostic or custody evidence blocks negative continuation. Total diagnostic failure may leave no complete receipt; no universal provenance guarantee is claimed.',
    'Helper memory is Darwin worker lifetime highwater only with no Native process. No full production worker+Native fit, phase allocation attribution, performance/RAM/causal speedup, target proof, GCTS conformance, RL/learning advantage or mathematical soundness claim follows.',
    'Earlier Source-review unexecuted wording belongs to its historical prelaunch state. Closed V2/V3 observations remain as separately saved history: V2 candidate common registration defect and six NOT_RUN; V3 two finite generic positives, one whole-reference deadline/cleanup-negative and five NOT_RUN. No full candidate bank qualification or old failure rescue is inherited. Root retired all old grants from further use; files remain immutable.'
]
negative_gate=dict(
    authority='Root derives a negative lifecycle outcome by joining current saved runner, consumed plan, actual and external observer records. Existing observer terminal_gate_passed remains positive-only; false does not itself establish a closed negative.',
    required=[
        'First original primary resource/work/quota failure remains negative; exact subject, consumed max-one launch and owned PID/PGID must join. A code, integrity, identity or protocol fault aborts dependent subjects.',
        'Real owned-child wait4 must supply reaped status, exit and usage/highwater; no cached observation, ECHILD, permission error or later OS absence can manufacture these.',
        'Final verified owned-group absence, no observed reappearance/ownership contradiction and timely cleanup completion. Permission-denied/UNKNOWN/PRESENT is not absence. No unverified signal, PID fallback or privilege escalation.',
        'Both genuine parent-close observations and complete stable whole log descriptors after wait4/group absence, within original per-log budgets; parent close alone is insufficient.',
        'cleanup.diagnostics_incomplete must be false; mandatory primary/error summaries cannot be UNAVAILABLE or missing. All required operation/custody observations must be complete, with tagged handled errors retained.',
        'post_child_raw_custody checked and complete before the same210 endpoint for interpreter, all selected Sources, declarations/closure, stdlib and every full original input. No negative prefix or later observation substitutes.',
        'Complete truthful final physical ledger including original9MiB reserve and original cap result, stable writer quiescence, complete bounded emitted receipt and exact plan/receipt/observer joins. No over-cap resource admission or silent cap change.',
        'External terminal and mandatory log/raw/ledger/receipt completion before original210. closed_ns is explicitly only the earlier wait4/parent-close snapshot, not a full-finalization timestamp.'
    ],
    continuation='Only a genuinely closed ordinary resource-negative or fully handled temporary cleanup error with every mandatory gate and no common defect permits the next distinct predeclared fresh separately authorized subject. Missing/unknown closure or diagnostic evidence means NOT_RUN_COMMON_PROTOCOL_ABORT for remaining subjects and retired grants. No retry/rescue or automatic launch.',
    declaration_contract=d['cleanup_stop_continue'],contract=a['contract'])

components=dict(common,schema='direct-projection-qualification-components-Source-review-v1',
    source_review_passed=True,author_identity='/root',
    author_identities=['/root','/root/conventional_library','/root/benchmark_design'],
    subjects=old['subjects'],harness_declaration=a['harness_declaration'],
    runtime_closure=a['runtime_closure'],declaration=a['declaration'],
    ancestry=ancestry,authorship_disclosure=authorship,limits=limits,
    unchanged_Source_count=6,unused_target_compile_count=8,
    scope='Exact current reference/candidate Arena+adapter, harnessV3 and workerV6, complete fixture declaration, unchanged core semantics with genuine prior Source review; new runner is separately reviewed by outer_Source.',
    conclusions=[
        'All six component Sources and the full B fixture declaration are byte-identical to the genuine V3b reviewed tuple. Candidate strict builtin/tuple-to-array projection, full typed equality and full second occurrence read, precommit BODY bound and legacy strict API remain unchanged. Bounded existing fragment serialization remains; only the separate full normalization carrier is removed.',
        'Complete23 ordered cases/six groups,9 generic outputs,21 Stores plus candidate3 separate Arenas/reference0 and exact3 reference API-NAs remain. Eighteen foreign phase cases and unread-tail predicates retain their reviewed finite scope. The declared work-limit probe uses inherited strict capture and does not cover every possible new-API stop site.',
        'All three whole original banks and eight immutable preimages remain, including full59,695,933-byte Model carrier and all six BankB labels. No sampling, failed-prefix recovery or solver/data execution is introduced. Full output byte comparison plus externaloneLF is still required during a future granted helper.',
        'One early append-only Root-owned lifetime aggregate retains every previous value identity/order/duplicate through final custody; registration1 is distinct from76/526 generic entries and7/13 bank entries, not a claim of fewer retained objects. Unique instance aggregate work includes failed registered attempts and remains400m each.',
        'Detached failure-prefix/lower-bound/unavailable constructor accounting and exact foreign-primary preservation remain reviewed, best effort and non-authoritative. New cleanup-only runner does not change these components or grant any mathematical/fullcold authority.'
    ],limitations=limitations)
component_pin=save('typed-components-Source-review-v1.json',components)

outer_subjects=[cl['arms']['reference'][k]for k in('runner','observer')]
outer=dict(common,schema='direct-projection-qualification-outer-Source-review-v1',
    source_review_passed=True,author_identity='/root',author_identities=['/root'],
    subjects=outer_subjects,ancestry=ancestry,authorship_disclosure=authorship,
    limits=limits,scope='Current v7 cleanup runner and unchanged dynamic-pin observer1, exact new declaration/closure coupling. Source-only conditional lifecycle review; no run or cleanup-qualification authority.',
    runner_interim_check_count=v7['check_count'],runner_interim_unused_compile_count=v7['unused_compile_count'],
    runner_interim_inert_fullfile_patch_directions=v7['inert_fullfile_patch_directions'],
    cleanup_stop_continue=negative_gate,
    conclusions=[
        'Original14-field plan/13-field subject, all intake and strict positive full-case/byte/cost/resource validators, one create-only consumed marker before one worker Popen, original numeric profiles and exact three role receipt schemas remain. Current Source checks passed for both arms and all current false subjects.',
        'V5 six defects and V6 diagnostic residuals are preserved as negative ancestors and corrected in the separately reviewed immutable v7. Independent bounded wait4/probe/signal/close steps retain first primary failure, actual wait4-only usage, UNKNOWN permissions, fresh verified signal ownership, TERM-before-KILL grace and irreversible absence/reappearance veto.',
        'Event32/poll2048 bounds and fixed-domain error summaries are bounded; collection failure or UNAVAILABLE permanently latches incomplete. Log full hashes require actual reaped child plus absent/no-reappearance group; otherwise only explicit provisional stat is retained. Genuine parent-close and stable child-writer custody remain separate.',
        'Negative paths independently observe full raw Source/input closure and physical ledger before210. Later errors stay nonpositive; receipt create-only emission is attempted once, with no masking retry. closed_ns scope is early, and only external terminal plus full saved joins can establish final negative closure.',
        'Unchanged observer takes the current runner descriptor from the exact plan, so no old runner hardcoded pin remains. Its ROOT_resource_accepted default remains false and its terminal gate remains positive-only; Root negative custody adoption requires the separately stated full gate matrix.'
    ],limitations=limitations)
outer_pin=save('typed-outer-Source-review-v1.json',outer)

prospective=dict(common,schema='direct-projection-qualification-prospective-plan-review-v1',
    prospective_review_passed=True,author_identity='/root',author_identities=['/root','/root/benchmark_design'],
    subjects=a['subjects'],declaration=a['declaration'],runtime_closure=a['runtime_closure'],
    manifest=a['manifest'],harness_declaration=a['harness_declaration'],
    current_components_Source=component_pin,current_outer_Source=outer_pin,
    ancestry=ancestry,authorship_disclosure=authorship,limits=limits,
    all_original_input_preimages=m['full_original_inputs'],original_input_count=8,
    original_input_total_bytes=130648177,actuals_proposed=8,actuals_launched_by_review=0,
    false_authorization_scope='Each exact seven-field false authorization has actual_execution_authorized:false, dormant maximum_actual_invocations:1 and empty roles. It cannot pass the current true-grant intake; no max0 claim is made.',
    cleanup_stop_continue=negative_gate,
    conclusions=[
        'Every full canonical13-field subject is literal-equal to its14-field false plan minus only authorization and matches the offered exact SHA. All selected six Source maps, Python, Root declaration, runtime closure, limits, whole inputs and IDs join independently for all eight rows.',
        'Serial order remains generic reference/candidate, full BankA fixed reference/candidate, full BankA symbolic reference/candidate, full BankB original006 reference/candidate. Generic extras are prospectively reference-N/A, so no generic timing rank is authorized.',
        'All eight actual paths, consumed markers, false observer paths and future true authorization/authorized-plan/observer paths were absent at this audit. Freshness is point-in-time only; Root must separately create exact grants and obtain a later auth-only delta/freshness review before launch.',
        'Root declaration, closure and manifest carry the same exact cleanup contract. A fully closed resource-negative may permit the next distinct authorized subject only after full same-window custody; no previous or current negative is rescued, and common protocol defects stop dependent rows.',
        'All original worker/harness/observer/arenas/adapters/input bytes and operation/global/log/metadata limits remain. New subject identity is cleanup-isolation-v1, never a consumed V2/V3 subject retry. Both retired histories and the v5/v6 Source negatives remain exact preserved records.'
    ],limitations=limitations,
    reviewer_audit_correction=dict(
        preserved_script=descriptor(C/'review_cleanup_false_bundle_v1.py'),
        corrected_script=descriptor(C/'review_cleanup_false_bundle_v2.py'),
        reason='Reviewer v1 audit assumed the design contract had a source_only boolean. It instead has explicit SOURCE_ONLY_DESIGN_UNIMPLEMENTED_UNEXECUTED status. The v1 audit stopped before writing a receipt. V2 checks this literal status separately and checks actual_source_only flags of the four current metadata packets. No subject Source/data changed or executed.'))
plan_pin=save('typed-prospective-plan-review-v1.json',prospective)
handoff=save('cleanup-isolation-review-handoff-v1.json',dict(
    schema='cleanup-isolation-three-scope-review-handoff-v1',reviewer_identity=common['reviewer_identity'],
    source_only=True,scientific_calls=0,component_imports=0,component_calls=0,process_probes=0,
    actual_execution_authorized=False,scientific_acceptance=False,full_pipeline_qualified=False,
    components_Source=component_pin,outer_Source=outer_pin,prospective_plans=plan_pin,
    audit=audit_pin,check_count=423,mismatch_count=0,subject_sha256s=[s['subject_sha256']for s in a['subjects']],
    limits=limits,tools_stopped_after_handoff=True,
    next_step='Root may read/adopt these limited Source/prospective scopes. No actual authorized; separate exact true-grant delta/freshness review required. All tools stop after this handoff.'))
print(json.dumps(dict(components=component_pin,outer=outer_pin,prospective=plan_pin,handoff=handoff),indent=2))
