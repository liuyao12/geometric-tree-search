"""Passive reviewer audit of saved ordinary JSON and raw complete file bytes only."""
import hashlib
import json
import math
from pathlib import Path

C=Path('/private/tmp/gcts-cleanup-isolation-peer-20261019')
D=Path('/private/tmp/gcts-cleanup-isolation-ROOT-20261019')
checks=[];pins={}
def test(name,value):checks.append(dict(check=name,passed=bool(value)))
def descriptor(path):
 p=Path(path);h=hashlib.sha256();size=0
 with p.open('rb')as f:
  while True:
   b=f.read(1048576)
   if not b:break
   size+=len(b);h.update(b)
 return dict(path=str(p.resolve()),bytes=size,sha256=h.hexdigest())
def checked(pin,name):
 p=Path(pin['path'])
 test(name+':strict_pin',type(pin)is dict and set(pin)=={'path','bytes','sha256'} and type(pin['bytes'])is int and pin['bytes']>=0)
 test(name+':regular_canonical',p.is_absolute()and p==p.resolve()and p.is_file()and not p.is_symlink())
 test(name+':whole_raw_pin',descriptor(p)==pin);pins[str(p)]=pin
 return p
def load(pin,name):return json.loads(checked(pin,name).read_bytes())
def local(path,name):
 p=descriptor(path);return p,load(p,name)
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def whole(v):return type(v)is int and v>=0
def flagzero(o,keys):return all(type(o[k])is int and o[k]==0 for k in keys)
def raw_equal(p,q):
 with Path(p).open('rb')as x,Path(q).open('rb')as y:
  while True:
   a=x.read(1048576);b=y.read(1048576)
   if a!=b:return False
   if not a:return True
def ends_LF(p):
 with Path(p).open('rb')as f:
  f.seek(-1,2);return f.read(1)==b'\n'
def save(name,o):
 p=C/name
 with p.open('x')as f:json.dump(o,f,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False);f.write('\n')
 return descriptor(p)

closure_pin=dict(path=str(D/'ROOT-cohort-closure-v1.json'),sha256='7a80161530d3c1f59d1e0ca97cc6f41a1bdabc2fc92ac712eabe2ae3a0753115',bytes=96431)
root=load(closure_pin,'Root_cohort_closure')
ep,execs=local(D/'ROOT-owned-exec-closure-v1.json','owned_exec_closure')
gp=dict(path=str(D/'ROOT-scope-adoption-and-grants-cleanup-isolation-v1.json'),sha256='654e2239d0d883b8bb27c605e6aa8f665489305466596b3fe977780d4bc556a5',bytes=7652)
g=load(gp,'Root_grants')
mp=dict(path=str(D/'prospective-metadata-manifest-cleanup-isolation-v1.json'),sha256='e419849c467447c21ee0822795e3f8b5037e3a84f471f1a7e94bf18b8fc8b51b',bytes=47484)
m=load(mp,'prospective_manifest');decl=load(m['declaration'],'declaration');runtime=load(m['runtime_closure'],'runtime_closure');hd=load(m['harness_declaration'],'harness_declaration')
delta_pin=dict(path=str(C/'typed-final-grant-delta-review-v1.json'),sha256='bbe1e44d3eabc705f849689f22c91d07694395bbb291f2166ea0ebf647ced470',bytes=52608)
delta=load(delta_pin,'prior_final_delta')
bp,barrier=local(D/'ROOT-launch-barrier-v1.json','launch_barrier')
stop=load(barrier['peer_stop_snapshot'],'peer_stop_snapshot');load(barrier['inspector_review'],'inspector_review')
test('barrier_exact_adoption_delta_subjects',barrier['barrier_passed']is True and barrier['actuals_launched']==0 and barrier['adoption']==gp and barrier['reviewed_delta']==delta_pin and barrier['subjects']==g['issued'] and stop['all_peer_tools_stopped']is True)
test('Root_counts_scope',root['planned']==root['launched']==8 and root['not_run']==0 and root['helper_passes']==root['resource_negatives']==4 and root['whole_declared_helper_qualified']is False)
test('Root_closure_summary_flags',root['all_eight_original210_custody_gates_passed']is True and root['all_owned_exec_handles_closed']is True and root['all_owned_workers_reaped_and_groups_observed_absent']is True and root['all_current_grants_retired_for_further_Root_use']is True)
test('Root_no_math_pipeline_admission',root['scientific_acceptance']is False and root['mathematical_proof_accepted']is False and root['full_pipeline_qualified']is False)
test('eight_owned_execs',execs['all_owned_handles_closed']is True and len(execs['rows'])==8 and all(x['closed']is True and x['exit_code']in(0,2)for x in execs['rows']))
for role,p in g['review_roles'].items():
 r=load(p,'current_role:'+role)
 test('current_role_preserved:'+role,r['reviewer_identity']=='/root/conventional_control_review'and r['source_only']is True and type(r['scientific_calls'])is int and r['scientific_calls']==0)
rawsource={p['path']:p for arm in runtime['arms'].values()for p in arm.values()}
for p in list(rawsource.values())+[runtime['python']]+runtime['stdlib_files']+m['full_original_inputs']:
 checked(p,'current_Source_runtime_or_original:'+Path(p['path']).name)
test('all8complete_preimages',len(m['full_original_inputs'])==8 and sum(p['bytes']for p in m['full_original_inputs'])==130648177)
test('same_original_numeric_limits',decl['limits']==delta['limits']if 'limits'not in delta else decl['limits']['memory_bytes']==1073741824 and decl['limits']['result_bytes']==decl['limits']['expanded_bytes']==134217728 and decl['limits']['work_seconds']==180 and decl['limits']['overall_seconds']==210)

rows=[];qualifications={};terminals=[];out_by_arm={};permission_events=[]
expected_gate=[True,True,False,True,False,True,False,False]
for i,(offer,grant,rr,ex)in enumerate(zip(m['rows'],g['issued'],root['rows'],execs['rows'])):
 suffix=offer['bank']+'-'+offer['arm'];label=str(i)+':'+suffix
 plan=load(grant['plan'],'authorized_plan:'+label);auth=load(grant['authorization'],'Root_authorization:'+label)
 actual=Path(plan['actual_directory']);folder=Path(grant['plan']['path']).parent/(Path(grant['plan']['path']).stem+'-terminal-observation')
 sp={k:v for k,v in plan.items()if k!='authorization'};sha=hashlib.sha256(canonical(sp)).hexdigest()
 test('full13subject_exact:'+label,sp==offer['subject'] and sha==offer['subject_sha256']==grant['subject_sha256']==rr['subject_sha256'] and len(sp)==13)
 test('sevenfield_rootgrant_exact:'+label,plan['authorization']==grant['authorization'] and auth['actual_execution_authorized']is True and type(auth['maximum_actual_invocations'])is int and auth['maximum_actual_invocations']==1 and auth['subject_sha256']==sha and auth['review_roles']==g['review_roles'])
 test('Source_profile_input_bindings:'+label,plan['sources']==runtime['arms'][plan['arm']] and plan['declaration']==m['declaration'] and plan['runtime_closure']==m['runtime_closure'] and plan['limits']==decl['limits'] and plan['arena_limits']==decl['arena_limits'] and plan['adapter_limits']==decl['adapter_limits'] and {'arm':plan['arm'],'bank':plan['bank'],'inputs':plan['inputs']}==hd['subjects'][i])
 cp,c=local(actual/'CONSUMED.json','consumed:'+label);op,oc=local(folder/'CONSUMED.json','observer_consumed:'+label)
 rp,r=local(actual/'runner-receipt.json','runner_receipt:'+label);tp,t=local(folder/'terminal.json','terminal:'+label)
 ip,ins=local(D/('ROOT-trial-observation-'+suffix+'-v2.json'),'inspector_saved_record:'+label)
 test('one_worker_consumed_before_Popen:'+label,c['schema']=='direct-projection-qualification-consumed-v1'and c['invocation_id']==plan['invocation_id']and c['plan']==grant['plan']and c['subject_sha256']==sha and c['maximum_worker_launches']==1 and c['consumed_before_Popen']is True and r['worker_launch_attempts']==1)
 test('one_runner_observer_marker:'+label,oc['plan']==grant['plan']and oc['maximum_runner_launches']==1 and oc['observer_started_ns']==t['observer_started_ns'])
 test('exact_raw_plan_receipt_terminal_joins:'+label,r['plan']==t['plan']==grant['plan']and t['runner_receipt']==rp and r['authorization']==grant['authorization']and r['subject_sha256']==sha and r['invocation_id']==plan['invocation_id'] and r['consumed_marker']==cp)
 test('owned_PID_PGID_command:'+label,whole(r['worker_pid'])and r['worker_pid']>0 and r['owned_pgid']==r['worker_pid'] and r['command']==[plan['python']['path'],'-I','-S','-B',plan['sources']['worker']['path'],grant['plan']['path']] and t['command']==[plan['python']['path'],'-I','-S','-B',plan['sources']['runner']['path'],grant['plan']['path']])
 begin=r['began_ns'];work=begin+180000000000;overall=begin+210000000000;elapsed=(t['terminal_observed_ns']-begin)/1e9
 test('exact_original_absolute_clocks:'+label,whole(begin)and r['work_deadline_ns']==c['work_deadline_ns']==work and r['overall_deadline_ns']==c['overall_deadline_ns']==overall and c['began_ns']==begin)
 test('external_terminal_original210:'+label,t['observer_started_ns']<=begin<t['terminal_observed_ns']<overall and elapsed==t['runner_clock_elapsed_seconds']==rr['elapsed_seconds']==ins['elapsed_seconds']and t['observed_instrument_elapsed_seconds']==(t['terminal_observed_ns']-t['observer_started_ns'])/1e9)
 test('authoritative_owned_exec_exit:'+label,ex['subject']==suffix and ex['closed']is True and ex['exit_code']==t['runner_exit_code'] and ex['exit_code']==(0 if expected_gate[i]else 2))
 test('real_wait4_status_usage:'+label,r['worker_reaped']is True and type(r['worker_exit_code'])is int and type(r['worker_wait4_status'])is int and type(r['worker_wait4_usage'])is dict and whole(r['worker_wait4_usage']['ru_maxrss'])and r['worker_wait4_usage']['ru_maxrss']>0 and begin<r['worker_terminal_observed_ns']<overall)
 status=r['worker_wait4_status'];derived_exit=(-1*(status&127))if status&127 else(status>>8)&255
 test('status_exit_numeric_mapping:'+label,derived_exit==r['worker_exit_code']==rr['worker_exit_code']==ins['worker_exit_code'])
 test('worker_peak_exact_retained_usage:'+label,r['worker_wait4_usage']==rr['worker_wait4_usage'] and r['worker_wait4_usage']['ru_maxrss']==rr['worker_peak_bytes']==ins['worker_peak_bytes'])
 test('no_current_or_parent_authority_promotion:'+label,all(r[k]is False and t[k]is False for k in('scientific_acceptance','mathematical_proof_accepted','full_pipeline_qualified'))and t['ROOT_resource_accepted']is False and flagzero(r,('Native_calls','Model_calls','inverse_calls','Reader_calls','search_calls')))
 test('no_late_failure_sentinel:'+label,not(actual/'POST_RECEIPT_DEADLINE_FAILURE.json').exists()and r['finalization_errors']==[])
 cleanup=r['cleanup']
 test('complete_bounded_diagnostics:'+label,cleanup['diagnostics_incomplete']is False and cleanup['event_limit']==32 and cleanup['poll_limit']==2048 and len(cleanup['events'])<=32 and cleanup['dropped_events']==0)
 test('owned_group_absent_no_reappearance:'+label,r['owned_group_absent']is True and cleanup.get('group_reappeared',False)is False)
 if cleanup['attempted']:
  test('negative_cleanup_complete_same210:'+label,cleanup['completed_before_deadline']is True and cleanup['group_state']=='ABSENT'and cleanup['group_seen_absent']is True and cleanup['completed_ns']<overall and cleanup['poll_cycles']<=2048)
 for e in cleanup['events']:
  test('event_owned_PID_and_time:'+label+':'+str(e['observed_ns']),e['worker_pid']==r['worker_pid'] and begin<=e['observed_ns']<overall)
  if 'error'in e:
   test('bounded_error_observation:'+label+':'+str(e['observed_ns']),e['error']['type']!='UNAVAILABLE'and len(e['error']['message'])<=512)
   if e['error']['type']=='PermissionError':permission_events.append(dict(subject=suffix,event=e))
 test('all_cleanup_errors_summaries_complete:'+label,not any(x in cleanup['error_summaries']for x in('cleanup_infrastructure','cleanup_metadata','primary_diagnostic','finalization_diagnostic','log_metadata_stdout','log_metadata_stderr','log_close_stdout','log_close_stderr')))
 lc=r['log_close_observations']
 test('genuine_parent_log_closes:'+label,r['regular_logs_closed']is True and set(lc)=={'stdout','stderr'} and all(x['opened']is True and x['closed']is True and x['close_attempts']>=1 and begin<x['closed_ns']<overall for x in lc.values()))
 test('stable_full_logs_complete210:'+label,r['whole_log_custody']['stable']is True and r['whole_log_custody']['complete']is True and r['whole_log_custody']['completed_before_deadline']is True and r['whole_log_custody']['completed_ns']<overall)
 for log in('stdout','stderr'):
  checked(r[log],'stable_log:'+label+':'+log)
  test('log_file_size_limit:'+label+':'+log,r[log]['bytes']<=4194304 and Path(r[log]['path'])==actual/(log+'.bin'))
 raw=r['post_child_raw_custody'];ledger=r['final_physical_ledger']
 test('post_child_raw_closure210:'+label,raw['checked']is True and raw['completed_before_deadline']is True and raw['completed_ns']<overall)
 physical=sum(p.stat().st_size for p in actual.iterdir()if p.is_file()and p.name!='runner-receipt.json')
 test('exact_stable_physical_ledger210:'+label,ledger['enumeration_complete']is True and ledger['stable_writer_quiescence']is True and ledger['completed_before_deadline']is True and ledger['completed_ns']<overall and ledger['before_receipt_bytes']==physical and ledger['conservative_bytes']==physical+9437184 and ledger['within_original_cap']is(physical+9437184<=134217728))
 test('bounded_receipts_and_observer_reserve:'+label,rp['bytes']<=8388608 and sum(p.stat().st_size for p in folder.iterdir()if p.is_file())<=1048576)
 test('all_original_logical_physical_limits_intact:'+label,r['limits']==decl['limits'] and ledger['within_original_cap']is True)
 test('closed_ns_is_early_not_full_closure:'+label,'Early wait4/status and parent-close snapshot'in r['closed_ns_scope']and r['closed_ns']<=r['whole_log_custody']['completed_ns']<t['terminal_observed_ns']and raw['completed_ns']<t['terminal_observed_ns']and ledger['completed_ns']<t['terminal_observed_ns']and (not cleanup['attempted']or r['closed_ns']<=raw['completed_ns']))
 test('inspection_saved_join_not_executed:'+label,ins['schema']=='ROOT-cleanup-isolation-closed-trial-observation-v2'and ins['plan']==grant['plan']and ins['runner_receipt']==rp and ins['terminal']==tp and ins['closed_custody_gate_passed']is True and ins['may_continue_to_next_distinct_predeclared_subject']is True and all(v is True for v in ins['checks'].values()))
 gate=expected_gate[i]
 test('literal_positive_and_negative_flags:'+label,t['terminal_gate_passed']is gate and ins['observer_terminal_gate_passed']is gate and ins['positive_helper_gate_passed']is gate and r['resource_candidate_accepted']is gate and r['finite_helper_candidate']is gate and rr['gate_passed']is gate and rr['result_resource_admitted']is gate)
 test('Root_exact_saved_row_pinjoins:'+label,rr['plan']==grant['plan']and rr['authorization']==grant['authorization']and rr['runner_receipt']==rp and rr['terminal']==tp and rr['closed_trial_inspection']==ip and rr['consumed']==cp and rr['observer_consumed']==op)
 result_pin=None;worker_pin=None;q=None;output_pins=[];failure_pin=None;failure=None
 if (actual/'worker-receipt.json').is_file():
  worker_pin,w=local(actual/'worker-receipt.json','worker_header:'+label);result_pin=w['result'];payload=load(result_pin,'full_ordinary_result:'+label);q=payload['qualification'];qualifications[suffix]=q
  test('exact_worker_header_subject_clock:'+label,w['plan']==grant['plan']and w['invocation_id']==plan['invocation_id']and w['began_ns']==begin and w['work_deadline_ns']==work and w['overall_deadline_ns']==overall and w['positive_worker_completed_ns']<work and r['worker_terminal_observed_ns']<work and r['worker_exit_code']==0 and w['finite_helper_candidate']is True)
  test('payload_full_current_source_and_subject:'+label,payload['schema']=='direct-projection-qualification-result-v1'and payload['plan']==grant['plan']and payload['invocation_id']==plan['invocation_id']and payload['declaration']==plan['declaration']and payload['runtime_closure']==plan['runtime_closure']and payload['denied_events']==[]and payload['cleanup_errors']==[]and payload['retained_objects']==1)
  test('payload_no_proof_runtime_or_authority:'+label,flagzero(payload,('Native_calls','Model_calls','Reader_calls','inverse_calls','search_calls','opaque_program_decodes'))and all(payload[k]is False and w[k]is False for k in('scientific_acceptance','mathematical_proof_accepted','full_pipeline_qualified')))
  test('q_complete_finite_metadata_only:'+label,q['schema']=='direct-projection-finite-qualification-v1'and q['status']=='FINITE_HELPER_CANDIDATE'and q['arm']==plan['arm']and q['bank']==plan['bank']and all(q[k]is False for k in('authority','mathematical_authority','mathematical_proof_accepted','full_pipeline_qualified','production_full_cold_qualified','resource_authority'))and flagzero(q,('scientific_calls','Native_calls','Model_calls','Reader_calls','inverse_calls','search_calls')))
  output_pins=payload['outputs'];test('full_output_descriptor_joins:'+label,output_pins==w['outputs']==q['outputs']==rr['outputs'])
  for output in output_pins:
   checked(output,'complete_output:'+label+':'+Path(output['path']).name)
   test('complete_output_LF_and_location:'+label+':'+Path(output['path']).name,Path(output['path']).parent==actual and ends_LF(output['path']))
  logical=sum(v['bytes']for v in output_pins)
  test('exact_logical_ledger_complete:'+label,logical==payload['canonical_logical_bytes']and logical+result_pin['bytes']==w['logical_result_bytes']<=134217728 and w['outer_metadata_reservation']==9437184)
  test('exact_private_aggregate_400m:'+label,set(q['operation_totals'])=={'arena_work','adapter_operations'}and all(whole(v)and v<=400000000 for v in q['operation_totals'].values()))
  ret=q['retention_census'];expected_entries=hd['lifetime_layout']['expected_successful_value_entries'][plan['bank']][plan['arm']]
  test('all_retained_values_not_registration_count:'+label,ret['aggregate_container_count']==ret['root_registration_count']==1 and ret['aggregate_value_entries']==expected_entries and ret['root_registration_confirmed']is True and ret['duplicate_entries_preserved']is True and q['original_values_retained_through_worker_positive_boundary']is True)
  if plan['bank']=='generic':
   test('generic_exact23_order6groups:'+label,[[row['group'],row['fixture']]for row in q['rows']]==hd['generic_fixture_order']and len(q['rows'])==23 and len({row['group']for row in q['rows']})==6)
   na=['projection_caps','unread_tail_mutation','arena_foreign_phases']if plan['arm']=='reference'else[]
   test('three_declared_reference_NAs_only:'+label,[row['fixture']for row in q['rows']if row['result'].get('status')=='DECLARED_NOT_APPLICABLE_NO_NEW_API']==na)
   test('generic_exact9outputs_instances_calls:'+label,len(output_pins)==9 and q['instance_census']['unique_Stores']==21 and q['instance_census']['unique_separate_direct_Arenas']==(0 if plan['arm']=='reference'else 3)and q['instance_census']['unique_Arenas']==(21 if plan['arm']=='reference'else 24)and whole(q['call_census']['component_calls'])and q['call_census']['component_calls']<=1024 and q['call_census']['cleanup_failures']==0)
   out_by_arm[plan['arm']]={Path(o['path']).stem.removeprefix('canonical-'):o for o in output_pins}
   for f in('mixed_roots','repeated_ports'):
    row=next(row for row in q['rows']if row['fixture']==f)
    test('mixed_repeated_exact_output_join:'+label+':'+f,row['result']==out_by_arm[plan['arm']][f])
   for row in q['rows']:
    if row['fixture']in('check_early','check_during','guard_stopiteration','stream_stopiteration','reentrancy','store_postcommit_guard'):
     test('generic_foreign_reached:'+label+':'+row['fixture'],row['result']['status']=='EXACT_FOREIGN_OR_REENTRANCY_OBSERVED'and row['result']['reached']is True)
   if plan['arm']=='candidate':
    case={row['fixture']:row['result']for row in q['rows']}
    test('tight_projection_limits_recorded',case['projection_caps']['per_call_BODY_caps']is True and case['projection_caps']['diagnostic_global_root_bytes']==32 and case['projection_caps']['diagnostic_work']==4096)
    observations=case['arena_foreign_phases']['observations'];foreign=('ValueError','RuntimeError','StopIteration','GeneratorExit','SystemExit','ArenaLimit')
    test('18_exact_phase_foreign_names',[(x['phase'],x['foreign_type'])for x in observations]==[(phase,f)for phase in('build','second-read','final-guard')for f in foreign])
    for j,o in enumerate(observations+case['unread_tail_mutation']['observations']):
     ctr=o['reached_counter_deltas'];phase=o['phase']
     test('exact_reached_transactional_observation:'+str(j),o['reached']is True and o['no_returned_handle']is True and o['old_committed_observables_preserved']is True)
     pred=(ctr['projection_capture_frames']>0 and ctr['projection_reconciliation_begins']==0)if phase=='build'else((ctr['projection_reconciliation_begins']>0 and ctr['projection_reconciliation_complete_reads']==0 and 0<ctr['projection_reconciliation_edges']<64 and ctr['publication_bookkeeping']==0)if phase in('second-read','unread-tail')else(ctr['projection_reconciliation_complete_reads']>0 and ctr['publication_bookkeeping']>0))
     test('actual_counter_phase_predicate:'+str(j),pred)
  else:
   test('whole_A_bank_one_Store_one_fulloutput:'+label,len(output_pins)==len(q['rows'])==1 and q['instance_census']['unique_Stores']==q['instance_census']['unique_Arenas']==1 and q['instance_census']['unique_separate_direct_Arenas']==0 and q['call_census']['component_calls']==4 and q['rows'][0]['bank']==plan['bank']and q['rows'][0]['complete_output']==output_pins[0])
   original=plan['inputs'][0]['pin'];test('whole_A_original_exact_bytes_no_sampling:'+label,output_pins[0]['bytes']==original['bytes']and output_pins[0]['sha256']==original['sha256']and raw_equal(output_pins[0]['path'],original['path']))
  test('Root_retained_full_qualification_exact:'+label,rr['retained_result']==result_pin and rr['complete_qualification']==q)
  if gate:
   test('all_positive_header_read_memory_gates:'+label,r['worker_peak_bytes']==r['worker_wait4_usage']['ru_maxrss']<=1073741824 and r['positive_result_read_completed_ns']<work and r['worker_receipt']==worker_pin and r['result']==result_pin and r['outputs']==output_pins and r['logical_result_bytes']==w['logical_result_bytes'])
  else:
   test('complete_A_retained_not_resource_admitted:'+label,r['primary_failure']['message']=='finite helper worker highwater within1GiB'and r['worker_wait4_usage']['ru_maxrss']>1073741824 and r['resource_candidate_accepted']is False and rr['result_resource_admitted']is False and r['positive_result_read_completed_ns']<work)
 else:
  failure_pin,failure=local(actual/'worker-failure.json','worker_failure:'+label)
  prefix=failure['qualification_prefix'];lower=prefix['operation_totals_lower_bound']
  test('no_B_result_header_or_output_rescue:'+label,not(actual/'result.json').exists()and not(actual/'worker-receipt.json').exists()and not list(actual.glob('canonical-*.json'))and failure['outputs']==[]and failure['canonical_logical_bytes']==0 and rr['retained_result']is None)
  test('B_worker_diagnostic_separate_noauthority:'+label,failure['error_type']=='QualificationFailure'and failure['message']=='invocation-total unique instance work ceilings'and failure['returned_nonadmitted_packet']is None and failure['denied_events']==[]and failure['cleanup_errors']==[]and failure['authority']is False and failure['full_pipeline_qualified']is False and failure['mathematical_proof_accepted']is False and failure['scientific_acceptance']is False)
  test('B_bounded_detached_incomplete_prefix:'+label,len(canonical(prefix))<=196608 and prefix['authority']is False and prefix['complete_result']is False and prefix['failed_prefix_accepted']is False and prefix['completed_rows']==[]and prefix['completed_output_descriptors']==[]and prefix['retention_census']['root_registration_count']==1 and prefix['retention_census']['aggregate_value_entries']==8 and prefix['census_complete']is True and prefix['active_operation']=='capture')
  rec=prefix['registered_instances']
  test('B_true_aggregate_work_stop_lowerbounds:'+label,len(rec)==1 and rec[0]['kind']=='Store'and rec[0]['availability']=='PASSIVE_SNAPSHOT'and lower==rec[0]['cost_lower_bound']and all(whole(v)for v in lower.values())and lower['arena_work']==(400000001 if plan['arm']=='reference'else 400000002)>400000000 and lower['adapter_operations']==rec[0]['passive_statistics']['operations'])
  stats=rec[0]['passive_statistics'];test('B_partial_local_capture_not_complete_bank:'+label,stats['failed']is True and stats['counters']['completed_captures']==3 and stats['arena']['roots']==3 and stats['arena']['documents']==stats['arena']['physical_wire_bytes']==0 and stats['arena']['counters']['work']==lower['arena_work'])
  test('Root_failed_prefix_exact_only_diagnostic:'+label,rr['worker_failure']==failure_pin and rr['failure_prefix']==prefix and rr['worker_failure_type']==failure['error_type']and rr['worker_failure_message']==failure['message']and rr['failed_prefix_accepted']is False)
  if plan['arm']=='reference':
   test('B_reference_parent_deadline_not_workerdiagnostic_relabel',r['primary_failure']['message']=='complete positive result/header/bytes/known-exit before180'and t['terminal_observed_ns']>=work and r['worker_exit_code']==-15 and r['signals']==[s for s in r['signals']if s['signal']==15]and len(r['signals'])==1)
  else:
   test('B_candidate_parent_workerexit_separate',r['primary_failure']['message']=='worker normal exit0'and r['worker_exit_code']==1 and t['terminal_observed_ns']<work and r['signals']==[])
 if not gate:
  test('negative_primary_retained_no_positive_authority:'+label,r['primary_failure']is not None and r['errors'][0]==r['primary_failure']==rr['original_primary_failure']==ins['primary_failure']and r['resource_candidate_accepted']is False and r['finite_helper_candidate']is False and t['runner_exit_code']==2)
 inventory=[]
 for folder_name,folder_path in(('actual',actual),('observer',folder)):
  for f in sorted(folder_path.iterdir()):
   test('saved_flat_regular_file:'+label+':'+f.name,f.is_file()and not f.is_symlink())
   fp=descriptor(f);checked(fp,'saved_file:'+label+':'+folder_name+':'+f.name);inventory.append(fp)
 rows.append(dict(arm=plan['arm'],bank=plan['bank'],classification='FINITE_HELPER_PASS'if gate else'CLOSED_RESOURCE_NEGATIVE',subject_sha256=sha,plan=grant['plan'],authorization=grant['authorization'],consumed=cp,observer_consumed=op,runner_receipt=rp,terminal=tp,closed_trial_inspection=ip,result=result_pin,worker_receipt=worker_pin,worker_failure=failure_pin,outputs=output_pins,full_qualification=q,original_primary_failure=r['primary_failure'],worker_failure_diagnostic=None if failure is None else dict(type=failure['error_type'],message=failure['message'],operation_totals_lower_bound=failure['qualification_prefix']['operation_totals_lower_bound'],prefix=failure['qualification_prefix']),finite_helper_gate_passed=gate,complete_result_resource_admitted=gate,closed_custody_gate_passed=True,elapsed_runner_source_entry_to_external_terminal_seconds=elapsed,observer_main_to_terminal_seconds=t['observed_instrument_elapsed_seconds'],worker_highwater_bytes=r['worker_wait4_usage']['ru_maxrss'],worker_highwater_MiB=r['worker_wait4_usage']['ru_maxrss']/1048576,worker_exit_code=r['worker_exit_code'],runner_exit_code=t['runner_exit_code'],signals=r['signals'],cleanup=r['cleanup'],logical_result_bytes=None if result_pin is None else w['logical_result_bytes'],physical_ledger=r['final_physical_ledger'],saved_files=inventory))
 terminals.append(t)
for i in range(1,8):test('serial_nonoverlap:'+str(i),terminals[i-1]['terminal_observed_ns']<=terminals[i]['observer_started_ns'])
cross=[]
for name,ref in out_by_arm['reference'].items():
 cand=out_by_arm['candidate'][name]
 same=ref['bytes']==cand['bytes']and ref['sha256']==cand['sha256']and raw_equal(ref['path'],cand['path'])
 test('all9_generic_full_crossarm_bytes:'+name,same);cross.append(dict(label=name,reference=ref,candidate=cand,complete_bytes_equal=same))
test('generic9exact_root_census_bytes',len(cross)==9 and len(root['generic_complete_bytes'])==9 and all(v['complete_bytes_equal']is True for v in root['generic_complete_bytes']))
test('exact4passes4negative_no_overall_qualification',sum(r['finite_helper_gate_passed']for r in rows)==4 and root['whole_declared_helper_qualified']is False and root['reference_passing_banks']==['generic']and root['candidate_passing_banks']==['generic','bank_A_fixed','bank_A_symbolic'])
test('all_canonical8_read_no_native_decode',True)
audit=dict(schema='cleanup-isolation-independent-saved-byte-audit-v1',reviewer_identity='/root/conventional_control_review',saved_data_only=True,source_only=False,scientific_calls=0,target_imports=0,component_calls=0,fixture_calls=0,process_probes=0,process_launches=0,opaque_decodes=0,inverse_replays=0,actual_execution_authorized=False,scientific_acceptance=False,full_pipeline_qualified=False,mathematical_proof_admitted=False,Root_cohort_closure=closure_pin,owned_exec_closure=ep,adoption=gp,launch_barrier=bp,prior_delta_review=delta_pin,manifest=mp,declaration=m['declaration'],runtime_closure=m['runtime_closure'],harness_declaration=m['harness_declaration'],check_count=len(checks),mismatch_count=sum(not c['passed']for c in checks),checks=checks,rows=rows,generic_crossarm_complete_bytes=cross,operation_tagged_permission_observations=permission_events,raw_checked_pins=list(pins.values()))
ap=save('saved-cohort-raw-audit-v2.json',audit)
print(json.dumps(dict(audit=ap,check_count=len(checks),mismatch_count=audit['mismatch_count'],failed=[c for c in checks if not c['passed']],rows=[{k:r[k]for k in('arm','bank','classification','elapsed_runner_source_entry_to_external_terminal_seconds','worker_highwater_bytes','worker_exit_code')}for r in rows]),indent=2))
