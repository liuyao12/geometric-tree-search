"""Reviewer-owned raw-byte/AST/ordinary-metadata audit; never loads target code."""
import ast
import hashlib
import json
import os
from pathlib import Path

C=Path('/private/tmp/gcts-cleanup-isolation-peer-20261019')
D=Path('/private/tmp/gcts-cleanup-isolation-ROOT-20261019')
P=Path('/private/tmp/gcts-direct-projection-review-20261019')
B=Path('/private/tmp/gcts-direct-projection-qualification-20261019')
checks=[]
raw_pins={}
trees={}
def test(name,value,detail=None):
    checks.append(dict(check=name,passed=bool(value),**({} if detail is None else dict(detail=detail))))
def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def desc(path):
    p=Path(path);raw=p.read_bytes()
    return dict(path=str(p.resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def pin(value,label):
    test(label+':strict_descriptor',type(value)is dict and set(value)=={'path','bytes','sha256'} and
         type(value['bytes'])is int and value['bytes']>=0)
    path=Path(value['path'])
    test(label+':canonical_regular',path.is_absolute() and path==path.resolve() and path.is_file() and not path.is_symlink())
    got=desc(path);test(label+':whole_raw_pin',got==value)
    raw_pins[str(path)]=got
    return path.read_bytes()
def load(value,label):return json.loads(pin(value,label))
def known(path,sha,size,label):
    value=dict(path=str(path),sha256=sha,bytes=size);pin(value,label);return value
def read_json(path):return json.loads(Path(path).read_bytes())
def assignments(tree):
    out={}
    for n in tree.body:
        if isinstance(n,ast.Assign):
            for target in n.targets:
                if isinstance(target,ast.Name):out[target.id]=n.value
    return out
def imports(tree):
    out=set()
    for n in ast.walk(tree):
        if isinstance(n,ast.Import):out.update(x.name.split('.')[0] for x in n.names)
        elif isinstance(n,ast.ImportFrom):out.add((n.module or '').split('.')[0])
    return sorted(out)

manifest_pin=known(D/'prospective-metadata-manifest-cleanup-isolation-v1.json','e419849c467447c21ee0822795e3f8b5037e3a84f471f1a7e94bf18b8fc8b51b',47484,'manifest')
m=read_json(manifest_pin['path'])
declaration=load(m['declaration'],'declaration');closure=load(m['runtime_closure'],'runtime_closure')
hd=load(m['harness_declaration'],'harness_declaration')
entries=load(m['frozen_subject_entries'],'frozen_subject_entries')
contract_pin=declaration['cleanup_stop_continue']['contract']
contract=load(contract_pin,'lifecycle_contract')
master=load(m['declaration'],'declaration_second_read')['current_master']
pin(master,'current_master')
test('current_master_authoritative_pin',master['sha256']=='ca6ee206287bf18b69f88a35d30968312499567755f347a819af4cf49743e7d4' and master['bytes']==36240)
test('manifest_protocol_schema',m['schema']=='ROOT-direct-projection-prospective-metadata-manifest-v1')
test('declaration_protocol_schema',declaration['schema']=='ROOT-direct-projection-qualification-declaration-v1')
test('closure_protocol_schema',closure['schema']=='ROOT-direct-projection-qualification-runtime-closure-v1')
test('manifest_no_execution_or_grants',all(type(m[k])is int and m[k]==0 for k in('scientific_calls','actuals_launched','actual_directories_created','true_grants_created','old_grants_reused')) and m['actual_execution_authorized']is False and m['source_only']is True)
test('all_metadata_source_only',all(o['source_only']is True and o['actual_execution_authorized']is False and type(o['scientific_calls'])is int and o['scientific_calls']==0 for o in(m,declaration,closure,hd,contract)))
test('shared_cleanup_contract_literal',m['cleanup_stop_continue']==declaration['cleanup_stop_continue']==closure['cleanup_stop_continue'])
test('same_original_subject_denominator',entries==hd['subjects']==declaration['subjects']==contract['cohort_invariants']['subjects'] and len(entries)==8)
test('same_harness_declaration',m['harness_declaration']==declaration['harness_declaration']==contract['cohort_invariants']['harness_declaration'])
test('runtime_declaration_descriptor_join',closure['declaration']==m['declaration'])
test('cohort_current',all(o['cohort']=='cleanup-isolation-v1' for o in(m,declaration,closure)))
test('all_proof_runtime_calls_zero',all(type(closure[k])is int and closure[k]==0 for k in('scientific_calls','Native_calls','Model_calls','Reader_calls','inverse_calls','search_calls','opaque_program_decodes')))

ancestors={
 'components':known(P/'typed-components-Source-review-v3b.json','9026796a6f6ce1416da126f86a7bd030d8cc0096dd0f822922d34f5a27f54b2a',15360,'prior_components'),
 'outer':known(P/'typed-outer-Source-review-v3b.json','ef23cb5022efe6c823979e7fc3814da33bcb3efafd4257d511fdbad254f9ec73',12379,'prior_outer'),
 'prospective':known(P/'typed-prospective-plan-review-v3b.json','3851f8cecdd7d62a6910cd35e706b1926ff5564d1c1bfd2226e382f0c61d9840',56302,'prior_prospective'),
 'runner_v7':known(C/'typed-runner-v7-Source-review-v1.json','97b4088cd1fe888ecf5404385cf3881123130d62ab7cbb5137b6f84606386777',12524,'runner_v7_review'),
 'runner_v5_negative':known(C/'typed-runner-v5-Source-review-negative-v1.json','d50e23063d814754e81af7d1b403907f23e5945279e72e6d1337775c38ebff89',10179,'runner_v5_negative'),
 'runner_v6_negative':known(C/'typed-runner-v6-Source-review-negative-v1.json','301447c0d3df02a16a552b84d43ba803a744f5d60b4a868b31575fa121af49c5',9863,'runner_v6_negative'),
 'saved_V2':known(P/'typed-saved-V2-common-defect-review-v1.json','0e609cce48a1edc41edc1d889c21c6a49cd3deed497da4ce67e304520b70513f',76428,'saved_V2_negative'),
 'saved_V3':known(P/'typed-saved-qualification-review-v3.json','a16b90d049b4109699102d61a8295ba6248eb79169ff0f19fe959b065e2b075b',122654,'saved_V3_negative_bank')}
old_components=read_json(ancestors['components']['path']);old_outer=read_json(ancestors['outer']['path'])
runner_review=read_json(ancestors['runner_v7']['path'])
test('genuine_prior_components_and_v7_Source_PASS',old_components['source_review_passed']is True and runner_review['source_review_passed']is True and runner_review['mismatch_count']==0)
component_subjects=old_components['subjects']
for p in component_subjects:pin(p,'unchanged_component:'+Path(p['path']).name)
source_pins={v['path']:v for arm in closure['arms'].values() for v in arm.values()}
test('eight_unique_runtime_Sources',len(source_pins)==8)
for p in source_pins.values():
    raw=pin(p,'Source:'+Path(p['path']).name)
    tree=ast.parse(raw,filename=p['path']);trees[p['path']]=tree
    unused=compile(tree,p['path'],'exec');del unused
    test('AST_unused_compile:'+Path(p['path']).name,True)
for arm,selected in closure['arms'].items():
    test('selected_exact_six_roles:'+arm,set(selected)=={'worker','harness','adapter','arena','runner','observer'})
    test('unchanged_component_scope:'+arm,all(selected[k] in component_subjects for k in('worker','harness','adapter','arena')))
    test('current_runner_scoped_PASS:'+arm,selected['runner'] in runner_review['subjects'] if 'subjects'in runner_review else selected['runner']==runner_review.get('runner'))
    test('unchanged_observer_scope:'+arm,selected['observer'] in old_outer['subjects'])
for arm in ('reference','candidate'):
    for role in ('arena','adapter'):
        test('lifecycle_component_implementation_join:'+arm+':'+role,closure['arms'][arm][role]==contract['cohort_invariants']['arena_adapter_implementations'][arm][role])
test('harness_Source_triplicate',closure['arms']['reference']['harness']==closure['arms']['candidate']['harness']==hd['harness']==contract['cohort_invariants']['harness'])
pin(closure['python'],'python_interpreter')
for p in closure['stdlib_files']:pin(p,'stdlib:'+p['path'].split('/python3.12/')[-1])
for census in closure['direct_import_census']:
    p=census['source'];tree=trees[p['path']]
    test('AST_census:'+Path(p['path']).name,census['AST_sha256']==hashlib.sha256(ast.dump(tree,include_attributes=False).encode()).hexdigest())
    test('import_census:'+Path(p['path']).name,census['direct_imports']==imports(tree))
test('complete_eight_census_subjects',{c['source']['path']for c in closure['direct_import_census']}==set(source_pins))
test('direct_import_union',closure['direct_import_modules']==sorted({i for c in closure['direct_import_census']for i in c['direct_imports']}))
test('no_dynamic_scientific_load_edges',len(closure['explicit_dynamic_edges'])==2 and 'Arena/adapter/harness only' in closure['explicit_dynamic_edges'][0])
test('trusted_loader_scope_explicit','no hostile-code sandbox' in closure['runtime_trust'] and 'builtin/frozen/transitive' in closure['runtime_trust'])

LIMITS=dict(work_seconds=180,overall_seconds=210,memory_bytes=1073741824,result_bytes=134217728,expanded_bytes=134217728,stdout_bytes=4194304,stderr_bytes=4194304,worker_receipt_bytes=4194304,runner_metadata_bytes=8388608,observer_bytes=1048576)
ARENA=dict(cache_bytes=8388608,cache_entries=65536,chunk_bytes=65536,depth=512,documents_expanded_bytes=134217728,edges=8000000,fragment_bytes=4096,integer_digits=4096,materialized_bytes=4194304,materialized_occurrences=100000,nodes=2000000,root_expanded_bytes=134217728,roots=4096,scalar_bytes=16777216,wire_bytes=134217728,work=400000000)
ADAPTER=dict(operations=400000000,value_bytes=134217728,depth=512,chunk_bytes=65536)
test('Root_declaration_exact_limits',declaration['limits']==LIMITS and declaration['arena_limits']==ARENA and declaration['adapter_limits']==ADAPTER)
test('B_harness_exact_limits',hd['arena_limits']==ARENA and hd['adapter_limits']==ADAPTER)
for role in ('runner','worker'):
    selected=closure['arms']['reference'][role];a=assignments(trees[selected['path']])
    test('literal_ARENA_LIMITS:'+role,ast.literal_eval(a['ARENA_LIMITS'])==ARENA)
    test('literal_ADAPTER_LIMITS:'+role,ast.literal_eval(a['ADAPTER_LIMITS'])==ADAPTER)
    # LIMITS is a literal dict(...) call, inspected without invoking it.
    node=a['LIMITS'];test('literal_LIMITS:'+role,isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id=='dict' and not node.args and {v.arg:ast.literal_eval(v.value)for v in node.keywords}==LIMITS)
worker=trees[closure['arms']['reference']['worker']['path']]
runner=trees[closure['arms']['reference']['runner']['path']]
def function(tree,name):return next(n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))and n.name==name)
test('whole_positive_case_validator_worker_runner_AST',ast.dump(function(worker,'validate_qualification'),include_attributes=False)==ast.dump(function(runner,'validate_qualification'),include_attributes=False))
for role in ('worker','runner'):
    tree=worker if role=='worker'else runner;a=assignments(tree)
    expected={'schema','invocation_id','actual_directory','arm','bank','python','sources','inputs','limits','arena_limits','adapter_limits','declaration','runtime_closure','authorization'}
    test('PLAN_FIELDS_fourteen:'+role,ast.literal_eval(a['PLAN_FIELDS'].args[0]) and set(ast.literal_eval(a['PLAN_FIELDS'].args[0]))==expected)
test('generic_exact_23_six_groups',len(hd['generic_fixture_order'])==23 and len({v[0]for v in hd['generic_fixture_order']})==6)
hc=hd['finite_expected_census'];g=hc['generic_each']
test('generic_21_Stores_9outputs_18_foreign',g['fresh_Stores']==21 and g['complete_actual_outputs']==9 and g['complete_ordered_rows']==23 and g['exact_foreign_phase_subcases']==18)
test('generic_three_reference_NAs',g['reference_predeclared_new_API_NA_cases']==['projection_caps','unread_tail_mutation','arena_foreign_phases'] and g['candidate_predeclared_NA_cases']==[] and g['reference_separate_direct_Arenas']==0 and g['candidate_separate_direct_Arenas']==3)
test('lifetime_census_exact',hd['lifetime_layout']==contract['cohort_invariants']['lifetime_layout'] and hd['lifetime_layout']['Root_registration_bound_unchanged']==512 and hd['lifetime_layout']['expected_Root_registrations_per_successful_subject']==1)
test('aggregate_work_failed_costs_and_no_resets','Every failed attempt counted' in hd['work_accounting'] and 'not 24 independent invocation grants' in hd['work_accounting'])
test('whole_A_bank_census',hc['bank_A_each']==dict(complete_actual_outputs=1,fresh_Stores=1,public_component_calls=4))
test('whole_B_bank_census',hc['bank_B']['captures']==6 and hc['bank_B']['public_component_calls']==10 and hc['bank_B']['fresh_Stores']==1 and hc['bank_B']['complete_actual_outputs']==1)

schedule=[(a,b)for b in('generic','bank_A_fixed','bank_A_symbolic','bank_B_original006')for a in('reference','candidate')]
expected_shas=['aecfd619008cb066e93e133ca6e9c696dcc3be4516b23cef18d4a66ff439d366','acbacbcde23e1094e5884244b4c0752bf75d2167162982518a92abcbf1e5fad7','2c3aa6dec4982b07c0df666590473f68fe5269ff2711809c83f8fbe26ac6004f','5363a6b07496bc93945ca23d9d04c0d01a0a87a8a74bd6706458e6b93e1235d7','2165164862e8a2f85a01706fa29fde43fa876969f7ca74ce8fe21820d9525cc0','52bca7f5b83fe70c20f4407b9a0b7c9ffc88a071ad87aa1e8d9f6a8932404502','26daffe49f38ebe637d9464c33548cd2a26df44a2e96b44399bce3c2974c3b6b','b790a11fda40bd08be6dd3859559b20886c0e739974bf6bde3901d8d6e516209']
test('eight_exact_serial_rows',len(m['rows'])==8 and [(r['arm'],r['bank'])for r in m['rows']]==schedule)
all_input_pins={}
fresh_paths=[]
subjects=[]
for i,row in enumerate(m['rows']):
    label=str(i)+':'+row['bank']+':'+row['arm'];plan=load(row['plan'],'false_plan:'+label)
    subject={k:v for k,v in plan.items()if k!='authorization'};sha=hashlib.sha256(canonical(subject)).hexdigest()
    test('exact_14_plan_13_subject:'+label,len(plan)==14 and len(subject)==13 and set(plan)==expected)
    test('full_subject_literal_and_hash:'+label,subject==row['subject'] and sha==row['subject_sha256']==expected_shas[i])
    test('plan_schema:'+label,plan['schema']=='ROOT-direct-projection-qualification-plan-v1')
    test('selected_full_Source_map:'+label,plan['sources']==closure['arms'][row['arm']])
    test('all_profile_literals:'+label,plan['limits']==LIMITS and plan['arena_limits']==ARENA and plan['adapter_limits']==ADAPTER)
    test('Root_closure_declaration_python:'+label,plan['runtime_closure']==m['runtime_closure'] and plan['declaration']==m['declaration'] and plan['python']==closure['python'])
    entry=dict(arm=plan['arm'],bank=plan['bank'],inputs=plan['inputs'])
    test('full_original_subject_entry:'+label,entry==entries[i] and entry==declaration['subjects'][i] and entry==hd['subjects'][i])
    suffix=row['bank']+'-'+row['arm'];actual=D/('actual-cleanup-isolation-'+suffix+'-v1')
    test('fresh_ID_path_literal:'+label,plan['invocation_id']=='direct-projection-cleanup-isolation-'+suffix+'-ROOT-20261019-v1' and plan['actual_directory']==str(actual)==row['actual_directory'] and actual==actual.resolve() and actual.parent.is_dir())
    auth=load(plan['authorization'],'false_authorization:'+label)
    test('false_exact_seven_grant_fields:'+label,set(auth)=={'schema','author_identity','actual_execution_authorized','maximum_actual_invocations','subject_sha256','review_roles','scope'} and auth['schema']=='ROOT-direct-projection-qualification-authorization-v1' and auth['author_identity']=='/root')
    test('false_not_launchable_dormant_max_one:'+label,auth['actual_execution_authorized']is False and type(auth['maximum_actual_invocations'])is int and auth['maximum_actual_invocations']==1 and auth['review_roles']=={} and auth['subject_sha256']==sha)
    folder=Path(row['plan']['path']).parent
    for path in (actual,actual/'CONSUMED.json',folder/(Path(row['plan']['path']).stem+'-terminal-observation'),folder/('authorization-true-'+suffix+'.json'),folder/('plan-authorized-'+suffix+'.json'),folder/('plan-authorized-'+suffix+'-terminal-observation')):
        test('fresh_path_absent:'+str(path),not os.path.lexists(path));fresh_paths.append(str(path))
    for item in plan['inputs']:all_input_pins[item['pin']['path']]=item['pin']
    subjects.append(dict(subject=subject,subject_sha256=sha,false_plan=row['plan'],false_authorization=plan['authorization']))
test('unique_all_invocation_actual_subjects',len({s['subject']['invocation_id']for s in subjects})==len({s['subject']['actual_directory']for s in subjects})==len({s['subject_sha256']for s in subjects})==8)
test('all_8_whole_input_pins',len(all_input_pins)==8 and set(all_input_pins)=={v['path']for v in m['full_original_inputs']})
for p in all_input_pins.values():pin(p,'whole_input_raw_only:'+Path(p['path']).name)
test('input_total_original_bytes',sum(v['bytes']for v in all_input_pins.values())==130648177)
test('manifest_input_descriptors_exact',all(p in m['full_original_inputs']for p in all_input_pins.values()))
test('bank_B_all_six_original_labels',[v['id']for v in entries[6]['inputs']]==['compiler','initial','inventory','model','policy','spec'] and entries[6]['inputs']==entries[7]['inputs'])
test('complete_B_Model_not_projection',next(v['pin']['bytes']for v in entries[6]['inputs']if v['id']=='model')==59695933)
test('positive180_later210_unchanged',m['cleanup_stop_continue']['positive_work_boundary_seconds']==180 and m['cleanup_stop_continue']['later_outer_terminal_seconds']==210 and m['cleanup_stop_continue']['negative_custody_is_positive_terminal_gate']is False)
test('no_rescue_or_unverified_signal','later OS absence cannot repair old wait4/highwater' in m['cleanup_stop_continue']['no_rescue'] and 'UNKNOWN, never absence' in m['cleanup_stop_continue']['permission_denial'])
test('lifecycle_contract_15_ordered_predicates',[c['id']for c in contract['checks']]==['L%02d'%i for i in range(1,16)])
test('contract_mandatory_diagnostic_failure_blocks_closure','inability to retain mandatory custody diagnostics blocks closure' in contract['expected_records']['cleanup_events']['overflow_rule'])
test('negative_observer_not_positive_gate','Separate negative custody closure' in contract['expected_records']['negative_lifecycle_outcome']['rule'])
test('natural_original_bank_exercise','bank_A_fixed reference' in m['cleanup_stop_continue']['natural_failure_exercise'])
test('no_current_grant_or_actual_adoption',not os.path.lexists(D/'ROOT-scope-adoption-and-grants-v1.json'))

# Exact runtime role receipt predicates are read as Source, not called.
runner_text=Path(closure['arms']['reference']['runner']['path']).read_text()
test('runner_three_review_schemas_present',all(s in runner_text for s in('direct-projection-qualification-components-Source-review-v1','direct-projection-qualification-outer-Source-review-v1','direct-projection-qualification-prospective-plan-review-v1')))
test('runner_requires_current_C_and_zero_science',"review['reviewer_identity']=='/root/conventional_control_review'" in runner_text and "type(review['scientific_calls'])is int" in runner_text and "review['actual_execution_authorized']is False" in runner_text)
test('before_Popen_consumed_boundary',runner_text.index("actual.mkdir(mode=0o700)")<runner_text.index("consumed=save_new")<runner_text.index('process=subprocess.Popen('))
test('closed_ns_early_scope_explicit','Early wait4/status and parent-close snapshot' in runner_text)
test('negative_raw_stable_log_final_ledger_present',all(s in runner_text for s in('negative raw custody begins before210','negative whole preimage read before210','whole stable log read completed before210','stable_writer_quiescence=stable','completed_before_deadline=ledger_completed<overall')))
test('diagnostic_incomplete_is_irreversible','diagnostics_incomplete=False' in runner_text and "cleanup['diagnostics_incomplete']=False" not in runner_text and "cleanup['diagnostics_incomplete']=True" in runner_text)
observer_text=Path(closure['arms']['reference']['observer']['path']).read_text()
test('observer_dynamic_runner_pin_no_old_hardcode',"checked(plan['sources']['runner'])" in observer_text and "plan['sources']['runner']['path']" in observer_text)
test('observer_negative_stays_nonadmitted',"outcome['terminal_gate_passed']=(code==0" in observer_text and 'ROOT_resource_accepted=False' in observer_text)
test('observer225_not_new_admission',"process.wait(timeout=225)" in observer_text and "observed<receipt['overall_deadline_ns']" in observer_text)

audit=dict(schema='cleanup-isolation-false-bundle-raw-AST-audit-v1',reviewer_identity='/root/conventional_control_review',
    source_only=True,scientific_calls=0,component_imports=0,component_calls=0,fixture_calls=0,Reader_calls=0,
    Native_calls=0,inverse_calls=0,OS_process_probes=0,process_launches=0,actual_execution_authorized=False,
    scientific_acceptance=False,full_pipeline_qualified=False,unused_target_compile_count=8,
    manifest=manifest_pin,declaration=m['declaration'],runtime_closure=m['runtime_closure'],
    harness_declaration=m['harness_declaration'],contract=contract_pin,current_master=master,
    prior_reviews=ancestors,raw_checked_pins=list(raw_pins.values()),subjects=subjects,
    fresh_paths_checked=fresh_paths,checks=checks,check_count=len(checks),mismatch_count=sum(not c['passed']for c in checks))
out=C/'cleanup-false-bundle-raw-audit-v1.json'
with out.open('x')as f:json.dump(audit,f,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False);f.write('\n')
print(json.dumps(dict(audit=desc(out),check_count=audit['check_count'],mismatch_count=audit['mismatch_count'],failed=[c for c in checks if not c['passed']]),indent=2))
