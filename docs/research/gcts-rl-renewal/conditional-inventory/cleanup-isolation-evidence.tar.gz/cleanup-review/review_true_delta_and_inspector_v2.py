"""Reviewer-owned ordinary/raw/AST audit; no target code is loaded or invoked."""
import ast
import difflib
import hashlib
import json
import os
from pathlib import Path

C=Path('/private/tmp/gcts-cleanup-isolation-peer-20261019')
D=Path('/private/tmp/gcts-cleanup-isolation-ROOT-20261019')
checks=[];rawpins={}
def check(name,value):checks.append(dict(check=name,passed=bool(value)))
def descriptor(path):
 p=Path(path);raw=p.read_bytes();return dict(path=str(p.resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def checked(pin,label):
 p=Path(pin['path']);check(label+':strict_pin',set(pin)=={'path','bytes','sha256'} and type(pin['bytes'])is int and pin['bytes']>=0)
 check(label+':canonical_regular',p.is_absolute() and p==p.resolve() and p.is_file() and not p.is_symlink())
 check(label+':whole_bytes',descriptor(p)==pin);rawpins[pin['path']]=pin
 return p.read_bytes()
def load(pin,label):return json.loads(checked(pin,label))
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def contains(v,p):
 if type(v)is dict:return v==p or any(contains(x,p)for x in v.values())
 if type(v)is list:return any(contains(x,p)for x in v)
 return False
def save(name,o):
 p=C/name
 with p.open('x')as f:json.dump(o,f,sort_keys=True,indent=2,allow_nan=False,ensure_ascii=False);f.write('\n')
 return descriptor(p)
adoption_pin=dict(path=str(D/'ROOT-scope-adoption-and-grants-cleanup-isolation-v1.json'),sha256='654e2239d0d883b8bb27c605e6aa8f665489305466596b3fe977780d4bc556a5',bytes=7652)
adoption=load(adoption_pin,'Root_adoption')
mp=dict(path=str(D/'prospective-metadata-manifest-cleanup-isolation-v1.json'),sha256='e419849c467447c21ee0822795e3f8b5037e3a84f471f1a7e94bf18b8fc8b51b',bytes=47484)
m=load(mp,'false_manifest');decl=load(m['declaration'],'declaration');closure=load(m['runtime_closure'],'closure')
hd=load(m['harness_declaration'],'harness_declaration')
rolepins=dict(Source=dict(path=str(C/'typed-components-Source-review-v1.json'),sha256='f4c558f9f917d0c1082a5d9fc568ed0a6f832b9bda18d8328e7492f726954a91',bytes=11751),outer_Source=dict(path=str(C/'typed-outer-Source-review-v1.json'),sha256='b71c35b8cdeb2104839c796f0fdb5f58cb7d642fb879191d52c4ff0f1cd96b6a',bytes=14091),plans=dict(path=str(C/'typed-prospective-plan-review-v1.json'),sha256='5dae694f297573859a58476fdde5efbe6112e77a72f02dc77eb7b45df7e9794f',bytes=60683))
roles={k:load(p,'role:'+k)for k,p in rolepins.items()}
check('adoption_exact_current_roles',adoption['review_roles']==rolepins and set(rolepins)=={'Source','outer_Source','plans'})
check('adoption_same_manifest_and_scope',adoption['prospective_manifest']==mp and adoption['author_identity']=='/root' and adoption['actual_execution_authorized']is True and adoption['launched_actuals']==0 and adoption['actual_invocations_maximum']==8 and len(adoption['issued'])==8)
check('adoption_stops_common_defect_no_rescue',all(t in adoption['stop_rule']for t in('NOT_RUN','No consumed subject retry','before original210','Unknown custody aborts','original180failure stays failed')))
for role,r in roles.items():
 check('role_zero_execution:'+role,r['reviewer_identity']=='/root/conventional_control_review' and r['source_only']is True and type(r['scientific_calls'])is int and r['scientific_calls']==0 and r['scientific_acceptance']is False and r['actual_execution_authorized']is False)
check('role_exact_schemas_and_pass',roles['Source']['schema']=='direct-projection-qualification-components-Source-review-v1' and roles['Source']['source_review_passed']is True and roles['outer_Source']['schema']=='direct-projection-qualification-outer-Source-review-v1' and roles['outer_Source']['source_review_passed']is True and roles['plans']['schema']=='direct-projection-qualification-prospective-plan-review-v1' and roles['plans']['prospective_review_passed']is True)
checks_start=len(checks)
issued=[];fresh=[];unique_pins={}
for i,(old,row)in enumerate(zip(m['rows'],adoption['issued'])):
 label=str(i)+':'+old['bank']+':'+old['arm']
 false=load(old['plan'],'false_plan:'+label);true=load(row['plan'],'true_plan:'+label)
 subject={k:v for k,v in true.items()if k!='authorization'}
 sha=hashlib.sha256(canonical(subject)).hexdigest()
 check('exact14plan13subject:'+label,len(true)==len(false)==14 and len(subject)==13 and set(true)==set(false))
 check('authorization_only_plan_delta:'+label,subject=={k:v for k,v in false.items()if k!='authorization'}==old['subject'] and [k for k in true if true[k]!=false[k]]==['authorization'])
 check('exact_subject_sha_and_schedule:'+label,sha==old['subject_sha256']==row['subject_sha256'] and row['arm']==old['arm'] and row['bank']==old['bank'])
 check('prospective_literal_full_subject:'+label,any(r['subject']==subject and r['subject_sha256']==sha for r in roles['plans']['subjects']))
 auth=load(row['authorization'],'Root_true_grant:'+label);fa=load(false['authorization'],'preserved_false_grant:'+label)
 check('exact_seven_field_Root_true_maxone:'+label,set(auth)=={'schema','author_identity','actual_execution_authorized','maximum_actual_invocations','subject_sha256','review_roles','scope'} and auth['schema']=='ROOT-direct-projection-qualification-authorization-v1' and auth['author_identity']=='/root' and auth['actual_execution_authorized']is True and type(auth['maximum_actual_invocations'])is int and auth['maximum_actual_invocations']==1 and auth['subject_sha256']==sha and auth['review_roles']==rolepins)
 check('preserved_false_not_reused:'+label,fa['actual_execution_authorized']is False and fa['review_roles']=={} and fa['subject_sha256']==sha and row['authorization']!=false['authorization'] and true['authorization']==row['authorization'])
 check('all_current_pins_limits_inputs_unchanged:'+label,true['declaration']==m['declaration'] and true['runtime_closure']==m['runtime_closure'] and true['sources']==closure['arms'][true['arm']] and true['python']==closure['python'] and true['limits']==decl['limits'] and true['arena_limits']==decl['arena_limits'] and true['adapter_limits']==decl['adapter_limits'] and {'arm':true['arm'],'bank':true['bank'],'inputs':true['inputs']}==decl['subjects'][i]==hd['subjects'][i])
 check('components_roles_exact_containment:'+label,all(contains(roles['Source'],true['sources'][k])for k in('worker','harness','adapter','arena')) and contains(roles['Source'],decl['harness_declaration']))
 check('outer_roles_exact_containment:'+label,all(contains(roles['outer_Source'],true['sources'][k])for k in('runner','observer')))
 check('plans_decl_closure_containment:'+label,contains(roles['plans'],true['declaration']) and contains(roles['plans'],true['runtime_closure']))
 actual=Path(true['actual_directory']);pp=Path(row['plan']['path']);terminal=pp.parent/(pp.stem+'-terminal-observation')
 check('canonical_fresh_actual_location:'+label,actual==actual.resolve() and actual.is_absolute() and actual.parent.is_dir())
 for p in (actual,actual/'CONSUMED.json',terminal,terminal/'CONSUMED.json',Path(old['plan']['path']).parent/(Path(old['plan']['path']).stem+'-terminal-observation')):
  check('fresh_absence:'+str(p),not os.path.lexists(p));fresh.append(str(p))
 for p in list(true['sources'].values())+[true['python']]+[v['pin']for v in true['inputs']]:unique_pins[p['path']]=p
 issued.append(dict(arm=true['arm'],bank=true['bank'],subject=subject,subject_sha256=sha,true_plan=row['plan'],authorization=row['authorization'],false_plan=old['plan'],actual_directory=str(actual),authorized_observer_directory=str(terminal)))
for p in closure['stdlib_files']:unique_pins[p['path']]=p
unique_pins[decl['cleanup_stop_continue']['contract']['path']]=decl['cleanup_stop_continue']['contract']
for p in unique_pins.values():checked(p,'current_raw_pin:'+Path(p['path']).name)
check('unique_eight_exact_subjects_paths',len({x['subject_sha256']for x in issued})==len({x['actual_directory']for x in issued})==len({x['subject']['invocation_id']for x in issued})==8)
check('same_role_reviewer_disclosed',len({r['reviewer_identity']for r in roles.values()})==1 and all('One reviewer' in r['authorship_disclosure'][0]for r in roles.values()))
audit=dict(schema='cleanup-isolation-final-grant-raw-audit-v1',reviewer_identity='/root/conventional_control_review',source_only=True,scientific_calls=0,component_calls=0,component_imports=0,process_probes=0,actual_execution_authorized=False,adoption=adoption_pin,review_roles=rolepins,manifest=mp,checks=checks,check_count=len(checks),mismatch_count=sum(not c['passed']for c in checks),raw_pins=list(rawpins.values()),fresh_paths_checked=fresh)
ap=save('final-grant-delta-raw-audit-v1.json',audit)
assert audit['mismatch_count']==0
receipt=dict(schema='direct-projection-qualification-final-grant-delta-review-v1',final_grant_delta_review_passed=True,reviewer_identity='/root/conventional_control_review',author_identity='/root',source_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,component_calls=0,component_imports=0,process_probes=0,process_launches=0,opaque_decodes=0,mathematical_proof_admitted=False,full_pipeline_qualified=False,Root_scope_adoption_and_grants=adoption_pin,manifest=mp,declaration=m['declaration'],runtime_closure=m['runtime_closure'],review_roles=rolepins,subjects=issued,check_count=audit['check_count'],mismatch_count=0,audit=ap,findings=[],limits=roles['plans']['limits'],scope='Narrow exact true-grant delta/freshness review only. Eight full13-field subjects are unchanged; only the authorization descriptor differs. Root-issued seven-field grants are true/maxone with three exact current roles. All actual/consumed/authorized-observer paths are absent at review. No launch authority delegated or worker/helper/probe called.',limitations=['One C reviewer fills all three prior role scopes and this delta, with exact disclosed inherited authorship and unchanged-source review ancestry. All previous Source/runtime/OS limitations remain.','Freshness is point-in-time. Root owns later barrier, exclusive ownership, serial launch, all180/210 and whole-byte/resource/custody gates. Source/prospective/delta PASS is not runtime success or qualification.','All V2/V3 consumed outcomes/grants and v5/v6 Source negatives remain unchanged and nonrescued. Negative continuation requires the separately declared full original210 custody matrix and no common defect.','Passive inspector v2 is a separate optional saved-metadata classifier, not a runtime Source/subject change or authority to turn a failed original180 result positive.'])
rp=save('typed-final-grant-delta-review-v1.json',receipt)

# The offered passive inspector is parsed/compiled only, not imported or called.
v1p=dict(path=str(D/'inspect_closed_trial_v1.py'),sha256='aab41d5da4439cc175787f4674b9a15e43295e24afb5891cd9b64efc45d21ed8',bytes=9166)
v2p=dict(path=str(D/'inspect_closed_trial_v2.py'),sha256='e1db576e9c1e6cf833be538b12c8e75e85721abe74d6b74f419f1cf33a7f4bc7',bytes=10169)
s1=checked(v1p,'inspector_v1').decode();s2=checked(v2p,'inspector_v2').decode()
t2=ast.parse(s2,filename=v2p['path']);unused=compile(t2,v2p['path'],'exec');del unused
diff=list(difflib.ndiff(s1.splitlines(keepends=True),s2.splitlines(keepends=True)))
inert_forward=''.join(difflib.restore(diff,2))==s2
inert_reverse=''.join(difflib.restore(diff,1))==s1
ic=[]
def it(n,b):ic.append(dict(check=n,passed=bool(b)))
it('actual_inert_forward_exact',inert_forward);it('actual_inert_reverse_exact',inert_reverse)
it('strict_nonnegative_int_lowerbounds','def whole(v):return type(v)is int and v>=0' in s2)
it('worker_deadline_numeric_witness',"wm=='complete positive work before180'and t['terminal_observed_ns']>=r['work_deadline_ns']"in s2)
it('worker_logical_part_plus_LF_witness',"wm=='full logical output cap'and whole(logical)and logical+1>134217728"in s2)
it('worker_logical_ledger_witness',"wm=='complete logical output ledger'and whole(logical)and logical>134217728"in s2)
it('worker_physical_witness',"wm=='all current physical files plus original9MiB outer reserves'and physical+9437184>134217728"in s2)
it('work_aggregate_strict_int_checks',"check('numeric_work_lowerbounds',whole(arena_work)and whole(adapter_work))"in s2 and 'and whole(arena_work)and whole(adapter_work)and max(arena_work,adapter_work)>400000000' in s2)
it('explicit_negative_exit_and_both_false_flags',"check('explicit_negative_exit_and_false_flags',t['runner_exit_code']==2 and\n              r['resource_candidate_accepted']is False and r['finite_helper_candidate']is False)"in s2)
it('literal_observer_field_and_joined_positive',"observer_terminal_gate_passed=positive,positive_helper_gate_passed=positive and passed"in s2)
it('all_original_custody_checks_retained',all(x in s2 for x in('real_wait4_exit_and_usage','no_observed_reappearance','negative_cleanup_closed_before210','stable_whole_logs_before210','post_child_complete_raw_custody_before210','stable_exact_final_physical_ledger','no_finalization_failure','no_integrity_diagnostic_errors')))
it('continuation_all_checks_fail_closed','passed=all(checks.values())'in s2 and 'may_continue_to_next_distinct_predeclared_subject=passed'in s2)
it('no_target_or_process_calls',not any(isinstance(n,ast.Call)and isinstance(n.func,ast.Attribute)and n.func.attr in('Popen','killpg','wait4','waitpid','run','call','exec_module')for n in ast.walk(t2)))
it('Source_only_AST_unused_compile',True)
assert all(x['passed']for x in ic)
ip=save('typed-passive-inspector-Source-review-v2.json',dict(schema='cleanup-isolation-passive-inspector-Source-review-v2',source_review_passed=True,reviewer_identity='/root/conventional_control_review',author_identity='/root',source_only=True,scientific_calls=0,subject_imports=0,component_calls=0,process_probes=0,actual_execution_authorized=False,scientific_acceptance=False,full_pipeline_qualified=False,subjects=[v2p],parent=v1p,preserved_negative=descriptor(C/'typed-passive-inspector-Source-review-v1-negative.json'),check_count=len(ic),mismatch_count=0,checks=ic,findings=[],unused_compile_count=1,inert_fullfile_directions=2,scope='Narrow I1/I2/I3 Source-only correction review. No inspector function or saved actual was evaluated. Optional post-terminal classifier remains outside the three execution Source roles and cannot qualify failed positive work.',limitations=['Trusted exact runner/observer/worker Source and exclusive-owner/stdlib/OS provenance remain conditional; this is not hostile JSON validation, comprehensive saved-data audit or a universal provenance guarantee.','New ValueError block also requires root_fault_type ValueError. Logical/physical emitter failures can have no latched checkpoint fault and are then conservatively unclassified, even with cap witnesses. Treat as UNKNOWN/manual review, not proof of a code defect or permission to continue. No claim of complete classification of all natural resource negatives.','Terminal-at-or-after-work is an after-error clock witness under trusted Source, not an exact recorded failure instant. Physical witness is complete retained current folder bytes plus original reserve, not simultaneous RAM or proof authority.','Missing files, invalid shapes or write errors can leave no inspector record; caller must preserve error and treat nonzero/missing/false as UNKNOWN/noncontinuation. All original external210/whole custody requirements remain.','No runtime smoke test or synthetic saved-data fixture was called; I1/I2/I3 corrections have Source review only. Previous v1 negative remains immutable.']))
handoff=save('final-grant-and-inspector-review-handoff-v1.json',dict(schema='cleanup-isolation-final-grant-and-inspector-handoff-v1',reviewer_identity='/root/conventional_control_review',source_only=True,scientific_calls=0,actual_execution_authorized=False,final_grant_delta_review=rp,passive_inspector_Source_review=ip,all_eight_true_plans=[x['true_plan']for x in issued],final_grant_delta_review_passed=True,tools_stopped_after_handoff=True,no_actual_or_probe_performed=True))
print(json.dumps(dict(final_grant_delta=rp,check_count=audit['check_count'],mismatch_count=0,inspector=ip,handoff=handoff,tools_stopped=True),indent=2))
