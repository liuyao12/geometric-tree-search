"""Ordinary metadata author only. Root must review before invoking this file.

Never imports, compiles, executes or calls any subject/component/fixture Source.
Writes fresh FALSE plans only; never makes an actual directory or true grant.
"""
from pathlib import Path
import ast
import hashlib
import json
import sys

D = Path('/private/tmp/gcts-cleanup-isolation-ROOT-20261019')
OLD = Path('/private/tmp/gcts-direct-projection-ROOT-20261019')
Q = Path('/private/tmp/gcts-direct-projection-qualification-20261019')
HERE = Path('/private/tmp/gcts-cleanup-lifecycle-contract-20261019')
PY = Path('/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12')
LIB = PY.parent.parent / 'lib/python3.12'
PLAN_SCHEMA = 'ROOT-direct-projection-qualification-plan-v1'
PLAN_FIELDS = frozenset(('schema','invocation_id','actual_directory','arm','bank',
    'python','sources','inputs','limits','arena_limits','adapter_limits',
    'declaration','runtime_closure','authorization'))
SUBJECT_FIELDS = PLAN_FIELDS - {'authorization'}
SOURCE_ROLES = frozenset(('worker','harness','adapter','arena','runner','observer'))


def pin(path):
    p = Path(path)
    assert p.is_absolute() and p == p.resolve() and p.is_file() and not p.is_symlink()
    raw = p.read_bytes()
    return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


def fixed(path, size, sha):
    result = pin(path)
    assert result['bytes'] == size and result['sha256'] == sha
    return result


def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,
                      allow_nan=False).encode('utf8')


def write(path, value):
    # Deliberate create-only output. Partial metadata failure is not resumed.
    with path.open('x') as stream:
        json.dump(value,stream,sort_keys=True,indent=2,allow_nan=False)
        stream.write('\n')
    return pin(path)


def literal(node):
    # Only explicit literal syntax and these two literal constructors; no eval.
    if (isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and
            node.func.id == 'dict' and not node.args and
            all(k.arg is not None for k in node.keywords)):
        return {k.arg:ast.literal_eval(k.value) for k in node.keywords}
    if (isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and
            node.func.id == 'frozenset' and len(node.args) == 1 and not node.keywords):
        return frozenset(ast.literal_eval(node.args[0]))
    return ast.literal_eval(node)


def literals(path):
    result = {}
    for node in ast.parse(path.read_bytes()).body:
        if not isinstance(node,ast.Assign):
            continue
        for target in node.targets:
            if not isinstance(target,ast.Name):
                continue
            try:
                result[target.id] = literal(node.value)
            except (ValueError,TypeError):
                pass
    return result


def main(runner_source_path):
    assert Path(sys.executable).resolve() == PY
    assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
    assert D.is_dir() and D == D.resolve() and not D.is_symlink()
    runner = Path(runner_source_path)
    assert runner.is_absolute() and runner == runner.resolve() and runner.parent == D
    runner_pin = pin(runner)

    # Every old scientific/evidence/fixture byte stays exact. Only Root's new
    # runner is parameterized; its newly computed descriptor still needs review.
    worker = fixed(OLD/'qualify_projection_worker_v6.py',19352,
        '52f23a9502038e90a8833e9b131cc1d48c3741ff9f7d423679efda79ed3d4645')
    observer = fixed(OLD/'observe_projection_qualification_once_v1.py',5461,
        '83c44206d7aedb14479d7479df8f8b02ca6ab6ac817d47b06e4b4ddbd578b557')
    harness = fixed(Q/'qualify_direct_projection_v3.py',32491,
        'fe75a4f9aaae247f298317a05aaf468b135d54d198c65ca0c70411cd4691dd55')
    harness_declaration = fixed(Q/'harness-declaration-v3.json',37420,
        'af7bc254ecf071e9748af0ec38921ca77940589e4a06a68c2c0a570c49467024')
    subject_entries_pin = fixed(Q/'subject-entries-v3.json',5775,
        '75e43ab0262c588d8830269380afae3c4e0ed761efdc548ca49366df52e2e261')
    python = fixed(PY,18058560,
        '21a9986bad1dbbcd813a252b19b4263fc0755ed2dbf8632c83e5d6117a12f319')
    reference = dict(
        adapter=fixed('/private/tmp/gcts-owned-evidence-integration-ROOT-20261019/owned_evidence_adapter_v3.py',14997,
            '91fb57f8a3fdd4563cb74f641b630bd725b813bd305608463920dd191f0216a8'),
        arena=fixed('/private/tmp/gcts-direct-reconcile-library-20261019/exact_evidence_arena_v3.py',38300,
            'fd3f1e1372c59365cc43c06dd8c815bdaca8cab6a2e4fa292d23a901d7f146f8'))
    candidate = dict(
        adapter=fixed(OLD/'owned_evidence_adapter_v4.py',15796,
            '9323bb2caf7eeb3907ff7079bb417e4764d5ad4813b669b08b23648209e3c769'),
        arena=fixed('/private/tmp/gcts-direct-projection-library-20261019/exact_evidence_arena_v4.py',48314,
            '99366602a91c83ccdf024107478bfa8d5814c7436f14d0e6d0b3ae870b478042'))
    parent_author = pin(OLD/'freeze_qualification_metadata_v5.py')
    parent_declaration = fixed(OLD/'qualification-declaration-v3.json',7942,
        'afa4f677e16d325967046813e6cde2f3cb642f0c9ee4b3504db63977f06e624c')
    parent_closure = fixed(OLD/'runtime-closure-v3.json',9811,
        'f391856bb277287c51cf0ca3de6ff86e7f12c4caad7d9e4bee9b95d81225105a')
    contract_pin = fixed(HERE/'lifecycle-observation-contract-v1.json',28571,
        '104f569f4de02c94d4334cdd697f3fe046e89a83d3a388911c01574aaea498d7')
    master = fixed(HERE/'basic-tiling-algorithm-isolated-HEAD.md',36240,
        'ca6ee206287bf18b69f88a35d30968312499567755f347a819af4cf49743e7d4')

    hd = json.loads(Path(harness_declaration['path']).read_bytes())
    subjects = json.loads(Path(subject_entries_pin['path']).read_bytes())
    pd = json.loads(Path(parent_declaration['path']).read_bytes())
    pc = json.loads(Path(parent_closure['path']).read_bytes())
    contract = json.loads(Path(contract_pin['path']).read_bytes())
    assert hd['schema'] == 'direct-projection-finite-harness-declaration-v3'
    assert hd['harness'] == harness and hd['subjects'] == subjects == pd['subjects']
    assert pd['harness_declaration'] == harness_declaration
    assert pc['declaration'] == parent_declaration and pc['python'] == python
    assert subjects == contract['cohort_invariants']['subjects']
    assert type(subjects) is list and len(subjects) == 8
    assert {(e['arm'],e['bank']) for e in subjects} == {
        (arm,bank) for arm in ('reference','candidate')
        for bank in ('generic','bank_A_fixed','bank_A_symbolic','bank_B_original006')}
    originals = {}
    for entry in subjects:
        assert set(entry) == {'arm','bank','inputs'}
        for item in entry['inputs']:
            assert set(item) == {'id','pin'} and pin(item['pin']['path']) == item['pin']
            originals[item['pin']['path']] = item['pin']
    assert len(originals) == 8
    assert len(hd['generic_fixture_order']) == 23 and len({g for g,n in hd['generic_fixture_order']}) == 6

    w = literals(Path(worker['path']))
    r = literals(runner)
    assert w['PLAN_SCHEMA'] == r['PLAN_SCHEMA'] == PLAN_SCHEMA
    assert w['PLAN_FIELDS'] == r['PLAN_FIELDS'] == PLAN_FIELDS and len(PLAN_FIELDS) == 14
    assert w['SOURCE_ROLES'] == r['SOURCE_ROLES'] == SOURCE_ROLES
    assert all(w[k] == r[k] for k in ('LIMITS','ARENA_LIMITS','ADAPTER_LIMITS'))
    assert w['LIMITS'] == pd['limits']
    assert w['ARENA_LIMITS'] == hd['arena_limits'] == pd['arena_limits']
    assert w['ADAPTER_LIMITS'] == hd['adapter_limits'] == pd['adapter_limits']
    assert hd['operation_ceilings'] == contract['preserved_operation_ceilings']
    assert w['LIMITS']['work_seconds'] == 180 and w['LIMITS']['overall_seconds'] == 210
    assert w['LIMITS']['memory_bytes'] == 1073741824
    assert w['LIMITS']['result_bytes'] == w['LIMITS']['expanded_bytes'] == 134217728
    assert w['ARENA_LIMITS']['work'] == w['ADAPTER_LIMITS']['operations'] == 400000000

    common = dict(worker=worker,runner=runner_pin,observer=observer,harness=harness)
    arms = dict(reference=dict(common,**reference),candidate=dict(common,**candidate))
    assert all(set(value) == SOURCE_ROLES for value in arms.values())
    for arm in ('reference','candidate'):
        assert {k:v for k,v in arms[arm].items() if k != 'runner'} == {
            k:v for k,v in pc['arms'][arm].items() if k != 'runner'}

    continuation = dict(
        contract=contract_pin,
        positive_work_boundary_seconds=180,later_outer_terminal_seconds=210,
        handled_cleanup_error_rule='May continue only to the next distinct predeclared fresh authorized subject after actual same-window wait4 exit/status/usage, final verified group absence with no observed reappearance/ownership contradiction, genuine stable bounded log custody, full runner/observer subject joins and no integrity/protocol defect, all before original210. Original180 negative stays failed.',
        permission_denial='UNKNOWN, never absence; no unverified signals or privilege/PID fallback.',
        common_defect_rule='Unreaped/missing wait4 evidence, UNKNOWN/PRESENT group, reappearance/ownership defect, missing required stable logs/receipt/join/accounting or external original210 closure: stop cohort, remaining NOT_RUN_COMMON_PROTOCOL_ABORT, retire grants.',
        no_rescue='No old actual/output/grant reuse; later OS absence cannot repair old wait4/highwater or admission.',
        natural_failure_exercise='Full unchanged bank_A_fixed reference, no substituted or reduced scientific input and no invented helper executions.',
        negative_custody_is_positive_terminal_gate=False)

    folder = D/'plans-cleanup-isolation-v1'
    declaration_path = D/'qualification-declaration-cleanup-isolation-v1.json'
    closure_path = D/'runtime-closure-cleanup-isolation-v1.json'
    manifest_path = D/'prospective-metadata-manifest-cleanup-isolation-v1.json'
    for output in (folder,declaration_path,closure_path,manifest_path):
        assert not output.exists()
    for entry in subjects:
        suffix = entry['bank']+'-'+entry['arm']
        assert not (D/('actual-cleanup-isolation-'+suffix+'-v1')).exists()
    # Prerequisite checks above are raw/AST/JSON only. Mutation starts here;
    # later closure serialization failure leaves partial FALSE metadata, no grant.
    folder.mkdir(exist_ok=False)
    declaration = write(declaration_path,dict(
        schema='ROOT-direct-projection-qualification-declaration-v1',author_identity='/root',
        cohort='cleanup-isolation-v1',source_only=True,scientific_calls=0,
        actual_execution_authorized=False,limits=w['LIMITS'],arena_limits=w['ARENA_LIMITS'],
        adapter_limits=w['ADAPTER_LIMITS'],harness_declaration=harness_declaration,
        subjects=subjects,full_pipeline_qualified=False,mathematical_proof_accepted=False,
        parent_declaration_context_only=parent_declaration,current_master=master,
        cleanup_stop_continue=continuation,
        scope='Cleanup-only runner successor; same three whole original representation banks and complete six-group generic bank, reference/candidate fresh subjects. Exposed finite evidence qualification only, no Native/Model/search/inverse/Reader execution or proof/fullcold authority. All failures preserved; no reduced bank, failed-prefix recovery, true grant or actual execution authorized by this metadata.'))

    sources = {v['path']:v for values in arms.values() for v in values.values()}
    census = []; modules = set()
    for descriptor in sources.values():
        raw = Path(descriptor['path']).read_bytes()
        assert pin(descriptor['path']) == descriptor
        tree = ast.parse(raw); imports = []
        for node in ast.walk(tree):
            if isinstance(node,ast.Import):
                imports.extend(a.name for a in node.names)
            elif isinstance(node,ast.ImportFrom):
                assert node.level == 0 and node.module is not None
                imports.append(node.module)
        modules.update(imports)
        census.append(dict(source=descriptor,direct_imports=sorted(set(imports)),
            AST_sha256=hashlib.sha256(ast.dump(tree,include_attributes=False).encode()).hexdigest()))
    files = {value['path']:value for value in pc['stdlib_files']}
    for name in sorted(modules | {'json.encoder','json.decoder','json.scanner'}):
        p = LIB.joinpath(*name.split('.'))
        p = p.with_suffix('.py') if p.with_suffix('.py').is_file() else p/'__init__.py'
        if p.is_file():
            files[str(p.resolve())] = pin(p.resolve())
    assert all(pin(value['path']) == value for value in pc['stdlib_files'])
    closure = write(closure_path,dict(
        schema='ROOT-direct-projection-qualification-runtime-closure-v1',author_identity='/root',
        cohort='cleanup-isolation-v1',source_only=True,scientific_calls=0,
        actual_execution_authorized=False,scientific_acceptance=False,
        python=python,arms=arms,declaration=declaration,stdlib_files=list(files.values()),
        direct_import_census=census,direct_import_modules=sorted(modules),
        explicit_dynamic_edges=pc['explicit_dynamic_edges'],runtime_trust=pc['runtime_trust'],
        parent_runtime_closure_context_only=parent_closure,
        trusted_stdlib_scope='Same parent direct-entry pinning and explicit builtin/frozen/transitive/OS-loader trust; current runner imports rescanned as raw AST. No whole-loader seal or hostile-code sandbox claim.',
        cleanup_stop_continue=continuation,
        Native_calls=0,Model_calls=0,inverse_calls=0,Reader_calls=0,search_calls=0,
        opaque_program_decodes=0,full_pipeline_qualified=False))

    manifest = []
    order = dict(generic=0,bank_A_fixed=1,bank_A_symbolic=2,bank_B_original006=3)
    for entry in sorted(subjects,key=lambda x:(order[x['bank']],x['arm'] != 'reference')):
        suffix = entry['bank']+'-'+entry['arm']
        ident = 'direct-projection-cleanup-isolation-'+suffix+'-ROOT-20261019-v1'
        actual = str(D/('actual-cleanup-isolation-'+suffix+'-v1'))
        subject = dict(schema=PLAN_SCHEMA,invocation_id=ident,actual_directory=actual,
            arm=entry['arm'],bank=entry['bank'],python=python,sources=arms[entry['arm']],
            inputs=entry['inputs'],limits=w['LIMITS'],arena_limits=w['ARENA_LIMITS'],
            adapter_limits=w['ADAPTER_LIMITS'],declaration=declaration,runtime_closure=closure)
        assert set(subject) == SUBJECT_FIELDS and len(subject) == 13
        sha = hashlib.sha256(canonical(subject)).hexdigest()
        authorization = write(folder/('authorization-false-'+suffix+'.json'),dict(
            schema='ROOT-direct-projection-qualification-authorization-v1',author_identity='/root',
            actual_execution_authorized=False,maximum_actual_invocations=1,
            subject_sha256=sha,review_roles={},scope='FALSE cleanup-isolation metadata only. No subject execution authorized.'))
        plan = dict(subject,authorization=authorization)
        assert set(plan) == PLAN_FIELDS and len(plan) == 14
        plan_pin = write(folder/('plan-false-'+suffix+'.json'),plan)
        manifest.append(dict(arm=entry['arm'],bank=entry['bank'],plan=plan_pin,subject=subject,
            subject_sha256=sha,actual_directory=actual))
    assert len(manifest) == 8
    final = write(manifest_path,dict(
        schema='ROOT-direct-projection-prospective-metadata-manifest-v1',author_identity='/root',
        cohort='cleanup-isolation-v1',source_only=True,scientific_calls=0,
        actual_execution_authorized=False,author_source=pin(Path(__file__).resolve()),
        parent_metadata_author_context_only=parent_author,harness_declaration=harness_declaration,
        frozen_subject_entries=subject_entries_pin,full_original_inputs=list(originals.values()),
        declaration=declaration,runtime_closure=closure,cleanup_stop_continue=continuation,
        rows=manifest,total_actuals_proposed=8,actuals_launched=0,
        actual_directories_created=0,true_grants_created=0,old_grants_reused=0,
        limitation='Ordinary raw/AST/JSON metadata only. Root must obtain fresh exact Source/outer/prospective reviews and grants; no subject or harness/component/fixture import, compilation, evaluation or execution here.'))
    print(json.dumps(final,sort_keys=True))


if __name__ == '__main__':
    assert len(sys.argv) == 2, 'one exact Root runner Source path inside the new output directory'
    main(sys.argv[1])
