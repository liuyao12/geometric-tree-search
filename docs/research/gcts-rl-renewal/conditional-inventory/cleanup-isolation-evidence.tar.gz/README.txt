CLEANUP ISOLATION AND EXPLICIT WANG SOURCE

Read root/ROOT-cohort-closure-v1.json first. Eight launched subjects: four finite helper passes, four closed resource negatives. Generic both pass; direct capture passes whole fixed and symbolic saved results. All six development roots fail: reference parent deadline (worker separately reports work ceiling), candidate aggregate Arena work ceiling. No whole-workload helper qualification, production qualification, new proof or GCTS/RL advantage. All current and prior execution grants are retired.

wang-library contains unexecuted compiler Source and an informal finite correspondence argument, with independent Source review. There is no fixed FOL checker/palette or runtime certificate.

Every complete declared input is included. The inventory maps original raw descriptors to archive paths. No runtime or opaque original parent is redistributed. Prior outcomes are retained, not rescued.
