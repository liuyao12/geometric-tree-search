"""Package closed saved evidence and complete preimages; no scientific replay."""
from pathlib import Path
import hashlib
import io
import json
import re
import tarfile

D=Path('/private/tmp/gcts-cleanup-isolation-ROOT-20261019')
OUT=D/'publication-staging-v1'


def descriptor(p):
    h=hashlib.sha256();n=0;tail=b''
    patterns=[rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',rb'ghp_[A-Za-z0-9]{30,}',
        rb'github_pat_[A-Za-z0-9_]{30,}',rb'sk-proj-[A-Za-z0-9_-]{30,}',rb'AKIA[0-9A-Z]{16}',
        rb'(?i)Authorization:\s*Bearer\s+[A-Za-z0-9._-]{20,}']
    with p.open('rb')as f:
        while b:=f.read(1048576):
            h.update(b);n+=len(b)
            assert not any(re.search(q,tail+b)for q in patterns),('possible secret; do not publish',str(p))
            tail=b[-256:]
    return dict(path=str(p.resolve()),bytes=n,sha256=h.hexdigest())


def main(review):
    closure=json.loads((D/'ROOT-cohort-closure-v1.json').read_bytes())
    assert closure['all_current_grants_retired_for_further_Root_use']is True
    assert closure['all_owned_exec_handles_closed']is True
    assert closure['all_owned_workers_reaped_and_groups_observed_absent']is True
    review_path=Path(review);assert review_path.is_file()
    sources=[]
    for label,root in [('root',D),('cleanup-review',Path('/private/tmp/gcts-cleanup-isolation-peer-20261019')),
        ('lifecycle-contract',Path('/private/tmp/gcts-cleanup-lifecycle-contract-20261019')),
        ('wang-library',Path('/private/tmp/gcts-wang-spacetime-library-20261019')),
        ('wang-review',Path('/private/tmp/gcts-wang-spacetime-benchmark-review-20261019')),
        ('public-math-review',Path('/private/tmp/gcts-cleanup-isolation-math-review-20261019'))]:
        for p in sorted(root.rglob('*')):
            if OUT in p.parents or p.name.startswith('ROOT-publication-'):
                continue
            assert not p.is_symlink(),'no symlinks'
            if p.is_file():
                assert p.suffix not in('.pyc','.gz','.png'),'no unexpected binary/cache'
                sources.append((p,label+'/'+str(p.relative_to(root))))
    grants=json.loads((D/'ROOT-scope-adoption-and-grants-cleanup-isolation-v1.json').read_bytes())
    external={}
    for row in grants['issued']:
        plan=json.loads(Path(row['plan']['path']).read_bytes())
        for item in plan['inputs']:
            d=item['pin'];external[d['path']]=(d,'fixtures/'+d['sha256']+'-'+Path(d['path']).name)
        for role,d in plan['sources'].items():
            if str(D) not in d['path']:
                external[d['path']]=(d,'execution-sources/'+d['sha256']+'-'+Path(d['path']).name)
    for p in [Path('/private/tmp/gcts-direct-projection-qualification-20261019/harness-declaration-v3.json'),
              Path('/private/tmp/gcts-direct-projection-qualification-20261019/subject-entries-v3.json'),
              Path('/private/tmp/gcts-direct-projection-qualification-20261019/complete-bank-provenance-v1.json'),
              Path('/private/tmp/gcts-direct-projection-qualification-20261019/harness-API-v3.json'),
              Path('/private/tmp/gcts-direct-projection-qualification-20261019/handoff-v3.json')]:
        assert p.is_file();sources.append((p,'execution-sources/'+p.name))
    for p in [Path('/private/tmp/gcts-direct-projection-ROOT-20261019/ROOT-final-milestone-v1.json'),
              Path('/private/tmp/gcts-direct-projection-ROOT-20261019/ROOT-qualification-cohort-closure-v1.json'),
              Path('/private/tmp/gcts-direct-projection-ROOT-20261019/ROOT-postfailure-owned-process-observation-v1.json'),
              Path('/private/tmp/gcts-direct-projection-cleanup-diagnosis-20261019/cleanup-Source-diagnosis-v1.json')]:
        assert p.is_file();sources.append((p,'previous-cohort/'+p.name))
    for path,(d,arc)in sorted(external.items()):
        p=Path(path);assert descriptor(p)==d
        sources.append((p,arc))
    assert len({arc for _,arc in sources})==len(sources)
    records=[dict(archive_path=arc,original=descriptor(p))for p,arc in sources]
    fixtures=[r for r in records if r['archive_path'].startswith('fixtures/')]
    assert len(fixtures)==8 and sum(r['original']['bytes']for r in fixtures)==130648177
    inventory=dict(schema='cleanup-isolation-public-evidence-inventory-v1',entries=records,
        fixture_count=8,complete_fixture_bytes=130648177,no_subject_execution=True,sensitive_pattern_scan_passed=True,
        scope='Current closed8subject cohort, all complete declared preimages, exact execution Sources/reviews, unexecuted drafts and selected prior-cohort saved records. Primary reader/index and opaque parent artifacts are not opened or included. All execution grants are retired; archive supplies no replay authorization.',
        portability='Original absolute descriptors map to archive paths. Runtime binaries/stdlib/OS are not redistributed. This is saved evidence, not a portable trusted runtime or replay recipe.',
        mathematical_proof_accepted=False,full_pipeline_qualified=False)
    readme=('CLEANUP ISOLATION AND EXPLICIT WANG SOURCE\n\n'
        'Read root/ROOT-cohort-closure-v1.json first. Eight launched subjects: four finite helper passes, '
        'four closed resource negatives. Generic both pass; direct capture passes whole fixed and symbolic saved results. '
        'All six development roots fail: reference parent deadline (worker separately reports work ceiling), '
        'candidate aggregate Arena work ceiling. No whole-workload helper qualification, production qualification, '
        'new proof or GCTS/RL advantage. All current and prior execution grants are retired.\n\n'
        'wang-library contains unexecuted compiler Source and an informal finite correspondence argument, '
        'with independent Source review. There is no fixed FOL checker/palette or runtime certificate.\n\n'
        'Every complete declared input is included. The inventory maps original raw descriptors to archive paths. '
        'No runtime or opaque original parent is redistributed. Prior outcomes are retained, not rescued.\n').encode()
    target=OUT/'cleanup-isolation-evidence.tar.gz';assert not target.exists()
    with tarfile.open(target,'w:gz',compresslevel=6)as archive:
        for p,arc in sources:
            info=archive.gettarinfo(str(p),arcname=arc);info.uid=info.gid=0;info.uname=info.gname='';info.mode=0o644
            with p.open('rb')as f:archive.addfile(info,f)
        for name,raw in [('EVIDENCE-INVENTORY.json',(json.dumps(inventory,sort_keys=True,indent=2)+'\n').encode()),('README.txt',readme)]:
            info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644;archive.addfile(info,io.BytesIO(raw))
    observation=dict(packet=descriptor(target),entries=len(records),raw_bytes=sum(r['original']['bytes']for r in records),complete_fixture_bytes=130648177,review=descriptor(review_path))
    with(D/'ROOT-evidence-packaging-observation-v1.json').open('x')as f:json.dump(observation,f,sort_keys=True,indent=2);f.write('\n')
    print(json.dumps(observation,sort_keys=True))


if __name__=='__main__':
    import sys
    assert len(sys.argv)==2
    main(sys.argv[1])
