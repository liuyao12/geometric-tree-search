"""Passive saved-JSON/raw-byte custody inspection after an owned exec is terminal.

Never imports or calls a subject, compiler, search, proof checker or decoder.
The returned gate cannot turn a resource-negative trial into a positive result.
"""
from pathlib import Path
import hashlib
import json
import sys

D=Path('/private/tmp/gcts-cleanup-isolation-ROOT-20261019')


def pin(p):
    b=p.read_bytes()
    return dict(path=str(p.resolve()),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())


def main(suffix):
    assert suffix in {b+'-'+a for b in ('generic','bank_A_fixed','bank_A_symbolic','bank_B_original006')
                      for a in ('reference','candidate')}
    pp=D/'plans-cleanup-isolation-v1'/('plan-authorized-'+suffix+'.json')
    plan=json.loads(pp.read_bytes());a=Path(plan['actual_directory'])
    folder=pp.parent/(pp.stem+'-terminal-observation')
    rp=a/'runner-receipt.json';tp=folder/'terminal.json'
    r=json.loads(rp.read_bytes());t=json.loads(tp.read_bytes())
    checks={}
    def check(name,value):checks[name]=value is True
    def whole(v):return type(v)is int and v>=0
    check('exact_plan_and_runner_receipt_joins',r['plan']==t['plan']==pin(pp) and t['runner_receipt']==pin(rp))
    check('exact_invocation_and_one_worker',r['invocation_id']==plan['invocation_id'] and r['worker_launch_attempts']==1)
    check('original_absolute_clock',r['work_deadline_ns']==r['began_ns']+180000000000 and
          r['overall_deadline_ns']==r['began_ns']+210000000000)
    check('external_terminal_before210',t['terminal_observed_ns']<r['overall_deadline_ns'] and
          t['runner_exit_code']in (0,2) and not t.get('residual_worker_cleanup_requires_inspection',False))
    check('real_wait4_exit_and_usage',r['worker_reaped'] is True and type(r.get('worker_exit_code')) is int and
          type(r.get('worker_wait4_status')) is int and type(r.get('worker_wait4_usage')) is dict and
          type(r['worker_wait4_usage'].get('ru_maxrss')) is int and r['worker_wait4_usage']['ru_maxrss']>=0 and
          r.get('worker_terminal_observed_ns',r['overall_deadline_ns'])<r['overall_deadline_ns'])
    check('final_group_absent',r['owned_group_absent'] is True)
    c=r['cleanup']
    check('complete_diagnostics',c['diagnostics_incomplete'] is False and len(c['events'])<=32 and
          c['event_limit']==32 and c['poll_limit']==2048)
    check('no_observed_reappearance',c.get('group_reappeared',False) is False)
    check('negative_cleanup_closed_before210',not c['attempted'] or
          (c.get('completed_before_deadline') is True and c.get('completed_ns',r['overall_deadline_ns'])<r['overall_deadline_ns'] and
           c.get('poll_cycles',2049)<=2048 and c.get('group_state')=='ABSENT'))
    check('actual_parent_log_closes',r['regular_logs_closed'] is True and all(
        o.get('opened') is True and o.get('closed') is True and o.get('close_attempts',0)>=1 and
        type(o.get('closed_ns')) is int for o in r['log_close_observations'].values()) and
        set(r['log_close_observations'])=={'stdout','stderr'})
    lc=r['whole_log_custody'];raw=r['post_child_raw_custody'];ledger=r.get('final_physical_ledger',{})
    check('stable_whole_logs_before210',lc.get('stable') is True and lc.get('complete') is True and
          lc.get('completed_before_deadline') is True and lc.get('completed_ns',r['overall_deadline_ns'])<r['overall_deadline_ns'])
    for name in ('stdout','stderr'):
        p=a/(name+'.bin')
        check('whole_'+name+'_pin',p.is_file() and p.stat().st_size<=4194304 and r.get(name)==pin(p))
    check('post_child_complete_raw_custody_before210',raw.get('checked') is True and
          raw.get('completed_before_deadline') is True and raw.get('completed_ns',r['overall_deadline_ns'])<r['overall_deadline_ns'])
    physical=sum(p.stat().st_size for p in a.iterdir()if p.is_file() and p.name!='runner-receipt.json')
    check('stable_exact_final_physical_ledger',ledger.get('enumeration_complete') is True and
          ledger.get('stable_writer_quiescence') is True and ledger.get('completed_before_deadline') is True and
          ledger.get('completed_ns',r['overall_deadline_ns'])<r['overall_deadline_ns'] and
          ledger.get('before_receipt_bytes')==physical and ledger.get('conservative_bytes')==physical+9437184)
    check('no_finalization_failure',r['finalization_errors']==[] and not(a/'POST_RECEIPT_DEADLINE_FAILURE.json').exists())
    check('observer_files_within_reserved1MiB',sum(p.stat().st_size for p in folder.iterdir()if p.is_file())<=1048576)
    check('no_proof_or_production_authority',all(r[k]is False for k in
          ('scientific_acceptance','mathematical_proof_accepted','full_pipeline_qualified')) and
          all(type(r[k])is int and r[k]==0 for k in ('Native_calls','Model_calls','inverse_calls','Reader_calls','search_calls')))
    bad_ops={'cleanup_infrastructure','cleanup_metadata','primary_diagnostic','finalization_diagnostic',
             'log_metadata_stdout','log_metadata_stderr','log_close_stdout','log_close_stderr'}
    check('no_integrity_diagnostic_errors',not any(k in bad_ops for k in c['error_summaries']))
    positive=t['terminal_gate_passed'] is True
    primary=r.get('primary_failure');resource_reason=None;worker_failure=None
    if positive:
        check('positive_original_terminal_gate',t['runner_exit_code']==0 and r['resource_candidate_accepted']is True and
              r['finite_helper_candidate']is True and ledger.get('within_original_cap')is True)
    else:
        check('explicit_negative_exit_and_false_flags',t['runner_exit_code']==2 and
              r['resource_candidate_accepted']is False and r['finite_helper_candidate']is False)
        check('negative_has_available_first_primary',type(primary)is dict and primary.get('type')!='UNAVAILABLE' and
              r['errors'] and r['errors'][0]==primary)
        if type(primary)is dict and primary.get('type')=='ValueError':
            msg=primary.get('message')
            if msg=='complete positive result/header/bytes/known-exit before180'and t['terminal_observed_ns']>=r['work_deadline_ns']:
                resource_reason=msg
            if msg=='finite helper worker highwater within1GiB'and r.get('worker_wait4_usage',{}).get('ru_maxrss',0)>1073741824:
                resource_reason=msg
            if msg=='all physical files plus outer9MiB reserves'and physical+9437184>134217728:
                resource_reason=msg
            if msg=='worker normal exit0' and (a/'worker-failure.json').is_file():
                worker_failure=json.loads((a/'worker-failure.json').read_bytes())
                kind=worker_failure['error_type'];wm=worker_failure['message']
                logical=worker_failure.get('canonical_logical_bytes')
                if kind=='ValueError'and worker_failure.get('root_fault_type')=='ValueError':
                    if wm=='complete positive work before180'and t['terminal_observed_ns']>=r['work_deadline_ns']:
                        resource_reason=wm
                    if wm=='full logical output cap'and whole(logical)and logical+1>134217728:
                        resource_reason=wm
                    if wm=='complete logical output ledger'and whole(logical)and logical>134217728:
                        resource_reason=wm
                    if wm=='all current physical files plus original9MiB outer reserves'and physical+9437184>134217728:
                        resource_reason=wm
                prefix=worker_failure.get('qualification_prefix')or{}
                lower=prefix.get('operation_totals_lower_bound',{})
                arena_work=lower.get('arena_work',0);adapter_work=lower.get('adapter_operations',0)
                check('numeric_work_lowerbounds',whole(arena_work)and whole(adapter_work))
                if kind=='ArenaLimit'and wm=='work'and whole(arena_work)and arena_work>400000000:
                    resource_reason=kind+':'+wm
                if kind=='EvidenceLimit'and wm=='adapter_operations'and whole(adapter_work)and adapter_work>400000000:
                    resource_reason=kind+':'+wm
                if kind=='QualificationFailure' and wm=='invocation-total unique instance work ceilings'and whole(arena_work)and whole(adapter_work)and max(arena_work,adapter_work)>400000000:
                    resource_reason=wm
                check('worker_failure_no_foreign_runtime',worker_failure.get('denied_events')==[] and
                      worker_failure.get('authority')is False and worker_failure.get('full_pipeline_qualified')is False)
        check('negative_reason_is_known_resource_failure',resource_reason is not None)
    passed=all(checks.values())
    out=dict(schema='ROOT-cleanup-isolation-closed-trial-observation-v2',suffix=suffix,checks=checks,
        closed_custody_gate_passed=passed,observer_terminal_gate_passed=positive,positive_helper_gate_passed=positive and passed,
        resource_failure_reason=resource_reason,may_continue_to_next_distinct_predeclared_subject=passed,
        runner_receipt=pin(rp),terminal=pin(tp),plan=pin(pp),
        elapsed_seconds=t['runner_clock_elapsed_seconds'],worker_peak_bytes=r.get('worker_wait4_usage',{}).get('ru_maxrss'),
        worker_exit_code=r.get('worker_exit_code'),primary_failure=primary,
        mathematical_proof_accepted=False,full_pipeline_qualified=False,
        scope='Saved ordinary metadata/raw-byte joins after owned exec closed. Clock claims depend on reviewed runner/observer, exclusive-owner/stdlib/OS assumptions; no replay or failed-prefix rescue. A closed resource-negative remains failed.')
    target=D/('ROOT-trial-observation-'+suffix+'-v2.json')
    with target.open('x')as f:json.dump(out,f,sort_keys=True,indent=2);f.write('\n')
    print(json.dumps(dict(record=pin(target),closed_custody_gate_passed=passed,observer_terminal_gate_passed=positive,positive_helper_gate_passed=positive and passed,
        resource_failure_reason=resource_reason,failed_checks=[k for k,v in checks.items()if not v],
        elapsed_seconds=out['elapsed_seconds'],worker_peak_bytes=out['worker_peak_bytes']),sort_keys=True))


if __name__=='__main__':
    assert len(sys.argv)==2
    main(sys.argv[1])
