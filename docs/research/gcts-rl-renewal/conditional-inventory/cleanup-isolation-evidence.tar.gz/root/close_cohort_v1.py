"""Summarize closed saved JSON and raw-byte descriptors; never execute a subject."""
from pathlib import Path
import hashlib
import json

D = Path('/private/tmp/gcts-cleanup-isolation-ROOT-20261019')


def pin(p):
    p = Path(p).resolve()
    b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())


def read(p):
    return json.loads(Path(p).read_bytes())


def main():
    grants_path = D/'ROOT-scope-adoption-and-grants-cleanup-isolation-v1.json'
    grants = read(grants_path)
    rows = []
    for issued in grants['issued']:
        pp = Path(issued['plan']['path'])
        assert pin(pp) == issued['plan']
        plan = read(pp)
        suffix = plan['bank']+'-'+plan['arm']
        a = Path(plan['actual_directory'])
        observation_path = D/('ROOT-trial-observation-'+suffix+'-v2.json')
        ob = read(observation_path)
        rp = a/'runner-receipt.json'
        tp = pp.parent/(pp.stem+'-terminal-observation')/'terminal.json'
        r, t = read(rp), read(tp)
        assert ob['runner_receipt'] == pin(rp) and ob['terminal'] == pin(tp)
        assert ob['closed_custody_gate_passed'] is True and all(ob['checks'].values())
        assert r['worker_reaped'] is True and r['owned_group_absent'] is True
        assert ob['positive_helper_gate_passed'] is t['terminal_gate_passed']
        positive = ob['positive_helper_gate_passed']
        row = dict(bank=plan['bank'], arm=plan['arm'], invocation_id=plan['invocation_id'],
            plan=pin(pp), authorization=issued['authorization'], subject_sha256=issued['subject_sha256'],
            runner_receipt=pin(rp), terminal=pin(tp), closed_trial_inspection=pin(observation_path),
            consumed=pin(a/'CONSUMED.json'), observer_consumed=pin(tp.parent/'CONSUMED.json'),
            launched=True, gate_passed=positive, closed_custody_gate_passed=True,
            classification='FINITE_HELPER_PASS' if positive else 'CLOSED_RESOURCE_NEGATIVE',
            original_primary_failure=r['primary_failure'],
            resource_failure_reason=ob['resource_failure_reason'],
            elapsed_seconds=ob['elapsed_seconds'], worker_peak_bytes=ob['worker_peak_bytes'],
            worker_exit_code=r['worker_exit_code'], worker_wait4_status=r['worker_wait4_status'],
            worker_wait4_usage=r['worker_wait4_usage'],
            terminal_before_original210=t['terminal_observed_ns'] < r['overall_deadline_ns'],
            mathematical_proof_accepted=False, full_pipeline_qualified=False)
        if (a/'result.json').is_file():
            result = read(a/'result.json')
            row['retained_result'] = pin(a/'result.json')
            row['result_resource_admitted'] = positive
            row['complete_qualification'] = result['qualification']
            row['outputs'] = result['outputs']
            for output in result['outputs']:
                assert pin(output['path']) == output
            assert result['Native_calls'] == result['Model_calls'] == result['search_calls'] == 0
        else:
            row['retained_result'] = None
            row['result_resource_admitted'] = False
            row['complete_qualification'] = None
            row['outputs'] = []
        if (a/'worker-failure.json').is_file():
            failure = read(a/'worker-failure.json')
            row['worker_failure'] = pin(a/'worker-failure.json')
            row['worker_failure_type'] = failure['error_type']
            row['worker_failure_message'] = failure['message']
            row['failure_prefix'] = failure.get('qualification_prefix')
            row['failed_prefix_accepted'] = False
        rows.append(row)
    assert len(rows) == 8 and sum(r['gate_passed'] for r in rows) == 4
    generic = {r['arm']:r for r in rows if r['bank']=='generic'}
    for row in generic.values():
        assert row['gate_passed'] and len(row['complete_qualification']['rows']) == 23
        assert len(row['outputs']) == 9
    exact = []
    for left,right in zip(generic['reference']['outputs'], generic['candidate']['outputs']):
        assert (left['bytes'],left['sha256']) == (right['bytes'],right['sha256'])
        exact.append(dict(reference=left,candidate=right,complete_bytes_equal=True))
    summary = dict(schema='ROOT-cleanup-isolation-cohort-closure-v1',author_identity='/root',
        grants=pin(grants_path),launch_barrier=pin(D/'ROOT-launch-barrier-v1.json'),
        original_master=pin(D/'basic-tiling-algorithm-current.md'),
        planned=8, launched=8, helper_passes=4, resource_negatives=4, not_run=0,
        candidate_passing_banks=[r['bank'] for r in rows if r['arm']=='candidate' and r['gate_passed']],
        reference_passing_banks=[r['bank'] for r in rows if r['arm']=='reference' and r['gate_passed']],
        generic_complete_bytes=exact,rows=rows,
        all_current_grants_retired_for_further_Root_use=True,
        all_owned_exec_handles_closed=True,all_owned_workers_reaped_and_groups_observed_absent=True,
        all_eight_original210_custody_gates_passed=True,
        whole_declared_helper_qualified=False,scientific_acceptance=False,
        mathematical_proof_accepted=False,full_pipeline_qualified=False,goal_complete=False,
        wang_source_adoption=pin(D/'ROOT-wang-Source-review-adoption-v1.json'),
        scope='Eight exact fresh serial helper subjects only. Four finite passes and four resource negatives. Full original fixtures and caps; no failed-prefix recovery or consumed-subject retry. No new theorem/search/RL/GCTS result. Source-only Wang compiler is separate and unexecuted.',
        comparison_limits=['One trial per arm/workload; no statistical speedup claim.',
            'Generic candidate includes three additional API diagnostics; generic elapsed time is not matched speed.',
            'Standalone worker peak excludes Native and is not full production fit or allocation attribution.',
            'B reference original runner primary is deadline; its retained worker diagnostic separately reports aggregate Arena work ceiling. Failure instants are not established by terminal times.',
            'B candidate work lower bound is a bounded diagnostic, not a complete output or a resumed proof.',
            'Four earlier source-only reviewer roles/deltas rely on the declared runtime/OS/exclusive-owner assumptions; no hostile sandbox or formal runtime guarantee.',
            'No current compiler, proof checker, search, inverse, Model or Native call was authorized by this cohort.'],
        next_research='Whole six-root work-ceiling failure remains open. Do not infer production readiness from the two saved-result passes. Advance the separate explicit fixed-checker/Wang foundation and independently checked theorem search; retain original limits and whole-workload admission before any later production comparison.')
    p=D/'ROOT-cohort-closure-v1.json'
    with p.open('x') as f:
        json.dump(summary,f,sort_keys=True,indent=2)
        f.write('\n')
    print(json.dumps(dict(closure=pin(p),planned=8,launched=8,helper_passes=4,resource_negatives=4),sort_keys=True))


if __name__ == '__main__':
    main()
