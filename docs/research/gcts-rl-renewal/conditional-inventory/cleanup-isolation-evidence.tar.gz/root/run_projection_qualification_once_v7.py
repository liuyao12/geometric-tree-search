"""One exact finite capture-qualification worker, unchanged numeric caps."""
import time
NOW=time.monotonic_ns
BEGAN=NOW()
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys

VERSION='direct-projection-qualification-once-runner-v7-isolated-cleanup'
PLAN_SCHEMA='ROOT-direct-projection-qualification-plan-v1'
PLAN_FIELDS=frozenset(('schema','invocation_id','actual_directory','arm','bank',
    'python','sources','inputs','limits','arena_limits','adapter_limits',
    'declaration','runtime_closure','authorization'))
SOURCE_ROLES=frozenset(('worker','harness','adapter','arena','runner','observer'))
LIMITS=dict(work_seconds=180,overall_seconds=210,memory_bytes=1073741824,
    result_bytes=134217728,expanded_bytes=134217728,stdout_bytes=4194304,
    stderr_bytes=4194304,worker_receipt_bytes=4194304,
    runner_metadata_bytes=8388608,observer_bytes=1048576)
_METADATA_BYTES=0
CLEANUP_EVENT_LIMIT=32
CLEANUP_POLL_LIMIT=2048


def error_information(error):
    """Best-effort bounded metadata; never rethrow while preserving a primary."""
    try:
        number=getattr(error,'errno',None)
        return dict(type=type(error).__name__,message=str(error)[:512],
                    errno=number if type(number)is int else None)
    except BaseException:
        return dict(type='UNAVAILABLE',message='error metadata unavailable',errno=None)

ARENA_LIMITS = {'cache_bytes':8388608,'cache_entries':65536,'chunk_bytes':65536,'depth':512,
    'documents_expanded_bytes':134217728,'edges':8000000,'fragment_bytes':4096,'integer_digits':4096,
    'materialized_bytes':4194304,'materialized_occurrences':100000,'nodes':2000000,
    'root_expanded_bytes':134217728,'roots':4096,'scalar_bytes':16777216,'wire_bytes':134217728,'work':400000000}
ADAPTER_LIMITS = {'operations':400000000,'value_bytes':134217728,'depth':512,'chunk_bytes':65536}


def need(value,message):
    if not value:raise ValueError(message)


def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode('utf8')


def descriptor(path,raw):
    return dict(path=str(Path(path).resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


def checked(pin,cap=16777216):
    need(type(pin)is dict and set(pin)=={'path','bytes','sha256'} and
         type(pin['bytes'])is int and 0<=pin['bytes']<=cap,'bounded exact descriptor')
    p=Path(pin['path']);need(p.is_absolute()and p==p.resolve()and p.is_file()and not p.is_symlink(),
                            'canonical regular input/Source')
    raw=p.read_bytes();need(descriptor(p,raw)==pin,'complete raw descriptor equality');return raw


def save_new(path,value):
    global _METADATA_BYTES
    raw=canonical(value)+b'\n';need(_METADATA_BYTES+len(raw)<=8388608,'aggregate outer metadata within8MiB')
    _METADATA_BYTES+=len(raw)
    fd=os.open(str(path),os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
    with os.fdopen(fd,'wb')as f:f.write(raw);f.flush();os.fsync(f.fileno())
    return descriptor(path,raw)


def contains(value,wanted):
    if value==wanted:return True
    if type(value)is dict:return any(contains(v,wanted)for v in value.values())
    if type(value)is list:return any(contains(v,wanted)for v in value)
    return False


def group_absent(pgid):
    try:os.killpg(pgid,0)
    except ProcessLookupError:return True
    return False


def validate_qualification(q,plan,declaration,outputs):
    need(q['outputs']==outputs,'qualification/emitter/header output join')
    need(q['original_values_retained_through_worker_positive_boundary']is True,
         'complete originals retained through final positive boundary')
    for field in ('authority','full_pipeline_qualified','mathematical_proof_accepted',
                  'mathematical_authority','resource_authority','production_full_cold_qualified'):
        need(q[field]is False,'finite representation only, no proof or production authority')
    for field in ('scientific_calls','Native_calls','Model_calls','search_calls','Reader_calls','inverse_calls'):
        need(type(q[field])is int and q[field]==0,'no proof/search runtime')
    expected=declaration['finite_expected_census'];ic=q['instance_census'];cc=q['call_census']
    need(all(type(ic[k])is int for k in ('unique_Stores','unique_separate_direct_Arenas','unique_Arenas')),
         'strict instance census integers')
    need(type(cc['component_calls'])is int and 0<cc['component_calls']<=declaration['call_bounds']['component_calls']==1024,
         'bounded actual public API starts')
    for field in ('passive_statistics_calls','check_callbacks','guard_callbacks','cleanup_failures'):
        need(type(cc[field])is int and cc[field]>=0,'strict callback/passive/cleanup counts')
    rows=q['rows'];need(type(rows)is list,'complete ordered result rows')
    if plan['bank']=='generic':
        e=expected['generic_each'];order=declaration['generic_fixture_order']
        need(e['fixture_count']==23 and e['group_count']==6 and len(order)==23 and
             [[r['group'],r['fixture']]for r in rows]==order and len({g for g,n in order})==6,
             'all twenty-three exact ordered generic cases across six groups')
        na={'projection_caps','unread_tail_mutation','arena_foreign_phases'}
        need(na<={name for group,name in order},'three exact prospectively reference-NA cases')
        for r in rows:
            need(type(r['result'])is dict,'complete ordinary per-case result')
            actual_na=r['result'].get('status')=='DECLARED_NOT_APPLICABLE_NO_NEW_API'
            need(actual_na==(plan['arm']=='reference'and r['fixture']in na),'exact reference-NA scope')
        direct=e[plan['arm']+'_separate_direct_Arenas']
        need(ic['unique_Stores']==e['fresh_Stores']==21 and
             ic['unique_separate_direct_Arenas']==direct and direct==(3 if plan['arm']=='candidate'else 0) and
             ic['unique_Arenas']==e[plan['arm']+'_total_Arenas']==21+direct,
             'all unique generic Store/private/direct Arena instances')
        labels=['wide_array','wide_object','shared_subtree','equal_distinct','tuple_projection',
                'chunk_unicode','mixed_roots','repeated_ports','scalar_domain']
        need([Path(x['path']).name for x in outputs]==['canonical-'+x+'.json'for x in labels],
             'all nine complete generic output bodies in exact order')
        for name in ('mixed_roots','repeated_ports'):
            row=next(r for r in rows if r['fixture']==name)
            need(row['result']in outputs,'mixed/repeated-reference row tied to actual output')
    else:
        e=expected['bank_B'if plan['bank']=='bank_B_original006'else'bank_A_each']
        need(ic['unique_Stores']==e['fresh_Stores']==1 and ic['unique_separate_direct_Arenas']==0 and
             ic['unique_Arenas']==1,'one retained Store/Arena for whole original bank')
        need(cc['component_calls']==e['public_component_calls']==(10 if plan['bank']=='bank_B_original006'else 4),
             'exact complete bank public-call census')
        need(len(outputs)==e['complete_actual_outputs']==1 and len(rows)==1 and
             rows[0]['bank']==plan['bank']and rows[0]['complete_output']==outputs[0] and
             Path(outputs[0]['path']).name=='canonical-'+plan['bank']+'.json',
             'one complete exact bank row and output, no shortened input or suffix')


def main(plan_path):
    need(sys.platform=='darwin','Darwin ru_maxrss bytes')
    p=Path(plan_path).resolve();raw=p.read_bytes();need(len(raw)<=16777216,'finite plan');plan=json.loads(raw)
    need(type(plan)is dict and set(plan)==PLAN_FIELDS and plan['schema']==PLAN_SCHEMA,'exact fourteen-field plan')
    need(plan['limits']==LIMITS and plan['arena_limits']==ARENA_LIMITS and
         plan['adapter_limits']==ADAPTER_LIMITS and plan['arm']in('reference','candidate'),'original numeric limits/selected arm')
    need(type(plan['sources'])is dict and set(plan['sources'])==SOURCE_ROLES and
         descriptor(__file__,Path(__file__).read_bytes())==plan['sources']['runner'],'exact runner Source')
    checked(plan['python'],67108864)
    for pin in plan['sources'].values():checked(pin)
    declaration=json.loads(checked(plan['declaration']));closure=json.loads(checked(plan['runtime_closure']))
    need(declaration['schema']=='ROOT-direct-projection-qualification-declaration-v1' and
         declaration['limits']==LIMITS and declaration['full_pipeline_qualified']is False and
         declaration['arena_limits']==plan['arena_limits'] and
         declaration['adapter_limits']==plan['adapter_limits'],'declared complete finite profile')
    harness_declaration=json.loads(checked(declaration['harness_declaration']))
    need({'arm':plan['arm'],'bank':plan['bank'],'inputs':plan['inputs']}in declaration['subjects'],
         'whole declared bank, no shortened subject')
    need(closure['schema']=='ROOT-direct-projection-qualification-runtime-closure-v1' and
         closure['python']==plan['python'] and closure['arms'][plan['arm']]==plan['sources'] and
         closure['declaration']==plan['declaration'],'exact runtime closure')
    for pin in closure['stdlib_files']:checked(pin)
    for item in plan['inputs']:checked(item['pin'],134217728)
    subject={k:v for k,v in plan.items()if k!='authorization'}
    subject_sha=hashlib.sha256(canonical(subject)).hexdigest()
    auth=json.loads(checked(plan['authorization']))
    need(set(auth)=={'schema','author_identity','actual_execution_authorized','maximum_actual_invocations',
                     'subject_sha256','review_roles','scope'}and
         auth['schema']=='ROOT-direct-projection-qualification-authorization-v1' and
         auth['author_identity']=='/root' and auth['actual_execution_authorized']is True and
         type(auth['maximum_actual_invocations'])is int and auth['maximum_actual_invocations']==1 and
         auth['subject_sha256']==subject_sha,'exact Root max-one complete-subject grant')
    need(type(auth['review_roles'])is dict and set(auth['review_roles'])=={'Source','outer_Source','plans'},
         'three disclosed review scopes')
    for role,pin in auth['review_roles'].items():
        review=json.loads(checked(pin))
        need(review['reviewer_identity']=='/root/conventional_control_review' and
             review['source_only']is True and type(review['scientific_calls'])is int and
             review['scientific_calls']==0 and review['scientific_acceptance']is False and
             review['actual_execution_authorized']is False,'independent zero-execution review receipt')
        if role=='Source':
            need(review['schema']=='direct-projection-qualification-components-Source-review-v1' and
                 review['source_review_passed']is True,'component Source review')
            for k in('worker','harness','adapter','arena'):need(contains(review,plan['sources'][k]),'reviewed '+k)
            need(contains(review,declaration['harness_declaration']),'reviewed complete fixture declaration')
        elif role=='outer_Source':
            need(review['schema']=='direct-projection-qualification-outer-Source-review-v1' and
                 review['source_review_passed']is True and
                 all(contains(review,plan['sources'][k])for k in('runner','observer')),'exact outer/observer review')
        else:
            need(review['schema']=='direct-projection-qualification-prospective-plan-review-v1' and
                 review['prospective_review_passed']is True and
                 any(v['subject']==subject and v['subject_sha256']==subject_sha for v in review['subjects']) and
                 contains(review,plan['declaration'])and contains(review,plan['runtime_closure']),
                 'entire prospective subject and closure reviewed')
    actual=Path(plan['actual_directory'])
    need(actual.is_absolute()and actual==actual.resolve()and actual.parent.is_dir(),'fresh canonical actual location')
    actual.mkdir(mode=0o700);work=BEGAN+180000000000;overall=BEGAN+210000000000
    consumed=save_new(actual/'CONSUMED.json',dict(schema='direct-projection-qualification-consumed-v1',
        invocation_id=plan['invocation_id'],plan=descriptor(p,raw),subject_sha256=subject_sha,
        maximum_worker_launches=1,consumed_before_Popen=True,began_ns=BEGAN,
        work_deadline_ns=work,overall_deadline_ns=overall))
    result=dict(schema='direct-projection-qualification-once-receipt-v1',version=VERSION,
        invocation_id=plan['invocation_id'],arm=plan['arm'],bank=plan['bank'],plan=descriptor(p,raw),
        authorization=plan['authorization'],subject_sha256=subject_sha,consumed_marker=consumed,
        began_ns=BEGAN,work_deadline_ns=work,overall_deadline_ns=overall,limits=LIMITS,
        worker_launch_attempts=0,worker_pid=None,owned_pgid=None,worker_reaped=False,
        owned_group_absent=False,regular_logs_closed=False,resource_candidate_accepted=False,
        finite_helper_candidate=False,full_pipeline_qualified=False,scientific_acceptance=False,
        mathematical_proof_accepted=False,Native_calls=0,Model_calls=0,inverse_calls=0,
        Reader_calls=0,search_calls=0,errors=[],signals=[])
    process=None;reaped=False;status=None;usage=None;group_seen_absent=False;group_reappeared=False
    accepted=False;receipt_written=False;primary_error=None
    log_handles={'stdout':None,'stderr':None}
    log_observations={name:dict(opened=False,close_attempts=0,closed=False)
                      for name in('stdout','stderr')}
    cleanup=dict(attempted=False,events=[],event_limit=CLEANUP_EVENT_LIMIT,
                 poll_limit=CLEANUP_POLL_LIMIT,
                 dropped_events=0,counts={},error_summaries={},diagnostics_incomplete=False,
                 group_state='NOT_OBSERVED',completed_before_deadline=False)
    result.update(log_close_observations=log_observations,cleanup=cleanup,finalization_errors=[],
                  post_child_raw_custody=dict(checked=False,completed_before_deadline=False),
                  whole_log_custody=dict(stable=False,complete=False),
                  primary_failure=None,
                  closed_ns_scope='Early wait4/status and parent-close snapshot; raw/log/ledger/receipt work follows. Full closure requires external terminal join.')
    def information(error):
        value=error_information(error)
        if value['type']=='UNAVAILABLE':
            try:cleanup['diagnostics_incomplete']=True
            except BaseException:pass
        return value
    def note(operation,outcome,error=None):
        # Diagnostics cannot decide process state or interrupt an independent reap.
        try:
            key=operation+':'+outcome
            cleanup['counts'][key]=cleanup['counts'].get(key,0)+1
            event=dict(operation=operation,outcome=outcome,observed_ns=NOW(),
                       worker_pid=process.pid if process is not None else None)
            if error is not None:
                event['error']=information(error)
                summary=cleanup['error_summaries'].get(operation)
                if summary is None:
                    cleanup['error_summaries'][operation]=dict(count=1,first=event,last=event)
                else:
                    summary['count']+=1;summary['last']=event
            if len(cleanup['events'])<CLEANUP_EVENT_LIMIT:cleanup['events'].append(event)
            else:
                cleanup['events'][-1]=event;cleanup['dropped_events']+=1
        except BaseException:
            try:cleanup['diagnostics_incomplete']=True
            except BaseException:pass
    def owned_group_absent():
        nonlocal group_seen_absent,group_reappeared
        absent=group_absent(process.pid)
        if not absent and group_seen_absent:group_reappeared=True
        need(absent or not group_seen_absent,'owned group reappeared; no unverified signal')
        group_seen_absent=group_seen_absent or absent;return absent
    def reap():
        nonlocal reaped,status,usage
        if reaped:return True
        got,st,ru=os.wait4(process.pid,os.WNOHANG)
        if got:
            status=st;usage=ru;reaped=True;process.returncode=os.waitstatus_to_exitcode(st)
            result['worker_terminal_observed_ns']=NOW()
        return reaped
    def open_log(name):
        handle=(actual/(name+'.bin')).open('xb');log_handles[name]=handle
        log_observations[name].update(opened=True,opened_ns=NOW())
        return handle
    def close_logs(strict):
        first=None
        for name in('stdout','stderr'):
            handle=log_handles[name]
            if handle is None:continue
            if not handle.closed:
                try:log_observations[name]['close_attempts']+=1
                except BaseException as error:
                    if first is None:first=error
                    note('log_metadata_'+name,'ERROR',error)
                try:
                    handle.close()
                except BaseException as error:
                    if first is None:first=error
                    note('log_close_'+name,'ERROR',error)
                else:
                    note('log_close_'+name,'CLOSED'if handle.closed else'UNKNOWN')
                    if not handle.closed and first is None:first=ValueError('log close did not close '+name)
                    try:
                        log_observations[name].update(closed=handle.closed,closed_ns=NOW())
                    except BaseException as error:
                        if first is None:first=error
                        note('log_metadata_'+name,'ERROR',error)
            # A close that raised does not acquire a successful-close timestamp.
            try:log_observations[name]['closed']=handle.closed
            except BaseException as error:
                if first is None:first=error
                note('log_metadata_'+name,'ERROR',error)
        result['regular_logs_closed']=all(log_handles[name]is not None and
            log_handles[name].closed for name in('stdout','stderr'))
        if strict and first is not None:raise first
    def cleanup_child():
        # Every OS operation is individually guarded, with the original absolute cap.
        last_state='NOT_OBSERVED';cycles=0;complete=False;completed_ns=None
        try:cleanup.update(attempted=True,started_ns=NOW())
        except BaseException as error:note('cleanup_metadata','ERROR',error)
        def reap_step():
            if NOW()>=overall:return False
            if reaped:
                note('wait4','CACHED_REAPED');return True
            try:
                done=reap();note('wait4','REAPED'if done else'RUNNING');return done
            except BaseException as error:
                note('wait4','ERROR',error);return False
        def probe_step():
            nonlocal last_state
            if NOW()>=overall:return 'DEADLINE'
            try:
                absent=owned_group_absent()
                last_state='ABSENT'if absent else'PRESENT'
                note('group_probe',last_state)
            except PermissionError as error:
                last_state='PERMISSION_DENIED';note('group_probe',last_state,error)
            except BaseException as error:
                last_state='REAPPEARED'if group_reappeared else'ERROR'
                note('group_probe',last_state,error)
            try:cleanup['group_state']=last_state
            except BaseException as error:note('cleanup_metadata','ERROR',error)
            return last_state
        def send_step(sig,label):
            # A previous PRESENT result is never reused as signal authority.
            if NOW()>=overall or group_seen_absent or group_reappeared:return False
            if probe_step()!='PRESENT' or NOW()>=overall:return False
            try:
                os.killpg(process.pid,sig)
            except BaseException as error:
                note(label,'ERROR',error);return False
            # Sending succeeded even if its diagnostic append subsequently fails.
            try:result['signals'].append(dict(signal=sig,sent_ns=NOW()))
            except BaseException:
                try:cleanup['diagnostics_incomplete']=True
                except BaseException:pass
            note(label,'SENT');return True
        def pause():
            remaining=(overall-NOW())/1e9
            if remaining>0:
                try:time.sleep(min(.02,remaining))
                except BaseException as error:note('cleanup_sleep','ERROR',error)
        reap_step();state=probe_step()
        sent=False
        if state!='ABSENT':sent=send_step(signal.SIGTERM,'signal_TERM')
        if sent:
            until=min(overall,NOW()+1000000000)
            while NOW()<until and cycles<CLEANUP_POLL_LIMIT:
                cycles+=1
                reap_step();state=probe_step()
                if state=='ABSENT':break
                pause()
        if sent and state!='ABSENT':send_step(signal.SIGKILL,'signal_KILL')
        while NOW()<overall and cycles<CLEANUP_POLL_LIMIT:
            cycles+=1
            reap_step();state=probe_step()
            if reaped and state=='ABSENT'and not group_reappeared:
                completed_ns=NOW();complete=completed_ns<overall
                break
            pause()
        result['owned_group_absent']=last_state=='ABSENT'and not group_reappeared
        try:
            cleanup.update(ended_ns=NOW(),group_seen_absent=group_seen_absent,
                group_reappeared=group_reappeared,poll_cycles=cycles,
                completed_before_deadline=complete,completed_ns=completed_ns)
        except BaseException as error:note('cleanup_metadata','ERROR',error)
    def positive():need(NOW()<work,'complete positive result/header/bytes/known-exit before180')
    try:
        positive()
        command=[plan['python']['path'],'-I','-S','-B',plan['sources']['worker']['path'],str(p)]
        environment={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8',
                     'PYTHONHASHSEED':'0','PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1'}
        out=open_log('stdout');err=open_log('stderr')
        result['worker_launch_attempts']=1
        process=subprocess.Popen(command,stdin=subprocess.DEVNULL,stdout=out,stderr=err,
            start_new_session=True,env=environment,cwd=str(actual))
        result.update(worker_pid=process.pid,owned_pgid=process.pid,command=command)
        while not reap():
            positive()
            for name in('stdout','stderr'):
                need((actual/(name+'.bin')).stat().st_size<=LIMITS[name+'_bytes'],'bounded worker '+name)
            time.sleep(.02)
        close_logs(True)
        need(process.returncode==0,'worker normal exit0');positive()
        need(owned_group_absent(),'owned group absent');result['owned_group_absent']=True
        wp=actual/'worker-receipt.json';wraw=wp.read_bytes();positive()
        need(len(wraw)<=4194304,'bounded complete worker receipt');w=json.loads(wraw)
        need(w['schema']=='direct-projection-qualification-worker-receipt-v1' and
             w['invocation_id']==plan['invocation_id']and w['plan']==descriptor(p,raw) and
             w['began_ns']==BEGAN and w['work_deadline_ns']==work and
             w['overall_deadline_ns']==overall and w['positive_worker_completed_ns']<work and
             w['finite_helper_candidate']is True,'whole exact positive worker header')
        payload=json.loads(checked(w['result'],1048576));positive()
        need(payload['schema']=='direct-projection-qualification-result-v1' and
             payload['plan']==descriptor(p,raw)and payload['invocation_id']==plan['invocation_id'] and
             payload['declaration']==plan['declaration']and payload['runtime_closure']==plan['runtime_closure'],
             'complete result subject')
        q=payload['qualification']
        need(q['schema']=='direct-projection-finite-qualification-v1' and q['status']=='FINITE_HELPER_CANDIDATE' and
             q['arm']==plan['arm']and q['bank']==plan['bank']and q['authority']is False and
             q['full_pipeline_qualified']is False and q['mathematical_proof_accepted']is False,
             'finite helper outcome only')
        validate_qualification(q,plan,harness_declaration,w['outputs'])
        totals=q['operation_totals']
        need(type(totals)is dict and set(totals)=={'arena_work','adapter_operations'}and
             all(type(v)is int and 0<=v<=400000000 for v in totals.values()),
             'whole invocation aggregate400m Arena/adapter work')
        need(payload['outputs']==w['outputs']and payload['denied_events']==[] and
             all(payload[k]==0 for k in('Native_calls','Model_calls','inverse_calls','Reader_calls','search_calls','opaque_program_decodes')),
             'no other scientific runtime')
        for k in('full_pipeline_qualified','scientific_acceptance','mathematical_proof_accepted'):
            need(payload[k]is False and w[k]is False,'no mathematical or production authority')
        output_bytes=0
        for pin in w['outputs']:
            op=Path(pin['path']);need(op.parent==actual and op.name.startswith('canonical-')and op.suffix=='.json',
                                      'canonical output in owned actual directory')
            body=checked(pin,134217728);need(body.endswith(b'\n'),'complete LF output');output_bytes+=len(body);positive()
        need(output_bytes==payload['canonical_logical_bytes'] and
             w['logical_result_bytes']==output_bytes+w['result']['bytes']<=134217728 and
             w['outer_metadata_reservation']==9437184,'complete logical ledger')
        positive();result['positive_result_read_completed_ns']=NOW()
        need(usage.ru_maxrss<=1073741824,'finite helper worker highwater within1GiB')
        for name in('stdout','stderr'):
            need((actual/(name+'.bin')).stat().st_size<=LIMITS[name+'_bytes'],'complete bounded worker '+name)
        total=sum(f.stat().st_size for f in actual.iterdir()if f.is_file())
        need(total+9437184<=134217728,'all physical files plus outer9MiB reserves')
        checked(plan['python'],67108864)
        for pin in plan['sources'].values():checked(pin)
        checked(plan['declaration']);checked(plan['runtime_closure']);checked(declaration['harness_declaration'])
        for pin in closure['stdlib_files']:checked(pin)
        for item in plan['inputs']:checked(item['pin'],134217728)
        need(NOW()<overall,'later custody/resource checks before210')
        custody_completed=NOW()
        result['post_child_raw_custody']=dict(checked=True,completed_ns=custody_completed,
            completed_before_deadline=custody_completed<overall,scope='positive complete raw closure')
        need(cleanup['diagnostics_incomplete']is False,'complete bounded log/cleanup observations')
        result.update(worker_receipt=descriptor(wp,wraw),result=w['result'],outputs=w['outputs'],
            physical_before_runner_receipt=total,conservative_physical_bytes=total+9437184,
            logical_result_bytes=w['logical_result_bytes'],worker_peak_bytes=usage.ru_maxrss,
            memory_scope='Standalone worker peak only; no Native, not full production sum or fit.',
            resource_candidate_accepted=True,finite_helper_candidate=True)
        accepted=True
    except BaseException as error:
        primary_error=error;accepted=False
        try:
            info=information(error);result['primary_failure']=info;result['errors'].append(info)
        except BaseException as collection_error:
            try:cleanup['diagnostics_incomplete']=True
            except BaseException:pass
            note('primary_diagnostic','ERROR',collection_error)
        if process is not None:
            try:cleanup_child()
            except BaseException as error:
                # Non-OS infrastructure/metadata failure remains a failed closure.
                note('cleanup_infrastructure','ERROR',error)
        result['resource_candidate_accepted']=False;result['finite_helper_candidate']=False
    finally:
        def finalize_result():
            nonlocal accepted,receipt_written,primary_error
            def finalization_error(operation,error):
                nonlocal accepted,primary_error
                accepted=False
                if primary_error is None:primary_error=error
                try:
                    result['resource_candidate_accepted']=False;result['finite_helper_candidate']=False
                    if result['primary_failure']is None:result['primary_failure']=information(primary_error)
                    result['finalization_errors'].append(dict(operation=operation,error=information(error),
                                                              observed_ns=NOW()))
                except BaseException as collection_error:
                    try:cleanup['diagnostics_incomplete']=True
                    except BaseException:pass
                    note('finalization_diagnostic','ERROR',collection_error)
            try:close_logs(True)
            except BaseException as error:finalization_error('close_logs',error)
            try:
                result['worker_reaped']=reaped
                if reaped:
                    result['worker_exit_code']=process.returncode;result['worker_wait4_status']=status
                    result['worker_wait4_usage']={k:getattr(usage,k)for k in('ru_utime','ru_stime','ru_maxrss','ru_minflt','ru_majflt')}
                result['closed_ns']=NOW()
            except BaseException as error:finalization_error('record_wait4_and_close_time',error)
            # A negative trial needs its own complete, same-window raw-custody checks.
            if not accepted and process is not None and reaped and result['owned_group_absent']and not group_reappeared:
                try:
                    need(NOW()<overall,'negative raw custody begins before210')
                    pins=[(plan['python'],67108864)]+[(v,16777216)for v in plan['sources'].values()]
                    pins.extend((v,16777216)for v in(plan['declaration'],plan['runtime_closure'],declaration['harness_declaration']))
                    pins.extend((v,16777216)for v in closure['stdlib_files'])
                    pins.extend((v['pin'],134217728)for v in plan['inputs'])
                    for pin,cap in pins:
                        need(NOW()<overall,'negative raw custody work before210');checked(pin,cap)
                        need(NOW()<overall,'negative whole preimage read before210')
                    custody_completed=NOW()
                    result['post_child_raw_custody']=dict(checked=True,completed_ns=custody_completed,
                        completed_before_deadline=custody_completed<overall,scope='negative complete raw closure')
                except BaseException as error:finalization_error('negative_raw_custody',error)
            stable=reaped and result['owned_group_absent']and not group_reappeared
            if stable:
                all_logs=True
                for name in('stdout','stderr'):
                    try:
                        need(NOW()<overall,'whole stable logs read before210')
                        f=actual/(name+'.bin')
                        need(f.is_file(),'whole stable log exists')
                        need(f.stat().st_size<=LIMITS[name+'_bytes'],'bounded final whole '+name)
                        result[name]=descriptor(f,f.read_bytes())
                        need(NOW()<overall,'whole stable log read completed before210')
                    except BaseException as error:
                        all_logs=False;finalization_error('whole_log_'+name,error)
                log_completed=NOW()
                result['whole_log_custody']=dict(stable=True,complete=all_logs,completed_ns=log_completed,
                    completed_before_deadline=all_logs and log_completed<overall,
                    scope='known wait4 exit and owned group absence; parent close is separate')
            else:
                result['whole_log_custody']=dict(stable=False,complete=False,
                    reason='worker/group closure unavailable; no whole stable descriptors claimed')
                for name in('stdout','stderr'):
                    try:
                        f=actual/(name+'.bin')
                        if f.exists():result[name+'_provisional_stat']=dict(bytes=f.stat().st_size,stable=False,complete=False)
                    except BaseException as error:finalization_error('provisional_log_stat_'+name,error)
            try:
                need(NOW()<overall,'final physical ledger before210')
                total=sum(f.stat().st_size for f in actual.iterdir()if f.is_file())
                ledger_completed=NOW()
                result['final_physical_ledger']=dict(enumeration_complete=True,before_receipt_bytes=total,
                    conservative_bytes=total+9437184,within_original_cap=total+9437184<=134217728,
                    completed_ns=ledger_completed,completed_before_deadline=ledger_completed<overall,
                    stable_writer_quiescence=stable)
            except BaseException as error:finalization_error('final_physical_ledger',error)
            try:
                save_new(actual/'runner-receipt.json',result);receipt_written=True
            except BaseException as error:
                finalization_error('save_runner_receipt',error)
                # No O_EXCL retry/overwrite. External observer owns missing-receipt failure.
                try:
                    sys.stderr.write(json.dumps(dict(schema='direct-projection-runner-finalization-failure-v1',
                        primary=information(primary_error)if primary_error is not None else None,
                        finalization=information(error)),sort_keys=True)+'\n');sys.stderr.flush()
                except BaseException:pass
            if NOW()>=overall:
                accepted=False
                try:save_new(actual/'POST_RECEIPT_DEADLINE_FAILURE.json',dict(admitted=False))
                except BaseException:pass
        try:finalize_result()
        except BaseException as error:
            accepted=False
            if primary_error is None:primary_error=error
            try:
                result['resource_candidate_accepted']=False;result['finite_helper_candidate']=False
                sys.stderr.write(json.dumps(dict(schema='direct-projection-runner-finalization-failure-v1',
                    primary=information(primary_error),finalization=information(error)),
                    sort_keys=True)+'\n');sys.stderr.flush()
            except BaseException:pass
    try:
        print(json.dumps(dict(actual=str(actual),resource_candidate_accepted=result['resource_candidate_accepted'],
                             finite_helper_candidate=result['finite_helper_candidate'])))
    except BaseException as error:
        accepted=False
        if primary_error is None:primary_error=error
        try:
            sys.stderr.write(json.dumps(dict(schema='direct-projection-runner-output-failure-v1',
                primary=information(primary_error),output=information(error)),sort_keys=True)+'\n')
        except BaseException:pass
    return 0 if accepted and receipt_written and NOW()<overall else 2


if __name__=='__main__':
    need(len(sys.argv)==2,'one reviewed once-plan path');raise SystemExit(main(sys.argv[1]))
