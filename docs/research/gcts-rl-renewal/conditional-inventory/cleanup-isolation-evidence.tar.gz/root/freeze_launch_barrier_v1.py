"""Raw-only launch barrier: does not call any reviewed scientific component."""
from pathlib import Path
import hashlib,json,os,sys
D=Path('/private/tmp/gcts-cleanup-isolation-ROOT-20261019')
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def main(delta,inspector_review,agents):
 dr=json.loads(Path(delta).read_bytes());ir=json.loads(Path(inspector_review).read_bytes());ag=json.loads(Path(agents).read_bytes())
 assert dr['final_grant_delta_review_passed']is True
 assert ir['source_review_passed']is True
 assert ag['all_peer_tools_stopped']is True
 adoption=D/'ROOT-scope-adoption-and-grants-cleanup-isolation-v1.json';a=json.loads(adoption.read_bytes())
 assert len(a['issued'])==8
 subjects=[]
 for row in a['issued']:
  assert pin(row['plan']['path'])==row['plan'];assert pin(row['authorization']['path'])==row['authorization']
  p=json.loads(Path(row['plan']['path']).read_bytes());assert not os.path.lexists(p['actual_directory'])
  pp=Path(row['plan']['path']);assert not os.path.lexists(pp.parent/(pp.stem+'-terminal-observation'))
  for d in p['sources'].values():assert pin(d['path'])==d
  for d in [p['python'],p['runtime_closure'],p['declaration']]:assert pin(d['path'])==d
  for item in p['inputs']:assert pin(item['pin']['path'])==item['pin']
  subjects.append(row)
 out=dict(schema='ROOT-cleanup-isolation-launch-barrier-v1',author_identity='/root',reviewed_delta=pin(delta),inspector_review=pin(inspector_review),peer_stop_snapshot=pin(agents),adoption=pin(adoption),subjects=subjects,barrier_passed=True,actuals_launched=0,scientific_calls=0,scope='Only Root may launch these8serial bounded subjects; no parallel peer tools during an owned actual. All earlier failed cohorts remain retired.')
 target=D/'ROOT-launch-barrier-v1.json'
 with target.open('x')as f:json.dump(out,f,indent=2,sort_keys=True);f.write('\n')
 print(json.dumps(pin(target),sort_keys=True))
if __name__=='__main__':
 assert len(sys.argv)==4
 main(*sys.argv[1:])
