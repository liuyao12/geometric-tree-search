"""Passive raw pins and authored JSON validation; no subject/sizing operations."""
from pathlib import Path
import hashlib
import json
import sys

O=Path(__file__).resolve().parent
D=O.parent
def pin(path):
    digest=hashlib.sha256();size=0
    with path.open('rb')as stream:
        while True:
            raw=stream.read(1048576)
            if not raw:break
            digest.update(raw);size+=len(raw)
    return dict(path=str(path.resolve()),bytes=size,sha256=digest.hexdigest())

note=O/'next-evidence-design-v1.json'
json.loads(note.read_bytes())  # Authored literal JSON syntax only.
partial_paths=[D/'root/actual-batch-v2/canonical-implicit-palette-calibration.json.partial',
               D/'root/actual-batch-v2/failed-prefix.json.partial',
               D/'recovered/ROOT/actual-implicit-v2/failed-prefix.json.partial']
partial_pins=[pin(path)for path in partial_paths]  # Raw hash/length only; no parser.
failure=D/'root/actual-batch-v2/worker-failure.json'
saved=json.loads(failure.read_bytes())  # Complete ordinary failure metadata permitted.
observation={key:saved[key]for key in('schema','stage','status','first_available_fault',
    'outputs','early_failure_summary','prefix_retention_error','no_failed_prefix_admission')}
record=dict(schema='Source-only-output-design-handoff-v1',author='/root/recovered_batch_integration',
    status='UNIMPLEMENTED_UNEXECUTED_NOT_GRANTED',design=pin(note),
    frozen_worker=pin(D/'root/qualify_complete_batch_worker_v2.py'),
    frozen_component=pin(D/'components-B/implicit_wang_batch_v2.py'),
    current_master=pin(D/'publisher/docs/basic-tiling-algorithm.md'),
    original_bank=pin(D/'recovered/ROOT/implicit-inputs-v1.json'),
    saved_failure=pin(failure),saved_failure_metadata=observation,
    consumed_files=[pin(D/'root/actual-batch-v2/CONSUMED.json'),
                    pin(D/'root/actual-batch-v2/WORKER_CONSUMED.json')],
    raw_only_partial_pins=partial_pins,partial_parse_calls=0,
    python=pin(Path(sys.executable)),python_version=sys.version,
    author_metadata_script=pin(Path(__file__)),subject_imports=0,subject_calls=0,
    semantic_sizing_calls=0,compiler_calls=0,checker_calls=0,fixture_calls=0,actual_launches=0,
    implementation_authorized=False,subject_execution_authorized=False,
    fitting_bound_proved=False,mathematical_authority=False)
out=O/'handoff-v1.json'
assert not out.exists()
out.write_text(json.dumps(record,indent=2,ensure_ascii=True)+'\n')
print(json.dumps(pin(out),indent=2))
