"""Source-only exact implicit palette; no top-level subject invocation.

All legacy tiles remain represented. Queries visit transition records and
constant-size Cartesian families, never the cell/triple/tile product.
"""
VERSION = 'implicit-wang-palette-v2'
DESCRIPTOR_SCHEMA = 'implicit-wang-palette-v1'
LIMIT_KEYS = ('work', 'symbols', 'states', 'transitions', 'integer_bits',
              'data_items', 'data_depth', 'string_chars')
MACHINE_KEYS = ('alphabet_size', 'state_count', 'blank', 'initial', 'accepting', 'transitions')
_OWNER = object()
WALL = ('wall',)


class Invalid(Exception):
    def __init__(self, reason, *, _owner=None):
        self.reason = reason
        self._owner = _owner
        super().__init__(reason)


class Limit(Exception):
    def __init__(self, reason, attempted_work, *, _owner=None):
        self.reason = reason
        self.attempted_work = attempted_work
        self._owner = _owner
        super().__init__(reason)


def is_own_invalid(error):
    return type(error) is Invalid and error._owner is _OWNER


def is_own_limit(error):
    return type(error) is Limit and error._owner is _OWNER


def _bad(reason):
    return Invalid(reason, _owner=_OWNER)


class _Work:
    def __init__(self, check, limits):
        if not callable(check):
            raise _bad('callable check required')
        if (type(limits) is not dict or len(limits) != len(LIMIT_KEYS)
                or any(type(k) is not str or k not in LIMIT_KEYS for k in limits)):
            raise _bad('exact limit keys required')
        owned = {}
        for key in LIMIT_KEYS:
            value = limits[key]
            if type(value) is not int or value <= 0:
                raise _bad('positive exact-int limits required')
            owned[key] = value
        self.limits = owned
        self.check = check
        self.work = 0
        self.items = 0
        self.tick()
        self.number(0)
        self.number(1)
        self.number(-1)

    def tick(self):
        self.work += 1
        if self.work > self.limits['work']:
            raise Limit('work', self.work, _owner=_OWNER)
        self.check()

    def bound(self, key, number):
        self.tick()
        if number > self.limits[key]:
            raise Limit(key, self.work, _owner=_OWNER)

    def number(self, value):
        self.tick()
        if type(value) is not int:
            raise _bad('exact int required; bool is distinct and invalid')
        if value.bit_length() > self.limits['integer_bits']:
            raise Limit('integer_bits', self.work, _owner=_OWNER)
        return value

    def item(self):
        self.items += 1
        self.bound('data_items', self.items)

    def tree(self, value, *, masks=False):
        # Immutable trees only. None is admitted only by _masks at outer slots.
        stack = [(value, 0)]
        while stack:
            item, depth = stack.pop()
            self.item()
            self.bound('data_depth', depth)
            kind = type(item)
            if kind is int:
                self.number(item)
            elif kind is str:
                self.bound('string_chars', len(item))
            elif kind is tuple:
                if masks and (not item or type(item[0]) is not str):
                    raise _bad('assigned tuple color requires a string tag')
                self.bound('data_items', self.items + len(item))
                for index in range(len(item) - 1, -1, -1):
                    self.tick()
                    stack.append((item[index], depth + 1))
            else:
                raise _bad('immutable exact tuple/string/int tree required')


def _run(check, limits, operation):
    work = None
    try:
        work = _Work(check, limits)
        result = operation(work)
        work.tick()  # last callback before returning owned data
        return result, work.work
    except BaseException as error:
        # Attachment only; preserve the exact primary object, including foreign
        # StopIteration/KeyboardInterrupt and exceptions of our public classes.
        try:
            error.implicit_palette_prefix = {
                'schema': 'implicit-wang-query-failure-prefix-v1',
                'attempted_work': None if work is None else work.work,
                'data_items': None if work is None else work.items,
                'authority': False}
        except BaseException:
            pass
        raise


def _int(value, low, high, work):
    work.number(value)
    if not low <= value < high:
        raise _bad('integer outside declared range')
    return value


def _sorted_rows(rows, work):
    # Explicit charged stable merge sort; O(D log D), no hidden subject calls.
    source = rows
    width = 1
    while width < len(source):
        target = []
        start = 0
        while start < len(source):
            left, middle = start, min(start + width, len(source))
            right, end = middle, min(start + 2 * width, len(source))
            while left < middle or right < end:
                work.tick()
                if right >= end or (left < middle and source[left][:2] <= source[right][:2]):
                    target.append(source[left])
                    left += 1
                else:
                    target.append(source[right])
                    right += 1
            start = end
        source = target
        width *= 2
    return tuple(source)


def _machine_record(value, work):
    if (type(value) is not dict or len(value) != 6
            or any(type(k) is not str or k not in MACHINE_KEYS for k in value)):
        raise _bad('exact machine record required')
    b = value['alphabet_size']
    q = value['state_count']
    work.number(b)
    work.number(q)
    if b < 1 or q < 1:
        raise _bad('positive alphabet and state counts required')
    work.bound('symbols', b)
    work.bound('states', q)
    blank = _int(value['blank'], 0, b, work)
    initial = _int(value['initial'], 0, q, work)
    accepting = _int(value['accepting'], 0, q, work)
    if initial == accepting:
        raise _bad('selector profile requires initial != accepting')
    raw = value['transitions']
    if type(raw) is not list:
        raise _bad('transition list required')
    work.bound('transitions', len(raw))
    work.bound('data_items', work.items + 6 * len(raw) + 6)
    rows = []
    seen = set()
    for row in raw:
        work.item()
        if type(row) is not list or len(row) != 5:
            raise _bad('five-field transition list required')
        a = _int(row[0], 0, q, work)
        read = _int(row[1], 0, b, work)
        nxt = _int(row[2], 0, q, work)
        write = _int(row[3], 0, b, work)
        move = _int(row[4], -1, 2, work)
        for unused in range(5):
            work.item()
        if a == accepting or (a, read) in seen:
            raise _bad('accepting transition or duplicate transition domain')
        seen.add((a, read))
        rows.append((a, read, nxt, write, move))
    return b, q, blank, initial, accepting, _sorted_rows(rows, work)


def _wire_record(value, machine, work):
    if (type(value) is not dict or len(value) != 3
            or any(type(k) is not str or k not in ('zero', 'one', 'terminator') for k in value)):
        raise _bad('exact wire record required')
    b, q, blank, initial, accepting, rows = machine
    copied = []
    for key in ('zero', 'one', 'terminator'):
        copied.append(_int(value[key], 0, b, work))
    result = tuple(copied)
    if len(set(result + (blank,))) != 4:
        raise _bad('wire symbols and blank must be four distinct symbols')
    return result


def _descriptor(value, work):
    if type(value) is not tuple or len(value) != 3 or value[0] != DESCRIPTOR_SCHEMA:
        raise _bad('owned immutable descriptor required')
    work.tree(value)
    machine, wire = value[1], value[2]
    if type(machine) is not tuple or len(machine) != 6 or type(wire) is not tuple or len(wire) != 3:
        raise _bad('descriptor machine/wire shape')
    b, q, blank, initial, accepting, rows = machine
    if type(rows) is not tuple:
        raise _bad('immutable transition tuple required')
    work.number(b)
    work.number(q)
    if b < 1 or q < 1:
        raise _bad('positive machine bounds required')
    work.bound('symbols', b)
    work.bound('states', q)
    for item, cap in ((blank, b), (initial, q), (accepting, q)):
        _int(item, 0, cap, work)
    if initial == accepting:
        raise _bad('initial equals accepting')
    work.bound('transitions', len(rows))
    prior = None
    for row in rows:
        work.tick()
        if type(row) is not tuple or len(row) != 5:
            raise _bad('immutable transition row required')
        a, read, nxt, write, move = row
        _int(a, 0, q, work)
        _int(read, 0, b, work)
        _int(nxt, 0, q, work)
        _int(write, 0, b, work)
        _int(move, -1, 2, work)
        if a == accepting or (prior is not None and prior >= (a, read)):
            raise _bad('noncanonical or accepting transition')
        prior = (a, read)
    for symbol in wire:
        _int(symbol, 0, b, work)
    if len(set(wire + (blank,))) != 4:
        raise _bad('wire collision')
    work.number(b * (q + 1))
    return machine, wire


def _masks(value, work):
    if type(value) is not tuple or len(value) != 4:
        raise _bad('NESW exact four-tuple mask required')
    for color in value:
        work.tick()
        if color is not None:
            work.tree(color, masks=True)
    return value


class _Ref:
    __slots__ = ('index',)
    def __init__(self, index):
        self.index = index


def _size(domain, b, q, work):
    kind, parameter = domain
    if kind == 'range':
        size = parameter
    elif kind == 'plain_wall':
        size = b + int(parameter)
    elif kind == 'cell':
        size = b * (q + 1)
    elif kind == 'enum':
        size = len(parameter)
    else:
        raise _bad('internal domain')
    return work.number(size)


def _rank(domain, value, b, q, work):
    work.tick()
    kind, parameter = domain
    if kind == 'range':
        return value if type(value) is int and 0 <= value < parameter else None
    if kind == 'enum':
        for index in range(len(parameter)):
            work.tick()
            if type(value) is type(parameter[index]) and value == parameter[index]:
                return index
        return None
    if kind == 'plain_wall':
        if value == WALL and type(value) is tuple and parameter:
            return b
        if type(value) is tuple and len(value) == 2 and value[0] == 'plain' and type(value[1]) is int and 0 <= value[1] < b:
            return value[1]
        return None
    if kind == 'cell':
        if type(value) is tuple and len(value) == 2 and value[0] == 'plain' and type(value[1]) is int and 0 <= value[1] < b:
            return value[1]
        if (type(value) is tuple and len(value) == 3 and value[0] == 'head'
                and type(value[1]) is int and 0 <= value[1] < q
                and type(value[2]) is int and 0 <= value[2] < b):
            return b + value[1] * b + value[2]
        return None
    raise _bad('internal rank domain')


def _unrank(domain, rank, b, q, work):
    work.tick()
    kind, parameter = domain
    if kind == 'range':
        return rank
    if kind == 'enum':
        return parameter[rank]
    if kind == 'plain_wall':
        return WALL if rank == b else ('plain', rank)
    if kind == 'cell':
        return ('plain', rank) if rank < b else ('head', (rank - b) // b, (rank - b) % b)
    raise _bad('internal unrank domain')


def _intersect(expressions, masks, domains, b, q, work):
    fixed = [None] * len(domains)
    stack = []
    for index in range(4):
        work.tick()
        if masks[index] is not None:
            stack.append((expressions[index], masks[index]))
    while stack:
        pattern, value = stack.pop()
        work.tick()
        if type(pattern) is _Ref:
            rank = _rank(domains[pattern.index], value, b, q, work)
            if rank is None or (fixed[pattern.index] is not None and fixed[pattern.index] != rank):
                return None
            fixed[pattern.index] = rank
        elif type(pattern) is tuple:
            if type(value) is not tuple or len(pattern) != len(value):
                return None
            for index in range(len(pattern)):
                work.tick()
                stack.append((pattern[index], value[index]))
        elif type(pattern) is not type(value) or pattern != value:
            return None
    return fixed


def _fill(expression, values, work):
    # Pattern depth is a fixed implementation constant (< 5), independent of
    # caller data_depth. Caller trees themselves are validated iteratively.
    work.tick()
    if type(expression) is _Ref:
        return values[expression.index]
    if type(expression) is tuple:
        copied = []
        for item in expression:
            copied.append(_fill(item, values, work))
        return tuple(copied)
    return expression


def _families(machine, wire, visit, work):
    b, q, blank, initial, accepting, rows = machine
    symbol = ('range', b)
    flag = ('range', 2)
    pw = ('plain_wall', True)
    cell = ('cell', None)
    v0, v1, v2 = _Ref(0), _Ref(1), _Ref(2)
    def step(domains, left, center, right, output):
        visit('step', (left, center, right),
              (('cell', center), ('pair', center, right), ('cell', output), ('pair', left, center)), domains)
    # Disjoint by number/location of heads. No accepting/undefined head row is
    # manufactured: every head-containing family is indexed by a defined row.
    step((pw, symbol, pw), v0, ('plain', v1), v2, ('plain', v1))
    for a, read, nxt, write, move in rows:
        work.tick()
        head = ('head', a, read)
        left_output = ('head', nxt, v0) if move == 1 else ('plain', v0)
        step((symbol, pw), head, ('plain', v0), v1, left_output)
        center_output = ('head', nxt, write) if move == 0 else ('plain', write)
        step((('plain_wall', move != -1), ('plain_wall', move != 1)), v0, head, v1, center_output)
        right_output = ('head', nxt, v1) if move == -1 else ('plain', v1)
        step((pw, symbol), v0, ('plain', v1), head, right_output)
    visit('collect_plain', (v0, v1), (('cell', ('plain', v0)), ('seen', v1), ('stop',), ('seen', v1)), (symbol, flag))
    visit('collect_accept', (accepting, v0), (('cell', ('head', accepting, v0)), ('seen', 1), ('stop',), ('seen', 0)), (symbol,))
    visit('left_step_frame', (v0,), (('side', 'left', 'run'), ('pair', WALL, v0), ('side', 'left', 'run'), ('exterior', 'left')), (cell,))
    visit('right_step_frame', (v0,), (('side', 'right', 'run'), ('exterior', 'right'), ('side', 'right', 'run'), ('pair', v0, WALL)), (cell,))
    visit('left_accept_frame', (), (('side', 'left', 'run'), ('seen', 0), ('side', 'left', 'done'), ('exterior', 'left')), ())
    visit('right_accept_frame', (), (('side', 'right', 'run'), ('exterior', 'right'), ('side', 'right', 'done'), ('seen', 1)), ())
    for before, after in (('PRE', 'PRE'), ('PAD', 'POST'), ('POST', 'POST')):
        work.tick()
        visit('init_fixed_plain', (before, after, v0, v1), (('init_north', 'plain', v0), ('init_horizontal', after, v1), ('cell', ('plain', v0)), ('init_horizontal', before, v1)), (symbol, flag))
        visit('init_fixed_head', (before, after, v0), (('init_north', 'head', initial, v0), ('init_horizontal', after, 1), ('cell', ('head', initial, v0)), ('init_horizontal', before, 0)), (symbol,))
    for before in ('PRE', 'ACTIVE'):
        work.tick()
        visit('init_free_bit', (before, v0, v1), (('init_north', 'free'), ('init_horizontal', 'ACTIVE', v1), ('cell', ('plain', v0)), ('init_horizontal', before, v1)), (('enum', wire[:2]), flag))
        visit('init_free_terminator', (before, v0), (('init_north', 'free'), ('init_horizontal', 'PAD', v0), ('cell', ('plain', wire[2])), ('init_horizontal', before, v0)), (flag,))
    visit('init_free_padding', (v0,), (('init_north', 'free'), ('init_horizontal', 'PAD', v0), ('cell', ('plain', blank)), ('init_horizontal', 'PAD', v0)), (flag,))
    visit('init_left_frame', (), (('init_north', 'frame', 'left'), ('init_horizontal', 'PRE', 0), ('side', 'left', 'run'), ('exterior', 'left')), ())
    visit('init_right_frame', (), (('init_north', 'frame', 'right'), ('exterior', 'right'), ('side', 'right', 'run'), ('init_horizontal', 'POST', 1)), ())


def _query(descriptor, masks, index, select_mode, work):
    machine, wire = _descriptor(descriptor, work)
    masks = _masks(masks, work)
    if select_mode:
        work.number(index)
        if index < 0:
            raise _bad('negative selection index')
    b, q = machine[:2]
    total = 0
    selected = None
    def visit(kind, origin, edges, domains):
        nonlocal total, selected
        work.tick()
        fixed = _intersect(edges, masks, domains, b, q, work)
        if fixed is None:
            return
        sizes = []
        amount = 1
        for position in range(len(domains)):
            work.tick()
            size = _size(domains[position], b, q, work) if fixed[position] is None else 1
            sizes.append(size)
            amount = work.number(amount * size)
        next_total = work.number(total + amount)
        if select_mode and selected is None and total <= index < next_total:
            rank = index - total
            ranks = [0] * len(domains)
            for position in range(len(domains) - 1, -1, -1):
                work.tick()
                rank, digit = divmod(rank, sizes[position])
                ranks[position] = fixed[position] if fixed[position] is not None else digit
            values = [_unrank(domains[p], ranks[p], b, q, work) for p in range(len(domains))]
            detail = _fill(origin, values, work)
            colors = _fill(edges, values, work)
            selected = dict(id=(kind, detail), kind=kind, origin=detail, edges_NESW=colors,
                            t=[[[0, 0], 1]],
                            m=[[[0, -1], 'edge', colors[0]], [[1, 0], 'edge', colors[1]],
                               [[0, 1], 'edge', colors[2]], [[-1, 0], 'edge', colors[3]]])
            work.tree((kind, detail, colors))
            # Fixed t/m row/list scaffolding and generated numeric atoms.
            for unused in range(34):
                work.item()
            work.number(-1)
            work.number(0)
            work.number(1)
        total = next_total
    _families(machine, wire, visit, work)
    if select_mode and selected is None:
        raise _bad('selection index outside exact matching domain')
    return total, selected


def build_palette_query(machine, wire, *, check, limits):
    def operation(work):
        owned = _machine_record(machine, work)
        fixed_wire = _wire_record(wire, owned, work)
        descriptor = (DESCRIPTOR_SCHEMA, owned, fixed_wire)
        _descriptor(descriptor, work)
        if _machine_record(machine, work) != owned or _wire_record(wire, owned, work) != fixed_wire:
            raise _bad('input changed during build')
        return descriptor
    descriptor, cost = _run(check, limits, operation)
    return dict(schema='implicit-wang-build-receipt-v1', descriptor=descriptor, attempted_work=cost,
                authority=False, executed_source_qualified=False)


def build_palette(machine, wire, *, check, limits):
    return build_palette_query(machine, wire, check=check, limits=limits)['descriptor']


def count_query(descriptor, masks, *, check, limits):
    result, cost = _run(check, limits, lambda work: _query(descriptor, masks, None, False, work))
    return dict(schema='implicit-wang-count-receipt-v1', count=result[0], attempted_work=cost, authority=False)


def select_query(descriptor, masks, index, *, check, limits):
    result, cost = _run(check, limits, lambda work: _query(descriptor, masks, index, True, work))
    return dict(schema='implicit-wang-select-receipt-v1', count=result[0], tile=result[1], attempted_work=cost, authority=False)


def count(descriptor, masks, *, check, limits):
    return count_query(descriptor, masks, check=check, limits=limits)['count']


def select(descriptor, masks, index, *, check, limits):
    return select_query(descriptor, masks, index, check=check, limits=limits)['tile']


def describe(descriptor, *, check, limits):
    def operation(work):
        machine, wire = _descriptor(descriptor, work)
        b, q, blank, initial, accepting, rows = machine
        stationary = 0
        for row in rows:
            work.tick()
            stationary += int(row[4] == 0)
        d = len(rows)
        a = work.number(b * (q + 1))
        step = work.number(b * (b + 1) * (b + 1) + 3 * d * b * (b + 1) + stationary * (b + 1))
        base = work.number(step + 3 * b + 2 * a + 2)
        selector = work.number(9 * b + 16)
        total = work.number(base + selector)
        return dict(schema='implicit-wang-description-v1', version=VERSION, descriptor_schema=DESCRIPTOR_SCHEMA,
                    alphabet=b, states=q, defined_transitions=d, stationary_transitions=stationary,
                    cell_alphabet=a, step_tiles=step, base_tiles=base, initializer_tiles=selector,
                    total_tiles=total, tile_identity='(kind, origin_tuple)', edge_order='NESW',
                    transformations='translations_only_2Z2', cache=False,
                    status='SOURCE_ONLY_CANDIDATE', authority=False,
                    executed_source_qualified=False, full_physical_VM_qualified=False)
    result, cost = _run(check, limits, operation)
    result['attempted_work'] = cost
    return result


def export_descriptor(descriptor, *, check, limits):
    def operation(work):
        machine, wire = _descriptor(descriptor, work)
        b, q, blank, initial, accepting, rows = machine
        copied = []
        for row in rows:
            work.tick()
            copied.append(list(row))
            for unused in range(6):
                work.item()
        return dict(schema='implicit-wang-palette-recipe-v1', version=VERSION,
                    machine=dict(alphabet_size=b, state_count=q, blank=blank, initial=initial,
                                 accepting=accepting, transitions=copied),
                    wire=dict(zero=wire[0], one=wire[1], terminator=wire[2]),
                    descriptor_schema=DESCRIPTOR_SCHEMA,
                    transformations='translations_only_2Z2', edge_order='NESW',
                    semantic_identity='kind_and_origin', authority=False)
    result, cost = _run(check, limits, operation)
    return dict(schema='implicit-wang-export-receipt-v1', recipe=result, attempted_work=cost, authority=False)
