"""Saved ordinary JSON/raw-byte audit only. The partial JSON is never parsed."""
import hashlib
import json
from pathlib import Path
C=Path('/private/tmp/gcts-implicit-review-C-20261020-v1')
D=Path('/private/tmp/gcts-implicit-ROOT-20261020-v1')
A=D/'actual-implicit-v2';O=D/'implicit-plan-authorized-v2-terminal-observation'
checks=[]
def pin(p):
    p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def ck(k,v,e=None):
    checks.append({'id':k,'passed':bool(v),'evidence':e});assert v,k
def raw(d):
    b=Path(d['path']).read_bytes();ck('raw:'+d['path'],pin(d['path'])==d,d);return b
def obj(d):return json.loads(raw(d))
def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()

planpin={'path':str(D/'implicit-plan-authorized-v2.json'),'bytes':3089,'sha256':'df6ceb94019c9520af7b9ff2d65dc85880d883c2848f119f105e0eb84ca16317'}
runnerpin={'path':str(A/'runner-receipt.json'),'bytes':5635,'sha256':'4cd2ff55b81d2c0488da788edf2d5cd6a73136a39526fbc5d2e978b7ab2365e4'}
terminalpin={'path':str(O/'terminal.json'),'bytes':1608,'sha256':'e5ef20aaa8a449aca991e7034a015d9d3bd586576027a1bd81d0f8e9e52ad9ce'}
retirepin=pin(D/'ROOT-grant-retirement-v2.json')
plan=obj(planpin);r=obj(runnerpin);t=obj(terminalpin);ret=obj(retirepin)
grant=obj(plan['authorization']);review=obj(grant['review'])
deltapin={'path':str(C/'typed-final-grant-delta-review-v2.json'),'bytes':27075,'sha256':'7dad06d4a9d52c760256de1dd1511bacb8444deb40ab6d50d8879139ab8e06ef'}
delta=obj(deltapin);decl=obj(plan['declaration']);closure=obj(plan['runtime_closure'])
ck('current_exact_review',grant['review']['sha256']=='c3be3652e2b75a49239b096c8728cedf796100b74ec194b19db405c63b821672'and review['review_passed']is True)
subject={k:v for k,v in plan.items()if k!='authorization'}
sha=hashlib.sha256(canon(subject)).hexdigest()
ck('all_subject_bindings',sha==review['subject_sha256']==grant['subject_sha256']==r['subject_sha256']==delta['subject_sha256']=='f7200a04eac8186ef00875982019c318bde68d30b17062cc1ee360fbc099a499'and subject==review['subject']==delta['subject'])
ck('one_Root_grant',grant['actual_execution_authorized']is True and grant['author_identity']=='/root'and type(grant['maximum_actual_invocations'])is int and grant['maximum_actual_invocations']==1)
ck('exact_plan_receipts',r['plan']==t['plan']==planpin and r['authorization']==plan['authorization'])
ck('exact_source_scope',plan['sources']==review['sources']==closure['sources'])
for d in plan['sources'].values():raw(d)
raw(plan['python'])
for d in closure['stdlib_files']:raw(d)
for d in plan['inputs']:raw(d['pin'])
raw(review['current_master'])
ck('whole_current_declaration_runtime',decl['inputs']==plan['inputs']and closure['declaration']==plan['declaration']and closure['python']==plan['python'])
ck('original_limits_current',r['limits']==plan['limits']==decl['limits'])
ck('full_bank_not_trimmed',decl['exact_cases']==15 and len(decl['diagnostics'])==33 and len(plan['inputs'])==1)

actual_pins=[pin(p)for p in sorted(A.iterdir())if p.is_file()]
observer_pins=[pin(p)for p in sorted(O.iterdir())if p.is_file()]
ck('exact_actual_six_files',{Path(x['path']).name for x in actual_pins}=={'CONSUMED.json','WORKER_CONSUMED.json','failed-prefix.json.partial','runner-receipt.json','stdout.bin','stderr.bin'})
ck('exact_observer_four_files',{Path(x['path']).name for x in observer_pins}=={'CONSUMED.json','stdout.bin','stderr.bin','terminal.json'})
ck('no_symlinked_saved_leafs',all(not Path(x['path']).is_symlink()for x in actual_pins+observer_pins))
ck('retirement_all_actual_pin_inventory',ret['retained_files']==actual_pins)
for d in ret['retained_files']:raw(d)
c=obj(r['consumed_marker']);wc=json.loads((A/'WORKER_CONSUMED.json').read_bytes());oc=json.loads((O/'CONSUMED.json').read_bytes())
ck('consumed_bindings',c['plan']==wc['plan']==oc['plan']==planpin and c['subject_sha256']==sha and c['invocation_id']==r['invocation_id']==plan['invocation_id'])
ck('one_worker_marker',c['maximum_worker_launches']==1 and c['consumed_before_Popen']is True and wc['maximum_invocations']==1 and r['worker_launch_attempts']==1)
ck('one_runner_marker',oc['maximum_runner_launches']==1 and oc['observer_started_ns']==t['observer_started_ns'])
ck('pid_parent_joins',wc['pid']==r['worker_pid']==r['owned_pgid']==21847 and wc['ppid']==t['runner_pid']==21846)
began=r['began_ns'];work=r['work_deadline_ns'];overall=r['overall_deadline_ns']
ck('original_epoch_limits',c['began_ns']==began and c['work_deadline_ns']==work==began+180000000000 and c['overall_deadline_ns']==overall==began+210000000000)
ck('entry_after_epoch',t['observer_started_ns']<began<wc['worker_entry_ns']<work)
ck('terminal_elapsed_exact',t['terminal_observed_ns']-began==180140972541 and t['runner_clock_elapsed_seconds']==(t['terminal_observed_ns']-began)/1e9)
ck('observer_elapsed_exact',t['observed_instrument_elapsed_seconds']==(t['terminal_observed_ns']-t['observer_started_ns'])/1e9)
ck('authoritative_terminal_negative',t['runner_exit_code']==2 and t['terminal_gate_passed']is False and t['terminal_observed_ns']<overall)
ck('observer_literal_resource_false',t['ROOT_resource_accepted']is False)
ck('runner_negative_admissions',r['resource_candidate_accepted']is False and r['finite_encoding_candidate']is False and r['full_pipeline_qualified']is False and r['scientific_acceptance']is False and r['mathematical_proof_accepted']is False)
ck('parent_primary_literal',r['primary_failure']==r['errors'][0]and r['primary_failure']['type']=='ValueError'and r['primary_failure']['message']=='complete positive result/header/bytes/known-exit before180')
ck('recorded_reaped_TERM_exit',r['worker_reaped']is True and r['worker_exit_code']==-15 and r['worker_wait4_status']==15)
ck('known_worker_exit_after_180',work<r['worker_terminal_observed_ns']<overall)
ck('one_TERM_no_KILL',len(r['signals'])==1 and r['signals'][0]['signal']==15 and work<r['signals'][0]['sent_ns']<r['worker_terminal_observed_ns'])
ck('owned_closure_saved',r['owned_group_absent']is True and r['regular_logs_closed']is True)
cl=r['cleanup']
ck('cleanup_complete_no_reappearance',cl['attempted']is True and cl['completed_before_deadline']is True and cl['group_seen_absent']is True and cl['group_reappeared']is False and cl['group_state']=='ABSENT')
ck('cleanup_bounded_complete_diagnostics',cl['diagnostics_incomplete']is False and cl['dropped_events']==0 and cl['poll_cycles']<=cl['poll_limit']==2048 and len(cl['events'])<=cl['event_limit']==32 and cl['error_summaries']=={})
ck('events_monotonic',all(a['observed_ns']<=b['observed_ns']for a,b in zip(cl['events'],cl['events'][1:])))
ck('events_owned_PID',all(x['worker_pid']==r['worker_pid']for x in cl['events']))
ck('reap_and_absence_recorded',any(x['operation']=='wait4'and x['outcome']=='REAPED'for x in cl['events'])and any(x['operation']=='group_probe'and x['outcome']=='ABSENT'for x in cl['events']))
ck('cleanup_completed_before_raw_custody',r['worker_terminal_observed_ns']<=cl['completed_ns']<=cl['ended_ns']<=r['closed_ns']<=r['post_child_raw_custody']['completed_ns']<overall)
ck('closed_ns_scope_early',r['closed_ns_scope']=='Early wait4/status and parent-close snapshot; raw/log/ledger/receipt work follows. Full closure requires external terminal join.')
for name in('stdout','stderr'):
    d=r['log_close_observations'][name]
    ck('genuine_parent_log_close:'+name,d['opened']is True and d['closed']is True and d['close_attempts']==1 and d['opened_ns']<work<d['closed_ns']<=r['closed_ns'])
    raw(r[name]);ck('worker_log_empty:'+name,r[name]['bytes']==0)
ck('negative_raw_custody_complete',r['post_child_raw_custody']['checked']is True and r['post_child_raw_custody']['completed_before_deadline']is True and r['post_child_raw_custody']['scope']=='negative complete raw closure')
ck('whole_stable_log_custody',r['whole_log_custody']['stable']is True and r['whole_log_custody']['complete']is True and r['whole_log_custody']['completed_before_deadline']is True and r['whole_log_custody']['completed_ns']<overall)
ledger=r['final_physical_ledger']
before=sum(x['bytes']for x in actual_pins if Path(x['path']).name!='runner-receipt.json')
ck('full_before_receipt_ledger',ledger['enumeration_complete']is True and ledger['before_receipt_bytes']==before==49941)
ck('conservative_ledger_arithmetic',ledger['conservative_bytes']==ledger['before_receipt_bytes']+9437184==9487125 and ledger['within_original_cap']is True and ledger['conservative_bytes']<=134217728)
ck('ledger_closed_in_window',ledger['stable_writer_quiescence']is True and ledger['completed_before_deadline']is True and r['whole_log_custody']['completed_ns']<=ledger['completed_ns']<t['terminal_observed_ns']<overall)
ck('actual_postreceipt_bytes',sum(x['bytes']for x in actual_pins)==ledger['before_receipt_bytes']+runnerpin['bytes']==55576)
ck('observer_allfiles_inside_reserved_MiB',sum(x['bytes']for x in observer_pins)<=1048576)
ck('runner_metadata_inside_reserve',runnerpin['bytes']<=8388608)
ck('no_finalization_errors',r['finalization_errors']==[])
ck('known_worker_HWM',type(r['worker_wait4_usage']['ru_maxrss'])is int and r['worker_wait4_usage']['ru_maxrss']==211124224<1073741824)
ck('missing_component_counters_are_null',all(k in r and r[k]is None for k in('compiler_calls','search_calls','verifier_calls','oracle_calls')))
ck('missing_counters_not_fabricated_zero',not any(r[k]==0 for k in('compiler_calls','search_calls','verifier_calls','oracle_calls')))
missing=['canonical-implicit-palette-calibration.json','result.json','worker-receipt.json','worker-failure.json','failed-prefix.json']
ck('all_complete_artifacts_absent',all(not(A/x).exists()for x in missing),missing)
fragment=next(x for x in actual_pins if Path(x['path']).name=='failed-prefix.json.partial')
ck('fragment_exact_raw_pin',fragment['bytes']==49135 and fragment['sha256']=='7db7a42e49d472ab902f9cac77106fc1b286586aa691630ffebeb23939151407')
# Intentionally no JSON parsing, repair, brace completion, field projection or
# mathematical inference is performed on this fragment.
ck('retirement_exact_once',ret['actual_invocations']==1 and ret['remaining_invocations']==0 and ret['retired']is True and ret['repeat_authorized']is False)
ck('retirement_negative_exact',ret['grant']==plan['authorization']and ret['runner']==runnerpin and ret['terminal']==terminalpin and ret['worker_exit']==-15 and ret['runner_exit']==2 and ret['terminal_gate_passed']is False and ret['resource_qualification']is False and ret['mathematical_adoption']is False)
barrierpin=pin(D/'ROOT-all-idle-fresh-barrier-v2.json');barrier=obj(barrierpin)
adoptpin=pin(D/'ROOT-Source-scope-adoption-v2.json');adopt=obj(adoptpin)
ck('recorded_barrier_exact_binding',barrier['plan']==planpin and barrier['grant_delta']==deltapin and barrier['all_paths_absent']is True and barrier['all_raw_pins_exact']is True)
ck('adoption_antecedent_only',adopt['Source_prospective_review']==grant['review']and adopt['grant']==plan['authorization']and adopt['grant_delta']==deltapin and adopt['actual_execution_so_far']==0 and adopt['status']=='SOURCE_ONLY_CONDITIONAL_ACCEPTED')
oldretpin=pin(D/'ROOT-prospective-v1-retirement.json');oldret=obj(oldretpin)
ck('unused_V1_preserved',oldret['actual_invocations']==0 and oldret['retired_without_grant']is True and not(D/'actual-implicit-v1').exists())

outcome={
 'status':'WORK_DEADLINE_REJECTED_UNQUALIFIED','worker_launches':1,
 'runner_exit_code':2,'worker_exit_code':-15,'worker_wait4_status':15,
 'parent_primary_failure':r['primary_failure'],
 'runner_epoch_to_terminal_seconds':t['runner_clock_elapsed_seconds'],
 'observer_instrument_elapsed_seconds':t['observed_instrument_elapsed_seconds'],
 'worker_peak_bytes':r['worker_wait4_usage']['ru_maxrss'],
 'worker_peak_scope':'Recorded standalone wait4 highwater, known measurement; below numeric1GiB alone is not resource admission.',
 'saved_negative_before_receipt_bytes':ledger['before_receipt_bytes'],
 'saved_negative_conservative_physical_bytes':ledger['conservative_bytes'],
 'postreceipt_actual_raw_files_bytes':sum(x['bytes']for x in actual_pins),
 'component_call_counts':{k:None for k in('compiler_calls','search_calls','verifier_calls','oracle_calls')},
 'unavailable':['Worker original exception/cause and active stage','Completed case/query/graph/diagnostic populations','Root callback count and private component work','Canonical logical/expanded positive output bytes','Full palette/count/select/graph comparison outcomes'],
 'fragment':fragment,'fragment_handling':'Raw byte pin only; never parsed/repaired/completed/projected. No field or mathematical outcome attributed.',
 'complete_artifacts_absent':missing,
 'recorded_cleanup':{'reaped':True,'group_absent':True,'reappeared':False,'logs_closed':True,'TERM_attempts':1,'KILL_attempts':0,'negative_raw_and_log_custody_before210':True,'external_terminal_before210':True},
 'resource_qualified':False,'finite_component_qualified':False,'mathematical_proof_admitted':False,
 'full_pipeline_qualified':False,'complete_physical_VM_qualified':False,
 'remaining_invocations':0,'repeat_authorized':False
}
receipt={
 'schema':'implicit-palette-saved-actual-negative-review-v2',
 'reviewer_identity':'/root/conventional_control_review','saved_review_passed':True,
 'saved_data_only':True,'scientific_calls':0,'reviewer_component_calls':0,
 'actual_execution_authorized':False,'scientific_acceptance':False,
 'resource_qualification':False,'finite_component_qualification':False,'mathematical_proof_admitted':False,'full_pipeline_qualified':False,
 'subject':subject,'subject_sha256':sha,'plan':planpin,'grant':plan['authorization'],
 'Source_prospective_review':grant['review'],'final_grant_delta_review':deltapin,
 'runner':runnerpin,'terminal':terminalpin,'grant_retirement':retirepin,
 'Root_barrier':barrierpin,'Root_Source_adoption':adoptpin,'unused_V1_retirement':oldretpin,
 'current_source_pins':plan['sources'],'declaration':plan['declaration'],'runtime_closure':plan['runtime_closure'],'python':plan['python'],'inputs':plan['inputs'],
 'actual_inventory':actual_pins,'observer_inventory':observer_pins,
 'outcome':outcome,'checks':checks,'summary':{'checks':len(checks),'failed':0},
 'interpretation_limits':[
   'saved_review_passed means saved negative/custody records are consistent. It is not resource, finite calibration, count/unrank/solution, theorem or mathematical admission.',
   'Parent work deadline is the retained primary. Worker was terminated by recorded TERM and its original exception/stage was not saved in a complete summary. No finer failure cause or expensive-phase attribution is inferred.',
   'All component counters are literal null/unavailable, never zero. No completed prefixes/cases/diagnostics, palette census or accepted partial outcomes are derived from the raw unclosed fragment.',
   'Manual Source inventory/count/unrank/scheduler arguments remain conditional and separate. This actual supplied no complete calibration certificate; neither representation nor full graph qualification is rescued.',
   'Known standalone HWM, CPU usage and negative byte ledger are observations of this rejected run. They establish no speedup, RAM advantage, literal expansion fit, full physical interpreter/FOL/RL/production performance or theorem.',
   'C performed no process probe or signal. Reaping/group absence/close events come from saved owned runner observations plus authoritative Root terminal release, under the reviewed OS/exclusive-owner trust limits.',
   'Root barrier/adoption records are historical prelaunch administrative observations. No filesystem freshness or idle state is backdated by this postterminal review.',
   'Grant is consumed once and retired with remaining0. No rerun, new grant, cap change, failed-prefix completion or future execution is authorized.',
   'Same reviewer covers historical Source/prospective/authdelta/saved scopes with disclosed control/review ancestry overlap; no formal independent kernel or universal provenance certification is claimed.'
 ]
}
out=C/'typed-saved-actual-negative-review-v2.json';assert not out.exists()
out.write_text(json.dumps(receipt,ensure_ascii=False,allow_nan=False,indent=2)+'\n')
print(json.dumps({'receipt':pin(out),'checks':len(checks)},sort_keys=True))
