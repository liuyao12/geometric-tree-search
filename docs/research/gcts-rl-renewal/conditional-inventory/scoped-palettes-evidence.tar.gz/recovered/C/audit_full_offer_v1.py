"""Independent ordinary byte/AST/JSON review. Never loads subject modules."""
import ast
import hashlib
import json
import sys
from pathlib import Path

C=Path('/private/tmp/gcts-implicit-review-C-20261020-v1')
D=Path('/private/tmp/gcts-implicit-ROOT-20261020-v1')
checks=[]
def check(name,condition,evidence=None):
    checks.append({'id':name,'passed':bool(condition),'evidence':evidence})
    return bool(condition)
def digest(raw):return hashlib.sha256(raw).hexdigest()
def pin(path):
    path=Path(path);raw=path.read_bytes()
    return {'path':str(path),'bytes':len(raw),'sha256':digest(raw)}
def readp(desc):
    p=Path(desc['path']);raw=p.read_bytes()
    check('raw:'+str(p),pin(p)==desc,desc)
    return raw
def readj(desc):return json.loads(readp(desc))
def canon(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def assignments(tree):
    # A literal metadata extractor, not eval or execution of Source expressions.
    def literal(n):
        if isinstance(n,ast.Constant):return n.value
        if isinstance(n,(ast.Tuple,ast.List)):
            r=[literal(x)for x in n.elts]
            return tuple(r)if isinstance(n,ast.Tuple)else r
        if isinstance(n,ast.Dict):return {literal(k):literal(v)for k,v in zip(n.keys,n.values)}
        if isinstance(n,ast.Call)and isinstance(n.func,ast.Name)and n.func.id=='dict'and not n.args:
            return {k.arg:literal(k.value)for k in n.keywords}
        raise ValueError('nonliteral metadata expression')
    out={}
    for n in tree.body:
        if isinstance(n,ast.Assign)and len(n.targets)==1 and isinstance(n.targets[0],ast.Name):
            try:out[n.targets[0].id]=literal(n.value)
            except ValueError:pass
    return out

offer_pin={'path':str(D/'implicit-Source-only-offer-v1.json'),'bytes':5966,'sha256':'2df91713aee7c1fa77411aa2e24954f023f7e36e18c907b4b481704dcf4cf5ee'}
offer=readj(offer_pin);plan=readj(offer['false_plan']);subject={k:v for k,v in plan.items()if k!='authorization'}
check('subject_full_value',subject==offer['subject'])
check('subject_nine_fields',len(subject)==9)
check('subject_canonical_sha',digest(canon(subject))==offer['subject_sha256']=='a7897ce30b891322b7d01583350736eec68fa564f6ad0a80293c7673de9d2990')
check('offer_Source_map',offer['sources']==plan['sources'])
decl=readj(plan['declaration']);closure=readj(plan['runtime_closure']);auth=readj(plan['authorization'])
input_data=readj(plan['inputs'][0]['pin'])
for value in offer['antecedents'].values():readp(value)
readp(plan['python'])
for value in closure['stdlib_files']:readp(value)
check('false_auth_exact_keys',set(auth)=={'schema','author_identity','actual_execution_authorized','maximum_actual_invocations','subject_sha256','review','scope'})
check('false_auth_owner',auth['author_identity']=='/root')
check('false_auth_false_maxzero',auth['actual_execution_authorized']is False and type(auth['maximum_actual_invocations'])is int and auth['maximum_actual_invocations']==0 and auth['review']is None)
check('false_auth_subject',auth['subject_sha256']==offer['subject_sha256'])
check('actual_directory_absent',not Path(subject['actual_directory']).exists())
observer_dir=Path(offer['false_plan']['path']).parent/(Path(offer['false_plan']['path']).stem+'-terminal-observation')
check('false_observer_directory_absent',not observer_dir.exists())
check('closure_full_sources',closure['sources']==plan['sources'])
check('closure_python',closure['python']==plan['python'])
check('closure_declaration',closure['declaration']==plan['declaration'])
check('whole_input_join',plan['inputs']==decl['inputs']and len(plan['inputs'])==1)

trees={};constants={};AST_rows=[]
for role,desc in plan['sources'].items():
    raw=readp(desc);tree=ast.parse(raw,filename=desc['path']);trees[role]=tree
    compile(tree,desc['path'],'exec') # discarded code object only
    constants[role]=assignments(tree)
    check('unused_compile:'+role,True)
    entry=next(x for x in closure['direct_import_census']if x['role']==role)
    check('census_pin:'+role,entry['source']==desc)
    imports=[]
    for node in ast.walk(tree):
        if isinstance(node,ast.Import):imports.extend(x.name for x in node.names)
        elif isinstance(node,ast.ImportFrom):imports.append(node.module)
    check('direct_imports:'+role,sorted(set(imports))==entry['direct_imports'])
    actual=digest(ast.dump(tree,include_attributes=False).encode())
    check('AST_digest:'+role,actual==entry['AST_sha256'],{'offered':entry['AST_sha256'],'pinned_parser_recomputed':actual})
    AST_rows.append({'role':role,'source':desc,'offered_AST_sha256':entry['AST_sha256'],'pinned_parser_AST_sha256':actual})
check('AST_parser_attributed_in_closure','AST_parser'in closure)
check('six_role_census',set(plan['sources'])=={'worker','implicit','graph','selector','runner','observer'}and len(closure['direct_import_census'])==6)
check('no_component_imports',all(not any(isinstance(n,(ast.Import,ast.ImportFrom))for n in ast.walk(trees[r]))for r in('implicit','graph','selector')))
expected_limits={'work_seconds':180,'overall_seconds':210,'memory_bytes':1073741824,'result_bytes':134217728,'expanded_bytes':134217728,'stdout_bytes':4194304,'stderr_bytes':4194304,'worker_receipt_bytes':4194304,'runner_metadata_bytes':8388608,'observer_bytes':1048576}
check('original_full_limits',plan['limits']==decl['limits']==constants['worker']['OUTER_LIMITS']==constants['runner']['LIMITS']==expected_limits)
check('component_limits_declared_literal',decl['component_limits']=={r:constants['worker'][{'selector':'SELECTOR_LIMITS','implicit':'IMPLICIT_LIMITS','graph':'GRAPH_LIMITS'}[r]]for r in('selector','implicit','graph')})
check('cumulative_callback_cap',decl['checkpoint_limit']==constants['worker']['CHECKPOINT_LIMIT']==400000000)
check('nine_MiB_reserve',constants['worker']['RESERVE_BYTES']==9437184)

small=input_data['small_palettes'];graphs=input_data['graph_cases'];diagnostics=input_data['diagnostics']
caseids=[x['id']for x in small]+[input_data['large_palette']['id']]+[x['id']for x in graphs]
check('complete_case_order',caseids==decl['case_ids']and len(caseids)==decl['exact_cases']==15 and len(set(caseids))==15)
check('whole_four_small',len(small)==4)
check('whole_ten_graphs',len(graphs)==10)
check('whole_33_diagnostics',len(diagnostics)==33 and diagnostics==decl['diagnostics']and [x['id']for x in diagnostics]==decl['diagnostic_ids'])
check('diagnostic_IDs_unique',len({x['id']for x in diagnostics})==33)
check('small_palette_ID_joins',all(x['palette_id']in{x['id']for x in small}for x in graphs))
for x in graphs:
    if x['kind']=='unknown_board':
        check('graph_record_full_join:'+x['id'],x['palette_record']==next(y for y in small if y['id']==x['palette_id']))
        check('complete_board_scope:'+x['id'],x['capacity']in(1,2)and x['steps']==1 and x['mode']=='all')
check('minimal_foreign_inputs',input_data['minimal_machine']=={'alphabet_size':4,'state_count':2,'blank':3,'initial':0,'accepting':1,'transitions':[]}and input_data['minimal_wire']=={'zero':0,'one':1,'terminator':2}and input_data['minimal_descriptor']==['implicit-wang-palette-v1',[4,2,3,0,1,[]],[0,1,2]])
large=input_data['large_palette']['machine'];rows=large['transitions']
check('large_complete_declarative_table',len(rows)==7936 and rows==[[q,r,q+1,r,(-1,0,1)[q%3]]for q in range(31)for r in range(256)])
check('large_full_machine_bounds',large['alphabet_size']==256 and large['state_count']==32 and large['accepting']==31 and large['initial']==0 and large['blank']==0)
byop={x['operation']:x for x in diagnostics}
check('foreign_count_anchors',all(byop[k]['expected']=='FOREIGN'and byop[k]['expected_callback_count']==v for k,v in {'implicit_foreign_entry':1,'implicit_foreign_wire':14,'implicit_foreign_fill':95,'implicit_foreign_same_invalid':1,'implicit_foreign_same_limit':1,'graph_foreign_entry':1,'graph_foreign_inside':10,'graph_foreign_same_invalid':10,'graph_foreign_same_limit':10}.items()))
check('foreign_named_anchors',byop['implicit_foreign_wire']['expected_callback_function']=='_wire_record'and byop['implicit_foreign_fill']['expected_callback_function']=='_fill')
check('nonforeign_zero_injection_counts',all(x['expected_callback_count']==0 for x in diagnostics if x['expected']!='FOREIGN'))
check('only_owned_search_unknown',byop['graph_work_unknown']['expected']=='UNKNOWN'and sum(x['expected']=='UNKNOWN'for x in diagnostics)==1)

pre=C/'prospective-v1-negative-preimages'
assert not pre.exists();pre.mkdir()
copied=[]
for name,desc in [('offer',offer_pin),('plan',offer['false_plan']),('authorization',plan['authorization']),('declaration',plan['declaration']),('closure',plan['runtime_closure'])]+[(r,d)for r,d in plan['sources'].items()]+[('input',plan['inputs'][0]['pin'])]:
    target=pre/(name+Path(desc['path']).suffix);target.write_bytes(readp(desc));p=pin(target)
    assert p['bytes']==desc['bytes']and p['sha256']==desc['sha256']
    copied.append({'original':desc,'copy':p,'exact_bytes':True})

manual=[
 {'id':'M01','passed':True,'finding':'Six disjoint semantic step cases, all collector/frame/initializer families, exact full tuple-color intersection and mixed-radix unranking reviewed against unchanged selector and legacy local rule; B V2 narrow Source PASS inherited explicitly.'},
 {'id':'M02','passed':True,'finding':'Four complete small palettes are compared by all sixteen tile-edge mask projections and every matching rank, full ID/NESW/t/m value equality and distinct population; declared empty masks use the literal reference, not the intended name. This is all nonempty masks, not every possible zero query.'},
 {'id':'M03','passed':True,'finding':'Large complete mixed-motion machine recipe retained; old algebraic count comparison plus first/middle/last ranks and six step cases/thirteen nonstep kinds use independent radius-one/template checks. No full large enumeration or literal-output fit claimed.'},
 {'id':'M04','passed':True,'finding':'Graph full palette remains available at each exact even origin; reverse midpoint dependencies include all support points and retain unrelated pins. Typed absent versus assigned zero and repeated reference ownership are preserved.'},
 {'id':'M05','passed':True,'finding':'Global DEAD before FORCED before earliest root generation with degree/index ties; explicit nonzero generations are a labeled finite ordering test variant.'},
 {'id':'M06','passed':True,'finding':'FIRST restores immutable parent then excludes only the exhaustively failed semantic ID under the parent context and reselects fresh rank zero. ALL has no pruning exclusions, uses stable parent-domain cursors and retains all solutions.'},
 {'id':'M07','passed':True,'finding':'Root independent literal census reconstructs chosen values, whole pin/placed marks and refcounts, all frontier domains/exclusions/support, scheduler and reverse incidence at every offered live/parent snapshot. Complete independent fixed-site population is not passed into search.'},
 {'id':'M08','passed':True,'finding':'BEFORE/AFTER rollback include identical full rollback_parent; Root compares the complete restored core, then exact original/root equality. Raw control frames are not fabricated into the popped stack.'},
 {'id':'M09','passed':True,'finding':'Every selected full certificate tile is joined to the old literal inventory and whole returned point IDs; ALL populations match the independent reference, FIRST validates complete returned member or exhaustive empty answer.'},
 {'id':'M10','passed':True,'finding':'Root genuine fault latch precedes expected refusals, planned callback checks call real Root guard first, exact precreated object identity is required, and Source function frames join wire/fill anchors. No target callback was executed by this reviewer.'},
 {'id':'M11','passed':True,'finding':'Private B errors require exact type plus module owner; graph UNKNOWN requires exact per-invocation SearchLimit owner, never a zero domain or UNSAT substitution. Foreign same-class and StopIteration diagnostics are explicit.'},
 {'id':'M12','passed':True,'finding':'Raw Source plus recursive function/code/default binding identities guarded around actual calls and full typed argument carriers checked on success/refusal. Dict field-order normalization is confined to inventory tile comparison; all declared fields and value types remain checked.'},
 {'id':'M13','passed':True,'finding':'Whole successful B calls and partial failure prefixes, incremental component rows, every graph snapshot/event/query/solution and all diagnostics retained within original fully expanded storage bounds. L prefix attaches available ordinary rows by reference and calls no post-stop callback.'},
 {'id':'M14','passed':True,'finding':'Worker/full result/full canonical bytes/known exit use original 180-second epoch; later raw custody/log/physical/receipt/terminal closure uses 210 seconds. Stable logs only after known reaping/group absence; unavailable OS observations never create admission.'},
 {'id':'M15','passed':True,'finding':'Fully emitted packet/result and all physical files plus nine-MiB reserve remain bounded by original 128MiB; duplicate retained subtrees are charged without sharing. Standalone worker HWM limit remains 1GiB, not physical VM/full-production fit.'},
 {'id':'M16','passed':True,'finding':'One fresh false/maxzero subject only. A future Root maxone grant, exact auth-only review and all-peer idle/fresh barrier remain required. No old negative outcome, retired grant or failed prefix is reused.'},
 {'id':'M17','passed':True,'finding':'SourceFileLoader/pyc/OS/builtins/frozen/transitive stdlib and exclusive read-only ownership remain trusted. Guard is not a hostile sandbox, compiled-object seal, full globals/default-content/closure seal or universal failure-provenance guarantee.'},
 {'id':'M18','passed':True,'finding':'Census units are exported Root wrapped-call and completed qualification-routine counters; callback/work/snapshot records have explicit cutoffs, not total CPU work. Failed private query costs may remain unavailable except exported prefixes.'},
 {'id':'M19','passed':True,'finding':'New representation and specialized finite singleton-center graph are not full mixed-generation/fractional/shared-t/extended-m GCTS conformance, a physical FOL interpreter, theory/target proof, new theorem, RL result, universality or measured advantage.'}
]
receipt={
 'schema':'wang-encoding-Source-prospective-review-v1','reviewer_identity':'/root/conventional_control_review',
 'review_passed':False,'source_only':True,'component_calls':0,'scientific_calls':0,'actual_execution_authorized':False,
 'scientific_acceptance':False,'subject':subject,'subject_sha256':offer['subject_sha256'],'sources':plan['sources'],
 'offer':offer_pin,'false_plan':offer['false_plan'],'false_authorization':plan['authorization'],
 'current_master':offer['antecedents']['current_master'],'antecedents':offer['antecedents'],
 'authorship':{'root_worker_outer_protocol':'/root','implicit_palette':'/root/benchmark_design','graph':'/root/conventional_library','independent_reviewer':'/root/conventional_control_review','ancestry_overlap':'Same reviewer across Source/once/prospective scopes; reviewer authored historical controls/reviews. Older selector/legacy and lifecycle reviews are genuine inherited provenance, not new independent kernel recertification.'},
 'mechanical_checks':checks,'manual_Source_checks':manual,
 'blocking_findings':[{'id':'P1_AST_PARSER_ATTRIBUTION','scope':'Prospective runtime-closure metadata only','description':'All six offered AST_sha256 values differ from independently parsed pinned Python3.12.14 ast.dump(include_attributes=False). The closure has no explicit AST_parser executable/version/serialization. No alternate serialization was established; no false Source-byte drift is inferred.','required_correction':'Preserve V1; freeze a metadata-only successor under the exact pinned interpreter with explicit parser/version/AST serialization and recomputed fingerprint/closure/plan/subject pins. Sources/input/caps need no repair identified by this review.','rows':AST_rows}],
 'parser_used_by_this_review':{'executable':sys.executable,'version':sys.version,'ast_source':pin(ast.__file__),'policy':'ast.parse(raw, filename=source path); ast.dump(include_attributes=False); UTF-8 bytes; SHA256. Discarded unused compile only, never exec/import subject.'},
 'preserved_preimages':copied,
 'limitations':['This bounded negative does not authorize any actual or grant and does not certify runtime completion.','Every other successful check is reusable only if exact relevant bytes remain unchanged in an offered successor.','No subject/helper/compiler/graph/fixture/oracle/checker execution, simulation, process probes or opaque decoding occurred.','Existing B V1 PEP479 negative and failed ENOSPC snapshot fact remain preserved; the later successful C V1-offer copies above are separate explicitly named raw preimages.']
}
receipt['summary']={'mechanical_checks':len(checks),'mechanical_failed':sum(not x['passed']for x in checks),'manual_Source_checks':len(manual),'blocking_findings':1}
out=C/'typed-implicit-Source-prospective-negative-v1.json';assert not out.exists()
out.write_text(json.dumps(receipt,ensure_ascii=False,allow_nan=False,indent=2)+'\n')
print(json.dumps({'receipt':pin(out),'summary':receipt['summary']},sort_keys=True))
