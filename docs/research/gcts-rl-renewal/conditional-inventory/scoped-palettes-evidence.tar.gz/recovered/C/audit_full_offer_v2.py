"""Exact metadata-successor audit; subject modules never imported or called."""
import ast
import hashlib
import json
import sys
from pathlib import Path

C=Path('/private/tmp/gcts-implicit-review-C-20261020-v1')
D=Path('/private/tmp/gcts-implicit-ROOT-20261020-v1')
checks=[]
def digest(b):return hashlib.sha256(b).hexdigest()
def pin(p):
    p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':digest(b)}
def ck(k,v,e=None):
    checks.append({'id':k,'passed':bool(v),'evidence':e})
    assert v,k
def raw(d):
    b=Path(d['path']).read_bytes();ck('raw:'+d['path'],pin(d['path'])==d,d);return b
def obj(d):return json.loads(raw(d))
def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()

oldpin=pin(C/'typed-implicit-Source-prospective-negative-v1.json')
ck('negative_ancestor_exact',oldpin['sha256']=='dd655c779e1790c3152c629a0857c416d4b0981c0266025f4205dfdee62f383e')
old=json.loads(Path(oldpin['path']).read_bytes())
offerpin={'path':str(D/'implicit-Source-only-offer-v2.json'),'bytes':6393,'sha256':'9d7f60650d0295dfa71cb0ee607ee43aa14336a83f6f583432b9fb6a20604586'}
offer=obj(offerpin);plan=obj(offer['false_plan']);sub={k:v for k,v in plan.items()if k!='authorization'}
ck('exact_nine_field_subject',len(sub)==9 and sub==offer['subject'])
ck('canonical_subject_sha',digest(canon(sub))==offer['subject_sha256']=='f7200a04eac8186ef00875982019c318bde68d30b17062cc1ee360fbc099a499')
ck('exact_ten_field_false_plan',set(plan)=={'schema','invocation_id','actual_directory','python','sources','inputs','limits','declaration','runtime_closure','authorization'})
ck('current_sources_exact_inherited',sub['sources']==old['sources']==offer['sources'])
changed={k for k in sub if sub[k]!=old['subject'][k]}
ck('subject_only_fresh_ID_path_closure',changed=={'invocation_id','actual_directory','runtime_closure'},sorted(changed))
for key in('schema','sources','inputs','declaration','python','limits'):
    ck('unchanged_subject:'+key,sub[key]==old['subject'][key])
decl=obj(sub['declaration']);closure=obj(sub['runtime_closure']);oldclosure=json.loads(Path(old['subject']['runtime_closure']['path']).read_bytes())
auth=obj(plan['authorization']);retire=obj(offer['retired_predecessor'])
ck('retirement_zero_actual',retire['actual_invocations']==0 and retire['retired_without_grant']is True and retire['actual_path_absent']is True)
ck('retirement_exact_negative_subject',retire['subject_sha256']==old['subject_sha256']and retire['false_plan']==old['false_plan']and retire['false_offer']==old['offer'])
ck('old_false_actual_still_absent',not Path(old['subject']['actual_directory']).exists())
ck('auth_exact_false_fields',set(auth)=={'schema','author_identity','actual_execution_authorized','maximum_actual_invocations','subject_sha256','review','scope'})
ck('false_maxzero_no_review',auth['actual_execution_authorized']is False and auth['author_identity']=='/root'and type(auth['maximum_actual_invocations'])is int and auth['maximum_actual_invocations']==0 and auth['review']is None)
ck('false_auth_subject',auth['subject_sha256']==offer['subject_sha256'])
ck('actual_path_fresh',not Path(sub['actual_directory']).exists())
obs=Path(offer['false_plan']['path']).parent/(Path(offer['false_plan']['path']).stem+'-terminal-observation')
ck('false_observer_path_fresh',not obs.exists())
for value in offer['antecedents'].values():raw(value)
raw(sub['python'])
for value in sub['sources'].values():raw(value)
for item in sub['inputs']:raw(item['pin'])
for value in closure['stdlib_files']:raw(value)
ck('closure_all_sources_python_decl',closure['sources']==sub['sources']and closure['python']==sub['python']and closure['declaration']==sub['declaration'])
ck('closure_unchanged_trust_stdlib',closure['runtime_trust']==oldclosure['runtime_trust']and closure['stdlib_files']==oldclosure['stdlib_files'])
ck('closure_only_allowed_fields',set(closure)==set(oldclosure)|{'AST_parser','supersedes_metadata_only'})
for key in set(oldclosure)-{'direct_import_census'}:
    ck('unchanged_closure:'+key,closure[key]==oldclosure[key])
parser=closure['AST_parser']
ck('parser_exact_runtime',parser['python']==sub['python']and parser['version']==sys.version and parser['implementation']==sys.implementation.name)
ck('parser_explicit_flags',parser['command_flags']==['-I','-S','-B'])
ck('parser_explicit_parse_policy',parser['parse']=={'mode':'exec','type_comments':False,'feature_version':None})
ck('parser_explicit_serialization',parser['serialization']=='ast.dump(tree, annotate_fields=True, include_attributes=False).encode(utf8)'and parser['digest']=='sha256')
oldc={r['role']:r for r in oldclosure['direct_import_census']};AST_rows=[]
for row in closure['direct_import_census']:
    role=row['role'];b=Path(sub['sources'][role]['path']).read_bytes()
    t=ast.parse(b,filename=sub['sources'][role]['path'],mode='exec',type_comments=False,feature_version=None)
    compile(t,sub['sources'][role]['path'],'exec') # discarded, never exec
    h=digest(ast.dump(t,annotate_fields=True,include_attributes=False).encode())
    ck('current_AST:'+role,h==row['AST_sha256'],h)
    ck('unchanged_census_Source_imports:'+role,row['source']==oldc[role]['source']and row['direct_imports']==oldc[role]['direct_imports'])
    ck('AST_row_only_digest_changed:'+role,set(row)==set(oldc[role]))
    AST_rows.append({'role':role,'source':row['source'],'AST_sha256':h})
ck('full_six_census',len(AST_rows)==6 and {r['role']for r in AST_rows}==set(sub['sources']))
ck('decl_still_exact_limits_inputs',decl['limits']==sub['limits']and decl['inputs']==sub['inputs'])
bank=json.loads(Path(sub['inputs'][0]['pin']['path']).read_bytes())
ck('normal_full_bank_unchanged',len(bank['small_palettes'])==4 and len(bank['graph_cases'])==10 and len(decl['case_ids'])==15 and decl['exact_cases']==15)
ck('diagnostics_full_bank_unchanged',len(bank['diagnostics'])==33 and bank['diagnostics']==decl['diagnostics'])
ck('all_manual_Source_checks_inherited_pass',all(x['passed']for x in old['manual_Source_checks']))
ck('only_old_metadata_failures',all(x['passed']or x['id'].startswith('AST_digest:')or x['id']=='AST_parser_attributed_in_closure'for x in old['mechanical_checks']))

receipt={
 'schema':'wang-encoding-Source-prospective-review-v1',
 'reviewer_identity':'/root/conventional_control_review',
 'review_passed':True,'source_only':True,'component_calls':0,'scientific_calls':0,
 'actual_execution_authorized':False,'scientific_acceptance':False,
 'subject':sub,'subject_sha256':offer['subject_sha256'],'sources':sub['sources'],
 'offer':offerpin,'false_plan':offer['false_plan'],'false_authorization':plan['authorization'],
 'declaration':sub['declaration'],'runtime_closure':sub['runtime_closure'],'python':sub['python'],'whole_inputs':sub['inputs'],
 'current_master':offer['antecedents']['current_master'],'antecedents':offer['antecedents'],
 'negative_predecessor':oldpin,'retired_predecessor':offer['retired_predecessor'],
 'authorship':old['authorship'],
 'review_method':{'Source':'Full B/graph/Root-worker/outer Source reading and manual reasoning, then exact raw/AST final binding. The unchanged selector and old lifecycle retain genuine prior reviews; no new full kernel or OS certification.','metadata':'Raw hash/path/byte checks, ordinary JSON full-value joins, pinned Python AST parsing and discarded unused compile only.','subject_execution':'No target imports/calls, oracle/fixtures/search/selector/simulation/checker/truth functions, process probes, launches or opaque decoding.'},
 'current_mechanical_checks':checks,'current_AST_census':AST_rows,'parser_verification':parser,
 'inherited_full_Source_checks':old['manual_Source_checks'],
 'reused_prior_mechanical_scope':{'prior_total':old['summary']['mechanical_checks'],'prior_passed':old['summary']['mechanical_checks']-old['summary']['mechanical_failed'],'prior_metadata_failures':7,'current_resolution':'All six digests recomputed exactly under explicit pinned parser; attribution now explicit. Current subject/closure/pins rechecked independently above. V1 negative retained.'},
 'semantic_scope':{
   'palette':'All old semantic tile identities and full constructor colors represented without materializing their Cartesian product; full small nonempty-mask/rank comparison remains the prospective finite test, with declared zero queries additional.',
   'large':'Complete synthetic mixed-motion transition table bound; full formula/count plus selected global ranks and every family-kind membership. No full large rank-space exhaustion, physical interpreter or literal-output fit.',
   'graph':'Finite even-origin singleton-center positive support, exactly four NESW midpoint marks; full candidate universe at every origin, all midpoint dependencies, global scheduler and context-safe rollback/exclusions. Does not cover arbitrary extended-m, shared/fractional support, mixed-generation or unbounded plane GCTS.',
   'oracle':'Independent literal palette comparison, complete fixed-site finite reference population and full snapshot/domain/mark/refcount/rollback comparisons are performed only inside a future authorized actual. Source arguments do not turn planned outputs into observed certificates.',
   'diagnostics':'All33 named operations/classes/counts mandatory; exact foreign identity and named _wire_record/_fill frames at ordinal14/95, plus entry1, with real Root check first. Foreign same-class never owned; own search quota is UNKNOWN, never exhaustion.'
 },
 'resource_and_retention_scope':{
   'positive_seconds':180,'later_custody_terminal_seconds':210,'observer_fallback_seconds':225,
   'worker_peak_limit_bytes':1073741824,'stored_expanded_and_physical_limit_bytes':134217728,
   'outer_reservation_bytes':9437184,'stdout_stderr_each_bytes':4194304,'worker_header_bytes':4194304,
   'runner_metadata_bytes':8388608,'observer_all_files_bytes':1048576,'Root_cumulative_callbacks':400000000,
   'private_units':'B and graph private charged visits/checks/arithmetic and exported cutoffs are distinct from CPU instructions, bytes and final callback totals; no operation/cost amnesty from per-call fresh budgets.',
   'retained':'Whole inputs/recipes, complete literal tiles, all query masks/selected values/full B args and receipts, every graph snapshot/event/query/solution/independent domain, all diagnostics. Duplicate subtrees count in actual expanded bytes. Failure evidence best-effort only before210 within the same physical cap, no partial admission.',
   'cost_taxonomy':'Wrapped component entry maps and completed Root qualification-routine counters do not census all internal functions/CPU work. Failed current B work can be unavailable unless its prefix exported; L completed-query sum is explicitly partial.'
 },
 'limitations':[
   'This is Source/prospective PASS for the exact false/maxzero V2 subject only. It grants no execution and certifies no runtime result, footprint or completion.',
   'Root must separately adopt precise scope, issue one fresh maxone grant, obtain auth-only delta review and save all-peer idle/fresh-path barrier before any actual.',
   'No full VM, BOOT/controller/checker, public theory/target FOL proof search, mathematical proof/new theorem, reusable lemma learning, trained RL, universal plane or speed advantage qualification.',
   'The mathematical represented palette cardinality is distinct from fully emitted JSON bytes; no claim the old literal expansion fits original output caps or prior failed experiments are rescued.',
   'Exclusive input/read-only callback ownership, raw SourceFileLoader/pyc/OS/builtin/frozen/transitive stdlib and interpreter remain trusted. Recursive callable/code/default identities do not seal defaults contents, globals, closures or every compiled object.',
   'No universal diagnostic/provenance guarantee under total metadata/storage failure; such failures remain unadmitted and must not acquire fabricated zero-cost or closure claims.',
   'One reviewer covers these limited scopes with disclosed historical authorship overlap. Separate palette/graph authors and Root literal oracle add scrutiny, not an independent formal kernel certificate.',
   'All prior negatives, retired grants and B V1 PEP479/snapshot failure records remain literal historical evidence. New mixed large table is frozen before any actual; early stationary planning was superseded without an outcome-based change.'
 ]
}
receipt['summary']={'current_checks':len(checks),'current_failures':0,'inherited_manual_Source_checks':len(old['manual_Source_checks']),'blocking_findings':0}
out=C/'typed-implicit-Source-prospective-review-v2.json';assert not out.exists()
out.write_text(json.dumps(receipt,ensure_ascii=False,allow_nan=False,indent=2)+'\n')
print(json.dumps({'receipt':pin(out),'summary':receipt['summary']},sort_keys=True))
