"""Raw/ordinary JSON authorization delta only; never starts a subject."""
import hashlib
import json
from pathlib import Path
C=Path('/private/tmp/gcts-implicit-review-C-20261020-v1')
D=Path('/private/tmp/gcts-implicit-ROOT-20261020-v1')
checks=[]
def pin(p):
    p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def ck(k,v,e=None):
    checks.append({'id':k,'passed':bool(v),'evidence':e});assert v,k
def raw(d):
    b=Path(d['path']).read_bytes();ck('raw:'+d['path'],pin(d['path'])==d,d);return b
def obj(d):return json.loads(raw(d))
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
reviewpin={'path':str(C/'typed-implicit-Source-prospective-review-v2.json'),'bytes':46330,'sha256':'c3be3652e2b75a49239b096c8728cedf796100b74ec194b19db405c63b821672'}
review=obj(reviewpin)
planpin={'path':str(D/'implicit-plan-authorized-v2.json'),'bytes':3089,'sha256':'df6ceb94019c9520af7b9ff2d65dc85880d883c2848f119f105e0eb84ca16317'}
plan=obj(planpin);false=obj(review['false_plan']);auth=obj(plan['authorization'])
subject={k:v for k,v in plan.items()if k!='authorization'}
ck('only_authorization_field_changed',{k for k in plan if plan[k]!=false[k]}=={'authorization'}and set(plan)==set(false))
ck('same_nine_field_subject',len(subject)==9 and subject==review['subject']=={k:v for k,v in false.items()if k!='authorization'})
ck('same_subject_canonical_SHA',hashlib.sha256(canonical(subject)).hexdigest()==review['subject_sha256']=='f7200a04eac8186ef00875982019c318bde68d30b17062cc1ee360fbc099a499')
ck('exact_grant_seven_fields',set(auth)=={'schema','author_identity','actual_execution_authorized','maximum_actual_invocations','subject_sha256','review','scope'})
ck('Root_true_exact_maxone',auth['schema']=='ROOT-wang-encoding-authorization-v1'and auth['author_identity']=='/root'and auth['actual_execution_authorized']is True and type(auth['maximum_actual_invocations'])is int and auth['maximum_actual_invocations']==1)
ck('grant_exact_review_subject',auth['subject_sha256']==review['subject_sha256']and auth['review']==reviewpin)
ck('current_Source_review_contract',review['schema']=='wang-encoding-Source-prospective-review-v1'and review['reviewer_identity']=='/root/conventional_control_review'and review['review_passed']is True and review['source_only']is True and type(review['component_calls'])is int and review['component_calls']==0 and review['actual_execution_authorized']is False)
oldauth=obj(false['authorization'])
ck('preserved_false_authorization',oldauth['actual_execution_authorized']is False and oldauth['maximum_actual_invocations']==0 and oldauth['review']is None)
ck('all_full_Source_subjects_unchanged',plan['sources']==review['sources'])
for desc in plan['sources'].values():raw(desc)
raw(plan['python']);decl=obj(plan['declaration']);closure=obj(plan['runtime_closure'])
ck('whole_input_decl_binding',plan['inputs']==decl['inputs']and plan['inputs']==review['whole_inputs']and len(plan['inputs'])==1)
for item in plan['inputs']:raw(item['pin'])
for desc in closure['stdlib_files']:raw(desc)
raw(review['current_master'])
ck('full_runtime_binding',closure['python']==plan['python']and closure['sources']==plan['sources']and closure['declaration']==plan['declaration'])
ck('all_limits_unchanged',plan['limits']==false['limits']==decl['limits']==review['subject']['limits'])
ck('full_whole_population_unchanged',decl['exact_cases']==15 and len(decl['diagnostics'])==33 and len(decl['case_ids'])==15)
actual=Path(plan['actual_directory']);observation=Path(planpin['path']).parent/(Path(planpin['path']).stem+'-terminal-observation')
ck('actual_path_absent',not actual.exists(),str(actual))
ck('authorized_observation_path_absent',not observation.exists(),str(observation))
ck('no_actual_consumed_marker',not(actual/'CONSUMED.json').exists()and not(actual/'WORKER_CONSUMED.json').exists())
retirement=obj(review['retired_predecessor'])
ck('V1_retired_unused',retirement['actual_invocations']==0 and retirement['retired_without_grant']is True and not Path(json.loads(Path(retirement['false_plan']['path']).read_bytes())['actual_directory']).exists())
receipt={
 'schema':'implicit-palette-final-grant-delta-review-v2',
 'reviewer_identity':'/root/conventional_control_review',
 'final_grant_delta_review_passed':True,'source_only':True,
 'component_calls':0,'scientific_calls':0,'actual_execution_authorized':False,
 'authorized_plan':planpin,'authorization':plan['authorization'],'false_plan':review['false_plan'],
 'full_authorization':auth,'subject':subject,'subject_sha256':review['subject_sha256'],
 'Source_prospective_review':reviewpin,'current_master':review['current_master'],
 'sources':plan['sources'],'inputs':plan['inputs'],'declaration':plan['declaration'],'runtime_closure':plan['runtime_closure'],'python':plan['python'],
 'fresh_paths':{'actual':str(actual),'authorized_observer':str(observation),'absent_at_review':True,'point_in_time_only':True},
 'checks':checks,'summary':{'checks':len(checks),'failed':0},
 'scope_and_limits':[
    'Only authorization descriptor changed. Same exact complete nine-field subject, six Sources, whole4-small/1-large/10-graph/33-diagnostic bank and original caps.',
    'This reviewer did not grant or execute anything. Root owns one future invocation; this receipt confirms its exact metadata delta, not an actual outcome or general execution permission.',
    'All limitations of the exact c3be Source/prospective review remain in force, including exclusive-owner/loader trust, finite singleton-center scope, large selected-only coverage, full expansion costs and best-effort failure retention.',
    'No complete physical VM/FOL/kernel/theorem/RL/universal or measured benefit claim; prior negatives and V1 retired unused offer remain unchanged.',
    'One reviewer covers Source/prospective/authdelta with disclosed historical ancestry overlap; no new independence or runtime acceptance is implied.',
    'Fresh paths are observed only at this metadata check. Root must separately inspect full raw pins/storage/paths and all-peer stopped barrier before its one future launch.',
    'C stops all tools immediately after handoff; no process probe/subject import/helper/fixture/oracle execution occurred.'
 ]
}
out=C/'typed-final-grant-delta-review-v2.json';assert not out.exists()
out.write_text(json.dumps(receipt,ensure_ascii=False,allow_nan=False,indent=2)+'\n')
print(json.dumps({'receipt':pin(out),'checks':len(checks)},sort_keys=True))
