"""Reviewer-owned raw/AST receipt writer; never imports or calls a subject."""
import ast
import hashlib
import json
from pathlib import Path

ROOT = Path('/private/tmp/gcts-implicit-review-C-20261020-v1')
SOURCE = Path('/private/tmp/gcts-implicit-wang-B-20261020-v1/implicit_wang_palette_v1.py')

def pin(path):
    path = Path(path)
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

raw = SOURCE.read_bytes()
assert len(raw) == 22565
assert hashlib.sha256(raw).hexdigest() == 'fa6a6a122fffe88111fe010a6af5b9676684caeddf62678b5d2ec0d9bc77e7ae'
tree = ast.parse(raw, filename=str(SOURCE))
compile(tree, str(SOURCE), 'exec')  # discarded code object; no exec/import
functions = {n.name: n for n in tree.body if isinstance(n, ast.FunctionDef)}
sites = []
for name, expected in [('_wire_record', 209), ('_fill', 364)]:
    gens = [n for n in ast.walk(functions[name])
            if isinstance(n, ast.GeneratorExp) and n.lineno == expected]
    assert len(gens) == 1 and gens[0].lineno == expected
    sites.append({'function': name, 'line': expected,
                  'literal': raw.decode().splitlines()[expected - 1].strip()})
snapshot = ROOT / 'implicit_wang_palette_observed-draft-v1.py'
assert not snapshot.exists()
receipt = {
    'schema': 'implicit-wang-palette-typed-Source-negative-review-v1',
    'reviewer_identity': '/root/conventional_control_review',
    'author_identity': '/root/benchmark_design',
    'source_review_passed': False,
    'source_only': True,
    'component_calls': 0,
    'scientific_calls': 0,
    'scientific_acceptance': False,
    'actual_execution_authorized': False,
    'subject': pin(SOURCE),
    'reference_pins': [
        pin('/private/tmp/gcts-fixed-initializer-ROOT-20261020-v1/basic-tiling-algorithm-current.md'),
        pin('/private/tmp/gcts-wang-spacetime-library-20261019/wang_spacetime_compiler_v1.py'),
        pin('/private/tmp/gcts-fixed-initializer-ROOT-20261020-v1/wang_unknown_certificate_initializer_v1.py'),
        pin(ROOT / 'independent-implicit-obligations-v1.json')
    ],
    'findings': [{
        'id': 'B1_CALLBACK_STOPITERATION_IDENTITY',
        'severity': 'BLOCKING_BEFORE_EXECUTED_QUALIFICATION',
        'sites': sites,
        'Source_witness': [
            '_wire_record evaluates _int inside a generator expression. _int calls work.number, which calls work.tick, which calls the supplied check callback.',
            '_fill evaluates a recursive _fill inside a generator expression. Each recursive _fill first calls work.tick and the supplied check callback.',
            'If that callback raises a precreated StopIteration object during either generator body, Python generator-boundary semantics transform it into RuntimeError. The original object is no longer the escaping primary exception.',
            '_run catches the transformed exception and bare-rethrows it after best-effort prefix attachment. It cannot undo the preceding generator transformation.'
        ],
        'claim_refuted': 'Exact foreign callback exception identity, including StopIteration, on every public path.',
        'required_correction': 'Replace both callback-bearing generator expressions with ordinary explicit loops followed by tuple conversion, preserving the existing call/tick order and all domains, quotas, tile semantics and output schemas.',
        'runtime_witness_executed': False,
        'callback_ordinal_derived_or_claimed_by_this_review': False,
        'future_qualification_requirement': 'A fresh separately reviewed Root subject must test exact StopIteration object identity at entry, wire numeric conversion and nested tuple fill; Source repair alone is not runtime qualification.'
    }],
    'review_method': ['Full affected raw Source and caller/callee reading',
                      'Standard-library AST inspection',
                      'Discarded unused compile only',
                      'Manual reasoning about generator exception semantics'],
    'snapshot_failure_custody': {
        'attempted_path': str(snapshot),
        'earlier_copy_result': 'cp failed with No space left on device; subsequent shasum reported no such file',
        'snapshot_created': False,
        'snapshot_exists_at_receipt_freeze': False,
        'snapshot_pin': None,
        'scope': 'The negative receipt binds the still-present original B V1 raw file directly. No successful snapshot or contemporaneous saved preimage is claimed. Root later reported free space; no deletion or recovery action is claimed by this reviewer.'
    },
    'scope_limits': [
        'This is a concrete Source-negative finding; no subject functions, fixtures, compiler, oracle or graph searches were imported or executed.',
        'No actual, grant, resource admission, mathematical universality, full VM or GCTS/RL benefit is authorized or certified.',
        'The previously frozen manual cardinality/count-unrank obligations remain prospective. This receipt does not silently convert them to an executed proof.',
        'Current L graph and Root oracle are separately evolving drafts and receive no PASS from this receipt.',
        'Historical authorship and retained Source ancestry are disclosed; this reviewer authored earlier review/control material, not this B implementation.'
    ]
}
target = ROOT / 'typed-implicit-palette-Source-negative-v1.json'
assert not target.exists()
target.write_text(json.dumps(receipt, ensure_ascii=False, allow_nan=False, indent=2) + '\n')
print(json.dumps(pin(target), sort_keys=True))
