"""Notation-only successor; no subject execution and no prior byte overwrite."""
import hashlib
import json
from pathlib import Path
D = Path('/private/tmp/gcts-implicit-review-C-20261020-v1')
old = D/'typed-implicit-palette-Source-review-v2.json'
raw = old.read_bytes()
assert hashlib.sha256(raw).hexdigest() == 'a442b84a8bcc16ecbe9f83a89abfb2a39343223103505fea009454f91d708ae2'
v = json.loads(raw)
v['notation_only_predecessor'] = {'path':str(old),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
v['notation_correction'] = 'Formula fields use LaTeX delimiters; review conclusions, pins, Source and all underlying arguments are unchanged.'
v['cardinality_argument'].update({
    'variables':r'\(b\) symbols; \(Q\) states; \(D\) defined transitions; \(D_0\) stationary transitions; \(A=b(Q+1)\).',
    'six_disjoint_step_counts':[r'\(b(b+1)^2\)',r'\(Db(b+1)\)',r'\(D_{-}b(b+1)\)',r'\(D_0(b+1)^2\)',r'\(D_{+}b(b+1)\)',r'\(Db(b+1)\)'],
    'step_total':r'\(S=b(b+1)^2+3Db(b+1)+D_0(b+1)\)',
    'base_total':r'\(T_{\mathrm{base}}=S+3b+2A+2\)',
    'initializer_total':r'\(T_{\mathrm{init}}=9b+16\)',
    'full_total':r'\(T=S+12b+2A+18\)'
})
out = D/'typed-implicit-palette-Source-review-v2b.json'
assert not out.exists()
out.write_text(json.dumps(v,ensure_ascii=False,allow_nan=False,indent=2)+'\n')
b=out.read_bytes()
print(json.dumps({'path':str(out),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()},sort_keys=True))
