"""SOURCE ONLY: exact finite singleton-center Wang domains via a certified oracle.

No imports, palette generation, simulation, fixture, or top-level search call.
The oracle and caller Source/argument guards are trust prerequisites.  This is
not a fractional/shared-positive-support engine or a fixed FOL interpreter.
"""

VERSION = 'implicit-wang-point-search-v1'
SCHEMA = 'finite-implicit-wang-point-instance-v1'
SNAPSHOT = 'implicit-wang-complete-domain-snapshot-v1'
PROFILE = 'singleton-center-NESW-implicit-complete-domains-v1'
OFFSETS = ((0, -1), (1, 0), (0, 1), (-1, 0))
LIMIT_KEYS = ('work', 'sites', 'pins', 'dependencies', 'frames', 'choices',
              'solutions', 'events', 'snapshots', 'snapshot_items',
              'selected_tiles', 'oracle_queries', 'integer_bits',
              'coordinate_abs', 'data_items', 'data_depth', 'string_chars')
ORACLE_LIMIT_KEYS = ('work', 'symbols', 'states', 'transitions', 'integer_bits',
                     'data_items', 'data_depth', 'string_chars')


class DeclarationError(Exception):
    pass


class OracleContractError(Exception):
    pass


class ReadOnlyViolation(Exception):
    pass


class SearchLimit(Exception):
    def __init__(self, owner, reason):
        self.owner = owner
        self.reason = reason
        super().__init__(reason)


class _Work:
    def __init__(self, check, limits):
        if (not callable(check) or type(limits) is not dict
                or any(type(k) is not str for k in limits) or set(limits) != set(LIMIT_KEYS)):
            raise DeclarationError('explicit check and exact search limits required')
        for k in LIMIT_KEYS:
            if type(limits[k]) is not int or limits[k] <= 0:
                raise DeclarationError('positive exact integer search limits required')
        if limits['data_depth'] > 128:
            raise DeclarationError('data_depth must be at most128')
        self.limits = dict(limits)
        self.check = check
        self.owner = object()
        self.total = 0
        self.counts = {}
        check()

    def step(self, kind, amount=1):
        self.total += amount
        self.counts[kind] = self.counts.get(kind, 0) + amount
        if self.total > self.limits['work']:
            raise SearchLimit(self.owner, 'work')
        self.check()

    def bound(self, kind, value):
        self.step('bound_checks')
        if value > self.limits[kind]:
            raise SearchLimit(self.owner, kind)

    def integer(self, value, coordinate=False, nonnegative=False):
        self.step('integer_checks')
        if type(value) is not int or (nonnegative and value < 0):
            raise DeclarationError('exact integer required')
        self.bound('integer_bits', abs(value).bit_length())
        if coordinate:
            self.bound('coordinate_abs', abs(value))
        return value

    def record(self):
        return {'attempted_work': self.total, 'by_kind': dict(self.counts),
                'cutoff': 'snapshot before subsequent output/callback/cleanup work'}


def _freeze(value, w):
    """Owned typed preimage; list/tuple/bool/int remain distinct."""
    active = set()
    seen = [0]

    def visit(x, depth):
        w.step('data_nodes')
        seen[0] += 1
        w.bound('data_items', seen[0])
        w.bound('data_depth', depth)
        t = type(x)
        if x is None:
            return ('null',)
        if t is bool:
            return ('bool', x)
        if t is int:
            w.integer(x)
            return ('int', x)
        if t is str:
            w.bound('string_chars', len(x))
            for char in x:
                w.step('string_characters')
                if 0xd800 <= ord(char) <= 0xdfff:
                    raise DeclarationError('Unicode scalar strings required')
            return ('str', x)
        if t not in (list, tuple, dict):
            raise DeclarationError('exact builtin finite data required')
        identity = id(x)
        if identity in active:
            raise DeclarationError('cyclic input data')
        active.add(identity)
        if t is dict:
            keys = []
            for key in x:
                w.step('object_keys')
                if type(key) is not str:
                    raise DeclarationError('string object keys required')
                keys.append(key)
            keys.sort()
            pairs = []
            for key in keys:
                pairs.append((visit(key, depth + 1), visit(x[key], depth + 1)))
            result = ('dict', tuple(pairs))
        else:
            children = []
            for item in x:
                children.append(visit(item, depth + 1))
            result = ('tuple' if t is tuple else 'list', tuple(children))
        active.remove(identity)
        return result

    return visit(value, 0)


def _thaw(value, w):
    w.step('detached_nodes')
    tag = value[0]
    if tag == 'null':
        return None
    if tag in ('bool', 'int', 'str'):
        return value[1]
    if tag == 'dict':
        out = {}
        for key, item in value[1]:
            out[_thaw(key, w)] = _thaw(item, w)
        return out
    items = []
    for item in value[1]:
        items.append(_thaw(item, w))
    return tuple(items) if tag == 'tuple' else items


def _point(value, w):
    if type(value) is not list or len(value) != 2:
        raise DeclarationError('literal two-coordinate list required')
    return (w.integer(value[0], coordinate=True), w.integer(value[1], coordinate=True))


def _color(value, w):
    # Oracle colors are immutable constructor tuples with str/int leaves.
    if type(value) is not tuple:
        raise DeclarationError('complete constructor tuple edge color required')
    token = _freeze(value, w)  # Depth/size checks precede the recursive scan.

    def inspect(x):
        w.step('color_nodes')
        if type(x) is tuple:
            if not x or type(x[0]) is not str:
                raise DeclarationError('every color tuple needs a string constructor')
            for child in x:
                inspect(child)
        elif type(x) not in (str, int):
            raise DeclarationError('color leaves must be exact str/int')

    inspect(value)
    return token


def _constraint(value, w):
    # Assigned scalar0 is an incompatible literal, never a missing mask slot.
    # The complete palette uses tuple colors; B proves scalar masks count0.
    if type(value) in (int, str):
        return _freeze(value, w)
    return _color(value, w)


class _Core:
    __slots__ = ('chosen', 'marks', 'domains', 'exclusions')

    def __init__(self, chosen, marks, domains, exclusions):
        object.__setattr__(self, 'chosen', chosen)
        object.__setattr__(self, 'marks', marks)
        object.__setattr__(self, 'domains', domains)
        object.__setattr__(self, 'exclusions', exclusions)

    def __setattr__(self, name, value):
        raise ReadOnlyViolation('immutable internal core')


class _Engine:
    def __init__(self, original, palette, descriptor, w, oracle_limits, observe, mode):
        self.w = w
        self.original = original
        self.original_descriptor = descriptor
        self.original_oracle_limits = oracle_limits
        self.palette = palette
        self.observe = observe
        self.mode = mode
        self.stage = 'ADMISSION'
        self.state = None
        self.initial = None
        self.frames = []
        self.journal = []
        self.queries = []
        self.solutions = []
        self.tiles = {}
        self.oracle_work = 0
        self.snapshot_count = 0
        self.input_owned = _freeze(original, w)
        self.descriptor_owned = _freeze(descriptor, w)
        self.oracle_limits_owned = _freeze(oracle_limits, w)
        if type(descriptor) is not tuple or len(descriptor) != 3 or descriptor[0] != 'implicit-wang-palette-v1':
            raise DeclarationError('immutable B palette descriptor required')
        if (type(oracle_limits) is not dict or set(oracle_limits) != set(ORACLE_LIMIT_KEYS)
                or any(type(oracle_limits[k]) is not int or oracle_limits[k] <= 0 for k in ORACLE_LIMIT_KEYS)):
            raise DeclarationError('exact positive oracle limits required')
        self.descriptor = _thaw(self.descriptor_owned, w)
        self.qlimits = _thaw(self.oracle_limits_owned, w)
        owned = _thaw(self.input_owned, w)
        keys = {'schema', 'required_centers', 'admissible_origins',
                'fixed_background_marks', 'root_generations'}
        if type(owned) is not dict or set(owned) != keys or owned['schema'] != SCHEMA:
            raise DeclarationError('exact implicit instance fields required')
        if type(owned['required_centers']) is not list or not owned['required_centers']:
            raise DeclarationError('nonempty finite required-center list required')
        self.centers = []
        used = set()
        for row in owned['required_centers']:
            w.step('centers')
            p = _point(row, w)
            if p in used or p[0] % 2 or p[1] % 2:
                raise DeclarationError('distinct signed-even centers required')
            used.add(p)
            self.centers.append(p)
        self.centers = tuple(self.centers)
        w.bound('sites', len(self.centers))
        if _freeze(owned['admissible_origins'], w) != _freeze(owned['required_centers'], w):
            raise DeclarationError('all and only required centers must be origins')
        generations = owned['root_generations']
        self.generation_profile = 'ALL_EXPLICIT_ROOTS_ZERO'
        if generations is None:
            self.generations = tuple(0 for _ in self.centers)
        else:
            self.generation_profile = 'EXPLICIT_ROOT_GENERATION_TEST_VARIANT'
            if type(generations) is not list or len(generations) != len(self.centers):
                raise DeclarationError('one explicit generation per root required')
            values = []
            for g in generations:
                values.append(w.integer(g, nonnegative=True))
            self.generations = tuple(values)
        pins = owned['fixed_background_marks']
        if type(pins) is not list:
            raise DeclarationError('literal background marking list required')
        w.bound('pins', len(pins))
        markmap = {}
        for row in pins:
            w.step('pins')
            if type(row) is not list or len(row) != 3 or type(row[1]) is not str:
                raise DeclarationError('pin [point,channel,value] required')
            point = _point(row[0], w)
            channel = row[1]
            value = _constraint(row[2], w) if channel == 'edge' else _freeze(row[2], w)
            key = (point, channel)
            if key in markmap:
                raise DeclarationError('duplicate fixed marking point/channel')
            markmap[key] = (value, 1, True)
        self.pin_marks = self._marks_tuple(markmap)
        dep = {}
        self.edges_at = []
        for i, center in enumerate(self.centers):
            sides = []
            for side, offset in enumerate(OFFSETS):
                point = (center[0] + offset[0], center[1] + offset[1])
                w.integer(point[0], coordinate=True)
                w.integer(point[1], coordinate=True)
                sides.append(point)
                dep.setdefault(point, []).append((i, side))
                w.step('midpoint_dependencies')
            self.edges_at.append(tuple(sides))
        w.bound('dependencies', 4 * len(self.centers))
        self.edges_at = tuple(self.edges_at)
        self.dependencies = tuple((p, tuple(dep[p])) for p in sorted(dep))
        self.depmap = {p: entries for p, entries in self.dependencies}
        domains = []
        empty = tuple(None for _ in self.centers)
        provisional = _Core(empty, self.pin_marks, (), ())
        for i in range(len(self.centers)):
            domains.append(self._domain(provisional, i))
        self.state = _Core(empty, self.pin_marks, tuple(domains), ())
        self.initial = self.state
        self._guard_inputs()

    def _guard_inputs(self):
        if (_freeze(self.original, self.w) != self.input_owned
                or _freeze(self.original_descriptor, self.w) != self.descriptor_owned
                or _freeze(self.original_oracle_limits, self.w) != self.oracle_limits_owned):
            raise ReadOnlyViolation('caller inputs changed')

    def _marks_tuple(self, mapping):
        out = []
        for point, channel in sorted(mapping):
            self.w.step('mark_rows')
            value, refs, fixed = mapping[point, channel]
            out.append((point, channel, value, refs, fixed))
        return tuple(out)

    def _mask(self, state, point):
        self.w.step('mask_mark_copy_items', len(state.marks))
        marks = {(p, ch): value for p, ch, value, refs, fixed in state.marks}
        result = []
        for p in self.edges_at[point]:
            self.w.step('mask_sides')
            result.append(marks.get((p, 'edge')))
        return tuple(result)

    def _mask_plain(self, mask):
        out = []
        for value in mask:
            out.append(None if value is None else _thaw(value, self.w))
        return tuple(out)

    def _oracle(self, operation, point, mask, index=None):
        w = self.w
        w.step('oracle_queries')
        w.bound('oracle_queries', len(self.queries) + 1)
        args = self._mask_plain(mask)
        qlimits = dict(self.qlimits)

        def charged_check():
            w.step('oracle_checkpoints')

        # Both wrappers are ordinary functions; no generator consumes a
        # delegated StopIteration.  Root authenticates the facade and module.
        if operation == 'count':
            raw = self.palette.count_query(self.descriptor, args, check=charged_check, limits=qlimits)
        else:
            raw = self.palette.select_query(self.descriptor, args, index, check=charged_check, limits=qlimits)
        if _freeze(qlimits, w) != self.oracle_limits_owned:
            raise ReadOnlyViolation('oracle mutated query limits')
        owned = _freeze(raw, w)
        receipt = _thaw(owned, w)
        if type(receipt) is not dict:
            raise OracleContractError('query receipt must be ordinary mapping')
        expected = {'schema', 'count', 'attempted_work', 'authority'}
        if operation == 'select':
            expected.add('tile')
        if (set(receipt) != expected
                or receipt['schema'] != 'implicit-wang-' + operation + '-receipt-v1'
                or receipt['authority'] is not False):
            raise OracleContractError('exact source-bound no-authority query receipt required')
        count = receipt.get('count')
        work = receipt.get('attempted_work')
        if type(count) is not int or count < 0 or type(work) is not int or work < 0:
            raise OracleContractError('exact nonnegative count/work required')
        w.integer(count, nonnegative=True)
        w.integer(work, nonnegative=True)
        self.oracle_work += work
        self.queries.append({'operation': operation, 'point': point,
                             'mask': args, 'index': index, 'receipt': receipt})
        return receipt

    def _matches(self, colors, mask):
        for color, constraint in zip(colors, mask):
            self.w.step('literal_color_comparisons')
            if constraint is not None and color != constraint:
                return False
        return True

    def _domain(self, state, point):
        if state.chosen[point] is not None:
            return None
        mask = self._mask(state, point)
        count = self._oracle('count', point, mask)['count']
        matching = []
        for p, identity, support in state.exclusions:
            self.w.step('exclusion_membership')
            if p == point:
                if identity not in self.tiles:
                    raise OracleContractError('missing literal exclusion tile')
                if self._matches(self.tiles[identity][0], mask):
                    matching.append(identity)
        if len(set(matching)) != len(matching) or len(matching) > count:
            raise OracleContractError('invalid matching exclusion census')
        return (mask, count, tuple(matching), count - len(matching))

    def _tile(self, raw, mask):
        w = self.w
        if type(raw) is not dict or set(raw) != {'id', 'kind', 'origin', 'edges_NESW', 't', 'm'}:
            raise OracleContractError('complete literal tile record required')
        identity = raw['id']
        if (type(identity) is not tuple or len(identity) != 2 or type(raw['kind']) is not str
                or type(raw['origin']) is not tuple or identity[0] != raw['kind']
                or _freeze(identity[1], w) != _freeze(raw['origin'], w)):
            raise OracleContractError('semantic kind/origin identity required')
        fid = _freeze(identity, w)
        edges = raw['edges_NESW']
        if type(edges) is not tuple or len(edges) != 4:
            raise OracleContractError('complete four-edge tuple required')
        color_rows = []
        for edge in edges:
            color_rows.append(_color(edge, w))
        colors = tuple(color_rows)
        if _freeze(raw['t'], w) != _freeze([[[0, 0], 1]], w):
            raise OracleContractError('singleton-center exact t=1 required')
        expected_m = []
        for offset, value in zip(OFFSETS, edges):
            expected_m.append([[offset[0], offset[1]], 'edge', value])
        if _freeze(raw['m'], w) != _freeze(expected_m, w):
            raise OracleContractError('all and only NESW midpoint marks required')
        if not self._matches(colors, mask):
            raise OracleContractError('selected tile violates exact mask')
        full = _freeze(raw, w)
        if fid in self.tiles:
            if self.tiles[fid] != (colors, full):
                raise OracleContractError('same semantic tile ID changed literal data')
        else:
            w.bound('selected_tiles', len(self.tiles) + 1)
            self.tiles[fid] = (colors, full)
        return fid, colors

    def _select(self, state, point, rank):
        domain = state.domains[point]
        if domain is None or type(rank) is not int or not 0 <= rank < domain[3]:
            raise OracleContractError('rank outside complete active domain')
        # Conditional ranks never advance across an exclusion insertion.  We
        # restart the original masked enumeration and skip exact matching IDs.
        remaining = rank
        excluded = set(domain[2])
        seen = set()
        for index in range(domain[1]):
            self.w.step('rank_scan')
            receipt = self._oracle('select', point, domain[0], index)
            if receipt['count'] != domain[1] or 'tile' not in receipt:
                raise OracleContractError('select/count consistency required')
            fid, colors = self._tile(receipt['tile'], domain[0])
            if fid in seen:
                raise OracleContractError('duplicate semantic ID in selected rank prefix')
            seen.add(fid)
            if fid not in excluded:
                if remaining == 0:
                    return fid, colors
                remaining -= 1
        raise OracleContractError('full rank exhaustion disagrees with exact degree')

    def _decision(self):
        frontier = []
        for i, domain in enumerate(self.state.domains):
            self.w.step('global_frontier_checks')
            if self.state.chosen[i] is None:
                if domain is None:
                    raise OracleContractError('missing frontier domain')
                frontier.append((i, domain[3]))
        for point, degree in frontier:
            self.w.step('global_dead_checks')
            if degree == 0:
                return ('DEAD', point, 0)
        for point, degree in frontier:
            self.w.step('global_forced_checks')
            if degree == 1:
                return ('FORCED', point, 1)
        if not frontier:
            return ('COMPLETE', None, 0)
        selected = min(frontier, key=lambda row: (self.generations[row[0]], row[1], row[0]))
        return ('BRANCH', selected[0], selected[1])

    def _support(self, state):
        out = []
        for i, value in enumerate(state.chosen):
            self.w.step('support_rows')
            if value is not None:
                out.append((i, value[0]))
        return tuple(out)

    def _place(self, point, fid, colors):
        old = self.state
        if old.chosen[point] is not None or fid in old.domains[point][2]:
            raise OracleContractError('occupied/excluded placement')
        self.w.step('placement_attempts')
        self.w.bound('choices', self.w.counts['placement_attempts'])
        self.w.step('core_mark_copy_items', len(old.marks))
        marks = {(p, ch): (value, refs, fixed) for p, ch, value, refs, fixed in old.marks}
        changed = set()
        for p, value in zip(self.edges_at[point], colors):
            self.w.step('placed_mark_rows')
            key = (p, 'edge')
            if key in marks:
                previous, refs, fixed = marks[key]
                if value != previous:
                    raise OracleContractError('placement contradicts live section')
                marks[key] = (value, refs + 1, fixed)
            else:
                marks[key] = (value, 1, False)
                changed.add(p)
        self.w.step('core_chosen_copy_items', len(old.chosen))
        chosen = list(old.chosen)
        chosen[point] = (fid, colors, self.generations[point] + 1)
        provisional = _Core(tuple(chosen), self._marks_tuple(marks), old.domains, old.exclusions)
        affected = {point}
        for p in changed:
            for i, side in self.depmap.get(p, ()):
                self.w.step('affected_reverse_dependencies')
                affected.add(i)
        self.w.step('core_domain_copy_items', len(old.domains))
        domains = list(old.domains)
        for i in sorted(affected):
            self.w.step('incremental_domain_updates')
            domains[i] = self._domain(provisional, i)
        # Sole core publication; unrelated domain objects remain identical.
        self.state = _Core(provisional.chosen, provisional.marks, tuple(domains), old.exclusions)

    def _exclude(self, point, fid):
        old = self.state
        support = self._support(old)
        for p, identity, context in old.exclusions:
            self.w.step('new_exclusion_checks')
            if p == point and identity == fid:
                raise OracleContractError('duplicate failed-child exclusion')
        exclusions = old.exclusions + ((point, fid, support),)
        provisional = _Core(old.chosen, old.marks, old.domains, exclusions)
        self.w.step('core_domain_copy_items', len(old.domains))
        domains = list(old.domains)
        domains[point] = self._domain(provisional, point)
        self.state = _Core(old.chosen, old.marks, tuple(domains), exclusions)

    def _event(self, kind, point=None, fid=None, detail=None):
        self.w.step('journal_rows')
        self.w.bound('events', len(self.journal) + 1)
        self.journal.append({'seq': len(self.journal), 'kind': kind, 'point': point,
                             'id': None if fid is None else _thaw(fid, self.w),
                             'detail': detail})

    def _core_plain(self, state):
        points = []
        chosen = []
        domains = []
        for i, center in enumerate(self.centers):
            self.w.step('snapshot_core_rows')
            value = state.chosen[i]
            points.append([i, list(center), 0 if value is None else 1, self.generations[i]])
            if value is not None:
                edge_values = []
                for color in value[1]:
                    edge_values.append(_thaw(color, self.w))
                chosen.append([i, _thaw(value[0], self.w),
                               tuple(edge_values), value[2]])
            domain = state.domains[i]
            if domain is None:
                domains.append(None)
            else:
                domains.append({'point': i, 'mask': self._mask_plain(domain[0]),
                                'physical_count': domain[1],
                                'matching_exclusions': [_thaw(x, self.w) for x in domain[2]],
                                'degree': domain[3]})
        marks = []
        for p, ch, value, refs, fixed in state.marks:
            marks.append([list(p), ch, _thaw(value, self.w), refs, fixed])
        exclusions = []
        for point, identity, support in state.exclusions:
            exclusions.append({'point': point, 'id': _thaw(identity, self.w),
                               'parent_support': [[i, _thaw(x, self.w)] for i, x in support]})
        return {'points': points, 'chosen': chosen, 'marks': marks,
                'domains': domains, 'exclusions': exclusions}

    def _observe(self, reason, rollback_parent=None):
        if self.observe is None:
            return
        self.w.step('snapshots')
        self.snapshot_count += 1
        self.w.bound('snapshots', self.snapshot_count)
        body = self._core_plain(self.state)
        frames = []
        for frame in self.frames:
            self.w.step('snapshot_frames')
            frames.append({'parent': self._core_plain(frame['parent']),
                           'point': frame['point'], 'id': _thaw(frame['id'], self.w),
                           'next_rank': frame['next_rank'], 'degree': frame['degree']})
        body.update({'schema': SNAPSHOT, 'reason': reason, 'mode': self.mode,
                     'palette_descriptor': _thaw(self.descriptor_owned, self.w),
                     'dependencies': [[list(p), [[i, side] for i, side in entries]]
                                      for p, entries in self.dependencies],
                     'branch_stack': frames, 'scheduler': list(self._decision()),
                     'rollback_parent': None if rollback_parent is None else self._core_plain(rollback_parent),
                     'work': self.w.record()})
        before = _freeze(body, self.w)
        # Counts the full typed snapshot tree, not just its outer rows.
        size = [0]

        def count_nodes(token):
            self.w.step('snapshot_items')
            size[0] += 1
            self.w.bound('snapshot_items', size[0])
            if token[0] in ('tuple', 'list'):
                for item in token[1]:
                    count_nodes(item)
            elif token[0] == 'dict':
                for key, item in token[1]:
                    count_nodes(key)
                    count_nodes(item)

        count_nodes(before)
        self.observe(body)
        if _freeze(body, self.w) != before:
            raise ReadOnlyViolation('observer mutated detached snapshot')

    def _verify_solution(self):
        self.w.step('terminal_pin_copy_items', len(self.pin_marks))
        reconstructed = {(p, ch): (value, refs, fixed)
                         for p, ch, value, refs, fixed in self.pin_marks}
        placements = []
        for i, selected in enumerate(self.state.chosen):
            self.w.step('terminal_centers')
            if selected is None or self.state.domains[i] is not None:
                raise OracleContractError('terminal must fill every required center')
            fid, colors, generation = selected
            if fid not in self.tiles:
                raise OracleContractError('missing complete selected tile')
            for p, value in zip(self.edges_at[i], colors):
                self.w.step('terminal_mark_rows')
                key = (p, 'edge')
                if key in reconstructed:
                    old, refs, fixed = reconstructed[key]
                    if old != value:
                        raise OracleContractError('whole target mark conflict')
                    reconstructed[key] = (old, refs + 1, fixed)
                else:
                    reconstructed[key] = (value, 1, False)
            placements.append({'point': i, 'origin': list(self.centers[i]),
                               'id': _thaw(fid, self.w),
                               'tile': _thaw(self.tiles[fid][1], self.w),
                               'generation': generation})
        if self._marks_tuple(reconstructed) != self.state.marks:
            raise OracleContractError('whole reconstructed marking/refcount section differs')
        self.w.bound('solutions', len(self.solutions) + 1)
        self.solutions.append({'schema': 'implicit-wang-point-solution-v1',
                               'placements': placements, 'whole_target_checked': True,
                               'mathematical_authority': False})

    def _restore_frame(self, frame):
        self._observe('BEFORE_ROLLBACK', frame['parent'])
        self._event('ROLLBACK_BEGIN', frame['point'], frame['id'])
        self.w.step('immutable_core_restorations')
        self.state = frame['parent']
        self._event('ROLLBACK_END', frame['point'], frame['id'])
        self._observe('AFTER_ROLLBACK', frame['parent'])

    def _finish(self, status, exhaustive):
        self._observe('BEFORE_ROOT_RESTORE')
        self.w.step('final_root_restorations')
        self.state = self.initial
        self.frames = []
        self._event('ROOT_RESTORED')
        self._observe('ROOT_RESTORED')
        self._guard_inputs()
        self.w.check()
        return {'schema': 'implicit-wang-point-search-result-v1', 'version': VERSION,
                'profile': PROFILE, 'status': status, 'exhaustive': exhaustive,
                'mode': self.mode, 'generation_profile': self.generation_profile,
                'solutions': self.solutions, 'journal': self.journal,
                'query_journal': self.queries, 'work': self.w.record(),
                'oracle_attempted_work_total': self.oracle_work,
                'root_restored': True, 'final_observation_completed': self.observe is not None,
                'mathematical_authority': False}

    def run(self):
        self.stage = 'SEARCH'
        self._observe('INITIAL')
        backtracking = False
        while True:
            self._observe('BEFORE_DECISION')
            decision, point, degree = self._decision()
            self._event(decision, point, detail={'degree': degree})
            if decision == 'COMPLETE':
                self._verify_solution()
                if self.mode == 'first':
                    return self._finish('SOLUTION_FOUND', False)
                backtracking = True
            elif decision == 'DEAD':
                backtracking = True
            elif decision == 'FORCED':
                fid, colors = self._select(self.state, point, 0)
                self._event('PLACE_FORCED_BEGIN', point, fid)
                self._place(point, fid, colors)
                self._event('PLACE_FORCED_COMMITTED', point, fid)
                continue
            else:
                fid, colors = self._select(self.state, point, 0)
                self.w.bound('frames', len(self.frames) + 1)
                self.frames.append({'parent': self.state, 'point': point, 'id': fid,
                                    'next_rank': 1, 'degree': degree})
                self._event('PLACE_BRANCH_BEGIN', point, fid)
                self._place(point, fid, colors)
                self._event('PLACE_BRANCH_COMMITTED', point, fid)
                continue
            if backtracking:
                resumed = False
                while self.frames:
                    frame = self.frames.pop()
                    self._restore_frame(frame)
                    if self.mode == 'first':
                        # Reaching this path in FIRST means the selected child
                        # failed exhaustively (success returns immediately).
                        self._exclude(frame['point'], frame['id'])
                        self._event('FAILED_CHILD_EXCLUDED', frame['point'], frame['id'])
                        resumed = True
                        break
                    if frame['next_rank'] < frame['degree']:
                        # ALL has no graph exclusions: its cursor means only
                        # enumerated alternatives, never a proved impossibility.
                        self._observe('BEFORE_DECISION')
                        current = self._decision()
                        if current != ('BRANCH', frame['point'], frame['degree']):
                            raise OracleContractError('restored ALL parent decision changed')
                        self._event('BRANCH_CONTINUATION', frame['point'],
                                    detail={'rank': frame['next_rank']})
                        fid, colors = self._select(self.state, frame['point'], frame['next_rank'])
                        frame = {'parent': frame['parent'], 'point': frame['point'], 'id': fid,
                                 'next_rank': frame['next_rank'] + 1, 'degree': frame['degree']}
                        self.frames.append(frame)
                        self._event('PLACE_BRANCH_BEGIN', frame['point'], fid)
                        self._place(frame['point'], fid, colors)
                        self._event('PLACE_BRANCH_COMMITTED', frame['point'], fid)
                        resumed = True
                        break
                if not resumed:
                    status = 'ALL_SOLUTIONS_EXHAUSTED' if self.mode == 'all' else 'EXHAUSTED_NO_SOLUTION'
                    return self._finish(status, True)
                backtracking = False


def search(instance, palette_module, descriptor, *, check, limits, oracle_limits,
           observe=None, mode='first'):
    """Complete finite implicit-domain search under the independently certified ABI.

    The immutable descriptor and actual module/facade must be Source-bound by
    the caller.  Expected oracle failures are not translated to domain counts.
    Only this invocation's exact own limit becomes UNKNOWN_SEARCH_LIMIT.
    """
    if type(mode) is not str or mode not in ('first', 'all') or (observe is not None and not callable(observe)):
        raise DeclarationError('explicit first/all mode and optional callback required')
    w = _Work(check, limits)
    engine = None
    try:
        engine = object.__new__(_Engine)
        _Engine.__init__(engine, instance, palette_module, descriptor, w, oracle_limits, observe, mode)
        return engine.run()
    except BaseException as error:
        # Constant-size root reference restoration; no callback after a stop.
        # Output/metadata/cleanup wall and memory remain charged by outer gates.
        if engine is not None and engine.initial is not None:
            engine.state = engine.initial
            engine.frames = []
        prefix = None
        try:
            prefix = {'schema': 'implicit-wang-search-unfinished-prefix-v1',
                      'status': 'FAILED_OR_UNFINISHED', 'mathematical_authority': False,
                      'exhaustive': False, 'stage': 'ADMISSION' if engine is None else engine.stage,
                      'events_completed': 0 if engine is None else len(engine.journal),
                      'solutions_completed': 0 if engine is None else len(engine.solutions),
                      'oracle_completed_queries': 0 if engine is None else len(engine.queries),
                      'oracle_completed_attempted_work': 0 if engine is None else engine.oracle_work,
                      'journal': [] if engine is None else engine.journal,
                      'query_journal': [] if engine is None else engine.queries,
                      'solutions': [] if engine is None else engine.solutions,
                      'retention_scope': 'whole available ordinary completed rows; no post-stop core projection or callback',
                      'root_restored': engine is not None and engine.initial is not None,
                      'final_observation_completed': False, 'work': w.record()}
        except BaseException:
            pass  # Diagnostic construction must not replace the active error.
        if prefix is None:
            raise
        if type(error) is SearchLimit and error.owner is w.owner:
            return {'schema': 'implicit-wang-point-search-result-v1', 'version': VERSION,
                    'profile': PROFILE, 'status': 'UNKNOWN_SEARCH_LIMIT',
                    'reason': error.reason, 'exhaustive': False, 'mode': mode,
                    'solutions': [] if engine is None else engine.solutions,
                    'journal': [] if engine is None else engine.journal,
                    'query_journal': [] if engine is None else engine.queries,
                    'interrupted_oracle_prefix': getattr(error, 'implicit_palette_prefix', None),
                    'unfinished_prefix': prefix, 'work': w.record(),
                    'mathematical_authority': False}
        try:
            error.implicit_search_prefix = prefix
        except BaseException:
            pass
        raise
