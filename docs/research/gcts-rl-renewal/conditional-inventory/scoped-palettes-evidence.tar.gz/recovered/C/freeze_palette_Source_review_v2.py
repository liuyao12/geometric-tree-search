"""Raw/AST independent review metadata only; no subject evaluation."""
import ast
import hashlib
import json
from pathlib import Path

D = Path('/private/tmp/gcts-implicit-review-C-20261020-v1')
B = Path('/private/tmp/gcts-implicit-wang-B-20261020-v2')
P = Path('/private/tmp/gcts-implicit-wang-B-20261020-v1/implicit_wang_palette_v1.py')
S = B / 'implicit_wang_palette_v2.py'

def pin(path):
    path = Path(path)
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

old, new = P.read_text(), S.read_text()
assert pin(P)['sha256'] == 'fa6a6a122fffe88111fe010a6af5b9676684caeddf62678b5d2ec0d9bc77e7ae'
assert pin(S) == {'path': str(S), 'bytes': 22683,
                  'sha256': '9ba1bd5ea53c899a24488ff474ed77f88ab4d9f159c3d4131a6c8c3d1cad73cf'}
changes = [
    ("VERSION = 'implicit-wang-palette-v1'", "VERSION = 'implicit-wang-palette-v2'"),
    ("    result = tuple(_int(value[k], 0, b, work) for k in ('zero', 'one', 'terminator'))",
     "    copied = []\n    for key in ('zero', 'one', 'terminator'):\n        copied.append(_int(value[key], 0, b, work))\n    result = tuple(copied)"),
    ("        return tuple(_fill(item, values, work) for item in expression)",
     "        copied = []\n        for item in expression:\n            copied.append(_fill(item, values, work))\n        return tuple(copied)")
]
forward, reverse = old, new
for before, after in changes:
    assert forward.count(before) == 1 and reverse.count(after) == 1
    forward = forward.replace(before, after, 1)
    reverse = reverse.replace(after, before, 1)
assert forward == new and reverse == old
ot, nt = ast.parse(old), ast.parse(new)
compile(nt, str(S), 'exec')  # unused; no exec/import
om = {n.name:n for n in ot.body if isinstance(n,(ast.FunctionDef, ast.ClassDef))}
nm = {n.name:n for n in nt.body if isinstance(n,(ast.FunctionDef, ast.ClassDef))}
assert om.keys() == nm.keys()
unchanged = []
for name in om:
    if name not in ('_wire_record', '_fill'):
        assert ast.dump(om[name], include_attributes=False) == ast.dump(nm[name], include_attributes=False)
        unchanged.append(name)
generators = []
for node in ast.walk(nt):
    if isinstance(node, ast.GeneratorExp):
        calls = [x.func.id if isinstance(x.func,ast.Name) else ast.dump(x.func)
                 for x in ast.walk(node) if isinstance(x,ast.Call)]
        assert calls and set(calls) == {'type'}
        generators.append({'line':node.lineno,'calls':calls})
assert len(generators) == 3
assert not any(isinstance(n,(ast.Yield,ast.YieldFrom,ast.Import,ast.ImportFrom)) for n in ast.walk(nt))
handoff = json.loads((B/'handoff-v2.json').read_text())
for item in handoff['files']:
    assert pin(item['path']) == item
assert pin(handoff['parent']['path']) == handoff['parent']

manual = [
    'The six disjoint head-position/motion step cases agree with the legacy radius-one local rule; accepting/undefined heads yield no step tile, and only a centered head crossing its destination wall is refused.',
    'Every complete cell color remains in frames, even when its transition is undefined; no reachability, certificate, target, tape-width or horizon trimming enters the descriptor.',
    'Every collector, step frame, accept frame and initializer phase/head flag family is retained with semantic kind/origin identity; no edge-value quotient merges distinct identities.',
    'The no-head, left-head, centered-head and right-head family domains are disjoint. Canonical deterministic transition rows prevent duplicate head triples within a family.',
    'Repeated variables in N/E/S/W patterns share one fixed rank. Intersecting all assigned masks therefore detects inconsistent center or copied-symbol constraints before multiplying domain sizes.',
    'Each surviving Cartesian family has product cardinality; prefix sums and mixed-radix unranking select each family member once. Enumeration order is deterministic but is not legacy numeric-ID order.',
    'None is absent only at the four outer mask slots. Exact scalar zero is an incompatible assigned value against tuple colors; bool/subclasses/nested None are invalid, and constructor integer zero remains assigned.',
    'Selected tile output retains full semantic ID/origin/constructor colors, exact singleton t and all four midpoint m rows; tuple-to-array JSON requires explicit schema restoration.',
    'Descriptor queries revalidate the complete immutable recipe; build rereads mutable inputs. This is endpoint reconciliation under exclusive/read-only callbacks, not hostile concurrent mutation protection.',
    'Private Invalid/Limit require exact class plus private owner. A foreign same-class object is not normalized to owned refusal or zero matches.',
    'Both callback-bearing reconstructions now execute in ordinary explicit loops. The remaining three generator expressions can call only builtin type on exact dict keys; no callback-bearing path crosses their bodies.',
    'Best-effort failure attachment catches its own errors and bare-rethrows the primary exception; constructor failed cost can be unavailable and is not fabricated as zero.',
    'All numeric atom/domain/product/count/rank bounds remain declared; operation units are private charged work, not CPU instructions or bytes. Per-call budgets do not establish invocation-total admission.',
    'The exact old initializer cardinality formula and factorized family sum agree manually, while represented mathematical cardinality remains separate from emitted/retained JSON size.',
    'Every public call is still unexecuted. Source correspondence does not certify graph integration, selector-strip qualification, a physical VM, theorem discovery, universal tiling or benefit.'
]
receipt = {
    'schema':'implicit-wang-palette-typed-Source-review-v2',
    'reviewer_identity':'/root/conventional_control_review',
    'author_identity':'/root/benchmark_design',
    'source_review_passed':True,
    'source_only':True,
    'component_calls':0,
    'scientific_calls':0,
    'scientific_acceptance':False,
    'actual_execution_authorized':False,
    'subject':pin(S),
    'handoff':pin(B/'handoff-v2.json'),
    'bound_metadata':[pin(B/name) for name in ('API-v2.json','proof-delta-v2.json','conformance-v2.json','correspondence-v2.html')],
    'current_master':pin('/private/tmp/gcts-fixed-initializer-ROOT-20261020-v1/basic-tiling-algorithm-current.md'),
    'legacy_references':[pin('/private/tmp/gcts-wang-spacetime-library-20261019/wang_spacetime_compiler_v1.py'),pin('/private/tmp/gcts-fixed-initializer-ROOT-20261020-v1/wang_unknown_certificate_initializer_v1.py')],
    'negative_ancestor':pin(D/'typed-implicit-palette-Source-negative-v1.json'),
    'obligations_ancestor':pin(D/'independent-implicit-obligations-v1.json'),
    'mechanical_checks':{
        'both_raw_text_directions_exact':True,
        'only_VERSION_wire_loop_fill_loop_changed':True,
        'unchanged_definition_AST_names':unchanged,
        'remaining_callback_free_generators':generators,
        'no_imports_or_yields':True,
        'discarded_unused_compile_passed':True,
        'all_handoff_file_raw_pins_exact':True
    },
    'manual_Source_checks':manual,
    'cardinality_argument':{
        'variables':'b symbols; Q states; D defined transitions; D0 stationary transitions; A=b(Q+1)',
        'six_disjoint_step_counts':['b(b+1)^2','Db(b+1)','D_minus b(b+1)','D0(b+1)^2','D_plus b(b+1)','Db(b+1)'],
        'step_total':'b(b+1)^2 + 3Db(b+1) + D0(b+1)',
        'base_total':'step_total + 3b + 2A + 2',
        'initializer_total':'9b + 16',
        'full_total':'step_total + 12b + 2A + 18',
        'proof_status':'Independent manual Source derivation; no palette/count/select operation evaluated.'
    },
    'prospective_exception_checks':{
        'B_advertises_Source_derived_callback_numbers':[1,14,95],
        'executed':False,
        'scope':'These are prospective finite diagnostic anchors, not observed evidence. A later full worker review must bind actual inputs, charged Root guard first, exact precreated StopIteration identity and reach records; no runtime coverage is inherited here.'
    },
    'limitations':[
        'Narrow Source PASS for exact B V2 only; no actual/process/grant/prospective full subject is approved.',
        'No whole large palette materialization or runtime fit claim; all nonempty small masks plus declared empty masks are still prospective coverage, not every zero-query Cartesian combination.',
        'The full palette must remain available at every allowed origin; Root/L must independently bind tuple-color semantics, all midpoint dependencies, global scheduler, exact exclusion context, rollback and aggregate cost.',
        'Exclusive-owner raw Source loading and endpoint input reconciliation are trust assumptions; no OS or comprehensive compiled-object integrity seal is implied.',
        'Current graph and Root worker drafts remain outside this receipt; no full components or prospective protocol PASS is inferred.',
        'Earlier V1 Source-negative and failed snapshot remain preserved. This reviewer has retained ancestry overlap in old controls/reviews and is not claiming a distinct kernel certification.'
    ]
}
out = D/'typed-implicit-palette-Source-review-v2.json'
assert not out.exists()
out.write_text(json.dumps(receipt,ensure_ascii=False,allow_nan=False,indent=2)+'\n')
print(json.dumps(pin(out),sort_keys=True))
