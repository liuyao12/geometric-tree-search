"""Raw text/AST/ordinary metadata only. No worker or helper is imported/called."""
import ast
import difflib
import hashlib
import json
from pathlib import Path

D = Path('/private/tmp/gcts-implicit-retention-L-20261020-v1')
P = Path('/private/tmp/gcts-implicit-ROOT-20261020-v1/qualify_implicit_worker_v1.py')
R = Path('/private/tmp/gcts-implicit-ROOT-20261020-v1/run_implicit_once_v1.py')
M = Path('/private/tmp/gcts-fixed-initializer-ROOT-20261020-v1/basic-tiling-algorithm-current.md')


def pin(path):
    raw = Path(path).read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def write(name, raw):
    path = D / name
    if path.exists():
        raise RuntimeError('no overwrite: ' + str(path))
    path.write_bytes(raw)
    return pin(path)


def document(name, value):
    return write(name, (json.dumps(value, sort_keys=True, ensure_ascii=True, indent=2) + '\n').encode())


def main():
    parent = P.read_text()
    pp = pin(P)
    assert pp['sha256'] == '88dbad5fdd008777bb47de8cbed48742f93ee319a27c2ab1354f9178684176ca'
    assert pp['bytes'] == 56779
    master = pin(M)
    assert master['sha256'] == 'c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9'
    helper = (D / 'summary_helpers.fragment.py').read_text()
    old_version = "VERSION = 'complete-implicit-palette-point-graph-worker-v1'"
    new_version = "VERSION = 'complete-implicit-palette-point-graph-worker-v2-summary-first'"
    seam = "        primary=s.first_fault if s.first_fault is not None else error\n"
    added = ("        early_summary = None\n"
             "        try:\n"
             "            early_summary = _write_failure_summary(s, _failure_summary_record(s, primary))\n"
             "        except BaseException:\n"
             "            pass  # Metadata-only attempt cannot change the selected primary fault.\n")
    update = "        failure.update(subject_prefix=getattr(primary,'implicit_palette_prefix',None),graph_prefix=getattr(primary,'implicit_search_prefix',None))\n"
    extra = "        failure['early_failure_summary'] = early_summary\n"
    assert parent.count(old_version) == parent.count(seam) == parent.count(update) == 1
    assert parent.count('class Session:\n') == 1
    candidate = parent.replace(old_version, new_version, 1)
    candidate = candidate.replace('class Session:\n', helper + '\n\nclass Session:\n', 1)
    candidate = candidate.replace(seam, seam + added, 1).replace(update, update + extra, 1)
    reverse = candidate.replace(new_version, old_version, 1)
    reverse = reverse.replace(helper + '\n\nclass Session:\n', 'class Session:\n', 1)
    reverse = reverse.replace(seam + added, seam, 1).replace(update + extra, update, 1)
    assert reverse == parent
    path = D / 'qualify_implicit_worker_v2_summary_first.py'
    pt = ast.parse(parent, filename=str(P))
    ct = ast.parse(candidate, filename=str(path))
    ht = ast.parse(helper)
    compile(ct, str(path), 'exec', dont_inherit=True, optimize=0)
    compile(ht, str(D / 'summary_helpers.fragment.py'), 'exec', dont_inherit=True, optimize=0)
    old_defs = {n.name: n for n in pt.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}
    new_defs = {n.name: n for n in ct.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}
    retained = []
    for name, node in old_defs.items():
        if name != 'main':
            assert ast.dump(node, include_attributes=False) == ast.dump(new_defs[name], include_attributes=False)
            retained.append(name)
    assert [ast.dump(n, include_attributes=False) for n in pt.body if isinstance(n, (ast.Import, ast.ImportFrom))] == [ast.dump(n, include_attributes=False) for n in ct.body if isinstance(n, (ast.Import, ast.ImportFrom))]
    assert not any(isinstance(n, (ast.GeneratorExp, ast.Yield, ast.YieldFrom)) for n in ast.walk(ht))
    source = write(path.name, candidate.encode())
    forward = write('parent-to-summary-first.patch', ''.join(difflib.unified_diff(parent.splitlines(True), candidate.splitlines(True), fromfile=str(P), tofile=str(path))).encode())
    inverse = write('summary-first-to-parent.patch', ''.join(difflib.unified_diff(candidate.splitlines(True), parent.splitlines(True), fromfile=str(path), tofile=str(P))).encode())
    common = dict(author_identity='/root/conventional_library', source_only=True,
        scientific_calls=0, subject_imports=0, subject_function_calls=0,
        helper_calls=0, fixture_calls=0, driver_calls=0, compiler_calls=0,
        checker_calls=0, simulator_calls=0, actual_execution_authorized=False,
        runtime_qualified=False, current_master=master, parent_worker=pp,
        unchanged_runner=pin(R), future_worker=source)
    contract = dict(common, schema='implicit-negative-summary-first-Source-contract-v1',
        status='FUTURE_SOURCE_ONLY_NOT_ADOPTED',
        scope='Only own VERSION and negative-handler summary ordering/helpers. Every existing non-main function/class, including Session.check/call/write_json, raw inverse+AST retained. Full mathematical cohort/algorithms/limits and all original failed artifacts unchanged.',
        helper_API=['_failure_summary_record(session, primary)->small owned ordinary diagnostic record',
                    '_write_failure_summary(session, summary)->descriptor or raises secondary diagnostic error'],
        record_schema='implicit-worker-failure-summary-v1',
        output_name='worker-failure-summary.json', temporary_name='worker-failure-summary.json.partial',
        order=['select existing Root first-fault latch or original caught error',
               'construct capped scalar summary and try one bounded exclusive partial-file write/fsync/rename',
               'construct inherited full failure record',
               'attempt unchanged whole failed-prefix JSON retention',
               'attempt inherited full worker-failure JSON retention; return original failure code2'],
        first_fault='No str(error), repr(error), traceback formatting, active-row clone or subject-prefix traversal. Retains bounded class name and only exact-str first BaseException.args member via built-in descriptor, with available/truncated flags. No arbitrary exception rendering or token normalization.',
        counters='Three maps each first16 insertion-order entries, labels48characters, exact uint63-orNone, total/truncated metadata. Original s.active exact-string ID retained; dict fallback is diagnostic-only for a future layout. s.rows length is completed-case count; component_rows/diagnostics lengths are progress/retained records, NOT claimed completed components. Other summaries are O(1) owned-list lengths and bounded row IDs/stages, not mathematical conclusions. Unknown/unavailable remainsNone with flags, never fabricated0.',
        static_bound={'counter_rows_each': 16, 'counter_maps': 3, 'label_characters': 48,
                      'other_variable_characters': 1024, 'maximum_ascii_escape_bytes_per_character': 12,
                      'per_counter_row_other_bytes_bound': 128, 'fixed_overhead_bound': 8192,
                      'derived_record_upper_bound_bytes': 3*16*(48*12+128)+1024*12+8192,
                      'hard_serialized_body_plus_LF_cap': 65536,
                      'directory_entries_observed_at_most': 64,
                      'scope': 'Manual Source bound for the exact record producer and pinned compact ensure_ascii JSON formatter, not arbitrary summary argument. Writer separately checks actual serialized length. Each OS operation can still block/fail.'},
        custody='Private exclusive actual-directory ownership; no symlink/nonregular file accepted by bounded prewrite ledger; exclusive no-follow partial creation, flush+file fsync, atomic name publication, no overwrite or retry. A raw descriptor is returned only after observed publication before original210. No directory-fsync/universal crash durability or hostile-race guarantee.',
        caps='Original180 success/known-exit/full outputs and210 negative custody remain unchanged. Same1GiB/128MiB/log/outer9MiB reserve; prewrite current root-file sizes+summary+original reserve must fit128MiB. Later bulk prior census includes the summary; parent final ledger remains authoritative. No allowance is increased.',
        parent_race='Current parent starts TERM cleanup at180; worker closure=True allows writes only until210 but supplies no guaranteed grace. TERM may arrive before handler, during record/write/fsync/rename or before final failure file. This patch improves ordering only if reached and completed; it guarantees neither deadline evidence nor universal storage retention.',
        negative_only='Even a complete summary is diagnostic-only with authority/resource/full-pipeline/mathematical flagsfalse; no positive header, result, exhausted/solved label or current failed prefix is admitted. Current timeout lacks usable stage/counters and is not repaired or retrospectively interpreted.',
        error_precedence='Summary construction/write error is attachment-only, caught without changing s.first_fault or primary. Existing later full failure path remains inherited and may itself fail. New helper never calls Root check/Source/subject/fixture/math functions after a stop. Its wall/RSS/I/O bytes remain charged by original outer gates.',
        new_closure_gate='New future worker Source pin/stdlib census/declaration/plan/independent review/fresh oncegrant required before any import or call. Existing grants are retired; no launch permission follows.',
        unresolved=['No runtime test or observed diagnostic improvement.',
                    'If deadline-independent observability is required, separately predeclare bounded predeadline progress records plus parent termination cause, with fresh overhead/profile review. Do not delay positive180 or silently grant computation until210.',
                    'Summary capped labels/counters can be truncated; full available prefix is still required for full evidence. Metadata-only output is not a replacement for whole cohort completion.'])
    contract_pin = document('Source-contract-v1.json', contract)
    api_pin = document('API-v1.json', dict(common, schema='implicit-negative-summary-first-API-v1',
        public_main='main(plan_path) unchanged; this is not authorized to run',
        new_helpers=contract['helper_API'], record_schema=contract['record_schema'],
        main_delta='Before any inherited full failure construction/bulk serialization, attempt a single summary write. Store successful descriptor (elseNone) in later full failure. Positive path unchanged apart from own VERSION value.',
        summary_fields=['schema','status','authority','mathematical_authority','resource_accepted','full_pipeline_qualified','no_failed_prefix_admission','invocation_id','plan_sha256','stage','active_row_id','active_row_stage','first_available_fault','snapshot_cutoff_ns','clock_available','work_deadline_ns','overall_deadline_ns','root_check_calls','call_started','call_completed','call_raised','completed_case_count','last_completed_case_id','component_progress_records','diagnostic_records_retained','retained_call_receipts','retained_output_descriptors','counter_scope','coverage'],
        cutoff='Captured ordinary metadata through one clock observation before I/O; excludes later serialization/cleanup/exit. A post-publication time check gates returned descriptor only, never claims summary itself is a terminal receipt.',
        contract=contract_pin))
    proposed = document('prospective-fault-cases-v1.json', dict(common,
        schema='implicit-summary-retention-prospective-fault-cases-v1', executable=False,
        cases=['Literal ordinary primary with counters/stage; summary committed before bulk writer is entered.',
               'Primary __str__/__repr__ raises or blocks: producer never invokes them; exact-str first args member only.',
               'Oversized/nonexact counter entries/texts; first16 and48char labels, explicitNone/truncated; serialized hardcap.',
               'Clock unavailable or original210 reached; summary unavailable, primary selection unchanged.',
               'RootTERM before handler/during partial/fsync: absent or partial summary is not successful retention.',
               'Disk-full/permission/shortwrite/rename/fsync error, occupied filename and nonregular entry; no retry or positive fallback.',
               'Current physical budget exhausted or directory census over64entries; diagnostic unavailable, cap not increased.',
               'Bulk prefix writer fails/hangs after an early committed summary; summary remains independent diagnostic-only.',
               'Observe parent worker positive known-exit180 and negative closure210 unchanged; no false graceful-window promise.']))
    audit = document('author-static-audit-v1.json', dict(common,
        schema='implicit-summary-first-author-static-audit-v1', independent_review=False,
        unused_compiles=2, AST_parses=3, unchanged_definition_names=retained,
        raw_exact_inverse=True, import_census_unchanged=True, no_generator_in_new_helpers=True,
        forward_patch=forward, inverse_patch=inverse,
        note='Raw text construction, AST equality and unused compile only. No new helper, future worker, Session, fault fixture, driver, checker or search invoked. No partial current output decoded.'))
    handoff = document('handoff-v1.json', dict(common,
        schema='implicit-summary-first-retention-handoff-v1', status='SOURCE_ONLY_FUTURE_PATCH',
        source_contract=contract_pin, API=api_pin, prospective_fault_cases=proposed,
        author_static_audit=audit, forward_patch=forward, inverse_patch=inverse,
        fragment=pin(D/'summary_helpers.fragment.py'), metadata_author=pin(Path(__file__)),
        current_failed_actual_changed=False, tools_stop_after_handoff=True))
    print(json.dumps(dict(source=source, handoff=handoff, API=api_pin), sort_keys=True))


if __name__ == '__main__':
    main()
