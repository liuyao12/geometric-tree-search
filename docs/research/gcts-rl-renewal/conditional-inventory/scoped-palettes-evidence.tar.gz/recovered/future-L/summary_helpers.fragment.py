# Future negative-only diagnostic path. No component, check, or Source replay.
FAILURE_SUMMARY_BYTES = 65536
FAILURE_SUMMARY_COUNTER_ROWS = 16
FAILURE_SUMMARY_DIRECTORY_ENTRIES = 64
FAILURE_SUMMARY_UINT_MAX = 9223372036854775807


def _summary_uint(value):
    return value if type(value) is int and 0 <= value <= FAILURE_SUMMARY_UINT_MAX else None


def _summary_text(value, maximum):
    if type(value) is not str:
        return dict(value=None, available=False, truncated=False)
    return dict(value=value[:maximum], available=True, truncated=len(value) > maximum)


def _summary_length(value):
    if type(value) not in (list, dict, tuple):
        return None
    return _summary_uint(len(value))


def _summary_counters(value):
    if type(value) is not dict:
        return dict(rows=[], total_entries=None, truncated=False, available=False)
    rows = []
    for label, count in value.items():
        if len(rows) == FAILURE_SUMMARY_COUNTER_ROWS:
            break
        rows.append([_summary_text(label, 48), _summary_uint(count)])
    return dict(rows=rows, total_entries=_summary_uint(len(value)),
                truncated=len(value) > len(rows), available=True)


def _failure_summary_record(s, primary):
    """Small new ordinary record; never str(error), clone(active), or prefix walk.

    All Session fields are owned plain carriers; external concurrent mutation is
    outside this protocol. Snapshot values are cutoff observations, not terminal
    totals. Failure to construct this record must leave the primary fault intact.
    """
    try:
        cutoff = _summary_uint(NOW())
    except BaseException:
        cutoff = None
    active = s.active if type(s.active) is dict else {}
    active_id = s.active if type(s.active) is str else active.get('id')
    last = s.rows[-1] if type(s.rows) is list and s.rows and type(s.rows[-1]) is dict else {}
    plan = s.plan if type(s.plan) is dict else {}
    plan_pin = s.plan_pin if type(s.plan_pin) is dict else {}
    try:
        fault_type = type(primary).__name__
    except BaseException:
        fault_type = None
    try:
        fault_args = BaseException.args.__get__(primary, BaseException)
        first_argument = fault_args[0] if type(fault_args) is tuple and fault_args else None
    except BaseException:
        first_argument = None
    return dict(
        schema='implicit-worker-failure-summary-v1', status='FAILED_OR_UNFINISHED',
        authority=False, mathematical_authority=False, resource_accepted=False,
        full_pipeline_qualified=False, no_failed_prefix_admission=True,
        invocation_id=_summary_text(plan.get('invocation_id'), 256),
        plan_sha256=_summary_text(plan_pin.get('sha256'), 64),
        stage=_summary_text(s.stage, 64), active_row_id=_summary_text(active_id, 96),
        active_row_stage=_summary_text(active.get('stage'), 64),
        first_available_fault=dict(type=_summary_text(fault_type, 128),
            literal_first_argument=_summary_text(first_argument, 256),
            origin='ROOT_FIRST_FAULT_LATCH' if s.first_fault is not None else 'CAUGHT_EXCEPTION',
            message_evaluated=False),
        snapshot_cutoff_ns=cutoff, clock_available=cutoff is not None,
        work_deadline_ns=_summary_uint(s.work_deadline),
        overall_deadline_ns=_summary_uint(s.overall_deadline),
        root_check_calls=_summary_uint(s.root_calls),
        call_started=_summary_counters(s.started),
        call_completed=_summary_counters(s.completed),
        call_raised=_summary_counters(s.raised),
        completed_case_count=_summary_length(s.rows),
        last_completed_case_id=_summary_text(last.get('id'), 96),
        component_progress_records=_summary_length(s.component_rows),
        diagnostic_records_retained=_summary_length(s.diagnostics),
        retained_call_receipts=_summary_length(s.retained),
        retained_output_descriptors=_summary_length(s.output_pins),
        counter_scope='Snapshot through cutoff; excludes later summary/bulk writes, cleanup and worker exit.',
        coverage='Scalar/capped metadata only; not a full prefix, mathematical outcome, bottleneck or completion certificate.')


def _write_failure_summary(s, summary):
    """One <=64KiB negative-only write, atomic name publication if it finishes.

    The parent may terminate at180s.210s is only the original negative-custody
    upper bound, never a guaranteed grace period. No success gate is consulted
    or changed here. No retries, overwrites, component calls, or Root.check.
    """
    raw = json.dumps(summary, sort_keys=True, separators=(',', ':'),
                     ensure_ascii=True, allow_nan=False).encode('ascii') + b'\n'
    if len(raw) > FAILURE_SUMMARY_BYTES:
        raise ValueError('bounded failure summary exceeded64KiB')
    if not NOW() < s.overall_deadline:
        raise ValueError('failure summary outside original210s custody')
    prior = 0
    entries = 0
    with os.scandir(s.actual) as directory:
        for item in directory:
            entries += 1
            if entries > FAILURE_SUMMARY_DIRECTORY_ENTRIES:
                raise ValueError('bounded failure directory census unavailable')
            record = item.stat(follow_symlinks=False)
            if record.st_mode & 0o170000 != 0o100000:
                raise ValueError('failure summary expects exclusive regular-file actual root')
            prior += record.st_size
    if prior + len(raw) + RESERVE_BYTES > OUTER_LIMITS['result_bytes']:
        raise ValueError('failure summary has no original physical budget remaining')
    path = s.actual / 'worker-failure-summary.json'
    temporary = s.actual / 'worker-failure-summary.json.partial'
    if path.exists() or temporary.exists():
        raise ValueError('failure summary cannot overwrite or retry')
    fd = os.open(str(temporary), os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    try:
        output = os.fdopen(fd, 'wb')
    except BaseException:
        try:
            os.close(fd)
        except BaseException:
            pass
        raise
    with output:
        if output.write(raw) != len(raw):
            raise ValueError('failure summary short write')
        output.flush()
        os.fsync(output.fileno())
    if not NOW() < s.overall_deadline:
        raise ValueError('failure summary did not complete before210s custody')
    # Directory exclusive ownership is a prerequisite; no hostile-race seal.
    os.rename(temporary, path)
    completed = NOW()
    if not completed < s.overall_deadline:
        raise ValueError('failure summary publication observed after210s custody')
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(),
                completed_ns=completed,
                diagnostic_only=True, complete_prefix=False)

