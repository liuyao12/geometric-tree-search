"""Prospective controlled refusals/faults, called only within the once actual."""

def diagnostic(s,d,inputs):
    op=d['operation'];role=d['role'];expected=d['expected']
    bound=dict(IMPLICIT_LIMITS if role=='implicit'else GRAPH_LIMITS)
    calls=0;foreign=None;callback_trace=[]
    def callback():
        nonlocal calls
        calls+=1;s.check()
        if calls==d['expected_callback_count']:
            frame=sys._getframe(1)
            while frame is not None and len(callback_trace)<32:
                if frame.f_code.co_filename==s.plan['sources'][role]['path']:
                    callback_trace.append(dict(function=frame.f_code.co_name,line=frame.f_lineno))
                frame=frame.f_back
            raise foreign
    desc=immutable(inputs['minimal_descriptor']);mask=(None,None,None,None)
    kwargs={};extra=None
    if role=='implicit':
        name='count_query';args=[desc,mask]
        if op.startswith('build_')or op=='implicit_foreign_wire':
            name='build_palette_query';machine=clone(inputs['minimal_machine']);wire=clone(inputs['minimal_wire']);args=[machine,wire]
            if op=='build_bool_symbol':machine['alphabet_size']=True
            elif op=='build_duplicate_transition':machine['transitions']=[[0,0,1,0,0],[0,0,1,0,0]]
            elif op=='build_accept_outgoing':machine['transitions']=[[1,0,0,0,0]]
            elif op=='build_wire_blank':wire['one']=machine['blank']
            elif op=='build_initial_accept':machine['initial']=machine['accepting']
        elif op=='count_bool_mask':args[1]=(('cell',('plain',True)),None,None,None)
        elif op=='count_list_mask':args[1]=[None,None,None,None]
        elif op=='count_nested_none':args[1]=(('cell',None),None,None,None)
        elif op.startswith('select_')or op=='implicit_foreign_fill':
            name='select_query';args=[desc,mask,0]
            if op=='select_bool_index':args[2]=True
            elif op=='select_negative_index':args[2]=-1
            elif op=='select_past_end':
                extra=palette_call(s,'count_query',[desc,mask]);args[2]=extra['count']
        elif op=='count_invalid_descriptor':args[0]=('wrong',desc[1],desc[2])
        elif op=='implicit_work_limit':bound['work']=1
        elif op=='implicit_integer_limit':bound['integer_bits']=1
        elif op=='implicit_data_limit':bound['data_items']=1
        if expected=='FOREIGN':
            if op=='implicit_foreign_same_invalid':foreign=s.modules['implicit'].Invalid('foreign public invalid')
            elif op=='implicit_foreign_same_limit':foreign=s.modules['implicit'].Limit('foreign public limit',0)
            else:foreign=StopIteration('declared exact delegated StopIteration')
        action=lambda:palette_call(s,name,args,bound,callback if expected=='FOREIGN'else None)
    else:
        instance=clone(inputs['graph_cases'][0]['instance']);mode='first'
        for row in instance['fixed_background_marks']:row[2]=immutable(row[2])
        if op=='graph_empty_target':instance['required_centers']=[];instance['admissible_origins']=[]
        elif op=='graph_odd_center':instance['required_centers'][0][0]=1;instance['admissible_origins']=clone(instance['required_centers'])
        elif op=='graph_duplicate_center':instance['required_centers'].append(instance['required_centers'][0][:]);instance['admissible_origins']=clone(instance['required_centers'])
        elif op=='graph_origin_mismatch':instance['admissible_origins']=[]
        elif op=='graph_duplicate_pin':instance['fixed_background_marks'].append(instance['fixed_background_marks'][0])
        elif op=='graph_none_pin':instance['fixed_background_marks'][0][2]=None
        elif op=='graph_bool_generation':instance['root_generations']=[False,0]
        elif op=='graph_bad_mode':mode='not_a_mode'
        elif op=='graph_work_unknown':bound['work']=1
        if expected=='FOREIGN':
            if op=='graph_foreign_same_invalid':foreign=s.modules['graph'].DeclarationError('foreign public invalid')
            elif op=='graph_foreign_same_limit':foreign=s.modules['graph'].SearchLimit(object(),'foreign own-class owner mismatch')
            else:foreign=StopIteration('declared exact graph StopIteration')
        class Facade:
            def count_query(self,descriptor,query,*,check,limits):return palette_call(s,'count_query',[descriptor,query],limits,check)
            def select_query(self,descriptor,query,index,*,check,limits):return palette_call(s,'select_query',[descriptor,query,index],limits,check)
        data=dict(instance=instance,descriptor=desc,limits=bound,oracle_limits=IMPLICIT_LIMITS,mode=mode)
        action=lambda:s.call('graph','search',data,lambda:s.modules['graph'].search(instance,Facade(),desc,
            check=callback if expected=='FOREIGN'else s.check,limits=bound,oracle_limits=dict(IMPLICIT_LIMITS),mode=mode))
    try:result=action()
    except BaseException as error:
        s.fault_gate()
        if expected=='FOREIGN':
            need(error is foreign and calls==d['expected_callback_count'],'exact delegated foreign object and declared site')
            if d['expected_callback_function']is not None:
                need(any(v['function']==d['expected_callback_function']for v in callback_trace),
                     'foreign reached the prospectively named subject function')
            if role=='implicit':
                for pred in('is_own_invalid','is_own_limit'):
                    need(s.call(role,pred,[],lambda pred=pred:getattr(s.modules[role],pred)(error))is False,'foreign public class not privately owned')
        elif role=='implicit':
            pred='is_own_invalid'if expected=='INVALID'else'is_own_limit'
            need(s.call(role,pred,[],lambda:getattr(s.modules[role],pred)(error))is True,'exact private owned refusal')
        else:need(expected=='INVALID'and type(error)is s.modules['graph'].DeclarationError,'exact graph declaration refusal')
        return dict(id=d['id'],operation=op,role=role,expected=expected,status='PASSED',callback_count=calls,
            callback_trace=callback_trace,exact_foreign_identity=(error is foreign)if expected=='FOREIGN'else None,error=information(error),
            implicit_prefix=getattr(error,'implicit_palette_prefix',None),graph_prefix=getattr(error,'implicit_search_prefix',None),setup_receipt=extra)
    s.fault_gate()
    need(expected=='UNKNOWN'and role=='graph'and result['status']=='UNKNOWN_SEARCH_LIMIT'and
         result['exhaustive']is False and result['unfinished_prefix']['final_observation_completed']is False,
         'only declared own search quota becomes UNKNOWN, never zero/UNSAT')
    return dict(id=d['id'],operation=op,role=role,expected=expected,status='PASSED',callback_count=calls,
        exact_foreign_identity=None,result=result,setup_receipt=extra)
