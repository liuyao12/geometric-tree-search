"""Actual-only independent literal oracles; no top-level subject operation."""

def immutable(x):
    if type(x) is list:
        return tuple(immutable(v) for v in x)
    if type(x) is tuple:
        return tuple(immutable(v) for v in x)
    return x


def literal_tiles(s, record):
    old = s.modules['selector']
    args = [record['machine'], record['wire']]
    limits = dict(SELECTOR_LIMITS)
    result = s.call('selector', 'compile_unknown_palette', dict(args=args, limits=limits),
        lambda: old.compile_unknown_palette(*args, check=s.check, limits=limits))
    palette = result['palette']
    tiles = []
    for tile in palette['tiles']:
        s.check()
        edges = tuple(palette['color_constructors'][n] for n in tile['edges_NESW'])
        identity = (tile['kind'], tile['origin'])
        tiles.append(dict(id=identity, kind=tile['kind'], origin=tile['origin'],
            edges_NESW=edges, t=[[[0, 0], 1]],
            m=[[[0, -1], 'edge', edges[0]], [[1, 0], 'edge', edges[1]],
               [[0, 1], 'edge', edges[2]], [[-1, 0], 'edge', edges[3]]]))
    need(len({v['id'] for v in tiles}) == len(tiles), 'distinct legacy semantic inventory identities')
    return palette, tiles


def tile_key(tile):
    need(type(tile) is dict and set(tile) == {'id','kind','origin','edges_NESW','t','m'},
         'exact semantic tile fields')
    need(tile['id'] == (tile['kind'], tile['origin']), 'semantic inventory identity')
    need(type(tile['edges_NESW']) is tuple and len(tile['edges_NESW']) == 4,
         'four immutable exact edge values')
    n,e,b,w = tile['edges_NESW']
    need(argument_bytes(tile['t']) == argument_bytes([[[0,0],1]]) and argument_bytes(tile['m']) == argument_bytes([
        [[0,-1],'edge',n], [[1,0],'edge',e], [[0,1],'edge',b], [[-1,0],'edge',w]]),
        'exact positive center and complete assigned point markings')
    return (tile['id'], tile['edges_NESW'])


def tile_bytes(tile):
    # Tile field insertion order is not inventory semantics. Full value types
    # and every declared field remain compared; code/typed-value order rules
    # from the earlier codec experiment are not silently applied to this API.
    return argument_bytes({k:tile[k]for k in sorted(tile)})


def palette_call(s, name, args, limits=None, callback=None):
    bound = dict(IMPLICIT_LIMITS if limits is None else limits)
    callback = s.check if callback is None else callback
    try:
        receipt=s.call('implicit', name, dict(args=args, limits=bound),
            lambda: getattr(s.modules['implicit'],name)(*args,check=callback,limits=bound))
    except BaseException as error:
        s.retained.append(dict(role='implicit',operation=name,args=args,limits=bound,
            completed=False,error=information(error),prefix=getattr(error,'implicit_palette_prefix',None)))
        raise
    s.retained.append(dict(role='implicit',operation=name,args=args,limits=bound,completed=True,receipt=receipt))
    return receipt


def qualify_small_palette(s, record):
    s.active = record['id']
    progress=dict(id=record['id'],stage='LITERAL_BUILD',input=record,queries=[])
    s.component_rows.append(progress)
    palette, tiles = literal_tiles(s, record)
    progress.update(legacy_palette=palette,semantic_tiles=tiles,stage='IMPLICIT_BUILD')
    build = palette_call(s, 'build_palette_query', [record['machine'],record['wire']])
    desc = build['descriptor']
    description = palette_call(s, 'describe', [desc])
    # Every distinct nonempty constraint mask is a projection of a literal tile.
    # For each fixed subset, these disjoint buckets partition the full inventory.
    buckets = {}
    keys = {tile_key(tile): tile for tile in tiles}
    for tile in tiles:
        for bits in range(16):
            s.check()
            mask = tuple(tile['edges_NESW'][i] if bits & (1 << i) else None for i in range(4))
            buckets.setdefault(mask, []).append(tile)
    zero_masks = [
        (0,None,None,None),
        (('not_a_palette_color',),None,None,None),
        (('cell',('plain',0)),('pair',('plain',1),('plain',0)),None,None),
        (('cell',('plain',0)),None,None,('pair',('plain',0),('plain',1))),
        (('cell',('wall',)),None,None,None),
        (('cell',('head',record['machine']['accepting'],0)),
         ('pair',('head',record['machine']['accepting'],0),('plain',0)),
         ('cell',('plain',0)),('pair',('plain',0),('head',record['machine']['accepting'],0))),
        (('cell',('head',0,0)),('pair',('head',0,0),('head',0,0)),
         None,('pair',('head',0,0),('head',0,0))),
    ]
    for mask in zero_masks:
        s.check()
        # The literal oracle, not the intended diagnostic name, decides the result.
        expected = [t for t in tiles if all(v is None or v == t['edges_NESW'][i]
                                          for i,v in enumerate(mask))]
        need(not expected, 'declared empty cross-splice really has no literal tile')
        buckets.setdefault(mask, [])
    queries = progress['queries'];progress.update(descriptor=desc,build=build,description=description,stage='QUERIES')
    witnesses = 0
    for query_index,(mask,expected) in enumerate(buckets.items()):
        s.check()
        q = palette_call(s,'count_query',[desc,mask])
        need(type(q['count']) is int and q['count'] == len(expected),
             'complete implicit degree equals independent literal projection bucket')
        found = []
        costs = []
        for rank in range(q['count']):
            s.check()
            selected = palette_call(s,'select_query',[desc,mask,rank])
            tile = selected['tile']
            key = tile_key(tile)
            need(key in keys and tile_bytes(tile)==tile_bytes(keys[key]),
                 'full selected point tile equals independent original literal tile')
            need(all(v is None or tile['edges_NESW'][i]==v for i,v in enumerate(mask)),
                 'selected rank matches all assigned values together')
            found.append(tile)
            costs.append(selected['attempted_work'])
            witnesses += 1
        need(len({tile_key(v) for v in found}) == len(found) and
             {tile_key(v) for v in found} == {tile_key(v) for v in expected},
             'every query unranking is a distinct exhaustive bijection')
        queries.append(dict(index=query_index,mask=mask,count=q['count'],
            count_attempted_work=q['attempted_work'],select_attempted_work=costs,
            selected_tiles=found,complete=True))
    # A tile appears once in every mask subset; no hash-only tile attribution.
    need(witnesses==16*len(tiles), 'exact sixteen full-inventory witness populations')
    if not hasattr(s,'literal_models'):s.literal_models={}
    s.literal_models[record['id']]=(palette,tiles,desc,buckets)
    s.oracle_work += 1
    return dict(id=record['id'],complete=True,input=record,descriptor=desc,
        build=build,description=description,legacy_palette=palette,semantic_tiles=tiles,
        queries=queries,nonempty_mask_queries=sum(bool(v['count']) for v in queries),
        zero_mask_queries=sum(not v['count'] for v in queries),
        selected_witnesses=witnesses,full_literal_tile_count=len(tiles),
        scope='All nonempty masks, all ranks, plus declared empty cross-splices; not the full Cartesian cube of colors.')


def independent_membership(s, tile, record):
    """Direct old local-rule definition, deliberately not the factorized generator."""
    tile_key(tile)
    machine=record['machine'];b=machine['alphabet_size'];Q=machine['state_count']
    kind=tile['kind'];origin=tile['origin'];edges=tile['edges_NESW']
    # Large selected witnesses are joined to a focused independently specified
    # literal template in the actual input bank; step outputs use radius-one rule.
    if kind=='step':
        need(type(origin)is tuple and len(origin)==3,'complete step triple')
        l,c,r=origin
        def cell(v,wall=False):
            if wall and v==('wall',):return
            need(type(v)is tuple and v,'literal cell')
            if v[0]=='plain':need(len(v)==2 and type(v[1])is int and 0<=v[1]<b,'plain cell')
            else:need(v[0]=='head' and len(v)==3 and type(v[1])is int and 0<=v[1]<Q and type(v[2])is int and 0<=v[2]<b,'head cell')
        cell(l,True);cell(c);cell(r,True)
        heads=[(i,v)for i,v in enumerate(origin)if v[0]=='head']
        need(len(heads)<=1,'no multiple heads in a step tile')
        output=c
        if heads:
            position,head=heads[0]
            rows=[v for v in machine['transitions']if v[0]==head[1] and v[1]==head[2]]
            for unused in machine['transitions']:s.check()
            need(len(rows)==1,'large step uses a declared unique transition')
            _,_,n,w,d=rows[0]
            if position==1:
                need(not(d==-1 and l==('wall',))and not(d==1 and r==('wall',)), 'no crossed wall')
                output=('head',n,w)if d==0 else('plain',w)
            elif(position==0 and d==1)or(position==2 and d==-1):output=('head',n,c[1])
        need(edges==(('cell',c),('pair',c,r),('cell',output),('pair',l,c)),
             'independent complete radius-one step witness')
    else:
        need(type(origin)is tuple,'immutable non-step origin')
        def natural(v,n):
            need(type(v)is int and 0<=v<n,'strict bounded non-step index')
            return v
        def phase(pair):
            need(pair in(('PRE','PRE'),('PAD','POST'),('POST','POST')),'fixed phase pair')
        def h(p,f):return ('init_horizontal',p,f)
        if kind=='collect_plain':
            need(len(origin)==2,'plain collector origin');a,f=origin;natural(a,b);natural(f,2)
            wanted=(('cell',('plain',a)),('seen',f),('stop',),('seen',f))
        elif kind=='collect_accept':
            need(len(origin)==2,'accept collector origin');q,a=origin;natural(q,Q);natural(a,b)
            need(q==machine['accepting'],'accept-only collector')
            wanted=(('cell',('head',q,a)),('seen',1),('stop',),('seen',0))
        elif kind in('left_step_frame','right_step_frame'):
            need(len(origin)==1,'step frame origin');v=origin[0]
            need(type(v)is tuple and v and v[0]in('plain','head'),'frame complete cell')
            if v[0]=='plain':need(len(v)==2,'frame plain arity');natural(v[1],b)
            else:need(len(v)==3,'frame head arity');natural(v[1],Q);natural(v[2],b)
            wanted=((('side','left','run'),('pair',('wall',),v),('side','left','run'),('exterior','left'))
                if kind=='left_step_frame' else
                (('side','right','run'),('exterior','right'),('side','right','run'),('pair',v,('wall',))))
        elif kind=='left_accept_frame':
            need(origin==(),'left closing frame origin')
            wanted=(('side','left','run'),('seen',0),('side','left','done'),('exterior','left'))
        elif kind=='right_accept_frame':
            need(origin==(),'right closing frame origin')
            wanted=(('side','right','run'),('exterior','right'),('side','right','done'),('seen',1))
        elif kind=='init_fixed_plain':
            need(len(origin)==4,'fixed plain origin');p,n,a,f=origin;phase((p,n));natural(a,b);natural(f,2)
            wanted=(('init_north','plain',a),h(n,f),('cell',('plain',a)),h(p,f))
        elif kind=='init_fixed_head':
            need(len(origin)==3,'fixed head origin');p,n,a=origin;phase((p,n));natural(a,b)
            wanted=(('init_north','head',machine['initial'],a),h(n,1),('cell',('head',machine['initial'],a)),h(p,0))
        elif kind=='init_free_bit':
            need(len(origin)==3,'bit origin');p,a,f=origin;natural(f,2)
            need(p in('PRE','ACTIVE')and a in(record['wire']['zero'],record['wire']['one']),'free bit phases/symbol')
            wanted=(('init_north','free'),h('ACTIVE',f),('cell',('plain',a)),h(p,f))
        elif kind=='init_free_terminator':
            need(len(origin)==2,'terminator origin');p,f=origin;natural(f,2);need(p in('PRE','ACTIVE'),'terminator phase')
            wanted=(('init_north','free'),h('PAD',f),('cell',('plain',record['wire']['terminator'])),h(p,f))
        elif kind=='init_free_padding':
            need(len(origin)==1,'padding origin');f=origin[0];natural(f,2)
            wanted=(('init_north','free'),h('PAD',f),('cell',('plain',machine['blank'])),h('PAD',f))
        elif kind=='init_left_frame':
            need(origin==(),'left initializer frame origin')
            wanted=(('init_north','frame','left'),h('PRE',0),('side','left','run'),('exterior','left'))
        else:
            need(kind=='init_right_frame'and origin==(),'right initializer frame origin')
            wanted=(('init_north','frame','right'),('exterior','right'),('side','right','run'),h('POST',1))
        need(edges==wanted,'independent complete non-step constructor witness')
    return True


def reference_tile(kind,origin,edges):
    n,e,b,w=edges
    return dict(id=(kind,origin),kind=kind,origin=origin,edges_NESW=edges,
        t=[[[0,0],1]],m=[[[0,-1],'edge',n],[[1,0],'edge',e],
                        [[0,1],'edge',b],[[-1,0],'edge',w]])


def qualify_large_palette(s,record):
    s.active=record['id']
    progress=dict(id=record['id'],stage='LARGE_BUILD',input=record,samples=[],focused=[])
    s.component_rows.append(progress)
    build=palette_call(s,'build_palette_query',[record['machine'],record['wire']])
    desc=build['descriptor']
    description=palette_call(s,'describe',[desc])
    machine=record['machine'];wire=record['wire'];limits=dict(SELECTOR_LIMITS)
    legacy=s.call('selector','describe_unknown_palette_cardinality',
        dict(machine=machine,wire=wire,limits=limits),
        lambda:s.modules['selector'].describe_unknown_palette_cardinality(machine,wire,
            check=s.check,limits=limits))
    total=palette_call(s,'count_query',[desc,(None,None,None,None)])
    need(total['count']==legacy['counts']['total_tiles'] and total['count']>134217728,
         'complete implicit count agrees exact old Source formula; not a literal-byte fit')
    samples=progress['samples'];progress.update(descriptor=desc,build=build,description=description,legacy_cardinality=legacy,total=total,stage='LARGE_WITNESSES')
    for rank in(0,total['count']//2,total['count']-1):
        selected=palette_call(s,'select_query',[desc,(None,None,None,None),rank])
        independent_membership(s,selected['tile'],record)
        samples.append(dict(mask=(None,None,None,None),rank=rank,receipt=selected))
    focused=progress['focused']
    plain=('plain',0);wall=('wall',)
    # Every disjoint step family, including both allowable wall sides.
    triples=[(plain,plain,plain),(('head',0,0),plain,wall),
             (wall,plain,('head',2,0)),(plain,('head',0,0),wall),
             (wall,('head',1,0),wall),(wall,('head',2,0),plain)]
    for i,(l,c,r)in enumerate(triples):
        mask=(('cell',c),('pair',c,r),None,('pair',l,c))
        count=palette_call(s,'count_query',[desc,mask]);need(count['count']==1,'one complete step identity')
        selected=palette_call(s,'select_query',[desc,mask,0])
        need(selected['tile']['id']==('step',(l,c,r)),'focused disjoint step identity')
        independent_membership(s,selected['tile'],record)
        focused.append(dict(family='step-family-'+str(i),mask=mask,count_receipt=count,selected=selected))
    def h(p,f):return ('init_horizontal',p,f)
    initial=machine['initial'];accepting=machine['accepting'];a=machine['alphabet_size']-1
    cell=('head',accepting,a)
    recipes=[
        ('collect_plain',(a,0),(('cell',('plain',a)),('seen',0),('stop',),('seen',0))),
        ('collect_accept',(accepting,a),(('cell',cell),('seen',1),('stop',),('seen',0))),
        ('left_step_frame',(cell,),(('side','left','run'),('pair',wall,cell),('side','left','run'),('exterior','left'))),
        ('right_step_frame',(cell,),(('side','right','run'),('exterior','right'),('side','right','run'),('pair',cell,wall))),
        ('left_accept_frame',(),(('side','left','run'),('seen',0),('side','left','done'),('exterior','left'))),
        ('right_accept_frame',(),(('side','right','run'),('exterior','right'),('side','right','done'),('seen',1))),
        ('init_fixed_plain',('POST','POST',a,1),(('init_north','plain',a),h('POST',1),('cell',('plain',a)),h('POST',1))),
        ('init_fixed_head',('PAD','POST',a),(('init_north','head',initial,a),h('POST',1),('cell',('head',initial,a)),h('PAD',0))),
        ('init_free_bit',('ACTIVE',wire['one'],1),(('init_north','free'),h('ACTIVE',1),('cell',('plain',wire['one'])),h('ACTIVE',1))),
        ('init_free_terminator',('PRE',0),(('init_north','free'),h('PAD',0),('cell',('plain',wire['terminator'])),h('PRE',0))),
        ('init_free_padding',(1,),(('init_north','free'),h('PAD',1),('cell',('plain',machine['blank'])),h('PAD',1))),
        ('init_left_frame',(),(('init_north','frame','left'),h('PRE',0),('side','left','run'),('exterior','left'))),
        ('init_right_frame',(),(('init_north','frame','right'),('exterior','right'),('side','right','run'),h('POST',1))),
    ]
    for kind,origin,edges in recipes:
        expected=reference_tile(kind,origin,edges);independent_membership(s,expected,record)
        count=palette_call(s,'count_query',[desc,edges]);need(count['count']==1,'unique full non-step edge mask')
        selected=palette_call(s,'select_query',[desc,edges,0])
        need(tile_bytes(selected['tile'])==tile_bytes(expected),'complete independently specified non-step tile')
        focused.append(dict(family=kind,mask=edges,count_receipt=count,selected=selected))
    s.oracle_work+=1
    return dict(id=record['id'],complete=True,input=record,descriptor=desc,build=build,
        description=description,legacy_cardinality=legacy,total_count=total,
        global_rank_samples=samples,focused_families=focused,
        fully_materialized=False,full_large_unranking_exhausted=False,
        scope='Exact full Source cardinality plus selected large membership and all family kinds. No full large palette enumeration, physical VM, theorem search or literal-output fit.')


OFFSETS=((0,-1),(1,0),(0,1),(-1,0))


def independent_graph_core(s,core,instance,tiles,buckets):
    points=instance['required_centers'];gens=instance['root_generations']
    if gens is None:gens=[0]*len(points)
    byid={t['id']:t for t in tiles}
    chosen={}
    for i,identity,edges,generation in core['chosen']:
        s.check();identity=immutable(identity)
        need(type(i)is int and 0<=i<len(points)and i not in chosen,'unique occupied required site')
        need(identity in byid and edges==byid[identity]['edges_NESW'] and generation==gens[i]+1,
             'whole chosen literal tile and root-derived tile generation')
        chosen[i]=identity
    expected_marks={}
    for p,ch,v in instance['fixed_background_marks']:
        s.check();expected_marks[(tuple(p),ch)]=[v,1,True]
    for i,identity in chosen.items():
        for side,(dx,dy)in enumerate(OFFSETS):
            s.check();p=(points[i][0]+dx,points[i][1]+dy);key=(p,'edge');v=byid[identity]['edges_NESW'][side]
            if key in expected_marks:
                need(expected_marks[key][0]==v,'independent whole point marking agreement')
                expected_marks[key][1]+=1
            else:expected_marks[key]=[v,1,False]
    rawmarks=[[list(p),ch,v,refs,fixed]for(p,ch),(v,refs,fixed)in sorted(expected_marks.items())]
    need(argument_bytes(core['marks'])==argument_bytes(rawmarks),'exact full mark values/refcounts/fixed ownership')
    need(len(core['points'])==len(points)and len(core['domains'])==len(points),'entire active finite target')
    exclusions={}
    for row in core['exclusions']:
        s.check();i=row['point'];identity=immutable(row['id'])
        need(type(i)is int and 0<=i<len(points)and identity in byid,'literal excluded candidate')
        need(identity not in exclusions.setdefault(i,[]),'distinct per-point exclusions')
        exclusions[i].append(identity)
        for p,parent_id in row['parent_support']:
            need(chosen.get(p)==immutable(parent_id),'exclusion only under its parent assumptions')
    degree=[];full_domains=[]
    for i,point in enumerate(points):
        s.check();need(core['points'][i]==[i,point,1 if i in chosen else 0,gens[i]],'exact point totals and generations')
        domain=core['domains'][i]
        if i in chosen:
            need(domain is None,'occupied site is absent from frontier');full_domains.append(None);continue
        mask=tuple(expected_marks.get(((point[0]+dx,point[1]+dy),'edge'),[None])[0]for dx,dy in OFFSETS)
        candidates=buckets.get(mask,[])
        physical={t['id']for t in candidates}
        matching=[identity for identity in exclusions.get(i,[])if identity in physical]
        available=[t['id']for t in candidates if t['id']not in matching]
        need(type(domain)is dict and domain['point']==i and domain['mask']==mask and
             type(domain['physical_count'])is int and domain['physical_count']==len(candidates)and
             immutable(domain['matching_exclusions'])==tuple(matching)and
             type(domain['degree'])is int and domain['degree']==len(available),
             'implicit incremental domain equals the complete independently indexed literal inventory')
        full_domains.append(available);degree.append((i,len(available)))
    zeros=[(i,n)for i,n in degree if n==0];ones=[(i,n)for i,n in degree if n==1]
    if zeros:decision=['DEAD',zeros[0][0],0]
    elif ones:decision=['FORCED',ones[0][0],1]
    elif not degree:decision=['COMPLETE',None,0]
    else:
        i,n=min(degree,key=lambda v:(gens[v[0]],v[1],v[0]));decision=['BRANCH',i,n]
    return decision,full_domains


def independent_all_solutions(s,instance,tiles,buckets):
    """Independent fixed-site-order literal point enumeration, not GCTS scheduling."""
    marks={(tuple(p),ch):v for p,ch,v in instance['fixed_background_marks']}
    points=instance['required_centers'];answers=[];chosen=[]
    def visit(i):
        s.check()
        if i==len(points):
            answers.append(tuple(chosen));need(len(answers)<=10000,'declared finite oracle answer cap');return
        p=points[i]
        mask=tuple(marks.get(((p[0]+dx,p[1]+dy),'edge'))for dx,dy in OFFSETS)
        for tile in buckets.get(mask,[]):
            s.check();trail=[]
            for side,(dx,dy)in enumerate(OFFSETS):
                key=((p[0]+dx,p[1]+dy),'edge')
                if key not in marks:marks[key]=tile['edges_NESW'][side];trail.append(key)
            chosen.append(tile['id']);visit(i+1);chosen.pop()
            for key in trail:del marks[key]
    visit(0);s.oracle_work+=1
    return answers


def graph_instance(s,case):
    if case['kind']=='literal':
        instance=clone(case['instance'])
        for row in instance['fixed_background_marks']:row[2]=immutable(row[2])
        return instance,None
    need(case['kind']=='unknown_board','declared graph instance construction')
    record=case['palette_record'];prefix=[immutable(x)for x in case['fixed_prefix']]
    suffix=[immutable(x)for x in case['fixed_suffix']];limits=dict(SELECTOR_LIMITS)
    args=[record['machine'],record['wire'],prefix,case['capacity'],suffix,case['steps']]
    old=s.call('selector','compile_unknown_problem',dict(args=args,limits=limits),
        lambda:s.modules['selector'].compile_unknown_problem(*args,check=s.check,limits=limits))
    colors=old['palette']['color_constructors']
    instance=dict(schema='finite-implicit-wang-point-instance-v1',
        required_centers=old['required_centers'],admissible_origins=old['admissible_origins'],
        fixed_background_marks=[[p,ch,colors[v]]for p,ch,v in old['fixed_background_marks']],root_generations=None)
    return instance,old


def qualify_graph(s,case):
    s.active=case['id'];instance,old=graph_instance(s,case)
    progress=dict(id=case['id'],stage='REFERENCE',input=case,instance=instance,legacy_problem=old,observations=[])
    s.component_rows.append(progress)
    palette,tiles,desc,buckets=s.literal_models[case['palette_id']]
    reference=independent_all_solutions(s,instance,tiles,buckets)
    observations=progress['observations'];pending_restore=[];root_core=None;domain_checks=0
    progress.update(independent_solution_ids=reference,stage='GRAPH_SEARCH')
    class Facade:
        def count_query(self,descriptor,mask,*,check,limits):
            return palette_call(s,'count_query',[descriptor,mask],limits,check)
        def select_query(self,descriptor,mask,index,*,check,limits):
            return palette_call(s,'select_query',[descriptor,mask,index],limits,check)
    def observe(snapshot):
        nonlocal root_core,domain_checks
        before=argument_bytes(snapshot);s.check()
        decision,domains=independent_graph_core(s,snapshot,instance,tiles,buckets)
        need(snapshot['scheduler']==decision,'global DEAD then FORCED then earliest generation')
        deps={}
        for i,p in enumerate(instance['required_centers']):
            for side,(dx,dy)in enumerate(OFFSETS):deps.setdefault((p[0]+dx,p[1]+dy),[]).append([i,side])
        need(snapshot['dependencies']==[[list(p),v]for p,v in sorted(deps.items())],
             'complete forward and reverse midpoint dependency incidence')
        for frame in snapshot['branch_stack']:
            independent_graph_core(s,frame['parent'],instance,tiles,buckets)
        core={k:snapshot[k]for k in('points','chosen','marks','domains','exclusions')}
        if snapshot['reason']=='BEFORE_ROLLBACK':
            need(snapshot['rollback_parent']is not None and not pending_restore,'one exact pending rollback checkpoint')
            independent_graph_core(s,snapshot['rollback_parent'],instance,tiles,buckets)
            pending_restore.append(argument_bytes(snapshot['rollback_parent']))
        if snapshot['reason']=='AFTER_ROLLBACK':
            need(len(pending_restore)==1 and argument_bytes(core)==pending_restore.pop() and
                 argument_bytes(core)==argument_bytes(snapshot['rollback_parent']),
                 'complete restored parent exactly equals its retained rollback checkpoint')
        if snapshot['reason']=='INITIAL':root_core=argument_bytes(core)
        if snapshot['reason']=='ROOT_RESTORED':need(argument_bytes(core)==root_core,'exact full initial state restored')
        domain_checks+=sum(d is not None for d in domains)
        observations.append(dict(snapshot=snapshot,independent_domains=domains,complete=True))
        need(argument_bytes(snapshot)==before,'read-only independent observer')
    data=dict(instance=instance,descriptor=desc,limits=GRAPH_LIMITS,oracle_limits=IMPLICIT_LIMITS,mode=case['mode'])
    result=s.call('graph','search',data,lambda:s.modules['graph'].search(instance,Facade(),desc,
        check=s.check,limits=dict(GRAPH_LIMITS),oracle_limits=dict(IMPLICIT_LIMITS),observe=observe,mode=case['mode']))
    progress.update(result=result,stage='GRAPH_RESULT')
    need(result['status']!='UNKNOWN_SEARCH_LIMIT'and result['root_restored']is True and
         result['final_observation_completed']is True,'whole graph case complete with observed exact restoration')
    need(not pending_restore,'all begun rollback comparisons completed')
    actual=[]
    for solution in result['solutions']:
        placements=solution['placements'];need(len(placements)==len(instance['required_centers']),'full finite target certificate')
        ids=[]
        for i,placement in enumerate(placements):
            need(placement['point']==i and placement['origin']==instance['required_centers'][i], 'ordered complete target')
            tile=placement['tile'];tile_key(tile)
            need(placement['id']==tile['id']and any(tile_bytes(tile)==tile_bytes(t)for t in tiles),
                 'every certificate tile is a complete literal inventory tile')
            ids.append(tile['id'])
        actual.append(tuple(ids))
    need(len(set(actual))==len(actual),'no duplicate whole tilings')
    if case['mode']=='all':
        need(result['exhaustive']is True and set(actual)==set(reference),'complete solution population equals independent point enumeration')
    elif reference:
        need(result['status']=='SOLUTION_FOUND'and len(actual)==1 and actual[0]in reference,'first solution independently valid')
    else:need(result['status']=='EXHAUSTED_NO_SOLUTION'and not actual and result['exhaustive']is True,'finite exhaustive negative independently agrees')
    decisions=[o['snapshot']['scheduler']for o in observations if o['snapshot']['reason']=='BEFORE_DECISION']
    if case['id']=='distant-DEAD-before-FORCED':need(decisions[0][0]=='DEAD'and not result['solutions'],'distant dead checked before sole placement')
    if case['id']=='distant-FORCED-before-BRANCH':need(decisions[0]==['FORCED',1,1],'distant forced checked before local choices')
    if case['id']=='earliest-before-lower-degree-TEST-VARIANT':need(decisions[0][0]=='BRANCH'and decisions[0][1]==0,'earlier root outranks lower later degree')
    if case['id']=='connected-failed-children-first':need(sum(e['kind']=='FAILED_CHILD_EXCLUDED'for e in result['journal'])>=3,'rank-shifting failed-child population actually reached')
    s.oracle_work+=1
    return dict(id=case['id'],complete=True,input=case,instance=instance,legacy_problem=old,
        result=result,observations=observations,independent_solution_ids=reference,
        independent_solution_count=len(reference),actual_solution_count=len(actual),domain_checks=domain_checks,
        scope='Complete finite singleton-center/four-midpoint point model; no physical FOL interpreter, remote extra tile marks, shared/fractional t support, RL or performance advantage.')
