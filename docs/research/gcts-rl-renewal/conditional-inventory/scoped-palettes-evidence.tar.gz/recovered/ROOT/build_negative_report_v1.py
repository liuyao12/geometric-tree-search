"""Passive saved JSON/raw Source/archive/report formatting only; no subject imports."""
from pathlib import Path
import json,hashlib,html,tarfile,gzip,io,subprocess
D=Path('/private/tmp/gcts-implicit-ROOT-20261020-v1')
P=Path('/private/tmp/gcts-split-controls-publish-20261015')
O=D/'publication'
assert not O.exists()
# Wait for the two separate future Source-only handoffs; they are not executed.
future=[Path('/private/tmp/gcts-implicit-batch-B-20261020-v1/handoff-v1.json'),Path('/private/tmp/gcts-implicit-retention-L-20261020-v1/handoff-v1.json')]
assert all(p.is_file()for p in future)
R=Path('/private/tmp/gcts-implicit-review-C-20261020-v1/typed-saved-actual-negative-review-v2.json')
audit=json.loads(R.read_bytes());assert audit['saved_review_passed']is True and audit['summary']=={'checks':111,'failed':0}
assert all(v['passed']is True for v in audit['checks'])
runner=json.loads((D/'actual-implicit-v2/runner-receipt.json').read_bytes())
terminal=json.loads((D/'implicit-plan-authorized-v2-terminal-observation/terminal.json').read_bytes())
disposition=json.loads((D/'ROOT-negative-disposition-v3.json').read_bytes())
assert disposition['resource_qualified']is False and disposition['finite_component_qualified']is False and terminal['runner_exit_code']==2 and not terminal['terminal_gate_passed']
assert all(runner[k]is None for k in('compiler_calls','search_calls','verifier_calls','oracle_calls'))
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def encoded(x):return (json.dumps(x,sort_keys=True,indent=2,ensure_ascii=True,allow_nan=False)+'\n').encode()
# Exact isolated Git object only; no primary reader or index access.
parent='281116a44c128d5fb44693329e61e8d0db597e32'
reader_path='docs/research/gcts-rl-renewal/conditional-inventory/reader.html'
pre=subprocess.run(['/usr/bin/git','show',parent+':'+reader_path],cwd=P,check=True,capture_output=True).stdout
assert pre.count(b'</main>')==1
(D/'reader-preimage-v1.html').write_bytes(pre)
card=b'<section id="implicit-palette-update"><h2>Implicit palette: construction and a deadline failure</h2><p>A complete factorized inventory and point-search adapter are implemented as reviewed Source. The whole calibration failed its original 180-second gate; no result was admitted. The raw negative evidence, missing diagnostic fields and separate unexecuted batch/summary designs are preserved.</p><p><a href="implicit-palette.html#outcome">Read the construction and failed qualification</a></p></section>\n'
reader=pre.replace(b'</main>',card+b'</main>',1);assert reader.replace(card,b'',1)==pre
(D/'reader-append-custody-v1.json').write_bytes(encoded(dict(schema='isolated-reader-append-custody-v1',parent_commit=parent,parent=pin(D/'reader-preimage-v1.html'),added_bytes=len(card),exact_inverse_restores_parent=True,primary_reader_or_index_accessed=False)))
O.mkdir()
summary=dict(schema='implicit-palette-negative-summary-v1',status=disposition['status'],actual_invocations=1,remaining_invocations=0,runner_exit_code=2,worker_exit_code=runner['worker_exit_code'],runner_epoch_to_terminal_seconds=terminal['runner_clock_elapsed_seconds'],worker_peak_bytes=runner['worker_wait4_usage']['ru_maxrss'],conservative_negative_ledger_bytes=runner['final_physical_ledger']['conservative_bytes'],fragment_bytes=49135,complete_positive_packet=False,stage='UNAVAILABLE',completed_case_counts='UNAVAILABLE',component_counts={k:runner[k]for k in('compiler_calls','search_calls','verifier_calls','oracle_calls')},planned_normal_cases=15,planned_diagnostics=33,resource_qualified=False,finite_component_qualified=False,mathematical_proof_admitted=False,full_pipeline_qualified=False,saved_negative_checks=111,fragment_handling='Raw archive bytes only; not parsed, repaired or admitted.',Source_scope='Reviewed generic construction only; runtime equivalence remains unqualified.',goal_status='active_not_complete')
(O/'implicit-palette-summary.json').write_bytes(encoded(summary))
(O/'implicit-palette-data.json').write_bytes(encoded(dict(schema='implicit-palette-negative-reader-data-v1',summary=summary,runner=runner,terminal=terminal,Root_disposition=disposition,Source_handoffs=[json.loads(p.read_bytes())for p in future],fragment_content_included_or_parsed=False)))
metrics='<div class="metrics"><div class="metric"><b>180 s</b>original positive-result gate</div><div class="metric"><b>'+format(terminal['runner_clock_elapsed_seconds'],'.3f')+' s</b>runner entry through terminal observation</div><div class="metric"><b>1</b>actual invocation; grant retired</div><div class="metric"><b>0</b>admitted positive packets</div></div>'
usage=runner['worker_wait4_usage']
details='<div class="card"><b>Recorded outer observations</b><p>Runner exit: <code>2</code>. Worker exit: <code>-15</code> after one TERM signal. Standalone worker high-water memory: '+format(usage['ru_maxrss'],',')+' bytes. Recorded worker CPU: '+format(usage['ru_utime'],'.6f')+' user seconds and '+format(usage['ru_stime'],'.6f')+' system seconds. The conservative saved negative ledger is '+format(runner['final_physical_ledger']['conservative_bytes'],',')+' bytes including the original reservation.</p><p class="small">These measurements do not admit the run. Algorithm, guard and output costs were not separately instrumented; completed component counters remain literal <code>null</code>.</p></div>'
futuretext='<p class="small">Two future Source-only candidates are archived separately: <code>with_profile</code>/<code>batch_query</code> for scoped preparation, and a bounded scalar failure-summary helper with a worker-only patch. They have not been imported, run, integrated into the frozen subject, or granted an experiment. Their correctness, custody equivalence and performance remain unqualified.</p>'
reviewtext='<p>Independent passive saved-data review recorded 111 consistency checks with no mismatches. It confirms the rejected status and unavailable fields; it grants no resource or mathematical qualification. Source review also preserved the earlier callback-generator defect and its explicit-loop repair, plus the parser-attribution metadata negative and corrected pinned-parser successor. All old negatives and grants remain unchanged.</p>'
template=(D/'implicit-negative-template.html').read_text();report=template.replace('__METRICS__',metrics).replace('__RUN_DETAILS__',details).replace('__FUTURE__',futuretext).replace('__REVIEW__',reviewtext)
assert '__METRICS__'not in report and '__RUN_DETAILS__'not in report
(O/'implicit-palette.html').write_text(report)
(O/'reader.html').write_bytes(reader)
# Explicit raw selection. No runtime binaries/stdlib contents, no unrelated checkout.
roots=[('ROOT',D),('Bv1',Path('/private/tmp/gcts-implicit-wang-B-20261020-v1')),('Bv2',Path('/private/tmp/gcts-implicit-wang-B-20261020-v2')),('L',Path('/private/tmp/gcts-implicit-graph-L-20261020-v1')),('C',Path('/private/tmp/gcts-implicit-review-C-20261020-v1')),('future-B',future[0].parent),('future-L',future[1].parent)]
files=[]
for label,root in roots:
 for p in sorted(root.rglob('*')):
  if not p.is_file()or p.is_symlink()or O in p.parents:continue
  if '__pycache__'in p.parts or p.suffix=='.pyc':continue
  if p.name.startswith('typed-publication-review')or p.name.startswith('live-')or p.name.startswith('local-')or p.name.startswith('pages-')or p.name.startswith('ROOT-final-milestone'):continue
  files.append((label+'/'+p.relative_to(root).as_posix(),p))
selector=Path('/private/tmp/gcts-fixed-initializer-ROOT-20261020-v1/wang_unknown_certificate_initializer_v1.py');files.append(('inherited-Source/'+selector.name,selector))
assert len({n for n,p in files})==len(files)
rows=[dict(member=n,**pin(p))for n,p in files]
pathmap=encoded(dict(schema='raw-archive-pathmap-v1',files=rows,scope='Frozen task-only Sources/evidence. Future candidates unexecuted; complete runtime binary/stdlib externally pinned only. Failed fragment raw bytes retained without parse. Detached publication review deliberately excluded.'))
archive=O/'implicit-palette-evidence.tar.gz'
with archive.open('xb')as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0)as gz:
  with tarfile.open(fileobj=gz,mode='w')as tar:
   for name,p in files:
    data=p.read_bytes();i=tarfile.TarInfo(name);i.size=len(data);i.mtime=0;i.mode=0o644;tar.addfile(i,io.BytesIO(data))
   i=tarfile.TarInfo('PATHMAP.json');i.size=len(pathmap);i.mtime=0;i.mode=0o644;tar.addfile(i,io.BytesIO(pathmap))
assets=[pin(O/n)for n in ['implicit-palette.html','implicit-palette-data.json','implicit-palette-summary.json','implicit-palette-evidence.tar.gz','reader.html']]
manifest=dict(schema='implicit-palette-negative-publication-manifest-v1',status=summary['status'],assets=assets,archive_files=rows,archive_members=len(rows)+1,archive_raw_bytes=sum(r['bytes']for r in rows),negative_review=pin(R),Root_disposition=pin(D/'ROOT-negative-disposition-v3.json'),parent_commit=parent,reader_append_custody=pin(D/'reader-append-custody-v1.json'),detached_review='implicit-palette-review.json excluded to avoid self-hash cycle',index_accessed_or_modified=False,Source_and_future_scopes='Source argument is conditional; actual timed out and all mathematical outputs unqualified. Future Sources archived only, no execution or measured advantage.')
(O/'implicit-palette-manifest.json').write_bytes(encoded(manifest))
print(json.dumps(dict(files=[pin(p)for p in sorted(O.iterdir())],archive_members=len(rows)+1,archive_raw_bytes=manifest['archive_raw_bytes']),indent=2))
