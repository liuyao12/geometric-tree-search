"""UNEXECUTED whole codec/image and unknown-initializer calibration worker.

Only fresh reviewed once-run execution may load/call the four components.
No Native/FOL-kernel/Model/Reader/inverse/solver imports or calls. No hostile sandbox
claim: input ownership, Source/callable custody and finite external gates apply.
"""
import time
NOW = time.monotonic_ns
ENTRY_NS = NOW()
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import types

VERSION = 'complete-implicit-palette-point-graph-worker-v1'
SOURCE_ROLES = ('worker','implicit','graph','selector','runner','observer')
SOURCE_PINS = {}  # Exact whole-subject Source pins are bound by the reviewed plan.

OUTER_LIMITS = dict(work_seconds=180, overall_seconds=210, memory_bytes=1073741824,
    result_bytes=134217728, expanded_bytes=134217728, stdout_bytes=4194304,
    stderr_bytes=4194304, worker_receipt_bytes=4194304,
    runner_metadata_bytes=8388608, observer_bytes=1048576)
SELECTOR_LIMITS=dict(work=400000000,symbols=256,states=100000,tiles=100000,colors=100000,cells=100000,dimension=10000)
IMPLICIT_LIMITS = {}  # Draft; exact ABI forthcoming.
GRAPH_LIMITS = {}
COMPONENT_LIMITS={'selector':SELECTOR_LIMITS,'implicit':IMPLICIT_LIMITS,'graph':GRAPH_LIMITS}

CHECKPOINT_LIMIT = 400000000
RESERVE_BYTES = 9437184
FORBIDDEN_EVENTS = ('subprocess.Popen','os.system','os.fork','os.posix_spawn','socket.connect','ctypes.dlopen')


class PolicyFailure(RuntimeError):
    pass


class PlannedForeign(BaseException):
    pass


def need(ok, message):
    if not ok:
        raise PolicyFailure(message)


def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode('utf8')


def clone(value):
    return json.loads(canonical(value))



def typed_value(value):
    """Strict typed literal carrier preserves dictionary order and tuple/list.

    Only called inside the once actual. Surrogatepass bytes preserve a lone
    surrogate pair versus an astral character, which JSON escapes can alias.
    """
    def visit(x,depth):
        need(depth<=128,'bounded typed argument guard depth')
        t=type(x)
        if x is None:return ['none']
        if t is bool:return ['bool',x]
        if t is int:return ['int',x]
        if t is float:return ['float_hex',x.hex()]
        if t is str:return ['str_utf8_surrogatepass_hex',x.encode('utf8','surrogatepass').hex()]
        if t is list:return ['list',[visit(y,depth+1)for y in x]]
        if t is tuple:return ['tuple',[visit(y,depth+1)for y in x]]
        need(t is dict,'ordinary typed argument carriers')
        return ['dict',[[visit(k,depth+1),visit(v,depth+1)]for k,v in x.items()]]
    return visit(value,0)


def argument_bytes(value):
    return json.dumps(typed_value(value),ensure_ascii=True,separators=(',',':'),allow_nan=False).encode('ascii')


def descriptor(path, raw):
    return dict(path=str(Path(path).resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


def checked(pin, cap=16777216):
    need(type(pin)is dict and set(pin)=={'path','bytes','sha256'} and type(pin['path'])is str and
         type(pin['bytes'])is int and 0<=pin['bytes']<=cap and type(pin['sha256'])is str and
         len(pin['sha256'])==64,'strict finite raw descriptor')
    path=Path(pin['path'])
    need(path.is_absolute()and path==path.resolve()and path.is_file()and not path.is_symlink(),'canonical regular raw input')
    raw=path.read_bytes();need(descriptor(path,raw)==pin,'complete raw hash/size/path join');return raw


def information(error):
    try:return dict(type=type(error).__name__,message=str(error)[:512])
    except BaseException:return dict(type='UNAVAILABLE',message='error metadata unavailable')


def callable_seal(module):
    rows=[];seen=set();pending=[('',vars(module))]
    while pending:
        prefix,values=pending.pop()
        for name,value in sorted(values.items()):
            key=prefix+name
            if type(value)is types.FunctionType and value.__module__==module.__name__:
                rows.append((key,id(value),id(value.__code__),id(value.__defaults__),id(value.__kwdefaults__)))
            elif type(value)is type and value.__module__==module.__name__ and id(value)not in seen:
                seen.add(id(value));rows.append((key,id(value)))
                owned={}
                for child,item in vars(value).items():
                    if type(item)in(staticmethod,classmethod):item=item.__func__
                    owned[child]=item
                pending.append((key+'.',owned))
    return tuple(sorted(rows))


class Session:
    def __init__(self,plan,plan_pin,consumed,actual):
        self.plan,self.plan_pin,self.actual=plan,plan_pin,actual
        self.began=consumed['began_ns'];self.work_deadline=consumed['work_deadline_ns']
        self.overall_deadline=consumed['overall_deadline_ns']
        self.root_calls=0;self.first_fault=None;self.stage='INTAKE';self.active=None
        self.started={};self.completed={};self.raised={};self.modules={};self.seals={};self.denied=[]
        self.oracle_work=0;self.oracle_work_unavailable=0;self.expanded_subtree_delta=0
        self.rows=[];self.diagnostics=[];self.malformed=[];self.component_rows=[];self.component_diagnostics=[];self.retained=[];self.output_pins=[]
        self.component_limits=clone(COMPONENT_LIMITS)

    def check(self):
        self.root_calls+=1
        try:
            need(self.root_calls<=CHECKPOINT_LIMIT,'invocation-total400m Root callback limit')
            need(NOW()<self.work_deadline,'original absolute180s work deadline')
            if self.first_fault is not None:raise self.first_fault
        except BaseException as error:
            if self.first_fault is None:self.first_fault=error
            raise

    def policy(self,action):
        try:return action()
        except BaseException as error:
            if self.first_fault is None:self.first_fault=error
            raise

    def guard(self):
        def action():
            self.check()
            for role,pin in self.plan['sources'].items():
                checked(pin)
            for role,module in self.modules.items():
                need(module.__file__==self.plan['sources'][role]['path'] and
                     callable_seal(module)==self.seals[role],'owned module origin/function/code/default binding')
            self.check()
        return self.policy(action)

    def fault_gate(self):
        if self.first_fault is not None:raise self.first_fault

    def call(self,role,name,data,action,expected_after=None):
        self.guard();before=argument_bytes(data()if callable(data)else data)
        self.check();key=role+'.'+name;self.started[key]=self.started.get(key,0)+1
        try:
            value=action()
        except BaseException as error:
            self.raised[key]=self.raised.get(key,0)+1
            self.fault_gate()
            self.fault_gate()
            self.guard()
            expected=before if expected_after is None else argument_bytes(expected_after)
            self.policy(lambda:need(argument_bytes(data()if callable(data)else data)==expected,'full literal call arguments after refusal/fault'))
            raise
        self.fault_gate();self.guard()
        expected=before if expected_after is None else argument_bytes(expected_after)
        self.policy(lambda:need(argument_bytes(data()if callable(data)else data)==expected,'full literal call arguments unchanged'))
        self.completed[key]=self.completed.get(key,0)+1
        return value

    def load(self,role):
        self.check();pin=self.plan['sources'][role];checked(pin)
        name='implicit_palette_actual_'+role
        spec=importlib.util.spec_from_file_location(name,pin['path'])
        need(spec is not None and spec.loader is not None,'exact Python Source loader')
        module=importlib.util.module_from_spec(spec);sys.modules[name]=module
        spec.loader.exec_module(module)
        need(module.__file__==pin['path'],'exact loaded Source origin')
        self.modules[role]=module;self.seals[role]=callable_seal(module);self.guard()
        return module

    def calls(self,role):
        return sum(value for key,value in self.started.items()if key.startswith(role+'.'))

    def write_json(self,name,value,cap,closure=False):
        path=self.actual/name;temporary=self.actual/(name+'.partial')
        need(not path.exists()and not temporary.exists(),'never overwrite or retry a packet')
        digest=hashlib.sha256();size=0;parts=0
        fd=os.open(str(temporary),os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
        with os.fdopen(fd,'wb')as output:
            for part in json.JSONEncoder(sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).iterencode(value):
                raw=part.encode('utf8');size+=len(raw);need(size+1<=cap,'whole JSON packet cap')
                output.write(raw);digest.update(raw);parts+=1
                if parts%1024==0:
                    if closure:need(NOW()<self.overall_deadline,'failure metadata210 deadline')
                    else:self.check()
            output.write(b'\n');digest.update(b'\n');size+=1;output.flush();os.fsync(output.fileno())
        if closure:need(NOW()<self.overall_deadline,'failure metadata completed before210')
        else:self.check()
        os.rename(temporary,path)
        return dict(path=str(path),bytes=size,sha256=digest.hexdigest())

