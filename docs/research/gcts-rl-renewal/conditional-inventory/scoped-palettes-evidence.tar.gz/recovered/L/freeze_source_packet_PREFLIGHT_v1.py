"""Raw/AST/ordinary metadata author; no subject import/call/evaluation."""
import ast
import hashlib
import json
from pathlib import Path

D = Path('/private/tmp/gcts-implicit-graph-L-20261020-v1')
S = D / 'implicit_wang_point_search_v1.py'
MASTER = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md')
B = Path('/private/tmp/gcts-implicit-wang-B-20261020-v2')


def pin(path):
    path = Path(path)
    raw = path.read_bytes()
    return {'path': str(path), 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}


def save(name, obj):
    path = D / name
    if path.exists():
        raise RuntimeError('no frozen metadata overwrite: ' + str(path))
    path.write_text(json.dumps(obj, sort_keys=True, ensure_ascii=True, indent=2) + '\n')
    return pin(path)


def main():
    master = pin(MASTER)
    assert master['sha256'] == 'c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9'
    assert master['bytes'] == 21657
    source = pin(S)
    tree = ast.parse(S.read_bytes(), filename=str(S))
    compile(tree, str(S), 'exec', dont_inherit=True, optimize=0)
    assert not any(isinstance(n, (ast.Import, ast.ImportFrom)) for n in ast.walk(tree))
    literal = {}
    for n in tree.body:
        if isinstance(n, ast.Assign) and len(n.targets) == 1 and isinstance(n.targets[0], ast.Name):
            try:
                literal[n.targets[0].id] = ast.literal_eval(n.value)
            except (ValueError, TypeError):
                pass
    assert literal['OFFSETS'] == ((0, -1), (1, 0), (0, 1), (-1, 0))
    assert len(literal['LIMIT_KEYS']) == 17 and len(literal['ORACLE_LIMIT_KEYS']) == 8
    gen_callbacks = []
    for n in ast.walk(tree):
        if isinstance(n, ast.GeneratorExp):
            for x in ast.walk(n):
                if isinstance(x, ast.Call) and isinstance(x.func, ast.Name) and x.func.id in ('_color', '_thaw', '_freeze'):
                    gen_callbacks.append(x.lineno)
    assert not gen_callbacks
    bp = pin(B / 'implicit_wang_palette_v2.py')
    assert bp['sha256'] == '9ba1bd5ea53c899a24488ff474ed77f88ab4d9f159c3d4131a6c8c3d1cad73cf'
    assert bp['bytes'] == 22683
    provenance = {
        'author_identity': '/root/conventional_library', 'source_only': True,
        'scientific_calls': 0, 'subject_imports': 0, 'subject_function_calls': 0,
        'oracle_calls': 0, 'fixture_calls': 0, 'search_calls': 0,
        'compiler_calls': 0, 'checker_calls': 0, 'simulator_calls': 0,
        'actual_execution_authorized': False, 'mathematical_authority': False,
        'runtime_qualified': False, 'current_master': master, 'source': source,
        'oracle_source': bp, 'oracle_handoff': pin(B / 'handoff-v1.json'),
    }
    snapshot = dict(provenance, schema='implicit-wang-snapshot-API-v1',
        snapshot_schema=literal['SNAPSHOT'],
        exact_keys=['schema', 'reason', 'mode', 'palette_descriptor', 'points', 'chosen',
                    'marks', 'domains', 'dependencies', 'exclusions', 'branch_stack',
                    'scheduler', 'rollback_parent', 'work'],
        core_exact_keys=['points', 'chosen', 'marks', 'domains', 'exclusions'],
        rows={
            'points': '[point_index,[x,y],occupancy0or1,root_generation] in original center order.',
            'chosen': '[point_index,semantic_ID,edges_NESW_tuple,placed_generation] in center order; placement identity is(point_index,semantic_ID).',
            'marks': '[[mx,my],channel,full_typed_value,reference_count,fixed_bool], sorted(point,channel). Pins start refcount1; each placed edge adds1; explicit0 never absence.',
            'domains': 'One list entry per center; occupied isNone. Unfilled exactkeys point,mask,physical_count,matching_exclusions,degree. mask is4tuple;Noneonlytopwildcard; assigned0 passes to B as an incompatible literal. degree=physical_count-len(matching_exclusions).',
            'dependencies': '[[mx,my],[[point_index,side_index],...]] sortedpoint, original site/side order. All four midpoint supports at all origins; pins outside this support have no false dependent candidates.',
            'exclusions': 'Each {point,id,parent_support}; parent_support=[[point,id],...] in center order. FIRST only, after an exhaustively failed selected child, active at that center under descendants of that exact parent. Only matching unique IDs subtract from a domain.',
            'branch_stack': 'Each {parent:full_core,point,id,next_rank,degree}. Full cores immutable internally, detached for observation. ALL cursor describes enumerated alternatives, never a pruning proof; ALL exclusions remainempty.',
            'scheduler': '[DEAD|FORCED|BRANCH|COMPLETE,point_orNone,degree]; globalDEADfirst,globalFORCEDsecond,then(root_generation,degree,point_index).',
            'rollback_parent': 'Full core of just-popped frame in BOTH BEFORE_ROLLBACK and AFTER_ROLLBACK;Noneotherwise. AFTER current core must equal this full parent. Popped frame is not fabricated into current branch_stack.',
            'palette_descriptor': 'Full immutable B recipe tuple, not a digest or sampled palette.',
            'work': 'Passive detached work/count cutoff prior to later snapshot verification/callback/output, not terminal CPU work.'},
        reasons=['INITIAL', 'BEFORE_DECISION', 'BEFORE_ROLLBACK', 'AFTER_ROLLBACK', 'BEFORE_ROOT_RESTORE', 'ROOT_RESTORED'],
        lifecycle='All snapshots detached and observer must be read-only. Full typed pre/post comparison rejects mutation. Every decision is preceded by an observed state if callback supplied. Final root restores the exact original immutable core and empty frames; work/query/event/tile-cache costs persist and are not rollback state.',
        implicit_incidence='Forward domain is the exact represented set of IDs matching the four assigned masks minus justified exclusions at one unfilled center, each contribution1. Reverse incidence maps each such placement back to that center only. No full universe materialization/top-k. Root must independently enumerate the entire literal comparison palette and check this representation at every offered stable state.',
        authority='Neither count/select nor this snapshot is an independent mathematical certificate. Current B Source and exact Root wrappers/argument guards remain trust prerequisites.')
    snapshot_pin = save('snapshot-API-v1.json', snapshot)
    api = dict(provenance, schema='implicit-wang-point-search-API-v1',
        status='SOURCE_ONLY_UNEXECUTED_CANDIDATE', version=literal['VERSION'],
        signature="search(instance,palette_module,descriptor,*,check,limits,oracle_limits,observe=None,mode='first')",
        instance={'schema': literal['SCHEMA'], 'required_centers': 'Nonempty ordered distinct signed-even[x,y] list.',
                  'admissible_origins': 'Exactly same ordered complete center list; every full palette ID at every origin.',
                  'fixed_background_marks': 'List[[[mx,my],channel,value],...]; unique(point,channel). edge value exactint/string or tagged constructor tuple, notbool/nestedNone. Other channels exact finite builtin data, preserved even outside every tile support.',
                  'root_generations': 'None=all0 master finite-root specialization; explicit nonnegative exactint list uses EXPLICIT_ROOT_GENERATION_TEST_VARIANT label.'},
        descriptor="('implicit-wang-palette-v1',machine_tuple,wire_tuple); same complete immutable B descriptor across all sites.",
        limits=list(literal['LIMIT_KEYS']), oracle_limits=list(literal['ORACLE_LIMIT_KEYS']),
        oracle_calls='Only count_query/select_query; fresh explicit oracle limits and charged external check per call. Exact full no-authority receipt keys/schema/count/work validated. Every completed full receipt retained. B attempted_work summed separately; failed B prefix stays on the original exception or interrupted_oracle_prefix for an own engine stop.',
        modes={'first': 'After failed child restores exact parent, add only that semantic ID under parent context and return to global scheduler, with fresh rank0. SOLUTION_FOUND is notexhaustive.',
               'all': 'No branch exclusions; parent immutable physical domain restored, decision rechecked, stable original rank advances. Every exact identity retained even when edge values agree. Actual cursor exhaustion only.'},
        result_schema='implicit-wang-point-search-result-v1',
        normal_result_keys=['schema','version','profile','status','exhaustive','mode','generation_profile','solutions','journal','query_journal','work','oracle_attempted_work_total','root_restored','final_observation_completed','mathematical_authority'],
        statuses=['SOLUTION_FOUND','EXHAUSTED_NO_SOLUTION','ALL_SOLUTIONS_EXHAUSTED','UNKNOWN_SEARCH_LIMIT'],
        solution='Each complete placement includes point/origin/full semanticID/full literal tile/generation; whole original target and all fixed+placed mark values/refcounts reconstructed before retention. Independent Root complete literal verification still required.',
        unknown='Only exact SearchLimit+private invocation owner token is normalized. No last callback after own stop; constant-reference root restoration, final_observation_completedfalse, unfinished prefix. No exhaustion or calibration admission. All completed ordinary query/event/solution rows retained; budget is never reset.',
        exceptions='Other BaseException objects propagate exactly (including foreign same-class, RuntimeError,ValueError,StopIteration), best-effort small implicit_search_prefix attachment only; B failure never becomes count0/singleton. Callback-bearing paths are ordinary functions/loops, no generators.',
        snapshot_API=snapshot_pin)
    api_pin = save('API-v1.json', api)
    obligations = dict(provenance, schema='implicit-wang-engine-source-arguments-v1',
        proof_status='MANUAL_SOURCE_ARGUMENTS_PENDING_DISTINCT_REVIEW',
        scope='Finite translation-only singleton-center unit t and exactly four NESW midpoint edge marks. No rotations, arbitrary extra tile-m, fractional/shared t, growth/whole-plane, fixed VM/FOL, learner or RL claim.',
        invariants=[
            'Complete immutable descriptor times every origin is the initial universe. Count oracle exactness/stable ID bijection is separately proved/tested. A huge implicit palette is never silently trimmed by reachability, role, board geometry or search proposal.',
            'At each unfilled point, physical count is full oracle mask count. Unique matching FIRST exclusions subtract once; nonmatching historical exclusions subtract zero. Stable selection rescans original masked rank and skips exact excluded IDs; no shifted-rank increment skips choices.',
            'Marks are a full value section with reference counts and fixed flags. Every dependency is built for all four supports at every site; a newly assigned edge refreshes all and only affected point domains, and t completion deactivates its center. Refcount-only changes do not alter masks. Unrelated immutable domain tuples are preserved.',
            'Before any action, whole frontier is checked forDEAD, thenFORCED; branch minimizes(root generation,degree,index). Explicit root0 dominates placement+1 so root generations stay0 in the default finite target.',
            'A branch saves the complete immutable core. All fallible placement/domain work precedes one core publication. Rollback uses the saved parent reference, preserving marks/refcounts/exclusions/domains/generations exactly; query/cache/journal costs are monotone.',
            'FIRST exclusion is justified only when the entire selected child has failed; success returns immediately. ALL successful children are never called impossible; independent fixed-domain cursors cover every alternative and root restore never claims successful alternatives were pruned.',
            'At terminal target, every center must be occupied once, every selected tile is retained from an authenticated select receipt, and all original fixed+selected edges and exact counts are freshly reconstructed. Root verifier remains independent.',
            'Read-only argument ownership and Root Source/callable guards are required. Caller inputs are never written; admission/final whole typed reconciliation plus detached snapshot pre/post checks are not a hostile-concurrency sandbox.' ],
        work_scope='work counts declared adapter visits, bulk structural copy items and oracle callback dispatches, not CPU instructions. Oracle private work remains a separate explicit total. Python allocation/sorting/wall/RSS/output cost remains under outer original gates; no performance equivalence follows from units.',
        representation_boundary='Finite recipe/domain masks are a NEW implicit representation profile, not a claim that a literal billion-tile JSON expansion fits128MiB. Root must predeclare encoded/logical packet accounting, retain exact complete recipe/cardinalities and all requested evidence. No cap/grant change is selected here.',
        source_ancestry='Library authored earlier literal Wang/general point engines, compiler/verifier, evidence/cold lineage. This new implementation is not an independent certificate of those or itself. B oracle authored separately; Root ordinary-domain recomputation/complete finite calibration and C review remain necessary.',
        future_checks='Exact full literal palette comparison per original machine, exhaustive degrees/membership/singletons at every offered state, independent full solutions/rollback/scheduler/refcounts, resource/fault/limit/identity fixtures, all with fresh Root review/grant. No calls now.')
    argument_pin = save('conformance-and-obligations-v1.json', obligations)
    fixtures = dict(provenance, schema='implicit-wang-engine-prospective-fixtures-v1',
        executable_fixture_source=False, executed=False,
        descriptions=[
            'Disconnected earlierFORCED and distant assigned scalar0DEAD: globalDEAD wins before any place.',
            'Disconnected branch site and distant singleton: globalFORCED wins before branch.',
            'Explicit generation[0,7] test variant: early unconstrained site wins over later smaller non-singleton; never label this all-root0 default.',
            'At leastfive original parent choices; firstthree fail then rank3 works. FIRST excludes/reselects fresh rank0; ALL complete solution population retains later choices without exclusion.',
            'Shared midpoint value agreement increments refcounts; rollback restores full fixed+placed counts and masks.',
            'Negative even centers, holes/nonrectangles, exterior pins, assigned scalar0 versus wildcardNone, seen0/plain0 tuple distinctions.',
            'AllpaletteIDs at allcenters; distinct semantic IDs with equal edges are distinct solutions, not quotient keys.',
            'Root complete unknown-certificate boards use whole palette, full pinned initial/final boundaries, no supplied witness; entire solution population independently enumerated.',
            'Per-call engine own limit and foreign same-class token; B own limit/Invalid; exact external RuntimeError/ValueError/StopIteration; no expected-bad catch may mask genuine Rootfault.',
            'Observer mutation and foreign observer failure; initial/afterrollback/rootrestored full literal recomputation, parent core pair exact; failed/unfinished prefix never exhaustion.',
            'Malformed duplicate/odd/origin-mismatched sites, malformed pin colors/bools/nestedNone, duplicate point/channel, nonexact limits, invalid masks and inconsistent count/select facade.' ],
        no_results='Descriptions only. Root owns all ordinary frozen fixture data/full cohorts/worker and grants. No target/helper/oracle/search/verifier called.')
    fixture_pin = save('prospective-fixtures-v1.json', fixtures)
    lines = {}
    for n in ast.walk(tree):
        if isinstance(n, (ast.ClassDef, ast.FunctionDef)):
            lines.setdefault(n.name, []).append([n.lineno, n.end_lineno])
    contract = dict(provenance, schema='implicit-wang-engine-Source-contract-v1',
        status='SOURCE_ONLY_NO_ACTUAL_AUTHORIZATION', API=api_pin, snapshot_API=snapshot_pin,
        conformance=argument_pin, fixture_descriptions=fixture_pin,
        source_regions=lines,
        immutable_ancestors_modified=False,
        imports=[],
        whole_outer_caps='Root original180 positive full-worker exit/output; later210 terminal;1GiB worker+Native separate highwater sum where applicable;128MiB declared packet/logical profile; log caps unchanged. This component has no Native/Model/compiler/checker/inverse/Reader calls.',
        missing='Distinct independent Source review, all finite runtime fixture/exhaustive equivalence/whole qualification and adopted common implicit output profile. No conformance/runtime gain inherited from older qualified code.')
    contract_pin = save('Source-contract-v1.json', contract)
    audit = dict(provenance, schema='implicit-wang-engine-author-static-audit-v1',
        independent_review=False, unused_compiles=1, AST_parses=1,
        checks=[{'name': x, 'passed': True} for x in
                ['current master wholepin', 'current B V2 wholepin', 'subject contains no imports',
                 'four literal NESW offsets', 'exact17search/8oracle limit literals',
                 'no generator-expression calls to callback-bearing freeze/thaw/color',
                 'Source AST parse and unused compile']],
        limits='These are authored bounded raw/AST checks. No Source function, fixture, oracle, mathematical predicate, compiler, search or verifier was invoked. Manual arguments and runtime assertions remain unexecuted, not tested passes.')
    audit_pin = save('author-static-audit-v1.json', audit)
    handoff = dict(provenance, schema='implicit-wang-point-search-handoff-v1',
        status='SOURCE_ONLY_UNEXECUTED', API=api_pin, snapshot_API=snapshot_pin,
        Source_contract=contract_pin, conformance=argument_pin,
        fixture_descriptions=fixture_pin, author_static_audit=audit_pin,
        metadata_author=pin(Path(__file__)), tools_stop_after_handoff=True)
    desc = save('handoff-v1.json', handoff)
    print(json.dumps({'source': source, 'API': api_pin, 'snapshot_API': snapshot_pin, 'handoff': desc}, sort_keys=True))


if __name__ == '__main__':
    main()
