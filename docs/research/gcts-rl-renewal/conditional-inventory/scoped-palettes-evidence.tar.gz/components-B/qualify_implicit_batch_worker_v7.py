"""UNEXECUTED whole implicit-palette and finite point-graph calibration worker.

Only fresh reviewed once-run execution may load/call the three components.
No Native/FOL-kernel/Model/Reader/inverse/solver imports or calls. No hostile sandbox
claim: input ownership, Source/callable custody and finite external gates apply.
"""
import time
NOW = time.monotonic_ns
ENTRY_NS = NOW()
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import types

VERSION = 'complete-implicit-batch-point-graph-worker-v3'
SOURCE_ROLES = ('worker','implicit','graph','selector','runner','observer')
SOURCE_PINS = {}  # Exact whole-subject Source pins are bound by the reviewed plan.

OUTER_LIMITS = dict(work_seconds=180, overall_seconds=210, memory_bytes=1073741824,
    result_bytes=134217728, expanded_bytes=134217728, stdout_bytes=4194304,
    stderr_bytes=4194304, worker_receipt_bytes=4194304,
    runner_metadata_bytes=8388608, observer_bytes=1048576)
SELECTOR_LIMITS=dict(work=400000000,symbols=256,states=100000,tiles=100000,colors=100000,cells=100000,dimension=10000)
IMPLICIT_LIMITS = dict(work=400000000,symbols=256,states=100000,transitions=1000000,integer_bits=4096,data_items=2000000,data_depth=128,string_chars=1000000)
GRAPH_LIMITS = dict(work=400000000,sites=10000,pins=100000,dependencies=40000,frames=10000,choices=1000000,solutions=10000,events=1000000,snapshots=1000000,snapshot_items=2000000,selected_tiles=1000000,oracle_queries=1000000,integer_bits=4096,coordinate_abs=1000000,data_items=2000000,data_depth=128,string_chars=1000000)
COMPONENT_LIMITS={'selector':SELECTOR_LIMITS,'implicit':IMPLICIT_LIMITS,'graph':GRAPH_LIMITS}
PROFILE_LIMITS = dict(IMPLICIT_LIMITS, queries=1000000, receipt_items=2000000)
PROFILE_QUERY_CHUNK = 128
PROFILE_GRANULARITY = 'PROFILE_ENTRY_EXIT_PLUS_LOCAL_QUERY_GUARDS_V1'
PROFILE_METRIC_KEYS = ('profile_count','profile_attempted_work','profile_preparation_work',
    'profile_query_kernel_work','profile_overhead_work','profile_postpreparation_overhead_work',
    'produced_receipt_count','preimage_completed_count','delivered_receipt_count',
    'attempted_queries','palette_attempted_work_known_total','palette_work_unavailable_count')

CHECKPOINT_LIMIT = 400000000
RESERVE_BYTES = 9437184
FORBIDDEN_EVENTS = ('subprocess.Popen','os.system','os.fork','os.posix_spawn','socket.connect','ctypes.dlopen')


class PolicyFailure(RuntimeError):
    pass


class PlannedForeign(BaseException):
    pass


def need(ok, message):
    if not ok:
        raise PolicyFailure(message)


def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode('utf8')


def clone(value):
    return json.loads(canonical(value))



def typed_value(value):
    """Strict typed literal carrier preserves dictionary order and tuple/list.

    Only called inside the once actual. Surrogatepass bytes preserve a lone
    surrogate pair versus an astral character, which JSON escapes can alias.
    """
    def visit(x,depth):
        need(depth<=128,'bounded typed argument guard depth')
        t=type(x)
        if x is None:return ['none']
        if t is bool:return ['bool',x]
        if t is int:return ['int',x]
        if t is float:return ['float_hex',x.hex()]
        if t is str:return ['str_utf8_surrogatepass_hex',x.encode('utf8','surrogatepass').hex()]
        if t is list:return ['list',[visit(y,depth+1)for y in x]]
        if t is tuple:return ['tuple',[visit(y,depth+1)for y in x]]
        need(t is dict,'ordinary typed argument carriers')
        return ['dict',[[visit(k,depth+1),visit(v,depth+1)]for k,v in x.items()]]
    return visit(value,0)


def argument_bytes(value):
    return json.dumps(typed_value(value),ensure_ascii=True,separators=(',',':'),allow_nan=False).encode('ascii')


def descriptor(path, raw):
    return dict(path=str(Path(path).resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


def checked(pin, cap=16777216):
    need(type(pin)is dict and set(pin)=={'path','bytes','sha256'} and type(pin['path'])is str and
         type(pin['bytes'])is int and 0<=pin['bytes']<=cap and type(pin['sha256'])is str and
         len(pin['sha256'])==64,'strict finite raw descriptor')
    path=Path(pin['path'])
    need(path.is_absolute()and path==path.resolve()and path.is_file()and not path.is_symlink(),'canonical regular raw input')
    raw=path.read_bytes();need(descriptor(path,raw)==pin,'complete raw hash/size/path join');return raw


def information(error):
    try:return dict(type=type(error).__name__,message=str(error)[:512])
    except BaseException:return dict(type='UNAVAILABLE',message='error metadata unavailable')


def callable_seal(module):
    rows=[];seen=set();pending=[('',vars(module))]
    while pending:
        prefix,values=pending.pop()
        for name,value in sorted(values.items()):
            key=prefix+name
            if type(value)is types.FunctionType and value.__module__==module.__name__:
                closure = value.__closure__
                closure_owners = []
                if closure is not None:
                    for cell in closure:
                        try: owner = id(cell.cell_contents)
                        except ValueError: owner = None
                        closure_owners.append((id(cell),owner))
                rows.append((key,id(value),id(value.__code__),id(value.__defaults__),
                             id(value.__kwdefaults__),id(closure),tuple(closure_owners)))
            elif type(value)is type and value.__module__==module.__name__ and id(value)not in seen:
                seen.add(id(value));rows.append((key,id(value)))
                owned={}
                for child,item in vars(value).items():
                    if type(item)in(staticmethod,classmethod):item=item.__func__
                    owned[child]=item
                pending.append((key+'.',owned))
    return tuple(sorted(rows))


# Future negative-only diagnostic path. No component, check, or Source replay.
FAILURE_SUMMARY_BYTES = 65536
FAILURE_SUMMARY_COUNTER_ROWS = 16
FAILURE_SUMMARY_DIRECTORY_ENTRIES = 64
FAILURE_SUMMARY_UINT_MAX = 9223372036854775807


def _summary_uint(value):
    return value if type(value) is int and 0 <= value <= FAILURE_SUMMARY_UINT_MAX else None


def _summary_text(value, maximum):
    if type(value) is not str:
        return dict(value=None, available=False, truncated=False)
    return dict(value=value[:maximum], available=True, truncated=len(value) > maximum)


def _summary_length(value):
    if type(value) not in (list, dict, tuple):
        return None
    return _summary_uint(len(value))


def _summary_counters(value):
    if type(value) is not dict:
        return dict(rows=[], total_entries=None, truncated=False, available=False)
    rows = []
    for label, count in value.items():
        if len(rows) == FAILURE_SUMMARY_COUNTER_ROWS:
            break
        rows.append([_summary_text(label, 48), _summary_uint(count)])
    return dict(rows=rows, total_entries=_summary_uint(len(value)),
                truncated=len(value) > len(rows), available=True)


def _failure_summary_record(s, primary):
    """Small new ordinary record; never str(error), clone(active), or prefix walk.

    All Session fields are owned plain carriers; external concurrent mutation is
    outside this protocol. Snapshot values are cutoff observations, not terminal
    totals. Failure to construct this record must leave the primary fault intact.
    """
    try:
        cutoff = _summary_uint(NOW())
    except BaseException:
        cutoff = None
    active = s.active if type(s.active) is dict else {}
    active_id = s.active if type(s.active) is str else active.get('id')
    last = s.rows[-1] if type(s.rows) is list and s.rows and type(s.rows[-1]) is dict else {}
    plan = s.plan if type(s.plan) is dict else {}
    plan_pin = s.plan_pin if type(s.plan_pin) is dict else {}
    try:
        fault_type = type(primary).__name__
    except BaseException:
        fault_type = None
    try:
        fault_args = BaseException.args.__get__(primary, BaseException)
        first_argument = fault_args[0] if type(fault_args) is tuple and fault_args else None
    except BaseException:
        first_argument = None
    return dict(
        schema='implicit-worker-failure-summary-v1', status='FAILED_OR_UNFINISHED',
        authority=False, mathematical_authority=False, resource_accepted=False,
        full_pipeline_qualified=False, no_failed_prefix_admission=True,
        invocation_id=_summary_text(plan.get('invocation_id'), 256),
        plan_sha256=_summary_text(plan_pin.get('sha256'), 64),
        stage=_summary_text(s.stage, 64), active_row_id=_summary_text(active_id, 96),
        active_row_stage=_summary_text(active.get('stage'), 64),
        first_available_fault=dict(type=_summary_text(fault_type, 128),
            literal_first_argument=_summary_text(first_argument, 256),
            origin='ROOT_FIRST_FAULT_LATCH' if s.first_fault is not None else 'CAUGHT_EXCEPTION',
            message_evaluated=False),
        snapshot_cutoff_ns=cutoff, clock_available=cutoff is not None,
        work_deadline_ns=_summary_uint(s.work_deadline),
        overall_deadline_ns=_summary_uint(s.overall_deadline),
        root_check_calls=_summary_uint(s.root_calls),
        call_started=_summary_counters(s.started),
        call_completed=_summary_counters(s.completed),
        call_raised=_summary_counters(s.raised),
        completed_case_count=_summary_length(s.rows),
        last_completed_case_id=_summary_text(last.get('id'), 96),
        component_progress_records=_summary_length(s.component_rows),
        diagnostic_records_retained=_summary_length(s.diagnostics),
        retained_call_receipts=_summary_length(s.retained),
        retained_output_descriptors=_summary_length(s.output_pins),
        counter_scope='Snapshot through cutoff; excludes later summary/bulk writes, cleanup and worker exit.',
        coverage='Scalar/capped metadata only; not a full prefix, mathematical outcome, bottleneck or completion certificate.')


def _write_failure_summary(s, summary):
    """One <=64KiB negative-only write, atomic name publication if it finishes.

    The parent may terminate at180s.210s is only the original negative-custody
    upper bound, never a guaranteed grace period. No success gate is consulted
    or changed here. No retries, overwrites, component calls, or Root.check.
    """
    raw = json.dumps(summary, sort_keys=True, separators=(',', ':'),
                     ensure_ascii=True, allow_nan=False).encode('ascii') + b'\n'
    if len(raw) > FAILURE_SUMMARY_BYTES:
        raise ValueError('bounded failure summary exceeded64KiB')
    if not NOW() < s.overall_deadline:
        raise ValueError('failure summary outside original210s custody')
    prior = 0
    entries = 0
    with os.scandir(s.actual) as directory:
        for item in directory:
            entries += 1
            if entries > FAILURE_SUMMARY_DIRECTORY_ENTRIES:
                raise ValueError('bounded failure directory census unavailable')
            record = item.stat(follow_symlinks=False)
            if record.st_mode & 0o170000 != 0o100000:
                raise ValueError('failure summary expects exclusive regular-file actual root')
            prior += record.st_size
    if prior + len(raw) + RESERVE_BYTES > OUTER_LIMITS['result_bytes']:
        raise ValueError('failure summary has no original physical budget remaining')
    path = s.actual / 'worker-failure-summary.json'
    temporary = s.actual / 'worker-failure-summary.json.partial'
    if path.exists() or temporary.exists():
        raise ValueError('failure summary cannot overwrite or retry')
    fd = os.open(str(temporary), os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    try:
        output = os.fdopen(fd, 'wb')
    except BaseException:
        try:
            os.close(fd)
        except BaseException:
            pass
        raise
    with output:
        if output.write(raw) != len(raw):
            raise ValueError('failure summary short write')
        output.flush()
        os.fsync(output.fileno())
    if not NOW() < s.overall_deadline:
        raise ValueError('failure summary did not complete before210s custody')
    # Directory exclusive ownership is a prerequisite; no hostile-race seal.
    os.rename(temporary, path)
    completed = NOW()
    if not completed < s.overall_deadline:
        raise ValueError('failure summary publication observed after210s custody')
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(),
                completed_ns=completed,
                diagnostic_only=True, complete_prefix=False)



class Session:
    def __init__(self,plan,plan_pin,consumed,actual):
        self.plan,self.plan_pin,self.actual=plan,plan_pin,actual
        self.began=consumed['began_ns'];self.work_deadline=consumed['work_deadline_ns']
        self.overall_deadline=consumed['overall_deadline_ns']
        self.root_calls=0;self.first_fault=None;self.stage='INTAKE';self.active=None
        self.started={};self.completed={};self.raised={};self.modules={};self.seals={};self.denied=[]
        self.oracle_work=0;self.oracle_work_unavailable=0;self.expanded_subtree_delta=0
        self.rows=[];self.diagnostics=[];self.malformed=[];self.component_rows=[];self.component_diagnostics=[];self.retained=[];self.output_pins=[]
        self.component_limits=clone(COMPONENT_LIMITS)
        self.profile_rows=[];self.profile_lifetimes=[];self.profile_owners=[];self.profile_accounting=[]
        self.profile_query_context=None
        self.palette_work_known_total=0;self.palette_work_unavailable_count=0
        self.batch_diagnostics=[];self.batch_diagnostic_progress=[];self.batch_diagnostic_owners=[]
        self.worker_function_seal=callable_seal(sys.modules[__name__])

    def check(self):
        self.root_calls+=1
        try:
            need(self.root_calls<=CHECKPOINT_LIMIT,'invocation-total400m Root callback limit')
            need(NOW()<self.work_deadline,'original absolute180s work deadline')
            if self.first_fault is not None:raise self.first_fault
        except BaseException as error:
            if self.first_fault is None:self.first_fault=error
            raise

    def policy(self,action):
        try:return action()
        except BaseException as error:
            if self.first_fault is None:self.first_fault=error
            raise

    def guard(self):
        def action():
            self.check()
            for role,pin in self.plan['sources'].items():
                checked(pin)
            need(callable_seal(sys.modules[__name__])==self.worker_function_seal,
                 'whole worker function/code/default/closure-owner binding')
            for role,module in self.modules.items():
                need(module.__file__==self.plan['sources'][role]['path'] and
                     callable_seal(module)==self.seals[role],'owned module origin/function/code/default binding')
            self.check()
        return self.policy(action)

    def fault_gate(self):
        if self.first_fault is not None:raise self.first_fault

    def call(self,role,name,data,action,expected_after=None):
        self.guard();before=argument_bytes(data()if callable(data)else data)
        self.check();key=role+'.'+name;self.started[key]=self.started.get(key,0)+1
        try:
            value=action()
        except BaseException as error:
            self.raised[key]=self.raised.get(key,0)+1
            self.fault_gate()
            self.fault_gate()
            self.guard()
            expected=before if expected_after is None else argument_bytes(expected_after)
            self.policy(lambda:need(argument_bytes(data()if callable(data)else data)==expected,'full literal call arguments after refusal/fault'))
            raise
        self.fault_gate();self.guard()
        expected=before if expected_after is None else argument_bytes(expected_after)
        self.policy(lambda:need(argument_bytes(data()if callable(data)else data)==expected,'full literal call arguments unchanged'))
        self.completed[key]=self.completed.get(key,0)+1
        return value

    def load(self,role):
        self.check();pin=self.plan['sources'][role];checked(pin)
        name='implicit_palette_actual_'+role
        spec=importlib.util.spec_from_file_location(name,pin['path'])
        need(spec is not None and spec.loader is not None,'exact Python Source loader')
        module=importlib.util.module_from_spec(spec);sys.modules[name]=module
        spec.loader.exec_module(module)
        need(module.__file__==pin['path'],'exact loaded Source origin')
        self.modules[role]=module;self.seals[role]=callable_seal(module);self.guard()
        return module

    def calls(self,role):
        return sum(value for key,value in self.started.items()if key.startswith(role+'.'))

    def write_json(self,name,value,cap,closure=False):
        path=self.actual/name;temporary=self.actual/(name+'.partial')
        need(not path.exists()and not temporary.exists(),'never overwrite or retry a packet')
        digest=hashlib.sha256();size=0;parts=0
        fd=os.open(str(temporary),os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
        with os.fdopen(fd,'wb')as output:
            for part in json.JSONEncoder(sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).iterencode(value):
                raw=part.encode('utf8');size+=len(raw);need(size+1<=cap,'whole JSON packet cap')
                output.write(raw);digest.update(raw);parts+=1
                if parts%1024==0:
                    if closure:need(NOW()<self.overall_deadline,'failure metadata210 deadline')
                    else:self.check()
            output.write(b'\n');digest.update(b'\n');size+=1;output.flush();os.fsync(output.fileno())
        if closure:need(NOW()<self.overall_deadline,'failure metadata completed before210')
        else:self.check()
        os.rename(temporary,path)
        return dict(path=str(path),bytes=size,sha256=digest.hexdigest())



"""Actual-only independent literal oracles; no top-level subject operation."""

def immutable(x):
    if type(x) is list:
        return tuple(immutable(v) for v in x)
    if type(x) is tuple:
        return tuple(immutable(v) for v in x)
    return x


def literal_tiles(s, record):
    old = s.modules['selector']
    args = [record['machine'], record['wire']]
    limits = dict(SELECTOR_LIMITS)
    result = s.call('selector', 'compile_unknown_palette', dict(args=args, limits=limits),
        lambda: old.compile_unknown_palette(*args, check=s.check, limits=limits))
    palette = result['palette']
    tiles = []
    for tile in palette['tiles']:
        s.check()
        edges = tuple(palette['color_constructors'][n] for n in tile['edges_NESW'])
        identity = (tile['kind'], tile['origin'])
        tiles.append(dict(id=identity, kind=tile['kind'], origin=tile['origin'],
            edges_NESW=edges, t=[[[0, 0], 1]],
            m=[[[0, -1], 'edge', edges[0]], [[1, 0], 'edge', edges[1]],
               [[0, 1], 'edge', edges[2]], [[-1, 0], 'edge', edges[3]]]))
    need(len({v['id'] for v in tiles}) == len(tiles), 'distinct legacy semantic inventory identities')
    return palette, tiles


def tile_key(tile):
    need(type(tile) is dict and set(tile) == {'id','kind','origin','edges_NESW','t','m'},
         'exact semantic tile fields')
    need(tile['id'] == (tile['kind'], tile['origin']), 'semantic inventory identity')
    need(type(tile['edges_NESW']) is tuple and len(tile['edges_NESW']) == 4,
         'four immutable exact edge values')
    n,e,b,w = tile['edges_NESW']
    need(argument_bytes(tile['t']) == argument_bytes([[[0,0],1]]) and argument_bytes(tile['m']) == argument_bytes([
        [[0,-1],'edge',n], [[1,0],'edge',e], [[0,1],'edge',b], [[-1,0],'edge',w]]),
        'exact positive center and complete assigned point markings')
    return (tile['id'], tile['edges_NESW'])


def tile_bytes(tile):
    # Tile field insertion order is not inventory semantics. Full value types
    # and every declared field remain compared; code/typed-value order rules
    # from the earlier codec experiment are not silently applied to this API.
    return argument_bytes({k:tile[k]for k in sorted(tile)})


def account_palette_work(s,amount):
    """One cost observation, never an invocation or a callback.

    Missing constructor prefixes are unavailable, never zero. On an active
    failure this helper cannot replace the primary. Invalid accounting still
    independently latches a Root policy fault for the later fault gate.
    """
    try:
        if amount is None:
            s.palette_work_unavailable_count += 1
        else:
            need(type(amount)is int and amount>=0,'exact available palette private work')
            s.palette_work_known_total += amount
    except BaseException as accounting_error:
        if s.first_fault is None:s.first_fault=accounting_error
        # This function is metadata-only. The independent fault latch is
        # authoritative and is checked before any expected-fault admission.
    return None


def record_profile_accounting(s,profile_id,*,receipt=None,prefix=None,lifetime=None):
    """Retain one known/unknown cost row for one complete attempted scope.

    Call exactly once, including diagnostics. This is not an extra allowance;
    it observes already attempted cumulative work. The helper itself performs
    no check, Source replay, component operation or warmup. Its failure latches
    independently, so an expected diagnostic cannot launder missing accounting.
    """
    try:
        need(type(profile_id)is str,'literal profile accounting id')
        need(not any(row['id']==profile_id for row in s.profile_accounting),
             'one metric observation per attempted profile')
        source=receipt if type(receipt)is dict else prefix if type(prefix)is dict else {}
        live=lifetime if type(lifetime)is dict else {}
        amount=source.get('attempted_work')
        if amount is None and live.get('work')is not None:
            amount=live['work'].work
        preparation=source.get('preparation_attempted_work',live.get('preparation_work'))
        kernel=source.get('query_attempted_work',live.get('query_work'))
        counters={}
        for key in('attempted_queries','produced_receipt_count',
                   'preimage_completed_count','delivered_receipt_count'):
            value=source.get(key,live.get(key))
            need(value is None or type(value)is int and value>=0,
                 'exact available profile lifetime counter')
            counters[key]=value
        for value in(amount,preparation,kernel):
            need(value is None or type(value)is int and value>=0,
                 'exact available cumulative profile work')
        overhead=None if amount is None or kernel is None else amount-kernel
        post=None if overhead is None or preparation is None else overhead-preparation
        need(overhead is None or overhead>=0,'nonnegative total profile overhead')
        need(post is None or post>=0,'nonnegative postpreparation profile overhead')
        row=dict(id=profile_id,attempted_work=amount,preparation_work=preparation,
            query_kernel_work=kernel,overhead_work=overhead,
            postpreparation_overhead_work=post,private_work_available=amount is not None,
            complete=type(receipt)is dict,**counters)
        s.profile_accounting.append(row)
        account_palette_work(s,amount)
    except BaseException as accounting_error:
        if s.first_fault is None:s.first_fault=accounting_error
    return None


def profile_metrics(s):
    """Twelve exact fields. Work sums cover available observations only.

    Cost-unavailable observations remain explicitly counted; numeric sums do
    not assert private-work completeness. Never add per-query costs to totals.
    """
    # Expected-failed diagnostic profiles are retained and charged in the
    # all-palette known/unavailable totals below, but are not completed profiles.
    # Their different production/copy/delivery populations remain per-row data.
    rows=[row for row in s.profile_accounting if row['complete']]
    def total(key):
        result=0
        for row in rows:
            value=row[key]
            if value is not None:result+=value
        return result
    return dict(profile_count=len(rows),
        profile_attempted_work=total('attempted_work'),
        profile_preparation_work=total('preparation_work'),
        profile_query_kernel_work=total('query_kernel_work'),
        profile_overhead_work=total('overhead_work'),
        profile_postpreparation_overhead_work=total('postpreparation_overhead_work'),
        produced_receipt_count=total('produced_receipt_count'),
        preimage_completed_count=total('preimage_completed_count'),
        delivered_receipt_count=total('delivered_receipt_count'),
        attempted_queries=total('attempted_queries'),
        palette_attempted_work_known_total=s.palette_work_known_total,
        palette_work_unavailable_count=s.palette_work_unavailable_count)


def palette_call(s,name,args,limits=None,callback=None):
    """Unchanged standalone path, retained for builds/description/33 old tests."""
    bound=dict(IMPLICIT_LIMITS if limits is None else limits)
    callback=s.check if callback is None else callback
    try:
        receipt=s.call('implicit',name,dict(args=args,limits=bound),
            lambda:getattr(s.modules['implicit'],name)(*args,check=callback,limits=bound))
    except BaseException as error:
        prefix=getattr(error,'implicit_palette_prefix',None)
        try:
            amount=prefix.get('attempted_work')if type(prefix)is dict else None
            account_palette_work(s,amount)
            s.retained.append(dict(role='implicit',operation=name,args=args,limits=bound,
                completed=False,error=information(error),prefix=prefix))
        except BaseException as retention_error:
            if s.first_fault is None:s.first_fault=retention_error
        raise
    account_palette_work(s,receipt.get('attempted_work')if type(receipt)is dict else None)
    s.fault_gate()
    s.retained.append(dict(role='implicit',operation=name,args=args,limits=bound,
        completed=True,receipt=receipt))
    return receipt


def function_owner_seal(value):
    need(type(value)is types.FunctionType,'owned synchronous profile callback function')
    closure=value.__closure__
    owners=[]
    if closure is not None:
        for cell in closure:
            try:
                content=cell.cell_contents
                owner=id(content)
            except ValueError:
                content=None;owner=None
            class_members=[]
            if type(content)is type:
                for name,item in sorted(vars(content).items()):
                    if type(item)in(staticmethod,classmethod):item=item.__func__
                    if type(item)is types.FunctionType:
                        class_members.append((name,id(item),id(item.__code__),
                            id(item.__defaults__),id(item.__kwdefaults__),id(item.__closure__)))
            owners.append((id(cell),owner,tuple(class_members)))
    return(id(value),id(value.__code__),id(value.__defaults__),id(value.__kwdefaults__),
           id(closure),tuple(owners))


def bind_profile_query(s,query):
    context=s.profile_query_context
    need(type(context)is dict and context['query']is None,'one synchronous scoped query owner')
    context['query']=query
    context['query_seal']=function_owner_seal(query)
    context['owners'].append(query)


def _exact_implicit_limits(limits):
    return(type(limits)is dict and len(limits)==len(IMPLICIT_LIMITS) and
           all(type(key)is str and key in IMPLICIT_LIMITS and type(value)is int and
               value==IMPLICIT_LIMITS[key]for key,value in limits.items()))


def profile_query(s,name,args,limits=None,callback=None):
    """Local query guard inside a fully custodied profile, no file rehash.

    The active dispatcher is replaced by the exact L charged_check for every
    dynamic graph request, so every internal B tick also charges L's work.
    Restoration occurs on both return and fault; descriptor/profile preparation
    and reconciliation use the Root check instead of a stale graph callback.
    """
    context=s.profile_query_context
    need(type(context)is dict and context['query']is not None,'query has a live Root profile owner')
    need(args[0]is context['descriptor'],'exact descriptor object within profile')
    if limits is not None:need(_exact_implicit_limits(limits),'exact unchanged graph oracle limits')
    need(name in('count_query','select_query'),'declared local query operation')
    request=('count',args[1])if name=='count_query'else('select',args[1],args[2])
    before=argument_bytes(request)
    previous=context['check']
    selected_check=s.check if callback is None else callback
    need(callable(selected_check),'exact charged dynamic callback')
    # Keep the callback and every argument owner alive through final custody.
    context['owners'].append((selected_check,args,request,before))
    context['requests'].append(request)
    context['check']=selected_check
    key='implicit.profile_'+name
    s.started[key]=s.started.get(key,0)+1
    try:
        need(function_owner_seal(context['query'])==context['query_seal'],
             'scoped query function/code/default/closure owner unchanged')
        receipt=context['query'](request)
    except BaseException:
        s.raised[key]=s.raised.get(key,0)+1
        # Root independent faults dominate an otherwise expected graph fault.
        s.fault_gate()
        raise
    finally:
        context['check']=previous
    s.fault_gate()
    s.policy(lambda:need(argument_bytes(request)==before,'full local literal request unchanged'))
    need(function_owner_seal(context['query'])==context['query_seal'],
         'scoped query binding unchanged after delivery')
    s.completed[key]=s.completed.get(key,0)+1
    return receipt


def _ordinary_profile_lifetime(state):
    """One complete ordinary projection; raw owner aggregate remains retained."""
    keys=('schema','descriptor','limits','active','busy','active_query','attempted_queries',
          'produced_receipt_count','preimage_completed_count','delivered_receipt_count',
          'receipts','requests','expected_receipts','query_work','receipt_items',
          'preparation_work','stage','failed_stage','custody_entry_attempted',
          'custody_entry_completed','custody_exit_attempted','custody_exit_completed',
          'custody_cleanup_error','registered','authority')
    ordinary={key:state[key]for key in keys}
    work=state['work']
    ordinary['attempted_work']=None if work is None else work.work
    ordinary['data_items']=None if work is None else work.items
    fault=state['query_fault']
    ordinary['query_fault']=None if fault is None else information(fault)
    ordinary['body_result']=state['body_result']
    return ordinary


def profile_call(s,profile_id,desc,guard_data,body):
    """One Root complete Source/closure/argument boundary for one profile."""
    need(s.profile_query_context is None,'no nested or warm profile state')
    bound=dict(PROFILE_LIMITS)
    data=dict(descriptor=desc,data=guard_data,limits=bound,
              granularity=PROFILE_GRANULARITY)
    before=argument_bytes(data)
    owner_seal=function_owner_seal(body)
    registered=[]
    context=dict(id=profile_id,descriptor=desc,query=None,query_seal=None,
                 check=s.check,owners=[body,data,before],requests=[])
    s.profile_query_context=context
    s.profile_owners.append(context)
    def dispatcher():
        context['check']()
    def custody(which):
        def verify():
            need(which in('entry','exit'),'exact profile custody endpoint')
            s.guard()
            need(argument_bytes(data)==before,'full profile descriptor/declared input/limits unchanged')
            need(function_owner_seal(body)==owner_seal,
                 'full profile body function/code/default/closure owner unchanged')
            if context['query']is not None:
                need(function_owner_seal(context['query'])==context['query_seal'],
                     'full scoped query function/code/default/closure owner unchanged')
            s.check()
        s.policy(verify)
        return None
    def retain(state):
        need(not registered,'one complete raw profile lifetime registration')
        registered.append(state)
        s.profile_lifetimes.append(state)
        context['owners'].append(state)
        return None
    # Keep callbacks and their captured owners alive, including fault paths.
    context['owners'].extend((dispatcher,custody,retain,registered))
    key='implicit.with_profile';s.started[key]=s.started.get(key,0)+1
    try:
        receipt=s.modules['implicit'].with_profile(desc,body,check=dispatcher,
            limits=bound,custody=custody,retain=retain)
    except BaseException as primary:
        s.raised[key]=s.raised.get(key,0)+1
        prefix=getattr(primary,'implicit_palette_batch_prefix',None)
        lifetime=registered[0]if registered else None
        record_profile_accounting(s,profile_id,prefix=prefix,lifetime=lifetime)
        # Best-effort ordinary projection cannot mask the exact primary. The
        # raw lifetime remains in s.profile_lifetimes even if projection fails.
        try:
            s.profile_rows.append(dict(id=profile_id,complete=False,prefix=prefix,
                lifetime=None if lifetime is None else _ordinary_profile_lifetime(lifetime)))
        except BaseException as projection_error:
            if s.first_fault is None:s.first_fault=projection_error
        s.fault_gate()
        raise
    finally:
        s.profile_query_context=None
    record_profile_accounting(s,profile_id,receipt=receipt,lifetime=registered[0]if registered else None)
    s.fault_gate()
    need(len(registered)==1 and receipt['profile_closed']is True,'complete registered closed profile')
    count=receipt['attempted_queries']
    need(count==receipt['produced_receipt_count']==receipt['preimage_completed_count']==
         receipt['delivered_receipt_count']==len(receipt['receipts'])==
         len(receipt['attempted_requests'])==len(receipt['exact_receipt_preimages'])==
         len(context['requests']),'normal profile exact request/production/preimage/delivery populations')
    need(receipt['active_query']is None,'no active query at normal profile close')
    need(receipt['body_result']is None,'caller-owned profile consumer outputs kept separately')
    ordinary=_ordinary_profile_lifetime(registered[0])
    # The one ordinary lifetime stores every full raw receipt/request/preimage.
    # The component return repeats these same sequences. Store only its other
    # fields and explicit complete field bindings; retain the actual original
    # return object in owners and conservatively charge reconstructed duplicates
    # to the unchanged expanded-byte gate. No hash substitutes for any value.
    duplicate_keys=('receipts','attempted_requests','exact_receipt_preimages','body_result')
    metadata={key:value for key,value in receipt.items()if key not in duplicate_keys}
    bindings=dict(receipts=dict(field='receipts',container='list'),
        attempted_requests=dict(field='requests',container='tuple'),
        exact_receipt_preimages=dict(field='expected_receipts',container='tuple'),
        body_result=dict(field='body_result',container='identity'))
    row=dict(id=profile_id,complete=True,lifetime=ordinary,
        profile_return_metadata=metadata,profile_return_bindings=bindings,
        reconstruction_scope='Full return reconstructed from the same row lifetime; conservative expanded-byte bound.')
    full_row=dict(id=profile_id,complete=True,receipt=receipt,lifetime=ordinary)
    s.check()
    raw_full=canonical(full_row)
    raw_compact=canonical(row)
    s.check()
    delta=max(0,len(raw_full)-len(raw_compact))
    row['expanded_reconstruction_charge_bytes']=delta
    s.expanded_subtree_delta+=delta
    context['owners'].extend((receipt,ordinary,row))
    s.profile_rows.append(row)
    s.completed[key]=s.completed.get(key,0)+1
    return receipt['body_result']


def final_profile_custody(s):
    """Retain originals through final custody; no second ordinary projection."""
    s.guard()
    need(s.profile_query_context is None,'all normal profile dispatchers released')
    for context in s.profile_owners:
        s.check()
        need(type(context)is dict and context['check'].__self__ is s,
             'closed profile restored Root dispatcher owner')
        if context['query']is not None:
            need(function_owner_seal(context['query'])==context['query_seal'],
                 'scoped query owner retained through final custody')
    for row in s.profile_accounting:
        s.check()
        need(type(row['private_work_available'])is bool,'explicit private-cost availability')
    s.fault_gate()


def qualify_small_palette(s,record):
    s.active=record['id']
    progress=dict(id=record['id'],stage='LITERAL_BUILD',input=record,queries=[])
    s.component_rows.append(progress)
    palette,tiles=literal_tiles(s,record)
    progress.update(legacy_palette=palette,semantic_tiles=tiles,stage='IMPLICIT_BUILD')
    build=palette_call(s,'build_palette_query',[record['machine'],record['wire']])
    desc=build['descriptor']
    description=palette_call(s,'describe',[desc])
    buckets={}
    keys={tile_key(tile):tile for tile in tiles}
    for tile in tiles:
        for bits in range(16):
            s.check()
            mask=tuple(tile['edges_NESW'][i]if bits&(1<<i)else None for i in range(4))
            buckets.setdefault(mask,[]).append(tile)
    zero_masks=[
        (0,None,None,None),
        (('not_a_palette_color',),None,None,None),
        (('cell',('plain',0)),('pair',('plain',1),('plain',0)),None,None),
        (('cell',('plain',0)),None,None,('pair',('plain',0),('plain',1))),
        (('cell',('wall',)),None,None,None),
        (('cell',('head',record['machine']['accepting'],0)),
         ('pair',('head',record['machine']['accepting'],0),('plain',0)),
         ('cell',('plain',0)),('pair',('plain',0),('head',record['machine']['accepting'],0))),
        (('cell',('head',0,0)),('pair',('head',0,0),('head',0,0)),
         None,('pair',('head',0,0),('head',0,0))),
    ]
    for mask in zero_masks:
        s.check()
        expected=[tile for tile in tiles if all(value is None or value==tile['edges_NESW'][i]
                                              for i,value in enumerate(mask))]
        need(not expected,'declared empty cross-splice really has no literal tile')
        buckets.setdefault(mask,[])
    progress.update(descriptor=desc,build=build,description=description,stage='QUERIES')
    queries=progress['queries']
    # Construct the entire original ordered request stream from independent
    # literal bucket populations. Counts never choose how many ranks to test.
    # Count then every rank per bucket, preserving original insertion order.
    pending=[]
    answers=[]
    scope_ordinal=0
    def flush():
        nonlocal scope_ordinal
        need(pending,'nonempty deterministic profile chunk')
        requests=tuple(pending)
        pending.clear()
        scope_ordinal+=1
        values=[]
        def body(query):
            bind_profile_query(s,query)
            for request in requests:
                s.check()
                if request[0]=='count':
                    value=profile_query(s,'count_query',[desc,request[1]])
                else:
                    value=profile_query(s,'select_query',[desc,request[1],request[2]])
                values.append(value)
            return None
        profile_call(s,record['id']+'-small-profile-'+str(scope_ordinal),desc,
            dict(record=record,ordered_requests=requests),body)
        need(len(values)==len(requests),'whole deterministic request chunk delivered')
        answers.extend(zip(requests,values))
    for mask,expected in buckets.items():
        s.check()
        pending.append(('count',mask))
        if len(pending)==PROFILE_QUERY_CHUNK:flush()
        for rank in range(len(expected)):
            s.check()
            pending.append(('select',mask,rank))
            if len(pending)==PROFILE_QUERY_CHUNK:flush()
    if pending:flush()
    # Verify all results only after retaining the complete unchanged stream.
    position=0;witnesses=0
    for query_index,(mask,expected)in enumerate(buckets.items()):
        s.check()
        request,q=answers[position];position+=1
        need(request==('count',mask)and type(q['count'])is int and q['count']==len(expected),
             'complete implicit degree equals independent literal projection bucket')
        found=[];costs=[]
        for rank in range(len(expected)):
            s.check()
            request,selected=answers[position];position+=1
            need(request==('select',mask,rank),'all independent ranks retain original query order')
            tile=selected['tile'];key=tile_key(tile)
            need(key in keys and tile_bytes(tile)==tile_bytes(keys[key]),
                 'full selected point tile equals independent original literal tile')
            need(all(value is None or tile['edges_NESW'][i]==value for i,value in enumerate(mask)),
                 'selected rank matches all assigned values together')
            found.append(tile);costs.append(selected['attempted_work']);witnesses+=1
        need(len({tile_key(tile)for tile in found})==len(found)and
             {tile_key(tile)for tile in found}=={tile_key(tile)for tile in expected},
             'every query unranking is a distinct exhaustive bijection')
        queries.append(dict(index=query_index,mask=mask,count=q['count'],
            count_attempted_work=q['attempted_work'],select_attempted_work=costs,
            selected_tiles=found,complete=True))
    need(position==len(answers),'entire unchanged query stream verified')
    need(witnesses==16*len(tiles),'exact sixteen full-inventory witness populations')
    if not hasattr(s,'literal_models'):s.literal_models={}
    s.literal_models[record['id']]=(palette,tiles,desc,buckets)
    s.oracle_work+=1
    return dict(id=record['id'],complete=True,input=record,descriptor=desc,
        build=build,description=description,legacy_palette=palette,semantic_tiles=tiles,
        queries=queries,nonempty_mask_queries=sum(bool(value['count'])for value in queries),
        zero_mask_queries=sum(not value['count']for value in queries),
        selected_witnesses=witnesses,full_literal_tile_count=len(tiles),
        scope='All nonempty masks, all independent ranks, plus declared empty cross-splices; deterministic128-request custody scopes, not the full Cartesian cube of colors.')


def independent_membership(s, tile, record):
    """Direct old local-rule definition, deliberately not the factorized generator."""
    tile_key(tile)
    machine=record['machine'];b=machine['alphabet_size'];Q=machine['state_count']
    kind=tile['kind'];origin=tile['origin'];edges=tile['edges_NESW']
    # Large selected witnesses are joined to a focused independently specified
    # literal template in the actual input bank; step outputs use radius-one rule.
    if kind=='step':
        need(type(origin)is tuple and len(origin)==3,'complete step triple')
        l,c,r=origin
        def cell(v,wall=False):
            if wall and v==('wall',):return
            need(type(v)is tuple and v,'literal cell')
            if v[0]=='plain':need(len(v)==2 and type(v[1])is int and 0<=v[1]<b,'plain cell')
            else:need(v[0]=='head' and len(v)==3 and type(v[1])is int and 0<=v[1]<Q and type(v[2])is int and 0<=v[2]<b,'head cell')
        cell(l,True);cell(c);cell(r,True)
        heads=[(i,v)for i,v in enumerate(origin)if v[0]=='head']
        need(len(heads)<=1,'no multiple heads in a step tile')
        output=c
        if heads:
            position,head=heads[0]
            rows=[v for v in machine['transitions']if v[0]==head[1] and v[1]==head[2]]
            for unused in machine['transitions']:s.check()
            need(len(rows)==1,'large step uses a declared unique transition')
            _,_,n,w,d=rows[0]
            if position==1:
                need(not(d==-1 and l==('wall',))and not(d==1 and r==('wall',)), 'no crossed wall')
                output=('head',n,w)if d==0 else('plain',w)
            elif(position==0 and d==1)or(position==2 and d==-1):output=('head',n,c[1])
        need(edges==(('cell',c),('pair',c,r),('cell',output),('pair',l,c)),
             'independent complete radius-one step witness')
    else:
        need(type(origin)is tuple,'immutable non-step origin')
        def natural(v,n):
            need(type(v)is int and 0<=v<n,'strict bounded non-step index')
            return v
        def phase(pair):
            need(pair in(('PRE','PRE'),('PAD','POST'),('POST','POST')),'fixed phase pair')
        def h(p,f):return ('init_horizontal',p,f)
        if kind=='collect_plain':
            need(len(origin)==2,'plain collector origin');a,f=origin;natural(a,b);natural(f,2)
            wanted=(('cell',('plain',a)),('seen',f),('stop',),('seen',f))
        elif kind=='collect_accept':
            need(len(origin)==2,'accept collector origin');q,a=origin;natural(q,Q);natural(a,b)
            need(q==machine['accepting'],'accept-only collector')
            wanted=(('cell',('head',q,a)),('seen',1),('stop',),('seen',0))
        elif kind in('left_step_frame','right_step_frame'):
            need(len(origin)==1,'step frame origin');v=origin[0]
            need(type(v)is tuple and v and v[0]in('plain','head'),'frame complete cell')
            if v[0]=='plain':need(len(v)==2,'frame plain arity');natural(v[1],b)
            else:need(len(v)==3,'frame head arity');natural(v[1],Q);natural(v[2],b)
            wanted=((('side','left','run'),('pair',('wall',),v),('side','left','run'),('exterior','left'))
                if kind=='left_step_frame' else
                (('side','right','run'),('exterior','right'),('side','right','run'),('pair',v,('wall',))))
        elif kind=='left_accept_frame':
            need(origin==(),'left closing frame origin')
            wanted=(('side','left','run'),('seen',0),('side','left','done'),('exterior','left'))
        elif kind=='right_accept_frame':
            need(origin==(),'right closing frame origin')
            wanted=(('side','right','run'),('exterior','right'),('side','right','done'),('seen',1))
        elif kind=='init_fixed_plain':
            need(len(origin)==4,'fixed plain origin');p,n,a,f=origin;phase((p,n));natural(a,b);natural(f,2)
            wanted=(('init_north','plain',a),h(n,f),('cell',('plain',a)),h(p,f))
        elif kind=='init_fixed_head':
            need(len(origin)==3,'fixed head origin');p,n,a=origin;phase((p,n));natural(a,b)
            wanted=(('init_north','head',machine['initial'],a),h(n,1),('cell',('head',machine['initial'],a)),h(p,0))
        elif kind=='init_free_bit':
            need(len(origin)==3,'bit origin');p,a,f=origin;natural(f,2)
            need(p in('PRE','ACTIVE')and a in(record['wire']['zero'],record['wire']['one']),'free bit phases/symbol')
            wanted=(('init_north','free'),h('ACTIVE',f),('cell',('plain',a)),h(p,f))
        elif kind=='init_free_terminator':
            need(len(origin)==2,'terminator origin');p,f=origin;natural(f,2);need(p in('PRE','ACTIVE'),'terminator phase')
            wanted=(('init_north','free'),h('PAD',f),('cell',('plain',record['wire']['terminator'])),h(p,f))
        elif kind=='init_free_padding':
            need(len(origin)==1,'padding origin');f=origin[0];natural(f,2)
            wanted=(('init_north','free'),h('PAD',f),('cell',('plain',machine['blank'])),h('PAD',f))
        elif kind=='init_left_frame':
            need(origin==(),'left initializer frame origin')
            wanted=(('init_north','frame','left'),h('PRE',0),('side','left','run'),('exterior','left'))
        else:
            need(kind=='init_right_frame'and origin==(),'right initializer frame origin')
            wanted=(('init_north','frame','right'),('exterior','right'),('side','right','run'),h('POST',1))
        need(edges==wanted,'independent complete non-step constructor witness')
    return True


def reference_tile(kind,origin,edges):
    n,e,b,w=edges
    return dict(id=(kind,origin),kind=kind,origin=origin,edges_NESW=edges,
        t=[[[0,0],1]],m=[[[0,-1],'edge',n],[[1,0],'edge',e],
                        [[0,1],'edge',b],[[-1,0],'edge',w]])


def qualify_large_palette(s,record):
    s.active=record['id']
    progress=dict(id=record['id'],stage='LARGE_BUILD',input=record,samples=[],focused=[])
    s.component_rows.append(progress)
    build=palette_call(s,'build_palette_query',[record['machine'],record['wire']])
    desc=build['descriptor']
    description=palette_call(s,'describe',[desc])
    machine=record['machine'];wire=record['wire'];limits=dict(SELECTOR_LIMITS)
    legacy=s.call('selector','describe_unknown_palette_cardinality',
        dict(machine=machine,wire=wire,limits=limits),
        lambda:s.modules['selector'].describe_unknown_palette_cardinality(machine,wire,
            check=s.check,limits=limits))
    total_holder=[]
    def body(query):
        bind_profile_query(s,query)
        total=profile_query(s,'count_query',[desc,(None,None,None,None)])
        need(total['count']==legacy['counts']['total_tiles'] and total['count']>134217728,
             'complete implicit count agrees exact old Source formula; not a literal-byte fit')
        samples=progress['samples'];progress.update(descriptor=desc,build=build,description=description,legacy_cardinality=legacy,total=total,stage='LARGE_WITNESSES')
        for rank in(0,total['count']//2,total['count']-1):
            selected=profile_query(s,'select_query',[desc,(None,None,None,None),rank])
            independent_membership(s,selected['tile'],record)
            samples.append(dict(mask=(None,None,None,None),rank=rank,receipt=selected))
        focused=progress['focused']
        plain=('plain',0);wall=('wall',)
        # Every disjoint step family, including both allowable wall sides.
        triples=[(plain,plain,plain),(('head',0,0),plain,wall),
                 (wall,plain,('head',2,0)),(plain,('head',0,0),wall),
                 (wall,('head',1,0),wall),(wall,('head',2,0),plain)]
        for i,(l,c,r)in enumerate(triples):
            mask=(('cell',c),('pair',c,r),None,('pair',l,c))
            count=profile_query(s,'count_query',[desc,mask]);need(count['count']==1,'one complete step identity')
            selected=profile_query(s,'select_query',[desc,mask,0])
            need(selected['tile']['id']==('step',(l,c,r)),'focused disjoint step identity')
            independent_membership(s,selected['tile'],record)
            focused.append(dict(family='step-family-'+str(i),mask=mask,count_receipt=count,selected=selected))
        def h(p,f):return ('init_horizontal',p,f)
        initial=machine['initial'];accepting=machine['accepting'];a=machine['alphabet_size']-1
        cell=('head',accepting,a)
        recipes=[
            ('collect_plain',(a,0),(('cell',('plain',a)),('seen',0),('stop',),('seen',0))),
            ('collect_accept',(accepting,a),(('cell',cell),('seen',1),('stop',),('seen',0))),
            ('left_step_frame',(cell,),(('side','left','run'),('pair',wall,cell),('side','left','run'),('exterior','left'))),
            ('right_step_frame',(cell,),(('side','right','run'),('exterior','right'),('side','right','run'),('pair',cell,wall))),
            ('left_accept_frame',(),(('side','left','run'),('seen',0),('side','left','done'),('exterior','left'))),
            ('right_accept_frame',(),(('side','right','run'),('exterior','right'),('side','right','done'),('seen',1))),
            ('init_fixed_plain',('POST','POST',a,1),(('init_north','plain',a),h('POST',1),('cell',('plain',a)),h('POST',1))),
            ('init_fixed_head',('PAD','POST',a),(('init_north','head',initial,a),h('POST',1),('cell',('head',initial,a)),h('PAD',0))),
            ('init_free_bit',('ACTIVE',wire['one'],1),(('init_north','free'),h('ACTIVE',1),('cell',('plain',wire['one'])),h('ACTIVE',1))),
            ('init_free_terminator',('PRE',0),(('init_north','free'),h('PAD',0),('cell',('plain',wire['terminator'])),h('PRE',0))),
            ('init_free_padding',(1,),(('init_north','free'),h('PAD',1),('cell',('plain',machine['blank'])),h('PAD',1))),
            ('init_left_frame',(),(('init_north','frame','left'),h('PRE',0),('side','left','run'),('exterior','left'))),
            ('init_right_frame',(),(('init_north','frame','right'),('exterior','right'),('side','right','run'),h('POST',1))),
        ]
        for kind,origin,edges in recipes:
            expected=reference_tile(kind,origin,edges);independent_membership(s,expected,record)
            count=profile_query(s,'count_query',[desc,edges]);need(count['count']==1,'unique full non-step edge mask')
            selected=profile_query(s,'select_query',[desc,edges,0])
            need(tile_bytes(selected['tile'])==tile_bytes(expected),'complete independently specified non-step tile')
            focused.append(dict(family=kind,mask=edges,count_receipt=count,selected=selected))
        total_holder.append(total)
        return None
    profile_call(s,record['id']+'-large-profile',desc,
        dict(record=record,descriptor=desc),body)
    need(len(total_holder)==1,'one complete large total')
    total=total_holder[0];samples=progress['samples'];focused=progress['focused']
    s.oracle_work+=1
    return dict(id=record['id'],complete=True,input=record,descriptor=desc,build=build,
        description=description,legacy_cardinality=legacy,total_count=total,
        global_rank_samples=samples,focused_families=focused,
        fully_materialized=False,full_large_unranking_exhausted=False,
        scope='Exact full Source cardinality plus selected large membership and all family kinds. No full large palette enumeration, physical VM, theorem search or literal-output fit.')


OFFSETS=((0,-1),(1,0),(0,1),(-1,0))


def independent_graph_core(s,core,instance,tiles,buckets):
    points=instance['required_centers'];gens=instance['root_generations']
    if gens is None:gens=[0]*len(points)
    byid={t['id']:t for t in tiles}
    chosen={}
    for i,identity,edges,generation in core['chosen']:
        s.check();identity=immutable(identity)
        need(type(i)is int and 0<=i<len(points)and i not in chosen,'unique occupied required site')
        need(identity in byid and edges==byid[identity]['edges_NESW'] and generation==gens[i]+1,
             'whole chosen literal tile and root-derived tile generation')
        chosen[i]=identity
    expected_marks={}
    for p,ch,v in instance['fixed_background_marks']:
        s.check();expected_marks[(tuple(p),ch)]=[v,1,True]
    for i,identity in chosen.items():
        for side,(dx,dy)in enumerate(OFFSETS):
            s.check();p=(points[i][0]+dx,points[i][1]+dy);key=(p,'edge');v=byid[identity]['edges_NESW'][side]
            if key in expected_marks:
                need(expected_marks[key][0]==v,'independent whole point marking agreement')
                expected_marks[key][1]+=1
            else:expected_marks[key]=[v,1,False]
    rawmarks=[[list(p),ch,v,refs,fixed]for(p,ch),(v,refs,fixed)in sorted(expected_marks.items())]
    need(argument_bytes(core['marks'])==argument_bytes(rawmarks),'exact full mark values/refcounts/fixed ownership')
    need(len(core['points'])==len(points)and len(core['domains'])==len(points),'entire active finite target')
    exclusions={}
    for row in core['exclusions']:
        s.check();i=row['point'];identity=immutable(row['id'])
        need(type(i)is int and 0<=i<len(points)and identity in byid,'literal excluded candidate')
        need(identity not in exclusions.setdefault(i,[]),'distinct per-point exclusions')
        exclusions[i].append(identity)
        for p,parent_id in row['parent_support']:
            need(chosen.get(p)==immutable(parent_id),'exclusion only under its parent assumptions')
    degree=[];full_domains=[]
    for i,point in enumerate(points):
        s.check();need(core['points'][i]==[i,point,1 if i in chosen else 0,gens[i]],'exact point totals and generations')
        domain=core['domains'][i]
        if i in chosen:
            need(domain is None,'occupied site is absent from frontier');full_domains.append(None);continue
        mask=tuple(expected_marks.get(((point[0]+dx,point[1]+dy),'edge'),[None])[0]for dx,dy in OFFSETS)
        candidates=buckets.get(mask,[])
        physical={t['id']for t in candidates}
        matching=[identity for identity in exclusions.get(i,[])if identity in physical]
        available=[t['id']for t in candidates if t['id']not in matching]
        need(type(domain)is dict and domain['point']==i and domain['mask']==mask and
             type(domain['physical_count'])is int and domain['physical_count']==len(candidates)and
             immutable(domain['matching_exclusions'])==tuple(matching)and
             type(domain['degree'])is int and domain['degree']==len(available),
             'implicit incremental domain equals the complete independently indexed literal inventory')
        full_domains.append(available);degree.append((i,len(available)))
    zeros=[(i,n)for i,n in degree if n==0];ones=[(i,n)for i,n in degree if n==1]
    if zeros:decision=['DEAD',zeros[0][0],0]
    elif ones:decision=['FORCED',ones[0][0],1]
    elif not degree:decision=['COMPLETE',None,0]
    else:
        i,n=min(degree,key=lambda v:(gens[v[0]],v[1],v[0]));decision=['BRANCH',i,n]
    return decision,full_domains


def independent_all_solutions(s,instance,tiles,buckets):
    """Independent fixed-site-order literal point enumeration, not GCTS scheduling."""
    marks={(tuple(p),ch):v for p,ch,v in instance['fixed_background_marks']}
    points=instance['required_centers'];answers=[];chosen=[]
    def visit(i):
        s.check()
        if i==len(points):
            answers.append(tuple(chosen));need(len(answers)<=10000,'declared finite oracle answer cap');return
        p=points[i]
        mask=tuple(marks.get(((p[0]+dx,p[1]+dy),'edge'))for dx,dy in OFFSETS)
        for tile in buckets.get(mask,[]):
            s.check();trail=[]
            for side,(dx,dy)in enumerate(OFFSETS):
                key=((p[0]+dx,p[1]+dy),'edge')
                if key not in marks:marks[key]=tile['edges_NESW'][side];trail.append(key)
            chosen.append(tile['id']);visit(i+1);chosen.pop()
            for key in trail:del marks[key]
    visit(0);s.oracle_work+=1
    return answers


def graph_instance(s,case):
    if case['kind']=='literal':
        instance=clone(case['instance'])
        for row in instance['fixed_background_marks']:row[2]=immutable(row[2])
        return instance,None
    need(case['kind']=='unknown_board','declared graph instance construction')
    record=case['palette_record'];prefix=[immutable(x)for x in case['fixed_prefix']]
    suffix=[immutable(x)for x in case['fixed_suffix']];limits=dict(SELECTOR_LIMITS)
    args=[record['machine'],record['wire'],prefix,case['capacity'],suffix,case['steps']]
    old=s.call('selector','compile_unknown_problem',dict(args=args,limits=limits),
        lambda:s.modules['selector'].compile_unknown_problem(*args,check=s.check,limits=limits))
    colors=old['palette']['color_constructors']
    instance=dict(schema='finite-implicit-wang-point-instance-v1',
        required_centers=old['required_centers'],admissible_origins=old['admissible_origins'],
        fixed_background_marks=[[p,ch,colors[v]]for p,ch,v in old['fixed_background_marks']],root_generations=None)
    return instance,old


def qualify_graph(s,case):
    s.active=case['id'];instance,old=graph_instance(s,case)
    progress=dict(id=case['id'],stage='REFERENCE',input=case,instance=instance,legacy_problem=old,observations=[])
    s.component_rows.append(progress)
    palette,tiles,desc,buckets=s.literal_models[case['palette_id']]
    reference=independent_all_solutions(s,instance,tiles,buckets)
    observations=progress['observations'];pending_restore=[];root_core=None;domain_checks=0
    progress.update(independent_solution_ids=reference,stage='GRAPH_SEARCH')
    class Facade:
        def count_query(self,descriptor,mask,*,check,limits):
            return profile_query(s,'count_query',[descriptor,mask],limits,check)
        def select_query(self,descriptor,mask,index,*,check,limits):
            return profile_query(s,'select_query',[descriptor,mask,index],limits,check)
    def observe(snapshot):
        nonlocal root_core,domain_checks
        before=argument_bytes(snapshot);s.check()
        decision,domains=independent_graph_core(s,snapshot,instance,tiles,buckets)
        need(snapshot['scheduler']==decision,'global DEAD then FORCED then earliest generation')
        deps={}
        for i,p in enumerate(instance['required_centers']):
            for side,(dx,dy)in enumerate(OFFSETS):deps.setdefault((p[0]+dx,p[1]+dy),[]).append([i,side])
        need(snapshot['dependencies']==[[list(p),v]for p,v in sorted(deps.items())],
             'complete forward and reverse midpoint dependency incidence')
        for frame in snapshot['branch_stack']:
            independent_graph_core(s,frame['parent'],instance,tiles,buckets)
        core={k:snapshot[k]for k in('points','chosen','marks','domains','exclusions')}
        if snapshot['reason']=='BEFORE_ROLLBACK':
            need(snapshot['rollback_parent']is not None and not pending_restore,'one exact pending rollback checkpoint')
            independent_graph_core(s,snapshot['rollback_parent'],instance,tiles,buckets)
            pending_restore.append(argument_bytes(snapshot['rollback_parent']))
        if snapshot['reason']=='AFTER_ROLLBACK':
            need(len(pending_restore)==1 and argument_bytes(core)==pending_restore.pop() and
                 argument_bytes(core)==argument_bytes(snapshot['rollback_parent']),
                 'complete restored parent exactly equals its retained rollback checkpoint')
        if snapshot['reason']=='INITIAL':root_core=argument_bytes(core)
        if snapshot['reason']=='ROOT_RESTORED':need(argument_bytes(core)==root_core,'exact full initial state restored')
        domain_checks+=sum(d is not None for d in domains)
        observations.append(dict(snapshot=snapshot,independent_domains=domains,complete=True))
        need(argument_bytes(snapshot)==before,'read-only independent observer')
    data=dict(instance=instance,descriptor=desc,limits=GRAPH_LIMITS,oracle_limits=IMPLICIT_LIMITS,mode=case['mode'])
    result_holder=[]
    def graph_body(query):
        bind_profile_query(s,query)
        result_holder.append(s.call('graph','search',data,lambda:s.modules['graph'].search(instance,Facade(),desc,
            check=s.check,limits=dict(GRAPH_LIMITS),oracle_limits=dict(IMPLICIT_LIMITS),observe=observe,mode=case['mode'])))
        return None
    profile_call(s,case['id']+'-graph-profile',desc,data,graph_body)
    need(len(result_holder)==1,'one complete graph consumer result')
    result=result_holder[0]
    progress.update(result=result,stage='GRAPH_RESULT')
    need(result['status']!='UNKNOWN_SEARCH_LIMIT'and result['root_restored']is True and
         result['final_observation_completed']is True,'whole graph case complete with observed exact restoration')
    need(not pending_restore,'all begun rollback comparisons completed')
    actual=[]
    for solution in result['solutions']:
        placements=solution['placements'];need(len(placements)==len(instance['required_centers']),'full finite target certificate')
        ids=[]
        for i,placement in enumerate(placements):
            need(placement['point']==i and placement['origin']==instance['required_centers'][i], 'ordered complete target')
            tile=placement['tile'];tile_key(tile)
            need(placement['id']==tile['id']and any(tile_bytes(tile)==tile_bytes(t)for t in tiles),
                 'every certificate tile is a complete literal inventory tile')
            ids.append(tile['id'])
        actual.append(tuple(ids))
    need(len(set(actual))==len(actual),'no duplicate whole tilings')
    if case['mode']=='all':
        need(result['exhaustive']is True and set(actual)==set(reference),'complete solution population equals independent point enumeration')
    elif reference:
        need(result['status']=='SOLUTION_FOUND'and len(actual)==1 and actual[0]in reference,'first solution independently valid')
    else:need(result['status']=='EXHAUSTED_NO_SOLUTION'and not actual and result['exhaustive']is True,'finite exhaustive negative independently agrees')
    decisions=[o['snapshot']['scheduler']for o in observations if o['snapshot']['reason']=='BEFORE_DECISION']
    if case['id']=='distant-DEAD-before-FORCED':need(decisions[0][0]=='DEAD'and not result['solutions'],'distant dead checked before sole placement')
    if case['id']=='distant-FORCED-before-BRANCH':need(decisions[0]==['FORCED',1,1],'distant forced checked before local choices')
    if case['id']=='earliest-before-lower-degree-TEST-VARIANT':need(decisions[0][0]=='BRANCH'and decisions[0][1]==0,'earlier root outranks lower later degree')
    if case['id']=='connected-failed-children-first':need(sum(e['kind']=='FAILED_CHILD_EXCLUDED'for e in result['journal'])>=3,'rank-shifting failed-child population actually reached')
    s.oracle_work+=1
    return dict(id=case['id'],complete=True,input=case,instance=instance,legacy_problem=old,
        result=result,observations=observations,independent_solution_ids=reference,
        independent_solution_count=len(reference),actual_solution_count=len(actual),domain_checks=domain_checks,
        scope='Complete finite singleton-center/four-midpoint point model; no physical FOL interpreter, remote extra tile marks, shared/fractional t support, RL or performance advantage.')


"""Prospective controlled refusals/faults, called only within the once actual."""

def diagnostic(s,d,inputs):
    op=d['operation'];role=d['role'];expected=d['expected']
    bound=dict(IMPLICIT_LIMITS if role=='implicit'else GRAPH_LIMITS)
    calls=0;foreign=None;callback_trace=[]
    def callback():
        nonlocal calls
        calls+=1;s.check()
        if calls==d['expected_callback_count']:
            frame=sys._getframe(1)
            while frame is not None and len(callback_trace)<32:
                if frame.f_code.co_filename==s.plan['sources'][role]['path']:
                    callback_trace.append(dict(function=frame.f_code.co_name,line=frame.f_lineno))
                frame=frame.f_back
            raise foreign
    desc=immutable(inputs['minimal_descriptor']);mask=(None,None,None,None)
    kwargs={};extra=None
    if role=='implicit':
        name='count_query';args=[desc,mask]
        if op.startswith('build_')or op=='implicit_foreign_wire':
            name='build_palette_query';machine=clone(inputs['minimal_machine']);wire=clone(inputs['minimal_wire']);args=[machine,wire]
            if op=='build_bool_symbol':machine['alphabet_size']=True
            elif op=='build_duplicate_transition':machine['transitions']=[[0,0,1,0,0],[0,0,1,0,0]]
            elif op=='build_accept_outgoing':machine['transitions']=[[1,0,0,0,0]]
            elif op=='build_wire_blank':wire['one']=machine['blank']
            elif op=='build_initial_accept':machine['initial']=machine['accepting']
        elif op=='count_bool_mask':args[1]=(('cell',('plain',True)),None,None,None)
        elif op=='count_list_mask':args[1]=[None,None,None,None]
        elif op=='count_nested_none':args[1]=(('cell',None),None,None,None)
        elif op.startswith('select_')or op=='implicit_foreign_fill':
            name='select_query';args=[desc,mask,0]
            if op=='select_bool_index':args[2]=True
            elif op=='select_negative_index':args[2]=-1
            elif op=='select_past_end':
                extra=palette_call(s,'count_query',[desc,mask]);args[2]=extra['count']
        elif op=='count_invalid_descriptor':args[0]=('wrong',desc[1],desc[2])
        elif op=='implicit_work_limit':bound['work']=1
        elif op=='implicit_integer_limit':bound['integer_bits']=1
        elif op=='implicit_data_limit':bound['data_items']=1
        if expected=='FOREIGN':
            if op=='implicit_foreign_same_invalid':foreign=s.modules['implicit'].Invalid('foreign public invalid')
            elif op=='implicit_foreign_same_limit':foreign=s.modules['implicit'].Limit('foreign public limit',0)
            else:foreign=StopIteration('declared exact delegated StopIteration')
        action=lambda:palette_call(s,name,args,bound,callback if expected=='FOREIGN'else None)
    else:
        instance=clone(inputs['graph_cases'][0]['instance']);mode='first'
        for row in instance['fixed_background_marks']:row[2]=immutable(row[2])
        if op=='graph_empty_target':instance['required_centers']=[];instance['admissible_origins']=[]
        elif op=='graph_odd_center':instance['required_centers'][0][0]=1;instance['admissible_origins']=clone(instance['required_centers'])
        elif op=='graph_duplicate_center':instance['required_centers'].append(instance['required_centers'][0][:]);instance['admissible_origins']=clone(instance['required_centers'])
        elif op=='graph_origin_mismatch':instance['admissible_origins']=[]
        elif op=='graph_duplicate_pin':instance['fixed_background_marks'].append(instance['fixed_background_marks'][0])
        elif op=='graph_none_pin':instance['fixed_background_marks'][0][2]=None
        elif op=='graph_bool_generation':instance['root_generations']=[False,0]
        elif op=='graph_bad_mode':mode='not_a_mode'
        elif op=='graph_work_unknown':bound['work']=1
        if expected=='FOREIGN':
            if op=='graph_foreign_same_invalid':foreign=s.modules['graph'].DeclarationError('foreign public invalid')
            elif op=='graph_foreign_same_limit':foreign=s.modules['graph'].SearchLimit(object(),'foreign own-class owner mismatch')
            else:foreign=StopIteration('declared exact graph StopIteration')
        class Facade:
            def count_query(self,descriptor,query,*,check,limits):return profile_query(s,'count_query',[descriptor,query],limits,check)
            def select_query(self,descriptor,query,index,*,check,limits):return profile_query(s,'select_query',[descriptor,query,index],limits,check)
        data=dict(instance=instance,descriptor=desc,limits=bound,oracle_limits=IMPLICIT_LIMITS,mode=mode)
        result_holder=[]
        def graph_body(query):
            bind_profile_query(s,query)
            result_holder.append(s.call('graph','search',data,lambda:s.modules['graph'].search(instance,Facade(),desc,
                check=callback if expected=='FOREIGN'else s.check,limits=bound,oracle_limits=dict(IMPLICIT_LIMITS),mode=mode)))
            return None
        def graph_action():
            profile_call(s,d['id']+'-graph-diagnostic-profile',desc,data,graph_body)
            need(len(result_holder)==1,'one complete original graph diagnostic result')
            return result_holder[0]
        action=graph_action
    try:result=action()
    except BaseException as error:
        s.fault_gate()
        if expected=='FOREIGN':
            need(error is foreign and calls==d['expected_callback_count'],'exact delegated foreign object and declared site')
            if d['expected_callback_function']is not None:
                need(any(v['function']==d['expected_callback_function']for v in callback_trace),
                     'foreign reached the prospectively named subject function')
            if role=='implicit':
                for pred in('is_own_invalid','is_own_limit'):
                    need(s.call(role,pred,[],lambda pred=pred:getattr(s.modules[role],pred)(error))is False,'foreign public class not privately owned')
        elif role=='implicit':
            pred='is_own_invalid'if expected=='INVALID'else'is_own_limit'
            need(s.call(role,pred,[],lambda:getattr(s.modules[role],pred)(error))is True,'exact private owned refusal')
        else:need(expected=='INVALID'and type(error)is s.modules['graph'].DeclarationError,'exact graph declaration refusal')
        return dict(id=d['id'],operation=op,role=role,expected=expected,status='PASSED',callback_count=calls,
            callback_trace=callback_trace,exact_foreign_identity=(error is foreign)if expected=='FOREIGN'else None,error=information(error),
            implicit_prefix=getattr(error,'implicit_palette_prefix',None),graph_prefix=getattr(error,'implicit_search_prefix',None),setup_receipt=extra)
    s.fault_gate()
    need(expected=='UNKNOWN'and role=='graph'and result['status']=='UNKNOWN_SEARCH_LIMIT'and
         result['exhaustive']is False and result['unfinished_prefix']['final_observation_completed']is False,
         'only declared own search quota becomes UNKNOWN, never zero/UNSAT')
    return dict(id=d['id'],operation=op,role=role,expected=expected,status='PASSED',callback_count=calls,
        exact_foreign_identity=None,result=result,setup_receipt=extra)


def run_new_diagnostics(s,bank):
    # Root must replace this explicit refusal with the independently authored
    # diagnostics fragment before any actual can be granted.
    raise PolicyFailure('new batch diagnostics fragment has not been integrated')


def qualify(s,inputs,batch_inputs):
    s.stage='FULL_SMALL_PALETTES';small=[]
    for record in inputs['small_palettes']:
        row=qualify_small_palette(s,record);small.append(row);s.rows.append(row)
    s.stage='LARGE_IMPLICIT_PALETTE'
    large=qualify_large_palette(s,inputs['large_palette']);s.rows.append(large)
    s.stage='COMPLETE_POINT_GRAPH';graphs=[]
    for case in inputs['graph_cases']:
        row=qualify_graph(s,case);graphs.append(row);s.rows.append(row)
    s.stage='DIAGNOSTICS'
    for d in inputs['diagnostics']:
        s.active=d['id'];s.diagnostics.append(diagnostic(s,d,inputs))
    s.stage='BATCH_DIAGNOSTICS'
    run_new_diagnostics(s,batch_inputs)
    final_profile_custody(s)
    return dict(schema='implicit-palette-graph-calibration-packet-v1',status='COMPLETE_COMPONENT_CALIBRATION_CANDIDATE',
        inputs=inputs,small_palettes=small,large_palette=large,graphs=graphs,diagnostics=s.diagnostics,call_receipts=s.retained,
        call_started=s.started,call_completed=s.completed,call_raised=s.raised,root_callbacks=s.root_calls,
        batch_inputs=batch_inputs,profile_rows=s.profile_rows,profile_metrics=profile_metrics(s),
        profile_accounting=s.profile_accounting,
        batch_diagnostics=s.batch_diagnostics,batch_diagnostic_progress=s.batch_diagnostic_progress,
        full_VM_implemented=False,full_FOL_palette_qualified=False,proof_discovery=False,
        full_pipeline_qualified=False,mathematical_authority=False,
        scope='New full implicit representation and finite point-domain comparison. Full small nonempty masks plus declared zero cases; selected large membership; entire finite graph solutions and every observed domain. No literal expansion fit, old negative rescue, physical FOL VM, theorem/RL discovery or speed advantage.')


def main(plan_path):
    plan_raw=Path(plan_path).read_bytes();need(len(plan_raw)<=16777216,'bounded whole plan')
    plan=json.loads(plan_raw);plan_pin=descriptor(plan_path,plan_raw)
    need(type(plan)is dict and set(plan)=={'schema','invocation_id','actual_directory','python','sources','inputs','limits','declaration','runtime_closure','authorization'}and
        plan['schema']=='ROOT-wang-encoding-qualification-plan-v1','exact whole once-plan')
    need(plan['limits']==OUTER_LIMITS and set(plan['sources'])==set(SOURCE_ROLES),'original caps and six exact Source roles')
    actual=Path(plan['actual_directory']);need(actual.is_absolute()and actual==actual.resolve()and actual.is_dir(),'owned fresh actual')
    consumed=json.loads((actual/'CONSUMED.json').read_bytes())
    need(consumed['plan']==plan_pin and consumed['invocation_id']==plan['invocation_id']and
        consumed['schema']=='wang-encoding-qualification-consumed-v1'and
        type(consumed['maximum_worker_launches'])is int and consumed['maximum_worker_launches']==1 and
        consumed['consumed_before_Popen']is True and type(consumed['began_ns'])is int and
        consumed['work_deadline_ns']==consumed['began_ns']+180000000000 and
        consumed['overall_deadline_ns']==consumed['began_ns']+210000000000,'same absolute Source-entry epoch')
    s=Session(plan,plan_pin,consumed,actual)
    try:
        s.check();need(descriptor(__file__,Path(__file__).read_bytes())==plan['sources']['worker'],'whole worker pin')
        for pin in plan['sources'].values():checked(pin)
        checked(plan['python'],67108864)
        declaration=json.loads(checked(plan['declaration']));closure=json.loads(checked(plan['runtime_closure']))
        need(declaration['schema']=='ROOT-wang-encoding-qualification-declaration-v1'and
            declaration['limits']==OUTER_LIMITS and declaration['component_limits']==COMPONENT_LIMITS and
            declaration['checkpoint_limit']==CHECKPOINT_LIMIT and declaration['experiment_kind']=='COMPLETE_IMPLICIT_BATCH_AND_POINT_GRAPH_CALIBRATION' and declaration['profile_limits']==PROFILE_LIMITS and declaration['profile_granularity']==PROFILE_GRANULARITY and declaration['profile_query_chunk']==PROFILE_QUERY_CHUNK,'whole new component declaration')
        need(closure['schema']=='ROOT-wang-encoding-runtime-closure-v1'and closure['python']==plan['python']and
            closure['sources']==plan['sources']and closure['declaration']==plan['declaration'],'exact full runtime closure')
        for pin in closure['stdlib_files']:checked(pin)
        need(plan['inputs']==declaration['inputs']and len(plan['inputs'])==2,'two whole declared calibration banks')
        inputs=json.loads(checked(plan['inputs'][0]['pin'],134217728))
        batch_inputs=json.loads(checked(plan['inputs'][1]['pin'],134217728))
        need(inputs['schema']=='implicit-palette-inputs-v1','exact original input schema')
        need(batch_inputs['schema']=='implicit-batch-summary-diagnostics-v1','exact new diagnostic schema')
        subject={k:v for k,v in plan.items()if k!='authorization'};auth=json.loads(checked(plan['authorization']))
        need(auth['actual_execution_authorized']is True and auth['author_identity']=='/root'and
            type(auth['maximum_actual_invocations'])is int and auth['maximum_actual_invocations']==1 and
            auth['subject_sha256']==hashlib.sha256(canonical(subject)).hexdigest(),'fresh Root exact-subject grant')
        s.write_json('WORKER_CONSUMED.json',dict(plan=plan_pin,pid=os.getpid(),ppid=os.getppid(),
            worker_entry_ns=ENTRY_NS,maximum_invocations=1),1048576)
        def audit(event,args):
            if event in FORBIDDEN_EVENTS:
                s.denied.append(event);s.policy(lambda:need(False,'forbidden process/network/dlopen'))
        sys.addaudithook(audit)
        for role in('selector','implicit','graph'):s.load(role)
        s.batch_original_inputs=inputs;s.batch_original_inputs_preimage=argument_bytes(inputs);packet=qualify(s,inputs,batch_inputs);s.active=None;s.guard();s.stage='FULL_PACKET_WRITE'
        output=s.write_json('canonical-implicit-palette-calibration.json',packet,134217728-RESERVE_BYTES)
        s.output_pins.append(output)
        expanded_packet_bytes=output['bytes']+s.expanded_subtree_delta
        need(output['bytes']<=expanded_packet_bytes<=134217728,
             'conservative full profile return reconstruction within original expanded128MiB')
        counts=dict(compiler_calls=s.started.get('implicit.build_palette_query',0)+s.calls('selector'),
            search_calls=s.started.get('graph.search',0),verifier_calls=s.oracle_work,oracle_calls=s.oracle_work)
        q=dict(schema='implicit-palette-graph-component-candidate-v1',status='COMPLETE_COMPONENT_CALIBRATION_CANDIDATE',
            outputs=s.output_pins,case_ids=[r['id']for r in s.rows],
            rows=[dict(id=r['id'],complete=r['complete'])for r in s.rows],
            diagnostics=s.diagnostics,diagnostic_ids=[r['id']for r in s.diagnostics],
            profile_metrics=profile_metrics(s),
            batch_diagnostics=[dict(id=g['id'],subject=g['subject'],recipe=g['recipe'],
                status=g['status'],complete=g['complete'],variants=[dict(id=v['id'],
                    status=v['status'],complete=v['complete'],expected=v['expected'])for v in g['variants']])
                for g in s.batch_diagnostics],
            batch_diagnostic_ids=[r['id']for r in s.batch_diagnostics],
            profile_granularity=PROFILE_GRANULARITY,profile_query_chunk=PROFILE_QUERY_CHUNK,
            small_palettes=len(packet['small_palettes']),
            small_mask_queries=sum(len(r['queries'])for r in packet['small_palettes']),
            selected_small_witnesses=sum(r['selected_witnesses']for r in packet['small_palettes']),
            large_logical_tiles=packet['large_palette']['total_count']['count'],
            graph_cases=len(packet['graphs']),graph_domain_checks=sum(r['domain_checks']for r in packet['graphs']),
            rollback_comparisons=sum(o['snapshot']['reason']=='AFTER_ROLLBACK'for r in packet['graphs']for o in r['observations']),
            palette_query_calls=s.calls('implicit'),root_check_calls=s.root_calls,
            root_check_calls_scope='Cutoff before result/header; every later callback shares400m ceiling, not CPU work.',
            full_pipeline_qualified=False,mathematical_proof_accepted=False,fixed_FOL_palette_qualified=False,
            gcts_rl_advantage_established=False,learned_pair_markings=False,trained_RL=False,
            complete_physical_VM=False,proof_discovery=False,**counts)
        zeros=dict(Native_calls=0,Model_calls=0,inverse_calls=0,Reader_calls=0,FOL_kernel_calls=0,opaque_program_decodes=0)
        payload=dict(schema='wang-encoding-qualification-result-v1',invocation_id=plan['invocation_id'],plan=plan_pin,
            declaration=plan['declaration'],runtime_closure=plan['runtime_closure'],qualification=q,outputs=s.output_pins,
            denied_events=s.denied,canonical_logical_bytes=output['bytes'],expanded_canonical_packet_bytes=expanded_packet_bytes,
            profile_return_reconstruction_delta_bytes=s.expanded_subtree_delta,
            expanded_scope='Conservative full-return reconstruction bound; q is an admission summary, not a duplicated full-row representation.',
            full_pipeline_qualified=False,scientific_acceptance=False,mathematical_proof_accepted=False,**counts,**zeros)
        s.stage='RESULT_WRITE';result=s.write_json('result.json',payload,134217728-RESERVE_BYTES-output['bytes'])
        s.guard()
        for pin in closure['stdlib_files']:checked(pin)
        for input_record in plan['inputs']:checked(input_record['pin'],134217728)
        final_profile_custody(s);s.check()
        logical=output['bytes']+result['bytes']
        expanded_logical=expanded_packet_bytes+result['bytes']
        need(0<logical<=expanded_logical<=134217728,'whole stored and conservatively expanded packet plus result within original128MiB')
        header=dict(schema='wang-encoding-qualification-worker-receipt-v1',version=VERSION,
            invocation_id=plan['invocation_id'],plan=plan_pin,began_ns=s.began,work_deadline_ns=s.work_deadline,
            overall_deadline_ns=s.overall_deadline,pid=os.getpid(),ppid=os.getppid(),worker_entry_ns=ENTRY_NS,
            result=result,outputs=s.output_pins,logical_result_bytes=logical,expanded_logical_result_bytes=expanded_logical,
            outer_metadata_reservation=RESERVE_BYTES,finite_encoding_candidate=True,
            full_pipeline_qualified=False,scientific_acceptance=False,mathematical_proof_accepted=False,
            call_started=s.started,call_completed=s.completed,call_raised=s.raised,
            root_check_calls=s.root_calls,positive_worker_completed_ns=NOW(),**zeros)
        s.stage='HEADER_WRITE';s.write_json('worker-receipt.json',header,4194304)
        need(sum(p.stat().st_size for p in actual.iterdir()if p.is_file())+RESERVE_BYTES<=134217728,'all actual files plus original outer9MiB reserve')
        s.check();return 0
    except BaseException as error:
        primary=s.first_fault if s.first_fault is not None else error
        early_summary = None
        try:
            early_summary = _write_failure_summary(s, _failure_summary_record(s, primary))
        except BaseException:
            pass  # Metadata-only attempt cannot change the selected primary fault.
        failure=dict(schema='implicit-palette-graph-worker-failure-v1',status='FAILED_OR_UNFINISHED',
            plan=plan_pin,invocation_id=plan['invocation_id'],stage=s.stage,active_row=s.active,
            completed_case_ids=[r['id']for r in s.rows],diagnostic_prefix=s.diagnostics,
            batch_diagnostic_progress=s.batch_diagnostic_progress,
            completed_component_ids=[r['id']for r in s.component_rows],
            call_started=s.started,call_completed=s.completed,call_raised=s.raised,root_check_calls=s.root_calls,
            first_available_fault=information(primary),outputs=s.output_pins,
            no_failed_prefix_admission=True,full_pipeline_qualified=False,mathematical_proof_accepted=False)
        failure.update(subject_prefix=getattr(primary,'implicit_palette_prefix',None),graph_prefix=getattr(primary,'implicit_search_prefix',None))
        failure['early_failure_summary'] = early_summary
        try:
            prior=sum(p.stat().st_size for p in actual.iterdir()if p.is_file())
            prefix=s.write_json('failed-prefix.json',dict(components=s.component_rows,call_receipts=s.retained,
                completed_cases=s.rows,diagnostics=s.diagnostics,
                profile_rows=s.profile_rows,batch_diagnostics=s.batch_diagnostics,
                profile_accounting=s.profile_accounting,
                batch_diagnostic_progress=s.batch_diagnostic_progress,no_admission=True),
                134217728-RESERVE_BYTES-prior,closure=True)
            failure['full_available_prefix']=prefix
        except BaseException as retention_error:failure['prefix_retention_error']=information(retention_error)
        try:s.write_json('worker-failure.json',failure,1048576,closure=True)
        except BaseException:pass
        return 2


if __name__=='__main__':
    need(len(sys.argv)==2,'one exact once-plan path')
    raise SystemExit(main(sys.argv[1]))

