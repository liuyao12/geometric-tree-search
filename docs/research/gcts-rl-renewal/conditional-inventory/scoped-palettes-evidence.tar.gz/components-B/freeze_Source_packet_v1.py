"""Passive raw/AST/unused-code metadata only; never imports authored subjects."""
from pathlib import Path
import ast
import hashlib
import json
import sys

O=Path(__file__).resolve().parent
D=O.parent
def pin(path):
    raw=path.read_bytes()
    return dict(path=str(path.resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def write(name,value):
    path=O/name
    assert not path.exists()
    path.write_text(json.dumps(value,indent=2,ensure_ascii=True)+'\n')

component=O/'implicit_wang_batch_v2.py'
worker=O/'qualify_implicit_batch_worker_v8.py'
old_component=D/'recovered/future-B/implicit_wang_batch_v1.py'
old_worker=D/'recovered/future-L/qualify_implicit_worker_v2_summary_first.py'
master=D/'publisher/docs/basic-tiling-algorithm.md'
bank=D/'recovered/ROOT/implicit-inputs-v1.json'
python=Path(sys.executable)
old_text=old_component.read_text()
new_text=component.read_text()
old_prefix=old_text.split('BATCH_LIMIT_KEYS =',1)[0]
new_prefix=new_text.split('BATCH_LIMIT_KEYS =',1)[0]
normalized=new_prefix.replace("VERSION = 'implicit-wang-batch-v2-receipt-lifetime'", "VERSION = 'implicit-wang-batch-v1'")
assert normalized==old_prefix
parsed=[]
for path in(component,worker):
    tree=ast.parse(path.read_bytes(),filename=str(path))
    unused=compile(tree,str(path),'exec')
    # Only the metadata code object exists: never executed or imported.
    del unused
    parsed.append(dict(**pin(path),ast_sha256=hashlib.sha256(ast.dump(tree,
        annotate_fields=True,include_attributes=False).encode()).hexdigest()))

original=json.loads(bank.read_bytes())
assert len(original['small_palettes'])==4
assert len(original['large_palette']['machine']['transitions'])==7936
assert len(original['graph_cases'])==10
assert len(original['diagnostics'])==33
assert pin(bank)['sha256']=='10fe60d005a2f586a76bf69ae30317b8dae538ba9f126714b9f71ffa474a89b4'
assert pin(master)['sha256']=='ca6ee206287bf18b69f88a35d30968312499567755f347a819af4cf49743e7d4'

api=json.loads((O/'API-v1.json').read_bytes())
api.update(status='SOURCE_ONLY_FROZEN_UNEXECUTED_NOT_GRANTED',worker_source=worker.name)
api['worker_profile']['consumer_results']='All normal wrapper bodies return None. Original caller-owned result holders retain complete small query replies, large total/samples/focused families, and each graph result. The original full case outputs remain unchanged; body_result is not duplicated inside profile lifetime.'
api['ordinary_projection']={
    'canonical':'One ordinary lifetime per normal scope contains all requests, full old-schema receipts, full typed preimages, counters/stages/custody/scalars. profile_return_metadata contains all other return fields. Four explicit field bindings reconstruct the complete component return from that lifetime without hash-only attribution.',
    'bindings':{'receipts':['receipts','list'],'attempted_requests':['requests','tuple'],
        'exact_receipt_preimages':['expected_receipts','tuple'],'body_result':['body_result','identity']},
    'owners':'The actual returned dictionary, raw lifetime, callbacks/functions, Work object, descriptor, original inputs, every request/receipt/preimage and original caller-owned results remain alive until final Root custody. Ordinary projection omits executable objects; it does not claim to reconstruct callable state.',
    'expanded':'Inside the sole actual only, compute canonical full-row bytes minus compact-row bytes before adding the charge field, and charge max(0,difference) through expanded_subtree_delta. Adding the nonnegative charge field makes stored+charged delta a conservative full-return reconstruction bound, not an exact compressed byte count. Original128MiB expanded ceiling remains unchanged.',
    'q':'q/result is an admission summary: twelve metrics and complete ordered group/variant status/expected summaries. All full profile rows, failed/successful accounting rows, batch runs/receipts/prefixes and progress remain in the canonical packet. No q summary is represented as a reconstruction reference or another full certificate.'}
api['drafts']={'qualify_implicit_batch_worker_v3.py':'Authoring SyntaxError in __self__ token; never imported or executed; raw Source retained.',
    'qualify_implicit_batch_worker_v4.py':'Unused compile passed; pre-own-worker-seal draft, never imported/executed.',
    'qualify_implicit_batch_worker_v5.py':'Unused compile passed; stale new-bank schema string and redundant projection, superseded without actual.',
    'qualify_implicit_batch_worker_v6.py':'Unused compile passed; bank schema corrected, redundant projection still present, superseded without actual.'}
api['drafts']['qualify_implicit_batch_worker_v7.py']='Unused compile passed; compact projection and expanded accounting complete, explicit raw standalone/error owner retention added by v8 before any actual.'
write('API-v2.json',api)
write('author-static-audit-v2.json',dict(schema='recovered-implicit-batch-author-static-v2',
    status='SOURCE_ONLY_UNUSED_COMPILE_AND_LITERAL_INPUT_AUDIT',python=pin(python),
    python_version=sys.version,AST_policy='ast.dump(annotate_fields=True,include_attributes=False), UTF-8',
    files=parsed,legacy_prefix_exact_except_VERSION=True,current_master=pin(master),
    complete_original_bank=pin(bank),ordinary_bank_counts=dict(small=4,large_rows=7936,graph=10,old_diagnostics=33),
    subject_imports=0,subject_calls=0,actual_launches=0,performance_tests=0,
    unused_code_objects_executed=0,semantic_helpers_called=0))

all_files=[]
for path in sorted(O.iterdir()):
    if path.is_file() and path.name not in('handoff-v2.json',):all_files.append(pin(path))
write('handoff-v2.json',dict(schema='recovered-implicit-batch-integration-handoff-v2',
    author='/root/recovered_batch_integration',status='SOURCE_ONLY_FROZEN_UNEXECUTED_NOT_GRANTED',
    current_component=pin(component),current_worker=pin(worker),original_component_negative=pin(old_component),
    original_worker_preimage=pin(old_worker),current_master=pin(master),original_full_input_bank=pin(bank),
    python=pin(python),python_version=sys.version,API=pin(O/'API-v2.json'),
    manual_equivalence=pin(O/'manual-equivalence-and-conformance-v1.json'),
    author_static=pin(O/'author-static-audit-v2.json'),files=all_files,
    integration_refusal='Root must replace exact run_new_diagnostics refusing stub with independently frozen fragment, then bind and prospectively review exact full Source/input/runner/closure subject. This source handoff gives no authority to import, call, probe, run fixtures, size semantically or launch an actual.',
    unchanged_caps=dict(root_callbacks=400000000,positive_seconds=180,custody_seconds=210,
        worker_HWM_bytes=1073741824,stored_and_expanded_bytes=134217728,
        physical_including_reserve_bytes=134217728,reserve_bytes=9437184),
    claims=dict(runtime_qualified=False,actual_authorized=False,full_pipeline_qualified=False,
        mathematical_authority=False,proof_discovery=False,performance_advantage=False)))
print(json.dumps(pin(O/'handoff-v2.json'),indent=2))
