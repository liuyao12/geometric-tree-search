def qualify_small_palette(s,record):
    s.active=record['id']
    progress=dict(id=record['id'],stage='LITERAL_BUILD',input=record,queries=[])
    s.component_rows.append(progress)
    palette,tiles=literal_tiles(s,record)
    progress.update(legacy_palette=palette,semantic_tiles=tiles,stage='IMPLICIT_BUILD')
    build=palette_call(s,'build_palette_query',[record['machine'],record['wire']])
    desc=build['descriptor']
    description=palette_call(s,'describe',[desc])
    buckets={}
    keys={tile_key(tile):tile for tile in tiles}
    for tile in tiles:
        for bits in range(16):
            s.check()
            mask=tuple(tile['edges_NESW'][i]if bits&(1<<i)else None for i in range(4))
            buckets.setdefault(mask,[]).append(tile)
    zero_masks=[
        (0,None,None,None),
        (('not_a_palette_color',),None,None,None),
        (('cell',('plain',0)),('pair',('plain',1),('plain',0)),None,None),
        (('cell',('plain',0)),None,None,('pair',('plain',0),('plain',1))),
        (('cell',('wall',)),None,None,None),
        (('cell',('head',record['machine']['accepting'],0)),
         ('pair',('head',record['machine']['accepting'],0),('plain',0)),
         ('cell',('plain',0)),('pair',('plain',0),('head',record['machine']['accepting'],0))),
        (('cell',('head',0,0)),('pair',('head',0,0),('head',0,0)),
         None,('pair',('head',0,0),('head',0,0))),
    ]
    for mask in zero_masks:
        s.check()
        expected=[tile for tile in tiles if all(value is None or value==tile['edges_NESW'][i]
                                              for i,value in enumerate(mask))]
        need(not expected,'declared empty cross-splice really has no literal tile')
        buckets.setdefault(mask,[])
    progress.update(descriptor=desc,build=build,description=description,stage='QUERIES')
    queries=progress['queries']
    # Construct the entire original ordered request stream from independent
    # literal bucket populations. Counts never choose how many ranks to test.
    # Count then every rank per bucket, preserving original insertion order.
    pending=[]
    answers=[]
    scope_ordinal=0
    def flush():
        nonlocal scope_ordinal
        need(pending,'nonempty deterministic profile chunk')
        requests=tuple(pending)
        pending.clear()
        scope_ordinal+=1
        values=[]
        def body(query):
            bind_profile_query(s,query)
            for request in requests:
                s.check()
                if request[0]=='count':
                    value=profile_query(s,'count_query',[desc,request[1]])
                else:
                    value=profile_query(s,'select_query',[desc,request[1],request[2]])
                values.append(value)
            return None
        profile_call(s,record['id']+'-small-profile-'+str(scope_ordinal),desc,
            dict(record=record,ordered_requests=requests),body)
        need(len(values)==len(requests),'whole deterministic request chunk delivered')
        answers.extend(zip(requests,values))
    for mask,expected in buckets.items():
        s.check()
        pending.append(('count',mask))
        if len(pending)==PROFILE_QUERY_CHUNK:flush()
        for rank in range(len(expected)):
            s.check()
            pending.append(('select',mask,rank))
            if len(pending)==PROFILE_QUERY_CHUNK:flush()
    if pending:flush()
    # Verify all results only after retaining the complete unchanged stream.
    position=0;witnesses=0
    for query_index,(mask,expected)in enumerate(buckets.items()):
        s.check()
        request,q=answers[position];position+=1
        need(request==('count',mask)and type(q['count'])is int and q['count']==len(expected),
             'complete implicit degree equals independent literal projection bucket')
        found=[];costs=[]
        for rank in range(len(expected)):
            s.check()
            request,selected=answers[position];position+=1
            need(request==('select',mask,rank),'all independent ranks retain original query order')
            tile=selected['tile'];key=tile_key(tile)
            need(key in keys and tile_bytes(tile)==tile_bytes(keys[key]),
                 'full selected point tile equals independent original literal tile')
            need(all(value is None or tile['edges_NESW'][i]==value for i,value in enumerate(mask)),
                 'selected rank matches all assigned values together')
            found.append(tile);costs.append(selected['attempted_work']);witnesses+=1
        need(len({tile_key(tile)for tile in found})==len(found)and
             {tile_key(tile)for tile in found}=={tile_key(tile)for tile in expected},
             'every query unranking is a distinct exhaustive bijection')
        queries.append(dict(index=query_index,mask=mask,count=q['count'],
            count_attempted_work=q['attempted_work'],select_attempted_work=costs,
            selected_tiles=found,complete=True))
    need(position==len(answers),'entire unchanged query stream verified')
    need(witnesses==16*len(tiles),'exact sixteen full-inventory witness populations')
    if not hasattr(s,'literal_models'):s.literal_models={}
    s.literal_models[record['id']]=(palette,tiles,desc,buckets)
    s.oracle_work+=1
    return dict(id=record['id'],complete=True,input=record,descriptor=desc,
        build=build,description=description,legacy_palette=palette,semantic_tiles=tiles,
        queries=queries,nonempty_mask_queries=sum(bool(value['count'])for value in queries),
        zero_mask_queries=sum(not value['count']for value in queries),
        selected_witnesses=witnesses,full_literal_tile_count=len(tiles),
        scope='All nonempty masks, all independent ranks, plus declared empty cross-splices; deterministic128-request custody scopes, not the full Cartesian cube of colors.')
