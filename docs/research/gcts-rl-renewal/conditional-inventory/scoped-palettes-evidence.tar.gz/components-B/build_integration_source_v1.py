"""Source text authoring only; never imports or calls authored subjects."""
from pathlib import Path
import ast
import hashlib
import json
import sys

D = Path(__file__).resolve().parent.parent
O = D / 'components-B'

def replace_once(text, old, new):
    assert text.count(old) == 1, (old[:160], text.count(old))
    return text.replace(old, new, 1)

source = (D / 'recovered/future-B/implicit_wang_batch_v1.py').read_text()
source = replace_once(source, "VERSION = 'implicit-wang-batch-v1'", "VERSION = 'implicit-wang-batch-v2-receipt-lifetime'")
source = replace_once(source,
    "active_query=None, attempted_queries=0, receipts=[],",
    "active_query=None, attempted_queries=0, produced_receipt_count=0,\n                 preimage_completed_count=0, delivered_receipt_count=0, receipts=[],")
source = replace_once(source,
    "start_work=work.work, delivered=False)",
    "start_work=work.work, produced_receipt=None,\n                                        produced_preimage=None, preimage_complete=False,\n                                        delivered=False)")
source = replace_once(source,
    """            state['active_query']['stage'] = 'RETAINING_EXACT_RECEIPT'
            expected = _receipt_tree(receipt, state)
            state['receipts'].append(receipt)
            state['expected_receipts'].append(expected)
            work.tick()
            state['active_query']['stage'] = 'DELIVERED'
            state['active_query']['delivered'] = True
            state['active_query'] = None
""",
    """            # Publish the complete raw output to the retained active lifetime
            # before any receipt-copy callback/limit can fail. There is no tick
            # between raw receipt production and its independent lifetime count.
            state['active_query']['produced_receipt'] = receipt
            state['produced_receipt_count'] += 1
            state['active_query']['stage'] = 'RETAINING_EXACT_RECEIPT'
            expected = _receipt_tree(receipt, state)
            # Keep the complete typed preimage before the next callback or
            # append can fail. A copied receipt is not yet a delivered receipt.
            state['active_query']['produced_preimage'] = expected
            state['active_query']['preimage_complete'] = True
            state['preimage_completed_count'] += 1
            work.tick()
            state['receipts'].append(receipt)
            state['expected_receipts'].append(expected)
            work.tick()
            state['active_query']['stage'] = 'DELIVERED'
            state['active_query']['delivered'] = True
            state['delivered_receipt_count'] += 1
            state['active_query'] = None
""")
source = replace_once(source,
    """                    attempted_queries=state['attempted_queries'],
                    attempted_requests=tuple(state['requests']),""",
    """                    attempted_queries=state['attempted_queries'],
                    produced_receipt_count=state['produced_receipt_count'],
                    preimage_completed_count=state['preimage_completed_count'],
                    delivered_receipt_count=state['delivered_receipt_count'],
                    attempted_requests=tuple(state['requests']),""")
source = replace_once(source,
    """                    attempted_queries=state['attempted_queries'],
                    preparation_attempted_work=state['preparation_work'],""",
    """                    attempted_queries=state['attempted_queries'],
                    produced_receipt_count=state['produced_receipt_count'],
                    preimage_completed_count=state['preimage_completed_count'],
                    delivered_receipt_count=state['delivered_receipt_count'],
                    active_query=state['active_query'],
                    attempted_requests=tuple(state['requests']),
                    exact_receipt_preimages=tuple(state['expected_receipts']),
                    preparation_attempted_work=state['preparation_work'],""")
component_path = O / 'implicit_wang_batch_v2.py'
if component_path.exists():
    assert component_path.read_text()==source
else:
    component_path.write_text(source)

# Worker integration is authored below from the separately preserved original
# summary-first Source. Neither Source module is imported, evaluated or called.
worker = (D / 'recovered/future-L/qualify_implicit_worker_v2_summary_first.py').read_text()
worker = replace_once(worker,
    "VERSION = 'complete-implicit-palette-point-graph-worker-v2-summary-first'",
    "VERSION = 'complete-implicit-batch-point-graph-worker-v3'")
worker = replace_once(worker,
    "COMPONENT_LIMITS={'selector':SELECTOR_LIMITS,'implicit':IMPLICIT_LIMITS,'graph':GRAPH_LIMITS}",
    """COMPONENT_LIMITS={'selector':SELECTOR_LIMITS,'implicit':IMPLICIT_LIMITS,'graph':GRAPH_LIMITS}
PROFILE_LIMITS = dict(IMPLICIT_LIMITS, queries=1000000, receipt_items=2000000)
PROFILE_QUERY_CHUNK = 128
PROFILE_GRANULARITY = 'PROFILE_ENTRY_EXIT_PLUS_LOCAL_QUERY_GUARDS_V1'
PROFILE_METRIC_KEYS = ('profile_count','profile_attempted_work','profile_preparation_work',
    'profile_query_kernel_work','profile_overhead_work','profile_postpreparation_overhead_work',
    'produced_receipt_count','preimage_completed_count','delivered_receipt_count',
    'attempted_queries','palette_attempted_work_known_total','palette_work_unavailable_count')""")
worker = replace_once(worker,
    """        self.component_limits=clone(COMPONENT_LIMITS)
""",
    """        self.component_limits=clone(COMPONENT_LIMITS)
        self.profile_rows=[];self.profile_lifetimes=[];self.profile_owners=[];self.profile_accounting=[]
        self.profile_query_context=None
        self.palette_work_known_total=0;self.palette_work_unavailable_count=0
        self.palette_call_owners=[]
        self.batch_diagnostics=[];self.batch_diagnostic_progress=[];self.batch_diagnostic_owners=[]
        self.worker_function_seal=callable_seal(sys.modules[__name__])
""")

worker = replace_once(worker,
    """                rows.append((key,id(value),id(value.__code__),id(value.__defaults__),id(value.__kwdefaults__)))""",
    """                closure = value.__closure__
                closure_owners = []
                if closure is not None:
                    for cell in closure:
                        try: owner = id(cell.cell_contents)
                        except ValueError: owner = None
                        closure_owners.append((id(cell),owner))
                rows.append((key,id(value),id(value.__code__),id(value.__defaults__),
                             id(value.__kwdefaults__),id(closure),tuple(closure_owners)))""")

worker = replace_once(worker,
    """            for role,module in self.modules.items():
""",
    """            need(callable_seal(sys.modules[__name__])==self.worker_function_seal,
                 'whole worker function/code/default/closure-owner binding')
            for role,module in self.modules.items():
""")

start = worker.index('def palette_call(')
end = worker.index('\ndef qualify_small_palette(', start)
helpers = (O / 'profile_helpers.fragment.py').read_text()
worker = worker[:start] + helpers + '\n' + worker[end:]

# Additional exact Source-text replacements are stored in separate authoring
# fragments for review. This builder only copies those literal fragments.
start = worker.index('def qualify_small_palette(')
end = worker.index('\ndef independent_membership(', start)
worker = worker[:start] + (O / 'small_profile.fragment.py').read_text() + '\n' + worker[end:]

start = worker.index('def qualify_large_palette(')
end = worker.index('\n\nOFFSETS=', start)
original_large = worker[start:end]
# Keep every original large query and oracle in its original order, merely
# moving that sequence into one synchronous profile body.
large_body_start = original_large.index("    total=palette_call(s,'count_query'")
large_body_end = original_large.index('    s.oracle_work+=1')
large_body = original_large[large_body_start:large_body_end]
large_body = large_body.replace("palette_call(s,'count_query',[desc,", "profile_query(s,'count_query',[desc,")
large_body = large_body.replace("palette_call(s,'select_query',[desc,", "profile_query(s,'select_query',[desc,")
large_body += "    total_holder.append(total)\n    return None\n"
large_body = ''.join('    '+line if line.strip() else line for line in large_body.splitlines(keepends=True))
large_new = (original_large[:large_body_start] + "    total_holder=[]\n    def body(query):\n" +
             "        bind_profile_query(s,query)\n" + large_body +
             "    profile_call(s,record['id']+'-large-profile',desc,\n" +
             "        dict(record=record,descriptor=desc),body)\n" +
             "    need(len(total_holder)==1,'one complete large total')\n" +
             "    total=total_holder[0];samples=progress['samples'];focused=progress['focused']\n" +
             original_large[large_body_end:])
worker = worker[:start]+large_new+worker[end:]

worker = replace_once(worker,
    """    class Facade:
        def count_query(self,descriptor,mask,*,check,limits):
            return palette_call(s,'count_query',[descriptor,mask],limits,check)
        def select_query(self,descriptor,mask,index,*,check,limits):
            return palette_call(s,'select_query',[descriptor,mask,index],limits,check)
""",
    """    class Facade:
        def count_query(self,descriptor,mask,*,check,limits):
            return profile_query(s,'count_query',[descriptor,mask],limits,check)
        def select_query(self,descriptor,mask,index,*,check,limits):
            return profile_query(s,'select_query',[descriptor,mask,index],limits,check)
""")
worker = replace_once(worker,
    """    result=s.call('graph','search',data,lambda:s.modules['graph'].search(instance,Facade(),desc,
        check=s.check,limits=dict(GRAPH_LIMITS),oracle_limits=dict(IMPLICIT_LIMITS),observe=observe,mode=case['mode']))""",
    """    result_holder=[]
    def graph_body(query):
        bind_profile_query(s,query)
        result_holder.append(s.call('graph','search',data,lambda:s.modules['graph'].search(instance,Facade(),desc,
            check=s.check,limits=dict(GRAPH_LIMITS),oracle_limits=dict(IMPLICIT_LIMITS),observe=observe,mode=case['mode'])))
        return None
    profile_call(s,case['id']+'-graph-profile',desc,data,graph_body)
    need(len(result_holder)==1,'one complete graph consumer result')
    result=result_holder[0]""")
worker = replace_once(worker,
    """            def count_query(self,descriptor,query,*,check,limits):return palette_call(s,'count_query',[descriptor,query],limits,check)
            def select_query(self,descriptor,query,index,*,check,limits):return palette_call(s,'select_query',[descriptor,query,index],limits,check)""",
    """            def count_query(self,descriptor,query,*,check,limits):return profile_query(s,'count_query',[descriptor,query],limits,check)
            def select_query(self,descriptor,query,index,*,check,limits):return profile_query(s,'select_query',[descriptor,query,index],limits,check)""")
worker = replace_once(worker,
    """        action=lambda:s.call('graph','search',data,lambda:s.modules['graph'].search(instance,Facade(),desc,
            check=callback if expected=='FOREIGN'else s.check,limits=bound,oracle_limits=dict(IMPLICIT_LIMITS),mode=mode))""",
    """        result_holder=[]
        def graph_body(query):
            bind_profile_query(s,query)
            result_holder.append(s.call('graph','search',data,lambda:s.modules['graph'].search(instance,Facade(),desc,
                check=callback if expected=='FOREIGN'else s.check,limits=bound,oracle_limits=dict(IMPLICIT_LIMITS),mode=mode)))
            return None
        def graph_action():
            profile_call(s,d['id']+'-graph-diagnostic-profile',desc,data,graph_body)
            need(len(result_holder)==1,'one complete original graph diagnostic result')
            return result_holder[0]
        action=graph_action""")

worker = replace_once(worker, 'def qualify(s,inputs):',
    """def run_new_diagnostics(s,bank):
    # Root must replace this explicit refusal with the independently authored
    # diagnostics fragment before any actual can be granted.
    raise PolicyFailure('new batch diagnostics fragment has not been integrated')


def qualify(s,inputs,batch_inputs):""")
worker = replace_once(worker,
    """        s.active=d['id'];s.diagnostics.append(diagnostic(s,d,inputs))
    return dict(schema='implicit-palette-graph-calibration-packet-v1'""",
    """        s.active=d['id'];s.diagnostics.append(diagnostic(s,d,inputs))
    s.stage='BATCH_DIAGNOSTICS'
    run_new_diagnostics(s,batch_inputs)
    final_profile_custody(s)
    return dict(schema='implicit-palette-graph-calibration-packet-v1'""")
worker = replace_once(worker,
    """        call_started=s.started,call_completed=s.completed,call_raised=s.raised,root_callbacks=s.root_calls,
        full_VM_implemented=False""",
    """        call_started=s.started,call_completed=s.completed,call_raised=s.raised,root_callbacks=s.root_calls,
        batch_inputs=batch_inputs,profile_rows=s.profile_rows,profile_metrics=profile_metrics(s),
        profile_accounting=s.profile_accounting,
        batch_diagnostics=s.batch_diagnostics,batch_diagnostic_progress=s.batch_diagnostic_progress,
        full_VM_implemented=False""")
worker = replace_once(worker,
    "declaration['checkpoint_limit']==CHECKPOINT_LIMIT and declaration['experiment_kind']=='COMPLETE_IMPLICIT_PALETTE_AND_POINT_GRAPH_CALIBRATION'",
    "declaration['checkpoint_limit']==CHECKPOINT_LIMIT and declaration['experiment_kind']=='COMPLETE_IMPLICIT_BATCH_AND_POINT_GRAPH_CALIBRATION' and declaration['profile_limits']==PROFILE_LIMITS and declaration['profile_granularity']==PROFILE_GRANULARITY and declaration['profile_query_chunk']==PROFILE_QUERY_CHUNK")
worker = replace_once(worker,
    """        need(plan['inputs']==declaration['inputs']and len(plan['inputs'])==1,'one whole declared calibration bank')
        inputs=json.loads(checked(plan['inputs'][0]['pin'],134217728))
        need(inputs['schema']=='implicit-palette-inputs-v1','exact input schema')""",
    """        need(plan['inputs']==declaration['inputs']and len(plan['inputs'])==2,'two whole declared calibration banks')
        inputs=json.loads(checked(plan['inputs'][0]['pin'],134217728))
        batch_inputs=json.loads(checked(plan['inputs'][1]['pin'],134217728))
        need(inputs['schema']=='implicit-palette-inputs-v1','exact original input schema')
        need(batch_inputs['schema']=='implicit-batch-summary-diagnostics-v1','exact new diagnostic schema')""")
worker = replace_once(worker, 'packet=qualify(s,inputs);', 's.batch_original_inputs=inputs;s.batch_original_inputs_preimage=argument_bytes(inputs);packet=qualify(s,inputs,batch_inputs);')
worker = replace_once(worker,
    """            diagnostics=s.diagnostics,diagnostic_ids=[r['id']for r in s.diagnostics],
            small_palettes=""",
    """            diagnostics=s.diagnostics,diagnostic_ids=[r['id']for r in s.diagnostics],
            profile_metrics=profile_metrics(s),
            batch_diagnostics=[dict(id=g['id'],subject=g['subject'],recipe=g['recipe'],
                status=g['status'],complete=g['complete'],variants=[dict(id=v['id'],
                    status=v['status'],complete=v['complete'],expected=v['expected'])for v in g['variants']])
                for g in s.batch_diagnostics],
            batch_diagnostic_ids=[r['id']for r in s.batch_diagnostics],
            profile_granularity=PROFILE_GRANULARITY,profile_query_chunk=PROFILE_QUERY_CHUNK,
            small_palettes=""")
worker = replace_once(worker,
    """        s.output_pins.append(output)
        counts=dict(""",
    """        s.output_pins.append(output)
        expanded_packet_bytes=output['bytes']+s.expanded_subtree_delta
        need(output['bytes']<=expanded_packet_bytes<=134217728,
             'conservative full profile return reconstruction within original expanded128MiB')
        counts=dict(""")
worker = replace_once(worker,
    """denied_events=s.denied,canonical_logical_bytes=output['bytes'],expanded_canonical_packet_bytes=output['bytes'],""",
    """denied_events=s.denied,canonical_logical_bytes=output['bytes'],expanded_canonical_packet_bytes=expanded_packet_bytes,
            profile_return_reconstruction_delta_bytes=s.expanded_subtree_delta,
            expanded_scope='Conservative full-return reconstruction bound; q is an admission summary, not a duplicated full-row representation.',""")
worker = replace_once(worker,
    """        logical=output['bytes']+result['bytes'];need(0<logical<=134217728,'full unshared stored/expanded packet')""",
    """        logical=output['bytes']+result['bytes']
        expanded_logical=expanded_packet_bytes+result['bytes']
        need(0<logical<=expanded_logical<=134217728,'whole stored and conservatively expanded packet plus result within original128MiB')""")
worker = replace_once(worker,
    """result=result,outputs=s.output_pins,logical_result_bytes=logical,expanded_logical_result_bytes=logical,""",
    """result=result,outputs=s.output_pins,logical_result_bytes=logical,expanded_logical_result_bytes=expanded_logical,""")
worker = replace_once(worker,
    """        checked(plan['inputs'][0]['pin'],134217728);s.check()""",
    """        for input_record in plan['inputs']:checked(input_record['pin'],134217728)
        final_profile_custody(s);s.check()""")
worker = replace_once(worker,
    """            completed_case_ids=[r['id']for r in s.rows],diagnostic_prefix=s.diagnostics,
""",
    """            completed_case_ids=[r['id']for r in s.rows],diagnostic_prefix=s.diagnostics,
            batch_diagnostic_progress=s.batch_diagnostic_progress,
""")
worker = replace_once(worker,
    """                completed_cases=s.rows,diagnostics=s.diagnostics,no_admission=True),""",
    """                completed_cases=s.rows,diagnostics=s.diagnostics,
                profile_rows=s.profile_rows,batch_diagnostics=s.batch_diagnostics,
                profile_accounting=s.profile_accounting,
                batch_diagnostic_progress=s.batch_diagnostic_progress,no_admission=True),""")
worker_path=O/'qualify_implicit_batch_worker_v8.py'
assert not worker_path.exists()
worker_path.write_text(worker)

pins=[]
for path in (component_path,worker_path):
    raw=path.read_bytes()
    parsed=ast.parse(raw,filename=str(path))
    compile(parsed,str(path),'exec')  # UNUSED code object; never exec/import.
    pins.append(dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),
        ast_sha256=hashlib.sha256(ast.dump(parsed,annotate_fields=True,include_attributes=False).encode()).hexdigest()))
(O/'author-Source-static-v8.json').write_text(json.dumps(dict(schema='Source-author-static-v1',
    status='SOURCE_ONLY_UNUSED_COMPILE',subject_imports=0,subject_calls=0,python=sys.version,
    files=pins),indent=2)+'\n')
print(json.dumps(pins,indent=2))
