def account_palette_work(s,amount):
    """One cost observation, never an invocation or a callback.

    Missing constructor prefixes are unavailable, never zero. On an active
    failure this helper cannot replace the primary. Invalid accounting still
    independently latches a Root policy fault for the later fault gate.
    """
    try:
        if amount is None:
            s.palette_work_unavailable_count += 1
        else:
            need(type(amount)is int and amount>=0,'exact available palette private work')
            s.palette_work_known_total += amount
    except BaseException as accounting_error:
        if s.first_fault is None:s.first_fault=accounting_error
        # This function is metadata-only. The independent fault latch is
        # authoritative and is checked before any expected-fault admission.
    return None


def record_profile_accounting(s,profile_id,*,receipt=None,prefix=None,lifetime=None):
    """Retain one known/unknown cost row for one complete attempted scope.

    Call exactly once, including diagnostics. This is not an extra allowance;
    it observes already attempted cumulative work. The helper itself performs
    no check, Source replay, component operation or warmup. Its failure latches
    independently, so an expected diagnostic cannot launder missing accounting.
    """
    try:
        need(type(profile_id)is str,'literal profile accounting id')
        need(not any(row['id']==profile_id for row in s.profile_accounting),
             'one metric observation per attempted profile')
        source=receipt if type(receipt)is dict else prefix if type(prefix)is dict else {}
        live=lifetime if type(lifetime)is dict else {}
        amount=source.get('attempted_work')
        if amount is None and live.get('work')is not None:
            amount=live['work'].work
        preparation=source.get('preparation_attempted_work',live.get('preparation_work'))
        kernel=source.get('query_attempted_work',live.get('query_work'))
        counters={}
        for key in('attempted_queries','produced_receipt_count',
                   'preimage_completed_count','delivered_receipt_count'):
            value=source.get(key,live.get(key))
            need(value is None or type(value)is int and value>=0,
                 'exact available profile lifetime counter')
            counters[key]=value
        for value in(amount,preparation,kernel):
            need(value is None or type(value)is int and value>=0,
                 'exact available cumulative profile work')
        overhead=None if amount is None or kernel is None else amount-kernel
        post=None if overhead is None or preparation is None else overhead-preparation
        need(overhead is None or overhead>=0,'nonnegative total profile overhead')
        need(post is None or post>=0,'nonnegative postpreparation profile overhead')
        row=dict(id=profile_id,attempted_work=amount,preparation_work=preparation,
            query_kernel_work=kernel,overhead_work=overhead,
            postpreparation_overhead_work=post,private_work_available=amount is not None,
            complete=type(receipt)is dict,**counters)
        s.profile_accounting.append(row)
        account_palette_work(s,amount)
    except BaseException as accounting_error:
        if s.first_fault is None:s.first_fault=accounting_error
    return None


def profile_metrics(s):
    """Twelve exact fields. Work sums cover available observations only.

    Cost-unavailable observations remain explicitly counted; numeric sums do
    not assert private-work completeness. Never add per-query costs to totals.
    """
    # Expected-failed diagnostic profiles are retained and charged in the
    # all-palette known/unavailable totals below, but are not completed profiles.
    # Their different production/copy/delivery populations remain per-row data.
    rows=[row for row in s.profile_accounting if row['complete']]
    def total(key):
        result=0
        for row in rows:
            value=row[key]
            if value is not None:result+=value
        return result
    return dict(profile_count=len(rows),
        profile_attempted_work=total('attempted_work'),
        profile_preparation_work=total('preparation_work'),
        profile_query_kernel_work=total('query_kernel_work'),
        profile_overhead_work=total('overhead_work'),
        profile_postpreparation_overhead_work=total('postpreparation_overhead_work'),
        produced_receipt_count=total('produced_receipt_count'),
        preimage_completed_count=total('preimage_completed_count'),
        delivered_receipt_count=total('delivered_receipt_count'),
        attempted_queries=total('attempted_queries'),
        palette_attempted_work_known_total=s.palette_work_known_total,
        palette_work_unavailable_count=s.palette_work_unavailable_count)


def palette_call(s,name,args,limits=None,callback=None):
    """Unchanged standalone path, retained for builds/description/33 old tests."""
    bound=dict(IMPLICIT_LIMITS if limits is None else limits)
    callback=s.check if callback is None else callback
    owner=dict(operation=name,args=args,limits=bound,callback=callback,
               receipt=None,error=None)
    s.palette_call_owners.append(owner)
    try:
        receipt=s.call('implicit',name,dict(args=args,limits=bound),
            lambda:getattr(s.modules['implicit'],name)(*args,check=callback,limits=bound))
    except BaseException as error:
        owner['error']=error
        prefix=getattr(error,'implicit_palette_prefix',None)
        try:
            amount=prefix.get('attempted_work')if type(prefix)is dict else None
            account_palette_work(s,amount)
            s.retained.append(dict(role='implicit',operation=name,args=args,limits=bound,
                completed=False,error=information(error),prefix=prefix))
        except BaseException as retention_error:
            if s.first_fault is None:s.first_fault=retention_error
        raise
    owner['receipt']=receipt
    account_palette_work(s,receipt.get('attempted_work')if type(receipt)is dict else None)
    s.fault_gate()
    s.retained.append(dict(role='implicit',operation=name,args=args,limits=bound,
        completed=True,receipt=receipt))
    return receipt


def function_owner_seal(value):
    need(type(value)is types.FunctionType,'owned synchronous profile callback function')
    closure=value.__closure__
    owners=[]
    if closure is not None:
        for cell in closure:
            try:
                content=cell.cell_contents
                owner=id(content)
            except ValueError:
                content=None;owner=None
            class_members=[]
            if type(content)is type:
                for name,item in sorted(vars(content).items()):
                    if type(item)in(staticmethod,classmethod):item=item.__func__
                    if type(item)is types.FunctionType:
                        class_members.append((name,id(item),id(item.__code__),
                            id(item.__defaults__),id(item.__kwdefaults__),id(item.__closure__)))
            owners.append((id(cell),owner,tuple(class_members)))
    return(id(value),id(value.__code__),id(value.__defaults__),id(value.__kwdefaults__),
           id(closure),tuple(owners))


def bind_profile_query(s,query):
    context=s.profile_query_context
    need(type(context)is dict and context['query']is None,'one synchronous scoped query owner')
    context['query']=query
    context['query_seal']=function_owner_seal(query)
    context['owners'].append(query)


def _exact_implicit_limits(limits):
    return(type(limits)is dict and len(limits)==len(IMPLICIT_LIMITS) and
           all(type(key)is str and key in IMPLICIT_LIMITS and type(value)is int and
               value==IMPLICIT_LIMITS[key]for key,value in limits.items()))


def profile_query(s,name,args,limits=None,callback=None):
    """Local query guard inside a fully custodied profile, no file rehash.

    The active dispatcher is replaced by the exact L charged_check for every
    dynamic graph request, so every internal B tick also charges L's work.
    Restoration occurs on both return and fault; descriptor/profile preparation
    and reconciliation use the Root check instead of a stale graph callback.
    """
    context=s.profile_query_context
    need(type(context)is dict and context['query']is not None,'query has a live Root profile owner')
    need(args[0]is context['descriptor'],'exact descriptor object within profile')
    if limits is not None:need(_exact_implicit_limits(limits),'exact unchanged graph oracle limits')
    need(name in('count_query','select_query'),'declared local query operation')
    request=('count',args[1])if name=='count_query'else('select',args[1],args[2])
    before=argument_bytes(request)
    previous=context['check']
    selected_check=s.check if callback is None else callback
    need(callable(selected_check),'exact charged dynamic callback')
    # Keep the callback and every argument owner alive through final custody.
    context['owners'].append((selected_check,args,request,before))
    context['requests'].append(request)
    context['check']=selected_check
    key='implicit.profile_'+name
    s.started[key]=s.started.get(key,0)+1
    try:
        need(function_owner_seal(context['query'])==context['query_seal'],
             'scoped query function/code/default/closure owner unchanged')
        receipt=context['query'](request)
    except BaseException:
        s.raised[key]=s.raised.get(key,0)+1
        # Root independent faults dominate an otherwise expected graph fault.
        s.fault_gate()
        raise
    finally:
        context['check']=previous
    s.fault_gate()
    s.policy(lambda:need(argument_bytes(request)==before,'full local literal request unchanged'))
    need(function_owner_seal(context['query'])==context['query_seal'],
         'scoped query binding unchanged after delivery')
    s.completed[key]=s.completed.get(key,0)+1
    return receipt


def _ordinary_profile_lifetime(state):
    """One complete ordinary projection; raw owner aggregate remains retained."""
    keys=('schema','descriptor','limits','active','busy','active_query','attempted_queries',
          'produced_receipt_count','preimage_completed_count','delivered_receipt_count',
          'receipts','requests','expected_receipts','query_work','receipt_items',
          'preparation_work','stage','failed_stage','custody_entry_attempted',
          'custody_entry_completed','custody_exit_attempted','custody_exit_completed',
          'custody_cleanup_error','registered','authority')
    ordinary={key:state[key]for key in keys}
    work=state['work']
    ordinary['attempted_work']=None if work is None else work.work
    ordinary['data_items']=None if work is None else work.items
    fault=state['query_fault']
    ordinary['query_fault']=None if fault is None else information(fault)
    ordinary['body_result']=state['body_result']
    return ordinary


def profile_call(s,profile_id,desc,guard_data,body):
    """One Root complete Source/closure/argument boundary for one profile."""
    need(s.profile_query_context is None,'no nested or warm profile state')
    bound=dict(PROFILE_LIMITS)
    data=dict(descriptor=desc,data=guard_data,limits=bound,
              granularity=PROFILE_GRANULARITY)
    before=argument_bytes(data)
    owner_seal=function_owner_seal(body)
    registered=[]
    context=dict(id=profile_id,descriptor=desc,query=None,query_seal=None,
                 check=s.check,owners=[body,data,before],requests=[])
    s.profile_query_context=context
    s.profile_owners.append(context)
    def dispatcher():
        context['check']()
    def custody(which):
        def verify():
            need(which in('entry','exit'),'exact profile custody endpoint')
            s.guard()
            need(argument_bytes(data)==before,'full profile descriptor/declared input/limits unchanged')
            need(function_owner_seal(body)==owner_seal,
                 'full profile body function/code/default/closure owner unchanged')
            if context['query']is not None:
                need(function_owner_seal(context['query'])==context['query_seal'],
                     'full scoped query function/code/default/closure owner unchanged')
            s.check()
        s.policy(verify)
        return None
    def retain(state):
        need(not registered,'one complete raw profile lifetime registration')
        registered.append(state)
        s.profile_lifetimes.append(state)
        context['owners'].append(state)
        return None
    # Keep callbacks and their captured owners alive, including fault paths.
    context['owners'].extend((dispatcher,custody,retain,registered))
    key='implicit.with_profile';s.started[key]=s.started.get(key,0)+1
    try:
        receipt=s.modules['implicit'].with_profile(desc,body,check=dispatcher,
            limits=bound,custody=custody,retain=retain)
    except BaseException as primary:
        context['owners'].append(primary)
        s.raised[key]=s.raised.get(key,0)+1
        prefix=getattr(primary,'implicit_palette_batch_prefix',None)
        lifetime=registered[0]if registered else None
        record_profile_accounting(s,profile_id,prefix=prefix,lifetime=lifetime)
        # Best-effort ordinary projection cannot mask the exact primary. The
        # raw lifetime remains in s.profile_lifetimes even if projection fails.
        try:
            s.profile_rows.append(dict(id=profile_id,complete=False,prefix=prefix,
                lifetime=None if lifetime is None else _ordinary_profile_lifetime(lifetime)))
        except BaseException as projection_error:
            if s.first_fault is None:s.first_fault=projection_error
        s.fault_gate()
        raise
    finally:
        s.profile_query_context=None
    record_profile_accounting(s,profile_id,receipt=receipt,lifetime=registered[0]if registered else None)
    s.fault_gate()
    need(len(registered)==1 and receipt['profile_closed']is True,'complete registered closed profile')
    count=receipt['attempted_queries']
    need(count==receipt['produced_receipt_count']==receipt['preimage_completed_count']==
         receipt['delivered_receipt_count']==len(receipt['receipts'])==
         len(receipt['attempted_requests'])==len(receipt['exact_receipt_preimages'])==
         len(context['requests']),'normal profile exact request/production/preimage/delivery populations')
    need(receipt['active_query']is None,'no active query at normal profile close')
    need(receipt['body_result']is None,'caller-owned profile consumer outputs kept separately')
    ordinary=_ordinary_profile_lifetime(registered[0])
    # The one ordinary lifetime stores every full raw receipt/request/preimage.
    # The component return repeats these same sequences. Store only its other
    # fields and explicit complete field bindings; retain the actual original
    # return object in owners and conservatively charge reconstructed duplicates
    # to the unchanged expanded-byte gate. No hash substitutes for any value.
    duplicate_keys=('receipts','attempted_requests','exact_receipt_preimages','body_result')
    metadata={key:value for key,value in receipt.items()if key not in duplicate_keys}
    bindings=dict(receipts=dict(field='receipts',container='list'),
        attempted_requests=dict(field='requests',container='tuple'),
        exact_receipt_preimages=dict(field='expected_receipts',container='tuple'),
        body_result=dict(field='body_result',container='identity'))
    row=dict(id=profile_id,complete=True,lifetime=ordinary,
        profile_return_metadata=metadata,profile_return_bindings=bindings,
        reconstruction_scope='Full return reconstructed from the same row lifetime; conservative expanded-byte bound.')
    full_row=dict(id=profile_id,complete=True,receipt=receipt,lifetime=ordinary)
    s.check()
    raw_full=canonical(full_row)
    raw_compact=canonical(row)
    s.check()
    delta=max(0,len(raw_full)-len(raw_compact))
    row['expanded_reconstruction_charge_bytes']=delta
    s.expanded_subtree_delta+=delta
    context['owners'].extend((receipt,ordinary,row))
    s.profile_rows.append(row)
    s.completed[key]=s.completed.get(key,0)+1
    return receipt['body_result']


def final_profile_custody(s):
    """Retain originals through final custody; no second ordinary projection."""
    s.guard()
    need(s.profile_query_context is None,'all normal profile dispatchers released')
    for context in s.profile_owners:
        s.check()
        need(type(context)is dict and context['check'].__self__ is s,
             'closed profile restored Root dispatcher owner')
        if context['query']is not None:
            need(function_owner_seal(context['query'])==context['query_seal'],
                 'scoped query owner retained through final custody')
    for row in s.profile_accounting:
        s.check()
        need(type(row['private_work_available'])is bool,'explicit private-cost availability')
    s.fault_gate()
