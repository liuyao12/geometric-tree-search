# Source-only diagnostic extension. No imports or top-level component calls.
# Root inserts this fragment before main in one freshly reviewed whole worker.


def _batch_diag_plain(s, value, owners, depth=0):
    """Full ordinary projection; nonliteral references are metadata, not replay."""
    s.check()
    need(depth <= 128, 'bounded diagnostic projection depth')
    kind = type(value)
    if value is None or kind in (str, int, bool):
        return value
    if kind is tuple:
        return dict(literal_type='tuple', items=[_batch_diag_plain(s, x, owners, depth + 1) for x in value])
    if kind is list:
        return [_batch_diag_plain(s, x, owners, depth + 1) for x in value]
    if kind is dict:
        need(all(type(k) is str for k in value), 'diagnostic ordinary string-key mapping')
        return {k: _batch_diag_plain(s, v, owners, depth + 1) for k, v in value.items()}
    position = None
    for i in range(len(owners)):
        s.check()
        if owners[i] is value:
            position = i
            break
    if position is None:
        position = len(owners)
        owners.append(value)
    name = type(value).__name__
    module = type(value).__module__
    return dict(nonliteral_reference=position,
                type_name=name[:160] if type(name) is str else None,
                type_module=module[:160] if type(module) is str else None,
                replayable=False, representation_evaluated=False)


def _batch_diag_immutable(s, value):
    s.check()
    if type(value) is list:
        copied = []
        for x in value:
            copied.append(_batch_diag_immutable(s, x))
        return tuple(copied)
    need(value is None or type(value) in (str, int, bool), 'original descriptor literal codec')
    return value


def _batch_diag_error(s, module, name):
    s.check()
    if name == 'RuntimeError':
        return RuntimeError('declared batch diagnostic RuntimeError')
    if name == 'ValueError':
        return ValueError('declared batch diagnostic ValueError')
    if name == 'StopIteration':
        return StopIteration('declared batch diagnostic StopIteration')
    if name == 'Invalid':
        return module.Invalid('foreign public Invalid without owner')
    if name == 'Limit':
        return module.Limit('foreign public Limit without owner', 0)
    need(False, 'literal diagnostic exception enum')


def _batch_diag_profile(s, desc, parameters, recipe, run_label, limits_override=None):
    """One Root boundary. Planned sentinels never enter Root's genuine latch."""
    m = s.modules['implicit']
    limits = dict(IMPLICIT_LIMITS)
    limits.update(queries=1000000, receipt_items=2000000)
    if limits_override is not None:
        limits.update(limits_override)
    mask = (None, None, None, None)
    requests = (('count', mask), ('select', mask, 0), ('count', (0, None, None, None)))
    owner = dict(label=run_label, recipe=recipe, parameters=parameters, descriptor=desc,
                 limits=limits, callbacks={}, errors=[], lifetimes=[], queries=[],
                 events=[], observed_receipts=[], checkpoint_after_first=None,
                 thrown=None, result=None, trigger_fired=False, foreign=None,
                 secondary=None, nonliteral_owners=[], profile_admitted=False,
                 custody_success=False)
    s.batch_diagnostic_owners.append(owner)
    if recipe in ('foreign-site', 'foreign-public-class'):
        owner['foreign'] = _batch_diag_error(s, m, parameters['exception'])
        owner['errors'].append(owner['foreign'])
    if recipe == 'closed-failure' or recipe == 'secondary-nonmasking':
        owner['foreign'] = _batch_diag_error(s, m, 'RuntimeError')
        owner['errors'].append(owner['foreign'])
    if recipe == 'secondary-nonmasking':
        owner['secondary'] = _batch_diag_error(s, m, parameters['secondary'])
        owner['errors'].append(owner['secondary'])
    baseline = argument_bytes(dict(descriptor=desc, limits=limits))

    def state_now():
        return owner['lifetimes'][0] if owner['lifetimes'] else None

    def fire():
        s.check()
        owner['trigger_fired'] = True
        raise owner['foreign']

    def check():
        # The real Root gate runs before even looking for a planned trigger.
        s.check()
        state = state_now()
        site = parameters.get('site')
        if recipe in ('foreign-site', 'foreign-public-class') and not owner['trigger_fired']:
            if site == 'entry' and state is None:
                fire()
            if state is not None:
                active = state['active_query']
                stage = state['stage']
                if site == 'preparation' and stage == 'VALIDATING_COMPLETE_DESCRIPTOR':
                    fire()
                if site == 'query-kernel' and active is not None and active['stage'] == 'INTERSECTING_FULL_PALETTE':
                    fire()
                if site == 'first-receipt-tree' and active is not None and active['stage'] == 'RETAINING_EXACT_RECEIPT':
                    frame = sys._getframe(1)
                    found = False
                    for unused in range(32):
                        if frame is None:
                            break
                        if frame.f_code.co_filename == s.plan['sources']['implicit']['path'] and frame.f_code.co_name == '_receipt_tree':
                            found = True
                            break
                        frame = frame.f_back
                    if found:
                        fire()
                if site == 'reconciliation' and stage == 'RECONCILING_FULL_RECEIPT_SEQUENCE':
                    frame = sys._getframe(1)
                    for unused in range(32):
                        if frame is None:
                            break
                        if frame.f_code.co_filename == s.plan['sources']['implicit']['path'] and frame.f_code.co_name == '_same_receipt_tree':
                            fire()
                        frame = frame.f_back
        if recipe == 'reentrant' and state is not None and state['active_query'] is not None and not owner['trigger_fired']:
            if state['active_query']['stage'] == 'INTERSECTING_FULL_PALETTE':
                owner['trigger_fired'] = True
                try:
                    owner['queries'][0](('count', mask))
                except BaseException as error:
                    owner['errors'].append(error)
                    owner['foreign'] = error
                    raise

    def custody(phase):
        # Integrity is real. Only after a successful guard may a planned refusal
        # be injected. It establishes refusal, never custody acceptance.
        s.guard()
        s.fault_gate()
        s.policy(lambda: need(argument_bytes(dict(descriptor=desc, limits=limits)) == baseline,
             'full diagnostic profile arguments at actual custody boundary'))
        owner['events'].append(phase)
        if recipe == 'foreign-site' and parameters['site'] == 'custody-' + phase:
            fire()
        if recipe == 'custody-return' and parameters['phase'] == phase:
            owner['trigger_fired'] = True
            return 1
        if recipe == 'secondary-nonmasking' and phase == 'exit':
            owner['trigger_fired'] = True
            raise owner['secondary']
        return None

    def retain(state):
        s.check()
        owner['lifetimes'].append(state)
        if recipe == 'foreign-site' and parameters['site'] == 'retain':
            fire()
        return None

    def body(query):
        s.check()
        owner['queries'].append(query)
        if recipe == 'foreign-site' and parameters['site'] == 'body':
            fire()
        if recipe in ('closed-failure', 'secondary-nonmasking'):
            raise owner['foreign']
        if recipe == 'swallowed-query':
            try:
                query(('unknown', mask))
            except BaseException as first:
                owner['errors'].append(first)
                owner['foreign'] = first
                try:
                    query(('count', mask))
                except BaseException as again:
                    owner['errors'].append(again)
                    need(again is first, 'swallowed query fault reappears by exact identity')
                else:
                    need(False, 'swallowed query cannot resume')
            else:
                need(False, 'declared invalid operation must fail')
            return 'body tried to swallow fault'
        active_requests = requests if recipe in ('ordered-positive', 'static-positive') else (('select', mask, 0),)
        if recipe == 'mutation-bool-int':
            active_requests = (('count', (0, None, None, None)),)
        if recipe in ('cumulative-baseline', 'work-cumulative', 'queries-cumulative', 'receipt-items-cumulative'):
            active_requests = (('count', mask), ('count', mask))
        for request in active_requests:
            receipt = query(request)
            owner['observed_receipts'].append(receipt)
            if owner['checkpoint_after_first'] is None:
                state = state_now()
                owner['checkpoint_after_first'] = dict(work=state['work'].work,
                    receipt_items=state['receipt_items'], delivered_receipt_count=state['delivered_receipt_count'])
        if recipe == 'mutation-bool-int':
            need(type(owner['observed_receipts'][0]['count']) is int and owner['observed_receipts'][0]['count'] == 0,
                 'exact assignedzero mask returns integerzero before alias mutation')
            owner['observed_receipts'][0]['count'] = False
        elif recipe == 'mutation-list-tuple':
            tile = owner['observed_receipts'][0]['tile']
            tile['t'] = tuple(tile['t'])
        elif recipe == 'mutation-absent-zero':
            if parameters['variant'] == 'absent':
                del owner['observed_receipts'][0]['authority']
            else:
                owner['observed_receipts'][0]['authority'] = 0
        return dict(ordered_requests=len(active_requests))

    owner['callbacks'].update(state_now=state_now, fire=fire, check=check,
                              custody=custody, retain=retain, body=body)
    data = dict(descriptor=desc, limits=limits, recipe=recipe, parameters=parameters,
                requests=requests if recipe == 'static-positive' else None)
    try:
        if recipe == 'static-positive':
            result = s.call('implicit', 'batch_diagnostic_static', data,
                lambda: m.batch_query(desc, requests, check=check, limits=limits, custody=custody, retain=retain))
        else:
            result = s.call('implicit', 'batch_diagnostic_profile', data,
                lambda: m.with_profile(desc, body, check=check, limits=limits, custody=custody, retain=retain))
    except BaseException as error:
        owner['thrown'] = error
        owner['errors'].append(error)
        state = state_now()
        prefix = getattr(error, 'implicit_palette_batch_prefix', None)
        record_profile_accounting(s, run_label, prefix=prefix, lifetime=state)
        # Never classify an expected diagnostic while a genuine Root fault lives.
        s.fault_gate()
        owner['prefix'] = prefix
    else:
        owner['result'] = result
        record_profile_accounting(s, run_label, receipt=result, lifetime=state_now())
        s.fault_gate()
        owner['profile_admitted'] = True
        owner['custody_success'] = True
    s.fault_gate()
    return owner


def _batch_diag_closed(s, owner):
    s.fault_gate()
    need(len(owner['queries']) == 1, 'one saved scoped query')
    query = owner['queries'][0]
    before = argument_bytes(dict(limits=owner['limits'], descriptor=owner['descriptor']))
    try:
        s.call('implicit', 'batch_diagnostic_closed_query', [], lambda: query(('count', (None, None, None, None))))
    except BaseException as error:
        s.fault_gate()
        owner['errors'].append(error)
        module = s.modules['implicit']
        need(s.call('implicit', 'is_own_invalid', [], lambda: module.is_own_invalid(error)) is True,
             'closed scope refuses by private owned Invalid')
        need(error.reason == 'query outside active profile lifetime', 'exact closed lifetime reason')
    else:
        need(False, 'closed scope query must refuse')
    need(argument_bytes(dict(limits=owner['limits'], descriptor=owner['descriptor'])) == before,
         'closed query cannot mutate profile inputs')


def _batch_diag_owner_result(s, owner):
    s.fault_gate()
    state = owner['lifetimes'][0] if owner['lifetimes'] else None
    return dict(profile_admitted=owner['profile_admitted'], custody_success=owner['custody_success'],
        planned_trigger_fired=owner['trigger_fired'],
        exact_primary_identity=None if owner['foreign'] is None else owner['thrown'] is owner['foreign'],
        thrown=_batch_diag_plain(s,owner['thrown'],owner['nonliteral_owners']),
        events=owner['events'][:], checkpoint_after_first=owner['checkpoint_after_first'],
        reference_receipts=_batch_diag_plain(s,owner.get('reference_receipts',[]),owner['nonliteral_owners']),
        callback_references=_batch_diag_plain(s,owner['callbacks'],owner['nonliteral_owners']),
        work_object_scalars=None if state is None or state['work'] is None else
            dict(work=state['work'].work,items=state['work'].items,limits=dict(state['work'].limits)),
        produced_receipt_count=None if state is None else state['produced_receipt_count'],
        preimage_completed_count=None if state is None else state['preimage_completed_count'],
        delivered_receipt_count=None if state is None else state['delivered_receipt_count'],
        ordinary_lifetime_projection=_batch_diag_plain(s, state, owner['nonliteral_owners']),
        ordinary_prefix_projection=_batch_diag_plain(s, owner.get('prefix'), owner['nonliteral_owners']),
        result=_batch_diag_plain(s, owner['result'], owner['nonliteral_owners']),
        callbacks_and_nonliteral_owners_retained=True,
        nonliteral_projection_scope='Bounded type/reference metadata only; original objects retained, not reconstructed.')


def _batch_diag_summary(s, group, variant):
    """Pure scalar record-builder coverage; no writer or filesystem invocation."""
    p = variant['parameters']
    class Carrier:
        pass
    class Hostile(Exception):
        def __str__(self):
            raise RuntimeError('summary must not render exceptions')
    class Untouched:
        def __iter__(self):
            raise RuntimeError('summary must not traverse subject prefixes')
        def __str__(self):
            raise RuntimeError('summary must not render subject prefixes')
    fake = Carrier()
    fake.active = 'active'; fake.rows = []; fake.plan = {}; fake.plan_pin = {}
    fake.stage = 'SUMMARY_TEST'; fake.first_fault = None
    fake.work_deadline = 10; fake.overall_deadline = 20; fake.root_calls = 0
    fake.started = {}; fake.completed = {}; fake.raised = {}
    fake.component_rows = []; fake.diagnostics = []; fake.retained = []; fake.output_pins = []
    primary = Hostile('literal summary detail')
    owner = dict(fake=fake, primary=primary, constructors=[Carrier, Hostile, Untouched])
    s.batch_diagnostic_owners.append(owner)
    if group['recipe'] == 'summary-hostile':
        primary.subject_prefix = Untouched()
    elif group['recipe'] == 'summary-scalar':
        value = {'bool': True, 'negative': -1, 'huge': 1 << 200, 'unavailable': Untouched()}[p['value']]
        fake.root_calls = value; fake.work_deadline = value; fake.overall_deadline = value
    elif group['recipe'] == 'summary-counter-caps':
        fake.started = {('x' * 49 + str(i)): i for i in range(17)}
        fake.completed = {'bool': True, 'negative': -1, 'huge': 1 << 200, 'ok': 7}
        fake.raised = None
    elif group['recipe'] == 'summary-active-metadata':
        fake.first_fault = primary
        fake.stage = 's' * 65
        fake.plan = dict(invocation_id='i' * 257)
        fake.plan_pin = dict(sha256='h' * 65)
        fake.rows = [dict(id='l' * 97)]
        if p['active'] == 'string':
            fake.active = 'a' * 97
        else:
            fake.active = dict(id='a' * 97, stage='r' * 65, subject_prefix=Untouched())
        primary.args = (Untouched(),)
    else:
        need(False, 'literal scalar summary recipe')
    s.guard(); s.fault_gate()
    record = s.call('worker', 'failure_summary_record_diagnostic', dict(group=group['id'], variant=variant['id']),
                    lambda: _failure_summary_record(fake, primary))
    s.fault_gate()
    need(record['authority'] is False and record['mathematical_authority'] is False and
         record['resource_accepted'] is False and record['full_pipeline_qualified'] is False and
         record['no_failed_prefix_admission'] is True, 'scalar metadata has no proof or admission authority')
    need(record['first_available_fault']['message_evaluated'] is False, 'exception str never requested')
    if group['recipe'] == 'summary-hostile':
        need(record['first_available_fault']['literal_first_argument'] ==
             dict(value='literal summary detail', available=True, truncated=False), 'literal first arg survives without rendering')
    elif group['recipe'] == 'summary-scalar':
        need(record['root_check_calls'] is None and record['work_deadline_ns'] is None and
             record['overall_deadline_ns'] is None, 'bool negative huge unavailable are not fabricated counters')
    elif group['recipe'] == 'summary-counter-caps':
        counts = record['call_started']
        need(counts['available'] is True and counts['total_entries'] == 17 and counts['truncated'] is True and
             len(counts['rows']) == 16 and all(len(r[0]['value']) == 48 and r[0]['truncated'] is True for r in counts['rows']),
             'exact first16 capped labels retained with total/truncation metadata')
        need([r[1] for r in record['call_completed']['rows']] == [None, None, None, 7] and
             record['call_raised']['available'] is False, 'invalid counts unavailable, exact valid count remains')
    else:
        need(record['first_available_fault']['origin'] == 'ROOT_FIRST_FAULT_LATCH' and
             record['first_available_fault']['literal_first_argument']['available'] is False,
             'first-fault origin and unavailable nonstring argument')
        for key in ('invocation_id', 'plan_sha256', 'stage', 'active_row_id', 'last_completed_case_id'):
            need(record[key]['truncated'] is True, 'declared scalar text cap')
        if p['active'] == 'dict':
            need(record['active_row_stage']['truncated'] is True, 'dictionary active stage capped')
    owner['record'] = record
    return dict(id=variant['id'], status='PASSED', complete=True, expected=variant['expected'], record=record,
                writer_invoked=False, filesystem_persistence_tested=False)


def run_new_diagnostics(s, bank):
    """Separate predeclared diagnostic cohort; never edits old33 diagnostics."""
    need(type(bank) is dict and set(bank) == {'schema','status','original_bank','descriptor_from_original_id',
         'tuple_codec','groups','coverage_scope','source_only','actual_execution_authorized'}, 'exact new diagnostic bank keys')
    need(bank['schema'] == 'implicit-batch-summary-diagnostics-v1' and bank['source_only'] is True and
         bank['actual_execution_authorized'] is False, 'ordinary bank gives no execution authority')
    need(bank['descriptor_from_original_id'] == 'minimal_descriptor' and bank['tuple_codec'] == 'recursive-original-JSON-lists-to-exact-tuples-v1',
         'declared original descriptor codec')
    need(type(bank['groups']) is list and len(bank['groups']) == 28 and len({g['id'] for g in bank['groups']}) == 28,
         'complete declared 24batch plus4summary groups')
    need(bank['original_bank'] == s.plan['inputs'][0]['pin'], 'new literal bank pins the complete original input descriptor')
    need(argument_bytes(s.batch_original_inputs) == s.batch_original_inputs_preimage, 'unchanged entire original input bank')
    desc = _batch_diag_immutable(s, s.batch_original_inputs['minimal_descriptor'])
    if not hasattr(s, 'batch_diagnostic_owners'):
        s.batch_diagnostic_owners = []
    need(type(s.batch_diagnostics) is list and not s.batch_diagnostics, 'fresh separate batch diagnostic results')
    previous_active = s.active
    s.batch_diagnostic_progress = dict(stage='RUNNING', active_group=None, active_variant=None,
                                      completed_group_ids=[], groups=[])
    for group in bank['groups']:
        s.check(); s.fault_gate()
        need(set(group) == {'id','subject','recipe','variants','source_reasoning'}, 'exact diagnostic group keys')
        progress = dict(id=group['id'], subject=group['subject'], recipe=group['recipe'],
                        stage='RUNNING', variants=[], active_runs=[])
        s.batch_diagnostic_progress['active_group'] = group['id']
        s.batch_diagnostic_progress['groups'].append(progress)
        for variant in group['variants']:
            need(set(variant) == {'id','parameters','trigger','expected'}, 'exact diagnostic variant keys')
            s.batch_diagnostic_progress['active_variant'] = variant['id']
            s.active = variant['id']
            if group['subject'] == 'scalar-summary-builder':
                row = _batch_diag_summary(s, group, variant)
            else:
                recipe = group['recipe']; p = variant['parameters']; runs = []
                if recipe in ('work-cumulative', 'receipt-items-cumulative'):
                    baseline = _batch_diag_profile(s, desc, {}, 'cumulative-baseline', variant['id'] + ':baseline')
                    runs.append(baseline)
                    need(baseline['result'] is not None, 'full two-query calibration before derived cumulative quota')
                    point = baseline['checkpoint_after_first']
                    limit = {'work': point['work'] + 1} if recipe == 'work-cumulative' else {'receipt_items': point['receipt_items'] + 1}
                elif recipe == 'queries-cumulative':
                    limit = {'queries': 1}
                else:
                    limit = None
                owner = _batch_diag_profile(s, desc, p, recipe, variant['id'], limit)
                runs.append(owner)
                progress['active_runs'] = [_batch_diag_owner_result(s, x) for x in runs]
                s.fault_gate()
                error = owner['thrown']; module = s.modules['implicit']
                if recipe in ('ordered-positive', 'static-positive', 'closed-success'):
                    need(error is None and owner['result'] is not None, 'complete positive diagnostic profile')
                    state = owner['lifetimes'][0]
                    expected_count = 3 if recipe in ('ordered-positive', 'static-positive') else 1
                    need(state['produced_receipt_count'] == expected_count and state['preimage_completed_count'] == expected_count and
                         state['delivered_receipt_count'] == expected_count, 'positive produced/preimage/delivery census')
                    if expected_count == 3:
                        receipts = owner['result']['receipts']
                        need([r['count'] for r in receipts] == [190,190,0] and receipts[1]['tile']['kind'] == 'step',
                             'ordered complete palette counts, select tile and explicit assignedzero mask')
                        reference = []
                        for name, args in (('count_query',[desc,(None,None,None,None)]),
                                           ('select_query',[desc,(None,None,None,None),0]),
                                           ('count_query',[desc,(0,None,None,None)])):
                            s.check()
                            receipt = s.call('implicit', 'batch_diagnostic_reference_' + name, args,
                                lambda name=name,args=args: getattr(module,name)(*args,check=s.check,limits=dict(IMPLICIT_LIMITS)))
                            account_palette_work(s,receipt['attempted_work']); s.fault_gate()
                            reference.append(receipt)
                        owner['reference_receipts'] = reference
                        for actual, expected in zip(receipts,reference):
                            a={k:v for k,v in actual.items() if k!='attempted_work'}
                            e={k:v for k,v in expected.items() if k!='attempted_work'}
                            need(argument_bytes(a)==argument_bytes(e), 'full strict typed ordered batch equals standalone legacy semantic receipts')
                    if recipe == 'closed-success':
                        _batch_diag_closed(s, owner)
                elif recipe in ('foreign-site','foreign-public-class','closed-failure','secondary-nonmasking'):
                    need(error is owner['foreign'], 'exact planned foreign primary identity preserved')
                    if recipe == 'foreign-public-class':
                        for predicate in ('is_own_invalid','is_own_limit'):
                            need(s.call('implicit',predicate,[],lambda predicate=predicate:getattr(module,predicate)(error)) is False,
                                 'same public class without private ownership is foreign')
                    if p.get('site') == 'first-receipt-tree':
                        state=owner['lifetimes'][0]; active=state['active_query']
                        need(state['produced_receipt_count']==1 and state['preimage_completed_count']==0 and state['delivered_receipt_count']==0,
                             'raw receipt retained before first typed-copy callback fault')
                        need(not state['receipts'] and active['produced_receipt'] is not None and active['produced_receipt']['tile']['kind']=='step' and
                             active['produced_preimage'] is None and active['preimage_complete'] is False and active['delivered'] is False,
                             'complete raw select tile survives first receipt-tree failure')
                    if recipe=='closed-failure':
                        _batch_diag_closed(s,owner)
                    if recipe=='secondary-nonmasking':
                        state=owner['lifetimes'][0]
                        need(state['custody_cleanup_exception'] is owner['secondary'] and state['custody_exit_completed'] is False,
                             'secondary custody exception retained and cannot mask primary')
                else:
                    need(error is not None,'declared refusal occurred')
                    predicate='is_own_limit' if recipe in ('work-cumulative','queries-cumulative','receipt-items-cumulative') else 'is_own_invalid'
                    need(s.call('implicit',predicate,[],lambda:getattr(module,predicate)(error)) is True,'exact private-owned diagnostic refusal')
                    if recipe in ('work-cumulative','queries-cumulative','receipt-items-cumulative'):
                        reason={'work-cumulative':'work','queries-cumulative':'queries','receipt-items-cumulative':'receipt_items'}[recipe]
                        need(error.reason==reason,'declared cumulative unit refused')
                        state=owner['lifetimes'][0]
                        need(state['attempted_queries']==2 and state['delivered_receipt_count']==1,'quota remains cumulative after first completed query')
                    elif recipe=='swallowed-query' or recipe=='reentrant':
                        need(error is owner['foreign'] and owner['lifetimes'][0]['query_fault'] is error,
                             'exact first query fault survives swallowing or reentrancy')
                    elif recipe.startswith('mutation-'):
                        need(error.reason=='body changed exact query receipt','complete typed reconciliation detects mutation')
                    elif recipe=='custody-return':
                        need(error.reason=='custody callback must return None after verification','non-None custody return refuses')
                s.fault_gate()
                if error is not None:
                    need(owner['profile_admitted'] is False and owner['custody_success'] is False,
                         'expected sentinel establishes refusal only, no admitted profile/custody')
                row=dict(id=variant['id'],status='PASSED',complete=True,expected=variant['expected'],
                         runs=[_batch_diag_owner_result(s,x) for x in runs],
                         real_root_fault_gate_passed=True, inherited_outer_gates_unchanged=True)
            progress['variants'].append(row)
        completed=dict(id=group['id'],subject=group['subject'],recipe=group['recipe'],status='PASSED',complete=True,variants=progress['variants'])
        progress['stage']='COMPLETE'
        progress['active_runs']=[]
        s.batch_diagnostics.append(completed)
        s.batch_diagnostic_progress['completed_group_ids'].append(group['id'])
    s.batch_diagnostic_progress.update(stage='COMPLETE',active_group=None,active_variant=None)
    need(argument_bytes(s.batch_original_inputs)==s.batch_original_inputs_preimage,'old full bank unchanged after all new diagnostics')
    s.active = previous_active
    return s.batch_diagnostics
