"""Ordinary metadata only; preserve a literal-count predicate correction."""
import hashlib
import json
from pathlib import Path
D = Path(__file__).resolve().parent
source = D / 'freeze_recovered_source_reviews_v2.py'
raw = source.read_bytes()
value = dict(schema='reviewer-metadata-check-negative-v2', status='REVIEWER_PREDICATE_FALSE_POSITIVE',
    author_identity='/root/recovered_batch_review', source_only=True,
    failed_metadata_author=dict(path=str(source), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()),
    invocation_exit_code=1, failed_predicate='original210 checks and no positive grace',
    cause='Literal count expected3 occurrences of s.overall_deadline in the whole helper fragment. There are3 writer checks plus1 scalar record field, for4 total. No Source deadline change occurred.',
    subject_imports=0, subject_calls=0, helper_calls=0, semantic_replays=0,
    correction='New v3 metadata author counts the exact writer substring only; original helper Source remains unchanged.')
with (D / 'reviewer-metadata-negative-v2.json').open('xb') as output:
    output.write((json.dumps(value, sort_keys=True, indent=2) + '\n').encode())
candidate = raw.decode().replace("'recovered-batch-negative-preimage-v2.py'", "'recovered-batch-negative-preimage-v3.py'")
candidate = candidate.replace("'typed-recovered-batch-Source-negative-v2.json'", "'typed-recovered-batch-Source-negative-v3.json'")
candidate = candidate.replace("'typed-recovered-summary-first-Source-review-v2.json'", "'typed-recovered-summary-first-Source-review-v3.json'")
candidate = candidate.replace("'handoff-recovered-stage-v2.json'", "'handoff-recovered-stage-v3.json'")
candidate = candidate.replace("helper.count('s.overall_deadline') == 3", "helper[helper.index('def _write_failure_summary'):].count('s.overall_deadline') == 3")
with (D / 'freeze_recovered_source_reviews_v3.py').open('xb') as output:
    output.write(candidate.encode())
