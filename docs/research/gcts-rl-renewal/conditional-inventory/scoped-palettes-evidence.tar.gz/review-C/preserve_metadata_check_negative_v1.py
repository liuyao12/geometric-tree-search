"""Ordinary metadata, preserving a reviewer predicate correction."""
import hashlib
import json
from pathlib import Path
D = Path(__file__).resolve().parent
source = D / 'freeze_recovered_source_reviews_v1.py'
raw = source.read_bytes()
value = dict(schema='reviewer-metadata-check-negative-v1', status='REVIEWER_PREDICATE_FALSE_POSITIVE',
    author_identity='/root/recovered_batch_review', source_only=True,
    failed_metadata_author=dict(path=str(source), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()),
    invocation_exit_code=1,
    failed_predicate='no new Root/Source/subject replay routes',
    cause='Predicate rejected every str(...) call, including the writer ordinary pathname conversion str(temporary). The intended prohibition is arbitrary exception formatting str(primary)/repr(primary), which does not occur.',
    subject_imports=0, subject_calls=0, helper_calls=0, semantic_replays=0,
    earlier_batch_negative_remains_preserved=True,
    correction='New v2 metadata author narrows prohibited formatting to primary/error objects. Exact helper Source is unchanged. This failed metadata pass is not a helper failure or runtime evidence.')
with (D / 'reviewer-metadata-negative-v1.json').open('xb') as output:
    output.write((json.dumps(value, sort_keys=True, indent=2) + '\n').encode())
candidate = raw.decode().replace("'recovered-batch-negative-preimage.py'", "'recovered-batch-negative-preimage-v2.py'")
candidate = candidate.replace("'typed-recovered-batch-Source-negative-v1.json'", "'typed-recovered-batch-Source-negative-v2.json'")
candidate = candidate.replace("'typed-recovered-summary-first-Source-review-v1.json'", "'typed-recovered-summary-first-Source-review-v2.json'")
candidate = candidate.replace("'handoff-recovered-stage-v1.json'", "'handoff-recovered-stage-v2.json'")
candidate = candidate.replace("{'clone','canonical','information','str','repr','exec','eval','compile','__import__'}", "{'clone','canonical','information','repr','exec','eval','compile','__import__'}")
candidate = candidate.replace("    check('summary attempted before inherited failure construction and bulk',", "    check('no primary/error string rendering', not any(isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == 'str' and any(isinstance(a, ast.Name) and a.id in {'primary', 'error'} for a in n.args) for n in ast.walk(ht)))\n    check('summary attempted before inherited failure construction and bulk',")
with (D / 'freeze_recovered_source_reviews_v2.py').open('xb') as output:
    output.write(candidate.encode())
