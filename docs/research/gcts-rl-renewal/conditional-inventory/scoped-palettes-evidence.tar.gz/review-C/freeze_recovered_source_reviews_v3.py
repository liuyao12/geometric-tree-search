"""Independent raw/AST metadata only; never import or call reviewed programs."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import sys

D = Path(__file__).resolve().parent.parent
O = Path(__file__).resolve().parent
R = D / 'recovered'
PYTHON = Path('/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12')


def pin(path):
    raw = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def save(name, value):
    raw = (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=True) + '\n').encode()
    path = O / name
    with path.open('xb') as output:
        output.write(raw)
    return pin(path)


def main():
    assert sys.version_info[:3] == (3, 12, 14)
    assert pin(PYTHON)['sha256'] == 'b6ea0c2a9bfce48dbf181a53f1ca4f0562d40658b85bf47258e2a88d8f9e3933'
    master = D / 'publisher/docs/basic-tiling-algorithm.md'
    assert pin(master)['sha256'] == 'ca6ee206287bf18b69f88a35d30968312499567755f347a819af4cf49743e7d4'
    assert pin(master)['bytes'] == 36240
    recovery = json.loads((D / 'recovery-manifest.json').read_bytes())
    assert recovery['archive_sha256'] == 'e63809c5b9760981714ad44eee29e280738728071717431ee7e98be277f1ee58'
    recovered = {row['name']: row for row in recovery['members']}
    names = ['future-B/implicit_wang_batch_v1.py', 'future-L/summary_helpers.fragment.py',
             'future-L/qualify_implicit_worker_v2_summary_first.py', 'ROOT/qualify_implicit_worker_v1.py',
             'ROOT/run_implicit_once_v1.py', 'future-L/parent-to-summary-first.patch',
             'future-L/summary-first-to-parent.patch']
    checks = []
    def check(label, ok, detail=None):
        checks.append(dict(label=label, passed=bool(ok), detail=detail))
        assert ok, label
    for name in names:
        found = pin(R / name)
        expected = recovered[name]
        check('recovered raw pin: ' + name,
              found['bytes'] == expected['bytes'] and found['sha256'] == expected['sha256'])
    paths = {name: R / name for name in names}
    sources = {name: path.read_text() for name, path in paths.items() if name.endswith('.py')}
    trees = {}
    for name, source in sources.items():
        trees[name] = ast.parse(source, filename=str(paths[name]))
        # Returned code objects remain unused and are never evaluated.
        compile(trees[name], str(paths[name]), 'exec', dont_inherit=True, optimize=0)
        check('AST and unused compile: ' + name, True)
    batch = sources['future-B/implicit_wang_batch_v1.py']
    check('receipt constructed before callback-capable preimage traversal',
          batch.index("receipt = dict(schema='implicit-wang-select-receipt-v1'") <
          batch.index('expected = _receipt_tree(receipt, state)') <
          batch.index("state['receipts'].append(receipt)"))
    check('active query lacks produced raw receipt',
          "request=request, stage='VALIDATING',\n                                        start_work=work.work, delivered=False)" in batch)
    check('receipt tree callback precedes first output retention',
          "action, item, depth = pending.pop()\n        work.tick()" in batch)
    check('failure prefix retains no local raw receipt',
          "descriptor=descriptor, active_query=state['active_query']" in batch and
          "completed_receipts=tuple(state['receipts'])" in batch)
    with (O / 'recovered-batch-negative-preimage-v3.py').open('xb') as output:
        output.write((R / names[0]).read_bytes())
    common = dict(author_identity='/root/recovered_batch_review', source_only=True,
                  actual_execution_authorized=False, runtime_qualified=False,
                  subject_imports=0, subject_function_calls=0, helper_calls=0,
                  fixture_calls=0, driver_calls=0, checker_calls=0,
                  compiler_calls=0, semantic_replays=0,
                  authority=False, mathematical_authority=False,
                  current_tracked_master=pin(master), recovery_manifest=pin(D / 'recovery-manifest.json'),
                  pinned_python=pin(PYTHON), parser_version=sys.version,
                  AST_policy='ast.dump(include_attributes=False); pinned CPython3.12.14; unused code objects only',
                  static_metadata_author=pin(Path(__file__)))
    negative = dict(common, schema='independent-recovered-batch-Source-negative-review-v1',
        status='SOURCE_NEGATIVE_NOT_RUNTIME_QUALIFIED', reviewed_source=pin(R / names[0]),
        preserved_preimage=pin(O / 'recovered-batch-negative-preimage-v3.py'),
        blocking_findings=[dict(id='PRODUCED_RECEIPT_LOST_BEFORE_TYPED_PREIMAGE', severity='blocking',
            source_lines=[719, 720, 721, 722, 723, 725, 726],
            trigger='Any foreign callback, own work/data/depth/string/integer/receipt_items failure during _receipt_tree after receipt creation and before receipts.append.',
            observation='The full count/select receipt and selected tile exist in local receipt only. active_query retains ordinal/request/stage/start_work/delivered but no rawreceipt; completed_receipts only reflects earlier appends. Exception stack retention is not a declared full-prefix carrier.',
            consequence='A produced full receipt can disappear from the registered lifetime and attached prefix. No failed-profile or selected-tile evidence may be admitted.',
            required_delta='Synchronously retain full rawreceipt in registered active_query before the first callback-capable preimage operation; separately expose produced, preimage-complete and delivered counters, including partial fault stages.')],
        nonclaims=['No callback/limit fixture was executed.', 'No old unavailable negative receipt is adopted as a current file.',
                   'Recovered original input bank and failed partial bytes are unchanged; failed partial content was never decoded.'],
        mechanical_checks=checks.copy())
    negative_pin = save('typed-recovered-batch-Source-negative-v3.json', negative)

    parent = sources['ROOT/qualify_implicit_worker_v1.py']
    candidate = sources['future-L/qualify_implicit_worker_v2_summary_first.py']
    helper = sources['future-L/summary_helpers.fragment.py']
    old_version = "VERSION = 'complete-implicit-palette-point-graph-worker-v1'"
    new_version = "VERSION = 'complete-implicit-palette-point-graph-worker-v2-summary-first'"
    seam = '        primary=s.first_fault if s.first_fault is not None else error\n'
    added = ("        early_summary = None\n"
             "        try:\n"
             "            early_summary = _write_failure_summary(s, _failure_summary_record(s, primary))\n"
             "        except BaseException:\n"
             "            pass  # Metadata-only attempt cannot change the selected primary fault.\n")
    update = "        failure.update(subject_prefix=getattr(primary,'implicit_palette_prefix',None),graph_prefix=getattr(primary,'implicit_search_prefix',None))\n"
    extra = "        failure['early_failure_summary'] = early_summary\n"
    check('raw helper inserted once', candidate.count(helper + '\n\nclass Session:\n') == 1)
    inverse = candidate.replace(new_version, old_version, 1)
    inverse = inverse.replace(helper + '\n\nclass Session:\n', 'class Session:\n', 1)
    inverse = inverse.replace(seam + added, seam, 1).replace(update + extra, update, 1)
    check('exact raw inverse to recovered parent', inverse == parent)
    expected = parent.replace(old_version, new_version, 1).replace('class Session:\n', helper + '\n\nclass Session:\n', 1)
    expected = expected.replace(seam, seam + added, 1).replace(update, update + extra, 1)
    check('exact forward construction', expected == candidate)
    for direction, before, after, a, b in [
        ('forward', parent, candidate, '/private/tmp/gcts-implicit-ROOT-20261020-v1/qualify_implicit_worker_v1.py', '/private/tmp/gcts-implicit-retention-L-20261020-v1/qualify_implicit_worker_v2_summary_first.py'),
        ('inverse', candidate, parent, '/private/tmp/gcts-implicit-retention-L-20261020-v1/qualify_implicit_worker_v2_summary_first.py', '/private/tmp/gcts-implicit-ROOT-20261020-v1/qualify_implicit_worker_v1.py')]:
        patch_name = 'future-L/parent-to-summary-first.patch' if direction == 'forward' else 'future-L/summary-first-to-parent.patch'
        expected_patch = ''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True), fromfile=a, tofile=b))
        check('exact saved raw ' + direction + ' patch', expected_patch.encode() == (R / patch_name).read_bytes())
    old_defs = {n.name: n for n in trees['ROOT/qualify_implicit_worker_v1.py'].body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}
    new_defs = {n.name: n for n in trees['future-L/qualify_implicit_worker_v2_summary_first.py'].body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}
    for name, node in old_defs.items():
        if name != 'main':
            check('unchanged AST definition: ' + name,
                  ast.dump(node, include_attributes=False) == ast.dump(new_defs[name], include_attributes=False))
    imports = lambda tree: [ast.dump(n, include_attributes=False) for n in tree.body if isinstance(n, (ast.Import, ast.ImportFrom))]
    check('import census unchanged', imports(trees['ROOT/qualify_implicit_worker_v1.py']) == imports(trees['future-L/qualify_implicit_worker_v2_summary_first.py']))
    ht = trees['future-L/summary_helpers.fragment.py']
    check('no generator/yield in helpers', not any(isinstance(n, (ast.GeneratorExp, ast.Yield, ast.YieldFrom)) for n in ast.walk(ht)))
    helper_names = {n.name for n in ht.body if isinstance(n, ast.FunctionDef)}
    check('exact six helper functions', helper_names == {'_summary_uint', '_summary_text', '_summary_length', '_summary_counters', '_failure_summary_record', '_write_failure_summary'})
    check('no new Root/Source/subject replay routes', not any(
        isinstance(n, ast.Call) and ((isinstance(n.func, ast.Attribute) and n.func.attr in {'check','guard','call','load','policy','write_json'}) or
        (isinstance(n.func, ast.Name) and n.func.id in {'clone','canonical','information','repr','exec','eval','compile','__import__'}))
        for n in ast.walk(ht)))
    check('no primary/error string rendering', not any(isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == 'str' and any(isinstance(a, ast.Name) and a.id in {'primary', 'error'} for a in n.args) for n in ast.walk(ht)))
    check('summary attempted before inherited failure construction and bulk',
          candidate.index(seam + added) < candidate.index("failure=dict(schema='implicit-palette-graph-worker-failure-v1'") <
          candidate.index("prefix=s.write_json('failed-prefix.json'"))
    check('unchanged original primary selection', candidate.count(seam) == parent.count(seam) == 1)
    check('no helper assignment to first_fault', not any(isinstance(n, ast.Attribute) and isinstance(n.ctx, ast.Store) and n.attr == 'first_fault' for n in ast.walk(ht)))
    check('hard producer/write caps explicit',
          'FAILURE_SUMMARY_BYTES = 65536' in helper and 'FAILURE_SUMMARY_COUNTER_ROWS = 16' in helper and
          'FAILURE_SUMMARY_DIRECTORY_ENTRIES = 64' in helper and 'if len(raw) > FAILURE_SUMMARY_BYTES:' in helper)
    check('original total physical cap/reserve check before write',
          "if prior + len(raw) + RESERVE_BYTES > OUTER_LIMITS['result_bytes']:" in helper and
          helper.index("if prior + len(raw) + RESERVE_BYTES") < helper.index('fd = os.open'))
    check('exclusive nofollow/create/fsync/rename sequence',
          'os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW' in helper and
          helper.index('os.fsync(output.fileno())') < helper.index('os.rename(temporary, path)'))
    check('original210 checks and no positive grace',
          helper[helper.index('def _write_failure_summary'):].count('s.overall_deadline') == 3 and 's.work_deadline' in helper and
          'No success gate is consulted' in helper and 'never a guaranteed grace period' in helper)
    check('negative-only fields in record', all(x in helper for x in [
          'authority=False, mathematical_authority=False, resource_accepted=False',
          'full_pipeline_qualified=False, no_failed_prefix_admission=True']))
    variable_caps = dict(invocation_id=256, plan_sha256=64, stage=64, active_row_id=96,
                         active_row_stage=64, fault_type=128, literal_first_argument=256,
                         last_completed_case_id=96)
    check('all noncounter variable text at most1024characters', sum(variable_caps.values()) == 1024)
    bound = 3 * 16 * (48 * 12 + 128) + 1024 * 12 + 8192
    check('conservative compact ASCII producer bound within64KiB', bound == 54272 and bound < 65536)
    summary = dict(common, schema='independent-recovered-summary-first-Source-review-v1',
        status='PASS_SOURCE_ONLY_FUTURE_NOT_GRANTED', reviewed_source=pin(R / 'future-L/qualify_implicit_worker_v2_summary_first.py'),
        helper=pin(R / 'future-L/summary_helpers.fragment.py'), parent_source=pin(R / 'ROOT/qualify_implicit_worker_v1.py'),
        unchanged_runner=pin(R / 'ROOT/run_implicit_once_v1.py'),
        raw_exact_forward_and_inverse=True,
        import_census_unchanged=True, unused_compile_count=len(trees),
        manual_findings=[
            'The selected primary is the existing Root first-fault latch if present; summary construction and write are guarded by a new bare BaseException catch which performs no assignment to the primary/latch.',
            'All inherited non-main function/class ASTs, including Session.check/call/write_json, are unchanged. Main only changes VERSION-related output value, inserts the guarded summary attempt, and later attaches its optional descriptor.',
            'The bounded producer reads owned plain scalar/carrier metadata. It never formats the exception, visits subject failure-prefix contents, clones active state, runs a checker, or calls Root.check after failure.',
            'Three counter maps retain at most16 insertion-order rows and48characters per label. Other strings cap at1024totalcharacters. Exact int63 checks bound integers; unknown/nonexact values become explicit nulls. Source-derived ensure_ascii upperbound54272bytes includes conservative fixed/row overhead; writer separately rejects body-plus-LF above65536.',
            'Writer observes at most64 actual-directory entries, rejects nonregular files, checks current sizes+summary+original9MiBreserve against128MiB, creates nofollow/exclusive partial once, flushes/fsyncs, and publishes by rename only with original210s observations. Private exclusive directory is assumed; no hostile-race or universal crash durability claim.',
            'Parent remains free to TERM at180; no210s grace or successful failure-summary persistence is promised. Every summary field is negative-only and is not a complete prefix or mathematical/resource acceptance record.',
            'Later inherited bulk retention may fail independently; this Source ordering improves observability only if reached and committed. No observed improvement, bottleneck diagnosis, or runtime success follows from this receipt.'
        ],
        producer_bound=dict(counter_maps=3, rows_each=16, label_chars=48,
                            other_text_caps=variable_caps, maximum_ascii_bytes_per_character=12,
                            per_row_other_bytes=128, fixed_overhead_bytes=8192,
                            upper_bound_bytes=bound, hard_body_plus_LF_cap_bytes=65536),
        mechanical_checks=checks.copy(),
        failed_checks=0,
        inherited_batch_negative=negative_pin,
        pending='Fresh integrated worker/closure/intake/plan/full prospective review and exact once-grant; no runtime authority from this receipt.',
        unavailable_historical_receipts_not_resurrected=['d21fc8…', '86b5…'])
    summary_pin = save('typed-recovered-summary-first-Source-review-v3.json', summary)
    handoff = save('handoff-recovered-stage-v3.json', dict(common,
        schema='independent-recovered-static-stage-handoff-v1',
        status='FROZEN_SOURCE_REVIEWS_ONLY', batch_negative=negative_pin,
        summary_review=summary_pin, checks=len(checks), failed_checks=0,
        tools_stop_after_handoff=True, final_review_requires_frozen_integrated_offer=True))
    print(json.dumps(dict(batch_negative=negative_pin, summary_review=summary_pin, handoff=handoff, checks=len(checks)), sort_keys=True))


if __name__ == '__main__':
    main()
