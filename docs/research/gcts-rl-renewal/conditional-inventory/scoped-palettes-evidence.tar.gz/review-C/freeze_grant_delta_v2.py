"""Raw JSON/hash custody only; no Source import/call or semantic replay."""
import hashlib
import json
from pathlib import Path

D = Path(__file__).resolve().parent.parent
O = Path(__file__).resolve().parent
R = D / 'root'


def pin(path):
    raw = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def read(value):
    path = Path(value['path'])
    assert path.is_absolute() and path.resolve() == path and path.is_file() and not path.is_symlink()
    assert pin(path) == value
    return path.read_bytes()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False).encode()


def main():
    checks = []
    def check(label, condition):
        checks.append(dict(label=label, passed=bool(condition)))
        assert condition, label
    review_path = O / 'typed-complete-batch-Source-prospective-review-v2.json'
    review_pin = pin(review_path)
    check('exact whole Source review preserved', review_pin['sha256'] == 'ffb0fca9b2628b470cf4f635b64b24b114fe41675be283d7d7f036da47f0b0d5')
    review = json.loads(review_path.read_bytes())
    check('independent explicit current PASS', review['schema'] == 'wang-encoding-Source-prospective-review-v1' and review['reviewer_identity'] == '/root/recovered_batch_review' and review['review_passed'] is True and review['source_only'] is True and review['component_calls'] == 0 and review['actual_execution_authorized'] is False)
    check('whole manual and mechanical review complete', len(review['mechanical_checks']) == 172 and review['failed_checks'] == [] and all(row['passed'] is True for row in review['mechanical_checks']) and len(review['manual_Source_findings']) == 14)
    offer = json.loads(read(review['offer']))
    prospective = json.loads(read(offer['prospective_plan']))
    plan_path = R / 'batch-plan-authorized-v2.json'
    plan_pin = pin(plan_path)
    check('exact authorized plan pin', plan_pin['sha256'] == '5ad547859e7a1092a36e9f715c9cf521aeb8748f0aba3f34248b15bd1705d378' and plan_pin['bytes'] == 3562)
    plan = json.loads(plan_path.read_bytes())
    check('authorization only plan-field delta', set(plan) == set(prospective) and [k for k in plan if plan[k] != prospective[k]] == ['authorization'])
    subject = {k:v for k,v in plan.items() if k != 'authorization'}
    check('unchanged full reviewed subject', subject == review['subject'] == offer['subject'])
    subject_sha = hashlib.sha256(canonical(subject)).hexdigest()
    check('unchanged exact subject digest', subject_sha == review['subject_sha256'] == '5c41ecdc77f6f88296614dff482c6187de13301a178c745a6b12e903de66467c')
    auth = json.loads(read(plan['authorization']))
    check('exact fresh once authorization pin', plan['authorization']['sha256'] == '912e15bd8e88451f1a157b292edff34fe0a4a29e1ff89395983ebdffaa03c1c1' and plan['authorization']['bytes'] == 885)
    check('exact grant fields and Root author', set(auth) == {'schema','author_identity','actual_execution_authorized','maximum_actual_invocations','subject_sha256','review','scope'} and auth['schema'] == 'ROOT-wang-encoding-authorization-v1' and auth['author_identity'] == '/root')
    check('exact true maximum1 and subject', auth['actual_execution_authorized'] is True and type(auth['maximum_actual_invocations']) is int and auth['maximum_actual_invocations'] == 1 and auth['subject_sha256'] == subject_sha)
    check('grant pins exact separate full review', auth['review'] == review_pin)
    issuance_path = R / 'ROOT-grant-issuance-v2.json'
    issuance_pin = pin(issuance_path)
    check('exact issuance raw pin', issuance_pin['sha256'] == 'c0875bce59eb846944ce2331295aac9d488f0c114d683fbdda241f1c560f5e61')
    closure = json.loads(read(subject['runtime_closure']))
    all_pins = [('python',subject['python']),('declaration',subject['declaration']),('runtime_closure',subject['runtime_closure'])]
    all_pins += [('Source-' + role,value) for role,value in subject['sources'].items()]
    all_pins += [('input-' + str(i),value['pin']) for i,value in enumerate(subject['inputs'])]
    all_pins += [('stdlib-' + str(i),value) for i,value in enumerate(closure['stdlib_files'])]
    for label,value in all_pins:
        read(value)
        check('current exact complete raw custody: ' + label, True)
    check('closure subjects unchanged', closure['sources'] == subject['sources'] and closure['python'] == subject['python'] and closure['declaration'] == subject['declaration'])
    actual = Path(subject['actual_directory'])
    observation = plan_path.parent / (plan_path.stem + '-terminal-observation')
    check('fresh actual absent', not actual.exists() and actual.is_absolute() and actual.resolve() == actual)
    check('fresh authorized observation folder absent', not observation.exists())
    check('prospective false authorization not overwritten', json.loads(read(offer['false_authorization']))['actual_execution_authorized'] is False)
    receipt = dict(schema='independent-complete-batch-final-grant-delta-review-v2',
        reviewer_identity='/root/recovered_batch_review', review_passed=True,
        source_only=True, component_calls=0, actual_execution_authorized=False,
        subject_imports=0, helper_calls=0, fixture_calls=0, semantic_replays=0,
        compiler_calls=0, checker_calls=0, Source_or_AST_execution=False,
        full_Source_review=review_pin, authorized_plan=plan_pin,
        authorization=plan['authorization'], Root_issuance=issuance_pin,
        subject=subject, subject_sha256=subject_sha, mechanical_checks=checks,
        failed_checks=0, actual_absent=True, authorized_observation_absent=True,
        status='PASS_GRANT_ONLY_DELTA_SOURCE_CUSTODY_NOT_EXPERIMENT_RESULT',
        scope='Only authorization pin changed. Exact already reviewed6Sources/2banks/declaration/closure/current Python and all declared stdlib raw pins rechecked. No subject/helper/fixture import, call, sizing, warmup, simulation or replay. This review does not issue an additional grant, establish runtime/resource/mathematical acceptance, or permit a repeat.',
        required_next='Root final all-peers-idle/current-raw/fresh-path barrier, then Root may consume the single exact existing grant. Any failure leaves all historical/current failed prefixes unadmitted.',
        tools_stopped_after_this_receipt=True,
        metadata_author=pin(Path(__file__)))
    path = O / 'typed-complete-batch-final-grant-delta-review-v2.json'
    with path.open('xb') as output:
        output.write((json.dumps(receipt, sort_keys=True, indent=2, ensure_ascii=True) + '\n').encode())
    print(json.dumps(dict(receipt=pin(path), checks=len(checks), review_passed=True, tools_stop=True), sort_keys=True))


if __name__ == '__main__':
    main()
