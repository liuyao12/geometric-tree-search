"""Passive saved JSON/raw bytes only. Partial JSON is NEVER decoded."""
import hashlib
import json
from pathlib import Path
import stat

D = Path(__file__).resolve().parent.parent
O = Path(__file__).resolve().parent
R = D / 'root'


def pin(path):
    path = Path(path)
    before = path.stat()
    assert stat.S_ISREG(before.st_mode) and not path.is_symlink()
    digest = hashlib.sha256()
    count = 0
    # Streaming raw hashing only; no partial-file parser, projector or decoder.
    with path.open('rb') as source:
        while True:
            raw = source.read(1048576)
            if not raw:
                break
            count += len(raw)
            digest.update(raw)
    after = path.stat()
    assert (before.st_size,before.st_mtime_ns,before.st_ino) == (after.st_size,after.st_mtime_ns,after.st_ino)
    assert count == after.st_size
    return dict(path=str(path.resolve()), bytes=count, sha256=digest.hexdigest())


def read(value):
    path = Path(value['path'])
    assert path.is_absolute() and path.resolve() == path and pin(path) == value
    return path.read_bytes()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False).encode()


def saved_json(path):
    assert path.suffix == '.json' and not path.name.endswith('.partial')
    raw = path.read_bytes()
    assert raw.endswith(b'\n')
    return json.loads(raw)


def main():
    checks = []
    def check(label, condition, detail=None):
        checks.append(dict(label=label, passed=bool(condition), detail=detail))
        assert condition, label
    plan_path = R / 'batch-plan-authorized-v2.json'
    plan_pin = pin(plan_path)
    check('exact authorized once-plan', plan_pin['sha256'] == '5ad547859e7a1092a36e9f715c9cf521aeb8748f0aba3f34248b15bd1705d378' and plan_pin['bytes'] == 3562)
    plan = saved_json(plan_path)
    subject = {k:v for k,v in plan.items() if k != 'authorization'}
    subject_sha = hashlib.sha256(canonical(subject)).hexdigest()
    check('exact reviewed subject', subject_sha == '5c41ecdc77f6f88296614dff482c6187de13301a178c745a6b12e903de66467c')
    auth = json.loads(read(plan['authorization']))
    check('exact existing max-one Root authorization', plan['authorization']['sha256'] == '912e15bd8e88451f1a157b292edff34fe0a4a29e1ff89395983ebdffaa03c1c1' and auth['author_identity'] == '/root' and auth['actual_execution_authorized'] is True and type(auth['maximum_actual_invocations']) is int and auth['maximum_actual_invocations'] == 1 and auth['subject_sha256'] == subject_sha)
    review = json.loads(read(auth['review']))
    check('exact full prior Source review join', auth['review']['sha256'] == 'ffb0fca9b2628b470cf4f635b64b24b114fe41675be283d7d7f036da47f0b0d5' and review['review_passed'] is True and review['subject'] == subject and review['component_calls'] == 0)
    A = Path(plan['actual_directory'])
    T = R / 'batch-plan-authorized-v2-terminal-observation'
    expected_actual = {'CONSUMED.json','WORKER_CONSUMED.json','canonical-implicit-palette-calibration.json.partial',
                       'failed-prefix.json.partial','runner-receipt.json','stderr.bin','stdout.bin','worker-failure.json'}
    expected_observer = {'CONSUMED.json','stderr.bin','stdout.bin','terminal.json'}
    check('exact saved8-file actual root', A.is_dir() and {p.name for p in A.iterdir()} == expected_actual)
    check('exact saved4-file observer root', T.is_dir() and {p.name for p in T.iterdir()} == expected_observer)
    raw_manifest = []
    for folder, category in [(A,'actual'),(T,'observer')]:
        for path in sorted(folder.iterdir()):
            value = pin(path)
            raw_manifest.append(dict(category=category, name=path.name, pin=value,
                custody='RAW_BYTES_HASH_ONLY_NEVER_DECODED' if path.name.endswith('.partial') else 'COMPLETE_SAVED_BYTES'))
            check('stable regular raw file: ' + category + '/' + path.name, True)
    manifest_by_name = {(row['category'],row['name']):row['pin'] for row in raw_manifest}
    partial_pin = manifest_by_name['actual','canonical-implicit-palette-calibration.json.partial']
    check('canonical partial raw pin and size', partial_pin['bytes'] == 124780541 and partial_pin['sha256'].startswith('49baf9'))
    check('failed-prefix partial is empty raw artifact', manifest_by_name['actual','failed-prefix.json.partial']['bytes'] == 0)
    check('complete worker-failure raw pin and size', manifest_by_name['actual','worker-failure.json']['bytes'] == 513516 and manifest_by_name['actual','worker-failure.json']['sha256'].startswith('081ce0'))
    check('complete runner raw pin', manifest_by_name['actual','runner-receipt.json']['sha256'] == 'bd2dd0c76e057534ea27888832459dc843e12f32e531d739f3e6bc02eb09e0db')
    consumed = saved_json(A/'CONSUMED.json')
    worker_consumed = saved_json(A/'WORKER_CONSUMED.json')
    runner = saved_json(A/'runner-receipt.json')
    failure = saved_json(A/'worker-failure.json')
    terminal = saved_json(T/'terminal.json')
    observer_consumed = saved_json(T/'CONSUMED.json')
    check('one worker consumption marker and same plan', consumed['schema'] == 'wang-encoding-qualification-consumed-v1' and consumed['maximum_worker_launches'] == 1 and consumed['consumed_before_Popen'] is True and consumed['plan'] == plan_pin and consumed['subject_sha256'] == subject_sha)
    check('one worker launch and one observer runner launch', runner['worker_launch_attempts'] == 1 and worker_consumed['maximum_invocations'] == 1 and observer_consumed['maximum_runner_launches'] == 1)
    check('all saved plan joins exact', all(value['plan'] == plan_pin for value in [worker_consumed,runner,failure,terminal,observer_consumed]))
    check('all saved invocation joins exact', all(value['invocation_id'] == plan['invocation_id'] for value in [consumed,runner,failure]))
    check('absolute180 and210 same Source-entry epoch', consumed['began_ns'] == runner['began_ns'] and consumed['work_deadline_ns'] == runner['work_deadline_ns'] == runner['began_ns'] + 180000000000 and consumed['overall_deadline_ns'] == runner['overall_deadline_ns'] == runner['began_ns'] + 210000000000)
    check('saved runner subject and grant joins', runner['subject_sha256'] == subject_sha and runner['authorization'] == plan['authorization'] and runner['consumed_marker'] == manifest_by_name['actual','CONSUMED.json'])
    check('worker/runner exact PID relationship', worker_consumed['pid'] == runner['worker_pid'] == 15156 and worker_consumed['ppid'] == terminal['runner_pid'] == 15155 and runner['owned_pgid'] == runner['worker_pid'])
    check('worker known terminal exit2 without signal', runner['worker_reaped'] is True and runner['worker_exit_code'] == 2 and runner['worker_wait4_status'] == 512 and runner['signals'] == [])
    check('runner external exit2 and failed terminal gate', terminal['runner_exit_code'] == 2 and terminal['terminal_gate_passed'] is False and terminal['ROOT_resource_accepted'] is False and terminal['runner_receipt'] == manifest_by_name['actual','runner-receipt.json'])
    check('worker/group/log closure explicit', runner['owned_group_absent'] is True and runner['regular_logs_closed'] is True and runner['cleanup']['group_seen_absent'] is True and runner['cleanup']['group_reappeared'] is False)
    check('cleanup complete before original210 without diagnostic losses', runner['cleanup']['completed_before_deadline'] is True and runner['cleanup']['completed_ns'] < runner['overall_deadline_ns'] and runner['cleanup']['diagnostics_incomplete'] is False and runner['cleanup']['dropped_events'] == 0)
    check('negative raw closure complete before original210', runner['post_child_raw_custody']['checked'] is True and runner['post_child_raw_custody']['completed_before_deadline'] is True and runner['post_child_raw_custody']['completed_ns'] < runner['overall_deadline_ns'])
    check('whole stable logs closed/custodied before original210', runner['whole_log_custody']['complete'] is True and runner['whole_log_custody']['stable'] is True and runner['whole_log_custody']['completed_before_deadline'] is True and runner['whole_log_custody']['completed_ns'] < runner['overall_deadline_ns'])
    check('actual logs exact stable pins and empty', runner['stdout'] == manifest_by_name['actual','stdout.bin'] and runner['stderr'] == manifest_by_name['actual','stderr.bin'] and runner['stdout']['bytes'] == runner['stderr']['bytes'] == 0)
    elapsed_ns = terminal['terminal_observed_ns'] - runner['began_ns']
    check('terminal clock148.885128167seconds from runner Source entry', elapsed_ns == 148885128167 and terminal['runner_clock_elapsed_seconds'] == elapsed_ns / 1000000000)
    check('known worker exit before180 and external terminal before210', runner['worker_terminal_observed_ns'] < runner['work_deadline_ns'] and terminal['terminal_observed_ns'] < runner['overall_deadline_ns'])
    check('outer resource/finite/scientific/math admissions all false', all(runner[key] is False for key in ['resource_candidate_accepted','finite_encoding_candidate','full_pipeline_qualified','scientific_acceptance','mathematical_proof_accepted']) and all(terminal[key] is False for key in ['ROOT_resource_accepted','terminal_gate_passed','full_pipeline_qualified','scientific_acceptance','mathematical_proof_accepted']))
    check('unavailable admitted-call counts remain null', all(runner[key] is None for key in ['compiler_calls','search_calls','verifier_calls','oracle_calls']))
    check('no positive result/header/canonical or complete summary', all(not (A/name).exists() for name in ['canonical-implicit-palette-calibration.json','result.json','worker-receipt.json','worker-failure-summary.json','failed-prefix.json']))
    check('complete negative worker schema and no admission', failure['schema'] == 'implicit-palette-graph-worker-failure-v1' and failure['status'] == 'FAILED_OR_UNFINISHED' and failure['no_failed_prefix_admission'] is True and failure['full_pipeline_qualified'] is False and failure['mathematical_proof_accepted'] is False)
    check('saved first fault is whole packet byte cap', failure['stage'] == 'FULL_PACKET_WRITE' and failure['first_available_fault'] == {'message':'whole JSON packet cap','type':'PolicyFailure'})
    check('failed-prefix retention also recorded packet cap', failure['prefix_retention_error'] == {'message':'whole JSON packet cap','type':'PolicyFailure'})
    check('summary unavailable and no positive outputs', failure['early_failure_summary'] is None and failure['outputs'] == [] and failure['subject_prefix'] is None and failure['graph_prefix'] is None)
    check('available Root counter explicit cutoff only', type(failure['root_check_calls']) is int and failure['root_check_calls'] == 324982843 and failure['root_check_calls'] <= 400000000)
    declaration = json.loads(read(plan['declaration']))
    check('failure reports all15 declared case/component IDs', failure['completed_case_ids'] == declaration['case_ids'] and failure['completed_component_ids'] == declaration['case_ids'] and len(failure['completed_case_ids']) == 15)
    check('failure retains all33 old diagnostic metadata rows/order', len(failure['diagnostic_prefix']) == 33 and [row['id'] for row in failure['diagnostic_prefix']] == declaration['diagnostic_ids'])
    for row, expected in zip(failure['diagnostic_prefix'], declaration['diagnostics']):
        check('saved old diagnostic status only: ' + row['id'], row['status'] == 'PASSED' and row['expected'] == expected['expected'] and row['operation'] == expected['operation'] and row['role'] == expected['role'])
    progress = failure['batch_diagnostic_progress']
    check('new diagnostic progress reports COMPLETE', progress['stage'] == 'COMPLETE' and progress['active_group'] is None and progress['active_variant'] is None)
    check('all28 new groups exact saved IDs/order', len(progress['groups']) == 28 and [g['id'] for g in progress['groups']] == progress['completed_group_ids'] == [g['id'] for g in declaration['batch_diagnostic_groups']])
    variant_rows = []
    for group, expected in zip(progress['groups'], declaration['batch_diagnostic_groups']):
        check('saved complete new group metadata: ' + group['id'], group['stage'] == 'COMPLETE' and group['active_runs'] == [] and group['subject'] == expected['subject'] and group['recipe'] == expected['recipe'] and [v['id'] for v in group['variants']] == [v['id'] for v in expected['variants']])
        for variant, expected_variant in zip(group['variants'], expected['variants']):
            check('saved complete new variant metadata: ' + variant['id'], variant['status'] == 'PASSED' and variant['complete'] is True and variant['expected'] == expected_variant['expected'])
            variant_rows.append(variant)
    check('all55 saved variants retained in complete diagnostic JSON', len(variant_rows) == 55)
    for key in ['call_started','call_completed','call_raised']:
        check('saved cutoff call map exact nonnegative ints: ' + key, type(failure[key]) is dict and all(type(k) is str and type(v) is int and v >= 0 for k,v in failure[key].items()))
    ledger = runner['final_physical_ledger']
    before_bytes = sum(row['pin']['bytes'] for row in raw_manifest if row['category'] == 'actual' and row['name'] != 'runner-receipt.json')
    check('saved pre-receipt raw physical ledger exact', before_bytes == ledger['before_receipt_bytes'] == 125294969)
    check('original9MiB conservative ledger exceeds128MiB', ledger['conservative_bytes'] == before_bytes + 9437184 == 134732153 and ledger['conservative_bytes'] > plan['limits']['result_bytes'] and ledger['within_original_cap'] is False)
    check('negative ledger complete/stable before210', ledger['enumeration_complete'] is True and ledger['stable_writer_quiescence'] is True and ledger['completed_before_deadline'] is True and ledger['completed_ns'] < runner['overall_deadline_ns'])
    check('worker highwater saved below1GiB but no total-fit authority', runner['worker_wait4_usage']['ru_maxrss'] == 937689088 and runner['worker_wait4_usage']['ru_maxrss'] <= plan['limits']['memory_bytes'])
    closure = json.loads(read(plan['runtime_closure']))
    all_pins = [('python',plan['python']),('declaration',plan['declaration']),('closure',plan['runtime_closure'])]
    all_pins += [('Source-' + role,value) for role,value in plan['sources'].items()]
    all_pins += [('input-' + str(i),value['pin']) for i,value in enumerate(plan['inputs'])]
    all_pins += [('stdlib-' + str(i),value) for i,value in enumerate(closure['stdlib_files'])]
    for label,value in all_pins:
        check('current complete raw closure matches saved subject: ' + label, pin(Path(value['path'])) == value)
    total_actual_bytes = sum(row['pin']['bytes'] for row in raw_manifest if row['category'] == 'actual')
    receipt = dict(schema='independent-complete-batch-saved-negative-review-v2',
        reviewer_identity='/root/recovered_batch_review',
        status='PASS_PASSIVE_NEGATIVE_CONSISTENCY_ONLY', review_passed=True,
        source_only_or_saved_data=True, actual_execution_authorized=False,
        subject_imports=0, subject_function_calls=0, helper_calls=0, fixture_calls=0,
        compiler_calls=0, checker_calls=0, semantic_replays=0, sizing_oracle_calls=0,
        plan=plan_pin, subject_sha256=subject_sha, authorization=plan['authorization'],
        full_Source_review=auth['review'], raw_manifest=raw_manifest,
        canonical_partial_policy='Raw bytes/hash only. Never decoded, projected, completed or admitted.',
        failed_prefix_partial_policy='Empty raw bytes only. Never treated as a complete JSON prefix.',
        historical_partial_policy='Historical failed partials were not accessed or admitted.',
        saved_negative_census=dict(scope='Worker-failure diagnostic metadata only; no complete canonical packet or result/header admission.',
            worker_stage=failure['stage'], first_available_fault=failure['first_available_fault'],
            case_ids=failure['completed_case_ids'], case_count=15, old_diagnostic_count=33,
            new_group_count=28, new_variant_count=55, new_progress_stage=progress['stage'],
            observed_status='All saved declared diagnostic statuses PASSED/COMPLETE; not independently replayed or promoted.',
            root_callbacks_at_failure_cutoff=failure['root_check_calls'],
            root_callback_scope='Available worker failure cutoff; not completed total/private CPU work or a positive result.',
            worker_call_started=failure['call_started'], worker_call_completed=failure['call_completed'], worker_call_raised=failure['call_raised'],
            worker_call_map_scope='Saved wrapper cutoff metadata. No admitted compiler/search/verifier/oracle aggregate is reconstructed.'),
        process_and_resources=dict(worker_exit_code=2, runner_exit_code=2, known_reaped=True,
            owned_group_absent=True, no_group_reappearance=True, logs_closed=True,
            runner_Source_entry_to_terminal_ns=elapsed_ns,
            worker_HWM_bytes=937689088, memory_scope='Standalone worker saved wait4 highwater only.',
            physical_before_runner_receipt_bytes=before_bytes,
            conservative_physical_including_original_reserve_bytes=134732153,
            original_physical_cap_bytes=134217728, original_cap_exceeded_by_bytes=134732153-134217728,
            current_raw_actual_bytes_including_runner_receipt=total_actual_bytes,
            negative_raw_log_group_ledger_terminal_before210=True),
        missing_complete_artifacts=['canonical-implicit-palette-calibration.json','result.json','worker-receipt.json','worker-failure-summary.json','failed-prefix.json'],
        unavailable_admitted_counts={key:None for key in ['compiler_calls','search_calls','verifier_calls','oracle_calls']},
        unavailable_admitted_profile_metrics=None, unavailable_expanded_packet_bytes=None,
        resource_accepted=False, finite_encoding_accepted=False, terminal_gate_passed=False,
        scientific_acceptance=False, mathematical_proof_accepted=False,
        full_pipeline_qualified=False, theorem_discovery=False, RL_qualification=False,
        no_failed_prefix_admission=True, mathematical_results_replayed=False,
        findings=[
            'One existing Root grant was consumed for this exact subject; no repeat or rescue authority follows.',
            'The complete worker failure record exposes a new output-byte failure after its reported full cohort progress. Earlier timeout-stage uncertainty is not retroactively repaired.',
            'Whole canonical JSON serialization exceeded its gate. The raw partial has no mathematical, verifier or census authority and was only hashed.',
            'The saved final conservative physical ledger independently exceeds the original128MiB ceiling. Earlier exit/time and worker-memory observations do not override the rejected whole-resource gate.',
            'No complete canonical packet, result/header or summary exists. Complete profile costs, expanded bytes and positive call aggregates remain unavailable; diagnostic statuses are not qualified component or theorem results.',
            'No cause is assigned to the absent early summary beyond its saved null/unavailable status. No subject helper was replayed to explain it.',
            'Root must retire the consumed grant with0remaining and publish this negative without trimming banks, raising caps, rescuing partials or claiming proof/RL/tiling advantage.'
        ],
        mechanical_checks=checks, failed_checks=0,
        tools_stopped_after_freeze=True, metadata_author=pin(Path(__file__)))
    output = O / 'typed-complete-batch-saved-negative-review-v2.json'
    with output.open('xb') as target:
        target.write((json.dumps(receipt, sort_keys=True, indent=2, ensure_ascii=True) + '\n').encode())
    print(json.dumps(dict(receipt=pin(output), checks=len(checks), review_passed=True,
                         worker_failure=manifest_by_name['actual','worker-failure.json'],
                         canonical_partial_raw_only=partial_pin, tools_stop=True), sort_keys=True))


if __name__ == '__main__':
    main()
