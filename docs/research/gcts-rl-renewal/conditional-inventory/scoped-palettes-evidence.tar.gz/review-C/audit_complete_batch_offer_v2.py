"""Independent Source/AST/raw-JSON review only; no subject imports or calls."""
import ast
import hashlib
import json
from pathlib import Path
import sys

D = Path(__file__).resolve().parent.parent
O = Path(__file__).resolve().parent
OFFER = D / 'root/batch-Source-only-offer-v2.json'


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False).encode()


def pin(path):
    path = Path(path)
    raw = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def read(pin_value):
    path = Path(pin_value['path'])
    assert path.is_absolute() and path.resolve() == path and path.is_file() and not path.is_symlink()
    assert pin(path) == pin_value
    return path.read_bytes()


def definitions(tree):
    return {n.name: n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}


def dump(tree):
    return ast.dump(tree, annotate_fields=True, include_attributes=False)


def source_dict(tree, name):
    """Parse literal dict(...) keyword constants without running Source."""
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == name for t in node.targets):
            value = node.value
            if isinstance(value, ast.Dict):
                return ast.literal_eval(value)
            assert isinstance(value, ast.Call) and isinstance(value.func, ast.Name) and value.func.id == 'dict' and not value.args
            return {kw.arg: ast.literal_eval(kw.value) for kw in value.keywords}
    raise AssertionError('missing literal Source dict: ' + name)


def assignment(tree, name):
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == name for t in node.targets):
            return node.value
    raise AssertionError('missing Source assignment: ' + name)


def main():
    assert sys.version_info[:3] == (3, 12, 14)
    assert pin(Path(sys.executable))['sha256'] == 'b6ea0c2a9bfce48dbf181a53f1ca4f0562d40658b85bf47258e2a88d8f9e3933'
    offer_pin = pin(OFFER)
    assert offer_pin['sha256'] == 'a8010f211e5f3fd9852d43195d6b562c7ae1c88ad046040bb0f8439f374f6f5d'
    offer = json.loads(OFFER.read_bytes())
    subject = offer['subject']
    subject_sha = hashlib.sha256(canonical(subject)).hexdigest()
    assert subject_sha == offer['subject_sha256'] == '5c41ecdc77f6f88296614dff482c6187de13301a178c745a6b12e903de66467c'
    checks = []
    def check(label, condition, detail=None):
        checks.append(dict(label=label, passed=bool(condition), detail=detail))
    check('exact nine-field subject', set(subject) == {'schema','invocation_id','actual_directory','python','sources','inputs','limits','declaration','runtime_closure'})
    check('exact six Source roles', set(subject['sources']) == {'worker','implicit','graph','selector','runner','observer'})
    check('ASCII exact subject avoids formatter ambiguity', canonical(subject).decode().isascii())
    check('no execution authority in offer', offer['source_only'] is True and offer['actual_execution_authorized'] is False)
    check('current Python whole pin', pin(Path(sys.executable)) == subject['python'])
    folder = O / 'prospective-5c41-review-preimages-v2'
    folder.mkdir()
    preimages = []
    def preserve(name, value):
        raw = read(value)
        path = folder / name
        with path.open('xb') as output:
            output.write(raw)
        preimages.append(dict(original=value, preserved=pin(path)))
        check('whole pinned raw preimage: ' + name, True)
        return raw
    sources = {}
    trees = {}
    for role, value in subject['sources'].items():
        raw = preserve(role + '.py', value)
        sources[role] = raw.decode()
        tree = ast.parse(raw.decode(), filename=value['path'])
        compile(tree, value['path'], 'exec', dont_inherit=True, optimize=0)
        trees[role] = tree
        check('AST/unused compile: ' + role, True)
    declaration = json.loads(preserve('declaration.json', subject['declaration']))
    closure = json.loads(preserve('closure.json', subject['runtime_closure']))
    plan = json.loads(preserve('prospective-plan.json', offer['prospective_plan']))
    authorization = json.loads(preserve('false-authorization.json', offer['false_authorization']))
    original = json.loads(preserve('input-original.json', subject['inputs'][0]['pin']))
    bank = json.loads(preserve('input-new.json', subject['inputs'][1]['pin']))
    preserve('master.md', offer['current_master'])
    assembly = json.loads(preserve('assembly-v2.json', offer['Source_assembly']))
    old_assembly = json.loads(read(assembly['previous_assembly']))
    B = json.loads(read(offer['B_handoff']))
    L = json.loads(read(offer['L_handoff']))
    check('handoff component Source exact', B['current_component'] == subject['sources']['implicit'])
    check('handoff new bank exact', L['bank'] == subject['inputs'][1]['pin'])
    check('entire current master explicit tracked copy', offer['current_master']['sha256'] == 'ca6ee206287bf18b69f88a35d30968312499567755f347a819af4cf49743e7d4' and offer['current_master']['bytes'] == 36240 and declaration['primary_working_master_bytes_available'] is False)
    check('prospective subject exact plan minus authorization', {k:v for k,v in plan.items() if k != 'authorization'} == subject)
    check('prospective false auth exact pin', plan['authorization'] == offer['false_authorization'])
    check('false authorization has maximum0', authorization['actual_execution_authorized'] is False and type(authorization['maximum_actual_invocations']) is int and authorization['maximum_actual_invocations'] == 0)
    check('false authorization subject join', authorization['subject_sha256'] == subject_sha)
    actual = Path(subject['actual_directory'])
    check('fresh actual path absent', not actual.exists() and actual.is_absolute() and actual.resolve() == actual and actual.parent.is_dir())
    observer_folder = Path(offer['prospective_plan']['path']).with_suffix('')
    observer_folder = observer_folder.parent / (observer_folder.name + '-terminal-observation')
    check('fresh prospective observation path absent', not observer_folder.exists())
    check('all old grants explicitly retired', offer['old_grants'] == 'All retired; no rescue or reexecution.')
    check('whole exact original bank preserved', subject['inputs'][0]['pin']['sha256'] == '10fe60d005a2f586a76bf69ae30317b8dae538ba9f126714b9f71ffa474a89b4' and subject['inputs'][0]['pin']['bytes'] == 740651)
    check('two exact declared banks', len(subject['inputs']) == 2 and declaration['inputs'] == subject['inputs'])
    case_ids = [r['id'] for r in original['small_palettes']] + [original['large_palette']['id']] + [r['id'] for r in original['graph_cases']]
    check('full original15 normal cases/order', len(original['small_palettes']) == 4 and len(original['graph_cases']) == 10 and declaration['exact_cases'] == 15 and declaration['case_ids'] == case_ids and len(set(case_ids)) == 15)
    check('full original33 diagnostic declarations/order', len(original['diagnostics']) == 33 and declaration['diagnostics'] == original['diagnostics'] and declaration['diagnostic_ids'] == [r['id'] for r in original['diagnostics']])
    check('all7936 large transition rows retained', len(original['large_palette']['machine']['transitions']) == 7936)
    check('new exact bank schema agreed', bank['schema'] == 'implicit-batch-summary-diagnostics-v1' and "need(batch_inputs['schema']=='implicit-batch-summary-diagnostics-v1'" in sources['worker'])
    check('new bank pins original whole descriptor', bank['original_bank'] == subject['inputs'][0]['pin'])
    check('all28 groups55 variants in exact declaration', len(bank['groups']) == 28 and sum(len(g['variants']) for g in bank['groups']) == 55 and declaration['batch_diagnostic_groups'] == bank['groups'])
    check('all declared group/variant identities distinct', len({g['id'] for g in bank['groups']}) == 28 and len({v['id'] for g in bank['groups'] for v in g['variants']}) == 55)
    check('24batch and4summary group split', sum(g['subject'] == 'batch-profile' for g in bank['groups']) == 24 and sum(g['subject'] == 'scalar-summary-builder' for g in bank['groups']) == 4)
    check('summary writer/persistence explicitly outside coverage', 'No summary writer or persistence test.' in declaration['diagnostics_scope'])
    check('closure subject joins', closure['sources'] == subject['sources'] and closure['python'] == subject['python'] and closure['declaration'] == subject['declaration'])
    check('parser provenance exact current executable/version', closure['AST_parser']['python'] == subject['python'] and closure['AST_parser']['version'] == sys.version)
    census = {row['role']: row for row in closure['direct_import_census']}
    check('six-role import census exact', set(census) == set(subject['sources']))
    for role, tree in trees.items():
        imports = []
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                imports.extend(alias.name for alias in node.names)
            elif isinstance(node, ast.ImportFrom):
                imports.append(node.module or '')
        imports = sorted(set(imports))
        check('AST digest exact: ' + role, census[role]['AST_sha256'] == hashlib.sha256(dump(tree).encode()).hexdigest())
        check('whole direct-import census: ' + role, imports == census[role]['direct_imports'] and census[role]['source'] == subject['sources'][role])
    for value in closure['stdlib_files']:
        read(value)
        check('declared stdlib raw custody: ' + Path(value['path']).name, True)
    check('stdlib loader scope explicitly trusted', 'transitive stdlib/OS loader/interpreter trusted' in closure['runtime_trust'])
    check('closure owners not claimed as hostile deep seal', 'not deep mutable-global/default-content/concurrent adversary sealing' in closure['runtime_trust'])
    old_worker = read(assembly['previous_worker']).decode()
    inverse = sources['worker'].replace("VERSION = '" + assembly['new_VERSION'] + "'", "VERSION = '" + assembly['old_VERSION'] + "'", 1)
    inverse = inverse.replace(assembly['new_guard'], assembly['old_guard'], 1)
    check('exact inverse v2 descriptor-only correction', inverse == old_worker)
    check('current guard retains descriptor copy before strict guard', sources['worker'].index("context['owners'].append(args)") < sources['worker'].index("argument_bytes(args[0])==argument_bytes(context['descriptor'])"))
    check('strict detached descriptor guard is independently latched', "s.policy(lambda:need(args[0]is context['descriptor'] or\n        argument_bytes(args[0])==argument_bytes(context['descriptor'])," in sources['worker'])
    check('detached graph descriptor remains unchanged', 'self.descriptor = _thaw(self.descriptor_owned, w)' in sources['graph'])
    old_guard_negative = O / 'typed-complete-batch-Source-prospective-negative-v1.json'
    check('original identity negative preserved raw', pin(old_guard_negative)['sha256'] == '585baf548c89bed938cfcd0ed65fdf66a54b9f218567591cef970303275396ea')
    base = read(B['current_worker']).decode()
    fragment = read(L['source']).decode()
    stitched = base.replace("VERSION = '" + old_assembly['old_VERSION'] + "'", "VERSION = '" + old_assembly['new_VERSION'] + "'", 1).replace(old_assembly['replaced_refusing_stub'], fragment, 1)
    check('exact Root B+L raw Source assembly', stitched == old_worker)
    check('no refusing diagnostics stub in current worker', 'new batch diagnostics fragment has not been integrated' not in sources['worker'])
    check('exact frozen diagnostics definitions inserted', all(dump(node) == dump(definitions(trees['worker'])[name]) for name, node in definitions(ast.parse(fragment)).items()))
    # Compare unchanged legacy semantic APIs by AST, and the exact extraction
    # of the old query tail into the new prepared-descriptor kernel.
    legacy_source = (D / 'recovered/Bv2/implicit_wang_palette_v2.py').read_text()
    legacy_defs = definitions(ast.parse(legacy_source))
    current_defs = definitions(trees['implicit'])
    for name, node in legacy_defs.items():
        if name != '_query':
            check('unchanged legacy palette definition: ' + name, name in current_defs and dump(node) == dump(current_defs[name]))
    old_query = legacy_defs['_query']
    owned_query = current_defs['_query_owned']
    check('prepared query kernel is exact old postdescriptor AST', [dump(n) for n in old_query.body[1:]] == [dump(n) for n in owned_query.body])
    expected_wrapper = ast.parse("def _query(descriptor, masks, index, select_mode, work):\n    machine, wire = _descriptor(descriptor, work)\n    return _query_owned(machine, wire, masks, index, select_mode, work)\n").body[0]
    check('standalone query retains exact descriptor preparation before extracted kernel', dump(current_defs['_query']) == dump(expected_wrapper))
    check('implicit component has no imports', census['implicit']['direct_imports'] == [])
    check('graph/selector exact recovered Source pins', subject['sources']['graph']['sha256'] == '1a83c9c59b2e1862d5a2acda69b826ccc3a8e2cf4899e824286f711f8bf25981' and subject['sources']['selector']['sha256'] == '02cf1718e09c1eadb4eda4811436e1c7139cb2e1c255f9d73894e0e3b5d21b43')
    limits = dict(work_seconds=180, overall_seconds=210, memory_bytes=1073741824,
        result_bytes=134217728, expanded_bytes=134217728, stdout_bytes=4194304,
        stderr_bytes=4194304, worker_receipt_bytes=4194304,
        runner_metadata_bytes=8388608, observer_bytes=1048576)
    check('all original outer limits exact', subject['limits'] == declaration['limits'] == source_dict(trees['runner'],'LIMITS') == source_dict(trees['worker'],'OUTER_LIMITS') == limits)
    for key, source_name in [('implicit','IMPLICIT_LIMITS'),('graph','GRAPH_LIMITS'),('selector','SELECTOR_LIMITS')]:
        check('unchanged private component limits: ' + key, source_dict(trees['worker'],source_name) == declaration['component_limits'][key])
    expected_profile = dict(declaration['component_limits']['implicit'], queries=1000000, receipt_items=2000000)
    check('ten exact declared profile limit units', declaration['profile_limits'] == expected_profile and len(expected_profile) == 10)
    check('profile Source limits derived from original8 plus2', dump(assignment(trees['worker'],'PROFILE_LIMITS')) == dump(ast.parse('dict(IMPLICIT_LIMITS, queries=1000000, receipt_items=2000000)',mode='eval').body))
    check('explicit deterministic128 custody partition', declaration['profile_query_chunk'] == 128 and ast.literal_eval(assignment(trees['worker'],'PROFILE_QUERY_CHUNK')) == 128)
    check('explicit profile entry/exit granularity', declaration['profile_granularity'] == ast.literal_eval(assignment(trees['worker'],'PROFILE_GRANULARITY')) == 'PROFILE_ENTRY_EXIT_PLUS_LOCAL_QUERY_GUARDS_V1')
    check('original cumulative400m Root limit', declaration['checkpoint_limit'] == ast.literal_eval(assignment(trees['worker'],'CHECKPOINT_LIMIT')) == 400000000)
    check('original9MiB reserve unchanged', ast.literal_eval(assignment(trees['worker'],'RESERVE_BYTES')) == 9437184)
    component = sources['implicit']; worker = sources['worker']; runner = sources['runner']; observer = sources['observer']
    check('raw receipt retained before callback-capable typed copy', component.index("state['active_query']['produced_receipt'] = receipt") < component.index('expected = _receipt_tree(receipt, state)'))
    check('preimage retained before next callback', "state['active_query']['produced_preimage'] = expected\n            state['active_query']['preimage_complete'] = True\n            state['preimage_completed_count'] += 1\n            work.tick()" in component)
    check('separate production/preimage/delivery fields', all(key in component for key in ['produced_receipt_count','preimage_completed_count','delivered_receipt_count','active_query']))
    check('exact query first-fault latch', "if state['query_fault'] is None:\n                state['query_fault'] = error" in component and "if state['query_fault'] is not None:\n            raise state['query_fault']" in component)
    check('no callback-bearing generators in batch extension', not any(isinstance(n,(ast.GeneratorExp,ast.Yield,ast.YieldFrom)) for name,node in current_defs.items() if name in {'with_profile','batch_query','_receipt_tree','_same_receipt_tree'} for n in ast.walk(node)))
    check('dynamic graph check exact route and restoration', "context['check']=selected_check" in worker and "finally:\n        context['check']=previous" in worker and "context['check']()" in worker)
    check('full Source/worker callable custody', "checked(pin)" in worker and "callable_seal(sys.modules[__name__])==self.worker_function_seal" in worker and 'id(closure),tuple(closure_owners)' in worker)
    check('Root first fault only initialized and conditionally latched', 'self.first_fault=None' in worker and 'if self.first_fault is None:self.first_fault=error' in worker and 'def fault_gate(self):' in worker)
    check('expected diagnostics always inspect independent latch', 's.fault_gate()\n        if expected==\'FOREIGN\':' in worker and 'Never classify an expected diagnostic while a genuine Root fault lives.' in worker)
    check('profile raw owners persist on success and fault', 'self.profile_lifetimes=[]' in worker and "context['owners'].append(primary)" in worker and "context['owners'].extend((receipt,ordinary,row))" in worker and 'self.palette_call_owners=[]' in worker)
    check('full query stream and independent all ranks', "for rank in range(len(expected)):" in worker and "need(witnesses==16*len(tiles)" in worker and "if len(pending)==PROFILE_QUERY_CHUNK:flush()" in worker)
    check('complete finite graph/root restoration comparator', "argument_bytes(core)==argument_bytes(snapshot['rollback_parent'])" in worker and "set(actual)==set(reference)" in worker and "complete independently indexed literal inventory" in worker)
    check('global dead/forced/generation scheduler remains', "('DEAD', point, 0)" in sources['graph'] and "('FORCED', point, 1)" in sources['graph'] and "self.generations[row[0]], row[1], row[0]" in sources['graph'])
    check('compact return values have full lifetime bindings', "duplicate_keys=('receipts','attempted_requests','exact_receipt_preimages','body_result')" in worker and "raw_full=canonical(full_row)" in worker and "raw_compact=canonical(row)" in worker and "delta=max(0,len(raw_full)-len(raw_compact))" in worker)
    check('full reconstruction charged to original expanded ceiling', "expanded_packet_bytes=output['bytes']+s.expanded_subtree_delta" in worker and "0<logical<=expanded_logical<=134217728" in worker and "w['logical_result_bytes']<=w['expanded_logical_result_bytes']<=134217728" in runner)
    check('complete data in canonical; result summary distinct', 'profile_accounting=s.profile_accounting' in worker and "variants=[dict(id=v['id']," in worker and 'q is an admission summary' in worker)
    check('known/unavailable costs distinct', 'palette_work_unavailable_count += 1' in worker and 'rows=[row for row in s.profile_accounting if row[\'complete\']]' in worker and 'not fabricated zero' in declaration['profile_cost_semantics'])
    check('inside-query graph quota behavior honestly scoped', 'inside a B query' in declaration['graph_quota_semantics'] and 'no new runtime claim' in declaration['graph_quota_semantics'])
    check('no new scalar writer calls in diagnostic fragment', '_write_failure_summary(' not in fragment and 'writer_invoked=False, filesystem_persistence_tested=False' in fragment)
    check('first receipt and reconciliation diagnostics name actual callback frames', "frame.f_code.co_name == '_receipt_tree'" in fragment and "frame.f_code.co_name == '_same_receipt_tree'" in fragment)
    check('bool/int test covers equal Python values', "active_requests = (('count', (0, None, None, None)),)" in fragment and "owner['observed_receipts'][0]['count'] = False" in fragment)
    check('all normal bodies require caller-owned None result', "need(receipt['body_result']is None" in worker)
    check('failure summary precedes bulk and cannot replace primary', worker.index('early_summary = _write_failure_summary(s, _failure_summary_record(s, primary))') < worker.index("failure=dict(schema='implicit-palette-graph-worker-failure-v1'") < worker.index("prefix=s.write_json('failed-prefix.json'"))
    check('summary helpers identical to recovered reviewed version', all(dump(definitions(trees['worker'])[name]) == dump(node) for name,node in definitions(ast.parse((D/'recovered/future-L/summary_helpers.fragment.py').read_text())).items()))
    check('failure prefix never authorizes partial admission', 'no_failed_prefix_admission=True' in worker and 'no_admission=True' in worker)
    check('runner consumes one before worker Popen', runner.index('consumed_before_Popen=True') < runner.index('process=subprocess.Popen(command'))
    check('runner demands separate exact current reviewer', "review['reviewer_identity']=='/root/recovered_batch_review'" in runner and "review['subject']==subject" in runner and "review['component_calls']==0" in runner)
    check('worker max-one exact subject Root grant', "auth['maximum_actual_invocations']==1" in worker and "auth['subject_sha256']==hashlib.sha256(canonical(subject)).hexdigest()" in worker)
    check('positive180 covers whole bytes and known worker exit', "worker normal exit0" in runner and "complete positive result/header/bytes/known-exit before180" in runner and "positive();result['positive_result_read_completed_ns']=NOW()" in runner)
    check('Darwin worker highwater1GiB checked', "sys.platform=='darwin'" in runner and "usage.ru_maxrss<=1073741824" in runner)
    check('original physical cap includes reserve', "total+9437184<=134217728" in runner and "all actual files plus original outer9MiB reserve" in worker)
    check('failure cleanup bounded and owned-group verified', 'CLEANUP_EVENT_LIMIT=32' in runner and 'CLEANUP_POLL_LIMIT=2048' in runner and "if probe_step()!='PRESENT'" in runner and 'group_reappeared' in runner)
    check('negative complete raw/log/ledger checks remain before210', "negative raw custody begins before210" in runner and "whole stable log read completed before210" in runner and "final physical ledger before210" in runner)
    check('observer225 is fallback only', 'process.wait(timeout=225)' in observer and "ROOT_resource_accepted=False,terminal_gate_passed=False" in observer and "observed<receipt['overall_deadline_ns']" in observer)
    check('observer joins known worker exit180 and rootterminal210', "receipt['worker_terminal_observed_ns']<receipt['work_deadline_ns']" in observer and "receipt['positive_result_read_completed_ns']<receipt['work_deadline_ns']" in observer)
    check('all broad scientific/proof claims remain false', all("'"+key+"'" in runner for key in ['full_pipeline_qualified','mathematical_proof_accepted','gcts_rl_advantage_established','learned_pair_markings','trained_RL','complete_physical_VM','proof_discovery']) and declaration['full_pipeline_qualified'] is False and declaration['mathematical_proof_accepted'] is False)
    failures = [row for row in checks if not row['passed']]
    manual = [
        dict(id='SEMANTIC_FULL_PALETTE', finding='All recovered legacy definitions retain exact ASTs except _query: its postdescriptor body is exactly extracted into _query_owned, while standalone _query still prepares the complete descriptor before delegating. Families partition head count/location and all defined transition rows without reachability, bound or target trimming. No-head step population is b(b+1)^2; left/right families each Db(b+1); center Db(b+1)+D0(b+1). Collectors/frames add3b+2b(Q+1)+2; full initializer adds9b+16. Semantic kind/origin identity and all full color constructors agree with literal construction; numeric intern order is not claimed preserved.'),
        dict(id='MASKS_AND_UNRANKING', finding='Outer None alone is missing. Assigned0 is a literal with no palette match. Exact types reject bool-as-int and nested None. Each family intersection simultaneously constrains shared parameters; product counts and mixed-radix selection cover every matching origin once. No full large-palette materialization or proof-kernel/VM qualification follows.'),
        dict(id='PROFILE_LIFETIME', finding='Every scope prepares the entire immutable descriptor anew. Full raw receipt and produced counter are retained before preimage callbacks; complete typed preimage precedes the next callback, and delivery is tracked independently. First query fault stays latched even if body swallows it. Closed or reentrant queries refuse. Cleanup preserves primary and retains secondary metadata/object where available.'),
        dict(id='DETACHED_DESCRIPTOR_FIX', finding='The prior identity-only blocker is resolved in this exact successor by retaining the graph-owned descriptor argument, then accepting original identity or complete strict typed serialization equality under s.policy. L retains its detached immutable descriptor and no semantic color comparison is relaxed. Exact inverse to previous subject is recorded; the previous negative remains authoritative for its own subject.'),
        dict(id='GRAPH_CALLBACK_COSTS', finding='Each dynamic graph query temporarily routes every B work tick through L charged_check, restoring the previous Root dispatcher on both returns and faults. Preparation/reconciliation are Root costs. An L quota caught inside graph does not clear the B query fault: that scope fails unknown/refusal, never UNSAT. Original work1 UNKNOWN occurs before a query and remains distinct.'),
        dict(id='CUSTODY_TRUST', finding='Profile entry/exit check whole Source pins, worker/module function/code/default/closure owners, and strict full descriptor/declared input/limit bytes. All callback/query/Work/error/return owners remain retained. This is ordinary exclusive ownership with read-only callbacks and named controlled mutations, not a hostile concurrent/deep mutable-global/default-content seal. Every real independently latched Root fault dominates expected refusal classification.'),
        dict(id='SCHEDULER_AND_ROLLBACK', finding='The unchanged L adapter represents singleton center t=1 with all four midpoint marks and every palette ID at every admissible center. It globally checks dead, then forced, then earliest explicit root generation with degree tie-break. Immutable complete cores restore parent/root state; first-mode exclusions carry parent support, all-mode uses stable parent rank cursors. No fractional/shared-positive support, remote extra tile marks or fair unbounded activation claim.'),
        dict(id='INDEPENDENT_FINITE_ORACLES', finding='All four complete literal inventories feed every16-subset projected nonempty mask and every independently determined rank, plus declared zero cross-splices. 128-request scopes only partition this unchanged stream. The large full7936-row case receives exact old-cardinality and selected/all-family membership checks, not exhaustive large unranking. All10 finite graph cases compare observed live/parent domains, marking refcounts, scheduler, exact rollback and complete first/all-solution semantics against independent fixed-site-order literal enumeration.'),
        dict(id='NEW_DIAGNOSTICS', finding='The separate literal28-group55-variant bank preserves all old15/33 cases. It tests ordered dynamic/static scopes, exact foreign identity at named stages, private same-class ownership, cumulative work/query/receipt quotas, bool/int0-versus-False, list/tuple and absent/zero mutation, swallowed/reentrant faults, closed queries, custody return and secondary nonmasking. Planned sentinels fire only after genuine Root gates. Four pure scalar-summary groups run no filesystem writer.'),
        dict(id='FULL_OUTPUT_AND_EXPANSION', finding='Normal profile canonical rows contain the full ordinary lifetime and every raw receipt/request/typed preimage once, plus full-return nonduplicate metadata and explicit field bindings. The actual full return remains owned. Inside the sole actual, canonical(full row)-canonical(compact row), floored at0, is charged once per row to the unchanged expanded-byte ceiling; adding the charge field makes this conservative. q is a distinct admission summary, while canonical retains full actual diagnostic data and all successful/failed profile accounting. No fit claim is inferred.'),
        dict(id='PRIVATE_WORK', finding='Whole scope cumulative work is kernel+overhead; overhead is preparation+postpreparation. Successful profile populations alone feed completed metrics. Every failed scope retains its distinct produced/copied/delivered counters and known/unavailable costs. Constructor prefix gaps increment unavailable, never fabricatedzero. Root invocation400m is a callback ceiling rather than CPU-work measure; every attempted phase and output cost remains in the180/210 epoch.'),
        dict(id='FAILURE_SUMMARY', finding='The six bounded scalar helpers exactly match the independently reviewed recovered Source. Summary is attempted before full bulk retention, stores capped exact metadata and no subject prefix traversal/exception formatting, and cannot replace the selected primary. Its hard64KiB writer remains within original physical reserve/210 custody checks. TERM at180 or storage failure may still prevent persistence; no grace or universal retention guarantee.'),
        dict(id='OUTER_ADMISSION', finding='Runner exact-subject separate review and Root max-one grant are required; consumed marker precedes one Popen. Positive header, full packet/result bytes and known worker exit must precede180 from runner Source entry. Worker standalone Darwin HWM, complete source/input/runtime/log/group/physical ledger and observer terminal must meet original1GiB/128MiB/210 bounds. Observer225 only supplies failed fallback observation. Startup/OS/transitive loader trust and worker-only memory scope are explicit.'),
        dict(id='RESEARCH_LIMITS', finding='This review qualifies only Source/prospective readiness for a fresh complete finite representation/search calibration. It proves neither runtime completion/correctness/fit nor a full physical interpreter/FOL proof system, mathematical theorem discovery, learned GCTS markings, RL, receptor lemmas, Turtle/Penrose practical tiling, plane tiling or comparative speed advantage. All those research obligations remain open.')
    ]
    receipt = dict(schema='wang-encoding-Source-prospective-review-v1',
        reviewer_identity='/root/recovered_batch_review', review_passed=not failures,
        source_only=True, component_calls=0, actual_execution_authorized=False,
        subject_imports=0, subject_function_calls=0, helper_calls=0, fixture_calls=0,
        semantic_replays=0, compiler_calls=0, checker_calls=0, simulator_calls=0,
        subject=subject, subject_sha256=subject_sha, offer=offer_pin,
        status='PASS_SOURCE_PROSPECTIVE_ONLY_NOT_GRANTED' if not failures else 'NEGATIVE_SOURCE_OR_METADATA_CHECKS',
        current_master=offer['current_master'], source_pins=subject['sources'],
        input_pins=subject['inputs'], declaration=subject['declaration'], runtime_closure=subject['runtime_closure'],
        raw_preimages=preimages, mechanical_checks=checks, failed_checks=failures,
        manual_Source_findings=manual,
        parser=dict(python=subject['python'], version=sys.version, implementation=sys.implementation.name,
                    flags=['-I','-S','-B'], parse='ast.parse(mode=exec,type_comments=False,feature_version=None)',
                    dump='ast.dump(annotate_fields=True,include_attributes=False).encode(utf8)',
                    unused_compile_count=6, no_returned_code_object_evaluated=True),
        preserved_predecessor_negative=pin(old_guard_negative),
        prior_negative_repaired_only_for_current_successor=True,
        unexecuted=True, runtime_qualified=False, resource_accepted=False,
        finite_encoding_accepted=False, mathematical_authority=False,
        scientific_acceptance=False, full_pipeline_qualified=False,
        actual_directory_absent=not actual.exists(), no_grant_issued_by_review=True,
        required_next='Root exact-subject max-one grant and final delta review, then all-peer idle/current-raw/fresh-path barrier. One actual only; no retry, bank trim, cap raise or failed-prefix rescue.',
        metadata_author=pin(Path(__file__)))
    output_path = O / 'typed-complete-batch-Source-prospective-review-v2.json'
    with output_path.open('xb') as output:
        output.write((json.dumps(receipt, sort_keys=True, indent=2, ensure_ascii=True) + '\n').encode())
    print(json.dumps(dict(receipt=pin(output_path), checks=len(checks), failed_checks=len(failures), review_passed=not failures, failure_labels=[x['label'] for x in failures]), sort_keys=True))


if __name__ == '__main__':
    main()
