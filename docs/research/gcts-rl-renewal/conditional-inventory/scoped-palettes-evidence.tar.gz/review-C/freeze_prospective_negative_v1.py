"""Independent raw/AST metadata only. No reviewed Source is imported/called."""
import ast
import hashlib
import json
from pathlib import Path
import sys

D = Path(__file__).resolve().parent.parent
O = Path(__file__).resolve().parent
offer_path = D / 'root/batch-Source-only-offer-v1.json'


def raw_pin(path):
    raw = Path(path).read_bytes()
    return dict(path=str(Path(path).resolve()), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()), raw


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False).encode()


def main():
    assert sys.version_info[:3] == (3, 12, 14)
    offer_pin, offer_raw = raw_pin(offer_path)
    assert offer_pin['sha256'] == 'b329e48cfb4b0a86e5a0e5f60cd400153d470c93a4053c68177071760d83bbf8'
    offer = json.loads(offer_raw)
    subject = offer['subject']
    subject_sha = hashlib.sha256(canonical(subject)).hexdigest()
    assert subject_sha == offer['subject_sha256'] == 'c2734fa3f86f75e38daf421f9c894620f19593c295a4f7b6cdb62cc0f2cc830e'
    folder = O / 'prospective-c2734-negative-preimages-v1'
    folder.mkdir()
    checks = []
    originals = []
    trees = {}
    for role, pin in subject['sources'].items():
        observed, raw = raw_pin(pin['path'])
        assert observed == pin
        destination = folder / (role + '.py')
        with destination.open('xb') as output:
            output.write(raw)
        tree = ast.parse(raw.decode(), filename=pin['path'])
        compile(tree, pin['path'], 'exec', dont_inherit=True, optimize=0)
        trees[role] = tree
        originals.append(dict(role=role, original=pin, preserved=raw_pin(destination)[0]))
        checks.append(dict(label='whole raw pin/AST/unused compile: ' + role, passed=True))
    for name, pin in [('declaration', subject['declaration']), ('closure', subject['runtime_closure']),
                      ('prospective_plan', offer['prospective_plan']), ('false_authorization', offer['false_authorization']),
                      ('master', offer['current_master'])] + [('input-' + str(i), value['pin']) for i, value in enumerate(subject['inputs'])]:
        observed, raw = raw_pin(pin['path'])
        assert observed == pin
        destination = folder / (name + ('.md' if name == 'master' else '.json'))
        with destination.open('xb') as output:
            output.write(raw)
        originals.append(dict(role=name, original=pin, preserved=raw_pin(destination)[0]))
        checks.append(dict(label='whole raw preimage: ' + name, passed=True))
    with (folder / 'offer.json').open('xb') as output:
        output.write(offer_raw)
    worker = (folder / 'worker.py').read_text()
    graph = (folder / 'graph.py').read_text()
    assert "need(args[0]is context['descriptor'],'exact descriptor object within profile')" in worker
    assert 'self.descriptor = _thaw(self.descriptor_owned, w)' in graph
    assert 'return tuple(items) if tag == \'tuple\' else items' in graph
    assert 'raw = self.palette.count_query(self.descriptor, args, check=charged_check, limits=qlimits)' in graph
    assert 'context=dict(id=profile_id,descriptor=desc,query=None,query_seal=None,' in worker
    assert "return profile_query(s,'count_query',[descriptor,mask],limits,check)" in worker
    checks.append(dict(label='detached descriptor enters identity-only profile guard', passed=True))
    assert not Path(subject['actual_directory']).exists()
    auth = json.loads((folder / 'false_authorization.json').read_bytes())
    assert auth['actual_execution_authorized'] is False and auth['maximum_actual_invocations'] == 0
    checks.append(dict(label='actual absent and no grant', passed=True))
    receipt = dict(schema='wang-encoding-Source-prospective-review-v1',
        reviewer_identity='/root/recovered_batch_review', review_passed=False,
        source_only=True, component_calls=0, actual_execution_authorized=False,
        subject_imports=0, helper_calls=0, fixture_calls=0, semantic_replays=0,
        compiler_calls=0, checker_calls=0, mathematical_authority=False,
        subject=subject, subject_sha256=subject_sha, offer=offer_pin,
        status='SOURCE_NEGATIVE_DESCRIPTOR_IDENTITY_CONFLICT',
        parser=dict(python=subject['python'], version=sys.version,
                    AST='ast.parse default exec; unused compile(dont_inherit=True,optimize=0)', unused_compiles=6),
        preserved_preimages=originals, mechanical_checks=checks,
        blocking_findings=[dict(id='GRAPH_DETACHED_DESCRIPTOR_REJECTED_BY_IDENTITY',
            subject_paths=[subject['sources']['worker']['path'], subject['sources']['graph']['path']],
            exact_worker_guard="need(args[0]is context['descriptor'],'exact descriptor object within profile')",
            graph_detach='self.descriptor = _thaw(self.descriptor_owned, w)',
            derivation=[
                'profile_call stores the original built immutable descriptor object in context.descriptor.',
                'L freezes then thaws the supplied descriptor; _thaw builds a new children list and tuple(items) at every nonempty tuple node.',
                'L._oracle passes its detached self.descriptor into the authenticated facade, which forwards it unchanged to profile_query.',
                'profile_query checks object identity against the original descriptor before any query. Equal tuple values cannot satisfy this distinct-owner identity check.',
                'The first normal graph query therefore refuses by PolicyFailure; none of the10 declared full graph cases can finish under this frozen subject.'
            ],
            required_delta='Check complete strict typed immutable descriptor equality and retain the detached argument owner, or explicitly bridge the already fully guarded facade to the original immutable descriptor. Preserve all value/source/callback/limit custody and full graph coverage; do not delete the guard or trim graph cases.',
            classification='Static integration blocker, not an observed runtime failure or mathematical tiling claim.')],
        prior_reviews_do_not_qualify_current_subject=True,
        current_grants='Prospective false maximum0; all historical actual grants retired.',
        prior_failed_partial='Never parsed, completed, projected or admitted.',
        metadata_author=raw_pin(Path(__file__))[0],
        full_subject_review_complete=False,
        next='Root may author a preserved successor; it requires a fresh full Source/prospective review before any exact once-grant.')
    output_path = O / 'typed-complete-batch-Source-prospective-negative-v1.json'
    with output_path.open('xb') as output:
        output.write((json.dumps(receipt, sort_keys=True, indent=2, ensure_ascii=True) + '\n').encode())
    print(json.dumps(dict(receipt=raw_pin(output_path)[0], checks=len(checks), review_passed=False), sort_keys=True))


if __name__ == '__main__':
    main()
