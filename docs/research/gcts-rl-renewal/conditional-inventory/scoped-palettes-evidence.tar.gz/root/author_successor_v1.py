"""Prepare a metadata-only successor author; never import the subject."""
from pathlib import Path
R=Path(__file__).resolve().parent
old=(R/'assemble_subject_v2.py').read_text()
start=old.index('fragment_path=')
end=old.index('olddecl=')
replacement='''previous_worker=R/'qualify_complete_batch_worker_v1.py'
base=previous_worker.read_text()
assert pin(previous_worker)['sha256']=='b63b928fb5b2d0b4ba1f0ae41622d80ac13600829352977751586358b1484545'
negative=D/'review-C/typed-complete-batch-Source-prospective-negative-v1.json'
assert pin(negative)['sha256']=='585baf548c89bed938cfcd0ed65fdf66a54b9f218567591cef970303275396ea'
old_guard="    need(args[0]is context['descriptor'],'exact descriptor object within profile')\\n"
new_guard="""    # L owns an immutable descriptor copy; require the entire strict typed value.
    # Keep that copy alive through final custody, including a refused query.
    context['owners'].append(args)
    s.policy(lambda:need(args[0]is context['descriptor'] or
        argument_bytes(args[0])==argument_bytes(context['descriptor']),
        'full strict typed descriptor value within profile'))
"""
assert base.count(old_guard)==1
old_version='complete-implicit-batch-Root-integrated-worker-v1'
new_version='complete-implicit-batch-Root-integrated-worker-v2'
assert base.count("VERSION = '"+old_version+"'")==1
combined=base.replace(old_guard,new_guard,1).replace("VERSION = '"+old_version+"'","VERSION = '"+new_version+"'",1)
worker=R/'qualify_complete_batch_worker_v2.py';assert not worker.exists();worker.write_text(combined)
ct=ast.parse(combined);code=compile(ct,str(worker),'exec');del code
names=[n.name for n in ct.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))];assert len(names)==len(set(names))
assembly=save('Root-Source-assembly-v2.json',dict(schema='Root-exact-Source-assembly-v2',author_identity='/root',previous_worker=pin(previous_worker),previous_assembly=pin(R/'Root-Source-assembly-v1.json'),independent_negative=pin(negative),old_guard=old_guard,new_guard=new_guard,old_VERSION=old_version,new_VERSION=new_version,result=pin(worker),source_only=True,subject_imports=0,subject_calls=0,AST_unused_compile=True,full_inverse=combined.replace(new_guard,old_guard,1).replace("VERSION = '"+new_version+"'","VERSION = '"+old_version+"'",1)==base,scope='Exact typed value equality accepts the graph-owned detached descriptor; every argument owner retained and integrity faults independently latched. No Python equality relaxation, cache, bank or limit change.'))
'''
new=old[:start]+replacement+old[end:]
for stem in ('batch-declaration','batch-runtime-closure','batch-authorization-prospective-false','batch-plan-prospective','batch-Source-only-offer'):
 new=new.replace(stem+'-v1.json',stem+'-v2.json')
new=new.replace("invocation_id='complete-batched-implicit-palette-point-graph-v1'","invocation_id='complete-batched-implicit-palette-point-graph-v2'")
new=new.replace("str(R/'actual-batch-v1')","str(R/'actual-batch-v2')")
target=R/'assemble_subject_v3.py';assert not target.exists();target.write_text(new)
print(str(target))
