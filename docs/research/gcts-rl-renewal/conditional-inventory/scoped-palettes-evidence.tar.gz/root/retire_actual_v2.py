"""Passive saved outcome custody only; no subject calls or partial JSON reads."""
from pathlib import Path
import json,hashlib,datetime
R=Path(__file__).resolve().parent;A=R/'actual-batch-v2'
def pin(p):
 p=p.resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def load(p):
 assert p.suffix=='.json' and not p.name.endswith('.partial')
 return json.loads(p.read_bytes())
def save(name,v):
 p=R/name;assert not p.exists();p.write_text(json.dumps(v,sort_keys=True,indent=2,allow_nan=False)+'\n');return pin(p)
plan=load(R/'batch-plan-authorized-v2.json');runner=load(A/'runner-receipt.json')
terminal_path=R/'batch-plan-authorized-v2-terminal-observation/terminal.json';terminal=load(terminal_path)
failure=load(A/'worker-failure.json')
assert runner['worker_launch_attempts']==1 and runner['worker_exit_code']==2
assert terminal['runner_exit_code']==2 and terminal['terminal_gate_passed']is False
assert runner['resource_candidate_accepted']is False and runner['finite_encoding_candidate']is False
assert runner['worker_reaped']is True and runner['owned_group_absent']is True
assert runner['regular_logs_closed']is True
assert failure['stage']=='FULL_PACKET_WRITE' and failure['first_available_fault']==dict(type='PolicyFailure',message='whole JSON packet cap')
assert not any((A/n).exists()for n in ('result.json','worker-receipt.json','canonical-implicit-palette-calibration.json','worker-failure-summary.json'))
manifest=[dict(name=p.name,pin=pin(p),handling='RAW_BYTES_HASH_ONLY_NEVER_PARSE'if p.name.endswith('.partial')else'COMPLETE_SAVED_RECORD_OR_LOG')for p in sorted(A.iterdir())if p.is_file()]
retirement=save('ROOT-grant-retirement-v2.json',dict(schema='ROOT-exact-grant-retirement-v1',author_identity='/root',observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),authorization=plan['authorization'],plan=pin(R/'batch-plan-authorized-v2.json'),subject_sha256=runner['subject_sha256'],actual_invocations=1,maximum_actual_invocations=1,remaining_actual_invocations=0,grant_status='RETIRED',observer_exec_handle=dict(session_id=55090,terminal_exit_code=2,authoritative_terminal_response=True),runner=pin(A/'runner-receipt.json'),terminal=pin(terminal_path),raw_actual=manifest,resource_accepted=False,finite_encoding_accepted=False,mathematical_authority=False,full_pipeline_qualified=False,no_retry_or_rescue=True,partial_policy='All partials, including historical partials, remain raw bytes/hash only. No parsing, completion, projection or mathematical admission.'))
print(json.dumps(retirement,indent=2))
