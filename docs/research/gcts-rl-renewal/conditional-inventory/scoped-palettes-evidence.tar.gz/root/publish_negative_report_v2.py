"""Publishable files from complete saved records and raw-byte archives only.

No subject imports, executions, replay, partial parsing or theorem checking.
"""
from pathlib import Path
import json,hashlib,html,tarfile,gzip,io,sys,shutil
R=Path(__file__).resolve().parent;D=R.parent
P=D/'publisher/docs/research/gcts-rl-renewal/conditional-inventory'
A=R/'actual-batch-v2';O=R/'batch-plan-authorized-v2-terminal-observation'
PREFIX='scoped-palettes'
def pin(p):
 p=p.resolve();raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def load(p):
 p=Path(p);assert p.suffix=='.json' and not p.name.endswith('.partial')
 return json.loads(p.read_bytes())
def save(p,v):p.write_text(json.dumps(v,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
def esc(v):return html.escape(str(v),quote=True)
def math(v):return r'\('+str(v).replace(',',r'\,')+r'\)'
def number(v):return math(format(v,','))if type(v)is int else 'Unavailable'
def card(v,label):return '<div class="metric"><b>'+v+'</b>'+label+'</div>'
assert len(sys.argv)==3
adoption_path=Path(sys.argv[1]).resolve();assert pin(adoption_path)['sha256']==sys.argv[2]
adoption=load(adoption_path)
assert adoption['status']=='OUTPUT_CAP_REJECTED_UNQUALIFIED'
assert adoption['resource_accepted']is False and adoption['finite_encoding_accepted']is False
runner=load(A/'runner-receipt.json');terminal=load(O/'terminal.json');failure=load(A/'worker-failure.json')
decl=load(R/'batch-declaration-v2.json');bank=load(D/'diagnostics-L/new-diagnostic-bank-v1.json')
narrative=load(R/'publication-narrative-v1.json')
elapsed=terminal['runner_clock_elapsed_seconds'];peak=runner['worker_wait4_usage']['ru_maxrss']
ledger=runner['final_physical_ledger']['conservative_bytes'];cap=runner['limits']['result_bytes']
assert ledger>cap and runner['resource_candidate_accepted']is False
assert len(failure['completed_case_ids'])==15 and len(failure['diagnostic_prefix'])==33
progress=failure['batch_diagnostic_progress'];groups=progress['groups']
assert progress['stage']=='COMPLETE' and len(groups)==28
variants=[v for g in groups for v in g['variants']];assert len(variants)==55
raw_manifest=[dict(name=p.name,pin=pin(p),handling='raw bytes/hash only'if p.name.endswith('.partial')else'complete saved record or log')for p in sorted(A.iterdir())if p.is_file()]
summary=dict(schema='scoped-palette-public-negative-summary-v1',status=adoption['status'],actual_invocations=1,remaining_actual_invocations=0,resource_accepted=False,finite_encoding_accepted=False,mathematical_proof_accepted=False,full_pipeline_qualified=False,trained_RL=False,gcts_rl_advantage_established=False,complete_physical_interpreter=False,proof_discovery=False,reported_before_write=dict(normal_case_ids=failure['completed_case_ids'],old_diagnostic_records=33,new_diagnostic_groups=28,new_diagnostic_variants=55,stage=failure['stage'],authority='Diagnostic reports only; no complete canonical experiment packet.'),root_callback_cutoff=failure['root_check_calls'],root_callback_scope='Failure-record snapshot; not terminal callback census or CPU work.',worker_peak_bytes=peak,runner_to_terminal_seconds=elapsed,conservative_physical_ledger_bytes=ledger,original_physical_cap_bytes=cap,canonical_partial=dict(bytes=124780541,sha256='49baf9b389b81f710893f6d88754e86dead98184394332fb8ae1637b669a4231',handling='Raw bytes/hash only; never parse, complete or admit.'),completed_component_call_counts={k:runner[k]for k in ('compiler_calls','search_calls','verifier_calls','oracle_calls')},missing=['canonical completed packet','result','worker header','scalar failure summary','full available prefix'],worker_failure=pin(A/'worker-failure.json'),runner=pin(A/'runner-receipt.json'),terminal=pin(O/'terminal.json'),root_adoption=pin(adoption_path),grant_retirement=pin(R/'ROOT-grant-retirement-v2.json'),limits=decl['limits'],no_new_mathematical_result=True)
save(P/(PREFIX+'-summary.json'),summary)
save(P/(PREFIX+'-data.json'),dict(schema='scoped-palette-passive-saved-records-v1',authority=False,summary=summary,runner=runner,terminal=terminal,worker_failure=failure,raw_actual=raw_manifest,Root_adoption=adoption,declaration=decl,scope='Complete saved negative records for inspection; all partial files are only raw pins. No mathematical replay or successful calibration admission.'))
shutil.copyfile(R/'profile-protocol.svg',P/(PREFIX+'-protocol.svg'))
for kind,source_name in (
 ('source-review','typed-complete-batch-Source-prospective-review-v2.json'),
 ('grant-review','typed-complete-batch-final-grant-delta-review-v2.json'),
 ('saved-review','typed-complete-batch-saved-negative-review-v2.json')):
 shutil.copyfile(D/'review-C'/source_name,P/(PREFIX+'-'+kind+'.json'))
design_path=D/'future-output-B/next-evidence-design-v1.json'
design=load(design_path)
assert design['status']=='UNIMPLEMENTED_SOURCE_ONLY_DESIGN_NOT_A_FITTING_BOUND'
assert design['early_summary_budget_gap']['integer_inequality']['excess_even_for_empty_summary_bytes']==909
shutil.copyfile(design_path,P/(PREFIX+'-next-design.json'))
rows=''.join('<tr><td><code>'+esc(g['id'])+'</code></td><td>'+number(len(g['variants']))+'</td><td>'+(esc(g['stage'])+'; variants '+esc(', '.join(sorted({v['status']for v in g['variants']}))))+' (diagnostic only)</td></tr>'for g in groups)
roles=''.join('<article class="card"><h3>'+esc(x['role'])+'</h3><p>'+esc(x['contribution'])+'</p></article>'for x in narrative['parallel_roles'])
case_rows=''.join('<li><code>'+esc(x)+'</code></li>'for x in failure['completed_case_ids'])
page=r'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Scoped palettes: output cap stops qualification — GCTS research</title>
<script>window.MathJax={tex:{inlineMath:[['\\(','\\)']],displayMath:[['\\[','\\]']]},options:{skipHtmlTags:['script','noscript','style','textarea','pre','code']}};</script><script defer src="https://cdn.jsdelivr.net/npm/mathjax@3.2.2/es5/tex-chtml.js"></script>
<style>:root{--ink:#1c413b;--muted:#586e65;--paper:#f4f6f0;--line:#cfdbd0}*{box-sizing:border-box}body{margin:0;background:var(--paper);color:var(--ink);font:16px/1.65 system-ui,sans-serif}main{max-width:1120px;margin:auto;padding:28px}nav{display:flex;gap:18px;flex-wrap:wrap}a{color:#216e69}h1{font-size:clamp(30px,4.5vw,48px);line-height:1.13;max-width:960px}h2{font-size:26px;line-height:1.25}h3{font-size:18px;margin:0}section{margin:36px 0}.lede{font-size:20px;max-width:960px}.small{font-size:14px;color:var(--muted)}.status,.card,.metric{background:white;border:1px solid var(--line);border-radius:10px;padding:18px}.status{border-left:6px solid #b98234}.metrics,.roles{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px}.metric b{display:block;font-size:27px}.roles .card p{margin-bottom:0}code{font-size:.88em;overflow-wrap:anywhere}.scroll{overflow:auto}table{border-collapse:collapse;width:100%;background:white}th,td{border:1px solid var(--line);padding:9px 12px;text-align:left;vertical-align:top}.diagram{width:100%;height:auto}.diagram-scroll{overflow:auto}.diagram-scroll img{min-width:760px}details{background:white;border:1px solid var(--line);border-radius:8px;padding:14px;margin:14px 0}summary{cursor:pointer;font-weight:650}li{margin:5px 0}footer{border-top:1px solid var(--line);padding:22px 0;color:var(--muted)}@media(max-width:600px){main{padding:16px}.metric{padding:14px}th,td{padding:6px}}</style></head><body><main>
<nav><a href="reader.html#scoped-palette-update">Research notebook</a><a href="implicit-palette.html#outcome">Previous deadline failure</a><a href="#parallel">Parallel work</a><a href="#diagnostics">Diagnostics</a><a href="#evidence">Evidence</a></nav>
<p class="small">20 October 2026 UTC · one new reviewed invocation · unchanged whole bank and caps</p><h1>Scoped palettes: output cap stops qualification</h1><p class="lede">Parallel implementation and review produced a complete batched experiment. Its saved failure record reports that every planned case and diagnostic reached the output stage. The complete canonical packet exceeded the original cap, so the experiment remains unqualified.</p>
<div class="status" id="outcome"><b>Output-cap rejection. No positive packet admitted.</b><p>The worker exited with code <code>2</code> at <code>FULL_PACKET_WRITE</code>, reporting <code>PolicyFailure: whole JSON packet cap</code>. The runner reaped it, observed its process group absent and closed the logs. The one-use grant is retired with no remaining invocations.</p></div>
<div class="metrics">@@METRICS@@</div>
<section id="observations"><h2>What the complete negative records establish</h2><p>The complete <code>worker-failure.json</code> records all \(15\) normal case IDs, \(33\) original diagnostic records, and all \(28\) new groups with \(55\) variants. The new progress record says <code>COMPLETE</code>. These are diagnostic observations about work reached before writing; the missing canonical packet prevents admission of a complete finite calibration.</p>
<p>The canonical temporary file contains @@PARTIALBYTES@@ bytes. It has no committed complete counterpart and is retained only as raw bytes and a hash. Neither it nor the historical partial is parsed, completed, projected or admitted. The separate failed-prefix temporary file is empty.</p>
<div class="card"><b>Outer observations</b><p>Runner entry to terminal observation: @@ELAPSED@@. Worker high-water memory: @@PEAK@@ bytes, approximately @@MIB@@. The conservative physical ledger, including the original metadata reservation, is @@LEDGER@@ bytes: @@INEQUALITY@@. It fails the original cap even though cleanup closed before the outer deadline.</p><p class="small">The result deadline remains \(180\,\mathrm{s}\); the full custody deadline remains \(210\,\mathrm{s}\). The epoch starts at runner Source entry and excludes the observer and interpreter prelude. Standalone worker memory is not a full production or native-checker fit measurement.</p></div>
<p>The failure record captures @@CALLS@@ Root callbacks before later negative retention. This is a cutoff observation, not CPU work or a final callback total. Completed compiler, search, verifier and oracle call counts in the runner remain literal <code>null</code>. There is no complete result, worker header, scalar failure summary or full available prefix.</p>
<details><summary>Every normal case ID reported completed before packet writing</summary><ol>@@CASES@@</ol></details></section>
<section id="protocol"><h2>What changed in the representation</h2><p>@@CHANGED@@</p><div class="diagram-scroll"><img class="diagram" src="scoped-palettes-protocol.svg" alt="Schematic of preparation, strict query, raw receipt retention, exact copying and delivery, and closing custody within one profile."></div><p class="small">Protocol schematic, not a saved tiling or mathematical proof. Colors distinguish preparation/custody, queries, raw production and delivery.</p><p>@@RECEIPTS@@</p><p>@@RETENTION@@</p><p>The graph owns an immutable copy of the palette descriptor. Independent review caught a guard that required the original object identity, which would have refused the first graph query. The successor retains that copied argument and checks full strict typed equality. The rejected predecessor and exact repair are archived.</p><p class="small">@@TRUST@@</p></section>
<section id="parallel"><h2>How the parallel agents contributed</h2><div class="roles">@@ROLES@@</div><p>Source review recorded \(172\) static checks and \(14\) manual findings. A separate grant-only review recorded \(50\) checks. Those reviews establish readiness for this one attempt; they do not convert its output failure into a passed experiment. A passive saved-data review recorded \(208\) consistency checks. Those checks confirm the negative record and its limits, without mathematical replay. The reviews are linked below.</p></section>
<section id="diagnostics"><h2>The new diagnostic bank was reached</h2><p>The saved complete failure record contains the following groups and reports their variants passed. All remain diagnostic observations within this rejected whole run. The original diagnostic bank is retained separately and unchanged.</p><div class="scroll"><table><thead><tr><th>Group</th><th>Variants</th><th>Saved report</th></tr></thead><tbody>@@GROUPS@@</tbody></table></div><p>@@DIAGNOSTICLIMIT@@ The scalar failure summary did not complete in this actual run. The complete later failure file identifies the cap failure; it does not record an independent cause for the missing scalar summary.</p></section>
<section id="limits"><h2>Research meaning and the next step</h2><p>@@SCIENTIFICLIMIT@@</p><p>@@RUNTIMELIMIT@@ The earlier timeout remains a separate negative result; a different failure mode here is not an established speedup.</p><p>The next representation change must retain the complete evidence while satisfying both the stored and expanded limits. Ordinary byte sharing alone is insufficient if the fully charged logical reconstruction still exceeds the cap. Failure diagnostics also need space available when the main writer exhausts its allowance. No fitting bound, revised implementation or new invocation is claimed here.</p><p>A separate <a href="scoped-palettes-next-design.json">unimplemented source design note</a> identifies repeated evidence views and a shared-budget flaw. Under exclusive ownership with no deletion or truncation, the two consumed files and the canonical fragment already give \[124\,780\,541+592+320+9\,437\,184=134\,218\,637>134\,217\,728.\] Thus the scalar summary budget predicate has no room even for an empty summary, exceeding the total by \(909\) bytes. This proves guard infeasibility under those assumptions; the suppressed runtime exception itself was not recorded. The proposed single-owner certificate and aggregate byte allocator have no fitting bound, implementation or execution authority.</p><p>@@NEXT@@</p></section>
<section id="evidence"><h2>Inspect the saved evidence</h2><p><a href="scoped-palettes-summary.json">Negative summary</a> · <a href="scoped-palettes-data.json">Complete saved failure and outer records</a> · <a href="scoped-palettes-manifest.json">Manifest</a> · <a href="scoped-palettes-source-review.json">Source review</a> · <a href="scoped-palettes-grant-review.json">Grant delta review</a> · <a href="scoped-palettes-saved-review.json">Passive negative audit</a> · <a href="scoped-palettes-review.json">Publication review</a> · <a href="scoped-palettes-evidence.tar.gz">Sources, inputs, reviews and all raw actual files</a></p><p>The archive preserves all raw partials with explicit handling restrictions, the frozen predecessor, the source and grant reviews, the once authorization and retirement, and the complete diagnostic-only failure record. No raw file is overwritten to create a successor result.</p></section>
<footer>The broader tiling and automated proof-search program remains active. This milestone records an output representation failure and inspectable parallel contributions.</footer></main></body></html>'''
substitutions={'METRICS':card(math('1'),'actual; grant retired')+card(math('15'),'normal case IDs reported')+card(math('33+55'),'diagnostic variants reported')+card(math('0'),'admitted complete packets'), 'PARTIALBYTES':number(124780541),'ELAPSED':math(format(elapsed,'.3f')+r'\,\mathrm{s}'),'PEAK':number(peak),'MIB':math(format(peak/1048576,'.2f')+r'\,\mathrm{MiB}'),'LEDGER':number(ledger),'INEQUALITY':math(format(ledger,',')+' > '+format(cap,',')),'CALLS':number(failure['root_check_calls']),'CASES':case_rows,'CHANGED':esc(narrative['changed']),'RECEIPTS':esc(narrative['receipt_distinction']),'RETENTION':esc(narrative['retention']),'TRUST':esc(narrative['trust']),'ROLES':roles,'GROUPS':rows,'DIAGNOSTICLIMIT':esc(narrative['diagnostic_limit']),'SCIENTIFICLIMIT':esc(narrative['scientific_limit']),'RUNTIMELIMIT':esc(narrative['runtime_limit']),'NEXT':esc(narrative['next_if_rejected'])}
for key,value in substitutions.items():page=page.replace('@@'+key+'@@',value)
assert '@@'not in page
(P/(PREFIX+'.html')).write_text(page)
reader=P/'reader.html';reader_source=reader.read_text();assert 'id="scoped-palette-update"'not in reader_source
new_section=r'''<section id="scoped-palette-update"><p class="eyebrow">20 OCTOBER 2026 UTC · LATEST WHOLE-COHORT ATTEMPT</p><h2>Scoped palettes reach output, then exceed the cap.</h2><p>The complete failure record reports all \(15\) normal cases, \(33\) original diagnostics and \(55\) new variants reached before writing. The canonical evidence packet exceeded its unchanged cap; no complete calibration or new theorem is admitted. <a href="scoped-palettes.html#outcome"><b>Read the saved negative outcome</b></a> · <a href="scoped-palettes.html#parallel">Parallel contributions and the pre-run bug found by review</a>.</p></section>'''
marker='<section id="implicit-palette-update">';assert reader_source.count(marker)==1
reader.write_text(reader_source.replace(marker,new_section+'\n'+marker,1))
# Exact raw-byte archive, including partials without attempting JSON decoding.
files=[]
for directory in ('root','components-B','diagnostics-L','review-C','recovered','future-output-B'):
 base=D/directory
 if not base.exists():continue
 for p in sorted(base.rglob('*')):
  assert not p.is_symlink()
  if p.is_file():files.append((directory+'/'+str(p.relative_to(base)),p))
files.extend([('recovery-manifest.json',D/'recovery-manifest.json'),('references/basic-tiling-algorithm.md',D/'publisher/docs/basic-tiling-algorithm.md'),('references/AGENTS.md',D/'publisher/AGENTS.md')])
pathmap=[dict(archive_path=name,source=pin(p),handling='RAW_BYTES_HASH_ONLY_NEVER_PARSE'if p.name.endswith('.partial')else'ordinary complete file')for name,p in files]
archive=P/(PREFIX+'-evidence.tar.gz');assert not archive.exists()
with archive.open('xb')as destination:
 with gzip.GzipFile(filename='',mode='wb',fileobj=destination,mtime=0,compresslevel=6)as compressed:
  with tarfile.open(fileobj=compressed,mode='w|')as tar:
   for name,p in files:
    raw=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o600;info.mtime=0
    tar.addfile(info,io.BytesIO(raw))
   raw=json.dumps(pathmap,sort_keys=True,indent=2).encode()+b'\n';info=tarfile.TarInfo('ARCHIVE-PATHMAP.json');info.size=len(raw);info.mode=0o600;info.mtime=0;tar.addfile(info,io.BytesIO(raw))
save(P/(PREFIX+'-manifest.json'),dict(schema='scoped-palette-publication-manifest-v1',status=summary['status'],author_identity='/root',files=[dict(name=n,pin=pin(P/n))for n in (PREFIX+'.html',PREFIX+'-summary.json',PREFIX+'-data.json',PREFIX+'-protocol.svg',PREFIX+'-source-review.json',PREFIX+'-grant-review.json',PREFIX+'-saved-review.json',PREFIX+'-next-design.json',PREFIX+'-evidence.tar.gz')],reader=pin(reader),archive_members=len(files)+1,archive_regular_source_bytes=sum(row['source']['bytes']for row in pathmap),raw_actual=raw_manifest,adoption=pin(adoption_path),all_partials_raw_bytes_only=True,archive_pathmap_sha256=hashlib.sha256(json.dumps(pathmap,sort_keys=True,indent=2).encode()+b'\n').hexdigest(),no_scientific_replay=True))
print(json.dumps(dict(page=pin(P/(PREFIX+'.html')),archive=pin(archive),summary=pin(P/(PREFIX+'-summary.json')),manifest=pin(P/(PREFIX+'-manifest.json'))),indent=2))
