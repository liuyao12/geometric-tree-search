"""Ordinary raw-custody metadata only. Never imports or calls subject code."""
from pathlib import Path
import hashlib,json,sys,shutil
R=Path(__file__).resolve().parent
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def pin(p):
 p=Path(p).resolve();raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def checked(p):
 assert pin(p['path'])==p
 return Path(p['path']).read_bytes()
def save(name,v):
 p=R/name;assert not p.exists();p.write_bytes(canonical(v)+b'\n');return pin(p)
assert len(sys.argv)==3
review_path=Path(sys.argv[1]).resolve();assert pin(review_path)['sha256']==sys.argv[2]
review=json.loads(review_path.read_bytes())
offer=json.loads((R/'batch-Source-only-offer-v2.json').read_bytes())
assert offer['subject_sha256']=='5c41ecdc77f6f88296614dff482c6187de13301a178c745a6b12e903de66467c'
subject=offer['subject'];subject_sha=hashlib.sha256(canonical(subject)).hexdigest()
assert subject_sha==offer['subject_sha256']
assert review['schema']=='wang-encoding-Source-prospective-review-v1'
assert review['reviewer_identity']=='/root/recovered_batch_review'
assert review['review_passed']is True and review['source_only']is True
assert review['status']=='PASS_SOURCE_PROSPECTIVE_ONLY_NOT_GRANTED'
assert review['failed_checks']==[] and len(review['manual_Source_findings'])==14
assert type(review['component_calls'])is int and review['component_calls']==0
assert review['actual_execution_authorized']is False
assert review['subject']==subject and review['subject_sha256']==subject_sha
checked(subject['python'])
for p in subject['sources'].values():checked(p)
for p in subject['inputs']:checked(p['pin'])
checked(subject['declaration']);closure=json.loads(checked(subject['runtime_closure']))
for p in closure['stdlib_files']:checked(p)
assert not Path(subject['actual_directory']).exists()
assert not (R/'batch-plan-authorized-v2-terminal-observation').exists()
barrier=json.loads((R/'barrier-before-grant-v1.json').read_bytes())
assert barrier['other_agents_tools_stopped']is True and barrier['no_subject_execution_yet']is True
assert shutil.disk_usage(R).free>2*1024*1024*1024
auth=dict(schema='ROOT-wang-encoding-authorization-v1',author_identity='/root',
 actual_execution_authorized=True,maximum_actual_invocations=1,
 subject_sha256=subject_sha,review=pin(review_path),
 scope='Exactly one Root-owned complete v2 batch/point-graph calibration with the unchanged whole original and new banks and original numeric limits. No prior negative rescue, fixture/sizing/probe or repeated invocation. Resource and finite component admission still require complete saved gates and terminal review; no theorem, RL, fixed physical interpreter or production fit authority.')
authorization=save('batch-authorization-once-v2.json',auth)
plan=save('batch-plan-authorized-v2.json',dict(subject,authorization=authorization))
receipt=save('ROOT-grant-issuance-v2.json',dict(schema='ROOT-exact-once-grant-issuance-v1',
 author_identity='/root',source_only=True,subject_imports=0,subject_calls=0,
 subject_sha256=subject_sha,review=pin(review_path),barrier=pin(R/'barrier-before-grant-v1.json'),
 original_prospective_plan=offer['prospective_plan'],authorization=authorization,plan=plan,
 actual_directory_absent_at_issuance=True,all_raw_pins_rechecked=True,
 maximum_actual_invocations=1,previous_grants='All remain retired; this is a distinct complete successor subject.'))
print(json.dumps(dict(plan=plan,authorization=authorization,issuance=receipt),indent=2))
