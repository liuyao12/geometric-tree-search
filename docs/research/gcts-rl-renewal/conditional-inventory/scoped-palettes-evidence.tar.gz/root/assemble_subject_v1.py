"""Source/AST/unused compilation and ordinary experiment metadata only."""
from pathlib import Path
import ast,hashlib,json,sys,datetime
D=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-batch-20261020');R=D/'root'
def pin(p):
 p=p.resolve();b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode('utf8')
def save(name,v):
 p=R/name;assert not p.exists();p.write_bytes(json.dumps(v,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False).encode()+b'\n');return pin(p)
def verify(d):assert pin(Path(d['path']))==d
B=json.loads((D/'components-B/handoff-v2.json').read_bytes());L=json.loads((D/'diagnostics-L/handoff-v1.json').read_bytes())
verify(B['current_worker']);verify(B['current_component'])
fragment_path=D/'diagnostics-L/new_diagnostics.fragment.py';fragment=fragment_path.read_text();assert pin(fragment_path)['sha256']=='195f8fc60f67bd0dd520ac3655af92832e918926d8bb9a40926bc4ca598a4d89'
base_path=Path(B['current_worker']['path']);base=base_path.read_text();tree=ast.parse(base)
stub=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='run_new_diagnostics'];assert len(stub)==1
stub=stub[0];lines=base.splitlines(keepends=True);old=''.join(lines[stub.lineno-1:stub.end_lineno])
assert 'need(False' in old and base.count(old)==1
combined=base.replace(old,fragment.rstrip()+'\n',1)
version=[n for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='VERSION'for t in n.targets)]
assert len(version)==1
old_version=ast.literal_eval(version[0].value);new_version='complete-implicit-batch-Root-integrated-worker-v1'
assert combined.count("VERSION = '"+old_version+"'")==1
combined=combined.replace("VERSION = '"+old_version+"'","VERSION = '"+new_version+"'",1)
worker=R/'qualify_complete_batch_worker_v1.py';assert not worker.exists();worker.write_text(combined)
ct=ast.parse(combined);code=compile(ct,str(worker),'exec');del code
names=[n.name for n in ct.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))];assert len(names)==len(set(names))
assembly=save('Root-Source-assembly-v1.json',{'schema':'Root-exact-Source-assembly-v1','author_identity':'/root','base':pin(base_path),'fragment':pin(fragment_path),'replaced_refusing_stub':old,'old_VERSION':old_version,'new_VERSION':new_version,'result':pin(worker),'source_only':True,'subject_imports':0,'subject_calls':0,'AST_unused_compile':True,'full_inverse':combined.replace(fragment.rstrip()+'\n',old,1).replace("VERSION = '"+new_version+"'","VERSION = '"+old_version+"'",1)==base})
olddecl=json.loads((D/'recovered/ROOT/implicit-declaration-v1.json').read_bytes());bankpath=D/'diagnostics-L/new-diagnostic-bank-v1.json';bank=json.loads(bankpath.read_bytes())
oldinput=D/'recovered/ROOT/implicit-inputs-v1.json'
assert pin(oldinput)['sha256']=='10fe60d005a2f586a76bf69ae30317b8dae538ba9f126714b9f71ffa474a89b4'
assert bank['original_bank']==pin(oldinput) and len(bank['groups'])==28 and sum(len(g['variants'])for g in bank['groups'])==55
inputs=[{'id':'whole-implicit-palette-point-graph-bank','pin':pin(oldinput)},{'id':'complete-new-batch-summary-diagnostic-bank','pin':pin(bankpath)}]
decl=dict(olddecl);decl.update(experiment_kind='COMPLETE_IMPLICIT_BATCH_AND_POINT_GRAPH_CALIBRATION',inputs=inputs,profile_limits=dict(olddecl['component_limits']['implicit'],queries=1000000,receipt_items=2000000),profile_query_chunk=128,profile_granularity='PROFILE_ENTRY_EXIT_PLUS_LOCAL_QUERY_GUARDS_V1',batch_diagnostic_groups=bank['groups'],batch_diagnostic_group_count=28,batch_diagnostic_variant_count=55)
decl.update(question='Qualify the complete implicit Wang palette/point adapter through explicitly scoped preparation while preserving the full original bank and independently testing lifetime, exact faults, custody, typed reconciliation and scalar diagnostics.',current_tracked_master=pin(D/'publisher/docs/basic-tiling-algorithm.md'),primary_working_master_bytes_available=False,master_conformance=pin(R/'master-conformance-v1.json'),Source_assembly=assembly)
decl['small_scope']=olddecl['small_scope']+' All original ordered count/all independent-rank requests retained in deterministic128request chunks. Each scope repeats complete descriptor preparation and custody; no crossscopewarmstate or trimmed query population.'
decl['diagnostics_scope']=olddecl['diagnostics_scope']+' Separate predeclared28groups/55variants add batch lifetime/refusal/primary identity and pure scalar-summary-builder cases. No summary writer or persistence test.'
decl['retention']='Whole original/new inputs and all original mathematical data retained. Canonical packet holds full normal case/graph values, all profile ordinary lifetimes, raw query receipts and exact preimages, full diagnostic run data/progress and all profile accounting. Component return duplicates are explicit per-row field bindings; conservative full-minus-compact byte deltas are charged to original expanded128MiB cap. Actual callback/Work/error/return objects remain owned through final custody; bounded nonliteral metadata is not Python reconstruction. Result q is a summary and never a substitute for the complete canonical packet. Failure summary first then full ordinary prefix best effort; parent180 can interrupt all writes, no guarantee of grace.'
decl['runtime_trust']='Exclusive ordinary Source/input ownership and read-only callbacks, with explicit controlled diagnostic mutations. Full raw Source/module function/code/default/closure-owner checks at profile entry/exit; local full literal query/descriptor/limit/query-function checks throughout. Worker and component Source files pinned, full final input/Source custody. Closure owner identity is not deep mutable-global/default-content/concurrent adversary sealing. SourceFileLoader/pyc/builtin/frozen/transitive stdlib/OS loader/interpreter trusted. Internal graph query ticks route exact graph charged_check; preparation/reconciliation use Root checks.'
decl['profile_cost_semantics']='Complete profile costs exact: cumulative=kernel+overhead; overhead=preparation+postpreparation. Completed-scope produced/preimage/delivered/attempted populations equal. Failed profile rows retain distinct counters and unavailable values. palette_attempted_work_known_total excludes explicitly counted constructor-prefix gaps; not fabricated zero or full private-work total. Root cumulative400m and absolute clocks apply throughout; these units are not CPU work.'
decl['graph_quota_semantics']='If a genuine graph SearchLimit occurs inside a B query, B latches and rethrows it at scope exit even if graph.search returned UNKNOWN. That profile fails and cannot establish UNSAT. Original work1 UNKNOWN diagnostic fires before any Bquery and retains its old semantics; no new runtime claim of the inside-query case without a declared reached diagnostic.'
decl['environment_comparison']='Current interpreter raw pin changed from historical21a998 to b6ea0c2a although reported3.12.14 unchanged; no causal speedup comparison to old failed run.'
declaration=save('batch-declaration-v1.json',decl)
python=pin(Path(sys.executable));assert python['sha256']=='b6ea0c2a9bfce48dbf181a53f1ca4f0562d40658b85bf47258e2a88d8f9e3933'
sources={'worker':pin(worker),'implicit':B['current_component'],'graph':pin(D/'recovered/L/implicit_wang_point_search_v1.py'),'selector':pin(D/'recovered/inherited-Source/wang_unknown_certificate_initializer_v1.py'),'runner':pin(R/'run_batch_once_v1.py'),'observer':pin(R/'observe_batch_once_v1.py')}
census=[]
for role,d in sources.items():
 raw=Path(d['path']).read_bytes();t=ast.parse(raw,filename=d['path']);unused=compile(t,d['path'],'exec');del unused
 imports=set()
 for n in ast.walk(t):
  if isinstance(n,ast.Import):imports.update(x.name for x in n.names)
  if isinstance(n,ast.ImportFrom):imports.add(n.module)
 census.append({'role':role,'source':d,'AST_sha256':hashlib.sha256(ast.dump(t,annotate_fields=True,include_attributes=False).encode('utf8')).hexdigest(),'direct_imports':sorted(imports)})
oldclosure=json.loads((D/'recovered/ROOT/implicit-runtime-closure-v2.json').read_bytes())
stdlib=[pin(Path(x['path']))for x in oldclosure['stdlib_files']]
parser=dict(author_identity='/root',command_flags=['-I','-S','-B'],digest='sha256',execution='AST parse and unused compile only; no Source import/exec/call',implementation=sys.implementation.name,parse=dict(feature_version=None,mode='exec',type_comments=False),python=python,serialization='ast.dump(tree, annotate_fields=True, include_attributes=False).encode(utf8)',version=sys.version)
closure=save('batch-runtime-closure-v1.json',dict(schema='ROOT-wang-encoding-runtime-closure-v1',source_only=True,actual_execution_authorized=False,python=python,sources=sources,declaration=declaration,stdlib_files=stdlib,direct_import_census=census,AST_parser=parser,runtime_trust=decl['runtime_trust']))
subject=dict(schema='ROOT-wang-encoding-qualification-plan-v1',invocation_id='complete-batched-implicit-palette-point-graph-v1',actual_directory=str(R/'actual-batch-v1'),python=python,sources=sources,inputs=inputs,limits=decl['limits'],declaration=declaration,runtime_closure=closure)
sha=hashlib.sha256(canonical(subject)).hexdigest()
auth=save('batch-authorization-prospective-false-v1.json',dict(schema='ROOT-wang-encoding-authorization-v1',author_identity='/root',actual_execution_authorized=False,maximum_actual_invocations=0,subject_sha256=sha,review=None,scope='Source-only prospective offer; no experiment authority.'))
plan=save('batch-plan-prospective-v1.json',dict(subject,authorization=auth))
offer=save('batch-Source-only-offer-v1.json',dict(schema='ROOT-batch-Source-only-offer-v1',author_identity='/root',source_only=True,actual_execution_authorized=False,subject=subject,subject_sha256=sha,prospective_plan=plan,false_authorization=auth,Source_assembly=assembly,current_master=decl['current_tracked_master'],conformance=decl['master_conformance'],B_handoff=pin(D/'components-B/handoff-v2.json'),L_handoff=pin(D/'diagnostics-L/handoff-v1.json'),C_recovered_stage=pin(D/'review-C/handoff-recovered-stage-v3.json'),recovery=pin(D/'recovery-manifest.json'),runtime_identity=pin(R/'ROOT-current-runtime-identity-v1.json'),old_grants='All retired; no rescue or reexecution.',no_subject_calls_outside_actual=True))
print(json.dumps({'worker':pin(worker),'subject_sha256':sha,'offer':offer,'declaration':declaration,'closure':closure,'all_ASTs_unused_compile':True,'actual_calls':0},indent=2))
