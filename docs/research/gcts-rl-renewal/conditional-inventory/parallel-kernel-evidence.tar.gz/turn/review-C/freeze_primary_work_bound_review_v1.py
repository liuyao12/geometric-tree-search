"""Reviewer metadata only. Never import or call any research Source."""
import ast
import hashlib
import json
from pathlib import Path

N = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-linked-evidence-20261020')
O = N / 'review-C'
C = O / 'primary-work-bound-Sources-v1'
C.mkdir(exist_ok=True)
checks = []

def need(name, condition):
    checks.append(dict(check=name, passed=bool(condition)))
    if not condition:
        raise ValueError(name)

def pin(path):
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

def exact(row):
    path = Path(row['path'])
    need('No partial path: ' + path.name, '.partial' not in path.name)
    actual = pin(path)
    need('Exact raw pin: ' + path.name, actual == row)
    return path

hpath = N / 'bounds-B/handoff-v1.json'
need('Exact frozen handoff', pin(hpath)['sha256'] == 'a7b30e63d9c3e669115fec37d44693f686ccc49a33ace2af8a372c03953c95ef'
     and pin(hpath)['bytes'] == 7481)
h = json.loads(hpath.read_bytes())
dependency_pins = []
for name, row in h['pins'].items():
    path = exact(row)
    dependency_pins.append(dict(role=name, **row))
    if name != 'python':
        dest = C / (name + '-' + path.name)
        need('Fresh dependency copy: ' + name, not dest.exists())
        dest.write_bytes(path.read_bytes())
for row in h['artifacts']:
    path = exact(row)
    dest = C / path.name
    need('Fresh bound copy: ' + path.name, not dest.exists())
    dest.write_bytes(path.read_bytes())
(C / 'handoff-v1.json').write_bytes(hpath.read_bytes())
b = json.loads((C / 'full-cohort-count-and-work-bound-v1.json').read_bytes())
failure = json.loads((C / ('old_complete_failure-worker-failure.json')).read_bytes())
cutoff = json.loads((C / 'old_cutoff_metadata-cutoff-metadata-v1.json').read_bytes())
bank = json.loads((C / 'original_bank-implicit-inputs-v1.json').read_bytes())
need('Complete failure cutoff', failure['stage'] == 'FULL_PACKET_WRITE'
     and failure['root_check_calls'] == 324982843
     and failure['first_available_fault'] == dict(message='whole JSON packet cap', type='PolicyFailure'))
need('All counter maps copied exactly', all(failure[k] == cutoff[k] for k in ('call_started','call_completed','call_raised')))
need('All original normal ids completed', failure['completed_case_ids'] == b['complete_cutoff_joins']['completed_case_ids']
     and len(failure['completed_case_ids']) == 15)
need('No complete positive output', failure['outputs'] == [] and failure['full_pipeline_qualified'] is False
     and failure['mathematical_proof_accepted'] is False)
retirement = json.loads((C / 'old_retirement-ROOT-grant-retirement-v2.json').read_bytes())
need('Raw length pin retained in complete retirement metadata',
     '124780541' in json.dumps(retirement)
     and '49baf9b389b81f710893f6d88754e86dead98184394332fb8ae1637b669a4231' in json.dumps(retirement))

# Literal input metadata counts and arithmetic; no tile generation or simulation.
rows = []
for source in bank['small_palettes']:
    m = source['machine']
    alphabet = m['alphabet_size']
    states = m['state_count']
    defined = len(m['transitions'])
    stationary = sum(1 for item in m['transitions'] if item[4] == 0)
    step = alphabet * (alphabet + 1) ** 2 + 3 * defined * alphabet * (alphabet + 1) + stationary * (alphabet + 1)
    nonstep = 12 * alphabet + 2 * alphabet * (states + 1) + 18
    rows.append(dict(id=source['id'], b=alphabet, q=states, d=defined, s=stationary,
        step=step, nonstep=nonstep, total=step+nonstep, selects=16*(step+nonstep),
        step_selects=16*step, request_upper=32*(step+nonstep)+7,
        scope_upper=(32*(step+nonstep)+7+127)//128))
need('All four literal palette formula rows', rows == b['palette_formula']['table'])
need('Small select populations', sum(r['selects'] for r in rows) == 29472
     and sum(r['step_selects'] for r in rows) == 23136)
legacy_graph = [r for r in bank['diagnostics'] if r['role'] == 'graph']
need('Thirteen legacy graph profiles', len(legacy_graph) == 13
     and [r['id'] for r in legacy_graph] == [r['id'] for r in cutoff['graph_legacy_diagnostic_metadata']])
need('Wrapper population', cutoff['call_started']['implicit.with_profile'] == 345
     and cutoff['call_completed']['implicit.with_profile'] == 333
     and cutoff['call_raised']['implicit.with_profile'] == 12)
small_scopes = 345 - 1 - 10 - 13
requests_lower = 128*(small_scopes-4)+4
count_lower = requests_lower-29472
need('Deterministic chunk lower bound', small_scopes == 321 and requests_lower == 40580 and count_lower == 11108)
need('Manual receipt and preimage arithmetic', 8*123+5*336 == 2664
     and 8*77+5*198 == 1606 and 8*13+5*27 == 239)
copies = 23136*2664 + 6336*1606 + count_lower*239
scopes = requests_lower*6*16
write_upper = 124780541//1024
old_lower = 324982843-write_upper-1024
total = old_lower+copies+scopes
need('Primary work arithmetic', copies == 74464732 and scopes == 3895680
     and write_upper == 121855 and old_lower == 324859964
     and total == 403220376 and total-400000000 == 3220376)
need('Author primary values', h['callback_lower'] == total and h['excess_lower'] == 3220376
     and b['primary_conditional_conclusion']['whole_required_Root_checks_lower'] == total)

oldtext = (C / 'old_worker-qualify_complete_batch_worker_v2.py').read_text()
newtext = (C / 'frozen_worker_v1-qualify_linked_batch_worker_v1.py').read_text()
oldtree = ast.parse(oldtext)
newtree = ast.parse(newtext)
oldfunc = {x.name:x for x in oldtree.body if isinstance(x,ast.FunctionDef)}
newfunc = {x.name:x for x in newtree.body if isinstance(x,ast.FunctionDef)}
for name in ('qualify_small_palette','qualify_large_palette'):
    newnode = newfunc['_original_'+name]
    saved = newnode.name
    newnode.name = name
    need('Unchanged original body: ' + name,
         ast.dump(oldfunc[name],include_attributes=False) == ast.dump(newnode,include_attributes=False))
    newnode.name = saved
oldsession = next(x for x in oldtree.body if isinstance(x,ast.ClassDef) and x.name == 'Session')
newsession = next(x for x in newtree.body if isinstance(x,ast.ClassDef) and x.name == 'Session')
for name in ('check','guard','policy'):
    a = next(x for x in oldsession.body if isinstance(x,ast.FunctionDef) and x.name == name)
    c = next(x for x in newsession.body if isinstance(x,ast.FunctionDef) and x.name == name)
    need('Unchanged original Root method: ' + name,
         ast.dump(a,include_attributes=False) == ast.dump(c,include_attributes=False))
static = []
for name in ('old_worker-qualify_complete_batch_worker_v2.py','old_component-implicit_wang_batch_v2.py',
             'frozen_worker_v1-qualify_linked_batch_worker_v1.py','frozen_hook-implicit_wang_linked_v1.py',
             'frozen_producer-linked_evidence_v1.py','json_encoder-encoder.py'):
    path = C/name
    tree = ast.parse(path.read_bytes())
    compile(tree,str(path),'exec')
    static.append(dict(pin=pin(path), AST_parse=True, unused_compile=True, executed=False))

findings = [
    dict(id='Old cutoff provenance', argument='Complete failure and retirement metadata retain the callback cutoff, full counter maps, original completed ids, empty outputs and raw partial length/hash. The partial was never opened. This is negative historical metadata, not admission.'),
    dict(id='JSON part boundary', argument='Old write_json increments parts only after cap acceptance and output.write; self.check follows each successful multiple of 1024. A final cap-failing part contributes no check. There is no successful final check because this write failed. Root raised a possible extra-check question, then resolved it from these exact lines; this review independently agrees.'),
    dict(id='Nonempty parts', argument='Pinned Python JSONEncoder.iterencode defaults _one_shot=False, selects _make_iterencode, indent None, comma/colon separators, ensure_ascii True. Every yielded literal/string/number/punctuation/buffer part has positive ASCII length; strings have quotes even when empty and compact list buffers are opening bracket or comma. Thus successful-part count is at most raw byte length. No decoder or encoder was run.'),
    dict(id='Intake exclusion', argument='Before qualification: initial Root check, completed small WORKER_CONSUMED write, three module loads with entry and two guard checks each, and final prewrite guard. Failure-summary construction/writing has no Root.check. The exclusion 1024 exceeds the manually counted fixed 13 checks and safely excludes this intake rather than adding a resource allowance.'),
    dict(id='Palette formula', argument='Disjoint Source families give step b(b+1)^2+3db(b+1)+s(b+1); base collectors/frame rows plus initializer give nonstep 12b+2b(q+1)+18. Four literal input declarations agree with all authored counts. This is a manual Source argument, not execution of the cardinality helper.'),
    dict(id='Every mask witness', argument='The original small qualification inserts each tile into all sixteen masks and selects every rank of every resulting bucket. Merged equal masks preserve their full tile lists. Consequently each tile contributes sixteen select occurrences, irrespective of mask sharing. Original small and large qualification function AST bodies are unchanged after renaming.'),
    dict(id='Scope membership', argument='Complete saved counters give 345 wrapper profiles. Source gives one large, ten normal graph and thirteen legacy graph profiles. New batch diagnostics use distinct counters. All small cases completed; the remainder is 321 nonempty small scopes across four independently chunked request streams. This establishes the interval lower bound 40580, not an invented exact request count.'),
    dict(id='Raw selected nodes', argument='Generic selected tile has at least t6, m29, id3, origin1, edges9, kind1, six keys and dictionary root7: tile56 and receipt66. Step wall/plain/wall has origin8, id10, edges25, t6, m45, kind1 and keys/root7: tile102 and receipt112. Other step alternatives only increase these minima. Receipt and tile dictionaries add eleven key-loop checks.'),
    dict(id='Count and typed nodes', argument='Count receipt has dictionary root plus four keys/four scalar values, giving nine native nodes and four key-loop checks. _receipt_tree maps each non-None native node to a tag/payload pair plus payload carrier, exactly three traversal nodes per original node. These count/select receipts have no None leaves. Thus typed lower counts are 27, 198 and 336.'),
    dict(id='Copy multiplicity', argument='Produced snapshot traverses raw receipt twice; preimage snapshot raw once and typed twice; delivered snapshot raw twice and typed once; query return raw once; profile return result and lifetime traverse raw twice and typed twice. literal_copy has cycle detection only, no alias cache: every occurrence is visited independently. This yields eight raw and five typed copies, excluding all reconciliation version copies and other positive work.'),
    dict(id='Scope disjointness', argument='Every completed query has six separate enter/registered/produced/preimage/delivered/return scope copies. A five-key scalar/None scope costs dictionary node plus five key-loop checks plus ten key/value nodes, at least sixteen checks. Those scope traversals are disjoint from receipt/preimage payload traversals.'),
    dict(id='Conditional additivity', argument='The claimed total is conditional on preserving the historical complete same-bank semantic/query/private-tick and original Root guard/call stream. Source wrappers are observational additions and Root check/guard/policy methods are AST identical. Any earlier genuine fault prevents completion instead. This is not a new measured call total or a mechanically proved all-path refinement.'),
    dict(id='Custody successor', argument='The reviewed named-owner v2 changes only the seal/version, retaining the same journal hook and copies. It cannot remove this copying-work obstruction. Snapshot key correction is separate and cannot refund checks.'),
    dict(id='Design consequence', argument='The one-owner successor note correctly proposes versioned immutable full values with separately retained raw owners and per-event ordinal/scope/role references. Such a different implementation can remove this particular repeated-copy premise; it still needs complete correspondence, independent validator, custody, resource bounds and explicit changed-gate adoption. No fit follows from this note.')
]
out = dict(
    schema='typed-primary-copying-journal-work-bound-Source-review-v1',
    reviewer_identity='/root/recovered_batch_review',
    status='PASS_CONDITIONAL_PRIMARY_WORK_OBSTRUCTION_ONLY', review_passed=True,
    source_only=True, handoff=pin(C/'handoff-v1.json'), dependency_pins=dependency_pins,
    source_copies=[pin(p) for p in sorted(C.iterdir())], static_metadata=static,
    manual_findings=findings,
    primary_bound=dict(old_qualification_lower=old_lower, new_small_payload_lower=copies,
        new_small_scope_lower=scopes, total_lower=total, unchanged_limit=400000000, excess_lower=3220376),
    conclusion='Under the explicit complete same-bank Source/cutoff preservation premise, the frozen copying journal cannot complete this full fixed cohort within the original Root callback cap, before codec/schema work. A new invocation was neither made nor needed for this conditional obstruction.',
    not_reviewed_as_part_of_this_PASS=['Concrete graph trace/solution/board operational counts in the author note.',
        'The secondary canonical DAG byte lower bound and exact sharing classes.',
        'Any resident-memory, whole-byte, elapsed-time upper bound or fit claim.',
        'The complete schema/outer-controller offer or one-owner successor implementation.'],
    resolved_review_question=dict(subject='Possible callback on final failing JSON part',
        outcome='No additional callback: cap rejection precedes write, part increment and modulo guard.',
        scientific_negative=False),
    retained_negatives=[pin(O/'typed-linked-parent-Source-custody-negative-v1.json'),
        pin(O/'typed-linked-parent-snapshot-schema-negative-v1.json')],
    checks=checks, failed_checks=[], actual_execution_authorized=False,
    subject_imports=0, subject_calls=0, helper_calls=0, compiler_calls=0, checker_calls=0,
    fixture_calls=0, simulator_calls=0, generator_calls=0, sizing_probes=0, semantic_replays=0,
    partial_files_opened=0, partial_parses=0, new_actuals=0, new_grants=0,
    G1_adopted=False, old_G0_negative_unchanged=True, runtime_qualified=False,
    full_VM_qualified=False, new_theorem=False, GCTS_RL_advantage_established=False,
    full_offer_review_completed=False, goal_status='active',
    primary_reader_index_active_mutated=False, frozen_offered_files_mutated=False,
    author=pin(Path(__file__)), tools_stopped_after_freeze=True)
path=O/'typed-primary-copying-journal-work-bound-Source-review-v1.json'
need('Fresh review',not path.exists())
path.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(review=pin(path),checks=len(checks)),sort_keys=True))
