"""Source authoring only: text replacement; no Subject imported or called."""
from pathlib import Path
B=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs')
O=B/'gcts-linked-evidence-20261020/schema-B'
old=(B/'gcts-batch-20261020/components-B/implicit_wang_batch_v2.py').read_text()
n=old.replace('def with_profile(descriptor, body, *, check, limits, custody, retain):',
 'def with_profile(descriptor, body, *, check, limits, custody, retain, evidence=None):',1)
n=n.replace('    def query(request):\n',"""    # Proposed G1 observation is new Source behavior; standalone APIs untouched.
    def notify(stage, request=None, value=None, error=None):
        if evidence is not None:
            if not callable(evidence):
                raise _bad('evidence callback must be callable or None')
            if evidence(stage,state,request,value,error) is not None:
                raise _bad('evidence callback must return None')

    original_custody=custody
    def observed_custody(phase):
        notify('CUSTODY_ENTER',value=phase)
        try:
            result=original_custody(phase)
        except BaseException as primary:
            try:notify('CUSTODY_RAISE',value=phase,error=primary)
            except BaseException:pass
            raise
        notify('CUSTODY_RETURN',value=(phase,result))
        return result
    custody=observed_custody

    def _query_core(request):
""",1)
n=n.replace("            _batch_bound(state, 'queries', state['attempted_queries'])",
 "            notify('QUERY_REGISTERED',request=request)\n            _batch_bound(state, 'queries', state['attempted_queries'])",1)
for needle,extra in [
 ("            state['active_query']['stage'] = 'RETAINING_EXACT_RECEIPT'","            notify('QUERY_PRODUCED',request=request,value=receipt)"),
 ("            state['preimage_completed_count'] += 1","            notify('QUERY_PREIMAGE',request=request,value=expected)"),
 ("            state['delivered_receipt_count'] += 1","            notify('QUERY_DELIVERED',request=request,value=receipt)")]:
 assert needle in n
 n=n.replace(needle,needle+'\n'+extra,1)
n=n.replace('    def prefix():\n',"""    def query(request):
        notify('QUERY_ENTER',request=request)
        try:
            result=_query_core(request)
        except BaseException as primary:
            try:notify('QUERY_RAISE',request=request,error=primary)
            except BaseException:pass
            raise
        notify('QUERY_RETURN',request=request,value=result)
        return result

    def prefix():
""",1)
n=n.replace("    try:\n        if not callable(body) or not callable(custody) or not callable(retain):",
 "    try:\n        notify('PROFILE_ENTER')\n        if not callable(body) or not callable(original_custody) or not callable(retain):",1)
n=n.replace("            if not _same_receipt_tree(actual, state['expected_receipts'][position], work):",
 "            notify('RECONCILE_VERSION',value=(position,state['expected_receipts'][position],actual))\n            same=_same_receipt_tree(actual,state['expected_receipts'][position],work)\n            notify('RECONCILE_RESULT',value=(position,same))\n            if not same:",1)
n=n.replace("        return dict(schema='implicit-wang-profile-receipt-v1',","        result = dict(schema='implicit-wang-profile-receipt-v1',",1)
needle="                    authority=False, executed_source_qualified=False)\n    except BaseException as primary:"
assert needle in n
n=n.replace(needle,"                    authority=False, executed_source_qualified=False)\n        notify('PROFILE_RETURN',value=result)\n        return result\n    except BaseException as primary:",1)
needle="            primary.implicit_palette_batch_prefix = prefix()\n        except BaseException:\n            pass\n        raise\n"
assert needle in n
n=n.replace(needle,"            primary.implicit_palette_batch_prefix = prefix()\n        except BaseException:\n            pass\n        try:notify('PROFILE_RAISE',error=primary)\n        except BaseException:pass\n        raise\n",1)
n=n.replace('def batch_query(descriptor, requests, *, check, limits, custody, retain):',
 'def batch_query(descriptor, requests, *, check, limits, custody, retain, evidence=None):',1)
n=n.replace('                        custody=custody, retain=retain)\n',
 '                        custody=custody, retain=retain, evidence=evidence)\n',1)
(O/'implicit_wang_linked_v1.py').write_text('"""UNEXECUTED G1 profile event-hook successor; predecessor unchanged. """\n'+n)
w=(B/'gcts-batch-20261020/root/qualify_complete_batch_worker_v2.py').read_text()
w=w[:w.index('\ndef main(plan_path):')]
w=w.replace("VERSION = 'complete-implicit-batch-Root-integrated-worker-v2'","VERSION = 'proposed-linked-complete-batch-worker-v1'",1)
w=w.replace("        self.worker_function_seal=callable_seal(sys.modules[__name__])",
 "        self.evidence=None\n        self.evidence_scope=dict(case_id=None,profile_id=None,group_id=None,variant_id=None,origin='wrapper')\n        self.evidence_runtime_owners=[]\n        self.worker_function_seal=callable_seal(sys.modules[__name__])",1)
w=w.replace('    def call(self,role,name,data,action,expected_after=None):',
 '    def _original_call(self,role,name,data,action,expected_after=None):',1)
i=w.index('    def load(self,role):')
w=w[:i]+"""    def call(self,role,name,data,action,expected_after=None):
        need(self.evidence is not None,'linked journal installed before subject calls')
        self.evidence_runtime_owners.append((data,action,expected_after))
        args=data() if callable(data) else data
        return _evidence_invoke(self,'CALL',role,name,args,
            lambda:self._original_call(role,name,data,action,expected_after),
            after=lambda:data() if callable(data) else data)

"""+w[i:]
w=w.replace("    context['owners'].extend((dispatcher,custody,retain,registered))",
 "    event_hook=_profile_evidence(s,profile_id,'wrapper')\n    context['owners'].extend((dispatcher,custody,retain,registered,event_hook))",1)
w=w.replace('            limits=bound,custody=custody,retain=retain)',
 '            limits=bound,custody=custody,retain=retain,evidence=event_hook)',1)
w=w.replace('    def observe(snapshot):\n','    def _observe_core(snapshot):\n',1)
needle="        need(argument_bytes(snapshot)==before,'read-only independent observer')\n"
assert needle in w
w=w.replace(needle,needle+"""    def observe(snapshot):
        return _evidence_invoke(s,'OBSERVATION','graph','observe',snapshot,
            lambda:_observe_core(snapshot),after=lambda:snapshot)
""",1)
w=w.replace("    owner['callbacks'].update(state_now=state_now, fire=fire, check=check,",
 "    event_hook=_profile_evidence(s,run_label,'diagnostic')\n    owner['callbacks']['evidence']=event_hook\n    owner['callbacks'].update(state_now=state_now, fire=fire, check=check,",1)
w=w.replace('lambda: m.batch_query(desc, requests, check=check, limits=limits, custody=custody, retain=retain))',
 'lambda: m.batch_query(desc, requests, check=check, limits=limits, custody=custody, retain=retain,evidence=event_hook))',1)
w=w.replace('lambda: m.with_profile(desc, body, check=check, limits=limits, custody=custody, retain=retain))',
 'lambda: m.with_profile(desc, body, check=check, limits=limits, custody=custody, retain=retain,evidence=event_hook))',1)
for name,kind in (('qualify_small_palette','CASE'),('qualify_large_palette','CASE'),('qualify_graph','CASE'),('diagnostic','LEGACY_DIAGNOSTIC')):
 w=w.replace('def '+name+'(','def _original_'+name+'(',1)
 if name=='diagnostic':
  w+="""\ndef diagnostic(s,d,inputs):
    return _evidence_invoke(s,'LEGACY_DIAGNOSTIC',d['role'],d['operation'],d,
        lambda:_original_diagnostic(s,d,inputs),case_id=d['id'])
"""
 else:
  w+='\ndef '+name+"(s,record):\n    return _evidence_invoke(s,'CASE','worker','"+name+"',record,\n        lambda:_original_"+name+"(s,record),case_id=record['id'])\n"
w=w.replace("    for group in bank['groups']:\n        s.check(); s.fault_gate()",
 "    for group in bank['groups']:\n        s.evidence_scope.update(group_id=group['id'],variant_id=None)\n        group_event=s.evidence.enter('DIAGNOSTIC_GROUP','worker',group['recipe'],group)\n        s.check(); s.fault_gate()",1)
w=w.replace("        for variant in group['variants']:\n            need(set(variant)",
 "        for variant in group['variants']:\n            s.evidence_scope['variant_id']=variant['id']\n            variant_event=s.evidence.enter('DIAGNOSTIC_VARIANT','worker',group['recipe'],variant)\n            need(set(variant)",1)
w=w.replace("            progress['variants'].append(row)\n",
 "            progress['variants'].append(row)\n            s.evidence.leave(variant_event,value=row)\n",1)
w=w.replace("        s.batch_diagnostic_progress['completed_group_ids'].append(group['id'])",
 "        s.batch_diagnostic_progress['completed_group_ids'].append(group['id'])\n        s.evidence.leave(group_event,value=completed)",1)
w=w.replace("    s.active = previous_active\n","    s.active = previous_active\n    s.evidence_scope.update(group_id=None,variant_id=None)\n",1)
w+='\n# Root integration functions are appended from a separate Source fragment.\n'
(O/'qualify_linked_batch_worker_v1.py').write_text(w)

