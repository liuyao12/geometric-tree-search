"""SOURCE ONLY independent parent schema/value/event validator.

Does not call the producer, its catalog builder, a subject or an oracle. The
already independently reviewed strict codec parses complete wire first. Root
provides original complete qualified objects as read-only comparison owners.
Every descendant is checked, including values not separately indexed below.
"""
VERSION = 'linked-complete-batch-validator-v1'
_OWNER = object()


class Invalid(Exception):
    def __init__(self, reason, *, _owner=None):
        self.reason, self._owner = reason, _owner
        super().__init__(reason)


def _require(ok, reason):
    if not ok:
        raise Invalid(reason, _owner=_OWNER)


def is_own_invalid(error):
    return type(error) is Invalid and error._owner is _OWNER


def _fields(value, names):
    _require(type(value) is dict and tuple(value)==names, 'exact ordered record fields')


def _equal(a, b, check):
    """Full strict typed correspondence, no producer helper or hash shortcut."""
    pending=[(a,b,0)]
    while pending:
        left,right,depth=pending.pop();check()
        _require(depth<=256 and type(left) is type(right), 'strict type/depth correspondence')
        kind=type(left)
        if left is None:
            continue
        if kind is float:
            _require(left.hex()==right.hex() and left.hex() not in ('nan','inf','-inf'), 'finite float-hex correspondence')
        elif kind in (str,int,bool):
            _require(left==right, 'full scalar correspondence')
        elif kind in (list,tuple):
            _require(len(left)==len(right),'full sequence population')
            for i in range(len(left)-1,-1,-1):
                pending.append((left[i],right[i],depth+1))
        elif kind is dict:
            _require(len(left)==len(right),'full mapping population')
            lr=list(left.items());rr=list(right.items())
            for i in range(len(lr)-1,-1,-1):
                pending.append((lr[i][1],rr[i][1],depth+1))
                pending.append((lr[i][0],rr[i][0],depth+1))
        else:
            _require(False,'unsupported exact parent value type')


def _uint(x):
    _require(type(x) is int and x>=0,'exact nonnegative counter')
    return x


def _at(root, path):
    _require(type(path) is tuple and path,'nonempty exact binding path')
    current=root
    for part in path:
        if type(current) is dict:
            _require(type(part) is str and part in current,'mapping path exists')
        else:
            _require(type(current) in (list,tuple) and type(part) is int and 0<=part<len(current),'sequence path exists')
        current=current[part]
    return current


def _catalog(packet, bindings, check):
    """Independent imperative expected path/role population; no producer call."""
    position=0
    def expect(path,role,case=None,profile=None,group=None,variant=None,run=None):
        nonlocal position
        check();_require(position<len(bindings),'missing required binding')
        row=bindings[position];position+=1
        _fields(row,('ordinal','path','role','case','profile','group','variant','run'))
        _equal((row['ordinal'],row['path'],row['role'],row['case'],row['profile'],row['group'],row['variant'],row['run']),
               (position,path,role,case,profile,group,variant,run),check)
        _at(packet,path)
    for field in ('schema','status','inputs','small_palettes','large_palette','graphs','diagnostics',
                  'call_receipts','call_started','call_completed','call_raised','root_callbacks','batch_inputs',
                  'profile_rows','profile_metrics','profile_accounting','batch_diagnostics','batch_diagnostic_progress',
                  'full_VM_implemented','full_FOL_palette_qualified','proof_discovery','full_pipeline_qualified',
                  'mathematical_authority','scope'):
        expect((field,),'predecessor-topfield')
    for i in range(len(packet['small_palettes'])):
        case=packet['small_palettes'][i];cid=case['id'];path=('small_palettes',i)
        expect(path,'normal-small',cid)
        for field in ('input','legacy_palette','semantic_tiles'):
            expect(path+(field,),'independent-'+field,cid)
        for j in range(len(case['queries'])):
            expect(path+('queries',j),'small-query-group',cid)
    cid=packet['large_palette']['id']
    expect(('large_palette',),'normal-large',cid)
    expect(('large_palette','legacy_cardinality'),'independent-cardinality',cid)
    for field in ('global_rank_samples','focused_families'):
        for i in range(len(packet['large_palette'][field])):
            expect(('large_palette',field,i),'large-'+field,cid)
    for i in range(len(packet['graphs'])):
        case=packet['graphs'][i];cid=case['id'];path=('graphs',i)
        expect(path,'normal-graph',cid)
        for field in ('input','instance','legacy_problem','independent_solution_ids'):
            expect(path+(field,),'independent-'+field,cid)
        for j in range(len(case['observations'])):
            expect(path+('observations',j),'graph-observation',cid)
            expect(path+('observations',j,'independent_domains'),'independent-domains',cid)
        for field in ('journal','query_journal','solutions'):
            for j in range(len(case['result'][field])):
                expect(path+('result',field,j),'graph-'+field,cid)
    for i in range(len(packet['diagnostics'])):
        expect(('diagnostics',i),'legacy-diagnostic',packet['diagnostics'][i]['id'])
    for i in range(len(packet['call_receipts'])):
        expect(('call_receipts',i),'standalone-call-receipt')
    for i in range(len(packet['profile_rows'])):
        expect(('profile_rows',i),'wrapper-profile',profile=packet['profile_rows'][i]['id'])
    for i in range(len(packet['profile_accounting'])):
        expect(('profile_accounting',i),'profile-accounting',profile=packet['profile_accounting'][i]['id'])
    for i in range(len(packet['batch_diagnostics'])):
        group=packet['batch_diagnostics'][i];gid=group['id'];path=('batch_diagnostics',i)
        expect(path,'new-diagnostic-group',group=gid)
        for j in range(len(group['variants'])):
            variant=group['variants'][j];vid=variant['id'];vpath=path+('variants',j)
            expect(vpath,'new-diagnostic-variant',group=gid,variant=vid)
            runs=variant.get('runs',[])
            for k in range(len(runs)):
                profile=vid+':baseline' if k==0 and group['recipe'] in ('work-cumulative','receipt-items-cumulative') else vid
                expect(vpath+('runs',k),'new-diagnostic-profile',profile=profile,group=gid,variant=vid,run=k)
    expect(('batch_diagnostic_progress',),'complete-progress-view')
    _require(position==len(bindings),'extra/unowned binding')


def _packet_population(p, check):
    _fields(p,('schema','status','inputs','small_palettes','large_palette','graphs','diagnostics','call_receipts',
        'call_started','call_completed','call_raised','root_callbacks','batch_inputs','profile_rows','profile_metrics',
        'profile_accounting','batch_diagnostics','batch_diagnostic_progress','full_VM_implemented',
        'full_FOL_palette_qualified','proof_discovery','full_pipeline_qualified','mathematical_authority','scope'))
    _require(p['schema']=='implicit-palette-graph-calibration-packet-v1' and
        p['status']=='COMPLETE_COMPONENT_CALIBRATION_CANDIDATE','predecessor candidate identity')
    for key in ('full_VM_implemented','full_FOL_palette_qualified','proof_discovery','full_pipeline_qualified','mathematical_authority'):
        _require(p[key] is False,'no broader claim')
    original=p['inputs'];batch=p['batch_inputs']
    _require(original['schema']=='implicit-palette-inputs-v1' and
        batch['schema']=='implicit-batch-summary-diagnostics-v1','whole unchanged bank schemas')
    _require(len(original['small_palettes'])==len(p['small_palettes'])==4 and
        len(original['graph_cases'])==len(p['graphs'])==10 and
        len(original['diagnostics'])==len(p['diagnostics'])==33,'entire15normal33legacy population')
    for i,case in enumerate(p['small_palettes']):
        _fields(case,('id','complete','input','descriptor','build','description','legacy_palette','semantic_tiles',
            'queries','nonempty_mask_queries','zero_mask_queries','selected_witnesses','full_literal_tile_count','scope'))
        _require(case['id']==original['small_palettes'][i]['id'] and case['complete'] is True,'small ordered case')
        _equal(case['input'],original['small_palettes'][i],check)
        _require(type(case['queries']) is list and type(case['semantic_tiles']) is list,'whole small literal arrays')
        _require(case['full_literal_tile_count']==len(case['semantic_tiles']) and
            case['selected_witnesses']==16*len(case['semantic_tiles']),'full small witness multiplicity')
        witnesses=0
        for j,query in enumerate(case['queries']):
            check();_fields(query,('index','mask','count','count_attempted_work','select_attempted_work','selected_tiles','complete'))
            _require(query['index']==j and query['complete'] is True and type(query['mask']) is tuple,'ordered full mask/rank group')
            _require(_uint(query['count'])==len(query['selected_tiles'])==len(query['select_attempted_work']),'all rank occurrences')
            witnesses+=query['count']
        _require(witnesses==case['selected_witnesses'],'witness conservation')
        _require(case['nonempty_mask_queries']==sum(row['count']!=0 for row in case['queries']) and
            case['zero_mask_queries']==sum(row['count']==0 for row in case['queries']),'mask populations')
    large=p['large_palette']
    _fields(large,('id','complete','input','descriptor','build','description','legacy_cardinality','total_count',
        'global_rank_samples','focused_families','fully_materialized','full_large_unranking_exhausted','scope'))
    _equal(large['input'],original['large_palette'],check)
    _require(large['id']==original['large_palette']['id'] and large['complete'] is True and
        large['fully_materialized'] is False and large['full_large_unranking_exhausted'] is False,'large scope unchanged')
    _require(len(large['global_rank_samples'])==3 and len(large['focused_families'])==19,'whole large bounded sequence')
    for i,case in enumerate(p['graphs']):
        check();_fields(case,('id','complete','input','instance','legacy_problem','result','observations',
            'independent_solution_ids','independent_solution_count','actual_solution_count','domain_checks','scope'))
        _equal(case['input'],original['graph_cases'][i],check)
        _require(case['id']==original['graph_cases'][i]['id'] and case['complete'] is True,'ordered graph population')
        result=case['result']
        _require(result['root_restored'] is True and result['final_observation_completed'] is True and
            result['status']!='UNKNOWN_SEARCH_LIMIT','normal graph complete/restored')
        _require(case['independent_solution_count']==len(case['independent_solution_ids']) and
            case['actual_solution_count']==len(result['solutions']),'whole independent solution populations')
        for observation in case['observations']:
            _fields(observation,('snapshot','independent_domains','complete'))
            _require(observation['complete'] is True,'full graph observation')
            snap=observation['snapshot']
            _require(type(snap) is dict and set(snap)=={'schema','reason','mode','descriptor','points','chosen','marks',
                'domains','exclusions','dependencies','branch_stack','scheduler','rollback_parent','work'},'full14snapshot fields')
    for i,row in enumerate(p['diagnostics']):
        declaration=original['diagnostics'][i]
        _require(row['id']==declaration['id'] and row['operation']==declaration['operation'] and
            row['role']==declaration['role'] and row['expected']==declaration['expected'] and row['status']=='PASSED',
            'unchanged legacy diagnostic row')
    _require(type(batch['groups']) is list and len(batch['groups'])==len(p['batch_diagnostics'])==28,'whole28newgroups')
    variant_count=0;run_count=0;run_ids=[]
    for i,group in enumerate(p['batch_diagnostics']):
        declared=batch['groups'][i]
        _fields(group,('id','subject','recipe','status','complete','variants'))
        _require((group['id'],group['subject'],group['recipe'])==(declared['id'],declared['subject'],declared['recipe']) and
            group['status']=='PASSED' and group['complete'] is True,'ordered unchanged diagnostic group')
        _require(len(group['variants'])==len(declared['variants']),'all declared variants')
        for j,variant in enumerate(group['variants']):
            check();declaration=declared['variants'][j];variant_count+=1
            _require(variant['id']==declaration['id'] and variant['status']=='PASSED' and variant['complete'] is True,'ordered variant')
            _equal(variant['expected'],declaration['expected'],check)
            if group['subject']=='scalar-summary-builder':
                _fields(variant,('id','status','complete','expected','record','writer_invoked','filesystem_persistence_tested'))
                _require(variant['writer_invoked'] is False and variant['filesystem_persistence_tested'] is False,'pure scalar scope')
                continue
            _fields(variant,('id','status','complete','expected','runs','real_root_fault_gate_passed','inherited_outer_gates_unchanged'))
            _require(variant['real_root_fault_gate_passed'] is True and variant['inherited_outer_gates_unchanged'] is True,'genuine fault gates')
            count=2 if group['recipe'] in ('work-cumulative','receipt-items-cumulative') else 1
            _require(len(variant['runs'])==count,'all baseline and main runs')
            for k,run in enumerate(variant['runs']):
                _fields(run,('profile_admitted','custody_success','planned_trigger_fired','exact_primary_identity','thrown',
                    'events','checkpoint_after_first','reference_receipts','callback_references','work_object_scalars',
                    'produced_receipt_count','preimage_completed_count','delivered_receipt_count','ordinary_lifetime_projection',
                    'ordinary_prefix_projection','result','callbacks_and_nonliteral_owners_retained','nonliteral_projection_scope'))
                _require(run['callbacks_and_nonliteral_owners_retained'] is True,'runtime owners not replayed')
                run_ids.append(variant['id']+':baseline' if count==2 and k==0 else variant['id']);run_count+=1
    _require(variant_count==55 and run_count==49,'complete55variant49profile population')
    progress=p['batch_diagnostic_progress']
    _fields(progress,('stage','active_group','active_variant','completed_group_ids','groups'))
    _require(progress['stage']=='COMPLETE' and progress['active_group'] is None and progress['active_variant'] is None,'no open diagnostic view')
    _equal(progress['completed_group_ids'],[g['id'] for g in p['batch_diagnostics']],check)
    _require(len(progress['groups'])==28,'complete final progress owners')
    for a,b in zip(progress['groups'],p['batch_diagnostics']):
        _fields(a,('id','subject','recipe','stage','variants','active_runs'))
        _require((a['id'],a['subject'],a['recipe'])==(b['id'],b['subject'],b['recipe']) and
            a['stage']=='COMPLETE' and a['active_runs']==[],'closed progress view')
        _equal(a['variants'],b['variants'],check)
    return run_ids


def _profiles(p, run_ids, check):
    wrapper_ids=[];profile_requests={}
    for row in p['profile_rows']:
        check();_require(type(row) is dict and type(row['id']) is str and type(row['complete']) is bool,'profile identity')
        _require(row['id'] not in wrapper_ids,'distinct profile occurrence identity');wrapper_ids.append(row['id'])
        live=row['lifetime']
        if live is not None:
            _fields(live,('schema','descriptor','limits','active','busy','active_query','attempted_queries',
                'produced_receipt_count','preimage_completed_count','delivered_receipt_count','receipts','requests',
                'expected_receipts','query_work','receipt_items','preparation_work','stage','failed_stage',
                'custody_entry_attempted','custody_entry_completed','custody_exit_attempted','custody_exit_completed',
                'custody_cleanup_error','registered','authority','attempted_work','data_items','query_fault','body_result'))
            profile_requests[row['id']]=live['requests']
        if not row['complete']:
            _fields(row,('id','complete','prefix','lifetime'));continue
        _fields(row,('id','complete','lifetime','profile_return_metadata','profile_return_bindings','reconstruction_scope',
                     'expanded_reconstruction_charge_bytes'))
        _require(live is not None and live['active'] is False and live['busy'] is False and
            live['active_query'] is None and live['body_result'] is None,'closed normal lifetime')
        n=_uint(live['attempted_queries'])
        _require(n==live['produced_receipt_count']==live['preimage_completed_count']==live['delivered_receipt_count']==
            len(live['requests'])==len(live['receipts'])==len(live['expected_receipts']),'normal lifecycle conservation')
        _equal(row['profile_return_bindings'],dict(receipts=dict(field='receipts',container='list'),
            attempted_requests=dict(field='requests',container='tuple'),
            exact_receipt_preimages=dict(field='expected_receipts',container='tuple'),
            body_result=dict(field='body_result',container='identity')),check)
        metadata=row['profile_return_metadata']
        _require(not any(k in metadata for k in ('receipts','attempted_requests','exact_receipt_preimages','body_result')),
                 'all four explicit returns exclusively bound')
        for key in ('attempted_queries','produced_receipt_count','preimage_completed_count','delivered_receipt_count'):
            _equal(metadata[key],live[key],check)
        _require(metadata['profile_closed'] is True and metadata['custody_entry_completed'] is True and
            metadata['custody_exit_completed'] is True,'full returned metadata closure')
        _uint(row['expanded_reconstruction_charge_bytes'])
    for group in p['batch_diagnostics']:
        for variant in group['variants']:
            runs=variant.get('runs',[])
            for k,run in enumerate(runs):
                pid=variant['id']+':baseline' if len(runs)==2 and k==0 else variant['id']
                live=run['ordinary_lifetime_projection']
                if live is not None:
                    def request_value(x):
                        check()
                        if type(x) is dict:
                            _fields(x,('literal_type','items'))
                            _require(x['literal_type']=='tuple','only tuple markers in request carriers')
                            items=[]
                            for y in x['items']:items.append(request_value(y))
                            return tuple(items)
                        if type(x) is list:return [request_value(y) for y in x]
                        _require(x is None or type(x) in (str,int,bool),'strict projected request scalar')
                        return x
                    profile_requests[pid]=request_value(live['requests'])
    ids=wrapper_ids+run_ids
    _require(len(ids)==len(set(ids)),'all attempted profile IDs globally distinct')
    accounting=p['profile_accounting']
    _require(len(accounting)==len(ids) and set(row['id'] for row in accounting)==set(ids),'one full accounting row per profile')
    metrics=p['profile_metrics']
    _fields(metrics,('profile_count','profile_attempted_work','profile_preparation_work','profile_query_kernel_work',
        'profile_overhead_work','profile_postpreparation_overhead_work','produced_receipt_count','preimage_completed_count',
        'delivered_receipt_count','attempted_queries','palette_attempted_work_known_total','palette_work_unavailable_count'))
    complete=[]
    for row in accounting:
        _fields(row,('id','attempted_work','preparation_work','query_kernel_work','overhead_work',
            'postpreparation_overhead_work','private_work_available','complete','attempted_queries',
            'produced_receipt_count','preimage_completed_count','delivered_receipt_count'))
        _require(type(row['complete']) is bool and row['private_work_available'] is (row['attempted_work'] is not None),'cost availability')
        for key,value in row.items():
            if key not in ('id','private_work_available','complete') and value is not None:
                _uint(value)
        a,k,h,prep,post=(row[n] for n in ('attempted_work','query_kernel_work','overhead_work','preparation_work','postpreparation_overhead_work'))
        if a is not None and k is not None:
            _require(h==a-k,'whole cumulative cost exactly once')
        if h is not None and prep is not None:
            _require(post==h-prep,'preparation/overhead separation')
        if row['complete']:
            _require(row['attempted_queries']==row['produced_receipt_count']==row['preimage_completed_count']==row['delivered_receipt_count'],
                     'successful accounting counters only');complete.append(row)
    sums=(('profile_attempted_work','attempted_work'),('profile_preparation_work','preparation_work'),
        ('profile_query_kernel_work','query_kernel_work'),('profile_overhead_work','overhead_work'),
        ('profile_postpreparation_overhead_work','postpreparation_overhead_work'),
        ('produced_receipt_count','produced_receipt_count'),('preimage_completed_count','preimage_completed_count'),
        ('delivered_receipt_count','delivered_receipt_count'),('attempted_queries','attempted_queries'))
    _require(metrics['profile_count']==len(complete),'complete profile portion only')
    for metric,key in sums:
        _require(metrics[metric]==sum(row[key] for row in complete if row[key] is not None),'metric sum conservation')
    _uint(metrics['palette_attempted_work_known_total']);_uint(metrics['palette_work_unavailable_count'])
    return ids,profile_requests


def _events(events, p, profile_ids, profile_requests, check):
    _require(type(events) is list,'ordered live occurrence list')
    stack=[];entered={};completed={};profiles={};queries={};observed={};started={};returned={};raised={}
    cases=[];legacy=[];groups=[];variants=[]
    for i,row in enumerate(events):
        check();_fields(row,('ordinal','phase','kind','role','operation','scope','entry','parent','arguments','value','error','complete'))
        _require(type(row['ordinal']) is int and row['ordinal']==i+1 and row['complete'] is True,'distinct complete ordinal')
        _fields(row['scope'],('case_id','profile_id','group_id','variant_id','origin'))
        phase=row['phase'];kind=row['kind'];role=row['role'];op=row['operation'];scope=row['scope']
        _require(type(kind) is str and type(role) is str and type(op) is str,'explicit event roles')
        _require(kind in ('CALL','PROFILE','QUERY','CUSTODY','PROFILE_STATE','CASE','LEGACY_DIAGNOSTIC',
            'DIAGNOSTIC_GROUP','DIAGNOSTIC_VARIANT','OBSERVATION','PROGRESS'),'closed event vocabulary')
        if phase=='ENTER':
            _require(row['entry'] is None and row['parent']==(stack[-1] if stack else None) and
                row['value'] is None and row['error'] is None,'entry shape/parent')
            entered[i+1]=row;stack.append(i+1)
            if kind=='CASE':cases.append((scope['case_id'],row['arguments']))
            if kind=='LEGACY_DIAGNOSTIC':legacy.append((scope['case_id'],row['arguments']))
            if kind=='DIAGNOSTIC_GROUP':groups.append((scope['group_id'],row['arguments']))
            if kind=='DIAGNOSTIC_VARIANT':variants.append((scope['group_id'],scope['variant_id'],row['arguments']))
            if kind=='CALL':
                key=role+'.'+op;started[key]=started.get(key,0)+1
            elif kind=='PROFILE':
                pid=scope['profile_id'];_require(pid in profile_ids and pid not in profiles,'one profile entry per attempted scope');profiles[pid]=row
                if scope['origin']=='wrapper':
                    key='implicit.with_profile';started[key]=started.get(key,0)+1
            elif kind=='QUERY' and scope['origin']=='wrapper':
                request=row['arguments'];_require(type(request) is tuple and request[0] in ('count','select'),'normal full query request')
                key='implicit.profile_'+request[0]+'_query';started[key]=started.get(key,0)+1
        elif phase in ('RETURN','RAISE'):
            token=row['entry'];_require(stack and token==stack[-1] and token in entered and token not in completed,'one exact LIFO exit')
            source=entered[token]
            _equal((kind,role,op,scope),(source['kind'],source['role'],source['operation'],source['scope']),check)
            _require(row['parent']==token and ((phase=='RAISE')==(row['error'] is not None)),'fault identity metadata scope')
            completed[token]=row;stack.pop()
            key=None
            if kind=='CALL':key=role+'.'+op
            elif kind=='PROFILE' and scope['origin']=='wrapper':key='implicit.with_profile'
            elif kind=='QUERY' and scope['origin']=='wrapper':key='implicit.profile_'+source['arguments'][0]+'_query'
            if key is not None:
                target=raised if phase=='RAISE' else returned;target[key]=target.get(key,0)+1
            if kind=='OBSERVATION' and phase=='RETURN':
                observed.setdefault(scope['case_id'],[]).append(source['arguments'])
        else:
            _require(phase=='SNAPSHOT' and row['entry'] is None and row['parent']==(stack[-1] if stack else None), 'snapshot occurrence')
            if kind=='PROFILE_STATE' and op=='QUERY_REGISTERED':
                queries.setdefault(scope['profile_id'],[]).append(row['value']['request'])
    _require(not stack and len(completed)==len(entered),'no unclosed occurrence admitted')
    _require(set(profiles)==set(profile_ids),'all successful/failed profile attempts recorded')
    _equal(list(profiles),[row['id'] for row in p['profile_accounting']],check)
    expected_cases=p['inputs']['small_palettes']+[p['inputs']['large_palette']]+p['inputs']['graph_cases']
    _equal(cases,[(row['id'],row) for row in expected_cases],check)
    _equal(legacy,[(row['id'],row) for row in p['inputs']['diagnostics']],check)
    _equal(groups,[(row['id'],row) for row in p['batch_inputs']['groups']],check)
    _equal(variants,[(g['id'],v['id'],v) for g in p['batch_inputs']['groups'] for v in g['variants']],check)
    for pid,requests in profile_requests.items():
        _equal(queries.get(pid,[]),requests,check)
    for graph in p['graphs']:
        _equal(observed.get(graph['id'],[]),[row['snapshot'] for row in graph['observations']],check)
    _equal(started,p['call_started'],check)
    _equal(returned,p['call_completed'],check)
    _equal(raised,p['call_raised'],check)
    return dict(occurrences=len(events),entries=len(entered),exits=len(completed),profiles=len(profiles))


def validate_parent(envelope, *, expected, check, retain):
    """Complete schema, catalogs and live joins against Root-owned full values.

    expected is runtime-only: packet, manifest, raw_banks, events, verify_raw_bank.
    The verifier must hash and parse the full raw bank independently in the once
    invocation. A public pin/equal status does not supply this custody callback.
    """
    state=dict(schema='linked-parent-validation-lifetime-v1',input=envelope,expected=expected,
               checked=False,error=None,receipt=None)
    _require(callable(check) and callable(retain) and retain(state) is None,'real Root validation retention')
    try:
        check();_fields(expected,('packet','manifest','raw_banks','events','verify_raw_bank'))
        _fields(envelope,('schema','gate_contract','predecessor_worker_sha256','manifest','raw_banks','canonical_packet',
            'events','bindings','coverage','G1_adopted','runtime_qualified','mathematical_authority'))
        _require(envelope['schema']=='linked-complete-batch-evidence-v1' and
            envelope['gate_contract']=='PROPOSED_G1_UNIQUE_TYPED_VALUES_ALL_ORDERED_OCCURRENCES_V1' and
            envelope['predecessor_worker_sha256']=='9ea014de87d5af2ed3017442f690699a0ef54750c8d8be12890e373936b65a03',
            'explicit unadopted successor/predecessor identity')
        _require(envelope['G1_adopted'] is False and envelope['runtime_qualified'] is False and
            envelope['mathematical_authority'] is False,'candidate has no admission authority')
        _fields(envelope['manifest'],('schema','invocation_id','plan','declaration','runtime_closure','source_pins',
            'python','stdlib_pins','outer_limits','component_limits','profile_limits','profile_granularity','profile_query_chunk',
            'predecessor_worker_sha256','terminal_policy','scope'))
        _require(envelope['manifest']['schema']=='linked-evidence-invocation-manifest-v1' and
            envelope['manifest']['terminal_policy']=='CANDIDATE_ONLY_REQUIRES_ROOT_EXTERNAL_TERMINAL_ADMISSION' and
            envelope['manifest']['profile_query_chunk']==128,'full invocation contract')
        m=envelope['manifest']
        _require(type(m['source_pins']) is dict and set(m['source_pins'])==
            {'worker','implicit','graph','selector','runner','observer','linked','schema','codec','writer'},
            'all ten current Source roles, no historical six-role omission')
        _require(m['plan']['schema']=='ROOT-linked-evidence-plan-v1' and
            m['declaration']['schema']=='ROOT-linked-evidence-declaration-v1' and
            m['runtime_closure']['schema']=='ROOT-linked-evidence-runtime-closure-v1',
            'new complete outer contract, historical grant cannot qualify')
        _equal(m['source_pins'],m['plan']['sources'],check)
        _equal(m['source_pins'],m['runtime_closure']['sources'],check)
        _equal(m['python'],m['plan']['python'],check)
        _equal(m['python'],m['runtime_closure']['python'],check)
        _equal(m['outer_limits'],m['plan']['limits'],check)
        _equal(m['outer_limits'],m['declaration']['limits'],check)
        _equal(m['component_limits'],m['declaration']['component_limits'],check)
        _equal(m['profile_limits'],m['declaration']['profile_limits'],check)
        _require(m['invocation_id']==m['plan']['invocation_id'] and
            m['profile_granularity']=='PROFILE_ENTRY_EXIT_PLUS_LOCAL_QUERY_GUARDS_V1',
            'new identity and unchanged scope granularity')
        _equal(envelope['manifest'],expected['manifest'],check)
        _equal(envelope['canonical_packet'],expected['packet'],check)
        _equal(envelope['events'],expected['events'],check)
        _equal(envelope['raw_banks'],expected['raw_banks'],check)
        banks=envelope['raw_banks'];_require(type(banks) is list and len(banks)==2,'both full original banks')
        for i,bank in enumerate(banks):
            _fields(bank,('role','pin','raw_hex','decoded'))
            _require(bank['role']==('original-bank','new-diagnostic-bank')[i] and type(bank['raw_hex']) is str,
                     'ordered complete raw bank carrier')
            # Callback is genuine Root Source-bound, not an encoded attestation.
            _require(expected['verify_raw_bank'](bank) is None,'raw bytes/hash/parser/decoded-value join')
            _equal(bank['pin'],m['plan']['inputs'][i]['pin'],check)
            _equal(bank['pin'],m['declaration']['inputs'][i]['pin'],check)
        p=envelope['canonical_packet']
        _equal(banks[0]['decoded'],p['inputs'],check);_equal(banks[1]['decoded'],p['batch_inputs'],check)
        _equal(banks[0]['pin'],p['batch_inputs']['original_bank'],check)
        run_ids=_packet_population(p,check)
        profile_ids,requests=_profiles(p,run_ids,check)
        _require(type(envelope['bindings']) is list,'complete binding catalog')
        _catalog(p,envelope['bindings'],check)
        event_counts=_events(envelope['events'],p,profile_ids,requests,check)
        coverage=envelope['coverage']
        _fields(coverage,('top_fields','normal_cases','legacy_diagnostics','new_groups','new_variants',
            'full_literal_descendants','live_occurrences_required','raw_runtime_custody_reconstructed'))
        _equal(coverage['top_fields'],tuple(p),check)
        _require((coverage['normal_cases'],coverage['legacy_diagnostics'],coverage['new_groups'],coverage['new_variants'])==(15,33,28,55)
            and coverage['full_literal_descendants'] is True and coverage['live_occurrences_required'] is True and
            coverage['raw_runtime_custody_reconstructed'] is False,'complete stated scope')
        state['checked']=True
        receipt=dict(schema='linked-parent-schema-candidate-v1',version=VERSION,
            complete_schema_and_value_binding=True,normal_cases=15,legacy_diagnostics=33,new_groups=28,new_variants=55,
            event_counts=event_counts,all24full_descendants_compared=True,independent_catalog_checked=True,
            runtime_custody_reconstructed=False,G1_adopted=False,resource_accepted=False,
            runtime_qualified=False,mathematical_authority=False)
        state['receipt']=receipt;check();return receipt
    except BaseException as error:
        state['error']=error
        raise
