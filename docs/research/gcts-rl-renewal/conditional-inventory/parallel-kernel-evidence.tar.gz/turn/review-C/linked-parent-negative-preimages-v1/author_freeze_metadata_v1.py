"""Metadata authoring only. No Subject/helper/codec/checker/fixture call."""
import ast
import hashlib
import json
from pathlib import Path

R=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs')
O=R/'gcts-linked-evidence-20261020/schema-B'
old=R/'gcts-batch-20261020'
prior=R/'gcts-evidence-next-20261020'
prev=R/'gcts-complete-evidence-20261020'
pins={}
paths={
 'master':old/'publisher/docs/basic-tiling-algorithm.md',
 'predecessor_worker':old/'root/qualify_complete_batch_worker_v2.py',
 'predecessor_component':old/'components-B/implicit_wang_batch_v2.py',
 'graph':old/'recovered/L/implicit_wang_point_search_v1.py',
 'original_bank':old/'recovered/ROOT/implicit-inputs-v1.json',
 'new_diagnostic_bank':old/'diagnostics-L/new-diagnostic-bank-v1.json',
 'obligations':prev/'review-C/independent-G1-obligations-v1.json',
 'field_map':prior/'bounds-B/one-owner-field-map-v1.json',
 'codec':prev/'schema-B/strict_value_dag_v1.py',
 'codec_review':prev/'review-C/typed-strict-value-dag-Source-review-v1.json',
 'writer':prior/'budget-L/aggregate_byte_budget_v2.py',
 'writer_api':prior/'budget-L/API-v2.json',
 'writer_review':prior/'review-C/typed-aggregate-budget-Source-review-v2.json',
 'milestone':prev/'root/ROOT-final-milestone-v1.json',
 'python':Path('/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12'),
}
for key,p in paths.items():
 raw=p.read_bytes();pins[key]=dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
obligations=json.loads(paths['obligations'].read_text())
population=obligations['original_population']
top=obligations['source_AST_field_inventory']['canonical_packet']['fields']
limits=dict(work_seconds=180,overall_seconds=210,memory_bytes=1073741824,
 stored_bytes=134217728,expanded_bytes=134217728,outer_reserve_bytes=9437184,
 stdout_bytes=4194304,stderr_bytes=4194304,header_bytes=4194304,
 negative_summary_bytes=65536,root_callbacks=400000000)
docs={}
docs['API-v1.json']={
 'schema':'linked-complete-evidence-API-v1','status':'SOURCE_ONLY_UNRUN_UNADOPTED',
 'scope':'Complete proposed parent and whole original qualification body; no executable outer grant/result/header/controller integration or fit established.',
 'source_components':{
  'producer':'linked_evidence_v1.py','independent_schema_validator':'validate_linked_evidence_v1.py',
  'profile_hook_successor':'implicit_wang_linked_v1.py','whole_worker_body':'qualify_linked_batch_worker_v1.py',
  'strict_codec':pins['codec'],'aggregate_writer':pins['writer']},
 'APIs':[
  'EvidenceJournal(*,check,retain,scope): fresh real Root-owned journal',
  'journal.enter(kind,role,operation,arguments,scope=None) -> immutable occurrence ordinal',
  'journal.leave(entry,*,arguments=None,value=None,error=None) -> distinct exit/fault ordinal',
  'journal.snapshot(kind,role,operation,value,scope=None) -> distinct snapshot ordinal',
  'journal.finish() -> full ordered list, only with no incomplete/open scope',
  'literal_copy(value,*,check,maximum_depth=256): fresh full strict snapshot',
  'assemble(packet,manifest,raw_banks,events,*,check,retain) -> full parent',
  'encode_candidate(parent,*,codec,checker,expected,check,codec_limits,retain) -> full wire, independent complete decode/schema validation and explicit measures',
  'full_tree_measure(value,*,check) -> exact new unshared typed tree bytes/items; not G0 JSON',
  'validate_parent(parent,*,expected,check,retain) -> complete schema/value/event CANDIDATE only',
  'run_linked_candidate(s,inputs,batch_inputs,raw_banks,manifest,*,codec_limits,writer,physical_limit,expanded_limit) -> whole15/33+28/55 writer candidate',
  'with_profile(...,evidence=None) and batch_query(...,evidence=None): new optional synchronous observation callback',
  'main(plan_path): deliberately refuses retired historical plans and all launches until new Root outer integration'],
 'envelope_exact_fields':['schema','gate_contract','predecessor_worker_sha256','manifest','raw_banks','canonical_packet','events','bindings','coverage','G1_adopted','runtime_qualified','mathematical_authority'],
 'manifest_exact_fields':['schema','invocation_id','plan','declaration','runtime_closure','source_pins','python','stdlib_pins','outer_limits','component_limits','profile_limits','profile_granularity','profile_query_chunk','predecessor_worker_sha256','terminal_policy','scope'],
 'expected_runtime_fields':['packet','manifest','raw_banks','events','verify_raw_bank'],
 'raw_bank_exact_fields':['role','pin','raw_hex','decoded'],
 'raw_banks_rule':'Two exact unchanged full banks, raw bytes represented losslessly by lowercase hex and strict decoded values. Independent Source-bound Root callback checks full raw file/path/size/hash and json parser/value join, never a partial.',
 'domain':'Full old strict finite literal domain, tuple/list and dict insertion order preserved. Codec supports float.hex including nonfinite, but parent rejects nonfinite as old JSON allow_nan=False. Raw bytes represented only by explicit raw_hex bank carrier; unsupported literal objects refuse. Runtime objects are never encoded as replayable values.',
 'event_fields':['ordinal','phase','kind','role','operation','scope','entry','parent','arguments','value','error','complete'],
 'scope_fields':['case_id','profile_id','group_id','variant_id','origin'],
 'phase_rule':'Live monotone ordinal is allocated before copying; ENTER and distinct RETURN/RAISE are LIFO-paired; SNAPSHOT is a separate ordered occurrence. Equal payloads never merge events. Incomplete rows cannot be admitted.',
 'profile_stages':['PROFILE_ENTER','CUSTODY_ENTER','CUSTODY_RETURN','CUSTODY_RAISE','QUERY_ENTER','QUERY_REGISTERED','QUERY_PRODUCED','QUERY_PREIMAGE','QUERY_DELIVERED','QUERY_RETURN','QUERY_RAISE','RECONCILE_VERSION','RECONCILE_RESULT','PROFILE_RETURN','PROFILE_RAISE'],
 'custody':'Actual Source/module/function/code/default/closure cells/helpers, descriptors, Work, callbacks, raw states/receipts/preimages and primary/secondary errors remain in real Session/journal/callback owners through final custody. IDs or exception type labels are nonreplayable metadata. New recursive function-owner seal includes wrapper-captured helper functions.',
 'charge_contract':'PROPOSED_G1_UNIQUE_TYPED_VALUES_ALL_ORDERED_OCCURRENCES_V1',
 'charge':'Exact complete canonical DAG wire length, including all unique typed records and every stored ordered reference, event ordinal record, role/binding/catalog/manifest/full raw bank field. Per-owner and total full typed TREE measures separately reported and not equated with G0 JSON or charged as if unique bytes were old unfolding.',
 'writer':'Pinned unchanged cooperative writer Source receives chunk expanded=len(chunk) ONLY under proposed G1 changed meaning. This does not satisfy writer documentation original-G0 upstream meaning. Root must explicitly declare/review/adopt this new charge convention. All caps and aggregate reservations unchanged.',
 'Source_provenance':'Source pins are new ten-role closure worker/implicit/graph/selector/runner/observer/linked/schema/codec/writer plus full stdlib/Python/plan/declaration closure. Historical six-role Source is provenance only, no grant.',
 'remaining_outer_work':['New Root plan/declaration/runtime closure/runner/observer and result/header schema preserving every old q/result/header field and raw pin; independent external terminal and OS resource observations.','Root shared aggregate writer/log sinks/reservation setup and bounded negative-summary path.','Whole Source independent review; full original plus prospective new diagnostics, fresh Root-only once authorization; no authorization here.'],
 'all_original_populations':population,'limits':limits,
 'G1_adopted':False,'fit_proved':False,'runtime_qualified':False,'actual_authorized':False}
field_rows=[]
roles={
 'schema':'predecessor identity','status':'predecessor candidate status','inputs':'complete original raw-bank decoded owner',
 'small_palettes':'all4 case payloads and independent palettes/semantic values/query groups',
 'large_palette':'complete large input, exact old cardinality and all42 bounded requests',
 'graphs':'all10 full graph results/journals/query streams/solutions/observations/independent domains/rollback',
 'diagnostics':'all33 unchanged declarations/outcomes/full available prefixes',
 'call_receipts':'all original retained standalone full arguments/limits/receipts/fault prefixes',
 'call_started':'complete start map','call_completed':'complete completion map','call_raised':'complete raise map',
 'root_callbacks':'preencoding cutoff, not terminal total','batch_inputs':'complete28group55variant raw-bank decoded owner',
 'profile_rows':'all wrapper attempts, ordinary full lifetimes, return metadata/four bindings and old reconstruction deltas',
 'profile_metrics':'all12 fields, successful-complete portion versus all known/unavailable totals',
 'profile_accounting':'one exact cost row per attempted wrapper/new diagnostic profile',
 'batch_diagnostics':'all28/55 full runs/baselines/reference/closed/scalar results',
 'batch_diagnostic_progress':'complete original final full view retained, no omitted duplicate descendants',
 'full_VM_implemented':'False','full_FOL_palette_qualified':'False','proof_discovery':'False',
 'full_pipeline_qualified':'False','mathematical_authority':'False','scope':'complete exact Source scope text'}
for i,key in enumerate(top):
 field_rows.append(dict(ordinal=i+1,old_path='packet.'+key,new_path='envelope.canonical_packet.'+key,
  owner_rule='FULL_STRICT_TYPED_SUBTREE_ALL_DESCENDANTS',role=roles[key],
  omission_or_extra_rule='Independent full typed comparison to actual guarded qualified packet; exact24 root fields/order; no summary/hash replacement.'))
docs['full-preservation-map-v1.json']={
 'schema':'linked-complete-parent-preservation-map-v1','field_rows':field_rows,
 'literal_descendants':'Every nested scalar/map key/value/list/tuple occurrence is in the complete codec root; complete decode plus independent strict whole-packet equality checks every descendant, including unknown dynamic data fields. Unknown structural fields are refused by exact records; unknown data keys are values and cannot disappear/coerce.',
 'live_source_joins':[
  {'event':'CALL','site':'Session.call around unchanged _original_call','payload':'Full declared effective literal args/limits before and after; raw action/closure/nonliteral exact arguments retained separately. Source private-owner predicate error argument is not serialized as a replayable literal.','join':'started/completed/raised maps, exact Source operation names and ordered distinct occurrences'},
  {'event':'CASE','site':'wrappers around original four-small/one-large/ten-graph bodies','payload':'Full original record and whole case output','join':'exact15 original input order'},
  {'event':'LEGACY_DIAGNOSTIC','site':'wrapper around unchanged diagnostic body','payload':'Full original declaration and full outcome','join':'exact33 original order and full declarations'},
  {'event':'DIAGNOSTIC_GROUP/VARIANT','site':'original run_new_diagnostics loop enter/leave','payload':'Full declarations and full group/variant outcome','join':'exact28 groups55 variants original order'},
  {'event':'PROFILE','site':'component new event hook before first Work callback and on return/fault','payload':'Declared descriptor/limits/guard inputs, full return and ordinary lifetime including unregistered constructor state, exact raw errors separately retained','join':'every accounting ID including49 new runs/baselines'},
  {'event':'QUERY','site':'component wrapper before inactive/reentrant/firstfault checks','payload':'Every invocation including static, closed, reentrant and swallowed retries; full request/return/fault state','join':'QUERY_REGISTERED stream equals complete lifetime requests; nonregistered attempts remain distinct'},
  {'event':'PROFILE_STATE','site':'produced/preimage/delivered/reconciliation notifications','payload':'Full raw production snapshot before receipt copy, full typed preimage before next tick, postcallback reconciliation tree/result, counters and active query','join':'separate immutable versions; do not intern mutable raw references before literal snapshots'},
  {'event':'OBSERVATION','site':'live wrapper around independent graph observer','payload':'Full snapshot before and after, exact exception object raw-owned','join':'same graph case, original observation order and full independent domains in packet'},
  {'event':'internal graph journal/query/solution','site':'original Source-owned ordered result lists and journal seq','payload':'Every full item preserved with (graph case, stream, original index/seq) binding','join':'Per-engine Source order retained. No invented global timestamp/order for internal journal appends is inferred from counters; live query/observation/call order is separately recorded.'}],
 'independent_routes':[
  {'paths':['small_palettes[*].legacy_palette','small_palettes[*].semantic_tiles'],'source_role':'selector + worker','site':'compile_unknown_palette -> literal_tiles','independence':'independent legacy compiler route, never actual implicit answer reused as expected'},
  {'paths':['small_palettes[*].queries[*]'],'source_role':'worker','site':'independent literal buckets + full bijection checks','independence':'all count/rank requests determined before implicit answers'},
  {'paths':['large_palette.legacy_cardinality','large_palette.focused_families'],'source_role':'selector + worker','site':'describe_unknown_palette_cardinality + independent_membership/reference_tile','independence':'direct old formula/local-rule route'},
  {'paths':['graphs[*].independent_solution_ids','graphs[*].observations[*].independent_domains'],'source_role':'worker','site':'independent_all_solutions + independent_graph_core','independence':'independent fixed-site enumeration and complete literal domains'},
  {'paths':['profile_rows[*].lifetime.expected_receipts','events QUERY_PREIMAGE/RECONCILE_VERSION'],'source_role':'implicit + worker','site':'_receipt_tree copy before callback; later strict reconciliation','independence':'distinct pre/post mutation versions, not same mutable pointer twice'}],
 'profile_return_bindings':obligations['exact_profile_return_bindings'],
 'outer_field_preservation':{key:obligations['source_AST_field_inventory'][key]['spread_fields_expanded'] if 'spread_fields_expanded' in obligations['source_AST_field_inventory'][key] else obligations['source_AST_field_inventory'][key]['fields'] for key in ('q','result_payload','worker_header','scalar_failure_summary','worker_failure')},
 'outer_implementation_status':'All listed outer fields remain mandatory Root work; new main refuses. The component does NOT claim their complete integration/admission.',
 'raw_runtime_owners':'Actual identity/custody remains runtime-only; no codec reconstruction of objects or private ownership.',
 'new_behavior':['New profile hook and live journal checks/allocation/custody cost.','New immutable before/after event snapshots and independent complete schema comparison.','New G1 unique-owner charge, NOT G0.','Stronger recursive local-helper callable seal.'],
 'unchanged':['Whole original input banks, all15/33+28/55 populations and recipes.','All original semantic qualification/oracle checks, graph scheduler/rollback predicates, eight standalone API bodies, three component limit maps and deterministic128 request scopes.'],
 'old_G0_negative_unchanged':True,'G1_adopted':False,'no_fit_claim':True}
docs['manual-correspondence-and-resource-v1.json']={
 'schema':'linked-parent-manual-correspondence-resource-v1','status':'SOURCE_ARGUMENT_NOT_EXECUTED_OR_ADOPTED',
 'correspondence_steps':[
  'Fresh whole qualifier executes the original all-case bodies. Wrappers record each live call/case/profile/query/observer/group/variant occurrence, without obtaining semantic answers from the value store.',
  'Each raw event/state/error owner is registered before copies/checks. Immutable full literal snapshots separate production, typed preimage, delivered value and postcallback reconciliation versions. A copy fault leaves an incomplete occurrence and prevents parent admission.',
  'The parent contains the entire24-field original packet, both full raw banks plus strict decoded values, live event sequence, full manifest and independent catalog. No old descendant is replaced by a pin/count/status.',
  'The frozen strict DAG codec has a separately reviewed complete scalar/type/reference grammar. Ordered references preserve all multiplicities; its decoder fully materializes every root occurrence, not a header/hash summary.',
  'The independent validator never calls the producer catalog builder. It checks exact parent/structural fields, whole original packet/raw banks/events/manifest against genuine Root-owned values, reconstructs the required catalog independently, checks full populations and live call/profile/query/observation joins.',
  'Every event carries a distinct ordinal node and full ordered references even when payload nodes share storage. Source-generated stream seq/index and scope bindings preserve internal graph occurrence order. Raw callable/Work/error identity is never claimed from decoding.',
  'Successful value/schema correspondence yields only a candidate. Original Source/function/argument/runtime custody, full output pins, external terminal/resource/denied-event observations and changed-gate adoption remain Root requirements.'],
 'gate_change':{'name':'PROPOSED_G1_UNIQUE_TYPED_VALUES_ALL_ORDERED_OCCURRENCES_V1',
  'old_G0':'Old literal JSON unfolding plus conservative full-return reconstruction remains rejected as reviewed. Nothing here rescues it.',
  'new_G1':'Complete unique canonical typed value records plus every stored reference and unique event/binding occurrence record. Complete old progress/reader payloads are retained but equal values can share typed nodes. The changed charge is explicitly unadopted.',
  'nonzero_occurrences':'Every event has a distinct ordinal and row; every binding has its own ordinal and row. Container arities and all ordered references are in the wire; physical sharing cannot erase a call/rank/variant/solution occurrence.',
  'three_measures':['Exact canonical stored wire bytes.','Exact separately computed full typed-tree unfolding per envelope owner and whole parent; this is not old JSON and is not charged as G1 unique bytes.','Exact proposed unique owner+all-stored-reference logical charge equals wire length; result/header/other output metadata are additional Root charges.']},
 'exact_wire_formula':'\\(W=9+u(N)+\\sum_{i=1}^{N}(u(|R_i|)+|R_i|)+u(1)+u(r)\\), where minimal unsigned LEB128 length is \\(u\\), all unique record bytes are \\(R_i\\), and there is one complete parent root \\(r\\).',
 'tree_formula':'A leaf has tag plus its length/sign/payload; a container has tag/arity plus the FULL recursively inlined ordered children (dict has both each key and value). The implementation computes this with real checks and returns exact occurrence counts. All envelope key/framing cost appears in whole-parent tree measure.',
 'whole_cohort_bounds':{
  'small_source_upper':'Selector tiles cap100000, four small inventories. Per case at most16*n+7 bucket masks,16*n selected ranks and32*n+7 requests. Thus at most12800028 small requests in at most100004 deterministic128-request profile scopes. These are loose Source maxima, not measured current-bank cardinalities.',
  'large_source_exact_sequence':'One total count,3 global selects and19 focused pairs:42 profile requests; no full large enumeration.',
  'normal_graph_source_upper':'Ten graph cases with at most1000000 oracle_queries each: at most10000000 core queries,10000000 snapshots and10000000 journal events;100000 solutions from the per-case10000 cap. All complete returned items remain required.',
  'legacy_source_scope':'All33 declarations unchanged.13 graph diagnostic profile attempts are required; the declared twelve graph invalid/foreign paths and one work1 UNKNOWN path make no graph oracle call under the pinned Source/control join. No saved partial is used.',
  'new_diagnostics_source_upper':'49 actual profile scopes including2 extra baselines; no profile body issues more than3 requests, plus2 closed-scope attempts outside those bodies, so at most149 query invocations.6 standalone reference calls and8 scalar-builder calls remain separate actual occurrences.',
  'aggregate_profile_query_upper':22800219,
  'profile_scope_upper':100077,
  'independent_domains_upper':'Full independent domain lists can contain up to sites10000 times palette100000 identities per observation, before Root/wall/memory gates. Ten million Source-limited snapshots give a deliberately very loose10^16 identity-occurrence bound. This already shows that these generic Source caps are not a useful128MiB fit proof.',
  'manifest_unknown':'Fresh Root plan/declaration/runtime closure/result/header/log schema and concrete codec limits are not yet declared. Their exact complete sizes/work cannot be supplied from retired Sources.',
  'stored_and_unique_logical':'Exact prospective canonical charge is W. Source codec enforces its caller-declared wire limit; that is a refusal gate, NOT a constructive bound showing this whole cohort fits.',
  'physical':'Pinned writer reserves9MiB outer +4MiB stdout +4MiB stderr +4MiB header +64KiB negative summary inside128MiB. At most112132096 bytes remain for canonical/result/other unfixed ordinary files before prior opaque P, so a full reservation requires W+J+P<=112132096. No values for W/J/P are inferred or measured here.',
  'work':'One invocation-total400m real Root callback ceiling remains. Journal copies, complete codec encode+decode, independent schema traversal, per-owner/full tree measures and every Source/argument guard are real costs, with no warm preparation. Codec attempted_work is separately reported, not added as a fabricated CPU count. If T is full parent tree items, the separate owner plus full tree measurements make at most4*T Root checks (apart from caller checks); journal copying and codec/checker work add further costs.',
  'memory':'Raw packet/runtime owners remain held. Fresh event snapshots, full typed argument seal bytes, codec records/wire, full independent native decode, expected originals and writer buffers coexist. No release/cap discount or1GiB fit proof is supplied.',
  'time':'Original absolute180s positive and210s negative custody gates unchanged; external termination may happen at180. No runtime duration/throughput prediction.',
  'conclusion':'No conservative useful full-case upper bound below the stored/logical/physical/time/HWM/callback caps has been proved. Generic Source worst bounds exceed them. This does NOT prove proposed G1 infeasible; no fit/resource/actual-ready claim is authorized.'},
 'remaining_gaps':['Independent full Source review, including event completeness, extra helper closure seals and foreign-fault nonmasking.','Fresh Root complete outer positive/negative writer integration and all q/result/header/external terminal fields.','Concrete full-case prospective Source upper bounds or separately authorized once evidence; no sizing probe or trim permitted.','Full unrun codec/writer/parent diagnostic populations before any adoption.'],
 'limits':limits,'subject_calls':0,'subject_imports':0,'codec_calls':0,'checker_calls':0,'fixture_calls':0,'sizing_probes':0,'partial_parses':0,'actual_launches':0,
 'G1_adopted':False,'fit_proved':False,'resource_accepted':False,'runtime_qualified':False,'mathematical_authority':False}
diagnostics=[]
for field in top:
 diagnostics.append(dict(id='missing-top-'+field,recipe='delete-one-required-topfield',field=field,expected='REFUSE_NO_ADMISSION'))
 diagnostics.append(dict(id='changed-top-'+field,recipe='replace-full-subtree-with-distinct-strict-value',field=field,expected='REFUSE_FULL_VALUE_JOIN'))
for name in ('schema','gate_contract','predecessor_worker_sha256','manifest','raw_banks','canonical_packet','events','bindings','coverage','G1_adopted','runtime_qualified','mathematical_authority'):
 diagnostics.append(dict(id='parent-field-'+name,recipe='missing-extra-or-wrong-typed-parent-field',field=name,expected='REFUSE_NO_ADMISSION'))
for case in [
 ('normal15-positive','full15normal33legacy28new55variants-complete-bank','CANDIDATE_ONLY'),
 ('raw-byte-change','change-original-bank-byte-without-pin','REFUSE_RAW_JOIN'),
 ('raw-decoded-change','same-pin-different-decoded-value','REFUSE_STRICT_JOIN'),
 ('raw-bank-reorder','swap-full-two-banks','REFUSE_POPULATION'),
 ('small-trim','remove-last-independent-mask-rank','REFUSE_FULL_SEQUENCE'),
 ('small-chunk','repartition128-scopes-without-preserving-original','REFUSE_LIVE_JOIN'),
 ('large-family','remove-last-focused-family','REFUSE_FULL_POPULATION'),
 ('graph-domain','replace-full-independent-domain-with-count','REFUSE_FULL_VALUE'),
 ('graph-rollback','change-rollback-parent-or-restoration-snapshot','REFUSE_FULL_VALUE'),
 ('normal-order','swap-two-normal-cases','REFUSE_ORDER'),
 ('legacy-order','swap-two-legacy-diagnostics','REFUSE_ORDER'),
 ('new-variant','drop-one-of55-variants','REFUSE_POPULATION'),
 ('baseline','drop-work-or-receipt-items-baseline','REFUSE49RUNS'),
 ('reference','drop-one-of6-standalone-references','REFUSE_FULL_VALUE_OR_CALL_MAP'),
 ('closed','erase-closed-query-attempt','REFUSE_EVENT_OR_CALL_MAP'),
 ('scalar','change-writer_invoked-or-filesystem_tested','REFUSE_SCOPE'),
 ('event-merge','coalesce-two-strict-equal-calls','REFUSE_EVENT_MULTIPLICITY'),
 ('event-ordinal','duplicate-or-gap-ordinal','REFUSE_ORDER'),
 ('event-parent','wrong-parent-or-exit-token','REFUSE_LIFO'),
 ('event-open','unfinished-query-or-diagnostic-scope','REFUSE_NONADMISSION'),
 ('event-extra','insert-unknown-kind-or-unowned-binding','REFUSE_VOCABULARY'),
 ('call-map','increment-only-start-complete-or-raised-map','REFUSE_CONSERVATION'),
 ('profile-id','reuse-accounting-id-across-two-attempts','REFUSE_ID_BIJECTION'),
 ('profile-unavailable','replace-None-constructor-work-with0','REFUSE_FULL_VALUE'),
 ('first-copy','select-produced1-preimage0-delivered0-full-raw-tile','CANDIDATE_EXPECTED_REFUSAL_ONLY'),
 ('mutation-bool','preserve-int0-delivery-and-boolFalse-postcallback','CANDIDATE_EXPECTED_REFUSAL_ONLY'),
 ('mutation-tuple','preserve-list-before-tuple-after','CANDIDATE_EXPECTED_REFUSAL_ONLY'),
 ('mutation-absent','preserve-authority-before-absent-after','CANDIDATE_EXPECTED_REFUSAL_ONLY'),
 ('mutation-zero','preserve-authorityFalse-before-int0-after','CANDIDATE_EXPECTED_REFUSAL_ONLY'),
 ('version-retarget','point-original-preimage-at-mutated-value','REFUSE_FULL_VERSION_JOIN'),
 ('return-binding','change-one-of-four-paths-types-owner-version','REFUSE_BINDING'),
 ('profile-failure','normalize-failed-graph-profile-to-success','REFUSE_LIFECYCLE'),
 ('foreign-StopIteration','foreign-exact-StopIteration-in-journal-copy-check','EXACT_PRIMARY_RAW_RETAINED_NO_ADMISSION'),
 ('secondary','Root-firstfault-and-journal-secondary-over-planned-sentinel','GENUINE_ROOT_FIRSTFAULT_DOMINATES'),
 ('hook-custody','mutate-query-wrapper-captured-helper-code','REFUSE_DEEP_SEAL'),
 ('source-role','omit-new-codec-checker-writer-Source','REFUSE_FULL_CLOSURE'),
 ('retired-grant','call-main-with-old-plan','ALWAYS_REFUSE'),
 ('writer-before-claim','attempt-bulk-allocation-outside-shared-lease','REFUSE_ROOT_INTEGRATION'),
 ('writer-shared-budget','canonical-result-header-logs-negative-reserve-within-same128MiB','REQUIRES_WHOLE_OUTER_GATES'),
 ('G0-label','call-unique-G1-charge-old-G0-expanded-pass','REFUSE_GATE_MEANING'),
 ('truncated-wire','decode-only-complete-authorized-wire-with-last-byte-missing','REFUSE_CODEC'),
 ('partial','supply-any-partial-for-decoding-projection-repair-or-admission','FORBIDDEN_NOT_A_FIXTURE'),
 ('full-tree-limit','shared-small-wire-native-unfold-exceeds-declared-quota','OWN_CODEC_LIMIT_NO_ADMISSION'),
 ('terminal','missing-external-exit-header-result-or-custody','NO_POSITIVE_ADMISSION')]:
 diagnostics.append(dict(id=case[0],recipe=case[1],expected=case[2]))
docs['prospective-whole-diagnostics-v1.json']={
 'schema':'linked-parent-prospective-whole-diagnostics-v1','status':'ALL_UNRUN_DECLARATIVE_ONLY',
 'original_cohort_unchanged':population,'original_bank':pins['original_bank'],'new_diagnostic_bank':pins['new_diagnostic_bank'],
 'codec_101_bank':dict(path=str(prev/'schema-B/diagnostic-bank-v1.json'),all_unrun=True),
 'writer_49groups70variants_bank':dict(path=str(prior/'budget-L/diagnostic-bank-v2.json'),all_unrun=True),
 'additional_parent_recipes':diagnostics,'additional_parent_recipe_count':len(diagnostics),
 'whole_scope':'Full original15/33+28/55 must run unchanged under any future full-successor offer. Additional negatives are separately declared ordinary complete inputs. No generated fixture, partial parse, sizing probe, subject call or cap/trim authority.',
 'actual_execution_authorized':False,'G1_adopted':False}
for name,obj in docs.items():
 (O/name).write_text(json.dumps(obj,ensure_ascii=True,indent=2)+'\n')
# Full prior obligation IDs retained with concrete status, not erased by codec.
implemented={'S01_TOTAL_SCHEMA','S02_FULL_INPUTS','S03_NORMAL_POPULATION','S05_EXACT_VALUES','S06_EVENT_IDENTITY','S08_RAW_PRODUCED_BEFORE_COPY','S09_MUTATION_VERSIONS','S10_RETURN_BINDINGS','S14_NEW_DIAGNOSTICS','S15_SCALAR_SUMMARY_SCOPE','S19_PROGRESS_VIEWS','S22_EXPLICIT_CHANGED_GATE','S26_INDEPENDENT_DECODE'}
partial={'S04_INDEPENDENT_ORACLES','S07_PROFILE_LIFECYCLE','S11_GRAPH_CONFORMANCE','S12_GRAPH_SCOPE','S13_LEGACY_DIAGNOSTICS','S16_COST_CONSERVATION','S17_CUSTODY_NOT_SERIALIZATION','S18_CALL_CONTRACTS','S23_THREE_BYTE_MEASURES','S27_PROVENANCE_AND_AUTHORITY','S28_SEPARATE_COMPONENT_EXPERIMENTS'}
status=[]
for obligation in obligations['obligations']:
 key=obligation['id']
 status.append(dict(id=key,requirement=obligation['requirement'],
  status='SOURCE_IMPLEMENTED_UNRUN_REQUIRES_INDEPENDENT_REVIEW' if key in implemented else 'SOURCE_PATH_PRESERVED_OR_PARTIAL_ROOT_INTEGRATION_REQUIRED' if key in partial else 'OPEN_ROOT_OUTER_RESOURCE_OR_ADMISSION_WORK',
  no_adoption_or_fit_inferred=True))
(O/'obligation-status-v1.json').write_text(json.dumps(dict(schema='linked-complete-parent-obligation-status-v1',rows=status,all_runtime_unqualified=True),indent=2)+'\n')
# Raw file hashing, AST and unused compilation only. No import/exec(code).
audit=[]
for name in ('linked_evidence_v1.py','validate_linked_evidence_v1.py','implicit_wang_linked_v1.py','qualify_linked_batch_worker_v1.py','worker_integration_v1.fragment.py'):
 p=O/name;raw=p.read_bytes();tree=ast.parse(raw,filename=str(p));unused=compile(tree,str(p),'exec');dump=ast.dump(tree,annotate_fields=True,include_attributes=False).encode()
 audit.append(dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),AST_sha256=hashlib.sha256(dump).hexdigest(),unused_compile=True,code_executed=False,
  import_nodes=sum(isinstance(n,(ast.Import,ast.ImportFrom))for n in ast.walk(tree)),generator_nodes=sum(isinstance(n,ast.GeneratorExp)for n in ast.walk(tree))))
(O/'author-static-audit-v1.json').write_text(json.dumps(dict(schema='linked-complete-parent-static-audit-v1',Source_rows=audit,metadata_python=pins['python'],
 Subject_imports=0,Subject_calls=0,codec_calls=0,checker_calls=0,fixture_calls=0,sizing_calls=0,partial_parses=0,actual_launches=0),indent=2)+'\n')
(O/'dependency-pins-v1.json').write_text(json.dumps(dict(schema='linked-complete-parent-dependency-pins-v1',pins=pins),indent=2)+'\n')
# Handoff freezes exact files after documents/static metadata. Author scripts
# are provenance only; Source generated above is authoritative if revised.
artifacts=[]
for name in ('linked_evidence_v1.py','validate_linked_evidence_v1.py','implicit_wang_linked_v1.py','qualify_linked_batch_worker_v1.py','worker_integration_v1.fragment.py','API-v1.json','full-preservation-map-v1.json','manual-correspondence-and-resource-v1.json','prospective-whole-diagnostics-v1.json','obligation-status-v1.json','author-static-audit-v1.json','dependency-pins-v1.json','author_successor_sources_v1.py','author_freeze_metadata_v1.py'):
 p=O/name;raw=p.read_bytes();artifacts.append(dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
handoff=dict(schema='linked-complete-parent-handoff-v1',status='FROZEN_SOURCE_ONLY_UNRUN_UNADOPTED_NOT_ACTUAL_READY',
 author='/root/recovered_batch_integration',artifacts=artifacts,dependencies=pins,
 whole_original_population=population,full24canonical_descendants_retained=True,
 complete_value_parent_and_schema_implemented_Source_only=True,
 full_original_worker_body_integration_Source_only=True,
 outer_plan_result_header_runner_observer_integration_complete=False,
 old_G0_negative_unchanged=True,G1_adopted=False,fit_proved=False,runtime_qualified=False,
 original_limits_unchanged=limits,prospective_additional_parent_recipes=len(diagnostics),
 subject_imports=0,subject_calls=0,codec_calls=0,checker_calls=0,fixture_calls=0,
 sizing_probes=0,partial_parses=0,partial_files_opened=0,new_actuals=0,new_grants=0,
 remaining_grants=0,mathematical_authority=False,GCTS_RL_advantage=False,
 remaining_gaps=docs['manual-correspondence-and-resource-v1.json']['remaining_gaps'],
 tools_stopped_after_handoff=True)
(O/'handoff-v1.json').write_text(json.dumps(handoff,indent=2)+'\n')
raw=(O/'handoff-v1.json').read_bytes()
print(json.dumps(dict(path=str(O/'handoff-v1.json'),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()),indent=2))

