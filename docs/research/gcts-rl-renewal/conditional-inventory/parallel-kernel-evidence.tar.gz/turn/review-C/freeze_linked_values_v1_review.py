"""Passive/AST manual review of frozen intermediate heap/ref parser Source."""
import ast
import hashlib
import json
from pathlib import Path
N=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-linked-evidence-20261020')
L=N/'physical-L';O=N/'review-C';C=O/'linked-values-Sources-v1';C.mkdir(exist_ok=True)
checks=[];pins=[]
def need(n,v):
    checks.append({'check':n,'passed':bool(v)})
    if not v:raise ValueError(n)
def pin(p):
    b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def rawcheck(r,n):
    p=Path(r['path']);need(n+':not-partial','.partial' not in p.name);b=p.read_bytes()
    need(n+':pin',len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256']);return b
hraw=(L/'handoff-v1.json').read_bytes()
need('exact-handoff',len(hraw)==3134 and hashlib.sha256(hraw).hexdigest()=='e5b9ee48cf6ea2f1b9f20bab2fdade6ebdbc7de26124293e9e663eec3368ac89')
h=json.loads(hraw)
for n in ['handoff-v1.json']+[Path(h[k]['path']).name for k in ('source','api','bank','lineage','manifest','manual','static_audit')]:
    p=L/n;dest=C/n;need('fresh:'+n,not dest.exists());dest.write_bytes(p.read_bytes());pins.append(pin(dest))
for key in ('source','api','bank','lineage','manifest','manual','static_audit'):rawcheck(h[key],'handoff-'+key)
manifest=json.loads((C/'freeze-manifest-v1.json').read_bytes())
for i,row in enumerate(manifest['members']):rawcheck(row,'manifest'+str(i))
lineage=json.loads((C/'lineage-pins-v1.json').read_bytes())
for i,row in enumerate(lineage['members']):rawcheck(row,'lineage'+str(i))
source=(C/'linked_boot_values_v1.py').read_bytes();t=ast.parse(source);compile(t,'linked_boot_values_v1.py','exec')
static=json.loads((C/'author-static-audit-v1.json').read_bytes())
need('AST-exact-author',hashlib.sha256(ast.dump(t,annotate_fields=True,include_attributes=False).encode()).hexdigest()==static['ast_sha256'])
need('no-imports',not any(isinstance(x,(ast.Import,ast.ImportFrom))for x in ast.walk(t)))
funcs=[x for x in t.body if isinstance(x,ast.FunctionDef)]
spec={
 '_put':'Completes every9nonfence RAW slot to supplied invalid continuation; fence remains sharedlowerer BOUND. Choice values exactliteral tuples; no runtime host operation.',
 '_row':'One named Source state allocation then full put, inherited raw-prefix/foreign/Rootguard obligations.',
 '_constant':'Only internal fixed bitword257/zero callsites; reverse Source chain writes bits in forward tape order after clearing. Not a problem-dependent word constructor.',
 '_copy':'Rewinds/clears output, copies every source bit in order untilB and rewinds output; contents of input preserved, cursor maymove. Requires distinct known bands and canonical padding.',
 '_increment':'Physical LSBcarry1->0,0/B->1 with rewound result; canonical nonempty COUNT invariant.',
 '_canonical_word':'First0 allowed only if immediateB or eventually final1; first1 likewise; accepts exactly nonempty canonicalLSB strings (0 or highbit1). Invalid visible symbols useinvalid; no trailing-padding validator.',
 '_atom_or_node':'After canonical validation, fewerthan9bits means atom<=255. At ninth bit only lower8zero plus1 plusB is256; every other canonical value isnodecandidate, never automatically existing node.',
 '_compare_words':'Exact bits and simultaneousB termination; mismatch preserves both wordcontents and choosesno; cursorpositions maychange.',
 '_next_heap_record':'From anywhere inside current wellformed pairrecord, skips0/1/comma tosemicolon thensteps to nextrecord/colon; relies on validated canonicalseed.',
 '_compare_heap_field':'Compares full heapfield to word including exact fielddelimiter/B alignment; consumes delimiter only on success; mismatch leavesheapcursor where skip can finish currentrecord.',
 '_copy_heap_field':'Clears destination and copies entire heapfield, consumes specifieddelimiter and rewinds result. Seedguarantees nonempty canonical childrefs.',
 '_write_word_here':'Replaces declared firstsymbol by firstbit then writes subsequent bits intoB, appendsdelimiter and advances. Srccontents preserved. Requires actual nonempty word, padding and proper destinationcursor.',
 '_valid_reference':'Canonical word then fixed finite atomrange test; nodecandidate scans actual seed/current records with physical COUNT257+ordinal, invalidatcolon when absent. Does not validate seedtopology itself.',
 'canonical_cons':'Validate both operands before scan, compare exact left/right fields, reuse unique equalpairID; else append atcolon with COUNTnextID. Operands denote atoms/earliernodes, so successful append preserves topology/acyclicity/uniqueness under validated seed. Earlierrecordcontents unchanged.',
 'heap_lookup':'Validate canonical RETURN word then scan actual implicitIDs, copy bothchildfields onmatch. Atoms/nonexistentIDs cannotmatch node257+ordinal. RETURN/HEAP contents preserved; no host array lookup at runtime.',
 '_clear_records':'Erases old properrecords up tocolon and restores emptycolon afterrewind; only valid scratchrecord grammar/padding assumed; no arbitrary payload sanitizer claim.',
 'stack_push':'Append nonempty valid RETURN reference atcolon, semicolon thennewcolon; requires caller alreadyvalidated ref. No new heaprecord is created by push.',
 'stack_pop':'Find endcolon, expose lastsemicolon as temporarycolon, seek left to priorsemicolon/^, copy/erase lastbits, erase temporarycolon, rewind and restorecolon atfirsterasedcell. Previousrecords unchanged; underflow destructivefailure invalid, never admitted.',
 '_read_atom9':'Nine physical input bits, ninth1 permitted only if low8all0; trimhighzeros backward; allzero restores single0. Thus all257atoms admitted and257..511refused, with exact sourcecursor advancement.',
 'postfix_roots':'Only fixed PUBLIC1/3roots and CERTIFICATE2/2roots. Clear stack, atom pushesactualID, cons popsright thenleft, interns/pushes actualnodeID, semicolon scans actualrefrecordcount; Bpadding tofirstcolon. Structural segment only, no taggedgrammar/UTF8/EOF theorem.',
 'install_postfix_pair':'Installs two separate entrybodies with supplied static ports; does not sequence/preservePUBLIC roots or assemble request. Explicit full_BOOT/tagged/request flagsfalse.'}
need('all21-functions',len(funcs)==21 and set(x.name for x in funcs)==set(spec))
need('all21-author-inventory',static['top_level_functions']==[x.name for x in funcs])
bank=json.loads((C/'prospective-whole-bank-v1.json').read_bytes())
need('whole11-plus6-bank',len(bank['implemented_component_cohorts'])==11 and len(bank['unimplemented_required_whole_BOOT_cohorts'])==6)
need('no-runtime-or-completeness-overclaim',h['full_BOOT'] is False and h['full_VM'] is False and h['runtime_qualified'] is False and h['actual_execution_authorized'] is False)
matrix=[{'name':x.name,'line':x.lineno,'end':x.end_lineno,'argument':spec[x.name],
         'status':'CONDITIONAL_MANUAL_SOURCE_ARGUMENT','runtime_executed':False}for x in funcs]
findings=[
 {'id':'LV1','claim':'Canonical seed and full inputlayout are preconditions; Source is not a seedvalidator. A seed selfreference/forwardreference/duplicatepair can destroy the abstract representation invariant even if an ID exists.','required':'Program/image intake must validate full canonical/topologicalseed before any proof data; add explicit invalid-seed futurecontrols without assuming component rejects all out-of-domain seeds.'},
 {'id':'LV2','claim':'Single used-endcolon and Bpadding are preconditions; B is a terminator and helpers cannot be claimed to validate all bytes beyond it.','required':'Full initialization and later semantictraversal verify entire relevant words/regions and do not confuse successfulprefix with fullcodec/EOF acceptance.'},
 {'id':'LV3','claim':'PUBLIC3 roots remain in PARSER_STACK and CERTIFICATE2 entry clears that stack. install_postfix_pair does not preserve them.','required':'Separate v2 must retain exact immutable publicrootvalues in another validated structure before stackreuse, then exact5field requestassembly. This v1 explicitlydoes notimplement it.'},
 {'id':'LV4','claim':'Neither taggedgrammar, UTF8 heap-linked traversal, objectduplicatekeys nor outerEOF/control is supplied. Standalone qualifiedUTF8 does not certify missing linkage.','required':'Keep all6 absentwholecohorts visible; no fullBOOT/VM/checker/equalityclaim from this component.'},
 {'id':'LV5','claim':'Every helper emits only Sourcefixed sharedBuilder method calls; rawexception identity/firstRootfault and Source/closure/argument custody remain wholeRoot obligations.','required':'Use reviewedBuilderv2 and completefailures as nonadmitted. Failure can destructively alter heap/stack/scratch, with no repair/partialproofadmission.'},
 {'id':'LV6','claim':'No micro/physicaltable was generated, so fullclientM/resourcefit isunknown.','required':'Preserve exactcaps and current Source-only status; future offer must include fullmatrix/output/custody/manualenvelopes and complete applicablebanks.'}]
extra=[
 {'id':'atom-node-boundaries','recipe':'Canonical words255,256,257,511,512 plus noncanonical-highzeros; atoms accepted without heap lookup, nodecandidates require actualID. All ninebit tokenpatterns include257..511refusals.','executed':False},
 {'id':'pair-length-mismatch-skip','recipe':'Leftfield properprefix/mismatch atfirst/middle/last bit and rightfield mismatch atsemicolon; ensure scanner skips exactlycurrentrecord andCOUNT increments once.','executed':False},
 {'id':'seed-invalid-domain','recipe':'Selfreference[(257,0)], forwardchild, duplicatepair, malformedrecorddelimiter and noncanonicalchildword must be refused by fullseedintake, not credited as component semanticqualification.','executed':False},
 {'id':'stack-pop-last-boundaries','recipe':'Empty, onezero, onenil, twoandthreeref stacks; pop frombothLEFT/RIGHT; exact erasedsuffix and previousprefix; emptyunderflow neveradmitted.','executed':False},
 {'id':'public-stack-reuse','recipe':'Install both parsers, copyPUBLICroots throughfuturev2retention beforefreeparser; otherwise caller mustmark incomplete and never attribute passedrequestassembly.','executed':False}]
out={
 'schema':'typed-linked-values-v1-Source-review-v1','reviewer_identity':'/root/recovered_batch_review',
 'status':'PASS_CONDITIONAL_INTERMEDIATE_SOURCE_ONLY','review_passed':True,'source_only':True,
 'frozen_handoff':pin(C/'handoff-v1.json'),'pins':pins,
 'shared_builder_review':pin(O/'typed-shared-builder-v2-Source-review-v1.json'),
 'functions':matrix,'whole_offered_API_manual_bank_read':True,
 'whole_bank_scope':{'implemented_component_cohorts':11,'required_absent_whole_BOOT_cohorts':6,'all_unrun':True},
 'manual_argument':'Induct on actualheaprecordordinal to identify COUNT257+i, then exactpaircomparison proves canonicalreuse/uniqueappend. Induct on postfix tokens to identify actualreference stack with consumedforest. Conditions are validatedseed/layout/padding; successful exits only. No host heap instruction is a physical runtime hook.',
 'remaining_obligations':findings,'additional_unrun_recipes':extra,
 'manual_not_mechanized':True,'runtime_qualified':False,'full_BOOT_qualified':False,
 'full_VM_qualified':False,'full_codec_or_host_checker_equivalence':False,
 'new_theorem':False,'GCTS_RL_advantage_established':False,'G1_adopted':False,
 'old_G0_negative_unchanged':True,'goal_status':'active','actual_execution_authorized':False,
 'subject_imports':0,'subject_calls':0,'helper_calls':0,'compiler_calls':0,'table_generation_calls':0,
 'fixture_calls':0,'simulator_calls':0,'sizing_probes':0,'semantic_replays':0,'partial_files_opened':0,
 'new_actuals':0,'new_grants':0,'AST_parse':True,'unused_compile':True,
 'checks':checks,'failed_checks':[],'author':pin(Path(__file__)),
 'frozen_files_mutated':False,'primary_reader_index_active_mutated':False,'tools_stopped_after_freeze':True}
f=O/'typed-linked-values-v1-Source-review-v1.json';need('fresh-review',not f.exists())
f.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print(json.dumps({'review':pin(f),'functions':len(funcs),'checks':len(checks)},sort_keys=True))
