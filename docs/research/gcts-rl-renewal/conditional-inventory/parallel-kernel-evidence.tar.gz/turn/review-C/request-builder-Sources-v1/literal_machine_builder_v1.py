"""Source-only common physical microassembler; not a complete VM or checker.

All client bands and continuations are fixed Source constants, never runtime
addresses. Every operation below emits literal symbol actions. Import, build,
lowering, generation and simulation require a separately reviewed once actual.
"""
VERSION='shared-sixteen-band-literal-builder-v1'
RAW=('B','^','0','1',':',',',';','|','!','#')
WORKSPACE=('PROGRAM','PUBLIC','CERTIFICATE','HEAP','REGISTERS','FRAMES',
 'FUNCTION','PC','DESTINATION','LEFT_VALUE','RIGHT_VALUE','RETURN_VALUE',
 'COUNT','TEMPORARY','PARSER_STACK','OUTPUT')
HALTS=('ACCEPT','REJECT','BOUND','MALFORMED')
LIMIT_KEYS=('work','microstates','states','symbols','transitions','undefined_slots')
_OWNER=object()

class DeclarationError(ValueError):
    def __init__(self,reason):self.owner=_OWNER;self.reason=reason;super().__init__(reason)
class ConstructionLimit(RuntimeError):
    def __init__(self,reason):self.owner=_OWNER;self.reason=reason;super().__init__(reason)
def is_owned_declaration(error):return type(error)is DeclarationError and error.owner is _OWNER
def is_owned_limit(error):return type(error)is ConstructionLimit and error.owner is _OWNER
def require(ok,reason):
    if not ok:raise DeclarationError(reason)

class Builder:
    def __init__(self,*,check,limits):
        self.names=[];self.rows=[];self.physical_names=[];self.physical_rows=[];self.undefined=[]
        self.active=None;self.stage='DECLARATION';self.original_limits=limits;self.original_check=check
        self.phases={};self.markers=[];self.alphabet=();self.physical_slots=set()
        self.counts={key:0 for key in LIMIT_KEYS};self.check=check;self.limits=None
        try:
            require(callable(check),'explicit check callback')
            require(type(limits)is dict and set(limits)==set(LIMIT_KEYS)and all(type(k)is str for k in limits),'exact limit keys')
            require(all(type(v)is int and 0<v<=400000000 for v in limits.values()),'positive exact bounded integer limits')
            self.limits=dict(limits);self.stage='MICRO_ALLOCATION';self._step()
            for name in HALTS:self.state(name)
        except BaseException as error:self._attach(error);raise
    def _attach(self,error):
        # Raw owners stay reachable. No callback, clone, replay or size probe.
        try:
            error.literal_builder_prefix=dict(version=VERSION,stage=self.stage,counts=dict(self.counts),
                names=self.names,rows=self.rows,physical_names=self.physical_names,
                physical_rows=self.physical_rows,undefined=self.undefined,active=self.active,
                phases=self.phases,markers=self.markers,alphabet=self.alphabet,physical_slots=self.physical_slots,
                complete=False,authority=False)
        except BaseException:pass
    def _step(self,kind=None):
        self.counts['work']+=1
        if kind is not None:self.counts[kind]+=1
        try:
            if self.counts['work']>self.limits['work']:raise ConstructionLimit('work')
            if kind is not None and self.counts[kind]>self.limits[kind]:raise ConstructionLimit(kind)
            self.check()
        except BaseException as error:self._attach(error);raise
    def state(self,name):
        try:
            require(type(name)is str and name and len(name)<=256,'bounded literal state name')
            require(name not in self.names,'unique state name')
            q=len(self.names);self.names.append(name);self.rows.append(None)
            self.active=dict(operation='state',state=q,name=name);self._step('microstates');return q
        except BaseException as error:self._attach(error);raise
    def put(self,q,band,choices):
        try:
            require(type(q)is int and 4<=q<len(self.rows)and self.rows[q]is None,'unassigned working state')
            require(type(band)is int and 0<=band<16,'fixed Source band')
            require(type(choices)is dict,'literal choices dictionary')
            made=[];self.active=dict(operation='put',state=q,band=band,input=choices,produced=made)
            self._step();seen=set()
            for read,action in choices.items():
                made.append([read,action]);self._step()
                require(type(read)is str and read in RAW and read!='#'and read not in seen,'raw nonfence read')
                require(type(action)is tuple and len(action)==3,'literal action triple')
                target,write,move=action
                require(type(target)is int and target>=0,'literal continuation')
                require(type(write)is str and write in RAW and write!='#','no delimiter/header/fence construction')
                require(type(move)is int and move in(-1,0,1),'unit physical head move')
                require(read!='^'or(write=='^'and move>=0),'left delimiter unchanged and uncrossed')
                require(write!='^'or read=='^','no forged left delimiter')
                require(band>2 or write==read,'immutable program/public/certificate payload')
                seen.add(read)
            # Missing raw reads have an explicit MALFORMED completion.
            full={read:choices.get(read,(3,read,0))for read in RAW if read!='#'}
            self.rows[q]=(band,full);self.active=None
        except BaseException as error:self._attach(error);raise
    def row(self,band,choices,name):
        q=self.state(name);self.put(q,band,choices);return q
    def rewind(self,band,out,name):
        q=self.state(name)
        choices={s:((out,s,1)if s=='^'else(q,s,-1))for s in RAW if s!='#'}
        self.put(q,band,choices);return q
    def clear_word(self,band,out,name):
        done=self.rewind(band,out,name+'/after')
        loop=self.state(name+'/erase')
        self.put(loop,band,{'0':(loop,'B',1),'1':(loop,'B',1),'B':(done,'B',0)})
        return self.rewind(band,loop,name+'/before')
    def copy_word(self,src,dst,out,name):
        require(src!=dst,'copy uses distinct fixed bands')
        loop=self.state(name+'/read');done=self.rewind(dst,out,name+'/done')
        choices={'B':(done,'B',0)}
        for bit in('0','1'):
            write=self.row(dst,{'B':(loop,bit,1)},name+'/write'+bit)
            choices[bit]=(write,bit,1)
        self.put(loop,src,choices)
        start=self.rewind(src,loop,name+'/source')
        return self.clear_word(dst,start,name+'/clear')
    def compare_words(self,left,right,yes,no,name):
        require(left!=right,'comparison uses distinct fixed bands')
        loop=self.state(name+'/read')
        end=self.row(right,{'0':(no,'0',0),'1':(no,'1',0),'B':(yes,'B',0)},name+'/end')
        choices={'B':(end,'B',0)}
        for bit in('0','1'):
            test=self.row(right,{s:((loop,s,1)if s==bit else(no,s,0))for s in('0','1','B')},name+'/bit'+bit)
            choices[bit]=(test,bit,1)
        self.put(loop,left,choices)
        start=self.rewind(right,loop,name+'/right')
        return self.rewind(left,start,name+'/left')
    def increment_word(self,band,out,name):
        q=self.state(name+'/carry');done=self.rewind(band,out,name+'/done')
        self.put(q,band,{'0':(done,'1',0),'1':(q,'0',1),'B':(done,'1',0)})
        return self.rewind(band,q,name+'/begin')
    def decode_U(self,source,count,output,out,reject,name):
        require(len({source,count,output})==3,'U uses three distinct fixed bands')
        prefix=self.state(name+'/prefix')
        prefix_put=self.row(count,{'B':(prefix,'1',1)},name+'/count-put')
        first=self.state(name+'/first');after0=self.state(name+'/after0');after1=self.state(name+'/after1')
        read=self.state(name+'/read');done=self.rewind(output,out,name+'/done')
        write0=self.row(output,{'B':(after0,'0',1)},name+'/write0')
        write1=self.row(output,{'B':(after1,'1',1)},name+'/write1')
        zero=self.row(output,{'B':(done,'0',1)},name+'/zero')
        self.put(read,source,{'0':(write0,'0',1),'1':(write1,'1',1)})
        self.put(first,count,{'1':(read,'1',1),'B':(zero,'B',0)})
        self.put(after0,count,{'1':(read,'1',1),'B':(reject,'B',0)})
        self.put(after1,count,{'1':(read,'1',1),'B':(done,'B',0)})
        counted=self.rewind(count,first,name+'/count-rewind')
        self.put(prefix,source,{'1':(prefix_put,'1',1),'0':(counted,'0',1)})
        start=self.clear_word(count,prefix,name+'/count-clear')
        return self.clear_word(output,start,name+'/output-clear')
    def lower(self,entries):
        """Emit the entire literal table; not a bounded input execution.

        Valid fixed layout is a precondition, not a host proof-admission test:
        L, then all sixteen h:NAME ^ payload # bands in fixed order, then R.
        Each band has one @raw cursor. Source headers/sentinels are immutable.
        Source-owned final client must establish this initialization by tiles.
        """
        try:
            self.stage='MICRO_CLOSURE';self.active=dict(operation='lower',entries=entries)
            require(type(entries)is dict and entries and all(type(k)is str and type(v)is int and 4<=v<len(self.rows)for k,v in entries.items()),'literal working entries')
            for q,row in enumerate(self.rows):
                self._step()
                require((q<4 and row is None)or(q>=4 and row is not None),'all working states assigned')
                if row is not None:
                    for target,write,move in row[1].values():
                        self._step();require(0<=target<len(self.rows),'closed micro continuations')
            marked=tuple('@'+s for s in RAW);headers=tuple('h:'+s for s in WORKSPACE)
            alphabet=('L','R')+RAW+marked+headers;self.alphabet=alphabet
            for symbol in alphabet:self._step('symbols')
            names=[];phases={};markers=[]
            self.physical_names=names;self.phases=phases;self.markers=markers
            for name in HALTS:names.append(name);self._step('states')
            for q in range(4,len(self.rows)):
                phases[q]=tuple(range(len(names),len(names)+4))
                for phase in('select','header','find','read'):
                    names.append(phase+'/'+str(q));self._step('states')
            for q in range(len(self.rows)):
                markers.append(len(names));names.append('mark/'+str(q));self._step('states')
            def entry(q):return q if q<4 else phases[q][0]
            delta=[];self.physical_rows=delta;slots=set();self.physical_slots=slots
            def put(q,read,target,write,move):
                raw=[q,read,target,write,move];delta.append(raw)
                self.active=dict(operation='physical-row',raw_row=raw)
                self._step('transitions');require((q,read)not in slots,'one physical read slot')
                slots.add((q,read))
            self.stage='PHYSICAL_ROWS'
            for q in range(4,len(self.rows)):
                band,choices=self.rows[q];select,header,find,read=phases[q]
                for symbol in alphabet:
                    if symbol=='L':target,move=header,1
                    elif symbol=='R':target,move=3,0
                    else:target,move=select,-1
                    put(select,symbol,target,symbol,move)
                    if symbol==headers[band]:target,move=find,1
                    elif symbol in('L','R'):target,move=3,0
                    else:target,move=header,1
                    put(header,symbol,target,symbol,move)
                    if symbol in marked:target,move=read,0
                    elif symbol in RAW and symbol!='#':target,move=find,1
                    else:target,move=3,0
                    put(find,symbol,target,symbol,move)
                    if symbol in marked:
                        raw=symbol[1:]
                        if raw=='#':target,write,move=2,'@#',0
                        else:
                            out,write,move=choices[raw]
                            target=entry(out)if move==0 else markers[out]
                            write='@'+write if move==0 else write
                    else:target,write,move=3,symbol,0
                    put(read,symbol,target,write,move)
            for q,mark in enumerate(markers):
                for symbol in alphabet:
                    if symbol in RAW and symbol!='#':target,write=entry(q),'@'+symbol
                    elif symbol=='#':target,write=2,symbol
                    else:target,write=3,symbol
                    put(mark,symbol,target,write,0)
            self.stage='UNDEFINED_SLOTS';undefined=[];self.undefined=undefined
            for q in range(len(names)):
                for symbol in alphabet:
                    self._step()
                    if(q,symbol)not in slots:
                        undefined.append([q,symbol]);self.active=dict(operation='undefined',row=undefined[-1]);self._step('undefined_slots')
            require(len(names)==5*len(self.rows)-12,'Source allocation equation')
            require(len(delta)==38*(len(names)-4)and len(undefined)==152,'complete assigned slots; four undefined halts')
            self.stage='COMPLETE';self.active=None;self._step()
            return dict(schema='shared-physical-builder-table-v1',version=VERSION,states=names,alphabet=list(alphabet),
                delta=delta,undefined=undefined,entries={k:entry(v)for k,v in entries.items()},halts={name:i for i,name in enumerate(HALTS)},
                workspace=list(WORKSPACE),blank='B',micro_names=self.names,micro_rows=self.rows,
                construction_counts=dict(self.counts),complete_VM=False,proof_checker=False,runtime_qualified=False,authority=False,
                scope='Literal lowering only, valid fixed layout precondition; no BOOT/program/controller/public-target or Wang initialization linkage.')
        except BaseException as error:self._attach(error);raise
