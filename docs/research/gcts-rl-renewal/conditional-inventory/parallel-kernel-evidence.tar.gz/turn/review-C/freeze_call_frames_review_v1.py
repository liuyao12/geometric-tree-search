"""Source-only literal call-frame review; no emitted table or runtime call."""
import ast
import hashlib
import json
from pathlib import Path
N=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-linked-evidence-20261020')
R=N/'root';O=N/'review-C';C=O/'call-frames-Sources-v1';C.mkdir(exist_ok=True)
checks=[];pins=[]
def need(n,v):
    checks.append({'check':n,'passed':bool(v)})
    if not v:raise ValueError(n)
def pin(p):
    b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
for n,z,h in [
 ('runtime_call_frames_v1.py',4873,'2d149f77342ff1d51734a9da6b334448d24e42cf4ed3ff69bd472c8af6429524'),
 ('runtime-call-frames-API-v1.json',3394,'bd21cfd5f5c2be2411fc4814ab4cde00e1de709bbd28501044f8d6a6bf618d1b')]:
    raw=(R/n).read_bytes();need('raw-pin:'+n,len(raw)==z and hashlib.sha256(raw).hexdigest()==h)
    p=C/n;need('fresh-copy:'+n,not p.exists());p.write_bytes(raw);pins.append(pin(p))
t=ast.parse((C/'runtime_call_frames_v1.py').read_bytes());compile(t,'runtime_call_frames_v1.py','exec')
need('no-imports',not any(isinstance(x,(ast.Import,ast.ImportFrom))for x in ast.walk(t)))
api=json.loads((C/'runtime-call-frames-API-v1.json').read_bytes())
need('exact-Builder-v2',api['builder']['sha256']=='4d13b99f90e9658508dcd4a289ece2d93bd21d862e4153a431a91ce17d78da20')
need('all-four-families-unrun',len(api['prospective_families'])==4 and api['all_unrun'] is True)
need('scope-no-full-VM',api['full_VM'] is False and api['authority'] is False and api['subject_calls']==api['generations']==api['simulations']==0)
spec={
 '_clear_vector':'Erase complete0/1/semicolon vector untilcolon/B andrewind R4, leaving blankpayload. Validvector/Bpadding are callerpreconditions; not arbitrary malformedpayloadvalidator.',
 '_append_word':'Rewind fixedsource, copyallbits into FRAMESB cells andappend suppliedfixeddelimiter. Payloadsource unchanged; nonemptycanonicalinput is a precondition, not checked by helper.',
 'frame_push':'Seek uniqueusedcolon ofvalid FRAMESlist, eraseit then append completeF6,PC7,D8 withcomma/comma/pipe, fullR4records, ! andnewcolon. Every sourcepayload includingVALUE11/BUFFER14 remains unchanged; partialappendfailure unadmitted.',
 '_pop_field':'Clear destinationword, require firstsourcebit, copy/erase everybit until declaredcomma/pipe, erase delimiter andrewind destination. Sourcecursor then points tonextfield. Priorframes outside copiedinterval untouched.',
 'frame_pop':'Seekcolon, examine preceding! or^; empty takes suppliednonacceptport withoutpayloadchanges. Otherwise backscan lastframe toprevious!/^, clearcalleeR, restorefullF6/PC7/D8, copy/eraseentire savedR, erase! andoldcolon; scan erasedB backward toprevious!/^ then writeprefixcolon. VALUE11 andallotherbands preserved.'}
funcs=[n for n in t.body if isinstance(n,ast.FunctionDef)]
need('all-five-functions',len(funcs)==5 and set(x.name for x in funcs)==set(spec))
recipes=[
 {'id':'empty-frame-nonaccept','recipe':'FRAMES^: withVALUE11=0,1,256 andlongnodeID; poptakes declaredemptyport, never componentout. Rootmust separately decide whether value1 means acceptance. Nopayloadwrite exceptcursorrelocation.','executed':False},
 {'id':'nested-frame-prefix-inverse','recipe':'Depth1/2with distinctfn/pc/dest andvectorsincludingempty; pushthenpoprestoreexactlatestF/PC/D/R andstrictpreviousframeprefix. Allsavedwordlengthrelations including0/255/256/257.','executed':False},
 {'id':'full-register-restore','recipe':'CallerRlonger/shorter/empty than currentcalleeR, repeatedrefs andnonnilnodevalues; restorationmust copyentirevector andclearstaletail, notonlytouchedregisters.','executed':False},
 {'id':'callee-return-and-cache-preservation','recipe':'DistinguishableVALUE11andBUFFER14/argumentcachebeforepop; verifyfullpayloadunchangedthroughrestore, and Rootsubsequentregisterwrite uses restoredD8 andsavedVALUE11.','executed':False},
 {'id':'frame-delimiters-and-cutoffs','recipe':'Fenceeveryneededheaderword/vector/!/colonwrite andrestorationcell. Missingcomma/pipe/!/: andemptyfieldcontrols distinguishedfromvalid-domain theorem; destructivefailure neverrepairedoradmitted.','executed':False},
 {'id':'caller-next-PC-and-args','recipe':'PC7mustalreadybe callercontinuation; allactualargumentvaluescapturedbeforeanycalleeRoverwrite; fn/PC/dest/arityboundsvalidatedbyfuturecontroller, notbyframeprimitives.','executed':False}]
out={
 'schema':'typed-runtime-call-frames-v1-Source-review-v1','reviewer_identity':'/root/recovered_batch_review',
 'status':'PASS_CONDITIONAL_COMPONENT_SOURCE_ONLY','review_passed':True,'source_only':True,
 'pins':pins,'full_Source_API_manual_plan_read':True,
 'builder_review':pin(O/'typed-shared-builder-v2-Source-review-v1.json'),
 'function_matrix':[{'name':x.name,'line':x.lineno,'end':x.end_lineno,'argument':spec[x.name]}for x in funcs],
 'manual_argument':'Under validfixedlayout/canonicalwords/completevalidR and FRAMESgrammar, pushappendsoneexactfullframe. Inpop, last! andbackscanprevious!/^ uniquelyidentifylatestframe. Forwarddestructivefieldcopies restoreall3words andentireR, then backwardBscan reinstatescolon atpreciseprefixboundary. Thus push/pop are payloadinverses forcallercontext whilecalleeVALUE11remainsunchanged. Empty/capacity/malformedstatuses confer noacceptanceauthority.',
 'whole_four_family_bank_read':True,'all_recipes_unrun':True,'additional_unrun_recipes':recipes,
 'remaining_obligations':[
  'FullRootcontroller supplies nonaccepting emptyport; Source does not itself ban passing ACCEPT as that continuation. Genericcomponentparameters are trustedfixedSource and must be validated by wholeclient/invariant proof.',
  'Fullframelist/canonicalreference/wordandprogramarity/index invariants must be established physically beforeuse; helpers are not completearbitrarygrammarvalidators.',
  'Full13opcodefetch/callargcapture, operandalias patterns, nextPCincrement, sourceoperandpreservation, rootVALUE11exact1condition and programseed/parser remain absent.',
  'Valid16bandinitialization, public/theory/target/Wangselectorbinding and noextraACCEPT/stuttering proof remain open.',
  'Source/default/closure/argument/callback/rawprefix custody andfirstRootfault beforeownedclassification; failedconstruction/runtimeprefix neveradmitted orresumedasrescue.',
  'No machine/table/statecensus or fit was generated; original400m/180/210/1GiB/128MiBexpanded-stored-physical/9MiBreserve/logcaps unchanged.'],
 'manual_argument_not_mechanized':True,'runtime_qualified':False,'full_VM_qualified':False,
 'new_theorem':False,'GCTS_RL_advantage_established':False,'G1_adopted':False,
 'old_G0_negative_unchanged':True,'goal_status':'active','AST_parse':True,'unused_compile':True,
 'subject_imports':0,'subject_calls':0,'helper_calls':0,'compiler_calls':0,'fixture_calls':0,
 'simulator_calls':0,'table_generation_calls':0,'sizing_probes':0,'semantic_replays':0,
 'partial_files_opened':0,'new_actuals':0,'new_grants':0,'actual_execution_authorized':False,
 'checks':checks,'failed_checks':[],'author':pin(Path(__file__)),'frozen_files_mutated':False,
 'primary_reader_index_active_mutated':False,'tools_stopped_after_freeze':True}
p=O/'typed-runtime-call-frames-v1-Source-review-v1.json';need('fresh-review',not p.exists())
p.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n');print(json.dumps({'review':pin(p),'checks':len(checks)},sort_keys=True))
