"""Independent static shape mismatch; no graph/checker execution."""
import ast
import hashlib
import json
from pathlib import Path
N=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-linked-evidence-20261020')
O=N/'review-C';B=N/'schema-B';C=O/'parent-snapshot-negative-preimages-v1';C.mkdir(exist_ok=True)
checks=[];pins=[]
def need(n,v):
    checks.append({'check':n,'passed':bool(v)})
    if not v:raise ValueError(n)
def pin(p):
    raw=p.read_bytes();return {'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
h=json.loads((B/'handoff-v1.json').read_bytes())
gr=h['dependencies']['graph'];vr=next(r for r in h['artifacts']if Path(r['path']).name=='validate_linked_evidence_v1.py')
for row,name in [(gr,'implicit_wang_point_search_v1.py'),(vr,'validate_linked_evidence_v1.py')]:
    p=Path(row['path']);raw=p.read_bytes();need('pin:'+name,len(raw)==row['bytes']and hashlib.sha256(raw).hexdigest()==row['sha256'])
    dest=C/name;need('fresh:'+name,not dest.exists());dest.write_bytes(raw);pins.append(pin(dest))
graw=(C/'implicit_wang_point_search_v1.py').read_bytes();vraw=(C/'validate_linked_evidence_v1.py').read_bytes()
gt=ast.parse(graw);vt=ast.parse(vraw)
core=next(x for x in ast.walk(gt)if isinstance(x,ast.FunctionDef)and x.name=='_core_plain')
obs=next(x for x in ast.walk(gt)if isinstance(x,ast.FunctionDef)and x.name=='_observe')
population=next(x for x in vt.body if isinstance(x,ast.FunctionDef)and x.name=='_packet_population')
corekeys=next([k.value for k in x.value.keys]for x in ast.walk(core)if isinstance(x,ast.Return)and isinstance(x.value,ast.Dict))
extras=next([k.value for k in x.args[0].keys]for x in ast.walk(obs)if isinstance(x,ast.Call)and isinstance(x.func,ast.Attribute)and x.func.attr=='update'and x.args and isinstance(x.args[0],ast.Dict))
expected=next(ast.literal_eval(x)for x in ast.walk(population)if isinstance(x,ast.Set)and len(x.elts)==14 and any(isinstance(z,ast.Constant)and z.value=='descriptor'for z in x.elts))
actual=set(corekeys+extras)
need('both14keys',len(actual)==len(expected)==14)
need('exact-single-key-mismatch',actual-expected=={'palette_descriptor'}and expected-actual=={'descriptor'})
worker=(O/'linked-parent-negative-preimages-v1/qualify_linked_batch_worker_v1.py').read_text()
need('worker-retains-snapshot-unchanged','observations.append(dict(snapshot=snapshot,independent_domains=domains,complete=True))'in worker)
out={
 'schema':'typed-linked-parent-snapshot-schema-negative-v1','reviewer_identity':'/root/recovered_batch_review',
 'status':'FAIL_SOURCE_GRAPH_SNAPSHOT_SCHEMA_MISMATCH','review_passed':False,'source_only':True,
 'full_offer_review_completed':False,'raw_preimages':pins,
 'frozen_offer':pin(O/'linked-parent-negative-preimages-v1/handoff-v1.json'),
 'custody_only_successor_handoff':pin(B/'custody-v2/handoff-v2.json'),
 'independent_confirmation':'B author reported this separate issue while deriving bounds; reviewer independently read and AST-extracted exact emitted/core and required sets from frozen Sources. No graph observation was regenerated.',
 'graph_emitter':{'function':'_observe','line':obs.lineno,'end':obs.end_lineno,
    'core_keys':corekeys,'updated_keys':extras,'full_snapshot_keys':sorted(actual)},
 'schema_requirement':{'function':'_packet_population','line':population.lineno,'end':population.end_lineno,
    'required_exact_keys':sorted(expected)},
 'mismatch':{'present_unexpected':'palette_descriptor','required_absent':'descriptor'},
 'manual_argument':'Every actual complete graph snapshot retains palette_descriptor. Worker stores that snapshot without a rename. Exact-set validation requires descriptor instead, so inspecting any such observation fails even when all graph checking and complete value correspondence succeeded. The custody-onlyv2 leaves this validator unchanged.',
 'scope':'Encoding/completeness defect in candidate parent schema, not an observed graph failure, false theorem, resource result or G1adoption.',
 'required_successor':'Preserve original emitted palette_descriptor and every descendant; separately named schema successor must require its exact correct field and add a real original-shape/renamed-shape unrun control. Do not rename/trim old graph evidence to satisfy wrong schema.',
 'unrun_recipes':[
  {'id':'real-original-shape','recipe':'Future fullparent suppliedwith real complete graph observation whose14keysinclude palette_descriptor must pass this shape gate if all otherobligations hold.','executed':False},
  {'id':'incorrect-rename','recipe':'Rename palette_descriptor to descriptor whilekeepingfullpayload; independentexpectedvalue join and correctschema mustrefuse, notrepair.','executed':False},
  {'id':'full-original-graph-population','recipe':'Retain all10graphcases/everyobservation/rollback/domain/scheduler/output and allold15/33+28/55. A literalone-rowshapecontrol isnotfullqualification.','executed':False}],
 'G1_adopted':False,'old_G0_negative_unchanged':True,'goal_status':'active',
 'subject_imports':0,'subject_calls':0,'helper_calls':0,'compiler_calls':0,'checker_calls':0,
 'fixture_calls':0,'simulator_calls':0,'sizing_probes':0,'semantic_replays':0,'partial_files_opened':0,
 'AST_parses':2,'new_actuals':0,'new_grants':0,'actual_execution_authorized':False,
 'checks':checks,'failed_static_metadata_checks':[],'author':pin(Path(__file__)),
 'frozen_sources_mutated':False,'primary_reader_index_active_mutated':False,'tools_stopped_after_freeze':True}
p=O/'typed-linked-parent-snapshot-schema-negative-v1.json';need('fresh-negative',not p.exists())
p.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n');print(json.dumps({'negative':pin(p),'checks':len(checks)},sort_keys=True))
