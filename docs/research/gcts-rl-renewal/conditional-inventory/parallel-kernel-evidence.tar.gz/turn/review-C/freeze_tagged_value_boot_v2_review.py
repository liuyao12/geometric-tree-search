"""Independent literal Source/AST/manual review; never build or run BOOT."""
import ast
import hashlib
import json
from pathlib import Path
N=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-linked-evidence-20261020')
O=N/'review-C';L=N/'physical-L';C=O/'tagged-BOOT-Sources-v2';C.mkdir(exist_ok=True)
checks=[];pins=[]
def need(n,v):
    checks.append({'check':n,'passed':bool(v)})
    if not v:raise ValueError(n)
def pin(p):
    b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def checked(row,label):
    p=Path(row['path']);need(label+':no-partial','.partial' not in p.name);raw=p.read_bytes()
    need(label+':raw-pin',len(raw)==row['bytes']and hashlib.sha256(raw).hexdigest()==row['sha256']);return raw
def exact(a,b):
    if type(a)is not type(b):return False
    if type(a)is dict:return set(a)==set(b)and all(exact(a[k],b[k])for k in a)
    if type(a)is list:return len(a)==len(b)and all(exact(x,y)for x,y in zip(a,b))
    return a==b
hraw=(L/'handoff-v2.json').read_bytes()
need('handoff-exact',len(hraw)==5305 and hashlib.sha256(hraw).hexdigest()=='cc8de8d62e27b0a02bfd500d46edb501d9e1069184f986671e0ea4ea9d472163')
h=json.loads(hraw)
for row in h['members']+[h['manifest']]:
    raw=checked(row,'member:'+Path(row['path']).name);p=C/Path(row['path']).name
    need('fresh:'+p.name,not p.exists());p.write_bytes(raw);pins.append(pin(p))
p=C/'handoff-v2.json';need('fresh-handoff',not p.exists());p.write_bytes(hraw)
manifest=json.loads((C/'freeze-manifest-v2.json').read_bytes())
need('manifest-exact-members',exact(manifest['members'],h['members']))
lineage=json.loads((C/'lineage-pins-v2.json').read_bytes())
for i,row in enumerate(lineage['additional_members']+lineage['all_v1_lineage_members_retained']):checked(row,'lineage:'+str(i))
raw=(C/'linked_boot_values_v2.py').read_bytes();t=ast.parse(raw);compile(t,'linked_boot_values_v2.py','exec')
need('no-imports',not any(isinstance(n,(ast.Import,ast.ImportFrom))for n in ast.walk(t)))
fn={n.name:n for n in t.body if isinstance(n,ast.FunctionDef)}
author=json.loads((C/'author-static-audit-v2.json').read_bytes())
need('full41function-inventory',len(fn)==41 and list(fn)==author['functions'])
oldraw=(O/'linked-values-Sources-v1/linked_boot_values_v1.py').read_bytes();ot=ast.parse(oldraw)
oldfn={n.name:n for n in ot.body if isinstance(n,ast.FunctionDef)}
def body(n):
    statements=n.body
    if statements and isinstance(statements[0],ast.Expr)and isinstance(statements[0].value,ast.Constant)and type(statements[0].value.value)is str:statements=statements[1:]
    return ast.dump(ast.Module(body=statements,type_ignores=[]),include_attributes=False),ast.dump(n.args,include_attributes=False)
for name,node in oldfn.items():need('v1-control-body-preserved:'+name,name in fn and body(node)==body(fn[name]))
oldreview=json.loads((O/'typed-linked-values-v1-Source-review-v1.json').read_bytes())
spec={x['name']:{'argument':x['argument'],'lineage':'Reviewedv1; semantic ASTbody/args unchanged (docstrings excluded).'}for x in oldreview['functions']}
new_specs={
 '_word_is':'Exact fixed Sourcebitword match withB simultaneousend, preservingword; everybranch rewindsbeforetesting, so chained tag/type tests seeoriginalvalue.',
 '_push_word_to':'Append actual sourceword to private task/outputrecordstack, including semicolon/newcolon. Inputnonempty canonicalword/validstack layout required; no runtime hostcontainer.',
 '_pop_word_from':'Pop actuallastword into destination with erasure/colonrestoration; same physicalstructure asv1stackpop. Validprivatewordrecordgrammar assumed; no hoststack/index.',
 '_empty_records':'Checkfirstcellafter^ isexactcolon, preservingit; used forcomplete task/frame/output cleanup assertions.',
 '_records_to_empty_word':'Requireemptyrecordcolon and eraseit toB; explicit mode switch after allsource roots popped.',
 '_word_to_empty_records':'Clear fullbitword andplaceemptycolon; explicit buffer->record switch beforefreeparse andfinalreturn.',
 '_copy_records_to_output':'FindOUTPUTcolon and appendallSTACKrecords inoriginalorder, preservingSourceSTACK. Used onlyafterexact3/2rootcount sofullpublic/free roots retained independently oflaterSTACKclear.',
 '_push_task':'Fixedkind0/1/2Sourcearg only; appendtype thennode actualword so nodepopsfirst. COUNTliteraltype clobbered; LEFT/RIGHT/RETURNsourcecontents preserved ascallerrequires.',
 '_open_key_frame':'ReplaceFRAMESusedcolon with| andnewcolon; marksinnermostobjectkeyscope physically.',
 '_close_key_frame':'Scanlastcolon backward eraseonlycurrentkeyrecords untilinnermost|, replacebarbycolon; previousobjectframecontents preserved.',
 '_unique_key_and_append':'Findinnermost| then compareLEFTkeyrefagainst everykeyref through itscolon withexactwordendalignment. Mismatchskips currentrecord; exactduplicateinvalid. Newkeyrefappendedbeforevalidation; anyinvalidkey laterrejectsentirerun.',
 '_append_byte':'ReadLEFTcanonicalbyteword, copyatmost8bits into currentSTACKbufferposition andpadshortwords withzeros toexactly8LSBbits; a ninthbit refuses. Atom256/nodeIDs cannot masquerade asbyte.',
 '_link_utf8':'Mapeveryliteralworkingrow fromfreshfullqualifiedtable ontoSTACK. Exact4slots/workingstate, halts/entries/undefineds/type/move/write/fencechecks. DONEout,REJECT1,BOUND2. Shapecheck doesnotcertifysemanticprovenance/freshness; RootmustbindwholefreshSource result.',
 '_byteword':'Traverse propercanonicalheaplist viaRETURN, lookupLEFTbyte/RIGHTtail, append8bits, copytailtoRETURN anditerate; nil256rewindsentirebufferintolinkedUTF8. No hostdecoder or partialbyteaccept.',
 '_unary':'Traverse properpairlist whoseheadsareexact1; nilendspositive, negativefirstentryexcludesnil. Impropertails/headmutationslookup/refusal. No nativeinteger predicate inrows.',
 '_tagged_validator':'Physicaltaskdispatch VALUE/ARRAYTAIL/OBJECTTAIL checksactualheaprefs andexact0..6tags. AllchildVALUE obligations pushedaftertail soLIFOvisitschildbeforeparenttail. Objectframeopen/close matchesnestedlifetime; bytewords/string/keys passlinkedUTF8, Boolean/null/unary normalforms exact.',
 '_schedule_stack_roots':'Unrolledfixedcount3/2, popactualroots andscheduleeachVALUE; allroots popped beforeSTACKcolon becomesB buffer. No depth/input-derived state allocation.',
 '_fixed_key':'Onlyliteralprotocol/theory/target/blocks/proofASCIIkeys,31totalbytes; reverse Sourceunrolling leads runtimecons construction incorrectbyteorder. TEMPvalue preserved becausecanonicalcons neverwritesband13.',
 '_request_assembly':'OUTPUTfivevalues popproof,blocks,target,theory,protocol; buildrawkey/valuepair thenprependrow intorowlist heldSTACKword. Wraptag0 andcheckemptyOUTPUT/TASKS/FRAMES, clearSTACKword->emptycolon. RETURNrequestroot survivescleanup.',
 'install_value_boot':'Freshrootstaticassembly, explicitcheck/outworking>=4/invalid1/nameguard; assembleprivatebodies thenactualexecution PUBLIC3 save/schedule/validate, STACKmode switch, CERT2 save/schedule/validate, exactrequest. Initialprivateclear andfailureprefixrawowners present; noACCEPT orVMcontroller.'}
for name,arg in new_specs.items():need('new-helper-unique:'+name,name not in spec);spec[name]={'argument':arg,'lineage':'Newv2 Source manually read in full.'}
need('all41manual-rows',set(fn)==set(spec))
bank=json.loads((C/'prospective-whole-bank-v2.json').read_bytes())
oldbank=json.loads((O/'linked-values-Sources-v1/prospective-whole-bank-v1.json').read_bytes())
need('entire-priorbank-retained',exact(bank['prior_full_bank_unchanged'],oldbank))
need('all23new-cohorts',len(bank['new_cohorts'])==23 and len({x['id']for x in bank['new_cohorts']})==23)
need('prior11-plus6',len(oldbank['implemented_component_cohorts'])==11 and len(oldbank['unimplemented_required_whole_BOOT_cohorts'])==6)
api=json.loads((C/'API-v2.json').read_bytes())
need('explicit-incomplete-full-BOOT',api['full_BOOT']is False and h['full_BOOT']is False and h['complete_interpreter']is False and h['runtime_qualified']is False)
need('declared-fixedlimits',api['limits']=={'Root_callback_max':400000000,'aggregate_stored_and_expanded_bytes':134217728,
 'each_log_and_header_bytes':4194304,'memory_bytes':1073741824,'outer_reserved_bytes':9437184,'positive_seconds':180,'terminal_seconds':210})
need('working-success-not-ACCEPT','out<4' in raw.decode()and'full_BOOT' in raw.decode())
matrix=[{'name':name,'line':node.lineno,'end':node.end_lineno,**spec[name],
         'status':'CONDITIONAL_MANUAL_SOURCE_ARGUMENT','executed':False}for name,node in fn.items()]
argument={
 'canonical-heap':'Use reviewedv1argument underphysicallyvalidateduniquepair/topologicalseed. ExactexistingIDrefs andnewappenddenotations remainstable; equalityofpropercanonicalbytewordstructure impliesequalref.',
 'tasks':'Maintainorderedtasks(type,node) withactualwordrecords andnestedFRAMESobjectscopes. Eachcontainer schedulesrestbeforechild; LIFOcompleteschild(andanynestedframes) beforeparentrest. Allpendingnodes eventuallychecked underacyclicseed; sharing mayrepeatwork.',
 'strings-and-keys':'Everyrawlisthead mustbe byteatom0..255; buffercontains eightLSBbits perhead withnointerbytepadding. LinkedfreshUTF8table checkswholeword atnil. Objectduplicatekeys comparecompletecanonicalrefs withininnermostframe; canonicalnativeUTF8encoding isinjective ondeclarednativecodepointsequences. No rawJSONnormalization inferred.',
 'public-and-request':'OUTPUTkeepspublic3beforefreeparserclearsSTACK, thenappendsfree2. Assemblypopsreverse5roots andprependsmatchingfixedkeyrows. TEMPpoppedvalue notclobberedbykeycons. Entireobjectorderedprotocol/theory/target/blocks/proof; no hostrequestconstructorintransitions.',
 'success-cleanup':'TASKS/FRAMES/OUTPUTcheckedempty, STACKclearedfromrowlistwordtoemptycolon; F6/PC7/D8neverusedbyinstalledbody. RETURNcontainscanonicalrequestref atRootworkingcontinuation, nottheoremacceptance.',
 'termination-and-cost':'Topologicalchildren strictlysmallerID establishfinitetraversal onfiniteinput; heapscans/binarycopy/taskunfolding stillcostrealwork andcapacity. This isnotpolynomialbound, horizonbound, generatedcensus or128MiBfit.'}
gaps=[
 {'id':'LV2-G1','obligation':'Rootactualinitializationtiles physicallyenforceall16bands/cursors/headers/nooverlap, immutableprogram/public/certificatepins andcanonicalwordpadding. Nohiddenhostlayoutpredicate canqualifyproof.'},
 {'id':'LV2-G2','obligation':'Completeimmutableprogram/seedloader physicallyvalidatecanon/topologicaluniquepairs beforeentry; generichelpers preservebutdonotestablishthosepreconditions.'},
 {'id':'LV2-G3','obligation':'ProjectedEOFmeansfixedcolon plusphysicalpostcolonBpins to#; bodydoesnotrejectarbitrarypostcolondata itself. Selectorcannotemit/movecolon; Rootintake/selectorbody remainsabsent.'},
 {'id':'LV2-G4','obligation':'FreshwholeUTF8generation mustbe ownedandboundto08f947Source insidefuturewholeactual. Savedqualifiedtable/admission2fc8 doesnotgrantnewexecution orprovefreshlinkerprovenance.'},
 {'id':'LV2-G5','obligation':'Inputdomain nativeorderedtaggedvalues withsurrogatepass bytewords, includingseparatenativeadjacentsurrogates. RawJSONimage/escape-normalization/expectedproblemhashinjectivity remainsseparateoriginalF6, never silentlyequated.'},
 {'id':'LV2-G6','obligation':'Root13opcodefetch/controller/programmetadata/register/frame/call/return andsuppliedworkingcontinuation linkage, exactrootreturn1ACCEPT, publiclicensing andnoextraaccept stillopen.'},
 {'id':'LV2-G7','obligation':'CompletewholeSource/banks/outerepochs/resource/writer/expansion/callbackcustodyfirstfault reviewandfreshonceauthorization beforeanygeneration/execution. No goodpartial/rescue/retry orunknown->theoremnegative.'}]
extra=[
 {'id':'nested-key-lifetime','recipe':'Outerkeyx pluschildobjectkeyx thenparenttailduplicatex: childscope reusevalid, laterparentduplicateinvalid; retainallframecells.','unrun':True},
 {'id':'task-scratch-alias-preservation','recipe':'DistinctRETURN/LEFT/RIGHT/TEMPsentinels atarrays/objectrows/keyUTF8/requestkeycons; scheduledchildref andpoppedrequestvalue surviveCOUNT/heaplookups exactly.','unrun':True},
 {'id':'whole-native-surrogate-distinction','recipe':'Usecodepointlists[65536]and[55296,56320]asdistinctnativekeys/values; keepUTF8surrogatepasswordidentity, avoidJSONstringnormalizationfixture.','unrun':True},
 {'id':'projected-colon-contract','recipe':'SamevalidthroughcolonforestwithpostcolonBversusdata mustbedistinguishedbyRootinitializer/selector; noincorrectcomponentallbandEOFclaim.','unrun':True},
 {'id':'full-table-provenance-and-metadata','recipe':'PreservefreshfullUTF8root/table/rawowners; rowshapecontrolalone cannotlicensearbitrarytable. Missing/declarationwrongtypesrefusals neverclasslaundered.','unrun':True}]
out={
 'schema':'typed-linked-tagged-value-BOOT-v2-Source-review-v1','reviewer_identity':'/root/recovered_batch_review',
 'status':'PASS_CONDITIONAL_VALUE_BODY_SOURCE_ONLY','review_passed':True,'source_only':True,
 'handoff':pin(C/'handoff-v2.json'),'pins':pins,'source_function_matrix':matrix,
 'full_Source_API_manual_and_complete_bank_read':True,'manual_argument':argument,
 'bank_scope':{'preserved_component_cohorts':11,'preserved_historical_gap_records':6,'new_cohorts':23,
  'all_unrun':True,'standalone_UTF8_dependency_cases_required':5378,'counts_are_declarative_not_executed':True},
 'body_implemented_conditionally_in_Source':True,'manual_argument_not_mechanized':True,
 'remaining_obligations':gaps,'additional_unrun_recipes':extra,
 'AST_parse':True,'unused_compile':True,'old21semantic_AST_bodies_preserved':True,
 'runtime_qualified':False,'full_BOOT_qualified':False,'complete_interpreter':False,
 'full_CodecV2_or_host_checker_equivalence':False,'new_theorem':False,'proof_discovery':False,
 'GCTS_RL_advantage_established':False,'G1_adopted':False,'old_G0_negative_unchanged':True,'goal_status':'active',
 'subject_imports':0,'subject_calls':0,'helper_calls':0,'compiler_calls':0,'checker_calls':0,
 'fixture_calls':0,'simulator_calls':0,'table_generation_calls':0,'sizing_probes':0,'semantic_replays':0,
 'partial_files_opened':0,'new_actuals':0,'new_grants':0,'actual_execution_authorized':False,
 'checks':checks,'failed_checks':[],'author':pin(Path(__file__)),'frozen_files_mutated':False,
 'primary_reader_index_active_mutated':False,'tools_stopped_after_freeze':True}
p=O/'typed-linked-tagged-value-BOOT-v2-Source-review-v1.json';need('fresh-review',not p.exists())
p.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n');print(json.dumps({'review':pin(p),'checks':len(checks),'functions':len(matrix)},sort_keys=True))
