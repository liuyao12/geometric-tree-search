class _NamedOwnerSeal:
    """Real retained owner graph; equality compares only exact scalar edge rows."""
    def __init__(self, rows, owners):
        self.rows=rows
        self.owners=owners
    def __eq__(self, other):
        return type(other)is _NamedOwnerSeal and self.rows==other.rows
    def __ne__(self, other):
        return not self.__eq__(other)


def _recursive_function_owner_seal(value):
    """Cycle-safe node traversal; EVERY named/slot edge occurrence is recorded.

    Nodes are visited once, edges are never deduplicated. Class member names,
    exact descriptor type/owner and accessor/target bindings remain explicit.
    Actual original objects are held strongly in _NamedOwnerSeal.owners; integer
    IDs alone never finance GC/rebinding or reconstruct executable custody.
    """
    need(type(value)is types.FunctionType,'owned synchronous callback function')
    pending=[value];seen=set();rows=[];owners=[value]
    def edge_owner(owner):
        owners.append(owner)
        if type(owner)is types.FunctionType or type(owner)is type:
            pending.append(owner)
        return id(owner)
    while pending:
        node=pending.pop();identity=id(node)
        if identity in seen:continue
        seen.add(identity);owners.append(node)
        if type(node)is types.FunctionType:
            code=node.__code__;defaults=node.__defaults__;kw=node.__kwdefaults__
            closure=node.__closure__;owners.extend((code,defaults,kw,closure))
            default_edges=[]
            if defaults is not None:
                need(type(defaults)is tuple,'exact function default tuple owner')
                for index,content in enumerate(defaults):
                    default_edges.append((index,edge_owner(content)))
            kw_edges=[]
            if kw is not None:
                need(type(kw)is dict and all(type(k)is str for k in kw),
                     'exact named keyword-default owners')
                for name,content in sorted(kw.items()):
                    kw_edges.append((name,edge_owner(content)))
            cells=[]
            if closure is not None:
                for index,cell in enumerate(closure):
                    owners.append(cell)
                    try:
                        content=cell.cell_contents
                    except ValueError:
                        cells.append((index,id(cell),False,None))
                    else:
                        cells.append((index,id(cell),True,edge_owner(content)))
            rows.append(('function',identity,id(code),id(defaults),id(kw),id(closure),
                         tuple(default_edges),tuple(kw_edges),tuple(cells)))
            continue
        need(type(node)is type,'only exact function/class owner nodes traversed')
        bases=node.__bases__;mro=node.__mro__
        owners.extend((bases,mro))
        base_edges=[]
        for index,base in enumerate(bases):
            base_edges.append((index,edge_owner(base)))
        mro_edges=[]
        for index,base in enumerate(mro):
            mro_edges.append((index,edge_owner(base)))
        members=[]
        namespace=vars(node)
        need(all(type(name)is str for name in namespace),'exact class member names')
        for name,member in sorted(namespace.items()):
            owners.append(member)
            kind=type(member);target=None;accessors=()
            if kind is staticmethod or kind is classmethod:
                target=edge_owner(member.__func__)
            elif kind is property:
                accessor_edges=[]
                for label,accessor in (('fget',member.fget),('fset',member.fset),('fdel',member.fdel)):
                    accessor_edges.append((label,edge_owner(accessor)))
                accessors=tuple(accessor_edges)
                owners.append(member.__doc__)
                target=id(member.__doc__)
            else:
                target=edge_owner(member)
            members.append((name,id(kind),id(member),target,accessors))
        rows.append(('class',identity,id(type(node)),id(bases),tuple(base_edges),
                     id(mro),tuple(mro_edges),tuple(members)))
    return _NamedOwnerSeal(tuple(sorted(rows)),tuple(owners))

