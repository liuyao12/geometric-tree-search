# UNEXECUTED Root integration fragment for the complete original cohort.
# Appended verbatim to the successor worker Source by metadata authoring only.


class _NamedOwnerSeal:
    """Real retained owner graph; equality compares only exact scalar edge rows."""
    def __init__(self, rows, owners):
        self.rows=rows
        self.owners=owners
    def __eq__(self, other):
        return type(other)is _NamedOwnerSeal and self.rows==other.rows
    def __ne__(self, other):
        return not self.__eq__(other)


def _recursive_function_owner_seal(value):
    """Cycle-safe node traversal; EVERY named/slot edge occurrence is recorded.

    Nodes are visited once, edges are never deduplicated. Class member names,
    exact descriptor type/owner and accessor/target bindings remain explicit.
    Actual original objects are held strongly in _NamedOwnerSeal.owners; integer
    IDs alone never finance GC/rebinding or reconstruct executable custody.
    """
    need(type(value)is types.FunctionType,'owned synchronous callback function')
    pending=[value];seen=set();rows=[];owners=[value]
    def edge_owner(owner):
        owners.append(owner)
        if type(owner)is types.FunctionType or type(owner)is type:
            pending.append(owner)
        return id(owner)
    while pending:
        node=pending.pop();identity=id(node)
        if identity in seen:continue
        seen.add(identity);owners.append(node)
        if type(node)is types.FunctionType:
            code=node.__code__;defaults=node.__defaults__;kw=node.__kwdefaults__
            closure=node.__closure__;owners.extend((code,defaults,kw,closure))
            default_edges=[]
            if defaults is not None:
                need(type(defaults)is tuple,'exact function default tuple owner')
                for index,content in enumerate(defaults):
                    default_edges.append((index,edge_owner(content)))
            kw_edges=[]
            if kw is not None:
                need(type(kw)is dict and all(type(k)is str for k in kw),
                     'exact named keyword-default owners')
                for name,content in sorted(kw.items()):
                    kw_edges.append((name,edge_owner(content)))
            cells=[]
            if closure is not None:
                for index,cell in enumerate(closure):
                    owners.append(cell)
                    try:
                        content=cell.cell_contents
                    except ValueError:
                        cells.append((index,id(cell),False,None))
                    else:
                        cells.append((index,id(cell),True,edge_owner(content)))
            rows.append(('function',identity,id(code),id(defaults),id(kw),id(closure),
                         tuple(default_edges),tuple(kw_edges),tuple(cells)))
            continue
        need(type(node)is type,'only exact function/class owner nodes traversed')
        bases=node.__bases__;mro=node.__mro__
        owners.extend((bases,mro))
        base_edges=[]
        for index,base in enumerate(bases):
            base_edges.append((index,edge_owner(base)))
        mro_edges=[]
        for index,base in enumerate(mro):
            mro_edges.append((index,edge_owner(base)))
        members=[]
        namespace=vars(node)
        need(all(type(name)is str for name in namespace),'exact class member names')
        for name,member in sorted(namespace.items()):
            owners.append(member)
            kind=type(member);target=None;accessors=()
            if kind is staticmethod or kind is classmethod:
                target=edge_owner(member.__func__)
            elif kind is property:
                accessor_edges=[]
                for label,accessor in (('fget',member.fget),('fset',member.fset),('fdel',member.fdel)):
                    accessor_edges.append((label,edge_owner(accessor)))
                accessors=tuple(accessor_edges)
                owners.append(member.__doc__)
                target=id(member.__doc__)
            else:
                target=edge_owner(member)
            members.append((name,id(kind),id(member),target,accessors))
        rows.append(('class',identity,id(type(node)),id(bases),tuple(base_edges),
                     id(mro),tuple(mro_edges),tuple(members)))
    return _NamedOwnerSeal(tuple(sorted(rows)),tuple(owners))


def _evidence_scope(s):
    scope=dict(s.evidence_scope)
    context=s.profile_query_context
    if type(context)is dict:
        scope['profile_id']=context['id']
    return scope


def _evidence_invoke(s,kind,role,operation,args,action,after=None,case_id=None):
    previous=dict(s.evidence_scope)
    if case_id is not None:
        s.evidence_scope['case_id']=case_id
    s.evidence_runtime_owners.append((action,args,after))
    action_seal=function_owner_seal(action)
    token=s.policy(lambda:s.evidence.enter(kind,role,operation,args))
    try:
        value=action()
    except BaseException as error:
        s.evidence_runtime_owners.append(error)
        try:
            final_args=args if after is None else after()
            s.policy(lambda:s.evidence.leave(token,arguments=final_args,error=error))
            s.policy(lambda:need(function_owner_seal(action)==action_seal,'live action callable custody after fault'))
        except BaseException as secondary:
            s.evidence_runtime_owners.append(secondary)
            if s.first_fault is None:s.first_fault=secondary
        s.fault_gate()
        raise
    else:
        final_args=args if after is None else after()
        s.policy(lambda:s.evidence.leave(token,arguments=final_args,value=value))
        s.policy(lambda:need(function_owner_seal(action)==action_seal,'live action callable custody after return'))
        return value
    finally:
        s.evidence_scope=previous


def _profile_evidence(s,profile_id,origin,declared_arguments=None):
    # Source changes in the component route every invocation, including static,
    # inactive, swallowed and reentrant attempts, through this real callback.
    scope=_evidence_scope(s)
    scope.update(profile_id=profile_id,origin=origin)
    tokens=[]
    callback_owners=[scope,tokens,declared_arguments]
    s.evidence_runtime_owners.append(callback_owners)
    def hook(stage,state,request,value,error):
        # Keep complete original state/receipt/preimage/errors BEFORE copying or
        # checking. Exact runtime objects are not reconstructed by the codec.
        callback_owners.append((state,request,value,error))
        def action():
            work=state['work']
            scalars=dict(stage=state['stage'],failed_stage=state['failed_stage'],
                attempted_queries=state['attempted_queries'],
                produced_receipt_count=state['produced_receipt_count'],
                preimage_completed_count=state['preimage_completed_count'],
                delivered_receipt_count=state['delivered_receipt_count'],
                attempted_work=None if work is None else work.work,
                data_items=None if work is None else work.items)
            if stage in ('PROFILE_ENTER','QUERY_ENTER','CUSTODY_ENTER'):
                kind=stage[:-6]
                arguments=declared_arguments if kind=='PROFILE' else request if kind=='QUERY' else value
                token=s.evidence.enter(kind,'implicit',kind.lower(),arguments,scope)
                tokens.append((kind,token))
            elif stage in ('PROFILE_RETURN','PROFILE_RAISE','QUERY_RETURN','QUERY_RAISE','CUSTODY_RETURN','CUSTODY_RAISE'):
                kind=stage.rsplit('_',1)[0]
                need(tokens and tokens[-1][0]==kind,'exact live component occurrence nesting')
                token=tokens[-1][1]
                final_value=dict(result=value,lifetime=_ordinary_profile_lifetime(state)) if kind=='PROFILE' else value
                if kind=='QUERY' and error is not None:
                    final_value=dict(active_query=state['active_query'],counters=scalars)
                s.evidence.leave(token,arguments=request if kind=='QUERY' else None,value=final_value,error=error)
                tokens.pop()
            else:
                s.evidence.snapshot('PROFILE_STATE','implicit',stage,
                    dict(request=request,active_query=state['active_query'],version=value,
                         counters=scalars),scope)
            return None
        return s.policy(action)
    callback_owners.append(hook)
    if not hasattr(s,'evidence_callback_seals'):s.evidence_callback_seals=[]
    s.evidence_callback_seals.append((hook,function_owner_seal(hook)))
    return hook


def _linked_raw_bank_verifier(s,bank):
    # Full raw bytes are ordinary original inputs, never an archived partial.
    s.guard()
    pin=bank['pin']
    raw=checked(pin,134217728)
    need(type(bank['raw_hex'])is str and raw.hex()==bank['raw_hex'],'full raw bank bytes, not only pin')
    decoded=json.loads(raw)
    s.policy(lambda:need(argument_bytes(decoded)==argument_bytes(bank['decoded']),
                        'independent full raw parser and strict decoded bank join'))
    return None


def _linked_final_custody(s):
    final_profile_custody(s)
    for callback,seal in s.evidence_callback_seals:
        s.check()
        s.policy(lambda callback=callback,seal=seal:need(function_owner_seal(callback)==seal,
            'all live evidence callbacks/code/default/closure owners retained through final custody'))
    for role in ('linked','schema','codec','writer'):
        need(role in s.modules,'whole new dependency closure loaded and retained')
    s.guard()
    s.fault_gate()


def run_linked_candidate(s,inputs,batch_inputs,raw_banks,manifest,*,codec_limits,writer,
                         physical_limit,expanded_limit):
    """Full15/33+28/55 new candidate operation; historical main refuses.

    Caller is a fresh Root Source-bound outer harness. It establishes original
    absolute epochs/limits, consumes a fresh once grant BEFORE launching, loads
    all pinned Sources, creates one cooperative AggregateWriter before any bulk
    allocation, and owns result/header/observer/external-exit admission.
    This function does not adopt G1, grant itself an invocation or accept a proof.
    """
    need(s.evidence is None and not s.rows and not s.profile_rows and not s.batch_diagnostics,
         'fresh ordinary whole-cohort construction, no warm state')
    need(type(physical_limit)is int and 0<physical_limit<=134217728 and
         type(expanded_limit)is int and 0<expanded_limit<=134217728,
         'caller must reserve complete candidate within unchanged128MiB caps')
    need(manifest['outer_limits']==OUTER_LIMITS and manifest['component_limits']==COMPONENT_LIMITS and
         manifest['profile_limits']==PROFILE_LIMITS and manifest['profile_query_chunk']==128 and
         manifest['profile_granularity']==PROFILE_GRANULARITY,'all original limits and full scope')
    need(manifest['source_pins']==s.plan['sources'] and
         manifest['predecessor_worker_sha256']=='9ea014de87d5af2ed3017442f690699a0ef54750c8d8be12890e373936b65a03',
         'complete new closure plus exact historical provenance')
    need(type(raw_banks)is list and len(raw_banks)==2 and
         argument_bytes(raw_banks[0]['decoded'])==argument_bytes(inputs) and
         argument_bytes(raw_banks[1]['decoded'])==argument_bytes(batch_inputs),
         'both complete raw banks and strict actual argument bindings')
    def retain(owner):
        s.evidence_runtime_owners.append(owner)
        return None
    def scope():
        return _evidence_scope(s)
    linked=s.modules['linked'];schema=s.modules['schema'];codec=s.modules['codec']
    s.evidence=linked.EvidenceJournal(check=s.check,retain=retain,scope=scope)
    s.evidence_runtime_owners.extend((writer,retain,scope,manifest,raw_banks,codec_limits))
    for bank in raw_banks:_linked_raw_bank_verifier(s,bank)
    s.batch_original_inputs=inputs
    s.batch_original_inputs_preimage=argument_bytes(inputs)
    packet=qualify(s,inputs,batch_inputs)
    _linked_final_custody(s)
    events=s.evidence.finish()
    # Preserve the exact complete old packet, including all full progress views,
    # diagnostics, failed attempts and all old reconstruction-charge fields.
    envelope=linked.assemble(packet,manifest,raw_banks,events,check=s.check,retain=retain)
    def verify_bank(bank):
        return _linked_raw_bank_verifier(s,bank)
    expected=dict(packet=packet,manifest=manifest,raw_banks=raw_banks,events=events,verify_raw_bank=verify_bank)
    sealed=argument_bytes((packet,manifest,raw_banks,events))
    state=dict(envelope=envelope,expected=expected,receipt=None,position=0,wire=None,
               producer_calls=0,writer_result=None,error=None)
    s.evidence_runtime_owners.extend((state,verify_bank,sealed))
    def producer():
        # AggregateWriter claims whole leases BEFORE its first producer call.
        # Full encode/decode/schema validation occurs once within that claim.
        s.check()
        state['producer_calls']+=1
        if state['wire']is None:
            receipt=linked.encode_candidate(envelope,codec=codec,checker=schema,
                expected=expected,check=s.check,codec_limits=codec_limits,retain=retain)
            state['receipt']=receipt
            state['wire']=receipt['wire']
            s.policy(lambda:need(argument_bytes((packet,manifest,raw_banks,events))==sealed,
                'complete originals/versions/ordered events unchanged after encoding/independent decode'))
            _linked_final_custody(s)
        wire=state['wire'];position=state['position']
        if position==len(wire):return None
        stop=min(position+65536,len(wire))
        chunk=wire[position:stop]
        state['position']=stop
        # This is the EXPLICIT new G1 unique-owner charge. It is not oldG0's
        # full recursive unfolding. Writer does not infer or adopt that meaning.
        return (chunk,len(chunk))
    s.evidence_runtime_owners.append(producer)
    try:
        output=writer.write_record('canonical-linked-batch-evidence.gctsdag',producer,
            physical_limit=physical_limit,expanded_limit=expanded_limit,kind='bulk')
        state['writer_result']=output
        need(state['receipt']is not None and state['position']==len(state['wire']),
             'whole complete binary output; no partial admission')
        _linked_final_custody(s)
        s.check()
        candidate_metadata={key:value for key,value in state['receipt'].items() if key!='wire'}
        return dict(schema='linked-complete-batch-worker-candidate-v1',
            output=output,candidate_metadata=candidate_metadata,normal_cases=15,legacy_diagnostics=33,
            new_groups=28,new_variants=55,profile_metrics=profile_metrics(s),
            root_callbacks_at_return=s.root_calls,root_callbacks_in_packet_are_preencoding_cutoff=True,
            full_pipeline_qualified=False,G1_adopted=False,resource_accepted=False,
            runtime_qualified=False,mathematical_authority=False)
    except BaseException as error:
        state['error']=error
        s.evidence_runtime_owners.append(error)
        s.fault_gate()
        raise


def main(plan_path):
    raise PolicyFailure('Historical plans/grants retired; new linked G1 requires fresh Root outer integration, independent review and once grant.')


if __name__=='__main__':
    raise SystemExit(main(None))

