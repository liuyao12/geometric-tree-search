"""Independent Source-only linked register routine review; no component calls."""
import ast
import hashlib
import json
from pathlib import Path
N=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-linked-evidence-20261020')
R=N/'root';O=N/'review-C';C=O/'register-records-Sources-v1';C.mkdir(exist_ok=True)
checks=[];pins=[]
def need(n,v):
    checks.append({'check':n,'passed':bool(v)})
    if not v:raise ValueError(n)
def pin(p):
    b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
for name,size,digest in [
 ('runtime_register_records_v1.py',5357,'280d0a1acaa8111bcd6f8ac30291d805a313f7a9498e9a434bdbacbd19386a98'),
 ('runtime-register-records-API-v1.json',3495,'87d2fc6e6bb1c2f15ec5ca7e2228781cdc7b6e7372a35f8d45706c1181aecbcc')]:
    p=R/name;b=p.read_bytes();need('offered-pin:'+name,len(b)==size and hashlib.sha256(b).hexdigest()==digest)
    dest=C/name;need('fresh-copy:'+name,not dest.exists());dest.write_bytes(b);pins.append(pin(dest))
source=(C/'runtime_register_records_v1.py').read_bytes();t=ast.parse(source);compile(t,'runtime_register_records_v1.py','exec')
need('no-import-nodes',not any(isinstance(x,(ast.Import,ast.ImportFrom))for x in ast.walk(t)))
api=json.loads((C/'runtime-register-records-API-v1.json').read_bytes())
need('Builder-v2-exact',api['builder']['sha256']=='4d13b99f90e9658508dcd4a289ece2d93bd21d862e4153a431a91ce17d78da20')
specs={
 '_zero':'Allocate literalwrite0 thenclear_word; leavescanonicalCOUNT0 and countcursoratfirstbit. Four allocatedmicrostates including sharedclear3.',
 '_skip_field':'From registerfieldstart/currentbits, scanbits throughsemicolon andadvance to nextfield. Colon beforesemicolon choosesinvalid. On malformedemptyfield it can skip, so caller mustalreadyvalidate vector; not a global malformedinputvalidator.',
 '_clear_records':'Rewind, erase0/1/semicolon untilcolon orB, erasecolon andrewind. Supports blankBUFFER and validrecordvector; successful exit leavesblank payload, not an emptycolonrecord. No arbitrarysuffixsanitization beyondfirstB.',
 'register_read':'InitializeCOUNT0 andREGcursorfirstfield; compareCOUNTtoINDEX using fullbinarywords. Onmismatch skip exactlyonefield andincrementCOUNT; onmatch clearVALUE, requirefirstbit (colonabsentinvalid), copyallbits tosemicolon, rewindVALUE. Exact selectedref returned, allREGpayload andINDEXpreserved.',
 'register_write':'ClearBUFFER then searchCOUNT0 upward, copying entire unmatchedprefix fields. Onmatch skipoldfield then copyentire preservedVALUE andappendsemicolon, then exact untouchedsuffix tocolon. Only aftercompletebuffer produced eraseoldREGwholevector, commitfullbuffer andnewcolon, clearBUFFER, rewindREG. No atomicrollback onfailure.'}
funcs=[x for x in t.body if isinstance(x,ast.FunctionDef)]
need('all-five-functions',len(funcs)==5 and set(x.name for x in funcs)==set(specs))
need('all-four-unrun-families',len(api['prospective_unrun_families'])==4)
need('Source-only-no-VM-claim',api['full_VM'] is False and api['authority'] is False and api['subject_calls']==api['table_generations']==api['simulations']==0)

# Hand-counted allocation terms from the frozen Source and Builder Source.
# These additions count Source callsites only; no generator or sizer is called.
read_terms={'field_loop':1,'value_rewind':1,'two_bit_writers':2,'nonempty_row':1,
 'clear_value':3,'compare_entry':1,'increment_word':3,'skip_field':1,
 'compare_words':6,'register_rewind':1,'zero_count':4}
write_terms={'register_done_rewind':1,'clear_buffer_after':3,'commit_loop':1,
 'commit_end':1,'commit_writers':3,'buffer_rewind':1,'erase_old_vector':3,
 'suffix_loop':1,'close_buffer':1,'suffix_writers':3,'replacement_loop':1,
 'replacement_delimiter':1,'replacement_writers':2,'replacement_rewind':1,
 'skip_old':1,'compare_entry':1,'increment_word':3,'prefix_loop':1,
 'prefix_delimiter':1,'prefix_writers':2,'compare_words':6,
 'register_rewind':1,'zero_count':4,'clear_buffer_before':3}
need('manual-read24',sum(read_terms.values())==api['manual_allocations']['register_read_microstates']==24)
need('manual-write46',sum(write_terms.values())==api['manual_allocations']['register_write_microstates']==46)
recipes=[
 {'id':'absent-index-empty-and-end','recipe':'Emptyvector withINDEX0/1; lengthNvector withINDEXN/N+1 and verylongcanonicalINDEX. Matchatcolon still reachesnonemptycheckinvalid, nonmatchskipcoloninvalid. No inventedregister returned.','executed':False},
 {'id':'read-full-values-and-preservation','recipe':'Selectedrefs0,1,255,256,257 andlargeractualnodeID atfirst/middle/lastfield; compareallVALUEbits andentireINDEX/REGISTERS/allotherpreservedbandpayloads; headsallowedtomove.','executed':False},
 {'id':'write-grow-shrink-and-suffix','recipe':'Replace eachfield of length0..3validvectors withallwordlengthrelations, includingfirst/last; staleBUFFERlongerthannextbuffer; compareentirevector, onechangedfieldonly, allpreservedVALUE/INDEX/otherpayloads and blankBUFFERaftercompletion.','executed':False},
 {'id':'copy-commit-boundaries','recipe':'FenceeveryneededCOUNTcarry/BUFFERcopy/REGcommitwrite. Failurebeforecommit leavesoldREGpayload; failureduringcommit maydestroyoldvector andmustretainrawprefixwithoutadmission/repair.','executed':False},
 {'id':'valid-domain-versus-malformation','recipe':'Canonicalref/vector/INDEX preconditions are fullclientobligations. Emptyfields, noncanonicalhighzeros, earlyB or missingdelimiters maynotallberefusedhere; do not labelroutineageneralvalidator.','executed':False},
 {'id':'Root-firstfault-and-raw-prefix','recipe':'Retainexactbuilderrawowners/callbackexception and firstRootfault; completeprospectiveforeign/ownedcutoffcontrols beforeanyfutureactual; noresumedfailedconstruction.','executed':False}]
remaining=[
 'Fullprogram/registerinitialization andvalidrefchecking; no candidate may supply an unvalidated registervector or executablecontrol/address.',
 'BUFFER14is sharedPARSER_STACK. Its priorcontents are intentionallyclobbered; fullcall/frame/BOOTclient mustschedule lifetime andsaveanythingneeded. No aliasing withINDEX8/VALUE11/COUNT12/REG4 permitted.',
 'Builder fixedlayout and canonicalwordpadding, Source/function/closure/argument/callback custody and firstRootfault precedence remain required. Malformedlayoutchecks cannot be a hiddenhostproofgate.',
 'Everyopcode mustcaptureallsourceoperandsbeforewritingdestinations; these primitives alone do not establish instructionalias semantics or frame restoration.',
 'Full13opcodefetch/programparser/controller/rootACCEPT, public/Wangselector, noextraaccept refinement and whole-resourcefit remain absent. Fourunrunfamilies andSourcecount24/46 are not qualification.']
out={
 'schema':'typed-runtime-register-records-v1-Source-review-v1','reviewer_identity':'/root/recovered_batch_review',
 'status':'PASS_CONDITIONAL_COMPONENT_SOURCE_ONLY','review_passed':True,'source_only':True,
 'pins':pins,'shared_builder_review':pin(O/'typed-shared-builder-v2-Source-review-v1.json'),
 'full_Source_and_API_read':True,
 'function_matrix':[{'name':x.name,'line':x.lineno,'end':x.end_lineno,'argument':specs[x.name]}for x in funcs],
 'manual_control_argument':'InductonCOUNT forprefixsearch; every unselected field is copied/skipped exactlyonce. Atmatch, read copies the completeword orwrite replaces exactlyonecompletefield. Write preserves prefix/suffix by streaming into full BUFFER beforedestructivecommit. Canonical validatedvector andavailablecapacity are essential preconditions.',
 'manual_allocations':{'read_terms':read_terms,'read_total':24,'write_terms':write_terms,'write_total':46,
  'scope':'Allocatedmicrostate callsites excluding sharedhalts and suppliedcontinuationbodies; no actualmachine/table/census generated.'},
 'whole_four_family_bank_read':True,'all_recipes_unrun':True,'additional_unrun_recipes':recipes,
 'remaining_obligations':remaining,'manual_argument_not_mechanized':True,
 'runtime_qualified':False,'full_VM_qualified':False,'new_theorem':False,'GCTS_RL_advantage_established':False,
 'G1_adopted':False,'old_G0_negative_unchanged':True,'goal_status':'active',
 'AST_parse':True,'unused_compile':True,'subject_imports':0,'subject_calls':0,'helper_calls':0,
 'compiler_calls':0,'fixture_calls':0,'simulator_calls':0,'table_generation_calls':0,'sizing_probes':0,
 'semantic_replays':0,'partial_files_opened':0,'new_actuals':0,'new_grants':0,'actual_execution_authorized':False,
 'checks':checks,'failed_checks':[],'author':pin(Path(__file__)),'frozen_files_mutated':False,
 'primary_reader_index_active_mutated':False,'tools_stopped_after_freeze':True}
p=O/'typed-runtime-register-records-v1-Source-review-v1.json';need('fresh-review',not p.exists())
p.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n');print(json.dumps({'review':pin(p),'checks':len(checks)},sort_keys=True))
