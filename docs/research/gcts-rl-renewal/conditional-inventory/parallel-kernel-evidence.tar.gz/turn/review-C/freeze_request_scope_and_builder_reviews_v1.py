"""Separate Source-only delta and microassembler reviews; no research imports."""
import ast
import hashlib
import json
from pathlib import Path

N=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-linked-evidence-20261020')
R=N/'root';O=N/'review-C';C=O/'request-builder-Sources-v1'
C.mkdir(exist_ok=True)
checks=[]
def need(name,ok):
    checks.append({'check':name,'passed':bool(ok)})
    if not ok:raise ValueError(name)
def pin(p):
    b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def copy(n,digest,size):
    p=R/n;b=p.read_bytes();need('pin:'+n,len(b)==size and hashlib.sha256(b).hexdigest()==digest)
    dest=C/n;need('fresh-copy:'+n,not dest.exists());dest.write_bytes(b);return pin(dest)
def freeze(n,data):
    p=O/n;need('fresh:'+n,not p.exists());p.write_text(json.dumps(data,indent=2,sort_keys=True)+'\n');return pin(p)
def inv(t,prefix=''):
    out=[]
    for x in ast.iter_child_nodes(t):
        if isinstance(x,(ast.FunctionDef,ast.ClassDef)):
            name=prefix+x.name
            if isinstance(x,ast.FunctionDef):out.append({'name':name,'line':x.lineno,'end':x.end_lineno})
            out.extend(inv(x,name+'.'))
        else:out.extend(inv(x,prefix))
    return out

kernel=copy('serialized_kernel_request_scope_v2.py','bb291445dbf02669d025fa6f3723b4ceea2ba96613e1d1bad4bfef82cbf02839',14241)
# Root metadata itself is passively pinned below; Source exact identity is above.
meta=(R/'kernel-request-scope-Source-v2.json').read_bytes()
need('kernel:metadata-pin',len(meta)==1230 and hashlib.sha256(meta).hexdigest()=='d2c7f9847b42c8d9b1e2496086c5745129981d7ab9c9c78dbc15b5becbdf4790')
dest=C/'kernel-request-scope-Source-v2.json';need('fresh-kernel-metadata',not dest.exists());dest.write_bytes(meta);kernel_meta=pin(dest)
old=(O/'Sources/serialized_kernel.py').read_bytes();new=(C/'serialized_kernel_request_scope_v2.py').read_bytes()
a=b'        self.blocks = {}\n';b=a+b'        self._request_started = False\n'
c=b'    def request(self, request):\n';d=c+b"        # A theorem inventory belongs to exactly one theory/request context.\n        if self._request_started:\n            raise Invalid('one request per checker; create a fresh instance')\n        self._request_started = True\n"
need('kernel:only-exact-two-insertions',old.count(a)==1 and old.count(c)==1 and old.replace(a,b,1).replace(c,d,1)==new)
kt=ast.parse(new);compile(kt,'request_scope_v2','exec')
need('kernel:same26-functions',len(inv(kt))==26)
request=next(n for n in ast.walk(kt) if isinstance(n,ast.FunctionDef) and n.name=='request')
need('kernel:latch-first-before-validation',isinstance(request.body[0],ast.If)
     and ast.unparse(request.body[0].test)=='self._request_started'
     and ast.unparse(request.body[1])=='self._request_started = True'
     and ast.unparse(request.body[2]).startswith('self.fields('))
kernel_checks=list(checks)
kernel_recipes=[
 {'id':'accepted-first-then-foreign-theory','recipe':'Use the two full literal requests in auditF1 with the same v2Checker. First accepts relative to oldbotaxiom; second raises Invalid before new theory validation or block lookup.','executed':False},
 {'id':'same-request-twice','recipe':'Even identical secondrequest is refused; inventories do not carry implicitly.','executed':False},
 {'id':'failed-first-fields','recipe':'First malformed rootfields attempt consumes latch; corrected secondrequest still refused.','executed':False},
 {'id':'failed-first-rule','recipe':'First has a valid earlierblock but laterproof fails; laterrequest cannot reuse retained partialregistry.','executed':False},
 {'id':'failed-first-resource','recipe':'First raises work Resource during request tick; secondattempt Invalid before tick.','executed':False},
 {'id':'fresh-public-check','recipe':'Two separate public check(payload) calls each construct a new Checker and keep first-call control flow of old public entrypoint.','executed':False},
 {'id':'complete-old-rule-bank','recipe':'Every11rule branch, full type/quantifier/equality/induction/block bank remains required; delta does not shrink checker. No runtime regression claim here.','executed':False}]
kout=freeze('typed-kernel-one-request-Source-delta-review-v1.json',{
 'schema':'typed-kernel-one-request-Source-delta-review-v1','reviewer_identity':'/root/recovered_batch_review',
 'status':'PASS_SOURCE_DELTA_ONLY','source_only':True,'review_passed':True,'source':kernel,'metadata':kernel_meta,
 'original':pin(O/'Sources/serialized_kernel.py'),
 'original_audit':pin(O/'independent-full-common-kernel-Source-audit-v1.json'),
 'argument':'Exactly two insertions add one-shot guard. New instance begins false; first request sets true before any validation/work. Every later request refuses before consulting or replacing theory. This closes the stale-block request-reuse recipe under ordinary API use. Public check is fresh already; first-call semantic body is byte-identical.',
 'preconditions':['Ordinary trusted API calls, no direct attribute tampering/reset or hostile introspection.','Low-level proof/term methods are not newly certified independently of an initialized bound context.'],
 'scope_remaining':'Original F2-F8 byte/string/boundary/license/status/full-physical obligations remain. This does not certify all-input/status host/tree correspondence, any native parser change, or a full VM.',
 'prospective_recipes':kernel_recipes,'all_recipes_unrun':True,'runtime_qualified':False,
 'checks':kernel_checks,'failed_checks':[],'AST_parse':True,'unused_compile':True,
 'subject_imports':0,'subject_calls':0,'checker_calls':0,'fixture_calls':0,'simulator_calls':0,
 'semantic_replays':0,'sizing_probes':0,'new_actuals':0,'new_grants':0,'actual_execution_authorized':False,
 'frozen_original_mutated':False,'author':pin(Path(__file__))})

builder=copy('literal_machine_builder_v2.py','4d13b99f90e9658508dcd4a289ece2d93bd21d862e4153a431a91ce17d78da20',13782)
abi=copy('shared-builder-ABI-v2.json','42f113591d92c4dd3098d7f5a6d83ce7434b5f4f146ff52cd4c925f283370040',4319)
manual=copy('shared-builder-manual-v2.json','3910b9719859ab6312e25696fae02657b4b8b1b6821ea4d95c6bb52b176dbb2a',2597)
bank=copy('shared-builder-prospective-bank-v2.json','64079cee3e712001d1a56d05557847a348b5fe8034ae06493e30f3fc7d14de85',2806)
for n in ('literal_machine_builder_v1.py','literal-builder-static-negative-v1.json'):
    raw=(R/n).read_bytes();p=C/n;need('fresh-predecessor:'+n,not p.exists());p.write_bytes(raw)
v1=(C/'literal_machine_builder_v1.py').read_bytes();v2=(C/'literal_machine_builder_v2.py').read_bytes()
repls=[(b"VERSION='shared-sixteen-band-literal-builder-v1'",b"VERSION='shared-sixteen-band-literal-builder-v2'"),
 (b'def __init__(self,reason):self.owner=_OWNER;',b'def __init__(self,reason,*,owner=None):self.owner=owner;'),
 (b'raise DeclarationError(reason)',b'raise DeclarationError(reason,owner=_OWNER)'),
 (b"raise ConstructionLimit('work')",b"raise ConstructionLimit('work',owner=_OWNER)"),
 (b'raise ConstructionLimit(kind)',b'raise ConstructionLimit(kind,owner=_OWNER)')]
rebuilt=v1
for before,after in repls:rebuilt=rebuilt.replace(before,after)
need('builder:v1-v2-only-owner-fix-and-version',rebuilt==v2)
bt=ast.parse(v2);compile(bt,'builder_v2','exec')
constants={}
for node in bt.body:
    if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name):
        try:constants[node.targets[0].id]=ast.literal_eval(node.value)
        except ValueError:pass
need('builder:fixed16bands-and4halts',len(constants['WORKSPACE'])==16 and len(set(constants['WORKSPACE']))==16
     and constants['HALTS']==('ACCEPT','REJECT','BOUND','MALFORMED'))
need('builder:38-symbols-by-literal-count',len(constants['RAW'])==10 and 2+2*len(constants['RAW'])+len(constants['WORKSPACE'])==38)
need('builder:bank-seven-full-families-unrun',len(json.loads((C/'shared-builder-prospective-bank-v2.json').read_bytes())['families'])==7)

specs={
 'DeclarationError.__init__':'Default ownerNone makes a public callback-constructed ordinary instance foreign. Explicit private owner is convention only, not a hostile introspection security boundary.',
 'ConstructionLimit.__init__':'Same owner distinction for limits; original public auto-owner bug preserved in v1 negative.',
 'is_owned_declaration':'Exact class plus private token identity; foreign error identity and Root firstfault must be checked before classification.',
 'is_owned_limit':'Exact class plus token; not a generic isinstance test. Caller must not infer Resource authority from type alone.',
 'require':'All actual Sourceowned declaration failures explicitly pass token.',
 'Builder.__init__':'Raw owners/containers installed before guarded validation; exact six-key positive bounded-int limits copied; explicit callback; halt allocation starts at IDs0..3.',
 'Builder._attach':'Best-effort raw partial prefix, preserving exception identity via bare raise in callers; raw lists/sets remain owned, not automatically literal or immutable JSON evidence.',
 'Builder._step':'Counts before callback and owned limit checks, exactforeign exceptions bare-raised. FirstRootfault precedence requires future outer latch before classifying local-limit exceptions.',
 'Builder.state':'Appends raw state/name and rowplaceholder before quota callback. Names unique and bounded; all working placeholders must later close.',
 'Builder.put':'Exact workingstate/band/dict/action types, nofence reads/writes, unitmoves, unchanged uncrossed^ and immutable0..2writes; raw producedchoice retained beforecallback. Full missingrawread MALFORMED completion after validation.',
 'Builder.row':'Allocation then put; partial failure leaves raw placeholder retained, never a complete table.',
 'Builder.rewind':'Leftscan finite valid band until^ then moveone right; noleftcross; invariant assumes unique leftdelimiter and reachable finite cursor.',
 'Builder.clear_word':'Rewind, erase finite0/1word to firstB, rewind. Binary scratchword domain and blank padding are caller invariants; it is not arbitrary RAW payload sanitizer.',
 'Builder.copy_word':'Distinct bands; clear destination, rewind source, read eachbit carry in finite Source state, write intoB, sourcehead endsB and destinationhead rewound. Destination must mutable and capacity sufficient else declaration/BOUND.',
 'Builder.compare_words':'Distinct band word heads rewound; compare fullbits and commonB terminator; yes/no preserve raw words but heads may remain inside. Does not certify arbitrary noncanonical words.',
 'Builder.increment_word':'Nonempty canonicalLSB input; carry1->0, first0/B->1 then rewind. Allones extends onecell. Fence yieldsBOUND. Invalid/noncanonical input not promised rejected.',
 'Builder.decode_U':'Distinct source/count/output; source starts currentcursor; clears scratchcount/output. Count unaryprefix1s then0, consume exactlycount bits; lastbit must1 for positive; prefix0 outputsbinary0. Continuation source remains afterencodedU; output rewound. Count andoutput mutable/capacity invariants.',
 'Builder.lower':'Full microclosure, alphabet and physicalphases; all live38readslots assigned, halts allundefined; fixed layout is an external initialization obligation. Completeclient and rootreturn1-onlyACCEPT invariant absent.',
 'Builder.lower.entry':'Halts mapdirect IDs0..3; workingmicrocontinuations mapto selectphase. No data-dependent runtime address.',
 'Builder.lower.put':'Raw physical5-field row appended and active before callback; then slotuniqueness recorded. A cutoff at this callback may have produced row not yet reflected in slots; retain both honestly.'}
funcs=inv(bt);need('builder:every-authored-function-reviewed',set(x['name'] for x in funcs)==set(specs))
matrix=[{**x,'manual_argument':specs[x['name']],'status':'SOURCE_ONLY_CONDITIONAL','executed':False}for x in funcs]
phase_argument={
 'precondition':'UniqueL then16 ordered h:WORKSPACE headers, each^payload# with exactlyone@raw cursor, thenuniqueR; payload has onlyRAW and no forgedheader/sentinel; microboundary physicalhead is at current bandcursor.',
 'select':'Seekleft toL preserving every symbol; R givesMALFORMED. Under validlayout it reachesL in finite time.',
 'header':'Seekright to exactfixed bandheader; L/R beforeit givesMALFORMED. Data cannot supply a header under validlayout.',
 'find':'Seek within selectedband toitsone@raw cursor; rawnonfence passes; raw# orheader/wrongsentinel givesMALFORMED. @# goesREAD thenBOUND.',
 'read':'Apply exactly one Source literal action. Stationarymove writes@write and enters mapped continuation/halt. Unitmove removes oldmarker, movesone physicalcell thenMARK.',
 'mark':'Neighbor rawinsideband becomes@raw thenmappedcontinuation; #givesBOUND; headers/markers/L/R giveMALFORMED. Thus logicalbandcursor movement is simulated, with extra physicalseeksteps.',
 'invariants':'Immutable0..2underlyingrawpayload unchanged; ^neverforged/written/leftcrossed; no#construction; exactlyonecursor persists on successful nonhalt boundary. A BOUND partial may lack a restored cursor and is not admitted.',
 'scope':'Conditional microstep stuttering argument only; not a proof that every arbitrary layout is refused or that any declared clientACCEPT is justified by the FOL checker.'}
obligations=[
 {'id':'B1','remaining':'Exact initialization tiles enforce layout and immutable program/public/certificate/full unknowncertificate selector. Valid-layout hostpredicate cannot silently replace t/m initialization.'},
 {'id':'B2','remaining':'FullSourcefixed client handles all69 checker functions via all13VMopcodes, BOOT semantic taggedvalues/keyuniqueness/text/publicbinding, heap/register/frame/controller. Only justified rootreturn1 maytargetACCEPT.'},
 {'id':'B3','remaining':'Future Root harness checks Source/function/default/closure/argument/Builder/rawcallback/error custody at entry, everycallback andexit; exact firstRootfault dominates localownedlimit and foreignclassification.'},
 {'id':'B4','remaining':'Failures are terminal to that construction lifetime or snapshots frozen before any resumed mutation. Builder itself has no fail-stop latch; rawprefix references can change if caller improperly resumes/reuses Builder. No such lifetime claim is certified here.'},
 {'id':'B5','remaining':'Complete ordinary projection for rawsets/aliases/callbacks/tracebacks plus fullmanifest and allnormal/diagnostic counts; a prefix name/hash is not complete proof or evidence. Stateaccounting can lead slotindex at a failedcallback honestly.'},
 {'id':'B6','remaining':'Manual clientM and complete output/work/time/heap envelopes before prospective onceoffer. Q=5M-12 does not establish size/fit or uniform practical speed; fullclientM remainsnull.'},
 {'id':'B7','remaining':'Run whole seven-family bank only after exact Source/prospective review and fresh Rootgrant; no generation/census/simulation is authorized by this review.'}]
extended_recipes=[
 {'id':'first-root-fault-before-local-quota','recipe':'Latch genuine Rootfault, then encounter local _step quota; future wrapper must preserve original Rootexception even though inner quota check precedes callback.','executed':False},
 {'id':'raw-row-before-slot-record','recipe':'Raise exactforeign sentinel at first physical-row callback; rawdelta includes producedrow and active while slots omits it. Project both whole values rather than force equality or trim.','executed':False},
 {'id':'failure-lifetime-no-resume','recipe':'After constructionerror, retain raw Builder/rows/check/limits/error traceback; a proposed retry on sameinstance must not mutate previously frozen evidence or bypass original oncegate.','executed':False},
 {'id':'public-owner-impostors','recipe':'Fresh public DeclarationError/ConstructionLimit with omitted owner remain foreign; callbacks throwing them must be retained exactidentity, not treated as owned quotas.','executed':False},
 {'id':'invalid-word-precondition','recipe':'Noncanonical highzero and garbageafterfirstB are outside canonical binaryhelper theorem; do not falsely require every helper to be an arbitrary-payload validator. Full BOOT mustvalidate before use.','executed':False}]
bout=freeze('typed-shared-builder-v2-Source-review-v1.json',{
 'schema':'typed-shared-builder-v2-Source-review-v1','reviewer_identity':'/root/recovered_batch_review',
 'status':'PASS_CONDITIONAL_COMPONENT_SOURCE_ONLY','review_passed':True,'source_only':True,
 'source':builder,'ABI':abi,'manual':manual,'prospective_bank':bank,
 'predecessor_source':pin(C/'literal_machine_builder_v1.py'),
 'predecessor_negative':pin(C/'literal-builder-static-negative-v1.json'),
 'all_functions':matrix,'phase_case_argument':phase_argument,
 'manual_census':{'formula_only':True,'microstates_symbol':'M','physical_states_latex':r'\(Q=5M-12\)',
     'alphabet':38,'assigned_rows_latex':r'\(D=38(Q-4)\)','undefined_halt_slots':152,
     'argument':'Fourmicrohalts +4phases for eachM-4workingmicrostates +Mmarkerstates =5M-12. Each physicalnonhalt state has every38reads assigned;4physicalhalts have none. Alphabet2global+10raw+10marked+16headers=38.',
     'actual_M':None,'generated':False,'full_client_fit_proved':False},
 'remaining_obligations':obligations,'additional_unrun_recipes':extended_recipes,
 'whole_offered_bank_read':True,'all_seven_families_unrun':True,
 'limits':'Original400m/180/210/1GiB/128MiBstored-expanded-physical/9MiBreserve/4MiBlogs unchanged. No fulloutput fit claim.',
 'manual_argument_not_mechanized':True,'AST_parse':True,'unused_compile':True,
 'full_VM_qualified':False,'BOOT_qualified':False,'runtime_qualified':False,
 'proof_checker_qualified':False,'new_theorem':False,'GCTS_RL_advantage_established':False,
 'G1_adopted':False,'old_G0_negative_unchanged':True,'goal_status':'active',
 'subject_imports':0,'subject_calls':0,'helper_calls':0,'compiler_calls':0,'fixture_calls':0,
 'simulator_calls':0,'table_generation_calls':0,'sizing_probes':0,'semantic_replays':0,
 'partial_files_opened':0,'actual_execution_authorized':False,'new_actuals':0,'new_grants':0,
 'checks':checks[len(kernel_checks):],'failed_checks':[], 'author':pin(Path(__file__)),
 'frozen_files_mutated':False,'primary_reader_index_active_mutated':False,'tools_stopped_after_freeze':True})
print(json.dumps({'kernel_review':kout,'builder_review':bout,'builder_functions':len(matrix),'checks':len(checks)},sort_keys=True))
