"""Source-only linked physical caller-frame save/restore; no VM executor.

Each frame retains the complete caller register vector, function, next PC and
destination. Runtime frame values are tape words, never finite-control names.
Exact well-formed-vector and Source-owned-layout preconditions are explicit.
"""
VERSION='linked-physical-call-frames-v1'
REGISTERS=4
FRAMES=5
FUNCTION=6
PC=7
DESTINATION=8

def _clear_vector(m,out,name):
    q=m.state(name+'/erase');done=m.rewind(REGISTERS,out,name+'/done')
    choices={s:(q,'B',1)for s in('0','1',';')}
    choices.update({':':(done,'B',0),'B':(done,'B',0)})
    m.put(q,REGISTERS,choices)
    return m.rewind(REGISTERS,q,name+'/begin')

def _append_word(m,source,delimiter,out,name):
    q=m.state(name+'/read')
    end=m.row(FRAMES,{'B':(out,delimiter,1)},name+'/delimiter')
    choices={'B':(end,'B',0)}
    for bit in('0','1'):
        write=m.row(FRAMES,{'B':(q,bit,1)},name+'/write-'+bit)
        choices[bit]=(write,bit,1)
    m.put(q,source,choices)
    return m.rewind(source,q,name+'/rewind')

def frame_push(m,out,invalid,name):
    """Append fn,pc,dst|ref;...! to FRAMES, restoring its used-end colon.

    FUNCTION/PC/DESTINATION are canonical nonempty binary words. PC already
    names the return instruction. REGISTERS is a whole valid vector. FRAMES
    is ^frame* : B...#. All source payloads, including the free argument cache,
    are preserved. Only FRAMES changes; logical head positions may change.
    """
    close=m.row(FRAMES,{'B':(out,':',0)},name+'/close')
    end=m.row(FRAMES,{'B':(close,'!',1)},name+'/frame-end')
    vector=m.state(name+'/vector-read')
    choices={':':(end,':',0)}
    for symbol in('0','1',';'):
        write=m.row(FRAMES,{'B':(vector,symbol,1)},name+'/vector-write-'+symbol)
        choices[symbol]=(write,symbol,1)
    m.put(vector,REGISTERS,choices)
    vector_start=m.rewind(REGISTERS,vector,name+'/vector-start')
    destination=_append_word(m,DESTINATION,'|',vector_start,name+'/destination')
    pc=_append_word(m,PC,',',destination,name+'/pc')
    function=_append_word(m,FUNCTION,',',pc,name+'/function')
    scan=m.state(name+'/used-end')
    choices={s:(scan,s,1)for s in('0','1',',','|',';','!')}
    choices.update({':':(function,'B',0),'B':(invalid,'B',0)})
    m.put(scan,FRAMES,choices)
    return m.rewind(FRAMES,scan,name+'/begin')

def _pop_field(m,destination,delimiter,out,invalid,name):
    q=m.state(name+'/read');done=m.rewind(destination,out,name+'/done')
    choices={delimiter:(done,'B',1)}
    for bit in('0','1'):
        write=m.row(destination,{'B':(q,bit,1)},name+'/write-'+bit)
        choices[bit]=(write,'B',1)
    m.put(q,FRAMES,choices)
    # Nonempty words are a frame invariant; malformed starts take invalid.
    first=m.row(FRAMES,{'0':(q,'0',0),'1':(q,'1',0),delimiter:(invalid,delimiter,0)},name+'/first')
    return m.clear_word(destination,first,name+'/clear')

def frame_pop(m,out,empty,invalid,name):
    """Restore latest full caller frame or take empty without accepting.

    FRAMES alone determines caller presence. The callee return VALUE11 is
    untouched. Successful pop restores R4/F6/PC7/D8, removes exactly the last
    frame and reinstates its prefix's colon. No recursion-depth bound is baked
    into Source. Missing finite tape room is BOUND in the common lowerer.
    """
    done=m.rewind(REGISTERS,out,name+'/done-registers')
    replace=m.row(FRAMES,{'B':(done,':',0)},name+'/prefix-colon')
    back=m.state(name+'/trim-back')
    m.put(back,FRAMES,{'B':(back,'B',-1),'!':(replace,'!',1),'^':(replace,'^',1)})
    erase_old_colon=m.row(FRAMES,{':':(back,'B',-1)},name+'/erase-old-colon')
    close_registers=m.row(REGISTERS,{'B':(erase_old_colon,':',0)},name+'/register-colon')
    vector=m.state(name+'/vector-read')
    choices={'!':(close_registers,'B',1)}
    for symbol in('0','1',';'):
        write=m.row(REGISTERS,{'B':(vector,symbol,1)},name+'/vector-write-'+symbol)
        choices[symbol]=(write,'B',1)
    m.put(vector,FRAMES,choices)
    destination=_pop_field(m,DESTINATION,'|',vector,invalid,name+'/destination')
    pc=_pop_field(m,PC,',',destination,invalid,name+'/pc')
    function=_pop_field(m,FUNCTION,',',pc,invalid,name+'/function')
    begin_restore=_clear_vector(m,function,name+'/erase-callee-vector')
    find_start=m.state(name+'/last-frame-start')
    choices={s:(find_start,s,-1)for s in('0','1',',','|',';')}
    choices.update({'!':(begin_restore,'!',1),'^':(begin_restore,'^',1)})
    m.put(find_start,FRAMES,choices)
    last=m.row(FRAMES,{'!':(find_start,'!',-1),'^':(empty,'^',0),':':(invalid,':',0),'B':(invalid,'B',0)},name+'/last')
    scan=m.state(name+'/used-end')
    choices={s:(scan,s,1)for s in('0','1',',','|',';','!')}
    choices.update({':':(last,':',-1),'B':(invalid,'B',0)})
    m.put(scan,FRAMES,choices)
    return m.rewind(FRAMES,scan,name+'/begin')
