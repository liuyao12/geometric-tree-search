"""Literal Source inverse and metadata review only; no validator invocation."""
import ast
import hashlib
import json
from pathlib import Path

N=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-linked-evidence-20261020')
O=N/'review-C';B=N/'schema-B/snapshot-v2';C=O/'snapshot-schema-Sources-v2'
C.mkdir(exist_ok=True)
checks=[]
def need(name,value):
    checks.append(dict(check=name,passed=bool(value)))
    if not value:raise ValueError(name)
def pin(p):
    raw=p.read_bytes()
    return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
hraw=(B/'handoff-v2.json').read_bytes()
need('Exact frozen handoff',len(hraw)==1639 and hashlib.sha256(hraw).hexdigest()=='ec230e3c8b981892f492550a45b381662c116ec2fbda93db857863598468ce3f')
h=json.loads(hraw)
pins=[]
for row in h['artifacts']:
    p=Path(row['path']);need('Exact pin: '+p.name,pin(p)==row)
    q=C/p.name;need('Fresh copy: '+p.name,not q.exists());q.write_bytes(p.read_bytes());pins.append(pin(q))
(C/'handoff-v2.json').write_bytes(hraw)
old=N/'schema-B/validate_linked_evidence_v1.py'
need('Frozen predecessor unchanged',pin(old)['sha256']=='b87dd325e260a0ef57f914f9b3da00519a26bd8bcff0c1e3a4c4e7c96254a95d' and pin(old)['bytes']==33471)
text=old.read_text();new=(C/'validate_linked_evidence_v2.py').read_text()
before="{'schema','reason','mode','descriptor','points','chosen','marks',"
after="{'schema','reason','mode','palette_descriptor','points','chosen','marks',"
need('Unique snapshot occurrence',text.count(before)==1 and new.count(after)==1)
need('Exact two-change Source inverse',text.replace(before,after,1).replace(
    "VERSION = 'linked-complete-batch-validator-v1'",
    "VERSION = 'linked-complete-batch-validator-v2-palette-descriptor'",1)==new)
tree=ast.parse(new);compile(tree,str(C/'validate_linked_evidence_v2.py'),'exec')
manual=json.loads((C/'manual-delta-v2.json').read_bytes())
bank=json.loads((C/'unrun-schema-recipes-v2.json').read_bytes())
need('Five complete declarative recipes',bank['all_unrun'] is True and len(bank['recipes'])==5
     and [r['id'] for r in bank['recipes']]==['whole-original-shape','wrong-predecessor-alias','both-names','missing-name','wrong-value'])
need('Exact fourteen original field names',set(manual['schema_keys'])=={
    'schema','reason','mode','palette_descriptor','points','chosen','marks','domains','exclusions',
    'dependencies','branch_stack','scheduler','rollback_parent','work'} and len(manual['schema_keys'])==14)
graph=Path(manual['graph']['path']);need('Original graph unchanged',pin(graph)==manual['graph'])
oldcopy=C/'validate_linked_evidence_v1.py';oldcopy.write_bytes(old.read_bytes())
graphcopy=C/'implicit_wang_point_search_v1.py';graphcopy.write_bytes(graph.read_bytes())
need('Full expected packet equality preserved',"_equal(envelope['canonical_packet'],expected['packet'],check)" in new)
need('Exact field set still used',"type(snap) is dict and set(snap)==" in new)
out=dict(schema='typed-linked-snapshot-schema-v2-Source-delta-review-v1',
    reviewer_identity='/root/recovered_batch_review',status='PASS_SPECIFIC_SOURCE_DELTA_ONLY',
    review_passed=True,source_only=True,handoff=pin(C/'handoff-v2.json'),pins=pins,
    retained_negative=pin(O/'typed-linked-parent-snapshot-schema-negative-v1.json'),
    predecessor=pin(oldcopy),original_graph=pin(graphcopy),
    manual_findings=[
        dict(id='Exact correction',argument='Only the VERSION label and required snapshot field descriptor to palette_descriptor change. Full raw inverse matches the frozen predecessor exactly. No original graph or packet field is renamed, omitted or rewritten.'),
        dict(id='Original producer shape',argument='Graph._core_plain emits points, chosen, marks, domains and exclusions; _observe adds schema, reason, mode, palette_descriptor, dependencies, branch_stack, scheduler, rollback_parent and work. The successor exact fourteen-key set matches these complete original fields.'),
        dict(id='Mutation controls',argument='The five unrun recipes retain the complete original shape and test wrong predecessor alias, both names, missing name and changed nested descriptor. Shape candidate is not whole admission; changed nested value/type/order remains subject to complete strict expected-packet equality.'),
        dict(id='No narrowing',argument='The exact key set continues to reject omissions and extras. Full packet comparison, catalog/event joins and all other validator code are unchanged by this delta. This review does not newly certify all unchanged code.'),
        dict(id='Independent remaining obstruction',argument='The named-custody correction is a separate reviewed successor. The copying-journal conditional callback lower bound remains; neither this correction nor custody v2 removes it. Outer controller, useful fit, full offer review, G1 adoption and runtime qualification remain open.')],
    static_metadata=dict(AST_parse=True,unused_compile=True,executed=False),
    all5_recipes_unrun=True,full_offer_review_completed=False,
    checks=checks,failed_checks=[],author=pin(Path(__file__)),
    related_reviews=[pin(O/'typed-linked-named-custody-v2-Source-delta-review-v1.json'),
        pin(O/'typed-primary-copying-journal-work-bound-Source-review-v1.json')],
    subject_imports=0,subject_calls=0,helper_calls=0,checker_calls=0,compiler_calls=0,
    fixture_calls=0,simulator_calls=0,generator_calls=0,sizing_probes=0,semantic_replays=0,
    partial_files_opened=0,new_actuals=0,new_grants=0,actual_execution_authorized=False,
    G1_adopted=False,old_G0_negative_unchanged=True,runtime_qualified=False,fit_proved=False,
    full_VM_qualified=False,new_theorem=False,GCTS_RL_advantage_established=False,goal_status='active',
    frozen_offered_files_mutated=False,primary_reader_index_active_mutated=False,
    tools_stopped_after_freeze=True)
p=O/'typed-linked-snapshot-schema-v2-Source-delta-review-v1.json'
need('Fresh review',not p.exists());p.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(review=pin(p),checks=len(checks)),sort_keys=True))
