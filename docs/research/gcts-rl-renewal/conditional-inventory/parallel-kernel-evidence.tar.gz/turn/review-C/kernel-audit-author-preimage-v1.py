"""Author a Source-only manual correspondence audit; never import research code."""
import ast
import hashlib
import json
from pathlib import Path

O = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-linked-evidence-20261020/review-C')
S = O/'Sources'
checks=[]

def need(name, condition):
    checks.append({'check':name,'passed':bool(condition)})
    if not condition: raise ValueError(name)

def pin(p):
    b=p.read_bytes()
    return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}

def freeze(name,value):
    p=O/name
    need('fresh:'+name,not p.exists())
    p.write_text(json.dumps(value,indent=2,sort_keys=True,ensure_ascii=True)+'\n')
    return pin(p)

expected={
 'serialized_kernel.py':('045cdba67ead9f12e91c702736fa09a5ae4d9796aea86831d65b245031a261f4',13977),
 'fol_checker.tree':('8c86a24231d9c7d1777d7998b747a8cfd07087c168da64db6c5dff0820c802ed',17577),
 'boundary_syntax.tree':('b19efd9bb2b599c1eefb7a62b5b92257483c809e63a81431f683064acd60c25c',1739),
 'proof_boundary.py':('36824e8d3b3968b1368f5f55f6cecb58b48ba5b58084fcb32f387d361c21d92f',6992),
 'tree_machine.py':('8bede1b069975ba5b911f8d27d64e550b75cf81b779aae38ad6c0bf8371d2257',13290),
 'combined_source.tree':('8b3b0af5a4f36a6eb01c8ad080b420bb014af84f647e8e95d0f61832edbb4623',19325),
 'fixed-interpreter-encoding-contract-v1.json':('356d2160f3a038260053b3973945e1aa1deb2cbd1bfc0a9d417337e45b36c539',22116),
 'basic-tiling-algorithm.md':('ca6ee206287bf18b69f88a35d30968312499567755f347a819af4cf49743e7d4',36240)}
for n,(h,z) in expected.items():
    p=pin(S/n);need('source-pin:'+n,p['sha256']==h and p['bytes']==z)

def inventory(tree,prefix=''):
    out=[]
    for x in ast.iter_child_nodes(tree):
        if isinstance(x,(ast.ClassDef,ast.FunctionDef)):
            name=prefix+x.name
            if isinstance(x,ast.FunctionDef):
                out.append({'name':name,'line':x.lineno,'end':x.end_lineno,
                            'positional_arity':len(x.args.args)})
            out.extend(inventory(x,name+'.'))
        else: out.extend(inventory(x,prefix))
    return out

trees={};static=[]
for n in ('serialized_kernel.py','fol_checker.tree','boundary_syntax.tree','proof_boundary.py','tree_machine.py','combined_source.tree'):
    raw=(S/n).read_bytes();t=ast.parse(raw,filename=n);compile(t,n,'exec')
    trees[n]=t
    static.append({'source':pin(S/n),'AST_parse':True,'unused_compile':True,
                   'function_inventory':inventory(t),'code_executed':False})
wire=(S/'boundary_syntax.tree').read_bytes();fol=(S/'fol_checker.tree').read_bytes()
need('combined:literal-full-wrapper-plus-one-main-rename',
     wire+fol.replace(b'def main(request):',b'def semantic_main(request):',1)==(S/'combined_source.tree').read_bytes())
need('combined:all69-functions',len(inventory(trees['combined_source.tree']))==69)

# Each authored function is covered individually below. Group descriptions are
# reused only where functions have the same structural invariant, never to drop
# a branch of the checker.
tree_specs={}
def group(names,relation,argument,precondition='Complete finite immutable tagged input, valid heap IDs, and well-formed proper-list preconditions at internal helpers.'):
    for n in names.split():
        need('unique-tree-manual:'+n,n not in tree_specs)
        tree_specs[n]={'host_relation':relation,'manual_argument':argument,'precondition':precondition}

group('main','Checker.request; check',
      'Exact5 root and4 theory fields; strict signature, zero-or-one recognized schema, all axioms closed, fresh local registry, all blocks checked before top proof. Returns only complete proof result. Generic theory is not independently licensed here.')
group('nil','None/list sentinel', 'Only atom256 denotes nil; Boolean false is atom0, so failed-block marker cannot masquerade as empty registry.')
group('same','Native structural equality after JSON syntax validation',
      'Induction on immutable finite cons trees; compare atoms only when either operand is not a pair; pair equality recursively compares both children. Tree tags keep Boolean, integer, list, object and string distinct.')
group('l1 l2 l3 l4 l5 l6','Native fixed-size tuple/list constructors',
      'Each constructor prepends exactly its listed arguments in order and terminates in nil; no arithmetic primitive or semantic shortcut.')
group('size1 size2 size3','Exact list lengths1/2/3',
      'Pair plus exact nil tail checks distinguish an arity from a prefix; malformed tails cannot pass the valid wire boundary.')
group('second third','Native positions1/2',
      'head/tail projection agrees with zero-indexed native list positions under caller size checks; invalid data operation is not acceptance.')
group('append','Native ordered list concatenation',
      'Recursion on first list preserves every element/order and then shares second immutable list; used to append proved formulas without reversing line indices.')
group('reverse','Native reversed sequence',
      'Loop invariant: output is reversed consumed prefix and input is unconsumed suffix; used only where host reversed order is explicit.')
group('length','Exact natural list length',
      'One cons(1,...) per element produces canonical unary nonnegative length; no host integer/Boolean coercion.')
group('nth','Checker.proof.prior and assumption lookup',
      'Unary index consumes one input element per1; out-of-range returns false atom0, never a well-formed formula. Type3 guard at callers excludes negative and Boolean indices.')
group('member','Native set membership with structural equality',
      'Linear exact membership of proper finite lists; variable sets have unique sorted entries and formula atom lists have structural rather than name-only equality.')
group('is_type','Exact JSON native-type/tag case split',
      'Tagged cons and exact atom tag are required; wire_value supplies the complete representation invariant.')
group('text_is','Native exact string equality to fixed rule/protocol names',
      'Tag2 plus byte-word equality; equivalent to Unicode names only after a faithful canonical text boundary, which is not supplied by wire_word alone.')
group('get','Native dict lookup',
      'Object row search returns exact matching byte key value, otherwise false. Uniqueness of keys comes from wire_value; absent formula cannot pass formula_ok.')
group('fields','Checker.fields',
      'Equal object and expected-key counts plus membership gives exact key set only under unique-key invariant. Calling this helper without the wrapper is insufficient to reject duplicate keys.')
group('signature_ok','Checker.signature/string/natural',
      'Object row values all tag3; wire_value already validates byte-word keys and canonical unary naturals. Arbitrary finite arities are permitted, not a selected syntax catalogue.')
group('tag arg1 arg2','Native AST tag/argument projection',
      'Syntax validators establish exact array arities and tag strings before recursive semantic helpers project them.')
group('jstr arr make1 make2 make3 var fun all imp eq','Native immutable AST constructors',
      'Each constructor emits the same JSON tag/array shape and order as parsed host tuples re-encoded by encode_json; no alpha-equivalence quotient is introduced.')
group('term_ok','Checker.term',
      'Exact var2/fun3 cases; string names and exact array arguments; declared function arity equals canonical unary list length; recursively all subterms checked.')
group('formula_ok','Checker.formula',
      'Complete bot1/not2/eq3/pred3/all3/imp3/and3/or3 grammar; recursive term/formula validation and signature arities; no exists or higher-order rule is silently accepted.')
group('byte_less next_byte text_less','Native variable-name sorting used by free sets/induction',
      'byte_less scans finite0..255 to first operand encountered; two valid bytes force termination before attempting successor255. text_less is lexicographic with proper prefix first. UTF8-surrogatepass is monotone by codepoint for valid strings; invalid words are currently a separate byte-name domain.')
group('insert union remove','Native sorted finite set operations',
      'insert preserves uniqueness and strict text order; union repeatedly inserts; remove deletes unique target. Needed for deterministic universal parameter order and fresh-name avoidance.')
group('term_free','Checker.term_free',
      'Structural term recursion returns exactly variable names; function arguments are unioned; function symbols are not variables.')
group('free','Checker.free',
      'False mode removes binders, True mode includes all bound and free variable names. Both modes traverse every logical connective; True mode is required to avoid capture under shadowing during alpha-renaming.')
group('subst_args subst_term','Checker.subst_term',
      'Substitute exactly free variable occurrences in terms, recurse over every function argument and preserve function name/arity/order.')
group('increment_digits decimal','Host decimal fresh-name suffix str(j)',
      'Little-endian decimal carry maps9 to0 and increments next digit; nil introduces1. decimal starts0 and increments once per unary unit, then reverses. Thus fresh0,fresh1,... including9/10,99/100 transitions match host suffixes.')
group('subst','Checker.subst',
      'Binder equal to substituted variable or absent variable returns unchanged. Capture risk triggers freshN outside all body variable names, replacement free names, x,y; alpha-renames only old binder free occurrences via recursive substitution, then descends. Other cases preserve complete formula grammar.')
group('collect_atoms','Checker.tautology.collect',
      'Decomposes exactly propositional imp/and/or/not; bot contributes no atom; quantifiers, equalities and predicates are whole atoms, each structurally unique. Atom order differs from host repr sort but exhaustive tautology Boolean is invariant.')
group('truth','Checker.tautology.truth',
      'Same classical truth clauses including false bot and implication; complete environment binds each collected atom. Absent-atom false default is unreachable for a well-formed collected formula.')
group('valuations tautology','Checker.tautology',
      'Binary recursion covers every assignment to the complete finite atom set, conjunctively; early false is sound. Exponential work remains charged; no time/cost/valuation-order correspondence is claimed.')
group('induction','Checker.induction',
      'Full arbitrary well-formed template, capture-avoiding base and successor substitutions, conjunction/implication/universal conclusion, universal closure of every other free parameter in the same ascending name order. Rule guard checks license and exact zero0/succ1 arities.')
group('formulas_ok','Host tuple(self.formula(...))',
      'Every premise is checked using the same complete grammar; no unchecked prefix or selected subset.')
group('lookup','Checker.blocks lookup',
      'Returns exact earlier registered block interface by full byte name. Valid interfaces are pairs, so atomFalse cleanly denotes absence.')
group('check_blocks','Checker.request block loop',
      'Sequentially verify every block, exact4 fields, unique names, every premise/conclusion, nonempty proof under only its premises and prior registry, then register. No self/forward recursion. Source differs from reusable host Checker because tree registry is always fresh.')
group('references','Block-call exact prior references',
      'Walk both lists in lockstep, require type3 indices and full formula equality, and require both lists exhausted. Duplicates allowed when premises repeat; out-of-range/forward indices cannot match formulas.')
group('proof','Checker.proof',
      'Nonempty list; forbids generalizing any variable free in any assumption; every line fully syntax checked and validated before appended, strict earlier proof domain, and final formula exactly target. No proof search or hypothesis discharge is invented.')
group('prior','Checker.proof.prior',
      'Field must be type3; nth over proved prefix means every successful reference strictly precedes this line, including zero. Boolean false is not index0.')
group('rule_ok','Checker.proof eleven-way rule dispatch',
      'All11 primitive rules are enumerated in separate rule matrix. Exact per-rule field sets; unknown names returnFalse. Relies on fresh registry, sound substitutions and licensed theory boundary.')

host_specs={
 'canonical':('No semantic tree equivalent; custody serialization','ensure_ascii sorted compact JSON and noNaN; not injective over every arbitrary native surrogate-string sequence. Never substitute a digest for full public-value equality.'),
 'problem_hash':('External public problem binding','Hashes only protocol/theory/target. Proof and block proposals intentionally excluded. Optional hash alone does not certify theory licensing or every native-string distinction.'),
 'Checker.__init__':('main local initialization','Fresh stats and empty blocks establish one-request invariant; required for public check soundness. Reuse across different theories violates it.'),
 'Checker.tick':('No exact tree cost equivalence','Work accounting/Resource only; does not decide logical validity. Native memory/parser/recursion and tree VM budgets are distinct.'),
 'Checker.fields':('fields','Exact native dict and exact key set; parser pairs rejects duplicates before dict construction.'),
 'Checker.string':('is_type2 plus faithful text boundary','Exact native str; strings are names, no geometric interpretation or restricted catalogue.'),
 'Checker.sequence':('is_type1 plus wire_value','Exact native list excludes tuples and Boolean/integer aliases.'),
 'Checker.natural':('is_type3 plus wire_ones','Exact int excludes bool, nonnegative; arbitrary finite size abstractly, subject to parser/resource conditions.'),
 'Checker.signature':('signature_ok','Exact object, all string keys and natural arities; no special PA or Hilbert symbol meanings.'),
 'Checker.term':('term_ok','Complete exact var/fun grammar and declared arities; native tuple internal AST relation given in representation section.'),
 'Checker.formula':('formula_ok','Complete8-form constructor grammar; every term/formula recursive position validated.'),
 'Checker.term_free':('term_free','Set of free variable names of complete validated terms.'),
 'Checker.free':('free','False free variables / True all variable names, exact binders handled.'),
 'Checker.subst_term':('subst_term/subst_args','Exact recursive variable replacement; arguments retain order.'),
 'Checker.subst':('subst','Capture-avoiding substitution and same freshN generation, including nested shadowing.'),
 'Checker.tautology':('collect_atoms/valuations/tautology','Full Boolean validity, not an arithmetic or FOL decision procedure; atom order and work differ.'),
 'Checker.tautology.collect':('collect_atoms','Complete propositional connective traversal, other formulas atoms and bot false.'),
 'Checker.tautology.truth':('truth','Same truth table under complete valuation; host dict lookup and tree association list agree.'),
 'Checker.induction':('induction plus rule guard','Only explicit nat-induction license and zero/succ arities; full schema over arbitrary formulas and all other free parameters.'),
 'Checker.proof':('proof/rule_ok','All11 rules, exact fields, strict prior indices, full assumptions, exact final target; rule matrix gives every side condition.'),
 'Checker.proof.fields':('fields','Per-line fields include rule/formula and exactly declared parameters.'),
 'Checker.proof.prior':('prior/nth','Exact natural strictly less than proved count; excludes self/forward/negative/bool.'),
 'Checker.request':('main/check_blocks','Full public problem grammar and complete block checking. Does not reset self.blocks: unsafe across reused instances with changed theories.'),
 'check':('Combined main only after separate byte/value/budget boundary','Fresh Checker, strict bytes, JSON decoder, duplicate and float refusal, optional public hash, status Resource/recursion/memory unknown. Generic ValueError from native decimal parser guard is classified rejected, so unrestricted status equivalence is unavailable.'),
 'check.pairs':('wire_key_seen','Reject duplicate JSON keys before collapse; native Unicode key equality differs from raw bytes until text boundary is faithful.'),
 'check.bad_number':('No float tag in checker wire_value','All floating/nonfinite JSON number spellings rejected; no float coercion to natural or bool.')}

wire_specs={
 'main':'Complete wire_value first, then full semantic_main; short-circuit prevents malformed values reaching unguarded structural helpers.',
 'wire_word':'Proper finite list of byte atoms0..255; excludes pairs and nil atom256 as elements. This is not UTF8 or JSON escape normalization and currently admits byte255.',
 'wire_ones':'Proper finite list consisting only of atom1; canonical unary natural including empty0.',
 'wire_key_seen':'Byte-exact prior-key comparison for all object rows; uniqueness only agrees with Unicode keys after text correspondence.',
 'wire_value':'Complete recursive object/array/string/natural/nonzero-negative/bool/null7-tag grammar. Full object row shape, duplicate keys and all nested values checked. Bool exact0/1 and negative0 forbidden. No float tag. Acyclic heap is separate BOOT premise.'}

boundary_specs={
 'boundary_program':'Literal full wire wrapper concatenated with full FOL Source renamed only main->semantic_main. Exact19325B assembly verified by raw bytes; compiler correctness remains a separate obligation.',
 'decoded_heap':'Debug utility parses textual heap labels/children; not a complete canonical validator and not an admissible proof boundary. Requires well-framed trusted input; no missing-semicolon or child-order rejection theorem from this function.',
 'tree_word':'Iterative postorder expansion of valid tree root and valid topological heap to0+9LSB atom/1cons. Internal-1 marker is not a candidate atom. No raw heap address may cross certificate boundary.',
 'value_word':'Host encode_json then tree_word, admitted native JSON-type subset only. Does not independently check public licensing or root request fields; strings encoded surrogatepass.',
 'boundary_words':'Fixed order protocol/theory/target and free blocks/proof; one; per band. Reads only five KEYS and ignores extra root fields: exact request-domain validation is a required precondition, not rejection equivalence for arbitrary dicts.',
 'BoundaryLowering.__init__':'Builds additional bands and frozen key heap; parses fixed3 then empties stack and parses free2; pops bind values in correct reverse stack order; constructs exact keyed object before old_start. Full lowerer physical refinement not established here.',
 'BoundaryLowering.push':'Copies a finite reversed value word to stack delimiter; relies on canonical Lowering scan/capacity semantics and region invariants; no BOOT semantic-value theorem from Source inspection alone.',
 'BoundaryLowering.pop':'Copies exactly one stack word to destination and removes delimiter; requires actual nonempty stack and complete region handling. Underflow cannot be borrowed from fixed public values because stack reset is explicit.',
 'BoundaryLowering.parse_band':'Token0 reads exactly9bits and rejects atom>256; token1 pops right/left and canonical-cons; one; then onlyB tofixedcolon then rewind. It validates structure, not tagged value/UTF8/program semantics; fences must remain BOUND.',
 'BoundaryLowering.parse_band.atom':'Full depth9 binary decision tree in Source, valid0..256 leaves assigned; no hand-selected byte subset. Not generated in this audit.',
 'BoundaryLowering.initial_boundary':'Trusted initialization builds full public and free words/capacities with fixedcolon; not itself an immutable public-data licensing check or unknown-certificate selector proof.',
 'BoundaryLowering.declaration':'Metadata exposes all bands/keynodes/bootnodes/old_start/wire syntax. Hashes/declared state names alone do not prove linked16band machine acceptance.'}

compiler_specs={
 'Heap.__init__':'Checks sequential topological seed cons cells and rejects duplicate canonical pairs; frozen initial program heap is a trust boundary.',
 'Heap.cons':'Exact existing IDs/atoms and canonical pair interning; values always valid under invariant; heap bound is Resource, not proof rejection.',
 'Heap.head':'Exact int existing node required; returns left.', 'Heap.tail':'Exact int existing node required; returns right.',
 'Heap.word':'Reverse-fold preserves list order and endsnil.', 'Heap.text':'UTF8-surrogatepass bytes, not JSON decoder semantics.',
 'Heap.natural':'Unary finite natural builder; requires nonnegative caller domain.',
 'encode_json':'All exact dict/list/str/bool/int/None tags with bool checked beforeint; native key strings are a caller premise (Heap.text fails otherwise). Dict order retained, negative0 not native distinct. Full all-str domain exceeds check(payload) JSON-image caveat.',
 'Compiler.__init__':'AST only ordinary function definitions, unique static names and fixed primitives; no dynamic request execution.',
 'Compiler.function':'Arguments then fresh nil locals/fullregisters, explicit function body then false return; no liveness alias allocator.',
 'Compiler.fresh':'Monotone register allocation.', 'Compiler.emit':'Literal ordered instruction append.',
 'Compiler.constant':'Only nil/bool/byte/string literals, canonical seed heap and unique constants; no formula-specific primitive.',
 'Compiler.expression':'Static Name/Constant/call/not/short-circuit And/Or, left-to-right arguments. All call arguments captured before target return destination write. Invalid AST rejected. Full formal compiler theorem not supplied.',
 'Compiler.statement':'Assignment/return/if/while/break branch patches preserve Source control structure under valid inputs; no request-dependent Source compilation.',
 'Compiler.declaration':'Complete13-opcode program/heap/constants/functions ordinary data, whole image must be fixed and checked.',
 'fingerprint':'Digest custody only; no semantic or identity proof.',
 'validate':'Static grammar/ranges/topological seed and arities, no proof semantics. Does not by itself prove every arbitrary hand-written program avoids fallthrough or that supplied runtime heap equals frozen seed.',
 'run':'Operational abstract interpreter, not literal physical TM. Requires validated fixed image, matched seeded heap and valid input ID; pair/atom validity relies on those invariants. Call copies all inputs, frames preserve registers, invalid operations reject, step/heap caps unknown. No call executed here.'}

matrices=[]
for source,specs in [('serialized_kernel.py',host_specs),('fol_checker.tree',tree_specs),('boundary_syntax.tree',wire_specs),('proof_boundary.py',boundary_specs),('tree_machine.py',compiler_specs)]:
    funcs=inventory(trees[source]);need('manual:complete-every-function:'+source,set(x['name'] for x in funcs)==set(specs))
    for x in funcs:
        spec=specs[x['name']]
        if isinstance(spec,tuple):spec={'tree_relation':spec[0],'manual_argument':spec[1]}
        if isinstance(spec,str):spec={'manual_argument':spec}
        matrices.append({'source':source,**x,**spec,'review':'MANUAL_SOURCE_ONLY',
                         'runtime_tested_here':False,'mechanized_correspondence':False})

rules=[
 ('axiom',['name'],r'\(A\) equals the named declared closed axiom.', 'Every model of the licensed theory satisfies it; checker does not establish external license.', ['unknown-name','formula-mismatch','open-theory-axiom','axiom-context-changed']),
 ('tautology',[],r'\(A\) is true in every propositional valuation of complete atomic subformulas.', 'The actual FOL interpretation induces one such valuation; treating quantified formulas as atoms is sound but incomplete.', ['one-false-valuation','bot-alone','quantified-atoms-distinct','repeated-identical-atom']),
 ('refl',[],r'\(A\) is exactly \(t=t\).','Identity equality is reflexive for every term valuation; both sides must be syntactically equal.', ['different-terms','predicate-instead-of-equality','malformed-term']),
 ('instantiate',['universal','term'],r'\(A=(\forall x\,P)\to P[t/x]\).','Capture-avoiding substitution lemma establishes all structures/assignments; u and t must themselves be well formed.', ['capture-requires-fresh','shadowed-variable','x-absent','universal-not-all','wrong-instance']),
 ('distribute',['variable','antecedent','consequent'],r'\(A=\forall x(P\to Q)\to(P\to\forall x\,Q)\), with \(x\notin FV(P)\).','Independence of antecedent from x is essential and explicitly checked.', ['x-free-in-antecedent','x-bound-only-in-antecedent','wrong-binder','wrong-consequent']),
 ('eq_subst',['variable','template','left','right'],r'\(A=(s=t)\to(P[s/x]\to P[t/x])\).','Equality replacement plus capture-avoiding substitution; arbitrary complete formula template, no selected term positions.', ['nested-binder-capture','x-absent','multiple-occurrences','left-right-mismatch','wrong-template']),
 ('mp',['antecedent','implication'],r'From earlier \(P\) and \(P\to A\), infer \(A\).','Both indices refer to proved prefix; semantic modus ponens preserves every current-assumption model.', ['self-reference','future-reference','bool-index','negative-index','out-of-range','antecedent-mismatch']),
 ('generalize',['variable','source'],r'From earlier \(P\), infer \(\forall x\,P\), with \(x\notin FV(\Gamma)\).','Forbid free x in all block premises, even unused ones; since all theory axioms are closed and earlier blocks are sound sequents, this is sufficient. No existential eigenvariable rule is implemented.', ['free-in-used-premise','free-in-unused-premise','bound-only-in-premise','source-self-reference']),
 ('induction',['variable','template'],r'\((P[0/x]\land\forall x(P\to P[Sx/x]))\to\forall x\,P\), universally closed over other free variables.', 'Only with enabled nat-induction and exact zero0/succ1 signature. This is a licensed schema, not valid in arbitrary equality structures without the license.', ['disabled-schema','zero-wrong-arity','succ-wrong-arity','arbitrary-template','multiple-parameters-order','nested-capture','missing-parameter-closure']),
 ('assumption',['index'],r'\(A\) equals one current block premise.', 'Current assumptions are supplied only by checked block interface; top-level list is empty.', ['top-level-assumption','bool-index','negative-index','out-of-range','formula-mismatch']),
 ('block',['name','inputs'],r'Use an earlier verified sequent \(\Gamma\vdash A\) with exact earlier lines for every premise.', 'Induction on registry order and proof line order; exact premise multiplicity/order and conclusion, no self/forward recursion or hidden substitution.', ['unknown-name','self-recursion','forward-block','too-few-inputs','too-many-inputs','reordered-distinct-premises','duplicate-premises','stale-theory-registry'])]
rule_matrix=[]
for name,parameters,form,argument,variants in rules:
    rule_matrix.append({'rule':name,'exact_fields':['rule','formula']+parameters,'form':form,
                        'manual_soundness_argument':argument,'prospective_variants':variants,
                        'status':'MANUAL_RELATIVE_THEORY_ARGUMENT_NOT_MECHANIZED','executed':False})
tree_rule_names=[]
for x in ast.walk(trees['fol_checker.tree']):
    if isinstance(x,ast.Call) and isinstance(x.func,ast.Name) and x.func.id=='same' and len(x.args)==2 and isinstance(x.args[0],ast.Name) and x.args[0].id=='rule' and isinstance(x.args[1],ast.Constant):tree_rule_names.append(x.args[1].value)
need('rules:all-eleven-exact-dispatch-branches',set(tree_rule_names)==set(x[0] for x in rules) and len(tree_rule_names)==len(rules)==11)

bot=['bot']; eqx=['eq',['var','x'],['var','x']]
empty={'functions':{},'predicates':{},'axioms':{},'schemas':[]}
old={'functions':{},'predicates':{},'axioms':{'old-false':bot},'schemas':[]}
stale_first={'protocol':'gcts-fol-1','theory':old,'blocks':[{'name':'stale','premises':[],'conclusion':bot,
    'proof':[{'rule':'axiom','formula':bot,'name':'old-false'}]}],
    'proof':[{'rule':'block','formula':bot,'name':'stale','inputs':[]}],'target':bot}
stale_second={'protocol':'gcts-fol-1','theory':empty,'blocks':[],
    'proof':[{'rule':'block','formula':bot,'name':'stale','inputs':[]}],'target':bot}
extra={'protocol':'gcts-fol-1','theory':empty,'blocks':[],
       'proof':[{'rule':'refl','formula':eqx}],'target':eqx,'extra':None}

findings=[
 {'id':'F1','severity':'HIGH_IF_LOW_LEVEL_CHECKER_IS_REUSED','source':'serialized_kernel.py','lines':[29,33,217,239],
  'claim':'Checker.request does not clear the old block registry when replacing its theory.',
  'manual_counterexample':'Use the same Checker for literal requests first and second below; old empty-premise block proves bot using old axiom, then remains available under empty new theory.',
  'requests':[stale_first,stale_second], 'predicted_reused_low_level_result':'Both requests return normally; second bot has no derivation in the new empty theory.',
  'safe_entrypoints':'check(payload) constructs a new Checker for each call; tree main starts registryNone. Neither current entrypoint has this reuse bug.',
  'required_invariant':'One fresh Checker per request, or a separately reviewed successor reset of blocks at the request boundary. Never infer safety for arbitrary reusable Checker.request/proof calls.',
  'executed':False,'changes_made':False},
 {'id':'F2','severity':'BLOCKS_UNRESTRICTED_HOST_TREE_CORRESPONDENCE','source':'boundary_syntax.tree','lines':[6,11,27,59],
  'claim':'wire_word accepts arbitrary byte words, including255, not just canonical UTF8-surrogatepass strings.',
  'manual_counterexample':'In an otherwise valid refl(eq(var(name),var(name))) request, let the tagged variable-name string body be the single byte255. Full wire/term/formula/proof logic accepts this byte-name reflexivity, but it is outside host str UTF8 encoding image.',
  'required_invariant':'A faithful text syntax gate must cover every nested string and object key. Qualified lexical routine is not already linked merely because it passed standalone tests.',
  'logical_effect':'Sound relative to a byte-word name language; not the same current host string language.', 'executed':False},
 {'id':'F3','severity':'INPUT_DOMAIN_CORRESPONDENCE_GAP','source':'proof_boundary.py','lines':[41,43],
  'claim':'boundary_words ignores extra request fields, while host check and full semantic_main reject them.',
  'literal_request':extra, 'manual_prediction':'Host check rejects extra field; helper emits the same5 selected values as a valid reflexivity request. No unsound mathematical conclusion follows, but arbitrary-input rejection correspondence is false.',
  'required_invariant':'Restrict this author utility to already exact-five-field requests or independently validate the full input before encoding; do not silently claim utility is an input validator.', 'executed':False},
 {'id':'F4','severity':'PUBLIC_THEORY_LICENSE_AND_BINDING_OPEN','source':'serialized_kernel.py;fol_checker.tree;proof_boundary.py',
  'claim':'The checker accepts relative to arbitrary supplied closed axioms and optional nat-induction; no built-in PA/Hilbert context license and no mandatory external full public pin is enforced by the common checker.',
  'manual_recipe':'A public theory whose named axiom is bot admits a one-line bot axiom proof. That is legitimate relative-theory derivability, not an absolute mathematical theorem. Changing target/theory when expected_problem_sha256 is None is intentionally not refused by check.',
  'required_invariant':'Externally license and freeze complete theory/signature/schema/binder formalization and exact protocol/target, then compare full values. Hashes remain custody metadata.', 'executed':False},
 {'id':'F5','severity':'RESOURCE_STATUS_CORRESPONDENCE_GAP','source':'serialized_kernel.py','lines':[252,264],
  'claim':'Generic ValueError, including a native decimal integer-digit parser guard failure if enabled, is classified rejected rather than unknown_resource_budget.',
  'manual_recipe':'If the runtime decoder enforces decimal limitD, declare an unused function with a natural arity havingD+1 decimal digits, use an otherwise valid reflexivity proof and sufficient explicit max_bytes. Native json.loads guard can raise ValueError before logical checking; abstract tagged unary signature remains well formed. No guard value or runtime occurrence was probed here.',
  'required_invariant':'Scope correspondence to successfully decoded admissible values under adequate native resources, or classify such native-limit failures separately in a reviewed successor. Rejection is certificate-relative and never theorem negation.', 'executed':False},
 {'id':'F6','severity':'SERIALIZATION_DOMAIN_AND_HASH_INJECTIVITY_OPEN','source':'serialized_kernel.py canonical/check; tree_machine.py encode_json',
  'claim':'Native all-str tagged-value domain is not automatically the image of UTF8-decoded JSON bytes. Standard ASCII JSON surrogate-pair normalization must be distinguished from surrogatepass encoding.',
  'manual_recipe':'Compare native name codepoints[65536] with native name codepoints[55296,56320]. Pure-Python stdlib ASCII encoder Source emits the same two Unicode escapes; decoder Source combines escaped high/low pair. The tagged UTF8-surrogatepass words differ. Thus canonical hashes alone must not identify all arbitrary native string values.',
  'evidence_scope':'Static reading of pinned stdlib pure-Python encoder.py lines48-68 and decoder.py lines118-125 only; C accelerator equivalence and an actual observation were not executed or certified here.',
  'required_invariant':'State whether the theorem concerns native Checker.request values or check(payload) JSON-image values; provide a full codec/normalization argument for that domain and full-value public binding. Do not add a smaller selected theorem language silently.', 'executed':False},
 {'id':'F7','severity':'LOW_LEVEL_BOUNDARY_PRECONDITIONS','source':'proof_boundary.py decoded_heap/tree_word',
  'claim':'decoded_heap is a debug textual decoder, not a canonical or complete proof validator; tree_word assumes valid heap/root and uses internal-1 marker.',
  'manual_recipe':'Missing finalsemicolon is removed by split(... )[:-1]; raw root-1 is treated as output cons marker. Those invalid arguments are outside the trusted valid Heap path, not a new checker acceptance counterexample.',
  'required_invariant':'Never use these helpers as validation of candidate heap records or candidate addresses. Candidate input is only atoms/cons and all actual semantic values must be checked after BOOT.', 'executed':False},
 {'id':'F8','severity':'FULL_PHYSICAL_CORRESPONDENCE_UNPROVED','source':'proof_boundary.py;tree_machine.py;fixed-interpreter-encoding-contract-v1.json',
  'claim':'Full compiler, immutable image/heap, canonical BOOT semantic values, public binding, all13 opcodes and literal physical linked machine remain distinct obligations.',
  'required_invariant':'The reviewed69-function Source is not itself a physical checker. L structural grammar and standalone UTF8 do not establish value construction/controller/linkage. Preserve BOUND/unknown and no extra accept across every interface.', 'executed':False}]

# These are explicit declarative families/controls, not materialized fixtures and
# not an exhaustive finite substitute for the unbounded input language.
families=[]
def family(identifier,functions,variants):
    families.append({'id':identifier,'functions':functions.split(),'variants':variants,'status':'DECLARATIVE_UNRUN'})

family('wire-complete-seven-tags','wire_value wire_word wire_ones wire_key_seen',[
 'Every tag0..6 valid empty/nonempty shape; wrong-tag7/255/256/node; array improper tail; object malformed row; nested invalid value.',
 'Object duplicate empty key and duplicate nonempty key separated by another row; samecount duplicate key with missing required key.',
 'Natural empty0 and unary1/2; bool0/1 versus natural0/1; boolbody2/nil; negativeempty0 must reject; nonempty unary negatives allowed.',
 'String/key bytes0,127,128,255; nil and pair as byte elements reject; byte255 currently accepted until linked UTF8 gate.'])
family('lists-and-constructors','nil same l1 l2 l3 l4 l5 l6 size1 size2 size3 second third append reverse length nth member is_type text_is get fields tag arg1 arg2 jstr arr make1 make2 make3 var fun all imp eq',[
 'Empty and length1/2/3/6 properlists, each strict arity and prefix/impropertail refusal; structural equality bothchildren and distinct tags.',
 'append empty/nonempty sharing; reverse twice and unarylength; nth0,last,length,+1 and all caller index tags; absent get returnsfalse.',
 'All exact root/theory/per-rule keysets; every omitted/extra field and reordered object; duplicate proof-field rows rejected at wrapper.'])
family('full-term-formula-grammar','signature_ok term_ok formula_ok formulas_ok',[
 'Both term constructors, all8 formula constructors, nullary and positivearity functions/predicates, empty variable/symbol names.',
 'Unknown symbols; exact arityoff-by-one; all wrongnode lengths; list/string/bool/int swapped; malformed nested subtree at every recursive argument.',
 'All signaturearitytags including bool0/1, negative, str; all closed versus free-variable theory axioms.'])
family('sets-order-and-freshnames','byte_less next_byte text_less insert union remove term_free free increment_digits decimal subst_args subst_term subst',[
 'Sorted Unicode names at ASCII/2byte/3byte/4byte boundaries, isolated surrogates and byte255; properprefix and duplicateinsert.',
 'Formula with nested repeated binders, free under sibling branch, all-names mode includes shadowed binders; remove absent/present/only.',
 'Substitute x=y binder:unchanged; xabsent:unchanged; no capture; replacement shares bindername; nested shadowing; fresh0,fresh1 occupied; carry9to10 and99to100.',
 'Both equality sides, all predicate arguments, all logical children, zero/succ terms; compare exact fresh-name AST outputs, not merely alpha-equivalence.'])
family('propositional-exhaustiveness','collect_atoms truth valuations tautology',[
 'botfalse, notbottrue, every truth clause; p->p, p or notp, p and notp; equality and quantified formulas treated as atoms.',
 'Repeated identical atoms deduplicated; structurally different sameprintedname predicates kept; every valuation for small full atomsets.',
 'Host reprsort versus tree atomcollection order must agree on Boolean validity only; cutoff is unknown rather than false theorem.'])
family('all-block-dependency-scopes','main check_blocks lookup references proof prior rule_ok',[
 'Empty registry; sequential chainof3 blocks; zero-premise and repeatedpremise block; exact inputs order/multiplicity and conclusion.',
 'Duplicate blockname empty/nonempty; self/forward/unknownblock; using a later block; failed block never added; failed registry atom0 cannot act asnil.',
 'Every self/forward/outofrange/negative/bool lineindex; no assumptions top-level; all generalization forbidden variables including unused premises.',
 'Two literalrequests F1 reused Checker must be refused by freshness boundary; same requests with fresh publiccheck each are separate contexts.'])
for row in rule_matrix:
    family('rule-'+row['rule'],'rule_ok proof', ['Valid full rule instance with exactfields.']+row['prospective_variants'])
family('public-licensing-and-target-pin','main',[
 'Complete licensed PAcontext with unrestricted induction versus omittedschema/alteredzero/succ; no claimPA from arbitrarysignaturealone.',
 'Complete separatelylicensed Hilbert context including explicit sort/binder/classfield encoding, not coordinate picture or tables/chairs semantics assumed.',
 'Change each publicprotocol/theory/target subtree while proofsame; mandatory fullvalue external pin must reject. Change only blocks/proof within approved capacity remains candidate data.',
 'Literal botaxiom relative-theory acceptance must never be labeled absolute theorem; proof of candidate-selected target is not proof of authorselected target.'])
family('boundary-all-token-and-scope-cases','boundary_program decoded_heap tree_word value_word boundary_words BoundaryLowering.__init__ BoundaryLowering.push BoundaryLowering.pop BoundaryLowering.parse_band BoundaryLowering.parse_band.atom BoundaryLowering.initial_boundary BoundaryLowering.declaration',[
 'All257 atom values0..256 and invalid257..511 in9bits; each truncated atom prefix; binary/cons underflow; properprefix trees; missing/extra terminator.',
 'Fixed3roots then reset then free2roots; fixed malformed count and free malformed count; free underflow cannot borrow public stack; exactfield order after pops.',
 'Padding B* then first fixedcolon only; nonblankgarbage or extra; after terminator reject; fence/capacity yields BOUND.',
 'Preserve exact full nested taggedvalue, objectkeyuniqueness and all string gates after structuralparse; no raw heap IDs or extra heads.',
 'F3 extra rootfield sanitizer distinction; F7 malformed debugheap does not become validated evidence.'])
family('compiler-and-runtime-separate-obligations','Heap.__init__ Heap.cons Heap.head Heap.tail Heap.word Heap.text Heap.natural encode_json Compiler.__init__ Compiler.function Compiler.fresh Compiler.emit Compiler.constant Compiler.expression Compiler.statement Compiler.declaration fingerprint validate run',[
 'Every13opcode and all operand aliaspatterns; fullregisters call frame, recursionreturn, explicit falsefallthrough, shortcircuit And/Or bothbranches, nestedloopbreak.',
 'Seedheap matched/notmatched, duplicatepair, forwardchild, boolID, invalidinputID; full programimagemalformedgrammar must be refused before attribution.',
 'Complete same69functions with no selectedproofpath; sourcecompiler work not runhere; semanticcompilerrefinement and physicalopcodes require separate future offer.',
 'Resource cutoff everyconstruction/opcodestep is unknown; no budgetincreased, reusedgrant or preparedwitnessroute.'])
family('native-parser-and-string-domain','check canonical problem_hash',[
 'Duplicate JSON keys at everyobjectdepth, floating/nonfinite number spellings, bytesrequired and invalidUTF8, integerdecimal guard whenenabled.',
 'JSON escaped isolatedsurrogate, nonBMPscalar, adjacentnative high/lowsurrogates; domainnormalization/serializeparse relation explicitly compared, never hashonly.',
 'Expectedproblemhashpresent/None, full publicvaluepins, byte/work/recursion/memory limits; distinguish invaliddata from nativelimit unknown.'])
bank={'schema':'common-kernel-complete-source-prospective-recipes-v1','source_only':True,'executed':False,
      'fixture_calls':0,'rule_count':11,'families':families,
      'per_function_recipe_obligations':[{'source':x['source'],'function':x['name'],
          'positive_and_negative_partition_obligation':x['manual_argument'],
          'status':'DECLARATIVE_UNRUN','materialized_fixture':False} for x in matrices],
      'explicit_counterexample_recipes':findings,
      'coverage_scope':'Every authored host/tree/wire/boundary function and all11 rules are audited. Families describe all branch obligations; the infinite mathematical input language is not a finite exhaustive runtime bank. No recipe ran.',
      'no_actual_authority':True}

representation=[
 'One host native JSON dict maps to tag0 plus ordered proper list of cons(keyByteWord,value); list tag1; string tag2; nonnegative exactint tag3 unaryones; negative nonzero tag4 unaryabs; bool tag5 atom0/1; None tag6nil. Host internal tuple AST is represented by the same JSON array constructors.',
 'Whole wrapper rejects duplicate keys and malformed taggedvalues before semantic_main. This makes fields count+membership equivalent to exact host key set and all type distinctions strict. Direct unwrapped semantic_main has weaker preconditions and is not the admitted arbitrary-value entrypoint.',
 'Unicode/string equivalence needs a domain theorem, not only byte validation. Successful native JSON parse, direct Checker.request values, canonical ensure_ascii bytes and surrogatepass tagged bytewords are distinct boundary layers. F2/F6 specify remaining gaps.',
 'Resource/status and exact traces are intentionally outside acceptance Boolean correspondence. Host repr-sorted tautology order differs from tree collection order; host work counters/native recursion/parser limits differ from finite treeVM limits.',
 'No scalar float or nonfinite value is part of this FOL checker language; new strict value DAG codec may preserve wider evidence types but does not change checker semantics.' ]

soundness={
 'claim':r'For a fresh one-request checker, valid finite input and faithfully bound licensed theory \(T\), if checking terminates with acceptance then \(T\vdash A\) in the displayed classical first-order calculus with equality and precisely the enabled induction schema. Consequently every intended model of those licensed axioms/schema satisfies \(A\).',
 'proof_plan':[
  'Simultaneous structural induction for term/formula validation and faithful representation, then free-variable and capture-avoiding substitution lemmas. Names are uninterpreted symbols; arbitrary bijective renaming does not supply intended geometry.',
  'For each of the11 rule rows, prove semantic validity under any assignment satisfying closed theoryaxioms, enabledschemas and current blockpremises. Generalization uses the complete forbidden free-variable set.',
  'Induct over prior blockregistry: each block is a sound sequent under its own exactpremises and the same unchangedtheory. Blockcall applies it only to strictlyprior exactpremise lines.',
  'Within each proof, induct over appended provedprefix. Every line is wellformed and entailed by currentpremises. Lastline exacttarget concludes; top-level assumptions empty.',
  'Use same full grammar/constructors and deterministic captureavoidance to obtain host/tree acceptance correspondence only on the stated common representation domain, fresh state and adequate resource conditions. F2/F3/F5/F6 prevent an unqualified all-input/status theorem now.',
  'Separately prove Source->bytecode->BOOT semanticvalues->physical machine->Wang rows->point t/m acceptance, noextraaccept and publicpin equality. None follows from this manual rule argument.' ],
 'not_claimed':['mechanized soundness theorem','runtime qualification of common checker or full VM','complete proof search','PA consistency or soundness','Hilbert geometry formalization adequacy','GCTS or RL contribution/speedup','any new discovered mathematical theorem'],
 'PA_scope':'Only exact externally licensed full PAaxioms plus arbitrary nat-induction templates can justify PAderivations. zero/succ symbolnames alone do not make a model natural numbers. Additional functions/predicates with induction require explicit theorylicense.',
 'geometry_scope':'Current signature is one-sorted first-order arities. Points/lines/planes, incidence/betweenness/congruence, dimensions and binder/classfield encodings must all be faithfully formalized/licensed externally before any Hilbert/Euclidean theorem claim. No explicit Euclidean picture is used.',
 'epistemic_status':'Independent manual Source argument with concrete interface counterexample recipes; conditional, not a mechanized proof. No rule-level counterexample found in fresh valid-domain entrypoint; not a certification of every low-levelAPI.'}

matrix_pin=freeze('complete-function-rule-obligation-matrix-v1.json',{
 'schema':'common-kernel-complete-function-rule-obligation-matrix-v1','source_only':True,
 'functions':matrices,'function_count':len(matrices),'rules':rule_matrix,'rule_count':11,
 'representation':representation,'subject_calls':0,'subject_imports':0,'static_metadata':static})
bank_pin=freeze('common-kernel-prospective-recipes-v1.json',bank)
negative_pin=freeze('common-kernel-source-interface-negatives-v1.json',{
 'schema':'common-kernel-source-interface-negatives-v1','source_only':True,'findings':findings,
 'current_public_check_freshness_not_broken':True,'all_recipes_unrun':True,
 'frozen_Sources_unchanged':True,'new_actual_invocations':0,'new_grants':0})
report={
 'schema':'independent-full-common-kernel-correspondence-Source-audit-v1',
 'status':'SOURCE_AUDIT_COMPLETE_WITH_INTERFACE_COUNTEREXAMPLES',
 'reviewer_identity':'/root/recovered_batch_review','source_only':True,
 'full_Source_read':['master contract','full fixed-interpreter design','full serialized_kernel','full64-function folchecker','full5-function wirewrapper','full69-function combinedSource','full proof_boundary','full tree_machine'],
 'sources':[pin(S/n) for n in expected],
 'supporting_stdlib_Source':[{'pin':pin(S/'stdlib-json-encoder.py'),'reviewed_lines':[48,68],
    'scope':'Pure-Python ASCII string encoder Source only; C accelerator not audited or executed.'},
   {'pin':pin(S/'stdlib-json-decoder.py'),'reviewed_lines':[118,125],
    'scope':'Pure-Python escaped-surrogate combination Source only; C accelerator not audited or executed.'}],
 'Source_recovery':[pin(O/'source-recovery-manifest-v1.json'),pin(O/'source-recovery-successor-v2.json'),pin(S/'Root-source-recovery-v1.json')],
 'source_recovery_note':'Initial exact git blob was missing in promisor clone; failed read-only retrieval preserved. Root recovered exact bytes through read-only git/blob API; sha/length verified before copying. No smaller kernel retyped or substituted.',
 'matrix':matrix_pin,'prospective_recipes':bank_pin,'interface_negatives':negative_pin,
 'function_count':len(matrices),'rule_count':11,'findings':findings,'manual_relative_soundness_argument':soundness,
 'whole_host_tree_correspondence_qualified':False,'mechanized_proof':False,
 'fresh_public_check_rule_soundness':'No rule-level counterexample found; conditional manual relative-theory argument above.',
 'all_function_obligations_covered':True,'all_rule_branches_covered':True,
 'runtime_qualified':False,'full_physical_VM_qualified':False,'new_theorem':False,
 'GCTS_RL_advantage_established':False,'G1_adopted':False,'old_G0_negative_unchanged':True,
 'goal_status':'active','actual_execution_authorized':False,'new_grants':0,'new_actual_invocations':0,
 'subject_imports':0,'subject_calls':0,'helper_calls':0,'compiler_calls':0,'checker_calls':0,
 'fixture_calls':0,'simulator_calls':0,'table_generation_calls':0,'sizing_probes':0,
 'semantic_replays':0,'partial_files_opened':0,
 'static_metadata_only':{'AST_parses':len(static),'unused_compiles':len(static),'research_code_executed':False},
 'remaining_gaps':[x['id']+': '+x['claim'] for x in findings],
 'checks':checks,'failed_static_checks':[], 'author':pin(Path(__file__)),
 'frozen_files_mutated':False,'primary_reader_index_active_mutated':False,
 'tools_stopped_after_freeze':True}
out=freeze('independent-full-common-kernel-Source-audit-v1.json',report)
print(json.dumps({'report':out,'matrix':matrix_pin,'recipes':bank_pin,'negatives':negative_pin,
                  'functions':len(matrices),'rules':len(rule_matrix),'static_checks':len(checks)},sort_keys=True))
