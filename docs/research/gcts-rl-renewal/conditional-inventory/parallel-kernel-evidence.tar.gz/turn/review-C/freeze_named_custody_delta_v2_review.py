"""Exact named-owner Source delta review only; no mutation or seal invocation."""
import ast
import hashlib
import json
from pathlib import Path
N=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-linked-evidence-20261020')
O=N/'review-C';B=N/'schema-B/custody-v2';C=O/'named-custody-Sources-v2';C.mkdir(exist_ok=True)
checks=[];pins=[]
def need(n,v):
    checks.append({'check':n,'passed':bool(v)})
    if not v:raise ValueError(n)
def pin(p):
    raw=p.read_bytes();return {'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
hraw=(B/'handoff-v2.json').read_bytes()
need('exact-handoff',len(hraw)==2773 and hashlib.sha256(hraw).hexdigest()=='88b6905335dfec7704ec6fb05ac7c0f49f4b4c5e7a5104ae875574a8a7f88171')
h=json.loads(hraw)
for row in h['artifacts']:
    p=Path(row['path']);raw=p.read_bytes();need('pin:'+p.name,len(raw)==row['bytes']and hashlib.sha256(raw).hexdigest()==row['sha256'])
    dest=C/p.name;need('fresh:'+p.name,not dest.exists());dest.write_bytes(raw);pins.append(pin(dest))
p=C/'handoff-v2.json';need('fresh-handoff',not p.exists());p.write_bytes(hraw)
oldworker=(O/'linked-parent-negative-preimages-v1/qualify_linked_batch_worker_v1.py').read_text()
oldfrag=(O/'linked-parent-negative-preimages-v1/worker_integration_v1.fragment.py').read_text()
oldtree=ast.parse(oldworker)
oldfn=next(n for n in oldtree.body if isinstance(n,ast.FunctionDef)and n.name=='_recursive_function_owner_seal')
oldbody=ast.get_source_segment(oldworker,oldfn)
newseal=(C/'named_owner_seal_v2.fragment.py').read_text().rstrip()
newworker=(C/'qualify_linked_batch_worker_v2.py').read_text()
need('worker-exact-seal-and-version-delta',oldworker.replace(oldbody,newseal,1).replace(
 "VERSION = 'proposed-linked-complete-batch-worker-v1'",
 "VERSION = 'proposed-linked-complete-batch-worker-v2-named-owner-seal'",1)==newworker)
need('fragment-only-exact-seal-delta',oldfrag.replace(oldbody,newseal,1)==(C/'worker_integration_v2.fragment.py').read_text())
static=[]
for n in ('named_owner_seal_v2.fragment.py','worker_integration_v2.fragment.py','qualify_linked_batch_worker_v2.py'):
    t=ast.parse((C/n).read_bytes());compile(t,n,'exec');static.append({'source':pin(C/n),'AST_parse':True,'unused_compile':True,'executed':False})
recipes=json.loads((C/'unrun-custody-recipes-v2.json').read_bytes())
need('all20-unrun-controls',len(recipes['recipes'])==recipes['count']==20 and recipes['all_unrun']is True
     and all(x['unrun']is True for x in recipes['recipes']))
need('class-bindings-explicit',"members.append((name,id(kind),id(member),target,accessors))"in newseal)
need('aliases-not-deduped-before-edge',"if identity in seen:continue"in newseal and'edge_owner(member)'in newseal)
need('strong-owners-retained','tuple(owners)'in newseal and'owners.append(owner)'in newseal)
need('main-still-refuses',"raise PolicyFailure('Historical plans/grants retired;"in newworker)
out={
 'schema':'typed-linked-named-custody-v2-Source-delta-review-v1','reviewer_identity':'/root/recovered_batch_review',
 'status':'PASS_SPECIFIC_SOURCE_DELTA_ONLY','review_passed':True,'source_only':True,
 'handoff':pin(C/'handoff-v2.json'),'pins':pins,
 'retained_negative':pin(O/'typed-linked-parent-Source-custody-negative-v1.json'),
 'separate_unfixed_schema_negative':pin(O/'typed-linked-parent-snapshot-schema-negative-v1.json'),
 'full_offer_review_completed':False,'specific_counterexample_fixed_manually':True,
 'manual_findings':[
  {'finding':'Namedclassedges','argument':'Everyclassmember recordsname,exactdescriptortypeid,descriptorownerid,target/accessors. SwappingFacade.count_query/select_query changesnamededges evenwithsamefunctionnodeset;66b418counterexample is addressed.'},
  {'finding':'Allaliasedges','argument':'Nodes visitedonce buteachprocessednode recordsallordered/namedoutgoingedges beforeworklistvisits. Repeatednamedaliases/default/closureslots retainmultiplicity andassociation.'},
  {'finding':'Functionslots','argument':'Functionid/code/defaulttuple/kwdefaultdict/closurecellowners included; eachpositionaldefaultindex andnamedkeyword default pluscellindex/availability/contentowner recorded. Emptycell differsfrompresentNone.'},
  {'finding':'Descriptorsandclasses','argument':'Exactstaticmethod/classmethod targets, propertyfget/fset/fdel/docowner, bases andMRO mappings included. Exacttype/functionscope avoidsarbitrarymetaclass/descriptoraccesscallbacks; mutablecontainercontents remainseparate literalguards.'},
  {'finding':'Strongcustody','argument':'Returned_NamedOwnerSeal ownsactualoriginalfunctions/code/defaults/kwdict/cells/contents/classes/descriptors/accessors/bases/MRO. IDsarediagnosticbindings, notruntimeownerreconstruction.'},
  {'finding':'Safeequalityandcycles','argument':'Rows containonlybuiltinscalars andtuples; comparison nevercomparesarbitraryowners. Explicitnodevisitedset terminatesfinitefunction/classcycles; allaliasedgesstillrecorded.'},
  {'finding':'Baselineprotection','argument':'Seal.rows/owners areordinaryRootownedattributes, notimmutableorhostileintrospectionsecurity. Rootmustretainandprotectthebaseline; noarbitrarymutation/concurrency sandbox isclaimed.'},
  {'finding':'Costs','argument':'ThisaddedownergraphtraversalcostsCPU/memory andretention; noRootcallbackcredit, fit, fullG1schema orruntimequalification follows.'}],
 'all20_recipes_unrun':True,'whole_15_33_28_55_qualification_not_substituted':True,
 'unfixed_remaining':'Graphsnapshotshape02aa31negative persists becausev2changesonlyworkerownerfunction/version. Fullproducer/schema/events/outeradmission/resourcefit review remains incomplete/open.',
 'static_metadata':static,'checks':checks,'failed_checks':[],
 'G1_adopted':False,'old_G0_negative_unchanged':True,'runtime_qualified':False,
 'full_VM_qualified':False,'new_theorem':False,'GCTS_RL_advantage_established':False,'goal_status':'active',
 'subject_imports':0,'subject_calls':0,'helper_calls':0,'compiler_calls':0,'checker_calls':0,
 'fixture_calls':0,'mutation_fixture_calls':0,'simulator_calls':0,'sizing_probes':0,'semantic_replays':0,
 'partial_files_opened':0,'new_actuals':0,'new_grants':0,'actual_execution_authorized':False,
 'author':pin(Path(__file__)),'frozen_v1_mutated':False,'primary_reader_index_active_mutated':False,
 'tools_stopped_after_freeze':True}
p=O/'typed-linked-named-custody-v2-Source-delta-review-v1.json';need('fresh-review',not p.exists())
p.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n');print(json.dumps({'review':pin(p),'checks':len(checks)},sort_keys=True))
