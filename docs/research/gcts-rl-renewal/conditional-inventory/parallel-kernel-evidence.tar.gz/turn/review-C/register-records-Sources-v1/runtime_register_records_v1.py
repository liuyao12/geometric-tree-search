"""Unexecuted linked physical register reads/writes, not a VM controller.

Client uses the pinned common Builder. Register indices and reference values
are unbounded binary tape words, never Source arguments/state indices. No host
fetch, array update, parser, arithmetic or inference action occurs in delta.
"""
VERSION='linked-physical-register-records-v1'
REGISTERS=4
INDEX=8                 # DESTINATION: canonical binary register index.
VALUE=11                # RETURN_VALUE: read output / write input reference.
COUNT=12
BUFFER=14               # PARSER_STACK: destructive write transaction buffer.

def _zero(m,band,out,name):
    write=m.row(band,{'B':(out,'0',0)},name+'/write')
    return m.clear_word(band,write,name+'/clear')

def _skip_field(m,out,invalid,name):
    q=m.state(name)
    m.put(q,REGISTERS,{'0':(q,'0',1),'1':(q,'1',1),';':(out,';',1),':':(invalid,':',0)})
    return q

def _clear_records(m,band,out,name):
    q=m.state(name+'/erase');done=m.rewind(band,out,name+'/done')
    choices={s:(q,'B',1)for s in('0','1',';')}
    choices.update({':':(done,'B',0),'B':(done,'B',0)})
    m.put(q,band,choices)
    return m.rewind(band,q,name+'/start')

def register_read(m,out,invalid,name):
    """Input INDEX, output VALUE; clobber COUNT, preserve full record payload.

    R is ^ref;...:B...#, each ref nonempty canonical existing value. INDEX is
    canonical binary. Absent index takes supplied invalid port. Complete
    program/register invariants remain client obligations, not host filters.
    """
    loop=m.state(name+'/field-read')
    finish=m.rewind(VALUE,out,name+'/value-rewind')
    choices={';':(finish,';',0),':':(invalid,':',0)}
    for bit in('0','1'):
        put=m.row(VALUE,{'B':(loop,bit,1)},name+'/copy-'+bit)
        choices[bit]=(put,bit,1)
    m.put(loop,REGISTERS,choices)
    nonempty=m.row(REGISTERS,{'0':(loop,'0',0),'1':(loop,'1',0),':':(invalid,':',0)},name+'/nonempty')
    found=m.clear_word(VALUE,nonempty,name+'/clear-value')
    compare=m.state(name+'/compare-entry')
    increment=m.increment_word(COUNT,compare,name+'/increment')
    skip=_skip_field(m,increment,invalid,name+'/skip')
    test=m.compare_words(COUNT,INDEX,found,skip,name+'/index')
    m.put(compare,COUNT,{'0':(test,'0',0),'1':(test,'1',0)})
    begin=m.rewind(REGISTERS,compare,name+'/records')
    return _zero(m,COUNT,begin,name+'/counter')

def register_write(m,out,invalid,name):
    """Replace one existing register from VALUE; INDEX/VALUE are preserved.

    INDEX and VALUE are canonical nonempty words. BUFFER is blank or a
    colon-terminated record vector; COUNT and BUFFER are clobbered. The whole
    finite record vector is copied
    physically to BUFFER with one replacement, then committed back. Failure
    may leave a transaction prefix and cannot yield admission. This is not an
    atomic/rollback instruction or a host array-update primitive.
    """
    # Commit copies only a fully produced colon-terminated buffer.
    done=m.rewind(REGISTERS,out,name+'/done-registers')
    finish=_clear_records(m,BUFFER,done,name+'/clear-buffer-after')
    commit=m.state(name+'/commit-read')
    end=m.row(REGISTERS,{'B':(finish,':',0)},name+'/commit-end')
    choices={':':(end,':',0)}
    for symbol in('0','1',';'):
        write=m.row(REGISTERS,{'B':(commit,symbol,1)},name+'/commit-write-'+symbol)
        choices[symbol]=(write,symbol,1)
    m.put(commit,BUFFER,choices)
    buffer_start=m.rewind(BUFFER,commit,name+'/commit-buffer-rewind')
    commit_start=_clear_records(m,REGISTERS,buffer_start,name+'/erase-old-vector')

    # Once the requested field was replaced, copy the entire untouched suffix.
    suffix=m.state(name+'/suffix-read')
    close=m.row(BUFFER,{'B':(commit_start,':',0)},name+'/close-buffer')
    choices={':':(close,':',0)}
    for symbol in('0','1',';'):
        write=m.row(BUFFER,{'B':(suffix,symbol,1)},name+'/suffix-write-'+symbol)
        choices[symbol]=(write,symbol,1)
    m.put(suffix,REGISTERS,choices)

    # Append VALUE at the current buffer end, then continue suffix copying.
    value=m.state(name+'/replacement-read')
    terminate=m.row(BUFFER,{'B':(suffix,';',1)},name+'/replacement-delimiter')
    choices={'B':(terminate,'B',0)}
    for bit in('0','1'):
        write=m.row(BUFFER,{'B':(value,bit,1)},name+'/replacement-write-'+bit)
        choices[bit]=(write,bit,1)
    m.put(value,VALUE,choices)
    replacement=m.rewind(VALUE,value,name+'/replacement-rewind')
    skip_old=_skip_field(m,replacement,invalid,name+'/skip-old-field')

    # Prefix fields are retained verbatim while COUNT searches INDEX.
    compare=m.state(name+'/compare-entry')
    increment=m.increment_word(COUNT,compare,name+'/increment')
    prefix=m.state(name+'/prefix-read')
    delimiter=m.row(BUFFER,{'B':(increment,';',1)},name+'/prefix-delimiter')
    choices={';':(delimiter,';',1),':':(invalid,':',0)}
    for bit in('0','1'):
        write=m.row(BUFFER,{'B':(prefix,bit,1)},name+'/prefix-write-'+bit)
        choices[bit]=(write,bit,1)
    m.put(prefix,REGISTERS,choices)
    test=m.compare_words(COUNT,INDEX,skip_old,prefix,name+'/index')
    m.put(compare,COUNT,{'0':(test,'0',0),'1':(test,'1',0)})
    begin=m.rewind(REGISTERS,compare,name+'/records')
    counter=_zero(m,COUNT,begin,name+'/counter')
    return _clear_records(m,BUFFER,counter,name+'/clear-buffer-before')
