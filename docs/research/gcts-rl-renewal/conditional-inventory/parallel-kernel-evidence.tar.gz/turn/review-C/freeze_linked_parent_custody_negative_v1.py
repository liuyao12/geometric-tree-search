"""Freeze an early Source blocker without executing any offered component."""
import ast
import hashlib
import json
from pathlib import Path
N=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-linked-evidence-20261020')
O=N/'review-C';B=N/'schema-B';C=O/'linked-parent-negative-preimages-v1';C.mkdir(exist_ok=True)
checks=[];pins=[]
def need(n,v):
    checks.append({'check':n,'passed':bool(v)})
    if not v:raise ValueError(n)
def pin(p):
    b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
hraw=(B/'handoff-v1.json').read_bytes()
need('exact-frozen-offer',len(hraw)==26901 and hashlib.sha256(hraw).hexdigest()=='24fc6d6463bec5935cf92004ba16e3514d983896f212be149d4d3bf62940607b')
h=json.loads(hraw)
for row in h['artifacts']:
    p=Path(row['path']);need('not-partial:'+p.name,'.partial' not in p.name)
    raw=p.read_bytes();need('exact:'+p.name,len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256'])
    dst=C/p.name;need('fresh:'+p.name,not dst.exists());dst.write_bytes(raw);pins.append(pin(dst))
dst=C/'handoff-v1.json';need('fresh-handoff-copy',not dst.exists());dst.write_bytes(hraw)
old=Path(h['dependencies']['predecessor_worker']['path']);oldraw=old.read_bytes();r=h['dependencies']['predecessor_worker']
need('old-worker-exact',len(oldraw)==r['bytes'] and hashlib.sha256(oldraw).hexdigest()==r['sha256'])
dst=C/'predecessor-worker-9ea014.py';need('fresh-old',not dst.exists());dst.write_bytes(oldraw)
newraw=(C/'qualify_linked_batch_worker_v1.py').read_bytes()
ot=ast.parse(oldraw);nt=ast.parse(newraw);ft=ast.parse((C/'worker_integration_v1.fragment.py').read_bytes())
compile(nt,'newworker','exec');compile(ft,'newfragment','exec')
of=next(n for n in ot.body if isinstance(n,ast.FunctionDef)and n.name=='function_owner_seal')
nf=next(n for n in nt.body if isinstance(n,ast.FunctionDef)and n.name=='_recursive_function_owner_seal')
ng=next(n for n in nt.body if isinstance(n,ast.FunctionDef)and n.name=='_original_qualify_graph')
facade=next(n for n in ng.body if isinstance(n,ast.ClassDef)and n.name=='Facade')
need('exact-dynamic-Facade-methods',[n.name for n in facade.body if isinstance(n,ast.FunctionDef)]==['count_query','select_query'])
oldtext=ast.get_source_segment(oldraw.decode(),of);newtext=ast.get_source_segment(newraw.decode(),nf)
need('old-seal-named-class-members','for name,item in sorted(vars(content).items())' in oldtext and '(name,id(item)' in oldtext)
need('new-seal-only-class-member-values','for member in vars(content).values()' in newtext and 'return tuple(sorted(rows))' in newtext)
need('graph-body-uses-captured-Facade',any(isinstance(n,ast.Name)and n.id=='Facade'for n in ast.walk(next(n for n in ng.body if isinstance(n,ast.FunctionDef)and n.name=='graph_body'))))
finding={
 'id':'LINKED_CLASS_BINDING_SEAL_REGRESSION',
 'severity':'BLOCKING_EXACT_CUSTODY_QUALIFICATION',
 'source':pin(C/'qualify_linked_batch_worker_v1.py'),
 'function':{'name':nf.name,'line':nf.lineno,'end':nf.end_lineno},
 'dynamic_class':{'name':'Facade','line':facade.lineno,'end':facade.end_lineno},
 'predecessor_function':{'name':of.name,'line':of.lineno,'end':of.end_lineno},
 'claim':'The recursive successor seals the set of functions reachable through a captured class, but no longer seals class member names or descriptor associations. Swapping two existing class methods leaves every recursively recorded function row and class closure-cell identity unchanged.',
 'manual_derivation':[
  'A captured class contributes only its class object identity as closure content; its member functions are added to a traversal worklist via vars(class).values().',
  'The traversal emits rows keyed by function identity/code/default/kwdefault/closure/cells and sorts the final rows. It records neither member name nor descriptor kind or name-to-function edge.',
  'Swap C.count_query and C.select_query while retaining both function objects. The class object identity and function set/rows remain unchanged, even though attribute lookup bindings differ.',
  'The predecessor separately recorded sorted(name,id(function),...) tuples for a captured class. Those named tuples change under the swap.',
  'Frozen worker actually creates local Facade with these two methods and captures it in graph_body/search lambda. It is not a module-owned class whose mapping is independently covered by the module callable_seal.'],
 'exact_predecessor_Source':oldtext,'exact_successor_Source':newtext,
 'unrun_counterexample_recipe':[
  'Inside a prospective test exposing the actual closure-owned Facade and graph_body, compute the successor seal before mutation.',
  'Retain a=Facade.count_query and b=Facade.select_query; set Facade.count_query=b and Facade.select_query=a.',
  'Compute the successor seal again: direct Source calculation predicts equality. The old named class-member seal predicts inequality.',
  'Exercise the actual whole Root guard/custody path at the mutation checkpoint. Qualification requires an independently latched integrity fault before any planned sentinel classification.',
  'Retain original class/function/rawowner identities and full negative prefix; do not promote a callback failure, arity failure or restored class to successful custody evidence.'],
 'required_successor':'Retain recursive helper closure coverage while also sealing each captured class named member association and descriptor type/function binding (including non-function members if claimed), then extend unrun whole custody recipes. Preserve exact frozen v1.',
 'scope_limit':'This is an integrity-seal counterexample, not an observed accepted false mathematical proof or a runtime claim. Swapped actual methods may independently fail arity/semantic checks; that does not establish the missing exact custody invariant.',
 'executed':False,'offered_files_mutated':False}
out={
 'schema':'typed-linked-parent-Source-custody-negative-v1','reviewer_identity':'/root/recovered_batch_review',
 'status':'FAIL_SOURCE_CUSTODY_REGRESSION','review_passed':False,
 'source_only':True,'full_review_completed':False,
 'review_scope':'Early blocking finding while reviewing complete frozen parent/worker offer. No full-schema, event-completeness, whole-harness or resource-fit PASS is claimed.',
 'offer':pin(C/'handoff-v1.json'),'raw_preimages':pins,
 'predecessor_worker':pin(C/'predecessor-worker-9ea014.py'),
 'finding':finding,'failed_requirements':['S17_RUNTIME_CUSTODY_EXACT_CLASS_MEMBER_BINDINGS'],
 'static_metadata':{'AST_parses':3,'unused_compiles':2,'research_code_executed':False},
 'checks':checks,'failed_static_metadata_checks':[],
 'G1_adopted':False,'old_G0_negative_unchanged':True,'goal_status':'active',
 'actual_execution_authorized':False,'new_grants':0,'new_actuals':0,
 'subject_imports':0,'subject_calls':0,'helper_calls':0,'compiler_calls':0,'checker_calls':0,
 'fixture_calls':0,'simulator_calls':0,'sizing_probes':0,'semantic_replays':0,'partial_files_opened':0,
 'author':pin(Path(__file__)),'frozen_files_mutated':False,
 'primary_reader_index_active_mutated':False,'tools_stopped_after_freeze':True}
p=O/'typed-linked-parent-Source-custody-negative-v1.json';need('fresh-negative',not p.exists())
p.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n');print(json.dumps({'negative':pin(p),'raw_preimages':len(pins),'checks':len(checks)},sort_keys=True))
