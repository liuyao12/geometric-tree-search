"""Publication metadata author only; never imports or calls research Sources."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

BASE=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
TURN=BASE/'research-runs/gcts-linked-evidence-20261020'
ROOT=TURN/'root'
PUB=BASE/'research-runs/gcts-batch-20261020/publisher'
DEST=PUB/'docs/research/gcts-rl-renewal/conditional-inventory'

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def pin(path):
    raw=path.read_bytes()
    return {'path':str(path),'bytes':len(raw),'sha256':digest(raw)}

def emit(name,value):
    raw=(json.dumps(value,ensure_ascii=True,indent=2,sort_keys=True)+'\n').encode()
    path=DEST/name
    if path.exists():
        raise ValueError('publication successor must preserve frozen asset: '+name)
    path.write_bytes(raw)
    return pin(path)

notes=json.loads((ROOT/'publication-notes-v1.json').read_bytes())
assert notes['source_only'] is True and notes['new_actuals']==0
assert notes['new_grants']==0 and notes['subject_calls']==0
reader=DEST/'reader.html'
before=reader.read_bytes()
assert digest(before)=='cc59def2227bf3597fdeb8a0168cb62947eb4d38f0a3a24af8c1f3bd4ad13e4e'
(ROOT/'reader-preimage-v1.html').write_bytes(before)
copies=notes['copied_reviews']
assets=[]
for name,source in copies.items():
    path=Path(source)
    raw=path.read_bytes()
    target=DEST/name
    if target.exists():
        raise ValueError('published asset already exists: '+name)
    target.write_bytes(raw)
    assets.append(pin(target))

matrix=json.loads((TURN/'review-C/complete-function-rule-obligation-matrix-v1.json').read_bytes())
audit=json.loads((TURN/'review-C/independent-full-common-kernel-Source-audit-v1.json').read_bytes())
assert matrix['function_count']==128 and matrix['rule_count']==11
assert len(matrix['rules'])==11
data={'schema':'parallel-common-kernel-report-data-v1','source_only':True,
      'new_actuals':0,'matrix':matrix,'findings':audit['findings'],
      'source_audit_status':audit['status'],'notes':notes}
assets.append(emit('parallel-kernel-data.json',data))

html=(ROOT/'parallel-kernel-draft.html').read_text()
for token,key in [('PHYSICAL_NOTES','physical_html'),('EVIDENCE_NOTES','evidence_html'),
                  ('ADDITIONAL_EVIDENCE','additional_evidence_html')]:
    marker='<!-- '+token+' -->'
    assert html.count(marker)==1
    html=html.replace(marker,notes[key])
assert '<!-- ' not in html
page=DEST/'parallel-kernel.html'
assert not page.exists()
page.write_text(html)
assets.append(pin(page))

members=[]
for path in sorted(TURN.rglob('*')):
    if not path.is_file():
        continue
    if '.partial' in path.name:
        raise ValueError('partial excluded before byte read')
    if path.suffix=='.png' or path.name.startswith('parallel-kernel-evidence'):
        continue
    if path.name in {'publication-asset-freeze-v1.json','archive-member-manifest-v1.json'}:
        continue
    members.append((str(Path('turn')/path.relative_to(TURN)),path))
for name,source in notes['external_sources'].items():
    path=Path(source)
    assert '.partial' not in path.name
    members.append((str(Path('dependencies')/name),path))
assert len({name for name,path in members})==len(members)
member_pins=[]
for name,path in members:
    item=pin(path)
    item['member']=name
    member_pins.append(item)
member_manifest={'schema':'parallel-kernel-archive-members-v1',
                 'source_only_current_turn':True,'new_actuals':0,'members':member_pins}
manifest_raw=(json.dumps(member_manifest,ensure_ascii=True,indent=2,sort_keys=True)+'\n').encode()
(ROOT/'archive-member-manifest-v1.json').write_bytes(manifest_raw)
archive=DEST/'parallel-kernel-evidence.tar.gz'
assert not archive.exists()
with archive.open('wb') as handle:
    with gzip.GzipFile(filename='',mode='wb',fileobj=handle,mtime=0) as zipped:
        with tarfile.open(fileobj=zipped,mode='w|',format=tarfile.PAX_FORMAT) as bundle:
            for name,path in members:
                raw=path.read_bytes()
                record=next(item for item in member_pins if item['member']==name)
                assert digest(raw)==record['sha256'] and len(raw)==record['bytes']
                info=tarfile.TarInfo(name)
                info.size=len(raw);info.mode=0o644;info.mtime=0
                bundle.addfile(info,io.BytesIO(raw))
            info=tarfile.TarInfo('archive-member-manifest-v1.json')
            info.size=len(manifest_raw);info.mode=0o644;info.mtime=0
            bundle.addfile(info,io.BytesIO(manifest_raw))
assets.append(pin(archive))
summary={k:v for k,v in notes.items() if k not in
         ('physical_html','evidence_html','additional_evidence_html','external_sources')}
summary.update(schema='parallel-common-kernel-milestone-v1',goal_status='active',
               full_physical_VM_qualified=False,new_theorem=False,
               trained_RL=False,GCTS_RL_advantage_established=False,
               G1_adopted=False,all_new_diagnostics_unrun=True,
               scientific_imports=0,table_generations=0,simulations=0,
               original_caps_unchanged=True,partial_files_opened=0,
               archive=pin(archive),archive_member_count=len(members)+1)
assets.append(emit('parallel-kernel-summary.json',summary))

card=(r'<section id="parallel-kernel-update"><p class="eyebrow">20 OCTOBER 2026 · PARALLEL SOURCE RESEARCH</p>'
      r'<h2>A complete kernel audit and physical linkage.</h2><p>Separate agents audited all \(128\) functions and '
      r'\(11\) rules, developed actual-value and call machinery, and found interface and evidence defects before '
      r'execution. The report explains why a lemma must retain its theory and lets you read every rule in formulas '
      r'and words. This is Source work with no new run, discovered theorem or GCTS/RL advantage. '
      r'<a href="parallel-kernel.html#outcome"><b>Read the milestone</b></a> · '
      r'<a href="parallel-kernel.html#inventory">Inspect lemma scope</a> · '
      r'<a href="parallel-kernel.html#rules">Read the rules</a>.</p></section>\n').replace('\\n','\n').encode()
needle=b'<section id="physical-lexicon-update">'
assert before.count(needle)==1
after=before.replace(needle,card+needle,1)
assert after.replace(card,b'',1)==before
reader.write_bytes(after)
assets.append(pin(reader))
manifest={'schema':'parallel-kernel-publication-manifest-v1',
          'source_only':True,'new_actuals':0,'goal_status':'active',
          'assets':assets,'archive_member_manifest_sha256':digest(manifest_raw),
          'reader_preimage':pin(ROOT/'reader-preimage-v1.html'),
          'reader_card_bytes':len(card),'reader_card_sha256':digest(card),
          'pending_separate_asset':'parallel-kernel-publication-review.json',
          'scientific_execution_authorized':False}
assets.append(emit('parallel-kernel-manifest.json',manifest))
freeze={'schema':'parallel-kernel-asset-freeze-v1','assets':assets,
        'subject_calls':0,'publication_only':True}
(ROOT/'publication-asset-freeze-v1.json').write_text(json.dumps(freeze,indent=2,sort_keys=True)+'\n')
print(json.dumps({'assets':len(assets),'archive_members':len(members)+1,
                  'archive_bytes':archive.stat().st_size,'page':str(page)}))
