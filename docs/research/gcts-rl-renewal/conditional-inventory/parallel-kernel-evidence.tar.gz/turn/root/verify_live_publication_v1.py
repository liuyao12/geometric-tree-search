"""Passive publication verification: complete ordinary HTTPS response bodies."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parent
BASE=ROOT.parents[2]
DEST=BASE/'research-runs/gcts-batch-20261020/publisher/docs/research/gcts-rl-renewal/conditional-inventory'
assert len(sys.argv)==2
commit=sys.argv[1]
assert len(commit)==40 and all(c in '0123456789abcdef' for c in commit)
URL='https://liuyao12.github.io/geometric-tree-search/docs/research/gcts-rl-renewal/conditional-inventory/'
outdir=ROOT/'live-parallel-kernel-v1'
outdir.mkdir()
manifest=json.loads((DEST/'parallel-kernel-manifest.json').read_bytes())
names=[Path(item['path']).name for item in manifest['assets']]
names+=['parallel-kernel-manifest.json','parallel-kernel-publication-review.json']
assert len(names)==len(set(names))

def fetch(name):
    expected=(DEST/name).read_bytes()
    target=outdir/name
    url=URL+name+'?v='+commit
    command=['/usr/bin/curl','--fail','--silent','--show-error','--location',
             '--max-time','45','--proto','=https','--tlsv1.2',
             '--output',str(target),'--write-out','%{http_code}\n%{url_effective}\n',url]
    process=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False)
    raw=target.read_bytes() if target.is_file() else b''
    return dict(file=name,url=url,curl_exit=process.returncode,
                http_metadata=process.stdout.decode(),stderr=process.stderr.decode(),
                bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),
                local_bytes=len(expected),local_sha256=hashlib.sha256(expected).hexdigest(),
                full_body_equal=raw==expected)

with ThreadPoolExecutor(max_workers=4) as pool:
    rows=list(pool.map(fetch,names))
passed=all(item['curl_exit']==0 and item['http_metadata'].startswith('200\n')
           and item['full_body_equal'] for item in rows)
receipt=dict(schema='parallel-kernel-full-live-publication-verification-v1',
             commit=commit,observed_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
             normal_TLS=True,certificate_verification_disabled=False,
             files=rows,all_full_bodies_equal=passed,subject_calls=0)
target=ROOT/'live-full-body-verification-v1.json'
assert not target.exists()
target.write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(receipt=str(target),files=len(rows),all_full_bodies_equal=passed)))
raise SystemExit(0 if passed else 2)
