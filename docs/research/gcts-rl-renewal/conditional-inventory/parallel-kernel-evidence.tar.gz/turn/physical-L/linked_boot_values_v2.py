"""Source-only shared16-band literal microcode for linked BOOT values.

No table generation or component call occurred. All construction functions below
emit only m.state/m.put/m.row/rewind/clear_word phases for Root's shared lowerer.
There is no host heap operation or semantic transition callback. The semantic
validator is a physical task stack, with linked heap lookups and key frames.
Root's program/seed/layout intake and the complete VM remain separate duties.
"""
VERSION = 'linked-boot-tagged-values-v2'
RAW = ('B', '^', '0', '1', ':', ',', ';', '|', '!', '#')
WORKSPACE = ('PROGRAM','PUBLIC','CERTIFICATE','HEAP','REGISTERS','FRAMES',
             'FUNCTION','PC','DESTINATION','LEFT_VALUE','RIGHT_VALUE',
             'RETURN_VALUE','COUNT','TEMPORARY','PARSER_STACK','OUTPUT')
HEAP=3
LEFT=9
RIGHT=10
RETURN=11
COUNT=12
TEMP=13
STACK=14
TASKS=4
FRAMES=5
OUTPUT=15


def _put(m,q,band,choices,invalid):
    expanded={}
    for symbol in RAW:
        if symbol!='#':
            expanded[symbol]=choices.get(symbol,(invalid,symbol,0))
    m.put(q,band,expanded)


def _row(m,band,choices,invalid,name):
    q=m.state(name)
    _put(m,q,band,choices,invalid)
    return q


def _constant(m,band,bits,out,invalid,name):
    # Every bits argument is a fixed Source constant, never a runtime word.
    nextq=out
    for j in range(len(bits)-1,-1,-1):
        nextq=_row(m,band,{'B':(nextq,bits[j],1)},invalid,name+'/bit'+str(j))
    return m.clear_word(band,nextq,name+'/clear')


def _copy(m,src,dst,out,invalid,name):
    loop=m.state(name+'/read')
    finish=m.rewind(dst,out,name+'/rewind-result')
    choices={'B':(finish,'B',0)}
    for bit in ('0','1'):
        write=_row(m,dst,{'B':(loop,bit,1)},invalid,name+'/write'+bit)
        choices[bit]=(write,bit,1)
    _put(m,loop,src,choices,invalid)
    read=m.rewind(src,loop,name+'/rewind-source')
    return m.clear_word(dst,read,name+'/clear-result')


def _increment(m,band,out,invalid,name):
    carry=m.state(name+'/carry')
    finish=m.rewind(band,out,name+'/rewind')
    _put(m,carry,band,{'0':(finish,'1',0),'1':(carry,'0',1),
                     'B':(finish,'1',0)},invalid)
    return m.rewind(band,carry,name+'/start')


def _canonical_word(m,band,out,invalid,name):
    first=m.state(name+'/first')
    firstzero=m.state(name+'/first-zero')
    lastzero=m.state(name+'/last-zero')
    lastone=m.state(name+'/last-one')
    _put(m,first,band,{'0':(firstzero,'0',1),'1':(lastone,'1',1)},invalid)
    _put(m,firstzero,band,{'B':(out,'B',0),'0':(lastzero,'0',1),
                         '1':(lastone,'1',1)},invalid)
    _put(m,lastzero,band,{'0':(lastzero,'0',1),'1':(lastone,'1',1)},invalid)
    _put(m,lastone,band,{'0':(lastzero,'0',1),'1':(lastone,'1',1),
                       'B':(out,'B',0)},invalid)
    return m.rewind(band,first,name+'/start')


def _atom_or_node(m,band,atom,node,invalid,name):
    states={}
    for j in range(9):
        for nonzero in (False,True):
            states[j,nonzero]=m.state(name+'/'+str(j)+'/'+str(int(nonzero)))
    end=_row(m,band,{'B':(atom,'B',0),'0':(node,'0',0),
                     '1':(node,'1',0)},invalid,name+'/exact256-end')
    for j in range(9):
        for nonzero in (False,True):
            choices={}
            if j:
                choices['B']=(atom,'B',0)
            if j<8:
                for bit in (0,1):
                    s='1' if bit else '0'
                    choices[s]=(states[j+1,nonzero or bool(bit)],s,1)
            else:
                choices['0']=(node,'0',0)
                choices['1']=(node if nonzero else end,'1',0 if nonzero else 1)
            _put(m,states[j,nonzero],band,choices,invalid)
    # Canonical-word validation is deliberately separate and precedes this test.
    return m.rewind(band,states[0,False],name+'/start')


def _compare_words(m,left,right,yes,no,invalid,name):
    loop=m.state(name+'/left')
    end=_row(m,right,{'B':(yes,'B',0),'0':(no,'0',0),
                     '1':(no,'1',0)},invalid,name+'/exact-end')
    choices={'B':(end,'B',0)}
    for bit in ('0','1'):
        check={}
        for symbol in ('0','1','B'):
            check[symbol]=(loop,symbol,1) if symbol==bit else (no,symbol,0)
        q=_row(m,right,check,invalid,name+'/right'+bit)
        choices[bit]=(q,bit,1)
    _put(m,loop,left,choices,invalid)
    start=m.rewind(right,loop,name+'/rewind-right')
    return m.rewind(left,start,name+'/rewind-left')


def _next_heap_record(m,out,invalid,name):
    q=m.state(name+'/scan-semicolon')
    _put(m,q,HEAP,{'0':(q,'0',1),'1':(q,'1',1),',':(q,',',1),
                   ';':(out,';',1)},invalid)
    return q


def _compare_heap_field(m,word,end_symbol,yes,no,invalid,name):
    loop=m.state(name+'/read-heap')
    consume=_row(m,HEAP,{end_symbol:(yes,end_symbol,1)},invalid,name+'/consume-delimiter')
    exact=_row(m,word,{'B':(consume,'B',0),'0':(no,'0',0),
                       '1':(no,'1',0)},invalid,name+'/word-exact-end')
    choices={end_symbol:(exact,end_symbol,0)}
    for bit in ('0','1'):
        check={}
        for symbol in ('0','1','B'):
            check[symbol]=(loop,symbol,1) if symbol==bit else (no,symbol,0)
        q=_row(m,word,check,invalid,name+'/compare'+bit)
        choices[bit]=(q,bit,1)
    _put(m,loop,HEAP,choices,invalid)
    return m.rewind(word,loop,name+'/rewind-word')


def _copy_heap_field(m,dst,end_symbol,out,invalid,name):
    loop=m.state(name+'/read')
    finish=m.rewind(dst,out,name+'/rewind-result')
    choices={end_symbol:(finish,end_symbol,1)}
    for bit in ('0','1'):
        write=_row(m,dst,{'B':(loop,bit,1)},invalid,name+'/write'+bit)
        choices[bit]=(write,bit,1)
    _put(m,loop,HEAP,choices,invalid)
    return m.clear_word(dst,loop,name+'/clear-result')


def _write_word_here(m,src,dst,first_symbol,end_symbol,out,invalid,name):
    first=m.state(name+'/read-first')
    more=m.state(name+'/read-more')
    delimiter=_row(m,dst,{'B':(out,end_symbol,1)},invalid,name+'/write-delimiter')
    more_choices={'B':(delimiter,'B',0)}
    first_choices={}
    for bit in ('0','1'):
        initial=_row(m,dst,{first_symbol:(more,bit,1)},invalid,name+'/initial'+bit)
        following=_row(m,dst,{'B':(more,bit,1)},invalid,name+'/following'+bit)
        first_choices[bit]=(initial,bit,1)
        more_choices[bit]=(following,bit,1)
    _put(m,first,src,first_choices,invalid)
    _put(m,more,src,more_choices,invalid)
    return m.rewind(src,first,name+'/rewind-source')


def _valid_reference(m,word,out,invalid,name):
    scan=m.state(name+'/heap-record')
    advance=m.state(name+'/advance')
    nxt=_next_heap_record(m,advance,invalid,name+'/next')
    inc=_increment(m,COUNT,scan,invalid,name+'/increment-ID')
    _put(m,advance,HEAP,{'0':(inc,'0',0),'1':(inc,'1',0),
                       ':':(inc,':',0)},invalid)
    compare=_compare_words(m,word,COUNT,out,nxt,invalid,name+'/compare-ID')
    _put(m,scan,HEAP,{'0':(compare,'0',0),'1':(compare,'1',0),
                     ':':(invalid,':',0)},invalid)
    heap_start=m.rewind(HEAP,scan,name+'/rewind-heap')
    count_start=_constant(m,COUNT,'100000001',heap_start,invalid,name+'/ID257')
    classify=_atom_or_node(m,word,out,count_start,invalid,name+'/atom-or-node')
    return _canonical_word(m,word,classify,invalid,name+'/canonical')


def canonical_cons(m,out,invalid,name='canonical-cons'):
    """Preserve LEFT/RIGHT words; return canonical pair ID in RETURN.

    HEAP must be canonical/topological from validated immutable seed plus prior
    successful appends. Both operands are physically checked as valid refs.
    COUNT is clobbered; TEMP's contents are preserved by every phase here.
    """
    scan=m.state(name+'/scan-pair')
    advance=m.state(name+'/advance')
    inc=_increment(m,COUNT,scan,invalid,name+'/increment-ID')
    _put(m,advance,HEAP,{'0':(inc,'0',0),'1':(inc,'1',0),
                       ':':(inc,':',0)},invalid)
    skip=_next_heap_record(m,advance,invalid,name+'/skip-unmatched')
    found=_copy(m,COUNT,RETURN,out,invalid,name+'/return-existing-ID')
    right=_compare_heap_field(m,RIGHT,';',found,skip,invalid,name+'/right')
    left=_compare_heap_field(m,LEFT,',',right,skip,invalid,name+'/left')
    finish=_row(m,HEAP,{'B':(out,':',0)},invalid,name+'/append-used-end')
    append_right=_write_word_here(m,RIGHT,HEAP,'B',';',finish,invalid,name+'/append-right')
    append_left=_write_word_here(m,LEFT,HEAP,':',',',append_right,invalid,name+'/append-left')
    append=_copy(m,COUNT,RETURN,append_left,invalid,name+'/return-new-ID')
    _put(m,scan,HEAP,{'0':(left,'0',0),'1':(left,'1',0),
                     ':':(append,':',0)},invalid)
    start=m.rewind(HEAP,scan,name+'/rewind-heap')
    start=_constant(m,COUNT,'100000001',start,invalid,name+'/ID257')
    start=_valid_reference(m,RIGHT,start,invalid,name+'/validate-right')
    return _valid_reference(m,LEFT,start,invalid,name+'/validate-left')


def heap_lookup(m,out,invalid,name='heap-lookup'):
    """Preserve RETURN node ID; output pair children LEFT/RIGHT or invalid.

    Atoms and nonexistent IDs never pass. No host indexing/arithmetic executes
    in a transition. COUNT is the physically incremented current implicit ID.
    """
    scan=m.state(name+'/scan')
    advance=m.state(name+'/advance')
    inc=_increment(m,COUNT,scan,invalid,name+'/increment-ID')
    _put(m,advance,HEAP,{'0':(inc,'0',0),'1':(inc,'1',0),
                       ':':(inc,':',0)},invalid)
    skip=_next_heap_record(m,advance,invalid,name+'/skip')
    right=_copy_heap_field(m,RIGHT,';',out,invalid,name+'/copy-right')
    left=_copy_heap_field(m,LEFT,',',right,invalid,name+'/copy-left')
    compare=_compare_words(m,RETURN,COUNT,left,skip,invalid,name+'/compare-ID')
    _put(m,scan,HEAP,{'0':(compare,'0',0),'1':(compare,'1',0),
                     ':':(invalid,':',0)},invalid)
    start=m.rewind(HEAP,scan,name+'/rewind-heap')
    start=_constant(m,COUNT,'100000001',start,invalid,name+'/ID257')
    return _canonical_word(m,RETURN,start,invalid,name+'/canonical-ID')


def _clear_records(m,band,out,invalid,name):
    scan=m.state(name+'/erase')
    end=_row(m,band,{'B':(out,':',0)},invalid,name+'/new-used-end')
    finish=m.rewind(band,end,name+'/rewind')
    choices={':':(finish,'B',0)}
    for symbol in ('0','1',',',';'):
        choices[symbol]=(scan,'B',1)
    _put(m,scan,band,choices,invalid)
    return m.rewind(band,scan,name+'/start')


def stack_push(m,out,invalid,name='stack-push'):
    """Append canonical RETURN reference; preserve that reference's contents."""
    seek=m.state(name+'/seek-used-end')
    finish=_row(m,STACK,{'B':(out,':',0)},invalid,name+'/new-used-end')
    append=_write_word_here(m,RETURN,STACK,':',';',finish,invalid,name+'/append')
    choices={':':(append,':',0)}
    for symbol in ('0','1',';'):
        choices[symbol]=(seek,symbol,1)
    _put(m,seek,STACK,choices,invalid)
    return m.rewind(STACK,seek,name+'/start')


def stack_pop(m,destination,out,invalid,name='stack-pop'):
    """Remove last reference, preserving prior prefix; destructive on failure."""
    seek=m.state(name+'/seek-used-end')
    semicolon=m.state(name+'/last-semicolon')
    back=m.state(name+'/find-word-start')
    copy=m.state(name+'/copy-erase')
    restore=m.state(name+'/seek-first-erased')
    finish=m.rewind(destination,out,name+'/rewind-output')
    _put(m,restore,STACK,{'0':(restore,'0',1),'1':(restore,'1',1),
                         ';':(restore,';',1),'B':(finish,':',0)},invalid)
    rewind_restore=m.rewind(STACK,restore,name+'/restore-end')
    choices={':':(rewind_restore,'B',0)}
    for bit in ('0','1'):
        write=_row(m,destination,{'B':(copy,bit,1)},invalid,name+'/write'+bit)
        choices[bit]=(write,'B',1)
    _put(m,copy,STACK,choices,invalid)
    _put(m,back,STACK,{'0':(back,'0',-1),'1':(back,'1',-1),
                      ';':(copy,';',1),'^':(copy,'^',1)},invalid)
    _put(m,semicolon,STACK,{';':(back,':',-1)},invalid)
    choices={':':(semicolon,'B',-1)}
    for symbol in ('0','1',';'):
        choices[symbol]=(seek,symbol,1)
    _put(m,seek,STACK,choices,invalid)
    start=m.rewind(STACK,seek,name+'/start')
    return m.clear_word(destination,start,name+'/clear-output')


def _read_atom9(m,source,out,invalid,name):
    states={}
    for j in range(9):
        for nonzero in (False,True):
            states[j,nonzero]=m.state(name+'/'+str(j)+'/'+str(int(nonzero)))
    trim=m.state(name+'/trim-high-zeros')
    finish=m.rewind(RETURN,out,name+'/rewind-result')
    zero=_row(m,RETURN,{'B':(finish,'0',0)},invalid,name+'/canonical-zero')
    _put(m,trim,RETURN,{'0':(trim,'B',-1),'1':(finish,'1',0),
                       '^':(zero,'^',1)},invalid)
    to_trim=_row(m,RETURN,{'B':(trim,'B',-1)},invalid,name+'/start-trim')
    for j in range(9):
        for nonzero in (False,True):
            choices={}
            for bit in (0,1):
                symbol='1' if bit else '0'
                if j==8 and bit and nonzero:
                    choices[symbol]=(invalid,symbol,0)
                    continue
                nxt=to_trim if j==8 else states[j+1,nonzero or bool(bit)]
                put=_row(m,RETURN,{'B':(nxt,symbol,1)},invalid,name+'/write'+str(j)+'/'+str(int(nonzero))+'/'+symbol)
                choices[symbol]=(put,symbol,1)
            _put(m,states[j,nonzero],source,choices,invalid)
    return m.clear_word(RETURN,states[0,False],name+'/clear-result')


def postfix_roots(m,source,root_count,out,invalid,name='postfix-roots'):
    """Fixed callsites PUBLIC3/CERTIFICATE2 only; not complete tagged BOOT.

    Parses real references through canonical_cons, retaining exact roots in
    PARSER_STACK. PUBLIC/CERTIFICATE data are only read with unchanged symbols.
    Semantic tagged-value/UTF8/key validation and copying public roots before
    reusing the stack are caller obligations explicitly not implemented here.
    """
    if type(source) is not int or type(root_count) is not int or (source,root_count) not in ((1,3),(2,2)):
        raise ValueError('fixed PUBLIC/CERTIFICATE root-mode callsites only')
    token=m.state(name+'/token')
    padding=m.state(name+'/padding')
    counts=[]
    for j in range(root_count+1):
        counts.append(m.state(name+'/root-count'+str(j)))
    atom_done=stack_push(m,token,invalid,name+'/atom-push')
    atom=_read_atom9(m,source,atom_done,invalid,name+'/atom')
    cons_done=stack_push(m,token,invalid,name+'/cons-push')
    cons=canonical_cons(m,cons_done,invalid,name+'/canonical-cons')
    pop_left=stack_pop(m,LEFT,cons,invalid,name+'/pop-left')
    pop_right=stack_pop(m,RIGHT,pop_left,invalid,name+'/pop-right')
    _put(m,token,source,{'0':(atom,'0',1),'1':(pop_right,'1',1),
                       ';':(m.rewind(STACK,counts[0],name+'/count-start'),';',1)},invalid)
    for j in range(root_count):
        _put(m,counts[j],STACK,{'0':(counts[j],'0',1),'1':(counts[j],'1',1),
                              ';':(counts[j+1],';',1)},invalid)
    _put(m,counts[root_count],STACK,{':':(padding,':',0)},invalid)
    _put(m,padding,source,{'B':(padding,'B',1),':':(out,':',0)},invalid)
    begin=m.rewind(source,token,name+'/rewind-immutable-source')
    return _clear_records(m,STACK,begin,invalid,name+'/clear-stack')


def install_postfix_pair(m,public_out,free_out,invalid,name='postfix-pair'):
    """Install both fixed bodies; Root owns their sequencing/copy/validation."""
    public=postfix_roots(m,1,3,public_out,invalid,name+'/PUBLIC3')
    free=postfix_roots(m,2,2,free_out,invalid,name+'/CERTIFICATE2')
    return dict(PUBLIC3=public,CERTIFICATE2=free,full_BOOT=False,
                tagged_value_validation=False,request_assembly=False)


def _word_is(m,band,bits,yes,no,invalid,name):
    """Compare a canonical word with one fixed Source word, preserving bytes."""
    end=_row(m,band,{'B':(yes,'B',0),'0':(no,'0',0),
                     '1':(no,'1',0)},invalid,name+'/end')
    nxt=end
    for j in range(len(bits)-1,-1,-1):
        choices={s:((nxt,s,1) if s==bits[j] else (no,s,0))
                 for s in ('0','1','B')}
        nxt=_row(m,band,choices,invalid,name+'/bit'+str(j))
    return m.rewind(band,nxt,name+'/start')


def _push_word_to(m,band,source,out,invalid,name):
    """Append a canonical word to a private physical record stack."""
    seek=m.state(name+'/seek')
    end=_row(m,band,{'B':(out,':',0)},invalid,name+'/new-end')
    append=_write_word_here(m,source,band,':',';',end,invalid,name+'/append')
    choices={':':(append,':',0)}
    for symbol in ('0','1',';','|'):
        choices[symbol]=(seek,symbol,1)
    _put(m,seek,band,choices,invalid)
    return m.rewind(band,seek,name+'/start')


def _pop_word_from(m,band,destination,out,invalid,name):
    """Pop a private word record; empty stack rejects without a host test."""
    seek=m.state(name+'/seek')
    semicolon=m.state(name+'/semicolon')
    back=m.state(name+'/back')
    copy=m.state(name+'/copy')
    restore=m.state(name+'/restore')
    finish=m.rewind(destination,out,name+'/result')
    _put(m,restore,band,{'0':(restore,'0',1),'1':(restore,'1',1),
                       ';':(restore,';',1),'B':(finish,':',0)},invalid)
    rewind_restore=m.rewind(band,restore,name+'/restore-start')
    choices={':':(rewind_restore,'B',0)}
    for bit in ('0','1'):
        write=_row(m,destination,{'B':(copy,bit,1)},invalid,name+'/write'+bit)
        choices[bit]=(write,'B',1)
    _put(m,copy,band,choices,invalid)
    _put(m,back,band,{'0':(back,'0',-1),'1':(back,'1',-1),
                     ';':(copy,';',1),'^':(copy,'^',1)},invalid)
    _put(m,semicolon,band,{';':(back,':',-1)},invalid)
    choices={':':(semicolon,'B',-1)}
    for symbol in ('0','1',';'):
        choices[symbol]=(seek,symbol,1)
    _put(m,seek,band,choices,invalid)
    start=m.rewind(band,seek,name+'/start')
    return m.clear_word(destination,start,name+'/clear')


def _empty_records(m,band,out,invalid,name):
    check=_row(m,band,{':':(out,':',0)},invalid,name+'/colon')
    return m.rewind(band,check,name+'/start')


def _records_to_empty_word(m,band,out,invalid,name):
    check=_row(m,band,{':':(out,'B',0)},invalid,name+'/erase-colon')
    return m.rewind(band,check,name+'/start')


def _word_to_empty_records(m,band,out,invalid,name):
    put=_row(m,band,{'B':(out,':',0)},invalid,name+'/put-colon')
    return m.clear_word(band,put,name+'/clear-word')


def _copy_records_to_output(m,out,invalid,name):
    """Append STACK's full records, preserving their order and physical bytes."""
    seek=m.state(name+'/seek-output')
    first=m.state(name+'/first')
    more=m.state(name+'/more')
    finish=m.rewind(OUTPUT,out,name+'/output-start')
    first_choices={':':(finish,':',0)}
    more_choices={':':(_row(m,OUTPUT,{'B':(finish,':',0)},invalid,
                           name+'/write-end'),':',0)}
    for symbol in ('0','1',';'):
        initial=_row(m,OUTPUT,{':':(more,symbol,1)},invalid,
                     name+'/initial'+symbol)
        following=_row(m,OUTPUT,{'B':(more,symbol,1)},invalid,
                       name+'/following'+symbol)
        first_choices[symbol]=(initial,symbol,1)
        more_choices[symbol]=(following,symbol,1)
    _put(m,first,STACK,first_choices,invalid)
    _put(m,more,STACK,more_choices,invalid)
    read=m.rewind(STACK,first,name+'/source-start')
    choices={':':(read,':',0)}
    for symbol in ('0','1',';'):
        choices[symbol]=(seek,symbol,1)
    _put(m,seek,OUTPUT,choices,invalid)
    return m.rewind(OUTPUT,seek,name+'/start')


def _push_task(m,kind,source,out,invalid,name):
    """Task is two real records type;node; with the node on top."""
    if type(kind) is not int or kind not in (0,1,2):
        raise ValueError('fixed value/array-tail/object-tail task only')
    bits=('0','1','01')[kind]
    node=_push_word_to(m,TASKS,source,out,invalid,name+'/node')
    typ=_push_word_to(m,TASKS,COUNT,node,invalid,name+'/type')
    return _constant(m,COUNT,bits,typ,invalid,name+'/literal-type')


def _open_key_frame(m,out,invalid,name):
    seek=m.state(name+'/seek')
    end=_row(m,FRAMES,{'B':(out,':',0)},invalid,name+'/new-end')
    choices={':':(end,'|',1)}
    for symbol in ('0','1',';','|'):
        choices[symbol]=(seek,symbol,1)
    _put(m,seek,FRAMES,choices,invalid)
    return m.rewind(FRAMES,seek,name+'/start')


def _close_key_frame(m,out,invalid,name):
    seek=m.state(name+'/seek')
    erase=m.state(name+'/erase-current-frame')
    choices={'|':(out,':',0)}
    for symbol in ('0','1',';'):
        choices[symbol]=(erase,'B',-1)
    _put(m,erase,FRAMES,choices,invalid)
    choices={':':(erase,'B',-1)}
    for symbol in ('0','1',';','|'):
        choices[symbol]=(seek,symbol,1)
    _put(m,seek,FRAMES,choices,invalid)
    return m.rewind(FRAMES,seek,name+'/start')


def _unique_key_and_append(m,out,invalid,name):
    """Compare LEFT against all key refs in only the innermost object frame."""
    seek=m.state(name+'/seek-end')
    back=m.state(name+'/seek-frame')
    record=m.state(name+'/record')
    skip=m.state(name+'/skip-record')
    loop=m.state(name+'/compare')
    append_end=_row(m,FRAMES,{'B':(out,':',0)},invalid,name+'/new-end')
    append=_write_word_here(m,LEFT,FRAMES,':',';',append_end,invalid,name+'/append')
    _put(m,skip,FRAMES,{'0':(skip,'0',1),'1':(skip,'1',1),
                       ';':(record,';',1)},invalid)
    consume=_row(m,FRAMES,{';':(invalid,';',0)},invalid,name+'/duplicate')
    exact=_row(m,LEFT,{'B':(consume,'B',0),'0':(skip,'0',0),
                      '1':(skip,'1',0)},invalid,name+'/exact')
    choices={';':(exact,';',0)}
    for bit in ('0','1'):
        test=_row(m,LEFT,{s:((loop,s,1) if s==bit else (skip,s,0))
                         for s in ('0','1','B')},invalid,name+'/test'+bit)
        choices[bit]=(test,bit,1)
    _put(m,loop,FRAMES,choices,invalid)
    compare=m.rewind(LEFT,loop,name+'/key-start')
    _put(m,record,FRAMES,{'0':(compare,'0',0),'1':(compare,'1',0),
                         ':':(append,':',0)},invalid)
    _put(m,back,FRAMES,{'0':(back,'0',-1),'1':(back,'1',-1),
                       ';':(back,';',-1),'|':(record,'|',1)},invalid)
    choices={':':(back,':',-1)}
    for symbol in ('0','1',';','|'):
        choices[symbol]=(seek,symbol,1)
    _put(m,seek,FRAMES,choices,invalid)
    return m.rewind(FRAMES,seek,name+'/start')


def _append_byte(m,out,invalid,name):
    """Copy LEFT atom to STACK as exactly eight LSB-first bits at its cursor."""
    states=[m.state(name+'/bit'+str(j)) for j in range(9)]
    _put(m,states[8],LEFT,{'B':(out,'B',0)},invalid)
    for j in range(8):
        choices={}
        for bit in ('0','1'):
            write=_row(m,STACK,{'B':(states[j+1],bit,1)},invalid,
                       name+'/copy'+str(j)+'/'+bit)
            choices[bit]=(write,bit,1)
        if j:
            nxt=out
            for k in range(7,j-1,-1):
                nxt=_row(m,STACK,{'B':(nxt,'0',1)},invalid,
                         name+'/pad'+str(j)+'/'+str(k))
            choices['B']=(nxt,'B',0)
        _put(m,states[j],LEFT,choices,invalid)
    return m.rewind(LEFT,states[0],name+'/start')


def _link_utf8(m,table,out,invalid,check,name):
    """Link a fresh complete qualified Source table; never host-decode a word.

    Fresh generation/provenance is a Root build obligation. Passing an arbitrary
    shape-compatible table does not establish UTF8 semantics or qualification.
    """
    check()
    if type(table) is not dict or type(table.get('schema')) is not str or table['schema']!='utf8-residual-physical-machine-v1':
        raise ValueError('full fixed UTF8 description required')
    halts=table.get('halts')
    alphabet=table.get('alphabet')
    if type(alphabet) is not list or any(type(s) is not str for s in alphabet) or alphabet!=['B','0','1','#'] or type(halts) is not dict or set(halts)!={'DONE','REJECT','BOUND'}:
        raise ValueError('fixed UTF8 symbols/ports required')
    if any(type(halts[k]) is not int or halts[k]!=v for k,v in (('DONE',0),('REJECT',1),('BOUND',2))):
        raise ValueError('exact typed UTF8 halt numbers required')
    if table.get('bit_order')!='least-significant-bit-first' or type(table.get('bits_per_byte')) is not int or table['bits_per_byte']!=8:
        raise ValueError('fixed eight-bit LSB-first UTF8 bytewords required')
    names=table.get('states')
    delta=table.get('delta')
    if type(names) is not list or not 4<=len(names)<=317 or type(delta) is not list or len(delta)>1256:
        raise ValueError('bounded complete UTF8 description required')
    roots=table.get('entries')
    modes=('LEAD','CONT1','CONT2','CONT3','E0_FIRST','F0_FIRST','F4_FIRST')
    if type(roots) is not dict or set(roots)!=set(modes):
        raise ValueError('all seven UTF8 entries required')
    for target in roots.values():
        check()
        if type(target) is not int or not 3<=target<len(names):
            raise ValueError('literal UTF8 entry state required')
    if type(table.get('initial')) is not int or table['initial']!=roots['LEAD']:
        raise ValueError('fixed UTF8 LEAD entry required')
    wanted=[]
    for q in range(3):
        for symbol in ('B','0','1','#'):
            check()
            wanted.append([q,symbol])
    undefined=table.get('undefined')
    if type(undefined) is not list or len(undefined)!=12:
        raise ValueError('full exact UTF8 halt-slot description required')
    for j,entry in enumerate(undefined):
        check()
        if type(entry) is not list or len(entry)!=2 or type(entry[0]) is not int or type(entry[1]) is not str or entry!=wanted[j]:
            raise ValueError('exact typed UTF8 halt-slot row required')
    states={0:out,1:invalid,2:2}
    choices={}
    for q in range(3,len(names)):
        check()
        states[q]=m.state(name+'/state'+str(q))
        choices[q]={}
    for entry in delta:
        check()
        if type(entry) is not list or len(entry)!=5:
            raise ValueError('literal full UTF8 row required')
        q,read,target,write,move=entry
        if type(q) is not int or not 3<=q<len(names) or type(target) is not int or not 0<=target<len(names):
            raise ValueError('literal bounded UTF8 row states required')
        if type(read) is not str or read not in ('B','0','1','#') or read in choices[q]:
            raise ValueError('unique UTF8 read slot required')
        if type(write) is not str or write!=read or type(move) is not int or move!=(1 if read in ('0','1') else 0):
            raise ValueError('unchanged UTF8 bytes and fixed physical moves required')
        if read=='#' and target!=2:
            raise ValueError('UTF8 fence always BOUND')
        choices[q][read]=(states[target],write,move)
    for q in range(3,len(names)):
        check()
        if set(choices[q])!={'B','0','1','#'}:
            raise ValueError('every UTF8 state must have its complete four slots')
        actions={s:choices[q][s] for s in ('B','0','1')}
        _put(m,states[q],STACK,actions,invalid)
    return m.rewind(STACK,states[roots['LEAD']],name+'/start')


def _byteword(m,table,out,invalid,check,name):
    """RETURN is raw byteword ref; STACK becomes its literal byte bit buffer."""
    loop=m.state(name+'/list')
    utf8=_link_utf8(m,table,out,invalid,check,name+'/UTF8')
    again=_copy(m,RIGHT,RETURN,loop,invalid,name+'/tail')
    byte=_append_byte(m,again,invalid,name+'/byte')
    pair=heap_lookup(m,byte,invalid,name+'/lookup-cell')
    branch=_word_is(m,RETURN,'000000001',utf8,pair,invalid,name+'/nil')
    _put(m,loop,RETURN,{s:(branch,s,0) for s in ('0','1')},invalid)
    return m.clear_word(STACK,loop,name+'/clear-buffer')


def _unary(m,out,invalid,negative,name):
    loop=m.state(name+'/list')
    again=_copy(m,RIGHT,RETURN,loop,invalid,name+'/tail')
    head=_word_is(m,LEFT,'1',again,invalid,invalid,name+'/one')
    pair=heap_lookup(m,head,invalid,name+'/lookup-cell')
    branch=_word_is(m,RETURN,'000000001',out,pair,invalid,name+'/nil')
    _put(m,loop,RETURN,{s:(branch,s,0) for s in ('0','1')},invalid)
    if negative:
        return _word_is(m,RETURN,'000000001',invalid,pair,invalid,name+'/nonzero')
    return loop


def _tagged_validator(m,table,out,invalid,check,name):
    """Iterative physical type/node tasks; caller has scheduled VALUE roots."""
    next_task=m.state(name+'/next-task')
    inspect=m.state(name+'/inspect-task')
    dispatch=m.state(name+'/dispatch-task')
    value=m.state(name+'/value-tag')
    array=m.state(name+'/array-tail')
    obj=m.state(name+'/object-tail')
    done=_empty_records(m,FRAMES,out,invalid,name+'/all-frames-closed')

    string=_byteword(m,table,next_task,invalid,check,name+'/string')
    string=_copy(m,RIGHT,RETURN,string,invalid,name+'/string-body')
    positive=_unary(m,next_task,invalid,False,name+'/integer-nonnegative')
    positive=_copy(m,RIGHT,RETURN,positive,invalid,name+'/positive-body')
    negative=_unary(m,next_task,invalid,True,name+'/integer-negative')
    negative=_copy(m,RIGHT,RETURN,negative,invalid,name+'/negative-body')
    boolean=_word_is(m,RIGHT,'1',next_task,invalid,invalid,name+'/boolean-one')
    boolean=_word_is(m,RIGHT,'0',next_task,boolean,invalid,name+'/boolean-zero')
    null=_word_is(m,RIGHT,'000000001',next_task,invalid,invalid,name+'/null')
    arr_body=_push_task(m,1,RIGHT,next_task,invalid,name+'/schedule-array')
    obj_body=_push_task(m,2,RIGHT,next_task,invalid,name+'/schedule-object')
    obj_body=_open_key_frame(m,obj_body,invalid,name+'/object-frame')
    tags=(('0',obj_body),('1',arr_body),('01',string),('11',positive),
          ('001',negative),('101',boolean),('011',null))
    tag_gate=invalid
    for j in range(len(tags)-1,-1,-1):
        bits,target=tags[j]
        tag_gate=_word_is(m,LEFT,bits,target,tag_gate,invalid,name+'/tag'+str(j))
    lookup=heap_lookup(m,tag_gate,invalid,name+'/value-lookup')
    _put(m,value,RETURN,{s:(lookup,s,0) for s in ('0','1')},invalid)

    arr_child=_push_task(m,0,LEFT,next_task,invalid,name+'/array-child')
    arr_tail=_push_task(m,1,RIGHT,arr_child,invalid,name+'/array-rest')
    arr_pair=heap_lookup(m,arr_tail,invalid,name+'/array-cell')
    arr_gate=_word_is(m,RETURN,'000000001',next_task,arr_pair,invalid,name+'/array-nil')
    _put(m,array,RETURN,{s:(arr_gate,s,0) for s in ('0','1')},invalid)

    key=_byteword(m,table,next_task,invalid,check,name+'/object-key')
    key=_copy(m,LEFT,RETURN,key,invalid,name+'/key-reference')
    key=_unique_key_and_append(m,key,invalid,name+'/key-uniqueness')
    obj_child=_push_task(m,0,RIGHT,key,invalid,name+'/object-value')
    obj_row=heap_lookup(m,obj_child,invalid,name+'/object-row')
    obj_row=_copy(m,LEFT,RETURN,obj_row,invalid,name+'/row-reference')
    obj_tail=_push_task(m,2,RIGHT,obj_row,invalid,name+'/object-rest')
    obj_pair=heap_lookup(m,obj_tail,invalid,name+'/object-cell')
    close=_close_key_frame(m,next_task,invalid,name+'/close-object')
    obj_gate=_word_is(m,RETURN,'000000001',close,obj_pair,invalid,name+'/object-nil')
    _put(m,obj,RETURN,{s:(obj_gate,s,0) for s in ('0','1')},invalid)

    task_gate=_word_is(m,TEMP,'01',obj,invalid,invalid,name+'/task-object')
    task_gate=_word_is(m,TEMP,'1',array,task_gate,invalid,name+'/task-array')
    task_gate=_word_is(m,TEMP,'0',value,task_gate,invalid,name+'/task-value')
    _put(m,dispatch,TEMP,{s:(task_gate,s,0) for s in ('0','1')},invalid)
    pop_type=_pop_word_from(m,TASKS,TEMP,dispatch,invalid,name+'/pop-type')
    pop_node=_pop_word_from(m,TASKS,RETURN,pop_type,invalid,name+'/pop-node')
    _put(m,inspect,TASKS,{':':(done,':',0),'0':(pop_node,'0',0),
                        '1':(pop_node,'1',0)},invalid)
    rewind=m.rewind(TASKS,inspect,name+'/task-start')
    _put(m,next_task,TASKS,{s:(rewind,s,0) for s in RAW if s!='#'},invalid)
    return next_task


def _schedule_stack_roots(m,count,out,invalid,name):
    """Pop a fixed Source count, then switch STACK to an empty byte buffer."""
    nxt=_records_to_empty_word(m,STACK,out,invalid,name+'/byte-buffer')
    for j in range(count):
        task=_push_task(m,0,RETURN,nxt,invalid,name+'/task'+str(j))
        nxt=stack_pop(m,RETURN,task,invalid,name+'/root'+str(j))
    return nxt


def _fixed_key(m,key,out,invalid,name):
    """Construct only one of five fixed request-key bytewords physically.

    The literal byte tuple belongs to this program, never to a runtime input or
    checker image. Each cons still executes the ordinary physical heap search.
    """
    keys={
        'protocol':('0000111','0100111','1111011','0010111','1111011','1100011','1111011','0011011'),
        'theory':('0010111','0001011','1010011','1111011','0100111','1001111'),
        'target':('0010111','1000011','0100111','1110011','1010011','0010111'),
        'blocks':('0100011','0011011','1111011','1100011','1101011','1100111'),
        'proof':('0000111','0100111','1111011','1111011','0110011')}
    if type(key) is not str or key not in keys:
        raise ValueError('fixed request key required')
    nxt=out
    # The reversed byte order is Source unrolling only. At runtime RIGHT is
    # the actual current byteword tail and canonical_cons does all heap work.
    for j,bits in enumerate(keys[key]):
        again=_copy(m,RETURN,RIGHT,nxt,invalid,name+'/tail'+str(j))
        cons=canonical_cons(m,again,invalid,name+'/cons'+str(j))
        nxt=_constant(m,LEFT,bits,cons,invalid,name+'/byte'+str(j))
    return _constant(m,RIGHT,'000000001',nxt,invalid,name+'/nil')


def _request_assembly(m,out,invalid,name):
    """Consume five saved roots and build the exact tagged request object."""
    clean_stack=_word_to_empty_records(m,STACK,out,invalid,name+'/clean-parser-stack')
    clean_frames=_empty_records(m,FRAMES,clean_stack,invalid,name+'/frames-empty')
    clean_tasks=_empty_records(m,TASKS,clean_frames,invalid,name+'/tasks-empty')
    clean_output=_empty_records(m,OUTPUT,clean_tasks,invalid,name+'/output-empty')
    finish=canonical_cons(m,clean_output,invalid,name+'/object-tag-cons')
    finish=_constant(m,LEFT,'0',finish,invalid,name+'/object-tag')
    finish=_copy(m,STACK,RIGHT,finish,invalid,name+'/object-body')
    nxt=finish
    # Construct backwards: the first executed key is proof, paired with the
    # last saved root; the final row order is protocol,theory,target,blocks,proof.
    for key in ('protocol','theory','target','blocks','proof'):
        save_tail=_copy(m,RETURN,STACK,nxt,invalid,name+'/'+key+'/save-list')
        list_cons=canonical_cons(m,save_tail,invalid,name+'/'+key+'/list-cons')
        list_cons=_copy(m,STACK,RIGHT,list_cons,invalid,name+'/'+key+'/list-tail')
        list_cons=_copy(m,RETURN,LEFT,list_cons,invalid,name+'/'+key+'/row-reference')
        row_cons=canonical_cons(m,list_cons,invalid,name+'/'+key+'/row-cons')
        row_cons=_copy(m,TEMP,RIGHT,row_cons,invalid,name+'/'+key+'/value')
        row_cons=_copy(m,RETURN,LEFT,row_cons,invalid,name+'/'+key+'/key-reference')
        key_body=_fixed_key(m,key,row_cons,invalid,name+'/'+key+'/key')
        nxt=_pop_word_from(m,OUTPUT,TEMP,key_body,invalid,name+'/'+key+'/pop-value')
    return _constant(m,STACK,'000000001',nxt,invalid,name+'/empty-row-list')


def install_value_boot(m,utf8_table,*,out,invalid,check,name='linked-value-BOOT'):
    """Install fixed complete value-body phases with explicit Root ports.

    This is static assembly, never input execution. Root must freshly generate
    utf8_table from the pinned qualified Source, own all quotas/custody and
    establish immutable program/seed/layout/projected-wire initialization pins.
    The success port receives the request reference, not proof acceptance.
    FUNCTION/PC/DESTINATION are not touched. No VM/controller is installed here.
    """
    state={'schema':'linked-value-boot-construction-prefix-v2','complete':False,
           'phase':'ENTRY','utf8_table':utf8_table,'builder':m,'entries':{},
           'authority':False,'full_BOOT':False}
    try:
        if not callable(check):
            raise ValueError('explicit Root callback required')
        check()
        if type(name) is not str or not name or len(name)>32:
            raise ValueError('bounded fixed Source name required')
        if type(out) is not int or out<4 or type(invalid) is not int or invalid!=1:
            raise ValueError('working Root success port and exact REJECT1 required')
        check()
        state['phase']='REQUEST_ASSEMBLY'
        assembly=_request_assembly(m,out,invalid,name+'/request')
        state['phase']='FREE_VALUE_VALIDATION'
        free_validator=_tagged_validator(m,utf8_table,assembly,invalid,check,name+'/free-values')
        free_schedule=_schedule_stack_roots(m,2,free_validator,invalid,name+'/free-roots')
        save_free=_copy_records_to_output(m,free_schedule,invalid,name+'/save-free')
        free=postfix_roots(m,2,2,save_free,invalid,name+'/CERTIFICATE2')
        free=_word_to_empty_records(m,STACK,free,invalid,name+'/prepare-free-parser')
        state['phase']='PUBLIC_VALUE_VALIDATION'
        public_validator=_tagged_validator(m,utf8_table,free,invalid,check,name+'/public-values')
        public_schedule=_schedule_stack_roots(m,3,public_validator,invalid,name+'/public-roots')
        save_public=_copy_records_to_output(m,public_schedule,invalid,name+'/save-public')
        public=postfix_roots(m,1,3,save_public,invalid,name+'/PUBLIC3')
        state['phase']='EMPTY_PRIVATE_STACKS'
        entry=_clear_records(m,OUTPUT,public,invalid,name+'/clear-output')
        entry=_clear_records(m,FRAMES,entry,invalid,name+'/clear-frames')
        entry=_clear_records(m,TASKS,entry,invalid,name+'/clear-tasks')
        state['entries'].update(BOOT=entry,PUBLIC3=public,CERTIFICATE2=free,
                                request_assembly=assembly)
        check()
        state['phase']='CLOSED'
        state['complete']=True
        return {'schema':'linked-value-BOOT-entries-v2','version':VERSION,
                'entries':dict(state['entries']),'value_body_complete':True,
                'full_BOOT':False,'complete_interpreter':False,
                'runtime_qualified':False,'mathematical_authority':False,
                'dependencies':['shared-builder-v2','fresh-qualified-UTF8-Source'],
                'conditional_intake':['canonical-program-seed','fixed-layout-and-cursors',
                    'word-padding','fixed-projected-colon-and-pinned-postcolon-blanks']}
    except BaseException as error:
        # No callback, replay, normalization or successful prefix on failure.
        # Exact foreign identities and genuine Root faults propagate unchanged.
        try:
            error.linked_boot_construction_prefix=state
        except BaseException:
            pass
        raise
