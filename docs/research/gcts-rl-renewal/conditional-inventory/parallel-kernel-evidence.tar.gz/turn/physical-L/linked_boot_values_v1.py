"""Source-only shared16-band literal microcode for canonical heap and postfix refs.

No table generation or component call occurred. All construction functions below
emit only m.state/m.put/m.row/rewind/clear_word phases for Root's shared lowerer.
There is no host heap operation or semantic transition callback. Full BOOT's
recursive tagged grammar, UTF8/key gate and request/controller remain absent.
"""
VERSION = 'linked-boot-canonical-values-v1'
RAW = ('B', '^', '0', '1', ':', ',', ';', '|', '!', '#')
WORKSPACE = ('PROGRAM','PUBLIC','CERTIFICATE','HEAP','REGISTERS','FRAMES',
             'FUNCTION','PC','DESTINATION','LEFT_VALUE','RIGHT_VALUE',
             'RETURN_VALUE','COUNT','TEMPORARY','PARSER_STACK','OUTPUT')
HEAP=3
LEFT=9
RIGHT=10
RETURN=11
COUNT=12
TEMP=13
STACK=14


def _put(m,q,band,choices,invalid):
    expanded={}
    for symbol in RAW:
        if symbol!='#':
            expanded[symbol]=choices.get(symbol,(invalid,symbol,0))
    m.put(q,band,expanded)


def _row(m,band,choices,invalid,name):
    q=m.state(name)
    _put(m,q,band,choices,invalid)
    return q


def _constant(m,band,bits,out,invalid,name):
    # Internal callsites use only fixed zero or257, never program/input words.
    nextq=out
    for j in range(len(bits)-1,-1,-1):
        nextq=_row(m,band,{'B':(nextq,bits[j],1)},invalid,name+'/bit'+str(j))
    return m.clear_word(band,nextq,name+'/clear')


def _copy(m,src,dst,out,invalid,name):
    loop=m.state(name+'/read')
    finish=m.rewind(dst,out,name+'/rewind-result')
    choices={'B':(finish,'B',0)}
    for bit in ('0','1'):
        write=_row(m,dst,{'B':(loop,bit,1)},invalid,name+'/write'+bit)
        choices[bit]=(write,bit,1)
    _put(m,loop,src,choices,invalid)
    read=m.rewind(src,loop,name+'/rewind-source')
    return m.clear_word(dst,read,name+'/clear-result')


def _increment(m,band,out,invalid,name):
    carry=m.state(name+'/carry')
    finish=m.rewind(band,out,name+'/rewind')
    _put(m,carry,band,{'0':(finish,'1',0),'1':(carry,'0',1),
                     'B':(finish,'1',0)},invalid)
    return m.rewind(band,carry,name+'/start')


def _canonical_word(m,band,out,invalid,name):
    first=m.state(name+'/first')
    firstzero=m.state(name+'/first-zero')
    lastzero=m.state(name+'/last-zero')
    lastone=m.state(name+'/last-one')
    _put(m,first,band,{'0':(firstzero,'0',1),'1':(lastone,'1',1)},invalid)
    _put(m,firstzero,band,{'B':(out,'B',0),'0':(lastzero,'0',1),
                         '1':(lastone,'1',1)},invalid)
    _put(m,lastzero,band,{'0':(lastzero,'0',1),'1':(lastone,'1',1)},invalid)
    _put(m,lastone,band,{'0':(lastzero,'0',1),'1':(lastone,'1',1),
                       'B':(out,'B',0)},invalid)
    return m.rewind(band,first,name+'/start')


def _atom_or_node(m,band,atom,node,invalid,name):
    states={}
    for j in range(9):
        for nonzero in (False,True):
            states[j,nonzero]=m.state(name+'/'+str(j)+'/'+str(int(nonzero)))
    end=_row(m,band,{'B':(atom,'B',0),'0':(node,'0',0),
                     '1':(node,'1',0)},invalid,name+'/exact256-end')
    for j in range(9):
        for nonzero in (False,True):
            choices={}
            if j:
                choices['B']=(atom,'B',0)
            if j<8:
                for bit in (0,1):
                    s='1' if bit else '0'
                    choices[s]=(states[j+1,nonzero or bool(bit)],s,1)
            else:
                choices['0']=(node,'0',0)
                choices['1']=(node if nonzero else end,'1',0 if nonzero else 1)
            _put(m,states[j,nonzero],band,choices,invalid)
    # Canonical-word validation is deliberately separate and precedes this test.
    return m.rewind(band,states[0,False],name+'/start')


def _compare_words(m,left,right,yes,no,invalid,name):
    loop=m.state(name+'/left')
    end=_row(m,right,{'B':(yes,'B',0),'0':(no,'0',0),
                     '1':(no,'1',0)},invalid,name+'/exact-end')
    choices={'B':(end,'B',0)}
    for bit in ('0','1'):
        check={}
        for symbol in ('0','1','B'):
            check[symbol]=(loop,symbol,1) if symbol==bit else (no,symbol,0)
        q=_row(m,right,check,invalid,name+'/right'+bit)
        choices[bit]=(q,bit,1)
    _put(m,loop,left,choices,invalid)
    start=m.rewind(right,loop,name+'/rewind-right')
    return m.rewind(left,start,name+'/rewind-left')


def _next_heap_record(m,out,invalid,name):
    q=m.state(name+'/scan-semicolon')
    _put(m,q,HEAP,{'0':(q,'0',1),'1':(q,'1',1),',':(q,',',1),
                   ';':(out,';',1)},invalid)
    return q


def _compare_heap_field(m,word,end_symbol,yes,no,invalid,name):
    loop=m.state(name+'/read-heap')
    consume=_row(m,HEAP,{end_symbol:(yes,end_symbol,1)},invalid,name+'/consume-delimiter')
    exact=_row(m,word,{'B':(consume,'B',0),'0':(no,'0',0),
                       '1':(no,'1',0)},invalid,name+'/word-exact-end')
    choices={end_symbol:(exact,end_symbol,0)}
    for bit in ('0','1'):
        check={}
        for symbol in ('0','1','B'):
            check[symbol]=(loop,symbol,1) if symbol==bit else (no,symbol,0)
        q=_row(m,word,check,invalid,name+'/compare'+bit)
        choices[bit]=(q,bit,1)
    _put(m,loop,HEAP,choices,invalid)
    return m.rewind(word,loop,name+'/rewind-word')


def _copy_heap_field(m,dst,end_symbol,out,invalid,name):
    loop=m.state(name+'/read')
    finish=m.rewind(dst,out,name+'/rewind-result')
    choices={end_symbol:(finish,end_symbol,1)}
    for bit in ('0','1'):
        write=_row(m,dst,{'B':(loop,bit,1)},invalid,name+'/write'+bit)
        choices[bit]=(write,bit,1)
    _put(m,loop,HEAP,choices,invalid)
    return m.clear_word(dst,loop,name+'/clear-result')


def _write_word_here(m,src,dst,first_symbol,end_symbol,out,invalid,name):
    first=m.state(name+'/read-first')
    more=m.state(name+'/read-more')
    delimiter=_row(m,dst,{'B':(out,end_symbol,1)},invalid,name+'/write-delimiter')
    more_choices={'B':(delimiter,'B',0)}
    first_choices={}
    for bit in ('0','1'):
        initial=_row(m,dst,{first_symbol:(more,bit,1)},invalid,name+'/initial'+bit)
        following=_row(m,dst,{'B':(more,bit,1)},invalid,name+'/following'+bit)
        first_choices[bit]=(initial,bit,1)
        more_choices[bit]=(following,bit,1)
    _put(m,first,src,first_choices,invalid)
    _put(m,more,src,more_choices,invalid)
    return m.rewind(src,first,name+'/rewind-source')


def _valid_reference(m,word,out,invalid,name):
    scan=m.state(name+'/heap-record')
    advance=m.state(name+'/advance')
    nxt=_next_heap_record(m,advance,invalid,name+'/next')
    inc=_increment(m,COUNT,scan,invalid,name+'/increment-ID')
    _put(m,advance,HEAP,{'0':(inc,'0',0),'1':(inc,'1',0),
                       ':':(inc,':',0)},invalid)
    compare=_compare_words(m,word,COUNT,out,nxt,invalid,name+'/compare-ID')
    _put(m,scan,HEAP,{'0':(compare,'0',0),'1':(compare,'1',0),
                     ':':(invalid,':',0)},invalid)
    heap_start=m.rewind(HEAP,scan,name+'/rewind-heap')
    count_start=_constant(m,COUNT,'100000001',heap_start,invalid,name+'/ID257')
    classify=_atom_or_node(m,word,out,count_start,invalid,name+'/atom-or-node')
    return _canonical_word(m,word,classify,invalid,name+'/canonical')


def canonical_cons(m,out,invalid,name='canonical-cons'):
    """Preserve LEFT/RIGHT words; return canonical pair ID in RETURN.

    HEAP must be canonical/topological from validated immutable seed plus prior
    successful appends. Both operands are physically checked as valid refs.
    COUNT is clobbered; TEMP is available but not used in this construction.
    """
    scan=m.state(name+'/scan-pair')
    advance=m.state(name+'/advance')
    inc=_increment(m,COUNT,scan,invalid,name+'/increment-ID')
    _put(m,advance,HEAP,{'0':(inc,'0',0),'1':(inc,'1',0),
                       ':':(inc,':',0)},invalid)
    skip=_next_heap_record(m,advance,invalid,name+'/skip-unmatched')
    found=_copy(m,COUNT,RETURN,out,invalid,name+'/return-existing-ID')
    right=_compare_heap_field(m,RIGHT,';',found,skip,invalid,name+'/right')
    left=_compare_heap_field(m,LEFT,',',right,skip,invalid,name+'/left')
    finish=_row(m,HEAP,{'B':(out,':',0)},invalid,name+'/append-used-end')
    append_right=_write_word_here(m,RIGHT,HEAP,'B',';',finish,invalid,name+'/append-right')
    append_left=_write_word_here(m,LEFT,HEAP,':',',',append_right,invalid,name+'/append-left')
    append=_copy(m,COUNT,RETURN,append_left,invalid,name+'/return-new-ID')
    _put(m,scan,HEAP,{'0':(left,'0',0),'1':(left,'1',0),
                     ':':(append,':',0)},invalid)
    start=m.rewind(HEAP,scan,name+'/rewind-heap')
    start=_constant(m,COUNT,'100000001',start,invalid,name+'/ID257')
    start=_valid_reference(m,RIGHT,start,invalid,name+'/validate-right')
    return _valid_reference(m,LEFT,start,invalid,name+'/validate-left')


def heap_lookup(m,out,invalid,name='heap-lookup'):
    """Preserve RETURN node ID; output pair children LEFT/RIGHT or invalid.

    Atoms and nonexistent IDs never pass. No host indexing/arithmetic executes
    in a transition. COUNT is the physically incremented current implicit ID.
    """
    scan=m.state(name+'/scan')
    advance=m.state(name+'/advance')
    inc=_increment(m,COUNT,scan,invalid,name+'/increment-ID')
    _put(m,advance,HEAP,{'0':(inc,'0',0),'1':(inc,'1',0),
                       ':':(inc,':',0)},invalid)
    skip=_next_heap_record(m,advance,invalid,name+'/skip')
    right=_copy_heap_field(m,RIGHT,';',out,invalid,name+'/copy-right')
    left=_copy_heap_field(m,LEFT,',',right,invalid,name+'/copy-left')
    compare=_compare_words(m,RETURN,COUNT,left,skip,invalid,name+'/compare-ID')
    _put(m,scan,HEAP,{'0':(compare,'0',0),'1':(compare,'1',0),
                     ':':(invalid,':',0)},invalid)
    start=m.rewind(HEAP,scan,name+'/rewind-heap')
    start=_constant(m,COUNT,'100000001',start,invalid,name+'/ID257')
    return _canonical_word(m,RETURN,start,invalid,name+'/canonical-ID')


def _clear_records(m,band,out,invalid,name):
    scan=m.state(name+'/erase')
    end=_row(m,band,{'B':(out,':',0)},invalid,name+'/new-used-end')
    finish=m.rewind(band,end,name+'/rewind')
    choices={':':(finish,'B',0)}
    for symbol in ('0','1',',',';'):
        choices[symbol]=(scan,'B',1)
    _put(m,scan,band,choices,invalid)
    return m.rewind(band,scan,name+'/start')


def stack_push(m,out,invalid,name='stack-push'):
    """Append canonical RETURN reference; preserve that reference's contents."""
    seek=m.state(name+'/seek-used-end')
    finish=_row(m,STACK,{'B':(out,':',0)},invalid,name+'/new-used-end')
    append=_write_word_here(m,RETURN,STACK,':',';',finish,invalid,name+'/append')
    choices={':':(append,':',0)}
    for symbol in ('0','1',';'):
        choices[symbol]=(seek,symbol,1)
    _put(m,seek,STACK,choices,invalid)
    return m.rewind(STACK,seek,name+'/start')


def stack_pop(m,destination,out,invalid,name='stack-pop'):
    """Remove last reference, preserving prior prefix; destructive on failure."""
    seek=m.state(name+'/seek-used-end')
    semicolon=m.state(name+'/last-semicolon')
    back=m.state(name+'/find-word-start')
    copy=m.state(name+'/copy-erase')
    restore=m.state(name+'/seek-first-erased')
    finish=m.rewind(destination,out,name+'/rewind-output')
    _put(m,restore,STACK,{'0':(restore,'0',1),'1':(restore,'1',1),
                         ';':(restore,';',1),'B':(finish,':',0)},invalid)
    rewind_restore=m.rewind(STACK,restore,name+'/restore-end')
    choices={':':(rewind_restore,'B',0)}
    for bit in ('0','1'):
        write=_row(m,destination,{'B':(copy,bit,1)},invalid,name+'/write'+bit)
        choices[bit]=(write,'B',1)
    _put(m,copy,STACK,choices,invalid)
    _put(m,back,STACK,{'0':(back,'0',-1),'1':(back,'1',-1),
                      ';':(copy,';',1),'^':(copy,'^',1)},invalid)
    _put(m,semicolon,STACK,{';':(back,':',-1)},invalid)
    choices={':':(semicolon,'B',-1)}
    for symbol in ('0','1',';'):
        choices[symbol]=(seek,symbol,1)
    _put(m,seek,STACK,choices,invalid)
    start=m.rewind(STACK,seek,name+'/start')
    return m.clear_word(destination,start,name+'/clear-output')


def _read_atom9(m,source,out,invalid,name):
    states={}
    for j in range(9):
        for nonzero in (False,True):
            states[j,nonzero]=m.state(name+'/'+str(j)+'/'+str(int(nonzero)))
    trim=m.state(name+'/trim-high-zeros')
    finish=m.rewind(RETURN,out,name+'/rewind-result')
    zero=_row(m,RETURN,{'B':(finish,'0',0)},invalid,name+'/canonical-zero')
    _put(m,trim,RETURN,{'0':(trim,'B',-1),'1':(finish,'1',0),
                       '^':(zero,'^',1)},invalid)
    to_trim=_row(m,RETURN,{'B':(trim,'B',-1)},invalid,name+'/start-trim')
    for j in range(9):
        for nonzero in (False,True):
            choices={}
            for bit in (0,1):
                symbol='1' if bit else '0'
                if j==8 and bit and nonzero:
                    choices[symbol]=(invalid,symbol,0)
                    continue
                nxt=to_trim if j==8 else states[j+1,nonzero or bool(bit)]
                put=_row(m,RETURN,{'B':(nxt,symbol,1)},invalid,name+'/write'+str(j)+'/'+str(int(nonzero))+'/'+symbol)
                choices[symbol]=(put,symbol,1)
            _put(m,states[j,nonzero],source,choices,invalid)
    return m.clear_word(RETURN,states[0,False],name+'/clear-result')


def postfix_roots(m,source,root_count,out,invalid,name='postfix-roots'):
    """Fixed callsites PUBLIC3/CERTIFICATE2 only; not complete tagged BOOT.

    Parses real references through canonical_cons, retaining exact roots in
    PARSER_STACK. PUBLIC/CERTIFICATE data are only read with unchanged symbols.
    Semantic tagged-value/UTF8/key validation and copying public roots before
    reusing the stack are caller obligations explicitly not implemented here.
    """
    if type(source) is not int or type(root_count) is not int or (source,root_count) not in ((1,3),(2,2)):
        raise ValueError('fixed PUBLIC/CERTIFICATE root-mode callsites only')
    token=m.state(name+'/token')
    padding=m.state(name+'/padding')
    counts=[]
    for j in range(root_count+1):
        counts.append(m.state(name+'/root-count'+str(j)))
    atom_done=stack_push(m,token,invalid,name+'/atom-push')
    atom=_read_atom9(m,source,atom_done,invalid,name+'/atom')
    cons_done=stack_push(m,token,invalid,name+'/cons-push')
    cons=canonical_cons(m,cons_done,invalid,name+'/canonical-cons')
    pop_left=stack_pop(m,LEFT,cons,invalid,name+'/pop-left')
    pop_right=stack_pop(m,RIGHT,pop_left,invalid,name+'/pop-right')
    _put(m,token,source,{'0':(atom,'0',1),'1':(pop_right,'1',1),
                       ';':(m.rewind(STACK,counts[0],name+'/count-start'),';',1)},invalid)
    for j in range(root_count):
        _put(m,counts[j],STACK,{'0':(counts[j],'0',1),'1':(counts[j],'1',1),
                              ';':(counts[j+1],';',1)},invalid)
    _put(m,counts[root_count],STACK,{':':(padding,':',0)},invalid)
    _put(m,padding,source,{'B':(padding,'B',1),':':(out,':',0)},invalid)
    begin=m.rewind(source,token,name+'/rewind-immutable-source')
    return _clear_records(m,STACK,begin,invalid,name+'/clear-stack')


def install_postfix_pair(m,public_out,free_out,invalid,name='postfix-pair'):
    """Install both fixed bodies; Root owns their sequencing/copy/validation."""
    public=postfix_roots(m,1,3,public_out,invalid,name+'/PUBLIC3')
    free=postfix_roots(m,2,2,free_out,invalid,name+'/CERTIFICATE2')
    return dict(PUBLIC3=public,CERTIFICATE2=free,full_BOOT=False,
                tagged_value_validation=False,request_assembly=False)
