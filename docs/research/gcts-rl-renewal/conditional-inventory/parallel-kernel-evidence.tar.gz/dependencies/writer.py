"""Source-only portable byte reservations and writer protocol; never imported here.

Directory ownership is exclusive and cooperative. Filesystem calls can block or
fail. No method checks a proof or admits a partial. Alternative operations are
explicit diagnostic backends, never attested physical I/O.
"""
import hashlib
import os
import stat

VERSION = 'aggregate-byte-budget-v2-fixed-completion'
CAP = 134217728
OUTER_RESERVE = 9437184
SUMMARY_CAP = 65536
LOG_CAP = 4194304
HEADER_CAP = 4194304
MAX_ENTRIES = 4096
CHUNK_CAP = 65536
FIXED = {'stdout.bin': LOG_CAP, 'stderr.bin': LOG_CAP,
         'worker-receipt.json': HEADER_CAP,
         'worker-failure-summary.json': SUMMARY_CAP}


class BudgetRefusal(Exception):
    pass


def exact_uint(value, label):
    if type(value) is not int or value < 0:
        raise BudgetRefusal('exact nonnegative integer required: ' + label)
    return value


def safe_name(name):
    if (type(name) is not str or not 1 <= len(name) <= 128 or
            name in ('.', '..') or name.endswith('.partial') or
            any(c not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._-' for c in name)):
        raise BudgetRefusal('safe final basename required')
    return name


class AggregateLedger:
    """Pure metadata carrier. Caller supplies observed sizes, never file content.

    Public dictionaries are inspectable, caller-read-only owned state. No hostile
    threads, mutation, shrinking/deleting files, or concurrent unleased writers.
    """
    def __init__(self, entries):
        if type(entries) is not list or len(entries) > MAX_ENTRIES:
            raise BudgetRefusal('bounded exact prior entry list required')
        self.prior = {}; self.slots = {}; self.spent = set(); self.events = []
        self.primary = None; self.secondaries = []; self.objects = []
        self.unavailable_physical = False; self.claims = 0
        for entry in entries:
            if type(entry) is not dict or set(entry) != {'name', 'bytes', 'identity'}:
                raise BudgetRefusal('exact metadata entry required')
            name = entry['name']
            if type(name) is not str or not name or '/' in name or '\\' in name or name in self.prior:
                raise BudgetRefusal('distinct plain entry names required')
            size = exact_uint(entry['bytes'], 'prior bytes')
            identity = entry['identity']
            if type(identity) is not tuple or len(identity) != 2:
                raise BudgetRefusal('exact device/inode identity tuple required')
            for number in identity:
                exact_uint(number, 'identity')
            self.prior[name] = dict(name=name, bytes=size, identity=identity)
            self.spent.add(name)
            self.spent.add(name[:-8] if name.endswith('.partial') else name + '.partial')
        # Summary/header must be unused before any bulk claim; old fragments are
        # charged opaque data, never reopened or repaired under the same name.
        for name in ('worker-receipt.json', 'worker-failure-summary.json'):
            if name in self.prior or name + '.partial' in self.prior:
                raise BudgetRefusal('fixed once-output already exists')
        for name, ceiling in FIXED.items():
            size = self.prior[name]['bytes'] if name in self.prior else 0
            if size > ceiling:
                raise BudgetRefusal('preexisting fixed file exceeds original cap')
            self.slots[name] = dict(name=name, kind='fixed', physical_limit=ceiling,
                expanded_limit=ceiling, physical=size, expanded=size,
                attempted=False, complete=False, failed=False,
                physical_exact=True, expanded_exact=True)
        self.opaque = sum(e['bytes'] for n, e in self.prior.items() if n not in FIXED)
        self.require_fit()

    def snapshot(self):
        return dict(schema='aggregate-byte-budget-ledger-v1', authority=False,
            cap=CAP, expanded_cap=CAP, outer_reserve=OUTER_RESERVE,
            negative_summary_reserved=SUMMARY_CAP, opaque_prior_bytes=self.opaque,
            observed_physical_bytes=self.opaque + sum(x['physical'] for x in self.slots.values()),
            charged_expanded_bytes=self.opaque + sum(x['expanded'] for x in self.slots.values()),
            committed_physical_bytes=self.opaque + OUTER_RESERVE + sum(x['physical_limit'] for x in self.slots.values()),
            committed_expanded_bytes=self.opaque + OUTER_RESERVE + sum(x['expanded_limit'] for x in self.slots.values()),
            physical_exact=not self.unavailable_physical and all(x['physical_exact'] for x in self.slots.values()),
            expanded_exact=all(x['expanded_exact'] for x in self.slots.values()),
            reservations=[dict(x) for x in self.slots.values()], claims=self.claims,
            partial_content_read=False, mathematical_admission=False)

    def require_fit(self):
        row = self.snapshot()
        if row['committed_physical_bytes'] > CAP or row['committed_expanded_bytes'] > CAP:
            raise BudgetRefusal('aggregate original stored/expanded byte cap')

    def claim(self, name, physical_limit, expanded_limit, kind):
        safe_name(name)
        exact_uint(physical_limit, 'physical ceiling')
        exact_uint(expanded_limit, 'expanded ceiling')
        if not physical_limit or expanded_limit < physical_limit:
            raise BudgetRefusal('positive physical ceiling and no smaller expanded ceiling')
        if kind not in ('bulk', 'result', 'header', 'negative-summary'):
            raise BudgetRefusal('literal writer kind required')
        if name in self.spent or name + '.partial' in self.spent:
            raise BudgetRefusal('no overwrite, retry or used-name reuse')
        self.spent.add(name); self.spent.add(name + '.partial'); self.claims += 1
        fixed_kind = {'worker-receipt.json': 'header', 'worker-failure-summary.json': 'negative-summary'}
        if name in FIXED:
            if fixed_kind.get(name) != kind or physical_limit != FIXED[name] or expanded_limit != FIXED[name]:
                raise BudgetRefusal('fixed reserved slot and exact original ceiling required')
            slot = self.slots[name]
        else:
            if kind in ('header', 'negative-summary'):
                raise BudgetRefusal('fixed reserved filename required')
            slot = dict(name=name, kind=kind, physical_limit=physical_limit,
                expanded_limit=expanded_limit, physical=0, expanded=0,
                attempted=False, complete=False, failed=False,
                physical_exact=True, expanded_exact=True)
            self.slots[name] = slot
        slot['attempted'] = True
        try:
            self.require_fit()
        except BaseException:
            slot['failed'] = True
            # A refused uncreated lease has written zero bytes. Keep its spent
            # name but remove its unavailable reservation; no file was deleted.
            if name not in FIXED:
                del self.slots[name]
            raise
        return slot

    def before_chunk(self, slot, physical, expanded):
        exact_uint(physical, 'chunk bytes'); exact_uint(expanded, 'expanded chunk charge')
        if not 0 < physical <= CHUNK_CAP or expanded < physical:
            raise BudgetRefusal('bounded nonempty byte chunk and full expansion charge required')
        if slot['physical'] + physical > slot['physical_limit'] or slot['expanded'] + expanded > slot['expanded_limit']:
            raise BudgetRefusal('writer reserved ceiling reached before write')

    def observed(self, slot, size):
        exact_uint(size, 'observed physical bytes')
        if size < slot['physical'] or size > slot['physical_limit']:
            slot['physical_exact'] = False
            raise BudgetRefusal('physical size violates monotone reserved writer')
        slot['physical'] = size
        slot['physical_exact'] = True

    def completed_chunk(self, slot, written, expanded):
        exact_uint(written, 'written bytes'); exact_uint(expanded, 'expanded debit')
        slot['physical'] += written; slot['expanded'] += expanded
        self.require_fit()

    def failed(self, slot):
        slot['failed'] = True
        slot['expanded_exact'] = False
        # Never free a failed writer's remaining lease, even after a short write.

    def finish(self, slot):
        if slot['failed']:
            raise BudgetRefusal('failed writer cannot become complete')
        slot['completed_physical'] = slot['physical']
        slot['completed_identity'] = slot.get('identity')
        slot['complete'] = True
        if slot['name'] not in FIXED:
            # Release only unused capacity of a verified closed successful file.
            # Written bytes remain charged permanently under the final name.
            slot['physical_limit'] = slot['physical']
            slot['expanded_limit'] = slot['expanded']
        self.require_fit()


class OSOperations:
    """Stdlib operations. No replacement or race protection beyond ownership."""
    def census(self, directory):
        rows = []
        with os.scandir(directory) as it:
            for entry in it:
                if len(rows) == MAX_ENTRIES:
                    raise BudgetRefusal('bounded directory census')
                row = entry.stat(follow_symlinks=False)
                if not stat.S_ISREG(row.st_mode) or row.st_nlink != 1:
                    raise BudgetRefusal('exclusive regular files only; no aliases')
                rows.append(dict(name=entry.name, bytes=row.st_size,
                                 identity=(row.st_dev, row.st_ino)))
        return rows

    def open(self, path):
        flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
        flags |= getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_BINARY', 0)
        fd = os.open(path, flags, 0o600)
        try:
            return os.fdopen(fd, 'wb', buffering=0)
        except BaseException as primary:
            try:
                os.close(fd)
            except BaseException as secondary:
                try:
                    primary.aggregate_open_cleanup_error = secondary
                except BaseException:
                    pass
            raise

    def metadata(self, output):
        row = os.fstat(output.fileno())
        if not stat.S_ISREG(row.st_mode) or row.st_nlink != 1:
            raise BudgetRefusal('owned output must remain one regular inode')
        return dict(bytes=row.st_size, identity=(row.st_dev,row.st_ino))

    def write(self, output, raw):
        return output.write(raw)

    def flush(self, output):
        output.flush()

    def sync(self, output):
        os.fsync(output.fileno())

    def close(self, output):
        output.close()

    def rename(self, partial, final):
        if os.path.lexists(final):
            raise BudgetRefusal('final path exists; no overwrite')
        # Portable cooperative-exclusive protocol. An adversarial creator could
        # race this check on POSIX; such a writer violates declared ownership.
        os.rename(partial, final)


class AggregateWriter:
    """One directory owner; every writer/parent log sink uses shared ceilings.

    check/custody/first_fault are real Root callbacks. negative_gate is a
    separately reviewed metadata-only closure gate, not positive check bypass.
    """
    def __init__(self, directory, *, check, custody, first_fault, negative_gate,
                 clock, work_deadline_ns, overall_deadline_ns, operations=None):
        if type(directory) is not str or not os.path.isabs(directory) or os.path.realpath(directory) != directory or os.path.islink(directory):
            raise BudgetRefusal('canonical exclusively owned directory required')
        for cb in (check, custody, first_fault, negative_gate, clock):
            if not callable(cb):
                raise BudgetRefusal('real callback contract required')
        exact_uint(work_deadline_ns, 'absolute work deadline')
        exact_uint(overall_deadline_ns, 'absolute overall deadline')
        if work_deadline_ns < 180000000000 or overall_deadline_ns != work_deadline_ns + 30000000000:
            raise BudgetRefusal('original absolute180/210 epoch required')
        self.directory = directory; self.check = check; self.custody = custody
        self.first_fault = first_fault; self.negative_gate = negative_gate; self.clock = clock
        self.work_deadline = work_deadline_ns; self.overall_deadline = overall_deadline_ns
        self.ops = OSOperations() if operations is None else operations
        self.busy = False; self.negative_attempted = False; self.owners = []
        self._gate(False, None)
        self.initial_entries = self.ops.census(directory)
        self.ledger = AggregateLedger(self.initial_entries)
        self._gate(False, None)

    def _gate(self, negative, primary):
        now = exact_uint(self.clock(), 'monotone clock')
        if now >= (self.overall_deadline if negative else self.work_deadline):
            raise BudgetRefusal('original absolute time cutoff')
        if negative:
            if self.negative_gate(primary) is not None:
                raise BudgetRefusal('negative metadata gate must return None')
        else:
            self.check()
            fault = self.first_fault()
            if fault is not None:
                raise fault
        if self.custody('negative' if negative else 'positive', primary) is not None:
            raise BudgetRefusal('real Source/byte custody must return None')
        now = exact_uint(self.clock(), 'monotone clock after custody')
        if now >= (self.overall_deadline if negative else self.work_deadline):
            raise BudgetRefusal('operation did not complete before original cutoff')

    def _latch(self, error):
        self.owners.append(error)
        try:
            root = self.first_fault()
        except BaseException as secondary:
            self.owners.append(secondary)
            root = None
        primary = root if root is not None else self.ledger.primary
        if primary is None:
            primary = error
        self.ledger.primary = primary
        return primary

    def _observe(self, slot, output, strict=False):
        try:
            metadata = self.ops.metadata(output)
            if slot.get('identity') is not None and slot['identity'] != metadata['identity']:
                raise BudgetRefusal('owned open file identity changed')
            slot['identity'] = metadata['identity']
            if strict and metadata['bytes'] != slot['physical']:
                raise BudgetRefusal('completed write size differs from charged chunks')
            self.ledger.observed(slot, metadata['bytes'])
        except BaseException as secondary:
            slot['physical_exact'] = False
            self.ledger.unavailable_physical = True
            self.ledger.secondaries.append(secondary); self.owners.append(secondary)

    def _final_census(self, name, slot):
        rows = self.ops.census(self.directory)
        found = {r['name']: r for r in rows}
        if len(found) != len(rows):
            raise BudgetRefusal('distinct final census entries required')
        for prior in self.initial_entries:
            current = found.get(prior['name'])
            if current is None or current['identity'] != prior['identity']:
                raise BudgetRefusal('prior file removed or replaced')
            if prior['name'] in ('stdout.bin', 'stderr.bin'):
                old = self.ledger.slots[prior['name']]
                self.ledger.observed(old, current['bytes'])
                old['expanded'] = old['physical']
            elif current['bytes'] != prior['bytes']:
                raise BudgetRefusal('opaque preexisting file changed')
        allowed = set(self.ledger.prior)
        for key, item in self.ledger.slots.items():
            if key in ('stdout.bin', 'stderr.bin'):
                allowed.add(key)
                current = found.get(key)
                if current is not None:
                    self.ledger.observed(item,current['bytes'])
                    item['expanded'] = item['physical']
                continue
            if item['attempted']:
                allowed.add(key); allowed.add(key + '.partial')
                current = found.get(key); unfinished = found.get(key + '.partial')
                if current is not None and unfinished is not None:
                    raise BudgetRefusal('writer cannot have both final and partial aliases')
                observed = current if current is not None else unfinished
                if observed is None:
                    if item['physical'] or item['complete']:
                        raise BudgetRefusal('owned written file disappeared')
                else:
                    if item.get('identity') is not None and item['identity'] != observed['identity']:
                        raise BudgetRefusal('owned file replaced')
                    self.ledger.observed(item,observed['bytes'])
                    if item['complete'] and (current is None or item['physical'] != item['completed_physical'] or
                                             current['identity'] != item['completed_identity']):
                        raise BudgetRefusal('closed successful file changed')
        if any(key not in allowed for key in found):
            raise BudgetRefusal('unleased file appeared')
        final = found.get(name)
        if final is None or name + '.partial' in found or final['bytes'] != slot['physical']:
            raise BudgetRefusal('rename must transfer the same whole bytes once')
        self.ledger.require_fit()

    def write_record(self, name, producer, *, physical_limit, expanded_limit,
                     kind='bulk', primary=None):
        negative = kind == 'negative-summary'
        if self.busy:
            raise BudgetRefusal('single cooperative writer; no reentrancy')
        if not callable(producer):
            raise BudgetRefusal('synchronous producer callable required')
        if negative and not isinstance(primary, BaseException):
            raise BudgetRefusal('negative summary requires retained primary')
        if not negative and primary is not None:
            raise BudgetRefusal('primary argument belongs only to negative closure')
        if negative:
            if self.negative_attempted:
                raise BudgetRefusal('negative summary is once-only, no retry')
            self.negative_attempted = True
            primary = self._latch(primary)
        if not negative and self.ledger.primary is not None:
            raise self.ledger.primary
        self.busy = True; output = None; slot = None
        self.owners.append(producer)
        if primary is not None:
            self.owners.append(primary)
        partial = os.path.join(self.directory, name + '.partial') if type(name) is str else None
        final = os.path.join(self.directory, name) if type(name) is str else None
        try:
            self._gate(negative, primary)
            slot = self.ledger.claim(name, physical_limit, expanded_limit, kind)
            output = self.ops.open(partial)
            digest = hashlib.sha256()
            while True:
                self._gate(negative, primary)
                piece = producer()
                self._gate(negative, primary)
                if piece is None:
                    break
                if type(piece) is not tuple or len(piece) != 2 or type(piece[0]) is not bytes:
                    raise BudgetRefusal('exact (bytes, full-expanded-charge) chunk required')
                raw, expanded = piece
                self.ledger.before_chunk(slot, len(raw), expanded)
                written = self.ops.write(output, raw)
                if type(written) is not int or written != len(raw):
                    self._observe(slot, output)
                    raise BudgetRefusal('short/invalid write; never retry remainder')
                self.ledger.completed_chunk(slot, written, expanded)
                digest.update(raw)
            self._gate(negative, primary)
            self.ops.flush(output); self._gate(negative, primary)
            self.ops.sync(output); self._gate(negative, primary)
            self._observe(slot, output, strict=True)
            if not slot['physical_exact']:
                raise BudgetRefusal('unavailable exact file size at completion')
            self.ops.close(output); output = None
            self._gate(negative, primary)
            self.ops.rename(partial, final)
            self._gate(negative, primary)
            self._final_census(name, slot)
            self._gate(negative, primary)
            self.ledger.finish(slot)
            return dict(schema='aggregate-writer-candidate-v1', name=name,
                bytes=slot['physical'], expanded_bytes=slot['expanded'], sha256=digest.hexdigest(),
                complete=True, diagnostic_only=negative or type(self.ops) is not OSOperations,
                stdlib_operations=type(self.ops) is OSOperations, authority=False,
                mathematical_admission=False, resource_admission=False,
                ledger=self.ledger.snapshot())
        except BaseException as error:
            if slot is not None:
                self.ledger.failed(slot)
            if output is not None:
                self._observe(slot, output)
                try:
                    self.ops.close(output)
                except BaseException as secondary:
                    self.ledger.secondaries.append(secondary); self.owners.append(secondary)
            selected = self._latch(primary if primary is not None else error)
            if primary is not None and error is not primary:
                self.ledger.secondaries.append(error); self.owners.append(error)
            try:
                selected.aggregate_byte_budget_prefix = self.ledger.snapshot()
            except BaseException:
                pass
            raise selected
        finally:
            self.busy = False

    def attempt_negative_summary(self, primary, raw):
        """Diagnostic-only bounded bytes; no parse/format/repair of any prefix."""
        if not isinstance(primary, BaseException):
            raise BudgetRefusal('exact retained primary exception required')
        self.owners.append(primary)
        used = False
        def producer():
            nonlocal used
            if used:
                return None
            used = True
            if type(raw) is not bytes or len(raw) > SUMMARY_CAP or not raw:
                raise BudgetRefusal('bounded already-built negative summary bytes required')
            return raw, len(raw)
        self.owners.append(producer)
        try:
            receipt = self.write_record('worker-failure-summary.json', producer,
                physical_limit=SUMMARY_CAP, expanded_limit=SUMMARY_CAP,
                kind='negative-summary', primary=primary)
        except BaseException as secondary_or_primary:
            self.owners.append(secondary_or_primary)
            return dict(schema='negative-summary-attempt-v1', complete=False,
                primary_retained=True, diagnostic_only=True, authority=False,
                mathematical_admission=False, resource_admission=False,
                ledger=self.ledger.snapshot())
        return dict(schema='negative-summary-attempt-v1', complete=True,
            primary_retained=True, diagnostic_only=True, authority=False,
            mathematical_admission=False, resource_admission=False, receipt=receipt)
