"""SOURCE ONLY. Complete old-packet parent for proposed, unadopted G1.

No top-level operations/imports. Root supplies pinned codec/checker dependencies,
genuine checks, read-only argument custody, and an actual retaining callback.
This is a candidate certificate builder, never an admission or proof checker.
"""
VERSION = 'linked-complete-batch-evidence-v1'
GATE = 'PROPOSED_G1_UNIQUE_TYPED_VALUES_ALL_ORDERED_OCCURRENCES_V1'
CODEC_PIN = '0f0cdf59ca7b676dd0bb86a7ff18be4ea6ca9a681d47b740d53db4e885e300b5'
PREDECESSOR_WORKER_PIN = '9ea014de87d5af2ed3017442f690699a0ef54750c8d8be12890e373936b65a03'
TOP_FIELDS = ('schema','status','inputs','small_palettes','large_palette','graphs',
    'diagnostics','call_receipts','call_started','call_completed','call_raised',
    'root_callbacks','batch_inputs','profile_rows','profile_metrics',
    'profile_accounting','batch_diagnostics','batch_diagnostic_progress',
    'full_VM_implemented','full_FOL_palette_qualified','proof_discovery',
    'full_pipeline_qualified','mathematical_authority','scope')
ENVELOPE_FIELDS = ('schema','gate_contract','predecessor_worker_sha256','manifest',
    'raw_banks','canonical_packet','events','bindings','coverage',
    'G1_adopted','runtime_qualified','mathematical_authority')
_OWNER = object()


class Invalid(Exception):
    def __init__(self, reason, *, _owner=None):
        self.reason, self._owner = reason, _owner
        super().__init__(reason)


def _need(ok, reason):
    if not ok:
        raise Invalid(reason, _owner=_OWNER)


def is_own_invalid(error):
    return type(error) is Invalid and error._owner is _OWNER


def literal_copy(value, *, check, maximum_depth=256):
    """Fresh, exact finite literal snapshot; raw identity belongs to Root.

    No repr/coercion/nonliteral stand-in. Called only within a future actual.
    Numeric/size bounds are Root's finite declared codec/schema quotas.
    """
    active = set()
    def copy(x, depth):
        check()
        _need(depth <= maximum_depth, 'literal snapshot depth')
        kind = type(x)
        if x is None or kind in (bool, int, str):
            return x
        if kind is float:
            _need(x.hex() not in ('inf','-inf','nan'), 'old canonical packet excludes nonfinite float')
            return x
        _need(kind in (list,tuple,dict), 'unsupported live literal carrier')
        _need(id(x) not in active, 'cyclic live value')
        active.add(id(x))
        if kind is dict:
            result = {}
            for key, item in x.items():
                check()
                result[copy(key,depth+1)] = copy(item,depth+1)
        else:
            rows = []
            for item in x:
                rows.append(copy(item,depth+1))
            result = rows if kind is list else tuple(rows)
        active.remove(id(x))
        return result
    return copy(value, 0)


class EvidenceJournal:
    """Live immutable snapshots, one ordinal per occurrence, no deduplication.

    owners contains original callbacks/arguments/results/errors and retains them
    through Root final custody. Serialized ordinals never reconstruct owners.
    No object is released when a scope closes or a snapshot refuses.
    """
    def __init__(self, *, check, retain, scope):
        _need(callable(check) and callable(retain) and callable(scope), 'genuine journal callbacks')
        self.check, self.scope = check, scope
        self.events, self.stack, self.owners = [], [], [check,retain,scope]
        self.pending, self.closed, self.primary = {}, False, None
        if retain(self) is not None:
            raise Invalid('Root must retain journal and return None', _owner=_OWNER)

    def _append(self, phase, kind, role, operation, scope, entry, arguments, value, error):
        self.owners.append((arguments,value,error,scope))
        ordinal = len(self.events) + 1
        # Reserve the occurrence before any copy/check can fail. Such a row is
        # explicitly incomplete and cannot be admitted; its raw owners survive.
        row = dict(ordinal=ordinal,phase=phase,kind=kind,role=role,operation=operation,
            scope=None,entry=entry,parent=self.stack[-1] if self.stack else None,
            arguments=None,value=None,error=None,complete=False)
        self.events.append(row)
        row['scope'] = literal_copy(scope,check=self.check)
        row['arguments'] = literal_copy(arguments,check=self.check)
        row['value'] = literal_copy(value,check=self.check)
        if error is not None:
            # No str(error), no hostile prefix walk. Actual exact error retained.
            row['error'] = dict(type_name=type(error).__name__,
                type_module=type(error).__module__,replayable=False)
        row['complete'] = True
        return ordinal

    def enter(self, kind, role, operation, arguments, scope=None):
        _need(not self.closed, 'journal closed')
        scope = self.scope() if scope is None else scope
        token = self._append('ENTER',kind,role,operation,scope,None,arguments,None,None)
        self.stack.append(token)
        self.pending[token] = (kind,role,operation,scope)
        return token

    def leave(self, token, *, arguments=None, value=None, error=None):
        _need(self.stack and self.stack[-1] == token and token in self.pending,
              'exact nested occurrence exit')
        kind,role,operation,scope = self.pending[token]
        phase = 'RAISE' if error is not None else 'RETURN'
        ordinal = self._append(phase,kind,role,operation,scope,token,arguments,value,error)
        self.stack.pop()
        del self.pending[token]
        return ordinal

    def snapshot(self, kind, role, operation, value, scope=None):
        _need(not self.closed, 'journal closed')
        scope = self.scope() if scope is None else scope
        return self._append('SNAPSHOT',kind,role,operation,scope,None,None,value,None)

    def finish(self):
        _need(not self.closed and not self.stack and not self.pending, 'all live occurrences closed')
        _need(all(row['complete'] is True for row in self.events), 'no incomplete event admitted')
        self.closed = True
        self.check()
        return self.events


def _bindings(packet, check):
    """Producer catalog. Decoder builds/checks its own catalog independently.

    A subtree binding owns ALL descendants with original type/order, including
    dynamic map keys. It is not a summary or a promise to regenerate a value.
    """
    rows = []
    def add(path, role, case=None, profile=None, group=None, variant=None, run=None):
        check()
        rows.append(dict(ordinal=len(rows)+1,path=path,role=role,case=case,
                         profile=profile,group=group,variant=variant,run=run))
    for key in TOP_FIELDS:
        add((key,), 'predecessor-topfield')
    for i, case in enumerate(packet['small_palettes']):
        path=('small_palettes',i); cid=case['id']
        add(path,'normal-small',cid)
        for key in ('input','legacy_palette','semantic_tiles'):
            add(path+(key,), 'independent-'+key,cid)
        for j, unused in enumerate(case['queries']):
            add(path+('queries',j),'small-query-group',cid)
    add(('large_palette',),'normal-large',packet['large_palette']['id'])
    add(('large_palette','legacy_cardinality'),'independent-cardinality',packet['large_palette']['id'])
    for key in ('global_rank_samples','focused_families'):
        for i, unused in enumerate(packet['large_palette'][key]):
            add(('large_palette',key,i),'large-'+key,packet['large_palette']['id'])
    for i, case in enumerate(packet['graphs']):
        path=('graphs',i); cid=case['id']
        add(path,'normal-graph',cid)
        for key in ('input','instance','legacy_problem','independent_solution_ids'):
            add(path+(key,),'independent-'+key,cid)
        for j, unused in enumerate(case['observations']):
            add(path+('observations',j),'graph-observation',cid)
            add(path+('observations',j,'independent_domains'),'independent-domains',cid)
        for key in ('journal','query_journal','solutions'):
            for j, unused in enumerate(case['result'][key]):
                add(path+('result',key,j),'graph-'+key,cid)
    for i, row in enumerate(packet['diagnostics']):
        add(('diagnostics',i),'legacy-diagnostic',row['id'])
    for i, row in enumerate(packet['call_receipts']):
        add(('call_receipts',i),'standalone-call-receipt')
    for i, row in enumerate(packet['profile_rows']):
        add(('profile_rows',i),'wrapper-profile',profile=row['id'])
    for i, row in enumerate(packet['profile_accounting']):
        add(('profile_accounting',i),'profile-accounting',profile=row['id'])
    for i, group in enumerate(packet['batch_diagnostics']):
        path=('batch_diagnostics',i); gid=group['id']
        add(path,'new-diagnostic-group',group=gid)
        for j, variant in enumerate(group['variants']):
            vpath=path+('variants',j); vid=variant['id']
            add(vpath,'new-diagnostic-variant',group=gid,variant=vid)
            for k, unused in enumerate(variant.get('runs',[])):
                pid=vid+':baseline' if k==0 and group['recipe'] in ('work-cumulative','receipt-items-cumulative') else vid
                add(vpath+('runs',k),'new-diagnostic-profile',profile=pid,group=gid,variant=vid,run=k)
    add(('batch_diagnostic_progress',),'complete-progress-view')
    return rows


def full_tree_measure(value, *, check):
    """Exact unshared typed TREE measure, separately reported, never G0 JSON.

    Tag + minimal unsigned lengths; children are fully recursively inlined.
    This diagnostic measure counts every occurrence and never supplies answers.
    It is deliberately different from both unique DAG charge and old G0 JSON.
    """
    def width(n):
        check();return max(1,(n.bit_length()+6)//7)
    active=set()
    def visit(x,depth):
        check();_need(depth<=256,'tree measure depth')
        kind=type(x)
        if x is None or kind is bool:return 1,1
        if kind is int:
            size=(abs(x).bit_length()+7)//8
            return 2+width(size)+size,1
        if kind is float:
            size=len(x.hex().encode('ascii'))
            return 1+width(size)+size,1
        if kind is str:
            size=len(x.encode('utf8','surrogatepass'))
            return 1+width(size)+size,1
        _need(kind in (list,tuple,dict) and id(x) not in active,'finite strict tree value')
        active.add(id(x));total=1+width(len(x));items=1
        if kind is dict:
            for k,v in x.items():
                for child in (k,v):
                    size,count=visit(child,depth+1);total+=size;items+=count
        else:
            for child in x:
                size,count=visit(child,depth+1);total+=size;items+=count
        active.remove(id(x));return total,items
    size,items=visit(value,0)
    return dict(full_typed_tree_bytes=size,full_typed_tree_occurrences=items,
                old_G0_JSON_measure=False,charged_as_G1_unique_owner_bytes=False)


def assemble(packet, manifest, raw_banks, events, *, check, retain):
    """Retain whole old packet plus complete new bindings; no old field removed."""
    state=dict(schema='linked-parent-build-lifetime-v1',packet=packet,manifest=manifest,
               raw_banks=raw_banks,events=events,bindings=None,envelope=None,error=None)
    _need(callable(retain) and retain(state) is None, 'Root aggregate retained')
    try:
        check()
        _need(type(packet) is dict and tuple(packet)==TOP_FIELDS, 'exact24 predecessor fields/order')
        bindings=_bindings(packet,check);state['bindings']=bindings
        envelope=dict(schema=VERSION,gate_contract=GATE,predecessor_worker_sha256=PREDECESSOR_WORKER_PIN,
            manifest=manifest,raw_banks=raw_banks,canonical_packet=packet,events=events,
            bindings=bindings,coverage=dict(top_fields=TOP_FIELDS,normal_cases=15,
                legacy_diagnostics=33,new_groups=28,new_variants=55,
                full_literal_descendants=True,live_occurrences_required=True,
                raw_runtime_custody_reconstructed=False),
            G1_adopted=False,runtime_qualified=False,mathematical_authority=False)
        state['envelope']=envelope
        check()
        return envelope
    except BaseException as error:
        state['error']=error
        raise


def encode_candidate(envelope, *, codec, checker, expected, check, codec_limits, retain):
    """Build complete wire, independently decode and validate every full root.

    Root must Source-bind codec/checker and callbacks, including their closure
    owners. Neither supplied module is trusted merely because VERSION matches.
    This API itself returns no mathematical, resource or runtime admission.
    """
    state=dict(schema='linked-parent-codec-lifetime-v1',envelope=envelope,expected=expected,
        codec=codec,checker=checker,encode=None,decode=None,validation=None,error=None)
    _need(callable(retain) and retain(state) is None, 'Root complete candidate retained')
    try:
        check()
        encoded=codec.encode_values((envelope,),check=check,limits=codec_limits,retain=retain)
        state['encode']=encoded
        wire=encoded['wire']
        decoded=codec.decode_values(wire,check=check,limits=codec_limits,retain=retain)
        state['decode']=decoded
        _need(type(decoded['values']) is tuple and len(decoded['values'])==1,'one total parent root')
        validation=checker.validate_parent(decoded['values'][0],expected=expected,check=check,retain=retain)
        state['validation']=validation
        owner_measures=[]
        for field in ENVELOPE_FIELDS:
            owner_measures.append(dict(path=(field,),measure=full_tree_measure(envelope[field],check=check)))
        state['owner_measures']=owner_measures
        full_parent_tree_measure=full_tree_measure(envelope,check=check)
        state['full_parent_tree_measure']=full_parent_tree_measure
        check()
        return dict(schema='linked-parent-candidate-receipt-v1',wire=wire,
            stored_bytes=len(wire),G1_unique_owner_charge_bytes=len(wire),
            charge_contract=GATE,old_G0_unfolding_charged=False,
            validation=validation,encode_work=encoded['attempted_work'],
            decode_work=decoded['attempted_work'],owner_full_tree_measures=owner_measures,G1_adopted=False,
            full_parent_tree_measure=full_parent_tree_measure,
            runtime_qualified=False,resource_accepted=False,mathematical_authority=False)
    except BaseException as error:
        state['error']=error
        raise
