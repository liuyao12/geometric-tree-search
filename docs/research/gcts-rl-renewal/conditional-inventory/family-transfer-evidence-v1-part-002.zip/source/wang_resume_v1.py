"""Retain original three jobs (including UNKNOWN); execute only unrun fourth.

The original driver incorrectly asserted that every qualification result must
be VERIFIED. The search limit is unchanged and no earlier job is re-executed.
"""
import importlib.util
from pathlib import Path
import resource
import sys
import time
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('original_transfer_driver',ROOT/'source/transfer_study_v1.py')
D=importlib.util.module_from_spec(spec);spec.loader.exec_module(D)

def main():
    started=time.perf_counter();phase='wang-recovery'
    try:
        old=D.read('data/wang-protocol-v1.json');D.unchanged(old)
        protocol=D.freeze(phase)
        assert not (ROOT/'data/wang-results-v1.json').exists()
        prepared=D.read('data/wang-inputs-v1.json.gz');input_ref=dict(path='data/wang-inputs-v1.json.gz',**D.pin(ROOT/'data/wang-inputs-v1.json.gz'))
        records=[]
        for i,item in enumerate(prepared[:3]):
            cid=item['fixture']['id'];record=D.read('data/wang/'+cid+'-record.json')
            raw=D.read(record['raw']['path'])
            assert D.pin(ROOT/record['raw']['path'])=={k:record['raw'][k] for k in ('bytes','sha256')}
            assert raw['model']==item['model'] and raw['fixture']==item['fixture']
            assert raw['universe_ref']==dict(**input_ref,pointer='/'+str(i)+'/universe')
            assert raw['result']['status']==record['result']
            assert record['result']==('UNKNOWN' if i==2 else 'SAT')
            records.append(record)
        item=prepared[3];cid=item['fixture']['id']
        assert not (ROOT/('data/runs/'+cid+'-started-v1.json')).exists()
        assert not (ROOT/('data/runs/'+cid+'-raw.json.gz')).exists()
        base='companion/wang-point-join-v1/'
        oracle=D.mod('resumed_wang_oracle',base+'reference/wang_model_checker_v1.py')
        engine=D.mod('resumed_wang_engine',base+'reference/growing_point_search_v2.py')
        checker=D.mod('resumed_wang_frontier',base+'reference/frontier_trace_checker_v1.py')
        admitted=oracle.verify_model(item);admission=D.save('data/wang/'+cid+'-model-check.json',admitted)
        assert admitted['status']=='VERIFIED'
        raw,record=D.run_point(engine,checker,cid,item['model'],None,item['universe'],
            dict(**input_ref,pointer='/3/universe'),dict(kind='WANG',fixture=item['fixture'],model_check=admission))
        checked=oracle.verify_result(item,raw['result']);check_ref=D.save('data/wang/'+cid+'-decode-check.json',checked)
        record.update(kind='WANG',fixture=item['fixture'],model_check=admission,decode_check=check_ref)
        D.save('data/wang/'+cid+'-record.json',record);records.append(record)
        assert record['assurance']!='REJECTED' and checked['status']!='REJECTED'
        D.unchanged(protocol);D.unchanged(old)
        D.save('data/wang-results-v1.json',dict(status='SCHEDULE_EXECUTED_WITH_RECOVERY',records=records,
            original_completed_jobs_retained=3,only_new_jobs=[cid],unknown_preserved=[records[2]['id']],
            sources_unchanged=True,original_driver_assertion='Unexpected UNKNOWN stopped original schedule; no search invalidity or resource change.'))
    finally:
        D.save('review/'+phase+'-invocation-v1.json',dict(status='FAILED' if sys.exc_info()[0] else 'COMPLETE',
            phase=phase,main_seconds=time.perf_counter()-started,platform=sys.platform,
            ru_maxrss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            scope='Recovery process only; original execution remains separately charged.'))
if __name__=='__main__':main()
