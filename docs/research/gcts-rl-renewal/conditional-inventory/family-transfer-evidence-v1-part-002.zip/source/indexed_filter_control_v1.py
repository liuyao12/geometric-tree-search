"""Indexed access to the EXACT already-admitted explicit FILTER inventory.

No classification, certificate generation, proof/control result, or search is
used here. The immutable full filtered universe defines this control; every
packet is its complete pure-current-t/m-compatible incident subset, BEFORE
selected/excluded filtering by the unchanged engine.
"""
import copy
import hashlib
import json
import time

VERSION = 'PFT-indexed-filter-control-v1'
ABI = 'IP-CURRENT-TM-INCIDENT-v1'


def _need(condition, reason):
    if not condition:
        raise ValueError(reason)


def _text(value):
    return json.dumps(value,sort_keys=True,ensure_ascii=True,separators=(',', ':'),allow_nan=False)


def _sha(value):
    return hashlib.sha256((_text(value)+'\n').encode('ascii')).hexdigest()


def _fields(value, names, reason):
    _need(type(value) is dict and set(value) == set(names),reason)


def _row(row, capacity):
    """Freeze a canonical admitted row, preserving its exact CID and supports."""
    _fields(row,('id','t','m'),'FILTER_ROW_FIELDS')
    _need(type(row['id']) is str and row['id'],'FILTER_CID')
    frozen = []
    for field in ('t','m'):
        rows = row[field]
        _need(type(rows) is list and (rows or field == 'm'),'FILTER_SUPPORT_LIST')
        result,previous = [],None
        for pair in rows:
            _need(type(pair) is list and len(pair) == 2 and type(pair[0]) is str,'FILTER_SUPPORT_ROW')
            point,value = pair
            _need(previous is None or previous < point,'FILTER_SUPPORT_ORDER_OR_DUPLICATE')
            previous = point
            if field == 't':
                _need(type(value) is int and 0 < value <= capacity,'FILTER_POSITIVE_T_UNITS')
            else:
                _need(type(value) is str,'FILTER_LITERAL_M_VALUE')
            result.append((point,value))
        frozen.append(tuple(result))
    return (row['id'],frozen[0],frozen[1])


class Provider:
    incident_query_abi = ABI

    def __init__(self, identity, capacity, universe):
        self.identity,self.capacity = identity,capacity
        self._rows = tuple(_row(row,capacity) for row in universe)
        _need(all(a[0] < b[0] for a,b in zip(self._rows,self._rows[1:])),'FILTER_CID_ORDER_OR_DUPLICATE')
        postings = {}
        for ordinal,(_,ts,_) in enumerate(self._rows):
            for point,_ in ts:
                postings.setdefault(point,[]).append(ordinal)
        # Each posting follows the globally sorted CID order. A complete scan
        # therefore returns sorted rows, without a policy-dependent reordering.
        self._by_point = {p:tuple(indices) for p,indices in postings.items()}
        self._calls = self._completed = self._work = self._potential = self._returned = 0
        self._seconds = 0.0
        self._index_postings = sum(len(v) for v in self._by_point.values())

    def _context(self,query,reserve):
        reserve()
        _fields(query,('schema','inventory_identity','point','capacity','totals','marks'),'QUERY_FIELDS')
        _need(type(query['schema']) is str and query['schema'] == 'IP-current-tm-incident-query-v1'
              and type(query['inventory_identity']) is str and query['inventory_identity'] == self.identity
              and type(query['point']) is str and type(query['capacity']) is int
              and query['capacity'] == self.capacity,'QUERY_BINDING')
        tables = []
        for field in ('totals','marks'):
            rows = query[field]
            _need(type(rows) is list,'QUERY_CONTEXT_LIST')
            reserve(1+2*len(rows))
            previous,table = None,{}
            for row in rows:
                reserve()
                _need(type(row) is list and len(row) == 2 and type(row[0]) is str,'QUERY_CONTEXT_ROW')
                point,value = row
                reserve(4+12*len(point))
                _need(previous is None or previous < point,'QUERY_CONTEXT_ORDER_OR_DUPLICATE')
                previous = point
                if field == 'totals':
                    _need(type(value) is int and 0 <= value <= self.capacity,'QUERY_TOTAL')
                else:
                    _need(type(value) is str,'QUERY_MARK')
                    reserve(4+12*len(value))
                table[point] = value
            tables.append(table)
        # All flat container/scalar types are checked before JSON. Reserve
        # worst-case escaping BEFORE canonical serialization and hashing.
        reserve(512+12*len(self.identity)+12*len(query['point']))
        raw = (_text(query)+'\n').encode('ascii')
        reserve(len(raw))
        return query['point'],tables[0],tables[1],hashlib.sha256(raw).hexdigest()

    def __call__(self,query,charge):
        started = time.perf_counter()
        self._calls += 1

        def reserve(units=1):
            # Owned engine refusals propagate, including during context/copy.
            charge(units)
            self._work += units

        try:
            point,totals,marks,context_hash = self._context(query,reserve)
            posting = self._by_point.get(point,())
            reserve(1+len(posting))
            out = []
            for ordinal in posting:
                cid,ts,ms = self._rows[ordinal]
                reserve(2+len(ts)+len(ms))
                compatible = True
                for p,n in ts:
                    reserve(2+len(p))
                    if totals.get(p,0)+n > self.capacity:
                        compatible = False
                        break
                if not compatible:
                    continue
                for p,value in ms:
                    reserve(2+len(p)+len(value))
                    if p in marks:
                        reserve(1+len(marks[p]))
                        if marks[p] != value:
                            compatible = False
                            break
                if compatible:
                    # Strings/ints are immutable; detach every returned list
                    # and dict so neither callback consumer nor engine can
                    # modify the immutable indexed universe.
                    reserve(4+len(cid)+3*len(ts)+3*len(ms))
                    out.append(dict(id=cid,t=[[p,n] for p,n in ts],m=[[p,v] for p,v in ms]))
            self._completed += 1
            self._potential += len(posting)
            self._returned += len(out)
            return dict(point=point,context_sha256=context_hash,complete=True,placements=out,
                certificate=dict(scope='COMPLETE_CURRENT_TM_COMPATIBLE_INCIDENT_SET',
                    potential_count=len(posting),compatible_count=len(out)))
        finally:
            self._seconds += time.perf_counter()-started

    def snapshot(self):
        return dict(implementation_version=VERSION,incident_query_abi=ABI,identity=self.identity,
            calls=self._calls,completed_calls=self._completed,charged_work=self._work,seconds=self._seconds,
            potential_rows=self._potential,rows=self._returned,omitted_rows=self._potential-self._returned,
            index_rows=len(self._rows),index_points=len(self._by_point),index_postings=self._index_postings,
            scope='Fresh cumulative full-filtered-inventory index telemetry; no classifier/proof/policy state or cached query answers.')


def make_lane(prepared):
    """Fresh indexed FILTER lane from a saved admitted PREPARED object only.

    Setup is outside the engine solve timer and is explicitly measured. It
    reuses the prior checked acquisition/table, whose original costs must also
    remain disclosed by the follow-up driver. No scientific dependency import.
    """
    started = time.perf_counter()
    _need(type(prepared) is dict and prepared.get('status') == 'PREPARED','ADMITTED_PREPARATION_REQUIRED')
    for key in ('profile_check','factory_check'):
        _need(prepared[key]['status'] == 'VERIFIED','PREPARATION_'+key)
    certificate = prepared['failure_certificate']
    absence = prepared['acquisition']['absence_check']
    _need(absence['status'] == 'VERIFIED' and absence['scope_sha256'] == certificate['scope_sha256']
          and absence['certificate_sha256'] == _sha(certificate),'CHECKED_FAILURE_CERTIFICATE_BINDING')
    base = prepared['factory_model']
    _need(base['inventory']['kind'] == 'CERTIFIED_INCIDENT' and
          type(base['inventory']['identity']) is str,'ORIGINAL_BASE_IDENTITY')
    _need(_text(base) == _text(prepared['lanes']['BASE']['model']),'ORIGINAL_BASE_MODEL_BINDING')
    lane = prepared['lanes']['FILTER']
    universe,original = lane['universe'],lane['model']
    _fields(original,('schema','version','capacity','roots','seed','inventory'),'FILTER_MODEL_FIELDS')
    _need(original['schema'] == 'Z-growing-point-model-v1' and original['capacity'] == 2
          and type(original['capacity']) is int,'FILTER_MODEL_SCHEMA_CAPACITY')
    _need(type(universe) is list and len(universe) <= 30000,'FULL_FILTERED_UNIVERSE_RESOURCE_BOUND')
    _fields(original['inventory'],('kind','placements'),'ORIGINAL_EXPLICIT_FILTER_INVENTORY')
    _need(original['inventory']['kind'] == 'EXPLICIT' and
          _text(original['inventory']['placements']) == _text(universe),'EXACT_ORIGINAL_FILTERED_ROWS')
    expected = prepared['universe_pins']['FILTER']
    universe_hash = _sha(universe)
    _need(type(expected['rows']) is int and expected['rows'] == len(universe)
          and expected['sha256'] == universe_hash,'FILTERED_UNIVERSE_PIN')
    for key in ('schema','capacity','roots','seed'):
        _need(_text(original[key]) == _text(base[key]),'FILTER_BASE_'+key)
    preimage = [VERSION,base['inventory']['identity'],universe_hash,
                certificate['scope_sha256'],_sha(certificate['requests'])]
    identity = _text(preimage)
    model = {key:copy.deepcopy(original[key]) for key in ('schema','capacity','roots','seed')}
    model.update(version=VERSION,inventory=dict(kind='CERTIFIED_INCIDENT',identity=identity))
    provider = Provider(identity,model['capacity'],universe)
    return dict(model=model,provider=provider,universe=universe,setup=dict(
        seconds=time.perf_counter()-started,inventory='CERTIFIED_INCIDENT',implementation_version=VERSION,
        identity_preimage=preimage,filtered_universe_sha256=universe_hash,
        checked_failure_certificate_sha256=absence['certificate_sha256'],
        index_rows=len(provider._rows),index_points=len(provider._by_point),index_postings=provider._index_postings,
        scope='Observed fresh exact-index validation/construction/copy cost. Original admitted filtered universe and acquisition are reused; no target proof, old query cache, classifier or extra semantic predicate.'))
