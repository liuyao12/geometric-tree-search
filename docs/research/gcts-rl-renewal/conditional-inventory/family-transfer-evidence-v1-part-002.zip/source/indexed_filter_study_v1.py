"""Prospectively frozen indexed-access follow-up, retaining the original study.

Motivated by explicit FILTER materialization costs observed in the original
paired cohort. Reuses those admitted inputs and certificates, never another
method's selected proof or search trace. Not a new cold/held-out cohort.
"""
import copy
import hashlib
import importlib.util
from pathlib import Path
import resource
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('frozen_original_driver',ROOT/'source/transfer_study_v1.py')
D=importlib.util.module_from_spec(spec);spec.loader.exec_module(D)

def digest(value):
    return hashlib.sha256(D.wire(value)).hexdigest()

def verified_ref(ref):
    assert D.pin(ROOT/ref['path'])=={k:ref[k] for k in ('bytes','sha256')},ref['path']
    return D.read(ref['path'])

def main():
    started=time.perf_counter()
    try:
        original=D.read('data/families-protocol-v1.json');D.unchanged(original)
        prior=D.read('data/family-results-v1.json')
        assert prior['status']=='SCHEDULE_EXECUTED' and len(prior['preparations'])==8
        protocol=D.freeze('indexed-filter')
        control=D.mod('exact_indexed_filter','source/indexed_filter_control_v1.py')
        inputs=D.mod('fresh_transfer_native_decoder','source/transfer_inputs_v1.py')
        engine=D.mod('unchanged_point_engine','reference/upstream/growing_point_search_v2.py')
        checker=D.mod('unchanged_frontier_checker','reference/upstream/frontier_trace_checker_v1.py')
        qualifications=[];records=[]
        for item in prior['preparations']:
            case_id=item['id'];prep_ref=item['prepared'];prepared=verified_ref(prep_ref)
            assert prepared['status']=='PREPARED' and item['status']=='PREPARED'
            job_started=time.perf_counter();lane=control.make_lane(prepared)
            universe=prepared['lanes']['FILTER']['universe']
            certificate=prepared['failure_certificate'];base=prepared['factory_model']
            universe_hash=digest(universe)
            expected_identity=D.wire(['PFT-indexed-filter-control-v1',
                base['inventory']['identity'],universe_hash,certificate['scope_sha256'],
                digest(certificate['requests'])]).decode('ascii').rstrip('\n')
            expected_model={key:copy.deepcopy(base[key]) for key in ('schema','capacity','roots','seed')}
            expected_model.update(version='PFT-indexed-filter-control-v1',
                inventory=dict(kind='CERTIFIED_INCIDENT',identity=expected_identity))
            assert D.wire(lane['model'])==D.wire(expected_model)
            assert D.wire(lane['universe'])==D.wire(universe)
            assert digest(universe)==prepared['universe_pins']['FILTER']['sha256']
            assert prepared['acquisition']['absence_check']['status']=='VERIFIED'
            assert digest(certificate)==prepared['acquisition']['absence_check']['certificate_sha256']
            qualifications.append(dict(case_id=case_id,status='VERIFIED',prepared=prep_ref,
                model_sha256=digest(expected_model),filtered_universe_sha256=universe_hash,
                rows=len(universe),identity_preimage=lane['setup']['identity_preimage'],
                checked_failure_certificate_sha256=digest(certificate),
                scope='Independent model/seed/identity/exact row binding before this search; full packet/graph qualification follows against the saved complete universe. No acquisition or proof replay.'))
            run_id=case_id+'--IFILTER'
            raw,entry=D.run_point(engine,checker,run_id,lane['model'],lane['provider'],universe,
                dict(**prep_ref,pointer='/lanes/FILTER/universe'),
                dict(kind='FAMILY',case_id=case_id,mode='IFILTER',prepared_ref=prep_ref,setup=lane['setup']))
            native=inputs.check_solution(prepared,raw['result'])
            native_ref=D.save('data/runs/'+run_id+'-native-check.json',native)
            entry.update(kind='FAMILY',case_id=case_id,mode='IFILTER',prepared=prep_ref,setup=lane['setup'],
                native_check=native_ref,proof_reader=native.get('proof_reader',[]),theory_reader=prepared['theory_reader'])
            entry['pipeline_seconds_before_record']=time.perf_counter()-job_started
            D.save('data/runs/'+run_id+'-record.json',entry)
            records.append(entry)
            assert entry['assurance']!='REJECTED',(run_id,D.read(entry['graph_check']['path']))
            if raw['result']['status']=='SAT':assert native['status']=='VERIFIED',(run_id,native)
            del raw,prepared,lane,universe
        D.unchanged(protocol);D.unchanged(original)
        D.save('review/indexed-filter-provider-qualification-v1.json',dict(status='VERIFIED',records=qualifications,
            scope='Eight independent model/exact inventory bindings; scientific packet completeness additionally checked by the unchanged full frontier checker per result.'))
        D.save('data/indexed-filter-results-v1.json',dict(status='SCHEDULE_EXECUTED',records=records,sources_unchanged=True,
            preparations=prior['preparations'],followup_scope='Eight prospectively frozen follow-up runs motivated by observed explicit inventory materialization. Exact original filtered universes and admission costs reused. Same original paired cohort, not new held-out/cold trials. Original 32 jobs and all UNKNOWN results retained.'))
    finally:
        D.save('review/indexed-filter-invocation-v1.json',dict(status='FAILED' if sys.exc_info()[0] else 'COMPLETE',
            phase='indexed-filter',main_seconds=time.perf_counter()-started,platform=sys.platform,
            ru_maxrss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            scope='Fresh follow-up invocation including saved-input reads, exact indexing, eight searches, native/frontier assurance and preceding persistence. Original acquisition costs separately retained; not rerun. Darwin RSS high-water bytes.'))

if __name__=='__main__':main()
