"""Prospective richer proof transfer and literal Wang qualification.

Persist every original result before independent assurance. No search consumes
another method's proof, Boolean witness, old library or policy.
"""
import argparse
import copy
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import resource
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
ENGINE_LIMITS=dict(wall_seconds=20,max_work=500000000,max_nodes=5000,
    max_events=50000,max_rollback_records=50000,max_candidates=50000,max_points=4096)
GRAPH_LIMITS=dict(max_items=300000000,wall_seconds=30)
DP_LIMITS=dict(wall_seconds=20,max_work=500000000,max_depth=128,
    max_items=10000000,max_states=200000,max_proof_lines=4096)
AUDIT_BYTES=128*1024*1024

def wire(v):return (json.dumps(v,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')
def pin(p):
    raw=p.read_bytes();return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(name,value):
    p=ROOT/name;p.parent.mkdir(parents=True,exist_ok=True);raw=wire(value)
    if name.endswith('.gz'):raw=gzip.compress(raw,mtime=0)
    with p.open('xb') as f:f.write(raw)
    return dict(path=name,**pin(p))
def read(name):
    p=ROOT/name;raw=p.read_bytes()
    return json.loads(gzip.decompress(raw) if p.suffix=='.gz' else raw)
def mod(name,path):
    spec=importlib.util.spec_from_file_location(name,ROOT/path)
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def freeze(phase):
    paths=sorted(p for folder in ('source','reference','companion') for p in (ROOT/folder).rglob('*') if p.is_file())
    v=dict(schema='PFT-prospective-protocol-v1',phase=phase,
        pins={p.relative_to(ROOT).as_posix():pin(p) for p in paths},
        python=dict(path=sys.executable,version=sys.version,**pin(Path(sys.executable))),
        engine_limits=ENGINE_LIMITS,graph_limits=GRAPH_LIMITS,dp_limits=DP_LIMITS,
        audit_byte_cap=AUDIT_BYTES,lane_rotation=['BASE','MARKS','FILTER'],
        scope='Finite original RF profile and height only. Literal Wang cases are a separate fixed-palette finite circuit qualification; no policy training or universal practical proof-search claim.')
    save('data/'+phase+'-protocol-v1.json',v);return v
def unchanged(protocol):
    for name,expected in protocol['pins'].items():assert pin(ROOT/name)==expected,name

def run_point(engine,checker,case_id,model,provider,universe,universe_ref,extra):
    save('data/runs/'+case_id+'-started-v1.json',dict(id=case_id,universe_ref=universe_ref,
        model_sha256=hashlib.sha256(wire(model)).hexdigest(),limits=ENGINE_LIMITS,extra=extra))
    observations=[];journal=dict(retained_bytes=0,refusal=None)
    def audit(event,state,charge):
        item=dict(event=event,state=state);size=len(wire(item))
        if journal['retained_bytes']+size>AUDIT_BYTES:
            journal['refusal']=dict(reason='AUDIT_STORAGE_BOUND',event_seq=event['seq'],next_bytes=size)
            charge(1<<128) # owned cooperative stop; never a failed-child exclusion
        observations.append(item);journal['retained_bytes']+=size
    kwargs=dict(audit=audit)
    if provider is not None:kwargs['enumerate_incident']=provider
    started=time.perf_counter();result=engine.solve(model,ENGINE_LIMITS,**kwargs)
    seconds=time.perf_counter()-started
    raw=dict(id=case_id,model=model,universe_ref=universe_ref,observations=observations,
        result=result,search_seconds=seconds,journal=journal,**extra)
    raw_ref=save('data/runs/'+case_id+'-raw.json.gz',raw)
    checked=checker.verify(model,universe,observations,result,**GRAPH_LIMITS)
    checked_ref=save('data/runs/'+case_id+'-graph-check.json',checked)
    entry=dict(id=case_id,raw=raw_ref,graph_check=checked_ref,result=result['status'],
        assurance=checked['status'],search_seconds=seconds,events=len(observations),
        journal_bytes=journal['retained_bytes'],journal_refusal=journal['refusal'])
    print(json.dumps(dict(id=case_id,result=result['status'],assurance=checked['status'],events=len(observations))),flush=True)
    return raw,entry

def rf_qualification():
    protocol=freeze('rf-qualification')
    compiler=mod('qualified_finite_basis','reference/upstream/finite_basis_v1.py')
    checker=mod('independent_rf_profile','reference/rf_catalogue_checker_v1.py')
    kernel=mod('native_fol','reference/upstream/independent_fol_checker_v1.py')
    v=lambda n:['var',n];c=['fun','c',[]];f=lambda t:['fun','f',[t]]
    p=lambda t:['pred','P',[t]];r=lambda a,b:['pred','R',[a,b]]
    declarations=[]
    def add(cid,functions,predicates,axioms,goal,terms=(),rounds=1):
        declarations.append(dict(id=cid,problem=dict(theory=dict(functions=functions,predicates=predicates,axioms=axioms),goal=goal),
            terms=list(terms),profile=dict(ui_rounds=rounds,max_terms=20,max_templates=24,max_definitions=8000)))
    add('ui-basic',{'c':0},{'P':1},{'given':['all','x',p(v('x'))]},p(c))
    add('ui-capture',{'c':0},{'R':2},{'given':['all','x',['all','y',r(v('x'),v('y'))]]},['all','y',r(c,v('y'))],[v('y')],2)
    add('equality-contexts',{'c':0,'f':1},{},{'given':['all','x',['eq',f(v('x')),v('x')]]},['all','x',['eq',f(f(v('x'))),f(v('x'))]])
    e=['eq',c,c]
    add('repeated-equality',{'c':0},{},{'given':['and',e,e]},e,rounds=0)
    add('fresh-hole',{'c':0,'f':1},{},{'given':['all','__rf_hole',['eq',f(v('__rf_hole')),v('__rf_hole')]]},e,rounds=0)
    save('data/rf-qualification-declarations-v1.json',declarations);records=[];compiled_inputs={}
    for d in declarations:
        compiled,generation=compiler.compile_case(d)
        raw=save('data/rf-qualification/'+d['id']+'-compiled.json.gz',dict(declaration=d,compiled=compiled,generation=generation))
        receipt=checker.verify(d,compiled,generation)
        zero=[kernel.check(compiled['theory'],[z['line']],z['line']['formula'],dict(max_depth=256,max_operations=10000000,max_proof_lines=4096)) for z in compiled['zero_instances']]
        ref=save('data/rf-qualification/'+d['id']+'-check.json',dict(profile=receipt,zero_checks=zero))
        assert receipt['status']=='VERIFIED',(d['id'],receipt)
        assert all(z['status']=='VERIFIED' for z in zero)
        compiled_inputs[d['id']]=(d,compiled,generation)
        records.append(dict(id=d['id'],raw=raw,check=ref))
    mutations=[]
    def mutated(cid,name,edit):
        d,c,g=copy.deepcopy(compiled_inputs[cid]);edit(c,g)
        core={k:v for k,v in c.items() if k not in ('costs','scope')}
        g['compiled_core_sha256']=hashlib.sha256(wire(core)).hexdigest()
        evidence=save('data/rf-qualification/'+name+'-mutant.json.gz',dict(declaration=d,compiled=c,generation=g))
        result=checker.verify(d,c,g);ref=save('data/rf-qualification/'+name+'-rejection.json',result)
        assert result['status']=='REJECTED',(name,result)
        mutations.append(dict(id=name,evidence=evidence,check=ref,status=result['status']))
    def omit_zero(c,g):
        i=next(i for i,z in enumerate(c['zero_instances']) if z['rule']=='instantiate')
        c['zero_instances'].pop(i)
        for i,z in enumerate(c['zero_instances']):z['id']='i'+str(i)
        c['costs']['instances']-=1;c['costs']['definitions']-=1;c['profile']['definition_count']-=1
        g['profile']=copy.deepcopy(c['profile'])
    mutated('ui-basic','omitted-zero-rehashed',omit_zero)
    mutated('ui-basic','omitted-MP-rehashed',lambda c,g:c['mp_index'].pop())
    mutated('equality-contexts','omitted-context-rehashed',lambda c,g:c['logical_basis']['templates'].pop())
    mutated('ui-capture','wrong-capture-count-rehashed',lambda c,g:c['costs'].__setitem__('capture_omissions',0))
    mutated('fresh-hole','wrong-fresh-hole-rehashed',lambda c,g:c['logical_basis'].__setitem__('hole','__rf_hole'))
    d,c,g=compiled_inputs['ui-basic'];limited=checker.verify(d,c,g,max_items=10)
    assert limited['status']=='UNKNOWN';save('data/rf-qualification/resource-refusal.json',limited)
    unchanged(protocol)
    save('data/rf-qualification-results-v1.json',dict(status='COMPLETE',records=records,mutations=mutations,resource_refusal=limited,sources_unchanged=True))

def wang():
    protocol=freeze('wang')
    base='companion/wang-point-join-v1/'
    fixtures=mod('fresh_wang',base+'source/wang_fixtures_v1.py')
    oracle=mod('independent_wang',base+'reference/wang_model_checker_v1.py')
    engine=mod('wang_point_engine',base+'reference/growing_point_search_v2.py')
    checker=mod('wang_full_frontier',base+'reference/frontier_trace_checker_v1.py')
    started=time.perf_counter();prepared=fixtures.prepare();preparation_seconds=time.perf_counter()-started
    input_ref=save('data/wang-inputs-v1.json.gz',prepared);records=[]
    for i,item in enumerate(prepared):
        case_id=item['fixture']['id'];model_check=oracle.verify_model(item)
        model_ref=save('data/wang/'+case_id+'-model-check.json',model_check)
        assert model_check['status']=='VERIFIED',model_check
        raw,record=run_point(engine,checker,case_id,item['model'],None,item['universe'],
            dict(**input_ref,pointer='/'+str(i)+'/universe'),dict(kind='WANG',fixture=item['fixture'],model_check=model_ref))
        decoded=oracle.verify_result(item,raw['result']);decode_ref=save('data/wang/'+case_id+'-decode-check.json',decoded)
        record.update(kind='WANG',fixture=item['fixture'],model_check=model_ref,decode_check=decode_ref)
        save('data/wang/'+case_id+'-record.json',record)
        assert record['assurance']=='VERIFIED' and decoded['status']=='VERIFIED',(case_id,record,decoded)
        records.append(record)
    unchanged(protocol)
    save('data/wang-results-v1.json',dict(status='COMPLETE',records=records,preparation_seconds=preparation_seconds,sources_unchanged=True))

def families():
    protocol=freeze('families');inputs=mod('fresh_transfer_inputs','source/transfer_inputs_v1.py')
    declarations=mod('fresh_transfer_cases','source/transfer_cases_v1.py').declarations()
    save('data/family-declarations-v1.json',declarations)
    engine=mod('family_point_engine','reference/upstream/growing_point_search_v2.py')
    checker=mod('family_full_frontier','reference/upstream/frontier_trace_checker_v1.py')
    dp=mod('conventional_height_dp','reference/upstream/growing_proof_verifier_v2.py')
    records=[];preparations=[]
    for index,declaration in enumerate(declarations):
        prepared=inputs.prepare(declaration);case_id=declaration['id']
        prep_ref=save('data/prepared/'+case_id+'.json.gz',prepared)
        preparations.append(dict(id=case_id,prepared=prep_ref,status=prepared['status']))
        if prepared['status']!='PREPARED':
            print(json.dumps(dict(id=case_id,preparation=prepared['status'])),flush=True);continue
        modes=['BASE','MARKS','FILTER'];offset=index%3;modes=modes[offset:]+modes[:offset]
        # DP order rotates too, but no lane consumes any returned control proof.
        jobs=modes+['DP'] if index%2==0 else ['DP']+modes
        for mode in jobs:
            job_started=time.perf_counter()
            run_id=case_id+'--'+mode
            if mode=='DP':
                save('data/runs/'+run_id+'-started-v1.json',dict(id=run_id,kind='DP',prepared=prep_ref,limits=DP_LIMITS))
                started=time.perf_counter();result=dp.tree_control(prepared['compiled'],prepared['depth'],DP_LIMITS)
                seconds=time.perf_counter()-started
                raw_ref=save('data/runs/'+run_id+'-raw.json.gz',dict(id=run_id,kind='DP',prepared_ref=prep_ref,result=result,search_seconds=seconds))
                selected=result.get('details',{}).get('selected') if result.get('details') else None
                native=inputs.check_solution(prepared,dict(status='SAT' if result['status']=='DERIVABLE' else 'UNKNOWN',selected=selected or []))
                native_ref=save('data/runs/'+run_id+'-native-check.json',native)
                entry=dict(id=run_id,kind='DP',case_id=case_id,mode=mode,raw=raw_ref,
                    result=result['status'],native_check=native_ref,search_seconds=seconds,
                    prepared=prep_ref,proof_reader=native.get('proof_reader',[]),theory_reader=prepared['theory_reader'])
                if result['status']=='DERIVABLE':assert native['status']=='VERIFIED',(run_id,native)
                print(json.dumps(dict(id=run_id,result=result['status'])),flush=True)
            else:
                lane=inputs.make_lane(prepared,mode)
                raw,entry=run_point(engine,checker,run_id,lane['model'],lane['provider'],lane['universe'],
                    dict(**prep_ref,pointer='/lanes/'+mode+'/universe'),
                    dict(kind='FAMILY',case_id=case_id,mode=mode,prepared_ref=prep_ref,setup=lane['setup']))
                native=inputs.check_solution(prepared,raw['result'])
                native_ref=save('data/runs/'+run_id+'-native-check.json',native)
                entry.update(kind='FAMILY',case_id=case_id,mode=mode,prepared=prep_ref,setup=lane['setup'],
                    native_check=native_ref,proof_reader=native.get('proof_reader',[]),theory_reader=prepared['theory_reader'])
                if raw['result']['status']=='SAT':assert native['status']=='VERIFIED',(run_id,native)
                # A verifier resource refusal is retained as a gap, never silently fixed by rerunning search.
                assert entry['assurance']!='REJECTED',(run_id,read(entry['graph_check']['path']))
            entry['pipeline_seconds_before_record']=time.perf_counter()-job_started
            save('data/runs/'+run_id+'-record.json',entry);records.append(entry)
    unchanged(protocol)
    save('data/family-results-v1.json',dict(status='SCHEDULE_EXECUTED',preparations=preparations,records=records,sources_unchanged=True))

def main():
    p=argparse.ArgumentParser();p.add_argument('phase',choices=('rf-qualification','wang','families'));args=p.parse_args()
    started=time.perf_counter()
    try:
        {'rf-qualification':rf_qualification,'wang':wang,'families':families}[args.phase]()
    finally:
        save('review/'+args.phase+'-invocation-v1.json',dict(status='FAILED' if sys.exc_info()[0] else 'COMPLETE',
            phase=args.phase,main_seconds=time.perf_counter()-started,platform=sys.platform,
            ru_maxrss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            scope='Own fresh main invocation including preparation, searches, inline assurance and preceding persistence. Startup and this receipt excluded; Darwin RSS high-water is bytes.'))
if __name__=='__main__':main()
