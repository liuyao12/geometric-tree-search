"""Saved-data transfer audit and summary writer v2; no scientific imports.

Only retained JSON/Source bytes, hashes, record extents and receipts are joined.
No compiler, provider, classifier, decoder, graph/logical checker or engine runs.
Full prepared inputs and raw traces are processed one case/run at a time.
Raw artifact hashes stay separate from checker-normalized content hashes.
Version1 and its failed audit attempt remain unchanged.
"""
import collections
import gc
import gzip
import hashlib
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MASTER = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md')
MASTER_SHA = 'c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9'


def wire(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(',', ':'),
                       allow_nan=False) + '\n').encode('ascii')


def sha(value):
    return hashlib.sha256(wire(value)).hexdigest()


NORMALIZATION_SCOPE = (
    'Checker content hashing only: preserve literal CIDs, point/value types and assignments; '
    'sort each t/m support by literal point ID, sort universe/explicit inventory rows by CID, '
    'sort roots and seed t/m rows. No IDs/points/values are removed or merged. '
    'Raw artifact pins and raw prepared-universe digests remain distinct and unchanged.')


def canonical_points(rows, marking=False, seed=False):
    assert type(rows) is list
    output, seen = [], set()
    for row in rows:
        assert type(row) is list and len(row) == 2
        point, value = row
        assert type(point) is str and point not in seen
        seen.add(point)
        assert type(value) is str if marking else type(value) is int and value >= (0 if seed else 1)
        output.append([point, value])
    return sorted(output, key=lambda row: row[0])


def canonical_row(row):
    assert type(row) is dict and set(row) == {'id', 't', 'm'}
    assert type(row['id']) is str and row['id']
    return dict(id=row['id'], t=canonical_points(row['t']),
                m=canonical_points(row['m'], marking=True))


def canonical_universe(rows):
    assert type(rows) is list
    output = [canonical_row(row) for row in rows]
    assert len({row['id'] for row in output}) == len(output)
    return sorted(output, key=lambda row: row['id'])


def canonical_model(model):
    assert type(model) is dict and set(model) == {'schema', 'version', 'capacity', 'roots', 'seed', 'inventory'}
    assert type(model['roots']) is list and all(type(p) is str for p in model['roots'])
    assert len(set(model['roots'])) == len(model['roots'])
    inventory = model['inventory']
    if inventory['kind'] == 'EXPLICIT':
        assert set(inventory) == {'kind', 'placements'}
        inventory = dict(kind='EXPLICIT', placements=canonical_universe(inventory['placements']))
    else:
        assert set(inventory) == {'kind', 'identity'} and inventory['kind'] == 'CERTIFIED_INCIDENT'
        inventory = dict(kind='CERTIFIED_INCIDENT', identity=inventory['identity'])
    return dict(schema=model['schema'], version=model['version'], capacity=model['capacity'],
        roots=sorted(model['roots']),
        seed=dict(t=canonical_points(model['seed']['t'], seed=True),
                  m=canonical_points(model['seed']['m'], marking=True)),
        inventory=inventory)


def pin(path):
    with path.open('rb') as stream:
        total, digest = 0, hashlib.sha256()
        while True:
            chunk = stream.read(1024 * 1024)
            if not chunk:
                break
            total += len(chunk)
            digest.update(chunk)
    return dict(bytes=total, sha256=digest.hexdigest())


def read(name):
    path = ROOT / name
    if path.suffix == '.gz':
        with gzip.open(path, 'rt', encoding='ascii') as stream:
            return json.load(stream)
    with path.open('r', encoding='ascii') as stream:
        return json.load(stream)


def is_ref(value):
    return type(value) is dict and {'path', 'bytes', 'sha256'} <= set(value)


def local_path(name):
    path = (ROOT / name).resolve()
    assert path.is_relative_to(ROOT) and not Path(name).is_absolute(), name
    return path


def pointer(value, path):
    assert type(path) is str and path.startswith('/')
    for item in path[1:].split('/'):
        item = item.replace('~1', '/').replace('~0', '~')
        value = value[int(item)] if type(value) is list else value[item]
    return value


def save(name, value):
    path = ROOT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(wire(value))
    return dict(path=name, **pin(path))


def difference_paths(left, right, path=''):
    """Exact saved-JSON comparison; reports fields, not scientific replay."""
    if type(left) is not type(right):
        return [path or '/']
    if type(left) is dict:
        result = []
        for key in sorted(set(left) | set(right)):
            child = path + '/' + str(key).replace('~', '~0').replace('/', '~1')
            if key not in left or key not in right:
                result.append(child)
            else:
                result.extend(difference_paths(left[key], right[key], child))
        return result
    if type(left) is list:
        result = [] if len(left) == len(right) else [path + '/length']
        for i, (a, b) in enumerate(zip(left, right)):
            result.extend(difference_paths(a, b, path + '/' + str(i)))
        return result
    return [] if left == right else [path or '/']


class Audit:
    def __init__(self):
        self.references = {}
        self.files = {}
        self.counts = collections.Counter()
        self.graph_counts = collections.Counter()
        self.event_kinds = collections.Counter()
        self.run_checks = []
        self.cost_rows = []
        self.positive_outputs = []
        self.source_pins = {}
        self.prep_summaries = []

    def file_ref(self, name):
        result = dict(path=name, **pin(local_path(name)))
        self.files[name] = {k: result[k] for k in ('bytes', 'sha256')}
        return result

    def verify_ref(self, reference):
        assert is_ref(reference), reference
        name = reference['path']
        expected = {k: reference[k] for k in ('bytes', 'sha256')}
        if name in self.references:
            assert self.references[name] == expected, name
        else:
            assert pin(local_path(name)) == expected, name
            self.references[name] = expected
        return name

    def load(self, reference):
        return read(self.verify_ref(reference))

    def walk_refs(self, value):
        if type(value) is dict:
            if is_ref(value) and not Path(value['path']).is_absolute():
                self.verify_ref(value)
            for item in value.values():
                self.walk_refs(item)
        elif type(value) is list:
            for item in value:
                self.walk_refs(item)

    def provenance(self):
        rows = []
        for path in sorted((ROOT / 'data').iterdir()):
            if not path.name.endswith('-protocol-v1.json'):
                continue
            protocol = read(path.relative_to(ROOT).as_posix())
            pins = protocol['pins']
            for name, expected in pins.items():
                assert pin(local_path(name)) == expected, name
                if name in self.source_pins:
                    assert self.source_pins[name] == expected, ('PHASE_PIN_INTERSECTION_CHANGED', name)
                self.source_pins[name] = expected
            runtime = protocol.get('python')
            if runtime:
                assert pin(Path(runtime['path'])) == {k: runtime[k] for k in ('bytes', 'sha256')}
            rows.append(dict(protocol=self.file_ref(path.relative_to(ROOT).as_posix()),
                phase=protocol.get('phase'), pinned_files=len(pins), python=runtime))
        assert rows
        assert pin(MASTER)['sha256'] == MASTER_SHA
        assert pin(ROOT / 'reference/basic-tiling-algorithm.md') == pin(MASTER)
        observers, invocations = [], []
        supervisors = {p.relative_to(ROOT).as_posix(): pin(p)
                       for p in (ROOT / 'review').iterdir()
                       if p.name.startswith('supervise_') and p.suffix == '.py'}
        for path in sorted((ROOT / 'review').iterdir()):
            if path.name.startswith('observer-') and path.name.endswith('-v1.json'):
                record = read(path.relative_to(ROOT).as_posix())
                assert record['status'] == 'TERMINAL'
                assert record['source_sha256'] in {v['sha256'] for v in supervisors.values()}
                phase = record.get('phase')
                for suffix in ('.stdout.log', '.stderr.log'):
                    self.file_ref('review/' + phase + suffix)
                observers.append(dict(reference=self.file_ref(path.relative_to(ROOT).as_posix()),
                    phase=record.get('phase'), native_exit=record['native_exit'], guard=record.get('guard'),
                    seconds=record.get('seconds'), sampled_peak_rss_bytes=record.get('sampled_peak_rss_bytes'),
                    supervisor_source_sha256=record.get('source_sha256'),
                    observation_failures=len(record.get('observation_failures', []))))
            if path.name.endswith('-invocation-v1.json'):
                record = read(path.relative_to(ROOT).as_posix())
                invocations.append(dict(reference=self.file_ref(path.relative_to(ROOT).as_posix()), **record))
        assert any(r['native_exit'] == 1 and r['phase'] == 'wang' for r in observers)
        assert any(r['native_exit'] == 0 and r['phase'] == 'wang-recovery' for r in observers)
        return dict(protocols=rows, current_source_pins=self.source_pins, supervisor_pins=supervisors, observers=observers,
            invocations=invocations, master=dict(path=str(MASTER), **pin(MASTER)),
            scope='Every recorded phase pin checked against current bytes; shared paths have identical pins. Later phases may include newly added Sources, so whole pin maps are not asserted identical. Original Wang exit1 and recovery exit0 remain separate.')

    def qualification(self):
        qualification = read('data/rf-qualification-results-v1.json')
        assert qualification['status'] == 'COMPLETE' and qualification['sources_unchanged'] is True
        self.walk_refs(qualification)
        for row in qualification['records']:
            raw, receipt = self.load(row['raw']), self.load(row['check'])
            assert receipt['profile']['status'] == 'VERIFIED'
            assert receipt['profile']['declaration_sha256'] == sha(raw['declaration'])
            assert all(r['status'] == 'VERIFIED' for r in receipt['zero_checks'])
            self.counts['rf_qualification_zero_receipts'] += len(receipt['zero_checks'])
        for row in qualification['mutations']:
            receipt = self.load(row['check'])
            assert row['status'] == receipt['status'] == 'REJECTED'
        assert qualification['resource_refusal']['status'] == 'UNKNOWN'
        return dict(reference=self.file_ref('data/rf-qualification-results-v1.json'),
            admitted_cases=len(qualification['records']), rejected_mutants=len(qualification['mutations']),
            resource_refusal=qualification['resource_refusal'])

    def prepare(self, row):
        prepared = self.load(row['prepared'])
        assert row['status'] == prepared['status'] == 'PREPARED'
        assert row['id'] == prepared['id']
        compiled, acquisition = prepared['compiled'], prepared['acquisition']
        profile = prepared['profile_check']
        assert profile['status'] == prepared['factory_check']['status'] == 'VERIFIED'
        assert profile['declaration_sha256'] == sha(prepared['declaration'])
        core = {k: v for k, v in compiled.items() if k not in ('costs', 'scope')}
        assert profile['compiled_core_sha256'] == prepared['generation']['compiled_core_sha256'] == sha(core)
        assert profile['counts'] == {k: v for k, v in compiled['costs'].items() if k != 'seconds'}
        assert prepared['factory']['status'] == 'COMPLETE'
        assert prepared['factory']['value']['definitions'] == prepared['definitions']
        zeros = prepared['zero_checks']
        assert len(zeros) == len(compiled['zero_instances'])
        for row_check, original in zip(zeros, compiled['zero_instances']):
            assert row_check['id'] == original['id'] and row_check['native_rule'] == original['rule']
            assert row_check['receipt']['status'] == 'VERIFIED' and row_check['receipt']['checked_lines'] == 1
        self.counts['family_native_zero_receipts'] += len(zeros)
        for name, expected in prepared['source_pins'].items():
            assert pin(local_path(name)) == expected, name
        certificate = prepared['failure_certificate']
        scope_payload = dict(schema='FM-native-producer-scope-v1', depth_semantics='FM-rooted-tree-height-v1',
            compiled_schema=compiled['schema'], compiled_version=compiled['version'], theory=compiled['theory'],
            registry=dict(formulas=compiled['logical_basis']['formulas'], colors=compiled['logical_basis']['colors']),
            zero_instances=compiled['zero_instances'], mp_index=compiled['mp_index'], gen_index=compiled['gen_index'])
        scope = sha(scope_payload)
        absence = acquisition['absence_check']
        assert absence['status'] == acquisition['marked_model_check']['status'] == 'VERIFIED'
        assert certificate['scope_sha256'] == absence['scope_sha256'] == scope
        assert absence['certificate_sha256'] == sha(certificate)
        assert absence['negative_requests'] == certificate['requests']
        assert absence['checked_node_count'] == len(certificate['nodes'])
        assert absence['checked_nodes'] == sorted([[n['fid'], n['remaining']] for n in certificate['nodes']])
        learned = acquisition['learned']
        assert learned['certificate'] == certificate and learned['requests'] == acquisition['requests']
        labels = learned['classifications']
        assert [[r['fid'], r['remaining']] for r in labels] == acquisition['requests']
        assert all(r['status'] in ('PROVED', 'ABSENT', 'UNKNOWN') for r in labels)
        assert [[r['fid'], r['remaining']] for r in labels if r['status'] == 'ABSENT'] == certificate['requests']
        self.counts.update(collections.Counter('classification/' + r['status'] for r in labels))
        row_ids = {}
        for mode, lane in prepared['lanes'].items():
            universe = lane['universe']
            assert prepared['universe_pins'][mode] == dict(rows=len(universe), sha256=sha(universe))
            ids = [item['id'] for item in universe]
            assert ids == sorted(set(ids))
            row_ids[mode] = ids
        assert row_ids['BASE'] == row_ids['MARKS']
        assert acquisition['all_marked_rows_independently_checked'] == len(prepared['lanes']['MARKS']['universe'])
        assert acquisition['marked_model_check']['model_sha256'] == sha(prepared['lanes']['MARKS']['model'])
        assert sorted(row_ids['FILTER'] + [r['id'] for r in acquisition['removed_rows']]) == row_ids['BASE']
        negative = {tuple(pair) for pair in certificate['requests']}
        assert all(r['certified_absent_premises'] and all(tuple(x) in negative for x in r['certified_absent_premises'])
                   for r in acquisition['removed_rows'])
        stages = prepared['stage_seconds']
        assert all(type(v) in (int, float) and math.isfinite(v) and v >= 0 for v in stages.values())
        assert math.isclose(sum(stages.values()), prepared['preparation_seconds'], abs_tol=1e-8)
        nested = prepared['nested_stage_seconds']
        zero_seconds = nested['zero_part_of_factory_and_zero']
        assert zero_seconds <= stages['factory_and_zero_seconds']
        summary = dict(id=prepared['id'], prepared=row['prepared'], status=prepared['status'],
            family=prepared['declaration']['family'], depth=prepared['depth'],
            renaming_index=prepared['declaration']['renaming_index'],
            formulas=len(compiled['logical_basis']['formulas']), definitions=len(prepared['definitions']),
            native_zero_receipts=len(zeros), universe_pins=prepared['universe_pins'],
            classification_counts=dict(collections.Counter(r['status'] for r in labels)),
            negative_requests=len(certificate['requests']), scope_sha256=scope,
            removed_rows=len(acquisition['removed_rows']),
            preparation_seconds=prepared['preparation_seconds'], stage_seconds=stages,
            nested_stage_seconds=nested, preservation_scope=acquisition['preservation_scope'])
        self.prep_summaries.append(summary)
        return prepared

    def stream(self, rows, extent, label):
        assert extent['retained'] == len(rows) <= extent['total']
        if extent['retained'] == extent['total']:
            digest = hashlib.sha256()
            for row in rows:
                digest.update(wire(row))
            assert digest.hexdigest() == extent['sha256'], label
            return True
        return False

    def point(self, row, raw, universe):
        result, observations = raw['result'], raw['observations']
        graph = self.load(row['graph_check'])
        assert row['id'] == raw['id'] and row['result'] == result['status']
        assert row['assurance'] == graph['status']
        assert len(observations) <= result['event_extent']['total']
        assert [o['event'] for o in observations] == result['events'][:len(observations)]
        assert all(o['event']['seq'] == i for i, o in enumerate(observations))
        events_complete = self.stream(result['events'], result['event_extent'], row['id'] + '/events')
        rollback_complete = self.stream(result['rollback_records'], result['rollback_extent'], row['id'] + '/rollback')
        provider = result['provider_evidence']
        queries_complete = self.stream(provider['records'], provider, row['id'] + '/queries')
        for query in provider['records']:
            assert query['reply']['context_sha256'] == sha(query['query'])
        for name in ('entry', 'final', 'restored'):
            state = result[name + '_state']
            assert result['state_hashes'][name] == (sha(state) if state is not None else None)
        assert result['entry_state'] == result['restored_state']
        journal_bytes = sum(len(wire(o)) for o in observations)
        assert journal_bytes == raw['journal']['retained_bytes'] == row['journal_bytes']
        assert row['events'] == len(observations)
        counts = graph.get('counts', {})
        assert counts.get('observations_checked', 0) <= len(observations)
        assert counts.get('queries_checked', 0) <= len(provider['records'])
        if graph['status'] == 'VERIFIED':
            assert result['status'] in ('SAT', 'UNSAT')
            assert len(observations) == result['event_extent']['total']
            assert events_complete and rollback_complete and queries_complete
            assert counts['observations_checked'] == len(observations)
            assert counts['queries_checked'] == len(provider['records'])
            assert graph['model_sha256'] == sha(canonical_model(raw['model']))
            assert graph['universe_sha256'] == sha(canonical_universe(universe))
            assert graph['gaps'] == []
        else:
            assert graph['status'] == 'UNKNOWN'
        if result['status'] == 'UNKNOWN':
            assert result['selected'] == [] and result['certificate'] is None and result['final_state'] is None
        self.counts['point_jobs'] += 1
        self.counts['point_result/' + result['status']] += 1
        self.counts['point_graph/' + graph['status']] += 1
        self.counts['retained_observations'] += len(observations)
        self.counts['emitted_events'] += result['event_extent']['total']
        self.counts['retained_queries'] += len(provider['records'])
        self.counts['emitted_queries'] += provider['total']
        self.counts['retained_rollback_records'] += len(result['rollback_records'])
        self.graph_counts.update(counts)
        self.event_kinds.update(o['event']['kind'] for o in observations)
        if raw['journal']['refusal'] is not None:
            self.counts['audit_storage_refusals'] += 1
        self.run_checks.append(dict(id=row['id'], result=result['status'], graph=graph['status'],
            event_total=result['event_extent']['total'], retained_observations=len(observations),
            queries=provider['total'], queries_semantically_joined=counts.get('queries_checked', 0),
            full_event_record_hash_verified=events_complete, full_rollback_record_hash_verified=rollback_complete,
            full_query_record_hash_verified=queries_complete, observation_gap=result['event_extent']['total'] - len(observations),
            raw_model_content_sha256=sha(raw['model']),
            raw_universe_content_sha256=sha(universe),
            checker_normalized_model_sha256=graph.get('model_sha256'),
            checker_normalized_universe_sha256=graph.get('universe_sha256'),
            normalization_scope=NORMALIZATION_SCOPE,
            graph_reason=graph.get('reason'), journal_refusal=raw['journal']['refusal']))
        return graph

    def native(self, row, raw, prepared):
        receipt = self.load(row['native_check'])
        result = raw['result']
        positive = result['status'] in ('SAT', 'DERIVABLE')
        assert row['proof_reader'] == receipt.get('proof_reader', [])
        assert row['theory_reader'] == prepared['theory_reader']
        if not positive:
            assert receipt['status'] == 'NOT_APPLICABLE'
            return receipt
        assert receipt['status'] == receipt['tree']['status'] == receipt['native_fol_kernel']['status'] == 'VERIFIED'
        decoded = receipt['decoded']
        assert decoded['target'] == prepared['compiled']['goal']
        proof, reader = decoded['proof'], receipt['proof_reader']
        assert len(proof) == len(reader) == receipt['native_fol_kernel']['checked_lines']
        if result['status'] == 'SAT':
            assert sorted(result['selected']) == decoded['tree']['selected']
        else:
            assert sorted(result['details']['selected']) == decoded['tree']['selected']
            assert result['proof'] == proof
            assert result['details']['minimum_tree_nodes'] == len(proof)
        for i, (line, text_row) in enumerate(zip(proof, reader), 1):
            assert text_row['line'] == i and text_row['formula'] == line['formula']
            assert text_row['rule'] == line['rule'] and type(text_row['formula_latex']) is str
            assert text_row['formula_latex'] and text_row['english']
            refs = ([line['antecedent'] + 1, line['implication'] + 1] if line['rule'] == 'mp'
                    else [line['source'] + 1] if line['rule'] == 'generalize' else [])
            assert text_row['dependencies'] == refs and all(0 < j < i for j in refs)
        output = dict(id=row['id'], case_id=row['case_id'], mode=row['mode'], lines=len(proof),
            proof_sha256=sha(proof), goal_sha256=sha(prepared['compiled']['goal']),
            rules=dict(collections.Counter(line['rule'] for line in proof)),
            native_check=row['native_check'])
        self.positive_outputs.append(output)
        self.counts['native_positive_outputs'] += 1
        return receipt

    def cost(self, row, raw, prepared=None, graph=None):
        pipeline = row.get('pipeline_seconds_before_record', row.get('pipeline_seconds'))
        setup = row.get('setup', {}).get('seconds')
        measured = dict(id=row['id'], mode=row.get('mode', row['kind']),
            search_seconds=row['search_seconds'], setup_seconds=setup,
            pipeline_seconds=pipeline, graph_checker_seconds=graph.get('seconds') if graph else None)
        if prepared:
            stages, nested = prepared['stage_seconds'], prepared['nested_stage_seconds']
            core = stages['compile_seconds'] + stages['independent_profile_admission_seconds'] + nested['zero_part_of_factory_and_zero']
            if row['mode'] == 'DP':
                selected_prep = core
            else:
                selected_prep = (stages['dependency_loading_seconds'] + stages['compile_seconds'] +
                    stages['independent_profile_admission_seconds'] + stages['factory_and_zero_seconds'] +
                    stages['base_universe_seconds'] + stages['return_data_hashes_reader_pins_seconds'])
                if row['mode'] in ('MARKS', 'FILTER', 'IFILTER'):
                    selected_prep += stages['failure_acquisition_and_check_seconds']
                if row['mode'] == 'MARKS':
                    selected_prep += stages['marked_universe_materialization_binding_seconds']
                if row['mode'] in ('FILTER', 'IFILTER'):
                    selected_prep += stages['filter_construction_seconds']
            measured.update(accounted_reused_preparation_seconds=selected_prep,
                accounted_reused_end_to_end_seconds=selected_prep + pipeline if pipeline is not None else None,
                preparation_observed_once_per_case=prepared['id'],
                accounting_scope='Selected measured preparation stages reused across methods, not an independently measured cold run. DP excludes factory/universe/materialization/acquisition. Point return/hash stage covers all returned lane data and is conservatively charged whole; actual once-only phase preparation is separately shown.')
        self.cost_rows.append(measured)


def main():
    audit = Audit()
    followup_path = ROOT / 'data/indexed-filter-results-v1.json'
    if not followup_path.exists():
        pending = dict(status='PENDING_INDEXED_FILTER_RESULTS', pending=['data/indexed-filter-results-v1.json'],
            scope='Final summary and final audit not written. No scientific execution occurred.')
        save('review/saved-data-audit-pending-v1.json', pending)
        print(json.dumps(pending))
        return
    family = read('data/family-results-v1.json')
    followup = read('data/indexed-filter-results-v1.json')
    provider_qualification = read('review/indexed-filter-provider-qualification-v1.json')
    assert provider_qualification['status'] == 'VERIFIED'
    assert len(provider_qualification['records']) == 8
    provider_by_case = {row['case_id']: row for row in provider_qualification['records']}
    assert len(provider_by_case) == 8
    wang = read('data/wang-results-v1.json')
    assert family['sources_unchanged'] and wang['sources_unchanged'] and followup['sources_unchanged']
    assert len(family['preparations']) == 8 and len(family['records']) == 32
    assert len(followup['records']) == 8 and len(wang['records']) == 4
    audit.walk_refs(family)
    audit.walk_refs(followup)
    audit.walk_refs(wang)
    provenance = audit.provenance()
    qualification = audit.qualification()
    all_family = family['records'] + followup['records']
    assert len({row['id'] for row in all_family}) == len(all_family)
    by_case = collections.defaultdict(list)
    for row in all_family:
        by_case[row['case_id']].append(row)
    comparisons, matched_arithmetic_events = [], []
    for preparation in family['preparations']:
        prepared = audit.prepare(preparation)
        rows = by_case.pop(prepared['id'])
        assert {r['mode'] for r in rows} == {'BASE', 'MARKS', 'FILTER', 'DP', 'IFILTER'}
        outcomes, event_pairs = {}, {}
        for row in rows:
            assert row['prepared'] == preparation['prepared']
            raw = audit.load(row['raw'])
            assert raw['id'] == row['id'] and raw['prepared_ref'] == preparation['prepared']
            assert raw['search_seconds'] == row['search_seconds']
            outcomes[row['mode']] = row['result']
            graph = None
            if row['mode'] != 'DP':
                ref = raw['universe_ref']
                audit.verify_ref(ref)
                assert {k: ref[k] for k in ('path', 'bytes', 'sha256')} == preparation['prepared']
                universe = pointer(prepared, ref['pointer'])
                expected_mode = 'FILTER' if row['mode'] == 'IFILTER' else row['mode']
                assert ref['pointer'] == '/lanes/' + expected_mode + '/universe'
                assert universe is prepared['lanes'][expected_mode]['universe']
                if row['mode'] == 'IFILTER':
                    model = raw['model']
                    assert model['seed'] == prepared['factory_model']['seed']
                    assert model['roots'] == prepared['factory_model']['roots']
                    assert model['capacity'] == prepared['factory_model']['capacity']
                    assert model['inventory']['kind'] == 'CERTIFIED_INCIDENT'
                    qualified = provider_by_case.pop(prepared['id'])
                    assert qualified['status'] == 'VERIFIED' and qualified['prepared'] == preparation['prepared']
                    expected_preimage = ['PFT-indexed-filter-control-v1',
                        prepared['factory_model']['inventory']['identity'], sha(universe),
                        prepared['failure_certificate']['scope_sha256'],
                        sha(prepared['failure_certificate']['requests'])]
                    assert qualified['identity_preimage'] == row['setup']['identity_preimage'] == expected_preimage
                    assert model['inventory']['identity'] == wire(expected_preimage).decode('ascii').rstrip('\n')
                    assert qualified['model_sha256'] == sha(model)
                    assert qualified['filtered_universe_sha256'] == sha(universe)
                    assert qualified['rows'] == len(universe)
                    assert qualified['checked_failure_certificate_sha256'] == sha(prepared['failure_certificate'])
                else:
                    assert raw['model'] == prepared['lanes'][row['mode']]['model']
                graph = audit.point(row, raw, universe)
            else:
                assert row['result'] == raw['result']['status']
                audit.counts['DP/' + row['result']] += 1
            native_receipt = audit.native(row, raw, prepared)
            if prepared['declaration']['family'] == 'arithmetic' and row['mode'] in ('MARKS', 'IFILTER'):
                assert raw['result']['status'] in ('SAT', 'UNSAT')
                event_pairs[row['mode']] = dict(events=raw['result']['events'],
                    proof_sha256=sha(native_receipt['decoded']['proof']) if native_receipt['status'] == 'VERIFIED' else None)
            audit.cost(row, raw, prepared, graph)
            del raw
            gc.collect()
        dp = outcomes['DP']
        for mode, outcome in outcomes.items():
            if mode == 'DP' or outcome == 'UNKNOWN' or dp == 'UNKNOWN':
                continue
            assert (outcome == 'SAT') == (dp == 'DERIVABLE'), (prepared['id'], mode, outcome, dp)
        comparisons.append(dict(id=prepared['id'], family=prepared['declaration']['family'],
            depth=prepared['depth'], renaming_index=prepared['declaration']['renaming_index'], outcomes=outcomes,
            completed_point_vs_dp_existence='AGREE', unknown_is_not_negative=True,
            exact_proof_set_counts='NOT_ATTEMPTED',
            preservation='Checked bounded absence and complete row transformation; not equality by exhaustive proof-set enumeration.'))
        if prepared['declaration']['family'] == 'arithmetic':
            assert set(event_pairs) == {'MARKS', 'IFILTER'}
            marked, filtered = event_pairs['MARKS'], event_pairs['IFILTER']
            differences = difference_paths(marked['events'], filtered['events'])
            projection = lambda records: [{k: event[k] for k in ('kind', 'point', 'candidate')} for event in records]
            assert marked['proof_sha256'] == filtered['proof_sha256']
            matched_arithmetic_events.append(dict(case_id=prepared['id'], depth=prepared['depth'],
                MARKS_events=len(marked['events']), IFILTER_events=len(filtered['events']),
                exact_event_dicts_equal=not differences,
                exact_event_difference_count=len(differences),
                exact_event_difference_paths=differences[:200],
                difference_path_retention='ALL' if len(differences) <= 200 else 'FIRST200_OF_EXACT_COUNT',
                kinds_points_candidate_ids_equal=projection(marked['events']) == projection(filtered['events']),
                decoded_proof_sha256_MARKS=marked['proof_sha256'],
                decoded_proof_sha256_IFILTER=filtered['proof_sha256'],
                scope='Actual completed arithmetic pair only. Model/snapshot/mark-port/provider telemetry are not asserted equal; full event dictionaries and kind/point/CID projections are compared separately. No rerun or causality claim.'))
        del prepared
        gc.collect()
    assert not by_case and not provider_by_case
    wang_inputs_ref = audit.file_ref('data/wang-inputs-v1.json.gz')
    wang_inputs = read(wang_inputs_ref['path'])
    for row in wang['records']:
        raw = audit.load(row['raw'])
        reference = raw['universe_ref']
        audit.verify_ref(reference)
        assert {k: reference[k] for k in ('path', 'bytes', 'sha256')} == wang_inputs_ref
        universe = pointer(wang_inputs, reference['pointer'])
        index = int(reference['pointer'].split('/')[1])
        item = wang_inputs[index]
        assert raw['model'] == item['model'] and row['fixture'] == item['fixture']
        assert item['supplied_boolean_witness'] is False
        model, decoded = audit.load(row['model_check']), audit.load(row['decode_check'])
        assert model['status'] == 'VERIFIED'
        assert model['model_sha256'] == sha(raw['model'])
        assert model['universe_sha256'] == sha(canonical_universe(universe))
        assert len(universe) == 100 * item['fixture']['cells']
        graph = audit.point(row, raw, universe)
        assert decoded['status'] == ('UNKNOWN' if row['result'] == 'UNKNOWN' else 'VERIFIED')
        audit.counts['wang/' + row['result']] += 1
        audit.cost(row, raw, graph=graph)
        del raw
        gc.collect()
    del wang_inputs
    method_costs = {}
    for mode in sorted({r['mode'] for r in audit.cost_rows}):
        rows = [r for r in audit.cost_rows if r['mode'] == mode]
        values = {}
        for key in ('search_seconds', 'setup_seconds', 'pipeline_seconds', 'graph_checker_seconds',
                    'accounted_reused_preparation_seconds', 'accounted_reused_end_to_end_seconds'):
            present = [r[key] for r in rows if r.get(key) is not None]
            values[key] = dict(measured_or_accounted_rows=len(present), missing_rows=len(rows) - len(present),
                total=sum(present) if present else None)
        method_costs[mode] = dict(jobs=len(rows), values=values)
    coverage = dict(counts=dict(audit.counts), graph_receipt_counts=dict(audit.graph_counts),
        event_kinds=dict(audit.event_kinds), fresh_statement_bound_cases=len(family['preparations']),
        family_original_jobs=len(family['records']), indexed_filter_followup_jobs=len(followup['records']),
        wang_jobs=len(wang['records']), rf_qualification_cases=qualification['admitted_cases'],
        rf_mutants_rejected=qualification['rejected_mutants'],
        rf_resource_refusal=qualification['resource_refusal']['status'],
        family_method_existence_comparisons=comparisons,
        positive_native_outputs=audit.positive_outputs,
        positive_schematic_families=sorted({p['id'].split('-')[1] for p in audit.positive_outputs}),
        completed_arithmetic_MARKS_vs_IFILTER_event_comparison=matched_arithmetic_events,
        exact_richer_proof_set_enumeration='NOT_ATTEMPTED')
    limitations = [
        'Arithmetic is an addition-zero/equality-congruence fragment, without induction or full PA; incidence is purely symbolic and one-sorted, without coordinates, segment-congruence axioms or full Hilbert geometry. No newly trained RL, ATP advantage or unrestricted FOL completeness is established.',
        'Family proofs use an anchored symbolic point-tree carrier. The separate Wang lane offers all100 fixed-orientation square types at every finite circuit cell; its program selectors are problem pins on interior vertical edges too. It has not searched arithmetic or geometry proofs on one universal fixed Wang palette.',
        'Only actual native solver/control outputs are checked. Repeated symbol renamings, bounds and method outputs are not distinct new mathematical theorem discoveries. MARKS may return a padded proof while DP optimizes expanded tree-node count.',
        'UNSAT/NOT_DERIVABLE concern the complete declared finite native basis and height. UNKNOWN is never a logical negative. The incidence jobs do not establish that the unrestricted geometric implication is unprovable.',
        'Exact all-rooted-proof-set enumeration was not attempted for richer profiles. Preserved-rooted-proof claims use the checked bounded absence-certificate argument and exact transformed inventory, not a sampled or truncated set comparison.',
        'Explicit FILTER embeds its full restricted inventory in the model and repeated audit snapshots; MARKS uses indexed packets. That representation and evidence cost confounds their raw timing comparison. IFILTER is a separately declared follow-up using the same static filtered inventory through an indexed provider; original jobs were not rerun or replaced.',
        'Common preparation was measured once per case and reused. Per-method end-to-end figures are clearly labeled accounting projections of observed stages, not independently timed cold trials. DP is not charged point-universe, marking-acquisition or model-materialization work. Full once-only preparation and process totals remain separately recorded.',
        'The original Wang driver exited1 because it asserted on a retained resource UNKNOWN. First three original jobs, including the partial32-cell parity attempt, remain immutable; only the never-run fourth job was executed in recovery at the same caps. No full tiling is synthesized for the UNKNOWN case.',
        'Audit journal/storage/work limits can stop a job after an event was emitted but before its snapshot was retained. Complete stored event-record hashes do not turn that missing observation into verified graph coverage. Refused assurance stays UNKNOWN.',
        'This assembler only joins saved bytes, scope digests, extents and receipts. It reruns no scientific computation and does not independently prove the correctness of the kernel, search implementation or catalogue checker.'
    ]
    limitations.append('The first saved-data assembler stopped on a raw-versus-normalized Wang universe hash comparison. Version2 only applies the declared support/CID/model ordering normalization when joining checker content hashes; original Source, raw pins and the failed audit attempt remain retained. No scientific job was replayed.')
    costs = dict(per_method=method_costs, per_run=audit.cost_rows,
        once_observed_preparation_seconds=sum(p['preparation_seconds'] for p in audit.prep_summaries),
        preparations=audit.prep_summaries, process_invocations=provenance['invocations'],
        observer_records=provenance['observers'],
        scope='Search/setup/pipeline/check clocks are observed quantities in their declared windows. Reused preparation-stage totals are accounting, not measured cold method runs, and are not additive to the already inclusive phase main timers. Pipeline covers native verification/persistence where no separate timer exists; unavailable quantities remain null. No cluster proposal or cluster-verification cost exists in this no-policy gate.')
    summary = dict(schema='PFT-saved-transfer-report-summary-v1',
        status='EXECUTED_WITH_RESOURCE_UNKNOWNS_AND_RECORDED_RECOVERY',
        families=all_family, wang=wang['records'], preparations=family['preparations'],
        coverage=coverage, costs=costs, limitations=limitations,
        provenance=provenance, rf_qualification=qualification,
        normalization_scope=NORMALIZATION_SCOPE,
        prior_saved_data_audit_attempt=audit.file_ref('review/saved-data-audit-attempt-v1.json'),
        original_family_results=audit.file_ref('data/family-results-v1.json'),
        original_family_protocol=audit.file_ref('data/families-protocol-v1.json'),
        indexed_filter_provider_qualification=audit.file_ref('review/indexed-filter-provider-qualification-v1.json'),
        indexed_filter_followup_metadata={k: v for k, v in followup.items() if k != 'records'},
        wang_recovery_metadata={k: v for k, v in wang.items() if k != 'records'})
    for name in ('data/family-results-v1.json', 'data/indexed-filter-results-v1.json',
                 'data/wang-results-v1.json', 'data/rf-qualification-results-v1.json',
                 'review/assemble_transfer_results_v1.py', 'review/assemble_transfer_results_v2.py',
                 'review/saved-data-audit-attempt-v1.json', 'report/build_transfer_report_v1.py'):
        audit.file_ref(name)
    receipt = dict(status='PASS_SAVED_DATA_TRANSFER_AUDIT', method=__doc__,
        coverage=coverage, preparations=audit.prep_summaries, run_checks=audit.run_checks,
        provenance=provenance, references_verified=audit.references, files=audit.files,
        normalization_scope=NORMALIZATION_SCOPE,
        exact_richer_proof_sets='NOT_ATTEMPTED', limitations=limitations)
    audit_ref = save('review/saved-data-audit-v1.json', receipt)
    summary['saved_data_audit'] = audit_ref
    result_ref = save('data/report-summary-v1.json', summary)
    print(json.dumps(dict(status=receipt['status'], audit=audit_ref, summary=result_ref,
        counts=dict(audit.counts)), sort_keys=True))


if __name__ == '__main__':
    main()
