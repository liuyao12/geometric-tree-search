"""Copy only the owned companion Sources; no scientific module imports."""
from pathlib import Path
import hashlib
import json
import shutil
ROOT=Path(__file__).resolve().parents[1]
source=ROOT.parent/'gcts-wang-point-join-20261103-v1'
target=ROOT/'companion/wang-point-join-v1'
assert not target.exists()
files=[p for group in ('source','reference') for p in sorted((source/group).rglob('*')) if p.is_file()]
assert files and any(p.name=='wang_fixtures_v1.py' for p in files)
pins={}
for p in files:
    assert not p.is_symlink()
    name=p.relative_to(source).as_posix();out=target/name
    out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,out)
    raw=p.read_bytes();assert raw==out.read_bytes()
    pins[name]=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
(target/'SOURCE-SNAPSHOT-v1.json').write_text(json.dumps(pins,indent=2)+'\n')
master=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md').read_bytes()
assert hashlib.sha256(master).hexdigest()=='c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9'
(ROOT/'reference/basic-tiling-algorithm.md').write_bytes(master)
print(json.dumps(dict(status='SOURCES_COPIED_BYTE_IDENTICALLY',files=len(files))))
