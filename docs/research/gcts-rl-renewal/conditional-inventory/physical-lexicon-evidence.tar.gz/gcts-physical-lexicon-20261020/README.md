# Parallel physical lexical research milestone

The current UTF8v2 bank was executed exactly once and qualified as a standalone lexical component. Complete ordinary JSON retains all5378normal cases, all five diagnostic groups, full malformed tables and complete word traces. The Root once grant is retired0. No partial files were produced.

The strict value DAG codec and physical postfix structural routine are Source-only and unexecuted. Their declarative banks have NOT passed runtime tests. Independent static reviews do not change that status. G1 is unadopted; the old G0 negative is unchanged. Historical Sources and the nested prior milestone archive retain their own recorded statuses; they are not new invocations. No fullBOOT, fullVM, theorem discovery, RL training or GCTS/RL advantage is established.

The browser display is a passive subset of sixteen saved word controls plus the full literal table. It does not execute the machine. Original absolute-path pins identify the research workspace; archive-relative mappings below preserve the exact bytes. Interpreter and stdlib are pinned, not bundled.
