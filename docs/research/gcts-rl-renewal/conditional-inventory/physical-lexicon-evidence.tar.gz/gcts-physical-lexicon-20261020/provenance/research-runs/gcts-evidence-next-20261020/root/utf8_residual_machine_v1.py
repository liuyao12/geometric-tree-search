"""Fixed finite UTF8_SURROGATEPASS byte recognizer: unexecuted Source.

This generates a literal one-tape transition table, independent of input,
checker image, formula, tape width and horizon. It is only a lexical routine;
it is not the unfinished proof-checker interpreter or a theorem prover.

Bytes are eight bits, least significant bit first. B ends a byteword; # is
a finite capacity fence (BOUND, never logical rejection). Accept empty input
and complete canonical surrogatepass UTF-8 bytewords. Mid-byte B rejects.
No host decoder or semantic operation occurs in a generated transition.
"""

VERSION = 'utf8-residual-physical-machine-v1'
MODES = ('LEAD', 'CONT1', 'CONT2', 'CONT3', 'E0_FIRST', 'F0_FIRST', 'F4_FIRST')
ALPHABET = ('B', '0', '1', '#')
HALTS = ('DONE', 'REJECT', 'BOUND')
SOURCE_ASSIGNED_STATE_UPPER_BOUND = 314
SOURCE_ALL_STATE_UPPER_BOUND = 317
SOURCE_TRANSITION_UPPER_BOUND = 1256


class DeclarationError(Exception):
    """Invalid generator declaration; no input word was executed."""


class ConstructionLimit(Exception):
    """Finite construction cutoff; no mathematical or lexical conclusion."""


def _next_mode(mode, byte):
    """Only called by the finite table generator on literal byte constants."""
    if mode == 'LEAD':
        if 0 <= byte <= 0x7f:
            return 'LEAD'
        if 0xc2 <= byte <= 0xdf:
            return 'CONT1'
        if byte == 0xe0:
            return 'E0_FIRST'
        if 0xe1 <= byte <= 0xef:
            return 'CONT2'
        if byte == 0xf0:
            return 'F0_FIRST'
        if 0xf1 <= byte <= 0xf3:
            return 'CONT3'
        if byte == 0xf4:
            return 'F4_FIRST'
    elif mode == 'CONT1' and 0x80 <= byte <= 0xbf:
        return 'LEAD'
    elif mode == 'CONT2' and 0x80 <= byte <= 0xbf:
        return 'CONT1'
    elif mode == 'CONT3' and 0x80 <= byte <= 0xbf:
        return 'CONT2'
    elif mode == 'E0_FIRST' and 0xa0 <= byte <= 0xbf:
        return 'CONT1'
    elif mode == 'F0_FIRST' and 0x90 <= byte <= 0xbf:
        return 'CONT2'
    elif mode == 'F4_FIRST' and 0x80 <= byte <= 0x8f:
        return 'CONT2'
    return None


def describe_utf8_machine(*, check, limits):
    """Generate all literal rows, all undefined halt slots and seven entries.

    Fresh construction and residual registry on every call; no warm cache.
    ``limits`` has exactly work/states/transitions, positive exact integers.
    Every construction action charges private work and invokes the supplied
    callback. Root's absolute/cumulative/resource guards remain external.

    A failure retains a raw available-prefix owner on the exact exception,
    when that exception allows metadata attachment. Never normalize foreign
    errors, retry, return a prefix as success, or interpret a quota as reject.
    """
    if not callable(check) or type(limits) is not dict:
        raise DeclarationError('explicit callback and exact limit dictionary required')
    if set(limits) != {'work', 'states', 'transitions'}:
        raise DeclarationError('exact construction limit keys required')
    for key, value in limits.items():
        if type(key) is not str or type(value) is not int or not 0 < value <= 400000000:
            raise DeclarationError('positive exact bounded construction limits required')
    bound = dict(limits)
    rows = [None, None, None]
    names = list(HALTS)
    state = dict(schema='utf8-construction-prefix-v1', complete=False,
                 attempted_work=0, states=0, transitions=0,
                 rows=rows, names=names, limits=bound, stage='ENTRY', authority=False,
                 active_state=None, active_choices=None)
    memo = {}
    roots = {}

    def step(kind):
        state['attempted_work'] += 1
        if state['attempted_work'] > bound['work']:
            raise ConstructionLimit('construction work')
        if kind != 'work':
            state[kind] += 1
            if state[kind] > bound[kind]:
                raise ConstructionLimit('construction '+kind)
        check()

    def allocate(name):
        step('states')
        q = len(rows)
        rows.append(None)
        names.append(name)
        return q

    def assign(q, zero, one, blank):
        if rows[q] is not None:
            raise DeclarationError('internal state assigned twice')
        choices = []
        state['active_state'] = q
        state['active_choices'] = choices
        for symbol, target, move in (('B', blank, 0), ('0', zero, 1),
                                     ('1', one, 1), ('#', 2, 0)):
            choices.append([q, symbol, target, symbol, move])
            step('transitions')
        rows[q] = choices
        state['active_state'] = None
        state['active_choices'] = None

    def residual(mode, depth, prefix):
        step('work')
        if depth == 8:
            out = _next_mode(mode, prefix)
            return 1 if out is None else roots[out]
        zero = residual(mode, depth+1, prefix)
        one = residual(mode, depth+1, prefix+(1 << depth))
        # Equal-depth, equal-successor rows have identical residual behavior.
        # Depth is retained: even an impossible prefix consumes eight bits,
        # and a capacity fence still yields BOUND before that byte completes.
        key = (depth, zero, one)
        step('work')
        if key in memo:
            return memo[key]
        q = allocate('residual/'+str(depth)+'/'+str(zero)+'/'+str(one))
        assign(q, zero, one, 1)
        memo[key] = q
        return q

    try:
        step('work')
        # Halts count toward the same explicit state budget.
        for _ in HALTS:
            step('states')
        state['stage'] = 'ROOTS'
        for mode in MODES:
            roots[mode] = allocate('byte/'+mode)
        state['stage'] = 'RESIDUALS'
        for mode in MODES:
            zero = residual(mode, 1, 0)
            one = residual(mode, 1, 1)
            assign(roots[mode], zero, one, 0 if mode == 'LEAD' else 1)
        state['stage'] = 'COMPLETE_TABLE'
        delta = []
        undefined = []
        for q, row in enumerate(rows):
            step('work')
            if q < 3:
                if row is not None:
                    raise DeclarationError('halt has executable rows')
                for symbol in ALPHABET:
                    step('work')
                    undefined.append([q, symbol])
            else:
                if type(row) is not list or len(row) != len(ALPHABET):
                    raise DeclarationError('incomplete physical state')
                for entry in row:
                    step('work')
                    target = entry[2]
                    if type(target) is not int or not 0 <= target < len(rows):
                        raise DeclarationError('dangling literal physical target')
                    delta.append(entry)
        if len(rows) > SOURCE_ALL_STATE_UPPER_BOUND:
            raise DeclarationError('Source state upper bound contradicted')
        if len(delta) > SOURCE_TRANSITION_UPPER_BOUND:
            raise DeclarationError('Source transition upper bound contradicted')
        step('work')
        state['stage'] = 'CLOSED'
        state['complete'] = True
        return dict(schema='utf8-residual-physical-machine-v1', version=VERSION,
                    alphabet=list(ALPHABET), states=names, delta=delta,
                    undefined=undefined, entries=dict(roots), initial=roots['LEAD'],
                    blank='B', halts=dict(DONE=0, REJECT=1, BOUND=2),
                    bit_order='least-significant-bit-first', bits_per_byte=8,
                    construction_counts=dict(attempted_work=state['attempted_work'],
                                             states=state['states'], transitions=state['transitions']),
                    scope='One physical lexical routine; no complete VM or proof checker.',
                    runtime_qualified=False, complete_interpreter=False,
                    mathematical_authority=False)
    except BaseException as error:
        # Raw ownership only. No callback, cloning, normalization or extra
        # traversal while handling the primary construction fault.
        try:
            error.utf8_construction_prefix = state
        except BaseException:
            pass
        raise
