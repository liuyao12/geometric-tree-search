"""SOURCE ONLY: canonical strict literal-value DAG, proposed/unadopted G1.

Never imported or called during authoring. Root owns evidence-schema binding,
all actual/grant/resource acceptance and raw Python object/callback custody.
"""
VERSION = 'strict-value-dag-v1'
MAGIC = b'GCTSDAG1\x00'
LIMIT_KEYS = ('work', 'nodes', 'roots', 'wire_bytes', 'record_bytes',
              'references', 'value_depth', 'integer_bits', 'string_bytes',
              'float_chars', 'expanded_items', 'counter_bits')
_OWNER = object()


class Invalid(Exception):
    def __init__(self, reason, *, _owner=None):
        self.reason = reason
        self._owner = _owner
        super().__init__(reason)


class Limit(Exception):
    def __init__(self, reason, attempted_work=None, *, _owner=None):
        self.reason = reason
        self.attempted_work = attempted_work
        self._owner = _owner
        super().__init__(reason)


def is_own_invalid(error):
    return type(error) is Invalid and error._owner is _OWNER


def is_own_limit(error):
    return type(error) is Limit and error._owner is _OWNER


def _bad(reason):
    return Invalid(reason, _owner=_OWNER)


class _Work:
    def __init__(self, check, limits):
        # Constructor has no delegated callback. The caller stores this object
        # before its first tick, so a first-callback fault keeps its Work owner.
        if not callable(check):
            raise _bad('callable check required')
        if type(limits) is not dict or len(limits) != len(LIMIT_KEYS):
            raise _bad('exact twelve-key limits required')
        copied = {}
        for key in limits:
            if type(key) is not str or key not in LIMIT_KEYS:
                raise _bad('exact literal limit keys required')
        for key in LIMIT_KEYS:
            value = limits[key]
            if type(value) is not int or value <= 0:
                raise _bad('positive exact-int limits required')
            copied[key] = value
        for value in copied.values():
            if value.bit_length() > copied['counter_bits']:
                raise _bad('limit metadata exceeds declared counter bits')
        self.limits = copied
        self.check = check
        self.total = 0
        self.items = 0
        self.references = 0

    def tick(self, units=1):
        if type(units) is not int or units < 0:
            raise _bad('internal exact work units')
        self.total += max(1, units)
        if self.total > self.limits['work']:
            raise Limit('work', self.total, _owner=_OWNER)
        self.check()

    def bound(self, name, value):
        self.tick()
        if value > self.limits[name]:
            raise Limit(name, self.total, _owner=_OWNER)

    def visit(self, depth):
        self.items += 1
        self.bound('expanded_items', self.items)
        self.bound('value_depth', depth)

    def refs(self, count):
        self.references += count
        self.bound('references', self.references)


def _unsigned(value, w):
    if type(value) is not int or value < 0:
        raise _bad('internal unsigned counter')
    if value.bit_length() > w.limits['counter_bits']:
        raise Limit('counter_bits', w.total, _owner=_OWNER)
    out = bytearray()
    while True:
        w.tick()
        part = value & 127
        value >>= 7
        out.append(part | (128 if value else 0))
        if not value:
            return bytes(out)


class _Reader:
    def __init__(self, raw, w):
        self.raw, self.w, self.position = raw, w, 0

    def take(self, count):
        self.w.tick(count)
        if type(count) is not int or count < 0 or count > len(self.raw) - self.position:
            raise _bad('truncated length-delimited data')
        begin = self.position
        self.position += count
        return self.raw[begin:self.position]

    def uint(self, maximum, *, structural=False):
        value = 0
        shift = 0
        count = 0
        while True:
            byte = self.take(1)[0]
            count += 1
            part = byte & 127
            if shift >= self.w.limits['counter_bits']:
                raise Limit('counter_bits', self.w.total, _owner=_OWNER)
            value |= part << shift
            if value.bit_length() > self.w.limits['counter_bits']:
                raise Limit('counter_bits', self.w.total, _owner=_OWNER)
            if value > maximum:
                if structural:
                    raise _bad('reference outside earlier-node domain')
                raise Limit('declared_counter_capacity', self.w.total, _owner=_OWNER)
            if byte < 128:
                if count > 1 and part == 0:
                    raise _bad('nonminimal unsigned integer')
                return value
            shift += 7

    def end(self):
        self.w.tick()
        if self.position != len(self.raw):
            raise _bad('trailing data')


def _record(tag, children, payload, w):
    if tag in (0, 1, 2):
        return bytes((tag,))
    if tag == 3:
        bits = payload.bit_length()
        w.bound('integer_bits', bits)
        count = (bits + 7) // 8
        w.bound('record_bytes', count + 3 + w.limits['counter_bits'])
        w.tick(count)
        magnitude = abs(payload).to_bytes(count, 'big')
        return b'\x03' + bytes((1 if payload < 0 else 0,)) + _unsigned(count, w) + magnitude
    if tag == 4:
        text = payload.hex()
        w.bound('float_chars', len(text))
        raw = text.encode('ascii')
        w.tick(len(raw))
        return b'\x04' + _unsigned(len(raw), w) + raw
    if tag == 5:
        # The four-byte-per-code-point estimate is an allocation preflight,
        # not a claim that ASCII costs four logical bytes. A conservative limit
        # can refuse before encoding; it never truncates or normalizes a value.
        w.bound('string_bytes', 4 * len(payload))
        w.bound('record_bytes', 4 * len(payload) + 1 + w.limits['counter_bits'])
        raw = payload.encode('utf8', 'surrogatepass')
        w.bound('string_bytes', len(raw))
        w.tick(len(raw))
        return b'\x05' + _unsigned(len(raw), w) + raw
    count = len(children) // 2 if tag == 8 else len(children)
    out = bytearray(bytes((tag,)) + _unsigned(count, w))
    for child in children:
        w.tick()
        piece = _unsigned(child, w)
        w.bound('record_bytes', len(out) + len(piece))
        out.extend(piece)
    return bytes(out)


def _container_items(value, w):
    if type(value) is dict:
        w.bound('expanded_items', w.items + 2 * len(value))
        rows = []
        for key, item in value.items():
            w.tick()
            rows.append(key)
            rows.append(item)
        return rows
    w.bound('expanded_items', w.items + len(value))
    rows = []
    for item in value:
        w.tick()
        rows.append(item)
    return rows


def _encode(roots, state, w):
    if type(roots) is not tuple:
        raise _bad('exact outer tuple of ordered root occurrences required')
    w.bound('roots', len(roots))
    records = state['records']
    index = {}  # Fresh exact-byte-key interning per invocation; never a cache.
    root_ids = state['root_ids']
    active = set()
    record_storage = 0
    for root in roots:
        pending = [('enter', root, 0)]
        results = []
        while pending:
            action, value, depth = pending.pop()
            w.tick()
            if action == 'finish':
                original, tag, count = value
                children = results[-count:] if count else []
                if count:
                    del results[-count:]
                record = _record(tag, children, None, w)
                active.remove(id(original))
            else:
                w.visit(depth)
                kind = type(value)
                if value is None:
                    tag, payload = 0, None
                elif kind is bool:
                    tag, payload = (2 if value else 1), None
                elif kind is int:
                    tag, payload = 3, value
                elif kind is float:
                    tag, payload = 4, value
                elif kind is str:
                    tag, payload = 5, value
                elif kind in (list, tuple, dict):
                    if id(value) in active:
                        raise _bad('cyclic literal input not supported')
                    active.add(id(value))
                    children_values = _container_items(value, w)
                    tag = 6 if kind is list else 7 if kind is tuple else 8
                    w.refs(len(children_values))
                    pending.append(('finish', (value, tag, len(children_values)), depth))
                    for position in range(len(children_values) - 1, -1, -1):
                        w.tick()
                        pending.append(('enter', children_values[position], depth + 1))
                    continue
                else:
                    raise _bad('unsupported exact literal type')
                record = _record(tag, (), payload, w)
            w.bound('record_bytes', len(record))
            w.tick(len(record))  # Exact-byte lookup, not hash-only attribution.
            identity = index.get(record)
            if identity is None:
                w.bound('nodes', len(records) + 1)
                record_storage += len(record)
                w.bound('wire_bytes', record_storage)
                identity = len(records) + 1
                index[record] = identity
                records.append(record)
            results.append(identity)
        if len(results) != 1:
            raise _bad('internal root traversal shape')
        root_ids.append(results[0])
    state['stage'] = 'ENCODING_WIRE'
    out = bytearray(MAGIC)
    def append(piece):
        w.bound('wire_bytes', len(out) + len(piece))
        w.tick(len(piece))
        out.extend(piece)
    append(_unsigned(len(records), w))
    for record in records:
        append(_unsigned(len(record), w))
        append(record)
    append(_unsigned(len(root_ids), w))
    for identity in root_ids:
        append(_unsigned(identity, w))
    w.tick(len(out))
    wire = bytes(out)
    state['produced_wire'] = wire  # Retain complete output before final callback.
    return wire


def _parse_record(raw, ordinal, w):
    r = _Reader(raw, w)
    tag = r.take(1)[0]
    if tag in (0, 1, 2):
        payload, children = None, ()
    elif tag == 3:
        sign = r.take(1)[0]
        if sign not in (0, 1):
            raise _bad('integer sign byte')
        count = r.uint((w.limits['integer_bits'] + 7) // 8)
        magnitude = r.take(count)
        if count and magnitude[0] == 0:
            raise _bad('integer magnitude has leading zero')
        if not count and sign:
            raise _bad('negative integer zero')
        value = int.from_bytes(magnitude, 'big')
        w.bound('integer_bits', value.bit_length())
        payload, children = (-value if sign else value), ()
    elif tag == 4:
        count = r.uint(w.limits['float_chars'])
        raw_text = r.take(count)
        try:
            text = raw_text.decode('ascii')
            value = float.fromhex(text)
        except (ValueError, OverflowError, UnicodeError):
            raise _bad('invalid float-hex payload')
        if value.hex() != text:
            raise _bad('noncanonical float-hex payload')
        payload, children = text, ()
    elif tag == 5:
        count = r.uint(w.limits['string_bytes'])
        raw_text = r.take(count)
        try:
            text = raw_text.decode('utf8', 'surrogatepass')
        except UnicodeError:
            raise _bad('invalid surrogatepass UTF8 payload')
        if text.encode('utf8', 'surrogatepass') != raw_text:
            raise _bad('noncanonical surrogatepass UTF8 payload')
        payload, children = text, ()
    elif tag in (6, 7, 8):
        count = r.uint(w.limits['references'])
        edge_count = 2 * count if tag == 8 else count
        w.refs(edge_count)
        values = []
        for unused in range(edge_count):
            w.tick()
            identity = r.uint(ordinal - 1, structural=True)
            if identity < 1:
                raise _bad('reference must name an earlier positive node')
            values.append(identity)
        payload, children = None, tuple(values)
    else:
        raise _bad('unknown node tag')
    r.end()
    return tag, payload, children


def _canonical_order(nodes, roots, w):
    seen = set()
    next_ordinal = 1
    for root in roots:
        pending = [('enter', root)]
        while pending:
            action, identity = pending.pop()
            w.tick()
            if action == 'finish':
                if identity != next_ordinal:
                    raise _bad('node order is not first-use postorder')
                next_ordinal += 1
                continue
            if identity in seen:
                continue
            seen.add(identity)
            pending.append(('finish', identity))
            children = nodes[identity - 1][2]
            for position in range(len(children) - 1, -1, -1):
                w.tick()
                pending.append(('enter', children[position]))
    if next_ordinal != len(nodes) + 1:
        raise _bad('unreachable node')


def _parse(wire, state, w):
    if type(wire) is not bytes:
        raise _bad('exact bytes wire required')
    w.bound('wire_bytes', len(wire))
    r = _Reader(wire, w)
    if r.take(len(MAGIC)) != MAGIC:
        raise _bad('wire magic/version')
    count = r.uint(w.limits['nodes'])
    records, nodes = state['records'], state['nodes']
    unique = {}
    for ordinal in range(1, count + 1):
        w.tick()
        size = r.uint(w.limits['record_bytes'])
        raw = r.take(size)
        w.tick(len(raw))
        if raw in unique:
            raise _bad('duplicate node record')
        unique[raw] = ordinal
        node = _parse_record(raw, ordinal, w)
        records.append(raw)
        nodes.append(node)
    root_count = r.uint(w.limits['roots'])
    roots = state['root_ids']
    for unused in range(root_count):
        w.tick()
        identity = r.uint(count, structural=True)
        if identity < 1:
            raise _bad('positive root node required')
        roots.append(identity)
    r.end()
    _canonical_order(nodes, roots, w)
    return nodes, roots


def _materialize(nodes, roots, state, w):
    # No native-value cache: every ordered reference occurrence is expanded
    # freshly. This preserves mutable-container separation and distinct NaN
    # dictionary-key occurrences. Raw input object identity is outside the codec.
    output = []
    for root in roots:
        pending = [('enter', root, 0)]
        results = []
        while pending:
            action, value, depth = pending.pop()
            w.tick()
            if action == 'finish':
                tag, count = value
                children = results[-count:] if count else []
                if count:
                    del results[-count:]
                if tag == 6:
                    result = list(children)
                elif tag == 7:
                    result = tuple(children)
                else:
                    result = {}
                    for position in range(0, len(children), 2):
                        w.tick()
                        before = len(result)
                        try:
                            result[children[position]] = children[position + 1]
                        except TypeError:
                            raise _bad('unhashable dictionary key')
                        if len(result) != before + 1:
                            raise _bad('dictionary keys collide under builtin equality')
                results.append(result)
                continue
            w.visit(depth)
            tag, payload, children = nodes[value - 1]
            if tag >= 6:
                w.bound('expanded_items', w.items + len(children))
                pending.append(('finish', (tag, len(children)), depth))
                for position in range(len(children) - 1, -1, -1):
                    w.tick()
                    pending.append(('enter', children[position], depth + 1))
                continue
            if tag == 0:
                result = None
            elif tag == 1:
                result = False
            elif tag == 2:
                result = True
            elif tag == 4:
                result = float.fromhex(payload)
            else:
                result = payload
            results.append(result)
        if len(results) != 1:
            raise _bad('internal materialization shape')
        output.append(results[0])
    values = tuple(output)
    state['produced_values'] = values
    return values


def _run(operation, subject, check, limits, retain):
    state = dict(schema='strict-value-dag-lifetime-v1', operation=operation,
        stage='INTAKE', input=subject, budget=None, records=[], nodes=[],
        root_ids=[], produced_wire=None, produced_values=None,
        registered=False, primary_error=None, authority=False)
    try:
        if not callable(retain):
            raise _bad('Root lifetime retainer required')
        if retain(state) is not None:
            raise _bad('retainer must return None')
        state['registered'] = True
        w = _Work(check, limits)
        state['budget'] = w
        w.tick()
        if operation == 'encode':
            state['stage'] = 'ENCODING_VALUES'
            wire = _encode(subject, state, w)
            values = None
        else:
            state['stage'] = 'VALIDATING_WIRE'
            nodes, roots = _parse(subject, state, w)
            state['stage'] = 'VALIDATING_NATIVE_CORRESPONDENCE'
            values = _materialize(nodes, roots, state, w)
            wire = subject
        state['stage'] = 'FINAL_CALLBACK'
        w.tick()
        state['stage'] = 'COMPLETE'
        receipt = dict(schema='strict-value-dag-receipt-v1', version=VERSION,
            operation=operation, status='SOURCE_CANDIDATE_COMPLETE',
            node_count=len(state['records']), root_occurrences=len(state['root_ids']),
            unique_logical_charge_bytes=len(wire), stored_wire_bytes=len(wire),
            charge_contract='PROPOSED_G1_CANONICAL_UNIQUE_NODE_RECORDS_AND_ALL_STORED_REFERENCES',
            old_G0_unfolding_charged=False, G1_adopted=False,
            attempted_work=w.total, expanded_occurrence_items=w.items,
            traversed_references=w.references, authority=False,
            runtime_qualified=False, mathematical_authority=False)
        if operation == 'encode':
            receipt['wire'] = wire
        elif operation == 'decode':
            receipt['values'] = values
        state['receipt'] = receipt
        return receipt
    except BaseException as primary:
        state['primary_error'] = primary
        try:
            w = state['budget']
            primary.strict_value_dag_prefix = dict(schema='strict-value-dag-failure-prefix-v1',
                operation=operation, stage=state['stage'],
                attempted_work=None if w is None else w.total,
                retained_node_records=len(state['records']),
                retained_root_references=len(state['root_ids']),
                produced_wire_available=state['produced_wire'] is not None,
                produced_values_available=state['produced_values'] is not None,
                registered=state['registered'], authority=False)
        except BaseException:
            pass
        raise


def encode_values(roots, *, check, limits, retain):
    """Fresh complete store for an exact tuple of ordered root occurrences."""
    return _run('encode', roots, check, limits, retain)


def decode_values(wire, *, check, limits, retain):
    """Complete canonical validation and fresh native root materialization."""
    return _run('decode', wire, check, limits, retain)


def validate_store(wire, *, check, limits, retain):
    """Same complete validation/materialization; only ordinary receipt returned.

    Native values remain in the registered lifetime. This is not a cheap header
    or hash check and may refuse its occurrence-expansion quota.
    """
    return _run('validate', wire, check, limits, retain)
