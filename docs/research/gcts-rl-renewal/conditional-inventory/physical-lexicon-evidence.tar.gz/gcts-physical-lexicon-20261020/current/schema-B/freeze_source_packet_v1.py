"""Raw Source/document pins only; no codec import/call or fixture/sizing work."""
from pathlib import Path
import hashlib
import json
import sys

O=Path(__file__).resolve().parent
old=O.parent.parent/'gcts-batch-20261020'
prior=O.parent.parent/'gcts-evidence-next-20261020'
def pin(path):
    raw=path.read_bytes()
    return dict(path=str(path.resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
retirement=old/'root/ROOT-grant-retirement-v2.json'
retired=json.loads(retirement.read_bytes())
assert retired['grant_status']=='RETIRED' and retired['remaining_actual_invocations']==0
audit=json.loads((O/'author-static-audit-v1.json').read_bytes())
source=pin(O/'strict_value_dag_v1.py')
assert source==audit['source']
all_files=[pin(path)for path in sorted(O.iterdir())if path.is_file() and path.name!='handoff-v1.json']
record=dict(schema='strict-value-dag-Source-handoff-v1',
    author='/root/recovered_batch_integration',status='FROZEN_SOURCE_ONLY_UNEXECUTED_UNADOPTED_G1',
    source=source,API=pin(O/'API-v1.json'),
    prospective_whole_bank=pin(O/'diagnostic-bank-v1.json'),
    prospective_case_count=audit['prospective_cases'],prospective_categories=audit['categories'],
    manual_correspondence=pin(O/'manual-codec-correspondence-v1.json'),
    author_static_audit=pin(O/'author-static-audit-v1.json'),
    predecessor_worker=pin(old/'root/qualify_complete_batch_worker_v2.py'),
    master=pin(old/'publisher/docs/basic-tiling-algorithm.md'),master_read_fully=True,
    predecessor_field_map=pin(prior/'bounds-B/one-owner-field-map-v1.json'),
    retirement=pin(retirement),old_grants_remaining=0,
    python=pin(Path(sys.executable)),python_version=sys.version,
    files=all_files,
    exact_type_domain=['None','bool','int','float_hex','surrogatepass_str','list','tuple','ordered_dict'],
    supported_forest='Finite acyclic exact builtin literal values; repeated values share records but preserve every root/parent occurrence. Raw identity/custody is separately retained.',
    charge='Exact canonical wire-size formula for unique node records and all stored references; explicitly different/unadopted G1, never oldG0 unfolding.',
    constraints='No parent schema/integration, fixture adapter, full-case binding or fit bound is supplied. Root must review and adopt an exact complete G1 subject before any separate grant.',
    unchanged_caps=dict(positive_seconds=180,custody_seconds=210,worker_HWM_bytes=1073741824,
        stored_bytes=134217728,expanded_bytes=134217728,physical_including_reserve_bytes=134217728,
        reserve_bytes=9437184,each_regular_log_bytes=4194304,root_callback_limit=400000000),
    Source_imports_executed=0,Source_function_calls=0,Source_helper_calls=0,
    fixture_calls=0,checker_calls=0,simulator_calls=0,sizing_calls=0,
    generator_functions_called=0,unused_code_objects_executed=0,
    partial_files_read=0,actual_launches=0,
    G1_adopted=False,new_actual_authority=False,runtime_qualified=False,fit_proved=False,
    mathematical_authority=False,proof_discovery=False,GCTS_RL_advantage=False)
out=O/'handoff-v1.json'
assert not out.exists()
out.write_text(json.dumps(record,indent=2,ensure_ascii=True)+'\n')
print(json.dumps(pin(out),indent=2))
