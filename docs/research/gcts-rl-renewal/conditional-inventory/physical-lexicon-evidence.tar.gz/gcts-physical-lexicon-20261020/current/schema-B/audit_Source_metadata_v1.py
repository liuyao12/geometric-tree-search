"""Passive Source/AST/unused compile and literal-bank metadata authoring only."""
from pathlib import Path
import ast
import hashlib
import json
import sys

O=Path(__file__).resolve().parent
old=O.parent.parent/'gcts-batch-20261020'
prior=O.parent.parent/'gcts-evidence-next-20261020'
def pin(path):
    raw=path.read_bytes()
    return dict(path=str(path.resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
source=O/'strict_value_dag_v1.py'
raw=source.read_bytes()
tree=ast.parse(raw,filename=str(source))
unused=compile(tree,str(source),'exec')
del unused  # No import, exec or evaluation of the code object.
bank=json.loads((O/'diagnostic-bank-v1.json').read_bytes())
ids=[row['id']for row in bank['cases']]
assert len(ids)==len(set(ids))
categories={}
for row in bank['cases']:
    categories[row['category']]=categories.get(row['category'],0)+1
for name in('API-v1.json','manual-codec-correspondence-v1.json'):
    json.loads((O/name).read_bytes())
python=pin(Path(sys.executable))
assert python['sha256']=='b6ea0c2a9bfce48dbf181a53f1ca4f0562d40658b85bf47258e2a88d8f9e3933'
master=pin(old/'publisher/docs/basic-tiling-algorithm.md')
assert master['sha256']=='ca6ee206287bf18b69f88a35d30968312499567755f347a819af4cf49743e7d4'
worker=pin(old/'root/qualify_complete_batch_worker_v2.py')
assert worker['sha256']=='9ea014de87d5af2ed3017442f690699a0ef54750c8d8be12890e373936b65a03'
audit=dict(schema='strict-value-dag-author-Source-audit-v1',status='UNUSED_COMPILE_ONLY',
    source=pin(source),python=python,python_version=sys.version,
    ast_sha256=hashlib.sha256(ast.dump(tree,annotate_fields=True,include_attributes=False).encode()).hexdigest(),
    AST_policy='ast.dump(annotate_fields=True,include_attributes=False), UTF8',
    generator_nodes=sum(isinstance(node,(ast.GeneratorExp,ast.Yield,ast.YieldFrom))for node in ast.walk(tree)),
    import_nodes=sum(isinstance(node,(ast.Import,ast.ImportFrom))for node in ast.walk(tree)),
    prospective_bank=pin(O/'diagnostic-bank-v1.json'),prospective_cases=len(ids),categories=categories,
    unique_case_ids=True,master=master,predecessor_worker=worker,
    predecessor_field_map=pin(prior/'bounds-B/one-owner-field-map-v1.json'),
    subject_imports=0,subject_function_calls=0,subject_helper_calls=0,
    semantic_sizing_calls=0,fixture_calls=0,simulator_calls=0,
    code_objects_executed=0,partial_files_read=0,actual_launches=0,
    G1_adopted=False,fit_proved=False,runtime_qualified=False,mathematical_authority=False)
out=O/'author-static-audit-v1.json'
assert not out.exists()
out.write_text(json.dumps(audit,indent=2,ensure_ascii=True)+'\n')
print(json.dumps(dict(source=audit['source'],audit=pin(out),cases=len(ids),categories=categories),indent=2))
