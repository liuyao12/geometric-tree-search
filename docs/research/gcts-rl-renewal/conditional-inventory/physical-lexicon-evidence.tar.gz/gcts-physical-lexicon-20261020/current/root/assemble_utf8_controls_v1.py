"""Source-text author only; never imports/calls a research subject or control."""
from pathlib import Path
import ast
import hashlib
import json

BASE=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs')
OLD=BASE/'gcts-batch-20261020/root'
ROOT=BASE/'gcts-complete-evidence-20261020/root'
runner=(OLD/'run_batch_once_v1.py').read_text()
start=runner.index('def validate_qualification(')
end=runner.index('\n\ndef main(',start)
validator='''def validate_qualification(q,plan,declaration,outputs):
    need(q['schema']=='utf8-lexical-component-candidate-v1'and
         q['status']=='COMPLETE_COMPONENT_CALIBRATION_CANDIDATE','whole lexical component result')
    need(q['outputs']==outputs and len(outputs)==1,'one whole canonical packet')
    need(q['normal_group_ids']==declaration['normal_group_ids']and
         q['normal_counts']==declaration['normal_counts']and
         q['normal_case_count']==5378,'entire unchanged UTF8v2 normal population')
    states=q['states'];transitions=q['transitions']
    need(type(states)is int and 10<=states<=100 and type(transitions)is int and
         transitions==4*(states-3)and q['undefined']==12,'complete fixed literal table census')
    need(q['diagnostic_ids']==declaration['diagnostic_ids']and
         [g['id']for g in q['diagnostics']]==declaration['diagnostic_ids']and
         all(g['complete']is True for g in q['diagnostics']),'all five full diagnostic groups')
    need([g['variants']for g in q['diagnostics']]==[32,3,25,3*transitions+states-3,0],
         'whole invalid/quota/foreign/full-row mutation/identity populations')
    need(q['compiler_calls']==62 and q['compiler_completed']==2 and q['compiler_raised']==60,
         'all complete construction and interruption calls accounted')
    need(q['search_calls']==0 and q['oracle_calls']==5378 and
         type(q['verifier_calls'])is int and q['verifier_calls']>5378,'full independent verification census')
    need(type(q['root_check_calls'])is int and 0<q['root_check_calls']<=400000000,'original total callback cap')
    for key in('complete_physical_VM','proof_discovery','G1_adopted','gcts_rl_advantage_established',
               'full_pipeline_qualified','mathematical_proof_accepted'):
        need(q[key]is False,'no broader authority')
'''
runner=runner[:start]+validator+runner[end:]
replacements={
    'One Root-owned complete batched implicit palette/point-graph calibration; original caps.':'One Root-owned complete UTF8v2 physical lexical component qualification; original caps.',
    "VERSION='implicit-batch-point-graph-once-runner-v1'":"VERSION='utf8-physical-lexical-once-runner-v1'",
    "SOURCE_ROLES=frozenset(('worker','implicit','graph','selector','runner','observer'))":"SOURCE_ROLES=frozenset(('worker','utf8','runner','observer'))",
    "len(plan['inputs'])==2,'unchanged complete original bank plus separate complete new diagnostic bank'":"len(plan['inputs'])==1,'entire original UTF8v2 component bank'",
    "profile='complete-batched-implicit-palette-point-graph-calibration'":"profile='complete-UTF8v2-physical-lexical-component'",
}
for before,after in replacements.items():
    assert runner.count(before)==1,before
    runner=runner.replace(before,after)
observer=(OLD/'observe_batch_once_v1.py').read_text()
before="VERSION='implicit-batch-point-graph-terminal-observer-v1'"
assert observer.count(before)==1
observer=observer.replace(before,"VERSION='utf8-physical-lexical-terminal-observer-v1'")
old_scope="Finite complete batched implicit-palette, singleton-center point-graph and batch/summary diagnostic calibration only; no full literal expansion, physical interpreter, FOL kernel/proof search or advantage qualification. Runner Source-entry epoch excludes observer/interpreter prelude. Standalone worker highwater has no Native/full-production fit authority."
new_scope="Complete declared UTF8v2 physical lexical component only. No G1, old palette/graph-cohort rescue, full VM/BOOT, FOL proof search, tiling/plane result or advantage qualification. Runner Source-entry epoch excludes observer/interpreter prelude. Standalone worker highwater has no Native/full-production fit authority."
assert observer.count(old_scope)==1
observer=observer.replace(old_scope,new_scope)
for name,source in [('run_utf8_once_v1.py',runner),('observe_utf8_once_v1.py',observer)]:
    path=ROOT/name
    ast.parse(source);compile(source,str(path),'exec')
    if path.exists():assert path.read_text()==source
    else:path.write_text(source)
worker=ROOT/'qualify_utf8_worker_v1.py'
ast.parse(worker.read_bytes());compile(worker.read_bytes(),str(worker),'exec')
report={'schema':'ROOT-utf8-controls-static-assembly-v1','status':'UNEXECUTED_SOURCE_ONLY',
        'old_runner_sha256':hashlib.sha256((OLD/'run_batch_once_v1.py').read_bytes()).hexdigest(),
        'old_observer_sha256':hashlib.sha256((OLD/'observe_batch_once_v1.py').read_bytes()).hexdigest(),
        'runner_delta':'Only docstring/version/source-role set/input population/profile and complete qualification validator replaced; original process/log/resource/clock/custody cleanup retained.',
        'observer_delta':'Only version and scope replaced; no epoch/timeout/resource changes.',
        'AST_unused_compile':True,'compiled_code_executed':False,'subject_imports':0,'subject_function_calls':0,
        'control_calls':0,'fixture_calls':0,'sizing_probes':0,'actual_authorized':False,'new_grants':0,
        'sources':[{ 'path':str(ROOT/name),'bytes':len((ROOT/name).read_bytes()),'sha256':hashlib.sha256((ROOT/name).read_bytes()).hexdigest()} for name in ['qualify_utf8_worker_v1.py','run_utf8_once_v1.py','observe_utf8_once_v1.py']]}
(ROOT/'utf8-controls-static-assembly-v1.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps(report))
