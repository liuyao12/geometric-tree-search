"""Root raw-custody metadata only; no subject, fixture or control execution."""
from pathlib import Path
import hashlib
import json
import shutil
import sys

ROOT=Path(__file__).resolve().parent
def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode()
def pin(path):
    path=Path(path).resolve();raw=path.read_bytes()
    return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def checked(p):
    assert pin(p['path'])==p
    return Path(p['path']).read_bytes()
def save(name,x):
    path=ROOT/name;assert not path.exists();path.write_bytes(canonical(x)+b'\n');return pin(path)

assert len(sys.argv)==3
review_path=Path(sys.argv[1]).resolve();assert pin(review_path)['sha256']==sys.argv[2]
review=json.loads(review_path.read_bytes())
offer=json.loads((ROOT/'utf8-Source-offer-v1.json').read_bytes())
subject=offer['subject'];subject_sha=hashlib.sha256(canonical(subject)).hexdigest()
assert subject_sha==offer['subject_sha256']=='d57adc6054cd43ed4623029655578709c6657e2e2705b3a8418dacd1d96d5712'
assert review['schema']=='wang-encoding-Source-prospective-review-v1'and review['reviewer_identity']=='/root/recovered_batch_review'
assert review['review_passed']is True and review['source_only']is True and review['failed_checks']==[]
assert type(review['component_calls'])is int and review['component_calls']==0
assert review['actual_execution_authorized']is False and review['subject']==subject and review['subject_sha256']==subject_sha
checked(subject['python'])
for p in subject['sources'].values():checked(p)
for p in subject['inputs']:checked(p['pin'])
declaration=json.loads(checked(subject['declaration']));closure=json.loads(checked(subject['runtime_closure']))
checked(declaration['manual_envelope'])
for p in closure['stdlib_files']:checked(p)
assert not Path(subject['actual_directory']).exists()
assert not (ROOT/'utf8-plan-authorized-v1-terminal-observation').exists()
barrier=json.loads((ROOT/'barrier-before-utf8-grant-v1.json').read_bytes())
assert barrier['other_agents_tools_stopped']is True and barrier['no_subject_execution_yet']is True and barrier['new_grants_before_this']==0
assert shutil.disk_usage(ROOT).free>2*1024*1024*1024
authorization=save('utf8-authorization-once-v1.json',dict(schema='ROOT-wang-encoding-authorization-v1',author_identity='/root',
    actual_execution_authorized=True,maximum_actual_invocations=1,subject_sha256=subject_sha,review=pin(review_path),
    scope='Exactly one complete declared UTF8v2 standalone physical lexical component qualification, all5378normals and all5diagnosticgroups. Original180/210/225,1GiB,both128MiB,9MiBreserve,4MiBlogs,400mcallbacks. No G1, trimmed oldcohort, oldnegative rescue, probe, rerun, fullBOOT/VM, theorem, GCTS/RL or speed authority.'))
plan=save('utf8-plan-authorized-v1.json',dict(subject,authorization=authorization))
issuance=save('ROOT-utf8-grant-issuance-v1.json',dict(schema='ROOT-exact-once-utf8-grant-issuance-v1',author_identity='/root',
    subject_sha256=subject_sha,review=pin(review_path),barrier=pin(ROOT/'barrier-before-utf8-grant-v1.json'),
    prospective_plan=offer['plan'],authorization=authorization,plan=plan,all_raw_pins_rechecked=True,
    actual_directory_absent_at_issuance=True,maximum_actual_invocations=1,subject_calls=0,old_grants_remaining=0))
print(json.dumps(dict(plan=plan,authorization=authorization,issuance=issuance),indent=2))
