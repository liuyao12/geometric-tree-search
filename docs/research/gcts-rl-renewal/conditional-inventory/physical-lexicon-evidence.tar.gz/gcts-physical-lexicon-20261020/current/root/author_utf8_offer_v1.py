"""Write ordinary Source-review/input metadata; execute no research routines."""
from pathlib import Path
import ast
import hashlib
import json

BASE=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs')
ROOT=BASE/'gcts-complete-evidence-20261020/root'
PREV=BASE/'gcts-evidence-next-20261020'
OLD=BASE/'gcts-batch-20261020/root'

def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode()
def pin(path):
    raw=path.read_bytes()
    return dict(path=str(path.resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def write(name,x):
    path=ROOT/name;raw=json.dumps(x,indent=2,sort_keys=True)+'\n'
    if path.exists():assert path.read_text()==raw
    else:path.write_text(raw)
    return pin(path)

source_paths={
    'worker':ROOT/'qualify_utf8_worker_v1.py','runner':ROOT/'run_utf8_once_v1.py',
    'observer':ROOT/'observe_utf8_once_v1.py','utf8':PREV/'root/utf8_residual_machine_v1.py'}
sources={role:pin(path)for role,path in source_paths.items()}
for path in source_paths.values():ast.parse(path.read_bytes());compile(path.read_bytes(),str(path),'exec')
limits=dict(work_seconds=180,overall_seconds=210,memory_bytes=1073741824,
    result_bytes=134217728,expanded_bytes=134217728,stdout_bytes=4194304,
    stderr_bytes=4194304,worker_receipt_bytes=4194304,
    runner_metadata_bytes=8388608,observer_bytes=1048576)
file_limits={'WORKER_CONSUMED.json':1048576,'canonical-utf8-calibration.json':50331648,
    'result.json':1048576,'worker-receipt.json':1048576,'worker-failure.json':50331648,'failure-summary.json':65536}
bankpin=pin(PREV/'root/utf8-prospective-bank-v2.json')
bank=json.loads(Path(bankpin['path']).read_bytes())
inputs=[dict(role='complete-UTF8v2-physical-lexical-bank',pin=bankpin)]
normal_ids=[g['id']for g in bank['normal_groups']]
normal_counts=dict(zip(normal_ids,[1792,1785,7,1778,16]))
assert sum(normal_counts.values())==5378

bound={
    'schema':'ROOT-utf8-complete-component-manual-envelope-v1',
    'status':'SOURCE_ONLY_CONDITIONAL_PREREQUISITE_PENDING_INDEPENDENT_REVIEW',
    'subject':sources,
    'not_a_probe':'No table, fixture, helper, simulator, subject, controller or sizing code was called. Character counts and finite Source case analysis only.',
    'LEAD_depth_upper':[1,2,4,5,5,7,7,7],
    'LEAD_argument':[
        'Depth0..2 use the full prefix population1/2/4.',
        'Depth3: with low3prefix p, remaining upper values0..15 always LEAD;16..23 REJECT;24 is REJECT at p0/1 and CONT1 otherwise;25..27 CONT1;28 E0_FIRST at p0 and CONT2 otherwise;29 CONT2;30 F0_FIRST at p0,CONT3 at p1..3,F4_FIRST at p4,REJECT otherwise;31 REJECT. Thus five classes0/1/2..3/4/5..7.',
        'Depth4: upper0..7 LEAD,8..11 REJECT,12 REJECT at lowprefix0/1 elseCONT1,13 CONT1,14 E0_FIRST at0 elseCONT2,15 F0_FIRST at0,CONT3 at1..3,F4_FIRST at4,REJECT otherwise. The same five classes0/1/2..3/4/other suffice.',
        'Depth5: upper0..3 LEAD,4..5 REJECT,6 REJECT at lowprefix0/1 elseCONT1,7 supplies E0_FIRST at0,CONT2 at1..15,F0_FIRST at16,CONT3 at17..19,F4_FIRST at20,REJECT at21..31. Seven lowprefix classes0/1/2..15/16/17..19/20/21..31 suffice.',
        'Depth6 residual vector is LEAD,LEAD,REJECT,lastlabel. lastlabel has only seven outputs REJECT/CONT1/E0_FIRST/CONT2/F0_FIRST/CONT3/F4_FIRST.',
        'Depth7 residual pair is LEAD,lastlabel with the same seven possibilities.',
        'Equal classifier residual functions have equal recursively interned successor pairs at the same depth. Separate roots and cross-mode sharing can only reduce this within-mode upper sum.'
    ],
    'other_modes_upper':[9,9,9,10,11,11],
    'assigned_upper':97,'all_states_upper':100,'literal_rows_upper':388,'undefined_halt_slots':12,
    'normal_population':normal_counts,'total_normals':5378,
    'normal_trajectory_steps_upper':40222,
    'normal_steps_argument':'Bytes1792*8=14336; prefix fence7*sum((d+1)*2**d,d0..7)=12551; midblank removes7root cases=12544; rootblank7;16word controls each at most49steps=784. Sum40222. Not CPU work.',
    'mutation_population_formula':'3*D+(Q-3), where D=4*(Q-3), Q<=100; all duplicate/dangling/wrong-move rows and every missing-fence row, full candidate table retained.',
    'mutation_population_upper':1261,'mutation_record_bytes_upper':24576,
    'mutation_size_argument':[
        'All state names use only the fixed ASCII name alphabet and at most64characters, at most100names. No escaping beyond quote delimiters is needed.',
        'A full or duplicate candidate has at most389rows. Every literal row has five entries: state/target at most100, single ASCII symbols, and move0/1 or deliberate2. Allow32bytes per row including comma.',
        'Allow100*(64+3)bytes for names and389*32for rows. The twelve halt slots, seven entries, fixed17field names, exact schema/version/scope, construction counters at most100000 and fixture/error/Source-location metadata fit a separate4096byte allowance. Total23244<24576.',
        'The worker independently checks the baseline shape/ASCII/census, only applies one exact documented patch, retains the whole candidate, and enforces the complete per-record bound. It never saves only a mutation hash or summary.'
    ],
    'normal_size_argument':'For a nonword there are at most8trace rows, each at most32bytes, at most9single-character tape cells and at most400bytes fixed group/mode/scalar metadata: below1024. A word has at most49trace rows,49tape cells,6byte atoms and400bytes metadata: below4096. Full trace+tape is saved.',
    'complete_packet_upper_terms':{
        'all_matrix_records':1261*24576,
        'all_nonword_normal_records':5362*1024,'all_word_records':16*4096,
        'all62_subject_call_records':62*32768,'all60_nonmatrix_failure_diagnostic_records':60*32768,
        'top_table_and_two_identity_table_views':3*32768,'all_remaining_bank_keys_delimiters_counts':1048576},
    'complete_packet_manual_upper_bytes':41691136,'complete_packet_lease_bytes':50331648,
    'failure_evidence':'Full in-memory completed ordinary rows/calls/diagnostics plus one pending group and active operation are retained on failure. Failure file has its own48MiB lease; no prefix/partial is read or repaired. An oversized failure remains a raw partial and cannot be admitted. Reserved scalar summary is attempted first and cannot mask the exact primary.',
    'maximum_physical_lease_bytes_including_logs_and_outer':sum(file_limits.values())+8388608+9437184,
    'physical_lease_argument':'Both48MiB main and48MiB failure leases remain charged even if failed, plus1MiB WORKER_CONSUMED,1MiB result,1MiB header,64KiB summary,4MiB per log and original9MiB outer reservation. No used-name retry/deletion/truncation or byte refund.',
    'stored_expanded_scope':'Every saved literal trace and mutated table is physically ordinary complete JSON; stored=expanded for this distinct component certificate. Not G1, not old v2 profile-return reconstruction, not an old-cohort rescue.',
    'work_argument':'Two complete constructions and all declaration/quota/foreign calls are charged. At most1261matrix fixtures each independently scans at most389rows plus100state checks; all5378trajectories total at most40222physical steps. Root guards/canonicalization/output/custody also share the original400m callbacks and180s wall deadline. No timing or fit measurement has occurred.',
    'memory_argument':'Full fixture tables share unmodified immutable baseline rows in memory while preserving every separate fixture object and full serialized input. At most1261candidate delta pointer lists of at most389members plus5378small trajectories and62call/prefix owners; no native solver or input-dependent machine. No exact Python heap or runtime fit is established; observed worker HWM must still pass1GiB.',
    'outer_limits':limits,'all_partials':'Raw bytes/length/hash only; never parse/project/complete/admit.',
    'component_qualification_only':True,'G1_adopted':False,'old_G0_unchanged':True,
    'actual_execution_authorized':False,'new_grants':0,'old_grant_remaining':0,
    'full_VM_implemented':False,'mathematical_authority':False}
assert sum(bound['complete_packet_upper_terms'].values())==bound['complete_packet_manual_upper_bytes']
assert bound['maximum_physical_lease_bytes_including_logs_and_outer']==121700352
boundpin=write('utf8-manual-envelope-v1.json',bound)
declaration={
    'schema':'ROOT-wang-encoding-qualification-declaration-v1',
    'experiment_kind':'COMPLETE_UTF8V2_PHYSICAL_LEXICAL_COMPONENT',
    'limits':limits,'generator_limits':dict(work=100000,states=317,transitions=1256),
    'file_limits':file_limits,'checkpoint_limit':400000000,'inputs':inputs,
    'normal_group_ids':normal_ids,'normal_counts':normal_counts,'exact_normal_cases':5378,
    'diagnostic_ids':[g['id']for g in bank['diagnostic_groups']],
    'diagnostic_variant_counts':{'exact-declaration-types':32,'construction-work-state-transition-cutoffs':3,
        'foreign-callback-identity':25,'complete-table-and-terminal-rows':'3*D+Q-3','fixed-machine-identity':1},
    'exact_generator_calls':62,'generator_completed':2,'generator_raised':60,
    'manual_envelope':boundpin,'full_pipeline_qualified':False,'G1_adopted':False,
    'authority':'Entire unchanged UTF8v2 bank, independent literal-matrix and complete trajectory component qualification only. No full VM/BOOT, Wang palette, old cohort, theorem, GCTS/RL or speed authority.',
    'newB_and_L':'Strict value codec and BOOT structural Source remain unrun and outside this exact subject.',
    'ordinary_table_semantics':'Literal states/delta/undefined/normal/diagnostic lists preserve complete order and multiplicity. Named mapping key order is not physical-machine semantics; effective call arguments retain the full old strict typed carrier, including dict order, float/int and missing/None.',
    'ownership':'Ordinary exclusive Source/input/actual-directory ownership, read-only diagnostic callbacks except exact planned raise and trigger recording; function/code/default/closure owners pinned, mutable globals not adversarially sealed.',
    'old_grant_remaining':0,'actual_execution_authorized':False}
declpin=write('utf8-declaration-v1.json',declaration)
oldclosure=json.loads((OLD/'batch-runtime-closure-v2.json').read_bytes())
pythonpin=oldclosure['python'];assert pin(Path(pythonpin['path']))==pythonpin
for p in oldclosure['stdlib_files']:assert pin(Path(p['path']))==p
imports={role:sorted({n.module if isinstance(n,ast.ImportFrom)else alias.name
    for n in ast.walk(ast.parse(path.read_bytes()))if isinstance(n,(ast.Import,ast.ImportFrom))
    for alias in ([None]if isinstance(n,ast.ImportFrom)else n.names)})for role,path in source_paths.items()}
closure={'schema':'ROOT-wang-encoding-runtime-closure-v1','python':pythonpin,'sources':sources,'declaration':declpin,
    'stdlib_files':oldclosure['stdlib_files'],'direct_import_census':imports,
    'runtime_trust':oldclosure['runtime_trust'],'source_only':True,'actual_execution_authorized':False,
    'predecessor_closure':pin(OLD/'batch-runtime-closure-v2.json')}
closurepin=write('utf8-runtime-closure-v1.json',closure)
authpin=write('utf8-authorization-prospective-false-v1.json',dict(schema='ROOT-wang-encoding-authorization-v1',author_identity='/root',
    actual_execution_authorized=False,maximum_actual_invocations=0,subject_sha256=None,review=None,scope='Prospective metadata only. No grant.'))
actual=ROOT/'actual-utf8-v1';assert not actual.exists()
plan={'schema':'ROOT-wang-encoding-qualification-plan-v1','invocation_id':'ROOT-UTF8v2-complete-20261020-v1',
    'actual_directory':str(actual),'python':pythonpin,'sources':sources,'inputs':inputs,'limits':limits,
    'declaration':declpin,'runtime_closure':closurepin,'authorization':authpin}
planpin=write('utf8-plan-prospective-v1.json',plan)
subject={k:v for k,v in plan.items()if k!='authorization'}
subjectsha=hashlib.sha256(canonical(subject)).hexdigest()
offer={'schema':'ROOT-UTF8v2-complete-Source-offer-v1','status':'SOURCE_ONLY_PENDING_EXACT_PROSPECTIVE_REVIEW',
    'subject':subject,'subject_sha256':subjectsha,'plan':planpin,'manual_envelope':boundpin,
    'old_subjects_and_grants':'All old negative results and retired0 grants unchanged. This is a separately declared complete lexical component qualification, not G1 or a trimmed old cohort.',
    'subject_imports':0,'subject_function_calls':0,'fixture_calls':0,'simulator_calls':0,'sizing_probes':0,
    'controller_calls':0,'actual_execution_authorized':False,'new_grants':0,'old_grant_remaining':0}
offerpin=write('utf8-Source-offer-v1.json',offer)
previouspin=pin(PREV/'root/ROOT-final-milestone-v1.json')
write('ROOT-continuation-assessment-v1.json',{'schema':'ROOT-continuation-assessment-v1','goal_status':'active',
    'previous_turn':'PROGRESS','previous_evidence':previouspin,'previous_published_commit':'78ea2758da701e41a350817c5089908b37d98989',
    'new_work':'Strict valuecodec Source, explicit completeG1 obligations, fully physical BOOT structural routine Source, and prospective whole UTF8v2 component qualification controls.',
    'no_subject_calls_or_actuals_yet':True,'old_grant_remaining':0,'new_grants':0,
    'full_objective_open':json.loads((PREV/'root/ROOT-final-milestone-v1.json').read_bytes())['full_program_open']})
print(json.dumps({'offer':offerpin,'subject_sha256':subjectsha,'manual_envelope':boundpin,'sources':sources,'actual_directory_created':False,'subject_calls':0}))
