"""Unexecuted complete UTF8v2 physical lexical component qualification.

Only the exact reviewed Root-owned once actual may import/call the subject or
execute fixtures, simulators and independent validators below. Not G1, the old
palette/graph cohort, a full interpreter, proof search or a performance test.
"""
import time
NOW = time.monotonic_ns
ENTRY_NS = NOW()
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import types

VERSION = 'complete-utf8-physical-component-worker-v1'
SOURCE_ROLES = ('worker', 'utf8', 'runner', 'observer')
OUTER_LIMITS = dict(work_seconds=180, overall_seconds=210, memory_bytes=1073741824,
    result_bytes=134217728, expanded_bytes=134217728, stdout_bytes=4194304,
    stderr_bytes=4194304, worker_receipt_bytes=4194304,
    runner_metadata_bytes=8388608, observer_bytes=1048576)
GENERATOR_LIMITS = dict(work=100000, states=317, transitions=1256)
FILE_LIMITS = {'WORKER_CONSUMED.json':1048576,
    'canonical-utf8-calibration.json':50331648, 'result.json':1048576,
    'worker-receipt.json':1048576, 'worker-failure.json':50331648,
    'failure-summary.json':65536}
MODES = ('LEAD','CONT1','CONT2','CONT3','E0_FIRST','F0_FIRST','F4_FIRST')
ALPHABET = ('B','0','1','#')
SITES = ('entry','root-allocation','raw-transition','residual-registry','final-census')
FOREIGN_TYPES = ('RuntimeError','ValueError','StopIteration','ConstructionLimit','DeclarationError')
FORBIDDEN_EVENTS = ('subprocess.Popen','os.system','os.fork','os.posix_spawn','socket.connect','ctypes.dlopen')
ROOT_CALLBACK = object()


class PolicyFailure(RuntimeError):
    pass


class TableInvalid(ValueError):
    pass


def need(value, message):
    if not value:
        raise PolicyFailure(message)


def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode('ascii')


def typed(value, depth=0):
    need(depth<=128,'strict argument depth')
    t=type(value)
    if value is None:return ['none']
    if t is bool:return ['bool',value]
    if t is int:return ['int',value]
    if t is float:return ['float_hex',value.hex()]
    if t is str:return ['str_utf8_surrogatepass_hex',value.encode('utf8','surrogatepass').hex()]
    if t is list:return ['list',[typed(x,depth+1)for x in value]]
    if t is tuple:return ['tuple',[typed(x,depth+1)for x in value]]
    need(t is dict,'exact literal argument carrier')
    return ['dict',[[typed(k,depth+1),typed(v,depth+1)]for k,v in value.items()]]


def descriptor(path, raw):
    return dict(path=str(Path(path).resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


def checked(pin, cap=16777216):
    need(type(pin)is dict and set(pin)=={'path','bytes','sha256'}and type(pin['bytes'])is int
         and 0<=pin['bytes']<=cap,'bounded exact pin')
    path=Path(pin['path'])
    need(path.is_absolute()and path==path.resolve()and path.is_file()and not path.is_symlink(),'canonical regular Source/input')
    raw=path.read_bytes();need(descriptor(path,raw)==pin,'complete raw pin equality')
    return raw


def information(error):
    try:return dict(type=type(error).__name__,message=str(error)[:512])
    except BaseException:return dict(type='UNAVAILABLE',message='unavailable')


def seal(module):
    rows=[];seen=set();pending=[('',vars(module))]
    while pending:
        prefix,values=pending.pop()
        for name,value in sorted(values.items()):
            key=prefix+name
            if type(value)is types.FunctionType and value.__module__==module.__name__:
                closure=value.__closure__;owners=[]
                if closure is not None:
                    for cell in closure:
                        try:owner=id(cell.cell_contents)
                        except ValueError:owner=None
                        owners.append((id(cell),owner))
                rows.append((key,id(value),id(value.__code__),id(value.__defaults__),id(value.__kwdefaults__),id(closure),tuple(owners)))
            elif type(value)is type and value.__module__==module.__name__ and id(value)not in seen:
                seen.add(id(value));rows.append((key,id(value)));owned={}
                for child,item in vars(value).items():
                    if type(item)in(staticmethod,classmethod):item=item.__func__
                    owned[child]=item
                pending.append((key+'.',owned))
    return tuple(sorted(rows))


def callback_seal(value):
    bound=None
    if type(value)is types.MethodType:bound=id(value.__self__);value=value.__func__
    if type(value)is not types.FunctionType:return ('nonfunction',id(type(value)),id(value))
    owners=[]
    for cell in value.__closure__ or ():
        try:owner=id(cell.cell_contents)
        except ValueError:owner=None
        owners.append((id(cell),owner))
    return (bound,id(value),id(value.__code__),id(value.__defaults__),id(value.__kwdefaults__),tuple(owners))


class Session:
    def __init__(self,plan,plan_pin,consumed,actual):
        self.plan=plan;self.plan_pin=plan_pin;self.actual=actual
        self.began=consumed['began_ns'];self.work_deadline=consumed['work_deadline_ns'];self.overall_deadline=consumed['overall_deadline_ns']
        self.root_calls=0;self.first_fault=None;self.stage='INTAKE';self.active=None
        self.started=0;self.completed=0;self.raised=0;self.oracle_calls=0;self.verifier_calls=0
        self.normal=[];self.diagnostics=[];self.calls=[];self.raw_owners=[];self.outputs=[];self.spent=set();self.denied=[]
        self.module=None;self.module_seal=None;self.worker_seal=seal(sys.modules[__name__])
        self.pending_group=None

    def check(self):
        self.root_calls+=1
        try:
            need(self.root_calls<=400000000,'invocation total400m callback ceiling')
            need(NOW()<self.work_deadline,'absolute180 work deadline')
            if self.first_fault is not None:raise self.first_fault
        except BaseException as error:
            if self.first_fault is None:self.first_fault=error
            raise

    def guard(self):
        try:
            self.check()
            for pin in self.plan['sources'].values():checked(pin)
            need(seal(sys.modules[__name__])==self.worker_seal,'worker function/code/default/closure owners')
            if self.module is not None:
                need(self.module.__file__==self.plan['sources']['utf8']['path']and seal(self.module)==self.module_seal,'complete subject function/code/default/closure owners')
            self.check()
        except BaseException as error:
            if self.first_fault is None:self.first_fault=error
            raise

    def load(self):
        self.guard();name='actual_utf8_lexical_component'
        spec=importlib.util.spec_from_file_location(name,self.plan['sources']['utf8']['path'])
        need(spec is not None and spec.loader is not None,'exact source loader')
        module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module)
        self.module=module;self.module_seal=seal(module);self.raw_owners.append(module);self.guard()

    def call(self, label, limits, callback=ROOT_CALLBACK, callback_label='Root'):
        self.guard();before=canonical(typed(limits));self.started+=1
        cb=self.check if callback is ROOT_CALLBACK else callback
        cb_seal=callback_seal(cb)
        owner=dict(id=label,limits=limits,before=before,callback=cb,result=None,error=None)
        self.raw_owners.append(owner)
        active=dict(stage='SUBJECT_CALL',id=label,limits=limits,before_typed=typed(limits),callback=callback_label,result=None,error=None,prefix=None)
        self.active=active
        try:
            value=self.module.describe_utf8_machine(check=cb,limits=limits)
        except BaseException as error:
            owner['error']=error;self.raised+=1
            active['error']=information(error);active['prefix']=getattr(error,'utf8_construction_prefix',None)
            if self.first_fault is not None:raise self.first_fault
            self.guard();need(canonical(typed(limits))==before,'unchanged full declaration after fault')
            need(callback_seal(cb)==cb_seal,'callback function/default/closure owners after fault')
            record=dict(id=label,limits=limits,before_typed=typed(limits),callback=callback_label,complete=False,error=information(error),
                prefix=getattr(error,'utf8_construction_prefix',None))
            self.calls.append(record);self.active=None;raise
        owner['result']=value
        active['result']=value
        if self.first_fault is not None:raise self.first_fault
        self.guard();need(canonical(typed(limits))==before,'unchanged full declaration after success')
        need(callback_seal(cb)==cb_seal,'callback function/default/closure owners after success')
        self.completed+=1;self.calls.append(dict(id=label,limits=limits,before_typed=typed(limits),callback=callback_label,complete=True,result=value))
        self.active=None
        return value

    def write(self,name,value,closure=False):
        need(name in FILE_LIMITS and name not in self.spent,'one declared exclusive file attempt')
        self.spent.add(name);path=self.actual/name;temporary=self.actual/(name+'.partial')
        need(not path.exists()and not temporary.exists(),'no overwrite/retry')
        digest=hashlib.sha256();size=0;parts=0
        fd=os.open(str(temporary),os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
        with os.fdopen(fd,'wb')as output:
            for part in json.JSONEncoder(sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).iterencode(value):
                raw=part.encode('ascii');need(size+len(raw)+1<=FILE_LIMITS[name],'declared file lease')
                output.write(raw);digest.update(raw);size+=len(raw);parts+=1
                if parts%1024==0:
                    if closure:need(NOW()<self.overall_deadline,'absolute210 negative metadata deadline')
                    else:self.check()
            output.write(b'\n');digest.update(b'\n');size+=1;output.flush();os.fsync(output.fileno())
        if closure:need(NOW()<self.overall_deadline,'negative complete close before210')
        else:self.check()
        os.rename(temporary,path)
        if closure:need(NOW()<self.overall_deadline,'negative publication before210')
        else:self.check()
        return dict(path=str(path),bytes=size,sha256=digest.hexdigest())


def table_check(s, table):
    """Independent full literal matrix checker. No subject operations."""
    s.verifier_calls+=1
    def require(ok, why):
        if not ok:raise TableInvalid(why)
    require(type(table)is dict,'table dict')
    require(set(table)=={'schema','version','alphabet','states','delta','undefined','entries','initial','blank','halts','bit_order','bits_per_byte','construction_counts','scope','runtime_qualified','complete_interpreter','mathematical_authority'},'complete exact table fields')
    require(table['schema']=='utf8-residual-physical-machine-v1','table schema')
    states=table['states'];delta=table['delta'];entries=table['entries'];halts=table['halts']
    require(type(states)is list and 10<=len(states)<=100,'Source-derived total state upper bound100')
    name_chars='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789/_-'
    require(all(type(x)is str and len(x)<=64 and all(ch in name_chars for ch in x)for x in states)and len(set(states))==len(states),'distinct bounded ASCII state names')
    require(states[:3]==['DONE','REJECT','BOUND']and type(halts)is dict and halts==dict(DONE=0,REJECT=1,BOUND=2)and all(type(q)is int for q in halts.values()),'exact typed exits')
    require(table['alphabet']==list(ALPHABET)and table['blank']=='B','exact finite alphabet')
    require(type(entries)is dict and set(entries)==set(MODES)and len(set(entries.values()))==7,'seven distinct labeled roots; mapping key order has no machine semantics')
    require(all(type(q)is int and 3<=q<len(states)for q in entries.values()),'literal root ids')
    require(table['initial']==entries['LEAD']and table['bit_order']=='least-significant-bit-first'and table['bits_per_byte']==8,'fixed entry and bit interface')
    require(type(delta)is list and len(delta)==4*(len(states)-3),'complete number of assigned slots')
    lookup={}
    for row in delta:
        s.check();require(type(row)is list and len(row)==5,'literal row shape')
        q,read,target,write,move=row
        require(type(q)is int and 3<=q<len(states)and type(target)is int and 0<=target<len(states),'exact literal state indices')
        require(type(read)is str and read in ALPHABET and write==read and type(write)is str,'literal read and unchanged write')
        require(type(move)is int and move==(1 if read in('0','1')else 0),'literal one-bit scan or stationary exit')
        require((q,read)not in lookup,'no duplicate literal slot');lookup[q,read]=row
    for q in range(3,len(states)):
        s.check()
        for symbol in ALPHABET:require((q,symbol)in lookup,'every assigned state/symbol slot')
        require(lookup[q,'#'][2]==2,'explicit capacity exit')
        expected=0 if q==entries['LEAD']else 1
        require(lookup[q,'B'][2]==expected,'mode-root/interior blank behavior')
    require(table['undefined']==[[q,a]for q in range(3)for a in ALPHABET],'all twelve undefined halt slots')
    counts=table['construction_counts']
    require(type(counts)is dict and set(counts)=={'attempted_work','states','transitions'}and type(counts['attempted_work'])is int and 0<counts['attempted_work']<=100000,'bounded full construction work')
    require(counts['states']==len(states)and counts['transitions']==len(delta),'exact table census')
    require(table['runtime_qualified']is False and table['complete_interpreter']is False and table['mathematical_authority']is False,'no broader authority')
    require(table['version']=='utf8-residual-physical-machine-v1'and table['scope']=='One physical lexical routine; no complete VM or proof checker.','fixed bounded metadata')
    return lookup


def expected_byte(mode, value):
    """Separately authored finite byte/category relation, not subject helper."""
    if mode!='LEAD':
        lower,upper,next_mode={
            'CONT1':(128,191,'LEAD'),'CONT2':(128,191,'CONT1'),'CONT3':(128,191,'CONT2'),
            'E0_FIRST':(160,191,'CONT1'),'F0_FIRST':(144,191,'CONT2'),'F4_FIRST':(128,143,'CONT2')}[mode]
        return next_mode if lower<=value<=upper else 'REJECT'
    groups=((0,127,'LEAD'),(194,223,'CONT1'),(224,224,'E0_FIRST'),(225,239,'CONT2'),
            (240,240,'F0_FIRST'),(241,243,'CONT3'),(244,244,'F4_FIRST'))
    for lower,upper,result in groups:
        if lower<=value<=upper:return result
    return 'REJECT'


def simulate(s, table, lookup, mode, symbols, steps):
    s.verifier_calls+=1;q=table['entries'][mode];head=0;tape=list(symbols);trace=[]
    active=dict(stage='PHYSICAL_SIMULATION',mode=mode,symbols=symbols,steps=steps,state=q,head=head,tape=tape,trace=trace)
    s.active=active
    for unused in range(steps):
        s.check();need(0<=head<len(tape),'complete finite simulated tape input')
        need(q>=3,'no early halt before declared physical step count')
        read=tape[head];row=lookup[q,read]
        before=q;old_head=head;q,write,move=row[2:]
        tape[head]=write;head+=move
        trace.append([before,old_head,read,q,head])
        active['state']=q;active['head']=head
    need(tape==symbols,'every physical transition preserved full tape')
    return dict(state=q,head=head,tape=tape,trace=trace)


def add_normal(s, record, word=False):
    s.active=record
    need(len(canonical(record))<=(4096 if word else 1024),'declared complete per-case byte envelope')
    s.normal.append(record)
    s.active=None


def normals(s,bank,table,lookup):
    for mode in MODES:
        for value in range(256):
            s.check();s.oracle_calls+=1
            bits=[str((value>>i)&1)for i in range(8)];out=expected_byte(mode,value)
            result=simulate(s,table,lookup,mode,bits,8)
            target=1 if out=='REJECT'else table['entries'][out]
            need(result['state']==target and result['head']==8,'independent complete byte successor')
            add_normal(s,dict(group='all-seven-mode-byte-transitions',mode=mode,value=value,expected=out,result=result))
    for group,end,start in (('all-finite-prefix-fences','#',0),('all-byte-boundary-blanks','B',0),('all-mid-byte-blanks','B',1)):
        if group=='all-byte-boundary-blanks':
            for mode in MODES:
                s.check();s.oracle_calls+=1;result=simulate(s,table,lookup,mode,['B'],1)
                need(result['state']==(0 if mode=='LEAD'else 1)and result['head']==0,'all root blanks')
                add_normal(s,dict(group=group,mode=mode,result=result))
            continue
        for mode in MODES:
            for length in range(start,8):
                for prefix in range(1<<length):
                    s.check();s.oracle_calls+=1
                    symbols=[str((prefix>>i)&1)for i in range(length)]+[end]
                    result=simulate(s,table,lookup,mode,symbols,length+1)
                    expected=2 if end=='#'else 1
                    need(result['state']==expected and result['head']==length,'full prefix/blank/fence trajectory')
                    add_normal(s,dict(group=group,mode=mode,length=length,prefix=prefix,expected=expected,result=result))
    for case in bank['normal_groups'][4]['cases']:
        s.check();s.oracle_calls+=1;raw=case['bytes'];mode='LEAD';consumed=0
        for value in raw:
            mode=expected_byte(mode,value);consumed+=8
            if mode=='REJECT':break
        lexical='DONE'if mode=='LEAD'else'REJECT'
        need(lexical==case['expected'],'declared word agrees independent byte relation')
        try:bytes(raw).decode('utf8','surrogatepass');host='DONE'
        except UnicodeDecodeError:host='REJECT'
        need(host==case['expected'],'independent host surrogatepass decoding agrees word control')
        symbols=[str((value>>i)&1)for value in raw for i in range(8)]+['B']
        count=consumed if mode=='REJECT'else consumed+1
        result=simulate(s,table,lookup,'LEAD',symbols,count)
        need(result['state']==(0 if lexical=='DONE'else 1),'complete word terminal')
        add_normal(s,dict(group='complete-word-controls',id=case['id'],bytes=raw,expected=lexical,host=host,result=result),True)


def traceback_site(error):
    tb=error.__traceback__
    while tb.tb_next is not None:tb=tb.tb_next
    return dict(file=tb.tb_frame.f_code.co_filename,function=tb.tb_frame.f_code.co_name,line=tb.tb_lineno)


def make_foreign_callback(s,m,site_name,foreign,trigger):
    """Fresh captured cells for each diagnostic; no late-bound loop owners."""
    def callback():
        s.check();frame=sys._getframe(1).f_back
        need(frame.f_code.co_filename==m.__file__,'subject callback caller Source')
        name=frame.f_code.co_name;local=frame.f_locals
        active=frame
        while active is not None and 'state'not in active.f_locals:active=active.f_back
        need(active is not None,'available generator state frame')
        state=active.f_locals['state'];stage=state['stage']
        fire=((site_name=='entry'and stage=='ENTRY')or
            (site_name=='root-allocation'and stage=='ROOTS'and name=='allocate')or
            (site_name=='raw-transition'and name=='assign'and state['active_choices']is not None)or
            (site_name=='residual-registry'and name=='residual'and 'key'in local)or
            (site_name=='final-census'and stage=='COMPLETE_TABLE'))
        if fire:
            trigger.append(dict(stage=stage,function=name,line=frame.f_lineno,active_state=state['active_state'],active_choices=state['active_choices']))
            raise foreign
    return callback


def generator_diagnostics(s):
    m=s.module;variants=[]
    group=dict(id='exact-declaration-types',variants=variants,complete=False);s.pending_group=group
    invalid=[]
    for key in ('work','states','transitions'):
        for label,value in (('bool',True),('zero',0),('negative',-1),('float',1.0),('string','1'),('none',None),('too-large',400000001)):
            limits=dict(GENERATOR_LIMITS);limits[key]=value;invalid.append((key+'-'+label,limits,None))
        limits=dict(GENERATOR_LIMITS);del limits[key];invalid.append((key+'-missing',limits,None))
    limits=dict(GENERATOR_LIMITS);limits['extra']=1;invalid.append(('extra-key',limits,None))
    for label,value in (('none',None),('list',[]),('bool',True)):
        invalid.append(('limits-'+label,value,None))
    for label,value in (('none',None),('bool',True),('int',0),('dict',{})):
        invalid.append(('check-'+label,dict(GENERATOR_LIMITS),value))
    for label,limits,invalid_check in invalid:
        s.check();callback=s.check if not label.startswith('check-')else invalid_check
        try:s.call('declaration/'+label,limits,callback,'declared invalid callback'if label.startswith('check-')else'Root')
        except m.DeclarationError as error:
            need(s.first_fault is None and traceback_site(error)['file']==m.__file__ and traceback_site(error)['function']=='describe_utf8_machine','exact declaration provenance')
            variants.append(dict(id=label,limits=limits,callback_type=type(callback).__name__,error=information(error),site=traceback_site(error),prefix=getattr(error,'utf8_construction_prefix',None)))
        else:need(False,'invalid declaration was accepted')
    group['complete']=True;s.diagnostics.append(group);s.pending_group=None
    variants=[]
    group=dict(id='construction-work-state-transition-cutoffs',variants=variants,complete=False);s.pending_group=group
    for key in ('work','states','transitions'):
        limits=dict(GENERATOR_LIMITS);limits[key]=1
        try:s.call('quota/'+key,limits)
        except m.ConstructionLimit as error:
            site=traceback_site(error);prefix=getattr(error,'utf8_construction_prefix',None)
            need(s.first_fault is None and site['file']==m.__file__ and site['function']=='step','owned quota Source site; not class alone')
            need(type(prefix)is dict and prefix['complete']is False,'full available quota prefix')
            counter='attempted_work'if key=='work'else key
            need(prefix[counter]==2,'exact first cutoff counter')
            if key=='transitions':need(prefix['active_choices']is not None and len(prefix['active_choices'])==2,'raw produced choices retained before quota')
            variants.append(dict(id=key,limits=limits,error=information(error),site=site,prefix=prefix))
        else:need(False,'quota failed to interrupt')
    group['complete']=True;s.diagnostics.append(group);s.pending_group=None
    variants=[]
    group=dict(id='foreign-callback-identity',variants=variants,complete=False);s.pending_group=group
    for site_name in SITES:
        for error_name in FOREIGN_TYPES:
            cls=getattr(m,error_name)if error_name in('ConstructionLimit','DeclarationError')else{'RuntimeError':RuntimeError,'ValueError':ValueError,'StopIteration':StopIteration}[error_name]
            foreign=cls('planned foreign '+site_name);trigger=[]
            s.raw_owners.extend((foreign,trigger))
            callback=make_foreign_callback(s,m,site_name,foreign,trigger)
            try:s.call('foreign/'+site_name+'/'+error_name,dict(GENERATOR_LIMITS),callback,site_name+'/'+error_name)
            except BaseException as error:
                if s.first_fault is not None:raise s.first_fault
                need(error is foreign and len(trigger)==1,'exact foreign object and planned site')
                prefix=getattr(error,'utf8_construction_prefix',None)
                need(type(prefix)is dict and prefix['complete']is False,'foreign full available prefix')
                if site_name=='raw-transition':need(prefix['active_choices']and len(prefix['active_choices'])==1,'first raw row retained before foreign callback')
                variants.append(dict(id=site_name+'/'+error_name,exact_foreign_identity=True,error=information(error),site=traceback_site(error),trigger=trigger,prefix=prefix,public_class_impostor=error_name in('ConstructionLimit','DeclarationError')))
            else:need(False,'planned foreign site was not reached')
    group['complete']=True;s.diagnostics.append(group);s.pending_group=None


def matrix_diagnostics(s,table):
    variants=[];count=len(table['delta'])
    group=dict(id='complete-table-and-terminal-rows',variants=variants,complete=False);s.pending_group=group
    before=canonical(typed(table))
    for index,row in enumerate(table['delta']):
        recipes=('duplicate','dangling','wrong-move')+ (('missing-fence',)if row[1]=='#'else())
        for recipe in recipes:
            s.check();candidate=dict(table);candidate['delta']=list(table['delta'])
            if recipe=='duplicate':candidate['delta'].append(list(row))
            elif recipe=='missing-fence':del candidate['delta'][index]
            else:
                changed=list(row);changed[2 if recipe=='dangling'else 4]=len(table['states'])if recipe=='dangling'else 2
                candidate['delta'][index]=changed
            s.raw_owners.append(candidate)
            s.active=dict(stage='MATRIX_VALIDATION',row_index=index,recipe=recipe,input=candidate)
            try:table_check(s,candidate)
            except TableInvalid as error:
                need(s.first_fault is None,'real Root failure dominates matrix diagnostic')
                record=dict(id=str(index)+'/'+recipe,row_index=index,recipe=recipe,input=candidate,rejected=True,error=information(error),site=traceback_site(error))
                need(len(canonical(record))<=24576,'complete literal mutation fixture byte bound24KiB')
                variants.append(record)
                s.active=None
            else:need(False,'malformed literal matrix accepted')
    need(len(variants)==3*count+len(table['states'])-3,'every row mutation and every fence row')
    need(canonical(typed(table))==before,'complete original matrix unchanged by every diagnostic')
    group['complete']=True;s.diagnostics.append(group);s.pending_group=None


def qualify(s,bank):
    s.stage='FIRST_COMPLETE_TABLE';table=s.call('first-fresh-construction',dict(GENERATOR_LIMITS));lookup=table_check(s,table)
    s.stage='ALL_DECLARED_NORMALS';normals(s,bank,table,lookup)
    counts={g['id']:sum(r['group']==g['id']for r in s.normal)for g in bank['normal_groups']}
    need(list(counts.values())==[1792,1785,7,1778,16]and len(s.normal)==5378,'entire unchanged UTF8v2 normal population')
    s.stage='GENERATOR_DIAGNOSTICS';generator_diagnostics(s)
    s.stage='COMPLETE_MATRIX_DIAGNOSTICS';matrix_diagnostics(s,table)
    s.stage='SECOND_FRESH_TABLE';second=s.call('second-fresh-construction',dict(GENERATOR_LIMITS));table_check(s,second)
    need(canonical(typed(table))==canonical(typed(second))and table is not second and table['delta']is not second['delta'],'two full fresh fixed tables identical')
    s.diagnostics.append(dict(id='fixed-machine-identity',first=table,second=second,strict_equal=True,fresh_owners=True,complete=True))
    need([g['id']for g in s.diagnostics]==[g['id']for g in bank['diagnostic_groups']],'all five original diagnostic groups')
    s.guard()
    return dict(schema='complete-utf8-lexical-packet-v1',status='COMPLETE_COMPONENT_CALIBRATION_CANDIDATE',bank=bank,
        table=table,normal=s.normal,normal_counts=counts,diagnostics=s.diagnostics,calls=s.calls,
        root_callbacks=s.root_calls,started=s.started,completed=s.completed,raised=s.raised,
        oracle_calls=s.oracle_calls,verifier_calls=s.verifier_calls,raw_owners_retained=True,
        scope='Complete declared UTF8v2 lexical component only; old stuck events completed as REJECT. No G1, old palette/graph cohort, full VM, BOOT, proof search or speed claim.',
        complete_physical_VM=False,proof_discovery=False,G1_adopted=False,mathematical_authority=False)


def main(plan_path):
    raw=Path(plan_path).read_bytes();need(len(raw)<=16777216,'bounded exact plan');plan=json.loads(raw);plan_pin=descriptor(plan_path,raw)
    need(plan['schema']=='ROOT-wang-encoding-qualification-plan-v1'and set(plan['sources'])==set(SOURCE_ROLES)and plan['limits']==OUTER_LIMITS,'complete distinct lexical subject and original caps')
    actual=Path(plan['actual_directory']);consumed=json.loads((actual/'CONSUMED.json').read_bytes())
    need(consumed['plan']==plan_pin and consumed['invocation_id']==plan['invocation_id']and consumed['maximum_worker_launches']==1 and consumed['consumed_before_Popen']is True,'same fresh consumed once marker')
    need(consumed['work_deadline_ns']==consumed['began_ns']+180000000000 and consumed['overall_deadline_ns']==consumed['began_ns']+210000000000,'same runner Source entry epoch')
    s=Session(plan,plan_pin,consumed,actual)
    try:
        s.guard();checked(plan['python'],67108864)
        need(descriptor(__file__,Path(__file__).read_bytes())==plan['sources']['worker'],'exact current worker')
        declaration=json.loads(checked(plan['declaration']));closure=json.loads(checked(plan['runtime_closure']))
        need(declaration['experiment_kind']=='COMPLETE_UTF8V2_PHYSICAL_LEXICAL_COMPONENT'and declaration['limits']==OUTER_LIMITS and declaration['generator_limits']==GENERATOR_LIMITS and declaration['file_limits']==FILE_LIMITS,'exact full lexical declaration')
        need(plan['inputs']==declaration['inputs']and len(plan['inputs'])==1 and closure['python']==plan['python']and closure['sources']==plan['sources']and closure['declaration']==plan['declaration'],'whole input and runtime closure')
        for pin in closure['stdlib_files']:checked(pin)
        subject={k:v for k,v in plan.items()if k!='authorization'};auth=json.loads(checked(plan['authorization']))
        need(auth['author_identity']=='/root'and auth['actual_execution_authorized']is True and type(auth['maximum_actual_invocations'])is int and auth['maximum_actual_invocations']==1 and auth['subject_sha256']==hashlib.sha256(canonical(subject)).hexdigest(),'fresh exact Root-only grant')
        bank=json.loads(checked(plan['inputs'][0]['pin']))
        need(bank['schema']=='utf8-residual-prospective-bank-v2'and [g['id']for g in bank['normal_groups']]==declaration['normal_group_ids']and [g['id']for g in bank['diagnostic_groups']]==declaration['diagnostic_ids'],'entire original lexical bank')
        s.write('WORKER_CONSUMED.json',dict(plan=plan_pin,pid=os.getpid(),ppid=os.getppid(),worker_entry_ns=ENTRY_NS,maximum_invocations=1))
        def audit(event,args):
            if event in FORBIDDEN_EVENTS:
                s.denied.append(event)
                if s.first_fault is None:s.first_fault=PolicyFailure('forbidden runtime event')
                raise s.first_fault
        sys.addaudithook(audit);s.load();packet=qualify(s,bank);s.stage='FULL_PACKET_WRITE';s.active=None
        output=s.write('canonical-utf8-calibration.json',packet);s.outputs.append(output)
        q=dict(schema='utf8-lexical-component-candidate-v1',status='COMPLETE_COMPONENT_CALIBRATION_CANDIDATE',outputs=s.outputs,
            normal_group_ids=declaration['normal_group_ids'],normal_counts=packet['normal_counts'],normal_case_count=len(s.normal),
            diagnostic_ids=[g['id']for g in s.diagnostics],diagnostics=[dict(id=g['id'],complete=g['complete'],variants=len(g.get('variants',[])))for g in s.diagnostics],
            states=len(packet['table']['states']),transitions=len(packet['table']['delta']),undefined=len(packet['table']['undefined']),
            compiler_calls=s.started,compiler_completed=s.completed,compiler_raised=s.raised,search_calls=0,
            verifier_calls=s.verifier_calls,oracle_calls=s.oracle_calls,root_check_calls=s.root_calls,
            complete_physical_VM=False,proof_discovery=False,G1_adopted=False,gcts_rl_advantage_established=False,
            full_pipeline_qualified=False,mathematical_proof_accepted=False)
        zeros=dict(Native_calls=0,Model_calls=0,inverse_calls=0,Reader_calls=0,FOL_kernel_calls=0,opaque_program_decodes=0)
        counts={k:q[k]for k in('compiler_calls','search_calls','verifier_calls','oracle_calls')}
        payload=dict(schema='wang-encoding-qualification-result-v1',invocation_id=plan['invocation_id'],plan=plan_pin,
            declaration=plan['declaration'],runtime_closure=plan['runtime_closure'],qualification=q,outputs=s.outputs,denied_events=s.denied,
            canonical_logical_bytes=output['bytes'],expanded_canonical_packet_bytes=output['bytes'],
            expanded_scope='Complete ordinary JSON; every saved literal matrix mutation and trace is fully present, no G1/reference expansion.',
            full_pipeline_qualified=False,scientific_acceptance=False,mathematical_proof_accepted=False,**counts,**zeros)
        s.stage='RESULT_WRITE';result=s.write('result.json',payload);s.guard()
        for pin in closure['stdlib_files']:checked(pin)
        for item in plan['inputs']:checked(item['pin'])
        logical=output['bytes']+result['bytes'];need(logical<=134217728,'complete stored and expanded ordinary JSON')
        header=dict(schema='wang-encoding-qualification-worker-receipt-v1',version=VERSION,invocation_id=plan['invocation_id'],plan=plan_pin,
            began_ns=s.began,work_deadline_ns=s.work_deadline,overall_deadline_ns=s.overall_deadline,pid=os.getpid(),ppid=os.getppid(),worker_entry_ns=ENTRY_NS,
            result=result,outputs=s.outputs,logical_result_bytes=logical,expanded_logical_result_bytes=logical,outer_metadata_reservation=9437184,
            finite_encoding_candidate=True,full_pipeline_qualified=False,scientific_acceptance=False,mathematical_proof_accepted=False,
            root_check_calls=s.root_calls,positive_worker_completed_ns=NOW(),**zeros)
        s.stage='HEADER_WRITE';s.write('worker-receipt.json',header)
        need(sum(f.stat().st_size for f in actual.iterdir()if f.is_file())+9437184<=134217728,'whole physical cap including outer9MiB')
        s.check();return 0
    except BaseException as error:
        primary=s.first_fault if s.first_fault is not None else error;s.raw_owners.extend((error,primary))
        active_metadata={k:str(s.active[k])[:160]for k in('stage','id','group','recipe')if type(s.active)is dict and k in s.active}
        summary=dict(schema='utf8-lexical-negative-summary-v1',stage=s.stage,active_metadata=active_metadata,error=information(primary),root_callbacks=s.root_calls,
            completed_normals=len(s.normal),completed_diagnostic_ids=[g['id']for g in s.diagnostics],started=s.started,completed=s.completed,raised=s.raised,
            admitted=False,mathematical_authority=False)
        try:s.write('failure-summary.json',summary,True)
        except BaseException as secondary:s.raw_owners.append(secondary)
        failure=dict(schema='utf8-lexical-worker-failure-v1',summary=summary,active=s.active,pending_group=s.pending_group,normal=s.normal,diagnostics=s.diagnostics,calls=s.calls,
            outputs=s.outputs,denied_events=s.denied,available_prefix=True,complete=False,admitted=False,mathematical_authority=False)
        try:s.write('worker-failure.json',failure,True)
        except BaseException as secondary:s.raw_owners.append(secondary)
        return 2


if __name__=='__main__':
    need(len(sys.argv)==2,'one reviewed once-plan path');raise SystemExit(main(sys.argv[1]))
