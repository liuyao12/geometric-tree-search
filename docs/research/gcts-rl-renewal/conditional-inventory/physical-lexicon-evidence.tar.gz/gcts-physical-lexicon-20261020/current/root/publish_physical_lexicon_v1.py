"""Publication-only projection of complete saved evidence; never run subjects."""
from pathlib import Path
import gzip,hashlib,io,json,tarfile

BASE=Path(__file__).resolve().parents[3]
NEW=BASE/'research-runs/gcts-complete-evidence-20261020'
R=NEW/'root'
PREV=BASE/'research-runs/gcts-evidence-next-20261020'
OLD=BASE/'research-runs/gcts-batch-20261020'
P=OLD/'publisher'
DEST=P/'docs/research/gcts-rl-renewal/conditional-inventory'
def pin(p):
    raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def load(p):
    assert p.suffix=='.json' and not p.name.endswith('.partial')
    return json.loads(p.read_bytes())
def rawjson(x):return (json.dumps(x,sort_keys=True,indent=2,ensure_ascii=True,allow_nan=False)+'\n').encode()
def write_new(p,raw):
    if p.exists():assert p.read_bytes()==raw,str(p)
    else:p.write_bytes(raw)

review_path=NEW/'review-C/typed-UTF8-complete-saved-result-review-v1.json'
review=load(review_path);assert review['review_passed']is True and review['failed_checks']==[]
admission=load(R/'ROOT-utf8-component-admission-v1.json')
assert admission['finite_lexical_component_qualified']is True and admission['remaining_actual_invocations']==0
a=R/'actual-utf8-v1';packet_path=a/'canonical-utf8-calibration.json';packet=load(packet_path)
result=load(a/'result.json');runner=load(a/'runner-receipt.json');terminal=load(R/'utf8-plan-authorized-v1-terminal-observation/terminal.json')
assert terminal['terminal_gate_passed'] is True
assert pin(packet_path)==result['outputs'][0]
words=[row for row in packet['normal']if row['group']=='complete-word-controls']
assert len(words)==16
write_new(DEST/'physical-lexicon-data.json',rawjson(dict(schema='physical-lexicon-saved-display-v1',source=pin(packet_path),scope='Passive display subset: all16wordcontrols and full literal table; complete5378normals and diagnostics in archive. No simulation.',table=packet['table'],words=words)))

copies={
 'physical-lexicon-review.json':review_path,
 'physical-lexicon-source-review.json':NEW/'review-C/typed-UTF8-component-Source-prospective-review-v1.json',
 'physical-lexicon-codec-review.json':NEW/'review-C/typed-strict-value-dag-Source-review-v1.json',
 'physical-lexicon-structure-review.json':NEW/'review-C/typed-boot-postfix-structure-Source-review-v1.json',
 'physical-lexicon-obligations.json':NEW/'review-C/independent-G1-obligations-v1.json',
}
for name,source in copies.items():write_new(DEST/name,source.read_bytes())
summary=dict(schema='parallel-physical-lexicon-milestone-v1',status='PROGRESS',goal_status='active',
    finite_lexical_component_qualified=True,subject_sha256=runner['subject_sha256'],
    qualification=result['qualification'],resources=dict(logical_bytes=runner['logical_result_bytes'],expanded_bytes=runner['expanded_logical_result_bytes'],pre_runner_receipt_conservative_physical_bytes=runner['conservative_physical_bytes'],post_receipt_actual_directory_plus_same_reserve_bytes=sum(p.stat().st_size for p in a.iterdir()if p.is_file())+9437184,worker_peak_bytes=runner['worker_peak_bytes'],terminal_runner_clock_seconds=terminal['runner_clock_elapsed_seconds'],limits=runner['limits']),
    result=pin(a/'result.json'),canonical=pin(packet_path),runner=pin(a/'runner-receipt.json'),
    terminal=pin(R/'utf8-plan-authorized-v1-terminal-observation/terminal.json'),admission=pin(R/'ROOT-utf8-component-admission-v1.json'),
    passive_review=pin(review_path),codec=dict(source_only=True,unrun_cases=101),
    structural_reader=dict(source_only=True,unrun_exhaustive_families=8,unrun_literal_controls=13,unrun_construction_diagnostics=24),
    G1_adopted=False,old_G0_negative_unchanged=True,complete_VM=False,new_theorem=False,proof_search_advantage=False,RL_training=False,
    remaining_actual_invocations=0,partial_files_produced=False)
write_new(DEST/'physical-lexicon-summary.json',rawjson(summary))
write_new(DEST/'physical-lexicon.html',(R/'physical-lexicon-template.html').read_bytes())

card=r'''<section id="physical-lexicon-update"><p class="eyebrow">20 OCTOBER 2026 · PARALLEL RESEARCH AND FINITE PHYSICAL QUALIFICATION</p><h2>A lexical machine passes its complete finite bank.</h2><p>One fresh run completed all \(5\,378\) normal cases and five diagnostic groups, emitting \(85\) states and \(328\) literal transitions within the original limits. The saved reader translates actual physical steps into words. Separate agents delivered an independently reviewed codec and structural reader; both remain unrun. No new theorem or GCTS+RL advantage follows. <a href="physical-lexicon.html#outcome"><b>Read the result</b></a> · <a href="physical-lexicon.html#reader">Inspect saved steps</a> · <a href="physical-lexicon.html#parallel">Agent contributions</a>.</p></section>'''
reader=DEST/'reader.html';preimage=R/'reader-before-physical-lexicon.html'
if not preimage.exists():
    assert 'physical-lexicon-update'not in reader.read_text()
    preimage.write_bytes(reader.read_bytes())
text=preimage.read_text();assert text.count('<section id="finalization-observation">')==1
changed=text.replace('<section id="finalization-observation">',card+'\n<section id="finalization-observation">',1)
if reader.read_bytes()!=preimage.read_bytes():assert reader.read_text()==changed
else:reader.write_text(changed)

members={}
for folder in ('schema-B','physical-L','review-C'):
    for path in sorted((NEW/folder).iterdir()):
        if path.is_file()and path.suffix in('.json','.py'):
            members['current/'+str(path.relative_to(NEW))]=path
root_names=[
 'ROOT-continuation-assessment-v1.json','assemble_utf8_controls_v1.py','author_utf8_offer_v1.py',
 'qualify_utf8_worker_v1.py','run_utf8_once_v1.py','observe_utf8_once_v1.py','prepare_utf8_once_grant_v1.py',
 'utf8-Source-offer-v1.json','utf8-declaration-v1.json','utf8-runtime-closure-v1.json','utf8-manual-envelope-v1.json',
 'utf8-controls-static-assembly-v1.json','utf8-plan-prospective-v1.json','utf8-authorization-prospective-false-v1.json',
 'barrier-before-utf8-grant-v1.json','ROOT-utf8-final-prelaunch-barrier-v1.json',
 'utf8-authorization-once-v1.json','utf8-plan-authorized-v1.json','ROOT-utf8-grant-issuance-v1.json',
 'ROOT-utf8-grant-retirement-v1.json','ROOT-utf8-component-admission-v1.json',
 'reader-before-physical-lexicon.html','physical-lexicon-template.html','publish_physical_lexicon_v1.py']
for name in root_names:members['current/root/'+name]=R/name
for folder in ('actual-utf8-v1','utf8-plan-authorized-v1-terminal-observation'):
    for path in sorted((R/folder).iterdir()):
        assert not path.name.endswith('.partial'),'No partial expected; never parse one'
        assert path.is_file() and not path.is_symlink()
        members['current/root/'+folder+'/'+path.name]=path
provenance=[
 PREV/'root/utf8_residual_machine_v1.py',PREV/'root/utf8-prospective-bank-v2.json',PREV/'root/utf8-residual-contract-v2.json',
 PREV/'recovered-checker/PhysicalFoundation/fixed_vm_physical_foundation_v1.py',
 PREV/'recovered-checker/CodecV2/fixed_vm_codec_v2.py',
 PREV/'bounds-B/one-owner-field-map-v1.json',PREV/'review-C/typed-expanded-lower-bound-review-v1.json',
 OLD/'root/run_batch_once_v1.py',OLD/'root/observe_batch_once_v1.py',OLD/'root/qualify_complete_batch_worker_v2.py',
 OLD/'root/ROOT-grant-retirement-v2.json',P/'docs/basic-tiling-algorithm.md',DEST/'evidence-limits-source.tar.gz']
for path in provenance:members['provenance/'+str(path.relative_to(BASE))]=path

readme='''# Parallel physical lexical research milestone\n\nThe current UTF8v2 bank was executed exactly once and qualified as a standalone lexical component. Complete ordinary JSON retains all5378normal cases, all five diagnostic groups, full malformed tables and complete word traces. The Root once grant is retired0. No partial files were produced.\n\nThe strict value DAG codec and physical postfix structural routine are Source-only and unexecuted. Their declarative banks have NOT passed runtime tests. Independent static reviews do not change that status. G1 is unadopted; the old G0 negative is unchanged. Historical Sources and the nested prior milestone archive retain their own recorded statuses; they are not new invocations. No fullBOOT, fullVM, theorem discovery, RL training or GCTS/RL advantage is established.\n\nThe browser display is a passive subset of sixteen saved word controls plus the full literal table. It does not execute the machine. Original absolute-path pins identify the research workspace; archive-relative mappings below preserve the exact bytes. Interpreter and stdlib are pinned, not bundled.\n'''.encode()
archive_manifest=dict(schema='physical-lexicon-archive-raw-manifest-v1',partial_content_included=False,files=[dict(archive_path=name,**pin(path))for name,path in sorted(members.items())])
buf=io.BytesIO()
with gzip.GzipFile(fileobj=buf,mode='wb',mtime=0)as zipped:
    with tarfile.open(fileobj=zipped,mode='w')as tar:
        for name,raw in [('README.md',readme),('MANIFEST.json',rawjson(archive_manifest))]+[(name,path.read_bytes())for name,path in sorted(members.items())]:
            info=tarfile.TarInfo('gcts-physical-lexicon-20261020/'+name);info.size=len(raw);info.mode=0o644;info.mtime=0
            tar.addfile(info,io.BytesIO(raw))
archive=DEST/'physical-lexicon-evidence.tar.gz';write_new(archive,buf.getvalue())
assets=[p for p in sorted(DEST.glob('physical-lexicon*'))if p.name not in ('physical-lexicon-manifest.json','physical-lexicon-publication-review.json')]
manifest=dict(schema='physical-lexicon-publication-manifest-v1',goal_status='active',status='PROGRESS',new_invocations=1,remaining_invocations=0,
    subject_sha256=runner['subject_sha256'],files=[dict(file=p.name,**pin(p))for p in assets],reader=dict(pin=pin(reader),preimage=pin(preimage),exact_added_section=card),
    archive_member_count=len(members)+2,archive_members=archive_manifest['files'],
    review_not_self_hashed='Publication review and manifest are excluded from the asset self-hash closure; review binds exact manifest bytes.')
write_new(DEST/'physical-lexicon-manifest.json',rawjson(manifest))
print(json.dumps(dict(assets=[p.name for p in assets],archive=pin(archive),manifest=pin(DEST/'physical-lexicon-manifest.json'),reader=pin(reader)),indent=2))
