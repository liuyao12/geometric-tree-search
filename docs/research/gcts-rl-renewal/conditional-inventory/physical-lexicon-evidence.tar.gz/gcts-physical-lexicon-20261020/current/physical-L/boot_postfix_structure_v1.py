"""Source-only fixed literal one-tape BOOT postfix lexical/depth routine.

This is not full BOOT, a value decoder, cons constructor, VM or proof checker.
Only the finite generator below may expand control; no generator was called.
Each generated action is exactly [read_symbol, next_state, write_symbol, move].
The tape carries the changing unary stack depth; no host stack runs a word.
"""
VERSION = 'boot-postfix-physical-structure-v1'
RAW = ('B', '^', '0', '1', ':', ',', ';', '|', '!', '#')
MARKED = ('@B', '@^', '@0', '@1', '@:', '@,', '@;', '@|', '@!', '@#')
ALPHABET = ('L', 'R', 'h:I', 'h:S') + RAW + MARKED
HALTS = ('DONE', 'REJECT', 'BOUND')
_OWNER = object()
LIMIT_KEYS = ('work', 'states', 'transitions')
SOURCE_ASSIGNED_STATE_UPPER = 149
SOURCE_ALL_STATE_UPPER = 152
SOURCE_TRANSITION_UPPER = 3576


class DeclarationError(Exception):
    def __init__(self, reason, *, owner=None):
        self.reason = reason; self.owner = owner
        super().__init__(reason)


class ConstructionLimit(Exception):
    def __init__(self, reason, attempted_work, *, owner=None):
        self.reason = reason; self.attempted_work = attempted_work; self.owner = owner
        super().__init__(reason)


def is_own_declaration(error):
    return type(error) is DeclarationError and error.owner is _OWNER


def is_own_limit(error):
    return type(error) is ConstructionLimit and error.owner is _OWNER


def describe_boot_postfix_machine(*, check, limits):
    """Generate one complete fixed table, two entries; no tape/data/bound arg.

    Every state has all24 literal physical read actions; only three halt states
    have undefined slots. Resource failures never become input REJECT/BOUND.
    Raw produced active actions are retained before a construction callback.
    """
    rows = [None, None, None]
    names = list(HALTS)
    state = dict(schema='boot-postfix-construction-prefix-v1', complete=False,
        authority=False, attempted_work=0, states=0, transitions=0,
        rows=rows, names=names, entries={}, active_state=None,
        active_choices=None, stage='DECLARATION', limits=None)
    try:
        if not callable(check) or type(limits) is not dict or len(limits) != 3:
            raise DeclarationError('explicit callback and exact limits required', owner=_OWNER)
        for key in limits:
            if type(key) is not str or key not in LIMIT_KEYS:
                raise DeclarationError('exact limit keys required', owner=_OWNER)
        owned = {}
        for key in LIMIT_KEYS:
            value = limits[key]
            if type(value) is not int or not 0 < value <= 400000000:
                raise DeclarationError('positive exact bounded integer limits required', owner=_OWNER)
            owned[key] = value
        state['limits'] = owned

        def step(kind):
            state['attempted_work'] += 1
            if state['attempted_work'] > owned['work']:
                raise ConstructionLimit('work', state['attempted_work'], owner=_OWNER)
            if kind != 'work':
                state[kind] += 1
                if state[kind] > owned[kind]:
                    raise ConstructionLimit(kind, state['attempted_work'], owner=_OWNER)
            check()

        def allocate(name):
            q = len(rows)
            rows.append(None); names.append(name)
            step('states')
            return q

        def assign(q, choices):
            if rows[q] is not None:
                raise DeclarationError('internal duplicate state assignment', owner=_OWNER)
            actions = []
            state['active_state'] = q; state['active_choices'] = actions
            for symbol in ALPHABET:
                step('work')
                target, write, move = choices.get(symbol, (2 if symbol == 'R' else 1, symbol, 0))
                if (type(target) is not int or target < 0 or write not in ALPHABET or
                        type(move) is not int or move not in (-1, 0, 1)):
                    raise DeclarationError('internal nonliteral physical action', owner=_OWNER)
                actions.append([symbol, target, write, move])
                step('transitions')
            rows[q] = actions
            state['active_state'] = None; state['active_choices'] = None

        step('work')
        for unused in HALTS:
            step('states')
        for roots in (2, 3):
            state['stage'] = 'FIXED_ROOT_MODE_' + str(roots)
            prefix = 'roots' + str(roots) + '/'
            token = allocate(prefix + 'token')
            padding = allocate(prefix + 'padding')
            push = allocate(prefix + 'push-scan')
            pop_first = allocate(prefix + 'pop-first')
            pop_scan = allocate(prefix + 'pop-scan')
            pop_erase = allocate(prefix + 'pop-erase')
            pop_check = allocate(prefix + 'pop-check-second')
            depth = []
            for j in range(roots + 1):
                depth.append(allocate(prefix + 'exact-root-count/' + str(j)))
            atom = {}
            for j in range(9):
                for nonzero in (False, True):
                    atom[j, nonzero] = allocate(prefix + 'atom-bit/' + str(j) + '/' + str(int(nonzero)))
            markers = {}

            def mark_then(out):
                # Fixed-control destinations only; never an input-derived index.
                step('work')
                if out in markers:
                    return markers[out]
                q = allocate(prefix + 'mark-input/' + str(out))
                choices = {}
                for symbol in RAW:
                    choices[symbol] = (out, '@' + symbol, 0)
                assign(q, choices)
                markers[out] = q
                return q

            def to_stack(out, label):
                rewind = allocate(prefix + label + '/rewind-L')
                seek = allocate(prefix + label + '/seek-stack-header')
                left = allocate(prefix + label + '/expect-stack-left')
                choices = {}
                for symbol in ALPHABET:
                    choices[symbol] = (seek, symbol, 1) if symbol == 'L' else (2, symbol, 0) if symbol == 'R' else (rewind, symbol, -1)
                assign(rewind, choices)
                choices = {}
                for symbol in ALPHABET:
                    choices[symbol] = (left, symbol, 1) if symbol == 'h:S' else (2, symbol, 0) if symbol == 'R' else (seek, symbol, 1)
                assign(seek, choices)
                assign(left, {'^': (out, '^', 1)})
                return rewind

            def to_input(out, label, initial=False):
                rewind = allocate(prefix + label + '/rewind-L')
                seek = allocate(prefix + label + '/seek-input-header')
                left = allocate(prefix + label + '/expect-input-left')
                find = allocate(prefix + label + ('/initial-mark' if initial else '/find-input-cursor'))
                choices = {}
                for symbol in ALPHABET:
                    choices[symbol] = (seek, symbol, 1) if symbol == 'L' else (2, symbol, 0) if symbol == 'R' else (rewind, symbol, -1)
                assign(rewind, choices)
                choices = {}
                for symbol in ALPHABET:
                    choices[symbol] = (left, symbol, 1) if symbol == 'h:I' else (2, symbol, 0) if symbol == 'R' else (seek, symbol, 1)
                assign(seek, choices)
                assign(left, {'^': (find, '^', 1)})
                choices = {}
                if initial:
                    for symbol in RAW:
                        choices[symbol] = (out, '@' + symbol, 0)
                else:
                    for symbol in RAW:
                        choices[symbol] = (2, symbol, 0) if symbol == '#' else (find, symbol, 1)
                    for symbol in MARKED:
                        choices[symbol] = (out, symbol, 0)
                assign(find, choices)
                return rewind

            return_token = to_input(token, 'return-token')
            return_padding = to_input(padding, 'return-padding')
            go_push = to_stack(push, 'go-push')
            go_pop = to_stack(pop_first, 'go-pop')
            go_roots = to_stack(depth[0], 'go-exact-roots')
            clear = allocate(prefix + 'initialize-clear-unary-stack')
            return_initial = to_input(token, 'return-initial', initial=True)
            entry = to_stack(clear, 'initialize-stack')
            state['entries']['FREE2' if roots == 2 else 'PUBLIC3'] = entry
            assign(clear, {'B': (clear, 'B', 1), '1': (clear, 'B', 1),
                           '#': (return_initial, '#', 0)})
            assign(token, {'@0': (mark_then(atom[0, False]), '0', 1),
                           '@1': (mark_then(go_pop), '1', 1),
                           '@;': (mark_then(go_roots), ';', 1),
                           '@#': (2, '@#', 0)})
            assign(padding, {'@B': (mark_then(padding), 'B', 1),
                             '@:': (0, ':', 0), '@#': (2, '@#', 0)})
            for j in range(9):
                for nonzero in (False, True):
                    choices = {'@#': (2, '@#', 0)}
                    for bit in (0, 1):
                        symbol = '1' if bit else '0'
                        if j < 8:
                            out = mark_then(atom[j + 1, nonzero or bool(bit)])
                        elif bit == 0 or not nonzero:
                            # Ninth bit0 covers0..255; ninth bit1 is256 only
                            # when all eight low bits were0. No host atom read.
                            out = mark_then(go_push)
                        else:
                            choices['@' + symbol] = (1, '@' + symbol, 0)
                            continue
                        choices['@' + symbol] = (out, symbol, 1)
                    assign(atom[j, nonzero], choices)
            assign(push, {'1': (push, '1', 1), 'B': (return_token, '1', 0),
                          '#': (2, '#', 0)})
            assign(pop_first, {'1': (pop_scan, '1', 1),
                               'B': (1, 'B', 0), '#': (1, '#', 0)})
            assign(pop_scan, {'1': (pop_scan, '1', 1),
                              'B': (pop_erase, 'B', -1),
                              '#': (pop_erase, '#', -1)})
            assign(pop_erase, {'1': (pop_check, 'B', -1)})
            assign(pop_check, {'1': (return_token, '1', 0), '^': (1, '^', 0)})
            for j in range(roots):
                assign(depth[j], {'1': (depth[j + 1], '1', 1),
                                  'B': (1, 'B', 0), '#': (1, '#', 0)})
            assign(depth[roots], {'B': (return_padding, 'B', 0),
                                  '#': (return_padding, '#', 0),
                                  '1': (1, '1', 0)})
        state['stage'] = 'COMPLETE_LITERAL_TABLE'
        delta = []; undefined = []
        for q, actions in enumerate(rows):
            step('work')
            if q < 3:
                for symbol in ALPHABET:
                    undefined.append([q, symbol]); step('work')
            else:
                if type(actions) is not list or len(actions) != 24:
                    raise DeclarationError('incomplete physical state', owner=_OWNER)
                for read, out, write, move in actions:
                    step('work')
                    if not 0 <= out < len(rows):
                        raise DeclarationError('dangling physical control target', owner=_OWNER)
                    delta.append([q, read, out, write, move])
        if len(rows) > SOURCE_ALL_STATE_UPPER or len(delta) > SOURCE_TRANSITION_UPPER:
            raise DeclarationError('manual finite Source upper bound contradicted', owner=_OWNER)
        step('work')
        state['stage'] = 'CLOSED'; state['complete'] = True
        return dict(schema='boot-postfix-physical-structure-v1', version=VERSION,
            alphabet=list(ALPHABET), states=names, rows=rows, delta=delta,
            undefined=undefined, entries=dict(state['entries']),
            halts=dict(DONE=0, REJECT=1, BOUND=2), blank='B',
            construction_counts=dict(attempted_work=state['attempted_work'],
                states=state['states'], transitions=state['transitions']),
            routine_scope='Postfix lexical grammar and unary stack depth only.',
            runtime_qualified=False, full_BOOT=False, full_VM=False,
            full_value_construction=False, mathematical_authority=False,
            physical_to_host_equivalence_established=False)
    except BaseException as error:
        try:
            error.boot_postfix_construction_prefix = state
        except BaseException:
            pass
        raise
