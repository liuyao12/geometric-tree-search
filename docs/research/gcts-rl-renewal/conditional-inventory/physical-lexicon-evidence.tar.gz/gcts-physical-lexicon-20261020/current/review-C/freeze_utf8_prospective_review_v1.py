"""Exact Source/AST/passive metadata audit only. No offered function runs."""
import ast
import hashlib
import json
from pathlib import Path

BASE=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs')
N=BASE/'gcts-complete-evidence-20261020';R=N/'root';O=N/'review-C';OLD=BASE/'gcts-batch-20261020'
checks=[]
def check(label,value):
 assert value,label
 checks.append(dict(id=label,passed=True))
def pin(path):
 raw=path.read_bytes();return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def load(path):return json.loads(path.read_text())
def raw_hash(value):return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode('ascii')).hexdigest()
def verify_pin(p,label):
 path=Path(p['path'])
 check(label+'-canonical-regular',path.is_absolute() and path.resolve()==path and path.is_file() and not path.is_symlink() and not path.name.endswith('.partial'))
 check(label+'-complete-pin',pin(path)==p)

offer_path=R/'utf8-Source-offer-v1.json';offer=load(offer_path)
check('exact-offer-pin',(pin(offer_path)['sha256'],pin(offer_path)['bytes'])==('561afd3a96586cc15b1ab28e775ac840a4168e6949e646bc5cd464f728aa55e0',4229))
subject=offer['subject']
check('exact-subject-sha',raw_hash(subject)==offer['subject_sha256']=='d57adc6054cd43ed4623029655578709c6657e2e2705b3a8418dacd1d96d5712')
verify_pin(offer['plan'],'prospective-plan')
plan=load(Path(offer['plan']['path']))
check('subject-plan-total-join',{k:v for k,v in plan.items() if k!='authorization'}==subject)
verify_pin(plan['authorization'],'false-authorization')
auth=load(Path(plan['authorization']['path']))
check('no-actual-authority',auth['actual_execution_authorized'] is False and type(auth['maximum_actual_invocations']) is int and auth['maximum_actual_invocations']==0 and auth['review'] is None and offer['actual_execution_authorized'] is False and offer['new_grants']==0)
verify_pin(subject['python'],'pinned-python')
trees={}
for role,p in subject['sources'].items():
 verify_pin(p,'Source-'+role)
 tree=ast.parse(Path(p['path']).read_bytes(),filename=p['path']);trees[role]=tree
 unused=compile(tree,p['path'],'exec');del unused
check('four-AST-unused-compiles-only',len(trees)==4)
for role in ('declaration','runtime_closure'):
 verify_pin(subject[role],role)
verify_pin(offer['manual_envelope'],'manual-envelope')
decl=load(Path(subject['declaration']['path']));closure=load(Path(subject['runtime_closure']['path']));manual=load(Path(offer['manual_envelope']['path']))
check('closure-total-source-join',closure['sources']==subject['sources'] and closure['python']==subject['python'] and closure['declaration']==subject['declaration'])
check('declaration-whole-input-join',decl['inputs']==subject['inputs'] and len(subject['inputs'])==1)
for record in subject['inputs']:verify_pin(record['pin'],'complete-input-'+record['role'])
for index,p in enumerate(closure['stdlib_files']):verify_pin(p,'stdlib-'+str(index))
verify_pin(closure['predecessor_closure'],'historical-closure')
for role,tree in trees.items():
 imports=set()
 for node in ast.walk(tree):
  if isinstance(node,ast.Import):imports.update(x.name for x in node.names)
  elif isinstance(node,ast.ImportFrom):imports.add(node.module)
 check('direct-import-census-'+role,sorted(imports)==closure['direct_import_census'][role])
check('manual-matches-sources',manual['subject']==subject['sources'])
check('exact-original-outer-limits',subject['limits']==decl['limits']==manual['outer_limits']==dict(work_seconds=180,overall_seconds=210,memory_bytes=1073741824,result_bytes=134217728,expanded_bytes=134217728,stdout_bytes=4194304,stderr_bytes=4194304,worker_receipt_bytes=4194304,runner_metadata_bytes=8388608,observer_bytes=1048576))
check('manual-pin-in-declaration',decl['manual_envelope']==offer['manual_envelope'])

bank=load(Path(subject['inputs'][0]['pin']['path']))
check('complete-unchanged-bank-pin',subject['inputs'][0]['pin']['sha256']=='081b2eb3344d56b10a3399e8bf9826248011bc8faedbc5065d26129c27939f88')
check('all-normal-group-order',[g['id'] for g in bank['normal_groups']]==decl['normal_group_ids'])
check('all-diagnostic-group-order',[g['id'] for g in bank['diagnostic_groups']]==decl['diagnostic_ids'])
check('normal-population-arithmetic',1792+1785+7+1778+16==5378 and decl['exact_normal_cases']==5378)
check('all16-word-controls-and-length-bound',len(bank['normal_groups'][4]['cases'])==16 and max(len(x['bytes']) for x in bank['normal_groups'][4]['cases'])==6)
check('all32-declaration-cases',3*(7+1)+1+3+4==32)
check('all25-foreign-sites-types',5*5==25)
check('all62-generator-calls',2+32+3+25==decl['exact_generator_calls']==62 and decl['generator_completed']==2 and decl['generator_raised']==60)
check('manual-LEAD-and-other-arithmetic',sum(manual['LEAD_depth_upper'])==38 and sum(manual['other_modes_upper'])==59 and manual['assigned_upper']==97 and manual['all_states_upper']==100 and manual['literal_rows_upper']==388)
check('full-mutation-population',3*388+(100-3)==manual['mutation_population_upper']==1261)
check('full-mutation-record-upper',100*(64+3)+389*32+4096==23244 and 23244<manual['mutation_record_bytes_upper']==24576)
check('ordinary-packet-bound-terms',sum(manual['complete_packet_upper_terms'].values())==manual['complete_packet_manual_upper_bytes']==41691136 and 41691136<manual['complete_packet_lease_bytes']==50331648)
check('manual-term-products',5362*1024==5490688 and 16*4096==65536 and 1261*24576==30990336 and 62*32768==2031616 and 60*32768==1966080 and 3*32768==98304)
check('normal-step-manual-arithmetic',1792*8+12551+12544+7+16*49==manual['normal_trajectory_steps_upper']==40222)
check('fixed-file-leases',decl['file_limits']=={'WORKER_CONSUMED.json':1048576,'canonical-utf8-calibration.json':50331648,'result.json':1048576,'worker-receipt.json':1048576,'worker-failure.json':50331648,'failure-summary.json':65536})
check('simultaneous-physical-bound',sum(decl['file_limits'].values())+2*4194304+9437184==manual['maximum_physical_lease_bytes_including_logs_and_outer']==121700352 and 121700352<134217728)
check('actual-directory-absent',not Path(subject['actual_directory']).exists())
check('prospective-terminal-directory-absent',not (R/'utf8-plan-prospective-v1-terminal-observation').exists())

assembly=load(R/'utf8-controls-static-assembly-v1.json')
old_runner=OLD/'root/run_batch_once_v1.py';old_observer=OLD/'root/observe_batch_once_v1.py'
check('historical-controller-Source-pins',pin(old_runner)['sha256']==assembly['old_runner_sha256']=='9f5a2a31acdc03d94b4e89842af2606f405ddb4ba933f1d5099f6b4280af3090' and pin(old_observer)['sha256']==assembly['old_observer_sha256']=='51a0385fb85f7715e01789d0ebcd2d5f7e806d7258cdd7db4fef4ca8d56219ab')
oldtext=old_runner.read_text();newtext=Path(subject['sources']['runner']['path']).read_text()
def remove_validator(text):
 a=text.index('def validate_qualification(');b=text.index('\n\ndef main(',a)
 return text[:a]+text[b:]
inverse=remove_validator(newtext)
for a,b in [
 ('One Root-owned complete UTF8v2 physical lexical component qualification; original caps.','One Root-owned complete batched implicit palette/point-graph calibration; original caps.'),
 ("VERSION='utf8-physical-lexical-once-runner-v1'","VERSION='implicit-batch-point-graph-once-runner-v1'"),
 ("SOURCE_ROLES=frozenset(('worker','utf8','runner','observer'))","SOURCE_ROLES=frozenset(('worker','implicit','graph','selector','runner','observer'))"),
 ("len(plan['inputs'])==1,'entire original UTF8v2 component bank'","len(plan['inputs'])==2,'unchanged complete original bank plus separate complete new diagnostic bank'"),
 ("profile='complete-UTF8v2-physical-lexical-component'","profile='complete-batched-implicit-palette-point-graph-calibration'")]:
 check('single-runner-declaration-delta-'+str(len(a)),inverse.count(a)==1);inverse=inverse.replace(a,b,1)
check('controller-process-log-clock-custody-byte-exact',inverse==remove_validator(oldtext))
obs=Path(subject['sources']['observer']['path']).read_text()
obs=obs.replace("VERSION='utf8-physical-lexical-terminal-observer-v1'","VERSION='implicit-batch-point-graph-terminal-observer-v1'",1)
newscope='Complete declared UTF8v2 physical lexical component only. No G1, old palette/graph-cohort rescue, full VM/BOOT, FOL proof search, tiling/plane result or advantage qualification. Runner Source-entry epoch excludes observer/interpreter prelude. Standalone worker highwater has no Native/full-production fit authority.'
oldscope='Finite complete batched implicit-palette, singleton-center point-graph and batch/summary diagnostic calibration only; no full literal expansion, physical interpreter, FOL kernel/proof search or advantage qualification. Runner Source-entry epoch excludes observer/interpreter prelude. Standalone worker highwater has no Native/full-production fit authority.'
check('observer-scope-single-delta',obs.count(newscope)==1)
obs=obs.replace(newscope,oldscope,1)
check('observer-terminal-timeout-byte-exact',obs==old_observer.read_text())
master=pin(OLD/'publisher/docs/basic-tiling-algorithm.md')
check('current-master-pin',master['sha256']=='ca6ee206287bf18b69f88a35d30968312499567755f347a819af4cf49743e7d4')
retired=load(OLD/'root/ROOT-grant-retirement-v2.json')
check('old-grant-stays-retired-zero',offer['old_grant_remaining']==0 and retired['grant_status']=='RETIRED' and type(retired['remaining_actual_invocations']) is int and retired['remaining_actual_invocations']==0)

findings=[
 dict(id='distinct-subject',finding='This is a fresh complete UTF8v2 lexical component cohort. It does not trim or qualify the old15case/33legacy/28newgraph cohort, adoptG1, rescueG0 or qualify a complete interpreter/proof/search/RL system.'),
 dict(id='full-bank-coverage',finding='All5378normals and all five unchanged diagnosticgroups are implemented:1792mode-byte,1785prefix-fence,7rootblank,1778midblank and16word controls;32declaration,3quota,25foreign, all3D+Q-3fulltable mutants and a twofreshconstruction identity group. No expected answer selects a smaller rank/population.'),
 dict(id='independent-physical-verification',finding='The full table checker validates exact fields, state/alphabet/index census, every unique read slot, unchangedwrites, bitmove/stationaryexits, root/interiorB, every#BOUND and all12undefined halt slots. Independent simulation retains full tape/head/trace; byte categories are separately authored, and all16word decisions additionally agree with pinnedPython surrogatepass decode.'),
 dict(id='lexical-scope',finding='Every input byte is consumed in exactly8LSB steps, including impossibleprefixes. MidbyteB explicitlyREJECT differs from oldundefined/stuck. The experiment tests the new completed lexical specification and accepted-word language under the documented oldnonaccepting interpretation, without oldphysical trajectory/headcost equivalence.'),
 dict(id='LEAD38-proof',finding='Depth0..2 use trivial1/2/4bounds. Depth3/4 partition lowprefix into0,1,2..3,4,other:5classes. Depth5 partitions0,1,2..15,16,17..19,20,21..31:7classes. Depth6 vectors LEAD,LEAD,REJECT,lasttag and depth7pairsLEAD,lasttag admit7lasttags. Equal residual functions share same depth/successor keys; sum38 is a conservative upper, not generatedcount.'),
 dict(id='other-mode59-proof',finding='Each128..191continuation interval has oneclass throughdepth6 and twoclasses atdepth7:9states.160..191 has sixearlyoneclasslevels then2+2:10.144..191 and128..143 each have fiveearlyoneclasslevels then2+2+2:11. Totals59, plus38LEAD=97assigned,3halts=100total and388literal rows; crossmode sharing only lowers this.'),
 dict(id='generator-cost-and-reuse',finding='Two complete fresh generation calls are required and strict full typed tables match while table/delta owners differ. Every declaration/quota/foreign call is fresh and recorded;62started,2complete,60raised are separately validated. No cached table attestation or pre-run generation is permitted.'),
 dict(id='exact-primary-and-custody',finding='Session.guard checks raw Sources and function/code/default/closure owners at call entry/exit, full typed effective limits and callback seals. Callback/argument/result/error owners are retained; plannedforeign objects and trigger lists remain exact. Genuine Root latches dominate expected-fault classification; foreign public exception class instances are not treatedowned by class.'),
 dict(id='raw-prefix-boundaries',finding='The subject retains complete available construction rows/names/activechoices on exact faults. Work/state/transition cutoffs check genuine Source.step provenance and exactfirstlimit populations. Raw firsttransition is retained beforecallback/limit. Failed prefixes never become lexicalrejection/BOUND or admittedtables.'),
 dict(id='mutation-evidence',finding='Every row has duplicate/dangling/wrongmove variants plus every fence-row deletion. Each record stores its complete ordinary candidate table, rejection/error and Source site; original baseline typed value is checked unchanged. It does not save only hashes or patches, and no archivedpartial is a fixture.'),
 dict(id='ordinary-byte-bound',finding='All literal names are bounded ASCII<=64characters, totalstates<=100, full/duplicate delta<=389rows at conservative32bytes/row.100*(64+3)+389*32+4096=23244<24576bytes including bounded metadata. At most1261matrixrecords; nonword/word records conservatively fit1024/4096bytes. The full summed41691136byte packet upper remains below48MiB.'),
 dict(id='complete-failure-evidence',finding='Failure retains completed normals/calls/diagnostics plus active operation and one pendinggroup, with a separate48MiBlease. It first attempts a separately bounded64KiBscalarnegative summary. Exact primary remains authoritative; oversized/incomplete output staysrawpartial/nonadmitted. No file repair, deletion, truncation, overwrite or name retry.'),
 dict(id='aggregate-physical-reservation',finding='All six declared file leases, simultaneous48MiBmain+48MiBfailure, bounded4MiBlogs and original9MiBouterreserve total121700352bytes<134217728. Each declared filename is spentonce and write enforces its ownceil; completedfiles and failedpartials remain charged. This is ordinary completeJSON stored=expanded for this distinct certificate, with no G1reference/unfolding shortcut.'),
 dict(id='work-time-memory-prerequisites',finding='The manual40222physical normal steps and full bounded row scans support a finite work prerequisite. Root callbacks, hashing/custody/canonicalization/writes and all preparations remain charged; no hardwaretime or exactheap fit is claimed. Actual180spositive,210scustody,400mRootcallbacks and1GiBworkerHWM gates remain decisive.'),
 dict(id='controller-preservation',finding='After removing the reviewed qualification-validator body and reversing five declaration replacements, the runner exactly matches its pinned predecessor bytes. Observer exactinverse changes onlyversion/scope. Processcreation, Sourceentryepoch, wait4reap, fresh ownedgroup probes before signals, separately guarded cleanup, stablewholelogs, finalrawcustody and externalterminal guards remain unchanged.'),
 dict(id='positive-terminal-gates',finding='No candidateadmission without completecanonical/result/header, knownnormalworkerexit and positiveresultread beforeoriginal180. Later rawinput/Source/stdlib/resource/log/ledger closure staysbefore210. Externalobserver joins runnerexit0 withsameplan/epoch/ownedgroup/log/bytes and no postreceiptdeadlinefailure; timeout225 is an observationfailsafe, not extendedpositiveauthority.'),
 dict(id='runtime-trust-scope',finding='Closure explicitly trusts interpreter/builtin/frozen/transitivestdlib/OSloader/SourceFileLoaderpyc under ordinaryexclusive ownership, not hostileglobals/defaultcontents/concurrentmutation. Its inherited oldprofile/graph-query prose is historical/out-of-subject: currentguard/typedlimits/callbackseals were reviewed directly, and no profile/graph qualification follows.'),
 dict(id='authority-barrier',finding='Prospectiveauthorization isfalse/max0, actualdirectory andprospectiveterminaldirectory absent, oldgrantsretired0. This review is Sourceonly and grantsnothing. Root may issue only a fresh exactsubjectonce grant after grant-onlydelta review and all-peer idlebarrier; no Source/harness/controller/fixture/simulator/sizing call has occurred in this review.'),
]
receipt=dict(schema='wang-encoding-Source-prospective-review-v1',reviewer_identity='/root/recovered_batch_review',review_passed=True,source_only=True,component_calls=0,actual_execution_authorized=False,full_subject_review_complete=True,
 subject=subject,subject_sha256=offer['subject_sha256'],offer=pin(offer_path),plan=offer['plan'],manual_envelope=offer['manual_envelope'],declaration=subject['declaration'],runtime_closure=subject['runtime_closure'],inputs=subject['inputs'],sources=subject['sources'],python=subject['python'],stdlib_files=closure['stdlib_files'],master=master,
 checks=checks,failed_checks=[],manual_findings=findings,
 subject_imports=0,subject_function_calls=0,controller_calls=0,fixture_calls=0,simulator_calls=0,table_generation_calls=0,sizing_probes=0,partial_files_opened=0,
 new_grants=0,old_grant_remaining=0,G1_adopted=False,old_G0_unchanged=True,complete_physical_VM=False,proof_discovery=False,mathematical_admission=False,runtime_qualified=False,
 full_read=['all4offeredSources','wholeUTF8v2bank','manualenvelope','declaration','runtimeclosure','prospectiveplan/falseauth','staticassemblySource/receipt'],
 static_metadata=dict(AST_parse_count=4,unused_compile_count=4,compiled_code_executed=False),
 metadata_note='Initial guessed manual-resource-envelope filename was absent; exact offered utf8-manual-envelope-v1.json then read fully. Missing optional path supplied no evidence and no Source operation. A receipt-author-only incorrect retirement field assumption was separately preserved and corrected; no offered Source changed.',
 review_author_metadata_negative=pin(O/'utf8-review-author-negative-v1.json'),
 tools_stopped_after_freeze=True)
out=O/'typed-UTF8-component-Source-prospective-review-v1.json'
with out.open('x') as f:f.write(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(receipt=pin(out),checks=len(checks),manual_findings=len(findings)),sort_keys=True))
