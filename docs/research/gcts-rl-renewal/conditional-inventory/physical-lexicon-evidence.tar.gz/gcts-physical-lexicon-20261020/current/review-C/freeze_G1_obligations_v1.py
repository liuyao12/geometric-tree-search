"""Independent Source/complete-metadata inventory author; no subject execution."""
import ast
import hashlib
import json
from pathlib import Path

BASE=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs')
OLD=BASE/'gcts-batch-20261020'
PRE=BASE/'gcts-evidence-next-20261020'
NEW=BASE/'gcts-complete-evidence-20261020'
OWN=NEW/'review-C'
checks=[]

def pin(path):
    raw=path.read_bytes()
    return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())

def check(label,condition):
    assert condition,label
    checks.append(dict(id=label,passed=True))

def load(path):
    return json.loads(path.read_text())

paths={
 'master':OLD/'publisher/docs/basic-tiling-algorithm.md',
 'worker':OLD/'root/qualify_complete_batch_worker_v2.py',
 'component':OLD/'components-B/implicit_wang_batch_v2.py',
 'graph':OLD/'recovered/L/implicit_wang_point_search_v1.py',
 'field_map':PRE/'bounds-B/one-owner-field-map-v1.json',
 'contract_findings':PRE/'review-C/evidence-expansion-contract-findings-v1.json',
 'old_bank':OLD/'recovered/ROOT/implicit-inputs-v1.json',
 'batch_bank':OLD/'diagnostics-L/new-diagnostic-bank-v1.json',
 'old_grant_retirement':OLD/'root/ROOT-grant-retirement-v2.json',
 'previous_final_milestone':PRE/'root/ROOT-final-milestone-v1.json',
 'previous_publication_commit':PRE/'root/ROOT-publication-commit-v1.json',
 'bound_review':PRE/'review-C/typed-expanded-lower-bound-review-v1.json',
 'python':Path('/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12'),
}
pins={name:pin(path) for name,path in paths.items()}
expected={
 'master':('ca6ee206287bf18b69f88a35d30968312499567755f347a819af4cf49743e7d4',36240),
 'worker':('9ea014de87d5af2ed3017442f690699a0ef54750c8d8be12890e373936b65a03',116476),
 'component':('2dd3269a96bbe8db63afdffc3b175830dad5dea7cc94555024a7aac95ef088e7',38513),
 'graph':('1a83c9c59b2e1862d5a2acda69b826ccc3a8e2cf4899e824286f711f8bf25981',36892),
 'field_map':('3d34e2572390a44b40e12d0ead9c110f5c6e30ae0079c3d617ff080da61a4020',18747),
 'contract_findings':('d5ec96f459b1c603fe7cd579997d4e9cec63bba2f68bbc8f807c2ac97073a02d',21455),
 'old_bank':('10fe60d005a2f586a76bf69ae30317b8dae538ba9f126714b9f71ffa474a89b4',740651),
 'batch_bank':('6e579fa58384188b5444606c87dbdee92a86f5771a983a36fbf6904192e669ab',38883),
 'old_grant_retirement':('d724f817dca900ce1e02bde46ae2a1b644344f12ca27b1de42173d3d1f4ab74d',5051),
 'bound_review':('b75be9752672ce878c67d8b9f85fafa557359b91c33de0ad65a203dcff162dba',11278),
 'python':('b6ea0c2a9bfce48dbf181a53f1ca4f0562d40658b85bf47258e2a88d8f9e3933',18058560),
}
for name,(sha,size) in expected.items():
    check('pin-'+name,(pins[name]['sha256'],pins[name]['bytes'])==(sha,size))
milestone=load(paths['previous_final_milestone'])
check('previous-published-active-no-authority',milestone['commit']=='78ea2758da701e41a350817c5089908b37d98989' and milestone['goal_status']=='active' and milestone['new_grants']==0 and milestone['new_actual_invocations']==0 and milestone['old_grant_remaining']==0 and milestone['G1_adopted'] is False)
worker=ast.parse(paths['worker'].read_bytes(),filename=str(paths['worker']))
component=ast.parse(paths['component'].read_bytes(),filename=str(paths['component']))
graph=ast.parse(paths['graph'].read_bytes(),filename=str(paths['graph']))
for tree,label in ((worker,'worker'),(component,'component'),(graph,'graph')):
    unused=compile(tree,label,'exec')
    del unused
check('three-AST-and-unused-compile-only',True)

def fn(tree,name):
    matches=[n for n in ast.walk(tree) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==name]
    assert len(matches)==1,(name,len(matches))
    return matches[0]

def dict_fields(node):
    assert isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id=='dict'
    return dict(line=node.lineno,fields=[x.arg for x in node.keywords if x.arg is not None],spreads=[ast.unparse(x.value) for x in node.keywords if x.arg is None])

def returned_dict(tree,name):
    nodes=[n.value for n in ast.walk(fn(tree,name)) if isinstance(n,ast.Return) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id=='dict']
    assert len(nodes)==1,(name,len(nodes))
    return dict_fields(nodes[0])

def assigned_dict(tree,function,target):
    nodes=[]
    for n in ast.walk(fn(tree,function)):
        if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==target for t in n.targets) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id=='dict':
            nodes.append(n.value)
    assert len(nodes)==1,(function,target,len(nodes))
    return dict_fields(nodes[0])

inventory={
 'canonical_packet':returned_dict(worker,'qualify'),
 'normal_small_palette':returned_dict(worker,'qualify_small_palette'),
 'normal_large_palette':returned_dict(worker,'qualify_large_palette'),
 'normal_graph_case':returned_dict(worker,'qualify_graph'),
 'profile_success_row':assigned_dict(worker,'profile_call','row'),
 'profile_return_bindings':assigned_dict(worker,'profile_call','bindings'),
 'profile_accounting_row':assigned_dict(worker,'record_profile_accounting','row'),
 'profile_metrics':returned_dict(worker,'profile_metrics'),
 'batch_diagnostic_run':returned_dict(worker,'_batch_diag_owner_result'),
 'q':assigned_dict(worker,'main','q'),
 'result_payload':assigned_dict(worker,'main','payload'),
 'worker_header':assigned_dict(worker,'main','header'),
 'operation_counts':assigned_dict(worker,'main','counts'),
 'forbidden_operation_zero_counters':assigned_dict(worker,'main','zeros'),
 'worker_failure':assigned_dict(worker,'main','failure'),
 'scalar_failure_summary':returned_dict(worker,'_failure_summary_record'),
 'raw_profile_state':assigned_dict(component,'with_profile','state'),
}
check('exact-24-canonical-fields',len(inventory['canonical_packet']['fields'])==24)
check('exact-12-metrics',len(inventory['profile_metrics']['fields'])==12)
for name in ('q','result_payload'):
    inventory[name]['spread_fields_expanded']=inventory[name]['fields']+inventory['operation_counts']['fields']+(inventory['forbidden_operation_zero_counters']['fields'] if name=='result_payload' else [])
inventory['worker_header']['spread_fields_expanded']=inventory['worker_header']['fields']+inventory['forbidden_operation_zero_counters']['fields']
ordinary=fn(worker,'_ordinary_profile_lifetime')
keys=[n.value for n in ast.walk(ordinary) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='keys' for t in n.targets)]
check('ordinary-lifetime-literal-key-tuple',len(keys)==1 and isinstance(keys[0],ast.Tuple))
inventory['ordinary_profile_lifetime']=dict(line=ordinary.lineno,fields=list(ast.literal_eval(keys[0]))+['attempted_work','data_items','query_fault','body_result'])
schema_records={}
for n in ast.walk(component):
    if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='dict':
        schemas=[k.value.value for k in n.keywords if k.arg=='schema' and isinstance(k.value,ast.Constant) and isinstance(k.value.value,str)]
        if schemas and schemas[0] in ('implicit-wang-profile-receipt-v1','implicit-wang-profile-failure-prefix-v1','implicit-wang-build-receipt-v1','implicit-wang-count-receipt-v1','implicit-wang-select-receipt-v1'):
            schema_records.setdefault(schemas[0],[]).append(dict_fields(n))
inventory['component_schema_records']=schema_records
old=load(paths['old_bank']);batch=load(paths['batch_bank'])
population=dict(
 normal_ids=[r['id'] for r in old['small_palettes']]+[old['large_palette']['id']]+[r['id'] for r in old['graph_cases']],
 small_palette_ids=[r['id'] for r in old['small_palettes']],
 large_palette_id=old['large_palette']['id'],
 graph_cases=[dict(id=r['id'],kind=r['kind'],mode=r['mode']) for r in old['graph_cases']],
 legacy_diagnostics=[dict(id=r['id'],operation=r['operation'],role=r['role'],expected=r['expected'],expected_callback_count=r['expected_callback_count'],expected_callback_function=r['expected_callback_function']) for r in old['diagnostics']],
 batch_groups=[dict(id=g['id'],subject=g['subject'],recipe=g['recipe'],variant_ids=[v['id'] for v in g['variants']]) for g in batch['groups']],
)
check('original-15-normal',len(population['normal_ids'])==15)
check('original-4-small-10-graph',len(population['small_palette_ids'])==4 and len(population['graph_cases'])==10)
check('original-33-legacy',len(population['legacy_diagnostics'])==33)
check('original-28-groups-55-variants',len(population['batch_groups'])==28 and sum(len(g['variant_ids']) for g in population['batch_groups'])==55)

obligations=[
 dict(id='S01_TOTAL_SCHEMA',requirement='Provide a versioned total schema and field-by-field mapping for all24 old canonical top-level fields and every literal descendant. Unknown, absent, duplicate or unowned required fields must cause refusal. A pin, count, PASSED status, recipe name or hash is not a replacement for a required value.',verification='Independent schema checker must enumerate required paths/roles and reject omissions/extras, not trust the producer mapping.'),
 dict(id='S02_FULL_INPUTS',requirement='Retain both complete raw original banks plus strict decoded values and exact ordered case bindings. Preserve all original machine transition rows, wire parameters, palette records, targets, pins, generations, modes,33legacy declarations and28groups55variants including parameters/triggers/expected/source_reasoning.',verification='Check raw byte pins and strict typed subtree bindings against original Source-bound inputs; never regenerate a smaller bank from emitted answers.'),
 dict(id='S03_NORMAL_POPULATION',requirement='Preserve exactly four small cases, one large case and ten graph cases in original order. For every small palette preserve all independent nonempty masks, declared empty cross-splices, every original rank and exact16-times-inventory witness multiplicity, with deterministic128-request scopes. Preserve large global samples and all focused families without claiming full large enumeration.',verification='Independent population/bijection checks and explicit original scope labels, including no-full-materialization/no-full-large-unranking.'),
 dict(id='S04_INDEPENDENT_ORACLES',requirement='Retain the complete independently compiled legacy palette and semantic tiles, independent expected bucket populations, direct large membership/cardinality provenance, every independent graph solution identity and independent domains. Equal actual and expected payloads may share bytes only with distinct provenance bindings.',verification='Expected values must come from the independent Source/oracle route; reading the actual answer twice is not independent verification.'),
 dict(id='S05_EXACT_VALUES',requirement='Preserve exact permitted types, tuple/list distinction, bool/int distinction, string code-unit content, dictionary insertion order when it is part of custody, absent keys versus assignedzero/None, and every nested t/m/color/inventory identity. Declare float/bytes/custom-object support explicitly; never coerce a nonliteral object into a replayable literal.',verification='Strict typed equality and complete decoding checks; hash lookup alone is insufficient, unsupported carriers refuse.'),
 dict(id='S06_EVENT_IDENTITY',requirement='Allocate a distinct immutable ordinal for every actual call, profile, query, observation, baseline/reference, diagnostic run and exit/fault occurrence. Equal payloads do not merge occurrences. Preserve original per-stream ordering and explicit cross-stream/case/profile/variant bindings.',verification='Closed population/order/conservation checks; no inferred global event order from an old rejected partial or from equality of values.'),
 dict(id='S07_PROFILE_LIFECYCLE',requirement='Retain every attempted profile, including failed constructor/entry/preparation/body/query/reconciliation/exit. Preserve the complete raw registered lifetime, ordinary projection, exact descriptor/limits/declared arguments, request sequence, receipts, typed preimages, stage/failed_stage, counters, cost availability and custody flags.',verification='One accounting row per attempted scope; normal request/produced/preimage/delivered populations agree only on success, and active failure states remain distinct.'),
 dict(id='S08_RAW_PRODUCED_BEFORE_COPY',requirement='Keep a produced raw receipt and full tile reachable before the first receipt-copy callback or quota can fail. An active query retains ordinal/request/stage/start_work/produced_receipt/produced_preimage/preimage_complete/delivered independently of completed receipts.',verification='Required first-receipt-tree diagnostic distinguishes1produced/0preimage/0delivered and empty completed sequence; no lost available tile or fabricated completed preimage.'),
 dict(id='S09_MUTATION_VERSIONS',requirement='Keep exact independent typed receipt preimage, observed post-callback value and reconciliation result as separately attributed versions. Do not retarget an earlier immutable owner after mutation or intern mutable references before the value is sealed.',verification='The bool0-to-False, list-to-tuple, absent-to-assignedzero and changed authority controls must retain both versions and private refusal semantics.'),
 dict(id='S10_RETURN_BINDINGS',requirement='Preserve all profile-return metadata plus four explicit bindings: receipts to lifetime.receipts aslist; attempted_requests to lifetime.requests astuple; exact_receipt_preimages to lifetime.expected_receipts astuple; body_result to lifetime.body_result byidentity. Normal body_result remainsNone and caller-owned small/large/graph results remain separately reachable.',verification='Total binding schema rejects wrong type/container/path/owner/version and verifies full returned object equivalence; a smaller body return may not erase consumer output.'),
 dict(id='S11_GRAPH_CONFORMANCE',requirement='Retain every graph result descendant, ordered journal/query_journal, whole solution placements/tiles/generations and every full observation: points/chosen/marks/domains/exclusions, dependency incidence, branch parent snapshots, next-rank cursors, scheduler and rollback_parent. Preserve every independent domain population and all BEFORE/AFTER_ROLLBACK and root-restoration checks.',verification='GlobalDEAD beforeFORCED beforeearliest-generation branching; full target, marking values/refcounts/fixed ownership and conditional exclusions independently checked under the master contract.'),
 dict(id='S12_GRAPH_SCOPE',requirement='Keep finite singleton-center/four-midpoint adaptation and the nonzero-root TEST_VARIANT label. No new claims for arbitrary support, remote extra markings, fractional t, infinite plane coverage, physical FOL interpreter or unrestricted RL follow from this calibration.',verification='Result statuses distinguish finite solution/exhaustion/restricted behavior/UNKNOWN; complete branch/root restoration is not a plane proof.'),
 dict(id='S13_LEGACY_DIAGNOSTICS',requirement='Retain all33 legacy diagnostic rows and every present descendant, including callback count/trace, original expected site, exact foreign identity, private-owner classification, setup receipts, full subject/graph prefixes and UNKNOWN results.',verification='GenuineRoot first fault checked before expected-fault classification. Foreign public class membership alone never means private ownership. Only exact graph-owned quota may become UNKNOWN, never zero or UNSAT.'),
 dict(id='S14_NEW_DIAGNOSTICS',requirement='Retain all28groups55variants in exact declaration order, including baselines, reference standalone calls, closed-query attempts, all owner-result fields, work scalars, three lifetime counters and ordinary lifetime/prefix projections. Preserve failedprofile notadmitted, custody refusal, swallowed/reentrant first-fault identity and secondary nonmasking.',verification='Every planned trigger must follow genuineRoot guard; expected refusal is distinct from profile/custody admission. Complete tuple/list/bool/None and nested values are retained.'),
 dict(id='S15_SCALAR_SUMMARY_SCOPE',requirement='Retain complete scalar-builder records and cap/availability/truncation flags, writer_invokedFalse and filesystem_persistence_testedFalse. A scalar summary is diagnostic-only and is not full prefix or output-persistence evidence.',verification='Hostile exception/prefix controls do not call repr/str/iterate. Missing/nonliteral counters stay unavailable; capped rows never stand in for uncapped evidence.'),
 dict(id='S16_COST_CONSERVATION',requirement='Keep started/completed/raised full maps, Root callback counts with cutoff scope, all12 profile metrics and every complete/failed per-profile cost row. Distinguish attempted cumulative profile cost, preparation, query kernel, overhead and post-preparation overhead. Count each cumulative profile once; do not add its kernels again.',verification='Known totals and unavailable observations are separate. Constructor or missing-prefix work remainsNone/unavailable; no zero fabrication or all-cost-complete inference from partial sums.'),
 dict(id='S17_CUSTODY_NOT_SERIALIZATION',requirement='Keep the actual Source/module/function/code/default/kwdefault/closure cells and contents, callback/class member owners, query dispatcher, descriptor/argument owners, Work owner and exact primary/secondary exception/traceback objects alive through final custody. Serialized IDs/type labels are nonreplayable metadata.',verification='Entry/exit/final genuine Source and strict argument seals remain real checks; round-tripping a value store does not reconstruct executable identity or private resource ownership.'),
 dict(id='S18_CALL_CONTRACTS',requirement='Retain original effective args/limits/callback association for every standalone/profile call and exact success/refusal/fault outcomes. Preserve detached descriptor acceptance only after full strict typed equality; dynamic graph oracle ticks still charge the exact L callback and Root guard.',verification='Before/after call integrity, query function/closure seals and dispatcher restoration are checked on both return and fault; no warm cache substitutes for an actual component operation.'),
 dict(id='S19_PROGRESS_VIEWS',requirement='Completed progress/reader groupings may be views only after an explicit mapping to the same canonical event owners. Preserve stage transitions, completed IDs/order and the full unfinished active run/prefix; do not drop incomplete state merely because no final row was admitted.',verification='Join views to complete owners with population equality and retain an immutable final reader projection. View deduplication is explicitly part of G1 gate change.'),
 dict(id='S20_OUTER_ENVELOPE',requirement='Preserve q/result/header identities, raw output pins, invocation/plan/declaration/runtime closure binding, call/metric counters, logical/expanded byte declarations, denied-event observations, process IDs/epochs/deadlines, exact broader-claimfalse flags and separate external runner/observer terminal observations.',verification='No positive component admission without complete canonical/result/header, original positive work deadline and known worker exit, final Source/input/stdlb custody, physical/memory/Root-callback gates and original outer cleanup window.'),
 dict(id='S21_NONADMISSION_ON_FAILURE',requirement='Any incomplete output, stopped query, failed seal, failed schema/binding verification, missing cost/terminal observation or unclosed active transaction prevents positive admission. Preserve exact first Root fault over planned/secondary faults. Retain all raw files, leases and objects; never repair a partial.',verification='Bounded negative summary/prefix is separately labeled diagnostic-only. File absence/rename/deletion cannot finance a retry or make missing completion counts available.'),
 dict(id='S22_EXPLICIT_CHANGED_GATE',requirement='G0 remains the old literal canonical expansion plus conservative profile-return reconstruction charge, with its reviewed negative unchanged. A DAG/one-owner format that charges fewer duplicate logical occurrences is a new gate even if all information is retained. Name the changed contract and exact semantic claim before adoption.',verification='No label of merecompression, exactoldgatepass or retroactive rescue. G1 remains unadopted until complete schema/preservation/independent verification/resource review.'),
 dict(id='S23_THREE_BYTE_MEASURES',requirement='Declare exact stored bytes, per-owner full typed unfolding bytes and semantic occurrence/binding charges separately. A physical reference is not itself a full logical value. If G1 intentionally charges a unique value owner once plus each event/binding record, say so explicitly; it is not old full-occurrence charging.',verification='Define a total cost function on the complete schema, specify all charged owners/events/roles/views/metadata, forbid silently zeroing required payload/occurrences and prove the implemented ledger equals that declared function.'),
 dict(id='S24_RESOURCE_BOUND',requirement='A valuecodec compression ratio or example roundtrip gives no whole-cohort fit. Bound full inputs, value nodes, event/binding records, independent evidence, diagnostic baselines/failures, type/version metadata, duplicate physical views, negative/header/log slots and all reconstruction/verification costs.',verification='Use exact complete-cohort Source bounds or actually admitted complete observations under unchanged caps. Preserve128MiB stored/declaredexpanded, physicalsumincluding9MiBreserve,180/210seconds,1GiBworkerHWM,400mRootcallbacks; no bank trimming or cap raise.'),
 dict(id='S25_AGGREGATE_OUTPUT',requirement='Use one cooperative aggregate budget across canonical file, result/header, logs, all partials and reserved negative space before bulk allocation. Failed leases retain unused capacity and exactness may become unavailable; successful fixed reservation and completed size remain separate.',verification='Fresh reviewed integration must use full writer contract, safe once names/no overwrite/retry/truncate/delete, exact raw pins and metadata census. Writer Source pass alone is not filesystem qualification.'),
 dict(id='S26_INDEPENDENT_DECODE',requirement='Provide an independently reviewed complete decoder/schema validator that rejects malformed, truncated, cyclic, forward/missing-reference, duplicate-owner, noncanonical/type-alias and trailing-data encodings according to the declared codec. Reconstruct complete required logical values and verify semantic joins separately.',verification='Codec roundtrip is one test, not proof of event completeness or field preservation. Decode only complete authorized outputs; partials remain raw bytes/length/hash only.'),
 dict(id='S27_PROVENANCE_AND_AUTHORITY',requirement='Bind all new Source/stdlib/dependency closures, raw banks, schema/version/charge convention, exact population, limits and claim scope in one prospective offer. Old six-role closure is historical provenance, not permission to omit a newly added codec/writer/checker dependency.',verification='Independent wholeSource review and fresh Root-only once grant, explicit consumed-beforelaunch and external terminal custody. All retired grants stayzero; no Source function or fixture calls before the new reviewed actual.'),
 dict(id='S28_SEPARATE_COMPONENT_EXPERIMENTS',requirement='These full15/33/28 requirements apply to a successor claiming qualification of the original full batch. A separately declared complete lexical or codec component bank can be qualified under its own exact reviewed once subject, with its own limited claim.',verification='Do not call a separate component bank a trimmed old-cohort pass, G1 adoption, fullVM, automatically discovered theorem or GCTS/RL advantage.'),
]

binding_details={
 'receipts':dict(source='profile_rows[*].lifetime.receipts',container='list'),
 'attempted_requests':dict(source='profile_rows[*].lifetime.requests',container='tuple'),
 'exact_receipt_preimages':dict(source='profile_rows[*].lifetime.expected_receipts',container='tuple'),
 'body_result':dict(source='profile_rows[*].lifetime.body_result',container='identity'),
}
report=dict(
 schema='independent-G1-complete-evidence-obligations-v1',
 reviewer_identity='/root/recovered_batch_review',
 status='SOURCE_ONLY_OBLIGATIONS_NOT_AN_IMPLEMENTATION_OR_GATE_ADOPTION',
 source_only=True,G0_unchanged=True,G1_adopted=False,fit_proved=False,
 actual_execution_authorized=False,new_grants=0,new_actual_invocations=0,
 subject_imports=0,subject_calls=0,helper_calls=0,compiler_calls=0,checker_calls=0,
 fixture_calls=0,simulator_calls=0,sizing_probes=0,table_generation_calls=0,
 partial_files_opened=0,partial_JSON_parses=0,mathematical_admission=False,
 runtime_qualified=False,GCTS_RL_advantage_established=False,goal_status='active',
 pins=pins,checks=checks,failed_checks=[],
 reading_scope=dict(master='Full current tracked isolated master read; no fresh primary-working-bytes claim.',worker='Full116476B oldworker read, including normal qualification,33legacy and28/55new diagnostic, wrapper/outer success/failure paths.',component='Relevant full profile/query lifecycle and return/prefix constructors read; schema descendants remain full literal obligations.',graph='Relevant oracle/query, observation/core, solution/journal/result and failure constructors read.',field_map='Full prior16-category mapping and gate-change text read.'),
 source_AST_field_inventory=inventory,
 original_population=population,
 full_literal_descendants_rule='Every listed schema payload owns every original descendant, not only the named fields. This inventory is derived from Source construction sites; it is not a parsed completed canonical packet. No such completed packet from the rejected old actual is claimed.',
 exact_profile_return_bindings=binding_details,
 obligations=obligations,
 plain_value_store_assessment=dict(
 sufficient_for='Exact immutable typed payload ownership, storage sharing and explicit full-value reconstruction under its separately reviewed codec contract.',
 insufficient_for=['Total oldfield/subtree coverage and full case/diagnostic populations.','Event identities/order/cross-stream joins and independent-oracle provenance.','Before/after mutation versions and partial query production/preimage/delivery states.','Actual Source/function/closure/argument/Work/error/callback owner custody.','Authentic Root firstfault, private ownership and known-versus-unavailable costs.','Whole-schema charge definition, complete resource bounds, aggregate physical output/negative reservation and external terminal admission.'],
 separate_inference='A complete codec may be correct and useful while no full G1 certificate is implemented, preserved, fitting, authorized or admitted.'),
 inherited_G0_negative=dict(review=pins['bound_review'],conditional_expanded_lower_bytes=134857533,unchanged_limit_bytes=134217728,excess_lower_bytes=639805,partial_content_used=False,no_global_infeasibility_claim=True),
 static_method=dict(AST_parse_count=3,unused_compile_count=3,compiled_code_executed=False,metadata_only=True),
 review_notes=[
  'A quick parent message stated26canonical fields; the exact AST inventory corrects that to24 before freezing. No Source execution occurred.',
  'An optional read of the not-yet-existing newRoot/research-direction-v1.json reported file missing. It was not used as authority or evidence; exact assigned scope comes from the parent instruction and pinned prior milestone.',
  'Current numeric byte caps are not a representation-independent semantic invariant. Owner-expanded versus occurrence-expanded charging must be stated precisely, and an explicitly new G1 gate must not be mislabeled oldG0 equivalence.',
  'This note defines review obligations; it does not execute a preservation checker, create fixtures, adopt a schema, implement codec/writer/controller, prove fit or authorize any actual.'
 ],
 tools_stopped_after_freeze=True,
)
out=OWN/'independent-G1-obligations-v1.json'
with out.open('x') as f:
    f.write(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(receipt=pin(out),checks=len(checks),canonical_field_count=len(inventory['canonical_packet']['fields']),normal=len(population['normal_ids']),legacy=len(population['legacy_diagnostics']),batch_groups=len(population['batch_groups']),batch_variants=sum(len(g['variant_ids']) for g in population['batch_groups'])),sort_keys=True))
