"""Grant-only raw metadata audit. No subject/control/harness functions run."""
import hashlib
import json
from pathlib import Path
N=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-complete-evidence-20261020')
R=N/'root';O=N/'review-C';checks=[]
def check(label,value):
 assert value,label
 checks.append(dict(id=label,passed=True))
def pin(path):
 raw=path.read_bytes();return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def load(path):return json.loads(path.read_text())
def verify(p,label):check(label,pin(Path(p['path']))==p)
expected={
 'utf8-authorization-once-v1.json':('e036272c2425fdf812d2ce63266069c0b15250f1e5943ab0f8b88c88ea725e2a',829),
 'utf8-plan-authorized-v1.json':('b77044480ccf93fe68ca120dafb98763c3f194ad7ea2d69015a638cb872168ac',2788),
 'ROOT-utf8-grant-issuance-v1.json':('185f126074935ae1a0f9a3cf7654c67283bdcf57f2bc921636cac6e5364364cb',1613),
 'barrier-before-utf8-grant-v1.json':('cb714a17f688d1613a6e7264042b438482c63dfa3025391012ce60b1d8e9f9d7',604),
}
pins={}
for name,(sha,size) in expected.items():
 p=pin(R/name);check('exact-pin-'+name,(p['sha256'],p['bytes'])==(sha,size));pins[name]=p
issued=load(R/'ROOT-utf8-grant-issuance-v1.json')
auth=load(R/'utf8-authorization-once-v1.json')
plan=load(R/'utf8-plan-authorized-v1.json')
barrier=load(R/'barrier-before-utf8-grant-v1.json')
for key in ('authorization','plan','prospective_plan','review','barrier'):verify(issued[key],'issuance-pin-'+key)
review=load(Path(issued['review']['path']));prospective=load(Path(issued['prospective_plan']['path']))
check('exact-complete-review',issued['review']['sha256']=='7ae6c69815b86a86232f040d328fc09ac7c53c1ac7686851f1f07bb086fada4b' and review['schema']=='wang-encoding-Source-prospective-review-v1' and review['reviewer_identity']=='/root/recovered_batch_review' and review['review_passed'] is True and review['full_subject_review_complete'] is True and review['failed_checks']==[] and len(review['manual_findings'])==18)
check('review-not-execution-authority',review['source_only'] is True and type(review['component_calls']) is int and review['component_calls']==0 and review['actual_execution_authorized'] is False)
subject={k:v for k,v in plan.items() if k!='authorization'}
check('only-plan-authorization-changed',subject=={k:v for k,v in prospective.items() if k!='authorization'}==review['subject'])
check('exact-plan-field-set',set(plan)==set(prospective))
digest=hashlib.sha256(json.dumps(subject,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode('ascii')).hexdigest()
check('same-exact-subject-SHA',digest==issued['subject_sha256']==review['subject_sha256']==auth['subject_sha256']=='d57adc6054cd43ed4623029655578709c6657e2e2705b3a8418dacd1d96d5712')
check('grant-literal-Root-once',set(auth)=={'schema','author_identity','actual_execution_authorized','maximum_actual_invocations','subject_sha256','review','scope'} and auth['schema']=='ROOT-wang-encoding-authorization-v1' and auth['author_identity']=='/root' and auth['actual_execution_authorized'] is True and type(auth['maximum_actual_invocations']) is int and auth['maximum_actual_invocations']==1 and auth['review']==issued['review'])
verify(plan['authorization'],'authorized-plan-auth-raw-pin')
verify(prospective['authorization'],'prospective-falseauth-raw-pin')
falseauth=load(Path(prospective['authorization']['path']))
check('old-prospective-auth-unchanged',falseauth['actual_execution_authorized'] is False and type(falseauth['maximum_actual_invocations']) is int and falseauth['maximum_actual_invocations']==0)
check('issuance-Root-once-no-old-reuse',issued['author_identity']=='/root' and type(issued['maximum_actual_invocations']) is int and issued['maximum_actual_invocations']==1 and issued['old_grants_remaining']==0 and issued['subject_calls']==0)
for role,p in subject['sources'].items():verify(p,'unchanged-Source-'+role)
for key in ('python','declaration','runtime_closure'):verify(subject[key],'unchanged-'+key)
verify(review['manual_envelope'],'unchanged-manual-envelope')
for row in subject['inputs']:verify(row['pin'],'unchanged-whole-input-'+row['role'])
for index,p in enumerate(review['stdlib_files']):verify(p,'unchanged-stdlib-'+str(index))
check('original-caps-unchanged',plan['limits']==prospective['limits']==review['subject']['limits'])
check('original-complete-bank-unchanged',plan['inputs']==prospective['inputs']==review['inputs'] and len(plan['inputs'])==1 and plan['inputs'][0]['pin']['sha256']=='081b2eb3344d56b10a3399e8bf9826248011bc8faedbc5065d26129c27939f88')
check('barrier-recorded-before-grant',barrier['author_identity']=='/root' and barrier['new_grants_before_this']==0 and barrier['no_subject_execution_yet'] is True and barrier['other_agents_tools_stopped'] is True and barrier['process_inventory_complete'] is True and barrier['owned_qualification_processes']==[] and barrier['other_python_process_metadata']==[] and barrier['review_sha256']==issued['review']['sha256'])
check('actual-still-absent',not Path(plan['actual_directory']).exists())
check('authorized-terminal-still-absent',not (R/'utf8-plan-authorized-v1-terminal-observation').exists())
check('no-G1-or-broader-authority',all(term in auth['scope'] for term in ('No G1','all5378normals','all5diagnosticgroups','rerun','fullBOOT/VM')))
receipt=dict(schema='wang-encoding-grant-only-delta-review-v1',reviewer_identity='/root/recovered_batch_review',status='PASS_GRANT_ONLY_DELTA',review_passed=True,grant_only=True,source_only=True,subject_sha256=digest,subject=subject,pins=pins,full_Source_review=issued['review'],manual_envelope=review['manual_envelope'],prospective_plan=issued['prospective_plan'],authorized_plan=issued['plan'],authorization=issued['authorization'],barrier=issued['barrier'],checks=checks,failed_checks=[],
 subject_imports=0,subject_calls=0,component_calls=0,controller_calls=0,helper_calls=0,fixture_calls=0,simulator_calls=0,sizing_probes=0,partial_files_opened=0,actual_launches_by_reviewer=0,
 actual_execution_authorized_by_this_review=False,Root_grant_maximum_actual_invocations=1,old_grants_remaining=0,G1_adopted=False,mathematical_admission=False,
 findings=['Exact unchanged prospective subject and full Source review joined; only authorization descriptor changes in plan values.','Root exactonce grant binds one complete unchanged UTF8v2 component bank and original caps; no oldgrant or G1 authority transfers.','AllSource/runtime/input/manual/stdlb raw pins remain exact.','Saved pregrant barrier reports allpeersstopped/noownedprocess; actual and authorizedterminal directories remain absent at this review.','This audit ran metadata-only tools. Root must obtain a fresh final idlebarrier after reviewer tools stop, then alone may invoke the one authorized observer. No launch or experiment was performed by the reviewer.'],
 tools_stopped_after_freeze=True)
out=O/'typed-UTF8-grant-only-delta-review-v1.json'
with out.open('x') as f:f.write(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(receipt=pin(out),checks=len(checks)),sort_keys=True))
