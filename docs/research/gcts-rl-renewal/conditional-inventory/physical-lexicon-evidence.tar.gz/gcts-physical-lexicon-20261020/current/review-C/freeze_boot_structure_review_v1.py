"""Passive Source/AST and declarative metadata review only."""
import ast
import hashlib
import json
from pathlib import Path
N=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-complete-evidence-20261020')
L=N/'physical-L'; O=N/'review-C'
def pin(p):
 raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
expected={
 'handoff-v1.json':('cfd6ca8fad3534fffa5575c4efafad2d531c36d92e482a693b41ae0b636cf787',3560),
 'boot_postfix_structure_v1.py':('830a57c3f2fc04e0327f73a12a7ce7dd921aad682390f5e67d8d2e745bbf8496',12628),
 'API-v1.json':('38f10de5abfe8f8a408f409d5ce9256fce9e18873cb150811df0c8dda5753e87',7248),
 'diagnostic-bank-v1.json':('1810831c038b51d6bd9018d7c8ce554a4e28127c3aa9f62681d802f2f0c16b7d',22461),
 'manual-argument-v1.json':('dea57bcb073fde3dfe7fd83894a56fe5d16be648c1a65b06a149262db4ed4611',5120),
 'lineage-pins-v1.json':('8de6f5e1d23b8be52e6a23eb779852b7f409203598e3bb98eb10000e6e48febf',1590),
 'freeze-manifest-v1.json':('2661f2cef75599b8009d8b0ff02a549befb2436a9839094cc40c1cadf0563b7e',1838),
 'author-static-audit-v1.json':('158efc23f5d0f9d8d2cc31b93033a0e9161e2720f46e77204d4ee2b2d29f7c3e',1425),
}
checks=[];pins={}
def check(name,value):
 assert value,name
 checks.append(dict(id=name,passed=True))
for name,(sha,size) in expected.items():
 p=pin(L/name);check('pin-'+name,(p['sha256'],p['bytes'])==(sha,size));pins[name]=p
tree=ast.parse((L/'boot_postfix_structure_v1.py').read_bytes())
unused=compile(tree,'boot_postfix_structure_v1.py','exec');del unused
check('Source-AST-unused-compile-only',True)
check('fixed-generator-keyword-interface',any(isinstance(n,ast.FunctionDef) and n.name=='describe_boot_postfix_machine' and len(n.args.args)==0 and [a.arg for a in n.args.kwonlyargs]==['check','limits'] for n in tree.body))
bank=json.loads((L/'diagnostic-bank-v1.json').read_text())
check('bank-full-eight-families',len(bank['families'])==8)
check('bank-full-thirteen-controls',len(bank['controls'])==13)
check('bank-full24-construction',len(bank['construction_diagnostics'])==24)
check('bank-unique-ids',len({x['id'] for k in ('families','controls','construction_diagnostics') for x in bank[k]})==45)
check('manual-allocation-arithmetic',7+3+18+12+12+1==53 and 53+21==74 and 54+21==75 and 74+75==149 and 149+3==152 and 149*24==3576 and 3*24==72)
api=json.loads((L/'API-v1.json').read_text())
check('explicit-limited-scope',api['full_BOOT'] is False and api['full_VM'] is False and api['runtime_qualified'] is False and api['actual_execution_authorized'] is False)
receipt=dict(schema='boot-postfix-physical-structure-independent-Source-review-v1',reviewer_identity='/root/recovered_batch_review',status='PASS_SOURCE_ONLY_CONDITIONAL_STRUCTURAL_GRAMMAR',source_only=True,
 subject_imports=0,subject_calls=0,helper_calls=0,table_generation_calls=0,fixture_calls=0,simulator_calls=0,sizing_probes=0,partial_files_opened=0,actual_execution_authorized=False,runtime_qualified=False,full_BOOT=False,full_VM=False,G1_adopted=False,mathematical_admission=False,
 pins=pins,checks=checks,failed_checks=[],full_read=['Source','API','manual argument','all eight family recipes','all13literal controls','all24construction cases','handoff'],
 manual_findings=[
  dict(id='literal-physical-actions',finding='Each nonhalt state is assigned exactly24 literal physical read/next/write/move actions. Default visible invalid symbols reject and globalR exitsBOUND. No transition invokes a host classifier, value decoder, arithmetic opcode or input-derived state index. State/alphabet generation accepts no word/program/theory/capacity/horizon.'),
  dict(id='physical-layout-preconditions',finding='Unique L/R, input/stack headers and delimiters, initial raw input, B/1 scratch and exclusive marker ownership are explicit preconditions. Scans rewind toL then seek fixed header. Missing/malformed layout is outside lexical/termination claims; there is no global layout validator or16band linkage.'),
  dict(id='atom-range',finding='The eighteen bit/flag states per mode physically read nineLSB-first bits. The low-eight nonzero flag allows ninth1 only after eightzero bits; hence accepted atom range is exactly0..256. The current input marker is consumed and the next physical symbol marked before a stack traversal.'),
  dict(id='unary-stack',finding='Initialization clears each B/1 scratch cell. Push scans unary1 prefix and writes firstB or returnsBOUND at capacity. Pop scans to B/fence, erases final1 then checks a predecessor1; empty/singleton underflow rejects, and a full scratch band can still pop. Failed scratch need not be restored and cannot be admitted.'),
  dict(id='roots-and-padding',finding='FREE2/PUBLIC3 scan exactlytwo/three pending unary roots, then require B/fence. Postsemicolon cursor accepts only B padding until firstcolonDONE. Input fence givesBOUND at that phase. DONE ignores postcolon data and constructs no actual value tree.'),
  dict(id='manual-bound',finding='Per-mode base counts53/54 plus21cached marker destinations give74/75assigned states;149assigned+3halts=152total,24symbols,3576literal rows and72undefined halt slots. These are conditional Source upper/count arguments, not generated census or resourcefit.'),
  dict(id='termination-scope',finding='On well-formed finite layout, each traversal stops at its declared header/marker/fence. The stated coarse32(W+1)^2 physical-step upper is consistent with at most a constant number of full-span traversals per consumed input symbol; no timing or whole interpreter fit follows.'),
  dict(id='construction-fault-custody',finding='Allocation publishes names/rows before state callback; assignment retains each raw action before its transition callback. Exact construction foreign errors are rethrown with best-effort original prefix attachment. Own predicates check exact type+private-convention owner; public impostor classes are not inferredowned.'),
  dict(id='bank-status',finding='All eight exhaustive families,13controls and24construction cases are declarative and unrun. Future independent oracle must model first observed lexical/capacity failure and all cases. No fixture or simulator was authored/called by this review.'),
  dict(id='scope-gaps',finding='Value/cons/heap construction, tagged values, UTF8/key uniqueness, program parser, fullBOOT/controller, outerEOF, sixteen-band linkage and physical-to-host checker correspondence remain absent. This is a useful structural routine Source component, not an implemented proof system or GCTS/RL result.')
 ],
 static_metadata=dict(AST_parse=True,unused_compile=True,compiled_code_executed=False),
 metadata_read_note='An initial guessed manual filename was absent; the exact handoff-named manual-argument-v1.json was then fully read. No Source function was run and no missing file supplied evidence.',
 tools_stopped_after_freeze=True)
out=O/'typed-boot-postfix-structure-Source-review-v1.json'
with out.open('x') as f:f.write(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(receipt=pin(out),checks=len(checks)),sort_keys=True))
