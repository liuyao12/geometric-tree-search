"""Passive complete saved JSON/value/pin audit; never reruns a research function."""
import hashlib
import json
from pathlib import Path
N=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-complete-evidence-20261020')
R=N/'root';O=N/'review-C';A=R/'actual-utf8-v1';T=R/'utf8-plan-authorized-v1-terminal-observation'
checks=[]
def check(label,value):
 assert value,label
 checks.append(dict(id=label,passed=True))
def pin(path):
 assert not path.name.endswith('.partial')
 raw=path.read_bytes();return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def pairs(rows):
 out={}
 for key,value in rows:
  if key in out:raise ValueError('duplicate saved JSON key')
  out[key]=value
 return out
def load(path):
 assert path.suffix=='.json' and not path.name.endswith('.partial')
 return json.loads(path.read_bytes(),object_pairs_hook=pairs)
def verify(p,label):check(label,pin(Path(p['path']))==p)
def same(a,b):
 if type(a) is not type(b):return False
 if type(a) in (list,tuple):return len(a)==len(b) and all(same(x,y) for x,y in zip(a,b))
 if type(a) is dict:return set(a)==set(b) and all(same(a[k],b[k]) for k in a)
 return a==b
retirement_path=R/'ROOT-utf8-grant-retirement-v1.json';ret=load(retirement_path)
check('exact-retirement-pin',(pin(retirement_path)['sha256'],pin(retirement_path)['bytes'])==('f6c466981753cdbc72e792364687ab1ca32fbe016d231d29680f737457f50572',5260))
check('retired-one-and-zero-remaining',ret['grant_status']=='RETIRED' and ret['actual_invocations']==1 and ret['remaining_actual_invocations']==0 and ret['rerun_authorized'] is False and ret['old_grants_remaining']==0)
raw_manifest=ret['all_actual_files']
check('twelve-complete-files',len(raw_manifest)==12)
for i,p in enumerate(raw_manifest):verify(p,'raw-file-pin-'+str(i))
observed_names={str(p) for folder in (A,T) for p in folder.iterdir() if p.is_file()}
check('complete-directory-census',observed_names=={p['path'] for p in raw_manifest})
check('no-partial-or-alias-members',all(not p.name.endswith('.partial') and p.is_file() and not p.is_symlink() for folder in (A,T) for p in folder.iterdir()))
packet_path=A/'canonical-utf8-calibration.json';packet=load(packet_path)
check('exact-complete-packet',(pin(packet_path)['sha256'],pin(packet_path)['bytes'])==('4b05a7048b885b008b1ca27d65dae446e8f080109d176b8bf703447d0f63b4c3',10533076))
payload=load(A/'result.json');runner=load(A/'runner-receipt.json');header=load(A/'worker-receipt.json');terminal=load(T/'terminal.json')
consumed=load(A/'CONSUMED.json');wc=load(A/'WORKER_CONSUMED.json');oc=load(T/'CONSUMED.json')
plan=load(R/'utf8-plan-authorized-v1.json');decl=load(Path(plan['declaration']['path']));closure=load(Path(plan['runtime_closure']['path']))
review=load(O/'typed-UTF8-component-Source-prospective-review-v1.json');grantreview=load(O/'typed-UTF8-grant-only-delta-review-v1.json')
verify(ret['authorized_plan'],'retired-exact-plan');verify(ret['grant'],'retired-exact-grant')
check('review-and-grant-exact-subject',ret['subject_sha256']==review['subject_sha256']==grantreview['subject_sha256']=='d57adc6054cd43ed4623029655578709c6657e2e2705b3a8418dacd1d96d5712' and {k:v for k,v in plan.items() if k!='authorization'}==review['subject'])
for role,p in plan['sources'].items():verify(p,'unchanged-Source-'+role)
for key in ('python','declaration','runtime_closure'):verify(plan[key],'unchanged-'+key)
verify(review['manual_envelope'],'unchanged-manual-envelope')
for i,p in enumerate(closure['stdlib_files']):verify(p,'unchanged-stdlib-'+str(i))
for item in plan['inputs']:verify(item['pin'],'unchanged-bank-pin')
bank=load(Path(plan['inputs'][0]['pin']['path']))
check('full-original-bank-stored',same(packet['bank'],bank))
check('packet-identity',packet['schema']=='complete-utf8-lexical-packet-v1' and packet['status']=='COMPLETE_COMPONENT_CALIBRATION_CANDIDATE' and packet['raw_owners_retained'] is True)
for key in ('G1_adopted','complete_physical_VM','proof_discovery','mathematical_authority'):check('packet-false-'+key,packet[key] is False)
table=packet['table'];Q=len(table['states']);D=len(table['delta']);modes=list(table['entries'])
check('actual-table-census',Q==85 and D==328 and len(table['undefined'])==12 and table['construction_counts']['states']==85 and table['construction_counts']['transitions']==328)
check('table-below-manual-bound',Q<=100 and D<=388 and len(table['entries'])==7)
slots={}
for row in table['delta']:
 assert type(row) is list and len(row)==5
 q,read,target,write,move=row
 assert type(q) is int and 3<=q<Q and type(target) is int and 0<=target<Q
 assert read in ('B','0','1','#') and write==read and type(move) is int and move==(1 if read in ('0','1') else 0)
 assert (q,read) not in slots
 slots[q,read]=row
check('all-saved-matrix-slots-present',len(slots)==4*(Q-3))
check('all-saved-halt-slots-present',table['undefined']==[[q,c] for q in range(3) for c in ('B','0','1','#')])

counts={g['id']:0 for g in bank['normal_groups']};seen={key:set() for key in counts};trace_count=0
words={c['id']:c for c in bank['normal_groups'][4]['cases']}
normal_order=[]
for record in packet['normal']:
 group=record['group'];counts[group]+=1
 if not normal_order or normal_order[-1]!=group:normal_order.append(group)
 result=record['result'];trace=result['trace'];tape=result['tape'];trace_count+=len(trace)
 assert type(trace) is list and trace and type(tape) is list and all(type(c) is str and c in ('B','0','1','#') for c in tape)
 mode=record.get('mode','LEAD');assert mode in table['entries']
 assert trace[0][0]==table['entries'][mode] and trace[0][1]==0
 # Static joins among saved literal rows and saved trace tuples only. No tape
 # or trajectory is generated, advanced or passed to a simulator/checker.
 for ordinal,step in enumerate(trace):
  assert type(step) is list and len(step)==5
  before,oldhead,read,after,newhead=step
  assert type(before) is int and type(oldhead) is int and type(after) is int and type(newhead) is int
  assert 0<=oldhead<len(tape) and tape[oldhead]==read
  row=slots[before,read]
  assert after==row[2] and newhead-oldhead==row[4]
  if ordinal:assert trace[ordinal-1][3]==before and trace[ordinal-1][4]==oldhead
 assert result['state']==trace[-1][3] and result['head']==trace[-1][4]
 if group=='all-seven-mode-byte-transitions':
  value=record['value'];assert type(value) is int and 0<=value<256 and len(trace)==8 and len(tape)==8
  assert sum((c=='1')*(1<<i) for i,c in enumerate(tape))==value
  target=1 if record['expected']=='REJECT' else table['entries'][record['expected']]
  assert result['state']==target and result['head']==8
  key=(mode,value)
 elif group in ('all-finite-prefix-fences','all-mid-byte-blanks'):
  length=record['length'];prefix=record['prefix'];assert type(length) is int and type(prefix) is int and 0<=prefix<(1<<length)
  assert (0 if group=='all-finite-prefix-fences' else 1)<=length<=7
  assert len(trace)==length+1 and len(tape)==length+1 and result['head']==length
  assert sum((c=='1')*(1<<i) for i,c in enumerate(tape[:-1]))==prefix
  assert tape[-1]==('#' if group=='all-finite-prefix-fences' else 'B')
  assert result['state']==record['expected']==(2 if group=='all-finite-prefix-fences' else 1)
  key=(mode,length,prefix)
 elif group=='all-byte-boundary-blanks':
  assert tape==['B'] and len(trace)==1 and result['head']==0 and result['state']==(0 if mode=='LEAD' else 1)
  key=mode
 else:
  assert group=='complete-word-controls'
  expected=words[record['id']]
  assert same(record['bytes'],expected['bytes']) and record['expected']==record['host']==expected['expected']
  assert len(trace)<=49 and len(tape)==8*len(record['bytes'])+1 and tape[-1]=='B'
  for i,c in enumerate(tape[:-1]):assert c==str((record['bytes'][i//8]>>(i%8))&1)
  assert result['state']==(0 if expected['expected']=='DONE' else 1)
  key=record['id']
 assert key not in seen[group]
 seen[group].add(key)
check('all-complete-normal-populations',counts==decl['normal_counts']==packet['normal_counts'] and sum(counts.values())==len(packet['normal'])==5378)
check('normal-group-order',normal_order==decl['normal_group_ids'])
check('all-normal-identities-unique',all(len(seen[k])==counts[k] for k in counts))
check('all-saved-full-traces-and-tapes-joined',0<trace_count<=40222)
check('all16-word-controls-direct-bank-join',seen['complete-word-controls']==set(words))

diags=packet['diagnostics'];check('five-complete-diagnostic-groups',[g['id'] for g in diags]==decl['diagnostic_ids'] and all(g['complete'] is True for g in diags))
check('all-diagnostic-populations',[len(g.get('variants',[])) for g in diags]==[32,3,25,1066,0] and 3*D+Q-3==1066)
call_ids=['first-fresh-construction']
for g in diags[:3]:
 for v in g['variants']:
  call_ids.append(('declaration/' if g is diags[0] else 'quota/' if g is diags[1] else 'foreign/')+v['id'])
call_ids.append('second-fresh-construction')
check('all62-call-occurrences-and-order',[c['id'] for c in packet['calls']]==call_ids and len(set(call_ids))==62)
callmap={c['id']:c for c in packet['calls']}
check('exact-success-failure-call-census',sum(c['complete'] is True for c in packet['calls'])==2 and sum(c['complete'] is False for c in packet['calls'])==60 and (packet['started'],packet['completed'],packet['raised'])==(62,2,60))
for v in diags[0]['variants']:
 c=callmap['declaration/'+v['id']]
 assert c['complete'] is False and same(c['limits'],v['limits']) and same(c['error'],v['error']) and same(c['prefix'],v['prefix'])
 assert v['error']['type']=='DeclarationError' and v['site']['file']==plan['sources']['utf8']['path'] and v['site']['function']=='describe_utf8_machine'
for v in diags[1]['variants']:
 c=callmap['quota/'+v['id']];p=v['prefix']
 assert same(c['prefix'],p) and same(c['error'],v['error']) and same(c['limits'],v['limits']) and p['complete'] is False
 assert v['error']['type']=='ConstructionLimit' and v['site']['file']==plan['sources']['utf8']['path'] and v['site']['function']=='step'
 assert p['attempted_work' if v['id']=='work' else v['id']]==2
 if v['id']=='transitions':assert len(p['active_choices'])==2
for v in diags[2]['variants']:
 c=callmap['foreign/'+v['id']];site,typ=v['id'].split('/')
 assert v['exact_foreign_identity'] is True and same(c['error'],v['error']) and same(c['prefix'],v['prefix'])
 assert v['error']['type']==typ and v['prefix']['complete'] is False and len(v['trigger'])==1
 assert v['site']['file']==plan['sources']['worker']['path'] and v['site']['function']=='callback'
 assert v['public_class_impostor'] is (typ in ('ConstructionLimit','DeclarationError'))
 if site=='raw-transition':assert len(v['prefix']['active_choices'])==1 and len(v['trigger'][0]['active_choices'])==1
check('all32-3-25-full-call-prefix-provenance-joins',True)

matrix=diags[3]['variants'];matrix_keys=set();recipes={}
for v in matrix:
 i=v['row_index'];recipe=v['recipe'];candidate=v['input'];delta=candidate['delta']
 assert type(i) is int and 0<=i<D and v['id']==str(i)+'/'+recipe and v['rejected'] is True and v['error']['type']=='TableInvalid'
 assert v['site']['file']==plan['sources']['worker']['path'] and v['site']['function']=='require'
 assert set(candidate)==set(table) and all(same(candidate[k],table[k]) for k in table if k!='delta')
 if recipe=='duplicate':
  assert len(delta)==D+1 and all(same(delta[j],table['delta'][j]) for j in range(D)) and same(delta[-1],table['delta'][i])
 elif recipe=='missing-fence':
  assert table['delta'][i][1]=='#' and len(delta)==D-1
  assert all(same(row,table['delta'][j if j<i else j+1]) for j,row in enumerate(delta))
 else:
  assert recipe in ('dangling','wrong-move') and len(delta)==D
  assert all(same(row,table['delta'][j]) for j,row in enumerate(delta) if j!=i)
  field=2 if recipe=='dangling' else 4
  assert all(same(x,table['delta'][i][j]) for j,x in enumerate(delta[i]) if j!=field)
  assert type(delta[i][field]) is int and delta[i][field]==(Q if recipe=='dangling' else 2)
 key=(i,recipe);assert key not in matrix_keys;matrix_keys.add(key);recipes[recipe]=recipes.get(recipe,0)+1
check('all1066-full-mutation-tables-exact-payload-deltas',recipes=={'duplicate':328,'dangling':328,'wrong-move':328,'missing-fence':82})
identity=diags[4]
check('two-full-identity-tables-retained',same(identity['first'],table) and same(identity['second'],table) and same(callmap['first-fresh-construction']['result'],table) and same(callmap['second-fresh-construction']['result'],table) and identity['strict_equal'] is True and identity['fresh_owners'] is True)
check('verifier-oracle-population-joins',packet['oracle_calls']==5378 and packet['verifier_calls']==5378+1066+2==6446)

q=payload['qualification'];check('result-census-joins',q['normal_counts']==counts and q['normal_case_count']==5378 and q['states']==Q and q['transitions']==D and q['undefined']==12 and q['compiler_calls']==62 and q['compiler_completed']==2 and q['compiler_raised']==60 and q['verifier_calls']==6446 and q['oracle_calls']==5378)
check('all-output-pins-join',payload['outputs']==q['outputs']==header['outputs']==runner['outputs']==[pin(packet_path)])
verify(header['result'],'worker-result-pin');verify(runner['worker_receipt'],'runner-worker-header-pin');verify(terminal['runner_receipt'],'terminal-runner-receipt-pin')
planpin=pin(R/'utf8-plan-authorized-v1.json')
check('all-plan-bindings',all(x['plan']==planpin for x in (payload,header,runner,terminal,consumed,wc,oc)))
check('same-epoch-and-deadlines',all(x['began_ns']==runner['began_ns'] and x['work_deadline_ns']==runner['began_ns']+180000000000 and x['overall_deadline_ns']==runner['began_ns']+210000000000 for x in (header,consumed)))
check('same-process-and-once-markers',header['pid']==wc['pid']==runner['worker_pid']==runner['owned_pgid'] and header['ppid']==wc['ppid']==terminal['runner_pid'] and wc['maximum_invocations']==consumed['maximum_worker_launches']==oc['maximum_runner_launches']==runner['worker_launch_attempts']==1 and consumed['consumed_before_Popen'] is True)
check('known-worker-runner-observer-exit0',runner['worker_exit_code']==0 and runner['worker_wait4_status']==0 and runner['worker_reaped'] is True and terminal['runner_exit_code']==0 and ret['tool_observed_terminal_exit']==0 and ret['tool_session']==49612)
check('positive-completion-before180',header['positive_worker_completed_ns']<runner['work_deadline_ns'] and runner['worker_terminal_observed_ns']<runner['work_deadline_ns'] and runner['positive_result_read_completed_ns']<runner['work_deadline_ns'])
check('terminal-and-custody-before210',terminal['terminal_gate_passed'] is True and terminal['terminal_observed_ns']<runner['overall_deadline_ns'] and runner['post_child_raw_custody']['checked'] is True and runner['post_child_raw_custody']['completed_before_deadline'] is True and runner['whole_log_custody']['complete'] is True and runner['whole_log_custody']['stable'] is True and runner['whole_log_custody']['completed_before_deadline'] is True and runner['final_physical_ledger']['completed_before_deadline'] is True)
check('logs-groups-and-no-faults',runner['owned_group_absent'] is True and runner['regular_logs_closed'] is True and runner['errors']==[] and runner['finalization_errors']==[] and runner['primary_failure'] is None and runner['signals']==[] and runner['cleanup']['diagnostics_incomplete'] is False and payload['denied_events']==[])
check('memory-original-gate',runner['worker_peak_bytes']==runner['worker_wait4_usage']['ru_maxrss']==59523072 and runner['worker_peak_bytes']<=1073741824)
check('same-original-limits',runner['limits']==plan['limits']==review['subject']['limits'])
logical=pin(packet_path)['bytes']+pin(A/'result.json')['bytes']
check('stored-expanded-ledgers',payload['canonical_logical_bytes']==payload['expanded_canonical_packet_bytes']==10533076 and logical==10536391==header['logical_result_bytes']==header['expanded_logical_result_bytes']==runner['logical_result_bytes']==runner['expanded_logical_result_bytes'] and logical<=134217728)
actual_bytes=sum(p['bytes'] for p in raw_manifest if Path(p['path']).parent==A)
observer_bytes=sum(p['bytes'] for p in raw_manifest if Path(p['path']).parent==T)
check('recorded-before-runner-receipt-physical',runner['final_physical_ledger']['before_receipt_bytes']+9437184==runner['conservative_physical_bytes']==19976017)
check('complete-after-receipt-physical',actual_bytes+9437184==19981710 and actual_bytes+9437184<=134217728 and actual_bytes+observer_bytes+9437184<=134217728)
check('observer-within-reserved1MiB',observer_bytes<=1048576)
check('Root-callback-cutoffs-exact',packet['root_callbacks']==196677 and q['root_check_calls']==199965 and header['root_check_calls']==199969 and 0<196677<199965<199969<=400000000)
check('recorded-clock-arithmetic',(terminal['terminal_observed_ns']-runner['began_ns'])/1e9==terminal['runner_clock_elapsed_seconds']==1.663739)
for obj in (payload,header,runner,terminal):
 for key in ('full_pipeline_qualified','scientific_acceptance','mathematical_proof_accepted'):assert obj[key] is False
check('scope-not-broader-qualification',q['G1_adopted'] is False and q['complete_physical_VM'] is False and q['proof_discovery'] is False and q['gcts_rl_advantage_established'] is False and terminal['ROOT_resource_accepted'] is False)
barrier=load(R/'ROOT-utf8-final-prelaunch-barrier-v1.json')
check('final-idle-barrier-join',barrier['subject_sha256']==ret['subject_sha256'] and barrier['grant_review_sha256']==pin(O/'typed-UTF8-grant-only-delta-review-v1.json')['sha256'] and barrier['all_other_agents_completed'] is True and barrier['all_tools_stopped'] is True and barrier['subject_calls_before_launch']==0 and barrier['python_processes']==[] and barrier['maximum_launches']==1)

receipt=dict(schema='UTF8-complete-saved-component-passive-review-v1',reviewer_identity='/root/recovered_batch_review',status='PASS_COMPLETE_SAVED_COMPONENT_EVIDENCE',review_passed=True,passive_only=True,complete_saved_packet_read=True,checks=checks,failed_checks=[],
 raw_manifest=raw_manifest,retirement=pin(retirement_path),Source_review=pin(O/'typed-UTF8-component-Source-prospective-review-v1.json'),grant_delta_review=pin(O/'typed-UTF8-grant-only-delta-review-v1.json'),final_idle_barrier=pin(R/'ROOT-utf8-final-prelaunch-barrier-v1.json'),
 saved_census=dict(states=85,transitions=328,undefined_slots=12,normal_cases=5378,normal_counts=counts,saved_trace_steps=trace_count,diagnostic_groups=5,declaration_cases=32,quota_cases=3,foreign_cases=25,matrix_full_records=1066,matrix_recipes=recipes,two_construction_identity_groups=1,subject_calls=62,subject_completed=2,subject_raised=60,verifier_calls=6446,oracle_calls=5378),
 resources=dict(terminal_runner_clock_seconds=terminal['runner_clock_elapsed_seconds'],instrument_seconds=terminal['observed_instrument_elapsed_seconds'],worker_HWM_bytes=59523072,canonical_bytes=10533076,stored_expanded_logical_bytes=10536391,runner_pre_receipt_conservative_physical_bytes=19976017,post_receipt_actual_directory_bytes=actual_bytes,post_receipt_actual_plus_same_reserve_bytes=19981710,observer_directory_bytes=observer_bytes,actual_and_observer_plus_reserve_bytes=actual_bytes+observer_bytes+9437184,Root_callbacks=dict(canonical_packet_cutoff=196677,result_cutoff=199965,worker_header_cutoff=199969,final_postheader_total=None),final_callback_scope='Later Source-enforced checks remain under400m; no separately serialized final postheader total is claimed.'),
 method='Complete JSON/raw-byte census, strict saved-value comparisons and literal saved-record joins only. No trajectory, byte-language answer, mutant fixture or output size was regenerated; no offered Source function, simulator, table checker, decoder or fixture was imported or called. Static saved trace tuples are joined to saved literal rows and tape cells; full candidate tables are compared with saved baseline subtrees, not executed.',
 limitations=['Exact foreign Python identity and fresh owner separation were checked inside the reviewed Source actual and saved as assertions/provenance. A post-exit JSON review cannot reconstruct or independently rerun those object identities.','Every complete saved record and literal descendant was parsed/compared for populations/joins; the reviewed actual remains the source of the independent semantic assertions. No new semantic replay or new test was conducted.','Standalone component resource observations do not establish wholeVM, fullBOOT, fullWang palette, proofsearch, GCTS/RL improvement or oldcohort/G1 qualification.','Root alone decides adoption within the limited finite lexical scope. The terminal ROOT_resource_accepted field remainsFalse until any separately authored Root adoption; this review creates no grant or rerun authority.'],
 review_author_metadata_negative=pin(O/'utf8-saved-review-author-negative-v1.json'),
 subject_imports=0,subject_function_calls=0,fixture_calls=0,simulator_calls=0,semantic_replays=0,checker_calls=0,sizing_probes=0,partial_files_opened=0,new_actual_invocations=0,new_grants=0,remaining_actual_invocations=0,actual_execution_authorized=False,
 supports_finite_component_adoption=True,ROOT_adoption_authority=False,G1_adopted=False,old_G0_unchanged=True,full_VM_qualified=False,proof_discovery=False,GCTS_RL_advantage_established=False,mathematical_admission=False,goal_status='active',tools_stopped_after_freeze=True)
out=O/'typed-UTF8-complete-saved-result-review-v1.json'
with out.open('x') as f:f.write(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(receipt=pin(out),checks=len(checks),trace_steps=trace_count,actual_bytes=actual_bytes,observer_bytes=observer_bytes),sort_keys=True))
