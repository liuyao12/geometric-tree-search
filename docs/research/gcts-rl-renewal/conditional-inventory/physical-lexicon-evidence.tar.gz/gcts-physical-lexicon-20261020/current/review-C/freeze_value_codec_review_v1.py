"""Static Source and complete declarative metadata audit; no codec imports."""
import ast
import hashlib
import json
from pathlib import Path
N=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-complete-evidence-20261020')
B=N/'schema-B';O=N/'review-C'
def pin(path):
 raw=path.read_bytes();return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def load(path):return json.loads(path.read_text())
checks=[]
def check(label,value):
 assert value,label
 checks.append(dict(id=label,passed=True))
handoff=load(B/'handoff-v1.json')
hp=pin(B/'handoff-v1.json')
check('exact-frozen-handoff',(hp['sha256'],hp['bytes'])==('7cefafe143ab68fb1f52ac54013caf54a0018c8e9ec8aa55ae07b7f01b4bb131',6710))
pins={'handoff':hp}
for entry in handoff['files']:
 p=pin(Path(entry['path']))
 check('frozen-file-'+Path(entry['path']).name,p==entry)
 pins[Path(entry['path']).name]=p
for key in ('predecessor_worker','master','predecessor_field_map','retirement','python'):
 check('lineage-pin-'+key,pin(Path(handoff[key]['path']))==handoff[key])
 pins[key]=handoff[key]
source=(B/'strict_value_dag_v1.py').read_bytes()
tree=ast.parse(source,filename='strict_value_dag_v1.py')
unused=compile(tree,'strict_value_dag_v1.py','exec');del unused
check('AST-unused-compile-only',True)
check('no-research-or-other-imports',not any(isinstance(x,(ast.Import,ast.ImportFrom)) for x in ast.walk(tree)))
check('no-callback-bearing-generators',not any(isinstance(x,(ast.GeneratorExp,ast.Yield,ast.YieldFrom)) for x in ast.walk(tree)))
bank=load(B/'diagnostic-bank-v1.json')
counts={}
for row in bank['cases']:counts[row['category']]=counts.get(row['category'],0)+1
check('all101-cases',len(bank['cases'])==101)
check('101-unique-ids',len({r['id'] for r in bank['cases']})==101)
check('exact-category-populations',counts=={'positive':28,'input-refusal':16,'wire-refusal':35,'quota':12,'foreign':10})
check('no-passed-test-labels',bank['status']=='DECLARATIVE_WHOLE_POPULATION_UNRUN' and not any(r['expected']=='PASSED' for r in bank['cases']))
api=load(B/'API-v1.json')
check('explicit-changed-gate-unadopted',api['unadopted_and_unqualified']['G1_adopted'] is False and api['unadopted_and_unqualified']['old_G0_unfolding_charged'] is False)
check('no-whole-schema-or-fit',api['unadopted_and_unqualified']['whole_case_schema_implemented'] is False and api['unadopted_and_unqualified']['fit_proved'] is False)
obligations=pin(O/'independent-G1-obligations-v1.json')
check('independent-obligations-pin',obligations['sha256']=='11133fef322621608f924f3368750b4e39aa2ae11f38fe1f4aa04fc3b815a17a')
findings=[
 dict(id='typed-domain',finding='Exact None/bool/int/float/str/list/tuple/dict are explicit and subclasses/bytes/custom values refuse. Ordered dictionary child occurrences, bool versusint, tuple versuslist, missing versuspresent values and surrogatepass string bytes are distinguished. Finite acyclic repeated values are allowed; active-container identity detects cycles.'),
 dict(id='float-policy',finding='Float value equivalence is the predecessor float.hex carrier, including signedzero/inf/nan. NaN sign/payload and raw alias identity are deliberately outside that carrier. Nonfinite support at this layer does not relax old canonical JSONallow_nanFalse or any future Root schema restriction.'),
 dict(id='exact-interning',finding='First-use depth-first postorder assigns positive child-before-parent IDs. Full immutable record bytes, not a digest, key fresh per-call interning. Repeated equal payloads may share one node but ordered root references and stored container child occurrences remain explicit. This is value sharing, not event provenance.'),
 dict(id='framing-canonicality',finding='The decoder checks fixedmagic, minimal unsignedLEB128, declared record lengths, exact per-record ends and no trailing data. Integers reject bad sign/negativezero/leadingzero magnitude; floats require exact .hex canonical spelling; strings require surrogatepass UTF8 re-encoding equality.'),
 dict(id='graph-canonicality',finding='Positive strictly earlier child IDs prevent cycles. Exact duplicate-record checks, first-use postorder traversal and total root reachability reject duplicate/padded/reordered graphs. Zero or out-of-store references refuse structurally.'),
 dict(id='native-dictionaries',finding='Complete decoder validation freshly materializes every reference occurrence and every dictionary, rejecting unhashable keys and builtin-equality collisions, including bool/int, int/float and signedzero collisions. Fresh NaN construction prevents interning alone from merging distinct native NaN key occurrences. The claim is value-tree correspondence under the declared pinnedPython behavior, not native alias/lookup identity.'),
 dict(id='no-header-shortcut',finding='validate_store follows the full parse and native-materialization path, retaining produced values in the raw lifetime even when only a receipt is returned. Every expanded native node occurrence consumes expanded_items/depth/work; a small shared store can refuse its expansion quota rather than pass by header/hash.'),
 dict(id='bounded-allocations',finding='String and integer allocation preflights conservatively bound their capacities; they may refuse before an exact wire-size limit is reached. Container reference and expanded-item/depth checks bound traversal. Private capacities are operation-local and provide no claim about outer actual memory/time or whole-cohort fit.'),
 dict(id='work-semantics',finding='tick charges max(1,units) then one Root callback. This is explicit traversal/byte accounting, not CPU instructions. Encode child-occurrence references and parser stored-reference counts have different declared scopes; no false equality between operation costs is asserted.'),
 dict(id='raw-owner-registration',finding='Mandatory retention receives state before Work construction. Work construction performs no delegatedcallback, and the Work owner is installed in retained state before its firsttick. The caller must retain actual aggregate, inputs, callbacks, Sources and exceptions through final custody; no-op retain is not evidence.'),
 dict(id='produced-output-and-faults',finding='Complete wire/native tuple is installed before final callback. Exact BaseException, includingStopIteration and foreign public-class instances, propagates unchanged; state retains exact primary and best-effort scalar prefix cannot admit or repair unfinished output. Private owned predicates require exactclass and matching owner.'),
 dict(id='read-only-precondition',finding='Root must supply genuine argument/function/closure custody and read-only callbacks/input. The codec is not a hostile-thread/global-mutation sandbox and does not establish firstRootfault dominance by itself. Future harness must check the independent Root latch before classifying expected failures.'),
 dict(id='manual-correspondence',finding='Under sufficient declared capacities and read-only supported input, the structural induction and canonical framing support value-tree decode/encode correspondence. It is a Source argument; no encoder, decoder, validator, materializer, carrier builder or test was called.'),
 dict(id='new-charge-definition',finding='The stated value-layer charge is exactly magic+count/length prefixes+unique full records+stored child/root references, hence wire length. It intentionally omits old recursively unfolded occurrences and is explicitly a new unadoptedG1 gate. No oldG0 pass, merecompression or retrospective rescue is claimed.'),
 dict(id='bank-scope',finding='All101cases are finite declarative recipes:28positive,16input refusal,35wire refusal,12quotas,10foreign. Their exact adapter, independent byte/value expectations, genuine Root gates and complete outcomes are still future work. The population is not exhaustive over all inputs/wires and is not reportedPASSED.'),
 dict(id='full-evidence-gap',finding='The codec supplies no complete case/event/provenance/mutation/custody schema or integration. Independent obligations11133f… remain binding for any original-cohortG1 successor; codec Source correctness and unique-byte charge alone cannot qualify that artifact.'),
 dict(id='unchanged-scientific-scope',finding='No t/m point semantics, scheduler, rollback, learned marking or RL behavior changes here. FullVM/checker/proofsearch, arithmetic/Hilbert theorem discovery, runtime/resourcefit and comparative advantage remain unestablished.'),
]
receipt=dict(schema='strict-value-dag-independent-Source-review-v1',reviewer_identity='/root/recovered_batch_review',status='PASS_SOURCE_ONLY_CONDITIONAL_VALUE_CODEC',source_only=True,pins=pins,independent_G1_obligations=obligations,checks=checks,failed_checks=[],manual_findings=findings,
 full_read=['Source','API','manual correspondence','all101declared cases','handoff'],bank_census=counts,
 subject_imports=0,subject_calls=0,helper_calls=0,codec_calls=0,fixture_calls=0,simulator_calls=0,sizing_probes=0,partial_files_opened=0,
 actual_execution_authorized=False,G1_adopted=False,old_G0_unfolding_charged=False,runtime_qualified=False,fit_proved=False,whole_G1_schema_qualified=False,mathematical_authority=False,
 static_metadata=dict(AST_parse=True,unused_compile=True,compiled_code_executed=False),tools_stopped_after_freeze=True)
out=O/'typed-strict-value-dag-Source-review-v1.json'
with out.open('x') as f:f.write(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(receipt=pin(out),checks=len(checks),cases=len(bank['cases'])),sort_keys=True))
