First complete point-tile search actual, 22 October 2026.

Original PA-reflexivity statement; automatic three-row E1/E1/GEN certificate.
Whole actual, independent review and Root disposition are distinct included records.
The unused duplicate row is retained. No proof minimality, arithmetic discovery, RL, learned marking, reusable family or speed advantage is claimed.
Original consumed negatives are not replayed. Other five statements remain unrun in this study.
Source/record packaging only. Pinned external Python binary is not bundled.
