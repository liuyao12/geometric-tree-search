"""Author metadata-only packaging code; no research imports or execution."""
from pathlib import Path

B = Path(__file__).resolve().parent.parent
OLD = B.parent / 'gcts-ordering-proof-pilot-20261020'
s = (OLD / 'root/package_ordering_report_v1.py').read_text()
s = s.replace("D10=B.parent/", "D11=B.parent/'gcts-ordering-proof-pilot-20261020'\nD10=B.parent/", 1)
s = s.replace("PREFIX='cluster-ordering-search'", "PREFIX='novel-cluster-search'")
s = s.replace("==205", "==169")
s = s.replace('typed-ordering-only-actual-scientific-review', 'typed-saturated-hint-actual-scientific-review')
s = s.replace('typed-ordering-only-resource-custody-review', 'typed-saturated-hint-resource-custody-review')
s = s.replace('97a58fbc063ff8b629393cdf21fe1d08436e3cded8b0237b1287ee06dd669b8c', 'b92f5d1d1fd7a6c7959c70b4e9d57a337f39a1868f693d9d3b504143052d1514')
a = s.index('insert=(')
z = s.index('offset=', a)
s = s[:a] + '''insert=('<section id="novel-cluster-update" class="panel"><h2>Declining redundant hints recovers the conventional proof</h2>'
        '<p><a href="novel-cluster-search.html#ordering">Read the exact-prefix novelty experiment</a>. '
        'All eighteen bounded searches return in three resource-admitted jobs. S0 and SC find the same fourteen-line proof through identical candidate ordering and primitive steps. '
        'This repairs the earlier regression without demonstrating useful cluster acceleration; all point searches remain budget unknown. Inspect both certificates, their colored markings and the reviewed evidence.</p></section>\\n').encode()
''' + s[z:]
s = s.replace("before.index(b'<section id=\"proof-cutoff-update\"')", "before.index(b'<section id=\"cluster-ordering-update\"')")
s = s.replace("paths.update([D10/", "paths.update([D11/'implementation-B/proof_search_pilot_v9.py',D11/'implementation-B/API-v1.json',\n              D11/'implementation-B/handoff-v1.json',D11/'root/protocol-v1.json',\n              D11/'root/passive-actual-assessment-v1.json',D11/'root/initial-passive-actual-join-v1.json',\n              D11/'publication/cluster-ordering-search-data.json',\n              P/'docs/research/gcts-rl-renewal/conditional-inventory/cluster-ordering-search-manifest.json',\n              D10/")
s = s.replace("elif path.is_relative_to(D10):", "elif path.is_relative_to(D11):name='dependencies/D11/'+path.relative_to(D11).as_posix()\n    elif path==P/'docs/research/gcts-rl-renewal/conditional-inventory/cluster-ordering-search-manifest.json':name='dependencies/D11/publication/cluster-ordering-search-manifest.json'\n    elif path.is_relative_to(D10):")
s = s.replace('admitted_point_placements=205', 'admitted_point_placements=169')
s = s.replace("qualified_recipient_certificates=1,recipient_engine='S0 conventional symbolic control'", "qualified_recipient_certificates=2,distinct_recipient_statements=1,recipient_engine='S0 conventional and SC cluster-guided symbolic searches; exact same primitive proof'")
a = s.index("scope='All three fresh D11 jobs")
z = s.index("')\nmb=", a)
s = s[:a] + "scope='All three fresh D12 jobs pass admission and all18 bounded arms return. Exact-prefix abstention plus inherited hint-only policy; registry remains UNKNOWN/unadmitted/usableempty. Two accepted records contain one known proof, no useful positive order difference or new theorem. Original D8 L handoff is inherited verifier provenance. B assessment is posthoc passive diagnosis, not a new experiment. Full D12 Sources and complete actuals are included; historical D11 raw actuals remain in the previous published evidence archive pinned by its included manifest. Publication-only review is outside this snapshot." + s[z:]
s = s.replace("conclusion='Three fresh resource-admitted jobs;205 placements/24 audits/144 word controls. All18 bounded searches returned, zero skips. SC80 packets and72 literal order changes lose the first S0 proof; point cluster arms0 proposals. One repeated conventional S0 certificate; no new theorem, point proof or GCTS/RL advantage.'", "conclusion='Three admitted jobs,18 searches/zero skips,169 point placements/24 audits/144 controls. S0 and SC produce the same14row known proof with identical positive candidate ordering and paths. SC8 packets/2 negative ordering changes, no point packets. Repair recovers baseline; no new theorem, useful ordering acceleration or trainedRL.'")
s = s.replace('cluster-ordering-reader-exact-insertion', 'novel-cluster-reader-exact-insertion')
s = s.replace('cluster-ordering-search-evidence-archive-v1', 'novel-cluster-search-evidence-archive-v1')
s = s.replace('cluster-ordering-archive-complete-byte-scan', 'novel-cluster-archive-complete-byte-scan')
s = s.replace('cluster-ordering-search-publication-manifest', 'novel-cluster-search-publication-manifest')
(B / 'root/package_novel_report_v1.py').write_text(s)
print('Metadata-only package script authored; no publication mutation yet.')
