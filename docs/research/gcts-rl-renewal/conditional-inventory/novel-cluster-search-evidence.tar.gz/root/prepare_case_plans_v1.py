"""Raw Source copies, complete saved metadata and AST/unused compile only."""
from pathlib import Path
import ast
import hashlib
import json

B = Path(__file__).resolve().parent.parent
OLD = B.parent / 'gcts-ordering-proof-pilot-20261020'
D5 = B.parent / 'gcts-proof-search-pilot-20261020'
R = B / 'root'
RUNTIME = B / 'runtime'

def pin(path):
    p = Path(path).resolve()
    assert '.partial' not in p.name
    raw = p.read_bytes()
    return dict(path=str(p), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

def read(path):
    assert '.partial' not in Path(path).name
    return json.loads(Path(path).read_bytes())

def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write('\n')

assert not RUNTIME.exists() and not (B / 'actual').exists()
RUNTIME.mkdir()
copies = []
names = ['observe_case_once_v2.py', 'run_case_once_v3.py',
         'case_worker_v1.py', 'independent_countermodel_v1.py']
runtime_sources = sorted((OLD / 'runtime').glob('*.py'))
assert len(runtime_sources) == 28
for source in runtime_sources + [OLD / 'root' / name for name in names]:
    target = (RUNTIME if source.parent.name == 'runtime' else R) / source.name
    assert not source.is_symlink() and not target.exists()
    target.write_bytes(source.read_bytes())
    assert target.read_bytes() == source.read_bytes()
    copies.append(dict(source=str(source), target=str(target),
                       bytes=source.stat().st_size, sha256=pin(source)['sha256']))
save(R / 'baseline-copy-pins-v1.json', dict(files=copies, count=32,
     scope='All runtime and custodian Sources byte-identical to D11; no execution.'))

api_path = B / 'implementation-B/API-v1.json'
handoff_path = B / 'implementation-B/handoff-v1.json'
api = read(api_path)
entry = Path(api['entry']['path'])
assert pin(entry) == api['entry']
assert api['roles'] == read(OLD / 'implementation-B/API-v1.json')['roles']
for field in ['model_source', 'verifier_source']:
    source = Path(api[field]['path'])
    assert pin(source) == api[field]
    assert (RUNTIME / source.name).read_bytes() == source.read_bytes()
assert read(handoff_path)
initial = read(R / 'Root-initial-reviews-handoff-v1.json')
for row in initial['reviews']:
    assert pin(row['path']) == row
    review = read(row['path'])
    assert review['review_passed'] and all(c['passed'] for c in review['checks'])

policy_path = Path(api['policy']['path'])
abstention_path = Path(api['abstention_policy']['path'])
assert pin(policy_path) == api['policy']
assert pin(abstention_path) == api['abstention_policy']
policy = read(policy_path)
abstention = read(abstention_path)
assert abstention['successor'] == pin(entry)
assert abstention['parent_ordering_policy'] == pin(policy_path)
assert policy['id'] == 'CONTEXT_CHECKED_PRIMITIVE_ORDERING_ONLY_V1'
assert policy['registry']['native_registry_required_for_ordering'] is False
assert all(policy['explicit_override'][k] for k in ['scope', 'specialization', 'freeze', 'literal_input'])
acquisition = Path(policy['superseded_acquisition_document']['path'])
assert pin(acquisition) == policy['superseded_acquisition_document']
corpus = D5 / 'corpus-L/pilot-inputs-v2.json'
assert pin(corpus) == api['corpus'] == policy['logical_corpus']
doc = read(corpus)
assert [s['length'] for s in doc['tests']] == [14, 13, 14]
old_offer = read(OLD / 'root/prospective-whole-offer-v1.json')
python = Path(old_offer['python']['path'])
assert pin(python) == old_offer['python']
old_protocol = read(OLD / 'root/protocol-v1.json')
limits = old_protocol['limits']
scientific = old_protocol['scientific_limits']
tree = ast.parse(entry.read_bytes(), filename=str(entry))
call = next(n.value for n in tree.body if isinstance(n, ast.Assign)
            and any(isinstance(t, ast.Name) and t.id == 'LIMITS' for t in n.targets))
assert isinstance(call, ast.Call) and isinstance(call.func, ast.Name) and call.func.id == 'dict'
assert {k.arg: ast.literal_eval(k.value) for k in call.keywords} == scientific == api['limits']
sources = sorted(RUNTIME.glob('*.py')) + [entry] + [R / n for n in names]
checks = []
for source in sources:
    parsed = ast.parse(source.read_bytes(), filename=str(source))
    compile(parsed, str(source), 'exec')
    checks.append(dict(path=str(source), AST_and_unused_compile=True))
assert len(sources) == 33
norms = [pin(B.parent.parent / 'docs/basic-tiling-algorithm.md'),
         pin(B.parent / 'gcts-batch-20261020/publisher/docs/basic-tiling-algorithm.md')]
assert norms == old_offer['normative_references']
native_root = D5 / 'implementation-B/recovered/and-support'
native = dict(template_path=str(native_root / 'fixed-native-inputs/proof-boundary-001.json'),
              micro_path=str(native_root / 'fixed-native-inputs/proof-boundary-microcode-001.json.gz'),
              executable_path=str(native_root / 'Native-runtime/boundary-oracle-v2'))
files = sources + [api_path, handoff_path, policy_path, abstention_path, acquisition,
                  corpus, python, native_root / 'Native-runtime/boundary_oracle.cpp']
files += [Path(p) for p in native.values()]
rows = [pin(p) for p in sorted(set(files))]
assert len(rows) == 44
protocol = dict(old_protocol)
protocol.update(schema='exact-prefix-saturated-hint-protocol-v1',
    status='FROZEN_REQUIRES_FRESH_WHOLE_PLAN_REVIEWS_AND_ONCE_GRANTS',
    ordering_policy=pin(policy_path), abstention_policy=pin(abstention_path),
    normative_references=norms,
    change='Only _expand and VERSION differ from D11. A cluster whose conclusion is already an exact formula in the incoming actual completed primitive prefix abstains before expansion. The full primitive fallback, including repeated derivations, remains.',
    source='All28 runtime and4 custodian Sources byte-identical D11. v10/API/B handoff, inherited D11 ordering policy, new abstention policy and original acquisition document make44 closure rows. Original D8 L handoff remains separate verifier provenance. Initial Source reviews are not whole-plan approval.',
    abstention='A general ordering preference filter, with no target-name/route tuning, formula normalization, inference rule, graph pruning or point candidate novelty. A present conclusion does not prove intermediate steps useless. Exact ordinary formula AST equality is bounded by the unchanged primitive prefix limit.',
    actual_context='SC supplies its actual primitive path; point hints supply the original contiguous completed command/guard prefix. No reference proof or hypothetical future prefix supplies the novelty condition. Remaining proposals retain the original Host actual-context checks and exact primitive keys.',
    costs='All original cold acquisition/compiler/reference/word/marking/Native registry/search/context/final-proof/output/custody costs remain charged. Abstained proposals avoid deep copy and expansion/Host work; that is part of the changed algorithm and must be measured. No phase timing or saturation counter was added. Nested clocks are not disjoint.',
    search_time='Original cooperative2s/600 attempts includes Graph construction/snapshots/audits and proposal work. Callers retain their checkpoints before the finite prefix scan; operations/cleanup can overshoot. No clock, quota, audit or point preference change.',
    baseline_scope='Same fixed three-case development cohort and six arm orders. Follow-up is informed by disclosed D11 failure; it is not a blind or held-out benchmark, strongest ATP comparison, causal phase profile or statistical speedup study.',
    execution='Three fresh sequential full cold case jobs; all agents tools idle during timed actuals. No supplied proof route, reused library/result/prefix/grant, target weakening or outcome-dependent retry. Fresh exact whole Source/plan reviews and once grants required.',
    limitation='Point novelty is a subsequent separate experiment. First-receptor zeros may persist. No predicted proof recovery, resource fit, speedup, new theorem or trained RL benefit.',
    previous_turn='PROGRESS: D11 all18 searches returned in3admitted jobs,205placements/24audits/144wordcontrols. SC80packets/72ordering changes did not help; only repeated conventionalS0 proof qualified. Published/liveverified5d3887b5eef3e2fbd16ff6f3585f33d663bcac6b. D12Source and conditional initial reviews are prepared; no D12actual yet.')
protocol_path = R / 'protocol-v1.json'
save(protocol_path, protocol)
plans = []
for spec in doc['tests']:
    actual = B / 'actual' / spec['id']
    assert not actual.exists() and not Path(str(actual) + '.observer').exists()
    plan = dict(schema='proof-search-case-once-plan-v1',
        experiment='exact-prefix-saturated-hint-v1', case_id=spec['id'],
        actual_dir=str(actual), runtime_dir=str(RUNTIME),
        runner_path=str(R / 'run_case_once_v3.py'), observer_path=str(R / 'observe_case_once_v2.py'),
        worker_path=str(R / 'case_worker_v1.py'), entry_path=str(entry),
        control_path=str(R / 'independent_countermodel_v1.py'), input_path=str(corpus),
        modules=api['roles'], native=native, python=pin(python), files=rows,
        limits=limits, experiment_limits=scientific, protocol=pin(protocol_path),
        ordering_policy=pin(policy_path), abstention_policy=pin(abstention_path),
        superseded_acquisition=pin(acquisition),
        authority='No execution from plan; exact fresh reviewed Root once grant required.',
        trusted_runtime='Pinned isolated CPython/fixed Sources; nonhostile reproducible custodian, no adversarial or OS real-time guarantee.',
        old_qualifications='D11 and older cohorts, failures, policies and consumed grants remain immutable. No rescue, outcome-dependent retry or prefix adoption.')
    path = R / ('plan-' + spec['id'] + '-v1.json')
    save(path, plan)
    plans.append(pin(path))
offer = dict(schema='saturated-hint-whole-offer-v1', plans=plans, files=rows,
    protocol=pin(protocol_path), ordering_policy=pin(policy_path), abstention_policy=pin(abstention_path),
    superseded_acquisition=pin(acquisition), normative_references=norms, python=pin(python),
    initial_Source_reviews=initial['reviews'], source_AST_checks=checks,
    expected_case_jobs=3, expected_explicit_arm_outcomes=18, scientific_calls=0,
    new_actuals=0, new_grants=0, old_grants_remaining=0,
    resource_fit='UNMEASURED; actual whole admission decisive.',
    readiness='PENDING_FRESH_WHOLE_SOURCE_PLAN_REVIEWS_AND_ROOT_ONCE_GRANTS')
save(R / 'prospective-whole-offer-v1.json', offer)
print(json.dumps(dict(offer=pin(R / 'prospective-whole-offer-v1.json'), plans=plans,
                     files=len(rows), Source_AST_checks=len(checks), new_actuals=0, new_grants=0)))
