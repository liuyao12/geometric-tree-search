"""Package complete saved bytes and one isolated reader insertion; no science calls."""
from pathlib import Path
import hashlib,io,json,subprocess,tarfile

B=Path(__file__).resolve().parent.parent
D11=B.parent/'gcts-ordering-proof-pilot-20261020'
D10=B.parent/'gcts-cutoff-proof-pilot-20261020'
D9=B.parent/'gcts-proof-memory-pilot-20261020'
D8=B.parent/'gcts-word-point-proof-pilot-20261020'
D5=B.parent/'gcts-proof-search-pilot-20261020'
P=B.parent/'gcts-batch-20261020/publisher'
D=P/'docs/research/gcts-rl-renewal/conditional-inventory'
OUT=B/'publication'
PREFIX='novel-cluster-search'

def sha(raw):return hashlib.sha256(raw).hexdigest()
def pin(path):
    raw=path.read_bytes();return dict(file=path.name,bytes=len(raw),sha256=sha(raw))
def read(path):
    assert '.partial' not in path.name
    return json.loads(path.read_bytes())
def save(path,value):path.write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')

summary=read(B/'root/passive-actual-assessment-v1.json')
assert summary['resource_admitted_case_jobs']==3 and summary['resource_rejected_case_jobs']==0
assert summary['admitted_point_placement_attempts']==169 and summary['admitted_complete_point_domain_audits']==24
reviews=[(B/'review-C/typed-saturated-hint-actual-scientific-review-v1.json',PREFIX+'-review-C.json'),
         (B/'verification-L/typed-saturated-hint-resource-custody-review-v1.json',PREFIX+'-review-L.json')]
for source,name in reviews:
    review=read(source);assert review['review_passed'] and all(x['passed'] for x in review['checks'])
    (OUT/name).write_bytes(source.read_bytes())

reader=D/'reader.html';before=reader.read_bytes()
assert sha(before)=='b92f5d1d1fd7a6c7959c70b4e9d57a337f39a1868f693d9d3b504143052d1514'
insert=('<section id="novel-cluster-update" class="panel"><h2>Declining redundant hints recovers the conventional proof</h2>'
        '<p><a href="novel-cluster-search.html#ordering">Read the exact-prefix novelty experiment</a>. '
        'All eighteen bounded searches return in three resource-admitted jobs. S0 and SC find the same fourteen-line proof through identical candidate ordering and primitive steps. '
        'This repairs the earlier regression without demonstrating useful cluster acceleration; all point searches remain budget unknown. Inspect both certificates, their colored markings and the reviewed evidence.</p></section>\n').encode()
offset=before.index(b'<section id="cluster-ordering-update"')
after=before[:offset]+insert+before[offset:]
assert after.replace(insert,b'',1)==before
(B/'root/reader-before-publication.html').write_bytes(before)
reader.write_bytes(after)
delta=dict(schema='novel-cluster-reader-exact-insertion-v1',path=str(reader),offset=offset,
           inserted_bytes=len(insert),inserted_text=insert.decode(),
           before=dict(bytes=len(before),sha256=sha(before)),after=dict(bytes=len(after),sha256=sha(after)),
           deleting_exact_insertion_recovers_prior_body=True)
save(B/'root/reader-publication-delta-v1.json',delta)

excluded={'archive-scan-v1.json','Root-final-milestone-v1.json','Root-next-stage-handoff-v1.json',
          'ordering-hint-next-assessment-v1.json'}
paths={p for p in B.rglob('*') if p.is_file() and 'publication' not in p.relative_to(B).parts
       and 'publication-C' not in p.relative_to(B).parts and p.name not in excluded}
offer=read(B/'root/prospective-whole-offer-v1.json');omitted=[]
for row in offer['files']:
    path=Path(row['path'])
    if path==Path(offer['python']['path']):
        omitted.append(dict(pin=row,reason='Pinned isolated trusted CPython binary not redistributed; all research Sources and Native assets are included.'))
    else:paths.add(path)
paths.update([D11/'implementation-B/proof_search_pilot_v9.py',D11/'implementation-B/API-v1.json',
              D11/'implementation-B/handoff-v1.json',D11/'root/protocol-v1.json',
              D11/'root/passive-actual-assessment-v1.json',D11/'root/initial-passive-actual-join-v1.json',
              D11/'publication/cluster-ordering-search-data.json',
              P/'docs/research/gcts-rl-renewal/conditional-inventory/cluster-ordering-search-manifest.json',
              D10/'implementation-B/proof_search_pilot_v8.py',D10/'implementation-B/API-v1.json',
              D10/'root/protocol-v1.json',D10/'root/passive-actual-assessment-v1.json',
              D9/'implementation-B/proof_search_pilot_v7.py',D9/'implementation-B/API-v1.json',
              D9/'implementation-B/handoff-v1.json',D9/'implementation-B/cutoff-retention-next-assessment-v1.json',
              D9/'root/protocol-v1.json',D9/'root/passive-actual-assessment-v1.json',
              D8/'implementation-B/word_point_model_v1.py',D8/'verification-L/word_point_reference_verifier_v1.py',
              D8/'verification-L/API-v1.json',D8/'verification-L/handoff-v1.json',
              D8/'verification-L/manual-correspondence-v1.json',D8/'verification-L/declarative-diagnostic-bank-v1.json',
              P/'docs/basic-tiling-algorithm.md'])
records=[];bodies=[];partials=[]
for path in sorted(paths):
    assert not path.is_symlink()
    if path.is_relative_to(B):name=path.relative_to(B).as_posix()
    elif path.is_relative_to(D11):name='dependencies/D11/'+path.relative_to(D11).as_posix()
    elif path==P/'docs/research/gcts-rl-renewal/conditional-inventory/cluster-ordering-search-manifest.json':name='dependencies/D11/publication/cluster-ordering-search-manifest.json'
    elif path.is_relative_to(D10):name='dependencies/D10/'+path.relative_to(D10).as_posix()
    elif path.is_relative_to(D9):name='dependencies/D9/'+path.relative_to(D9).as_posix()
    elif path.is_relative_to(D8):name='dependencies/D8/'+path.relative_to(D8).as_posix()
    elif path.is_relative_to(D5):name='dependencies/D5/'+path.relative_to(D5).as_posix()
    elif path==P/'docs/basic-tiling-algorithm.md':name='reference/basic-tiling-algorithm.md'
    else:raise ValueError('undeclared archive path '+str(path))
    raw=path.read_bytes();row=dict(file=name,bytes=len(raw),sha256=sha(raw))
    if '.partial' in path.name:partials.append(row)
    else:records.append(row);bodies.append((name,raw))
manifest=dict(schema='novel-cluster-search-evidence-archive-v1',files=records,
              partial_raw_metadata_only=partials,omitted_trusted_runtime=omitted,
              actual_case_attempts=3,resource_admitted_case_attempts=3,resource_rejected_case_attempts=0,
              complete_actual_and_observer_files=42,observed_searches=18,observed_cluster_skips=0,
              admitted_searches=18,admitted_cluster_skips=0,admitted_point_placements=169,admitted_point_audits=24,
              qualified_recipient_certificates=2,distinct_recipient_statements=1,recipient_engine='S0 conventional and SC cluster-guided symbolic searches; exact same primitive proof',
              new_theorem_or_point_proof=False,scientific_comparison_complete=True,scientific_calls_during_packaging=0,
              reproduction='Consumed grants cannot be reused. Reproduction requires new paths, exact reviewed Source/plans and fresh one-use grants. Full fixed-dependency Sources and all complete case evidence are included; trusted Python binary is explicitly omitted.',
              scope='All three fresh D12 jobs pass admission and all18 bounded arms return. Exact-prefix abstention plus inherited hint-only policy; registry remains UNKNOWN/unadmitted/usableempty. Two accepted records contain one known proof, no useful positive order difference or new theorem. Original D8 L handoff is inherited verifier provenance. B assessment is posthoc passive diagnosis, not a new experiment. Full D12 Sources and complete actuals are included; historical D11 raw actuals remain in the previous published evidence archive pinned by its included manifest. Publication-only review is outside this snapshot.')
mb=(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode()
archive=OUT/(PREFIX+'-evidence.tar.gz')
assert not archive.exists()
with tarfile.open(archive,'w:gz',compresslevel=9) as stream:
    for name,raw in bodies+[('MANIFEST.json',mb)]:
        item=tarfile.TarInfo(name);item.size=len(raw);item.mode=0o644;item.mtime=0
        stream.addfile(item,io.BytesIO(raw))
with tarfile.open(archive,'r:gz') as stream:
    assert len(stream.getmembers())==len(records)+1
    for row in records:
        raw=stream.extractfile(row['file']).read()
        assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
    assert stream.extractfile('MANIFEST.json').read()==mb
scan=dict(schema='novel-cluster-archive-complete-byte-scan-v1',archive=pin(archive),members=len(records)+1,
          payload_bytes=sum(row['bytes'] for row in records),all_members_byte_checked=True,
          partial_raw_metadata_only=partials,omitted_trusted_runtime=omitted)
save(B/'root/archive-scan-v1.json',scan)
for path in sorted(OUT.glob(PREFIX+'*')):(D/path.name).write_bytes(path.read_bytes())
owned=sorted(p for p in D.glob(PREFIX+'*') if p.name!=PREFIX+'-manifest.json')+[reader]
assert len(owned)==7
parent=subprocess.check_output(['git','rev-parse','HEAD'],cwd=P,text=True).strip()
public=dict(schema='novel-cluster-search-publication-manifest-v1',source_parent_commit=parent,
            files=[pin(p) for p in owned],archive_scan=scan,reader_delta=delta,
            conclusion='Three admitted jobs,18 searches/zero skips,169 point placements/24 audits/144 controls. S0 and SC produce the same14row known proof with identical positive candidate ordering and paths. SC8 packets/2 negative ordering changes, no point packets. Repair recovers baseline; no new theorem, useful ordering acceleration or trainedRL.')
save(D/(PREFIX+'-manifest.json'),public)
print(json.dumps(scan))
