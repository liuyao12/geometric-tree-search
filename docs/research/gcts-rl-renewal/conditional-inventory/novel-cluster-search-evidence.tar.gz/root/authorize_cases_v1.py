"""Exact Root metadata preflight and fresh single-use grants; no science calls."""
from pathlib import Path
import hashlib
import json
import sys

B = Path(__file__).resolve().parent.parent
R = B / 'root'

def pin(path):
    p = Path(path).resolve()
    assert '.partial' not in p.name
    raw = p.read_bytes()
    return dict(path=str(p), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write('\n')

def contains(value, expected):
    if value == expected:
        return True
    if isinstance(value, dict):
        return any(contains(v, expected) for v in value.values())
    if isinstance(value, list):
        return any(contains(v, expected) for v in value)
    return False

assert len(sys.argv) == 5
offer_path = R / 'prospective-whole-offer-v1.json'
offer = json.loads(offer_path.read_bytes())
for row in offer['files'] + offer['plans'] + [offer['protocol']] + offer['normative_references']:
    assert pin(row['path']) == row
assert len(offer['files']) == 44 and len(offer['plans']) == 3
expected_names = ['typed-saturated-hint-Source-review-v1.json',
    'typed-saturated-hint-Source-ABI-review-v1.json',
    'typed-saturated-hint-whole-prospective-Source-review-v1.json',
    'typed-saturated-hint-whole-plan-Source-ABI-review-v1.json']
reviews = []
for argument, name in zip(sys.argv[1:], expected_names):
    path = Path(argument).resolve()
    assert path.name == name and path.is_relative_to(B)
    receipt = json.loads(path.read_bytes())
    assert receipt['review_passed'] is True and receipt['checks']
    assert all(c['passed'] for c in receipt['checks'])
    if len(reviews) >= 2:
        assert contains(receipt, pin(offer_path)), 'whole review must bind exact offer'
    reviews.append(pin(path))
assert reviews[:2] == offer['initial_Source_reviews']
preflight = dict(schema='Root-saturated-hint-search-preflight-v1',
    offer=pin(offer_path), protocol=offer['protocol'], reviews=reviews,
    review_passed=True, new_uses=3, old_grants_remaining=0, goal_status='active',
    previous_turn='PROGRESS: D11 completed18 searches in3admitted jobs and was liveverified at5d3887b. The heuristic failed to help. This separate followup tests generic saturated-hint abstention; no result predicted.',
    authority='Three fresh serial cold attempts only; agents tools idle during actuals. No outcome-dependent retry or old grant/prefix/library adoption.',
    conformance='D11 ordering-only Native UNKNOWN/acquisition override and new literal actual-prefix abstention both pinned. No block inference, pruning or point novelty. Full primitive fallback/global dead-forced-earliest-generation/rollback/contextual Host/final Host-region-Native blocks=[] gates unchanged.44closure/32copies/firsttwo fullaudits/48wordcontrols must actually return.',
    scope='Reachable aligned complete-word Native/point adaptation only. No arbitrary partial/shifted word states, physical universal Wang, trainedRL, practical Turtle/Penrose plane construction or wholeprogram completion claim.',
    partial_files_parsed=False, scientific_calls=0)
save(R / 'Root-preflight-v1.json', preflight)
for row in offer['plans']:
    plan = json.loads(Path(row['path']).read_bytes())
    assert not Path(plan['actual_dir']).exists()
    assert not Path(plan['actual_dir'] + '.observer').exists()
    grant = dict(schema='Root-fresh-saturated-hint-case-grant-v1',
        authorized=True, uses=1, no_retry=True, case_id=plan['case_id'],
        actual_dir=plan['actual_dir'], plan_sha256=row['sha256'],
        runner_sha256=pin(plan['runner_path'])['sha256'],
        observer_sha256=pin(plan['observer_path'])['sha256'],
        review_passed=True, reviews=reviews,
        root_preflight=pin(R / 'Root-preflight-v1.json'), old_grants_reused=False)
    save(R / ('grant-' + plan['case_id'] + '-v1.json'), grant)
print(json.dumps(dict(preflight=pin(R / 'Root-preflight-v1.json'), fresh_grants=3, actuals=0)))
