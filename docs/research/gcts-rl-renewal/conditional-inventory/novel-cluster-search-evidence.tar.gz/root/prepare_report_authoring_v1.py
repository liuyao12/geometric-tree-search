"""Author a passive report builder and HTML; no research imports or execution."""
from pathlib import Path

B = Path(__file__).resolve().parent.parent
OLD = B.parent / 'gcts-ordering-proof-pilot-20261020'
OUT = B / 'publication'
OUT.mkdir(exist_ok=True)
s = (OLD / 'root/build_ordering_report_v1.py').read_text()
s = s.replace('cluster-ordering-search', 'novel-cluster-search')
s = s.replace("prior_path=B.parent/'gcts-cutoff-proof-pilot-20261020/root/passive-actual-assessment-v1.json'",
              "prior_path=B.parent/'gcts-ordering-proof-pilot-20261020/root/passive-actual-assessment-v1.json'")
s = s.replace("engine='conventional symbolic control' if a['method']=='symbolic' else 'point Graph search'",
              "engine='cluster-guided symbolic search' if a['id']=='SC' else 'conventional symbolic control' if a['method']=='symbolic' else 'point Graph search'")
a = s.index("assert summary['accepted_recipient_proofs']==1")
z = s.index('\ndef prose_spacing', a)
s = s[:a] + '''assert summary['accepted_recipient_proofs']==2
assert [a['arm'] for a in totals[0]['accepted_recipient_proofs']]==['S0','SC']
assert [a['rows'] for a in totals[0]['accepted_recipient_proofs']]==[14,14]
assert proofs[0]['proof']==proofs[1]['proof']
assert len(pointrows)==12 and all(p['status']=='unknown_search_budget' for p in pointrows)
assert summary['searches_returned']==18 and summary['cluster_arms_skipped']==0
assert summary['admitted_point_placement_attempts']==169 and summary['admitted_complete_point_domain_audits']==24
assert len(ordering)==9 and sum(o['successful_proposals'] for o in ordering)==8
assert sum(o['symbolic_order_changes'] or 0 for o in ordering)==2
summary.update(ordering_only_policy=True,exact_prefix_abstention=True,registered_ground_blocks=False,successful_ordering_proposals=8,literal_symbolic_order_changes=2,accepted_recipient_certificates=2,distinct_recipient_statements=1,new_theorem=False)
save(B/'root/passive-actual-assessment-v1.json',summary)
symbolic_comparison=[]
for spec in corpus['tests']:
    previous_path=B.parent/'gcts-ordering-proof-pilot-20261020/actual'/spec['id']/'result.json'
    previous=read(previous_path)['scientific_result']['tests'][0]
    current=read(B/'actual'/spec['id']/'result.json')['scientific_result']['tests'][0]
    before=next(a for a in previous['arms'] if a['id']=='SC')
    after=next(a for a in current['arms'] if a['id']=='SC')
    baseline=next(a for a in current['arms'] if a['id']=='S0')
    symbolic_comparison.append(dict(title=spec['title'],case_id=spec['id'],previous_SC_attempts=before['search']['metrics']['attempts'],previous_SC_accepted=before['native_proof_accepted'],current_SC_attempts=after['search']['metrics']['attempts'],current_SC_accepted=after['native_proof_accepted'],current_S0_attempts=baseline['search']['metrics']['attempts'],current_S0_accepted=baseline['native_proof_accepted'],same_accepted_primitive_proof=after['search']['proof'] is not None and after['search']['proof']==baseline['search']['proof'],previous_source=pin(previous_path)))
headline="The hint regression is repaired; useful cluster acceleration remains unproved."
conclusion="All 18 searches returned in three resource-admitted jobs. S0 and SC independently produce the same 14-line proof in 14 extensions. The positive SC trace has four successful packets and no changed candidate ordering. All twelve point searches remain budget unknown. This is recovery of baseline behavior, not a new theorem or a GCTS/RL advantage."
assessment=[
    'Only the common expansion path changes: a cluster whose exact conclusion already appears in the actual completed primitive prefix declines to supply an ordering preference. All repeated derivations remain ordinary primitive alternatives. The point candidate order, complete graph scheduler, rollback, budgets and proof gates remain unchanged.',
    'The first target now has two accepted certificates, one from S0 and one from SC. They are the same fourteen-row primitive proof of one already-known statement. SC uses the baseline candidate ordering throughout this positive trace. Four successful proposal packets therefore do not demonstrate useful guidance or realized cluster execution.',
    'The previous SC run reached 600 extensions without a proof on the first target. In this new run it reaches the ordinary control result in 14. This disclosed development repair removes a specific regression; it does not establish statistical speedup, held-out transfer or superiority over existing proof search.',
    'All twelve point searches remain budget UNKNOWN: 169 actual placement events and 24 exhaustive domain audits. The six cluster-enabled point arms record zero successful packets and zero activations. This change did not add the separate point novelty order needed to test the missing-receptor hypothesis.',
    'Eight successful symbolic proposal packets were recorded overall, with two literal candidate-order changes, both in the negative control. No saturation counter or phase profile was added. Absence of redundant packets follows from the Source condition plus saved-prefix joins, not from an invented rejection metric.',
    'All 144 word-reference controls and complete model correspondence checks belong to admitted jobs. Certified failure markings remove twelve initial incidences in each paired marked comparison per case. These shallow exclusions are not a learned multiscale proof abstraction.',
    'All ground registry queries remain Native UNKNOWN, unadmitted, with usable empty. The seven, eleven and seven grounded templates remain eligible only as actual-context-checked primitive preferences under the inherited declared policy. No inference block, trained RL policy or physical universal Wang qualification is introduced.',
    'The next separate test should give all four point arms the same general formula-novelty preference among candidates at the Graph-selected branch point, retain every primitive alternative and the mandatory scheduler, and measure whether useful receptors become available. This is a prospective heuristic, with no predicted recovery or advantage.',
    'The full program remains practical boundary tiling, hierarchical receptor and lemma inventories, learned proposal policies, automated arithmetic and symbolic Hilbert geometry, and honest conventional benchmarks. Turtle/Penrose plane constructions and the universal Wang bridge remain unfinished.'
]
next_path=B/'implementation-B/novelty-outcome-next-assessment-v1.json'
report=dict(schema='novel-cluster-search-report-v1',headline=headline,conclusion=conclusion,proof_scope='Two independent search records contain the same fourteen-line primitive certificate for one recipient statement: S0 and SC. Choose either to inspect its exact command and guard tiles, formulas and English readings. These are two certificates of the same known theorem, not two new theorems. The three elementary donor proofs follow from the first admitted cold job.',cases=cases,proofs=proofs,tiles=tiles,actual_summary=summary,comparison=comparison,comparison_source=pin(prior_path),symbolic_comparison=symbolic_comparison,ordering=ordering,assessment=assessment,next_assessment=read(next_path),next_assessment_source=pin(next_path),ordering_diagnostic_text='The filter repairs the first symbolic regression, but the accepted SC proof follows the same candidate ordering and primitive path as S0. Point proposals remain absent. The passive diagnosis below distinguishes exact saved-trace evidence, Source arguments and unmeasured costs; a separate point-ordering experiment is proposed.',review_summary='Initial Source and whole-plan reviews preceded three fresh serial cold jobs. Independent scientific and resource/custody reviews classify complete records under the inherited hint-only policy plus the exact-prefix abstention rule. Registry UNKNOWN, proof acceptance, bounded experiment completion and resource admission remain separate. No scientific replay occurred outside actuals.')
''' + s[z:]
(B / 'root/build_novel_report_v1.py').write_text(s)

h = (OLD / 'publication/cluster-ordering-search.html').read_text()
h = h.replace('cluster-ordering-search', 'novel-cluster-search').replace('cluster-ordering-update', 'novel-cluster-update')
h = h.replace('Do acquired cluster hints help? — GCTS research', 'Declining redundant cluster hints — GCTS research')
h = h.replace('Do acquired cluster hints help proof search?', 'Declining redundant cluster hints repairs a regression')
h = h.replace('proof-cutoff-search.html#outcome', 'cluster-ordering-search.html#ordering').replace('Previous lifecycle experiment', 'Previous negative comparison')
h = h.replace('Three fresh cold cases test whether automatically acquired lemma clusters can guide primitive proof search. All six methods now run. The first complete comparison gives a negative result and a concrete diagnostic for the next experiment.', 'Three fresh cold cases test one general repair: a cluster with an already-derived conclusion declines to influence ordering. The first symbolic target is recovered, with the same proof and candidate ordering as the conventional control. Useful GCTS guidance remains unproved.')
h = h.replace('Separate context-checked primitive ordering hints from new inference blocks; retain the full primitive fallback and final proof gates.', 'Decline a redundant cluster preference using the actual proof prefix; retain every primitive fallback move and final proof gate.')
h = h.replace('This experiment changes only the declared ordering eligibility after bounded registry UNKNOWN.', 'The inherited policy allows bounded registry UNKNOWN only for ordering preferences. This follow-up adds exact-prefix abstention before expansion; no block is registered.')
start = h.index('<section id="carrier">')
h = h[:start] + '<section id="repair"><h2>One preference filter, with ordinary fallback intact</h2><div class="cards"><article class="card"><h3>Read the actual prefix</h3><p>Use only completed earlier primitive rows. Compare the cluster conclusion by exact formula syntax.</p></article><article class="card"><h3>Decline a repeated conclusion</h3><p>If that conclusion is already present, return no hint from this instance. Its primitive derivation remains an available ordinary continuation.</p></article><article class="card"><h3>Retain proof checking</h3><p>Other hints still require actual-context validation. Every found proof still passes all original primitive checks.</p></article></div><p class="warning">A repeated conclusion can have useful intermediate derivations. Declining its preference is an unproved utility heuristic. Completeness relies on retaining the full primitive fallback.</p></section>' + h[start:]
h = h.replace('Point placements, previous two arms / current four arms', 'Point placements, previous / current, four arms each')
a = h.index('<p>The previous <a href="cluster-ordering-search.html#ordering">')
z = h.index('</p>', a) + 4
h = h[:a] + '<p>The <a href="cluster-ordering-search.html#ordering">previous negative comparison</a> and this follow-up both execute all four point arms and all six methods per case. The follow-up changes one disclosed utility heuristic. These are single cold development cohorts; memory and timed-prefix differences are observations without phase attribution or a statistical speedup claim.</p>' + h[z:]
a = h.index('<section id="ordering">')
z = h.index('<section id="results">', a)
h = h[:a] + '<section id="ordering"><h2>Recovered baseline behavior</h2><div class="scroll"><table><thead><tr><th>Case</th><th>Previous SC attempts / proof</th><th>Current SC attempts / proof</th><th>Current S0 attempts / proof</th><th>Same accepted primitive proof?</th></tr></thead><tbody id="symbolic-comparison"></tbody></table></div><p>On the first target, the current S0 and SC traces use identical candidate ordering and the same accepted primitive proof. This is recovery from the old heuristic regression. Two accepted search records prove one already-known statement.</p><h3>Where did cluster guidance reach?</h3><div class="scroll"><table><thead><tr><th>Case / arm</th><th>Eligible instances</th><th>Successful proposal packets</th><th>Changed symbolic orderings</th><th>Point activated packets</th><th>Attempts / result</th></tr></thead><tbody id="ordering-rows"></tbody></table></div><p class="small">Eight symbolic proposal packets were recorded: four on the first target, none on equality, four on the negative control. The only two recorded candidate-order changes occur on the negative control. The six point-cluster arms record zero packets and activations. An ordering change is a literal trace comparison, not a count of executed clusters.</p><p id="ordering-diagnostic"></p><p class="warning">No saturation counter or phase timing was added. Completed trace joins and the Source condition must be distinguished from unlogged cutoff work. A separate point preference that favors novel formulas is proposed equally for all four point methods; its usefulness is unmeasured.</p><details><summary>Inspect the passive diagnosis and next experiment proposal</summary><pre id="diagnostic-detail"></pre></details></section>' + h[z:]
h = h.replace("function showOrdering(){", "function showOrdering(){el('symbolic-comparison').replaceChildren(...data.symbolic_comparison.map(c=>{const tr=document.createElement('tr');[c.title,c.previous_SC_attempts+' / '+(c.previous_SC_accepted?'accepted':'unknown'),c.current_SC_attempts+' / '+(c.current_SC_accepted?'accepted':'unknown'),c.current_S0_attempts+' / '+(c.current_S0_accepted?'accepted':'unknown'),c.same_accepted_primitive_proof?'Yes':'No accepted pair'].forEach(v=>tr.append(txt('td',v)));return tr}));")
(OUT / 'novel-cluster-search.html').write_text(h)
print('Passive report builder and HTML authored; no scientific calls.')
