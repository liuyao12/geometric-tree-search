"""Independent Source/AST and saved-metadata review only; no research imports."""
from pathlib import Path
import ast
import copy
import difflib
import hashlib
import json

BASE = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
D = BASE / 'research-runs/gcts-novelty-proof-pilot-20261020'
B = D / 'implementation-B'
OLD = BASE / 'research-runs/gcts-ordering-proof-pilot-20261020'

def pin(path):
    p = Path(path)
    assert '.partial' not in p.name
    raw = p.read_bytes()
    return dict(path=str(p), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

def load(path):
    p = Path(path)
    assert p.suffix == '.json' and '.partial' not in p.name
    return json.loads(p.read_bytes())

def verify(row):
    assert pin(row['path']) == row

handoff_path = B / 'handoff-v1.json'
handoff = load(handoff_path)
assert pin(handoff_path)['sha256'].startswith('2d12486c') and pin(handoff_path)['bytes'] == 3248
for key in ['entry', 'api', 'policy', 'patch', 'ast_diff', 'manual', 'manifest', 'model_source', 'verifier_source']:
    verify(handoff[key])
api = load(handoff['api']['path'])
policy = load(handoff['policy']['path'])
manual = load(handoff['manual']['path'])
manifest = load(handoff['manifest']['path'])
for row in manifest['files']:
    verify(row)
verify(api['corpus'])
verify(api['predecessor'])
verify(policy['parent_ordering_policy'])
verify(policy['posthoc_motivation'])
assert api['entry'] == handoff['entry'] == policy['successor']
assert api['abstention_policy'] == handoff['policy']
assert api['policy'] == policy['parent_ordering_policy']
assert api['policy_lineage'] == [policy['parent_ordering_policy'], handoff['policy']]
assert api['predecessor'] == policy['predecessor']
assert api['entry']['sha256'] == 'e33801360f36f51efc99b69278ef0e8cd7d783892dec7fa9763c8f63378c6b93'
assert api['predecessor']['sha256'] == '9c734a91f77c6714d0ed7201dbefcf4e263603a2007261b2667a0ef5b47136a8'
old_path = Path(api['predecessor']['path'])
new_path = Path(api['entry']['path'])
old = old_path.read_text()
new = new_path.read_text()
old_tree = ast.parse(old, filename=str(old_path))
new_tree = ast.parse(new, filename=str(new_path))
compile(old_tree, str(old_path), 'exec')
compile(new_tree, str(new_path), 'exec')
definition_types = (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)
old_defs = {n.name: n for n in old_tree.body if isinstance(n, definition_types)}
new_defs = {n.name: n for n in new_tree.body if isinstance(n, definition_types)}
assert old_defs.keys() == new_defs.keys()
dump = lambda node: ast.dump(node, include_attributes=False)
changed = [name for name in old_defs if dump(old_defs[name]) != dump(new_defs[name])]
assert changed == ['_expand']
unchanged = [name for name in old_defs if name not in changed]
assert len(unchanged) == 28
old_expand = old_defs['_expand']
new_expand = new_defs['_expand']
assert len(new_expand.body) == len(old_expand.body) + 1
assert dump(new_expand.body[2]) == dump(ast.parse("if any(c['formula'] == definition['conclusion'] for c in prefix):\n    return None\n").body[0])
assert [dump(n) for n in new_expand.body[:2] + new_expand.body[3:]] == [dump(n) for n in old_expand.body]
restored_tree = copy.deepcopy(new_tree)
restored_expand = next(n for n in restored_tree.body if isinstance(n, ast.FunctionDef) and n.name == '_expand')
del restored_expand.body[2]
old_version = next(n for n in old_tree.body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'VERSION' for t in n.targets))
new_version = next(n for n in restored_tree.body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'VERSION' for t in n.targets))
new_version.value = copy.deepcopy(old_version.value)
assert dump(restored_tree) == dump(old_tree)
old_fragment = "    definition = instance['definition']; proof = copy.deepcopy(prefix); expansion = []; remap = {}\n"
new_fragment = "    definition = instance['definition']\n    if any(c['formula'] == definition['conclusion'] for c in prefix):\n        return None\n    proof = copy.deepcopy(prefix); expansion = []; remap = {}\n"
assert old.count(old_fragment) == new.count(new_fragment) == 1
inverse = new.replace(new_fragment, old_fragment, 1).replace(
    "VERSION = 'native-point-matched-proof-search-pilot-v10-novel-cluster-conclusions'",
    "VERSION = 'native-point-matched-proof-search-pilot-v9-ordering-only-clusters'", 1)
assert inverse == old
patch = ''.join(difflib.unified_diff(old.splitlines(keepends=True), new.splitlines(keepends=True), fromfile=str(old_path), tofile=str(new_path)))
assert patch.encode() == Path(handoff['patch']['path']).read_bytes()
prior_api = load(OLD / 'implementation-B/API-v1.json')
assert api['roles'] == prior_api['roles'] and api['limits'] == prior_api['limits']
assert api['model_source'] == prior_api['model_source'] and api['verifier_source'] == prior_api['verifier_source']
assert api['corpus'] == prior_api['corpus']
masters = [BASE / 'docs/basic-tiling-algorithm.md', BASE / 'research-runs/gcts-batch-20261020/publisher/docs/basic-tiling-algorithm.md']
assert [pin(p)['sha256'] for p in masters] == ['c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9', 'ca6ee206287bf18b69f88a35d30968312499567755f347a819af4cf49743e7d4']
assert manual['master'] == pin(masters[1])
runtime_path = Path('/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12')
assert pin(runtime_path)['sha256'] == 'b6ea0c2a9bfce48dbf181a53f1ca4f0562d40658b85bf47258e2a88d8f9e3933'
source_review_path = OLD / 'review-C/typed-scientific-delta-Source-review-v1.json'
actual_review_path = OLD / 'review-C/typed-ordering-only-actual-scientific-review-v1.json'
assert pin(source_review_path)['sha256'] == '3ab3ffa3db815cb30f69e080f09d0ebe5319f80282197a5aa2e5cf4da9d5ac94'
assert pin(actual_review_path)['sha256'] == '3cf59e5a1d7f0d3906fd9dbd265d8e7b61a6e6bd56e12876b93591118c9c6648'
assert load(source_review_path)['review_passed'] is load(actual_review_path)['review_passed'] is True

checks = [
    ('exact-one-function-and-version-delta', 'All frozen B artifact/dependency pins independently revalidated. The full raw inverse and exact unified patch reproduce v9. Only _expand differs among29 function/class ASTs;28 unchanged. Removing the one exact membership If and restoring VERSION gives the entire old module AST. Both Sources were AST parsed/unused compiled; neither was imported or called.'),
    ('actual-prefix-and-general-structural-membership', 'The new condition reads instance.definition.conclusion and actual incoming prefix command formulas using exact structural equality in the fixed well-formed ordinary list-AST domain. It has no target/case/family ID, named route, successful reference proof, formula normalization or alpha-equivalence test. SC passes its actual primitive path; point hints pass the unchanged contiguous agreeing C/G prefix. It is a general syntactic preference test, not a new theorem rule.'),
    ('read-only-scope-and-faults', 'The finite prefix scan does not mutate prefix, instances, formulas, library, State, Graph or candidate metadata. It precedes old deepcopy/Host work only for an abstained proposal. Existing caller budget checks remain, no exception catch/reclassification/context cleanup is added, and foreign/Root errors are not treated as proof/pruning. Structural equality has no hostile/custom-object guarantee; claims remain within the pinned valid literal pilot inputs and bounded row limits.'),
    ('fallback-completeness-and-original-search-contract', 'Returning None is the pre-existing unavailable-proposal path. Callers continue other instances and retain every original primitive alternative, including the repeated derivation. Both searches, _point_hint, candidate/guard construction, global DEAD/FORCED/earliest-generation scheduler, degrees, markings and rollback ASTs are identical. The filter does not remove a candidate or certify an exclusion; finite-bound search trajectories may change, while no claim of improved completeness/utility follows.'),
    ('unchanged-authority-and-proof-gates', 'Ground query/status/cost, Native UNKNOWN unadmitted/usable[], separate ordering_instances and hard rejected/unrecognized/Root/foreign fault handling remain exactly D11. Surviving proposals retain old receptor resolution and actual-context Host checking. Compiler empty inventory/no block grammar and donor/essential/final Host/fullregion/fresh Native blocks=[] checks are identical. An abstained saturated template is not a newly admitted lemma or proof shortcut.'),
    ('same-budgets-schema-and-no-point-novelty', 'Exact roles, model/verifier/corpus and all scientific limits equal D11; complete module inverse excludes hidden import/timer/audit/instrumentation changes. Point branch novelty is not implemented. Existing successful proposal/activation counters are unchanged and do not record a saturation-reason count. VERSION identifies the new stage while inherited completion_scope names base D11 ordering policy; fresh protocol must explain this lineage rather than relabel older results.'),
    ('utility-limit-and-cost-fairness', 'A cluster with an already-present conclusion may contain useful intermediate steps or a beneficial alternate derivation; this rule may decline it. No domination theorem, route recovery, time saving, fit or gain is proved. The new scan and avoided expansion validation are part of the changed algorithm under unchanged cooperative clocks. Point first-receptor failures and repeated primitive baseline choices may persist; zero proposals alone cannot diagnose this filter. This is an authored follow-up to disclosed D11 negative data, not blind validation or trainedRL.'),
    ('conditional-policy-and-fresh-Root-obligations', 'Exact abstention9c22 policy inherits ordering57ee and explicitly leaves primitive fallback and authority unchanged. A fresh Root protocol/full closure/plans must pin both policies and the old acquisition override, same cold full cases/arms/schedules/costs/limits, and independent whole reviews before Root once grants/idle execution. This receipt reviews only the scientific Source delta, creates no plan/grant/actual and grants no runtime/publication authority. D11 frozen results remain unchanged.')
]
receipt = dict(schema='typed-saturated-hint-scientific-Source-review-v1', reviewer_identity='/root/recovered_batch_review', review_passed=True, status='PASS_CONDITIONAL_SINGLE_FUNCTION_PREFERENCE_ABSTENTION_FRESH_WHOLE_PLAN_REVIEW_REQUIRED', source_only=True, scientific_calls=0, component_calls=0, logical_replays=0, whole_plan_reviewed=False, actual_execution_authorized=False, grant_authority=False, actual_resource_accepted=False, check_count=len(checks), failed_checks=0, checks=[dict(id=i, passed=True, finding=f) for i,f in checks], entry=api['entry'], predecessor=api['predecessor'], implementation_handoff=pin(handoff_path), API=handoff['api'], abstention_policy=handoff['policy'], parent_ordering_policy=policy['parent_ordering_policy'], artifacts=[pin(p) for p in sorted(B.iterdir()) if p.is_file()], dependency_pins=[api['model_source'], api['verifier_source'], api['corpus'], policy['posthoc_motivation']], normative_references=[pin(p) for p in masters], metadata_parser_runtime=pin(runtime_path), changed_functions=['_expand'], unchanged_function_class_AST_count=28, unchanged_function_classes=unchanged, full_module_AST_inverse_exact=True, full_raw_Source_inverse_exact=True, patch_reproduced=True, inherited_D11_Source_review=pin(source_review_path), inherited_D11_actual_review=pin(actual_review_path), limits=api['limits'], no_point_candidate_novelty=True, no_new_inference_or_pruning=True, actual_usefulness_and_fit='UNMEASURED', required_fresh_Root_joins=['Exact parent ordering policy and acquisition-only override plus new abstention policy in fresh protocol/closure/plans.', 'Same full corpus, three cold donors/case, six arms/schedules, candidate universe, quotas and final proof gates.', 'Independent whole reviews and fresh Root once grants/all-agent idle barrier before Root-only actuals.'], partial_policy='No partial content read, parsed, projected or admitted.', manual_scope='Independent conditional Source/manual preference/fallback argument, not mechanized soundness, runtime conformance or performance evidence.', tools_stopped=True)
target = D / 'review-C/typed-saturated-hint-Source-review-v1.json'
with target.open('x') as stream:
    json.dump(receipt, stream, indent=2)
    stream.write('\n')
print(json.dumps(pin(target)))
