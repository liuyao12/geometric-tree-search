"""Passive joins over complete saved JSON only; no research imports or replay."""
from pathlib import Path
import collections
import hashlib
import json

BASE = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
D = BASE / 'research-runs/gcts-novelty-proof-pilot-20261020'
OLD = BASE / 'research-runs/gcts-ordering-proof-pilot-20261020'
D8 = BASE / 'research-runs/gcts-word-point-proof-pilot-20261020'

def pin(path):
    p = Path(path)
    assert '.partial' not in p.name
    b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())

def read(path):
    p = Path(path)
    assert p.suffix == '.json' and '.partial' not in p.name
    return json.loads(p.read_bytes())

def verify(row):
    assert pin(row['path']) == {k: row[k] for k in ('path', 'bytes', 'sha256')}

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode()

offer_path = D / 'root/prospective-whole-offer-v1.json'
offer = read(offer_path)
assert len(offer['files']) == 44
for row in offer['files'] + offer['plans'] + [offer['protocol']] + offer['normative_references']:
    verify(row)
corpus = read(next(r['path'] for r in offer['files'] if r['sha256'] == '2f206ef004c4d723f862ee36f08355816c5264a5809340be9787331d82d33cd6'))
bank = read(D8 / 'verification-L/declarative-diagnostic-bank-v1.json')
control_ids = [r['id'] for r in bank['controls']]
external_path = D / 'root/external-tool-observer-v1.json'
external = read(external_path)
assert external['all_handles_terminal'] is True and len(external['cases']) == 3
cases = [s['id'] for s in corpus['tests']]
expected = [dict(S0=14, SC=14, P00=20, P01=20, P10=20, P11=19),
            dict(S0=600, SC=600, P00=10, P01=11, P10=7, P11=17),
            dict(S0=600, SC=600, P00=11, P01=17, P10=7, P11=10)]
expected_peaks = [853262336, 782876672, 810958848]
expected_instances = [7, 11, 7]
expected_proposals = [4, 0, 4]
expected_order_changes = [0, 0, 2]
observations = []
actual_pins = []
grant_pins = []
status_total = collections.Counter()
point_total = audit_total = proposal_total = changed_order_total = 0
for index, cid in enumerate(cases):
    path = D / 'actual' / cid
    observer_path = D / 'actual' / (cid + '.observer') / 'observer.json'
    result_path = path / 'result.json'
    rp = pin(result_path)
    record = read(result_path)
    s = record['scientific_result']
    assert len(s['tests']) == 1
    t = s['tests'][0]
    header = read(path / 'worker-header.json')
    terminal = read(path / 'terminal.json')
    observer = read(observer_path)
    tool = next(r for r in external['cases'] if r['case_id'] == cid)
    plan_path = D / 'root' / ('plan-' + cid + '-v1.json')
    plan = read(plan_path)
    grant_path = D / 'root' / ('grant-' + cid + '-v1.json')
    grant = read(grant_path)
    consumed = read(path / 'CONSUMED.json')
    grant_pins.append(pin(grant_path))
    assert record['case_id'] == s['selected_case_id'] == header['case_id'] == terminal['case_id'] == observer['case_id'] == cid
    assert consumed['case_id'] == grant['case_id'] == cid and consumed['uses'] == grant['uses'] == 1
    assert consumed['plan_sha256'] == grant['plan_sha256'] == pin(plan_path)['sha256']
    assert consumed['grant_sha256'] == pin(grant_path)['sha256']
    assert grant['authorized'] is grant['no_retry'] is True and grant['old_grants_reused'] is False
    for row in grant['reviews']:
        verify(row)
    assert s['inputs'] == corpus and s['limits'] == plan['experiment_limits']
    assert s['job_record_complete'] is s['all_six_searched'] is s['scientific_complete'] is s['complete'] is True
    assert s['resource_accepted'] is False
    assert s['registry_native_admitted'] is s['registered_inference_used'] is False
    assert s['ordering_hints_enabled'] is True
    assert s['ordering_policy']['id'] == 'CONTEXT_CHECKED_PRIMITIVE_ORDERING_ONLY_V1'
    assert s['ordering_policy']['native_registry_required_for_ordering'] is False
    assert record['status'] == header['status'] == 'COMPLETE' and record['error'] is None
    assert record['first_Root_fault'] is header['first_Root_fault'] is False
    assert terminal['header_valid'] is True and terminal['process_exit_code'] == 0
    assert header['result'] == terminal['result'] == rp and terminal['header'] == header
    assert record['source_unchanged'] is terminal['sources_unchanged'] is True
    assert record['old_qualification_reused'] is record['full_physical_Wang_claim'] is False
    assert observer['resource_candidate_accepted'] is True
    assert tool['terminal']['exit_code'] == observer['parent_exit_code'] == 0
    assert observer['conservative_whole_peak_bytes'] == expected_peaks[index] < plan['limits']['memory_bytes']
    transport = record['native_transport']
    queries = record['native_queries']
    assert s['native_records'] == queries and transport['complete_records'] == len(queries)
    assert transport['all_reaped'] is transport['closed'] is True and transport['native_exit_code'] == 0
    assert [q['id'] for q in queries] == list(range(len(queries)))
    assert len(transport['request_stages']) == len(queries)
    for q, stage in zip(queries, transport['request_stages'], strict=True):
        assert hashlib.sha256(canonical(q['request'])).hexdigest() == q['request_sha256']
        assert stage['record_id'] == stage['ordinal'] == q['id'] and stage['stage'] == 'COMPLETED'
        assert stage['purpose'] == q['purpose'] and stage['limit'] == plan['experiment_limits']['native_steps']
        for key in ['input_sha256', 'output_sha256', 'request_sha256']:
            assert stage[key] == q[key]
    assert pin(path / 'native/input.bin')['sha256'] == queries[-1]['input_sha256']
    assert pin(path / 'native/output.bin')['sha256'] == queries[-1]['output_sha256']
    qs = collections.Counter(q['result']['status'] for q in queries)
    status_total.update(qs)
    ground = t['clusters']
    gq = queries[ground['admission_query']]
    assert gq['purpose'] == 'pilot_ground_cluster_admission' and gq['request']['theory'] == t['spec']['theory']
    assert gq['request']['blocks'] == [r['definition'] for r in ground['instances']]
    assert ground['instances'] == ground['ordering_instances']
    assert len(ground['instances']) == expected_instances[index]
    assert gq['result']['status'] == ground['native_status'] == 'unknown_step_budget'
    assert gq['result']['micro_steps'] == 1000000000 and ground['binding_work'] == 20003
    assert ground['usable'] == [] and ground['registry_native_admitted'] is False
    assert ground['ordering_hints_enabled'] is True and ground['usage'] == 'CONTEXT_CHECKED_PRIMITIVE_ORDERING_ONLY'
    wr = s['word_reference_diagnostics']
    assert wr['complete'] is True and [r['id'] for r in wr['controls']] == control_ids
    assert all(r['status'] == 'PASSED' for r in wr['controls']) and wr['tiny_full_byte_pair_comparisons'] == 49
    assert s['diagnostics']['status'] == 'complete'
    assert s['diagnostics']['base_solutions'] == s['diagnostics']['marked_solutions']
    assert s['diagnostics']['global_dead_forced_generation_controls'] is s['diagnostics']['callback_identity_propagated'] is True
    for key in ['reference_check', 'word_model_check', 'marked_extension_check', 'marking_certificate_check']:
        assert t[key]['complete'] is True
    m = t['model']
    bykey = {tuple(r['key']): r for r in m['placements']}
    assert len(bykey) == len(m['placements']) == t['reference_check']['accepted_placements']
    assert len(m['word_dictionary']) == t['reference_check']['distinct_complete_words']
    assert len(m['conflicts']) == t['reference_check']['internal_conflicts']
    assert m['word_terminator'] == 256 and m['initial']['marks'] == [[[4 * (t['spec']['length'] - 1), 100], 0]]
    assert bytes.fromhex(m['word_dictionary'][0]) == canonical(t['spec']['target'])
    assert sum(len(r['keys']) for r in m['dependencies']) == t['reference_check']['dependency_memberships']
    roots = {tuple(r['point']): r['keys'] for r in m['alignments']}
    certs = t['markings']['certificates']
    assert len(certs) == t['marking_certificate_check']['certificates'] == t['marked_extension_check']['auxiliary_points'] == 12
    for ordinal, c in enumerate(certs):
        assert c['id'] == ordinal and c['trial'] == [c['auxiliary']['placement']]
        assert c['trial'][0][:2] == [0, 0] and c['exhausted_root'] == [0, 1]
        assert c['auxiliary']['point'] == [-100, ordinal] and c['auxiliary']['placement_value'] == 0 and c['auxiliary']['initial_value'] == 1
        assert [r['key'] for r in c['all_candidates']] == roots[(0, 1)]
    donors = []
    assert len(s['training']) == len(s['library']) == 3 and s['library_frozen_before_tests'] is True
    for tr, length in zip(s['training'], [3, 5, 5], strict=True):
        assert len(tr['search']['proof']) == len(tr['essential_proof']) == length
        assert tr['host_check']['accepted'] is tr['essential_host_check']['accepted'] is tr['region']['complete'] is tr['reference_check']['complete'] is True
        for field, proof in [('native_query', tr['search']['proof']), ('essential_native_query', tr['essential_proof'])]:
            q = queries[tr[field]]
            assert q['result']['status'] == 'accepted'
            assert q['request']['proof'] == proof and q['request']['theory'] == tr['spec']['theory']
            assert q['request']['target'] == tr['spec']['target'] and q['request']['blocks'] == []
        donors.append(dict(id=tr['spec']['id'], rows=length, whole_query=tr['native_query'], essential_query=tr['essential_native_query']))
    assert [a['id'] for a in t['arms']] == corpus['protocol']['arm_order'][cid] and len(t['arms']) == 6
    arms = {a['id']: a for a in t['arms']}
    arm_rows = []
    for a in t['arms']:
        aid = a['id']
        search = a['search']
        trace = search['trace']
        metrics = search['metrics']
        assert a['execution_status'] == 'SEARCH_RETURNED' and search['root_restored'] is True
        assert metrics['attempts'] == expected[index][aid]
        obs = a['ordering_observations']
        cluster = aid in ['SC', 'P01', 'P11']
        marked = aid in ['P10', 'P11']
        assert a['cluster_enabled'] is cluster and a['marking_enabled'] is marked
        assert obs['enabled'] is cluster and obs['available_instances'] == (expected_instances[index] if cluster else 0)
        assert obs['symbolic_activation_count'] is obs['realized_primitive_choice_count'] is None
        assert obs['successful_proposals'] == metrics.get('cluster_proposals', 0)
        events = collections.Counter(e['event'] for e in trace)
        row = dict(id=aid, status=search['status'], metrics=metrics, trace_event_counts=dict(events), seconds=search['seconds'], full_arm_seconds=a['timings']['full_arm_seconds'], root_restored=True, ordering_observations=obs, proof_verification_status=a['proof_verification_status'])
        if aid.startswith('P'):
            assert search['status'] == 'unknown_search_budget' and search['proof'] is None and search['placements'] == []
            assert len(search['domain_audits']) == 2 and all(r['complete'] is True for r in search['domain_audits'])
            assert events['place'] == metrics['attempts'] and events['decision'] == metrics['nodes']
            assert events['return'] == metrics.get('backtracks', 0)
            assert trace[-1] == dict(event='cutoff', attempts=metrics['attempts'])
            kinds = collections.Counter(e['kind'] for e in trace if e['event'] == 'decision')
            for kind in ['branch', 'forced', 'dead']:
                assert kinds[kind] == metrics.get(kind, 0)
            for ordinal, e in enumerate(trace):
                if e['event'] == 'decision':
                    assert e['ordinal'] == ordinal
                elif e['event'] == 'order':
                    decision = trace[e['decision']]
                    assert decision['kind'] in ['forced', 'branch']
                    assert sorted(e['alternatives']) == sorted(decision['original_alternatives'])
                elif e['event'] in ['place', 'return']:
                    order = next(r for r in trace[e['decision'] + 1:] if r['event'] == 'order' and r['decision'] == e['decision'])
                    assert e['key'] in order['alternatives']
                elif e['event'] == 'cluster_proposals':
                    assert e['proposals'] == []
            assert len(search['initial_auxiliary_removals']) == (12 if marked else 0)
            assert metrics['auxiliary_removed_incidences'] == 0
            if marked:
                assert [w['candidate'] for w in search['initial_auxiliary_removals']] == [c['auxiliary']['placement'] for c in certs]
            if cluster:
                assert obs['successful_proposals'] == obs['point_activated_proposal_packets'] == metrics.get('cluster_hints', 0) == 0
            else:
                assert obs['point_activated_proposal_packets'] is None
            row['completed_audits'] = search['domain_audits']
            row['initial_auxiliary_witnesses'] = len(search['initial_auxiliary_removals'])
            point_total += metrics['attempts']
            audit_total += 2
        else:
            assert events['extend'] == metrics['attempts']
            assert events['decision'] == metrics['nodes'] - (1 if search['proof'] is not None else 0)
            assert events['return'] == metrics.get('backtracks', 0) + (14 if search['proof'] is not None else 0)
            path_commands = []
            proposals = changes = 0
            for e in trace:
                if e['event'] == 'decision':
                    assert e['row'] == len(path_commands)
                    assert sorted(e['ordered_candidates']) == sorted(e['original_candidates'])
                    changes += e['ordered_candidates'] != e['original_candidates']
                    for p in e['proposals']:
                        assert p['instance'] in {r['id'] for r in ground['instances']}
                        assert p['prefix_rows'] == len(path_commands)
                        assert p['checked_primitive_proof'] == path_commands + p['commands']
                        assert p['result_formula'] not in [c['formula'] for c in path_commands]
                        assert p['host_check']['accepted'] is True
                        assert p['host_check']['rows'] == len(p['checked_primitive_proof'])
                        assert p['host_check']['target'] == p['result_formula'] == p['commands'][-1]['formula']
                        assert any(m['domains'][e['row']][k] == p['commands'][0] for k, v in e['original_candidates'])
                    proposals += len(e['proposals'])
                elif e['event'] == 'extend':
                    dec = trace[e['decision']]
                    assert [e['skeleton'], e['variant']] in dec['ordered_candidates']
                    path_commands.append(m['domains'][dec['row']][e['skeleton']])
                elif e['event'] == 'return':
                    assert len(path_commands) == trace[e['decision']]['row'] + 1
                    path_commands.pop()
            assert proposals == metrics.get('cluster_proposals', 0)
            assert proposals == (expected_proposals[index] if aid == 'SC' else 0)
            assert changes == (expected_order_changes[index] if aid == 'SC' else 0)
            row['passive_trace_successful_proposal_packets'] = proposals
            row['passive_trace_decisions_with_changed_order'] = changes
            row['passive_trace_metric_scope'] = 'Literal saved decision-array comparisons; not realized primitive-choice or completed-cluster counts.'
            proposal_total += proposals
            changed_order_total += changes
        if index == 0 and aid in ['S0', 'SC']:
            assert a['native_proof_accepted'] is a['host_check']['accepted'] is a['region']['complete'] is True
            assert len(search['proof']) == 14 and len(search['placements']) == 28
            q = queries[a['native_query']]
            assert q['result']['status'] == 'accepted' and q['purpose'] == 'pilot_test_' + cid + '_' + aid
            assert q['request']['proof'] == search['proof'] and q['request']['theory'] == t['spec']['theory']
            assert q['request']['target'] == t['spec']['target'] and q['request']['blocks'] == []
            for key in search['placements']:
                item = bykey[tuple(key)]
                slot, k = item['command_reference']
                assert m['domains'][slot][k] == search['proof'][slot]
            prior = read(OLD / 'actual' / cid / 'result.json')
            prior_proof = next(x['search']['proof'] for x in prior['scientific_result']['tests'][0]['arms'] if x['id'] == 'S0')
            assert search['proof'] == prior_proof
            row['qualified_primitive_certificate'] = dict(arm=aid, rows=14, selected_placements=28, Native_query=q['id'], Native_status='accepted', rules=dict(collections.Counter(c['rule'] for c in search['proof'])), repeated_D11_S0_certificate=True, novel_theorem=False, GCTS_point_proof=False)
        else:
            assert search['proof'] is None and search['status'] == 'unknown_search_budget'
        arm_rows.append(row)
    for bare, marked in [('P00', 'P10'), ('P01', 'P11')]:
        b = arms[bare]['search']['domain_audits']
        a = arms[marked]['search']['domain_audits']
        assert b[0]['incidences'] - a[0]['incidences'] == 12 and b[0]['decision'] == a[0]['decision']
        assert b[1] == a[1]
    assert arms['P00']['search']['domain_audits'] == arms['P01']['search']['domain_audits']
    assert arms['P10']['search']['domain_audits'] == arms['P11']['search']['domain_audits']
    control = record['independent_external_controls']
    assert control['supplied_to_proof_search'] is False
    assert all(control['base']['premise_truths']) and control['base']['goal_truth'] is False
    files = sorted(p for folder in [path, observer_path.parent] for p in folder.rglob('*') if p.is_file())
    assert not any('.partial' in p.name for p in files) and len(files) == 14
    actual_pins.extend(pin(p) for p in files)
    observations.append(dict(case_id=cid, resource_admitted=True, packet=rp, whole_peak_bytes=observer['conservative_whole_peak_bytes'], observer_gate_seconds=observer['final_observer_gate_seconds'], plan=pin(plan_path), grant=pin(grant_path), consumed=pin(path/'CONSUMED.json'), Native_queries=len(queries), Native_status_counts=dict(qs), donors=donors, library_family_ids=[r['id'] for r in s['library']], registry_native_admitted=False, registry_status=ground['native_status'], registry_usable=0, ordering_instances=len(ground['ordering_instances']), registry_binding_work=ground['binding_work'], scientific_complete=True, word_reference_controls=48, full_shared_setup_seconds=t['full_shared_setup_seconds'], compile_and_model_seconds=t['compile_and_model_seconds'], arms=arm_rows))

assert point_total == 169 and audit_total == 24 and proposal_total == 8 and changed_order_total == 2
assert len(actual_pins) == 42 and dict(status_total) == dict(accepted=76, rejected=209, unknown_step_budget=3)
assert len({r['sha256'] for r in grant_pins}) == 3
old_review_path = OLD / 'review-C/typed-ordering-only-actual-scientific-review-v1.json'
old_review = read(old_review_path)
assert pin(old_review_path)['sha256'] == '3cf59e5a1d7f0d3906fd9dbd265d8e7b61a6e6bd56e12876b93591118c9c6648'
for row in old_review['actual_file_pins']:
    verify(row)
first = read(D/'actual'/cases[0]/'result.json')['scientific_result']['tests'][0]
first_arms = {a['id']: a for a in first['arms']}
base = first_arms['S0']['search']
guided = first_arms['SC']['search']
assert base['proof'] == guided['proof'] and base['placements'] == guided['placements']
base_decisions = [e for e in base['trace'] if e['event'] == 'decision']
guided_decisions = [e for e in guided['trace'] if e['event'] == 'decision']
assert len(base_decisions) == len(guided_decisions) == 14
assert [(e['row'], e['original_candidates'], e['ordered_candidates']) for e in base_decisions] == [(e['row'], e['original_candidates'], e['ordered_candidates']) for e in guided_decisions]
assert [{k:v for k,v in e.items() if k != 'proposals'} for e in base['trace']] == [{k:v for k,v in e.items() if k != 'proposals'} for e in guided['trace']]
assert base['metrics']['attempts'] == guided['metrics']['attempts'] == 14
assert base['metrics']['skeleton_tests'] == guided['metrics']['skeleton_tests'] == 47209
assert all(p['result_formula'] not in [c['formula'] for c in p['checked_primitive_proof'][:p['prefix_rows']]] for e in guided_decisions for p in e['proposals'])
expected_results = [('e7763a8245115b28e27f5ad3ec56660cbfb22c6d01ad07c17ebb28a6d2c34f05',31602698),('ca541e8ad0464d6e24d2012cb0db0a095b979a040d1a51ac32f3a00d9327017c',31157030),('938ca2175a9ea5a35c686cb775eab0f20af58630739e6bb5c0e42cb48a5b8a05',31532998)]
for row, expected_result in zip(observations, expected_results, strict=True):
    assert (row['packet']['sha256'], row['packet']['bytes']) == expected_result
C_source_path = D/'review-C/typed-saturated-hint-Source-review-v1.json'
C_whole_path = D/'review-C/typed-saturated-hint-whole-prospective-Source-review-v1.json'
assert pin(C_source_path)['sha256'] == 'b4311b9243bca5274f621b3d8f8969141fbccb3012cf1b30500da308cb1effaf'
assert pin(C_whole_path)['sha256'] == '0303262999d47ed0d81df2806b9b8610fc873345f40ba5ddc145a92646559284'
assert read(C_source_path)['review_passed'] is read(C_whole_path)['review_passed'] is True
assert read(C_whole_path)['whole_offer'] == pin(offer_path)
checks = [
    ('complete-fresh-pinned-evidence', 'All44 offered closure pins and42 complete actual/observer bodies independently revalidated. Three fresh unique consumed once grants join exact plans/reviews. All worker/parent/observer/tool exits0 and conservative whole peaks853,262,336/782,876,672/810,958,848B qualify. No partials observed/read, no scientific/Host/Native replay.'),
    ('complete-eighteen-arm-ordering-protocol', 'All18 arms SEARCH_RETURNED under the separately preregistered exact-prefix abstention follow-up. Three full cold jobs each acquired/check/mined3/5/5 donors and retained the original case bounds/schedules. Completion is bounded record coverage with candidate proof gates, not all targets solved, Native registry qualification, a novel theorem or superiority. The inner resource_accepted=False placeholder is distinct from outer whole admission.'),
    ('Native-registry-donor-and-candidate-joins', 'All288 complete Native requests/stages/digests/last raw input-output joins reconcile:76accepted/209rejected/3unknown. All three aggregate inventories remain UNKNOWN after1e9 steps, usable=[]/registry_admitted=false with7/11/7 separate ordering instances. Eighteen whole/essential donor acceptances and both first-recipient flat requests use exact theory/target/proof and final blocks=[]. No registered inference was used.'),
    ('actual-reduction-markings-and-controls', 'All144 unchanged word-reference control rows, full model dictionary/target/placement/dependency joins, overlay/certificate checks and Tiny scheduler/rollback observations qualify. All36 failure certificates remain shallow first-row mandatory-root support exhaustion. Both marked/unmarked point pairs per case have12 fewer initial audited incidences and equal second audits; witnesses alone are not substituted for these Graph audits. No high-level lemma or arbitrary-state reduction proof follows.'),
    ('point-progress-fallback-and-limited-audits', 'All12 point calls remain UNKNOWN with169 placement events and24 complete initial domain/incidence/scheduler audits. Every saved alternative order/key/counter/kind/cutoff/root-restored join reconciles; both clusters-on point arms/case show0 successful proposals and0 activated packets. Only firsttwo states/call were independently audited. No claim of point novelty, useful hint activation or time-normalized improvement follows from differing cooperative prefixes.'),
    ('surviving-proposals-and-actual-prefix-scope', 'SC recorded4/0/4 successful packets and0/0/2 literal order changes,8packets/2changes total. Every packet joins the actual current trace prefix and primitive suffix/instance/accepted Host receipt, and every conclusion is absent from that incoming prefix. This is consistent with the exact reviewed abstention Source. No saturation-reason/call counter exists, so the number or cost of declined hints is unavailable; zero point packets does not attribute a cause or prove exhaustive abstention.'),
    ('baseline-recovery-with-identical-positive-path', 'First S0 and SC both return the same14-row primitive proof and same28 selected command/guard placements; final Host/fullregion/Native accepted queries89/90. All14 original/ordered candidate arrays and every decision/extension/return field except proposal payloads are identical. Both make14extensions/47,209skeleton tests; SC4packets causes0order changes. The proof equals D11 S0. This recovers the conventional result after the prior heuristic failure, not a new theorem, faster route or useful positive-case ordering advantage. Equality and negative S0/SC plus all point calls remain bounded UNKNOWN.'),
    ('fair-costs-history-and-open-goals', 'All cold acquisition/compiler/reference/word/marking/registry/search/final/output/custody costs remain charged. Abstention changes work by declining some optional validation but no phase or decline instrumentation supports causal memory/time attribution. Full D11 raw actual pins remain exact and its negative result is not retroactively improved. Single designed follow-ups, differing timed prefixes and cooperative overshoot establish no statistical gain, trainedRL, physicalWang/fullVM or broader arithmetic/geometry/tiling completion.')
]
review = dict(schema='typed-saturated-hint-actual-scientific-review-v1', reviewer_identity='/root/recovered_batch_review', review_passed=True, status='PASS_PASSIVE_COMPLETE_SAVED_SCOPE_ALL_JOBS_ADMITTED_BASELINE_RECOVERY_NOT_ORDERING_ADVANTAGE', passive_complete_saved_data_only=True, scientific_calls=0, logical_replays=0, actual_execution_authorized=False, check_count=len(checks), failed_checks=0, checks=[dict(id=i,passed=True,finding=f) for i,f in checks], complete_pilot_comparison=True, resource_admitted_case_ids=cases, resource_rejected_case_ids=[], registered_inference_admitted=False, GCTS_point_proofs_admitted=0, accepted_recipient_certificate_occurrences=2, distinct_recipient_proof_bodies=1, novel_mathematical_theorem=False, useful_positive_ordering_difference=False, GCTS_or_RL_advantage_established=False, totals=dict(searches=18,skips=0,point_searches=12,point_placements=169,point_domain_audits=24,Native_queries=288,Native_status_counts=dict(status_total),donor_whole_essential_acceptances=18,word_control_returns=144,symbolic_successful_proposal_packets=8,passive_decisions_with_changed_symbolic_order=2,point_successful_proposal_packets=0,point_activated_packets=0), first_positive_exact_S0_SC_comparison=dict(proof_bodies_identical=True,selected28placements_identical=True,all14original_and_ordered_candidate_arrays_identical=True,full_event_fields_except_proposals_identical=True,attempts_each=14,skeleton_tests_each=47209,SC_successful_proposals=4,SC_changed_orders=0,interpretation='Recovered existing conventional route; no positive-case ordering improvement.'), cases=observations,complete_input_pins=offer['files'],actual_file_pins=actual_pins,grant_pins=grant_pins,whole_offer=pin(offer_path),protocol=offer['protocol'],scientific_Source_delta_review=pin(C_source_path),whole_Source_review=pin(C_whole_path),external_tool_observer=pin(external_path),Root_initial_passive_join=pin(D/'root/initial-passive-actual-join-v1.json'),D11_historical_review=pin(old_review_path),partial_policy='No partial content read/projected/adopted. D11/older records and policies remain unchanged.',remaining='All18 bounded arms completed; one repeated proof body occurs in S0 and SC. Useful point/cluster/RL advantage and all broader goals remain open.',tools_stopped=True)
resource = D/'verification-L/typed-saturated-hint-resource-custody-review-v1.json'
if resource.exists():
    assert read(resource)['review_passed'] is True
    review['independent_resource_review'] = pin(resource)
target = D/'review-C/typed-saturated-hint-actual-scientific-review-v1.json'
with target.open('x') as stream:
    json.dump(review,stream,indent=2,ensure_ascii=False)
    stream.write('\n')
print(json.dumps(pin(target)))
