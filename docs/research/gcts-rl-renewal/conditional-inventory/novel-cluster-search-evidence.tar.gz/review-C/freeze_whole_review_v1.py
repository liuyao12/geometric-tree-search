"""Independent passive complete metadata and Source/AST preflight only."""
from pathlib import Path
import ast
import hashlib
import json

BASE = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
D = BASE / 'research-runs/gcts-novelty-proof-pilot-20261020'
OLD = BASE / 'research-runs/gcts-ordering-proof-pilot-20261020'
R = D / 'root'

def pin(path):
    p = Path(path)
    assert '.partial' not in p.name
    b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())

def read(path):
    p = Path(path)
    assert p.suffix == '.json' and '.partial' not in p.name
    return json.loads(p.read_bytes())

def verify(row):
    assert pin(row['path']) == row

offer_path = R / 'prospective-whole-offer-v1.json'
offer = read(offer_path)
assert pin(offer_path)['sha256'] == '6f38cdfc1a9fbf022be03510cfac12df71998cb46c6ff4011e8c6ef0a7983f01'
assert pin(offer_path)['bytes'] == 23140
assert len(offer['files']) == len({r['path'] for r in offer['files']}) == 44
assert len(offer['plans']) == 3
for row in offer['files'] + offer['plans'] + [offer['protocol']] + offer['normative_references'] + offer['initial_Source_reviews']:
    verify(row)
for field in ['scientific_calls', 'new_actuals', 'new_grants', 'old_grants_remaining']:
    assert offer[field] == 0
assert offer['expected_case_jobs'] == 3 and offer['expected_explicit_arm_outcomes'] == 18
protocol = read(offer['protocol']['path'])
api_path = D / 'implementation-B/API-v1.json'
api = read(api_path)
parent = read(offer['ordering_policy']['path'])
abstention = read(offer['abstention_policy']['path'])
old_protocol = read(OLD / 'root/protocol-v1.json')
assert offer['ordering_policy'] == api['policy'] == protocol['ordering_policy'] == abstention['parent_ordering_policy']
assert offer['abstention_policy'] == api['abstention_policy'] == protocol['abstention_policy']
assert offer['superseded_acquisition'] == parent['superseded_acquisition_document'] == protocol['superseded_acquisition']
assert protocol['explicit_override'] == parent['explicit_override'] == old_protocol['explicit_override']
assert parent['registry']['native_registry_required_for_ordering'] is False
assert abstention['successor'] == api['entry'] and api['entry']['sha256'] == 'e33801360f36f51efc99b69278ef0e8cd7d783892dec7fa9763c8f63378c6b93'
assert protocol['limits'] == old_protocol['limits']
assert protocol['scientific_limits'] == old_protocol['scientific_limits'] == api['limits']
assert protocol['input'] == api['corpus'] == parent['logical_corpus']
assert protocol['input']['sha256'] == '2f206ef004c4d723f862ee36f08355816c5264a5809340be9787331d82d33cd6'
assert protocol['normative_references'] == offer['normative_references']
assert [r['sha256'] for r in offer['normative_references']] == ['c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9', 'ca6ee206287bf18b69f88a35d30968312499567755f347a819af4cf49743e7d4']
assert offer['python']['sha256'] == 'b6ea0c2a9bfce48dbf181a53f1ca4f0562d40658b85bf47258e2a88d8f9e3933'
sources = [Path(r['path']) for r in offer['files'] if r['path'].endswith('.py')]
assert len(sources) == len(offer['source_AST_checks']) == 33
assert {r['path'] for r in offer['source_AST_checks']} == set(map(str, sources))
assert all(r['AST_and_unused_compile'] is True for r in offer['source_AST_checks'])
for p in sources:
    tree = ast.parse(p.read_bytes(), filename=str(p))
    compile(tree, str(p), 'exec')
runtime = sorted((D / 'runtime').glob('*.py'))
names = ['case_worker_v1.py', 'run_case_once_v3.py', 'observe_case_once_v2.py', 'independent_countermodel_v1.py']
copied = runtime + [R / name for name in names]
assert len(runtime) == 28 and len(copied) == 32
baseline_path = R / 'baseline-copy-pins-v1.json'
baseline = read(baseline_path)
assert len(baseline['files']) == 32 and {r['target'] for r in baseline['files']} == set(map(str, copied))
for row in baseline['files']:
    before = Path(row['source'])
    after = Path(row['target'])
    assert before.is_relative_to(OLD) and before.relative_to(OLD) == after.relative_to(D)
    assert before.read_bytes() == after.read_bytes()
    assert pin(before)['sha256'] == pin(after)['sha256'] == row['sha256']
    assert pin(before)['bytes'] == pin(after)['bytes'] == row['bytes']
for field in ['model_source', 'verifier_source']:
    verify(api[field])
    assert (D / 'runtime' / Path(api[field]['path']).name).read_bytes() == Path(api[field]['path']).read_bytes()
expected_closure = set(map(str, copied)) | {api['entry']['path'], str(api_path), str(D/'implementation-B/handoff-v1.json'), offer['ordering_policy']['path'], offer['abstention_policy']['path'], offer['superseded_acquisition']['path'], api['corpus']['path'], offer['python']['path']}
native_rows = [r for r in offer['files'] if '/recovered/and-support/' in r['path']]
assert len(native_rows) == 4
expected_closure |= {r['path'] for r in native_rows}
assert expected_closure == {r['path'] for r in offer['files']}
doc = read(protocol['input']['path'])
assert [t['length'] for t in doc['tests']] == [14, 13, 14]
assert [t['length'] for t in doc['training']] == [3, 5, 5]
for row, spec in zip(offer['plans'], doc['tests'], strict=True):
    plan = read(row['path'])
    old_plan = read(OLD / 'root' / Path(row['path']).name)
    assert plan['case_id'] == spec['id'] and plan['schema'] == 'proof-search-case-once-plan-v1'
    assert plan['experiment'] == 'exact-prefix-saturated-hint-v1'
    assert plan['files'] == offer['files'] and plan['protocol'] == offer['protocol']
    for field in ['ordering_policy', 'abstention_policy', 'superseded_acquisition']:
        assert plan[field] == offer[field]
    assert plan['limits'] == protocol['limits'] == old_plan['limits']
    assert plan['experiment_limits'] == protocol['scientific_limits'] == old_plan['experiment_limits']
    assert plan['modules'] == api['roles'] == old_plan['modules']
    assert plan['native'] == old_plan['native'] and plan['python'] == offer['python'] == old_plan['python']
    assert plan['input_path'] == protocol['input']['path'] == old_plan['input_path']
    assert plan['entry_path'] == api['entry']['path'] and plan['runtime_dir'] == str(D/'runtime')
    for field, name in [('worker_path', names[0]), ('runner_path', names[1]), ('observer_path', names[2]), ('control_path', names[3])]:
        assert plan[field] == str(R/name)
    assert plan['actual_dir'] == str(D/'actual'/spec['id'])
    assert not Path(plan['actual_dir']).exists() and not Path(plan['actual_dir']+'.observer').exists()
assert not list(R.glob('grant-*.json')) and not (R/'Root-preflight-v1.json').exists()
C_path = D/'review-C/typed-saturated-hint-Source-review-v1.json'
L_path = D/'verification-L/typed-saturated-hint-Source-ABI-review-v1.json'
assert pin(C_path)['sha256'] == 'b4311b9243bca5274f621b3d8f8969141fbccb3012cf1b30500da308cb1effaf'
assert pin(L_path)['sha256'] == '3c01e332019d4e600dd81cf47497752aa4e2c01370296f874e87f6dcce5726ac'
assert read(C_path)['review_passed'] is read(L_path)['review_passed'] is True
assert offer['initial_Source_reviews'] == [pin(C_path), pin(L_path)]
inherited_path = OLD/'review-C/typed-whole-prospective-Source-review-v1.json'
assert pin(inherited_path)['sha256'] == 'b7c549a72e4334a3b3e50a1668ca6e5310cb2619cb34a2569ca439a7f8e9441d'
original_L = BASE/'research-runs/gcts-word-point-proof-pilot-20261020/verification-L/handoff-v1.json'
assert pin(original_L)['sha256'] == '5cfa4cc5ed78ff1f762040c6c394375a87165c11416bebded0ce2233a97386c2'

checks = [
    ('exact-44-file-closure-and-parser', 'All44 closure pins, three plan pins, protocol, initial reviews and both normative master pins independently revalidated. All33 complete Sources AST parsed and unused compiled under the pinned parser without imports/execution. Closure adds the new abstention policy to the full inherited ordering/acquisition/input/Native dependencies; no hidden helper or reduced cohort.'),
    ('unchanged-runtime-and-custody', 'All28 runtime and four worker/parent/observer/control Sources are byte-identical D11. Model/verifier originals equal runtime copies. Prior complete-domain, scheduler, rollback, word-reduction, parent-view, owned-cutoff and fixed nonhostile custody Source judgments apply to exact bodies. Full actual output/memory/time/Native-reaping/tool joins still decide future admission; Source reuse is not a fit guarantee or fullVM qualification.'),
    ('initial-scientific-reviews-and-policy-join', 'Exact Cb431 and L3c01 initial reviews bind v10e338 and abstention9c22. Whole protocol/three plans now explicitly bind inherited ordering57ee plus the old7d55 specialization/freeze override and this new general prefix abstention. Inherited completion_scope wording names base D11; the new Root/API distinctly declare the D12 follow-up, with no old record relabeling.'),
    ('hint-only-abstention-and-acceptance', 'Reviewed exact one-function condition returns existing None on an already-present exact incoming prefix conclusion. Every repeated primitive remains fallback. No target route, point novelty, domain/degree/pruning/marking/new inference or proof compression. Registry UNKNOWN stays unadmitted/usable[], actual query/status/cost/hard faults and surviving proposal Host checks unchanged. Final flat Host/fullregion/Native blocks=[] gates remain.'),
    ('three-full-cold-case-plans-and-fairness', 'Three distinct absent actual/observer paths bind the entire same corpus,14/13/14targets, fresh3/5/5donors, all six arm configurations and exact relative schedules. No supplied route, old library/result/prefix/grant reuse, target weakening or outcome-dependent retry. This is a disclosed follow-up to D11, not blind/held-out or strongest-ATP/statistical comparison. All18 outcomes remain needed for full bounded comparison.'),
    ('unchanged-budgets-and-full-costs', 'All local/scientific and outer caps equal D11:600attempts/cooperative2s including Graph/audits/proposals, two full domain audits, Native1e9 and unchanged other quotas;160work/180positive/210custody/225fallback,1GiB/128MiB/9MiBreserve/400mcallbacks and exact logs/results. Abstention may avoid expansion/Host work but its scan remains inside the original clocks. Nested clocks are not additive, no phase/saturation counter added, no promised fit or gain.'),
    ('limitations-and-completion-honesty', 'A saturated conclusion may hide useful intermediate derivations; no dominance claim is made. Point first-receptor zeros may persist, and no common point novelty change is bundled. Eligibility/proposals/activation and unavailable realized-choice metrics retain D11 meanings. scientific_complete describes the new bounded ordering comparison, not registry acceptance, solved targets, trainedRL, physicalWang or completion of the broader proof/tiling program.'),
    ('fresh-independent-and-Root-authority-barrier', 'No new actual/observer/grant/preflight files at freeze; all offered authority counters zero. This receipt authorizes no execution and does not assume a future L whole-plan PASS. Root must collect that separate receipt, issue exact fresh once grants and observe tools idle before its serial actuals. D11/older results/failures/policies remain frozen; partial content is never parsed or adopted.')
]
receipt = dict(schema='typed-saturated-hint-whole-prospective-Source-review-v1', reviewer_identity='/root/recovered_batch_review', review_passed=True, status='PASS_EXACT_WHOLE_SOURCE_PLAN_PREFLIGHT_SEPARATE_L_WHOLE_REVIEW_AND_ROOT_GRANTS_REQUIRED', source_only=True, scientific_calls=0, component_calls=0, logical_replays=0, actual_execution_authorized=False, grant_authority=False, actual_resource_accepted=False, check_count=len(checks), failed_checks=0, checks=[dict(id=i, passed=True, finding=f) for i,f in checks], whole_offer=pin(offer_path), protocol=offer['protocol'], plans=offer['plans'], complete_input_pins=offer['files'], normative_references=offer['normative_references'], AST_unused_compile_count=33, unchanged_runtime_Source_count=28, unchanged_custodian_Source_count=4, exact_D11_copy_manifest=pin(baseline_path), initial_scientific_C_review=pin(C_path), separate_initial_L_review=pin(L_path), inherited_D11_C_whole_review=pin(inherited_path), original_D8_L_verifier_handoff=pin(original_L), ordering_policy=offer['ordering_policy'], abstention_policy=offer['abstention_policy'], superseded_acquisition=offer['superseded_acquisition'], metadata_author=pin(R/'prepare_case_plans_v1.py'), separate_D12_L_whole_review_required=True, L_whole_PASS_not_assumed=True, resource_fit='UNMEASURED', new_actuals=0, new_grants=0, old_grants_remaining=0, partial_policy='No partial content opened, parsed, projected or admitted.', manual_scope='Conditional Source/manual complete preflight; no runtime, proof replay or performance qualification.', tools_stopped=True)
target = D/'review-C/typed-saturated-hint-whole-prospective-Source-review-v1.json'
with target.open('x') as stream:
    json.dump(receipt, stream, indent=2)
    stream.write('\n')
print(json.dumps(pin(target)))
