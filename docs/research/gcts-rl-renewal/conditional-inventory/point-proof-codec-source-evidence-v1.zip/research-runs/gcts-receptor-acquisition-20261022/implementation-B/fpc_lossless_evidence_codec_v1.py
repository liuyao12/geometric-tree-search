"""Lossless parsed-value qualification transport. Source-only initial offer.

All public work requires a genuine bounded callback. This is inert transport,
not proof checking, admission, raw-wire parsing, or a scientific algorithm.
Callers keep reachable mutable inputs stable during intake only and preserve
this namespace and the native integer policy. No private object is test intake.
"""
import hashlib
import json
import math
import struct
import sys


VERSION = 'FPC-LOSSLESS-QUALIFICATION-EVIDENCE-CODEC-v1'
PROFILE = 'EXISTING_JSON221_V1'
SCHEMA = 'FPC-lossless-qualification-evidence-v1'
READBACK_SCHEMA = 'FPC-lossless-evidence-readback-v1'
SOURCE_CHUNK = 4096
OUTPUT_CHUNK = 65536
_OWNER = object()
_EXPECTED_SCOPE = (('baseline56', ('codec-hi-and-exists-literal', 'codec-pa-no-profile-payload', 'codec-metadata-query-invariance', 'codec-shadowed-binder-preserved', 'codec-bool-mode-refused', 'codec-open-theorem-refused', 'codec-signature-mismatch-refused', 'codec-binder-order-refused', 'codec-extra-proof-field-refused', 'codec-retained-fault-identity', 'product-two-by-three', 'product-three-binary-slots', 'product-closed-empty', 'product-zero-arity', 'product-open-request-not-eof', 'product-staggered-arrivals', 'product-known-empty-dominates-open', 'match-formula-meta', 'match-consistent-repeat', 'match-conflicting-repeat', 'match-rigid-binder', 'match-no-alpha-renaming', 'match-term-meta', 'match-sort-conflict', 'match-variable-meta', 'match-rigid-arity-conflict', 'builder-H1-literal', 'builder-H2-literal', 'builder-H3-literal', 'builder-Q1-literal', 'builder-Q2-literal', 'builder-Q3-literal', 'builder-E1-literal', 'builder-E2-literal', 'builder-Q1-capture-refused', 'builder-Q3-free-variable-refused', 'builder-E2-capture-refused', 'builder-induction-full-parameters-refused', 'search-antecedent-first-closure', 'search-implication-first-closure', 'search-duplicate-source-aliases', 'search-cyclic-demand-no-fact', 'search-long-source-witness-not-fact', 'search-shared-DAG-export', 'search-late-GEN', 'search-full-Gamma-GEN-refusal', 'search-source-variable-outside-grammar', 'search-source-depth-outside-grammar', 'search-priority-record-invariants', 'search-cutoff-live-prefix-no-exhaustion', 'fault-product-first-ValueError', 'fault-matcher-first-StopIteration', 'fault-search-retained-owned-codec', 'fault-search-later-RuntimeError', 'fault-final-validator-first-identity', 'fault-builder-public-class-identity'), 56, 'baseline_bank', 'baseline_search', 'Unchanged original56 codec/builders/old search expectations only. Fresh controls, never claims about the new producer.'), ('obligation47', ('search-context-Gamma-present', 'search-context-Gamma-absent', 'search-context-theory-present', 'search-context-theory-absent', 'search-cycle-without-seed', 'search-premise-source-first', 'search-premise-implication-first', 'search-premise-duplicate-source', 'search-shared-context-diamond', 'guard-UI-capture-binder', 'guard-UI-closed-term-no-capture', 'guard-UI-shadowed-target-ID', 'guard-GEN-unused-Gamma-variable', 'guard-GEN-full-Gamma-clear', 'guard-GEN-unused-local-variable', 'guard-induction-wrong-profile', 'guard-induction-wrong-parameters', 'guard-induction-parameter-closure', 'compile-intro-identity', 'compile-intro-root-hypothesis', 'compile-intro-MP', 'compile-intro-GEN', 'compile-nested-equal-assumptions', 'compile-intro-finite-table', 'compile-intro-logical-axiom', 'compile-intro-PA-table', 'compile-intro-incidence-table', 'compile-intro-induction', 'compile-full-FPC-deep-term', 'compile-full-FPC-large-formula', 'refuse-MP-premise-order', 'refuse-rigid-binder-HYP', 'refuse-GEN-unused-root', 'refuse-GEN-unused-local', 'refuse-context-opener', 'refuse-forward-premise', 'refuse-duplicate-arena-row', 'product-diagonal-2x2', 'product-open-WAIT-growth', 'product-closed-empty-open-other', 'product-zero-arity', 'fault-search-first-RuntimeError', 'fault-guard-StopIteration', 'fault-compile-same-public-class', 'fault-retained-owned-through-guard', 'fault-late-compile-first-before-second', 'fault-dual-validators'), 47, 'obligation_bank', 'producer', 'Additive new synthetic query/guard/compiler/product/fault coverage with full separate current receipts.'), ('intro_integration1', ('producer-INTRO-local-HYP-dual-export',), 1, 'intro_bank', 'producer', 'Synthetic search-only discovery of current-context INTRO/localHYP and primitive compiler/dual validation integration; not a six-goal theorem.'), ('point20', ('point-HYP-MP-agreement', 'point-wrong-MP-mark-conflict', 'point-final-goal-boundary-conflict', 'point-GEN-agreement', 'point-GEN-source-mark-conflict', 'point-GEN-unused-Gamma-refusal', 'point-HYP-declared-conclusion-refusal', 'point-LOGICAL-declared-conclusion-refusal', 'point-THEORY-profile-refusal', 'point-MP-forward-reference-refusal', 'point-MP-coincident-port-refusal', 'point-repeated-remote-port-agreement', 'point-long-range-mark-only-agreement', 'point-LOGICAL-Q3-agreement', 'point-THEORY-finite-agreement', 'point-first-RuntimeError-identity', 'point-first-public-refusal-class-identity', 'point-first-StopIteration-identity', 'point-later-first-fault-and-immutability', 'point-retained-family-refusal-identity'), 20, 'point_bank', 'point_adapter', 'Current parametric point-row representation only, no parser or search/graph qualification.'), ('regression2', ('refuse-extra-INTRO-reused-owned-context', 'constructor-StopIteration-first-fault-and-owned-cleanup'), 2, 'regression_bank', 'producer', 'Exact malformed ownership and public-phase first-StopIteration regressions only; cleanup remains Source/whole custody authority.'), ('point-kernel13', ('global-dead-before-forced', 'global-forced-before-earlier-branch', 'generation-before-degree', 'remote-mark-only-zero-is-assigned', 'remote-conflict-dead-before-other-force', 'shared-fractional-placement-once', 'distinct-inventory-identical-point-functions', 'rollback-parent-exclusion', 'mark-reference-count-rollback', 'generation-minimum-rollback', 'outside-support-global-legality', 'lazy-prefix-not-singleton', 'frame-boundary-growth'), 13, 'explicit_bank', 'explicit_kernel', 'Generic explicit graph13 or safety3 only; not full logical provider/controller proof validation.'), ('point-kernel-safety3', ('normal-refusal-and-input-ownership', 'checkpoint-path-and-cursor-ownership', 'first-fault-and-retained-owned-identity'), 3, 'explicit_bank', 'explicit_kernel', 'Generic explicit graph13 or safety3 only; not full logical provider/controller proof validation.'), ('tiny-full-provider10', ('duplicate-HYP-table-full-domain', 'GEN-full-formula-valued-identities', 'MP-full-formula-valued-identities', 'E1-singleton-requires-full-EOF', 'full-Gamma-outside-envelope-blocks-GEN', 'full-Gamma-unblocked-GEN-counterpart', 'out-of-envelope-goal-stays-boundary', 'remote-ports-rebind-retained-parent', 'initial-inspection-not-tried-remainder', 'inventory-first-fault-no-prefix'), 10, 'tiny_bank', 'provider', 'Restricted profile0,b<=3,n<=4 full-row membership; not all-FPC runtime qualification. Current provider subject is5; only the original explicitly scoped facets are tested.'), ('full-frame-controller10', ('protocol-dead-before-forced', 'protocol-no-forcing-unresolved', 'protocol-global-single-before-earlier-branch', 'protocol-parent-offer-remainder', 'protocol-fuel-not-child-failure', 'protocol-first-fault-no-normal-result', 'real-tiny-candidate-frame-agreement', 'real-tiny-empty-frame-agreement', 'dovetail-first-prefix-budget-restarts', 'public-strict-int-and-input-identity'), 10, 'controller_bank', 'controller', 'Protocol stubs/schedule/intake plus separately identified real tiny positive/empty/reuse facets; no theorem discovery authority. Current provider subject is5; only the original explicitly scoped facets are tested.'), ('constructor-index14', ('shape-H1-ancestor-descendant', 'shape-H2-ancestor-descendant', 'shape-H3-ancestor-descendant', 'shape-Q1-ancestor-descendant', 'shape-Q2-ancestor-descendant', 'shape-Q3-ancestor-descendant', 'shape-E1-ancestor-descendant', 'shape-E2-ancestor-descendant', 'shape-induction-empty-prefix-core', 'shape-induction-nonempty-prefix-core', 'helper-first-fault-identities', 'public-cursor-first-fault-poison', 'public-tiny-identities-order-remainders', 'public-incompatible-shape-EOF'), 14, 'conclusion_index_bank', 'legacy_provider', 'New separately scoped necessary-predicate54 literal cases across10 groups, helper faults, Source-bound public fault/poison, original tiny full-identity/order/remainder/SINGLE EOF and new generic empty single-row b5. Not a public full-profile inventory equivalence, scheduler, cleanup, practical benefit or proof-admission qualification. Original26 declarations remain distinct and unchanged. Subject is separately imported exact provider4, never current6.'), ('fixed-free-slot8', ('rigid-visible-logical-equations', 'Q1-free-terms-public-order-EOF', 'E2-free-body-binder-forward-aliases', 'induction-prefix-singleton-forward', 'MP-fixed-B-reset-unfilled-reference-order', 'GEN-full-Gamma-unfilled-reference-domain', 'absent-output-typed-slots-source-aliases', 'restriction-first-fault-parent-remainder'), 8, 'fixed_slot_bank', 'provider', 'Independent private rigid equation/typed-slot plus public tiny full identity/order/EOF/remainder/fault controls; legacy4 only common literal-set/order comparison. No all26 or full-profile/large-E2/cleanup/performance authority.'), ('matched-controller8', ('protocol-global-dead-before-singleton', 'protocol-unresolved-row-ties-no-MRV', 'protocol-remote-dependency-and-exact-undo', 'protocol-owned-offer-remainder-backtrack', 'protocol-phase-fuel-first-fault-and-diagnostics', 'real-duplicate-identities-and-empty-EOF', 'real-E1-two-row-Cartesian-reuse', 'real-full-Gamma-remote-contradictions'), 8, 'matched_controller_bank', 'csp_controller', 'Five independent protocol groups and three real provider6 facets for BOTH matched_point_controller and csp_controller; same49field observation and common14phase clock. Oracle complete tiny sets, driver first exports only. No all-profile equivalence or cleanup/fault-sweep proof.'), ('selector6', ('selector-tree-order', 'selector-atom-renaming', 'selector-Boolean-eligibility', 'selector-single-axiom-exclusion', 'selector-distinct-prefix-and-stop', 'selector-envelope-and-first-fault'), 6, 'selector_bank', 'selector', 'Fresh independent input-only prefix/Boolean/pattern/slot/fault qualification. No proof/query-byte/producer authority; STOP branch runtime coverage remains explicit. Original192 scope objects unchanged.'), ('nonwrapper_selector6', ('literal-helper-facts', 'canonical-occurrence-and-copying', 'malformed-envelope-owned-refusals', 'complete-ordered-winning-prefixes', 'first-and-retained-callback-identity', 'fresh-call-and-slot-isolation'), 6, 'nonwrapper_selector_bank', 'nonwrapper_selector', 'New selector public endpoint controls only; selected control slots are not research input authority.'), ('signed_propositional8_successor_v2', ('compiler-signed-rules-and-source-occurrences', 'strict-invalid-tree-refusals', 'search-closed-rule-counts-and-primitive-validation', 'total-countermodels-and-second-split-branch', 'malformed-unsupported-mode-and-EOF', 'configuration-module-and-owned-refusals', 'normal-FINAL-counts-and-owned-snapshot-isolation', 'first-retained-fault-and-stale-diagnostic-identity'), 8, 'signed_bank', 'signed_producer', 'Exact original8 semantic obligations/IDs on explicit compiler Source3 publicVERSION2, producer Source3 VERSION2 and signed-bank2. No retargeting/admission/retry of failed legacy1.'), ('occurrence_diagnostics9', ('unused-LOCAL-root-and-both-split-branches', 'equal-LOCAL-used-outer-unused-inner', 'shared-original-source-boundary', 'ordered-Gamma-and-finite-table-aliases', 'LOCAL-equal-to-surviving-root-Gamma', 'nested-composite-LOCAL-substitution', 'exact-diagnostic-intake-refusals', 'normal-FINAL-transport-and-no-compiler-paths', 'first-callback-retained-and-malformed-sink-identity'), 9, 'occurrence_bank', 'signed_producer/signed_compiler', 'Nine additional independently authored occurrence/mathematical/diagnostic groups; Source2 bank VERSION1/98 fixed direct call locators. Complete only after all facets, no research proof or legacy-prefix authority.'))
_BANK_ORDER = (
    'baseline56', 'obligation47', 'intro_integration1', 'regression2',
    'point20', 'explicit16', 'tiny-full-provider10', 'full-frame-controller10',
    'constructor-index14', 'fixed-free-slot8', 'matched-controller8',
    'selector6', 'nonwrapper_selector6', 'signed_propositional8_successor_v2',
    'occurrence_diagnostics9',
)
_CAPS = (
    ('work_seconds', 160), ('positive_seconds', 180),
    ('custody_seconds', 210), ('observer_fallback_seconds', 225),
    ('memory_bytes', 1073741824), ('physical_bytes', 134217728),
    ('result_bytes', 50331648), ('log_bytes', 4194304),
    ('reserved_outer_bytes', 9437184), ('root_callbacks', 400000000),
)
_ENVELOPE_KEYS = (
    'schema', 'profile', 'scope_manifest', 'bank_roots', 'control_index',
    'nodes', 'blobs', 'qualification_root', 'capture_root',
    'canonical_qualification',
)


class EvidenceFormatError(ValueError):
    """Public construction is unowned; reason/path are diagnostic only."""
    def __init__(self, message):
        super().__init__(message)
        self._reason = None
        self._path = None
        self._owner = None
        self._token = None

    @property
    def reason(self):
        return self._reason

    @property
    def path(self):
        return self._path


class _Array(tuple):
    """Private immutable snapshot array, never a public input type."""


class _Object(tuple):
    """Private immutable sorted key/value snapshot."""


class _Call:
    def __init__(self, check):
        self.check = check
        self.policy = None
        self.first = None
        self.token = object()
        if not callable(check):
            self.fail('INVALID_CODEC_CALL', ('check',))
        self.tick()

    def latch(self, error):
        if self.first is None:
            self.first = error
        return self.first

    def fail(self, reason, path):
        if self.first is not None:
            raise self.first
        error = EvidenceFormatError(reason)
        error._reason = reason
        error._path = tuple(path)
        error._owner = _OWNER
        error._token = self.token
        self.first = error
        raise error

    def need(self, condition, reason, path):
        if not condition:
            self.fail(reason, path)

    def tick(self):
        if self.first is not None:
            raise self.first
        try:
            self.check()
        except BaseException as error:
            raise self.latch(error)
        if self.policy is not None:
            try:
                current = sys.get_int_max_str_digits()
            except BaseException as error:
                raise self.latch(error)
            self.need(type(current) is int and current == self.policy,
                      'REFERENCE_INTEGER_POLICY_CHANGED',
                      ('reference_integer_policy',))

    def bind_policy(self, binding):
        path = ('reference_integer_policy',)
        self.need(type(binding) is tuple and len(binding) == 2,
                  'INVALID_REFERENCE_INTEGER_POLICY_BINDING', path)
        self.need(type(binding[0]) is str and type(binding[1]) is int,
                  'INVALID_REFERENCE_INTEGER_POLICY_BINDING', path)
        self.need(binding[0] == 'FPC-original-json-integer-policy-v1'
                  and binding[1] >= 0,
                  'INVALID_REFERENCE_INTEGER_POLICY_BINDING', path)
        try:
            current = sys.get_int_max_str_digits()
        except BaseException as error:
            raise self.latch(error)
        self.need(type(current) is int and current == binding[1],
                  'INVALID_REFERENCE_INTEGER_POLICY_BINDING', path)
        self.policy = current


def _str_compare(left, right, call):
    limit = min(len(left), len(right))
    offset = 0
    while offset < limit:
        call.tick()
        end = min(limit, offset + SOURCE_CHUNK)
        for index in range(offset, end):
            a, b = ord(left[index]), ord(right[index])
            if a != b:
                return -1 if a < b else 1
        offset = end
    return (len(left) > len(right)) - (len(left) < len(right))


def _str_equal(left, right, call):
    if len(left) != len(right):
        return False
    return _str_compare(left, right, call) == 0


def _sorted_keys(keys, call):
    # Checked stable bottom-up merge; no unbounded native string comparison.
    width = 1
    current = keys
    while width < len(current):
        target = []
        for start in range(0, len(current), 2 * width):
            call.tick()
            a, b = start, min(start + width, len(current))
            a_end, b_end = b, min(start + 2 * width, len(current))
            while a < a_end or b < b_end:
                call.tick()
                if b == b_end or (a < a_end and
                        _str_compare(current[a], current[b], call) <= 0):
                    target.append(current[a]); a += 1
                else:
                    target.append(current[b]); b += 1
        current = target
        width *= 2
    return current


def _snapshot(value, call, path, reason):
    """Checked owned acyclic tree snapshot, no caller container retained."""
    frames = []
    active = set()
    pending = (value, path)
    result = None
    while True:
        if pending is not None:
            call.tick()
            current, here = pending
            pending = None
            kind = type(current)
            if current is None or kind in (bool, int, float, str):
                if kind is float:
                    call.need(math.isfinite(current), reason, here)
                result = current
            else:
                call.need(kind in (list, tuple, dict), reason, here)
                identity = id(current)
                call.need(identity not in active, 'CYCLIC_INPUT', here)
                active.add(identity)
                keys = None
                if kind is dict:
                    keys = []
                    # Check every key type BEFORE lookup/sort/hash/equality.
                    for key in current:
                        call.tick()
                        call.need(type(key) is str, reason, here)
                        keys.append(key)
                    keys = _sorted_keys(keys, call)
                count = len(current)
                frames.append([current, keys, 0, count, [], here, identity])
                if count:
                    key = keys[0] if keys is not None else 0
                    pending = (current[key], here + (key,))
                    continue
                frames.pop()
                active.remove(identity)
                result = _Object() if keys is not None else _Array()
        if not frames:
            return result
        call.tick()
        frame = frames[-1]
        source, keys, index, count, items, here, identity = frame
        if keys is None:
            items.append(result)
        else:
            items.append((keys[index], result))
        frame[2] += 1
        if frame[2] < count:
            key = keys[frame[2]] if keys is not None else frame[2]
            pending = (source[key], here + (key,))
        else:
            frames.pop()
            active.remove(identity)
            result = _Array(items) if keys is None else _Object(items)


def _get(obj, key, call, path, reason='INVALID_EVIDENCE'):
    call.need(type(obj) is _Object, reason, path)
    for name, value in obj:
        call.tick()
        if _str_equal(name, key, call):
            return value
    call.fail(reason, path + (key,))


def _keys(obj, expected, call, path, reason='INVALID_EVIDENCE'):
    call.need(type(obj) is _Object and len(obj) == len(expected), reason, path)
    names = []
    for name in expected:
        call.tick()
        names.append(name)
    names = _sorted_keys(names, call)
    for index, pair in enumerate(obj):
        call.tick()
        call.need(_str_equal(pair[0], names[index], call), reason, path)


def _integer_text(value, call, path):
    # Exact decimal conversion without invoking an unlimited native big-int str.
    call.tick()
    if value == 0:
        return '0'
    negative = value < 0
    rest = -value if negative else value
    chunks = []
    while rest:
        call.tick()
        rest, digit = divmod(rest, 1000000000)
        chunks.append(digit)
    head = str(chunks[-1])  # At most nine decimal digits.
    digits = len(head) + 9 * (len(chunks) - 1)
    call.need(call.policy == 0 or digits <= call.policy,
              'INTEGER_OUTSIDE_REFERENCE_CANON_DOMAIN', path)
    parts = ['-' if negative else '', head]
    for index in range(len(chunks) - 2, -1, -1):
        call.tick()
        parts.append(format(chunks[index], '09d'))
    return ''.join(parts)


def _decimal_valid(text, call, path):
    call.need(type(text) is str and bool(text), 'INVALID_EVIDENCE', path)
    start = 1 if text[0] == '-' else 0
    call.need(start < len(text), 'INVALID_EVIDENCE', path)
    call.need(text[start] != '0' or (start == 0 and len(text) == 1),
              'INVALID_EVIDENCE', path)
    for offset in range(start, len(text), SOURCE_CHUNK):
        call.tick()
        for index in range(offset, min(len(text), offset + SOURCE_CHUNK)):
            call.need('0' <= text[index] <= '9', 'INVALID_EVIDENCE', path)
    call.need(call.policy == 0 or len(text) - start <= call.policy,
              'INTEGER_OUTSIDE_REFERENCE_CANON_DOMAIN', path)


def _float_parts(value):
    return (struct.pack('>d', value).hex(),
            json.dumps(value, ensure_ascii=True, allow_nan=False,
                       separators=(',', ':')))


def _equal(left, right, call):
    stack = [(left, right)]
    while stack:
        call.tick()
        a, b = stack.pop()
        if type(a) is not type(b):
            return False
        kind = type(a)
        if kind is str:
            if not _str_equal(a, b, call):
                return False
        elif kind is int:
            if not _str_equal(_integer_text(a, call, ()),
                              _integer_text(b, call, ()), call):
                return False
        elif kind is float:
            if struct.pack('>d', a) != struct.pack('>d', b):
                return False
        elif kind in (_Array, _Object):
            if len(a) != len(b):
                return False
            for index in range(len(a) - 1, -1, -1):
                call.tick()
                if kind is _Array:
                    stack.append((a[index], b[index]))
                else:
                    if not _str_equal(a[index][0], b[index][0], call):
                        return False
                    stack.append((a[index][1], b[index][1]))
        elif a != b:
            return False
    return True


def _expected_manifest(call):
    values = []
    for population, ids, groups, bank_role, subject_role, scope in _EXPECTED_SCOPE:
        call.tick()
        copied_ids = []
        for control_id in ids:
            call.tick()
            copied_ids.append(control_id)
        values.append(dict(population=population, control_ids=copied_ids,
                           groups=groups, bank_role=bank_role,
                           subject_role=subject_role, scope=scope))
    return _snapshot(values, call, ('scope_manifest',), 'INVALID_CODEC_CALL')


def _validate_limits(limits, call):
    owned = _snapshot(limits, call, ('limits',), 'INVALID_CODEC_CALL')
    names = []
    for name, expected in _CAPS:
        call.tick()
        names.append(name)
    _keys(owned, tuple(names), call, ('limits',),
          'INVALID_CODEC_CALL')
    for key, expected in _CAPS:
        call.tick()
        value = _get(owned, key, call, ('limits',), 'INVALID_CODEC_CALL')
        call.need(type(value) is int and value == expected,
                  'INVALID_CODEC_CALL', ('limits', key))
    return owned


def _descriptor_equal(left, right, call):
    if left[0] != right[0] or len(left) != len(right):
        return False
    tag = left[0]
    if tag == 'N':
        return True
    if tag == 'B':
        return left[1] is right[1]
    if tag in ('I', 'S'):
        return _str_equal(left[1], right[1], call)
    if tag == 'F':
        return (_str_equal(left[1], right[1], call)
                and _str_equal(left[2], right[2], call))
    if len(left[1]) != len(right[1]):
        return False
    for index in range(len(left[1])):
        call.tick()
        a, b = left[1][index], right[1][index]
        if tag == 'A':
            if a != b:
                return False
        elif a[1] != b[1] or not _str_equal(a[0], b[0], call):
            return False
    return True


def _descriptor_hash(desc, call):
    digest = hashlib.sha256()
    digest.update(desc[0].encode('ascii'))
    pieces = []
    if desc[0] in ('I', 'S'):
        pieces.append(desc[1])
    elif desc[0] == 'F':
        pieces.extend((desc[1], desc[2]))
    elif desc[0] == 'B':
        pieces.append('1' if desc[1] else '0')
    elif desc[0] in ('A', 'O'):
        for item in desc[1]:
            call.tick()
            if desc[0] == 'A':
                pieces.append(str(item))
            else:
                pieces.extend((item[0], str(item[1])))
    for piece in pieces:
        call.tick()
        digest.update(b'|')
        for offset in range(0, len(piece), SOURCE_CHUNK):
            call.tick()
            digest.update(piece[offset:offset + SOURCE_CHUNK].encode(
                'utf-8', 'surrogatepass'))
    return digest.digest()


class _Pool:
    def __init__(self, call):
        self.call = call
        self.nodes = []
        self.buckets = {}

    def intern(self, desc):
        self.call.tick()
        digest = _descriptor_hash(desc, self.call)
        bucket = self.buckets.get(digest)
        if bucket is not None:
            for ref in bucket:
                self.call.tick()
                if _descriptor_equal(self.nodes[ref], desc, self.call):
                    return ref
        ref = len(self.nodes)
        self.nodes.append(desc)
        if bucket is None:
            self.buckets[digest] = [ref]
        else:
            bucket.append(ref)
        return ref


def _pack(value, pool, call, path):
    frames = []
    pending = (value, path)
    result = None
    while True:
        if pending is not None:
            call.tick()
            value, here = pending
            pending = None
            kind = type(value)
            if kind in (_Array, _Object):
                if value:
                    frames.append([value, here, 0, []])
                    child = value[0] if kind is _Array else value[0][1]
                    key = 0 if kind is _Array else value[0][0]
                    pending = (child, here + (key,))
                    continue
                result = pool.intern(('A' if kind is _Array else 'O', ()))
            elif value is None:
                result = pool.intern(('N',))
            elif kind is bool:
                result = pool.intern(('B', value))
            elif kind is int:
                result = pool.intern(('I', _integer_text(value, call, here)))
            elif kind is float:
                bits, token = _float_parts(value)
                result = pool.intern(('F', bits, token))
            else:
                call.need(kind is str, 'INVALID_EVIDENCE', here)
                result = pool.intern(('S', value))
        if not frames:
            return result
        call.tick()
        frame = frames[-1]
        value, here, index, children = frame
        kind = type(value)
        children.append(result if kind is _Array else (value[index][0], result))
        frame[2] += 1
        if frame[2] < len(value):
            key = frame[2] if kind is _Array else value[frame[2]][0]
            child = value[frame[2]] if kind is _Array else value[frame[2]][1]
            pending = (child, here + (key,))
        else:
            frames.pop()
            result = pool.intern(('A' if kind is _Array else 'O', tuple(children)))


def _thaw(value, call):
    frames = []
    pending = value
    have = True
    result = None
    while True:
        if have:
            call.tick()
            have = False
            if type(pending) in (_Array, _Object):
                container = pending
                if container:
                    frames.append([container, 0, []])
                    pending = container[0] if type(container) is _Array else container[0][1]
                    have = True
                    continue
                result = [] if type(container) is _Array else {}
            else:
                result = pending
        if not frames:
            return result
        call.tick()
        frame = frames[-1]
        container, index, children = frame
        children.append(result if type(container) is _Array else (container[index][0], result))
        frame[1] += 1
        if frame[1] < len(container):
            pending = container[frame[1]] if type(container) is _Array else container[frame[1]][1]
            have = True
        else:
            frames.pop()
            if type(container) is _Array:
                result = children
            else:
                result = {}
                for key, child in children:
                    call.tick()
                    result[key] = child


def _node_export(desc, call):
    tag = desc[0]
    if tag in ('N', 'B', 'I', 'F', 'S'):
        return list(desc)
    children = []
    for child in desc[1]:
        call.tick()
        children.append(child if tag == 'A' else [child[0], child[1]])
    return [tag, children]


def _node_child(nodes, ref, key, call, path, reason):
    call.tick()
    desc = nodes[ref]
    if type(key) is str:
        call.need(desc[0] == 'O', reason, path)
        for name, child in desc[1]:
            call.tick()
            if _str_equal(name, key, call):
                return child
    elif type(key) is int and key >= 0 and desc[0] == 'A':
        call.need(key < len(desc[1]), reason, path)
        return desc[1][key]
    call.fail(reason, path)


def _lookup(nodes, root, path, call, reason, error_path=None):
    ref = root
    walked = ()
    for key in path:
        call.tick()
        walked += (key,)
        ref = _node_child(nodes, ref, key, call,
                          walked if error_path is None else error_path, reason)
    return ref


def _indices(nodes, root, call):
    index = []
    for population, ids, groups, bank_role, subject_role, scope in _EXPECTED_SCOPE:
        call.tick()
        if population == 'point-kernel13':
            bank = 'explicit16'; prefix = (bank, 'raw_population', 'controls')
        elif population == 'point-kernel-safety3':
            bank = 'explicit16'; prefix = (bank, 'additional_population', 'controls')
        else:
            bank = population; prefix = (bank, 'controls')
        controls = _lookup(nodes, root, prefix, call, 'INVALID_EVIDENCE')
        call.need(nodes[controls][0] == 'A' and len(nodes[controls][1]) == groups,
                  'INVALID_EVIDENCE', prefix)
        for number, control_id in enumerate(ids):
            call.tick()
            path = prefix + (number,)
            row = nodes[controls][1][number]
            identity = _node_child(nodes, row, 'id', call, path, 'INVALID_EVIDENCE')
            call.need(nodes[identity][0] == 'S'
                      and _str_equal(nodes[identity][1], control_id, call),
                      'INVALID_EVIDENCE', path + ('id',))
            index.append(dict(population=population, id=control_id, bank_key=bank,
                              path=list(path), row_ref=row))
    return index


class _Output:
    def __init__(self, call, writer):
        self.call = call
        self.writer = writer
        self.buffer = bytearray()
        self.bytes = 0
        self.digest = hashlib.sha256()

    def put(self, body):
        offset = 0
        while offset < len(body):
            self.call.tick()
            count = min(OUTPUT_CHUNK - len(self.buffer), len(body) - offset)
            self.buffer.extend(body[offset:offset + count])
            offset += count
            if len(self.buffer) == OUTPUT_CHUNK:
                self.flush()

    def flush(self):
        if not self.buffer:
            return
        self.call.tick()
        body = bytes(self.buffer)
        if self.writer is not None:
            try:
                self.writer(body)
            except BaseException as error:
                raise self.call.latch(error)
        self.digest.update(body)
        self.bytes += len(body)
        self.buffer.clear()

    def string(self, text):
        self.put(b'"')
        for offset in range(0, len(text), SOURCE_CHUNK):
            self.call.tick()
            token = json.dumps(text[offset:offset + SOURCE_CHUNK],
                               ensure_ascii=True, allow_nan=False)
            self.put(token[1:-1].encode('ascii'))
        self.put(b'"')


def _stream(nodes, root, call, writer):
    out = _Output(call, writer)
    stack = [('node', root, 0)]
    while stack:
        call.tick()
        action, item, index = stack.pop()
        if action == 'node':
            desc = nodes[item]
            tag = desc[0]
            if tag == 'N':
                out.put(b'null')
            elif tag == 'B':
                out.put(b'true' if desc[1] else b'false')
            elif tag in ('I', 'F'):
                token = desc[1] if tag == 'I' else desc[2]
                for offset in range(0, len(token), SOURCE_CHUNK):
                    call.tick()
                    out.put(token[offset:offset + SOURCE_CHUNK].encode('ascii'))
            elif tag == 'S':
                out.string(desc[1])
            elif tag == 'A':
                out.put(b'[')
                stack.append(('array', desc[1], 0))
            else:
                out.put(b'{')
                stack.append(('object', desc[1], 0))
        elif action == 'array':
            if index == len(item):
                out.put(b']')
            else:
                if index:
                    out.put(b',')
                stack.append(('array', item, index + 1))
                stack.append(('node', item[index], 0))
        else:
            if index == len(item):
                out.put(b'}')
            else:
                if index:
                    out.put(b',')
                out.string(item[index][0])
                out.put(b':')
                stack.append(('object', item, index + 1))
                stack.append(('node', item[index][1], 0))
    out.put(b'\n')
    out.flush()
    return dict(schema=READBACK_SCHEMA, complete=True, bytes=out.bytes,
                sha256=out.digest.hexdigest())


class _Handle:
    def __init__(self, call):
        self._call = call
        self._state = 'OPEN'

    def _enter(self, allowed):
        call = self._call
        if call.first is not None:
            raise call.first
        if self._state == 'CLOSED':
            call.fail('INVALID_SESSION_STATE', ('state',))
        call.tick()
        call.need(self._state == allowed, 'INVALID_SESSION_STATE', ('state',))

    def _abort(self, error):
        self._state = 'POISONED'
        return self._call.latch(error)

    def close(self):
        # Callback-free, no native getter, no promise of constant-time decref.
        self._state = 'CLOSED'
        self._release()
        return None


class _Encoder(_Handle):
    def __init__(self, call, manifest, limits):
        super().__init__(call)
        self._manifest = manifest
        self._limits = limits
        self._pool = _Pool(call)
        self._roots = []

    def _release(self):
        self._manifest = None
        self._limits = None
        self._pool = None
        self._roots = None

    def add_bank(self, bank_key, complete_value):
        try:
            self._enter('OPEN')
            call = self._call
            call.need(type(bank_key) is str, 'INVALID_CODEC_CALL', ('bank_key',))
            call.need(len(self._roots) < len(_BANK_ORDER)
                      and _str_equal(bank_key, _BANK_ORDER[len(self._roots)], call),
                      'INVALID_SESSION_STATE', ('state',))
            owned = _snapshot(complete_value, call, (bank_key,), 'INVALID_EVIDENCE')
            call.need(type(owned) is _Object, 'INVALID_EVIDENCE', (bank_key,))
            ref = _pack(owned, self._pool, call, (bank_key,))
            self._roots.append((bank_key, ref))
            return ref
        except BaseException as error:
            raise self._abort(error)

    def finish(self):
        try:
            self._enter('OPEN')
            call = self._call
            call.need(len(self._roots) == len(_BANK_ORDER),
                      'INVALID_SESSION_STATE', ('state',))
            names = []
            for name, ref in self._roots:
                call.tick()
                names.append(name)
            keys = _sorted_keys(names, call)
            pairs = []
            for name in keys:
                call.tick()
                for bank_key, ref in self._roots:
                    call.tick()
                    if _str_equal(name, bank_key, call):
                        pairs.append((name, ref)); break
            root = self._pool.intern(('O', tuple(pairs)))
            controls = _indices(self._pool.nodes, root, call)
            measured = _stream(self._pool.nodes, root, call, None)
            nodes = []
            for desc in self._pool.nodes:
                call.tick()
                nodes.append(_node_export(desc, call))
            bank_roots = []
            for name, ref in self._roots:
                call.tick()
                bank_roots.append(dict(bank_key=name, root=ref))
            envelope = dict(schema=SCHEMA, profile=PROFILE,
                scope_manifest=_thaw(self._manifest, call), bank_roots=bank_roots,
                control_index=controls, nodes=nodes, blobs=[],
                qualification_root=root, capture_root=None,
                canonical_qualification=dict(bytes=measured['bytes'],
                                             sha256=measured['sha256']))
            call.tick()
            self._state = 'FINISHED'
            return envelope
        except BaseException as error:
            raise self._abort(error)


def open_encoder(*, scope_manifest, profile, limits, check,
                 reference_integer_policy):
    call = _Call(check)
    try:
        call.bind_policy(reference_integer_policy)
        call.need(type(profile) is str and _str_equal(profile, PROFILE, call),
                  'INVALID_CODEC_CALL', ('profile',))
        owned_limits = _validate_limits(limits, call)
        manifest = _snapshot(scope_manifest, call, ('scope_manifest',),
                             'INVALID_CODEC_CALL')
        call.need(_equal(manifest, _expected_manifest(call), call),
                  'INVALID_CODEC_CALL', ('scope_manifest',))
        return _Encoder(call, manifest, owned_limits)
    except BaseException as error:
        raise call.latch(error)


def _reference(value, limit, call, path):
    call.need(type(value) is int and 0 <= value < limit,
              'INVALID_EVIDENCE', path)
    return value


def _lower_hex(text, size, call, path):
    call.need(type(text) is str and len(text) == size,
              'INVALID_EVIDENCE', path)
    for offset in range(0, len(text), SOURCE_CHUNK):
        call.tick()
        for index in range(offset, min(len(text), offset + SOURCE_CHUNK)):
            call.need(text[index] in '0123456789abcdef',
                      'INVALID_EVIDENCE', path)


def _parse_nodes(raw_nodes, call):
    base = ('envelope', 'nodes')
    call.need(type(raw_nodes) is _Array and len(raw_nodes) > 0,
              'INVALID_EVIDENCE', base)
    pool = _Pool(call)
    for number, value in enumerate(raw_nodes):
        call.tick()
        path = base + (number,)
        call.need(type(value) is _Array and len(value) > 0,
                  'INVALID_EVIDENCE', path)
        tag = value[0]
        call.need(type(tag) is str and len(tag) == 1
                  and tag in ('N', 'B', 'I', 'F', 'S', 'A', 'O'),
                  'INVALID_EVIDENCE', path + (0,))
        arity = 1 if tag == 'N' else 3 if tag == 'F' else 2
        call.need(len(value) == arity, 'INVALID_EVIDENCE', path)
        if tag == 'N':
            desc = ('N',)
        elif tag == 'B':
            call.need(type(value[1]) is bool, 'INVALID_EVIDENCE', path + (1,))
            desc = ('B', value[1])
        elif tag == 'I':
            _decimal_valid(value[1], call, path + (1,))
            desc = ('I', value[1])
        elif tag == 'F':
            _lower_hex(value[1], 16, call, path + (1,))
            call.need(type(value[2]) is str, 'INVALID_EVIDENCE', path + (2,))
            actual = struct.unpack('>d', bytes.fromhex(value[1]))[0]
            call.need(math.isfinite(actual), 'INVALID_EVIDENCE', path + (1,))
            bits, token = _float_parts(actual)
            call.need(_str_equal(bits, value[1], call)
                      and _str_equal(token, value[2], call),
                      'INVALID_EVIDENCE', path)
            desc = ('F', bits, token)
        elif tag == 'S':
            call.need(type(value[1]) is str, 'INVALID_EVIDENCE', path + (1,))
            desc = ('S', value[1])
        else:
            children = value[1]
            call.need(type(children) is _Array, 'INVALID_EVIDENCE', path + (1,))
            entries = []
            prior = None
            for index, child in enumerate(children):
                call.tick()
                here = path + (1, index)
                if tag == 'A':
                    entries.append(_reference(child, number, call, here))
                else:
                    call.need(type(child) is _Array and len(child) == 2,
                              'INVALID_EVIDENCE', here)
                    name = child[0]
                    call.need(type(name) is str, 'INVALID_EVIDENCE', here + (0,))
                    if prior is not None:
                        call.need(_str_compare(prior, name, call) < 0,
                                  'INVALID_EVIDENCE', here + (0,))
                    prior = name
                    entries.append((name, _reference(child[1], number, call,
                                                     here + (1,))))
            desc = (tag, tuple(entries))
        # Hashes are hints: intern performs full checked descriptor equality.
        call.need(pool.intern(desc) == number, 'INVALID_EVIDENCE', path)
    return pool


def _bank_roots(owned, nodes, call):
    base = ('envelope', 'bank_roots')
    call.need(type(owned) is _Array and len(owned) == len(_BANK_ORDER),
              'INVALID_EVIDENCE', base)
    result = []
    for index, expected in enumerate(_BANK_ORDER):
        call.tick()
        record = owned[index]
        path = base + (index,)
        _keys(record, ('bank_key', 'root'), call, path)
        name = _get(record, 'bank_key', call, path)
        call.need(type(name) is str and _str_equal(name, expected, call),
                  'INVALID_EVIDENCE', path + ('bank_key',))
        ref = _reference(_get(record, 'root', call, path), len(nodes), call,
                         path + ('root',))
        call.need(nodes[ref][0] == 'O', 'INVALID_EVIDENCE', path + ('root',))
        result.append((name, ref))
    return tuple(result)


def _canonical_forest(nodes, banks, root, call):
    seen = set()
    next_id = 0
    roots = []
    for name, ref in banks:
        call.tick()
        roots.append(ref)
    roots.append(root)
    for start in roots:
        call.tick()
        stack = [(start, 0)]
        while stack:
            call.tick()
            ref, index = stack.pop()
            if ref in seen:
                continue
            desc = nodes[ref]
            count = len(desc[1]) if desc[0] in ('A', 'O') else 0
            if index < count:
                stack.append((ref, index + 1))
                child = desc[1][index] if desc[0] == 'A' else desc[1][index][1]
                if child not in seen:
                    stack.append((child, 0))
            else:
                call.need(ref == next_id, 'INVALID_EVIDENCE',
                          ('envelope', 'nodes', ref))
                seen.add(ref)
                next_id += 1
    call.need(next_id == len(nodes), 'INVALID_EVIDENCE', ('envelope', 'nodes'))


class _Reader(_Handle):
    def __init__(self, call, envelope, limits, nodes, root, measured):
        super().__init__(call)
        self._state = 'READY'
        self._envelope = envelope
        self._limits = limits
        self._nodes = nodes
        self._root = root
        self._bytes = measured['bytes']
        self._sha256 = measured['sha256']

    def _release(self):
        self._envelope = None
        self._limits = None
        self._nodes = None
        self._root = None
        self._bytes = None
        self._sha256 = None

    def write_existing_json(self, write):
        try:
            self._enter('READY')
            call = self._call
            call.need(callable(write), 'INVALID_CODEC_CALL', ('write',))
            measured = _stream(self._nodes, self._root, call, write)
            call.need(measured['bytes'] == self._bytes
                      and _str_equal(measured['sha256'], self._sha256, call),
                      'INVALID_EVIDENCE', ('envelope', 'canonical_qualification'))
            call.tick()
            return measured
        except BaseException as error:
            raise self._abort(error)

    def write_value_json(self, path, write):
        try:
            self._enter('READY')
            call = self._call
            call.need(callable(write), 'INVALID_CODEC_CALL', ('write',))
            call.need(type(path) in (list, tuple), 'INVALID_CODEC_CALL', ('path',))
            owned_path = []
            for index, part in enumerate(path):
                call.tick()
                call.need(type(part) is str or (type(part) is int and part >= 0),
                          'INVALID_CODEC_CALL', ('path', index))
                owned_path.append(part)
            ref = _lookup(self._nodes, self._root, tuple(owned_path), call,
                          'INVALID_CODEC_CALL', ('path',))
            measured = _stream(self._nodes, ref, call, write)
            call.tick()
            return measured
        except BaseException as error:
            raise self._abort(error)


def open_reader(envelope, *, limits, check, reference_integer_policy):
    call = _Call(check)
    try:
        call.bind_policy(reference_integer_policy)
        owned_limits = _validate_limits(limits, call)
        owned = _snapshot(envelope, call, ('envelope',), 'INVALID_EVIDENCE')
        _keys(owned, _ENVELOPE_KEYS, call, ('envelope',))
        for field, expected in (('schema', SCHEMA), ('profile', PROFILE)):
            value = _get(owned, field, call, ('envelope',))
            call.need(type(value) is str and _str_equal(value, expected, call),
                      'INVALID_EVIDENCE', ('envelope', field))
        manifest = _get(owned, 'scope_manifest', call, ('envelope',))
        call.need(_equal(manifest, _expected_manifest(call), call),
                  'INVALID_EVIDENCE', ('envelope', 'scope_manifest'))
        blobs = _get(owned, 'blobs', call, ('envelope',))
        call.need(type(blobs) is _Array and len(blobs) == 0,
                  'INVALID_EVIDENCE', ('envelope', 'blobs'))
        call.need(_get(owned, 'capture_root', call, ('envelope',)) is None,
                  'INVALID_EVIDENCE', ('envelope', 'capture_root'))
        pool = _parse_nodes(_get(owned, 'nodes', call, ('envelope',)), call)
        nodes = pool.nodes
        banks = _bank_roots(_get(owned, 'bank_roots', call, ('envelope',)),
                            nodes, call)
        root = _reference(_get(owned, 'qualification_root', call, ('envelope',)),
                          len(nodes), call, ('envelope', 'qualification_root'))
        expected_pairs = []
        names = []
        for name, ref in banks:
            call.tick()
            names.append(name)
        names = _sorted_keys(names, call)
        for name in names:
            call.tick()
            for bank, ref in banks:
                call.tick()
                if _str_equal(name, bank, call):
                    expected_pairs.append((name, ref)); break
        call.need(_descriptor_equal(nodes[root], ('O', tuple(expected_pairs)), call),
                  'INVALID_EVIDENCE', ('envelope', 'qualification_root'))
        _canonical_forest(nodes, banks, root, call)
        actual_index = _get(owned, 'control_index', call, ('envelope',))
        expected_index = _snapshot(_indices(nodes, root, call), call,
                                   ('envelope', 'control_index'), 'INVALID_EVIDENCE')
        call.need(_equal(actual_index, expected_index, call),
                  'INVALID_EVIDENCE', ('envelope', 'control_index'))
        canonical = _get(owned, 'canonical_qualification', call, ('envelope',))
        base = ('envelope', 'canonical_qualification')
        _keys(canonical, ('bytes', 'sha256'), call, base)
        count = _get(canonical, 'bytes', call, base)
        digest = _get(canonical, 'sha256', call, base)
        call.need(type(count) is int and count >= 0, 'INVALID_EVIDENCE', base + ('bytes',))
        _integer_text(count, call, base + ('bytes',))
        _lower_hex(digest, 64, call, base + ('sha256',))
        measured = _stream(nodes, root, call, None)
        call.need(count == measured['bytes']
                  and _str_equal(digest, measured['sha256'], call),
                  'INVALID_EVIDENCE', base)
        # Drop the hash lookup index normally; only owned immutable nodes remain.
        immutable_nodes = tuple(nodes)
        pool.buckets.clear()
        call.tick()
        return _Reader(call, owned, owned_limits, immutable_nodes, root, measured)
    except BaseException as error:
        raise call.latch(error)
