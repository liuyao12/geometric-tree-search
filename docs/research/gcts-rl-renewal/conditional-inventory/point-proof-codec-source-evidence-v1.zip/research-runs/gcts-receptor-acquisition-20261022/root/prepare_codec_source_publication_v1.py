"""Administrative Source milestone packaging; never imports research modules."""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent
OLD = ROOT / 'publication-output-qualification-v2'
P2 = ROOT.parents[1] / 'gcts-batch-20261020' / 'publisher-recovery-6338a77'
PREFIX = 'docs/research/gcts-rl-renewal/conditional-inventory/'


def body_json(value):
    return (json.dumps(value, indent=2, ensure_ascii=True, allow_nan=False) + '\n').encode()


def pin(body):
    return dict(bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def emit(path, body):
    with path.open('xb') as stream:
        stream.write(body)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--catalog', required=True)
    args = parser.parse_args()
    catalog_path = Path(args.catalog)
    catalog = json.loads(catalog_path.read_bytes())
    assert catalog['scientific_execution'] is False
    assert catalog['new_qualified_suites'] == 0 and catalog['new_research_proofs'] == 0
    output = ROOT / 'publication-codec-source-v1'
    staging = P2 / 'publication-payload-codec-source-v1'
    assert not output.exists() and not staging.exists()
    output.mkdir()
    staging.mkdir()
    entries = []
    zip_path = output / 'point-proof-codec-source-evidence-v1.zip'
    with zipfile.ZipFile(zip_path, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for record in catalog['archive_files']:
            path = Path(record['path'])
            assert path.is_relative_to(ROOT.parent) or path == ROOT.parents[2] / 'docs/basic-tiling-algorithm.md'
            assert not path.is_symlink()
            body = path.read_bytes()
            assert pin(body) == {key: record[key] for key in ('bytes', 'sha256')}
            name = path.relative_to(ROOT.parents[2]).as_posix()
            assert name not in {row['name'] for row in entries}
            archive.writestr(name, body)
            entries.append(dict(name=name, **pin(body)))
        archive.writestr('milestone-catalog.json', catalog_path.read_bytes())
        entries.append(dict(name='milestone-catalog.json', **pin(catalog_path.read_bytes())))
    with zipfile.ZipFile(zip_path) as archive:
        assert archive.testzip() is None
        assert archive.namelist() == [row['name'] for row in entries]
        for row in entries:
            assert pin(archive.read(row['name'])) == {key: row[key] for key in ('bytes', 'sha256')}
    public = {key: value for key, value in catalog.items() if key != 'archive_files'}
    public.update(schema='Root-codec-Source-publication-manifest-v1', members=entries,
                  archive=pin(zip_path.read_bytes()), archive_member_count=len(entries))
    manifest_name = 'point-proof-codec-source-manifest-v1.json'
    emit(output / manifest_name, body_json(public))
    old_report = (OLD / 'point-proof-parallel-progress-v1.html').read_text()
    assert pin(old_report.encode())['sha256'] == '34b4a322a5d4f98822bb6b33b7c2ae1fff8072d9fa96ec69dae98bc44c98a3ac'
    style = old_report.split('<style>', 1)[1].split('</style>', 1)[0]
    html = '''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Parallel proof-search research: Source milestone</title>
<script>window.MathJax={tex:{inlineMath:[['\\\\(','\\\\)']],displayMath:[['\\\\[','\\\\]']]},options:{skipHtmlTags:['script','noscript','style','pre','code']}};</script>
<script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js"></script>
<style>''' + style + '''
.status{font-size:13px;letter-spacing:.06em;text-transform:uppercase;color:var(--amber);font-weight:700}.fact{font-size:32px;line-height:1.2;display:block;color:var(--teal)}.trace{display:grid;grid-template-columns:1.2fr 1fr 1.2fr;gap:16px;align-items:stretch}.trace>div{padding:20px;background:#edf4f1;border:1px solid var(--rule);border-radius:10px}.trace .shared{background:#f1edf8;border-color:#cbbce0}.occ{padding:8px 12px;margin:8px 0;background:white;border-left:5px solid var(--teal)}.occ.purple{border-left-color:var(--purple)}.trace h3{font-size:17px;margin-top:0}@media(max-width:760px){.trace{grid-template-columns:1fr}}
</style></head><body><main>
<p class="eyebrow">GCTS + RL research · 23 October 2026 UTC</p>
<h1>Parallel work is catching errors before experiments</h1>
<p>The lossless evidence codec and its independent control bank are now written. ''' + catalog['component_status_prose'] + ''' The eight new test groups remain unrun. There is no new theorem or successful whole qualification in this milestone.</p>
<p class="notice"><strong>Research remains active and incomplete.</strong> The latest measured qualification still failed at the 48 MiB output ceiling. A smaller complete report, useful reusable lemmas and a GCTS/RL advantage are all unestablished. <a href="point-proof-search-v1.html#codec-source-milestone">Main research notebook</a>.</p>
<section class="panel"><h2>Three roles, one integration point</h2><div class="grid">
<article class="card"><h3>Implementation</h3><p>Writes the transport under a fixed public contract. Exact repeated values may share storage; proof occurrences retain their own identities.</p><p class="status">''' + catalog['implementation_label'] + '''</p></article>
<article class="card"><h3>Independent controls</h3><p>Fixes expectations before seeing the codec algorithm. The controls compare readback with the original input, including every retained observation path.</p><p class="status">8 groups written · all unrun</p></article>
<article class="card"><h3>Critical review</h3><p>Reads the complete implementation and tests. Review found unsafe type classification and two diagnostic-path mismatches before execution.</p><p class="status">''' + catalog['review_label'] + '''</p></article>
</div><p class="caption">Root integrates the components, owns the serial measured runs and publishes the evidence. Other agents and unrelated tools are idle during a benchmark run.</p></section>
<section class="panel"><h2>The repair preserves observations while sharing values</h2><div class="trace" role="img" aria-label="Different observation occurrences can reference one exact typed value; readback restores each original path">
<div><h3>Original observations</h3><div class="occ">Control A · its own path</div><div class="occ purple">Control B · its own path</div><p>Two records may contain the same large value.</p></div>
<div class="shared"><h3>Shared typed value</h3><p>Store the exact value once. Keep both references, their order and their complete surrounding records.</p><p><strong>Equality is checked in full.</strong> A matching hash alone cannot merge values.</p></div>
<div><h3>Passive readback</h3><div class="occ">Control A · original value</div><div class="occ purple">Control B · original value</div><p>Stream the original JSON values at their original paths.</p></div>
</div><p class="caption">This diagram explains the representation. It is not measured evidence of size reduction. A self-consistent encoded hash cannot replace an independent comparison with the original input.</p></section>
<section class="panel"><h2>What is ready, and what remains open</h2><table><thead><tr><th>Layer</th><th>Current state</th></tr></thead><tbody>
<tr><td>Public representation</td><td>Specified: exact typed JSON values, complete roots and observation paths, checked readback, immutable owned inputs and first-error handling.</td></tr>
<tr><td>Implementation and independent bank</td><td>''' + catalog['component_status_prose'] + ''' Static parsing and compilation do not execute either component.</td></tr>
<tr><td>Original scientific observations</td><td>All 221 obligations across 15 wrappers stay separate from the synthetic codec controls. No qualified prefix of the failed run is admitted.</td></tr>
<tr><td>New transport controls</td><td>Eight prospective groups, with 168 declared public calls and 31 observations. These are Source declarations; all are unrun.</td></tr>
<tr><td>Whole integration</td><td>Worker integration, full caller review and a fresh bounded qualification remain open. No new whole-run denominator, grant or actual has been fixed.</td></tr>
<tr><td>Resource fit</td><td>Unmeasured. Original time, memory, physical storage and output limits remain. Both positive evidence pools must be withheld on whole failure.</td></tr>
</tbody></table></section>
<section class="panel"><h2>Why the independent review mattered</h2><p>A type-membership check could invoke an unsupported object's custom equality before rejecting it. The correction uses identity checks. Two further corrections keep Reader diagnostic paths consistent with the agreed public interface. These findings came from reading the code; no ad hoc test or scientific run was used.</p><p>''' + catalog['review_resolution_prose'] + ''' Native allocation, integer arithmetic and cleanup still have costs that Source review cannot bound tightly. Only a complete measured run can establish resource fit.</p></section>
<section class="panel"><h2>Return to the scientific question</h2><p>The useful comparison remains mechanically acquired receptor families against a matched ordinary prover with primitive fallback. Fresh checked donors must first supply the reusable material; a pre-frozen structural holdout must then require actual use of a family in a complete checked proof. Learned failure markings and RL should be tested as separate later factors.</p><p>This transport work changes neither the logic nor the search strategy. No learned inventory, GCTS/RL advantage or fixed finite universal Wang palette has been established. Arithmetic, symbolic Hilbert geometry and practical regional tiling remain research goals.</p></section>
<section class="panel" id="downloads"><h2>Inspect the Source and reviews</h2><p><a href="point-proof-codec-source-manifest-v1.json">Current Source milestone manifest</a> · <a href="point-proof-codec-source-evidence-v1.zip">Source, independent controls, contracts and reviews</a></p><p><a href="point-proof-output-qualification-data-v1.json">Latest measured outcome</a> · <a href="point-proof-output-qualification-evidence-v1.zip">Historical complete negative packet</a></p><p class="caption">The new archive is unexecuted Source evidence. The historical negative archive is unchanged. Original certificate bytes are still required for future proof admission; parsed values and hashes do not replace them.</p></section>
<footer>Several agents help by separating implementation, expected behavior and criticism. Research progress is assessed by complete checked proofs and matched experiments; parallel activity itself is not evidence of a mathematical or performance advantage.</footer>
</main></body></html>'''
    emit(output / 'point-proof-parallel-progress-v1.html', html.encode())
    report = (OLD / 'point-proof-search-v1.html').read_text()
    assert pin(report.encode())['sha256'] == 'a1cbbd8044ec786fa433dc2b5602867c9501431907e6834424e46667ff6b2237'
    notice = '<p class="notice" id="codec-source-current"><strong>Source milestone · 23 October 2026 UTC.</strong> The lossless codec and independent eight-group bank are written; all eight groups remain unrun. ' + catalog['component_status_prose'] + ' Earlier implementation status labels below are historical. <a href="point-proof-parallel-progress-v1.html">Current parallel progress</a>.</p>'
    assert report.count('<nav>') == 1
    report = report.replace('<nav>', notice + '<nav>', 1)
    section = '<section class="panel" id="codec-source-milestone"><h2>Lossless transport: Source milestone</h2><p>' + catalog['component_status_prose'] + ' Independent expectations froze before codec algorithm intake. The new eight groups remain unrun; no new whole qualification or research proof follows.</p><p>The original 221 observations retain their own 15-root envelope. New synthetic codec evidence will be saved separately. Whole failure must withhold both positive pools; original resource ceilings remain.</p><p><a href="point-proof-parallel-progress-v1.html">Visual report</a> · <a href="point-proof-codec-source-manifest-v1.json">Manifest</a> · <a href="point-proof-codec-source-evidence-v1.zip">Source and reviews</a></p></section>'
    anchor = '<section class="panel" id="next">'
    assert report.count(anchor) == 1
    report = report.replace(anchor, section + anchor, 1)
    emit(output / 'point-proof-search-v1.html', report.encode())
    names = ['point-proof-search-v1.html', 'point-proof-parallel-progress-v1.html', manifest_name, zip_path.name]
    files = []
    for name in names:
        body = (output / name).read_bytes()
        emit(staging / name, body)
        assert (staging / name).read_bytes() == body
        files.append(dict(path=PREFIX + name, publisher_source=str(staging / name), **pin(body),
                          git_blob_sha1=hashlib.sha1(b'blob ' + str(len(body)).encode() + b'\0' + body).hexdigest()))
    record = dict(schema='Root-codec-Source-publication-staging-v1',
                  issued_utc=datetime.now(timezone.utc).isoformat(), files=files,
                  catalog=dict(path=str(catalog_path), **pin(catalog_path.read_bytes())),
                  archive_members_verified=len(entries), scientific_execution=False,
                  expected_remote={names[0]: dict(sha='0f2e1d7be4049d15d56844e094c6c9a83c2bbcff', size=56041),
                                   names[1]: dict(sha='917c563c61aa72ad3a8a41213cc06fe314e2a2da', size=10955)},
                  new_paths_must_be_absent=names[2:], published=False)
    emit(output / 'P2-staging.json', body_json(record))
    print(json.dumps(dict(staging=str(output / 'P2-staging.json'), files=len(files), archive_members=len(entries))))


if __name__ == '__main__':
    main()
