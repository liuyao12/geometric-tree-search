"""Inert conditional cluster-token REINFORCE actor; no solver, I/O or CLI.

Approximate scores guide ordering only. Concrete expansion validity belongs to
the point/CSP kernel and independent checker, never this proposal generator.
"""
import hashlib
import json
import math
import random
import time
from types import MappingProxyType

VERSION = 'GCTS-CLUSTER-TOKEN-ACTOR-v1'
FEATURES = ('stop', 'stop_size_fraction', 'anchor_domain_fraction',
            'relative_dx', 'relative_dy', 'relative_l1',
            'selected_mark_contact_fraction', 'partial_mark_contact_fraction',
            'active_conflict_fraction', 'mark_term_fraction',
            'same_type_as_first', 'literal_diversity_fraction')
OBS_FIELDS = ('schema', 'model_sha256', 'inventory_version', 'marking_version',
              'value_policy', 'selected', 'excluded', 'point', 'generation',
              'incident_domain', 'active_bitset')
POLICY_FIELDS = ('schema', 'feature_names', 'max_members', 'learning_rate',
                 'weight_clip', 'baseline_beta', 'weights', 'baseline', 'updates')
COST_FIELDS = ('preparation_elapsed_seconds', 'budget_callbacks', 'model_rows',
               'mark_terms', 'conflict_pairs', 'calls', 'fresh_calls',
               'pending_reuses', 'pending_drops', 'candidate_feature_visits',
               'tokens', 'stop_tokens')
DELTA_FIELDS = ('candidate_feature_visits', 'tokens', 'stop_tokens',
                'pending_reuses', 'pending_drops', 'budget_callbacks')
CALL_FIELDS = ('index', 'mode', 'observation', 'observation_sha256', 'packet',
               'origin_call', 'original_members', 'root_selected', 'dropped',
               'skipped', 'tokens', 'descriptor', 'cost_delta', 'termination')
TOKEN_FIELDS = ('index', 'action_kind', 'placement_id', 'option_count',
                'probability', 'log_probability', 'features', 'gradient',
                'sample_u', 'partial_before')
SNAP_FIELDS = ('schema', 'model_sha256', 'id_order_sha256', 'policy_sha256',
               'policy', 'config', 'costs', 'calls', 'pending', 'family_scope')
FEEDBACK_FIELDS = ('status', 'verified_terminal', 'verification_sha256',
                   'required_points', 'max_verified_filled', 'attempts',
                   'branches', 'backtracks', 'actor_candidate_visits',
                   'certificate_kind')


class ActorError(ValueError):
    pass


class ActorUnsupportedProfile(ActorError):
    pass


class ActorBudgetExceeded(RuntimeError):
    pass


def _need(ok, message='ACTOR_INVALID_DATA'):
    if not ok:
        raise ActorError(message)


def _plain(value, depth=0, ancestors=()):
    """Detach plain data without callbacks/custom hooks while taking a copy."""
    _need(depth <= 64, 'ACTOR_DATA_DEPTH')
    kind = type(value)
    if value is None or kind in (str, bool, int):
        return value
    if kind is float:
        _need(math.isfinite(value), 'ACTOR_NONFINITE')
        return value
    _need(kind in (list, dict), 'ACTOR_NONPLAIN_DATA')
    _need(id(value) not in ancestors, 'ACTOR_DATA_CYCLE')
    chain = ancestors + (id(value),)
    if kind is list:
        return [_plain(x, depth + 1, chain) for x in value]
    _need(all(type(k) is str for k in value), 'ACTOR_NONSTRING_KEY')
    return {k: _plain(v, depth + 1, chain) for k, v in value.items()}


def _record(value, keys):
    _need(type(value) is dict and set(value) == set(keys), 'ACTOR_RECORD')


def _integer(value, minimum=0):
    _need(type(value) is int and value >= minimum, 'ACTOR_INTEGER')
    return value


def _number(value):
    _need(type(value) in (int, float), 'ACTOR_NUMBER')
    try:
        result = float(value)
    except (OverflowError, ValueError):
        raise ActorError('ACTOR_NUMBER') from None
    _need(math.isfinite(result), 'ACTOR_NUMBER')
    return result


def _point(value):
    _need(type(value) is list and len(value) == 2
          and all(type(x) is int for x in value), 'ACTOR_POINT')
    return tuple(value)


def _strings(value, *, ordered=False):
    _need(type(value) is list and all(type(x) is str for x in value)
          and len(value) == len(set(value)), 'ACTOR_IDS')
    if ordered:
        _need(value == sorted(value), 'ACTOR_ID_ORDER')
    return value


def _encoded(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       separators=(',', ':'), allow_nan=False) + '\n').encode()


def _sha(value):
    return hashlib.sha256(_encoded(value)).hexdigest()


class _Meter:
    def __init__(self, budget, costs):
        _need(budget is None or callable(budget), 'ACTOR_CALLBACK')
        self.budget, self.costs = budget, costs

    def tick(self):
        if self.budget is not None:
            self.costs['budget_callbacks'] += 1
            result = self.budget()
            if result is False:
                raise ActorBudgetExceeded('ACTOR_BUDGET')
            _need(result is None or result is True, 'ACTOR_CALLBACK_RETURN')


def new_policy(*, max_members=4, learning_rate=0.04, weight_clip=4.0,
               baseline_beta=0.2):
    _integer(max_members, 1)
    _need(max_members <= 256, 'ACTOR_MAX_MEMBERS')
    alpha, clip, beta = map(_number, (learning_rate, weight_clip, baseline_beta))
    _need(0 < alpha <= 1 and 0 < clip <= 16 and 0 < beta <= 1, 'ACTOR_POLICY_OPTIONS')
    return {'schema': 'GCTS-cluster-token-policy-v1', 'feature_names': list(FEATURES),
            'max_members': max_members, 'learning_rate': alpha, 'weight_clip': clip,
            'baseline_beta': beta, 'weights': [0.0] * 12, 'baseline': 0.0, 'updates': 0}


def _policy(value):
    _record(value, POLICY_FIELDS)
    _need(value['schema'] == 'GCTS-cluster-token-policy-v1'
          and value['feature_names'] == list(FEATURES), 'ACTOR_POLICY_SCHEMA')
    reference = new_policy(max_members=value['max_members'],
                           learning_rate=value['learning_rate'],
                           weight_clip=value['weight_clip'],
                           baseline_beta=value['baseline_beta'])
    _need(type(value['weights']) is list and len(value['weights']) == 12,
          'ACTOR_WEIGHT_VECTOR')
    for weight in value['weights']:
        _need(type(weight) is float and math.isfinite(weight)
              and abs(weight) <= reference['weight_clip'], 'ACTOR_WEIGHT')
    _need(type(value['baseline']) is float and math.isfinite(value['baseline']),
          'ACTOR_BASELINE')
    _integer(value['updates'])
    _need(type(value['learning_rate']) is float and type(value['weight_clip']) is float
          and type(value['baseline_beta']) is float, 'ACTOR_POLICY_CANONICAL')
    return value


def _model(value, meter):
    _record(value, ('schema', 'capacity', 'required', 'placements', 'seeds'))
    _need(type(value['schema']) is str and value['schema'] == 'GCTS-finite-point-instance-v1',
          'ACTOR_MODEL_SCHEMA')
    if type(value['capacity']) is not int or value['capacity'] != 1:
        raise ActorUnsupportedProfile('ACTOR_UNIT_CAPACITY_ONLY')
    _need(type(value['required']) is list and type(value['placements']) is list,
          'ACTOR_MODEL_LISTS')
    required = [_point(p) for p in value['required']]
    _need(required == sorted(set(required)), 'ACTOR_MODEL_CANONICAL')
    rows = {}
    for row in value['placements']:
        meter.tick()
        _record(row, ('id', 'type', 'translation', 't', 'm'))
        pid = row['id']
        _need(type(pid) is str and type(row['type']) is str and pid not in rows,
              'ACTOR_PLACEMENT_ID')
        translation = _point(row['translation'])
        if not (type(row['t']) is list and len(row['t']) == 1
                and type(row['t'][0]) is list and len(row['t'][0]) == 3
                and type(row['t'][0][2]) is int and row['t'][0][2] == 1):
            raise ActorUnsupportedProfile('ACTOR_UNIT_ANCHOR_ONLY')
        anchor = _point(row['t'][0][:2])
        _need(type(row['m']) is list, 'ACTOR_MARKS')
        marks = []
        seen = set()
        for term in row['m']:
            meter.tick()
            _need(type(term) is list and len(term) == 4, 'ACTOR_MARK_TERM')
            x, y = _point(term[:2])
            channel, literal = term[2:]
            _need(type(channel) is str and type(literal) is str
                  and (x, y, channel) not in seen, 'ACTOR_MARK_SLOT')
            seen.add((x, y, channel))
            marks.append((x, y, channel, literal))
        _need(marks == sorted(marks), 'ACTOR_MODEL_CANONICAL')
        rows[pid] = (row['type'], anchor, translation, tuple(marks))
    _need([row['id'] for row in value['placements']] == sorted(rows),
          'ACTOR_MODEL_CANONICAL')
    seeds = _strings(value['seeds'])
    _need(all(pid in rows for pid in seeds), 'ACTOR_SEEDS')
    _need(all(pid in seeds or row[1] in required for pid, row in rows.items()),
          'ACTOR_NONFRONTIER_UNIVERSE')
    _union(rows, seeds, meter)
    return rows


def _union(rows, members, meter):
    anchors, marks = set(), {}
    for pid in members:
        meter.tick()
        anchor, terms = rows[pid][1], rows[pid][3]
        _need(anchor not in anchors, 'ACTOR_CONTEXT_CAPACITY')
        anchors.add(anchor)
        for x, y, channel, value in terms:
            meter.tick()
            slot = (x, y, channel)
            _need(slot not in marks or marks[slot] == value, 'ACTOR_CONTEXT_MARKING')
            marks[slot] = value
    return marks


class ClusterProposer:
    def __init__(self, model, policy, *, seed, continuations=True,
                 inventory_version='BASE', marking_version='MODEL', budget=None):
        started = time.perf_counter()
        frozen_model, frozen_policy = _plain(model), _plain(policy)
        _integer(seed)
        _need(type(continuations) is bool and type(inventory_version) is str
              and inventory_version and type(marking_version) is str and marking_version,
              'ACTOR_CONFIG')
        self._costs = {key: 0 for key in COST_FIELDS}
        self._meter = _Meter(budget, self._costs)
        self._meter.tick()
        _policy(frozen_policy)
        rows = _model(frozen_model, self._meter)
        self._rows = MappingProxyType(rows)
        self._ids = tuple(sorted(rows))
        self._rank = MappingProxyType({pid: i for i, pid in enumerate(self._ids)})
        self._model_sha = _sha(frozen_model)
        self._id_sha = _sha(list(self._ids))
        self._policy_bytes = _encoded(frozen_policy)
        self._policy_sha = hashlib.sha256(self._policy_bytes).hexdigest()
        self._weights = tuple(frozen_policy['weights'])
        self._maximum = frozen_policy['max_members']
        self._config = {'seed': seed, 'continuations': continuations,
                        'inventory_version': inventory_version,
                        'marking_version': marking_version,
                        'max_pending': 64, 'selection': 'STOCHASTIC'}
        at_anchor, by_slot = {}, {}
        for pid in self._ids:
            self._meter.tick()
            row, bit = rows[pid], 1 << self._rank[pid]
            at_anchor[row[1]] = at_anchor.get(row[1], 0) | bit
            for x, y, channel, value in row[3]:
                self._meter.tick()
                groups = by_slot.setdefault((x, y, channel), {})
                groups[value] = groups.get(value, 0) | bit
        conflicts = []
        for pid in self._ids:
            self._meter.tick()
            row = rows[pid]
            bits = at_anchor[row[1]]
            for x, y, channel, value in row[3]:
                self._meter.tick()
                for other_value, group in by_slot[(x, y, channel)].items():
                    if other_value != value:
                        bits |= group
            conflicts.append(bits & ~(1 << self._rank[pid]))
        self._conflicts = tuple(conflicts)
        self._at_anchor = MappingProxyType(at_anchor)
        anchors = [row[1] for row in rows.values()]
        self._span = max(1, max((p[0] for p in anchors), default=0)
                         - min((p[0] for p in anchors), default=0),
                         max((p[1] for p in anchors), default=0)
                         - min((p[1] for p in anchors), default=0))
        self._max_marks = max(1, max((len(row[3]) for row in rows.values()), default=0))
        self._calls, self._pending = [], []
        self._costs['model_rows'] = len(rows)
        self._costs['mark_terms'] = sum(len(row[3]) for row in rows.values())
        self._costs['conflict_pairs'] = sum(bits.bit_count() for bits in conflicts) // 2
        self._costs['preparation_elapsed_seconds'] = time.perf_counter() - started

    def _observation(self, obs):
        _record(obs, OBS_FIELDS)
        _need(obs['schema'] == 'GCTS-cluster-receptor-observation-v1'
              and obs['model_sha256'] == self._model_sha
              and obs['inventory_version'] == self._config['inventory_version']
              and obs['marking_version'] == self._config['marking_version']
              and obs['value_policy'] == 'VALIDATED_CLUSTER_PREFERENCE_THEN_COMPLETE_LEX',
              'ACTOR_OBSERVATION_BINDING')
        _point(obs['point'])
        _need(type(obs['generation']) is int and obs['generation'] == 0,
              'ACTOR_ROOT0_ONLY')
        selected = _strings(obs['selected'])
        excluded = _strings(obs['excluded'], ordered=True)
        domain = _strings(obs['incident_domain'], ordered=True)
        _need(len(domain) >= 2 and all(pid in self._rows for pid in selected + excluded + domain)
              and not set(selected) & set(excluded), 'ACTOR_OBSERVATION_CONTEXT')
        encoded = obs['active_bitset']
        _record(encoded, ('encoding', 'id_order_sha256', 'universe_size', 'hex'))
        text, size = encoded['hex'], len(self._ids)
        _need(encoded['encoding'] == 'LSB0_HEX' and encoded['id_order_sha256'] == self._id_sha
              and type(encoded['universe_size']) is int and encoded['universe_size'] == size
              and type(text) is str and len(text) == 2 * ((size + 7) // 8)
              and all(c in '0123456789abcdef' for c in text), 'ACTOR_ACTIVE_ENCODING')
        bits = int.from_bytes(bytes.fromhex(text), 'little')
        _need(bits >> size == 0, 'ACTOR_ACTIVE_PADDING')
        active = [pid for i, pid in enumerate(self._ids) if bits & (1 << i)]
        _need(not (set(selected) | set(excluded)) & set(active)
              and set(domain) <= set(active)
              and all(self._rows[pid][1] == tuple(obs['point']) for pid in domain),
              'ACTOR_OBSERVATION_CONTEXT')
        marks = _union(self._rows, selected, self._meter)
        return bits, active, marks

    def _features(self, pid, partial, obs, bits, selected_marks, partial_marks):
        self._costs['candidate_feature_visits'] += 1
        if pid is None:
            return [1.0, len(partial) / self._maximum] + [0.0] * 10
        row = self._rows[pid]
        dx, dy = row[1][0] - obs['point'][0], row[1][1] - obs['point'][1]
        maximum_domain = max(1, max((v & bits).bit_count() for v in self._at_anchor.values()))
        denominator = max(1, len(row[3]))
        selected_contact = sum(selected_marks.get((x, y, c), None) == v
                               for x, y, c, v in row[3])
        partial_contact = sum(partial_marks.get((x, y, c), None) == v
                              for x, y, c, v in row[3])
        return [0.0, 0.0,
                (self._at_anchor[row[1]] & bits).bit_count() / maximum_domain,
                dx / self._span, dy / self._span,
                (abs(dx) + abs(dy)) / (2 * self._span),
                selected_contact / denominator, partial_contact / denominator,
                (self._conflicts[self._rank[pid]] & bits).bit_count() / max(1, bits.bit_count()),
                len(row[3]) / self._max_marks,
                float(bool(partial) and row[0] == self._rows[partial[0]][0]),
                len({term[3] for term in row[3]}) / denominator]

    def _sample(self, options, partial, obs, bits, selected_marks, token_index):
        partial_marks = _union(self._rows, partial, self._meter)
        feature_rows, scores, derivatives = [], [], []
        for pid in options:
            self._meter.tick()
            features = self._features(pid, partial, obs, bits, selected_marks, partial_marks)
            raw = sum(w * f for w, f in zip(self._weights, features))
            feature_rows.append(features)
            scores.append(max(-16.0, min(16.0, raw)))
            derivatives.append(features if -16.0 < raw < 16.0 else [0.0] * 12)
        largest = max(scores)
        exponentials = [math.exp(score - largest) for score in scores]
        total = sum(exponentials)
        probabilities = [value / total for value in exponentials]
        seed_record = {key: obs[key] for key in ('model_sha256', 'selected', 'excluded',
                                                'point', 'generation', 'incident_domain',
                                                'active_bitset')}
        seed_record.update(seed=self._config['seed'], call_index=len(self._calls),
                           token_index=token_index, partial_before=list(partial))
        uniform = random.Random(int(_sha(seed_record), 16)).random()
        cumulative, chosen = 0.0, len(options) - 1
        for index, probability in enumerate(probabilities):
            cumulative += probability
            if uniform < cumulative:
                chosen = index
                break
        expected = [sum(p * derivative[j] for p, derivative in zip(probabilities, derivatives))
                    for j in range(12)]
        gradient = [derivatives[chosen][j] - expected[j] for j in range(12)]
        pid = options[chosen]
        self._costs['tokens'] += 1
        self._costs['stop_tokens'] += pid is None
        token = {'index': token_index, 'action_kind': 'STOP' if pid is None else 'PLACE',
                 'placement_id': pid, 'option_count': len(options),
                 'probability': probabilities[chosen],
                 'log_probability': math.log(probabilities[chosen]),
                 'features': feature_rows[chosen], 'gradient': gradient,
                 'sample_u': uniform, 'partial_before': list(partial)}
        return pid, token

    def _descriptor(self, origin_point, members):
        classes, pattern = {}, []
        for pid in members:
            kind = self._rows[pid][0]
            if kind not in classes:
                classes[kind] = len(classes)
            pattern.append(classes[kind])
        return {'origin_point': list(origin_point),
                'relative_anchors': [[self._rows[pid][1][0] - origin_point[0],
                                      self._rows[pid][1][1] - origin_point[1]] for pid in members],
                'type_pattern': pattern}

    def __call__(self, observation):
        obs = _plain(observation)
        before = {key: self._costs[key] for key in DELTA_FIELDS}
        self._meter.tick()
        bits, active, selected_marks = self._observation(obs)
        index = len(self._calls)
        self._costs['calls'] += 1
        selected, excluded = set(obs['selected']), set(obs['excluded'])
        dropped, skipped, remaining, applicable = [], [], [], None
        for record in self._pending:
            self._meter.tick()
            members = record['members']
            if not set(record['origin_selected']) <= selected:
                reason = 'PARENT_CONTEXT_LOST'
            elif record['original_first'] not in selected:
                reason = 'FIRST_MEMBER_LOST'
            elif set(members) & excluded:
                reason = 'EXCLUDED'
            elif any(pid not in selected and pid not in active for pid in members):
                reason = 'INACTIVE'
            elif set(members) <= selected:
                reason = 'FULLY_REALIZED'
            else:
                reason = None
            if reason is not None:
                dropped.append({'origin_call': record['origin_call'], 'reason': reason})
                self._costs['pending_drops'] += 1
            else:
                remaining.append(record)
                if set(members) & set(obs['incident_domain']):
                    if applicable is None:
                        applicable = record
                else:
                    skipped.append({'origin_call': record['origin_call'], 'reason': 'NOT_INCIDENT'})
        self._pending = remaining
        tokens = []
        if applicable is not None:
            mode, termination = 'PENDING_REUSE', 'REUSE'
            self._costs['pending_reuses'] += 1
            original = list(applicable['members'])
            origin_call = applicable['origin_call']
            origin_sha = applicable['origin_observation_sha256']
            root_selected = list(applicable['origin_selected'])
            origin_point = list(applicable['origin_point'])
        else:
            mode, termination = 'FRESH', 'SIZE_CAP'
            self._costs['fresh_calls'] += 1
            original = []
            while len(original) < self._maximum:
                self._meter.tick()
                if not original:
                    options = list(obs['incident_domain'])
                else:
                    occupied = sum(1 << self._rank[pid] for pid in original)
                    options = [None] + [pid for pid in active if pid not in original
                                       and not (self._conflicts[self._rank[pid]] & occupied)]
                pid, token = self._sample(options, original, obs, bits,
                                           selected_marks, len(tokens))
                tokens.append(token)
                if pid is None:
                    termination = 'STOP'
                    break
                original.append(pid)
            origin_call, origin_sha = index, _sha(obs)
            root_selected, origin_point = list(obs['selected']), list(obs['point'])
            if self._config['continuations']:
                self._pending.append({'origin_call': index,
                                      'origin_observation_sha256': origin_sha,
                                      'origin_selected': list(root_selected),
                                      'origin_point': list(origin_point),
                                      'members': list(original), 'original_first': original[0],
                                      'model_sha256': self._model_sha,
                                      'inventory_version': self._config['inventory_version'],
                                      'marking_version': self._config['marking_version']})
                if len(self._pending) > self._config['max_pending']:
                    old = self._pending.pop(0)
                    dropped.append({'origin_call': old['origin_call'], 'reason': 'CACHE_LIMIT'})
                    self._costs['pending_drops'] += 1
        packet = {'schema': 'GCTS-concrete-cluster-proposals-v1',
                  'observation_sha256': _sha(obs),
                  'clusters': [{'id': 'ACTOR_CLUSTER:' + origin_sha,
                                'inventory_version': self._config['inventory_version'],
                                'marking_version': self._config['marking_version'],
                                'members': list(original)}]}
        record = {'index': index, 'mode': mode, 'observation': obs,
                  'observation_sha256': _sha(obs), 'packet': _plain(packet),
                  'origin_call': origin_call, 'original_members': list(original),
                  'root_selected': root_selected, 'dropped': dropped, 'skipped': skipped,
                  'tokens': tokens, 'descriptor': self._descriptor(origin_point, original),
                  'cost_delta': {key: self._costs[key] - before[key] for key in DELTA_FIELDS},
                  'termination': termination}
        self._calls.append(_plain(record))
        return _plain(packet)

    def snapshot(self):
        self._meter.tick()
        return _plain({'schema': 'GCTS-cluster-proposer-evidence-v1',
                       'model_sha256': self._model_sha, 'id_order_sha256': self._id_sha,
                       'policy_sha256': self._policy_sha, 'policy': json.loads(self._policy_bytes),
                       'config': self._config, 'costs': self._costs, 'calls': self._calls,
                       'pending': self._pending,
                       'family_scope': 'Conditional finite unit-anchor proposals, not proof lemmas; '
                                       'completion observed only at proposal contexts; actual '
                                       'member execution/causal effects require kernel/event joins.'})


def reinforce_update(policy, episode_evidence, feedback, *, budget=None):
    value, evidence, signal = _plain(policy), _plain(episode_evidence), _plain(feedback)
    costs = {'budget_callbacks': 0}
    meter = _Meter(budget, costs)
    meter.tick()
    _policy(value)
    _record(evidence, SNAP_FIELDS)
    _policy(evidence['policy'])
    _need(evidence['schema'] == 'GCTS-cluster-proposer-evidence-v1'
          and _sha(evidence['policy']) == _sha(value)
          and evidence['policy_sha256'] == _sha(value),
          'ACTOR_EPISODE_POLICY')
    _record(signal, FEEDBACK_FIELDS)
    _need(type(signal['status']) is str and signal['status'] in ('SAT', 'UNSAT', 'UNKNOWN')
          and type(signal['verified_terminal']) is bool, 'ACTOR_FEEDBACK_STATUS')
    _need((signal['status'] == 'UNKNOWN' and signal['verified_terminal'] is False
           and signal['certificate_kind'] == 'INCOMPLETE')
          or (signal['status'] in ('SAT', 'UNSAT') and signal['verified_terminal'] is True
              and signal['certificate_kind'] == signal['status']), 'ACTOR_FEEDBACK_CERTIFICATE')
    _need(type(signal['verification_sha256']) is str and len(signal['verification_sha256']) == 64
          and all(c in '0123456789abcdef' for c in signal['verification_sha256']),
          'ACTOR_FEEDBACK_ASSOCIATION')
    for key in ('required_points', 'max_verified_filled', 'attempts', 'branches',
                'backtracks', 'actor_candidate_visits'):
        _integer(signal[key])
    _need(signal['max_verified_filled'] <= signal['required_points'], 'ACTOR_FEEDBACK_PROGRESS')
    _record(evidence['costs'], COST_FIELDS)
    for key in COST_FIELDS:
        if key == 'preparation_elapsed_seconds':
            _need(type(evidence['costs'][key]) is float
                  and math.isfinite(evidence['costs'][key]) and evidence['costs'][key] >= 0,
                  'ACTOR_EPISODE_PREPARATION_COST')
        else:
            _integer(evidence['costs'][key])
    _need(signal['actor_candidate_visits'] == evidence['costs']['candidate_feature_visits'],
          'ACTOR_FEEDBACK_COST')
    _need(type(evidence['calls']) is list, 'ACTOR_EPISODE_CALLS')
    gradients = []
    for index, call in enumerate(evidence['calls']):
        meter.tick()
        _record(call, CALL_FIELDS)
        _need(type(call['index']) is int and call['index'] == index
              and call['mode'] in ('FRESH', 'PENDING_REUSE') and type(call['tokens']) is list,
              'ACTOR_EPISODE_CALL')
        _need(call['mode'] == 'FRESH' or not call['tokens'], 'ACTOR_REUSE_GRADIENT')
        for token_index, token in enumerate(call['tokens']):
            meter.tick()
            _record(token, TOKEN_FIELDS)
            _need(type(token['index']) is int and token['index'] == token_index
                  and token['action_kind'] in ('PLACE', 'STOP'), 'ACTOR_EPISODE_TOKEN')
            _need((token['action_kind'] == 'STOP' and token['placement_id'] is None)
                  or (token['action_kind'] == 'PLACE' and type(token['placement_id']) is str),
                  'ACTOR_EPISODE_TOKEN_ID')
            _integer(token['option_count'], 1)
            _need(0 < _number(token['probability']) <= 1
                  and 0 <= _number(token['sample_u']) < 1, 'ACTOR_EPISODE_PROBABILITY')
            _need(abs(_number(token['log_probability']) - math.log(token['probability'])) <= 1e-12,
                  'ACTOR_EPISODE_LOGPROBABILITY')
            for key in ('features', 'gradient'):
                _need(type(token[key]) is list and len(token[key]) == 12
                      and all(type(x) is float and math.isfinite(x) for x in token[key]),
                      'ACTOR_EPISODE_VECTOR')
            gradients.append(token['gradient'])
    _need(evidence['costs']['calls'] == len(evidence['calls'])
          and evidence['costs']['fresh_calls']
          == sum(call['mode'] == 'FRESH' for call in evidence['calls'])
          and evidence['costs']['pending_reuses']
          == sum(call['mode'] == 'PENDING_REUSE' for call in evidence['calls'])
          and evidence['costs']['tokens'] == len(gradients)
          and evidence['costs']['stop_tokens']
          == sum(token['action_kind'] == 'STOP' for call in evidence['calls']
                 for token in call['tokens'])
          and evidence['costs']['candidate_feature_visits']
          == sum(token['option_count'] for call in evidence['calls']
                 for token in call['tokens']), 'ACTOR_EPISODE_COUNTER_ASSOCIATION')
    terminal = 1.0 if signal['verified_terminal'] else 0.0
    shaping = 0.1 * signal['max_verified_filled'] / max(1, signal['required_points'])
    search_penalty = 0.005 * (signal['attempts'] + signal['branches'] + signal['backtracks'])
    proposal_penalty = 0.00001 * signal['actor_candidate_visits']
    reward = terminal + shaping - search_penalty - proposal_penalty
    advantage = reward - value['baseline']
    mean = [sum(row[j] for row in gradients) / max(1, len(gradients)) for j in range(12)]
    _need(math.isfinite(reward) and math.isfinite(advantage)
          and all(math.isfinite(x) for x in mean), 'ACTOR_UPDATE_NONFINITE')
    updated = _plain(value)
    clip, alpha = value['weight_clip'], value['learning_rate']
    fixed_scale = len(gradients) / value['max_members']
    updated['weights'] = [max(-clip, min(clip, w + alpha * advantage * g * fixed_scale))
                          for w, g in zip(value['weights'], mean)]
    beta = value['baseline_beta']
    updated['baseline'] = (1 - beta) * value['baseline'] + beta * reward
    updated['updates'] += 1
    _policy(updated)
    return {'schema': 'GCTS-cluster-token-policy-update-v1',
            'before_policy_sha256': _sha(value), 'after_policy': updated,
            'reward_terms': {'terminal': terminal, 'shaping': shaping,
                             'search_penalty': search_penalty,
                             'proposal_penalty': proposal_penalty, 'reward': reward},
            'advantage': advantage, 'mean_gradient': mean, 'token_count': len(gradients),
            'evidence_sha256': _sha(evidence), 'feedback': signal}
