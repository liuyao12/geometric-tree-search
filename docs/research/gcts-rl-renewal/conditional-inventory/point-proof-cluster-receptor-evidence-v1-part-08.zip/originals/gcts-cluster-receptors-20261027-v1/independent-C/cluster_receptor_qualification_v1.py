"""Independent public cluster-receipt checker and tiny qualification recipes.

AUTHORING ONLY: this module has not been imported, called, or tested.
No engine or actor imports, I/O, CLI, solver, or process-global evidence cache.
"""
import hashlib
import json
import math
import random
import time
from types import MappingProxyType

VERSION = 'GCTS-CLUSTER-RECEPTOR-INDEPENDENT-QUALIFICATION-v1'
POLICY = 'VALIDATED_CLUSTER_PREFERENCE_THEN_COMPLETE_LEX'
LEX = 'LEX_ID'
METRICS = ('branch_observations', 'proposer_calls', 'packets_rejected',
           'clusters_proposed', 'clusters_accepted', 'clusters_rejected',
           'joint_members_checked', 'joint_t_terms_checked',
           'joint_m_terms_checked', 'branch_order_changes', 'proposal_audit_calls')
OBS_KEYS = ('schema', 'model_sha256', 'inventory_version', 'marking_version',
            'value_policy', 'selected', 'excluded', 'point', 'generation',
            'incident_domain', 'active_bitset')
RECORD_KEYS = ('schema', 'index', 'status', 'observation', 'observation_sha256',
               'raw_packet', 'packet_rejection', 'clusters', 'ordered_candidates',
               'logical_before_sha256', 'logical_after_sha256', 'value_policy',
               'counters', 'error_type')
STATE_KEYS = ('schema', 'selected', 'assigned', 'excluded', 'physical_domains',
              'eligible_domains', 'active_candidates', 'forward_incidence',
              'reverse_incidence')


class ClusterQualificationError(ValueError):
    pass


class UnsupportedClusterProfile(ClusterQualificationError):
    pass


class ClusterQualificationBudgetExceeded(RuntimeError):
    pass


class _Clock:
    def __init__(self, budget):
        self.began = time.perf_counter()
        self.budget = budget
        self.calls = 0
        if budget is not None and not callable(budget):
            raise ClusterQualificationError('budget callable')

    def tick(self):
        if self.budget is not None:
            self.calls += 1
            value = self.budget()
            if value is False:
                raise ClusterQualificationBudgetExceeded('budget')
            if value is not None and value is not True:
                raise ClusterQualificationError('budget result')

    def costs(self):
        return {'elapsed_seconds': time.perf_counter() - self.began,
                'budget_callbacks': self.calls}


def _need(ok, reason):
    if not ok:
        raise ClusterQualificationError(reason)


def _copy(value, depth=0, path=None):
    """Exact metadata copy before callbacks; wrapper depth128, no custom hooks."""
    if path is None:
        path = set()
    if depth > 128:
        raise ClusterQualificationError('JSON depth')
    kind = type(value)
    if value is None or kind in (bool, int, str):
        return value
    if kind is float:
        _need(math.isfinite(value), 'finite JSON number')
        return value
    _need(kind in (list, dict), 'plain JSON data')
    ident = id(value)
    _need(ident not in path, 'JSON cycle')
    path.add(ident)
    try:
        if kind is list:
            return [_copy(x, depth + 1, path) for x in value]
        _need(all(type(k) is str for k in value), 'JSON string keys')
        return {k: _copy(v, depth + 1, path) for k, v in value.items()}
    finally:
        path.remove(ident)


def _bytes(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       separators=(',', ':'), allow_nan=False) + '\n').encode('utf-8')


def _sha(value):
    return hashlib.sha256(_bytes(value)).hexdigest()


def _eq(left, right, reason):
    _need(_bytes(left) == _bytes(right), reason)


def _keys(value, keys, reason):
    _need(type(value) is dict and set(value) == set(keys), reason)


def _int(value, reason, minimum=0):
    _need(type(value) is int and value >= minimum, reason)


def _text(value, reason, nonempty=False):
    _need(type(value) is str and (not nonempty or bool(value)), reason)


def _freeze(value):
    if type(value) is dict:
        return MappingProxyType({k: _freeze(v) for k, v in value.items()})
    if type(value) is list:
        return tuple(_freeze(x) for x in value)
    return value


class PreparedClusterModel:
    __slots__ = ('_raw', '_model', '_by_id', '_ids', '_points', '_at', '_hash',
                 '_order_hash', '_preparation', '_tag')

    def __setattr__(self, name, value):
        raise AttributeError('immutable prepared model')

    @property
    def version(self):
        return VERSION

    @property
    def model_sha256(self):
        return self._hash

    @property
    def id_order_sha256(self):
        return self._order_hash

    @property
    def preparation_costs(self):
        return dict(self._preparation)


class ProposalCursor:
    __slots__ = ('_model', '_index', '_counts', '_audit', '_versions', '_chain')

    def __setattr__(self, name, value):
        raise AttributeError('immutable proposal cursor')


def _prepared(value):
    _need(type(value) is PreparedClusterModel and getattr(value, '_tag', None) == VERSION,
          'prepared model handle')
    return value


def prepare_cluster_model(raw_model, *, budget=None):
    clock = _Clock(budget)
    raw = _copy(raw_model)
    clock.tick()
    _keys(raw, ('schema', 'capacity', 'required', 'placements', 'seeds'), 'model5')
    _need(raw['schema'] == 'GCTS-finite-point-instance-v1', 'model schema')
    _int(raw['capacity'], 'capacity', 1)
    if raw['capacity'] != 1:
        raise UnsupportedClusterProfile('capacity1')
    _need(type(raw['required']) is list and type(raw['placements']) is list and
          type(raw['seeds']) is list, 'model arrays')
    points = []
    for point in raw['required']:
        clock.tick()
        _need(type(point) is list and len(point) == 2 and
              all(type(v) is int for v in point), 'required exact point')
        points.append(tuple(point))
    _need(len(points) == len(set(points)), 'required unique')
    points.sort()
    rows = []
    ids = set()
    for placement in raw['placements']:
        clock.tick()
        _keys(placement, ('id', 'type', 'translation', 't', 'm'), 'placement5')
        _text(placement['id'], 'placement ID', True)
        _need(placement['id'] not in ids, 'placement duplicate')
        ids.add(placement['id'])
        _text(placement['type'], 'type')
        tr = placement['translation']
        _need(type(tr) is list and len(tr) == 2 and
              all(type(v) is int for v in tr), 'translation')
        _need(type(placement['t']) is list and type(placement['m']) is list,
              'support arrays')
        t_rows, m_rows = [], []
        for t in placement['t']:
            clock.tick()
            _need(type(t) is list and len(t) == 3 and
                  all(type(v) is int for v in t) and 0 < t[2] <= raw['capacity'],
                  'positive integer t')
            t_rows.append(t[:])
        _need(bool(t_rows) and len({tuple(t[:2]) for t in t_rows}) == len(t_rows),
              't support')
        if len(t_rows) != 1 or t_rows[0][2] != 1:
            raise UnsupportedClusterProfile('one unit anchor')
        _need(tuple(t_rows[0][:2]) in points or placement['id'] in raw['seeds'],
              'nonseed anchor touches required; seed may be exterior')
        for mark in placement['m']:
            clock.tick()
            _need(type(mark) is list and len(mark) == 4 and
                  type(mark[0]) is int and type(mark[1]) is int and
                  type(mark[2]) is str and type(mark[3]) is str, 'literal m row')
            m_rows.append(mark[:])
        _need(len({tuple(m[:3]) for m in m_rows}) == len(m_rows), 'unique m slot')
        rows.append({'id': placement['id'], 'type': placement['type'],
                     'translation': tr[:], 't': sorted(t_rows), 'm': sorted(m_rows)})
    rows.sort(key=lambda row: row['id'])
    _need(all(type(s) is str and s in ids for s in raw['seeds']) and
          len(raw['seeds']) == len(set(raw['seeds'])), 'seed IDs')
    normalized = {'schema': raw['schema'], 'capacity': 1,
                  'required': [list(p) for p in points], 'placements': rows,
                  'seeds': raw['seeds'][:]}
    handle = object.__new__(PreparedClusterModel)
    frozen = _freeze(normalized)
    for key, value in (('_raw', _bytes(raw)), ('_model', frozen),
                       ('_by_id', MappingProxyType({r['id']: r for r in frozen['placements']})),
                       ('_ids', tuple(r['id'] for r in rows)), ('_points', tuple(points)),
                       ('_at', MappingProxyType({p: tuple(r['id'] for r in rows
                                                        if tuple(r['t'][0][:2]) == p)
                                               for p in points})),
                       ('_hash', _sha(normalized)), ('_order_hash', _sha([r['id'] for r in rows])),
                       ('_tag', VERSION)):
        object.__setattr__(handle, key, value)
    seed_conflict, unused = _union(handle, list(raw['seeds']), [], clock)
    _need(seed_conflict is None, 'legal seed union')
    clock.tick()
    object.__setattr__(handle, '_preparation', tuple(clock.costs().items()))
    return handle


def _union(prepared, selected, new, clock):
    totals, marks = {}, {}
    work = {key: 0 for key in ('joint_members_checked', 'joint_t_terms_checked',
                               'joint_m_terms_checked')}
    order = selected + new
    for ident in order:
        clock.tick()
        work['joint_members_checked'] += 1
        for x, y, amount in prepared._by_id[ident]['t']:
            clock.tick()
            work['joint_t_terms_checked'] += 1
            point = (x, y)
            totals[point] = totals.get(point, 0) + amount
            if totals[point] > 1:
                return 'CAPACITY_CONFLICT', work
    for ident in order:
        clock.tick()
        for x, y, channel, value in prepared._by_id[ident]['m']:
            clock.tick()
            work['joint_m_terms_checked'] += 1
            slot = (x, y, channel)
            if slot in marks and marks[slot] != value:
                return 'MARKING_CONFLICT', work
            marks[slot] = value
    return None, work


def _state(prepared, supplied, clock):
    _keys(supplied, STATE_KEYS, 'normalized9')
    _need(supplied['schema'] == 'GCTS-unit-cell-normalized-state-v1', 'state schema')
    selected, excluded = supplied['selected'], supplied['excluded']
    _need(type(selected) is list and all(type(x) is str and x in prepared._by_id
                                       for x in selected) and
          len(selected) == len(set(selected)), 'selected IDs')
    _eq(selected[:len(prepared._model['seeds'])], list(prepared._model['seeds']),
        'seed order prefix')
    _need(type(excluded) is list, 'excluded array')
    ex = []
    for row in excluded:
        clock.tick()
        _keys(row, ('id', 'reason'), 'excluded2')
        _need(type(row['id']) is str and row['id'] in prepared._by_id and
              row['id'] not in selected, 'excluded ID')
        _text(row['reason'], 'excluded reason')
        ex.append(row['id'])
    _need(ex == sorted(set(ex)), 'sorted unique exclusions')
    conflict, unused = _union(prepared, selected, [], clock)
    _need(conflict is None, 'current selected union')
    occupied = {}
    for ident in selected:
        clock.tick()
        occupied[tuple(prepared._by_id[ident]['t'][0][:2])] = ident
    physical, eligible, forward, reverse = [], [], [], []
    for point in prepared._points:
        clock.tick()
        if point in occupied:
            continue
        domain = []
        for ident in prepared._at[point]:
            clock.tick()
            if ident in selected or tuple(prepared._by_id[ident]['t'][0][:2]) != point:
                continue
            conflict, unused = _union(prepared, selected, [ident], clock)
            if conflict is None:
                domain.append(ident)
        active = [ident for ident in domain if ident not in ex]
        physical.append({'point': list(point), 'candidates': domain})
        eligible.append({'point': list(point), 'generation': 0, 'candidates': active})
        for ident in active:
            forward.append([*point, ident, 1])
            reverse.append({'id': ident, 'points': [[*point, 1]]})
    active_ids = sorted(row['id'] for row in reverse)
    expected = {'schema': 'GCTS-unit-cell-normalized-state-v1',
                'selected': selected[:],
                'assigned': [{'point': list(p), 'id': ident}
                             for p, ident in sorted(occupied.items())
                             if ident not in prepared._model['seeds']],
                'excluded': excluded,
                'physical_domains': physical, 'eligible_domains': eligible,
                'active_candidates': active_ids, 'forward_incidence': forward,
                'reverse_incidence': sorted(reverse, key=lambda row: row['id'])}
    _eq(supplied, expected, 'complete independently reconstructed normalized state')
    return expected


def _observation(prepared, state, versions, clock):
    rows = state['eligible_domains']
    _need(rows and all(len(row['candidates']) >= 2 for row in rows),
          'proposal only after no global dead/forced')
    chosen = min(rows, key=lambda row: (row['generation'], len(row['candidates']),
                                       tuple(row['point'])))
    active = set(state['active_candidates'])
    packed = bytearray((len(prepared._ids) + 7) // 8)
    for i, ident in enumerate(prepared._ids):
        clock.tick()
        if ident in active:
            packed[i // 8] |= 1 << (i % 8)
    return {'schema': 'GCTS-cluster-receptor-observation-v1',
            'model_sha256': prepared.model_sha256,
            'inventory_version': versions[0], 'marking_version': versions[1],
            'value_policy': POLICY, 'selected': state['selected'][:],
            'excluded': [row['id'] for row in state['excluded']],
            'point': chosen['point'][:], 'generation': chosen['generation'],
            'incident_domain': chosen['candidates'][:],
            'active_bitset': {'encoding': 'LSB0_HEX',
                              'id_order_sha256': prepared.id_order_sha256,
                              'universe_size': len(prepared._ids), 'hex': packed.hex()}}


def _packet(prepared, observation, packet, declared_rejection, clock):
    domain = observation['incident_domain']
    delta = {key: 0 for key in METRICS}
    delta['branch_observations'] = delta['proposer_calls'] = 1
    rows, order = [], []
    rejection = None
    if declared_rejection == 'NON_JSON_PACKET':
        _need(packet is None, 'nonJSON stored null')
        rejection = 'NON_JSON_PACKET'
    elif packet is None:
        pass
    elif type(packet) is not dict or set(packet) != {'schema', 'observation_sha256', 'clusters'} or packet.get('schema') != 'GCTS-concrete-cluster-proposals-v1' or type(packet.get('clusters')) is not list:
        rejection = 'PACKET_SHAPE'
    elif type(packet['observation_sha256']) is not str or packet['observation_sha256'] != _sha(observation):
        rejection = 'PACKET_BINDING'
    elif len(packet['clusters']) > 64:
        rejection = 'PACKET_SIZE'
    else:
        reserved = set()
        selected = observation['selected']
        excluded = set(observation['excluded'])
        active_raw = bytes.fromhex(observation['active_bitset']['hex'])
        active = {ident for i, ident in enumerate(prepared._ids)
                  if active_raw[i // 8] & (1 << (i % 8))}
        for index, raw in enumerate(packet['clusters']):
            clock.tick()
            delta['clusters_proposed'] += 1
            row = {'index': index, 'raw_cluster': raw, 'id': None,
                   'shared_ids': [], 'new_ids': [], 'incident_ids': [],
                   'accepted': False, 'rejection': None}
            code = None
            if type(raw) is not dict or set(raw) != {'id', 'inventory_version', 'marking_version', 'members'}:
                code = 'CLUSTER_SHAPE'
            elif type(raw['id']) is not str or not raw['id'] or raw['id'] in reserved:
                code = 'CLUSTER_ID'
            else:
                row['id'] = raw['id']
                reserved.add(raw['id'])
                if type(raw['inventory_version']) is not str or type(raw['marking_version']) is not str or raw['inventory_version'] != observation['inventory_version'] or raw['marking_version'] != observation['marking_version']:
                    code = 'CLUSTER_VERSION'
                else:
                    members = raw['members']
                    if type(members) is not list or not members or len(members) > 256 or any(type(x) is not str for x in members) or len(set(members)) != len(members):
                        code = 'CLUSTER_MEMBERS'
                    elif any(x not in prepared._by_id for x in members):
                        code = 'UNKNOWN_MEMBER'
                    else:
                        shared = [x for x in members if x in selected]
                        new = [x for x in members if x not in selected]
                        incident = [x for x in new if x in domain]
                        row.update(shared_ids=shared, new_ids=new, incident_ids=incident)
                        if any(x in excluded for x in members):
                            code = 'EXCLUDED_MEMBER'
                        elif any(x not in active for x in new):
                            code = 'INACTIVE_MEMBER'
                        else:
                            code, work = _union(prepared, selected, new, clock)
                            for key, value in work.items():
                                delta[key] += value
                            if code is None and not incident:
                                code = 'NO_INCIDENT_MEMBER'
            row['rejection'] = code
            row['accepted'] = code is None
            delta['clusters_accepted' if code is None else 'clusters_rejected'] += 1
            if code is None:
                for ident in row['incident_ids']:
                    if ident not in order:
                        order.append(ident)
            rows.append(row)
    if rejection is not None:
        delta['packets_rejected'] = 1
    order.extend(x for x in domain if x not in order)
    delta['branch_order_changes'] = int(order != domain)
    return rejection, rows, order, delta


def verify_proposal_receipt(prepared, receipt, normalized_state, *, previous=None,
                            proposal_audit_enabled=False, inventory_version='BASE',
                            marking_version='MODEL', budget=None):
    clock = _Clock(budget)
    record, state = _copy(receipt), _copy(normalized_state)
    clock.tick()
    model = _prepared(prepared)
    _need(type(proposal_audit_enabled) is bool, 'audit enabled bool')
    _keys(record, RECORD_KEYS, 'proposal record14')
    _need(record['schema'] == 'GCTS-cluster-proposal-receipt-v1', 'receipt schema')
    _int(record['index'], 'receipt index')
    _keys(record['observation'], OBS_KEYS, 'observation11')
    versions = (record['observation']['inventory_version'],
                record['observation']['marking_version'])
    for value in versions:
        _text(value, 'version nonempty', True)
    _text(inventory_version, 'expected inventory version', True)
    _text(marking_version, 'expected marking version', True)
    _eq(list(versions), [inventory_version, marking_version], 'external constructor versions')
    current = _state(model, state, clock)
    observation = _observation(model, current, versions, clock)
    _eq(record['observation'], observation, 'complete actual observation and bitset')
    observation_hash = _sha(observation)
    for key in ('observation_sha256', 'logical_before_sha256'):
        _need(record[key] == observation_hash and type(record[key]) is str,
              'bound observation fingerprints')
    _need(record['logical_after_sha256'] == observation_hash or
          (record['status'] != 'VALIDATED' and record['logical_after_sha256'] is None),
          'normal unchanged or incomplete logical after hash')
    _need(record['value_policy'] == POLICY, 'declared alternate value policy')
    prior = {key: 0 for key in METRICS}
    index, chain = 0, ''
    if previous is not None:
        _need(type(previous) is ProposalCursor and previous._model is model and
              previous._audit is proposal_audit_enabled and previous._versions == versions,
              'same exact prepared/cursor/version/audit binding')
        prior = dict(previous._counts)
        index, chain = previous._index, previous._chain
    _need(record['index'] == index, 'complete consecutive attempt index')
    _keys(record['counters'], METRICS, 'proposal counters11')
    for value in record['counters'].values():
        _int(value, 'nonnegative exact counters')
    if record['status'] != 'VALIDATED':
        _need(record['status'] in ('PENDING', 'PROPOSER_EXCEPTION', 'INTERRUPTED'),
              'partial receipt status')
        _need(record['error_type'] is None or type(record['error_type']) is str,
              'partial first error type envelope')
        checks = {'current_state_and_observation': True, 'complete_order': False,
                  'partial_counters_observed_not_verified': record['counters']}
        return {'schema': 'GCTS-cluster-proposal-independent-verification-v1',
                'status': 'VERIFIED_NONFINAL_ENVELOPE_ONLY', 'verifier_version': VERSION,
                'model_sha256': model.model_sha256, 'receipt_sha256': _sha(record),
                'observation_sha256': observation_hash, 'index': index,
                'state_sha256': _sha(current), 'ordered_candidates': None,
                'counters': None, 'checks': checks,
                'scope': 'Partial exceptional receipt; no complete order/counter/negative certificate. Context and foreign-error origins require caller custody. No next cursor.',
                'costs': clock.costs()}, None
    _need(record['error_type'] is None, 'normal receipt no error')
    rejection, rows, order, delta = _packet(model, observation, record['raw_packet'],
                                           record['packet_rejection'], clock)
    _eq(record['packet_rejection'], rejection, 'packet rejection priority')
    _eq(record['clusters'], rows, 'every cluster row/union/reason')
    _eq(record['ordered_candidates'], order, 'complete validated order and lexical fallback')
    expected = {key: prior[key] + delta[key] for key in METRICS}
    _eq(record['counters'], expected, 'exact cumulative attempt and union work counters')
    next_counts = expected.copy()
    if proposal_audit_enabled:
        next_counts['proposal_audit_calls'] += 1
    cursor = object.__new__(ProposalCursor)
    for key, value in (('_model', model), ('_index', index + 1),
                       ('_counts', tuple(next_counts.items())), ('_audit', proposal_audit_enabled),
                       ('_versions', versions), ('_chain', _sha([chain, _sha(record)]))):
        object.__setattr__(cursor, key, value)
    return {'schema': 'GCTS-cluster-proposal-independent-verification-v1',
            'status': 'VERIFIED_COMPLETE_CLUSTER_ORDER', 'verifier_version': VERSION,
            'model_sha256': model.model_sha256, 'receipt_sha256': _sha(record),
            'observation_sha256': observation_hash, 'index': index,
            'state_sha256': _sha(current), 'ordered_candidates': order,
            'counters': expected,
            'checks': {'current_state_and_observation': True, 'complete_order': True,
                       'rows': len(rows), 'audit_snapshot_excludes_current_call': True,
                       'NON_JSON_origin_not_recoverable': rejection == 'NON_JSON_PACKET'},
            'scope': 'Exact current unit-profile observation, joint literals, complete permutation and cumulative recorded work. No private trail, producer intent or OS custody proof.',
            'costs': clock.costs()}, cursor


def _fixture(kind='plain'):
    """Source-literal tiny controls; factory is UNRUN during authorship."""
    def row(ident, x, marks):
        return {'id': ident, 'type': 'TYPE:' + ident, 'translation': [x, 0],
                't': [[x, 0, 1]], 'm': marks}
    placements = [row('A', 0, []), row('B', 0, []),
                  row('C', 2, []), row('D', 2, [])]
    required, seeds = [[0, 0], [2, 0]], []
    if kind in ('marks', 'fallback', 'unsat'):
        placements[0]['m'] = [[100, -7, 'REMOTE', '0']]
        placements[2]['m'] = [[100, -7, 'REMOTE', '0' if kind == 'marks' else '1']]
        placements[3]['m'] = [[100, -7, 'REMOTE', '1']]
        if kind == 'fallback':
            placements[1]['m'] = [[100, -7, 'REMOTE', '1']]
        elif kind == 'unsat':
            placements[1]['m'] = [[100, -7, 'REMOTE', '0']]
    elif kind in ('remote', 'exterior_seed'):
        if kind == 'remote':
            required.append([4, 0])
        seeds.append('S')
        placements.extend([row('S', 4, [[100, -7, 'REMOTE', '0']]), row('X', 0, [])])
        placements[1]['m'] = [[100, -7, 'REMOTE', '1']]
    elif kind == 'forced':
        required.append([4, 0])
        placements.append(row('S', 4, []))
    elif kind == 'three':
        placements.append(row('X', 0, []))
    elif kind == 'actor':
        for index, placement in enumerate(placements):
            placement['m'] = [[100, -7, 'REMOTE', '0']]
            placement['type'] = 'OPAQUE_TYPE:' + str(index % 2)
    elif kind == 'dead_forced':
        required.extend([[4, 0], [6, 0]])
        placements.append(row('S', 4, []))
    elif kind != 'plain':
        raise ClusterQualificationError('unknown fixture recipe')
    return {'schema': 'GCTS-finite-point-instance-v1', 'capacity': 1,
            'required': required, 'placements': placements, 'seeds': seeds}


def _cluster(observation, members, ident='CONTROL'):
    return {'id': ident, 'inventory_version': observation['inventory_version'],
            'marking_version': observation['marking_version'], 'members': list(members)}


def _proposal(observation, clusters):
    return {'schema': 'GCTS-concrete-cluster-proposals-v1',
            'observation_sha256': _sha(observation), 'clusters': clusters}


def _control_proposer(mode, trace, box):
    def proposer(observation):
        pristine = _copy(observation)
        trace.append(pristine)
        domain = pristine['incident_domain']
        first = domain[0]
        if mode == 'empty':
            return _proposal(pristine, [])
        if mode == 'none':
            return None
        if mode == 'foreign':
            raise box['sentinel']
        if mode == 'budget':
            box['interrupt'] = True
            return None
        if mode == 'stale':
            if 'old' not in box:
                box['old'] = _proposal(pristine, [_cluster(pristine, ['B'])])
            return _copy(box['old'])
        if mode == 'multi':
            members = ['B', 'D']
        elif mode == 'fresh_first_only':
            members = ['B', 'D'] if pristine['point'] == [0, 0] else [first]
        elif mode == 'shared':
            members = ['A', 'D']
        elif mode == 'seedshared':
            members = ['S', first]
        elif mode == 'duplicate':
            members = [first, first]
        elif mode == 'unknown':
            members = [first, 'FOREIGN_ID']
        elif mode == 'capacity':
            members = ['A', 'B']
        elif mode == 'mark_conflict':
            members = ['A', 'D']
        elif mode == 'assigned_zero':
            members = ['A', 'C']
        elif mode == 'absent':
            members = ['B', 'D']
        elif mode == 'remote':
            members = [first, 'B']
        elif mode == 'excluded':
            members = ['B', 'D']
        elif mode == 'inactive':
            members = ['B', 'D']
        elif mode == 'nonincident':
            members = ['C']
        elif mode == 'fallback':
            members = ['A'] if 'A' in domain else [first]
        else:
            members = [domain[-1]]
        packet = _proposal(pristine, [_cluster(pristine, members)])
        if mode == 'bad_packet':
            packet['extra'] = True
        elif mode == 'bad_binding':
            packet['observation_sha256'] = '0' * 64
        elif mode == 'packet_size':
            packet['clusters'] = [_cluster(pristine, [first], str(i)) for i in range(65)]
        elif mode == 'bad_cluster':
            packet['clusters'][0]['extra'] = 1
        elif mode == 'bad_id':
            packet['clusters'][0]['id'] = ''
        elif mode == 'bad_version':
            packet['clusters'][0]['marking_version'] = 'FOREIGN'
        elif mode == 'duplicate_cluster':
            packet['clusters'].append(_copy(packet['clusters'][0]))
        elif mode == 'alternatives':
            packet['clusters'] = [_cluster(pristine, ['A'], 'LEFT'),
                                  _cluster(pristine, ['B'], 'RIGHT')]
        elif mode == 'nonjson':
            return object()
        elif mode == 'mutate_observation':
            observation['selected'].append('FOREIGN_ID')
            observation['active_bitset']['hex'] = ''
        elif mode == 'alias_packet':
            box['alias'] = packet
        elif mode == 'reentrant':
            error_type = box['owned_error']
            try:
                box['engine'].place(first, 'FORBIDDEN_REENTRANCY')
            except error_type:
                box['reentrant_refused'] = True
            else:
                raise ClusterQualificationError('public callback reentrancy allowed')
        return packet
    return proposer


class _ForeignSentinel(RuntimeError):
    pass


def _exercise(P, C, O, model, role, mode, action, setup, clock, counters,
              actor_callable=None):
    """One actual tiny engine run only when the future qualifier is invoked."""
    def budget():
        clock.tick()
        if mode == 'alias_packet' and 'alias' in box and not box.get('alias_changed'):
            box['alias']['clusters'][0]['members'].append('FOREIGN_ID')
            box['alias_changed'] = True
        if box.get('interrupt', False):
            box['interrupt'] = False
            return False
        return True
    box, observations, events, proposal_checks = {}, [], [], []
    box['sentinel'] = _ForeignSentinel('qualification foreign callback')
    cm = prepare_cluster_model(model, budget=clock.tick)
    counters['C_preparations'] += 1
    om = O.prepare_model(model, budget=clock.tick)
    counters['L_preparations'] += 1
    proposer = (actor_callable if actor_callable is not None else
                None if mode == 'baseline' else _control_proposer(mode, observations, box))
    value_policy = LEX if proposer is None else POLICY
    spec = C.export_unit_cell_csp(model, value_policy=value_policy)
    counters['exports'] += 1
    os = O.prepare_unit_cell_spec(om, spec, budget=clock.tick)
    counters['L_spec_preparations'] += 1
    audit_cursor, proposal_cursor = [None], [None]
    def native_audit(engine, event):
        clock.tick()
        state = engine.snapshot()
        if role == 'point':
            checked, cursor = O.verify_point_event(om, state, event, audit_cursor[0],
                                                  value_policy=value_policy, budget=clock.tick)
        else:
            checked, cursor = O.verify_normalized_event(os, state, event,
                                                       audit_cursor[0], budget=clock.tick)
        counters['L_event_checks'] += 1
        _need(checked['status'] == 'VERIFIED', 'whole native event verified')
        audit_cursor[0] = cursor
        events.append({'event': _copy(event), 'state': _copy(state),
                       'independent': _copy(checked)})
    def current_normalized():
        state = box['engine'].snapshot()
        if role == 'point':
            checked = O.verify_point_snapshot(om, state, value_policy=value_policy,
                                               budget=clock.tick)
            counters['L_state_checks'] += 1
            return checked['normalized_state']
        checked = O.verify_normalized_state(os, state, budget=clock.tick)
        counters['L_state_checks'] += 1
        return checked['normalized_state']
    def proposal_audit(record):
        clock.tick()
        normal = current_normalized()
        lcheck = O.verify_cluster_receipt(om, normal, record, budget=clock.tick)
        counters['L_proposal_checks'] += 1
        ccheck, cursor = verify_proposal_receipt(cm, record, normal,
                                                 previous=proposal_cursor[0],
                                                 proposal_audit_enabled=True,
                                                 budget=clock.tick)
        counters['C_receipt_checks'] += 1
        _need(lcheck['status'] == 'VERIFIED' and
              ccheck['status'] == 'VERIFIED_COMPLETE_CLUSTER_ORDER', 'dual proposal checks')
        proposal_cursor[0] = cursor
        proposal_checks.append({'raw': _copy(record), 'state': _copy(normal),
                                'L': _copy(lcheck), 'C': _copy(ccheck)})
        if mode == 'audit_mutation':
            record['observation']['selected'].append('FOREIGN_ID')
    kwargs = {'audit': native_audit, 'budget': budget}
    if proposer is not None:
        kwargs.update(proposer=proposer, proposal_audit=proposal_audit)
    if role == 'point':
        engine = P.Engine(model, **kwargs)
        box['owned_error'] = P.EngineError
    else:
        engine = C.CellCSP(spec, **kwargs)
        box['owned_error'] = C.CSPError
    box['engine'] = engine
    counters['engine_instances'] += 1
    for kind, ident in setup:
        clock.tick()
        if kind == 'place':
            engine.place(ident, 'CONTROL_SELECTED')
        else:
            engine.exclude(ident, 'CONTROL_EXCLUDED')
    entry = engine.snapshot()
    checkpoint = engine.checkpoint()
    independent_checkpoint = O.checkpoint(om, entry, native=role == 'point', budget=clock.tick)
    counters['L_checkpoints'] += 1
    result, decision, foreign = None, None, None
    if mode == 'foreign':
        try:
            counters['solve_calls'] += 1
            engine.solve(node_limit=100)
        except _ForeignSentinel as exc:
            _need(exc is box['sentinel'], 'foreign exception identity')
            foreign = type(exc).__name__
        else:
            raise ClusterQualificationError('foreign exception swallowed')
        _eq(engine.snapshot(), entry, 'foreign exact solve restoration')
    elif action == 'solve':
        counters['solve_calls'] += 1
        result = engine.solve(node_limit=100)
        if role == 'point':
            result_check = O.verify_point_result(om, result, budget=clock.tick)
        else:
            result_check = O.verify_unit_cell_result(os, result, budget=clock.tick)
        counters['L_result_checks'] += 1
        _need(result_check['status'] == 'VERIFIED', 'whole result/certificate check')
        result_check = _copy(result_check)
    elif action == 'stale_sequence':
        counters['decision_calls'] += 2
        first_decision = engine.decision()
        engine.place('B', 'CONTROL_SELECTED')
        second_decision = engine.decision()
        decision = {'first': first_decision, 'second': second_decision}
    else:
        counters['decision_calls'] += 1
        decision = engine.decision()
        _eq(engine.snapshot(), entry, 'proposal decision does not change native state')
    final = engine.snapshot()
    final_normalized = current_normalized()
    evidence, metrics = engine.proposal_evidence, engine.proposal_metrics
    if mode not in ('foreign', 'budget') and proposal_cursor[0] is not None:
        _eq(metrics, dict(proposal_cursor[0]._counts), 'actual counters after audit callbacks')
    if mode == 'alias_packet':
        _need(box.get('alias_changed', False), 'postcopy alias mutation actually exercised')
    if mode == 'reentrant':
        _need(box.get('reentrant_refused', False), 'reentrant control reached')
    # Mutation of returned public evidence/properties must not alter stored history.
    saved_evidence = _copy(evidence)
    if evidence:
        evidence[0]['observation']['selected'].append('FOREIGN_ID')
    _eq(engine.proposal_evidence, saved_evidence, 'detached evidence getter')
    engine.rollback(checkpoint)
    _eq(engine.snapshot(), entry, 'exact public checkpoint/trail restoration')
    rollback_check = O.verify_rollback(om, independent_checkpoint, engine.snapshot(), budget=clock.tick)
    counters['L_rollback_checks'] += 1
    _need(rollback_check['status'] == 'VERIFIED', 'independent rollback')
    return {'role': role, 'mode': mode, 'action': action, 'model': _copy(model),
            'entry': entry, 'final': final, 'decision': decision,
            'final_normalized': final_normalized,
            'result': result, 'result_check': result_check if result is not None else None,
            'foreign': foreign, 'observations': observations,
            'proposal_evidence': saved_evidence, 'proposal_metrics': metrics,
            'proposal_checks': proposal_checks, 'events': events,
            'rollback': {'state': engine.snapshot(), 'independent': _copy(rollback_check)}}


def _receipt_forgery_controls(prepared, check, clock):
    original, state = check['raw'], check['state']
    _need(original['index'] == 0, 'forgeries use first independent receipt')
    mutations = (
        ('bitset', lambda r: r['observation']['active_bitset'].__setitem__('hex', '')),
        ('missing_alternative', lambda r: r['ordered_candidates'].pop()),
        ('counter', lambda r: r['counters'].__setitem__('joint_m_terms_checked',
                                    r['counters']['joint_m_terms_checked'] + 1)),
        ('index', lambda r: r.__setitem__('index', 1)),
        ('logical_hash', lambda r: r.__setitem__('logical_after_sha256', '0' * 64)),
        ('raw_packet', lambda r: r['raw_packet']['clusters'][0]['members'].append('FOREIGN_ID')),
        ('false_acceptance', lambda r: r['clusters'][0].__setitem__('accepted', False)),
        ('shared_ids', lambda r: r['clusters'][0]['shared_ids'].append('A')),
        ('policy', lambda r: r.__setitem__('value_policy', LEX)),
    )
    results = []
    for name, change in mutations:
        clock.tick()
        forged = _copy(original)
        change(forged)
        try:
            verify_proposal_receipt(prepared, forged, state,
                                    proposal_audit_enabled=True, budget=clock.tick)
        except ClusterQualificationError as exc:
            results.append({'name': name, 'rejected': True, 'reason': str(exc),
                            'forged': forged})
        else:
            raise ClusterQualificationError('forged receipt accepted: ' + name)
    return results


def run_cluster_qualification(point_module, csp_module, indexed_oracle_module,
                              actor_module, *, budget=None):
    """Only a separately granted caller may invoke these unexecuted recipes."""
    clock = _Clock(budget)
    clock.tick()
    P, C, O, A = point_module, csp_module, indexed_oracle_module, actor_module
    counters = {key: 0 for key in ('engine_instances', 'exports', 'solve_calls',
                'decision_calls', 'C_preparations', 'L_preparations',
                'L_spec_preparations', 'L_event_checks', 'L_state_checks',
                'L_proposal_checks', 'C_receipt_checks', 'L_result_checks',
                'L_checkpoints', 'L_rollback_checks', 'synthetic_selector_calls',
                'actor_objects', 'actor_updates')}
    # Recipes are not evaluated at authoring/import. Each produces two fresh roles.
    recipes = (
        ('baseline', 'plain', 'baseline', 'solve', (), None),
        ('empty', 'plain', 'empty', 'solve', (), None),
        ('none', 'plain', 'none', 'solve', (), None),
        ('multistep', 'plain', 'multi', 'solve', (), None),
        ('first_only_fresh', 'plain', 'fresh_first_only', 'solve', (), None),
        ('shared', 'plain', 'shared', 'solve', (('place', 'A'),), None),
        ('shared_seed', 'remote', 'seedshared', 'decision', (), None),
        ('exterior_seed', 'exterior_seed', 'seedshared', 'decision', (), None),
        ('duplicate_member', 'plain', 'duplicate', 'decision', (), 'CLUSTER_MEMBERS'),
        ('foreign_member', 'plain', 'unknown', 'decision', (), 'UNKNOWN_MEMBER'),
        ('capacity', 'plain', 'capacity', 'decision', (), 'CAPACITY_CONFLICT'),
        ('marking', 'marks', 'mark_conflict', 'decision', (), 'MARKING_CONFLICT'),
        ('assigned_zero', 'marks', 'assigned_zero', 'decision', (), None),
        ('absent', 'marks', 'absent', 'decision', (), None),
        ('remote_outside_Q', 'remote', 'remote', 'decision', (), 'INACTIVE_MEMBER'),
        ('excluded', 'three', 'excluded', 'decision', (('exclude', 'B'),), 'EXCLUDED_MEMBER'),
        ('inactive', 'plain', 'inactive', 'decision', (('place', 'A'),), 'INACTIVE_MEMBER'),
        ('nonincident', 'plain', 'nonincident', 'decision', (), 'NO_INCIDENT_MEMBER'),
        ('stale_context', 'plain', 'stale', 'stale_sequence', (), 'PACKET_BINDING'),
        ('mutated_observation', 'plain', 'mutate_observation', 'decision', (), None),
        ('postcopy_packet_alias', 'plain', 'alias_packet', 'decision', (), None),
        ('mutated_audit', 'plain', 'audit_mutation', 'decision', (), None),
        ('foreign_exception', 'plain', 'foreign', 'solve', (), None),
        ('owned_unknown', 'plain', 'budget', 'solve', (), None),
        ('dead_before_forced', 'dead_forced', 'empty', 'decision', (), None),
        ('forced_before_branch', 'forced', 'empty', 'decision', (), None),
        ('failed_first_fallback', 'fallback', 'fallback', 'solve', (), None),
        ('complete_unsat', 'unsat', 'empty', 'solve', (), None),
        ('legacy_complete_unsat', 'unsat', 'baseline', 'solve', (), None),
        ('incompatible_alternatives', 'plain', 'alternatives', 'decision', (), None),
        ('packet_shape', 'plain', 'bad_packet', 'decision', (), 'PACKET_SHAPE'),
        ('packet_binding', 'plain', 'bad_binding', 'decision', (), 'PACKET_BINDING'),
        ('packet_size', 'plain', 'packet_size', 'decision', (), 'PACKET_SIZE'),
        ('cluster_shape', 'plain', 'bad_cluster', 'decision', (), 'CLUSTER_SHAPE'),
        ('cluster_id', 'plain', 'bad_id', 'decision', (), 'CLUSTER_ID'),
        ('cluster_version', 'plain', 'bad_version', 'decision', (), 'CLUSTER_VERSION'),
        ('duplicate_cluster_id', 'plain', 'duplicate_cluster', 'decision', (), 'CLUSTER_ID'),
        ('nonJSON', 'plain', 'nonjson', 'decision', (), 'NON_JSON_PACKET'),
        ('public_reentrancy', 'plain', 'reentrant', 'decision', (), None),
    )
    controls, lookup = [], {}
    for name, fixture, mode, action, setup, rejection in recipes:
        clock.tick()
        pair = []
        for role in ('point', 'csp'):
            model = _fixture(fixture)
            outcome = _exercise(P, C, O, model, role, mode, action, setup, clock, counters)
            evidence = outcome['proposal_evidence']
            if rejection is not None:
                reasons = [r['packet_rejection'] for r in evidence]
                reasons += [row['rejection'] for r in evidence for row in r['clusters']]
                _need(rejection in reasons, 'required rejection reached: ' + name)
            if name == 'multistep':
                _eq(outcome['result']['selected'], ['B', 'D'], 'two nonforced cluster members')
                _need(len(evidence) == 2 and evidence[1]['clusters'][0]['shared_ids'] == ['B']
                      and evidence[1]['clusters'][0]['incident_ids'] == ['D'],
                      'second distinct branch continuation actually influences ordering')
            elif name == 'first_only_fresh':
                _eq(outcome['result']['selected'], ['B', 'C'], 'fresh first-only different second choice')
            elif name == 'shared':
                _eq(evidence[0]['clusters'][0]['shared_ids'], ['A'], 'shared selected exactly once')
            elif name in ('shared_seed', 'exterior_seed'):
                _eq(evidence[0]['clusters'][0]['shared_ids'], ['S'], 'shared seed exactly once')
            elif name == 'foreign_exception':
                _need(outcome['foreign'] == '_ForeignSentinel', 'foreign identity retained')
            elif name == 'owned_unknown':
                _need(outcome['result']['status'] == 'UNKNOWN' and
                      outcome['result']['reason'] == 'EXTERNAL_BUDGET', 'owned interruption unknown')
                _eq(outcome['entry'], outcome['final'], 'unknown exact native restoration')
            elif name in ('dead_before_forced', 'forced_before_branch'):
                _need(outcome['decision']['kind'] == ('DEAD' if name == 'dead_before_forced' else 'FORCED')
                      and not evidence, 'global priority before proposer')
            elif name == 'failed_first_fallback':
                _need(outcome['result']['status'] == 'FINITE_EXACT_SOLUTION' and
                      'B' in outcome['result']['selected'] and
                      any(row['id'] == 'A' for row in outcome['final']['excluded']),
                      'failed preferred child, successful fallback, retained parent-local ban')
            elif name in ('complete_unsat', 'legacy_complete_unsat'):
                _need(outcome['result']['status'] == 'EXHAUSTED_FINITE_SEARCH',
                      'complete tiny UNSAT certificate')
                _eq(outcome['entry'], outcome['final'], 'exhaustion exact restoration')
            if action == 'decision' and outcome['decision']['kind'] == 'BRANCH':
                _need(set(outcome['decision']['candidates']) ==
                      set(outcome['proposal_evidence'][-1]['observation']['incident_domain']),
                      'no rejected proposal removes base fallback')
            pair.append(outcome)
        # Compare equal information without dropping timing fields from retained receipts.
        if pair[0]['proposal_evidence'] and pair[1]['proposal_evidence']:
            _eq([x['observation'] for x in pair[0]['proposal_evidence']],
                [x['observation'] for x in pair[1]['proposal_evidence']],
                'same point/CSP complete receptor information')
            _eq([x['ordered_candidates'] for x in pair[0]['proposal_evidence']],
                [x['ordered_candidates'] for x in pair[1]['proposal_evidence']],
                'same validated complete branch ordering')
        if pair[0]['result'] is not None and pair[1]['result'] is not None:
            _eq(pair[0]['result']['status'], pair[1]['result']['status'], 'pair result status')
            _eq(pair[0]['result']['selected'], pair[1]['result']['selected'], 'pair selected witness')
        controls.append({'id': name, 'status': 'PASS', 'roles': pair})
        lookup[name] = pair
    for role_index in (0, 1):
        baseline = lookup['baseline'][role_index]
        for nochange in ('empty', 'none'):
            candidate = lookup[nochange][role_index]
            _eq([{'event': x['event'], 'state': x['state']} for x in baseline['events']],
                [{'event': x['event'], 'state': x['state']} for x in candidate['events']],
                'no-op proposal preserves entire native events and snapshots')
            for field in ('status', 'reason', 'nodes', 'selected', 'context',
                          'solution_verified', 'metrics'):
                _eq(baseline['result'][field], candidate['result'][field],
                    'no-op proposal preserves native result semantics and counters')
    # Synthetic selector only: production finite required points are all roots0.
    synthetic = [{'point': [0, 0], 'generation': 0, 'candidates': ['A', 'B', 'C']},
                 {'point': [2, 0], 'generation': 1, 'candidates': ['D', 'E']}]
    selected = P.reference_decision(synthetic)
    counters['synthetic_selector_calls'] += 1
    _need(selected['kind'] == 'BRANCH' and selected['point'] == [0, 0],
          'synthetic earlier generation outranks smaller later domain')
    controls.append({'id': 'synthetic_generation', 'status': 'PASS',
                     'scope': 'Synthetic public selector, not native nonroot runtime coverage.',
                     'input': synthetic, 'output': selected})
    prepared = prepare_cluster_model(_fixture(), budget=clock.tick)
    counters['C_preparations'] += 1
    forged = _receipt_forgery_controls(prepared, lookup['multistep'][0]['proposal_checks'][0], clock)
    counters['C_receipt_checks'] += len(forged)
    controls.append({'id': 'nine_independent_receipt_forgeries', 'status': 'PASS', 'cases': forged})
    unknown = lookup['owned_unknown'][0]
    _need(bool(unknown['proposal_evidence']), 'owned interruption retains attempt')
    partial_check, partial_cursor = verify_proposal_receipt(
        prepared, unknown['proposal_evidence'][0], unknown['final_normalized'],
        proposal_audit_enabled=True, budget=clock.tick)
    counters['C_receipt_checks'] += 1
    _need(partial_check['status'] == 'VERIFIED_NONFINAL_ENVELOPE_ONLY' and
          partial_cursor is None and partial_check['counters'] is None and
          partial_check['ordered_candidates'] is None, 'partial is not full order/counter proof')
    controls.append({'id': 'partial_scope_only', 'status': 'PASS', 'independent': partial_check})
    controls.extend(_self_model_controls(clock, counters))
    controls.append(_certificate_forgeries(C, O, lookup, clock, counters))
    controls.append(_indexed_negative_controls(C, O, lookup, clock, counters))
    actor_controls = _actor_qualification(P, C, O, A, clock, counters)
    controls.extend(actor_controls)
    clock.tick()
    return {'schema': 'GCTS-cluster-receptor-independent-qualification-result-v1',
            'status': 'PASS',
            'source_versions': {'point': P.VERSION, 'csp': C.VERSION,
                                'oracle': O.VERSION, 'actor': 'GCTS-cluster-token-policy-v1',
                                'qualification': VERSION},
            'controls': controls,
            'coverage': {'actual_call_counters': counters, 'paired_kernel_recipes': len(recipes),
                         'same_information_pairs': True,
                         'limits': ['Unit-anchor/root0 tiny controls, not general growth or fractional proof.',
                                    'Shared-selected control is not multianchor shared-forced runtime coverage.',
                                    'Deterministic multistep mechanism is not trained RL performance.',
                                    'Formal lemma, infinity, arbitrary transformer completeness and speed not established.']},
            'costs': clock.costs()}


FEATURES = ('stop', 'stop_size_fraction', 'anchor_domain_fraction', 'relative_dx',
            'relative_dy', 'relative_l1', 'selected_mark_contact_fraction',
            'partial_mark_contact_fraction', 'active_conflict_fraction',
            'mark_term_fraction', 'same_type_as_first', 'literal_diversity_fraction')


def _near(actual, expected, reason):
    _need(type(actual) in (int, float) and type(actual) is not bool and
          math.isfinite(actual) and abs(actual - expected) <= 1e-10 * max(1.0, abs(expected)),
          reason)


def _conflict(prepared, left, right):
    a, b = prepared._by_id[left], prepared._by_id[right]
    if a['t'][0][:2] == b['t'][0][:2]:
        return True
    slots = {tuple(m[:3]): m[3] for m in a['m']}
    return any(tuple(m[:3]) in slots and slots[tuple(m[:3])] != m[3] for m in b['m'])


def _active_ids(prepared, observation):
    packed = bytes.fromhex(observation['active_bitset']['hex'])
    return [ident for i, ident in enumerate(prepared._ids)
            if packed[i // 8] & (1 << (i % 8))]


def _actor_features(prepared, observation, partial, ident, max_members):
    if ident is None:
        return [1.0, len(partial) / max_members] + [0.0] * 10
    placement = prepared._by_id[ident]
    active = _active_ids(prepared, observation)
    counts = {}
    for key in active:
        anchor = tuple(prepared._by_id[key]['t'][0][:2])
        counts[anchor] = counts.get(anchor, 0) + 1
    anchors = [row['t'][0][:2] for row in prepared._by_id.values()]
    span = max(1, max((p[0] for p in anchors), default=0) - min((p[0] for p in anchors), default=0),
               max((p[1] for p in anchors), default=0) - min((p[1] for p in anchors), default=0))
    anchor = placement['t'][0][:2]
    dx, dy = anchor[0] - observation['point'][0], anchor[1] - observation['point'][1]
    def contact(ids):
        union = {tuple(m[:3]): m[3] for key in ids for m in prepared._by_id[key]['m']}
        return sum(tuple(m[:3]) in union and union[tuple(m[:3])] == m[3]
                   for m in placement['m']) / max(1, len(placement['m']))
    return [0.0, 0.0, counts[tuple(anchor)] / max(1, max(counts.values(), default=0)),
            dx / span, dy / span, (abs(dx) + abs(dy)) / (2 * span),
            contact(observation['selected']), contact(partial),
            sum(key != ident and _conflict(prepared, ident, key) for key in active) / max(1, len(active)),
            len(placement['m']) / max(1, max((len(r['m']) for r in prepared._by_id.values()), default=0)),
            float(bool(partial) and placement['type'] == prepared._by_id[partial[0]]['type']),
            len({m[3] for m in placement['m']}) / max(1, len(placement['m']))]


def _actor_snapshot_check(prepared, snapshot, clock):
    snap = _copy(snapshot)
    _keys(snap, ('schema', 'model_sha256', 'id_order_sha256', 'policy_sha256', 'policy',
                 'config', 'costs', 'calls', 'pending', 'family_scope'), 'actor snapshot10')
    _need(snap['schema'] == 'GCTS-cluster-proposer-evidence-v1' and
          snap['model_sha256'] == prepared.model_sha256 and
          snap['id_order_sha256'] == prepared.id_order_sha256, 'actor model bindings')
    _need(snap['policy_sha256'] == _sha(snap['policy']), 'actor frozen policy hash')
    policy, config = snap['policy'], snap['config']
    _keys(policy, ('schema', 'feature_names', 'max_members', 'learning_rate', 'weight_clip',
                   'baseline_beta', 'weights', 'baseline', 'updates'), 'policy9')
    _need(policy['schema'] == 'GCTS-cluster-token-policy-v1', 'policy schema')
    _need(type(policy['max_members']) is int and 1 <= policy['max_members'] <= 256,
          'policy member cap')
    _need(type(policy['weights']) is list and len(policy['weights']) == 12,
          'policy weights12')
    _eq(policy['feature_names'], list(FEATURES), 'feature order12')
    _keys(config, ('seed', 'continuations', 'inventory_version', 'marking_version',
                   'max_pending', 'selection'), 'actor config6')
    _need(config['max_pending'] == 64 and config['selection'] == 'STOCHASTIC', 'config literal bounds')
    _need(type(config['seed']) is int and type(config['continuations']) is bool,
          'actor seed and continuation types')
    costs = snap['costs']
    _keys(costs, ('preparation_elapsed_seconds', 'budget_callbacks', 'model_rows', 'mark_terms',
                 'conflict_pairs', 'calls', 'fresh_calls', 'pending_reuses', 'pending_drops',
                 'candidate_feature_visits', 'tokens', 'stop_tokens'), 'actor costs12')
    for key, value in costs.items():
        if key == 'preparation_elapsed_seconds':
            _need(type(value) in (int, float) and type(value) is not bool and
                  math.isfinite(value) and value >= 0, 'actor preparation elapsed')
        else:
            _int(value, 'actor actual counter')
    _need(costs['model_rows'] == len(prepared._ids) and
          costs['mark_terms'] == sum(len(r['m']) for r in prepared._by_id.values()), 'actor raw work')
    _need(costs['conflict_pairs'] == sum(_conflict(prepared, a, b)
              for i, a in enumerate(prepared._ids) for b in prepared._ids[i + 1:]), 'actor static conflicts')
    fresh = reuses = visits = chosen_count = stops = drops = 0
    call_by_index = {}
    for call in snap['calls']:
        clock.tick()
        _keys(call, ('index', 'mode', 'observation', 'observation_sha256', 'packet', 'origin_call',
                     'original_members', 'root_selected', 'dropped', 'skipped', 'tokens',
                     'descriptor', 'cost_delta', 'termination'), 'actor call14')
        _need(type(call['index']) is int and call['index'] == len(call_by_index), 'actor call order')
        obs = call['observation']
        _need(call['observation_sha256'] == _sha(obs), 'actor observation hash')
        _eq(call['packet']['observation_sha256'], _sha(obs), 'actor current packet binding')
        _keys(call['cost_delta'], ('candidate_feature_visits', 'tokens', 'stop_tokens',
                                  'pending_reuses', 'pending_drops', 'budget_callbacks'), 'call delta6')
        for value in call['cost_delta'].values():
            _int(value, 'actor delta counter')
        drops += len(call['dropped'])
        for row in call['dropped'] + call['skipped']:
            _keys(row, ('origin_call', 'reason'), 'pending decision2')
            _int(row['origin_call'], 'pending origin')
        partial = []
        call_visits = call_stops = 0
        if call['mode'] == 'FRESH':
            fresh += 1
            _need(call['origin_call'] == call['index'], 'fresh origin self')
            _eq(call['root_selected'], obs['selected'], 'fresh selected receptor')
            for index, token in enumerate(call['tokens']):
                clock.tick()
                _keys(token, ('index', 'action_kind', 'placement_id', 'option_count', 'probability',
                              'log_probability', 'features', 'gradient', 'sample_u', 'partial_before'), 'token10')
                _need(token['index'] == index, 'token order')
                _eq(token['partial_before'], partial, 'token prefix')
                active = _active_ids(prepared, obs)
                options = obs['incident_domain'][:] if not partial else [None] + [key for key in active
                    if key not in partial and all(not _conflict(prepared, key, old) for old in partial)]
                vectors = [_actor_features(prepared, obs, partial, key, policy['max_members']) for key in options]
                raw_scores = [sum(w * v for w, v in zip(policy['weights'], vector)) for vector in vectors]
                scores = [min(16.0, max(-16.0, score)) for score in raw_scores]
                exponentials = [math.exp(score - max(scores)) for score in scores]
                probabilities = [x / sum(exponentials) for x in exponentials]
                derivative = [vector if -16 < raw_score < 16 else [0.0] * 12
                              for vector, raw_score in zip(vectors, raw_scores)]
                key = {'seed': config['seed'], 'model_sha256': obs['model_sha256'],
                       'selected': obs['selected'], 'excluded': obs['excluded'], 'point': obs['point'],
                       'generation': obs['generation'], 'incident_domain': obs['incident_domain'],
                       'active_bitset': obs['active_bitset'], 'call_index': call['index'],
                       'token_index': index, 'partial_before': partial[:]}
                uniform = random.Random(int(_sha(key), 16)).random()
                selected_index, cumulative = len(options) - 1, 0.0
                for i, probability in enumerate(probabilities):
                    cumulative += probability
                    if uniform < cumulative:
                        selected_index = i
                        break
                ident = options[selected_index]
                _need(token['option_count'] == len(options) and token['action_kind'] ==
                      ('STOP' if ident is None else 'PLACE') and token['placement_id'] == ident,
                      'complete categorical support and counter-seeded selection')
                _near(token['sample_u'], uniform, 'common uniform')
                _near(token['probability'], probabilities[selected_index], 'full softmax probability')
                _near(token['log_probability'], math.log(probabilities[selected_index]), 'log probability')
                _need(type(token['features']) is list and len(token['features']) == 12 and
                      type(token['gradient']) is list and len(token['gradient']) == 12, 'vectors12')
                for k in range(12):
                    _near(token['features'][k], vectors[selected_index][k], 'actual receptor feature')
                    gradient = derivative[selected_index][k] - sum(p * vector[k]
                        for p, vector in zip(probabilities, derivative))
                    _near(token['gradient'][k], gradient, 'all-option clipped log-score gradient')
                call_visits += len(options)
                if ident is None:
                    call_stops += 1
                    _need(index == len(call['tokens']) - 1 and call['termination'] == 'STOP', 'STOP terminates')
                else:
                    partial.append(ident)
            _eq(call['original_members'], partial, 'expanded members from actual tokens')
            if not call_stops:
                _need(call['termination'] == 'SIZE_CAP' and len(partial) == policy['max_members'], 'size termination')
        else:
            reuses += 1
            _need(call['mode'] == 'PENDING_REUSE' and config['continuations'] is True and
                  not call['tokens'] and call['termination'] == 'REUSE', 'reuse no new stochastic token')
            origin = call_by_index[call['origin_call']]
            _eq(call['original_members'], origin['original_members'], 'same original ordered expansion')
            _need(set(origin['root_selected']).issubset(obs['selected']) and
                  origin['original_members'][0] in obs['selected'], 'pending actual parent context and first member')
            _need(all(key in obs['selected'] or key in _active_ids(prepared, obs)
                      for key in call['original_members']) and
                  not set(call['original_members']).intersection(obs['excluded']), 'pending current active context')
            _need(any(key not in obs['selected'] and key in obs['incident_domain']
                      for key in call['original_members']), 'pending later actual chosen branch incidence')
        origin = call if call['mode'] == 'FRESH' else call_by_index[call['origin_call']]
        cluster = call['packet']['clusters'][0]
        _need(len(call['packet']['clusters']) == 1 and cluster['id'] ==
              'ACTOR_CLUSTER:' + origin['observation_sha256'], 'conditional family identity')
        _eq(cluster['members'], call['original_members'], 'full expansion returned, no trim')
        descriptor = call['descriptor']
        _keys(descriptor, ('origin_point', 'relative_anchors', 'type_pattern'), 'descriptor3')
        _eq(descriptor['origin_point'], origin['observation']['point'], 'descriptor origin')
        point = descriptor['origin_point']
        _eq(descriptor['relative_anchors'], [[prepared._by_id[key]['t'][0][0] - point[0],
            prepared._by_id[key]['t'][0][1] - point[1]] for key in call['original_members']], 'relative expansion')
        types, pattern = [], []
        for key in call['original_members']:
            value = prepared._by_id[key]['type']
            if value not in types:
                types.append(value)
            pattern.append(types.index(value))
        _eq(descriptor['type_pattern'], pattern, 'opaque type equality pattern')
        _need(call['cost_delta']['candidate_feature_visits'] == call_visits and
              call['cost_delta']['tokens'] == len(call['tokens']) and
              call['cost_delta']['stop_tokens'] == call_stops and
              call['cost_delta']['pending_reuses'] == int(call['mode'] == 'PENDING_REUSE') and
              call['cost_delta']['pending_drops'] == len(call['dropped']), 'actual per-call work')
        visits += call_visits
        chosen_count += len(call['tokens'])
        stops += call_stops
        call_by_index[call['index']] = call
    _need(costs['calls'] == len(snap['calls']) and costs['fresh_calls'] == fresh and
          costs['pending_reuses'] == reuses and costs['pending_drops'] == drops and
          costs['candidate_feature_visits'] == visits and costs['tokens'] == chosen_count and
          costs['stop_tokens'] == stops, 'actual actor cumulative work')
    if config['continuations'] is False:
        _need(not snap['pending'] and reuses == 0, 'fresh first-only never retains/resubmits tails')
    for pending in snap['pending']:
        _keys(pending, ('origin_call', 'origin_observation_sha256', 'origin_selected', 'origin_point',
                       'members', 'original_first', 'model_sha256', 'inventory_version', 'marking_version'), 'pending9')
        origin = call_by_index[pending['origin_call']]
        _eq(pending['members'], origin['original_members'], 'pending exact expansion')
        _need(pending['original_first'] == pending['members'][0] and
              pending['model_sha256'] == prepared.model_sha256, 'pending bindings')
    return {'status': 'VERIFIED_ACTOR_HEURISTIC_TRAJECTORY', 'calls': len(snap['calls']),
            'fresh_tokens': chosen_count, 'pending_reuses': reuses,
            'scope': 'Independent current features/support/PRNG/softmax/gradient/work check; floats are heuristic, not proof arithmetic.'}


def _update_check(policy, evidence, feedback, result, clock):
    _keys(result, ('schema', 'before_policy_sha256', 'after_policy', 'reward_terms', 'advantage',
                   'mean_gradient', 'token_count', 'evidence_sha256', 'feedback'), 'update9')
    _need(result['schema'] == 'GCTS-cluster-token-policy-update-v1' and
          result['before_policy_sha256'] == _sha(policy) and
          result['evidence_sha256'] == _sha(evidence), 'update raw associations')
    _eq(result['feedback'], feedback, 'complete feedback retention')
    terminal = float(feedback['verified_terminal'])
    shaping = .1 * feedback['max_verified_filled'] / max(1, feedback['required_points'])
    search = .005 * (feedback['attempts'] + feedback['branches'] + feedback['backtracks'])
    proposal = .00001 * feedback['actor_candidate_visits']
    reward = terminal + shaping - search - proposal
    terms = {'terminal': terminal, 'shaping': shaping, 'search_penalty': search,
             'proposal_penalty': proposal, 'reward': reward}
    _keys(result['reward_terms'], tuple(terms), 'reward terms5')
    for key, value in terms.items():
        _near(result['reward_terms'][key], value, 'reward formula')
    gradients = [token['gradient'] for call in evidence['calls'] for token in call['tokens']]
    mean = [sum(g[k] for g in gradients) / max(1, len(gradients)) for k in range(12)]
    advantage = reward - policy['baseline']
    _need(result['token_count'] == len(gradients), 'actual stochastic token count')
    _near(result['advantage'], advantage, 'reward-caused advantage')
    _need(type(result['mean_gradient']) is list and len(result['mean_gradient']) == 12, 'mean gradient12')
    for k, value in enumerate(mean):
        _near(result['mean_gradient'][k], value, 'all fresh score gradients averaged')
    expected = _copy(policy)
    expected['weights'] = [min(policy['weight_clip'], max(-policy['weight_clip'],
                         weight + policy['learning_rate'] * advantage * gradient *
                         len(gradients) / policy['max_members']))
                         for weight, gradient in zip(policy['weights'], mean)]
    expected['baseline'] = (1 - policy['baseline_beta']) * policy['baseline'] + policy['baseline_beta'] * reward
    expected['updates'] += 1
    after = result['after_policy']
    _need(set(after) == set(expected), 'after policy same9')
    for key in expected:
        clock.tick()
        if key == 'weights':
            for actual, value in zip(after[key], expected[key]):
                _near(actual, value, 'episodic gradient weight update')
            _need(len(after[key]) == 12, 'after weights12')
        elif key == 'baseline':
            _near(after[key], expected[key], 'episodic baseline update')
        else:
            _eq(after[key], expected[key], 'unchanged policy config or updates')
    return {'status': 'VERIFIED_SYNTHETIC_NUMERIC_UPDATE', 'reward': reward,
            'token_count': len(gradients), 'scope': 'Explicitly synthetic feedback, not mathematical result evidence.'}


def _actor_qualification(P, C, O, A, clock, counters):
    controls = []
    model = _fixture('actor')
    prepared = prepare_cluster_model(model, budget=clock.tick)
    counters['C_preparations'] += 1
    policy = A.new_policy(max_members=2, weight_clip=16.0)
    _eq(policy['weights'], [0.0] * 12, 'fresh zero weights')
    _need(policy['updates'] == 0, 'fresh no prior updates')
    # Finite explicit seed sweep is a qualification control, not outcome selection.
    # Every attempted seed/role and all its raw evidence is retained and charged.
    policy['weights'][0] = -16.0
    successful = None
    attempts = []
    for seed in range(8):
        clock.tick()
        pair = []
        for role in ('point', 'csp'):
            actor = A.ClusterProposer(model, policy, seed=seed, continuations=True, budget=clock.tick)
            counters['actor_objects'] += 1
            outcome = _exercise(P, C, O, model, role, 'actor', 'solve', (), clock,
                                counters, actor_callable=actor)
            snapshot = actor.snapshot()
            checked = _actor_snapshot_check(prepared, snapshot, clock)
            pair.append({'outcome': outcome, 'snapshot': snapshot, 'independent': checked})
        _eq([x['observation'] for x in pair[0]['snapshot']['calls']],
            [x['observation'] for x in pair[1]['snapshot']['calls']], 'actor equal point/CSP receptors')
        _eq([x['packet'] for x in pair[0]['snapshot']['calls']],
            [x['packet'] for x in pair[1]['snapshot']['calls']], 'actor equal uniforms and packet outputs')
        attempts.append({'seed': seed, 'roles': pair})
        if any(call['mode'] == 'PENDING_REUSE' for call in pair[0]['snapshot']['calls']):
            successful = pair
            break
    _need(successful is not None, 'bounded actor positive pending control reached')
    controls.append({'id': 'actor_actual_two_step_pending', 'status': 'PASS', 'all_attempts': attempts,
                     'scope': 'Tiny mechanism qualification; every seed attempt retained, no evaluation-cohort selection.'})
    evidence = successful[0]['snapshot']
    initial = _copy(policy)
    for verified in (False, True):
        feedback = {'status': 'SAT' if verified else 'UNKNOWN', 'verified_terminal': verified,
                    'verification_sha256': 'f' * 64, 'required_points': 2,
                    'max_verified_filled': 2 if verified else 1, 'attempts': 4, 'branches': 2,
                    'backtracks': 1, 'actor_candidate_visits': evidence['costs']['candidate_feature_visits'],
                    'certificate_kind': 'SAT' if verified else 'INCOMPLETE'}
        before_policy, before_evidence, before_feedback = _copy(initial), _copy(evidence), _copy(feedback)
        update = A.reinforce_update(initial, evidence, feedback, budget=clock.tick)
        counters['actor_updates'] += 1
        checked = _update_check(initial, evidence, feedback, update, clock)
        _eq(initial, before_policy, 'update policy purity')
        _eq(evidence, before_evidence, 'update trajectory purity')
        _eq(feedback, before_feedback, 'update feedback purity')
        controls.append({'id': 'actor_synthetic_update_' + str(verified), 'status': 'PASS',
                         'feedback': feedback, 'update': update, 'independent': checked})
    first_only = []
    for role in ('point', 'csp'):
        actor = A.ClusterProposer(model, policy, seed=attempts[-1]['seed'], continuations=False,
                                 budget=clock.tick)
        counters['actor_objects'] += 1
        outcome = _exercise(P, C, O, model, role, 'actor', 'solve', (), clock,
                            counters, actor_callable=actor)
        snapshot = actor.snapshot()
        checked = _actor_snapshot_check(prepared, snapshot, clock)
        _need(not snapshot['pending'] and all(c['mode'] == 'FRESH' for c in snapshot['calls']),
              'fresh first-only actually stores no tails')
        first_only.append({'outcome': outcome, 'snapshot': snapshot, 'independent': checked})
    _eq(first_only[0]['snapshot']['calls'][0]['packet'], evidence['calls'][0]['packet'],
        'first-only shared initial receptor and uniform, full packet paid')
    controls.append({'id': 'actor_fresh_first_only', 'status': 'PASS', 'roles': first_only,
                     'scope': 'No claim equal later packets/costs or necessarily different solution; actual study must show causal effects.'})
    longer_evidence = first_only[0]['snapshot']
    fixed_feedback = {'status': 'UNKNOWN', 'verified_terminal': False,
                      'verification_sha256': 'f' * 64, 'required_points': 2,
                      'max_verified_filled': 1, 'attempts': 4, 'branches': 2,
                      'backtracks': 1,
                      'actor_candidate_visits': longer_evidence['costs']['candidate_feature_visits'],
                      'certificate_kind': 'INCOMPLETE'}
    fixed_update = A.reinforce_update(policy, longer_evidence, fixed_feedback, budget=clock.tick)
    counters['actor_updates'] += 1
    fixed_check = _update_check(policy, longer_evidence, fixed_feedback, fixed_update, clock)
    _need(fixed_update['token_count'] != policy['max_members'] and
          any(abs(x) > 1e-8 for x in fixed_update['mean_gradient']),
          'fixed scoreSUM/H control differs from random-token-count mean update')
    controls.append({'id': 'actor_fixed_score_sum_not_random_length_mean', 'status': 'PASS',
                     'feedback': fixed_feedback, 'update': fixed_update,
                     'independent': fixed_check,
                     'scope': 'Synthetic numeric feedback with token_count different from fixed H; no certificate claim.'})
    clipped_policy = A.new_policy(max_members=1, weight_clip=16.0)
    clipped_policy['weights'] = [16.0] * 12
    input_model, input_policy = _copy(model), _copy(clipped_policy)
    clipped_actor = A.ClusterProposer(input_model, input_policy, seed=0,
                                      continuations=False, budget=None)
    counters['actor_objects'] += 1
    input_model['placements'][0]['m'].append([222, 333, 'MUTATED', '1'])
    input_policy['weights'][0] = -16.0
    observation = _copy(evidence['calls'][0]['observation'])
    original_observation = _copy(observation)
    returned_packet = clipped_actor(observation)
    returned_packet['clusters'][0]['members'].append('FOREIGN_ID')
    observation['selected'].append('FOREIGN_ID')
    clipped_snapshot = clipped_actor.snapshot()
    clipped_check = _actor_snapshot_check(prepared, clipped_snapshot, clock)
    _eq(clipped_snapshot['calls'][0]['observation'], original_observation,
        'actor observation callback alias isolated')
    _eq(clipped_snapshot['policy'], clipped_policy, 'actor constructor policy alias isolated')
    _need(clipped_snapshot['costs']['budget_callbacks'] == 0,
          'None budget means zero actual actor callback invocations')
    retained_calls = _copy(clipped_snapshot['calls'])
    clipped_snapshot['calls'][0]['original_members'].append('FOREIGN_ID')
    clipped_snapshot['policy']['weights'][0] = -16.0
    detached_again = clipped_actor.snapshot()
    _eq(detached_again['calls'], retained_calls, 'actor snapshot descendants detached')
    _eq(detached_again['policy'], clipped_policy, 'actor snapshot policy detached')
    controls.append({'id': 'actor_saturated_gradient_and_aliases', 'status': 'PASS',
                     'snapshot': clipped_actor.snapshot(), 'independent': clipped_check,
                     'scope': 'Hand-set saturated weights only a numeric qualification control, not actual training.'})
    for kind in ('owned', 'foreign'):
        sentinel = _ForeignSentinel('actor budget foreign identity')
        def actor_budget():
            if kind == 'foreign':
                raise sentinel
            return False
        try:
            counters['actor_objects'] += 1
            A.ClusterProposer(model, policy, seed=0, budget=actor_budget)
        except A.ActorBudgetExceeded:
            _need(kind == 'owned', 'foreign not reclassified')
        except _ForeignSentinel as exc:
            _need(kind == 'foreign' and exc is sentinel, 'actor foreign exact identity')
        else:
            raise ClusterQualificationError('actor budget ignored')
        controls.append({'id': 'actor_budget_' + kind, 'status': 'PASS'})
    controls.append(_actor_negative_controls(A, model, policy, evidence, clock, counters))
    return controls


def _actor_negative_controls(A, model, policy, evidence, clock, counters):
    observation = _copy(evidence['calls'][0]['observation'])
    feedback = {'status': 'UNKNOWN', 'verified_terminal': False,
                'verification_sha256': 'f' * 64, 'required_points': 2,
                'max_verified_filled': 1, 'attempts': 4, 'branches': 2,
                'backtracks': 1, 'actor_candidate_visits': evidence['costs']['candidate_feature_visits'],
                'certificate_kind': 'INCOMPLETE'}
    cases = []
    for name in ('member_bool', 'rate_bool', 'noncanonical_model', 'unsupported_model',
                 'foreign_observation', 'bitset_bool', 'bitset_extent',
                 'feedback_visits', 'false_terminal'):
        clock.tick()
        try:
            if name == 'member_bool':
                A.new_policy(max_members=True)
            elif name == 'rate_bool':
                A.new_policy(learning_rate=True)
            elif name in ('noncanonical_model', 'unsupported_model'):
                bad = _copy(model)
                if name == 'noncanonical_model':
                    bad['placements'].reverse()
                else:
                    bad['capacity'] = 2
                counters['actor_objects'] += 1
                A.ClusterProposer(bad, policy, seed=0, budget=clock.tick)
            elif name in ('foreign_observation', 'bitset_bool', 'bitset_extent'):
                counters['actor_objects'] += 1
                actor = A.ClusterProposer(model, policy, seed=0, budget=clock.tick)
                bad = _copy(observation)
                if name == 'foreign_observation':
                    bad['model_sha256'] = '0' * 64
                elif name == 'bitset_bool':
                    bad['active_bitset']['universe_size'] = True
                else:
                    bad['active_bitset']['hex'] += '00'
                actor(bad)
            else:
                bad = _copy(feedback)
                if name == 'feedback_visits':
                    bad['actor_candidate_visits'] += 1
                else:
                    bad['status'], bad['certificate_kind'] = 'SAT', 'SAT'
                counters['actor_updates'] += 1
                A.reinforce_update(policy, evidence, bad, budget=clock.tick)
        except A.ActorError as exc:
            cases.append({'id': name, 'rejected': True, 'reason': str(exc)})
        else:
            raise ClusterQualificationError('actor malformed public input accepted: ' + name)
    return {'id': 'actor_nine_malformed_controls', 'status': 'PASS', 'cases': cases}


def _self_model_controls(clock, counters):
    outcomes = []
    model = _fixture()
    original = _copy(model)
    handle = prepare_cluster_model(model, budget=clock.tick)
    counters['C_preparations'] += 1
    model['placements'][0]['m'].append([77, 88, 'ALIAS', '0'])
    _need(handle.model_sha256 == _sha(original), 'prepared input alias isolated')
    costs = handle.preparation_costs
    costs['budget_callbacks'] = -1
    _need(handle.preparation_costs['budget_callbacks'] >= 0, 'prepared cost getter detached')
    try:
        handle._hash = 'foreign'
    except AttributeError:
        pass
    else:
        raise ClusterQualificationError('mutable prepared model')
    outcomes.append({'id': 'prepared_alias_immutability', 'status': 'PASS'})
    for name, bad, expected in (('unsupported_capacity', 2, UnsupportedClusterProfile),
                                ('capacity_bool', True, ClusterQualificationError)):
        malformed = _fixture()
        malformed['capacity'] = bad
        try:
            counters['C_preparations'] += 1
            prepare_cluster_model(malformed, budget=clock.tick)
        except expected as exc:
            outcomes.append({'id': name, 'status': 'PASS', 'reason': str(exc)})
        else:
            raise ClusterQualificationError('malformed profile accepted')
    try:
        counters['C_preparations'] += 1
        prepare_cluster_model(_fixture(), budget=lambda: False)
    except ClusterQualificationBudgetExceeded:
        outcomes.append({'id': 'C_budget_unknown_not_negative', 'status': 'PASS'})
    else:
        raise ClusterQualificationError('owned C budget ignored')
    sentinel = _ForeignSentinel('independent checker foreign budget')
    def foreign():
        raise sentinel
    try:
        counters['C_preparations'] += 1
        prepare_cluster_model(_fixture(), budget=foreign)
    except _ForeignSentinel as exc:
        _need(exc is sentinel, 'independent checker foreign identity')
        outcomes.append({'id': 'C_foreign_exception', 'status': 'PASS'})
    else:
        raise ClusterQualificationError('independent checker foreign swallowed')
    return outcomes


def _certificate_forgeries(C, O, lookup, clock, counters):
    source = lookup['complete_unsat'][1]
    model = source['model']
    prepared = O.prepare_model(model, budget=clock.tick)
    spec = C.export_unit_cell_csp(model, value_policy=POLICY)
    prepared_spec = O.prepare_unit_cell_spec(prepared, spec, budget=clock.tick)
    counters['L_preparations'] += 1
    counters['exports'] += 1
    counters['L_spec_preparations'] += 1
    unknown_model = lookup['owned_unknown'][1]['model']
    unknown_prepared = O.prepare_model(unknown_model, budget=clock.tick)
    unknown_spec = C.export_unit_cell_csp(unknown_model, value_policy=POLICY)
    unknown_prepared_spec = O.prepare_unit_cell_spec(unknown_prepared, unknown_spec,
                                                    budget=clock.tick)
    counters['L_preparations'] += 1
    counters['exports'] += 1
    counters['L_spec_preparations'] += 1
    cases = []
    for name in ('missing_alternative', 'duplicate_alternative', 'missing_remainder',
                 'false_dead', 'UNKNOWN_as_UNSAT'):
        clock.tick()
        if name == 'UNKNOWN_as_UNSAT':
            forged = _copy(lookup['owned_unknown'][1]['result'])
            forged['status'], forged['reason'] = 'EXHAUSTED_FINITE_SEARCH', 'EXHAUSTED'
            forged['certificate']['kind'] = 'UNSAT'
        else:
            forged = _copy(source['result'])
            root = forged['certificate']['root']
            _need(root['kind'] == 'BRANCH', 'tiny UNSAT has nontrivial branch proof')
            if name == 'missing_alternative':
                root['candidates'].pop()
            elif name == 'duplicate_alternative':
                root['candidates'].append(root['candidates'][0])
            elif name == 'missing_remainder':
                root['remainder'] = None
            else:
                forged['certificate']['root'] = {'kind': 'DEAD', 'point': root['point'],
                                                 'domains_sha256': root['domains_sha256']}
        try:
            counters['L_result_checks'] += 1
            O.verify_unit_cell_result(unknown_prepared_spec if name == 'UNKNOWN_as_UNSAT'
                                      else prepared_spec, forged, budget=clock.tick)
        except O.IndexedOracleError as exc:
            cases.append({'id': name, 'rejected': True, 'reason': str(exc), 'raw': forged})
        else:
            raise ClusterQualificationError('forged complete proof accepted: ' + name)
    return {'id': 'five_certificate_forgeries', 'status': 'PASS', 'cases': cases,
            'scope': 'Missing/duplicate alternatives, absent complete remainder, false DEAD, UNKNOWN cannot certify UNSAT. No solver replay.'}


def _indexed_negative_controls(C, O, lookup, clock, counters):
    source = lookup['multistep'][0]
    model, entry = source['model'], source['entry']
    prepared = O.prepare_model(model, budget=clock.tick)
    spec = C.export_unit_cell_csp(model, value_policy=POLICY)
    prepared_spec = O.prepare_unit_cell_spec(prepared, spec, budget=clock.tick)
    counters['L_preparations'] += 1
    counters['exports'] += 1
    counters['L_spec_preparations'] += 1
    cases = []
    def reject(name, category, function, raw=None):
        clock.tick()
        counters[category] += 1
        try:
            function()
        except O.IndexedOracleError as exc:
            cases.append({'id': name, 'rejected': True, 'reason': str(exc), 'raw': raw})
        else:
            raise ClusterQualificationError('indexed evidence forgery accepted: ' + name)
    point_mutations = {
        'schema': lambda s: s.__setitem__('schema', 'FOREIGN'),
        'selected': lambda s: s['selected'].append('FOREIGN_ID'),
        'excluded': lambda s: s['excluded'].append({'id': 'FOREIGN_ID', 'reason': 'CONTROL'}),
        'totals': lambda s: s['totals'].pop(),
        'markings': lambda s: s['markings'].append([77, 88, 'FOREIGN', '0', 1]),
        'point_generations': lambda s: s['point_generations'][0].__setitem__(2, True),
        'tile_generations': lambda s: s['tile_generations'].append(['FOREIGN_ID', 1]),
        'frontier': lambda s: s['frontier'][0]['candidates'].pop(),
        'candidate_rows': lambda s: s['candidate_rows'][0].__setitem__('legal', False),
        'active_candidates': lambda s: s['active_candidates'].pop(),
        'forward_incidence': lambda s: s['forward_incidence'].pop(),
        'reverse_incidence': lambda s: s['reverse_incidence'].pop(),
        'trail_size': lambda s: s.__setitem__('trail_size', -1),
    }
    for name, mutation in point_mutations.items():
        bad = _copy(entry)
        mutation(bad)
        reject('point_' + name, 'L_state_checks',
               lambda bad=bad: O.verify_point_snapshot(prepared, bad, value_policy=POLICY,
                                                       budget=clock.tick), bad)
    normal = O.verify_point_snapshot(prepared, entry, value_policy=POLICY,
                                     budget=clock.tick)['normalized_state']
    counters['L_state_checks'] += 1
    normalized_mutations = {
        'schema': lambda s: s.__setitem__('schema', 'FOREIGN'),
        'selected': lambda s: s['selected'].append('FOREIGN_ID'),
        'assigned': lambda s: s['assigned'].append({'point': [0, 0], 'id': 'A'}),
        'excluded': lambda s: s['excluded'].append({'id': 'FOREIGN_ID', 'reason': 'CONTROL'}),
        'physical_domains': lambda s: s['physical_domains'][0]['candidates'].pop(),
        'eligible_domains': lambda s: s['eligible_domains'][0]['candidates'].pop(),
        'active_candidates': lambda s: s['active_candidates'].pop(),
        'forward_incidence': lambda s: s['forward_incidence'].pop(),
        'reverse_incidence': lambda s: s['reverse_incidence'].pop(),
    }
    for name, mutation in normalized_mutations.items():
        bad = _copy(normal)
        mutation(bad)
        reject('normalized_' + name, 'L_state_checks',
               lambda bad=bad: O.verify_normalized_state(prepared_spec, bad, budget=clock.tick), bad)
    initial_event = {'kind': 'INITIALIZED', 'data': {}}
    initial_receipt, cursor = O.verify_point_event(prepared, entry, initial_event,
                                                   value_policy=POLICY, budget=clock.tick)
    counters['L_event_checks'] += 1
    _need(initial_receipt['status'] == 'VERIFIED', 'initial complete event')
    terminal = next(x for x in source['events'] if x['event']['kind'] == 'SOLVE_RESULT')
    reject('full_event_SAT_jump', 'L_event_checks',
           lambda: O.verify_point_event(prepared, terminal['state'], terminal['event'], cursor,
                                         value_policy=POLICY, budget=clock.tick),
           {'entry': entry, 'jump_state': terminal['state'], 'jump_event': terminal['event']})
    checkpoint = O.checkpoint(prepared, entry, native=True, budget=clock.tick)
    counters['L_checkpoints'] += 1
    reject('stale_checkpoint', 'L_rollback_checks',
           lambda: O.verify_rollback(prepared, checkpoint, source['final'], budget=clock.tick), source['final'])
    changed = _copy(model)
    changed['placements'][0]['type'] = 'FOREIGN_MODEL_TYPE'
    foreign_model = O.prepare_model(changed, budget=clock.tick)
    counters['L_preparations'] += 1
    reject('cross_model_checkpoint', 'L_rollback_checks',
           lambda: O.verify_rollback(foreign_model, checkpoint, entry, budget=clock.tick), entry)
    reject('cross_model_cursor', 'L_event_checks',
           lambda: O.verify_point_event(foreign_model, entry, initial_event, cursor,
                                         value_policy=POLICY, budget=clock.tick), entry)
    reject('cross_model_spec', 'L_spec_preparations',
           lambda: O.prepare_unit_cell_spec(foreign_model, spec, budget=clock.tick), spec)
    # Whole event-list verification, stopping at result; explicit rollback later
    # in _exercise has separate complete saved evidence and is not result history.
    csp_source = lookup['multistep'][1]
    history = []
    for saved in csp_source['events']:
        snapshot = saved['state']
        event = saved['event']
        history.append({'seq': len(history), 'kind': event['kind'], 'data': event['data'],
                        'snapshot': snapshot, 'domains_sha256': _sha(snapshot['eligible_domains']),
                        'state_sha256': _sha(snapshot)})
        if event['kind'] == 'SOLVE_RESULT':
            break
    full_check = O.verify_unit_cell_result(prepared_spec, csp_source['result'],
                                           normalized_events=history, budget=clock.tick)
    counters['L_result_checks'] += 1
    _need(full_check['status'] == 'VERIFIED', 'complete normalized history profile')
    truncated = [_copy(history[0]), _copy(history[-2]), _copy(history[-1])]
    for index, row in enumerate(truncated):
        row['seq'] = index
    reject('truncated_full_history', 'L_result_checks',
           lambda: O.verify_unit_cell_result(prepared_spec, csp_source['result'],
                                             normalized_events=truncated, budget=clock.tick), truncated)
    lex_spec = C.export_unit_cell_csp(model, value_policy=LEX)
    lex_prepared = O.prepare_unit_cell_spec(prepared, lex_spec, budget=clock.tick)
    counters['exports'] += 1
    counters['L_spec_preparations'] += 1
    reject('wrong_policy_spec_handle', 'L_result_checks',
           lambda: O.verify_unit_cell_result(lex_prepared, csp_source['result'], budget=clock.tick),
           csp_source['result'])
    altered_trail = _copy(entry)
    altered_trail['trail_size'] += 1
    reject('checkpoint_exact_trail_metadata', 'L_rollback_checks',
           lambda: O.verify_rollback(prepared, checkpoint, altered_trail, budget=clock.tick), altered_trail)
    return {'id': 'indexed_full_field_event_cache_negatives', 'status': 'PASS',
            'cases': cases, 'complete_history': history, 'complete_history_check': full_check,
            'scope': 'All13 native/all9 normalized field families; full-event SAT jump/truncation; stale/cross-model context/cache/spec; exact public trail checkpoint equality, not hidden trail reconstruction.'}
