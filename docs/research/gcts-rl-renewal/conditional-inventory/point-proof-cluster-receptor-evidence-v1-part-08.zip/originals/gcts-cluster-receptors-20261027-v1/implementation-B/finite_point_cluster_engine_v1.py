"""Finite exact point-value search; Source-only until separately authorized.

Every admitted placement has a single identity and may be used once.  All
required points are roots.  This is not a growing-frontier or geometric tiler.
The only module dependency is the standard library; there is no IO or CLI.
"""

import copy
import hashlib
import math
import json


VERSION = "GCTS-FINITE-POINT-CLUSTER-ENGINE-v1"
MODEL_SCHEMA = "GCTS-finite-point-instance-v1"
SNAPSHOT_SCHEMA = "GCTS-finite-point-snapshot-v1"
RESULT_SCHEMA = "GCTS-finite-point-solve-result-v1"


CLUSTER_VALUE_POLICY = "VALIDATED_CLUSTER_PREFERENCE_THEN_COMPLETE_LEX"
CLUSTER_OBSERVATION_SCHEMA = "GCTS-cluster-receptor-observation-v1"
CLUSTER_PACKET_SCHEMA = "GCTS-concrete-cluster-proposals-v1"
CLUSTER_RECEIPT_SCHEMA = "GCTS-cluster-proposal-receipt-v1"


class _ClusterJSONError(ValueError):
    """Private structural-copy refusal, never a search exclusion."""


def _cluster_hash(value):
    body = (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       separators=(",", ":"), allow_nan=False) + "\n").encode()
    return hashlib.sha256(body).hexdigest()


def _cluster_json_copy(value):
    """Copy plain JSON only; never invoke producer-defined copying methods."""
    active = set()
    def visit(item, depth):
        if depth > 64:
            raise _ClusterJSONError()
        kind = type(item)
        if item is None or kind in (bool, int, str):
            return item
        if kind is float:
            if not math.isfinite(item):
                raise _ClusterJSONError()
            return item
        if kind not in (list, dict) or id(item) in active:
            raise _ClusterJSONError()
        active.add(id(item))
        try:
            if kind is list:
                return [visit(v, depth + 1) for v in item]
            if any(type(k) is not str for k in item):
                raise _ClusterJSONError()
            return {k: visit(v, depth + 1) for k, v in item.items()}
        finally:
            active.remove(id(item))
    return visit(value, 0)


def _cluster_bitset(ids, active, order_sha):
    bits = bytearray((len(ids) + 7) // 8)
    for i, pid in enumerate(ids):
        if pid in active:
            bits[i // 8] |= 1 << (i % 8)
    return {"encoding": "LSB0_HEX", "id_order_sha256": order_sha,
            "universe_size": len(ids), "hex": bytes(bits).hex()}


class ModelError(ValueError):
    """Malformed explicit finite model or Wang compiler input."""


class EngineError(ValueError):
    """Invalid engine operation or callback protocol."""


class BudgetExceeded(RuntimeError):
    """Cooperative interruption; never an exhausted-search certificate."""


def _record(value, fields, label, error=ModelError):
    if type(value) is not dict or set(value) != set(fields):
        raise error(label + ": wrong record fields")


def _list(value, label, error=ModelError):
    if type(value) is not list:
        raise error(label + ": expected list")


def _string(value, label, error=ModelError):
    if type(value) is not str:
        raise error(label + ": expected literal string")


def _point(value, label, error=ModelError):
    if (type(value) is not list or len(value) != 2
            or any(type(v) is not int for v in value)):
        raise error(label + ": expected two exact integers")
    return tuple(value)


def _normalize_model(model):
    """Validate/copy the entire explicit universe, without semantic coercion."""
    _record(model, ("schema", "capacity", "required", "placements", "seeds"), "model")
    if model["schema"] != MODEL_SCHEMA or type(model["schema"]) is not str:
        raise ModelError("model: unsupported schema")
    cap = model["capacity"]
    if type(cap) is not int or cap <= 0:
        raise ModelError("capacity: expected positive exact integer")
    _list(model["required"], "required")
    required = set()
    for row in model["required"]:
        p = _point(row, "required point")
        if p in required:
            raise ModelError("required: duplicate point")
        required.add(p)
    _list(model["placements"], "placements")
    placements = {}
    for row in model["placements"]:
        _record(row, ("id", "type", "translation", "t", "m"), "placement")
        pid = row["id"]
        _string(pid, "placement id")
        _string(row["type"], "placement type")
        if pid in placements:
            raise ModelError("placements: duplicate id")
        translation = _point(row["translation"], "translation")
        _list(row["t"], "t")
        if not row["t"]:
            raise ModelError("placement: empty positive support")
        positive = {}
        for term in row["t"]:
            if type(term) is not list or len(term) != 3:
                raise ModelError("t: expected coordinate and units")
            p = _point(term[:2], "t point")
            units = term[2]
            if type(units) is not int or not 0 < units <= cap:
                raise ModelError("t: units outside capacity")
            if p in positive:
                raise ModelError("t: duplicate point")
            positive[p] = units
        _list(row["m"], "m")
        marking = {}
        for term in row["m"]:
            if type(term) is not list or len(term) != 4:
                raise ModelError("m: expected point/channel/value")
            p = _point(term[:2], "m point")
            _string(term[2], "m channel")
            _string(term[3], "m value")
            slot = p + (term[2],)
            if slot in marking:
                raise ModelError("m: duplicate slot")
            marking[slot] = term[3]
        placements[pid] = {
            "id": pid, "type": row["type"], "translation": list(translation),
            "t": [[p[0], p[1], positive[p]] for p in sorted(positive)],
            "m": [[s[0], s[1], s[2], marking[s]] for s in sorted(marking)],
        }
    _list(model["seeds"], "seeds")
    seeds = []
    seed_ids = set()
    for pid in model["seeds"]:
        _string(pid, "seed id")
        if pid not in placements or pid in seed_ids:
            raise ModelError("seeds: unknown or duplicate id")
        seed_ids.add(pid)
        seeds.append(pid)
    for pid, row in placements.items():
        if pid not in seed_ids and not any(tuple(t[:2]) in required for t in row["t"]):
            raise ModelError("nonseed placement must touch required positively")
    sums = {}
    marks = {}
    for pid in seeds:
        for x, y, units in placements[pid]["t"]:
            p = (x, y)
            sums[p] = sums.get(p, 0) + units
            if sums[p] > cap:
                raise ModelError("seeds: capacity conflict")
        for x, y, channel, value in placements[pid]["m"]:
            slot = (x, y, channel)
            if slot in marks and marks[slot] != value:
                raise ModelError("seeds: literal marking conflict")
            marks[slot] = value
    return {
        "schema": MODEL_SCHEMA, "capacity": cap,
        "required": [list(p) for p in sorted(required)],
        "placements": [placements[pid] for pid in sorted(placements)], "seeds": seeds,
    }


def reference_decision(frontier_rows):
    """Mandatory global dead, global forced, generation-first scheduler."""
    _list(frontier_rows, "frontier", EngineError)
    rows = []
    seen = set()
    for row in frontier_rows:
        _record(row, ("point", "generation", "candidates"), "frontier row", EngineError)
        p = _point(row["point"], "frontier point", EngineError)
        generation = row["generation"]
        if type(generation) is not int or generation < 0 or p in seen:
            raise EngineError("frontier: invalid generation or duplicate point")
        seen.add(p)
        _list(row["candidates"], "candidates", EngineError)
        ids = row["candidates"]
        if any(type(pid) is not str for pid in ids) or len(set(ids)) != len(ids):
            raise EngineError("frontier: invalid or duplicate candidate id")
        rows.append((p, generation, sorted(ids)))
    if not rows:
        return {"kind": "SOLUTION", "point": None, "candidates": []}
    dead = [r for r in rows if not r[2]]
    forced = [r for r in rows if len(r[2]) == 1]
    if dead:
        chosen = min(dead, key=lambda r: r[0])
        kind = "DEAD"
    elif forced:
        chosen = min(forced, key=lambda r: r[0])
        kind = "FORCED"
    else:
        chosen = min(rows, key=lambda r: (r[1], len(r[2]), r[0]))
        kind = "BRANCH"
    return {"kind": kind, "point": list(chosen[0]), "candidates": chosen[2]}


class Engine:
    """Incremental finite point engine with a semantic delta trail.

    Immutable values in mutable indexed maps make each undo record local.  The
    trail never contains a complete state/model snapshot.  Static dependency
    indexes cover all support; dynamic incidence indexes contain shared nodes.
    """

    def __init__(self, model, audit=None, budget=None, *, proposer=None,
                 proposal_audit=None, inventory_version="BASE", marking_version="MODEL"):
        if audit is not None and not callable(audit):
            raise EngineError("audit must be callable")
        if budget is not None and not callable(budget):
            raise EngineError("budget must be callable")
        self._model = _normalize_model(model)
        self._audit = audit
        self._budget = budget
        self._in_callback = False
        self._solving = False
        self._cluster_setup(proposer, proposal_audit, inventory_version, marking_version)
        self._cap = self._model["capacity"]
        self._required = frozenset(tuple(p) for p in self._model["required"])
        self._placements = {p["id"]: p for p in self._model["placements"]}
        self._ids = tuple(sorted(self._placements))
        self._t = {pid: {tuple(r[:2]): r[2] for r in p["t"]}
                   for pid, p in self._placements.items()}
        self._m = {pid: {tuple(r[:3]): r[3] for r in p["m"]}
                   for pid, p in self._placements.items()}
        self._dep_t = {}
        self._dep_m = {}
        for pid in self._ids:
            for p in self._t[pid]:
                self._dep_t.setdefault(p, set()).add(pid)
            for slot in self._m[pid]:
                self._dep_m.setdefault(slot, set()).add(pid)
        self._dep_t = {p: frozenset(ids) for p, ids in self._dep_t.items()}
        self._dep_m = {s: frozenset(ids) for s, ids in self._dep_m.items()}
        self._totals = {p: 0 for p in self._required | self._dep_t.keys()}
        self._marks = {}
        self._selected = list(self._model["seeds"])
        self._selected_ids = {pid: True for pid in self._selected}
        self._excluded = {}
        self._point_gen = {p: 0 for p in self._required}
        self._tile_gen = {pid: 0 for pid in self._selected}
        for pid in self._selected:
            for p, units in self._t[pid].items():
                self._totals[p] += units
                self._point_gen[p] = 0
            for slot, value in self._m[pid].items():
                old = self._marks.get(slot)
                self._marks[slot] = (value, 1 if old is None else old[1] + 1)
        self._conflicts = {pid: self._classify(pid) for pid in self._ids}
        self._frontier = {p: frozenset() for p in self._required if self._totals[p] < self._cap}
        self._reverse = {}
        for pid in self._ids:
            points = self._eligible_points(pid)
            if points:
                self._reverse[pid] = points
                for p in points:
                    self._frontier[p] = self._frontier[p] | {pid}
        self._trail = []
        self._boundaries = {0}
        nseed = len(self._selected)
        self._counts = {
            "attempts": nseed, "accepted_base_placements": nseed,
            "seed_placements": nseed, "forced_placements": 0,
            "branch_decisions": 0, "backtracks": 0,
            "candidate_removals": {r: 0 for r in (
                "SELECTED", "EXCLUDED", "CAPACITY", "MARKING", "NO_FRONTIER")},
            "max_frontier_points": 0, "max_active_candidates": 0, "max_edges": 0,
        }
        self._measure(frozenset())
        self._guard()
        self._emit("INITIALIZED", {})


    def _cluster_setup(self, proposer, proposal_audit, inventory_version, marking_version):
        if ((proposer is not None and not callable(proposer))
                or (proposal_audit is not None and not callable(proposal_audit))
                or (proposer is None and proposal_audit is not None)
                or type(inventory_version) is not str or not inventory_version
                or type(marking_version) is not str or not marking_version):
            raise self._cluster_error("invalid cluster callback/version configuration")
        self._proposer, self._proposal_audit = proposer, proposal_audit
        self._inventory_version, self._marking_version = inventory_version, marking_version
        self._cluster_model_sha = _cluster_hash(self._model)
        self._cluster_ids = tuple(row["id"] for row in self._model["placements"])
        self._cluster_order_sha = _cluster_hash(list(self._cluster_ids))
        self._proposal_records = []
        self._proposal_counts = {key: 0 for key in (
            "branch_observations", "proposer_calls", "packets_rejected",
            "clusters_proposed", "clusters_accepted", "clusters_rejected",
            "joint_members_checked", "joint_t_terms_checked", "joint_m_terms_checked",
            "branch_order_changes", "proposal_audit_calls")}

    @property
    def value_policy(self):
        return "LEX_ID" if self._proposer is None else CLUSTER_VALUE_POLICY

    @property
    def proposal_evidence(self):
        return copy.deepcopy(self._proposal_records)

    @property
    def proposal_metrics(self):
        return dict(self._proposal_counts)

    def _cluster_observation(self, choice):
        point = tuple(choice["point"])
        return {"schema": CLUSTER_OBSERVATION_SCHEMA,
                "model_sha256": self._cluster_model_sha,
                "inventory_version": self._inventory_version,
                "marking_version": self._marking_version,
                "value_policy": self.value_policy,
                "selected": list(self._selected), "excluded": sorted(self._excluded),
                "point": list(point), "generation": self._cluster_generation(point),
                "incident_domain": self._cluster_incident(point),
                "active_bitset": _cluster_bitset(self._cluster_ids, self._cluster_active(),
                                                 self._cluster_order_sha)}

    def _cluster_check(self, raw_cluster, index, seen, incident, active):
        self._guard()
        row = {"index": index, "raw_cluster": raw_cluster, "id": None,
               "shared_ids": [], "new_ids": [], "incident_ids": [],
               "accepted": False, "rejection": None}
        def reject(code):
            row["rejection"] = code
            return row
        if (type(raw_cluster) is not dict or set(raw_cluster) !=
                {"id", "inventory_version", "marking_version", "members"}):
            return reject("CLUSTER_SHAPE")
        cid = raw_cluster["id"]
        if type(cid) is not str or not cid or cid in seen:
            return reject("CLUSTER_ID")
        seen.add(cid)
        row["id"] = cid
        if (type(raw_cluster["inventory_version"]) is not str
                or type(raw_cluster["marking_version"]) is not str
                or raw_cluster["inventory_version"] != self._inventory_version
                or raw_cluster["marking_version"] != self._marking_version):
            return reject("CLUSTER_VERSION")
        members = raw_cluster["members"]
        if (type(members) is not list or not 1 <= len(members) <= 256
                or any(type(pid) is not str for pid in members)
                or len(set(members)) != len(members)):
            return reject("CLUSTER_MEMBERS")
        if any(pid not in self._placements for pid in members):
            return reject("UNKNOWN_MEMBER")
        row["shared_ids"] = [pid for pid in members if pid in self._selected_ids]
        row["new_ids"] = [pid for pid in members if pid not in self._selected_ids]
        row["incident_ids"] = [pid for pid in row["new_ids"] if pid in incident]
        if any(pid in self._excluded for pid in members):
            return reject("EXCLUDED_MEMBER")
        if any(pid not in active for pid in row["new_ids"]):
            return reject("INACTIVE_MEMBER")
        union = list(self._selected) + row["new_ids"]
        totals = {}
        for pid in union:
            self._guard()
            self._proposal_counts["joint_members_checked"] += 1
            for x, y, units in self._placements[pid]["t"]:
                self._proposal_counts["joint_t_terms_checked"] += 1
                if self._proposal_counts["joint_t_terms_checked"] % 64 == 0:
                    self._guard()
                p = (x, y)
                totals[p] = totals.get(p, 0) + units
                if totals[p] > self._model["capacity"]:
                    return reject("CAPACITY_CONFLICT")
        marks = {}
        for pid in union:
            self._guard()
            for x, y, channel, value in self._placements[pid]["m"]:
                self._proposal_counts["joint_m_terms_checked"] += 1
                if self._proposal_counts["joint_m_terms_checked"] % 64 == 0:
                    self._guard()
                slot = (x, y, channel)
                if slot in marks and marks[slot] != value:
                    return reject("MARKING_CONFLICT")
                marks[slot] = value
        if not row["incident_ids"]:
            return reject("NO_INCIDENT_MEMBER")
        row["accepted"] = True
        return row

    def _cluster_packet_order(self, packet, receipt, observation_sha, lexical):
        if packet is None:
            return lexical
        rejection = None
        if (type(packet) is not dict or set(packet) !=
                {"schema", "observation_sha256", "clusters"}
                or type(packet["schema"]) is not str
                or packet["schema"] != CLUSTER_PACKET_SCHEMA
                or type(packet["observation_sha256"]) is not str
                or type(packet["clusters"]) is not list):
            rejection = "PACKET_SHAPE"
        elif packet["observation_sha256"] != observation_sha:
            rejection = "PACKET_BINDING"
        elif len(packet["clusters"]) > 64:
            rejection = "PACKET_SIZE"
        if rejection:
            receipt["packet_rejection"] = rejection
            self._proposal_counts["packets_rejected"] += 1
            return lexical
        ordered, ranked, seen = [], set(), set()
        incident, active = set(lexical), self._cluster_active()
        for index, cluster in enumerate(packet["clusters"]):
            self._proposal_counts["clusters_proposed"] += 1
            row = self._cluster_check(cluster, index, seen, incident, active)
            receipt["clusters"].append(row)
            key = "clusters_accepted" if row["accepted"] else "clusters_rejected"
            self._proposal_counts[key] += 1
            if row["accepted"]:
                for pid in row["incident_ids"]:
                    if pid not in ranked:
                        ordered.append(pid)
                        ranked.add(pid)
        ordered.extend(pid for pid in lexical if pid not in ranked)
        return ordered

    def _cluster_order(self, choice):
        if self._proposer is None or choice["kind"] != "BRANCH":
            return choice
        self._guard()
        observation = self._cluster_observation(choice)
        before = _cluster_hash(observation)
        lexical = list(choice["candidates"])
        receipt = {"schema": CLUSTER_RECEIPT_SCHEMA,
                   "index": len(self._proposal_records), "status": "PENDING",
                   "observation": observation, "observation_sha256": before,
                   "raw_packet": None, "packet_rejection": None, "clusters": [],
                   "ordered_candidates": lexical,
                   "logical_before_sha256": before, "logical_after_sha256": None,
                   "value_policy": self.value_policy,
                   "counters": self.proposal_metrics, "error_type": None}
        self._proposal_records.append(receipt)
        self._proposal_counts["branch_observations"] += 1
        try:
            self._proposal_counts["proposer_calls"] += 1
            receipt["counters"] = self.proposal_metrics
            self._in_callback = True
            try:
                raw_packet = self._proposer(copy.deepcopy(observation))
            finally:
                self._in_callback = False
        except BaseException as error:
            receipt["status"] = "PROPOSER_EXCEPTION"
            receipt["error_type"] = type(error).__name__
            receipt["logical_after_sha256"] = _cluster_hash(self._cluster_observation(choice))
            receipt["counters"] = self.proposal_metrics
            raise
        try:
            try:
                packet = _cluster_json_copy(raw_packet)
            except _ClusterJSONError:
                receipt["packet_rejection"] = "NON_JSON_PACKET"
                self._proposal_counts["packets_rejected"] += 1
                ordered = lexical
            else:
                receipt["raw_packet"] = packet
                ordered = self._cluster_packet_order(packet, receipt, before, lexical)
            self._guard()
            after = _cluster_hash(self._cluster_observation(choice))
            if after != before:
                raise self._cluster_error("cluster callback changed logical state", operation=True)
            if ordered != lexical:
                self._proposal_counts["branch_order_changes"] += 1
            receipt["ordered_candidates"] = list(ordered)
            receipt["logical_after_sha256"] = after
            receipt["status"] = "VALIDATED"
            receipt["counters"] = self.proposal_metrics
            if self._proposal_audit is not None:
                self._proposal_counts["proposal_audit_calls"] += 1
                self._in_callback = True
                try:
                    self._proposal_audit(copy.deepcopy(receipt))
                finally:
                    self._in_callback = False
            return dict(choice, candidates=ordered)
        except BaseException as error:
            receipt["status"] = "INTERRUPTED"
            receipt["error_type"] = type(error).__name__
            receipt["logical_after_sha256"] = _cluster_hash(self._cluster_observation(choice))
            receipt["counters"] = self.proposal_metrics
            raise


    def _cluster_error(self, message, operation=False):
        return EngineError(message)

    def _cluster_active(self):
        return frozenset(self._reverse)

    def _cluster_incident(self, point):
        return sorted(self._frontier.get(point, ()))

    def _cluster_generation(self, point):
        return self._point_gen.get(point, 0)

    @property
    def model(self):
        return copy.deepcopy(self._model)

    @property
    def dependencies(self):
        return {
            "t": [{"point": list(p), "placements": sorted(self._dep_t[p])}
                  for p in sorted(self._dep_t)],
            "m": [{"point": list(s[:2]), "channel": s[2],
                   "placements": sorted(self._dep_m[s])} for s in sorted(self._dep_m)],
        }

    @property
    def metrics(self):
        result = copy.deepcopy(self._counts)
        result.update({"final_frontier_points": len(self._frontier),
                       "final_active_candidates": len(self._reverse),
                       "final_edges": sum(len(v) for v in self._reverse.values())})
        return result

    def _entry(self):
        if self._in_callback or self._solving:
            raise EngineError("reentrant mutation/decision/solve refused")

    def _guard(self):
        if self._budget is None:
            return
        self._in_callback = True
        try:
            value = self._budget()
        finally:
            self._in_callback = False
        if value is False:
            raise BudgetExceeded("external budget refused")
        if value is not None and value is not True:
            raise EngineError("budget must return None, True or False")

    def _emit(self, kind, data):
        if self._audit is None:
            return
        self._in_callback = True
        try:
            self._audit(self, {"kind": kind, "data": copy.deepcopy(data)})
        finally:
            self._in_callback = False

    def _set(self, name, key, value):
        table = getattr(self, name)
        exists = key in table
        old = table.get(key)
        if exists and old == value:
            return
        self._trail.append(("map", name, key, exists, old, True, value))
        table[key] = value

    def _delete(self, name, key):
        table = getattr(self, name)
        if key in table:
            self._trail.append(("map", name, key, True, table[key], False, None))
            del table[key]

    def _append_selected(self, pid):
        self._trail.append(("append", "_selected", None, False, None, True, pid))
        self._selected.append(pid)

    def _undo(self, checkpoint):
        while len(self._trail) > checkpoint:
            kind, name, key, existed, old, _new_exists, _new = self._trail.pop()
            table = getattr(self, name)
            if kind == "append":
                table.pop()
            elif existed:
                table[key] = old
            else:
                del table[key]
        self._boundaries = {cp for cp in self._boundaries if cp <= checkpoint}

    def _redo_deltas(self, deltas):
        # Transactional recovery from a failed rollback callback uses only the
        # removed local deltas, never a state snapshot or placement replay.
        for delta in deltas:
            kind, name, key, _existed, _old, new_exists, new = delta
            table = getattr(self, name)
            if kind == "append":
                table.append(new)
            elif new_exists:
                table[key] = new
            else:
                del table[key]
            self._trail.append(delta)

    def _classify(self, pid):
        cap = tuple(sorted(p for p, u in self._t[pid].items()
                           if self._totals[p] + u > self._cap))
        marks = tuple(sorted(s for s, v in self._m[pid].items()
                             if s in self._marks and self._marks[s][0] != v))
        return cap, marks

    def _legal(self, pid):
        cap, marks = self._conflicts[pid]
        return pid not in self._selected_ids and not cap and not marks

    def _eligible_points(self, pid):
        if pid in self._excluded or not self._legal(pid):
            return frozenset()
        return frozenset(p for p in self._t[pid] if p in self._frontier)

    def _sync(self, pid, new_points):
        old_points = self._reverse.get(pid, frozenset())
        for p in old_points - new_points:
            if p in self._frontier:
                self._set("_frontier", p, self._frontier[p] - {pid})
        for p in new_points - old_points:
            self._set("_frontier", p, self._frontier[p] | {pid})
        if new_points:
            self._set("_reverse", pid, new_points)
        else:
            self._delete("_reverse", pid)

    def _measure(self, old_active):
        for pid in old_active - self._reverse.keys():
            cap, marks = self._conflicts[pid]
            if pid in self._selected_ids:
                reason = "SELECTED"
            elif pid in self._excluded:
                reason = "EXCLUDED"
            elif cap:
                reason = "CAPACITY"
            elif marks:
                reason = "MARKING"
            else:
                reason = "NO_FRONTIER"
            self._counts["candidate_removals"][reason] += 1
        values = {"max_frontier_points": len(self._frontier),
                  "max_active_candidates": len(self._reverse),
                  "max_edges": sum(len(v) for v in self._reverse.values())}
        for name, value in values.items():
            self._counts[name] = max(self._counts[name], value)

    def snapshot(self):
        rows = []
        for pid in self._ids:
            cap, marks = self._conflicts[pid]
            rows.append({"id": pid, "selected": pid in self._selected_ids,
                         "excluded": pid in self._excluded, "legal": self._legal(pid),
                         "active": pid in self._reverse,
                         "capacity_conflicts": [list(p) for p in cap],
                         "marking_conflicts": [list(s) for s in marks]})
        return {
            "schema": SNAPSHOT_SCHEMA, "selected": list(self._selected),
            "excluded": [{"id": pid, "reason": self._excluded[pid]}
                         for pid in sorted(self._excluded)],
            "totals": [[p[0], p[1], self._totals[p]] for p in sorted(self._totals)],
            "markings": [[s[0], s[1], s[2], self._marks[s][0], self._marks[s][1]]
                         for s in sorted(self._marks)],
            "point_generations": [[p[0], p[1], self._point_gen[p]] for p in sorted(self._point_gen)],
            "tile_generations": [[pid, self._tile_gen[pid]] for pid in self._selected],
            "frontier": self._frontier_rows(), "candidate_rows": rows,
            "active_candidates": sorted(self._reverse),
            "forward_incidence": [[p[0], p[1], pid, self._t[pid][p]]
                                  for p in sorted(self._frontier)
                                  for pid in sorted(self._frontier[p])],
            "reverse_incidence": [{"id": pid, "points": [
                [p[0], p[1], self._t[pid][p]] for p in sorted(self._reverse[pid])]}
                                  for pid in sorted(self._reverse)],
            "trail_size": len(self._trail),
        }

    def _frontier_rows(self):
        return [{"point": list(p), "generation": self._point_gen[p],
                 "candidates": sorted(self._frontier[p])} for p in sorted(self._frontier)]

    def checkpoint(self):
        return len(self._trail)

    def _check_id_reason(self, pid, reason):
        _string(pid, "placement id", EngineError)
        _string(reason, "reason", EngineError)
        if pid not in self._placements:
            raise EngineError("unknown placement id")

    def _place(self, pid, reason, forced=False):
        self._check_id_reason(pid, reason)
        self._counts["attempts"] += 1
        self._guard()
        if pid in self._selected_ids or pid in self._excluded or not self._legal(pid):
            raise EngineError("placement not available/legal")
        cp = len(self._trail)
        old_active = frozenset(self._reverse)
        generation = 1 + min(self._point_gen[p] for p in self._t[pid] if p in self._point_gen)
        try:
            self._set("_selected_ids", pid, True)
            self._append_selected(pid)
            self._set("_tile_gen", pid, generation)
            affected = {pid}
            for p, units in self._t[pid].items():
                self._set("_totals", p, self._totals[p] + units)
                self._set("_point_gen", p, min(self._point_gen.get(p, generation), generation))
                affected.update(self._dep_t[p])
                if p in self._frontier and self._totals[p] == self._cap:
                    self._delete("_frontier", p)
            for slot, value in self._m[pid].items():
                old = self._marks.get(slot)
                self._set("_marks", slot, (value, 1 if old is None else old[1] + 1))
                affected.update(self._dep_m[slot])
            for other in sorted(affected):
                self._set("_conflicts", other, self._classify(other))
            for other in sorted(affected):
                self._sync(other, self._eligible_points(other))
            self._boundaries.add(len(self._trail))
            self._counts["accepted_base_placements"] += 1
            if forced:
                self._counts["forced_placements"] += 1
            self._measure(old_active)
            self._emit("PLACED", {"id": pid, "reason": reason, "generation": generation})
        except BaseException:
            self._undo(cp)
            raise

    def place(self, placement_id, reason):
        self._entry()
        self._place(placement_id, reason)

    def _exclude(self, pid, reason):
        self._check_id_reason(pid, reason)
        self._guard()
        if pid in self._selected_ids or pid in self._excluded:
            raise EngineError("placement cannot be excluded twice or after selection")
        cp = len(self._trail)
        old_active = frozenset(self._reverse)
        try:
            self._set("_excluded", pid, reason)
            self._sync(pid, frozenset())
            self._boundaries.add(len(self._trail))
            self._measure(old_active)
            self._emit("EXCLUDED", {"id": pid, "reason": reason})
        except BaseException:
            self._undo(cp)
            raise

    def exclude(self, placement_id, reason):
        self._entry()
        self._exclude(placement_id, reason)

    def rollback(self, checkpoint):
        self._entry()
        if type(checkpoint) is not int or checkpoint not in self._boundaries:
            raise EngineError("checkpoint is not a reachable stable boundary")
        self._guard()
        removed_deltas = self._trail[checkpoint:]
        boundaries = set(self._boundaries)
        self._undo(checkpoint)
        try:
            self._emit("ROLLED_BACK", {"checkpoint": checkpoint})
        except BaseException:
            self._redo_deltas(removed_deltas)
            self._boundaries = boundaries
            raise

    def _decision(self):
        self._guard()
        result = reference_decision(self._frontier_rows())
        result = self._cluster_order(result)
        self._emit("DECISION", result)
        return result

    def decision(self):
        self._entry()
        return self._decision()

    def _whole_solution(self):
        """Recompute from admitted raw placements, not cached graph legality."""
        if len(set(self._selected)) != len(self._selected):
            return False
        if not set(self._model["seeds"]).issubset(self._selected):
            return False
        sums = {}
        marks = {}
        for pid in self._selected:
            if pid not in self._placements or pid in self._excluded:
                return False
            row = self._placements[pid]
            for x, y, units in row["t"]:
                p = (x, y)
                sums[p] = sums.get(p, 0) + units
                if sums[p] > self._cap:
                    return False
            for x, y, channel, value in row["m"]:
                slot = (x, y, channel)
                if slot in marks and marks[slot] != value:
                    return False
                marks[slot] = value
        return all(sums.get(p, 0) == self._cap for p in self._required)

    def _result(self, status, reason, nodes, context):
        self._emit("SOLVE_RESULT", {"status": status, "nodes": nodes, "reason": reason})
        return {"schema": RESULT_SCHEMA, "status": status, "reason": reason,
                "nodes": nodes, "selected": list(self._selected),
                "context": copy.deepcopy(context), "model": self.model,
                "solution_verified": status == "FINITE_EXACT_SOLUTION", "metrics": self.metrics}

    def solve(self, node_limit=100000):
        self._entry()
        if type(node_limit) is not int or node_limit < 0:
            raise EngineError("node_limit must be a nonnegative exact integer")
        entry = len(self._trail)
        context = {"selected": list(self._selected), "excluded": [
            {"id": pid, "reason": self._excluded[pid]} for pid in sorted(self._excluded)]}
        nodes = 0
        stack = []
        self._solving = True
        try:
            try:
                while True:
                    if nodes >= node_limit:
                        self._undo(entry)
                        return self._result("UNKNOWN", "NODE_LIMIT", nodes, context)
                    choice = self._decision()
                    nodes += 1
                    if choice["kind"] == "SOLUTION":
                        if not self._whole_solution():
                            raise EngineError("whole selected-set verification failed")
                        return self._result("FINITE_EXACT_SOLUTION", "SOLUTION", nodes, context)
                    if choice["kind"] == "DEAD":
                        if not stack:
                            self._undo(entry)
                            return self._result("EXHAUSTED_FINITE_SEARCH", "EXHAUSTED", nodes, context)
                        parent, failed = stack.pop()
                        self._undo(parent)
                        self._emit("ROLLED_BACK", {"checkpoint": parent})
                        # The child reached DEAD after all of its alternatives
                        # were exhausted. This exclusion belongs only here.
                        self._exclude(failed, "EXHAUSTED_CHILD")
                        self._counts["backtracks"] += 1
                        continue
                    pid = choice["candidates"][0]
                    if choice["kind"] == "BRANCH":
                        stack.append((len(self._trail), pid))
                        self._counts["branch_decisions"] += 1
                        self._place(pid, "BRANCH")
                    else:
                        self._place(pid, "FORCED", forced=True)
            except BudgetExceeded:
                self._undo(entry)
                try:
                    return self._result("UNKNOWN", "EXTERNAL_BUDGET", nodes, context)
                except BudgetExceeded:
                    # A failing final negative notification cannot admit a
                    # positive/exhausted result. Its only permitted result is
                    # UNKNOWN, with entry state already restored.
                    return {"schema": RESULT_SCHEMA, "status": "UNKNOWN",
                            "reason": "EXTERNAL_BUDGET", "nodes": nodes,
                            "selected": list(self._selected), "context": copy.deepcopy(context),
                            "model": self.model, "solution_verified": False, "metrics": self.metrics}
        except BaseException:
            self._undo(entry)
            raise
        finally:
            self._solving = False


def _encoded(value):
    return json.dumps(value, ensure_ascii=True, separators=(",", ":"))


def compile_wang(palette, region, boundary=None):
    """Finite translation-only anchor/midpoint model with positive collar.

    Boundary records constrain exposed edges only.  Unspecified exposed edges
    remain free.  One fixed seed represents each constrained exterior neighbor,
    including a neighbor adjacent to several region cells around a hole.
    """
    _list(palette, "palette")
    tiles = {}
    for row in palette:
        _record(row, ("id", "N", "E", "S", "W"), "Wang tile")
        for key in ("id", "N", "E", "S", "W"):
            _string(row[key], "Wang " + key)
        if row["id"] in tiles:
            raise ModelError("palette: duplicate id")
        tiles[row["id"]] = dict(row)
    _list(region, "region")
    cells = set()
    for row in region:
        p = _point(row, "region point")
        if p in cells:
            raise ModelError("region: duplicate cell")
        cells.add(p)
    directions = {"N": (0, -1), "E": (1, 0), "S": (0, 1), "W": (-1, 0)}
    if boundary is None:
        boundary = []
    _list(boundary, "boundary")
    seen = set()
    collar = {}
    for row in boundary:
        if type(row) is not list or len(row) != 4:
            raise ModelError("boundary: expected point/direction/color")
        p = _point(row[:2], "boundary point")
        direction, color = row[2:]
        _string(direction, "boundary direction")
        _string(color, "boundary color")
        if direction not in directions or p not in cells:
            raise ModelError("boundary: invalid cell/direction")
        dx, dy = directions[direction]
        z = (p[0] + dx, p[1] + dy)
        key = p + (direction,)
        if z in cells or key in seen:
            raise ModelError("boundary: repeated or nonexposed edge")
        seen.add(key)
        # Midpoint relative to exterior anchor is the inward unit vector.
        collar.setdefault(z, {})[(-dx, -dy)] = color
    placements = []
    for x, y in sorted(cells):
        for pid in sorted(tiles):
            tile = tiles[pid]
            placements.append({
                "id": _encoded(["WANG", pid, x, y]), "type": _encoded(["WANG", pid]),
                "translation": [2 * x, 2 * y], "t": [[2 * x, 2 * y, 1]],
                "m": [[2 * x + dx, 2 * y + dy, "WANG", tile[d]]
                      for d, (dx, dy) in directions.items()],
            })
    seeds = []
    for x, y in sorted(collar):
        pattern = [[dx, dy, color] for (dx, dy), color in sorted(collar[(x, y)].items())]
        pid = _encoded(["COLLAR", x, y])
        seeds.append(pid)
        placements.append({
            "id": pid, "type": _encoded(["COLLAR", pattern]),
            "translation": [2 * x, 2 * y], "t": [[2 * x, 2 * y, 1]],
            "m": [[2 * x + dx, 2 * y + dy, "WANG", color] for dx, dy, color in pattern],
        })
    return _normalize_model({
        "schema": MODEL_SCHEMA, "capacity": 1,
        "required": [[2 * x, 2 * y] for x, y in sorted(cells | collar.keys())],
        "placements": placements, "seeds": seeds,
    })
