Common-model quantified symbolic mechanism comparison.

The manifest maps original task paths to literal whole bytes in objects/SHA256. All six once-only runs and native records are retained, plus raw JSON and report projections. Never reuse consumed actual directories/grants. A new execution needs new frozen inputs/reviews/Root maxone grants.

Python and full Z3 are external pinned runtime dependencies. Native checker source/binary, fixed program/microcode and actual data are included. Bundled standard library, platform and loader remain trusted. Memory analysis concerns preceding quantified cohort, whose existing evidence archive is separately identified.

This evidence does not establish general GCTS or RL advantage, heldout generalization, full first-order completeness, a universal primitive Wang palette, induction, full Hilbert geometry or plane tiling.
