"""Static Source correspondence only; no custodian or scientific code run."""
from pathlib import Path
import ast
import hashlib
import json

C=Path(__file__).resolve().parent
D=C.parent
R=D/'root'
OLD=D.parent/'gcts-principal-receptor-families-20261021'

def pin(path):
    path=Path(path).resolve();b=path.read_bytes()
    return dict(path=str(path),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())

def load(path):
    return json.loads(Path(path).read_bytes())

worker=R/'fixed_family_worker_v1.py'
parent=R/'run_fixed_family_once_v1.py'
observer=R/'observe_fixed_family_once_v1.py'
expected=[('125e4261305f7949685df38e59185c6df0a6cea7bbf19f9b058de3b2fd74545c',17314),
 ('98c55321bb87a8c04b2c6d56b357aba9c3a8f5fc98660474ae3ac1c9d00b0aca',12973),
 ('24804c7d4558d8df511942d9e6b2e4d8d2cfd88ce7df6f5b5f775f87d0c20ca9',10113)]
for path,(sha,size) in zip([worker,parent,observer],expected):
    row=pin(path);assert row['sha256']==sha and row['bytes']==size
    tree=ast.parse(path.read_bytes(),filename=str(path))
    compile(tree,str(path),'exec',dont_inherit=True)  # unused code object
assert parent.read_bytes()==(OLD/'root/run_mechanism_once_v1.py').read_bytes()
assert observer.read_bytes()==(OLD/'root/observe_mechanism_once_v1.py').read_bytes()
composition=load(R/'custody-Source-composition-v1.json')
assert composition['outputs']==[pin(worker),pin(parent),pin(observer)]
assert composition['base_worker']==pin(OLD/'root/mechanism_worker_v1.py')
before=ast.parse((OLD/'root/mechanism_worker_v1.py').read_bytes())
after=ast.parse(worker.read_bytes())
def named(tree,name,kind=ast.FunctionDef):
    found=[n for n in ast.walk(tree) if isinstance(n,kind) and n.name==name]
    assert len(found)==1
    return ast.dump(found[0],include_attributes=False)
same_functions=['raw_pin','canonical','write_complete','check','custody_check',
                'stage','verify_files','construct_oracle']
for name in same_functions:
    assert named(before,name)==named(after,name)
assert named(before,'RootRequestOracle',ast.ClassDef)==named(after,'RootRequestOracle',ast.ClassDef)
assert named(before,'RootBudget',ast.ClassDef)==named(after,'RootBudget',ast.ClassDef)
protocol=load(R/'protocol-v1.json')
assert pin(R/'protocol-v1.json')['sha256']=='76c7c5466c3d3e53e9d1d042fd411b17c61223142b73b41f9ac95424fd105309'
assert protocol['experiment_limits']['compile_queries']==512 and protocol['experiment_limits']['native_steps']==1000000000
assert protocol['limits']==dict(work_seconds=160,positive_seconds=180,custody_seconds=210,
    observer_fallback_seconds=225,memory_bytes=1073741824,physical_bytes=134217728,
    result_bytes=50331648,log_bytes=4194304,reserved_outer_bytes=9437184,root_callbacks=400000000)

checks=[
 dict(id='exact frozen Source and original complete custodian preservation',passed=True,
      evidence='All three requested raw pins/sizes and composition outputs match. Parent and observer are byte-identical to the fully reviewed D16 Sources, including owned process-group monitoring, bounded pipe logs, disappearance-safe file census, final known-exit/output gates, cleanup and complete atomic outputs.'),
 dict(id='worker exact consumed-plan and owned-process preconditions',passed=True,
      evidence='Worker joins the raw plan hash, case and actual directory to CONSUMED before scientific imports. Parent retains exact fresh-grant validation/consumption and process-group creation. Darwin resident-memory interpretation is explicit; FSIZE is a file ceiling, not a resident-memory sandbox.'),
 dict(id='unchanged sticky Root work/custody first fault and counters',passed=True,
      evidence='check/custody_check/stage/verify_files have identical ASTs to D16. First Root fault is retained and rethrown before later fault classification; one cumulative callback count and original absolute work/custody deadlines remain.'),
 dict(id='global Native start and step guard before delegation',passed=True,
      evidence='RootRequestOracle class and construct_oracle ASTs are identical to D16. Every request invokes genuine check before requiring exact-int positive steps within the plan ceiling and remaining whole-start quota; increments starts before super.request. Exceeding a ceiling latches the Root fault. Root protocol fixes these to 512 starts and 1e9 micro steps; exact future plans must retain those values.'),
 dict(id='whole fixed Native program and bounded transport custody',passed=True,
      evidence='Unchanged full program/microcode digest join precedes fixed binary generation inside the actual. Owned executable raw copy is checked. The bounded persistent transport retains complete records, stage/budget/digest metadata, exact owned group, normal closure/reaping and measured Native high water; no transport status self-admits a theorem.'),
 dict(id='exact single fresh-acquisition envelope and raw completed-body intake',passed=True,
      evidence='Acquire requires no upstream and returns acquisition=None/receipt=None. Evaluate requires exactly acquire-0 and one 13-field Root envelope, no policy/history and prior_cost_receipts=[]. read_complete_pin rejects partial basenames, checks exact raw hash/size/path and only then parses completed JSON. Full plan/result/header/terminal/observer join, scientific stage completeness and exact export digest are checked.'),
 dict(id='upstream resource and known completion joins',passed=True,
      evidence='Matching IDs/stage, COMPLETE result/header, no Root fault, source guards, closed/reaped Native, identical embedded header/output pin, zero worker/parent exits, no errors/reason, final custody pass, positive exit gate, observer acceptance/no fallback, owned plan hash, whole-peak/custody samples and envelope cost fields must all agree.'),
 dict(id='cold phase dispatch and semantic trust boundary',passed=True,
      evidence='Worker invokes only run_fixed_stage with the current phase document, one upstream export/receipt and six fixed scientific roles. It does not select proofs/families or train weights. Entry owns complete scientific export reconstruction; Root admission owns raw Native-record joins. Phase exclusion/freshness are NOT inferred from a generic stage ID or envelope flag alone.'),
 dict(id='complete result/failure, final output and conservative resource authority',passed=True,
      evidence='Original result/failure byte ceiling, atomic partial-to-complete rename and post-output Python header sample retained. Worker cannot turn failure into result. Parent and observer conservatively include child/Python/Native/own high-water samples plus output reserves, known terminal exits, EOF and physical/time gates. Internal COMPLETE/resource flags are not a substitute for independent whole scientific admission.'),
 dict(id='protocol binding and no implicit plan/actual authority',passed=True,
      evidence='Current Root protocol declares original caps, unique new D17 acquisition, no evaluation-bearing acquire files, complete upstream Source/scientific/resource/owned-Native admission and seal, same64 slots/17 jobs, no old export or weights, common v3 plus one tiny calibration, and uniform omission of unused registry. Exact B entry/phase plans/materializer/seal and actual results remain unreviewed here.')
]

result=dict(schema='typed-principal-search-custodian-Source-review-v1',
 reviewer_identity='/root/recovered_batch_review',review_passed=True,source_only=True,
 scientific_imports=0,scientific_calls=0,custodian_calls=0,helpers_executed=0,
 AST_parsed_unused_compiled=3,compiled_code_executed=False,partial_files_parsed=False,
 actual_execution_authorized=False,whole_plan_approved=False,
 input_pins=[pin(worker),pin(parent),pin(observer),pin(R/'custody-Source-composition-v1.json'),pin(R/'protocol-v1.json')],
 original_Source_pins=[pin(OLD/'root/mechanism_worker_v1.py'),pin(OLD/'root/run_mechanism_once_v1.py'),pin(OLD/'root/observe_mechanism_once_v1.py')],
 prior_independent_full_Source_review=pin(OLD/'review-C/typed-principal-mechanism-whole-Source-plan-review-v1.json'),
 exact_worker_preserved_ASTs=same_functions+['RootRequestOracle class','RootBudget class'],
 new_top_level_functions=['read_complete_pin','intake_upstream'],
 changed_top_level_function='main: phase/intake/stage dispatch and receipt label; preserved nested resource/transport guards above',
 checks=checks,failed_checks=[],
 required_future_whole_plan_conditions=[
   'The exact configured Source closure/limits/experiment_limits, modules, input body and current raw Sources must be independently reviewed. This worker is not a validator for arbitrary supplied plans.',
   'Acquire plan.files is read in full by verify_files. It must exclude evaluation-input bodies, earlier evaluation/mechanism results, display/statement documents carrying evaluation formulas and other irrelevant target-bearing files. Metadata containing IDs/hashes alone is separately scoped.',
   'Evaluation must pin the unique newly admitted D17 acquire-0 plan/result/header/terminal/observer, the current owned Native-record join, independent scientific/resource admission, complete export and Root seal. A matching stage_id alone does not prove freshness.',
   'Upstream source_plan limits and receipts are trusted only through their exact reviewed raw pins and admission workflow. Generic 13-field shape/resource flags do not substitute for exact original caps, complete file/log census or scientific proof checks.',
   'The entry must revalidate whole donor/candidate ancestry, Host proofs, owned accepted Native evidence, complete independent typing and paired wrappers before evaluation use. This component review does not approve its still-pending Source.',
   'Complete old C calibration module peer review is required; current independent L receipt 6886cd06… satisfies the Source peer barrier only. The calibration and all experiment controls remain unrun.',
   'A fresh exact plan review and Root once grant are still mandatory for acquisition; dependent materialized evaluation plans require their own reviews after admitted acquisition. No retry or changed-bound authority follows.'
 ],
 limitations=[
   'Fixed-dependency nonhostile reproducible custody, not an adversarial sandbox, physical OS real-time guarantee or cryptographic authenticity proof.',
   'Source equality and unused compilation do not establish runtime fit, successful Native construction, acquisition completion or proof-search benefit.',
   'Read-hash/read-parse intake and live file census assume the declared immutable nonhostile files. Parent/observer final receipts and terminal tool exit remain required at actual admission.',
   'No inference is made about D15/D16 qualification, whole physical Wang interpretation, generic G0/G1 admission, learned RL or new mathematical theorems.'
 ],tools_stopped_after_freeze=True)
p=C/'typed-principal-search-custodian-Source-review-v1.json';assert not p.exists()
p.write_text(json.dumps(result,sort_keys=True,ensure_ascii=True,allow_nan=False,indent=2)+'\n')
print(json.dumps(dict(review=pin(p),review_passed=True,checks=len(checks),failed_checks=[])))
