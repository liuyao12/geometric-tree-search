"""C-owned raw-byte and complete JSON audit. No scientific modules imported."""
import collections
import hashlib
import json
from pathlib import Path

D=Path(__file__).resolve().parents[1]; C=D/'review-C'; R=D/'root'
cache={}
def pin(p):
    p=Path(p).resolve()
    if str(p) not in cache:
        b=p.read_bytes();cache[str(p)]=dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
    return cache[str(p)]
def load(p):
    assert '.partial' not in Path(p).name
    return json.loads(Path(p).read_text())
def verify(p):assert pin(p['path'])==p,p['path']
def digest(v):return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
def tuples(v):return [tuple(x) for x in v]

indexp=R/'materialized-evaluation-plans-v2.json';index=load(indexp)
preflightp=C/'typed-fixed-family-evaluation16-plan-review-v1.json';preflight=load(preflightp)
acqreviewp=C/'typed-fixed-principal-family-acquisition-actual-review-v1.json'
acqreview=load(acqreviewp);acqseal=load(R/'seals/acquire-0-v1.json')
acq=load(acqseal['result']['path'])['scientific_result']
assert preflight['review_passed'] is acqreview['review_passed'] is True
assert preflight['plans']==index['plans']
assert pin(preflightp)['sha256']=='e1727660b0e30c5ef2aafd5dc61fad59dc736fa0c57497968044deb993b9daf8'
for row in preflight['complete_unique_input_pins']:verify(row)
grantindexp=R/'evaluation16-grants-v1.json';grantindex=load(grantindexp)
barrierp=R/'serial-barrier-evaluation16-v1.json';barrier=load(barrierp)
toolp=R/'evaluation16-tool-terminal-transcription-v1.json';tool=load(toolp)
assert grantindex['C_review']==pin(preflightp)
assert barrier['plans']==index['plans']
assert len(tool['observations'])==16 and tool['serial_order'] is True
assert [g['path'] for g in grantindex['grants']]==[str(R/'grants'/(p['stage_id']+'-v1.json')) for p in preflight['plan_details']]

case_rows=[];all_arm_rows=[];native_rows=[];all_files=[];pool_rows=[]
aggregate=collections.Counter();native_status=collections.Counter();methods=collections.defaultdict(collections.Counter)
frozen_libraries=acq['export']['libraries'];library_digest=digest(frozen_libraries)
evaldoc=load(preflight['plan_details'][0]['input']['path'])
specs={v['id']:v for v in evaldoc['evaluation']}
expected_acq_native={c['native_record']['id']:c['native_record'] for c in acq['certificates']}
expected_acq_native.update({r['proof_check']['native_record']['id']:r['proof_check']['native_record'] for r in acq['records']})

for ordinal,(offered,detail,gpin,toolrow) in enumerate(zip(index['plans'],preflight['plan_details'],grantindex['grants'],tool['observations'])):
    verify(offered);verify(gpin)
    p=load(offered['path']);cid=p['case_id'];A=Path(p['actual_dir']);O=Path(str(A)+'.observer')
    assert cid==detail['stage_id']==barrier['execution_order'][ordinal]
    assert len(p['files'])==100
    for row in p['files']:verify(row)
    grant=load(gpin['path']);consumed=load(A/'CONSUMED.json');owner=load(A/'owned-child.json')
    assert grant['authorized'] is grant['review_passed'] is True and grant['uses']==consumed['uses']==1
    assert grant['C_review']==pin(preflightp) and grant['serial_barrier']==pin(barrierp)
    assert grant['plan_sha256']==consumed['plan_sha256']==owner['plan_sha256']==offered['sha256']
    assert consumed['grant_sha256']==gpin['sha256'] and consumed['case_id']==cid
    assert grant['runner_sha256']==pin(p['runner_path'])['sha256']
    assert owner['child_pid']==owner['child_pgid']
    h=load(A/'worker-header.json');t=load(A/'terminal.json');o=load(O/'observer.json')
    returned=(A/'result.json').exists()
    bodyp=A/('result.json' if returned else 'failure.json');r=load(bodyp)
    assert not (A/('failure.json' if returned else 'result.json')).exists()
    assert h['result']==pin(bodyp) and r['case_id']==h['case_id']==t['case_id']==o['case_id']==cid
    assert t['header']==h and o['owned_child']==owner
    assert r['source_unchanged'] is h['source_unchanged'] is t['sources_unchanged'] is True
    assert r['callbacks']==h['callbacks']<p['limits']['root_callbacks']
    assert t['threads_terminal'] is True and t['errors']==o['errors']==[]
    assert t['reason'] is o['reason'] is None
    assert t['final_custody_gate_passed'] is True and t['final_custody_gate_seconds']<p['limits']['custody_seconds']
    assert o['final_observer_gate_seconds']<p['limits']['observer_fallback_seconds'] and o['fallback_trigger_seconds'] is None
    assert o['partial_files_parsed'] is False
    for obj,root in ((t,A),(o,O)):
        for name in ('stdout','stderr'):
            lg=obj['logs'][name];assert lg['eof'] is True and lg['overflow'] is False
            assert lg['stored']==lg['bytes']==pin(root/(name+'.bin'))['bytes']<=p['limits']['log_bytes']
    census=[pin(q) for root in (A,O) for q in sorted(root.rglob('*')) if q.is_file()]
    partials=[v for v in census if '.partial' in Path(v['path']).name]
    assert not partials and len(census)==(14 if returned else 13)
    all_files.extend(census)
    physical=sum(v['bytes'] for v in census)
    assert physical+p['limits']['reserved_outer_bytes']<p['limits']['physical_bytes']
    assert pin(bodyp)['bytes']<p['limits']['result_bytes']
    nt=r['native_transport'];qs=r['native_queries'];stages=nt['request_stages']
    assert nt['closed'] is nt['all_reaped'] is nt['same_owned_process_group'] is True
    assert nt['cleanup_errors']==[] and nt['stdout_eof'] is nt['stderr_complete'] is True
    assert nt['stderr_bytes']==nt['stdout_pending_bytes']==0
    assert nt['native_pgid']==nt['parent_pgid']==owner['child_pgid'] and nt['parent_pid']==owner['child_pid']
    assert h['native_closed_and_reaped'] is True
    assert len(qs)==nt['complete_records'] and len(stages)==r['native_requests_started']<=512
    qcounts=collections.Counter()
    for qid,q in enumerate(qs):
        st=stages[qid]
        assert q['id']==st['ordinal']==st['record_id']==qid and st['stage']=='COMPLETED'
        assert st['limit']==1000000000 and q['result']['micro_steps']<=st['limit']
        assert q['query_target']=='fixed_assertion' and q['request']['protocol']=='gcts-fol-1' and q['request']['blocks']==[]
        assert q['request_sha256']==st['request_sha256']==digest(q['request'])
        assert q['purpose']==st['purpose'] and q['input_sha256']==st['input_sha256'] and q['output_sha256']==st['output_sha256']
        assert q['result']['status'] in ('accepted','rejected','unknown_step_budget','unknown_space_budget')
        qcounts[q['result']['status']]+=1
        native_rows.append(dict(stage_id=cid,id=qid,purpose=q['purpose'],status=q['result']['status'],request_sha256=q['request_sha256'],micro_steps=q['result']['micro_steps']))
    native_status.update(qcounts)
    assert pin(A/'native/boundary-oracle')['sha256']==pin(p['native']['executable_path'])['sha256']
    assert pin(A/'native/code.bin')['sha256']=='97f0b600cffd83552c4e0f0c4fb1f5d26cfdb76e3e74b267bbaebeddc836e7ed'
    assert pin(A/'native/input.bin')['sha256']==stages[-1]['input_sha256']
    if returned:assert pin(A/'native/output.bin')['sha256']==qs[-1]['output_sha256']
    assert toolrow['exit_code']==(0 if returned else 2)
    tool_output=toolrow['output']
    # Tool receipt is a Root transcription, distinct from on-disk clock authority.
    assert tool_output['resource_candidate_accepted'] is returned
    resource=o['resource_candidate_accepted'] is True
    assert resource is returned
    if returned:
        assert r['status']==h['status']=='COMPLETE' and r['error'] is None
        assert r['first_Root_fault'] is h['first_Root_fault'] is False
        assert t['process_exit_code']==o['parent_exit_code']==nt['native_exit_code']==nt['wait4_status']==0
        assert nt['termination_signals']==[] and len(qs)==len(stages)
        assert t['header_valid'] is True and t['result']==pin(bodyp)
        assert r['elapsed_seconds']<h['seconds']<p['limits']['positive_seconds']
        for stage in r['stages']:
            assert stage['status']=='COMPLETED' and stage['began']+stage['seconds']<p['limits']['work_seconds']
        parent=t['parent_usage']['ru_maxrss']+max(t['child_usage']['ru_maxrss'],h['python_peak_after_output_bytes'])+h['native_peak_bytes']+t['memory_terminal_output_reserve_bytes']
        assert parent==t['conservative_combined_peak_bytes']
        peak=parent+max(o['observer_peak_before_receipt_bytes'],o['final_observer_peak_bytes'])+o['final_output_memory_reserve_bytes']
        assert peak==o['conservative_whole_peak_bytes']==o['final_conservative_whole_peak_bytes']<p['limits']['memory_bytes']
    else:
        assert r['status']==h['status']=='FAILED_CASE_NOT_ADMITTED'
        assert r['scientific_result'] is None and r['first_Root_fault'] is h['first_Root_fault'] is True
        assert r['error']['type']=='RootBudget' and r['error']['message']=='absolute case work deadline'
        assert t['process_exit_code']==o['parent_exit_code']==2 and t['result'] is None and t['header_valid'] is False
        assert t['conservative_combined_peak_bytes'] is o['conservative_whole_peak_bytes'] is o['final_conservative_whole_peak_bytes'] is None
        assert nt['native_exit_code']==-15 and nt['termination_signals']==[15]
        assert len(stages)==len(qs)+1 and stages[-1]['stage']=='SENT'
        assert r['stages'][-1]['status']=='STARTED' and 'compile_guards' in r['error']['traceback']
        peak=None
    crow=dict(stage_id=cid,case_id=detail['case_id'],seed=detail['seed'],plan=offered,
        result=pin(bodyp) if returned else None,failure=None if returned else pin(bodyp),
        worker_output=pin(bodyp),header=pin(A/'worker-header.json'),terminal=pin(A/'terminal.json'),observer=pin(O/'observer.json'),
        consumed=pin(A/'CONSUMED.json'),grant=gpin,owner=pin(A/'owned-child.json'),
        resource_admitted=resource,scientific_qualified=returned,stage_complete=returned,admitted=returned,
        admission_emitted=False,resource_scope='Eligibility classification only; Root owns actual admission/seal.',
        worker_status=r['status'],worker_error=r['error'],method_order=detail['method_order'],
        observer_elapsed_ledger_sample=o['elapsed_seconds'],final_observer_gate_seconds=o['final_observer_gate_seconds'],
        whole_peak_bytes=peak,physical_actual_bytes=physical,complete_file_census=census,
        native_started=r['native_requests_started'],native_complete=len(qs),native_status_counts=dict(qcounts),
        uncompleted_native_stage=None if returned else stages[-1],tool_transcription_row=toolrow,
        arms=[])
    aggregate['jobs']+=1;aggregate['Native_starts']+=r['native_requests_started'];aggregate['Native_complete']+=len(qs)
    if not returned:
        assert cid in ('eval-eval-quantified-02-seed0','eval-eval-quantified-02-seed1')
        aggregate['failed_jobs']+=1;aggregate['unavailable_method_slots']+=4
        for method in detail['method_order']:
            crow['arms'].append(dict(id=method,status='UNAVAILABLE_WHOLE_JOB_WORK_FAILURE',search_returned=False,
                proof_accepted=None,resource_admitted=False,scientific_qualified=False))
        case_rows.append(crow);continue

    aggregate['qualified_jobs']+=1
    s=r['scientific_result'];assert s['status']=='EVALUATION_FOUR_METHOD_RECORD'
    assert s['stage']=='evaluate' and s['stage_id']==cid and s['evaluation_seed']==detail['seed']
    assert s['stage_complete'] is s['job_record_complete'] is s['all_four_searched'] is True
    assert s['resource_admitted'] is False  # internal placeholder, not whole resource authority
    assert s['inputs']==evaldoc and s['limits']==p['experiment_limits'] and s['native_records']==qs
    assert s['libraries']==frozen_libraries
    reuse=s['acquisition_check'];assert reuse['complete'] is reuse['qualified'] is True
    assert reuse['donors']==2 and reuse['certificates']==5 and reuse['pairing']==acq['pairing']
    assert {x['query'] for x in reuse['Native_evidence']}==set(expected_acq_native)
    for ev in reuse['Native_evidence']:
        old=expected_acq_native[ev['query']]
        assert ev['request_sha256']==old['request_sha256'] and ev['result_sha256']==digest(old['result'])
    assert s['controls']['corpus'] is s['controls']['reference_setup_calibration'] is None
    control_summary=[]
    for name,count in [('numeric',23),('word',48),('graph',22),('encoding',40),('principal',53)]:
        controls=s['controls'][name]
        assert controls['complete'] is True and len(controls['controls'])==count
        assert len({v['id'] for v in controls['controls']})==count
        assert all(v['status']=='PASSED' for v in controls['controls'])
        control_summary.append(dict(name=name,count=count,saved_sha256=digest(controls)))
    assert sum(v['count'] for v in control_summary)==186
    assert s['controls']['inherited']['status']=='complete'
    assert s['controls']['inherited']['callback_identity_propagated'] is True
    aggregate['finite_control_rows']+=186
    crow['controls']=control_summary
    cost=s['cumulative_costs']
    assert cost['stage_ids']==['acquire-0'] and cost['receipts']==[acqseal]
    assert cost['whole_seconds']==acqseal['whole_seconds'] and cost['maximum_prior_whole_peak_bytes']==acqseal['whole_peak_bytes']
    assert cost['current_whole_seconds'] is None and cost['current_entry_seconds']==s['seconds']
    assert cost['upstream_plus_current_entry_seconds']==s['seconds']+acqseal['whole_seconds']
    assert len(s['records'])==1
    rec=s['records'][0];spec=rec['spec'];assert spec==specs[detail['case_id']]
    assert rec['diagnostic_ground_registry'] is None
    assert rec['compiler']['status']=='complete'
    assert [a['id'] for a in rec['arms']]==detail['method_order']
    assert len(rec['arms'])==4
    used=set(rec['compiler']['queries'])
    for qid in used:assert qs[qid]['request']['theory']==spec['theory']
    m=rec['model'];words=[json.loads(bytes.fromhex(v)) for v in m['word_dictionary']]
    assert m['arity']==0 and m['word_terminator']==256 and words[0]==spec['target']
    assert len(m['word_dictionary'])==len(set(m['word_dictionary']))
    placements={tuple(v['key']):v for v in m['placements']};assert len(placements)==len(m['placements'])
    marks_by_key={key:{tuple(pt):val for pt,val in v['marks']} for key,v in placements.items()}
    command_by_key={key:words[marks[(4*key[0]+1,100)]] for key,marks in marks_by_key.items()}
    deps={tuple(v['point']):{tuple(k) for k in v['keys']} for v in m['dependencies']}
    expected_deps={}
    for key,v in placements.items():
        assert v['command_reference']==[key[0],key[2]]
        for pt in {tuple(pt) for pt,_ in v['marks']+v['occupancy']}:expected_deps.setdefault(pt,set()).add(key)
    assert deps==expected_deps
    align={tuple(v['point']):set(tuples(v['keys'])) for v in m['alignments']}
    expected_align={}
    for key,v in placements.items():
        for pt,amount in v['occupancy']:
            if amount:expected_align.setdefault(tuple(pt),set()).add(key)
    assert align==expected_align
    ref=rec['reference_check'];assert ref['complete'] is rec['word_model_check']['complete'] is True
    assert ref['schema']=='aligned-complete-word-reference-v3' and ref['pointwise_identity'] is False
    assert ref['accepted_placements']==len(placements) and ref['distinct_complete_words']==len(words)
    assert ref['internal_conflicts']==len(m['conflicts']) and ref['attempted_placements']==len(placements)+len(m['conflicts'])
    assert ref['dependency_memberships']==sum(map(len,deps.values()))
    assert rec['word_reference_differential']['performed_on_this_model'] is False
    mark=rec['marking'];assert mark['marked_extension_check']['complete'] is mark['marking_certificate_check']['complete'] is True
    certificates=mark['markings']['certificates'];assert mark['marking_certificate_check']['certificates']==len(certificates)
    aux_by_key={};aux_initial={}
    for ci,cert in enumerate(certificates):
        assert cert['id']==ci and len(cert['trial'])==1
        root=tuple(cert['exhausted_root']);allc=cert['all_candidates']
        assert {tuple(v['key']) for v in allc}==align[root]
        aux=cert['auxiliary'];trialkey=tuple(cert['trial'][0])
        assert aux['placement']==list(trialkey) and aux['placement_value']==0 and aux['initial_value']==1
        auxpoint=tuple(aux['point']);assert auxpoint==(-100,ci)
        aux_by_key.setdefault(trialkey,[]).append((auxpoint,0));aux_initial[auxpoint]=1
        for witness in allc:
            key=tuple(witness['key']);w=witness['witness'];point=tuple(w['point'])
            assert w['kind']=='marking' and w['assigned_owner']==list(trialkey)
            assert marks_by_key[key][point]==w['candidate_value']
            assert marks_by_key[trialkey][point]==w['assigned_value']!=w['candidate_value']
    aggregate['marking_certificates']+=len(certificates)
    crow['model']=dict(placements=len(placements),distinct_words=len(words),dependency_memberships=sum(map(len,deps.values())),
        reference_sha256=digest(ref),marking_certificates=len(certificates),marking_packet_sha256=digest(mark['markings']))
    def literal_prefix(selected):
        by_role={(k[0],k[1]):k for k in selected};out=[]
        for row in range(spec['length']):
            if (row,0) not in by_role or (row,1) not in by_role:break
            left=command_by_key[by_role[row,0]];right=command_by_key[by_role[row,1]]
            if left!=right:break
            out.append(left)
        return out
    for arm in rec['arms']:
        mid=arm['id'];search=arm['search'];pc=arm['proof_check'];trace=search['trace']
        assert arm['execution_status']=='SEARCH_RETURNED' and search['root_restored'] is True
        assert arm['certified_markings'] is (mid!='S0')
        assert arm['cluster_ordering'] is search['cluster_ordering'] is (mid in ('PA','PP'))
        assert arm['abstraction_mode']=={'PA':'atom','PP':'principal'}.get(mid)
        ar=dict(id=mid,status=search['status'],search_returned=True,proof_status=pc['status'],
            proof_accepted=pc['native_proof_accepted'],attempts=search['metrics'].get('attempts',0),
            search_seconds=search['seconds'],full_arm_seconds=arm['full_arm_seconds'],
            resource_admitted=True,scientific_qualified=True,trace_sha256=digest(trace),
            domain_audits=0,selector_pools=0,packet_proposals=0)
        aggregate['returned_methods']+=1;methods[mid]['returned']+=1
        proof=search['proof']
        if proof is None:
            assert search['status']=='unknown_search_budget' and pc['status']=='NO_PROOF_CANDIDATE'
            assert pc['native_proof_accepted'] is False and pc['native_record'] is pc['host_check'] is pc['region'] is None
            aggregate['UNKNOWN_methods']+=1;methods[mid]['UNKNOWN']+=1
            ar['proof_sha256']=None
        else:
            assert pc['status']=='HOST_REGION_NATIVE_ACCEPTED' and pc['native_proof_accepted'] is True
            assert pc['host_check']['accepted'] is True and pc['host_check']['rows']==len(proof)
            assert pc['host_check']['target']==proof[-1]['formula']==spec['target']
            q=pc['native_record'];assert q==qs[q['id']] and q['id'] not in used
            used.add(q['id'])
            assert q['purpose']=='fixed_family_evaluation_'+spec['id']+'_'+mid
            assert q['result']['status']=='accepted'
            assert q['request']==dict(protocol='gcts-fol-1',theory=spec['theory'],target=spec['target'],proof=proof,blocks=[])
            # Literal saved selected-region sums and word/command joins only, no State or verifier call.
            selected=tuples(search['placements']);assert len(set(selected))==len(selected)==2*len(proof)
            seenmarks={tuple(pt):v for pt,v in m['initial']['marks']};totals=collections.Counter()
            if mid!='S0':seenmarks.update(aux_initial)
            for key in selected:
                assert key in placements
                for pt,val in placements[key]['marks']+(aux_by_key.get(key,[]) if mid!='S0' else []):
                    pt=tuple(pt);assert pt not in seenmarks or seenmarks[pt]==val
                    seenmarks[pt]=val
                for pt,val in placements[key]['occupancy']:totals[tuple(pt)]+=val
                assert command_by_key[key]==proof[key[0]]
                for source,formula in placements[key]['metadata']['requirements']:
                    assert type(source) is int and 0<=source<key[0] and proof[source]['formula']==formula
            roots={tuple(pt) for pt in m['initial']['allowed_points']}
            assert set(totals)==roots and set(totals.values())=={12}
            assert pc['region']==dict(complete=True,decoded_rows=len(proof),mark_points=len(seenmarks),
                required_points=len(roots),selected_placements=len(selected))
            aggregate['accepted_proof_occurrences']+=1;methods[mid]['accepted']+=1
            ar.update(proof_sha256=digest(proof),proof_rows=len(proof),native_query=q['id'],native_request_sha256=q['request_sha256'],region=pc['region'])
        if mid=='S0':
            assert all(e.get('proposals',[])==[] for e in trace if e['event']=='decision')
        else:
            events=collections.Counter(e['event'] for e in trace)
            assert events['place']==ar['attempts']
            aggregate['point_placements']+=events['place'];methods[mid]['point_placements']+=events['place']
            audits=search['domain_audits'];assert len(audits)==2 and all(x['complete'] is True for x in audits)
            decisions=[e for e in trace if e['event']=='decision']
            for audit,de in zip(audits,decisions):
                assert audit['decision']==[de['kind'],de['point'],de['original_alternatives']]
            ar['domain_audits']=len(audits);aggregate['point_domain_audits']+=len(audits)
            selected=[];selected_actions=[];order_count=0
            for ti,e in enumerate(trace):
                event=e['event']
                if event=='place':
                    key=tuple(e['key']);assert key in placements and key not in selected
                    de=trace[e['decision']];assert de['event']=='decision' and list(key) in de['original_alternatives']
                    selected.append(key)
                elif event=='return':
                    assert selected and selected[-1]==tuple(e['key']);selected.pop()
                elif event=='order':
                    de=trace[e['decision']];original=de['original_alternatives'];preferred=e['preferred']
                    assert collections.Counter(tuples(e['alternatives']))==collections.Counter(tuples(original))
                    if de['kind']=='forced':assert e['alternatives']==original
                    else:
                        prefix=literal_prefix(selected);tiers=[[],[],[],[]]
                        for key in original:
                            repeated=any(command_by_key[tuple(key)]['formula']==x['formula'] for x in prefix)
                            tiers[(2 if repeated else 0)+(0 if key in preferred else 1)].append(key)
                        assert e['alternatives']==[v for tier in tiers for v in tier]
                    order_count+=1
                elif event=='selector_pool':
                    assert mid in ('PA','PP')
                    de=trace[e['decision']];assert de['kind']=='branch'
                    pool=e['pool'];action=e['action'];prefix=literal_prefix(selected)
                    assert pool['complete'] is True and pool['coverage']=='deterministic bounded prefix, not exhaustive all bindings'
                    assert pool['termination'] in ('declared_occurrences_exhausted','work_prefix','proposal_prefix')
                    assert pool['validation_checks']<=p['experiment_limits']['cluster_binding_work']
                    assert len(pool['packets'])<=p['experiment_limits']['cluster_proposals']
                    sources=[dict(kind='prefix',row=i,formula=cmd['formula']) for i,cmd in enumerate(prefix)]
                    sources += [dict(kind='axiom',name=n,formula=f) for n,f in sorted(spec['theory']['axioms'].items())]
                    assert pool['source_occurrences']==sources
                    assert action['mode']=='fixed' and action['weights']==[0.0]*9 and action['draw'] is None and action['choice']==0
                    assert action['scores']==[0.0]*len(action['features'])
                    assert len(action['features'])==len(pool['packets'])+1 and action['features'][-1]==[0.0]*8+[1.0]
                    assert action['probabilities']==[1.0]+[0.0]*(len(action['features'])-1)
                    assert e['action_index']==len(selected_actions);selected_actions.append(action)
                    mode=arm['abstraction_mode'];ids={f['id'] for f in frozen_libraries[mode]}
                    for pi,packet in enumerate(pool['packets']):
                        assert packet['pool_ordinal']==pi and packet['family'] in ids
                        assert packet['prefix_rows']==len(prefix)
                        assert packet['checked_primitive_proof']==prefix+packet['commands']
                        assert packet['result_formula']==packet['checked_primitive_proof'][-1]['formula']
                        assert packet['host_check']['accepted'] is True
                        assert packet['host_check']['target']==packet['result_formula']
                        assert packet['host_check']['rows']==len(packet['checked_primitive_proof'])
                        assert all(source in sources for source in packet['source_binding'])
                        members=tuples(packet['members']);assert len(members)==2*len(packet['commands'])
                        assert packet['pending']==[list(key) for key in members if key not in selected]
                        assert any(key in tuples(de['original_alternatives']) for key in tuples(packet['pending']))
                        for offset,cmd in enumerate(packet['commands']):
                            for key in members[2*offset:2*offset+2]:
                                assert key[0]==len(prefix)+offset and key in placements and command_by_key[key]==cmd
                        pool_rows.append(dict(stage_id=cid,method=mid,trace_index=ti,packet_ordinal=pi,family=packet['family'],
                            source_binding_sha256=digest(packet['source_binding']),prefix_rows=len(prefix),
                            commands_sha256=digest(packet['commands']),members=packet['members'],host_accepted=True,
                            status='CONTEXT_CHECKED_ORDERING_PACKET_NOT_TARGET_PROOF'))
                    ar['selector_pools']+=1;ar['packet_proposals']+=len(pool['packets'])
            if mid in ('PA','PP'):
                assert selected_actions==search['selector_decisions']
                assert search['metrics'].get('cluster_proposals',0)==ar['packet_proposals']
                assert search['validation_checks']>=sum(e['pool']['validation_checks'] for e in trace if e['event']=='selector_pool')
            else:assert ar['selector_pools']==0
            ar['recorded_complete_orders']=order_count
        crow['arms'].append(ar);all_arm_rows.append(dict(stage_id=cid,case_id=spec['id'],seed=detail['seed'],**ar))
    assert used==set(range(len(qs)))
    exported=s['export'];assert exported['acquisition_export_sha256']==acqreview['export_sha256']
    assert exported['libraries_sha256']==library_digest and exported['stage_id']==cid
    assert exported['outcomes']==[dict(id=a['id'],search_status=a['search']['status'],proof_status=a['proof_check']['status']) for a in rec['arms']]
    crow['export_sha256']=digest(exported);crow['cumulative_costs']=cost
    case_rows.append(crow)

assert aggregate['jobs']==16 and aggregate['qualified_jobs']==14 and aggregate['failed_jobs']==2
assert aggregate['returned_methods']==56 and aggregate['unavailable_method_slots']==8
assert aggregate['accepted_proof_occurrences']==50 and aggregate['UNKNOWN_methods']==6
assert aggregate['point_placements']==1217 and aggregate['point_domain_audits']==84
assert aggregate['finite_control_rows']==2604 and len(all_files)==222
full_elapsed=sum(row['observer_elapsed_ledger_sample'] for row in case_rows)
comparisons=[]
for cid in specs:
    rows=[row for row in case_rows if row['case_id']==cid]
    comparisons.append(dict(case_id=cid,qualified_orders=sum(row['admitted'] for row in rows),
        method_results=[dict(seed=row['seed'],outcomes=[dict(id=a['id'],status=a['status'],proof_accepted=a.get('proof_accepted'),attempts=a.get('attempts'),search_seconds=a.get('search_seconds'),full_arm_seconds=a.get('full_arm_seconds')) for a in row['arms']]) for row in rows]))
review=dict(schema='D17-independent-fixed-family-final16-passive-actual-review-v1',
    reviewer_identity='/root/recovered_batch_review',review_passed=True,
    scope='Truthful independent passive classification of all sixteen exact once attempts and all sixty-four planned method slots. Per-case admitted flags are eligibility recommendations for Root, not emitted admissions or seals.',
    check_count=6,failed_checks=[],
    checks=[dict(check='Exact current Source, acquisition and preflight chain',passed=True),
        dict(check='Sixteen grants, consumed records, owned groups, complete census and resource classification',passed=True),
        dict(check='Every completed current Native request, stage digest and cleanup; unresolved SENT stages kept failed',passed=True),
        dict(check='Complete production reference, finite controls, certified m witnesses and saved domain audits',passed=True),
        dict(check='Fresh final Host/full-region/Native proof gates and literal word/command/guard joins',passed=True),
        dict(check='Immutable paired library, fixed selectors, complete primitive permutations and packet context joins',passed=True)],
    index=pin(indexp),preflight=pin(preflightp),acquisition_review=pin(acqreviewp),
    acquisition_seal=pin(R/'seals/acquire-0-v1.json'),acquisition_admission=pin(R/'admission/acquire-0-v1.json'),
    grants=pin(grantindexp),barrier=pin(barrierp),tool_transcription=pin(toolp),
    cases=case_rows,aggregate=dict(aggregate),native_status_counts=dict(native_status),
    per_method={k:dict(v) for k,v in methods.items()},comparisons=comparisons,
    Native_complete_request_joins=native_rows,point_packet_literal_joins=pool_rows,
    common_library_sha256=library_digest,exact_input_pins=sorted(cache.values(),key=lambda v:v['path']),
    whole_study_complete=False,whole_study_resource_admitted=False,whole_study_scientific_qualified=False,
    admission_or_seal_emitted=False,grants_issued=0,actual_execution_authorized=False,
    scientific_calls=0,scientific_imports=0,helper_calls=0,scientific_replay=False,partial_files_parsed=False,
    costs=dict(evaluation_observer_elapsed_samples_sum=full_elapsed,acquisition_observer_sample=acqseal['whole_seconds'],
        deduplicated_study_observer_samples_sum=full_elapsed+acqseal['whole_seconds'],
        scope='Sums of declared observer ledger samples, not final tool-output end-to-end wallclock. Include failed attempts; do not duplicate shared acquisition as sixteen real acquisitions.'),
    permitted_conclusions=[
        'Fourteen complete resource-qualified evaluation records contain fifty saved accepted proof occurrences and six bounded point-search UNKNOWNs. Eight slots are unavailable because both quantified-02 jobs failed the whole work gate during compiler requests.',
        'All fourteen S0 recipient searches returned saved accepted proofs. No case here establishes that PA or PP proves a target unavailable to S0. The authored opaque-equality contrast records a shorter placement path for PP than P0/PA; deterministic mirrored development runs are not statistical superiority evidence.',
        'PA and PP used the same three paired inventory units and ordinary primitive candidates. Production/independent acquisition typing and current context Host/trial gates justify only validated ordering proposals, not registered Native rules. Pool completion is a bounded declared prefix, not exhaustive semantic coverage.',
        'No policy was trained or updated, and numeric zero-weight controls are not RL learning. No GCTS/RL/SOTA advantage, new theorem, causal phase attribution, whole-VM/G0/G1 rescue or resource-fit extrapolation follows.'
    ],
    gaps=[
        'The full planned sixty-four-slot cohort is incomplete. Failed complete packets and unfinished SENT Native stages remain diagnostic only; no setup prefix or exported partial is adopted.',
        'This audit joins complete saved bytes, references and recorded checker outcomes. It does not rerun Host, Native, Graph, State, unification, reduction, proposal trials, controls, or helpers and does not constitute an independent mathematical replay.',
        'Saved full-domain decisions, root-restored flags and finite isolation controls are joined to reviewed Source; passive data does not establish a new all-input scheduler or implementation theorem.',
        'The common v3 verifier setup and omitted unused registry distinguish this study from earlier studies. Cross-study end-to-end timing changes cannot be attributed solely to abstraction.',
        'Root tool observations and serial barrier are explicitly labeled transcriptions/owned metadata. On-disk custody is separate, and no real-time OS or hostile-sandbox guarantee is claimed.'
    ],reviewer_author_source=pin(Path(__file__)))
out=C/'typed-fixed-family-final16-evaluation-actual-review-v1.json'
assert not out.exists()
out.write_text(json.dumps(review,sort_keys=True,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(dict(output=pin(out),review_passed=True,aggregate=dict(aggregate),native_status=dict(native_status))))
