"""C-owned passive complete JSON/raw-byte audit; never import offered modules."""
import collections
import hashlib
import json
from pathlib import Path

D = Path(__file__).resolve().parents[1]
C = D / 'review-C'
R = D / 'root'
A = D / 'actual/acquire-0'
O = D / 'actual/acquire-0.observer'

def pin(p):
    p = Path(p).resolve()
    b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())

def load(p):
    p = Path(p)
    assert '.partial' not in p.name
    return json.loads(p.read_text())

def digest(v):
    return hashlib.sha256(json.dumps(v, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()).hexdigest()

def pinned(v):
    assert pin(v['path']) == v, v['path']

checks = []
def ok(name, evidence):
    checks.append(dict(check=name, passed=True, evidence=evidence))

planp = R / 'plans/acquire-0-v2.json'
plan = load(planp)
rp = A / 'result.json'
r = load(rp)
s = r['scientific_result']
jp = R / 'admission/acquire-0-passive-join-v1.json'
j = load(jp)
header = load(A / 'worker-header.json')
terminal = load(A / 'terminal.json')
observer = load(O / 'observer.json')
owner = load(A / 'owned-child.json')
consumed = load(A / 'CONSUMED.json')
grantp = R / 'grants/acquire-0-v1.json'
grant = load(grantp)
barrierp = R / 'serial-barrier-acquire-0-v1.json'
barrier = load(barrierp)

assert pin(planp)['sha256'] == '660fbc37bb99f856477beabddba427ec4f61f9df088f794e39e1c0f71957f36d'
assert pin(rp)['sha256'] == '19deae831df78548e957702a8802cb769da43bdf9720840bc10bb596324ca3f9'
assert pin(jp)['sha256'] == 'ea00b102af9a6696b8a14a9997feada88f26b85fdf55e1b22343d9f644b3ba81'
assert len(plan['files']) == 90
assert len({v['path'] for v in plan['files']}) == 90
for v in plan['files']:
    pinned(v)
prior = [C / 'typed-fixed-principal-family-search-Source-review-v2.json',
         C / 'typed-principal-search-custodian-Source-review-v1.json',
         C / 'typed-principal-search-corpus-Source-review-v1.json',
         C / 'typed-principal-family-search-whole-prospective-Source-review-v2.json']
for p in prior:
    assert load(p)['review_passed'] is True
assert plan['stage'] == 'acquire' and plan['case_id'] == 'acquire-0'
assert plan['required_upstream_ids'] == plan['upstream_receipts'] == []
assert plan['template_pending_fresh_acquisition'] is False
assert all('evaluation-inputs' not in row['path'] and 'mechanism-inputs' not in row['path'] for row in plan['files'])
assert grant['authorized'] is True and grant['review_passed'] is True and grant['uses'] == 1
assert grant['C_review'] == pin(prior[-1]) == barrier['review']
assert grant['serial_barrier'] == pin(barrierp)
assert barrier['team_tools_stopped'] == ['B', 'C', 'L']
assert barrier['study_worker_or_preview_services_running'] is False
assert barrier['browser_QA_running'] is False
assert consumed['uses'] == 1 and consumed['case_id'] == plan['case_id']
assert consumed['grant_sha256'] == pin(grantp)['sha256']
assert consumed['plan_sha256'] == grant['plan_sha256'] == owner['plan_sha256'] == pin(planp)['sha256']
assert grant['runner_sha256'] == pin(plan['runner_path'])['sha256']
ok('Exact frozen Source, prior reviews, cold phase closure and once grant', dict(
    source_rows=90, prior_reviews=[pin(p) for p in prior], grant=pin(grantp), consumed=pin(A/'CONSUMED.json'),
    barrier=pin(barrierp), scope='All offered bodies rehashed. Fresh acquisition only; no historical library, evaluation input or template execution. Barrier is Root-owned metadata, not an independently measured idle OS.'))

actual_files = sorted([p for root in (A, O) for p in root.rglob('*') if p.is_file()])
partials = [pin(p) for p in actual_files if '.partial' in p.name]
assert partials == []
actual_pins = [pin(p) for p in actual_files]
assert len(actual_pins) == 14
assert actual_pins == j['complete_file_census']
for v in j['artifacts'].values(): pinned(v)
assert j['plan'] == pin(planp) and j['result'] == pin(rp)
assert j['header'] == pin(A/'worker-header.json') and j['terminal'] == pin(A/'terminal.json')
assert j['observer'] == pin(O/'observer.json')
assert (R/'admission/acquire-0-passive-join-stdout-v1.bin').read_bytes() == jp.read_bytes()
assert (R/'admission/acquire-0-passive-join-stderr-v1.bin').read_bytes() == b''
assert r['status'] == header['status'] == 'COMPLETE' and r['error'] is None
assert r['source_unchanged'] is header['source_unchanged'] is terminal['sources_unchanged'] is True
assert r['first_Root_fault'] is header['first_Root_fault'] is False
assert r['callbacks'] == header['callbacks'] < plan['limits']['root_callbacks']
assert terminal['process_exit_code'] == observer['parent_exit_code'] == 0
assert terminal['errors'] == observer['errors'] == []
assert terminal['reason'] is observer['reason'] is None
assert terminal['header_valid'] is terminal['threads_terminal'] is terminal['final_custody_gate_passed'] is True
assert terminal['header'] == header and header['result'] == terminal['result'] == pin(rp)
assert observer['owned_child'] == owner
assert owner['child_pid'] == owner['child_pgid'] and owner['parent_pid'] != owner['child_pid']
for obj, root in [(terminal, A), (observer, O)]:
    for name in ('stdout','stderr'):
        log = obj['logs'][name]
        assert log['eof'] is True and log['overflow'] is False
        assert log['stored'] == log['bytes'] == pin(root/(name+'.bin'))['bytes']
        assert log['bytes'] <= plan['limits']['log_bytes']
for stage in r['stages']:
    assert stage['status'] == 'COMPLETED'
    assert 0 <= stage['began'] <= stage['began']+stage['seconds'] < plan['limits']['work_seconds']
assert r['elapsed_seconds'] < header['seconds'] < plan['limits']['positive_seconds']
assert terminal['final_custody_gate_seconds'] < plan['limits']['custody_seconds']
assert observer['final_observer_gate_seconds'] < plan['limits']['observer_fallback_seconds']
assert observer['resource_candidate_accepted'] is observer['resource_candidate_before_receipt'] is True
assert observer['fallback_trigger_seconds'] is None
parent_peak = terminal['parent_usage']['ru_maxrss'] + max(terminal['child_usage']['ru_maxrss'], header['python_peak_after_output_bytes']) + header['native_peak_bytes'] + terminal['memory_terminal_output_reserve_bytes']
assert parent_peak == terminal['conservative_combined_peak_bytes'] == 272973824
whole_peak = parent_peak + max(observer['observer_peak_before_receipt_bytes'],observer['final_observer_peak_bytes']) + observer['final_output_memory_reserve_bytes']
assert whole_peak == observer['conservative_whole_peak_bytes'] == observer['final_conservative_whole_peak_bytes'] == j['whole_peak_bytes'] == 303874048
assert whole_peak < plan['limits']['memory_bytes']
physical = sum(v['bytes'] for v in actual_pins)
assert physical == j['physical_bytes'] == 9436111
assert physical + plan['limits']['reserved_outer_bytes'] < plan['limits']['physical_bytes']
assert pin(rp)['bytes'] < plan['limits']['result_bytes']
transcriptionp = R / 'acquisition-tool-terminal-transcription-v1.json'
transcription = load(transcriptionp)
ok('Complete saved process, output, clock and resource custody', dict(
    actual_files=actual_pins, complete_files=14, partial_raw_metadata=[], callbacks=r['callbacks'],
    parent_peak_bytes=parent_peak, whole_peak_bytes=whole_peak, physical_actual_bytes=physical,
    charged_physical_with_outer_reserve=physical+plan['limits']['reserved_outer_bytes'],
    elapsed_observer_ledger_sample=observer['elapsed_seconds'],
    later_final_observer_gate_seconds=observer['final_observer_gate_seconds'],
    worker_elapsed=r['elapsed_seconds'], worker_header_seconds=header['seconds'],
    Root_tool_transcription=pin(transcriptionp),
    tool_scope='Root-labeled session 23986 exit0 transcription is separate from the on-disk observer and is not an independent end-to-end clock. No replay or live PID probe.'))

queries = r['native_queries']
nt = r['native_transport']
stages = nt['request_stages']
assert len(queries) == len(stages) == nt['complete_records'] == r['native_requests_started'] == len(s['native_records']) == 19
assert s['native_records'] == queries
assert len(queries) <= plan['experiment_limits']['compile_queries'] == 512
assert nt['closed'] is nt['all_reaped'] is nt['same_owned_process_group'] is True
assert nt['native_exit_code'] == nt['wait4_status'] == 0
assert nt['cleanup_errors'] == nt['termination_signals'] == []
assert nt['stderr_complete'] is nt['stdout_eof'] is True
assert nt['stderr_bytes'] == nt['stdout_pending_bytes'] == 0
assert nt['native_pgid'] == nt['parent_pgid'] == owner['child_pgid']
assert nt['parent_pid'] == owner['child_pid']
assert header['native_closed_and_reaped'] is True
native_rows = []
for i,(q,st) in enumerate(zip(queries,stages)):
    assert q['id'] == st['ordinal'] == st['record_id'] == i
    assert st['stage'] == 'COMPLETED'
    assert q['query_target'] == 'fixed_assertion'
    assert q['request']['protocol'] == 'gcts-fol-1' and q['request']['blocks'] == []
    assert q['request_sha256'] == st['request_sha256'] == digest(q['request'])
    assert q['purpose'] == st['purpose']
    assert q['input_sha256'] == st['input_sha256'] and q['output_sha256'] == st['output_sha256']
    assert st['limit'] == plan['experiment_limits']['native_steps'] == 1000000000
    assert q['result']['micro_steps'] <= st['limit']
    assert q['result']['status'] in ('accepted','rejected')
    native_rows.append(dict(id=i,purpose=q['purpose'],status=q['result']['status'],request_sha256=q['request_sha256'],micro_steps=q['result']['micro_steps']))
assert pin(A/'native/input.bin')['sha256'] == queries[-1]['input_sha256']
assert pin(A/'native/output.bin')['sha256'] == queries[-1]['output_sha256']
assert pin(A/'native/boundary-oracle')['sha256'] == pin(plan['native']['executable_path'])['sha256']
assert pin(A/'native/code.bin')['sha256'] == '97f0b600cffd83552c4e0f0c4fb1f5d26cfdb76e3e74b267bbaebeddc836e7ed'
assert collections.Counter(q['result']['status'] for q in queries) == {'accepted':9,'rejected':10}
assert j['Native']['status_counts'] == {'accepted':9,'rejected':10}
ok('Every current owned Native request and terminal transport join', dict(
    rows=native_rows, accepted=9,rejected=10,unknown=0,
    scope='Exact request JSON, digests, stage order, fixed program raw bytes and saved result joins. No Native program/tape decode or logical replay. Ten compiler candidate rejections are retained; not all requests accepted.'))

document = load(plan['input_path'])
assert s['inputs'] == document
assert s['format_check']['complete'] is True
assert s['format_check']['statement_ids'] == [d['id'] for d in document['donors']]
assert s['stage'] == plan['stage'] == 'acquire' and s['stage_id'] == plan['case_id']
assert s['status'] == 'PAIRED_ACQUISITION_COMPLETE'
assert s['job_record_complete'] is s['stage_complete'] is s['qualified'] is s['all_profile_fragments_accepted'] is True
assert s['resource_admitted'] is False  # entry placeholder; outer resource authority is independent
assert s['limits'] == plan['experiment_limits']
assert len(s['records']) == len(s['donor_outcomes']) == len(document['donors']) == 2
owned = set()
donor_rows = []
expected_certs = []
candidate_rows = []
regions = []
for index,(spec,d,outcome) in enumerate(zip(document['donors'],s['records'],s['donor_outcomes'])):
    assert d['spec'] == spec
    proof = d['search']['proof']
    assert len(proof) == spec['length'] and proof[-1]['formula'] == spec['target']
    assert d['search']['status'] == 'symbolic_proof_candidate' and d['search']['root_restored'] is True
    assert d['search']['cluster_ordering'] is False
    decisions = [e for e in d['search']['trace'] if e['event']=='decision']
    extensions = [e for e in d['search']['trace'] if e['event']=='extend']
    assert len(decisions) == len(extensions) == d['search']['metrics']['attempts'] == len(proof)
    assert d['search']['metrics']['nodes'] == len(proof)+1
    for e in decisions:
        assert e['ordered_candidates'] == e['original_candidates'] and e['proposals'] == []
    for e in extensions:
        de = d['search']['trace'][e['decision']]
        assert de['event'] == 'decision' and [e['skeleton'],e['variant']] in de['ordered_candidates']
    compiler = d['compiler']
    assert compiler['status'] == 'complete'
    for qid in compiler['queries']:
        assert qid not in owned
        owned.add(qid)
        assert queries[qid]['request']['theory'] == spec['theory']
    assert queries[compiler['theory_query']]['purpose']=='first_order_theory_admission'
    assert queries[compiler['theory_query']]['result']['status']=='accepted'
    whole = d['proof_check']
    q = whole['native_record']
    assert q == queries[q['id']] and q['id'] not in owned
    owned.add(q['id'])
    assert whole['status']=='HOST_REGION_NATIVE_ACCEPTED' and whole['native_proof_accepted'] is True
    assert whole['host_check']['accepted'] is True and whole['host_check']['rows']==len(proof)
    assert whole['host_check']['target']==spec['target']
    assert q['request']==dict(blocks=[],proof=proof,protocol='gcts-fol-1',target=spec['target'],theory=spec['theory'])
    assert q['result']['status']=='accepted' and whole['native_limit']==1000000000

    # Literal complete saved point/word incidence and selected-region association only.
    # No model, State, Graph, verifier or scientific routine is called.
    m=d['model']; dictionary=m['word_dictionary']
    words=[json.loads(bytes.fromhex(v)) for v in dictionary]
    assert len(dictionary)==len(set(dictionary)) and m['word_terminator']==256 and m['arity']==0
    assert words[0] == spec['target']
    assert m['initial']['marks']==[[[4*(len(proof)-1),100],0]]
    placements={tuple(p['key']):p for p in m['placements']}
    assert len(placements)==len(m['placements'])
    dep={tuple(v['point']):{tuple(k) for k in v['keys']} for v in m['dependencies']}
    expected_dep={}
    for key,p in placements.items():
        assert p['metadata']['slot']==key[0]
        assert p['command_reference']==[key[0],key[2]]
        for pt,val in p['marks']:
            assert type(val) is int and type(pt[0]) is type(pt[1]) is int
            if pt[1]==100: assert 0<=val<len(words)
            elif pt[1]==90: assert val==0
            else: assert False
        for pt in {tuple(pt) for pt,_ in p['marks']+p['occupancy']}:
            expected_dep.setdefault(pt,set()).add(key)
    assert dep==expected_dep
    for alignment in m['alignments']:
        pt=tuple(alignment['point'])
        assert {tuple(k) for k in alignment['keys']}=={key for key,p in placements.items() if any(tuple(q)==pt and v for q,v in p['occupancy'])}
    assert len(d['search']['placements'])==2*len(proof)
    marks={tuple(p):v for p,v in m['initial']['marks']}
    totals=collections.Counter()
    for rawkey in d['search']['placements']:
        key=tuple(rawkey); p=placements[key]
        for point,value in p['marks']:
            point=tuple(point)
            assert point not in marks or marks[point]==value
            marks[point]=value
        for point,value in p['occupancy']: totals[tuple(point)]+=value
        row=key[0]
        local={tuple(pt):v for pt,v in p['marks']}
        assert words[local[(4*row,100)]]==proof[row]['formula']
        assert words[local[(4*row+1,100)]]==proof[row]
        for source,formula in p['metadata']['requirements']:
            assert type(source) is int and 0<=source<row
            assert formula==proof[source]['formula']
    required={tuple(pt) for pt in m['initial']['allowed_points']}
    assert set(totals)==required and set(totals.values())=={12}
    region=dict(complete=True,decoded_rows=len(proof),mark_points=len(marks),required_points=len(required),selected_placements=2*len(proof))
    assert region==whole['region']
    ref=d['reference_check']
    assert ref['complete'] is d['word_model_check']['complete'] is True
    assert ref['schema']=='aligned-complete-word-reference-v3' and ref['pointwise_identity'] is False
    assert ref['accepted_placements']==len(placements)
    assert ref['distinct_complete_words']==len(dictionary)
    assert ref['dependency_points']==len(dep)
    assert ref['dependency_memberships']==sum(len(v) for v in dep.values())
    assert ref['internal_conflicts']==len(m['conflicts'])
    assert ref['attempted_placements']==len(placements)+len(m['conflicts'])
    assert d['word_reference_differential']['performed_on_this_model'] is False
    assert d['word_reference_differential']['complete'] is None
    regions.append(dict(donor=spec['id'],region=region,placements_sha256=digest(m['placements']),
        all_dependency_memberships=sum(len(v) for v in dep.values()),whole_query=q['id'],saved_reference=digest(ref)))

    # Join remapped ancestor candidates to the literal ordered donor rows.
    # This is address/occurrence reconstruction, not execution of a proof checker.
    assert len(d['candidates'])==len(proof)+1
    profile_count=0
    for ordinal,c in enumerate(d['candidates']):
        if ordinal==0:
            ancestry=list(range(len(proof))); fragment=proof
            assert c['kind']=='full' and c['source_row'] is None
        else:
            row=ordinal-1
            closure={row}; pending=[row]
            while pending:
                at=pending.pop()
                cmd=proof[at]
                if cmd['rule']=='mp':
                    for refname in ('antecedent','implication'):
                        refrow=cmd[refname]
                        assert type(refrow) is int and 0<=refrow<at
                        if refrow not in closure:
                            closure.add(refrow);pending.append(refrow)
            ancestry=sorted(closure); remap={old:new for new,old in enumerate(ancestry)}
            fragment=[]
            for old in ancestry:
                cmd=dict(proof[old])
                if cmd['rule']=='mp':
                    for refname in ('antecedent','implication'): cmd[refname]=remap[cmd[refname]]
                fragment.append(cmd)
            assert c['kind']=='ancestor_closure' and c['source_row']==row
        assert c['ordinal']==ordinal and c['ancestry']==ancestry and c['proof']==fragment
        assert c['target']==fragment[-1]['formula']
        profile=all(v['rule'] in ('axiom','mp') for v in fragment) and any(v['rule']=='mp' for v in fragment)
        assert c['profile_eligible'] is profile
        cr=dict(donor=spec['id'],ordinal=ordinal,kind=c['kind'],source_row=c['source_row'],ancestry=ancestry,
                proof_sha256=digest(fragment),profile_eligible=profile,native_resolution=c['native_resolution'])
        if not profile:
            assert c['eligible'] is False and c['native_record'] is c['family'] is c['host_check'] is None
            assert c['native_resolution']=='OUTSIDE_DECLARED_PROFILE'
        else:
            profile_count+=1
            q=c['native_record']
            assert q==queries[q['id']] and q['id'] not in owned
            owned.add(q['id'])
            assert q['request']==dict(blocks=[],proof=fragment,protocol='gcts-fol-1',target=c['target'],theory=spec['theory'])
            assert q['result']['status']==c['native_resolution']=='accepted' and c['eligible'] is True
            assert c['host_check']['accepted'] is True and c['host_check']['rows']==len(fragment)
            provenance=dict(training_id=spec['id'],candidate_ordinal=ordinal,kind=c['kind'],source_row=c['source_row'],
                            ancestry=ancestry,native_query=q['id'],request_digest=digest(q['request']))
            for mode,f in c['families'].items():
                assert f['provenance']==provenance and f['dependencies']==[]
            f=c['families']['principal']; pc=c['principal_check']; cert=f['certificate']; typing=cert['typing']; independent=pc['independent']
            assert c['family']==f and pc['complete'] is independent['complete'] is True
            assert cert['provenance']==provenance and cert['request_sha256']==q['request_sha256']
            assert cert['concrete_row_formulas']==[v['formula'] for v in fragment]
            ports=[];aliases=[];graph=[]
            for at,cmd in enumerate(fragment):
                if cmd['rule']=='axiom':
                    assert spec['theory']['axioms'][cmd['name']]==cmd['formula']
                    if cmd['formula'] not in ports: ports.append(cmd['formula']);aliases.append([])
                    pindex=ports.index(cmd['formula']);aliases[pindex].append(dict(name=cmd['name'],row=at))
                    graph.append(dict(row=at,kind='port',port=pindex))
                else:
                    graph.append(dict(row=at,kind='mp',antecedent=cmd['antecedent'],implication=cmd['implication']))
            assert cert['concrete_ports']==ports and cert['port_occurrences']==aliases
            assert typing['graph']==graph==independent['graph']
            for field in ('graph','row_formulas','premises','conclusion','port_count','parameters'):
                assert typing[field]==independent[field]
            assert typing['port_count']==len(ports)
            assert f['template']==independent['template']
            assert f['parameters']==independent['parameters']
            assert cert['donor_arguments']==independent['concrete_arguments']
            assert cert['port_occurrences']==independent['port_aliases']
            expected_certs.append(dict(spec=spec,proof=fragment,target=c['target'],provenance=provenance,
                family=f,families=c['families'],principal_check=pc,acquisition_mode='principal',
                native_record=q,native_limit=1000000000,full_donor_proof=proof,full_donor_check=whole,
                fragment_region_scope='No separate fragment region compiled; exact remapped primitive Host/Native certificate. Whole donor has full original region.'))
            cr.update(native_query=q['id'],parameters=f['parameters'],port_count=len(ports),
                principal_structural_id=f['structural_id'],saved_independent_sha256=digest(independent))
        candidate_rows.append(cr)
    expected_resolution=dict(schema='fixed-acquisition-fragment-resolution-v1',complete=True,
        profile_eligible_count=profile_count,native_accepted_count=profile_count,unresolved=[],all_profile_fragments_accepted=True)
    assert d['fragment_resolution']==expected_resolution
    assert outcome==dict(id=spec['id'],status=d['search']['status'],whole_native_accepted=True,
        eligible_fragments=profile_count,record_sha256=digest(d))
    donor_rows.append(dict(id=spec['id'],proof_rows=len(proof),attempts=len(extensions),
        proof_sha256=digest(proof),full_postannotation_record_sha256=digest(d),profiles=profile_count,accepted=profile_count))
assert owned==set(range(19))
assert expected_certs==s['certificates'] and len(expected_certs)==5
ok('Fresh complete donors, literal full-region binding and all remapped fragment profiles',dict(
    donors=donor_rows,selected_regions=regions,candidates=candidate_rows,
    whole_donors=2,whole_proof_rows=8,raw_candidates=10,profile_fragments=5,all_profile_accepted=True,
    scope='Full donor proofs joined to selected commands, guards, dictionary payloads, complete saved incidence and current owned Native requests. All ancestor row references and remaps joined independently. No Host/Native/reduction/miner/MGU execution; fragments have remapped Host/Native evidence and no separately compiled fragment region.'))

certs=s['certificates'];units=s['pairing']['units']
groups={}
for i,cert in enumerate(certs):groups.setdefault(cert['families']['atom']['id'],[]).append(i)
assert list(groups)==[u['paired_unit_id'] for u in units]
assert len(units)==s['pairing']['paired_units']==3
assert s['pairing']['raw_certificates']==5 and s['pairing']['no_principal_coalescence'] is True
for u,(identity,ordinals) in zip(units,groups.items()):
    assert u['members']==[dict(certificate_ordinal=i,provenance=certs[i]['provenance']) for i in ordinals]
    first=certs[ordinals[0]]
    for i in ordinals:
        for mode in ('atom','principal'):
            f=certs[i]['families'][mode];base=first['families'][mode]
            assert f['parameters']==base['parameters'] and f['template']==base['template']
            if mode=='principal':assert f['certificate']['typing']['graph']==base['certificate']['typing']['graph']
    for mode in ('atom','principal'):
        family=first['families'][mode]
        w=s['libraries'][mode][list(groups).index(identity)]
        assert w['structural_family']==family
        assert w['id']==w['paired_unit_id']==identity
        assert w['structural_id']==family['id']==u[mode+'_structural_id']
        assert w['source_certificate_ordinal']==ordinals[0] and w['abstraction_mode']==mode
        for key,value in family.items():
            if key!='id':assert w[key]==value
        assert u['wrapper_checks'][mode]['complete'] is True
assert [f['paired_unit_id'] for f in s['libraries']['atom']]==[f['paired_unit_id'] for f in s['libraries']['principal']]
assert s['pairing']['principal_structures']==len({f['structural_id'] for f in s['libraries']['principal']})==2
export=s['export']
assert export['schema']=='gcts-principal-family-search-stage-export-v2'
assert export['stage']=='acquire' and export['stage_id']=='acquire-0' and export['qualified'] is True
assert export['acquisition_document']==document
assert export['donor_ids']==[d['id'] for d in document['donors']]
assert export['donor_outcomes']==s['donor_outcomes']
assert export['certificates']==certs and export['libraries']==s['libraries'] and export['pairing']==s['pairing']
for d,ev in zip(s['records'],export['donor_evidence']):
    assert ev==dict(spec=d['spec'],search=dict(status=d['search']['status'],proof=d['search']['proof']),
        proof_check=d['proof_check'],candidates=d['candidates'],fragment_resolution=d['fragment_resolution'],full_record_sha256=digest(d))
assert export['native_certificate_identity']['program_sha256']=='877c47879b027b08f02d3923d1e6dd9ccaf9a12e354567109f1aaa640a8fb673'
assert export['native_certificate_identity']['micro_sha256']=='2f9e430b0b7034ed615d81c3e9b3978dc47ba4136686227a9b86df5779b203ac'
assert digest(export)==j['export_sha256']=='2e9fef7dffd9480c57a33f69ac457767ed589c3391d8c4bfef0afaa1d7cd5464'
ok('Production-independent saved typing fields, all paired members, wrappers and complete export',dict(
    paired_units=[dict(id=u['paired_unit_id'],certificate_ordinals=[m['certificate_ordinal'] for m in u['members']],
        principal_structural_id=u['principal_structural_id']) for u in units],
    certificates=5,paired_units_count=3,principal_structures=2,export_sha256=digest(export),
    scope='Full saved production and independently authored typing receipts agree on six fields, template, concrete arguments and aliases for every live eligible request. Manual principal-family Source review retained; this audit does not rerun unification or claim mechanized soundness. Principal structures are not coalesced across atom classes.'))

control_rows=[]
for name,count in [('numeric',23),('word',48),('graph',22),('encoding',40),('principal',53),('corpus',24)]:
    v=s['controls'][name]
    assert v['complete'] is True and len(v['controls'])==count
    assert len({x['id'] for x in v['controls']})==count
    assert all(x['status']=='PASSED' for x in v['controls'])
    control_rows.append(dict(name=name,count=count,ids=[x['id'] for x in v['controls']],saved_sha256=digest(v)))
g=s['controls']['graph']
assert g['status']=='PASSED' and g['fixture_count']==len(g['fixtures'])==10
for control in g['controls']:
    if 'snapshots' in control:
        assert control['fixture'] in g['fixtures']
        for event in control.get('events',[]):
            for snap in event.get('full_reference_equal_nodes',{}).values():assert 0<=snap<len(control['snapshots'])
tiny=s['controls']['inherited']
assert tiny['status']=='complete' and tiny['callback_identity_propagated'] is True
assert tiny['global_dead_forced_generation_controls'] is tiny['incomplete_certificate_rejected'] is True
assert len(tiny['base_solutions'])==len(tiny['marked_solutions'])
assert tiny['marking_verification']['complete'] is tiny['marked_extension_check']['complete'] is True
cal=s['controls']['reference_setup_calibration']
assert cal['complete'] is cal['full_model_value_unchanged'] is True
assert cal['status']=='PASSED' and cal['control_count']==1
assert cal['fixture_kind']=='HAND_AUTHORED_REDUCTION_CONTROL_NOT_ACQUIRED_DONOR'
assert cal['omitted_from_comparison']==['schema','storage_scope']
assert {k:v for k,v in cal['original'].items() if k not in cal['omitted_from_comparison']}=={k:v for k,v in cal['production'].items() if k not in cal['omitted_from_comparison']}
control_rows.append(dict(name='reference_setup_calibration',count=1,saved_sha256=digest(cal)))
assert sum(v['count'] for v in control_rows)==211
assert [v['count'] for v in j['scientific']['controls']]==[v['count'] for v in control_rows]
assert j['scientific']['retained_certificates']==5 and j['scientific']['unresolved_profile']==[]
assert j['admitted'] is j['seal_emitted'] is False and j['independent_actual_review_required'] is True
assert j['candidate_join_passed'] is j['candidate_admission'] is j['scientific_qualified'] is j['resource_admitted'] is True
cost=s['cumulative_costs']
assert len(cost)==8 and cost['stage_ids']==cost['receipts']==[]
assert cost['current_entry_seconds']==cost['upstream_plus_current_entry_seconds']==s['seconds']
assert cost['current_whole_seconds'] is None and cost['whole_seconds']==0.0 and cost['maximum_prior_whole_peak_bytes']==0
assert j['whole_seconds']==observer['elapsed_seconds']==13.17763045799802
ok('Returned finite controls, calibration scope, final cost carrier and passive candidate agreement',dict(
    controls=control_rows,total_finite_control_rows=211,inherited_tiny_diagnostics='separate complete record, not another donor',
    real_production_models=2,real_model_original_v1_differentials=0,tiny_same_model_differentials=1,
    costs=cost,scope='All saved finite controls returned PASSED; no control or algorithm replay. Numeric controls do not mean policy training. The tiny v1/v3 differential is separately labeled and real models each retain the full v3 gate.'))

review=dict(
    schema='D17-independent-complete-acquisition-actual-scientific-custody-review-v1',
    reviewer_identity='/root/recovered_batch_review',review_passed=True,resource_admitted=True,scientific_qualified=True,
    plan=pin(planp),result=pin(rp),passive_join=pin(jp),
    stage='acquire',stage_id='acquire-0',stage_complete=True,
    review_scope='Independent passive complete saved acquisition evidence and exact reviewed Source composition. Qualified for this fresh D17 acquisition only; Root admission/seal remains separate. No evaluation actual or future plan authority.',
    scientific_calls=0,scientific_imports=0,helper_calls=0,scientific_replay=False,partial_files_parsed=False,
    actual_execution_authorized=False,seal_emitted=False,evaluation_execution_authorized=False,
    Source_pins=plan['files'],checks=checks,failed_checks=[],check_count=len(checks),
    aggregate=dict(complete_jobs=1,resource_qualified_jobs=1,donors=2,whole_proof_rows=8,whole_donor_certificates=2,
        raw_candidate_occurrences=10,eligible_fragment_certificates=5,unresolved_profiles=0,paired_library_units=3,
        principal_structures=2,Native_requests=19,Native_accepted=9,Native_rejected=10,Native_unknown=0,
        finite_control_rows=211,recipient_searches=0,trained_policies=0,
        whole_peak_bytes=whole_peak,observer_elapsed_ledger_sample=observer['elapsed_seconds']),
    donor_literal_joins=donor_rows,fragment_literal_joins=candidate_rows,
    export_sha256=digest(export),
    limits_and_interpretation=[
      'Two public authored donor statements were freshly searched conventionally. Accepted saved donor/fragment certificates are not new theorems or recipient-search successes.',
      'The fixed formula-port quotient, inherited atom classes, paired multiplicity and full prefix/library fallback remain those of the reviewed Source. Principal generalization is relative to that declared DAG and quotient.',
      'The actual has no unresolved eligible fragments. Its successful path does not execute the preserved hypothetical UNKNOWN regression; the no-export UNKNOWN branch remains a conditional Source control-flow argument.',
      'No Host, Native, point reduction, unifier, miner, numeric update, control bank or helper was called by C. Saved checker evidence and literal provenance are reviewed, not independently mathematically replayed.',
      'Observer elapsed is the fixed cold-cost sample, not last tool-output wall time. Entry, worker, parent, final observer and Root tool-transcription samples remain distinct.',
      'This review emits no admission or 13-field receipt. Root may seal only through the separately reviewed exact helper/review joins; all 16 evaluation templates still require exact materialization and review.',
      'No RL, ATP superiority, speedup, fit extrapolation, causal memory attribution, full physical VM qualification, G0/G1 rescue or whole-study comparison follows. Old studies and failed sources remain immutable.'
    ],
    reviewer_author_source=pin(Path(__file__)),
)
out=C/'typed-fixed-principal-family-acquisition-actual-review-v1.json'
assert not out.exists()
out.write_text(json.dumps(review,sort_keys=True,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(dict(output=pin(out),checks=len(checks),review_passed=True,resource_admitted=True,scientific_qualified=True)))
