"""Static and complete metadata only. Never call a studied module/helper."""
from pathlib import Path
import ast
import hashlib
import json

C=Path(__file__).resolve().parent
D=C.parent
R=D/'root'
L=D/'diagnostics-L'

def pin(path):
    path=Path(path).resolve();body=path.read_bytes()
    return dict(path=str(path),bytes=len(body),sha256=hashlib.sha256(body).hexdigest())

def load(path):
    path=Path(path);assert '.partial' not in path.name
    return json.loads(path.read_bytes())

def same(a,b):
    return json.dumps(a,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)==json.dumps(b,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)

family_path=R/'plan-family-v2.json'
plan_path=R/'plans/acquire-0-v2.json'
assert pin(family_path)['sha256']=='e1918d701e77d700d4d85792e6283a529ccbae93b49cc969ba0a69c1bd4448ba'
assert pin(plan_path)['sha256']=='660fbc37bb99f856477beabddba427ec4f61f9df088f794e39e1c0f71957f36d'
family=load(family_path);plan=load(plan_path);protocol=load(R/'protocol-v1.json')
helper_handoff_path=L/'passive-acquisition-join-handoff-v3.json'
helper_handoff=load(helper_handoff_path)
assert pin(helper_handoff_path)['sha256']=='9edc2a0f0afabfef25f1e3e40555b86a4968b1ab55c1fcd847a9e9f534ddf848'
assert same(family['helper_handoff'],pin(helper_handoff_path))
assert len(family['common_files'])==89 and len(plan['files'])==90 and len(family['jobs'])==17
assert plan['files'][:-1]==family['common_files']
assert len({r['path'] for r in plan['files']})==90
for row in plan['files']+helper_handoff['files']:
    assert same(pin(row['path']),row)
assert pin(L/'passive_acquisition_join_v3.py')['sha256']=='e1d596e5e9f7ab8a5adbe81a3e6308f0175c2cf46ba033aa6a1eb45a0ed05d34'
assert pin(R/'materialize_plans_v3.py')['sha256']=='2c3f233671d6760562a3d5d012367a65c74fae010de305ec917cd842628a93e8'
assert pin(R/'seal_acquisition_v2.py')['sha256']=='63867845dc1e90dd68580a207eaa51f241b32075e24749432b4ae043ed4f48ae'

for filename in ['typed-fixed-principal-family-search-Source-review-v2.json',
                 'typed-principal-search-custodian-Source-review-v1.json',
                 'typed-principal-search-corpus-Source-review-v1.json']:
    assert load(C/filename)['review_passed'] is True
assert pin(C/'typed-fixed-principal-family-search-Source-review-v2.json')['sha256']=='ec4216d2f1a15fbfd9dae93c29b1d4139592695bd5d935b93fed8d59f683bcdf'
assert pin(C/'typed-principal-search-custodian-Source-review-v1.json')['sha256']=='b3928179cfe32fa2a9026eed847f13bd38a37df0aa9e65bae586e8fbbd450b08'
assert load(L/'typed-reference-setup-calibration-Source-review-v1.json')['review_passed'] is True

assert plan['schema']=='proof-search-case-once-plan-v1' and plan['stage']=='acquire' and plan['case_id']=='acquire-0'
assert plan['required_upstream_ids']==plan['upstream_receipts']==[] and plan['template_pending_fresh_acquisition'] is False
assert plan['entry_path']==str(D/'implementation-B/proof_search_pilot_v16.py')
assert plan['input_path']==str(L/'acquisition-inputs-v1.json')
assert same(plan['limits'],protocol['limits']) and same(plan['experiment_limits'],protocol['experiment_limits'])
assert same(plan['protocol'],pin(R/'protocol-v1.json'))
assert pin(plan['python']['path'])==plan['python']
expected_modules=dict(compiler='quantified_receptors_v1',host='logic',miner='semantic_lemma_inventory',
                     model='word_point_model_v1',points='turtle',symbolic='quantified_symbolic_control_v2')
assert plan['modules']==expected_modules

forbidden_sha={
 '04fffc6e3ea0e9bbbe2ec1c2f1b251ce62ff0a527571288c96a0ccda77b6a174',
 '4c1f3ce62d6b27f16042442176171dd7fd2d9f26211553907d0ce6ab3a43db93',
 'c58d29127d3fc912c70b9de73dd1f4caed806a8b33542295cc6fc1257528bbaf'}
for row in plan['files']:
    assert row['sha256'] not in forbidden_sha and '/actual/' not in row['path']
    assert not any('.partial' in x for x in Path(row['path']).parts)
common_paths={r['path'] for r in family['common_files']}
assert str(L/'acquisition-inputs-v1.json') not in common_paths
assert str(L/'evaluation-inputs-v1.json') not in common_paths
assert str(R/'materialize_plans_v3.py') in common_paths and str(R/'seal_acquisition_v2.py') in common_paths
assert str(L/'passive_acquisition_join_v3.py') in common_paths
assert str(L/'passive_acquisition_join_v2.py') not in common_paths

jobs=protocol['job_recipes'];templates=[]
assert len(jobs)==17 and family['jobs'][0]['plan_or_template']==pin(plan_path)
for ordinal,(record,recipe) in enumerate(zip(family['jobs'],jobs)):
    assert record['stage_id']==recipe['stage_id'] and record['stage']==recipe['stage']
    assert record['scientific_execution_authorized'] is False
    assert same(pin(record['plan_or_template']['path']),record['plan_or_template'])
    subject=load(record['plan_or_template']['path'])
    assert subject['case_id']==record['stage_id'] and subject['stage']==record['stage']
    assert not Path(subject['actual_dir']).exists() and not Path(subject['actual_dir']+'.observer').exists()
    if ordinal:
        expected=dict(plan)
        expected.update(schema='proof-search-case-once-template-v1',stage='evaluate',case_id=record['stage_id'],
            actual_dir=str(D/'actual'/record['stage_id']),input_path=str(L/'evaluation-inputs-v1.json'),
            files=family['common_files']+[pin(L/'evaluation-inputs-v1.json')],
            required_upstream_ids=['acquire-0'],upstream_receipts=[],template_pending_fresh_acquisition=True)
        assert same(subject,expected)
        templates.append(record)
assert len(templates)==16

copies=load(R/'inherited-runtime-raw-copy-v1.json')['raw_copies']
assert len(copies)==38
for row in copies:
    assert same(pin(row['source']['path']),row['source']) and same(pin(row['copy']['path']),row['copy'])
    assert row['source']['sha256']==row['copy']['sha256']
    assert row['copy']['path'] in common_paths
runtime=set((D/'runtime').glob('*.py'))
assert len(runtime)==38 and {str(p) for p in runtime}=={row['copy']['path'] for row in copies}

asts=[]
for row in plan['files']:
    p=Path(row['path'])
    if p.suffix=='.py':
        tree=ast.parse(p.read_bytes(),filename=str(p));compile(tree,str(p),'exec',dont_inherit=True)
        asts.append(row)
passive_source=L/'passive_acquisition_join_v3.py'
helper_tree=ast.parse(passive_source.read_bytes())
assert {n.names[0].name for n in helper_tree.body if isinstance(n,ast.Import)}=={'argparse','hashlib','json','math','time'}
assert [n.module for n in helper_tree.body if isinstance(n,ast.ImportFrom)]==['pathlib']
helper_matrix=[dict(name=n.name,start=n.lineno,end=n.end_lineno) for n in helper_tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))]

checks=[
 dict(id='exact successor acquisition plan and complete template family',passed=True,
      evidence='Exact familye1918d70…/34339B and acquisition660fbc37…/29724B;89 common/90 phase rows and all17 member pins match. One acquisition plan and16 template declarations, no actual directory exists.'),
 dict(id='all declared executing Sources and runtime copy closure',passed=True,
      evidence=dict(declared_rows=90,runtime_modules=38,raw_copy_rows=38,AST_unused_compiles=len(asts),
        meaning='Every raw Source/input/Python/Native dependency row matches. The38 runtime files exactly equal their declared source/copy rows. Byte-identical earlier algorithms are reused through the independent component review, not reexecuted.')),
 dict(id='cold phase exclusion and exact original corpus',passed=True,
      evidence='Acquisition closure has only the two-donor statement body; all three known evaluation-bearing bodies are excluded by raw SHA as well as no old actual bodies. Common metadata may name or pin target files but does not contain their full statement bodies. Each template uses only the frozen eight-case evaluation document plus common Sources; no old proof/export/policy is upstream.'),
 dict(id='all original limits, six scientific roles and fixed Native identity',passed=True,
      evidence='Plan exactRoot160/180/210/225s,1GiB/128MiB/48MiB result/9MiB reserve/4MiB logs/400m callbacks; local600/2s,512/1e9,16/20000 and all markings/audit quotas match protocol and reviewed B Source. Same pinned Python and fixed Native dependencies. No fit prediction.'),
 dict(id='independent B/corpus/custodian/calibration Source review join',passed=True,
      evidence='Exact v16 component receipt ec4216d2…, custodian b3928179…, corpus da8f9574… and independent L calibration6886cd06… are bound. The preserved v15 UNKNOWN-fragment negative is corrected by complete-profile gates; calibration is independently peer-reviewed, not C self-admitted.'),
 dict(id='complete passive helper Source and no scientific replay',passed=True,
      evidence='All43,463B manually read. Only stdlib imports; raw pins/complete JSON, literal profile/field/digest/projection/custody joins only. No checker/miner/unifier/compiler/Graph/encoder/tape decoder or Native call. CLI exit0 can report unqualified; it never writes an admission/seal and remains admitted=False until separate Root/C actions.'),
 dict(id='clock negative retained and corrected sample boundary',passed=True,
      evidence='Original helper clock negative retained. Worker elapsed is post-Native-close/final-Source work and is checked against original positive180, not scientificwork160; the genuine160 work limit remains the exact reviewed worker callback/first-fault/stage contract. Header/known exit/custody/observer samples are separately bounded, not relabeled launch-to-tool-end time.'),
 dict(id='returned cost-carrier negative retained and exact v3 correction',passed=True,
      evidence='C negative ece854f6… binds the unexecuted old v2 helper/family. Exact v3 changes only VERSION and the stale initial5field block. It validates the returned8field carrier: no old history/cost, finite science.seconds identical to current_entry and cold upstream-plus samples, exact final qualification text. No helper was invoked to test this; Source ABI/control flow only.'),
 dict(id='every Native current membership and accepted acquisition scope',passed=True,
      evidence='Helper compares whole worker/science streams and every ordered completed start/stage/request/input/output digest/limit, fixed query protocol/blocks=[], owned group/closed/reaped Native, HWM and final raw input/output. Whole/fragment certificates must literally equal current owned records under exact theory/proof/actual target. Compiler rejections remain distinct from accepted proof authority.'),
 dict(id='independent full-profile resolution and exact full export joins',passed=True,
      evidence='Helper derives axiom/MP-with-MP profile from every candidate proof, joins Native status, retains UNKNOWN unresolved and recomputes qualification independent of flags/minimum library. It joins post-annotation full record hashes, exact slim projections, all accepted certificates, full dual libraries/member templates/DAGs/inner wrappers and observed structure count. No old count forecast or shortened-library rescue.'),
 dict(id='complete control and v3 reduction evidence requirements',passed=True,
      evidence='Expected211 acquisition finite rows and separate Tiny diagnostics are checked as actual returned records, not Source passes. Original/v3 tiny same-model field comparison and every real-model full v3+wire receipt remain required. These are finite implementation controls, not a mechanized principal theorem or full FOL replay.'),
 dict(id='Root sealer and materializer exact review/passive/native/export binding',passed=True,
      evidence='Materializer-v3 and sealer-v2 manually read by exact predecessor/delta. Missing passive_join equality is corrected. Both require unique new D17 plan/result/header/terminal/observer, successful exact C actual review and same passive helper/cost/proof-admission joins; sealer explicitly joins export SHA. Complete exclusively created13field seal/admission required together; a crash cannot authorize downstream execution.'),
 dict(id='non-executable templates and future materialized-plan barrier',passed=True,
      evidence='All16 templates match the common acquisition declaration except exact phase/schema/case/input/upstream/pending fields. The unchanged parent rejects their template schema. Materializer rehashes every template Source and adds unique sealed upstream/admission/C-review/helper/complete artifact pins. Every resulting concrete eval plan still requires independent exact review and fresh once grant; none is approved for execution here.'),
 dict(id='manual UNKNOWN regression and honest study scope',passed=True,
      evidence='Source-control-flow regression was reviewed, not executed. No extra synthetic controller is required; independently derived passive profile checks and separate complete actual review are mandatory before sealing. Same17job/64slot public development population, PA/PP matched abstraction factor, shared markings, no RL, no old adoption, no claimed fit/benefit/new theorem, no direct D15 timing attribution.'),
 dict(id='frozen negatives and current Source/whole review boundaries',passed=True,
      evidence='Retain old v15 scientific-completeness negative, v1 clock negative, v2 helper cost negative and materializer draft missing-join observation. They are not silently qualified or mislabeled actual failures. All current offered raw bodies remain unchanged; no grant or actual result is produced by this reviewer.')
]

v=dict(schema='typed-principal-family-search-whole-prospective-Source-review-v2',
 reviewer_identity='/root/recovered_batch_review',review_passed=True,source_only=True,
 scientific_calls=0,scientific_imports=0,helper_or_materializer_calls=0,
 fixtures_executed=0,compiled_code_executed=False,partial_files_parsed=False,
 actual_execution_authorized=False,grant_issued=False,retry_authority=False,
 scope='Final independent whole prospective Source/ABI/custody review of the exact new acquisition plan. Evaluation templates are design declarations only, never execution approval.',
 plan=pin(plan_path),template_family=pin(family_path),template_pins=templates,
 source_closure_pins=plan['files'],AST_unused_compile_pins=asts,runtime_raw_copy_rows=copies,
 B_component_review=pin(C/'typed-fixed-principal-family-search-Source-review-v2.json'),
 custodian_component_review=pin(C/'typed-principal-search-custodian-Source-review-v1.json'),
 corpus_component_review=pin(C/'typed-principal-search-corpus-Source-review-v1.json'),
 independent_calibration_peer_review=pin(L/'typed-reference-setup-calibration-Source-review-v1.json'),
 conditional_reference_contract=pin(C/'reference-production-contract-v1.json'),
 passive_helper_handoff=pin(helper_handoff_path),passive_helper_Source=pin(passive_source),
 passive_helper_function_matrix=helper_matrix,
 materializer_Source=pin(R/'materialize_plans_v3.py'),sealer_Source=pin(R/'seal_acquisition_v2.py'),
 preserved_negatives=[pin(C/'typed-fixed-family-Source-negative-v15.json'),
   pin(L/'passive-acquisition-join-Source-negative-v1.json'),
   pin(C/'typed-passive-acquisition-join-Source-negative-v2.json'),
   pin(C/'typed-materializer-draft-observation-v1.json')],
 checks=checks,failed_checks=[],
 controls_status='All D17 controls UNRUN. Prior D16 evidence is historical development confidence only, not adoption or current qualification.',
 unknown_regression_status='MANUAL_SOURCE_CONTROL_FLOW_REVIEW_ONLY; no simulated Native outcome or executed helper fixture.',
 current_acquisition_prerequisites='Root must bind this exact receipt/plan in one fresh max-one grant after all scientific tools/processes/preview services are idle. This review issues no grant and predicts no successful fit.',
 future_actual_review_required=[
   'Independent C passive review of every complete acquisition artifact, exact grant/consumption/tool-known exits and whole resource gates before any seal; no accepted prefix/partial rescue.',
   'C must independently join full/ancestor proof row copies and remapped references to original whole donor rows, Host/full-region gates and all owned Native records. The passive helper deliberately does not rerun ancestor extraction, a proof checker, miner or MGU.',
   'Join all live independent typing fields/concrete donor arguments/aliases, complete profile-resolution counters, paired class membership/inner wrappers and exact post-annotation record/export projections; no old fixed certificate count.',
   'C actual receipt must include review_passed/resource_admitted/scientific_qualified, exact plan/result and passive_join pins. Resource candidate report/tool exit alone is not scientific admission.',
   'Only after new complete admitted acquisition may Root seal and materialize eval plans. Each exact materialized plan must be reviewed; preserve all64 slots, failed jobs and UNKNOWNs under original bounds, no retry or historical library fallback.'
 ],
 limitations=['Fixed-dependency nonhostile research custody, not hostile sandbox or real-time OS guarantee.',
   'No scientific code or passive helper executed by reviewer; Source/static/pin review establishes no actual resource fit or outcome.',
   'Finite control receipts and manual principal/reference arguments are not mechanized general soundness or full proof-search/physical Wang qualification.'],
 tools_stopped_after_freeze=True)
target=C/'typed-principal-family-search-whole-prospective-Source-review-v2.json'
assert not target.exists()
target.write_text(json.dumps(v,sort_keys=True,ensure_ascii=True,allow_nan=False,indent=2)+'\n')
print(json.dumps(dict(review=pin(target),review_passed=True,checks=len(checks),failed_checks=[],
 Source_rows=len(plan['files']),AST_unused_compiles=len(asts),eval_templates=len(templates))))
