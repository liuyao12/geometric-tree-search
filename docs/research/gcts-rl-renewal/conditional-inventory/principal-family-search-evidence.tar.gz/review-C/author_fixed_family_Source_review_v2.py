"""Independent static Source/literal/pin review; no science is imported/run."""
from pathlib import Path
import ast
import hashlib
import json
import re

C=Path(__file__).resolve().parent
D=C.parent
B=D/'implementation-B'
L=D/'diagnostics-L'
OLD=D.parent/'gcts-principal-receptor-families-20261021'

def pin(path):
    path=Path(path).resolve();raw=path.read_bytes()
    return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())

def load(path):
    path=Path(path);assert '.partial' not in path.name
    return json.loads(path.read_bytes())

def wire(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)

def same(a,b):return wire(a)==wire(b)

def declared_pins(value):
    result={}
    if type(value) is dict:
        if set(value)=={'path','bytes','sha256'}:
            result[value['path']]=value
        for child in value.values():result.update(declared_pins(child))
    elif type(value) is list:
        for child in value:result.update(declared_pins(child))
    return result

handoff=load(B/'handoff-v2.json')
assert pin(B/'handoff-v2.json')['sha256']=='0b8833f2c3b8ee096862c39521bd9e7f0fcc4134178e0da7bc8aa2de1c03924f'
assert pin(B/'proof_search_pilot_v16.py')==handoff['entry']
assert handoff['entry']['sha256']=='27222503eee9aebd01b21ed1ecf2e298bdde8d2560ab099165a3d867696b004c'
api=load(B/'API-v2.json');manual=load(B/'manual-conformance-v2.json')
policy=load(B/'fixed-stage-policy-v2.json');manifest=load(B/'manifest-v2.json')
Lhandoff=load(L/'handoff-v3.json');Lapi=load(L/'API-v3.json');Lp=load(L/'protocol-proposal-v3.json')
pins={}
for value in [handoff,api,manual,policy,manifest,Lhandoff,Lapi,Lp]:pins.update(declared_pins(value))
for row in pins.values():assert same(pin(row['path']),row)

sources=[OLD/'implementation-B/proof_search_pilot_v14.py',B/'proof_search_pilot_v15.py',B/'proof_search_pilot_v16.py']
texts=[p.read_text() for p in sources]
trees=[ast.parse(t,filename=str(p)) for t,p in zip(texts,sources)]
for tree,p in zip(trees,sources):compile(tree,str(p),'exec',dont_inherit=True)  # never executed
def functions(tree):
    return {n.name:ast.dump(n,include_attributes=False) for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
f14,f15,f16=[functions(t) for t in trees]
assert set(f14)<=set(f16)
changed14=sorted(k for k in f14 if f14[k]!=f16[k])
added14=sorted(f16.keys()-f14.keys())
assert changed14==['_compile_selector_case','_verify_native_evidence']
assert added14==['_fixed_controls','_fixed_donor_evidence','_fixed_fragment_resolution','_fixed_upstream','_fixed_verify_acquisition','run_fixed_stage']
assert sorted(k for k in f15 if f15[k]!=f16[k])==['_fixed_donor_evidence','_fixed_verify_acquisition','run_fixed_stage']
assert set(f16)-set(f15)=={'_fixed_fragment_resolution'}

# Apply only text hunks to in-memory strings; never execute or overwrite Source.
def text_patch(raw, patch):
    lines=raw.splitlines(keepends=True); result=[]; cursor=0
    chunks=patch.splitlines(keepends=True);i=2
    while i<len(chunks):
        found=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',chunks[i])
        assert found
        start=int(found.group(1))-1
        result.extend(lines[cursor:start]);cursor=start;i+=1
        while i<len(chunks) and not chunks[i].startswith('@@ '):
            line=chunks[i];i+=1
            assert line[0] in ' +-'
            if line[0] in ' -':assert lines[cursor]==line[1:];cursor+=1
            if line[0] in ' +':result.append(line[1:])
    result.extend(lines[cursor:]);return ''.join(result)
assert text_patch(texts[1],(B/'proof-search-v15-v16-raw.patch').read_text())==texts[2]
assert text_patch(texts[0],(B/'proof-search-v14-v16-cumulative-raw.patch').read_text())==texts[2]
assert pin(C/'fixed-family-v15-negative-raw.py')['sha256']==pin(sources[1])['sha256']

# Numeric limits read from AST literal keyword declarations, not module calls.
limit_node=next(n.value for n in trees[2].body if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='LIMITS' for x in n.targets))
assert isinstance(limit_node,ast.Call) and isinstance(limit_node.func,ast.Name) and limit_node.func.id=='dict' and not limit_node.args
limits={k.arg:ast.literal_eval(k.value) for k in limit_node.keywords}
root_protocol=load(D/'root/protocol-v1.json')
assert same(limits,root_protocol['experiment_limits']) and same(api['limits'],limits)
assert same(policy['recipes'],Lp['job_recipes']) and same(root_protocol['job_recipes'],Lp['job_recipes'])
assert same(root_protocol['limits'],Lp['limits'])
assert load(C/'typed-principal-search-corpus-Source-review-v1.json')['review_passed']
assert load(C/'typed-principal-search-custodian-Source-review-v1.json')['review_passed']
peer_path=L/'typed-reference-setup-calibration-Source-review-v1.json'
peer=load(peer_path);assert peer['review_passed']

# Prove the corpus successor changes metadata only by rejoining original bodies.
priorL=load(L/'handoff-v2.json')
prior_by_name={Path(r['path']).name:r for r in priorL['files']}
new_by_name={Path(r['path']).name:r for r in Lhandoff['files']}
for name in ['principal_search_corpus_contract_v1.py','acquisition-inputs-v1.json','evaluation-inputs-v1.json','corpus-control-bank-v1.json']:
    assert same(prior_by_name[name],new_by_name[name])
oldLp=load(L/'protocol-proposal-v2.json')
changed_L_fields=sorted(k for k in oldLp.keys()|Lp.keys() if not same(oldLp.get(k),Lp.get(k)))
assert changed_L_fields==['bounded_pool_scope','schema','selector','supersedes_metadata','uniform_omitted_diagnostic']

checks=[
 dict(id='exact immutable B offer, Source lineage and raw patch reconstruction',passed=True,
      evidence='All recursive raw pins in the frozen B/L packet match. Both unified text patches reconstruct exact v16 bytes from immutable v15 and reviewed v14. Preserved v15 raw Source and independent negative remain exact.'),
 dict(id='full inherited algorithm and proof-authority preservation',passed=True,
      evidence=dict(unchanged_count=len([k for k in f14 if f14[k]==f16[k]]),
        changed_inherited=changed14,new_D17_helpers=added14,
        meaning='All search_symbolic/search_points/search_points_selected, pool, primitive fallback, graph scheduler, markings, rollback, cutoff identity/cleanup, principal/reference mining, pairing/wrappers and final proof-gate function/class ASTs are unchanged. Old run_stage/run_mechanism remain unlaunched.')),
 dict(id='common v3 production reference and explicit separate legacy calibration',passed=True,
      evidence='Every _compile_selector_case constructs the same primitive empty-inventory/no-family model and invokes the complete exact v3 reference. It labels performed_on_this_model=False for old-v1 differential, never fabricates a per-case comparison. One original-v1/v3 same-owner tiny calibration runs in acquisition only, separately peer-reviewed by L. All 48 word/40 encoder gates remain.'),
 dict(id='D17 corpus-v3 metadata delta and complete fixed population',passed=True,
      evidence=dict(changed_protocol_fields=changed_L_fields,
        unchanged='Source, both literal inputs and all24 format controls; all six D15 cases and two explicit contrasts; two fresh donor statements;17 jobs/64 slots and mirrored orders.',
        clarification='Pool coverage is a deterministic bounded prefix up to16 packets/20000validation checks, distinct from the complete primitive incidence graph. The uniformly omitted unused registry is not a prior UNKNOWN promotion.')),
 dict(id='cold acquisition and complete ordinary raw donor/candidate evidence',passed=True,
      evidence='Only acquire-0 with acquisition=None/receipt=None is allowed. Both statement-only donors are freshly searched through unchanged S0 and Host/full-region/Native gates. Every full/ancestor candidate remains in ordered raw records. Slim export retains exact whole proof/check and all annotated candidates, with full record digest computed AFTER annotations.'),
 dict(id='v15 UNKNOWN-fragment blocker corrected without shorter-library rescue',passed=True,
      evidence='New _fixed_fragment_resolution independently derives profile membership from full axiom/MP proof shape. UNKNOWN remains profile_eligible=True/native_resolution=<unknown>, records unresolved ordinal/status and all_profile_fragments_accepted=False. Qualification requires both whole donors AND all profile fragments accepted, plus nontriviality threshold. Result is unresolved/stage incomplete/export=None even if a shortened library could meet threshold. Axiom-only non-profile candidates remain separately labeled; no fixed old certificate count or retry.'),
 dict(id='independent sealed reconstruction refuses every unresolved profile',passed=True,
      evidence='Evaluator re-derives every whole/ancestor fragment and exact reference remapping, profile membership and Native resolution. Each profile requires accepted; the previous UNKNOWN-continue is gone. Exact independently reconstructed resolution counters/unresolved=[] must match each donor projection before certificates, all atom classes and wrappers are rebuilt.'),
 dict(id='full Native certificate reuse and scientific versus custody boundaries',passed=True,
      evidence='Exact request protocol/theory/proof/actual target/blocks=[], request and binary digest fields, accepted status, fixed Native identity and full Root export hash are rejoined. Later phases freshly Host-check whole/fragments and rerun production+independent typing and wrapper verification; identical Native proof evidence is reused, not replayed. Exact owned oracle membership/full-region/full-record projection and freshness remain mandatory Root admission/seal prerequisites.'),
 dict(id='same atom-class pairing, multiplicity, all members and exact structural wrappers',passed=True,
      evidence='Unchanged _paired_receptor_libraries and _mine_receptor_pair retain all live independent typing fields and concrete arguments/aliases. Same atom classes/order/multiplicity in PA/PP, all class members agree principal template/DAG; no principal coalescence. Relabeled outer ID never substitutes for exact structural inner family passed to principal.verify.'),
 dict(id='four methods, fixed selection, shared markings and unchanged fallback',passed=True,
      evidence='S0 uses unmarked base/no library; P0 uses common verified marked model/no library; PA/PP use the same marked model and unchanged selected-point search with their respective paired library. Dummy nine zero floats feed fixed choose mode, which selects first packet or ABSTAIN without policy history/update. Only original primitive keys can be preferred; forced moves/point choice/novelty tiers/full fallback remain. Seed labels change only declared order, not stochastic learning.'),
 dict(id='uniform unused diagnostic omission and honest comparison scope',passed=True,
      evidence='New evaluation driver never invokes _ground_clusters/diagnostic_ground_registry for any method; records None and explicit omitted-diagnostic scope. All acquired-fragment and final fresh Host/full-region/Native blocks=[] authority stays unchanged. Common v3 and registry omission are setup changes, so D15/D17 elapsed/fit is historical context, not a single-factor speedup.'),
 dict(id='complete final proof gates, UNKNOWN and resource nonauthority',passed=True,
      evidence='Every found proof is freshly Host checked, whole-region verified and Native queried for the exact declared target with no blocks. Rejected actual certificate faults; known Native unknown leaves final-unresolved/stage incomplete. No-proof bounded UNKNOWN is a returned observation, not an unprovability proof. Four-method record completion, scientific stage completeness and Root whole resource admission remain separate.'),
 dict(id='all original caps, cumulative costs and prospective control census',passed=True,
      evidence=dict(experiment_limits=limits,
        outer='Exact Root protocol keeps160/180/210/225s,1GiB,128MiB,48MiB result,9MiB outer reserve,4MiB logs and400m callbacks.',
        finite_control_rows_acquisition=211,finite_control_rows_evaluation=186,
        controls_status='All UNRUN. Inherited Tiny diagnostics are separate from these row counts.',
        costs='Fresh acquisition observer sample carried once, current entry clocks separately labeled, whole/custody samples added only after actual completion; cross-job totals must deduplicate shared acquisition. No overlap clocks summed as independent components.')),
 dict(id='fault propagation and immutable input/library scope',passed=True,
      evidence='New stage helpers introduce no exception catch/reclassification and all genuine Root/foreign faults escape unchanged. Fixed stage hashes original phase and upstream values, checks libraries and zero interface after every arm. No actual old State/Graph/function owner is reconstructed from exported identifiers.'),
 dict(id='scope and remaining whole-plan barriers',passed=True,
      evidence='No current component Source blocker remains on exact v16. This receipt does not approve Root admission helper, acquisition/evaluation closures, concrete plans, grants, actual fit, outcomes, learning, useful GCTS advantage or new theorems. Failed v15 is retained, not retrospectively qualified.')
]

v=dict(schema='typed-fixed-principal-family-search-Source-review-v2',reviewer_identity='/root/recovered_batch_review',
 review_passed=True,source_only=True,scientific_imports=0,scientific_calls=0,helpers_or_fixtures_executed=0,
 AST_unused_compile=True,compiled_code_executed=False,partial_files_parsed=False,
 actual_execution_authorized=False,whole_plan_approved=False,retry_or_changed_bound_authority=False,
 handoff=pin(B/'handoff-v2.json'),entry=handoff['entry'],API=handoff['API'],
 all_current_declared_pin_joins=sorted(pins.values(),key=lambda p:p['path']),
 raw_predecessors=[pin(p) for p in sources[:2]],
 prior_independent_full_Source_review=pin(OLD/'review-C/typed-principal-mechanism-whole-Source-plan-review-v1.json'),
 preserved_negative=pin(C/'typed-fixed-family-Source-negative-v15.json'),
 corrected_source_contract=dict(export_schema='gcts-principal-family-search-stage-export-v2',
   profile_membership='Every derived axiom/MP-with-MP fragment, independent of legacy eligible admission flag.',
   UNKNOWN='Retained as in-profile, never accepted, blocks whole export and sealed reuse.',
   manual_counterexample_resolution='The exact unrun v15 chain proper-fragment UNKNOWN recipe now makes all_fragments_accepted false regardless of the remaining two-class threshold; no scientific execution was used to reach this Source conclusion.'),
 inherited_AST_matrix=[dict(name=k,unchanged=(f14[k]==f16[k])) for k in sorted(f14)],
 D17_function_review_matrix=[dict(name=n.name,start=n.lineno,end=n.end_lineno,
   review='Full new Source read; checks above describe scientific/trust scope.') for n in trees[2].body
   if isinstance(n,ast.FunctionDef) and n.name in added14+changed14],
 conditional_reference_contract=pin(C/'reference-production-contract-v1.json'),
 calibration_author_handoff=pin(C/'reference-setup-calibration-handoff-v1.json'),
 calibration_independent_peer_review=pin(peer_path),
 corpus_Source_review=pin(C/'typed-principal-search-corpus-Source-review-v1.json'),
 corpus_v3_handoff=pin(L/'handoff-v3.json'),custodian_Source_review=pin(C/'typed-principal-search-custodian-Source-review-v1.json'),
 Root_protocol=pin(D/'root/protocol-v1.json'),checks=checks,failed_checks=[],
 permitted_conclusion='Conditional component Source/ABI/protocol correctness review of exact frozen v16 composition, including the preserved negative and separately authored calibration peer review. No runtime or study result.',
 future_required=[
   'Root whole acquisition plan/phase closure must bind these exact Sources and caps, exclude all evaluation-bearing bodies and use fresh once grant only after the whole review/idle barrier.',
   'Root acquisition admission/seal must bind every post-annotation full donor record hash/projection, complete candidate resolution, all whole/fragment owned Native records and independently accepted Source/resource/scientific reviews; no stage-ID-only freshness inference.',
   'Every evaluation requires the unique new D17 complete sealed export and exact materialized plan with reviewed dependencies; no historical D16 adoption, shortened library, old weights, retries or changed bounds.',
   'Actual complete control records, all64 method slots including unavailable failures/UNKNOWN, proof checks, packet/trace/permutation/audits/rollback and all costs still need independent passive review.',
   'Finite calibration/control results do not mechanize the principal theorem or universal verifier equivalence. General logical theorem scope remains fixed finite MP DAG/whole-formula port quotient; this is public development, not blind or family-held-out validation.'
 ],tools_stopped_after_freeze=True)
p=C/'typed-fixed-principal-family-search-Source-review-v2.json';assert not p.exists()
p.write_text(json.dumps(v,sort_keys=True,ensure_ascii=True,allow_nan=False,indent=2)+'\n')
print(json.dumps(dict(review=pin(p),checks=len(checks),failed_checks=[],review_passed=True,
                     unchanged_inherited=len([k for k in f14 if f14[k]==f16[k]]),all_pin_rows=len(pins))))
