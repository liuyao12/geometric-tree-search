"""Passive raw Source and admission-output review; do not invoke Root helpers."""
import ast
import difflib
import hashlib
import json
from pathlib import Path

D=Path(__file__).resolve().parents[1];R=D/'root';C=D/'review-C'
def pin(p):
    p=Path(p).resolve();b=p.read_bytes()
    return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def load(p):
    assert '.partial' not in Path(p).name
    return json.loads(Path(p).read_text())
def verify(row):assert pin(row['path'])==row,row['path']

actualp=C/'typed-fixed-family-final16-evaluation-actual-review-v1.json'
actual=load(actualp)
assert pin(actualp)['sha256']=='6c31cc94dc522a7053434c8ee578cce30709db80ebc54050c33c0eabfe036067'
assert actual['review_passed'] is True and actual['failed_checks']==[]
for row in actual['exact_input_pins']:verify(row)
for case in actual['cases']:
    for row in case['complete_file_census']:verify(row)

v1=R/'admit_evaluations_v1.py';v2=R/'admit_evaluations_v2.py'
correctionp=R/'passive-admission-helper-correction-v1.json';correction=load(correctionp)
assert correction['preserved_source']==pin(v1)
assert correction['corrected_source']==pin(v2)
assert pin(v1)['sha256']=='8ddf202e71009d509f0b8ee0e0a9a90d9fbecaa1d30f8d4e8ee2e0a22d2ba03a'
assert pin(v2)['sha256']=='18a17b4a69dacc5c7f738e9aeb332aa7052969542f929776e510ad29bc195bd9'
old=v1.read_text();new=v2.read_text()
ta=ast.parse(old);tb=ast.parse(new)
assert [n.module for n in tb.body if isinstance(n,ast.ImportFrom)]==['pathlib']
assert [n.names[0].name for n in tb.body if isinstance(n,ast.Import)]==['hashlib','json']
olddefs={n.name:n for n in ta.body if isinstance(n,ast.FunctionDef)}
newdefs={n.name:n for n in tb.body if isinstance(n,ast.FunctionDef)}
assert set(olddefs)==set(newdefs)=={'pin','read','write','main'}
assert ast.dump(olddefs['pin'])==ast.dump(newdefs['pin'])
assert ast.dump(olddefs['read'])==ast.dump(newdefs['read'])
assert "assert case['arms'] == []" in old and "assert len(case['arms']) == 4" in new
assert "assert path.read_bytes() == body, 'existing admission must be byte-identical'" in new
assert "with path.open('xb') as stream:" in new
assert "assert not target.exists()" in old and "assert not target.exists()" not in new
diff=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=str(v1),tofile=str(v2)))

indexp=R/'evaluation16-admissions-v1.json';index=load(indexp)
assert index['C_review']==pin(actualp)
assert index['whole_study_complete'] is False and index['scientific_calls']==0 and index['partial_files_parsed'] is False
assert len(index['admissions'])==len(actual['cases'])==16
rows=[];counts=dict(admitted=0,rejected=0,accepted_proof_occurrences=0,UNKNOWN=0,unavailable=0)
for offered,case in zip(index['admissions'],actual['cases']):
    verify(offered);a=load(offered['path'])
    assert a['schema']=='D17-Root-whole-admission-v1' and a['stage']=='evaluate' and a['stage_id']==case['stage_id']
    assert a['C_review']==pin(actualp)
    for key in ('resource_admitted','scientific_qualified','stage_complete','admitted'):
        assert type(a[key]) is bool and a[key] is case[key]
    for key in ('plan','result','failure','header','terminal','observer'):
        assert a[key]==case[key]
        if a[key] is not None:verify(a[key])
    assert a['whole_seconds']==case['observer_elapsed_ledger_sample']
    assert a['whole_peak_bytes']==case['whole_peak_bytes']
    assert (Path(offered['path']).parent==R/'admission')
    assert Path(offered['path']).name==case['stage_id']+'-v1.json'
    if a['admitted']:
        assert all(a[k] for k in ('resource_admitted','scientific_qualified','stage_complete'))
        assert a['result'] is not None and a['failure'] is None
        assert len(case['arms'])==4
        counts['admitted']+=1
        for arm in case['arms']:
            if arm['proof_accepted']:
                assert arm['proof_status']=='HOST_REGION_NATIVE_ACCEPTED'
                counts['accepted_proof_occurrences']+=1
            else:
                assert arm['status']=='unknown_search_budget' and arm['proof_status']=='NO_PROOF_CANDIDATE'
                counts['UNKNOWN']+=1
    else:
        assert all(a[k] is False for k in ('resource_admitted','scientific_qualified','stage_complete'))
        assert a['result'] is None and a['failure'] is not None and a['whole_peak_bytes'] is None
        assert len(case['arms'])==4 and [arm['id'] for arm in case['arms']]==case['method_order']
        for arm in case['arms']:
            assert arm['status']=='UNAVAILABLE_WHOLE_JOB_WORK_FAILURE'
            assert arm['proof_accepted'] is None and arm['search_returned'] is False
            assert arm['resource_admitted'] is arm['scientific_qualified'] is False
        counts['rejected']+=1;counts['unavailable']+=4
    rows.append(dict(admission=offered,stage_id=a['stage_id'],
        **{key:a[key] for key in ('plan','result','failure','header','terminal','observer','resource_admitted',
            'scientific_qualified','stage_complete','admitted','whole_seconds','whole_peak_bytes')}))
assert counts==dict(admitted=14,rejected=2,accepted_proof_occurrences=50,UNKNOWN=6,unavailable=8)
assert index['summary']==dict(qualified_jobs=14,failed_jobs=2,planned_slots=64,returned_searches=56,
    accepted_proof_occurrences=50,bounded_point_UNKNOWN=6,unavailable_setup_slots=8)
prefix=correction['prior_exact_prefix_receipts']
assert len(prefix)==6
assert {row['path'] for row in prefix}=={row['path'] for row in index['admissions'][:6]}
for row in prefix:
    verify(row)
    assert row in index['admissions']
assert not any(load(row['path'])['admitted'] is False for row in prefix)

review=dict(schema='D17-independent-passive-admission-correction-and-output-review-v1',
    reviewer_identity='/root/recovered_batch_review',review_passed=True,
    scope='Source-only review of the Root passive helper correction and exact saved per-case admission outputs. No scientific replay, helper execution, new admission or grant.',
    actual_review=pin(actualp),admission_index=pin(indexp),helper_v1=pin(v1),helper_v2=pin(v2),correction=pin(correctionp),
    check_count=3,failed_checks=[],
    checks=[dict(check='Exact preserved helper lineage and narrowly scoped Source correction',passed=True,
        evidence=dict(diff=diff,imports=['pathlib','hashlib','json'],
            interpretation='V1 incorrectly rejected the four unavailable method placeholders at the first failed job. V2 validates their complete fixed order and unavailable status. Existing receipts are read and accepted only if their full generated bytes match; new files use exclusive binary creation. No existing receipt is rewritten.')),
        dict(check='All sixteen admission outputs match frozen independent classifications and artifact pins',passed=True,
            evidence=dict(cases=rows,counts=counts,unchanged_actual_input_pins=len(actual['exact_input_pins']),
                unchanged_complete_actual_files=sum(len(c['complete_file_census']) for c in actual['cases']))),
        dict(check='Six valid prefix receipts retained and whole-cohort gap preserved',passed=True,
            evidence=dict(prior_prefix_receipts=prefix,whole_study_complete=False,
                interpretation='All six earlier successful per-case receipts remain byte-identical. The correction completes passive metadata only; it is not an actual retry or prefix adoption of a failed scientific job. The reported execution sequence is Root-owned provenance, not independently inferred from file timestamps.'))],
    scientific_calls=0,scientific_imports=0,helper_calls=0,scientific_replay=False,partial_files_parsed=False,
    admission_or_seal_emitted=False,actual_execution_authorized=False,whole_study_complete=False,
    permitted_summary=index['summary'],
    limitations=['UNKNOWN remains an outcome of a completed bounded search, not a proof of impossibility.',
        'Two failed setup jobs retain null result authority, complete failure pins and four unavailable placeholders each; all eight slots remain in the planned cohort.',
        'The helper sources are fixed-dependency nonhostile passive custodians. The review does not extend them into a general hostile-data security boundary.',
        'No new target proof, RL learning, useful GCTS/ATP advantage, speedup or complete-study qualification follows from admission metadata.'],
    reviewer_author_source=pin(Path(__file__)))
out=C/'typed-evaluation16-admission-output-review-v1.json'
assert not out.exists()
out.write_text(json.dumps(review,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(output=pin(out),review_passed=True,counts=counts)))
