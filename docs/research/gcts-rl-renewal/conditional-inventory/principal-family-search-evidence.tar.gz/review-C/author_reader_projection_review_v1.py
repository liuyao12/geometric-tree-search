"""Passive complete display-data joins; never run/import the projector."""
import collections
import copy
import hashlib
import json
from pathlib import Path

D=Path(__file__).resolve().parents[1];C=D/'review-C';B=D/'implementation-B';R=D/'root'
def pin(p):
    p=Path(p).resolve();b=p.read_bytes()
    return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def load(p):
    assert '.partial' not in Path(p).name
    return json.loads(Path(p).read_text())
def verify(p):assert pin(p['path'])==p
data_p=D/'publication/principal-family-search-data.json';html_p=D/'publication/principal-family-search.html'
data=load(data_p)
assert pin(data_p)['sha256']=='5af3a9bb797a691fcf3ab639d6bcd20903ef4f04af6aaf32c3d1b0ee9f5a997f'
assert pin(data_p)['bytes']==1340062
assert html_p.read_bytes()==(B/'principal-family-search-template-v2.html').read_bytes()
source_reviewp=C/'typed-passive-reader-Source-review-v2.json'
actual_reviewp=C/'typed-fixed-family-final16-evaluation-actual-review-v1.json'
admission_reviewp=C/'typed-evaluation16-admission-output-review-v1.json'
assert load(source_reviewp)['review_passed'] is load(admission_reviewp)['review_passed'] is True
actual=load(actual_reviewp)
for row in actual['exact_input_pins']:verify(row)
admissions=load(R/'evaluation16-admissions-v1.json')
assert admissions['whole_study_complete'] is False
acq=load(D/'actual/acquire-0/result.json')['scientific_result']
cases={c['stage_id']:c for c in actual['cases']}
raws={cid:load(c['worker_output']['path']) for cid,c in cases.items()}
raws['acquire-0']=load(D/'actual/acquire-0/result.json')
assert data['schema']=='D17-principal-family-search-passive-reader-v2'
assert data['corpus']['acquisition']==load(D/'diagnostics-L/acquisition-inputs-v1.json')
assert data['corpus']['evaluation']==load(D/'diagnostics-L/evaluation-inputs-v1.json')
for p in data['corpus']['pins']:verify(p)
assert len(data['slots'])==64 and len(data['jobs'])==16 and len(data['proofs'])==52

def check_admission(projected,cid):
    p=R/'admission'/(cid+'-v1.json');a=load(p)
    assert projected['receipt']['pin']==pin(p)
    assert projected['receipt']['plan']==a['plan']
    assert projected['receipt']['result']==a['result'] and projected['receipt']['C_review']==a['C_review']
    for k in ('admitted','resource_admitted','scientific_qualified','stage_complete'):
        assert projected[k] is a[k]
    assert projected['status']==('WHOLE_ADMITTED' if a['admitted'] else 'NOT_WHOLE_ADMITTED')

expected_views=[];expected_slots=[];counts=collections.Counter();methods=collections.defaultdict(collections.Counter)
acq_proj=data['acquisition'];check_admission(acq_proj['admission'],'acquire-0')
assert acq_proj['executed'] is True and acq_proj['status']==acq['status']
assert acq_proj['all_profile_fragments_accepted'] is True
assert acq_proj['donor_outcomes']==acq['donor_outcomes'] and acq_proj['pairing']==acq['pairing']
for i,rec in enumerate(acq['records']):
    expected_views.append(('acquire-0','scientific_result.records[%d]'%i,'DONOR',rec,rec['search'],rec['proof_check']))

trace_summaries=[]
def check_trace(projected,search,cid,mid):
    orders={};pools=[];selected=[];preferred=[]
    for i,e in enumerate(search['trace']):
        if e['event']=='order':orders[e['decision']]=(i,e)
        elif e['event']=='selector_pool':
            po=e['pool'];choice=e['action']['choice']
            pools.append(dict(trace_index=i,decision=e['decision'],packet_count=len(po['packets']),
                distinct_continuations=po['distinct_primitive_continuations'],termination=po['termination'],
                inspected_bindings=po['inspected_bindings'],validation_checks=po['validation_checks'],
                pool_size_class=po['pool_size_class'],continuation_size_class=po['continuation_size_class'],
                action_choice=choice,abstained=choice==len(po['packets'])))
            if choice<len(po['packets']):
                packet=po['packets'][choice]
                selected.append(dict(trace_index=i,decision=e['decision'],packet_ordinal=choice,
                    **{k:packet[k] for k in ('family','arguments','source_binding','prefix_rows','result_formula','commands','pending','members')},
                    source_path='search.trace[%d].pool.packets[%d]'%(i,choice),
                    immediate_preferred_placement_trace_indices=[],whole_cluster_completion=None))
        elif e['event']=='place':
            oi,order=orders[e['decision']]
            if e['key'] in order['preferred']:
                preferred.append(dict(trace_index=i,order_trace_index=oi,decision=e['decision'],key=e['key']))
                for p in selected:
                    if p['decision']==e['decision'] and e['key'] in p['pending']:
                        p['immediate_preferred_placement_trace_indices'].append(i)
    assert projected['pools']==pools and projected['preferred_placement_events']==preferred
    assert len(projected['selected_packets'])==len(selected)
    for a,b in zip(projected['selected_packets'],selected):
        for k,v in b.items():assert a[k]==v
    assert projected['completed_pool_calls']==len(pools)
    assert projected['returned_pool_packets']==sum(v['packet_count'] for v in pools)
    assert projected['selected_packet_count']==len(selected)
    assert projected['preferred_placement_count']==len(preferred)
    assert projected['whole_cluster_completion_count'] is None
    assert projected['pools_with_competing_continuations']==sum(v['distinct_continuations']>=2 for v in pools)
    trace_summaries.append(dict(stage_id=cid,method=mid,pools=len(pools),packets=projected['returned_pool_packets'],
        selected=len(selected),preferred_events=len(preferred),whole_cluster_completion=None))

slot_index=0
for job,checked in zip(data['jobs'],actual['cases']):
    cid=checked['stage_id'];raw=raws[cid];s=raw['scientific_result']
    assert job['stage_id']==cid and job['executed'] is True
    check_admission(job['admission'],cid)
    assert job['worker_status']==raw['status'] and job['error']==raw['error'] and job['worker_stages']==raw['stages']
    assert job['file_pins']['result']==checked['worker_output']
    for k in ('header','terminal','observer'):
        assert job['file_pins'][k]==checked[k]
        assert job['resource_receipts'][k]==load(checked[k]['path'])
    if s is None:
        assert job['stage_complete'] is None
        assert job['failure_phase']['code']=='SHARED_COMPILER_NATIVE_SETUP_DEADLINE'
        assert job['shared_setup_seconds'] is None
        arms={}
    else:
        assert job['stage_complete'] is True and job['failure_phase'] is None
        rec=s['records'][0];arms={a['id']:a for a in rec['arms']}
        assert job['shared_setup_seconds']==rec['shared_setup_seconds']
    for pos,mid in enumerate(checked['method_order']):
        row=data['slots'][slot_index];slot_index+=1
        assert row['stage_id']==cid and row['case_id']==checked['case_id'] and row['seed']==checked['seed']
        assert row['method']==mid and row['order_position']==pos+1
        check_admission(row['admission'],cid)
        methods[mid]['planned']+=1
        if s is None:
            assert row['returned'] is row['admitted_proof'] is False
            assert row['execution_status']=='NOT_RUN_SHARED_SETUP_FAILED'
            assert all(row[k] is None for k in ('search_status','proof_status','native_proof_observed','metrics',
                'attempt_unit','search_seconds','full_arm_seconds','proof_view_index','domain_audits','trace_joins','shared_setup_seconds'))
            assert row['failure_phase']==job['failure_phase']
            methods[mid]['missing_returned_searches']+=1;counts['unavailable']+=1
            continue
        arm=arms[mid];search=arm['search'];pc=arm['proof_check']
        assert row['returned'] is True and row['execution_status']==arm['execution_status']=='SEARCH_RETURNED'
        assert row['search_status']==search['status'] and row['proof_status']==pc['status']
        assert row['native_proof_observed'] is row['admitted_proof'] is pc['native_proof_accepted']
        assert row['metrics']==search['metrics'] and row['attempt_unit']==search['attempt_unit']
        assert row['search_seconds']==search['seconds'] and row['full_arm_seconds']==arm['full_arm_seconds']
        assert row['domain_audits']==len(search.get('domain_audits',[]))
        assert row['shared_setup_seconds']==rec['shared_setup_seconds'] and row['failure_phase'] is None
        methods[mid]['returned']+=1;methods[mid]['whole_admitted_searches']+=1;counts['returned']+=1
        if pc['native_proof_accepted']:
            methods[mid]['admitted_proofs']+=1;methods[mid]['raw_native_accepted']+=1;counts['accepted']+=1
        else:
            methods[mid]['returned_search_unknown']+=1;counts['UNKNOWN']+=1
        if mid=='S0':assert row['trace_joins'] is None
        else:
            check_trace(row['trace_joins'],search,cid,mid)
            for k in ('returned_pool_packets','selected_packets','preferred_placement_events'):
                name={'selected_packets':'selected_packet_count','preferred_placement_events':'preferred_placement_count'}.get(k,k)
                methods[mid][k]+=row['trace_joins'][name]
        if search['proof'] is None:assert row['proof_view_index'] is None
        else:
            assert row['proof_view_index']==len(expected_views)
            source='scientific_result.records[0].arms[%d]'%rec['arms'].index(arm)
            expected_views.append((cid,source,mid,rec,search,pc))
assert counts==dict(returned=56,accepted=50,UNKNOWN=6,unavailable=8)
for summary in data['method_summary']:
    mid=summary['method']
    assert {k:v for k,v in summary.items() if k!='method'}=={k:methods[mid][k] for k in summary if k!='method'}

assert len(expected_views)==len(data['proofs'])==52
row_count=card_count=word_count=aux_count=0
for pi,(view,(cid,path,mid,rec,search,pc)) in enumerate(zip(data['proofs'],expected_views)):
    assert view['source']==dict(stage_id=cid,path=path)
    assert view['method']==mid and view['proof']==search['proof'] and view['proof_check']==pc
    assert view['spec']==rec['spec'] and view['target']==rec['spec']['target']
    assert view['admitted_proof'] is True and view['scope']=='WHOLE-ADMITTED PRIMITIVE PROOF'
    assert view['word_terminator']==rec['model']['word_terminator']==256
    assert len(view['tiles'])==2*len(view['proof'])
    model=rec['model'];lookup={tuple(p['key']):p for p in model['placements']}
    aux=[];overlay={}
    if mid not in ('S0','DONOR'):
        for cert in rec['marking']['markings']['certificates']:
            a=cert['auxiliary']
            aux.append(dict(point=a['point'],value=a['initial_value'],excluded_placement=a['placement'],
                excluded_placement_value=a['placement_value'],certificate_id=cert['id'],
                exhausted_root=cert['exhausted_root'],support_witness_count=len(cert['all_candidates'])))
            overlay.setdefault(tuple(a['placement']),[]).append([a['point'],a['placement_value']])
    assert view['fixed_auxiliary_initial']==aux;aux_count+=len(aux)
    word_ids=set()
    for tile,key in zip(view['tiles'],search['placements']):
        key=tuple(key);original=lookup[key];expected=copy.deepcopy(original)
        expected['auxiliary_overlay']=overlay.get(key,[])
        if expected['auxiliary_overlay']:
            marks={tuple(p):v for p,v in expected['marks']}
            for point,v in expected['auxiliary_overlay']:
                point=tuple(point);assert point not in marks or marks[point]==v;marks[point]=v
            expected['marks']=[[list(p),v] for p,v in sorted(marks.items())]
        assert tile==expected
        slot,choice=tile['command_reference'];assert model['domains'][slot][choice]==view['proof'][slot]
        for point,val in tile['marks']:
            if point[1]==100:word_ids.add(val)
        card_count+=1
    assert set(view['words'])=={str(i) for i in word_ids}
    for word_id in word_ids:
        raw=model['word_dictionary'][word_id];wv=view['words'][str(word_id)]
        assert wv==dict(hex=raw,literal=json.loads(bytes.fromhex(raw).decode('utf8')))
    row_count+=len(view['proof']);word_count+=len(word_ids)
assert row_count==486 and card_count==972
assert data['families']==[dict(paired_unit_id=a['paired_unit_id'],atom=a,principal=b) for a,b in zip(acq['libraries']['atom'],acq['libraries']['principal'])]
costs=data['cost_samples'];assert costs['unique_stage_count']==len(costs['unique_job_samples'])==17
assert [v['stage_id'] for v in costs['unique_job_samples']]==['acquire-0']+[v['stage_id'] for v in actual['cases']]
for sample in costs['unique_job_samples']:
    obs_p=D/'actual'/(sample['stage_id']+'.observer')/'observer.json';obs=load(obs_p)
    assert sample['observer']==pin(obs_p)
    assert sample['elapsed_seconds']==obs['elapsed_seconds']
    assert sample['final_observer_gate_seconds']==obs['final_observer_gate_seconds']
    assert sample['whole_peak_bytes']==obs['final_conservative_whole_peak_bytes']
assert costs['acquisition_observer_seconds']==costs['unique_job_samples'][0]['elapsed_seconds']
assert costs['evaluation_observer_seconds']==sum(v['elapsed_seconds'] for v in costs['unique_job_samples'][1:])
assert costs['total_observer_seconds']==sum(v['elapsed_seconds'] for v in costs['unique_job_samples'])
assert 'small local point-placement improvement' in data['summary']
assert any('not eight proof rejections' in text for text in data['assessment'])
assert any('not RL training' in text for text in data['assessment'])
assert any('no principal-versus-atom target-coverage gain' in text for text in data['assessment'])

review=dict(schema='D17-independent-complete-reader-projection-review-v1',reviewer_identity='/root/recovered_batch_review',
    review_passed=True,data=pin(data_p),HTML=pin(html_p),Source_review=pin(source_reviewp),actual_review=pin(actual_reviewp),
    admission_output_review=pin(admission_reviewp),check_count=4,failed_checks=[],
    checks=[dict(check='All64 slots and17 job admission/custody/corpus pins',passed=True,evidence=dict(counts=dict(counts),
        planned_slots=64,whole_admitted_returned=56,failed_setup_unavailable=8,
        scope='Exact current Root receipts/result-or-failure pins, forwarded v2 plan pins and source indexes. No failed setup is displayed as UNKNOWN or theorem rejection.')),
      dict(check='Every proof, command/guard card, full word and auxiliary assignment',passed=True,evidence=dict(
        views=52,recipient_proofs=50,donors=2,primitive_rows=row_count,selected_cards=card_count,
        referenced_word_occurrences_across_views=word_count,displayed_auxiliary_initial_assignments=aux_count,
        scope='All486 rows/972cards joined to complete saved models, exact selected keys/domain commands, word IDs/fullhex/literalpayloads/terminator256 and marking overlays. No logical replay.')),
      dict(check='All projected pool/choice/preferred-placement counters and paired family owners',passed=True,evidence=dict(
        trace_summaries=trace_summaries,method_summary=data['method_summary'],paired_units=3,
        scope='Every complete projected trace join checked literally. Whole-cluster completion remains unavailable. Preferred placements may be backtracked; packet selection is not macro execution.')),
      dict(check='Current assessment and nonoverlapping cost sample ledger',passed=True,evidence=dict(
        cost_samples=costs,scope='All17 unique jobs including failures. Acquisition charged once; observer ledger samples separate from later final gates/tool clocks. Deterministic local placement observations do not establish target-coverage, GCTS/RL/SOTA or causal timing advantage.'))],
    scientific_calls=0,scientific_imports=0,helper_calls=0,projector_calls=0,scientific_replay=False,partial_files_parsed=False,
    browser_calls=0,publication_authorized=False,admission_or_seal_emitted=False,
    remaining=['Browser full52proof/all972card/MathJax/mobile behavior is Root separate QA, not confirmed by passive data review.',
        'Final archive completeness, whitelist/publication bindings and live verification remain separate publication gates.',
        'Full64slot scientific cohort remains incomplete; fourteen admitted jobs and two failed setups retain all original classifications.'],
    reviewer_author_source=pin(Path(__file__)))
out=C/'typed-passive-reader-projection-review-v1.json';assert not out.exists()
out.write_text(json.dumps(review,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(output=pin(out),review_passed=True,slots=64,proofs=52,rows=row_count,cards=card_count)))
