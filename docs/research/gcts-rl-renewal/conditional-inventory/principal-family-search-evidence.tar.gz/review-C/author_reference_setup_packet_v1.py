"""Write Source/manual metadata. Does not import or execute scientific code."""
from pathlib import Path
import ast
import hashlib
import json

C = Path(__file__).resolve().parent
D = C.parent
BASE = D.parents[1]
PREV = D.parent / 'gcts-principal-receptor-families-20261021'

def pin(path):
    path = Path(path).resolve()
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

def save(name, value):
    p = C / name
    assert not p.exists(), 'immutable packet, never overwrite'
    p.write_text(json.dumps(value, sort_keys=True, ensure_ascii=True,
                            allow_nan=False, indent=2) + '\n')
    return pin(p)

def functions(tree):
    result = {}
    for node in tree.body:
        if isinstance(node, ast.FunctionDef):
            result[node.name] = ast.dump(node, include_attributes=False)
        elif isinstance(node, ast.ClassDef):
            for method in node.body:
                if isinstance(method, ast.FunctionDef):
                    result[node.name + '.' + method.name] = ast.dump(method, include_attributes=False)
    return result

source = C / 'reference_setup_calibration_v1.py'
old = PREV / 'runtime/word_point_reference_verifier_v1.py'
new = PREV / 'root/word_point_reference_verifier_v3.py'
model = PREV / 'runtime/word_point_model_v1.py'
tree = ast.parse(source.read_bytes(), filename=str(source))
compile(tree, str(source), 'exec', dont_inherit=True)  # unused code object only
before = functions(ast.parse(old.read_bytes()))
after = functions(ast.parse(new.read_bytes()))
changed = sorted(k for k in before.keys() & after.keys() if before[k] != after[k])
added = sorted(after.keys() - before.keys())
assert changed == ['_Words.__init__', '_Words.payload', 'verify_word_reference']
assert added == ['_Words._encode', 'run_encoding_diagnostics']
masters = [BASE/'docs/basic-tiling-algorithm.md',
           D.parent/'gcts-batch-20261020/publisher/docs/basic-tiling-algorithm.md']
master_pins = [pin(p) for p in masters]
assert [x['sha256'] for x in master_pins] == [
    'c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9',
    'ca6ee206287bf18b69f88a35d30968312499567755f347a819af4cf49743e7d4']

contract = save('reference-production-contract-v1.json', dict(
    schema='D17-conditional-reference-production-contract-v1',
    reviewer_identity='/root/recovered_batch_review', source_only=True,
    scientific_calls=0, scientific_imports=0, fixtures_executed=0,
    masters_fully_reread_and_unchanged=master_pins,
    exact_sources=dict(original_reference=pin(old), production_reference=pin(new), model=pin(model),
                       independent_calibration=pin(source)),
    historical_development_evidence=dict(
        independent_encoder_Source_review=pin(PREV/'review-C/typed-word-subtree-encoding-Source-review-v3.json'),
        retained_failed_v2_review=pin(PREV/'review-C/typed-word-subtree-encoding-Source-negative-v1.json'),
        complete_D16_actual_review=pin(PREV/'review-C/typed-principal-mechanism-actual-scientific-review-v2.json'),
        scope='Historical implementation evidence only. No D16 donor, proof, library, weight, export or grant is adopted in D17.'),
    proposition=dict(
        title='Conditional canonical-byte preservation',
        formula=r'\operatorname{bytes}_{3}(v)=\operatorname{JSON}_{\mathrm{canonical}}(v)=\operatorname{bytes}_{1}(v)',
        assumptions=[
            'The actual input is fixed during the nonhostile audit. Every cached owner is retained strongly. No external mutation or callback reentrancy changes a value.',
            'The value is finite and acyclic and lies in the stdlib JSON-encodable domain, with exact list/tuple or string-key dictionary containers on the recursive path. Every used string admits the declared UTF-8 encoding.',
            'All genuine Root callbacks return normally, and the encoder completes within the actual stack, work, memory and output limits.'
        ],
        manual_argument=[
            'Use structural induction on finite container height. Scalar and fallback cases invoke the original stdlib canonical encoder directly.',
            'For exact lists and tuples, each recursively encoded child equals its canonical bytes by the induction hypothesis; the same bracket and comma concatenation yields the canonical array.',
            'For exact string-key dictionaries, both algorithms use the same string-key sorting order and stdlib key escaping. Child-byte equality plus the same colon/comma/braces yields the same canonical object.',
            'A reused cache entry retains the exact owner and bytes from a previously completed encoding. Under fixed-input assumptions this preserves the same proposition and prevents identity recycling.',
            'The active set rejects cycles, and finally cleanup runs on any nested fault. Explicit append loops avoid callback StopIteration rewriting through generator evaluation.'
        ],
        limits=[
            'This manual argument is conditional Source reasoning, not a mechanized proof or a theorem inferred from finite tests.',
            'Recursion depth, checkpoint counts, allocation, completion status under a budget and callback/error timing can differ. No all-input totality, identical exception prefix, fit, timing or memory guarantee follows.',
            'Unsupported/malformed values keep stdlib fallback behavior where reached, but this statement does not claim equal resource-failure thresholds or ordering of all possible errors.'
        ]),
    predicate_preservation=dict(
        unchanged_qualified_function_ASTs=sorted(k for k in before.keys() & after.keys() if before[k] == after[k]),
        changed_qualified_functions=changed, added_functions=added,
        meaning='The substantive domain, attempted placement, conflict, complete dictionary, root/initial state and dependency/incidence checks remain. verify_word_reference changes its schema/storage_scope description, not the admission predicate. The _Words path changes canonical byte construction/cache reuse.',
        no_gate_waiver=True,
        all_fresh_production_models_require='Complete exact v3 verifier receipt and full literal model evidence; unchanged selected proof Host/full-region/fresh Native blocks=[] gates remain separate.'),
    current_finite_evidence=dict(
        historical_encoder_controls=40, historical_unchanged_word_controls=48,
        historical_complete_model_differentials=6,
        new_same_model_calibration_controls=1, new_control_status='UNRUN',
        inference='Finite evidence supports implementation confidence and regression detection only; it is not universal equivalence or a new logical proof rule.'),
    planned_stage_scope=dict(
        jobs=17, fresh_acquisition_jobs=1, original_D15_evaluation_cases=6,
        added_authored_positive_contrast_controls=2, orders_per_case=2,
        methods=['S0','P0','PA','PP'],
        acquisition_control='One original-v1/v3 tiny full-model differential in the fresh acquisition actual; retained as an explicit synthetic control.',
        production='Common exact v3 reference for every fresh acquired/evaluation model, shared by all compared methods. No mandatory old-v1 large-case duplicate.',
        source_plan_status='Architecture only. Exact B/L/Root composition, phase exclusions, upstream evidence and every materialized plan still require independent review.'),
    scientific_fairness_obligations=[
        'Both libraries use the same fresh atom-template class units, same order and class multiplicity; principal structural equality never silently coalesces actions.',
        'Fixed PA and PP differ only in the declared abstraction choice. No weights, learned selector, target-specific routes, new inference or candidate pruning are introduced.',
        'Primitive P0, PA and PP share the same marked model and all original point scheduler/forced/dead/earliest-generation/fallback/rollback rules and all numeric quotas.',
        'A dummy zero-weight carrier in fixed mode is not trained RL and cannot be described as policy reuse. Known Native UNKNOWN remains unadmitted; final proof gates use fresh Host/full-region/Native blocks=[].',
        'Repeated orders are counterbalanced development observations, not statistically independent samples. Preserve setup/Native/control/verification and all failed-job costs.',
        'No inherited six-case population may disappear behind the two added calibration contexts; UNKNOWN or resource failure remains explicit, with no retry, bound increase or positive-prefix adoption.'
    ],
    review_status='Conditional design and encoder Source assessment only. Author-written calibration needs independent peer review; no whole-offer, actual, fit, result or grant approval.'))

api = save('reference-setup-calibration-API-v1.json', dict(
    schema='D17-reference-setup-calibration-API-v1', source=pin(source),
    callable='run_reference_setup_control(word_module, legacy_reference, production_reference, *, check)',
    fixed_modules=dict(word_model=pin(model), original_reference=pin(old), production_reference=pin(new)),
    actual_execution='Only inside a fresh reviewed Root acquisition actual, before donor work. No import-time control or module self-execution.',
    output='One complete receipt containing full authored fixture, full model evidence, full original/production receipts, exact field omissions and unchanged-value joins.',
    omitted_fields=['schema','storage_scope'],
    exceptions='No BaseException is caught. Root and foreign callbacks propagate by original identity. Internal SetupMismatch has a private owner; public construction defaults to owner=None. Caller must not infer Root fault ownership by exception type.',
    fixture_scope='One hand-authored three-row reduction fixture with shared formula containers. Synthetic catalog/inventory status fields are structural test declarations, never claims of a Native compiler/query or acquired donor.',
    retained_obligations=['Every fresh production-model v3 full reference gate','All 48 word controls','All 40 encoder controls','Unchanged Host/full-region/fresh Native final proof checks'],
    status='SOURCE_ONLY_UNRUN', source_author_self_admission=False,
    prospective_receipt_expected=dict(complete=True,status='PASSED',control_count=1,
        original_version='aligned-complete-word-reference-verifier-v1',
        production_version='aligned-complete-word-reference-verifier-v3-subtree-json'),
    full_plan_approval=False, actual_authority=False))

bank = save('reference-setup-control-bank-v1.json', dict(
    schema='D17-reference-setup-control-bank-v1', status='UNRUN',
    controls=[dict(id='same-synthetic-model-full-v1-v3',kind='HAND_AUTHORED_REDUCTION_CONTROL',
       fixture_source=pin(source), rows=3, Native_queries=0, Host_proof_queries=0,
       required=['Same exact model owner passed to both complete verifiers',
                 'All receipt fields except schema/storage_scope strictly equal',
                 'Full fixture and model evidence unchanged after both audits',
                 'Full original and production receipts retained'])],
    fault_semantics='The bridge contains no catch/reclassification path. Existing word/encoder foreign-sentinel controls remain separate; malformed versions or unequal receipts raise privately owned SetupMismatch.',
    proof_route=False, donor=False, scientific_execution_authorized=False))

audit = save('reference-setup-static-audit-v1.json', dict(
    schema='D17-reference-setup-static-audit-v1', source=pin(source),
    AST_parsed=True, unused_compile=True, compiled_code_executed=False,
    functions=sum(isinstance(n,ast.FunctionDef) for n in ast.walk(tree)),
    imports=[ast.dump(n,include_attributes=False) for n in tree.body if isinstance(n,(ast.Import,ast.ImportFrom))],
    scientific_imports=0, scientific_calls=0, controls_executed=0,
    no_self_admission=True, scientific_status='UNRUN'))

handoff = save('reference-setup-calibration-handoff-v1.json', dict(
    schema='D17-reference-setup-calibration-Source-handoff-v1',
    author='/root/recovered_batch_review',
    source=pin(source), API=api, contract=contract, bank=bank, static_audit=audit,
    files=[pin(source),api,contract,bank,audit],
    source_only=True, component_calls=0, scientific_imports=0, scientific_calls=0,
    controls_status='UNRUN', independent_peer_review='Pending author-L review; C does not self-admit this control.',
    no_actual_or_whole_plan_authority=True, no_fit_or_speed_claim=True))
print(json.dumps(handoff))
