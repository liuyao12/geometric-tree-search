"""Independent passive materialized-plan review; no offered helper is called."""
import hashlib
import json
from pathlib import Path

D = Path(__file__).resolve().parents[1]
C = D/'review-C'
R = D/'root'
cache = {}
def pin(path):
    path = Path(path).resolve()
    if str(path) not in cache:
        body = path.read_bytes()
        cache[str(path)] = dict(path=str(path),bytes=len(body),sha256=hashlib.sha256(body).hexdigest())
    return cache[str(path)]
def load(path):
    assert '.partial' not in Path(path).name
    return json.loads(Path(path).read_text())
def verify(row):
    assert pin(row['path']) == row, row['path']
def digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
checks=[]
def passed(name,evidence):checks.append(dict(check=name,passed=True,evidence=evidence))

indexp=R/'materialized-evaluation-plans-v2.json'
familyp=R/'plan-family-v2.json'
admissionp=R/'admission/acquire-0-v1.json'
sealp=R/'seals/acquire-0-v1.json'
actualreviewp=C/'typed-fixed-principal-family-acquisition-actual-review-v1.json'
wholereviewp=C/'typed-principal-family-search-whole-prospective-Source-review-v2.json'
index=load(indexp);family=load(familyp);adm=load(admissionp);seal=load(sealp)
actualreview=load(actualreviewp);whole=load(wholereviewp)
assert pin(indexp)['sha256']=='0259790f5036e3729da0de6e175ffc7ee94b4833345b79e423798c6c2cb479d1'
assert pin(familyp)['sha256']=='e1918d701e77d700d4d85792e6283a529ccbae93b49cc969ba0a69c1bd4448ba'
assert pin(actualreviewp)['sha256']=='6b7c84960e0fa4aa39ae9c1d8110edecc706f8d78c1c219f1513ac0e1c21f652'
assert pin(wholereviewp)['sha256']=='c9949059996dd18a6ac75340e80a91eedae11f8f1df027b267dea125391fa9c5'
assert whole['review_passed'] is actualreview['review_passed'] is True
assert actualreview['resource_admitted'] is actualreview['scientific_qualified'] is True
assert pin(admissionp)==index['acquisition_admission'] and pin(sealp)==index['acquisition_seal']
assert pin(admissionp)['sha256']=='4415d38bebbce778dff1bff41138a424bb0982c3a501d4bfbf336a2f5e11bb1a'
assert pin(sealp)['sha256']=='1363cca61879513f07d8ba49efc206bea48d8ae84b86f2218ccf2ef9040a198a'
assert adm['schema']=='D17-Root-whole-admission-v1'
assert adm['C_review']==pin(actualreviewp)
assert set(seal)=={'export_sha256','header','observer','plan','prior_cost_receipts','resource_admitted',
    'result','stage','stage_complete','stage_id','terminal','whole_peak_bytes','whole_seconds'}
for obj in (adm,seal):
    assert obj['stage']=='acquire' and obj['stage_id']=='acquire-0'
    assert obj['resource_admitted'] is obj['stage_complete'] is True
    for key in ('plan','result','header','terminal','observer'):verify(obj[key])
assert adm['admitted'] is adm['scientific_qualified'] is True
assert seal['prior_cost_receipts']==[]
for key in ('plan','result'):
    assert adm[key]==seal[key]==actualreview[key]
for key in ('header','terminal','observer','whole_seconds','whole_peak_bytes'):
    assert adm[key]==seal[key]
verify(adm['passive_join'])
assert adm['passive_join']==actualreview['passive_join']
join=load(adm['passive_join']['path'])
for key in ('resource_admitted','scientific_qualified','stage_complete','candidate_admission'):
    assert join[key] is True
for key in ('plan','result','header','terminal','observer','whole_seconds','whole_peak_bytes'):
    assert join[key]==adm[key]
result=load(seal['result']['path'])
assert seal['export_sha256']==digest(result['scientific_result']['export'])==actualreview['export_sha256']==join['export_sha256']
assert seal['whole_seconds']==13.17763045799802 and seal['whole_peak_bytes']==303874048
assert adm['plan']['path']==str((R/'plans/acquire-0-v2.json').resolve())
assert adm['result']['path']==str((D/'actual/acquire-0/result.json').resolve())
passed('Fresh complete acquisition admission, independent review and exact 13-field receipt',dict(
    admission=pin(admissionp),seal=pin(sealp),C_actual_review=pin(actualreviewp),passive_join=adm['passive_join'],
    plan=seal['plan'],result=seal['result'],export_sha256=seal['export_sha256'],
    whole_seconds=seal['whole_seconds'],whole_peak_bytes=seal['whole_peak_bytes'],prior_cost_receipts=[],
    scope='Same unique fresh D17 acquisition, not a historical substitution. Complete raw result and all envelope pins rehashed; prior C actual review is reused by exact pin. No helper/sealer execution.'))

assert len(family['jobs'])==17 and len(family['common_files'])==89
assert len(index['plans'])==16 and len({p['path'] for p in index['plans']})==16
assert index['grants']==index['scientific_calls']==0
for row in family['common_files']:verify(row)
for job in family['jobs']:verify(job['plan_or_template'])
evaljobs=family['jobs'][1:]
acqplan=load(seal['plan']['path'])
local=acqplan['experiment_limits'];outer=acqplan['limits']
assert local==dict(cluster_binding_work=20000,cluster_instances=12,cluster_proposals=16,compile_queries=512,
    domain_audits=2,marking_certificates=12,marking_proposals=48,marking_work=200000,
    native_steps=1000000000,search_attempts=600,search_seconds=2.0)
assert outer==dict(custody_seconds=210,log_bytes=4194304,memory_bytes=1073741824,
    observer_fallback_seconds=225,physical_bytes=134217728,positive_seconds=180,
    reserved_outer_bytes=9437184,result_bytes=50331648,root_callbacks=400000000,work_seconds=160)
plan_rows=[];common_runtime=[]
for offered,job in zip(index['plans'],evaljobs):
    verify(offered)
    p=load(offered['path']);tp=job['plan_or_template'];t=load(tp['path'])
    assert p['case_id']==job['stage_id']==t['case_id']
    assert p['stage']==job['stage']==t['stage']=='evaluate'
    assert p['schema']=='proof-search-case-once-plan-v1'
    assert t['schema']=='proof-search-case-once-template-v1'
    assert p['template_pending_fresh_acquisition'] is False and t['template_pending_fresh_acquisition'] is True
    assert p['materialized_from']==tp
    assert p['required_upstream_ids']==t['required_upstream_ids']==['acquire-0']
    assert p['upstream_receipts']==[pin(sealp)] and t['upstream_receipts']==[]
    exceptions={'schema','template_pending_fresh_acquisition','upstream_receipts','materialized_from','files'}
    assert {k:v for k,v in p.items() if k not in exceptions}=={k:v for k,v in t.items() if k not in exceptions}
    assert p['experiment_limits']==local and p['limits']==outer
    old={v['path']:v for v in t['files']};new={v['path']:v for v in p['files']}
    assert len(old)==len(t['files'])==90 and len(new)==len(p['files'])==100
    assert all(new[k]==v for k,v in old.items())
    additions=[pin(sealp),pin(admissionp),pin(actualreviewp),adm['passive_join'],
        seal['plan'],seal['result'],seal['header'],seal['terminal'],seal['observer'],tp]
    assert {k:v for k,v in new.items() if k not in old}=={v['path']:v for v in additions}
    for row in p['files']:verify(row)
    for row in family['common_files']:assert new[row['path']]==row
    assert new[p['input_path']]['sha256']=='04fffc6e3ea0e9bbbe2ec1c2f1b251ce62ff0a527571288c96a0ccda77b6a174'
    assert p['entry_path']==acqplan['entry_path']
    assert new[p['entry_path']]['sha256']=='27222503eee9aebd01b21ed1ecf2e298bdde8d2560ab099165a3d867696b004c'
    for role in ('modules','native','python','runtime_dir','worker_path','runner_path','observer_path','protocol'):
        assert p[role]==acqplan[role]
    actual=Path(p['actual_dir'])
    assert actual==D/'actual'/p['case_id']
    assert not actual.exists() and not Path(str(actual)+'.observer').exists()
    assert not (R/'grants'/(p['case_id']+'-v1.json')).exists()
    doc=load(p['input_path'])
    prefix='eval-'; assert p['case_id'].startswith(prefix)
    case_id,seedtext=p['case_id'][len(prefix):].rsplit('-seed',1)
    seed=int(seedtext)
    cases={c['id']:c for c in doc['evaluation']}
    assert case_id in cases and seed in doc['protocol']['evaluation_seeds']
    methods=doc['protocol']['methods'];order=doc['protocol']['arm_order'][case_id][str(seed)]
    assert sorted(order)==sorted(methods)==['P0','PA','PP','S0']
    assert doc['protocol']['policy_training'] is False
    assert doc['protocol']['arm_order'][case_id]['1']==list(reversed(doc['protocol']['arm_order'][case_id]['0']))
    plan_rows.append(dict(plan=offered,template=tp,stage_id=p['case_id'],case_id=case_id,seed=seed,
        method_order=order,source_rows=100,exact_inherited_template_rows=90,added_upstream_rows=10,
        input=pin(p['input_path']),actual_dir=str(actual),actual_directory_absent=True,observer_directory_absent=True,
        grant_absent=True,acquisition_seal=pin(sealp)))
    common_runtime=[v for v in p['files'] if Path(v['path']).parent==Path(p['runtime_dir'])]
assert len(common_runtime)==38
assert len({(v['case_id'],v['seed']) for v in plan_rows})==16
assert {v['seed'] for v in plan_rows}=={0,1}
assert len({v['case_id'] for v in plan_rows})==8
assert len({v['actual_dir'] for v in plan_rows})==16
passed('All sixteen exact materializations are limited deltas of frozen templates',dict(
    index=pin(indexp),family=pin(familyp),plans=plan_rows,
    common_bodies=family['common_files'],runtime_bodies=common_runtime,
    invariant='Ninety template rows retained byte-exact; precisely ten current acquisition/review/template pins appended to each 100-row plan. Only schema, pending flag, receipt and materialized_from changed outside files.',
    whole_prospective_review=pin(wholereviewp)))

doc=load(plan_rows[0]['input']['path'])
assert len(doc['evaluation'])==8
assert len(plan_rows)*len(doc['protocol']['methods'])==64
ids=[c['id'] for c in doc['evaluation']]
expected=['eval-sharing-01','eval-sharing-02','eval-quantified-01','eval-quantified-02',
    'eval-equality-01','eval-equality-02','context-atomic-serial','context-opaque-equality']
assert ids==expected
assert [(v['case_id'],v['seed']) for v in plan_rows]==[(cid,seed) for cid in ids for seed in (0,1)]
assert doc['protocol']['methods']==['S0','P0','PA','PP']
passed('Same complete scientific population, deterministic orders, budgets and future directories',dict(
    cases=ids,seeds=[0,1],methods=doc['protocol']['methods'],planned_jobs=16,planned_method_slots=64,
    method_orders=doc['protocol']['arm_order'],experiment_limits=local,outer_limits=outer,
    protocol=acqplan['protocol'],
    future_grants_found=0,future_actual_directories_found=0,future_observer_directories_found=0,
    scientific_scope='Six unchanged original D15 cases and two declared authored contrasts. Seeds label mirrored method orders, not independent stochastic replicates. Same fixed PA/PP choice, zero dummy weights, full primitive fallback, marked P0/PA/PP and final fresh Host/full-region/Native blocks=[] gates from exact reviewed engine.'))

review=dict(schema='D17-independent-exact-sixteen-materialized-evaluation-plan-review-v1',
    reviewer_identity='/root/recovered_batch_review',review_passed=True,
    index=pin(indexp),family=pin(familyp),acquisition_admission=pin(admissionp),acquisition_seal=pin(sealp),
    acquisition_actual_review=pin(actualreviewp),whole_prospective_review=pin(wholereviewp),
    plans=[v['plan'] for v in plan_rows],plan_details=plan_rows,
    complete_unique_input_pins=sorted(cache.values(),key=lambda v:v['path']),
    checks=checks,failed_checks=[],check_count=len(checks),
    scientific_calls=0,scientific_imports=0,helper_calls=0,scientific_replay=False,
    partial_files_parsed=False,grants_issued=0,actual_execution_authorized=False,
    scope='Exact final preflight of these sixteen v2 evaluation plans. C confirms the independent review gate only; Root alone may issue separate fresh once grants after the serial idle barrier.',
    limitations=[
        'No future result, proof, resource fit, useful abstraction effect, speedup or superiority is predicted. Every planned job must preserve complete success, UNKNOWN or failure evidence under the original caps.',
        'Current acquisition costs are retained once per cold method comparison via the same exact 13-field receipt; they are not zero-cost or sixteen newly performed acquisitions. No acquisition receipt from D15/D16 is admitted.',
        'The exact scientific engine, thirty-eight runtime files and three custodians are reused by raw equality and prior independent Source reviews; this metadata review does not reexecute or duplicate scientific checks.',
        'The physical evaluation closure intentionally includes the current acquisition result and its original plan/observer/admission/reviews. Acquisition itself was completed under its separate evaluation-excluding closure.',
        'No authority for retries, altered inputs, changed bounds, unoffered plans or posthoc cohort replacement follows. All sixteen method populations are required for a complete study comparison.'
    ],reviewer_author_source=pin(Path(__file__)))
out=C/'typed-fixed-family-evaluation16-plan-review-v1.json'
assert not out.exists()
out.write_text(json.dumps(review,sort_keys=True,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(dict(output=pin(out),review_passed=True,checks=len(checks),plans=16,method_slots=64)))
