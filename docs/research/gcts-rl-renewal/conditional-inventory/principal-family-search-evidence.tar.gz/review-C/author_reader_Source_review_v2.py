"""Read/AST-only peer review of passive display Sources. No projector import/call."""
import ast
import difflib
import hashlib
import json
from pathlib import Path

D=Path(__file__).resolve().parents[1];B=D/'implementation-B';C=D/'review-C'
def pin(p):
    p=Path(p).resolve();raw=p.read_bytes()
    return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def load(p):
    assert '.partial' not in Path(p).name
    return json.loads(Path(p).read_text())
def verify(row):assert pin(row['path'])==row,row['path']

hp=B/'reader-source-handoff-v2.json';h=load(hp)
assert pin(hp)['sha256']=='7f85b9f66df470a5edf3b040cb3ddbf3d8f0d33cad1e07fd0fb8e3c4e506ce57'
pins=[]
for key in ('projector','template','API','manual','AST_delta','static_validation','actual_literal_compatibility',
            'current_narrative','retained_predecessor','science_offer_unchanged'):
    verify(h[key]);pins.append(h[key])
for row in h['patches']:verify(row);pins.append(row)
api=load(h['API']['path']);verify(api['inline_JS']);pins.append(api['inline_JS'])
prior=load(h['retained_predecessor']['path'])
verify(prior['projector']);verify(prior['template'])
source=Path(h['projector']['path']).read_text();old=Path(prior['projector']['path']).read_text()
template=Path(h['template']['path']).read_text();oldtemplate=Path(prior['template']['path']).read_text()
tree=ast.parse(source);oldtree=ast.parse(old)
assert [n.module for n in tree.body if isinstance(n,ast.ImportFrom)]==['pathlib']
assert [n.names[0].name for n in tree.body if isinstance(n,ast.Import)]==['argparse','copy','hashlib','json']
defs={n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
olddefs={n.name:n for n in oldtree.body if isinstance(n,ast.FunctionDef)}
assert set(defs)-set(olddefs)=={'failure_phase'}
changed=[name for name in olddefs if ast.dump(olddefs[name])!=ast.dump(defs[name])]
assert changed==['admission','project']
for name in ('read','optional','pin','require','key','job','point_trace','proof_view','main'):
    assert ast.dump(defs[name])==ast.dump(olddefs[name])
assert (B/'reader-projector-v1-v2-raw.patch').read_text()==''.join(difflib.unified_diff(old.splitlines(True),source.splitlines(True),fromfile='project_saved_principal_search_v1.py',tofile='project_saved_principal_search_v2.py'))
assert (B/'reader-template-v1-v2-raw.patch').read_text()==''.join(difflib.unified_diff(oldtemplate.splitlines(True),template.splitlines(True),fromfile='principal-family-search-template-v1.html',tofile='principal-family-search-template-v2.html'))
assert "with args.output.open('x') as stream:" in source
assert "if any('.partial' in part for part in path.parts):" in source
assert "row['result'] == pin(result_path)" in source
assert "for name in ('admitted','resource_admitted','scientific_qualified','stage_complete')" in source
assert 'whole_cluster_completion=None' in source and 'whole_cluster_completion_count=None' in source
assert 'NO_RETURNED_SEARCH_RECORD_JOB_FAILED_OR_INCOMPLETE' in source
assert 'NOT_RUN_SHARED_SETUP_FAILED' in source
assert "and 'in _compile_selector_case' in stack and 'in compile_guards' in stack" in source
assert "and 'in _read_line' in stack" in source
assert "require(len(slots)==64" in source
assert "all(current['executed'] and 'terminal' in current['files'] for current in all_jobs)" in source
assert 'not eight proof rejections' in source
assert "c['stage_id']=='acquire-0'" in source
assert "'inlineMath'" not in template  # established configuration uses an ordinary JS property
assert "inlineMath:[['\\\\(','\\\\)']]" in template
assert "math=x=>'\\\\('+x+'\\\\)'" in template
assert 'mathjax@3/es5/tex-svg.js' in template and 'MathJax.typesetPromise()' in template
assert 'explicit terminator' in template.lower()
assert 'not a qualified physical Wang tile system' in template
assert 'Whole-cluster completion unavailable' in template
assert 'Whole admission remains a separate gate' in source

actualp=C/'typed-fixed-family-final16-evaluation-actual-review-v1.json'
admissionreviewp=C/'typed-evaluation16-admission-output-review-v1.json'
assert load(actualp)['review_passed'] is load(admissionreviewp)['review_passed'] is True
review=dict(schema='D17-independent-passive-reader-Source-review-v2',
    reviewer_identity='/root/recovered_batch_review',review_passed=True,
    scope='Independent complete read and stdlib AST review of the exact frozen reader v2 Sources and metadata. Current nonhostile complete-data display only; not projection execution, generated-data admission or browser/publication approval.',
    handoff=pin(hp),input_pins=pins,retained_predecessor_projector=prior['projector'],retained_predecessor_template=prior['template'],
    actual_review=pin(actualp),admission_output_review=pin(admissionreviewp),
    check_count=5,failed_checks=[],checks=[
      dict(check='Pure passive Source boundary and preserved delta',passed=True,evidence=dict(
        imports=['pathlib','argparse','copy','hashlib','json'],changed_inherited_functions=changed,new_functions=['failure_phase'],
        unchanged_functions=['read','optional','pin','require','key','job','point_trace','proof_view','main'],
        raw_patches='Both exact unified patches reproduced by stdlib text comparison; predecessors remain pinned.',
        scope='No scientific module/helper/process/network/checker call. Reads exact complete named JSON; .partial paths refused. Output uses exclusive create.')),
      dict(check='Admission and whole-job-failure versus bounded UNKNOWN',passed=True,evidence=dict(
        admission='All four exact Root booleans and current result.json byte pin precede admitted proof count. Missing admission stays pending; Native or worker flags do not promote it.',
        failure='Complete failure error/stack identifies the actual compiler/Native reply deadline. Four unavailable placeholders per failed setup retain null search/proof/attempt fields. No scientific_result or hidden setup prefix is reconstructed.',
        authority='The reader consumes Root receipts already independently joined by the admission-output review; it is not a substitute admission validator for arbitrary changed inputs.')),
      dict(check='Proof rows, complete words, marking overlays and trace event scope',passed=True,evidence=dict(
        proof='Every selected key binds to saved unique placement and exact domain command at its row. Displayed final gate observations require Host, complete region, Native accepted, same primitive proof and blocks=[]. Root current result binding carries the independently checked target/theory provenance.',
        words='Selected word IDs are strict integer indexes; full saved payload hex is JSON-decoded literally, with terminator256. Only referenced words projected; full models remain in archive.',
        overlay='P0/PA/PP receive keyed auxiliary additions and initial assignments; S0/donors retain base marks. Explicit zero is shown.',
        trace='Complete pools, selected packets, literal preferred child placements and target proofs remain distinct. Rollback caveat explicit; whole-cluster completion unavailable.')),
      dict(check='Counts, comparable units, cold costs and honest interpretation',passed=True,evidence=dict(
        population='All64 planned slots,16 fixed-denominator slots per method,56 returned/50 saved accepted/6 point UNKNOWN/8 not dispatched in current actuals.',
        local='Opaque-equality PP10 versus PA/P013 placements in both deterministic orders is a narrow comparable-unit observation. Same accepted target set, no principal coverage gain. Quantified01 PA=PP23 versusP028 does not isolate principal benefit.',
        costs='Unique17 actual observer samples include acquisition once and failed jobs. Overlapping setup/search/arm/entry/observer clocks are not added; final observer gate samples retained separately. No D15/D16 causal timing comparison.',
        limits='No RL update, matched conventional principal arm, marking-off ablation, novel theorem, GCTS-specific or SOTA benefit claim.')),
      dict(check='Human-facing math and rendering Source',passed=True,evidence=dict(
        mathematics='Established MathJax3 LaTeX inline/display delimiters, correctly doubled JS delimiter escapes, formula/term/template rendering and LaTeX t/m assignments reviewed.',
        prose='Primitive-rule English distinguishes UI/equality implication axioms from direct premise application. Word-point cards explicitly avoid a physical Wang qualification claim.',
        remaining='Actual projection data joins and all proof/card/MathJax/mobile browser QA remain separate future gates; Source read alone does not confirm visual execution.'))],
    scientific_calls=0,scientific_imports=0,helper_calls=0,projector_calls=0,browser_calls=0,
    scientific_replay=False,partial_files_parsed=False,publication_authorized=False,admission_or_seal_emitted=False,
    reviewer_author_source=pin(Path(__file__)))
out=C/'typed-passive-reader-Source-review-v2.json';assert not out.exists()
out.write_text(json.dumps(review,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(output=pin(out),review_passed=True,checks=5)))
