"""Static literal/pin audit only; no offered function is imported or called."""
from pathlib import Path
import ast
import collections
import hashlib
import json

C=Path(__file__).resolve().parent
D=C.parent
L=D/'diagnostics-L'

def pin(path):
    path=Path(path).resolve(); raw=path.read_bytes()
    return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())

def read(path):
    path=Path(path); assert '.partial' not in path.name
    return json.loads(path.read_bytes())

def wire(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)

def same(a,b):
    return wire(a)==wire(b)

handoff=read(L/'handoff-v2.json')
assert pin(L/'handoff-v2.json')['sha256']=='8670b67e2ac5a18a5d7a1cc21d1aa8b1b47e04388d3d10df904205179e58df36'
for row in handoff['files']+handoff['predecessor_statements_only']+handoff['master_pins']:
    assert same(pin(row['path']),row)
acq=read(L/'acquisition-inputs-v1.json')
evaluation=read(L/'evaluation-inputs-v1.json')
protocol=read(L/'protocol-proposal-v2.json')
old_eval=read(D.parent/'gcts-learned-selector-proof-pilot-20261020/corpus-L/evaluation-inputs-v1.json')
old_mechanism=read(D.parent/'gcts-principal-receptor-families-20261021/diagnostics-L/mechanism-inputs-v1.json')
assert same(acq['donors'],old_mechanism['donors'])
assert same(evaluation['evaluation'][:6],old_eval['evaluation'])
assert same(evaluation['evaluation'][6:],[s for s in old_mechanism['contexts'] if s['id'] in ['context-atomic-serial','context-opaque-equality']])
source=L/'principal_search_corpus_contract_v1.py'
tree=ast.parse(source.read_bytes(),filename=str(source))
compile(tree,str(source),'exec',dont_inherit=True)  # unused code object only

# Read only top-level literal constant declarations. Never execute a module or
# evaluate any call, attribute, subscript, operator or function body.
constants={}
def literal(node):
    if isinstance(node,ast.Constant):return node.value
    if isinstance(node,ast.List):return [literal(x) for x in node.elts]
    if isinstance(node,ast.Tuple):return tuple(literal(x) for x in node.elts)
    if isinstance(node,ast.Dict):return {literal(k):literal(v) for k,v in zip(node.keys,node.values)}
    if isinstance(node,ast.Name) and node.id in constants:return constants[node.id]
    raise ValueError('Not a supported literal declaration')
for node in tree.body:
    if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name):
        try:constants[node.targets[0].id]=literal(node.value)
        except ValueError:pass
assert same(acq['protocol'],constants['ACQUISITION_PROTOCOL'])
assert same(evaluation['protocol'],constants['EVALUATION_PROTOCOL'])
assert tuple(s['id'] for s in acq['donors'])==constants['DONOR_IDS']
assert tuple(s['id'] for s in evaluation['evaluation'])==constants['CASE_IDS']
assert all(type(s['length']) is int and s['length']==constants['ROW_BOUNDS'][s['id']] for s in acq['donors']+evaluation['evaluation'])
bank=read(L/'corpus-control-bank-v1.json')
assert tuple(x['id'] for x in bank['controls'])==constants['CONTROL_IDS'] and len(bank['controls'])==24
assert all(x['status']=='UNRUN' for x in bank['controls'])
positions={m:[0,0,0,0] for m in constants['METHODS']}
jobs=protocol['job_recipes']; assert len(jobs)==17 and jobs[0]['stage_id']=='acquire-0'
for spec in evaluation['evaluation']:
    orders=evaluation['protocol']['arm_order'][spec['id']]
    assert orders['1']==list(reversed(orders['0']))
    for seed in [0,1]:
        order=orders[str(seed)]; assert sorted(order)==sorted(constants['METHODS'])
        row=next(j for j in jobs[1:] if j['stage_id']=='eval-'+spec['id']+'-seed'+str(seed))
        assert row['case_id']==spec['id'] and type(row['seed']) is int and row['seed']==seed and same(row['arm_order'],order)
        for i,m in enumerate(order):positions[m][i]+=1
assert all(v==[4,4,4,4] for v in positions.values())
assert same(positions,protocol['scheduling']['aggregate_position_counts'])

checks=[
 dict(id='all frozen raw corpus, Source, API and predecessor statement pins',passed=True,
      evidence='Ten current handoff bodies, both statement-only predecessors and both unchanged masters match raw hashes and sizes.'),
 dict(id='exact full population and original literal statement preservation',passed=True,
      evidence='Both D16 donor specs, all six complete D15 evaluation specs and the two complete positive D16 contrast specs match value-exactly. No proof, family or old export is present.'),
 dict(id='strict statement-only grammar, licensing and bounded closedness',passed=True,
      evidence='Full Source read: exact document/spec/theory fields, exact int bounds/arity, declared symbol arity, binder-scoped variables and closed axioms/targets; depth64 and arity0..2 explicitly scoped to these inputs. It is a format guard, not the Host/Native kernel.'),
 dict(id='complete 24 prospective format and fault controls',passed=True,
      evidence='Two positives, eighteen owned malformed refusals and four exact foreign sentinel identities. Predicate-arity mutation changes used donor X. Synthetic evaluation carriers use only acquisition syntax, never actual evaluation formulas. Catching is restricted to exact private CorpusFormatError ownership.'),
 dict(id='fixed 17 jobs, 64 search slots and counterbalanced order',passed=True,
      evidence=dict(acquisition_jobs=1,evaluation_jobs=16,cases=8,orders=2,methods=4,slots=64,position_counts=positions)),
 dict(id='paired factor, common marked model and full fallback requirements',passed=True,
      evidence='PA/PP use the same fresh atom-class order/multiplicity and fixed selector; principal coalescence forbidden. Same complete marked point model for P0/PA/PP, all original graph/marking/quotas/final proof gates. No RL, fresh target-dependent route, new inference or filter.'),
 dict(id='physical phase separation and future exact plan gate',passed=True,
      evidence='Acquisition Source/constants have no actual evaluation formulas or file reads; controls synthesize only format carriers. Exact Root closures must additionally exclude evaluation bodies until the full fresh acquisition is independently admitted/sealed. Metadata may pin bodies, but pinning does not authorize opening them.'),
 dict(id='honest development limits and authoritative metadata',passed=True,
      evidence='Public authored cohort, two contrasts selected after D16, no blind/family-held-out or fit/benefit claim. seed0/seed1 mean mirrored deterministic order, not independent stochastic repeats. Protocol-v2 overrides the earlier manual/v1 optional-setup wording: exactly 17 jobs, no optional quantified setup job. D15 costs/results are historical, not matched causal controls.')
]
result=dict(schema='typed-principal-search-corpus-Source-review-v1',reviewer_identity='/root/recovered_batch_review',
    review_passed=True,source_only=True,scientific_calls=0,scientific_imports=0,controls_executed=0,
    partial_files_parsed=False,actual_execution_authorized=False,whole_offer_approved=False,
    handoff=pin(L/'handoff-v2.json'),input_pins=handoff['files'],predecessor_statements=handoff['predecessor_statements_only'],
    masters=handoff['master_pins'],checks=checks,failed_checks=[],
    controls_status='24 UNRUN; no runtime or scientific conformance inferred from Source.',
    remaining_barriers=['Independent exact B driver/selector/pairing/export Source review',
      'Independent peer review of C calibration module; C does not self-admit its authored setup fixture',
      'Exact Root worker/phase closure/protocol/acquisition-plan review',
      'Fresh once acquisition and complete independent result/resource/Native admission before any dependent evaluation',
      'Exact materialized evaluation plans with immutable fresh sealed library and unchanged budgets'],
    tools_scope='This packet completes the corpus Source review only; later offered Source/plan reviews remain separate.')
p=C/'typed-principal-search-corpus-Source-review-v1.json';assert not p.exists()
p.write_text(json.dumps(result,sort_keys=True,ensure_ascii=True,allow_nan=False,indent=2)+'\n')
print(json.dumps(dict(review=pin(p),review_passed=True,checks=len(checks),failed_checks=[])))
