"""Small matched Native/point proof-search pilot; Source-only until Root actual.

All logical acceptance belongs to the injected unchanged Native oracle. This
module adds a compact search record and certified redundant auxiliary m-values.
Acquired clusters only order existing primitive commands/placements. The v13
stage API adds actual reward-trained selection; v14 adds explicitly paired
atom/principal acquisition and a separate context-availability mechanism, with no physical Wang acceptance
or block command candidate. The inherited v12 entry remains unchanged and unused.
"""
import collections
import copy
import itertools
import json
import math
import time
import random
import hashlib
import learned_cluster_selector_v1 as selector
import selector_corpus_contract_v1 as corpus_reference
import selector_numeric_controls_v1 as numeric_reference
import word_point_model_v1 as word_points
import word_point_reference_verifier_v1 as reference_v1
import word_point_reference_verifier_v3 as reference
import graph_copy_reference_v1 as graph_reference
import principal_receptor_families_v1 as principal
import principal_family_reference_v1 as principal_reference
import mechanism_corpus_contract_v1 as mechanism_reference

VERSION = 'native-word-point-principal-receptor-pilot-v14'
MODULE_ROLES = ('compiler', 'model', 'points', 'symbolic', 'miner', 'host')
LIMITS = dict(search_attempts=600, search_seconds=2.0,
              compile_queries=512, native_steps=1000000000,
              marking_proposals=48, marking_certificates=12,
              marking_work=200000, cluster_instances=12,
              cluster_binding_work=20000, cluster_proposals=16,
              domain_audits=2)


def literal(value):
    return json.loads(json.dumps(value, sort_keys=True, separators=(',', ':'),
                                 ensure_ascii=False, allow_nan=False))


def word(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=False, allow_nan=False)


def need(condition, message):
    if not condition:
        raise ValueError(message)


class _Cutoff(Exception):
    pass


class _Budget:
    def __init__(self, check, limits):
        self.root_check = check
        self.end = time.perf_counter() + limits['search_seconds']
        self.limit = limits['search_attempts']
        self.attempts = 0
        self.stop = _Cutoff('owned search budget')

    def check(self):
        self.root_check()
        if time.perf_counter() >= self.end:
            raise self.stop

    def extend(self):
        self.check()
        if self.attempts >= self.limit:
            raise self.stop
        self.attempts += 1


def _request(oracle, spec, proof, check, limits, purpose, blocks=None, target=None):
    check()
    request = dict(protocol='gcts-fol-1', theory=spec['theory'],
                   blocks=[] if blocks is None else blocks,
                   proof=literal(proof), target=spec['target'] if target is None else target)
    record = oracle.request(request, limits['native_steps'], purpose)
    check()
    need(record['request'] == request and type(record['id']) is int and
         oracle.records[record['id']] is record, 'exact current Native record/request')
    return record


def _tuple_ast(value):
    if type(value) is list:
        return tuple(_tuple_ast(x) for x in value)
    if type(value) is dict:
        return {k: _tuple_ast(v) for k, v in value.items()}
    return value


def host_check(spec, proof, target, host, check):
    check()
    need(all(c['rule'] not in ('block', 'assumption') for c in proof), 'flat primitive Host certificate')
    kernel = host.Kernel(spec['theory']['functions'], spec['theory']['predicates'],
                         {k: _tuple_ast(v) for k, v in spec['theory']['axioms'].items()})
    accepted = kernel.check(_tuple_ast(proof), _tuple_ast(target))
    check()
    return dict(accepted=accepted, rows=len(proof), target=literal(target),
                scope='independent flat Host Kernel; syntax helpers also used by compiler; exact case theory, no extra premises')


def _empty_inventory():
    return dict(status='native_accepted', definitions=[], interfaces=[], native_blocks=[])


def _root_of(model, key):
    occupancy = model.placement(key).occupancy
    need(len(occupancy) == 1 and occupancy[0][1] == 12, 'pilot unit-center adapter')
    return occupancy[0][0]


def _reason(model, state, key, owners=None):
    """Independent literal local witness, never a candidate shortlist."""
    c = model.placement(key)
    if key in state.selected:
        return dict(kind='already_selected', key=key)
    for point, value in c.occupancy:
        if state.allowed_points is not None and point not in state.allowed_points:
            return dict(kind='outside_target', point=point)
        if state.totals.get(point, 0) + value > 12:
            return dict(kind='capacity', point=point, candidate_value=value,
                        assigned_value=state.totals.get(point, 0))
    for point, value in c.marks:
        if point in state.marks and state.marks[point] != value:
            return dict(kind='marking', point=point, candidate_value=value,
                        assigned_value=state.marks[point],
                        assigned_owner=None if owners is None else owners.get(point))
    return None


def audit_domains(model, state, graph, check):
    """Complete independent original-domain census at this actual state."""
    expected = {}
    for point in sorted(state.frontier()):
        check()
        expected[point] = set()
        for key in model.alignments(point):
            check()
            if _reason(model, state, key) is None:
                expected[point].add(key)
    need(expected == graph.domains, 'independent full point-domain comparison')
    edges = collections.defaultdict(set)
    for point, keys in expected.items():
        for key in keys:
            check()
            edges[key].add(point)
    need(dict(edges) == graph.edges, 'independent complete inverse incidence')
    dead = sorted(p for p, keys in expected.items() if not keys)
    forced = sorted(p for p, keys in expected.items() if len(keys) == 1)
    if dead:
        decision = ('dead', dead[0], [])
    elif forced:
        p = forced[0]; decision = ('forced', p, sorted(expected[p]))
    elif not expected:
        decision = ('empty', None, [])
    else:
        p = min(expected, key=lambda q: (state.generations.get(q, state.roots.get(q, 0)),
                                        len(expected[q]), q))
        decision = ('branch', p, sorted(expected[p]))
    need(decision == graph.decision(state), 'global DEAD/FORCED/generation scheduler')
    return dict(frontier_points=len(expected), incidences=sum(map(len, expected.values())),
                decision=decision, complete=True)


def verify_region(model, placements, proof, check):
    """Whole t/m and decoded word verification independent of State/Graph."""
    initial = model.initial(); totals = dict(initial.totals); marks = dict(initial.marks)
    seen = set()
    for key in placements:
        check(); need(key not in seen and key in model.cache, 'distinct actual placement')
        seen.add(key); c = model.placement(key)
        for p, v in c.occupancy:
            totals[p] = totals.get(p, 0) + v
        for p, v in c.marks:
            need(p not in marks or marks[p] == v, 'whole exact m-value agreement')
            marks[p] = v
    need(set(totals) == set(model.align_cache) and all(v == 12 for v in totals.values()),
         'whole target exact t-value capacity')
    decoded = model.decode(placements)
    need(decoded == proof and all(c['rule'] != 'block' for c in decoded),
         'whole decoded primitive word')
    return dict(complete=True, required_points=len(totals), selected_placements=len(seen),
                mark_points=len(marks), decoded_rows=len(decoded))


def compile_markings(model, check, limits):
    """Discover unary failed extensions; certify a full mandatory support domain.

    A certificate is sound because any completion containing the trial candidate
    must fill the exhibited unfilled root, yet every original root candidate has
    a literal t/m conflict already forced by that trial. No partial scan licenses
    a marking. Trials and certificates are bounded proposals, never search pruning.
    """
    result = dict(schema='certified-unary-point-failures-v1', proposals=[],
                  certificates=[], work=0, complete_proposal_prefix=True,
                  stopped=None, soundness='full original mandatory-root support exhaustion')
    for key in sorted(model.cache):
        check()
        if len(result['proposals']) >= limits['marking_proposals']:
            result['stopped'] = 'proposal_limit'; break
        if len(result['certificates']) >= limits['marking_certificates']:
            result['stopped'] = 'certificate_limit'; break
        state = model.initial()
        if _reason(model, state, key) is not None:
            continue
        trial = dict(key=key, status='NO_CERTIFICATE', tested_roots=[])
        result['proposals'].append(trial)
        owners = {p: 'initial' for p in state.marks}
        state.place(model.placement(key))
        for p, unused in model.placement(key).marks:
            owners[p] = key
        for root in sorted(state.frontier()):
            check(); witnesses = []; supported = False
            for candidate in model.alignments(root):
                check()
                if result['work'] >= limits['marking_work']:
                    trial['status'] = 'INCOMPLETE_SCAN'
                    result['complete_proposal_prefix'] = False
                    result['stopped'] = 'work_limit'
                    return result
                result['work'] += 1
                why = _reason(model, state, candidate, owners)
                if why is None:
                    supported = True; break
                witnesses.append(dict(key=candidate, witness=why))
            trial['tested_roots'].append(dict(root=root, supported=supported,
                                              tested_candidates=len(witnesses) + int(supported)))
            if not supported:
                ordinal = len(result['certificates']); point = (-100, ordinal)
                certificate = dict(id=ordinal, trial=[key], exhausted_root=root,
                                   all_candidates=witnesses,
                                   auxiliary=dict(point=point, initial_value=1,
                                                  placement=key, placement_value=0))
                result['certificates'].append(certificate)
                trial.update(status='CERTIFIED', certificate=ordinal)
                break
    return result


def verify_markings(model, packet, check):
    """Recheck every whole root and exact witness using the unmarked base model."""
    seen = set()
    for ordinal, certificate in enumerate(packet['certificates']):
        check(); key, = certificate['trial']; state = model.initial()
        need(certificate['id'] == ordinal and key not in seen, 'marking certificate order')
        seen.add(key); need(_reason(model, state, key) is None, 'legal trial')
        owners = {p: 'initial' for p in state.marks}
        state.place(model.placement(key))
        owners.update({p: key for p, unused in model.placement(key).marks})
        root = certificate['exhausted_root']; need(root in state.frontier(), 'mandatory unfilled root')
        expected = []
        for candidate in model.alignments(root):
            check(); why = _reason(model, state, candidate, owners)
            need(why is not None, 'every original root candidate must conflict')
            expected.append(dict(key=candidate, witness=why))
        need(expected == certificate['all_candidates'], 'complete literal support certificate')
        need(certificate['auxiliary'] == dict(point=(-100, ordinal), initial_value=1,
             placement=key, placement_value=0), 'exact redundant unary auxiliary marking')
    return dict(complete=True, certificates=len(seen), authority='finite point-support theorem only')


_MarkedModel = word_points.MarkedModel


def _same_wire(wire, actual, check):
    """Strict JSON carrier equality; declared tuple sequences decode as arrays."""
    pending = [(wire, actual)]
    while pending:
        check(); left, right = pending.pop()
        if type(right) in (tuple, list):
            if type(left) is not list or len(left) != len(right):
                return False
            pending.extend(zip(left, right))
        elif type(right) is dict:
            if type(left) is not dict or set(left) != set(right):
                return False
            pending.extend((left[k], right[k]) for k in right)
        elif type(left) is not type(right) or left != right:
            return False
    return True


def indexed_model(model, check):
    return word_points.evidence_view(model, check)


def verify_indexed_model(packet, model, check):
    return word_points.verify_evidence(packet, model, check)


def _essential(proof, check):
    """Extract actual final-assertion ancestry, preserving primitive references."""
    needed = set(); pending = [len(proof) - 1]
    while pending:
        check(); index = pending.pop()
        if index in needed:
            continue
        need(0 <= index < len(proof), 'actual donor ancestry reference')
        needed.add(index); c = proof[index]
        refs = ([c['antecedent'], c['implication']] if c['rule'] == 'mp'
                else [c['source']] if c['rule'] == 'generalize' else [])
        need(all(type(r) is int and 0 <= r < index for r in refs), 'strict-prior donor references')
        pending.extend(refs)
    mapping = {old: new for new, old in enumerate(sorted(needed))}; output = []
    for old in sorted(needed):
        check(); c = copy.deepcopy(proof[old])
        if c['rule'] == 'mp':
            c['antecedent'] = mapping[c['antecedent']]; c['implication'] = mapping[c['implication']]
        elif c['rule'] == 'generalize':
            c['source'] = mapping[c['source']]
        need(c['rule'] != 'block', 'primitive essential donor')
        output.append(c)
    return output, sorted(needed)


def _ground_clusters(library, compiled, spec, miner, oracle, check, limits):
    """Registry result stays explicit; primitive ordering does not admit blocks."""
    basis = [spec['target']] + [f for f in compiled['basis'] if f != spec['target']]
    instances = []; seen = set(); work = 0
    for family in library:
        interface = [family['template']['conclusion']] + family['template']['premises']
        family_start = len(instances)
        family_quota = max(1, limits['cluster_instances'] // max(1, len(library)))
        def visit(index, binding):
            nonlocal work
            check()
            if (work >= limits['cluster_binding_work'] or len(instances) >= limits['cluster_instances'] or
                    len(instances) - family_start >= family_quota):
                return
            if index == len(interface):
                if len(binding) != family['parameters']:
                    return
                args = [binding[j] for j in range(family['parameters'])]
                ground = miner.replace(family['template'], args)
                signature = word(ground)
                if signature in seen:
                    return
                seen.add(signature)
                name = 'pilot_cluster_' + str(len(instances))
                definition = dict(name=name, premises=ground['premises'],
                                  conclusion=ground['conclusion'], proof=ground['proof'])
                need(not any(c['rule'] == 'block' for c in definition['proof']), 'primitive donor only')
                instances.append(dict(id=name, family=family['id'], arguments=args,
                                      definition=definition))
                return
            for f in basis:
                check(); work += 1
                if work > limits['cluster_binding_work']:
                    return
                bound = miner.unify(interface[index], f, binding)
                if bound is not None:
                    visit(index + 1, bound)
                if (len(instances) >= limits['cluster_instances'] or
                        len(instances) - family_start >= family_quota):
                    return
        visit(0, {})
    taut = ['imp', ['bot'], ['bot']]
    q = _request(oracle, spec, [dict(rule='tautology', formula=taut)], check, limits,
                 'pilot_ground_cluster_admission', blocks=[i['definition'] for i in instances], target=taut)
    native_status = q['result']['status']
    need(type(native_status) is str and native_status in
         ('accepted', 'rejected', 'unknown_step_budget', 'unknown_space_budget'),
         'unrecognized Native ground admission status')
    need(native_status != 'rejected', 'Native rejected actual ground cluster acquisition')
    accepted = native_status == 'accepted'
    return dict(instances=instances, admission_query=q['id'], native_status=native_status, status='native_accepted' if accepted else 'unknown_cluster_admission',
                registry_native_admitted=accepted, ordering_hints_enabled=True,
                usage='CONTEXT_CHECKED_PRIMITIVE_ORDERING_ONLY',
                usable=instances if accepted else [], ordering_instances=instances, binding_work=work,
                proposal_coverage='bounded context-checked primitive ordering proposals only; no registry inference or candidate removal')


def _expand(instance, prefix, spec, host, check):
    """Resolve learned assumption receptors to actual earlier rows or named axioms."""
    definition = instance['definition']
    if any(c['formula'] == definition['conclusion'] for c in prefix):
        return None
    proof = copy.deepcopy(prefix); expansion = []; remap = {}
    for index, original in enumerate(definition['proof']):
        check(); c = copy.deepcopy(original)
        if c['rule'] == 'assumption':
            port = c['index']
            need(0 <= port < len(definition['premises']) and c['formula'] == definition['premises'][port],
                 'actual learned premise receptor')
            sources = [j for j, old in enumerate(proof) if old['formula'] == c['formula']]
            if sources:
                remap[index] = sources[0]; continue
            names = [n for n, f in sorted(spec['theory']['axioms'].items()) if f == c['formula']]
            if not names:
                return None
            c = dict(rule='axiom', formula=c['formula'], name=names[0])
        elif c['rule'] == 'mp':
            c['antecedent'] = remap[c['antecedent']]; c['implication'] = remap[c['implication']]
        elif c['rule'] == 'generalize':
            c['source'] = remap[c['source']]
        need(c['rule'] != 'block', 'no block primitive expansion')
        remap[index] = len(proof); proof.append(c); expansion.append(c)
    if not expansion or len(proof) > spec['length']:
        return None
    host_receipt = host_check(spec, proof, definition['conclusion'], host, check)
    if not host_receipt['accepted']:
        return None
    return dict(instance=instance['id'], prefix_rows=len(prefix), commands=expansion,
                result_formula=definition['conclusion'], host_check=host_receipt,
                checked_primitive_proof=proof)


def _prefix(model, state):
    by_role = {(k[0], k[1]): k for k in state.selected}; prefix = []
    for row in range(model.spec['length']):
        if (row, 0) not in by_role or (row, 1) not in by_role:
            break
        a = model.metadata[by_role[row, 0]]['command']; b = model.metadata[by_role[row, 1]]['command']
        if a != b:
            break
        prefix.append(a)
    return prefix


def _keys_for_commands(model, prefix_count, commands, check):
    keys = []
    basis_index = {word(f): j for j, f in enumerate(model.compiled['basis'])}
    for offset, c in enumerate(commands):
        check(); row = prefix_count + offset
        if row >= model.spec['length']:
            return None
        matches = [k for k, item in enumerate(model.domains[row]) if item == c]
        if len(matches) != 1:
            return None
        k = matches[0]
        guards = [key for key in model.alignments((4 * row, 1)) if key[2] == k]
        if c['rule'] == 'mp':
            # The command carries references; its actual antecedent implication
            # is selected by the guard's existing literal variant, never invented.
            pass
        if not guards:
            return None
        # Keep all guard variants as separate cluster proposals in caller.
        keys.append(((row, 0, k, 0), guards))
    return keys


def _point_hint(model, state, graph, point, instances, host, check, limits):
    prefix = _prefix(model, state); proposals = []
    for instance in instances:
        check()
        if len(proposals) >= limits['cluster_proposals']:
            break
        expansion = _expand(instance, prefix, model.spec, host, check)
        if expansion is None:
            continue
        skeleton = _keys_for_commands(model, len(prefix), expansion['commands'], check)
        if skeleton is None:
            continue
        # All compatible primitive guard variants are eligible proposals. A
        # bounded proposer can abstain; search still keeps every primitive key.
        for variants in itertools.product(*(guards for command, guards in skeleton)):
            check()
            members = [key for (command, unused), guard in zip(skeleton, variants) for key in (command, guard)]
            trial = state.copy(); valid = True
            for key in members:
                check()
                if key in trial.selected:
                    continue
                if _reason(model, trial, key) is not None:
                    valid = False; break
                trial.place(model.placement(key))
            if not valid:
                continue
            pending = [k for k in members if k not in state.selected]
            if not any(k in graph.domains[point] for k in pending):
                continue
            packet = dict(expansion, members=members, pending=pending)
            proposals.append(packet)
            if len(proposals) >= limits['cluster_proposals']:
                break
    return proposals


def _aux_removals(model, state, before, after, check):
    witnesses = []
    for point, keys in sorted(before.items()):
        for key in sorted(keys - after.get(point, set())):
            check()
            c = model.placement(key)
            for p, value in c.marks:
                if p[0] == -100 and p in state.marks and state.marks[p] != value:
                    witnesses.append(dict(frontier_point=point, candidate=key, auxiliary_point=p,
                                          channel='certified-failure', candidate_value=value,
                                          assigned_value=state.marks[p], assigned_owner='initial'))
                    break
    return witnesses


def search_points(model, instances, enabled, modules, check, limits):
    points = modules['points']; began = time.perf_counter(); budget = _Budget(check, limits)
    initial = model.initial(); graph = points.Graph(model, initial)
    state_pre = copy.deepcopy(initial.__dict__)
    graph_pre = graph.fingerprint(); trace = []; audits = []; metrics = collections.Counter(); found = None
    def visit(state, g, hint):
        nonlocal found
        budget.check(); kind, point, keys = g.decision(state); metrics['nodes'] += 1
        if len(audits) < limits['domain_audits']:
            audits.append(audit_domains(model, state, g, budget.check))
        node = len(trace); trace.append(dict(event='decision', ordinal=node, kind=kind, point=point,
                                             original_alternatives=keys))
        if kind == 'dead':
            metrics['dead'] += 1; return False
        if kind == 'empty':
            found = state; return True
        metrics[kind] += 1; preferred = []
        if hint is not None:
            pending = [k for k in hint['pending'] if k not in state.selected]
            if not pending or any(_reason(model, state, k) is not None for k in pending):
                hint = None
            else:
                preferred = [k for k in pending if k in g.domains[point]]
        if kind == 'branch' and hint is None and enabled:
            proposals = _point_hint(model, state, g, point, instances, modules['host'], budget.check, limits)
            trace.append(dict(event='cluster_proposals', decision=node, proposals=proposals))
            metrics['cluster_proposals'] += len(proposals)
            if proposals:
                hint = proposals[0]; preferred = [k for k in hint['pending'] if k in g.domains[point]]
                metrics['cluster_hints'] += 1
        if kind == 'forced':
            alternatives = keys
        else:
            completed_formulas = [c['formula'] for c in _prefix(model, state)]
            tiers = ([], [], [], [])
            for key in keys:
                budget.check()
                formula = model.metadata[key]['command']['formula']
                repeated = any(formula == prior for prior in completed_formulas)
                tier = (2 if repeated else 0) + (0 if key in preferred else 1)
                tiers[tier].append(key)
            alternatives = [key for tier in tiers for key in tier]
            budget.check()
        need(sorted(alternatives) == sorted(keys), 'complete primitive fallback/multiplicity')
        trace.append(dict(event='order', decision=node, alternatives=alternatives, preferred=preferred))
        for key in alternatives:
            budget.extend(); metrics['attempts'] += 1
            child = state.copy(); cg = g.copy(); changed = child.place(model.placement(key))
            # Parent domains remain unchanged; only the copied child graph is updated.
            before = g.domains
            cg.update(model, child, changed)
            removed = _aux_removals(model, child, before, cg.domains, check)
            trace.append(dict(event='place', decision=node, key=key, generation=child.tile_generations[-1],
                              auxiliary_removals=removed))
            metrics['auxiliary_removed_incidences'] += len(removed)
            ok = visit(child, cg, hint)
            trace.append(dict(event='return', decision=node, key=key, result=ok))
            if ok:
                return True
            metrics['backtracks'] += 1
        return False
    status = 'unknown_search_budget'
    try:
        complete = visit(initial, graph, None)
        status = 'point_proof_candidate' if complete else 'exhausted_finite_point_region'
    except _Cutoff as error:
        if error is not budget.stop:
            raise
        trace.append(dict(event='cutoff', attempts=budget.attempts))
        budget.stop.__traceback__ = None
    need(state_pre == initial.__dict__ and
         graph_pre == graph.fingerprint(), 'exact original point state/graph rollback')
    placements = [] if found is None else found.order
    proof = None if found is None else model.decode(placements)
    # Initial m eliminations are present before the first Graph update event.
    initial_aux = []
    for p in sorted(initial.frontier()):
        for key in model.alignments(p):
            check(); why = _reason(model, initial, key)
            if why and why['kind'] == 'marking' and why['point'][0] == -100:
                initial_aux.append(dict(frontier_point=p, candidate=key, auxiliary_point=why['point'],
                                        channel='certified-failure', candidate_value=why['candidate_value'],
                                        assigned_value=why['assigned_value'], assigned_owner='initial'))
    metrics['initial_auxiliary_removed_incidences'] = len(initial_aux)
    metrics['auxiliary_removed_incidences_total'] = metrics['auxiliary_removed_incidences'] + len(initial_aux)
    return dict(status=status, proof=proof, placements=placements, trace=trace, metrics=dict(metrics),
                initial_auxiliary_removals=initial_aux, domain_audits=audits, root_restored=True,
                graph_metrics=dict(model.metrics), seconds=time.perf_counter() - began,
                attempt_unit='primitive point placement', cluster_ordering=enabled)


def search_symbolic(model, instances, enabled, modules, check, limits):
    began = time.perf_counter(); budget = _Budget(check, limits); helper = modules['symbolic']
    compiled = model.compiled; spec = model.spec
    basis_index = {helper._json(f): i for i, f in enumerate(compiled['basis'])}
    tauts = {helper._json(f) for f in compiled['tautologies']}; schemes = {helper._json(c) for c in compiled['admitted_schemes']}
    distances = {}
    path = []; selected = []; trace = []; metrics = collections.Counter(); found = None
    def visit(hint=None):
        nonlocal found
        budget.check(); row = len(path); metrics['nodes'] += 1
        if row == spec['length']:
            found = (copy.deepcopy(path), list(selected)); return True
        candidates = []
        for k, c in enumerate(model.domains[row]):
            budget.check(); metrics['skeleton_tests'] += 1
            if c['rule'] == 'axiom':
                v = 0 if spec['theory']['axioms'][c['name']] == c['formula'] else None
            else:
                v = helper._primitive_guard(c, path, basis_index, tauts, schemes)
            if v is not None:
                candidates.append((k, v, c))
        available = {word(c['formula']) for c in path}
        candidates.sort(key=lambda item: (word(item[2]['formula']) in available,
                        distances.get(helper._json(item[2]['formula']), len(distances) + 1), item[0]))
        active = hint
        if active is not None and (not active['commands'] or active['prefix_rows'] != row):
            active = None
        proposals = []
        if enabled and active is None:
            for instance in instances:
                budget.check(); item = _expand(instance, path, spec, modules['host'], budget.check)
                if item is not None and any(c == item['commands'][0] for k, v, c in candidates):
                    proposals.append(item)
                if len(proposals) >= limits['cluster_proposals']:
                    break
            active = proposals[0] if proposals else None
            metrics['cluster_proposals'] += len(proposals)
        preferred = active['commands'][0] if active is not None else None
        ordered = [item for item in candidates if item[2] == preferred] + [item for item in candidates if item[2] != preferred]
        need(len(ordered) == len(candidates), 'symbolic complete primitive fallback')
        ordinal = len(trace); trace.append(dict(event='decision', row=row,
            original_candidates=[[k, v] for k, v, c in candidates],
            ordered_candidates=[[k, v] for k, v, c in ordered], proposals=proposals))
        for k, v, c in ordered:
            budget.extend(); metrics['attempts'] += 1
            trace.append(dict(event='extend', decision=ordinal, skeleton=k, variant=v))
            path.append(c); selected.extend([(row, 0, k, 0), (row, 1, k, v)])
            child_hint = None
            if active is not None and c == preferred:
                child_hint = dict(active, prefix_rows=row + 1, commands=active['commands'][1:])
            try:
                if visit(child_hint):
                    trace.append(dict(event='return', decision=ordinal, skeleton=k, result=True)); return True
                trace.append(dict(event='return', decision=ordinal, skeleton=k, result=False)); metrics['backtracks'] += 1
            finally:
                del selected[-2:]; path.pop()
        return False
    status = 'unknown_search_budget'
    try:
        dependencies = helper._backward_distances(compiled['basis'], compiled['variables'], [], budget)
        distances = helper._distances_from_target(spec['target'], dependencies, budget)
        complete = visit()
        status = 'symbolic_proof_candidate' if complete else 'exhausted_finite_symbolic_grammar'
    except _Cutoff as error:
        if error is not budget.stop:
            raise
        trace.append(dict(event='cutoff', attempts=budget.attempts))
    need(not path and not selected, 'exact symbolic prefix rollback')
    return dict(status=status, proof=None if found is None else found[0],
                placements=[] if found is None else found[1], trace=trace,
                metrics=dict(metrics), seconds=time.perf_counter() - began,
                attempt_unit='primitive proof-row extension', root_restored=True,
                cluster_ordering=enabled, strategy='existing novelty/backward order plus optional acquired cluster')


def run_pilot(input_document, *, case_id, check, limits, modules, oracle):
    """Root owns Source/runtime custody, Native lifecycle and whole resource caps.

    This one actual constructs each model and certification afresh. Full model,
    Native records, training proofs, frozen mined library, ground admissions,
    marking certificates and ordered compact search traces are returned. The
    callback is never caught/classified as our own budget. No old qualification
    result or physical Wang gate is changed by this new experiment.
    """
    check(); need(set(modules) == set(MODULE_ROLES), 'exact injected pilot roles')
    need(limits == LIMITS, 'exact preregistered scientific limits')
    original = literal(input_document); doc = literal(input_document)
    need(doc['schema'] == 'gcts-proof-search-pilot-inputs-v1', 'pilot input schema')
    need(len(doc['training']) == 3 and len(doc['tests']) == 3, 'complete new pilot input cohort')
    selected_tests = [s for s in doc['tests'] if s['id'] == case_id]
    need(type(case_id) is str and len(selected_tests) == 1, 'exact preregistered case job')
    need(not oracle.records, 'fresh cold Native query stream for this job')
    expected_arms = [dict(id=i, engine=e, certified_markings=m, acquired_clusters=c)
        for i, e, m, c in [('S0','symbolic',False,False),('SC','symbolic',False,True),
                           ('P00','point',False,False),('P01','point',False,True),
                           ('P10','point',True,False),('P11','point',True,True)]]
    need(_same_wire(doc['arms'], expected_arms, check), 'six exact typed arm configurations')
    began = time.perf_counter(); result = dict(schema=VERSION, inputs=doc,
        limits=literal(limits), selected_case_id=case_id, job_scope='all six arms plus all three cold donors for exactly one declared case; all three jobs required for overall comparison', training=[], library=[], tests=[], scope='Native/point adaptation; no RL or physical Wang acceptance',
        resource_accepted=False, complete=False, job_record_complete=False,
        all_six_searched=False, scientific_complete=False,
        registry_native_admitted=None, ordering_hints_enabled=False, registered_inference_used=False,
        ordering_policy=dict(id='CONTEXT_CHECKED_PRIMITIVE_ORDERING_ONLY_V1',
            usage='CONTEXT_CHECKED_PRIMITIVE_ORDERING_ONLY', native_registry_required_for_ordering=False,
            supersedes_input_protocol='Native registry prerequisite only for ordering preferences; no new inference interface is admitted.'),
        completion_scope='D11 job_record_complete denotes six explicit arm records. scientific_complete denotes the ordering-only protocol, not Native registry or registered-inference qualification; Root resource/custody admission remains separate.')
    def compile_case(spec):
        check(); compiled = modules['compiler'].compile_guards(spec, oracle,
                           limit=limits['native_steps'], queries=limits['compile_queries'])
        check(); need(compiled['status'] == 'complete', 'whole Native-admitted compiler required')
        inventory = _empty_inventory()
        model = modules['model'].Model(spec, compiled, inventory, arity=0, families=False, check=check)
        reference_receipt = reference.verify_word_reference(spec, compiled, inventory, model, check=check)
        model.reference_receipt = reference_receipt
        check(); need(model.arity == 0 and not model.interfaces and
                      all(c['rule'] != 'block' for row in model.domains for c in row),
                      'same complete primitive candidate grammar')
        return compiled, model
    # Actual acquisition contains no supplied donor proof/route/library.
    training_started = time.perf_counter()
    for spec in doc['training']:
        donor_started = time.perf_counter(); check()
        stage_started = time.perf_counter(); compiled, model = compile_case(spec)
        compile_and_model_seconds = time.perf_counter() - stage_started
        stage_started = time.perf_counter()
        search = search_symbolic(model, [], False, modules, check, limits)
        search_stage_seconds = time.perf_counter() - stage_started
        entry = dict(spec=spec, compiler=compiled, domains=model.domains, reference_check=model.reference_receipt, search=search, acquired=False,
                     timings=dict(compile_and_model_seconds=compile_and_model_seconds,
                                  search_seconds=search_stage_seconds,
                                  whole_host_region_native_seconds=None,
                                  essential_extract_host_native_seconds=None, mining_seconds=None,
                                  full_donor_seconds=None))
        result['training'].append(entry)
        if search['proof'] is not None:
            stage_started = time.perf_counter()
            entry['host_check'] = host_check(spec, search['proof'], spec['target'], modules['host'], check)
            need(entry['host_check']['accepted'], 'Host rejected discovered training proof')
            entry['region'] = verify_region(model, search['placements'], search['proof'], check)
            q = _request(oracle, spec, search['proof'], check, limits, 'pilot_training_whole_primitive')
            entry['native_query'] = q['id']
            entry['timings']['whole_host_region_native_seconds'] = time.perf_counter() - stage_started
            need(q['result']['status'] != 'rejected', 'Native rejected searched training proof')
            if q['result']['status'] == 'accepted':
                stage_started = time.perf_counter()
                essential, ancestry = _essential(search['proof'], check)
                entry['essential_host_check'] = host_check(spec, essential, spec['target'], modules['host'], check)
                need(entry['essential_host_check']['accepted'], 'Host rejected extracted essential donor')
                eq = _request(oracle, spec, essential, check, limits, 'pilot_training_essential_primitive')
                entry['essential_proof'] = essential; entry['essential_ancestry'] = ancestry
                entry['essential_native_query'] = eq['id']
                entry['timings']['essential_extract_host_native_seconds'] = time.perf_counter() - stage_started
                if eq['result']['status'] != 'accepted':
                    entry['timings']['full_donor_seconds'] = time.perf_counter() - donor_started
                    result['training_and_acquisition_seconds'] = time.perf_counter() - training_started
                    result.update(status='TRAINING_INCOMPLETE', native_records=literal(oracle.records),
                                  seconds=time.perf_counter() - began)
                    return result
                need(all(c['rule'] in ('axiom', 'mp') for c in essential), 'declared training primitive rule profile')
                stage_started = time.perf_counter()
                family = modules['miner'].mine(eq['request'], [], dict(training_id=spec['id'], native_query=eq['id']))
                entry['timings']['mining_seconds'] = time.perf_counter() - stage_started
                need(not family['dependencies'], 'primitive training donor dependency')
                entry['acquired'] = True; entry['family'] = family['id']; result['library'].append(family)
        entry['timings']['full_donor_seconds'] = time.perf_counter() - donor_started
        if not entry['acquired']:
            result['training_and_acquisition_seconds'] = time.perf_counter() - training_started
            result.update(status='TRAINING_INCOMPLETE', native_records=literal(oracle.records),
                          seconds=time.perf_counter() - began)
            return result
    result['training_and_acquisition_seconds'] = time.perf_counter() - training_started
    frozen_library = literal(result['library']); result['library_frozen_before_tests'] = True
    result['diagnostics'] = run_diagnostics(modules, check, limits)
    result['word_reference_diagnostics'] = reference.run_word_reference_diagnostics(word_points, check=check)
    result['graph_storage_diagnostics'] = graph_reference.run_graph_copy_controls(modules['points'], check=check)
    for spec in selected_tests:
        setup_started = time.perf_counter(); check()
        stage_started = time.perf_counter(); compiled, model = compile_case(spec)
        compile_and_model_seconds = time.perf_counter() - stage_started
        encoding_started = time.perf_counter()
        model_record = indexed_model(model, check)
        indexed_check = verify_indexed_model(model_record, model, check)
        encoding_seconds = time.perf_counter() - encoding_started
        marking_started = time.perf_counter()
        marking = compile_markings(model, check, limits)
        certificate_check = verify_markings(model, marking, check)
        marking['compile_and_verification_seconds'] = time.perf_counter() - marking_started
        marked = _MarkedModel(model, marking, modules['points'])
        marked_extension_check = reference.verify_marked_extension(model, marked, marking, check=check)
        cluster_started = time.perf_counter()
        clusters = _ground_clusters(frozen_library, compiled, spec, modules['miner'], oracle, check, limits)
        clusters['specialization_and_admission_seconds'] = time.perf_counter() - cluster_started
        need(clusters['usage'] == 'CONTEXT_CHECKED_PRIMITIVE_ORDERING_ONLY' and
             clusters['ordering_hints_enabled'] is True and
             type(clusters['registry_native_admitted']) is bool and
             clusters['registry_native_admitted'] == (clusters['native_status'] == 'accepted') and
             clusters['native_status'] in ('accepted', 'unknown_step_budget', 'unknown_space_budget'),
             'exact ordering-only role and independent Native registry status')
        result['registry_native_admitted'] = clusters['registry_native_admitted']
        result['ordering_hints_enabled'] = True
        case = dict(spec=spec, compiler=compiled, compile_and_model_seconds=compile_and_model_seconds,
                    model=model_record, reference_check=model.reference_receipt, word_model_check=indexed_check,
                    word_model_seconds=encoding_seconds, markings=marking,
                    marking_certificate_check=certificate_check, marked_extension_check=marked_extension_check,
                    clusters=clusters, arms=[])
        result['tests'].append(case)
        case['full_shared_setup_seconds'] = time.perf_counter() - setup_started
        arm_rows = {a['id']: a for a in doc['arms']}
        arm_order = doc['protocol']['arm_order'][case_id]
        need(len(arm_order) == 6 and set(arm_order) == set(arm_rows), 'whole preregistered six-arm schedule')
        for arm_id in arm_order:
            arm_started = time.perf_counter()
            arm = arm_rows[arm_id]
            check(); symbolic = arm['engine'] == 'symbolic'
            cluster_on = arm['acquired_clusters']
            marking_on = arm['certified_markings']
            active_model = marked if marking_on else model
            active_model.metrics.clear()
            usable = clusters['ordering_instances'] if cluster_on else []
            stage_started = time.perf_counter()
            search = (search_symbolic(active_model, usable, cluster_on, modules, check, limits)
                      if symbolic else search_points(active_model, usable, cluster_on, modules, check, limits))
            search_stage_seconds = time.perf_counter() - stage_started
            entry = dict(id=arm_id, method='symbolic' if symbolic else 'point',
                         marking_enabled=marking_on, cluster_enabled=cluster_on,
                         execution_status='SEARCH_RETURNED', reason=None,
                         prerequisite=dict(required=False, admission_query=clusters['admission_query'],
                                           native_status=clusters['native_status'],
                                           registry_native_admitted=clusters['registry_native_admitted'],
                                           registry_required_for_ordering=False,
                                           context_checked_primitive_expansion_required=cluster_on,
                                           usage=clusters['usage'] if cluster_on else 'DISABLED'),
                         ordering_observations=dict(enabled=cluster_on, available_instances=len(usable),
                             successful_proposals=search['metrics'].get('cluster_proposals', 0),
                             outcome=('DISABLED' if not cluster_on else
                                      'NO_INSTANCES' if not usable else
                                      'NO_SUCCESSFUL_PROPOSAL_RECORDED' if not search['metrics'].get('cluster_proposals', 0) else
                                      'SUCCESSFUL_PROPOSALS_RECORDED'),
                             point_activated_proposal_packets=(search['metrics'].get('cluster_hints', 0)
                                 if cluster_on and not symbolic else None),
                             symbolic_activation_count=None, realized_primitive_choice_count=None,
                             scope='Existing successful proposal packets and point ordering activations only; no claim of realised cluster execution. No recorded proposal can also mean budget stopped before scanning. Symbolic activation and realised-choice counts are unavailable.'),
                         search=search, native_proof_accepted=False,
                         proof_verification_status='NO_PROOF_CANDIDATE',
                         timings=dict(search_seconds=search_stage_seconds,
                                      host_region_native_seconds=None, full_arm_seconds=None,
                                      scope='Full arm includes search, proof gates and entry preparation. Cold shared compilation/acquisition/marking/indexed output and final job serialization remain separately charged once.'))
            case['arms'].append(entry)
            if search['proof'] is not None:
                stage_started = time.perf_counter()
                entry['host_check'] = host_check(spec, search['proof'], spec['target'], modules['host'], check)
                need(entry['host_check']['accepted'], 'Host rejected discovered test proof')
                entry['region'] = verify_region(active_model, search['placements'], search['proof'], check)
                q = _request(oracle, spec, search['proof'], check, limits, 'pilot_test_' + spec['id'] + '_' + arm_id)
                entry['native_query'] = q['id']; entry['native_proof_accepted'] = q['result']['status'] == 'accepted'
                need(q['result']['status'] != 'rejected', 'whole Native rejected candidate is experiment failure')
                entry['proof_verification_status'] = ('HOST_REGION_NATIVE_ACCEPTED'
                    if entry['native_proof_accepted'] else 'HOST_REGION_ACCEPTED_NATIVE_UNKNOWN')
                entry['timings']['host_region_native_seconds'] = time.perf_counter() - stage_started
            check()
            entry['timings']['full_arm_seconds'] = time.perf_counter() - arm_started
        need(literal(result['library']) == frozen_library, 'no test-time library acquisition')
    check(); need(literal(input_document) == original, 'caller input unchanged')
    result['native_records'] = literal(oracle.records)
    arms = result['tests'][0]['arms']
    need(len(arms) == 6 and [a['id'] for a in arms] == doc['protocol']['arm_order'][case_id],
         'all six ordered explicit arm outcomes')
    result['job_record_complete'] = True
    result['all_six_searched'] = all(a['execution_status'] == 'SEARCH_RETURNED' for a in arms)
    result['scientific_complete'] = (result['all_six_searched'] and
        all(a['proof_verification_status'] != 'HOST_REGION_ACCEPTED_NATIVE_UNKNOWN' for a in arms))
    result['complete'] = result['scientific_complete']
    result['comparison_status'] = ('FULL_SIX_ARM_RECORD' if result['scientific_complete'] else
                                   'INCOMPLETE_SCIENTIFIC_COMPARISON')
    result['seconds'] = time.perf_counter() - began
    return result


def run_diagnostics(modules, check, limits):
    """Actual tiny full-domain/marking checks; no theorem or benchmark substitute."""
    check(); points = modules['points']
    class Tiny:
        def __init__(self):
            self.cache = {}; self.align_cache = {(0, 0): [], (4, 0): []}
            self.dependencies = collections.defaultdict(set); self.metadata = {}
            self.metrics = collections.Counter(); self.domains = []; self.spec = {}
            self.compiled = {}; self.inventory = {}; self.arity = 0; self.mode = {}; self.interfaces = []
            for index, root, value in [(0, (0, 0), 1), (1, (0, 0), 0),
                                        (2, (4, 0), 0), (3, (4, 0), 0)]:
                key = (index, 0, 0, 0)
                c = points.Placement(key, ((root, 12),), (((1, 50), value),), ())
                self.cache[key] = c; self.align_cache[root].append(key)
                for p, unused in c.occupancy + c.marks:
                    self.dependencies[p].add(key)
        def initial(self):
            roots = {p: 0 for p in self.align_cache}
            return points.State(generations=roots.copy(), roots=roots.copy(), allowed_points=frozenset(roots))
        def placement(self, key):
            return self.cache[key]
        def alignments(self, point):
            return self.align_cache[point]
    base = Tiny(); packet = compile_markings(base, check, limits)
    verified = verify_markings(base, packet, check)
    need(any(c['trial'] == [(0, 0, 0, 0)] for c in packet['certificates']), 'tiny failed extension is discovered')
    marked = _MarkedModel(base, packet, points)
    marked_extension_check = reference.verify_marked_extension(base, marked, packet, check=check)
    solutions = []
    audits = []
    for model in (base, marked):
        state = model.initial(); graph = points.Graph(model, state)
        audits.append(audit_domains(model, state, graph, check)); rows = []
        for a in base.alignments((0, 0)):
            for b in base.alignments((4, 0)):
                check(); trial = model.initial(); legal = True
                for key in (a, b):
                    if _reason(model, trial, key) is not None:
                        legal = False; break
                    trial.place(model.placement(key))
                if legal:
                    rows.append([a, b])
        solutions.append(rows)
        for key in sorted(model.cache):
            check()
            if _reason(model, state, key) is None:
                child = state.copy(); cg = graph.copy(); cg.update(model, child, child.place(model.placement(key)))
                audits.append(audit_domains(model, child, cg, check))
        need(not state.selected and graph.fingerprint() == points.Graph(model, model.initial()).fingerprint(),
             'tiny exact independent branch rollback')
    need(solutions[0] == solutions[1] and len(solutions[0]) == 2, 'all tiny solutions preserved by real m lane')
    malformed = copy.deepcopy(packet); malformed['certificates'][0]['all_candidates'].pop()
    rejected = False; genuine_fault = []
    def guarded_check():
        try:
            check()
        except BaseException as error:
            genuine_fault.append(error)
            raise
    try:
        verify_markings(base, malformed, guarded_check)
    except ValueError as error:
        # Only our deterministic certificate rejection is expected; Root faults
        # have distinct objects/types and must escape untouched.
        if (genuine_fault and error is genuine_fault[0]) or str(error) != 'complete literal support certificate':
            raise
        rejected = True
    need(rejected, 'missing whole-domain certificate member rejected')
    probe = points.Graph(base, base.initial())
    probe.domains[(0, 0)] = {(1, 0, 0, 0)}; probe.domains[(4, 0)] = set()
    need(probe.decision(base.initial())[0] == 'dead', 'global distant DEAD precedes forced')
    probe = points.Graph(base, base.initial()); generation_state = base.initial()
    generation_state.generations[(0, 0)] = 1
    # Synthetic decision input: earlier generation has degree3, later has2.
    # Full legal graph construction is audited separately above.
    probe.domains[(4, 0)].add((99, 0, 0, 0))
    need(probe.decision(generation_state)[1] == (4, 0), 'earliest generation precedes coordinate order')
    probe.domains[(0, 0)] = {(1, 0, 0, 0)}
    need(probe.decision(generation_state)[:2] == ('forced', (0, 0)), 'global forced precedes branch generation')
    zero_work = dict(limits, marking_work=0)
    incomplete = compile_markings(base, check, zero_work)
    need(not incomplete['certificates'] and incomplete['stopped'] == 'work_limit',
         'unknown support scan never licenses a marking')
    sentinel = RuntimeError('diagnostic external callback sentinel')
    def external():
        check(); raise sentinel
    escaped = False
    try:
        compile_markings(base, external, limits)
    except BaseException as error:
        if error is not sentinel:
            raise
        escaped = True
    need(escaped, 'exact external callback identity propagated')
    return dict(schema='pilot-actual-tiny-diagnostics-v1', status='complete',
                full_domain_audits=audits, base_solutions=solutions[0], marked_solutions=solutions[1],
                markings=packet, marking_verification=verified, marked_extension_check=marked_extension_check,
                incomplete_certificate_rejected=rejected, callback_identity_propagated=escaped,
                global_dead_forced_generation_controls=True, incomplete_support_scan=incomplete,
                scope='tiny mechanism diagnostics; real complete logical case and all arms remain required')


"""Authored v13 addition; assembled into the complete entry before freeze.

No import, constructor, checker, fixture or function is run by authoring this
fragment. The complete entry supplies the unchanged v12 primitives and modules.
"""


class _ReadyPoolLimit(Exception):
    pass


def _replace_checked(value, arguments, check):
    check()
    if type(value) is list:
        if len(value) == 2 and value[0] == 'meta':
            need(type(value[1]) is int and 0 <= value[1] < len(arguments), 'formula parameter index')
            return copy.deepcopy(arguments[value[1]])
        out = []
        for item in value:
            check(); out.append(_replace_checked(item, arguments, check))
        return out
    if type(value) is dict:
        out = {}
        for key, item in value.items():
            check(); out[key] = _replace_checked(item, arguments, check)
        return out
    need(value is None or type(value) in (str, int, bool), 'literal family template')
    return value


def _unify_checked(pattern, formula, binding, check):
    check()
    if type(pattern) is list and len(pattern) == 2 and pattern[0] == 'meta':
        parameter = pattern[1]; need(type(parameter) is int and parameter >= 0, 'parameter index')
        if parameter in binding:
            return binding if binding[parameter] == formula else None
        result = binding.copy(); result[parameter] = formula; return result
    if type(pattern) is list:
        if type(formula) is not list or len(pattern) != len(formula):
            return None
        result = binding
        for left, right in zip(pattern, formula):
            check(); result = _unify_checked(left, right, result, check)
            if result is None:
                return None
        return result
    return binding if type(pattern) is type(formula) and pattern == formula else None


def _bound_expansion(family, arguments, sources, prefix, spec, host, check):
    ground = _replace_checked(family['template'], arguments, check)
    if any(command['formula'] == ground['conclusion'] for command in prefix):
        return None, 'saturated'
    proof = copy.deepcopy(prefix); commands = []; remap = {}
    for index, old in enumerate(ground['proof']):
        check(); command = copy.deepcopy(old)
        if command['rule'] == 'assumption':
            port = command['index']
            need(type(port) is int and 0 <= port < len(sources)
                 and command['formula'] == ground['premises'][port], 'bound actual receptor')
            source = sources[port]
            if source['kind'] == 'prefix':
                row = source['row']
                need(0 <= row < len(prefix) and prefix[row]['formula'] == command['formula'],
                     'actual prefix occurrence receptor')
                remap[index] = row; continue
            need(source['kind'] == 'axiom' and
                 spec['theory']['axioms'][source['name']] == command['formula'],
                 'licensed named axiom receptor')
            command = dict(rule='axiom', name=source['name'], formula=command['formula'])
        elif command['rule'] == 'mp':
            command['antecedent'] = remap[command['antecedent']]
            command['implication'] = remap[command['implication']]
        else:
            raise ValueError('nullary primitive axiom/MP donor template only')
        remap[index] = len(proof); proof.append(command); commands.append(command)
    if not commands or len(proof) > spec['length']:
        return None, 'length_or_empty'
    checked = host_check(spec, proof, ground['conclusion'], host, check)
    if not checked['accepted']:
        return None, 'Host_refused'
    return dict(family=family['id'], arguments=arguments, source_binding=copy.deepcopy(sources),
                prefix_rows=len(prefix), commands=commands, result_formula=ground['conclusion'],
                checked_primitive_proof=proof, host_check=checked), None


def _checked_key_skeleton(model, prefix_count, commands, check):
    skeleton = []
    for offset, command in enumerate(commands):
        check(); row = prefix_count + offset
        if row >= model.spec['length']:
            return None
        matches = []
        for index, item in enumerate(model.domains[row]):
            check()
            if item == command:
                matches.append(index)
        if len(matches) != 1:
            return None
        index = matches[0]; guards = []
        for key in model.alignments((4*row, 1)):
            check()
            if key[2] == index:
                guards.append(key)
        if not guards:
            return None
        skeleton.append(((row, 0, index, 0), guards))
    return skeleton


def ready_pool(model, state, graph, point, library, host, check, limits, work_counter):
    """Complete a deterministic bounded prefix BEFORE any selector is called.

    Work/quota termination is declared bounded coverage. An external or local
    search cutoff propagates; no selector consumes its unfinished pool.
    """
    prefix = _prefix(model, state); available = []
    for row, command in enumerate(prefix):
        check(); available.append(dict(kind='prefix', row=row, formula=command['formula']))
    for name, formula in sorted(model.spec['theory']['axioms'].items()):
        check(); available.append(dict(kind='axiom', name=name, formula=formula))
    result = dict(schema='context-occurrence-ready-pool-v1', packets=[], complete=False,
                  coverage='deterministic bounded prefix, not exhaustive all bindings',
                  termination=None, validation_checks=0, inspected_bindings=0,
                  refusals=collections.Counter(), source_occurrences=copy.deepcopy(available))
    stop = _ReadyPoolLimit('owned common ready-pool work/quota guard')
    def tick():
        check()
        if result['validation_checks'] >= limits['cluster_binding_work']:
            result['termination'] = 'work_prefix'; raise stop
        result['validation_checks'] += 1
        work_counter['completed'] += 1
    def admit(family, binding, sources):
        tick(); result['inspected_bindings'] += 1
        if len(binding) != family['parameters']:
            result['refusals']['unbound_parameter_abstention'] += 1; return
        arguments = [binding[index] for index in range(family['parameters'])]
        expansion, refusal = _bound_expansion(family, arguments, sources, prefix,
                                             model.spec, host, tick)
        if refusal is not None:
            result['refusals'][refusal] += 1; return
        skeleton = _checked_key_skeleton(model, len(prefix), expansion['commands'], tick)
        if skeleton is None:
            result['refusals']['no_exact_existing_primitive_keys'] += 1; return
        for variants in itertools.product(*(guards for command, guards in skeleton)):
            tick(); members = []
            for (command, guards), guard in zip(skeleton, variants):
                tick(); members.extend((command, guard))
            trial = state.copy(); legal = True
            for key in members:
                tick()
                if key in trial.selected:
                    continue
                if _reason(model, trial, key) is not None:
                    legal = False; break
                trial.place(model.placement(key))
            if not legal:
                result['refusals']['trial_t_m_conflict'] += 1; continue
            pending = [key for key in members if key not in state.selected]
            if graph is not None and not any(key in graph.domains[point] for key in pending):
                result['refusals']['does_not_reach_selected_graph_point'] += 1; continue
            before = after = 0
            for root in state.roots:
                tick(); before += state.totals.get(root, 0) == 12
                after += trial.totals.get(root, 0) == 12
            packet = dict(expansion, members=members, pending=pending,
                          pool_ordinal=len(result['packets']),
                          newly_satisfied_roots=after-before,
                          validation_checks_at_admission=result['validation_checks'])
            result['packets'].append(packet)
            if len(result['packets']) >= limits['cluster_proposals']:
                result['termination'] = 'packet_quota'; raise stop
    def bind(family, port, binding, sources):
        tick(); premises = family['template']['premises']
        if port == len(premises):
            admit(family, binding, sources); return
        for source in available:
            tick(); joined = _unify_checked(premises[port], source['formula'], binding, tick)
            if joined is not None:
                bind(family, port+1, joined, sources+[source])
    try:
        for family in library:
            tick(); bind(family, 0, {}, [])
        result['termination'] = 'declared_occurrences_exhausted'
    except _ReadyPoolLimit as error:
        if error is not stop:
            raise
    finally:
        # Only the proposer-owned exception/closures are changed. A genuine
        # Root/local-search fault keeps its exact object and propagates.
        stop.__traceback__ = None
        bind = None; admit = None; tick = None
    result['complete'] = True; result['refusals'] = dict(result['refusals'])
    result['pool_size_class'] = '0' if not result['packets'] else '1' if len(result['packets']) == 1 else '2+'
    continuations = set()
    for packet in result['packets']:
        check(); continuations.add(tuple(packet['pending']))
    result['distinct_primitive_continuations'] = len(continuations)
    result['continuation_size_class'] = ('0' if not continuations else
                                         '1' if len(continuations) == 1 else '2+')
    check(); return result


def packet_features(packet, model, state, graph, point, library, check, limits):
    check(); pending = packet['pending']; prefix = _prefix(model, state)
    premise_rows = set(); maximum_premises = 1
    for family in library:
        check(); maximum_premises = max(maximum_premises, len(family['template']['premises']))
    for source in packet['source_binding']:
        check()
        if source['kind'] == 'prefix':
            premise_rows.add(source['row'])
    eligible = 0
    for key in pending:
        check(); eligible += key in graph.domains[point]
    novel = True
    for command in prefix:
        check()
        if command['formula'] == packet['result_formula']:
            novel = False
    roots = max(1, len(state.roots))
    features = [1.0, len(pending)/(2.0*model.spec['length']),
                len(premise_rows)/float(maximum_premises),
                packet['newly_satisfied_roots']/float(roots), float(novel),
                eligible/float(max(1, len(pending))),
                float(packet['result_formula'] == model.spec['target']),
                min(1.0, packet['validation_checks_at_admission']/float(limits['cluster_binding_work'])), 0.0]
    check(); return features


def search_points_selected(model, library, mode, policy, seed, modules, check, limits):
    """The v12 scheduler/rollback/primitive fallback with a common selector hook."""
    points = modules['points']; began = time.perf_counter(); budget = _Budget(check, limits)
    initial = model.initial(); graph = points.Graph(model, initial)
    state_pre = copy.deepcopy(initial.__dict__); graph_pre = graph.fingerprint()
    trace = []; audits = []; decisions = []; metrics = collections.Counter(); found = None
    rng = random.Random(seed); maximum_live = 0.0; work_counter = {'completed': 0}
    def visit(state, g, hint):
        nonlocal found, maximum_live
        budget.check(); kind, point, keys = g.decision(state); metrics['nodes'] += 1
        satisfied = 0
        for root in initial.roots:
            budget.check(); satisfied += state.totals.get(root, 0) == 12
        live = satisfied/float(max(1, len(initial.roots))); maximum_live = max(maximum_live, live)
        if len(audits) < limits['domain_audits']:
            audits.append(audit_domains(model, state, g, budget.check))
        node = len(trace); trace.append(dict(event='decision', ordinal=node, kind=kind, point=point,
                                             original_alternatives=keys, live_root_fraction=live))
        if kind == 'dead':
            metrics['dead'] += 1; return False
        if kind == 'empty':
            found = state; return True
        metrics[kind] += 1; preferred = []
        if hint is not None:
            pending = [key for key in hint['pending'] if key not in state.selected]
            if not pending or any(_reason(model, state, key) is not None for key in pending):
                hint = None
            else:
                preferred = [key for key in pending if key in g.domains[point]]
        if kind == 'branch' and hint is None:
            pool = ready_pool(model, state, g, point, library, modules['host'],
                              budget.check, limits, work_counter)
            packets = pool['packets']
            features = []
            for packet in packets:
                budget.check(); features.append(packet_features(packet, model, state, g, point,
                                                                library, budget.check, limits))
            features.append([0.0]*8+[1.0])
            action = selector.choose(mode, policy['weights'], features, rng, check=budget.check)
            decisions.append(action); action_index = action['choice']
            trace.append(dict(event='selector_pool', decision=node, pool=pool,
                              action_index=len(decisions)-1, action=action))
            metrics['pool_'+pool['pool_size_class']] += 1
            metrics['continuations_'+pool['continuation_size_class']] += 1
            metrics['cluster_proposals'] += len(packets)
            if action_index < len(packets):
                hint = packets[action_index]
                preferred = [key for key in hint['pending'] if key in g.domains[point]]
                metrics['cluster_hints'] += 1
            else:
                metrics['abstentions'] += 1
        if kind == 'forced':
            alternatives = keys; novelty_only = keys
        else:
            completed_formulas = [command['formula'] for command in _prefix(model, state)]
            tiers = ([], [], [], []); novelty_tiers = ([], [])
            for key in keys:
                budget.check(); formula = model.metadata[key]['command']['formula']
                repeated = any(formula == prior for prior in completed_formulas)
                tiers[(2 if repeated else 0)+(0 if key in preferred else 1)].append(key)
                novelty_tiers[int(repeated)].append(key)
            alternatives = [key for tier in tiers for key in tier]; budget.check()
            novelty_only = novelty_tiers[0] + novelty_tiers[1]
        need(sorted(alternatives) == sorted(keys), 'complete primitive fallback/multiplicity')
        metrics['effective_order_changes'] += alternatives != keys
        metrics['selector_order_changes'] += alternatives != novelty_only
        metrics['novelty_order_changes'] += novelty_only != keys
        trace.append(dict(event='order', decision=node, alternatives=alternatives, preferred=preferred,
                          selector_changed_order=alternatives != novelty_only,
                          novelty_changed_order=novelty_only != keys))
        for key in alternatives:
            budget.extend(); metrics['attempts'] += 1
            child = state.copy(); cg = g.copy(); changed = child.place(model.placement(key))
            before = g.domains; cg.update(model, child, changed)
            removed = _aux_removals(model, child, before, cg.domains, check)
            trace.append(dict(event='place', decision=node, key=key, generation=child.tile_generations[-1],
                              auxiliary_removals=removed))
            metrics['auxiliary_removed_incidences'] += len(removed)
            okay = visit(child, cg, hint)
            trace.append(dict(event='return', decision=node, key=key, result=okay))
            if okay:
                return True
            metrics['backtracks'] += 1
        return False
    status = 'unknown_search_budget'
    try:
        complete = visit(initial, graph, None)
        status = 'point_proof_candidate' if complete else 'exhausted_finite_point_region'
    except _Cutoff as error:
        if error is not budget.stop:
            raise
        trace.append(dict(event='cutoff', attempts=budget.attempts))
        budget.stop.__traceback__ = None
    # End the owned recursive closure cycle; no graph owner is exported by ID.
    visit = None
    need(state_pre == initial.__dict__ and graph_pre == graph.fingerprint(),
         'exact original point state/graph rollback')
    placements = [] if found is None else found.order
    proof = None if found is None else model.decode(placements)
    initial_aux = []
    for point in sorted(initial.frontier()):
        for key in model.alignments(point):
            check(); why = _reason(model, initial, key)
            if why and why['kind'] == 'marking' and why['point'][0] == -100:
                initial_aux.append(dict(frontier_point=point, candidate=key,
                    auxiliary_point=why['point'], channel='certified-failure',
                    candidate_value=why['candidate_value'], assigned_value=why['assigned_value'],
                    assigned_owner='initial'))
    metrics['initial_auxiliary_removed_incidences'] = len(initial_aux)
    metrics['auxiliary_removed_incidences_total'] = metrics['auxiliary_removed_incidences'] + len(initial_aux)
    check(); return dict(status=status, proof=proof, placements=placements, trace=trace,
                         metrics=dict(metrics), selector_decisions=decisions,
                         max_live_root_fraction=maximum_live,
                         validation_checks=work_counter['completed'], domain_audits=audits,
                         initial_auxiliary_removals=initial_aux,
                         root_restored=True, graph_metrics=dict(model.metrics),
                         seconds=time.perf_counter()-began,
                         attempt_unit='primitive point placement', cluster_ordering=True)


"""Complete staged driver addition, assembled with the unchanged v12 base."""


STAGE_SCHEMA = 'gcts-principal-selector-stage-export-v1'
ACQUISITION_MODES = ('atom', 'principal')
PAIRING_POLICY = 'UNCHANGED_ATOM_TEMPLATE_CLASSES_NO_PRINCIPAL_COALESCENCE_V1'
METHODS = ('S0', 'SH', 'P0', 'PH', 'PU', 'PR')
NATIVE_STATUSES = ('accepted', 'rejected', 'unknown_step_budget', 'unknown_space_budget')
NATIVE_CERTIFICATE_IDENTITY = dict(
    program_sha256='877c47879b027b08f02d3923d1e6dd9ccaf9a12e354567109f1aaa640a8fb673',
    micro_sha256='2f9e430b0b7034ed615d81c3e9b3978dc47ba4136686227a9b86df5779b203ac',
    query_target='fixed_assertion', protocol='gcts-fol-1', native_steps=1000000000,
    executable_identity_scope='Exact executable/compiler/Host/transport Source pins in Root-admitted acquisition plan and result; no identity reconstructed from an accepted flag.')


def _checked_literal(value, check):
    check()
    if type(value) is list:
        return [_checked_literal(item, check) for item in value]
    if type(value) is tuple:
        return [_checked_literal(item, check) for item in value]
    if type(value) is dict:
        result = {}
        for key, item in value.items():
            check(); need(type(key) is str, 'ordinary string-key export')
            result[key] = _checked_literal(item, check)
        return result
    need(value is None or type(value) in (str, int, bool, float), 'ordinary stage value')
    need(type(value) is not float or math.isfinite(value), 'finite stage number')
    return value


def _payload_digest(value, check):
    body = word(_checked_literal(value, check)).encode('utf-8')
    check(); return hashlib.sha256(body).hexdigest()


def _native_status(record, check):
    check(); status = record['result']['status']
    need(type(status) is str and status in NATIVE_STATUSES, 'declared Native outcome')
    need(status != 'rejected', 'Native rejected actual primitive certificate')
    return status


def _compile_selector_case(spec, modules, oracle, check, limits):
    began = time.perf_counter(); check()
    compiled = modules['compiler'].compile_guards(spec, oracle,
                       limit=limits['native_steps'], queries=limits['compile_queries'])
    check(); need(compiled['status'] == 'complete', 'complete Native-admitted compiler')
    inventory = _empty_inventory()
    model = modules['model'].Model(spec, compiled, inventory, arity=0, families=False, check=check)
    model.reference_receipt = reference.verify_word_reference(spec, compiled, inventory, model, check=check)
    model.reference_v1_receipt = reference_v1.verify_word_reference(spec, compiled, inventory, model, check=check)
    old_values = {k:v for k,v in model.reference_v1_receipt.items() if k not in ('schema','storage_scope')}
    new_values = {k:v for k,v in model.reference_receipt.items() if k not in ('schema','storage_scope')}
    need(_same_wire(old_values, new_values, check), 'complete v1/v3 word-reference receipt correspondence')
    model.reference_differential = dict(complete=True, old=model.reference_v1_receipt,
        new=model.reference_receipt, old_version=reference_v1.VERSION, new_version=reference.VERSION, omitted_from_comparison=['schema','storage_scope'],
        scope='Both independent full placement/dictionary/domain/dependency verifiers ran on the same fresh model; encoding-only implementation contrast, shared by both abstraction modes.')
    need(model.arity == 0 and not model.interfaces, 'primitive empty-inventory model')
    for row in model.domains:
        for command in row:
            check(); need(command['rule'] not in ('block', 'assumption'), 'no macro candidate')
    return compiled, model, time.perf_counter()-began


def _case_evidence(spec, compiled, model, setup_seconds, check):
    began = time.perf_counter(); encoded = indexed_model(model, check)
    verified = verify_indexed_model(encoded, model, check)
    return dict(spec=spec, compiler=compiled, model=encoded,
                reference_check=model.reference_receipt, word_reference_differential=model.reference_differential,
                word_model_check=verified,
                compile_and_model_seconds=setup_seconds,
                word_model_seconds=time.perf_counter()-began)


def _mark_selector_model(model, modules, check, limits):
    began = time.perf_counter(); packet = compile_markings(model, check, limits)
    certificate = verify_markings(model, packet, check)
    marked = _MarkedModel(model, packet, modules['points'])
    extension = reference.verify_marked_extension(model, marked, packet, check=check)
    return marked, dict(markings=packet, marking_certificate_check=certificate,
                        marked_extension_check=extension, seconds=time.perf_counter()-began)


def _finish_selector_proof(spec, model, search, modules, oracle, check, limits, purpose):
    result = dict(native_proof_accepted=False, status='NO_PROOF_CANDIDATE',
                  host_check=None, region=None, native_record=None, native_limit=limits['native_steps'])
    if search['proof'] is None:
        return result
    began = time.perf_counter()
    result['host_check'] = host_check(spec, search['proof'], spec['target'], modules['host'], check)
    need(result['host_check']['accepted'], 'Host rejected discovered primitive proof')
    result['region'] = verify_region(model, search['placements'], search['proof'], check)
    q = _request(oracle, spec, search['proof'], check, limits, purpose)
    status = _native_status(q, check); result['native_record'] = _checked_literal(q, check)
    result['native_proof_accepted'] = status == 'accepted'
    result['status'] = ('HOST_REGION_NATIVE_ACCEPTED' if status == 'accepted' else
                         'HOST_REGION_ACCEPTED_NATIVE_UNKNOWN')
    result['seconds'] = time.perf_counter()-began
    return result



def _mine_receptor_pair(request, provenance, modules, check):
    """Both factors from one freshly checked exact primitive fragment."""
    check(); atom = modules['miner'].mine(request, [], provenance); check()
    typed = principal.mine(request, provenance, check=check)
    receipt = principal.verify(request, typed, check=check)
    independent = principal_reference.infer_request(request, check=check)
    need(typed['parameters'] == independent['parameters'] and
         _same_wire(typed['template'], independent['template'], check) and
         _same_wire(typed['certificate']['donor_arguments'], independent['concrete_arguments'], check) and
         _same_wire(typed['certificate']['port_occurrences'], independent['port_aliases'], check),
         'fresh independent principal family and concrete donor correspondence')
    for field in ('graph','row_formulas','premises','conclusion','port_count','parameters'):
        check(); need(_same_wire(typed['certificate']['typing'][field], independent[field], check),
                      'fresh independent principal DAG typing field '+field)
    receipt['independent'] = independent
    need(not atom['dependencies'] and not typed['dependencies'] and receipt['complete'],
         'primitive dual abstractions, no imported inference')
    return dict(atom=atom, principal=typed), receipt



def _verify_paired_receptor_wrapper(wrapper, structural, certificate, mode, unit_id, ordinal, check):
    check(); metadata = {'paired_unit_id','structural_id','abstraction_mode','pairing_policy',
                         'structural_family','source_certificate_ordinal','wrapper_scope'}
    need(set(wrapper) == set(structural) | metadata and type(wrapper['id']) is str and
         type(wrapper['paired_unit_id']) is str and type(wrapper['structural_id']) is str and
         type(wrapper['source_certificate_ordinal']) is int and
         type(wrapper['abstraction_mode']) is str and wrapper['id'] == unit_id and
         wrapper['paired_unit_id'] == unit_id and wrapper['structural_id'] == structural['id'] and
         wrapper['abstraction_mode'] == mode and wrapper['pairing_policy'] == PAIRING_POLICY and
         wrapper['source_certificate_ordinal'] == ordinal and
         _same_wire(wrapper['structural_family'], structural, check),
         'exact structural-family owner and explicit paired wrapper binding')
    for key, value in structural.items():
        check()
        if key != 'id':
            need(_same_wire(wrapper[key], value, check), 'all structural family fields forwarded literally')
    typed_receipt = (principal.verify(certificate['native_record']['request'],
                      wrapper['structural_family'], check=check) if mode == 'principal' else None)
    return dict(complete=True, mode=mode, paired_unit_id=unit_id,
                structural_id=structural['id'], source_certificate_ordinal=ordinal,
                principal_structural_check=typed_receipt,
                scope='Literal wrapper-to-exact-inner binding. Atom inner was freshly reconstructed by unchanged miner; principal.verify receives only exact inner, never relabeled wrapper. Native/query authority remains the retained source certificate.')

def _paired_receptor_libraries(certificates, check):
    """Old atom classes define shared units; never coalesce principal structures."""
    units = []; by_atom = {}; libraries = dict(atom=[], principal=[])
    for ordinal, certificate in enumerate(certificates):
        check(); families = certificate['families']; atom = families['atom']; typed = families['principal']
        identity = atom['id']
        if identity not in by_atom:
            unit = dict(paired_unit_id=identity, atom_structural_id=atom['id'],
                        principal_structural_id=typed['structural_id'], members=[], wrapper_checks={})
            by_atom[identity] = (unit, atom, typed); units.append(unit)
            for mode in ACQUISITION_MODES:
                family = _checked_literal(families[mode], check)
                family.update(id=identity, paired_unit_id=identity,
                              structural_id=families[mode]['id'], abstraction_mode=mode,
                              pairing_policy=PAIRING_POLICY,
                              structural_family=_checked_literal(families[mode], check),
                              source_certificate_ordinal=ordinal,
                              wrapper_scope='Paired ordering-inventory wrapper; only exact inner structural_family is passed to its structural verifier.')
                unit['wrapper_checks'][mode] = _verify_paired_receptor_wrapper(
                    family, families[mode], certificate, mode, identity, ordinal, check)
                libraries[mode].append(family)
        else:
            unit, prior_atom, prior_typed = by_atom[identity]
            need(atom['parameters'] == prior_atom['parameters'] and
                 _same_wire(atom['template'], prior_atom['template'], check), 'old atom digest collision')
            need(typed['parameters'] == prior_typed['parameters'] and
                 typed['structural_id'] == prior_typed['structural_id'] and
                 _same_wire(typed['template'], prior_typed['template'], check) and
                 _same_wire(typed['certificate']['typing']['graph'],
                            prior_typed['certificate']['typing']['graph'], check),
                 'all atom-class members share one canonical principal interface and DAG')
        unit['members'].append(dict(certificate_ordinal=ordinal,
                                    provenance=_checked_literal(certificate['provenance'], check)))
    need([f['paired_unit_id'] for f in libraries['atom']] ==
         [f['paired_unit_id'] for f in libraries['principal']], 'identical paired multiplicity/order')
    return libraries, dict(policy=PAIRING_POLICY, units=units, raw_certificates=len(certificates),
        paired_units=len(units), principal_structures=len({f['structural_id'] for f in libraries['principal']}),
        no_principal_coalescence=True,
        scope='Principal relative to unchanged exact-formula premise-port quotient and full fixed donor DAG; abstraction may remove incidental constructors and atom equalities, never DAG-required constraints.')

def _acquire_selector_donor(spec, modules, oracle, check, limits, acquisition_mode):
    began = time.perf_counter(); compiled, model, seconds = _compile_selector_case(spec, modules, oracle, check, limits)
    entry = _case_evidence(spec, compiled, model, seconds, check)
    search = search_symbolic(model, [], False, modules, check, limits)
    entry['search'] = search
    entry['proof_check'] = _finish_selector_proof(spec, model, search, modules, oracle, check, limits,
                                                 'selector_acquisition_whole_'+spec['id'])
    entry['candidates'] = []; certificates = []
    if entry['proof_check']['native_proof_accepted']:
        proof = search['proof']; candidates = [('full', None, proof, list(range(len(proof))))]
        for index in range(len(proof)):
            check(); extracted, ancestry = _essential(proof[:index+1], check)
            candidates.append(('ancestor_closure', index, extracted, ancestry))
        for ordinal, (kind, row, fragment, ancestry) in enumerate(candidates):
            check(); target = fragment[-1]['formula']
            candidate = dict(ordinal=ordinal, kind=kind, source_row=row, ancestry=ancestry,
                             proof=fragment, target=target, eligible=False, reason=None,
                             host_check=None, native_record=None, family=None)
            entry['candidates'].append(candidate)
            if (not all(c['rule'] in ('axiom', 'mp') for c in fragment)
                    or not any(c['rule'] == 'mp' for c in fragment)):
                candidate['reason'] = 'declared_axiom_MP_with_at_least_one_MP_profile'; continue
            candidate['host_check'] = host_check(spec, fragment, target, modules['host'], check)
            need(candidate['host_check']['accepted'], 'Host rejected exact remapped fragment')
            q = _request(oracle, spec, fragment, check, limits,
                         'selector_acquisition_fragment_'+spec['id']+'_'+str(ordinal), target=target)
            candidate['native_record'] = _checked_literal(q, check)
            if _native_status(q, check) != 'accepted':
                candidate['reason'] = 'Native_unknown_fragment'; continue
            provenance = dict(training_id=spec['id'], candidate_ordinal=ordinal,
                              kind=kind, source_row=row, ancestry=ancestry,
                              native_query=q['id'], request_digest=_payload_digest(q['request'], check))
            families, typing_check = _mine_receptor_pair(q['request'], provenance, modules, check)
            family = families[acquisition_mode]
            candidate.update(families=families, principal_check=typing_check)
            candidate.update(eligible=True, reason='fresh_Host_and_Native_accepted', family=family)
            certificates.append(dict(spec=spec, proof=fragment, target=target, provenance=provenance,
                family=family, families=families, principal_check=typing_check, acquisition_mode=acquisition_mode,
                native_record=_checked_literal(q, check), native_limit=limits['native_steps'],
                full_donor_proof=proof, full_donor_check=entry['proof_check'],
                fragment_region_scope='No separate fragment region compiled; exact remapped primitive Host/Native certificate. Whole donor has full original region.'))
    entry['seconds'] = time.perf_counter()-began
    return entry, certificates


def _verify_native_evidence(record, spec, proof, target, check, limits):
    check(); need(type(record) is dict and set(record) == {'id','request','query_target','request_sha256',
                  'input_sha256','output_sha256','result','seconds','purpose'}
                  and type(record.get('id')) is int and record['id'] >= 0,
                  'full exact accepted acquisition query')
    expected = dict(protocol='gcts-fol-1', theory=spec['theory'], blocks=[], proof=proof, target=target)
    need(_same_wire(record['request'], expected, check), 'exact certified theory/proof/target/no blocks')
    need(record['request_sha256'] == _payload_digest(expected, check) and
         record['query_target'] == 'fixed_assertion' and type(record['purpose']) is str,
         'full query digest/target/purpose carrier')
    for name in ('input_sha256','output_sha256'):
        check(); need(type(record[name]) is str and len(record[name]) == 64, 'complete Native transport payload digest')
    need(_native_status(record, check) == 'accepted', 'only accepted Native proof reused')
    return dict(query=record['id'], request_sha256=_payload_digest(expected, check),
                result_sha256=_payload_digest(record['result'], check),
                scope='Exact full evidence from Root-admitted D16 acquisition; Native not replayed here.')


def _verify_acquisition_exports(exports, modules, check, limits, acquisition_mode):
    need(type(exports) is list and len(exports) == 3, 'all three admitted acquisition exports')
    certificates = []; training_doc = None; verification = []; all_donors = []
    for shard, exported in enumerate(exports):
        check(); need(exported['schema'] == STAGE_SCHEMA and exported['stage'] == 'acquire'
              and exported['stage_id'] == 'acquire-'+str(shard)
              and exported['acquisition_mode'] == acquisition_mode
              and exported['pairing_policy'] == PAIRING_POLICY, 'ordered mode-bound acquisition export identities')
        need(_same_wire(exported['native_certificate_identity'], NATIVE_CERTIFICATE_IDENTITY, check),
             'same exact Root-bound checker/program contract')
        doc = exported['training_document']; corpus_reference.validate_training_document(doc, check=check)
        if training_doc is None:
            training_doc = doc
        need(_same_wire(doc, training_doc, check), 'one unchanged training manifest')
        expected_ids = [s['id'] for s in doc['training'][4*shard:4*shard+4]]
        need(exported['donor_ids'] == expected_ids and len(exported['donor_outcomes']) == 4,
             'all four donor attempts retained')
        need([r['id'] for r in exported['donor_outcomes']] == expected_ids, 'donor outcome order')
        all_donors.extend(exported['donor_outcomes'])
        for certificate in exported['certificates']:
            check(); spec = certificate['spec']
            need(any(_same_wire(spec, s, check) for s in doc['training'][4*shard:4*shard+4]),
                 'certificate belongs to declared donor shard')
            proof = certificate['proof']; target = certificate['target']; provenance = certificate['provenance']
            whole = certificate['full_donor_proof']; wholecheck = certificate['full_donor_check']
            need(wholecheck['native_proof_accepted'] is True and wholecheck['region'] is not None,
                 'searched whole donor Host/region/Native provenance')
            need(type(certificate['native_limit']) is int and certificate['native_limit'] == limits['native_steps']
                 and type(wholecheck['native_limit']) is int and wholecheck['native_limit'] == limits['native_steps'],
                 'exact acquisition query limits bound by admitted actual call records')
            _verify_native_evidence(wholecheck['native_record'], spec, whole, spec['target'], check, limits)
            need(host_check(spec, whole, spec['target'], modules['host'], check)['accepted'],
                 'fresh Host whole donor recheck')
            kind = provenance['kind']; row = provenance['source_row']
            if kind == 'full':
                expected = whole; ancestry = list(range(len(whole)))
            else:
                need(kind == 'ancestor_closure' and type(row) is int and 0 <= row < len(whole),
                     'exact fragment source row')
                expected, ancestry = _essential(whole[:row+1], check)
            need(_same_wire(proof, expected, check) and ancestry == provenance['ancestry']
                 and target == proof[-1]['formula'], 'exact full/ancestor remapping correspondence')
            need(all(c['rule'] in ('axiom', 'mp') for c in proof) and any(c['rule']=='mp' for c in proof),
                 'retained nullary donor primitive profile')
            need(host_check(spec, proof, target, modules['host'], check)['accepted'], 'fresh Host fragment recheck')
            receipt = _verify_native_evidence(certificate['native_record'], spec, proof, target, check, limits)
            need(provenance['native_query'] == certificate['native_record']['id'] and
                 provenance['request_digest'] == receipt['request_sha256'], 'query/digest provenance binding')
            families, typing_check = _mine_receptor_pair(certificate['native_record']['request'], provenance, modules, check)
            need(certificate['acquisition_mode'] == acquisition_mode and
                 _same_wire(families, certificate['families'], check) and
                 _same_wire(typing_check, certificate['principal_check'], check) and
                 _same_wire(families[acquisition_mode], certificate['family'], check),
                 'fresh exact dual abstraction and selected mode reconstruction')
            certificates.append(certificate); verification.append(receipt)
    need(len(all_donors) == 12 and len(certificates) <= 64, 'complete bounded acquisition population')
    libraries, pairing = _paired_receptor_libraries(certificates, check)
    library = libraries[acquisition_mode]
    provenance_rows = [dict(family=c['families']['atom']['id'], provenance=c['provenance']) for c in certificates]
    derived = [sum(c['rule'] == 'mp' for c in family['template']['proof']) for family in library]
    ready = len(library) >= 2 and any(count >= 2 for count in derived)
    return library, training_doc, dict(complete=True, qualified=ready, families=len(library),
        certificates=len(certificates), donor_outcomes=all_donors, Native_evidence=verification,
        all_family_provenance=provenance_rows, pairing=pairing, acquisition_mode=acquisition_mode,
        evidence_scope='Fresh Host and family reconstruction; exact accepted Native evidence reused under Root-admitted acquisition/export identity. No Native replay or new universal substitution theorem.')


def _expected_prior_stages(stage, index):
    if stage == 'acquire':
        return []
    return ['acquire-'+str(i) for i in range(3)] + ['train-'+str(i) for i in range(index)]


def _verify_upstream(upstream, stage, index, check):
    need(type(upstream) is dict and set(upstream) == {'acquisition', 'policy', 'receipts'},
         'exact stage upstream interface')
    expected = _expected_prior_stages(stage, index)
    rows = upstream['receipts']; need(type(rows) is list and len(rows) == len(expected), 'all required direct upstream receipts')
    mapping = {}; seconds = 0.0; peaks = []
    required_fields = {'stage_id','stage','resource_admitted','stage_complete','plan','result','header',
                       'terminal','observer','export_sha256','whole_seconds','whole_peak_bytes','prior_cost_receipts'}
    for row in rows:
        check(); need(type(row) is dict and set(row) == required_fields, 'exact Root-admitted receipt envelope')
        identity = row['stage_id']; need(identity in expected and identity not in mapping, 'unique required upstream stage')
        need(row['stage'] == ('acquire' if identity.startswith('acquire-') else 'train') and
             row['resource_admitted'] is True and row['stage_complete'] is True and row['prior_cost_receipts'] == [],
             'whole admitted complete direct receipt, never cumulative double counting')
        for name in ('plan','result','header','terminal','observer'):
            pin = row[name]; check()
            need(type(pin) is dict and set(pin) == {'path','bytes','sha256'} and type(pin['path']) is str and
                 type(pin['bytes']) is int and pin['bytes'] >= 0 and type(pin['sha256']) is str and len(pin['sha256']) == 64,
                 'complete upstream raw custody pin')
        value = row['whole_seconds']; peak = row['whole_peak_bytes']
        need(type(value) in (float,int) and type(value) is not bool and math.isfinite(value) and 0 <= value <= 225,
             'admitted direct whole elapsed seconds')
        need(type(peak) is int and 0 <= peak <= 1073741824, 'admitted whole high water')
        mapping[identity] = row; seconds += value; peaks.append(peak)
    need(set(mapping) == set(expected), 'complete exact prior-stage set')
    acquisitions = upstream['acquisition']
    if stage == 'acquire':
        need(acquisitions == [] and upstream['policy'] is None, 'cold acquisition has no library or policy')
    else:
        need(type(acquisitions) is list and len(acquisitions) == 3, 'all three acquisition payloads')
        for i, exported in enumerate(acquisitions):
            check(); need(_payload_digest(exported, check) == mapping['acquire-'+str(i)]['export_sha256'],
                          'exact Root sealed acquisition export')
        if index == 0:
            need(upstream['policy'] is None, 'first train shard starts zero policy')
        else:
            exported = upstream['policy']; identity = 'train-'+str(index-1)
            need(type(exported) is dict and exported['stage_id'] == identity and
                 _payload_digest(exported, check) == mapping[identity]['export_sha256'], 'exact last admitted frozen policy export')
    return dict(stage_ids=expected, whole_seconds=seconds, maximum_prior_whole_peak_bytes=max(peaks, default=0),
                receipts=_checked_literal(rows, check), current_whole_seconds=None,
                scope='Sum each unique admitted predecessor direct whole cost once. Current entry cost reported separately; final current custody unavailable inside entry.')


def _verify_policy_export(exported, library, training_doc, episodes, acquisitions, receipts, check, acquisition_mode):
    need(exported['schema'] == STAGE_SCHEMA and exported['stage'] == 'train' and
         exported['stage_id'] == 'train-'+str(episodes//8-1) and
         exported['acquisition_mode'] == acquisition_mode, 'mode-bound policy chain stage')
    need(exported['training_document_sha256'] == _payload_digest(training_doc, check) and
         exported['library_sha256'] == _payload_digest(library, check), 'frozen training/library join')
    expected_acquisition = [_payload_digest(v, check) for v in acquisitions]
    need(exported['acquisition_exports'] == expected_acquisition, 'same three exact acquisition exports')
    previous = None if episodes == 8 else next(r['export_sha256'] for r in receipts if r['stage_id'] == 'train-'+str(episodes//8-2))
    need(exported['prior_policy_export_sha256'] == previous, 'immediate admitted policy chain link')
    policy = exported['policy']; ids = [s['id'] for s in training_doc['training']]
    receipt = selector.verify_policy(policy, ids, check=check)
    need(policy['episodes'] == episodes and len(exported['episode_bindings']) == episodes,
         'complete unshortened episode schedule')
    for index, binding in enumerate(exported['episode_bindings']):
        check(); episode = policy['history'][index]['episode']
        need(type(binding['index']) is int and binding['index'] == index and binding['stage_id'] == 'train-'+str(index//8) and
             binding['episode_sha256'] == _payload_digest(episode, check) and
             binding['problem_id'] == ids[index % 12], 'exact admitted episode/action/reward provenance')
        need(type(binding['search_sha256']) is str and len(binding['search_sha256']) == 64 and
             binding['reward_components'] == episode['reward_components'] and
             binding['selector_decisions_sha256'] == _payload_digest(episode['decisions'], check),
             'full live record digest and exact numeric ledger link')
        need(binding['provenance_scope'] == 'ROOT_ADMITTED_ACTUAL_STAGE_RECORD', 'honest live-state trust boundary')
    return receipt


def search_symbolic_selected(model, library, modules, check, limits):
    """Fixed symbolic ordering; same binding/guard validator, no Graph scheduler claim."""
    began = time.perf_counter(); budget = _Budget(check, limits); helper = modules['symbolic']
    compiled = model.compiled; spec = model.spec
    basis_index = {helper._json(f): i for i, f in enumerate(compiled['basis'])}
    tauts = {helper._json(f) for f in compiled['tautologies']}; schemes = {helper._json(c) for c in compiled['admitted_schemes']}
    distances = {}; path = []; selected = []; trace = []; metrics = collections.Counter(); found = None
    work = {'completed': 0}
    def visit(hint=None):
        nonlocal found
        budget.check(); row = len(path); metrics['nodes'] += 1
        if row == spec['length']:
            found = (copy.deepcopy(path), list(selected)); return True
        candidates = []
        for k, command in enumerate(model.domains[row]):
            budget.check(); metrics['skeleton_tests'] += 1
            variant = (0 if spec['theory']['axioms'][command['name']] == command['formula'] else None
                       ) if command['rule'] == 'axiom' else helper._primitive_guard(command, path, basis_index, tauts, schemes)
            if variant is not None:
                candidates.append((k, variant, command))
        available = {word(c['formula']) for c in path}
        candidates.sort(key=lambda item: (word(item[2]['formula']) in available,
                         distances.get(helper._json(item[2]['formula']), len(distances)+1), item[0]))
        active = hint
        if active is not None and (not active['commands'] or active['prefix_rows'] != row):
            active = None
        pool = None
        if active is None:
            state = model.initial()
            for key in selected:
                budget.check(); need(_reason(model, state, key) is None, 'actual symbolic prefix point correspondence')
                state.place(model.placement(key))
            pool = ready_pool(model, state, None, None, library, modules['host'], budget.check, limits, work)
            active = pool['packets'][0] if pool['packets'] else None
            metrics['cluster_proposals'] += len(pool['packets']); metrics['pool_'+pool['pool_size_class']] += 1
        preferred = active['commands'][0] if active is not None else None
        ordered = [item for item in candidates if item[2] == preferred]+[item for item in candidates if item[2] != preferred]
        need(sorted((k,v) for k,v,c in ordered) == sorted((k,v) for k,v,c in candidates), 'symbolic full fallback')
        metrics['effective_order_changes'] += ordered != candidates
        ordinal = len(trace); trace.append(dict(event='decision', row=row,
            original_candidates=[[k,v] for k,v,c in candidates], ordered_candidates=[[k,v] for k,v,c in ordered], pool=pool))
        for k, variant, command in ordered:
            budget.extend(); metrics['attempts'] += 1
            trace.append(dict(event='extend', decision=ordinal, skeleton=k, variant=variant))
            path.append(command); selected.extend([(row,0,k,0),(row,1,k,variant)])
            next_hint = (dict(active, prefix_rows=row+1, commands=active['commands'][1:])
                         if active is not None and command == preferred else None)
            try:
                if visit(next_hint):
                    trace.append(dict(event='return', decision=ordinal, skeleton=k, result=True)); return True
                trace.append(dict(event='return', decision=ordinal, skeleton=k, result=False)); metrics['backtracks'] += 1
            finally:
                del selected[-2:]; path.pop()
        return False
    status = 'unknown_search_budget'
    try:
        dependencies = helper._backward_distances(compiled['basis'], compiled['variables'], [], budget)
        distances = helper._distances_from_target(spec['target'], dependencies, budget)
        complete = visit(); status = 'symbolic_proof_candidate' if complete else 'exhausted_finite_symbolic_grammar'
    except _Cutoff as error:
        if error is not budget.stop:
            raise
        trace.append(dict(event='cutoff', attempts=budget.attempts)); budget.stop.__traceback__ = None
    visit = None; need(not path and not selected, 'exact symbolic prefix rollback')
    return dict(status=status, proof=None if found is None else found[0], placements=[] if found is None else found[1],
        trace=trace, metrics=dict(metrics), validation_checks=work['completed'], seconds=time.perf_counter()-began,
        attempt_unit='primitive proof-row extension', root_restored=True, cluster_ordering=True,
        strategy='same bounded family/occurrence/guard pool; fixed first packet; symbolic prefix has no selected Graph point')


def _selector_controls(stage, document, modules, check, limits):
    result = dict(numeric=numeric_reference.run_numeric_controls(selector, check=check),
                  inherited=run_diagnostics(modules, check, limits),
                  word=reference.run_word_reference_diagnostics(word_points, check=check),
                  graph=graph_reference.run_graph_copy_controls(modules['points'], check=check),
                  encoding=reference.run_encoding_diagnostics(check=check),
                  principal=principal_reference.run_principal_reference_controls(principal, check=check))
    result['corpus'] = (corpus_reference.run_corpus_controls(document, check=check)
                        if stage == 'acquire' else None)
    return result


def run_stage(stage_input, upstream_payloads, *, stage, stage_id, check, limits, modules, oracle, acquisition_mode):
    """Fresh actual only. Root owns raw input/executable/Native/resource custody."""
    check(); began = time.perf_counter(); need(set(modules) == set(MODULE_ROLES), 'six exact injected scientific roles')
    need(_same_wire(limits, LIMITS, check) and not oracle.records, 'unchanged limits and cold current Native stream')
    need(stage in ('acquire','train','evaluate') and type(stage_id) is str, 'declared stage dispatch')
    need(type(acquisition_mode) is str and acquisition_mode in ACQUISITION_MODES, 'explicit abstraction factor')
    original = _checked_literal(stage_input, check); document = _checked_literal(stage_input, check)
    upstream_before = _payload_digest(upstream_payloads, check)
    if stage in ('acquire','train'):
        format_receipt = corpus_reference.validate_training_document(document, check=check)
        need(stage_id in tuple(stage+'-'+str(i) for i in range(3)), 'fixed shard ID')
        index = int(stage_id.rsplit('-',1)[1])
    else:
        # Root must freeze/admit all upstream policy/library bytes BEFORE it reads
        # this physically separate evaluation document. This function cannot
        # substitute for that process-intake boundary.
        format_receipt = corpus_reference.validate_evaluation_document(document, check=check)
        index = 3
    costs = _verify_upstream(upstream_payloads, stage, index, check)
    result = dict(schema=VERSION, stage=stage, stage_id=stage_id, inputs=document, limits=literal(limits),
        format_check=format_receipt, stage_complete=False, status='INCOMPLETE', export=None, records=[],
        acquisition_mode=acquisition_mode, pairing_policy=PAIRING_POLICY,
        cumulative_costs=costs, resource_admitted=False,
        scope='Native/word-point adaptation with actual reward-trained primitive ordering; no physical Wang or universal proof-search claim')
    result['controls'] = _selector_controls(stage, document, modules, check, limits)
    if stage == 'acquire':
        selected = document['training'][4*index:4*index+4]; certificates = []; outcomes = []
        for spec in selected:
            check(); record, acquired = _acquire_selector_donor(spec, modules, oracle, check, limits, acquisition_mode)
            result['records'].append(record); certificates.extend(acquired)
            outcomes.append(dict(id=spec['id'], status=record['search']['status'],
                whole_native_accepted=record['proof_check']['native_proof_accepted'],
                eligible_fragments=len(acquired), record_sha256=_payload_digest(record, check)))
        exported = dict(schema=STAGE_SCHEMA, stage=stage, stage_id=stage_id, training_document=document,
                        donor_ids=[s['id'] for s in selected], donor_outcomes=outcomes, certificates=certificates,
                        native_certificate_identity=copy.deepcopy(NATIVE_CERTIFICATE_IDENTITY),
                        acquisition_mode=acquisition_mode, pairing_policy=PAIRING_POLICY,
                        acquisition_scope='Fresh searched donor Host/full-region/Native. Exact remapped fragment Host/Native before dual atom/principal mining.')
        result.update(stage_complete=True, status='ACQUISITION_SHARD_RECORDED', export=exported)
    else:
        library, training_document, verified = _verify_acquisition_exports(upstream_payloads['acquisition'], modules, check, limits, acquisition_mode)
        result['library'] = library; result['acquisition_check'] = verified
        result['library_sha256'] = _payload_digest(library, check)
        if not verified['qualified']:
            result['status'] = 'INSUFFICIENT_ACQUISITION'
        else:
            if stage == 'train' and index == 0:
                policy = selector.initial_policy(check=check); bindings = []
                prior_check = dict(complete=True, episodes=0, scope='declared zero initialization')
            else:
                prior = upstream_payloads['policy']; count = index*8
                prior_check = _verify_policy_export(prior, library, training_document, count,
                    upstream_payloads['acquisition'], upstream_payloads['receipts'], check, acquisition_mode)
                policy = _checked_literal(prior['policy'], check); bindings = _checked_literal(prior['episode_bindings'], check)
            result['prior_policy_check'] = prior_check
            if stage == 'train':
                need(_same_wire(document, training_document, check), 'training shard unchanged from acquisition input')
                for episode_index in range(index*8,(index+1)*8):
                    check(); episode_started = time.perf_counter(); spec = document['training'][episode_index % 12]
                    compiled, model, seconds = _compile_selector_case(spec, modules, oracle, check, limits)
                    record = _case_evidence(spec, compiled, model, seconds, check)
                    marked, marking_record = _mark_selector_model(model, modules, check, limits)
                    record['marking'] = marking_record
                    record['diagnostic_ground_registry'] = _ground_clusters(library, compiled, spec, modules['miner'], oracle, check, limits)
                    record['search'] = search_points_selected(marked, library, 'rl', policy, episode_index, modules, check, limits)
                    record['proof_check'] = _finish_selector_proof(spec, marked, record['search'], modules, oracle, check, limits,
                                                                  'selector_training_'+str(episode_index))
                    search = record['search']; components = dict(native_accepted=record['proof_check']['native_proof_accepted'],
                        max_live_root_fraction=search['max_live_root_fraction'], attempts=search['metrics'].get('attempts',0),
                        validation_checks=search['validation_checks'])
                    episode = dict(index=episode_index, problem_id=spec['id'], decisions=search['selector_decisions'], reward_components=components)
                    record['episode'] = episode; policy = selector.update_policy(policy, episode, check=check)
                    record['update'] = policy['history'][-1]['update']; record['seconds'] = time.perf_counter()-episode_started
                    binding = dict(index=episode_index, stage_id=stage_id, problem_id=spec['id'],
                        episode_sha256=_payload_digest(episode, check), search_sha256=_payload_digest(search, check),
                        selector_decisions_sha256=_payload_digest(episode['decisions'], check), reward_components=components,
                        proof_status=record['proof_check']['status'], record_sha256=_payload_digest(record, check),
                        provenance_scope='ROOT_ADMITTED_ACTUAL_STAGE_RECORD')
                    bindings.append(binding); result['records'].append(record)
                    # No raw model/State/Graph is intentionally included in exports.
                    del search, marked, model, compiled
                ids = [s['id'] for s in training_document['training']]
                result['policy_check'] = selector.verify_policy(policy, ids, check=check)
                exported = dict(schema=STAGE_SCHEMA, stage=stage, stage_id=stage_id,
                    training_document_sha256=_payload_digest(training_document, check), library_sha256=result['library_sha256'],
                    acquisition_exports=[_payload_digest(v, check) for v in upstream_payloads['acquisition']],
                    policy=policy, episode_bindings=bindings, prior_policy_export_sha256=(None if index==0 else _payload_digest(upstream_payloads['policy'], check)),
                    acquisition_mode=acquisition_mode, pairing_policy=PAIRING_POLICY,
                    live_provenance_scope='Numeric history joins actual source-generated search/action/reward records through Root-admitted stage/export bytes; arithmetic replay alone does not prove raw State identity.')
                result.update(stage_complete=True, status='TRAINING_SHARD_COMPLETE', export=exported)
            else:
                matches = []
                for spec in document['evaluation']:
                    for seed in document['protocol']['evaluation_seeds']:
                        check()
                        if stage_id == 'eval-'+spec['id']+'-seed-'+str(seed):
                            matches.append((spec, seed))
                need(len(matches) == 1, 'exact preregistered evaluation case/seed')
                spec, seed = matches[0]; frozen_policy = _checked_literal(policy, check); frozen_library = _payload_digest(library, check)
                setup_started = time.perf_counter(); compiled, model, seconds = _compile_selector_case(spec, modules, oracle, check, limits)
                case = _case_evidence(spec, compiled, model, seconds, check)
                marked, marking_record = _mark_selector_model(model, modules, check, limits); case['marking'] = marking_record
                case['diagnostic_ground_registry'] = _ground_clusters(library, compiled, spec, modules['miner'], oracle, check, limits)
                case['shared_setup_seconds'] = time.perf_counter()-setup_started; case['arms'] = []; result['records'].append(case)
                order = document['protocol']['arm_order'][spec['id']][str(seed)]
                need(len(order)==6 and set(order)==set(METHODS), 'whole fixed six-method order')
                for method in order:
                    check(); arm_started = time.perf_counter(); active = model if method in ('S0','SH') else marked
                    active.metrics.clear()
                    if method == 'S0':
                        search = search_symbolic(active, [], False, modules, check, limits)
                    elif method == 'SH':
                        search = search_symbolic_selected(active, library, modules, check, limits)
                    elif method == 'P0':
                        search = search_points(active, [], False, modules, check, limits)
                    else:
                        mode = {'PH':'fixed','PU':'uniform','PR':'rl'}[method]
                        search = search_points_selected(active, library, mode, policy, seed, modules, check, limits)
                    entry = dict(id=method, search=search, certified_markings=method not in ('S0','SH'),
                        cluster_ordering=method in ('SH','PH','PU','PR'), execution_status='SEARCH_RETURNED')
                    entry['proof_check'] = _finish_selector_proof(spec, active, search, modules, oracle, check, limits,
                                                                  'selector_evaluation_'+spec['id']+'_'+method)
                    entry['full_arm_seconds'] = time.perf_counter()-arm_started; case['arms'].append(entry)
                    need(_same_wire(policy, frozen_policy, check) and _payload_digest(library, check)==frozen_library,
                         'no evaluation weight/library update')
                no_unknown_final = all(a['proof_check']['status'] != 'HOST_REGION_ACCEPTED_NATIVE_UNKNOWN' for a in case['arms'])
                result.update(stage_complete=no_unknown_final, status=('EVALUATION_SIX_METHOD_RECORD' if no_unknown_final else 'FINAL_NATIVE_UNRESOLVED'),
                    all_six_searched=True, policy_frozen_sha256=_payload_digest(policy, check), evaluation_seed=seed,
                    export=dict(schema=STAGE_SCHEMA,stage=stage,stage_id=stage_id,case_id=spec['id'],seed=seed,
                        library_sha256=frozen_library,policy_sha256=_payload_digest(policy,check),
                        outcomes=[dict(id=a['id'],search_status=a['search']['status'],proof_status=a['proof_check']['status']) for a in case['arms']]) if no_unknown_final else None)
    check(); need(_same_wire(stage_input, original, check), 'original physical phase input unchanged')
    need(_payload_digest(upstream_payloads, check) == upstream_before, 'all exact admitted upstream inputs unchanged')
    result['native_records'] = _checked_literal(oracle.records, check)
    result['seconds'] = time.perf_counter()-began
    result['cumulative_costs']['current_entry_seconds'] = result['seconds']
    result['cumulative_costs']['upstream_plus_current_entry_seconds'] = costs['whole_seconds']+result['seconds']
    result['cumulative_costs']['qualification'] = 'Current whole resource/serialization/Native-close/custody cost and admission are Root-owned, unavailable until terminal observer.'
    return result


MECHANISM_SCHEMA = 'gcts-principal-receptor-mechanism-result-v1'


def run_mechanism(document, *, check, limits, modules, oracle):
    """Fresh paired abstraction mechanism, not a proof-search/RL benchmark.

    Root must own a total512-query guard on the actual oracle, including calls
    made directly by the unchanged compiler. Both abstractions share each fresh
    model and BOTH full word-reference audits (original v1 and corrected v3). No D15 library/policy is reused.
    """
    check(); began = time.perf_counter()
    need(set(modules) == set(MODULE_ROLES) and _same_wire(limits, LIMITS, check),
         'same six primitive scientific roles and all original local limits')
    need(not oracle.records, 'cold current Native stream')
    original = _checked_literal(document, check)
    format_check = mechanism_reference.validate_document(document, check=check)
    controls = _selector_controls('mechanism', document, modules, check, limits)
    controls['mechanism_corpus'] = mechanism_reference.run_contract_controls(document, check=check)
    result = dict(schema=MECHANISM_SCHEMA, implementation=VERSION, inputs=original,
        limits=literal(limits), format_check=format_check, controls=controls,
        records=[], contexts=[], export=None, stage_complete=False,
        record_complete=False, status='INCOMPLETE', resource_admitted=False,
        pairing_policy=PAIRING_POLICY,
        scope='Fresh paired atom/principal context-packet availability only; no GCTS search, RL learning, timing advantage, physical Wang or universalized inference claim.')
    certificates = []; donor_outcomes = []
    for spec in document['donors']:
        check(); record, acquired = _acquire_selector_donor(spec, modules, oracle, check, limits, 'principal')
        need(len(oracle.records) <= 512, 'whole mechanism Native query guard')
        result['records'].append(record); certificates.extend(acquired)
        donor_outcomes.append(dict(id=spec['id'], search_status=record['search']['status'],
            whole_native_accepted=record['proof_check']['native_proof_accepted'],
            retained_fragment_certificates=len(acquired)))
    libraries, pairing = _paired_receptor_libraries(certificates, check)
    result.update(certificates=certificates, libraries=libraries, pairing=pairing,
                  donor_outcomes=donor_outcomes)
    multistep = any(sum(c['rule'] == 'mp' for c in f['template']['proof']) >= 2
                    for f in libraries['atom'])
    acquired = (len(donor_outcomes) == 2 and all(d['whole_native_accepted'] for d in donor_outcomes)
                and len(libraries['atom']) >= 2 and multistep)
    result['acquisition_complete'] = acquired
    if not acquired:
        result.update(record_complete=True, status='INSUFFICIENT_FRESH_ACQUISITION',
                      native_records=_checked_literal(oracle.records, check), seconds=time.perf_counter()-began)
        return result
    all_witnesses_accepted = True; cell_results = []
    for spec in document['contexts']:
        check(); started = time.perf_counter()
        compiled, model, setup = _compile_selector_case(spec, modules, oracle, check, limits)
        need(len(oracle.records) <= 512, 'whole mechanism Native query guard')
        case = _case_evidence(spec, compiled, model, setup, check)
        case.update(cells=[], stage_scope='Original unmarked context model; legal licensed axiom receptors. No Graph point is selected in this packet-availability diagnostic.')
        result['contexts'].append(case)
        for cell in document['protocol']['cells']:
            check()
            if cell['context_id'] != spec['id']:
                continue
            mode = cell['mode']; view = cell['view']; library = libraries[mode]
            if view == 'one_mp':
                library = [f for f in library if sum(c['rule'] == 'mp' for c in f['template']['proof']) == 1]
            state = model.initial(); before = copy.deepcopy(state.__dict__); work = {'completed':0}
            pool_started = time.perf_counter()
            pool = ready_pool(model, state, None, None, library, modules['host'], check, limits, work)
            pool_seconds = time.perf_counter()-pool_started
            need(before == state.__dict__ and pool['complete'], 'exact context boundary retained after bounded complete pool')
            selected = {}; packets = pool['packets']
            if packets:
                selected[0] = ['first_packet']
            for index, packet in enumerate(packets):
                check()
                if (sum(c['rule'] == 'mp' for c in packet['checked_primitive_proof']) >= 2
                        and packet['result_formula'] == spec['target']):
                    selected.setdefault(index, []).append('first_two_MP_declared_target_packet')
                    break
            need(len(selected) <= 2, 'fixed Native witness schedule union')
            witnesses = []; packet_native = []
            for index, packet in enumerate(packets):
                check()
                if index not in selected:
                    packet_native.append(dict(packet_ordinal=index, status='NATIVE_UNREQUESTED',
                                              clauses=[], native_record=None, target_match=packet['result_formula']==spec['target']))
                    continue
                need(len(oracle.records) < 512, 'whole mechanism Native query guard before witness')
                proof = packet['checked_primitive_proof']; whole_region = None
                if packet['result_formula'] == spec['target'] and len(proof) == spec['length']:
                    whole_region = verify_region(model, packet['members'], proof, check)
                q = _request(oracle, spec, proof, check, limits,
                    'principal_mechanism_'+spec['id']+'_'+view+'_'+mode+'_'+str(index),
                    target=packet['result_formula'])
                status = _native_status(q, check)
                all_witnesses_accepted = all_witnesses_accepted and status == 'accepted'
                witness = dict(packet_ordinal=index, clauses=selected[index], status=status,
                    target_match=packet['result_formula']==spec['target'],
                    native_record=_checked_literal(q, check), native_limit=limits['native_steps'],
                    whole_region=whole_region,
                    whole_target_certificate_accepted=status=='accepted' and whole_region is not None,
                    scope='Fresh flat blocks=[] Native certificate for THIS packet result formula; partial local packet does not certify the whole declared target region.')
                witnesses.append(witness); packet_native.append(witness)
            row = dict(cell=_checked_literal(cell, check), paired_unit_ids=[f['paired_unit_id'] for f in library],
                pool=pool, pool_seconds=pool_seconds, validation_checks=work['completed'],
                packet_native=packet_native, selected_witnesses=witnesses,
                counts=dict(host_trial_packets=len(packets), distinct_primitive_continuations=pool['distinct_primitive_continuations'],
                    selected_Native_witnesses=len(witnesses), Native_accepted=sum(w['status']=='accepted' for w in witnesses),
                    Native_unknown=sum(w['status']!='accepted' for w in witnesses),
                    Native_unrequested=len(packets)-len(witnesses),
                    whole_target_certificates=sum(w['whole_target_certificate_accepted'] for w in witnesses)),
                scope='Pool quota/work-prefix completion is bounded coverage, not exhaustion of every possible formula binding. All raw packets and failures retained; no backfill after a witness UNKNOWN.')
            case['cells'].append(row); cell_results.append(row)
        case['seconds'] = time.perf_counter()-started
        del model, compiled
    need(len(cell_results) == 16, 'all preregistered context/view/mode cells')
    need(_same_wire(document, original, check), 'complete mechanism input unchanged')
    need(len(oracle.records) <= 512, 'whole mechanism Native query guard at exit')
    result.update(record_complete=True, stage_complete=all_witnesses_accepted,
        status=('MECHANISM_RECORD_COMPLETE' if all_witnesses_accepted else 'MECHANISM_RECORD_COMPLETE_NATIVE_UNRESOLVED'),
        native_records=_checked_literal(oracle.records, check), seconds=time.perf_counter()-began,
        witness_schedule='Union of first packet and first >=2-MP packet with exact declared target, at most2/cell, no retry/backfill.',
        proof_authority='Only selected fresh Nativeaccepted witnesses are admitted local primitive certificates; whole target also requires exact full region. Unrequested/UNKNOWN packets stay unadmitted.',
        population=dict(donors=2, contexts=4, cells=16))
    return result
