from pathlib import Path
import ast
B=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-principal-family-search-20261021/implementation-B')
s=(B/'project_saved_principal_search_v1.py').read_text().replace("SCHEMA = 'D17-principal-family-search-passive-reader-v1'", "SCHEMA = 'D17-principal-family-search-passive-reader-v2'")
s=s.replace("receipt=dict(pin=pin(path),result=row['result'],C_review=row['C_review'],", "receipt=dict(pin=pin(path),plan=row['plan'],result=row['result'],C_review=row['C_review'],")
pos=s.index('\ndef point_trace(')
s=s[:pos]+'''
def failure_phase(worker, science):
    """Classify only the preserved complete failure stack, never lost state."""
    if worker is None or science is not None or worker.get('error') is None:
        return None
    error = worker['error']; stack = error.get('traceback','')
    if (error.get('message') == 'absolute case work deadline'
            and 'in _compile_selector_case' in stack and 'in compile_guards' in stack
            and 'in _read_line' in stack):
        return dict(code='SHARED_COMPILER_NATIVE_SETUP_DEADLINE',
            evidence='Complete saved failure stack: _compile_selector_case -> compile_guards -> Native reply wait; absolute work deadline.',
            scope='Recipient shared setup precedes model return and all four arm dispatches in the frozen driver. No scientific_result is reconstructed; no time or memory phase attribution.')
    return dict(code='NO_RETURNED_SCIENTIFIC_RECORD',
        evidence='Complete saved worker failure; inspect exact error/stage records.',
        scope='The saved record does not identify a returned arm outcome. No proof or state is reconstructed.')

'''+s[pos:]
s=s.replace("science = current['science']; case = None", "science = current['science']; case = None; phase = failure_phase(current['worker'],science)")
s=s.replace("                if current['executed']:\n                        status = 'NO_RETURNED_SEARCH_RECORD_JOB_FAILED_OR_INCOMPLETE'", "                if current['executed']:\n                        status = ('NOT_RUN_SHARED_SETUP_FAILED' if phase is not None\n                                  and phase['code'] == 'SHARED_COMPILER_NATIVE_SETUP_DEADLINE' else\n                                  'NO_RETURNED_SEARCH_RECORD_JOB_FAILED_OR_INCOMPLETE')")
# The predecessor source uses this exact indentation; refusal catches accidental miss.
assert "status = ('NOT_RUN_SHARED_SETUP_FAILED'" in s
s=s.replace("shared_setup_seconds=case['shared_setup_seconds'])", "shared_setup_seconds=case['shared_setup_seconds'],failure_phase=phase)")
s=s.replace("proof_view_index=None,domain_audits=None,trace_joins=None,shared_setup_seconds=None)", "proof_view_index=None,domain_audits=None,trace_joins=None,shared_setup_seconds=None,failure_phase=phase)")
s=s.replace("worker_status=None if worker is None else worker['status'],error=None if worker is None else worker['error'],", "worker_status=None if worker is None else worker['status'],error=None if worker is None else worker['error'],\n                failure_phase=phase,")
s=s.replace("missing_returned_searches=sum(not r['returned'] for r in rows)))", "missing_returned_searches=sum(not r['returned'] for r in rows),\n            returned_pool_packets=sum(r['trace_joins']['returned_pool_packets'] for r in rows if r['trace_joins'] is not None),\n            selected_packets=sum(r['trace_joins']['selected_packet_count'] for r in rows if r['trace_joins'] is not None),\n            preferred_placement_events=sum(r['trace_joins']['preferred_placement_count'] for r in rows if r['trace_joins'] is not None)))")
needle="    return dict(schema=SCHEMA,summary='A fixed-selection recipient-search comparison. Every planned slot is retained; only exact Root-admitted jobs and complete proof gates count as admitted proofs.',"
assert needle in s
replacement='''    returned = sum(row['returned'] for row in slots)
    raw_accepted = sum(row['native_proof_observed'] is True for row in slots)
    point_unknown = sum(row['returned'] and row['method'] != 'S0'
                        and row['search_status'] == 'unknown_search_budget' for row in slots)
    setup_missing = sum(row['execution_status'] == 'NOT_RUN_SHARED_SETUP_FAILED' for row in slots)
    by_method = {row['method']:row for row in summary}
    opaque = {method:[row['metrics']['attempts'] if row['metrics'] is not None else None
                      for row in slots if row['case_id'] == 'context-opaque-equality' and row['method'] == method]
              for method in ('P0','PA','PP')}
    quantified = {method:[row['metrics']['attempts'] if row['metrics'] is not None else None
                          for row in slots if row['case_id'] == 'eval-quantified-01' and row['method'] == method]
                  for method in ('P0','PA','PP')}
    assessment = [
        '%d of64 planned search records returned. The raw final checker observations include%d accepted target-proof occurrences and%d point-search UNKNOWN outcomes; %d slots were not dispatched because shared compiler/Native setup hit the absolute deadline. Whole admission remains a separate gate.' % (returned,raw_accepted,point_unknown,setup_missing),
        'Raw Native-accepted target occurrences out of16 planned slots per method: S0=%d, P0=%d, PA=%d, PP=%d. The two order labels repeat case targets and are not new theorems or stochastic replications.' % tuple(by_method[m]['raw_native_accepted'] for m in METHODS),
        'Opaque equality control, point-placement attempts in order labels0/1: PP=%s, PA=%s, P0=%s. In these saved records principal families give a small local placement-count improvement, not an increase in target-proof coverage.' % (opaque['PP'],opaque['PA'],opaque['P0']),
        'First quantified case, point-placement attempts in order labels0/1: PA=%s, PP=%s, P0=%s. The shared improvement of PA and PP does not isolate a principal-abstraction benefit.' % (quantified['PA'],quantified['PP'],quantified['P0']),
        'Every returned point search on the second equality case ends UNKNOWN within its unchanged local budget; conventional S0 has saved accepted proof observations there. The second quantified case has no dispatched method search, not eight proof rejections.',
        'Saved returned pool packets: PA=%d and PP=%d; selected ordering packets: PA=%d and PP=%d. Larger returned packet counts are not proof gains or completed cluster executions. Exact preferred-placement events appear below, and may later be rolled back.' % (by_method['PA']['returned_pool_packets'],by_method['PP']['returned_pool_packets'],by_method['PA']['selected_packets'],by_method['PP']['selected_packets']),
        'This is fixed selection, not RL training. All point methods share certified markings. There is no matched conventional principal-library arm or marking-off ablation, so these observations do not establish a GCTS-specific, RL or state-of-the-art advantage. Common setup differs from D15/D16; no cross-study timing speedup is claimed.'
    ]
    return dict(schema=SCHEMA,summary='The fixed recipient searches show a small local point-placement improvement, with no principal-versus-atom target-coverage gain in the saved records. All64 slots and the separate Root admission gates remain visible.',
        assessment=assessment,
'''
s=s.replace(needle,replacement.rstrip())
# Parse/compile only. No projector or research callable is executed.
ast.parse(s);compile(s,str(B/'project_saved_principal_search_v2.py'),'exec')
(B/'project_saved_principal_search_v2.py').write_text(s)
h=(B/'principal-family-search-template-v1.html').read_text()
h=h.replace('<h2 id="comparison">All 64 planned search slots</h2>', '<h2>What the saved comparison found</h2>\n<div id="assessment" class="panel"></div>\n<h2 id="comparison">All 64 planned search slots</h2>')
h=h.replace("esc(r.admission.status)+'</td><td>'", "esc(r.admission.status)+(r.failure_phase?'<br><small>'+esc(r.failure_phase.code)+'</small>':'')+'</td><td>'")
h=h.replace('<th>Raw Native accepted observations</th><th>Missing records</th>', '<th>Raw Native accepted observations</th><th>Returned search UNKNOWN</th><th>Missing records</th>')
h=h.replace("r.raw_native_accepted+'</td><td>'+r.missing_returned_searches", "r.raw_native_accepted+'</td><td>'+r.returned_search_unknown+'</td><td>'+r.missing_returned_searches")
h=h.replace("el('case').innerHTML=d.corpus", "el('assessment').innerHTML=d.assessment.map(s=>'<p>'+esc(s)+'</p>').join('');el('case').innerHTML=d.corpus")
(B/'principal-family-search-template-v2.html').write_text(h)
