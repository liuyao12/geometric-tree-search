from pathlib import Path
import ast,copy,difflib,hashlib,json,sys
B=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-principal-family-search-20261021/implementation-B');D=B.parent
old=B/'proof_search_pilot_v15.py'; new=B/'proof_search_pilot_v16.py'; base=B/'predecessor-Sources-v1/proof_search_pilot_v14.py'
def pin(p):
 p=Path(p);body=p.read_bytes();return dict(path=str(p.resolve()),bytes=len(body),sha256=hashlib.sha256(body).hexdigest())
def read(p):return json.loads(Path(p).read_bytes())
def write(n,x):
 p=B/n
 assert not p.exists(),str(p)
 p.write_text(json.dumps(x,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
a=old.read_text();b=new.read_text(); c=base.read_text(); ta=ast.parse(a);tb=ast.parse(b);compile(b,str(new),'exec')
fa={x.name:ast.dump(x,include_attributes=False) for x in ta.body if isinstance(x,(ast.FunctionDef,ast.ClassDef))}
fb={x.name:ast.dump(x,include_attributes=False) for x in tb.body if isinstance(x,(ast.FunctionDef,ast.ClassDef))}
changed=[n for n in fa if fa[n]!=fb[n]];added=[n for n in fb if n not in fa]
assert changed==['_fixed_donor_evidence','_fixed_verify_acquisition','run_fixed_stage']
assert added==['_fixed_fragment_resolution']
for name,left,right in [('proof-search-v15-v16-raw.patch',a,b),('proof-search-v14-v16-cumulative-raw.patch',c,b)]:
 nd=list(difflib.ndiff(left.splitlines(True),right.splitlines(True)))
 assert ''.join(difflib.restore(nd,1))==left and ''.join(difflib.restore(nd,2))==right
 (B/name).write_text(''.join(difflib.unified_diff(left.splitlines(True),right.splitlines(True),fromfile='predecessor.py',tofile='proof_search_pilot_v16.py')))
negative=pin(D/'review-C/typed-fixed-family-Source-negative-v15.json')
write('AST-delta-v2.json',dict(schema='D17-fixed-search-AST-delta-v2',status='SOURCE_ONLY_UNRUN',predecessor=pin(old),entry=pin(new),base_predecessor=pin(base),
 changed_existing=changed,added=added,removed=[],unchanged=[n for n in fa if fa[n]==fb[n]],
 constants_changed=['VERSION','FIXED_STAGE_SCHEMA'],
 exact_delta='One derived profile/Native-resolution annotation helper; donor projection carries resolution; acquisition qualification requires all profile fragments accepted; sealed verifier refuses every unresolved profile and strictly reconstructs resolution. No inherited acquirer/search/miner/pairing/final-gate changes.',
 v15_negative=negative,raw_inverse_exact=True,raw_inverse_method='stdlib difflib ndiff/restore on raw Source only',raw_patch=pin(B/'proof-search-v15-v16-raw.patch'),cumulative_patch=pin(B/'proof-search-v14-v16-cumulative-raw.patch'),scientific_calls=0))
m=read(B/'manual-conformance-v1.json');m['schema']='D17-fixed-principal-family-search-manual-v2';m['predecessor_manual']=pin(B/'manual-conformance-v1.json');m['v15_negative']=negative
m['profile_resolution_correction']=[
 'Frozen v15 and its negative are retained. The v15 acquisition threshold could ignore an eligible fragment Native UNKNOWN while other families still met the class threshold; v16 corrects this actual Source defect.',
 'Every fresh candidate gets exact boolean profile_eligible derived from its complete primitive proof: axiom/MP only and at least one MP. Native UNKNOWN remains profile_eligible=True. The legacy eligible flag retains its narrower acquired-family meaning and is never used to decide profile membership.',
 'native_resolution is exact accepted/unknown_step_budget/unknown_space_budget for profile members, or OUTSIDE_DECLARED_PROFILE for axiom-only/outside-profile rows. Original ordinal/kind/reason/proof/Native record remain unchanged.',
 'A per-donor fragment_resolution lists all unresolved profile ordinals/statuses and separate derived profile/accepted counts. Both donor searches still run and all records remain inspectable. No profile UNKNOWN may produce any acquisition export, stage qualification or downstream shorter-library admission.',
 'Every accepted upstream candidate is independently shape-classified from its reconstructed full/ancestor proof. The sealed verifier requires Native accepted for every profile, exact metadata and complete accepted-resolution receipt; it has no UNKNOWN-continue path.',
 'The fixed export schema is v2. Full donor record hashes and slim projections are calculated after candidate annotations and the resolution receipt. Root admission must bind exactly those source records and owned queries.',
 'This correction adds no fixed expected family/certificate count; it accepts only all profile-eligible fragments from whatever genuinely discovered complete donor proofs satisfy the original statement and gates. No retries or hand-authored route.']
m['scientific_calls']=0;write('manual-conformance-v2.json',m)
p=read(B/'fixed-stage-policy-v1.json');p['schema']='D17-fixed-family-search-policy-v2';p['predecessor_policy']=pin(B/'fixed-stage-policy-v1.json');p['v15_negative']=negative
p['acquisition_export_only_if']='Both whole donors accepted AND every shape-profile-eligible full/ancestor fragment Native accepted, plus at least2paired atom units and one multi-MP unit. UNKNOWN stays in-profile/unresolved and blocks export; complete raw rows retained.'
p['profile_fields']={'profile_eligible':'exact bool derived from complete axiom/MP-with-MP fragment shape, independent of admission','native_resolution':'exact declared Native status or OUTSIDE_DECLARED_PROFILE','legacy_eligible':'unchanged inherited acquired-family admission flag, not profile membership','fragment_resolution':'complete per-donor derived profile/accepted counts and every unresolved ordinal/status'}
write('fixed-stage-policy-v2.json',p)
api=read(B/'API-v1.json');api['schema']='D17-fixed-principal-family-search-API-v2';api['entry']=pin(new);api['predecessor']=pin(old);api['base_predecessor']=pin(base);api['predecessor_API']=pin(B/'API-v1.json');api['v15_negative']=negative
api['export_schema']='gcts-principal-family-search-stage-export-v2';api['fixed_stage_policy']=pin(B/'fixed-stage-policy-v2.json')
api['donor_evidence_fields']=['spec','search','proof_check','candidates','fragment_resolution','full_record_sha256']
api['candidate_resolution_fields']=p['profile_fields'];api['acquisition_qualification']=p['acquisition_export_only_if']
api['hash_binding']='full_record_sha256 and outcome.record_sha256 are computed only after annotation/resolution fields are attached. Root seal must join exact current owned record/projection and every owned Native record before downstream admission.'
api['preservation']['inherited_acquirer_AST_unchanged']=True;api['preservation']['search_and_final_gates_unchanged_from_v15']=True
write('API-v2.json',api)
controls=read(B/'prospective-controls-v1.json');controls['schema']='D17-fixed-stage-prospective-obligations-v2';controls['predecessor_bank']=pin(B/'prospective-controls-v1.json');controls['v15_negative']=negative
controls['new_stage_review_recipes'] += [
 'Exact v15 regression recipe: both whole donors accepted; full/final chain and generic-MP fragments accepted; proper one-MP chain ancestor Native UNKNOWN. Retain this row with profile_eligible=True and unknown native_resolution; qualified=False, stage_complete=False, export=None even if remaining paired units>=2 and multi-MP.',
 'Coherent tamper of that unresolved profile to legacy eligible=False must not allow export or sealed reconstruction; membership is freshly derived from complete fragment shape.',
 'Reject false/nonbool profile_eligible, wrong accepted/unknown/outside native_resolution, omitted unresolved ordinal or changed resolution counts, even with otherwise valid accepted certificates.',
 'Require full_record_sha256/owned source record/slim donor projection join AFTER metadata annotation; original ordinal/reason/query/proof retained.'
]
write('prospective-controls-v2.json',controls)
write('static-validation-v2.json',dict(schema='D17-Source-static-validation-v2',entry=pin(new),predecessor=pin(old),python=pin(sys.executable),AST_parsed=True,unused_compile=True,
 AST_changed_existing=changed,AST_added=added,unchanged_callable_count=len(fa)-len(changed),predecessor_callable_count=len(fa),new_callable_count=len(fb),
 raw_delta_inverse_exact=True,scientific_modules_imported=0,scientific_functions_called=0,checks_or_fixtures_executed=0,actuals=0,
 scope='Only stdlib Source/AST/JSON/raw-byte authoring; unused code object never executed. No runtime qualification or predicted fit.'))
items=['proof_search_pilot_v16.py','proof-search-v15-v16-raw.patch','proof-search-v14-v16-cumulative-raw.patch','AST-delta-v2.json','manual-conformance-v2.json','fixed-stage-policy-v2.json','API-v2.json','prospective-controls-v2.json','static-validation-v2.json']
write('manifest-v2.json',dict(schema='D17-B-frozen-Source-manifest-v2',files=[pin(B/n) for n in items],retained_predecessor_manifest=pin(B/'manifest-v1.json'),retained_predecessor_handoff=pin(B/'handoff-v1.json'),independent_v15_negative=negative,
 dependencies=read(B/'manifest-v1.json')['dependencies'],scientific_calls=0,actual_authority=False))
write('handoff-v2.json',dict(schema='D17-B-fixed-search-handoff-v2',status='FROZEN_SOURCE_ONLY_PENDING_INDEPENDENT_REVIEW',entry=pin(new),API=pin(B/'API-v2.json'),manual=pin(B/'manual-conformance-v2.json'),policy=pin(B/'fixed-stage-policy-v2.json'),
 raw_patch=pin(B/'proof-search-v15-v16-raw.patch'),cumulative_patch=pin(B/'proof-search-v14-v16-cumulative-raw.patch'),AST_delta=pin(B/'AST-delta-v2.json'),manifest=pin(B/'manifest-v2.json'),controls=pin(B/'prospective-controls-v2.json'),
 retained_v15_handoff=pin(B/'handoff-v1.json'),v15_negative=negative,L_handoff=api['input_contract_handoff'],C_calibration_handoff=api['setup_calibration_handoff'],
 exact_delta='Preserved v15; explicit independent profile-membership vs Native-admission metadata and complete resolution; every profile fragment must be accepted to export or revalidate. One new helper, three existing D17 helper/body changes plus VERSION/export-schema/docs. All inherited acquisition/search/pool/mining/pairing/marking/final-gate ASTs unchanged.',
 remaining=['Independent exact v16 and full composition review.','Root seal must join post-annotation donor record hashes/projections and every actual owned Native record.','Whole-plan review/grants/serial actual barrier and actual resource/search outcomes remain Root-owned and absent.'],scientific_calls=0,actuals=0,grants=0,execution_authority=False,tools_stopped_after_handoff=True))
for n in ['proof_search_pilot_v16.py','API-v2.json','handoff-v2.json','manifest-v2.json']:
 print(json.dumps(pin(B/n)))
