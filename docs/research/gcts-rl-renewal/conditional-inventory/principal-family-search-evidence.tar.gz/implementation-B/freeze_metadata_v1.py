from pathlib import Path
import ast, difflib, hashlib, json, shutil, sys
R=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs')
D=R/'gcts-principal-family-search-20261021'; B=D/'implementation-B'
P=R/'gcts-principal-receptor-families-20261021/implementation-B'
def pin(p):
    p=Path(p); body=p.read_bytes(); return dict(path=str(p.resolve()),bytes=len(body),sha256=hashlib.sha256(body).hexdigest())
def write(name,x):
    (B/name).write_text(json.dumps(x,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
def read(p): return json.loads(Path(p).read_bytes())
old=P/'proof_search_pilot_v14.py'; new=B/'proof_search_pilot_v15.py'
a=old.read_text(); b=new.read_text(); ta=ast.parse(a); tb=ast.parse(b)
compile(b,str(new),'exec')
fa={x.name:ast.dump(x,include_attributes=False) for x in ta.body if isinstance(x,(ast.FunctionDef,ast.ClassDef))}
fb={x.name:ast.dump(x,include_attributes=False) for x in tb.body if isinstance(x,(ast.FunctionDef,ast.ClassDef))}
changed=[n for n in fa if n in fb and fa[n]!=fb[n]]; added=[n for n in fb if n not in fa]
assert changed==['_compile_selector_case','_verify_native_evidence']
assert added==['_fixed_upstream','_fixed_controls','_fixed_donor_evidence','_fixed_verify_acquisition','run_fixed_stage']
assert all(fa[n]==fb[n] for n in ('search_points','search_points_selected','search_symbolic','search_symbolic_selected','ready_pool','run_stage','run_mechanism','_paired_receptor_libraries','_mine_receptor_pair','_acquire_selector_donor','_mark_selector_model','_finish_selector_proof'))
pre=B/'predecessor-Sources-v1'; pre.mkdir(exist_ok=True)
shutil.copyfile(old,pre/old.name)
for row in read(P/'API-v1.json')['policies']:
    shutil.copyfile(row['path'],pre/Path(row['path']).name)
patch=''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='proof_search_pilot_v14.py',tofile='proof_search_pilot_v15.py'))
(B/'proof-search-v14-v15-raw.patch').write_text(patch)
nd=list(difflib.ndiff(a.splitlines(True),b.splitlines(True)))
assert ''.join(difflib.restore(nd,1))==a and ''.join(difflib.restore(nd,2))==b
oldapi=read(P/'API-v1.json')
ls=D/'diagnostics-L'; cs=D/'review-C'
controls=read(ls/'API-v3.json')
limits=oldapi['limits']; roles=oldapi['roles']
source_additions=[pin(ls/'principal_search_corpus_contract_v1.py'),pin(cs/'reference_setup_calibration_v1.py')]
write('AST-delta-v1.json',dict(schema='D17-fixed-search-AST-delta-v1',status='SOURCE_ONLY',predecessor=pin(old),entry=pin(new),
 changed_existing=changed,added=added,removed=[n for n in fa if n not in fb],
 unchanged=[n for n in fa if n in fb and fa[n]==fb[n]],
 change_scope={'_compile_selector_case':'Full v3 verification for every fresh production model; no large per-model original-v1 differential. Explicit not-performed metadata points to separate acquisition calibration.',
 '_verify_native_evidence':'Only receipt prose replaces D16-specific acquisition wording with fresh-acquisition scope; validation AST body otherwise unchanged.'},
 raw_patch=pin(B/'proof-search-v14-v15-raw.patch'),raw_inverse_verified_by='stdlib difflib ndiff/restore on raw Source only; no Source execution',
 source_compile='AST parse and unused compile only; no scientific import or callable invocation',scientific_calls=0))
write('manual-conformance-v1.json',dict(schema='D17-fixed-principal-family-search-manual-v1',status='SOURCE_ONLY_UNRUN',
 factor=r'Compare atom-name versus principal-DAG abstraction at the same paired atom-equivalence units. Principal is relative to the unchanged exact-donor-formula premise-port quotient and fixed DAG; it can remove incidental constructor and atom-equality constraints, but not constraints forced by $F_{\mathrm{imp}}=\operatorname{Imp}(F_{\mathrm{ant}},F_{\mathrm{out}})$. Generic MP already exists in the atom inventory.',
 population='One fresh two-donor acquisition plus sixteen recipient jobs (eight fixed public authored cases, two counterbalanced deterministic order labels), four methods per evaluation job;64 planned search slots. No RL retraining or old result adoption.',
 ownership='Only Root owns exact actual grants, files, process/custody, native request records and acquisition seals. Raw executable/State/Graph owners are not reconstructed from exports. Source exceptions and Root/foreign callbacks are not caught by the new stage helpers.',
 acquisition=['Both donor searches run from statement-only input; every complete or unknown donor outcome and full/ancestor candidate record is retained.',
 'Whole donors need fresh Host, full original point region and Native blocks=[] acceptance. Eligible axiom/MP fragments need fresh Host and Native for the exact remapped proof before either abstraction is mined.',
 'Both dual families and independent full typing receipt are retained per accepted fragment. All atom-class members must agree on the principal structural interface/DAG. No principal structural coalescence or open receptor cuts.',
 'Both donors must be whole accepted, with at least two paired units and a multi-MP unit, before export. Unknown is never accepted or used to shorten acquisition.',
 'Later evaluation checks the exact Root envelope/export digest, reconstructs every full/ancestor candidate, freshly checks Host and both miners/independent typing, rebuilds all wrappers and exact paired order. Identical accepted Native records are certified reuse; no Native replay. Root must additionally bind every query and slim donor projection to actual acquisition records before seal.'],
 search=['S0 uses unchanged conventional primitive search without a library. P0 uses unchanged marked point search without clusters. PA/PP use the same unchanged selected-point search with fixed mode and respective paired library.',
 'Every P method uses one common independently checked certified marking overlay. All methods share the same original primitive model/compiled grammar, candidate keys/guard variants and final acceptance gates.',
 'The Graph alone selects DEAD, FORCED or earliest-generation BRANCH, with degree only breaking generation ties; proposals only reorder primitive alternatives at that selected point.',
 'Every chosen pool packet is Host/context/trial checked, with unchanged saturated-hint abstention, exact-formula novelty tiers, full primitive fallback, rollback, two full domain audits, owned cutoff traceback cleanup and shared Graph storage scope.',
 'The numeric weights=[0.0]*9 object is an untrained fixed-interface argument. Fixed mode always chooses the first returned packet or final ABSTAIN when no packets exist. No random choice, policy update or family/theorem-ID feature is introduced.',
 'Seed labels0/1 only designate mirrored arm orders, not stochastic replications. Packet selection/activation is not completed macro execution or goal proof.'],
 setup=['Every fresh real model receives the complete corrected-v3 placement/dictionary/domain/incidence reference gate, the exact indexed word evidence correspondence and no-block/no-assumption check.',
 'Original-v1 versus production-v3 is retained as a separate same-model three-row synthetic acquisition control plus original48 word and40 encoding controls. It is not a universal equivalence proof and not a per-model differential.',
 'Unused grounded Native block-registry diagnostic is uniformly omitted. Ordering-only context checks and final Native blocks=[] gates are unchanged. Common setup differs from D15/D16; no direct end-to-end speed attribution across those studies.'],
 acceptance='A found proof is freshly Host checked, full-region verified and submitted to Native blocks=[]. Rejected actual proof is a fault; recognized Native unknown leaves HOST_REGION_ACCEPTED_NATIVE_UNKNOWN and stage incomplete. No-proof search UNKNOWN is a completed bounded outcome, not a theorem rejection. Job-record completion, stage completion and Root whole admission are separate.',
 accounting='Original600 primitive extensions/2s local clock includes search/audits/pool work as before. Root whole Native512/1e9,160work/180positive/210custody/225fallback,1GiB,128MiB physical with9MiB reserve,48MiB result,400m callbacks and logs4MiB are unchanged. Acquisition observer cost is carried once per cold comparison; aggregate study totals deduplicate acquire-0. Entry clocks exclude later serialization/Native-close/custody and are labeled separately.',
 limits='No Source-based fit, speed, success or GCTS/RL advantage prediction. Existing Turtle/Penrose/Peano/Hilbert/universal Wang goals remain outside this bounded Native/point experiment.',
 open=['Full independent B composition/custody/whole-plan review required before any new exact grant.',
 'Root seal must join exact full donor records/projection hashes and accepted fragment/whole owned oracle records, fixed Native identities and unchanged limits before downstream intake.',
 'Actual time/memory/output fit and all64 search outcomes remain unmeasured. Failure or UNKNOWN prevents unsupported admissions; no old partial or historical library can be used as rescue.'],scientific_calls=0,actual_authority=False))
recipes=read(ls/'protocol-proposal-v3.json')['job_recipes']
write('fixed-stage-policy-v1.json',dict(schema='D17-fixed-family-search-policy-v1',status='PROSPECTIVE_SOURCE_ONLY',
 accepted_parent_authorization='Root approved two fresh donors,17 jobs, productionv3-only large setup plus tinyv1/v3 calibration, uniform omission of unused registry diagnostic; no scientific actual authorized by this file.',
 predecessor_entry=pin(old),inherited_policies=[pin(pre/Path(x['path']).name) for x in oldapi['policies']],
 inherited_ordering_scope='Context-checked primitive ordering only. No family becomes a Native-accepted general inference rule. Every final recipient proof is flat and freshly Native checked with blocks=[].',
 policies_unchanged=True,recipes=recipes,methods={
 'S0':'Unchanged conventional search, no cluster library, no auxiliary marking overlay.',
 'P0':'Unchanged point search with common certified marks, no cluster library.',
 'PA':'Same marked points and fixed complete bounded ready_pool using atom paired units.',
 'PP':'Same marked points and fixed complete bounded ready_pool using principal paired units.'},
 acquisition_export_only_if='Both fresh donors whole accepted plus at least2paired units and one multi-MP unit; complete candidates/provenance retained.',
 common_setup_factor='Complete production v3 reference gate on every fresh model; tiny original-v1/v3 same-model acquisition calibration; omit unused diagnostic grounded registry uniformly.',
 old_results_mutated=False,old_qualification_reused=False,RL=False,actual_authority=False,scientific_calls=0))
api=dict(schema='D17-fixed-principal-family-search-API-v1',status='SOURCE_ONLY_UNRUN',entry=pin(new),predecessor=pin(old),predecessor_API=pin(P/'API-v1.json'),
 execution_entry='run_fixed_stage(document, upstream_payloads, *, stage, stage_id, check, limits, modules, oracle)',
 stages=['acquire','evaluate'],stage_ids=[x['stage_id'] for x in recipes],roles=roles,limits=limits,outer=oldapi['outer'],
 input={'acquisition':pin(ls/'acquisition-inputs-v1.json'),'evaluation':pin(ls/'evaluation-inputs-v1.json')},
 input_contract_source=source_additions[0],input_contract_API=pin(ls/'API-v3.json'),input_contract_handoff=pin(ls/'handoff-v3.json'),
 setup_calibration_source=source_additions[1],setup_calibration_API=pin(cs/'reference-setup-calibration-API-v1.json'),setup_calibration_handoff=pin(cs/'reference-setup-calibration-handoff-v1.json'),
 runtime_additions=source_additions,
 model_source=oldapi['model_source'],graph_source=oldapi['graph_source'],graph_reference_source=oldapi['graph_reference_source'],
 original_word_reference_source=oldapi['original_word_reference_source'],production_word_reference_source=oldapi['new_word_reference_source'],
 principal_module=oldapi['principal_module'],independent_principal_reference_source=oldapi['independent_principal_reference_source'],
 policies=[pin(pre/Path(x['path']).name) for x in oldapi['policies']],fixed_stage_policy=pin(B/'fixed-stage-policy-v1.json'),
 upstream={'acquire':{'acquisition':None,'receipt':None},'evaluate':'exact keys acquisition (complete full sealed export) and receipt (one exact Root admitted envelope); no policy field',
 'receipt_fields':['stage_id','stage','resource_admitted','stage_complete','plan','result','header','terminal','observer','export_sha256','whole_seconds','whole_peak_bytes','prior_cost_receipts'],
 'receipt_stage':'acquire-0/acquire, resource_admitted=True, stage_complete=True, prior_cost_receipts=[]',
 'root_boundary':'Root must read/verify complete plan/result/header/terminal/observer pins and exact actual Native query records before passing scientific export. Entry independently checks receipt shape/cost/export digest and complete scientific reconstruction. No new identity reconstructed from IDs.'},
 export_schema='gcts-principal-family-search-stage-export-v1',acquisition_export_fields=['schema','stage','stage_id','acquisition_document','donor_ids','donor_outcomes','donor_evidence','certificates','libraries','pairing','native_certificate_identity','pairing_policy','qualified','scope'],
 donor_evidence_fields=['spec','search','proof_check','candidates','full_record_sha256'],donor_search_projection_fields=['status','proof'],
 record_locations={'acquire':'records in donor manifest order; full case/model/search/check/candidates; certificates/libraries/pairing also present even if acquisition insufficient.',
 'evaluate':'records[0] full spec/compiler/indexed word model/reference/marking plus arms in exact declared method order; each arm has full search trace/proof/placements/metrics and proof_check.',
 'proof':'records[*].search.proof for donor; records[0].arms[*].search.proof for recipient. Formula rows and command/guard tile keys are literal primitive certificates.',
 'm_values':'records[*].model exact word dictionary/placements; evaluation records[0].marking exact auxiliary assignments/certificates; selected keys refer to full model evidence.',
 'native':'native_records includes complete current owned query records; per-proof proof_check.native_record and acquisition certificate native_record copied literally. Root binds identity and membership.'},
 completion={'job_record_complete':'True only at normal end; no guarantee Root resource admission.', 'stage_complete':'Acquire qualification or all4 searches returned with no candidate left Native unknown; not all goals proved.',
 'all_four_searched':'Evaluation only; true after all four bounded searches returned.', 'resource_admitted':'False placeholder; actual Root terminal+observer gates alone admit.'},
 cost='cumulative_costs carries unique direct acquire-0 observer sample, current entry seconds separately; do not sum the shared acquisition sixteen times in study totals.',
 selector='Untrained numeric interface weights=[0.0]*9, mode=fixed; no policy history/export/update and no RL claim.',
 setup='Production v3 gate on every fresh real model, C same-model v1/v3 tiny calibration acquisition-only. Uniform unused registry diagnostic omitted and labeled; not comparable to old end-to-end setup.',
 unlaunched_entries=['run_pilot','run_stage','run_mechanism'],
 preservation={'unchanged_search_functions':True,'unchanged_pairing_and_typing':True,'old_run_stage_AST_unchanged':True,'old_run_mechanism_AST_unchanged':True,'shared_setup_delta_explicit':True},
 actual_authority=False,scientific_calls=0,grants=0)
write('API-v1.json',api)
write('prospective-controls-v1.json',dict(schema='D17-fixed-stage-prospective-obligations-v1',status='UNRUN',
 executed_controls_in_future={'acquisition':'Inherited tiny search diagnostics;23 numeric,48 word,22 Graph,40 encoding,53 principal,24 new corpus controls and one separate tiny full v1/v3 differential. No controls have run in this authoring turn.',
 'evaluation':'Inherited tiny search diagnostics;23 numeric,48 word,22 Graph,40 encoding,53 principal controls. No acquisition body controls or large v1 differential rerun.'},
 new_stage_review_recipes=[
 'Reject missing/extra upstream key or policy field.', 'Reject nonempty acquire upstream; require acquire-0.',
 'Reject incomplete/resource-failed/wrong-stage/duplicate/cumulative receipt or changed export digest.',
 'Reject old D16 export schema and stage population.', 'Preserve both donor UNKNOWN outcomes; no partial library export.',
 'Reject missing/reordered/extra full or ancestor candidate.', 'Reject bool candidate ordinal/source row or changed ancestry/proof/target.',
 'Reject unknown/rejected actual fragment as authority; rejected faults, unknown retained without family.',
 'Reject altered whole/fragment Native request/proof/theory/target/blocks/query/digest or limit.',
 'Reject altered dual family, independent typing or paired inner wrapper; preserve all atom class multiplicities.',
 'Reject principal structural coalescence, trimmed certificate list or changed paired order.',
 'Require complete v3 gate on every real model and independent marking overlay check.',
 'Require exactly four methods in literal mirrored order, common model/markings and unchanged fixed numeric interface.',
 'Preserve primitive candidate multiplicity, Graph point authority, full fallback and rollback.',
 'Keep no-proof search UNKNOWN separate from final Native UNKNOWN; latter stage incomplete.',
 'Keep all fresh Host/fullregion/Native blocks=[] final proof gates; rejected actual proof faults.',
 'Reject input/upstream/library mutation; keep Root/foreign error identity propagation.',
 'Charge direct shared acquisition once and current entry separately; no predicted whole fit.'
 ],
 scope='Declarative review/actual obligations only. These recipes are not claimed executed tests, automatic PASS, or a substitute for Root whole review.',scientific_calls=0))
write('static-validation-v1.json',dict(schema='D17-Source-static-validation-v1',entry=pin(new),predecessor=pin(old),python=pin(sys.executable),
 AST_parsed=True,unused_compile=True,AST_changed_existing=changed,AST_added=added,
 unchanged_callable_count=len(fa)-len(changed),predecessor_callable_count=len(fa),new_callable_count=len(fb),
 raw_delta_inverse_exact=True,scientific_modules_imported=0,scientific_functions_called=0,checks_or_fixtures_executed=0,actuals=0,
 scope='Only stdlib Source/AST/JSON/raw-byte authoring; no code object executed. Claims are static Source facts, not runtime qualification.'))
# Remove the mutable one-time Source-authoring draft; no frozen predecessor is changed.
(B/'author_v15.py').unlink(missing_ok=True)
items=['proof_search_pilot_v15.py','proof-search-v14-v15-raw.patch','AST-delta-v1.json','manual-conformance-v1.json','fixed-stage-policy-v1.json','API-v1.json','prospective-controls-v1.json','static-validation-v1.json']
write('manifest-v1.json',dict(schema='D17-B-frozen-Source-manifest-v1',files=[pin(B/n) for n in items]+[pin(x) for x in sorted(pre.iterdir())],
 dependencies=source_additions+[pin(P/'principal_receptor_families_v1.py'),pin(R/'gcts-principal-receptor-families-20261021/review-C/principal_family_reference_v1.py')],scientific_calls=0,actual_authority=False))
write('handoff-v1.json',dict(schema='D17-B-fixed-search-handoff-v1',status='FROZEN_SOURCE_ONLY_PENDING_INDEPENDENT_REVIEW',
 entry=pin(new),API=pin(B/'API-v1.json'),manual=pin(B/'manual-conformance-v1.json'),policy=pin(B/'fixed-stage-policy-v1.json'),
 raw_patch=pin(B/'proof-search-v14-v15-raw.patch'),AST_delta=pin(B/'AST-delta-v1.json'),manifest=pin(B/'manifest-v1.json'),controls=pin(B/'prospective-controls-v1.json'),
 L_handoff=pin(ls/'handoff-v3.json'),C_calibration_handoff=pin(cs/'reference-setup-calibration-handoff-v1.json'),
 exact_delta='Version/doc/imports; complete production-v3-only setup, generic fresh-acquisition receipt scope text;5new fixed stage helpers. Every other inherited function/class AST unchanged, including all search/pool/marking/typing/pairing/final-gate and old run_stage/run_mechanism bodies.',
 whole_population='Two freshly searched donors;16later evaluation jobs×4methods=64slots on eight original bounds. No scientific invocation or old export adoption.',
 remaining=['Independent Source/whole review and exact Root acquisition seal/projection/native-query joins.','Fresh exact grants and serial actual barrier are Root-owned and absent.','Actual time/memory/output fit and recipient-search outcomes unmeasured.'],
 scientific_calls=0,actuals=0,grants=0,execution_authority=False,tools_stopped_after_handoff=True))
print(json.dumps({n:pin(B/n) for n in ['proof_search_pilot_v15.py','API-v1.json','handoff-v1.json','manifest-v1.json']},indent=2))
