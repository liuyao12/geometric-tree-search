from pathlib import Path
import ast
B=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-principal-family-search-20261021/implementation-B')
s=(B/'proof_search_pilot_v15.py').read_text()
s=s.replace("VERSION = 'native-word-point-principal-family-search-pilot-v15'", "VERSION = 'native-word-point-principal-family-search-pilot-v16'")
s=s.replace("D17 v15 adds a fixed recipient-search stage", "D17 v16 adds a fixed recipient-search stage")
s=s.replace("search=dict(status=record['search']['status'], proof=record['search']['proof']),\n        proof_check=record['proof_check'], candidates=record['candidates'],", "search=dict(status=record['search']['status'], proof=record['search']['proof']),\n        proof_check=record['proof_check'], candidates=record['candidates'],\n        fragment_resolution=record['fragment_resolution'],")
pos=s.index('\ndef _fixed_donor_evidence(')
s=s[:pos]+'''
def _fixed_fragment_resolution(record, check):
    """Classify profile membership independently of Native admission.

    The inherited raw eligible flag records acquisition, not shape membership.
    UNKNOWN therefore stays profile_eligible=True and prevents any export.
    """
    count = 0; accepted = 0; unresolved = []
    for candidate in record['candidates']:
        check(); proof = candidate['proof']
        profile = (all(row['rule'] in ('axiom','mp') for row in proof)
                   and any(row['rule'] == 'mp' for row in proof))
        candidate['profile_eligible'] = profile
        if not profile:
            need(candidate['eligible'] is False and candidate['native_record'] is None,
                 'outside-profile raw candidate has no acquisition authority')
            candidate['native_resolution'] = 'OUTSIDE_DECLARED_PROFILE'
            continue
        count += 1; status = _native_status(candidate['native_record'],check)
        candidate['native_resolution'] = status
        need(candidate['eligible'] is (status == 'accepted'),
             'profile membership separate from actual Native acquisition')
        if status == 'accepted':
            accepted += 1
        else:
            unresolved.append(dict(candidate_ordinal=candidate['ordinal'],native_status=status))
    return dict(schema='fixed-acquisition-fragment-resolution-v1',complete=True,
                profile_eligible_count=count,native_accepted_count=accepted,unresolved=unresolved,
                all_profile_fragments_accepted=not unresolved)

'''+s[pos:]
s=s.replace("{'spec','search','proof_check','candidates','full_record_sha256'}", "{'spec','search','proof_check','candidates','fragment_resolution','full_record_sha256'}")
s=s.replace("'host_check','native_record','family'}\n            need(type(candidate)", "'host_check','native_record','family','profile_eligible','native_resolution'}\n            need(type(candidate)")
s=s.replace("and _same_wire(candidate['ancestry'],ancestry,check), 'ordered exact remapped candidate')", "and _same_wire(candidate['ancestry'],ancestry,check)\n                 and candidate['profile_eligible'] is eligible, 'ordered exact remapped candidate/profile')")
s=s.replace("and candidate['host_check'] is None and candidate['native_record'] is None and candidate['family'] is None,\n                     'all ineligible", "and candidate['host_check'] is None and candidate['native_record'] is None and candidate['family'] is None\n                     and type(candidate['native_resolution']) is str and candidate['native_resolution'] == 'OUTSIDE_DECLARED_PROFILE',\n                     'all ineligible")
s=s.replace("            if status != 'accepted':\n                need(candidate['eligible'] is False and candidate['reason'] == 'Native_unknown_fragment'\n                     and candidate['family'] is None, 'unknown fragment never acquires a family')\n                continue\n            need(candidate['eligible'] is True", "            need(status == 'accepted' and type(candidate['native_resolution']) is str\n                 and candidate['native_resolution'] == status,\n                 'every profile-eligible fragment must be Native accepted before sealed reuse')\n            need(candidate['eligible'] is True")
s=s.replace("        expected_outcome = dict(id=spec['id']", "        expected_resolution = dict(schema='fixed-acquisition-fragment-resolution-v1',complete=True,\n            profile_eligible_count=eligible_count,native_accepted_count=eligible_count,unresolved=[],\n            all_profile_fragments_accepted=True)\n        need(_same_wire(evidence['fragment_resolution'],expected_resolution,check),\n             'complete independent accepted-profile resolution reconstruction')\n        expected_outcome = dict(id=spec['id']")
s=s.replace("certificates = []; outcomes = []; evidence = []\n        for spec in active_doc['donors']:", "certificates = []; outcomes = []; evidence = []; all_fragments_accepted = True\n        for spec in active_doc['donors']:")
mark=s.index("\nFIXED_STAGE_SCHEMA =")
s=s[:mark]+s[mark:].replace("            result['records'].append(record); certificates.extend(acquired)\n            outcomes.append", "            record['fragment_resolution'] = _fixed_fragment_resolution(record,check)\n            all_fragments_accepted = (all_fragments_accepted and\n                                      record['fragment_resolution']['all_profile_fragments_accepted'])\n            result['records'].append(record); certificates.extend(acquired)\n            outcomes.append")
s=s.replace("qualified = (all(o['whole_native_accepted'] for o in outcomes) and len(libraries['atom']) >= 2", "qualified = (all(o['whole_native_accepted'] for o in outcomes) and all_fragments_accepted\n                     and len(libraries['atom']) >= 2")
s=s.replace("result.update(libraries=libraries,pairing=pairing,certificates=certificates,qualified=qualified,\n                      status='PAIRED_ACQUISITION_COMPLETE' if qualified else 'INSUFFICIENT_ACQUISITION',", "result.update(libraries=libraries,pairing=pairing,certificates=certificates,qualified=qualified,\n                      all_profile_fragments_accepted=all_fragments_accepted,\n                      status=('PAIRED_ACQUISITION_COMPLETE' if qualified else\n                              ('UNRESOLVED_ACQUISITION_FRAGMENTS' if not all_fragments_accepted else 'INSUFFICIENT_ACQUISITION')),")
# Confirm no inherited acquisition or search function was edited by a broad replacement.
a=ast.parse((B/'proof_search_pilot_v15.py').read_text()); b=ast.parse(s)
fa={x.name:ast.dump(x,include_attributes=False) for x in a.body if isinstance(x,(ast.FunctionDef,ast.ClassDef))}
fb={x.name:ast.dump(x,include_attributes=False) for x in b.body if isinstance(x,(ast.FunctionDef,ast.ClassDef))}
changed=[n for n in fa if n in fb and fa[n]!=fb[n]]
assert changed==['_fixed_donor_evidence','_fixed_verify_acquisition','run_fixed_stage'],changed
assert [n for n in fb if n not in fa]==['_fixed_fragment_resolution']
compile(s,str(B/'proof_search_pilot_v16.py'),'exec')
(B/'proof_search_pilot_v16.py').write_text(s)
