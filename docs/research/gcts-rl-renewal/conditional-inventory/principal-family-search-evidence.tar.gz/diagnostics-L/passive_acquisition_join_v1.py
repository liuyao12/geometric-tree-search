"""Passive D17 complete acquisition joins. No scientific imports or replay.

Return a candidate report only. Root must obtain independent complete actual
review before writing its separately owned admission/envelope. This module
never seals, writes a report, reruns a proof, mines a family or adopts a partial.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path
import time

VERSION = 'D17-passive-complete-acquisition-join-v1'
ENTRY_SHA = '27222503eee9aebd01b21ed1ecf2e298bdde8d2560ab099165a3d867696b004c'
INPUT_SHA = 'e6531f6b83f2ffdd8baa44f57e54834bc825617347334558f1f4ac6b63e6159f'
PROGRAM_SHA = '877c47879b027b08f02d3923d1e6dd9ccaf9a12e354567109f1aaa640a8fb673'
MICRO_SHA = '2f9e430b0b7034ed615d81c3e9b3978dc47ba4136686227a9b86df5779b203ac'
PAIRING = 'UNCHANGED_ATOM_TEMPLATE_CLASSES_NO_PRINCIPAL_COALESCENCE_V1'
OUTER = {'work_seconds': 160, 'positive_seconds': 180, 'custody_seconds': 210,
         'observer_fallback_seconds': 225, 'memory_bytes': 1073741824,
         'physical_bytes': 134217728, 'result_bytes': 50331648,
         'log_bytes': 4194304, 'reserved_outer_bytes': 9437184,
         'root_callbacks': 400000000}
LOCAL = {'cluster_binding_work': 20000, 'cluster_instances': 12,
         'cluster_proposals': 16, 'compile_queries': 512, 'domain_audits': 2,
         'marking_certificates': 12, 'marking_proposals': 48,
         'marking_work': 200000, 'native_steps': 1000000000,
         'search_attempts': 600, 'search_seconds': 2.0}
NATIVE_IDENTITY = {
    'program_sha256': PROGRAM_SHA, 'micro_sha256': MICRO_SHA,
    'query_target': 'fixed_assertion', 'protocol': 'gcts-fol-1',
    'native_steps': 1000000000,
    'executable_identity_scope': 'Exact executable/compiler/Host/transport Source pins in Root-admitted acquisition plan and result; no identity reconstructed from an accepted flag.'}
FORBIDDEN_INPUT_SHA = (
    '04fffc6e3ea0e9bbbe2ec1c2f1b251ce62ff0a527571288c96a0ccda77b6a174',
    '4c1f3ce62d6b27f16042442176171dd7fd2d9f26211553907d0ce6ab3a43db93',
    'c58d29127d3fc912c70b9de73dd1f4caed806a8b33542295cc6fc1257528bbaf')
_OWNER = object()


class JoinRefusal(ValueError):
    def __init__(self, message, owner=None):
        super().__init__(message)
        self.owner = owner


def is_owned_error(error):
    return type(error) is JoinRefusal and error.owner is _OWNER


def _need(ok, message, check):
    check()
    if not ok:
        raise JoinRefusal(message, _OWNER)


def _same(left, right, check):
    check()
    if type(left) is not type(right):
        return False
    if type(left) is dict:
        if set(left) != set(right):
            return False
        for key in left:
            if not _same(left[key], right[key], check):
                return False
        return True
    if type(left) is list:
        if len(left) != len(right):
            return False
        for a, b in zip(left, right):
            if not _same(a, b, check):
                return False
        return True
    if type(left) is float:
        return math.isfinite(left) and math.isfinite(right) and left.hex() == right.hex()
    return left == right


def _canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=False, allow_nan=False).encode('utf8')


def _digest(value, check):
    check(); body = _canonical(value); check()
    return hashlib.sha256(body).hexdigest()


def _pin(path, check):
    path = Path(path); check(); digest = hashlib.sha256(); count = 0
    with path.open('rb') as stream:
        while True:
            check(); body = stream.read(1048576)
            if not body:
                break
            count += len(body); digest.update(body)
    return dict(path=str(path.resolve()), bytes=count, sha256=digest.hexdigest())


def _complete(path, cap, check):
    path = Path(path); check()
    _need(not any('.partial' in part for part in path.parts), 'partial content is never parsed', check)
    with path.open('rb') as stream:
        body = stream.read(cap+1)
    _need(len(body) <= cap, 'complete JSON body exceeds declared cap', check)
    check(); value = json.loads(body); check()
    return value, dict(path=str(path.resolve()), bytes=len(body),
                       sha256=hashlib.sha256(body).hexdigest())


def _load_pin(row, cap, check):
    _need(type(row) is dict and set(row) == {'path', 'bytes', 'sha256'}
          and type(row['path']) is str and type(row['bytes']) is int
          and 0 <= row['bytes'] <= cap and type(row['sha256']) is str
          and len(row['sha256']) == 64, 'exact complete raw pin', check)
    value, actual = _complete(row['path'], cap, check)
    _need(_same(row, actual, check), 'complete raw pin changed', check)
    return value


def _census(directories, check):
    records = []; partials = []; total = 0
    for directory in directories:
        check()
        if not directory.is_dir():
            continue
        for path in sorted(directory.rglob('*')):
            check()
            if path.is_file():
                row = _pin(path, check); records.append(row); total += row['bytes']
                if '.partial' in path.name:
                    partials.append(row)  # Raw bytes/hash only, never JSON.
    return records, partials, total


def _number(value, check):
    _need(type(value) in (int, float) and math.isfinite(value) and value >= 0,
          'finite nonnegative recorded sample', check)
    return value


def _native_queries(worker, science, directory, owner, check):
    queries = worker['native_queries']; transport = worker['native_transport']
    _need(type(queries) is list and _same(queries, science['native_records'], check),
          'full worker/scientific current Native stream', check)
    stages = transport['request_stages']
    _need(type(stages) is list and type(worker['native_requests_started']) is int
          and type(transport['complete_records']) is int
          and len(queries) == len(stages) == transport['complete_records']
          == worker['native_requests_started'] and len(queries) <= LOCAL['compile_queries'],
          'every started current Native request completed', check)
    _need(transport['closed'] is True and transport['all_reaped'] is True
          and type(transport['native_exit_code']) is int
          and type(transport['wait4_status']) is int
          and transport['native_exit_code'] == transport['wait4_status'] == 0
          and not transport['cleanup_errors'] and not transport['termination_signals']
          and transport['same_owned_process_group'] is True
          and transport['native_pgid'] == owner['child_pgid']
          and transport['parent_pid'] == owner['child_pid']
          and transport['stdout_eof'] is True and transport['stdout_pending_bytes'] == 0
          and transport['stderr_complete'] is True and transport['stderr_bytes'] == 0,
          'complete owned Native process closure/reaping', check)
    _need(type(transport['native_high_water_bytes']) is int
          and transport['native_high_water_bytes'] == transport['wait4_usage']['ru_maxrss']
          == worker['native_peak_bytes'], 'waited Native HWM authority', check)
    by_id = {}; rows = []; statuses = {}
    for index, (query, stage) in enumerate(zip(queries, stages)):
        check()
        _need(type(query) is dict and type(query['id']) is int and query['id'] == index
              and stage['ordinal'] == stage['record_id'] == index
              and stage['stage'] == 'COMPLETED', 'exact ordered current Native membership', check)
        for field in ('purpose', 'request_sha256', 'input_sha256', 'output_sha256'):
            _need(_same(query[field], stage[field], check), 'request-stage '+field, check)
        _need(query['request_sha256'] == _digest(query['request'], check)
              and query['request']['protocol'] == 'gcts-fol-1'
              and query['request']['blocks'] == []
              and query['query_target'] == 'fixed_assertion'
              and type(stage['limit']) is int and stage['limit'] == LOCAL['native_steps'],
              'exact complete request/digest/limit/protocol', check)
        for field in ('input_sha256', 'output_sha256'):
            _need(type(query[field]) is str and len(query[field]) == 64,
                  'recorded full binary payload digest', check)
        status = query['result']['status']
        _need(status in ('accepted', 'rejected', 'unknown_step_budget', 'unknown_space_budget'),
              'known Native record status', check)
        statuses[status] = statuses.get(status, 0)+1; by_id[index] = query
        rows.append(dict(id=index, purpose=query['purpose'], status=status,
                         request_sha256=query['request_sha256'], limit=stage['limit']))
    if queries:
        _need(_pin(directory/'native/input.bin', check)['sha256'] == queries[-1]['input_sha256']
              and _pin(directory/'native/output.bin', check)['sha256'] == queries[-1]['output_sha256'],
              'last complete Native binary receipts', check)
    return by_id, dict(started=len(queries), status_counts=statuses, records=rows,
                       closed=True, all_reaped=True,
                       scope='Current owned recorded membership/digests only; no Native replay or decoder.')


def _proof_query(query, spec, proof, target, by_id, check):
    _need(type(query) is dict and type(query['id']) is int and query['id'] in by_id
          and _same(query, by_id[query['id']], check), 'exact proof query in current owned stream', check)
    expected = dict(protocol='gcts-fol-1', theory=spec['theory'], blocks=[],
                    proof=proof, target=target)
    _need(_same(query['request'], expected, check)
          and query['request_sha256'] == _digest(expected, check),
          'exact theory/proof/target Native request', check)
    return query['result']['status']


def _controls(controls, check):
    counts = {'numeric': 23, 'word': 48, 'graph': 22, 'encoding': 40,
              'principal': 53, 'corpus': 24}
    rows = []
    _need(type(controls) is dict and set(controls) == set(counts) |
          {'inherited', 'reference_setup_calibration'}, 'complete acquisition control population', check)
    for name, count in counts.items():
        record = controls[name]
        _need(record['complete'] is True and type(record['controls']) is list
              and len(record['controls']) == count, 'complete '+name+' controls', check)
        ids = []
        for control in record['controls']:
            _need(control['status'] == 'PASSED' and type(control['id']) is str,
                  'returned control PASS, not Source-only expectation', check)
            ids.append(control['id'])
        _need(len(set(ids)) == count, 'distinct complete control IDs', check)
        rows.append(dict(name=name, count=count, ids=ids, saved_sha256=_digest(record, check)))
    inherited = controls['inherited']
    _need(inherited['status'] == 'complete' and inherited['callback_identity_propagated'] is True
          and inherited['global_dead_forced_generation_controls'] is True
          and inherited['incomplete_certificate_rejected'] is True,
          'inherited global/rollback/fault controls complete', check)
    for audit in inherited['full_domain_audits']:
        _need(audit['complete'] is True, 'complete inherited domain audit', check)
    calibration = controls['reference_setup_calibration']
    _need(calibration['complete'] is True and calibration['status'] == 'PASSED'
          and calibration['control_count'] == 1 and calibration['full_model_value_unchanged'] is True
          and calibration['omitted_from_comparison'] == ['schema', 'storage_scope'],
          'explicit one same-model original/production calibration', check)
    old = calibration['original']; new = calibration['production']
    _need(old['complete'] is True and new['complete'] is True, 'two complete calibration audits', check)
    old_values = {}; new_values = {}
    for key in old:
        check()
        if key not in ('schema', 'storage_scope'):
            old_values[key] = old[key]
    for key in new:
        check()
        if key not in ('schema', 'storage_scope'):
            new_values[key] = new[key]
    _need(_same(old_values, new_values, check), 'complete saved calibration field correspondence', check)
    rows.append(dict(name='reference_setup_calibration', count=1,
                     saved_sha256=_digest(calibration, check)))
    return rows


def _scientific_join(science, document, by_id, check):
    _need(science['stage'] == 'acquire' and science['stage_id'] == 'acquire-0'
          and _same(science['inputs'], document, check)
          and _same(science['limits'], LOCAL, check)
          and science['resource_admitted'] is False,
          'full fresh acquisition carrier and external admission boundary', check)
    costs = science['cumulative_costs']
    _need(_same(costs, dict(stage_ids=[], whole_seconds=0.0,
              maximum_prior_whole_peak_bytes=0, receipts=[], current_whole_seconds=None), check),
          'no historical acquisition cost/export adoption', check)
    control_rows = _controls(science['controls'], check)
    records = science['records']; outcomes = science['donor_outcomes']; donors = document['donors']
    _need(type(records) is list and type(outcomes) is list
          and len(records) == len(outcomes) == len(donors) == 2,
          'both ordered full donor records and outcomes', check)
    projected = []; expected_certificates = []; donor_rows = []; unresolved = []
    all_whole = True
    for index, (record, spec) in enumerate(zip(records, donors)):
        check(); search = record['search']; proof = search['proof']; wholecheck = record['proof_check']
        _need(_same(record['spec'], spec, check), 'exact manifest donor spec', check)
        _need(record['reference_check']['complete'] is True
              and record['reference_check']['schema'] == 'aligned-complete-word-reference-v3'
              and record['word_model_check']['complete'] is True,
              'complete production v3 reduction and actual word-model gate', check)
        whole_accepted = wholecheck['native_proof_accepted'] is True
        all_whole = all_whole and whole_accepted
        if whole_accepted:
            _need(type(proof) is list and 0 < len(proof) <= spec['length']
                  and _same(proof[-1]['formula'], spec['target'], check)
                  and wholecheck['status'] == 'HOST_REGION_NATIVE_ACCEPTED'
                  and wholecheck['host_check']['accepted'] is True
                  and wholecheck['host_check']['rows'] == len(proof)
                  and wholecheck['region']['complete'] is True
                  and wholecheck['region']['decoded_rows'] == len(proof)
                  and wholecheck['region']['selected_placements'] == len(search['placements'])
                  and type(wholecheck['native_limit']) is int
                  and wholecheck['native_limit'] == LOCAL['native_steps']
                  and _same(wholecheck['host_check']['target'], spec['target'], check),
                  'recorded whole donor Host/full-region/limit gates', check)
            _need(_proof_query(wholecheck['native_record'], spec, proof, spec['target'], by_id, check)
                  == 'accepted', 'whole donor accepted by current Native stream', check)
        candidates = record['candidates']; accepted_count = 0; profile_count = 0; pending = []
        _need(type(candidates) is list and (not whole_accepted or len(candidates) == len(proof)+1),
              'complete full plus ordered ancestor candidate population', check)
        candidate_rows = []
        for ordinal, candidate in enumerate(candidates):
            check(); fragment = candidate['proof']
            _need(type(candidate['ordinal']) is int and candidate['ordinal'] == ordinal
                  and candidate['kind'] == ('full' if ordinal == 0 else 'ancestor_closure')
                  and _same(candidate['source_row'], None if ordinal == 0 else ordinal-1, check)
                  and type(fragment) is list and len(fragment) > 0,
                  'complete ordered candidate carriers', check)
            _need(_same(candidate['target'], fragment[-1]['formula'], check),
                  'candidate exact last formula target', check)
            # Syntactic profile only, never a new proof/inference check.
            profile = True; has_mp = False
            for command in fragment:
                _need(type(command) is dict and type(command.get('rule')) is str,
                      'literal candidate command carrier', check)
                profile = profile and command['rule'] in ('axiom', 'mp')
                has_mp = has_mp or command['rule'] == 'mp'
            profile = profile and has_mp
            _need(type(candidate['profile_eligible']) is bool
                  and candidate['profile_eligible'] is profile,
                  'derive profile independently of admission flags', check)
            status = 'OUTSIDE_DECLARED_PROFILE'; query_id = None
            if profile:
                profile_count += 1
                status = _proof_query(candidate['native_record'], spec, fragment,
                                      candidate['target'], by_id, check)
                query_id = candidate['native_record']['id']
                _need(type(candidate['native_resolution']) is str
                      and candidate['native_resolution'] == status
                      and type(candidate['eligible']) is bool
                      and candidate['eligible'] is (status == 'accepted'),
                      'derived profile resolution and acquisition separated', check)
                if status == 'accepted':
                    accepted_count += 1
                    _need(candidate['host_check']['accepted'] is True
                          and _same(candidate['host_check']['target'], candidate['target'], check)
                          and candidate['host_check']['rows'] == len(fragment)
                          and candidate['reason'] == 'fresh_Host_and_Native_accepted',
                          'retained candidate recorded Host acceptance', check)
                    provenance = dict(training_id=spec['id'], candidate_ordinal=ordinal,
                        kind=candidate['kind'], source_row=candidate['source_row'],
                        ancestry=candidate['ancestry'], native_query=query_id,
                        request_digest=candidate['native_record']['request_sha256'])
                    typed = candidate['principal_check']; independent = typed['independent']
                    families = candidate['families']
                    _need(type(families) is dict and set(families) == {'atom', 'principal'},
                          'exact dual-family carrier', check)
                    principal = families['principal']
                    _need(typed['complete'] is True and independent['complete'] is True
                          and _same(principal, candidate['family'], check)
                          and _same(principal['template'], independent['template'], check)
                          and _same(principal['certificate']['donor_arguments'], independent['concrete_arguments'], check)
                          and _same(principal['certificate']['port_occurrences'], independent['port_aliases'], check),
                          'complete saved production/independent principal evidence', check)
                    for field in ('graph', 'row_formulas', 'premises', 'conclusion', 'port_count', 'parameters'):
                        _need(_same(principal['certificate']['typing'][field], independent[field], check),
                              'all live independent principal fields '+field, check)
                    for family in families.values():
                        _need(_same(family['provenance'], provenance, check)
                              and family['dependencies'] == [], 'exact fresh family provenance/no blocks', check)
                    certificate = dict(spec=spec, proof=fragment, target=candidate['target'],
                        provenance=provenance, family=principal, families=families,
                        principal_check=typed, acquisition_mode='principal',
                        native_record=candidate['native_record'], native_limit=LOCAL['native_steps'],
                        full_donor_proof=proof, full_donor_check=wholecheck,
                        fragment_region_scope='No separate fragment region compiled; exact remapped primitive Host/Native certificate. Whole donor has full original region.')
                    expected_certificates.append(certificate)
                else:
                    pending.append(dict(candidate_ordinal=ordinal, native_status=status))
                    unresolved.append(dict(donor_id=spec['id'], candidate_ordinal=ordinal, native_status=status))
            else:
                _need(candidate['eligible'] is False and candidate['native_record'] is None
                      and candidate['host_check'] is None and candidate['family'] is None
                      and candidate['native_resolution'] == status,
                      'outside-profile candidate retained without authority', check)
            candidate_rows.append(dict(ordinal=ordinal, profile_eligible=profile,
                                       native_resolution=status, current_query_id=query_id))
        resolution = dict(schema='fixed-acquisition-fragment-resolution-v1', complete=True,
            profile_eligible_count=profile_count, native_accepted_count=accepted_count,
            unresolved=pending, all_profile_fragments_accepted=not pending)
        _need(_same(record['fragment_resolution'], resolution, check),
              'complete derived fragment resolution, no UNKNOWN laundering', check)
        record_hash = _digest(record, check)
        outcome = dict(id=spec['id'], status=search['status'],
                       whole_native_accepted=whole_accepted,
                       eligible_fragments=accepted_count, record_sha256=record_hash)
        _need(_same(outcomes[index], outcome, check), 'post-annotation full donor record/outcome hash', check)
        projected.append(dict(spec=spec, search=dict(status=search['status'], proof=proof),
            proof_check=wholecheck, candidates=candidates, fragment_resolution=resolution,
            full_record_sha256=record_hash))
        donor_rows.append(dict(id=spec['id'], full_record_sha256=record_hash,
            whole_native_accepted=whole_accepted, profile_count=profile_count,
            accepted_count=accepted_count, candidates=candidate_rows))
    _need(_same(science['certificates'], expected_certificates, check),
          'all and only recorded current accepted candidate certificates in order', check)
    pairing = science['pairing']; libraries = science['libraries']; unit_rows = []; seen = set(); member_ordinals = []
    _need(set(libraries) == {'atom', 'principal'}
          and len(libraries['atom']) == len(libraries['principal']) == len(pairing['units'])
          and pairing['policy'] == science['pairing_policy'] == PAIRING,
          'same paired atom-class units in both complete inventories', check)
    for index, unit in enumerate(pairing['units']):
        check(); members = unit['members']; identity = unit['paired_unit_id']
        _need(type(identity) is str and identity not in seen and members,
              'one unit per atom class, all members retained', check); seen.add(identity)
        first = members[0]['certificate_ordinal']
        _need(type(first) is int and 0 <= first < len(expected_certificates),
              'exact first current certificate member index', check)
        base = expected_certificates[first]
        _need(base['families']['atom']['id'] == unit['atom_structural_id'] == identity
              and base['families']['principal']['structural_id'] == unit['principal_structural_id'],
              'unit exact atom and principal structural identity', check)
        for member in members:
            ordinal = member['certificate_ordinal']
            _need(type(ordinal) is int and 0 <= ordinal < len(expected_certificates),
                  'exact current certificate member index', check)
            member_ordinals.append(ordinal); certificate = expected_certificates[ordinal]
            _need(_same(member['provenance'], certificate['provenance'], check)
                  and certificate['families']['atom']['id'] == identity
                  and certificate['families']['principal']['structural_id'] == unit['principal_structural_id']
                  and certificate['families']['atom']['parameters'] == base['families']['atom']['parameters']
                  and certificate['families']['principal']['parameters'] == base['families']['principal']['parameters']
                  and _same(certificate['families']['atom']['template'], base['families']['atom']['template'], check)
                  and _same(certificate['families']['principal']['template'], base['families']['principal']['template'], check)
                  and _same(certificate['families']['principal']['certificate']['typing']['graph'],
                            base['families']['principal']['certificate']['typing']['graph'], check),
                  'every class member exact paired template/DAG/provenance', check)
        for mode in ('atom', 'principal'):
            wrapper = libraries[mode][index]; inner = base['families'][mode]
            _need(wrapper['id'] == wrapper['paired_unit_id'] == identity
                  and wrapper['abstraction_mode'] == mode and wrapper['pairing_policy'] == PAIRING
                  and wrapper['structural_id'] == inner['id']
                  and type(wrapper['source_certificate_ordinal']) is int
                  and wrapper['source_certificate_ordinal'] == first
                  and _same(wrapper['structural_family'], inner, check)
                  and unit['wrapper_checks'][mode]['complete'] is True
                  and unit['wrapper_checks'][mode]['mode'] == mode
                  and unit['wrapper_checks'][mode]['paired_unit_id'] == identity
                  and unit['wrapper_checks'][mode]['structural_id'] == inner['id']
                  and type(unit['wrapper_checks'][mode]['source_certificate_ordinal']) is int
                  and unit['wrapper_checks'][mode]['source_certificate_ordinal'] == first,
                  'exact structural owner inside paired library wrapper', check)
            for key in inner:
                if key != 'id':
                    _need(_same(wrapper[key], inner[key], check), 'wrapper forwards all inner fields', check)
            structural_check = unit['wrapper_checks'][mode]['principal_structural_check']
            _need((structural_check is None if mode == 'atom' else
                   structural_check['complete'] is True and structural_check['structural_id'] == inner['id']),
                  'recorded principal wrapper structural check', check)
        unit_rows.append(dict(paired_unit_id=identity,
                             certificate_ordinals=[m['certificate_ordinal'] for m in members]))
    _need(sorted(member_ordinals) == list(range(len(expected_certificates)))
          and pairing['raw_certificates'] == len(expected_certificates)
          and pairing['paired_units'] == len(unit_rows)
          and pairing['no_principal_coalescence'] is True,
          'complete fragment membership without dropped/duplicated units', check)
    principal_ids = {f['structural_id'] for f in libraries['principal']}
    _need(pairing['principal_structures'] == len(principal_ids), 'observed principal structures, not forecast', check)
    has_multistep = False
    for family in libraries['principal']:
        mp_count = 0
        for command in family['template']['proof']:
            check(); mp_count += command['rule'] == 'mp'
        has_multistep = has_multistep or mp_count >= 2
    qualified = all_whole and not unresolved and len(libraries['atom']) >= 2 and has_multistep
    _need(science['qualified'] is qualified
          and science['all_profile_fragments_accepted'] is (not unresolved)
          and science['stage_complete'] is qualified and science['job_record_complete'] is True,
          'derived complete qualification independent of exported flags', check)
    exported = science['export']
    if qualified:
        _need(type(exported) is dict and set(exported) == {
            'schema','stage','stage_id','acquisition_document','donor_ids','donor_outcomes',
            'donor_evidence','certificates','libraries','pairing','native_certificate_identity',
            'pairing_policy','qualified','scope'}, 'exact complete v2 export', check)
        _need(exported['schema'] == 'gcts-principal-family-search-stage-export-v2'
              and exported['stage'] == 'acquire' and exported['stage_id'] == 'acquire-0'
              and exported['qualified'] is True
              and _same(exported['acquisition_document'], document, check)
              and exported['donor_ids'] == [s['id'] for s in donors]
              and _same(exported['donor_outcomes'], outcomes, check)
              and _same(exported['donor_evidence'], projected, check)
              and _same(exported['certificates'], science['certificates'], check)
              and _same(exported['libraries'], libraries, check)
              and _same(exported['pairing'], pairing, check)
              and exported['pairing_policy'] == PAIRING
              and _same(exported['native_certificate_identity'], NATIVE_IDENTITY, check),
              'full annotated records/projected v2 export/current Native program identity', check)
    else:
        _need(exported is None, 'unresolved/insufficient acquisition has no shortened export', check)
    return dict(scientific_candidate_complete=qualified, unresolved_profile=unresolved,
                donors=donor_rows, retained_certificates=len(expected_certificates),
                paired_units=unit_rows, principal_structures=len(principal_ids),
                controls=control_rows, export_sha256=_digest(exported, check) if qualified else None,
                scope='Saved literal/provenance/profile joins only; no proof, ancestor closure, miner, MGU, compiler or verifier replay.')


def join_acquisition(plan_pin, *, check):
    began = time.perf_counter(); check(); plan = _load_pin(plan_pin, 4194304, check)
    _need(plan['stage'] == 'acquire' and plan['case_id'] == 'acquire-0'
          and plan['required_upstream_ids'] == plan['upstream_receipts'] == []
          and _same(plan['limits'], OUTER, check)
          and _same(plan['experiment_limits'], LOCAL, check),
          'exact cold acquire-0 phase and unchanged caps', check)
    closure = plan['files']; paths = set()
    for row in closure:
        check(); _need(row['path'] not in paths, 'unique complete Source closure', check); paths.add(row['path'])
        _need('/actual/' not in row['path'] and row['sha256'] not in FORBIDDEN_INPUT_SHA
              and not any('.partial' in part for part in Path(row['path']).parts),
              'no historical actual/evaluation-bearing input in acquisition closure', check)
        _need(_same(_pin(row['path'], check), row, check), 'current Source/input closure unchanged', check)
    for field in ('entry_path', 'worker_path', 'runner_path', 'observer_path', 'input_path'):
        _need(plan[field] in paths, 'all executing/intake paths in exact closure', check)
    for field in ('executable_path', 'template_path', 'micro_path'):
        _need(plan['native'][field] in paths, 'fixed Native dependency in exact closure', check)
    _need(_pin(plan['entry_path'], check)['sha256'] == ENTRY_SHA
          and _pin(plan['input_path'], check)['sha256'] == INPUT_SHA,
          'exact reviewed v16 Source and acquisition literal', check)
    document, input_pin = _complete(plan['input_path'], 4194304, check)
    directory = Path(plan['actual_dir']); observer_dir = Path(str(directory)+'.observer')
    census, partials, total = _census((directory, observer_dir), check)
    required = {'header': directory/'worker-header.json', 'terminal': directory/'terminal.json',
                'observer': observer_dir/'observer.json', 'consumed': directory/'CONSUMED.json',
                'owner': directory/'owned-child.json'}
    missing = [str(path) for path in required.values() if not path.is_file()]
    report = dict(schema=VERSION, candidate_join_passed=False, candidate_admission=False,
        resource_admitted=False, scientific_qualified=False, stage_complete=False,
        result=None, header=None, terminal=None, observer=None,
        whole_seconds=None, whole_peak_bytes=None, admitted=False,
        seal_emitted=False, independent_actual_review_required=True, plan=plan_pin,
        input=input_pin, complete_file_census=census, partial_raw_metadata=partials,
        physical_bytes=total, Source_rows_verified=len(closure), missing=missing,
        cold_cost=None, scientific=None,
        scope='Pure passive candidate report. Root seal and exact successful independent actual review remain separate authorities.')
    if missing:
        report.update(status='UNAVAILABLE_REQUIRED_COMPLETE_ARTIFACTS',
                      passive_join_seconds=time.perf_counter()-began)
        return report
    artifacts = {}; pins = {}
    for name, path in required.items():
        artifacts[name], pins[name] = _complete(path, 4194304, check)
    header = artifacts['header']; terminal = artifacts['terminal']; observer = artifacts['observer']
    _need(header['case_id'] == terminal['case_id'] == observer['case_id'] == 'acquire-0',
          'complete case IDs', check)
    result_pin = header['result']
    _need(result_pin['path'] in (str((directory/'result.json').resolve()),
                                str((directory/'failure.json').resolve())),
          'result belongs to this actual complete named packet', check)
    worker = _load_pin(result_pin, OUTER['result_bytes'], check); pins['result'] = result_pin
    report['artifacts'] = pins; report['worker_status'] = worker['status']
    for name in ('result', 'header', 'terminal', 'observer'):
        report[name] = pins[name]
    report['whole_seconds'] = observer['elapsed_seconds']
    report['whole_peak_bytes'] = observer['final_conservative_whole_peak_bytes']
    recorded_science = worker['scientific_result']
    if type(recorded_science) is dict:
        _need(type(recorded_science['stage_complete']) is bool, 'typed recorded stage completion', check)
        report['stage_complete'] = recorded_science['stage_complete']
    report['parent_exit_code'] = terminal['process_exit_code']; report['observer_parent_exit_code'] = observer['parent_exit_code']
    report['worker_error'] = worker['error']; report['observer_reason'] = observer['reason']
    report['cold_cost'] = dict(stage_id='acquire-0', counted_once=True,
        observer_elapsed_sample=observer['elapsed_seconds'],
        whole_peak_bytes=observer['final_conservative_whole_peak_bytes'],
        prior_cost_receipts=[], scope='One cold actual observer sample; join time and component clocks are separate, never overlapping totals.')
    if worker['status'] != 'COMPLETE' or header['status'] != 'COMPLETE' or partials:
        report.update(status='FAILED_OR_PARTIAL_ACQUISITION_NOT_ADMITTED',
                      passive_join_seconds=time.perf_counter()-began)
        return report
    _need(worker['case_id'] == 'acquire-0' and worker['stage'] == 'acquire'
          and worker['error'] is None and worker['first_Root_fault'] is False
          and worker['source_unchanged'] is header['source_unchanged'] is terminal['sources_unchanged'] is True
          and worker['old_qualification_reused'] is False
          and header['native_closed_and_reaped'] is True and header['first_Root_fault'] is False
          and _same(terminal['header'], header, check) and terminal['header_valid'] is True
          and _same(terminal['result'], result_pin, check), 'complete worker/header/parent result binding', check)
    completed_stages = set()
    for stage in worker['stages']:
        _need(stage['status'] == 'COMPLETED', 'no unfinished worker stage on positive path', check)
        completed_stages.add(stage['name'])
    _need({'DECODE fixed template', 'DECODE fixed microcode', 'ENCODE complete fixed Native table',
           'START bounded Native oracle', 'INTAKE fresh complete acquisition export',
           'RUN complete fixed principal-family stage'} <= completed_stages,
          'reviewed program/microcode/input/scientific stage completion', check)
    consumed = artifacts['consumed']; owner = artifacts['owner']
    _need(consumed['case_id'] == owner['case_id'] == 'acquire-0'
          and type(consumed['uses']) is int and consumed['uses'] == 1
          and consumed['plan_sha256'] == owner['plan_sha256'] == plan_pin['sha256']
          and _same(observer['owned_child'], owner, check)
          and type(owner['child_pid']) is int and owner['child_pid'] == owner['child_pgid'],
          'consumed exact plan and current owned process group', check)
    _need(type(terminal['process_exit_code']) is int and type(observer['parent_exit_code']) is int,
          'exact process exit code types', check)
    resource_passed = (terminal['process_exit_code'] == observer['parent_exit_code'] == 0
        and terminal['reason'] is observer['reason'] is None and not terminal['errors'] and not observer['errors']
        and terminal['threads_terminal'] is True and terminal['final_custody_gate_passed'] is True
        and observer['resource_candidate_accepted'] is True and observer['fallback_trigger_seconds'] is None)
    worker_seconds = _number(worker['elapsed_seconds'], check)
    resource_passed = resource_passed and worker_seconds < OUTER['work_seconds']
    resource_passed = resource_passed and _number(header['seconds'], check) < OUTER['positive_seconds']
    resource_passed = resource_passed and _number(terminal['known_exit_seconds'], check) <= OUTER['positive_seconds']
    resource_passed = resource_passed and _number(terminal['final_custody_gate_seconds'], check) <= OUTER['custody_seconds']
    resource_passed = resource_passed and _number(observer['final_observer_gate_seconds'], check) <= OUTER['custody_seconds']
    _need(type(worker['callbacks']) is int and worker['callbacks'] == header['callbacks']
          and worker['callbacks'] <= OUTER['root_callbacks'], 'whole callback count', check)
    for record, folder in ((terminal, directory), (observer, observer_dir)):
        for name, log in record['logs'].items():
            check(); _need(log['eof'] is True and log['overflow'] is False
                and log['bytes'] == log['stored'] == (folder/(name+'.bin')).stat().st_size,
                'complete bounded log stream', check)
            resource_passed = resource_passed and log['bytes'] <= (OUTER['log_bytes'] if folder == directory else 1048576)
    for sample in (worker['python_peak_bytes'], worker['native_peak_bytes'],
                   header['python_peak_after_output_bytes'], header['native_peak_bytes'],
                   terminal['parent_usage']['ru_maxrss'], terminal['child_usage']['ru_maxrss'],
                   observer['final_observer_peak_bytes']):
        _need(type(sample) is int and sample >= 0, 'exact recorded HWM bytes', check)
    _need(worker['native_peak_bytes'] == header['native_peak_bytes']
          and terminal['memory_terminal_output_reserve_bytes'] == OUTER['reserved_outer_bytes']
          and observer['final_output_memory_reserve_bytes'] == OUTER['reserved_outer_bytes'],
          'same Native HWM and unchanged materialization reserves', check)
    peak = terminal['parent_usage']['ru_maxrss'] + max(terminal['child_usage']['ru_maxrss'],
        header['python_peak_after_output_bytes']) + header['native_peak_bytes'] + OUTER['reserved_outer_bytes']
    whole = peak + observer['final_observer_peak_bytes'] + OUTER['reserved_outer_bytes']
    _need(type(peak) is int and peak == terminal['conservative_combined_peak_bytes']
          and type(whole) is int and whole == observer['final_conservative_whole_peak_bytes'],
          'complete post-output/waited-child/Native/parent/observer reserve sum', check)
    resource_passed = resource_passed and whole < OUTER['memory_bytes'] and total <= OUTER['physical_bytes']
    resource_passed = resource_passed and terminal['stored_bytes_before_terminal_receipt'] <= OUTER['physical_bytes']-OUTER['reserved_outer_bytes']
    report['resource_candidate_accepted'] = resource_passed
    report['resource_admitted'] = bool(resource_passed)
    if not resource_passed:
        report.update(status='RESOURCE_REJECTED_ACQUISITION_NOT_ADMITTED',
                      passive_join_seconds=time.perf_counter()-began)
        return report
    science = worker['scientific_result']; by_id, native = _native_queries(worker, science, directory, owner, check)
    report['Native'] = native
    _need(_pin(directory/'native/boundary-oracle', check)['sha256']
          == _pin(plan['native']['executable_path'], check)['sha256'],
          'owned Native executable equals current pinned dependency', check)
    report['scientific'] = _scientific_join(science, document, by_id, check)
    for row in closure:
        _need(_same(_pin(row['path'], check), row, check), 'Source closure unchanged at passive exit', check)
    report.update(candidate_join_passed=report['scientific']['scientific_candidate_complete'],
        candidate_admission=report['scientific']['scientific_candidate_complete'],
        scientific_qualified=report['scientific']['scientific_candidate_complete'],
        status=('COMPLETE_CANDIDATE_JOIN_PENDING_INDEPENDENT_ACTUAL_REVIEW'
                if report['scientific']['scientific_candidate_complete'] else
                'UNRESOLVED_OR_INSUFFICIENT_ACQUISITION_NOT_ADMITTED'),
        export_sha256=report['scientific']['export_sha256'],
        passive_join_seconds=time.perf_counter()-began,
        program_identity_evidence='Raw pinned executable/template/microcode plus reviewed completed worker stages; no tape decoder, scientific checker, compiler or microcode was called by this helper.')
    check()
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', required=True)
    parser.add_argument('--plan-sha256', required=True)
    parser.add_argument('--plan-bytes', required=True, type=int)
    args = parser.parse_args()
    # No report path is opened here. Root persists the one complete stdout
    # document only after exit0, then independently reviews it before sealing.
    report = join_acquisition(dict(path=str(Path(args.plan).resolve()),
        bytes=args.plan_bytes, sha256=args.plan_sha256), check=lambda: None)
    body = json.dumps(report, sort_keys=True, ensure_ascii=True, allow_nan=False)
    print(body)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
