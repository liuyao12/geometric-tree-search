"""Root-only passive exact-pin/idle-barrier grant composition; no science calls."""
from pathlib import Path
import hashlib
import json

BASE = Path(__file__).resolve().parents[1]


def pin(path):
    path = Path(path).resolve()
    body = path.read_bytes()
    return {'path': str(path), 'bytes': len(body),
            'sha256': hashlib.sha256(body).hexdigest()}


def read(path):
    path = Path(path)
    assert '.partial' not in path.name
    return json.loads(path.read_bytes())


def write_new(path, value):
    with Path(path).open('x') as stream:
        stream.write(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n')


def main():
    review_path = BASE / 'review-C/typed-fixed-family-evaluation16-plan-review-v1.json'
    review_pin = pin(review_path)
    assert review_pin['bytes'] == 158973
    assert review_pin['sha256'] == 'e1727660b0e30c5ef2aafd5dc61fad59dc736fa0c57497968044deb993b9daf8'
    review = read(review_path)
    assert review['review_passed'] is True
    assert review['scientific_calls'] == review['scientific_imports'] == 0
    assert review['scientific_replay'] is False
    assert len(review['checks']) == 3 and all(c['passed'] is True for c in review['checks'])
    manifest_path = BASE / 'root/materialized-evaluation-plans-v2.json'
    manifest = read(manifest_path)
    assert manifest['plans'] == review['plans'] and len(manifest['plans']) == 16
    for row in review['complete_unique_input_pins']:
        assert pin(row['path']) == row, row['path']
    plans = []
    for row in manifest['plans']:
        assert pin(row['path']) == row
        plan = read(row['path'])
        assert plan['stage'] == 'evaluate'
        assert plan['template_pending_fresh_acquisition'] is False
        assert plan['required_upstream_ids'] == ['acquire-0']
        assert not Path(plan['actual_dir']).exists()
        assert not Path(plan['actual_dir'] + '.observer').exists()
        grant_path = BASE / ('root/grants/' + plan['case_id'] + '-v1.json')
        assert not grant_path.exists()
        plans.append((row, plan, grant_path))
    runner_pin = pin(BASE / 'root/run_fixed_family_once_v1.py')
    assert runner_pin['sha256'] == '98c55321bb87a8c04b2c6d56b357aba9c3a8f5fc98660474ae3ac1c9d00b0aca'
    barrier_path = BASE / 'root/serial-barrier-evaluation16-v1.json'
    barrier = {
        'schema': 'D17-Root-serial-barrier-v1',
        'review': review_pin, 'plans': manifest['plans'],
        'team_tools_stopped': ['B', 'C', 'L'],
        'basis': 'Root observed all three agents completed immediately before grant composition; acquisition observer/parent/tool session terminal.',
        'study_worker_or_preview_services_running': False,
        'browser_QA_running': False,
        'unrelated_services_preserved': True,
        'execution_order': [p['case_id'] for _, p, _ in plans],
        'scope': 'Owned study isolation only. Direct serial once calls, wait for each terminal and owned cleanup before next. No globally idle OS or realtime sandbox claim.'}
    write_new(barrier_path, barrier)
    grants = []
    for row, plan, grant_path in plans:
        write_new(grant_path, {
            'authorized': True, 'uses': 1, 'review_passed': True,
            'plan_sha256': row['sha256'],
            'runner_sha256': runner_pin['sha256'],
            'C_review': review_pin, 'serial_barrier': pin(barrier_path),
            'scope': 'Root fresh exact once evaluation only, in declared serial order. No retry, replacement library, bound or population change.'})
        grants.append(pin(grant_path))
    write_new(BASE / 'root/evaluation16-grants-v1.json', {
        'schema': 'D17-Root-evaluation16-grants-v1', 'C_review': review_pin,
        'manifest': pin(manifest_path), 'serial_barrier': pin(barrier_path),
        'grants': grants, 'scientific_calls': 0})
    print(json.dumps({'grants': len(grants), 'plans': len(plans),
                      'review_passed': True, 'scientific_calls': 0}))


if __name__ == '__main__':
    main()
