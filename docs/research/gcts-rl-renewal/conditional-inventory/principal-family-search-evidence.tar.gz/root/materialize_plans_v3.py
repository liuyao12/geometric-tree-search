"""Passive Source/pin plan composition. Never imports research code.

prepare writes one exact acquisition plan and sixteen NON-EXECUTABLE templates.
materialize binds those templates to one independently admitted fresh acquisition.
Neither command grants permission to execute a scientific actual.
"""
from pathlib import Path
import argparse
import hashlib
import json

ROOT = Path(__file__).resolve().parent
STUDY = ROOT.parent
REPO = STUDY.parent.parent
PREVIOUS = REPO/'research-runs/gcts-principal-receptor-families-20261021'


def pin(path):
    path = Path(path).resolve()
    if '.partial' in path.name:
        raise ValueError('no partial declarations or result bodies')
    body = path.read_bytes()
    return dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def read(path):
    row = pin(path)
    return json.loads(Path(row['path']).read_bytes())


def checked(row):
    if pin(row['path']) != row:
        raise ValueError('exact complete pin changed')
    return read(row['path'])


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')


def prepare(helper_handoff):
    previous = read(PREVIOUS/'root/plan-mechanism-0-v1.json')
    protocol = read(ROOT/'protocol-v1.json')
    l_protocol = STUDY/'diagnostics-L/protocol-proposal-v3.json'
    if protocol['corpus_protocol'] != pin(l_protocol):
        raise ValueError('frozen corpus protocol')
    manifest = read(STUDY/'implementation-B/manifest-v2.json')
    helper = read(helper_handoff)
    paths = set()
    for folder in ('runtime',):
        paths.update(STUDY.joinpath(folder).glob('*.py'))
    if len(paths) != 38:
        raise ValueError('exact full 38-module inherited/new runtime')
    for row in manifest['files'] + manifest['dependencies'] + helper['files']:
        if pin(row['path']) != row:
            raise ValueError('frozen Source offer changed')
        paths.add(Path(row['path']))
    relatives = [
        'root/protocol-v1.json', 'root/materialize_plans_v3.py', 'root/seal_acquisition_v2.py',
        'root/fixed_family_worker_v1.py', 'root/run_fixed_family_once_v1.py',
        'root/observe_fixed_family_once_v1.py', 'root/inherited-runtime-raw-copy-v1.json',
        'root/custody-Source-composition-v1.json',
        'implementation-B/handoff-v2.json', 'implementation-B/manifest-v2.json',
        'diagnostics-L/API-v3.json', 'diagnostics-L/handoff-v3.json',
        'diagnostics-L/protocol-proposal-v3.json', 'diagnostics-L/corpus-control-bank-v1.json',
        'diagnostics-L/typed-reference-setup-calibration-Source-review-v1.json',
        'review-C/reference-setup-calibration-handoff-v1.json',
        'review-C/reference-setup-calibration-API-v1.json',
        'review-C/reference-production-contract-v1.json',
        'review-C/reference-setup-control-bank-v1.json',
        'review-C/typed-principal-search-corpus-Source-review-v1.json',
        'review-C/typed-principal-search-custodian-Source-review-v1.json',
        'review-C/typed-fixed-principal-family-search-Source-review-v2.json',
        'review-C/typed-fixed-family-Source-negative-v15.json',
    ]
    paths.update(STUDY/p for p in relatives)
    paths.add(Path(helper_handoff).resolve())
    paths.add(REPO/'docs/basic-tiling-algorithm.md')
    paths.add(REPO/'research-runs/gcts-batch-20261020/publisher/docs/basic-tiling-algorithm.md')
    paths.add(Path(previous['python']['path']))
    paths.update(Path(v) for v in previous['native'].values())
    paths.add(Path(previous['native']['executable_path']).with_name('boundary_oracle.cpp'))
    # No scientific input/results from old studies enter these closures.
    forbidden = {
        str((REPO/'research-runs/gcts-learned-selector-proof-pilot-20261020/corpus-L/evaluation-inputs-v1.json').resolve()),
        str((PREVIOUS/'diagnostics-L/mechanism-inputs-v1.json').resolve()),
        str((STUDY/'diagnostics-L/evaluation-inputs-v1.json').resolve()),
    }
    if any(str(p.resolve()) in forbidden for p in paths):
        raise ValueError('evaluation-bearing input in acquisition/common closure')
    common = [pin(p) for p in sorted(paths)]
    # Revalidate the exact previously composed runtime copies without importing.
    for row in read(ROOT/'inherited-runtime-raw-copy-v1.json')['raw_copies']:
        if pin(row['copy']['path']) != row['copy'] or pin(row['source']['path']) != row['source']:
            raise ValueError('frozen full runtime copy/source changed')
    records = []
    for recipe in protocol['job_recipes']:
        stage, stage_id = recipe['stage'], recipe['stage_id']
        acquisition = stage == 'acquire'
        input_path = STUDY/'diagnostics-L'/('acquisition-inputs-v1.json' if acquisition else 'evaluation-inputs-v1.json')
        plan = dict(schema='proof-search-case-once-plan-v1' if acquisition else 'proof-search-case-once-template-v1',
            experiment='D17-fixed-paired-principal-family-search-v1', stage=stage, case_id=stage_id,
            limits=protocol['limits'], experiment_limits=protocol['experiment_limits'],
            modules=previous['modules'], native=previous['native'], python=previous['python'],
            trusted_runtime=previous['trusted_runtime'], runtime_dir=str(STUDY/'runtime'),
            entry_path=str(STUDY/'implementation-B/proof_search_pilot_v16.py'),
            worker_path=str(ROOT/'fixed_family_worker_v1.py'), runner_path=str(ROOT/'run_fixed_family_once_v1.py'),
            observer_path=str(ROOT/'observe_fixed_family_once_v1.py'),
            actual_dir=str(STUDY/'actual'/stage_id), input_path=str(input_path),
            protocol=pin(ROOT/'protocol-v1.json'), files=common+[pin(input_path)],
            required_upstream_ids=[] if acquisition else ['acquire-0'], upstream_receipts=[],
            old_qualifications='No historical results/exports/policies/proofs adopted. Fresh D17 only.',
            template_pending_fresh_acquisition=not acquisition)
        if Path(plan['actual_dir']).exists() or Path(plan['actual_dir']+'.observer').exists():
            raise ValueError('one-use actual/observer must not exist')
        target = ROOT/('plans' if acquisition else 'templates')/(stage_id+'-v2.json')
        write(target, plan)
        records.append(dict(stage_id=stage_id, stage=stage, plan_or_template=pin(target), scientific_execution_authorized=False))
    write(ROOT/'plan-family-v2.json', dict(schema='D17-Root-plan-family-v2',
        Source_only=True, scientific_calls=0, grants=0, actuals=0,
        common_files=common, helper_handoff=pin(helper_handoff), jobs=records,
        acquisition_input_excluded_from_eval_closure=True,
        evaluation_input_excluded_from_acquisition_closure=True,
        scope='Root exact acquisition plan plus sixteen unexecutable eval templates. Independent whole review and once grants remain required.'))


def materialize():
    seal_path = ROOT/'seals/acquire-0-v1.json'
    admission_path = ROOT/'admission/acquire-0-v1.json'
    envelope = read(seal_path)
    admission = read(admission_path)
    expected = dict(plan=ROOT/'plans/acquire-0-v2.json',
        result=STUDY/'actual/acquire-0/result.json', header=STUDY/'actual/acquire-0/worker-header.json',
        terminal=STUDY/'actual/acquire-0/terminal.json', observer=STUDY/'actual/acquire-0.observer/observer.json')
    if not (admission['schema'] == 'D17-Root-whole-admission-v1'
            and admission['stage_id'] == envelope['stage_id'] == 'acquire-0'
            and admission['stage'] == envelope['stage'] == 'acquire'
            and all(admission[k] is True for k in ('admitted','resource_admitted','scientific_qualified','stage_complete'))
            and envelope['resource_admitted'] is True and envelope['stage_complete'] is True
            and envelope['prior_cost_receipts'] == []):
        raise ValueError('unique fresh D17 independently admitted complete acquisition required')
    for key, path in expected.items():
        if envelope[key] != pin(path) or admission[key] != pin(path):
            raise ValueError('no historical acquisition substitution')
        checked(envelope[key])
    review = checked(admission['C_review'])
    if not (review['review_passed'] is True and review['resource_admitted'] is True
            and review['scientific_qualified'] is True and review['plan'] == envelope['plan']
            and review['result'] == envelope['result']
            and review['passive_join'] == admission['passive_join']):
        raise ValueError('exact independent actual scientific/resource review')
    joined = checked(admission['passive_join'])
    if not (all(joined[k] is True for k in ('candidate_admission', 'resource_admitted', 'scientific_qualified', 'stage_complete'))
            and all(joined[k] == envelope[k] for k in expected)
            and joined['whole_seconds'] == envelope['whole_seconds'] == admission['whole_seconds']
            and joined['whole_peak_bytes'] == envelope['whole_peak_bytes'] == admission['whole_peak_bytes']):
        raise ValueError('same independently reviewed complete passive acquisition joins')
    science = checked(envelope['result'])['scientific_result']
    export_body = json.dumps(science['export'], sort_keys=True, separators=(',', ':'),
                             ensure_ascii=False, allow_nan=False).encode('utf8')
    if hashlib.sha256(export_body).hexdigest() != envelope['export_sha256']:
        raise ValueError('exact complete acquisition export seal')
    family = read(ROOT/'plan-family-v2.json')
    added = [pin(seal_path), pin(admission_path), admission['C_review'], admission['passive_join']]+list(envelope[k] for k in expected)
    materialized = []
    for row in family['jobs'][1:]:
        template = checked(row['plan_or_template'])
        if template['schema'] != 'proof-search-case-once-template-v1' or template['required_upstream_ids'] != ['acquire-0']:
            raise ValueError('exact previously frozen eval template')
        for source in template['files']:
            if pin(source['path']) != source:
                raise ValueError('reviewed eval Source/input changed')
        template['schema'] = 'proof-search-case-once-plan-v1'
        template['template_pending_fresh_acquisition'] = False
        template['upstream_receipts'] = [pin(seal_path)]
        template['files'] += added
        template['materialized_from'] = row['plan_or_template']
        template['files'].append(row['plan_or_template'])
        output = ROOT/'plans'/(row['stage_id']+'-v2.json')
        write(output, template)
        materialized.append(pin(output))
    write(ROOT/'materialized-evaluation-plans-v2.json', dict(schema='D17-eval-materialization-v1',
        acquisition_seal=pin(seal_path), acquisition_admission=pin(admission_path),
        plans=materialized, scientific_calls=0, grants=0,
        scope='Raw complete joins only. Exact materialized plans require independent review before one-use grants.'))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('mode', choices=['prepare','materialize'])
    parser.add_argument('--helper-handoff', type=Path)
    args = parser.parse_args()
    if args.mode == 'prepare':
        if args.helper_handoff is None:
            parser.error('prepare requires exact frozen passive helper handoff')
        prepare(args.helper_handoff)
    else:
        materialize()
