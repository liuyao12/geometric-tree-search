"""Source-only D17 custody composition; never imports scientific modules."""
from pathlib import Path
import ast
import hashlib
import json

REPO = Path(__file__).resolve().parents[3]
OLD = REPO / 'research-runs/gcts-principal-receptor-families-20261021/root'
HERE = Path(__file__).resolve().parent


def replace_once(text, before, after):
    if text.count(before) != 1:
        raise ValueError('exact Source replacement expected')
    return text.replace(before, after, 1)


INTAKE = '''def read_complete_pin(row):
    if type(row) is not dict or set(row) != {'path', 'bytes', 'sha256'}:
        raise ValueError('exact complete upstream pin fields')
    path = Path(row['path'])
    if '.partial' in path.name:
        raise ValueError('partial upstream files are never parsed')
    if raw_pin(path) != row:
        raise ValueError('changed complete upstream pin: '+str(path))
    return json.loads(path.read_bytes())


def intake_upstream(plan, check):
    """Only complete raw/custody joins; entry owns scientific revalidation."""
    check()
    if plan['stage'] not in ('acquire', 'evaluate'):
        raise ValueError('only fresh acquisition or fixed evaluation')
    expected = [] if plan['stage'] == 'acquire' else ['acquire-0']
    if plan['required_upstream_ids'] != expected:
        raise ValueError('one fresh acquisition, never historical mechanism adoption')
    rows = plan['upstream_receipts']
    if type(rows) is not list or len(rows) != len(expected):
        raise ValueError('exact upstream receipt population')
    if not rows:
        return dict(acquisition=None, receipt=None)
    envelope = read_complete_pin(rows[0])
    if not (type(envelope) is dict and set(envelope) == {
            'stage_id', 'stage', 'resource_admitted', 'stage_complete',
            'plan', 'result', 'header', 'terminal', 'observer',
            'export_sha256', 'whole_seconds', 'whole_peak_bytes', 'prior_cost_receipts'}
            and envelope['stage_id'] == expected[0] and envelope['stage'] == 'acquire'
            and envelope['resource_admitted'] is True
            and envelope['stage_complete'] is True
            and envelope['prior_cost_receipts'] == []):
        raise ValueError('exact complete Root-admitted acquisition envelope')
    source_plan = read_complete_pin(envelope['plan'])
    result = read_complete_pin(envelope['result'])
    header = read_complete_pin(envelope['header'])
    terminal = read_complete_pin(envelope['terminal'])
    observer = read_complete_pin(envelope['observer'])
    limits = source_plan['limits']
    if not (source_plan['case_id'] == result['case_id'] == header['case_id']
            == terminal['case_id'] == observer['case_id'] == expected[0]
            and source_plan['stage'] == envelope['stage']
            and source_plan['required_upstream_ids'] == source_plan['upstream_receipts'] == []
            and result['status'] == header['status'] == 'COMPLETE'
            and result['source_unchanged'] is True and result['first_Root_fault'] is False
            and header['source_unchanged'] is True
            and header['native_closed_and_reaped'] is True
            and header['first_Root_fault'] is False
            and header['result'] == terminal['result'] == envelope['result']
            and terminal['header'] == header and terminal['header_valid'] is True
            and terminal['sources_unchanged'] is True and terminal['threads_terminal'] is True
            and terminal['process_exit_code'] == observer['parent_exit_code'] == 0
            and terminal['reason'] is None and observer['reason'] is None
            and not terminal['errors'] and not observer['errors']
            and terminal['final_custody_gate_passed'] is True
            and terminal['known_exit_seconds'] <= limits['positive_seconds']
            and observer['resource_candidate_accepted'] is True
            and observer['fallback_trigger_seconds'] is None
            and observer['owned_child']['plan_sha256'] == envelope['plan']['sha256']
            and observer['final_conservative_whole_peak_bytes'] < limits['memory_bytes']
            and observer['final_observer_gate_seconds'] <= limits['custody_seconds']
            and envelope['whole_seconds'] == observer['elapsed_seconds']
            and envelope['whole_peak_bytes'] == observer['final_conservative_whole_peak_bytes']):
        raise ValueError('upstream complete custody/resource binding')
    science = result['scientific_result']
    if not (science['stage_complete'] is True and science['export'] is not None
            and hashlib.sha256(canonical(science['export'])).hexdigest()
            == envelope['export_sha256']):
        raise ValueError('exact complete scientific export binding')
    check()
    return dict(acquisition=science['export'], receipt=envelope)


'''


def pin(path):
    body = path.read_bytes()
    return dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def main():
    worker = (OLD / 'mechanism_worker_v1.py').read_text()
    worker = replace_once(worker,
        'Child-only entry for a fresh, declared principal-receptor mechanism actual.',
        'Child-only entry for a fresh, declared fixed principal-family search actual.')
    worker = replace_once(worker, 'def main(plan_path, directory, began):',
                          INTAKE + 'def main(plan_path, directory, began):')
    before = """        if plan['stage'] != 'mechanism':
            raise ValueError('exact declared principal-family mechanism stage')
        input_document = stage('READ fresh public mechanism statements',
            lambda: json.loads(Path(plan['input_path']).read_bytes()))
        scientific_result = stage('RUN searched-donor principal-family mechanism',
            lambda: entry.run_mechanism(input_document, check=check,
                limits=plan['experiment_limits'], modules=modules, oracle=oracle))
"""
    after = """        if plan['stage'] not in ('acquire', 'evaluate'):
            raise ValueError('exact declared fixed principal-family stage')
        upstream_payloads = stage('INTAKE fresh complete acquisition export',
            lambda: intake_upstream(plan, check))
        # Each worker reads only its phase's public statement document. No
        # evaluation body is a Source pin of the acquisition actual.
        input_document = stage('READ phase-only principal-family input',
            lambda: json.loads(Path(plan['input_path']).read_bytes()))
        scientific_result = stage('RUN complete fixed principal-family stage',
            lambda: entry.run_fixed_stage(input_document, upstream_payloads,
                stage=plan['stage'], stage_id=plan['case_id'], check=check,
                limits=plan['experiment_limits'], modules=modules, oracle=oracle))
"""
    worker = replace_once(worker, before, after)
    worker = replace_once(worker,
        "'scope': 'Fresh fixed-dependency, nonhostile searched-donor receptor-family mechanism; '",
        "'scope': 'Fresh fixed-dependency, nonhostile fixed principal-family search; '")
    worker = replace_once(worker, 'usage: mechanism_worker_v1.py', 'usage: fixed_family_worker_v1.py')
    target = HERE / 'fixed_family_worker_v1.py'
    with target.open('x') as stream:
        stream.write(worker)
    for source, destination in (
            ('run_mechanism_once_v1.py', 'run_fixed_family_once_v1.py'),
            ('observe_mechanism_once_v1.py', 'observe_fixed_family_once_v1.py')):
        with (HERE / destination).open('xb') as stream:
            stream.write((OLD / source).read_bytes())
    records = []
    for path in (target, HERE/'run_fixed_family_once_v1.py', HERE/'observe_fixed_family_once_v1.py'):
        source = path.read_text()
        ast.parse(source)
        compile(source, str(path), 'exec')  # Never execute the resulting code.
        records.append(pin(path))
    report = dict(schema='D17-custody-Source-composition-v1',
        scientific_imports=0, scientific_calls=0, Source_only=True,
        base_worker=pin(OLD/'mechanism_worker_v1.py'), outputs=records,
        deltas=['single fresh dual acquisition intake; no policy/training/history',
                'acquire/evaluate run_fixed_stage ABI',
                'otherwise D16 whole Native starts guard, deadlines, custody unchanged'],
        parent_and_observer_byte_exact_to_D16=True)
    with (HERE / 'custody-Source-composition-v1.json').open('x') as stream:
        json.dump(report, stream, indent=2, sort_keys=True)
        stream.write('\n')
    print(json.dumps(report, sort_keys=True))


if __name__ == '__main__':
    main()
