"""Pure passive Root seal after complete joins and independent actual review.

No scientific module, checker, miner, fixture or proof search is imported.
The exact 13-field seal is a custody envelope, never a new proof certificate.
"""
from pathlib import Path
import hashlib
import json
import argparse

ROOT = Path(__file__).resolve().parent
STUDY = ROOT.parent


def pin(path):
    path = Path(path).resolve()
    if '.partial' in path.name:
        raise ValueError('no partial artifact may enter admission')
    body = path.read_bytes()
    return dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def read(path):
    row = pin(path)
    return json.loads(Path(row['path']).read_bytes())


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2, allow_nan=False)
        stream.write('\n')


def main(join_path, review_path):
    plan_path = ROOT/'plans/acquire-0-v1.json'
    paths = dict(plan=plan_path, result=STUDY/'actual/acquire-0/result.json',
        header=STUDY/'actual/acquire-0/worker-header.json',
        terminal=STUDY/'actual/acquire-0/terminal.json',
        observer=STUDY/'actual/acquire-0.observer/observer.json')
    pins = {key: pin(path) for key, path in paths.items()}
    joined = read(join_path)
    reviewed = read(review_path)
    for key in pins:
        if joined[key] != pins[key]:
            raise ValueError('passive report is not for this unique fresh complete D17 acquisition')
    if not (all(joined[key] is True for key in (
            'resource_admitted', 'scientific_qualified', 'candidate_admission', 'stage_complete'))
            and reviewed['review_passed'] is True and reviewed['resource_admitted'] is True
            and reviewed['scientific_qualified'] is True and reviewed['plan'] == pins['plan']
            and reviewed['result'] == pins['result'] and reviewed['passive_join'] == pin(join_path)):
        raise ValueError('complete passive gates and independent exact actual review required')
    plan = read(plan_path)
    result = read(paths['result'])
    observer = read(paths['observer'])
    science = result['scientific_result']
    if not (plan['case_id'] == result['case_id'] == 'acquire-0' and plan['stage'] == 'acquire'
            and result['status'] == 'COMPLETE' and science['stage'] == 'acquire'
            and science['stage_id'] == 'acquire-0' and science['stage_complete'] is True
            and science['qualified'] is True and science['job_record_complete'] is True
            and science['export'] is not None
            and joined['whole_seconds'] == observer['elapsed_seconds']
            and joined['whole_peak_bytes'] == observer['final_conservative_whole_peak_bytes']):
        raise ValueError('complete fresh acquisition, unique whole-cost samples')
    export_body = json.dumps(science['export'], sort_keys=True, separators=(',', ':'),
                             ensure_ascii=False, allow_nan=False).encode('utf8')
    admission = dict(schema='D17-Root-whole-admission-v1', stage_id='acquire-0', stage='acquire',
        resource_admitted=True, scientific_qualified=True, stage_complete=True, admitted=True,
        **pins, C_review=pin(review_path), passive_join=pin(join_path),
        whole_seconds=joined['whole_seconds'], whole_peak_bytes=joined['whole_peak_bytes'],
        scope='Root custody admission after independent complete actual review. Not a new proof rule, Native replay, prior-artifact adoption or zero-cost acquisition.')
    envelope = dict(stage_id='acquire-0', stage='acquire', resource_admitted=True,
        stage_complete=True, **pins, export_sha256=hashlib.sha256(export_body).hexdigest(),
        whole_seconds=joined['whole_seconds'], whole_peak_bytes=joined['whole_peak_bytes'], prior_cost_receipts=[])
    if len(envelope) != 13:
        raise ValueError('exact existing single-upstream ABI')
    # Both names are fresh, exclusive destinations. A crash between complete
    # writes cannot authorize evaluation: the materializer requires both.
    admission_path = ROOT/'admission/acquire-0-v1.json'
    seal_path = ROOT/'seals/acquire-0-v1.json'
    if admission_path.exists() or seal_path.exists():
        raise ValueError('no overwrite, rerun, reseal or historical adoption')
    write(admission_path, admission)
    write(seal_path, envelope)
    print(json.dumps(dict(admission=pin(admission_path), seal=pin(seal_path)), sort_keys=True))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--join', required=True, type=Path)
    parser.add_argument('--review', required=True, type=Path)
    args = parser.parse_args()
    main(args.join, args.review)
