"""Insert one task-owned literal section in the isolated allowed reader only."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
PUBLISHER = ROOT.parent / 'gcts-batch-20261020/publisher'
TARGET = PUBLISHER / 'docs/research/gcts-rl-renewal/conditional-inventory/reader.html'


def pin(path):
    body = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(body),
                sha256=hashlib.sha256(body).hexdigest())


def main():
    before = TARGET.read_bytes()
    assert len(before) == 117644
    assert hashlib.sha256(before).hexdigest() == '14582d521129def00d8cd86623b56ed9169652fe06248a3f0007fa5a230ea95d'
    # Publish only after independent actual review and Root admission exist.
    admissions = sorted((ROOT/'root/admission').glob('eval-*-v1.json'))
    assert len(admissions) == 16
    accepted = rejected = 0
    for path in admissions:
        value = json.loads(path.read_bytes())
        assert value['schema'] == 'D17-Root-whole-admission-v1'
        accepted += value['admitted'] is True
        rejected += value['admitted'] is False
    assert (accepted, rejected) == (14, 2)
    data = json.loads((ROOT/'publication/principal-family-search-data.json').read_bytes())
    assert len(data['slots']) == 64
    assert sum(s['admitted_proof'] is True for s in data['slots']) == 50
    assert sum(s['returned'] is True for s in data['slots']) == 56
    section_path = ROOT/'publication/reader-section-v1.html'
    section = section_path.read_bytes().rstrip(b'\n') + b'\n'
    anchor = b'<section id="parallel-research-update"'
    assert before.count(anchor) == 1
    assert b'id="principal-family-search-update"' not in before
    after = before.replace(anchor, section + anchor, 1)
    assert after.replace(section, b'', 1) == before
    TARGET.write_bytes(after)
    receipt = {
        'schema': 'D17-single-reader-literal-insertion-v1',
        'before': {'bytes': len(before), 'sha256': hashlib.sha256(before).hexdigest()},
        'inserted_section': pin(section_path), 'after': pin(TARGET),
        'exact_inverse_matches_previous_reader': True,
        'scope': 'One new result section in the isolated allowed reader. All prior bytes retained exactly. No primary reader or other website files touched.'}
    with (ROOT/'root/reader-insertion-v1.json').open('x') as stream:
        stream.write(json.dumps(receipt, indent=2, sort_keys=True)+'\n')
    print(json.dumps(receipt))


if __name__ == '__main__':
    main()
