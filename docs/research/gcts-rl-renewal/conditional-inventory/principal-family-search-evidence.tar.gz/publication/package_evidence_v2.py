"""Closed raw evidence archive. No scientific imports, calls or partial parsing."""
from pathlib import Path, PurePosixPath
import gzip
import hashlib
import io
import json
import tarfile

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT.parents[1]
OUT = ROOT / 'publication'


def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=True,
                       allow_nan=False) + '\n').encode()


def pin(path):
    path = Path(path).resolve()
    body = path.read_bytes()
    return {'path': str(path), 'bytes': len(body),
            'sha256': hashlib.sha256(body).hexdigest()}


def main():
    # Explicit task-owned roots only. The primary reader, .gcts-active and
    # unrelated project files are never traversed. Later publication receipts
    # are outside this closed snapshot, not retroactive evidence changes.
    paths = {}
    for folder in ('root', 'runtime', 'implementation-B', 'diagnostics-L',
                   'review-C', 'actual'):
        for path in sorted((ROOT / folder).rglob('*')):
            if path.is_symlink():
                raise ValueError('no symbolic archive input')
            if path.is_file():
                paths[str(path.relative_to(ROOT))] = path
    for name in ('package_evidence_v1.py', 'package_evidence_v2.py',
                 'reader-section-v1.html', 'reader-section-v2.html',
                 'install_reader_section_v1.py', 'install_reader_section_v2.py',
                 'principal-family-search-data.json', 'principal-family-search.html'):
        path = OUT / name
        assert path.is_file() and not path.is_symlink()
        paths['publication/' + name] = path
    manifest_doc = json.loads((ROOT / 'root/materialized-evaluation-plans-v2.json').read_bytes())
    plan_paths = [ROOT / 'root/plans/acquire-0-v2.json'] + [Path(p['path']) for p in manifest_doc['plans']]
    external = {}
    interpreter = None
    for plan_path in plan_paths:
        plan = json.loads(plan_path.read_bytes())
        assert interpreter is None or interpreter == plan['python']
        interpreter = plan['python']
        for row in plan['files']:
            current = pin(row['path'])
            assert current == {k: row[k] for k in ('path', 'bytes', 'sha256')}
            path = Path(row['path'])
            if not path.is_relative_to(ROOT):
                external[str(path)] = row
    omitted = []
    for row in external.values():
        path = Path(row['path'])
        if row == interpreter:
            omitted.append(dict(**row, reason='Pinned isolated interpreter identity only; executable is not redistributed.'))
            continue
        assert path.is_relative_to(REPO), path
        name = 'declared-dependencies/' + str(path.relative_to(REPO))
        assert name not in paths
        paths[name] = path
    pairs = sorted(paths.items())
    for name, path in pairs:
        assert not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts
        assert not path.is_symlink()
    rows = [dict(archive_path=name, raw_partial_opaque=('.partial' in path.name),
                 **pin(path)) for name, path in pairs]
    snapshot = {
        'schema': 'D17-complete-raw-evidence-snapshot-v1',
        'files': rows, 'omitted_runtime': omitted,
        'raw_partial_files': sum(r['raw_partial_opaque'] for r in rows),
        'partial_files_parsed': False, 'scientific_calls': 0,
        'scope': 'Closed raw task Source, plans, grants, fixed dependencies, all once actuals, complete failure/custody/review/admission records, and passive display. Any .partial member is opaque raw bytes only, never parsed, reconstructed or admitted. Historical declared dependencies are Source/provenance only; no old proof/library/policy is adopted. Later live-publication receipts remain outside this snapshot.'}
    manifest_body = encoded(snapshot)
    archive = OUT / 'principal-family-search-evidence.tar.gz'
    with archive.open('xb') as target:
        with gzip.GzipFile(fileobj=target, mode='wb', filename='', mtime=0,
                           compresslevel=9) as compressed:
            with tarfile.open(fileobj=compressed, mode='w') as tar:
                def add(name, body):
                    info = tarfile.TarInfo(name)
                    info.size = len(body)
                    info.mtime = info.uid = info.gid = 0
                    info.mode = 0o644
                    tar.addfile(info, io.BytesIO(body))
                add('snapshot-manifest.json', manifest_body)
                for row, (name, path) in zip(rows, pairs):
                    body = path.read_bytes()
                    assert len(body) == row['bytes'] and hashlib.sha256(body).hexdigest() == row['sha256']
                    add(name, body)
    for row, (_, path) in zip(rows, pairs):
        assert pin(path) == {k: row[k] for k in ('path', 'bytes', 'sha256')}
    # Read every archived member as raw bytes and verify completeness without
    # extracting or interpreting any scientific or partial payload.
    expected = {'snapshot-manifest.json': (len(manifest_body), hashlib.sha256(manifest_body).hexdigest())}
    expected.update({r['archive_path']: (r['bytes'], r['sha256']) for r in rows})
    seen = set()
    with tarfile.open(archive, 'r:gz') as tar:
        for member in tar:
            assert member.isfile() and member.name not in seen and member.name in expected
            seen.add(member.name)
            body = tar.extractfile(member).read()
            assert (len(body), hashlib.sha256(body).hexdigest()) == expected[member.name]
    assert seen == set(expected)
    final = dict(snapshot, archive=pin(archive), regular_files=len(expected),
                 uncompressed_source_bytes=sum(row['bytes'] for row in rows),
                 snapshot_manifest_sha256=hashlib.sha256(manifest_body).hexdigest(),
                 snapshot_manifest_bytes=len(manifest_body),
                 all_members_raw_verified=True)
    final_path = OUT / 'principal-family-search-manifest.json'
    with final_path.open('xb') as stream:
        stream.write(encoded(final))
    print(json.dumps({'archive': pin(archive), 'manifest': pin(final_path),
                      'regular_files': len(expected),
                      'raw_bytes': final['uncompressed_source_bytes'],
                      'partial_files': snapshot['raw_partial_files'],
                      'scientific_calls': 0}))


if __name__ == '__main__':
    main()
