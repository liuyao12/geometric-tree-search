Independent semantic event certificates, 2026-11-03.

Download EVERY semantic-certificates-evidence-v1-part-NNN.zip and the external
semantic-certificates-evidence-manifest-v1.json. Each ZIP is at most 44 MiB.
Extract all volumes together; each contains the same ARCHIVE-file-manifest-v1.json.
Every original path present at the current cut is physically stored exactly once,
with exact original bytes/SHA256 and all CRC checks. No aliases or reconstruction
recipes replace files. Generated package outputs cannot archive themselves;
receipts created after the cut remain later local custody evidence.

The full current Sources, raw outcomes, actual tiny producer observations,
semantic certificates, full-observation and assignment checks, mutation packets,
logs, plans, review/API/baseline/publication tools and reader assets are included.
All 80 actual historical input copies are physically included under their exact
input/retrospective paths. The predecessor full 293-original evidence archive
remains separately published and linked at resource-diagnostic-evidence-v1.html;
this archive does not claim to contain those 293 predecessor originals.
Local file paths, logs and the full task evidence are approved for this existing
public destination. No frozen science or old run has been rewritten.

Serve this extracted directory and open report/semantic-certificates-v1.html.
Thirteen fresh generic explicit point fixtures each had one actual audited
engine call, semantic certificate check, old full-observation check, independent
all-subset oracle and every-state derived/actual graph comparison. Twenty
corruption/refusal controls preserve explicit UNKNOWNs and metadata scopes.
The retrospective phase only checked eight saved records: no engine reruns.
Six semantic certificates are VERIFIED, including two fixed-inventory finite
exhaustions; two records remain UNKNOWN. The original first native exit one remains
FAILED_POSTCHECK_AFTER_SCIENCE and execution_unadmitted despite its independently
valid positive evidence. A new certificate does not repair that process failure.

Semantic event exhaustion is conditional on the exact finite explicit inventory;
it is not unrestricted mathematical nonprovability. Actual intermediate producer
tables were observed/compared only in tiny qualification, not in retrospective
records. Dead contexts require full model/trace/exclusion provenance and are not
standalone learned markings. The ternary expressivity analysis is supplied
mathematics checked against saved evidence, not a learned discovery. No new
native mathematical theorem, search speed gain, RL or learned-marking advantage,
PA/Hilbert or unrestricted FOL completeness, universal Wang search or whole-plane
tiling result is established. The research program remains ACTIVE.
