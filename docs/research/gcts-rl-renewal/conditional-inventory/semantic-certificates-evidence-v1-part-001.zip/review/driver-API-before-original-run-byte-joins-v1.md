# Semantic assurance driver API, before execution

`source/run_semantic_assurance_v1.py` is Source-only until Root has read the full
body, received peer closure and authorized a prospective freeze. It imports no
scientific module at module load time. No engine, checker, assignment oracle or
native logical kernel has been called in preparing this driver.

The unchanged engine, complete explicit inventory, lexical order and scheduler
are the subject. This milestone adds an independent semantic event certificate;
it does not change the engine, learn markings, run RL or compare search speed.
The master reference is the copied `reference/basic-tiling-algorithm.md`, pinned
to `c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9`.

## Commands and phase custody

The future authorized invocations use the same Python executable with
`-I -S -B` throughout:

```text
python -I -S -B source/run_semantic_assurance_v1.py freeze
python -I -S -B source/run_semantic_assurance_v1.py run qualify
python -I -S -B source/run_semantic_assurance_v1.py run retrospective
```

These commands are documentation, not a record of execution. `freeze` writes
`data/protocol-frozen-v1.json` exclusively. It pins the exact file set beneath
`source/`, `reference/`, `input/` and `plan/`, plus the input-copy receipt, current
master bytes, executable bytes and flags, all limits and both declared phases.
No refreeze is supported. `unchanged()` returns one protocol dictionary; worker
and observer postchecks read its `status` key directly. No tuple return contract
is used. Inputs and frozen Sources must remain unchanged through both phases.

`run` launches exactly one owned child in a new process group, redirects its
combined log and observes its actual exit. It polls only that child's RSS and
uses an owned CPU limit. Observer errors or failed RSS probes fail closed and
trigger bounded TERM/KILL/reap cleanup of that group. Polled RSS is not a strict
instantaneous memory guarantee. No phase is silently retried. Existing phase
logs or outputs block a second attempt.

Each phase records `data/<phase>-started.json`, `review/<phase>-native.log`,
`review/<phase>-invocation.json`, `review/<phase>-observer.json` and, if science
returns, `data/<phase>-result.json`. The invocation binds the saved result bytes
and scientific status. The retrospective gate requires a fully qualified
13-case/20-control result plus matching phase/PID/protocol, actual exit zero,
clean observer and unchanged pre/post custody. Scientific UNKNOWN remains a
scientific outcome, distinct from process failure.

## Frozen limits

| Scope | Prospective limit |
| --- | --- |
| Each tiny engine call | `wall_seconds=3`, `max_work=1000000000`, `max_nodes=10000`, `max_events=10000`, `max_rollback_records=10000`, `max_candidates=1000`, `max_points=128` |
| Each public semantic check | `max_items=100000000`, `max_work=10000000000`, `wall_seconds=30` |
| Each qualification private Reader pass | The same semantic limits, as a separate call |
| Each actual full-snapshot check | `max_items=100000000`, `wall_seconds=30` |
| Each assignment oracle | `max_candidates=16`, `max_assignments=65536`, `wall_seconds=10`, `max_items=200000`, `max_work=10000000` |
| Each whole owned phase | wall 1200 seconds, CPU 900 seconds, polled RSS 1073741824 bytes |
| Each saved JSON artifact | 268435456 uncompressed bytes |

The semantic work limit is deliberately prospective and generous because its
Source counts operations differently from the engine. These limits are not
comparable work units. Capture is streamed and exclusive. A byte-bound refusal
retains an explicitly incomplete prefix and separate refusal metadata; it never
presents that prefix as a complete JSON result or a proof of absence.

## Fresh qualification: one engine call per fixture

The declaration is `plan/semantic-qualification-cases-v1.json`: 13 literal fresh
models and 20 corruption/resource controls. Analytic expected outcomes are
prospective fixture assertions, not supplied selected solutions. The unmarked
ternary fixture is included before freeze; its actual search and assignment
sets will be observed, not injected.

For each case `id`, artifacts are under `data/qualification/<id>/`:

| Artifact | Origin |
| --- | --- |
| `model.json` | Exact declared model |
| `raw-engine-result.json.gz` | One actual `E.solve(model, POINT, audit=callback, order=None)` call |
| `actual-observations.json.gz` | Actual callback rows `{event,state}`, never reconstructed payloads |
| `semantic-certificate.json` | Public `C.verify_explicit_events(model, raw, **SEMANTIC)` |
| `actual-full-snapshot-check.json` | Existing `T.verify(model, universe, actual_observations, raw, **FULL_TRACE)` |
| `incremental-versus-actual-graphs.json` | Separate bounded private `C.Reader` replay against every actual callback graph |
| `assignment-oracle.json.gz` | Independent exhaustive candidate-subset oracle |
| `attempt-summary.json` | All returned statuses and exact artifact refs, saved before outcome assertions |
| `qualified-summary.json` | Definite status, complete gates and required actual observations all pass |

Raw result and actual observations are saved before assurance calls. `stage`
records call time, write time and their combined pipeline time separately in
artifact refs. The callback cost is part of this single audited engine call;
this is qualification, not a timed search benchmark.

The private Reader pass uses the exact pinned `C.Meter` and `C.Reader` Source.
It scans all inputs within a fresh budget, advances once per actual event and
compares its complete derived snapshot with the actual callback snapshot. It
records event sequence/kind, derived pre/post hashes, actual observation hash,
equality and point/edge/selection counts. The old full checker independently
re-enumerates the universe against those same actual snapshots. The public
semantic check remains a separate complete-certificate gate. Neither the
derived graphs nor fabricated callback payloads are passed to the old checker.
This extra pass occurs only on tiny qualification fixtures, not retrospective
inputs. Its call count and cost remain explicit.

The result has status `QUALIFIED_FRESH_SEMANTIC_ASSURANCE`, `cases`, `mutations`,
`counts` and `scope`. Each case row has `id`, `raw_status`,
`semantic_status`, `full_snapshot_status`, `oracle_status`,
`incremental_graph_comparison_status`, `engine_calls=1`,
`semantic_public_calls=1`, `private_reader_passes=1`, `refs`, `seconds`,
`status=QUALIFIED`, `semantic_claim` and `required_observations`.
The refs keys are `model`, `raw`, `observations`, `semantic`, `full_snapshot`,
`incremental_graph_comparison` and `oracle`.

Mutation packets are generated from the actual fresh raw results by the pure
`semantic_mutations_v1.build(models, results, declarations)` function and saved
before checking. Each declares target `SEMANTIC` or `ASSIGNMENT_ORACLE`; limits
overrides apply to that target only. Missing event anchors block qualification
as `NOT_EXERCISED`. Input, receipt and comparison are saved as
`data/mutations/<id>-{input.json.gz,receipt.json,comparison.json}`. In particular,
complete events with legitimately capped rollback rows may be VERIFIED while
reporting `rollback_metadata_coverage=PREFIX`; truncated events or resources
must not be admitted as absence.

## Eight historical records: checker only

`plan/retrospective-inputs-v1.json` pins exactly eight physically copied raw
records and their original model/declaration/gate/protocol/process evidence.
The retrospective function loads only `semantic_event_checker_v1.py`. It does
not load or call the engine, full-snapshot checker, assignment oracle, mutation
builder, native logical kernel or proof decoder. Historical selections never
enter qualification searches.

Each model/universe is associated with its retained original complete-model
gate. All copied input bytes are checked before use. Original started,
invocation and observer phase/PID/protocol/exit/postcheck context are joined.
The first CALv1 process remains `FAILED_POSTCHECK_AFTER_SCIENCE`, native exit one
and `execution_admitted=false`. Seven later clean processes retain their own
original classifications. An independently verified semantic certificate
cannot change any historical process classification.

For each `id`, `data/retrospective/<id>/semantic-certificate.json` is the new
receipt and `record.json` contains `raw_status`, `old_science_status`,
`original_process`, `new_semantic_status`, `new_semantic_claim`,
`bounded_absence`, `event_coverage`, `rollback_metadata_coverage`, original
`inputs`, new `receipt`, measured `costs` and `scope`. No expected semantic
admission is encoded. Raw UNKNOWN can never be promoted to VERIFIED. The phase
status is `RETROSPECTIVE_CHECKS_RECORDED_WITH_EXPLICIT_SCOPES`, with all eight
records, observed counts and `engine_reruns=0`.

## Claim boundary

Complete semantic events can certify a finite explicit-inventory exhaustion.
This is distinct from equality of every producer intermediate table. The latter
is checked directly only in the tiny qualification comparison; historical
claims concern reconstructed semantic graphs and actual serialized endpoints.
Retained rollback metadata may be a valid prefix without invalidating a
complete semantic event proof. Hashes establish custody associations, not
logical truth. No unrestricted mathematical nonprovability, native theorem,
Wang-grid/universal-logic result, search speed gain or RL advantage follows from
this milestone.
