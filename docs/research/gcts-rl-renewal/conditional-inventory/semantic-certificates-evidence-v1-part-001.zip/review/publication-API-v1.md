# Semantic certificates publication: Source-only handoff

All five scripts under `publication/` adapt the exact CALv2 publication Sources
from the existing public commit `12a97f97006aa40d227e61f99f5155cd7737a034`.
The originals are retained byte-for-byte under
`review/publication-cal2-baseline-v1/`; their pins are in
`review/publication-baseline-pins-v1.json`. The complete adaptation is
`review/publication-adaptation-diff-v1.patch`. Preparation consisted of ordinary
Source editing, static AST parsing and existing metadata inspection. None of
these publication tools has been imported or executed. No package, report build,
Git/network call, upload, live download, mirror copy or scientific replay is
authorized by this handoff alone. Root must read the full Sources before use.

The existing destination is unchanged:
`docs/research/gcts-rl-renewal/conditional-inventory/` in
`liuyao12/geometric-tree-search`. The new reader and evidence names are
`semantic-certificates-v1.html`, `semantic-certificates-evidence-v1.html`,
`semantic-certificates-results-v1.json.gz` and
`semantic-certificates-downloads-v1/`. Archive names are
`semantic-certificates-evidence-v1-part-NNN.zip` and
`semantic-certificates-evidence-manifest-v1.json`.
The exact archive-link marker is `SEMANTIC_CERTIFICATES_ARCHIVE_LINK`.
The sole allowed modified existing web path is `resource-diagnostic-v1.html`,
receiving one backlink. Every new path collision is refused. No primary checkout
or primary Git index is staged.

## Current evidence gates

The summary must have schema `Semantic-certificates-saved-summary-v1`, status
`ADMITTED_SEMANTIC_CERTIFICATES_WITH_EXPLICIT_UNKNOWN`; the saved audit must have
schema `Semantic-certificates-saved-data-audit-v1`, status
`PASS_SAVED_DATA_AUDIT`. The summary's `saved_data_audit` ref must point exactly
to `review/saved-data-audit-v1.json` and match its bytes and SHA256. Qualification
and retrospective counts/IDs/process classifications are joined to the actual
phase result files; independent status strings alone are insufficient.

Mandatory readiness paths and statuses:

- `review/saved-data-audit-v1.json`: `PASS_SAVED_DATA_AUDIT`.
- `review/report-build-v1.json`: `PASS_REPORT_BUILD`.
- `review/local-ui-qualification-v1.json`: `PASS_LOCAL_UI`, zero math errors,
  no body overflow or console entries, and exact final main-page bytes.
- `review/root-publication-admission-v1.json`: `PASS`, written by Root after
  final report/UI/content readiness.
- `review/root-source-admission-v1.json`:
  `PASS_SOURCE_REVIEW_BEFORE_FREEZE`, a historical pre-execution gate which
  cannot stand in for publication admission.

`verify_protocol` checks the exact 101 frozen scientific/input/plan files, the
prospectively frozen protocol bytes, reviewed driver and two peer receipts,
current runtime executable/flags, copied/current master and Root's source-review
ref list. It requires both declared current phases (`qualify`, `retrospective`)
to have matching started/invocation/observer phase, PID and protocol, actual
native exit zero, no guard/observer/reap/postcheck failure, and an invocation
whose scientific status and complete saved-result bytes match the actual result.
No search/checker/kernel is rerun by any publication gate.

The qualified result must retain 13 actual cases, one engine call/public semantic
check/private Reader pass per case, all semantic/full-observation/paired-graph
checks VERIFIED and assignment oracles EXHAUSTED. All 20 corruption/refusal
controls must match their declared outcomes. The summary retains six VERIFIED
and two UNKNOWN retrospective results, including exactly two fixed-inventory
finite-exhaustion certificates. Raw UNKNOWN and truncated streams cannot become
absence claims.

## Historical custody without replacing the predecessor archive

`verify_history` checks all 80 current copied historical input paths physically,
using the frozen eight-case manifest. Every path is unique and matches its
bytes/SHA256; the set is exactly the current `input/` file set. Original
started/invocation/observer/protocol/PID/log/result/input-ref associations are
checked as retained metadata. The first historical process remains native exit
one, `FAILED_POSTCHECK_AFTER_SCIENCE` and `execution_admitted=false`, with the
literal tuple-postcheck error preserved. Seven historical continuation processes
retain their own clean classifications. A new semantic certificate does not
repair or relabel any historical process.

The current physical archive contains those 80 copies and all current milestone
originals at its cut. It does not claim that the predecessor's 293 original files
are stored here. That complete older archive remains linked through
`resource-diagnostic-evidence-v1.html`. The manifest field
`preserved_retrospective_inputs` directly enumerates the 80 copied paths and
the eight original process classifications. All copied paths also occur in the
ordinary full archive file list with part assignments.

## Local planning, packaging and isolated commit

`package_publish_v1.py --prepare-links` writes only the archive README, link-plan
metadata and bounded archive-link blocks in the two current report pages. It
does not build a ZIP, contact the network, stage Git or push. Final local UI must
be revalidated after link injection; the final page hashes and planned volume
count are required at packaging. A changed partition count requires reviewing
links/UI again before any archive is built.

The later packaging invocation takes an explicitly reviewed 40-character remote
base and refuses an existing package, prepared commit or isolated index. Every
current original file at the cut is included: Sources, all scientific raw and
observed graphs, receipts, mutations, plans, docs, review/API/baseline files,
publication planning tools and rendered reader assets. Only the generated
`package/` directory is excluded because an archive cannot include itself.
Receipts created after that cut remain later custody evidence. Nothing present
at the cut may subsequently be changed, including publication metadata.

Each original path is physically stored exactly once across independent ZIP
volumes, including byte-identical files with different original paths. No alias
or deduplication recipe replaces bytes. Every part is at most 44 MiB and below
the 50 MiB web-asset ceiling. Each part includes the same internal full manifest.
Verification checks exact member sets, all CRCs, original uncompressed sizes and
SHA256 values, final ZIP pins and all 80 historical copied-path memberships.

After physical verification, an official read-only GitHub GET confirms that main
still equals the reviewed base. The local tree/commit is prepared in the existing
isolated bare repository and task-owned index, with hooks disabled. All changed
paths must be additions except the sole `resource-diagnostic-v1.html` backlink.
The commit has exactly that reviewed base as its sole parent. This script never
pushes. Root's later publication uses a normal non-force push; if remote main has
moved, the task requires review against the new base rather than overwriting it.

## Observation, live bytes and completion

`observe_github_v1.py` makes bounded official GETs for remote main, exact
commit/tree/sole-parent and the matching Pages repository/branch/head/completed-
success state. Replaced observation receipts are retained. It cannot push or
POST. `verify_live_v1.py` is byte-identical to the hardened CALv2 tool: normal TLS,
HTTPS-only redirects, HTTP/1.1, and exact bytes for every prepared asset followed
by full physical-member/CRC verification of downloaded ZIPs. Any failed body or
archive prevents completion; retrying transport does not rerun science.

`complete_publication_v1.py` requires remote/Pages/live-byte/UI, archive, summary,
audit, readiness and frozen-protocol evidence to agree. It rechecks every original
file's bytes at the archive cut. The primary-project research-run mirror accepts
existing files only when byte-identical; all collisions are preflighted before
copying missing files. Each copy is verified. Completion receipts are created
exclusively or accepted only if already identical. No scientific or frozen file
is changed, and the research program remains ACTIVE.

These tools do not strengthen the underlying scientific scope: the new result
is a qualified semantic certificate for the declared finite explicit inventory,
not equality of every historical producer table. Dead contexts need complete
trace/exclusion provenance. No standalone learned marking, RL or speed advantage,
new native mathematical theorem, unrestricted nonprovability, PA/Hilbert
completeness, universal Wang system or whole-plane tiling is established.
