# Independent semantic checker: Source review

Status: **PASS_SOURCE_REVIEW_PENDING_EXECUTED_QUALIFICATION**. This is a
read-only review of the full Source bodies and API, not an import, execution,
model construction, event replay, native check or scientific result.

Reviewed `source/semantic_event_checker_v1.py`: \(39{,}367\) bytes, SHA256
`6985af4d1f56789c1237522141b1d04815370566dd99cb22da6a048eb6bc0613`.
Reviewed `plan/semantic-checker-API-v1.md`: \(8{,}912\) bytes, SHA256
`5330e9b851b6b3109985f7dd96efdcdd4c1fcd089eadb5e29fae6853b6fe8829`.
The unchanged engine and master were read as references; their pins are in the
active protocol. No other agent's Source was edited.

No blocking logical or interface fault was found at these pins.

- The checker builds independent immutable positive-support and marking-support
  reverse indexes from the complete EXPLICIT universe. Placement changes
  recheck whole-support legality for the union of affected buckets, then update
  every incident active domain. Mark-only contacts, assigned zero, unequal
  integer edge weights, selected-once identity and incomplete residuals are
  preserved. Newly active and completed obligations are handled separately.
- Its own trail restores totals, marking values/reference counts, active and
  selected generations, selected/excluded membership, eligibility, forward and
  reverse incidence, domains, loaded history and edge count. The branch
  checkpoint precedes the chosen placement and retains earlier parent
  exclusions. Forced descendants undo with that selected branch; child-local
  exclusions do not leak to an ancestor or sibling.
- Complete domain reconstruction justifies global dead before forced before
  earliest generation. Branching is a selected-versus-excluded split with the
  full lexical domain. `EXCLUDE` requires the latest checked dead child and
  exact saved frame; raw UNKNOWN cannot justify it. This supports finite
  refutation over this frozen universe, including weighted contributions;
  it supplies no unrestricted native nonprovability claim.
- Literal protocol checks distinguish native integers from booleans/floats,
  compare canonical bytes rather than Python numeric equality, validate event
  order/count/hash, and independently recompute actual saved endpoints.
  Complete semantic counters, including the main-loop node count, are joined
  separately from unverified physical-operation counters and timings.
- Event and optional rollback coverage remain distinct. Missing event payload
  is UNKNOWN. Complete events can certify semantics with prefix-only rollback
  metadata; retained rollback rows still require exact types/arithmetic and
  the independently derived failure-parent association. Actual intermediate
  producer bookkeeping is explicitly `NOT_CHECKED`.
- Resource scanning charges literal string/key lengths, recursive structure,
  conservative serialization bounds, independent updates and owned trail
  storage; long loops check time. Caps/memory/depth refusal stay UNKNOWN and
  never manufacture a failed child. Work units remain checker-specific.
- Exported dead contexts are explicitly semantic preimages bound to the model
  and complete trace/exclusion provenance. Their bounded sample and hashes
  are not promoted to standalone reusable clauses or GCTS markings.

Executed qualification remains mandatory. Root's proposed extra receiver
replay should compare `Reader.snapshot()` **after each actual saved engine
event** with that event's actually observed producer snapshot, independently
checked by the old full-universe checker. This tests the receiver's incremental
graph against real observations without relabeling receiver-generated graphs
as producer observations in ordinary lean verification. It does not require a
second engine run. The separate tiny all-subset assignment oracle checks
existence without reproducing the scheduler or graph implementation.

Fresh qualification declarations cover generation lowering, sibling revival,
reference counts and remote mark-only effects; mutation packets test coherent
rehashing, malformed types, incomplete event retention and weaker optional
rollback coverage. Their expected statuses are prospective only. No review
claim substitutes for the actual checks or changes any archived status.
