# Independent semantic search certificate: Source-only design

Status: **DESIGN_ONLY_PENDING_ROOT_REVIEW**. No implementation, model construction,
search, scientific import, proof replay, or historical-result verification was
performed for this note. The current calibration archive is untouched. This is
a proposal for a new checker and prospective qualification, not a new claim
about any archived result.

## Recommendation and assurance boundary

Start with a complete **explicit, immutable, finite placement universe** and the
engine's existing fully retained event stream. Independently reconstruct the
point state and complete semantic candidate graph. Check every scheduling
decision and the failed-child/exclusion stack. This can certify finite search
exhaustion without retaining a producer graph snapshot at every event and
without changing the engine. A low-level mutation journal is not necessary for
this first, useful assurance claim.

Keep three claims separate:

| Claim | Evidence proposed here |
| --- | --- |
| The recorded decisions constitute a conforming semantic search and, when terminally exhausted, a finite refutation of the declared point problem | Independent reconstruction from the complete universe and complete event stream |
| The serialized entry, successful/failure final, and restored endpoints agree with that reconstruction | Existing endpoint snapshots and exact canonical hashes; restored entry equality |
| Every actual intermediate producer table, edge, dependency bucket, and physical trail operation was correct | **Not checked** by this certificate; needs producer observations or a separately designed faithful mutation journal |

Do not adapt the old checker by calling `event(event, self.snapshot())`. Its
`graph_check` would then compare a verifier-generated graph with itself and
fabricate an observation. The new path must have an explicit semantic-event
method with no producer-snapshot argument. Use `decision_events_checked`,
`semantic_states_reconstructed`, and `endpoint_snapshots_checked`; never report
those counts as `graphs_checked` or full observed intermediate conformance.

## Exact Source reviewed

All paths below were read directly, and their bytes were hashed without
importing them. The complete engine and complete checker bodies were read.

| Source | Bytes | SHA-256 |
| --- | ---: | --- |
| `/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md` | 21657 | `c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9` |
| `/Users/liuyao/.codex/visualizations/2026/10/09/01a11e8d-0cf0-7ed2-8930-2aa7f4aab37b/gcts-proof-dag-search-20261103-v1/reference/upstream/growing_point_search_v2.py` | 39556 | `6e9687145ec2c86719266e07f7ddee4077d88a386c67152dec368657eae43cbb` |
| `/Users/liuyao/.codex/visualizations/2026/10/09/01a11e8d-0cf0-7ed2-8930-2aa7f4aab37b/gcts-proof-dag-search-20261103-v1/reference/upstream/frontier_trace_checker_v1.py` | 27040 | `01f46bdf34b414c7470f75f1507f3e76bfefa739533fcc4b2fd121900378343f` |

The engine version is `IP-GROWING-POINT-SEARCH-v2`. Its existing `_Events.emit`
retains small events and a whole-stream digest independently of the optional
`audit` callback. The callback always builds and serializes a full snapshot;
there is currently no cheap event-only audit callback. Therefore use complete
`result.events` with `audit=None` for the first gate. An optional later event
sink is a transport improvement, not a mathematical prerequisite.

## Supported semantics and independent state

The first API accepts the unchanged engine model/result JSON, requiring
`inventory.kind == 'EXPLICIT'`. The model is the entire immutable universe;
there is no producer shortlist, classifier, geometric predicate, or presumed
proof structure. An externally supplied universe, if supported at all, must
equal the explicit inventory after exact canonical normalization. The native
logical validity of a decoded proof remains a separate gate.

With integer capacity \(C\), independently derive

\[
T(p)=T_0(p)+\sum_{c\in S}t_c(p),\qquad
F=\{p\in Q:T(p)<C\}.
\]

A candidate is legal exactly when it is neither selected nor parent-locally
excluded, all its positive contributions keep totals at most \(C\), and every
assigned marking agrees with the current assignment. Test **all** positive and
marking support, including marking-only points outside \(Q\). Assigned zero is
a value; absent marking is unconstrained. A candidate contributes its actual
integer edge units and need not fill a residual deficit in one move.

The verifier owns totals, marking values/reference counts, active point
generations, selected tile generations, exclusions, full domains, and forward
and reverse weighted incidence. Positive seed support and explicit roots have
generation zero. Newly selected tile generation is one plus the minimum
existing generation on its positive support. Every point generation is the
minimum of its explicit root/positive-seed generation and currently incident
selected tile generations. Existing generations can decrease. Selected tile
generations are assigned at selection, not recomputed retrospectively.

All newly contributed positive support becomes active, even outside the
initial roots. Completed active points remain in \(Q\), but leave the frontier.
No placement may be added disconnected from the current active point set.
This certifies the engine's finite growing-active-obligation semantics; it
does not impose an impermeable geometric boundary or infinite-plane coverage.
Geometric nonoverlap follows only when a separately qualified point carrier
establishes that equivalence.

## Minimal existing transcript and replay automaton

Require exact event fields `seq,kind,point,candidate,data`, consecutive native
integer sequence numbers starting at zero, and the existing canonical JSON
plus line-feed stream digest. Native booleans/floats cannot impersonate integer
capacity, generation, count, or sequence fields.

At every decision, independently compute the complete frontier domains. The
engine's exact tie order is:

1. Any empty domain: choose the minimum `(generation,point)` among dead points.
2. Otherwise any singleton: choose the minimum `(generation,point)` among
   forced points, and its unique candidate.
3. Otherwise, if no frontier remains, accept a solution decision.
4. Otherwise branch at minimum `(generation,domain_size,point)`.

Neither the producer label nor its supplied degree is evidence for this test.
The event automaton is:

| Event | Independent obligation and transition |
| --- | --- |
| `READY` | Exactly first; initialized semantic state and entry endpoint agree |
| `FORCED` | Derived scheduler is forced at the same point and same unique CID; create a pending primitive placement |
| `BRANCH` | Derived scheduler chooses this point; `legal` is the entire independently derived sorted domain; `order` is a unique permutation of it; save the full semantic parent context and `order[0]` in a new frame; create pending placement |
| `PLACED` | Must fulfill the pending forced/branch move with matching point/CID/kind; independently apply its complete support and verify the reported tile generation |
| `DEAD` | Derived scheduler is dead at the same point; record failure of the current residual problem, bound to the latest open branch frame or the root |
| `EXCLUDE` | Must immediately resolve that failed child, with its saved frame CID; restore the verifier's saved parent, discard all child-local state/exclusions, then exclude that CID only in that parent; resume global scheduling |
| `EXHAUSTED` | Must follow independently established root failure with no open branch frame |
| `SOLUTION` | No active frontier remains and no pending move/failure; independently check the exact selected point certificate |

Other events, duplicate terminals, gaps, phantom exclusions, or an exclusion
after an unresolved/resource-limited child cannot pass. Forced moves do not
create branch frames; all forced descendants are undone with their enclosing
failed branch. Previously justified exclusions in the restored parent remain;
descendant exclusions do not leak upward. There is no need to assume a fixed
policy order: the recorded `order` must retain full fallback, and each actual
branch uses its first member.

The pinned Source emits no `UNKNOWN` event. An interrupted result is identified
by `result.status == 'UNKNOWN'`; it may end between a decision and `PLACED`, or
after an emitted event whose full-snapshot audit callback did not complete.
Such a prefix is not a refutation. A `SOLUTION` event followed by a resource
stop before the engine's final certificate/result is committed does not turn
the recorded process into a clean successful run.

### Why the complete event stream is sufficient

Induct on the event sequence. Initialization fixes the point state. Each
`PLACED` fixes the next state using immutable supports. A `BRANCH` fixes a
parent context and chosen child. `DEAD` is justified independently from complete
domains. `EXCLUDE` has a unique meaning in the pinned Source grammar: undo the
latest chosen branch and exclude its CID in the saved parent. Thus every
semantic state and exclusion context is reconstructible without an intermediate
producer snapshot or a physical trail-operation transcript.

At a frontier point with positive deficit, any exact extension must include at
least one currently legal incident candidate. An empty domain proves failure;
a singleton is necessary; a full branch domain exhausts the alternatives.
Excluding a candidate only after its entire child residual problem has failed
preserves that disjunction. Induction over failed frames proves root failure
when `EXHAUSTED` is reached. Finiteness follows from a finite universe with each
CID selectable at most once. This is a finite point-problem refutation, not
unrestricted first-order nonprovability, a plane-tiling theorem, or preservation
of an unmarked solution set after learned restrictive markings.

## Rollback and endpoint coverage

For the semantic claim, the event grammar already cross-orders failure and
restoration: `DEAD` then its `EXCLUDE` identifies the frame. A new unified
rollback journal is not required. The verifier restores its own exact state,
including parent exclusions and generations, at that transition.

Also check the existing retained `rollback_records` and their declared extent.
The expected full sequence has one `FAILED_CHILD` row per such transition, in
order, followed by the engine's `FINAL_RESTORE` row. Bind retained reasons and
selected-before/after cardinalities to the independent replay. Validate native
integer trail lengths, their subtraction, and final trail target zero whenever
the final row is retained. Recompute the full rollback digest only when its
full sequence is available. These arithmetic checks do **not** reconstruct the
producer's individual physical trail writes. A truncated rollback-record suffix
limits that metadata coverage; it does not invalidate a complete semantic
event refutation, since the latter derives restoration from `EXCLUDE` itself.

Check the serialized entry and final snapshots against independently derived
endpoint graphs, and require restored snapshot equality with entry, including
their canonical hashes. This costs a few full snapshots, not one per event.
It verifies observed serialized endpoints under the pinned execution/source
association, not the actual tables between them. Endpoint restoration after a
resource stop remains useful evidence but cannot complete a missing child
refutation. Partial initialization with no complete entry checkpoint remains
`UNKNOWN`.

For exclusions, record compact provenance such as branch-event sequence,
dead-event sequence, and exclude-event sequence. There is no need to serialize
a complete graph and hash it again for every parent/dead context. If a context
fingerprint is later used, name its exact semantic preimage and charge its
serialization; do not mislabel it an observed producer graph hash.

## Independent incremental reconstruction and bounded cost

Read and validate the complete universe once. Build immutable independent
positive-support and marking-support reverse indexes. On a placement, changed
totals can affect only candidates in the relevant positive-support buckets;
new marking assignments can affect only their marking-support buckets. Add
selected/excluded CIDs to this affected set. Recompute each affected legality
predicate from its **whole** support; update all of its frontier incidences.
Create complete domains for newly active points from the immutable incidence
index, remove completed point domains, and update priority metadata when point
generation changes. Mark reference counts and zero-versus-absence are trailed
even when equal-valued refcount changes do not alter legality.

This local update is sound because a candidate outside those dependency
buckets has unchanged membership filters, totals, and marking values at every
support point. Its legality predicate is therefore unchanged. Newly activated
and completed frontier membership is a separate required update. The argument
depends on frozen supports/marking rules; a runtime rule change invalidates it.

Use an independent reversible state, not the producer's trail. Frames need
only independent checkpoints plus branch provenance; a separate verifier trail
can restore exact state without copying a whole graph at every branch. A first
implementation may choose simpler bounded parent copies, but must charge their
actual work/memory and make no claimed efficiency gain until measured. Tiny
exhaustive re-enumeration must qualify the incremental implementation against
every replayed state before relying on this optimization.

Suggested public API, **not yet implemented**:

```python
verify_explicit_events(model, result, *, max_items, max_work, wall_seconds)
```

Require a complete event extent for a terminal semantic receipt. Report
rollback-record coverage separately as full or retained prefix; never call its
unavailable suffix verified. Verify all retained bytes and exact normalized
model identity. Check semantic event counters separately from nonsemantic
producer timing/work metadata.
`audit_calls` can correctly be zero; do not require one callback per event.
`ordering_calls` is coverage metadata only, since raw ordering callback
requests/responses are not retained. The actual event permutation is checked.

The receipt should distinguish:

- `VERIFIED`, `run_status: SAT|UNSAT`, semantic decisions checked, endpoint
  snapshot count, full event coverage, exclusions justified, separate
  rollback-record coverage, and bounded absence only for terminal `UNSAT`.
- `UNKNOWN`, with an exact reason and verified-prefix counts, for truncated
  event evidence, incomplete initialization, interrupted run, or any
  verifier resource limit. A claimed complete `UNSAT` with missing evidence
  remains unsupported; it is never accepted from a stream digest alone.
- `REJECTED` for an actual contradiction, malformed literal type, wrong
  generation/domain/permutation, illegal move, phantom exclusion, bad binding,
  or terminal mismatch in retained evidence.

Always report `producer_intermediate_bookkeeping: NOT_CHECKED`. Native proof
truth and the carrier's reduction validity are explicit external gates.

Budget whole literal strings and dictionary keys, nesting, universe supports,
event parsing, independent graph edits, frame copies/trail writes, endpoint
serialization, and stream hashing. Check wall time inside long scans. Owned
memory/depth/item/work stops are `UNKNOWN`; a resource stop must not create an
exclusion or negative result. Input stream hashes attest omitted suffix bytes
only as custody claims; they do not supply the omitted semantics.

## Indexed/eager providers and stronger bookkeeping: later gates

Do not silently generalize the explicit gate to an unqualified provider.
Supporting indexed inventories additionally requires a complete independently
qualified universe/descriptor and chronological load reconstruction. Validate
every pure total/mark-compatible incident packet in its actual initialization
or placement context, **before** selected/excluded filtering. Its selected CID
may still be pure-compatible with fractional units. Parent-local exclusions
must not remove contacts from this packet. Check all supports and exact counts,
not only emitted rows. Loaded-point and registered-row state must roll back
with the parent; immutable caches are not logical registration.

The old checker reconstructs this distinction, but it also compares real full
observations. A future semantic-only provider path must retain the distinction
without claiming unobserved maps. Eager callbacks do not retain their raw wire
packets in the pinned engine; an independently known universe can reconstruct
expected registration semantics, not prove raw callback-wire equality.

A later **actual bookkeeping** gate could observe every canonical commit or
retain a versioned complete mutation journal covering registrations,
dependencies, legality, weighted domains/reverse edges, loaded points,
generations, totals/marks/refcounts, exclusions, and undo. It must be tied to
actual store writes, not a second intended-state model. No fallible callback
may interrupt physical undo: buffer or mark assurance incomplete, finish undo,
then report `UNKNOWN`. Digest-only commitments prove nothing about semantic
correctness unless their preimages are actual stores and the verifier can
independently derive the expected commitments. This stronger instrumentation
has its own resource cost and Source review; it is not demanded merely to
certify finite semantic exhaustion.

## Qualification and prospective comparison

Before executing a checker, freeze its Source/API and use fresh tiny explicit
fixtures with independent exhaustive point solutions. Cover remote dead over
forced, forced over branch, earlier generation over smaller later degree,
generation lowering, shared fractional candidates, zero residuals, explicit
zero roots, extended mark-only conflicts, assigned zero, repeated same-value
mark refcounts, disconnected placements, nested failed-child exclusions and
restoration. Include a stop inside a child and a missing-event prefix.

Mutants must include deleted compatible candidate with adjusted branch counts,
wrong generation, shortened `order`, `EXCLUDE` after a prefix/unknown child,
wrong restored parent exclusion, omitted/reordered event, altered endpoint
edge/dependency, false `EXHAUSTED`, and bool/float integer forgeries. Keep
separate expected outcomes for semantic corruption and endpoint corruption.

For a prospective cost study, compare identical frozen point inputs, ordering,
engine semantics, and resource scopes; record search, event retention, observer
serialization, verifier preparation, verification, and process overhead. Old
equal numeric `max_work` settings do not establish equal logical search budgets
because the current engine charges audit snapshots to that meter. A no-callback
run with complete events can receive the new semantic absence certificate only
after this new checker is reviewed, qualified, and actually passes. Historical
archived `UNKNOWN` labels stay unchanged; a later saved-data check is a new,
separately admitted result and needs no engine rerun.

The immediate next implementable gate is this explicit semantic verifier plus
fresh tiny qualification. Defer mutation journaling and new performance claims
until that smaller gate establishes what assurance is needed and what it costs.
