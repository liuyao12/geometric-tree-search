# Final custody/exit delta and tiny helpers: Source review addendum

Status: **PASS_SOURCE_REVIEW_PENDING_PROSPECTIVE_FREEZE_AND_EXECUTION**.
This extends, and does not overwrite, `review/driver-peer-source-v1.md`
(4858 bytes, SHA-256
`2351ec7bee360ec25670d536e8d61ebb269228a553467fe9373c64e616418ea9`).
No scientific module was imported or executed. No existing raw trace, selected
proof, engine result, or target-proof payload was replayed or evaluated.

## Final Source pins

| File | Bytes | SHA-256 |
| --- | ---: | --- |
| `source/run_semantic_assurance_v1.py` | 30531 | `710cd6ba92cd55df24b5f62e593284dd7c97351833f7d72e28c4bc8a11a042c4` |
| `plan/driver-API-v1.md` | 10405 | `75450941b5af67e55614f3cd6623989eb76c676b42140d7912f26958941c0397` |
| `review/driver-original-run-byte-joins-v1.patch` | 6447 | `e277774d492948bcc5bba2c46ee80c8c871d2066e7e22c25d816c5922a995ead` |
| `source/tiny_assignment_oracle_v1.py` | 9152 | `2822c946e3ec74753f16df1f96289f15db00edaebb7139f8e50f69c98352633a` |
| `source/semantic_mutations_v1.py` | 10097 | `a8f2e52de558e6781678614b0299dff6598e0b5253b82ded1be186edb62d5086` |

The exact final driver/API diff was read in full against the previously
reviewed bodies. Both tiny helper bodies were read in full. No blocking defect
or further requested Source change was found.

## Driver closure

The added original-run joins correctly bind its own raw-result byte/hash ref
and complete-capture flag to the actual copied raw input. The original
declaration, prepared model, and model-gate refs bind to the corresponding
copies. Declared source-case ID and literal statement are joined to the
prepared statement. The observer log ref binds copied log bytes, whose physical
input pin is already checked by the freeze/unchanged closure. The first failed
process's exact tuple-index postcheck error remains joined between original
invocation and observer rather than relabeled a clean native process.

The outer `run` command now prints the retained observer answer, then exits
nonzero for an unadmitted owned child exit, guard, observer/reap error, or
Source postcheck. This corrects automation signaling without changing a
scientific call, replaying an attempt, hiding the failed process, or weakening
the separately recorded actual native exit. Prior driver/API drafts are
preserved. The API accurately describes these narrow changes.

## Tiny exhaustive oracle

The oracle uses no engine, scheduler, semantic-checker, or model-helper import.
It enumerates every subset of the distinct declared CIDs within its explicit
tiny bounds, computes exact total units and whole marking agreement, and
requires exact coverage of roots, positive seed support, and selected positive
support. Nonroot seed zeros do not become obligations. A candidate identity
is selectable once, including duplicate-support distinct identities.

Its additional positive-support reachability test is necessary for the engine's
growing attachment semantics and sufficient for existence of some legal
attachment order: take reachable candidates successively, and final capacity
legality and marking agreement imply legality of every subset prefix. If a
remaining candidate touches an already full point, final legality would be
contradicted. This is an existence quotient, not a reproduction of the engine's
generation/scheduler. Empty initial activation and disconnected extra selected
components are handled by the reachability requirement.

Resource refusal leaves `exists` unknown, with any partial witness count
separately labeled. The method is deliberately limited to at most sixteen
candidates and bounded exhaustive assignments; its counters are not engine
work units or an OS-memory claim. Fixture execution and actual agreement are
still prospective, not established by this Source review.

## Mutation helper

The helper has no scientific imports. It deep-copies bounded actual fresh
models/results, requires complete actual terminal traces and specific event
anchors, and labels every packet as a mutation rather than an executed run.
Missing anchors refuse as `NOT_EXERCISED`. Full forged transcripts are
rehashable negative controls; retained-prefix controls retain their missing
suffix distinction. The rollback-prefix control also sets the native retention
cap to zero, so its weaker metadata scope is honest. The raw-unknown pending
prefix clears committed solution/final claims and cannot become absence.
Targets and resource overrides are explicit; packets are saved by the reviewed
driver before checking.

Nothing here admits an empirical outcome, intermediate producer-map conformance
on historical cases, unrestricted mathematical completeness, or a speed gain.
Root's prospective freeze and fresh qualification remain the next gate.
