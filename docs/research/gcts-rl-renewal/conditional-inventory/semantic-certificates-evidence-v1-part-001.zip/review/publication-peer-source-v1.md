# Semantic certificate publication: independent Source review

Status: **PASS_SOURCE_REVIEW_PENDING_ROOT_PUBLICATION_ADMISSION_AND_EXECUTION**.
All five current publication Source bodies, the complete baseline adaptation
diff, and the API were read. No blocking defect or further Source change is
requested. No publication tool was imported or executed; no package, Git,
network, live verification, mirror copy, build, or scientific replay occurred
in this review. Frozen scientific directories and prior archives are untouched.

## Reviewed pins

| File | Bytes | SHA-256 |
| --- | ---: | --- |
| `publication/evidence_common_v1.py` | 18200 | `d87fc5c22b5f8411f10d1cc10b6477533775e21fdab9690b882dfa83f340c736` |
| `publication/package_publish_v1.py` | 15282 | `4c26df7beba5785817b50ab397e573b9984ade6ae31f71c0730963015c746e68` |
| `publication/observe_github_v1.py` | 4736 | `b775a24f6d3cd93726d8786042b3b3fd4b63c531321b487b3334029733bcf5cf` |
| `publication/verify_live_v1.py` | 5085 | `fea78427e2929e93df1ddd05154f7806a5e763ca829e12757bf8502b0ee6e84e` |
| `publication/complete_publication_v1.py` | 10723 | `9ddcd191abbf3172fe5fe2e64574ef65e0b89cccf430d4bd3f1b1bc103211bff` |
| `review/publication-adaptation-diff-v1.patch` | 44393 | `83662d6f720315c3860a2608546ff403c194d0c87db51ada981289c9441c8d47` |
| `review/publication-API-v1.md` | 8725 | `af1bb6ecdfe1908fda4e4aca46142da84a2e1d0455738de152de727eb9fa0151` |

The live verifier is byte-identical to the preserved hardened CALv2 baseline.
The other differences are the current schema/pins/custody gates, file names,
scope text, predecessor backlink, and mirror destination. The full diff was
read in separate bounded sections rather than relying on a truncated display.

## Evidence admission and preservation

The common gate requires the exact prospective protocol and complete frozen
101-file set, the reviewed driver and peer files, Root's historical Source
admission, pinned executable bytes/recorded isolation flags, and current master.
Both actual current phases require matching phase/PID/protocol, actual native
integer exit zero, clean observer/guard/reap/postcheck, and byte-bound complete
results/logs. Their scientific results remain distinct from process admission.

The history gate physically verifies every one of the 80 unique current copied
input paths and the exact current input-file set. Original raw/input/log refs
and process associations are retained. The first process remains native exit
one, failed postcheck and execution unadmitted, with its literal tuple-index
error. The seven clean historical continuations keep their own classifications.
The new archive does not pretend to contain the predecessor's 293 originals;
that prior archive is separately linked. No old search or kernel is rerun.

Summary admission binds the exact saved audit, phase counts/IDs, statuses,
process classifications and new semantic results. It requires six retrospective
VERIFIED receipts, two UNKNOWN receipts, and two fixed-inventory finite
exhaustions. Refusals cannot claim absence. Root's final publication PASS is
mandatory independently of the historical Source-review PASS. Local UI must
identify the final main-page bytes with zero math/overflow/console errors.

## Physical archive and isolated Git

All original files present at the cut are physically included, including
scientific Sources, raw/actual observations, refusals, controls, logs,
review/API/baseline/publication tools, planning receipts and report assets.
Only generated `package/` outputs are excluded; later deployment receipts are
explicitly outside that earlier cut. Original paths are not replaced by aliases.

Volume estimates reserve manifest/header space, then actual compressed bytes
must satisfy the 44 MiB cap. Each volume contains the same full internal
inventory. Verification requires exact member sets, no duplicate members, all
original uncompressed sizes/SHA-256 values, every CRC, all volume pins, and all
80 preserved copied-path memberships. Original cut bytes are rechecked before
the tree preparation and again during completion.

Link planning is separate from packaging; changed final page bytes or volume
count require planning/UI again. A fresh official read-only GET binds the
reviewed remote base immediately before the isolated tree. The existing bare
repository and task-owned index are used, hooks/lazy fetch are disabled, new
path collisions refuse, and the complete prepared name-status diff must be
task additions plus only the predecessor resource-diagnostic backlink. The
prepared commit has the reviewed base as its sole parent. No script pushes or
stages the primary checkout.

## Remote, live and mirror closure

The observer makes bounded official GETs and requires exact remote
commit/main/tree/sole-parent association. It retains replaced observations and
records Pages success only for the matching repository/main/head commit.
Transport errors remain nonterminal observations rather than deployment proof.

The unchanged live verifier uses normal TLS, HTTPS-only redirects, HTTP/1.1,
and one or two workers. Every prepared body must match exact bytes, then every
downloaded archive member/hash/CRC must pass. Prior receipt history is retained;
same-commit retry reuse still rehashes local bodies. Failure prevents completion.

Completion joins remote commit and Pages success, complete asset membership,
live body bytes, local/live UI, archive receipts, original cut files, readiness,
summary/audit and frozen protocol. It preflights primary-mirror collisions,
accepts existing files only if byte-identical, copies missing files exclusively,
and verifies each copy. It never stages or pushes primary Git. Completion
receipts preserve the research program's ACTIVE status.

The scopes stay honest: this is finite explicit semantic event assurance, with
actual intermediate-map observations only on tiny qualification. No historical
internal-table equality, standalone learned marking, new theorem, RL/search
superiority, unrestricted nonprovability, full arithmetic/geometry completeness,
universal Wang search, or whole-plane result follows. These are Source-review
conclusions; actual packaging, publication, live/UI and mirror results remain
Root's next execution/admission gates.
