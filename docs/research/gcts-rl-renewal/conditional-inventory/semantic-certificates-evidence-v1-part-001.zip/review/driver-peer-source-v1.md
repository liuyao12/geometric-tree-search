# Semantic-assurance driver: independent Source review

Status: **PASS_SOURCE_REVIEW_PENDING_PROSPECTIVE_FREEZE_AND_EXECUTION**.
No scientific Source was imported, and no model, engine, checker, oracle,
decoder, proof kernel, or retrospective verifier was executed during review.

Full bodies reviewed:

| File | Bytes | SHA-256 |
| --- | ---: | --- |
| `source/run_semantic_assurance_v1.py` | 28942 | `30076bd61c464ecb7e068cf5043f5d617731fc20ed6c53bc9c7055c8d946a472` |
| `plan/driver-API-v1.md` | 9542 | `0d860c1f86a32266bb964c20f2d7d63ec3fe43f1d0d7ed73d93139e78fb33442` |

The checker ABI used by the driver is the reviewed
`source/semantic_event_checker_v1.py`, 39367 bytes, SHA-256
`6985af4d1f56789c1237522141b1d04815370566dd99cb22da6a048eb6bc0613`.
No Source changes are requested by this review.

## Findings

The driver has no scientific imports at module initialization. Its prospective
freeze is exclusive and precedes dynamic loading. It pins the exact files
beneath Source/reference/input/plan, the input dependency receipt, current
master, executable and isolated/no-site/no-bytecode flags, phase declarations,
and all limits. Both child and supervisor check this closure. Owned child
commands retain `-I -S -B`; phase outputs/logs are exclusive, so an existing
attempt is not silently rerun. Actual child exit, guard reason, source
postcheck, observer errors, and invocation result bytes remain distinct.

Fresh qualification calls the unchanged engine once per declared tiny model.
It saves the raw result and actual callback observations before assurance.
Public semantic verification, actual full-snapshot verification, exhaustive
assignment checking, and required observation assertions are all separate
gates. Returned assurance data is saved before final qualification assertions.
Mutation inputs are saved before their check, limits overrides are explicit,
and nonverified semantic mutations may not claim absence.

The second private `C.Reader` pass is an acceptable qualification-only use of
the current pinned implementation API. It compares independently derived
graphs against the actual engine callback payloads, while the existing full
checker separately re-enumerates those actual payloads. It does not pass a
fabricated snapshot to the full checker. This pass is bounded and timed as its
own call and is not an additional engine execution. The public semantic
certificate remains a prior separate gate; this private method is not silently
used to strengthen retrospective observations.

The retrospective function dynamically loads only the new semantic checker.
It does not load the engine, native kernel, decoder, exhaustive oracle,
full-snapshot checker, or mutation helper. It checks copied input pins and
original complete-model associations, then joins the original phase/PID,
protocol, invocation, observed exit, and postcheck classification. The failed
first process remains native exit one with failed postcheck. Seven original
clean classifications are retained separately. No historical witness is fed
into a fresh search, and no new native logical validity is asserted.

The retrospective phase requires the fresh qualification's exact result byte
ref, successful native exit, phase/PID, scientific status, clean observer, and
source postcheck. Its own new outcomes are recorded rather than predeclared.
Raw `UNKNOWN` is prohibited from becoming `VERIFIED`. The new semantic result
cannot repair a failed historical process or amend an archived report.

## Scope and limitations retained

This is verifier qualification and saved-data certification, not a paired
search-speed benchmark. The different tools have different work accounting;
their prospective generous limits are not claimed to be equivalent units.
The audited tiny engine acquisition includes callback costs. The private
comparison adds another bounded checker pass. All call/write/pipeline times
are recorded separately, and no cost advantage follows from Source inspection.

RSS is polled for the one owned child, not claimed as a strict instantaneous
bound. Streamed artifact capture can refuse and retain an explicitly incomplete
prefix; such a process cannot pass the later qualification/phase admission
gates. A valid semantic certificate, raw scientific status, and successful
native process are independent facts. Actual intermediate-map claims belong
only to the tiny actual-observation comparisons; the historical semantic
method reconstructs graphs and checks serialized endpoints.

The use of prior complete-model/process receipts is an explicit trusted
lineage premise, not a new execution of their producer/native kernels. Any
later saved-data assembler/publication must preserve those input refs and all
actual process/UNKNOWN distinctions. Nothing in this review admits outcomes
before the prospective freeze and actual qualification.
