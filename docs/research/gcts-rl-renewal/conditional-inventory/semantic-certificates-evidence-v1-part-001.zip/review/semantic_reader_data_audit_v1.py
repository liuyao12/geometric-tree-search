"""Independent passive saved-data/download audit; no scientific helper imports.

Does not execute a checker, oracle, solver, model builder, decoder, kernel,
renderer or state transition. Source PAGE is read by Python AST literal lookup.
"""
import ast
from collections import Counter
import gzip
import hashlib
import json
from pathlib import Path
import time

ROOT = Path(__file__).resolve().parents[1]
STARTED = time.perf_counter()
TOTAL = 0
FILES = set()
MAX_FILE = 268435456
MAX_TOTAL = 1073741824
BEGIN = b'<!-- SEMANTIC_CERTIFICATES_ARCHIVE_LINK -->'
END = b'<!-- /SEMANTIC_CERTIFICATES_ARCHIVE_LINK -->'


def need(ok, why):
    if not ok:
        raise ValueError(why)


def wire(x):
    return (json.dumps(x, sort_keys=True, ensure_ascii=True,
                       separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')


def same(a, b, why):
    need(wire(a) == wire(b), why)


def digest(b):
    return hashlib.sha256(b).hexdigest()


def local(name):
    p = Path(name)
    need(type(name) is str and not p.is_absolute() and '..' not in p.parts, 'LOCAL_PATH')
    out = ROOT
    for part in p.parts:
        out = out / part
        need(not out.is_symlink(), 'NO_SYMLINK')
    need(out.resolve().is_relative_to(ROOT), 'ROOT_PATH')
    return out


def raw(name, ref=None):
    global TOTAL
    need(time.perf_counter() - STARTED < 120, 'PASSIVE_WALL_BOUND')
    p = local(name)
    need(p.stat().st_size <= MAX_FILE, 'PASSIVE_FILE_BOUND')
    b = p.read_bytes()
    TOTAL += len(b)
    need(TOTAL <= MAX_TOTAL, 'PASSIVE_TOTAL_READ_BOUND')
    if ref is not None:
        same(dict(path=name, bytes=len(b), sha256=digest(b)),
             {k:ref[k] for k in ('path','bytes','sha256')}, 'EXACT_ARTIFACT_BYTES:' + name)
    FILES.add(name)
    return b


def unpack(b):
    if b[:2] == b'\x1f\x8b':
        # gzip.decompress checks every gzip member's CRC and uncompressed length.
        b = gzip.decompress(b)
    need(len(b) <= MAX_FILE, 'PASSIVE_LOGICAL_FILE_BOUND')
    return b


def read(name, ref=None):
    return json.loads(unpack(raw(name, ref)))


def checked(ref):
    return read(ref['path'], ref)


def without_archive(b):
    need(b.count(BEGIN) == 1, 'SINGLE_ARCHIVE_MARKER')
    if END not in b:
        return b, False
    need(b.count(END) == 1, 'SINGLE_ARCHIVE_END')
    left, tail = b.split(BEGIN, 1)
    middle, right = tail.split(END, 1)
    need(b'Full approved archive:' in middle, 'KNOWN_ARCHIVE_INJECTION')
    return left + BEGIN + right, True


def run():
    summary_bytes = raw('data/report-summary-v1.json')
    s = json.loads(summary_bytes)
    b = read('review/report-build-v1.json')
    need(s['schema'] == 'Semantic-certificates-saved-summary-v1'
         and s['status'] == 'ADMITTED_SEMANTIC_CERTIFICATES_WITH_EXPLICIT_UNKNOWN', 'SUMMARY_ADMISSION')
    need(b['status'] == 'PASS_REPORT_BUILD', 'BUILD_STATUS')
    same(dict(path='data/report-summary-v1.json', bytes=len(summary_bytes), sha256=digest(summary_bytes)),
         b['summary'], 'BUILD_SUMMARY_PIN')
    audit = checked(s['saved_data_audit'])
    need(audit['status'] == 'PASS_SAVED_DATA_AUDIT', 'SAVED_AUDIT_PASS')
    source = raw(b['renderer_source']['path'], b['renderer_source'])
    tree = ast.parse(source)
    page = next(ast.literal_eval(n.value) for n in tree.body if isinstance(n, ast.Assign)
                and any(isinstance(t, ast.Name) and t.id == 'PAGE' for t in n.targets))
    html_bytes, injected_main = without_archive(raw(b['outputs']['main']['path']))
    same(dict(bytes=len(html_bytes), sha256=digest(html_bytes)),
         {k:b['outputs']['main'][k] for k in ('bytes','sha256')}, 'ORIGINAL_MAIN_BYTES')
    need(html_bytes == page.encode('utf-8'), 'HTML_EQUALS_SOURCE_PAGE')
    evidence, injected_evidence = without_archive(raw(b['outputs']['evidence']['path']))
    same(dict(bytes=len(evidence), sha256=digest(evidence)),
         {k:b['outputs']['evidence'][k] for k in ('bytes','sha256')}, 'ORIGINAL_EVIDENCE_BYTES')
    public = checked(b['outputs']['data'])
    same({k:v for k,v in public.items() if k != 'downloads'}, s, 'ALL_READER_CORE_FIELDS')
    need(len(b['downloads']) == 254 == len(public['downloads']), 'ALL_254_DOWNLOADS')
    readbacks = []
    for item in b['downloads']:
        original = raw(item['source']['path'], item['source'])
        published = raw(item['published']['path'], item['published'])
        need(item['href'].encode() in evidence, 'EVIDENCE_DOWNLOAD_LINK')
        if item['encoding'] == 'ORIGINAL_GZIP_BYTES':
            need(published == original, 'ORIGINAL_GZIP_COPY')
            logical = unpack(published)
            need(logical == unpack(original), 'ORIGINAL_GZIP_LOGICAL_READBACK')
        else:
            need(item['encoding'] == 'GZIP_WRAPPED_ORIGINAL_BYTES', 'KNOWN_DOWNLOAD_ENCODING')
            logical = unpack(published)
            need(logical == original, 'WRAPPED_ORIGINAL_BYTE_READBACK')
        same(public['downloads'][item['source']['path']], item, 'READER_DOWNLOAD_MAPPING')
        readbacks.append(dict(source=item['source'], published=item['published'],
                              logical_bytes=len(logical), logical_sha256=digest(logical)))
    decl = read('plan/semantic-qualification-cases-v1.json')
    q = s['qualification']['cases']
    need(len(q) == 13 and [x['id'] for x in q] == [x['id'] for x in decl['cases']], 'THIRTEEN_CASE_IDS')
    paired = 0
    snapshots = 0
    for case in q:
        values = {k:checked(v) for k,v in case['refs'].items()}
        for key, artifact in [('model','model'),('observations','observations'),('semantic','semantic'),
                              ('observed_snapshot_check','full_snapshot'),('oracle','oracle')]:
            same(case[key], values[artifact], 'FULL_QUALIFICATION_PROJECTION:' + key)
        raw_result = values['raw']
        same(case['stats'], raw_result['stats'], 'TINY_STATS')
        same([x['event'] for x in case['observations']], raw_result['events'], 'SAVED_ACTUAL_EVENTS')
        g = values['incremental_graph_comparison']
        same(case['paired_graph_check'], {k:v for k,v in g.items() if k != 'comparisons'}, 'PAIRED_SUMMARY')
        need(g['status'] == 'VERIFIED' and len(g['comparisons']) == len(case['observations']), 'ALL_PAIRED_STATES')
        for i,(row, observation) in enumerate(zip(g['comparisons'], case['observations'])):
            need(row['equal'] is True and row['seq'] == observation['event']['seq']
                 and row['after_derived_sha256'] == row['actual_observation_sha256']
                 == digest(wire(observation['state'])), 'ACTUAL_PAIRED_GRAPH_HASH')
            prior = raw_result['entry_state'] if i == 0 else case['observations'][i-1]['state']
            need(row['before_derived_sha256'] == digest(wire(prior)), 'PAIRED_PRIOR_HASH')
        paired += g['events_checked']
        snapshots += len(case['observations'])
    need(paired == snapshots == 106, '106_ACTUAL_PAIRED_SNAPSHOTS')
    ternary = next(x for x in q if x['id'] == s['ternary']['case_id'])
    solutions = ternary['oracle']['solutions']
    need(len(solutions) == 6 and ternary['oracle']['assignments_checked'] == 512, 'ACTUAL_TERNARY_ORACLE_CENSUS')
    for pair in s['ternary']['pair_completions']:
        same(pair['completions'], [x for x in solutions if set(pair['required']) <= set(x)], 'PAIR_COMPLETIONS_FROM_SAVED_ORACLE')
    same(s['ternary']['triple_completions'], [x for x in solutions if {'00-A','10-B','20-C'} <= set(x)], 'TRIPLE_COMPLETIONS')
    need(s['ternary']['analytic_lemma_premises_observed'] is True, 'SUPPLIED_LEMMA_PREMISES')
    h = read('plan/retrospective-inputs-v1.json')
    rs = s['retrospective']['records']
    need(len(rs) == 8 and [x['id'] for x in rs] == [x['id'] for x in h['cases']], 'EIGHT_OLD_IDS')
    old_refs = 0
    events = 0
    candidates = 0
    formula_rows = 0
    statuses = Counter()
    for declared, row in zip(h['cases'], rs):
        same(row['refs']['inputs'], declared['inputs'], 'EXACT_HISTORICAL_REFERENCE_OBJECTS')
        same(row['original_process'], declared['original_process'], 'FAILED_OR_CLEAN_PROCESS_PRESERVED')
        data = {}
        for key, reference in declared['inputs'].items():
            if key.endswith('_log'):
                raw(reference['path'], reference)
            else:
                data[key] = checked(reference)
            old_refs += 1
        c = checked(row['refs']['semantic'])
        same(row['semantic'], c, 'ENTIRE_NEW_SEMANTIC_RECEIPT')
        statuses[c['status']] += 1
        raw_result = data['raw_result']
        p = data['prepared']
        need(row['raw_status'] == raw_result['status'] and row['reason'] == raw_result['reason'], 'OLD_RAW_OUTCOME')
        same(row['statement'], p['statement'], 'ORIGINAL_STATEMENT_UNCHANGED')
        same(row['formulas'], p['catalogue']['formulas'], 'LITERAL_FORMULA_UNIVERSE')
        same(row['old_native_admission'], data['original_scientific_result'].get('admission'), 'REUSED_NATIVE_ADMISSION')
        same(row['old_proof_lines'], data['original_scientific_result'].get('proof_lines'), 'REUSED_NATIVE_LINE_COUNT')
        projected = []
        wanted = set()
        for original in raw_result['events']:
            event = json.loads(wire(original))
            if original['candidate'] is not None:
                wanted.add(original['candidate'])
            if original['kind'] == 'BRANCH':
                d = original['data']
                wanted.add(d['order'][0])
                event['data'] = dict(generation=d['generation'],legal_count=len(d['legal']),
                    order_count=len(d['order']),first_candidate=d['order'][0])
            projected.append(event)
        same(row['events'], projected, 'EXACT_EVENT_PROJECTION')
        events += len(projected)
        for witness in c.get('dead_context_witnesses', []):
            wanted.update(x for x,g in witness['context_preimage']['selected'])
            wanted.update(witness['context_preimage']['excluded'])
        need(set(row['candidate_display']) == wanted, 'COMPLETE_EVENT_LITERAL_DISPLAY_KEYS')
        universe = {x['id']:x for x in p['universe']}
        for cid, display in row['candidate_display'].items():
            item = universe[cid]
            token = json.loads(cid)
            own = [value for point,value in item['m']
                   if json.loads(point) == ['DAG-slot-formula-v1',p['binding']['scope'],token[2]]]
            need(len(own) == 1, 'LITERAL_OWN_FORMULA_PORT')
            fid = int(own[0])
            same(display, dict(token=token,formula_id=fid,
                 formula=p['catalogue']['formulas'][fid-1] if fid else None), 'CID_PORT_TO_FORMULA_LOOKUP')
            candidates += 1
            formula_rows += bool(fid)
        if c['status'] == 'UNKNOWN':
            need(c['bounded_absence'] is False and not c.get('dead_context_witnesses'), 'UNKNOWN_HAS_NO_CERTIFIED_FAILURE')
    need(old_refs == 80, 'ALL_80_PHYSICAL_OLD_INPUT_REFS')
    same(dict(statuses), {'VERIFIED':6,'UNKNOWN':2}, 'ACTUAL_RETROSPECTIVE_STATUSES')
    failed = [x for x in rs if x['original_process']['execution_admitted'] is False]
    need(len(failed) == 1 and failed[0]['original_process']['native_exit_code'] == 1, 'ORIGINAL_FAILED_NATIVE_ONE')
    finite = [x['id'] for x in rs if x['semantic']['status'] == 'VERIFIED' and x['semantic']['bounded_absence'] is True]
    need(len(finite) == 2, 'ACTUAL_TWO_BOUNDED_REFUTATIONS')
    result = dict(schema='Semantic-reader-independent-passive-audit-v1',status='PASS',
        scope='Saved-data literal joins, byte/hash/gzip-CRC readbacks and Source-PAGE equality only. No scientific helper import, state transition, solver/oracle/checker/kernel or report rerun.',
        summary=dict(bytes=len(summary_bytes),sha256=digest(summary_bytes)),
        renderer_source=b['renderer_source'],downloads_checked=len(readbacks),
        download_readback_commitment_sha256=digest(wire(readbacks)),
        qualification=dict(cases=13,actual_snapshots=snapshots,paired_state_hash_joins=paired,
            ternary_subsets=512,ternary_saved_solutions=6),
        retrospective=dict(records=8,physical_input_refs=old_refs,event_rows=events,
            literal_candidate_display_rows=candidates,nonpadding_formula_lookup_rows=formula_rows,
            semantic_statuses=dict(statuses),bounded_refutation_ids=finite,original_failed_native_one=failed[0]['id']),
        html_source_equality=True,archive_injection_normalized=dict(main=injected_main,evidence=injected_evidence),
        unique_physical_files_read=len(FILES),cumulative_physical_bytes_read=TOTAL,
        utility_sha256=digest(Path(__file__).read_bytes()),seconds=time.perf_counter()-STARTED)
    out = ROOT / 'review/semantic-reader-independent-data-audit-v1.json'
    with out.open('xb') as f:
        f.write(wire(result))
    print(json.dumps(result,sort_keys=True))


if __name__ == '__main__':
    run()
