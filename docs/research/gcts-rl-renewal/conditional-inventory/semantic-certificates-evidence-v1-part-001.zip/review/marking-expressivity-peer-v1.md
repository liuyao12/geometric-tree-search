# Fixed marking expressivity: independent analytic Source review

Status: **PASS_SOURCE_ARGUMENT_ONLY**. No engine, checker, model generator,
native kernel, or scientific Source was imported or executed. This review does
not establish that the proposed executable fixture has passed.

Reviewed `plan/fixed-marking-expressivity-v1.md` in full: 5,254 bytes, SHA-256
`f86f90754dea72b9cf849e1f6da0d26a39ffab89decde2468f058f3ebbe25980`.
The elementary lemma
and concrete nine-candidate model are correct as written. This is a supplied
analytic argument, not a general theorem discovered by search.

For fixed per-placement partial functions and a consistent fixed seed, a
marking conflict necessarily consists of two different assigned values at one
point/channel. Their sources are two placements or a placement and the seed.
Hence a union whose every placement is seed-compatible and whose every pair is
compatible is compatible. Arbitrarily distant support and extra equality
channels do not change this property. The preservation hypothesis matters:
each distinguished pair must occur in a complete tiling that the added layer
is required to preserve. The claim does not apply to context-dependent
assignments, new auxiliary placements/states, or a learned restriction allowed
to remove those tilings.

In the supplied capacity-two model, the three pair completions have totals
equal to capacity at every activated point:

\[
\{A,B,X_{c,i}\},\qquad \{A,C,X_{b,i}\},\qquad
\{B,C,X_{a,i}\}.
\]

The simultaneous distinguished triple is capacity-legal but leaves
\(T(p)=1\). Each filler would exceed capacity at its corresponding already
completed root. With the declared finite inventory, there is no remaining
extension. Distinct duplicate-support filler identities are legitimate and do
not allow selecting both at the same completed root.

The predicted initial lexical path is also correct by hand. All initial roots
have generation zero and three candidates, so the literal root order selects
\(A\), then \(B\). Afterwards the active point \(p\) has generation one and
two candidates, while root \(c\) has generation zero and three candidates.
Generation priority therefore selects \(C\), and \(p\) becomes dead. Only the
selected child containing \(C\) is thereby refuted; rollback justifies its
parent-local exclusion. A later filler can complete the parent. This is a
prediction pending actual qualification, not an observed run result.

The proposed conclusion is appropriately scoped: fixed markings on the same
placements cannot encode every higher-order forbidden conjunction while
preserving all original complete tilings. Auxiliary-state encodings need their
own projection/preservation proof and empirical cost comparison. The citations
are identified in the reviewed note as prior encoding precedents; this review
did not independently browse or admit those external articles.
