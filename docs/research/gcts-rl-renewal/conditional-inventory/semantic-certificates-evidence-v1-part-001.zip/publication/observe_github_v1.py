"""Read-only official GitHub commit/main/Pages observations. Never push or POST.

One invocation makes bounded observations, not an unbounded deployment wait.
Different prior latest receipts are preserved under observation-history-v1/.
"""
import argparse
import json
from pathlib import Path
import subprocess
import sys
import time
sys.path.insert(0,str(Path(__file__).resolve().parent))
from evidence_common_v1 import ROOT,PREFIX,wire,digest

P=ROOT/'publication'
GH='/Users/liuyao/bin/gh'
REPO='liuyao12/geometric-tree-search'
def read(name):return json.loads((P/name).read_text())
def save(name,value):
    path=P/name;raw=wire(value)
    if path.exists() and path.read_bytes()!=raw:
        old=path.read_bytes();history=P/'observation-history-v1';history.mkdir(exist_ok=True)
        archived=history/(path.stem+'-'+digest(old)+path.suffix)
        if archived.exists():assert archived.read_bytes()==old
        else:archived.write_bytes(old)
    path.write_bytes(raw)
def api(path):
    r=subprocess.run([GH,'api','--hostname','github.com','--method','GET','repos/'+REPO+'/'+path],capture_output=True,text=True,timeout=50)
    if r.returncode:raise RuntimeError(r.stderr)
    return json.loads(r.stdout)
def base():
    ref=api('git/ref/heads/main')
    assert ref['ref']=='refs/heads/main' and ref['object']['type']=='commit'
    value=dict(status='REMOTE_BASE_OBSERVED',repository=REPO,base=ref['object']['sha'],
        observed_epoch=time.time(),method='Official read-only GitHub GET',response=ref)
    save('remote-base-v1.json',value)
    print(json.dumps(dict(status=value['status'],base=value['base'])),flush=True)
def commit(prepared):
    c=api('git/commits/'+prepared['commit']);ref=api('git/ref/heads/main')
    assert c['sha']==ref['object']['sha']==prepared['commit']
    assert c['tree']['sha']==prepared['tree'] and [x['sha'] for x in c['parents']]==[prepared['base']]
    files=[]
    for line in prepared['diff'].splitlines():
        status,path=line.split('\t');assert status in ('A','M')
        assert status==('M' if path==PREFIX+'resource-diagnostic-v1.html' else 'A')
        files.append(dict(filename=path,status={'A':'added','M':'modified'}[status]))
    assert len(files)==len(prepared['assets']) and {f['filename'] for f in files}=={a['path'] for a in prepared['assets']}
    save('remote-commit-v1.json',c);save('remote-main-v1.json',ref)
    save('remote-compare-v1.json',dict(status='PASS',method='Official remote commit tree and sole parent exactly equal the complete isolated prepared tree/parent; name-status diff enumerates every task path. No truncated compare-file page is used.',commit=prepared['commit'],tree=prepared['tree'],parent=prepared['base'],files=files))
    print(json.dumps(dict(status='REMOTE_COMMIT_MAIN_PASS',commit=prepared['commit'],parent=prepared['base'],tree=prepared['tree'],files=len(files))),flush=True)
def pages(prepared):
    listing=api('actions/runs?head_sha='+prepared['commit']+'&per_page=50');save('pages-listing-v1.json',listing)
    candidates=[r for r in listing['workflow_runs'] if r['name']=='pages build and deployment' and r['head_sha']==prepared['commit']]
    if not candidates:
        print(json.dumps(dict(observation='PAGES_RUN_NOT_LISTED_YET',commit=prepared['commit'])),flush=True);return
    latest=max(candidates,key=lambda r:(r.get('run_number',0),r.get('run_attempt',0),r.get('created_at',''),r['id']))
    d=api('actions/runs/'+str(latest['id']))
    assert d['head_sha']==prepared['commit'] and d['name']=='pages build and deployment'
    assert d.get('head_branch')=='main' and d['repository']['full_name']==REPO
    save('pages-observation-v1.json',d)
    with (P/'pages-observation-history-v1.jsonl').open('ab') as f:f.write(wire(dict(epoch=time.time(),id=d['id'],head_sha=d['head_sha'],status=d['status'],conclusion=d['conclusion'],run_attempt=d.get('run_attempt'),updated_at=d['updated_at'])))
    if d['status']=='completed' and d['conclusion']=='success':save('pages-deployment-v1.json',d)
    print(json.dumps({k:d[k] for k in ('id','head_sha','status','conclusion','updated_at')}),flush=True)
def main():
    p=argparse.ArgumentParser();p.add_argument('mode',choices=('base','commit','pages','all'));args=p.parse_args()
    if args.mode=='base':base();return
    prepared=read('prepared-v1.json')
    assert prepared['status']=='PREPARED_TASK_ASSETS_ONLY' and not prepared['primary_checkout_staged']
    try:
        if args.mode in ('commit','all'):commit(prepared)
        if args.mode in ('pages','all'):pages(prepared)
    except (RuntimeError,subprocess.TimeoutExpired) as error:
        print(json.dumps(dict(observation='TRANSPORT_OR_API_ERROR_NOT_TERMINAL',error=str(error))),flush=True)
if __name__=='__main__':main()
