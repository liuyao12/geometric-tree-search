"""Byte/process/ZIP gates for semantic certificates; no science or Git calls."""
import hashlib
import json
from pathlib import Path,PurePosixPath
import zipfile

ROOT=Path(__file__).resolve().parents[1]
PREFIX='docs/research/gcts-rl-renewal/conditional-inventory/'
BASE_URL='https://liuyao12.github.io/geometric-tree-search/'
MANIFEST='semantic-certificates-evidence-manifest-v1.json'
INTERNAL='ARCHIVE-file-manifest-v1.json'
PART_STEM='semantic-certificates-evidence-v1-part-'
MAX_PART=44*1024*1024
PHASES=('qualify','retrospective')
HISTORY='plan/retrospective-inputs-v1.json'
FIRST_PHASE='seen-off-dsgb-alternate-l10-v1'
SUMMARY_SCHEMA='Semantic-certificates-saved-summary-v1'
SUMMARY_STATUS='ADMITTED_SEMANTIC_CERTIFICATES_WITH_EXPLICIT_UNKNOWN'
AUDIT_SCHEMA='Semantic-certificates-saved-data-audit-v1'
AUDIT_STATUS='PASS_SAVED_DATA_AUDIT'
REPORT_BUILDER='report/build_semantic_report_v1.py'
ROOT_ADMISSION='review/root-publication-admission-v1.json'
SOURCE_ADMISSION='review/root-source-admission-v1.json'
READINESS_STATUSES={'review/saved-data-audit-v1.json':AUDIT_STATUS,
    'review/report-build-v1.json':'PASS_REPORT_BUILD',
    'review/local-ui-qualification-v1.json':'PASS_LOCAL_UI',ROOT_ADMISSION:'PASS',
    SOURCE_ADMISSION:'PASS_SOURCE_REVIEW_BEFORE_FREEZE'}
READINESS=tuple(READINESS_STATUSES)
REVIEWED_DRIVER={'path':'source/run_semantic_assurance_v1.py','bytes':30531,
    'sha256':'710cd6ba92cd55df24b5f62e593284dd7c97351833f7d72e28c4bc8a11a042c4'}
DRIVER_PEERS=[{'path':'review/driver-peer-source-v1.md','bytes':4858,
    'sha256':'2351ec7bee360ec25670d536e8d61ebb269228a553467fe9373c64e616418ea9'},
    {'path':'review/driver-peer-source-addendum-v1.md','bytes':4760,
    'sha256':'bb9634aad47f385de986c957e8a7c79051c831b99167714bfcbe8607b96eed37'}]
FROZEN_PROTOCOL={'path':'data/protocol-frozen-v1.json','bytes':18498,
    'sha256':'17555ad342a7cff214dfa8a3c2c2de281e2b99871ba4a8da8fea2f533d7aec99'}
PREVIOUS_EVIDENCE_URL=BASE_URL+PREFIX+'resource-diagnostic-evidence-v1.html'
PRIMARY_MASTER=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md')

def wire(v):return (json.dumps(v,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')
def digest(raw):return hashlib.sha256(raw).hexdigest()
def stream_pin(stream):
    h=hashlib.sha256();size=0
    for block in iter(lambda:stream.read(1048576),b''):h.update(block);size+=len(block)
    return dict(bytes=size,sha256=h.hexdigest())
def pin(path):
    with path.open('rb') as f:return stream_pin(f)
def relative_name(value):
    assert type(value) is str and value and '\\' not in value and '\x00' not in value
    p=PurePosixPath(value)
    assert not p.is_absolute() and all(v not in ('','.','..') for v in p.parts) and p.as_posix()==value
    return value
def local(root,value):
    p=root/relative_name(value);assert root.resolve() in p.resolve().parents
    return p
def load(name):return json.loads(local(ROOT,name).read_text())
def exact(name,expected):
    assert wire(pin(local(ROOT,name)))==wire({k:expected[k] for k in ('bytes','sha256')}),name
def same_bytes(left,right):return wire({k:left[k] for k in ('bytes','sha256')})==wire({k:right[k] for k in ('bytes','sha256')})

def verify_history():
    """All 80 current input copies, not a claim to archive 293 prior originals."""
    history=load(HISTORY)
    assert history['schema']=='Semantic-assurance-retrospective-inputs-v1'
    assert history['original_records']==len(history['cases'])==8
    assert history['failed_first_processes']==1 and history['clean_continuation_processes']==7
    names=set();files=[];records=[]
    for entry in history['cases']:
        assert entry['classification']=='SEEN_RETROSPECTIVE_CHECKER_INPUT'
        assert entry['no_engine_rerun'] is entry['raw_capture_complete'] is entry['no_expected_semantic_outcome'] is True
        assert len(entry['inputs'])==10
        for role,e in entry['inputs'].items():
            name=relative_name(e['path']);assert name.startswith('input/retrospective/') and name not in names
            names.add(name);exact(name,e);files.append(dict(case_id=entry['id'],role=role,path=name,**{k:e[k] for k in ('bytes','sha256')}))
        ins=entry['inputs'];start=load(ins['original_started']['path']);inv=load(ins['original_invocation']['path']);obs=load(ins['original_observer']['path'])
        protocol=load(ins['original_protocol']['path']);old=load(ins['original_scientific_result']['path']);process=entry['original_process']
        assert start['status']=='STARTED' and obs['status']=='TERMINAL'
        assert start['phase']==inv['phase']==obs['phase']==process['phase']==entry['id']
        assert type(start['pid']) is int and start['pid']>0 and start['pid']==inv['pid']==obs['pid']==process['pid']
        assert start['protocol_sha256']==digest(wire(protocol))
        assert obs['guard_reason'] is obs['observer_error'] is obs['reap_error'] is None
        assert same_bytes(obs['log'],ins['original_log'])
        assert old['id']==entry['id'] and old['source_case_id']==entry['source_case_id']
        assert inv['scientific_status']==process['scientific_status']==old['status']
        assert same_bytes(old['refs']['raw_result'],ins['raw_result']) and old['refs']['raw_result']['complete_json'] is True
        for a,b in [('declaration','declaration'),('prepared','prepared'),('original_gate','basis_model_gate')]:assert same_bytes(old['inputs'][a],ins[b])
        if entry['id']==FIRST_PHASE:
            assert process['status']=='FAILED_POSTCHECK_AFTER_SCIENCE' and process['execution_admitted'] is False
            assert type(obs['native_exit_code']) is int and obs['native_exit_code']==process['native_exit_code']==1
            assert inv['status']=='ERROR' and inv['frozen_postcheck']==obs['frozen_postcheck']=='FAILED'
            assert inv['postcheck_error']==obs['postcheck_error']=='tuple indices must be integers or slices, not str'
        else:
            assert process['status']=='COMPLETE_NATIVE_EXECUTION' and process['execution_admitted'] is True
            assert type(obs['native_exit_code']) is int and obs['native_exit_code']==process['native_exit_code']==0
            assert inv['status']=='COMPLETE' and inv['frozen_postcheck']==obs['frozen_postcheck']==protocol['status']
            assert inv['postcheck_error'] is obs['postcheck_error'] is None
        records.append(dict(id=entry['id'],source_case_id=entry['source_case_id'],original_process=process))
    assert len(names)==len(files)==80 and len({e['id'] for e in records})==8
    assert {p.relative_to(ROOT).as_posix() for p in (ROOT/'input').rglob('*') if p.is_file()}==names
    return dict(status='ALL_80_RETROSPECTIVE_INPUT_COPIES_PHYSICALLY_VERIFIED',
        manifest=dict(path=HISTORY,**pin(local(ROOT,HISTORY))),input_copies=80,records=records,files=sorted(files,key=lambda e:e['path']),
        previous_full_archive_link=PREVIOUS_EVIDENCE_URL,
        scope='Current80 actual copied inputs physically included; predecessor full 293 archive remains separately linked. No prior original-count reclamation or old engine rerun.')

def verify_protocol(relative,context_root=''):
    """Exact 101 frozen files/runtime/master plus two actual clean processes."""
    path=local(ROOT,relative);value=load(relative)
    assert relative==FROZEN_PROTOCOL['path'] and context_root=='';exact(relative,FROZEN_PROTOCOL)
    assert value['schema']=='Semantic-assurance-prospective-protocol-v1' and value['status']=='FROZEN_BEFORE_SCIENTIFIC_IMPORTS'
    assert path.read_bytes()==wire(value)
    paths=[]
    for folder in ('source','reference','input','plan'):
        for p in (ROOT/folder).rglob('*'):
            assert not p.is_symlink()
            if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc':paths.append(p)
    paths.append(local(ROOT,'review/input-dependency-snapshot-v1.json'))
    current=[dict(path=p.relative_to(ROOT).as_posix(),**pin(p)) for p in sorted(paths)]
    assert len(current)==101 and wire(current)==wire(value['files']),'Exact frozen scientific file set changed'
    indexed={e['path']:e for e in current};assert len(indexed)==len(current)
    assert wire(indexed[REVIEWED_DRIVER['path']])==wire(REVIEWED_DRIVER)
    for peer in DRIVER_PEERS:exact(peer['path'],peer)
    source_admission=load(SOURCE_ADMISSION)
    assert source_admission['schema']=='Root-semantic-assurance-source-admission-v1' and source_admission['status']==READINESS_STATUSES[SOURCE_ADMISSION]
    for e in source_admission['sources_and_reviews']:exact(e['path'],e)
    executable=value['runtime']['executable'];assert Path(executable['path']).is_absolute()
    assert wire(pin(Path(executable['path'])))==wire({k:executable[k] for k in ('bytes','sha256')})
    assert type(value['runtime']['isolated']) is int and type(value['runtime']['no_site']) is int
    assert value['runtime']['isolated']==value['runtime']['no_site']==1 and value['runtime']['dont_write_bytecode'] is True
    master=indexed['reference/basic-tiling-algorithm.md']
    assert wire(pin(PRIMARY_MASTER))==wire({k:master[k] for k in ('bytes','sha256')})
    assert same_bytes(master,value['master'])
    assert value['phases']==list(PHASES)
    declarations=load('plan/semantic-qualification-cases-v1.json')
    assert len(declarations['cases'])==len({c['id'] for c in declarations['cases']})==13 and len(declarations['mutation_specs'])==20
    phases=[]
    for phase in PHASES:
        started_name='data/'+phase+'-started.json';started=load(started_name)
        assert started['phase']==phase and started['status']=='STARTED'
        assert type(started['pid']) is int and started['pid']>0 and started['protocol_sha256']==digest(wire(value))
        refs={'started':dict(path=started_name,**pin(local(ROOT,started_name)))}
        for key,suffix in (('observer','-observer.json'),('invocation','-invocation.json')):
            name='review/'+phase+suffix;receipt=load(name)
            assert receipt['phase']==phase and type(receipt['pid']) is int and receipt['pid']==started['pid']
            assert receipt['frozen_postcheck']==value['status'] and receipt['postcheck_error'] is None
            if key=='observer':
                assert receipt['status']=='TERMINAL' and type(receipt['native_exit_code']) is int and receipt['native_exit_code']==0
                assert receipt['guard_reason'] is receipt['observer_error'] is receipt['reap_error'] is None
                assert receipt['log']['path']=='review/'+phase+'-native.log';exact(receipt['log']['path'],receipt['log']);refs['log']=receipt['log']
            else:assert receipt['status']=='COMPLETE' and receipt['error_type'] is None
            refs[key]=dict(path=name,**pin(local(ROOT,name)))
        result_name='data/'+phase+'-result.json';result=load(result_name);inv=load('review/'+phase+'-invocation.json')
        assert inv['scientific_status']==result['status'] and inv['result']['path']==result_name and inv['result']['complete_json'] is True
        exact(result_name,inv['result']);refs['result']=dict(path=result_name,**pin(local(ROOT,result_name)))
        phases.append(dict(phase=phase,execution_admitted=True,native_exit_code=0,receipts=refs))
    q=load('data/qualify-result.json');retro=load('data/retrospective-result.json')
    assert q['status']=='QUALIFIED_FRESH_SEMANTIC_ASSURANCE' and len(q['cases'])==q['counts']['cases']==13
    assert {c['id'] for c in q['cases']}=={c['id'] for c in declarations['cases']}
    for row in q['cases']:
        assert row['status']=='QUALIFIED' and row['engine_calls']==row['semantic_public_calls']==row['private_reader_passes']==1
        assert row['semantic_status']==row['full_snapshot_status']==row['incremental_graph_comparison_status']=='VERIFIED' and row['oracle_status']=='EXHAUSTED'
        for e in row['refs'].values():exact(e['path'],e)
    assert len(q['mutations'])==20 and {c['id'] for c in q['mutations']}=={c['id'] for c in declarations['mutation_specs']}
    for row in q['mutations']:
        assert row['actual']==row['expected']
        for e in (row['input'],row['receipt']):exact(e['path'],e)
    assert retro['status']=='RETROSPECTIVE_CHECKS_RECORDED_WITH_EXPLICIT_SCOPES' and retro['engine_reruns']==0
    history=verify_history();assert len(retro['records'])==retro['counts']['records']==8
    assert [r['id'] for r in retro['records']]==[r['id'] for r in history['records']]
    for row,original in zip(retro['records'],history['records']):
        assert wire(row['original_process'])==wire(original['original_process']);exact(row['receipt']['path'],row['receipt'])
    return dict(path=relative,context_root=context_root,schema=value['schema'],phases=phases,
        source_pin_count=len(current),reviewed_driver=REVIEWED_DRIVER,driver_peers=DRIVER_PEERS,
        retrospective_inputs=history,**pin(path))

def verify_summary(summary):
    assert summary['schema']==SUMMARY_SCHEMA and summary['status']==SUMMARY_STATUS
    audit_ref=summary['saved_data_audit'];assert audit_ref['path']=='review/saved-data-audit-v1.json'
    exact(audit_ref['path'],audit_ref);audit=load(audit_ref['path'])
    assert audit['schema']==AUDIT_SCHEMA and audit['status']==AUDIT_STATUS
    q=summary['qualification'];r=summary['retrospective'];original_q=load('data/qualify-result.json');original_r=load('data/retrospective-result.json')
    assert len(q['cases'])==audit['qualification_cases']==13 and len(q['mutations'])==audit['mutation_packets']==20
    assert len(r['records'])==audit['retrospective_records']==8 and r['engine_reruns']==audit['retrospective_engine_reruns']==0
    assert audit['new_engine_runs_claimed']==13 and audit['original_failed_processes']==1
    assert wire(q['counts'])==wire(original_q['counts']) and wire(r['counts'])==wire(original_r['counts'])
    for group in (q,r):assert group['process']['execution_admitted'] is True and group['process']['native_exit_code']==0
    assert [c['id'] for c in q['cases']]==[c['id'] for c in original_q['cases']]
    for row in q['cases']:
        assert row['semantic']['status']==row['observed_snapshot_check']['status']==row['paired_graph_check']['status']=='VERIFIED'
        assert row['oracle']['status']=='EXHAUSTED'
    assert all(c['actual']==c['expected'] for c in q['mutations'])
    assert [c['id'] for c in r['records']]==[c['id'] for c in original_r['records']]
    for row,original in zip(r['records'],original_r['records']):
        assert row['raw_status']==original['raw_status'] and wire(row['original_process'])==wire(original['original_process'])
        assert row['semantic']['status']==original['new_semantic_status'] and row['semantic']['bounded_absence'] is original['bounded_absence']
        if row['semantic']['status']!='VERIFIED':assert row['semantic']['bounded_absence'] is False
    first=[c for c in r['records'] if c['id']==FIRST_PHASE];assert len(first)==1
    assert first[0]['original_process']['status']=='FAILED_POSTCHECK_AFTER_SCIENCE' and first[0]['original_process']['execution_admitted'] is False
    assert first[0]['original_process']['native_exit_code']==1
    assert sum(c['semantic']['status']=='VERIFIED' for c in r['records'])==6
    assert sum(c['semantic']['status']=='UNKNOWN' for c in r['records'])==2
    assert sum(c['semantic']['status']=='VERIFIED' and c['semantic']['bounded_absence'] for c in r['records'])==2
    return True

def inventory_from_manifest(manifest):
    assert manifest['schema']=='Semantic-certificates-physical-multipart-evidence-v1' and manifest['inventory_file']==INTERNAL
    core={k:v for k,v in manifest.items() if k not in ('inventory_sha256','inventory_schema','inventory_file')}
    core['schema']=manifest['inventory_schema']
    core['parts']=[dict(number=p['number'],name=p['name']) for p in manifest['parts']]
    assert core['schema']=='Semantic-certificates-physical-evidence-inventory-v1' and digest(wire(core))==manifest['inventory_sha256']
    return core
def verify_archive(folder,manifest):
    core=inventory_from_manifest(manifest);entries=manifest['files'];by_path={e['path']:e for e in entries}
    assert len(by_path)==len(entries)==manifest['original_files'] and manifest['all_originals_physically_stored'] is True
    assert sum(e['bytes'] for e in entries)==manifest['original_bytes']
    inputs=manifest['preserved_retrospective_inputs']
    assert inputs['input_copies']==len(inputs['files'])==80 and len(inputs['records'])==8
    assert len({e['path'] for e in inputs['files']})==80
    for e in inputs['files']:
        assert e['path'] in by_path and all(e[k]==by_path[e['path']][k] for k in ('bytes','sha256'))
    failed=[e for e in inputs['records'] if e['id']==FIRST_PHASE]
    assert len(failed)==1 and failed[0]['original_process']['native_exit_code']==1 and failed[0]['original_process']['execution_admitted'] is False
    for e in entries:
        relative_name(e['path']);assert type(e['part']) is int and 1<=e['part']<=len(manifest['parts'])
    parts=[];verified=set()
    for number,part in enumerate(manifest['parts'],1):
        assert part['number']==number and part['name']==PART_STEM+'%03d.zip'%number
        archive=local(folder,part['name']);actual=pin(archive)
        assert wire(actual)==wire({k:part[k] for k in ('bytes','sha256')}) and actual['bytes']<=MAX_PART and actual['bytes']<50*1024*1024
        expected={e['path'] for e in entries if e['part']==number}
        with zipfile.ZipFile(archive) as z:
            assert len(z.namelist())==len(set(z.namelist())) and set(z.namelist())==expected|{INTERNAL}
            assert z.read(INTERNAL)==wire(core) and z.testzip() is None
            for name in sorted(expected):
                e=by_path[name];assert name not in verified and z.getinfo(name).file_size==e['bytes']
                with z.open(name) as stream:p=stream_pin(stream)
                assert wire(p)==wire({k:e[k] for k in ('bytes','sha256')});verified.add(name)
        parts.append(dict(number=number,name=part['name'],**actual,CRC='PASS'))
    assert verified==set(by_path)
    return dict(status='PASS',original_files=len(entries),all_original_files_physically_stored=True,
        all_original_paths_byte_verified=True,all_CRC_verified=True,parts=parts)
