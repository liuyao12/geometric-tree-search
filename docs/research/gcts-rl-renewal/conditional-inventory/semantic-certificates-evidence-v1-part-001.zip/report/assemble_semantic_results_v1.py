"""Passive saved-data joins only; no scientific modules imported or replayed.

Run only after Root Source review and actual phase completion. Unknown semantic
outcomes stay unknown. Original process failure and native admissions are not
rewritten by a new semantic certificate.
"""
from collections import Counter
import gzip
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
LEDGER = {}
MAX_JSON = 134217728
MASTER = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md')


def need(ok, why):
    if not ok:
        raise ValueError(why)


def wire(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')


def sha(value):
    return hashlib.sha256(wire(value)).hexdigest()


def same(actual, expected, why):
    need(wire(actual) == wire(expected), why)


def local(name):
    need(type(name) is str and bool(name), 'LITERAL_RELATIVE_PATH')
    p = Path(name)
    need(not p.is_absolute() and '..' not in p.parts, 'LOCAL_PATH_ONLY')
    out = ROOT
    for part in p.parts:
        out = out / part
        need(not out.is_symlink(), 'NO_ARTIFACT_SYMLINK:' + name)
    need(out.resolve().is_relative_to(ROOT), 'PATH_ESCAPE')
    return out


def bytepin(p):
    h = hashlib.sha256()
    size = 0
    with p.open('rb') as f:
        for block in iter(lambda: f.read(1048576), b''):
            h.update(block)
            size += len(block)
    return dict(bytes=size, sha256=h.hexdigest())


def pin(name):
    item = dict(path=name, **bytepin(local(name)))
    LEDGER[name] = item
    return item


def frozen_environment(protocol):
    paths = []
    for folder in ('source', 'reference', 'input', 'plan'):
        for p in (ROOT / folder).rglob('*'):
            need(not p.is_symlink(), 'NO_FROZEN_SYMLINK')
            if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc':
                paths.append(p)
    paths.append(local('review/input-dependency-snapshot-v1.json'))
    current = [pin(p.relative_to(ROOT).as_posix()) for p in sorted(paths)]
    same(current, protocol['files'], 'EXACT_CURRENT_FROZEN_FILE_SET_AND_BYTES')
    executable = Path(sys.executable).resolve()
    runtime = dict(executable=dict(path=str(executable), **bytepin(executable)),
                   version=sys.version, isolated=sys.flags.isolated,
                   no_site=sys.flags.no_site, dont_write_bytecode=sys.dont_write_bytecode)
    need(sys.flags.isolated == 1 and sys.flags.no_site == 1
         and sys.dont_write_bytecode is True, 'ISOLATED_NO_SITE_NO_BYTECODE')
    same(runtime, protocol['runtime'], 'CURRENT_PINNED_RUNTIME_BYTES_VERSION_FLAGS')
    master = dict(path=str(MASTER), **bytepin(MASTER))
    same(master, protocol['master'], 'CURRENT_MASTER_BYTES')
    # These are separate external custody metadata, never relative download refs.
    return dict(runtime=runtime, master=master, frozen_files=len(current))


def read(name, reference=None):
    actual = pin(name)
    if reference is not None:
        need(all(actual[k] == reference[k] for k in ('path', 'bytes', 'sha256')),
             'ARTIFACT_BYTES:' + name)
        need(reference.get('complete_json', True) is True, 'COMPLETE_JSON:' + name)
    p = local(name)
    with gzip.open(p, 'rb') if p.suffix == '.gz' else p.open('rb') as f:
        raw = f.read(MAX_JSON + 1)
    need(len(raw) <= MAX_JSON, 'PASSIVE_JSON_BOUND:' + name)
    return json.loads(raw)


def checked(reference):
    return read(reference['path'], reference)


def save(name, value):
    p = local(name)
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open('xb') as f:
        f.write(wire(value))
    return pin(name)


def phase(name, protocol):
    result = read('data/' + name + '-result.json')
    started = read('data/' + name + '-started.json')
    invocation = read('review/' + name + '-invocation.json')
    observer = read('review/' + name + '-observer.json')
    need(started['status'] == 'STARTED' and observer['status'] == 'TERMINAL', 'PHASE_TERMINAL')
    need(started['phase'] == invocation['phase'] == observer['phase'] == name, 'PHASE_JOIN')
    need(all(type(v['pid']) is int for v in (started, invocation, observer))
         and started['pid'] == invocation['pid'] == observer['pid'], 'PID_JOIN')
    need(started['protocol_sha256'] == sha(protocol), 'FROZEN_PROTOCOL_JOIN')
    need(invocation['status'] == 'COMPLETE' and invocation['error_type'] is None
         and type(observer['native_exit_code']) is int
         and observer['native_exit_code'] == 0, 'CURRENT_PHASE_NATIVE_ADMISSION')
    for k in ('guard_reason', 'observer_error', 'reap_error', 'postcheck_error'):
        need(observer[k] is None, 'OBSERVER_' + k)
    need(invocation['postcheck_error'] is None
         and invocation['frozen_postcheck'] == observer['frozen_postcheck'] == protocol['status'],
         'SOURCE_POSTCHECK')
    need(invocation['scientific_status'] == result['status'], 'PHASE_SCIENCE_JOIN')
    need(checked(invocation['result']) == result, 'PHASE_RESULT_JOIN')
    need(pin(observer['log']['path']) == {k:observer['log'][k]
         for k in ('path','bytes','sha256')}, 'NATIVE_LOG_BYTES')
    return result, dict(native_exit_code=0, execution_admitted=True,
                        observer_seconds=observer['seconds'], invocation_seconds=invocation['seconds'],
                        peak_observed_rss_bytes=observer['peak_observed_rss_bytes'],
                        refs={k: pin(v) for k,v in dict(
                            result='data/' + name + '-result.json',
                            started='data/' + name + '-started.json',
                            invocation='review/' + name + '-invocation.json',
                            observer='review/' + name + '-observer.json').items()})


def semantic_join(model, raw, certificate, observations=None):
    need(certificate['status'] in ('VERIFIED', 'UNKNOWN', 'REJECTED'), 'CERTIFICATE_STATUS')
    if certificate['status'] != 'VERIFIED':
        need(certificate['bounded_absence'] is False, 'NO_REFUSAL_ABSENCE')
        return
    need(raw['status'] in ('SAT', 'UNSAT') and certificate['run_status'] == raw['status'], 'RAW_CERTIFICATE_STATUS')
    same(certificate['claim'], 'SEMANTIC_COMPLETE_SAT_CERTIFICATE' if raw['status'] == 'SAT'
         else 'SEMANTIC_COMPLETE_FINITE_EXHAUSTION', 'EXACT_SEMANTIC_CLAIM')
    need(certificate['model_sha256'] == raw['model_sha256']
         and certificate['event_sha256'] == raw['event_extent']['sha256'], 'CERTIFICATE_BINDINGS')
    need(certificate['bounded_absence'] is (raw['status'] == 'UNSAT')
         and certificate['event_coverage'] == 'COMPLETE', 'EXACT_ABSENCE_SCOPE')
    need(certificate['producer_intermediate_bookkeeping'] == 'NOT_CHECKED', 'NO_INVENTED_MAP_OBSERVATIONS')
    events = raw['events']
    need(certificate['counts']['decision_events_checked'] == len(events)
         == raw['event_extent']['total'], 'COMPLETE_EVENTS')
    need(hashlib.sha256(b''.join(wire(e) for e in events)).hexdigest()
         == raw['event_extent']['sha256'], 'SAVED_EVENT_BYTES')
    for witness in certificate['dead_context_witnesses']:
        event = events[witness['dead_event']]
        context = witness['context_preimage']
        need(event['kind'] == 'DEAD' and event['point'] == context['dead_point']
             and event['data']['generation'] == context['generation'], 'DEAD_LITERAL_JOIN')
        need(context['model_sha256'] == raw['model_sha256']
             and sha(context) == witness['semantic_context_sha256'], 'DEAD_CONTEXT_BINDING')
        if observations is not None:
            state = observations[witness['dead_event']]['state']
            need(all(wire(context[k]) == wire(state[k]) for k in ('selected', 'excluded', 'Q')),
                 'TINY_WITNESS_ACTUAL_OBSERVATION_JOIN')
    for failure in certificate['failure_provenance']:
        branch, dead, exclude = [events[failure[k]] for k in ('branch_event', 'dead_event', 'exclude_event')]
        need(branch['kind'] == 'BRANCH' and dead['kind'] == 'DEAD' and exclude['kind'] == 'EXCLUDE'
             and branch['data']['order'][0] == exclude['candidate'] == failure['candidate'],
             'FAILURE_EVENT_LITERAL_JOIN')


def candidates_for_events(prepared, raw, certificate):
    """Literal lookup/display metadata, not decoding or proof validity checking."""
    wanted = {e['candidate'] for e in raw['events'] if e['candidate'] is not None}
    wanted.update(e['data']['order'][0] for e in raw['events'] if e['kind'] == 'BRANCH')
    for w in certificate.get('dead_context_witnesses', []):
        wanted.update(c for c,g in w['context_preimage']['selected'])
        wanted.update(w['context_preimage']['excluded'])
    byid = {r['id']: r for r in prepared['universe']}
    need(wanted <= byid.keys(), 'EVENT_CIDS_BELONG_TO_PREPARED_DATA')
    rows = {}
    for cid in sorted(wanted):
        row = byid[cid]
        try:
            token = json.loads(cid)
        except (ValueError, TypeError):
            token = None
        own_formula = None
        if type(token) is list and len(token) == 6 and token[0] == 'DAG-candidate-v1':
            slot = token[2]
            for point, value in row['m']:
                port = json.loads(point)
                if port == ['DAG-slot-formula-v1', prepared['binding']['scope'], slot]:
                    own_formula = int(value)
            rows[cid] = dict(token=token, formula_id=own_formula,
                             formula=prepared['catalogue']['formulas'][own_formula-1]
                             if own_formula else None)
        else:
            rows[cid] = dict(token=token, formula_id=None, formula=None)
    return rows


def event_projection(events):
    projected = []
    for e in events:
        row = json.loads(wire(e))
        if row['kind'] == 'BRANCH':
            data = row['data']
            row['data'] = dict(generation=data['generation'], legal_count=len(data['legal']),
                               order_count=len(data['order']), first_candidate=data['order'][0])
        projected.append(row)
    return projected


def assemble():
    source_admission = read('review/root-source-admission-v1.json')
    need(source_admission['status'] == 'PASS_SOURCE_REVIEW_BEFORE_FREEZE', 'ROOT_SOURCE_ADMISSION')
    protocol = read('data/protocol-frozen-v1.json')
    need(protocol['status'] == 'FROZEN_BEFORE_SCIENTIFIC_IMPORTS', 'PROSPECTIVE_FREEZE')
    environment = frozen_environment(protocol)
    declarations = read('plan/semantic-qualification-cases-v1.json')
    historical = read('plan/retrospective-inputs-v1.json')
    qualification, qprocess = phase('qualify', protocol)
    retrospective, rprocess = phase('retrospective', protocol)
    need(qualification['status'] == 'QUALIFIED_FRESH_SEMANTIC_ASSURANCE', 'QUALIFICATION_ADMITTED')
    need(retrospective['status'] == 'RETROSPECTIVE_CHECKS_RECORDED_WITH_EXPLICIT_SCOPES'
         and retrospective['engine_reruns'] == 0, 'CHECKER_ONLY_RETROSPECTIVE')
    same(retrospective['engine_reruns'], 0, 'NATIVE_ZERO_RETROSPECTIVE_ENGINE_RERUNS')
    need([r['id'] for r in qualification['cases']] == [c['id'] for c in declarations['cases']]
         and len(qualification['cases']) == 13, 'EXACT_FRESH_CASES')
    need([r['id'] for r in retrospective['records']] == [c['id'] for c in historical['cases']]
         and len(retrospective['records']) == 8, 'EXACT_SEEN_RECORDS')
    fresh = []
    for declared, row in zip(declarations['cases'], qualification['cases']):
        values = {k: checked(v) for k,v in row['refs'].items()}
        model, raw, observed = values['model'], values['raw'], values['observations']
        c, t, g, o = [values[k] for k in ('semantic', 'full_snapshot', 'incremental_graph_comparison', 'oracle')]
        need(wire(model) == wire(declared['model']) and row['status'] == 'QUALIFIED', 'DECLARED_MODEL_JOIN')
        need(raw['status'] == declared['expected']['raw_status'] == row['raw_status'], 'TINY_RAW_OUTCOME')
        semantic_join(model, raw, c, observed)
        need(c['status'] == t['status'] == g['status'] == 'VERIFIED'
             and t['run_status'] == raw['status'], 'TINY_ASSURANCE_JOINS')
        same({k:row[k] for k in ('semantic_status','full_snapshot_status','oracle_status',
             'incremental_graph_comparison_status','semantic_claim','engine_calls',
             'semantic_public_calls','private_reader_passes')},
             dict(semantic_status=c['status'],full_snapshot_status=t['status'],
                  oracle_status=o['status'],incremental_graph_comparison_status=g['status'],
                  semantic_claim=c['claim'],engine_calls=1,semantic_public_calls=1,
                  private_reader_passes=1), 'QUALIFICATION_ROW_TYPED_JOINS')
        need(t['model_sha256'] == o['model_sha256'] == raw['model_sha256'], 'TINY_MODEL_BINDINGS')
        need(o['status'] == 'EXHAUSTED' and o['exists'] is declared['expected']['exists']
             and o['exists'] is (raw['status'] == 'SAT'), 'INDEPENDENT_ORACLE_JOIN')
        need(o['candidate_count'] == len(model['inventory']['placements'])
             and o['assignments_checked'] == o['subsets_total'] == (1 << o['candidate_count']),
             'COMPLETE_ASSIGNMENT_CENSUS')
        need(wire([x['event'] for x in observed]) == wire(raw['events'])
             and len(observed) == g['events_checked'] == t['counts']['observations_checked'], 'ACTUAL_OBSERVATION_COVERAGE')
        need(len(g['comparisons']) == len(observed), 'PAIRED_GRAPH_COVERAGE')
        for i, (comparison, actual) in enumerate(zip(g['comparisons'], observed)):
            need(comparison['equal'] is True and comparison['seq'] == actual['event']['seq']
                 and comparison['actual_observation_sha256'] == comparison['after_derived_sha256']
                 == sha(actual['state']), 'SAVED_PAIRED_GRAPH_HASH_JOIN')
            need(comparison['before_derived_sha256'] == sha(raw['entry_state'] if i == 0
                 else observed[i-1]['state']), 'PAIRED_GRAPH_PRIOR_STATE_HASH')
        fresh.append(dict(id=row['id'], expected=declared['expected'], model=model,
                          raw_status=raw['status'], reason=raw['reason'], observations=observed,
                          semantic=c, observed_snapshot_check=t, paired_graph_check={
                              k:v for k,v in g.items() if k!='comparisons'},
                          oracle=o, stats=raw['stats'], refs=row['refs'], seconds=row['seconds'],
                          required_observations=row['required_observations']))
    mutants = []
    need(len(qualification['mutations']) == len(declarations['mutation_specs']) == 20, 'TWENTY_MUTATIONS')
    for declared, row in zip(declarations['mutation_specs'], qualification['mutations']):
        packet, receipt = checked(row['input']), checked(row['receipt'])
        need(row['id'] == packet['id'] == declared['id'] and row['case_id'] == declared['case_id']
             and row['actual'] == receipt['status'] == row['expected'] == declared['expected'], 'MUTATION_ASSOCIATION')
        if row['target'] == 'SEMANTIC' and receipt['status'] != 'VERIFIED':
            need(receipt['bounded_absence'] is False, 'MUTANT_NO_FALSE_ABSENCE')
        mutants.append(dict(**row, reason=receipt.get('reason'),
                            event_coverage=receipt.get('event_coverage'),
                            rollback_metadata_coverage=receipt.get('rollback_metadata_coverage')))
    seen = []
    for declared, row in zip(historical['cases'], retrospective['records']):
        data = {k: checked(v) for k,v in row['inputs'].items() if not k.endswith('_log')}
        for k,v in row['inputs'].items():
            if k.endswith('_log'):
                need(pin(v['path']) == {a:v[a] for a in ('path','bytes','sha256')}, 'ORIGINAL_LOG_PIN')
        raw, prepared = data['raw_result'], data['prepared']
        old, certificate = data['original_scientific_result'], checked(row['receipt'])
        semantic_join(prepared['model'], raw, certificate)
        need(row['original_process'] == declared['original_process'], 'PRESERVED_ORIGINAL_PROCESS')
        need(type(row['original_process']['execution_admitted']) is bool
             and type(row['original_process']['native_exit_code']) is int
             and type(data['original_observer']['native_exit_code']) is int,
             'ORIGINAL_PROCESS_NATIVE_TYPES')
        need(raw['status'] == row['raw_status'] == old['raw_engine_status']
             and old['status'] == row['old_science_status'], 'HISTORICAL_RAW_SCIENCE_JOIN')
        need(row['new_semantic_status'] == certificate['status']
             and row['bounded_absence'] is certificate['bounded_absence'], 'RETROSPECTIVE_CLAIM_JOIN')
        same({k:row[k] for k in ('new_semantic_claim','event_coverage','rollback_metadata_coverage')},
             dict(new_semantic_claim=certificate.get('claim'),event_coverage=certificate.get('event_coverage'),
                  rollback_metadata_coverage=certificate.get('rollback_metadata_coverage')),
             'RETROSPECTIVE_ROW_CLAIM_AND_COVERAGE')
        need(data['original_observer']['native_exit_code'] == row['original_process']['native_exit_code'], 'ORIGINAL_EXIT_RETAINED')
        seen.append(dict(id=row['id'], source_case_id=row['source_case_id'], raw_status=raw['status'],
                         reason=raw['reason'], old_science_status=old['status'],
                         old_native_admission=old.get('admission'), original_process=row['original_process'],
                         old_proof_lines=old.get('proof_lines'),
                         semantic=certificate, costs=row['costs'], old_costs=old.get('costs'),
                         original_observer_seconds=data['original_observer']['seconds'],
                         events=event_projection(raw['events']), event_extent=raw['event_extent'],
                         rollback_extent=raw['rollback_extent'], stats=raw['stats'],
                         statement=prepared['statement'], formulas=prepared['catalogue']['formulas'],
                         literal_formula_inventory_sha256=sha({k:prepared['catalogue'][k]
                             for k in ('formulas','zeros','mp','gen')}),
                         candidate_display=candidates_for_events(prepared, raw, certificate),
                         model_metadata=dict(capacity=prepared['model']['capacity'],
                             slots=prepared['binding']['slots'] if 'slots' in prepared['binding'] else prepared['census']['slots'],
                             census=prepared['census'], binding=prepared['binding']['scope']),
                         refs=dict(inputs=row['inputs'], semantic=row['receipt'])))
    qualification_counts = dict(cases=len(fresh), finite_exhaustion_certificates=sum(
        c['semantic']['claim'] == 'SEMANTIC_COMPLETE_FINITE_EXHAUSTION' for c in fresh),
        mutation_statuses=dict(Counter(m['actual'] for m in mutants)))
    retrospective_counts = dict(records=len(seen),
        semantic_statuses=dict(Counter(c['semantic']['status'] for c in seen)),
        new_finite_exhaustion_certificates=sum(c['semantic']['status'] == 'VERIFIED'
            and c['semantic']['bounded_absence'] is True for c in seen),
        original_failed_processes=sum(c['original_process']['execution_admitted'] is False for c in seen))
    same(qualification['counts'], qualification_counts, 'RECOMPUTED_TYPED_QUALIFICATION_COUNTS')
    same(retrospective['counts'], retrospective_counts, 'RECOMPUTED_TYPED_RETROSPECTIVE_COUNTS')
    contrasts = []
    for lower in seen:
        if not (lower['semantic']['status'] == 'VERIFIED' and lower['semantic']['bounded_absence']):
            continue
        for upper in seen:
            if (upper['old_science_status'] == 'VERIFIED_POSITIVE'
                and upper['model_metadata']['slots'] > lower['model_metadata']['slots']
                and wire(upper['statement']) == wire(lower['statement'])
                and upper['literal_formula_inventory_sha256'] == lower['literal_formula_inventory_sha256']):
                contrasts.append(dict(lower_id=lower['id'], upper_id=upper['id'],
                    original_statement_sha256=sha(lower['statement']),
                    formula_inventory_sha256=lower['literal_formula_inventory_sha256'],
                    lower_slots=lower['model_metadata']['slots'], upper_slots=upper['model_metadata']['slots'],
                    upper_saved_native_proof_lines=upper['old_proof_lines'],
                    upper_semantic_status=upper['semantic']['status']))
    ternary = next(c for c in fresh if c['id'] == 'sq13-unmarked-ternary-failure')
    solutions = ternary['oracle']['solutions']
    pairs = [dict(required=required, completions=[s for s in solutions if set(required)<=set(s)])
             for required in (['00-A','10-B'], ['00-A','20-C'], ['10-B','20-C'])]
    triple = [s for s in solutions if {'00-A','10-B','20-C'}<=set(s)]
    source_refs = [pin(n) for n in ('plan/fixed-marking-expressivity-v1.md',
                                   'plan/experiment-protocol-v1.md',
                                   'plan/semantic-checker-API-v1.md')]
    summary = dict(schema='Semantic-certificates-saved-summary-v1',
        status='ADMITTED_SEMANTIC_CERTIFICATES_WITH_EXPLICIT_UNKNOWN',
        qualification=dict(cases=fresh, mutations=mutants, process=qprocess,
                           counts=qualification_counts),
        retrospective=dict(records=seen, process=rprocess, counts=retrospective_counts, engine_reruns=0),
        bound_contrasts=contrasts,
        ternary=dict(case_id=ternary['id'], saved_oracle_solutions=len(solutions),
                     pair_completions=pairs, triple_completions=triple,
                     analytic_lemma_premises_observed=all(p['completions'] for p in pairs) and not triple),
        costs=dict(qualification_observed_process_seconds=qprocess['observer_seconds'],
                   retrospective_observed_process_seconds=rprocess['observer_seconds'],
                   retrospective_new_assurance_seconds=sum(c['costs']['verifier_and_save_seconds'] for c in seen),
                   scope='New qualification acquisition and checker-only retrospective costs; historical search clocks reused, no new engine timing comparison.'),
        provenance=dict(protocol=pin('data/protocol-frozen-v1.json'),
                        root_source_admission=pin('review/root-source-admission-v1.json'), notes=source_refs,
                        frozen_files_checked=len(protocol['files']), current_external_custody=environment),
        reader_projection='Tiny observations are actual producer snapshots. Retrospective events omit only BRANCH legal/order arrays in this reader projection and retain their counts; full raw bytes are downloadable. Literal formula display is lookup only, not a new decoder/kernel execution.',
        limitations=['Semantic complete finite point-inventory exhaustion is not the logical negation of the goal or unrestricted mathematical nonprovability.',
                     'Retrospective intermediate producer maps were not observed by the new semantic checker.',
                     'The original failed postcheck/native exit one remains failed even if its semantic and native positive evidence is valid.',
                     'All eight retrospective examples are seen; no search rerun, RL, learned marking, new theorem or speed advantage is established.',
                     'Dead context witnesses require the whole verified trace/model/exclusion provenance; they are not standalone learned constraints.'])
    audit = dict(schema='Semantic-certificates-saved-data-audit-v1', status='PASS_SAVED_DATA_AUDIT',
                 qualification_cases=len(fresh), mutation_packets=len(mutants), retrospective_records=len(seen),
                 new_engine_runs_claimed=len(fresh), retrospective_engine_reruns=0,
                 original_failed_processes=sum(not c['original_process']['execution_admitted'] for c in seen),
                 passive_only=True, scientific_modules_imported=False,
                 scope='Exact physical byte pins, saved result/process/certificate/event/witness/observation joins only. No checker, oracle, solver, model builder, native kernel or state replay executed.',
                 artifacts=list(LEDGER.values()))
    audit_ref = save('review/saved-data-audit-v1.json', audit)
    summary['saved_data_audit'] = audit_ref
    summary['artifacts'] = list(LEDGER.values())
    return save('data/report-summary-v1.json', summary)


if __name__ == '__main__':
    print(json.dumps(assemble(), sort_keys=True))
