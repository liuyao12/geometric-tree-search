# Passive report handoff

Status: **SOURCE_ONLY_PENDING_ROOT_READ_AND_EXECUTION**. Python AST parsing and
JavaScript syntax compilation passed. The JavaScript was compiled inside an
uninvoked function body; no reader, assembler, scientific module or kernel was
executed. The earlier command-line Node lookup was unavailable; the later
isolated Node REPL compilation supplied the syntax check.

Root runs these in order with the already pinned isolated Python runtime,
using `-I -S -B`:

1. `report/assemble_semantic_results_v1.py`
2. `report/build_semantic_report_v1.py`

Both use their own file location to find this root. They accept no external
paths and write exclusively: preserve an earlier attempt before any reviewed
correction. No run is authorized by this note. Scientific `source`, `reference`,
`input` and `plan` directories remain frozen and untouched.

The assembler consumes actual completed `qualify` and `retrospective` result,
started/invocation/observer receipts, the frozen protocol and its exact byte
pins, all driver artifact refs, and Root's Source admission at
`review/root-source-admission-v1.json` with
`status=PASS_SOURCE_REVIEW_BEFORE_FREEZE`. It hashes and joins saved data only;
it does not import scientific helpers or replay state transitions.

The passive gate also enumerates the exact current frozen file set, verifies
current master and isolated Python executable/version/flags against the
protocol, joins claims and coverage to their saved receipts, and recomputes
typed qualification/mutation/retrospective counts. External runtime/master
custody metadata stays separate from the relative artifact download ledger.

Outputs:

- `data/report-summary-v1.json`, schema
  `Semantic-certificates-saved-summary-v1`, status
  `ADMITTED_SEMANTIC_CERTIFICATES_WITH_EXPLICIT_UNKNOWN`.
- `review/saved-data-audit-v1.json`, schema
  `Semantic-certificates-saved-data-audit-v1`, status
  `PASS_SAVED_DATA_AUDIT`.

Summary fields are `qualification` (`cases`, `mutations`, `process`, `counts`),
`retrospective` (`records`, `process`, `counts`, `engine_reruns`), `ternary`,
`bound_contrasts`, `costs`, `provenance`, `reader_projection`, `limitations`,
`saved_data_audit` and physically local pinned `artifacts`. The summary preserves
each original process/native-exit status independently from new semantic
assurance. Prior native positive admission is reused metadata, never a new
kernel call. A larger-bound contrast is included only when the saved original
statements and literal formula/producer inventories match exactly.

The builder consumes that summary and its pinned PASS audit, then emits:

- `report/semantic-certificates-v1.html`, anchor `#reader`.
- `report/semantic-certificates-evidence-v1.html`.
- `report/semantic-certificates-results-v1.json.gz`.
- `report/semantic-certificates-downloads-v1/`.
- `review/report-build-v1.json`, schema
  `Semantic-certificates-report-build-v1`, status `PASS_REPORT_BUILD`, with
  `summary`, `saved_data_audit`, `renderer_source`, `outputs` (`main`, `evidence`,
  `data`), `downloads` and `scope`.

Tiny event-player snapshots are actual producer observations. Retrospective
event projections remove only long branch legal/order arrays and retain their
counts; raw arrays remain downloadable. Candidate formulas are literal lookup
annotations. Pair completions are filtered only from the saved exhaustive
oracle solutions. A checked dead context still requires its full trace/model
and exclusion provenance, so the reader never advertises it as an admitted
standalone learned marking.
Witness lists explicitly show retained, total, unshown and sample-limit counts.
Branch formula annotations refer to the recorded first candidate pending its
`PLACED` event, not an already adopted placement.

Download names end in `.gz`. Original gzip bytes are copied unchanged; other
artifact bytes are losslessly wrapped in deterministic gzip and checked by
decompression. The evidence table states original byte counts and hashes.
No source/log/history material is fetched from old immutable roots.

Both pages contain `<!-- SEMANTIC_CERTIFICATES_ARCHIVE_LINK -->`. Publication
is a separate Root action gated by `review/root-publication-admission-v1.json`
with status `PASS`, after actual results, passive audit, report build and local
UI checks. The Source admission alone cannot authorize publication. Use only
the existing `conditional-inventory` destination; the sole old-page backlink
change is `resource-diagnostic-v1.html` to the new `#reader`.
