"""Administrative publication of the complete three-arm negative, without replay."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import html
import json
import zipfile

ROOT = Path(__file__).resolve().parent
STUDY = ROOT.parent
REPO = STUDY.parents[1]
P2 = STUDY.parent / 'gcts-batch-20261020/publisher-recovery-6338a77'
STAGE = ROOT / 'publication-frozen-target-comparison-v1'
PAYLOAD = P2 / 'publication-payload-frozen-target-comparison-v1'
PRIOR = ROOT / 'publication-contextual-controls-v1'
PREFIX = 'docs/research/gcts-rl-renewal/conditional-inventory/'
NAMES = ('point-proof-parallel-progress-v1.html',
         'point-proof-frozen-target-comparison-summary-v1.json',
         'point-proof-frozen-target-comparison-evidence-v1.zip')

SOURCE_SNAPSHOTS = {}
SOURCE_RECOVERY = []

def raw(path):
    path = Path(path)
    assert path.is_absolute() and path.resolve() == path
    assert path.is_file() and not path.is_symlink() and '.partial' not in path.name
    assert path.name not in ('index.html', '.gcts-active')
    if path in SOURCE_SNAPSHOTS:
        return SOURCE_SNAPSHOTS[path]
    return path.read_bytes()


def pin(path):
    body = raw(path)
    return dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def js(value):
    return (json.dumps(value, indent=2, ensure_ascii=True, allow_nan=False) + '\n').encode()


def write(path, body):
    with path.open('xb') as stream:
        stream.write(body)
    assert raw(path) == body


def math(value):
    return r'\(' + html.escape(str(value)) + r'\)'


def main():
    disposition_path = ROOT / 'frozen-target-contextual-three-arm-Root-complete-whole-disposition-v1.json'
    disposition = json.loads(raw(disposition_path))
    assert disposition['study_outcome'] == 'ALL_THREE_WHOLE_RESOURCE_NEGATIVES'
    assert disposition['admitted_proofs'] == 0 and disposition['admitted_contextual_uses'] == 0
    assert disposition['all_three_outcomes_reviewed'] is True
    assert disposition['resources_admitted'] is False
    audit_path = ROOT / 'frozen-target-contextual-three-arm-complete-raw-Root-passive-audit-v1.json'
    audit = json.loads(raw(audit_path))
    assert disposition['passive_audit'] == pin(audit_path)
    complete_review = disposition['complete_C_review']
    assert complete_review == pin(Path(complete_review['path']))
    reviewed = json.loads(raw(complete_review['path']))
    assert reviewed['review_passed'] is True and reviewed['blockers'] == []
    observed_path = Path(disposition['observed_coverage']['path'])
    assert pin(observed_path) == disposition['observed_coverage']
    authorization = ROOT / 'full-evidence-archive-direct-user-publication-authorization-v1.json'
    assert json.loads(raw(authorization))['direct_human_answer'] == 'Approve publishing the full archive'
    arms = audit['arms']
    assert [row['arm'] for row in arms] == ['NO_LIBRARY','CONDITIONAL_LEMMA_CD','RECEPTOR_DAG']
    members, external = {}, []

    def include(path, role, expected=None):
        path = Path(path)
        body = raw(path)
        ref = dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())
        if expected is not None:
            assert ref == {k: expected[k] for k in ('path','bytes','sha256')}
        try:
            name = 'project/' + path.relative_to(REPO).as_posix()
        except ValueError:
            assert ref == plans[0]['python']
            if not external:
                external.append(dict(role=role, **ref, supplied_separately=True))
            return
        assert not any(p in ('.git','.ssh','.aws') for p in path.parts)
        if name in members:
            assert members[name]['ref'] == ref
        else:
            members[name] = dict(role=role,ref=ref,body=body)

    plans = [json.loads(raw(row['plan']['path'])) for row in arms]
    assert all(plan['files'] == plans[0]['files'] for plan in plans)
    # Only raw Source snapshots are recovered; no historical scientific result is decoded.
    prior_zip_source = PRIOR/'point-proof-contextual-controls-evidence-v1.zip'
    prior_body = raw(prior_zip_source)
    assert len(prior_body)==15563253 and hashlib.sha256(prior_body).hexdigest()=='046b2205ef28110948ebfd04ee67ee4ca34d84b9f9344e1f78a737ab4cba1b51'
    assert disposition['all47guard_pins_current'] is True
    recover_names = []
    with zipfile.ZipFile(__import__('io').BytesIO(prior_body)) as previous:
        available=set(previous.namelist())
        for guard in plans[0]['files']:
            p=Path(guard['path'])
            if p.suffix!='.py' or not p.is_relative_to(REPO):
                continue
            relative=p.relative_to(REPO).as_posix()
            if 'project/'+relative in available:
                recover_names.append(relative)
    assert len(recover_names)>=3
    import io
    with zipfile.ZipFile(io.BytesIO(prior_body)) as previous:
        for relative in recover_names:
            p=REPO/relative
            ref=next(row for row in plans[0]['files'] if row['path']==str(p))
            member='project/'+relative
            assert previous.namelist().count(member)==1 and p.stat().st_size==ref['bytes']
            body=previous.read(member)
            assert len(body)==ref['bytes'] and hashlib.sha256(body).hexdigest()==ref['sha256']
            SOURCE_SNAPSHOTS[p]=body
            SOURCE_RECOVERY.append(dict(**ref,prior_archive_member=member,provenance='Byte-identical prior archived Source; current guard identity freshly verified by complete Root disposition, not reread again during packaging.'))
    for row in plans[0]['files']:
        include(row['path'],'current-runtime-or-explicit-metadata-guard',row)
    for row in audit['all_files']:
        include(row['path'],'complete-current-actual-or-observer-file',row)
    extras = [disposition_path,audit_path,Path(complete_review['path']),observed_path,authorization,
        ROOT/'frozen-target-contextual-reuse-study-preparation-v1.json',
        ROOT/'frozen-target-contextual-prospective-Root-passive-audit-v1.json',
        STUDY/'review-C/typed-frozen-target-contextual-reuse-complete-three-arm-whole-prospective-review-v1.json',
        ROOT/'admit_frozen_target_comparison_v1.py',ROOT/'prepare_frozen_target_comparison_publication_v1.py',ROOT/'prepare_frozen_target_comparison_publication_v2.py',ROOT/'frozen-target-comparison-administrative-read-recovery-complete-v2.json',Path(__file__).resolve(),
        ROOT/'publish_frozen_target_comparison_api_v1.py',ROOT/'verify_frozen_target_comparison_live_v1.py']
    for row in arms:
        extras.extend(Path(row[k]['path']) for k in ('plan','grant','Root_once_acceptance'))
    for row in disposition['per_arm_C_reviews']:
        extras.append(Path(row['path']))
    for key in ('Source_diagnosis','Source_diagnosis_review','next_Source_contract'):
        if key in disposition:
            record=disposition[key]
            include(record['path'],'explicit-prospective-Source-diagnosis-not-a-runtime-result',record)
    prior_zip = PRIOR/'point-proof-contextual-controls-evidence-v1.zip'
    extras.append(prior_zip)
    for path in extras:
        include(path,'explicit-current-disposition-review-or-provenance-or-prior-archive')
    catalog=dict(schema='Root-frozen-target-comparison-full-evidence-catalog-v1',
        issued_utc=datetime.now(timezone.utc).isoformat(),Root_disposition=pin(disposition_path),
        direct_user_archive_authorization=pin(authorization),
        members=[dict(member=n,role=v['role'],**v['ref']) for n,v in sorted(members.items())],
        external_runtime=external,prior_archive=pin(prior_zip),source_snapshot_recovery=SOURCE_RECOVERY,current_guard_identity_disposition=pin(disposition_path),scientific_replay=False,
        scope='Exact current47-guard closure except separately supplied Python; all33 complete three-case/observer files; all three plans/grants/once acceptances, complete negative reviews/disposition and explicit metadata/Source helpers. Explicit guard-listed byte-identical raw Python Source snapshots already present in the prior archive are copied from the prior verified archive, with current guard identity verified in the complete Root disposition. The prior full archive is additionally included unchanged as one opaque nested member. Original carrier and learned-result bodies are not newly opened or repeated here. Not a recursive closure of every historical citation. No failed prefix is a proof or admitted inventory.')
    STAGE.mkdir()
    PAYLOAD.mkdir()
    archive_path=STAGE/NAMES[2]
    with zipfile.ZipFile(archive_path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as bundle:
        for n,body in [('catalog.json',js(catalog))]+[(n,v['body']) for n,v in sorted(members.items())]:
            info=zipfile.ZipInfo(n,(2026,10,25,0,0,0));info.external_attr=0o100644<<16
            bundle.writestr(info,body,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
    with zipfile.ZipFile(archive_path) as bundle:
        assert len(bundle.namelist())==len(members)+1 and set(bundle.namelist())==set(members)|{'catalog.json'}
        for n,v in members.items():
            assert bundle.read(n)==v['body']
    summary=dict(schema='public-frozen-target-three-arm-comparison-summary-v1',
        status='ALL_THREE_WHOLE_RESOURCE_NEGATIVES',admitted_proofs=0,admitted_contextual_uses=0,
        normal_unknown_results=0,complete_normal_search_receipts=0,retained_candidate_certificates=0,
        offers_and_selected_application_counts=None,
        target_identity=plans[0]['input_authority']['target_identity'],
        fixed_arm_order=[r['arm'] for r in arms],
        rows=[{k:row[k] for k in ('arm','case_id','observed_status','error_type','error_message',
            'all7positive_fields_null','resource_candidate_accepted','normal_search_result_retained',
            'normal_unknown','final_use_map_retained','callbacks','observer_elapsed_seconds',
            'observer_final_gate_seconds','raw_child_high_water_bytes','worker_header_high_water_bytes',
            'conservative_whole_peak_bytes','physical_files','physical_bytes','stages')} for row in arms],
        original_limits=plans[0]['limits'],configuration=json.loads(raw(plans[0]['protocol']['path']))['metadata']['configuration'],
        complete_C_review=complete_review,Root_disposition=pin(disposition_path),
        scope='Same frozen target, three predeclared serial cold attempts. Failure times are termination diagnostics, not proof times or relative efficiency. Child RSS is not whole memory; the original whole-bound fields remain null. No selected-use count is inferred from missing receipts. No GCTS/RL advantage, successful transfer or nonprovability claim.',
        evidence_archive=dict(name=NAMES[2],**{k:pin(archive_path)[k] for k in ('bytes','sha256')},entries=len(members)+1))
    labels={'NO_LIBRARY':'No library','CONDITIONAL_LEMMA_CD':'Conditional lemmas','RECEPTOR_DAG':'Direct DAG'}
    table=[];bars=[]
    for row in arms:
        table.append('<tr><td>'+labels[row['arm']]+'</td><td>'+math(f"{row['observer_elapsed_seconds']:.3f}\\,\\mathrm{{s}}")+'</td><td>'+math(str(row['raw_child_high_water_bytes'])+r'\,\mathrm{bytes}')+'</td><td>Memory limit during search</td></tr>')
        percent=100*row['raw_child_high_water_bytes']/(1.3*1073741824)
        bars.append('<div class="memory-row"><b>'+labels[row['arm']]+'</b><div class="memory-track"><div class="memory-fill" style="width:'+f'{percent:.6f}'+'%"></div><div class="memory-limit"></div></div><span>'+math(f"{row['raw_child_high_water_bytes']/1048576:.1f}\\,\\mathrm{{MiB}}")+'</span></div>')
    section=r'''<style>.negative-lead{border-top:6px solid #a44f38}.memory-chart{padding:20px 0}.memory-row{display:grid;grid-template-columns:180px 1fr 150px;gap:16px;align-items:center;margin:18px 0}.memory-row b{font-size:15px}.memory-row span{font-size:15px}.memory-track{height:32px;background:#f2eeea;position:relative;border-radius:4px}.memory-fill{height:100%;background:#b9654b;border-radius:4px}.memory-limit{position:absolute;left:76.923077%;top:-8px;height:48px;border-left:3px dashed #203239}.negative-lead .fact{color:#a44f38}.negative-table{overflow-x:auto}@media(max-width:720px){.memory-row{grid-template-columns:1fr 130px;gap:8px}.memory-row b{grid-column:1/-1}.negative-table table{min-width:680px}}</style>
<section class="panel negative-lead" id="frozen-target-comparison-current"><p class="status">Current result · three fixed target attempts · 25 October 2026 UTC</p>
<h1>The first transfer comparison failed in all three arms.</h1>
<p>The same frozen propositional target was attempted with no library, with ordinary conditional lemmas, and with direct attachment of the acquired proof families. Every run hit the declared Python memory threshold during search. No run returned a complete search receipt or certificate for the two original validators.</p>
<div class="grid"><article class="card"><h3>Checked proofs</h3><span class="fact">\(0\)</span><p>No new theorem proof or final lemma-use map was admitted.</p></article><article class="card"><h3>Resource failures</h3><span class="fact">\(3/3\)</span><p>All predeclared arms were consumed once, in order, under the unchanged limits.</p></article><article class="card"><h3>Evaluation target</h3><span class="fact">\(1\)</span><p>The exact same original input bytes were used in every arm. The target was not replaced after failure.</p></article></div>
<div class="notice"><strong>Assessment:</strong> the present symbolic consumer is not practically adequate for this target and budget. The acquired inventory has not yet demonstrated useful transfer. These failures provide no evidence of a CD-versus-DAG advantage or a GCTS/RL contribution.</div>
<h2>The measured outcomes</h2><div class="negative-table"><table><thead><tr><th>Arm</th><th>Whole observer elapsed</th><th>Recorded child high-water</th><th>Outcome</th></tr></thead><tbody>'''+''.join(table)+r'''</tbody></table></div>
<p>Elapsed time here measures termination at resource failure. A speed comparison requires reaching the same verified goal. The two library arms both completed the declared all-seven-family intake stage before entering search; that does not establish selection of a family or useful reuse.</p>
<h2>Memory observations, with their limits</h2><p>The dashed line marks the \(1\,\mathrm{GiB}\) cooperative rejection threshold. The bars show the operating system's child-process high-water observations, not a qualified whole-process memory bound.</p><div class="memory-chart" role="img" aria-label="All three recorded child memory peaks exceed the cooperative rejection threshold">'''+''.join(bars)+r'''</div>
<p class="caption">Allocations between checkpoints can overshoot the threshold. The saved whole-memory-bound fields remain null because the cases failed. No accepted memory fit or causal memory profile is inferred from these bars.</p>
<h2>What remains known after failure</h2><p>Each case preserved the original first memory error, completed custody and log EOF, and withheld all seven positive payloads. All \(33\) actual and observer files remain available. The provisional query artifacts agree byte for byte. There is no completed normal search return, no retained candidate certificate and no final proof-use trace.</p>
<p>Internal offer, application and hierarchy counts are unavailable. They are not displayed as zero. No postfailure getter or replay was used to recover a positive prefix. This is a resource-limited negative, rather than a nonprovability result or a normal exhausted-search unknown.</p>
<h2>What changes next</h2><p>Inspect the active obligation, alternative and watcher storage before another proof-search experiment. In this implementation, the configuration field <code>obligation_nodes</code> bounds formula size; it does not cap the number of stored obligations or alternatives. The Source retains several record views and dependency entries for generated alternatives. That makes representation and growth control concrete candidates for redesign, while the actual dominant allocation remains unmeasured.</p>
<p>A successor must preserve the declared inference choices, real boundary obligations, complete checking and primitive fallback. It needs a prospective contract and a separate experiment; these three consumed failures stay unchanged. Reusable proof families, learned markings and RL remain research goals. The current engine is an ordinary symbolic obligation-search adaptation, with no claim of full geometric GCTS conformance.</p>
<p><a href="point-proof-frozen-target-comparison-summary-v1.json">Exact per-arm outcomes and clock scopes</a> · <a href="point-proof-frozen-target-comparison-evidence-v1.zip">Full approved three-arm evidence archive</a> · <a href="#contextual-controls-current">Earlier finite qualification and its coverage gaps</a> · <a href="point-proof-discovered-proofs-v1.html">Earlier automatically found training proofs</a></p>
<p class="caption">The complete archive includes current Source snapshots, original input artifacts, failure traces, logs, complete independent reviews and local provenance paths under direct user approval. It nests the earlier full archive unchanged. The pinned external Python runtime is identified separately. These failed runs contribute no new line-by-line proof to the reader.</p></section>
<p class="notice"><strong>Earlier milestones below.</strong> Their old current-status and unopened-target labels describe those earlier checkpoints. The three resource failures above are the current evaluation outcome.</p>'''
    page=raw(PRIOR/NAMES[0]).decode();assert page.count('<body><main>')==1
    page=page.replace('<body><main>','<body><main>'+section,1)
    page=page.replace('<title>Proof-family search: closed reuse observed, open reuse unexercised</title>',
                      '<title>First proof-family transfer test: three memory-limited failures</title>',1)
    assert not any(ord(c)<32 and c not in '\n\t' for c in page)
    rows=[]
    for name,body in zip(NAMES,(page.encode(),js(summary),raw(archive_path))):
        if name!=NAMES[2]:write(STAGE/name,body)
        write(PAYLOAD/name,body)
        rows.append(dict(path=PREFIX+name,root_source=str(STAGE/name),publisher_source=str(PAYLOAD/name),
            bytes=len(body),sha256=hashlib.sha256(body).hexdigest(),
            git_blob_sha1=hashlib.sha1(b'blob '+str(len(body)).encode()+b'\0'+body).hexdigest()))
    staging=dict(schema='Root-frozen-target-comparison-three-path-staging-v1',scientific_execution=False,
        disposition=pin(disposition_path),baseline=pin(PRIOR/NAMES[0]),direct_user_archive_authorization=pin(authorization),
        files=rows,archive_entries=len(members)+1,archive_members_verified=True,external_runtime=external,source_snapshot_recovery=SOURCE_RECOVERY,
        scope='Exact report, negative summary and approved full task archive; sole isolated P2 only. No current failed prefix or new proof admission.')
    write(STAGE/'P2-staging.json',js(staging));print(json.dumps(pin(STAGE/'P2-staging.json')))


if __name__=='__main__':
    main()
