"""External disposition of three complete resource negatives; no scientific replay."""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json

ROOT=Path(__file__).resolve().parent
STUDY=ROOT.parent


def pin(path):
    body=path.read_bytes()
    return dict(path=str(path),bytes=len(body),sha256=hashlib.sha256(body).hexdigest())


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--diagnosis')
    args=parser.parse_args()
    review_path=STUDY/'review-C/typed-frozen-target-contextual-reuse-three-arm-aggregate-negative-assessment-v1.json'
    review=json.loads(review_path.read_bytes())
    assert review['schema']=='C-frozen-target-contextual-reuse-three-arm-aggregate-negative-assessment-v1'
    assert review['review_passed'] is True and review['blockers']==[]
    assert review['disposition']=='ALL_THREE_CONSUMED_WHOLE_NEGATIVE'
    assert all(review[k] is False for k in ('resources_admitted','proof_admitted','contextual_use_admitted'))
    audit_path=ROOT/'frozen-target-contextual-three-arm-complete-raw-Root-passive-audit-v1.json'
    audit=json.loads(audit_path.read_bytes())
    observed_path=STUDY/'diagnostics-L/frozen-target-contextual-reuse-three-arm-passive-outcome-census-v1.json'
    observed=json.loads(observed_path.read_bytes())
    assert observed['assessment_complete'] is True
    assert observed['aggregate']['consumed_cases']==3
    assert observed['aggregate']['complete_normal_search_receipts']==0
    assert observed['aggregate']['admitted_research_proofs']==0
    arms=('NO_LIBRARY','CONDITIONAL_LEMMA_CD','RECEPTOR_DAG')
    assert [r['arm'] for r in audit['arms']]==review['fixed_arm_order']==list(arms)
    for record in audit['all_files']:
        assert pin(Path(record['path']))==record
    for own,other,record in zip(audit['arms'],review['subjects']['cases'],review['subjects']['per_arm_reviews']):
        assert own['arm']==other['arm']
        p=Path(record['path']);assert pin(p)==record
        c=json.loads(p.read_bytes())
        assert c['review_passed'] is True and c['blockers']==[]
        assert c['negative_disposition_complete'] is True and c['case_id']==own['case_id']
        assert all(c[k] is False for k in ('resources_admitted','proof_admitted','contextual_use_admitted','normal_search_outcome_admitted'))
        for name in ('plan','grant','Root_once_acceptance','failure','terminal','observer','query'):
            assert own[name]==other[name]==c['subjects'][name]==pin(Path(own[name]['path']))
        plan=json.loads(Path(own['plan']['path']).read_bytes())
        for guard in plan['files']:
            assert pin(Path(guard['path']))==guard
        failure=json.loads(Path(own['failure']['path']).read_bytes())
        assert failure['status']=='FAILED_CASE_NOT_ADMITTED' and failure['first_Root_fault'] is True
        assert all(failure[k] is None for k in ('qualification_provenance','input_freeze','library_provenance',
            'producer_result','subject_receipt','reference_receipt','scientific_result'))
        assert failure['error']['type']=='RootBudget' and failure['error']['message']=='whole Python high-water ceiling'
    value=dict(schema='Root-frozen-target-contextual-three-arm-complete-whole-disposition-v1',
        issued_utc=datetime.now(timezone.utc).isoformat(),
        study_outcome='ALL_THREE_WHOLE_RESOURCE_NEGATIVES',
        comparison_attempt_complete=True,all_three_outcomes_reviewed=True,
        negative_disposition_accepted=True,resources_admitted=False,
        admitted_proofs=0,admitted_contextual_uses=0,normal_unknown_results=0,
        complete_C_review=pin(review_path),per_arm_C_reviews=review['subjects']['per_arm_reviews'],
        passive_audit=pin(audit_path),observed_coverage=pin(observed_path),
        arms=audit['arms'],all33_files=33,all_actual_bytes=audit['complete_file_bytes'],
        all47guard_pins_current=True,actuals_this_turn=3,uses_per_case=1,
        same_original_query_bytes=True,
        target_identity=dict(bytes=38,sha256='8e56b3ed583f537881ffebcd40dc32443e5b0e204e52a978f9b7e65ee6104f24'),
        holdout_loaded=True,holdout_searched=True,holdout_proved=False,
        library_intake_scope='Both library-arm LOAD ALL SEVEN FAMILIES stages completed before SEARCH under unchanged Source; their detailed positive intake records were retired on first failure. No selected-use, offer or hierarchy count is available.',
        original_worker_flags_and_negative_files_unchanged=True,
        prior_inventory_and_qualification_admissions_unchanged=True,
        partial_or_postfault_positive_snapshot_admitted=False,
        GCTS_RL_advantage=False,
        conformance='Ordinary monotone symbolic obligation-search adaptation; no full geometric point-incidence/generation/rollback conformance or learned GCTS/RL implementation claim.',
        cost_scope='Saved per-case observer termination times and raw child RSS only. Failed cases have null qualified whole-memory bounds. No completed proof-time, speed, CD/DAG representation or relative memory-efficiency comparison follows.',
        scope='Complete three-arm negative lifecycle only. Each case hit the genuine cooperative Python high-water check during SEARCH. No normal search receipt, original candidate certificate, paired proof validation or final use map was produced. Not unprovability or normal UNKNOWN; no prefix salvage or current-case retry.',
        next_priority='Inspect and redesign shared active obligation/alternative retention while preserving inference choices, real boundary obligations, primitive fallback, complete proof checking and the original negative history. Any successor requires a prospective Source/experiment contract; no easier target or enlarged limits to relabel these cases.',
        scientific_imports_calls_or_replays_in_disposition=0,
        goal_status='ACTIVE_UNBUDGETED_INCOMPLETE')
    if args.diagnosis:
        p=Path(args.diagnosis)
        assert p.parent==STUDY/'implementation-B' and p.suffix=='.json'
        value['Source_diagnosis']=pin(p)
        value['Source_diagnosis_scope']='Prospective Source-only analysis/design; not runtime allocation attribution, measured optimization or new scientific admission.'
    out=ROOT/'frozen-target-contextual-three-arm-Root-complete-whole-disposition-v1.json'
    with out.open('x') as stream:
        json.dump(value,stream,indent=2,sort_keys=True,ensure_ascii=True,allow_nan=False)
        stream.write('\n')
    print(json.dumps(pin(out)))


if __name__=='__main__':
    main()
