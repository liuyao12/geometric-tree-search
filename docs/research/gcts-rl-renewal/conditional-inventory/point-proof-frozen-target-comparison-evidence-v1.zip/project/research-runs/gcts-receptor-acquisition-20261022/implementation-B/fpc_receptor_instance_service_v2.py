"""Generic typed receptor instance service; Source only until reviewed once.

No donor data, target proof, search, controller, learned policy, filesystem or
native-policy getter is imported or executed by this standalone module.
"""
VERSION = 'FPC-RECEPTOR-INSTANCE-SERVICE-v2'
import hashlib
import json
import math
from types import MappingProxyType

_OWNER = object()
_QUERY_FIELDS = ('version', 'claim_mode', 'function_arities', 'predicate_arities',
                 'theory_profile', 'finite_axioms', 'Gamma', 'goal')
_FAMILY_FIELDS = ('family_key', 'family_id', 'parameters', 'root_local_id',
    'internal_nodes', 'boundary_nodes', 'source_occurrences', 'distinct_base_nodes',
    'size_band', 'validation_provenance')
_NODE_FIELDS = ('local_id', 'rule_tag', 'subtag', 'formula_pattern', 'witness_pattern', 'references')
_MODULE_VERSIONS = {'checker': 'FPC-H1-BYTE-CHECKER-v1',
    'builders': 'FPC-H1-AST-BUILDERS-v1', 'reference': 'FPC-H1-independent-flat-reference-v2'}


class FamilyInputError(ValueError):
    """Public message construction is unowned; only a private call mints refusal."""


def is_owned_error(error):
    return type(error) is FamilyInputError and getattr(error, '_owner', None) is _OWNER


class _Call:
    def __init__(self, check):
        self.check, self.first, self.token = check, None, object()

    def fault(self):
        if self.first is not None:
            raise self.first

    def abort(self, error):
        if self.first is None:
            self.first = error
        raise self.first

    def tick(self):
        self.fault()
        try:
            self.check()
        except BaseException as error:
            self.abort(error)

    def fail(self, code, path, message):
        self.fault()
        error = FamilyInputError(message)
        error.code, error.path = code, path
        error._owner, error._call_token = _OWNER, self.token
        self.abort(error)

    def need(self, condition, path, message, code='INVALID_INPUT'):
        self.tick()
        if not condition:
            self.fail(code, path, message)

    def helper(self, function, *args, **kwargs):
        self.tick()
        try:
            answer = function(*args, **kwargs)
        except BaseException as error:
            self.abort(error)
        self.tick()
        return answer


def _nat(value):
    return type(value) is int and value >= 0


def _keys(value, names, c, path):
    c.need(type(value) is dict or type(value) is MappingProxyType, path, 'plain object required')
    c.need(len(value) == len(names), path, 'exact object fields required')
    for key in value:
        c.need(type(key) is str, path, 'exactstr keys before lookup')
    c.need(set(value) == set(names), path, 'exact object fields required')


def _array(value, c, path):
    c.need(type(value) is list or type(value) is tuple, path, 'ordinary ordered vector required')
    return value


def _copy(value, c, *, frozen, allow_bytes=False):
    """Occurrence-preserving iterative owned copy; no object identity is semantic."""
    stack, values, active = [('visit', value)], [], set()
    while stack:
        c.tick()
        task = stack.pop()
        if task[0] == 'visit':
            item = task[1]
            kind = type(item)
            if item is None or kind is bool or kind is int or kind is str:
                values.append(item)
            elif kind is float:
                c.need(math.isfinite(item), (), 'finite diagnostic float required')
                values.append(item)
            elif kind is bytes and allow_bytes:
                values.append(item)
            else:
                mapping = kind is dict or kind is MappingProxyType
                c.need(mapping or kind is list or kind is tuple, (), 'exact JSON or declared bytes carrier required')
                identity = id(item)
                c.need(identity not in active, (), 'acyclic carrier required')
                active.add(identity)
                keys = []
                if mapping:
                    for key in item:
                        c.need(type(key) is str, (), 'exactstr keys before child lookup')
                        keys.append(key)
                stack.append(('finish', mapping, keys, len(item), identity))
                if mapping:
                    for key in reversed(keys):
                        c.tick()
                        stack.append(('visit', item[key]))
                else:
                    for child in reversed(item):
                        c.tick()
                        stack.append(('visit', child))
        else:
            _, mapping, keys, count, identity = task
            children = values[-count:] if count else []
            if count:
                del values[-count:]
            if mapping:
                copied = {}
                for key, child in zip(keys, children):
                    c.tick()
                    copied[key] = child
                values.append(MappingProxyType(copied) if frozen else copied)
            else:
                values.append(tuple(children) if frozen else list(children))
            active.remove(identity)
    c.need(len(values) == 1, (), 'one complete copied value required')
    return values[0]


def _freeze(value, c, allow_bytes=False):
    return _copy(value, c, frozen=True, allow_bytes=allow_bytes)


def _plain(value, c, allow_bytes=False):
    return _copy(value, c, frozen=False, allow_bytes=allow_bytes)


def _equal(left, right, c):
    stack = [(left, right)]
    while stack:
        c.tick()
        a, b = stack.pop()
        ak, bk = type(a), type(b)
        aa, ba = ak is list or ak is tuple, bk is list or bk is tuple
        am, bm = ak is dict or ak is MappingProxyType, bk is dict or bk is MappingProxyType
        if aa or ba:
            if not (aa and ba and len(a) == len(b)):
                return False
            for index in range(len(a) - 1, -1, -1):
                c.tick()
                stack.append((a[index], b[index]))
        elif am or bm:
            if not (am and bm and len(a) == len(b)):
                return False
            for key in a:
                c.tick()
                if key not in b:
                    return False
                stack.append((a[key], b[key]))
        elif ak is not bk:
            return False
        elif ak is str or ak is bytes:
            if len(a) != len(b): return False
            for offset in range(0, len(a), 65536):
                c.tick()
                if a[offset:offset + 65536] != b[offset:offset + 65536]: return False
        elif a != b:
            return False
    return True


def _identity(raw, c):
    c.need(type(raw) is bytes, (), 'exact immutable original bytes required')
    digest = hashlib.sha256()
    for offset in range(0, len(raw), 65536):
        c.tick()
        digest.update(raw[offset:offset + 65536])
    c.tick()
    return dict(bytes=len(raw), sha256=digest.hexdigest())


def _canonical(key, c):
    value = _plain(key, c)
    c.tick()
    raw = json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True,
                     allow_nan=False).encode('ascii')
    c.tick()
    return raw, _identity(raw, c)['sha256']


def _modules(raw, c):
    _keys(raw, ('checker', 'builders', 'reference'), c, ('modules',))
    modules = {}
    for key, version in _MODULE_VERSIONS.items():
        c.tick()
        module = raw[key]
        actual_version = getattr(module, 'VERSION', None)
        c.need(type(actual_version) is str and actual_version == version,
               ('modules', key), 'original public namespace VERSION required')
        modules[key] = module
    return MappingProxyType(modules)


def _formula(tree, c, signature=None):
    """Full core syntax, rigid IDs; expanded occurrences checked individually."""
    stack = [('F', tree)]
    while stack:
        c.tick()
        sort, node = stack.pop()
        _array(node, c, ('formula',))
        c.need(bool(node) and type(node[0]) is str, ('formula',), 'core constructor required')
        tag = node[0]
        if sort == 'T' and tag == 'var':
            c.need(len(node) == 2 and _nat(node[1]), ('formula',), 'variable constructor')
        elif (sort == 'T' and tag == 'fun') or (sort == 'F' and tag == 'pred'):
            c.need(len(node) == 3 and _nat(node[1]), ('formula',), 'symbol constructor')
            args = _array(node[2], c, ('formula',))
            if signature is not None:
                arities = signature[0 if sort == 'T' else 1]
                c.need(node[1] < len(arities) and len(args) == arities[node[1]],
                       ('formula',), 'exact context signature/arity')
            for child in reversed(args):
                c.tick()
                stack.append(('T', child))
        elif sort == 'F' and tag == 'eq':
            c.need(len(node) == 3, ('formula',), 'equality constructor')
            stack.append(('T', node[2])); stack.append(('T', node[1]))
        elif sort == 'F' and tag == 'not':
            c.need(len(node) == 2, ('formula',), 'negation constructor')
            stack.append(('F', node[1]))
        elif sort == 'F' and tag == 'imp':
            c.need(len(node) == 3, ('formula',), 'implication constructor')
            stack.append(('F', node[2])); stack.append(('F', node[1]))
        elif sort == 'F' and tag == 'all':
            c.need(len(node) == 3 and _nat(node[1]), ('formula',), 'quantifier constructor')
            stack.append(('F', node[2]))
        else:
            c.fail('INVALID_INPUT', ('formula',), 'typed core Formula required')
    return tree


def _pattern(tree, count, c):
    stack = [tree]
    while stack:
        c.tick()
        node = stack.pop()
        _array(node, c, ('family', 'pattern'))
        c.need(bool(node) and type(node[0]) is str, ('family', 'pattern'), 'pattern constructor')
        if node[0] == 'param':
            c.need(len(node) == 2 and _nat(node[1]) and node[1] < count,
                   ('family', 'pattern'), 'declared Formula parameter')
        elif node[0] == 'not':
            c.need(len(node) == 2, ('family', 'pattern'), 'not pattern')
            stack.append(node[1])
        elif node[0] == 'imp':
            c.need(len(node) == 3, ('family', 'pattern'), 'imp pattern')
            stack.append(node[2]); stack.append(node[1])
        else:
            c.fail('INVALID_FAMILY', ('family', 'pattern'), 'only whole Formula parameters/not/imp')


def _logical(subtag, w):
    if subtag == 0:
        a, b = w
        return ('imp', a, ('imp', b, a))
    if subtag == 1:
        a, b, d = w
        return ('imp', ('imp', a, ('imp', b, d)), ('imp', ('imp', a, b), ('imp', a, d)))
    a, b = w
    return ('imp', ('imp', ('not', b), ('not', a)), ('imp', a, b))


def _bindings(raw, count, c, complete=True, signature=None):
    _array(raw, c, ('bindings',))
    found, previous = {}, -1
    for row in raw:
        _keys(row, ('parameter_id', 'formula'), c, ('bindings',))
        index = row['parameter_id']
        c.need(_nat(index) and previous < index < count, ('bindings',), 'ordered unique parameter IDs')
        previous = index
        found[index] = _formula(row['formula'], c, signature)
    c.need(not complete or len(found) == count, ('bindings',), 'complete Formula binding required')
    return found


def _substitute(pattern, images, c):
    stack, result = [('visit', pattern)], []
    while stack:
        c.tick()
        action, node = stack.pop()
        if action == 'visit':
            if node[0] == 'param':
                # Whole immutable image, never traversed for another parameter.
                result.append(images[node[1]])
            elif node[0] == 'not':
                stack.append(('not', None)); stack.append(('visit', node[1]))
            else:
                stack.append(('imp', None)); stack.append(('visit', node[2])); stack.append(('visit', node[1]))
        elif action == 'not':
            result.append(('not', result.pop()))
        else:
            right, left = result.pop(), result.pop()
            result.append(('imp', left, right))
    c.need(len(result) == 1, (), 'one complete substituted Formula')
    return result[0]


def _family(raw, c):
    family = _freeze(raw, c)
    _keys(family, _FAMILY_FIELDS, c, ('family',))
    params = _array(family['parameters'], c, ('family',))
    for index, row in enumerate(params):
        _keys(row, ('id', 'sort'), c, ('family', 'parameters'))
        c.need(type(row['id']) is int and row['id'] == index and row['sort'] == 'Formula',
               ('family', 'parameters'), 'contiguous Formula parameter IDs')
    nodes = _array(family['internal_nodes'], c, ('family',))
    boundary = _array(family['boundary_nodes'], c, ('family',))
    c.need(2 <= len(nodes) <= 8 and len(boundary) <= 4,
           ('family',), 'declared internal/boundary bounds', 'INVALID_FAMILY')
    c.need(type(family['root_local_id']) is int and family['root_local_id'] == len(nodes)-1
           and type(family['distinct_base_nodes']) is int and family['distinct_base_nodes'] == len(nodes)
           and family['size_band'] == ('SMALL_2_4' if len(nodes) <= 4 else 'LARGE_5_8'),
           ('family',), 'exact source-order root/node/size metadata', 'INVALID_FAMILY')
    traversal = []
    for index, row in enumerate(boundary):
        _keys(row, ('boundary_id', 'formula_pattern'), c, ('family', 'boundary'))
        c.need(type(row['boundary_id']) is int and row['boundary_id'] == index,
               ('family', 'boundary'), 'ordered distinct boundary IDs')
        _pattern(row['formula_pattern'], len(params), c)
        traversal.append(row['formula_pattern'])
    used_boundary = set()
    for index, row in enumerate(nodes):
        _keys(row, _NODE_FIELDS, c, ('family', 'nodes'))
        c.need(type(row['local_id']) is int and row['local_id'] == index,
               ('family', 'nodes'), 'ordered internal IDs')
        _pattern(row['formula_pattern'], len(params), c)
        traversal.append(row['formula_pattern'])
        refs = _array(row['references'], c, ('family', 'references'))
        for ref in refs:
            _keys(ref, ('kind', 'id'), c, ('family', 'reference'))
            c.need(type(ref['kind']) is str and ref['kind'] in ('internal', 'boundary') and _nat(ref['id']),
                   ('family', 'reference'), 'canonical typed reference')
            c.need(ref['id'] < (index if ref['kind'] == 'internal' else len(boundary)),
                   ('family', 'reference'), 'strict backward/internal or actual boundary reference')
            if ref['kind'] == 'boundary': used_boundary.add(ref['id'])
        if type(row['rule_tag']) is int and row['rule_tag'] == 1:
            c.need(type(row['subtag']) is int and 0 <= row['subtag'] <= 2 and not refs,
                   ('family', 'logical'), 'H1/H2/H3 only without row references')
            witness = _array(row['witness_pattern'], c, ('family', 'logical'))
            c.need(len(witness) == (3 if row['subtag'] == 1 else 2), ('family',), 'exact logical witness count')
            for pattern in witness:
                _pattern(pattern, len(params), c); traversal.append(pattern)
            c.need(_equal(row['formula_pattern'], _logical(row['subtag'], witness), c),
                   ('family',), 'exact primitive logical pattern equation', 'INVALID_FAMILY')
        else:
            c.need(type(row['rule_tag']) is int and row['rule_tag'] == 3
                   and row['subtag'] is None and row['witness_pattern'] is None and len(refs) == 2,
                   ('family',), 'MP authoritative ordered references and null witness pattern', 'INVALID_FAMILY')
            formulas = []
            for ref in refs:
                c.tick()
                formulas.append((nodes if ref['kind'] == 'internal' else boundary)[ref['id']]['formula_pattern'])
            c.need(_equal(formulas[1], ('imp', formulas[0], row['formula_pattern']), c),
                   ('family',), 'exact ordered MP pattern equation', 'INVALID_FAMILY')
    c.need(len(used_boundary) == len(boundary), ('family',), 'boundary ports are exactly referenced occurrences')
    seen, next_parameter = set(), 0
    for pattern in traversal:
        stack = [pattern]
        while stack:
            c.tick(); node = stack.pop()
            if node[0] == 'param':
                if node[1] not in seen:
                    c.need(node[1] == next_parameter, ('family',), 'first-occurrence parameter normalization')
                    seen.add(node[1]); next_parameter += 1
            elif node[0] == 'not':
                stack.append(node[1])
            else:
                stack.append(node[2]); stack.append(node[1])
    c.need(len(seen) == len(params), ('family',), 'no omitted/unused declared parameter')
    reachable, todo = set(), [len(nodes)-1]
    while todo:
        c.tick(); index = todo.pop()
        if index not in reachable:
            reachable.add(index)
            for ref in nodes[index]['references']:
                c.tick()
                if ref['kind'] == 'internal': todo.append(ref['id'])
    c.need(len(reachable) == len(nodes), ('family',), 'all selected nodes reach root', 'INVALID_FAMILY')
    key = family['family_key']
    _keys(key, ('parameters', 'root_local_id', 'internal_nodes', 'boundary_nodes'), c, ('family_key',))
    for name in ('parameters', 'root_local_id', 'internal_nodes', 'boundary_nodes'):
        c.need(_equal(key[name], family[name], c), ('family_key', name), 'complete structural key association')
    _, digest = _canonical(key, c)
    c.need(type(family['family_id']) is str and family['family_id'] == digest,
           ('family_id',), 'full key digest is display only; exact key still authoritative')
    occurrences = _array(family['source_occurrences'], c, ('family',))
    c.need(1 <= len(occurrences) <= 2, ('family',), 'one selected representative per donor/key')
    occurrence_labels = set()
    for occurrence in occurrences:
        _keys(occurrence, ('donor_id', 'root_source_row', 'source_to_local',
                           'boundary_source_to_port', 'source_bindings'), c, ('source_occurrences',))
        c.need(type(occurrence['donor_id']) is str and bool(occurrence['donor_id']),
               ('source_occurrences',), 'donor occurrence label')
        c.need(occurrence['donor_id'] not in occurrence_labels, ('source_occurrences',), 'distinct donor representatives')
        occurrence_labels.add(occurrence['donor_id'])
        mapped = []
        for name, count in (('source_to_local', len(nodes)), ('boundary_source_to_port', len(boundary))):
            vector = _array(occurrence[name], c, ('source_occurrences', name))
            c.need(len(vector) == count, ('source_occurrences',), 'complete ordered source map')
            values, previous = [], -1
            for index, pair in enumerate(vector):
                _array(pair, c, ('source_occurrences', name))
                c.need(len(pair) == 2 and _nat(pair[0]) and pair[0] > previous
                       and type(pair[1]) is int and pair[1] == index,
                       ('source_occurrences', name), 'strict source order and contiguous occurrence map')
                previous = pair[0]; values.append(pair[0])
            mapped.append(values)
        c.need(_nat(occurrence['root_source_row']) and occurrence['root_source_row'] == mapped[0][-1],
               ('source_occurrences',), 'root source/local association')
        c.need(not set(mapped[0]).intersection(mapped[1]), ('source_occurrences',), 'boundary identities outside selected set')
        for index, node in enumerate(nodes):
            for ref in node['references']:
                c.tick()
                source = mapped[0 if ref['kind'] == 'internal' else 1][ref['id']]
                c.need(source < mapped[0][index], ('source_occurrences',), 'source reference remains backward')
        _bindings(occurrence['source_bindings'], len(params), c)
    refs = _array(family['validation_provenance'], c, ('family',))
    previous = -1
    for ref in refs:
        c.need(_nat(ref) and previous < ref < 2, ('family',), 'ordered donor-validation index reference')
        previous = ref
    c.need(bool(refs), ('family',), 'donor validation reference required')
    return family


def _joined_span(subject, reference, limit, c, path):
    for span in (subject, reference):
        _array(span, c, path)
        c.need(len(span) == 2 and _nat(span[0]) and _nat(span[1])
               and span[0] < span[1] <= limit, path, 'original nonempty in-body byte span')
    c.need(_equal(subject, reference, c), path, 'identical original view byte spans', 'INVALID_INSTANCE')
    return subject


def _join_tree_view(tree, source, flat, limit, c, path):
    """Associate actual nested AST occurrences with the original flat layout."""
    _keys(flat, ('prefix_tokens', 'node_byte_spans'), c, path)
    tokens = _array(flat['prefix_tokens'], c, path)
    spans = _array(flat['node_byte_spans'], c, path)
    nodes = _array(source['nodes'], c, path)
    c.need(bool(tokens) and len(tokens) == len(spans) == len(nodes),
           path, 'complete matching original preorder node counts', 'INVALID_INSTANCE')
    c.need(type(source['kind']) is str and source['kind'] in ('formula', 'term'),
           path, 'original Formula or Term source map')
    outer = _joined_span(source['span'], spans[0], limit, c, path)
    todo, ordinal = [(source['kind'], tree, None, None)], 0
    while todo:
        c.tick()
        sort, node, parent, slot = todo.pop()
        _array(node, c, path)
        c.need(bool(node) and type(node[0]) is str and ordinal < len(tokens),
               path, 'complete typed AST occurrence for each flat token', 'INVALID_INSTANCE')
        tag, children = node[0], []
        if sort == 'term' and tag == 'var':
            c.need(len(node) == 2 and _nat(node[1]), path, 'rigid variable token')
            token, code, child_sort = ('var', node[1]), 0, 'term'
        elif (sort == 'term' and tag == 'fun') or (sort == 'formula' and tag == 'pred'):
            c.need(len(node) == 3 and _nat(node[1]), path, 'rigid symbol token')
            children = _array(node[2], c, path)
            token, code, child_sort = (tag, node[1], len(children)), (1 if tag == 'fun' else 0), 'term'
        elif sort == 'formula' and tag == 'all':
            c.need(len(node) == 3 and _nat(node[1]), path, 'rigid binder token')
            token, code, child_sort, children = ('all', node[1]), 4, 'formula', [node[2]]
        elif sort == 'formula' and tag == 'not':
            c.need(len(node) == 2, path, 'unary negation token')
            token, code, child_sort, children = ('not',), 2, 'formula', [node[1]]
        elif sort == 'formula' and (tag == 'eq' or tag == 'imp'):
            c.need(len(node) == 3, path, 'binary Formula token')
            token, code = (tag,), (1 if tag == 'eq' else 3)
            child_sort, children = ('term' if tag == 'eq' else 'formula'), [node[1], node[2]]
        else:
            c.fail('INVALID_INSTANCE', path, 'original typed AST token required')
        metadata = nodes[ordinal]
        c.need(type(metadata['kind']) is str and metadata['kind'] == sort
               and type(metadata['tag']) is int and metadata['tag'] == code,
               path, 'original source node sort/tag association', 'INVALID_INSTANCE')
        c.need(_equal(metadata['parent'], parent, c) and _equal(metadata['slot'], slot, c),
               path, 'original preorder parent/child-slot association', 'INVALID_INSTANCE')
        span = _joined_span(metadata['span'], spans[ordinal], limit, c, path)
        c.need(outer[0] <= span[0] < span[1] <= outer[1], path, 'node lies in original tree span')
        if parent is not None:
            parent_span = nodes[parent]['span']
            c.need(parent_span[0] < span[0] and span[1] <= parent_span[1],
                   path, 'child occurrence lies in original parent span')
        c.need(_equal(tokens[ordinal], token, c), path, 'exact independent preorder token', 'INVALID_INSTANCE')
        current = ordinal
        ordinal += 1
        for child in range(len(children) - 1, -1, -1):
            c.tick()
            todo.append((child_sort, children[child], current, child))
    c.need(ordinal == len(tokens), path, 'no omitted or extra independent tree occurrence', 'INVALID_INSTANCE')


def _join_witness_views(row, independent, limit, c, path):
    tag, subtag = row['rule_tag'], row['subtag']
    payload = _array(independent['payload'], c, path)
    witness = _array(row['witness'], c, path)
    fields = _array(row['witness_source'], c, path)
    c.need(_equal(independent['witness_tag'], subtag, c), path,
           'exact independent logical/theory witness tag', 'INVALID_INSTANCE')
    offset = 1 if tag == 1 or tag == 2 else 0
    c.need(len(fields) == len(witness) + offset and len(payload) == len(witness),
           path, 'complete ordered witness fields and payload', 'INVALID_INSTANCE')
    cursor = row['rule_source']['span'][1]
    if offset:
        field = fields[0]
        c.need(field['name'] == ('logical_tag' if tag == 1 else 'theory_witness_tag')
               and field['kind'] == 'natural', path, 'original witness tag field')
        span = _joined_span(field['span'], field['span'], limit, c, path)
        c.need(span[0] == cursor, path, 'contiguous original witness tag field')
        cursor = span[1]
    if tag == 0:
        specification = (('hypothesis_index', 'natural'),)
    elif tag == 1:
        specification = (
            (('A', 'formula'), ('B', 'formula')),
            (('A', 'formula'), ('B', 'formula'), ('C', 'formula')),
            (('A', 'formula'), ('B', 'formula')),
            (('A', 'formula'), ('x', 'natural'), ('t', 'term')),
            (('A', 'formula'), ('B', 'formula'), ('x', 'natural')),
            (('A', 'formula'), ('x', 'natural')),
            (('t', 'term'),),
            (('A', 'formula'), ('x', 'natural'), ('s', 'term'), ('t', 'term')))[subtag]
    elif tag == 2:
        specification = (('A', 'formula'), ('x', 'natural'), ('parameters', 'natural_vector')) if subtag == 2 else (('table_index', 'natural'),)
    elif tag == 3:
        specification = (('antecedent_row', 'natural'), ('implication_row', 'natural'))
    else:
        specification = (('source_row', 'natural'), ('variable_id', 'natural'))
    c.need(len(witness) == len(specification), path, 'original exact witness arity')
    for index, (name, kind) in enumerate(specification):
        c.tick()
        field, value, other = fields[index + offset], witness[index], payload[index]
        c.need(field['name'] == name and field['kind'] == kind, path, 'original ordered typed witness field')
        span = _joined_span(field['span'], field['span'], limit, c, path)
        c.need(span[0] == cursor, path, 'contiguous original witness payload span')
        if kind == 'formula' or kind == 'term':
            _join_tree_view(value, field, other, limit, c, path + (index,))
        elif kind == 'natural':
            c.need(_nat(value) and _nat(other) and value == other, path, 'exact independent natural witness', 'INVALID_INSTANCE')
        else:
            _array(value, c, path); _array(other, c, path)
            elements = _array(field['elements'], c, path)
            c.need(len(value) == len(other) == len(elements), path, 'complete ordered natural vector')
            previous = span[0]
            for number, alternate, element in zip(value, other, elements):
                c.need(_nat(number) and _nat(alternate) and number == alternate,
                       path, 'exact independent natural-vector payload', 'INVALID_INSTANCE')
                element_span = _joined_span(element['span'], element['span'], limit, c, path)
                c.need(element['name'] == 'element' and element['kind'] == 'natural'
                       and previous < element_span[0] and element_span[1] <= span[1],
                       path, 'ordered original natural-vector element spans')
                previous = element_span[0]
        cursor = span[1]
    c.need(cursor == row['span'][1], path, 'witness payload covers complete original row')


def _join_pair_views(subject, reference, query_bytes, certificate_bytes, c):
    """Explicit association only: neither view is reparsed or substituted."""
    query, alternate = subject['query'], reference['query']
    c.need(type(query['version']) is int and query['version'] == 1
           and _equal(query['claim_mode'], alternate['mode'], c)
           and _equal(query['theory_profile'], alternate['profile'], c)
           and _equal((query['function_arities'], query['predicate_arities']), alternate['signature'], c),
           ('query',), 'full independent original query header association', 'INVALID_INSTANCE')
    fields = _array(query['source_fields'], c, ('query',))
    c.need(len(fields) == 8, ('query',), 'original eight-field query source map')
    for name, other_name, position in (('finite_axioms', 'theory', 5), ('Gamma', 'hypotheses', 6)):
        left = _array(query[name], c, ('query', name))
        right = _array(alternate[other_name], c, ('query', name))
        c.need(len(left) == len(right), ('query', name), 'complete ordered independent query vector')
        if name == 'finite_axioms' and query['theory_profile'] != 0:
            c.need(not left and fields[position]['kind'] == 'empty', ('query', name), 'original empty nonfinite-profile payload')
            continue
        maps = _array(fields[position]['elements'], c, ('query', name))
        c.need(fields[position]['name'] == name and fields[position]['kind'] == 'formula_vector'
               and len(maps) == len(left), ('query', name), 'original query vector source maps')
        for index, (tree, source, flat) in enumerate(zip(left, maps, right)):
            c.tick()
            _join_tree_view(tree, source, flat, len(query_bytes), c, ('query', name, index))
    _join_tree_view(query['goal'], fields[7], alternate['goal'], len(query_bytes), c, ('query', 'goal'))
    previous_end = None
    for index, (row, independent) in enumerate(zip(subject['certificate']['rows'], reference['rows'])):
        c.tick()
        path = ('certificate', index)
        c.need(type(row['index']) is int and type(independent['index']) is int
               and row['index'] == independent['index'] == index
               and type(row['rule_tag']) is int and type(independent['rule_tag']) is int
               and row['rule_tag'] == independent['rule_tag'], path, 'identical physical row index and rule tag', 'INVALID_INSTANCE')
        span = _joined_span(row['span'], independent['byte_span'], len(certificate_bytes), c, path)
        c.need(previous_end is None or previous_end == span[0], path, 'contiguous original physical rows')
        _join_tree_view(row['formula'], row['formula_source'], independent['formula'], len(certificate_bytes), c, path + ('formula',))
        c.need(row['formula_source']['span'][0] == span[0]
               and row['formula_source']['span'][1] == row['rule_source']['span'][0]
               and row['rule_source']['name'] == 'rule_tag' and row['rule_source']['kind'] == 'natural',
               path, 'original formula then rule field association')
        rule_span = _joined_span(row['rule_source']['span'], row['rule_source']['span'], len(certificate_bytes), c, path)
        c.need(rule_span[1] <= span[1], path, 'original rule field lies inside physical row')
        _join_witness_views(row, independent, len(certificate_bytes), c, path + ('witness',))
        previous_end = span[1]
    c.need(previous_end == len(certificate_bytes), ('certificate',), 'last independent row reaches original certificate EOF')


def _validate_pair(query_bytes, certificate_bytes, modules, c):
    subject = c.helper(modules['checker'].check_certificate, query_bytes, certificate_bytes, check=c.tick)
    c.need(type(subject) is dict and subject.get('schema') == 'FPC-H1-finite-byte-check-receipt-v1'
           and subject.get('version') == _MODULE_VERSIONS['checker']
           and subject.get('no_prefix_authority') is True
           and subject.get('complete') is True and subject.get('accepted') is True
           and subject.get('syntax_complete') is True and subject.get('derivation_complete') is True
           and subject.get('final_goal_equal') is True and subject.get('status') == 'VALID_DERIVATION',
           (), 'full original subject proof required', 'INVALID_INSTANCE')
    c.need(subject['query']['EOF'] == len(query_bytes) and subject['certificate']['EOF'] == len(certificate_bytes),
           (), 'strict original subject query/certificate EOF')
    for key, raw in (('query', query_bytes), ('certificate', certificate_bytes)):
        c.need(_equal(subject['raw_inputs'][key], _identity(raw, c), c), (), 'identical original raw byte pair')
    reference = c.helper(modules['reference'].reference_check_certificate,
                         query_bytes, certificate_bytes, check=c.tick)
    c.need(type(reference) is dict and reference.get('schema') == _MODULE_VERSIONS['reference']
           and reference.get('complete_check') is True
           and reference.get('final_goal_equal') is True and reference.get('status') == 'VALID_DERIVATION',
           (), 'complete independent original proof required', 'INVALID_INSTANCE')
    count = subject['certificate']['row_count']
    c.need(_nat(count) and count > 0 and len(subject['certificate']['rows']) == count
           and len(reference['rows']) == count, (), 'full row count association')
    _join_pair_views(subject, reference, query_bytes, certificate_bytes, c)
    return _freeze(subject, c), _freeze(reference, c)


_TINY_LIMITS = {'symbols_per_sort': 4, 'axioms': 4, 'hypotheses': 4,
    'total_nodes': 256, 'depth': 32, 'natural': 65535, 'query_bytes': 4096}


def _match(pattern, formula, images, c):
    stack = [(pattern, formula)]
    while stack:
        c.tick()
        pat, actual = stack.pop()
        if pat[0] == 'param':
            index = pat[1]
            if index in images:
                if not _equal(images[index], actual, c): return False
            else:
                images[index] = actual
        elif type(actual) is not tuple or not actual or actual[0] != pat[0] or len(actual) != len(pat):
            return False
        elif pat[0] == 'not':
            stack.append((pat[1], actual[1]))
        else:
            stack.append((pat[2], actual[2])); stack.append((pat[1], actual[1]))
    return True


def match_receptor(family, *, input_formulas, output_formula, check):
    c = _Call(check)
    try:
        if not callable(check): c.fail('INVALID_INPUT', ('check',), 'genuine check callable required')
        c.tick()
        own = _family(family, c)
        inputs = _freeze(input_formulas, c)
        _array(inputs, c, ('input_formulas',))
        c.need(len(inputs) == len(own['boundary_nodes']), ('input_formulas',), 'exact ordered boundary input count')
        output = _freeze(output_formula, c)
        images, matched = {}, True
        for actual, boundary in zip(inputs, own['boundary_nodes']):
            _formula(actual, c)
            if not _match(boundary['formula_pattern'], actual, images, c):
                matched = False
        if output is not None:
            _formula(output, c)
            if not _match(own['internal_nodes'][own['root_local_id']]['formula_pattern'], output, images, c):
                matched = False
        if not matched:
            images = {}
        bindings, residual = [], []
        for parameter in own['parameters']:
            c.tick(); index = parameter['id']
            if index in images:
                bindings.append(dict(parameter_id=index, formula=images[index]))
            else:
                residual.append(parameter)
        answer = _plain(dict(matched=matched, bindings=bindings, residual_parameters=residual), c)
        c.tick()
        return answer
    except BaseException as error:
        c.abort(error)


def _tiny_scope(query, c):
    functions, predicates = query['function_arities'], query['predicate_arities']
    c.need(len(functions) <= 4 and len(predicates) <= 4 and len(query['Gamma']) <= 4,
           (), 'existing tiny encoder signature/context limit', 'UNSUPPORTED_SCOPE')
    for arity in functions:
        c.need(type(arity) is int and arity == 0, (), 'tiny nullary function scope', 'UNSUPPORTED_SCOPE')
    for arity in predicates:
        c.need(type(arity) is int and arity in (0, 1), (), 'tiny predicate scope', 'UNSUPPORTED_SCOPE')
    nodes = 0
    for formula in tuple(query['Gamma']) + (query['goal'],):
        stack = [(formula, 1)]
        while stack:
            c.tick(); node, depth = stack.pop(); nodes += 1
            c.need(nodes <= 256 and depth <= 32, (), 'existing tiny query syntax limits', 'UNSUPPORTED_SCOPE')
            tag = node[0]
            if tag == 'pred' or tag == 'fun':
                c.need(node[1] <= 65535, (), 'tiny natural limit', 'UNSUPPORTED_SCOPE')
                for child in reversed(node[2]):
                    c.tick(); stack.append((child, depth + 1))
            elif tag == 'var':
                c.need(node[1] <= 65535, (), 'tiny natural limit', 'UNSUPPORTED_SCOPE')
            elif tag == 'all':
                c.need(node[1] <= 65535, (), 'tiny natural limit', 'UNSUPPORTED_SCOPE')
                stack.append((node[2], depth + 1))
            elif tag == 'not':
                stack.append((node[1], depth + 1))
            else:
                stack.append((node[2], depth + 1)); stack.append((node[1], depth + 1))


def _wire_natural(value, output, c):
    c.need(_nat(value), (), 'strict wire natural')
    while value >= 128:
        c.tick(); output.append((value & 127) | 128); value >>= 7
    c.tick(); output.append(value)


def _wire_formula(tree, output, c):
    stack = [('F', tree)]
    while stack:
        c.tick(); sort, node = stack.pop(); tag = node[0]
        if sort == 'T':
            _wire_natural(0 if tag == 'var' else 1, output, c)
            _wire_natural(node[1], output, c)
            if tag == 'fun':
                _wire_natural(len(node[2]), output, c)
                for child in reversed(node[2]):
                    c.tick(); stack.append(('T', child))
        elif tag == 'pred':
            _wire_natural(0, output, c); _wire_natural(node[1], output, c)
            _wire_natural(len(node[2]), output, c)
            for child in reversed(node[2]):
                c.tick(); stack.append(('T', child))
        elif tag == 'eq':
            _wire_natural(1, output, c); stack.append(('T', node[2])); stack.append(('T', node[1]))
        elif tag == 'not':
            _wire_natural(2, output, c); stack.append(('F', node[1]))
        elif tag == 'imp':
            _wire_natural(3, output, c); stack.append(('F', node[2])); stack.append(('F', node[1]))
        else:
            _wire_natural(4, output, c); _wire_natural(node[1], output, c); stack.append(('F', node[2]))


def compile_instance(context_query_bytes, family, bindings, *, encoder, modules, check):
    c = _Call(check)
    try:
        if not callable(check): c.fail('INVALID_INPUT', ('check',), 'genuine check callable required')
        c.need(callable(encoder), ('encoder',), 'explicit tiny encoder callable required')
        owned_modules = _modules(modules, c)
        c.need(type(context_query_bytes) is bytes, (), 'original context query bytes')
        decoded = c.helper(owned_modules['checker'].decode_query, context_query_bytes, check=c.tick)
        c.need(type(decoded) is dict and type(decoded.get('EOF')) is int
               and decoded['EOF'] == len(context_query_bytes), (), 'complete original context EOF')
        context = _freeze({name: decoded[name] for name in _QUERY_FIELDS}, c)
        c.need(context['theory_profile'] == 0, (), 'existing finite-profile encoder only', 'UNSUPPORTED_SCOPE')
        own = _family(family, c)
        bound = _freeze(bindings, c)
        signature = (context['function_arities'], context['predicate_arities'])
        images = _bindings(bound, len(own['parameters']), c, signature=signature)
        rows, gamma = [], []
        for boundary in own['boundary_nodes']:
            c.tick(); index = boundary['boundary_id']
            formula = _substitute(boundary['formula_pattern'], images, c)
            _formula(formula, c, signature); gamma.append(formula)
            rows.append(dict(wire_index=len(rows), origin_kind='boundary', origin_id=index,
                formula=formula, rule_tag=0, subtag=None, witness=[index], references=[]))
        for node in own['internal_nodes']:
            c.tick(); index = node['local_id']
            formula = _substitute(node['formula_pattern'], images, c)
            _formula(formula, c, signature)
            refs = []
            for ref in node['references']:
                c.tick(); refs.append(ref['id'] if ref['kind'] == 'boundary' else len(gamma) + ref['id'])
            if node['rule_tag'] == 1:
                witness = []
                for pat in node['witness_pattern']:
                    c.tick(); witness.append(_substitute(pat, images, c))
                expected = c.helper(owned_modules['builders'].logical_axiom, node['subtag'], witness, check=c.tick)
                c.need(_equal(formula, _freeze(expected, c), c), (), 'original whole logical witness equation', 'INVALID_INSTANCE')
            else:
                witness = list(refs)
                c.need(_equal(rows[refs[1]]['formula'], ('imp', rows[refs[0]]['formula'], formula), c),
                       (), 'exact ordered actual MP equation', 'INVALID_INSTANCE')
            rows.append(dict(wire_index=len(rows), origin_kind='internal', origin_id=index,
                formula=formula, rule_tag=node['rule_tag'], subtag=node['subtag'], witness=witness, references=refs))
        query = dict(version=1, claim_mode=1, function_arities=context['function_arities'],
            predicate_arities=context['predicate_arities'], theory_profile=0, finite_axioms=[],
            Gamma=gamma, goal=rows[-1]['formula'])
        _tiny_scope(query, c)
        encoded = c.helper(encoder, _plain(query, c), check=c.tick)
        _keys(encoded, ('query_bytes', 'receipt'), c, ('encoder',))
        query_bytes, er = encoded['query_bytes'], encoded['receipt']
        c.need(type(query_bytes) is bytes and bool(query_bytes), (), 'original encoder query byte body')
        _keys(er, ('schema', 'version', 'complete', 'semantic_query', 'query_identity', 'limits', 'expanded_nodes', 'scope'), c, ('encoder',))
        c.need(er['schema'] == 'independent-tiny-FPC-query-encoding-v1'
               and er['version'] == 'L-tiny-FPC-query-encoder-v1' and er['complete'] is True
               and _nat(er['expanded_nodes']) and er['expanded_nodes'] <= 256
               and type(er['scope']) is str and _equal(er['limits'], _TINY_LIMITS, c)
               and _equal(er['semantic_query'], query, c)
               and _equal(er['query_identity'], _identity(query_bytes, c), c), (), 'complete declared encoder association')
        output = bytearray(b'FPP1')
        _wire_natural(len(rows), output, c)
        for row in rows:
            c.tick(); _wire_formula(row['formula'], output, c); _wire_natural(row['rule_tag'], output, c)
            if row['rule_tag'] == 1:
                _wire_natural(row['subtag'], output, c)
                for formula in row['witness']:
                    _wire_formula(formula, output, c)
            else:
                for number in row['witness']:
                    _wire_natural(number, output, c)
        c.tick(); certificate_bytes = bytes(output); c.tick()
        subject, reference = _validate_pair(query_bytes, certificate_bytes, owned_modules, c)
        for name in _QUERY_FIELDS:
            c.need(_equal(subject['query'][name], query[name], c), (), 'full fresh boundary query association')
        c.need(subject['certificate']['row_count'] == len(rows), (), 'no wire identity contraction')
        for expected, actual, independent in zip(rows, subject['certificate']['rows'], reference['rows']):
            c.tick()
            for key in ('formula', 'rule_tag', 'subtag', 'witness'):
                c.need(_equal(expected[key], actual[key], c), (), 'every physical row/witness matches complete original subject view')
            c.need(actual['index'] == expected['wire_index'] == independent['index'],
                   (), 'exact physical occurrence index in both original views')
            if expected['rule_tag'] == 3:
                c.need(_equal(expected['references'], independent['payload'], c),
                       (), 'ordered emitted MP references match independent payload')
        context_identity = _plain(context, c)
        context_identity.update(_identity(context_query_bytes, c)); context_identity['query_hex'] = context_query_bytes.hex()
        mapping = dict(boundary_to_wire=[], internal_to_wire=[])
        for index in range(len(gamma)):
            c.tick()
            c.need(rows[index]['origin_kind'] == 'boundary' and rows[index]['origin_id'] == index
                   and subject['certificate']['rows'][index]['index'] == reference['rows'][index]['index'] == index,
                   (), 'boundary port map joins the same physical occurrence in both views')
            mapping['boundary_to_wire'].append([index, index])
        for index in range(len(own['internal_nodes'])):
            c.tick()
            wire_index = len(gamma) + index
            c.need(rows[wire_index]['origin_kind'] == 'internal' and rows[wire_index]['origin_id'] == index
                   and subject['certificate']['rows'][wire_index]['index'] == reference['rows'][wire_index]['index'] == wire_index,
                   (), 'internal node map joins the same physical occurrence in both views')
            mapping['internal_to_wire'].append([index, wire_index])
        result = dict(schema='FPC-receptor-instance-candidate-v1', complete=True, accepted=False,
            context_query_identity=context_identity, binding=bound, expansion_rows=rows,
            family_to_wire_rows=mapping, boundary_query_bytes=query_bytes,
            boundary_certificate_bytes=certificate_bytes, subject_receipt=subject, reference_receipt=reference)
        answer = _plain(result, c, allow_bytes=True)
        result = subject = reference = rows = own = decoded = context = bound = images = None
        gamma = mapping = encoded = er = query = output = None
        c.tick()
        return answer
    except BaseException as error:
        c.abort(error)
