"""FPC-H1 ordinary symbolic obligation producer. SOURCE ONLY, not executed.

No target identities, supplied derivations or old state enter search. A found
certificate needs the two external complete validators. The module namespaces,
input objects and exclusive progress owner must stay unchanged during a call.
"""
from collections import deque
import hashlib
import json

VERSION = "FPC-H1-CONTEXTUAL-LIBRARY-PRODUCER-v1"
BASE_VERSION = "FPC-H1-OBLIGATION-PRODUCER-v2"
_SEARCH_SCHEMA = "FPC-H1-obligation-search-receipt-v1"
_SORTS = (("F", "F"), ("F", "F", "F"), ("F", "F"),
          ("F", "V", "T"), ("F", "F", "V"), ("F", "V"),
          ("T",), ("F", "V", "T", "T"), ("F", "V"))
_OWNER = object()


class ProducerInputError(ValueError):
    """Only a privately marked current-call refusal is an owned refusal."""


def is_owned_error(error):
    return type(error) is ProducerInputError and getattr(error, "_owner", None) is _OWNER


class _Call:
    def __init__(self, check):
        if not callable(check):
            raise TypeError("check must be callable")
        self.check, self.first, self.calls = check, None, 0
        self.token = object()

    def tick(self):
        if self.first is not None:
            raise self.first
        try:
            self.check()
        except BaseException as error:
            self.first = error
            raise
        self.calls += 1

    def fault(self):
        if self.first is not None:
            raise self.first

    def need(self, condition, reason):
        self.fault()
        if not condition:
            error = ProducerInputError(reason)
            error._owner, error._call = _OWNER, self.token
            raise error

    def helper(self, module, function, *args):
        """A direct pinned helper guard, never class-only callback handling."""
        self.tick()
        try:
            value = function(*args, check=self.tick)
        except BaseException as error:
            self.fault()
            expected = getattr(module, "InvalidWitness", None)
            if expected is not None and type(error) is expected:
                return False, str(error)
            raise
        self.fault()
        return True, value


def _nat(value):
    return type(value) is int and value >= 0


def _keys(value, keys, call, reason):
    call.tick()
    call.need(type(value) is dict and len(value) == len(keys), reason)
    for key in keys:
        call.tick()
        call.need(key in value, reason)


def _hash_raw(raw, call):
    h = hashlib.sha256()
    view = memoryview(raw)
    for start in range(0, len(raw), 65536):
        call.tick()
        h.update(view[start:start + 65536])
    call.tick()
    return h.hexdigest()


def _copy(value, call):
    """Checked ordinary-data copy; no caller subclasses or shared output trees."""
    pending, values = [("visit", value)], []
    while pending:
        call.tick()
        kind, item = pending.pop()
        if kind == "list":
            n = item
            children = values[-n:] if n else []
            if n:
                del values[-n:]
            values.append(children)
        elif kind == "dict":
            names = item
            children = values[-len(names):] if names else []
            if names:
                del values[-len(names):]
            result = {}
            for name, child in zip(names, children):
                call.tick()
                result[name] = child
            values.append(result)
        elif type(item) in (list, tuple):
            pending.append(("list", len(item)))
            for child in reversed(item):
                call.tick()
                pending.append(("visit", child))
        elif type(item) is dict:
            names = []
            for name in item:
                call.tick()
                call.need(type(name) is str, "ordinary dictionary key")
                names.append(name)
            pending.append(("dict", names))
            for name in reversed(names):
                call.tick()
                pending.append(("visit", item[name]))
        else:
            call.need(item is None or type(item) in (str, int, bool, float), "ordinary scalar")
            values.append(item)
    return values[0]


class _Arena:
    def __init__(self, functions, predicates, call):
        self.functions, self.predicates, self.c = functions, predicates, call
        self.rows, self.keys, self.meta, self.mirror = [], {}, [], None

    def add(self, sort, tag, symbol, children):
        self.c.tick()
        kids = []
        for child in children:
            self.c.tick()
            self.c.need(_nat(child) and child < len(self.rows), "AST child")
            kids.append(child)
        children = tuple(kids)
        self.c.need(type(sort) is str and sort in ("T", "F") and type(tag) is str, "AST sort/tag")
        if sort == "T" and tag == "var":
            self.c.need(_nat(symbol) and not children, "variable AST")
        elif sort == "T" and tag == "fun":
            self.c.need(_nat(symbol) and symbol < len(self.functions) and
                        len(children) == self.functions[symbol], "function AST")
            for child in children:
                self.c.tick()
                self.c.need(self.rows[child][0] == "T", "function child sort")
        elif sort == "F" and tag == "pred":
            self.c.need(_nat(symbol) and symbol < len(self.predicates) and
                        len(children) == self.predicates[symbol], "predicate AST")
            for child in children:
                self.c.tick()
                self.c.need(self.rows[child][0] == "T", "predicate child sort")
        else:
            counts = {"eq": 2, "not": 1, "imp": 2, "all": 1}
            self.c.need(sort == "F" and tag in counts and len(children) == counts[tag], "formula AST")
            expected = "T" if tag == "eq" else "F"
            for child in children:
                self.c.tick()
                self.c.need(self.rows[child][0] == expected, "formula child sort")
            self.c.need(_nat(symbol) if tag == "all" else symbol is None, "formula symbol")
        key = (sort, tag, symbol, children)
        if key in self.keys:
            return self.keys[key]
        count, depth, variables, free = 1, 0, set(), set()
        for child in children:
            self.c.tick()
            info = self.meta[child]
            count += info["nodes"]
            for variable in info["variables"]:
                self.c.tick()
                variables.add(variable)
            for variable in info["FV"]:
                self.c.tick()
                free.add(variable)
            depth = max(depth, info["term_depth"])
        if tag == "var":
            variables.add(symbol)
            free.add(symbol)
        elif tag == "fun" and children:
            depth += 1
        elif tag == "all":
            variables.add(symbol)
            free.discard(symbol)
        number = len(self.rows)
        self.rows.append(key)
        self.keys[key] = number
        self.meta.append({"nodes": count, "term_depth": depth,
                          "variables": frozenset(variables), "FV": frozenset(free)})
        if self.mirror is not None:
            self.mirror.append({"id": number, "sort": sort, "tag": tag,
                                "symbol": symbol, "children": list(children)})
        return number

    def tree(self, root):
        pending, values = [(False, root)], []
        while pending:
            self.c.tick()
            built, number = pending.pop()
            sort, tag, symbol, children = self.rows[number]
            if not built:
                pending.append((True, number))
                for child in reversed(children):
                    self.c.tick()
                    pending.append((False, child))
                continue
            n = len(children)
            args = values[-n:] if n else []
            if n:
                del values[-n:]
            if tag == "var":
                value = [tag, symbol]
            elif tag in ("fun", "pred"):
                value = [tag, symbol, args]
            elif tag == "all":
                value = [tag, symbol, args[0]]
            else:
                value = [tag] + args
            values.append(value)
        return values[0]

    def load(self, value, sort="F"):
        pending, values = [(False, sort, value)], []
        while pending:
            self.c.tick()
            built, kind, node = pending.pop()
            if built:
                tag, symbol, n = node
                children = values[-n:] if n else []
                if n:
                    del values[-n:]
                values.append(self.add(kind, tag, symbol, children))
                continue
            self.c.need(type(node) in (list, tuple) and bool(node), "core AST carrier")
            tag = node[0]
            if kind == "T" and tag == "var":
                self.c.need(len(node) == 2, "variable shape")
                values.append(self.add("T", tag, node[1], ()))
                continue
            if tag in ("fun", "pred"):
                self.c.need(len(node) == 3 and type(node[2]) in (list, tuple), "application shape")
                symbol, children, child_sort = node[1], node[2], "T"
            elif tag == "all":
                self.c.need(kind == "F" and len(node) == 3, "ALL shape")
                symbol, children, child_sort = node[1], (node[2],), "F"
            else:
                self.c.need(kind == "F" and tag in ("eq", "not", "imp"), "core tag")
                self.c.need(len(node) == (2 if tag == "not" else 3), "connective shape")
                symbol, children = None, node[1:]
                child_sort = "T" if tag == "eq" else "F"
            pending.append((True, kind, (tag, symbol, len(children))))
            for child in reversed(children):
                self.c.tick()
                pending.append((False, child_sort, child))
        return values[0]

    def records(self):
        result = []
        for number, (sort, tag, symbol, children) in enumerate(self.rows):
            self.c.tick()
            result.append({"id": number, "sort": sort, "tag": tag,
                           "symbol": symbol, "children": list(children)})
        return result


class _Query:
    def __init__(self, raw, modules, call):
        call.need(type(raw) is bytes, "query must be immutable bytes")
        _keys(modules, ("checker", "builders"), call, "module roles")
        self.c, self.modules, self.raw = call, modules, raw
        ok, q = call.helper(modules["checker"], modules["checker"].decode_query, raw)
        call.need(ok, "malformed query: " + str(q) if not ok else "query")
        self.decoded = q
        self.a = _Arena(tuple(q["function_arities"]), tuple(q["predicate_arities"]), call)
        self.gamma = [self.a.load(x) for x in q["Gamma"]]
        self.goal = self.a.load(q["goal"])
        self.profile = q["theory_profile"]
        table = q["finite_axioms"] if self.profile == 0 else (
            modules["builders"].PA_AXIOMS if self.profile == 1 else modules["builders"].INCIDENCE_AXIOMS)
        self.table = []
        for formula in table:
            call.tick()
            self.table.append(self.a.load(formula))
        self.pin = {"bytes": len(raw), "sha256": _hash_raw(raw, call)}
        call.tick()

    def logical(self, tag, witness):
        args = []
        self.c.need(_nat(tag) and tag < 8 and len(witness) == len(_SORTS[tag]), "logical payload")
        for sort, value in witness:
            self.c.tick()
            args.append(value if sort == "V" else self.a.tree(value))
        builder = self.modules["builders"]
        ok, value = self.c.helper(builder, builder.logical_axiom, tag, args)
        return (True, self.a.load(value)) if ok else (False, value)

    def induction(self, formula, variable, parameters):
        builder = self.modules["builders"]
        ok, value = self.c.helper(builder, builder.pa_induction,
                                 self.a.tree(formula), variable, list(parameters))
        return (True, self.a.load(value)) if ok else (False, value)


def _uleb(value, out, call):
    call.need(_nat(value), "wire natural")
    while True:
        call.tick()
        digit = value & 127
        value >>= 7
        out.append(digit | (128 if value else 0))
        if not value:
            return


def _encode_ast(arena, root, out, call):
    pending = [root]
    while pending:
        call.tick()
        number = pending.pop()
        sort, tag, symbol, children = arena.rows[number]
        _uleb(({"var": 0, "fun": 1} if sort == "T" else
               {"pred": 0, "eq": 1, "not": 2, "imp": 3, "all": 4})[tag], out, call)
        if tag in ("var", "fun", "pred", "all"):
            _uleb(symbol, out, call)
        if tag in ("fun", "pred"):
            _uleb(len(children), out, call)
        for child in reversed(children):
            call.tick()
            pending.append(child)


def _witness_records(witness):
    return [{"sort": sort, "value" if sort == "V" else "id": value}
            for sort, value in witness]


class _Primitive:
    def __init__(self, q, contexts):
        self.q, self.a, self.c, self.contexts = q, q.a, q.c, contexts
        self.rows, self.keys = [], {}
        self.discharges = []

    def add(self, context, formula, rule, subtag, witness, premises, origin):
        self.c.tick()
        premises = tuple(premises)
        for ref in premises:
            self.c.tick()
            self.c.need(_nat(ref) and ref < len(self.rows) and
                        self.rows[ref]["context"] == context, "primitive context/reference")
        key = (context, formula, rule, subtag, witness, premises)
        if key in self.keys:
            return self.keys[key]
        number = len(self.rows)
        self.keys[key] = number
        self.rows.append({"id": number, "context": context, "formula": formula,
                          "rule_tag": rule, "subtag": subtag, "witness": witness,
                          "premises": premises, "origins": [origin]})
        return number

    def ax(self, context, tag, witness, origin):
        ok, formula = self.q.logical(tag, witness)
        self.c.need(ok, "logical guard: " + str(formula))
        return self.add(context, formula, 1, tag, tuple(witness), (), origin)

    def mp(self, context, antecedent, implication, origin):
        a, i = self.rows[antecedent], self.rows[implication]
        sort, tag, _, children = self.a.rows[i["formula"]]
        self.c.need(tag == "imp" and children[0] == a["formula"], "MP formula")
        return self.add(context, children[1], 3, None, (), (antecedent, implication), origin)

    def gen(self, context, source, variable, origin):
        for formula in self.contexts[context]["gamma"]:
            self.c.tick()
            self.c.need(variable not in self.a.meta[formula]["FV"], "GEN full-context guard")
        result = self.a.add("F", "all", variable, (self.rows[source]["formula"],))
        return self.add(context, result, 4, None, variable, (source,), origin)

    def postorder(self, root):
        result, done, pending = [], set(), [(root, False)]
        while pending:
            self.c.tick()
            number, ready = pending.pop()
            if number in done:
                continue
            if not ready:
                pending.append((number, True))
                for child in reversed(self.rows[number]["premises"]):
                    self.c.tick()
                    pending.append((child, False))
            else:
                done.add(number)
                result.append(number)
        return result

    def deduce(self, root, child_context, parent_context, assumption, intro_node):
        mapping, records, guards = {}, [], []
        last_index = len(self.contexts[child_context]["gamma"]) - 1
        self.c.need(self.contexts[child_context]["gamma"] ==
                    self.contexts[parent_context]["gamma"] + [assumption], "discharge context")
        for source in self.postorder(root):
            self.c.tick()
            row = self.rows[source]
            self.c.need(row["context"] == child_context, "discharge primitive scope")
            C, rule = row["formula"], row["rule_tag"]
            origin = {"plan_node": intro_node, "compiler_case": "", "input_primitive_id": source}
            if rule == 0 and row["witness"] == last_index:
                case = "DISCHARGED_HYP"
                origin["compiler_case"] = case
                AA = self.a.add("F", "imp", None, (assumption, assumption))
                one = self.ax(parent_context, 0, (("F", assumption), ("F", AA)), origin)
                two = self.ax(parent_context, 0, (("F", assumption), ("F", assumption)), origin)
                three = self.ax(parent_context, 1, (("F", assumption), ("F", AA), ("F", assumption)), origin)
                result = self.mp(parent_context, two, self.mp(parent_context, one, three, origin), origin)
            elif rule in (0, 1, 2):
                case = "LIFT_HYP_OR_AXIOM"
                origin["compiler_case"] = case
                original = self.add(parent_context, C, rule, row["subtag"], row["witness"], (), origin)
                lifted = self.ax(parent_context, 0, (("F", C), ("F", assumption)), origin)
                result = self.mp(parent_context, original, lifted, origin)
            elif rule == 3:
                case = "LIFT_MP"
                origin["compiler_case"] = case
                left, right = row["premises"]
                D = self.rows[left]["formula"]
                h2 = self.ax(parent_context, 1, (("F", assumption), ("F", D), ("F", C)), origin)
                result = self.mp(parent_context, mapping[left],
                                 self.mp(parent_context, mapping[right], h2, origin), origin)
            else:
                self.c.need(rule == 4, "primitive tag in discharge")
                case = "LIFT_GEN"
                origin["compiler_case"] = case
                variable, premise = row["witness"], row["premises"][0]
                FV = []
                for formula in self.contexts[child_context]["gamma"]:
                    self.c.tick()
                    vector = sorted(self.a.meta[formula]["FV"])
                    FV.append(vector)
                    self.c.need(variable not in vector, "GEN discharge full premise context")
                guards.append({"input_primitive": source, "variable": variable,
                               "full_hypothesis_FV": FV, "permitted": True})
                D = self.rows[premise]["formula"]
                generalized = self.gen(parent_context, mapping[premise], variable, origin)
                q2 = self.ax(parent_context, 4, (("F", assumption), ("F", D), ("V", variable)), origin)
                DE = self.mp(parent_context, generalized, q2, origin)
                AD = self.ax(parent_context, 5, (("F", assumption), ("V", variable)), origin)
                de_formula = self.rows[DE]["formula"]
                D1, E1 = self.a.rows[de_formula][3]
                h1 = self.ax(parent_context, 0, (("F", de_formula), ("F", assumption)), origin)
                ADE = self.mp(parent_context, DE, h1, origin)
                h2 = self.ax(parent_context, 1, (("F", assumption), ("F", D1), ("F", E1)), origin)
                result = self.mp(parent_context, AD, self.mp(parent_context, ADE, h2, origin), origin)
            mapping[source] = result
            records.append({"input_primitive": source, "output_primitive": result, "case": case})
        self.discharges.append({"intro_node": intro_node, "child_context": child_context,
                               "parent_context": parent_context, "discharged_hypothesis_index": last_index,
                               "mapping": records, "GEN_guards": guards})
        return mapping[root]

    def payload(self, row):
        rule, subtag, value = row["rule_tag"], row["subtag"], row["witness"]
        if rule == 0:
            return {"index": value}
        if rule == 1:
            return {"tag": subtag, "witness": _witness_records(value)}
        if rule == 2:
            if subtag == 2:
                formula, variable, parameters = value
                return {"tag": 2, "formula": formula, "variable": variable, "parameters": list(parameters)}
            return {"tag": subtag, "index": value}
        return {"variable": value} if rule == 4 else {}

    def export(self, root):
        order, remap, rows, out = self.postorder(root), {}, [], bytearray(b"FPP1")
        _uleb(len(order), out, self.c)
        for number, old in enumerate(order):
            self.c.tick()
            row = self.rows[old]
            self.c.need(row["context"] == 0, "local hypothesis leaked into root certificate")
            refs = [remap[x] for x in row["premises"]]
            _encode_ast(self.a, row["formula"], out, self.c)
            rule, subtag, value = row["rule_tag"], row["subtag"], row["witness"]
            _uleb(rule, out, self.c)
            if rule == 0:
                _uleb(value, out, self.c)
                wire_witness = value
            elif rule == 1:
                _uleb(subtag, out, self.c)
                wire_witness = []
                for kind, item in value:
                    self.c.tick()
                    if kind == "V":
                        _uleb(item, out, self.c)
                        wire_witness.append(item)
                    else:
                        _encode_ast(self.a, item, out, self.c)
                        wire_witness.append(self.a.tree(item))
            elif rule == 2:
                _uleb(subtag, out, self.c)
                if subtag == 2:
                    formula, variable, parameters = value
                    _encode_ast(self.a, formula, out, self.c)
                    _uleb(variable, out, self.c)
                    _uleb(len(parameters), out, self.c)
                    for x in parameters:
                        _uleb(x, out, self.c)
                    wire_witness = [self.a.tree(formula), variable, list(parameters)]
                else:
                    _uleb(value, out, self.c)
                    wire_witness = value
            elif rule == 3:
                for ref in refs:
                    _uleb(ref, out, self.c)
                wire_witness = None
            else:
                _uleb(refs[0], out, self.c)
                _uleb(value, out, self.c)
                wire_witness = value
            remap[old] = number
            rows.append({"index": number, "formula": self.a.tree(row["formula"]),
                         "rule_tag": rule, "subtag": subtag, "witness": wire_witness,
                         "references": refs, "primitive": old})
        self.c.need(self.rows[root]["formula"] == self.q.goal, "compiled final goal")
        self.c.tick()
        return bytes(out), rows, [{"primitive": x, "row": remap[x]} for x in order]


def _digest(value, call):
    h = hashlib.sha256()
    for part in json.JSONEncoder(sort_keys=True, separators=(",", ":"), ensure_ascii=True).iterencode(value):
        call.tick()
        h.update(part.encode("ascii"))
    return h.hexdigest()


def _load_plan(q, plan):
    c, a = q.c, q.a
    _keys(plan, ("schema", "arena", "contexts", "nodes", "root"), c, "plan keys")
    c.need(plan["schema"] == "FPC-H1-obligation-plan-v1", "plan schema")
    c.need(type(plan["arena"]) is list and type(plan["contexts"]) is list and
           type(plan["nodes"]) is list, "plan arrays")
    ids, unique = [], set()
    for i, row in enumerate(plan["arena"]):
        _keys(row, ("id", "sort", "tag", "symbol", "children"), c, "arena row keys")
        c.need(type(row["id"]) is int and row["id"] == i and type(row["children"]) is list, "arena index")
        children = []
        for ref in row["children"]:
            c.tick()
            c.need(_nat(ref) and ref < i, "arena backward child")
            children.append(ids[ref])
        number = a.add(row["sort"], row["tag"], row["symbol"], children)
        c.need(number not in unique, "noncanonical duplicate arena row")
        unique.add(number)
        ids.append(number)
    def formula(ref):
        c.need(_nat(ref) and ref < len(ids) and a.rows[ids[ref]][0] == "F", "formula arena reference")
        return ids[ref]
    contexts = []
    for i, row in enumerate(plan["contexts"]):
        _keys(row, ("id", "parent", "opener", "assumption"), c, "context keys")
        c.need(type(row["id"]) is int and row["id"] == i, "context ID")
        if i == 0:
            c.need(row["parent"] is None and row["opener"] is None and row["assumption"] is None, "root context")
            context = {"id": 0, "parent": None, "opener": None, "assumption": None, "gamma": list(q.gamma)}
        else:
            c.need(_nat(row["parent"]) and row["parent"] < i and _nat(row["opener"]), "local context ancestry")
            value = formula(row["assumption"])
            context = {"id": i, "parent": row["parent"], "opener": row["opener"],
                       "assumption": value, "gamma": contexts[row["parent"]]["gamma"] + [value]}
        contexts.append(context)
    c.need(bool(contexts), "missing root context")
    nodes = []
    for i, row in enumerate(plan["nodes"]):
        _keys(row, ("id", "context", "formula", "operator", "premises", "payload"), c, "plan node keys")
        c.need(type(row["id"]) is int and row["id"] == i and _nat(row["context"]) and
               row["context"] < len(contexts) and type(row["premises"]) is list, "plan node index")
        refs = []
        for ref in row["premises"]:
            c.tick()
            c.need(_nat(ref) and ref < i, "plan backward premise")
            refs.append(ref)
        operator, payload = row["operator"], row["payload"]
        c.need(operator in ("HYP", "LOGICAL_AXIOM", "THEORY_AXIOM", "MP", "GEN", "INTRO"), "plan operator")
        if operator == "HYP":
            _keys(payload, ("index",), c, "HYP payload")
            c.need(_nat(payload["index"]) and not refs, "HYP index/premises")
            data = payload["index"]
        elif operator == "LOGICAL_AXIOM":
            _keys(payload, ("tag", "witness"), c, "logical payload keys")
            tag = payload["tag"]
            c.need(_nat(tag) and tag < 8 and type(payload["witness"]) is list and
                   len(payload["witness"]) == len(_SORTS[tag]) and not refs, "logical witness arity")
            data = []
            for kind, item in zip(_SORTS[tag], payload["witness"]):
                _keys(item, ("sort", "value" if kind == "V" else "id"), c, "typed witness keys")
                c.need(item["sort"] == kind, "typed witness sort")
                if kind == "V":
                    c.need(_nat(item["value"]), "witness variable")
                    value = item["value"]
                else:
                    ref = item["id"]
                    c.need(_nat(ref) and ref < len(ids) and a.rows[ids[ref]][0] == kind, "witness arena sort")
                    value = ids[ref]
                data.append((kind, value))
            data = (tag, tuple(data))
        elif operator == "THEORY_AXIOM":
            c.need(type(payload) is dict and _nat(payload.get("tag")) and not refs, "theory payload")
            tag = payload["tag"]
            if tag == 2:
                _keys(payload, ("tag", "formula", "variable", "parameters"), c, "induction payload")
                c.need(_nat(payload["variable"]) and type(payload["parameters"]) is list, "induction variables")
                parameters = []
                for x in payload["parameters"]:
                    c.tick()
                    c.need(_nat(x), "induction parameter natural")
                    parameters.append(x)
                data = (2, (formula(payload["formula"]), payload["variable"], tuple(parameters)))
            else:
                _keys(payload, ("tag", "index"), c, "table payload")
                c.need(tag in (0, 1, 3) and _nat(payload["index"]), "table index")
                data = (tag, payload["index"])
        elif operator == "MP":
            _keys(payload, (), c, "MP payload")
            c.need(len(refs) == 2, "MP premise arity")
            data = None
        elif operator == "GEN":
            _keys(payload, ("variable",), c, "GEN payload")
            c.need(_nat(payload["variable"]) and len(refs) == 1, "GEN variable/premise")
            data = payload["variable"]
        else:
            _keys(payload, ("child_context",), c, "INTRO payload")
            c.need(_nat(payload["child_context"]) and payload["child_context"] < len(contexts) and
                   len(refs) == 1, "INTRO child context")
            data = payload["child_context"]
        nodes.append({"id": i, "context": row["context"], "formula": formula(row["formula"]),
                      "operator": operator, "premises": refs, "data": data})
    root = plan["root"]
    c.need(_nat(root) and root < len(nodes), "plan root")
    c.need(nodes[root]["context"] == 0 and nodes[root]["formula"] == q.goal, "root context/goal")
    seen, pending = set(), [root]
    while pending:
        c.tick()
        i = pending.pop()
        if i not in seen:
            seen.add(i)
            for ref in nodes[i]["premises"]:
                c.tick()
                pending.append(ref)
    c.need(len(seen) == len(nodes), "unreachable plan node")
    used_contexts = {0}
    owners = set()
    for i, context in enumerate(contexts[1:], 1):
        c.tick()
        owner = context["opener"]
        c.need(owner < len(nodes) and owner not in owners, "context opener")
        owners.add(owner)
        row = nodes[owner]
        c.need(row["operator"] == "INTRO" and row["data"] == i and
               row["context"] == context["parent"], "context ownership")
        child = nodes[row["premises"][0]]
        c.need(child["context"] == i and row["formula"] == a.add("F", "imp", None,
               (context["assumption"], child["formula"])), "INTRO exact implication")
    for row in nodes:
        c.tick()
        used_contexts.add(row["context"])
        if row["operator"] == "INTRO":
            c.need(row["data"] > 0, "INTRO nonroot child context")
            context = contexts[row["data"]]
            c.need(context["opener"] == row["id"] and context["parent"] == row["context"],
                   "INTRO reciprocal ownership")
            child = nodes[row["premises"][0]]
            c.need(child["context"] == row["data"] and row["formula"] == a.add("F", "imp", None,
                   (context["assumption"], child["formula"])), "INTRO reciprocal implication")
        else:
            for ref in row["premises"]:
                c.tick()
                c.need(nodes[ref]["context"] == row["context"], "cross-context premise")
    c.need(len(used_contexts) == len(contexts), "unused context")
    return contexts, nodes, root


def _compile(q, plan):
    c, a = q.c, q.a
    contexts, nodes, root = _load_plan(q, plan)
    proof, outputs = _Primitive(q, contexts), []
    for node in nodes:
        c.tick()
        number, context, f = node["id"], node["context"], node["formula"]
        op, data = node["operator"], node["data"]
        origin = {"plan_node": number, "compiler_case": "DIRECT_" + op, "input_primitive_id": None}
        if op == "HYP":
            c.need(data < len(contexts[context]["gamma"]) and contexts[context]["gamma"][data] == f, "HYP formula/index")
            value = proof.add(context, f, 0, None, data, (), origin)
        elif op == "LOGICAL_AXIOM":
            tag, witness = data
            value = proof.ax(context, tag, witness, origin)
            c.need(proof.rows[value]["formula"] == f, "logical row formula")
        elif op == "THEORY_AXIOM":
            tag, witness = data
            if tag == 2:
                c.need(q.profile == 1, "induction profile")
                formula, variable, parameters = witness
                expected = sorted(a.meta[formula]["FV"] - {variable})
                c.need(list(parameters) == expected, "induction parameters")
                ok, result = q.induction(formula, variable, parameters)
                c.need(ok and result == f, "induction guard/formula")
            else:
                c.need(tag == (0 if q.profile == 0 else (1 if q.profile == 1 else 3)) and
                       witness < len(q.table) and q.table[witness] == f, "theory table/profile/formula")
            value = proof.add(context, f, 2, tag, witness, (), origin)
        elif op == "MP":
            value = proof.mp(context, outputs[node["premises"][0]], outputs[node["premises"][1]], origin)
            c.need(proof.rows[value]["formula"] == f, "MP result")
        elif op == "GEN":
            value = proof.gen(context, outputs[node["premises"][0]], data, origin)
            c.need(proof.rows[value]["formula"] == f, "GEN result")
        else:
            child = outputs[node["premises"][0]]
            value = proof.deduce(child, data, context, contexts[data]["assumption"], number)
            c.need(proof.rows[value]["formula"] == f, "INTRO elaboration result")
        outputs.append(value)
    certificate, rows, export = proof.export(outputs[root])
    primitive_rows = []
    for row in proof.rows:
        c.tick()
        primitive_rows.append({"id": row["id"], "context": row["context"], "formula": row["formula"],
                               "rule_tag": row["rule_tag"], "subtag": row["subtag"],
                               "witness": proof.payload(row), "premises": list(row["premises"]),
                               "origins": _copy(row["origins"], c)})
    context_rows = []
    for context in contexts:
        c.tick()
        context_rows.append({key: context[key] for key in ("id", "parent", "opener", "assumption")})
    receipt = {"schema": "FPC-H1-obligation-elaboration-receipt-v1", "version": VERSION,
               "status": "ELABORATED_NOT_VALIDATED", "complete": True, "accepted": False,
               "query": q.pin, "input_plan_sha256": _digest(plan, c), "arena": a.records(),
               "contexts": context_rows, "primitive_nodes": primitive_rows,
               "plan_outputs": [{"node": i, "primitive": value} for i, value in enumerate(outputs)],
               "discharges": proof.discharges, "export_map": export, "candidate_rows": rows,
               "certificate": {"bytes": len(certificate), "sha256": _hash_raw(certificate, c)},
               "scope": "Primitive expansion only; external same-byte complete dual validation required."}
    c.tick()
    return {"candidate_certificate_bytes": certificate, "receipt": receipt}


def compile_plan(query_bytes, plan, *, modules, check):
    call = _Call(check)
    try:
        snapshot = _copy(plan, call)
        return _compile(_Query(query_bytes, modules, call), snapshot)
    except BaseException:
        call.fault()
        raise


def inspect_guard(query_bytes, request, *, modules, check):
    call = _Call(check)
    value = _copy(request, call)
    q = _Query(query_bytes, modules, call)
    call.need(type(value) is dict and value.get("kind") in ("UI", "GEN", "INDUCTION"), "guard kind")
    kind = value["kind"]
    fields = {"UI": ("kind", "formula", "variable", "term", "local_stack"),
              "GEN": ("kind", "variable", "local_stack"),
              "INDUCTION": ("kind", "formula", "variable", "parameters", "local_stack")}[kind]
    _keys(value, fields, call, "guard keys")
    call.need(_nat(value["variable"]) and type(value["local_stack"]) is list, "guard context")
    stack, gamma, owners = [], list(q.gamma), set()
    for local in value["local_stack"]:
        _keys(local, ("owner", "formula"), call, "local stack keys")
        call.need(_nat(local["owner"]) and local["owner"] not in owners, "local owner")
        owners.add(local["owner"])
        f = q.a.load(local["formula"])
        gamma.append(f)
        stack.append({"owner": local["owner"], "formula": q.a.tree(f)})
    variable, builder = value["variable"], modules["builders"]
    reason, permitted = "OK", True
    if kind == "GEN":
        vectors, bad = [], []
        for i, formula in enumerate(gamma):
            call.tick()
            vector = sorted(q.a.meta[formula]["FV"])
            vectors.append(vector)
            if variable in vector:
                bad.append(i)
        permitted = not bad
        reason = "OK" if permitted else "GEN_FULL_CONTEXT_FV"
        evidence = {"variable": variable, "hypothesis_FV": vectors, "offending_indices": bad}
    else:
        formula = q.a.load(value["formula"])
        if kind == "UI":
            term = q.a.load(value["term"], "T")
            ok, result = call.helper(builder, builder.substitute, q.a.tree(term), variable, q.a.tree(formula))
            permitted, reason = ok, "OK" if ok else "UI_CAPTURE"
            evidence = {"free_for": ok, "term_FV": sorted(q.a.meta[term]["FV"]),
                        "formula_FV": sorted(q.a.meta[formula]["FV"]),
                        "substitution_result": result if ok else None}
        else:
            call.need(type(value["parameters"]) is list, "parameter carrier")
            for x in value["parameters"]:
                call.tick()
                call.need(_nat(x), "parameter natural")
            expected = sorted(q.a.meta[formula]["FV"] - {variable})
            equal = value["parameters"] == expected
            capture, generated = None, None
            if q.profile != 1:
                permitted, reason = False, "INDUCTION_WRONG_PROFILE"
            elif not equal:
                permitted, reason = False, "INDUCTION_PARAMETERS"
            else:
                ok, result = q.induction(formula, variable, expected)
                capture, permitted = ok, ok
                reason = "OK" if ok else "INDUCTION_CAPTURE"
                if ok:
                    generated = q.a.tree(result)
            evidence = {"profile": q.profile, "expected_parameters": expected,
                        "parameter_equal": equal, "capture_free": capture, "generated_formula": generated}
    receipt = {"schema": "FPC-H1-obligation-guard-receipt-v1", "complete": True, "kind": kind,
               "context": {"query_sha256": q.pin["sha256"],
                           "root_Gamma": [q.a.tree(f) for f in q.gamma], "local_stack": stack,
                           "scope": "DECLARED_LOCAL_SCOPE_NOT_AUTHENTICATED_AS_PLAN"},
               "permitted": permitted, "reason": reason, "evidence": evidence}
    call.tick()
    return receipt


def _product(state, lengths, closed, call):
    _keys(state, ("arity", "diagonal", "positions", "started", "finished"), call, "product state")
    n = state["arity"]
    call.need(_nat(n) and _nat(state["diagonal"]) and type(state["positions"]) is list and
              len(state["positions"]) == n and type(state["started"]) is bool and
              type(state["finished"]) is bool and type(lengths) is list and type(closed) is list and
              len(lengths) == n and len(closed) == n, "product carriers")
    positions, total, stop, all_closed, maximum = [], 0, False, True, 0
    for i in range(n):
        call.tick()
        x = state["positions"][i]
        call.need(_nat(x) and _nat(lengths[i]) and type(closed[i]) is bool, "product dimension")
        positions.append(x)
        total += x
        stop = stop or (closed[i] and lengths[i] == 0)
        all_closed = all_closed and closed[i]
        maximum += max(0, lengths[i] - 1)
    call.need(total == state["diagonal"], "product diagonal")
    call.need(state["started"] or state["diagonal"] == 0, "initial product diagonal")
    next_state = {"arity": n, "diagonal": state["diagonal"], "positions": positions,
                  "started": state["started"], "finished": state["finished"]}
    if state["finished"] or stop or (n == 0 and state["started"]) or (all_closed and state["diagonal"] > maximum):
        next_state["finished"] = True
        return {"kind": "EOF", "state": next_state, "indices": None, "requests": []}
    if n == 0:
        next_state["started"] = True
        return {"kind": "TUPLE", "state": next_state, "indices": [], "requests": []}
    outside, requests = False, []
    for i in range(n):
        call.tick()
        if positions[i] >= lengths[i]:
            if closed[i]:
                outside = True
            else:
                requests.append({"slot": i, "index": positions[i]})
    if requests and not outside:
        return {"kind": "WAIT", "state": next_state, "indices": None, "requests": requests}
    output = list(positions)
    advanced = False
    for j in range(n - 2, -1, -1):
        call.tick()
        prefix = 0
        for k in range(j + 1):
            call.tick()
            prefix += positions[k]
        if prefix < state["diagonal"]:
            positions[j] += 1
            for k in range(j + 1, n - 1):
                call.tick()
                positions[k] = 0
            prefix = 0
            for k in range(n - 1):
                call.tick()
                prefix += positions[k]
            positions[-1] = state["diagonal"] - prefix
            advanced = True
            break
    if not advanced:
        next_state["diagonal"] += 1
        for i in range(n):
            call.tick()
            positions[i] = next_state["diagonal"] if i == n - 1 else 0
    next_state["started"] = True
    return {"kind": "SKIP_OUTSIDE" if outside else "TUPLE", "state": next_state,
            "indices": output, "requests": []}


def product_step(state, lengths, closed, *, check):
    call = _Call(check)
    return _product(_copy(state, call), _copy(lengths, call), _copy(closed, call), call)


def _product_initial(arity):
    return {"arity": arity, "diagonal": 0, "positions": [0] * arity,
            "started": False, "finished": False}


def _patterns():
    A, B, C, X, T = ("$F", "A"), ("$F", "B"), ("$F", "C"), ("$V", "x"), ("$T", "t")
    return (("imp", A, ("imp", B, A)),
            ("imp", ("imp", A, ("imp", B, C)), ("imp", ("imp", A, B), ("imp", A, C))),
            ("imp", ("imp", ("not", B), ("not", A)), ("imp", A, B)),
            None,
            ("imp", ("all", X, ("imp", A, B)), ("imp", ("all", X, A), ("all", X, B))),
            ("imp", A, ("all", X, A)), ("eq", T, T), None)


def _pattern_substitute(pattern, variable, replacement, call):
    pending, values = [(False, pattern)], []
    while pending:
        call.tick()
        built, node = pending.pop()
        if built:
            tag, metadata, count = node
            children = values[-count:] if count else []
            if count:
                del values[-count:]
            if tag in ("fun", "pred"):
                values.append((tag, metadata, tuple(children)))
            elif tag == "all":
                values.append((tag, metadata, children[0]))
            else:
                values.append((tag,) + tuple(children))
        elif node[0].startswith("$") or (node[0] == "all" and node[1] == variable):
            values.append(node)
        elif node[0] == "var":
            values.append(replacement if node[1] == variable else node)
        else:
            tag = node[0]
            children = node[2] if tag in ("fun", "pred") else ([node[2]] if tag == "all" else node[1:])
            pending.append((True, (tag, node[1] if tag in ("fun", "pred", "all") else None, len(children))))
            for child in reversed(children):
                call.tick()
                pending.append((False, child))
    return values[0]


def _sites(pattern, call, allow_all):
    path, slots, current = [], [], pattern
    while True:
        call.tick()
        yield current, tuple(path), tuple(slots)
        if current[0] == "imp":
            path.append(("IMP",))
            current = current[2]
        elif current[0] == "all" and allow_all and type(current[1]) is int:
            name = "s" + str(len(slots))
            slots.append(("T", name))
            path.append(("ALL", current[1], name))
            current = _pattern_substitute(current[2], current[1], ("$T", name), call)
        else:
            return


def _match_step(event, arena, call):
    """One pattern-pair comparison per call; rigid terms never become metas."""
    if not event["pending"]:
        return "MATCHED"
    call.tick()
    pattern, value, kind = event["pending"].pop()
    if type(pattern) is int:
        return "CONTINUE" if kind == "V" and pattern == value else "MISMATCH"
    if pattern[0].startswith("$"):
        expected, name = pattern[0][1:], pattern[1]
        if expected != kind:
            return "MISMATCH"
        key = (expected, name)
        if key in event["bindings"] and event["bindings"][key] != value:
            return "MISMATCH"
        event["bindings"][key] = value
        return "CONTINUE"
    if kind == "V":
        return "MISMATCH"
    sort, tag, symbol, children = arena.rows[value]
    event["rigid_nodes"] = event.get("rigid_nodes", 0) + 1
    if sort != kind or pattern[0] != tag:
        return "MISMATCH"
    if tag == "var":
        return "CONTINUE" if pattern[1] == symbol else "MISMATCH"
    if tag in ("fun", "pred"):
        if pattern[1] != symbol or len(pattern[2]) != len(children):
            return "MISMATCH"
        for p, child in zip(reversed(pattern[2]), reversed(children)):
            call.tick()
            event["pending"].append((p, child, "T"))
    elif tag == "all":
        event["pending"].append((pattern[2], children[0], "F"))
        event["pending"].append((pattern[1], symbol, "V"))
    else:
        if len(pattern) - 1 != len(children):
            return "MISMATCH"
        for p, child in zip(reversed(pattern[1:]), reversed(children)):
            call.tick()
            event["pending"].append((p, child, "T" if tag == "eq" else "F"))
    return "CONTINUE"


def _walk_ids(arena, root):
    pending = [(root, ())]
    while pending:
        arena.c.tick()
        value, path = pending.pop()
        yield value, path
        children = arena.rows[value][3]
        for slot in range(len(children) - 1, -1, -1):
            arena.c.tick()
            pending.append((children[slot], path + (slot,)))


def _compositions(total, count, call):
    if count == 0:
        if total == 0:
            yield ()
        return
    if total < count:
        return
    state = _product_initial(count)
    lengths, closed = [total] * count, [True] * count
    while True:
        call.tick()
        result = _product(state, lengths, closed, call)
        state = result["state"]
        if result["kind"] == "EOF":
            return
        if result["kind"] == "TUPLE":
            vector = []
            amount = 0
            for x in result["indices"]:
                call.tick()
                vector.append(x + 1)
                amount += x + 1
            if amount == total:
                yield tuple(vector)
        yield None
        if state["diagonal"] > total - count:
            return


class _Catalog:
    def __init__(self, engine, sort, bound=None, sources=()):
        self.e, self.sort, self.bound = engine, sort, bound
        self.entries, self.keys, self.eof = [], set(), False
        self.cursor = {"phase": "NOT_STARTED", "position": 0}
        self.requests, self.request_keys = [], {}
        self.request_scan, self.requests_total, self.requests_retired = 0, 0, 0
        self.generator = self.terms() if sort == "T" else self.formulas(sources)

    def request(self, owner, slot, index):
        self.e.c.tick()
        key = (owner, slot)
        self.requests_total += 1
        if key in self.request_keys:
            self.requests[self.request_keys[key]]["index"] = index
        else:
            self.request_keys[key] = len(self.requests)
            self.requests.append({"owner": owner, "slot": slot, "index": index})

    def retire_request_step(self):
        if not self.requests:
            return
        self.e.c.tick()
        position = self.request_scan % len(self.requests)
        row = self.requests[position]
        if self.eof or row["index"] < len(self.entries) or self.e.nodes[row["owner"]]["state"] == "SOLVED":
            self.request_keys.pop((row["owner"], row["slot"]))
            last = self.requests.pop()
            if position < len(self.requests):
                self.requests[position] = last
                self.request_keys[(last["owner"], last["slot"])] = position
            self.requests_retired += 1
        else:
            self.request_scan += 1

    def advance(self):
        self.retire_request_step()
        if self.eof:
            return False
        self.e.c.tick()
        try:
            value = next(self.generator)
        except BaseException as error:
            self.e.c.fault()
            if type(error) is StopIteration:
                self.eof = True
                return True
            raise
        self.e.c.fault()
        if value is not None and value not in self.keys:
            self.keys.add(value)
            self.entries.append(value)
            if self.sort == "W":
                self.e.add_priority("F", value)
            elif self.sort == "T":
                self.e.add_priority("T", value)
        return True

    def terms(self):
        e, a, c = self.e, self.e.a, self.e.c
        for x in range(e.g["variables"]):
            self.cursor = {"phase": "VARIABLE", "position": x}
            c.tick()
            yield a.add("T", "var", x, ())
        for symbol, arity in enumerate(a.functions):
            self.cursor = {"phase": "NULLARY", "position": symbol}
            c.tick()
            yield a.add("T", "fun", symbol, ()) if arity == 0 else None
        for depth in range(1, e.g["term_depth"] + 1):
            pool = []
            for position, term in enumerate(self.entries):
                c.tick()
                self.cursor = {"phase": "DEPTH_POOL", "position": {"depth": depth, "index": position}}
                if a.meta[term]["term_depth"] < depth:
                    pool.append(term)
                yield None
            for symbol, arity in enumerate(a.functions):
                if not arity:
                    continue
                state = _product_initial(arity)
                while True:
                    c.tick()
                    result = _product(state, [len(pool)] * arity, [True] * arity, c)
                    state = result["state"]
                    self.cursor = {"phase": "FUNCTION_PRODUCT", "position": {"depth": depth, "symbol": symbol, "product": state}}
                    if result["kind"] == "EOF":
                        break
                    if result["kind"] == "TUPLE":
                        kids = []
                        for index in result["indices"]:
                            c.tick()
                            kids.append(pool[index])
                        value = a.add("T", "fun", symbol, kids)
                        yield value if a.meta[value]["term_depth"] == depth else None
                    else:
                        yield None

    def formulas(self, sources):
        e, a, c = self.e, self.e.a, self.e.c
        for root in sources:
            if self.sort == "W":
                for value, path in _walk_ids(a, root):
                    self.cursor = {"phase": "SOURCE_PREFIX", "position": {"root": root, "path": list(path)}}
                    yield value if a.rows[value][0] == "F" else None
            else:
                self.cursor = {"phase": "SOURCE_PREFIX", "position": root}
                yield root
        while not e.T.eof:
            c.tick()
            self.cursor = {"phase": "WAIT_T_EOF", "position": len(e.T.entries)}
            yield None
        terms, formulas = {}, {}
        for term in e.T.entries:
            c.tick()
            terms.setdefault(a.meta[term]["nodes"], []).append(term)
            yield None
        for value in self.entries:
            c.tick()
            size = a.meta[value]["nodes"]
            if size <= self.bound:
                formulas.setdefault(size, []).append(value)
            yield None
        for size in range(1, self.bound + 1):
            for tag in ("pred", "eq", "not", "imp", "all"):
                variants = enumerate(a.predicates) if tag == "pred" else [(None, {"eq": 2, "not": 1, "imp": 2, "all": 1}[tag])]
                for symbol, arity in variants:
                    for partition in _compositions(size - 1, arity, c):
                        if partition is None:
                            yield None
                            continue
                        table = terms if tag in ("pred", "eq") else formulas
                        groups = []
                        for weight in partition:
                            c.tick()
                            groups.append(table.get(weight, []))
                        state = _product_initial(arity)
                        while True:
                            c.tick()
                            step = _product(state, [len(x) for x in groups], [True] * arity, c)
                            state = step["state"]
                            self.cursor = {"phase": "FORMULA_PRODUCT", "position": {"size": size, "tag": tag, "symbol": symbol,
                                                                                      "partition": list(partition), "product": state}}
                            if step["kind"] == "EOF":
                                break
                            if step["kind"] != "TUPLE":
                                yield None
                                continue
                            children = []
                            for group, index in zip(groups, step["indices"]):
                                c.tick()
                                children.append(group[index])
                            for variable in (range(e.g["variables"]) if tag == "all" else (None,)):
                                c.tick()
                                value = a.add("F", tag, variable if tag == "all" else symbol, children)
                                if value not in self.keys:
                                    formulas.setdefault(size, []).append(value)
                                    yield value
                                else:
                                    yield None


class _Engine:
    def __init__(self, q, configuration, receipt):
        self.q, self.a, self.c, self.r = q, q.a, q.c, receipt
        self.preparing = None
        self.g = configuration
        self.contexts = [{"id": 0, "parent": None, "opener": None, "assumption": None,
                          "gamma": list(q.gamma), "stack": ()}]
        self.context_keys, self.nodes, self.node_keys = {}, [], {}
        self.source_site_cache = {}
        self.schema_patterns = _patterns()
        self.alternatives, self.alt_keys, self.watchers, self.notify = [], {}, [], deque()
        self.watch_index, self.registration, self.registration_jobs = {}, deque(), {}
        self.matching, self.descriptors, self.ready, self.oldest, self.active = deque(), [], [], {}, set()
        self.heap_positions = {}
        self.fallback_nodes, self.MP_nodes = deque(), deque()
        self.pending_products, self.pending_MP = 0, 0
        self.r["arena"] = self.a.records()
        self.a.mirror = self.r["arena"]
        root_FV = set()
        for f in q.gamma:
            self.c.tick()
            root_FV.update(self.a.meta[f]["FV"])
        self.r["contexts"] = [{"id": 0, "parent_id": None, "root_query_sha256": q.pin["sha256"],
                               "local_occurrences": [], "full_Gamma_formula_ids": list(q.gamma),
                               "FV_union": sorted(root_FV)}]
        self.r["obligations"], self.r["alternatives"] = [], []
        self.r["cursors"] = {"next_lane": 0, "lane_visits": [0] * 8, "catalogs": {},
                              "node_fallback": [], "priority": {"visits": 0, "ready": self.ready,
                              "oldest": None, "descriptors": []}, "watchers": self.watchers}
        self.r["operations"]["live_snapshot_complete"] = False
        self.r["operations"]["live_unavailable_fields"] = ["cursors.priority.oldest", "coverage final census"]
        self.priority = {"F": [], "T": [], "V": list(range(self.g["variables"]))}
        self.priority_keys = {"F": set(), "T": set(), "V": set(self.priority["V"])}
        self.solved_serial, self.priority_visits = 0, 0
        self.counts = {name: 0 for name in ("attempted_primitive_witnesses", "guard_refusals", "duplicate_alternatives",
                      "retired_descriptors", "source_uses", "MP_resolutions", "GEN_resolutions", "INTRO_resolutions",
                      "outside_premises", "priority_inverse_not_handled", "intro_depth_refusals")}
        self.guard_reasons = {}
        self.r["counts"] = self.counts
        self.S = q.gamma + q.table
        self.source_set, self.source_W = set(self.S), set()
        self.outside = None
        for root in self.S + [q.goal]:
            self.c.tick()
            if not self.alphabet(root):
                self.outside = {"kind": "SOURCE_ALPHABET", "formula": root}
        for root in self.S:
            self.preparing = _walk_ids(self.a, root)
            for value, _ in self.preparing:
                if self.a.rows[value][0] == "F":
                    self.source_W.add(value)
                if self.member(self.a.rows[value][0], value, False):
                    self.add_priority(self.a.rows[value][0], value)
            self.preparing = None
        self.T = _Catalog(self, "T")
        self.W = _Catalog(self, "W", self.g["fallback_witness_nodes"], self.S)
        self.U = _Catalog(self, "U", self.g["obligation_nodes"], self.S)
        for name, catalog in (("T", self.T), ("W_fallback", self.W), ("U", self.U)):
            self.r["cursors"]["catalogs"][name] = {"entries": catalog.entries, "eof": False,
                                                    "cursor": catalog.cursor, "requests": catalog.requests}
        if not self.universe(q.goal):
            self.outside = {"kind": "GOAL_OUTSIDE_U", "formula": q.goal}
        self.root = self.want(0, q.goal, None, None) if self.outside is None else None
        self.next_lane, self.lane_visits, self.turn = 0, [0] * 8, [0] * 8
        self.terminal_priority = False

    def alphabet(self, value):
        info = self.a.meta[value]
        return info["term_depth"] <= self.g["term_depth"] and all(x < self.g["variables"] for x in info["variables"])

    def member(self, sort, value, priority):
        self.c.tick()
        if sort == "V":
            return _nat(value) and value < self.g["variables"]
        if self.a.rows[value][0] != sort or not self.alphabet(value):
            return False
        if sort == "T":
            return True
        return (self.a.meta[value]["nodes"] <= self.g["fallback_witness_nodes"] or value in self.source_W or
                (priority and self.a.meta[value]["nodes"] <= self.g["priority_subformula_nodes"]))

    def universe(self, value):
        return self.alphabet(value) and (self.a.meta[value]["nodes"] <= self.g["obligation_nodes"] or value in self.source_set)

    def add_priority(self, sort, value):
        self.c.tick()
        if value not in self.priority_keys[sort]:
            self.priority_keys[sort].add(value)
            self.priority[sort].append(value)

    def want(self, context, formula, requester, position):
        self.c.tick()
        self.c.need(self.universe(formula), "internal outside obligation")
        key = (context, formula)
        if key in self.node_keys:
            number = self.node_keys[key]
        else:
            number = len(self.nodes)
            self.node_keys[key] = number
            tags = list(range(8)) + ([8] if self.q.profile == 1 else [])
            self.nodes.append({"id": number, "context_id": context, "formula_id": formula,
                               "origins": [], "origin_keys": set(), "state": "OPEN", "selected_alternative_id": None,
                               "solved_serial": None, "products": [{"tag": tag, "state": _product_initial(len(_SORTS[tag])),
                                                                       "status": "OPEN"} for tag in tags],
                               "MP": {"index": 0, "status": "OPEN"}, "next_tag": 0})
            self.registration.append(number)
            self.registration_jobs[number] = self.initialize(number)
            self.fallback_nodes.append(number)
            self.MP_nodes.append(number)
            self.pending_products += len(tags)
            self.pending_MP += 1
            self.terminal_priority = False
            node = self.nodes[number]
            view = {key: node[key] for key in ("id", "context_id", "formula_id", "origins", "state",
                                               "selected_alternative_id", "solved_serial")}
            node["view"] = view
            self.r["obligations"].append(view)
            self.r["cursors"]["node_fallback"].append({"node": number, "products": node["products"],
                                                       "MP": node["MP"], "next_tag": 0})
        node = self.nodes[number]
        origin = (requester, position)
        if origin not in node["origin_keys"]:
            node["origin_keys"].add(origin)
            node["origins"].append({"requester_alternative_id": requester, "premise_position": position})
        return number

    def alternative(self, owner, operator, premises, payload, program=()):
        self.c.tick()
        node = self.nodes[owner]
        if node["state"] == "SOLVED":
            return None
        frozen = _digest({"operator": operator, "premises": premises, "payload": payload, "program": program}, self.c)
        key = (owner, frozen)
        # Digest buckets never define equality: compare full ordinary records.
        exact = {"operator": operator, "premises": list(premises), "payload": payload, "program": list(program)}
        for prior in self.alt_keys.get(key, ()):
            self.c.tick()
            if self.alternatives[prior]["exact"] == exact:
                self.counts["duplicate_alternatives"] += 1
                return prior
        number = len(self.alternatives)
        row = {"id": number, "owner": owner, "operator": operator, "premise_ids": list(premises),
               "witness": payload, "program": list(program), "status": "PENDING", "exact": exact}
        row["view"] = {key: row[key] for key in ("id", "owner", "operator", "premise_ids", "witness", "program", "status")}
        row["view"]["key"] = exact
        row["view"]["guard_receipt"] = {"complete": True, "scope": "CONCRETE_OPERATOR_GUARDS_NO_PROOF_AUTHORITY"}
        self.alternatives.append(row)
        self.r["alternatives"].append(row["view"])
        self.alt_keys.setdefault(key, []).append(number)
        for position, premise in enumerate(premises):
            self.c.tick()
            origin_key = (number, position)
            target = self.nodes[premise]
            if origin_key not in target["origin_keys"]:
                target["origin_keys"].add(origin_key)
                target["origins"].append({"requester_alternative_id": number, "premise_position": position})
            watcher = len(self.watchers)
            self.watchers.append({"premise": premise, "alternative": number, "position": position, "notified": False})
            self.watch_index.setdefault(premise, []).append(watcher)
        self.notify.append(("ALT", number, 0))
        return number

    def context(self, parent, owner, assumption):
        key = (parent, owner, assumption)
        if key not in self.context_keys:
            self.c.tick()
            number = len(self.contexts)
            self.context_keys[key] = number
            old = self.contexts[parent]
            self.contexts.append({"id": number, "parent": parent, "opener": owner, "assumption": assumption,
                                  "gamma": old["gamma"] + [assumption], "stack": old["stack"] + ((owner, assumption),)})
            local = []
            FV = set()
            for j, (opened, f) in enumerate(self.contexts[number]["stack"]):
                self.c.tick()
                local.append({"owner_intro_obligation_id": opened, "formula_id": f,
                              "hypothesis_index": len(self.q.gamma) + j})
            for f in self.contexts[number]["gamma"]:
                self.c.tick()
                FV.update(self.a.meta[f]["FV"])
            self.r["contexts"].append({"id": number, "parent_id": parent,
                "root_query_sha256": self.q.pin["sha256"], "local_occurrences": local,
                "full_Gamma_formula_ids": list(self.contexts[number]["gamma"]), "FV_union": sorted(FV)})
            self.r["sources"].append({"kind": "HYP", "context_id": number,
                "index": len(self.contexts[number]["gamma"]) - 1, "formula_id": assumption})
        return self.context_keys[key]

    def initialize(self, number):
        node, a = self.nodes[number], self.a
        context, formula = node["context_id"], node["formula_id"]
        for value, path in _walk_ids(a, formula):
            kind = a.rows[value][0]
            if self.member(kind, value, True):
                self.add_priority(kind, value)
            yield None
        sort, tag, variable, children = a.rows[formula]
        if tag == "all":
            allowed = True
            for f in self.contexts[context]["gamma"]:
                self.c.tick()
                allowed = allowed and variable not in a.meta[f]["FV"]
                yield None
            if allowed and self.universe(children[0]):
                child = self.want(context, children[0], None, 0)
                self.alternative(number, "GEN", [child], {"variable": variable})
            elif not allowed:
                self.refusal("GEN_FULL_CONTEXT_FV")
            else:
                self.counts["outside_premises"] += 1
            yield None
        if tag == "imp":
            if len(self.contexts[context]["stack"]) >= self.g["intro_depth"]:
                self.counts["intro_depth_refusals"] += 1
            elif not self.universe(children[0]) or not self.universe(children[1]):
                self.counts["outside_premises"] += 1
            else:
                child_context = self.context(context, number, children[0])
                child = self.want(child_context, children[1], None, 0)
                self.alternative(number, "INTRO", [child], {"child_context": child_context})
            yield None
        for index, source in enumerate(self.contexts[context]["gamma"]):
            self.c.tick()
            if source == formula:
                self.alternative(number, "HYP", [], {"index": index})
            yield None
            yield from self.source_sites(number, source, {"kind": "HYP", "index": index})
        table_tag = 0 if self.q.profile == 0 else (1 if self.q.profile == 1 else 3)
        for index, source in enumerate(self.q.table):
            self.c.tick()
            if source == formula:
                self.alternative(number, "THEORY_AXIOM", [], {"tag": table_tag, "index": index})
            yield None
            yield from self.source_sites(number, source, {"kind": "THEORY_AXIOM", "tag": table_tag, "index": index})
        for tag_number, pattern in enumerate(self.schema_patterns):
            self.c.tick()
            if pattern is None:
                self.counts["priority_inverse_not_handled"] += 1
                yield None
                continue
            names = (("A", "B"), ("A", "B", "C"), ("A", "B"), ("A", "x", "t"),
                     ("A", "B", "x"), ("A", "x"), ("t",), ("A", "x", "s", "t"))[tag_number]
            slots = tuple(zip(_SORTS[tag_number], names))
            for site, path, _ in _sites(pattern, self.c, False):
                self.matching.append({"owner": number, "pending": [(site, formula, "F")], "bindings": {},
                                      "base": {"kind": "LOGICAL", "tag": tag_number}, "slots": slots, "path": path})
                yield None
        if self.q.profile == 1 and tag == "all" and self.member("F", children[0], True):
            # Generic consequent binding only; other induction inversions remain
            # deliberately unsupported priority sites, with full bounded fallback.
            self.enqueue_descriptor(number, {"kind": "INDUCTION", "formula": children[0], "variable": variable}, (), {}, ())
            yield None

    def source_sites(self, number, source, origin):
        if source not in self.source_site_cache:
            compiled = []
            for site in _sites(self.a.tree(source), self.c, True):
                self.c.tick()
                compiled.append(site)
            self.source_site_cache[source] = tuple(compiled)
        for site, path, slots in self.source_site_cache[source]:
            self.c.tick()
            if not path:
                yield None
                continue
            self.matching.append({"owner": number, "pending": [(site, self.nodes[number]["formula_id"], "F")],
                                  "bindings": {}, "base": dict(origin, formula=source), "slots": slots, "path": path})
            yield None

    def refusal(self, reason):
        self.counts["guard_refusals"] += 1
        self.guard_reasons[reason] = self.guard_reasons.get(reason, 0) + 1

    def enqueue_descriptor(self, owner, base, slots, bindings, path, rigid_nodes=0):
        if self.nodes[owner]["state"] == "SOLVED":
            return
        for kind, value in bindings.items():
            self.c.tick()
            if not self.member(kind[0], value, True):
                self.refusal("PRIORITY_WITNESS_DOMAIN")
                return
        residual = []
        for kind, name in slots:
            self.c.tick()
            if (kind, name) not in bindings:
                residual.append((kind, name))
        number = len(self.descriptors)
        self.descriptors.append({"id": number, "owner": owner, "base": base, "slots": slots,
                                 "bindings": dict(bindings), "residual": residual, "path": path,
                                 "product": _product_initial(len(residual)), "born": number,
                                 "status": "OPEN", "requests": [],
                                 "score": (len(residual), 513, -rigid_nodes, number)})
        self.descriptors[-1]["view"] = {"id": number, "owner": owner, "kind": base["kind"],
            "bindings": {kind + ":" + name: value for (kind, name), value in bindings.items()},
            "residual_sorts": [kind for kind, _ in residual], "product": self.descriptors[-1]["product"],
            "score": list(self.descriptors[-1]["score"]), "born": number, "status": "OPEN", "requests": []}
        self.r["cursors"]["priority"]["descriptors"].append(self.descriptors[-1]["view"])
        self.queue_add(number)

    def queue_add(self, number):
        self.c.tick()
        self.active.add(number)
        self.oldest[number] = None
        position = len(self.ready)
        self.ready.append(number)
        self.heap_positions[number] = position
        while position:
            self.c.tick()
            parent = (position - 1) // 2
            if self.descriptors[self.ready[parent]]["score"] <= self.descriptors[number]["score"]:
                break
            moved = self.ready[parent]
            self.ready[position] = moved
            self.heap_positions[moved] = position
            position = parent
        self.ready[position] = number
        self.heap_positions[number] = position

    def queue_take(self, oldest):
        self.c.tick()
        number = next(iter(self.oldest)) if oldest else self.ready[0]
        self.oldest.pop(number)
        self.active.remove(number)
        position = self.heap_positions.pop(number)
        last = self.ready.pop()
        if position < len(self.ready):
            self.ready[position] = last
            self.heap_positions[last] = position
            while position:
                self.c.tick()
                parent = (position - 1) // 2
                if self.descriptors[self.ready[parent]]["score"] <= self.descriptors[last]["score"]:
                    break
                moved = self.ready[parent]
                self.ready[position] = moved
                self.heap_positions[moved] = position
                position = parent
            self.ready[position] = last
            self.heap_positions[last] = position
            while 2 * position + 1 < len(self.ready):
                self.c.tick()
                child = 2 * position + 1
                if child + 1 < len(self.ready) and self.descriptors[self.ready[child + 1]]["score"] < self.descriptors[self.ready[child]]["score"]:
                    child += 1
                if self.descriptors[last]["score"] <= self.descriptors[self.ready[child]]["score"]:
                    break
                moved = self.ready[child]
                self.ready[position] = moved
                self.heap_positions[moved] = position
                position = child
            self.ready[position] = last
            self.heap_positions[last] = position
        return number

    def raw_logical(self, tag, witness):
        values = []
        for kind, value in witness:
            self.c.tick()
            values.append(value if kind == "V" else self.a.tree(value))
        b = self.q.modules["builders"]
        return self.c.helper(b, b.logical_axiom, tag, values)

    def raw_induction(self, formula, variable):
        parameters = sorted(self.a.meta[formula]["FV"] - {variable})
        b = self.q.modules["builders"]
        ok, result = self.c.helper(b, b.pa_induction, self.a.tree(formula), variable, parameters)
        return ok, result, parameters

    def raw_equal(self, raw, value):
        pending = [(raw, value, self.a.rows[value][0])]
        while pending:
            self.c.tick()
            node, number, kind = pending.pop()
            sort, tag, symbol, children = self.a.rows[number]
            if node[0] != tag or kind != sort:
                return False
            if tag == "var":
                if node[1] != symbol:
                    return False
            elif tag in ("fun", "pred"):
                if node[1] != symbol or len(node[2]) != len(children):
                    return False
                for child, ref in zip(node[2], children):
                    self.c.tick()
                    pending.append((child, ref, "T"))
            elif tag == "all":
                if node[1] != symbol:
                    return False
                pending.append((node[2], children[0], "F"))
            else:
                for child, ref in zip(node[1:], children):
                    self.c.tick()
                    pending.append((child, ref, "T" if tag == "eq" else "F"))
        return True

    def raw_universe(self, raw):
        temporary = _Arena(self.a.functions, self.a.predicates, self.c)
        root = temporary.load(raw)
        info = temporary.meta[root]
        if info["term_depth"] > self.g["term_depth"] or any(x >= self.g["variables"] for x in info["variables"]):
            return False
        if info["nodes"] <= self.g["obligation_nodes"]:
            return True
        for source in self.S:
            self.c.tick()
            if self.raw_equal(raw, source):
                return True
        return False

    def build_descriptor(self, descriptor, binding):
        owner, base = descriptor["owner"], descriptor["base"]
        desired = self.nodes[owner]["formula_id"]
        self.counts["attempted_primitive_witnesses"] += 1
        if base["kind"] == "LOGICAL":
            witness = []
            for kind, name in descriptor["slots"]:
                self.c.tick()
                witness.append((kind, binding[(kind, name)]))
            ok, current = self.raw_logical(base["tag"], witness)
            initial = {"kind": "LOGICAL_AXIOM", "tag": base["tag"], "witness": _witness_records(witness)}
        elif base["kind"] == "INDUCTION":
            ok, raw, parameters = self.raw_induction(base["formula"], base["variable"])
            if not ok:
                self.refusal(str(raw))
                return
            origin = {"kind": "INDUCTION_ROW", "formula": base["formula"],
                      "variable": base["variable"], "parameters": parameters}
            for site, path, slots in _sites(raw, self.c, True):
                self.matching.append({"owner": owner, "pending": [(site, desired, "F")], "bindings": {},
                                      "base": origin, "slots": slots, "path": path})
            return
        elif base["kind"] == "INDUCTION_ROW":
            ok, current, parameters = self.raw_induction(base["formula"], base["variable"])
            initial = {"kind": "THEORY_AXIOM", "tag": 2, "formula": base["formula"],
                       "variable": base["variable"], "parameters": parameters}
        else:
            ok, current = True, self.a.tree(base["formula"])
            initial = {key: base[key] for key in base if key != "formula"}
        if not ok:
            self.refusal(str(current))
            return
        raw_premises, program = [], []
        for step in descriptor["path"]:
            self.c.tick()
            if step[0] == "ALL":
                variable, term = step[1], binding[("T", step[2])]
                if current[0] != "all" or current[1] != variable:
                    self.refusal("RECEPTOR_RIGID_BINDER")
                    return
                b = self.q.modules["builders"]
                permitted, axiom = self.c.helper(b, b.logical_axiom, 3,
                                                [current[2], variable, self.a.tree(term)])
                if not permitted:
                    self.refusal("UI_CAPTURE")
                    return
                current = axiom[2]
                program.append({"kind": "ALL", "variable": variable, "term": term})
            else:
                if current[0] != "imp":
                    self.refusal("RECEPTOR_IMPLICATION_SHAPE")
                    return
                raw_premises.append(current[1])
                program.append({"kind": "IMP", "position": len(raw_premises) - 1})
                current = current[2]
        if not self.raw_equal(current, desired):
            return
        for formula in raw_premises:
            self.c.tick()
            if not self.raw_universe(formula):
                self.counts["outside_premises"] += 1
                return
        premise_ids = []
        for position, formula in enumerate(raw_premises):
            self.c.tick()
            premise_ids.append(self.want(self.nodes[owner]["context_id"], self.a.load(formula), None, position))
        self.alternative(owner, "RECEPTOR", premise_ids, initial, program)

    def priority_step(self):
        if not self.active:
            return False
        oldest = self.g["ordering"] == "FIFO" or (self.priority_visits + 1) % self.g["oldest_period"] == 0
        number = self.queue_take(oldest)
        descriptor = self.descriptors[number]
        if self.nodes[descriptor["owner"]]["state"] == "SOLVED":
            descriptor["status"] = "RETIRED_SOLVED"
            descriptor["view"]["status"] = descriptor["status"]
            self.counts["retired_descriptors"] += 1
            return True
        self.priority_visits += 1
        self.r["cursors"]["priority"]["visits"] = self.priority_visits
        groups, lengths, closed = [], [], []
        for kind, _ in descriptor["residual"]:
            self.c.tick()
            group = self.priority[kind]
            groups.append(group)
            lengths.append(len(group))
            closed.append(kind == "V" or self.terminal_priority)
        step = _product(descriptor["product"], lengths, closed, self.c)
        descriptor["product"] = step["state"]
        descriptor["view"]["product"] = descriptor["product"]
        descriptor["requests"] = [{"slot": x["slot"], "index": x["index"],
                                   "sort": descriptor["residual"][x["slot"]][0]} for x in step["requests"]]
        descriptor["view"]["requests"] = descriptor["requests"]
        if step["kind"] == "EOF":
            descriptor["status"] = "EOF"
            descriptor["view"]["status"] = "EOF"
            return True
        descriptor["status"] = "WAIT" if step["kind"] == "WAIT" else "OPEN"
        if step["kind"] == "TUPLE":
            binding = dict(descriptor["bindings"])
            for pair, group, index in zip(descriptor["residual"], groups, step["indices"]):
                self.c.tick()
                binding[pair] = group[index]
            self.build_descriptor(descriptor, binding)
        descriptor["view"]["status"] = descriptor["status"]
        self.queue_add(number)
        return True

    def matcher_step(self):
        if not self.matching:
            return False
        event = self.matching.popleft()
        if self.nodes[event["owner"]]["state"] == "SOLVED":
            return True
        status = _match_step(event, self.a, self.c)
        if status == "MATCHED":
            self.enqueue_descriptor(event["owner"], event["base"], event["slots"], event["bindings"], event["path"], event.get("rigid_nodes", 0))
        elif status != "MISMATCH":
            self.matching.append(event)
        return True

    def fallback_step(self):
        if not self.fallback_nodes:
            return False
        index = self.fallback_nodes.popleft()
        node = self.nodes[index]
        if node["state"] != "SOLVED":
            self.fallback_nodes.append(index)
        if node["state"] == "SOLVED":
            return False
        producer = node["products"][node["next_tag"] % len(node["products"])]
        node["next_tag"] += 1
        self.r["cursors"]["node_fallback"][index]["next_tag"] = node["next_tag"]
        if producer["status"] == "EOF":
            return False
        tag, sorts = producer["tag"], _SORTS[producer["tag"]]
        groups, lengths, closed, catalogs = [], [], [], []
        for kind in sorts:
            self.c.tick()
            catalog = self.W if kind == "F" else (self.T if kind == "T" else None)
            group = catalog.entries if catalog is not None else self.priority["V"]
            groups.append(group)
            lengths.append(len(group))
            closed.append(catalog.eof if catalog is not None else True)
            catalogs.append(catalog)
        step = _product(producer["state"], lengths, closed, self.c)
        producer["state"] = step["state"]
        if step["kind"] == "EOF":
            producer["status"] = "EOF"
            self.pending_products -= 1
        elif step["kind"] == "WAIT":
            producer["status"] = "WAIT"
            for request in step["requests"]:
                self.c.tick()
                catalog = catalogs[request["slot"]]
                if catalog is not None:
                    catalog.request(index, request["slot"], request["index"])
        elif step["kind"] == "TUPLE":
            producer["status"] = "OPEN"
            witness = []
            for kind, group, at in zip(sorts, groups, step["indices"]):
                self.c.tick()
                witness.append((kind, group[at]))
            self.counts["attempted_primitive_witnesses"] += 1
            if tag < 8:
                ok, formula = self.raw_logical(tag, witness)
                payload = {"tag": tag, "witness": _witness_records(witness)}
                op = "LOGICAL_AXIOM"
            else:
                A, x = witness[0][1], witness[1][1]
                ok, formula, parameters = self.raw_induction(A, x)
                payload = {"tag": 2, "formula": A, "variable": x, "parameters": parameters}
                op = "THEORY_AXIOM"
            if not ok:
                self.refusal(str(formula))
            elif self.raw_equal(formula, node["formula_id"]):
                self.alternative(index, op, [], payload)
        return True

    def mp_step(self):
        if not self.MP_nodes:
            return False
        index = self.MP_nodes.popleft()
        node = self.nodes[index]
        if node["state"] != "SOLVED" and node["MP"]["status"] != "EOF":
            self.MP_nodes.append(index)
        if node["state"] == "SOLVED":
            return False
        cursor = node["MP"]
        if cursor["status"] == "EOF":
            return False
        at = cursor["index"]
        if at >= len(self.U.entries):
            cursor["status"] = "EOF" if self.U.eof else "WAIT"
            if self.U.eof:
                self.pending_MP -= 1
            if not self.U.eof:
                self.U.request(index, 0, at)
            return True
        antecedent = self.U.entries[at]
        cursor["index"] += 1
        cursor["status"] = "OPEN"
        # Temporary shape size avoids retaining a new out-of-domain implication.
        count = 1 + self.a.meta[antecedent]["nodes"] + self.a.meta[node["formula_id"]]["nodes"]
        implication = None
        if count <= self.g["obligation_nodes"]:
            implication = self.a.add("F", "imp", None, (antecedent, node["formula_id"]))
        else:
            for source in self.S:
                self.c.tick()
                row = self.a.rows[source]
                if row[1] == "imp" and row[3] == (antecedent, node["formula_id"]):
                    implication = source
                    break
        if implication is not None and self.universe(implication):
            left = self.want(node["context_id"], antecedent, None, 0)
            right = self.want(node["context_id"], implication, None, 1)
            self.alternative(index, "MP", [left, right], {})
        else:
            self.counts["outside_premises"] += 1
        return True

    def watcher_step(self):
        if not self.notify:
            return False
        kind, number, position = self.notify.popleft()
        if kind == "NODE":
            refs = self.watch_index.get(number, ())
            if position < len(refs):
                watcher = self.watchers[refs[position]]
                watcher["notified"] = True
                self.notify.append(("ALT", watcher["alternative"], 0))
                self.notify.append(("NODE", number, position + 1))
            return True
        alternative = self.alternatives[number]
        owner = self.nodes[alternative["owner"]]
        if owner["state"] == "SOLVED":
            if owner["selected_alternative_id"] != number:
                alternative["status"] = "NOT_NEEDED_FOR_FOUND_WITNESS"
                alternative["view"]["status"] = alternative["status"]
            return True
        if position < len(alternative["premise_ids"]):
            if self.nodes[alternative["premise_ids"][position]]["state"] == "SOLVED":
                self.notify.append(("ALT", number, position + 1))
            return True
        self.solved_serial += 1
        for premise in alternative["premise_ids"]:
            self.c.tick()
            self.c.need(self.nodes[premise]["solved_serial"] < self.solved_serial, "cyclic solved dependency")
        owner["state"], owner["selected_alternative_id"], owner["solved_serial"] = "SOLVED", number, self.solved_serial
        alternative["status"] = "SELECTED"
        alternative["view"]["status"] = "SELECTED"
        for key in ("state", "selected_alternative_id", "solved_serial"):
            owner["view"][key] = owner[key]
        for product in owner["products"]:
            self.c.tick()
            if product["status"] != "EOF":
                self.pending_products -= 1
                product["status"] = "RETIRED_SOLVED"
        if owner["MP"]["status"] != "EOF":
            self.pending_MP -= 1
            owner["MP"]["status"] = "RETIRED_SOLVED"
        op = alternative["operator"]
        if op in ("MP", "GEN", "INTRO"):
            self.counts[op + "_resolutions"] += 1
        elif op in ("HYP", "THEORY_AXIOM") or (op == "RECEPTOR" and
                alternative["witness"]["kind"] in ("HYP", "THEORY_AXIOM")):
            self.counts["source_uses"] += 1
        self.notify.append(("NODE", owner["id"], 0))
        return True

    def registration_step(self):
        if not self.registration:
            return False
        number = self.registration.popleft()
        if self.nodes[number]["state"] == "SOLVED":
            self.registration_jobs.pop(number, None)
            return True
        try:
            next(self.registration_jobs[number])
        except BaseException as error:
            self.c.fault()
            if type(error) is StopIteration:
                self.registration_jobs.pop(number, None)
                return True
            raise
        self.c.fault()
        self.registration.append(number)
        return True

    def catalog_step(self):
        catalogs = (self.T, self.W, self.U)
        at = self.turn[3] % 3
        self.turn[3] += 1
        result = catalogs[at].advance()
        name = ("T", "W_fallback", "U")[at]
        self.r["cursors"]["catalogs"][name]["eof"] = catalogs[at].eof
        self.r["cursors"]["catalogs"][name]["cursor"] = catalogs[at].cursor
        return result

    def ordinary_quiescent(self):
        if self.registration or self.matching or self.notify or not (self.T.eof and self.W.eof and self.U.eof):
            return False
        return self.pending_products == 0 and self.pending_MP == 0

    def selected_plan(self):
        c, a = self.c, self.a
        order, seen, pending = [], set(), [(self.root, False)]
        while pending:
            c.tick()
            node, ready = pending.pop()
            if node in seen:
                continue
            alt = self.alternatives[self.nodes[node]["selected_alternative_id"]]
            if not ready:
                pending.append((node, True))
                for child in reversed(alt["premise_ids"]):
                    c.tick()
                    pending.append((child, False))
            else:
                seen.add(node)
                order.append(node)
        context_set = {0}
        for node in order:
            context = self.nodes[node]["context_id"]
            while context:
                c.tick()
                context_set.add(context)
                context = self.contexts[context]["parent"]
        context_ids, context_rows = {}, []
        for old in sorted(context_set):
            c.tick()
            context_ids[old] = len(context_rows)
            ctx = self.contexts[old]
            context_rows.append({"id": len(context_rows), "parent": None if old == 0 else context_ids[ctx["parent"]],
                                 "opener": None if old == 0 else ctx["opener"], "assumption": ctx["assumption"]})
        rows, outputs = [], {}
        def emit(context, formula, op, refs, payload):
            c.tick()
            number = len(rows)
            rows.append({"id": number, "context": context, "formula": formula,
                         "operator": op, "premises": refs, "payload": payload})
            return number
        for node_id in order:
            c.tick()
            node = self.nodes[node_id]
            alt = self.alternatives[node["selected_alternative_id"]]
            context, f = context_ids[node["context_id"]], node["formula_id"]
            refs = [outputs[x] for x in alt["premise_ids"]]
            op, payload = alt["operator"], _copy(alt["witness"], c)
            if op == "RECEPTOR":
                initial = payload
                kind = initial.pop("kind")
                if kind == "HYP":
                    current_f = self.contexts[node["context_id"]]["gamma"][initial["index"]]
                elif kind == "LOGICAL_AXIOM":
                    witness = [(x["sort"], x.get("id", x.get("value"))) for x in initial["witness"]]
                    ok, current_f = self.q.logical(initial["tag"], witness)
                    c.need(ok, "selected receptor logical invariant")
                elif initial["tag"] == 2:
                    ok, current_f = self.q.induction(initial["formula"], initial["variable"], initial["parameters"])
                    c.need(ok, "selected induction invariant")
                else:
                    current_f = self.q.table[initial["index"]]
                current = emit(context, current_f, kind, [], initial)
                for step in alt["program"]:
                    c.tick()
                    if step["kind"] == "ALL":
                        body = a.rows[current_f][3][0]
                        witness = (("F", body), ("V", step["variable"]), ("T", step["term"]))
                        ok, axiom = self.q.logical(3, witness)
                        c.need(ok, "selected UI guard invariant")
                        q1 = emit(context, axiom, "LOGICAL_AXIOM", [], {"tag": 3, "witness": _witness_records(witness)})
                        current_f = a.rows[axiom][3][1]
                        current = emit(context, current_f, "MP", [current, q1], {})
                    else:
                        current_f = a.rows[current_f][3][1]
                        current = emit(context, current_f, "MP", [refs[step["position"]], current], {})
                c.need(current_f == f, "selected receptor final invariant")
                outputs[node_id] = current
            else:
                if op == "INTRO":
                    payload = {"child_context": context_ids[payload["child_context"]]}
                outputs[node_id] = emit(context, f, op, refs, payload)
        for context in context_rows[1:]:
            c.tick()
            context["opener"] = outputs[context["opener"]]
        # Remove source-sharing duplicate plan nodes not reachable from the root.
        needed, pending = set(), [outputs[self.root]]
        while pending:
            c.tick()
            node = pending.pop()
            if node not in needed:
                needed.add(node)
                pending.extend(rows[node]["premises"])
        remap, final = {}, []
        for row in rows:
            c.tick()
            if row["id"] in needed:
                remap[row["id"]] = len(final)
                final.append(dict(row, id=len(final), premises=[remap[x] for x in row["premises"]]))
        for context in context_rows[1:]:
            c.tick()
            context["opener"] = remap[context["opener"]]
        return {"schema": "FPC-H1-obligation-plan-v1", "arena": a.records(), "contexts": context_rows,
                "nodes": final, "root": remap[outputs[self.root]]}

    def snapshot(self, status, compilation=None):
        c, r = self.c, self.r
        r["status"] = status
        r["arena"] = self.a.records()
        contexts = []
        for ctx in self.contexts:
            c.tick()
            local = []
            for j, (owner, formula) in enumerate(ctx["stack"]):
                c.tick()
                local.append({"owner_intro_obligation_id": owner, "formula_id": formula,
                              "hypothesis_index": len(self.q.gamma) + j})
            FV = set()
            for f in ctx["gamma"]:
                c.tick()
                FV.update(self.a.meta[f]["FV"])
            contexts.append({"id": ctx["id"], "parent_id": ctx["parent"], "root_query_sha256": self.q.pin["sha256"],
                             "local_occurrences": local, "full_Gamma_formula_ids": list(ctx["gamma"]), "FV_union": sorted(FV)})
        r["contexts"] = contexts
        r["obligations"] = []
        for node in self.nodes:
            c.tick()
            r["obligations"].append({key: _copy(node[key], c) for key in
                ("id", "context_id", "formula_id", "origins", "state", "selected_alternative_id", "solved_serial")})
        r["alternatives"] = []
        for alt in self.alternatives:
            c.tick()
            view = {key: _copy(alt[key], c) for key in
                    ("id", "owner", "operator", "premise_ids", "witness", "program", "status")}
            view["key"] = _copy(alt["exact"], c)
            view["guard_receipt"] = _copy(alt["view"]["guard_receipt"], c)
            r["alternatives"].append(view)
        catalogs = {}
        for key, catalog in (("T", self.T), ("W_fallback", self.W), ("U", self.U)):
            c.tick()
            catalogs[key] = {"entries": list(catalog.entries), "eof": catalog.eof,
                             "cursor": _copy(catalog.cursor, c),
                             "requests": _copy([x for x in catalog.requests if not catalog.eof and
                                x["index"] >= len(catalog.entries) and self.nodes[x["owner"]]["state"] != "SOLVED"], c)}
        fallback, descriptors = [], []
        for node in self.nodes:
            c.tick()
            fallback.append({"node": node["id"], "products": _copy(node["products"], c),
                             "MP": _copy(node["MP"], c), "next_tag": node["next_tag"]})
        for descriptor in self.descriptors:
            c.tick()
            descriptors.append({"id": descriptor["id"], "owner": descriptor["owner"], "kind": descriptor["base"]["kind"],
                                "bindings": {kind + ":" + name: value for (kind, name), value in descriptor["bindings"].items()},
                                "residual_sorts": [kind for kind, _ in descriptor["residual"]],
                                "product": _copy(descriptor["product"], c), "score": list(descriptor["score"]),
                                "born": descriptor["born"], "status": descriptor["status"],
                                "requests": _copy(descriptor["requests"], c)})
        r["cursors"] = {"next_lane": self.next_lane, "lane_visits": list(self.lane_visits), "catalogs": catalogs,
                        "node_fallback": fallback, "priority": {"visits": self.priority_visits,
                        "ready": [x for x in self.ready if x in self.active],
                        "oldest": [x for x in self.oldest if x in self.active], "descriptors": descriptors},
                        "watchers": _copy(self.watchers, c)}
        r["coverage"] = {"restricted": True, "exhaustion_claim": False,
                         "all_lanes_quiescent": self.terminal_priority and not self.active,
                         "pending_nodes": sum(x["state"] == "OPEN" for x in self.nodes),
                         "pending_alternatives": sum(x["status"] == "PENDING" for x in self.alternatives),
                         "pending_watchers": len(self.notify), "pending_catalogs": sum(not x.eof for x in (self.T, self.W, self.U)),
                         "intro_depth_refusals": self.counts["intro_depth_refusals"],
                         "outside_premise_counts": self.counts["outside_premises"],
                         "priority_inverse_not_handled": self.counts["priority_inverse_not_handled"],
                         "retirement_counts": self.counts["retired_descriptors"]}
        r["counts"] = dict(self.counts, obligations=len(self.nodes), alternatives=len(self.alternatives),
                           live_descriptors=len(self.active),
                           compiled_primitive_rows=0 if compilation is None else len(compilation["receipt"]["candidate_rows"]),
                           guard_refusals_by_reason=dict(self.guard_reasons), callbacks=c.calls)
        r["operations"]["live_snapshot_complete"] = True
        r["operations"]["live_unavailable_fields"] = []
        if compilation is not None:
            r["candidate_rows"] = compilation["receipt"]["candidate_rows"]
            r["elaboration"] = compilation["receipt"]
        c.tick()

    def close(self):
        # Construction is covered too: missing fields own no generators yet.
        # All iterators below are this Source's own, with no user finally code.
        # No callback is made and no saved progress/receipt object is rewritten.
        preparing = getattr(self, "preparing", None)
        if preparing is not None:
            preparing.close()
            self.preparing = None
        jobs = getattr(self, "registration_jobs", None)
        if jobs is not None:
            for job in jobs.values():
                job.close()
            jobs.clear()
        for name in ("T", "W", "U"):
            catalog = getattr(self, name, None)
            if catalog is not None and catalog.generator is not None:
                catalog.generator.close()
                catalog.generator = None
        arena = getattr(self, "a", None)
        if arena is not None:
            arena.mirror = None

    def run(self):
        if self.outside is not None:
            self.r["scope"]["outside"] = self.outside
            self.snapshot("SOURCE_OUTSIDE_DECLARED_SCOPE")
            return {"status": self.r["status"], "candidate_certificate_bytes": None, "receipt": self.r}
        while True:
            self.c.tick()
            lane = self.next_lane
            self.next_lane = (lane + 1) % 8
            self.lane_visits[lane] += 1
            self.r["cursors"]["next_lane"] = self.next_lane
            self.r["cursors"]["lane_visits"][lane] = self.lane_visits[lane]
            if lane == 0:
                self.registration_step()
            elif lane == 1:
                self.priority_step()
            elif lane == 2:
                self.matcher_step()
            elif lane == 3:
                self.catalog_step()
            elif lane == 4:
                self.fallback_step()
            elif lane == 5:
                self.mp_step()
            elif lane == 6:
                self.watcher_step()
            elif self.nodes[self.root]["state"] == "SOLVED":
                plan = self.selected_plan()
                self.r["selected_plan"] = plan
                compiled = _compile(self.q, plan)
                self.snapshot("CANDIDATE_FOUND", compiled)
                return {"status": "CANDIDATE_FOUND", "candidate_certificate_bytes": compiled["candidate_certificate_bytes"], "receipt": self.r}
            elif self.ordinary_quiescent():
                self.terminal_priority = True
                if not self.active:
                    self.snapshot("UNKNOWN_DECLARED_PRODUCER")
                    return {"status": "UNKNOWN_DECLARED_PRODUCER", "candidate_certificate_bytes": None, "receipt": self.r}


def search_obligations(query_bytes, *, configuration, modules, check, progress=None):
    call = _Call(check)
    receipt = {"schema": _SEARCH_SCHEMA, "version": VERSION, "query": None, "configuration": None,
               "status": "STARTED", "accepted": False, "candidate_validation": "NOT_RUN_EXTERNAL_DUAL_GATE_REQUIRED",
               "scope": {"ordinary_symbolic": True, "exhaustion_claim": False, "no_prefix_authority": True},
               "arena": [], "contexts": [], "obligations": [], "alternatives": [], "sources": [],
               "cursors": {}, "coverage": {}, "counts": {}, "selected_plan": None, "candidate_rows": [],
               "operations": {"old_state_adopted": False, "proof_admitted": False}}
    engine = None
    try:
        if progress is not None:
            call.need(type(progress) is list and not progress, "progress must be exclusive empty list")
            progress.append(receipt)
        g = _copy(configuration, call)
        names = ("schema", "control_only", "variables", "term_depth", "fallback_witness_nodes", "obligation_nodes",
                 "priority_subformula_nodes", "intro_depth", "oldest_period", "ordering")
        _keys(g, names, call, "configuration keys")
        call.need(g["schema"] == "FPC-H1-obligation-configuration-v1" and type(g["control_only"]) is bool and
                  g["ordering"] in ("FOCUSED", "FIFO") and type(g["oldest_period"]) is int and g["oldest_period"] == 4,
                  "configuration schema/order")
        for key, maximum in (("variables", 8), ("term_depth", 2), ("fallback_witness_nodes", 9),
                             ("obligation_nodes", 512), ("priority_subformula_nodes", 512), ("intro_depth", 8)):
            call.tick()
            call.need(_nat(g[key]) and g[key] <= maximum and (g["control_only"] or g[key] == maximum), "configuration bound: " + key)
        q = _Query(query_bytes, modules, call)
        receipt["query"] = dict(q.pin, version=q.decoded["version"], claim_mode=q.decoded["claim_mode"],
                                function_arities=list(q.a.functions), predicate_arities=list(q.a.predicates),
                                theory_profile=q.profile, finite_axioms=[q.a.tree(x) for x in q.table] if q.profile == 0 else [],
                                Gamma=[q.a.tree(x) for x in q.gamma], goal=q.a.tree(q.goal))
        receipt["configuration"] = g
        # Retain the instance before __init__ can call any callback or generator.
        engine = object.__new__(_Engine)
        _Engine.__init__(engine, q, g, receipt)
        for index, formula in enumerate(q.gamma):
            call.tick()
            receipt["sources"].append({"kind": "HYP", "context_id": 0, "index": index, "formula_id": formula})
        for index, formula in enumerate(q.table):
            call.tick()
            receipt["sources"].append({"kind": "THEORY_AXIOM", "tag": 0 if q.profile == 0 else (1 if q.profile == 1 else 3),
                                       "index": index, "formula_id": formula})
        return engine.run()
    except BaseException:
        call.fault()
        raise
    finally:
        if engine is not None:
            try:
                engine.close()
            except BaseException:
                call.fault()
                raise


# The original ordinary definitions above are retained, except VERSION metadata.
# The library extension below owns its snapshots, cursors and selected lowering.
LIBRARY_BINDING_POLICY = "QUERY_FORMULA_SUBFORMULAS_PLUS_ORIGINAL_W_v1"
LIBRARY_ARMS = ("CONDITIONAL_LEMMA_CD", "RECEPTOR_DAG")
_LIBRARY_SCHEMA = "FPC-H1-contextual-library-search-receipt-v1"
_INSTANCE_VERSION = "FPC-RECEPTOR-INSTANCE-SERVICE-v2"


class _LibraryCall(_Call):
    def dependency(self, function, *args, **kwargs):
        self.tick()
        try:
            result = function(*args, **kwargs, check=self.tick)
        except BaseException as error:
            if self.first is None:
                self.first = error
            raise self.first
        self.fault()
        return result


def _library_copy(value, c):
    """Detached acyclic ordinary image, with identity-only external dispatch."""
    import math
    todo, values, active = [("visit", value)], [], set()
    while todo:
        c.tick()
        action, item = todo.pop()
        if action == "array":
            identity, count = item
            children = values[-count:] if count else []
            if count:
                del values[-count:]
            active.remove(identity)
            values.append(children)
        elif action == "mapping":
            identity, names = item
            children = values[-len(names):] if names else []
            if names:
                del values[-len(names):]
            result = {}
            for name, child in zip(names, children):
                c.tick()
                result[name] = child
            active.remove(identity)
            values.append(result)
        elif type(item) is list or type(item) is tuple:
            c.need(id(item) not in active, "cyclic library input")
            active.add(id(item))
            todo.append(("array", (id(item), len(item))))
            for child in reversed(item):
                c.tick()
                todo.append(("visit", child))
        elif type(item) is dict:
            c.need(id(item) not in active, "cyclic library input")
            active.add(id(item))
            names = []
            for name in item:
                c.tick()
                c.need(type(name) is str, "library dictionary key")
                names.append(name)
            todo.append(("mapping", (id(item), names)))
            for name in reversed(names):
                c.tick()
                todo.append(("visit", item[name]))
        else:
            kind = type(item)
            c.need(item is None or kind is str or kind is int or kind is bool or
                   (kind is float and math.isfinite(item)), "finite ordinary library scalar")
            values.append(item)
    c.need(len(values) == 1, "complete library snapshot")
    return values[0]


def _library_equal(left, right, c):
    pending = [(left, right)]
    while pending:
        c.tick()
        a, b = pending.pop()
        aa = type(a) is list or type(a) is tuple
        ba = type(b) is list or type(b) is tuple
        if aa or ba:
            if not (aa and ba and len(a) == len(b)):
                return False
            for index in range(len(a) - 1, -1, -1):
                c.tick()
                pending.append((a[index], b[index]))
        elif type(a) is dict or type(b) is dict:
            if not (type(a) is dict and type(b) is dict and len(a) == len(b)):
                return False
            for key in a:
                c.tick()
                if key not in b:
                    return False
                pending.append((a[key], b[key]))
        elif type(a) is not type(b):
            return False
        elif type(a) is str:
            if len(a) != len(b):
                return False
            for start in range(0, len(a), 4096):
                c.tick()
                if a[start:start + 4096] != b[start:start + 4096]:
                    return False
        elif a != b:
            return False
    return True


def _library_keys(value, names, c, reason):
    c.tick()
    c.need(type(value) is dict and len(value) == len(names), reason)
    for key in value:
        c.tick()
        c.need(type(key) is str, reason)
    for key in names:
        c.tick()
        c.need(key in value, reason)


def _library_pattern(pattern, count, c):
    todo = [pattern]
    while todo:
        c.tick()
        node = todo.pop()
        c.need(type(node) is list and bool(node) and type(node[0]) is str,
               "library Formula pattern")
        if node[0] == "param":
            c.need(len(node) == 2 and _nat(node[1]) and node[1] < count,
                   "library Formula parameter")
        elif node[0] == "not":
            c.need(len(node) == 2, "library not pattern")
            todo.append(node[1])
        else:
            c.need(node[0] == "imp" and len(node) == 3, "library imp pattern")
            todo.append(node[2])
            todo.append(node[1])


def _library_instantiate(pattern, images, arena, c):
    todo, result = [(False, pattern)], []
    while todo:
        c.tick()
        ready, node = todo.pop()
        if not ready:
            if node[0] == "param":
                result.append(images[node[1]])
            else:
                todo.append((True, node))
                if node[0] == "imp":
                    todo.append((False, node[2]))
                todo.append((False, node[1]))
        elif node[0] == "not":
            result.append(arena.add("F", "not", None, (result.pop(),)))
        else:
            right, left = result.pop(), result.pop()
            result.append(arena.add("F", "imp", None, (left, right)))
    c.need(len(result) == 1, "complete simultaneous library substitution")
    return result[0]


def _library_family_inputs(raw, q, instance, c):
    own = _library_copy(raw, c)
    c.need(type(own) is list, "complete family list")
    for family in own:
        c.tick()
        _library_keys(family, ("family_key", "family_id", "parameters", "root_local_id",
            "internal_nodes", "boundary_nodes", "source_occurrences", "distinct_base_nodes",
            "size_band", "validation_provenance"), c, "complete family fields")
        params, nodes, ports = family["parameters"], family["internal_nodes"], family["boundary_nodes"]
        c.need(type(params) is list and type(nodes) is list and type(ports) is list and
               2 <= len(nodes) <= 8 and len(ports) <= 4 and
               type(family["root_local_id"]) is int and family["root_local_id"] == len(nodes) - 1,
               "family preliminary dimensions")
        for index, parameter in enumerate(params):
            _library_keys(parameter, ("id", "sort"), c, "Formula parameter fields")
            c.need(type(parameter["id"]) is int and parameter["id"] == index and
                   parameter["sort"] == "Formula", "Formula parameter sequence")
        for row in ports:
            _library_keys(row, ("boundary_id", "formula_pattern"), c, "boundary fields")
            _library_pattern(row["formula_pattern"], len(params), c)
        for row in nodes:
            _library_keys(row, ("local_id", "rule_tag", "subtag", "formula_pattern",
                                "witness_pattern", "references"), c, "internal fields")
            _library_pattern(row["formula_pattern"], len(params), c)
        # Public matcher validates the entire structural key, equations, source
        # association and graph. The repeated goal images are validation only;
        # they are never a search binding or a donor default.
        images = {}
        for parameter in params:
            c.tick()
            images[parameter["id"]] = q.goal
        inputs = []
        for row in ports:
            c.tick()
            inputs.append(q.a.tree(_library_instantiate(row["formula_pattern"], images, q.a, c)))
        output = q.a.tree(_library_instantiate(nodes[-1]["formula_pattern"], images, q.a, c))
        answer = c.dependency(instance.match_receptor, family, input_formulas=inputs, output_formula=output)
        _library_keys(answer, ("matched", "bindings", "residual_parameters"), c, "matcher intake fields")
        c.need(answer["matched"] is True, "self-instantiated family must match")
    return own


class _LibraryEngine(_Engine):
    def __init__(self, q, configuration, receipt, families, arm, instance):
        self.families, self.arm, self.instance = families, arm, instance
        self.library_queue, self.library_jobs, self.library_records = deque(), {}, []
        self.library_domain, self.library_keys, self.library_seed = [], set(), set()
        self.library_W_position, self.library_turn, self.library_sync_turn = 0, 0, 0
        self.library_offers, self.library_lowering = [], None
        self.library_counts = {name: 0 for name in ("root_mismatches", "bound_outside_domain",
            "binding_tuples", "outside_boundaries", "matcher_mismatches", "registered_offers")}
        super().__init__(q, configuration, receipt)
        # This is before any registration generator is advanced. No boundary
        # generated by this extension can enter the seed.
        for root in q.gamma + q.table + [q.goal]:
            for value, _ in _walk_ids(self.a, root):
                self.c.tick()
                if self.a.rows[value][0] == "F" and self.member("F", value, True):
                    self.library_seed.add(value)
                    if value not in self.library_keys:
                        self.library_keys.add(value)
                        self.library_domain.append(value)
        self.library_seed_order = list(self.library_domain)

    def library_member(self, value):
        self.c.tick()
        return value in self.library_seed or self.member("F", value, False)

    def initialize(self, number):
        for family_index in range(len(self.families)):
            self.c.tick()
            index = len(self.library_records)
            self.library_records.append({"id": index, "owner": number, "family_index": family_index,
                "status": "ROOT_MATCH", "root_bindings": [], "residual_parameters": [],
                "product": None, "requests": []})
            self.library_jobs[index] = self.library_job(index)
            self.library_queue.append(index)
            yield None
        yield from super().initialize(number)

    def library_job(self, index):
        record, c, a = self.library_records[index], self.c, self.a
        owner = self.nodes[record["owner"]]
        family = self.families[record["family_index"]]
        pending = [(family["internal_nodes"][-1]["formula_pattern"], owner["formula_id"])]
        bound = {}
        while pending:
            c.tick()
            pattern, actual = pending.pop()
            if pattern[0] == "param":
                key = pattern[1]
                if key in bound and bound[key] != actual:
                    self.library_counts["root_mismatches"] += 1
                    record["status"] = "ROOT_MISMATCH"
                    return
                bound[key] = actual
            else:
                _, tag, _, children = a.rows[actual]
                if tag != pattern[0]:
                    self.library_counts["root_mismatches"] += 1
                    record["status"] = "ROOT_MISMATCH"
                    return
                if tag == "imp":
                    pending.append((pattern[2], children[1]))
                pending.append((pattern[1], children[0]))
            yield None
        for key in sorted(bound):
            c.tick()
            record["root_bindings"].append({"parameter_id": key, "formula_id": bound[key]})
            if not self.library_member(bound[key]):
                self.library_counts["bound_outside_domain"] += 1
                record["status"] = "BOUND_OUTSIDE_DOMAIN"
                return
            yield None
        residual = []
        for parameter in family["parameters"]:
            c.tick()
            if parameter["id"] not in bound:
                residual.append(parameter["id"])
            yield None
        record["residual_parameters"] = list(residual)
        record["product"] = _product_initial(len(residual))
        while owner["state"] != "SOLVED":
            c.tick()
            closed = self.W.eof and self.library_W_position == len(self.W.entries)
            lengths, closeds = [], []
            for _ in residual:
                c.tick()
                lengths.append(len(self.library_domain)); closeds.append(closed)
            step = _product(record["product"], lengths, closeds, c)
            record["product"], record["requests"] = step["state"], step["requests"]
            record["status"] = step["kind"]
            if step["kind"] == "EOF":
                return
            if step["kind"] == "TUPLE":
                images = dict(bound)
                for parameter, position in zip(residual, step["indices"]):
                    c.tick()
                    images[parameter] = self.library_domain[position]
                self.library_counts["binding_tuples"] += 1
                self.library_offer(record, family, images)
            yield None
        record["status"] = "RETIRED_SOLVED"

    def library_offer(self, record, family, images):
        c, a = self.c, self.a
        owner = self.nodes[record["owner"]]
        inputs, input_ids, binding = [], [], []
        for parameter in family["parameters"]:
            c.tick()
            value = images[parameter["id"]]
            c.need(self.library_member(value), "chosen image outside fixed domain")
            binding.append({"parameter_id": parameter["id"], "formula_id": value, "formula": a.tree(value)})
        for port in family["boundary_nodes"]:
            c.tick()
            value = _library_instantiate(port["formula_pattern"], images, a, c)
            if not self.universe(value):
                self.library_counts["outside_boundaries"] += 1
                return
            input_ids.append(value)
            inputs.append(a.tree(value))
        output = _library_instantiate(family["internal_nodes"][-1]["formula_pattern"], images, a, c)
        c.need(output == owner["formula_id"], "complete binding output equality")
        answer = c.dependency(self.instance.match_receptor, family,
                              input_formulas=inputs, output_formula=a.tree(output))
        _library_keys(answer, ("matched", "bindings", "residual_parameters"), c, "public matcher carrier")
        c.need(type(answer["matched"]) is bool and type(answer["bindings"]) is list and
               type(answer["residual_parameters"]) is list, "public matcher exact carriers")
        if not answer["matched"]:
            self.library_counts["matcher_mismatches"] += 1
            return
        seen = set()
        for row in answer["bindings"]:
            _library_keys(row, ("parameter_id", "formula"), c, "public matcher binding")
            parameter = row["parameter_id"]
            c.need(_nat(parameter) and parameter in images and parameter not in seen,
                   "matcher parameter association")
            c.need(_library_equal(row["formula"], a.tree(images[parameter]), c),
                   "matcher binding agrees with complete chosen binding")
            seen.add(parameter)
        complement = []
        for parameter in family["parameters"]:
            c.tick()
            if parameter["id"] not in seen:
                complement.append(parameter)
        c.need(_library_equal(complement, answer["residual_parameters"], c),
               "exact matcher residual complement including witness-only parameters")
        premises = []
        for position, value in enumerate(input_ids):
            c.tick()
            premises.append(self.want(owner["context_id"], value, None, position))
        payload = {"family_index": record["family_index"], "binding": binding,
                   "boundary_formula_ids": input_ids, "offer_id": len(self.library_offers)}
        alternative = self.alternative(owner["id"], "LIBRARY", premises, payload)
        self.library_offers.append({"id": len(self.library_offers), "owner": owner["id"],
            "context_id": owner["context_id"], "family_index": record["family_index"],
            "family_key": _library_copy(family["family_key"], c), "binding": _library_copy(binding, c),
            "boundary_formula_ids": list(input_ids), "boundary_obligation_ids": list(premises),
            "alternative_id": alternative, "matcher_receipt": _library_copy(answer, c)})
        self.library_counts["registered_offers"] += 1

    def library_step(self):
        self.c.tick()
        self.library_sync_turn += 1
        if self.library_sync_turn % 2 and self.library_W_position < len(self.W.entries):
            value = self.W.entries[self.library_W_position]
            self.library_W_position += 1
            if value not in self.library_keys:
                self.library_keys.add(value)
                self.library_domain.append(value)
            return True
        if not self.library_queue:
            if self.library_W_position < len(self.W.entries):
                value = self.W.entries[self.library_W_position]
                self.library_W_position += 1
                if value not in self.library_keys:
                    self.library_keys.add(value)
                    self.library_domain.append(value)
                return True
            return False
        index = self.library_queue.popleft()
        record = self.library_records[index]
        if self.nodes[record["owner"]]["state"] == "SOLVED":
            self.library_jobs.pop(index).close()
            record["status"] = "RETIRED_SOLVED"
            return True
        try:
            next(self.library_jobs[index])
        except BaseException as error:
            self.c.fault()
            if type(error) is StopIteration:
                self.library_jobs.pop(index)
                return True
            raise
        self.c.fault()
        self.library_queue.append(index)
        return True

    def priority_step(self):
        if not self.families:
            return super().priority_step()
        self.library_turn += 1
        return super().priority_step() if self.library_turn % 2 else self.library_step()

    def ordinary_quiescent(self):
        return (super().ordinary_quiescent() and not self.library_queue and
                (not self.families or self.library_W_position == len(self.W.entries)))

    def lower_library(self, node, alt, context, refs, context_rows, emit):
        c, a = self.c, self.a
        payload = alt["witness"]
        family = self.families[payload["family_index"]]
        images = {}
        for binding in payload["binding"]:
            c.tick()
            images[binding["parameter_id"]] = binding["formula_id"]
        ports = payload["boundary_formula_ids"]
        c.need(len(ports) == len(refs) == len(family["boundary_nodes"]), "selected ordered port completeness")
        body_context, body_ports, added_contexts = context, list(refs), []
        if self.arm == "CONDITIONAL_LEMMA_CD":
            # These are proof-elaboration contexts, not search contexts; search
            # intro_depth never changes the common offer predicate.
            for formula in ports:
                c.tick()
                child = len(context_rows)
                context_rows.append({"id": child, "parent": body_context,
                                     "opener": None, "assumption": formula})
                added_contexts.append(child)
                body_context = child
            body_ports = []
            base = len(self.contexts[node["context_id"]]["gamma"])
            for position, formula in enumerate(ports):
                c.tick()
                body_ports.append(emit(body_context, formula, "HYP", [], {"index": base + position}))
        internals, local_rows = [], []
        for row in family["internal_nodes"]:
            c.tick()
            formula = _library_instantiate(row["formula_pattern"], images, a, c)
            if row["rule_tag"] == 1:
                witness = []
                for pattern in row["witness_pattern"]:
                    c.tick()
                    witness.append({"sort": "F", "id": _library_instantiate(pattern, images, a, c)})
                value = emit(body_context, formula, "LOGICAL_AXIOM", [],
                             {"tag": row["subtag"], "witness": witness})
            else:
                premises = []
                for reference in row["references"]:
                    c.tick()
                    premises.append((internals if reference["kind"] == "internal" else body_ports)[reference["id"]])
                value = emit(body_context, formula, "MP", premises, {})
            internals.append(value)
            local_rows.append({"local_id": row["local_id"], "formula_id": formula, "unpruned_plan_node": value})
        current, current_formula = internals[family["root_local_id"]], node["formula_id"]
        introductions, applications = [], []
        if self.arm == "CONDITIONAL_LEMMA_CD":
            for position in range(len(ports) - 1, -1, -1):
                c.tick()
                child = added_contexts[position]
                parent = context_rows[child]["parent"]
                current_formula = a.add("F", "imp", None, (ports[position], current_formula))
                current = emit(parent, current_formula, "INTRO", [current], {"child_context": child})
                context_rows[child]["opener"] = current
                introductions.append(current)
            for position, premise in enumerate(refs):
                c.tick()
                _, tag, _, children = a.rows[current_formula]
                c.need(tag == "imp" and children[0] == ports[position], "ordered conditional lemma application")
                current_formula = children[1]
                current = emit(context, current_formula, "MP", [premise, current], {})
                applications.append(current)
        c.need(current_formula == node["formula_id"], "selected library final Formula")
        boundaries = []
        for position, (proof, body) in enumerate(zip(refs, body_ports)):
            c.tick()
            obligation = self.nodes[alt["premise_ids"][position]]
            c.need(obligation["context_id"] == node["context_id"] and
                   obligation["formula_id"] == ports[position] and
                   obligation["solved_serial"] < node["solved_serial"], "strict same-context proved boundary")
            boundaries.append({"boundary_id": position, "formula_id": ports[position],
                "obligation_id": obligation["id"], "proof_serial": obligation["solved_serial"],
                "unpruned_proof_plan_node": proof, "unpruned_body_plan_node": body})
        return current, {"application_id": len(self.library_lowering["applications"]),
            "offer_id": payload["offer_id"], "owner_obligation_id": node["id"],
            "owner_context_id": node["context_id"], "selected_alternative_id": alt["id"],
            "selected_serial": node["solved_serial"], "family_index": payload["family_index"],
            "family_key": _library_copy(family["family_key"], c),
            "binding": _library_copy(payload["binding"], c), "arm": self.arm,
            "boundaries": boundaries, "internal_nodes": local_rows,
            "lowering_context_ids": added_contexts, "unpruned_INTRO_nodes": introductions,
            "unpruned_application_MP_nodes": applications, "unpruned_output_plan_node": current}

    def selected_plan(self):
        c, a = self.c, self.a
        order, seen, pending = [], set(), [(self.root, False)]
        while pending:
            c.tick()
            node, ready = pending.pop()
            if node in seen:
                continue
            alt = self.alternatives[self.nodes[node]["selected_alternative_id"]]
            if not ready:
                pending.append((node, True))
                for child in reversed(alt["premise_ids"]):
                    c.tick()
                    pending.append((child, False))
            else:
                seen.add(node)
                order.append(node)
        context_set = {0}
        for node in order:
            context = self.nodes[node]["context_id"]
            while context:
                c.tick()
                context_set.add(context)
                context = self.contexts[context]["parent"]
        context_ids, context_rows = {}, []
        for old in sorted(context_set):
            c.tick()
            context_ids[old] = len(context_rows)
            ctx = self.contexts[old]
            context_rows.append({"id": len(context_rows), "parent": None if old == 0 else context_ids[ctx["parent"]],
                                 "opener": None if old == 0 else ctx["opener"], "assumption": ctx["assumption"]})
        original_context_count = len(context_rows)
        rows, outputs = [], {}
        self.library_lowering = {"applications": [], "pruning": [], "context_map": [],
                                 "symbolic_placement_claim": False}
        def emit(context, formula, op, refs, payload):
            c.tick()
            number = len(rows)
            own_refs = []
            for reference in refs:
                c.tick()
                own_refs.append(reference)
            rows.append({"id": number, "context": context, "formula": formula,
                         "operator": op, "premises": own_refs, "payload": payload})
            return number
        for node_id in order:
            c.tick()
            node = self.nodes[node_id]
            alt = self.alternatives[node["selected_alternative_id"]]
            context, f = context_ids[node["context_id"]], node["formula_id"]
            refs = []
            for premise in alt["premise_ids"]:
                c.tick()
                refs.append(outputs[premise])
            op, payload = alt["operator"], _copy(alt["witness"], c)
            if op == "LIBRARY":
                output, application = self.lower_library(node, alt, context, refs, context_rows, emit)
                outputs[node_id] = output
                self.library_lowering["applications"].append(application)
            elif op == "RECEPTOR":
                initial = payload
                kind = initial.pop("kind")
                if kind == "HYP":
                    current_f = self.contexts[node["context_id"]]["gamma"][initial["index"]]
                elif kind == "LOGICAL_AXIOM":
                    witness = [(x["sort"], x.get("id", x.get("value"))) for x in initial["witness"]]
                    ok, current_f = self.q.logical(initial["tag"], witness)
                    c.need(ok, "selected receptor logical invariant")
                elif initial["tag"] == 2:
                    ok, current_f = self.q.induction(initial["formula"], initial["variable"], initial["parameters"])
                    c.need(ok, "selected induction invariant")
                else:
                    current_f = self.q.table[initial["index"]]
                current = emit(context, current_f, kind, [], initial)
                for step in alt["program"]:
                    c.tick()
                    if step["kind"] == "ALL":
                        body = a.rows[current_f][3][0]
                        witness = (("F", body), ("V", step["variable"]), ("T", step["term"]))
                        ok, axiom = self.q.logical(3, witness)
                        c.need(ok, "selected UI guard invariant")
                        q1 = emit(context, axiom, "LOGICAL_AXIOM", [], {"tag": 3, "witness": _witness_records(witness)})
                        current_f = a.rows[axiom][3][1]
                        current = emit(context, current_f, "MP", [current, q1], {})
                    else:
                        current_f = a.rows[current_f][3][1]
                        current = emit(context, current_f, "MP", [refs[step["position"]], current], {})
                c.need(current_f == f, "selected receptor final invariant")
                outputs[node_id] = current
            else:
                if op == "INTRO":
                    payload = {"child_context": context_ids[payload["child_context"]]}
                outputs[node_id] = emit(context, f, op, refs, payload)
        for context in context_rows[1:original_context_count]:
            c.tick()
            context["opener"] = outputs[context["opener"]]
        needed, pending = set(), [outputs[self.root]]
        while pending:
            c.tick()
            node = pending.pop()
            if node not in needed:
                needed.add(node)
                for premise in rows[node]["premises"]:
                    c.tick()
                    pending.append(premise)
        remap, final = {}, []
        for row in rows:
            c.tick()
            if row["id"] in needed:
                remap[row["id"]] = len(final)
                references = []
                for premise in row["premises"]:
                    c.tick()
                    references.append(remap[premise])
                final.append(dict(row, id=len(final), premises=references))
            self.library_lowering["pruning"].append({"unpruned_plan_node": row["id"],
                                                     "plan_node": remap.get(row["id"])})
        for context in context_rows[1:]:
            c.tick()
            c.need(context["opener"] in remap, "selected context opener survives pruning")
            context["opener"] = remap[context["opener"]]
        for old, new in context_ids.items():
            c.tick()
            self.library_lowering["context_map"].append({"search_context": old, "plan_context": new})
        for application in self.library_lowering["applications"]:
            for row in application["internal_nodes"]:
                c.tick()
                row["plan_node"] = remap.get(row["unpruned_plan_node"])
            for row in application["boundaries"]:
                c.tick()
                row["proof_plan_node"] = remap.get(row["unpruned_proof_plan_node"])
                row["body_plan_node"] = remap.get(row["unpruned_body_plan_node"])
            for source, target in (("unpruned_INTRO_nodes", "INTRO_nodes"),
                                   ("unpruned_application_MP_nodes", "application_MP_nodes")):
                application[target] = []
                for value in application[source]:
                    c.tick()
                    application[target].append(remap.get(value))
            application["output_plan_node"] = remap.get(application["unpruned_output_plan_node"])
        return {"schema": "FPC-H1-obligation-plan-v1", "arena": a.records(), "contexts": context_rows,
                "nodes": final, "root": remap[outputs[self.root]]}

    def library_compiler_maps(self, compilation):
        c = self.c
        plan, receipt = self.r["selected_plan"], compilation["receipt"]
        primitive, plan_images, export = receipt["primitive_nodes"], {}, {}
        for row in receipt["plan_outputs"]:
            c.tick()
            c.need(row["node"] == len(plan_images), "complete compiler plan output order")
            plan_images[row["node"]] = row["primitive"]
        c.need(len(plan_images) == len(plan["nodes"]), "every lowered plan node has an image")
        quotient, associations = {}, []
        discharge_by_intro = {}
        for record in receipt["discharges"]:
            c.tick()
            c.need(record["intro_node"] not in discharge_by_intro, "unique occurrence discharge")
            discharge_by_intro[record["intro_node"]] = record
        for row in plan["nodes"]:
            c.tick()
            image = plan_images[row["id"]]
            actual = primitive[image]
            c.need(actual["id"] == image and actual["context"] == row["context"] and
                   actual["formula"] == row["formula"], "compiler context/Formula image")
            op, payload = row["operator"], row["payload"]
            if op == "INTRO":
                c.need(row["id"] in discharge_by_intro, "complete INTRO transformation record")
                record = discharge_by_intro[row["id"]]
                child_image = plan_images[row["premises"][0]]
                found = False
                for edge in record["mapping"]:
                    c.tick()
                    if edge["input_primitive"] == child_image:
                        c.need(edge["output_primitive"] == image, "INTRO root transform image")
                        found = True
                c.need(found and record["child_context"] == payload["child_context"] and
                       record["parent_context"] == row["context"], "INTRO exact context ownership")
            else:
                expected_rule = {"HYP": 0, "LOGICAL_AXIOM": 1, "THEORY_AXIOM": 2, "MP": 3, "GEN": 4}[op]
                expected_subtag = payload.get("tag") if op == "LOGICAL_AXIOM" or op == "THEORY_AXIOM" else None
                expected_refs = []
                for reference in row["premises"]:
                    c.tick()
                    expected_refs.append(plan_images[reference])
                c.need(actual["rule_tag"] == expected_rule and actual["subtag"] == expected_subtag and
                       _library_equal(actual["witness"], payload, c) and
                       _library_equal(actual["premises"], expected_refs, c),
                       "exact compiler key: rule/subtag/witness/ordered premises")
            quotient.setdefault(image, []).append(row["id"])
            associations.append({"plan_node": row["id"], "primitive": image,
                                 "checked_complete_key": op != "INTRO", "INTRO": op == "INTRO"})
        for row in receipt["export_map"]:
            c.tick()
            c.need(row["primitive"] not in export, "unique exported primitive")
            export[row["primitive"]] = row["row"]
        root = plan_images[plan["root"]]
        reachable, todo = set(), [root]
        while todo:
            c.tick()
            number = todo.pop()
            if number not in reachable:
                reachable.add(number)
                for child in primitive[number]["premises"]:
                    c.tick()
                    todo.append(child)
        c.need(len(reachable) == len(export), "complete final root export domain")
        for number in reachable:
            c.tick()
            c.need(number in export, "every final dependency exported")
            wire = receipt["candidate_rows"][export[number]]
            actual = primitive[number]
            c.need(wire["primitive"] == number and wire["rule_tag"] == actual["rule_tag"] and
                   wire["subtag"] == actual["subtag"] and
                   _library_equal(wire["formula"], self.a.tree(actual["formula"]), c), "export Formula/rule association")
            refs = []
            for child in actual["premises"]:
                c.tick()
                refs.append(export[child])
            c.need(_library_equal(wire["references"], refs, c), "ordered wire premise map")
            data, rule = actual["witness"], actual["rule_tag"]
            if rule == 0:
                witness = data["index"]
            elif rule == 1:
                witness = []
                for field in data["witness"]:
                    c.tick()
                    witness.append(field["value"] if field["sort"] == "V" else self.a.tree(field["id"]))
            elif rule == 2:
                witness = ([self.a.tree(data["formula"]), data["variable"], data["parameters"]]
                           if data["tag"] == 2 else data["index"])
            elif rule == 3:
                witness = None
            else:
                witness = data["variable"]
            c.need(_library_equal(wire["witness"], witness, c), "complete original wire witness association")
        def trace(plan_node):
            c.tick()
            if plan_node is None:
                return {"status": "PRUNED", "primitive": None, "transformations": [], "final_primitive": None, "wire_row": None}
            current, transformations = plan_images[plan_node], []
            initial = current
            for discharge_index, record in enumerate(receipt["discharges"]):
                c.tick()
                before = primitive[current]
                if before["context"] != record["child_context"]:
                    continue
                found = None
                for edge_index, edge in enumerate(record["mapping"]):
                    c.tick()
                    if edge["input_primitive"] == current:
                        c.need(found is None, "unique discharge input image")
                        found = edge
                        found_index = edge_index
                if found is None:
                    continue
                after = primitive[found["output_primitive"]]
                assumption = plan["contexts"][record["child_context"]]["assumption"]
                expected = self.a.add("F", "imp", None, (assumption, before["formula"]))
                c.need(after["context"] == record["parent_context"] and after["formula"] == expected,
                       "discharge transformation context and implication Formula")
                transformations.append({"intro_node": record["intro_node"],
                    "child_context": record["child_context"], "parent_context": record["parent_context"],
                    "assumption_formula_id": assumption,
                    "discharged_hypothesis_index": record["discharged_hypothesis_index"],
                    "edge": _library_copy(found, c), "discharge_record_index": discharge_index,
                    "mapping_edge_index": found_index,
                    "full_record_path": ["elaboration", "discharges", discharge_index]})
                current = found["output_primitive"]
            return {"status": "FINAL_ROOT_DEPENDENCY" if current in reachable else "NOT_FINAL_ROOT_DEPENDENCY",
                "primitive": initial, "transformations": transformations, "final_primitive": current,
                "wire_row": export.get(current)}
        for application in self.library_lowering["applications"]:
            c.tick()
            application["output_trace"] = trace(application["output_plan_node"])
            for row in application["internal_nodes"]:
                c.tick()
                row["trace"] = trace(row["plan_node"])
            for row in application["boundaries"]:
                c.tick()
                row["proof_trace"], row["body_trace"] = trace(row["proof_plan_node"]), trace(row["body_plan_node"])
            application["all_internal_images_final"] = True
            for row in application["internal_nodes"]:
                c.tick()
                if row["trace"]["status"] != "FINAL_ROOT_DEPENDENCY":
                    application["all_internal_images_final"] = False
        groups = []
        for image, nodes in quotient.items():
            c.tick()
            groups.append({"primitive": image, "plan_nodes": nodes, "many_to_one": len(nodes) > 1})
        return {"plan_associations": associations, "quotient_groups": groups,
                "final_root_primitive": root, "final_root_dependencies": sorted(reachable),
                "distinct_final_rows": len(export), "origins_are_mapping_authority": False,
                "external_same_byte_dual_validation": "NOT_RUN_REQUIRED"}

    def snapshot(self, status, compilation=None):
        super().snapshot(status, compilation)
        c = self.c
        library = {"binding_policy": LIBRARY_BINDING_POLICY, "arm": self.arm,
            "families": _library_copy(self.families, c), "domain_seed": list(self.library_seed_order),
            "domain_entries": list(self.library_domain), "W_consumed": self.library_W_position,
            "domain_eof": self.W.eof and self.library_W_position == len(self.W.entries),
            "priority_sublane_visits": self.library_turn,
            "sync_sublane_visits": self.library_sync_turn,
            "records": _library_copy(self.library_records, c), "queue": list(self.library_queue),
            "offers": _library_copy(self.library_offers, c), "counts": dict(self.library_counts),
            "selected_lowering": None, "compiler_maps": None,
            "accepted": False, "proof_use_admitted": False}
        if compilation is not None:
            library["compiler_maps"] = self.library_compiler_maps(compilation)
            library["selected_lowering"] = _library_copy(self.library_lowering, c)
        self.r["library"] = library
        self.r["schema"], self.r["version"] = _LIBRARY_SCHEMA, VERSION
        self.r["counts"]["callbacks"] = c.calls
        c.tick()

    def close(self):
        for job in getattr(self, "library_jobs", {}).values():
            job.close()
        if hasattr(self, "library_jobs"):
            self.library_jobs.clear()
        super().close()


def search_with_library(query_bytes, *, families, arm, configuration, modules, check, progress=None):
    """Shared finite contextual search; only selected proof lowering uses arm.

    A normal candidate is primitive but NOT validated or admitted here. The
    exclusive caller must check the identical original query/certificate bytes
    with both original validators and associate every claimed final-use map.
    """
    call = _LibraryCall(check)
    receipt = {"schema": _LIBRARY_SCHEMA, "version": VERSION, "query": None, "configuration": None,
               "status": "STARTED", "accepted": False, "candidate_validation": "NOT_RUN_EXTERNAL_DUAL_GATE_REQUIRED",
               "scope": {"ordinary_symbolic": True, "exhaustion_claim": False, "no_prefix_authority": True},
               "arena": [], "contexts": [], "obligations": [], "alternatives": [], "sources": [],
               "cursors": {}, "coverage": {}, "counts": {}, "selected_plan": None, "candidate_rows": [],
               "library": None, "operations": {"old_state_adopted": False, "proof_admitted": False}}
    engine = None
    try:
        call.tick()
        call.need(type(arm) is str and arm in LIBRARY_ARMS, "declared library arm")
        _library_keys(modules, ("checker", "builders", "instance"), call, "library module roles")
        instance = modules["instance"]
        instance_version = getattr(instance, "VERSION", None)
        call.need(type(instance_version) is str and instance_version == _INSTANCE_VERSION,
                  "original public instance2 namespace")
        call.need(callable(getattr(instance, "match_receptor", None)), "public match_receptor callable")
        if progress is not None:
            call.need(type(progress) is list and not progress, "progress must be exclusive empty list")
            progress.append(receipt)
        g = _library_copy(configuration, call)
        names = ("schema", "control_only", "variables", "term_depth", "fallback_witness_nodes", "obligation_nodes",
                 "priority_subformula_nodes", "intro_depth", "oldest_period", "ordering")
        _library_keys(g, names, call, "configuration keys")
        call.need(g["schema"] == "FPC-H1-obligation-configuration-v1" and type(g["control_only"]) is bool and
                  type(g["ordering"]) is str and g["ordering"] in ("FOCUSED", "FIFO") and
                  type(g["oldest_period"]) is int and g["oldest_period"] == 4, "configuration schema/order")
        for key, maximum in (("variables", 8), ("term_depth", 2), ("fallback_witness_nodes", 9),
                             ("obligation_nodes", 512), ("priority_subformula_nodes", 512), ("intro_depth", 8)):
            call.tick()
            call.need(_nat(g[key]) and g[key] <= maximum and (g["control_only"] or g[key] == maximum),
                      "configuration bound: " + key)
        original_modules = {"checker": modules["checker"], "builders": modules["builders"]}
        q = _Query(query_bytes, original_modules, call)
        own = _library_family_inputs(families, q, instance, call)
        receipt["query"] = dict(q.pin, version=q.decoded["version"], claim_mode=q.decoded["claim_mode"],
                                function_arities=list(q.a.functions), predicate_arities=list(q.a.predicates),
                                theory_profile=q.profile, finite_axioms=[q.a.tree(x) for x in q.table] if q.profile == 0 else [],
                                Gamma=[q.a.tree(x) for x in q.gamma], goal=q.a.tree(q.goal))
        receipt["configuration"] = g
        engine = object.__new__(_LibraryEngine)
        _LibraryEngine.__init__(engine, q, g, receipt, own, arm, instance)
        for index, formula in enumerate(q.gamma):
            call.tick()
            receipt["sources"].append({"kind": "HYP", "context_id": 0, "index": index, "formula_id": formula})
        for index, formula in enumerate(q.table):
            call.tick()
            receipt["sources"].append({"kind": "THEORY_AXIOM", "tag": 0 if q.profile == 0 else (1 if q.profile == 1 else 3),
                                       "index": index, "formula_id": formula})
        result = engine.run()
        # Detached normal data preserves every field; no receipt is fetched or
        # reconstructed after an error. Immutable certificate bytes are retained.
        return {"status": result["status"], "candidate_certificate_bytes": result["candidate_certificate_bytes"],
                "receipt": _library_copy(result["receipt"], call)}
    except BaseException as error:
        if call.first is None:
            call.first = error
        raise call.first
    finally:
        if engine is not None:
            try:
                engine.close()
            except BaseException as error:
                if call.first is None:
                    call.first = error
                raise call.first
