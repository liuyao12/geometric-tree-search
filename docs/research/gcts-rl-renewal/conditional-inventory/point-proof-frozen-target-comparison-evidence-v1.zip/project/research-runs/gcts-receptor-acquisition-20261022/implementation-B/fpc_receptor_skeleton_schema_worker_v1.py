"""Bounded fixed-skeleton schema feasibility caller; inert Source authorship.

Only a prospectively reviewed once child loads seven exact namespaces and the
declared admitted library data. No selector, donor certificate, search, holdout,
old qualifier, private service getter or theorem route enters this profile.
"""
from pathlib import Path
import hashlib
import importlib.util
import json
import math
import os
import resource
import sys
import time
import traceback

VERSION = 'FPC-receptor-skeleton-schema-worker-v1'
EXPERIMENT = 'admitted-library-skeleton-schema-feasibility-v1'
PROTOCOL_SCHEMA = 'Root-FPC-skeleton-schema-feasibility-protocol-v1'
PROFILE = 'skeleton-schema-whole-feasibility-v1'
CASE = 'admitted-library-skeleton-schema-feasibility-v1-case-0'
MODULE_ROLES = ('checker', 'builders', 'reference', 'instance', 'tiny_encoder', 'schema', 'schema_bank')
MODULE_PINS = {'checker': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/implementation-B/fpc_h1_byte_checker_v1.py',
             'bytes': 31557,
             'sha256': '140a9c4b7a6a18c4c20aa4294a0f3fa90f65fe319adbf47a22125170f32b2ef7'},
 'builders': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/implementation-B/fpc_h1_ast_and_builders_v1.py',
              'bytes': 11348,
              'sha256': 'a42aa71f1e5482a1e1d9637290b4c7f8b52f366d86f7234a86cb11420171ed32'},
 'reference': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/diagnostics-L/fpc_h1_independent_reference_v2.py',
               'bytes': 24681,
               'sha256': 'ecda2a10feb69e5aed6ae34dc6c2123dbbc3297ab5c0a431861d628e9cd4334a'},
 'instance': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/fpc_receptor_instance_service_v2.py',
              'bytes': 46609,
              'sha256': '7b7ca98d3e3dd2e48680d5f499594a8ec7322753bf7a6e8511d5cc667526fae9'},
 'tiny_encoder': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/diagnostics-L/tiny_fpc_query_encoder_v1.py',
                  'bytes': 9018,
                  'sha256': '154615acacc813239d6cf005c82aa37fce96e631098f6408a8798a981a08455d'},
 'schema': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/fpc_receptor_skeleton_schema_v1.py',
            'bytes': 32008,
            'sha256': '6d2aedd01f5fc6dc85e9c908bcd947e9d9aba04e68b2bc18f2107bfd81363338'},
 'schema_bank': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/diagnostics-L/fpc_receptor_skeleton_schema_independent_bank_v1.py',
                 'bytes': 21081,
                 'sha256': '4106228b297edf30178d86a56aa29a7df8ec6e39178fe0cb9600cd4eab2efb1f'}}
MODULE_VERSIONS = {'checker': 'FPC-H1-BYTE-CHECKER-v1',
 'builders': 'FPC-H1-AST-BUILDERS-v1',
 'reference': 'FPC-H1-independent-flat-reference-v2',
 'instance': 'FPC-RECEPTOR-INSTANCE-SERVICE-v2',
 'tiny_encoder': 'L-tiny-FPC-query-encoder-v1',
 'schema': 'FPC-RECEPTOR-SKELETON-SCHEMA-v1',
 'schema_bank': 'FPC-RECEPTOR-SKELETON-SCHEMA-INDEPENDENT-BANK-v1'}
CONTROL_IDS = {'skeleton_schema6': ('schema-equations',
                      'accidental-equality-removal',
                      'ordered-node-source-identity',
                      'detached-specialization',
                      'invalid-input',
                      'first-fault-dependency')}
CONTROL_POPULATIONS = [{'population': 'skeleton_schema6',
  'control_ids': ['schema-equations',
                  'accidental-equality-removal',
                  'ordered-node-source-identity',
                  'detached-specialization',
                  'invalid-input',
                  'first-fault-dependency'],
  'groups': 6,
  'bank_role': 'schema_bank',
  'subject_role': ['schema', 'instance'],
  'scope': 'Synthetic public fixed-skeleton inference controls only; no donor, transfer, library, principal-schema, '
           'GCTS or RL admission.'}]
CAPS = {'work_seconds': 160,
 'positive_seconds': 180,
 'custody_seconds': 210,
 'observer_fallback_seconds': 225,
 'memory_bytes': 1073741824,
 'physical_bytes': 134217728,
 'result_bytes': 50331648,
 'log_bytes': 4194304,
 'reserved_outer_bytes': 9437184,
 'root_callbacks': 400000000}
INPUT_AUTHORITY = {'library_admission': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/receptor-library-extract-0-Root-complete-whole-admission-v1.json',
                       'bytes': 18410,
                       'sha256': '3200dfbb02b421372ce9e21a3a26081b7e2a1b1088407b1f419896dfa848079f'},
 'library_result': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/actual/two-admitted-donor-receptor-library-feasibility-v1-extract-0/result.json',
                    'bytes': 23499000,
                    'sha256': 'caa9569363b28eef0265384dc9b8d0df54805a46ba229d85364a0848ec7cddac'},
 'family_order_and_count': 'Exactly the complete admitted extraction_result.families in saved order, four entries; '
                           'check each complete key/id/source maps against the admitted summaries. No old '
                           'proof/quota/case re-execution.',
 'context_queries': [{'donor_id': 'donor0',
                      'query': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/actual/signed-propositional-cohort-proof-benchmark-v1-donor-0/query.bin',
                                'bytes': 30,
                                'sha256': '353d584927c405f1350729890920dee7265f03f3af148855e171c4cc52e77169'}},
                     {'donor_id': 'donor1',
                      'query': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/actual/signed-propositional-cohort-proof-benchmark-v1-donor-1/query.bin',
                                'bytes': 37,
                                'sha256': 'de00382d25dc4a96696ce98fc7bfa95c87ef9c8a51440390fa0e4cb6d3c063b5'}}],
 'data_scope': 'Only the exact admitted library result and two original context query bodies may be read '
               'scientifically inside once. No donor certificate/search/selector/holdout/old bank rerun. Metadata '
               'Sources/admissions/contracts are raw guard inputs only. Full library result is authenticated before '
               'parsing; only original admitted families become this inference input.'}
SOURCE_COMPONENTS = [{'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/receptor-skeleton-schema-Root-Source-component-acceptance-v1.json',
  'bytes': 5610,
  'sha256': 'b1790a6ba8b206569e82f0a042f3143e5bc070aabbfb2df803985cd2d1997a12'},
 {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/receptor-skeleton-schema6-bank-Root-Source-component-acceptance-v1.json',
  'bytes': 5343,
  'sha256': '898922a645122c422fcd2f193f96f40d12d19ce009231fdedcc130a0daeca677'}]
CUSTODY_RUNTIME = {'runner': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-conditional-selector-main-20261021/root/run_conditional_once_v1.py',
            'bytes': 12973,
            'sha256': '98c55321bb87a8c04b2c6d56b357aba9c3a8f5fc98660474ae3ac1c9d00b0aca'},
 'observer': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-conditional-selector-main-20261021/root/observe_conditional_once_v1.py',
              'bytes': 10113,
              'sha256': '24804c7d4558d8df511942d9e6b2e4d8d2cfd88ce7df6f5b5f775f87d0c20ca9'},
 'python': {'bytes': 18058560,
            'path': '/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12',
            'sha256': 'b6ea0c2a9bfce48dbf181a53f1ca4f0562d40658b85bf47258e2a88d8f9e3933'}}
REQUIRED_METADATA_GUARDS = [{'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/skeleton-schema-whole-feasibility-Source-CONTRACT-v1.json',
  'bytes': 13608,
  'sha256': '2db0e3b9fc256c42c82b45e451effd0ec5852811f3afc82451cda0675f41a822'},
 {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/receptor-skeleton-schema-API-v1.json',
  'bytes': 8556,
  'sha256': '8b4c61f7b9531b466710658eb2029041be817139840a2c982b948a6ea422302b'},
 {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/receptor-skeleton-schema-cost-and-fault-manual-v1.json',
  'bytes': 10361,
  'sha256': '7992191379fa208afe5f6c983361a0abe9745c90edc13725e223f10536a80a80'},
 {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/receptor-skeleton-schema-Source-handoff-v1.json',
  'bytes': 3591,
  'sha256': 'f6ec99f202366cfd7b56a1d382ef051236bd1555f1e9b5e716c29dd86813b244'},
 {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/receptor-family-and-instance-API-v2.json',
  'bytes': 27122,
  'sha256': '74f10ef380e7a86c145d18e3e27f12aefedbaeebf55f2bf7853fded14275a917'},
 {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/diagnostics-L/receptor-skeleton-schema6-independent-bank-Source-handoff-v1.json',
  'bytes': 16270,
  'sha256': '8816db27508cb676a5f83edd0b4355beed701fdaeeec5e3cfec3d30bf3fc3c82'},
 {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/receptor-skeleton-schema-Root-Source-component-acceptance-v1.json',
  'bytes': 5610,
  'sha256': 'b1790a6ba8b206569e82f0a042f3143e5bc070aabbfb2df803985cd2d1997a12'},
 {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/receptor-skeleton-schema6-bank-Root-Source-component-acceptance-v1.json',
  'bytes': 5343,
  'sha256': '898922a645122c422fcd2f193f96f40d12d19ce009231fdedcc130a0daeca677'},
 {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/review-C/typed-receptor-skeleton-schema-complete-component-Source-review-v1.json',
  'bytes': 10684,
  'sha256': '248c60963223514892f122595eaeb91188ed9944ec34238a9e5f0b9d48cc664f'},
 {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/review-C/typed-receptor-skeleton-schema6-independent-bank-complete-Source-review-v1.json',
  'bytes': 13746,
  'sha256': '87134ed0288f31a3242c2469fade772d52d7361860a990cf1637f01352abf937'},
 {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/receptor-library-extract-0-Root-complete-whole-admission-v1.json',
  'bytes': 18410,
  'sha256': '3200dfbb02b421372ce9e21a3a26081b7e2a1b1088407b1f419896dfa848079f'},
 {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/review-C/typed-receptor-library-extract-0-complete-whole-actual-review-v1.json',
  'bytes': 27189,
  'sha256': 'c6a70c6276d250bc2252a74e3ffcfc3c39cd8b7ee3b407687240f487ca06a5a6'}]
POLICY_BINDING = ('FPC-original-json-integer-policy-v1', 4300)
PLAN_FIELDS = ('schema',
 'case_id',
 'stage',
 'experiment',
 'actual_dir',
 'worker_path',
 'runner_path',
 'python',
 'files',
 'limits',
 'protocol',
 'profile',
 'module_pins',
 'input_authority',
 'Source_components')
QUERY_FIELDS = ('version', 'claim_mode', 'function_arities', 'predicate_arities', 'theory_profile', 'finite_axioms', 'Gamma', 'goal')
INSTANCE_FIELDS = ('schema',
 'complete',
 'accepted',
 'context_query_identity',
 'binding',
 'expansion_rows',
 'family_to_wire_rows',
 'boundary_query_bytes',
 'boundary_certificate_bytes',
 'subject_receipt',
 'reference_receipt')
SCHEMA_FIELDS = ('schema',
 'version',
 'complete',
 'accepted',
 'library_admitted',
 'method',
 'source_family',
 'family',
 'specialization',
 'source_associations',
 'input_guards',
 'output_guards',
 'costs',
 'scope')
SCHEMA_COST_FIELDS = ('successful_callbacks',
 'copy_visits',
 'comparison_visits',
 'fresh_metavariables',
 'unification_pairs',
 'dereference_steps',
 'occurs_visits',
 'resolved_term_visits',
 'normalization_visits',
 'specialization_pairs',
 'equation_checks',
 'source_backprojection_checks',
 'public_input_guard_calls',
 'public_output_guard_calls',
 'canonical_bytes')
POSITIVE_FIELDS = ('library_provenance',
 'input_freeze',
 'schema6_qualification',
 'inference_results',
 'source_instance_results',
 'generic_exercise_results',
 'scientific_result')
PUBLIC_ENTRIES = {'checker': ('decode_query', 'check_certificate'),
 'builders': ('logical_axiom',),
 'reference': ('reference_check_certificate',),
 'instance': ('match_receptor', 'compile_instance'),
 'tiny_encoder': ('encode_tiny_declared_query',),
 'schema': ('infer_schematic_family',),
 'schema_bank': ('run_bank',)}

class RootBudget(RuntimeError):
    """Genuine whole-caller resource or complete-output ceiling."""


def raw_pin(path):
    path = Path(path)
    if (not path.is_absolute() or path.is_symlink() or path.resolve() != path
            or not path.is_file() or '.partial' in path.name):
        raise ValueError('canonical complete ordinary raw body required')
    body = path.read_bytes()
    return dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def pin_fields(row):
    if not (type(row) is dict and {'path', 'bytes', 'sha256'} <= set(row)
            and type(row['path']) is str and type(row['bytes']) is int
            and row['bytes'] >= 0 and type(row['sha256']) is str
            and len(row['sha256']) == 64
            and all(c in '0123456789abcdef' for c in row['sha256'])):
        raise ValueError('typed raw identity required')
    return {key: row[key] for key in ('path', 'bytes', 'sha256')}


def byte_identity(body):
    if type(body) is not bytes:
        raise ValueError('exact immutable bytes required')
    return dict(bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def serialize(value, cap):
    body = (json.dumps(value, sort_keys=True, ensure_ascii=True, allow_nan=False,
                       separators=(',', ':')) + '\n').encode('ascii')
    if len(body) > cap:
        raise RootBudget('complete output ceiling; no truncation or prefix authority')
    return body


def write_body(path, body):
    if path.exists():
        raise ValueError('exclusive new complete output required')
    temporary = path.with_name(path.name + '.partial')
    stream = None
    primary = None
    try:
        stream = temporary.open('xb')
        stream.write(body)
        stream.flush()
        os.fsync(stream.fileno())
    except BaseException as error:
        primary = error
        raise
    finally:
        if stream is not None:
            try:
                stream.close()
            except BaseException:
                if primary is None:
                    raise
    temporary.replace(path)


def load_exact(row, name, check):
    check()
    if name in sys.modules or raw_pin(row['path']) != pin_fields(row):
        raise ValueError('exact new module and unused owned import name required')
    spec = importlib.util.spec_from_file_location(name, row['path'])
    if spec is None or spec.loader is None:
        raise ValueError('ordinary Python Source loader required')
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    check()
    if (Path(module.__file__).resolve() != Path(row['path'])
            or raw_pin(row['path']) != pin_fields(row)):
        raise ValueError('stable exact imported Source origin required')
    return module


def _validate_json_image(value, check):
    """Validate only; no copied tree, coercion, memo cache or codec-private API."""
    active = set()
    stack = [('node', value, None, 0)]
    while stack:
        check()
        action, item, keys, index = stack.pop()
        if action == 'node':
            kind = type(item)
            if item is None or kind is bool or kind is int or kind is str:
                continue
            if kind is float:
                if not math.isfinite(item):
                    raise ValueError('finite original JSON-image float required')
                continue
            if not (kind is list or kind is tuple or kind is dict):
                raise ValueError('exact original JSON-image type required')
            identity = id(item)
            if identity in active:
                raise ValueError('active original JSON-image cycle refused')
            active.add(identity)
            if kind is dict:
                keys = []
                for key in item:
                    check()
                    if type(key) is not str:
                        raise ValueError('all exactstr keys required before lookup')
                    keys.append(key)
                stack.append(('object', item, keys, 0))
            else:
                stack.append(('array', item, None, 0))
        elif index == len(item):
            active.remove(id(item))
        else:
            # The node/edge checkpoint above precedes each child lookup.
            stack.append((action, item, keys, index + 1))
            child = item[keys[index]] if action == 'object' else item[index]
            stack.append(('node', child, None, 0))


def _checked_byte_equal(left, right, check):
    if len(left) != len(right):
        return False
    for offset in range(0, len(left), 65536):
        check()
        if left[offset:offset + 65536] != right[offset:offset + 65536]:
            return False
    return True


def _write_bank_and_readback(path, body, check, progress):
    """New positive IO only. Close cannot replace an earlier actual E."""
    temporary = path.with_name(path.name + '.partial')
    check()
    if path.exists():
        raise ValueError('exclusive new bank artifact required')
    stream = None
    primary = None
    try:
        check()
        stream = temporary.open('xb')
        progress['phase'] = 'WRITING_PARTIAL'
        offset = 0
        while offset < len(body):
            check()
            chunk = body[offset:offset + 65536]
            written = stream.write(chunk)
            if type(written) is not int or not 0 < written <= len(chunk):
                raise ValueError('complete bounded bank write required')
            offset += written
        check()
        stream.flush()
        check()
        os.fsync(stream.fileno())
    except BaseException as error:
        primary = error
        raise
    finally:
        if stream is not None:
            try:
                stream.close()
            except BaseException:
                if primary is None:
                    raise
    check()
    temporary.replace(path)
    progress['phase'] = 'PUBLISHED_PROVISIONAL'
    stream = None
    primary = None
    try:
        check()
        stream = path.open('rb')
        digest = hashlib.sha256()
        offset = 0
        while offset < len(body):
            check()
            chunk = stream.read(min(65536, len(body) - offset))
            if type(chunk) is not bytes or not chunk:
                raise ValueError('complete original bank readback required')
            check()
            if chunk != body[offset:offset + len(chunk)]:
                raise ValueError('exact original bank readback mismatch')
            check()
            digest.update(chunk)
            offset += len(chunk)
        check()
        if stream.read(1) != b'':
            raise ValueError('original bank readback strict EOF required')
        answer = dict(bytes=offset, sha256=digest.hexdigest())
    except BaseException as error:
        primary = error
        raise
    finally:
        if stream is not None:
            try:
                stream.close()
            except BaseException:
                if primary is None:
                    raise
    check()
    progress['phase'] = 'READBACK_COMPLETE'
    progress['readback_complete'] = True
    return answer


def _keys(value, names, check):
    check()
    if type(value) is not dict or len(value) != len(names):
        raise ValueError('exact plain object carrier required')
    for key in value:
        check()
        if type(key) is not str:
            raise ValueError('exactstr keys required before membership or lookup')
    if set(value) != set(names):
        raise ValueError('exact public object fields required')


def _natural(value):
    return type(value) is int and value >= 0


def _digest(body, check):
    if type(body) is not bytes:
        raise ValueError('original immutable byte body required')
    digest = hashlib.sha256()
    for offset in range(0, len(body), 65536):
        check()
        digest.update(body[offset:offset + 65536])
    check()
    return dict(bytes=len(body), sha256=digest.hexdigest())


def _same(left, right, check):
    """Checked exact JSON-image association; list/tuple denote one array image."""
    stack = [(left, right)]
    while stack:
        check()
        a, b = stack.pop()
        ak, bk = type(a), type(b)
        aa, ba = ak is list or ak is tuple, bk is list or bk is tuple
        if aa or ba:
            if not (aa and ba and len(a) == len(b)):
                return False
            for index in range(len(a) - 1, -1, -1):
                check()
                stack.append((a[index], b[index]))
        elif ak is dict or bk is dict:
            if not (ak is dict and bk is dict and len(a) == len(b)):
                return False
            for key in a:
                check()
                if type(key) is not str or key not in b:
                    return False
                stack.append((a[key], b[key]))
        elif ak is not bk:
            return False
        elif ak is str or ak is bytes:
            if not _checked_byte_equal(a, b, check):
                return False
        elif a is None or ak is bool or ak is int or ak is float:
            if ak is float and (not math.isfinite(a) or not math.isfinite(b)):
                raise ValueError('finite exact JSON-image equality required')
            if a != b:
                return False
        else:
            raise ValueError('ordinary exact JSON-image equality required')
    return True


def _read_original(row, check):
    expected = pin_fields(row)
    path = Path(expected['path'])
    check()
    if (not path.is_absolute() or path.is_symlink() or path.resolve() != path
            or not path.is_file() or '.partial' in path.name):
        raise ValueError('canonical complete declared original required')
    stream, primary, chunks = None, None, []
    try:
        check()
        stream = path.open('rb')
        offset, digest = 0, hashlib.sha256()
        while offset < expected['bytes']:
            check()
            chunk = stream.read(min(65536, expected['bytes'] - offset))
            if type(chunk) is not bytes or not chunk:
                raise ValueError('entire declared original read required')
            check()
            digest.update(chunk)
            chunks.append(chunk)
            offset += len(chunk)
        check()
        if stream.read(1) != b'' or digest.hexdigest() != expected['sha256']:
            raise ValueError('original full raw length/hash/EOF association required')
    except BaseException as error:
        primary = error
        raise
    finally:
        if stream is not None:
            try:
                stream.close()
            except BaseException:
                if primary is None:
                    raise
    check()
    answer = b''.join(chunks)
    check()
    return answer


def _backproject(family, occurrence, result, donor, check):
    _keys(result, INSTANCE_FIELDS, check)
    if (result['schema'] != 'FPC-receptor-instance-candidate-v1'
            or result['complete'] is not True or result['accepted'] is not False):
        raise ValueError('complete explicitly unadmitted instance required')
    source_subject, source_reference = donor['subject_receipt'], donor['reference_receipt']
    subject, reference = result['subject_receipt'], result['reference_receipt']
    if (subject['accepted'] is not True or subject['complete'] is not True
            or subject['status'] != 'VALID_DERIVATION' or reference['complete_check'] is not True
            or reference['status'] != 'VALID_DERIVATION' or not subject['final_goal_equal'] is True
            or reference['final_goal_equal'] is not True):
        raise ValueError('both complete fresh original instance views required')
    if not _same(result['binding'], occurrence['source_bindings'], check):
        raise ValueError('stored complete source binding must be used unchanged')
    for name in QUERY_FIELDS:
        check()
        if not _same(result['context_query_identity'][name], source_subject['query'][name], check):
            raise ValueError('all original donor context semantics retained')
    rows, nodes, ports = result['expansion_rows'], family['internal_nodes'], family['boundary_nodes']
    if not 2 <= len(nodes) <= 8 or len(ports) > 4:
        raise ValueError('fixed original family internal and boundary bounds required')
    count, boundary_count = len(nodes) + len(ports), len(ports)
    if (len(rows) != count or subject['certificate']['row_count'] != count
            or len(subject['certificate']['rows']) != count or len(reference['rows']) != count):
        raise ValueError('complete noncontracted physical instance rows required')
    maps = result['family_to_wire_rows']
    _keys(maps, ('boundary_to_wire', 'internal_to_wire'), check)
    if (not _same(maps['boundary_to_wire'], [[i,i] for i in range(boundary_count)], check)
            or not _same(maps['internal_to_wire'], [[i,boundary_count+i] for i in range(len(nodes))], check)):
        raise ValueError('complete canonical source identity to wire maps required')
    source_to_wire, selected_sources = {}, []
    for name, expected_count, shift in (('boundary_source_to_port', boundary_count, 0), ('source_to_local', len(nodes), boundary_count)):
        mapping = occurrence[name]
        if len(mapping) != expected_count:
            raise ValueError('complete chosen source occurrence map required')
        for index, pair in enumerate(mapping):
            check()
            if (not (type(pair) is list or type(pair) is tuple) or len(pair) != 2
                    or not _natural(pair[0]) or type(pair[1]) is not int or pair[1] != index
                    or pair[0] >= len(source_reference['rows']) or pair[0] in source_to_wire):
                raise ValueError('strict distinct source occurrence map required')
            source_to_wire[pair[0]] = shift + index
            if name == 'source_to_local':
                selected_sources.append(pair[0])
    checks, gamma = [], []
    for name, kind, shift in (('boundary_source_to_port','boundary',0), ('source_to_local','internal',boundary_count)):
        for source_index, local_index in occurrence[name]:
            check()
            wire_index = shift + local_index
            old = source_subject['certificate']['rows'][source_index]
            flat_old = source_reference['rows'][source_index]
            emitted, actual, flat = rows[wire_index], subject['certificate']['rows'][wire_index], reference['rows'][wire_index]
            _keys(emitted,('wire_index','origin_kind','origin_id','formula','rule_tag','subtag','witness','references'),check)
            if (emitted['origin_kind'] != kind or emitted['origin_id'] != local_index
                    or emitted['wire_index'] != wire_index or actual['index'] != wire_index or flat['index'] != wire_index
                    or old['index'] != source_index or flat_old['index'] != source_index
                    or not _same(emitted['formula'], old['formula'], check)
                    or not _same(actual['formula'], old['formula'], check)
                    or not _same(flat['formula']['prefix_tokens'], flat_old['formula']['prefix_tokens'], check)):
                raise ValueError('every physical original formula and identity backprojects in both views')
            if kind == 'boundary':
                gamma.append(old['formula'])
                if (actual['rule_tag'] != 0 or actual['subtag'] is not None
                        or not _same(actual['witness'], [local_index], check)
                        or flat['rule_tag'] != 0 or flat['witness_tag'] is not None
                        or not _same(flat['payload'], [local_index], check)):
                    raise ValueError('distinct boundary occurrence is its exact standalone HYP port')
            else:
                if (actual['rule_tag'] != old['rule_tag'] or actual['subtag'] != old['subtag']
                        or flat['rule_tag'] != flat_old['rule_tag'] or flat['witness_tag'] != flat_old['witness_tag']):
                    raise ValueError('original selected primitive tag/subtag backprojection required')
                if old['rule_tag'] == 1:
                    if (type(old['subtag']) is not int or not 0 <= old['subtag'] <= 2
                            or not _same(actual['witness'], old['witness'], check) or len(flat['payload']) != len(flat_old['payload'])):
                        raise ValueError('complete original logical witnesses required')
                    for current, original in zip(flat['payload'], flat_old['payload']):
                        check()
                        if not _same(current['prefix_tokens'], original['prefix_tokens'], check):
                            raise ValueError('independent ordered logical witness backprojection required')
                elif old['rule_tag'] == 3:
                    if not _same(old['witness'], flat_old['payload'], check):
                        raise ValueError('ordered original MP references join both source views')
                    expected = []
                    for original_reference in old['witness']:
                        check()
                        if not _natural(original_reference) or original_reference not in source_to_wire:
                            raise ValueError('all actual source MP ports covered by chosen full map')
                        expected.append(source_to_wire[original_reference])
                    if (not _same(actual['witness'], expected, check) or not _same(flat['payload'], expected, check)
                            or not _same(emitted['references'], expected, check) or not _same(emitted['witness'], expected, check)):
                        raise ValueError('translate original ordered MP source indices to exact emitted wire refs')
                else:
                    raise ValueError('only original H1/H2/H3 or MP selected internal rows')
            checks.append(dict(source_row=source_index,wire_row=wire_index,origin_kind=kind,origin_id=local_index,
                original_row_span=old['span'], independent_original_row_span=flat_old['byte_span'],
                emitted_row_span=actual['span'],independent_emitted_row_span=flat['byte_span']))
    root_source = occurrence['root_source_row']
    for key in ('version','function_arities','predicate_arities'):
        check()
        if not _same(subject['query'][key],source_subject['query'][key],check):
            raise ValueError('exact original signature and version in boundary query required')
    if (not selected_sources or root_source != selected_sources[-1]
            or source_to_wire[root_source] != count-1 or not _same(subject['query']['goal'], source_subject['certificate']['rows'][root_source]['formula'], check)
            or not _same(subject['query']['Gamma'], gamma, check)
            or subject['query']['claim_mode'] != 1 or subject['query']['theory_profile'] != 0
            or subject['query']['finite_axioms'] != []):
        raise ValueError('exact standalone boundary context and mapped source root required')
    return dict(schema='FPC-receptor-source-occurrence-backprojection-v1',complete=True,accepted=False,
        source_root_row=root_source,source_to_wire_rows=sorted(source_to_wire.items()),physical_rows=checks,
        meaning='Standalone boundary consequence/source occurrence only; no original theorem or final-used-map admission.')



def _subst(pattern, bindings, check):
    images={}
    for row in bindings:
        check(); images[row['parameter_id']]=row['formula']
    pending,values=[('read',pattern)],[]
    while pending:
        check(); action,node=pending.pop()
        if action=='read':
            if node[0]=='param': values.append(images[node[1]])
            elif node[0]=='not': pending.extend([('not',None),('read',node[1])])
            elif node[0]=='imp': pending.extend([('imp',None),('read',node[2]),('read',node[1])])
            else: raise ValueError('declared param/not/imp pattern required')
        elif action=='not': values.append(['not',values.pop()])
        else:
            right,left=values.pop(),values.pop(); values.append(['imp',left,right])
    if len(values)!=1: raise ValueError('complete simultaneous Formula substitution required')
    return values[0]


def _tokens(formula,check):
    result=[]; pending=[('F',formula)]
    while pending:
        check(); sort,node=pending.pop(); tag=node[0]
        if sort=='T' and tag=='var': result.append(['var',node[1]])
        elif (sort=='T' and tag=='fun') or (sort=='F' and tag=='pred'):
            result.append([tag,node[1],len(node[2])])
            for child in reversed(node[2]): check(); pending.append(('T',child))
        elif tag=='all': result.append(['all',node[1]]); pending.append(('F',node[2]))
        elif tag=='not': result.append(['not']); pending.append(('F',node[1]))
        elif tag=='eq' or tag=='imp':
            result.append([tag]); child_sort='T' if tag=='eq' else 'F'
            pending.extend([(child_sort,node[2]),(child_sort,node[1])])
        else: raise ValueError('complete typed core Formula token association required')
    return result


def _bank_complete(value,check):
    _validate_json_image(value,check)
    _keys(value,('schema','version','population','complete','control_ids','controls','counts','scope','coverage_limits'),check)
    if (value['schema']!='FPC-receptor-skeleton-schema-independent-controls-v1'
            or value['version']!=MODULE_VERSIONS['schema_bank'] or value['population']!='skeleton_schema6'
            or value['complete'] is not True or not _same(value['control_ids'],list(CONTROL_IDS['skeleton_schema6']),check)
            or not _same(value['counts'],dict(groups=6,passed=6,failed=0),check)
            or value['scope']!=CONTROL_POPULATIONS[0]['scope'] or len(value['controls'])!=6):
        raise ValueError('complete unchanged scoped schema6 bank required')
    for name,row in zip(CONTROL_IDS['skeleton_schema6'],value['controls']):
        check(); _keys(row,('id','passed','observations'),check)
        if row['id']!=name or row['passed'] is not True or type(row['observations']) is not list:
            raise ValueError('every complete schema6 row and observation required')
    expected=['No valid cyclic proof skeleton or public unifier hook: occurs-check rejection is Source-review-only.',
              'Selected first-callback and public dependency faults only; no all-cutoff/native-allocation claim.',
              'No compiler, original proof checker, consumer, primitive fallback transaction or final-root-use path is exercised.']
    if not _same(value['coverage_limits'],expected,check): raise ValueError('all declared unexercised bank scope retained')


def _inference_complete(value,source,check):
    _validate_json_image(value,check); _keys(value,SCHEMA_FIELDS,check)
    if (value['schema']!='FPC-receptor-skeleton-schema-candidate-v1' or value['version']!=MODULE_VERSIONS['schema']
            or value['complete'] is not True or value['accepted'] is not False or value['library_admitted'] is not False
            or value['method']!='fixed-proof-skeleton-first-order-unification-v1'
            or not _same(value['source_family'],source,check)):
        raise ValueError('complete detached nonadmitting inference and original full family required')
    _keys(value['costs'],SCHEMA_COST_FIELDS,check)
    for number in value['costs'].values():
        check()
        if not _natural(number): raise ValueError('exact normal inference cost integers required')
    family=value['family']
    for name in ('root_local_id','distinct_base_nodes','size_band','validation_provenance'):
        if not _same(family[name],source[name],check): raise ValueError('unchanged source topology/provenance metadata')
    for name in ('parameters','root_local_id','internal_nodes','boundary_nodes'):
        if not _same(family['family_key'][name],family[name],check): raise ValueError('complete generalized full key required')
    if len(family['source_occurrences'])!=len(source['source_occurrences']): raise ValueError('every original occurrence retained')
    if len(value['specialization'])!=len(family['parameters']): raise ValueError('complete old-pattern specialization required')
    for index,row in enumerate(value['specialization']):
        check(); _keys(row,('parameter_id','source_pattern'),check)
        if type(row['parameter_id']) is not int or row['parameter_id']!=index: raise ValueError('ordered strict specialization IDs')
    for name in ('input_guards','output_guards','source_associations'):
        if len(value[name])!=len(source['source_occurrences']): raise ValueError('all source guard/backprojection rows retained')
    for index,(old,new,association) in enumerate(zip(source['source_occurrences'],family['source_occurrences'],value['source_associations'])):
        check()
        for name in ('donor_id','root_source_row','source_to_local','boundary_source_to_port'):
            if not _same(old[name],new[name],check) or not _same(old[name],association[name],check):
                raise ValueError('unchanged exact source identity maps required')
        if (association['occurrence_index']!=index
                or not _same(association['original_source_bindings'],old['source_bindings'],check)
                or not _same(association['generalized_source_bindings'],new['source_bindings'],check)):
            raise ValueError('complete source binding association required')
        for field in ('boundary_checks','internal_checks'):
            for row in association[field]:
                check()
                if row['formula_equal'] is not True or ('witness_equal' in row and row['witness_equal'] is not True):
                    raise ValueError('every exact source formula/witness comparison completed')
        for name in ('input_guards','output_guards'):
            row=value[name][index]
            if row['occurrence_index']!=index or row['match_result']['matched'] is not True:
                raise ValueError('every complete public normal guard required')


def _instance_join(family,binding,result,context,context_bytes,check):
    _keys(result,INSTANCE_FIELDS,check)
    if (result['schema']!='FPC-receptor-instance-candidate-v1' or result['complete'] is not True or result['accepted'] is not False
            or not _same(result['binding'],binding,check)): raise ValueError('complete exact-bound instance candidate required')
    for name in QUERY_FIELDS:
        if not _same(result['context_query_identity'][name],context[name],check): raise ValueError('full original context retained')
    identity=_digest(context_bytes,check)
    for name in ('bytes','sha256'):
        if not _same(result['context_query_identity'][name],identity[name],check): raise ValueError('original context raw identity retained')
    if not _same(result['context_query_identity']['query_hex'],context_bytes.hex(),check): raise ValueError('full original context byte image retained')
    q,cert=result['boundary_query_bytes'],result['boundary_certificate_bytes']
    if type(q) is not bytes or type(cert) is not bytes: raise ValueError('exact two immutable service byte leaves required')
    subject,reference=result['subject_receipt'],result['reference_receipt']
    if (subject['accepted'] is not True or subject['complete'] is not True or subject['status']!='VALID_DERIVATION'
            or subject['final_goal_equal'] is not True or subject['syntax_complete'] is not True or subject['derivation_complete'] is not True
            or reference['status']!='VALID_DERIVATION' or reference['complete_check'] is not True or reference['final_goal_equal'] is not True
            or subject['query']['EOF']!=len(q) or subject['certificate']['EOF']!=len(cert)):
        raise ValueError('complete fresh original identical-byte dual evidence required')
    for name,body in (('query',q),('certificate',cert)):
        if not _same(subject['raw_inputs'][name],_digest(body,check),check): raise ValueError('same original service byte identity')
    ports,nodes=family['boundary_nodes'],family['internal_nodes']; count=len(ports)+len(nodes)
    rows=result['expansion_rows']
    if len(rows)!=count or len(subject['certificate']['rows'])!=count or len(reference['rows'])!=count or subject['certificate']['row_count']!=count:
        raise ValueError('all physical rows retained without contraction')
    expected_maps=dict(boundary_to_wire=[[i,i] for i in range(len(ports))],internal_to_wire=[[i,len(ports)+i] for i in range(len(nodes))])
    if not _same(result['family_to_wire_rows'],expected_maps,check): raise ValueError('all canonical physical maps required')
    gamma=[]; evidence=[]
    for index,(emitted,actual,flat) in enumerate(zip(rows,subject['certificate']['rows'],reference['rows'])):
        check(); boundary=index<len(ports); local=index if boundary else index-len(ports)
        record=ports[local] if boundary else nodes[local]
        formula=_subst(record['formula_pattern'],binding,check)
        if (emitted['wire_index']!=index or actual['index']!=index or flat['index']!=index
                or emitted['origin_kind']!=('boundary' if boundary else 'internal') or emitted['origin_id']!=local
                or not _same(formula,emitted['formula'],check) or not _same(formula,actual['formula'],check)
                or not _same(_tokens(formula,check),flat['formula']['prefix_tokens'],check)
                or not _same(actual['span'],flat['byte_span'],check)):
            raise ValueError('every instantiated Formula/physical index/span joins both complete views')
        if boundary:
            gamma.append(formula); tag,subtag,witness,refs=0,None,[local],[]
        else:
            tag,subtag=record['rule_tag'],record['subtag']; refs=[]
            for ref in record['references']:
                check(); refs.append(ref['id'] if ref['kind']=='boundary' else len(ports)+ref['id'])
            witness=[_subst(p,binding,check) for p in record['witness_pattern']] if tag==1 else list(refs)
        if (emitted['rule_tag']!=tag or actual['rule_tag']!=tag or flat['rule_tag']!=tag
                or emitted['subtag']!=subtag or actual['subtag']!=subtag or flat['witness_tag']!=subtag
                or not _same(emitted['witness'],witness,check) or not _same(actual['witness'],witness,check)
                or not _same(emitted['references'],refs,check)):
            raise ValueError('all original logical witness and ordered reference joins required')
        if tag==1:
            if len(flat['payload'])!=len(witness): raise ValueError('complete independent logical payload')
            for value,other in zip(witness,flat['payload']):
                if not _same(_tokens(value,check),other['prefix_tokens'],check): raise ValueError('independent witness Formula token association')
        elif not _same(flat['payload'],witness,check): raise ValueError('independent ordered natural payload association')
        evidence.append(dict(wire_row=index,origin_kind=emitted['origin_kind'],origin_id=local,
            subject_row_span=actual['span'],reference_row_span=flat['byte_span'],formula_witness_reference_joined=True))
    expected=dict(version=1,claim_mode=1,function_arities=context['function_arities'],predicate_arities=context['predicate_arities'],
                  theory_profile=0,finite_axioms=[],Gamma=gamma,goal=_subst(nodes[-1]['formula_pattern'],binding,check))
    for name in QUERY_FIELDS:
        if not _same(subject['query'][name],expected[name],check): raise ValueError('exact complete standalone query semantics')
    return dict(schema='FPC-skeleton-instance-full-row-association-v1',complete=True,accepted=False,
                family_to_wire_rows=expected_maps,physical_rows=evidence,standalone_only=True)


def main(plan_path,actual_dir,root_start):
    if not (sys.platform=='darwin' and sys.implementation.name=='cpython' and sys.version.split()[0]=='3.12.14'
            and sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode and os.getpid()==os.getpgrp()
            and type(root_start) is float and math.isfinite(root_start) and 0<=root_start<=time.monotonic()):
        raise ValueError('exact isolated owned pinned child and inherited genuine parent clock required')
    began=root_start; directory=Path(actual_dir); plan_path=Path(plan_path); study=Path(__file__).resolve().parents[1]
    plan_pin=raw_pin(plan_path); plan_body=plan_path.read_bytes()
    if byte_identity(plan_body)!={k:plan_pin[k] for k in ('bytes','sha256')}: raise ValueError('stable entire plan required')
    plan=json.loads(plan_body); plan_body=None
    if type(plan) is not dict or set(plan)!=set(PLAN_FIELDS): raise ValueError('exact narrow profile plan fields required')
    if (plan['schema']!='proof-search-case-once-plan-v1' or plan['case_id']!=CASE or plan['experiment']!=EXPERIMENT
            or plan['stage']!='schema' or plan['profile']!=PROFILE or directory!=study/'actual'/CASE
            or plan['actual_dir']!=str(directory) or not directory.is_absolute() or directory.resolve()!=directory
            or directory.is_symlink() or not directory.is_dir() or plan_path.parent!=study/'root'/'plans'
            or Path(plan['worker_path'])!=Path(__file__).resolve()): raise ValueError('one exact new schema case required')
    if type(plan['limits']) is not dict or set(plan['limits'])!=set(CAPS) or any(type(plan['limits'][k]) is not int or plan['limits'][k]!=v for k,v in CAPS.items()):
        raise ValueError('all original exact ten caps required')
    resource.setrlimit(resource.RLIMIT_FSIZE,(CAPS['physical_bytes'],CAPS['physical_bytes']))
    consumed=json.loads((directory/'CONSUMED.json').read_bytes())
    if consumed['schema']!='proof-search-case-consumed-v1' or consumed['plan_sha256']!=plan_pin['sha256'] or consumed['case_id']!=CASE or type(consumed['uses']) is not int or consumed['uses']!=1:
        raise ValueError('one fresh owned consumption required')
    state=dict(stage='PIN_INTAKE',callbacks=0,first_fault=None,first_fault_monotonic_ns=None,stages=[],versions={})
    primary=None; guards=[]; source_unchanged=False; modules={}; public_bindings=[]; projections={}
    positives={name:None for name in POSITIVE_FIELDS}; provisional=[]; committed_bytes=0; output_rejection=None
    originals={}; contexts={}; historical=None; source_records=[]; inference_results=[]; source_instances=[]; generic_instances=[]; groups=[]
    data_refs=[INPUT_AUTHORITY['library_result']]+[x['query'] for x in INPUT_AUTHORITY['context_queries']]

    def check():
        if state['first_fault'] is not None: raise state['first_fault']
        state['callbacks']+=1; error=None
        if state['callbacks']>CAPS['root_callbacks']: error=RootBudget('cumulative Root callback ceiling')
        elif time.monotonic()-began>=CAPS['work_seconds']: error=RootBudget('absolute whole-work deadline')
        elif resource.getrusage(resource.RUSAGE_SELF).ru_maxrss>=CAPS['memory_bytes']: error=RootBudget('strict Python whole high-water ceiling')
        if error is not None:
            state['first_fault']=error; state['first_fault_monotonic_ns']=time.monotonic_ns(); raise error

    def policy_check():
        check(); value=sys.get_int_max_str_digits()
        if type(value) is not int or value!=POLICY_BINDING[1]: raise ValueError('reference effective native integer policy drift')
        return value

    def stage(name,operation):
        policy_check(); state['stage']=name
        row=dict(name=name,began=time.monotonic()-began,status='STARTED'); state['stages'].append(row)
        value=operation(); policy_check(); row.update(status='COMPLETED',seconds=time.monotonic()-began-row['began']); return value

    def verify_files(cooperative):
        for row in guards:
            if cooperative: check()
            if raw_pin(row['path'])!=row: raise ValueError('changed declared Source/metadata: '+row['path'])

    def canonical(value):
        _validate_json_image(value,check); policy_check()
        body=(json.dumps(value,sort_keys=True,ensure_ascii=True,allow_nan=False,separators=(',',':'))+'\n').encode('ascii')
        policy_check(); return body

    def metadata(ref):
        ref=pin_fields(ref)
        if by_path.get(ref['path'])!=ref: raise ValueError('explicit guarded metadata required')
        body=_read_original(ref,policy_check); value=json.loads(body); policy_check(); return value

    def stable():
        policy_check()
        for role,name,entry in public_bindings:
            check()
            if getattr(modules[role],name) is not entry: raise ValueError('original public callable identity changed')
        for name,expected in (('bank',('schema','instance')),('service',('checker','builders','reference'))):
            if name in projections:
                _keys(projections[name],expected,check)
                for role in expected:
                    check()
                    if projections[name][role] is not modules[role]: raise ValueError('exact projection mutated')

    def decide_size(body,name):
        nonlocal output_rejection
        policy_check(); prospective=committed_bytes+len(body)
        if prospective>CAPS['result_bytes']:
            if output_rejection is None:
                output_rejection=dict(schema='FPC-skeleton-schema-output-rejection-v1',component=name,
                    exact_attempt_bytes=len(body),committed_positive_bytes_before=committed_bytes,
                    prospective_positive_bytes=prospective,cap_bytes=CAPS['result_bytes'])
            error=RootBudget('bank+contexts+all instance bytes+ENTIRE result exceed shared48MiB')
            state['first_fault']=error; state['first_fault_monotonic_ns']=time.monotonic_ns(); raise error

    def export(name,body):
        nonlocal committed_bytes
        if type(body) is not bytes: raise ValueError('original immutable artifact bytes required')
        decide_size(body,name); progress=dict(basename=name,phase='BEFORE_WRITE',readback_complete=False); provisional.append(progress)
        expected=_digest(body,policy_check); actual=_write_bank_and_readback(directory/name,body,policy_check,progress)
        if not _same(actual,expected,check): raise ValueError('full original artifact readback required')
        committed_bytes+=len(body)
        return dict(schema='FPC-receptor-original-bytes-artifact-ref-v1',path=name,bytes=actual['bytes'],sha256=actual['sha256'])

    def saved_instance(result,prefix):
        q=result['boundary_query_bytes']; cert=result['boundary_certificate_bytes']
        qref=stage('EXPORT '+prefix+' QUERY',lambda:export(prefix+'-query.bin',q))
        cref=stage('EXPORT '+prefix+' CERTIFICATE',lambda:export(prefix+'-certificate.bin',cert))
        saved=dict(result); saved['boundary_query_bytes']=qref; saved['boundary_certificate_bytes']=cref
        _validate_json_image(saved,check); return saved

    def retire_positive():
        nonlocal historical,source_records,inference_results,source_instances,generic_instances,groups,contexts,originals
        for name in POSITIVE_FIELDS: positives[name]=None
        historical=None; source_records=[]; inference_results=[]; source_instances=[]; generic_instances=[]; groups=[]; contexts={}; originals={}

    try:
        check(); _keys(plan['module_pins'],MODULE_ROLES,check)
        if not _same(plan['module_pins'],MODULE_PINS,check) or not _same(plan['input_authority'],INPUT_AUTHORITY,check) or not _same(plan['Source_components'],SOURCE_COMPONENTS,check):
            raise ValueError('exact active profile pins/input authority/components required')
        if type(plan['files']) is not list or not plan['files']: raise ValueError('nonempty explicit Source closure required')
        guards=[pin_fields(row) for row in plan['files']]; by_path={row['path']:row for row in guards}
        if len(by_path)!=len(guards): raise ValueError('unique Source guard paths required')
        for ref in guards:
            check()
            if '/actual/' in ref['path'] or ref['path'].endswith('.bin'): raise ValueError('data bodies never Source guards')
        for ref in list(MODULE_PINS.values())+list(CUSTODY_RUNTIME.values())+REQUIRED_METADATA_GUARDS:
            check()
            if by_path.get(ref['path'])!=ref: raise ValueError('every exact used runtime/metadata guard required')
        if (pin_fields(plan['python'])!=CUSTODY_RUNTIME['python'] or raw_pin(Path(sys.executable).resolve())!=CUSTODY_RUNTIME['python']
                or plan['runner_path']!=CUSTODY_RUNTIME['runner']['path']
                or by_path.get(str(Path(__file__).resolve()))!=raw_pin(Path(__file__).resolve())):
            raise ValueError('exact inherited custody/current worker/environment required')
        protocol=metadata(plan['protocol']); _keys(protocol,('schema','experiment','limits','module_pins','control_populations','job_recipes','metadata'),check)
        expected_metadata=dict(profile=PROFILE,input_authority=INPUT_AUTHORITY,Source_components=SOURCE_COMPONENTS,reference_integer_policy=list(POLICY_BINDING))
        if (protocol['schema']!=PROTOCOL_SCHEMA or protocol['experiment']!=EXPERIMENT or not _same(protocol['limits'],CAPS,check)
                or not _same(protocol['module_pins'],MODULE_PINS,check) or not _same(protocol['control_populations'],CONTROL_POPULATIONS,check)
                or not _same(protocol['job_recipes'],[dict(case_id=CASE,stage='schema')],check)
                or not _same(protocol['metadata'],expected_metadata,check)): raise ValueError('exact prospective narrow protocol required')
        verify_files(True); reference_policy=[POLICY_BINDING[0],policy_check()]
        for ref,role in zip(SOURCE_COMPONENTS,('schema','schema_bank')):
            component=metadata(ref)
            if component['Source_component_accepted'] is not True or not _same(component['Source'],MODULE_PINS[role],check):
                raise ValueError('exact independently reviewed component Source required')
            review=metadata(component['independent_review'])
            if review['review_passed'] is not True: raise ValueError('complete component Source review required')
        admission=metadata(INPUT_AUTHORITY['library_admission']); review=metadata(admission['complete_C_review'])
        if (admission['finite_inventory_admitted'] is not True or admission['library_admitted'] is not True
                or admission['resources_and_custody_accepted'] is not True or not _same(admission['result'],INPUT_AUTHORITY['library_result'],check)
                or review['review_passed'] is not True or review['blockers']!=[]
                or not _same(review['subjects']['result'],INPUT_AUTHORITY['library_result'],check)):
            raise ValueError('exact complete Root/C library admission required')
        for role in MODULE_ROLES:
            modules[role]=stage('IMPORT '+role,lambda role=role:load_exact(MODULE_PINS[role],'_skeleton_schema_'+role+'_once_v1',check))
            if type(modules[role].VERSION) is not str or modules[role].VERSION!=MODULE_VERSIONS[role]: raise ValueError('exact namespace VERSION required')
            state['versions'][role]=modules[role].VERSION
            for name in PUBLIC_ENTRIES[role]:
                check(); entry=getattr(modules[role],name)
                if not callable(entry): raise ValueError('genuine original public callable required')
                public_bindings.append((role,name,entry))
        projections['bank']={role:modules[role] for role in ('schema','instance')}
        projections['service']={role:modules[role] for role in ('checker','builders','reference')}
        bank=stage('SCHEMA6',lambda:modules['schema_bank'].run_bank(projections['bank'],check=check)); stable(); _bank_complete(bank,check)
        bank_ref=stage('EXPORT SCHEMA6',lambda:export('schema-bank.json',canonical(bank)))
        positives['schema6_qualification']=dict(complete_return=bank,artifact=bank_ref)
        historical_body=stage('READ ADMITTED LIBRARY',lambda:_read_original(INPUT_AUTHORITY['library_result'],policy_check))
        historical=json.loads(historical_body); policy_check(); historical_body=None
        if (historical['status']!='LIBRARY_FEASIBILITY_CANDIDATE' or historical['candidate_complete'] is not True
                or historical['accepted'] is not False or historical['library_admitted'] is not False
                or historical['source_unchanged'] is not True or historical['first_Root_fault'] is not False
                or historical['error'] is not None or historical['STOP'] is not None): raise ValueError('exact admitted complete historical candidate data required')
        source_records=historical['extraction_result']['families']
        if type(source_records) is not list or len(source_records)!=4 or len(admission['family_summaries'])!=4: raise ValueError('complete admitted four-family vector required')
        family_freeze=canonical(source_records); family_summaries=[]
        for index,(family,summary) in enumerate(zip(source_records,admission['family_summaries'])):
            check(); key=family['family_key']
            for name in ('parameters','root_local_id','internal_nodes','boundary_nodes'):
                if not _same(key[name],family[name],check): raise ValueError('original full structural key association')
            key_body=canonical(key)[:-1]
            if (summary['index']!=index or family['family_id']!=summary['family_id'] or len(key_body)!=summary['full_key_canonical_bytes']
                    or _digest(key_body,check)['sha256']!=family['family_id'] or len(family['internal_nodes'])!=summary['internal_nodes']
                    or len(family['boundary_nodes'])!=summary['boundary_nodes'] or len(family['parameters'])!=summary['parameters']
                    or len(family['source_occurrences'])!=1): raise ValueError('every complete admitted source key/summary required')
            occurrence=family['source_occurrences'][0]
            for name in ('donor_id','root_source_row','source_to_local','boundary_source_to_port'):
                if not _same(occurrence[name],summary[name],check): raise ValueError('every admitted source identity map retained')
            family_summaries.append(summary)
        context_freeze=[]
        for index,row in enumerate(INPUT_AUTHORITY['context_queries']):
            donor=row['donor_id']; raw=stage('READ CONTEXT '+donor,lambda row=row:_read_original(row['query'],policy_check))
            decoded=stage('DECODE CONTEXT '+donor,lambda raw=raw:modules['checker'].decode_query(raw,check=check))
            if decoded['EOF']!=len(raw) or decoded['version']!=1 or decoded['theory_profile']!=0 or decoded['predicate_arities']!=[0,0,0]:
                raise ValueError('exact original three-nullary-predicate context scope required')
            originals[donor]=raw; contexts[donor]=decoded
            artifact=stage('EXPORT CONTEXT '+donor,lambda raw=raw,index=index:export('context-'+str(index)+'-query.bin',raw))
            context_freeze.append(dict(donor_id=donor,original_query=row['query'],artifact=artifact,decoded=decoded))
        positives['library_provenance']=dict(admission=INPUT_AUTHORITY['library_admission'],complete_C_review=admission['complete_C_review'],
            original_result=INPUT_AUTHORITY['library_result'],admitted_family_summaries=family_summaries,old229_and_DAG8_rerun=False)
        positives['input_freeze']=dict(profile=PROFILE,input_authority=INPUT_AUTHORITY,Source_components=SOURCE_COMPONENTS,
            runtime_module_pins=MODULE_PINS,reference_integer_policy=reference_policy,contexts=context_freeze,original_family_vector_identity=_digest(family_freeze,check))
        for family_index,family in enumerate(source_records):
            before=canonical(family)
            candidate=stage('INFER '+str(family_index),lambda family=family:modules['schema'].infer_schematic_family(family,instance=modules['instance'],check=check))
            stable()
            if not _checked_byte_equal(before,canonical(family),check): raise ValueError('input family mutated by inference')
            _inference_complete(candidate,family,check); inference_results.append(candidate)
            generalized=candidate['family']; generalized_freeze=canonical(generalized)
            for occurrence_index,occurrence in enumerate(generalized['source_occurrences']):
                donor=occurrence['donor_id']
                if donor not in originals: raise ValueError('exact owning admitted source context required')
                service=stage('SOURCE INSTANCE '+str(family_index)+':'+str(occurrence_index),lambda generalized=generalized,occurrence=occurrence,donor=donor:
                    modules['instance'].compile_instance(originals[donor],generalized,occurrence['source_bindings'],encoder=modules['tiny_encoder'].encode_tiny_declared_query,modules=projections['service'],check=check))
                stable(); join=_instance_join(generalized,occurrence['source_bindings'],service,contexts[donor],originals[donor],check)
                validation_index=0 if donor=='donor0' else 1
                backprojection=_backproject(generalized,occurrence,service,historical['extraction_result']['donor_validation'][validation_index],check)
                saved=saved_instance(service,'source-'+str(len(source_instances)))
                source_instances.append(dict(input_family_index=family_index,source_occurrence_index=occurrence_index,
                    instance=saved,full_row_association=join,source_backprojection=backprojection))
                if not _checked_byte_equal(generalized_freeze,canonical(generalized),check): raise ValueError('generalized source family mutation')
                service=saved=join=backprojection=None
            target=None
            for group in groups:
                check()
                if _same(group['family']['family_key'],generalized['family_key'],check): target=group; break
            if target is None:
                group_family=json.loads(canonical(generalized)); policy_check()
                target=dict(group_index=len(groups),input_family_indices=[],specialization_links=[],family=group_family)
                groups.append(target)
            else:
                for occurrence in generalized['source_occurrences']:
                    check()
                    if any(old['donor_id']==occurrence['donor_id'] for old in target['family']['source_occurrences']):
                        raise ValueError('cannot skip/merge duplicate donor representative')
                    target['family']['source_occurrences'].append(json.loads(canonical(occurrence))); policy_check()
                if len(target['family']['source_occurrences'])>2: raise ValueError('whole STOP: original occurrence bound exceeded')
                provenance=set(target['family']['validation_provenance'])
                for ref in generalized['validation_provenance']: check(); provenance.add(ref)
                target['family']['validation_provenance']=sorted(provenance)
            target['input_family_indices'].append(family_index)
            target['specialization_links'].append(dict(input_family_index=family_index,inference_result_index=family_index,original_family_id=family['family_id']))
        if not _checked_byte_equal(family_freeze,canonical(source_records),check): raise ValueError('entire original admitted family vector unchanged')
        for group in groups:
            group_index=group['group_index']; generalized=group['family']; occurrence=generalized['source_occurrences'][0]; donor=occurrence['donor_id']
            binding=[]
            for index,parameter in enumerate(generalized['parameters']):
                check()
                if parameter['id']!=index or index>=len(contexts[donor]['predicate_arities']) or contexts[donor]['predicate_arities'][index]!=0:
                    raise ValueError('whole STOP: independent atoms exceed original context signature')
                binding.append(dict(parameter_id=index,formula=['pred',index,[]]))
            frozen=canonical(generalized)
            service=stage('GENERIC INSTANCE '+str(group_index),lambda generalized=generalized,binding=binding,donor=donor:
                modules['instance'].compile_instance(originals[donor],generalized,binding,encoder=modules['tiny_encoder'].encode_tiny_declared_query,modules=projections['service'],check=check))
            stable(); join=_instance_join(generalized,binding,service,contexts[donor],originals[donor],check)
            if not _checked_byte_equal(frozen,canonical(generalized),check): raise ValueError('grouped family mutated')
            saved=saved_instance(service,'generic-'+str(group_index))
            generic_instances.append(dict(group_index=group_index,owning_donor=donor,independent_atom_binding=binding,instance=saved,full_row_association=join))
            service=saved=join=None
        expected_sources=sum(len(x['family']['source_occurrences']) for x in inference_results)
        if len(inference_results)!=4 or len(source_instances)!=expected_sources or len(generic_instances)!=len(groups):
            raise ValueError('all inferred/source/generic obligations required together')
        positives['inference_results']=inference_results; positives['source_instance_results']=source_instances; positives['generic_exercise_results']=generic_instances
        positives['scientific_result']=dict(schema='FPC-skeleton-schema-feasibility-observation-v1',accepted=False,library_admitted=False,proof_admitted=False,
            scoped_bank_groups=6,inference_calls=4,source_instance_calls=len(source_instances),generic_instance_calls=len(generic_instances),generalized_groups=groups,
            old229_and_DAG8_rerun=False,holdout_loaded=False,holdout_searched=False,contextual_use=False,principal_schema_claim=False,GCTS_RL_claim=False,
            positive_body_bytes_before_result=committed_bytes,cost_scope='Inherited parent-start entire cold setup/imports/schema6/admitted data intake/all inference/all source and generic compilation/dual row maps/export/readback/retirement/custody; prior acquisition/qualification/extraction separately reported.')
        stable()
        for ref in data_refs: _read_original(ref,policy_check)
        verify_files(True); policy_check()
    except BaseException as error:
        primary=state['first_fault'] if state['first_fault'] is not None else error
    finally:
        source_unchanged=False
        try: verify_files(primary is None); source_unchanged=bool(guards)
        except BaseException as error:
            if primary is None: primary=state['first_fault'] if state['first_fault'] is not None else error
        if primary is not None: retire_positive()
    historical=None; source_records=[]; originals={}; contexts={}; source_instances=[]; generic_instances=[]; inference_results=[]; groups=[]
    family=candidate=generalized=occurrence=service=saved=join=backprojection=target=group=group_family=decoded=raw=before=frozen=binding=None
    bank=bank_ref=context_freeze=family_freeze=family_summaries=generalized_freeze=expected_sources=key_body=None
    public_bindings.clear(); projections.clear(); modules.clear()

    def receipt():
        value=dict(schema='FPC-skeleton-schema-whole-feasibility-receipt-v1',case_id=CASE,stage='schema',worker_version=VERSION,
            status='SKELETON_SCHEMA_FEASIBILITY_CANDIDATE' if primary is None else 'FAILED_CASE_NOT_ADMITTED',
            accepted=False,library_admitted=False,proof_admitted=False,candidate_complete=primary is None,qualification_complete=False,
            prior_qualification_rerun=False,stages=state['stages'],callbacks=state['callbacks'],elapsed_seconds=time.monotonic()-began,
            python_peak_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,source_unchanged=source_unchanged,
            native_peak_bytes=0,native_requests_started=0,native_queries=[],native_transport=dict(closed=True,all_reaped=True,native_exit_code=0,
                native_high_water_bytes=0,subprocesses_started=0,scope='VACUOUS_NO_NATIVE_SUBPROCESS'),guard_compilations=[],
            component_versions=state['versions'],error=None if primary is None else dict(type=type(primary).__name__,message=str(primary),traceback=''.join(traceback.format_exception(primary))),
            first_Root_fault=state['first_fault'] is not None,first_fault_monotonic_ns=state['first_fault_monotonic_ns'],output_rejection=output_rejection,
            provisional_artifacts=provisional,STOP=None if primary is None else 'STOP_WHOLE_NOT_ADMITTED',
            scope='Distinct schema6 and complete admitted-family inference/source/generic exercise feasibility only; no old229/DAG8 rerun, contextual heldout use, principal-schema proof, GCTS/RL advantage or library/proof admission.')
        for name in POSITIVE_FIELDS: value[name]=positives[name] if primary is None else None
        return value

    try:
        if primary is None:
            body=canonical(receipt()); decide_size(body,'ENTIRE_RESULT_JSON'); policy_check()
        else: body=serialize(receipt(),CAPS['result_bytes'])
    except BaseException as error:
        if primary is None: primary=state['first_fault'] if state['first_fault'] is not None else error
        retire_positive(); body=serialize(receipt(),CAPS['result_bytes'])
    output=directory/('result.json' if primary is None else 'failure.json')
    if primary is None:
        progress=dict(phase='BEFORE_WRITE',readback_complete=False)
        try:
            _write_bank_and_readback(output,body,policy_check,progress)
            source_unchanged=False; verify_files(True); source_unchanged=bool(guards); policy_check()
        except BaseException as error:
            if progress['phase']=='BEFORE_WRITE' or progress['phase']=='WRITING_PARTIAL':
                primary=state['first_fault'] if state['first_fault'] is not None else error
                retire_positive(); body=serialize(receipt(),CAPS['result_bytes']); output=directory/'failure.json'; write_body(output,body)
            else: raise
    else: write_body(output,body)
    body=None
    header=dict(schema='proof-search-case-worker-header-v1',case_id=CASE,status='COMPLETE' if primary is None else 'FAILED_CASE_NOT_ADMITTED',
        callbacks=state['callbacks'],seconds=time.monotonic()-began,python_peak_after_output_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        native_peak_bytes=0,source_unchanged=source_unchanged,native_closed_and_reaped=True,first_Root_fault=state['first_fault'] is not None,
        result=raw_pin(output),native_scope='VACUOUS_NO_NATIVE_SUBPROCESS')
    write_body(directory/'worker-header.json',serialize(header,CAPS['log_bytes']))
    print(json.dumps(dict(case_id=CASE,status=header['status'],callbacks=state['callbacks'],seconds=time.monotonic()-began)))
    return 0 if primary is None and source_unchanged and time.monotonic()-began<CAPS['positive_seconds'] and resource.getrusage(resource.RUSAGE_SELF).ru_maxrss<CAPS['memory_bytes'] else 2


if __name__=='__main__':
    if len(sys.argv)!=4: raise SystemExit('usage: fpc_receptor_skeleton_schema_worker_v1.py PLAN ACTUAL_DIR ROOT_START')
    raise SystemExit(main(sys.argv[1],sys.argv[2],float(sys.argv[3])))
