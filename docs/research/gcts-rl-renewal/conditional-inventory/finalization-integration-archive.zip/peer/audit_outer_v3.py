from pathlib import Path
import ast,copy,difflib,hashlib,json
C=Path('/private/tmp/gcts-finalization-integration-peer-20261019');D=Path('/private/tmp/gcts-finalization-integration-ROOT-20261019')
def ds(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def rd(p):return json.loads(Path(p).read_bytes())
def regs(s):return {n.name:n for n in ast.parse(s).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
def dump(n):return ast.dump(n,include_attributes=False)
def literal(s,name):return ast.literal_eval(next(n.value for n in ast.parse(s).body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id==name for t in n.targets)))
checks=[]
def ck(n,v):checks.append(dict(check=n,passed=bool(v)))
contract=rd(D/'outer-Source-contract-v1.json');src=contract['sources'];texts={k:Path(v['path']).read_text()for k,v in src.items()};old={k:Path(v['path']).read_text()for k,v in contract['parents'].items()};priorpath=Path('/private/tmp/gcts-cadence-integration-peer-20261019/typed-once-Source-review-v1.json');prior=rd(priorpath)
ck('whole offered contract',ds(D/'outer-Source-contract-v1.json')['sha256']=='c5193d6546bdbd85fb9f937a51e55bb68b798e422384850f99d470373c2c4f61'and ds(D/'outer-Source-contract-v1.json')['bytes']==3152)
for role in ['runner','observer']:
 ck('whole current '+role,ds(src[role]['path'])==src[role]);ck('whole parent '+role,ds(contract['parents'][role]['path'])==contract['parents'][role]==prior['sources'][role])
 compile(texts[role],src[role]['path'],'exec');ck('unused compile '+role,True)
 nd=list(difflib.ndiff(old[role].splitlines(True),texts[role].splitlines(True)))
 ck('actual inert forward '+role,''.join(difflib.restore(nd,2))==texts[role]);ck('actual inert reverse '+role,''.join(difflib.restore(nd,1))==old[role])
 ip=C/('outer-independent-'+role+'-v2-v3.diff');assert not ip.exists();ip.write_text(''.join(nd))
 for name,node in regs(old[role]).items():
  if (role=='runner'and name in ['intake_subject','run_once'])or(role=='observer'and name=='main'):continue
  ck('exact retained raw/AST '+role+'/'+name,dump(node)==dump(regs(texts[role])[name])and ast.get_source_segment(old[role],node)==ast.get_source_segment(texts[role],regs(texts[role])[name]))
r=texts['runner'];o=texts['observer'];origr=old['runner'];origo=old['observer']
profile="""    need(declaration['finalization_profile']==closure['finalization_profile']==
         'owned-finalization-phase-instrumented-v1',
         'explicit current out-of-band observation profile, never proof authority')
"""
start=r.index('        # Read-only joins of already serialized diagnostics.')
end=r.index("        need(worker_receipt['result_reading']",start)
observation=r[start:end]
ck('exact one new declarationprofile guard',r.count(profile)==1)
ck('new observation only3locals2needs',len(ast.parse('def f():\n'+observation).body[0].body)==5)
normalized=r.replace(profile,'',1).replace(observation,'',1)
normalized=normalized.replace("VERSION = 'owned-evidence-external-once-runner-v3-instrumented'","VERSION = 'owned-evidence-external-once-runner-v2-cadence'",1)
newcold=next(n for n in ast.parse(r).body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='COLD_PIN'for t in n.targets));oldcold=next(n for n in ast.parse(origr).body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='COLD_PIN'for t in n.targets))
normalized=normalized.replace(ast.get_source_segment(r,newcold),ast.get_source_segment(origr,oldcold),1)
ck('whole runner literal inverse exact',normalized==origr)
ck('whole runner AST inverse exact',dump(ast.parse(normalized))==dump(ast.parse(origr)))
obnorm=o.replace("VERSION = 'owned-evidence-final-terminal-observer-v3-instrumented'","VERSION = 'owned-evidence-final-terminal-observer-v2-cadence'",1).replace(src['runner']['sha256'],contract['parents']['runner']['sha256'],1)
ck('whole observer literal+AST inverse exact',obnorm==origo and dump(ast.parse(obnorm))==dump(ast.parse(origo)))
ck('whole numeric/role constants retained',all(literal(r,n)==literal(origr,n)for n in ['LIMITS','KINDS','STORAGES','ORDERINGS','CERTIFICATIONS','REVIEW_ROLES','SCHEMA_SOURCES','RETAINED_ORDERING_SOURCES']))
ck('exact current cold pin',literal(r,'COLD_PIN')==contract['cold']and ds(contract['cold']['path'])==contract['cold'])
ck('nongenerator new joins',not any(isinstance(n,(ast.Yield,ast.YieldFrom))for n in ast.walk(ast.parse('def f():\n'+observation))))
ck('new metadata block onlyboundedbuiltin calls',all((isinstance(n.func,ast.Name)and n.func.id in ['need','type','all','len','canonical'])for n in ast.walk(ast.parse('def f():\n'+observation))if isinstance(n,ast.Call)))
ck('driver observation strictdict/schema/profile',all(x in observation for x in ["type(driver_observation)is dict","type(driver_receipt)is dict","'owned-finalization-observation-v1'","driver_observation['profile']==declaration['finalization_profile']"]))
ck('driver observation all3authorityfalse','all(driver_observation[k]is False'in observation and "('authority','mathematical_authority','resource_authority')"in observation)
ck('driver complete and64KiB whole',"driver_observation['completed']is True and len(canonical(driver_observation))<=65536"in observation)
ck('drivercurrentversion+whole canonical receiptmatch',"driver_receipt['version']=='semantic-family-owned-evidence-driver-v2-instrumented'"in observation and "canonical(driver_observation)==canonical(driver_receipt['finalization_observation'])"in observation)
ck('cold strictdict/schema/profile','type(cold_observation)is dict'in observation and "'owned-cold-phase-observation-v1'"in observation and "cold_observation['profile']==declaration['finalization_profile']"in observation)
ck('cold nonauthority/cutoff/scope256KiB',all(x in observation for x in ['all(cold_observation[k]is False',"'snapshot_cutoff_ns'in cold_observation","type(cold_observation['snapshot_scope'])is str","len(canonical(cold_observation))<=262144"]))
ck('no timestamprepair or completionfabrication',all(x not in observation for x in ['_NOW(','statistics(','observe(','completed=True','snapshot_cutoff_ns=']))
ck('Sourceentry epoch unchanged',r.index('ENTRY_BEGAN_NS = _NOW()')<r.index('import hashlib')and 'began=ENTRY_BEGAN_NS'in r)
ck('strict parser unchanged',all(dump(regs(r)[x])==dump(regs(origr)[x])for x in ['reject_pairs','reject_constant','finite_float','parse']))
ck('captured Python baseline/stat/final no rebaseline',dump(regs(r)['python_custody'])==dump(regs(origr)['python_custody'])and 'OUTER_POLL_METADATA_ONLY_NO_REBASELINE'in r)
ck('complete28+schema1+cold review30scope',all(x in r for x in ["len(worker['project_sources'])==22","len(names)==28","list(worker['project_sources'].values())+list(worker['components'].values())+","list(closure['evidence_sources'].values())+list(SCHEMA_SOURCES.values())+[plan['cold']]"]))
ck('same3 currentroles fullsubjects custody only',set(literal(r,'REVIEW_ROLES'))=={'current_components_Source','once_Source','prospective_plans'}and 'not scope semantics'in r)
ck('same once18subject and max1','subject={k:v for k,v in plan.items() if k!=\'authorization\'}'in r and 'maximum_worker_launches\':1'in r and r.index("marker_pin=write_new(actual/'CONSUMED.json'")<r.index('process=subprocess.Popen('))
ck('exact original4 coldarguments no bootstrap',"plan['cold']['path'],plan['worker_plan']['path'],str(began),str(work_end),str(overall_end)"in r)
run=regs(r)['run_once'];orig_run=regs(origr)['run_once'];nested=lambda f:{n.name:n for n in f.body if isinstance(n,ast.FunctionDef)}
for name,node in nested(orig_run).items():ck('exact nested lifecycle raw/AST '+name,dump(node)==dump(nested(run)[name])and ast.get_source_segment(origr,node)==ast.get_source_segment(r,nested(run)[name]))
ck('permanent reappearance latch and nosignal',all(x in r for x in ['owned PGID reappearance is permanently unaccepted','group_reappearance_observed_ns=group_last_probe_ns','not group_absence_latched','never a reused absent PGID']))
ck('postreap authoritative group plus pipeEOF',all(x in r for x in ['Reaping the leader alone is not closure','both bounded logs fully drained to EOF','final postlog group/EOF/runtime closure']))
ck('positive worker/read/knownexit180 retained',all(x in r for x in ["terminal_ns<work_end","evidence_meta['completed_ns']<work_end","worker_receipt['result_reading']['completed_ns']<work_end"]))
ck('all finalouterchecks210 retained','all complete terminal/custody/resource checks before210'in r and 'closed_ns>=overall_end'in r)
ck('fullforestfreshinverse completion retained',all(x in r for x in ["evidence_meta['status']=='COMPLETE'","evidence_meta['statistics']['prepared']is True","['receiver:complete-legacy-result']['completed']is True","logical_file_bytes","whole result EOF/size/hash join"]))
ck('oldreader/native/point/schemaauthority retained',all(x in r for x in ['literal_bytes_equal','explicit schema registry permission separated from Native proof authority','VERIFIED_WHOLE_FINITE_POINT_REGION','exact native successful wait4 reaping']))
ck('original conservative1GiB sum retained',"aggregate=wait_usage['ru_maxrss']+native['native_high_water_bytes']"in r and "aggregate<=LIMITS['aggregate_peak_bytes']"in r)
ck('original128MiB+9MiB physical diagnostics retained',all(x in r for x in ['len(result_raw)+len(forest_raw)+sum(d[\'bytes\'] for d in metadata)+8388608+1048576',"physical_upper<=LIMITS['result_bytes']",'Logs have their separate complete4MiB gates.']))
ck('observer225 failure-only directPID cleanup',all(x in o for x in ['process.wait(timeout=225)','process.kill();process.wait(timeout=5)','residual_worker_cleanup_requires_inspection=True']))
ck('observerfull210 terminal no proofauthority',all(x in o for x in ["observed<receipt['overall_deadline_ns']","receipt['resource_candidate_accepted'] is True","receipt['stdout_eof'] is True","receipt['stderr_eof'] is True","ROOT_resource_accepted=False","mathematical_proof_accepted=False"]))
ck('observermetadata1MiB andregularlogs4MiB',all(x in o for x in ['_METADATA_BYTES+len(raw)<=1048576','<=4194304']))
for key in ['inherited_independent_lifecycle_peer','inherited_parent_delta_peer']:
 ck('exact named inherited peer '+key,ds(prior[key]['path'])==prior[key])
master=rd(C/'review-criteria-v1.json')['references']['master'];ck('current master unchanged raw',ds(master['path'])==master)
assert all(x['passed']for x in checks),[x for x in checks if not x['passed']]
ap=C/'outer-Source-audit-v1.json';a=dict(schema='finalization-integration-independent-outer-Source-audit-v1',source_only=True,scientific_calls=0,module_imports=0,component_calls=0,fixture_calls=0,checks=checks,check_count=len(checks),mismatch_count=0,findings=[],sources=src,parents=contract['parents'],inert_forward_reverse_directions=4,unused_compiles=2);assert not ap.exists();ap.write_text(json.dumps(a,sort_keys=True,indent=2)+'\n')
rpt=dict(schema='owned-evidence-integration-once-typed-Source-review-v1',author_identity='/root',reviewer_identity='/root/conventional_control_review',source_review_passed=True,source_only=True,scientific_calls=0,module_imports=0,module_evaluations=0,component_calls=0,fixture_calls=0,codec_replays=0,inverse_replays=0,Native_calls=0,Model_calls=0,renderer_calls=0,scientific_acceptance=False,actual_execution_authorized=False,mismatch_count=0,findings=[],check_count=len(checks),sources=src,required_subjects=list(src.values()),cold=contract['cold'],parents=contract['parents'],parent_review=ds(priorpath),inherited_independent_lifecycle_peer=prior['inherited_independent_lifecycle_peer'],inherited_parent_delta_peer=prior['inherited_parent_delta_peer'],Source_contract=ds(D/'outer-Source-contract-v1.json'),current_master=master,criteria=ds(C/'review-criteria-v1.json'),static_audit=ds(ap),inert_forward_reverse_directions=4,unused_compiles=2,
 scope='Independent Root new outer/observer observation-coupling delta only. Whole literal and AST inverse removal restores exact parent Sources after the declared versions/current pins and bounded metadata joins. No production/component/function/module was executed. Complete current30subject Source/closure, separate two-plan and grant/runtime/resource/proof admissions remain pending.',
 exact_clock_scope=dict(worker_positive='Original180s monotonic Source-entry positive worker work, complete saved inverse/result reading/header and known worker exit. All admitted outputs require work completed and knownexit before180.',outer_terminal='Later full raw/resource/custody/group/EOF/metadata joins and observed external terminal210; observer225failurecleanup only.',nonclaim='No new all-outer-check180 or CPU-time interpretation, no observer/Python prelude inclusion, no changed callback scheduling.'),
 Source_backed_conclusions=['All retained top-level helpers and nested wait4/drain/group/cleanup bodies are raw/AST exact. Strict duplicate/nonfinite JSON parser, stablePython metadata polling+final wholehash, original argv/maxonce and resource/Native/point/savedinverse gates are preserved.','New intake adds only exact common declaration/closure finalization_profile. Normal worker header must carry complete bounded64KiB nonauthority current driver observation canonically equal to returned driverreceipt and a256KiB nonauthority cold snapshot with explicit cutoff/scope.','The new block reads already serialized ordinary metadata using bounded builtin/canonical operations, no additional component/statistics/clock/stream calls or scientific roots. It does not repair timestamps or promote local Native diagnostic stages.','Cold None clocks, errors and truncation may remain literal diagnostic data; they are not a fabricated complete phase trace or a mathematical/refinement certificate. Driver completion is required separately from cold phase availability.'],
 limitations=['This is Source-only coupling reasoning; helper27+3 qualification does not establish production admission, real deadline retention, full phase visibility, fit or runtime performance.','Scope lookup requires complete literal descriptors, but Root must independently adopt semantic coverage/ancestry/current30subjects and full two-plan capsules before grants. One Control identity fills the disclosed scopes.','Existing parent runtime/lifecycle/mathematical bodies rely exact retained peer ancestry. Control authored historical outer/symbolic/helper algorithms, not this Root delta; no fresh independent self-certification or kernel/GCTS conformance theorem.','New metadata validation consumes charged outer time. Nested intervals are not additive, snapshot cutoff excludes later work, coldguard counts are not per-origin totals and old decode_seconds includes inverse.','Separate Darwin worker+Native highwater sum remains1GiB, not simultaneous RAM or continuousRSS. Complete physical/logical outputs and all observation/header/failuremetadata retain128MiB/log/outerreservation profile; outer/observer RAM remains excluded.','All old consumed fullpipeline failures and older symbolic positive/standalone inverse status remain. No failed-prefix rescue, new theorem, causal speed/RAM/GCTS/RL or broad benchmark gain is supplied.'],
 authorship_disclosure=prior['authorship_disclosure'],tools_stopped_pending_current_components_and_plans=True)
rp=C/'typed-once-Source-review-v1.json';assert not rp.exists();rp.write_text(json.dumps(rpt,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(receipt=ds(rp),audit=ds(ap),checks=len(checks),mismatch_count=0),indent=2))
