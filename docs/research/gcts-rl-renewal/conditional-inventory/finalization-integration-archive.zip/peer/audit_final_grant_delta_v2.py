from pathlib import Path
import hashlib,json
C=Path('/private/tmp/gcts-finalization-integration-peer-20261019');D=Path('/private/tmp/gcts-finalization-integration-ROOT-20261019')
def canon(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def read(p):return json.loads(Path(p).read_bytes())
def desc(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
checks=[]
def ck(n,p):checks.append(dict(check=n,passed=bool(p)))
def contains(tree,target):
 if canon(tree)==canon(target):return True
 if type(tree)is dict:return any(contains(v,target)for v in tree.values())
 if type(tree)is list:return any(contains(v,target)for v in tree)
 return False
sp=D/'ROOT-pregrant-scope-adoption-v1.json';gp=D/'ROOT-scope-adoption-and-grants-v1.json';scope=read(sp);grants=read(gp);pros=read(C/'typed-prospective-plan-review-v1.json');comp=read(C/'typed-components-Source-review-v1.json');once=read(C/'typed-once-Source-review-v1.json');manifest=read(D/'false-plan-manifest-v1.json')
ck('exact offered Root scope adoption',desc(sp)==dict(path=str(sp),bytes=3643,sha256='13924a2ba9fc5adc2314b17bde6412a4f199edbb84cbe928306b9458a4133149'))
ck('exact offered Root grant adoption',desc(gp)==dict(path=str(gp),bytes=2643,sha256='60b852b332459961a73c918774e8911c13a10c29a5f7cbf64867e60c18223b06'))
ck('Root adopts limited scopes without science/math/resource acceptance',scope['author_identity']=='/root'and scope['scientific_calls']==0 and scope['scientific_acceptance']is False and scope['ROOT_resource_accepted']is False and scope['mathematical_proof_accepted']is False and grants['source_scopes_adopted']is True)
ck('exact 2 ordered grants fixed then symbolic',[r['mode']for r in grants['plans']]==['fixed','symbolic']and len(grants['plans'])==2)
roles={k:desc(C/f)for k,f in [('current_components_Source','typed-components-Source-review-v1.json'),('once_Source','typed-once-Source-review-v1.json'),('prospective_plans','typed-prospective-plan-review-v1.json')]}
ck('Root review role descriptors exact three scopes',grants['review_roles']==roles and scope['reviews']=={Path(x['path']).name:x for x in roles.values()})
role_spec={'current_components_Source':('owned-evidence-integration-components-typed-Source-review-v1','source_review_passed',comp),'once_Source':('owned-evidence-integration-once-typed-Source-review-v1','source_review_passed',once),'prospective_plans':('owned-evidence-integration-prospective-plan-review-v1','prospective_review_passed',pros)}
for role,(schema,field,r)in role_spec.items():
 ck('receipt role schema/pass/nonactivation '+role,r['schema']==schema and r[field]is True and r['source_only']is True and r['scientific_calls']==0 and r['scientific_acceptance']is False and r['actual_execution_authorized']is False and r['reviewer_identity']=='/root/conventional_control_review')
ck('one reviewer in three roles explicitly disclosed',all(r['reviewer_identity']=='/root/conventional_control_review'for _,_,r in role_spec.values())and 'One Control identity'in scope['authorship_limits']and grants['inherited_author_overlap_disclosed']is True)
expected={'fixed':dict(subject='56af7111528c20e2c6fd4221a0ecef72ffe909d3195e610f663f65c977c5f18b',plan_sha='90ab64567a6131537b4c98dac2031ea2d8e3f768f2a89a997acc55b330575ae0',plan_bytes=2810,auth_sha='b689509b468fe680408a7419a0a214a55ba3b9b5d0bee72eb44fbb2ad33a6a30',auth_bytes=10703),'symbolic':dict(subject='d8daeac92b90f23d1c18f88f735dec57e93289d273099d875cf7da81a80a4b14',plan_sha='4bfc700c7af3d009d816fb2d6ef81dcf42cb510a9c04e603796c3eac2983d493',plan_bytes=2825,auth_sha='ee22007e034dcc1d8fc5b20bdbfe9100021099f8ef602e79fba8e261c0ca0f30',auth_bytes=10706)}
rows=[];pinmap={}
def collect(x):
 if type(x)is dict:
  if {'path','sha256','bytes'}<=x.keys()and type(x['path'])is str and x['path'].startswith('/')and type(x['bytes'])is int:
   d={k:x[k]for k in ['path','sha256','bytes']};pinmap[(d['path'],d['sha256'],d['bytes'])]=d
  for v in x.values():collect(v)
 elif type(x)is list:
  for v in x:collect(v)
collect(comp['required_current_subjects']);collect(roles);collect(pros['declaration']);collect(pros['closure']);collect(scope['current_master'])
for row,prior in zip(grants['plans'],pros['subjects']):
 mode=row['mode'];ex=expected[mode];plan=read(row['once_plan']['path']);old=read(prior['false_once_plan']['path']);auth=read(row['authorization']['path']);sub={k:v for k,v in plan.items()if k!='authorization'};oldsub={k:v for k,v in old.items()if k!='authorization'};sha=hashlib.sha256(canon(sub)).hexdigest();worker=read(plan['worker_plan']['path'])
 ck('exact offered true plan raw '+mode,desc(row['once_plan']['path'])==row['once_plan']and row['once_plan']['sha256']==ex['plan_sha']and row['once_plan']['bytes']==ex['plan_bytes'])
 ck('exact offered grant raw '+mode,desc(row['authorization']['path'])==row['authorization']and row['authorization']['sha256']==ex['auth_sha']and row['authorization']['bytes']==ex['auth_bytes'])
 ck('exact reviewed false plan raw '+mode,desc(prior['false_once_plan']['path'])==prior['false_once_plan'])
 ck('only authorization field changed '+mode,set(plan)==set(old)and [k for k in old if canon(old[k])!=canon(plan[k])]==['authorization'])
 ck('literal18 subject retained independently '+mode,len(sub)==18 and canon(sub)==canon(oldsub)==canon(prior['subject'])and sha==prior['subject_sha256']==row['subject_sha256']==ex['subject'])
 ck('false deliberately nonrunnable stub retained '+mode,old['authorization']==dict(path='NO_AUTHORIZATION_FALSE_PLAN',bytes=0,sha256='NO_AUTHORIZATION'))
 ck('new authorization descriptor joined '+mode,plan['authorization']==row['authorization'])
 ck('strict exact7field Root maxone grant '+mode,set(auth)=={'schema','author_identity','subject_sha256','actual_execution_authorized','maximum_actual_invocations','review_roles','scope'}and auth['schema']=='ROOT-owned-evidence-integration-once-authorization-v1'and auth['author_identity']=='/root'and auth['actual_execution_authorized']is True and type(auth['maximum_actual_invocations'])is int and auth['maximum_actual_invocations']==1 and auth['subject_sha256']==sha)
 ck('exact3 complete auth roles '+mode,set(auth['review_roles'])==set(role_spec))
 required={'current_components_Source':comp['required_current_subjects'],'once_Source':[plan['runner'],plan['observer']],'prospective_plans':[plan['integration_declaration'],plan['runtime_closure'],plan['worker_plan']]}
 for role,(schema,field,receipt)in role_spec.items():
  gate=auth['review_roles'][role]
  ck('exact role keys/identity/receipt '+mode+'/'+role,set(gate)=={'receipt','reviewer_identity','required_subjects'}and gate['reviewer_identity']==receipt['reviewer_identity']and gate['receipt']==roles[role])
  ck('whole exact role subject coverage '+mode+'/'+role,sorted(map(canon,gate['required_subjects']))==sorted(map(canon,required[role]))and all(contains(receipt,x)for x in gate['required_subjects']))
 ck('current30Source scope retained '+mode,len(auth['review_roles']['current_components_Source']['required_subjects'])==30)
 ck('full worker+closure/declaration bindings retained '+mode,plan['worker_plan']==prior['worker_plan']and plan['integration_declaration']==prior['integration_declaration']==pros['declaration']and plan['runtime_closure']==prior['runtime_closure']==pros['closure'])
 ck('original profile/state/currentSource no field change '+mode,all(canon(plan[k])==canon(old[k])for k in ['limits','environment','cold','python','receiver_id','mode','search_ordering','inventory_certification_mode','model_storage','result_reader'])and plan['invocation_id']==worker['invocation_id']and plan['actual_directory']==worker['actual_directory'])
 actual=Path(plan['actual_directory']);terminal=Path(row['once_plan']['path']).with_name(Path(row['once_plan']['path']).stem+'-terminal-observation')
 ck('canonical fresh named local actual '+mode,actual.parent==D and actual==actual.resolve())
 for label,path in [('actual',actual),('actual consumed',actual/'CONSUMED.json'),('observer',terminal),('observer consumed',terminal/'CONSUMED.json'),('false observer',Path(prior['false_once_plan']['path']).with_name(Path(prior['false_once_plan']['path']).stem+'-terminal-observation'))]:ck('absent no marker/retry '+mode+'/'+label,not path.exists()and not path.is_symlink())
 collect(plan);collect(worker);collect(auth)
 rows.append(dict(mode=mode,subject=sub,subject_sha256=sha,false_once_plan=prior['false_once_plan'],once_plan=row['once_plan'],authorization=row['authorization'],actual_directory=str(actual),observer_directory=str(terminal),maximum_actual_invocations=1,authorization_only_change=True))
for d in pinmap.values():ck('whole unchanged active raw pin '+d['path'],desc(d['path'])==d)
ck('unique exactly2subjects/iids/actuals',len({x['subject_sha256']for x in rows})==len({x['subject']['invocation_id']for x in rows})==len({x['actual_directory']for x in rows})==2)
assert all(x['passed']for x in checks),[x for x in checks if not x['passed']]
audit=dict(schema='finalization-integration-independent-final-grant-delta-audit-v1',saved_metadata_only=True,source_only=True,scientific_calls=0,module_imports=0,module_evaluations=0,component_calls=0,fixture_calls=0,Native_calls=0,codec_replays=0,inverse_replays=0,checks=checks,check_count=len(checks),raw_pin_count=len(pinmap),mismatch_count=0,findings=[],subjects=rows,Root_scope_adoption=desc(sp),Root_grant_adoption=desc(gp))
ap=C/'final-grant-delta-audit-v1.json';assert not ap.exists();ap.write_text(json.dumps(audit,sort_keys=True,indent=2)+'\n')
receipt=dict(schema='owned-evidence-integration-final-grant-delta-review-v1',author_identity='/root',reviewer_identity='/root/conventional_control_review',final_grant_delta_review_passed=True,source_only=True,saved_metadata_only=True,scientific_calls=0,module_imports=0,module_evaluations=0,component_calls=0,fixture_calls=0,Native_calls=0,Model_calls=0,codec_replays=0,inverse_replays=0,renderer_calls=0,scientific_acceptance=False,actual_execution_authorized=False,check_count=len(checks),mismatch_count=0,findings=[],raw_pin_count=len(pinmap),static_audit=desc(ap),subjects=rows,Root_scope_adoption=desc(sp),Root_grant_adoption=desc(gp),current_reviews=roles,scope='Narrow independent ordinary-metadata/raw-byte true-grant delta and prelaunch freshness review only. Both exact eighteen-field reviewed subjects are unchanged; only authorization descriptors changed to separate Root maximum-one grants with three explicitly scoped reviews by one Control identity. No launch, runtime acceptance or scientific authority is delegated by this receipt.',limitations=['Fresh-path checks are a point-in-time saved filesystem observation; Root must preflight immediately before its serial once invocations.','Source/policy/input/Python/Z3/Native artifacts were whole-raw hashed only. No scientific/Native/codec/inverse/harness/module/function evaluation or opaque-program decode occurred.','Inherited author overlap and current scoped Source/metadata review limits remain in Root explicit adoption and all three current receipts. This is not independent kernel soundness or production qualification.','Original worker-positive/read/known-exit180 and later outer210 boundaries, separate Darwin highwater sum and original cap/profile limits remain exactly the reviewed subjects. No resource or proof outcome follows before complete saved actual admission.'],tools_stopped_and_idle_pending_Root_authoritative_cohort_closure=True)
rp=C/'typed-final-grant-delta-review-v1.json';assert not rp.exists();rp.write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(receipt=desc(rp),audit=desc(ap),check_count=len(checks),raw_pin_count=len(pinmap),mismatch_count=0),indent=2))
