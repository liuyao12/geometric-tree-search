from pathlib import Path
import ast,copy,hashlib,json,stat
C=Path('/private/tmp/gcts-finalization-integration-peer-20261019');D=Path('/private/tmp/gcts-finalization-integration-ROOT-20261019');S=Path('/private/tmp/gcts-finalization-instrumentation-peer-20261019')
def ds(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def rd(p):return json.loads(Path(p).read_bytes())
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def lit(s,name):return ast.literal_eval(next(n.value for n in ast.parse(s).body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id==name for t in n.targets)))
checks=[]
def ck(n,v):checks.append(dict(check=n,passed=bool(v)))
m=rd(D/'false-plan-manifest-v1.json');cl=rd(m['runtime_closure']['path']);decl=rd(m['case_declaration']['path']);parent=rd(cl['previous_instrumentation_parent_closure']['path']);prev=rd('/private/tmp/gcts-cadence-integration-peer-20261019/typed-components-Source-review-v1.json');dr=rd(S/'typed-driver-Source-review-v2.json');cr=rd(S/'typed-cold-Source-review-v1.json');helper=rd(S/'typed-saved-helper-qualification-review-v2.json');outer=rd(C/'typed-once-Source-review-v1.json')
ck('exact offered manifest whole',ds(D/'false-plan-manifest-v1.json')['sha256']=='0a3c7f6d3cf0566eec884478924a31699292cf084c40432f8b8d4fbd8d72e2da'and ds(D/'false-plan-manifest-v1.json')['bytes']==4297)
ck('exact offered closure whole',ds(m['runtime_closure']['path'])==m['runtime_closure']and m['runtime_closure']['sha256']=='efc15108d03dc3cf75151867ed85598d8ab264547b1d3e38e52545b3b2d86406')
ck('exact offered declaration whole',ds(m['case_declaration']['path'])==m['case_declaration']and m['case_declaration']['sha256']=='d9b6d91f5348da44ada03616ca527e4d7b42620017e6929b52b3835f539922af')
ck('same22project Sources',cl['project_sources']==prev['project_sources']==parent['project_sources']and len(cl['project_sources'])==22)
ck('same boundedtransport only changed driver',set(cl['additional_nonseed_components'])=={'receiver_driver','bounded_transport'}and cl['additional_nonseed_components']['bounded_transport']==prev['components']['bounded_transport'])
ck('current driver raw independentlyreviewed',cl['additional_nonseed_components']['receiver_driver']==dr['source']and dr['source_review_passed']is True)
ck('current cold raw independentlyreviewed',cl['cold']==cr['source']==m['cold']and cr['source_review_passed']is True)
ck('evidence+inverse+schema Sources unchanged',cl['evidence_sources']==parent['evidence_sources']==prev['evidence_sources']and cl['schema_sources']==parent['schema_sources']==prev['schema_sources'])
ck('evidence fullprofile unchanged',cl['evidence_profile']==parent['evidence_profile']==prev['evidence_profile']==decl['evidence_profile'])
aliases=dict(cl['project_sources'],semantic_receiver_driver=cl['additional_nonseed_components']['receiver_driver'],bounded_request_oracle=cl['additional_nonseed_components']['bounded_transport']);aliases.update(owned_evidence_adapter=cl['evidence_sources']['adapter'],exact_evidence_arena=cl['evidence_sources']['arena'],owned_inventory_join=cl['evidence_sources']['join'],independent_forest_inverse=cl['evidence_sources']['inverse'])
ck('literal28 original+component+evidence aliases',len(aliases)==28 and aliases==cl['materialized_aliases'])
all_sources=dict(aliases,**cl['schema_sources'],__cold__=cl['cold'])
ck('full30scope22+2+4+1+1',len(all_sources)==30 and cl['current_scientific_alias_count']==28 and cl['schema_extra_component_count']==1)
ck('current30 Source census exactaliases',len(cl['Source_AST_census'])==30 and {x['alias']for x in cl['Source_AST_census']}==set(all_sources))
texts={};trees={};callables={};census={x['alias']:x for x in cl['Source_AST_census']};imports_total=0;dyn_total=0;edges=[];unresolved=[]
stdlib=set(cl['current_import_census_summary']['stdlib_roots']);external=set(cl['external_imports'])
def classify(module,level=0):
 if level:return 'relative_unresolved'
 root=module.split('.')[0]if module else ''
 if root in all_sources:return 'owned_internal'
 if root in external:return 'inherited_external'
 if root in stdlib:return 'declared_Python_stdlib_or_builtin'
 unresolved.append((module,level));return 'unclassified_root'
for alias,row in all_sources.items():
 raw=Path(row['path']).read_bytes();ck('whole exact project Source '+alias,ds(row['path'])==row)
 s=raw.decode();tree=ast.parse(s,filename=row['path']);texts[alias]=s;trees[alias]=tree;compile(s,row['path'],'exec');ck('unused compile '+alias,True)
 ck('complete AST+Source pin '+alias,census[alias]['source']==row and hashlib.sha256(ast.dump(tree,include_attributes=True).encode()).hexdigest()==census[alias]['AST_sha256'])
 imp=[];dyn=[]
 for node in ast.walk(tree):
  if isinstance(node,ast.Import):
   for item in node.names:
    k=classify(item.name);imp.append(dict(kind='import',module=item.name,asname=item.asname,line=node.lineno,column=node.col_offset,classification=k))
    if k=='owned_internal':edges.append(dict(source=alias,target=item.name.split('.')[0],line=node.lineno))
  elif isinstance(node,ast.ImportFrom):
   k=classify(node.module,node.level);imp.append(dict(kind='from',module=node.module,level=node.level,names=[dict(name=x.name,asname=x.asname)for x in node.names],line=node.lineno,column=node.col_offset,classification=k))
   if k=='owned_internal':edges.append(dict(source=alias,target=node.module.split('.')[0],line=node.lineno))
  elif isinstance(node,ast.Call)and((isinstance(node.func,ast.Name)and node.func.id=='__import__')or(isinstance(node.func,ast.Attribute)and node.func.attr=='import_module')):
   module=node.args[0].value if node.args and isinstance(node.args[0],ast.Constant)and type(node.args[0].value)is str else None
   dyn.append(dict(line=node.lineno,column=node.col_offset,callable_AST=ast.dump(node.func,include_attributes=False),literal_module=module,argument_AST=ast.dump(node.args[0],include_attributes=False)if node.args else None,classification=classify(module)if module is not None else'nonliteral_dynamic_site'))
 ck('all static import sites exact '+alias,imp==census[alias]['imports']);ck('all dynamic import AST exact '+alias,dyn==[{k:v for k,v in x.items()if k!='scope'}for x in census[alias]['dynamic_import_sites']])
 imports_total+=len(imp);dyn_total+=len(dyn)
 callables[alias]=[dict(name=n.name,line=n.lineno,kind=type(n).__name__)for n in ast.walk(tree)if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))]
ck('full current150static5dynamic census',imports_total==cl['current_import_census_summary']['static_import_sites']==150 and dyn_total==cl['current_import_census_summary']['dynamic_import_sites']==5)
ck('all actual internal edges exact',edges==cl['current_import_census_summary']['internal_edges'])
ck('only2 nonliteral cold sites nohiddenmodule',len(cl['current_import_census_summary']['nonliteral_dynamic_sites'])==2 and all(x['alias']=='__cold__'for x in cl['current_import_census_summary']['nonliteral_dynamic_sites'])and not unresolved and cl['current_import_census_summary']['unclassified_roots']==[])
ck('helper harness absent entire30productionSource',all('qualify_finalization_harness'not in s and '_owned_finalization_qualification'not in s for s in texts.values()))
driver=texts['semantic_receiver_driver'];cold=texts['__cold__'];driver_names={x['name']for x in callables['semantic_receiver_driver']};cold_names={x['name']for x in callables['__cold__']}
ck('new driver observation class+methods fullASTcovered',{'_OwnedFinalizationObservation','call','snapshot','record','attach','complete'}<=driver_names)
ck('all new cold metadata functions fullASTcovered',{'new_cold_observation','cold_phase_begin','cold_phase_end','cold_phase_failure','cold_count','cold_guard_finished','cold_observation_snapshot','bounded_driver_diagnostics','cold_failure_diagnostics'}<=cold_names)
ck('current raw seal walks functions/classes+properties',all(x in cold for x in ['for module in modules:','value.__module__==module.__name__','klass(value)','f.__code__ is code','f.__defaults__ is defaults','f.__kwdefaults__ is kwdefaults','for f in (value.fget,value.fset,value.fdel)']))
ck('base28+Z3+cold seal before extra schema no rebaseline',cold.index('module_guards.append(seal_callables(list(loaded.values())+z3_modules+[sys.modules[__name__]]))')<cold.index('module_guards.append(seal_callables([module]))'))
ck('current finalization profile exact declarationclosure',cl['finalization_profile']==decl['finalization_profile']==m['finalization_profile']=='owned-finalization-phase-instrumented-v1')
ck('profile included in current cold',"integration['finalization_profile']==FINALIZATION_PROFILE"in cold and "profile=FINALIZATION_PROFILE"in cold and "finalization_observation=driver_observation"in cold)
ck('same whole Native/policy/runtime/Z3 capsule',all(cl[k]==parent[k]for k in ['fixed_native_inputs','native_CPP','runtime','Z3','Z3_imports','schema_kernel_source']))
ck('same inherited scientific peerbindings',cl['inherited_role_bindings']==parent['inherited_role_bindings']==prev['inherited_role_bindings'])
# Whole descriptors only, including opaque Native/program binaries: no parse/decode.
pins={}
def collect(v):
 if type(v)is dict:
  if {'path','sha256','bytes'}<=set(v)and type(v['path'])is str and v['path'].startswith('/')and type(v['bytes'])is int:pins[(v['path'],v['sha256'],v['bytes'])]={k:v[k]for k in ['path','sha256','bytes']}
  for x in v.values():collect(x)
 elif type(v)is list:
  for x in v:collect(x)
collect(cl)
for row in pins.values():ck('full closure raw pin '+row['path'],ds(row['path'])==row)
ck('stdlib loader limitations disclosed',any('not an activation seal'in x for x in cl['limitations'])and 'recursive standard-library imports'in cl['runtime']['stdlib_scope'])
ck('helper finite qualification not promoted',cl['prerequisite_helper_qualification']['full_pipeline_qualified']is False and helper['full_pipeline_qualified']is False and helper['finite_helper_qualification_supported']is True)
ck('Source reviews+input master bound',all(ds(x['path'])==x for x in decl['prerequisite_finalization_components'].values())and ds(m['current_master']['path'])==m['current_master']==decl['current_master']==cl['current_master'])
assert all(x['passed']for x in checks),[x for x in checks if not x['passed']]
ap=C/'components-current-Source-audit-v1.json';audit=dict(schema='finalization-integration-independent-current-components-audit-v1',source_only=True,scientific_calls=0,module_imports=0,component_calls=0,fixture_calls=0,checks=checks,check_count=len(checks),mismatch_count=0,findings=[],sources=all_sources,current_callable_AST_census=callables,closure=m['runtime_closure'],raw_pin_count=len(pins),unused_compiles=30);assert rd(ap)==audit
rc=dict(metadata_handoff=ds('/private/tmp/gcts-finalization-integration-library-20261019/handoff-v1.json'),schema='owned-evidence-integration-components-typed-Source-review-v1',author_identity='/root',author_identities=['/root','/root/conventional_library'],metadata_author_identity='/root/conventional_library',reviewer_identity='/root/conventional_control_review',source_review_passed=True,source_only=True,scientific_calls=0,module_imports=0,module_evaluations=0,component_calls=0,fixture_calls=0,codec_replays=0,inverse_replays=0,Native_calls=0,Model_calls=0,renderer_calls=0,scientific_acceptance=False,actual_execution_authorized=False,mismatch_count=0,findings=[],check_count=len(checks),static_audit=ds(ap),project_sources=cl['project_sources'],components=cl['additional_nonseed_components'],evidence_sources=cl['evidence_sources'],schema_sources=cl['schema_sources'],cold=cl['cold'],required_current_subjects=list(all_sources.values()),required_subjects=list(all_sources.values()),current_master=cl['current_master'],closure=m['runtime_closure'],finalization_profile=cl['finalization_profile'],evidence_profile=cl['evidence_profile'],driver_instrumentation_Source=ds(S/'typed-driver-Source-review-v2.json'),cold_instrumentation_Source=ds(S/'typed-cold-Source-review-v1.json'),helper_finite_saved_scope=ds(S/'typed-saved-helper-qualification-review-v2.json'),prior_components_Source_review=ds('/private/tmp/gcts-cadence-integration-peer-20261019/typed-components-Source-review-v1.json'),inherited_role_bindings=cl['inherited_role_bindings'],criteria=ds(C/'review-criteria-v1.json'),unused_compiles=30,
 scope='Independent current full30Source raw/AST import/callable-custody and instrumentation coupling review. Existing22project, transport,4evidence and schema Sources remain exact to inherited peer-bound parent; only driverV6/coldV6 observation deltas are rebound to their distinct current scoped reviews. No engine/module/component/function was imported or executed. This is not mathematical or production qualification.',
 exact_clock_scope=outer['exact_clock_scope'],limitations=['All30wholeSource/importAST hashes include new driver observation methods and cold metadata helpers; unchanged runtime callable walker covers current functions/classes when later loaded. A static census is not an activation/callback/default-cell/OS memory seal.','Direct stdlib entry pins remain inherited partial references. Bundled stdlib/builtins/C-extension/native loader and OS remain trusted; no full OS dynamic closure or universal mathematical/kernel soundness is proved.','Nonliteral import sites are the retained fixed-map cold imports, not evaluated by this review. Z3/Native/program/opaque microcode are rawhashed only; no solver/function/codec/program decoding or replay was performed.','Helper27+3qualification exercises mock metadata APIs and charged startup only, not production finalization/inverse/Native/Model/complete evidence cost or fit. All fresh productiongates remain separate.','Snapshots are cutoff-scoped and may be partial/None/UNAVAILABLE. Nestedinclusive intervals overlap; coldlocalguard counts are not allorigin totals. Old decode_seconds includes inverse. Extra observation cost is fullycharged under originalcaps.','Exact two prospective subjects, Root scopeadoption/maxonegrants/freshness and actual saved/proof/resource admission remain pending. All prior negativepairs/older symbolicpositive retain status; no causalperformance/GCTS/RL/generaltheorem claim.'],inherited_authorship_disclosure_historical=prev['authorship_disclosure'],authorship_disclosure='Control authored historical symbolic/helper/driver/outer algorithms and prior scoped reviews, but did not author current Root driverV6, Library coldV6, Root outerV3/observerV3 or the operative owned-evidence/arena/inverse Sources. Current author deltas and exact inherited raw/AST custody are independently reviewed. Genuine older peers remain named ancestry; no fresh independent self-certification of inherited Control algorithms or mathematical/kernel soundness is asserted. One Control identity fills three separately declared roles, not three independent reviewers.',tools_stopped_pending_separate_plan_review=True)
cp=C/'typed-components-Source-review-v1.json';assert not cp.exists();cp.write_text(json.dumps(rc,sort_keys=True,indent=2)+'\n')

# Distinct two-plan metadata role; no intake/proof/engine functions invoked.
pc=[]
def pk(n,v):pc.append(dict(check=n,passed=bool(v)))
pair=[];common_fields=['cold','components','declaration','inventory_certification_mode','model_storage','native_inputs','policy','project_sources','python','receiver_id','result_reader','runtime_closure','schema','search_ordering','z3']
cap=rd(decl['parent_structural_declaration']['path']);prior_decl=rd(decl['parent_instrumentation_declaration']['path']);oldworkers=[];prior_manifest=rd('/private/tmp/gcts-cadence-integration-ROOT-20261019/false-plan-manifest-v1.json');prior_workers={x['row']['mode']:rd(x['worker_plan']['path'])for x in prior_manifest['plans']}
pk('fullcapsule original equality',decl['parent_structural_declaration']==prior_decl['parent_structural_declaration']and decl['selected_receiver']==prior_decl['selected_receiver']and decl['selected_receiver_id']=='prospective-fol-20261018-001' and decl['selected_receiver']==next(x for x in cap['receivers']if x['id']==decl['selected_receiver_id']))
pk('schedule fixedthen symbolic literal',decl['schedule']==[x['row']for x in m['plans']]and [x['mode']for x in decl['schedule']]==['fixed','symbolic']and [x['order']for x in decl['schedule']]==[1,2])
pk('exact common limits unchanged',decl['limits']==prior_decl['limits']and decl['limits']['work_seconds']==180 and decl['limits']['overall_seconds']==210 and decl['limits']['conservative_worker_plus_native_peak_bytes']==1073741824 and decl['limits']['result_bytes']==134217728)
pk('explicit costs/claim scopes',all(x in decl['clock_scope']for x in ['before180','before210','no standalone qualifier'])and all(x in decl['scope']for x in ['Helper-only prerequisite does not qualify','no ordinary-storage arm','causal acceleration']))
pk('current profile matching coldandclosure',decl['finalization_profile']==cl['finalization_profile']==m['finalization_profile'])
pk('no actual/RLtraining authority',decl['actual_execution_authorized']is False and decl['new_RL_training']is False and decl['goal_complete']is False and cl['actual_execution_authorized']is False and m['actual_execution_authorized']is False)
fields={'schema','invocation_id','mode','search_ordering','inventory_certification_mode','model_storage','result_reader','receiver_id','actual_directory','runner','observer','python','cold','worker_plan','integration_declaration','runtime_closure','authorization','limits','environment'}
rows=[]
for item in m['plans']:
 mode=item['row']['mode'];wp=rd(item['worker_plan']['path']);once=rd(item['false_once_plan']['path']);sub={k:v for k,v in once.items()if k!='authorization'};sha=hashlib.sha256(canonical(sub)).hexdigest()
 pk('whole workerplan '+mode,ds(item['worker_plan']['path'])==item['worker_plan']);pk('whole falseonce '+mode,ds(item['false_once_plan']['path'])==item['false_once_plan'])
 pk('exact19planfields and18subject '+mode,set(once)==fields and len(sub)==18)
 pk('deliberately unlaunchable authstub '+mode,once['authorization']==dict(path='NO_AUTHORIZATION_FALSE_PLAN',bytes=0,sha256='NO_AUTHORIZATION'))
 for key in ['invocation_id','mode','search_ordering','inventory_certification_mode','actual_directory','cold','python','receiver_id','result_reader','model_storage','integration_declaration','runtime_closure']:
  pk('wholeworker-once common '+mode+'/'+key,wp[key]==once[key])
 for key in ['invocation_id','mode','search_ordering','inventory_certification_mode','actual_directory','receiver_id','result_reader','model_storage']:pk('schedule literal '+mode+'/'+key,once[key]==item['row'][key])
 pk('whole currentnew outercold '+mode,once['runner']==m['runner']==outer['sources']['runner']and once['observer']==m['observer']==outer['sources']['observer']and once['cold']==m['cold']==cl['cold'])
 pk('wholeworker/currentclosuremaps '+mode,wp['project_sources']==cl['project_sources']and wp['components']==cl['additional_nonseed_components'])
 pk('current declaration+closure complete '+mode,once['integration_declaration']==m['case_declaration']and once['runtime_closure']==m['runtime_closure']and once['worker_plan']==item['worker_plan'])
 pk('exact prior full input+policy+Native/runtime unchanged '+mode,wp['declaration']==decl['parent_structural_declaration']and all(wp[k]==prior_workers[mode][k]for k in ['declaration','native_inputs','policy','python','z3','receiver_id','mode','search_ordering','inventory_certification_mode','model_storage','result_reader']))
 pk('native descriptors equal full closure '+mode,wp['native_inputs']==dict(native_cpp=cl['native_CPP']['binary'],opaque_microcode_gzip=cl['fixed_native_inputs']['opaque_microcode_gzip'],program_and_template=cl['fixed_native_inputs']['program_and_template']))
 pk('pinned policy/Python equal raw '+mode,ds(wp['policy']['path'])==wp['policy']and ds(wp['python']['path'])==wp['python']==cl['runtime']['Python_executable'])
 pk('same wholeZ3 packagefiledescs '+mode,len(wp['z3']['files'])==cl['Z3']['file_count']==41 and all({k:x[k]for k in ['path','sha256','bytes']}==y for x,y in zip(cl['Z3']['files'],wp['z3']['files']))and wp['z3']['library']==next({k:x[k]for k in ['path','sha256','bytes']}for x in cl['Z3']['files']if x['path']==wp['z3']['library']['path']))
 pk('once original caps literal '+mode,once['limits']==lit(Path(m['runner']['path']).read_text(),'LIMITS'))
 pk('strict minimal child environment '+mode,once['environment']==dict(LANG='C',LC_ALL='C',PYTHONHASHSEED='0'))
 pk('notargetroute/extrahelperworkerfields '+mode,set(wp)=={'actual_directory','cold','components','declaration','integration_declaration','inventory_certification_mode','invocation_id','mode','model_storage','native_inputs','policy','project_sources','python','receiver_id','result_reader','runtime_closure','schema','search_ordering','z3'})
 act=Path(once['actual_directory']);pk('canonical localactualpath '+mode,act==act.resolve()and act.parent==D)
 for name,path in [('actual',act),('actual consumed',act/'CONSUMED.json'),('falseobserver',Path(item['false_once_plan']['path']).parent/(Path(item['false_once_plan']['path']).stem+'-terminal-observation')),('trueonce',D/'plans-v1'/'once-plans'/(once['invocation_id']+'.json')),('trueauthorization',D/'plans-v1'/'authorizations'/(once['invocation_id']+'.json')),('trueobserver',D/'plans-v1'/'once-plans'/(once['invocation_id']+'-terminal-observation'))]:pk('fresh absent '+mode+'/'+name,not path.exists())
 pair.append(dict(mode=mode,subject=sub,subject_sha256=sha,false_once_plan=item['false_once_plan'],worker_plan=item['worker_plan'],integration_declaration=m['case_declaration'],runtime_closure=m['runtime_closure']));rows.append(once);oldworkers.append(wp)
pk('same scientific workerinputs botharms',all(oldworkers[0][k]==oldworkers[1][k]for k in common_fields))
pk('two unique iidactualsubjectSHAs',len({x['subject_sha256']for x in pair})==2 and len({x['invocation_id']for x in rows})==2 and len({x['actual_directory']for x in rows})==2)
pk('inactive metadata exact Source review coverage',len(rc['required_current_subjects'])==30 and rc['source_review_passed']is True and outer['source_review_passed']is True)
assert all(x['passed']for x in pc),[x for x in pc if not x['passed']]
pa=C/'prospective-plan-audit-v1.json';pp=dict(schema='finalization-integration-independent-prospective-audit-v1',source_only=True,scientific_calls=0,module_imports=0,component_calls=0,fixture_calls=0,checks=pc,check_count=len(pc),mismatch_count=0,findings=[],subjects=pair,manifest=ds(D/'false-plan-manifest-v1.json'));assert not pa.exists();pa.write_text(json.dumps(pp,sort_keys=True,indent=2)+'\n')
pr=dict(schema='owned-evidence-integration-prospective-plan-review-v1',author_identity='/root/conventional_library',cohort_owner_identity='/root',reviewer_identity='/root/conventional_control_review',prospective_review_passed=True,source_only=True,scientific_calls=0,module_imports=0,module_evaluations=0,component_calls=0,fixture_calls=0,codec_replays=0,inverse_replays=0,Native_calls=0,Model_calls=0,renderer_calls=0,scientific_acceptance=False,actual_execution_authorized=False,mismatch_count=0,findings=[],check_count=len(pc),static_audit=ds(pa),subjects=pair,required_subjects=[m['case_declaration'],m['runtime_closure']]+[x[k]for x in m['plans']for k in ['worker_plan','false_once_plan']],false_manifest=ds(D/'false-plan-manifest-v1.json'),declaration=m['case_declaration'],closure=m['runtime_closure'],current_components_review=ds(cp),once_Source_review=ds(C/'typed-once-Source-review-v1.json'),current_master=m['current_master'],scope='Separate independent full two prospective18fieldsubjects/worker/declaration/closure and originalcapsule/native/policy/Python/Z3/source/profile/schedule/freshness review. False auth descriptors intentionally nonrunnable; no grants or actuals are accepted by this receipt. SubjectSHAs exclude only authorization. One Control identity fills the disclosed scopes; Root must externally adopt and freeze newmax1auth plus finaldelta.',limitations=rc['limitations'],authorship_disclosure=rc['authorship_disclosure'],tools_stopped_pending_Root_grants_and_finaldelta=True)
rp=C/'typed-prospective-plan-review-v1.json';assert not rp.exists();rp.write_text(json.dumps(pr,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(components=ds(cp),component_checks=len(checks),components_audit=ds(ap),plans=ds(rp),plan_checks=len(pc),plan_audit=ds(pa),subjects=[dict(mode=x['mode'],sha256=x['subject_sha256'])for x in pair],mismatch_count=0),indent=2))
