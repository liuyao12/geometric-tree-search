"""Raw/AST-only production outer observation binding; no research evaluation."""
from pathlib import Path
import ast,difflib,hashlib,json
D=Path('/private/tmp/gcts-finalization-integration-ROOT-20261019')
P=Path('/private/tmp/gcts-cadence-integration-ROOT-20261019')
def pin(p):
 b=p.read_bytes();return dict(path=str(p.resolve()),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(name,raw):
 p=D/name
 if not isinstance(raw,str):raw=json.dumps(raw,sort_keys=True,indent=2,allow_nan=False)+'\n'
 with p.open('x')as f:f.write(raw)
 return pin(p)
old=P/'owned_evidence_once_runner_v2.py';s=old.read_text()
assert pin(old)['sha256']=='b8f11d9a50c05b93f1066ecdcebec46f3d14681ae0e69c25450e8aee09f252ae'
cold=pin(Path('/private/tmp/gcts-finalization-instrumentation-library-20261019/owned_evidence_cold_v6.py'))
assert cold['sha256']=='e1101723f559ae2dfecc030470a3e6e9e79c71b10c416c2bcdfc8f2f5b101d43'
node=next(n for n in ast.parse(s).body if type(n)is ast.Assign and any(type(t)is ast.Name and t.id=='COLD_PIN'for t in n.targets))
lines=s.splitlines(True);before=''.join(lines[node.lineno-1:node.end_lineno]);assert s.count(before)==1
s=s.replace(before,'COLD_PIN = '+repr(cold)+'\n',1)
s=s.replace("VERSION = 'owned-evidence-external-once-runner-v2-cadence'","VERSION = 'owned-evidence-external-once-runner-v3-instrumented'")
anchor="    schedule=declaration['schedule'];ids=[r['invocation_id'] for r in schedule]\n"
intake="""    need(declaration['finalization_profile']==closure['finalization_profile']==
         'owned-finalization-phase-instrumented-v1',
         'explicit current out-of-band observation profile, never proof authority')
"""
assert s.count(anchor)==1;s=s.replace(anchor,intake+anchor,1)
anchor="        need(type(worker_receipt['status'])is str and all(type(worker_receipt[k])is bool for k in ['work_completed','logical_proof_accepted','primary_family_hint_accepted','schema_inventory_admitted']),'literal worker status flags')\n"
joins="""        # Read-only joins of already serialized diagnostics. No component call,
        # repaired timestamp, late statistics snapshot or scientific result root.
        driver_observation=worker_receipt['finalization_observation']
        driver_receipt=worker_receipt['driver_output_receipt']
        need(type(driver_observation)is dict and type(driver_receipt)is dict and
             driver_observation['schema']=='owned-finalization-observation-v1' and
             driver_observation['profile']==declaration['finalization_profile'] and
             all(driver_observation[k]is False for k in
                 ('authority','mathematical_authority','resource_authority')) and
             driver_observation['completed']is True and len(canonical(driver_observation))<=65536 and
             driver_receipt['version']=='semantic-family-owned-evidence-driver-v2-instrumented' and
             canonical(driver_observation)==canonical(driver_receipt['finalization_observation']),
             'bounded complete detached driver observation matches returned receipt')
        cold_observation=worker_receipt['cold_observation']
        need(type(cold_observation)is dict and
             cold_observation['schema']=='owned-cold-phase-observation-v1' and
             cold_observation['profile']==declaration['finalization_profile'] and
             all(cold_observation[k]is False for k in
                 ('authority','mathematical_authority','resource_authority')) and
             'snapshot_cutoff_ns'in cold_observation and
             type(cold_observation['snapshot_scope'])is str and
             len(canonical(cold_observation))<=262144,
             'bounded cold observation with explicit cutoff; no whole-window counter claim')
"""
assert s.count(anchor)==1;s=s.replace(anchor,anchor+joins,1)
dest=D/'owned_evidence_once_runner_v3.py';ast.parse(s);compile(s,str(dest),'exec');save(dest.name,s)
ob=P/'observe_owned_evidence_runner_v2.py';t=ob.read_text()
assert pin(ob)['sha256']=='70cce32675f2d2b0648155cae05dbe7415c25945aeaf3949d65b5fc3e4f5d9d8'
assert t.count(pin(old)['sha256'])==1
t=t.replace('owned-evidence-final-terminal-observer-v2-cadence','owned-evidence-final-terminal-observer-v3-instrumented').replace(pin(old)['sha256'],pin(dest)['sha256'])
out=D/'observe_owned_evidence_runner_v3.py';ast.parse(t);compile(t,str(out),'exec');save(out.name,t)
save('outer-v2-v3.patch',''.join(difflib.unified_diff(old.read_text().splitlines(True),s.splitlines(True),fromfile=str(old),tofile=str(dest))))
save('observer-v2-v3.patch',''.join(difflib.unified_diff(ob.read_text().splitlines(True),t.splitlines(True),fromfile=str(ob),tofile=str(out))))
# Reverse exactly the recognized Source additions and constants into the parent.
restored=s.replace(intake,'',1).replace(joins,'',1).replace('COLD_PIN = '+repr(cold)+'\n',before,1).replace("VERSION = 'owned-evidence-external-once-runner-v3-instrumented'","VERSION = 'owned-evidence-external-once-runner-v2-cadence'")
assert restored==old.read_text()
assert t.replace(pin(dest)['sha256'],pin(old)['sha256']).replace('owned-evidence-final-terminal-observer-v3-instrumented','owned-evidence-final-terminal-observer-v2-cadence')==ob.read_text()
record=dict(schema='ROOT-finalization-integration-outer-Source-contract-v1',author_identity='/root',source_only=True,
 sources=dict(runner=pin(dest),observer=pin(out)),parents=dict(runner=pin(old),observer=pin(ob)),cold=cold,
 changes='Own VERSION/current cold and downstream runner pins; mandatory common declaration/closure finalization_profile; bounded read-only normal driver/cold observation schema/profile/authority/cutoff/receipt equality joins. No scientific calls or other body changes.',
 original_actions_restored_exactly_after_removing_declared_layer=True,unused_compiles=2,component_evaluations=0,scientific_calls=0,
 clock='Original full profile: positive worker work, full saved inverse/result/point/native/header and known exit before180 monotonic seconds; later full outer metadata/resource/custody/group/EOF/terminal before210. Observer225 timeout is failure cleanup only.',
 resource='Original conservative separate Darwin worker+Native highwater1GiB, logical/physical128MiB with8MiB runner+1MiB observer reservations and4MiB captured logs. No live group RSS cap; outer/observer RAM excluded.',
 diagnostic_scope='Normal header requires complete driver observation. Cold diagnostic errors, None clock values and truncation flags remain literal data; no exact per-origin callback census, disjoint phase sum or missing historical telemetry recovery. Failure packets never become positive outputs.',
 trust_scope='Inherited raw/runtime/callable/once/process ownership assumptions remain unchanged; own delta review is not fresh kernel or historical algorithm certification.',
 mathematical_changes=False,actual_execution_authorized=False,scientific_acceptance=False,goal_complete=False,
 pending=['Independent current complete component/outer Source scopes','Exact common full capsule/declaration/falseplan scopes','Root adoption and new max1 grants/final freshness delta','Peer-idle serial bounded actuals and independent saved outcome joins'])
print(json.dumps(save('outer-Source-contract-v1.json',record),sort_keys=True))
print(json.dumps(record['sources'],sort_keys=True))
