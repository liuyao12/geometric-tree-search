"""Ordinary saved-data custody and existing-gate audit; no component or proof replay."""
from pathlib import Path
import hashlib,json
D=Path('/private/tmp/gcts-finalization-integration-ROOT-20261019')
checks=[]
def need(x,name):
 checks.append({'check':name,'passed':bool(x)})
 if not x:raise AssertionError(name)
def load(p):return json.loads(Path(p).read_bytes())
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def checked(x):
 need(pin(x['path'])==x,'whole raw '+x['path']);return load(x['path'])
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
a=load(D/'ROOT-scope-adoption-and-grants-v1.json');rows=[]
for arm in a['plans']:
 p=checked(arm['once_plan']);auth=checked(arm['authorization']);A=Path(p['actual_directory']);op=Path(arm['once_plan']['path']);T=op.parent/(op.stem+'-terminal-observation')/'terminal.json';t=load(T);r=checked(t['runner_receipt']);j=load(A/'result.json');m=p['mode'];prefix=m+': '
 need(r['plan']==t['plan']==arm['once_plan'] and r['authorization']==arm['authorization'],prefix+'exact once bindings')
 need(hashlib.sha256(canonical({k:v for k,v in p.items() if k!='authorization'})).hexdigest()==r['subject_sha256']==auth['subject_sha256']==arm['subject_sha256'],prefix+'exact eighteen-field subject')
 need(auth['maximum_actual_invocations']==1 and auth['actual_execution_authorized'] is True and r['consumed_once'] is True and r['worker_launch_attempts']==1,prefix+'one launch only')
 need(r['python_reaped'] is True and r['owned_group_absent'] is True and r['stdout_eof'] is True and r['stderr_eof'] is True and r['log_capture_complete'] is True,prefix+'known reap group absence EOF')
 need(t['runner_clock_elapsed_seconds']==(t['terminal_observed_ns']-r['began_ns'])/1e9,prefix+'saved same Python clock')
 for key in ('result','evidence_forest','worker_receipt','stdout','stderr'):
  if key in r['outputs']:need(pin(r['outputs'][key]['path'])==r['outputs'][key],prefix+'output '+key)
 w=load(A/('worker-receipt.json'if m=='symbolic'else'worker-failure.json'))
 d=w.get('finalization_observation',w.get('owned_finalization_observation'));dr=w.get('driver_output_receipt',w.get('driver_returned_receipt'));c=w['cold_observation'];native=dr['transport_receipt']
 need(d==dr['finalization_observation'],prefix+'detached driver observation canonical content')
 need(d['schema']=='owned-finalization-observation-v1' and d['profile']=='owned-finalization-phase-instrumented-v1' and d['completed'] is True,prefix+'complete driver ledger')
 need(len(canonical(d))<=65536 and len(d['phases'])==9 and len(d['passive_statistics'])==7,prefix+'driver bounds and expected nine phases seven snapshots')
 need(all(d[k] is False and c[k] is False for k in ('authority','mathematical_authority','resource_authority')),prefix+'observations carry no authority')
 need(all(x['completed'] is True and x['action_returned'] is True and x['error_type'] is None and x['returned_monotonic']>=x['started_monotonic'] for x in d['phases']),prefix+'nine driver actions returned normally')
 need(c['schema']=='owned-cold-phase-observation-v1' and c['profile']==d['profile'] and len(canonical(c))<=262144 and c['diagnostic_errors']==0 and c['truncated'] is False,prefix+'available bounded cold diagnostic')
 need(type(c['snapshot_cutoff_ns'])is int and 'Excludes later' in c['snapshot_scope'],prefix+'explicit cold snapshot cutoff')
 counts=c['counts'];need(counts['source_guard_invocations']==counts['source_guard_completed']==counts['source_guard_timed_intervals'] and counts['source_guard_failed']==0,prefix+'cold-local guard counters joined')
 need(native['closed'] is True and native['all_reaped'] is True and native['native_exit_code']==0 and native['cleanup_errors']==[] and native['stdout_eof'] is True and native['stderr_complete'] is True,prefix+'Native reaped and closed')
 need(native['complete_records']==len(j['records'])==16 and native['request_stages'][-1]['purpose']=='fresh_quantified_receiver_final',prefix+'complete current Native record ledger')
 need(j['native_proof_accepted'] is True and j['status']=='native_proof_discovered' and j['work_window_complete'] is True,prefix+'local full scientific result retained')
 need(j['model_identity_sha256']==j['model_after_identity_sha256'] and j['declaration']['id']==p['receiver_id'] and j['declaration']['length']==12 and j['declaration']['instantiation_rounds']==2,prefix+'same complete model and original twelve-row capsule')
 need(j['declaration']['theory']['schemas']==[] and j['declaration']['target']==['pred','P',[['fun','b',[]]]],prefix+'unchanged closed target and no open schema')
 st=c['inverse_statistics'];need(st['phase']=='DOCUMENT_COMPLETE' and st['prepared'] is True and st['pending_callback_operations']==0 and st['maximum_callback_operation_gap']<=1024,prefix+'saved inverse completed with bounded cadence')
 need(st['attempted_operations']==sum(st['operations_by_kind'].values())<=30000000 and st['callback_dispatches']==sum(st['callback_dispatches_by_reason'].values()) and st['last_callback_operation']==st['attempted_operations'],prefix+'inverse operation and callback totals')
 row=dict(mode=m,once_plan=arm['once_plan'],authorization=arm['authorization'],terminal=pin(T),runner_receipt=pin(A/'runner-receipt.json'),worker_record=pin(A/('worker-receipt.json'if m=='symbolic'else'worker-failure.json')),result=pin(A/'result.json'),evidence_forest=pin(A/'evidence-forest.json'),external_terminal_seconds=t['runner_clock_elapsed_seconds'],worker_exit=r['python_exit_code'],outer_exit=t['runner_exit_code'],terminal_gate_passed=t['terminal_gate_passed'],all_lifecycle_closed=True,local_native_proof_discovered=True,driver_observation=d,cold_observation=c,inverse_statistics=st,ROOT_resource_accepted=False,ROOT_mathematical_proof_admitted=False,scientific_acceptance=False,aggregate_peak_bytes=r['conservative_parent_plus_native_peak_bytes'],diagnostic_separate_highwater_sum_bytes=r['python_wait4_usage']['ru_maxrss']+native['native_high_water_bytes'],worker_highwater_bytes=r['python_wait4_usage']['ru_maxrss'],native_highwater_bytes=native['native_high_water_bytes'],scientific_stop_seconds=j['scientific_stopped_monotonic']-r['began_ns']/1e9,oracle_closed_seconds=j['oracle_closed_monotonic']-r['began_ns']/1e9,driver_phases=[dict(phase=x['phase'],started_seconds=x['started_monotonic']-r['began_ns']/1e9,returned_seconds=x['returned_monotonic']-r['began_ns']/1e9,duration_seconds=x['returned_monotonic']-x['started_monotonic'])for x in d['phases']],cold_phases=[dict(phase=x['phase'],state=x['state'],started_seconds=(x['started_ns']-r['began_ns'])/1e9,returned_seconds=(x['returned_ns']-r['began_ns'])/1e9 if x['returned_ns']is not None else None,duration_seconds=(x['returned_ns']-x['started_ns'])/1e9 if x['returned_ns']is not None else None)for x in c['phases']])
 if m=='fixed':
  need(t['runner_exit_code']==2 and r['python_exit_code']==1 and t['terminal_gate_passed'] is False and r['resource_candidate_accepted'] is False and r['worker_receipt'] is None and r['conservative_parent_plus_native_peak_bytes'] is None,prefix+'failed complete gate remains unadmitted and accepted aggregate unavailable')
  need(w['message']=='positive full result reading within original work' and w['error_type']=='ColdError' and w['logical_proof_accepted'] is False and w['resource_accepted'] is False and w['cleanup_errors']==[],prefix+'exact retained original failure')
  need(c['phases'][-1]['phase']=='old_canonical_roundtrip' and c['phases'][-1]['state']=='OPEN_AT_FAILURE' and c['phases'][-1]['returned_ns'] is None,prefix+'unfinished canonical roundtrip not invented complete')
  row.update(failure_message=w['message'],failure_type=w['error_type'],failure_phase='old_canonical_roundtrip',old_result_reading_unavailable=True,whole_point_verification_unavailable=True,physical_admission_ledger_unavailable=True)
 else:
  need(t['runner_exit_code']==0 and r['python_exit_code']==0 and t['terminal_gate_passed'] is True and r['resource_candidate_accepted'] is True and r['errors']==[],prefix+'all positive outer gates')
  need(r['worker_terminal_observed_ns']<r['work_deadline_ns'] and t['terminal_observed_ns']<r['overall_deadline_ns'],prefix+'worker known exit180 later outer terminal210')
  need(w==r['worker_receipt'] and w['logical_proof_accepted'] is True and r['logical_proof_transport_candidate'] is True and w['work_completed'] is True,prefix+'exact positive worker header')
  need(w['evidence_verification']['status']=='COMPLETE' and w['evidence_verification']['mathematical_authority'] is False and w['evidence_verification']['statistics']==st and w['evidence_verification']['completed_ns']<r['work_deadline_ns'],prefix+'separate complete independent saved inverse')
  need(w['result_reading']['roundtrip']['literal_bytes_equal'] is True and w['result_reading']['completed_ns']<r['work_deadline_ns'],prefix+'old full canonical result reader completed')
  need(w['final_region_verification']['status']=='VERIFIED_WHOLE_FINITE_POINT_REGION' and w['final_region_verification']['decoded_rows']==12 and w['final_region_verification']['selected_placements']==w['final_region_verification']['required_points']==60,prefix+'whole finite point region and twelve rows')
  need(w['adapter_diagnostics']['status']=='COMPLETE' and len(w['adapter_diagnostics']['groups'])==5 and w['schema_inventory_admitted'] is True and w['receiver_input_qualified'] is True,prefix+'old boundary/schema/input gates')
  need(r['conservative_parent_plus_native_peak_bytes']==row['diagnostic_separate_highwater_sum_bytes']<=1073741824,prefix+'separate highwater sum within1GiB')
  need(r['outputs']['physical_output_budget']['conservative_physical_bytes']<=134217728 and r['outputs']['physical_output_budget']['logical_bytes']==row['result']['bytes'],prefix+'complete logical physical128MiB')
  row.update(ROOT_resource_accepted=True,ROOT_mathematical_proof_admitted=True,resource_admission_scope='Separate measured Darwin worker+Native highwater sum only; not simultaneousRSS. Outer/observer RAM excluded.',physical_ledger=r['outputs']['physical_output_budget'],evidence_verification=w['evidence_verification'],result_reading=w['result_reading'],final_region_verification=w['final_region_verification'])
 rows.append(row)
need(rows[0]['external_terminal_seconds']>0 and load(rows[0]['terminal']['path'])['terminal_observed_ns']<load(rows[1]['runner_receipt']['path'])['began_ns'],'serial fixed closed before symbolic Source entry; same pinned Python clock')
v=dict(schema='ROOT-finalization-integration-saved-actual-audit-v1',author_identity='/root',saved_data_only=True,scientific_calls=0,component_imports=0,mathematical_replay=False,scope='Raw saved ordinary receipts and existing Native/whole-point/inverse/logical/resource evidence, under adopted current and inherited Source/trust scopes. No fresh independent kernel theorem.',checks=checks,check_count=len(checks),mismatch_count=0,arms=rows,new_RL_training=False,GCTS_RL_advantage_established=False,causal_speed_claim=False,goal_complete=False,observation_limits='Nested inclusive intervals/guardtimes overlap and are not additive. Cold counts and snapshot are local and cutoff-scoped; old decode_seconds includes inverse. Instrumentation has charged overhead; no same-input causal timing claim follows.',historical_outcomes_unchanged=True)
p=D/'ROOT-saved-actual-audit-v1.json';need(not p.exists(),'fresh audit output');v['check_count']=len(checks);p.write_text(json.dumps(v,sort_keys=True,indent=2,allow_nan=False)+'\n');print(json.dumps(pin(p)));print(json.dumps([{k:r[k]for k in ('mode','external_terminal_seconds','ROOT_resource_accepted','ROOT_mathematical_proof_admitted','aggregate_peak_bytes','diagnostic_separate_highwater_sum_bytes')}for r in rows],indent=2))
