"""Raw/AST/ordinary-JSON builder only; never loads a scientific component.

CLI: PINNED_PYTHON build_false_plans_v1.py ROOT_DIRECTORY RUNNER_SOURCE OBSERVER_SOURCE
It writes new inactive metadata only, never actual/terminal directories or grants.
Parent Sources, plans, results and publisher files remain untouched.
"""
import ast
import hashlib
import json
from pathlib import Path
import sys

VERSION = 'finalization-full-integration-metadata-builder-v1'
AUTHOR = '/root/conventional_library'
ROOT = '/private/tmp/gcts-finalization-integration-ROOT-20261019'
PARENT = '/private/tmp/gcts-cadence-integration-ROOT-20261019'
LIBRARY = '/private/tmp/gcts-finalization-instrumentation-library-20261019'
FINALIZATION_PROFILE = 'owned-finalization-phase-instrumented-v1'
MASTER = {'path': PARENT + '/basic-tiling-algorithm-HEAD.md', 'bytes': 36240,
          'sha256': 'ca6ee206287bf18b69f88a35d30968312499567755f347a819af4cf49743e7d4'}
COLD = {'path': LIBRARY + '/owned_evidence_cold_v6.py', 'bytes': 72712,
        'sha256': 'e1101723f559ae2dfecc030470a3e6e9e79c71b10c416c2bcdfc8f2f5b101d43'}
DRIVER = {'path': '/private/tmp/gcts-finalization-instrumentation-ROOT-20261019/owned_evidence_receiver_driver_v6.py',
          'bytes': 120766, 'sha256': 'e8ff0690472140e510f8ffab383be8c22791da6b27ef0a27fda013ea48e5f5cf'}
RUNNER = {'path': ROOT + '/owned_evidence_once_runner_v3.py', 'bytes': 43452,
          'sha256': '1099886bf7dbf7d4a0321843a3da306f373d321d77a156d6d8d94160626484f0'}
OBSERVER = {'path': ROOT + '/observe_owned_evidence_runner_v3.py', 'bytes': 5609,
            'sha256': 'efe2b571d5c7cffc6a9986d53837f01b5ce8d709ce658b093194ef92ed01fd22'}
RECEIVER_ID = 'prospective-fol-20261018-001'
FALSE_AUTHORIZATION = {'path': 'NO_AUTHORIZATION_FALSE_PLAN', 'bytes': 0,
                       'sha256': 'NO_AUTHORIZATION'}
RUNNER_LIMITS = {'work_seconds': 180, 'overall_seconds': 210,
    'aggregate_peak_bytes': 1073741824, 'stdout_bytes': 4194304,
    'stderr_bytes': 4194304, 'result_bytes': 134217728,
    'worker_receipt_bytes': 4194304, 'runner_plan_bytes': 16777216,
    'failure_cleanup_seconds': 5, 'poll_milliseconds': 20}
PREREQUISITES = {
    'driver_Source': '/private/tmp/gcts-finalization-instrumentation-peer-20261019/typed-driver-Source-review-v2.json',
    'cold_Source': '/private/tmp/gcts-finalization-instrumentation-peer-20261019/typed-cold-Source-review-v1.json',
    'helper_components_Source': '/private/tmp/gcts-finalization-instrumentation-peer-20261019/typed-components-Source-review-v3.json',
    'helper_saved_admission': '/private/tmp/gcts-finalization-instrumentation-ROOT-20261019/ROOT-saved-actual-audit-v1.json',
    'inverse_qualification': '/private/tmp/gcts-inverse-cadence-ROOT-20261019/ROOT-final-milestone-v1.json',
    'integration_design': LIBRARY + '/next-full-pipeline-integration-design-v1.json',
    'cold_handoff': LIBRARY + '/handoff-v1.json',
    'helper_handoff': LIBRARY + '/qualification-handoff-v2.json',
}


def need(ok, message):
    if not ok:
        raise ValueError(message)


def canonical(value):
    return json.dumps(value, sort_keys=True, indent=2, ensure_ascii=True,
                      allow_nan=False).encode('utf8') + b'\n'


def descriptor(path, raw):
    return dict(path=str(Path(path).resolve()), bytes=len(raw),
                sha256=hashlib.sha256(raw).hexdigest())


def raw_pin(path):
    path = Path(path)
    need(path.is_absolute() and path == path.resolve() and path.is_file() and not path.is_symlink(),
         'owned canonical regular raw input: ' + str(path))
    return descriptor(path, path.read_bytes())


def checked(pin):
    need(type(pin) is dict and set(pin) == {'path', 'bytes', 'sha256'} and
         type(pin['bytes']) is int and pin['bytes'] >= 0, 'exact raw descriptor')
    actual = raw_pin(pin['path'])
    need(actual == pin, 'whole raw size/hash changed: ' + pin['path'])
    return Path(pin['path']).read_bytes()


def load(path):
    return json.loads(Path(path).read_bytes())


def literal_assignments(path):
    tree = ast.parse(Path(path).read_bytes(), filename=str(path))
    output = {}
    for node in tree.body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            try:
                output[node.targets[0].id] = ast.literal_eval(node.value)
            except (ValueError, TypeError):
                pass
    return output


def make_census(modules, stdlib_roots, external_roots):
    records, internal_edges, stdlib, external, unresolved, relative = [], [], set(), set(), [], []
    all_names = set(modules)

    def classification(module, level=0):
        if level:
            return 'relative_unresolved'
        root = module.split('.')[0] if module else ''
        if root in all_names:
            return 'owned_internal'
        if root in external_roots:
            external.add(root)
            return 'inherited_external'
        if root in stdlib_roots:
            stdlib.add(root)
            return 'declared_Python_stdlib_or_builtin'
        unresolved.append(dict(module=module, level=level))
        return 'unclassified_root'

    for alias, source in modules.items():
        raw = checked(source)
        tree = ast.parse(raw, filename=source['path'])
        imports, dynamic = [], []
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for item in node.names:
                    kind = classification(item.name)
                    row = dict(kind='import', module=item.name, asname=item.asname,
                               line=node.lineno, column=node.col_offset, classification=kind)
                    imports.append(row)
                    if kind == 'owned_internal':
                        internal_edges.append(dict(source=alias, target=item.name.split('.')[0], line=node.lineno))
            elif isinstance(node, ast.ImportFrom):
                kind = classification(node.module, node.level)
                row = dict(kind='from', module=node.module, level=node.level,
                    names=[dict(name=item.name, asname=item.asname) for item in node.names],
                    line=node.lineno, column=node.col_offset, classification=kind)
                imports.append(row)
                if kind == 'owned_internal':
                    internal_edges.append(dict(source=alias, target=node.module.split('.')[0], line=node.lineno))
                if node.level:
                    relative.append(dict(source=alias, **row))
            elif isinstance(node, ast.Call) and (
                (isinstance(node.func, ast.Name) and node.func.id == '__import__') or
                (isinstance(node.func, ast.Attribute) and node.func.attr == 'import_module')):
                literal = node.args[0].value if node.args and isinstance(node.args[0], ast.Constant) and type(node.args[0].value) is str else None
                row = dict(line=node.lineno, column=node.col_offset,
                    callable_AST=ast.dump(node.func, include_attributes=False), literal_module=literal,
                    argument_AST=ast.dump(node.args[0], include_attributes=False) if node.args else None,
                    classification=classification(literal) if literal is not None else 'nonliteral_dynamic_site')
                if literal is None:
                    row['scope'] = ('Cold imports fixed alias/schema maps at runtime under current Source guards; this raw AST site is retained, not evaluated or proved by census.'
                                    if alias == '__cold__' else 'Unresolved literal target; retained for independent review.')
                dynamic.append(row)
        records.append(dict(alias=alias, source=source,
            AST_sha256=hashlib.sha256(ast.dump(tree, include_attributes=True).encode('utf8')).hexdigest(),
            imports=imports, dynamic_import_sites=dynamic))
    return records, dict(schema='owned-current-raw-import-census-summary-v1',
        sources=len(records), static_import_sites=sum(len(x['imports']) for x in records),
        dynamic_import_sites=sum(len(x['dynamic_import_sites']) for x in records),
        nonliteral_dynamic_sites=[dict(alias=x['alias'], **site) for x in records
            for site in x['dynamic_import_sites'] if site['literal_module'] is None],
        internal_edges=internal_edges, stdlib_roots=sorted(stdlib), inherited_external_roots=sorted(external),
        unclassified_roots=unresolved, relative_import_sites=relative,
        scope='Exact raw/AST census only; nonliteral imports are not executed. Python/bundled stdlib/OS loader assumptions remain inherited; no whole loader proof or activation.')


def main(argv):
    need(len(argv) == 3, 'ROOT_DIRECTORY RUNNER_SOURCE OBSERVER_SOURCE')
    root = Path(argv[0])
    need(str(root) == ROOT and root == root.resolve() and root.is_dir(), 'exact fresh Root metadata directory')
    need(raw_pin(argv[1]) == RUNNER and raw_pin(argv[2]) == OBSERVER, 'current Root outer Source arguments')
    parent = Path(PARENT)
    oldclosure = load(parent / 'runtime-closure-v1.json')
    base = load(parent / 'case-declaration-v1.json')
    oldworker_path = parent / 'plans-v1/worker-plans/cadence-integration-001-fixed-ROOT-20261019-v1.json'
    oldworker = load(oldworker_path)
    oldonce = load(parent / 'plans-v1/once-plans/cadence-integration-001-fixed-ROOT-20261019-v1.json')
    checked(MASTER);checked(COLD);checked(DRIVER);checked(RUNNER);checked(OBSERVER)
    need(raw_pin(Path(sys.executable).resolve()) == oldworker['python'] and sys.version_info[:2] == (3, 12),
         'ordinary metadata authoring uses the declared pinned3.12 runtime')
    need(hasattr(sys, 'stdlib_module_names'), 'pinned stdlib root catalogue')
    need(base['evidence_profile'] == oldclosure['evidence_profile'] ==
         load('/private/tmp/gcts-cadence-integration-library-20261019/EVIDENCE_PROFILE-v4.json'),
         'unchanged full evidence profile')
    old_fields = set(oldworker)
    profile = base['evidence_profile']
    project = dict(oldworker['project_sources'])
    components = dict(oldworker['components'])
    components['receiver_driver'] = DRIVER
    evidence = oldclosure['evidence_sources']
    schema_sources = oldclosure['schema_sources']
    names = dict(project, semantic_receiver_driver=DRIVER,
                 bounded_request_oracle=components['bounded_transport'],
                 owned_evidence_adapter=evidence['adapter'], exact_evidence_arena=evidence['arena'],
                 owned_inventory_join=evidence['join'], independent_forest_inverse=evidence['inverse'])
    need(len(project) == 22 and len(components) == 2 and len(evidence) == 4 and len(names) == 28
         and len(schema_sources) == 1, 'same22+2+4 then separate schema1')
    need({k: v for k, v in names.items() if k != 'semantic_receiver_driver'} ==
         {k: v for k, v in oldclosure['materialized_aliases'].items() if k != 'semantic_receiver_driver'},
         'all27 other materialized aliases exact parent')
    literal_cold = literal_assignments(COLD['path'])
    literal_driver = literal_assignments(DRIVER['path'])
    literal_runner = literal_assignments(RUNNER['path'])
    need(literal_cold['FINALIZATION_PROFILE'] == FINALIZATION_PROFILE and
         literal_cold['RECEIVER_DRIVER_SOURCE'] == DRIVER and literal_runner['COLD_PIN'] == COLD,
         'exact current literal Source bindings')
    need(literal_driver['OWNED_VERSION'] == 'semantic-family-owned-evidence-driver-v2-instrumented',
         'explicit current owned driver version')
    observer_tree = ast.parse(checked(OBSERVER), filename=OBSERVER['path'])
    observer_runner_subject = ast.dump(ast.parse("plan['runner']['sha256']", mode='eval').body,
                                       include_attributes=False)
    need(any(isinstance(node, ast.Compare) and len(node.ops) == 1 and isinstance(node.ops[0], ast.Eq)
             and ast.dump(node.left, include_attributes=False) == observer_runner_subject
             and len(node.comparators) == 1 and isinstance(node.comparators[0], ast.Constant)
             and node.comparators[0].value == RUNNER['sha256'] for node in ast.walk(observer_tree)),
         'observer exact literal runner SHA binding (not an invented RUNNER_PIN constant)')
    prerequisites = {k: raw_pin(v) for k, v in PREREQUISITES.items()}
    helper = load(PREREQUISITES['helper_saved_admission'])
    need(helper['finite_helper_qualification_adopted'] is True and helper['full_pipeline_qualified'] is False
         and helper['scientific_acceptance'] is False and helper['scientific_calls'] == 0,
         'finite helper-only prerequisite; no production fit inherited')
    # Raw hashes only: fixed native gzip is never decoded and no scientific JSON
    # is interpreted. The complete selected assertion capsule is ordinary input.
    checked(oldworker['python']);checked(oldworker['policy']);checked(oldworker['declaration'])
    for value in oldworker['native_inputs'].values():
        checked(value)
    for value in oldworker['z3']['files']:
        checked(value)
    checked(oldworker['z3']['library']);checked(oldclosure['schema_kernel_source'])
    for entry in oldclosure['stdlib_entry_references'].values():
        if 'pin' in entry:
            checked(entry['pin'])
        for value in entry.get('pins', []):
            checked(value)
    census, summary = make_census(dict(names, **schema_sources, __cold__=COLD),
        set(sys.stdlib_module_names) | set(sys.builtin_module_names), set(oldclosure['external_imports']))
    need(not summary['unclassified_roots'] and not summary['relative_import_sites'],
         'no silently guessed import roots/relative imports')
    pending = []

    def stage(path, value):
        raw = canonical(value)
        pending.append((Path(path), raw))
        return descriptor(path, raw)

    closure = dict(oldclosure)
    closure.update(author_identity=AUTHOR, cohort_owner_identity='/root', source_only=True,
        scientific_calls=0, actual_execution_authorized=False, scientific_acceptance=False,
        previous_instrumentation_parent_closure=raw_pin(parent / 'runtime-closure-v1.json'),
        project_sources=project, additional_nonseed_components=components,
        materialized_aliases=names, cold=COLD, finalization_profile=FINALIZATION_PROFILE,
        current_master=MASTER, current_scientific_alias_count=28, schema_extra_component_count=1,
        Source_AST_census=census, current_import_census_summary=summary,
        prerequisite_finalization_components={k: prerequisites[k] for k in ('driver_Source', 'cold_Source')},
        prerequisite_helper_qualification=dict(admission=prerequisites['helper_saved_admission'],
            Source=prerequisites['helper_components_Source'], full_pipeline_qualified=False,
            scope='Finite fake-interface metadata helpers only; no current production run or real pipeline cost/fit qualification.'),
        next_integration_design=prerequisites['integration_design'],
        inherited_role_bindings_scope='Historical parent provenance only; never current once permission or a replayable Source grant.',
        review_scope='Current instrumented coldV6/driverV6 raw bindings and same full28+schema1 closure. Distinct current review scopes required; author also wrote cold/helper/Model/bridge/point/certifier ancestors and does not independently certify them.',
        limitations=list(oldclosure['limitations']) + [
            'Only out-of-band instrumentation changes current driver/cold; every old scientific/evidence Source remains exact.',
            'Helper pass cannot establish full pipeline retention, actual cost, performance, fit or mathematical authority. All observation costs count in unchanged caps.',
            'AST census retains nonliteral cold import sites explicitly; current callable/origin seals remain runtime obligations.'])
    closure_pin = stage(root / 'runtime-closure-v1.json', closure)
    capsule = load(oldworker['declaration']['path'])
    matches = [r for r in capsule['receivers'] if r['id'] == RECEIVER_ID]
    need(len(matches) == 1 and matches[0] == base['selected_receiver'], 'exact original001 complete input selection')
    selected = matches[0]
    need(selected['length'] == 12 and selected['instantiation_rounds'] == 2, 'original row/round profile')
    schedule = [dict(order=index + 1,
        invocation_id='finalization-integration-001-' + mode + '-ROOT-20261019-v1',
        mode=mode, search_ordering='and_support', inventory_certification_mode='schema_then_native',
        model_storage='literal_interned', result_reader='interned', receiver_id=RECEIVER_ID,
        actual_directory=str(root / ('actual-' + mode + '-v1')))
        for index, mode in enumerate(('fixed', 'symbolic'))]
    planroot = root / 'plans-v1'
    for row in schedule:
        actual = Path(row['actual_directory'])
        invocation = row['invocation_id']
        need(not actual.exists() and not actual.is_symlink(), 'fresh absent actual directory')
        for folder in ('once-plans', 'false-once-plans'):
            terminal = planroot / folder / (invocation + '-terminal-observation')
            need(not terminal.exists() and not terminal.is_symlink(), 'fresh absent terminal directory')
    declaration = dict(base)
    declaration.update(author_identity=AUTHOR, cohort_owner_identity='/root', source_only=True,
        scientific_calls=0, actual_execution_authorized=False, goal_complete=False,
        parent_instrumentation_declaration=raw_pin(parent / 'case-declaration-v1.json'),
        runtime_closure=closure_pin, schedule=schedule, selected_receiver_id=RECEIVER_ID,
        selected_receiver=selected, finalization_profile=FINALIZATION_PROFILE, current_master=MASTER,
        current_sources=dict(cold=COLD, driver=DRIVER, runner=RUNNER, observer=OBSERVER),
        prerequisite_finalization_components=closure['prerequisite_finalization_components'],
        prerequisite_helper_qualification=closure['prerequisite_helper_qualification'],
        next_integration_design=prerequisites['integration_design'],
        changed_profile='Out-of-band finalization observation only, current driver/cold/outer Source identities and fresh subjects. No candidate/marking/grammar/library/inventory/Native/Model/search/cap change, no causal performance claim.',
        observation_scope='Driver seconds and cold nanoseconds are labeled. Nested phases and guard intervals overlap. Counts are cold-local through detached snapshot_cutoff_ns and exclude later guards/receipt writing/cleanup/worker exit; no Arena/adapter dispatch categories inferred. Old decode_seconds includes whole inverse interval.',
        failure_policy='Keep all original errors/UNKNOWN/output/resource failures and available bounded observation prefix. No failed Native candidate or completed driver packet becomes admitted proof, no rewritten forest/result, cap rise or retry.',
        scope='Fresh familiar original001 fixed/symbolic full-pipeline phase measurement only. Helper-only prerequisite does not qualify production retention or real cost. One deterministic pair, no ordinary-storage arm, new theorem, RL training, causal acceleration or general fit claim.')
    declaration_pin = stage(root / 'case-declaration-v1.json', declaration)
    manifest = []
    for row in schedule:
        worker = dict(oldworker)
        worker.update({k: v for k, v in row.items() if k != 'order'})
        worker.update(cold=COLD, project_sources=project, components=components,
                      runtime_closure=closure_pin, integration_declaration=declaration_pin)
        need(set(worker) == old_fields, 'worker exact old fields')
        worker_pin = stage(planroot / 'worker-plans' / (row['invocation_id'] + '.json'), worker)
        once = dict(schema='ROOT-owned-evidence-integration-once-plan-v1',
            **{k: v for k, v in row.items() if k != 'order'}, runner=RUNNER, observer=OBSERVER,
            python=oldworker['python'], cold=COLD, worker_plan=worker_pin,
            integration_declaration=declaration_pin, runtime_closure=closure_pin,
            authorization=dict(FALSE_AUTHORIZATION), limits=dict(RUNNER_LIMITS),
            environment={'PYTHONHASHSEED': '0', 'LC_ALL': 'C', 'LANG': 'C'})
        need(set(once) == set(oldonce), 'once exact old fields')
        once_pin = stage(planroot / 'false-once-plans' / (row['invocation_id'] + '.json'), once)
        manifest.append(dict(row=row, worker_plan=worker_pin, false_once_plan=once_pin))
    manifest_pin = stage(root / 'false-plan-manifest-v1.json', dict(
        schema='ROOT-owned-evidence-false-plan-manifest-v1', author_identity=AUTHOR,
        cohort_owner_identity='/root', source_only=True, scientific_calls=0,
        actual_execution_authorized=False, cold=COLD, runner=RUNNER, observer=OBSERVER,
        case_declaration=declaration_pin, runtime_closure=closure_pin,
        finalization_profile=FINALIZATION_PROFILE, current_master=MASTER, plans=manifest,
        metadata_builder=raw_pin(Path(__file__).resolve()),
        pending='All false plans deliberately unlaunchable. Current independent Sources/full subjects, fresh true grants/finaldelta and all peers idle still required.'))
    # Complete all fallible metadata preparation and absence checks first. Each
    # output is exclusive; an unexpected writer fault leaves metadata only, never
    # an actual/grant or an assertion of complete successful preparation.
    need(not planroot.exists(), 'new plans-v1 namespace only')
    for path, raw in pending:
        need(not path.exists() and not path.is_symlink(), 'new metadata path only: ' + str(path))
    for path, raw in pending:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open('xb') as stream:
            stream.write(raw)
        need(raw_pin(path) == descriptor(path, raw), 'whole emitted metadata bytes')
    print(json.dumps(dict(schema='finalization-integration-metadata-build-result-v1',
        source_only=True, scientific_calls=0, actual_execution_authorized=False,
        manifest=manifest_pin, closure=closure_pin, declaration=declaration_pin,
        files=len(pending), alias_count=28, schema_extra_count=1,
        census_sources=len(census), static_import_sites=summary['static_import_sites'],
        dynamic_import_sites=summary['dynamic_import_sites'])))


if __name__ == '__main__':
    main(sys.argv[1:])
