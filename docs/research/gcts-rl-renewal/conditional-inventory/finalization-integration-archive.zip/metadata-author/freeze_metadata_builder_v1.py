"""Author raw/AST/ordinary-output audit only; no scientific code is loaded."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile

L = Path('/private/tmp/gcts-finalization-integration-library-20261019')
D = Path('/private/tmp/gcts-finalization-integration-ROOT-20261019')
P = Path('/private/tmp/gcts-cadence-integration-ROOT-20261019')
B = L / 'build_false_plans_v1.py'


def pin(path):
    path = Path(path).resolve()
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def read(path):
    return json.loads(Path(path).read_bytes())


def save(name, value):
    path = L / name
    if path.exists():
        raise ValueError('frozen metadata already exists: ' + name)
    path.write_text(json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False,
                               allow_nan=False) + '\n')
    return pin(path)


checks = []


def check(name, ok):
    checks.append(dict(name=name, passed=bool(ok)))
    if not ok:
        raise ValueError(name)


raw = B.read_bytes()
tree = ast.parse(raw, filename=str(B))
constants = {}


def literal(node):
    if isinstance(node, ast.Constant):
        return node.value
    if isinstance(node, ast.Name) and node.id in constants:
        return constants[node.id]
    if isinstance(node, ast.Dict):
        return {literal(k): literal(v) for k, v in zip(node.keys, node.values)}
    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
        left, right = literal(node.left), literal(node.right)
        if type(left) is str and type(right) is str:
            return left + right
    raise ValueError('not a literal metadata constant')


for node in tree.body:
    if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
        constants[node.targets[0].id] = literal(node.value)
check('builder Source exact pre-execution reviewed pin',
      pin(B)['sha256'] == 'e6923ffe8627d96018f64d1c37113828a1c52f8e6422fd3c30b068508fbfcdf2')
check('stdlib-only imports', sorted(
    [a.name for n in tree.body if isinstance(n, ast.Import) for a in n.names] +
    [n.module for n in tree.body if isinstance(n, ast.ImportFrom)]) ==
    ['ast', 'hashlib', 'json', 'pathlib', 'sys'])
for name in ('eval', 'exec', '__import__', 'compile_guards', 'run_receiver_owned',
             'prepare_forest', 'iter_document', 'search', 'write_micro', 'Popen', 'decompress'):
    check('no forbidden call: ' + name, not any(isinstance(n, ast.Call) and
        ((isinstance(n.func, ast.Name) and n.func.id == name) or
         (isinstance(n.func, ast.Attribute) and n.func.attr == name)) for n in ast.walk(tree)))
check('explicit same profile string', constants['FINALIZATION_PROFILE'] == 'owned-finalization-phase-instrumented-v1')
compile(raw, str(B), 'exec')
unused_compiles = 1
changed = raw.decode().replace('Raw/AST/ordinary-JSON builder only;',
                               'Raw/AST/ordinary-JSON builder only (inert marker);', 1)
forward = ''.join(difflib.unified_diff(raw.decode().splitlines(True), changed.splitlines(True),
    fromfile='a/builder.py', tofile='b/builder.py'))
reverse = ''.join(difflib.unified_diff(changed.splitlines(True), raw.decode().splitlines(True),
    fromfile='a/builder.py', tofile='b/builder.py'))
(L / 'builder-inert-forward.patch').write_text(forward)
(L / 'builder-inert-reverse.patch').write_text(reverse)
with tempfile.TemporaryDirectory(prefix='finalization-builder-inert-', dir='/private/tmp') as tmp:
    target = Path(tmp) / 'builder.py'
    target.write_bytes(raw)
    subprocess.run(['patch', '-p1', '--batch'], input=forward.encode(), cwd=tmp,
                   capture_output=True, check=True)
    check('actual inert forward bytes', target.read_text() == changed)
    compile(target.read_bytes(), str(target), 'exec');unused_compiles += 1
    subprocess.run(['patch', '-p1', '--batch'], input=reverse.encode(), cwd=tmp,
                   capture_output=True, check=True)
    check('actual inert inverse whole Source bytes', target.read_bytes() == raw)
    compile(target.read_bytes(), str(target), 'exec');unused_compiles += 1
check('all executable AST exact under inert docstring marker',
      ast.dump(ast.Module(body=tree.body[1:], type_ignores=[]), include_attributes=False) ==
      ast.dump(ast.Module(body=ast.parse(changed).body[1:], type_ignores=[]), include_attributes=False))

manifest = read(D / 'false-plan-manifest-v1.json')
closure = read(D / 'runtime-closure-v1.json')
declaration = read(D / 'case-declaration-v1.json')
oldclosure = read(P / 'runtime-closure-v1.json')
olddeclaration = read(P / 'case-declaration-v1.json')
oldworker = read(P / 'plans-v1/worker-plans/cadence-integration-001-fixed-ROOT-20261019-v1.json')
oldonce = read(P / 'plans-v1/once-plans/cadence-integration-001-fixed-ROOT-20261019-v1.json')
check('all metadata honestly authored Library', all(v['author_identity'] == '/root/conventional_library'
      and v['cohort_owner_identity'] == '/root' for v in (manifest, closure, declaration)))
check('all false/source-only metadata', all(v['source_only'] is True and
      v['actual_execution_authorized'] is False and v['scientific_calls'] == 0
      for v in (manifest, closure, declaration)))
check('declaration+closure mandatory finalization_profile',
      closure['finalization_profile'] == declaration['finalization_profile'] == constants['FINALIZATION_PROFILE'])
check('manifest whole closure/declaration descriptors', manifest['runtime_closure'] == pin(D / 'runtime-closure-v1.json')
      and manifest['case_declaration'] == pin(D / 'case-declaration-v1.json'))
check('full28alias+separate schema1', len(closure['materialized_aliases']) == 28 and
      len(closure['project_sources']) == 22 and len(closure['additional_nonseed_components']) == 2 and
      len(closure['evidence_sources']) == 4 and len(closure['schema_sources']) == 1)
check('all project Sources exact unchanged', closure['project_sources'] == oldclosure['project_sources'])
check('all four evidence Sources exact unchanged', closure['evidence_sources'] == oldclosure['evidence_sources'])
check('schema and kernel exact unchanged', closure['schema_sources'] == oldclosure['schema_sources'] and
      closure['schema_kernel_source'] == oldclosure['schema_kernel_source'])
check('sole alias difference exact driverV6',
      {k: v for k, v in closure['materialized_aliases'].items() if k != 'semantic_receiver_driver'} ==
      {k: v for k, v in oldclosure['materialized_aliases'].items() if k != 'semantic_receiver_driver'} and
      closure['materialized_aliases']['semantic_receiver_driver'] == constants['DRIVER'])
for name in ('Z3', 'Z3_imports', 'external_imports', 'fixed_native_inputs', 'native_CPP',
             'runtime', 'stdlib_entry_references', 'parent_closure'):
    check('unchanged full parent map: ' + name, closure[name] == oldclosure[name])
check('unchanged complete evidence profile', closure['evidence_profile'] == declaration['evidence_profile'] ==
      olddeclaration['evidence_profile'])
check('same full input and declaration limits', declaration['selected_receiver'] == olddeclaration['selected_receiver']
      and declaration['parent_structural_declaration'] == olddeclaration['parent_structural_declaration']
      and declaration['limits'] == olddeclaration['limits'])
check('current master exact pin', closure['current_master'] == declaration['current_master'] == constants['MASTER'])
check('helper prerequisite expressly not production qualified',
      closure['prerequisite_helper_qualification']['full_pipeline_qualified'] is False and
      declaration['prerequisite_helper_qualification'] == closure['prerequisite_helper_qualification'])
census = closure['Source_AST_census']
check('full current30 Source census', len(census) == 30 and len({r['alias'] for r in census}) == 30)
for row in census:
    check('census current raw pin: ' + row['alias'], pin(row['source']['path']) == row['source'])
    parsed = ast.parse(Path(row['source']['path']).read_bytes())
    check('census current AST pin: ' + row['alias'], hashlib.sha256(
          ast.dump(parsed, include_attributes=True).encode()).hexdigest() == row['AST_sha256'])
summary = closure['current_import_census_summary']
check('all import sites recounted', summary['static_import_sites'] == sum(len(r['imports']) for r in census)
      and summary['dynamic_import_sites'] == sum(len(r['dynamic_import_sites']) for r in census))
check('no guessed unclassified/relative imports', summary['unclassified_roots'] == [] and summary['relative_import_sites'] == [])
check('nonliteral dynamic sites explicitly retained', len(summary['nonliteral_dynamic_sites']) ==
      sum(site['literal_module'] is None for row in census for site in row['dynamic_import_sites']))
check('exact fixed then symbolic two-arm order', [r['mode'] for r in declaration['schedule']] == ['fixed', 'symbolic']
      and [r['order'] for r in declaration['schedule']] == [1, 2] and len(manifest['plans']) == 2)
outputs = [pin(D / name) for name in ('runtime-closure-v1.json', 'case-declaration-v1.json', 'false-plan-manifest-v1.json')]
for row, planned in zip(declaration['schedule'], manifest['plans']):
    check('complete literal schedule row: ' + row['mode'], planned['row'] == row)
    w = read(planned['worker_plan']['path'])
    o = read(planned['false_once_plan']['path'])
    outputs.extend([planned['worker_plan'], planned['false_once_plan']])
    check('whole worker/false-once pins: ' + row['mode'], pin(planned['worker_plan']['path']) == planned['worker_plan']
          and pin(planned['false_once_plan']['path']) == planned['false_once_plan'])
    check('same exact worker/once fieldsets: ' + row['mode'], set(w) == set(oldworker) and set(o) == set(oldonce))
    check('all row fields exact bothplans: ' + row['mode'], all(w[k] == o[k] == value for k, value in row.items() if k != 'order'))
    check('current full Sources/decl/closure/cold: ' + row['mode'],
          w['project_sources'] == closure['project_sources'] and w['components'] == closure['additional_nonseed_components']
          and w['cold'] == o['cold'] == constants['COLD']
          and w['integration_declaration'] == o['integration_declaration'] == pin(D / 'case-declaration-v1.json')
          and w['runtime_closure'] == o['runtime_closure'] == pin(D / 'runtime-closure-v1.json'))
    check('all Native/Python/Z3/policy/capsule unchanged: ' + row['mode'], all(w[k] == oldworker[k] for k in
          ('native_inputs', 'python', 'z3', 'policy', 'declaration')))
    check('same original outerlimits/environment: ' + row['mode'], o['limits'] == oldonce['limits'] and
          o['environment'] == oldonce['environment'])
    check('false authorization sentinel unlaunchable: ' + row['mode'], o['authorization'] == constants['FALSE_AUTHORIZATION'])
    check('fresh actual and both possible terminal paths absent: ' + row['mode'],
          not Path(row['actual_directory']).exists() and all(not (D / 'plans-v1' / folder /
          (row['invocation_id'] + '-terminal-observation')).exists() for folder in ('once-plans', 'false-once-plans')))

api_pin = save('API-v1.json', dict(
    schema='finalization-integration-metadata-builder-API-v1', author_identity='/root/conventional_library',
    source_only=True, scientific_calls=0, actual_execution_authorized=False,
    Source=pin(B), CLI='PINNED_PYTHON build_false_plans_v1.py ROOT_DIRECTORY RUNNER_SOURCE OBSERVER_SOURCE',
    fixed_output_root=str(D), current_outer=dict(runner=constants['RUNNER'], observer=constants['OBSERVER']),
    fixed_current_components=dict(cold=constants['COLD'], driver=constants['DRIVER']),
    output_files=outputs, output_count=7,
    schemas=dict(closure=closure['schema'], declaration=declaration['schema'],
                 worker=oldworker['schema'], once=oldonce['schema'], manifest=manifest['schema']),
    inactive='No actual or terminal directory, true grant, authorization file, scientific execution or component import. False once plans keep inherited non-descriptor authorization sentinel.',
    corpus='Exact original001 closed input from full original capsule, fixed then symbolic, and_support/schema_then_native/interned/literal_interned, same complete22+2+4 aliases before schema1.',
    trust='Raw pins and AST imports only; Python/bundled stdlib, runtime loader and OS assumptions inherited. Nonliteral imports remain explicit, not evaluated.',
    one_use='Rejects existing metadata paths/plans namespace and absent-path violations; unexpected write failures leave metadata only, not an actual or positive preparation admission.'))
audit_pin = save('author-static-and-output-audit-v1.json', dict(
    schema='finalization-integration-metadata-builder-author-audit-v1', author_identity='/root/conventional_library',
    source_only=True, independent_review=False, scientific_calls=0, component_imports=0,
    fixture_calls=0, Native_calls=0, Model_calls=0, search_calls=0,
    actual_execution_authorized=False, metadata_builder_invocations=1,
    metadata_runtime='Exact pinned Python3.12 executable; only stdlib/raw/AST/ordinaryJSON authoring.',
    Source=pin(B), checks=checks, static_output_checks=len(checks), mismatches=0,
    unused_compiles=unused_compiles, actual_inert_patch_directions=2,
    parent_builder=pin(P / 'build_false_plans_v2.py'), output_files=outputs,
    no_target_execution='No project/component modules loaded, no opaque Native decoding, no model/guard/compiler/search/inverse/renderer functions called.',
    ancestry='Author wrote cold/Model/bridge/point/certifier/helper ancestors; this author audit does not certify own scientific Sources. Root owns cohort and outer Sources; current distinct Source/plan/finalgrant reviews remain required.'))
contract_pin = save('Source-contract-v1.json', dict(
    schema='finalization-integration-metadata-builder-Source-contract-v1',
    author_identity='/root/conventional_library', cohort_owner_identity='/root',
    source_only=True, scientific_acceptance=False, scientific_calls=0,
    actual_execution_authorized=False, Source=pin(B), API=api_pin, author_audit=audit_pin,
    current_master=constants['MASTER'], output_files=outputs,
    preserved='Every scientific Source/Native input/runtime/library/candidate/marking/grammar/profile unchanged except already independently reviewed driverV6/coldV6 instrumentation identities; all original caps/checks/knownexit gates retained by separately reviewed outer.',
    new_fields='finalization_profile mandatory in both declaration and closure, current Source/master/helper prerequisites, full refreshed30-source raw/AST census, explicitly inactive fresh pair subjects.',
    qualification='Helper-only actual does not qualify complete production pipeline or real cost/fit. No new theorem, acceleration, GCTS/RL or activation claim.',
    gate='Root independent adoption and Control current combined Source/full-subject reviews, then separately fresh true max-once grants/finaldelta, then all peers idle before any launch. This packet supplies no execution authorization.'))
handoff = save('handoff-v1.json', dict(
    schema='finalization-integration-metadata-source-output-handoff-v1',
    author_identity='/root/conventional_library', cohort_owner_identity='/root',
    source_only=True, scientific_calls=0, actual_execution_authorized=False,
    status='FROZEN_INACTIVE_METADATA_ONLY', Source=pin(B), API=api_pin,
    contract=contract_pin, author_audit=audit_pin, author_script=pin(__file__),
    manifest=pin(D / 'false-plan-manifest-v1.json'), closure=pin(D / 'runtime-closure-v1.json'),
    declaration=pin(D / 'case-declaration-v1.json'),
    expected_arms=['fixed', 'symbolic'], output_files=outputs,
    current_master=constants['MASTER'],
    pending='Independent current Source/whole-subject review, Root adoption, future true-grant/finaldelta/freshness. No actual authorized or launched.'))
print(json.dumps(dict(handoff=handoff, Source=pin(B), API=api_pin,
                     contract=contract_pin, audit=audit_pin, checks=len(checks))))
