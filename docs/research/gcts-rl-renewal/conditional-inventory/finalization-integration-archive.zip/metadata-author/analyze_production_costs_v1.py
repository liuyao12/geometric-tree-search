"""Saved ordinary metadata arithmetic/raw Source pins only; no component calls."""
import hashlib
import json
from pathlib import Path

L = Path('/private/tmp/gcts-finalization-integration-library-20261019')
D = Path('/private/tmp/gcts-finalization-integration-ROOT-20261019')
COLD = Path('/private/tmp/gcts-finalization-instrumentation-library-20261019/owned_evidence_cold_v6.py')
DRIVER = Path('/private/tmp/gcts-finalization-instrumentation-ROOT-20261019/owned_evidence_receiver_driver_v6.py')
ADAPTER = Path('/private/tmp/gcts-owned-evidence-integration-ROOT-20261019/owned_evidence_adapter_v3.py')
ARENA = Path('/private/tmp/gcts-direct-reconcile-library-20261019/exact_evidence_arena_v3.py')
INVERSE = Path('/private/tmp/gcts-inverse-cadence-ROOT-20261019/independent_forest_inverse_v7.py')


def pin(path):
    path = Path(path).resolve()
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def read(path):
    return json.loads(Path(path).read_bytes())


def save(name, value):
    path = L / name
    if path.exists():
        raise ValueError('frozen report already exists')
    path.write_text(json.dumps(value, sort_keys=True, indent=2, ensure_ascii=False,
                               allow_nan=False) + '\n')
    return pin(path)


rows = []
input_pins = []
for mode, filename in (('fixed', 'worker-failure.json'), ('symbolic', 'worker-receipt.json')):
    actual = D / ('actual-' + mode + '-v1')
    record_path = actual / filename
    runner_path = actual / 'runner-receipt.json'
    record, runner = read(record_path), read(runner_path)
    input_pins.extend([pin(record_path), pin(runner_path)])
    obs = record['cold_observation']
    final = record.get('owned_finalization_observation', record.get('finalization_observation'))
    receipt = record.get('driver_returned_receipt', record.get('driver_output_receipt'))
    if not (final['schema'] == 'owned-finalization-observation-v1' and final['completed'] is True
            and final['authority'] is False and len(final['phases']) == 9
            and len(final['passive_statistics']) == 7):
        raise ValueError('current complete driver observations required for this analysis')
    snapshots = {r['label']: r for r in final['passive_statistics']}
    before = snapshots['before_final_assemble']['statistics']
    after = snapshots['after_final_assemble']['statistics']
    last = snapshots['after_final_full_boundary_check']['statistics']
    driver_phases = [dict(phase=r['phase'], started_seconds=r['started_monotonic'],
        returned_seconds=r['returned_monotonic'], completed=r['completed'],
        action_returned=r['action_returned'],
        observed_seconds=r['returned_monotonic'] - r['started_monotonic']) for r in final['phases']]
    cold_phases = []
    for r in obs['phases']:
        value = dict(phase=r['phase'], state=r['state'], error_type=r['error_type'],
            started_ns=r['started_ns'], returned_ns=r['returned_ns'],
            opened_at_failure_ns=r['opened_at_failure_ns'], completed_interval_seconds=None,
            open_interval_to_failure_seconds=None)
        if r['returned_ns'] is not None and r['started_ns'] is not None:
            value['completed_interval_seconds'] = (r['returned_ns'] - r['started_ns']) / 1e9
        if r['opened_at_failure_ns'] is not None and r['started_ns'] is not None:
            value['open_interval_to_failure_seconds'] = (r['opened_at_failure_ns'] - r['started_ns']) / 1e9
        cold_phases.append(value)
    production = dict(
        adapter_operations=last['operations'], arena_work=last['arena']['counters']['work'],
        nodes=last['arena']['nodes'], edges=last['arena']['edges'], roots=last['arena']['roots'],
        logical_document_bytes=last['arena']['logical_document_bytes'],
        physical_forest_bytes=last['arena']['physical_wire_bytes'],
        arena_cache_bytes=last['arena']['cache_bytes'], arena_cache_entries=last['arena']['cache_entries'],
        scope='Last passive snapshot of this production Store only; excludes separate finite diagnostic Stores and later cold/outer work.')
    for name, expected in (('result.json', production['logical_document_bytes']),
                           ('evidence-forest.json', production['physical_forest_bytes'])):
        p = pin(actual / name)
        if p['bytes'] != expected:
            raise ValueError('whole retained file length disagrees with passive production ledger')
        input_pins.append(p)
    inv = obs['inverse_statistics']
    inverse = dict(prepared=inv['prepared'], phase=inv['phase'],
        document_completed=inv['documents']['receiver:complete-legacy-result']['completed'],
        attempted_operations=inv['attempted_operations'], callback_dispatches=inv['callback_dispatches'],
        maximum_callback_operation_gap=inv['maximum_callback_operation_gap'],
        cache_payload_bytes=inv['cache_payload_bytes'], cache_entries=inv['cache_entries'],
        cache_hits_stream=inv['cache_hits_stream'], logical_documents=inv['logical_documents'],
        aggregate_document_bytes=inv['aggregate_document_bytes'],
        stream_chunks=inv['documents']['receiver:complete-legacy-result']['chunks'],
        authority=False)
    terminal_path = D / 'plans-v1/once-plans' / (
        'finalization-integration-001-' + mode + '-ROOT-20261019-v1-terminal-observation/terminal.json')
    terminal = read(terminal_path)
    input_pins.append(pin(terminal_path))
    rows.append(dict(mode=mode, worker_record=pin(record_path), runner_record=pin(runner_path),
        worker_failure=filename == 'worker-failure.json',
        failure=dict(type=record.get('error_type'), message=record.get('message')),
        resource_candidate_accepted=runner['resource_candidate_accepted'],
        logical_proof_transport_candidate=runner['logical_proof_transport_candidate'],
        driver_native_candidate=receipt['native_proof_accepted'],
        root_or_mathematical_admission_claimed_here=False,
        worker_exit=runner['python_exit_code'], worker_reaped=runner['python_reaped'],
        conservative_worker_plus_native_highwater_bytes=runner['conservative_parent_plus_native_peak_bytes'],
        worker_known_exit_from_Source_entry_seconds=(runner['worker_terminal_observed_ns'] - runner['began_ns']) / 1e9,
        outer_checks_closed_from_Source_entry_seconds=(runner['checks_closed_ns'] - runner['began_ns']) / 1e9,
        external_terminal=terminal,
        driver_phases=driver_phases, cold_phases=cold_phases,
        assembly_snapshot_delta=dict(
            between_labels=['before_final_assemble', 'after_final_assemble'],
            adapter_operations=after['operations'] - before['operations'],
            adapter_counters={k: after['counters'].get(k, 0) - before['counters'].get(k, 0)
                              for k in after['counters']},
            arena_work=after['arena']['counters']['work'] - before['arena']['counters']['work'],
            arena_counters={k: after['arena']['counters'].get(k, 0) - before['arena']['counters'].get(k, 0)
                            for k in after['arena']['counters']}),
        production_last_snapshot=production, independent_inverse=inverse,
        cold_counts=dict(obs['counts']), snapshot_cutoff_ns=obs['snapshot_cutoff_ns'],
        snapshot_scope=obs['snapshot_scope'], diagnostic_errors=obs['diagnostic_errors'], truncated=obs['truncated'],
        old_result_reading=record.get('result_reading'),
        whole_file_pins=[pin(actual / 'result.json'), pin(actual / 'evidence-forest.json')]))

report = dict(
    schema='instrumented-production-evidence-cost-next-design-v1',
    author_identity='/root/conventional_library', saved_data_and_Source_only=True,
    status='DIAGNOSTIC_ANALYSIS_AND_PROPOSED_UNIMPLEMENTED_OPTIMIZATION',
    scientific_calls=0, component_imports=0, fixture_calls=0, proof_replays=0,
    Native_Model_inverse_codec_renderer_calls=0, scientific_acceptance=False,
    actual_execution_authorized=False, future_execution_authorized=False,
    reviewed_master=pin('/private/tmp/gcts-cadence-integration-ROOT-20261019/basic-tiling-algorithm-HEAD.md'),
    scope='Two already-closed familiar original001 full-pipeline observations. Saved ordinary metadata arithmetic plus whole raw file hash/size and raw Source inspection. No full result semantic parse, component evaluation or independent resource/logic admission here.',
    ancestry='Author wrote current cold instrumentation, helper harness, prior Model/bridge/point/certifier and metadata builder. Root authored driverV6 and actuals. This is not independent certification of own Sources or an alternative to Control saved-data audit.',
    inputs=input_pins, current_sources={name: pin(path) for name, path in (
        ('cold', COLD), ('driver', DRIVER), ('adapter', ADAPTER), ('arena', ARENA), ('inverse', INVERSE))},
    observations=rows,
    primary_findings=[
        'final_assemble is the largest observed individual named driver phase:82.514643292s fixed and75.879929792s symbolic. These elapsed action intervals include their nested work/guards; they do not measure which internal operation caused the cost.',
        'ordinary_atomic_stream_write is next at31.128524750s fixed and22.693087709s symbolic. seal+wire are individually about3.2–3.6s. All finish before driver return in both arms.',
        'Fresh saved inverse completed in both:8.141780625s fixed and7.409865292s symbolic including child preparation+stream/comparison. It is not the fixed failure phase this time.',
        'Fixed old_result_decode returned after1.464695250s, then old_canonical_roundtrip remained OPEN_AT_FAILURE after5.540450417s. That open interval is not a completed comparison timing. Symbolic decode1.230313084s and canonical comparison4.475515042s completed.',
        'Only symbolic has a normal whole worker header and outer candidate resource/proof gates; fixed earlier Native candidate/complete driver/complete inverse do not admit a bounded proof. Fixed aggregate highwater is null and remains unavailable; do not fill it with a worker-only maximum.',
        'Assembly deltas:47/48 completed capture calls,94/96 JSON freezes and47/48 JSON parse pairs (fixed/symbolic). legacy_JSON_parts and copy_chunks each rise34,768,650/31,625,504. These are Source counter meanings, not bytes, allocations, callback dispatches or independent microsteps.',
        'Last production snapshots show Arena391,006,399/355,073,140 work against400m and adapter128,915,931/116,635,629 operations against400m. They are distinct profiles, not comparable operation units or complete process costs.',
        'Cold guard totals32.819971415/34.704391525s are overlapping aggregate intervals through their own cutoffs. They cannot be added to phases or used to predict guard removal gains. Arena/adapter callback-origin categories remain unavailable.'],
    Source_diagnosis=[
        dict(source='adapter', lines=[127, 201],
            fact='assemble classifies each mixed subtree with _contains_reference; a reference-free subtree enters _capture, which repeats the domain scan, then _canonical(original), json.loads, _canonical(normalized), and Arena.capture. _canonical iterates tiny JSONEncoder parts and separately counts/encodes/copies each part.',
            hypothesis='This repeated validation/normalization/encoding is a concrete contributor candidate for the large assembly interval. No per-subroutine wall or allocation measurement isolates its share.'),
        dict(source='arena', lines=[120, 194],
            fact='Ordinary output stream uses token machine, bounded pending buffer, per-token/copy accounting, exact expanded size/occurrence completion and current Source/clock gates. Cached fragments are bounded; full output still visits/copies every emitted byte.',
            hypothesis='The31/22s streaming intervals may include token/accounting/copy/guard/FS costs. Current counters do not isolate them; independent inverse has a different algorithm/cache profile and is not an apples-to-apples speed control.'),
        dict(source='cold', lines=[241, 257],
            fact='verify_literal_result encodes every original JSONEncoder part, slices/compares the matching raw interval and calls need() per part; it increments chunks as encoder-part count and checkpoints every65,536 parts, then hashes the complete body once at EOF.',
            hypothesis='Avoiding millions of tiny raw slice/equality/need calls is a narrow candidate. Hashing is not performed per part. Symbolic retained chunks15,901,556 means parts, not64KiB byte blocks.'),
        dict(source='cold', lines=[975, 1019],
            fact='Inherited result_reading.decode_seconds begins before saved inverse and ends after ordinary decode; it includes inverse/parse work. New old_result_decode is the narrower decode interval.',
            hypothesis='No phase sum may count old decode_seconds plus inverse as disjoint work.')],
    recommended_first_optimization=dict(
        name='Bounded buffered canonical byte comparison in verify_literal_result only',
        status='PROPOSED_UNIMPLEMENTED_UNMEASURED',
        why_first='Smallest reviewable change at the newly observed fixed stop, using the same canonical encoder and full ordinary preimage. It does not solve or optimize the larger assembly phase and no fit/speed result is predicted.',
        boundary='Fresh cold Source successor changes only this verifier body and version/profile metadata; current driver/adapter/Arena/inverse/Native/Model/search remain pinned.',
        algorithm=[
            'Keep exactly the old JSONEncoder options and every emitted text part/UTF8 byte; count original parts identically and preserve chunks as that old count.',
            'Accumulate encoded bytes into a bounded at-most64KiB byte buffer and compare contiguous blocks to the raw complete BODY. Split a long encoded part across bounded buffer fills without dropping or reordering bytes; the original part encode still has the old nonpreemptive builtin caveat.',
            'Flush and compare all pending bytes before each existing65,536-part checkpoint, preserving mismatch-before-external-callback ordering for the already-generated prefix. Keep initial/final direct checkpoints; no generator wrapper or exception conversion.',
            'Require the same full BODY length/EOF and single external LF semantics enforced by unchanged surrounding pipeline; hash the same body once at EOF. No digest-only equality or prefix acceptance.',
            'If reporting block count, name it separately from original encoder-part chunks; keep new metadata out of mathematical result authority and include all CPU/byte/copy/RAM costs.'],
        preserved=['Every original result datum and canonical byte; complete independent forest inverse remains separate.',
                   'Exact original error/callback identity and non-success on unfinished comparison.',
                   'Whole original point/Native checks, scheduler/base alternatives/rollback, inventory/grammar/case and all numeric caps.',
                   'No old failure recovery, replayed proof, changed allowance, optional verification skip or ordinary-output removal.'],
        future_qualification=['Independent Source/AST delta review and bounded finite unequal/malformed/truncated/rawLF/Unicode/float-signedzero/tuple-reader cases; exact checkpoint exceptions including StopIteration must escape unconverted.',
            'Show all parts and compared byte blocks fully covered, flush before original checkpoint boundaries, and EOF/body hash agrees on whole retained ordinary preimages. No fixtures run in this task.',
            'Any fresh matched full-pipeline pair must receive the same Source/profile in both arms with new reviewed subjects/grants. Old fixed negative remains negative; no cap/time reset or fit guarantee.']),
    larger_deferred_choice=dict(
        name='Typed legacy normalization and assembly traversal redesign',
        rationale='The75–82s dominant phase and observed repeated full JSON conversion justify investigating this separately, after the narrow verifier change is assessed or if Root prioritizes the larger boundary.',
        not_authorized='No implementation, claim or combined factor in the next comparison is authorized here.',
        obligations=['A fused tuple-to-array exact builtin snapshot plus direct second-read reconciliation may replace redundant domain scans/JSON encode-parse-encode only after demonstrating exact old canonical projection for every supported type/key/order/float/Unicode/missing/zero case.',
            'Keep complete caller ownership/mutation detection, all full certificate/inventory/Model/trace data, private custody snapshots and every capture/compose root reachability; never cache mutable carriers by identity/hash as authority.',
            'Arena first build/direct reconciliation/transaction/publication, independent inverse and whole output checks remain unchanged. All real operations/allocations counted; any new accounting profile is explicit and cannot relabel old work guard success.',
            'Do not combine this with cache selection, Native aliases, changed callback cadence or limits. Additional copy/reconciliation may cost more; current counters prove no saving.']),
    accounting_limits=[
        'Driver seconds are binary-float observations; cold phase clocks are integer nanoseconds. Preserve both units and exact raw timestamps.',
        'driver_run encloses all driver phases. saved_forest_full_comparison encloses independent_prepare/independent_stream_and_compare. Cold source_guard intervals overlap these. Do not sum nested quantities as disjoint total.',
        'Cold snapshot_cutoff excludes later guards, metadata fixed-point serialization, cleanup and exit. Fixed is a post-failure snapshot; symbolic is before final header/exit. Counts are not whole-window terminal totals.',
        'No ordinary-storage ablation, randomized repeats, blind theorem or causal optimization comparison. Different fixed/symbolic traces/output sizes/work units prevent attributing their timing difference to this representation.',
        'Global180work/positive+knownexit, later210outer, conservative separate worker+Native1GiB, both logical/physical128MiB and logs4MiB remain mandatory. New copies/checks/observations count against those same gates.',
        'One or both future arms can remain UNKNOWN/resource-failed. No runtime-saving, bounded-fit, mathematical, GCTS or RL advantage is inferred.'])

report_pin = save('production-evidence-cost-next-design-v1.json', report)
handoff_pin = save('production-evidence-cost-next-design-handoff-v1.json', dict(
    schema='production-evidence-cost-next-design-handoff-v1',
    author_identity='/root/conventional_library', source_and_saved_metadata_only=True,
    actual_execution_authorized=False, future_execution_authorized=False,
    scientific_acceptance=False, scientific_calls=0, component_imports=0,
    component_Native_inverse_fixture_calls=0, report=report_pin,
    author_script=pin(__file__),
    summary='Assembly dominates observed driver phases; fixed fails later canonical comparison after complete inverse. Recommend small buffered full canonical byte comparator first; larger normalization redesign separately scoped. No implementation or predicted gain.'))
print(json.dumps(dict(report=report_pin, handoff=handoff_pin)))
