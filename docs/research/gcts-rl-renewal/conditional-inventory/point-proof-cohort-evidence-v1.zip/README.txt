Six original public development targets; one admitted elementary reflexivity proof and five whole-work deadline failures.
V2 repairs only a temporal description of the first proof archive; identical current cohort data.
V1 display and its independent negative review are preserved historical evidence, not the current page.
Old first-case files saying other targets were unrun describe their original checkpoint. PUBLIC-RESULT gives current six-case outcomes.
Case0 alone has 162 qualified scoped control groups. Five failures supply no positive prefix and no qualified whole memory.
No practical theorem-search, matched-baseline, learned marking, RL or receptor-family advantage established.
Full selected Source/records only; no research invocation by packaging. External interpreter pinned, not bundled.
