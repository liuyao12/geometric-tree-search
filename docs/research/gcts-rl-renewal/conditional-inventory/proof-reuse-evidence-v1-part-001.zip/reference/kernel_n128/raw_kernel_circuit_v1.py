"""Raw bounded FOL Hilbert kernel lowered into NAND, without rule catalogues.

Formula DAG labels and children, proof records and substitution maps are circuit
data. Only declared problem pins may partially evaluate the generic checker.
This module performs no proof search and imports no logical validity checker.
"""
from fixed_palette_v1 import Builder as BasicBuilder

CAPS = dict(nodes=128, variables=8, functions=16, predicates=16, axioms=16,
            lines=16, substitutions=4, arity=4)
GATE_CAP = 1000000
TAGS = dict(VAR=1, FUN=2, PRED=3, EQ=4, NOT=5, IMP=6, ALL=7, BOT=10)
RULES = ['AXIOM','MP','GEN','UI','REFL','DIST','EQSUB','AX1','AX2','AX3','BOT_FALSE']


class ResourceLimit(ValueError):
    pass


class Builder(BasicBuilder):
    """NAND constant propagation, including fixed input bits; no logical oracle."""
    def __init__(self, inputs):
        super().__init__(inputs)
        self.fixed = {i:v['value'] for i,v in enumerate(inputs) if v['value'] is not None}
        self.opposites = {0:1, 1:0}

    def resolve(self, a):
        return self.fixed.get(a, a)

    def raw(self, a, b):
        key = tuple(sorted((a,b)))
        if key not in self.cache:
            if len(self.gates) >= GATE_CAP:
                raise ResourceLimit('NAND_GATE_CAP')
            self.cache[key] = len(self.inputs)+len(self.gates)
            self.gates.append(list(key))
        return self.cache[key]

    def NOT(self, a):
        a=self.resolve(a)
        if a in self.opposites:
            return self.opposites[a]
        result=self.raw(a,a); self.opposites[a]=result; self.opposites[result]=a
        return result

    def nand(self, a, b):
        a,b=self.resolve(a),self.resolve(b)
        if a==0 or b==0: return 1
        if a==1: return self.NOT(b)
        if b==1 or a==b: return self.NOT(a)
        return self.raw(a,b)

    def AND(self,a,b):
        a,b=self.resolve(a),self.resolve(b)
        if a==b: return a
        return self.NOT(self.nand(a,b))

    def OR(self,a,b):
        a,b=self.resolve(a),self.resolve(b)
        if a==b: return a
        return self.nand(self.NOT(a),self.NOT(b))

    def XOR(self,a,b):
        a,b=self.resolve(a),self.resolve(b)
        if a==b: return 0
        return super().XOR(a,b)

    def EQ(self,a,b):
        a,b=self.resolve(a),self.resolve(b)
        if a==b: return 1
        return self.NOT(self.XOR(a,b))

    def mux(self,s,a,b):
        s,a,b=self.resolve(s),self.resolve(a),self.resolve(b)
        if s==0: return a
        if s==1 or a==b: return b
        return self.nand(self.nand(self.NOT(s),a),self.nand(s,b))


def widths(bounds):
    if type(bounds) is not dict or set(bounds)!=set(CAPS):
        raise ValueError('BOUNDS_FIELDS')
    for name,cap in CAPS.items():
        minimum=2 if name in ('nodes','arity') else 1 if name in ('variables','lines') else 0
        if type(bounds[name]) is not int or bounds[name]<minimum: raise ValueError('BOUNDS_TYPE_OR_RANGE')
        if bounds[name]>cap: raise ResourceLimit('BOUND_'+name)
    return {'node':max(1,(bounds['nodes']-1).bit_length()),
            'head':max(1,(max(bounds['variables'],bounds['functions'],bounds['predicates'],1)-1).bit_length()),
            'arity':max(1,bounds['arity'].bit_length()),
            'ref':max(1,(bounds['lines']-1).bit_length()),
            'aux':max(1,(max(bounds['axioms'],bounds['substitutions'],1)-1).bit_length())}


class Compiler:
    def __init__(self,bounds,pins):
        self.bounds=dict(bounds); self.w=widths(bounds)
        if type(pins) is not dict or any(type(k) is not str or type(v) is not int or v not in (0,1) for k,v in pins.items()):
            raise ValueError('PIN_TYPES')
        self.inputs=[{'name':'zero','value':0},{'name':'one','value':1}]
        names=set()
        def word(name,width):
            result=[]
            for bit in range(width):
                label=name+'.'+str(bit); names.add(label); result.append(len(self.inputs))
                self.inputs.append({'name':label,'value':pins.get(label)})
            return result
        def bit(name):
            names.add(name); result=len(self.inputs); self.inputs.append({'name':name,'value':pins.get(name)});return result
        self.functions=[word('function.%d.arity'%i,self.w['arity']) for i in range(bounds['functions'])]
        self.predicates=[word('predicate.%d.arity'%i,self.w['arity']) for i in range(bounds['predicates'])]
        self.nodes=[]
        for i in range(bounds['nodes']):
            self.nodes.append({'tag':word('node.%d.tag'%i,4),'head':word('node.%d.head'%i,self.w['head']),
                               'args':[word('node.%d.arg.%d'%(i,k),self.w['node']) for k in range(bounds['arity'])]})
        self.axioms=[word('axiom.%d'%i,self.w['node']) for i in range(bounds['axioms'])]
        self.goal=word('goal',self.w['node'])
        self.lines=[]
        for i in range(bounds['lines']):
            self.lines.append({name:word('line.%d.%s'%(i,name),width) for name,width in
                               [('rule',4),('formula',self.w['node']),('ref0',self.w['ref']),('ref1',self.w['ref']),('aux0',self.w['aux']),('aux1',self.w['aux'])]})
        self.subs=[]
        for i in range(bounds['substitutions']):
            self.subs.append({**{name:word('sub.%d.%s'%(i,name),self.w['head'] if name=='variable' else self.w['node'])
                                for name in ('source','variable','term','result')},
                              'active':[bit('sub.%d.active.%d'%(i,j)) for j in range(bounds['nodes'])],
                              'map':[word('sub.%d.map.%d'%(i,j),self.w['node']) for j in range(bounds['nodes'])]})
        if set(pins)-names: raise ValueError('UNKNOWN_PIN_NAMES')
        self.b=Builder(self.inputs); self.select_cache={}; self.node_cache={};self.groups=[]

    def equal(self,word,value):
        return self.b.word_eq(word,self.b.const_word(value,len(word))) if 0<=value<1<<len(word) else 0

    def selectors(self,word,count):
        normalized=tuple(self.b.resolve(x) for x in word); key=(normalized,count)
        if key not in self.select_cache:
            self.select_cache[key]=[self.equal(normalized,i) for i in range(count)]
        return self.select_cache[key]

    def lookup(self,rows,word,width):
        normalized=[self.b.resolve(x) for x in word]
        if all(x in (0,1) for x in normalized):
            i=sum(v<<k for k,v in enumerate(normalized))
            return (list(rows[i]),1) if i<len(rows) else ([0]*width,0)
        selected=self.selectors(normalized,len(rows)); found=self.b.any(selected)
        return [self.b.any([self.b.AND(s,row[k]) for s,row in zip(selected,rows)]) for k in range(width)],found

    def scalar(self,rows,word):
        result,found=self.lookup([[x] for x in rows],word,1);return result[0],found

    def implication(self,a,b):
        return self.b.OR(self.b.NOT(a),b)

    def select_var(self,vector,word):
        return self.scalar(vector,word)[0]

    def all(self,*items): return self.b.all(items)
    def is_tag(self,node,tag): return self.equal(node['tag'],tag)
    def id_equal(self,left,right): return self.b.word_eq(left,right)

    def grammar(self):
        b=self.b; V=self.bounds['variables'];R=self.bounds['arity'];checks=[]
        start=len(b.gates)
        for arity in self.functions+self.predicates:
            checks.append(b.any([self.equal(arity,r) for r in range(R+1)]))
        for i,node in enumerate(self.nodes):
            tags={name:self.is_tag(node,value) for name,value in TAGS.items()}
            node['is_term']=b.OR(tags['VAR'],tags['FUN']) if i else 0
            node['is_formula']=b.any([tags[k] for k in ('PRED','EQ','NOT','IMP','ALL','BOT')]) if i else 0
        for i,node in enumerate(self.nodes):
            if i==0:
                checks += [self.equal(node['tag'],0),self.equal(node['head'],0)]+[self.equal(a,0) for a in node['args']]
                node['fv']=[0]*V; node['used']=[0]*R; continue
            tags={name:self.is_tag(node,value) for name,value in TAGS.items()}
            variable_ok=b.any(self.selectors(node['head'],V))
            fnarity,fnfound=self.lookup(self.functions,node['head'],self.w['arity'])
            prarity,prfound=self.lookup(self.predicates,node['head'],self.w['arity'])
            fngt=[b.any([self.equal(fnarity,n) for n in range(k+1,R+1)]) for k in range(R)]
            prgt=[b.any([self.equal(prarity,n) for n in range(k+1,R+1)]) for k in range(R)]
            child_terms=[];child_forms=[];prior=[];fvs=[]
            for arg in node['args']:
                prior.append(b.any(self.selectors(arg,i)[1:]))
                child_terms.append(self.scalar([n['is_term'] for n in self.nodes],arg)[0])
                child_forms.append(self.scalar([n['is_formula'] for n in self.nodes],arg)[0])
                fvs.append(self.lookup([n['fv'] for n in self.nodes[:i]],arg,V)[0])
            zeros=[self.equal(a,0) for a in node['args']]
            termchild=[self.all(p,t) for p,t in zip(prior,child_terms)]
            formchild=[self.all(p,t) for p,t in zip(prior,child_forms)]
            fnargs=b.all([b.mux(used,zero,ok) for used,zero,ok in zip(fngt,zeros,termchild)])
            prargs=b.all([b.mux(used,zero,ok) for used,zero,ok in zip(prgt,zeros,termchild)])
            headzero=self.equal(node['head'],0)
            checks.append(b.any([
                self.all(tags['VAR'],variable_ok,*zeros),self.all(tags['FUN'],fnfound,fnargs),
                self.all(tags['PRED'],prfound,prargs),
                self.all(tags['EQ'],headzero,*termchild[:2],*zeros[2:]),
                self.all(tags['NOT'],headzero,formchild[0],*zeros[1:]),
                self.all(tags['IMP'],headzero,*formchild[:2],*zeros[2:]),
                self.all(tags['ALL'],variable_ok,formchild[0],*zeros[1:]),
                self.all(tags['BOT'],headzero,*zeros)]))
            node['fv']=[]
            for v in range(V):
                union=b.any([fv[v] for fv in fvs])
                node['fv'].append(b.mux(tags['VAR'],b.AND(union,b.NOT(b.AND(tags['ALL'],self.equal(node['head'],v)))),self.equal(node['head'],v)))
            node['used']=[b.any([b.AND(tags['FUN'],fngt[k]),b.AND(tags['PRED'],prgt[k]),
                                 b.OR(tags['EQ'],tags['IMP']) if k<2 else 0,
                                 b.OR(tags['NOT'],tags['ALL']) if k==0 else 0]) for k in range(R)]
        self.groups.append({'label':'formula syntax, types and free variables','start':start,'end':len(b.gates)})
        return b.all(checks)

    def node(self,word):
        key=tuple(self.b.resolve(v) for v in word)
        if key in self.node_cache:return self.node_cache[key]
        R,V=self.bounds['arity'],self.bounds['variables'];nw,hw=self.w['node'],self.w['head']
        rows=[n['tag']+n['head']+sum(n['args'],[])+[n['is_term'],n['is_formula']]+n['fv'] for n in self.nodes]
        values,found=self.lookup(rows,word,4+hw+R*nw+2+V)
        offset=4+hw
        result={'id':list(word),'tag':values[:4],'head':values[4:offset],
                'args':[values[offset+k*nw:offset+(k+1)*nw] for k in range(R)],
                'is_term':values[offset+R*nw],'is_formula':values[offset+R*nw+1],
                'fv':values[offset+R*nw+2:],'found':found}
        self.node_cache[key]=result;return result

    def substitution(self,task,index):
        b=self.b;N=self.bounds['nodes'];start=len(b.gates)
        source,term,result=(self.node(task[k]) for k in ('source','term','result'))
        mapped,_=self.lookup(task['map'],task['source'],self.w['node'])
        active,_=self.scalar(task['active'],task['source'])
        checks=[source['is_formula'],term['is_term'],result['is_formula'],
                b.any(self.selectors(task['variable'],self.bounds['variables'])),
                b.NOT(task['active'][0]),active,self.id_equal(mapped,task['result'])]
        checks.extend(b.any(self.selectors(word,N)) for word in task['map'])
        for i in range(1,N):
            src=self.nodes[i];dst=self.node(task['map'][i])
            isvar=self.is_tag(src,1);isall=self.is_tag(src,7);samevar=self.id_equal(src['head'],task['variable'])
            mapi=self.equal(task['map'][i],i)
            leafvar=b.mux(samevar,mapi,self.id_equal(task['map'][i],task['term']))
            recurse=[dst['found'],self.id_equal(src['tag'],dst['tag']),self.id_equal(src['head'],dst['head'])]
            for used,arg,outarg in zip(src['used'],src['args'],dst['args']):
                childactive,_=self.scalar(task['active'],arg)
                childmap,_=self.lookup(task['map'],arg,self.w['node'])
                recurse.append(self.implication(used,self.all(childactive,self.id_equal(childmap,outarg))))
            bodyfv=self.lookup([n['fv'] for n in self.nodes],src['args'][0],self.bounds['variables'])[0]
            capture=b.AND(self.select_var(bodyfv,task['variable']),self.select_var(term['fv'],src['head']))
            recurse.append(self.implication(isall,b.NOT(capture)))
            ordinary=b.all(recurse)
            valid=b.mux(isall,b.mux(isvar,ordinary,leafvar),b.mux(samevar,ordinary,mapi))
            checks.append(self.implication(task['active'][i],valid))
        valid=b.all(checks)
        self.groups.append({'label':'capture-free substitution certificate %d'%(index+1),'start':start,'end':len(b.gates)})
        return valid

    def task(self,index):
        nw,hw=self.w['node'],self.w['head']
        rows=[t['source']+t['variable']+t['term']+t['result'] for t in self.subs]
        values,found=self.lookup(rows,index,3*nw+hw)
        return {'source':values[:nw],'variable':values[nw:nw+hw],
                'term':values[nw+hw:2*nw+hw],'result':values[2*nw+hw:],'found':found}

    def proof_line(self,i,line):
        b=self.b;start=len(b.gates)
        f=self.node(line['formula']);l=self.node(f['args'][0]);r=self.node(f['args'][1])
        ll=self.node(l['args'][0]);lr=self.node(l['args'][1]);rl=self.node(r['args'][0]);rr=self.node(r['args'][1])
        prior=[p['formula'] for p in self.lines[:i]]
        a,ref0ok=self.lookup(prior,line['ref0'],self.w['node']);u,ref1ok=self.lookup(prior,line['ref1'],self.w['node'])
        implication=self.node(u)
        axiom,axok=self.lookup(self.axioms,line['aux0'],self.w['node'])
        s0,s1=self.task(line['aux0']),self.task(line['aux1'])
        imp=lambda n:self.is_tag(n,6);alltag=lambda n:self.is_tag(n,7);nottag=lambda n:self.is_tag(n,5)
        rules=[
            self.all(axok,self.id_equal(line['formula'],axiom)),
            self.all(ref0ok,ref1ok,imp(implication),self.id_equal(implication['args'][0],a),self.id_equal(implication['args'][1],line['formula'])),
            self.all(ref0ok,alltag(f),self.id_equal(f['args'][0],a)),
            self.all(imp(f),alltag(l),s0['found'],self.id_equal(s0['source'],l['args'][0]),
                     self.id_equal(s0['variable'],l['head']),self.id_equal(s0['result'],f['args'][1])),
            self.all(self.is_tag(f,4),self.id_equal(f['args'][0],f['args'][1])),
            self.all(imp(f),alltag(l),imp(ll),imp(r),alltag(rr),
                     self.id_equal(l['head'],rr['head']),self.id_equal(ll['args'][0],r['args'][0]),
                     self.id_equal(ll['args'][1],rr['args'][0]),b.NOT(self.select_var(rl['fv'],l['head']))),
            self.all(imp(f),self.is_tag(l,4),imp(r),s0['found'],s1['found'],
                     self.id_equal(s0['source'],s1['source']),self.id_equal(s0['variable'],s1['variable']),
                     self.id_equal(s0['term'],l['args'][0]),self.id_equal(s1['term'],l['args'][1]),
                     self.id_equal(s0['result'],r['args'][0]),self.id_equal(s1['result'],r['args'][1])),
            self.all(imp(f),imp(r),self.id_equal(f['args'][0],r['args'][1])),
            self.all(imp(f),imp(l),imp(lr),imp(r),imp(rl),imp(rr),
                     self.id_equal(l['args'][0],rl['args'][0]),self.id_equal(l['args'][0],rr['args'][0]),
                     self.id_equal(lr['args'][0],rl['args'][1]),self.id_equal(lr['args'][1],rr['args'][1])),
            self.all(imp(f),imp(l),nottag(ll),nottag(lr),imp(r),
                     self.id_equal(ll['args'][0],r['args'][1]),self.id_equal(lr['args'][0],r['args'][0])),
            self.all(nottag(f),self.is_tag(l,10))]
        valid=self.all(f['is_formula'],b.any([self.all(self.equal(line['rule'],rule),value) for rule,value in enumerate(rules)]))
        self.groups.append({'label':'raw proof line %d'%(i+1),'start':start,'end':len(b.gates),'proof_line':i})
        return valid,rules

    def compile(self):
        b=self.b;checks=[self.grammar()];line_rules=[]
        for i,task in enumerate(self.subs): checks.append(self.substitution(task,i))
        for axiom in self.axioms:
            n=self.node(axiom); checks += [n['is_formula'],b.NOT(b.any(n['fv']))]
        checks.append(self.node(self.goal)['is_formula'])
        for i,line in enumerate(self.lines):
            valid,rules=self.proof_line(i,line); checks.append(valid);line_rules.append(rules)
        start=len(b.gates);checks.append(self.id_equal(self.lines[-1]['formula'],self.goal))
        output=b.all(checks)
        self.groups.append({'label':'all logical checks and final goal','start':start,'end':len(b.gates)})
        return b.finish(output),{'schema':'NK-raw-kernel-circuit-metadata-v1','bounds':self.bounds,
                'widths':self.w,'inputs':self.inputs,'groups':self.groups,'rule_names':RULES,
                'checks':checks,'line_rule_validity_wires':line_rules,'gate_cap':GATE_CAP,
                'scope':'Raw bounded first-order Hilbert proof checking. Partial evaluation only of declared input pins; no admitted producer catalogue or proof search.'}


def compile_kernel(bounds,pins):
    return Compiler(bounds,pins).compile()
