"""Independent bounded raw-AST first-order Hilbert checker, inert Source.

No compiler, Builder, encoder, proof search or external logical-zero catalogue.
All syntax and substitution tasks are checked, including unused supplied data.
ID equality supplies shared literal AST equality; no alpha-renaming is assumed.
"""
import hashlib
import json

VERSION = 'NK-RAW-FOL-CHECKER-n128-resource-v1'
CAPS = {'nodes': 128, 'variables': 8, 'functions': 16, 'predicates': 16,
        'axioms': 16, 'lines': 16, 'substitutions': 4, 'arity': 4}
RULES = ('AXIOM', 'MP', 'GEN', 'UI', 'REFL', 'DIST', 'EQSUB',
         'AX1', 'AX2', 'AX3', 'BOT_FALSE')


class _Failure(Exception):
    def __init__(self, status, reason):
        self.status, self.reason = status, reason


def _need(condition, reason):
    if not condition:
        raise _Failure('REJECTED', reason)


def _limit(condition, reason):
    if not condition:
        raise _Failure('UNKNOWN', reason)


def _fields(value, names, reason):
    _need(type(value) is dict and all(type(key) is str for key in value)
          and set(value) == set(names), reason)


def _integer(value, lower, upper):
    return type(value) is int and lower <= value <= upper


def _hash(value):
    data = (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')
    return hashlib.sha256(data).hexdigest()


def _bounds(bounds):
    _fields(bounds, CAPS, 'BOUNDS_FIELDS')
    for name, cap in CAPS.items():
        minimum = {'nodes': 2, 'variables': 1, 'lines': 1, 'arity': 2}.get(name, 0)
        _need(type(bounds[name]) is int and bounds[name] >= minimum, 'BOUNDS_NATIVE_INTEGER_OR_MINIMUM')
        _limit(bounds[name] <= cap, 'RESOURCE_BOUND_' + name)
    return dict(bounds)


def _word(value, width, reason):
    _need(_integer(value, 0, (1 << width) - 1), reason)


def _sort(identifier, expected, sorts):
    _need(_integer(identifier, 1, len(sorts) - 1)
          and sorts[identifier] == expected, 'NODE_ID_OR_SORT_' + expected)


def _syntax(bounds, certificate):
    n, v, a = bounds['nodes'], bounds['variables'], bounds['arity']
    nw = max(1, (n - 1).bit_length())
    hw = max(1, (max(v, bounds['functions'], bounds['predicates'], 1) - 1).bit_length())
    for name in ('functions', 'predicates'):
        signature = certificate[name]
        _need(type(signature) is list and len(signature) == bounds[name], 'SIGNATURE_COUNT_' + name)
        _need(all(_integer(arity, 0, a) for arity in signature), 'SIGNATURE_ARITY_' + name)
    nodes = certificate['nodes']
    _need(type(nodes) is list and len(nodes) == n, 'NODE_COUNT')
    sorts, free, used_counts = ['NULL'], [0], [0]
    for i, row in enumerate(nodes):
        _need(type(row) is list and len(row) == 2 + a, 'NODE_ROW_LENGTH')
        _word(row[0], 4, 'NODE_TAG_WORD'); _word(row[1], hw, 'NODE_HEAD_WORD')
        for child in row[2:]:
            _word(child, nw, 'NODE_CHILD_WORD')
        if i == 0:
            _need(all(value == 0 for value in row), 'EXACT_NULL_NODE_ZERO')
            continue
        tag, head, args = row[0], row[1], row[2:]
        _need(tag in (1, 2, 3, 4, 5, 6, 7, 10), 'NODE_TAG_GRAMMAR')
        if tag == 1:
            _need(head < v, 'VARIABLE_HEAD')
            used, child_sort, own_sort, fv = 0, None, 'TERM', 1 << head
        elif tag in (2, 3):
            signature = certificate['functions' if tag == 2 else 'predicates']
            _need(head < len(signature), 'SIGNATURE_HEAD')
            used, child_sort = signature[head], 'TERM'
            own_sort, fv = ('TERM' if tag == 2 else 'FORMULA'), 0
        else:
            _need(head < v if tag == 7 else head == 0, 'LOGICAL_NODE_HEAD')
            used = {4: 2, 5: 1, 6: 2, 7: 1, 10: 0}[tag]
            child_sort, own_sort, fv = ('TERM' if tag == 4 else 'FORMULA'), 'FORMULA', 0
        _need(all(value == 0 for value in args[used:]), 'UNUSED_NODE_ARGUMENTS_ZERO')
        for child in args[:used]:
            _need(0 < child < i and sorts[child] == child_sort, 'STRICT_PRIOR_CHILD_OR_SORT')
            fv |= free[child]
        if tag == 7:
            fv &= ~(1 << head)
        sorts.append(own_sort); free.append(fv); used_counts.append(used)
    return nodes, sorts, free, used_counts


def _tasks(bounds, certificate, nodes, sorts, free, used_counts):
    tasks = certificate['substitutions']
    _need(type(tasks) is list and len(tasks) == bounds['substitutions'], 'SUBSTITUTION_COUNT')
    n, v = bounds['nodes'], bounds['variables']
    for task in tasks:
        _fields(task, ('source', 'variable', 'term', 'result', 'active', 'map'), 'SUBSTITUTION_FIELDS')
        _sort(task['source'], 'FORMULA', sorts); _sort(task['result'], 'FORMULA', sorts)
        _sort(task['term'], 'TERM', sorts)
        x = task['variable']; _need(_integer(x, 0, v - 1), 'SUBSTITUTION_VARIABLE')
        active, mapping = task['active'], task['map']
        _need(type(active) is list and len(active) == n
              and all(type(bit) is int and bit in (0, 1) for bit in active), 'SUBSTITUTION_ACTIVE_BITS')
        _need(type(mapping) is list and len(mapping) == n
              and all(_integer(identifier, 0, n - 1) for identifier in mapping), 'SUBSTITUTION_MAP_IDS')
        _need(active[0] == 0 and active[task['source']] == 1
              and mapping[task['source']] == task['result'], 'SUBSTITUTION_ROOT_BINDING')
        for i in range(1, n):
            if not active[i]:
                continue
            source, target = nodes[i], mapping[i]
            if source[0] == 1:
                _need(target == (task['term'] if source[1] == x else i), 'SUBSTITUTION_VARIABLE_IMAGE')
            elif source[0] == 7 and source[1] == x:
                _need(target == i, 'SUBSTITUTION_BOUND_VARIABLE_STOP')
            else:
                result = nodes[target]
                _need(result[:2] == source[:2], 'SUBSTITUTION_TAG_HEAD_IMAGE')
                for k in range(used_counts[i]):
                    child = source[2 + k]
                    _need(active[child] == 1 and result[2 + k] == mapping[child], 'SUBSTITUTION_ACTIVE_CHILD_IMAGE')
                if source[0] == 7:
                    binder, body = source[1], source[2]
                    _need(not ((free[body] >> x) & 1 and (free[task['term']] >> binder) & 1), 'SUBSTITUTION_CAPTURE')
    return tasks


def _tag(nodes, identifier, tag):
    return 0 < identifier < len(nodes) and nodes[identifier][0] == tag


def _rule(rule, formula, ref0, ref1, aux0, aux1, line, proof, axioms, tasks, nodes, free):
    node = nodes[formula]
    if rule == 0:
        _need(aux0 < len(axioms) and formula == axioms[aux0], 'AXIOM_INSTANCE')
    elif rule == 1:
        _need(ref0 < line and ref1 < line, 'MP_STRICT_PRIOR_REFERENCES')
        a, implication = proof[ref0]['formula'], proof[ref1]['formula']
        _need(_tag(nodes, implication, 6) and nodes[implication][2] == a
              and nodes[implication][3] == formula, 'MP_FORMULA_INCIDENCE')
    elif rule == 2:
        _need(ref0 < line and node[0] == 7
              and node[2] == proof[ref0]['formula'], 'GEN_INSTANCE')
    elif rule == 3:
        _need(aux0 < len(tasks) and node[0] == 6 and _tag(nodes, node[2], 7), 'UI_SHAPE_OR_TASK')
        universal, task = nodes[node[2]], tasks[aux0]
        _need(task['source'] == universal[2] and task['variable'] == universal[1]
              and task['result'] == node[3], 'UI_SUBSTITUTION_BINDING')
    elif rule == 4:
        _need(node[0] == 4 and node[2] == node[3], 'REFL_INSTANCE')
    elif rule == 5:
        _need(node[0] == 6 and _tag(nodes, node[2], 7) and _tag(nodes, node[3], 6), 'DIST_OUTER_SHAPE')
        universal, right = nodes[node[2]], nodes[node[3]]
        _need(_tag(nodes, universal[2], 6) and _tag(nodes, right[3], 7), 'DIST_INNER_SHAPE')
        implication, last = nodes[universal[2]], nodes[right[3]]
        _need(right[2] == implication[2] and last[1] == universal[1]
              and last[2] == implication[3] and not ((free[implication[2]] >> universal[1]) & 1), 'DIST_INCIDENCE_OR_FREE_VARIABLE')
    elif rule == 6:
        _need(aux0 < len(tasks) and aux1 < len(tasks) and node[0] == 6
              and _tag(nodes, node[2], 4) and _tag(nodes, node[3], 6), 'EQSUB_SHAPE_OR_TASKS')
        equality, implication = nodes[node[2]], nodes[node[3]]
        first, second = tasks[aux0], tasks[aux1]
        _need(first['source'] == second['source'] and first['variable'] == second['variable']
              and first['term'] == equality[2] and second['term'] == equality[3]
              and first['result'] == implication[2] and second['result'] == implication[3], 'EQSUB_SUBSTITUTION_INCIDENCE')
    elif rule == 7:
        _need(node[0] == 6 and _tag(nodes, node[3], 6)
              and nodes[node[3]][3] == node[2], 'AX1_INSTANCE')
    elif rule == 8:
        _need(node[0] == 6 and _tag(nodes, node[2], 6) and _tag(nodes, node[3], 6), 'AX2_OUTER_SHAPE')
        left, right = nodes[node[2]], nodes[node[3]]
        _need(_tag(nodes, left[3], 6) and _tag(nodes, right[2], 6)
              and _tag(nodes, right[3], 6), 'AX2_INNER_SHAPE')
        bc, ab, ac = nodes[left[3]], nodes[right[2]], nodes[right[3]]
        _need(ab[2] == left[2] == ac[2] and ab[3] == bc[2]
              and ac[3] == bc[3], 'AX2_FORMULA_INCIDENCE')
    elif rule == 9:
        _need(node[0] == 6 and _tag(nodes, node[2], 6) and _tag(nodes, node[3], 6), 'AX3_OUTER_SHAPE')
        left, right = nodes[node[2]], nodes[node[3]]
        _need(_tag(nodes, left[2], 5) and _tag(nodes, left[3], 5)
              and nodes[left[3]][2] == right[2] and nodes[left[2]][2] == right[3], 'AX3_NEGATION_INCIDENCE')
    else:
        _need(rule == 10 and node[0] == 5 and _tag(nodes, node[2], 10), 'BOT_FALSE_INSTANCE')


def check(bounds, certificate):
    """Return a receipt; no proof search, alpha-renaming or external admission."""
    stage, index = 'bounds', None
    try:
        limits = _bounds(bounds)
        stage = 'certificate'
        _fields(certificate, ('functions', 'predicates', 'nodes', 'axioms', 'goal', 'proof', 'substitutions'), 'CERTIFICATE_FIELDS')
        stage = 'syntax'
        nodes, sorts, free, used_counts = _syntax(limits, certificate)
        stage = 'closed_Gamma'
        axioms = certificate['axioms']
        _need(type(axioms) is list and len(axioms) == limits['axioms'], 'AXIOM_COUNT')
        for index, axiom in enumerate(axioms):
            _sort(axiom, 'FORMULA', sorts); _need(free[axiom] == 0, 'OPEN_ASSUMPTION')
        _sort(certificate['goal'], 'FORMULA', sorts)
        stage, index = 'substitutions', None
        tasks = _tasks(limits, certificate, nodes, sorts, free, used_counts)
        stage = 'proof'
        proof = certificate['proof']
        _need(type(proof) is list and len(proof) == limits['lines'], 'PROOF_LENGTH')
        ref_width = max(1, (limits['lines'] - 1).bit_length())
        aux_width = max(1, (max(limits['axioms'], limits['substitutions'], 1) - 1).bit_length())
        counts = {name: 0 for name in RULES}
        for index, record in enumerate(proof):
            _fields(record, ('rule', 'formula', 'ref0', 'ref1', 'aux0', 'aux1'), 'PROOF_RECORD_FIELDS')
            _word(record['rule'], 4, 'RULE_WORD')
            _need(record['rule'] < len(RULES), 'UNLISTED_RULE')
            _sort(record['formula'], 'FORMULA', sorts)
            for key in ('ref0', 'ref1'):
                _word(record[key], ref_width, 'REFERENCE_WORD')
            for key in ('aux0', 'aux1'):
                _word(record[key], aux_width, 'AUXILIARY_WORD')
            _rule(record['rule'], record['formula'], record['ref0'], record['ref1'],
                  record['aux0'], record['aux1'], index, proof, axioms, tasks, nodes, free)
            counts[RULES[record['rule']]] += 1
        _need(proof[-1]['formula'] == certificate['goal'], 'FINAL_GOAL')
        return {'schema': 'NK-raw-FOL-check-receipt-v1', 'status': 'VERIFIED',
                'reason': 'WHOLE_BOUNDED_RAW_AST_DERIVATION', 'version': VERSION,
                'bounds': limits, 'certificate_sha256': _hash(certificate),
                'checked_nodes': len(nodes), 'checked_lines': len(proof),
                'checked_substitutions': len(tasks), 'closed_Gamma': True,
                'goal': certificate['goal'], 'rule_counts': counts,
                'node_sorts': sorts,
                'free_variable_vectors': [[(mask >> variable) & 1 for variable in range(limits['variables'])] for mask in free],
                'scope': 'Derivation from exactly the supplied closed Gamma under raw Hilbert rules0..10. Every syntax node and substitution task checked. No external logical-zero catalogue, proof search, infinite tiling or unbounded completeness claim.'}
    except _Failure as failure:
        return {'schema': 'NK-raw-FOL-check-receipt-v1', 'status': failure.status,
                'reason': failure.reason, 'version': VERSION, 'stage': stage, 'index': index}
