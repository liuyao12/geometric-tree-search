# Independent proof-reuse audit API, Source-only version 1

Status: Source implementation and AST parsing only. No compressor, scientific module, native checker, encoder, evaluator or proof search was imported/executed. No scientific proof contents or DP/control packets were read while authoring this checker. Only the compressor's packet ABI, rule-reference field declarations and metadata contracts were inspected. Current backend/depth studies are unchanged.

## Entry point

```python
verify(original_statement, actual_proof, compression_packet, *,
       provenance_binding=None, native_receipt_bindings=None,
       max_items=100000000, max_work=100000000, wall_seconds=30.0)
```

The module is `reference/proof_reuse_checker_v1.py`. Inputs are native JSON values. `original_statement` has exactly the keys `theory` and `goal`; the original proof is nonempty. The accepted success packet schema is `Exact-earlier-fact-proof-DAG-reuse-v1` with `status='COMPRESSED_UNVERIFIED'`. Unsupported/malformed packets are rejected, while upstream compression UNKNOWN and resource limits remain UNKNOWN. No file is read by this API.

Serialization and hashing use cooperative accounting: the prior input scan charges native JSON items/string sizes, with additional algorithm checkpoints and wall gates after mapping hashes, provenance joins and native-receipt hashes. A final gate follows all success-path hashing/joins before VERIFIED can be constructed. This is not exact CPU-instruction accounting or preemption inside a JSON/hash operation; an operation may finish after the deadline, in which case the following gate returns UNKNOWN.

The checker independently derives exact formula-byte classes, their earliest original indices, every original/remapped dependency, the complete backward closure from the earliest representative of the original final goal, all retained source lines, and every line/reference map. Only native proof-reference fields may change: `mp` uses `antecedent`/`implication`, and `generalize` uses `source`. Both original and remapped references must be strict earlier native integers; bool/float indices are refused. Other copied fields, including formula ASTs, axiom names and schema payloads, must match literally. There is no alpha-renaming, term rewriting, conjunction normalization, selected easier subgoal or new proof search.

It audits all packet mapping arrays, per-line formula hashes, retained-reference mappings and integer counts. The compressor's nonnegative finite `metrics.seconds` is metadata only. AST container/sort shape is checked, but native signature arities, rule truth, substitution hygiene and generalization side conditions remain obligations of the independent native logical checker.

## Distinct gates

The receipt contains:

- `mapping`: VERIFIED only for the exact deterministic reuse/closure/copying contract. This is not a logical proof-validity receipt.
- `provenance`: `NOT_SUPPLIED` or `VERIFIED_CONTENT_BINDING`. Contradictory bindings reject; resource/unverified source outcomes remain UNKNOWN.
- `native_receipt_interfaces`: `NOT_SUPPLIED`, `BOUND_VERIFIED_RECEIPTS`, REJECTED or UNKNOWN. These are wrappers around externally executed native checks, not new native checks.
- `logical_validity='NOT_RUN_BY_THIS_MODULE'` and `artifact_byte_custody='CALLER_OWNED'` always.

A top-level VERIFIED with bindings omitted claims **mapping correctness only**. Missing source/native bindings are never silently filled. A supplied external rejected or unknown native receipt prevents top-level VERIFIED while retaining the mapping result when already established. Callers must inspect all gates and perform their own complete admission; a boolean status alone is insufficient.

Both full proofs must independently pass the unchanged native B checker under exactly the same original assumption context \(\Gamma\) and goal. Earlier-fact reuse is conditional on those validity checks. This codec does not prove that the original searched derivation is sound, that receipts were truly executed, that the compression is globally optimal, or that fewer lines indicate a new theorem/GCTS/RL/search advantage. Compressed line count is not original proof-tree height, placement count, frontier generation or a newly searched proof.

## Optional actual-search provenance interface

Supply exactly:

```python
provenance_binding = {
    'source_raw': exact_original_raw_or_declared_content_projection,
    'source_native_check': exact_source_native_check_payload,
    'source_graph_check': exact_source_graph_check_payload,
    'original_compiled': exact_original_compiled_payload,
    'artifact_refs': {
        'source_raw': {'path': '...', 'bytes': 123, 'sha256': '...'},
        'source_native_check': {'path': '...', 'bytes': 123, 'sha256': '...'},
        'source_graph_check': {'path': '...', 'bytes': 123, 'sha256': '...'},
        'original_compiled': {'path': '...', 'bytes': 123, 'sha256': '...',
                              'pointer': '/compiled'},
    },
}
```

Extra artifact labels are allowed. Extra binding payload keys are refused. Artifact paths/pins are interface metadata only: **the caller must read and hash each stored artifact, verify its byte count/SHA, resolve every JSON pointer, and bind the supplied payload to those bytes**. The checker performs no filesystem access and cannot authenticate a caller-authored receipt or pin assertion. A declared lightweight content projection must be independently joined to the exact original file by the caller; a public `reader_projection` is explicitly refused as original search evidence.

Content checks require an actual `Z-growing-point-search-result-v1` SAT result, no DP/control source kind/mode, a complete VERIFIED graph receipt with the matching model hash, original native/tree receipts and the exact searched selected-CID-to-decoded-proof/goal correspondence. The supplied compiled theory/goal must exactly equal `original_statement`. If raw observations are supplied, their count must match the graph receipt and full emitted-event count. These joins do not replay the graph checker or authenticate historical execution.

The compression packet's provenance must explicitly contain a nonempty noncontrol `mode` in addition to `source_kind='POINT_SEARCH'`, `search_status='SAT'`, `native_status='VERIFIED'`, `control_proof_used=False` and the exact original proof hash. If it includes `source_run_id`, that ID must match the source raw record. This audit requires an explicit mode even though the producer's minimal input check permits its omission. No DP/control proof may be passed in place of a point-search derivation.

## Optional native receipt-interface bindings

After actually running native B on both complete proofs, supply:

```python
native_receipt_bindings = {
    'original': {
        'statement_sha256': canonical_statement_sha,
        'proof_sha256': canonical_original_proof_sha,
        'receipt': original_native_B_receipt,
    },
    'compressed': {
        'statement_sha256': canonical_statement_sha,
        'proof_sha256': canonical_compressed_proof_sha,
        'receipt': compressed_native_B_receipt,
    },
}
```

Canonical hashes are SHA256 of sorted-key, compact, ASCII JSON plus one LF, with nonfinite numbers forbidden. A VERIFIED native wrapper must carry the actual native receipt's `checked_lines` equal to the full proof length. Both context digests must match the unchanged statement; the compressed proof is not checked under a weakened, enriched or substituted theory. UNKNOWN/REJECTED external statuses are retained rather than promoted. A hash-bound JSON receipt is still not evidence that its checker ran: the caller's execution/source/byte-custody records supply that separate gate.

## Prospective qualification plan

Freeze Source/runtime and exact point-search inputs before use. Do not read or substitute conventional-control proofs. Test the codec with declarative synthetic proof packets for reference/representation behavior, clearly labeling them as mapping fixtures rather than independently valid mathematical proofs. Then use the actual pinned point-search derivations only after their original graph/native receipts and bytes are admitted. Neither their expected compressed length nor an alternate proof is hardcoded here.

Mutate the earliest representative, a representative map to a later duplicate, one original/compressed reference (including bool/float/forward forms), dependency closure, retained source line/formula/axiom payload, copied goal/theory, count/hash, line mapping, unused/duplicate metadata, provenance mode/status/source proof, selected CID join and native wrapper input digests. Coherently rehash packet fields where appropriate. The mapping/content audit must reject semantic map changes rather than relying only on stale hashes. Also deliberately cap items/work/time and retain UNKNOWN. A correct mapping over an invalid derivation may pass the mapping gate; native B must independently reject that derivation, demonstrating the intended trust boundary.

Keep every original derivation, compression packet, mapping receipt, both native receipts and every failed/resource-limited attempt separately. This Source-only stage establishes no compressed result or backend capacity improvement.
