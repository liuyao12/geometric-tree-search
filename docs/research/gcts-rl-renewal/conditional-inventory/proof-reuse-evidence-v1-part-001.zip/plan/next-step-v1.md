# Exact fact reuse and a node-bound resource variant

Status: prospective Source only. No compressor, encoder, checker, compiler, evaluator or proof search has been executed. No DP or conventional-control proof has been read. Current published originals and the arithmetic backend join are unchanged.

## Proof data flow

Call `source/proof_dag_v1.py::compress(original_statement, actual_proof, provenance=...)` on the complete actual point-search derivation. The provenance record requires `source_kind="POINT_SEARCH"`, `search_status="SAT"`, `native_status="VERIFIED"`, `control_proof_used=false`, and the exact `original_proof_sha256`; source references and their correspondence require separate admission. The routine reads no files and imports no logical checker.

It chooses the earliest line with each exactly identical formula AST, remaps later references to that fact, and retains only the backwards dependency slice of the original final formula. It preserves the complete original proof, every formula representative, original-to-compressed and compressed-to-original mappings, and all reference remaps. There is no alpha-renaming, conjunction/disjunction normalization, proof search or imported lemma. Counts are derived when the future frozen experiment runs; no expected compressed length is hardcoded.

Conditional correctness is ordinary earlier-fact reuse. If the original derivation is valid under the same fixed assumption context \(\Gamma\), each substituted earlier fact has literally the same formula. Its new reference remains earlier because the representative is no later than the original referenced line. Induction over retained representative lines establishes the same derived formulas. The backwards slice ends at the original goal. This is a human metatheoretic argument, not an independent validity receipt: both original and compressed proofs must be checked by the unchanged native B checker, and mapping/provenance needs a separate audit.

This represents reuse of an inventory of already established facts. It establishes no distinctive GCTS/RL novelty or search advantage. The compressed DAG line count is not the original searched tree height, placement count, frontier generation or evidence of a newly found proof.

## Witness-sized encoding

Call `source/witness_size_v1.py::prepare_minimal(original_compiled, compression_packet, probe_nodes=128, substitutions=4)`. This invokes only the unchanged data encoder. Signature and variable-pool data come from the whole original compiled basis and zero schemas; the original statement remains authoritative. It probes the complete compressed proof, not a selected easier subgoal.

The chosen row count retains the entire problem prefix, every nonpadding syntax row, all syntax-child references, axioms, goal and proof formulas, every substitution source/term/result, active source index and map target. Only unused trailing `VAR0` padding may disappear. The bound is one plus the largest retained node ID, at least two. It is minimal for that stable-ID representation, not an optimal encoding theorem. The fresh problem and complete proof are then re-encoded; numeric proof/signature fields, prefix, syntax rows and truncated task arrays must match the probe exactly.

This is explicitly witness-sized backend certification after examining a supplied searched proof. It is not a proof-search bound selected prospectively, held-out evidence, an enumeration of proofs, or a replacement for the prior original-proof certificates. A line count above the unchanged sixteen-line cap, more than four substitution tasks, a node requirement above 128, or another unchanged resource refusal remains `UNKNOWN`. No smaller target, DP derivation or alternate proof is substituted.

## Resource-only compiler/checker extension

`source/resource_kernel_v1.py::compile_kernel(bounds,pins)` has the existing tuple ABI. Its private compiler bundle changes only `CAPS.nodes` from 64 to 128 in the v1 implementation; lazy v2 and the two-million-gate v3 Sources are byte exact. The separate `reference/raw_fol_checker_n128_v1.py` changes only that node cap and its receipt version. All logical functions are to be compared structurally with their preserved originals before execution.

The fixed100 palette, data encoder, inverse decoder, native B checker and ribbon checker are unchanged pinned copies. All other bounds and the two-million NAND gate cap remain unchanged. The larger syntax table may still exceed that gate cap; such a refusal is a result, not permission to narrow the proof or silently raise another cap.

Future admission should freeze all Sources and actual point-proof inputs, independently verify both native proofs and every mapping, verify fresh raw records and common-statement/bit round trips, then compile/evaluate and certify ribbons under declared process/certificate limits. Preserve every original and every failed/resource-limited attempt. No geometric tiling, primitive Wang proof search, new theorem or gain has yet been demonstrated by this Source preparation.
