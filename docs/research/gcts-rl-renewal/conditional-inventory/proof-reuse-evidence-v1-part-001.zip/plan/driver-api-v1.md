# Prospective execution API: exact proof reuse and backend join

This is Source only. The driver has not been imported or executed. No compressor, encoder, compiler, checker, evaluator or search has run in this authoring phase. Current publication and original evidence remain unchanged. Root must review these new files before freezing and authorizing any execution.

The entry point is `source/run_dag_reuse_v1.py`. All paths derive from its sibling run directory. Reviewed `proof_dag_v1.py`, `witness_size_v1.py`, `resource_kernel_v1.py`, independent reuse checker and snapshotted dependencies remain unchanged.

## Phase schedule

Use the pinned Python executable consistently, with isolated mode, site loading disabled and bytecode writing disabled. The previously admitted runtime is Python `3.12.14`, executable SHA256 `0048df8bc66cbf4cc964f31eb89321e762902aeecf95dfbde306a36601d27034`; the new freeze records and checks its exact path, bytes and version:

```sh
GCTS_DAG_PY='/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12'
"$GCTS_DAG_PY" -I -S -B source/run_dag_reuse_v1.py freeze
"$GCTS_DAG_PY" -I -S -B source/run_dag_reuse_v1.py run qualify-arithmetic
"$GCTS_DAG_PY" -I -S -B source/run_dag_reuse_v1.py run reuse-incidence
"$GCTS_DAG_PY" -I -S -B source/run_dag_reuse_v1.py run backend-arithmetic
"$GCTS_DAG_PY" -I -S -B source/run_dag_reuse_v1.py run backend-incidence
```

These commands are a prospective API, not a record of execution. The supervisor starts its child with the same explicit `-I -S -B` flags, so `PYTHONPATH`, user-site packages and `sitecustomize` cannot change scientific imports. No phase is automatically started by another phase. The two backend phases require admitted reuse for their respective cases; incidence reuse requires arithmetic qualification. Root should inspect actual phase artifacts and observer receipts before proceeding. A refusal must not be followed by changing the selected proof, narrowing the target or raising caps without a new prospectively frozen version.

1. **Freeze.** This byte-only command checks the declared dependency pins, final reuse-checker pin, exact eight-file MARKS input snapshot and reviewed master reference. It snapshots the master if absent, then pins all files in `source`, `reference`, `plan` and `input`, plus `review/input-snapshot-v1.json`. It freezes the exact Python executable bytes, version and platform, phase schedule, native/codec limits and process/backend caps into `data/protocol-frozen-v1.json`. It imports no scientific module. The expected master pin is explicit; a changed master requires renewed review, rather than silently accepting it.
2. **Qualify on genuine arithmetic.** Consume only the already pinned arithmetic MARKS search result, prepared compiled context, full graph receipt and native receipt. Save the one raw compression packet before executing assurance. Save original and compressed proofs separately. Run unchanged native B separately on both under exactly the original \(\Gamma\) and goal; then run the independent mapping checker with complete source-content and native-receipt bindings. This is the arithmetic reuse result itself, not a throwaway fixture. Never label a synthetic non-search proof `POINT_SEARCH`.
3. **Bounded corruption controls.** Derive every mutant from that saved genuine packet. The planned controls change the earliest duplicate representative, retained formula with refreshed compressed-proof hash, forward and Boolean references with refreshed hashes, retained original index, count, original statement with refreshed statement hash, control-mode provenance, selected-CID join, native-wrapper proof digest and an explicit UNKNOWN native wrapper. A `max_work=1` mapping refusal must remain UNKNOWN. Save each complete mutant/override specification before its check, and each receipt before comparison. No new compression or repeated baseline logical check is performed for these controls. The fixed corpus must actually contain a duplicate and a dependency reference; otherwise qualification stops without inventing one.
4. **Incidence reuse.** Apply the same source/native/mapping gates to the second genuine pinned MARKS witness. Compress it once. No DP or conventional-control proof is read, selected or substituted. Its retained line count is derived at execution, not predicted in this plan.
5. **Backend, separately per case.** Read the already admitted exact compression packet and its pinned artifacts. The data-only sizer probes the complete compressed proof at the declared node ceiling, then freshly re-encodes the unchanged problem and whole proof at the derived stable-ID bound. Save that packet even when UNKNOWN. Check its raw certificate independently with the node128 checker. Compile under the unchanged NAND gate cap; save the circuit and metadata before encoding. Save bits, independent inverse receipt, decoded-native B receipt and explicit common-statement/line roundtrip. Only then construct and independently check the fixed-palette ribbon. Save symbolic and literal outcomes separately; an honest literal UNKNOWN is allowed beside a verified compressed backend join.

## Artifact and admission ABI

Actual source provenance comes from `input/arithmetic-*` or `input/incidence-*` only. `source_case` hashes each stored file against `review/input-snapshot-v1.json`, resolves `/compiled` itself, and passes full saved payloads to the independent mapping checker. The provenance claim records actual `MARKS` mode, raw run ID, SAT status, original native status and exact proof hash. The checker additionally joins selected CIDs, goal, original theory, complete observations and graph model hash. This is a newly checked content/custody join of inherited graph evidence; the old point search and graph checker are not rerun.

The independent reuse call is:

```python
N.verify(statement, actual_proof, compression_packet,
         provenance_binding=full_saved_payload_binding,
         native_receipt_bindings=actual_two_native_B_receipts,
         max_items=100000000, max_work=100000000, wall_seconds=30.0)
```

Admission requires all of: original native B VERIFIED; compressed native B VERIFIED; mapping VERIFIED; provenance `VERIFIED_CONTENT_BINDING`; native interfaces `BOUND_VERIFIED_RECEIPTS`; overall mapping receipt VERIFIED. Top-level mapping success alone is insufficient. UNKNOWN gates remain explicit and prevent admission.

The principal files are:

- `data/reuse/<case>/compression.json.gz`, original/compressed proof files, both native B receipts, native-receipt bindings, mapping/provenance check and `result.json`.
- `data/qualification/<control>-input.json.gz` and corresponding check; `data/qualification-result-v1.json` binds the actual arithmetic reuse result and all control outcomes.
- `data/backend/<case>/witness-size.json.gz`, `raw-128-check.json`, `circuit.json.gz`, `encoded-bits.json.gz`, `inverse-check.json.gz`, `decoded-native-B.json`, `common-statement-check.json`, palette, evaluated gate bits, ribbon and its symbolic/literal receipts, then `result.json`.
- Per-phase exclusive started record, native log, worker invocation receipt and independent process-observer receipt under `data`/`review`.

All artifact refs are path, byte count and SHA256; saved refs are rechecked before consuming them. JSON is compact ASCII with one LF; canonical content hashes use that representation. Gzip uses empty filename and fixed zero modification time. All writes are exclusive. A started, interrupted, failed or partially persisted phase cannot be silently restarted by this driver. A separately reviewed recovery version would have to preserve originals, account for lost work and specify exactly which unfinished stages it may execute.

## Fixed resources and accounting

The whole-proof profile preserves the existing non-node limits: at most sixteen proof lines, eight variables, sixteen functions/predicates/axioms, four substitution tasks and arity four. Only the node ceiling is extended to \(128\). Sizing removes only an unused trailing VAR0 padding suffix while retaining every problem-prefix row, all nonpadding rows, children and all referenced substitution-map targets. It does not renumber the AST DAG or claim globally minimal syntax.

The compiler retains its hard \(2{,}000{,}000\) NAND-gate cap. Additional prospective construction guards are at most \(20{,}000\) inputs, \(2{,}000{,}000\) ribbon rows and \(10^{13}\) nominal cells. These limits are declared before execution; the nominal grid size is not expanded or searched work. There is no call to a primitive Wang point model or a tile search. Fixed-palette construction evaluates the NAND circuit a second time internally; metrics explicitly count two evaluations rather than disguising the cost as one.

Each `run` owns one child process and records its native exit. The child enforces a \(900\)-second CPU limit. The parent polls RSS every quarter second and terminates that owned process group above \(2\) GiB RSS or \(1{,}200\) seconds wall time; an unavailable RSS observer also stops the run. RSS polling is not an instantaneous hard memory bound. Parent and child check frozen Source/runtime/master/input bytes; exceptions and terminations remain recorded, without changing scientific UNKNOWN into rejection or nonprovability. Stage persistence and inline assurance belong to observed pipeline cost; guard observation is outside the child. The high-water RSS receipt labels platform units explicitly.

## Interpretation

Original searched proofs and compressed proofs are distinct evidence. Exact earlier-fact reuse plus backward slicing concerns a proof DAG under one fixed assumption context. A reduction in line count is not a reduction in original tree height, frontier generation, point placements or original search cost, and is not a new theorem or a GCTS/RL contribution by itself.

The raw backend independently decodes the original statement with explicit `and`/`or` notation expansion. Its receipt must bind normalized formulas, rule payloads, references and complete bits to the compressed native proof, while retaining the exact original statement hash. A Wang row here is NAND checker computation; one mathematical proof line may require many such rows. The final circuit/ribbon is constructed after search. A failed whole-incidence encoding remains a result; the driver must not replace it with an easier arithmetic/Horn theorem or a conventional proof.

This prospective run makes no new proof-search, held-out, learned-policy, full Peano arithmetic, full Hilbert geometry, universal first-order compiler or physical-tiling acceleration claim.
