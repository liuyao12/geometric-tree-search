"""Passive report projection of admitted saved DAG-reuse results.

Only stdlib data/HTML processing. No scientific Source import, proof search,
proof transformation, native check, encoder, circuit evaluation or grid expansion.
Large saved gate/row arrays are streamed, retaining selected display samples.
"""
import argparse
import gzip
import hashlib
import html
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parents[1]


def canonical(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       separators=(',', ':'), allow_nan=False)+'\n').encode('ascii')


def pin(path):
    h, count = hashlib.sha256(), 0
    with path.open('rb') as source:
        for chunk in iter(lambda: source.read(1048576), b''):
            count += len(chunk)
            h.update(chunk)
    return dict(bytes=count, sha256=h.hexdigest())


def is_ref(value):
    return isinstance(value, dict) and {'path', 'bytes', 'sha256'} <= set(value)


def references(value):
    if is_ref(value):
        yield value
    elif isinstance(value, dict):
        for child in value.values():
            yield from references(child)
    elif isinstance(value, list):
        for child in value:
            yield from references(child)


def ref_path(root, ref):
    path = (root/ref['path']).resolve()
    if not path.is_relative_to(root) or pin(path) != {k: ref[k] for k in ('bytes', 'sha256')}:
        raise ValueError('Unbound saved artifact: '+str(ref['path']))
    return path


def load_ref(root, ref):
    path = ref_path(root, ref)
    with (gzip.open(path, 'rt', encoding='ascii') if path.suffix == '.gz'
          else path.open(encoding='ascii')) as stream:
        value = json.load(stream)
    for part in ref.get('pointer', '').split('/')[1:]:
        key = part.replace('~1', '/').replace('~0', '~')
        value = value[int(key)] if isinstance(value, list) else value[key]
    return value


class StreamJSON:
    """Data-only selective JSON reader; complete arrays counted, not retained."""
    def __init__(self, stream):
        self.stream, self.buffer, self.pos, self.eof = stream, '', 0, False
        self.decoder = json.JSONDecoder()

    def more(self):
        self.buffer = self.buffer[self.pos:]
        self.pos = 0
        part = self.stream.read(65536)
        self.buffer += part
        self.eof = not part

    def space(self):
        while True:
            while self.pos < len(self.buffer) and self.buffer[self.pos].isspace():
                self.pos += 1
            if self.pos < len(self.buffer) or self.eof:
                return
            self.more()

    def expect(self, char):
        self.space()
        if self.buffer[self.pos:self.pos+1] != char:
            raise ValueError('Saved JSON delimiter: '+char)
        self.pos += 1

    def value(self):
        self.space()
        while True:
            try:
                value, end = self.decoder.raw_decode(self.buffer, self.pos)
                # A number at a chunk boundary may not yet be complete.
                if end == len(self.buffer) and not self.eof:
                    self.more()
                    continue
                self.pos = end
                return value
            except json.JSONDecodeError:
                if self.eof:
                    raise
                self.more()
                if len(self.buffer) > 134217728:
                    raise ValueError('Passive scalar/metadata value exceeds display parser cap')

    def object(self, handlers):
        self.expect('{')
        result = {}
        self.space()
        if self.buffer[self.pos:self.pos+1] == '}':
            self.pos += 1
            return result
        while True:
            key = self.value()
            if not isinstance(key, str):
                raise ValueError('Saved JSON object key')
            self.expect(':')
            result[key] = handlers[key](self) if key in handlers else self.value()
            self.space()
            char = self.buffer[self.pos:self.pos+1]
            self.pos += 1
            if char == '}':
                return result
            if char != ',':
                raise ValueError('Saved JSON object separator')

    def sparse(self, wanted):
        self.expect('[')
        rows, index = {}, 0
        self.space()
        if self.buffer[self.pos:self.pos+1] == ']':
            self.pos += 1
            return dict(count=0, selected=rows)
        while True:
            value = self.value()
            if index in wanted:
                rows[index] = value
            index += 1
            self.space()
            char = self.buffer[self.pos:self.pos+1]
            self.pos += 1
            if char == ']':
                return dict(count=index, selected=rows)
            if char != ',':
                raise ValueError('Saved JSON array separator')


def stream_packet(root, ref, handlers):
    path = ref_path(root, ref)
    with (gzip.open(path, 'rt', encoding='ascii') if path.suffix == '.gz'
          else path.open(encoding='ascii')) as stream:
        reader = StreamJSON(stream)
        value = reader.object(handlers)
        reader.space()
        if reader.buffer[reader.pos:] or not reader.eof:
            raise ValueError('Trailing saved JSON data')
        return value


def receipt(root, value):
    return load_ref(root, value) if is_ref(value) else value


def tile_samples(root, backend):
    """Decode sparse stored active IDs/CROSS intervals; never evaluate NAND."""
    if backend.get('status') != 'VERIFIED_COMPRESSED_BACKEND_JOIN':
        return dict(status='NOT_AVAILABLE', reason='No admitted compressed backend join.')
    refs = backend.get('artifacts', {})
    required = ('circuit', 'ribbon', 'palette')
    if not all(is_ref(refs.get(key)) for key in required):
        return dict(status='NOT_AVAILABLE', reason='Required saved display artifacts absent.')
    metrics = backend.get('metrics') or {}
    count = metrics.get('nand_gates')
    if not isinstance(count, int) or count < 1:
        return dict(status='NOT_AVAILABLE', reason='No recorded positive gate count.')
    symbolic = receipt(root, refs['symbolic']) if is_ref(refs.get('symbolic')) else backend.get('checks', {}).get('symbolic')
    if not isinstance(symbolic, dict) or symbolic.get('status') != 'VERIFIED':
        return dict(status='NOT_AVAILABLE', reason='Saved symbolic certificate check is not VERIFIED.')
    ys = sorted({0, count//2, count-1})
    cp = stream_packet(root, refs['circuit'], {
        'circuit': lambda p: p.object({'gates': lambda q: q.sparse(set(ys))})})
    circuit = cp['circuit']
    if circuit['gates']['count'] != count:
        raise ValueError('Saved gate count differs from backend metrics')
    inputs = len(circuit['inputs'])
    width = inputs+count
    windows = {}
    gate_bits_needed = set(ys)
    for y in ys:
        a, b = circuit['gates']['selected'][y]
        starts = sorted({max(0, min(width-12, min(a, b)-2)),
                         max(0, min(width-12, max(a, b)-2)),
                         max(0, min(width-12, inputs+y-5))})
        windows[y] = [(start, min(width, start+12)) for start in starts]
        for start, end in windows[y]:
            gate_bits_needed.update(x-inputs for x in range(start, end)
                                    if inputs <= x < inputs+y)
    row_ids = set(ys) | {y+1 for y in ys if y+1 < count}
    rp = stream_packet(root, refs['ribbon'], {'certificate': lambda p: p.object({
        'rows': lambda q: q.sparse(row_ids),
        'gate_bits': lambda q: q.sparse(gate_bits_needed)})})
    cert = rp['certificate']
    if cert['rows']['count'] != count or cert['gate_bits']['count'] != count:
        raise ValueError('Saved ribbon census differs from gate count')
    palette = load_ref(root, refs['palette'])
    tiles = {t['id']: t for t in palette['tiles']}
    if len(tiles) != 100 or set(tiles) != set(range(100)):
        raise ValueError('Saved fixed-palette display inventory is not 100 types')
    rows = []
    for y in ys:
        row = cert['rows']['selected'][y]
        active = dict(row['active'])
        following = dict(cert['rows']['selected'][y+1]['active']) if y+1 < count else {}
        views = []
        for start, end in windows[y]:
            cells = []
            for x in range(start, end):
                if x in active:
                    tid, origin = active[x], dict(kind='STORED_ACTIVE_ID', gate_row=y, column=x)
                else:
                    matches = [band for band in row['ribbons'] if band[0] <= x < band[1]]
                    if len(matches) != 1:
                        raise ValueError('Displayed column lacks a unique saved ribbon')
                    lo, hi, bus = matches[0]
                    north = cert['input_bits'][x] if x < inputs else cert['gate_bits']['selected'][x-inputs] if x-inputs < y else 0
                    next_op = tiles[following[x]]['N'][0] if x in following else 'CROSS'
                    ids = [t['id'] for t in palette['tiles'] if
                           t['N'] == ['CROSS', north] and t['S'] == [next_op, north]
                           and t['W'] == t['E'] == bus]
                    if len(ids) != 1:
                        raise ValueError('Displayed CROSS record does not decode uniquely')
                    tid, origin = ids[0], dict(kind='STORED_CROSS_INTERVAL', gate_row=y,
                        column=x, interval=[lo, hi, bus])
                cells.append(dict(x=x, y=y, tile=tiles[tid], origin=origin))
            views.append(dict(start=start, end=end, cells=cells))
        rows.append(dict(y=y, nand=circuit['gates']['selected'][y],
            output_wire=inputs+y, saved_output_bit=cert['gate_bits']['selected'][y],
            compressed_row=row, windows=views))
    return dict(status='SAVED_COMPRESSED_SAMPLES', palette=palette,
        palette_ref=refs['palette'], width=width, height=count, rows=rows,
        scope='Only first/midpoint/last NAND rows and up to three 12-column windows per row. IDs decode stored active records or CROSS intervals using stored bits; no circuit evaluation or new literal check. Display samples do not increase either checker expanded-cell count.')


def exclusive(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(raw)


CSS = r'''
:root{--ink:#20333c;--muted:#5d6e74;--line:#dce4e3;--paper:#f7f9f7;--teal:#216e6a;--gold:#a76b27;--violet:#785393;--blue:#407dae;--red:#a34b4b}*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;background:var(--paper);color:var(--ink);font:16px/1.65 system-ui,sans-serif}a{color:#216d84;text-underline-offset:3px}header{background:#183d42;color:white;padding:48px max(24px,calc((100vw - 1200px)/2)) 30px}header a{color:#c1e6df}.eyebrow{letter-spacing:.15em;text-transform:uppercase;font-size:12px;color:#acd3cd}h1{font-family:Georgia,serif;font-size:clamp(32px,5vw,52px);line-height:1.12;max-width:900px;margin:15px 0}h2{font:30px/1.2 Georgia,serif;margin:0 0 15px}h3{font:21px/1.3 Georgia,serif;margin:22px 0 10px}p{margin:10px 0}.lede{max-width:900px;font-size:18px;color:#dce9e5}nav{display:flex;gap:20px;flex-wrap:wrap;margin-top:22px;font-size:14px}main{max-width:1250px;padding:30px 24px 70px;margin:auto}section{padding:27px;background:#fff;border:1px solid var(--line);border-radius:14px;margin-bottom:24px}label{font-size:13px;color:var(--muted);display:inline-flex;flex-direction:column;gap:5px;margin:0 14px 12px 0}select,button{font:inherit;color:var(--ink);border:1px solid #b7c9c7;background:white;border-radius:7px;padding:8px 12px}button{cursor:pointer}button:hover,button.active{border-color:var(--teal);background:#e9f3ee}.note{font-size:14px;color:var(--muted)}.callout{border-left:4px solid var(--teal);background:#eef5f1;padding:14px 18px}.warning{border-color:var(--gold);background:#faf3e8}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:12px}.metric{border:1px solid var(--line);padding:15px;border-radius:9px}.metric strong{font:30px Georgia,serif;display:block}.metric span{font-size:13px;color:var(--muted)}.scroll{overflow-x:auto}.formula-scroll{max-width:100%;overflow-x:auto;padding:3px 0}.badge{display:inline-block;border-radius:5px;background:#e9efed;padding:2px 7px;font:12px/1.5 ui-monospace,monospace;overflow-wrap:anywhere}.badge.ok{background:#dfeee5;color:#275d42}.badge.unknown{background:#f8ead3;color:#815c20}table{width:100%;border-collapse:collapse;font-size:14px}td,th{border-bottom:1px solid var(--line);text-align:left;vertical-align:top;padding:11px 9px}th{font-weight:600;color:#45616b;background:#f5f8f7}code,pre{font:12px/1.5 ui-monospace,monospace}code{overflow-wrap:anywhere}pre{white-space:pre-wrap;background:#f3f6f5;padding:14px;border-radius:8px;max-height:440px;overflow:auto}.proof-table{table-layout:fixed}.proof-table th:nth-child(1){width:5%}.proof-table th:nth-child(2){width:43%}.proof-table th:nth-child(3){width:31%}.proof-table th:nth-child(4){width:21%}.proof-table td:nth-child(2){overflow:hidden}.proof-table tr.chosen{background:#edf5f0}.mini{font-size:12px;color:var(--muted)}.twocol{display:grid;grid-template-columns:1fr 1fr;gap:25px}.diagram{min-width:560px;width:100%;display:block}.legend{display:flex;gap:14px;flex-wrap:wrap;font-size:12px;margin:12px 0}.dot{width:10px;height:10px;border-radius:50%;display:inline-block;margin-right:5px}.fact-card{border:1px solid var(--line);border-top:4px solid var(--teal);padding:12px;border-radius:8px}.fact-card button{text-align:left;width:100%;border:0;padding:0;background:none}.fact-card .formula-scroll{font-size:13px}.tiles{display:flex;gap:5px;min-width:max-content;padding:15px 3px}.wang{position:relative;width:76px;height:76px;flex-shrink:0;border:1px solid #5b747d;border-radius:0;background:#fff;cursor:pointer;padding:0}.wang .edge{position:absolute;display:flex;font:8px/10px ui-monospace,monospace;color:#fff;text-shadow:0 1px 1px #234}.wang .north,.wang .south{left:0;right:0;height:13px}.wang .north{top:0}.wang .south{bottom:0}.wang .part{flex:1;overflow:hidden}.wang .west,.wang .east{top:13px;bottom:13px;width:11px;align-items:center;justify-content:center}.wang .west{left:0}.wang .east{right:0}.wang .center{position:absolute;inset:17px 12px;font-size:10px;line-height:18px;display:flex;flex-direction:column;align-items:center;justify-content:center}.wang .center b{font-size:9px}.palette{display:grid;grid-template-columns:repeat(auto-fill,76px);gap:8px}.family-label{display:inline-block;color:var(--teal);font-size:12px;font-weight:600;text-transform:uppercase;letter-spacing:.06em}details{margin:12px 0}summary{cursor:pointer;color:#36656c}footer{font-size:13px;color:var(--muted);padding:10px 0}.error{color:var(--red)}@media(max-width:780px){main{padding:15px 10px}section{padding:18px 12px}.twocol{grid-template-columns:1fr}.proof-table{min-width:800px}.metric strong{font-size:25px}header{padding:35px 20px 24px}}'''

CSS += r'''body{overflow-x:clip}.twocol>*{min-width:0}.fact-card{min-width:0}.formula-scroll{overflow-y:hidden}.formula-scroll mjx-container{min-width:max-content}'''

BODY = r'''
<header><div class="eyebrow">GCTS research · exact proof reuse</div><h1>From a searched proof tree<br>to a shared inventory of facts</h1><p class="lede">Keep the original derivation. Reuse literally identical earlier facts, retain the dependencies needed for the same conclusion, and independently check the shorter proof.</p><nav><a href="#findings">Results</a><a href="#reader">Proof reader</a><a href="#inventory">Fact DAG</a><a href="#backend">Same 100-tile backend</a><a href="proof-reuse-evidence-v1.html">Evidence</a></nav></header>
<main><p id="loading" class="note">Loading admitted saved evidence…</p>
<section id="findings"><h2>What this establishes</h2><div id="headline"></div><div id="counts" class="grid"></div><p class="callout">This is automatic reuse within proofs already discovered by bounded point search. It adds no new theorem or proof search, and establishes no distinctive GCTS contribution, RL result or search-speed advantage.</p><p class="note">Arithmetic uses the addition-zero fragment without induction. Geometry here is a one-sorted symbolic incidence fragment, not full Hilbert geometry. The original proofs remain separately inspectable. Changed proof length and a witness-sized syntax bound both affect the new backend size; this experiment does not isolate compression alone as the cause.</p><div id="result-table" class="scroll"></div></section>
<section id="reader"><span class="family-label">One assumption context · one exact goal</span><h2>Inspect every line</h2><label>Proof family<select id="case"></select></label><label>Derivation<select id="view"><option value="compressed">Shared-fact proof</option><option value="original">Original searched proof</option></select></label><p id="context-scope" class="note"></p><div id="statement"></div><p id="proof-caption" class="callout"></p><div id="proof" class="scroll"></div><details><summary>Exact native proof and mapping downloads</summary><div id="literal-links"></div><pre id="exact-line"></pre></details></section>
<section id="inventory"><h2>The reusable facts in this derivation</h2><p class="note">A fact is admitted under the same original assumptions, with the exact same formula bytes. This is a shared dependency DAG, not a cross-problem lemma library or a newly learned marking. A schema instance can have no incoming proof references; its later use is an explicit modus ponens step.</p><div class="legend"><span><i class="dot" style="background:#b8833c"></i>Assumption</span><span><i class="dot" style="background:#4986b6"></i>Logical schema / instantiation</span><span><i class="dot" style="background:#2c8b79"></i>Modus ponens</span><span><i class="dot" style="background:#80529d"></i>Generalization</span></div><div class="twocol"><div><h3>Original line to retained fact</h3><div id="map" class="scroll"></div></div><div><h3>Exact dependency DAG</h3><div id="dag" class="scroll"></div><div id="selected-fact" class="callout"></div></div></div><h3>Fact inventory</h3><div id="cards" class="grid"></div></section>
<section id="backend"><h2>One fixed palette for both proof families</h2><p>The proof records are encoded after search into a bounded first-order checker and then a NAND computation. Its compressed Wang certificate uses translations of the same square tiles. A NAND row is checker computation; it is not a line of mathematical inference.</p><div id="backend-status"></div><div id="backend-metrics" class="grid"></div><div id="backend-checks" class="scroll"></div><div id="samples"><h3>Actual saved color samples</h3><label>NAND row<select id="sample-row"></select></label><label>Column window<select id="sample-window"></select></label><p id="sample-caption" class="note"></p><div id="tile-strip" class="scroll"></div><pre id="tile-detail"></pre></div><details><summary>Inspect the fixed palette of 100 square tiles</summary><p class="note">North/south display separate operation and bit layers; east/west display bit colors. Center capacity is \(t=1\). The program selectors are pinned throughout the interior, not only at the outer boundary. Rotations are not allowed.</p><label>Operation<select id="palette-op"><option value="ALL">All operations</option><option>CROSS</option><option>READ</option><option>NAND</option><option>NOT</option><option>WRITE</option></select></label><div id="palette" class="palette"></div></details><p class="callout warning">Symbolic expansion verification and literal checking are separate outcomes. Displaying a handful of certificate squares does not expand or independently verify the full grid. Nominal cell counts describe a constructed compressed certificate, not searched tile placements.</p><p class="note"><a href="backend-join-v1.html">Earlier original-proof backend join</a> · <a href="family-transfer-v1.html">Earlier bounded proof-search assessment</a></p></section>
<section id="assurance"><h2>Checks, costs and limits</h2><div id="qualification"></div><div id="costs"></div><div id="limitations"></div><details><summary>Provenance and saved-data projection</summary><pre id="provenance"></pre></details><p><a href="proof-reuse-evidence-v1.html">Open the evidence index</a> · <a download href="proof-reuse-results-v1.json.gz">Download reader projection</a></p><!-- DAG_ARCHIVE_LINK --></section><footer>Formulas and English come from the saved native proof readers. Reference explanations are remapped to the displayed shared proof; the original proof remains available byte for byte.</footer></main>'''

SCRIPT = r'''
const $=id=>document.getElementById(id),esc=x=>String(x??'Unavailable').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const text=x=>x===null||x===undefined?'Unavailable':typeof x==='object'?JSON.stringify(x):String(x),num=x=>typeof x==='number'?x.toLocaleString('en-US'):text(x),badge=x=>`<span class="badge ${String(x).includes('VERIFIED')||x==='QUALIFIED'?'ok':String(x).includes('UNKNOWN')||x==='PENDING'?'unknown':''}">${esc(text(x))}</span>`;
const formula=r=>`\\(${esc(r?.formula_latex??'\\text{Unavailable}')}\\)`,table=(heads,rows,cls='')=>`<table class="${cls}"><thead><tr>${heads.map(h=>`<th>${esc(h)}</th>`).join('')}</tr></thead><tbody>${rows.join('')}</tbody></table>`,metric=(v,l)=>`<div class="metric"><strong>${esc(num(v))}</strong><span>${esc(l)}</span></div>`;
let data,ci=0,view='compressed',selected=0,rowIndex=0,windowIndex=0,mathQueue=Promise.resolve();
function typeset(node=document.body){mathQueue=mathQueue.then(async()=>{if(window.MathJax?.startup?.promise)await MathJax.startup.promise;if(window.MathJax?.typesetPromise)await MathJax.typesetPromise([node]);});mathQueue.catch(e=>console.error(e));}
window.addEventListener('load',()=>typeset(document.body));
const current=()=>data.cases[ci],deps=line=>line.rule==='mp'?[line.antecedent,line.implication]:line.rule==='generalize'?[line.source]:[],color=rule=>rule==='axiom'?'#b8833c':rule==='mp'?'#2c8b79':rule==='generalize'?'#80529d':'#4986b6';
function chooseLine(i){selected=i;renderProof();renderInventory();let c=current(),p=view==='compressed'?c.compressed_native:c.original_native;$('exact-line').textContent=JSON.stringify({displayed_line:i+1,native:p[i],retained_original_line:view==='compressed'?c.mapping.compressed_to_original[i]+1:i+1},null,2);}
function renderProof(){let c=current(),rows=view==='compressed'?c.compressed_proof_reader:c.original_proof_reader,p=view==='compressed'?c.compressed_native:c.original_native;selected=Math.min(selected,p.length-1);$('proof-caption').textContent=view==='compressed'?`${p.length} independently checked shared-fact lines; retained original line IDs appear below. Same original theory and goal.`:`${p.length} lines of the original point-search derivation, retained without replacement.`;$('proof').innerHTML=table(['Line','Formula','English','Rule / references'],rows.map((r,i)=>`<tr class="${i===selected?'chosen':''}"><td><button data-line="${i}">${i+1}</button></td><td><div class="formula-scroll">${formula(r)}</div></td><td>${esc(r.english)}${r.reason?`<p class="mini">${esc(r.reason)}</p>`:''}</td><td><code>${esc(p[i].rule)}</code><br>${deps(p[i]).length?'Uses '+deps(p[i]).map(j=>j+1).join(', '):'No earlier-line reference'}${view==='compressed'?`<p class="mini">Original line ${c.mapping.compressed_to_original[i]+1}</p>`:''}</td></tr>`),'proof-table');document.querySelectorAll('[data-line]').forEach(b=>b.onclick=()=>chooseLine(Number(b.dataset.line)));typeset($('proof'));}
function renderInventory(){let c=current(),m=c.mapping,n=c.original_native.length,k=c.compressed_native.length,from=view==='compressed'?selected:m.original_to_compressed[selected];let selectedFact=from===null?null:from;let height=Math.max(n,k)*27+46;let pieces=[`<svg class="diagram" viewBox="0 0 560 ${height}" role="img" aria-label="Exact original-to-shared-fact mapping"><text x="20" y="18" font-size="12">Original proof</text><text x="380" y="18" font-size="12">Shared facts</text>`];for(let i=0;i<n;i++){let j=m.original_to_compressed[i],y=40+i*27,duplicate=m.original_to_representative[i]!==i;pieces.push(`<text x="20" y="${y+4}" font-size="12" fill="${j===null?'#7d8b90':'#234753'}">Line ${i+1}${duplicate?' · repeated fact':''}${j===null?' · unused for goal':''}</text>`);if(j!==null){let y2=40+j*(height-65)/Math.max(k-1,1);pieces.push(`<path d="M190 ${y} C285 ${y},290 ${y2},375 ${y2}" stroke="${j===selectedFact?'#2b8374':'#bed0ce'}" stroke-width="${i===m.compressed_to_original[j]?2:1}" fill="none" ${duplicate?'stroke-dasharray="4 3"':''}/>`);}}for(let j=0;j<k;j++){let y=40+j*(height-65)/Math.max(k-1,1);pieces.push(`<g data-fact="${j}" role="button" tabindex="0"><rect x="376" y="${y-12}" width="170" height="24" rx="5" fill="${j===selectedFact?'#d8ece2':'#edf3ef'}"/><text x="386" y="${y+4}" font-size="12">Fact ${j+1} · original ${m.compressed_to_original[j]+1}</text></g>`);}pieces.push('</svg>');$('map').innerHTML=pieces.join('');
let levels=[],positions=[],buckets={};c.compressed_native.forEach((line,i)=>{let d=deps(line);levels[i]=d.length?Math.max(...d.map(j=>levels[j]))+1:0;(buckets[levels[i]]??=[]).push(i);});let maxLevel=Math.max(...levels),dagHeight=Math.max(220,...Object.values(buckets).map(v=>v.length*66+30)),width=Math.max(560,(maxLevel+1)*145);Object.entries(buckets).forEach(([level,ids])=>ids.forEach((i,j)=>positions[i]=[65+Number(level)*(width-120)/Math.max(maxLevel,1),35+j*(dagHeight-65)/Math.max(ids.length-1,1)]));let graph=[`<svg class="diagram" viewBox="0 0 ${width} ${dagHeight}" role="img" aria-label="Native proof dependency DAG"><defs><marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M0 0L10 5L0 10Z" fill="#91a9a5"/></marker></defs>`];c.compressed_native.forEach((line,i)=>deps(line).forEach(j=>{let [x,y]=positions[j],[a,b]=positions[i];graph.push(`<path d="M${x+30} ${y} C${x+70} ${y},${a-70} ${b},${a-32} ${b}" stroke="#91a9a5" fill="none" marker-end="url(#arrow)"/>`);}));c.compressed_native.forEach((line,i)=>{let [x,y]=positions[i];graph.push(`<g data-fact="${i}" role="button" tabindex="0"><rect x="${x-32}" y="${y-19}" width="64" height="38" rx="7" fill="${color(line.rule)}" stroke="${i===selectedFact?'#183c43':'white'}" stroke-width="3"/><text x="${x}" y="${y+4}" text-anchor="middle" font-size="12" fill="white">Fact ${i+1}</text></g>`);});graph.push('</svg>');$('dag').innerHTML=graph.join('');$('selected-fact').innerHTML=selectedFact===null?'<p>This original fact is outside the backward dependency slice of the conclusion.</p>':`<b>Fact ${selectedFact+1}</b> · original line ${m.compressed_to_original[selectedFact]+1}<div class="formula-scroll">${formula(c.compressed_proof_reader[selectedFact])}</div><p class="note">${esc(c.compressed_proof_reader[selectedFact].english)}</p>`;$('cards').innerHTML=c.compressed_native.map((line,i)=>`<div class="fact-card" style="border-top-color:${color(line.rule)}"><button data-fact="${i}"><b>Fact ${i+1}</b> <span class="mini">Original ${m.compressed_to_original[i]+1}</span><div class="formula-scroll">${formula(c.compressed_proof_reader[i])}</div><span class="mini">${esc(line.rule)}${deps(line).length?' · facts '+deps(line).map(j=>j+1).join(', '):' · no earlier-line reference'}</span></button></div>`).join('');document.querySelectorAll('[data-fact]').forEach(b=>b.onclick=()=>{view='compressed';$('view').value=view;chooseLine(Number(b.dataset.fact));});typeset($('inventory'));}
const opColors={CROSS:'#667d86',READ:'#407ca6',NAND:'#99622e',NOT:'#855599',WRITE:'#2a8374'},bitColor=b=>b?'#bb5564':'#3e7caa';
function square(t,i,origin){return `<button class="wang" data-tile="${i}" aria-label="Tile ${t.id}"><span class="edge north"><span class="part" style="background:${opColors[t.N[0]]}">${esc(t.N[0])}</span><span class="part" style="background:${bitColor(t.N[1])}">${t.N[1]}</span></span><span class="edge south"><span class="part" style="background:${opColors[t.S[0]]}">${esc(t.S[0])}</span><span class="part" style="background:${bitColor(t.S[1])}">${t.S[1]}</span></span><span class="edge west" style="background:${bitColor(t.W)}">${t.W}</span><span class="edge east" style="background:${bitColor(t.E)}">${t.E}</span><span class="center"><b>ID ${t.id}</b><span>\\(t=1\\)</span></span></button>`;}
function wireSquares(container,cells){$(container).querySelectorAll('[data-tile]').forEach(b=>b.onclick=()=>{$('tile-detail').textContent=JSON.stringify(cells[Number(b.dataset.tile)],null,2);});}
function renderPalette(){let samples=current().tile_samples,tiles=samples.palette?.tiles??data.shared_palette?.tiles??[],op=$('palette-op').value;tiles=tiles.filter(t=>op==='ALL'||t.N[0]===op);$('palette').innerHTML=tiles.map((t,i)=>square(t,i)).join('');wireSquares('palette',tiles.map(t=>({tile:t,scope:'Fixed decorated type; placement by translation only.'})));typeset($('palette'));}
function renderSample(){let s=current().tile_samples,r=s.rows?.[rowIndex];if(!r)return;windowIndex=Math.min(windowIndex,r.windows.length-1);$('sample-window').innerHTML=r.windows.map((w,i)=>`<option value="${i}">Columns ${w.start}–${w.end-1}</option>`).join('');$('sample-window').value=windowIndex;let w=r.windows[windowIndex];$('tile-strip').innerHTML='<div class="tiles">'+w.cells.map((c,i)=>square(c.tile,i)).join('')+'</div>';wireSquares('tile-strip',w.cells);$('sample-caption').textContent=`Saved NAND row ${r.y}: input wires ${r.nand.join(', ')}, output wire ${r.output_wire}, stored output bit ${r.saved_output_bit}. Sample only; no new literal-grid verification.`;$('tile-detail').textContent=JSON.stringify({saved_row:r.compressed_row,selected_window:[w.start,w.end]},null,2);typeset($('tile-strip'));}
function renderBackend(){let c=current(),b=c.backend??{},m=b.metrics??{},checks=b.checks??{};$('backend-status').innerHTML=`<p>${badge(b.status??'PENDING')}${b.stopped_stage?' · stopped at '+esc(b.stopped_stage):''}</p>`;$('backend-metrics').innerHTML=metric(m.chosen_nodes,'Witness-sized syntax nodes')+metric(m.compressed_lines,'Encoded proof lines')+metric(m.nand_gates,'NAND checker rows')+metric(m.nominal_cells,'Nominal tile instances');$('backend-checks').innerHTML=table(['Saved gate','Outcome'],Object.entries(checks).map(([k,v])=>`<tr><td><code>${esc(k)}</code></td><td>${badge(v?.status??v)}</td></tr>`));let s=c.tile_samples;$('samples').hidden=s.status!=='SAVED_COMPRESSED_SAMPLES';if(!$('samples').hidden){rowIndex=windowIndex=0;$('sample-row').innerHTML=s.rows.map((r,i)=>`<option value="${i}">NAND row ${num(r.y)}</option>`).join('');renderSample();}else $('tile-detail').textContent=s.reason;renderPalette();}
function selectCase(){let c=current(),th=c.theory_reader;selected=0;$('context-scope').textContent=th?.scope??'The unchanged original assumption context and conclusion.';$('statement').innerHTML=th?table(['Hypothesis','Formula','English'],(th.hypotheses??[]).map(r=>`<tr><td><code>${esc(r.name)}</code></td><td><div class="formula-scroll">${formula(r)}</div></td><td>${esc(r.english)}</td></tr>`))+`<h3>Same original conclusion</h3><div class="formula-scroll">${formula(th.conclusion)}</div><p>${esc(th.conclusion?.english)}</p>`:'<p class="note">No saved human statement reader was supplied; exact original statement remains in the compression download.</p>';$('literal-links').innerHTML=['original_proof','compressed_proof','compression'].map(key=>`<p><a download href="${esc(c.downloads[key])}">${esc(key.replaceAll('_',' '))}</a></p>`).join('');chooseLine(0);renderBackend();typeset($('statement'));}
function renderSummary(){let rs=data.cases;$('headline').innerHTML=rs.map(c=>`<p><b>${esc(c.label??c.id)}</b>: ${num(c.original_native.length)} original lines to ${num(c.compressed_native.length)} shared-fact lines. ${badge(c.reuse.status)}; backend ${badge(c.backend?.status??'PENDING')}.</p>`).join('');$('counts').innerHTML=rs.map(c=>metric(`${c.original_native.length} to ${c.compressed_native.length}`,c.label??c.id)).join('');$('result-table').innerHTML=table(['Proof family','Original / reused','Native proofs','Mapping / provenance','Symbolic / literal'],rs.map(c=>{let g=c.reuse.gates??{},ch=c.backend.checks??{};return `<tr><td>${esc(c.label??c.id)}</td><td>${c.original_native.length} / ${c.compressed_native.length}</td><td>${badge(g.original_native)} ${badge(g.compressed_native)}</td><td>${badge(g.mapping)}<br>${badge(g.provenance)}</td><td>${badge(ch.symbolic?.status??c.backend.metrics?.symbolic_status??'PENDING')}<br>${badge(ch.literal?.status??c.backend.metrics?.literal_status??'PENDING')}</td></tr>`;}));let q=data.qualification;$('qualification').innerHTML=`<h3>Qualification</h3><p>${badge(q?.status??'Unavailable')}</p>`+(q?.controls?table(['Saved corruption / refusal control','Expected','Recorded'],q.controls.map(r=>`<tr><td>${esc(r.id)}</td><td>${badge(r.expected)}</td><td>${badge(r.actual)}</td></tr>`)):'');$('costs').innerHTML='<h3>Observed costs</h3><pre>'+esc(JSON.stringify(data.costs,null,2))+'</pre><p class="note">These are post-search reuse, encoding, construction and assurance costs. They do not measure proof-search improvement. Earlier search/acquisition costs are separate inherited evidence.</p>';$('limitations').innerHTML='<h3>Scope</h3><ul>'+data.limitations.map(l=>`<li>${esc(text(l))}</li>`).join('')+'</ul>';$('provenance').textContent=JSON.stringify({summary_pin:data.input_summary_pin,provenance:data.provenance,projection:data.reader_projection},null,2);}
async function load(){let response=await fetch('proof-reuse-results-v1.json.gz',{cache:'no-store'});if(!response.ok)throw Error('Reader data HTTP '+response.status);let bytes=new Uint8Array(await response.arrayBuffer());let body=bytes[0]===31&&bytes[1]===139?await new Response(new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'))).text():new TextDecoder().decode(bytes);data=JSON.parse(body);$('loading').remove();$('case').innerHTML=data.cases.map((c,i)=>`<option value="${i}">${esc(c.label??c.id)}</option>`).join('');$('case').onchange=()=>{ci=Number($('case').value);selectCase();};$('view').onchange=()=>{view=$('view').value;chooseLine(0);};$('sample-row').onchange=()=>{rowIndex=Number($('sample-row').value);windowIndex=0;renderSample();};$('sample-window').onchange=()=>{windowIndex=Number($('sample-window').value);renderSample();};$('palette-op').onchange=renderPalette;renderSummary();selectCase();typeset();}load().catch(e=>{$('loading').className='error';$('loading').textContent='Could not load admitted evidence: '+e.message;console.error(e);});
'''


def page(title, body, script=''):
    return ('<!doctype html><html lang="en"><head><meta charset="utf-8">'
        '<meta name="viewport" content="width=device-width, initial-scale=1"><title>'+html.escape(title)+'</title><style>'+CSS+'</style>'
        '<script>window.MathJax={tex:{inlineMath:[["\\\\(","\\\\)"]],displayMath:[["\\\\[","\\\\]"]]},options:{skipHtmlTags:["script","noscript","style","textarea","pre","code"]}};</script>'
        '<script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-svg.js"></script></head><body>'+body+
        ('<script>'+script+'</script>' if script else '')+'</body></html>')


def build(root):
    root = root.resolve()
    summary_path = root/'data/report-summary-v1.json'
    summary = json.loads(summary_path.read_bytes())
    allowed_statuses = {'VERIFIED_POSTSEARCH_REUSE_AND_BACKEND_JOINS', 'EXECUTED_WITH_UNKNOWN_OR_PENDING_PHASES'}
    if summary.get('schema') != 'DAG-reuse-saved-summary-v1' or summary.get('status') not in allowed_statuses:
        raise ValueError('Expected the admitted DAG reuse saved-data summary')
    audit = load_ref(root, summary['saved_data_audit'])
    if audit.get('status') != 'PASS_SAVED_DATA_AUDIT' or audit.get('scientific_summary_status') != summary['status']:
        raise ValueError('Saved-data audit does not admit this summary status')
    out = root/'report'
    downloads_dir = out/'dag-downloads-v1'
    downloads_dir.mkdir(parents=True, exist_ok=True)
    downloads, copied = [], {}
    for ref in references(summary):
        if not str(ref['path']).startswith(('data/', 'input/', 'review/')):
            continue
        path = ref_path(root, ref)
        key = (ref['bytes'], ref['sha256'])
        name = ref['sha256'][:16]+'-'+path.name
        target = downloads_dir/name
        if key not in copied:
            if target.exists():
                if pin(target) != pin(path):
                    raise ValueError('Existing download mismatch')
            else:
                with target.open('xb') as destination, path.open('rb') as source:
                    shutil.copyfileobj(source, destination, 1048576)
            copied[key] = 'dag-downloads-v1/'+name
            downloads.append(dict(original=ref['path'], download=copied[key], **pin(path)))
    view = dict(schema='Passive-exact-proof-DAG-reader-v1', status=summary['status'],
        input_summary_pin=pin(summary_path), cases=[], qualification=summary.get('qualification'),
        costs=summary.get('costs'), provenance=summary.get('provenance'),
        limitations=summary.get('limitations', []), downloads=downloads,
        reader_projection=dict(scope='Saved proofs/readers/mapping arrays with sparse stored Wang certificate samples. No proof transformation, search, native check, encoder, NAND evaluation or whole-grid expansion is run by this builder.',
            original_evidence='Complete pinned raw/compiled/proof/backend artifacts remain downloadable and in the evidence archive. Reader samples are a display projection, not replacement certificates.'))
    for case in summary['cases']:
        packet = load_ref(root, case['compression'])
        original, compressed = load_ref(root, case['original_proof']), load_ref(root, case['compressed_proof'])
        if original != packet['original_proof'] or compressed != packet['compressed_proof']:
            raise ValueError('Saved proof/packet display mismatch')
        if len(case['original_proof_reader']) != len(original) or len(case['compressed_proof_reader']) != len(compressed):
            raise ValueError('Saved reader line counts mismatch')
        backend = dict(case.get('backend') or dict(status='PENDING'))
        backend['checks'] = {key: receipt(root, value) for key, value in (backend.get('checks') or {}).items()}
        item = dict(id=case['id'], label=case.get('label', case['id']),
            statement_sha256=case.get('statement_sha256'), theory_reader=case.get('theory_reader'),
            original_native=original, compressed_native=compressed,
            original_proof_reader=case['original_proof_reader'], compressed_proof_reader=case['compressed_proof_reader'],
            mapping={key: packet[key] for key in ('original_to_representative', 'original_to_compressed',
                'compressed_to_original', 'line_mapping', 'retained_reference_mapping')},
            reuse=case['reuse'], backend=backend, tile_samples=tile_samples(root, backend),
            downloads={key: copied[(case[key]['bytes'], case[key]['sha256'])]
                       for key in ('original_proof', 'compressed_proof', 'compression')})
        view['cases'].append(item)
    palettes = [case['tile_samples']['palette'] for case in view['cases']
                if case['tile_samples']['status'] == 'SAVED_COMPRESSED_SAMPLES']
    if palettes and not all(p == palettes[0] for p in palettes):
        raise ValueError('Saved proof-family palettes differ; cannot claim one fixed palette')
    if palettes:
        view['shared_palette'] = palettes[0]
        view['reader_projection']['same_saved_palette_across_available_samples'] = True
    exclusive(out/'proof-reuse-results-v1.json.gz', gzip.compress(canonical(view), compresslevel=6, mtime=0))
    exclusive(out/'proof-reuse-v1.html', page('Exact shared-fact proof reuse · GCTS research', BODY, SCRIPT).encode())
    rows = ''.join('<tr><td><code>'+html.escape(d['original'])+'</code></td><td><a download href="'+
        html.escape(d['download'], quote=True)+'">Download</a></td><td>'+str(d['bytes'])+'</td><td><code>'+d['sha256']+'</code></td></tr>' for d in downloads)
    evidence = '<header><div class="eyebrow">Saved evidence</div><h1>Proof reuse and backend joins</h1><nav><a href="proof-reuse-v1.html">Return to proof reader</a></nav></header><main><section><h2>Complete saved artifacts</h2><p>Original and compressed proofs, mapping/native receipts and backend artifacts are distinct. The reader does not replace them. No new search or checking is performed by this evidence index.</p><!-- DAG_ARCHIVE_LINK --><p><a download href="proof-reuse-results-v1.json.gz">Reader projection</a></p><div class="scroll"><table><thead><tr><th>Saved path</th><th>Artifact</th><th>Bytes</th><th>SHA256</th></tr></thead><tbody>'+rows+'</tbody></table></div></section><section><h2>Summary provenance</h2><pre>'+html.escape(json.dumps(dict(summary_pin=view['input_summary_pin'],status=view['status'],projection=view['reader_projection']),indent=2))+'</pre></section></main>'
    exclusive(out/'proof-reuse-evidence-v1.html', page('Evidence · exact proof reuse', evidence).encode())
    return dict(status='PASSIVE_REPORT_WRITTEN', cases=len(view['cases']), downloads=len(downloads),
        outputs={name: pin(out/name) for name in ('proof-reuse-v1.html','proof-reuse-evidence-v1.html','proof-reuse-results-v1.json.gz')})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=ROOT)
    args = parser.parse_args()
    print(json.dumps(build(args.root), sort_keys=True))


if __name__ == '__main__':
    main()
