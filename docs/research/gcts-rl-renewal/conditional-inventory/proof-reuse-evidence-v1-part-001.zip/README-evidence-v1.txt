Exact proof-DAG reuse and both compressed Wang backend joins, 2026-11-03.

Download EVERY proof-reuse-evidence-v1-part-NNN.zip and the external
proof-reuse-evidence-manifest-v1.json. Each volume is a separate valid ZIP,
at most forty-four MiB. Extract all volumes into one empty directory. Each has
the identical ARCHIVE-file-manifest-v1.json; identical copies may overwrite.
Every original task path is physically stored exactly once, without aliases or
deduplication. The manifest binds every original path/byte count/SHA256 and every
volume's completed bytes/hash. Publication verifies every original and every CRC.

All original NEXT task files at the archive cut are physically kept: Sources,
original point-search inputs and proof readers, original and compressed proofs,
reuse maps, native/provenance checks, raw/circuit/ribbon certificates, all twelve
qualification controls and honest UNKNOWNs, protocol, logs, reviews and viewer
assets. No duplicate-path aliases or reconstruction instructions replace bytes.
Publication Python Sources are physically included. Generated package outputs
and publication planning/deployment receipts are excluded to avoid recursion.
Deployment receipts created after this cut remain local custody evidence. Full task archive
and local paths are explicitly approved for the existing public destination.

Serve the extracted directory with python3 -m http.server and open
report/proof-reuse-v1.html. Scientific code is inert data for the reader.
The previously searched arithmetic and symbolic-incidence proofs are retained
alongside exact-earlier-fact reuse and backward slicing. Each compressed proof
is independently native-checked under its unchanged original theory and goal,
then joined through witness-sized raw syntax, inverse/statement binding, NAND
acceptance and the same fixed 100-type Wang palette. These are post-search
backend certificates, not new proof discovery or primitive grid proof search.
Both literal resource refusals remain UNKNOWN; symbolic checks expand no cells.
Both proof length and node bound changed, so compression alone is not isolated.
No new theorem, search-speed benefit, distinctive GCTS/RL advantage, complete
PA/Hilbert geometry, universal primitive Wang proof search or plane result is
established. The research program remains ACTIVE.
