"""Close only this publication milestone; keep the research program ACTIVE.

Receipt/data reads and exact local copying only. No solver/checker execution,
network call, Git staging or push. Run after observer, live bytes and UI finish.
"""
import argparse
import json
from pathlib import Path
import shutil
import sys
from urllib.parse import urlsplit
sys.path.insert(0,str(Path(__file__).resolve().parent))
from evidence_common_v1 import ROOT,PREFIX,BASE_URL,MANIFEST,MAX_PART,READINESS,PHASES,wire,pin,local,inventory_from_manifest,verify_protocol
MIRROR=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-proof-dag-reuse-20261103-v1')
RESERVED={'publication/live-complete-v1.json','publication/mirror-inventory-v1.json'}
def load(name):return json.loads(local(ROOT,name).read_text())
def exact(path,expected):assert wire(pin(path))==wire({k:expected[k] for k in ('bytes','sha256')}),str(path)
def owned(path,raw):
    path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists():assert path.is_file() and path.read_bytes()==raw,'Preserve different receipt '+str(path)
    else:
        with path.open('xb') as f:f.write(raw)
def ui(name,commit,live):
    u=load(name);assert u['status']=='PASS' and u['math_errors']==0 and u['body_overflow'] is False and u['console']==[]
    if 'source' in u:exact(local(ROOT,u['source']['path']),u['source'])
    if 'commit' in u:assert u['commit']==commit
    if live:
        assert u['commit']==commit;p=urlsplit(u['url'])
        assert p.scheme=='https' and p.netloc=='liuyao12.github.io' and p.path=='/geometric-tree-search/'+PREFIX+'proof-reuse-v1.html'
    return u
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--local-ui',default='review/local-ui-qualification-v1.json');ap.add_argument('--live-ui',default='publication/live-ui-v1.json');args=ap.parse_args()
    prepared=load('publication/prepared-v1.json');commit=prepared['commit'];assert prepared['status']=='PREPARED_TASK_ASSETS_ONLY' and not prepared['primary_checkout_staged']
    c=load('publication/remote-commit-v1.json');ref=load('publication/remote-main-v1.json');compare=load('publication/remote-compare-v1.json');pages=load('publication/pages-deployment-v1.json')
    assert c['sha']==ref['object']['sha']==commit and c['tree']['sha']==prepared['tree'] and [p['sha'] for p in c['parents']]==[prepared['base']]
    assert compare['status']=='PASS' and compare['commit']==commit and compare['tree']==prepared['tree'] and compare['parent']==prepared['base']
    assets={a['path']:a for a in prepared['assets']};assert len(assets)==len(prepared['assets'])
    changes=[line.split('\t') for line in prepared['diff'].splitlines()]
    assert {path for status,path in changes}==set(assets) and all(status==('M' if path==PREFIX+'backend-join-v1.html' else 'A') for status,path in changes)
    assert len(compare['files'])==len(assets) and {f['filename'] for f in compare['files']}==set(assets)
    statuses={name:'modified' if status=='M' else 'added' for status,name in changes};assert all(f['status']==statuses[f['filename']] for f in compare['files'])
    assert pages['head_sha']==commit and pages['head_branch']=='main' and pages['repository']['full_name']=='liuyao12/geometric-tree-search'
    assert pages['name']=='pages build and deployment' and pages['status']=='completed' and pages['conclusion']=='success'
    local_ui=ui(args.local_ui,commit,False);live_ui=ui(args.live_ui,commit,True)
    live=load('publication/live-byte-check-v1.json');assert live['status']=='PASS' and live['commit']==commit and live['normal_TLS'] is True
    observed={e['path']:e for e in live['assets']};assert len(observed)==len(live['assets'])==len(assets) and set(observed)==set(assets)
    bodies=ROOT/'publication/live-bodies-v1'
    for name,a in assets.items():
        e=observed[name];assert e['match'] is True and e['curl_exit']==0 and e['normal_TLS'] is True
        assert a['url']==e['url']==BASE_URL+name and name.startswith(PREFIX)
        assert e['bytes']==e['expected_bytes']==a['bytes'] and e['sha256']==e['expected_sha256']==a['sha256']
        exact(local(ROOT,a['local']),a);exact(local(bodies,name[len(PREFIX):]),a)
    manifest=load('package/'+MANIFEST);inventory_from_manifest(manifest)
    assert wire(manifest)==wire(json.loads((bodies/MANIFEST).read_text()))
    for proof in (load('package/archive-verification-v1.json'),live['archive']):
        assert proof['status']=='PASS' and proof['original_files']==manifest['original_files']
        assert proof['all_original_files_physically_stored'] is True and proof['all_original_paths_byte_verified'] is True and proof['all_CRC_verified'] is True
        assert len(proof['parts'])==len(manifest['parts']) and len(proof['parts'])>=1
        for a,b in zip(proof['parts'],manifest['parts']):
            assert all(a[k]==b[k] for k in ('number','name','bytes','sha256')) and a['CRC']=='PASS'
            assert b['bytes']<=MAX_PART;exact(ROOT/'package'/b['name'],b)
    for e in manifest['files']:exact(local(ROOT,e['path']),e)
    summary=load('data/report-summary-v1.json');saved=load('review/saved-data-audit-v1.json')
    assert summary['schema']=='DAG-reuse-saved-summary-v1' and summary['status']=='VERIFIED_POSTSEARCH_REUSE_AND_BACKEND_JOINS' and saved['status']=='PASS_SAVED_DATA_AUDIT'
    exact(local(ROOT,manifest['summary']['path']),manifest['summary'])
    assert manifest['summary']['schema']==summary['schema']
    readiness={e['path']:e for e in manifest['readiness_receipts']}
    assert set(READINESS)<=set(readiness)
    assert load('review/root-source-admission-v1.json')['status']=='PASS'
    for name,expected in readiness.items():
        exact(local(ROOT,name),expected);receipt=load(name)
        assert receipt['status']==expected['status'] and receipt['status'].startswith(('PASS','VERIFIED','COMPLETE','ADMITTED'))
    protocols=[]
    for expected in manifest['protocols']:
        exact(local(ROOT,expected['path']),expected)
        observed_protocol=verify_protocol(expected['path'],expected['context_root'])
        assert wire(observed_protocol)==wire(expected)
        protocols.append(dict(context_root=expected['context_root'],phases=expected['phases'],source_pin_count=expected['source_pin_count']))
    assert len(protocols)==1 and protocols[0]['context_root']=='' and [p['phase'] for p in protocols[0]['phases']]==list(PHASES)
    # Existing primary files, including the earlier plan, are preserved unless
    # byte-identical. Preflight all collisions before creating any new copy.
    assert not MIRROR.is_symlink() and MIRROR.resolve()!=ROOT.resolve();files=[]
    for source in sorted(ROOT.rglob('*')):
        assert not source.is_symlink(),'Mirror refuses symlink'
        if not source.is_file():continue
        name=source.relative_to(ROOT).as_posix()
        if name in RESERVED:continue
        expected=pin(source);target=local(MIRROR,name);assert not target.is_symlink()
        if target.exists():assert target.is_file();exact(target,expected)
        files.append(dict(path=name,**expected))
    for i,e in enumerate(files,1):
        source=local(ROOT,e['path']);target=local(MIRROR,e['path']);exact(source,e)
        if not target.exists():
            target.parent.mkdir(parents=True,exist_ok=True)
            with source.open('rb') as incoming,target.open('xb') as outgoing:shutil.copyfileobj(incoming,outgoing,1048576)
        exact(target,e)
        if i%128==0 or i==len(files):print(json.dumps(dict(phase='MIRROR_BYTE_CHECK',checked=i,total=len(files))),flush=True)
    inventory=dict(schema='DAG-completed-mirror-v1',status='EXACT_TASK_FILES_VERIFIED',source_root=str(ROOT),mirror_root=str(MIRROR),commit=commit,files=files,generated_receipts_not_self_hashed=sorted(RESERVED))
    receipt=dict(status='PUBLISHED_LIVE_VERIFIED',study_status=summary['status'],commit=commit,parent=prepared['base'],tree=prepared['tree'],pages_run=pages['id'],reader_url=live_ui['url'],evidence_url=BASE_URL+PREFIX+'proof-reuse-evidence-v1.html',normal_TLS_assets_byte_verified=len(assets),archive=dict(original_files=manifest['original_files'],all_originals_physical=True,all_CRC_and_bytes_verified=True,parts=manifest['parts']),local_UI_status=local_ui['status'],live_UI_status=live_ui['status'],protocols=protocols,saved_data_audit=saved['status'],root_source_admission=readiness['review/root-source-admission-v1.json'],summary=summary,primary_mirror=str(MIRROR),mirror_files_verified_before_generated_receipts=len(files),primary_checkout_staged=False,program_goal_status='ACTIVE',scope='Exact earlier-fact reuse of two previously searched proofs with original derivations retained; both compressed proofs joined to the same fixed 100-type Wang palette by independent native/mapping/raw/inverse/NAND/symbolic checks. Post-search witness certification is not new proof discovery or primitive grid search; both literal checks remain UNKNOWN. Both proof length and syntax bound changed. No new theorem, search-speed gain, distinctive GCTS/RL advantage, full PA/Hilbert formalization, universal primitive Wang proof search or plane result.')
    outputs={'publication/mirror-inventory-v1.json':wire(inventory),'publication/live-complete-v1.json':wire(receipt)}
    for name,raw in outputs.items():
        for root in (ROOT,MIRROR):
            p=local(root,name)
            if p.exists():assert p.read_bytes()==raw,'Preserve different prior completion receipt'
    for name,raw in outputs.items():
        for root in (ROOT,MIRROR):owned(local(root,name),raw)
    print(json.dumps(dict(status=receipt['status'],commit=commit,assets=len(assets),original_files=manifest['original_files'],mirror_files=len(files),program_goal_status='ACTIVE')))
if __name__=='__main__':main()
