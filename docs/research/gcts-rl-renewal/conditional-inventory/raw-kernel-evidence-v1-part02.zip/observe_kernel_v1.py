"""One supervised kernel experiment; explicit terminal receipt, no retry."""
import hashlib
import json
from pathlib import Path
import resource
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parent
PYTHON='/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12'


def pin(path):
    data=Path(path).read_bytes();return {'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}


def main():
    mode=sys.argv[1];assert mode in ('qualify','research')
    folder=ROOT/('observation-'+mode+'-v1');folder.mkdir()
    source=ROOT/'source/run_kernel_study_v1.py'
    record={'schema':'NK-native-observation-v1','mode':mode,'source':pin(source),'runtime':pin(PYTHON),
            'argv':[PYTHON,'-I','-S','-B',str(source),mode],'max_wall_seconds':300,'retry':False,'start_unix':time.time()}
    (folder/'before.json').write_text(json.dumps(record,indent=2)+'\n')
    start=time.perf_counter()
    with (folder/'stdout.txt').open('xb') as out,(folder/'stderr.txt').open('xb') as err:
        process=subprocess.Popen(record['argv'],cwd=ROOT,stdout=out,stderr=err)
        print(json.dumps({'mode':mode,'pid':process.pid,'status':'RUNNING'}),flush=True)
        while process.poll() is None and time.perf_counter()-start<300:time.sleep(.1)
        record['terminated_on_wall_limit']=process.poll() is None
        if process.poll() is None:
            process.terminate()
            try:process.wait(timeout=5)
            except subprocess.TimeoutExpired:process.kill();process.wait()
        record.update({'native_exit':process.returncode,'elapsed_seconds':time.perf_counter()-start,
                       'peak_child_rss':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,'platform':sys.platform,
                       'source_after':pin(source),'runtime_after':pin(PYTHON)})
    record.update({'stdout':pin(folder/'stdout.txt'),'stderr':pin(folder/'stderr.txt')})
    (folder/'completion.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps({'mode':mode,'native_exit':record['native_exit'],'seconds':record['elapsed_seconds'],
                      'peak_child_rss':record['peak_child_rss']}),flush=True)
    raise SystemExit(process.returncode or 0)


if __name__=='__main__':main()
