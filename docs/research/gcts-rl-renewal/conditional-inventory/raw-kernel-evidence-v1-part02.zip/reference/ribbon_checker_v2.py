"""Independent fixed-100 Wang ribbon and literal certificate checkers.

Inert stdlib-only Source. No constructor, subject helper, SAT/proof solver,
sampling, IO or search is imported. Ribbons preserve the vertical BIT; their
full south color may change its op selector according to the bound program.
"""
import hashlib
import json

VERSION = 'FP-INDEPENDENT-RIBBON-CHECKER-v2-NK'
OPS = ('CROSS', 'READ', 'NAND', 'NOT', 'WRITE')
MAX_INPUTS, MAX_GATES, MAX_WIDTH = 1000000, 1000000, 2000000
MAX_NAME_UNITS, MAX_LITERAL_CELLS = 16777216, 50000


class _Failure(Exception):
    def __init__(self, status, reason):
        self.status, self.reason = status, reason


def _need(condition, reason):
    if not condition:
        raise _Failure('REJECTED', reason)


def _limit(condition, reason):
    if not condition:
        raise _Failure('UNKNOWN', reason)


def _fields(value, names, reason):
    _need(type(value) is dict and all(type(k) is str for k in value)
          and set(value) == set(names), reason)


def _integer(value, lo, hi):
    return type(value) is int and lo <= value <= hi


def _bit(value):
    return type(value) is int and value in (0, 1)


def _digest(value):
    encoder = json.JSONEncoder(sort_keys=True, ensure_ascii=True,
                               separators=(',', ':'), allow_nan=False)
    result = hashlib.sha256()
    for chunk in encoder.iterencode(value):
        result.update(chunk.encode('ascii'))
    result.update(b'\n')
    return result.hexdigest()


def _tile(identifier):
    group, next_index = divmod(identifier, 5)
    op_index, pair = divmod(group, 4)
    north, west = divmod(pair, 2)
    op, following = OPS[op_index], OPS[next_index]
    if op == 'CROSS':
        east, south = west, north
    elif op == 'READ':
        east, south = north, north
    elif op == 'NAND':
        east, south = 1 - north * west, north
    elif op == 'NOT':
        east, south = 1 - north, north
    else:
        east, south = west, west
    return {'id': identifier, 'N': [op, north], 'S': [following, south],
            'W': west, 'E': east}


def _palette(palette):
    _fields(palette, ('schema', 'tiles'), 'PALETTE_FIELDS')
    _need(type(palette['schema']) is str and palette['schema'] == 'FP-fixed-Wang-palette-v1', 'PALETTE_SCHEMA')
    tiles = palette['tiles']
    _need(type(tiles) is list and len(tiles) == 100, 'PALETTE_SIZE')
    for i, tile in enumerate(tiles):
        _fields(tile, ('id', 'N', 'S', 'W', 'E'), 'TILE_FIELDS')
        _need(type(tile['id']) is int and tile['id'] == i, 'TILE_ID_ORDER')
        for side in ('N', 'S'):
            pair = tile[side]
            _need(type(pair) is list and len(pair) == 2
                  and type(pair[0]) is str and pair[0] in OPS and _bit(pair[1]), 'VERTICAL_COLOR_TYPE')
        _need(_bit(tile['W']) and _bit(tile['E']), 'BUS_COLOR_TYPE')
        _need(tile == _tile(i), 'EXACT_100_TILE_TABLE')
    # Exhaust the entire CROSS table: 2 north bits x 2 bus bits x 5 next ops.
    # N=(CROSS,n), S=(next,n), W=E=bus. This is bit transport, not N=S.
    for north in (0, 1):
        for bus in (0, 1):
            for next_index, following in enumerate(OPS):
                tile = tiles[5 * (2 * north + bus) + next_index]
                _need(tile['N'] == ['CROSS', north] and tile['S'] == [following, north]
                      and tile['W'] == bus and tile['E'] == bus, 'EXHAUSTIVE_CROSS_TRANSPORT_LEMMA')
    return tiles


def _circuit(circuit):
    _fields(circuit, ('schema', 'inputs', 'gates', 'output'), 'CIRCUIT_FIELDS')
    _need(type(circuit['schema']) is str and circuit['schema'] == 'FP-NAND-circuit-v1', 'CIRCUIT_SCHEMA')
    inputs, gates = circuit['inputs'], circuit['gates']
    _need(type(inputs) is list and type(gates) is list, 'CIRCUIT_ARRAYS')
    _limit(len(inputs) <= MAX_INPUTS and len(gates) <= MAX_GATES, 'CIRCUIT_RESOURCE_BOUND')
    count, height = len(inputs), len(gates)
    width = count + height
    _need(count >= 2, 'FIXED_CONSTANT_INPUTS_REQUIRED')
    _limit(width <= MAX_WIDTH, 'WIDTH_RESOURCE_BOUND')
    values, names = [], 0
    for item in inputs:
        _fields(item, ('name', 'value'), 'INPUT_FIELDS')
        _need(type(item['name']) is str, 'INPUT_NAME_TYPE')
        names += len(item['name'])
        _limit(names <= MAX_NAME_UNITS, 'INPUT_NAME_RESOURCE_BOUND')
        value = item['value']
        _need(value is None or _bit(value), 'INPUT_VALUE_TYPE')
        values.append(value)
    _need(type(values[0]) is int and values[0] == 0
          and type(values[1]) is int and values[1] == 1, 'FIXED_ZERO_ONE_INPUTS')
    program = []
    for y, gate in enumerate(gates):
        destination = count + y
        _need(type(gate) is list and len(gate) == 2
              and all(_integer(arg, 0, destination - 1) for arg in gate), 'STRICT_FORWARD_NAND_GATE')
        program.append((gate[0], gate[1]))
    _need(_integer(circuit['output'], 0, width - 1), 'OUTPUT_INDEX')
    return tuple(values), tuple(program), circuit['output'], width, height


def _roles(gate, destination):
    a, b = gate
    if a == b:
        return ((a, 'NOT'), (destination, 'WRITE'))
    return ((min(a, b), 'READ'), (max(a, b), 'NAND'), (destination, 'WRITE'))


def _op(roles, x):
    for point, role in roles:
        if point == x:
            return role
    return 'CROSS'


def _vertical(x, row, inputs, gates):
    # The known bit stream above row; below row y is this same law at y+1.
    # Only destination len(inputs)+y can change between these two streams.
    if x < len(inputs):
        return inputs[x]
    gate = x - len(inputs)
    return gates[gate] if gate < row else 0


def _certificate(circuit, certificate, palette):
    _fields(certificate, ('schema', 'circuit_sha256', 'palette_sha256', 'input_bits', 'gate_bits', 'rows'), 'CERTIFICATE_FIELDS')
    _need(type(certificate['schema']) is str and certificate['schema'] == 'FP-ribbon-certificate-v1', 'CERTIFICATE_SCHEMA')
    tiles = _palette(palette)
    constants, program, output, width, height = _circuit(circuit)
    circuit_sha, palette_sha = _digest(circuit), _digest(palette)
    _need(type(certificate['circuit_sha256']) is str and certificate['circuit_sha256'] == circuit_sha, 'CIRCUIT_HASH_BINDING')
    _need(type(certificate['palette_sha256']) is str and certificate['palette_sha256'] == palette_sha, 'PALETTE_HASH_BINDING')
    inputs, gates, rows = certificate['input_bits'], certificate['gate_bits'], certificate['rows']
    _need(type(inputs) is list and len(inputs) == len(constants) and all(_bit(v) for v in inputs), 'INPUT_BIT_VECTOR')
    _need(type(gates) is list and len(gates) == height and all(_bit(v) for v in gates), 'GATE_BIT_VECTOR')
    _need(type(rows) is list and len(rows) == height, 'ROW_COUNT')
    _need(all(fixed is None or fixed == chosen for fixed, chosen in zip(constants, inputs)), 'TOP_INPUT_BOUNDARY')
    _need(_vertical(output, height, inputs, gates) == 1, 'BOTTOM_OUTPUT_ONE_BOUNDARY')
    return tiles, program, tuple(inputs), tuple(gates), output, width, height, circuit_sha, palette_sha


def _row(row, roles, width):
    _fields(row, ('active', 'ribbons'), 'ROW_FIELDS')
    active, ribbons = row['active'], row['ribbons']
    _need(type(active) is list and len(active) == len(roles), 'ACTIVE_COUNT')
    for item, expected in zip(active, roles):
        _need(type(item) is list and len(item) == 2 and type(item[0]) is int
              and item[0] == expected[0] and _integer(item[1], 0, 99), 'EXACT_SORTED_ACTIVE_POSITIONS')
    _need(type(ribbons) is list and len(ribbons) <= len(roles) + 1, 'RIBBON_ARRAY')
    previous = -1
    for item in ribbons:
        _need(type(item) is list and len(item) == 3
              and _integer(item[0], 0, width - 1) and _integer(item[1], 1, width)
              and item[0] < item[1] and _bit(item[2]), 'HALF_OPEN_RIBBON_TYPE')
        _need(previous < item[0], 'RIBBONS_NOT_SORTED_OR_NOT_MAXIMAL')
        previous = item[1]
    return active, ribbons


def _summary(circuit, certificate, palette, data, active, ribbons, expanded):
    _, _, _, _, output, width, height, circuit_sha, palette_sha = data
    return {'status': 'VERIFIED', 'reason': 'EXACT_LITERAL_GRID' if expanded else 'EXACT_RIBBON_CERTIFICATE',
            'version': VERSION, 'circuit_sha256': circuit_sha, 'palette_sha256': palette_sha,
            'certificate_sha256': _digest(certificate), 'width': width, 'height': height,
            'cells': width * height, 'active_cells': active, 'ribbon_cells': width * height - active,
            'ribbon_intervals': ribbons, 'cross_transport_cases': 20,
            'output_column': output, 'bottom_output_bit': 1, 'bottom_op_selector': 'CROSS',
            'all_vertical_op_selectors_bound_to_circuit': True,
            'exact_cell_partition_t1': True, 'all_literal_edge_interfaces_agree': True,
            'expanded_cells': width * height if expanded else 0,
            'empty_grid_coincident_top_bottom': height == 0,
            'scope': 'Finite translation-only Wang grid certificate. Ribbons prove bit transport with template-selected full south colors. No grid search or external semantic-logic admission is claimed.'}


def verify(circuit, certificate, palette):
    """Verify a symbolic ribbon certificate without expanding its CROSS cells."""
    try:
        data = _certificate(circuit, certificate, palette)
        tiles, program, inputs, gates, _, width, height, _, _ = data
        total_active = total_ribbons = 0
        for y, gate in enumerate(program):
            destination = len(inputs) + y
            roles = _roles(gate, destination)
            following = _roles(program[y + 1], destination + 1) if y + 1 < height else ()
            active, ribbons = _row(certificate['rows'][y], roles, width)
            # The exact maximal complement is derived from EVERY active position.
            gaps, cursor = [], 0
            for x, _ in roles:
                if cursor < x:
                    gaps.append((cursor, x))
                cursor = x + 1
            if cursor < width:
                gaps.append((cursor, width))
            _need(len(gaps) == len(ribbons), 'EXACT_RIBBON_COMPLEMENT')
            for (lo, hi), item in zip(gaps, ribbons):
                _need((item[0], item[1]) == (lo, hi), 'EXACT_MAXIMAL_RIBBON_INTERVAL')
                # For every x in this interval, _vertical(x,y)==_vertical(x,y+1):
                # the only differing index is destination, which is outside it.
                _need(not lo <= destination < hi, 'RIBBON_CONTAINS_WRITE')
                # Thus known input/prior-gate/future-zero streams all satisfy the
                # exhaustive 20-type lemma. At each x use next op _op(following,x),
                # not an assumption that the full north and south colors match.
            bus, r, cursor = 0, 0, 0
            for (x, op), (_, identifier) in zip(roles, active):
                if cursor < x:
                    _need(ribbons[r] == [cursor, x, bus], 'RIBBON_BUS_CONTINUITY')
                    r += 1
                tile = tiles[identifier]
                _need(tile['N'] == [op, _vertical(x, y, inputs, gates)]
                      and tile['S'] == [_op(following, x), _vertical(x, y + 1, inputs, gates)]
                      and tile['W'] == bus, 'ACTIVE_FULL_EDGE_BINDING')
                bus = tile['E']; cursor = x + 1
            if cursor < width:
                _need(ribbons[r] == [cursor, width, bus], 'FINAL_RIBBON_BUS_CONTINUITY')
                r += 1
            _need(r == len(ribbons), 'ROW_FULL_PARTITION')
            total_active += len(active); total_ribbons += len(ribbons)
        return _summary(circuit, certificate, palette, data, total_active, total_ribbons, False)
    except _Failure as error:
        return {'status': error.status, 'reason': error.reason, 'version': VERSION}


def verify_literal(circuit, certificate, palette):
    """Deterministically expand tiny certificates and check every cell/interface."""
    try:
        data = _certificate(circuit, certificate, palette)
        tiles, program, inputs, gates, output, width, height, _, _ = data
        _limit(width * height <= MAX_LITERAL_CELLS, 'LITERAL_CELL_RESOURCE_BOUND')
        previous, grid, total_active, total_ribbons = None, [], 0, 0
        for y, gate in enumerate(program):
            roles = _roles(gate, len(inputs) + y)
            following = _roles(program[y + 1], len(inputs) + y + 1) if y + 1 < height else ()
            active, ribbons = _row(certificate['rows'][y], roles, width)
            cells = [None] * width
            for x, identifier in active:
                _need(cells[x] is None, 'LITERAL_ACTIVE_OVERLAP'); cells[x] = identifier
            for lo, hi, bus in ribbons:
                for x in range(lo, hi):
                    _need(cells[x] is None and _op(roles, x) == 'CROSS', 'LITERAL_RIBBON_OVERLAP_OR_OP')
                    north, following_op = _vertical(x, y, inputs, gates), _op(following, x)
                    cells[x] = 5 * (2 * north + bus) + OPS.index(following_op)
            _need(all(identifier is not None for identifier in cells), 'LITERAL_UNCOVERED_CELL')
            for x, identifier in enumerate(cells):
                tile = tiles[identifier]
                _need(tile['N'] == [_op(roles, x), _vertical(x, y, inputs, gates)]
                      and tile['S'] == [_op(following, x), _vertical(x, y + 1, inputs, gates)], 'LITERAL_VERTICAL_TEMPLATE_OR_BIT')
                _need(tile['W'] == (0 if x == 0 else tiles[cells[x - 1]]['E']), 'LITERAL_HORIZONTAL_INTERFACE_OR_WEST')
                if previous is not None:
                    _need(tiles[previous[x]]['S'] == tile['N'], 'LITERAL_VERTICAL_INTERFACE')
                if y + 1 == height:
                    _need(tile['S'][0] == 'CROSS', 'LITERAL_BOTTOM_OP')
            previous = cells; grid.append(cells)
            total_active += len(active); total_ribbons += len(ribbons)
        if height:
            _need(tiles[previous[output]]['S'][1] == 1, 'LITERAL_BOTTOM_OUTPUT_ONE')
        result = _summary(circuit, certificate, palette, data, total_active, total_ribbons, True)
        result.update({'expanded_grid_sha256': _digest(grid),
                       'horizontal_adjacencies_checked': height * max(0, width - 1),
                       'vertical_adjacencies_checked': max(0, height - 1) * width})
        return result
    except _Failure as error:
        return {'status': error.status, 'reason': error.reason, 'version': VERSION}
