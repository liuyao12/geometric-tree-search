"""Prepare only raw-kernel task assets in isolated Git; no network/push."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parent
GIT='/private/tmp/gcts-history-publication-20261102-v1.git'
PREFIX='docs/research/gcts-rl-renewal/conditional-inventory/'


def main():
    base=sys.argv[1];assert len(base)==40 and all(c in '0123456789abcdef' for c in base)
    folder=ROOT/'publication';folder.mkdir(exist_ok=True)
    env=os.environ.copy();env.update(GIT_INDEX_FILE=str(folder/'index-v1'),GIT_NO_LAZY_FETCH='1',
        GIT_AUTHOR_NAME='Codex',GIT_AUTHOR_EMAIL='codex@openai.com',GIT_COMMITTER_NAME='Codex',GIT_COMMITTER_EMAIL='codex@openai.com')
    def git(*args):return subprocess.check_output(['git','-c','core.hooksPath=/dev/null','-c','gc.auto=0','--git-dir='+GIT,*args],env=env).decode().strip()
    existing=PREFIX+'fixed-palette-proof-backend-v1.html'
    raw=subprocess.check_output(['git','--git-dir='+GIT,'show',base+':'+existing])
    assert hashlib.sha256(raw).hexdigest()=='9c24c0cf68c311b572773af22ba57635a2b6a076f139e5b8fc0985ea802e2568'
    archive=json.loads((ROOT/'package/archive-verification-v1.json').read_text())
    assert archive['status']=='PASS_FULL_MULTIVOLUME_CLOSURE'
    sources=[('report/raw-first-order-kernel-v1.html','raw-first-order-kernel-v1.html'),
             ('report/raw-kernel-results-v1.json.gz','raw-kernel-results-v1.json.gz'),
             ('package/raw-kernel-evidence-v1.html','raw-kernel-evidence-v1.html'),
             ('package/raw-kernel-evidence-manifest-v1.json','raw-kernel-evidence-manifest-v1.json')]
    sources += [('package/'+p['name'],p['name']) for p in archive['parts']]
    for _,name in sources:
        check=subprocess.run(['git','--git-dir='+GIT,'cat-file','-e',base+':'+PREFIX+name],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        assert check.returncode!=0,'Do not overwrite an existing new asset.'
    sources.append(('report/fixed-palette-proof-backend-v1.html','fixed-palette-proof-backend-v1.html'))
    git('read-tree',base);assets=[]
    for local,name in sources:
        path=ROOT/local;data=path.read_bytes();assert len(data)<50*1024*1024
        oid=git('hash-object','-w',str(path));destination=PREFIX+name
        git('update-index','--add','--cacheinfo','100644',oid,destination)
        assets.append(dict(local=local,path=destination,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),git_blob=oid,
                           url='https://liuyao12.github.io/geometric-tree-search/'+destination))
    tree=git('write-tree','--missing-ok')
    commit=git('commit-tree',tree,'-p',base,'-m','Publish raw first-order Wang checking kernel and reproducible validation')
    diff=git('diff-tree','--no-commit-id','--no-renames','--raw','-r',base,commit)
    assert {s.split('\t')[1] for s in diff.splitlines()}=={a['path'] for a in assets}
    assert sum(line.split('\t')[0].endswith(' M') for line in diff.splitlines())==1
    record=dict(status='PREPARED_TASK_ASSETS_ONLY',base=base,tree=tree,commit=commit,assets=assets,raw_diff=diff,
                primary_checkout_staged=False,push='NOT_YET_PERFORMED')
    (folder/'prepared-v1.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps({'commit':commit,'tree':tree,'assets':len(assets),'base':base}))


if __name__=='__main__':main()
