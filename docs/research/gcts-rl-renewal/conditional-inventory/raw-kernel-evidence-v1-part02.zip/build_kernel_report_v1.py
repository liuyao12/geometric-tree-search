"""Project completed evidence into a compressed public reader; no science calls."""
import gzip
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent


def load(name):
    p=ROOT/name;raw=p.read_bytes()
    return json.loads(gzip.decompress(raw) if name.endswith('.gz') else raw)


def main():
    q=load('attempt-v2/qualify-results-v1.json.gz')
    geo=load('attempt-v2/research-results-v1.json.gz')
    pa=load('attempt-v3/research-results-v1.json.gz')
    selected=[next(c for c in q['cases'] if c['id']=='reflexivity'),*pa['cases'],*geo['cases']]
    assert len(selected)==3
    raw_locations={'reflexivity':'attempt-v2/actual/reflexivity.json.gz',
                   'raw-pa-add-successor-zero':'attempt-v3/actual/raw-pa-add-successor-zero.json.gz',
                   'raw-incidence-common-two-points':'attempt-v2/actual/raw-incidence-common-two-points.json.gz'}
    for case in selected:
        original=load(raw_locations[case['id']]);record=original['record'];problem=record['problem']
        case['raw_certificate']=record['raw_certificate']
        case['bounds']=record['bounds']
        case['problem_pins']={'pinned_bits':len(problem['pins']),'total_input_bits':len(case['input_bits']),
                              'pinned_syntax_prefix_nodes':len(problem['node_prefix']),
                              'functions':problem['maps']['function'],'predicates':problem['maps']['predicate'],
                              'variables':problem['variables'],'axiom_names':problem['axiom_names'],
                              'all_statement_AST_closures_pinned':True}
        case['kernel_metadata']={'rule_names':original['metadata']['rule_names'],
                                  'gate_cap':original['metadata']['gate_cap'],
                                  'schema':original['metadata']['schema'],'optimization':original['metadata'].get('optimization')}
        for group in case['groups']:
            if 'proof_line' in group:group['formula']=case['proof']['lines'][group['proof_line']]['formula']
        case['label']=('Reflexivity: a fully expanded tiny kernel patch' if case['id']=='reflexivity' else case['label']+' · reused searched proof')
    qualification=[]
    for row in q['summary']:
        qualification.append({'id':row['id'],'expected':row['expected'],'circuit_output':int(row['checks']['circuit_accepts']),
                              'checker_status':row['checks']['raw_kernel']['status'],
                              'native_checker_status':row['checks']['native_FOL']['status'],
                              'status':'PASS' if row['checks']['circuit_accepts']==row['expected'] else 'FAIL',
                              'reason':row['checks']['raw_kernel']['reason'],'gates':row['costs']['gates'],
                              'fixture':'Explicit qualification fixture, not a searched theorem.'})
    previous=load('upstream/fixed-palette-results-v1.json')
    prior_search={c['id']:c['checks']['search']['stats']['elapsed_seconds'] for c in previous['cases'] if 'proof' in c}
    doc={'schema':'NK-public-raw-kernel-reader-v1','palette':q['palette'],'cases':selected,'qualification':qualification,
         'notes':['The raw first-order kernel now checks syntax, substitutions and inference rules inside the NAND computation represented by the same Wang palette. No externally admitted zero-rule or producer catalogue is supplied.',
                  'Seventeen explicit qualification fixtures cover all eleven rules and four intended rejection cases. These are unit tests. The two seven-line research witnesses were found by earlier automatic GCTS search and are reused here to test the stronger backend.',
                  r'The arithmetic compilation reached the \(10^6\) gate cap in both original and lazy attempts. It completed after an explicit extension to \(2\cdot10^6\) gates with the same \(64\)-node logical bound and free proof-data space. All earlier UNKNOWN outcomes remain in the evidence.'],
         'construction':['Problem signatures, axiom and goal IDs, and every field of their transitive syntax closure are fixed data. Other AST rows, proof rule/formula/reference fields and substitution maps are unknown circuit inputs. Bound checks, syntax, free-variable equations and every rule are emitted as Boolean operations.',
                         'Substitution tasks carry a checked active recursion and node mapping. Quantifiers binding the substituted variable stop recursion; other binders must not capture a free variable of the replacement term. Irrelevant name clashes remain allowed.',
                         'The underlying semantics is classical first-order logic with equality over a nonempty domain. Primitive falsity has the explicit rule NOT BOT. Conjunction/disjunction in the human proof are desugared, not treated as extra primitive inference rules.',
                         'CROSS ribbons are manually proved reusable compiler clusters. Their exact expansion is checked without enumerating every cell; this is not learned cluster discovery or literal Wang-grid proof search.'],
         'limitations':['This milestone is a proof-checking backend. No new proof search or RL was run. It establishes neither search superiority nor a practical algorithm for arbitrary tiling regions.',
                   r'Both research circuits allow \(64\) syntax nodes, three variable IDs, seven proof lines and two substitution tasks. Current executable caps are finite; logical expressivity of the unbounded calculus is a separate mathematical claim.',
                   r'The arithmetic case has \(1{,}344{,}049\) NAND gates, and the incidence case \(573{,}693\). The arithmetic process peaked at approximately \(1.58\,\mathrm{GB}\) on this host. Literal expansion is UNKNOWN for both, while compressed ribbon certificates are verified.',
                   'These costs support keeping proof search on semantic clusters and using the Wang representation as an independent checking backend. The earlier recorded semantic searches were much smaller jobs; their timings are not a controlled benchmark comparison.',
                   'Next research: binding-aware reusable lemma families and learned point markings with comparable conventional controls. Turtle/Penrose and plane-tiling objectives remain open.'],
         'bounds':{'implementation_caps':load('attempt-v3/research-design-v1.json')['resource_caps'],'per_case':{c['id']:c['bounds'] for c in selected}},
         'problem_pins':{c['id']:c['problem_pins'] for c in selected},
         'kernel_metadata':{'rule_count':11,'statement_binding':'Entire transitive AST closure, signatures, axiom IDs and goal ID. No admitted logical-step table.',
                            'free_data':'All remaining syntax rows, rule codes, formula and prior-line references, and substitution tasks.'},
         'provenance':{'palette_sha256':hashlib.sha256((json.dumps(q['palette'],sort_keys=True,ensure_ascii=True,separators=(',',':'))+'\n').encode()).hexdigest(),
                       'reused_proof_source':'fixed-palette-results-v1.json, published fc75fa5885c6b820b13fdcfa0cc4ef02f2f240bb',
                       'previous_semantic_search_seconds':prior_search,
                       'qualification_observer':load('attempt-v2/observation-qualify-v2/completion.json'),
                       'geometry_observer':load('attempt-v2/observation-research-v2/completion.json'),
                       'arithmetic_observer':load('attempt-v3/observation-research-v3/completion.json'),
                       'source_pins':pa['source_pins'],'tiny_equivalence':load('review/lazy-equivalence-v1.json'),
                       'archive':'raw-kernel-evidence-v1.html','program_goal_status':'ACTIVE'}}
    out=ROOT/'report';out.mkdir(exist_ok=True)
    raw=(json.dumps(doc,sort_keys=True,ensure_ascii=True,separators=(',',':'))+'\n').encode()
    (out/'raw-kernel-results-v1.json.gz').write_bytes(gzip.compress(raw,mtime=0))
    html=(out/'raw-kernel-template-v1.html').read_text()
    html=html.replace('Check the proof’s syntax, not a supplied rule catalogue','Check first-order proofs in one Wang palette')
    html=html.replace('href="raw-kernel-evidence-v1.zip"','href="raw-kernel-evidence-v1.html"')
    html=html.replace('href="raw-kernel-results-v1.json">Results JSON','href="raw-kernel-results-v1.json.gz">Compressed results JSON')
    html=html.replace("new URL('raw-kernel-results-v1.json',location.href)","new URL('raw-kernel-results-v1.json.gz',location.href)")
    html=html.replace("return r.json();","if(!window.DecompressionStream)throw new Error('This reader needs gzip stream support; the full evidence remains downloadable.');return new Response(r.body.pipeThrough(new DecompressionStream('gzip'))).json();")
    # Raw certificate data is visible, rather than only the human formula layer.
    html=html.replace('<section class="panel"><h2>The eleven-rule calculus</h2>',
        '<section class="panel"><h2>Raw kernel data for this proof</h2><p>Node rows contain tag, symbol or variable ID, and child IDs. The exact proof records and substitution maps are the bits checked by the circuit. The human reader above uses the declared conjunction/disjunction abbreviations.</p><details><summary>Inspect raw AST, proof records and substitution maps</summary><pre id="raw-certificate"></pre></details><details><summary>Inspect fixed problem data and resource bounds</summary><pre id="problem-binding"></pre></details></section><section class="panel"><h2>The eleven-rule calculus</h2>')
    html=html.replace("function renderCase(){const c=current(),{I,G,W}=dimensions(c);", "function renderCase(){const c=current(),{I,G,W}=dimensions(c);$('raw-certificate').textContent=json(c.raw_certificate);$('problem-binding').textContent=json({bounds:c.bounds,problem_pins:c.problem_pins,kernel_metadata:c.kernel_metadata});")
    cite='<p>Background: the <a href="https://cs.uwaterloo.ca/~david/cs245/cs-firstorder.pdf">University of Waterloo first-order logic notes</a> describe syntax, capture-avoiding substitution, Hilbert reasoning, equality and nonempty-domain semantics. Their exact presentation differs; the eleven rules implemented here are listed above and reviewed in the archive. Validation of this compiler remains finite experimental evidence.</p>'
    html=html.replace('<p class="footer">',cite+'<p class="footer">')
    (out/'raw-first-order-kernel-v1.html').write_text(html)
    print(json.dumps({'raw_JSON_bytes':len(raw),'compressed_JSON_bytes':(out/'raw-kernel-results-v1.json.gz').stat().st_size,
                      'HTML_bytes':len(html.encode()),'cases':len(selected),'qualification_cases':len(qualification)}))


if __name__=='__main__':main()
