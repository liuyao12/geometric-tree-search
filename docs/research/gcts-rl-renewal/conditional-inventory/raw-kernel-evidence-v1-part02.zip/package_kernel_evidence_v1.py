"""Exact full evidence archive in ordinary ZIP volumes below Git file limits."""
import hashlib
import html
import json
from pathlib import Path
import subprocess
import zipfile

ROOT=Path(__file__).resolve().parent
BASE='fc75fa5885c6b820b13fdcfa0cc4ef02f2f240bb'
GIT='/private/tmp/gcts-history-publication-20261102-v1.git'
PART_LIMIT=44*1024*1024


def main():
    # Source admission is passive; no scientific functions are called here.
    admission=json.loads((ROOT/'review/research-passive-admission-v1.json').read_text())
    text=json.dumps(admission);assert 'PASS' in text and '1344049' in text and '573693' in text
    for name in ('attempt-v2/observation-qualify-v2/completion.json','attempt-v2/observation-research-v2/completion.json','attempt-v3/observation-research-v3/completion.json'):
        observed=json.loads((ROOT/name).read_text())
        assert observed['native_exit']==0 and not observed['terminated_on_wall_limit']
        assert observed['runtime']==observed['runtime_after'] and observed['source']==observed['source_after']
    old=subprocess.check_output(['git','--git-dir='+GIT,'show',BASE+':docs/research/gcts-rl-renewal/conditional-inventory/fixed-palette-proof-backend-v1.html']).decode()
    assert hashlib.sha256(old.encode()).hexdigest()=='9c24c0cf68c311b572773af22ba57635a2b6a076f139e5b8fc0985ea802e2568'
    link='<p class="panel scope"><a href="raw-first-order-kernel-v1.html#reader">Next milestone: raw first-order syntax, capture-free substitution and all eleven logical rules checked inside the same Wang palette.</a></p>'
    assert old.count('</h1>')==1
    (ROOT/'report/fixed-palette-proof-backend-v1.html').write_text(old.replace('</h1>','</h1>'+link,1))
    readme='''Full raw first-order checking-kernel evidence archive.

Download ALL listed ordinary ZIP volumes and extract them into one directory.
The volumes partition the original file paths; no original file is omitted or
split. Each volume contains the full file manifest, including SHA256 hashes.
The public manifest also records each volume's bytes and SHA256. Volumes stay
below repository single-file limits. This is the complete prepublication cut.

Main experiments: attempt-v2/qualify (17 fixtures,13accept4reject),
attempt-v2/research (geometry verified; arithmetic UNKNOWN at1M gate cap),
attempt-v3/research (same arithmetic proof/bounds verified with2M cap).
Original v1 experiments and both arithmetic UNKNOWN outcomes remain intact.
The arithmetic and geometry seven-line proofs were found automatically in the
prior fixed-palette study, then reused here. No new proof search/RL was run.
Qualification fixture proofs are hand-supplied unit tests, not discoveries.

Logical syntax/rules are checked inside NAND, with no external logical-zero
or producer-admission catalogue. The theory/goal AST closure and signature
are problem data pinned before witness encoding. Other syntax/proof/task data
remain free. Every completed witness additionally passed two independent
procedural logical checks and the independent physical ribbon checker.

Scientific Sources are in source/ and reference/. The v1 compiler is the eager
baseline; v2 lazily emits consumed fields, preserving the predicate; v3 changes
only its construction ceiling. The resource-cap peer reviews and1,024-input
tiny equivalence test are in reference/ and review/. Runtime observations,
Source guards, frozen circuits, raw logical data and tile certificates are saved.

To reproduce, copy source/, reference/, upstream/ and the observer scripts to a
fresh directory. Use the recorded Python3.12 runtime (stdlib only). Run
observe_kernel_v2.py qualify, observe_kernel_v2.py research, then
observe_kernel_v3.py research. Observer runtime paths may need adapting on a
different host; no scientific Source edit is required. Outputs use exclusive
writes: do not run over this evidence directory. The larger arithmetic run used
about1.58GB peak native memory and a2M gate cap. Literal large grids are not
expanded; their literal checks remain UNKNOWN, separate from ribbon verification.

The user explicitly approved publishing Source snapshots, raw certificates,
execution logs and local filesystem paths to the existing public GitHub Pages
site. Only task-owned evidence is included. Retired materials work is absent.

Archive cut excludes package/ and publication/: generated archive/index outputs
cannot recursively include themselves; later Git/Pages/TLS/live-UI receipts stay
in the local publication supplement. The broader research goal remains ACTIVE.
'''
    (ROOT/'README-evidence-v1.txt').write_text(readme)
    paths=sorted(p for p in ROOT.rglob('*') if p.is_file() and p.relative_to(ROOT).parts[0] not in ('package','publication'))
    entries=[];groups=[[]];current=0
    for path in paths:
        raw=path.read_bytes();assert len(raw)<PART_LIMIT
        if current+len(raw)>PART_LIMIT and groups[-1]:groups.append([]);current=0
        entry=dict(path=str(path.relative_to(ROOT)),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),part=len(groups))
        entries.append(entry);groups[-1].append(entry);current+=len(raw)
    manifest={'schema':'NK-complete-evidence-volumes-v1','original_files':len(entries),
              'original_bytes':sum(e['bytes'] for e in entries),'volume_count':len(groups),'files':entries,
              'exclusions':['package/ generated outputs','publication/ post-cut receipts']}
    package=ROOT/'package';package.mkdir(exist_ok=True);parts=[]
    manifest_bytes=(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode()
    seen=set()
    for index,group in enumerate(groups,1):
        name='raw-kernel-evidence-v1-part%02d.zip'%index;target=package/name
        with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
            for entry in group:
                info=zipfile.ZipInfo(entry['path'],date_time=(2026,11,3,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
                archive.writestr(info,(ROOT/entry['path']).read_bytes())
            info=zipfile.ZipInfo('ARCHIVE-file-manifest-v1.json',date_time=(2026,11,3,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
            archive.writestr(info,manifest_bytes)
        with zipfile.ZipFile(target) as archive:
            assert archive.testzip() is None
            for entry in group:
                raw=archive.read(entry['path']);assert len(raw)==entry['bytes'] and hashlib.sha256(raw).hexdigest()==entry['sha256']
                assert entry['path'] not in seen;seen.add(entry['path'])
        parts.append(dict(name=name,bytes=target.stat().st_size,sha256=hashlib.sha256(target.read_bytes()).hexdigest(),original_files=len(group)))
        print(json.dumps({'volume':name,'bytes':target.stat().st_size,'files':len(group)}),flush=True)
    assert seen=={e['path'] for e in entries}
    manifest['parts']=parts
    (package/'raw-kernel-evidence-manifest-v1.json').write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n')
    rows=''.join('<tr><td><a href="'+p['name']+'">'+p['name']+'</a></td><td>'+str(p['bytes'])+'</td><td><code>'+p['sha256']+'</code></td></tr>' for p in parts)
    page='''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Full raw-kernel evidence archive</title><style>body{font:16px/1.6 system-ui;color:#213543;background:#f2f5f7;margin:40px auto;max-width:1100px;padding:24px}main{background:white;border:1px solid #d4dfe6;border-radius:12px;padding:28px}td,th{padding:12px;text-align:left;border-bottom:1px solid #d4dfe6}table{width:100%;border-collapse:collapse}code{font-size:12px;overflow-wrap:anywhere}a{color:#176387}.scroll{overflow-x:auto}</style><main><h1>Full evidence archive</h1><p>Download every volume below and extract them into one directory. The original files are partitioned across ordinary ZIP archives; every Source, certificate, experiment and review in the prepublication cut is retained.</p><p><a href="raw-first-order-kernel-v1.html#reader">Return to the notebook</a> · <a href="raw-kernel-evidence-manifest-v1.json">Complete file and volume manifest</a></p><div class="scroll"><table><thead><tr><th>Volume</th><th>Bytes</th><th>SHA256</th></tr></thead><tbody>'''+rows+'''</tbody></table></div><p>The archives include local file paths and execution logs, published with the user's explicit approval. Earlier resource refusals remain UNKNOWN; the evidence does not claim new proof search or a speed advantage.</p></main></html>'''
    (package/'raw-kernel-evidence-v1.html').write_text(page)
    receipt=dict(status='PASS_FULL_MULTIVOLUME_CLOSURE',parts=parts,original_files=len(entries),original_bytes=manifest['original_bytes'],
                 all_original_files_byte_verified=True,all_volume_CRC_verified=True,unrelated_files_included=False)
    (package/'archive-verification-v1.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({'status':receipt['status'],'parts':len(parts),'original_files':len(entries),'original_bytes':manifest['original_bytes']}))


if __name__=='__main__':main()
