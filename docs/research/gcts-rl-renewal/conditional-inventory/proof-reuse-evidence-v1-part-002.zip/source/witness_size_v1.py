"""Data-only probe and exact node-bound sizing for an already searched proof.

The only scientific dependency called is the unchanged raw data encoder. No
compiler, checker, evaluator, proof search or alternative/control proof is used.
Witness-sized certification is not a prospective proof-search/held-out result.
"""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import time


ROOT = Path(__file__).resolve().parents[1]
VERSION = 'Witness-sized-raw-node-bound-v1'


def canonical(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       separators=(',', ':'), allow_nan=False)+'\n').encode('ascii')


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def _need(condition, reason):
    if not condition:
        raise ValueError(reason)


def _support():
    path = Path(__file__).with_name('resource_kernel_v1.py')
    spec = importlib.util.spec_from_file_location('dag_reuse_resource_support', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _variables(compiled):
    names = set()

    def walk(value):
        if type(value) is dict:
            for child in value.values():
                walk(child)
        elif type(value) is list:
            if value and value[0] in ('var', 'all'):
                _need(len(value) >= 2 and type(value[1]) is str and value[1], 'DECLARED_VARIABLE_NAME')
                names.add(value[1])
            for child in value:
                walk(child)
    for field in ('theory', 'goal', 'logical_basis', 'zero_instances'):
        _need(field in compiled, 'WHOLE_ORIGINAL_BASIS_REQUIRED:'+field)
        walk(compiled[field])
    return sorted(names)


def used_node_bound(bounds, metadata, certificate):
    """Minimum stable-ID length retaining all nonpadding or referenced rows.

    Only a trailing suffix of literal VAR0 padding may disappear. We do not
    renumber syntax nodes or drop nonpadding intermediate syntax. Prefix nodes,
    all supplied syntax children and every substitution map target are kept.
    """
    count, arity = bounds['nodes'], bounds['arity']
    nodes = certificate['nodes']
    _need(type(nodes) is list and len(nodes) == count, 'PROBE_NODE_COUNT')
    prefix_count = len(metadata['node_prefix'])
    _need(nodes[:prefix_count] == metadata['node_prefix'], 'PROBE_PROBLEM_PREFIX')
    filler = [1, 0]+[0]*arity
    used = set(range(prefix_count))
    for i, row in enumerate(nodes):
        _need(type(row) is list and len(row) == 2+arity, 'PROBE_NODE_WIDTH')
        if row != filler:
            used.add(i)
        used.update(child for child in row[2:] if child)
    used.update(certificate['axioms'])
    used.add(certificate['goal'])
    used.update(line['formula'] for line in certificate['proof'])
    for task in certificate['substitutions']:
        used.update(task[field] for field in ('source', 'term', 'result'))
        _need(len(task['active']) == len(task['map']) == count, 'PROBE_SUBSTITUTION_ARRAY_WIDTH')
        used.update(i for i, active in enumerate(task['active']) if active)
        used.update(task['map'])
    _need(all(type(i) is int and 0 <= i < count for i in used), 'PROBE_REFERENCED_NODE_RANGE')
    needed = max(2, max(used)+1)
    _need(all(row == filler for row in nodes[needed:]) and all(i < needed for i in used),
          'ONLY_UNUSED_TRAILING_VAR0_PADDING_CAN_BE_REMOVED')
    return dict(nodes=needed, used_node_ids=sorted(used), prefix_nodes=prefix_count,
        removed_trailing_padding_rows=count-needed, filler_row=filler,
        interpretation='Minimum row-count for this unchanged stable-ID encoder output; not a globally optimal AST/DAG representation.')


def prepare_minimal(original_compiled, compression, *, probe_nodes=128, substitutions=4, arity=None):
    """Probe the complete compressed proof, then re-encode the fresh problem.

    Refuse an oversized whole proof/profile rather than select a smaller target,
    silently raise another cap or substitute a conventional control proof.
    """
    started = time.perf_counter()
    try:
        _need(type(compression) is dict and compression['status'] == 'COMPRESSED_UNVERIFIED',
              'EXACT_COMPRESSION_PACKET_REQUIRED')
        _need(compression['provenance']['source_kind'] == 'POINT_SEARCH'
              and compression['provenance']['control_proof_used'] is False, 'NO_CONTROL_PROOF_INPUT')
        statement = dict(theory=copy.deepcopy(original_compiled['theory']),
                         goal=copy.deepcopy(original_compiled['goal']))
        _need(canonical(statement) == canonical(compression['original_statement'])
              and digest(statement) == compression['original_statement_sha256'], 'UNCHANGED_COMMON_STATEMENT')
        _need(digest(compression['original_proof']) == compression['original_proof_sha256'] and
              digest(compression['compressed_proof']) == compression['compressed_proof_sha256'], 'COMPLETE_PROOF_HASH_BINDINGS')
        proof, theory = compression['compressed_proof'], statement['theory']
        _need(type(probe_nodes) is int and 2 <= probe_nodes <= 128 and
              type(substitutions) is int and 0 <= substitutions <= 4, 'DECLARED_PROBE_CAPS')
        variables = _variables(original_compiled)
        required_arity = max([2]+list(theory['functions'].values())+list(theory['predicates'].values()))
        arity_value = required_arity if arity is None else arity
        _need(type(arity_value) is int and required_arity <= arity_value <= 4, 'DECLARED_ARITY_CAP')
        if len(proof) > 16 or len(variables) > 8 or any(len(theory[k]) > 16 for k in ('functions', 'predicates', 'axioms')):
            return dict(schema=VERSION, status='UNKNOWN', reason='WHOLE_COMPRESSED_PROOF_EXCEEDS_UNCHANGED_NONNODE_CAP',
                metrics=dict(lines=len(proof), variables=len(variables)),
                scope='No narrowing or substitute proof attempted; original/compression packets remain separate evidence.')
        probe_bounds = dict(nodes=probe_nodes, variables=max(1, len(variables)),
            functions=len(theory['functions']), predicates=len(theory['predicates']), axioms=len(theory['axioms']),
            lines=len(proof), substitutions=substitutions, arity=arity_value)
        support = _support()
        data = support.encoder_module()
        encoding_theory = dict(copy.deepcopy(theory), variables=variables)
        probe_pins, probe_metadata = data.build_problem(probe_bounds, encoding_theory, statement['goal'])
        probe_certificate = data.build_witness(probe_bounds, probe_metadata, proof)
        sizing = used_node_bound(probe_bounds, probe_metadata, probe_certificate)
        fresh_bounds = dict(probe_bounds, nodes=sizing['nodes'])
        fresh_pins, fresh_metadata = data.build_problem(fresh_bounds, encoding_theory, statement['goal'])
        fresh_certificate = data.build_witness(fresh_bounds, fresh_metadata, proof)
        _need(fresh_certificate['nodes'] == probe_certificate['nodes'][:sizing['nodes']], 'FRESH_SYNTAX_ID_PRESERVATION')
        for key in ('functions', 'predicates', 'axioms', 'goal', 'proof'):
            _need(fresh_certificate[key] == probe_certificate[key], 'FRESH_RAW_FIELD_PRESERVATION:'+key)
        for before, after in zip(probe_certificate['substitutions'], fresh_certificate['substitutions']):
            for field in ('source', 'variable', 'term', 'result'):
                _need(before[field] == after[field], 'FRESH_TASK_ID_PRESERVATION')
            _need(before['active'][:sizing['nodes']] == after['active'] and
                  before['map'][:sizing['nodes']] == after['map'], 'FRESH_TASK_MAP_PRESERVATION')
        _need(len(fresh_metadata['node_prefix']) == len(probe_metadata['node_prefix']) and
              fresh_metadata['node_prefix'] == probe_metadata['node_prefix'], 'COMPLETE_FRESH_PROBLEM_PREFIX')
        return dict(schema=VERSION, status='WITNESS_SIZED_UNVERIFIED', original_statement=statement,
            original_statement_sha256=digest(statement), original_compiled_sha256=digest(original_compiled),
            original_proof_sha256=compression['original_proof_sha256'],
            compressed_proof_sha256=compression['compressed_proof_sha256'],
            compressed_proof=copy.deepcopy(proof), encoding_theory=encoding_theory,
            probe_bounds=probe_bounds, probe_pins=probe_pins, probe_metadata=probe_metadata,
            probe_certificate=probe_certificate, sizing=sizing,
            bounds=fresh_bounds, pins=fresh_pins, problem_metadata=fresh_metadata, raw_certificate=fresh_certificate,
            raw_certificate_sha256=digest(fresh_certificate), source_pins=support.source_pins(),
            metrics=dict(original_lines=len(compression['original_proof']), compressed_lines=len(proof),
                probe_nodes=probe_nodes, chosen_node_bound=sizing['nodes'], seconds=time.perf_counter()-started),
            required_next_checks=['Independent original and compressed native-B validity.',
                'Independent extended raw128 checker and unchanged inverse codec/common-statement roundtrip.',
                'Circuit and fixed-palette ribbon checks under unchanged2M gate cap, retaining every resource refusal.'],
            scope='Data-derived witness-sized certification only. Complete original problem prefix and complete compressed proof retained; no proof search, held-out assessment, logic change, primitive grid search or replacement of prior original-proof artifacts.')
    except (MemoryError, RecursionError, OSError) as error:
        return dict(schema=VERSION, status='UNKNOWN', reason=type(error).__name__+':'+str(error),
                    seconds=time.perf_counter()-started)
    except Exception as error:
        if type(error).__name__ in ('EncodingError', 'ResourceLimit'):
            return dict(schema=VERSION, status='UNKNOWN', reason=type(error).__name__+':'+str(error),
                        seconds=time.perf_counter()-started,
                        scope='Full supplied proof refused by the declared encoding profile; no smaller proof/target substituted.')
        if isinstance(error, (ValueError, TypeError, KeyError, IndexError)):
            return dict(schema=VERSION, status='REJECTED_INPUT', reason=str(error), seconds=time.perf_counter()-started)
        raise
