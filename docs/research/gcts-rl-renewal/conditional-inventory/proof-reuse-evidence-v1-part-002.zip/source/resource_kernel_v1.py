"""Private node128 resource variant; logical Sources and gate cap unchanged.

All dependencies load lazily, by exact byte pins. Encoder/palette/decoder are
unchanged; compiler v1 differs only at CAPS.nodes and v2/v3 are byte exact.
The separate checker variant changes that cap and receipt VERSION only.
"""
import hashlib
import importlib.util
from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parents[1]
CAPS = dict(nodes=128, variables=8, functions=16, predicates=16, axioms=16,
            lines=16, substitutions=4, arity=4)
GATE_CAP = 2000000
PINS = {
    'reference/upstream/fixed_palette_v1.py': '8d4c09e1977302fd89454f1ab6d8b752d475c0a1a318ddcedac3f434518635fc',
    'reference/upstream/kernel_data_v1.py': '7fc693a12fca8940e95fa7d49ce0982094d03efdfda32d23d839fbe52833596f',
    'reference/upstream/raw_input_decoder_v1.py': '31604ebb7166764c6475789c9b0bd5cb643aeafe9d64a91b974c5abe04644560',
    'reference/kernel_n128/raw_kernel_circuit_v1.py': '7e7f067497e586dabbac2666717a15e4d9911dedd07b8a958b79bef07cd340ad',
    'reference/kernel_n128/raw_kernel_circuit_v2.py': 'a38aa4f2415965e894ce6b6764b0fb5be166f10259b0e12664b11780604f99cb',
    'reference/kernel_n128/raw_kernel_circuit_v3.py': '921dd80dfff1db388a8d36b7e8ae93df5cba33dfc0a01917f15a178d86b7593f',
    'reference/raw_fol_checker_n128_v1.py': 'd105477e8ca0ed728a6fa1f8c1207dc6fc5dc5143c7f9a583ca6837466c13d15',
}
_ENCODER = None
_KERNEL = None


def source_pins():
    result = {}
    for relative, expected in PINS.items():
        raw = (ROOT/relative).read_bytes()
        actual = hashlib.sha256(raw).hexdigest()
        if actual != expected:
            raise ValueError('RESOURCE_VARIANT_SOURCE_CHANGED:'+relative)
        result[relative] = dict(bytes=len(raw), sha256=actual)
    return result


def _load(name, relative):
    spec = importlib.util.spec_from_file_location(name, ROOT/relative)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def encoder_module():
    """Only unchanged data encoder is executed; no circuit is compiled here."""
    global _ENCODER
    source_pins()
    if _ENCODER is None:
        _ENCODER = _load('dag_reuse_unchanged_data_encoder', 'reference/upstream/kernel_data_v1.py')
    return _ENCODER


def _kernel():
    global _KERNEL
    source_pins()
    if _KERNEL is None:
        entries = [('fixed_palette_v1', 'reference/upstream/fixed_palette_v1.py')]+[
            ('raw_kernel_circuit_v%d' % version, 'reference/kernel_n128/raw_kernel_circuit_v%d.py' % version)
            for version in (1, 2, 3)]
        missing = object()
        saved = {name: sys.modules.get(name, missing) for name, relative in entries}
        loaded = {}
        try:
            for name, relative in entries:
                module = _load(name, relative)
                sys.modules[name] = module
                loaded[name] = module
        finally:
            for name, value in saved.items():
                if value is missing:
                    sys.modules.pop(name, None)
                else:
                    sys.modules[name] = value
        _KERNEL = loaded['raw_kernel_circuit_v3']
        if _KERNEL.CAPS != CAPS or _KERNEL.GATE_CAP != GATE_CAP:
            raise ValueError('RESOURCE_VARIANT_CAPS_OR_GATE_CAP_DIFFER')
    return _KERNEL


def compile_kernel(bounds, pins):
    """Same (circuit, metadata) ABI; resource refusals propagate unchanged."""
    kernel = _kernel()
    circuit, metadata = kernel.compile_kernel(bounds, pins)
    metadata.update(resource_variant='nodes128-only; other logical predicates/caps and2M NAND cap unchanged',
                    resource_variant_source_pins=source_pins())
    return circuit, metadata
