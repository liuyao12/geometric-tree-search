"""Data-only exact earlier-fact reuse and backward slicing of searched proofs.

No proof search, AST normalization, alpha-renaming, control-proof reading or
native checker import. The original and compressed proof both require later
independent native-B checks in the exact same original assumption context.
"""
import copy
import hashlib
import json
import time


VERSION = 'Exact-earlier-fact-proof-DAG-reuse-v1'
NO_REFERENCE_RULES = frozenset(('axiom', 'instantiate', 'refl', 'eq_subst',
    'distribute', 'tautology', 'ax1', 'ax2', 'ax3', 'bot_false'))
REFERENCE_FIELDS = {'mp': ('antecedent', 'implication'), 'generalize': ('source',)}


def canonical(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       separators=(',', ':'), allow_nan=False)+'\n').encode('ascii')


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def _need(condition, reason):
    if not condition:
        raise ValueError(reason)


def compress(original_statement, actual_proof, *, provenance):
    """Keep the earliest exact formula, then only facts supporting the goal.

    provenance must describe an actual POINT_SEARCH, not a DP/control proof.
    Its receipts and the correspondence to these bytes are checked externally;
    this routine verifies only the explicit supplied hash and data invariants.
    """
    started = time.perf_counter()
    try:
        _need(type(original_statement) is dict and set(original_statement) == {'theory', 'goal'},
              'EXACT_ORIGINAL_STATEMENT_REQUIRED')
        _need(type(actual_proof) is list and actual_proof, 'NONEMPTY_ACTUAL_PROOF_REQUIRED')
        _need(type(provenance) is dict and provenance.get('source_kind') == 'POINT_SEARCH'
              and provenance.get('search_status') == 'SAT' and provenance.get('native_status') == 'VERIFIED'
              and provenance.get('control_proof_used') is False, 'ACTUAL_POINT_SEARCH_PROVENANCE_REQUIRED')
        _need(str(provenance.get('mode', '')).upper() not in ('DP', 'DP_CONTROL', 'MEMOIZED'),
              'NO_CONTROL_PROOF_INPUT')
        proof_hash = digest(actual_proof)
        _need(provenance.get('original_proof_sha256') == proof_hash, 'ORIGINAL_PROOF_HASH_BINDING')
        _need(canonical(actual_proof[-1]['formula']) == canonical(original_statement['goal']),
              'EXACT_ORIGINAL_FINAL_GOAL_REQUIRED_NO_SILENT_NORMALIZATION')
        first, representatives, references = {}, [], []
        for i, line in enumerate(actual_proof):
            _need(type(line) is dict and type(line.get('rule')) is str and 'formula' in line,
                  'NATIVE_LINE_FIELDS')
            rule = line['rule']
            if rule in REFERENCE_FIELDS:
                fields = REFERENCE_FIELDS[rule]
            elif rule in NO_REFERENCE_RULES:
                fields = ()
            else:
                return dict(schema=VERSION, status='UNKNOWN', reason='UNSUPPORTED_NATIVE_RULE:'+rule,
                    original_proof=copy.deepcopy(actual_proof), original_proof_sha256=proof_hash,
                    scope='No narrowing, alternate proof or rule semantics supplied.')
            deps = {}
            for field in fields:
                value = line.get(field)
                _need(type(value) is int and 0 <= value < i, 'STRICTLY_EARLIER_NATIVE_REFERENCE')
                deps[field] = value
            references.append(deps)
            key = canonical(line['formula'])
            if key not in first:
                first[key] = i
            representatives.append(first[key])
        remapped_dependencies = [{field: representatives[target] for field, target in deps.items()}
                                 for deps in references]
        needed, pending = set(), [representatives[-1]]
        while pending:
            representative = pending.pop()
            if representative in needed:
                continue
            needed.add(representative)
            pending.extend(remapped_dependencies[representative].values())
        retained = sorted(needed)
        new_id = {old: new for new, old in enumerate(retained)}
        compressed, lineage = [], []
        for new, old in enumerate(retained):
            line = copy.deepcopy(actual_proof[old])
            for field, old_target in remapped_dependencies[old].items():
                _need(old_target in new_id and new_id[old_target] < new, 'DAG_REFERENCE_REMAP_ORDER')
                line[field] = new_id[old_target]
            compressed.append(line)
            lineage.append(dict(compressed_index=new, original_representative=old,
                original_references=references[old], representative_references=remapped_dependencies[old],
                compressed_references={f: line[f] for f in references[old]}))
        _need(canonical(compressed[-1]['formula']) == canonical(original_statement['goal']), 'COMPRESSED_FINAL_GOAL')
        mapping = []
        for i, representative in enumerate(representatives):
            mapping.append(dict(original_index=i, representative=representative,
                compressed_index=new_id.get(representative), exact_formula_sha256=digest(actual_proof[i]['formula']),
                duplicate=i != representative, retained_representative=representative in needed,
                original_dependencies=references[i], representative_dependencies=remapped_dependencies[i]))
        return dict(schema=VERSION, status='COMPRESSED_UNVERIFIED',
            original_statement=copy.deepcopy(original_statement), original_statement_sha256=digest(original_statement),
            original_proof=copy.deepcopy(actual_proof), original_proof_sha256=proof_hash,
            compressed_proof=compressed, compressed_proof_sha256=digest(compressed),
            original_to_representative=representatives,
            original_to_compressed=[new_id.get(r) for r in representatives],
            compressed_to_original=retained, line_mapping=mapping, retained_reference_mapping=lineage,
            metrics=dict(original_lines=len(actual_proof), distinct_formula_representatives=len(first),
                retained_lines=len(compressed), duplicate_lines=sum(i != r for i, r in enumerate(representatives)),
                unused_representatives=len(first)-len(retained), seconds=time.perf_counter()-started),
            provenance=copy.deepcopy(provenance),
            required_next_checks=['Independent native-B check of the original proof.',
                'Independent native-B check of the compressed proof with the same theory and exact goal.',
                'Independent mapping/reuse audit and source-search provenance binding.'],
            scope='Deterministic reuse of already proved exact earlier formulas within one fixed assumption context, followed by a backward dependency slice. No new theorem, search, held-out result, GCTS/RL novelty or replacement of the original searched proof.')
    except (MemoryError, RecursionError) as error:
        return dict(schema=VERSION, status='UNKNOWN', reason=type(error).__name__,
                    seconds=time.perf_counter()-started)
    except (ValueError, TypeError, KeyError, IndexError) as error:
        return dict(schema=VERSION, status='REJECTED_INPUT', reason=str(error),
                    seconds=time.perf_counter()-started)
