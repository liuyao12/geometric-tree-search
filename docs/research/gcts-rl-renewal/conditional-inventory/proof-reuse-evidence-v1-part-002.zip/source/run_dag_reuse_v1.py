"""Prospective guarded proof-reuse/backend driver. Source only until authorized.

Only pinned MARKS point-search witnesses are consumed. Qualification uses the
actual arithmetic witness once; incidence is the second reuse case. No search,
control proof, replacement target, learned policy or publication is performed.
Every scientific artifact/refusal is saved before an admission decision.
"""
import argparse
import copy
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
MASTER = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md')
MASTER_PIN = dict(bytes=21657, sha256='c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9')
N_PIN = dict(bytes=21129, sha256='f3e5910ecc13aa35477cef30c87a7274bd570f87c0b34ddbc678af06eb3c821a')
PHASES = ('qualify-arithmetic', 'reuse-incidence', 'backend-arithmetic', 'backend-incidence')
NATIVE_LIMITS = dict(max_depth=256, max_operations=10000000, max_proof_lines=4096)
MAPPING_LIMITS = dict(max_items=100000000, max_work=100000000, wall_seconds=30.0)
DECODER_LIMITS = dict(max_items=10000000, max_work=20000000, wall_seconds=30.0)
GUARDS = dict(rss_bytes=2147483648, cpu_seconds=900, wall_seconds=1200.0)
BACKEND_CAPS = dict(probe_nodes=128, substitutions=4, nand_gates=2000000,
                    inputs=20000, ribbon_rows=2000000, nominal_cells=10000000000000)
PROTOCOL = 'data/protocol-frozen-v1.json'


def wire(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       separators=(',', ':'), allow_nan=False)+'\n').encode('ascii')


def sha(value):
    return hashlib.sha256(wire(value)).hexdigest()


def need(condition, reason):
    if not condition:
        raise ValueError(reason)


def pin(path):
    h, count = hashlib.sha256(), 0
    with Path(path).open('rb') as source:
        for chunk in iter(lambda: source.read(1048576), b''):
            h.update(chunk)
            count += len(chunk)
    return dict(bytes=count, sha256=h.hexdigest())


def save(name, value):
    """Exclusive, deterministic JSON/gzip; completed raw stages never replaced."""
    path = ROOT/name
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as raw:
        stream = gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0,
                               compresslevel=6) if path.suffix == '.gz' else raw
        try:
            for part in json.JSONEncoder(sort_keys=True, ensure_ascii=True,
                    separators=(',', ':'), allow_nan=False).iterencode(value):
                stream.write(part.encode('ascii'))
            stream.write(b'\n')
        finally:
            if stream is not raw:
                stream.close()
    return dict(path=name, **pin(path))


def read(name):
    path = ROOT/name
    with (gzip.open(path, 'rt', encoding='ascii') if path.suffix == '.gz'
          else path.open(encoding='ascii')) as source:
        return json.load(source)


def read_ref(ref):
    need(pin(ROOT/ref['path']) == {k: ref[k] for k in ('bytes', 'sha256')},
         'SAVED_ARTIFACT_CHANGED:'+ref['path'])
    return read(ref['path'])


def module(name, relative):
    spec = importlib.util.spec_from_file_location(name, ROOT/relative)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def frozen_files():
    paths = [path for folder in ('source', 'reference', 'plan', 'input')
             for path in sorted((ROOT/folder).rglob('*'))
             if path.is_file() and '__pycache__' not in path.parts and path.suffix != '.pyc']
    paths.append(ROOT/'review/input-snapshot-v1.json')
    return {p.relative_to(ROOT).as_posix(): pin(p) for p in paths}


def runtime():
    path = Path(sys.executable).resolve()
    return dict(path=str(path), version=sys.version, platform=sys.platform, **pin(path))


def check_declared_dependencies():
    declared = read('reference/source-pins-v1.json')
    for entry in declared['unchanged']+declared['variants']:
        need(pin(ROOT/entry['path']) == {k: entry[k] for k in ('bytes', 'sha256')},
             'DECLARED_DEPENDENCY_CHANGED:'+entry['path'])
    need(pin(ROOT/'reference/proof_reuse_checker_v1.py') == N_PIN, 'MAPPING_CHECKER_PIN')
    snapshot = read('review/input-snapshot-v1.json')
    need(snapshot['status'] == 'EXACT_POINT_SEARCH_INPUTS_COPIED' and
         snapshot['source_kind'] == 'POINT_SEARCH' and snapshot['control_proof_used'] is False,
         'POINT_ONLY_INPUT_SNAPSHOT')
    expected = {'input/'+case+'-'+suffix for case in ('arithmetic', 'incidence')
                for suffix in ('prepared.json.gz', 'search-raw.json.gz',
                               'native-check.json', 'graph-check.json')}
    need({x['path'] for x in snapshot['files']} == expected and len(snapshot['files']) == 8,
         'EXACT_EIGHT_POINT_INPUTS')
    for entry in snapshot['files']:
        need(pin(ROOT/entry['path']) == {k: entry[k] for k in ('bytes', 'sha256')},
             'INPUT_SNAPSHOT_CHANGED:'+entry['path'])


def freeze():
    """Byte-only phase; no scientific module imports or proof manipulation."""
    check_declared_dependencies()
    need(pin(MASTER) == MASTER_PIN, 'REVIEWED_MASTER_CHANGED')
    target = ROOT/'reference/basic-tiling-algorithm.md'
    if target.exists():
        need(pin(target) == MASTER_PIN, 'MASTER_SNAPSHOT_CHANGED')
    else:
        with target.open('xb') as destination:
            destination.write(MASTER.read_bytes())
    protocol = dict(schema='Proof-DAG-reuse-prospective-protocol-v1', status='FROZEN',
        pins=frozen_files(), runtime=runtime(), master=dict(path=str(MASTER), **MASTER_PIN),
        phases=list(PHASES), native_limits=NATIVE_LIMITS, mapping_limits=MAPPING_LIMITS,
        decoder_limits=DECODER_LIMITS, process_guards=GUARDS, backend_caps=BACKEND_CAPS,
        qualification='One genuine pinned arithmetic MARKS witness: compression once, original/compressed native B, full mapping/provenance gates, then saved corruption/resource controls. No synthetic search claims.',
        scope='Post-search exact earlier-fact reuse and witness-sized certification. No new proof search, DP/control proof input, held-out advantage, GCTS/RL novelty or primitive large Wang-grid search.')
    return save(PROTOCOL, protocol)


def unchanged(protocol):
    need(frozen_files() == protocol['pins'], 'FROZEN_SOURCE_OR_INPUT_SET_CHANGED')
    need(runtime() == protocol['runtime'], 'FROZEN_RUNTIME_CHANGED')
    need(pin(MASTER) == MASTER_PIN, 'LIVE_MASTER_CHANGED')
    check_declared_dependencies()


def source_case(case):
    entries = {x['path']: x for x in read('review/input-snapshot-v1.json')['files']}
    refs = {}
    for key, suffix in (('source_raw', 'search-raw.json.gz'),
                        ('source_native_check', 'native-check.json'),
                        ('source_graph_check', 'graph-check.json'),
                        ('original_compiled', 'prepared.json.gz')):
        path = 'input/'+case+'-'+suffix
        entry = entries[path]
        need(pin(ROOT/path) == {k: entry[k] for k in ('bytes', 'sha256')}, 'EXACT_INPUT_BYTES')
        refs[key] = dict(path=path, **{k: entry[k] for k in ('bytes', 'sha256')})
    prepared = read(refs['original_compiled']['path'])
    raw = read(refs['source_raw']['path'])
    native = read(refs['source_native_check']['path'])
    graph = read(refs['source_graph_check']['path'])
    compiled = prepared['compiled']
    statement = dict(theory=compiled['theory'], goal=compiled['goal'])
    proof = native['decoded']['proof']
    refs['original_compiled']['pointer'] = '/compiled'
    need(raw['mode'] == 'MARKS' and raw['result']['status'] == 'SAT', 'ACTUAL_MARKS_SAT_ONLY')
    provenance = dict(source_kind='POINT_SEARCH', search_status=raw['result']['status'],
        native_status=native['status'], control_proof_used=False, mode=raw['mode'],
        source_run_id=raw['id'], original_proof_sha256=sha(proof),
        input_snapshot_sha256=pin(ROOT/'review/input-snapshot-v1.json')['sha256'])
    binding = dict(source_raw=raw, source_native_check=native,
        source_graph_check=graph, original_compiled=compiled, artifact_refs=refs)
    return statement, proof, compiled, provenance, binding


def native_wrappers(statement, original, compressed, receipts):
    return {key: dict(statement_sha256=sha(statement), proof_sha256=sha(proof), receipt=receipt)
            for key, proof, receipt in (('original', original, receipts[0]),
                                       ('compressed', compressed, receipts[1]))}


def call_save(name, function):
    started = time.perf_counter()
    try:
        value = function()
    except Exception as error:
        if isinstance(error, (MemoryError, RecursionError, OSError, TimeoutError)) or \
                type(error).__name__ in ('ResourceLimit', 'EncodingError'):
            value = dict(status='UNKNOWN', reason=type(error).__name__+':'+str(error))
        else:
            value = dict(status='ERROR', reason=type(error).__name__+':'+str(error))
    ref = save(name, value)
    print(json.dumps(dict(stage=name, status=value.get('status'),
                          seconds=time.perf_counter()-started)), flush=True)
    return value, ref


def reuse(case):
    started = time.perf_counter()
    statement, proof, compiled, provenance, binding = source_case(case)
    folder = 'data/reuse/'+case+'/'
    refs = dict(source_declaration=save(folder+'source-declaration.json', dict(
        statement_sha256=sha(statement), original_proof_sha256=sha(proof),
        provenance=provenance, source_artifacts=binding['artifact_refs'],
        inherited_evidence_scope='Exact historical raw/graph/native bytes and content joins; this phase does not rerun historical point search or graph assurance.')))
    D = module('actual_proof_dag', 'source/proof_dag_v1.py')
    packet, refs['compression'] = call_save(folder+'compression.json.gz',
        lambda: D.compress(statement, proof, provenance=provenance))
    record = dict(id=case, status='UNKNOWN', artifacts=refs,
        original_statement_sha256=sha(statement), original_proof_sha256=sha(proof))
    if packet.get('status') == 'COMPRESSED_UNVERIFIED':
        refs['original_proof'] = save(folder+'original-proof.json.gz', proof)
        refs['compressed_proof'] = save(folder+'compressed-proof.json.gz', packet['compressed_proof'])
        B = module('reuse_native_B', 'reference/upstream/native_fol_checker_v1.py')
        original, refs['original_native'] = call_save(folder+'original-native-B.json',
            lambda: B.check(statement['theory'], proof, statement['goal'], NATIVE_LIMITS))
        compressed, refs['compressed_native'] = call_save(folder+'compressed-native-B.json',
            lambda: B.check(statement['theory'], packet['compressed_proof'], statement['goal'], NATIVE_LIMITS))
        wrappers = native_wrappers(statement, proof, packet['compressed_proof'], (original, compressed))
        refs['native_receipt_bindings'] = save(folder+'native-receipt-bindings.json', wrappers)
        N = module('independent_reuse_mapping', 'reference/proof_reuse_checker_v1.py')
        checked, refs['mapping'] = call_save(folder+'mapping-and-provenance-check.json',
            lambda: N.verify(statement, proof, packet, provenance_binding=binding,
                            native_receipt_bindings=wrappers, **MAPPING_LIMITS))
        gates = dict(original_native=original.get('status'), compressed_native=compressed.get('status'),
            mapping=(checked.get('mapping') or {}).get('status'),
            provenance=(checked.get('provenance') or {}).get('status'),
            native_interfaces=(checked.get('native_receipt_interfaces') or {}).get('status'),
            mapping_overall=checked.get('status'))
        admitted = gates == dict(original_native='VERIFIED', compressed_native='VERIFIED',
            mapping='VERIFIED', provenance='VERIFIED_CONTENT_BINDING',
            native_interfaces='BOUND_VERIFIED_RECEIPTS', mapping_overall='VERIFIED')
        record.update(status='VERIFIED_PROOF_REUSE' if admitted else
            'UNKNOWN' if 'UNKNOWN' in gates.values() else 'NOT_ADMITTED',
            gates=gates, metrics=packet['metrics'], compressed_proof_sha256=packet['compressed_proof_sha256'])
    else:
        record.update(status=packet.get('status', 'ERROR'), reason=packet.get('reason'))
    record.update(seconds=time.perf_counter()-started,
        scope='Original and compressed proofs are separate artifacts under exactly the same statement. A native line reduction is neither a newly searched proof nor a GCTS/RL advantage.')
    save(folder+'result.json', record)
    return record


def qualify():
    baseline = reuse('arithmetic')
    rows = []
    if baseline['status'] == 'VERIFIED_PROOF_REUSE':
        statement, proof, _, _, binding = source_case('arithmetic')
        packet = read_ref(baseline['artifacts']['compression'])
        wrappers = read_ref(baseline['artifacts']['native_receipt_bindings'])
        N = module('qualification_mapping_N', 'reference/proof_reuse_checker_v1.py')

        def control(cid, expected, change=None, bindings_change=None, native_change=None, limits=None):
            mutant = copy.deepcopy(packet)
            if change:
                change(mutant)
            bind = copy.deepcopy(binding) if bindings_change else binding
            native = copy.deepcopy(wrappers) if native_change else wrappers
            if bindings_change:
                bindings_change(bind)
            if native_change:
                native_change(native)
            spec = dict(id=cid, qualification_only=True, expected=expected,
                original_artifacts=baseline['artifacts'], packet=mutant,
                source_override=bind if bindings_change else None,
                native_receipt_bindings=native, limits=limits or MAPPING_LIMITS)
            input_ref = save('data/qualification/'+cid+'-input.json.gz', spec)
            result, check_ref = call_save('data/qualification/'+cid+'-check.json',
                lambda: N.verify(statement, proof, mutant, provenance_binding=bind,
                    native_receipt_bindings=native, **(limits or MAPPING_LIMITS)))
            rows.append(dict(id=cid, expected=expected, actual=result.get('status'),
                matched=result.get('status') == expected, input=input_ref, check=check_ref))

        duplicates = [i for i, rep in enumerate(packet['original_to_representative']) if i != rep]
        need(duplicates, 'QUALIFICATION_CORPUS_NEEDS_AN_ACTUAL_DUPLICATE')
        duplicate = duplicates[0]
        control('later-duplicate-representative', 'REJECTED',
            lambda p: p['original_to_representative'].__setitem__(duplicate, duplicate))

        def changed_formula(p):
            first = p['compressed_proof'][0]
            first['formula'] = ['imp', first['formula'], first['formula']]
            p['compressed_proof_sha256'] = sha(p['compressed_proof'])
        control('changed-retained-formula-rehashed', 'REJECTED', changed_formula)

        refs = [(i, field) for i, line in enumerate(packet['compressed_proof'])
                for field in ('antecedent', 'implication', 'source') if field in line]
        need(refs, 'QUALIFICATION_CORPUS_NEEDS_AN_ACTUAL_REFERENCE')
        index, field = refs[0]
        def changed_reference(p):
            p['compressed_proof'][index][field] = index
            p['compressed_proof_sha256'] = sha(p['compressed_proof'])
        control('forward-native-reference-rehashed', 'REJECTED', changed_reference)
        control('boolean-native-reference-rehashed', 'REJECTED',
            lambda p: (p['compressed_proof'][index].__setitem__(field, True),
                       p.__setitem__('compressed_proof_sha256', sha(p['compressed_proof']))))
        control('wrong-retained-original-index', 'REJECTED',
            lambda p: p['compressed_to_original'].__setitem__(0, len(proof)-1))
        control('wrong-unused-count', 'REJECTED',
            lambda p: p['metrics'].__setitem__('unused_representatives', p['metrics']['unused_representatives']+1))
        def changed_statement(p):
            p['original_statement']['goal'] = ['imp', p['original_statement']['goal'], p['original_statement']['goal']]
            p['original_statement_sha256'] = sha(p['original_statement'])
        control('changed-common-statement-rehashed', 'REJECTED', changed_statement)
        control('control-mode-provenance', 'REJECTED',
            lambda p: p['provenance'].__setitem__('mode', 'DP_CONTROL'))
        control('selected-CID-content-join', 'REJECTED', bindings_change=lambda b:
            b['source_native_check']['decoded']['tree'].__setitem__('selected', []))
        control('wrong-native-wrapper-proof-digest', 'REJECTED', native_change=lambda n:
            n['compressed'].__setitem__('proof_sha256', '0'*64))
        control('native-wrapper-unknown-retained', 'UNKNOWN', native_change=lambda n:
            n['compressed'].__setitem__('receipt', dict(status='UNKNOWN', reason='DECLARED_QUALIFICATION_REFUSAL')))
        control('mapping-work-resource-refusal', 'UNKNOWN', limits=dict(MAPPING_LIMITS, max_work=1))
    status = 'QUALIFIED' if baseline['status'] == 'VERIFIED_PROOF_REUSE' and rows and all(r['matched'] for r in rows) else \
        'UNKNOWN' if baseline['status'] == 'UNKNOWN' or any(r['actual'] == 'UNKNOWN' and not r['matched'] for r in rows) else 'NOT_ADMITTED'
    value = dict(schema='DAG-reuse-actual-witness-qualification-v1', status=status,
        arithmetic_reuse_result=dict(path='data/reuse/arithmetic/result.json', **pin(ROOT/'data/reuse/arithmetic/result.json')),
        controls=rows, scope='Real arithmetic source provenance, not a synthetic search claim. Compression and both native checks were performed once and will be reused, not recomputed for another phase name.')
    save('data/qualification-result-v1.json', value)
    return value


def normalized(ast):
    """Explicit and/or notation expansion, not proof search or rewriting rules."""
    tag = ast[0]
    if tag == 'var':
        return list(ast)
    if tag in ('fun', 'pred'):
        return [tag, ast[1], [normalized(a) for a in ast[2]]]
    if tag in ('and', 'or', 'imp', 'eq'):
        a, b = normalized(ast[1]), normalized(ast[2])
        return ['not', ['imp', a, ['not', b]]] if tag == 'and' else ['imp', ['not', a], b] if tag == 'or' else [tag, a, b]
    if tag == 'all':
        return [tag, ast[1], normalized(ast[2])]
    if tag == 'not':
        return [tag, normalized(ast[1])]
    need(tag == 'bot' and len(ast) == 1, 'SUPPORTED_NORMALIZATION_AST')
    return ['bot']


def line_projection(lines):
    payload = dict(axiom=('name',), mp=('antecedent', 'implication'),
        generalize=('source', 'variable'), instantiate=('universal', 'term'),
        refl=(), eq_subst=('variable', 'template', 'left', 'right'),
        distribute=('variable', 'antecedent', 'consequent'), tautology=(),
        ax1=(), ax2=(), ax3=(), bot_false=())
    ast_fields = {'formula', 'universal', 'term', 'template', 'left', 'right'}
    result = []
    for line in lines:
        rule = line['rule']
        need(rule in payload, 'UNSUPPORTED_NORMALIZED_LINE_PROJECTION:'+rule)
        ast_keys = ast_fields | ({'antecedent', 'consequent'} if rule == 'distribute' else set())
        output = {key: normalized(line[key]) if key in ast_keys else line[key]
                  for key in ('rule', 'formula')+payload[rule]}
        if rule in ('ax1', 'ax2', 'ax3', 'bot_false'):
            output['rule'] = 'tautology'
        result.append(output)
    return result


def backend(case):
    started, folder, artifacts = time.perf_counter(), 'data/backend/'+case+'/', {}
    qualification = read('data/qualification-result-v1.json')
    need(qualification['status'] == 'QUALIFIED', 'QUALIFICATION_REQUIRED')
    if case == 'arithmetic':
        admitted = read_ref(qualification['arithmetic_reuse_result'])
    else:
        admitted = read('data/reuse/incidence/result.json')
    need(admitted['status'] == 'VERIFIED_PROOF_REUSE', 'INDEPENDENT_REUSE_ADMISSION_REQUIRED')
    packet = read_ref(admitted['artifacts']['compression'])
    statement, proof, compiled, _, _ = source_case(case)
    need(sha(statement) == packet['original_statement_sha256'] and
         sha(proof) == packet['original_proof_sha256'], 'SAME_ACTUAL_ORIGINAL_STATEMENT_AND_PROOF')

    def finish(status, stopped=None, metrics=None):
        value = dict(schema='DAG-witness-sized-backend-result-v1', id=case, status=status,
            stopped_stage=stopped, artifacts=artifacts, seconds=time.perf_counter()-started,
            original_statement_sha256=sha(statement), original_proof_sha256=sha(proof),
            compressed_proof_sha256=packet['compressed_proof_sha256'], metrics=metrics,
            scope='Post-search compressed-proof certification, witness-sized node resource. Does not replace the original searched proof, run primitive Wang proof search, or establish a GCTS/RL speed gain.')
        save(folder+'result.json', value)
        return value

    W = module('witness_sizing_data', 'source/witness_size_v1.py')
    sized, artifacts['witness_size'] = call_save(folder+'witness-size.json.gz', lambda:
        W.prepare_minimal(compiled, packet, probe_nodes=BACKEND_CAPS['probe_nodes'],
                          substitutions=BACKEND_CAPS['substitutions']))
    if sized.get('status') != 'WITNESS_SIZED_UNVERIFIED':
        return finish('UNKNOWN' if sized.get('status') == 'UNKNOWN' else 'NOT_ADMITTED', 'witness_size')
    bounds, raw = sized['bounds'], sized['raw_certificate']
    F = module('independent_raw_128', 'reference/raw_fol_checker_n128_v1.py')
    raw_check, artifacts['raw_check'] = call_save(folder+'raw-128-check.json', lambda: F.check(bounds, raw))
    if raw_check.get('status') != 'VERIFIED':
        return finish('UNKNOWN' if raw_check.get('status') == 'UNKNOWN' else 'NOT_ADMITTED', 'raw_check')
    S = module('dag_reuse_resource_support_driver', 'source/resource_kernel_v1.py')
    def compile_stage():
        circuit, metadata = S.compile_kernel(bounds, sized['pins'])
        counts = dict(inputs=len(circuit['inputs']), nand_gates=len(circuit['gates']))
        counts.update(width=counts['inputs']+counts['nand_gates'], height=counts['nand_gates'])
        counts['nominal_cells'] = counts['width']*counts['height']
        oversize = counts['inputs'] > BACKEND_CAPS['inputs'] or counts['nand_gates'] > BACKEND_CAPS['nand_gates'] or counts['height'] > BACKEND_CAPS['ribbon_rows'] or counts['nominal_cells'] > BACKEND_CAPS['nominal_cells']
        return dict(status='UNKNOWN' if oversize else 'COMPILED', reason='DECLARED_BACKEND_CAP' if oversize else None,
                    circuit=circuit, metadata=metadata, counts=counts)
    compiled_backend, artifacts['circuit'] = call_save(folder+'circuit.json.gz', compile_stage)
    if compiled_backend.get('status') != 'COMPILED':
        return finish('UNKNOWN' if compiled_backend.get('status') == 'UNKNOWN' else 'NOT_ADMITTED', 'compile')
    circuit = compiled_backend['circuit']
    data = S.encoder_module()
    encoded, artifacts['bits'] = call_save(folder+'encoded-bits.json.gz', lambda:
        dict(status='ENCODED', input_bits=data.encode_bits(bounds, raw, circuit['inputs'])))
    if encoded.get('status') != 'ENCODED':
        return finish('UNKNOWN' if encoded.get('status') == 'UNKNOWN' else 'NOT_ADMITTED', 'encode')
    bits = encoded['input_bits']
    D = module('independent_inverse_codec', 'reference/upstream/raw_input_decoder_v1.py')
    inverse, artifacts['inverse'] = call_save(folder+'inverse-check.json.gz', lambda:
        D.decode(bounds, circuit['inputs'], bits, statement,
            variables=sized['encoding_theory']['variables'], **DECODER_LIMITS))
    if inverse.get('status') != 'VERIFIED':
        return finish('UNKNOWN' if inverse.get('status') == 'UNKNOWN' else 'NOT_ADMITTED', 'inverse')
    human = inverse['human']
    B = module('decoded_named_native_B', 'reference/upstream/native_fol_checker_v1.py')
    native, artifacts['decoded_native'] = call_save(folder+'decoded-native-B.json', lambda:
        B.check(human['theory'], human['proof'], human['goal'], NATIVE_LIMITS))
    def join():
        normalized_statement = dict(theory=dict(functions=statement['theory']['functions'],
            predicates=statement['theory']['predicates'],
            axioms={key: normalized(ast) for key, ast in statement['theory']['axioms'].items()}),
            goal=normalized(statement['goal']))
        checks = dict(exact_raw=inverse['raw_certificate'] == raw,
            exact_input_roundtrip=data.encode_bits(bounds, inverse['raw_certificate'], circuit['inputs']) == bits,
            exact_normalized_lines=line_projection(packet['compressed_proof']) == line_projection(human['proof']),
            exact_normalized_statement=human['normalized_original_statement'] == normalized_statement,
            decoded_signature_context=human['theory'] == normalized_statement['theory'],
            decoded_goal=human['goal'] == normalized_statement['goal'])
        return dict(status='VERIFIED' if all(checks.values()) else 'REJECTED', checks=checks,
            original_statement_sha256=sha(statement), normalized_statement_sha256=sha(normalized_statement),
            normalized_statement=normalized_statement,
            normalization='Only and(A,B) := not(imp(A,not(B))) and or(A,B) := imp(not(A),B); all other AST names/structure unchanged. Explicit named schema tags may display as decoder tautology with the same normalized formula.')
    binding, artifacts['common_statement'] = call_save(folder+'common-statement-check.json', join)
    if native.get('status') != 'VERIFIED' or binding.get('status') != 'VERIFIED':
        return finish('UNKNOWN' if native.get('status') == 'UNKNOWN' or binding.get('status') == 'UNKNOWN' else 'NOT_ADMITTED', 'decoded_native_or_common_statement')
    FP = module('unchanged_fixed_palette', 'reference/upstream/fixed_palette_v1.py')
    palette = FP.palette()
    artifacts['palette'] = save(folder+'palette.json', palette)
    evaluation, artifacts['evaluation'] = call_save(folder+'circuit-evaluation.json.gz', lambda:
        dict(zip(('gate_bits', 'acceptance_bit'), FP.evaluate(circuit, bits)), status='EVALUATED'))
    if evaluation.get('status') != 'EVALUATED' or evaluation.get('acceptance_bit') != 1:
        return finish('UNKNOWN' if evaluation.get('status') == 'UNKNOWN' else 'NOT_ADMITTED', 'circuit_evaluation')
    ribbon, artifacts['ribbon'] = call_save(folder+'ribbon.json.gz', lambda:
        dict(status='CONSTRUCTED', certificate=FP.certificate(circuit, bits, palette)))
    if ribbon.get('status') != 'CONSTRUCTED':
        return finish('UNKNOWN' if ribbon.get('status') == 'UNKNOWN' else 'NOT_ADMITTED', 'ribbon')
    R = module('independent_ribbon_checker', 'reference/upstream/ribbon_checker_v3.py')
    symbolic, artifacts['symbolic'] = call_save(folder+'symbolic-tile-check.json', lambda:
        R.verify(circuit, ribbon['certificate'], palette))
    literal, artifacts['literal'] = call_save(folder+'literal-tile-check.json', lambda:
        R.verify_literal(circuit, ribbon['certificate'], palette))
    certificate = ribbon['certificate']
    metrics = dict(compiled_backend['counts'], original_lines=len(proof),
        compressed_lines=len(packet['compressed_proof']), probe_nodes=sized['probe_bounds']['nodes'],
        chosen_nodes=bounds['nodes'], palette_types=len(palette['tiles']),
        active_tile_instances=sum(len(row['active']) for row in certificate['rows']),
        ribbon_intervals=sum(len(row['ribbons']) for row in certificate['rows']),
        known_input_bits=sum(item['value'] is not None for item in circuit['inputs']),
        symbolic_status=symbolic.get('status'), literal_status=literal.get('status'),
        circuit_evaluations=2, symbolic_expanded_cells=symbolic.get('expanded_cells'))
    acceptable = symbolic.get('status') == 'VERIFIED' and literal.get('status') in ('VERIFIED', 'UNKNOWN')
    return finish('VERIFIED_COMPRESSED_BACKEND_JOIN' if acceptable else
        'UNKNOWN' if symbolic.get('status') == 'UNKNOWN' else 'NOT_ADMITTED', metrics=metrics)


def worker(phase):
    need(os.environ.get('GCTS_DAG_GUARD_PARENT') == str(os.getppid()), 'GUARDED_INVOCATION_REQUIRED')
    resource.setrlimit(resource.RLIMIT_CPU, (GUARDS['cpu_seconds'], GUARDS['cpu_seconds']+1))
    protocol = read(PROTOCOL)
    unchanged(protocol)
    started = time.perf_counter()
    save('data/'+phase+'-started-v1.json', dict(status='STARTED', phase=phase,
        protocol=dict(path=PROTOCOL, **pin(ROOT/PROTOCOL)), pid=os.getpid(),
        cpu_limit_seconds=GUARDS['cpu_seconds']))
    outcome = None
    try:
        if phase == 'qualify-arithmetic':
            outcome = qualify()
        elif phase == 'reuse-incidence':
            need(read('data/qualification-result-v1.json')['status'] == 'QUALIFIED', 'QUALIFICATION_REQUIRED')
            outcome = reuse('incidence')
        else:
            outcome = backend(phase.split('-', 1)[1])
        unchanged(protocol)
        return outcome
    finally:
        save('review/'+phase+'-invocation-v1.json', dict(
            status='ERROR' if sys.exc_info()[0] else 'COMPLETE', phase=phase,
            scientific_status=outcome.get('status') if outcome else None,
            seconds=time.perf_counter()-started,
            maxrss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            maxrss_units='bytes' if sys.platform == 'darwin' else 'KiB',
            includes='Guarded worker with stage persistence and inline independent assurance; not only algorithm time.'))


def supervise(phase):
    """Own native child only; CPU limit inside, RSS/wall polling outside."""
    protocol = read(PROTOCOL)
    unchanged(protocol)
    need(not (ROOT/('data/'+phase+'-started-v1.json')).exists(), 'NO_SILENT_PHASE_RESTART')
    log = ROOT/('review/'+phase+'-native-v1.log')
    log.parent.mkdir(parents=True, exist_ok=True)
    started, peak, reason, child = time.perf_counter(), 0, None, None
    probes = []
    with log.open('xb') as output:
        env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', GCTS_DAG_GUARD_PARENT=str(os.getpid()))
        child = subprocess.Popen([sys.executable, '-I', '-S', '-B', str(Path(__file__).resolve()), '_worker', phase],
            cwd=str(ROOT), env=env, stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            while child.poll() is None:
                if time.perf_counter()-started > GUARDS['wall_seconds']:
                    reason = 'WALL_GUARD'
                    break
                probe = subprocess.run(['/bin/ps', '-o', 'rss=', '-p', str(child.pid)],
                    capture_output=True, text=True, timeout=5)
                text = probe.stdout.strip()
                if probe.returncode == 0 and text.isdigit():
                    rss = int(text)*1024
                    peak = max(peak, rss)
                    if not probes or rss > probes[-1]['rss_bytes']:
                        probes.append(dict(seconds=time.perf_counter()-started, rss_bytes=rss))
                    if rss > GUARDS['rss_bytes']:
                        reason = 'RSS_GUARD'
                        break
                elif child.poll() is None:
                    reason = 'RSS_OBSERVER_UNAVAILABLE'
                    break
                time.sleep(0.25)
        except BaseException as error:
            reason = 'OBSERVER_INTERRUPTION:'+type(error).__name__
        finally:
            if child.poll() is None:
                os.killpg(child.pid, signal.SIGTERM)
                try:
                    child.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid, signal.SIGKILL)
            exit_code = child.wait()
    changed = None
    try:
        unchanged(protocol)
    except Exception as error:
        changed = str(error)
    value = dict(schema='DAG-reuse-owned-process-observer-v1', phase=phase,
        status='COMPLETE' if exit_code == 0 and reason is None and changed is None else 'UNKNOWN',
        pid=child.pid, native_exit_code=exit_code, guard_reason=reason,
        frozen_postcheck_error=changed, wall_seconds=time.perf_counter()-started,
        peak_observed_rss_bytes=peak, rss_samples=probes,
        log=dict(path=log.relative_to(ROOT).as_posix(), **pin(log)),
        scope='RSS is polled, not a strict instantaneous upper bound. CPU is enforced by native RLIMIT_CPU. Nonzero/terminated execution and any unfinished phase remain UNKNOWN; saved artifacts are not deleted or rerun.')
    save('review/'+phase+'-observer-v1.json', value)
    return value


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=('freeze', 'run', '_worker'))
    parser.add_argument('phase', choices=PHASES, nargs='?')
    args = parser.parse_args()
    need((args.command == 'freeze') == (args.phase is None), 'EXACT_COMMAND_ARGUMENTS')
    value = freeze() if args.command == 'freeze' else supervise(args.phase) if args.command == 'run' else worker(args.phase)
    print(json.dumps(value, sort_keys=True), flush=True)
    if args.command == 'run' and value['status'] != 'COMPLETE':
        raise SystemExit(1)


if __name__ == '__main__':
    main()
