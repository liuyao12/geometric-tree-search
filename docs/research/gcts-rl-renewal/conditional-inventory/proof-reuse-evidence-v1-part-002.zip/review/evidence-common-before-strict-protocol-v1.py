"""Byte/ZIP utilities; no scientific code, networking or Git operations."""
import hashlib
import json
from pathlib import Path,PurePosixPath
import zipfile

ROOT=Path(__file__).resolve().parents[1]
PREFIX='docs/research/gcts-rl-renewal/conditional-inventory/'
BASE_URL='https://liuyao12.github.io/geometric-tree-search/'
MANIFEST='proof-reuse-evidence-manifest-v1.json'
INTERNAL='ARCHIVE-file-manifest-v1.json'
PART_STEM='proof-reuse-evidence-v1-part-'
MAX_PART=44*1024*1024
PHASES=('qualify-arithmetic','reuse-incidence','backend-arithmetic','backend-incidence')
READINESS=('review/saved-data-audit-v1.json','review/report-build-v1.json',
           'review/local-ui-qualification-v1.json','review/root-source-admission-v1.json')

def wire(v):return (json.dumps(v,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')
def digest(raw):return hashlib.sha256(raw).hexdigest()
def stream_pin(stream):
    h=hashlib.sha256();size=0
    for block in iter(lambda:stream.read(1048576),b''):h.update(block);size+=len(block)
    return dict(bytes=size,sha256=h.hexdigest())
def pin(path):
    with path.open('rb') as f:return stream_pin(f)
def relative_name(value):
    assert type(value) is str and value and '\\' not in value and '\x00' not in value
    p=PurePosixPath(value)
    assert not p.is_absolute() and all(v not in ('','.','..') for v in p.parts) and p.as_posix()==value
    return value
def local(root,value):
    p=root/relative_name(value);assert root.resolve() in p.resolve().parents
    return p
def verify_protocol(relative,context_root=''):
    """Byte-only frozen Source/runtime/master and four completed phase joins."""
    path=local(ROOT,relative);value=json.loads(path.read_text())
    assert relative=='data/protocol-frozen-v1.json' and context_root==''
    assert value['schema']=='Proof-DAG-reuse-prospective-protocol-v1' and value['status']=='FROZEN'
    assert value['phases']==list(PHASES)
    base=ROOT
    for name,expected in value['pins'].items():
        assert wire(pin(local(base,name)))==wire(expected),context_root+'/'+name
    runtime=value['runtime']
    assert runtime and wire(pin(Path(runtime['path'])))==wire({k:runtime[k] for k in ('bytes','sha256')})
    master=value['master'];expected={k:master[k] for k in ('bytes','sha256')}
    assert wire(pin(Path(master['path'])))==wire(expected)
    assert wire(pin(ROOT/'reference/basic-tiling-algorithm.md'))==wire(expected)
    phases=[]
    for phase in PHASES:
        refs={}
        for key,suffix in (('observer','-observer-v1.json'),('invocation','-invocation-v1.json')):
            name='review/'+phase+suffix;receipt=json.loads(local(ROOT,name).read_text())
            assert receipt['status']=='COMPLETE' and receipt['phase']==phase
            if key=='observer':
                assert receipt['native_exit_code']==0 and receipt['guard_reason'] is None and receipt['frozen_postcheck_error'] is None
            else:
                expected_status='QUALIFIED' if phase=='qualify-arithmetic' else 'VERIFIED_PROOF_REUSE' if phase=='reuse-incidence' else 'VERIFIED_COMPRESSED_BACKEND_JOIN'
                assert receipt['scientific_status']==expected_status
            refs[key]=dict(path=name,**pin(local(ROOT,name)))
        phases.append(dict(phase=phase,receipts=refs))
    return dict(path=relative,context_root=context_root,schema=value['schema'],phases=phases,source_pin_count=len(value['pins']),**pin(path))
def inventory_from_manifest(manifest):
    assert manifest['schema']=='DAG-physical-multipart-evidence-v1' and manifest['inventory_file']==INTERNAL
    core={k:v for k,v in manifest.items() if k not in ('inventory_sha256','inventory_schema','inventory_file')}
    core['schema']=manifest['inventory_schema']
    core['parts']=[dict(number=p['number'],name=p['name']) for p in manifest['parts']]
    assert core['schema']=='DAG-physical-evidence-inventory-v1' and digest(wire(core))==manifest['inventory_sha256']
    return core
def verify_archive(folder,manifest):
    core=inventory_from_manifest(manifest);entries=manifest['files'];by_path={e['path']:e for e in entries}
    assert len(by_path)==len(entries)==manifest['original_files'] and manifest['all_originals_physically_stored'] is True
    assert sum(e['bytes'] for e in entries)==manifest['original_bytes']
    for e in entries:
        relative_name(e['path']);assert type(e['part']) is int and 1<=e['part']<=len(manifest['parts'])
    parts=[];verified=set()
    for number,part in enumerate(manifest['parts'],1):
        assert part['number']==number and part['name']==PART_STEM+'%03d.zip'%number
        archive=local(folder,part['name']);actual=pin(archive)
        assert wire(actual)==wire({k:part[k] for k in ('bytes','sha256')}) and actual['bytes']<=MAX_PART and actual['bytes']<50*1024*1024
        expected={e['path'] for e in entries if e['part']==number}
        with zipfile.ZipFile(archive) as z:
            assert len(z.namelist())==len(set(z.namelist())) and set(z.namelist())==expected|{INTERNAL}
            assert z.read(INTERNAL)==wire(core) and z.testzip() is None
            for name in sorted(expected):
                e=by_path[name];assert name not in verified and z.getinfo(name).file_size==e['bytes']
                with z.open(name) as stream:p=stream_pin(stream)
                assert wire(p)==wire({k:e[k] for k in ('bytes','sha256')});verified.add(name)
        parts.append(dict(number=number,name=part['name'],**actual,CRC='PASS'))
    assert verified==set(by_path)
    return dict(status='PASS',original_files=len(entries),all_original_files_physically_stored=True,
        all_original_paths_byte_verified=True,all_CRC_verified=True,parts=parts)
