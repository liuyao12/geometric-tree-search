"""Passive DAG-reuse/backend evidence audit and reader summary.

Stdlib only. No compressor, scientific module, kernel, decoder, encoder,
evaluator, tile checker, proof search or DP/control proof is executed/read.
Large circuit/ribbon arrays are streamed for exact byte digests and counts;
their semantics remain the separately recorded independent checker claims.
This assembler is scoped to the available QUALIFIED arithmetic dataset; it
does not provide a missing-qualification fallback or manufacture any receipt.
"""
import collections
import copy
import gc
import gzip
import hashlib
import json
import math
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
MASTER=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md')
PHASES=('qualify-arithmetic','reuse-incidence','backend-arithmetic','backend-incidence')


def wire(value):
    return (json.dumps(value,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')


def sha(value):
    digest=hashlib.sha256()
    for part in json.JSONEncoder(sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False).iterencode(value):
        digest.update(part.encode('ascii'))
    digest.update(b'\n')
    return digest.hexdigest()


def pin(path):
    total=0;digest=hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda:stream.read(1048576),b''):
            total+=len(chunk);digest.update(chunk)
    return dict(bytes=total,sha256=digest.hexdigest())


def local(name):
    path=(ROOT/name).resolve()
    assert not Path(name).is_absolute() and path.is_relative_to(ROOT),name
    return path


def read(name):
    path=local(name)
    with (gzip.open(path,'rt',encoding='ascii') if path.suffix=='.gz' else path.open('r',encoding='ascii')) as stream:
        return json.load(stream)


def save(name,value):
    path=ROOT/name;path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as stream:stream.write(wire(value))
    return dict(path=name,**pin(path))


class JSONStream:
    """Canonical saved-JSON projection; skip array values without building them."""
    def __init__(self,stream):
        self.stream=stream;self.buffer=b'';self.offset=0

    def peek(self):
        if self.offset==len(self.buffer):
            self.buffer=self.stream.read(1048576);self.offset=0
        if not self.buffer:raise EOFError('Unfinished saved JSON')
        return self.buffer[self.offset]

    def take(self,count=1):
        output=[]
        while count:
            self.peek();size=min(count,len(self.buffer)-self.offset)
            output.append(self.buffer[self.offset:self.offset+size]);self.offset+=size;count-=size
        return b''.join(output)

    @staticmethod
    def update(hashers,data):
        for digest in hashers:digest.update(data)

    def token(self,parents=(),capture=True,max_capture=16777216):
        """One JSON value, keeping exact serialized bytes/array element count."""
        first=self.peek();own=hashlib.sha256();hashers=tuple(parents)+(own,)
        chunks=[];size=0;elements=None
        if first in (ord('{'),ord('[')):
            stack=[];quoted=False;escape=False;seen_array_value=False
            if first==ord('['):elements=0
            done=False
            while not done:
                self.peek();begin=self.offset
                while self.offset<len(self.buffer):
                    char=self.buffer[self.offset];self.offset+=1
                    if quoted:
                        if escape:escape=False
                        elif char==92:escape=True
                        elif char==34:quoted=False
                    else:
                        if elements is not None and len(stack)==1 and stack[0]==91:
                            if char not in (9,10,13,32,44,93) and not seen_array_value:
                                elements=1;seen_array_value=True
                            elif char==44:elements+=1
                        if char==34:quoted=True
                        elif char in (123,91):stack.append(char)
                        elif char in (125,93):
                            assert stack and ((stack[-1]==123 and char==125) or (stack[-1]==91 and char==93))
                            stack.pop()
                            if not stack:done=True;break
                    if done:break
                part=self.buffer[begin:self.offset];self.update(hashers,part);size+=len(part)
                if capture:
                    assert size<=max_capture,'Saved small field exceeded projection cap'
                    chunks.append(part)
        elif first==34:
            escaped=False;initial=True
            while True:
                char=self.take();self.update(hashers,char);size+=1
                if capture:chunks.append(char)
                if initial:initial=False;continue
                if escaped:escaped=False
                elif char==b'\\':escaped=True
                elif char==b'"':break
                assert size<=max_capture,'Saved string exceeded projection cap'
        else:
            value=[]
            while self.peek() not in (9,10,13,32,44,93,125):
                char=self.take();self.update(hashers,char);size+=1;value.append(char)
            if capture:chunks=value
        own.update(b'\n')
        info=dict(canonical_value_sha256=own.hexdigest(),serialized_value_bytes=size)
        if elements is not None:info['array_items']=elements
        return (json.loads(b''.join(chunks)) if capture else None),info

    def object(self,skip=frozenset(),nested=None,parents=()):
        nested={} if nested is None else nested
        own=hashlib.sha256();hashers=tuple(parents)+(own,)
        char=self.take();assert char==b'{';self.update(hashers,char)
        value={};omitted={};field_info={}
        if self.peek()==125:
            self.update(hashers,self.take())
        else:
            while True:
                key,_=self.token(hashers,capture=True,max_capture=4096)
                assert type(key) is str and key not in value and key not in omitted
                char=self.take();assert char==b':';self.update(hashers,char)
                if key in nested:
                    child,info=self.object(parents=hashers,**nested[key])
                    value[key]=child;field_info[key]=info
                else:
                    child,info=self.token(hashers,capture=key not in skip)
                    if key in skip:omitted[key]=info
                    else:value[key]=child
                    field_info[key]=info
                char=self.take();self.update(hashers,char)
                if char==b'}':break
                assert char==b','
        own.update(b'\n')
        return value,dict(canonical_value_sha256=own.hexdigest(),omitted=omitted,fields=field_info)


def project_large(name,kind):
    path=local(name)
    nested=({'circuit':dict(skip=frozenset(('gates',)))} if kind=='circuit' else
            {'certificate':dict(skip=frozenset(('gate_bits','rows')))} if kind=='ribbon' else {})
    skip=frozenset(('gate_bits',)) if kind=='evaluation' else frozenset()
    with (gzip.open(path,'rb') if path.suffix=='.gz' else path.open('rb')) as stream:
        reader=JSONStream(stream);value,info=reader.object(skip=skip,nested=nested)
        remainder=reader.buffer[reader.offset:]+stream.read()
        assert remainder==b'\n','Noncanonical or unfinished saved wrapper'
    return value,info


def normalized_ast(ast):
    tag=ast[0]
    if tag=='var':return list(ast)
    if tag in ('fun','pred'):return [tag,ast[1],[normalized_ast(a) for a in ast[2]]]
    if tag=='all':return [tag,ast[1],normalized_ast(ast[2])]
    if tag=='not':return [tag,normalized_ast(ast[1])]
    if tag=='bot':assert len(ast)==1;return ['bot']
    left,right=normalized_ast(ast[1]),normalized_ast(ast[2])
    if tag=='and':return ['not',['imp',left,['not',right]]]
    if tag=='or':return ['imp',['not',left],right]
    assert tag in ('eq','imp');return [tag,left,right]


def line_projection(proof):
    fields=dict(axiom=('name',),mp=('antecedent','implication'),generalize=('source','variable'),
        instantiate=('universal','term'),refl=(),eq_subst=('variable','template','left','right'),
        distribute=('variable','antecedent','consequent'),tautology=(),ax1=(),ax2=(),ax3=(),bot_false=())
    ast_keys={'formula','universal','term','template','left','right'}
    result=[]
    for line in proof:
        rule=line['rule'];keys=ast_keys|({'antecedent','consequent'} if rule=='distribute' else set())
        row={k:normalized_ast(line[k]) if k in keys else line[k] for k in ('rule','formula')+fields[rule]}
        if rule in ('ax1','ax2','ax3','bot_false'):row['rule']='tautology'
        result.append(row)
    return result


class Audit:
    def __init__(self):
        self.refs={};self.files={};self.stages=[];self.phase_rows={};self.findings=[]

    def ref(self,reference):
        assert type(reference) is dict and {'path','bytes','sha256'}<=set(reference)
        name=reference['path'];expected={k:reference[k] for k in ('bytes','sha256')}
        if name not in self.refs:assert pin(local(name))==expected,name;self.refs[name]=expected
        else:assert self.refs[name]==expected,name
        return name

    def load(self,reference):
        return read(self.ref(reference))

    def file(self,name):
        reference=dict(path=name,**pin(local(name)));self.files[name]={k:reference[k] for k in ('bytes','sha256')}
        return reference

    def provenance(self):
        protocol=read('data/protocol-frozen-v1.json')
        assert protocol['schema']=='Proof-DAG-reuse-prospective-protocol-v1' and protocol['status']=='FROZEN'
        assert protocol['phases']==list(PHASES)
        current={p.relative_to(ROOT).as_posix():pin(p) for folder in ('source','reference','plan','input')
            for p in sorted((ROOT/folder).rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}
        current['review/input-snapshot-v1.json']=pin(local('review/input-snapshot-v1.json'))
        assert current==protocol['pins']
        assert pin(Path(protocol['runtime']['path']))=={k:protocol['runtime'][k] for k in ('bytes','sha256')}
        assert pin(MASTER)=={k:protocol['master'][k] for k in ('bytes','sha256')}
        assert pin(local('reference/basic-tiling-algorithm.md'))==pin(MASTER)
        declared=read('reference/source-pins-v1.json')
        for item in declared['unchanged']+declared['variants']:
            assert pin(local(item['path']))=={k:item[k] for k in ('bytes','sha256')}
        snapshot=read('review/input-snapshot-v1.json')
        assert snapshot['status']=='EXACT_POINT_SEARCH_INPUTS_COPIED' and snapshot['source_kind']=='POINT_SEARCH'
        assert snapshot['control_proof_used'] is False and len(snapshot['files'])==8
        for entry in snapshot['files']:self.ref(entry)
        phases={}
        for phase in PHASES:
            started_name='data/'+phase+'-started-v1.json'
            observer_name='review/'+phase+'-observer-v1.json'
            invocation_name='review/'+phase+'-invocation-v1.json'
            row=dict(phase=phase,status='NOT_STARTED',execution_admitted=False)
            started=observer=invocation=None
            if local(started_name).exists():
                started=read(started_name);row.update(status='INCOMPLETE_NO_TERMINAL_OBSERVER',started=self.file(started_name))
                assert started['status']=='STARTED' and started['phase']==phase
                assert type(started['pid']) is int and started['pid']>0
                assert started['protocol']==dict(path='data/protocol-frozen-v1.json',**pin(local('data/protocol-frozen-v1.json')))
            if local(observer_name).exists():
                observer=read(observer_name)
                assert observer['phase']==phase
                if started is not None:assert started['pid']==observer['pid']
                if observer.get('log'):self.ref(observer['log'])
                row.update(status=observer['status'],observer=self.file(observer_name),
                    native_exit_code=observer['native_exit_code'],guard_reason=observer['guard_reason'],
                    frozen_postcheck_error=observer['frozen_postcheck_error'],wall_seconds=observer['wall_seconds'],
                    peak_observed_rss_bytes=observer['peak_observed_rss_bytes'])
                for line in local(observer['log']['path']).read_text(encoding='ascii',errors='replace').splitlines():
                    try:value=json.loads(line)
                    except ValueError:continue
                    if type(value) is dict and 'stage' in value and 'seconds' in value:
                        self.stages.append(dict(phase=phase,**value))
            if local(invocation_name).exists():
                invocation=read(invocation_name);assert invocation['phase']==phase
                row.update(invocation=self.file(invocation_name),worker_status=invocation['status'],
                    worker_scientific_status=invocation['scientific_status'],worker_seconds=invocation['seconds'],
                    native_lifetime_maxrss=invocation['maxrss'],native_lifetime_maxrss_units=invocation['maxrss_units'])
            row['execution_admitted']=bool(started is not None and observer is not None and invocation is not None
                and observer['status']=='COMPLETE' and observer['native_exit_code']==0
                and observer['guard_reason'] is None and observer['frozen_postcheck_error'] is None
                and invocation['status']=='COMPLETE')
            phases[phase]=row
        self.phase_rows=phases
        return dict(protocol=self.file('data/protocol-frozen-v1.json'),source_and_input_pins=current,
            runtime=protocol['runtime'],current_master=protocol['master'],input_snapshot=self.file('review/input-snapshot-v1.json'),
            declared_dependencies=self.file('reference/source-pins-v1.json'),phases=phases,
            guards=protocol['process_guards'],backend_caps=protocol['backend_caps'],
            scope='Current frozen source/reference/plan/input set, runtime, master and copied original input bytes joined. RSS polling and native lifetime high-water are reported separately. Nonzero/guarded or unfinished phases remain unadmitted. No historical search or checker is rerun.')

    def admitted_result(self,result,phase,*,prerequisite=True):
        """Separate retained scientific status from process/prerequisite admission."""
        admitted=self.phase_rows[phase]['execution_admitted']
        return dict(result,saved_scientific_status=result['status'],phase=self.phase_rows[phase],
            execution_admitted=admitted,prerequisite_admitted=prerequisite,
            status=result['status'] if admitted and prerequisite else 'UNADMITTED_EXECUTION_OR_PREREQUISITE')

    def source_case(self,case):
        files={x['path']:x for x in read('review/input-snapshot-v1.json')['files']}
        refs={}
        for key,suffix in (('prepared','prepared.json.gz'),('raw','search-raw.json.gz'),
                           ('native','native-check.json'),('graph','graph-check.json')):
            refs[key]=files['input/'+case+'-'+suffix];self.ref(refs[key])
        prepared=self.load(refs['prepared']);native=self.load(refs['native']);graph=self.load(refs['graph'])
        raw=self.load(refs['raw']);compiled=prepared['compiled'];statement=dict(theory=compiled['theory'],goal=compiled['goal'])
        assert raw['mode']=='MARKS' and raw['result']['status']=='SAT'
        assert native['status']==native['tree']['status']==native['native_fol_kernel']['status']=='VERIFIED'
        assert graph['status']=='VERIFIED' and graph['run_status']=='SAT'
        proof=native['decoded']['proof']
        assert native['decoded']['target']==statement['goal']
        assert sorted(raw['result']['selected'])==native['decoded']['tree']['selected']
        assert graph['model_sha256']==raw['result']['model_sha256']
        lane=prepared['lanes']['MARKS']
        assert raw['model']==lane['model']
        # These admitted input files already store the canonical model and row
        # order used by their checker. Bind exact values, not a new normalizer.
        assert sha(raw['model'])==graph['model_sha256']
        context_join=dict(status='PASS_SAVED_CONTEXT_BINDING',model_sha256=sha(raw['model']))
        if 'universe' in lane:
            assert sha(lane['universe'])==graph['universe_sha256']
            assert raw['universe_ref']['pointer']=='/lanes/MARKS/universe'
            context_join.update(universe_sha256=graph['universe_sha256'],hash_scope='SAVED_COMPLETE_CANONICAL_ROWS')
        else:
            assert sha(lane['descriptor'])==graph['universe_descriptor_sha256']
            assert graph['universe_sha256'] is None
            assert graph['universe_hash_scope']=='INTENSIONAL_DESCRIPTOR_NOT_EXPANDED_ROW_STREAM'
            assert lane['descriptor_check']['descriptor_sha256']==graph['universe_descriptor_sha256']
            assert lane['descriptor_check']['status']=='VERIFIED'
            assert raw['universe_ref']['pointer']=='/lanes/MARKS/descriptor'
            assert raw['native_context_ref']['pointers']==dict(compiled='/compiled',
                generation='/generation',certificate='/failure_certificate')
            context_join.update(universe_descriptor_sha256=graph['universe_descriptor_sha256'],
                hash_scope=graph['universe_hash_scope'])
        assert graph['counts']['observations_checked']==len(raw['observations'])==raw['result']['event_extent']['total']
        assert native['native_fol_kernel']['checked_lines']==len(proof)
        for reference_key in ('prepared_ref','universe_ref','native_context_ref'):
            if reference_key in raw:
                # Historical paths are not rewritten into this new root; bind
                # the copied exact prepared file by its stored byte identity.
                historical=raw[reference_key]
                assert {k:historical[k] for k in ('bytes','sha256')}=={k:refs['prepared'][k] for k in ('bytes','sha256')}
        source=dict(case=case,refs=refs,statement=statement,proof=proof,compiled=compiled,
            native=native,graph=graph,theory_reader=prepared['theory_reader'],
            source_run_id=raw['id'],inherited_search_seconds=raw['search_seconds'],source_context_join=context_join)
        del prepared,raw;gc.collect()
        return source

    def reuse(self,source):
        case=source['case'];name='data/reuse/'+case+'/result.json'
        if not local(name).exists():return dict(id=case,status='PENDING_REUSE',artifacts={}),None
        result=read(name);artifacts=result['artifacts']
        phase='qualify-arithmetic' if case=='arithmetic' else 'reuse-incidence'
        phase_row=self.phase_rows[phase]
        if case=='incidence' and phase_row.get('worker_status')=='COMPLETE':
            assert phase_row['worker_scientific_status']==result['status']
        for reference in artifacts.values():self.ref(reference)
        declaration=self.load(artifacts['source_declaration'])
        assert result['original_statement_sha256']==declaration['statement_sha256']==sha(source['statement'])
        assert result['original_proof_sha256']==declaration['original_proof_sha256']==sha(source['proof'])
        assert declaration['provenance']['source_kind']=='POINT_SEARCH'
        assert declaration['provenance']['control_proof_used'] is False
        expected_source_refs={label:{k:source['refs'][key][k] for k in ('path','bytes','sha256')}
            for label,key in (('source_raw','raw'),('source_native_check','native'),
                ('source_graph_check','graph'),('original_compiled','prepared'))}
        expected_source_refs['original_compiled']['pointer']='/compiled'
        assert declaration['source_artifacts']==expected_source_refs
        assert declaration['provenance']['source_run_id']==source['source_run_id']
        assert declaration['provenance']['mode']=='MARKS'
        assert declaration['provenance']['original_proof_sha256']==sha(source['proof'])
        assert declaration['provenance']['input_snapshot_sha256']==pin(local('review/input-snapshot-v1.json'))['sha256']
        for label,reference in declaration['source_artifacts'].items():self.ref(reference)
        packet=self.load(artifacts['compression'])
        if packet['status']!='COMPRESSED_UNVERIFIED':
            assert result['status'] in ('UNKNOWN','REJECTED_INPUT','ERROR')
            return self.admitted_result(result,phase),packet
        assert packet['provenance']==declaration['provenance']
        original=self.load(artifacts['original_proof']);compressed=self.load(artifacts['compressed_proof'])
        assert original==source['proof']==packet['original_proof']
        assert compressed==packet['compressed_proof']
        assert packet['original_statement']==source['statement']
        assert packet['original_statement_sha256']==sha(source['statement'])
        assert packet['original_proof_sha256']==sha(original)
        assert packet['compressed_proof_sha256']==sha(compressed)==result['compressed_proof_sha256']
        assert original[-1]['formula']==compressed[-1]['formula']==source['statement']['goal']
        original_B=self.load(artifacts['original_native']);compressed_B=self.load(artifacts['compressed_native'])
        wrappers=self.load(artifacts['native_receipt_bindings']);mapping=self.load(artifacts['mapping'])
        for label,proof,receipt in (('original',original,original_B),('compressed',compressed,compressed_B)):
            assert wrappers[label]['statement_sha256']==sha(source['statement'])
            assert wrappers[label]['proof_sha256']==sha(proof) and wrappers[label]['receipt']==receipt
            if receipt['status']=='VERIFIED':assert receipt['checked_lines']==len(proof)
        if result['status']=='VERIFIED_PROOF_REUSE':
            assert original_B['status']==compressed_B['status']==mapping['status']=='VERIFIED'
            assert mapping['mapping']['status']=='VERIFIED'
            assert mapping['provenance']['status']=='VERIFIED_CONTENT_BINDING'
            assert mapping['native_receipt_interfaces']['status']=='BOUND_VERIFIED_RECEIPTS'
            assert mapping['logical_validity']=='NOT_RUN_BY_THIS_MODULE'
            assert mapping['mapping']['statement_sha256']==sha(source['statement'])
            assert mapping['mapping']['original_proof_sha256']==sha(original)
            assert mapping['mapping']['compressed_proof_sha256']==sha(compressed)
            assert mapping['provenance']['source_run_id']==source['source_run_id']
            assert mapping['provenance']['mode']=='MARKS'
            assert mapping['provenance']['source_selected_cids_sha256']==sha(source['native']['decoded']['tree']['selected'])
            assert mapping['provenance']['source_proof_sha256']==sha(source['proof'])
            assert mapping['provenance']['original_statement_sha256']==sha(source['statement'])
            assert mapping['provenance']['artifact_refs']==expected_source_refs
            for label,proof,receipt in (('original',original,original_B),('compressed',compressed,compressed_B)):
                interface=mapping['native_receipt_interfaces']['bindings'][label]
                assert interface==dict(status=receipt['status'],
                    statement_sha256=wrappers[label]['statement_sha256'],
                    proof_sha256=wrappers[label]['proof_sha256'],receipt_sha256=sha(wrappers[label]['receipt']))
            expected_maps={k:packet[k] for k in ('original_to_representative','original_to_compressed',
                'compressed_to_original','line_mapping','retained_reference_mapping')}
            assert mapping['mapping']['mapping_digest']==sha(expected_maps)
            assert mapping['mapping']['counts']=={k:v for k,v in packet['metrics'].items() if k!='seconds'}
        assert result.get('metrics')==packet['metrics']
        self.file(name)
        return self.admitted_result(result,phase),packet

    def readers(self,source,packet):
        original=source['native']['proof_reader'];proof=source['proof']
        assert len(original)==len(proof)
        for row,line in zip(original,proof):
            assert row['formula']==line['formula'] and row['rule']==line['rule']
            assert row['formula_latex'] and row['english']
        compressed=[]
        for new,old in enumerate(packet['compressed_to_original']):
            row=copy.deepcopy(original[old]);line=packet['compressed_proof'][new]
            assert row['formula']==line['formula'] and row['rule']==line['rule']
            dependencies=([line['antecedent']+1,line['implication']+1] if line['rule']=='mp'
                          else [line['source']+1] if line['rule']=='generalize' else [])
            assert all(type(i) is int and 0<i<new+1 for i in dependencies)
            row.update(line=new+1,dependencies=dependencies,source_original_line=old+1)
            if line['rule']=='mp':
                row['reason']='Apply the implication on line %d to line %d.'%(dependencies[1],dependencies[0])
            elif line['rule']=='generalize':
                row['reason']='Generalize line %d under the unchanged original hypotheses.'%dependencies[0]
            compressed.append(row)
        return original,compressed

    def backend(self,source,reuse,packet):
        case=source['case'];folder='data/backend/'+case+'/'
        phase=self.phase_rows['backend-'+case];name=folder+'result.json'
        if not local(name).exists():
            present=[p.name for p in local(folder).iterdir()] if local(folder).exists() else []
            return dict(id=case,status='GUARDED_OR_UNFINISHED_BACKEND',phase=phase,artifacts={},
                retained_stage_files=present,scope='No final backend result exists; retained files are not silently promoted or rerun.')
        result=read(name);artifacts=result['artifacts']
        if phase.get('worker_status')=='COMPLETE':assert phase['worker_scientific_status']==result['status']
        for reference in artifacts.values():self.ref(reference)
        assert result['original_statement_sha256']==sha(source['statement'])
        assert result['original_proof_sha256']==sha(source['proof'])
        assert result['compressed_proof_sha256']==packet['compressed_proof_sha256']
        checks={}
        def finish(*,complete=False):
            prerequisite=(reuse['status']=='VERIFIED_PROOF_REUSE' and
                (result['status']!='VERIFIED_COMPRESSED_BACKEND_JOIN' or complete))
            return self.admitted_result(dict(result,checks=checks,content_join_complete=complete),
                'backend-'+case,prerequisite=prerequisite)
        sized=self.load(artifacts['witness_size'])
        checks['witness_size']=dict(status=sized['status'],metrics=sized.get('metrics'),reason=sized.get('reason'))
        if sized['status']!='WITNESS_SIZED_UNVERIFIED':
            return finish()
        assert sized['original_statement']==source['statement']
        assert sized['original_statement_sha256']==sha(source['statement'])
        assert sized['original_compiled_sha256']==sha(source['compiled'])
        assert sized['original_proof_sha256']==sha(source['proof'])
        assert sized['compressed_proof_sha256']==sha(packet['compressed_proof'])
        assert sized['compressed_proof']==packet['compressed_proof']
        raw=sized['raw_certificate'];bounds=sized['bounds'];n=bounds['nodes']
        assert sized['raw_certificate_sha256']==sha(raw)
        assert raw['nodes']==sized['probe_certificate']['nodes'][:n]
        for key in ('functions','predicates','axioms','goal','proof'):assert raw[key]==sized['probe_certificate'][key]
        assert sized['problem_metadata']['node_prefix']==sized['probe_metadata']['node_prefix']
        assert sized['sizing']['nodes']==n and n==1+max(sized['sizing']['used_node_ids'])
        for old,new in zip(sized['probe_certificate']['substitutions'],raw['substitutions']):
            for key in ('source','variable','term','result'):assert old[key]==new[key]
            assert old['active'][:n]==new['active'] and old['map'][:n]==new['map']
        checks['raw_check']=self.load(artifacts['raw_check'])
        if checks['raw_check']['status']!='VERIFIED':return finish()
        raw_check=checks['raw_check']
        assert raw_check['certificate_sha256']==sha(raw) and raw_check['bounds']==bounds
        assert raw_check['checked_nodes']==len(raw['nodes'])==n
        assert raw_check['checked_lines']==len(raw['proof'])==bounds['lines']
        assert raw_check['checked_substitutions']==len(raw['substitutions'])==bounds['substitutions']
        assert raw_check['goal']==raw['goal'] and raw_check['closed_Gamma'] is True
        circuit_value,circuit_stream=project_large(self.ref(artifacts['circuit']),'circuit')
        checks['circuit_stage']=dict(status=circuit_value['status'],reason=circuit_value.get('reason'),
            counts=circuit_value.get('counts'))
        if circuit_value['status']!='COMPILED':return finish()
        circuit=circuit_value['circuit'];info=circuit_stream['fields']['circuit']
        gates=info['omitted']['gates']['array_items'];inputs=circuit['inputs']
        counts=circuit_value['counts'];circuit_hash=info['canonical_value_sha256']
        assert counts['inputs']==len(inputs) and counts['nand_gates']==gates
        assert counts['width']==len(inputs)+gates and counts['height']==gates
        assert counts['nominal_cells']==counts['width']*gates
        if 'bits' not in artifacts:
            return finish()
        bits=self.load(artifacts['bits'])
        checks['encoded_bits']=dict(status=bits['status'],reason=bits.get('reason'))
        if bits['status']!='ENCODED' or 'inverse' not in artifacts:
            return finish()
        inverse=self.load(artifacts['inverse'])
        checks['inverse']=dict(status=inverse['status'],reason=inverse.get('reason'))
        if inverse['status']!='VERIFIED':
            return finish()
        assert inverse['raw_certificate']==raw and inverse['raw_certificate_sha256']==sha(raw)
        assert inverse['input_bits_sha256']==sha(bits['input_bits'])
        assert inverse['input_layout_sha256']==sha(inputs)
        assert inverse['original_statement_sha256']==sha(source['statement']) and inverse['raw_bit_roundtrip'] is True
        statement=dict(theory=dict(functions=source['statement']['theory']['functions'],
            predicates=source['statement']['theory']['predicates'],
            axioms={name:normalized_ast(form) for name,form in source['statement']['theory']['axioms'].items()}),
            goal=normalized_ast(source['statement']['goal']))
        if 'common_statement' not in artifacts or 'decoded_native' not in artifacts:
            return finish()
        human=inverse['human'];common=self.load(artifacts['common_statement'])
        decoded_native=self.load(artifacts['decoded_native'])
        checks.update(common_statement=common,decoded_native=decoded_native)
        if common['status']!='VERIFIED' or decoded_native['status']!='VERIFIED':
            return finish()
        assert human['normalized_original_statement']==common['normalized_statement']==statement
        assert human['theory']==statement['theory'] and human['goal']==statement['goal']
        assert line_projection(human['proof'])==line_projection(packet['compressed_proof'])
        assert common['status']=='VERIFIED' and all(value is True for value in common['checks'].values())
        assert common['original_statement_sha256']==sha(source['statement'])
        assert common['normalized_statement_sha256']==inverse['normalized_statement_sha256']==sha(statement)
        assert decoded_native['status']=='VERIFIED' and decoded_native['checked_lines']==len(human['proof'])
        if 'evaluation' not in artifacts or 'palette' not in artifacts:
            return finish()
        palette=self.load(artifacts['palette']);evaluation,eval_stream=project_large(self.ref(artifacts['evaluation']),'evaluation')
        checks['evaluation']=dict(status=evaluation['status'],acceptance_bit=evaluation.get('acceptance_bit'))
        if evaluation['status']!='EVALUATED' or evaluation.get('acceptance_bit')!=1 or 'ribbon' not in artifacts:
            return finish()
        ribbon,ribbon_stream=project_large(self.ref(artifacts['ribbon']),'ribbon')
        checks['ribbon']=dict(status=ribbon['status'],reason=ribbon.get('reason'))
        if ribbon['status']!='CONSTRUCTED' or 'symbolic' not in artifacts or 'literal' not in artifacts:
            return finish()
        certificate=ribbon['certificate'];cert_info=ribbon_stream['fields']['certificate']
        assert certificate['circuit_sha256']==circuit_hash
        assert certificate['palette_sha256']==sha(palette)
        assert certificate['input_bits']==bits['input_bits'] and len(bits['input_bits'])==len(inputs)
        assert cert_info['omitted']['gate_bits']['canonical_value_sha256']==eval_stream['omitted']['gate_bits']['canonical_value_sha256']
        assert cert_info['omitted']['gate_bits']['array_items']==eval_stream['omitted']['gate_bits']['array_items']==gates
        assert cert_info['omitted']['rows']['array_items']==gates
        symbolic=self.load(artifacts['symbolic']);literal=self.load(artifacts['literal'])
        if symbolic['status']=='VERIFIED':
            assert symbolic['circuit_sha256']==circuit_hash and symbolic['palette_sha256']==sha(palette)
            assert symbolic['certificate_sha256']==cert_info['canonical_value_sha256']
            assert symbolic['height']==gates and symbolic['width']==counts['width']
            assert symbolic['cells']==counts['nominal_cells'] and symbolic['expanded_cells']==0
            assert symbolic['exact_cell_partition_t1'] is True and symbolic['all_literal_edge_interfaces_agree'] is True
            assert symbolic['all_vertical_op_selectors_bound_to_circuit'] is True
        metrics=result.get('metrics')
        if symbolic['status']!='VERIFIED' or metrics is None:
            checks.update(symbolic=symbolic,literal=literal)
            return finish()
        for key in ('inputs','nand_gates','width','height','nominal_cells'):assert metrics[key]==counts[key]
        assert metrics['original_lines']==len(source['proof']) and metrics['compressed_lines']==len(packet['compressed_proof'])
        assert metrics['chosen_nodes']==n and metrics['palette_types']==len(palette['tiles'])==100
        assert metrics['active_tile_instances']==symbolic.get('active_cells')
        assert metrics['ribbon_intervals']==symbolic.get('ribbon_intervals')
        assert metrics['known_input_bits']==sum(row['value'] is not None for row in inputs)
        assert metrics['literal_status']==literal['status'] and metrics['symbolic_status']==symbolic['status']
        assert metrics['symbolic_expanded_cells']==symbolic.get('expanded_cells')
        if result['status']=='VERIFIED_COMPRESSED_BACKEND_JOIN':
            assert symbolic['status']=='VERIFIED' and literal['status'] in ('UNKNOWN','VERIFIED')
        checks.update(inverse=dict(status=inverse['status'],raw_certificate_sha256=inverse['raw_certificate_sha256'],
            input_bits_sha256=inverse['input_bits_sha256'],input_layout_sha256=inverse['input_layout_sha256'],
            original_statement_sha256=inverse['original_statement_sha256'],
            normalized_statement_sha256=inverse['normalized_statement_sha256'],raw_bit_roundtrip=inverse['raw_bit_roundtrip']),
            common_statement=common,decoded_native=decoded_native,symbolic=symbolic,literal=literal,
            streamed_digest_join=dict(status='PASS',circuit_sha256=circuit_hash,palette_sha256=sha(palette),
                ribbon_certificate_sha256=cert_info['canonical_value_sha256'],
                gate_bits_sha256=cert_info['omitted']['gate_bits']['canonical_value_sha256'],
                ribbon_rows=gates,scope='Exact saved canonical-value byte digests and array counts, no gate/circuit/row semantics reevaluated. Full symbolic semantics remain the pinned independent receipt.'))
        self.file(name)
        del inverse,sized,raw,bits,circuit_value,ribbon;gc.collect()
        return finish(complete=True)


def main():
    audit=Audit();provenance=audit.provenance();qualification=read('data/qualification-result-v1.json')
    for row in qualification['controls']:
        audit.ref(row['input']);check=audit.load(row['check'])
        assert row['actual']==check['status'] and row['matched']==(row['actual']==row['expected'])
    assert qualification['status']=='QUALIFIED' and all(row['matched'] for row in qualification['controls'])
    qualification_phase=audit.phase_rows['qualify-arithmetic']
    if qualification_phase.get('worker_status')=='COMPLETE':
        assert qualification_phase['worker_scientific_status']==qualification['status']
    qualification['result_ref']=audit.file('data/qualification-result-v1.json')
    audit.ref(qualification['arithmetic_reuse_result'])
    assert qualification['arithmetic_reuse_result']['path']=='data/reuse/arithmetic/result.json'
    qualification=audit.admitted_result(qualification,'qualify-arithmetic')
    cases=[];backend_palette_hashes=[];pending=[]
    for case in ('arithmetic','incidence'):
        source=audit.source_case(case);reuse,packet=audit.reuse(source)
        if reuse['status']!='VERIFIED_PROOF_REUSE':pending.append('reuse-'+case)
        row=dict(id=case,label='Arithmetic: addition-zero congruence' if case=='arithmetic' else 'Symbolic incidence and stamp congruence',
            statement=source['statement'],statement_sha256=sha(source['statement']),theory_reader=source['theory_reader'],
            source_artifacts=source['refs'],source_run_id=source['source_run_id'],
            inherited_point_search_seconds=source['inherited_search_seconds'],
            source_context_join=source['source_context_join'],reuse=reuse)
        if packet and packet.get('status')=='COMPRESSED_UNVERIFIED':
            original_reader,compressed_reader=audit.readers(source,packet)
            row.update(compression=reuse['artifacts']['compression'],original_proof=reuse['artifacts']['original_proof'],
                compressed_proof=reuse['artifacts']['compressed_proof'],original_proof_reader=original_reader,
                compressed_proof_reader=compressed_reader,compression_metrics=packet['metrics'])
            backend=audit.backend(source,reuse,packet);row['backend']=backend
            symbolic=backend.get('checks',{}).get('symbolic',{})
            if symbolic.get('status')=='VERIFIED':backend_palette_hashes.append(symbolic['palette_sha256'])
            if backend.get('status')!='VERIFIED_COMPRESSED_BACKEND_JOIN':pending.append('backend-'+case)
        else:
            row.update(original_proof_reader=source['native']['proof_reader'],compressed_proof_reader=[],
                backend=dict(status='PENDING_REUSE_ADMISSION',artifacts={}))
            pending.append('reuse-'+case)
        cases.append(row);del source,packet;gc.collect()
    if len(backend_palette_hashes)==2:assert len(set(backend_palette_hashes))==1
    for phase,info in audit.phase_rows.items():
        if not info['execution_admitted']:
            pending.append(phase)
    coverage=dict(reuse_cases=len(cases),verified_reuse_cases=sum(c['reuse']['status']=='VERIFIED_PROOF_REUSE' for c in cases),
        backend_verified_cases=sum(c['backend']['status']=='VERIFIED_COMPRESSED_BACKEND_JOIN' for c in cases),
        controls=dict(collections.Counter(row['actual'] for row in qualification['controls'])),
        actual_compressions=sum('compression' in c['reuse'].get('artifacts',{}) for c in cases),
        additional_proof_searches=0,control_proofs_read=0,
        original_lines={c['id']:c.get('compression_metrics',{}).get('original_lines') for c in cases},
        compressed_lines={c['id']:c.get('compression_metrics',{}).get('retained_lines') for c in cases},
        shared_fixed_palette_sha256=backend_palette_hashes[0] if backend_palette_hashes and len(set(backend_palette_hashes))==1 else None,
        literal_statuses={c['id']:(c['backend'].get('metrics') or {}).get('literal_status') for c in cases},
        pending_or_unadmitted_phases=sorted(set(pending)))
    limitations=[
        'This is post-search exact earlier-fact reuse and backend certification of two existing point-search derivations. No new target proof was searched, no DP/control proof was supplied and no GCTS/RL novelty or speed advantage follows from fewer proof lines.',
        'Compressed proofs retain exactly the same original hypotheses and goal; original proofs/native receipts remain separate. The reuse algorithm is deterministic literal formula sharing plus backward slicing, not globally optimal proof minimization.',
        'Backend node sizing is witness-dependent after observing each actual compressed proof. It is minimal only for the retained stable-ID encoding, not a prospective proof-search bound or optimal encoding theorem.',
        'The node cap alone changes from64 to128; other logical rules/resources and the2M NAND cap remain as declared. A chosen bound above64 demonstrates a representation resource need, not a stronger mathematical logic.',
        'Conjunction/disjunction receive explicitly recorded notation expansion in the raw backend. The inverse/common-statement join and fresh decoded native-B check certify that declared normalization; there is no silent target/theory substitution.',
        'Symbolic ribbons certify the saved large finite Wang grid using transport lemmas and all interior operation-selector pins. Literal expansion remains UNKNOWN where the cell cap refuses it; zero expanded cells is not literal grid checking or primitive tile proof search.',
        'The assembler streams large arrays only for exact saved canonical-value digests and counts. It reruns no mapping checker, native/raw checker, encoder/decoder, circuit evaluator or symbolic/literal tile verifier.',
        'This assembler requires the available QUALIFIED arithmetic qualification dataset and its saved controls; a missing qualification file is an unsupported input, not an automatically summarized fallback. Per-phase process admission requires matching phase names/PIDs and complete original started/observer/worker receipts with native exit zero and no guard or frozen-postcheck error. Retained child scientific statuses alone cannot make a case green.',
        'Resource/guarded/unfinished phases remain explicit and cannot be promoted from a partial artifact. Sampled RSS and native lifetime maxrss are distinct; a polling guard is not a strict instantaneous memory limit.',
        'The incidence statement is a one-sorted symbolic incidence/equality fragment, not full Hilbert geometry; arithmetic uses an addition-zero/congruence fragment without induction or full PA.',
        'No universal practical proof search on one fixed Wang palette, whole-plane tiling result, new RL training or general ATP comparison is established.'
    ]
    costs=dict(phases=provenance['phases'],saved_stage_logs=audit.stages,
        reuse_seconds={c['id']:c['reuse'].get('seconds') for c in cases},
        backend_seconds={c['id']:c['backend'].get('seconds') for c in cases},
        inherited_search_seconds={c['id']:c['inherited_point_search_seconds'] for c in cases},
        scope='Reuse/backend clocks include their actual guarded work and persistence. Historical point-search times are inherited context, not rerun measurements or additive fresh costs. Stage log clocks include each function plus artifact persistence and overlap phase totals.')
    for name in ('review/assemble_dag_results_v1.py','review/assemble_dag_results_v2.py',
                 'review/root-source-review-v1.json','review/root-driver-source-review-v1.json'):
        audit.file(name)
    status='VERIFIED_POSTSEARCH_REUSE_AND_BACKEND_JOINS' if not pending else 'EXECUTED_WITH_UNKNOWN_OR_PENDING_PHASES'
    receipt=dict(schema='DAG-reuse-passive-evidence-audit-v1',status='PASS_SAVED_DATA_AUDIT',
        scientific_summary_status=status,coverage=coverage,provenance=provenance,
        verified_artifact_refs=audit.refs,files=audit.files,stage_costs=audit.stages,
        scope=__doc__,limitations=limitations)
    audit_ref=save('review/saved-data-audit-v1.json',receipt)
    summary=dict(schema='DAG-reuse-saved-summary-v1',status=status,cases=cases,coverage=coverage,
        qualification=qualification,costs=costs,provenance=provenance,limitations=limitations,saved_data_audit=audit_ref,
        reader_scope='Original formula/English/native-reader rows retained; compressed line/dependency numbers and reference reasons remapped from retained original indices. No translator or proof checker runs in report assembly.')
    summary_ref=save('data/report-summary-v1.json',summary)
    print(json.dumps(dict(status=receipt['status'],summary_status=status,audit=audit_ref,summary=summary_ref,
        coverage=coverage),sort_keys=True))


if __name__=='__main__':
    main()
