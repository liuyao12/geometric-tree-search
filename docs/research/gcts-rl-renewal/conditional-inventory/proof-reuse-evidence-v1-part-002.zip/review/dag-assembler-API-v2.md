# Passive DAG assembler, version 2

The Source-only entry point is `review/assemble_dag_results_v2.py::main()`. Version 1 remains byte-identical. Neither version has been executed by this author. All changes are confined to `review/`; frozen `source/`, `reference/`, `plan/` and `input/` files remain unchanged.

The summary/reader ABI and exclusive output names remain unchanged:

- `review/saved-data-audit-v1.json`: schema `DAG-reuse-passive-evidence-audit-v1`, status `PASS_SAVED_DATA_AUDIT`, and separate `scientific_summary_status`.
- `data/report-summary-v1.json`: schema `DAG-reuse-saved-summary-v1`; success status `VERIFIED_POSTSEARCH_REUSE_AND_BACKEND_JOINS`, otherwise `EXECUTED_WITH_UNKNOWN_OR_PENDING_PHASES`.

This assembler is scoped to the available arithmetic qualification result with saved status `QUALIFIED` and all matched controls. It does not promise a fallback for a missing qualification dataset. Changed pinned bytes, contradictory phase identities/PIDs or contradictory completed worker/result statuses fail the audit rather than producing a pass.

Each phase now has `execution_admitted`. This requires the original started receipt, terminal observer and worker invocation; all phase names must match the requested phase, started and observer PIDs must match, the protocol ref must match exact frozen bytes, the observer must be complete with native exit zero and no guard or frozen-postcheck error, and the worker must be complete. A cleanly completed scientific `UNKNOWN` can have process admission without a green scientific result. The arithmetic qualification worker status joins to the qualification result, incidence reuse joins to its reuse result, and each backend joins to its backend result.

Per-case `reuse` and `backend` retain `saved_scientific_status`, `execution_admitted`, `prerequisite_admitted` and `phase`. Their displayed/admitted `status` becomes `UNADMITTED_EXECUTION_OR_PREREQUISITE` when admission fails. Backend green admission additionally requires admitted reuse and the complete saved-content join. Early stage refusals cannot leave a retained backend green status. Qualification carries the same process/admitted distinction. Existing coverage counts use admitted statuses; phase gaps remain explicit.

Additional exact saved-data joins are:

- Raw checker certificate digest, bounds, node/line/substitution census, goal and closed-hypothesis flag to the sized raw certificate.
- Mapping native receipt interfaces to both complete wrappers and actual separately saved native receipts, including status and statement/proof/receipt digests.
- Mapping provenance to the actual copied source run, MARKS mode, selected IDs, proof, statement, exact source artifact refs and the compiled pointer.
- Original raw model to the saved MARKS model, and their exact stored canonical model digest to graph/result receipts. Arithmetic's already canonical complete row array is digest-bound to its full-universe receipt. Incidence's descriptor digest and declared intensional hash scope are bound separately, with no expanded-universe digest claim. Native-context and universe pointers and prepared-file byte identities are checked.

`cases[*].source_context_join` records this final context binding. These admitted input files already have the canonical ordering used by their graph checkers; this assembler checks those exact saved values rather than implementing another graph normalizer.

Original/compressed proof refs and reader arrays are unchanged. The assembler only remaps retained source line/dependency indices, streams saved large arrays for value digests/census and checks saved receipt joins. It imports stdlib only and executes no compressor, proof/native/raw checker, decoder, encoder, circuit evaluator, tiling checker, search or DP/control. Mapping, native validity, byte custody and native process admission remain distinct gates.

The complete Source diff is `review/dag-assembler-v1-to-v2.patch`. Root must review the new Source before executing it. Output files are opened exclusively, so any prior attempt must be preserved and handled explicitly rather than overwritten.
