# Passive DAG assembler: Source-only handoff

The entry point is `review/assemble_dag_results_v1.py::main()`. It imports stdlib only. It has not been executed by its author. No scientific checker/encoder/decoder/evaluator/search is invoked, and no frozen `source/`, `reference/`, `plan/` or `input/` file is changed.

Its exclusive outputs are:

- `review/saved-data-audit-v1.json`, with `schema='DAG-reuse-passive-evidence-audit-v1'`, `status='PASS_SAVED_DATA_AUDIT'`, and a separate `scientific_summary_status`.
- `data/report-summary-v1.json`, with `schema='DAG-reuse-saved-summary-v1'`.

If all original terminal observers and both native/mapping/backend joins remain admitted, the summary status is `VERIFIED_POSTSEARCH_REUSE_AND_BACKEND_JOINS`. A missing/guarded/incomplete phase or nonadmitted case instead yields `EXECUTED_WITH_UNKNOWN_OR_PENDING_PHASES` plus explicit coverage/pending fields; it is not silently reconstructed, rerun or promoted from a partial artifact. Changed pinned bytes or contradictory completed receipts fail the audit instead of writing a pass.

`cases` contains arithmetic and incidence. Each has:

```text
id, label, statement, statement_sha256, theory_reader,
source_artifacts, source_run_id, inherited_point_search_seconds,
reuse: complete saved reuse record with gates/metrics/artifacts,
compression: direct pinned compression packet ref,
original_proof: direct pinned proof ref,
compressed_proof: direct pinned proof ref,
original_proof_reader: embedded stored native-reader rows,
compressed_proof_reader: retained original rows, new line/dependencies/reason,
compression_metrics,
backend: saved result plus phase execution status and small checks/receipts.
```

Every proof formula/English display value comes from the retained original native reader. The compressed line number, dependency list and rule-reference reason are remapped using the saved retained-source index and compressed native line. No theorem translator runs. The mapping receipt digest binds all maps/counts; the assembler does not execute the mapping algorithm again. Native B validity remains the separately retained original/compressed/decoded receipts.

Top-level fields also include `coverage`, `qualification`, `costs`, `provenance`, `limitations`, `saved_data_audit` and `reader_scope`. The backend's existing `metrics` and artifact refs remain available directly to the renderer, including `nand_gates`, `chosen_nodes`, `compressed_lines`, `nominal_cells`, circuit/ribbon/palette and symbolic/literal receipts. `backend.checks` contains small existing receipts and explicit saved-data joins; no raw gate/row semantic evaluation is repeated.

Large circuit gate arrays, evaluation bit arrays and certificate row/gate-bit arrays are streamed from their exact canonical saved JSON. The projection computes canonical-value SHA256 plus LF and top-level array element counts without retaining those arrays. Circuit/input-layout/bit/ribbon/palette digests are joined to inverse/common-statement and symbolic receipts. Streamed row-content semantics are still the independently executed symbolic checker's claim, not a new grid verification. Complete stored-byte hashes remain distinct from those value digests.

Phase runtime, current master, complete frozen file set, declared Source variants, all eight copied point-search inputs, every stage artifact, both source native proofs and all qualification controls are checked from saved bytes. Historical paths inside copied source raw records are not rewritten: their byte identities are joined to the exact copied prepared input. No DP/control artifact is opened. RSS polling maxima and native lifetime high-water RSS are distinct recorded fields.

Preparation/code/reader audit does not claim a new proof search, optimum proof compression, independent cold timing, stronger logic, primitive large Wang-grid search, literal expansion of the nominal area, or GCTS/RL novelty. Literal UNKNOWN and zero expanded symbolic cells remain visible.
