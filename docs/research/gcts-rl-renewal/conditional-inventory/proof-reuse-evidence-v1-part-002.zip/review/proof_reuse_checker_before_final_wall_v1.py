"""Independent exact-fact reuse mapping and optional receipt-interface audit.

No file reads, compressor imports, proof search, DP/control proof access, encoder
or native logical checker runs. VERIFIED concerns the mapping/content joins
described in the receipt; native validity and artifact-byte custody are separate.
"""
import hashlib
import json
import math
import time

VERSION = 'Independent-exact-proof-reuse-checker-v1'
PACKET_SCHEMA = 'Exact-earlier-fact-proof-DAG-reuse-v1'
LEAF_RULES = frozenset(('axiom','instantiate','refl','eq_subst','distribute',
                       'tautology','ax1','ax2','ax3','bot_false'))
REFS = {'mp':('antecedent','implication'), 'generalize':('source',)}
PACKET_KEYS = frozenset(('schema','status','original_statement','original_statement_sha256',
    'original_proof','original_proof_sha256','compressed_proof','compressed_proof_sha256',
    'original_to_representative','original_to_compressed','compressed_to_original',
    'line_mapping','retained_reference_mapping','metrics','provenance','required_next_checks','scope'))


class Reject(Exception):
    pass


class Bound(Exception):
    pass


def need(condition, reason):
    if not condition:
        raise Reject(reason)


def wire(value):
    return (json.dumps(value,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')


def digest(value):
    return hashlib.sha256(wire(value)).hexdigest()


def same(left,right):
    return wire(left)==wire(right)


class Meter:
    def __init__(self,items,work,seconds):
        need(type(items) is int and items>0 and type(work) is int and work>0,'RESOURCE_INTEGER_LIMITS')
        need(type(seconds) in (int,float) and math.isfinite(seconds) and seconds>0,'RESOURCE_WALL_LIMIT')
        self.limit_items,self.limit_work=items,work
        self.items,self.work=0,0
        self.started=time.monotonic();self.deadline=self.started+seconds

    def tick(self,amount=1):
        self.work+=amount
        if self.work>self.limit_work:
            raise Bound('MAPPING_WORK_BOUND')
        if time.monotonic()>=self.deadline:
            raise Bound('MAPPING_WALL_BOUND')

    def scan(self,value):
        pending=[(value,0)]
        while pending:
            node,depth=pending.pop();self.tick();self.items+=1
            if depth>256:
                raise Bound('MAPPING_JSON_DEPTH_BOUND')
            if type(node) is str:
                self.items+=len(node);self.tick(len(node))
            elif type(node) is int:
                need(node.bit_length()<=256,'JSON_INTEGER_BITS')
            elif node is None or type(node) is bool:
                pass
            elif type(node) is float:
                need(math.isfinite(node),'NONFINITE_JSON')
            elif type(node) is list:
                self.items+=len(node);self.tick(len(node));pending.extend((x,depth+1) for x in node)
            elif type(node) is dict:
                need(all(type(k) is str for k in node),'JSON_OBJECT_KEYS')
                self.items+=2*len(node);self.tick(2*len(node))
                pending.extend((k,depth+1) for k in node)
                pending.extend((x,depth+1) for x in node.values())
            else:
                raise Reject('NATIVE_JSON_REQUIRED')
            if self.items>self.limit_items:
                raise Bound('MAPPING_ITEM_BOUND')

    def formula(self,root):
        """AST container/sort shape only; arities and logical validity stay external."""
        pending=[('formula',root)]
        while pending:
            sort,node=pending.pop();self.tick()
            need(type(node) is list and node and type(node[0]) is str,'FORMULA_AST_CONTAINER')
            tag=node[0]
            if sort=='term':
                if tag=='var':
                    need(len(node)==2 and type(node[1]) is str and node[1],'VARIABLE_AST')
                else:
                    need(tag=='fun' and len(node)==3 and type(node[1]) is str and node[1]
                         and type(node[2]) is list,'FUNCTION_AST')
                    pending.extend(('term',child) for child in node[2])
            elif tag=='pred':
                need(len(node)==3 and type(node[1]) is str and node[1] and type(node[2]) is list,'PREDICATE_AST')
                pending.extend(('term',child) for child in node[2])
            elif tag=='eq':
                need(len(node)==3,'EQUALITY_AST');pending.extend((('term',node[1]),('term',node[2])))
            elif tag in ('imp','and','or'):
                need(len(node)==3,'BINARY_FORMULA_AST');pending.extend((('formula',node[1]),('formula',node[2])))
            elif tag=='all':
                need(len(node)==3 and type(node[1]) is str and node[1],'UNIVERSAL_AST')
                pending.append(('formula',node[2]))
            elif tag=='not':
                need(len(node)==2,'NEGATION_AST');pending.append(('formula',node[1]))
            else:
                need(tag=='bot' and len(node)==1,'FORMULA_TAG')


def _provenance_claim(provenance,proof_hash,meter):
    need(type(provenance) is dict,'PROVENANCE_OBJECT')
    need(provenance.get('source_kind')=='POINT_SEARCH' and provenance.get('search_status')=='SAT'
         and provenance.get('native_status')=='VERIFIED' and provenance.get('control_proof_used') is False,
         'POINT_SEARCH_PROVENANCE_CLAIM_REQUIRED')
    mode=provenance.get('mode')
    need(type(mode) is str and mode and mode.upper() not in ('DP','DP_CONTROL','MEMOIZED','CONTROL'),
         'NO_CONTROL_PROOF_INPUT')
    need(provenance.get('original_proof_sha256')==proof_hash,'PROVENANCE_PROOF_DIGEST')
    meter.tick()


def _mapping(statement,proof,packet,meter):
    need(type(statement) is dict and set(statement)=={'theory','goal'} and type(statement['theory']) is dict,
         'EXACT_ORIGINAL_STATEMENT')
    need(type(proof) is list and proof,'NONEMPTY_ORIGINAL_PROOF')
    need(type(packet) is dict and packet.get('schema')==PACKET_SCHEMA,'COMPRESSION_PACKET_SCHEMA')
    if packet.get('status')=='UNKNOWN':
        raise Bound('UPSTREAM_COMPRESSION_UNKNOWN')
    need(packet.get('status')=='COMPRESSED_UNVERIFIED' and set(packet)==PACKET_KEYS,'COMPRESSION_PACKET_FIELDS_STATUS')
    meter.formula(statement['goal'])
    statement_hash,proof_hash=digest(statement),digest(proof)
    need(same(packet['original_statement'],statement) and packet['original_statement_sha256']==statement_hash,
         'ORIGINAL_STATEMENT_BYTES')
    need(same(packet['original_proof'],proof) and packet['original_proof_sha256']==proof_hash,
         'ORIGINAL_PROOF_BYTES')
    _provenance_claim(packet['provenance'],proof_hash,meter)
    # Define representatives from exact formula-byte classes, independently of
    # all packet-provided maps. Original dependency indices are audited first.
    formulas=[];original_refs=[];first={};representative=[]
    for index,line in enumerate(proof):
        meter.tick()
        need(type(line) is dict and type(line.get('rule')) is str and 'formula' in line,'ORIGINAL_LINE_FIELDS')
        meter.formula(line['formula'])
        rule=line['rule']
        need(rule in LEAF_RULES or rule in REFS,'UNSUPPORTED_NATIVE_REFERENCE_RULE')
        fields=REFS.get(rule,())
        dependencies={}
        for field in fields:
            value=line.get(field)
            need(type(value) is int and 0<=value<index,'STRICT_PRIOR_ORIGINAL_REFERENCE')
            dependencies[field]=value
        original_refs.append(dependencies)
        encoded=wire(line['formula']);meter.tick(len(encoded));formulas.append(encoded)
        if encoded not in first:first[encoded]=index
        representative.append(first[encoded])
    need(formulas[-1]==wire(statement['goal']),'ORIGINAL_FINAL_GOAL')
    remapped=[{field:representative[target] for field,target in dependencies.items()}
              for dependencies in original_refs]
    # Repeated monotone predecessor closure over the chosen goal representative.
    # Only representative lines can enter the set, and every edge goes earlier.
    needed={representative[-1]}
    frontier=list(needed)
    while frontier:
        index=frontier.pop();meter.tick()
        need(representative[index]==index,'INTERNAL_REPRESENTATIVE')
        for target in remapped[index].values():
            need(target<index,'STRICT_PRIOR_REPRESENTATIVE_REFERENCE')
            if target not in needed:needed.add(target);frontier.append(target)
    retained=sorted(needed);new_index={old:i for i,old in enumerate(retained)}
    need(retained and retained[-1]==representative[-1],'GOAL_CLOSURE_ORDER')
    compressed=[];retained_maps=[]
    for new,old in enumerate(retained):
        meter.tick()
        # Copy each retained source field; only known proof-reference fields
        # receive new indices. Every other AST/name/schema payload is unchanged.
        line={field:value for field,value in proof[old].items()}
        for field,target in remapped[old].items():
            need(target in new_index and new_index[target]<new,'STRICT_PRIOR_COMPRESSED_REFERENCE')
            line[field]=new_index[target]
        compressed.append(line)
        retained_maps.append(dict(compressed_index=new,original_representative=old,
            original_references=original_refs[old],representative_references=remapped[old],
            compressed_references={field:line[field] for field in original_refs[old]}))
    need(same(packet['compressed_proof'],compressed),'EXACT_COPIED_RETAINED_LINES')
    need(packet['compressed_proof_sha256']==digest(compressed),'COMPRESSED_PROOF_DIGEST')
    need(same(compressed[-1]['formula'],statement['goal']),'COMPRESSED_FINAL_GOAL')
    orig_to_new=[new_index.get(rep) for rep in representative]
    line_maps=[dict(original_index=i,representative=rep,compressed_index=new_index.get(rep),
        exact_formula_sha256=hashlib.sha256(formulas[i]).hexdigest(),duplicate=i!=rep,
        retained_representative=rep in needed,original_dependencies=original_refs[i],
        representative_dependencies=remapped[i]) for i,rep in enumerate(representative)]
    for name,expected in (
        ('original_to_representative',representative),('original_to_compressed',orig_to_new),
        ('compressed_to_original',retained),('line_mapping',line_maps),
        ('retained_reference_mapping',retained_maps)):
        meter.tick();need(same(packet[name],expected),'EXACT_MAPPING:'+name)
    metrics=packet['metrics']
    need(type(metrics) is dict and set(metrics)=={'original_lines','distinct_formula_representatives',
         'retained_lines','duplicate_lines','unused_representatives','seconds'},'METRIC_FIELDS')
    expected=dict(original_lines=len(proof),distinct_formula_representatives=len(first),
        retained_lines=len(retained),duplicate_lines=len(proof)-len(first),
        unused_representatives=len(first)-len(retained))
    for key,value in expected.items():
        need(type(metrics[key]) is int and metrics[key]==value,'EXACT_COUNT:'+key)
    seconds=metrics['seconds']
    need(type(seconds) in (int,float) and math.isfinite(seconds) and seconds>=0,'COMPRESSION_SECONDS_METADATA')
    need(type(packet['required_next_checks']) is list and len(packet['required_next_checks'])==3 and
         all(type(s) is str and s for s in packet['required_next_checks']),'REQUIRED_NEXT_CHECKS_METADATA')
    need(type(packet['scope']) is str and packet['scope'],'SCOPE_METADATA')
    return dict(status='VERIFIED',statement_sha256=statement_hash,original_proof_sha256=proof_hash,
        compressed_proof_sha256=digest(compressed),counts=expected,
        original_goal_representative=representative[-1],retained_original_indices=retained,
        mapping_digest=digest(dict(original_to_representative=representative,original_to_compressed=orig_to_new,
            compressed_to_original=retained,line_mapping=line_maps,retained_reference_mapping=retained_maps)),
        claim='EXACT_FACT_REUSE_MAPPING_ONLY',
        scope='Earliest literally identical formula representatives, complete backward dependency closure, exact retained source fields and strict earlier-reference remapping under one unchanged statement. No logical proof validity or optimal-compression claim.')


def _refs(artifact_refs,meter):
    need(type(artifact_refs) is dict and {'source_raw','source_native_check','source_graph_check','original_compiled'}<=set(artifact_refs),
         'PROVENANCE_ARTIFACT_REF_SET')
    for label,ref in artifact_refs.items():
        meter.tick()
        need(type(label) is str and type(ref) is dict and {'path','bytes','sha256'}<=set(ref),'ARTIFACT_REF_FIELDS')
        need(type(ref['path']) is str and ref['path'] and type(ref['bytes']) is int and ref['bytes']>=0,
             'ARTIFACT_REF_PATH_BYTES')
        need(type(ref['sha256']) is str and len(ref['sha256'])==64 and all(c in '0123456789abcdef' for c in ref['sha256']),
             'ARTIFACT_REF_SHA256')


def _provenance_binding(statement,proof,packet,binding,meter):
    if binding is None:
        return dict(status='NOT_SUPPLIED',artifact_byte_custody='CALLER_REQUIRED')
    need(type(binding) is dict and set(binding)=={'source_raw','source_native_check','source_graph_check',
         'original_compiled','artifact_refs'},'PROVENANCE_BINDING_FIELDS')
    _refs(binding['artifact_refs'],meter)
    raw,native,graph,compiled=(binding[k] for k in ('source_raw','source_native_check','source_graph_check','original_compiled'))
    need(all(type(value) is dict for value in (raw,native,graph,compiled)),'PROVENANCE_PAYLOAD_OBJECTS')
    need(str(raw.get('kind','')).upper() not in ('DP','DP_CONTROL','MEMOIZED','CONTROL'),'CONTROL_SOURCE_REFUSED')
    need('reader_projection' not in raw,'PROJECTED_READER_IS_NOT_ORIGINAL_SEARCH_EVIDENCE')
    result=raw['result']
    if result.get('status')=='UNKNOWN':
        raise Bound('SOURCE_POINT_SEARCH_UNKNOWN')
    need(result.get('schema')=='Z-growing-point-search-result-v1' and result.get('status')=='SAT',
         'ACTUAL_POINT_SEARCH_SAT_REQUIRED')
    provenance=packet['provenance']
    if 'mode' in raw:
        need(raw['mode']==provenance['mode'],'SOURCE_SEARCH_MODE_BINDING')
    if 'source_run_id' in provenance:
        need(provenance['source_run_id']==raw.get('id'),'SOURCE_SEARCH_ID_BINDING')
    need(same(dict(theory=compiled['theory'],goal=compiled['goal']),statement),'SOURCE_ORIGINAL_STATEMENT')
    if native.get('status')=='UNKNOWN' or native.get('native_fol_kernel',{}).get('status')=='UNKNOWN':
        raise Bound('SOURCE_NATIVE_RECEIPT_UNKNOWN')
    need(native.get('status')=='VERIFIED' and native['tree']['status']=='VERIFIED' and
         native['native_fol_kernel']['status']=='VERIFIED','SOURCE_NATIVE_RECEIPTS_REQUIRED')
    need(native['decoded']['status']=='UNVERIFIED_CERTIFICATE','SOURCE_DECODER_PACKET_STATUS')
    need(same(native['decoded']['proof'],proof) and same(native['decoded']['target'],statement['goal']),
         'SOURCE_ACTUAL_DECODED_PROOF_TARGET')
    selected=result['selected']
    need(type(selected) is list and all(type(cid) is str for cid in selected) and len(selected)==len(set(selected)),
         'SOURCE_SELECTED_CIDS')
    need(same(sorted(selected),native['decoded']['tree']['selected']),'SOURCE_SELECTED_DECODED_TREE')
    need(type(native['native_fol_kernel'].get('checked_lines')) is int and
         native['native_fol_kernel']['checked_lines']==len(proof),'SOURCE_NATIVE_LINE_COUNT')
    if graph.get('status')=='UNKNOWN':
        raise Bound('SOURCE_GRAPH_RECEIPT_UNKNOWN')
    need(graph.get('status')=='VERIFIED' and graph.get('run_status')=='SAT','SOURCE_COMPLETE_GRAPH_RECEIPT_REQUIRED')
    need(graph.get('model_sha256')==result.get('model_sha256') and type(result.get('model_sha256')) is str,
         'SOURCE_GRAPH_MODEL_BINDING')
    if 'observations' in raw:
        need(type(raw['observations']) is list and graph['counts']['observations_checked']==len(raw['observations'])==
             result['event_extent']['total'],'SOURCE_GRAPH_CALLBACK_CENSUS_BINDING')
    return dict(status='VERIFIED_CONTENT_BINDING',source_run_id=raw.get('id'),mode=provenance['mode'],
        source_selected_cids_sha256=digest(sorted(selected)),source_proof_sha256=digest(proof),
        original_statement_sha256=digest(statement),artifact_refs=binding['artifact_refs'],
        artifact_byte_custody='NOT_READ_OR_VERIFIED_BY_THIS_MODULE; CALLER_MUST_VERIFY_EACH_REF_AND_PAYLOAD_JOIN',
        logical_receipt_scope='Existing source receipt fields joined only, not rerun and not independently authenticated here.')


def _native_bindings(statement,proof,packet,bindings,meter):
    if bindings is None:
        return dict(status='NOT_SUPPLIED',original='PENDING_NATIVE_B',compressed='PENDING_NATIVE_B')
    need(type(bindings) is dict and set(bindings)=={'original','compressed'},'NATIVE_RECEIPT_PAIR_REQUIRED')
    rows={};statuses=[]
    for label,value in (('original',proof),('compressed',packet['compressed_proof'])):
        meter.tick();wrapped=bindings[label]
        need(type(wrapped) is dict and set(wrapped)=={'statement_sha256','proof_sha256','receipt'},
             'NATIVE_RECEIPT_WRAPPER_FIELDS')
        need(wrapped['statement_sha256']==digest(statement) and wrapped['proof_sha256']==digest(value),
             'NATIVE_RECEIPT_INPUT_DIGEST_BINDING:'+label)
        receipt=wrapped['receipt'];need(type(receipt) is dict and receipt.get('status') in ('VERIFIED','REJECTED','UNKNOWN'),
             'NATIVE_RECEIPT_STATUS')
        if receipt['status']=='VERIFIED':
            need(type(receipt.get('checked_lines')) is int and receipt['checked_lines']==len(value),
                 'NATIVE_RECEIPT_LINE_COUNT:'+label)
        statuses.append(receipt['status'])
        rows[label]=dict(status=receipt['status'],statement_sha256=wrapped['statement_sha256'],
                        proof_sha256=wrapped['proof_sha256'],receipt_sha256=digest(receipt))
    status='REJECTED' if 'REJECTED' in statuses else 'UNKNOWN' if 'UNKNOWN' in statuses else 'BOUND_VERIFIED_RECEIPTS'
    return dict(status=status,bindings=rows,
        scope='Hash-bound external native-B receipt interfaces only. Caller must actually run the pinned native checker independently on both full proofs and the exact same original theory/goal; this module does not validate a proof or authenticate receipt execution.')


def verify(original_statement,actual_proof,packet,*,provenance_binding=None,native_receipt_bindings=None,
           max_items=100000000,max_work=100000000,wall_seconds=30.0):
    """Return distinct mapping/provenance/native-interface gates.

    A bare VERIFIED result claims mapping correctness only. Missing external
    bindings remain NOT_SUPPLIED; no native validity or artifact custody is
    inferred. Explicit external REJECTED/UNKNOWN statuses stay separate and also
    prevent a top-level VERIFIED outcome.
    """
    started=time.monotonic();meter=None;mapping=None
    try:
        meter=Meter(max_items,max_work,wall_seconds)
        for value in (original_statement,actual_proof,packet,provenance_binding,native_receipt_bindings):meter.scan(value)
        mapping=_mapping(original_statement,actual_proof,packet,meter)
        provenance=_provenance_binding(original_statement,actual_proof,packet,provenance_binding,meter)
        native=_native_bindings(original_statement,actual_proof,packet,native_receipt_bindings,meter)
        status='REJECTED' if native['status']=='REJECTED' else 'UNKNOWN' if native['status']=='UNKNOWN' else 'VERIFIED'
        answer=dict(status=status,mapping=mapping,provenance=provenance,native_receipt_interfaces=native,
            verified_claim='EXACT_REUSE_MAPPING_AND_EXPLICITLY_SUPPLIED_CONTENT_BINDINGS_ONLY',
            logical_validity='NOT_RUN_BY_THIS_MODULE',artifact_byte_custody='CALLER_OWNED',
            required_external_gates=['Independently validate every source artifact byte/hash and decoded payload reference.',
                'Run unchanged native B on original proof with the exact original theory and goal.',
                'Run unchanged native B on compressed proof with that same theory and goal.'])
    except Reject as error:
        answer=dict(status='REJECTED',reason=str(error),mapping=mapping,
                    logical_validity='NOT_RUN_BY_THIS_MODULE',artifact_byte_custody='CALLER_OWNED')
    except (Bound,MemoryError,RecursionError) as error:
        answer=dict(status='UNKNOWN',reason=str(error) or type(error).__name__,mapping=mapping,
                    logical_validity='NOT_RUN_BY_THIS_MODULE',artifact_byte_custody='CALLER_OWNED')
    except (ValueError,KeyError,TypeError,IndexError) as error:
        answer=dict(status='REJECTED',reason='MALFORMED_PACKET:'+type(error).__name__+':'+str(error),mapping=mapping,
                    logical_validity='NOT_RUN_BY_THIS_MODULE',artifact_byte_custody='CALLER_OWNED')
    answer.update(version=VERSION,items=0 if meter is None else meter.items,
        work=0 if meter is None else meter.work,seconds=time.monotonic()-started)
    return answer
