Audit-off shared-point resource diagnostic, 2026-11-03.

Download EVERY resource-diagnostic-evidence-v1-part-NNN.zip and the external
resource-diagnostic-evidence-manifest-v1.json. Each independent ZIP is at most
forty-four MiB. Extract all volumes together; each contains the identical
ARCHIVE-file-manifest-v1.json. Every original path at the cut is physically
stored exactly once with exact byte/SHA256 and CRC checks. No duplicate aliases
or reconstruction recipes replace original bytes.

All CALv2 Sources, exact input/dependency copies, raw results and certificates,
receipts, logs, reviews, plans, reader assets and publication planning files
present at the cut are included. All fifty-one original CALv1 files are also
physically retained under history/first-attempt-v1/files, with a direct original
path submanifest. Generated package outputs cannot archive themselves; receipts
created only after this cut remain later local custody evidence. No scientific
file or historical failure has been deleted or rewritten. Local file paths,
logs and full task evidence are approved for this existing public destination.

Serve the extracted directory and open report/resource-diagnostic-v1.html.
The first CALv1 actual SAT and separately checked five-line proof remain
FAILED_POSTCHECK_AFTER_SCIENCE with native exit one and execution unadmitted.
Seven previously unexecuted CALv2 cases have their own complete process receipts.
The first case was never rerun. Logical proof admission is separate from process
admission; a proof never repairs a failed native exit.

The unchanged semantic slot/remote-mark engine uses a different resource budget
and no full snapshot callback in this timing diagnostic. Exact positive static
point decoding and native checking remain; raw exhausted outcomes are not
independently certified absence. All UNKNOWNs and first attempts remain visible.
The old forward/SAT outputs are historical and are neither rerun nor relabeled.
Seen finite ground pred0/imp cases are not fresh held-out theorems. No full graph
conformance, learned marking, RL advantage, PA/Hilbert or unrestricted FOL
completeness, universal Wang search, or whole-plane result is established.
The overall research program remains ACTIVE.
