"""SOURCE-ONLY until Root review: eight seen audit-off point diagnostics.

No module implementing science is imported before an explicit prospective
freeze. Exact old prepared inputs contain no selected/decoded target witness.
The unchanged engine runs with lexical ordering and audit=None. Only actual SAT
can receive complete independent static point decoding and native-B admission.
Raw UNSAT remains unverified exhaustion/absence UNKNOWN. No trace conformance,
new theorem, RL or comparison against rerun forward/SAT methods is claimed.
"""
import argparse
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
MASTER=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md')
MASTER_SHA='c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9'
PLAN='plan/input-declarations-v1.json'
PROTOCOL='data/protocol-frozen-v1.json'
CAPTURE_LIMIT=268435456
SEMANTIC=('statement','proof','slots','slot_to_native','native_to_slot','reference_mapping',
    'proof_dag','selected','selected_sha256','original_statement_sha256','scope')


class CaptureBound(Exception):
    def __init__(self,reference):super().__init__('JSON_CAPTURE_BOUND');self.reference=reference


def need(condition,reason):
    if not condition:raise ValueError(reason)


def wire(value):
    return (json.dumps(value,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')


def sha(value):
    h=hashlib.sha256()
    for part in json.JSONEncoder(sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False).iterencode(value):h.update(part.encode('ascii'))
    h.update(b'\n');return h.hexdigest()


def local(name):
    need(type(name) is str and not Path(name).is_absolute(),'LOCAL_RELATIVE_PATH')
    path=(ROOT/name).resolve();need(path.is_relative_to(ROOT),'TASK_OWNED_PATH');return path


def pin(path):
    h=hashlib.sha256();size=0
    with path.open('rb') as stream:
        for part in iter(lambda:stream.read(1048576),b''):size+=len(part);h.update(part)
    return dict(bytes=size,sha256=h.hexdigest())


def ref(name):return dict(path=name,**pin(local(name)))


def read(name):
    path=local(name)
    with (gzip.open(path,'rt',encoding='ascii') if path.suffix=='.gz' else path.open('r',encoding='ascii')) as stream:return json.load(stream)


def save(name,value,*,allow_partial=False):
    """Exclusive streaming capture; an over-cap JSON prefix is never a full JSON."""
    path=local(name);path.parent.mkdir(parents=True,exist_ok=True)
    limit=CAPTURE_LIMIT;total=0;complete=True
    encoder=json.JSONEncoder(sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)
    with path.open('xb') as raw:
        output=gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) if path.suffix=='.gz' else raw
        try:
            for text in encoder.iterencode(value):
                part=text.encode('ascii')
                if total+len(part)>limit:
                    output.write(part[:max(0,limit-total)]);total=limit;complete=False;break
                output.write(part);total+=len(part)
            if complete:
                if total==limit:complete=False
                else:output.write(b'\n');total+=1
        finally:
            if output is not raw:output.close()
    reference=dict(path=name,**pin(path),logical_json_bytes=total,complete_json=complete,
        capture_scope='COMPLETE_JSON' if complete else 'EXPLICITLY_PARTIAL_JSON_PREFIX')
    if not complete and not allow_partial:raise CaptureBound(reference)
    return reference


def checked_load(reference):
    name=reference['path'];need(pin(local(name))=={k:reference[k] for k in ('bytes','sha256')},'INPUT_BYTES:'+name)
    return read(name)


def frozen_files():
    paths=[]
    for folder in ('source','reference','input','plan'):
        for path in (ROOT/folder).rglob('*'):
            need(not path.is_symlink(),'NO_FROZEN_SYMLINK')
            if path.is_file() and '__pycache__' not in path.parts and path.suffix!='.pyc':paths.append(path)
    paths.append(local('review/input-dependency-snapshot-v1.json'))
    return [dict(path=p.relative_to(ROOT).as_posix(),**pin(p)) for p in sorted(paths)]


def runtime():
    path=Path(sys.executable).resolve()
    return dict(executable=dict(path=str(path),**pin(path)),version=sys.version,isolated=sys.flags.isolated,
        no_site=sys.flags.no_site,dont_write_bytecode=sys.dont_write_bytecode)


def master_check():
    need(pin(MASTER)['sha256']==pin(local('reference/basic-tiling-algorithm.md'))['sha256']==MASTER_SHA,'CURRENT_AND_COPIED_MASTER')


def freeze():
    need(sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode,'ISOLATED_RUNTIME_REQUIRED')
    need(not local(PROTOCOL).exists(),'NO_REFREEZE');master_check();plan=read(PLAN)
    need(plan['arm']=='AUDIT_OFF_DIAGNOSTIC' and len(plan['cases'])==8,'FIXED_EIGHT_SEEN_CASES')
    need(plan['capture']['max_logical_json_bytes_per_artifact']==CAPTURE_LIMIT,'EXACT_CAPTURE_CEILING')
    need(len({c['id'] for c in plan['cases']})==8,'UNIQUE_PHASE_IDS')
    for dep in plan['source_dependencies']:need(pin(local(dep['ref']['path']))=={k:dep['ref'][k] for k in ('bytes','sha256')},'UNCHANGED_DEPENDENCY_BYTES')
    for case in plan['cases']:
        for value in case['inputs'].values():need(pin(local(value['path']))=={k:value[k] for k in ('bytes','sha256')},'EXACT_SEEN_INPUT_BYTES')
    protocol=dict(schema='Shared-resource-audit-off-protocol-v1',status='FROZEN_BEFORE_SCIENTIFIC_IMPORTS',
        files=frozen_files(),runtime=runtime(),input_declarations=ref(PLAN),phase_ids=[c['id'] for c in plan['cases']],
        point_limits=plan['point_limits'],guards=plan['guards'],native_limits=plan['native_limits'],decoder_limits=plan['decoder_limits'],capture=plan['capture'],
        master=dict(path=str(MASTER),**pin(MASTER)),arm='AUDIT_OFF_DIAGNOSTIC',
        scope='Eight seen same-complete-input positive-proof timing attempts; no snapshots, full trace certificate or independent absence. No forward/SAT rerun or imported target proof.',
        frozen_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()))
    return save(PROTOCOL,protocol)


def unchanged():
    protocol=read(PROTOCOL);need(protocol['status']=='FROZEN_BEFORE_SCIENTIFIC_IMPORTS','FROZEN_STATUS')
    need(protocol['files']==frozen_files(),'EXACT_FROZEN_FILE_SET');need(protocol['runtime']==runtime(),'UNCHANGED_RUNTIME')
    master_check();plan=read(PLAN);need(ref(PLAN)==protocol['input_declarations'],'FROZEN_DECLARATIONS')
    for key in ('point_limits','guards','native_limits','decoder_limits','capture'):need(plan[key]==protocol[key],'FROZEN_'+key)
    return protocol,plan


def module(name,path):
    spec=importlib.util.spec_from_file_location(name,local(path));value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value


def modules():
    return {name:module('resource_diag_'+name,'reference/upstream/'+path) for name,path in dict(
        E='growing_point_search_v2.py',M='shared_fact_model_v1.py',K='shared_fact_checker_v1.py',B='native_fol_checker_v1.py').items()}


def stage(name,fn):
    start=time.perf_counter();value=fn();reference=save(name,value)
    reference['call_seconds']=time.perf_counter()-start
    print(json.dumps(dict(stage=name,status=value.get('status'),seconds=reference['call_seconds'])),flush=True)
    return value,reference


def diagnostic(case,protocol,mods):
    phase=case['id'];base='data/runs/'+phase;start=time.perf_counter();refs={}
    load_start=time.perf_counter();declaration=checked_load(case['inputs']['declaration']);prepared=checked_load(case['inputs']['prepared']);old_gate=checked_load(case['inputs']['original_gate'])
    load_seconds=time.perf_counter()-load_start;catalogue=prepared['catalogue'];model=prepared['model'];binding=case['admitted_input_binding']
    need(declaration['id']==case['source_case_id'] and prepared['statement']==declaration['statement'],'UNCHANGED_DECLARED_STATEMENT')
    need(old_gate['status']==old_gate['basis']['status']=='VERIFIED','REUSED_COMPLETE_BASIS_MODEL_GATE')
    need(all(old_gate[key]==binding[key] for key in binding),'EXACT_REUSED_GATE_BINDING')
    need(sha(model)==binding['model_sha256'] and sha(prepared['universe'])==binding['universe_sha256'],'EXACT_MODEL_UNIVERSE_VALUES')
    need(sha(catalogue)==binding['catalogue_sha256'] and sha(declaration['statement'])==binding['original_statement_sha256'],'EXACT_CATALOGUE_STATEMENT_VALUES')
    need(model['inventory']['placements']==prepared['universe'],'COMPLETE_EXPLICIT_UNIVERSE')
    gate,refs['fresh_input_admission']=stage(base+'/fresh-input-admission.json',lambda:mods['K'].verify(declaration,catalogue,prepared,**protocol['decoder_limits']))
    if gate['status']!='VERIFIED':
        need(gate['status']=='UNKNOWN','INPUT_ADMISSION_REJECTED')
        return dict(status='UNKNOWN_INPUT_ADMISSION',id=phase,raw_engine_status=None,admission=dict(status='UNKNOWN',reason=gate.get('reason')),
            refs=refs,input_load_seconds=load_seconds,seconds=time.perf_counter()-start)
    need(gate['model_sha256']==binding['model_sha256'] and gate['universe_sha256']==binding['universe_sha256'],'FRESH_MODEL_UNIVERSE_ASSOCIATION')
    before=sha(model);search_start=time.perf_counter()
    raw=mods['E'].solve(model,protocol['point_limits'],audit=None,order=None)
    search_seconds=time.perf_counter()-search_start
    need(raw['status'] in ('SAT','UNSAT','UNKNOWN'),'RAW_ENGINE_STATUS')
    # Preserve the actual outcome/certificate first, before possibly large
    # internal checkpoint/event serialization or any decoder/native assurance.
    compact={key:raw[key] for key in ('schema','version','status','reason','model_sha256','selected','certificate',
        'event_extent','rollback_extent','stats','limits','state_hashes')}
    refs['actual_outcome']=save(base+'/actual-engine-outcome.json.gz',compact)
    capture_start=time.perf_counter();refs['raw_result']=save(base+'/raw-engine-result.json.gz',raw,allow_partial=True)
    capture_seconds=time.perf_counter()-capture_start
    need(sha(model)==before,'CALLER_MODEL_UNCHANGED')
    outcome=dict(status='UNKNOWN_RESOURCE' if raw['status']=='UNKNOWN' else 'UNVERIFIED_EXHAUSTION' if raw['status']=='UNSAT' else 'POSITIVE_PENDING_STATIC_CHECKS',
        id=phase,source_case_id=case['source_case_id'],classification='SEEN_DIAGNOSTIC',arm='AUDIT_OFF_DIAGNOSTIC',
        raw_engine_status=raw['status'],raw_reason=raw['reason'],refs=refs,inputs=case['inputs'],
        raw_capture_status='COMPLETE' if refs['raw_result']['complete_json'] else 'UNKNOWN_CAPTURE',
        admission=dict(status='UNKNOWN',absence='UNKNOWN',full_graph_conformance='NOT_MEASURED',reason='NO_FULL_SNAPSHOT_OR_SEARCH_TREE_CERTIFICATE'),
        costs=dict(input_load_seconds=load_seconds,search_call_seconds=search_seconds,raw_capture_seconds=capture_seconds,
            fresh_input_admission_call_seconds=refs['fresh_input_admission']['call_seconds'],
            old_preparation='REUSED_INPUT_BYTES_AND_ADMISSION_NOT_COLD_PREPARATION'),
        stats=raw['stats'],event_extent=raw['event_extent'],rollback_extent=raw['rollback_extent'],
        scope='Audit-off positive-proof timing on an unchanged complete finite universe. Raw UNSAT is unverified exhaustion; UNKNOWN stays unresolved. No per-run full graph observation or general conformance claim.')
    if not refs['raw_result']['complete_json']:
        outcome.update(status='UNKNOWN_CAPTURE',seconds=time.perf_counter()-start);return outcome
    if raw['status']=='SAT':
        selected=raw['selected'];need(selected and raw['certificate'] is not None,'FOUND_CERTIFICATE_REQUIRED')
        a,refs['adapter_decode']=stage(base+'/adapter-decoding.json.gz',lambda:mods['M'].decode(prepared,selected))
        b,refs['independent_decode']=stage(base+'/independent-decoding.json.gz',lambda:mods['K'].decode(prepared,selected,**protocol['decoder_limits']))
        if a['status']=='UNKNOWN' or b['status']=='UNKNOWN':
            outcome.update(status='UNKNOWN_STATIC_ASSURANCE',admission=dict(status='UNKNOWN',absence='UNKNOWN',full_graph_conformance='NOT_MEASURED',reason='STATIC_DECODE_RESOURCE'))
        else:
            need(a['status']==b['status']=='UNVERIFIED_NATIVE_CERTIFICATE','STATIC_POINT_DECODE_REJECTED')
            need(all(sha(a[key])==sha(b[key]) for key in SEMANTIC),'COMPLETE_INDEPENDENT_STATIC_POINT_DECODING_AGREEMENT')
            need(b['statement']==declaration['statement'] and b['original_statement_sha256']==binding['original_statement_sha256'],'SAME_ORIGINAL_STATEMENT')
            need(b['selected']==sorted(selected) and b['selected_sha256']==sha(sorted(selected)),'ACTUAL_SELECTION_ASSOCIATION')
            need(0<len(b['proof'])<=declaration['profile']['slots'] and b['proof'][-1]['formula']==declaration['statement']['goal'],'BOUNDED_ORIGINAL_GOAL')
            native,refs['native_B']=stage(base+'/native-B.json',lambda:mods['B'].check(declaration['statement']['theory'],b['proof'],declaration['statement']['goal'],protocol['native_limits']))
            if native['status']=='VERIFIED':
                need(native['checked_lines']==len(b['proof']),'ALL_NATIVE_LINES_CHECKED')
                outcome.update(status='VERIFIED_POSITIVE',proof_lines=len(b['proof']),proof_sha256=sha(b['proof']),
                    original_statement_sha256=binding['original_statement_sha256'],
                    admission=dict(status='VERIFIED_POSITIVE',native_receipt_sha256=sha(native),selected_sha256=sha(sorted(selected)),
                        absence='NOT_CLAIMED',full_graph_conformance='NOT_MEASURED',
                        scope='Complete actual selected point assignment decoded by two independent implementations; entire native proof checked under original hypotheses/goal. Search trace/absence not certified.'))
            else:
                need(native['status']=='UNKNOWN_BUDGET','NATIVE_PROOF_REJECTED')
                outcome.update(status='UNKNOWN_NATIVE_ASSURANCE',admission=dict(status='UNKNOWN',absence='UNKNOWN',full_graph_conformance='NOT_MEASURED',reason=native.get('reason')))
    outcome['seconds']=time.perf_counter()-start
    outcome['costs']['whole_diagnostic_pipeline_seconds']=outcome['seconds']
    outcome['costs']['static_decode_native_call_seconds']=sum(refs[key]['call_seconds'] for key in ('adapter_decode','independent_decode','native_B') if key in refs)
    return outcome


def worker(phase):
    protocol,plan=unchanged();cases=[case for case in plan['cases'] if case['id']==phase];need(len(cases)==1,'DECLARED_PHASE')
    start=time.perf_counter();result=None
    save('data/'+phase+'-started.json',dict(status='STARTED',phase=phase,pid=os.getpid(),protocol_sha256=sha(protocol),utc=time.time()))
    try:
        result=diagnostic(cases[0],protocol,modules());unchanged()
        result_ref=save('data/'+phase+'-result.json',result)
        return dict(status='COMPLETE',phase=phase,scientific_status=result['status'],result=result_ref)
    except CaptureBound as error:
        result=dict(status='UNKNOWN_CAPTURE',id=phase,capture_prefix=error.reference,
            scope='Capture resource refusal. Keep every prior outcome/selection artifact; no positive, absence or trace admission.')
        save('data/'+phase+'-capture-refusal.json',result)
        raise
    finally:
        error=sys.exc_info()[0];post_error=None
        try:postcheck=unchanged()['status']
        except Exception as failure:postcheck='FAILED';post_error=str(failure)
        save('review/'+phase+'-invocation.json',dict(status='ERROR' if error or post_error else 'COMPLETE',phase=phase,pid=os.getpid(),
            scientific_status=result.get('status') if result else None,seconds=time.perf_counter()-start,
            maxrss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,maxrss_units='bytes' if sys.platform=='darwin' else 'KiB',
            frozen_postcheck=postcheck,postcheck_error=post_error,error_type=error.__name__ if error else None))
        if post_error and error is None:raise RuntimeError('FROZEN_POSTCHECK:'+post_error)


def supervise(phase):
    protocol,plan=unchanged();need(phase in protocol['phase_ids'],'DECLARED_PHASE')
    for name in ('data/'+phase+'-started.json','data/'+phase+'-result.json','review/'+phase+'-invocation.json','review/'+phase+'-observer.json','review/'+phase+'-native.log'):
        need(not local(name).exists(),'PRESERVE_FIRST_ATTEMPT:'+name)
    log=local('review/'+phase+'-native.log');log.parent.mkdir(parents=True,exist_ok=True)
    start=time.perf_counter();peak=0;probes=[];reason=None;observer_error=None;code=None;child=None;reap_error=None
    def cpu_guard():resource.setrlimit(resource.RLIMIT_CPU,(protocol['guards']['cpu_seconds'],protocol['guards']['cpu_seconds']+1))
    with log.open('xb') as out:
        try:
            child=subprocess.Popen([sys.executable,'-I','-S','-B',str(Path(__file__).resolve()),'_worker',phase],cwd=ROOT,
                env={'PATH':'/usr/bin:/bin','LANG':'C','PYTHONDONTWRITEBYTECODE':'1'},stdout=out,stderr=subprocess.STDOUT,start_new_session=True,preexec_fn=cpu_guard)
            while child.poll() is None:
                probe=subprocess.run(['/bin/ps','-o','rss=','-p',str(child.pid)],capture_output=True,text=True,timeout=5)
                if probe.returncode==0 and probe.stdout.strip():
                    rss=int(probe.stdout.strip())*1024
                    if rss>peak:peak=rss;probes.append(dict(seconds=time.perf_counter()-start,rss_bytes=rss))
                    if rss>protocol['guards']['rss_bytes']:reason='RSS_POLL_BOUND';break
                elif child.poll() is None:reason='RSS_PROBE_FAILED';break
                if time.perf_counter()-start>protocol['guards']['wall_seconds']:reason='WALL_BOUND';break
                time.sleep(.2)
        except BaseException as error:
            reason='OBSERVER_ERROR:'+type(error).__name__;observer_error=str(error)
        finally:
            if child is not None:
                if reason and child.poll() is None:
                    try:os.killpg(child.pid,signal.SIGTERM)
                    except ProcessLookupError:pass
                    except OSError as error:observer_error=(observer_error or '')+'; OWNED_TERM_ERROR:'+str(error)
                    try:child.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        try:os.killpg(child.pid,signal.SIGKILL)
                        except ProcessLookupError:pass
                        except OSError as error:observer_error=(observer_error or '')+'; OWNED_KILL_ERROR:'+str(error)
                try:code=child.wait(timeout=5)
                except subprocess.TimeoutExpired:reap_error='NATIVE_EXIT_UNOBSERVED_AFTER_OWNED_KILL'
    post_error=None
    try:postcheck=unchanged()['status']
    except Exception as error:postcheck='FAILED';post_error=str(error)
    receipt=dict(status='TERMINAL' if code is not None else 'UNADMITTED_PROCESS',phase=phase,pid=child.pid if child else None,
        native_exit_code=code,guard_reason=reason,observer_error=observer_error,reap_error=reap_error,
        seconds=time.perf_counter()-start,peak_observed_rss_bytes=peak,rss_samples=probes,log=ref(str(log.relative_to(ROOT))),
        frozen_postcheck=postcheck,postcheck_error=post_error,
        scope='Owned single child only; native CPU cap, sampled RSS, bounded TERM/KILL/reap and actual observed exit. Nonzero, unobserved or guarded remains unadmitted, never rerun silently.')
    save('review/'+phase+'-observer.json',receipt);return receipt


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('command',choices=('freeze','run','_worker'));parser.add_argument('phase',nargs='?');args=parser.parse_args()
    need((args.command=='freeze')==(args.phase is None),'COMMAND_PHASE')
    print(json.dumps(freeze() if args.command=='freeze' else supervise(args.phase) if args.command=='run' else worker(args.phase),sort_keys=True),flush=True)
