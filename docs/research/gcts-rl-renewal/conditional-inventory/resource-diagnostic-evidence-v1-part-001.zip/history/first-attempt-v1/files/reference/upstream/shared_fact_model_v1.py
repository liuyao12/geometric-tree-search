"""Finite anchored shared-fact point catalogue and native-proof decoder.

No engine, logical checker, theorem search or previous proof is imported.
PREPARED_UNVERIFIED requires external ZERO truth and complete model admission.
Decoded native proofs remain unverified until independently checked.
"""
import copy
import hashlib
import json
import math
import time

SCHEMA = 'Shared-fact-finite-catalogue-v1'
PROFILE_VERSION = 'LITERAL_SORTED_CANONICAL_JSON_V1'
DEFAULT_LIMITS = dict(max_formulas=48, max_rows=25000, max_slots=64,
    max_zero_definitions=256, max_items=2000000, max_depth=128, wall_seconds=10.0)
ZERO_RULES = frozenset(('axiom', 'instantiate', 'refl', 'eq_subst', 'distribute', 'tautology'))


class Refusal(Exception):
    pass


def canonical(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       separators=(',', ':'), allow_nan=False)+'\n').encode('ascii')


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def need(condition, reason):
    if not condition:
        raise ValueError(reason)


def integer(value, minimum=0):
    return type(value) is int and value >= minimum


def fields(value, keys, label):
    need(type(value) is dict and set(value) == set(keys), label)


def limits_value(limits):
    result = dict(DEFAULT_LIMITS)
    if limits is not None:
        need(type(limits) is dict and set(limits) <= set(result), 'LIMIT_FIELDS')
        result.update(limits)
    for key, value in result.items():
        if key == 'wall_seconds':
            need(type(value) in (int, float) and math.isfinite(value) and value > 0,
                 'POSITIVE_WALL_LIMIT')
        else:
            need(integer(value, 1), 'POSITIVE_INTEGER_LIMIT:'+key)
        need(value <= DEFAULT_LIMITS[key], 'LIMIT_EXCEEDS_DECLARED_CEILING:'+key)
    return result


class Meter:
    def __init__(self, limits):
        self.limits, self.items = limits, 0
        self.started = time.perf_counter()

    def tick(self, count=1):
        self.items += count
        if self.items > self.limits['max_items']:
            raise Refusal('PREPARATION_ITEM_BOUND')
        if time.perf_counter()-self.started > self.limits['wall_seconds']:
            raise Refusal('PREPARATION_WALL_BOUND')

    def scan(self, value, depth=0):
        self.tick()
        if depth > self.limits['max_depth']:
            raise Refusal('NATIVE_JSON_DEPTH_BOUND')
        if type(value) is str:
            self.tick(len(value))
        elif type(value) is list:
            for child in value:
                self.scan(child, depth+1)
        elif type(value) is dict:
            for key, child in value.items():
                need(type(key) is str, 'NATIVE_JSON_KEYS')
                self.scan(key, depth+1)
                self.scan(child, depth+1)
        else:
            need(value is None or type(value) in (int, bool) or
                 type(value) is float and math.isfinite(value), 'FINITE_NATIVE_JSON')


def syntax(ast, expected, theory, variables, meter, depth=0):
    """Structural sort/signature/FV check only; never rule truth or hygiene."""
    meter.tick()
    if depth > meter.limits['max_depth']:
        raise Refusal('AST_DEPTH_BOUND')
    need(type(ast) is list and ast and type(ast[0]) is str, 'LITERAL_AST')
    tag = ast[0]
    if expected == 'term':
        if tag == 'var':
            need(len(ast) == 2 and type(ast[1]) is str and ast[1] in variables, 'DECLARED_VARIABLE')
            return {ast[1]}
        need(tag == 'fun' and len(ast) == 3 and type(ast[1]) is str and
             ast[1] in theory['functions'] and type(ast[2]) is list and
             len(ast[2]) == theory['functions'][ast[1]], 'FUNCTION_SIGNATURE')
        result = set()
        for child in ast[2]:
            result.update(syntax(child, 'term', theory, variables, meter, depth+1))
        return result
    need(expected == 'formula', 'EXPECTED_SORT')
    if tag == 'pred':
        need(len(ast) == 3 and type(ast[1]) is str and ast[1] in theory['predicates'] and
             type(ast[2]) is list and len(ast[2]) == theory['predicates'][ast[1]], 'PREDICATE_SIGNATURE')
        result = set()
        for child in ast[2]:
            result.update(syntax(child, 'term', theory, variables, meter, depth+1))
        return result
    if tag in ('imp', 'and', 'or', 'eq'):
        need(len(ast) == 3, 'BINARY_AST')
        child_sort = 'term' if tag == 'eq' else 'formula'
        return syntax(ast[1], child_sort, theory, variables, meter, depth+1) | syntax(ast[2], child_sort, theory, variables, meter, depth+1)
    if tag == 'not':
        need(len(ast) == 2, 'NEGATION_AST')
        return syntax(ast[1], 'formula', theory, variables, meter, depth+1)
    if tag == 'all':
        need(len(ast) == 3 and type(ast[1]) is str and ast[1] in variables, 'DECLARED_BINDER')
        return syntax(ast[2], 'formula', theory, variables, meter, depth+1)-{ast[1]}
    need(tag == 'bot' and len(ast) == 1, 'FORMULA_AST_TAG')
    return set()


def checked_catalogue(catalogue, meter):
    meter.scan(catalogue)
    fields(catalogue, ('schema', 'statement', 'formulas', 'zeros', 'mp', 'gen', 'profile', 'provenance'), 'CATALOGUE_FIELDS')
    need(catalogue['schema'] == SCHEMA, 'CATALOGUE_SCHEMA')
    need(type(catalogue['provenance']) is dict, 'PROVENANCE_DICTIONARY')
    statement, profile = catalogue['statement'], catalogue['profile']
    fields(statement, ('theory', 'goal'), 'STATEMENT_FIELDS')
    theory = statement['theory']
    fields(theory, ('functions', 'predicates', 'axioms'), 'THEORY_FIELDS')
    for category in ('functions', 'predicates'):
        signature = theory[category]
        need(type(signature) is dict and all(type(k) is str and k and integer(v)
             for k, v in signature.items()), 'SIGNATURE:'+category)
    need(type(theory['axioms']) is dict and all(type(k) is str and k for k in theory['axioms']), 'AXIOM_NAMES')
    required = {'kind', 'slots', 'formula_universe_version', 'zero_instance_profile', 'variables', 'allow_gen'}
    need(type(profile) is dict and required <= set(profile), 'PROFILE_FIELDS')
    need(type(profile['kind']) is str and profile['kind'] and
         profile['formula_universe_version'] == PROFILE_VERSION and
         type(profile['zero_instance_profile']) is str and profile['zero_instance_profile'], 'PROFILE_VERSION')
    need(integer(profile['slots'], 1) and type(profile['allow_gen']) is bool, 'SLOT_AND_GEN_PROFILE')
    variables = profile['variables']
    need(type(variables) is list and all(type(x) is str and x for x in variables) and
         len(set(variables)) == len(variables), 'VARIABLE_POOL')
    for formula in theory['axioms'].values():
        need(not syntax(formula, 'formula', theory, variables, meter), 'CLOSED_ASSUMPTIONS_REQUIRED')
    syntax(statement['goal'], 'formula', theory, variables, meter)
    formulas = catalogue['formulas']
    need(type(formulas) is list and formulas, 'NONEMPTY_FORMULA_UNIVERSE')
    if len(formulas) > meter.limits['max_formulas']:
        raise Refusal('FORMULA_UNIVERSE_CAP')
    keys = []
    for formula in formulas:
        syntax(formula, 'formula', theory, variables, meter)
        keys.append(canonical(formula))
    need(keys == sorted(set(keys)), 'EXACT_SORTED_DISTINCT_FORMULA_IDS')
    ids = {key: i+1 for i, key in enumerate(keys)}
    need(canonical(statement['goal']) in ids, 'GOAL_IN_FINITE_UNIVERSE')
    need(all(canonical(f) in ids for f in theory['axioms'].values()), 'ASSUMPTIONS_IN_UNIVERSE')
    zeros = catalogue['zeros']
    need(type(zeros) is list, 'ZERO_LIST')
    if len(zeros) > meter.limits['max_zero_definitions']:
        raise Refusal('ZERO_DEFINITION_CAP')
    zero_ids, zdefs = [], []
    for zero in zeros:
        fields(zero, ('id', 'native'), 'ZERO_FIELDS')
        need(type(zero['id']) is str and zero['id'], 'ZERO_ID')
        native = zero['native']
        need(type(native) is dict and native.get('rule') in ZERO_RULES and 'formula' in native, 'PRIMITIVE_ZERO_PAYLOAD')
        syntax(native['formula'], 'formula', theory, variables, meter)
        need(canonical(native['formula']) in ids, 'ZERO_OUTPUT_IN_UNIVERSE')
        zero_ids.append(zero['id'])
        zdefs.append(dict(id=zero['id'], output=ids[canonical(native['formula'])], native=copy.deepcopy(native)))
    need(zero_ids == sorted(set(zero_ids)), 'SORTED_UNIQUE_ZERO_IDS')
    mp, gen = [], []
    for output_id, formula in enumerate(formulas, 1):
        meter.tick()
        if formula[0] == 'imp' and canonical(formula[1]) in ids and canonical(formula[2]) in ids:
            mp.append(dict(antecedent=ids[canonical(formula[1])], implication=output_id,
                           output=ids[canonical(formula[2])]))
        if profile['allow_gen'] and formula[0] == 'all' and canonical(formula[2]) in ids:
            gen.append(dict(source=ids[canonical(formula[2])], output=output_id, variable=formula[1]))
    mp.sort(key=lambda d: (d['antecedent'], d['implication'], d['output']))
    gen.sort(key=lambda d: (d['source'], d['output'], d['variable']))
    for key, expected, key_fields in (('mp', mp, ('antecedent', 'implication', 'output')),
                                     ('gen', gen, ('source', 'output', 'variable'))):
        need(type(catalogue[key]) is list, 'DEFINITION_LIST:'+key)
        for definition in catalogue[key]:
            fields(definition, key_fields, 'DEFINITION_FIELDS:'+key)
            for field in key_fields:
                need(type(definition[field]) is str if field == 'variable' else integer(definition[field], 1), 'DEFINITION_VALUE:'+field)
        need(catalogue[key] == expected, 'COMPLETE_STRUCTURAL_DEFINITIONS:'+key)
    definitions = dict(zeros=zdefs,
        mp=[dict(id='mp:'+str(d['implication']), **d) for d in mp],
        gen=[dict(id='gen:'+str(d['output']), **d) for d in gen],
        pad=dict(id='pad', active=0, formula_id=0))
    return ids, definitions


def point(kind, scope, slot):
    return canonical(['DAG-slot-'+kind+'-v1', scope, slot]).decode('ascii')


def row(scope, slot, kind, definition_id, refs, output, demands):
    marks = {}
    for index, active, formula in [(slot, int(kind != 'PAD'), output)]+demands:
        for port, value in ((point('active', scope, index), str(active)),
                            (point('formula', scope, index), str(formula))):
            if port in marks and marks[port] != value:
                return None
            marks[port] = value
    return dict(id=canonical(['DAG-candidate-v1', scope, slot, kind, definition_id, refs]).decode('ascii'),
        t=[[point('center', scope, slot), 1]], m=sorted([[p, v] for p, v in marks.items()]))


def prepare(catalogue, slots, limits=None):
    started, census = time.perf_counter(), {}
    try:
        effective = limits_value(limits)
        meter = Meter(effective)
        ids, definitions = checked_catalogue(catalogue, meter)
        need(integer(slots, 1) and slots == catalogue['profile']['slots'], 'DECLARED_SLOT_BOUND_MISMATCH')
        if slots > effective['max_slots']:
            raise Refusal('SLOT_CAP')
        sum_i, sum_square = slots*(slots-1)//2, slots*(slots-1)*(2*slots-1)//6
        counts = dict(formulas=len(catalogue['formulas']), zero_definitions=len(definitions['zeros']),
            mp_definitions=len(definitions['mp']), gen_definitions=len(definitions['gen']), slots=slots)
        potential = slots*(counts['zero_definitions']+1)+sum_square*counts['mp_definitions']+sum_i*counts['gen_definitions']
        conflicts = sum_i*counts['mp_definitions']
        census = dict(counts, potential_rows=potential, self_conflicting_rows=conflicts,
            rows=potential-conflicts, points_required=slots, mark_only_ports=2*slots)
        if census['rows'] > effective['max_rows']:
            raise Refusal('COMPLETE_ROW_UNIVERSE_CAP')
        logical_catalogue = {key: copy.deepcopy(catalogue[key]) for key in
            ('schema', 'statement', 'formulas', 'zeros', 'mp', 'gen', 'profile')}
        preimage = dict(schema='Shared-fact-point-scope-v1', catalogue=logical_catalogue,
            slots=slots, allow_padding=True, point_version='DAG-slot-ports-v1', candidate_version='DAG-candidate-v1')
        scope = digest(preimage)
        binding = dict(scope=scope, scope_preimage=preimage, slots=slots,
            goal_id=ids[canonical(catalogue['statement']['goal'])], catalogue_sha256=digest(catalogue),
            original_statement_sha256=digest(catalogue['statement']))
        universe, actual_conflicts = [], 0
        for i in range(slots):
            for definition in definitions['zeros']:
                meter.tick()
                universe.append(row(scope, i, 'ZERO', definition['id'], [], definition['output'], []))
            for definition in definitions['mp']:
                for j in range(i):
                    for k in range(i):
                        meter.tick()
                        candidate = row(scope, i, 'MP', definition['id'], [j, k], definition['output'],
                            [(j, 1, definition['antecedent']), (k, 1, definition['implication'])])
                        if candidate is None:
                            actual_conflicts += 1
                        else:
                            universe.append(candidate)
            for definition in definitions['gen']:
                for j in range(i):
                    meter.tick()
                    universe.append(row(scope, i, 'GEN', definition['id'], [j], definition['output'], [(j, 1, definition['source'])]))
            universe.append(row(scope, i, 'PAD', 'pad', [], 0, []))
        need(actual_conflicts == conflicts and len(universe) == census['rows'], 'ROW_CENSUS_INVARIANT')
        universe.sort(key=lambda candidate: candidate['id'])
        need(len({candidate['id'] for candidate in universe}) == len(universe), 'UNIQUE_CANDIDATES')
        model = dict(schema='Z-growing-point-model-v1',
            version='Shared-fact-slots-active-formula-v1:'+scope, capacity=1,
            roots=sorted(point('center', scope, i) for i in range(slots)),
            seed=dict(t=[], m=sorted([[point('active', scope, slots-1), '1'],
                [point('formula', scope, slots-1), str(binding['goal_id'])]])),
            inventory=dict(kind='EXPLICIT', placements=universe))
        result = dict(schema='Shared-fact-prepared-v1', status='PREPARED_UNVERIFIED',
            statement=copy.deepcopy(catalogue['statement']), catalogue=copy.deepcopy(catalogue),
            binding=binding, definitions=definitions, model=model, universe=universe,
            census=census, limits=effective, timings=dict(seconds=time.perf_counter()-started, items=meter.items),
            admission='External complete basis/model/trace and all native ZERO checks required; generic FOL catalogue completeness is not claimed.')
        meter.tick()
        result['timings'] = dict(seconds=time.perf_counter()-started, items=meter.items)
        return result
    except (Refusal, MemoryError, RecursionError) as error:
        return dict(schema='Shared-fact-prepared-v1', status='UNKNOWN', reason=str(error) or type(error).__name__,
            census=census, seconds=time.perf_counter()-started, model=None, universe=None)
    except (ValueError, TypeError, KeyError, IndexError, AttributeError) as error:
        return dict(schema='Shared-fact-prepared-v1', status='REJECTED_INPUT', reason=str(error),
            census=census, seconds=time.perf_counter()-started, model=None, universe=None)


def decode(prepared, selected, limits=None):
    """Rebuild own data, check exact selected tiling, strip PAD and remap refs.

    This is not an independent model or native logical checker. No proof is
    generated beyond decoding the supplied complete selected certificate.
    """
    started = time.perf_counter()
    try:
        need(type(prepared) is dict and prepared.get('status') == 'PREPARED_UNVERIFIED', 'PREPARED_PACKET_REQUIRED')
        effective = limits_value(prepared['limits'] if limits is None else limits)
        meter = Meter(effective)
        regenerated = prepare(prepared['catalogue'], prepared['binding']['slots'], effective)
        if regenerated['status'] == 'UNKNOWN':
            return dict(status='UNKNOWN', reason='DECODER_RECONSTRUCTION:'+regenerated['reason'])
        need(regenerated['status'] == 'PREPARED_UNVERIFIED', 'DECODER_MODEL_RECONSTRUCTION')
        for key in ('schema', 'status', 'statement', 'catalogue', 'binding', 'definitions', 'model', 'universe', 'census'):
            meter.tick()
            need(canonical(prepared[key]) == canonical(regenerated[key]), 'EXACT_PREPARED_BINDING:'+key)
        meter.scan(selected)
        need(type(selected) is list and all(type(cid) is str for cid in selected) and
             len(set(selected)) == len(selected), 'UNIQUE_SELECTED_CIDS')
        n, scope = prepared['binding']['slots'], prepared['binding']['scope']
        need(len(selected) == n, 'ONE_OWNER_PER_REQUIRED_SLOT')
        by_id = {candidate['id']: candidate for candidate in regenerated['universe']}
        owners, totals = {}, {}
        marks = dict(prepared['model']['seed']['m'])
        parsed = {}
        for cid in selected:
            meter.tick()
            need(cid in by_id, 'SELECTED_ID_IN_COMPLETE_UNIVERSE')
            action = json.loads(cid)
            need(type(action) is list and len(action) == 6 and canonical(action).decode('ascii') == cid, 'CANONICAL_SELECTED_ID')
            version, actual_scope, slot, kind, definition_id, refs = action
            need(version == 'DAG-candidate-v1' and actual_scope == scope and integer(slot) and slot < n,
                 'SELECTED_SCOPE_SLOT')
            need(slot not in owners, 'UNIQUE_SLOT_OWNER')
            owners[slot], parsed[slot] = cid, (kind, definition_id, refs)
            for p, value in by_id[cid]['t']:
                totals[p] = totals.get(p, 0)+value
                need(totals[p] <= 1, 'SELECTED_CAPACITY')
            for p, value in by_id[cid]['m']:
                need(p not in marks or marks[p] == value, 'EXACT_MARK_AND_SEED_AGREEMENT')
                marks[p] = value
        need(set(owners) == set(range(n)) and all(totals.get(p, 0) == 1 for p in prepared['model']['roots']), 'COMPLETE_REQUIRED_TARGET')
        active_slots = [i for i in range(n) if parsed[i][0] != 'PAD']
        native_to_slot = active_slots
        slot_to_native = [None]*n
        for line_index, slot in enumerate(active_slots):
            slot_to_native[slot] = line_index
        definitions = prepared['definitions']
        zero = {d['id']: d for d in definitions['zeros']}
        mp = {d['id']: d for d in definitions['mp']}
        gen = {d['id']: d for d in definitions['gen']}
        proof, slot_rows, mappings, nodes, edges = [], [], [], [], []
        formulas = prepared['catalogue']['formulas']
        for slot in range(n):
            meter.tick()
            kind, definition_id, refs = parsed[slot]
            output = int(marks[point('formula', scope, slot)])
            active = int(marks[point('active', scope, slot)])
            line_index = slot_to_native[slot]
            slot_rows.append(dict(slot=slot, cid=owners[slot], active=active,
                formula_id=output, native_line_index_or_null=line_index))
            if kind == 'PAD':
                need(active == output == 0 and refs == [], 'INACTIVE_PAD_EXACT_ZERO')
                continue
            need(active == 1 and integer(output, 1) and output <= len(formulas), 'ACTIVE_OWNER_FORMULA')
            need(all(integer(j) and j < slot and slot_to_native[j] is not None for j in refs), 'EARLIER_ACTIVE_REFERENCES')
            old_refs = {}
            if kind == 'ZERO':
                line = copy.deepcopy(zero[definition_id]['native'])
                need(refs == [], 'ZERO_REFERENCE_COUNT')
            elif kind == 'MP':
                need(len(refs) == 2 and definition_id in mp, 'MP_DEFINITION_AND_REFS')
                old_refs = dict(antecedent=refs[0], implication=refs[1])
                line = dict(rule='mp', formula=copy.deepcopy(formulas[output-1]),
                    antecedent=slot_to_native[refs[0]], implication=slot_to_native[refs[1]])
            elif kind == 'GEN':
                need(len(refs) == 1 and definition_id in gen, 'GEN_DEFINITION_AND_REFS')
                old_refs = dict(source=refs[0])
                line = dict(rule='generalize', formula=copy.deepcopy(formulas[output-1]),
                    source=slot_to_native[refs[0]], variable=gen[definition_id]['variable'])
            else:
                raise ValueError('NATIVE_CANDIDATE_KIND')
            need(line['formula'] == formulas[output-1], 'DECODED_FORMULA_BINDING')
            proof.append(line)
            nodes.append(dict(line=line_index, slot=slot, formula_id=output))
            if old_refs:
                mappings.append(dict(slot=slot, native_line=line_index, rule=line['rule'],
                    slot_references=old_refs, native_references={key: line[key] for key in old_refs}))
                edges.extend(dict(premise=line[key], conclusion=line_index, field=key) for key in old_refs)
        statement = prepared['statement']
        need(proof and slot_to_native[-1] == len(proof)-1 and proof[-1]['formula'] == statement['goal'], 'UNCHANGED_LAST_GOAL')
        result = dict(schema='Shared-fact-native-decoding-v1', status='UNVERIFIED_NATIVE_CERTIFICATE',
            statement=copy.deepcopy(statement), proof=proof, slots=slot_rows,
            slot_to_native=slot_to_native, native_to_slot=native_to_slot,
            reference_mapping=mappings, proof_dag=dict(nodes=nodes, edges=edges),
            selected=sorted(selected), selected_sha256=digest(sorted(selected)),
            original_statement_sha256=digest(statement), scope=scope,
            seconds=time.perf_counter()-started,
            validity='Independent basis/model/full-trace admission and complete native B check remain external.')
        meter.tick()
        result['seconds'] = time.perf_counter()-started
        return result
    except (Refusal, MemoryError, RecursionError) as error:
        return dict(status='UNKNOWN', reason=str(error) or type(error).__name__, seconds=time.perf_counter()-started)
    except (ValueError, TypeError, KeyError, IndexError, AttributeError) as error:
        return dict(status='REJECTED', reason=str(error), seconds=time.perf_counter()-started)
