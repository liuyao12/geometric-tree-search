# Root review before the next experiment

The saved metrics and the plan were read. The current published pilot remains
unchanged. Nothing in this directory has been executed as a scientific run.

Accept the same-input diagnostic, exact native proof checks, explicit resource
refusals and separation of full-audit evidence from timing. These are seen
cases, and the existing forward/SAT results remain historical controls.

Do not automatically implement the proposed thirty-two-cell work-cap sweep.
Some of the larger original cases reached only the initial decision and placed
no candidate. The pilot therefore has not yet tested their search difficulty.
More repeated snapshot capture can turn another capture limit into the next
bottleneck without answering the practical proof-search question.

Before freezing a driver, choose a smaller, explicit diagnostic schedule. Give
priority to distinguishing two questions:

- Can the unchanged, previously qualified point engine discover a complete
  proof within the fixed wall allowance, followed by independent static point
  decoding and native checking? Full snapshot capture can be disabled in a
  separately labeled positive-proof timing lane. This must not claim complete
  per-run internal graph conformance or independently certified absence.
- How much does complete snapshot capture and its verification cost on these
  same inputs? Keep that cost visible in a separate audited diagnostic, with
  declared work, event, storage and process limits. Moving a resource bottleneck
  is not an algorithmic speedup.

For a positive-proof timing lane, retain every actual found certificate and
every failed/unknown first attempt. Include preparation, decoding and native
validation in reported costs. Never fill an unsuccessful point record with a
forward or SAT proof. No RL policy or learned markings are introduced by this
resource experiment.

If independently certified bounded negatives become necessary, an event-only
search-tree verifier could be specified later. It would have to reconstruct
complete legal domains, global dead/forced decisions, branch alternatives and
rollback from the exact finite universe. Such a certificate is distinct from
checking every actual internal graph snapshot; no synthetic snapshots should
be presented as observations of the solver.

The next prospective protocol must settle the schedule and assurance labels
before execution. The current plan is a design proposal, not authorization to
silently rerun or replace any archived experiment.
