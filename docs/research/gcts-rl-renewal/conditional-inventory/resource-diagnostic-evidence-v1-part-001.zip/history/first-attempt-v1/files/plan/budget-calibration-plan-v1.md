# Prospective shared-point resource calibration

Status: Source-only plan, awaiting Root review and a fresh freeze. No scientific module, model, search, checker or native proof was imported, constructed or executed. The original DAG-search run and its frozen archive are untouched. Context is limited to the eight saved per-case benchmark summaries' counters, statuses, census and cost fields; exact refs and metrics are in `saved-metrics-context-v1.json`. No selected or decoded proof payload was read.

The current master hash remains `c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9`. Its complete point domains, global dead/forced priority, generation scheduler and exact rollback remain normative.

The eight previous point results are UNKNOWN. Their charged work is between \(99{,}998{,}910\) and \(99{,}999{,}998\), while recorded internal time is only about \(0.0676\)–\(0.0912\,\mathrm{s}\). They visited between one and eighteen nodes and captured between one and thirty-six callbacks. Their complete universes contain 144–1,270 rows. These counters are evidence that the conservative work ceiling intervened early; they do not show that work beyond that ceiling will find a proof or make point search practical. The original statuses remain exactly as published.

## Fixed diagnostic scope

Use the same eight admitted finite declarations and their exact complete prepared models/universes as SEEN diagnostic inputs, with new run IDs and separate artifacts. Reuse their byte-pinned basis/model admission as a declared dependency; do not read any original found proof, feed a target derivation, narrow the grammar, prune a candidate or change the goal/seed. Record preparation as reused rather than measured cold. Keep lexical ordering, capacity/mark semantics, scheduler, generations, normalization, engine Source and rollback unchanged.

Freeze the entire new Source/input/limits/runtime/master set and schedule before execution. The main matrix is eight cases by four declared work ceilings, one new attempt per cell:

\[
\mathrm{max\_work}\in\{10^8,10^9,10^{10},10^{11}\},\qquad
\mathrm{wall\_seconds}=3.
\]

The low-cap cell is a new calibration reference under the new frozen capture protocol. It neither replaces nor erases the original attempt. Run every declared cell regardless of intermediate success; do not choose a cap that makes a favored case look good. Rotate cap order across cases prospectively to reduce a fixed warmup order, while keeping each cell a fresh engine instance. No forward or SAT method is rerun or relabeled in this diagnostic. Their previous outputs are historical context only, not a new paired performance trial.

Keep the independent owned guards at the previous declared values: one child per cell, \(180\,\mathrm{s}\) outer wall, \(150\,\mathrm{s}\) native CPU and \(1\,\mathrm{GiB}\) polled RSS. Preserve \(10{,}000\) nodes, 25,000 candidates and 128 points unless Root separately rejects/freezes those values before any execution. These counters have different meanings from CPU time; raising only `max_work` is budget calibration, not an algorithmic acceleration.

## Full-audit primary arm

Retain every emitted primitive event and complete point snapshot for independent whole-frontier checking. Freeze explicit limits of 1,000 captured audit events, 1,000 rollback records and 128 MiB of logical serialized callback data per cell. The new capture protocol must count actual serialized bytes and charge its own time; that instrumentation is held identical across all four work caps. It may change capture overhead relative to the old study, so the old timing is not an interchangeable baseline.

Use a cooperative stop for a node/event/audit-byte/storage bound. Retain the exact engine reason and an independent driver-stop reason such as `AUDIT_EVENT_BOUND` or `AUDIT_BYTES_BOUND`; an intentional work-meter stop used to request cleanup must not masquerade as evidence that the engine's ordinary work ceiling was reached. Keep a coverage inventory with total emitted and fully saved callbacks and the exact missing suffix, if any. Never retain a success or absence admission after truncating an event. If the callback that triggers a limit cannot be fully stored, record the gap and leave full assurance UNKNOWN. An OS guard remains UNKNOWN with original logs, process/exit evidence and unfinished artifacts preserved.

Persist raw search/result/callback bytes before independent assurance. Measure capture, result writing, observation writing, trace checking, positive decoding and native checking as separate components, plus complete cell pipeline cost. Keep inner charged work, nodes, placements, branches, forced moves, dead ends, backtracks, callback count/bytes and actual wall time. Report which limit was first, including cooperative wall overshoot; a three-second check between operations is not a strict instantaneous OS timer.

For a completed positive, independently verify the exact point selection and whole native proof under the unchanged original theory/goal. For a completed negative, require a complete independent global-frontier/rollback/exhaustion certificate and the original complete finite rule/universe admission. A hash or prefix cannot replace missing graphs. Every preparation, capture, trace, native or process refusal remains explicitly UNKNOWN. Clean native exit means execution completed, not that a proof or finite absence was established.

## Optional audit-overhead arm, separately frozen

After the primary protocol is accepted, Root may freeze eight additional seen-case attempts at the already declared highest work cap, still with the same three-second wall and owned guards, using the unchanged engine with full-snapshot callbacks disabled. This is a timing/instrumentation diagnostic. Its bounded internal event retention and output storage must be declared explicitly; for example 50,000 compact events, 1,000 rollback records and 128 MiB retained output. A retained prefix is identified as a prefix even if its stream hash covers more events.

Label this arm `AUDIT_OFF_DIAGNOSTIC`, never full-trace conformance. A found complete selection may receive fresh independent static point verification, decoding and native B, so a positive proof can still be exact. Its search time alone omits the full-audit cost. A raw exhausted result cannot be promoted to independently verified finite absence with the current snapshot-based checker. A future event-only independent reconstruction checker would need a separate Source/specification freeze and tiny qualification of complete domains, scheduling, branch-local exclusions and rollback. It cannot be replaced by sampling, a digest or assuming deterministic replay. Any second audited execution or replay is a separate measured cost and result, not hidden free assurance.

If audit-off is not independently specified before its execution, omit it. The primary full-audit work-cap matrix is sufficient for the initial diagnostic. No RL, learned family ordering or new marking lane starts until an honest baseline budget and assurance scope are stable.

## Falsification and decision rules

- The same-input scheduler/event prefix before a resource interruption must agree across cap cells, apart from explicitly nonsemantic timing/cost fields. A divergent legal domain, chosen candidate, exclusion or restored state is an implementation/custody issue; stop interpretation rather than call it calibration noise.
- If a larger work allowance does not extend the checked prefix or move the first binding limit away from work, the explanation is incomplete. Check actual applied limits and accounting before claiming the ceiling is resolved. Do not increase time, remove audit or narrow the universe to rescue a preferred outcome.
- If the highest predeclared work cap is still reached long before the wall allowance, report calibration unresolved. If wall, node, audit, storage or RSS becomes first, report that new bottleneck explicitly. Moving a bottleneck is not a search-speed improvement.
- If high-cap, fully audited runs still find no proof within the fixed allowance, that is a negative practical result for this encoding/search combination. UNKNOWN remains UNKNOWN; success of the earlier forward control does not supply the missing point proof.
- The audit-overhead hypothesis is supported only by the separately declared paired timing arm with its weaker assurance scope visible. If its timing/progress does not improve, full-snapshot overhead is not a sufficient explanation. Audit-off success plus audited failure does not establish fully certified practical superiority.
- Any native/point rejection of a claimed positive or failure of a complete absence certificate is a scientific issue, not a run to discard. All first attempts, failed phases and coverage gaps remain in the evidence.
- These are seen cases, four designed theory templates and repeated bounds. No solve-rate generalization, new theorem, held-out transfer, established-ATP/SAT advantage, PA/Hilbert completeness, universal Wang system or plane-tiling result follows. Genuinely fresh structural cases require their own prospective declarations/partition freeze after calibration, not symbol-renamed copies described as held out.

Root should review this plan in a future goal turn before authoring/running a new driver. No existing forward, SAT or GCTS result is changed by this proposal.
