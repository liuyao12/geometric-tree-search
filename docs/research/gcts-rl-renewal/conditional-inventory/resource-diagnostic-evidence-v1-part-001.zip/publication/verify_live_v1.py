"""Normal-TLS HTTP/1.1 verification of every prepared asset and ZIP original.

Downloads only the approved existing Pages prefix, at one or two workers.
Never disables certificate checks. No scientific code or Git mutations.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor,as_completed
import json
from pathlib import Path
import subprocess
import sys
import time
from urllib.parse import urlsplit
sys.path.insert(0,str(Path(__file__).resolve().parent))
from evidence_common_v1 import ROOT,PREFIX,BASE_URL,MANIFEST,wire,pin,local,verify_archive

def save(path,value):path.write_bytes(wire(value))
def main():
    p=argparse.ArgumentParser();p.add_argument('--workers',type=int,choices=(1,2),default=2);p.add_argument('--retry-failed',action='store_true');args=p.parse_args()
    prepared=json.loads((ROOT/'publication/prepared-v1.json').read_text());destination=ROOT/'publication/live-bodies-v1';destination.mkdir(exist_ok=True)
    assert prepared['status']=='PREPARED_TASK_ASSETS_ONLY' and len(prepared['commit'])==40
    assert len(prepared['assets'])==len({a['path'] for a in prepared['assets']})
    previous={}
    old=ROOT/'publication/live-byte-check-v1.json'
    if old.exists():
        history=ROOT/'publication/live-byte-check-history-v1';history.mkdir(exist_ok=True)
        identity=pin(old)['sha256'];retained=history/(identity+'.json')
        if retained.exists():assert retained.read_bytes()==old.read_bytes()
        else:retained.write_bytes(old.read_bytes())
    if args.retry_failed and old.exists():
        receipt=json.loads(old.read_text());assert receipt['commit']==prepared['commit']
        previous={e['path']:e for e in receipt['assets'] if e['match']}
    def check(asset):
        assert asset['path'].startswith(PREFIX) and asset['url']==BASE_URL+asset['path']
        parsed=urlsplit(asset['url']);assert parsed.scheme=='https' and parsed.netloc=='liuyao12.github.io'
        relative=asset['path'][len(PREFIX):];target=local(destination,relative);target.parent.mkdir(parents=True,exist_ok=True)
        if asset['path'] in previous and target.is_file():
            actual=pin(target)
            if (actual['bytes'],actual['sha256'])==(asset['bytes'],asset['sha256']):return {**previous[asset['path']],'retained_from_same_commit_check':True}
        cmd=['curl','--http1.1','--fail','--location','--silent','--show-error','--connect-timeout','20','--max-time','120','--retry','2','--retry-delay','1','--retry-all-errors','--proto','=https','--proto-redir','=https','--dump-header',str(target)+'.headers.txt','--output',str(target),'--write-out','%{http_code} %{size_download} %{url_effective}',asset['url']+'?gcts_commit='+prepared['commit']]
        start=time.perf_counter();r=subprocess.run(cmd,capture_output=True,text=True)
        actual=pin(target) if target.is_file() else dict(bytes=0,sha256=None)
        return dict(path=asset['path'],url=asset['url'],curl_exit=r.returncode,curl_output=r.stdout,stderr=r.stderr,normal_TLS=True,HTTP='1.1 requested',seconds=time.perf_counter()-start,**actual,expected_bytes=asset['bytes'],expected_sha256=asset['sha256'],match=r.returncode==0 and actual['bytes']==asset['bytes'] and actual['sha256']==asset['sha256'])
    entries=[];started=time.perf_counter()
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures={pool.submit(check,a):a for a in prepared['assets']}
        for future in as_completed(futures):
            asset=futures[future]
            try:e=future.result()
            except Exception as error:e=dict(path=asset['path'],url=asset['url'],match=False,error=type(error).__name__+': '+str(error))
            entries.append(e)
            save(ROOT/'publication/live-byte-check-progress-v1.json',dict(status='CHECKING',commit=prepared['commit'],checked=len(entries),total=len(futures),failures=sum(not x['match'] for x in entries),assets=entries))
            if not e['match'] or len(entries)%32==0 or len(entries)==len(futures):print(json.dumps(dict(checked=len(entries),total=len(futures),failures=sum(not x['match'] for x in entries))),flush=True)
    entries.sort(key=lambda e:e['path']);passed=len(entries)==len(prepared['assets']) and all(e['match'] for e in entries);archive=None
    if passed:
        try:
            manifest=json.loads((destination/MANIFEST).read_text());archive=verify_archive(destination,manifest)
        except Exception as error:
            archive=dict(status='FAIL',error=type(error).__name__+': '+str(error));passed=False
    receipt=dict(status='PASS' if passed else 'FAIL',commit=prepared['commit'],workers=args.workers,normal_TLS=True,HTTP='1.1 requested',assets=entries,archive=archive,seconds=time.perf_counter()-started,scope='Every prepared web body byte checked; every original archive path physically stored in the full ZIP checked with every CRC.')
    save(ROOT/'publication/live-byte-check-v1.json',receipt)
    print(json.dumps(dict(status=receipt['status'],assets=len(entries),archive=archive),sort_keys=True))
    raise SystemExit(0 if passed else 1)

if __name__=='__main__':main()
