"""Passive saved-reader/proof/row/download associations; no scientific imports."""
import gzip
import hashlib
import ast
import html
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def wire(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       separators=(',', ':'), allow_nan=False)+'\n').encode('ascii')


def same(a, b):
    assert wire(a) == wire(b)


def stream_pin(stream):
    h, size = hashlib.sha256(), 0
    for block in iter(lambda: stream.read(1048576), b''):
        h.update(block)
        size += len(block)
    return dict(bytes=size, sha256=h.hexdigest())


def pin(path):
    with path.open('rb') as stream:
        return stream_pin(stream)


def local(relative):
    path = ROOT/relative
    assert not path.is_symlink()
    for parent in path.parents:
        if parent == ROOT:
            break
        assert not parent.is_symlink()
    path = path.resolve()
    assert path.is_relative_to(ROOT)
    return path


def read(relative):
    path = local(relative)
    with (gzip.open(path, 'rt', encoding='ascii') if path.suffix == '.gz'
          else path.open(encoding='ascii')) as stream:
        return json.load(stream)


def ref(value):
    same(pin(local(value['path'])), {key: value[key] for key in ('bytes', 'sha256')})
    result = read(value['path'])
    for part in value.get('pointer', '').split('/')[1:]:
        key = part.replace('~1', '/').replace('~0', '~')
        result = result[int(key)] if type(result) is list else result[key]
    return result


def main():
    summary = read('data/report-summary-v1.json')
    view = read('report/resource-diagnostic-results-v1.json.gz')
    assert summary['schema'] == 'Resource-diagnostic-saved-summary-v1'
    assert summary['status'] == view['status'] == 'ADMITTED_DIAGNOSTIC_WITH_PRESERVED_FAILURE_AND_UNKNOWN'
    same(view['input_summary_pin'], pin(local('data/report-summary-v1.json')))
    saved = {r['id']: r for r in summary['records']}
    displayed = {r['id']: r for r in view['records']}
    assert len(saved) == len(displayed) == 8 and set(saved) == set(displayed)
    rows_checked = proof_lines = formula_refs = request_ports = 0
    positive = []
    counters = []
    for identity, original in saved.items():
        record = displayed[identity]
        for key, value in original.items():
            same(record[key], value)
        assert record['method'] == 'point'
        if record['kind'] == 'FIRST_ATTEMPT':
            assert record['process']['status'] == 'FAILED_POSTCHECK_AFTER_SCIENCE'
            assert type(record['process']['native_exit_code']) is int and record['process']['native_exit_code'] == 1
            assert record['process']['execution_admitted'] is False
        else:
            assert record['kind'] == 'CONTINUATION' and record['process']['execution_admitted'] is True
            assert record['process']['native_exit_code'] == 0
        if not record['proof_reader']:
            assert record['selected'] == record['selected_rows'] == record['slot_rows'] == []
            assert record['admission']['status'] == record['admission']['absence'] == 'UNKNOWN'
            assert record['mark_display']['status'] == 'NO_POINT_CERTIFICATE'
            assert record['mark_display']['slots'] == []
            continue
        assert record['status'] == 'SAT' and record['admission']['status'] == 'VERIFIED_POSITIVE'
        prepared = ref(record['prepared_ref'])
        decoded = ref(record['decoded_ref'])
        native_proof = ref(record['proof_ref'])
        same(decoded['proof'], native_proof)
        same(record['proof_dag'], decoded['proof_dag'])
        same(record['slot_rows'], decoded['slots'])
        same(record['reference_mapping'], decoded['reference_mapping'])
        same(record['case']['statement'], decoded['statement'])
        full_universe = {r['id']: r for r in prepared['universe']}
        actual = {r['id']: r for r in record['selected_rows']}
        assert len(actual) == len(record['selected']) and set(actual) == set(record['selected'])
        for cid, row in actual.items():
            same(row, full_universe[cid])
        display_slots = {r['slot']: r for r in record['mark_display']['slots']}
        assert len(display_slots) == prepared['binding']['slots']
        by_slot = {r['slot']: r for r in decoded['slots']}
        assert set(display_slots) == set(by_slot)
        for index, slot in by_slot.items():
            shown = display_slots[index]
            same(shown['exact'], actual[slot['cid']])
            assert shown['line_index'] == slot['native_line_index_or_null']
            assert shown['active']['value'] == str(slot['active'])
            assert shown['formula']['value'] == str(slot['formula_id'])
            action = json.loads(slot['cid'])
            assert shown['kind'] == action[3] and shown['refs'] == action[5]
            own = {}
            remote = []
            for point, value in actual[slot['cid']]['m']:
                port = json.loads(point)
                layer = 'active' if port[0] == 'DAG-slot-active-v1' else 'formula'
                assert port[0] in ('DAG-slot-active-v1', 'DAG-slot-formula-v1')
                if port[2] == index:
                    own[layer] = dict(point=point, value=value)
                else:
                    remote.append(dict(channel=layer, owner_slot=port[2], point=point, value=value))
            same(shown['active'], own['active'])
            same(shown['formula'], own['formula'])
            same(shown['requests'], remote)
            for request in shown['requests']:
                owner = display_slots[request['owner_slot']]
                assert owner[request['channel']]['value'] == request['value']
            rows_checked += 1
            request_ports += len(remote)
        for i, (line, reader) in enumerate(zip(native_proof, record['proof_reader'])):
            assert reader['line'] == i+1 and reader['rule'] == line['rule']
            same(reader['formula'], line['formula'])
            assert reader['slot'] == decoded['native_to_slot'][i]
            node = decoded['proof_dag']['nodes'][i]
            assert node['line'] == i and reader['formula_id'] == node['formula_id']
            same(reader['formula'], prepared['catalogue']['formulas'][reader['formula_id']-1])
            dependencies = [line['antecedent'], line['implication']] if line['rule'] == 'mp' else []
            assert reader['dependencies'] == [j+1 for j in dependencies]
            assert all(type(j) is int and 0 <= j < i for j in dependencies)
            formula_refs += len(dependencies)
            proof_lines += 1
        assert len(native_proof) == len(record['proof_reader'])
        same(native_proof[-1]['formula'], record['case']['statement']['goal'])
        native_receipt = ref(record['refs']['native_B'])
        assert native_receipt['status'] == 'VERIFIED' and native_receipt['checked_lines'] == len(native_proof)
        positive.append(dict(id=identity, proof_lines=len(native_proof), slots=len(by_slot),
            process_status=record['process']['status'], native_exit_code=record['process']['native_exit_code']))
        stats, old_limits = record['resources']['stats'], record['old_pilot']['limits']
        counters.append(dict(id=identity, recorded_work=stats['work'], old_numeric_work_limit=old_limits['max_work'],
            below_old_numeric_work_limit=stats['work'] <= old_limits['max_work'],
            interpretation='Recorded numeric comparison only; work composition/caps/callback changed, no counterfactual run.'))
    downloads = view['downloads']
    assert len({d['download'] for d in downloads}) == len(downloads)
    assets = {}
    for item in downloads:
        original = local(item['original'])
        expected = dict(bytes=item['original_bytes'], sha256=item['original_sha256'])
        same(pin(original), expected)
        relative = 'report/'+item['download']
        assert relative.endswith(('.json', '.gz'))
        target = local(relative)
        same(pin(target), {key: item[key] for key in ('bytes', 'sha256')})
        if item['wrapped_gzip']:
            with gzip.open(target, 'rb') as stream:
                same(stream_pin(stream), expected)
        else:
            same(pin(target), expected)
        assets[item['download']] = item
    for record in view['records']:
        for link in record['downloads'].values():
            assert link['url'] in assets and local('report/'+link['url']).is_file()
    first = [r for r in view['records'] if r['kind'] == 'FIRST_ATTEMPT']
    assert len(first) == 1 and len(positive) == 5
    same(view['old_pilot_limits'], summary['old_pilot_limits'])
    assert view['coverage']['same_positive_examples_as_historical_forward'] is True
    # Independent template-byte association only; no builder import or build.
    source_path = local('report/build_resource_report_v1.py')
    syntax = ast.parse(source_path.read_bytes())
    constants = {node.targets[0].id: ast.literal_eval(node.value) for node in syntax.body
        if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name)
        and isinstance(node.value, ast.Constant) and node.targets[0].id in ('CSS', 'BODY', 'SCRIPT')}
    page_node = next(node for node in syntax.body if isinstance(node, ast.FunctionDef) and node.name == 'page')
    config = ast.literal_eval(next(node.value for node in page_node.body
        if isinstance(node, ast.Assign) and node.targets[0].id == 'config'))
    expected_main = ('<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
        '<title>'+html.escape('Point-search resource diagnostic · GCTS research')+'</title><style>'+constants['CSS']+'</style>'+config+
        '<script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-svg.js"></script></head><body>'+constants['BODY']+
        '<script>'+constants['SCRIPT']+'</script></body></html>').encode()
    begin, end = b'<!-- RESOURCE_DIAGNOSTIC_ARCHIVE_LINK -->', b'<!-- /RESOURCE_DIAGNOSTIC_ARCHIVE_LINK -->'
    actual_main = local('report/resource-diagnostic-v1.html').read_bytes()
    assert actual_main.count(begin) == actual_main.count(end) == 1
    left, tail = actual_main.split(begin)
    _, right = tail.split(end)
    assert left+begin+right == expected_main
    evidence = local('report/resource-diagnostic-evidence-v1.html').read_text()
    assert evidence.count(begin.decode()) == evidence.count(end.decode()) == 1
    for download in downloads:
        assert 'href="'+html.escape(download['download'], quote=True)+'"' in evidence
    receipt = dict(schema='Resource-reader-passive-data-audit-v1', status='PASS_PASSIVE_READER_DATA_ASSOCIATIONS',
        summary=pin(local('data/report-summary-v1.json')), reader=pin(local('report/resource-diagnostic-results-v1.json.gz')),
        records=8, native_admitted_positive_certificates=positive, proof_lines=proof_lines,
        selected_rows=rows_checked, long_range_request_ports=request_ports, native_reference_edges=formula_refs,
        complete_download_byte_hash_and_gzip_original_readbacks=len(downloads), numeric_observations=counters,
        main_HTML_matches_reviewed_Source_after_removing_archive_injection=True,
        evidence_download_links_present=len(downloads), report_source=pin(source_path),
        source=pin(Path(__file__).resolve()), scientific_modules_imported=False, scientific_reruns=False,
        scope='Only saved file/field/selected-row/proof projection associations and download readbacks. No engine, model constructor, native kernel, decoder, graph verifier or search replay executed; no new graph/absence/counterfactual claim.')
    target = ROOT/'review/resource-reader-data-audit-v1.json'
    with target.open('xb') as stream:
        stream.write(wire(receipt))
    print(json.dumps(dict(status=receipt['status'], records=8, positives=len(positive),
        proof_lines=proof_lines, selected_rows=rows_checked, downloads=len(downloads), receipt=pin(target)), sort_keys=True))


if __name__ == '__main__':
    main()
