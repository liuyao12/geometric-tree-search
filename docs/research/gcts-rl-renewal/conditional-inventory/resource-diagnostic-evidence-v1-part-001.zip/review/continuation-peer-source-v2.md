# CALv2 continuation independent Source review

Status: **PASS_SOURCE_REVIEW_FOR_PREFLIGHT_AND_FUTURE_FREEZE**. No blocking defect found in the reviewed continuation. This is Source/metadata review only. The reviewer did not import or execute the preflight, either driver, model/engine/static decoder/native checker, or any scientific function. No protocol was frozen and no new case result was read or constructed. Only this new-root review file was written; CALv1 and the published DAG/archive remain unchanged.

Reviewed pins:

| File | Bytes | SHA256 |
| --- | ---: | --- |
| `source/run_resource_diagnostic_v2.py` | 21678 | `7d2afdd63637a036fcf34c3325b0800f0c688ec4283a165ae161288ba5e87b9a` |
| `source/data_only_preflight_v1.py` | 6150 | `403b322f88f8c88d85ca4db6259f4ee0eff22be1a30100bd2933d966f53cf874` |
| `plan/input-declarations-v2.json` | 19545 | `2c2cfa764ec48004fe7af5d56bb41f7213f6064fe87f835bcc21db5b5be9f376` |
| `review/CALv1-to-CALv2-driver.patch` | 5348 | `86c92c6d621c1fa887ea87f09710ea517dfeb9f64efa7e519f2e046d7fe1e674` |

The reviewer previously read the whole executed CALv1 driver at `9d9995b3db26e889b22b40fdd8ceca45c1f7325427e83ff13520fce7ec8610c9`, its root/master review and all scientific call boundaries. The complete new diff, continuation API, literal seven-case metadata and preflight body were read. AST parsing and file hashes only were performed here.

The two faulty status accesses now select tuple element zero before the dictionary key. This matches the actual single `return protocol,plan` in `unchanged()`. The preflight examines that concrete AST return and all five real call sites: unpack, ignored validation call, or tuple-zero/status access. It does not import the driver or substitute mock science. It compares all scientific/diagnostic/worker/observer functions to the preserved executed baseline after exactly those two getter substitutions; only freeze/file-set metadata functions are excluded, and their complete diff is small and reviewed. Top-level changes are the continuation documentation and new declaration path.

The executable case list is exactly the original eight seen phase IDs minus `seen-off-dsgb-alternate-l10-v1`. The first case is not accepted by the supervisor or direct worker lookup. Its saved history remains `FAILED_POSTCHECK_AFTER_SCIENCE`, actual native exit one, `execution_admitted=false`, and `no_rerun=true`. Its valid saved proof evidence is a separate passive-audit matter; the continuation never loads or assumes it as a witness.

The remaining seven declaration/prepared/gate sets retain identical case contents and 21 byte refs. Point, decoder, native, capture and outer guard limits remain the original diagnostic values. The preflight checks these bindings and dependency bytes as data only and does not parse prepared models. The same full finite universes, lexical point search, complete static selection decoding and fresh native gates are used. Raw UNSAT still carries no independent absence admission and no audit-off result claims full graph conformance.

The history reference manifest is added to the frozen file set together with preserved baseline Source/declarations. It is opaque archive metadata, not a driver input bank or scientific import path. History payload materialization must be a later byte-verified Root custody step; references alone are not a physical full archive. All science outputs resolve within the new CALv2 root and retain exclusive first-attempt writes and owned process guards. The earlier failed attempt and all its costs remain evidence, not a clean native run.

Root may now review/execute the data-only preflight, inspect its actual receipt, then explicitly freeze and run only the seven remaining phases. This Source review does not assert that preflight or science has passed. The final Source/peer files are held unchanged after handoff.
