# Resource diagnostic publication: Source-only handoff

All five scripts are adapted from the exact published shared-DAG publication Sources, retained under `review/publication-dag-baseline-v1/` with original pins. The complete current adaptation is `review/publication-adaptation-diff-v1.patch`. The original Source-only handoff metadata is preserved under `review/publication-before-summary-association-v1/`; Root also retained the pre-association common Source separately. Since that initial handoff, Root has performed the official read-only remote-base observation and local `--prepare-links` using the old common Source. No archive package, Git mutation, live download, mirror copy or scientific execution has been performed by these publication tools at this metadata update. This author's update is AST/static metadata work only.

The existing destination remains `docs/research/gcts-rl-renewal/conditional-inventory/` in `liuyao12/geometric-tree-search`. New names are `resource-diagnostic-v1.html`, `resource-diagnostic-evidence-v1.html`, `resource-diagnostic-results-v1.json.gz`, `resource-diagnostic-downloads-v1/`, and `resource-diagnostic-evidence-v1-part-NNN.zip` plus its manifest. The only allowed modified existing web path is `shared-search-v1.html`, receiving one backlink. Every new asset collision is refused. The primary checkout/index is never staged.

## Evidence gates

The summary must have schema `Resource-diagnostic-saved-summary-v1`, status `ADMITTED_DIAGNOSTIC_WITH_PRESERVED_FAILURE_AND_UNKNOWN`, and eight records. The saved audit must have schema `Resource-diagnostic-saved-audit-v1`, status `PASS_SAVED_DATA_AUDIT`.

The current `verify_summary` additionally requires `summary.saved_data_audit.path` to be exactly `review/saved-data-audit-v1.json`, checks that file's actual bytes/SHA256 against the summary ref, loads its exact schema/status, and compares summary/audit coverage by canonical wire equality. Thus independently acceptable status strings alone cannot substitute a different saved audit. This is a custody/content association check, not a rerun of scientific assurance.

Mandatory readiness receipts and exact statuses:

- `review/saved-data-audit-v1.json`: `PASS_SAVED_DATA_AUDIT`.
- `review/report-build-v1.json`: `PASS_REPORT_BUILD`.
- `review/local-ui-qualification-v1.json`: `PASS_LOCAL_UI`, zero math errors, no body overflow or console entries, with the final main page's current bytes/hash.
- `review/root-publication-admission-v1.json`: `PASS`, written by Root only after final review/readiness.
- `review/first-attempt-materialization-v1.json`: `PHYSICALLY_MATERIALIZED_ALL_FIRST_ATTEMPT_ORIGINALS`.
- `review/first-attempt-passive-audit-v1.json`: `PASS_PASSIVE_SAVED_PROOF_JOINS_WITH_FAILED_EXECUTION`.

Publication independently joins the exact 33 frozen CALv2 files, unchanged reviewed driver, driver peer, data-only preflight, runtime executable and current/copy master. It requires all seven declared continuation started/invocation/observer phase/PID/protocol joins, native exit zero, no guard/observer/reap/postcheck error, and invocation scientific status matching the actual saved result. Resource UNKNOWN inside a clean native execution is preserved, not reclassified as a negative.

The first attempt is a separate required historical gate. All 51 original CALv1 paths must physically exist under `history/first-attempt-v1/files/` with exact hashes and no extra/aliased paths. The immutable reference manifest is supplemented by the later materialization receipt. Its actual first started/invocation/observer/log and frozen Source bytes are checked from that local physical copy. Native exit remains one, invocation ERROR and both tuple-postcheck failures remain FAILED. The independent saved logical audit can admit its five-line SAT proof without changing `execution_admitted=false`. Summary records must expose this distinction and retain absence UNKNOWN/full graph conformance NOT_MEASURED.

## Physical archive and isolated preparation

`package_publish_v1.py --prepare-links` writes only the task README/archive-link plan and page link blocks, then final UI must be revalidated. It does not build a ZIP or stage Git. Package preparation later takes an explicitly reviewed 40-hex remote base. It refuses any previous package/prepared/index attempt rather than overwriting it.

Every original CALv2 file present at the cut is included, including publication Sources, baseline copies, API/diff/review files, archive-planning metadata and all scientific raw/receipt paths. Only generated `package/` outputs are excluded because an archive cannot include itself. Deployment receipts created after that cut remain later custody evidence, not falsely claimed original archive contents.

Each original path is physically stored once across independent ZIP volumes; no content-dedup aliases replace bytes. Every part is at most 44 MiB and below GitHub's 50-MiB task asset ceiling. Every ZIP has an identical internal full manifest. Verification checks exact member sets, every CRC, every uncompressed original path/size/SHA256, final part bytes/hash, and all 51 direct original-to-materialized first-attempt paths. The manifest's `preserved_first_attempt_originals.files` provides that direct submanifest; its paths also occur in the ordinary part-assigned full file list.

After complete archive verification, an official read-only GitHub GET confirms remote main still equals the reviewed base. Local commit creation uses an isolated bare repository/index with hooks disabled; the exact tree diff must be additions only except the sole shared-search backlink. The commit has exactly that base as its one parent. This script never pushes. Root's later publication must use a normal non-force push of this prepared commit; a moved remote base requires review rather than a forced replacement.

## Observation and completion

`observe_github_v1.py` uses bounded official GETs for remote main, commit/tree/sole-parent and exact Pages workflow/head/branch/repository/completed-success evidence. It preserves replaced observations. `verify_live_v1.py` is byte-identical to the hardened baseline: normal TLS, HTTPS-only redirects, HTTP/1.1 and exact bytes for every prepared asset, followed by every physical ZIP original and CRC from live downloaded parts.

`complete_publication_v1.py` requires remote/main/Pages, all live bodies, archive/readiness/protocol/history, final local/live UI and current original bytes to agree. Its primary-project research-run mirror preflights all collisions and accepts only byte-identical existing files; it creates only missing task files and verifies every copy. Generated completion receipts are written exclusively/idempotently after that verification. No scientific Source is changed and the research program remains ACTIVE.

Root must read the full Sources and diff before any script execution. Local/archive readiness and normal deployment/live verification are separate stages. These tools do not strengthen the scientific result: no new theorem, full per-run graph certificate, independent absence, RL advantage, broad ATP superiority, PA/Hilbert completeness, universal Wang or plane-tiling claim is introduced.
