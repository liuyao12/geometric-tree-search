"""Passive resource-diagnostic custody/receipt joins; no scientific imports.

Requires seven completed CALv2 processes and the physically retained failed
CALv1 first attempt. Saved checkpoints are hashed, not semantically replayed.
Static selected point arithmetic and literal decoder associations do not
establish an internal search/graph or absence certificate.
"""
from collections import Counter
import copy
import gzip
import hashlib
import json
import math
from pathlib import Path
import re
import sys

ROOT=Path(__file__).resolve().parents[1]
HISTORY='history/first-attempt-v1/files/'
MANIFEST='history/first-attempt-v1/reference-manifest-v1.json'
FIRST='seen-off-dsgb-alternate-l10-v1'
OLD_PROTOCOL='comparison/old-pilot-protocol-v1.json'
OLD_PROTOCOL_PIN=dict(bytes=5030,sha256='dea6491b67c2c8c3bda9d933a23f770e545385f16dd08ab1d397a0d7aa503c65')
SEMANTIC=('statement','proof','slots','slot_to_native','native_to_slot',
    'reference_mapping','proof_dag','selected','selected_sha256',
    'original_statement_sha256','scope')


def wire(x):return (json.dumps(x,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')
def sha(x):return hashlib.sha256(wire(x)).hexdigest()
def same(a,b):return wire(a)==wire(b)
def path(name):
    assert type(name) is str and name and not Path(name).is_absolute()
    p=(ROOT/name).resolve();assert p.is_relative_to(ROOT),name
    return p
def pin(p):
    h=hashlib.sha256();size=0
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b);size+=len(b)
    return dict(bytes=size,sha256=h.hexdigest())
def read(name):
    p=path(name)
    with (gzip.open(p,'rt',encoding='ascii') if p.suffix=='.gz' else p.open('r',encoding='ascii')) as f:return json.load(f)
def save(name,x):
    p=path(name);p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('xb') as f:f.write(wire(x))
    return dict(path=name,**pin(p))
def elapsed(v):assert type(v) in (int,float) and math.isfinite(v) and v>=0;return v


class Tokens:
    """Exact token hashes for the frozen compact canonical JSON writer."""
    def __init__(self,f):self.f=f;self.buf=b'';self.i=0
    def peek(self):
        if self.i==len(self.buf):self.buf=self.f.read(1048576);self.i=0
        assert self.buf,'UNFINISHED_JSON';return self.buf[self.i]
    def char(self):v=self.peek();self.i+=1;return v
    def token(self,capture=True):
        h=hashlib.sha256();parts=[];first=self.peek();stack=[];quoted=False;escaped=False;done=False
        if first in (123,91):
            while not done:
                self.peek();start=self.i
                while self.i<len(self.buf):
                    c=self.buf[self.i];self.i+=1
                    if quoted:
                        if escaped:escaped=False
                        elif c==92:escaped=True
                        elif c==34:quoted=False
                    elif c==34:quoted=True
                    elif c in (123,91):stack.append(c)
                    elif c in (125,93):
                        assert stack and (stack[-1],c) in ((123,125),(91,93));stack.pop()
                        if not stack:done=True;break
                b=self.buf[start:self.i];h.update(b)
                if capture:parts.append(b)
        elif first==34:
            beginning=True
            while True:
                c=self.char();b=bytes((c,));h.update(b)
                if capture:parts.append(b)
                if beginning:beginning=False;continue
                if escaped:escaped=False
                elif c==92:escaped=True
                elif c==34:break
        else:
            while self.peek() not in (9,10,13,32,44,93,125):
                b=bytes((self.char(),));h.update(b)
                if capture:parts.append(b)
        h.update(b'\n');return (json.loads(b''.join(parts)) if capture else None),h.hexdigest()


def projected_raw(name):
    raw={};checkpoints={}
    with gzip.open(path(name),'rb') as f:
        s=Tokens(f);assert s.char()==123
        while True:
            key,_=s.token();assert key not in raw and s.char()==58
            keep=key not in ('entry_state','final_state','restored_state')
            value,digest=s.token(keep);raw[key]=value
            if not keep:checkpoints[key]=digest
            c=s.char()
            if c==125:break
            assert c==44
        assert s.buf[s.i:]+f.read()==b'\n'
    for key,digest in checkpoints.items():
        expected=raw['state_hashes'][key.removesuffix('_state')]
        assert digest==(sha(None) if expected is None else expected)
    assert raw['state_hashes']['entry']==raw['state_hashes']['restored']
    for values,extent in (('events','event_extent'),('rollback_records','rollback_extent')):
        xs=raw[values];e=raw[extent];assert e['retained']==len(xs)<=e['total']
        if len(xs)==e['total']:
            h=hashlib.sha256()
            for x in xs:h.update(wire(x))
            assert h.hexdigest()==e['sha256']
    return raw,dict(checkpoint_hashes=checkpoints,event_extent=raw['event_extent'],
        rollback_extent=raw['rollback_extent'],events_complete=len(raw['events'])==raw['event_extent']['total'],
        rollbacks_complete=len(raw['rollback_records'])==raw['rollback_extent']['total'],
        scope='Exact saved checkpoint tokens; full journal digests checked only when all emitted records were retained. Truncated journals remain explicit prefixes. No graph or scheduler replay.')


def latex(f):
    if f[0]=='pred':
        assert f[2]==[] and re.fullmatch(r'[A-Za-z0-9_]+',f[1]);return r'\mathsf{'+f[1].replace('_',r'\_')+'}'
    assert f[0]=='imp';return r'\left('+latex(f[1])+r'\Rightarrow '+latex(f[2])+r'\right)'
def words(f):return 'proposition '+f[1] if f[0]=='pred' else 'if '+words(f[1])+', then '+words(f[2])
def human(statement,proof=None,decoded=None):
    theory=dict(hypotheses=[dict(name=n,formula=f,formula_latex=latex(f),english=words(f))
        for n,f in sorted(statement['theory']['axioms'].items())],
        goal=dict(formula=statement['goal'],formula_latex=latex(statement['goal']),english=words(statement['goal'])))
    rows=[]
    for i,line in enumerate(proof or []):
        assert line['rule'] in ('axiom','mp')
        deps=[line['antecedent'],line['implication']] if line['rule']=='mp' else []
        assert all(type(j) is int and 0<=j<i for j in deps)
        text='Use assumption '+line['name']+'.' if not deps else 'Apply the implication on line %d to line %d.'%(deps[1]+1,deps[0]+1)
        rows.append(dict(line=i+1,formula=line['formula'],formula_latex=latex(line['formula']),
            english=text+' '+words(line['formula'])+'.',rule=line['rule'],dependencies=[j+1 for j in deps],
            formula_id=decoded['proof_dag']['nodes'][i]['formula_id'] if decoded else None,
            slot=decoded['native_to_slot'][i] if decoded else None))
    return theory,rows


class Audit:
    def __init__(self):self.refs={};self.records=[]
    def ref(self,r,prefix=''):
        out=dict(r,path=prefix+r['path'])
        lexical=ROOT/out['path'];assert not lexical.is_symlink()
        for parent in lexical.parents:
            if parent==ROOT:break
            assert not parent.is_symlink()
        expected={k:r[k] for k in ('bytes','sha256')}
        assert same(pin(path(out['path'])),expected),out['path']
        self.refs[out['path']]=expected;return out
    def file(self,name):return self.ref(dict(path=name,**pin(path(name))))
    def load(self,r,prefix=''):
        r=self.ref(r,prefix);assert r.get('complete_json') is not False
        return read(r['path']),r
    def history(self):
        m=read(MANIFEST);self.file(MANIFEST)
        assert m['classification']=='FAILED_POSTCHECK_AFTER_SCIENCE' and m['native_exit_code']==1 and m['execution_admitted'] is False
        assert len(m['files'])==m['original_files']==51
        assert len({e['path'] for e in m['files']})==51
        for e in m['files']:self.ref(e,HISTORY)
        return dict(status='ALL_CALV1_ORIGINALS_PHYSICALLY_BYTE_VERIFIED',manifest=self.file(MANIFEST),files=51,prefix=HISTORY)
    def protocol(self,prefix,continuation):
        name=prefix+'data/protocol-frozen-v1.json';p=read(name);self.file(name)
        assert p['status']=='FROZEN_BEFORE_SCIENTIFIC_IMPORTS'
        assert p['schema']==('Shared-resource-audit-off-continuation-protocol-v2' if continuation else 'Shared-resource-audit-off-protocol-v1')
        base=path(prefix) if prefix else ROOT;files=[]
        for folder in ('source','reference','input','plan'):
            for f in (base/folder).rglob('*'):
                assert not f.is_symlink()
                if f.is_file() and '__pycache__' not in f.parts and f.suffix!='.pyc':files.append(f)
        extra=['review/input-dependency-snapshot-v1.json']
        if continuation:extra+=['review/CALv1-driver-preserved-v1.py','review/CALv1-input-declarations-preserved-v1.json',MANIFEST]
        files.extend(base/x for x in extra)
        actual=[dict(path=f.relative_to(base).as_posix(),**pin(f)) for f in sorted(files)]
        assert same(actual,p['files'])
        executable=p['runtime']['executable'];assert same(pin(Path(executable['path'])),{k:executable[k] for k in ('bytes','sha256')})
        assert p['runtime']['isolated']==p['runtime']['no_site']==1 and p['runtime']['dont_write_bytecode'] is True
        assert same(pin(Path(p['master']['path'])),{k:p['master'][k] for k in ('bytes','sha256')})
        assert same(pin(base/'reference/basic-tiling-algorithm.md'),{k:p['master'][k] for k in ('bytes','sha256')})
        return p,dict(protocol=self.file(name),frozen_files=len(actual),runtime_binary_bytes_match=True,current_master_bytes_match=True)
    def process(self,prefix,phase,p,first):
        refs={k:self.file(prefix+folder+'/'+phase+suffix) for k,folder,suffix in
            (('started','data','-started.json'),('invocation','review','-invocation.json'),('observer','review','-observer.json'))}
        start,inv,obs=(read(refs[k]['path']) for k in ('started','invocation','observer'))
        assert start['status']=='STARTED' and obs['status']=='TERMINAL'
        assert start['phase']==inv['phase']==obs['phase']==phase
        assert all(type(x['pid']) is int and x['pid']>0 for x in (start,inv,obs)) and start['pid']==inv['pid']==obs['pid']
        assert start['protocol_sha256']==sha(p) and obs['guard_reason'] is None
        assert obs['observer_error'] is obs['reap_error'] is None
        refs['log']=self.ref(obs['log'],prefix)
        if first:
            assert obs['native_exit_code']==1 and inv['status']=='ERROR'
            assert inv['frozen_postcheck']==obs['frozen_postcheck']=='FAILED'
            assert inv['postcheck_error']==obs['postcheck_error']=='tuple indices must be integers or slices, not str'
            status='FAILED_POSTCHECK_AFTER_SCIENCE'
        else:
            assert type(obs['native_exit_code']) is int and obs['native_exit_code']==0 and inv['status']=='COMPLETE'
            assert inv['frozen_postcheck']==obs['frozen_postcheck']==p['status']
            assert inv['postcheck_error'] is obs['postcheck_error'] is inv['error_type'] is None
            status='COMPLETE_NATIVE_EXECUTION'
        return dict(status=status,native_exit_code=obs['native_exit_code'],execution_admitted=not first,
            pid=start['pid'],phase=phase,worker_status=inv['status'],worker_scientific_status=inv['scientific_status'],
            frozen_postcheck=obs['frozen_postcheck'],postcheck_error=obs['postcheck_error'],refs=refs,
            observed_seconds=elapsed(obs['seconds']),worker_seconds=elapsed(inv['seconds']),
            sampled_peak_rss_bytes=obs['peak_observed_rss_bytes'],native_lifetime_maxrss=inv['maxrss'],native_lifetime_maxrss_units=inv['maxrss_units'])
    def selected(self,model,universe,selected,certificate):
        byid={r['id']:r for r in universe};assert len(byid)==len(universe) and len(set(selected))==len(selected)
        rows=[byid[c] for c in selected];totals=dict(model['seed']['t']);marks={p:[v,1] for p,v in model['seed']['m']}
        for row in rows:
            for p,n in row['t']:totals[p]=totals.get(p,0)+n;assert totals[p]<=model['capacity']
            for p,v in row['m']:
                if p in marks:assert marks[p][0]==v;marks[p][1]+=1
                else:marks[p]=[v,1]
        assert all(totals.get(p,0)==model['capacity'] for p in model['roots'])
        expected=dict(capacity=model['capacity'],roots=model['roots'],seed=model['seed'],placements=rows,
            totals=sorted([[p,n] for p,n in totals.items()]),marks=sorted([[p,v,n] for p,(v,n) in marks.items()]))
        assert same(expected,certificate);return rows
    def projection(self,prepared,selected,decoded):
        """Literal stored-CID/slot/reference joins, not a new logical check."""
        actions=[(json.loads(c),c) for c in selected];actions.sort(key=lambda x:x[0][2])
        n=prepared['binding']['slots'];scope=prepared['binding']['scope']
        assert len(actions)==n and [a[0][2] for a in actions]==list(range(n))
        active=[a[0][2] for a in actions if a[0][3]!='PAD'];slot_map=[None]*n
        for i,s in enumerate(active):slot_map[s]=i
        assert decoded['native_to_slot']==active and same(decoded['slot_to_native'],slot_map)
        defs=prepared['definitions'];zeros={d['id']:d for d in defs['zeros']};mp={d['id']:d for d in defs['mp']}
        slots=[];mapping=[];nodes=[];edges=[]
        for action,cid in actions:
            tag,actual_scope,s,kind,did,refs=action
            assert wire(action).decode('ascii')==cid and tag=='DAG-candidate-v1' and actual_scope==scope
            assert kind in ('ZERO','MP','PAD')
            out=0 if kind=='PAD' else (zeros[did] if kind=='ZERO' else mp[did])['output']
            slots.append(dict(slot=s,cid=cid,active=int(kind!='PAD'),formula_id=out,native_line_index_or_null=slot_map[s]))
            if kind=='PAD':assert refs==[] and did=='pad';continue
            line=decoded['proof'][slot_map[s]];assert same(line['formula'],prepared['catalogue']['formulas'][out-1])
            nodes.append(dict(line=slot_map[s],slot=s,formula_id=out))
            if kind=='ZERO':assert refs==[] and same(line,zeros[did]['native'])
            else:
                assert len(refs)==2 and all(type(j) is int and 0<=j<s and slot_map[j] is not None for j in refs)
                old=dict(antecedent=refs[0],implication=refs[1]);new={k:slot_map[j] for k,j in old.items()}
                assert line['rule']=='mp' and all(type(line[k]) is int and line[k]==v for k,v in new.items())
                mapping.append(dict(slot=s,native_line=slot_map[s],rule='mp',slot_references=old,native_references=new))
                edges.extend(dict(premise=v,conclusion=slot_map[s],field=k) for k,v in new.items())
        assert same(decoded['slots'],slots) and same(decoded['reference_mapping'],mapping)
        assert same(decoded['proof_dag'],dict(nodes=nodes,edges=edges))
    def case(self,entry,prefix,p,old_metrics,old_index,old_limits,first=False):
        phase=entry['id'];process=self.process(prefix,phase,p,first)
        result_name=prefix+'data/'+phase+'-result.json';out=read(result_name);self.file(result_name)
        assert out['id']==phase and process['worker_scientific_status']==out['status']
        assert same(out['inputs'],entry['inputs'])
        inputs={k:self.ref(r,prefix) for k,r in entry['inputs'].items()}
        declaration=read(inputs['declaration']['path']);prepared=read(inputs['prepared']['path']);model=prepared['model']
        assert declaration['id']==entry['source_case_id'] and same(declaration['statement'],prepared['statement'])
        assert sha(model)==entry['admitted_input_binding']['model_sha256'] and sha(prepared['universe'])==entry['admitted_input_binding']['universe_sha256']
        refs={k:self.ref(r,prefix) for k,r in out['refs'].items()}
        fresh=read(refs['fresh_input_admission']['path']);science=out['status']
        if science!='UNKNOWN_INPUT_ADMISSION':
            assert fresh['status']=='VERIFIED' and fresh['model_sha256']==sha(model) and fresh['universe_sha256']==sha(prepared['universe'])
            assert all(same(fresh[k],v) for k,v in entry['admitted_input_binding'].items())
        else:assert fresh['status']=='UNKNOWN'
        raw=None;custody=None;raw_status=out.get('raw_engine_status') or 'UNKNOWN'
        if 'actual_outcome' in refs:
            assert refs['actual_outcome']['complete_json'] is True
            compact=read(refs['actual_outcome']['path']);assert compact['status']==raw_status and compact['model_sha256']==sha(model)
            assert same(compact['limits'],p['point_limits'])
            assert same(out['stats'],compact['stats']) and out['raw_reason']==compact['reason']
            assert same(out['event_extent'],compact['event_extent']) and same(out['rollback_extent'],compact['rollback_extent'])
            if refs['raw_result']['complete_json']:
                raw,custody=projected_raw(refs['raw_result']['path'])
                assert all(same(v,raw[k]) for k,v in compact.items())
            else:assert science=='UNKNOWN_CAPTURE'
        assert raw_status in ('SAT','UNSAT','UNKNOWN')
        statement=declaration['statement'];decoded=None;proof=[];selected=[];selected_rows=[];admission=copy.deepcopy(out['admission'])
        assert admission['full_graph_conformance']=='NOT_MEASURED'
        if science=='VERIFIED_POSITIVE':
            assert raw is not None and raw_status=='SAT'
            a=read(refs['adapter_decode']['path']);decoded=read(refs['independent_decode']['path']);native=read(refs['native_B']['path'])
            assert a['status']==decoded['status']=='UNVERIFIED_NATIVE_CERTIFICATE' and all(same(a[k],decoded[k]) for k in SEMANTIC)
            proof=decoded['proof'];selected=raw['selected'];selected_rows=self.selected(model,prepared['universe'],selected,raw['certificate'])
            self.projection(prepared,selected,decoded)
            assert same(decoded['statement'],statement) and decoded['original_statement_sha256']==sha(statement)==out['original_statement_sha256']
            assert decoded['selected']==sorted(selected) and decoded['selected_sha256']==sha(sorted(selected))==admission['selected_sha256']
            assert decoded['scope']==prepared['binding']['scope'] and len(proof)==out['proof_lines']<=declaration['profile']['slots']
            assert proof and same(proof[-1]['formula'],statement['goal']) and sha(proof)==out['proof_sha256']
            assert native['status']=='VERIFIED' and native['checked_lines']==len(proof) and sha(native)==admission['native_receipt_sha256']
            assert same(native['limits'],p['native_limits'])
            counts=Counter(l['rule'] for l in proof);assert all(type(v) is int and v==counts.get(k,0) for k,v in native['rule_counts'].items()) and sum(native['rule_counts'].values())==len(proof)
            assert admission['status']=='VERIFIED_POSITIVE' and admission['absence']=='NOT_CLAIMED'
        else:
            assert admission['status']=='UNKNOWN' and admission['absence']=='UNKNOWN'
            if raw_status=='UNSAT':assert science in ('UNVERIFIED_EXHAUSTION','UNKNOWN_CAPTURE')
        theory,reader=human(statement,proof,decoded)
        metrics_ref=self.file(HISTORY+'plan/saved-metrics-context-v1.json')
        old=old_metrics['rows'][old_index];assert old['id']==entry['source_case_id']
        previous=dict(status=old['point_status'],point_status=old['point_status'],forward_status=old['forward_status'],reason=None,limits=old_limits,
            stats=old['point_stats'],resources=dict(stats=old['point_stats']),
            costs=dict(old['costs'],search_seconds=old['point_stats']['elapsed_seconds'],point_pipeline_seconds=old['costs']['point_pipeline']),
            refs=dict(metrics=dict(metrics_ref,pointer='/rows/'+str(old_index)),protocol=self.file(OLD_PROTOCOL)),
            scope='Historical counters plus exact copied old protocol. Raw reason was not copied; no old control proof is supplied or attributed.')
        metadata=dict(scope=prepared['binding']['scope'],capacity=model['capacity'],slots=prepared['binding']['slots'],
            required_points=len(model['roots']),roots=model['roots'],universe_count=len(prepared['universe']),
            formula_count=len(prepared['catalogue']['formulas']),seed=model['seed'],
            formula_colors=[dict(value=str(i+1),formula=f,formula_latex=latex(f)) for i,f in enumerate(prepared['catalogue']['formulas'])],
            active_colors=[dict(value='0',meaning='PAD'),dict(value='1',meaning='Active native line')],padding_formula_color='0',
            coordinate_scope='Anchored semantic slot ports; not a planar Wang grid.',marking_scope='PROBLEM_DEFINING_NATIVE_PROOF_CONSTRAINTS')
        costs=dict(out.get('costs',{}),observer_seconds=process['observed_seconds'],worker_seconds=process['worker_seconds'],
            raw_engine_seconds=(out.get('stats') or {}).get('elapsed_seconds'),
            observed_process_seconds=process['observed_seconds'],measured_pipeline_seconds=out.get('seconds'),
            execution_failed=first,scope='Actual once-executed diagnostic costs, including the failed first attempt; nested clocks overlap and reused preparation is not cold.')
        record=dict(id=phase,case_id=entry['source_case_id'],case=declaration,method='point',kind='FIRST_ATTEMPT' if first else 'CONTINUATION',
            status=raw_status,science_status=science,reason=out.get('raw_reason') or admission.get('reason'),
            process=process,admission=admission,old_pilot=previous,costs=costs,
            resources=dict(stats=out.get('stats'),limits=p['point_limits'],internal_seconds=(out.get('stats') or {}).get('elapsed_seconds'),
                checkpoint_and_journal_custody=custody,capture_status=out.get('raw_capture_status'),full_graph_conformance='NOT_MEASURED'),
            raw_ref=refs.get('actual_outcome'),raw_full_ref=refs.get('raw_result'),prepared_ref=inputs['prepared'],
            model_ref=dict(inputs['prepared'],pointer='/model'),decoded_ref=refs.get('independent_decode') if decoded else None,
            proof_ref=dict(refs['independent_decode'],pointer='/proof') if decoded else None,
            refs=refs,proof_reader=reader,theory_reader=theory,proof_dag=decoded['proof_dag'] if decoded else None,
            selected=selected,selected_rows=selected_rows,slot_rows=decoded['slots'] if decoded else [],
            reference_mapping=decoded['reference_mapping'] if decoded else [],model_metadata=metadata,
            original_statement_sha256=sha(statement))
        self.records.append(record);return record


def main():
    audit=Audit();history=audit.history();old_p,old_guard=audit.protocol(HISTORY,False);p,guard=audit.protocol('',True)
    plan=read('plan/input-declarations-v2.json');audit.file('plan/input-declarations-v2.json')
    assert p['phase_ids']==[c['id'] for c in plan['cases']] and len(plan['cases'])==7
    assert FIRST not in p['phase_ids'] and plan['continuation_history']['execution_admitted'] is False
    assert set(p['phase_ids'])==set(old_p['phase_ids'])-{FIRST} and same(p['point_limits'],old_p['point_limits'])
    assert old_p['phase_ids'][0]==FIRST
    first_audit=read('review/first-attempt-passive-audit-v1.json');first_ref=audit.file('review/first-attempt-passive-audit-v1.json')
    assert first_audit['status']=='PASS_PASSIVE_SAVED_PROOF_JOINS_WITH_FAILED_EXECUTION'
    assert first_audit['execution']['native_exit_code']==1 and first_audit['execution']['execution_admitted'] is False
    assert same(pin(path(OLD_PROTOCOL)),OLD_PROTOCOL_PIN)
    old_protocol=read(OLD_PROTOCOL);audit.file(OLD_PROTOCOL)
    assert old_protocol['schema']=='Shared-fact-search-protocol-v1' and old_protocol['status']=='FROZEN_BEFORE_SCIENTIFIC_IMPORTS'
    old_limits=old_protocol['point_limits']
    old_plan=read(HISTORY+'plan/input-declarations-v1.json')
    metrics=read(HISTORY+'plan/saved-metrics-context-v1.json');assert metrics['status']=='SAVED_COUNTERS_ONLY_NO_SCIENCE_EXECUTED'
    index={row['id']:i for i,row in enumerate(metrics['rows'])};assert len(index)==8
    original={c['id']:c for c in old_plan['cases']};assert len(original)==8
    for phase in old_p['phase_ids']:
        first=phase==FIRST;entry=original[phase] if first else next(c for c in plan['cases'] if c['id']==phase)
        assert same(entry,original[phase])
        row=audit.case(entry,HISTORY if first else '',old_p if first else p,metrics,index[entry['source_case_id']],old_limits,first)
        if first:
            assert row['science_status']=='VERIFIED_POSITIVE' and row['status']=='SAT'
            assert sha(read(row['decoded_ref']['path'])['proof'])==first_audit['logical_evidence']['proof_sha256']
    coverage=dict(records=len(audit.records),original_cases=8,continuation_cases=7,
        raw_statuses=dict(Counter(r['status'] for r in audit.records)),science_statuses=dict(Counter(r['science_status'] for r in audit.records)),
        execution_admitted=sum(r['process']['execution_admitted'] for r in audit.records),preserved_failed_processes=1,
        separately_verified_positive_proofs=sum(r['admission']['status']=='VERIFIED_POSITIVE' for r in audit.records),
        clean_continuation_positive_proofs=sum(r['process']['execution_admitted'] and r['admission']['status']=='VERIFIED_POSITIVE' for r in audit.records),
        preserved_failed_process_positive_proofs=sum(not r['process']['execution_admitted'] and r['admission']['status']=='VERIFIED_POSITIVE' for r in audit.records),
        independently_verified_absence=0,full_graph_conformance_records=0,assembler_scientific_calls=0)
    old_forward_ids=sorted(row['id'] for row in metrics['rows'] if row['forward_status']=='DERIVABLE')
    point_positive_ids=sorted(r['case_id'] for r in audit.records if r['admission']['status']=='VERIFIED_POSITIVE')
    coverage.update(historical_forward_positive_case_ids=old_forward_ids,current_point_positive_case_ids=point_positive_ids,
        same_positive_examples_as_historical_forward=(old_forward_ids==point_positive_ids))
    assert old_forward_ids==point_positive_ids and len(point_positive_ids)==5
    assert coverage['records']==8 and coverage['execution_admitted']==7
    limitations=[__doc__,
        'The first native process remains exit1/FAILED_POSTCHECK_AFTER_SCIENCE despite separately valid saved proof evidence. The first case was not rerun.',
        'Only actual audit-off SAT selections with saved full static/native checks have proof readers. Raw UNSAT has absence UNKNOWN; all resource/assurance/capture refusals remain explicit.',
        'No callback graph stream or independent search-tree replay exists. Checkpoint/journal hashes are custody joins, not conformance or absence proofs.',
        'Seen inputs and reused preparation, fixed ordering and changed work/node/retention plus callback instrumentation. Historical figures are not a paired one-factor or cold speed comparison.',
        'The historical forward control had already found these same five positive case/bound examples. It was not rerun here; its earlier tiny pipeline clocks are not a fair paired timing comparison. This closes the point-search gap on seen examples, without a superiority or new-theorem claim.',
        'Native and static receipts supply their executed semantic gates; this assembler only joins saved bytes and literal associations. No science or historical control proof is rerun.',
        'No RL, learned marking, held-out generalization, broad ATP advantage, unrestricted logic completeness, literal Wang search or whole-plane result.']
    costs=dict(observer_seconds_total=sum(r['process']['observed_seconds'] for r in audit.records),
        worker_seconds_total=sum(r['process']['worker_seconds'] for r in audit.records),
        failed_first_attempt_observer_seconds=audit.records[0]['process']['observed_seconds'],
        scope='Includes the failed first native attempt. Inner diagnostic/component times overlap outer clocks; no invented sum or cold preparation.')
    audit.file('review/assemble_resource_results_v1.py')
    receipt=dict(schema='Resource-diagnostic-saved-audit-v1',status='PASS_SAVED_DATA_AUDIT',
        coverage=coverage,history=history,protocols=[old_guard,guard],first_attempt_passive_audit=first_ref,
        verified_artifact_refs=audit.refs,limitations=limitations)
    audit_ref=save('review/saved-data-audit-v1.json',receipt)
    summary=dict(schema='Resource-diagnostic-saved-summary-v1',status='ADMITTED_DIAGNOSTIC_WITH_PRESERVED_FAILURE_AND_UNKNOWN',
        records=audit.records,cases=audit.records,coverage=coverage,costs=costs,history=history,
        provenance=dict(protocols=[old_guard,guard],first_attempt_passive_audit=first_ref),
        old_pilot_limits=old_limits,old_pilot_protocol=audit.file(OLD_PROTOCOL),
        limitations=limitations,saved_data_audit=audit_ref)
    summary_ref=save('data/report-summary-v1.json',summary)
    print(json.dumps(dict(status=receipt['status'],audit=audit_ref,summary=summary_ref,coverage=coverage),sort_keys=True))


if __name__=='__main__':main()
