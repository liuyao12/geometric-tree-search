"""Byte/ZIP utilities; no scientific code, networking or Git operations."""
import hashlib
import json
from pathlib import Path,PurePosixPath
import zipfile

ROOT=Path(__file__).resolve().parents[1]
PREFIX='docs/research/gcts-rl-renewal/conditional-inventory/'
BASE_URL='https://liuyao12.github.io/geometric-tree-search/'
MANIFEST='shared-search-evidence-manifest-v1.json'
INTERNAL='ARCHIVE-file-manifest-v1.json'
PART_STEM='shared-search-evidence-v1-part-'
MAX_PART=44*1024*1024
PHASES=('qualify','dsgb-shared-l6-v1','dsgb-shared-l10-v1',
        'dsgb-shared-tail-l6-v1','dsgb-shared-tail-l10-v1',
        'dsgb-alternate-l6-v1','dsgb-alternate-l10-v1',
        'dsgb-ungrounded-l6-v1','dsgb-ungrounded-l10-v1')
READINESS=('review/saved-data-audit-v1.json','review/report-build-v1.json',
           'review/local-ui-qualification-v1.json')
SUMMARY_SCHEMA='Shared-fact-search-saved-summary-v1'
SUMMARY_STATUS='VERIFIED_PILOT_WITH_EXPLICIT_UNKNOWN'
AUDIT_SCHEMA='Shared-fact-search-saved-audit-v1'
AUDIT_STATUS='PASS_SAVED_DATA_AUDIT'
REPORT_BUILDER='report/build_shared_report_v1.py'
HISTORICAL_SOURCE='review/root-source-admission-v1.json'
HISTORICAL_STATUS='ROOT_SOURCE_READ_AND_AST_ONLY_PENDING_FINAL_PEER_CLOSURE'
REVIEWED_DRIVER={'path':'source/run_shared_search_v1.py','bytes':23579,
    'sha256':'ae7e94a02c0cc04de4d484ad7c7451ed8a42e99ecd7b777644ea7735aad6179b'}
DRIVER_PEER={'path':'review/peer-driver-controls-v1.md','bytes':4190,
    'sha256':'ff5047c007e80513ad0330a55d11e116d9430c0703107ed72e7682d7e3fa16f3'}
PRIMARY_MASTER=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md')

def wire(v):return (json.dumps(v,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')
def digest(raw):return hashlib.sha256(raw).hexdigest()
def stream_pin(stream):
    h=hashlib.sha256();size=0
    for block in iter(lambda:stream.read(1048576),b''):h.update(block);size+=len(block)
    return dict(bytes=size,sha256=h.hexdigest())
def pin(path):
    with path.open('rb') as f:return stream_pin(f)
def relative_name(value):
    assert type(value) is str and value and '\\' not in value and '\x00' not in value
    p=PurePosixPath(value)
    assert not p.is_absolute() and all(v not in ('','.','..') for v in p.parts) and p.as_posix()==value
    return value
def local(root,value):
    p=root/relative_name(value);assert root.resolve() in p.resolve().parents
    return p
def verify_protocol(relative,context_root=''):
    """Byte-only exact frozen inputs and nine completed original phase joins.

    Internal search UNKNOWN is permitted in completed admitted attempts. No
    missing/guarded process is promoted; no scientific module is imported.
    """
    path=local(ROOT,relative);value=json.loads(path.read_text())
    assert relative=='data/protocol-frozen-v1.json' and context_root==''
    assert value['schema']=='Shared-fact-search-protocol-v1' and value['status']=='FROZEN_BEFORE_SCIENTIFIC_IMPORTS'
    assert path.read_bytes()==wire(value),'Protocol must retain exact canonical saved bytes'
    paths=sorted([*ROOT.glob('source/*.py'),*ROOT.glob('reference/*.py'),
        *ROOT.glob('reference/upstream/*.py'),*ROOT.glob('reference/*.md'),
        *ROOT.glob('plan/*.md'),*ROOT.glob('plan/*.json'),*ROOT.glob('review/peer-*.md')])
    assert all(not p.is_symlink() for p in paths)
    current=[dict(path=p.relative_to(ROOT).as_posix(),**pin(p)) for p in paths]
    assert wire(current)==wire(value['files']),'Exact frozen Source/plan/peer file set changed'
    indexed={e['path']:e for e in current};assert len(indexed)==len(current)
    for expected in (REVIEWED_DRIVER,DRIVER_PEER):
        assert wire(indexed[expected['path']])==wire(expected),'Reviewed driver/peer pin changed'
    assert REVIEWED_DRIVER['sha256'] in local(ROOT,DRIVER_PEER['path']).read_text()
    runtime=value['runtime']
    executable=runtime['executable'];assert Path(executable['path']).is_absolute()
    assert wire(pin(Path(executable['path'])))==wire({k:executable[k] for k in ('bytes','sha256')})
    assert type(runtime['version']) is str and runtime['version']
    assert type(runtime['isolated']) is int and runtime['isolated']==1
    assert type(runtime['no_site']) is int and runtime['no_site']==1 and runtime['dont_write_bytecode'] is True
    master=indexed['reference/basic-tiling-algorithm.md']
    assert wire(pin(PRIMARY_MASTER))==wire({k:master[k] for k in ('bytes','sha256')})
    proposal=json.loads(local(ROOT,'plan/qualification-cases-proposal-v1.json').read_text())
    assert proposal['schema']=='Shared-fact-prospective-qualification-proposal-v1'
    assert ['qualify']+[e['case']['id'] for e in proposal['benchmark_cases']]==list(PHASES)
    phases=[]
    for phase in PHASES:
        started_name='data/'+phase+'-started.json'
        started=json.loads(local(ROOT,started_name).read_text())
        assert started['phase']==phase and started['status']=='STARTED'
        assert type(started['pid']) is int and started['pid']>0
        assert started['protocol_sha256']==digest(wire(value))
        refs={'started':dict(path=started_name,**pin(local(ROOT,started_name)))}
        for key,suffix in (('observer','-observer.json'),('invocation','-invocation.json')):
            name='review/'+phase+suffix;receipt=json.loads(local(ROOT,name).read_text())
            assert receipt['phase']==phase and type(receipt['pid']) is int and receipt['pid']==started['pid']
            assert receipt['frozen_postcheck']=='FROZEN_BEFORE_SCIENTIFIC_IMPORTS' and receipt['postcheck_error'] is None
            if key=='observer':
                assert receipt['status']=='TERMINAL' and type(receipt['native_exit_code']) is int
                assert receipt['native_exit_code']==0 and receipt['guard_reason'] is None
                log=receipt['log'];assert log['path']=='review/'+phase+'-native.log'
                assert wire(pin(local(ROOT,log['path'])))==wire({k:log[k] for k in ('bytes','sha256')})
                refs['log']=log
            else:
                assert receipt['status']=='COMPLETE' and receipt['error_type'] is None
            refs[key]=dict(path=name,**pin(local(ROOT,name)))
        result_name='data/'+phase+'-result.json';result=json.loads(local(ROOT,result_name).read_text())
        expected_status='VERIFIED_QUALIFICATION' if phase=='qualify' else 'COMPLETED_ADMITTED_ATTEMPTS'
        assert result['status']==expected_status
        if phase!='qualify':assert result['id']==phase
        refs['result']=dict(path=result_name,**pin(local(ROOT,result_name)))
        phases.append(dict(phase=phase,receipts=refs))
    return dict(path=relative,context_root=context_root,schema=value['schema'],
        phases=phases,source_pin_count=len(current),reviewed_driver=REVIEWED_DRIVER,
        driver_peer=DRIVER_PEER,**pin(path))
def inventory_from_manifest(manifest):
    assert manifest['schema']=='Shared-search-physical-multipart-evidence-v1' and manifest['inventory_file']==INTERNAL
    core={k:v for k,v in manifest.items() if k not in ('inventory_sha256','inventory_schema','inventory_file')}
    core['schema']=manifest['inventory_schema']
    core['parts']=[dict(number=p['number'],name=p['name']) for p in manifest['parts']]
    assert core['schema']=='Shared-search-physical-evidence-inventory-v1' and digest(wire(core))==manifest['inventory_sha256']
    return core
def verify_archive(folder,manifest):
    core=inventory_from_manifest(manifest);entries=manifest['files'];by_path={e['path']:e for e in entries}
    assert len(by_path)==len(entries)==manifest['original_files'] and manifest['all_originals_physically_stored'] is True
    assert sum(e['bytes'] for e in entries)==manifest['original_bytes']
    for e in entries:
        relative_name(e['path']);assert type(e['part']) is int and 1<=e['part']<=len(manifest['parts'])
    parts=[];verified=set()
    for number,part in enumerate(manifest['parts'],1):
        assert part['number']==number and part['name']==PART_STEM+'%03d.zip'%number
        archive=local(folder,part['name']);actual=pin(archive)
        assert wire(actual)==wire({k:part[k] for k in ('bytes','sha256')}) and actual['bytes']<=MAX_PART and actual['bytes']<50*1024*1024
        expected={e['path'] for e in entries if e['part']==number}
        with zipfile.ZipFile(archive) as z:
            assert len(z.namelist())==len(set(z.namelist())) and set(z.namelist())==expected|{INTERNAL}
            assert z.read(INTERNAL)==wire(core) and z.testzip() is None
            for name in sorted(expected):
                e=by_path[name];assert name not in verified and z.getinfo(name).file_size==e['bytes']
                with z.open(name) as stream:p=stream_pin(stream)
                assert wire(p)==wire({k:e[k] for k in ('bytes','sha256')});verified.add(name)
        parts.append(dict(number=number,name=part['name'],**actual,CRC='PASS'))
    assert verified==set(by_path)
    return dict(status='PASS',original_files=len(entries),all_original_files_physically_stored=True,
        all_original_paths_byte_verified=True,all_CRC_verified=True,parts=parts)
