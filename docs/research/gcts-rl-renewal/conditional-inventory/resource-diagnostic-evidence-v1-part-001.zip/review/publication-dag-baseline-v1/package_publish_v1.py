"""Prepare full approved physical evidence volumes and isolated Git commit.

Never pushes or stages primary. Run --prepare-links, validate final local UI,
then package BASE. If added files change volume count, repeat links/UI first.
"""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import zipfile
import zlib
sys.path.insert(0,str(Path(__file__).resolve().parent))
from evidence_common_v1 import ROOT,PREFIX,BASE_URL,MANIFEST,INTERNAL,PART_STEM,MAX_PART,READINESS,SUMMARY_SCHEMA,SUMMARY_STATUS,AUDIT_SCHEMA,AUDIT_STATUS,REPORT_BUILDER,HISTORICAL_SOURCE,HISTORICAL_STATUS,wire,digest,pin,relative_name,local,verify_archive,verify_protocol

GIT='/private/tmp/gcts-history-publication-20261102-v1.git'
MAIN='shared-search-v1.html'
EVIDENCE='shared-search-evidence-v1.html'
OLD='proof-reuse-v1.html'
BEGIN=b'<!-- SHARED_SEARCH_ARCHIVE_LINK -->';END=b'<!-- /SHARED_SEARCH_ARCHIVE_LINK -->'
RESERVE=2*1024*1024
README=b'''Finite shared-fact point proof search and controls, 2026-11-03.

Download EVERY shared-search-evidence-v1-part-NNN.zip and the external
shared-search-evidence-manifest-v1.json. Each volume is a separate valid ZIP,
at most forty-four MiB. Extract all volumes into one empty directory. Each has
the identical ARCHIVE-file-manifest-v1.json; identical copies may overwrite.
Every original task path is physically stored exactly once, without aliases or
deduplication. The manifest binds every original path/byte count/SHA256 and every
volume's completed bytes/hash. Publication verifies every original and every CRC.

All original task files at the archive cut are physically kept: Sources,
prospective declarations and protocol, full finite catalogues and point models,
raw point results and every retained observation, independent basis/model/full
frontier checks, decoded certificates and native checks, forward and reference
SAT control inputs/results/certificates, qualification mutations and resource
refusals, all UNKNOWNs, logs, reviews, report builder and viewer assets. No
duplicate-path aliases or reconstruction instructions replace original bytes.
Publication Python Sources are physically included. Generated package outputs
and publication planning/deployment receipts are excluded to avoid recursion.
Deployment receipts created after this cut remain local custody evidence. Full task archive
and local paths are explicitly approved for the existing public destination.

Serve the extracted directory with python3 -m http.server and open
report/shared-search-v1.html. Scientific code is inert data for the reader.
The declared finite pred0/imp profile uses named assumptions and structural MP.
Shared prior facts are read by remote active/formula markings without consuming
their owner capacity again. Each selected point certificate still requires full
point-trace, independent decoding and native logical admission. Controls use the
same admitted finite catalogue and line bound; assumptions are not free facts.
All solve refusals remain UNKNOWN. Related line bounds are not independent
theorems. The simple reference DPLL is not a modern SAT performance baseline.
This anchored semantic point search is not literal Wang-grid search or a
uniform finite palette. No GCTS/RL advantage, complete PA/Hilbert/FOL search or
plane-tiling result is established. The research program remains ACTIVE.
'''

GH='/Users/liuyao/bin/gh'
REPO='liuyao12/geometric-tree-search'

def fresh_remote_base(expected):
    """Official read-only GET immediately before preparing the local tree."""
    observed=json.loads(subprocess.check_output([GH,'api','--hostname','github.com','--method','GET',
        'repos/'+REPO+'/git/ref/heads/main'],timeout=50))
    assert observed['ref']=='refs/heads/main' and observed['object']['type']=='commit'
    assert observed['object']['sha']==expected,'Remote main changed; preserve package and prepare from a freshly reviewed remote base'
    receipt=dict(status='FRESH_REMOTE_BASE_CONFIRMED',repository=REPO,base=expected,
        observed_epoch=time.time(),method='Official GitHub GET git/ref/heads/main',response=observed)
    owned(ROOT/'publication/remote-base-at-prepare-v1.json',wire(receipt))
    return receipt

def load(name):return json.loads(local(ROOT,name).read_text())
def save(path,v):path.write_bytes(wire(v))
def owned(path,raw):
    if path.exists():assert path.read_bytes()==raw,'Preserve different bytes '+str(path)
    else:
        with path.open('xb') as f:f.write(raw)
def original_files():
    files=[]
    for p in sorted(ROOT.rglob('*')):
        name=p.relative_to(ROOT).as_posix()
        if name.split('/')[0]=='package':continue
        if name.split('/')[0]=='publication' and not (p.parent==ROOT/'publication' and p.suffix=='.py'):continue
        assert not p.is_symlink(),'Archive refuses symlink '+name
        if p.is_file():files.append(dict(path=relative_name(name),**pin(p)))
    assert INTERNAL not in {e['path'] for e in files}
    return files
def estimate(path):
    c=zlib.compressobj(6,zlib.DEFLATED,-15);size=0
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1048576),b''):size+=len(c.compress(block))
    return size+len(c.flush())
def partition(files):
    groups=[[]];used=0
    for e in files:
        charge=estimate(ROOT/e['path'])+256+4*len(e['path'].encode('utf8'))
        assert charge<=MAX_PART-RESERVE,'Single member too large for declared ZIP design: '+e['path']
        if groups[-1] and used+charge>MAX_PART-RESERVE:groups.append([]);used=0
        groups[-1].append(e['path']);used+=charge
    return groups
def names_for(n):return [PART_STEM+'%03d.zip'%i for i in range(1,n+1)]
def set_links(names):
    links=' · '.join('<a href="'+name+'">Evidence volume '+str(i)+'</a>' for i,name in enumerate(names,1))
    block=BEGIN+('<p>Full approved archive: '+links+' · <a href="'+MANIFEST+'">Every original file and volume hash</a>.</p><p>Download all volumes and extract together. Every Source/raw/log/recovery/UNKNOWN path is physically retained; no alias restoration is needed. Local paths are included with approval.</p>').encode('utf8')+END
    changed=[]
    for name in (MAIN,EVIDENCE):
        p=ROOT/'report'/name;raw=p.read_bytes()
        if BEGIN in raw:
            assert raw.count(BEGIN)==1
            if END in raw:
                assert raw.count(END)==1
                left,tail=raw.split(BEGIN);middle,right=tail.split(END);new=left+block+right
            else:new=raw.replace(BEGIN,block,1)
        else:
            assert raw.count(b'</h1>')==1
            new=raw.replace(b'</h1>',b'</h1>'+block,1)
        if new!=raw:p.write_bytes(new);changed.append(name)
    return changed
def prepare_links():
    owned(ROOT/'README-evidence-v1.txt',README)
    guess=1
    for iteration in range(16):
        names=names_for(guess);set_links(names);files=original_files();groups=partition(files)
        print(json.dumps(dict(phase='VOLUME_PLAN',iteration=iteration,files=len(files),volumes=len(groups))),flush=True)
        if len(groups)==guess:break
        guess=len(groups)
    else:raise AssertionError('Volume count did not stabilize')
    plan=dict(status='ARCHIVE_LINKS_PREPARED',parts=names,
        pages={name:dict(path='report/'+name,**pin(ROOT/'report'/name)) for name in (MAIN,EVIDENCE)},
        scope='Planning only. New UI/review files may change partitioning; package refuses changed volume count or page bytes. Revalidate final UI after any link change.')
    save(ROOT/'publication/archive-plan-v1.json',plan)
    print(json.dumps(dict(status=plan['status'],parts=names,next='Validate final local UI and preserve pinned receipts; do not rebuild report.')),flush=True)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('base',nargs='?');ap.add_argument('--prepare-links',action='store_true');ap.add_argument('--git-dir',default=GIT);ap.add_argument('--require-receipt',action='append',default=[]);args=ap.parse_args()
    if args.prepare_links:
        assert args.base is None;prepare_links();return
    assert args.base and len(args.base)==40 and all(c in '0123456789abcdef' for c in args.base)
    pub=ROOT/'publication';package=ROOT/'package'
    assert not package.exists() and not (pub/'prepared-v1.json').exists() and not (pub/'index-v1').exists(),'Preserve prior packaging attempt'
    summary=load('data/report-summary-v1.json');assert summary['schema']==SUMMARY_SCHEMA and summary['status']==SUMMARY_STATUS
    audit=load('review/saved-data-audit-v1.json');assert audit['schema']==AUDIT_SCHEMA and audit['status']==AUDIT_STATUS
    ui=load('review/local-ui-qualification-v1.json');assert ui['status']=='PASS_LOCAL_UI' and type(ui['math_errors']) is int and ui['math_errors']==0 and ui['body_overflow'] is False and ui['console']==[]
    source=ui['source'];assert source['path']=='report/'+MAIN and wire(pin(ROOT/source['path']))==wire({k:source[k] for k in ('bytes','sha256')})
    readiness=[]
    expected_statuses=dict(zip(READINESS,(AUDIT_STATUS,'PASS_REPORT_BUILD','PASS_LOCAL_UI')))
    for name in list(READINESS)+args.require_receipt:
        value=load(name)
        if name in expected_statuses:assert value['status']==expected_statuses[name],name
        else:assert type(value.get('status')) is str and value['status'].startswith(('PASS','VERIFIED','COMPLETE','ADMITTED')),name
        readiness.append(dict(path=name,status=value['status'],**pin(local(ROOT,name))))
    protocols=[verify_protocol('data/protocol-frozen-v1.json')]
    historical=load(HISTORICAL_SOURCE);assert historical['status']==HISTORICAL_STATUS
    provenance=dict(path=HISTORICAL_SOURCE,status=historical['status'],**pin(local(ROOT,HISTORICAL_SOURCE)),
        scope='Historical Source-only review, not a runtime or scientific PASS gate.')
    report_builder=dict(path=REPORT_BUILDER,**pin(local(ROOT,REPORT_BUILDER)))
    plan=load('publication/archive-plan-v1.json');assert plan['status']=='ARCHIVE_LINKS_PREPARED'
    for e in plan['pages'].values():assert wire(pin(local(ROOT,e['path'])))==wire({k:e[k] for k in ('bytes','sha256')}),'Re-run --prepare-links and final UI after page changes'
    owned(ROOT/'README-evidence-v1.txt',README)
    files=original_files();groups=partition(files);names=names_for(len(groups))
    assert names==plan['parts'],'Additional final files changed volume count; repeat --prepare-links and final UI before packaging'
    assignments={name:i for i,g in enumerate(groups,1) for name in g}
    entries=[dict(**e,part=assignments[e['path']]) for e in files]
    core=dict(schema='Shared-search-physical-evidence-inventory-v1',original_files=len(entries),
        original_bytes=sum(e['bytes'] for e in entries),files=entries,all_originals_physically_stored=True,
        parts=[dict(number=i,name=n) for i,n in enumerate(names,1)],protocols=protocols,readiness_receipts=readiness,
        report_builder=report_builder,historical_source_review=provenance,
        summary=dict(path='data/report-summary-v1.json',schema=summary['schema'],**pin(ROOT/'data/report-summary-v1.json')),
        exclusions=['package/ generated archive outputs','publication/ generated planning/deployment receipts; publication/*.py Sources are physically included'],generated_members=[INTERNAL])
    inventory=wire(core);assert len(zlib.compress(inventory,6))+65536<RESERVE
    package.mkdir();parts=[]
    for number,(name,group) in enumerate(zip(names,groups),1):
        path=package/name
        with zipfile.ZipFile(path,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
            for member in group:z.write(ROOT/member,member)
            z.writestr(INTERNAL,inventory)
        actual=pin(path);assert actual['bytes']<=MAX_PART and actual['bytes']<50*1024*1024
        parts.append(dict(number=number,name=name,**actual));print(json.dumps(dict(phase='VOLUME_WRITTEN',number=number,**actual)),flush=True)
    manifest={**core,'schema':'Shared-search-physical-multipart-evidence-v1','inventory_schema':core['schema'],'inventory_file':INTERNAL,'inventory_sha256':digest(inventory),'parts':parts}
    save(package/MANIFEST,manifest);checked=verify_archive(package,manifest);save(package/'archive-verification-v1.json',checked)
    for e in files:assert wire(pin(ROOT/e['path']))==wire({k:e[k] for k in ('bytes','sha256')}),e['path']
    remote_base=fresh_remote_base(args.base)
    env={k:v for k,v in os.environ.items() if not k.startswith('GIT_')};env.update(GIT_INDEX_FILE=str(pub/'index-v1'),GIT_NO_LAZY_FETCH='1',GIT_AUTHOR_NAME='Codex',GIT_AUTHOR_EMAIL='codex@openai.com',GIT_COMMITTER_NAME='Codex',GIT_COMMITTER_EMAIL='codex@openai.com')
    def git(*a,input=None):return subprocess.check_output(['git','-c','core.hooksPath=/dev/null','-c','gc.auto=0','--git-dir='+args.git_dir,*a],env=env,input=input).decode().strip()
    assert git('rev-parse','--is-bare-repository')=='true' and git('cat-file','-t',args.base)=='commit'
    old=subprocess.check_output(['git','--git-dir='+args.git_dir,'show',args.base+':'+PREFIX+OLD],env=env)
    assert old.count(b'</h1>')==1 and MAIN.encode() not in old
    backlink=('<p><a href="'+MAIN+'#reader">Continue: searching with shared prior facts through remote point markings, with complete finite catalogues, native proof readers and forward/SAT controls.</a></p>').encode('utf8')
    previous=pub/'previous-report-with-backlink-v1.html';previous.write_bytes(old.replace(b'</h1>',b'</h1>'+backlink,1))
    sources=[(p,PREFIX+p.relative_to(ROOT/'report').as_posix()) for p in sorted((ROOT/'report').rglob('*')) if p.is_file() and p.suffix in ('.html','.json','.gz')]
    sources += [(package/p['name'],PREFIX+p['name']) for p in parts]
    sources += [(package/MANIFEST,PREFIX+MANIFEST),(previous,PREFIX+OLD)]
    assert len(sources)==len({target for p,target in sources});git('read-tree',args.base);assets=[]
    for p,target in sources:
        if target!=PREFIX+OLD:assert not git('ls-tree','--full-name',args.base,'--',target),'New task path exists: '+target
        actual=pin(p);assert actual['bytes']<50*1024*1024;raw=p.read_bytes();assert digest(raw)==actual['sha256']
        oid=git('hash-object','-w','--stdin',input=raw);git('update-index','--add','--cacheinfo','100644',oid,target)
        assets.append(dict(local=p.relative_to(ROOT).as_posix(),path=target,**actual,git_blob=oid,url=BASE_URL+target))
    tree=git('write-tree','--missing-ok');commit=git('commit-tree',tree,'-p',args.base,'-m','Publish bounded shared-fact point proof search and control evidence')
    diff=git('diff-tree','--no-commit-id','--no-renames','--name-status','-r',args.base,commit);changes=[s.split('\t') for s in diff.splitlines()]
    assert {name for status,name in changes}=={a['path'] for a in assets} and all(status==('M' if name==PREFIX+OLD else 'A') for status,name in changes)
    prepared=dict(status='PREPARED_TASK_ASSETS_ONLY',base=args.base,tree=tree,commit=commit,assets=assets,diff=diff,
        archive_manifest='package/'+MANIFEST,archive_verification=checked,remote_base=remote_base,primary_checkout_staged=False,pushed=False)
    save(pub/'prepared-v1.json',prepared);print(json.dumps(dict(status=prepared['status'],commit=commit,parent=args.base,assets=len(assets),parts=len(parts),original_files=len(files))),flush=True)
if __name__=='__main__':main()
