"""Byte/process/ZIP publication gates; no scientific execution or Git calls."""
import hashlib
import json
from pathlib import Path,PurePosixPath
import zipfile

ROOT=Path(__file__).resolve().parents[1]
PREFIX='docs/research/gcts-rl-renewal/conditional-inventory/'
BASE_URL='https://liuyao12.github.io/geometric-tree-search/'
MANIFEST='resource-diagnostic-evidence-manifest-v1.json'
INTERNAL='ARCHIVE-file-manifest-v1.json'
PART_STEM='resource-diagnostic-evidence-v1-part-'
MAX_PART=44*1024*1024
FIRST_PHASE='seen-off-dsgb-alternate-l10-v1'
FIRST_PREFIX='history/first-attempt-v1/files/'
FIRST_MANIFEST='history/first-attempt-v1/reference-manifest-v1.json'
FIRST_MATERIALIZATION='review/first-attempt-materialization-v1.json'
FIRST_AUDIT='review/first-attempt-passive-audit-v1.json'
PHASES=('seen-off-dsgb-alternate-l6-v1','seen-off-dsgb-shared-l10-v1',
        'seen-off-dsgb-shared-l6-v1','seen-off-dsgb-shared-tail-l10-v1',
        'seen-off-dsgb-shared-tail-l6-v1','seen-off-dsgb-ungrounded-l10-v1',
        'seen-off-dsgb-ungrounded-l6-v1')
SUMMARY_SCHEMA='Resource-diagnostic-saved-summary-v1'
SUMMARY_STATUS='ADMITTED_DIAGNOSTIC_WITH_PRESERVED_FAILURE_AND_UNKNOWN'
AUDIT_SCHEMA='Resource-diagnostic-saved-audit-v1'
AUDIT_STATUS='PASS_SAVED_DATA_AUDIT'
REPORT_BUILDER='report/build_resource_report_v1.py'
ROOT_ADMISSION='review/root-publication-admission-v1.json'
READINESS_STATUSES={'review/saved-data-audit-v1.json':AUDIT_STATUS,
    'review/report-build-v1.json':'PASS_REPORT_BUILD',
    'review/local-ui-qualification-v1.json':'PASS_LOCAL_UI',ROOT_ADMISSION:'PASS',
    FIRST_MATERIALIZATION:'PHYSICALLY_MATERIALIZED_ALL_FIRST_ATTEMPT_ORIGINALS',
    FIRST_AUDIT:'PASS_PASSIVE_SAVED_PROOF_JOINS_WITH_FAILED_EXECUTION'}
READINESS=tuple(READINESS_STATUSES)
REVIEWED_DRIVER={'path':'source/run_resource_diagnostic_v2.py','bytes':21678,
    'sha256':'7d2afdd63637a036fcf34c3325b0800f0c688ec4283a165ae161288ba5e87b9a'}
DRIVER_PEER={'path':'review/continuation-peer-source-v2.md','bytes':3871,
    'sha256':'01d42b1dcee203aaf3a151ec56e5e635332d23e61c149565d3187a8a4f880695'}
PRIMARY_MASTER=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md')

def wire(v):return (json.dumps(v,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')
def digest(raw):return hashlib.sha256(raw).hexdigest()
def stream_pin(stream):
    h=hashlib.sha256();size=0
    for block in iter(lambda:stream.read(1048576),b''):h.update(block);size+=len(block)
    return dict(bytes=size,sha256=h.hexdigest())
def pin(path):
    with path.open('rb') as f:return stream_pin(f)
def relative_name(value):
    assert type(value) is str and value and '\\' not in value and '\x00' not in value
    p=PurePosixPath(value)
    assert not p.is_absolute() and all(v not in ('','.','..') for v in p.parts) and p.as_posix()==value
    return value
def local(root,value):
    p=root/relative_name(value);assert root.resolve() in p.resolve().parents
    return p
def load(name):return json.loads(local(ROOT,name).read_text())
def exact(name,expected):
    assert wire(pin(local(ROOT,name)))==wire({k:expected[k] for k in ('bytes','sha256')}),name

def verify_history():
    """Every original physically present; first failure never becomes native0."""
    history=load(FIRST_MANIFEST);materialized=load(FIRST_MATERIALIZATION);audit=load(FIRST_AUDIT)
    assert history['schema']=='CALv1-first-attempt-archive-reference-v1' and history['original_files']==51
    assert history['classification']=='FAILED_POSTCHECK_AFTER_SCIENCE' and history['execution_admitted'] is False
    assert type(history['native_exit_code']) is int and history['native_exit_code']==1 and history['phase_id']==FIRST_PHASE
    assert materialized['schema']=='First-attempt-materialization-v1' and materialized['status']==READINESS_STATUSES[FIRST_MATERIALIZATION]
    assert materialized['original_files']==51 and len(materialized['files'])==len(history['files'])==51
    original={e['path']:e for e in history['files']};assert len(original)==51
    targets={e['original']:e for e in materialized['files']};assert set(targets)==set(original)
    for name,e in original.items():
        relative_name(name);target=FIRST_PREFIX+name;row=targets[name]
        assert row['path']==target and all(row[k]==e[k] for k in ('bytes','sha256'));exact(target,e)
    paths=[p for p in local(ROOT,FIRST_PREFIX.rstrip('/')).rglob('*') if p.is_file()]
    assert all(not p.is_symlink() for p in local(ROOT,FIRST_PREFIX.rstrip('/')).rglob('*'))
    assert {p.relative_to(ROOT).as_posix() for p in paths}=={FIRST_PREFIX+n for n in original}
    protocol=load(FIRST_PREFIX+'data/protocol-frozen-v1.json')
    assert protocol['schema']=='Shared-resource-audit-off-protocol-v1' and protocol['status']=='FROZEN_BEFORE_SCIENTIFIC_IMPORTS'
    for e in protocol['files']:exact(FIRST_PREFIX+e['path'],e)
    start=load(FIRST_PREFIX+'data/'+FIRST_PHASE+'-started.json')
    inv=load(FIRST_PREFIX+'review/'+FIRST_PHASE+'-invocation.json')
    obs=load(FIRST_PREFIX+'review/'+FIRST_PHASE+'-observer.json')
    assert start['status']=='STARTED' and inv['status']=='ERROR' and obs['status']=='TERMINAL'
    assert start['phase']==inv['phase']==obs['phase']==FIRST_PHASE
    assert type(start['pid']) is int and start['pid']>0 and start['pid']==inv['pid']==obs['pid']
    assert start['protocol_sha256']==digest(wire(protocol))
    assert type(obs['native_exit_code']) is int and obs['native_exit_code']==1 and obs['guard_reason'] is None
    assert inv['frozen_postcheck']==obs['frozen_postcheck']=='FAILED'
    assert inv['postcheck_error']==obs['postcheck_error']=='tuple indices must be integers or slices, not str'
    assert inv['scientific_status']=='VERIFIED_POSITIVE'
    exact(FIRST_PREFIX+obs['log']['path'],obs['log'])
    assert audit['schema']=='Shared-resource-first-attempt-passive-audit-v1' and audit['status']==READINESS_STATUSES[FIRST_AUDIT]
    assert audit['execution']['status']=='FAILED_POSTCHECK_AFTER_SCIENCE' and audit['execution']['execution_admitted'] is False
    assert audit['execution']['native_exit_code']==1
    assert audit['logical_evidence']['status']=='VERIFIED_SAVED_POSITIVE_ASSOCIATION'
    assert audit['logical_evidence']['raw_engine_status']=='SAT'
    return dict(status='ALL_51_ORIGINALS_PHYSICALLY_VERIFIED_WITH_FAILED_PROCESS_PRESERVED',
        manifest=dict(path=FIRST_MANIFEST,**pin(local(ROOT,FIRST_MANIFEST))),
        materialization=dict(path=FIRST_MATERIALIZATION,**pin(local(ROOT,FIRST_MATERIALIZATION))),
        passive_audit=dict(path=FIRST_AUDIT,**pin(local(ROOT,FIRST_AUDIT))),prefix=FIRST_PREFIX,original_files=51,
        phase=FIRST_PHASE,native_exit_code=1,execution_admitted=False,classification='FAILED_POSTCHECK_AFTER_SCIENCE',
        files=[dict(original_path=name,path=FIRST_PREFIX+name,**{k:original[name][k] for k in ('bytes','sha256')}) for name in sorted(original)])

def verify_protocol(relative,context_root=''):
    """Exact frozen33/runtime/master; seven clean processes plus failed history."""
    path=local(ROOT,relative);value=load(relative)
    assert relative=='data/protocol-frozen-v1.json' and context_root==''
    assert value['schema']=='Shared-resource-audit-off-continuation-protocol-v2' and value['status']=='FROZEN_BEFORE_SCIENTIFIC_IMPORTS'
    assert path.read_bytes()==wire(value)
    paths=[]
    for folder in ('source','reference','input','plan'):
        for p in (ROOT/folder).rglob('*'):
            assert not p.is_symlink()
            if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc':paths.append(p)
    paths.extend(local(ROOT,p) for p in ('review/input-dependency-snapshot-v1.json',
        'review/CALv1-driver-preserved-v1.py','review/CALv1-input-declarations-preserved-v1.json',FIRST_MANIFEST))
    current=[dict(path=p.relative_to(ROOT).as_posix(),**pin(p)) for p in sorted(paths)]
    assert len(current)==33 and wire(current)==wire(value['files']),'Exact frozen scientific file set changed'
    indexed={e['path']:e for e in current};assert len(indexed)==len(current)
    assert wire(indexed[REVIEWED_DRIVER['path']])==wire(REVIEWED_DRIVER)
    exact(DRIVER_PEER['path'],DRIVER_PEER)
    preflight=load('review/data-only-preflight-v1.json')
    assert preflight['status']=='PASS_STATIC_TUPLE_RETURN_ACCESS_AND_SEVEN_CASE_CONTINUATION'
    assert preflight['source']==REVIEWED_DRIVER
    executable=value['runtime']['executable'];assert Path(executable['path']).is_absolute()
    assert wire(pin(Path(executable['path'])))==wire({k:executable[k] for k in ('bytes','sha256')})
    assert type(value['runtime']['isolated']) is int and type(value['runtime']['no_site']) is int
    assert value['runtime']['isolated']==value['runtime']['no_site']==1 and value['runtime']['dont_write_bytecode'] is True
    master=indexed['reference/basic-tiling-algorithm.md']
    assert wire(pin(PRIMARY_MASTER))==wire({k:master[k] for k in ('bytes','sha256')})
    assert value['phase_ids']==list(PHASES)
    plan=load('plan/input-declarations-v2.json')
    assert [c['id'] for c in plan['cases']]==list(PHASES)
    cohort={c['id'] for c in plan['original_cohort']}
    assert len(cohort)==8 and set(PHASES)==cohort-{FIRST_PHASE}
    assert plan['continuation_history']['excluded_phase_id']==FIRST_PHASE and plan['continuation_history']['no_rerun'] is True
    phases=[]
    for phase in PHASES:
        started_name='data/'+phase+'-started.json';started=load(started_name)
        assert started['phase']==phase and started['status']=='STARTED'
        assert type(started['pid']) is int and started['pid']>0 and started['protocol_sha256']==digest(wire(value))
        refs={'started':dict(path=started_name,**pin(local(ROOT,started_name)))}
        for key,suffix in (('observer','-observer.json'),('invocation','-invocation.json')):
            name='review/'+phase+suffix;receipt=load(name)
            assert receipt['phase']==phase and type(receipt['pid']) is int and receipt['pid']==started['pid']
            assert receipt['frozen_postcheck']==value['status'] and receipt['postcheck_error'] is None
            if key=='observer':
                assert receipt['status']=='TERMINAL' and type(receipt['native_exit_code']) is int and receipt['native_exit_code']==0
                assert receipt['guard_reason'] is receipt['observer_error'] is receipt['reap_error'] is None
                assert receipt['log']['path']=='review/'+phase+'-native.log';exact(receipt['log']['path'],receipt['log']);refs['log']=receipt['log']
            else:assert receipt['status']=='COMPLETE' and receipt['error_type'] is None
            refs[key]=dict(path=name,**pin(local(ROOT,name)))
        result_name='data/'+phase+'-result.json';result=load(result_name)
        assert result['id']==phase and load('review/'+phase+'-invocation.json')['scientific_status']==result['status']
        refs['result']=dict(path=result_name,**pin(local(ROOT,result_name)))
        phases.append(dict(phase=phase,execution_admitted=True,native_exit_code=0,receipts=refs))
    return dict(path=relative,context_root=context_root,schema=value['schema'],phases=phases,
        source_pin_count=len(current),reviewed_driver=REVIEWED_DRIVER,driver_peer=DRIVER_PEER,
        first_attempt=verify_history(),**pin(path))

def verify_summary(summary):
    assert summary['schema']==SUMMARY_SCHEMA and summary['status']==SUMMARY_STATUS
    rows=summary['records'];assert len(rows)==8 and {r['id'] for r in rows}==set(PHASES)|{FIRST_PHASE}
    first=[r for r in rows if r['id']==FIRST_PHASE];assert len(first)==1
    for row in rows:
        process=row['process'];assert row['method']=='point' and process['phase']==row['id']
        assert row['resources']['full_graph_conformance']=='NOT_MEASURED'
        if row['id']==FIRST_PHASE:
            assert row['kind']=='FIRST_ATTEMPT' and process['status']=='FAILED_POSTCHECK_AFTER_SCIENCE'
            assert process['native_exit_code']==1 and process['execution_admitted'] is False
            assert row['status']=='SAT' and row['admission']['status']=='VERIFIED_POSITIVE' and len(row['proof_reader'])==5
        else:
            assert row['kind']=='CONTINUATION' and process['status']=='COMPLETE_NATIVE_EXECUTION'
            assert process['native_exit_code']==0 and process['execution_admitted'] is True
        if row['status']=='UNSAT':assert row['admission']['absence']=='UNKNOWN' and row['admission']['status']=='UNKNOWN'
        if row['status']=='UNKNOWN':assert row['admission']['status']=='UNKNOWN' and not row['proof_reader']
    assert summary['coverage']['execution_admitted']==7 and summary['coverage']['preserved_failed_processes']==1
    assert summary['coverage']['independently_verified_absence']==summary['coverage']['full_graph_conformance_records']==0
    return True
def inventory_from_manifest(manifest):
    assert manifest['schema']=='Resource-diagnostic-physical-multipart-evidence-v1' and manifest['inventory_file']==INTERNAL
    core={k:v for k,v in manifest.items() if k not in ('inventory_sha256','inventory_schema','inventory_file')}
    core['schema']=manifest['inventory_schema']
    core['parts']=[dict(number=p['number'],name=p['name']) for p in manifest['parts']]
    assert core['schema']=='Resource-diagnostic-physical-evidence-inventory-v1' and digest(wire(core))==manifest['inventory_sha256']
    return core
def verify_archive(folder,manifest):
    core=inventory_from_manifest(manifest);entries=manifest['files'];by_path={e['path']:e for e in entries}
    assert len(by_path)==len(entries)==manifest['original_files'] and manifest['all_originals_physically_stored'] is True
    assert sum(e['bytes'] for e in entries)==manifest['original_bytes']
    first=manifest['preserved_first_attempt_originals']
    assert first['original_files']==len(first['files'])==51 and first['native_exit_code']==1 and first['execution_admitted'] is False
    assert first['classification']=='FAILED_POSTCHECK_AFTER_SCIENCE'
    assert len({e['original_path'] for e in first['files']})==51
    for e in first['files']:
        assert e['path']==FIRST_PREFIX+relative_name(e['original_path']) and e['path'] in by_path
        assert all(e[k]==by_path[e['path']][k] for k in ('bytes','sha256'))
    for e in entries:
        relative_name(e['path']);assert type(e['part']) is int and 1<=e['part']<=len(manifest['parts'])
    parts=[];verified=set()
    for number,part in enumerate(manifest['parts'],1):
        assert part['number']==number and part['name']==PART_STEM+'%03d.zip'%number
        archive=local(folder,part['name']);actual=pin(archive)
        assert wire(actual)==wire({k:part[k] for k in ('bytes','sha256')}) and actual['bytes']<=MAX_PART and actual['bytes']<50*1024*1024
        expected={e['path'] for e in entries if e['part']==number}
        with zipfile.ZipFile(archive) as z:
            assert len(z.namelist())==len(set(z.namelist())) and set(z.namelist())==expected|{INTERNAL}
            assert z.read(INTERNAL)==wire(core) and z.testzip() is None
            for name in sorted(expected):
                e=by_path[name];assert name not in verified and z.getinfo(name).file_size==e['bytes']
                with z.open(name) as stream:p=stream_pin(stream)
                assert wire(p)==wire({k:e[k] for k in ('bytes','sha256')});verified.add(name)
        parts.append(dict(number=number,name=part['name'],**actual,CRC='PASS'))
    assert verified==set(by_path)
    return dict(status='PASS',original_files=len(entries),all_original_files_physically_stored=True,
        all_original_paths_byte_verified=True,all_CRC_verified=True,parts=parts)
