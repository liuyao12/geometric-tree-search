"""Passive resource diagnostic of saved audit-off point-search attempts.

No scientific Source imports, model construction, solving, native checking,
certificate replay or proof transformation. Only saved-data selection and
literal point-row display metadata are produced. No new full per-run graph assurance is implied.
"""
import argparse
import copy
import gzip
import hashlib
import html
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parents[1]
RESULTS = 'resource-diagnostic-results-v1.json.gz'


def wire(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       separators=(',', ':'), allow_nan=False)+'\n').encode('ascii')


def pin(path):
    h, n = hashlib.sha256(), 0
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1048576), b''):
            h.update(block)
            n += len(block)
    return dict(bytes=n, sha256=h.hexdigest())


def is_ref(value):
    return isinstance(value, dict) and {'path', 'bytes', 'sha256'} <= set(value)


def references(value):
    if is_ref(value):
        yield value
    elif isinstance(value, dict):
        for child in value.values():
            yield from references(child)
    elif isinstance(value, list):
        for child in value:
            yield from references(child)


def path_for(root, ref):
    path = (root/ref['path']).resolve()
    if not path.is_relative_to(root) or pin(path) != {key: ref[key] for key in ('bytes', 'sha256')}:
        raise ValueError('Saved artifact byte binding: '+str(ref['path']))
    return path


def exclusive(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(raw)


def mark_display(record):
    """Read own/remote port identities from the actual selected t/m rows."""
    rows = record.get('selected_rows') or []
    if not rows:
        return dict(status='NO_POINT_CERTIFICATE', slots=[],
            scope='No selected point certificate is supplied for this method/outcome.')
    if record['method'] not in ('point', 'sat') or not record.get('proof_reader'):
        raise ValueError('Selected rows require an independently admitted point/SAT positive')
    if set(record.get('selected') or []) != {row['id'] for row in rows}:
        raise ValueError('Selected rows/identities differ')
    decoded_slots = {row['slot']: row for row in (record.get('slot_rows') or [])}
    slots = []
    for row in rows:
        action = json.loads(row['id'])
        if not isinstance(action, list) or len(action) != 6 or action[0] != 'DAG-candidate-v1':
            raise ValueError('Unsupported saved selected-CID display profile')
        _, scope, index, kind, definition, refs = action
        if type(index) is not int or index < 0:
            raise ValueError('Saved slot index')
        own, requests = {}, []
        for point, value in row['m']:
            port = json.loads(point)
            if not isinstance(port, list) or len(port) != 3 or port[1] != scope or type(port[2]) is not int:
                raise ValueError('Saved mark port display profile')
            if port[0] not in ('DAG-slot-active-v1', 'DAG-slot-formula-v1'):
                raise ValueError('Unknown saved mark layer')
            channel = 'active' if port[0] == 'DAG-slot-active-v1' else 'formula'
            if port[2] == index:
                own[channel] = dict(point=point, value=value)
            else:
                requests.append(dict(channel=channel, owner_slot=port[2], point=point, value=value))
        if set(own) != {'active', 'formula'} or len(row['t']) != 1:
            raise ValueError('Saved owner ports/positive support')
        center, units = row['t'][0]
        if wire(json.loads(center)) != wire(['DAG-slot-center-v1', scope, index]) or type(units) is not int or units != 1:
            raise ValueError('Saved center display binding')
        mapped = decoded_slots.get(index)
        if mapped is None or mapped['cid'] != row['id'] or str(mapped['active']) != own['active']['value'] or str(mapped['formula_id']) != own['formula']['value']:
            raise ValueError('Saved row/decoded slot display mismatch')
        slots.append(dict(slot=index, kind=kind, definition=definition, refs=refs,
            line_index=mapped['native_line_index_or_null'], active=own['active'], formula=own['formula'],
            center=dict(point=center, units=units), requests=requests, exact=row))
    slots.sort(key=lambda item: item['slot'])
    if len({item['slot'] for item in slots}) != len(slots):
        raise ValueError('Duplicate displayed slot')
    by_slot = {item['slot']: item for item in slots}
    for item in slots:
        for request in item['requests']:
            owner = by_slot.get(request['owner_slot'])
            if owner is None or owner[request['channel']]['point'] != request['point'] or owner[request['channel']]['value'] != request['value']:
                raise ValueError('Saved receptor/owner display mismatch')
    return dict(status='ACTUAL_SELECTED_POINT_ROWS', slots=slots,
        scope='Colored own and requested marks are taken literally from the saved selected rows. This display does not independently validate a model, proof, search trace or certificate.')


CSS = r'''
:root{--ink:#233840;--muted:#607478;--line:#dbe5e2;--paper:#f6f8f6;--teal:#267b6b;--blue:#397ea8;--gold:#a87733;--red:#a14f51}*{box-sizing:border-box}body{margin:0;background:var(--paper);color:var(--ink);font:16px/1.65 system-ui,sans-serif}a{color:#236c86;text-underline-offset:3px}header{background:#173e42;color:white;padding:46px max(24px,calc((100vw - 1220px)/2)) 32px}header a{color:#c4e6dd}.eyebrow{font-size:12px;letter-spacing:.16em;text-transform:uppercase;color:#acd5cb}h1{font:clamp(32px,5vw,52px)/1.12 Georgia,serif;max-width:900px;margin:15px 0}h2{font:30px/1.2 Georgia,serif;margin:0 0 18px}h3{font:22px/1.25 Georgia,serif;margin:22px 0 10px}p{margin:10px 0}.lede{font-size:18px;max-width:900px;color:#d9e9e3}nav{display:flex;gap:20px;flex-wrap:wrap;font-size:14px;margin-top:22px}main{max-width:1270px;margin:auto;padding:30px 24px 65px}section{background:white;border:1px solid var(--line);border-radius:13px;padding:26px;margin-bottom:24px}.note{font-size:14px;color:var(--muted)}.callout{padding:13px 17px;border-left:4px solid var(--teal);background:#edf5ef}.warning{border-color:var(--gold);background:#fbf4e8}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:13px}.metric{padding:15px;border:1px solid var(--line);border-radius:8px}.metric strong{font:30px Georgia,serif;display:block}.metric span{font-size:13px;color:var(--muted)}.scroll,.formula-scroll{overflow-x:auto}.formula-scroll{max-width:100%;padding:3px 0}table{width:100%;border-collapse:collapse;font-size:14px}td,th{overflow-wrap:anywhere;padding:10px 9px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top}th{background:#f3f7f4;color:#44616a}.badge{display:inline-block;background:#eaf0ed;border-radius:5px;padding:2px 7px;font:12px/1.5 ui-monospace,monospace;overflow-wrap:anywhere}.badge.failed{background:#f8e3e2;color:#953c44}.badge.ok{background:#deeee3;color:#2b6547}.badge.unknown{background:#f8ead2;color:#855e22}.finder{display:inline-block;border:1px solid #c6d8d3;border-radius:6px;padding:5px 10px;font-size:13px;font-weight:600;color:#315f65}.proof-table{table-layout:fixed}.proof-table th:nth-child(1){width:5%}.proof-table th:nth-child(2){width:43%}.proof-table th:nth-child(3){width:31%}.proof-table th:nth-child(4){width:21%}.proof-table td:nth-child(2){overflow:hidden}.proof-table tr.chosen{background:#edf5ef}.proof-table button{padding:3px 6px}button,select{font:inherit;color:var(--ink);background:#fff;border:1px solid #b7cbc5;border-radius:7px;padding:8px 12px}button{cursor:pointer}button:hover,button.active{background:#edf5ef;border-color:#498a78}label{display:inline-flex;flex-direction:column;gap:5px;margin:0 12px 14px 0;color:var(--muted);font-size:13px}.check-label{flex-direction:row;align-items:center;gap:8px}code,pre{font:12px/1.5 ui-monospace,monospace}code{overflow-wrap:anywhere}pre{padding:14px;background:#f3f6f4;border-radius:7px;white-space:pre-wrap;max-height:430px;overflow:auto}.two>div{min-width:0}.two{display:grid;grid-template-columns:1.15fr 1fr;gap:24px}.diagram{min-width:560px;width:100%;display:block}.legend{display:flex;gap:17px;flex-wrap:wrap;font-size:12px;margin-bottom:15px}.dot{width:11px;height:11px;border-radius:50%;display:inline-block;margin-right:5px}.links{display:flex;gap:15px;flex-wrap:wrap;font-size:14px}.quick{display:flex;gap:8px;flex-wrap:wrap;margin:15px 0}.quick button{font-size:12px}.mini{font-size:12px;color:var(--muted)}.error{color:var(--red)}details{margin:15px 0}summary{cursor:pointer;color:#356971}footer{font-size:13px;color:var(--muted)}@media(max-width:800px){main{padding:15px 10px}section{padding:18px 12px}.two{grid-template-columns:1fr}.proof-table{min-width:800px}header{padding:34px 20px 25px}}'''

BODY = r'''
<header><div class="eyebrow">GCTS research · resource diagnostic</div><h1>Separate a checked proof<br>from how its process ended</h1><p class="lede">The same eight seen proof problems, with changed resource settings and the audit callback disabled. Read the actual point-search certificates, resource observations and retained process failure.</p><nav><a href="#assessment">Diagnostic comparison</a><a href="#reader">Proof reader</a><a href="#markings">Actual point markings</a><a href="#costs">Costs and scope</a><a href="resource-diagnostic-evidence-v1.html">Evidence</a></nav></header>
<main><p id="loading" class="note">Loading admitted diagnostic evidence…</p>
<section id="assessment"><h2>What is admitted, and at which level</h2><div id="assessment-text"></div><div id="metrics" class="grid"></div><p class="callout warning">The first attempt completed scientific output and a native-checked proof, then failed its process postcheck. Its native exit remains one and execution admission remains false. It was not rerun; the corrected continuation covers only the seven remaining inputs.</p><p>The callback setting and multiple caps change together. This is a diagnostic on already seen inputs, with no isolated audit-causality, new-theorem, held-out, RL or search-speed claim. The original <a href="shared-search-v1.html#assessment">conventional forward control already proved the same positive examples</a>. This diagnostic closes a point-search gap; it establishes no superiority. Five certificates at repeated bounds cover three positive target families, not five distinct new theorems. New raw UNSAT outcomes remain UNKNOWN for absence without full independent per-run graph assurance.</p><div id="comparison" class="scroll"></div></section>
<section id="reader"><h2>Inspect a saved point-search attempt</h2><label>Case and origin<select id="case"></select></label><label class="check-label"><input type="checkbox" id="short-labels" checked>Use short proposition labels</label><div id="attempt"></div><div id="theory"></div><details><summary>Bijective labels and unaltered selected formula</summary><div id="symbol-legend"></div><pre id="literal-formula"></pre><p class="note">Short labels affect display only. Native symbols and the exact formula AST are retained; untick the box for the saved full-name formulas and English.</p></details><div id="proof-state"></div><div id="proof" class="scroll"></div><details><summary>Exact attempt artifacts and admission fields</summary><div id="record-downloads" class="links"></div><pre id="record-admission"></pre></details></section>
<section id="markings"><h2>Literal active and formula receptors</h2><p>Each owner contributes \(t=1\) at its slot. Active and formula marks can be read at distant earlier slots; PAD explicitly assigns zero. Several consumers may read the same owner without selecting it twice.</p><div id="mark-status"></div><div class="legend"><span><i class="dot" style="background:#258375"></i>Active layer</span><span><i class="dot" style="background:#437faf"></i>Formula layer, literal ID colors</span><span><i class="dot" style="background:#aab5b6"></i>PAD</span></div><label class="check-label"><input type="checkbox" id="all-links" checked>Show every selected-row receptor connection</label><div class="two"><div id="slot-diagram" class="scroll"></div><div><div id="selected-slot"></div><h3>Actual shared references</h3><div id="sharing"></div><details><summary>Formula-ID color legend</summary><div id="fid-legend"></div></details><details><summary>Exact selected row</summary><pre id="exact-row"></pre></details></div></div><details><summary>Saved model and seed metadata</summary><pre id="model-metadata"></pre></details><p class="note">This is the same semantic slot/mark adaptation, not literal uniform-Wang search. Marks are problem-defining, not learned. The picture uses actual admitted selected rows only; it is not a full search-graph certificate. Slot indices are zero-based; human proof lines start at one.</p></section>
<section id="costs"><h2>Recorded resource use and limitations</h2><h3>Selected attempt</h3><div id="selected-costs" class="scroll"></div><details><summary>Exact cost/resource fields</summary><pre id="exact-costs"></pre></details><h3>Comparison to the old numeric ceilings</h3><div id="cap-comparison" class="scroll"></div><p class="note">Only comparable saved numeric fields are tested. Falling below an old numeric ceiling does not establish that the run was made under that old configuration; no counterfactual rerun was performed. The callback, caps and reporting path differ. The old callback charged full snapshots and their serialization to the work counter; switching it off changes the composition of charged work. These are not equal-work or counterfactual runs.</p><h3>Observed accounting</h3><div id="diagnostic-costs"></div><div id="limitations"></div><details><summary>Saved-data audit and provenance</summary><pre id="provenance"></pre></details><p class="links"><a href="shared-search-v1.html#reader">Original full-audit pilot</a><a href="resource-diagnostic-evidence-v1.html">Evidence index</a><a download href="resource-diagnostic-results-v1.json.gz">Reader projection</a></p><!-- RESOURCE_DIAGNOSTIC_ARCHIVE_LINK --></section><footer>Logical proof validity, raw engine status, process completion and whole-graph assurance are separate fields. No science code executes in this reader.</footer></main>
'''

SCRIPT = r'''
const $=id=>document.getElementById(id),esc=x=>String(x??'Unavailable').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const text=x=>x===null||x===undefined?'Unavailable':typeof x==='object'?JSON.stringify(x):String(x),num=x=>typeof x==='number'?x.toLocaleString('en-US',{maximumFractionDigits:6}):text(x),found=r=>r.status==='SAT'||r.status==='DERIVABLE',absent=r=>r.status==='UNSAT'||r.status==='NOT_DERIVABLE_WITHIN_BOUND';
const names={point:'Point engine with audit callback off',forward:'Conventional forward control',sat:'Reference SAT / DPLL control'},badge=x=>`<span class="badge ${x==='SAT'||x==='DERIVABLE'||String(x).includes('VERIFIED')?'ok':String(x).startsWith('UNKNOWN')?'unknown':String(x).startsWith('FAILED')?'failed':''}">${esc(text(x))}</span>`,table=(heads,rows,cls='')=>`<table class="${cls}"><thead><tr>${heads.map(h=>`<th>${esc(h)}</th>`).join('')}</tr></thead><tbody>${rows.join('')}</tbody></table>`;
let data,recordIndex=0,lineIndex=0,slotIndex=null,aliases={},mathQueue=Promise.resolve();
function typeset(node=document.body){mathQueue=mathQueue.catch(()=>{}).then(async()=>{if(window.MathJax?.startup?.promise)await MathJax.startup.promise;if(window.MathJax?.typesetPromise)await MathJax.typesetPromise([node]);});mathQueue.catch(e=>console.error(e));}window.addEventListener('load',()=>typeset(document.body));
const current=()=>data.records[recordIndex],readers=()=>current().proof_reader??[],edges=()=>current().proof_dag?.edges??[],fidColor=id=>id==='0'?'#9caeb1':`hsl(${(Number(id)*67+175)%360} 42% 43%)`;
function aliasesFor(r){let ns=Object.keys(r.case?.statement?.theory?.predicates??{}).sort(),last=ns.map(n=>n.match(/([A-Za-z])$/)?.[1]?.toUpperCase()??null),unique=last.every(Boolean)&&new Set(last).size===ns.length;return Object.fromEntries(ns.map((n,i)=>[n,unique?last[i]:i<26?String.fromCharCode(65+i):'P'+(i+1)]));}
function shortLatex(a){if(!Array.isArray(a))return null;if(a[0]==='pred'&&Array.isArray(a[2])&&!a[2].length&&aliases[a[1]])return '\\mathsf{'+aliases[a[1]]+'}';if(a[0]==='imp'){let l=shortLatex(a[1]),r=shortLatex(a[2]);if(l!==null&&r!==null)return '\\left('+l+'\\Rightarrow '+r+'\\right)';}return null;}
function formula(r){let latex=$('short-labels').checked?shortLatex(r?.formula):null;return `\\(${esc(latex??r?.formula_latex??'\\text{Unavailable}')}\\)`;}
function english(r){let t=text(r?.english);if($('short-labels').checked)for(let n of Object.keys(aliases).sort((a,b)=>b.length-a.length))t=t.split(n).join(aliases[n]);return t;}
function renderSymbols(){let r=current();aliases=aliasesFor(r);$('symbol-legend').innerHTML=table(['Display label','Unchanged native proposition'],Object.entries(aliases).map(([n,a])=>`<tr><td>\\(\\mathsf{${esc(a)}}\\)</td><td><code>${esc(n)}</code></td></tr>`));renderLiteral();typeset($('symbol-legend'));}
function renderLiteral(){let r=readers()[lineIndex];$('literal-formula').textContent=JSON.stringify(r?{human_line:lineIndex+1,formula:r.formula,rule:r.rule,dependencies:r.dependencies,slot:r.slot,formula_id:r.formula_id,original_english:r.english,proof_source:current().proof_ref}: {scope:'No admitted proof line for this outcome.'},null,2);}
function renderTheory(){let th=current().theory_reader;$('theory').innerHTML=th?table(['Original assumption','Formula','English'],(th.hypotheses??[]).map(h=>`<tr><td><code>${esc(h.name)}</code></td><td><div class="formula-scroll">${formula(h)}</div></td><td>${esc(english(h))}</td></tr>`))+`<h3>Declared target</h3><div class="formula-scroll">${formula(th.goal??th.conclusion)}</div><p>${esc(english(th.goal??th.conclusion))}</p>`:'<p class="note">No human statement projection was supplied; inspect the exact declaration download.</p>';typeset($('theory'));}

function chooseLine(i){lineIndex=i;renderLiteral();let slot=current().mark_display.slots?.find(s=>s.line_index===i);slotIndex=slot?.slot??null;renderProof();renderMarks();}
function renderProof(){let rs=readers();$('proof').innerHTML=rs.length?table(['Line','Formula','English','Rule / references'],rs.map((r,i)=>{let dependencies=edges().filter(e=>e.conclusion===i).map(e=>e.premise+1);return `<tr class="${i===lineIndex?'chosen':''}"><td><button data-line="${i}">${i+1}</button></td><td><div class="formula-scroll">${formula(r)}</div></td><td>${esc(english(r))}</td><td><code>${esc(r.rule)}</code><br>${dependencies.length?'Uses lines '+[...new Set(dependencies)].join(', '):'No earlier-line reference'}${r.slot!==null&&r.slot!==undefined?'<p class="mini">Certificate slot '+esc(r.slot)+'</p>':''}</td></tr>`;}),'proof-table'):'';document.querySelectorAll('[data-line]').forEach(b=>b.onclick=()=>chooseLine(Number(b.dataset.line)));typeset($('proof'));}
function renderMarks(){let r=current(),display=r.mark_display,slots=display.slots??[],has=display.status==='ACTUAL_SELECTED_POINT_ROWS';$('mark-status').innerHTML=has?`<p class="callout">Actual selected point certificate found by <b>${esc(names[r.method])}</b>. Select a slot or proof line to inspect its two marking layers and earlier-slot requests.</p>`:`<p class="callout warning">${r.method==='forward'&&readers().length?'The forward control supplies a native proof without an anchored point-placement certificate. Its shared logical references appear below; no slot tiling is invented.':'No complete selected point certificate is admitted for this attempt. No marking diagram is borrowed from another method.'}</p>`;$('model-metadata').textContent=JSON.stringify(r.model_metadata??null,null,2);$('slot-diagram').innerHTML='';$('selected-slot').innerHTML='';$('exact-row').textContent='';if(has){if(!slots.some(s=>s.slot===slotIndex))slotIndex=slots.find(s=>s.active.value==='1')?.slot??slots[0].slot;let height=slots.length*83+45,y=s=>35+slots.findIndex(x=>x.slot===s)*83;let p=[`<svg class="diagram" viewBox="0 0 720 ${height}" role="img" aria-label="Actual selected owner slots and long-range active/formula requests"><defs><marker id="mark-arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="5" markerHeight="5" orient="auto"><path d="M0 0L10 5L0 10Z" fill="#647d79"/></marker></defs>`];let shown=$('all-links').checked?slots:slots.filter(s=>s.slot===slotIndex);shown.forEach(s=>s.requests.forEach((q,i)=>{let source=y(s.slot)+(q.channel==='active'?21:45),target=y(q.owner_slot)+(q.channel==='active'?21:45),x=450+(s.slot%3)*45+(i%2)*16;p.push(`<path d="M385 ${source} C${x} ${source},${x} ${target},385 ${target}" stroke="${q.channel==='active'?'#258375':fidColor(q.value)}" stroke-width="${s.slot===slotIndex?2.5:1.1}" fill="none" ${q.channel==='active'?'stroke-dasharray="5 3"':''} marker-end="url(#mark-arrow)"><title>${esc('Slot '+s.slot+' requests '+q.channel+' '+q.value+' from slot '+q.owner_slot)}</title></path>`);}));slots.forEach(s=>{let yy=y(s.slot),active=s.active.value==='1';p.push(`<g data-slot="${s.slot}" role="button" tabindex="0"><rect x="24" y="${yy}" width="362" height="66" rx="7" fill="${s.slot===slotIndex?'#e7f3ec':'#f8faf8'}" stroke="${s.slot===slotIndex?'#2a7b69':'#c8d8d1'}" stroke-width="${s.slot===slotIndex?2:1}"/><rect x="170" y="${yy+9}" width="205" height="22" rx="4" fill="${active?'#258375':'#9caeb1'}"/><rect x="170" y="${yy+35}" width="205" height="22" rx="4" fill="${fidColor(s.formula.value)}"/><text x="36" y="${yy+20}" font-size="12" fill="#28444b">Slot ${s.slot} · ${esc(s.kind)}</text><text x="36" y="${yy+42}" font-size="11" fill="#5b7077">${s.line_index===null?'No native line':'Proof line '+(s.line_index+1)}</text><text x="36" y="${yy+57}" font-size="10" fill="#5b7077">One center unit</text><text x="182" y="${yy+24}" font-size="11" fill="white">active port: ${esc(s.active.value)}</text><text x="182" y="${yy+50}" font-size="11" fill="white">formula ID: ${esc(s.formula.value)}</text></g>`);});p.push('</svg>');$('slot-diagram').innerHTML=p.join('');document.querySelectorAll('[data-slot]').forEach(b=>b.onclick=()=>{slotIndex=Number(b.dataset.slot);let s=slots.find(s=>s.slot===slotIndex);lineIndex=s.line_index;renderProof();renderMarks();});let selected=slots.find(s=>s.slot===slotIndex),reader=selected.line_index===null?null:readers()[selected.line_index];$('selected-slot').innerHTML=`<h3>Slot ${selected.slot} · ${esc(selected.kind)}</h3><p>Own center capacity: \\(t=1\\). Active value <code>${esc(selected.active.value)}</code>; formula ID <code>${esc(selected.formula.value)}</code>.</p>`+(reader?`<div class="formula-scroll">${formula(reader)}</div><p>${esc(english(reader))}</p>`:'<p class="note">Explicit inactive PAD, with both marking values zero.</p>')+(selected.requests.length?table(['Layer','Earlier owner','Literal value'],selected.requests.map(q=>`<tr><td>${esc(q.channel)}</td><td>Slot ${q.owner_slot}</td><td><code>${esc(q.value)}</code></td></tr>`)):'<p class="note">This owner requests no earlier fact.</p>');$('exact-row').textContent=JSON.stringify(selected.exact,null,2);}
let consumers={};edges().forEach(e=>(consumers[e.premise]??=new Set()).add(e.conclusion));let shared=Object.entries(consumers).filter(([_,v])=>v.size>1);$('sharing').innerHTML=shared.length?table(['One earlier fact','Consumers'],shared.map(([i,js])=>`<tr><td><button data-share="${i}">Proof line ${Number(i)+1}</button><div class="formula-scroll">${formula(readers()[Number(i)])}</div></td><td>${[...js].sort((a,b)=>a-b).map(j=>j+1).join(', ')}</td></tr>`)):`<p class="note">${readers().length?'This certificate contains no fact referenced by multiple later proof lines.':'No admitted proof DAG is available.'}</p>`;document.querySelectorAll('[data-share]').forEach(b=>b.onclick=()=>chooseLine(Number(b.dataset.share)));let fs=new Map();readers().forEach(x=>{if(x.formula_id!==null&&x.formula_id!==undefined)fs.set(x.formula_id,x);});$('fid-legend').innerHTML=fs.size?table(['Literal formula ID','Displayed formula'],[...fs].sort((a,b)=>a[0]-b[0]).map(([id,x])=>`<tr><td><i class="dot" style="background:${fidColor(String(id))}"></i><code>${esc(id)}</code></td><td><div class="formula-scroll">${formula(x)}</div></td></tr>`)):'<p class="note">No selected proof formulas for this outcome.</p>';renderLiteral();typeset($('markings'));}
function flatten(value,prefix='',out=[]){if(value!==null&&typeof value==='object'&&!Array.isArray(value)){for(let [key,v] of Object.entries(value))flatten(v,prefix?prefix+'.'+key:key,out);}else out.push([prefix,value]);return out;}
function renderCosts(){let r=current();$('selected-costs').innerHTML=table(['Recorded field','Value'],flatten(r.costs??{}).map(([key,v])=>`<tr><td>${esc(key.replaceAll('_',' '))}</td><td>${esc(typeof v==='number'?num(v):text(v))}</td></tr>`));$('exact-costs').textContent=JSON.stringify({costs:r.costs,resources:r.resources},null,2);}

function rawStatus(r){return r.raw_engine_status??r.status;}
function logicalStatus(r){if(rawStatus(r)==='UNSAT')return 'UNKNOWN_ABSENCE';if(readersFor(r).length)return 'VERIFIED_NATIVE_PROOF';return text(r.logical_admission?.status??r.logical_admission??r.admission?.status??'UNKNOWN');}
function readersFor(r){return r.proof_reader??[];}
function processStatus(r){return r.process?.status??'NOT_RECORDED';}
function secondsPair(r){let old=r.old_pilot?.stats??r.old_pilot?.point_stats??r.old_pilot?.resources?.stats??{},now=r.resources?.stats??{};return [old.elapsed_seconds,r.resources?.internal_seconds??now.elapsed_seconds];}

function renderAssessment(){let rs=data.records,proofs=rs.filter(r=>readersFor(r).length).length,rawUnsat=rs.filter(r=>rawStatus(r)==='UNSAT').length,unk=rs.filter(r=>rawStatus(r)==='UNKNOWN').length,failed=rs.filter(r=>typeof r.process?.native_exit_code==='number'&&r.process.native_exit_code!==0).length;$('assessment-text').innerHTML=`<p><b>${proofs} native-checked positive certificates among ${rs.length} recorded diagnostic attempts.</b> ${rawUnsat} raw UNSAT results have no certified absence here; ${unk} raw results are UNKNOWN. ${failed} process failure is retained separately.</p>`;$('metrics').innerHTML=[[proofs,'Native-checked positive certificates'],[rawUnsat,'Raw UNSAT; absence remains UNKNOWN'],[failed,'Retained nonzero process exits']].map(([n,l])=>`<div class="metric"><strong>${n}</strong><span>${esc(l)}</span></div>`).join('');$('comparison').innerHTML=table(['Seen input','Old full-audit pilot','New raw engine','Logical / absence admission','Process / native exit','Recorded engine seconds: old / new'],rs.map((r,i)=>`<tr><td><button data-record="${i}">${esc(r.case_id)}</button><br><span class="mini">${esc(r.kind)}</span></td><td>${badge(r.old_pilot?.raw_engine_status??r.old_pilot?.point_status??r.old_pilot?.status??'NOT_RECORDED')}${r.old_pilot?.reason?'<br><span class="mini">'+esc(r.old_pilot.reason)+'</span>':''}</td><td>${badge(rawStatus(r))}${r.reason?'<br><span class="mini">'+esc(r.reason)+'</span>':''}</td><td>${badge(logicalStatus(r))}</td><td>${badge(processStatus(r))}<br><code>exit ${esc(text(r.process?.native_exit_code))}</code><br><span class="mini">Execution admitted: ${esc(text(r.process?.execution_admitted))}</span></td><td>${secondsPair(r).map(num).map(esc).join(' / ')}<br><span class="mini">Internal engine time; full costs below</span></td></tr>`));document.querySelectorAll('[data-record]').forEach(b=>b.onclick=()=>selectExact(Number(b.dataset.record)));}
function recordLinks(r){return Object.entries(r.downloads??{}).map(([key,ref])=>`<a download href="${esc(ref.url)}">${esc(key.replaceAll('_',' '))}${ref.pointer?' · '+esc(ref.pointer):''}</a>`).join('');}
function selectExact(index){recordIndex=index;$('case').value=index;selectRecord();}
function selectRecord(){let r=current();lineIndex=0;slotIndex=r.mark_display.slots?.find(s=>s.line_index===0)?.slot??null;$('attempt').innerHTML=`<p><span class="finder">Actual point engine, audit callback off</span> ${badge(rawStatus(r))} <span class="mini">${esc(r.kind)} · ${esc(r.case_id)}</span></p><p>Logical evidence ${badge(logicalStatus(r))}; process ${badge(processStatus(r))}; native exit <code>${esc(text(r.process?.native_exit_code))}</code>.</p>`+(r.kind==='FIRST_ATTEMPT'?'<p class="callout warning">Preserved first attempt: scientific proof output exists, but the postcheck failed. Execution was not admitted as a clean process.</p>':'')+(r.reason?`<p class="note">Recorded engine reason: <code>${esc(r.reason)}</code></p>`:'');renderSymbols();renderTheory();let has=readers().length>0;$('proof-state').innerHTML=has?'<p class="callout">This is the actual point-search proof from this attempt, checked separately by both static decoders and native B. Its logical validity does not erase a process failure or supply full per-run graph assurance.</p>':`<p class="callout warning">${rawStatus(r)==='UNSAT'?'The engine returned raw UNSAT. Absence remains UNKNOWN because this diagnostic has no independent full per-run graph certificate.':rawStatus(r)==='SAT'?'A raw SAT result is present, but no separately admitted native proof is supplied here.':'This search outcome is unresolved.'} No prior control proof is substituted.</p>`;$('record-downloads').innerHTML=recordLinks(r);$('record-admission').textContent=JSON.stringify({logical:r.logical_admission??r.admission,process:r.process,graph_assurance:r.graph_assurance??r.resources?.graph_assurance},null,2);renderProof();renderMarks();renderCosts();renderCaps();typeset($('reader'));}
function comparisons(r){if(Array.isArray(r.old_cap_comparisons))return r.old_cap_comparisons;let old=r.old_pilot?.resources??{},lim=old.limits??r.old_pilot?.limits??data.old_pilot_limits??{},now=r.resources??{},stats=now.stats??{},pairs=[['Recorded work',stats.work??now.work,lim.max_work],['Recorded search nodes',stats.nodes??now.nodes,lim.max_nodes],['Recorded internal seconds',now.internal_seconds??stats.elapsed_seconds,lim.wall_seconds]];return pairs.filter(([_,v,l])=>typeof v==='number'&&typeof l==='number').map(([name,value,old_limit])=>({name,value,old_limit,within:value<=old_limit}));}
function renderCaps(){let rows=comparisons(current());$('cap-comparison').innerHTML=rows.length?table(['Recorded field','New observed value','Old numeric ceiling','Within that number'],rows.map(r=>`<tr><td>${esc(r.name??r.field)}</td><td>${esc(num(r.value??r.observed))}</td><td>${esc(num(r.old_limit))}</td><td>${esc(text(r.within))}</td></tr>`)):'<p class="note">Comparable recorded fields were not supplied; no missing cost or count is replaced by zero.</p>';}
function renderOther(){$('diagnostic-costs').innerHTML='<pre>'+esc(JSON.stringify(data.costs,null,2))+'</pre>';$('limitations').innerHTML='<ul>'+(data.limitations??[]).map(x=>'<li>'+esc(text(x))+'</li>').join('')+'</ul>';$('provenance').textContent=JSON.stringify({input_summary_pin:data.input_summary_pin,coverage:data.coverage,saved_data_audit:data.saved_data_audit,provenance:data.provenance,projection:data.reader_projection},null,2);}
async function load(){let response=await fetch('resource-diagnostic-results-v1.json.gz',{cache:'no-store'});if(!response.ok)throw Error('Reader HTTP '+response.status);let bytes=new Uint8Array(await response.arrayBuffer()),body=bytes[0]===31&&bytes[1]===139?await new Response(new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'))).text():new TextDecoder().decode(bytes);data=JSON.parse(body);$('loading').remove();$('case').innerHTML=data.records.map((r,i)=>`<option value="${i}">${esc(r.case_id)} · ${esc(r.kind)} · ${esc(rawStatus(r))}</option>`).join('');$('case').onchange=()=>selectExact(Number($('case').value));$('all-links').onchange=renderMarks;$('short-labels').onchange=()=>{renderTheory();renderProof();renderMarks();renderLiteral();};renderAssessment();renderOther();let first=data.records.findIndex(r=>r.kind==='FIRST_ATTEMPT');if(first<0)first=data.records.findIndex(r=>readersFor(r).length);selectExact(Math.max(0,first));typeset();}load().catch(e=>{let n=$('loading');if(n){n.className='error';n.textContent='Unable to load admitted evidence: '+e.message;}console.error(e);});
'''

def page(title, body, script=''):
    config = r'<script>window.MathJax={tex:{inlineMath:[["\\(","\\)"]],displayMath:[["\\[","\\]"]]},options:{skipHtmlTags:["script","noscript","style","textarea","pre","code"]}};</script>'
    return ('<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
        '<title>'+html.escape(title)+'</title><style>'+CSS+'</style>'+config+
        '<script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-svg.js"></script></head><body>'+body+
        ('<script>'+script+'</script>' if script else '')+'</body></html>')


def build(root):
    root = root.resolve()
    summary_path = root/'data/report-summary-v1.json'
    summary = json.loads(summary_path.read_bytes())
    if summary.get('schema') != 'Resource-diagnostic-saved-summary-v1' or summary.get('status') != 'ADMITTED_DIAGNOSTIC_WITH_PRESERVED_FAILURE_AND_UNKNOWN':
        raise ValueError('Admitted diagnostic summary with preserved failure/UNKNOWN required')
    audit = summary.get('saved_data_audit')
    if is_ref(audit):
        audit = json.loads(path_for(root, audit).read_bytes())
    if not isinstance(audit, dict) or audit.get('status') != 'PASS_SAVED_DATA_AUDIT':
        raise ValueError('Global saved-data audit required; first-proof association alone is insufficient')
    saved_records = summary['records']
    if not isinstance(saved_records, list) or len(saved_records) != 8:
        raise ValueError('Expected the eight seen-input diagnostic records')
    first = [r for r in saved_records if r.get('kind') == 'FIRST_ATTEMPT']
    if len(first) != 1 or first[0].get('process', {}).get('status') != 'FAILED_POSTCHECK_AFTER_SCIENCE' or (type(first[0]['process'].get('native_exit_code')) is not int or first[0]['process']['native_exit_code'] != 1) or first[0]['process'].get('execution_admitted') is not False:
        raise ValueError('Retained failed first process must not be relabeled clean')
    out, folder = root/'report', root/'report/resource-diagnostic-downloads-v1'
    folder.mkdir(parents=True, exist_ok=True)
    copied, downloads = {}, []
    for ref in references(summary):
        if Path(str(ref['path'])).is_absolute():
            continue
        key = (ref['bytes'], ref['sha256'])
        if key in copied:
            continue
        source = path_for(root, ref)
        wrapped = source.suffix not in ('.json', '.gz')
        name = ref['sha256'][:16]+'-'+source.name+('.gz' if wrapped else '')
        target = folder/name
        if target.exists():
            raise ValueError('Preserve prior download projection: '+name)
        with target.open('xb') as destination, source.open('rb') as incoming:
            if wrapped:
                with gzip.GzipFile(filename='', fileobj=destination, mode='wb', mtime=0, compresslevel=6) as stream:
                    shutil.copyfileobj(incoming, stream, 1048576)
            else:
                shutil.copyfileobj(incoming, destination, 1048576)
        actual = pin(target)
        if not wrapped and actual != {key: ref[key] for key in ('bytes', 'sha256')}:
            raise ValueError('Raw download copy differs from its admitted original')
        copied[key] = dict(url='resource-diagnostic-downloads-v1/'+name, pointer=ref.get('pointer'))
        downloads.append(dict(original=ref['path'], original_bytes=ref['bytes'],
            original_sha256=ref['sha256'], download=copied[key]['url'], wrapped_gzip=wrapped, **actual))
    records = []
    for saved in saved_records:
        record = copy.deepcopy(saved)
        if record.get('method') != 'point' or record.get('status') not in ('SAT', 'UNSAT', 'UNKNOWN'):
            raise ValueError('Actual raw point-engine status required')
        if record.get('proof_reader') and record['status'] != 'SAT':
            raise ValueError('Nonpositive raw attempt cannot carry a substituted proof')
        if (record.get('old_pilot') or {}).get('proof_reader'):
            raise ValueError('Prior control/old-pilot proofs must not be borrowed')
        # Normalize only direct saved references; no proof or point data is made.
        for key in ('raw_ref', 'prepared_ref', 'decoded_ref', 'proof_ref'):
            if key not in record and is_ref((record.get('refs') or {}).get(key)):
                record[key] = record['refs'][key]
        record['mark_display'] = mark_display(record)
        direct = {key: value for key, value in record.items() if is_ref(value)}
        direct.update({key: value for key, value in (record.get('refs') or {}).items() if is_ref(value)})
        record['downloads'] = {key: dict(copied[(value['bytes'], value['sha256'])], pointer=value.get('pointer'))
            for key, value in direct.items() if (value['bytes'], value['sha256']) in copied}
        records.append(record)
    view = dict(schema='Passive-resource-diagnostic-reader-v1', status=summary['status'],
        input_summary_pin=pin(summary_path), records=records, saved_data_audit=audit,
        costs=summary.get('costs'), old_pilot_limits=summary.get('old_pilot_limits'), coverage=summary.get('coverage'), provenance=summary.get('provenance'),
        limitations=summary.get('limitations', []), downloads=downloads,
        reader_projection=dict(scope='Only admitted saved summary and actual selected point rows. No scientific Source imported, proof transformed, model constructed, search/native checker run or graph certificate replayed.',
            execution_boundary='The preserved first native exit one and failed postcheck are distinct from its admitted logical certificate. Seven continuation inputs do not repeat the first attempt.',
            assurance_boundary='Audit-off raw UNSAT does not supply independently certified absence. No full per-run graph assurance is claimed. No prior control proof fills missing evidence.',
            causal_boundary='Callback and multiple caps change together on seen inputs; numeric ceiling comparisons are observations, not controlled causal or counterfactual claims.',
            download_rule='Only .json/.gz direct downloads. Other file types use standalone gzip wrappers; the physical evidence archive preserves original paths and bytes.'))
    exclusive(out/RESULTS, gzip.compress(wire(view), mtime=0, compresslevel=6))
    exclusive(out/'resource-diagnostic-v1.html', page('Point-search resource diagnostic · GCTS research', BODY, SCRIPT).encode())
    rows = ''.join('<tr><td><code>'+html.escape(d['original'])+'</code></td><td><a download href="'+
        html.escape(d['download'], quote=True)+'">'+('Gzip download' if d['wrapped_gzip'] else 'Exact download')+'</a></td><td>'+str(d['original_bytes'])+'</td><td><code>'+d['original_sha256']+'</code></td></tr>' for d in downloads)
    body = '<header><div class="eyebrow">Diagnostic evidence</div><h1>Preserved failure and logical certificates</h1><nav><a href="resource-diagnostic-v1.html#reader">Proof reader</a></nav></header><main><section><h2>Original saved paths and bytes</h2><p>The first CALv1 attempt is retained with its native exit one and failed postcheck. Its separately checked positive proof is not relabeled as clean execution. The continuation concerns only seven remaining seen inputs. No whole-graph or absence claim follows from audit-off outputs.</p><!-- RESOURCE_DIAGNOSTIC_ARCHIVE_LINK --><p><a download href="resource-diagnostic-results-v1.json.gz">Reader projection</a></p><div class="scroll"><table><thead><tr><th>Original relative path</th><th>Download</th><th>Original bytes</th><th>Original SHA256</th></tr></thead><tbody>'+rows+'</tbody></table></div></section><section><h2>Projection and admission scope</h2><pre>'+html.escape(json.dumps(dict(summary_pin=view['input_summary_pin'],status=view['status'],projection=view['reader_projection']),indent=2))+'</pre></section></main>'
    exclusive(out/'resource-diagnostic-evidence-v1.html', page('Evidence · resource diagnostic', body).encode())
    return dict(status='PASSIVE_REPORT_WRITTEN', records=len(records), downloads=len(downloads),
        outputs={name: pin(out/name) for name in ('resource-diagnostic-v1.html', 'resource-diagnostic-evidence-v1.html', RESULTS)})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=ROOT)
    args = parser.parse_args()
    print(json.dumps(build(args.root), sort_keys=True))


if __name__ == '__main__':
    main()


