# Passive resource-diagnostic assembler

Source entry point: `review/assemble_resource_results_v1.py::main()`, 29062 bytes, SHA256 `5f5d70989b8902580ffb35922fddf170bebf7ee155772328302fe1d371f04dc4`. Stdlib only. Source was written/read/AST-parsed but never imported or executed by its author. Root and an independent peer must review before execution. Scientific Sources, protocols and outputs are unchanged.

The available-dataset scope requires the seven original CALv2 continuation phases to be terminal native exit zero with complete/frozen worker receipts, plus the original CALv1 first attempt with its actual failed postchecks and native exit one. It does not manufacture missing-phase outcomes or provide a generic guarded-process fallback. A contradictory/missing artifact fails before the exclusive outputs.

Root must physically materialize all 51 CALv1 originals at `history/first-attempt-v1/files/<original-relative-path>`. The immutable reference manifest still has its historical reference-only status; this assembler independently checks every actual file against that manifest and records physical custody separately. It reads no external old-run path. Downloadable artifact refs are all CALv2-relative; absolute origins/runtime/master metadata inside retained protocols are inert provenance.

The exact old DAG protocol is passively copied to `comparison/old-pilot-protocol-v1.json`, 5030 bytes, SHA256 `dea6491b67c2c8c3bda9d933a23f770e545385f16dd08ab1d397a0d7aa503c65`. It supplies actual declared old point limits, not inferred limits. The historical metrics-only context supplies old statuses/counters/costs, including `forward_status`; it has no raw stop reason, so `old_pilot.reason` remains null. No old control proof is loaded or supplied.

Exclusive outputs:

- `review/saved-data-audit-v1.json`: schema `Resource-diagnostic-saved-audit-v1`, status `PASS_SAVED_DATA_AUDIT`.
- `data/report-summary-v1.json`: schema `Resource-diagnostic-saved-summary-v1`, status `ADMITTED_DIAGNOSTIC_WITH_PRESERVED_FAILURE_AND_UNKNOWN`.

The summary has eight flat `records` (also exposed as `cases`), `coverage`, `costs`, `history`, `provenance`, `limitations`, `saved_data_audit`, `old_pilot_limits` and its pinned protocol ref. It asserts the original first phase is first in cohort order and preserves its actual cost. The current five separately admitted point proof case/bound IDs must equal the historical forward-positive IDs. That fact is disclosed as historical context, not a new paired timing result or count of distinct theorems.

Each record has `id`, original `case_id`/`case`, `method='point'`, `kind=FIRST_ATTEMPT|CONTINUATION`, `status` equal to raw SAT/UNSAT/UNKNOWN, and separate `science_status`, `reason`, `process`, `admission`, `costs`, `resources`, `old_pilot`, full refs and model metadata. First `process.status` is `FAILED_POSTCHECK_AFTER_SCIENCE`, native exit one and `execution_admitted=false` even though its saved positive proof is valid. Seven continuation processes are individually joined to their original phase/PID/protocol/log/postcheck receipts. No first-case rerun or native-zero relabel is accepted.

Only `science_status='VERIFIED_POSITIVE'` receives actual `selected`, `selected_rows`, `slot_rows`, `reference_mapping`, `proof_dag`, `proof_reader`, `decoded_ref` and `proof_ref`. Raw SAT without complete static/native admission has no proof reader. Raw UNSAT has absence UNKNOWN and no independent negative certificate; raw resource/assurance/capture refusals stay explicit. Every record retains full graph conformance `NOT_MEASURED`.

Positive admission joins complete model/fresh-admission hashes, both stored decoder semantic projections, original statement/goal, exact selected point totals/seed/mark agreement and raw certificate, literal CID-to-slot/native-reference/DAG maps, native receipt limits/whole line census and saved proof/selected/native hashes. The assembler does not import/run any model checker, decoder or kernel. Native semantic truth remains the separately executed receipt and frozen driver context; kernel receipts do not carry independent input self-hashes.

Large saved raw checkpoints are scanned for exact token hashes without loading or replaying their graph state. Emitted event/rollback digest checks run only when the whole stream was retained; explicit complete flags and original extents preserve prefixes. The compact actual outcome is compared with every corresponding field of a complete full raw record; duplicate reported statistics/reason/extents must also match that compact outcome. A partial raw JSON prefix is never parsed or admitted as a proof. Artifact and parent-directory symlinks are rejected before path resolution.

Reader rows contain one-based line/dependency numbers, exact formula, LaTeX and deterministic pred0/imp English, actual zero-based slot and `formula_id` from the saved decoded DAG. Formula colors and active/PAD channels come from the original prepared model. There is no invented graph, geometric coordinate assignment or old control derivation.

Current cost aliases are `raw_engine_seconds` from actual engine statistics, `observed_process_seconds` from the observer (including the failed first attempt), and nullable `measured_pipeline_seconds` from the diagnostic result. Original measured cost keys remain. Historical `old_pilot.costs.search_seconds` is old internal engine time; `point_pipeline_seconds` is the saved old point pipeline. These clock scopes differ and overlap; reused preparation is not cold and no fair callback-only/algorithmic timing gain is claimed.

After Source review, use the same pinned isolated Python with `-I -S -B` to execute the passive assembler once. It writes no scientific artifact and reruns no engine, model builder, decoder, kernel, control or graph checker. Its author has not executed it.
