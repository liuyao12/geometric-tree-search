"""AST/data-only continuation preflight; never import or run either driver.

The proof obligation is the actual Source return/access structure, not a mock
science function. No engine, model builder, logical checker, proof decoder,
prepared JSON parser or historical proof payload is imported/read/executed.
"""
import ast
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
BASE_SOURCE='review/CALv1-driver-preserved-v1.py'
SOURCE='source/run_resource_diagnostic_v2.py'
OLD_PLAN='review/CALv1-input-declarations-preserved-v1.json'
PLAN='plan/input-declarations-v2.json'
FIRST='seen-off-dsgb-alternate-l10-v1'


def pin(path):
    h=hashlib.sha256();size=0
    with path.open('rb') as stream:
        for part in iter(lambda:stream.read(1048576),b''):h.update(part);size+=len(part)
    return dict(bytes=size,sha256=h.hexdigest())


def read(name):return json.loads((ROOT/name).read_bytes())
def dump(node):return ast.dump(node,include_attributes=False)


def main():
    baseline=(ROOT/BASE_SOURCE).read_text();current=(ROOT/SOURCE).read_text()
    assert pin(ROOT/BASE_SOURCE)['sha256']=='9d9995b3db26e889b22b40fdd8ceca45c1f7325427e83ff13520fce7ec8610c9'
    assert baseline.count("unchanged()['status']")==2 and "unchanged()['status']" not in current
    old_tree=ast.parse(baseline.replace("unchanged()['status']","unchanged()[0]['status']"));tree=ast.parse(current)
    functions={n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
    old_functions={n.name:n for n in old_tree.body if isinstance(n,ast.FunctionDef)}
    assert set(functions)==set(old_functions)
    # Only freeze metadata/schedule and its history manifest file set differ.
    # All run/science/observer functions equal v1 after the two getter fixes.
    unchanged_functions=[]
    for name in functions:
        if name not in ('freeze','frozen_files'):
            assert dump(functions[name])==dump(old_functions[name]),name
            unchanged_functions.append(name)
    contract=functions['unchanged'];returns=[n for n in ast.walk(contract) if isinstance(n,ast.Return)]
    assert len(returns)==1 and isinstance(returns[0].value,ast.Tuple)
    assert [dump(n) for n in returns[0].value.elts]==[dump(ast.Name(id='protocol',ctx=ast.Load())),dump(ast.Name(id='plan',ctx=ast.Load()))]
    parent={id(child):node for node in ast.walk(tree) for child in ast.iter_child_nodes(node)}
    sites=[]
    for call in ast.walk(tree):
        if not (isinstance(call,ast.Call) and isinstance(call.func,ast.Name) and call.func.id=='unchanged'):continue
        assert not call.args and not call.keywords
        use=parent[id(call)]
        if isinstance(use,ast.Assign):
            assert len(use.targets)==1 and isinstance(use.targets[0],ast.Tuple)
            assert [n.id for n in use.targets[0].elts]==['protocol','plan'];kind='UNPACK_PROTOCOL_PLAN'
        elif isinstance(use,ast.Expr):kind='CHECK_ONLY_IGNORED_PAIR'
        else:
            assert isinstance(use,ast.Subscript) and isinstance(use.slice,ast.Constant)
            assert type(use.slice.value) is int and use.slice.value==0
            outer=parent[id(use)]
            assert isinstance(outer,ast.Subscript) and isinstance(outer.slice,ast.Constant) and outer.slice.value=='status'
            kind='PAIR_ZERO_PROTOCOL_STATUS'
        sites.append(dict(line=call.lineno,kind=kind))
    assert len(sites)==5 and sum(s['kind']=='PAIR_ZERO_PROTOCOL_STATUS' for s in sites)==2
    old=read(OLD_PLAN);plan=read(PLAN);history=plan['continuation_history']
    old_cases={c['id']:c for c in old['cases']};cases={c['id']:c for c in plan['cases']}
    assert len(old_cases)==8 and len(cases)==7 and FIRST not in cases and set(cases)==set(old_cases)-{FIRST}
    assert history['excluded_phase_id']==FIRST and history['classification']=='FAILED_POSTCHECK_AFTER_SCIENCE'
    assert history['native_exit_code']==1 and history['execution_admitted'] is False and history['no_rerun'] is True
    assert {c['id'] for c in plan['original_cohort']}==set(old_cases)
    for key in ('point_limits','guards','native_limits','decoder_limits','capture'):assert plan[key]==old[key],key
    inputs=[]
    for identity,case in cases.items():
        assert case==old_cases[identity],identity
        for value in case['inputs'].values():
            path=ROOT/value['path'];assert pin(path)=={k:value[k] for k in ('bytes','sha256')}
            inputs.append(dict(path=value['path'],**pin(path)))
    assert len(inputs)==21
    assert [d['ref'] for d in plan['source_dependencies']]==[d['ref'] for d in old['source_dependencies']]
    for dep in plan['source_dependencies']:
        assert pin(ROOT/dep['ref']['path'])=={k:dep['ref'][k] for k in ('bytes','sha256')}
    history_ref=history['reference_manifest'];assert pin(ROOT/history_ref['path'])=={k:history_ref[k] for k in ('bytes','sha256')}
    record=dict(schema='Shared-resource-data-only-preflight-v1',status='PASS_STATIC_TUPLE_RETURN_ACCESS_AND_SEVEN_CASE_CONTINUATION',
        source=dict(path=SOURCE,**pin(ROOT/SOURCE)),baseline_source=dict(path=BASE_SOURCE,**pin(ROOT/BASE_SOURCE)),
        source_return_contract='unchanged returns exactly (protocol, plan); both status getters index tuple0 before status',
        call_sites=sites,functions_unchanged_after_two_getter_fixes=sorted(unchanged_functions),
        original_cohort=8,remaining_unexecuted_cases=7,excluded_first_case=FIRST,limits_unchanged=True,
        byte_checked_remaining_input_artifacts=inputs,history_reference_only=history_ref,
        scientific_imports=False,scientific_calls=False,driver_imported=False,mock_science=False,
        scope='Structural AST/data proof only. Does not run either driver or evaluate a logical/model/search function; no historic selected/decoded proof is opened. Root must still review Sources before freeze.')
    path=ROOT/'review/data-only-preflight-v1.json'
    with path.open('x') as stream:json.dump(record,stream,sort_keys=True,indent=2);stream.write('\n')
    print(json.dumps(dict(status=record['status'],receipt=dict(path=str(path.relative_to(ROOT)),**pin(path))),sort_keys=True))


if __name__=='__main__':main()
