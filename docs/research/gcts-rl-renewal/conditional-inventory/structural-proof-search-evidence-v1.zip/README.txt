Milestone S: complete frozen research evidence

Scientific once is permanently spent. The sole run passed all23 qualification controls. Point search selected eight proofs and returned five wall UNKNOWNs. The conventional control produced nine proofs and four finite-fragment nonreachability certificates. All17 successful certificates passed actual fixed C1 and independent B. No trained RL or fixed literal Wang proof palette is claimed.

MANIFEST.json maps every original complete byte body to its source path, size and SHA256. Gzip originals remain gzip; their decoded identities are in worker/custody records. Native traces retain eight events and full event hashes; point event histories retain64 prefixes, not whole UNSAT trees. UNKNOWN final restored snapshots are absent, not synthesized. Runtime binaries and later publication/TLS/live QA are excluded as stated in the manifest.
