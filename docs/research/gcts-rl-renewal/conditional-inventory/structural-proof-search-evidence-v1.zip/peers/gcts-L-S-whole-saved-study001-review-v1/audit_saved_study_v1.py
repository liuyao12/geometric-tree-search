"""Stdlib saved-data audit only. No subject module imported/called/replayed."""
from pathlib import Path
import json,gzip,hashlib,itertools,collections,math,stat
S=Path('/private/tmp/gcts-proof-structure-20261028-v1');A=S/'actual/study-001';D=Path(__file__).parent
checks=collections.Counter();raws=[];guards=[];states=[];results=[];bundles=[];qrows=[];case_rows=[]
def need(v,s):
 if not v:raise AssertionError(s)
 checks[s]+=1
def wire(x):return (json.dumps(x,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode()
def color(x):return json.dumps(x,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)
def sha(b):return hashlib.sha256(b).hexdigest()
def pairs(xs):
 d={}
 for k,v in xs:need(k not in d,'unique JSON key');d[k]=v
 return d
def load(b):return json.loads(b,object_pairs_hook=pairs,parse_constant=lambda s:(_ for _ in ()).throw(ValueError(s)))
def native(x):
 if type(x)is dict:
  for k,v in x.items():need(type(k)is str,'JSON string key');native(v)
 elif type(x)is list:
  for v in x:native(v)
 else:need(x is None or type(x)in(str,int,bool) or type(x)is float and math.isfinite(x),'finite native JSON leaf')
def eq(a,b,s):need(wire(a)==wire(b),s)
def pin(p):
 p=Path(p);st=p.lstat();need(stat.S_ISREG(st.st_mode)and not p.is_symlink(),'regular nonsymlink file');b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def ref(t,label):
 need(type(t)is dict and set(t)=={'path','bytes','sha256'} and type(t['bytes'])is int,'strict rawref3');p=pin(t['path']);eq(p,t,'full current rawref match');guards.append({'kind':label,**p});return Path(t['path']).read_bytes()
root=load(ref({'path':str(S/'root/study-001-original-tool-whole-transport-adoption-v1.json'),'bytes':2797,'sha256':'1e23917932010693cdf7d9072ce7e27e6bc362f5744b0f59f5c7a2903efe6e7c'},'Root original transport adoption'))
o=load(ref(root['observer_receipt'],'observer receipt'));need(root['tool']=={'initial_chunk':'5efb74','session_id':44824,'terminal_chunk':'b6cf15','exit_code':0,'remaining_session':False},'original owned exit0 SourceonceSPENT')
plan=load(ref(root['plan'],'plan'));auth=load(ref(root['authority'],'authority'));spent=load(ref(root['consumed'],'adjacent consumed'));ac=load((A/'CONSUMED.json').read_bytes())
need(len(plan['sources'])==9 and len(plan['metadata'])==8,'all9 current Sources8 metadata')
for k,t in plan['sources'].items():ref(t,'Source '+k)
for k,t in plan['metadata'].items():ref(t,'metadata '+k)
ref(plan['bootstrap'],'bootstrap');ref(plan['python'],'D90')
need(set(auth)=={'schema','authorized','uses','plan','runner','python'} and auth['authorized']is True and type(auth['uses'])is int and auth['uses']==1,'typed A6 once authority')
eq(auth['plan'],root['plan'],'authority exactplan');eq(auth['runner'],plan['sources']['runner'],'authority exactrunner');eq(auth['python'],plan['python'],'authority exactD90');eq(spent,{'authority':root['authority'],'plan':root['plan'],'status':'SPENT'},'full spent authority association');eq(ac,{'authority':root['authority'],'consumed':root['consumed']},'actual consumed association')
wt=load(ref(o['streams']['stdout'],'worker full stdout'));need(len(ref(o['streams']['stderr'],'worker stderr'))==0,'worker stderr empty');eq(wt,o['worker_terminal'],'whole worker terminal capture')
outer=load(ref(root['outer_stdout'],'outer stdout'));need(len(ref(root['outer_stderr'],'outer stderr'))==0,'outer stderr empty');eq(outer,{'receipt':root['observer_receipt'],'status':'COMPLETE'},'complete outer receipt binding')
need(o['status']=='COMPLETE' and o['returncode']==0 and o['wait_confirmed']is True and o['both_streams_EOF']is True and o['group_gone']is True and o['cleanup_errors']==[] and o['failure']is None,'complete owned wait EOF group cleanup')
need(o['retained_streams_complete']=={'stdout':True,'stderr':True} and o['observed_stream_bytes']=={'stdout':1147,'stderr':0},'full streams no truncation')
need(o['stdin_bytes_sent']==plan['sources']['runner']['bytes'],'complete retained runner input bytes')
expected_argv=[plan['python']['path'],'-I','-S','-B',plan['bootstrap']['path'],plan['sources']['runner']['path'],str(plan['sources']['runner']['bytes']),plan['sources']['runner']['sha256'],'--mode','worker','--plan',root['plan']['path']];eq(o['command'],expected_argv,'exact declared child bootstrap argv')
eq(wt['plan'],root['plan'],'worker terminal exactplan');need(wt['status']=='COMPLETE','complete worker terminal')
allfiles={str(p)for p in A.iterdir()};need(allfiles=={t['path']for t in o['files']}|{str(A/'observer-result.json')}and len(allfiles)==125,'all125 actual files exact census')
for t in o['files']:ref(t,'owned actual file')
need(sum(t['bytes']for t in o['files'])==o['stored_bytes']==2156477,'all124 priorowned stored extents')
owned=sum(Path(p).stat().st_size for p in allfiles);need(owned<=plan['limits']['total_bytes'] and len(allfiles)<=plan['limits']['max_files'] and o['wait4_peak_bytes']==56442880 and o['wait4_peak_bytes']<=plan['limits']['rss_bytes'],'current aggregate count observedRSS gates')
need(o['whole_observer_seconds']<=plan['limits']['observer_seconds'] and wt['elapsed_seconds']<=plan['limits']['worker_seconds'],'named whole cooperative clock gates')
refs={};data={};rawsum=0;storedsum=0
def artifact(t):
 global rawsum,storedsum
 need(set(t)=={'encoding','name','raw_bytes','raw_sha256','stored'} and t['encoding']in('json','gzip-json'),'artifact exact5 wire');n=t['name'];need(n not in refs,'unique artifact name');refs[n]=t
 sb=ref(t['stored'],'artifact '+n);need(Path(t['stored']['path']).parent==A and len(sb)<=plan['limits']['file_bytes'],'owned artifact path/body cap');b=gzip.decompress(sb)if t['encoding']=='gzip-json'else sb
 need(len(b)==t['raw_bytes'] and sha(b)==t['raw_sha256'],'complete raw decode hash extent');x=load(b);native(x);need(b==wire(x),'full canonical artifact JSON');data[n]=x;raws.append({**t,'stored_raw_CRC_canonical_complete':True});rawsum+=len(b);storedsum+=len(sb);return x
r=artifact(wt['result']);eq(wt['result'],root['worker_result'],'Root worker result identity')
for t in r['artifacts']:artifact(t)
need(len(refs)==121 and len(r['artifacts'])==120,'all121 artifact bodies including worker result');eq(wt['public_calls'],r['outer_public_calls'],'whole outside-method call ledger')
q=r['qualification'];eq(q,data['whole-qualification'],'whole qualification summary identity');need(q['status']=='PASS'and q['controls']==23 and len(q['records'])==23 and q['public_calls']=={'compiler.compile_problem':4,'engine.solve':23}and q['conventional_calls']==5,'complete fixed23 qualification census')
for rr in q['records']:eq(rr['emitter_return'],refs['qualification-'+rr['id']],'all qualification record rawref association')
# Direct saved-data relations below are not calls to any project oracle or search.
def formula(f,catalog):
 need(type(f)is list and len(f)==3 and type(f[0])is str,'finite formula array')
 if f[0]=='pred':need(type(f[1])is str and f[1]and len(f[1])<=64 and all(32<=ord(c)<=126 for c in f[1])and type(f[2])is list and f[2]==[],'exact zeroarity atom')
 else:need(f[0]=='imp','only implication');formula(f[1],catalog);formula(f[2],catalog)
 catalog[color(f)]=f

def proof(problem,lines,label,bound=True):
 need(type(lines)is list and 1<=len(lines) and (not bound or len(lines)<=problem['maxlines']),'within bound selected proof')
 outs=[]
 for i,line in enumerate(lines):
  formula(line['formula'],{})
  if line['rule']=='axiom':need(set(line)=={'rule','name','formula'}and line['name']in problem['hypotheses'],'exact given proof line');eq(line['formula'],problem['hypotheses'][line['name']],'given formula equality')
  else:
   need(set(line)=={'rule','formula','antecedent','implication'}and line['rule']=='mp','exact MP proof line');a,b=line['antecedent'],line['implication'];need(type(a)is int and type(b)is int and 0<=a<i and 0<=b<i,'strict earlier native MP refs');eq(outs[b],['imp',outs[a],line['formula']],'actual earlier-reference MP equality')
  outs.append(line['formula'])
 eq(outs[-1],problem['goal'],'actual final proof equals goal');return {'label':label,'lines':len(lines),'given':sum(x['rule']=='axiom'for x in lines),'mp':sum(x['rule']=='mp'for x in lines),'sha256':sha(wire(lines))}

def bundle(problem,b,label):
 need(set(problem)=={'hypotheses','goal','maxlines'}and type(problem['maxlines'])is int and 1<=problem['maxlines']<=32,'exact problem3')
 catalog={}
 for f in problem['hypotheses'].values():formula(f,catalog)
 formula(problem['goal'],catalog);cs=[catalog[k]for k in sorted(catalog)];eq(b['formula_catalog'],cs,'entire subformula catalogue');eq(b['hypotheses'],problem['hypotheses'],'bundle hypotheses exact');eq(b['goal'],problem['goal'],'bundle goal exact');need(b['slots']==problem['maxlines'],'bundle slots exact')
 expected=[];steps={};n=problem['maxlines']
 def add(i,cid,line,marks):
  if i==n-1 and color(line['formula'])!=color(problem['goal']):return
  mm={}
  for p,v in marks:
   if p in mm and mm[p]!=v:return
   mm[p]=v
  expected.append({'id':cid,'t':['slot:'+str(i)],'m':[[p,mm[p]]for p in sorted(mm)]});steps[cid]={'slot':i,'line':line}
 for i in range(n):
  out='out:'+str(i)
  for j,name in enumerate(sorted(problem['hypotheses'])):
   f=problem['hypotheses'][name];add(i,'r'+str(i)+':h'+str(j),{'rule':'axiom','name':name,'formula':f},[(out,color(f))])
  for j,f in enumerate(cs):
   if f[0]!='imp':continue
   for a in range(i):
    for bb in range(i):add(i,'r'+str(i)+':mp'+str(j)+':'+str(a)+':'+str(bb),{'rule':'mp','formula':f[2],'antecedent':a,'implication':bb},[(out,color(f[2])),('out:'+str(a),color(f[1])),('out:'+str(bb),color(f))])
 eq(b['model'],{'required':['slot:'+str(i)for i in range(n)],'candidates':expected},'every exact t/m candidate identity and order');eq(b['steps'],steps,'all candidate step data');need(b['compilation']['candidates']==len(expected)and b['version']=='S-STRUCTURAL-PROOF-TILES-v2','complete compiler census/currentversion');bundles.append({'label':label,'slots':n,'catalogue':len(cs),'candidates':len(expected)});return len(expected)

def graph(model,selected,excluded):
 roots=model['required'];byid={c['id']:c for c in model['candidates']};need(len(byid)==len(model['candidates'])and len(set(roots))==len(roots),'whole unique raw model')
 need(type(selected)is list and type(excluded)is list and all(type(x)is str and x in byid for x in selected+excluded)and len(set(selected))==len(selected)and len(set(excluded))==len(excluded)and not set(selected)&set(excluded),'selected/excluded current universe')
 totals=dict.fromkeys(roots,0);marks={}
 for cid in selected:
  c=byid[cid];need(len(c['t'])==1 and c['t'][0]in totals,'singleton unit required support');totals[c['t'][0]]+=1;need(totals[c['t'][0]]==1,'actual t capacity')
  for p,v in c['m']:
   need(p not in marks or marks[p][0]==v,'actual selected m equality');marks[p]=(v,marks.get(p,(None,0))[1]+1)
 domains={p:[]for p in roots};banned=set(excluded)
 for cid in sorted(byid):
  c=byid[cid];need(type(c['id'])is str and len(c['t'])==1 and c['t'][0]in totals and len({p for p,v in c['m']})==len(c['m']) and all(type(p)is str and type(v)is str for p,v in c['m']),'full raw candidate t/m native fields')
  if not totals[c['t'][0]]and cid not in banned and all(p not in marks or marks[p][0]==v for p,v in c['m']):domains[c['t'][0]].append(cid)
 return {'schema':'S-structural-unit-point-state-v1','selected':sorted(selected),'totals':[[p,totals[p]]for p in roots],'markings':[[p,v,n]for p,(v,n)in sorted(marks.items())],'domains':[[p,domains[p]]for p in roots],'excluded':sorted(excluded),'forward_incidence':[[p,cid,1]for p in roots for cid in domains[p]],'reverse_incidence':[[cid,byid[cid]['t'][0],1]for cid in sorted(byid)if cid in domains[byid[cid]['t'][0]]],'generations':[[p,0]for p in roots]}

def state(model,s,label,role):
 expected=graph(model,s['selected'],s['excluded']);eq(s,expected,'entire native state9 and both graphs');states.append({'label':label,'role':role,'candidates':len(model['candidates']),'selected':len(s['selected']),'state_SHA256':sha(wire(s))})

def brute(model):
 choices={p:[]for p in model['required']}
 for c in model['candidates']:choices[c['t'][0]].append(c['id'])
 total=math.prod(map(len,choices.values()));need(total<=100000,'tiny full product prospectively bounded');sol=[]
 for ids in itertools.product(*(sorted(choices[p])for p in model['required'])):
  try:g=graph(model,list(ids),[])
  except AssertionError:continue
  if all(v==1 for p,v in g['totals']):sol.append(sorted(ids))
 return sol,total

def modelhash(model):return sha(wire({'required':model['required'],'candidates':[{'id':c['id'],'t':c['t'],'m':sorted(c['m'])}for c in sorted(model['candidates'],key=lambda c:c['id'])]}))
def rcheck(model,x,label):
 need(set(x)=={'schema','version','status','reason','selected','certificate','stats','events','event_extent','model_sha256','entry_state','restored_state','state_hashes','rollback_records','scope'},'native result exact15');need(x['version']=='S-STRUCTURAL-UNIT-POINT-SEARCH-v1','current result VERSION');need(x['status']in('SAT','UNSAT','UNKNOWN'),'three honest statuses')
 for role,key in [('entry_state','entry'),('restored_state','restored')]:
  if x[role]is not None:state(model,x[role],label,role)
  if x['state_hashes'][key]is not None:need(x[role]is not None and sha(wire(x[role]))==x['state_hashes'][key],'all supplied fullstate hashes exact')
  else:need(x['status']=='UNKNOWN','null hash onlyUNKNOWN')
 if x['model_sha256']is not None:need(x['model_sha256']==modelhash(model),'entire normalized model hash')
 if x['status']!='UNKNOWN':need(x['entry_state']is not None and x['restored_state']is not None,'normal actual full snapshots');eq(x['entry_state'],x['restored_state'],'normal exact rollback observed')
 if x['status']=='SAT':
  g=graph(model,x['selected'],[]);need(all(v==1 for p,v in g['totals']),'whole SAT exact t target');eq(x['certificate'],{'selected':sorted(x['selected']),'totals':g['totals'],'markings':g['markings'],'generations':[[c,1]for c in sorted(x['selected'])]},'whole SAT actual m certificate')
 else:need(x['selected']is None and x['certificate']is None,'no witness onUNKNOWN orUNSAT')
 e=x['event_extent'];body=b''.join(wire(v)for v in x['events']);need([v['seq']for v in x['events']]==list(range(len(x['events'])))and e['retained']==len(x['events'])<=e['count']and len(body)<=e['JSONL_bytes'],'complete retained event sequence count bytes');need(e['retained_complete']is(e['retained']==e['count']),'truthful prefix flag')
 if e['retained_complete']:need(sha(body)==e['SHA256']and len(body)==e['JSONL_bytes'],'full emitted event body SHA')
 need(e['evaluation_complete']is(x['status']in('SAT','UNSAT')),'honest completion flag')
 for rr in x['rollback_records']:
  need(set(rr)=={'reason','candidate','from_trail','to_trail','undone','expected_sha256','restored_sha256','equal'}and all(type(rr[k])is int and rr[k]>=0 for k in ['from_trail','to_trail','undone'])and rr['from_trail']-rr['to_trail']==rr['undone'],'full exact rollback8 extent')
  if rr['reason']=='COMPLETE_FAILED_CHILD':need(rr['equal']is True and rr['restored_sha256']==rr['expected_sha256'],'every complete child hash restoration')
  if x['status']!='UNKNOWN':need(rr['equal']is True and rr['restored_sha256']==rr['expected_sha256'],'normal final rollback observed equality')
 need(x['rollback_records'][-1]['reason']=='FINAL_MANDATORY_CLEANUP'and x['rollback_records'][-1]['to_trail']==0,'mandatory cleanup trail0 receipt')
 need(x['stats']['trail_writes']==x['stats']['trail_undos']and x['stats']['events']==e['count']and x['stats']['retained_events']==e['retained'],'all deltas counted reversed and event counters')
 # Interpret only the SAVED event prefix, never search an omitted alternative.
 chosen=[];banned=[];stack=[];pending=None
 for ev in x['events']:
  k,d=ev['kind'],ev['data'];g=graph(model,chosen,banned);front=[(p,len(ids))for(p,ids),(pp,t)in zip(g['domains'],g['totals'],strict=True)if not t];zero=sorted(p for p,n in front if n==0);forced=sorted(p for p,n in front if n==1)
  if k=='BRANCH':
   need(not zero and not forced and d['point']==min(front,key=lambda z:(z[1],z[0]))[0],'saved branch obeys globaldead forced and all0MRV');legal=dict(g['domains'])[d['point']];eq(d['legal'],legal,'saved complete current branch domains');need(set(d['ordering'])==set(legal)and len(d['ordering'])==len(legal),'complete orderingfallback notpruning');stack.append((list(chosen),list(banned),d['ordering'][0],sha(wire(g))));pending=d['ordering'][0]
  elif k=='PLACED':
   need(not zero and d['root_generation']==0 and d['tile_generation']==1,'placed after no dead generation0/1')
   if d['forced']:need(forced and d['point']==forced[0]and dict(g['domains'])[d['point']]==[d['candidate']],'actual global forced candidate')
   else:need(not forced and pending==d['candidate'],'actual branch firstordered candidate');pending=None
   chosen.append(d['candidate']);graph(model,chosen,banned)
  elif k=='DEAD':need(zero and d['point']==zero[0],'actual global late dead')
  elif k=='ROLLBACK':
   need(stack,'saved child rollback has parentframe');before,ex,cid,hs=stack.pop();need(cid==d['candidate']and hs==d['expected_sha256']==d['restored_sha256'],'saved branchparent complete rollback association');chosen,banned=before,ex;pending=None
  elif k=='EXCLUDED':need(sha(wire(g))==d['parent_sha256']and d['candidate']not in chosen,'exclusion only actual restored parent');banned.append(d['candidate'])
  elif k=='SOLUTION':need(not front,'complete saved solution event');eq(d['selected'],sorted(chosen),'saved solution actual selected')
  else:raise AssertionError('unknown event kind')
 results.append({'label':label,'status':x['status'],'nodes':x['stats']['nodes'],'forced':x['stats']['forced_placements'],'branches':x['stats']['branch_decisions'],'backtracks':x['stats']['backtracks'],'retained_events_independently_interpreted':len(x['events']),'event_count':e['count'],'full_event_body_present':e['retained_complete'],'rollback_records':len(x['rollback_records']),'actual_restored_snapshot':x['restored_state']is not None})

# Complete23 qualification, including declared negative data and tiny full products.
for i in range(1,24):
 name=next(n for n in refs if n.startswith('qualification-Q'+str(i).zfill(2)+'-'));x=data[name];need(x['schema']=='L-S-independent-qualification-control-v1','qualification case schema')
 if x['kind']in('INPUT_ERROR','ORDER_ERROR','FOREIGN'):
  need('result'not in x and x['exception']['type']==({'INPUT_ERROR':'InputError','ORDER_ERROR':'OrderingError','FOREIGN':'ForeignOrder'}[x['kind']]),'expected typed error control')
  if x['kind']=='FOREIGN':need(x['exception']['same_instance']is True,'same instance foreign propagation saved assertion')
  if i==6:need(x['model']['candidates'][0]['m']==[['x','0'],['x','1']],'contradictory selfmarks actual malformed data')
  if i==7:need(len(x['model']['candidates'][0]['t'])==2,'shared-positive explicitly unsupported negative')
  if i==8:need(len({c['id']for c in x['model']['candidates']})<len(x['model']['candidates']),'duplicate candidate identity negative')
  if i==9:need(type(x['model']['candidates'][0]['m'][0][1])is bool,'bool marking actualtyped negative')
  qrows.append({'name':name,'outcome':x['kind'],'exception':x['exception']});continue
 model=x['bundle']['model']if x['kind']=='COMPILED_TINY'else x['model'];rcheck(model,x['result'],name);ss,count=brute(model);eq(x['independent_exhaustion']['solutions'],ss,'all full tiny raw tilings');need(x['independent_exhaustion']['assignments_examined']==count and x['independent_exhaustion']['status']=='COMPLETE','full tiny assignment extent')
 if x['kind']!='NODE_ZERO':need(x['result']['status']==('SAT'if ss else'UNSAT'),'tiny complete producer truth')
 if x['result']['status']=='SAT':need(x['result']['selected']in ss,'actual tiny witness member')
 if i==2:need(x['result']['stats']['nodes']==1 and x['result']['stats']['forced_placements']==x['result']['stats']['branch_decisions']==0 and x['result']['events'][0]['data']['point']=='z','late globaldead beforeavailableforced')
 if i==5:need(x['result']['selected']==['A','C'],'missing distinct assigned0 actualcontrol')
 if i==10:
  need(x['data_only_negative']['status']=='EXPECTED_REJECTED_FORGED_DATA','actual checker refused rollbackforgery')
  f=x['data_only_negative']['forged_result'];orig=load(wire(x['result']));orig['restored_state']['totals'][0][1]=1;eq(f,orig,'isolated rollback forgery entirebody');need(f['restored_state']!=graph(model,f['restored_state']['selected'],f['restored_state']['excluded']),'rollback forgery demonstrably inconsistent graph')
 if i==12:
  need(x['result']['status']=='UNKNOWN','node0unknown');v=x['data_only_hash_variants'];need(v['UNKNOWN_with_observed_entry_and_null_hash']['status']=='VERIFIED_DATA_ONLY_PROFILE' and v['normal_with_observed_entry_and_null_hash']['status']=='EXPECTED_REJECTED_FORGED_DATA','actual checker distinguishes UNKNOWN optionalhash vsnormal requiredhash');partial=v['UNKNOWN_with_observed_entry_and_null_hash']['result'];orig=load(wire(x['result']));orig['state_hashes']['entry']=None;eq(partial,orig,'isolated validUNKNOWN missinghash variant');rcheck(model,partial,name+'-data-only-UNKNOWN-hash');normal=v['normal_with_observed_entry_and_null_hash']['result'];base=data['qualification-Q10-failed-branch']['result'];orig=load(wire(base));orig['state_hashes']['entry']=None;eq(normal,orig,'isolated normal missinghash forgery');need(normal['status']=='SAT'and normal['entry_state']is not None and normal['state_hashes']['entry']is None,'normal missinghash invalidprofile')
 if i==13:need(x['result']['events']==[]and x['result']['event_extent']['count']>0 and x['result']['event_extent']['retained_complete']is False,'zero retained prefix not clippedevaluation')
 if i in(18,19):need(next(e for e in x['result']['events']if e['kind']=='BRANCH')['data']['point']==('z'if i==18 else'a'),'MRVall0 andlexicaltie')
 if x['kind']=='COMPILED_TINY':
  bundle(x['problem'],x['bundle'],name)
  if x['result']['status']=='SAT':proof(x['problem'],[x['bundle']['steps'][cid]['line']for cid in sorted(x['result']['selected'],key=lambda c:x['bundle']['steps'][c]['slot'])],name)
  cc=x['conventional'];need(cc['status']==('UNKNOWN_BOUND'if i in(20,21)else'DERIVABLE'),'actual overlong closure is not false bounded negative')
  if cc['status']=='UNKNOWN_BOUND':need(cc['proof']is None and len(cc['unbounded_certificate'])==3>x['problem']['maxlines'],'overbound witness stays separate');proof(x['problem'],cc['unbounded_certificate'],name+'-unbounded',False)
  else:proof(x['problem'],cc['proof'],name+'-conventional')
  if i==22:
   f=x['data_only_universe_negative']['forged_bundle'];orig=load(wire(x['bundle']));orig['model']['candidates'].pop(0);eq(f,orig,'isolated omittedcandidate forgedbundle entirebody');need(len(f['model']['candidates'])+1==len(x['bundle']['model']['candidates'])and x['data_only_universe_negative']['independent_rejection']['status']=='REJECTED','missing completeuniverse correctlyrejected')
 qrows.append({'name':name,'outcome':x['result']['status'],'full_raw_assignments':count,'complete_solutions':len(ss),'kind':x['kind']})
supp=q['supplementary_negative_closure'];np={'hypotheses':{'a':['imp',['pred','P',[]],['pred','Q',[]]]},'goal':['pred','Q',[]],'maxlines':3}
need(supp['status']=='NOT_DERIVABLE'and supp['proof']is None and supp['problem_sha256']==sha(wire(np)),'fixed supplementary closure negative input binding')
eq(supp['closure'],[np['hypotheses']['a']],'supplementary negative complete MPclosed given only')
# All13 research bundle universes + result/proof data, not producer execution.
inputs=load(Path(plan['metadata']['cases']['path']).read_bytes());need(len(inputs)==13 and {x['id']for x in r['results']}==set(inputs),'whole13 immutable input cases')
for row in r['results']:
 name=row['id'];problem=inputs[name];eq(row['problem'],problem,'exact benchmark input only problem');b=data[name+'-complete-point-model'];x=data[name+'-point-solve'];bundle(problem,b,name);rcheck(b['model'],x,name);need(data[name+'-independent-model']['status']=='VERIFIED'and data[name+'-independent-result']['status']=='VERIFIED','stored independent gates present');eq(row['point']['status'],x['status'],'summary point status');eq(row['point']['stats'],x['stats'],'summary fullpointstats');info={'id':name,'point_status':x['status'],'conventional_status':row['conventional']['status'],'candidates':len(b['model']['candidates']),'nodes':x['stats']['nodes']}
 if x['status']=='SAT':
  lines=[b['steps'][cid]['line']for cid in sorted(x['selected'],key=lambda c:b['steps'][c]['slot'])];eq(lines,row['point']['proof'],'actual selected steps match savedproof');info['point_proof']=proof(problem,lines,name);eq(x['selected'],row['point']['selected'],'fullselected summary binding')
 else:need(x['status']=='UNKNOWN'and x['reason']=='WALL_SECONDS'and x['certificate']is None and x['selected']is None,'all5 wallUNKNOWN nofalseproof');need(row['point'].get('proof')is None,'no UNKNOWN summaryproof')
 conventional=data[name+'-conventional-closure'];need(conventional['status']==row['conventional']['status'],'conventional summarystatus')
 known={color(f):f for f in conventional['closure']};need(len(known)==len(conventional['closure']),'completeunique closure carrier')
 for f in problem['hypotheses'].values():need(color(f)in known,'closure includes allgiven')
 for f in known.values():
  if f[0]=='imp'and color(f[1])in known:need(color(f[2])in known,'stored closedset isactuallyMPclosed')
 if conventional['status']=='DERIVABLE':info['conventional_proof']=proof(problem,conventional['proof'],name+'-conventional')
 else:need(conventional['status']=='NOT_DERIVABLE'and color(problem['goal'])not in known and conventional['proof']is None,'completeMPclosed superset excludesgoal nofragmentproof')
 case_rows.append(info)
need(collections.Counter(x['point_status']for x in case_rows)=={'SAT':8,'UNKNOWN':5},'all13 point verdictcensus');need(collections.Counter(x['conventional_status']for x in case_rows)=={'DERIVABLE':9,'NOT_DERIVABLE':4},'all13 conventionalverdictcensus')
support={'schema':'L-S-complete-saved-study001-independent-support-v1','status':'PASS','subject_calls':0,'method':'Stdlib data-only full byte/gzip/nativeJSON/canonical/hash and direct finite candidate/t-m/proof relations. Saved event-prefix interpretation only, no replay/search of omitted alternatives and no project imports/functions/checkers.','transport_adoption':pin(S/'root/study-001-original-tool-whole-transport-adoption-v1.json'),'observer':pin(A/'observer-result.json'),'all121_artifacts':raws,'current_raw_guards':guards,'qualification23':qrows,'research13':case_rows,'all_native_states':states,'all_native_result_profiles':results,'all_complete_bundle_universes':bundles,'totals':{'actual_files':len(allfiles),'prior_owned_bytes':o['stored_bytes'],'whole_actual_bytes':owned,'artifact_count':len(refs),'artifact_raw_bytes':rawsum,'artifact_stored_bytes':storedsum,'qualification_controls':len(qrows),'research_cases':len(case_rows),'full_state9_checks':len(states),'saved_event_rows_interpreted':sum(x['retained_events_independently_interpreted']for x in results),'full_bundle_universes':len(bundles),'rollback_rows_checked':sum(x['rollback_records']for x in results)},'checks':dict(checks),'scope':'No Source/helpers/VM/codec/solver/qualification replay, no actual rerun, no source or payload changes. Full17 native FOL/codec/carrier validation semantics are independently audited by C, not replaced by this record.'}
p=D/'complete-saved-study001-data-support-v1.json'
with p.open('w')as f:json.dump(support,f,sort_keys=True,ensure_ascii=True,indent=2);f.write('\n')
print(json.dumps({'status':'PASS','totals':support['totals'],'support':pin(p)},sort_keys=True))
