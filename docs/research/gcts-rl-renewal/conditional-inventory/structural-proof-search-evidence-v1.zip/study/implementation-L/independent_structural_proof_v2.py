"""Independent finite GIVEN/MP, raw point-domain checks and symbolic control.

Inert Source: no project imports, IO, demo, factory call or main execution.
This is an explicit formula-valued finite point adaptation, not literal Wang.
"""
import hashlib
import itertools
import json
import math
import time

VERSION = 'S-INDEPENDENT-STRUCTURAL-PROOF-v2'
DEFAULT_LIMITS = {'wall_seconds': 10, 'max_work': 20000000, 'max_depth': 128,
                  'max_candidates': 100000, 'max_assignments': 100000,
                  'max_output_bytes': 16777216}


class VerificationError(Exception):
    pass


class VerificationBudgetExceeded(Exception):
    pass


def _need(value, message):
    if not value:
        raise VerificationError(message)


def _fields(value, keys):
    _need(type(value) is dict and len(value) == len(keys), 'exact record cardinality')
    _need(set(value) == set(keys), 'exact record fields')


class _Meter:
    def __init__(self, limits, budget, wall=None):
        self.start = time.perf_counter()
        src = DEFAULT_LIMITS if limits is None else limits
        _fields(src, DEFAULT_LIMITS)
        if wall is None:
            wall = src['wall_seconds']
        _need(type(wall) in (int, float) and math.isfinite(wall)
              and 0 < wall <= 60, 'finite positive wall at most60')
        self.limits = dict(src)
        self.limits['wall_seconds'] = wall
        for key in DEFAULT_LIMITS:
            if key != 'wall_seconds':
                _need(type(src[key]) is int and 0 <= src[key] <= 100000000,
                      'bounded exact integer limit')
        _need(budget is None or callable(budget), 'optional budget callable')
        self.budget = budget
        self.work = 0
        self.callbacks = 0
        self.assertions = 0

    def take(self, amount=1):
        _need(type(amount) is int and amount >= 0, 'exact work reservation')
        if self.work + amount > self.limits['max_work']:
            raise VerificationBudgetExceeded('independent logical work ceiling')
        if time.perf_counter() - self.start >= self.limits['wall_seconds']:
            raise VerificationBudgetExceeded('independent cooperative wall ceiling')
        self.work += amount
        if self.budget is not None:
            self.callbacks += 1
            self.budget()

    def cap(self, amount, key):
        self.take()
        if amount > self.limits[key]:
            raise VerificationBudgetExceeded(key)

    def costs(self):
        return {'logical_work': self.work, 'budget_callbacks': self.callbacks,
                'elapsed_main_entry_seconds': time.perf_counter() - self.start,
                'scope': 'Preparation, full checks and certificate construction included; '
                         'returned-record serialization and caller tail excluded. '
                         'Cooperative logical/wall bounds, not OS quotas.'}


def _text(x, m, maxlen=256, printable=False):
    _need(type(x) is str and x and len(x) <= maxlen, 'bounded nonempty string')
    m.take(12 * len(x))
    if printable:
        _need(all(32 <= ord(c) <= 126 for c in x), 'printable ASCII name')
    else:
        try:
            x.encode('utf-8')
        except UnicodeEncodeError as e:
            raise VerificationError('valid Unicode scalar string') from e
    return x


def _bound(x, m, active, depth=0):
    m.take()
    m.cap(depth, 'max_depth')
    if type(x) is str:
        m.take(12 * len(x))
        return 2 + 12 * len(x)
    if x is None or type(x) is bool:
        return 5
    if type(x) is int:
        m.cap(x.bit_length(), 'max_output_bytes')
        m.take(x.bit_length())
        return 3 + x.bit_length()
    if type(x) is float:
        _need(math.isfinite(x), 'finite JSON number')
        return 32
    _need(type(x) in (list, dict), 'native JSON container')
    _need(id(x) not in active, 'acyclic JSON container')
    m.take(len(x))
    active.add(id(x))
    try:
        size = 2
        if type(x) is list:
            for v in x:
                size += 1 + _bound(v, m, active, depth + 1)
        else:
            for k, v in x.items():
                _need(type(k) is str, 'native JSON key')
                size += 2 + _bound(k, m, active, depth + 1) + _bound(v, m, active, depth + 1)
        return size
    finally:
        active.remove(id(x))


def _image(x, m):
    upper = _bound(x, m, set())
    m.cap(upper, 'max_output_bytes')
    m.take(upper)
    return json.dumps(x, sort_keys=True, ensure_ascii=True,
                      separators=(',', ':'), allow_nan=False)


def _same(a, b, m, message):
    _need(_image(a, m) == _image(b, m), message)
    m.assertions += 1


def _digest(x, m):
    return hashlib.sha256((_image(x, m) + '\n').encode('ascii')).hexdigest()


def _formula(f, m, catalog, active, depth=0):
    m.take()
    m.cap(depth, 'max_depth')
    _need(type(f) is list and f and type(f[0]) is str, 'native formula array and tag')
    _need(id(f) not in active, 'acyclic formula')
    active.add(id(f))
    try:
        if f[0] == 'pred':
            _need(len(f) == 3 and type(f[2]) is list and len(f[2]) == 0,
                  'zeroarity atom')
            name = _text(f[1], m, 64, True)
            out = ['pred', name, []]
        else:
            _need(f[0] == 'imp' and len(f) == 3, 'implication-only fragment')
            left = _formula(f[1], m, catalog, active, depth + 1)
            right = _formula(f[2], m, catalog, active, depth + 1)
            out = ['imp', left, right]
        key = _image(out, m)
        m.take(len(key) + 1)
        catalog[key] = out
        return out
    finally:
        active.remove(id(f))


def _problem(problem, m):
    _fields(problem, ('hypotheses', 'goal', 'maxlines'))
    h = problem['hypotheses']
    _need(type(h) is dict and len(h) <= 256, 'at most256 named hypotheses')
    n = problem['maxlines']
    _need(type(n) is int and 1 <= n <= 32, 'exact bounded line count')
    m.take(len(h))
    for name in h:
        _text(name, m, 64, True)
    catalog = {}
    normalized = {}
    for name in sorted(h):
        normalized[name] = _formula(h[name], m, catalog, set())
    goal = _formula(problem['goal'], m, catalog, set())
    p = {'hypotheses': normalized, 'goal': goal, 'maxlines': n}
    return p, [catalog[k] for k in sorted(catalog)], _digest(p, m)


def _point_string(value, m):
    _need(type(value) is str, 'exact point/id/value string')
    m.take(12 * len(value) + 1)
    return value


def _raw_model(model, m):
    _fields(model, ('required', 'candidates'))
    required = model['required']
    candidates = model['candidates']
    _need(type(required) is list, 'finite explicit required roots')
    if len(required) > 32:
        raise VerificationBudgetExceeded('independent required-root profile32')
    _need(type(candidates) is list, 'complete explicit candidate array')
    m.cap(len(candidates), 'max_candidates')
    m.take(len(required) + len(candidates))
    roots = set()
    for p in required:
        _point_string(p, m)
        _need(p not in roots, 'unique required root')
        roots.add(p)
    byid = {}
    for c in candidates:
        _fields(c, ('id', 't', 'm'))
        cid = _point_string(c['id'], m)
        _need(cid not in byid, 'unique inventory candidate identity')
        _need(type(c['t']) is list and len(c['t']) == 1
              and type(c['t'][0]) is str and c['t'][0] in roots,
              'exactly one unit positive root')
        marks = c['m']
        _need(type(marks) is list, 'complete finite marking list')
        m.take(len(marks))
        seen = set()
        for row in marks:
            _need(type(row) is list and len(row) == 2, 'point/value pair')
            _point_string(row[0], m)
            _need(type(row[1]) is str, 'exact marking string value')
            m.take(12 * len(row[1]))
            _need(row[0] not in seen, 'no duplicate or inconsistent selfmark')
            seen.add(row[0])
        byid[cid] = c
    return sorted(roots), byid


def _expected(p, catalog, m):
    slots = p['maxlines']
    candidates = []
    steps = {}
    implications = [(j, f) for j, f in enumerate(catalog) if f[0] == 'imp']
    target_key = _image(p['goal'], m)
    def append(i, identity, line, pairs):
        m.take(len(pairs) + 1)
        output = _image(line['formula'], m)
        if i == slots - 1 and output != target_key:
            return
        united = {}
        for q, value in pairs:
            if q in united and united[q] != value:
                return
            united[q] = value
        m.cap(len(candidates) + 1, 'max_candidates')
        m.take(2 + len(united))
        candidates.append({'id': identity, 't': ['slot:' + str(i)],
                           'm': [[q, united[q]] for q in sorted(united)]})
        steps[identity] = {'slot': i, 'line': line}
    for i in range(slots):
        out = 'out:' + str(i)
        for hindex, name in enumerate(sorted(p['hypotheses'])):
            f = p['hypotheses'][name]
            append(i, 'r' + str(i) + ':h' + str(hindex),
                   {'rule': 'axiom', 'name': name, 'formula': f},
                   [(out, _image(f, m))])
        for j, f in implications:
            ak, ik, bk = (_image(z, m) for z in (f[1], f, f[2]))
            for a in range(i):
                for b in range(i):
                    m.take()
                    append(i, 'r' + str(i) + ':mp' + str(j) + ':' + str(a) + ':' + str(b),
                           {'rule': 'mp', 'formula': f[2], 'antecedent': a, 'implication': b},
                           [(out, bk), ('out:' + str(a), ak), ('out:' + str(b), ik)])
    return {'required': ['slot:' + str(i) for i in range(slots)],
            'candidates': candidates}, steps


def _bundle(problem, bundle, m):
    p, catalog, digest = _problem(problem, m)
    _fields(bundle, ('schema', 'version', 'hypotheses', 'goal', 'slots', 'formula_catalog',
                     'model', 'steps', 'compilation', 'scope'))
    _need(bundle['schema'] == 'S-finite-structural-proof-model-v1'
          and bundle['version'] == 'S-STRUCTURAL-PROOF-TILES-v2', 'current compiler identity')
    _same(bundle['hypotheses'], p['hypotheses'], m, 'entire given hypothesis binding')
    _same(bundle['goal'], p['goal'], m, 'entire given goal binding')
    _need(type(bundle['slots']) is int and bundle['slots'] == p['maxlines'], 'bound slot count')
    _same(bundle['formula_catalog'], catalog, m, 'complete independent subformula catalogue')
    model, steps = _expected(p, catalog, m)
    _same(bundle['model'], model, m, 'entire complete t/m candidate universe and order')
    _same(bundle['steps'], steps, m, 'entire candidate/step metadata association')
    roots, byid = _raw_model(bundle['model'], m)
    _fields(bundle['compilation'], ('work', 'candidates', 'wall_seconds'))
    c = bundle['compilation']
    _need(type(c['work']) is int and c['work'] >= 0
          and type(c['candidates']) is int and c['candidates'] == len(byid),
          'typed complete compilation counters')
    _need(type(c['wall_seconds']) in (int, float) and math.isfinite(c['wall_seconds'])
          and c['wall_seconds'] >= 0 and type(bundle['scope']) is str, 'typed compiler metadata')
    return p, digest, roots, byid


def _domains(model, selected, excluded, m):
    roots, byid = _raw_model(model, m)
    _need(type(selected) is list and type(excluded) is list, 'complete selected/excluded lists')
    m.take(len(selected) + len(excluded))
    _need(all(type(c) is str for c in selected + excluded), 'native candidate ids')
    _need(len(selected) == len(set(selected)) and len(excluded) == len(set(excluded)),
          'unique selected/excluded identities')
    _need(not set(selected) & set(excluded), 'selected/excluded disjoint')
    _need(all(c in byid for c in selected + excluded), 'current universe identity binding')
    total = {p: 0 for p in roots}
    marks = {}
    for cid in selected:
        c = byid[cid]
        total[c['t'][0]] += 1
        _need(total[c['t'][0]] == 1, 'whole selected exact unit capacity')
        m.take(len(c['m']) + 1)
        for q, value in c['m']:
            _need(q not in marks or marks[q][0] == value, 'whole selected actual m agreement')
            marks[q] = (value, marks.get(q, (None, 0))[1] + 1)
    legal = []
    selected_set, excluded_set = set(selected), set(excluded)
    for cid in sorted(byid):
        c = byid[cid]
        m.take(len(c['m']) + 1)
        if total[c['t'][0]] or cid in selected_set or cid in excluded_set:
            continue
        if all(q not in marks or marks[q][0] == value for q, value in c['m']):
            legal.append(cid)
    domains = {p: [] for p in roots}
    for cid in legal:
        m.take()
        domains[byid[cid]['t'][0]].append(cid)
    return {'schema': 'L-complete-unit-point-graph-v1',
            'totals': [[p, total[p]] for p in roots],
            'markings': [[p, value, count] for p, (value, count) in sorted(marks.items())],
            'selected': sorted(selected), 'excluded': sorted(excluded),
            'domains': domains,
            'frontier': [[p, 0, len(domains[p])] for p in roots if not total[p]],
            'forward_incidence': [[p, list(domains[p])] for p in roots if not total[p]],
            'reverse_incidence': [[cid, byid[cid]['t'][0], 1] for cid in legal]}


def _proof(p, lines, m, bound=True):
    _need(type(lines) is list and lines, 'nonempty proof line array')
    if bound:
        _need(len(lines) <= p['maxlines'], 'proof within requested bound')
    outputs = []
    for i, line in enumerate(lines):
        m.take()
        _need(type(line) is dict and type(line.get('rule')) is str, 'native proof line')
        f = _formula(line.get('formula'), m, {}, set())
        if line['rule'] == 'axiom':
            _fields(line, ('rule', 'name', 'formula'))
            name = line['name']
            _need(type(name) is str and name in p['hypotheses'], 'given named hypothesis')
            _same(f, p['hypotheses'][name], m, 'exact hypothesis formula')
        else:
            _fields(line, ('rule', 'formula', 'antecedent', 'implication'))
            _need(line['rule'] == 'mp', 'only GIVEN or MP rule')
            a, b = line['antecedent'], line['implication']
            _need(type(a) is int and type(b) is int and 0 <= a < i and 0 <= b < i,
                  'exact nonbool earlier reference indexes')
            antecedent = outputs[a]
            implication = outputs[b]
            _same(implication, ['imp', antecedent, f], m, 'earlier-reference MP full formulas')
        outputs.append(f)
    _same(outputs[-1], p['goal'], m, 'actual last output equals given goal')
    return lines


def _selected(p, bundle, ids, m):
    _need(type(ids) is list and len(ids) == p['maxlines'], 'one chosen candidate per slot')
    graph = _domains(bundle['model'], ids, [], m)
    _need(all(v == 1 for q, v in graph['totals']), 'whole target exact tiling')
    _need(all(not ids for ids in graph['domains'].values()), 'whole target no frontier')
    byslot = {}
    for cid in ids:
        m.take()
        step = bundle['steps'][cid]
        _need(step['slot'] not in byslot, 'unique selected slot')
        byslot[step['slot']] = step['line']
    _need(set(byslot) == set(range(p['maxlines'])), 'all selected slots present')
    lines = [byslot[i] for i in range(p['maxlines'])]
    _proof(p, lines, m)
    return {'status': 'VERIFIED_CERTIFICATE', 'proof': lines, 'target': p['goal'],
            'selected_ids': list(ids), 'whole_point_state': graph}


def _receipt(m, status, digest=None, checks=None, certificate=None, reason=None):
    return {'schema': 'L-structural-proof-independent-check-v1', 'version': VERSION,
            'status': status, 'problem_sha256': digest,
            'checks': {} if checks is None else checks, 'certificate': certificate,
            'costs': None if m is None else m.costs(), 'reason': reason,
            'scope': 'Complete declared finite input/candidate/point/proof relation checks. '
                     'No producer checker, logical oracle, cached legality or proof hint.'}


def _verification(action, limits, budget):
    meter = None
    try:
        meter = _Meter(limits, budget)
        digest, checks, certificate = action(meter)
        meter.take()
        return _receipt(meter, 'VERIFIED', digest, checks, certificate)
    except VerificationBudgetExceeded as e:
        return _receipt(meter, 'UNKNOWN_BUDGET', reason=str(e))
    except VerificationError as e:
        return _receipt(meter, 'REJECTED', reason=str(e))


def verify_bundle(problem, bundle, *, limits=None, budget=None):
    def action(m):
        p, digest, roots, byid = _bundle(problem, bundle, m)
        return digest, {'required_roots': len(roots), 'complete_candidates': len(byid),
                        'complete_subformula_catalogue': len(bundle['formula_catalog']),
                        'all_root_generations': 0}, None
    return _verification(action, limits, budget)


def verify_selected(problem, bundle, ids, *, limits=None, budget=None):
    def action(m):
        p, digest, roots, byid = _bundle(problem, bundle, m)
        cert = _selected(p, bundle, ids, m)
        return digest, {'complete_candidates': len(byid), 'whole_target_and_markings': True,
                        'independent_given_MP_proof': True}, cert
    return _verification(action, limits, budget)


def verify_domains(model, selected, excluded, reported_domains=None, *, limits=None, budget=None):
    def action(m):
        graph = _domains(model, selected, excluded, m)
        if reported_domains is not None:
            _same(reported_domains, graph['domains'], m, 'entire reported current domains')
        return None, {'complete_candidate_domain_check': True,
                      'both_incidence_directions': True}, graph
    return _verification(action, limits, budget)


def brute_tiny_model(model, *, limits=None, budget=None):
    meter = None
    try:
        meter = _Meter(limits, budget)
        roots, byid = _raw_model(model, meter)
        domains = {p: [] for p in roots}
        for cid in sorted(byid):
            domains[byid[cid]['t'][0]].append(cid)
        combinations = 1
        for p in roots:
            combinations *= len(domains[p])
            meter.cap(combinations, 'max_assignments')
        solutions = []
        solution_extent_bound = 2
        visited = 0
        for ids in itertools.product(*(domains[p] for p in roots)):
            meter.take()
            visited += 1
            try:
                graph = _domains(model, list(ids), [], meter)
            except VerificationError:
                continue
            _need(all(v == 1 for p, v in graph['totals']), 'whole brute target')
            meter.take(len(ids) + 1)
            meter.cap(len(solutions) + 1, 'max_assignments')
            solution_extent_bound += 3 + sum(3 + 12 * len(cid) for cid in ids)
            meter.cap(solution_extent_bound, 'max_output_bytes')
            solutions.append(sorted(ids))
        meter.take()
        return {'schema': 'L-tiny-unit-point-exhaustion-v1', 'version': VERSION,
                'status': 'COMPLETE', 'assignments_examined': visited,
                'solutions': solutions, 'costs': meter.costs(), 'reason': None,
                'scope': 'Entire tiny raw candidate assignment product, not producer search.'}
    except (VerificationError, VerificationBudgetExceeded) as e:
        return {'schema': 'L-tiny-unit-point-exhaustion-v1', 'version': VERSION,
                'status': 'UNKNOWN_BUDGET' if isinstance(e, VerificationBudgetExceeded) else 'REJECTED',
                'assignments_examined': None, 'solutions': None,
                'costs': None if meter is None else meter.costs(), 'reason': str(e),
                'scope': 'No incomplete assignment set is returned as complete.'}


def mp_closure(problem, wall_seconds=2, *, limits=None, budget=None):
    m = None
    try:
        m = _Meter(limits, budget, wall_seconds)
        p, catalog, digest = _problem(problem, m)
        known = {}
        origins = {}
        for name in sorted(p['hypotheses']):
            f = p['hypotheses'][name]
            key = _image(f, m)
            if key not in known:
                m.take()
                known[key] = f
                origins[key] = ('GIVEN', name)
        changed = True
        while changed:
            changed = False
            for ikey in sorted(known):
                m.take()
                implication = known[ikey]
                if implication[0] != 'imp':
                    continue
                ak = _image(implication[1], m)
                bk = _image(implication[2], m)
                if ak in known and bk not in known:
                    m.take(len(bk) + 1)
                    known[bk] = implication[2]
                    origins[bk] = ('MP', ak, ikey)
                    changed = True
        closure = [known[k] for k in sorted(known)]
        target = _image(p['goal'], m)
        certificate = None
        if target in known:
            lines = []
            emitted = {}
            needed = set()
            pending = [target]
            while pending:
                m.take()
                key = pending.pop()
                if key in needed:
                    continue
                needed.add(key)
                origin = origins[key]
                if origin[0] == 'MP':
                    m.take(2)
                    pending.extend([origin[1], origin[2]])
            # Discovery insertion order topologically precedes every MP child.
            for key, origin in origins.items():
                m.take()
                if key not in needed:
                    continue
                if origin[0] == 'GIVEN':
                    line = {'rule': 'axiom', 'name': origin[1], 'formula': known[key]}
                else:
                    _need(origin[1] in emitted and origin[2] in emitted,
                          'well-founded discovery certificate')
                    line = {'rule': 'mp', 'antecedent': emitted[origin[1]],
                            'implication': emitted[origin[2]], 'formula': known[key]}
                m.take(len(lines) + 1)
                emitted[key] = len(lines)
                lines.append(line)
            _proof(p, lines, m, False)
            certificate = lines
        status = ('NOT_DERIVABLE' if certificate is None else
                  'DERIVABLE' if len(certificate) <= p['maxlines'] else 'UNKNOWN_BOUND')
        m.take()
        return {'schema': 'L-conventional-GIVEN-MP-closure-v1', 'version': VERSION,
                'status': status, 'problem_sha256': digest,
                'proof': certificate if status == 'DERIVABLE' else None,
                'unbounded_certificate': certificate if status == 'UNKNOWN_BOUND' else None,
                'within_line_bound': status == 'DERIVABLE' if certificate is not None else None,
                'closure': closure, 'costs': m.costs(),
                'reason': 'first discovery DAG exceeds requested line bound' if status == 'UNKNOWN_BOUND' else None,
                'attribution': 'Conventional symbolic fixed-point control independently constructs this proof; '
                               'it is not a tile-search or RL-discovered certificate.',
                'scope': 'Complete finite MP closure; NOT_DERIVABLE is stronger than bounded failure. '
                         'A first-found overlong certificate does not prove bounded UNSAT. '
                         'Input preparation, closure and certificate reconstruction/checking are inside the clock.'}
    except (VerificationError, VerificationBudgetExceeded) as e:
        return {'schema': 'L-conventional-GIVEN-MP-closure-v1', 'version': VERSION,
                'status': 'UNKNOWN_BUDGET' if isinstance(e, VerificationBudgetExceeded) else 'REJECTED',
                'problem_sha256': None, 'proof': None, 'unbounded_certificate': None,
                'within_line_bound': None, 'closure': None,
                'costs': None if m is None else m.costs(), 'reason': str(e),
                'attribution': 'Conventional symbolic control; no admitted partial certificate.',
                'scope': 'Budget refusal is unknown, not bounded unprovability.'}


def _native_state(model, state, m):
    _fields(state, ('schema', 'selected', 'totals', 'markings', 'domains', 'excluded',
                    'forward_incidence', 'reverse_incidence', 'generations'))
    _need(state['schema'] == 'S-structural-unit-point-state-v1', 'native state identity')
    graph = _domains(model, state['selected'], state['excluded'], m)
    total = dict(graph['totals'])
    roots = model['required']
    expected = {'schema': 'S-structural-unit-point-state-v1',
                'selected': graph['selected'],
                'totals': [[p, total[p]] for p in roots],
                'markings': graph['markings'],
                'domains': [[p, graph['domains'][p]] for p in roots],
                'excluded': graph['excluded'],
                'forward_incidence': [[p, cid, 1] for p in roots
                    for cid in graph['domains'][p]],
                'reverse_incidence': graph['reverse_incidence'],
                'generations': [[p, 0] for p in roots]}
    _same(state, expected, m, 'entire native state9 and both graph directions')
    return graph


def _hash_text(value):
    return (type(value) is str and len(value) == 64
            and all(c in '0123456789abcdef' for c in value))


def _normal_model(model):
    return {'required': list(model['required']),
            'candidates': [{'id': c['id'], 't': list(c['t']),
                            'm': sorted([list(row) for row in c['m']])}
                           for c in sorted(model['candidates'], key=lambda c: c['id'])]}


def _rollback(row, byid, normal, m):
    _fields(row, ('reason', 'candidate', 'from_trail', 'to_trail', 'undone',
                  'expected_sha256', 'restored_sha256', 'equal'))
    _need(row['reason'] in ('COMPLETE_FAILED_CHILD', 'FINAL_MANDATORY_CLEANUP')
          and (row['candidate'] is None or type(row['candidate']) is str
               and row['candidate'] in byid), 'scoped rollback identity')
    _need(all(type(row[k]) is int and row[k] >= 0
              for k in ('from_trail', 'to_trail', 'undone'))
          and row['from_trail'] - row['to_trail'] == row['undone'], 'exact rollback extent')
    _need(row['expected_sha256'] is None or _hash_text(row['expected_sha256']),
          'rollback expected full state hash')
    _need(row['restored_sha256'] is None or _hash_text(row['restored_sha256']),
          'rollback observed full state hash')
    if normal:
        _need(row['equal'] is True and row['expected_sha256'] == row['restored_sha256']
              and _hash_text(row['expected_sha256']), 'normal full rollback equality')
    else:
        _need(row['equal'] is None or type(row['equal']) is bool,
              'truthful optional UNKNOWN rollback observation')
    m.take()


def _native_result(model, result, m):
    _fields(result, ('schema', 'version', 'status', 'reason', 'selected', 'certificate',
                     'stats', 'events', 'event_extent', 'model_sha256', 'entry_state',
                     'restored_state', 'state_hashes', 'rollback_records', 'scope'))
    _need(result['schema'] == 'S-structural-unit-point-result-v1'
          and result['version'] == 'S-STRUCTURAL-UNIT-POINT-SEARCH-v1', 'native result identity')
    _need(result['status'] in ('SAT', 'UNSAT', 'UNKNOWN'), 'exact three result statuses')
    _need(type(result['reason']) is str and result['reason'] in (
        'EXACT_FINITE_TARGET_AND_LITERAL_MARKINGS', 'COMPLETE_FINITE_SEARCH_EXHAUSTED',
        'WALL_SECONDS', 'MAX_NODES') and type(result['scope']) is str,
        'public reason and scope metadata')
    roots, byid = _raw_model(model, m)
    if result['model_sha256'] is not None:
        _need(result['model_sha256'] == _digest(_normal_model(model), m),
              'entire normalized current raw model hash')
    for role in ('entry_state', 'restored_state'):
        if result[role] is not None:
            _native_state(model, result[role], m)
    _fields(result['state_hashes'], ('entry', 'restored'))
    for role, key in [('entry_state', 'entry'), ('restored_state', 'restored')]:
        supplied = result['state_hashes'][key]
        if supplied is None:
            _need(result['status'] == 'UNKNOWN', 'normal native state hash required')
        else:
            _need(result[role] is not None, 'supplied hash requires actual observed state')
            _same(supplied, _digest(result[role], m), m, 'whole native state hash association')
    normal = result['status'] in ('SAT', 'UNSAT')
    if normal:
        _need(_hash_text(result['model_sha256']), 'normal full model association')
        _need(result['entry_state'] is not None and result['restored_state'] is not None,
              'normal full entry and restored observations required')
        _same(result['entry_state'], result['restored_state'], m,
              'complete normal mandatory rollback')
        entry = _domains(model, [], [], m)
        _need(result['entry_state']['selected'] == []
              and result['entry_state']['excluded'] == [], 'clean complete root entry')
        _same(result['entry_state']['markings'], entry['markings'], m, 'no hidden entry markings')
    certificate = None
    if result['status'] == 'SAT':
        chosen = result['selected']
        graph = _domains(model, chosen, [], m)
        _need(all(v == 1 for p, v in graph['totals']), 'whole native SAT exact target')
        total = dict(graph['totals'])
        certificate = {'selected': sorted(chosen),
                       'totals': [[p, total[p]] for p in model['required']],
                       'markings': graph['markings'],
                       'generations': [[cid, 1] for cid in sorted(chosen)]}
        _same(result['certificate'], certificate, m, 'whole native t/m certificate4')
    else:
        _need(result['selected'] is None and result['certificate'] is None,
              'no false witness on UNSAT or UNKNOWN')
    _need(type(result['events']) is list, 'retained event array')
    extent = result['event_extent']
    _fields(extent, ('count', 'retained', 'JSONL_bytes', 'SHA256',
                     'retained_complete', 'evaluation_complete'))
    _need(all(type(extent[k]) is int and extent[k] >= 0
              for k in ('count', 'retained', 'JSONL_bytes')), 'exact nonnegative event extents')
    _need(type(extent['retained_complete']) is bool
          and type(extent['evaluation_complete']) is bool
          and _hash_text(extent['SHA256']), 'typed event completeness and digest')
    h = hashlib.sha256()
    rawbytes = 0
    for i, event in enumerate(result['events']):
        m.take()
        _fields(event, ('seq', 'kind', 'data'))
        _need(type(event['seq']) is int and event['seq'] == i, 'complete retained event prefix sequence')
        _need(event['kind'] in ('DEAD', 'PLACED', 'BRANCH', 'ROLLBACK', 'EXCLUDED', 'SOLUTION')
              and type(event['data']) is dict, 'public native event kind and data')
        data = event['data']
        if event['kind'] == 'DEAD':
            _fields(data, ('point', 'generation'))
            _need(data['point'] in roots and type(data['generation']) is int
                  and data['generation'] == 0, 'dead root generation0')
        elif event['kind'] == 'PLACED':
            _fields(data, ('candidate', 'point', 'forced', 'root_generation', 'tile_generation'))
            _need(type(data['candidate']) is str and data['candidate'] in byid and data['point'] == byid[data['candidate']]['t'][0]
                  and type(data['forced']) is bool and type(data['root_generation']) is int
                  and data['root_generation'] == 0 and type(data['tile_generation']) is int
                  and data['tile_generation'] == 1, 'placement identity and exact root0 tile1')
        elif event['kind'] == 'BRANCH':
            _fields(data, ('point', 'generation', 'legal', 'ordering', 'policy'))
            _need(data['point'] in roots and type(data['generation']) is int
                  and data['generation'] == 0 and type(data['legal']) is list
                  and type(data['ordering']) is list
                  and all(type(cid) is str for cid in data['legal'] + data['ordering'])
                  and type(data['policy']) is str and data['policy'] in ('LEXICAL',
                  'NO_PREFERENCE_LEXICAL', 'PREFIX_PLUS_COMPLETE_LEXICAL_FALLBACK'),
                  'complete branch-domain event')
            _need(data['legal'] == sorted(set(data['legal']))
                  and len(data['ordering']) == len(set(data['ordering']))
                  and set(data['ordering']) == set(data['legal'])
                  and all(cid in byid and byid[cid]['t'][0] == data['point']
                          for cid in data['legal']), 'ordering is a complete current base permutation')
        elif event['kind'] == 'ROLLBACK':
            _rollback(data, byid, normal, m)
        elif event['kind'] == 'EXCLUDED':
            _fields(data, ('candidate', 'parent_sha256', 'meaning'))
            _need(type(data['candidate']) is str and data['candidate'] in byid
                  and _hash_text(data['parent_sha256']) and type(data['meaning']) is str,
                  'typed scoped exclusion event')
        elif event['kind'] == 'SOLUTION':
            _fields(data, ('selected',))
            solved = _domains(model, data['selected'], [], m)
            _need(all(v == 1 for p, v in solved['totals']), 'recorded whole solution t/m')
        encoded = (_image(event, m) + '\n').encode('ascii')
        h.update(encoded)
        rawbytes += len(encoded)
    _need(extent['retained'] == len(result['events']) <= extent['count']
          and rawbytes <= extent['JSONL_bytes'], 'full retained-body count and byte extents')
    _need(extent['retained_complete'] is (extent['retained'] == extent['count']),
          'truthful retained-prefix flag')
    if extent['retained_complete']:
        _need(extent['JSONL_bytes'] == rawbytes and extent['SHA256'] == h.hexdigest(),
              'complete event body/hash exact equality')
    if normal:
        _need(extent['evaluation_complete'] is True, 'normal evaluation completion')
    else:
        _need(extent['evaluation_complete'] is False, 'UNKNOWN is incomplete evaluation')
    _need(type(result['rollback_records']) is list, 'complete rollback receipt array')
    for row in result['rollback_records']:
        _rollback(row, byid, normal, m)
    if normal:
        _need(result['rollback_records'] and result['rollback_records'][-1]['reason']
              == 'FINAL_MANDATORY_CLEANUP' and result['rollback_records'][-1]['to_trail'] == 0,
              'normal final mandatory trail0 receipt')
    stats_keys = ('operations', 'validation_items', 'required_points', 'candidates',
        'mark_assignments', 'mark_points', 'dependency_links', 'initial_edges', 'nodes',
        'forced_placements', 'branch_decisions', 'backtracks', 'scoped_exclusions',
        'deactivated_selected', 'candidate_eliminations_capacity', 'candidate_eliminations_mark',
        'candidate_eliminations_exclusion', 'dependency_visits', 'trail_writes', 'trail_undos',
        'max_trail', 'ordering_calls', 'ordering_prefix_items', 'ordering_changed_first',
        'certificate_checks', 'cleanup_operations', 'elapsed_seconds', 'events', 'retained_events')
    _fields(result['stats'], stats_keys)
    stats = result['stats']
    for key in stats_keys:
        value = stats[key]
        if key == 'elapsed_seconds':
            _need(type(value) in (int, float) and math.isfinite(value) and value >= 0,
                  'finite named native elapsed observation')
        else:
            _need(type(value) is int and value >= 0, 'exact native decision counter')
    _need(stats['events'] == extent['count'] and stats['retained_events'] == extent['retained'],
          'entire native event counter association')
    if normal:
        _need(stats['required_points'] == len(model['required'])
              and stats['candidates'] == len(byid)
              and stats['mark_assignments'] == sum(len(c['m']) for c in byid.values())
              and stats['mark_points'] == len({q for c in byid.values() for q, v in c['m']})
              and stats['initial_edges'] == len(byid), 'entire immutable model census')
        _need(stats['trail_writes'] == stats['trail_undos'], 'normal all recorded deltas reversed')
    return certificate


def verify_result(problem, bundle, result, *, limits=None, budget=None):
    def action(m):
        p, digest, roots, byid = _bundle(problem, bundle, m)
        _native_result(bundle['model'], result, m)
        cert = _selected(p, bundle, result['selected'], m) if result['status'] == 'SAT' else None
        return digest, {'complete_model_and_graphs': True, 'whole_SAT_proof_checked': cert is not None,
                        'UNSAT_scope': 'Reviewed producer exhaustion path only; no independent '
                        'UNSAT tree follows from a clipped event prefix. Tiny brute or '
                        'complete symbolic closure supplies separate negative evidence.'}, cert
    return _verification(action, limits, budget)


def _qualification_models():
    def candidate(cid, point, marks):
        return {'id': cid, 't': [point], 'm': marks}
    def model(required, rows):
        return {'required': required, 'candidates': rows}
    def binary_pair():
        return model(['p', 'q'], [candidate('A0', 'p', [['remote', '0']]),
               candidate('A1', 'p', [['remote', '1']]),
               candidate('B0', 'q', [['remote', '1']]),
               candidate('B1', 'q', [['remote', '1']])])
    def triangle():
        return model(['a', 'b', 'c'], [
          candidate('A0', 'a', [['ab', '0'], ['ca', '0']]),
          candidate('A1', 'a', [['ab', '1'], ['ca', '1']]),
          candidate('B0', 'b', [['ab', '0'], ['bc', '0']]),
          candidate('B1', 'b', [['ab', '1'], ['bc', '1']]),
          candidate('C0', 'c', [['bc', '0'], ['ca', '1']]),
          candidate('C1', 'c', [['bc', '1'], ['ca', '0']])])
    return [
      ('Q01-empty', model([], []), 'NORMAL'),
      ('Q02-late-dead', model(['a', 'z'], [candidate('A', 'a', [])]), 'NORMAL'),
      ('Q03-remote-zero', model(['a', 'b'], [candidate('A', 'a', [['outside', '0']]),
                                              candidate('B', 'b', [['outside', '0']])]), 'NORMAL'),
      ('Q04-remote-conflict', model(['a', 'b'], [candidate('A', 'a', [['outside', '0']]),
                                                  candidate('B', 'b', [['outside', '1']])]), 'NORMAL'),
      ('Q05-missing-zero', model(['p', 'q'], [candidate('A', 'p', []),
                          candidate('B', 'p', [['outside', '0']]),
                          candidate('C', 'q', [['outside', '1']])]), 'NORMAL'),
      ('Q06-inconsistent-self', model(['p'], [candidate('A', 'p', [['x', '0'], ['x', '1']])]), 'INPUT_ERROR'),
      ('Q07-shared-positive', model(['p', 'q'], [{'id': 'A', 't': ['p', 'q'], 'm': []}]), 'INPUT_ERROR'),
      ('Q08-duplicate-id', model(['p'], [candidate('A', 'p', []), candidate('A', 'p', [])]), 'INPUT_ERROR'),
      ('Q09-bool-mark', model(['p'], [candidate('A', 'p', [['x', True]])]), 'INPUT_ERROR'),
      ('Q10-failed-branch', binary_pair(), 'NORMAL'),
      ('Q11-closed-UNSAT', triangle(), 'NORMAL'),
      ('Q12-node-UNKNOWN', binary_pair(), 'NODE_ZERO'),
      ('Q13-event-prefix-zero', binary_pair(), 'EVENT_ZERO'),
      ('Q14-empty-order-fallback', binary_pair(), 'EMPTY_ORDER'),
      ('Q15-invalid-order', binary_pair(), 'ORDER_ERROR'),
      ('Q16-foreign-order', binary_pair(), 'FOREIGN'),
      ('Q17-preference', binary_pair(), 'PREFER'),
      ('Q18-MRV', model(['a', 'z'], [candidate('A0', 'a', []), candidate('A1', 'a', []),
          candidate('A2', 'a', []), candidate('Z0', 'z', []), candidate('Z1', 'z', [])]), 'NORMAL'),
      ('Q19-generation-tie', model(['a', 'z'], [candidate('A0', 'a', []), candidate('A1', 'a', []),
          candidate('Z0', 'z', []), candidate('Z1', 'z', [])]), 'NORMAL')]


def qualify(compiler, engine, emit):
    """23 fixed future controls. Module objects and emit are caller supplied."""
    _need(callable(emit), 'qualification emitter')
    limits = dict(DEFAULT_LIMITS)
    limits['wall_seconds'] = 30
    meter = _Meter(limits, None)
    records = []
    normal_reference = None
    calls = {'engine.solve': 0, 'compiler.compile_problem': 0}
    def output(name, full):
        meter.take()
        record = {'schema': 'L-S-independent-qualification-control-v1', 'id': name, **full}
        reference = emit(name, record)
        records.append({'id': name, 'emitter_return': reference})
    class ForeignOrder(Exception):
        pass
    for name, model, mode in _qualification_models():
        meter.take()
        lim = {'wall_seconds': 2, 'max_nodes': 0 if mode == 'NODE_ZERO' else 50000,
               'max_events': 0 if mode == 'EVENT_ZERO' else 64}
        before = _image(model, meter)
        order = None
        marker = ForeignOrder('authored independent order refusal')
        if mode == 'EMPTY_ORDER':
            order = lambda point, legal: []
        elif mode == 'PREFER':
            order = lambda point, legal: ['A1'] if 'A1' in legal else []
        elif mode == 'ORDER_ERROR':
            order = lambda point, legal: ['FOREIGN_CANDIDATE']
        elif mode == 'FOREIGN':
            def refuse(point, legal):
                raise marker
            order = refuse
        calls['engine.solve'] += 1
        caught = None
        result = None
        try:
            result = engine.solve(model, lim, order=order)
        except engine.InputError as error:
            _need(mode == 'INPUT_ERROR', 'only declared malformed input rejection')
            caught = {'type': type(error).__name__, 'message': str(error)}
        except engine.OrderingError as error:
            _need(mode == 'ORDER_ERROR', 'only declared ordering rejection')
            caught = {'type': type(error).__name__, 'message': str(error)}
        except ForeignOrder as error:
            _need(mode == 'FOREIGN' and error is marker, 'exact foreign order propagation')
            caught = {'type': type(error).__name__, 'message': str(error), 'same_instance': True}
        _need(before == _image(model, meter), 'producer did not mutate raw model')
        if mode in ('INPUT_ERROR', 'ORDER_ERROR', 'FOREIGN'):
            _need(caught is not None and result is None, 'expected complete exception, not ignored failure')
            output(name, {'kind': mode, 'model': model, 'limits': lim, 'exception': caught})
            continue
        _need(caught is None and result is not None, 'normal producer return present')
        _native_result(model, result, meter)
        brute = brute_tiny_model(model)
        _need(brute['status'] == 'COMPLETE', 'full independent tiny assignment set')
        hash_variants = None
        if mode == 'NODE_ZERO':
            _need(result['status'] == 'UNKNOWN', 'budget refusal remains UNKNOWN')
            _need(result['entry_state'] is not None and normal_reference is not None,
                  'actual prepared UNKNOWN and prior normal data for isolated hash controls')
            partial = json.loads(_image(result, meter))
            partial['state_hashes']['entry'] = None
            _native_result(model, partial, meter)
            normal_missing_hash = json.loads(_image(normal_reference, meter))
            normal_missing_hash['state_hashes']['entry'] = None
            refused = False
            try:
                _native_result(model, normal_missing_hash, meter)
            except VerificationError:
                refused = True
            _need(refused, 'normal observed state cannot lose required hash')
            hash_variants = {'UNKNOWN_with_observed_entry_and_null_hash': {
                'status': 'VERIFIED_DATA_ONLY_PROFILE', 'result': partial},
                'normal_with_observed_entry_and_null_hash': {
                'status': 'EXPECTED_REJECTED_FORGED_DATA', 'result': normal_missing_hash}}

        else:
            _need(result['status'] == ('SAT' if brute['solutions'] else 'UNSAT'),
                  'producer agrees with complete tiny finite relation')
            if result['status'] == 'SAT':
                _need(result['selected'] in brute['solutions'], 'actual SAT member of full tiny set')
        rejection_check = None
        if name == 'Q02-late-dead':
            _need(result['stats']['nodes'] == 1 and result['stats']['forced_placements']
                  == result['stats']['branch_decisions'] == 0,
                  'global later empty domain before available forced move')
            _need(result['events'] and result['events'][0]['kind'] == 'DEAD'
                  and result['events'][0]['data']['point'] == 'z', 'actual late-root DEAD event first')
        if name == 'Q05-missing-zero':
            _need(result['selected'] == ['A', 'C'], 'missing differs from explicitly assigned0')
        if name == 'Q10-failed-branch':
            normal_reference = result
            _need(result['stats']['backtracks'] > 0 and any(r['reason'] == 'COMPLETE_FAILED_CHILD'
                  for r in result['rollback_records']), 'actual failed child rollback path exercised')
            forged = json.loads(_image(result, meter))
            forged['restored_state']['totals'][0][1] = 1
            refused = False
            try:
                _native_result(model, forged, meter)
            except VerificationError:
                refused = True
            _need(refused, 'independent checker refuses corrupted rollback truth')
            rejection_check = {'status': 'EXPECTED_REJECTED_FORGED_DATA',
                               'kind': 'restored total changed without selected placement',
                               'forged_result': forged}
        if name == 'Q11-closed-UNSAT':
            _need(result['status'] == 'UNSAT' and result['stats']['backtracks'] > 0,
                  'complete nontrivial finite UNSAT rollback')
        if mode == 'EVENT_ZERO':
            _need(result['events'] == [] and result['event_extent']['count'] > 0
                  and result['event_extent']['retained_complete'] is False,
                  'clipped event observation is explicit, not clipped evaluation')
        if mode == 'PREFER':
            _need('A1' in result['selected'], 'preference chosen through complete fallback scheduler')
        if name in ('Q18-MRV', 'Q19-generation-tie'):
            branch = next(e for e in result['events'] if e['kind'] == 'BRANCH')
            _need(branch['data']['point'] == ('z' if name == 'Q18-MRV' else 'a'),
                  'MRV only within all-root0 generation, lexical tie')
        output(name, {'kind': mode, 'model': model, 'limits': lim,
                      'result': result, 'independent_exhaustion': brute,
                      'data_only_negative': rejection_check, 'data_only_hash_variants': hash_variants})
    atom_p, atom_q, atom_r = ['pred', 'P', []], ['pred', 'Q', []], ['pred', 'R', []]
    tiny = [('Q20-domain-one', {'hypotheses': {'a': atom_p, 'b': ['imp', atom_p, atom_q]},
                              'goal': atom_q, 'maxlines': 1}),
            ('Q21-domain-two', {'hypotheses': {'a': atom_p, 'b': ['imp', atom_p, atom_q]},
                              'goal': atom_q, 'maxlines': 2}),
            ('Q22-domain-three', {'hypotheses': {'a': atom_p, 'b': ['imp', atom_p, atom_q]},
                                'goal': atom_q, 'maxlines': 3}),
            ('Q23-implication-premise', {'hypotheses': {
                'a': ['imp', atom_p, atom_q], 'b': ['imp', ['imp', atom_p, atom_q], atom_r]},
                'goal': atom_r, 'maxlines': 3})]
    for name, problem in tiny:
        meter.take()
        cl = {'wall_seconds': 2, 'max_candidates': 50000, 'max_work': 10000000, 'max_depth': 128}
        calls['compiler.compile_problem'] += 1
        bundle = compiler.compile_problem(problem['hypotheses'], problem['goal'], problem['maxlines'], cl)
        checked = verify_bundle(problem, bundle)
        _need(checked['status'] == 'VERIFIED', 'complete independent compilation universe')
        lim = {'wall_seconds': 2, 'max_nodes': 50000, 'max_events': 64}
        calls['engine.solve'] += 1
        result = engine.solve(bundle['model'], lim)
        checked_result = verify_result(problem, bundle, result)
        brute = brute_tiny_model(bundle['model'])
        _need(checked_result['status'] == 'VERIFIED' and brute['status'] == 'COMPLETE',
              'full tiny model state/proof and brute checks')
        _need(result['status'] == ('SAT' if brute['solutions'] else 'UNSAT'),
              'complete tiny proof-tiling equivalence')
        incomplete = None
        if name == 'Q22-domain-three':
            incomplete = json.loads(_image(bundle, meter))
            incomplete['model']['candidates'].pop(0)
            refused = verify_bundle(problem, incomplete)
            _need(refused['status'] == 'REJECTED', 'independent checker refuses incomplete universe')
            incomplete = {'forged_bundle': incomplete, 'independent_rejection': refused}
        conventional = mp_closure(problem)
        _need(conventional['status'] == ('UNKNOWN_BOUND' if problem['maxlines'] < 3 else 'DERIVABLE'),
              'closure certificate length is not false bounded UNSAT')
        output(name, {'kind': 'COMPILED_TINY', 'problem': problem, 'bundle': bundle,
              'compilation_limits': cl, 'limits': lim, 'result': result,
              'independent_bundle': checked, 'independent_result': checked_result,
              'independent_exhaustion': brute, 'conventional': conventional,
              'data_only_universe_negative': incomplete})
    negative = mp_closure({'hypotheses': {'a': ['imp', atom_p, atom_q]},
                          'goal': atom_q, 'maxlines': 3})
    _need(negative['status'] == 'NOT_DERIVABLE' and negative['proof'] is None,
          'complete symbolic nonreachability control')
    _need(len(records) == 23 and calls == {'engine.solve': 23, 'compiler.compile_problem': 4},
          'closed23 qualification call census')
    meter.take()
    return {'schema': 'L-S-independent-qualification-result-v1', 'status': 'PASS',
            'version': VERSION, 'records': records, 'controls': 23, 'public_calls': calls,
            'conventional_calls': 5, 'costs': meter.costs(),
            'supplementary_negative_closure': negative,
            'scope': 'Authored unit-root finite controls only. Fractional t, shared positive support, '
                     'dynamic generations/growth and general tiler claims excluded. '
                     'All controls execute only within a future explicit Root authority.'}
