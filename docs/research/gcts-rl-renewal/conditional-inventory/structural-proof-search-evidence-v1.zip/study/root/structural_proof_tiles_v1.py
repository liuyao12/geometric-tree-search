"""Finite proof-row families: GIVEN hypotheses and modus ponens, no proof hints.

This is a bounded symbolic point-tile compilation, NOT a fixed literal Wang
palette. Each row has one unit occupancy root. Output and premise receptors
are exact formula-valued marks outside the occupancy domain. Every rule and
earlier-line reference is enumerated before any search. No proof is generated
here; decoding a selected tiling yields an UNVERIFIED certificate.
"""
import json
import time

VERSION = 'S-STRUCTURAL-PROOF-TILES-v1'


class InputError(Exception):
    pass


class BudgetExceeded(Exception):
    pass


def canonical(value):
    return json.dumps(value, ensure_ascii=True, sort_keys=True,
                      separators=(',', ':'))


class Budget:
    def __init__(self, limits):
        self.start = time.perf_counter()
        if type(limits) is not dict or set(limits) != {
                'wall_seconds', 'max_candidates', 'max_work', 'max_depth'}:
            raise InputError('exact compilation limits')
        if (type(limits['wall_seconds']) not in (int, float)
                or not 0 < limits['wall_seconds'] <= 60):
            raise InputError('positive finite wall_seconds at most60')
        for name in ('max_candidates', 'max_work', 'max_depth'):
            if type(limits[name]) is not int or not 0 <= limits[name] <= 10000000:
                raise InputError('bounded nonnegative integer limits')
        self.limits = dict(limits)
        self.work = 0
        self.candidates = 0

    def tick(self, amount=1):
        self.work += amount
        if self.work > self.limits['max_work']:
            raise BudgetExceeded('compilation work')
        if time.perf_counter() - self.start >= self.limits['wall_seconds']:
            raise BudgetExceeded('compilation wall')


def validate_formula(formula, budget, catalog, active, depth=0):
    budget.tick()
    if depth > budget.limits['max_depth']:
        raise BudgetExceeded('formula depth')
    if type(formula) is not list or not formula:
        raise InputError('formula list')
    if type(formula[0]) is not str:
        raise InputError('native formula tag')
    if id(formula) in active:
        raise InputError('cyclic formula')
    active.add(id(formula))
    try:
        if formula[0] == 'pred':
            if (len(formula) != 3 or type(formula[1]) is not str
                    or not formula[1] or len(formula[1]) > 64
                    or not formula[1].isascii() or formula[2] != []
                    or type(formula[2]) is not list):
                raise InputError('zeroarity ASCII predicate')
            result = ['pred', formula[1], []]
        elif formula[0] == 'imp' and len(formula) == 3:
            result = ['imp',
                      validate_formula(formula[1], budget, catalog, active, depth + 1),
                      validate_formula(formula[2], budget, catalog, active, depth + 1)]
        else:
            raise InputError('implicational fragment only')
        key = canonical(result)
        budget.tick(len(key))
        catalog[key] = result
        return result
    finally:
        active.remove(id(formula))


def compile_problem(hypotheses, goal, slots, limits):
    """Return complete finite candidate universe; exceptions mean no result.

    A solution is an exactly slots-long hypothesis/MP proof ending at goal.
    Repeated hypothesis rows permit padding shorter proofs when hypotheses
    exist. All slots are explicitly activated generation-zero roots. Absolute
    root IDs identify anchored translations; rotations/reflections absent.
    """
    budget = Budget(limits)
    budget.tick()
    if (type(hypotheses) is not dict or len(hypotheses) > 256
            or any(type(k) is not str or not k or len(k) > 64
                   or not k.isascii() for k in hypotheses)):
        raise InputError('bounded named hypotheses')
    if type(slots) is not int or not 1 <= slots <= 32:
        raise InputError('slots1..32')
    catalog = {}
    normalized = {name: validate_formula(hypotheses[name], budget, catalog, set())
                  for name in sorted(hypotheses)}
    target = validate_formula(goal, budget, catalog, set())
    formulas = [catalog[key] for key in sorted(catalog)]
    implications = [(index, value) for index, value in enumerate(formulas)
                    if value[0] == 'imp']
    required = ['slot:' + str(i) for i in range(slots)]
    candidates, steps = [], {}

    def add(slot, identity, line, marks):
        budget.tick(len(marks) + 1)
        if slot == slots - 1 and line['formula'] != target:
            return
        # An internally inconsistent placement is never a tile in the model.
        merged = {}
        for point, value in marks:
            if point in merged and merged[point] != value:
                return
            merged[point] = value
        budget.candidates += 1
        if budget.candidates > budget.limits['max_candidates']:
            raise BudgetExceeded('complete candidate universe exceeds cap')
        candidates.append({'id': identity, 't': [required[slot]],
                           'm': [[p, merged[p]] for p in sorted(merged)]})
        steps[identity] = {'slot': slot, 'line': line}

    for slot in range(slots):
        output = 'out:' + str(slot)
        for index, (name, formula) in enumerate(normalized.items()):
            budget.tick()
            add(slot, 'r' + str(slot) + ':h' + str(index),
                {'rule': 'axiom', 'name': name, 'formula': formula},
                [(output, canonical(formula))])
        for index, formula in implications:
            antecedent, conclusion = formula[1:]
            a_key, i_key, c_key = map(canonical,
                                     (antecedent, formula, conclusion))
            budget.tick(len(a_key) + len(i_key) + len(c_key))
            for a in range(slot):
                for b in range(slot):
                    budget.tick()
                    add(slot, 'r' + str(slot) + ':mp' + str(index)
                        + ':' + str(a) + ':' + str(b),
                        {'rule': 'mp', 'formula': conclusion,
                         'antecedent': a, 'implication': b},
                        [(output, c_key), ('out:' + str(a), a_key),
                         ('out:' + str(b), i_key)])
    budget.tick()
    return {'schema': 'S-finite-structural-proof-model-v1', 'version': VERSION,
            'hypotheses': normalized, 'goal': target, 'slots': slots,
            'formula_catalog': formulas,
            'model': {'required': required, 'candidates': candidates},
            'steps': steps,
            'compilation': {'work': budget.work, 'candidates': budget.candidates,
                            'wall_seconds': time.perf_counter() - budget.start},
            'scope': 'Complete bounded hypothesis/MP fragment. No supplied proof, '
                     'no target-specific rule path, no fixed universal Wang palette.'}


def decode_selected(bundle, selected):
    """Pure representation decoding; output does not assert validity."""
    if type(selected) is not list or any(type(x) is not str for x in selected):
        raise InputError('selected candidate ids')
    if len(selected) != bundle['slots'] or len(set(selected)) != len(selected):
        raise InputError('one distinct candidate per slot')
    rows = {}
    for identity in selected:
        if identity not in bundle['steps']:
            raise InputError('unknown candidate')
        record = bundle['steps'][identity]
        if record['slot'] in rows:
            raise InputError('duplicate slot')
        rows[record['slot']] = record['line']
    if set(rows) != set(range(bundle['slots'])):
        raise InputError('missing slot')
    # JSON roundtrip detaches returned data from the model/metadata containers.
    return json.loads(canonical({'status': 'UNVERIFIED_CERTIFICATE',
                                 'proof': [rows[i] for i in range(bundle['slots'])],
                                 'target': bundle['goal']}))
