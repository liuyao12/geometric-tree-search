"""Closed S worker and owned observer. Inert until a fresh exact once grant.

Only pinned retained Source bytes execute. All outcomes and complete proof
checks are retained. The supervisor owns one child, its streams and wait4;
timeouts/refusals never become mathematical negatives. No network or Git.
"""
import argparse
import gzip
import hashlib
import json
import os
from pathlib import Path
import resource
import selectors
import signal
import subprocess
import sys
import time
import types

ROOT = Path('/private/tmp/gcts-proof-structure-20261028-v1')
PYTHON = '/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12'
ROLES = {'runner', 'compiler', 'engine', 'independent', 'tree_machine',
         'codec', 'carrier', 'fol_checker', 'real_parser'}


def require(ok, reason):
    if not ok:
        raise RuntimeError(reason)


def raw_json(value):
    return (json.dumps(value, ensure_ascii=True, sort_keys=True,
                       separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')


def raw_ref(path, raw):
    return {'path': str(path), 'bytes': len(raw),
            'sha256': hashlib.sha256(raw).hexdigest()}


def read_ref(ref, maximum=1048576):
    require(type(ref) is dict and set(ref) == {'path', 'bytes', 'sha256'}, 'raw ref')
    path = Path(ref['path'])
    require(path.is_absolute() and not path.is_symlink(), 'regular absolute path')
    require(type(ref['bytes']) is int and 0 <= ref['bytes'] <= maximum, 'raw length bound')
    with path.open('rb') as f:
        data = f.read(ref['bytes'] + 1)
    require(raw_ref(path, data) == ref, 'whole raw association')
    return data


def put(path, raw):
    with path.open('xb') as f:
        f.write(raw)
        f.flush()
        os.fsync(f.fileno())
    require(path.read_bytes() == raw, 'whole written bytes')
    return raw_ref(path, raw)


def load_plan(path):
    raw = Path(path).read_bytes()
    plan = json.loads(raw)
    require(set(plan) == {'schema', 'sources', 'metadata', 'python', 'bootstrap',
                          'actual_dir', 'limits'}, 'exact plan')
    require(plan['schema'] == 'S-structural-proof-once-plan-v1', 'plan schema')
    require(set(plan['sources']) == ROLES, 'closed Source roles')
    require(Path(plan['actual_dir']) == ROOT / 'actual' / 'study-001', 'owned output')
    require(plan['sources']['runner']['path'] == __file__, 'runner location')
    require(sys.executable == PYTHON and sys.flags.isolated and sys.flags.no_site
            and sys.dont_write_bytecode, 'isolated D90')
    require(plan['limits'] == {'worker_seconds': 120, 'observer_seconds': 150,
            'rss_bytes': 1073741824, 'file_bytes': 8388608,
            'total_bytes': 134217728, 'max_files': 192,
            'stream_bytes': 1048576}, 'fixed process and artifact profile')
    retained = {k: read_ref(v) for k, v in plan['sources'].items()}
    metadata = {k: read_ref(v) for k, v in plan['metadata'].items()}
    read_ref(plan['python'], 33554432)
    read_ref(plan['bootstrap'])
    return plan, raw, retained, metadata


def worker(plan_path):
    started = time.perf_counter()
    plan, plan_raw, sources, metadata = load_plan(plan_path)
    directory = Path(plan['actual_dir'])
    require((directory / 'CONSUMED.json').is_file(), 'once consumed before execution')
    artifacts, total_bytes, calls = [], 0, {}

    def budget():
        require(time.perf_counter() - started < 120, 'whole worker sampled wall')
        require(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss <= 1073741824,
                'whole worker sampled RSS bytes on Darwin')

    def emit(name, data):
        nonlocal total_bytes
        budget()
        require(type(name) is str and name and all(c.isalnum() or c in '-.'
                for c in name) and name.isascii(), 'artifact name')
        require(len(artifacts) < 184, 'artifact count')
        raw = raw_json(data)
        require(len(raw) <= 8388608, 'full artifact raw cap')
        compressed = len(raw) > 65536
        stored = gzip.compress(raw, mtime=0) if compressed else raw
        total_bytes += len(stored)
        require(total_bytes <= 125829120, 'whole artifact stored cap')
        path = directory / (name + ('.json.gz' if compressed else '.json'))
        ref = put(path, stored)
        require((gzip.decompress(stored) if compressed else stored) == raw,
                'lossless complete artifact')
        answer = {'name': name, 'stored': ref, 'encoding': 'gzip-json' if compressed else 'json',
                  'raw_bytes': len(raw), 'raw_sha256': hashlib.sha256(raw).hexdigest()}
        artifacts.append(answer)
        return answer

    modules = {}
    for role in sorted(ROLES - {'runner', 'real_parser'}):
        budget()
        module = types.ModuleType('S_' + role)
        module.__file__ = plan['sources'][role]['path']
        exec(compile(sources[role], module.__file__, 'exec', dont_inherit=True), module.__dict__)
        modules[role] = module

    def call(role, name, *args, **kwargs):
        budget()
        key = role + '.' + name
        calls[key] = calls.get(key, 0) + 1
        require(calls[key] <= 256, 'public outer entry cap')
        value = getattr(modules[role], name)(*args, **kwargs)
        budget()
        return value

    tm = modules['tree_machine']
    cold = time.perf_counter()
    compiler = call('tree_machine', 'Compiler', sources['real_parser'].decode('utf-8'))
    program = compiler.declaration()
    call('tree_machine', 'validate', program)
    emit('fixed-native-program', program)
    native_preparation_seconds = time.perf_counter() - cold
    qualification = call('independent', 'qualify', modules['compiler'], modules['engine'],
                         lambda name, data: emit('qualification-' + name, data))
    emit('whole-qualification', qualification)
    require(qualification['status'] == 'PASS', 'whole qualification gate')
    problems = json.loads(metadata['cases'])
    design = json.loads(metadata['benchmark_design'])
    require(type(problems) is dict and len(problems) == 13, 'closed13 cases')
    families = {}
    for family, names in design['groups'].items():
        for name in names:
            require(name not in families, 'one declared family per case')
            families[name] = family
    require(set(families) == set(problems), 'all benchmark metadata joins')
    cases = [{'id': name, 'family': families[name], 'problem': problems[name]}
             for name in sorted(problems)]
    limits = json.loads(metadata['experiment_limits'])
    output = []

    def checked_proof(case_id, lane, problem, proof):
        t = time.perf_counter()
        atoms = set()
        def collect(f):
            if f[0] == 'pred':
                atoms.add(f[1])
            else:
                collect(f[1]); collect(f[2])
        for f in list(problem['hypotheses'].values()) + [problem['goal']]:
            collect(f)
        theory = {'functions': {}, 'predicates': {a: 0 for a in sorted(atoms)},
                  'axioms': problem['hypotheses']}
        encode = call('codec', 'encode', proof, limits['codec'])
        require(encode['status'] == 'COMPLETE', 'proof codec encode')
        stream = bytes.fromhex(encode['stream_hex'])
        decode = call('codec', 'decode', stream, limits['codec'])
        require(decode['status'] == 'COMPLETE' and decode['proof'] == proof,
                'exact independent byte roundtrip')
        carrier = call('carrier', 'build_carrier', program, dict(theory, schemas=[]),
                       problem['goal'], len(stream), limits['carrier'], budget=budget)
        nodes = [list(n) for n in carrier['value']['nodes']]
        for row in carrier['value']['byte_rows']:
            nodes[row['node_index']][0] = stream[row['byte_index']]
        choice = call('carrier', 'verify_carrier_choice', carrier, nodes,
                      carrier['value']['input_node'], budget=budget)
        require(choice['status'] == 'VERIFIED' and choice['byte_values'] == list(stream),
                'whole chosen byte carrier')
        heap = call('tree_machine', 'Heap', nodes, limit=limits['native']['max_heap_nodes'])
        native = call('tree_machine', 'run', program, heap, carrier['value']['input_node'],
                      limit=limits['native']['max_steps'], keep=limits['native']['max_trace_records'])
        independent = call('fol_checker', 'check', theory, decode['proof'],
                           problem['goal'], limits['checker'])
        accepted = (native.get('status') == 'accepted' and type(native.get('value')) is int
                    and native['value'] == 1 and independent['status'] == 'VERIFIED')
        record = {'status': 'VERIFIED' if accepted else 'UNADMITTED_CHECKER_OUTCOME',
                  'theory': theory, 'goal': problem['goal'], 'proof': proof,
                  'encoding': encode, 'decoding': decode, 'carrier': carrier,
                  'initial_nodes': nodes, 'choice': choice, 'native': native,
                  'final_heap': heap.nodes, 'independent': independent,
                  'seconds': time.perf_counter() - t}
        emit(case_id + '-' + lane + '-whole-proof-check', record)
        return {'status': record['status'], 'seconds': record['seconds'],
                'proof_lines': len(proof), 'proof_bytes': len(stream),
                'native_status': native.get('status'), 'native_value': native.get('value'),
                'native_steps': native.get('steps'), 'independent': independent}

    for case in cases:
        require(type(case) is dict and set(case) == {'id', 'family', 'problem'}, 'case wire')
        identity, problem = case['id'], case['problem']
        point_started = time.perf_counter()
        point = {'status': 'UNKNOWN_COMPILATION', 'selected': None, 'proof': None}
        bundle = answer = None
        try:
            cl = dict(limits['compilation'], wall_seconds=limits['lane_wall_seconds'])
            bundle = call('compiler', 'compile_problem', problem['hypotheses'],
                          problem['goal'], problem['maxlines'], cl)
            remaining = limits['lane_wall_seconds'] - (time.perf_counter() - point_started)
            if remaining > 0:
                answer = call('engine', 'solve', bundle['model'],
                              dict(limits['point'], wall_seconds=remaining))
                point.update(status=answer['status'], selected=answer['selected'],
                             stats=answer['stats'])
        except modules['compiler'].BudgetExceeded as error:
            point['reason'] = str(error)
        point['search_seconds_inclusive'] = time.perf_counter() - point_started
        audit_started = time.perf_counter()
        if bundle is not None:
            emit(identity + '-complete-point-model', bundle)
            join = call('independent', 'verify_bundle', problem, bundle)
            require(join['status'] == 'VERIFIED', 'whole independent candidate universe')
            emit(identity + '-independent-model', join)
        if answer is not None:
            emit(identity + '-point-solve', answer)
            if answer['status'] == 'SAT':
                verified = call('independent', 'verify_selected', problem, bundle,
                                answer['selected'])
                require(verified['status'] == 'VERIFIED', 'whole selected tiling/proof')
                emit(identity + '-independent-tiling', verified)
                decoded = call('compiler', 'decode_selected', bundle, answer['selected'])
                point['proof'] = decoded['proof']
        point['audit_and_storage_seconds'] = time.perf_counter() - audit_started
        conventional_started = time.perf_counter()
        conventional = call('independent', 'mp_closure', problem,
                            wall_seconds=limits['lane_wall_seconds'])
        conventional['search_seconds_inclusive'] = time.perf_counter() - conventional_started
        emit(identity + '-conventional-closure', conventional)
        # Alternate validation order across cases; search never consumes any
        # generated control proof, final certificate, or future case result.
        lanes = [('point', point), ('conventional', conventional)]
        if len(output) % 2:
            lanes.reverse()
        for lane, result in lanes:
            proof = result.get('proof')
            if proof is not None:
                require(len(proof) <= problem['maxlines'], 'equal certificate line cap')
                result['checking'] = checked_proof(identity, lane, problem, proof)
        output.append({'id': identity, 'family': case['family'], 'problem': problem,
                       'point': point, 'conventional': conventional})
        emit(identity + '-result', output[-1])
    result = {'schema': 'S-structural-proof-study-result-v1', 'results': output,
              'qualification': qualification, 'native_preparation_seconds': native_preparation_seconds,
              'outer_public_calls': calls, 'artifacts': list(artifacts),
              'scope': 'Unknown axiom/MP structure and earlier references in bounded implication fragment. '
                       'Point search includes representation construction; independent domain audit '
                       'and storage are separately timed. '
                       'conventional closure uses the same input and line/wall caps. All checks separately '
                       'reported. No trained RL, fixed literal Wang FOL proof, arithmetic induction, '
                       'full Hilbert geometry, optimized ATP comparison or superiority claim.'}
    result_ref = emit('worker-result', result)
    for role, ref in plan['sources'].items():
        require(read_ref(ref) == sources[role], 'post Source guard')
    for role, ref in plan['metadata'].items():
        require(read_ref(ref) == metadata[role], 'post data guard')
    budget()
    terminal = {'status': 'COMPLETE', 'result': result_ref,
                'plan': raw_ref(plan_path, plan_raw), 'public_calls': calls,
                'elapsed_seconds': time.perf_counter() - started,
                'self_lifetime_peak_bytes': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                'scope': 'Scientific admission still requires owned original exit and complete peer review.'}
    sys.stdout.buffer.write(raw_json(terminal)); sys.stdout.buffer.flush()
    return 0


def observer(plan_path, authority_path):
    started = time.perf_counter()
    plan, plan_raw, sources, metadata = load_plan(plan_path)
    authority_raw = Path(authority_path).read_bytes()
    authority = json.loads(authority_raw)
    expected = {'schema': 'S-structural-proof-once-authority-v1', 'uses': 1,
                'authorized': True, 'plan': raw_ref(plan_path, plan_raw),
                'runner': plan['sources']['runner'], 'python': plan['python']}
    require(authority == expected, 'exact fresh Root once')
    directory = Path(plan['actual_dir'])
    require(not directory.exists() and not directory.is_symlink(), 'fresh output directory')
    consumed = Path(str(authority_path) + '.CONSUMED.json')
    put(consumed, raw_json({'authority': raw_ref(authority_path, authority_raw),
                            'plan': raw_ref(plan_path, plan_raw), 'status': 'SPENT'}))
    directory.mkdir(parents=True)
    put(directory / 'CONSUMED.json', raw_json({'authority': raw_ref(authority_path, authority_raw),
                                               'consumed': raw_ref(consumed, consumed.read_bytes())}))
    command = [PYTHON, '-I', '-S', '-B', plan['bootstrap']['path'],
               plan['sources']['runner']['path'], str(len(sources['runner'])),
               plan['sources']['runner']['sha256'], '--mode', 'worker', '--plan', str(plan_path)]
    child = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                             stderr=subprocess.PIPE, cwd=ROOT / 'root', start_new_session=True)
    captured = {'stdout': bytearray(), 'stderr': bytearray()}
    selector = selectors.DefaultSelector()
    wait_status = usage = None
    failure = None
    try:
        child.stdin.write(sources['runner']); child.stdin.close()
        for name, stream in [('stdout', child.stdout), ('stderr', child.stderr)]:
            os.set_blocking(stream.fileno(), False)
            selector.register(stream, selectors.EVENT_READ, name)
        while wait_status is None or selector.get_map():
            if time.perf_counter() - started > 150 and failure is None:
                failure = 'OBSERVER_WALL_TIMEOUT'
                os.killpg(child.pid, signal.SIGKILL)
            for key, _ in selector.select(timeout=0.05):
                block = os.read(key.fileobj.fileno(), 65536)
                if not block:
                    selector.unregister(key.fileobj); key.fileobj.close()
                else:
                    captured[key.data].extend(block)
                    if len(captured[key.data]) > 1048576 and failure is None:
                        failure = 'STREAM_CAP'
                        os.killpg(child.pid, signal.SIGKILL)
            if wait_status is None:
                pid, status, ru = os.wait4(child.pid, os.WNOHANG)
                if pid:
                    wait_status, usage = status, ru
                    child.returncode = os.waitstatus_to_exitcode(status)
    finally:
        if wait_status is None:
            try:
                os.killpg(child.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            _, wait_status, usage = os.wait4(child.pid, 0)
            child.returncode = os.waitstatus_to_exitcode(wait_status)
        both_eof = not selector.get_map()
        selector.close()
        child.stdout.close(); child.stderr.close()
    streams = {k: put(directory / (k + '.bin'), bytes(v)) for k, v in captured.items()}
    terminal = None
    if child.returncode == 0 and not failure and not captured['stderr']:
        terminal = json.loads(captured['stdout'])
        require(terminal['status'] == 'COMPLETE', 'whole worker terminal')
        read_ref(terminal['result']['stored'], 8388608)
    files = []
    total = 0
    for p in sorted(directory.iterdir()):
        require(p.is_file() and not p.is_symlink(), 'closed regular output')
        raw = p.read_bytes(); total += len(raw)
        require(len(raw) <= 8388608 and total <= 134217728, 'whole readback ceilings')
        files.append(raw_ref(p, raw))
    require(len(files) <= 191, 'whole output count')
    for role, ref in plan['sources'].items():
        require(read_ref(ref) == sources[role], 'observer post Source guard')
    for role, ref in plan['metadata'].items():
        require(read_ref(ref) == metadata[role], 'observer post data guard')
    outcome = {'schema': 'S-owned-observer-result-v1',
               'status': 'COMPLETE' if terminal is not None else 'UNADMITTED',
               'child_pid': child.pid, 'command': command, 'returncode': child.returncode,
               'failure': failure, 'both_streams_EOF': both_eof,
               'streams': streams, 'worker_terminal': terminal, 'files': files,
               'stored_bytes': total, 'wait4_peak_bytes': usage.ru_maxrss,
               'whole_observer_seconds': time.perf_counter() - started,
               'scope': 'One fresh child. wait4 lifetime RSS on Darwin; no hard RAM quota. '
                        'Timeout uses owned process group. Worker native steps/heaps and '
                        'cooperative wall checks are distinct from observer wall.'}
    receipt = put(directory / 'observer-result.json', raw_json(outcome))
    sys.stdout.buffer.write(raw_json({'status': outcome['status'], 'receipt': receipt}))
    sys.stdout.buffer.flush()
    return 0 if terminal is not None else 1


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', choices=('worker', 'observer'), required=True)
    parser.add_argument('--plan', required=True)
    parser.add_argument('--authority')
    args = parser.parse_args()
    if args.mode == 'worker':
        require(args.authority is None, 'worker has no authority path')
        return worker(args.plan)
    require(args.authority is not None, 'observer needs once authority')
    return observer(args.plan, args.authority)


if __name__ == '__main__':
    raise SystemExit(main())
