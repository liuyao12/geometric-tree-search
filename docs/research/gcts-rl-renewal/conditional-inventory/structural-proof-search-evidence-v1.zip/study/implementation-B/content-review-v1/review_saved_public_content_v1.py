"""Passive stored-data/content joins only; no project imports or evaluation."""
from pathlib import Path
import gzip
import hashlib
from html.parser import HTMLParser
import json
import re

S = Path('/private/tmp/gcts-proof-structure-20261028-v1')
A = S / 'actual/study-001'
D = S / 'root/report-draft'
OUT = S / 'implementation-B/content-review-v1'
def sha(b):
    return hashlib.sha256(b).hexdigest()
def pin(p):
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': sha(b)}
def load(b):
    def pairs(rows):
        d = {}
        for k, v in rows:
            assert k not in d
            d[k] = v
        return d
    return json.loads(b, object_pairs_hook=pairs, parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))
def artifact(ref):
    p = Path(ref['stored']['path'])
    assert p.parent == A
    b = p.read_bytes()
    assert len(b) == ref['stored']['bytes'] and sha(b) == ref['stored']['sha256']
    raw = gzip.decompress(b) if ref['encoding'] == 'gzip-json' else b
    assert ref['encoding'] in ('json', 'gzip-json')
    assert len(raw) == ref['raw_bytes'] and sha(raw) == ref['raw_sha256']
    return load(raw)
def compact(v):
    return json.dumps(v, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False)

htmlpath = D / 'structural-proof-search-v1.html'
jsonpath = D / 'structural-proof-search-results-v1.json'
html = htmlpath.read_bytes()
public_bytes = jsonpath.read_bytes()
public = load(public_bytes)
embedded = re.findall(rb'<script id="study-data" type="application/json">(.*?)</script>', html, re.S)
assert len(embedded) == 1 and embedded[0] == public_bytes
worker = artifact(public['provenance']['worker_result'])
observer_path = A / 'observer-result.json'
observer_bytes = observer_path.read_bytes()
observer = load(observer_bytes)
assert sha(observer_bytes) == public['provenance']['observer_sha256']
assert observer['status'] == 'COMPLETE' and observer['returncode'] == 0
assert observer['both_streams_EOF'] and observer['wait_confirmed'] and observer['group_gone']
assert observer['failure'] is None and observer['cleanup_errors'] == []
assert observer['wait4_peak_bytes'] == 56442880
assert round(observer['whole_observer_seconds'], 3) == 15.027
assert worker['qualification']['status'] == 'PASS' and worker['qualification']['controls'] == 23

# Read every original physical actual file; no helper or scientific re-evaluation.
physical = sorted(A.iterdir())
assert len(physical) == 125 and all(p.is_file() for p in physical)
physical_pins = [pin(p) for p in physical]
for ref in observer['files']:
    assert pin(Path(ref['path'])) == ref
artifacts = {x['name']: x for x in worker['artifacts']}
assert len(artifacts) == len(worker['artifacts']) == 120
decoded = {name: artifact(ref) for name, ref in artifacts.items()}
assert len(public['results']) == len(worker['results']) == 13

rows = []
successful_point = successful_conventional = unknown = nonreach = native_count = 0
selected_tile_count = 0
for pub, original in zip(public['results'], worker['results'], strict=True):
    case = pub['id']
    assert pub['id'] == original['id']
    assert pub['family'] == original['family'] and pub['problem'] == original['problem']
    assert decoded[case + '-result'] == original
    assert pub['conventional'] == original['conventional']
    for k, v in original['point'].items():
        assert pub['point'][k] == v
    assert set(pub) == set(original) | {'formula_catalog'}
    assert set(pub['point']) == set(original['point']) | {'model_counts', 'model_evidence', 'solve_evidence', 'selected_tiles'}
    assert pub['point']['model_evidence'] == artifacts[case + '-complete-point-model']
    assert pub['point']['solve_evidence'] == artifacts[case + '-point-solve']
    bundle = decoded[case + '-complete-point-model']
    model = bundle['model']
    assert pub['formula_catalog'] == bundle['formula_catalog']
    assert pub['point']['model_counts'] == {'candidates': len(model['candidates']), 'required': len(model['required']), 'mark_assignments': sum(len(x['m']) for x in model['candidates'])}
    by_id = {x['id']: x for x in model['candidates']}
    assert len(by_id) == len(model['candidates'])
    selected = pub['point']['selected'] or []
    expected_tiles = [by_id[x] for x in selected]
    assert pub['point']['selected_tiles'] == (expected_tiles if pub['point']['selected'] is not None else None)
    solve = decoded[case + '-point-solve']
    assert solve['status'] == pub['point']['status']
    assert solve['selected'] == pub['point']['selected'] and solve['stats'] == pub['point']['stats']
    assert pub['conventional']['search_seconds_inclusive'] < pub['point']['search_seconds_inclusive']
    selected_tile_count += len(selected)
    if pub['point']['status'] == 'SAT':
        successful_point += 1
        assert len(selected) == len(pub['point']['proof']) == pub['problem']['maxlines']
        assert [x['t'] for x in expected_tiles] == [['slot:' + str(i)] for i in range(len(selected))]
        # Data-only formula/port joins, not another proof checker invocation.
        for i, (tile, line) in enumerate(zip(expected_tiles, pub['point']['proof'], strict=True)):
            assert tile == by_id[selected[i]]
            assert load(dict(tile['m'])['out:' + str(i)]) == line['formula']
            for q, value in tile['m']:
                j = int(q.split(':')[1])
                assert 0 <= j <= i and value == compact(pub['point']['proof'][j]['formula'])
            if line['rule'] == 'mp':
                assert set(q for q, _ in tile['m']) == {'out:' + str(i), 'out:' + str(line['antecedent']), 'out:' + str(line['implication'])}
            else:
                assert line['rule'] == 'axiom' and tile['m'] == [['out:' + str(i), compact(line['formula'])]]
    else:
        assert pub['point']['status'] == 'UNKNOWN'
        unknown += 1
        assert pub['point']['proof'] is None and selected == [] and expected_tiles == []
        assert 'checking' not in pub['point'] and solve['reason'] == 'WALL_SECONDS'
    if pub['conventional']['status'] == 'DERIVABLE':
        successful_conventional += 1
    else:
        assert pub['conventional']['status'] == 'NOT_DERIVABLE'
        nonreach += 1
        assert pub['conventional']['proof'] is None and 'checking' not in pub['conventional']
    lane_checks = []
    for lane in ('point', 'conventional'):
        z = pub[lane]
        if not z.get('proof'):
            continue
        checks = decoded[case + '-' + lane + '-whole-proof-check']
        assert checks['status'] == z['checking']['status'] == 'VERIFIED'
        assert checks['proof'] == z['proof'] and checks['goal'] == pub['problem']['goal']
        assert checks['native']['status'] == z['checking']['native_status'] == 'accepted'
        assert checks['native']['value'] == z['checking']['native_value'] == 1
        assert checks['native']['steps'] == z['checking']['native_steps']
        assert checks['independent'] == z['checking']['independent']
        assert checks['independent']['status'] == 'VERIFIED'
        assert checks['independent']['checked_lines'] == len(z['proof']) == z['checking']['proof_lines']
        assert checks['decoding']['proof'] == z['proof']
        assert len(checks['native']['trace']) <= 8
        assert re.fullmatch('[0-9a-f]{64}', checks['native']['event_sha256'])
        native_count += 1
        lane_checks.append({'lane': lane, 'proof_lines': len(z['proof']), 'native_value': 1, 'native_steps': checks['native']['steps'], 'whole_check': artifacts[case + '-' + lane + '-whole-proof-check']})
    rows.append({'id': case, 'family': pub['family'], 'line_cap': pub['problem']['maxlines'],
                 'point': pub['point']['status'], 'conventional': pub['conventional']['status'],
                 'point_seconds': pub['point']['search_seconds_inclusive'],
                 'conventional_seconds': pub['conventional']['search_seconds_inclusive'],
                 'model_counts': pub['point']['model_counts'], 'selected_tile_count': len(selected),
                 'public_row_SHA256': sha(compact(pub).encode()), 'original_worker_fields_equal': True,
                 'full_formula_catalog_and_selected_tile_rows_equal': True,
                 'checks': lane_checks})
assert (successful_point, unknown, successful_conventional, nonreach, native_count) == (8, 5, 9, 4, 17)
assert selected_tile_count == 48
for k in ['codec.decode', 'codec.encode', 'carrier.build_carrier', 'carrier.verify_carrier_choice', 'fol_checker.check', 'tree_machine.Heap', 'tree_machine.run']:
    assert worker['outer_public_calls'][k] == 17
assert public['provenance']['point_verified'] == 8 and public['provenance']['point_unknown'] == 5
assert public['provenance']['conventional_verified'] == 9 and public['provenance']['native_verified_certificates'] == 17
assert public['provenance']['qualification_controls'] == 23

class Inventory(HTMLParser):
    def __init__(self):
        super().__init__(); self.ids = []; self.links = []; self.external = []
    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if 'id' in a: self.ids.append(a['id'])
        if tag == 'a': self.links.append(a.get('href'))
        if tag == 'script' and 'src' in a: self.external.append(a['src'])
inv = Inventory(); inv.feed(html.decode()); inv.close()
assert len(inv.ids) == len(set(inv.ids))
assert inv.external == ['https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js']
assert all('#' + k in inv.links for k in ['results', 'reader', 'model', 'comparison', 'evidence'])
assert 'structural-proof-search-results-v1.json' in inv.links and 'structural-proof-search-evidence-v1.zip' in inv.links
assert 'compact-proof-search-v1.html#reader' in inv.links

result = {'schema': 'B-S-public-content-complete-draft-review-v1',
 'decision': 'PASS_CURRENT_CONTENT_PENDING_FINAL_ADMISSION_ARCHIVE_AND_CALLER', 'blockers': [],
 'content': {'HTML': pin(htmlpath), 'public_JSON': pin(jsonpath), 'embedded_JSON_byte_exact': True},
 'current_data_basis': {'worker_result': public['provenance']['worker_result'], 'observer': pin(observer_path),
                       'physical_actual_file_count': 125, 'worker_artifacts': 120, 'all_originals_fresh_rawpin_readback': True,
                       'all_120_artifact_complete_raw_gzip_hash_and_strict_JSON_joins': True},
 'full_13_case_projection': rows,
 'complete_claim_findings': [
  'Every original worker case, problem, family, point field and complete conventional record is unchanged in the public JSON. The only additions are exact saved formula catalogues, complete selected candidate rows, model/solve evidence and factual model counts.',
  'Eight point SAT proofs, five WALL_SECONDS UNKNOWN records, nine conventional DERIVABLE proofs and four complete finite MP-closure NOT_DERIVABLE outcomes are preserved. All13 observed conventional search clocks are lower. The report scopes this to one ordered authored-control run and makes no causal or general performance advantage claim.',
  'All17 successful certificates join complete saved check records: actual native status accepted/value1, exact proof/goal/byte-decoding, independent VERIFIED whole-proof receipt and full checked-line count. No check/solver/codec was replayed.',
  'The48 actual selected rows from eight point proofs match complete model candidate dictionaries in row order. Unit slot support and every outside-frontier output/reference marking value join actual proof rows. Conventional viewer dependencies are explicitly labeled without claiming point-selected tiles.',
  'Whole HTML, CSS and JS were read statically. Existing MathJax handles all displayed formulas; literal slot/out IDs are code/data labels. The viewer reads actual t/m rows, draws fixed symbolic positions without rotation or polygon-overlap semantics, distinguishes open unsupported output points and explains its schematic geometry. Full IDs and formula values are inspectable.',
  'The supplied marking-support screenshot was visually inspected as a stored QA artifact only. It shows actual slot4 and out2/out3/out4 support with corresponding Q, Q-implies-G and G formulas. No browser, JS or renderer was executed by this reviewer.',
  'Complete rule catalogue, strict earlier references, final-goal restriction, full graph/outsideQ dependencies and all-root generation0 specialization are accurately explained. Formula-valued anchored point families are explicitly separated from a fixed literal Wang palette.',
  'No trained RL, marking learner, universal literal Wang FOL machine, full PA induction, Hilbert geometry, mathematical unprovability or optimized ATP superiority is claimed. Reusable families/cluster proposals remain objectives.',
  'Observer15.026576584s rounds to15.027s and fresh-child lifetime RSS56442880B joins the saved complete observer receipt. Point compilation is included in search timing; independent auditing/storage/native checks are separately exposed. Native instruction prefixes have saved full event hashes; native bodies are not claimed to retain every instruction.',
  'Results/archive relative links match the exact three new publication sibling names; prior milestone link stays separate. Full archive inclusion and whole scientific admission remain prospective until separately reviewed.'
 ],
 'HTML_static_inventory': {'unique_ids': inv.ids, 'links': inv.links, 'external_scripts': inv.external},
 'visual_QA_sample': pin(S / 'root/browser-QA/local-marking-support.jpg'),
 'pending_final_combined_review': ['Current Root scientific whole admission and exact final content pins', 'Complete concrete archive origins/member readback and all three staged byte twins', 'Exact current plan/caller/runtime/bootstrap/Source/caps/fresh once and capture paths'],
 'scope': 'Static public content plus passive current saved-data associations. Not an independent scientific replay, whole scientific admission, browser test, archive adoption or publication authority.',
 'operations': {'subject_calls': 0, 'network_calls': 0, 'browser_or_JS_execution': 0,
                'actual_mutation': 0, 'data_only': ['strict JSON', 'gzip', 'hash', 'field equality', 'counts/arithmetic', 'HTML inventory', 'stored screenshot inspection']},
 'audit_Source': pin(Path(__file__)), 'terminal_state': 'TOOLS_IDLE_AWAITING_CONCRETE_FINAL_PACKAGE_CALLER'}
OUT.mkdir(parents=True, exist_ok=True)
path = OUT / 'structural-public-content-complete-draft-review-v1.json'
b = json.dumps(result, sort_keys=True, indent=2, ensure_ascii=True, allow_nan=False).encode() + b'\n'
with path.open('xb') as f: f.write(b)
assert path.read_bytes() == b
print(json.dumps(pin(path), sort_keys=True))
print(json.dumps({'counts': [successful_point, unknown, successful_conventional, nonreach, native_count], 'selected_tiles': selected_tile_count, 'cases': len(rows)}, sort_keys=True))
