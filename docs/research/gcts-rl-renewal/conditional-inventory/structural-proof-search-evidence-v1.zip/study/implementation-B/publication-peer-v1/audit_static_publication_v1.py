"""Administrative Source/AST review only; never imports or executes subject code."""
import ast
import hashlib
import json
from pathlib import Path
import re
import symtable
import sys

C = Path('/private/tmp/gcts-proof-structure-20261028-v1/implementation-C')
OUT = Path('/private/tmp/gcts-proof-structure-20261028-v1/implementation-B/publication-peer-v1')
def digest(b):
    return hashlib.sha256(b).hexdigest()
def encode(v):
    return json.dumps(v, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False).encode()
def pin(p):
    b = Path(p).read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': digest(b)}
def checked(ref):
    b = Path(ref['path']).read_bytes()
    assert len(b) == ref['bytes'] and digest(b) == ref['sha256'], ref['path']
    return b
def getjson(ref):
    return json.loads(checked(ref))
def units(t, source):
    found = []
    lines = source.splitlines(keepends=True)
    def walk(n, prefix):
        for child in ast.iter_child_nodes(n):
            if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                name = prefix + child.name
                found.append({'name': name, 'lines': [child.lineno, child.end_lineno],
                              'raw_sha256': digest(b''.join(lines[child.lineno - 1:child.end_lineno])),
                              'AST_sha256': digest(ast.dump(child).encode()),
                              'positioned_AST_sha256': digest(ast.dump(child, include_attributes=True).encode()),
                              'calls': sorted({ast.unparse(x.func) for x in ast.walk(child) if isinstance(x, ast.Call)})})
                walk(child, name + '.')
            else:
                walk(child, prefix)
    walk(t, '')
    return found
def scopes(st):
    flags = ['referenced', 'parameter', 'global', 'declared_global', 'nonlocal', 'local', 'free', 'imported', 'assigned', 'namespace', 'annotated']
    result = []
    def visit(table, name):
        symbols = []
        for s in table.get_symbols():
            row = {'name': s.get_name()}
            row.update({f: getattr(s, 'is_' + f)() for f in flags})
            symbols.append(row)
        result.append({'name': name, 'line': table.get_lineno(), 'type': table.get_type(),
                       'symbol_count': len(symbols), 'full_symbol_flags_sha256': digest(encode(symbols))})
        for child in table.get_children():
            visit(child, name + '.' + child.get_name())
    visit(st, 'top')
    return result
def differences(a, b, path):
    assert type(a) is type(b), path
    if isinstance(a, ast.AST):
        assert a._fields == b._fields, path
        result = []
        for f in a._fields:
            result += differences(getattr(a, f), getattr(b, f), path + '.' + f)
        return result
    if isinstance(a, list):
        assert len(a) == len(b), path
        result = []
        for i, (x, y) in enumerate(zip(a, b, strict=True)):
            result += differences(x, y, path + '[' + str(i) + ']')
        return result
    if a == b:
        return []
    assert type(a) is str, (path, a, b)
    return [{'path': path, 'old': a, 'new': b}]
def apply_patch(source, patch):
    src = source.decode().splitlines(keepends=True)
    rows = patch.decode().splitlines(keepends=True)
    assert rows[0].startswith('--- ') and rows[1].startswith('+++ ')
    out, pos, i = [], 0, 2
    while i < len(rows):
        m = re.fullmatch(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@.*\n', rows[i])
        assert m, rows[i]
        oldstart, oldn = int(m[1]), int(m[2] or '1')
        newstart, newn = int(m[3]), int(m[4] or '1')
        start = oldstart - 1 if oldn else oldstart
        assert start >= pos
        out.extend(src[pos:start]); pos = start
        assert len(out) == (newstart - 1 if newn else newstart)
        i += 1; seenold = seennew = 0
        while i < len(rows) and not rows[i].startswith('@@ '):
            row = rows[i]; i += 1
            assert row[0] in ' +-'
            if row[0] in ' -':
                assert pos < len(src) and src[pos] == row[1:]
                pos += 1; seenold += 1
            if row[0] in ' +':
                out.append(row[1:]); seennew += 1
        assert (seenold, seennew) == (oldn, newn)
    out.extend(src[pos:])
    return ''.join(out).encode()

handoff_ref = {'path': str(C / 'structural-proof-search-publication-complete-inert-Source-handoff-v1.json'), 'bytes': 3907, 'sha256': '6f13a4fbd463b9ab21e8cf1f6ccbc0eb50fc92e67fb4d8d1e3937dec5814c9e9'}
h = getjson(handoff_ref)
support = {k: getjson(v) for k, v in h['supporting_records'].items()}
for p in h['four_patches']:
    checked(p)
prior = pin('/private/tmp/gcts-B-R-publication-Source-peer-v1/R-publication-complete-independent-literal-Source-peer-review-v1.json')
assert (prior['bytes'], prior['sha256']) == (7616, '5c1206d4c70402d354d0ef876d0e4d49ef8e07148a6578976064fe15c24ad237')
prior_review = json.loads(checked(prior))
records = []
for r in support['complete_literal_preservation']['roles']:
    role = r['role']; old = checked(r['base']); new = checked(r['Source'])
    assert h['subjects'][role] == r['Source']
    transformed = old; counts = []
    for change in r['substitutions']:
        before = change['old'].encode(); after = change['new'].encode()
        assert transformed.count(before) == change['occurrences']
        counts.append(change['occurrences']); transformed = transformed.replace(before, after)
    assert transformed == new
    recovered = new
    for change in reversed(r['substitutions']):
        recovered = recovered.replace(change['new'].encode(), change['old'].encode())
    assert recovered == old
    a = ast.parse(old, r['base']['path']); b = ast.parse(new, r['Source']['path'])
    assert ast.dump(ast.parse(recovered), include_attributes=True) == ast.dump(a, include_attributes=True)
    delta = differences(a, b, 'Module')
    assert delta == r['all_AST_differences']
    static = support['complete_static']['records'][role]
    assert delta == static['AST_string_leaf_changes']
    current_units = units(b, new); old_units = units(a, old)
    assert current_units == static['all_named_units']
    assert [u['name'] for u in current_units] == [u['name'] for u in old_units]
    helper_old = {u['name']: u for u in old_units}
    for u, hp in zip(current_units, r['helper_preservation'], strict=True):
        ou = helper_old[u['name']]
        assert u['calls'] == ou['calls']
        assert hp == {'name': u['name'], 'new_raw_sha256': u['raw_sha256'],
                      'old_raw_sha256': ou['raw_sha256'], 'raw_unchanged': u['raw_sha256'] == ou['raw_sha256']}
    current_scopes = scopes(symtable.symtable(new.decode(), r['Source']['path'], 'exec'))
    assert current_scopes == static['all_scopes']
    assert digest(ast.dump(b).encode()) == static['whole_AST_sha256']
    assert digest(ast.dump(b, include_attributes=True).encode()) == static['whole_positioned_AST_sha256']
    assert len(current_units) == static['named_count'] and len(current_scopes) == static['scope_count']
    assert sum(isinstance(x, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)) for x in b.body) == static['top_units']
    for m in support['complete_helper_walkthrough']['helpers']:
        if m['role'] == role:
            u = next(x for x in current_units if x['name'] == m['helper'])
            assert u['raw_sha256'] == m['raw_sha256'] and u['lines'] == m['lines']
    forward, inverse = [checked(x) for x in r['patches']]
    assert apply_patch(old, forward) == new and apply_patch(new, inverse) == old
    code = compile(new, r['Source']['path'], 'exec'); del code
    records.append({'role': role, 'Source': r['Source'], 'base': r['base'],
                    'replacement_classes': len(counts), 'raw_replacement_occurrences': sum(counts),
                    'changed_AST_string_leaves': len(delta), 'named_units': len(current_units),
                    'scopes': len(current_scopes), 'top_units': static['top_units'],
                    'raw_unchanged_units': sum(u['raw_sha256'] == helper_old[u['name']]['raw_sha256'] for u in current_units),
                    'all_operative_AST_structure_nonstring_literals_imports_signatures_and_callsets_unchanged': True,
                    'whole_forward_inverse_raw_and_positioned_AST_exact': True,
                    'four_patch_readback_and_application_exact': True,
                    'all_helper_AST_raw_positioned_callset_manual_joins': True,
                    'all_symbol_scope_fingerprints_joined': True, 'unused_compile_pass': True,
                    'whole_AST_sha256': static['whole_AST_sha256'],
                    'whole_positioned_AST_sha256': static['whole_positioned_AST_sha256']})

review = {
 'schema': 'B-S-publication-complete-independent-literal-Source-peer-review-v1',
 'decision': 'PASS_SOURCE_ONLY', 'complete_review': True, 'blockers': [],
 'subjects': h['subjects'], 'handoff': handoff_ref,
 'reviewed_support': h['supporting_records'], 'four_patches': h['four_patches'],
 'inherited_complete_R_Source_peer': prior,
 'scope': 'Complete current literal-only publisher and normal-TLS Source peer. Every change was read; the entire two Sources are raw/AST/positioned-AST joined to the already fully reviewed R behavior. No current scientific actual or output intake.',
 'independent_static_results': records,
 'current_bindings': {
   'study': '/private/tmp/gcts-proof-structure-20261028-v1',
   'publisher_SELF': h['subjects']['publisher']['path'], 'verifier_SELF': h['subjects']['verifier']['path'],
   'expected_parent': '03f9276bfd9dc3b28b0cb837690fd2e4a39c814b',
   'expected_tree': '0f83e5e7e3a784e43c74044155bc2bcf131d7d01',
   'target_prefix': 'docs/research/gcts-rl-renewal/conditional-inventory/',
   'exact_three_new_names': ['structural-proof-search-v1.html', 'structural-proof-search-results-v1.json', 'structural-proof-search-evidence-v1.zip'],
   'root_stage': '/private/tmp/gcts-proof-structure-20261028-v1/root/publication-structural-proof-search-v1',
   'publisher_stage': '/private/tmp/gcts-proof-structure-20261028-v1/publisher-structural-proof-search-payload',
   'publisher_OUT': '/private/tmp/gcts-proof-structure-20261028-v1/root/publication-structural-proof-search-api-v1',
   'TLS_OUT': '/private/tmp/gcts-proof-structure-20261028-v1/root/structural-proof-search-live-TLS-verification-v1'},
 'full_behavior_findings': [
  'Exact9 publication plan, ordered3 exact4 file rows, exact3 typed rawrefs, parent/tree/main/stages/absence and full local twins/Gitblob guards retained. Current names/schema/status/selfpaths agree with effective ABI.',
  'Same isolated P2 Git Data API route; no local Git. Twelve API calls: six GET, three blob POST, tree POST, single-parent commit POST, one force=false PATCH. Both complete untruncated trees preserve every non-target leaf mode/type/SHA/size and require exactly three previously absent new leaves. Fresh pre-PATCH race and post-head equality retained.',
  'Typed fresh A6 exact6, current Source/D90/plan/payload authentication, exclusive durable consume before payload transport/network, own-output ownership, complete request/stdout/stderr/status/EOF/cleanup/postguards retained. Every uncertain mutation remains spent, with no automatic retry. Root must authenticate genuine full outer captures and authoritative normal exit.',
  'Same payload caps 1MiB HTML/8MiB JSON/32MiB ZIP; API request48MiB/response16MiB/stderr1MiB/60s; publication admin1MiB/output256MiB/count64/900s/cleanup5s. These are inherited observed/cooperative scopes, not a new hard OS resource claim.',
  'TLS exact4 plan plus exact6 once and consumed records; current genuine publisher terminal and separately adopted commit are external preconditions. Exactly three fixed same-origin HTTPS URLs include adopted commit, normal certificate/hostname checking, no redirects, retries or TLS bypass.',
  'TLS reads all three bodies through EOF and checks status200/finalURL/Content-Length/full SHA256/Gitblob and byte equality to both local twins; HTML/JSON/ZIP remain opaque. Header64KiB/output48MiB/count16/socket45s/wall180s scopes retained. Browser rendering and scientific-content admission are separate gates.',
  'All51 named units,64 symbol scopes,41 top-level units and four whole patches joined. Only39 AST string leaves and39 raw replacement occurrences across12 declared classes differ; no algorithm, callset, numeric cap, ownership or failure behavior changes.'
 ],
 'remaining_external_Root_gates': [
  'Whole current S scientific admission and full concrete content/archive/payload adoption before a publication plan or authority.',
  'Direct existing-destination full-archive human authorization remains an external genuine-evidence requirement; nonempty quote/date/scope alone is not proof of authorization.',
  'Current strict plan/payload/Source/runtime/caller association; fresh absent output/captures/authority/consume; one separately reviewed fresh once. No old spent authority reuse.',
  'Actual publisher exact current-head and full-tree checks; authoritative original transport/exit and full stored records adopted before verifier; Pages readiness and current TLS caller/once reviewed separately.'
 ],
 'operations': {'subject_imports': 0, 'subject_functions_or_codeobjects_executed': 0, 'scientific_actual_intakes': 0,
                'network_calls': 0, 'payload_or_plan_or_authority_created': 0,
                'allowed': ['raw Source/metadata reads', 'SHA256', 'JSON', 'AST', 'symtable', 'discarded unused compile', 'in-memory textual patch application']},
 'terminal_state': 'TOOLS_TERMINAL_IDLE', 'execution_or_publication_authority': False,
 'audit_Source': pin(__file__), 'static_runtime': sys.version
}
OUT.mkdir(parents=True, exist_ok=True)
destination = OUT / 'structural-publication-complete-independent-Source-peer-review-v1.json'
body = json.dumps(review, sort_keys=True, indent=2, ensure_ascii=True, allow_nan=False).encode() + b'\n'
with destination.open('xb') as f:
    f.write(body)
assert destination.read_bytes() == body
print(json.dumps(pin(destination), sort_keys=True))
print(json.dumps({'decision': review['decision'], 'roles': records, 'subject_calls': 0}, sort_keys=True))
