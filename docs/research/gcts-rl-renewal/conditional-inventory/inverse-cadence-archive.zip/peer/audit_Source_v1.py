from pathlib import Path
import ast,hashlib,json,re
C=Path('/private/tmp/gcts-inverse-cadence-peer-20261019');D=Path('/private/tmp/gcts-inverse-cadence-ROOT-20261019');P=Path('/private/tmp/gcts-incremental-arena-ROOT-20261019/independent_forest_inverse_v6.py');N=D/'independent_forest_inverse_v7.py'
checks=[]
def ck(n,c,detail=None):checks.append({'check':n,'passed':bool(c),'detail':detail})
def ds(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
a=P.read_text();b=N.read_text();patch=(D/'inverse-v6-v7.patch').read_text();contract=json.loads((D/'Source-contract-v1.json').read_text())
for key,p in [('source',N),('parent',P),('patch',D/'inverse-v6-v7.patch')]:ck('whole raw '+key,ds(p)==contract[key])
ck('offered current Source pin',ds(N)['sha256']=='fcbed7c5b95c8b8e6b1fc152c3d93689d644aa2e3ac32810dc77857e475750a7' and ds(N)['bytes']==24144)
# Apply unified patch as inert text; never load or execute either component.
lines=patch.splitlines(keepends=True);hunks=[];i=0
while i<len(lines):
 if lines[i].startswith('@@'):
  m=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',lines[i]);old_start,old_n,new_start,new_n=[int(x)if x is not None else 1 for x in m.groups()];i+=1;old=[];new=[]
  while i<len(lines)and not lines[i].startswith('@@'):
   line=lines[i]
   if line.startswith(' '):old.append(line[1:]);new.append(line[1:])
   elif line.startswith('-'):old.append(line[1:])
   elif line.startswith('+'):new.append(line[1:])
   elif line.startswith('\\ No newline'):raise AssertionError('unexpected newline directive')
   i+=1
  assert len(old)==old_n and len(new)==new_n
  hunks.append((old_start,new_start,old,new))
 else:i+=1
def inert_apply(source,reverse=False):
 src=source.splitlines(keepends=True);out=[];at=0
 for os,ns,old,new in hunks:
  start=(ns if reverse else os)-1;expect=new if reverse else old;replace=old if reverse else new
  assert src[start:start+len(expect)]==expect
  out.extend(src[at:start]);out.extend(replace);at=start+len(expect)
 out.extend(src[at:]);return ''.join(out)
forward=inert_apply(a);reverse=inert_apply(b,True)
ck('actual inert forward full equality',forward==b);ck('actual inert reverse full equality',reverse==a)
AT=ast.parse(a);BT=ast.parse(b)
for name,text in [('V6',a),('V7',b)]:compile(text,str(P if name=='V6'else N),'exec');ck('unused compile '+name,True)
def imports(t):return [ast.dump(x,include_attributes=False)for x in t.body if isinstance(x,(ast.Import,ast.ImportFrom))]
ck('stdlib imports exact',imports(AT)==imports(BT)and [x.names[0].name for x in BT.body if isinstance(x,ast.Import)]==['json','math','re'])
ck('no yield functions added',not any(isinstance(x,(ast.Yield,ast.YieldFrom))for x in ast.walk(BT)))
def funcs(t):
 out={}
 for n in t.body:
  if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)):out[n.name]=n
  if isinstance(n,ast.ClassDef):
   for x in n.body:
    if isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef)):out[n.name+'.'+x.name]=x
 return out
AF=funcs(AT);BF=funcs(BT);changed=[]
for n,v in AF.items():
 if ast.dump(v,include_attributes=False)!=ast.dump(BF[n],include_attributes=False):changed.append(n)
 else:ck('unchanged callable AST '+n,True)
expected=['_State.__init__','_State.tick','_State.snapshot','_DocumentStream.__next__','PreparedForest.documents','PreparedForest.catalogue','PreparedForest.iter_document']
ck('exact seven changed existing callables',changed==expected,changed);ck('only added dispatch callable',set(BF)-set(AF)=={'_State.dispatch'})
def src(text,node):return ast.get_source_segment(text,node)
for n in ['prepare_forest','_Pieces.__init__','_Pieces.take','_State.metrics','_State.tokenize','_DocumentStream._emit','_DocumentStream._advance','_DocumentStream.close','_State.gate','is_own_limit','is_own_reentrancy','_limits']:
 ck('raw full invariant '+n,src(a,AF[n])==src(b,BF[n]))
def assign(t,n):return next(x for x in t.body if isinstance(x,ast.Assign)and any(isinstance(y,ast.Name)and y.id==n for y in x.targets))
for n in ['SCHEMA','WIRE_VERSION','DEFAULT_LIMITS','_LIMIT_TOKEN','_PREPARED_TOKEN']:
 ck('exact constant AST '+n,ast.dump(assign(AT,n),include_attributes=False)==ast.dump(assign(BT,n),include_attributes=False))
oldtick=AF['_State.tick'];newtick=BF['_State.tick']
ck('tick seven accounting statements exact',all(ast.dump(x,include_attributes=False)==ast.dump(y,include_attributes=False)for x,y in zip(oldtick.body[:6],newtick.body[:6])))
ck('unconditional owned work test before dispatch',isinstance(newtick.body[5],ast.If)and "self.cap['work']"in src(b,newtick.body[5]) and '_stop' in src(b,newtick.body[5]) and isinstance(newtick.body[6],ast.If))
# Declarative source checks: no reviewed callable is evaluated.
dispatch=src(b,BF['_State.dispatch']);nexts=src(b,BF['_DocumentStream.__next__']);snapshot=src(b,BF['_State.snapshot']);init=src(b,BF['_State.__init__'])
ck('force resets before delegated callback',dispatch.index('self.last_callback_operation=n')<dispatch.index('try:self.check()'))
ck('private reentrancy guard dispatch',dispatch.index('self.gate()')<dispatch.index('self.in_callback=True')<dispatch.index('try:self.check()'))
ck('exact delegated errors reraised with finally', 'except BaseException:'in dispatch and 'self.publish_preserving_error();raise'in dispatch and 'finally:self.in_callback=False'in dispatch)
ck('snapshot owns both nested counter maps',"s['operations_by_kind']=dict(self.stats['operations_by_kind'])"in snapshot and "s['callback_dispatches_by_reason']=dict(self.stats['callback_dispatches_by_reason'])"in snapshot)
ck('snapshot owns document rows',"s['documents']={k:dict(v)for k,v in self.stats['documents'].items()}"in snapshot)
ck('pending computed from invocation operations',"s['pending_callback_operations']=s['attempted_operations']-self.last_callback_operation"in snapshot)
ck('closed next before delegated pull','if self.closed:raise StopIteration'in nexts and nexts.index('if self.closed:raise StopIteration')<nexts.index("state.dispatch('document_pull_entry')"))
ck('pull check inside exact error closure',nexts.index('try:')<nexts.index("state.dispatch('document_pull_entry')")<nexts.index('except BaseException:')and 'state.publish_preserving_error();raise'in nexts)
ck('no callback on completed property or cleanup',src(a,AF['_DocumentStream.completed'])==src(b,BF['_DocumentStream.completed'])and src(a,AF['_DocumentStream.close'])==src(b,BF['_DocumentStream.close']))
ck('initial chunk completion operations forced',"_BOUNDARY_OPERATIONS=frozenset(('initial','yield_chunk','preparation_completion','document_completion'))"in b)
ck('chunk check before materialized return',src(b,BF['_DocumentStream._emit']).index("tick('yield_chunk')")<src(b,BF['_DocumentStream._emit']).index('chunk=bytes'))
ck('successful prep after forced check',"state.tick('preparation_completion');s['prepared']=True"in b)
ck('successful document after forced check',"state.tick('document_completion');self.row['completed']=True"in b)
ck('passive statistics exact',src(a,AF['PreparedForest.statistics'])==src(b,BF['PreparedForest.statistics']))
ck('new profile explicit',contract['changed_execution_profile']=='independent-forest-actual-operations-v2-callback-cadence1024' and contract['cadence_operations']==1024)
ck('contract no latency or inherited coverage claim','not unchanged V6 fault coverage'in contract['callback_scope']and'no elapsed-latency bound'in contract['callback_scope'])
output={'schema':'inverse-cadence-static-Source-audit-v1','reviewed_Source':ds(N),'parent':ds(P),'contract':ds(D/'Source-contract-v1.json'),'patch':ds(D/'inverse-v6-v7.patch'),'source_only':True,'scientific_calls':0,'component_evaluations':0,'actual_execution_authorized':False,'inert_directions':2,'unused_compiles':2,'callable_count':len(BF),'exact_changed_callables':changed,'check_count':len(checks),'mismatch_count':sum(not x['passed']for x in checks),'checks':checks}
(C/'static-Source-audit-v1.json').write_text(json.dumps(output,sort_keys=True,indent=2)+'\n');print(json.dumps({k:v for k,v in output.items()if k!='checks'},indent=2));print('FAILURES',[x for x in checks if not x['passed']])
