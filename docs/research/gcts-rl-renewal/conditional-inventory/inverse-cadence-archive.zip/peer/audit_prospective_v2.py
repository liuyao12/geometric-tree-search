from pathlib import Path
import ast,json,hashlib
D=Path('/private/tmp/gcts-inverse-cadence-ROOT-20261019');L=Path('/private/tmp/gcts-inverse-cadence-library-20261019');C=Path('/private/tmp/gcts-inverse-cadence-peer-20261019')
def ds(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
checks=[]
def ck(n,c,detail=None):checks.append({'check':n,'passed':bool(c),'detail':detail})
def literal(t,n):return ast.literal_eval(next(x.value for x in t.body if isinstance(x,ast.Assign)and any(isinstance(k,ast.Name)and k.id==n for k in x.targets)))
p=D/'plan-false-v2.json';plan=json.loads(p.read_bytes());decl=json.loads(Path(plan['declaration']['path']).read_bytes());auth=json.loads(Path(plan['authorization']['path']).read_bytes());subject={k:v for k,v in plan.items()if k!='authorization'};sha=hashlib.sha256(json.dumps(subject,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest();h=L/'inverse_cadence_qualification_v2.py';ht=ast.parse(h.read_text())
ck('offered plan raw pin',ds(p)['sha256']=='95c7dd71b95ac37f29d56ce4192c22da84291ad4f018b473b46e5e03e1478185')
ck('exact plan14 and subject13',len(plan)==14 and len(subject)==13 and set(plan)=={'schema','invocation_id','actual_directory','python','worker','harness','inverse','runner','observer','inputs','limits','reference','declaration','authorization'})
for k in ['python','worker','harness','inverse','runner','observer','reference','declaration','authorization']:ck('whole raw '+k,ds(plan[k]['path'])==plan[k])
for r in plan['inputs']:
 for k in ['forest','result']:ck('whole raw original '+r['mode']+'/'+k,ds(r[k]['path'])==r[k])
ck('complete input order/scopes',plan['inputs']==literal(ht,'INPUTS')==decl['exact_inputs'])
ck('all4 original raw bytes',sum(r[k]['bytes']for r in plan['inputs']for k in ['forest','result'])==101004580)
ck('full logical bound',sum(r['result']['bytes']for r in plan['inputs'])==70916162<=134217728)
ck('full forest bound',sum(r['forest']['bytes']for r in plan['inputs'])==30088418<=134217728)
ck('reference exact current prior header',plan['reference']==decl['exact_reference']==literal(ht,'REFERENCE_STATS'))
ck('inverse Source exact',plan['inverse']==literal(ht,'INVERSE_PIN'))
ck('expected30 exact ordered names',list(literal(ht,'EXPECTED_DIAGNOSTICS'))==decl['expected_fixture_names']and len(set(decl['expected_fixture_names']))==len(decl['expected_fixture_names'])==decl['diagnostic_groups']==30)
ck('profile/version exact',literal(ht,'INVERSE_PROFILE')==decl['execution_profile']and literal(ht,'INVERSE_VERSION')==decl['inverse_version'])
ck('original global limits',plan['limits']==dict(work_seconds=180,overall_seconds=210,memory_bytes=1073741824,result_bytes=134217728,expanded_bytes=134217728,stdout_bytes=4194304,stderr_bytes=4194304))
ck('false max0 authorization',auth==dict(actual_execution_authorized=False,author_identity='/root',maximum_actual_invocations=0,schema='ROOT-inverse-cadence-once-authorization-v1'))
ck('strict false maximum integer',type(auth['maximum_actual_invocations'])is int and auth['maximum_actual_invocations']==0)
ck('declaration nonauthority',decl['actual_execution_authorized']is False and decl['scientific_acceptance']is False and decl['scientific_calls']==0 and decl['source_only']is True)
actual=Path(plan['actual_directory']);ck('private fresh canonical actual',actual.is_absolute()and str(actual.resolve())==str(actual)and str(actual).startswith('/private/tmp/')and actual.parent.is_dir()and not actual.exists())
ck('no observer consumed dirs',not list(D.glob('*-terminal-observation')))
for k in ['worker','harness','inverse','runner','observer']:
 s=Path(plan[k]['path']).read_text();ast.parse(s);compile(s,plan[k]['path'],'exec');ck('unused compile '+k,True)
# Raw symbolic statistics reference; no result tree or inverse evaluation.
reference=json.loads(Path(plan['reference']['path']).read_bytes())['evidence_verification']['statistics']
ck('prior reference operations sum',sum(reference['operations_by_kind'].values())==reference['attempted_operations']==reference['callback_dispatches']==21304533)
ck('prior reference finite completed doc',reference['prepared']is True and reference['documents']['receiver:complete-legacy-result']['completed']is True)
out={'schema':'inverse-cadence-prospective-static-audit-v1','plan':ds(p),'declaration':plan['declaration'],'subject':subject,'subject_sha256':sha,'subject_fields':13,'raw_checks':checks,'raw_check_count':len(checks),'raw_mismatch_count':sum(not x['passed']for x in checks),'source_only':True,'scientific_calls':0,'component_evaluations':0,'actual_execution_authorized':False,'blocking_Source_findings_separate':0}
(C/'prospective-static-audit-v2.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k not in ['subject','raw_checks']},indent=2));print([x for x in checks if not x['passed']])
