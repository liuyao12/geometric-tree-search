from pathlib import Path
import ast,json,hashlib
C=Path('/private/tmp/gcts-inverse-cadence-peer-20261019');D=Path('/private/tmp/gcts-inverse-cadence-ROOT-20261019');L=Path('/private/tmp/gcts-inverse-cadence-library-20261019')
checks=[]
def ck(n,v,detail=None):checks.append({'check':n,'passed':bool(v),'detail':detail})
def ds(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
plan=json.loads((D/'plan-false-v2.json').read_text());texts={};trees={}
for k in ['inverse','harness','worker','runner','observer']:
 p=Path(plan[k]['path']);s=p.read_text();texts[k]=s;trees[k]=ast.parse(s);compile(s,str(p),'exec');ck('exact full Source '+k,ds(p)==plan[k]);ck('unused compile '+k,True)
h=texts['harness'];w=texts['worker'];r=texts['runner'];o=texts['observer'];inv=texts['inverse']
transform=json.loads((L/'source-transform-v2.json').read_text());old=(L/'inverse_cadence_qualification_v1.py').read_text();new=h
forward=old;reverse=new
for c in transform['changes']:
 ck('unique actual forward anchor '+c['reason'],forward.count(c['old'])==1)
 forward=forward.replace(c['old'],c['new'],1)
for c in reversed(transform['changes']):
 ck('unique actual reverse anchor '+c['reason'],reverse.count(c['new'])==1)
 reverse=reverse.replace(c['new'],c['old'],1)
ck('actual inert full forward',forward==new);ck('actual inert full reverse',reverse==old)
for k in ['harness','inverse']:
 imports=[x.module if isinstance(x,ast.ImportFrom)else n.name for x in trees[k].body if isinstance(x,(ast.Import,ast.ImportFrom))for n in(x.names if isinstance(x,ast.Import)else [None])]
 ck('stdlib-only imports '+k,set(imports)<=set(['json','math','re','os','hashlib','pathlib','stat']),imports)
ck('only current inverse+harness dynamic loads',w.count("load_source('")==2 and "load_source('qualified_inverse_v7', plan['inverse'])"in w and "load_source('inverse_cadence_finite_harness', plan['harness'])"in w)
ck('whole exact4 sources plus Python guards',"for item in sources.values(): checked(item)"in w and "('python', 'worker', 'inverse', 'harness', 'runner', 'observer')"in w)
ck('failure best effort bare reraise',"except BaseException: pass\n        raise"in w)
ck('progress aggregate1MiB owned snapshot',"progress_bytes + len(body) <= 1048576"in w and 'progress_rows.append(json.loads(body))'in w)
ck('bounded failure prefix2MiB',"len(canonical(prefix)) > 2097152"in w)
ck('new private owner work disposition',"work_stop=(type(error)is QualificationDeadline and error._owner is _TOKEN)"in h and "result['status']=('UNKNOWN_WORK_DEADLINE'if work_stop else"in h)
ck('pretarget unexpected error exact reraise',"if error is not seen[0]or not inverse.is_own_reentrancy(error):raise"in h)
ck('external fault latch restored before expected fixtures',h.count('if boundary.foreign is not None:raise boundary.foreign')==9,h.count('if boundary.foreign is not None:raise boundary.foreign'))
ck('full callback controls explicit',"self.call(self.external_check);stamp=self.call(self.now)"in h and "self.tick();self.call(self.guard);self.tick()"in h)
ck('raw input nofollow regular descriptor EOF',all(s in h for s in ['os.O_RDONLY|os.O_NOFOLLOW','stat.S_ISREG(info.st_mode)','size==pin[\'bytes\']and h.hexdigest()==pin[\'sha256\']','return b\'\'.join(parts)']))
ck('exact2 whole pairs before any diagnostic',h.index('for row in inputs:\n            for key in')<h.index('_diagnostics(inverse_module')and 'raw_bytes==101004580 and raw_bytes<=134217728'in h)
ck('owned input/reference descriptor clones and unchanged caller',all(s in h for s in ['original_input_bytes=_canonical(inputs)','inputs=_clone(inputs);reference_stats=_clone(reference_stats)','_canonical(original_inputs)==original_input_bytes','_canonical(original_reference)==original_reference_bytes']))
ck('no old inverse evaluation',not any(isinstance(x,ast.ImportFrom)and x.module and ('v6'in x.module or 'arena'in x.module)for x in ast.walk(trees['harness'])))
ck('whole original BODY byte comparison',"chunk==actual"in h and 'digest.update(actual);size+=len(actual)'in h)
ck('one LF full final EOF/hash',"tail=os.read(fd,2);_need(tail==b'\\n'"in h and "size==expected['bytes']and digest.hexdigest()==expected['sha256']"in h)
ck('explicit stream completion not exhausted bytes alone',"if source.completed is not True:raise"in h and "_need(source.completed is True,'explicit full reconstructed stream completion')"in h)
ck('whole size occurrence and physical reconcile',all(s in h for s in ["stats['wire_canonical_bytes']==row['forest']['bytes']","stats['aggregate_document_bytes']==size","d['copied_body_bytes']==d['emitted_body_bytes']==size-1","d['stream_value_occurrences']==d['logical_value_occurrences']"]))
ck('symbolic full retained per-kind equality',"_canonical(stats['operations_by_kind'])==_canonical(reference['operations_by_kind'])"in h and "reference['attempted_operations']==21304533"in h)
ck('whole current cadence/completion checks',"stats['pending_callback_operations']==0"in h and "stats['maximum_callback_operation_gap']<=1024"in h)
ck('all30 strict diagnostic list before whole inputs',"_diagnostics(inverse_module,boundary,result['diagnostics'],phase,progress)"in h and h.index("_diagnostics(inverse_module,boundary,result['diagnostics'],phase,progress)")<h.index('packet=_whole('))
ck('qualified only exact complete30+2',"len(result['diagnostics'])==len(EXPECTED_DIAGNOSTICS)and len(result['whole_inputs'])==2"in h)
ck('9 meaningful prepare error combinations',"for target in ('validation_cadence','cache_build_cadence','preparation_completion'):"in h and "len(observed)==9"in h)
ck('18 meaningful public/stream error combinations',"'yield_chunk','document_completion','operation_cadence')"in h and "len(observed)==18"in h)
ck('error sentinels exact classes',h.count('for cls in (RuntimeError,ValueError,StopIteration):')==4,h.count('for cls in (RuntimeError,ValueError,StopIteration):'))
ck('new phase evidence public stats only',"holder[0].statistics()"in h and 'obs.get(\'phase\')'in h and '._state'not in h)
ck('no late chunks masquerade completion',"last byte is not completion"in h and "mandatory trailing pull completion"in h and "closed next has no delegated callback"in h)
ck('owned quota expected strict counters',"obs['attempted_operations']==2 and obs['prepared']is False"in h)
ck('both unknown prefixes no normal authority',"if normal:return result"in h and "result['complete_output_qualified']=False"in h and "error.inverse_qualification_prefix=result"in h)
ck('fixed remains historically failed',"prior_fixed_failure_recovered=False"in h and 'The fixed historical pipeline remains failed.'in w)
ck('worker exact strict fixture status and authority',"all(row['status'] == 'passed' and row['mathematical_authority'] is False"in w)
ck('outer exact fixture list/status/authority',"[f['name']for f in fixtures]==expected and len(set(expected))==len(expected)"in r and "all(f['status']=='passed'and f['mathematical_authority']is False"in r)
ck('worker status API success joined',"payload['status'] == 'FINITE_REPRESENTATION_QUALIFIED'"in w and "q['status']=='FINITE_REPRESENTATION_QUALIFIED'"in r)
ck('outer logical total exact original byte sum',"sum(r['reconstructed_complete_file_bytes']for r in q['whole_inputs'])==sum(r['result']['bytes']for r in plan['inputs'])==w['logical_result_bytes']<=LIMITS['expanded_bytes']"in r)
ck('outer source/plan review schemas scoped',all(s in r for s in ['inverse-cadence-qualification-components-Source-review-v1','inverse-cadence-qualification-prospective-plan-review-v1',"set(auth['review_roles'])=={'Source','plans'}","len(subject)==13"]))
ck('exclusive marker before Popen',r.index("consumed=save_new(actual/'CONSUMED.json'")<r.index('process=subprocess.Popen'))
ck('strict supplied Python isolated worker',"'-I','-S','-B',plan['worker']['path']"in r and 'start_new_session=True'in r)
ck('wait4 only exact child plus Darwin bytes',"os.wait4(process.pid,os.WNOHANG)"in r and "usage.ru_maxrss<=LIMITS['memory_bytes']"in r and "sys.platform=='darwin'"in r)
ck('positive checks known exit <180',all(s in r for s in ['normal exact worker exit0','positive known exit and checks before180','positive final whole checks before180']))
ck('failure clears both candidate flags',"result['resource_candidate_accepted']=False;result['representation_candidate']=False"in r)
ck('no signal after observed groupabsence',"need(absent or not group_seen_absent,'owned group reappeared; no unverified signal')"in r and "if not owned_group_absent():os.killpg(process.pid,sig)"in r)
ck('physical total reserved9MiB',"total+9437184<=LIMITS['result_bytes']"in r and "physical + 9437184 + 4194304 <= LIMITS['result_bytes']"in w)
ck('source final checks and work bound independent',r.index("for k in ['python','worker','harness','inverse','runner','observer','reference','declaration']:checked(plan[k])",r.index('worker peak within1GiB'))<r.index("need(NOW()<work,'positive final whole checks before180')"))
ck('observer exact runner literal',plan['runner']['sha256']in o)
ck('observer separate marker before runner',o.index("write_new(folder/'CONSUMED.json'")<o.index('process=subprocess.Popen'))
ck('observer terminal gate all exact positive/close',all(s in o for s in ["code==0 and observed<receipt['overall_deadline_ns']","receipt['worker_reaped']is True","receipt['owned_group_absent']is True","receipt['regular_logs_closed']is True","receipt['worker_launch_attempts']==1"]))
ck('postreceipt work/total failure veto',"POST_RECEIPT_DEADLINE_FAILURE.json"in o and "POST_RECEIPT_WORK_FAILURE.json"in o)
ck('observer reserves aggregate1MiB/log4MiB',"_METADATA_BYTES+len(raw)<=1048576"in o and "stat().st_size<=4194304"in o)
ck('timeout directchild only failure scope',"process.kill();process.wait(timeout=5)"in o and 'residual_worker_cleanup_requires_inspection=True'in o)
ck('observer epoch exclusion explicit','Source-entry epoch excludes observer/Python prelude.'in o)
ck('no positive mathematical permission',all(s in r for s in ['scientific_acceptance=False','mathematical_proof_accepted=False','Model_permission=False','Native_calls=0']))
out={'schema':'inverse-cadence-qualification-static-Source-audit-v2','subjects':{k:plan[k]for k in texts},'source_only':True,'scientific_calls':0,'component_evaluations':0,'actual_execution_authorized':False,'inert_directions':2,'unused_compile_count':5,'check_count':len(checks),'mismatch_count':sum(not c['passed']for c in checks),'checks':checks}
(C/'qualification-static-Source-audit-v2.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k!='checks'},indent=2));print('FAILURES',[c for c in checks if not c['passed']])
