"""Two exact Source disposition repairs only; no component evaluation."""
from pathlib import Path
import ast
import hashlib
import json

D=Path(__file__).parent;P=D/'inverse_cadence_qualification_v1.py'
b=P.read_bytes();assert hashlib.sha256(b).hexdigest()=='3d88094fd9283c14b7b92c64bfe5a0ea1c2f4e2f13934b465b1530be8b0ebe90'
s=b.decode();changes=[]
def change(old,new,reason):
    global s
    assert s.count(old)==1
    s=s.replace(old,new,1);changes.append(dict(old=old,new=new,reason=reason))
change("VERSION = 'inverse-cadence-qualification-v1'","VERSION = 'inverse-cadence-qualification-v2-disposition-fixes'",'Explicit preserved successor metadata.')
change("            _need(error is seen[0]and inverse.is_own_reentrancy(error),'exact private reentrancy propagation')", "            if error is not seen[0]or not inverse.is_own_reentrancy(error):raise",'A pre-target deadline/foreign error must propagate rather than become a fixture assertion error.')
change("        normal=(type(error)is QualificationDeadline and error._owner is _TOKEN)", "        work_stop=(type(error)is QualificationDeadline and error._owner is _TOKEN)\n        normal=work_stop",'Class name alone never classifies a foreign same-class error as an owned work stop.')
change("result['status']=('UNKNOWN_WORK_DEADLINE'if type(error)is QualificationDeadline else", "result['status']=('UNKNOWN_WORK_DEADLINE'if work_stop else",'Returned status uses exact private owner predicate.')
q=D/'inverse_cadence_qualification_v2.py';assert not q.exists();ast.parse(s);compile(s,str(q),'exec');q.write_text(s)
raw=q.read_bytes();print(json.dumps(dict(path=str(q),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))))
(D/'source-transform-v2.json').write_text(json.dumps(dict(schema='inverse-cadence-qualification-source-transform-v2',
    parent=dict(path=str(P),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b)),
    source=dict(path=str(q),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw)),
    changes=changes,target_functions_called=0),indent=2)+'\n')
