"""Metadata/AST/inert-patch author audit; no component import or invocation."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import subprocess

D=Path(__file__).parent;S=D/'inverse_cadence_qualification_v1.py';P=D/'inverse_cadence_qualification_v0_draft.py'
def pin(path):
    p=Path(path);h=hashlib.sha256();size=0
    with p.open('rb')as f:
        while True:
            b=f.read(1048576)
            if not b:break
            size+=len(b);h.update(b)
    return dict(path=str(p),sha256=h.hexdigest(),bytes=size)
def write(name,value):
    p=D/name;assert not p.exists(),name
    p.write_text(json.dumps(value,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
    return pin(p)
text=S.read_text();tree=ast.parse(text)
assign={n.targets[0].id:n.value for n in tree.body if isinstance(n,ast.Assign)and isinstance(n.targets[0],ast.Name)}
def literal(name):return ast.literal_eval(assign[name])
def dictcall(node,base=None):
    assert isinstance(node,ast.Call)and isinstance(node.func,ast.Name)and node.func.id=='dict'
    out={}if base is None else dict(base)
    out.update({x.arg:ast.literal_eval(x.value)for x in node.keywords});return out
limits=dictcall(assign['LIMITS']);fixture_limits=dictcall(assign['FIXTURE_LIMITS'],limits)
inputs=literal('INPUTS');reference=literal('REFERENCE_STATS');names=list(literal('EXPECTED_DIAGNOSTICS'))
source=pin(S);component=literal('INVERSE_PIN')
checks=[]
def check(name,condition,detail):
    assert condition,name
    checks.append(dict(name=name,passed=True,method='Source/raw/AST/metadata only',detail=detail))
check('current_source',source['sha256']=='3d88094fd9283c14b7b92c64bfe5a0ea1c2f4e2f13934b465b1530be8b0ebe90'and source['bytes']==32792,'Exact final Source.')
check('inverse_pin',pin(component['path'])==component,'Exact Root independently authored V7 Source.')
for index,row in enumerate(inputs):
    for kind in ('forest','result'):check('whole_raw_'+row['mode']+'_'+kind,pin(row[kind]['path'])==row[kind],'Complete original immutable artifact raw hash; no proof or opaque decoding.')
check('reference_pin',pin(reference['path'])==reference,'Original full symbolic V6 worker metadata, not a V6 invocation.')
check('complete_input_order',[r['mode']for r in inputs]==['fixed','symbolic'],'Two full originals, fixed first; no smaller input substitute.')
check('complete_input_bytes',sum(r[k]['bytes']for r in inputs for k in ('forest','result'))==101004580,'All four raw files, below aggregate128MiB.')
check('main_limits',limits==dict(nodes=2000000,edges=8000000,roots=4096,depth=513,work=30000000,expanded_bytes=134217728,wire_bytes=134217728,scalar_bytes=16777216,integer_digits=4096,fragment_bytes=4096,cache_bytes=8388608,cache_entries=65536,chunk_bytes=65536),'Exact unchanged inverse per-preparation caps.')
check('small_fixture_caps',fixture_limits['work']==200000 and fixture_limits['expanded_bytes']==1048576 and fixture_limits['wire_bytes']==1048576,'Smaller diagnostic caps; no main private limit reset.')
check('literal_30_groups',len(names)==30 and len(set(names))==30,'Finite exact names before future grant.')
check('no_top_level_component_imports',all(n.names[0].name in('hashlib','json','math','os','stat')for n in tree.body if isinstance(n,ast.Import))and all(n.module=='pathlib'for n in tree.body if isinstance(n,ast.ImportFrom)),'Only builtin standard-library imports.')
check('no_main_dispatch',not any(isinstance(n,ast.If)and '__name__'in ast.unparse(n.test)for n in tree.body),'Library entry only, wrapper owns launch/admission.')
check('no_eval',not any(isinstance(n,ast.Call)and isinstance(n.func,ast.Name)and n.func.id in('exec','eval','compile','__import__')for n in ast.walk(tree)),'No component or dynamic execution path in harness Source.')
check('strict_current_source_auth',"current exact injected V7 Source"in text and "inverse.CHECKPOINT_OPERATIONS==1024"in text,'Raw current Source+public ABI joined; Root module-origin seal still required.')
check('raw_file_bounded',"os.O_RDONLY|os.O_NOFOLLOW"in text and "whole raw hash/EOF"in text,'Canonical path, regular size, full SHA/EOF and growth cap.')
check('caller_input_copy',"inputs=_clone(inputs);reference_stats=_clone(reference_stats)"in text and "caller input/reference descriptors unchanged"in text,'Fresh operational descriptors plus final original-caller custody comparison.')
check('pre_and_post_clock',text.index('stamp=self.call(self.now)')<text.index('self.call(self.external_check);stamp=self.call(self.now)'), 'Known-expired work stops before delegated check; post-call check preserves strict completion gate.')
check('callback_source_origin',"self.foreign=error;raise"in text and "if boundary.foreign is not None:raise boundary.foreign"in text,'Unexpected Root fault cannot become a passed negative fixture.')
check('fixture_completion',"if source.completed is not True:raise"in text and "explicit diagnostic completion"in text,'Manual next/completed required, no swallowed foreign StopIteration.')
check('typed_scalars',all(x in text for x in ("['bool',False]","['int','0']","['float','0.0']","['float','-0.0']")),'Full scalar lexical distinctions and Unicode exact bytes.')
check('ordered_shared_ports',"aggregate_document_value_occurrences']>len(shared['nodes'])"in text,'Repeated ordered use counted as logical occurrence.')
check('cache_fallback',"cache_bytes=0,cache_entries=0"in text and "cache_capacity_fallbacks']>0"in text,'No-cache full stream remains complete.')
check('strict_malformed_shapes',len(names[3:15])==12 and "for name,w in zip(EXPECTED_DIAGNOSTICS[3:15],invalid)"in text,'Twelve finite invalid forms; final all-name equality prevents omitted group passing.')
check('bool_limit',"dict(work=True)"in text,'Boolean is not an integer limit.')
check('scalar_boundary',"dict(scalar_bytes=7)"in text and "dict(scalar_bytes=8)"in text,'Quoted newline token exact boundary.')
check('depth_boundary',"dict(depth=3)"in text and "dict(depth=4)"in text,'Inverse scalar depth1, exact nested array boundary.')
check('expanded_occurrences',"dict(expanded_bytes=size-1)"in text and "exact_logical_bytes=size"in text,'One external LF and repeated uses included.')
check('physical_boundary',"size=len(_canonical(base))+1"in text and "dict(wire_bytes=size-1)"in text,'Canonical seven-field wire plus exactly one LF.')
check('own_work_cap',"obs['attempted_operations']==2 and obs['prepared']is False"in text,'Own work1 refusal at operation2, never partial preparation authority.')
check('gap_evidence',"maximum_callback_operation_gap']<=1024"in text and "pending_callback_operations']==0"in text,'Finite final gap and completion observations, not a wall-latency proof.')
check('forced_public_entries',all("'"+x+"'"in text for x in ('documents_entry','catalogue_entry','document_stream_entry','document_pull_entry','yield_chunk','document_completion')),'All declared forced public/pull/yield/completion kinds reached in positive diagnostic.')
check('trailing_pull',"last byte is not completion"in text and "mandatory trailing pull completion"in text,'Exact body bytes before final next do not qualify.')
check('closed_next_no_callback',"closed next has no delegated callback"in text and "closed_incomplete']is True"in text,'Closed/incomplete behavior is separate from successful exhaustion.')
check('three_foreign_classes',"for cls in (RuntimeError,ValueError,StopIteration)"in text,'Exact exception objects, not broad error-type normalization.')
check('prepare_phase_reached',"'validation_cadence','cache_build_cadence','preparation_completion'"in text and "len(observed)==9"in text,'Three error classes at actually reached phase callbacks.')
check('stream_phase_reached',"'yield_chunk','document_completion','operation_cadence'"in text and "len(observed)==18"in text,'Three classes at six reached public/stream reasons.')
check('no_private_state_access',not any(isinstance(n,ast.Attribute)and n.attr in('_state','_nodes','_cache','_documents')for n in ast.walk(tree)),'Only public inverse API, provided observer and passive statistics.')
check('reentrant_exact_identity',"error is seen[0]and inverse.is_own_reentrancy(error)"in text,'Own reentrancy object propagates; passive statistics permitted.')
check('late_completion_fault',"late foreign StopIteration never admits completion"in text,'Exact body complete is not enough after late fault.')
check('append_only_successful_group',"boundary.full();rows.append"in text,'Completed diagnostics only appended after full checks.')
check('whole_result_not_decoded',"wire=json.loads(raw)"in text and "json.loads(_raw(row['result']"not in text,'Only forest and reference metadata decoded. Whole original result compared as raw file bytes.')
check('whole_body_file_equality',"chunk==actual"in text and "tail==b'\\n'"in text and "digest.hexdigest()==expected['sha256']"in text,'Complete fresh reconstructed BODY+oneLF, raw SHA/EOF.')
check('whole_sequence_matches_V6',"prepared.documents==(DOCUMENT,)"in text and "source=prepared.iter_document(DOCUMENT)"in text,'One documents read, one stream, all next/close; no catalogue call in whole path.')
check('full_counter_reference',"stats['attempted_operations']==reference['attempted_operations']==21304533"in text and "_canonical(stats['operations_by_kind'])==_canonical(reference['operations_by_kind'])"in text,'All old per-kind units compared as complete literal metadata, no V6 execution.')
check('whole_complete_first',"result['whole_inputs'].append(packet)"in text and "explicit_completed=True"in text,'Only completed full-file packets enter completed prefix.')
check('normal_limit_unknown',"UNKNOWN_EVIDENCE_LIMIT"in text and "UNKNOWN_WORK_DEADLINE"in text,'Normal own limit/deadline retains partial metadata, never complete qualification.')
check('foreign_reraise',"raise error"in text and "error.inverse_qualification_prefix=result"in text,'Unexpected errors rethrow exact object with best-effort prefix only.')
check('no_native_authority',"mathematical_authority=False,scientific_acceptance=False,ROOT_resource_accepted=False"in text,'Representation-only candidate; outer exact resource admission remains required.')
check('no_automatic_retry',all(x not in text for x in ('subprocess','Popen','sleep(','os.system','run_receiver','Native.query')),'No launch/retry/search/Native path.')

# Inert rehearsal from preserved28-group draft to current30-group Source.
before=P.read_text();after=text
patches=[]
for direction,start,wanted in [('forward',before,after),('inverse',after,before)]:
    patch=''.join(difflib.unified_diff(start.splitlines(True),wanted.splitlines(True),fromfile='harness.py',tofile='harness.py'))
    patch_path=D/('harness-'+direction+'.patch');assert not patch_path.exists();patch_path.write_text(patch)
    scratch=D/'inert-patch'/direction;scratch.mkdir(parents=True)
    (scratch/'harness.py').write_text(start)
    proc=subprocess.run(['/usr/bin/patch','--batch','-p0','-i',str(patch_path)],cwd=scratch,capture_output=True,text=True)
    assert proc.returncode==0,(proc.stdout,proc.stderr)
    actual=(scratch/'harness.py').read_text();assert actual==wanted
    ast.parse(actual);compile(actual,str(scratch/'harness.py'),'exec')
    patches.append(dict(direction=direction,patch=pin(patch_path),result=pin(scratch/'harness.py'),
        actual_text_patch_applied=True,whole_bytes_equal=True,unused_compile=True,target_calls=0))
compile(text,str(S),'exec')
profile=write('prospective-profile-v1.json',dict(schema='inverse-cadence-qualification-profile-v1',
    inputs=inputs,reference_stats=reference,inverse=component,inverse_limits=limits,diagnostic_limits=fixture_limits,
    expected_diagnostics=names,diagnostic_count=30,raw_input_bytes=101004580,
    outer=dict(work_seconds=180,overall_seconds=210,worker_peak_bytes=1073741824,
        input_aggregate_bytes=134217728,physical_output_bytes=134217728,expanded_output_bytes=134217728,
        logs_bytes_each=4194304),
    work_scope='Inverse30m is per fresh prepare/forest as in its API. Diagnostics have separate smaller per-call200k, all charged inside single shared180/210 invocation. No global quota reset or old failure recovery.',
    representation_only=True,future_execution_authorized=False))
api=write('API-v1.json',dict(schema='inverse-cadence-qualification-API-v1',source=source,
    VERSION=literal('VERSION'),RESULT_SCHEMA=literal('RESULT_SCHEMA'),
    signature='run_inverse_qualification(*,inverse_module,inputs,reference_stats,check,source_guard,now,work_deadline,closure_deadline,progress=None)',
    inverse_source=component,inverse_version=literal('INVERSE_VERSION'),inverse_profile=literal('INVERSE_PROFILE'),
    inputs=inputs,reference_stats=reference,EXPECTED_DIAGNOSTICS=names,diagnostic_count=30,
    inputs_total_raw_bytes=101004580,reference_format='Exact original66838-byte symbolic worker header descriptor; extract evidence_verification.statistics. Not Root new compact reference file.',
    result_fields=['schema','version','status','representation_only','mathematical_authority','scientific_acceptance','ROOT_resource_accepted',
        'inputs','reference_stats','diagnostics','whole_inputs','limits','stage','started_monotonic','completed_monotonic',
        'owned_inverse_source','complete_original_raw_input_bytes'],
    completed_status='FINITE_REPRESENTATION_QUALIFIED',
    diagnostic_row=dict(schema='inverse-cadence-finite-diagnostic-v1',name='one literal EXPECTED_DIAGNOSTICS value',status='passed',mathematical_authority=False,details='bounded ordinary observation'),
    whole_input_row_keys=['schema','mode','status','forest','original_result','reconstructed_complete_file_bytes',
        'full_original_file_sha256','explicit_completed','statistics','V6_retained_reference_comparison','representation_only','mathematical_authority',
        'prior_fixed_failure_recovered','started_monotonic','completed_monotonic'],
    unknown_statuses=['UNKNOWN_WORK_DEADLINE','UNKNOWN_EVIDENCE_LIMIT'],
    unknown_extra_fields=['partial_phase','error','complete_output_qualified:false'],
    unexpected='Rethrow exact BaseException object, best-effort inverse_qualification_prefix only. Outer must retain failure and reject admission.',
    outer_mandatory=['Root authenticates exact module origin/callables/current Source and all inputs/plans/grant before invocation.',
        'Root writes bounded atomic ordinary result with no positive work after180 and retains normal UNKNOWN metadata within210.',
        'Root gates Darwin worker wait4<=1GiB, full known exit/owned-group absence/log EOF and once/max-one, no Native child.',
        'No positive authority comes from receipt count or this candidate status alone. Old fixed full-pipeline failure remains failed.',
        'Do not relabel this pure retained-byte component test as fresh proof search, Native acceptance, speed gain or memory saving.']))
argument=write('Source-argument-v1.json',dict(schema='inverse-cadence-qualification-author-Source-argument-v1',source=source,
    author_identity='/root/conventional_library',source_only=True,component_calls=0,
    rationale=['Full exact four raw input descriptors are checked before all diagnostics and freshly during whole inverse/result comparison.',
        'The two originals are never replaced by smaller packets; only forest/old header JSON are decoded; original proof result is full raw bytes.',
        'New callback-profile fixtures use observed current phase/reason, require reached flags and exact error objects, never old ordinals.',
        'Every completed whole traversal retains full current inverse statistics and logical/physical byte/occurrence ledgers.',
        'The symbolic public call sequence matches original cold so old attempted/per-kind counters are comparable without invoking V6.'],
    finite_coverage=['30 groups; malformed forms do not prove universal robustness.',
        'Initial prepare/pull errors and reached validation/cache/preparation-completion/public-entry/yield/document-completion/stream-cadence errors cover RuntimeError,ValueError,StopIteration.',
        'No SystemExit/GeneratorExit/concurrent caller mutation or hostile private-runtime sandbox qualification is claimed.',
        'Cadence bound concerns logical operations, not elapsed-time preemption; final outer deadline gate is independent.'],
    ancestry='Author of qualified arena, owned cold/registry and older Model/point work; neither this author packet nor fixture Source is an independent certificate of those components. InverseV7 is Root-authored and has a separate distinct Source peer.',
    limitations=['No runtime fixture/component/codec/Native/Model/search call occurred in authoring.',
        'Builtin JSON parsing and whole-file canonical comparisons are bounded by byte limits with cooperative boundary checks, not interruptible mid-builtin.',
        'All outputs are representation-only candidates until independent fresh once resource/custody audit; no old failure is rescued.',
        'Exclusive ordinary input/Source/module custody and trusted pinned Python/OS remain assumptions.']))
contract=write('Source-contract-v1.json',dict(schema='inverse-cadence-qualification-Source-contract-v1',source=source,sources=[source],
    author_identity='/root/conventional_library',API=api,profile=profile,argument=argument,
    dependency=component,all_inputs=inputs,reference_stats=reference,
    source_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,
    unchanged='No edits to qualified V6/V7, arena/adapter, prior actuals, theorem inventory, Model, Native checker, search or report.',
    review_ABI=dict(schema='inverse-cadence-qualification-typed-Source-review-v1',required_fields=[
        'schema','source','sources','source_contract','author_identity','reviewer_identity','source_only','source_review_passed',
        'scientific_calls','scientific_acceptance','actual_execution_authorized','findings','limitations'],
        author_identity='/root/conventional_library',reviewer_must_be_distinct=True),
    pending=['Distinct Source/fixture oracle review','Root new pure qualifier/once/observer Source and full current closure',
        'Prospective full input/profile/plan review','Exact final max-one grant review','Agents idle before Root-only actual']))
audit=write('author-static-audit-v1.json',dict(schema='inverse-cadence-qualification-author-static-audit-v1',source=source,
    author_identity='/root/conventional_library',independent=False,checks=checks,check_count=len(checks),mismatches=0,
    inert_patches=patches,unused_compiles=3,target_imports=0,target_functions_called=0,fixture_calls=0,
    scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,
    prior_draft=pin(P),runtime_tests='NOT_EXECUTED'))
handoff=write('handoff-v1.json',dict(schema='inverse-cadence-qualification-author-handoff-v1',source=source,sources=[source],
    author_identity='/root/conventional_library',source_contract=contract,API=api,profile=profile,argument=argument,
    author_static_audit=audit,inverse=component,inputs=inputs,reference_stats=reference,
    source_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,
    status='FROZEN_SOURCE_ONLY_NOT_RUNTIME_QUALIFIED',diagnostic_groups=30,whole_inputs=2))
print(json.dumps(dict(source=source,handoff=handoff,API=api,contract=contract,checks=len(checks))))
