"""Finite Source-only qualification authoring; never self-executed.

Root must separately authenticate this Source, the injected inverse, complete
inputs and once subject before calling it. This compares saved ordinary bytes;
it never imports an encoder, Model, Native checker or proof-search component.
"""
import hashlib
import json
import math
import os
from pathlib import Path
import stat

VERSION = 'inverse-cadence-qualification-v2-disposition-fixes'
RESULT_SCHEMA = 'inverse-cadence-qualification-result-v1'
INVERSE_VERSION = 'independent-evidence-forest-inverse-v7-bounded-callback-cadence'
INVERSE_PROFILE = 'independent-forest-actual-operations-v2-callback-cadence1024'
INVERSE_PIN = {'path':'/private/tmp/gcts-inverse-cadence-ROOT-20261019/independent_forest_inverse_v7.py',
    'sha256':'fcbed7c5b95c8b8e6b1fc152c3d93689d644aa2e3ac32810dc77857e475750a7','bytes':24144}
LIMITS = dict(nodes=2000000,edges=8000000,roots=4096,depth=513,work=30000000,
    expanded_bytes=134217728,wire_bytes=134217728,scalar_bytes=16777216,integer_digits=4096,
    fragment_bytes=4096,cache_bytes=8388608,cache_entries=65536,chunk_bytes=65536)
FIXTURE_LIMITS = dict(LIMITS,work=200000,nodes=20000,edges=40000,roots=128,
    depth=128,expanded_bytes=1048576,wire_bytes=1048576,scalar_bytes=65536,
    cache_bytes=65536,cache_entries=4096,chunk_bytes=4096)
INPUTS = [
    {'mode':'fixed','forest':{'path':'/private/tmp/gcts-owned-evidence-integration-ROOT-20261019/actual-fixed-v1/evidence-forest.json',
        'sha256':'f7e39ed6b02d3c6b80cccb5e40ac4f254a1d989fdf129b6571df500d1bbe554a','bytes':15181545},
     'result':{'path':'/private/tmp/gcts-owned-evidence-integration-ROOT-20261019/actual-fixed-v1/result.json',
        'sha256':'16e1935a7b46b70dc8588e1427d9de5de59554816f743de2ea9bd462a6545b25','bytes':36914326}},
    {'mode':'symbolic','forest':{'path':'/private/tmp/gcts-owned-evidence-integration-ROOT-20261019/actual-symbolic-v1/evidence-forest.json',
        'sha256':'c783757e1f0119d60249ac6c43e581ecce35861471299fae67926d4cc840d146','bytes':14906873},
     'result':{'path':'/private/tmp/gcts-owned-evidence-integration-ROOT-20261019/actual-symbolic-v1/result.json',
        'sha256':'e6e247eb9e52640d92b1ae51b837661be372bbdf2f6865d0273db13d2d6a0310','bytes':34001836}}]
REFERENCE_STATS = {'path':'/private/tmp/gcts-owned-evidence-integration-ROOT-20261019/actual-symbolic-v1/worker-receipt.json',
    'sha256':'002b536459e70bef5c89ca6a3be8d82671ed3feb1196b0b3ae9bce035f3cc832','bytes':66838}
DOCUMENT = 'receiver:complete-legacy-result'
EXPECTED_DIAGNOSTICS = (
    'typed_scalars_signed_zero_unicode_and_repeated_ports',
    'shared_producers_ordered_object_ports',
    'cache_disabled_complete_fallback',
    'strict_top_fields','strict_boolean_reference','strict_forward_reference',
    'all_nodes_reachable','all_catalogue_roots_covered','typed_node_uniqueness',
    'sorted_object_keys','unique_object_keys','canonical_integer_lexeme',
    'canonical_float_type','finite_float_lexeme','unicode_scalar_string',
    'strict_boolean_limit','quoted_scalar_exact_boundary','depth_exact_boundary',
    'expanded_multiplicity_exact_boundary','physical_wire_exact_boundary',
    'private_work_cap_no_partial_authority',
    'cadence_and_forced_public_entries','chunk_boundary_and_trailing_completion',
    'foreign_prepare_exception_identity','foreign_stream_exception_identity',
    'late_completion_exception_identity','callback_reentrancy_identity',
    'close_incomplete_and_closed_next_no_callback',
    'foreign_validation_cache_and_preparation_completion_identity',
    'foreign_public_yield_completion_and_stream_cadence_identity')
_TOKEN = object()


class QualificationError(ValueError):pass
class QualificationDeadline(RuntimeError):
    def __init__(self,*,_owner=None):self._owner=_owner;super().__init__('qualification own work deadline')


def _need(ok,message):
    if not ok:raise QualificationError(message)


def _canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode('utf8')


class _Boundary:
    def __init__(self,check,guard,now,deadline):
        _need(callable(check)and callable(guard)and callable(now),'explicit external callbacks')
        _need(type(deadline)in(int,float)and math.isfinite(deadline),'finite work deadline')
        self.external_check=check;self.guard=guard;self.now=now;self.deadline=deadline
        self.foreign=None;self.last=None
    def call(self,callback):
        try:return callback()
        except BaseException as error:
            self.foreign=error;raise
    def tick(self):
        stamp=self.call(self.now)
        _need(type(stamp)in(int,float)and math.isfinite(stamp),'finite monotonic observation')
        self.last=stamp
        if stamp>=self.deadline:raise QualificationDeadline(_owner=_TOKEN)
        self.call(self.external_check);stamp=self.call(self.now)
        _need(type(stamp)in(int,float)and math.isfinite(stamp),'finite monotonic observation')
        self.last=stamp
        if stamp>=self.deadline:raise QualificationDeadline(_owner=_TOKEN)
    def full(self):
        self.tick();self.call(self.guard);self.tick()


def _raw(pin,boundary,cap=134217728):
    _need(type(pin)is dict and set(pin)=={'path','sha256','bytes'},'complete raw descriptor')
    _need(type(pin['bytes'])is int and 0<=pin['bytes']<=cap,'strict bounded file bytes')
    p=Path(pin['path']);_need(p.is_absolute()and p==p.resolve(),'canonical absolute input path')
    boundary.tick();fd=os.open(str(p),os.O_RDONLY|os.O_NOFOLLOW)
    try:
        info=os.fstat(fd);_need(stat.S_ISREG(info.st_mode)and info.st_size==pin['bytes'],'regular exact file size')
        h=hashlib.sha256();parts=[];size=0
        while True:
            boundary.tick();part=os.read(fd,65536)
            if not part:break
            size+=len(part);_need(size<=pin['bytes'],'input grew beyond declared size')
            h.update(part);parts.append(part)
        _need(size==pin['bytes']and h.hexdigest()==pin['sha256'],'complete raw hash/EOF')
        return b''.join(parts)
    finally:os.close(fd)


def _authenticate(inverse,boundary):
    boundary.full();p=Path(inverse.__file__).resolve()
    raw=_raw(dict(path=str(p),sha256=INVERSE_PIN['sha256'],bytes=INVERSE_PIN['bytes']),boundary,16777216)
    _need((hashlib.sha256(raw).hexdigest(),len(raw))==(INVERSE_PIN['sha256'],INVERSE_PIN['bytes']),
          'current exact injected V7 Source')
    _need(inverse.VERSION==INVERSE_VERSION and inverse.EXECUTION_PROFILE==INVERSE_PROFILE and
          type(inverse.CHECKPOINT_OPERATIONS)is int and inverse.CHECKPOINT_OPERATIONS==1024,
          'explicit V7 callback execution profile')
    return dict(path=str(p),sha256=INVERSE_PIN['sha256'],bytes=INVERSE_PIN['bytes'])


def _forest(nodes,root=None,label='d'):
    return dict(schema='exact-evidence-forest-v1',version='exact-evidence-arena-v1',
        source_epoch='s',semantic_epoch='m',nodes=nodes,
        roots=[[label,len(nodes)-1 if root is None else root]],documents=[label])


def _clone(value):return json.loads(json.dumps(value,allow_nan=False))


def _limits(changes=None):
    result=dict(FIXTURE_LIMITS)
    if changes:result.update(changes)
    return result


def _drain(prepared,label,wanted,boundary):
    source=prepared.iter_document(label);offset=0;chunks=0
    try:
        while True:
            boundary.tick()
            try:part=next(source)
            except StopIteration:
                if source.completed is not True:raise
                break
            _need(type(part)is bytes and part==wanted[offset:offset+len(part)],'complete diagnostic BODY bytes')
            offset+=len(part);chunks+=1
        _need(source.completed is True and offset==len(wanted),'explicit diagnostic completion')
    finally:source.close()
    return dict(body_bytes=offset,chunks=chunks,completed=True)


def _diagnostics(inverse,boundary,rows,phase,progress):
    def announce(name):
        boundary.full();phase.update(stage='DIAGNOSTIC',name=name,observer=None)
        if progress is not None:boundary.call(lambda:progress(dict(phase)))
    def passed(name,details):
        boundary.full();rows.append(dict(schema='inverse-cadence-finite-diagnostic-v1',name=name,
            status='passed',mathematical_authority=False,details=details))
    def prepare(w,limits=None,check=None,observation=None):
        return inverse.prepare_forest(w,boundary.tick if check is None else check,
            _limits(limits),statistics={}if observation is None else observation)
    def expect(action,kind,reason=None):
        try:action()
        except BaseException as error:
            if boundary.foreign is not None:raise boundary.foreign
            if kind=='data':
                if type(error)is not inverse.ForestDataError:raise
            elif kind=='limit':
                if not inverse.is_own_limit(error):raise
                if reason is not None:_need(error.reason==reason,'exact own limit reason')
            else:raise QualificationError('unknown fixture refusal kind')
            return dict(type=type(error).__name__,reason=getattr(error,'reason',None),authority=False)
        raise QualificationError('expected finite refusal was not raised')

    name=EXPECTED_DIAGNOSTICS[0];announce(name)
    nodes=[['null'],['bool',False],['int','0'],['float','0.0'],['float','-0.0'],['str','\n雪'],['array',[0,1,2,3,4,5,2]]]
    wanted=_canonical([None,False,0,0.0,-0.0,'\n雪',0]);p=prepare(_forest(nodes))
    passed(name,_drain(p,'d',wanted,boundary))

    name=EXPECTED_DIAGNOSTICS[1];announce(name)
    shared=_forest([['int','1'],['str','p'],['array',[0,1,0]],['object',[['a',2],['z',2]]]])
    wanted=_canonical({'a':[1,'p',1],'z':[1,'p',1]});p=prepare(_clone(shared))
    r=_drain(p,'d',wanted,boundary);_need(p.statistics()['aggregate_document_value_occurrences']>len(shared['nodes']),
        'repeated ordered uses count by occurrence');passed(name,r)

    name=EXPECTED_DIAGNOSTICS[2];announce(name)
    p=prepare(_clone(shared),dict(cache_bytes=0,cache_entries=0));r=_drain(p,'d',wanted,boundary)
    stats=p.statistics();_need(stats['cache_entries']==0 and stats['cache_capacity_fallbacks']>0,'complete disabled-cache fallback')
    passed(name,dict(r,cache_entries=0,capacity_fallbacks=stats['cache_capacity_fallbacks']))

    base=_forest([['null']])
    invalid=[]
    q=_clone(base);q['extra']=0;invalid.append(q)
    invalid.append(_forest([['null'],['array',[False]]]))
    invalid.append(_forest([['array',[1]],['null']]))
    invalid.append(_forest([['null'],['int','1']]))
    q=_forest([['null'],['int','1']]);q['roots']=[['d',1],['unused',0]];invalid.append(q)
    invalid.append(_forest([['null'],['null']]))
    invalid.append(_forest([['null'],['object',[['z',0],['a',0]]]]))
    invalid.append(_forest([['null'],['object',[['a',0],['a',0]]]]))
    invalid.append(_forest([['int','01']]))
    invalid.append(_forest([['float','0']]))
    invalid.append(_forest([['float','NaN']]))
    invalid.append(_forest([['str','\ud800']]))
    for name,w in zip(EXPECTED_DIAGNOSTICS[3:15],invalid):
        announce(name);passed(name,expect(lambda w=w:prepare(w),'data'))

    name=EXPECTED_DIAGNOSTICS[15];announce(name)
    passed(name,expect(lambda:prepare(_clone(base),dict(work=True)),'data'))
    name=EXPECTED_DIAGNOSTICS[16];announce(name);w=_forest([['str','\n'*3]])
    bad=expect(lambda:prepare(_clone(w),dict(scalar_bytes=7)),'limit','scalar bytes')
    p=prepare(_clone(w),dict(scalar_bytes=8));r=_drain(p,'d',_canonical('\n'*3),boundary)
    passed(name,dict(rejected_at7=bad,accepted_at8=r))
    name=EXPECTED_DIAGNOSTICS[17];announce(name);w=_forest([['int','0'],['array',[0]],['array',[1]],['array',[2]]])
    bad=expect(lambda:prepare(_clone(w),dict(depth=3)),'limit','depth')
    p=prepare(_clone(w),dict(depth=4));passed(name,dict(rejected_at3=bad,accepted_at4=_drain(p,'d',b'[[[0]]]',boundary)))
    name=EXPECTED_DIAGNOSTICS[18];announce(name);w=_forest([['int','0'],['array',[0]*16]])
    wanted=_canonical([0]*16);size=len(wanted)+1
    bad=expect(lambda:prepare(_clone(w),dict(expanded_bytes=size-1)),'limit','aggregate document bytes')
    p=prepare(_clone(w),dict(expanded_bytes=size));passed(name,dict(exact_logical_bytes=size,rejected_below=bad,
        accepted=_drain(p,'d',wanted,boundary)))
    name=EXPECTED_DIAGNOSTICS[19];announce(name);size=len(_canonical(base))+1
    bad=expect(lambda:prepare(_clone(base),dict(wire_bytes=size-1)),'limit','wire bytes')
    p=prepare(_clone(base),dict(wire_bytes=size));passed(name,dict(exact_wire_bytes=size,rejected_below=bad,
        accepted=_drain(p,'d',b'null',boundary)))
    name=EXPECTED_DIAGNOSTICS[20];announce(name);obs={}
    bad=expect(lambda:prepare(_clone(base),dict(work=1),observation=obs),'limit','work')
    _need(obs['attempted_operations']==2 and obs['prepared']is False,'exact work-cap refusal before authority')
    passed(name,dict(refusal=bad,attempted_operations=obs['attempted_operations'],prepared=False))

    name=EXPECTED_DIAGNOSTICS[21];announce(name)
    long=_forest([['int','0'],['array',[0]*4096]])
    p=prepare(long,dict(cache_bytes=0,cache_entries=0,chunk_bytes=32))
    initial=p.statistics();_need(initial['callback_dispatches_by_reason'].get('initial')==1 and
        initial['callback_dispatches_by_reason'].get('preparation_completion')==1 and
        initial['callback_dispatches_by_reason'].get('operation_cadence',0)>0,'initial/preparation/cadence forced')
    _need(p.documents==('d',)and len(p.catalogue)==1,'complete public read projections')
    r=_drain(p,'d',_canonical([0]*4096),boundary);stats=p.statistics();reasons=stats['callback_dispatches_by_reason']
    _need(stats['callback_cadence_operations']==1024 and 0<=stats['maximum_callback_operation_gap']<=1024 and
        stats['pending_callback_operations']==0 and all(reasons.get(k,0)>0 for k in
            ('documents_entry','catalogue_entry','document_stream_entry','document_pull_entry','yield_chunk','document_completion')),
        'full finite callback gap/public entry/completion evidence')
    passed(name,dict(r,maximum_callback_operation_gap=stats['maximum_callback_operation_gap'],
        reasons=reasons,attempted_operations=stats['attempted_operations']))

    name=EXPECTED_DIAGNOSTICS[22];announce(name)
    p=prepare(_forest([['str','abcdefghij']]),dict(chunk_bytes=4));s=p.iter_document('d');parts=[]
    try:
        for count in range(3):
            boundary.tick();part=next(s);_need(len(part)==4,'exact finite chunk boundary');parts.append(part)
        _need(b''.join(parts)==b'"abcdefghij"'and s.completed is False,'last byte is not completion')
        try:next(s)
        except StopIteration:_need(s.completed is True,'mandatory trailing pull completion')
        else:raise QualificationError('extra BODY chunk')
        before=p.statistics()['callback_dispatches']
        try:next(s)
        except StopIteration:pass
        else:raise QualificationError('closed stream did not stop')
        _need(p.statistics()['callback_dispatches']==before,'closed next has no delegated callback')
    finally:s.close()
    passed(name,dict(chunks=3,last_chunk_requires_trailing_pull=True,closed_next_callback_delta=0))

    name=EXPECTED_DIAGNOSTICS[23];announce(name);identities=[]
    for cls in (RuntimeError,ValueError,StopIteration):
        sentinel=cls('finite-inverse-prepare-callback-sentinel')
        def injected():boundary.tick();raise sentinel
        try:prepare(_clone(base),check=injected)
        except BaseException as error:
            if boundary.foreign is not None:raise boundary.foreign
            if error is not sentinel:raise
        else:raise QualificationError('foreign prepare callback accepted')
        identities.append(cls.__name__)
    passed(name,dict(exact_exception_objects=identities,initial_checkpoint=True))

    name=EXPECTED_DIAGNOSTICS[24];announce(name);identities=[]
    for cls in (RuntimeError,ValueError,StopIteration):
        sentinel=cls('finite-inverse-stream-callback-sentinel');armed=[False]
        def injected():
            boundary.tick()
            if armed[0]:raise sentinel
        p=prepare(_clone(base),check=injected);s=p.iter_document('d');armed[0]=True
        try:
            try:next(s)
            except BaseException as error:
                if boundary.foreign is not None:raise boundary.foreign
                if error is not sentinel:raise
            else:raise QualificationError('foreign stream callback accepted')
            _need(s.completed is False,'foreign callback cannot complete stream')
            identities.append(cls.__name__)
        finally:s.close()
    passed(name,dict(exact_exception_objects=identities,manual_next=True,completed=False))

    name=EXPECTED_DIAGNOSTICS[25];announce(name);holder=[None];sentinel=StopIteration('late-completion-callback')
    def late():
        boundary.tick()
        if holder[0]is not None and holder[0].statistics()['callback_dispatches_by_reason'].get('document_completion',0):
            raise sentinel
    p=prepare(_clone(base),check=late);holder[0]=p;s=p.iter_document('d')
    try:
        _need(next(s)==b'null'and s.completed is False,'body complete before final pull')
        try:next(s)
        except BaseException as error:
            if boundary.foreign is not None:raise boundary.foreign
            if error is not sentinel:raise
        else:raise QualificationError('late callback was not observed')
        _need(s.completed is False,'late foreign StopIteration never admits completion')
    finally:s.close()
    passed(name,dict(exact_StopIteration_identity=True,body_already_returned=True,completed=False))

    name=EXPECTED_DIAGNOSTICS[26];announce(name);holder=[None];armed=[False];seen=[None]
    def recursive():
        boundary.tick()
        if armed[0]:
            armed[0]=False
            _need(type(holder[0].statistics())is dict,'passive callback statistics permitted')
            try:holder[0].documents
            except BaseException as error:seen[0]=error;raise
    p=prepare(_clone(base),check=recursive);holder[0]=p;s=p.iter_document('d');armed[0]=True
    try:
        try:next(s)
        except BaseException as error:
            if boundary.foreign is not None:raise boundary.foreign
            if error is not seen[0]or not inverse.is_own_reentrancy(error):raise
        else:raise QualificationError('charged callback recursion accepted')
        _need(s.completed is False,'reentrancy failure not completed')
    finally:s.close()
    passed(name,dict(passive_statistics=True,own_reentrancy_identity=True,completed=False))

    name=EXPECTED_DIAGNOSTICS[27];announce(name);p=prepare(_clone(base));s=p.iter_document('d')
    s.close();before=p.statistics()['callback_dispatches']
    try:next(s)
    except StopIteration:pass
    else:raise QualificationError('closed incomplete stream emitted bytes')
    _need(s.completed is False and p.statistics()['callback_dispatches']==before and
        p.statistics()['documents']['d']['closed_incomplete']is True,'close cannot invent completion')
    passed(name,dict(completed=False,closed_incomplete=True,closed_next_callback_delta=0))

    name=EXPECTED_DIAGNOSTICS[28];announce(name);observed=[]
    cache_wire=_forest([['int',str(i)]for i in range(600)]+[['array',list(range(600))*2]])
    for target in ('validation_cadence','cache_build_cadence','preparation_completion'):
        for cls in (RuntimeError,ValueError,StopIteration):
            sentinel=cls('finite-current-prepare-phase-callback');obs={};reached=[None]
            def injected_phase():
                boundary.tick();phase_name=obs.get('phase');operation=obs.get('last_operation')
                hit=((target=='validation_cadence'and phase_name=='VALIDATE_COMPLETE_FOREST')or
                     (target=='cache_build_cadence'and phase_name=='BUILD_BOUNDED_FOREST_FRAGMENTS'and
                         operation!='preparation_completion')or
                     (target=='preparation_completion'and operation=='preparation_completion'))
                if hit:
                    reached[0]=dict(target=target,phase=phase_name,operation=operation,
                                    exception_type=cls.__name__)
                    raise sentinel
            try:prepare(_clone(cache_wire),check=injected_phase,observation=obs)
            except BaseException as error:
                if boundary.foreign is not None:raise boundary.foreign
                if error is not sentinel:raise
            else:raise QualificationError('declared validation/cache/completion callback was not reached')
            _need(reached[0]is not None and obs['prepared']is False,
                  'actually invoked prepare phase, exact foreign exception and no partial prepared authority')
            observed.append(reached[0])
    _need(len(observed)==9,'all three exception classes at all three prepare phases')
    passed(name,dict(observations=observed,exact_identity=True,private_State_access=False))

    name=EXPECTED_DIAGNOSTICS[29];announce(name);observed=[]
    targets=('documents_entry','catalogue_entry','document_stream_entry',
             'yield_chunk','document_completion','operation_cadence')
    for target in targets:
        for cls in (RuntimeError,ValueError,StopIteration):
            sentinel=cls('finite-current-public-stream-phase-callback')
            holder=[None];armed=[False];baseline=[0];reached=[None]
            def injected_public():
                boundary.tick()
                if not armed[0]or holder[0]is None:return
                stats=holder[0].statistics();reasons=stats['callback_dispatches_by_reason']
                if reasons.get(target,0)>baseline[0]and (target!='operation_cadence'or stats['phase']=='STREAM_DOCUMENT'):
                    reached[0]=dict(target=target,phase=stats['phase'],last_operation=stats['last_operation'],
                                    exception_type=cls.__name__)
                    raise sentinel
            w=(_forest([['int','0'],['array',[0]*4096]])if target=='operation_cadence'else _clone(base))
            p=prepare(w,dict(cache_bytes=0,cache_entries=0),check=injected_public);holder[0]=p;s=None
            if target not in ('documents_entry','catalogue_entry','document_stream_entry'):
                s=p.iter_document('d')
                if target=='document_completion':
                    _need(next(s)==b'null'and s.completed is False,'late callback after exact BODY')
            baseline[0]=p.statistics()['callback_dispatches_by_reason'].get(target,0);armed[0]=True
            try:
                try:
                    if target=='documents_entry':p.documents
                    elif target=='catalogue_entry':p.catalogue
                    elif target=='document_stream_entry':p.iter_document('d')
                    else:next(s)
                except BaseException as error:
                    if boundary.foreign is not None:raise boundary.foreign
                    if error is not sentinel:raise
                else:raise QualificationError('declared public/yield/completion/cadence checkpoint was not reached')
                _need(reached[0]is not None,'actually invoked current callback checkpoint')
                if s is not None:_need(s.completed is False,'foreign checkpoint failure cannot complete stream')
                observed.append(reached[0])
            finally:
                if s is not None:s.close()
    _need(len(observed)==18,'three exact exception classes at all six public/stream checkpoints')
    passed(name,dict(observations=observed,exact_identity=True,manual_next=True,private_State_access=False))
    _need(tuple(r['name']for r in rows)==EXPECTED_DIAGNOSTICS,'all and only diagnostic groups retained')


def _whole(inverse,row,boundary,phase,reference):
    boundary.full();phase.update(stage='WHOLE_INPUT',mode=row['mode'],observer={})
    # Full raw files are freshly pinned; no failed-input recovery or V6 call.
    raw=_raw(row['forest'],boundary);wire=json.loads(raw);del raw
    prepared=inverse.prepare_forest(wire,boundary.tick,limits=dict(LIMITS),statistics=phase['observer'])
    del wire
    _need(prepared.documents==(DOCUMENT,),'same sole complete legacy result document')
    source=prepared.iter_document(DOCUMENT);expected=row['result'];p=Path(expected['path'])
    _need(p.is_absolute()and p==p.resolve(),'canonical original result path')
    boundary.tick();fd=os.open(str(p),os.O_RDONLY|os.O_NOFOLLOW);digest=hashlib.sha256();size=0
    try:
        info=os.fstat(fd);_need(stat.S_ISREG(info.st_mode)and info.st_size==expected['bytes'],'full original result regular size')
        while True:
            boundary.tick()
            try:chunk=next(source)
            except StopIteration:
                if source.completed is not True:raise
                break
            _need(type(chunk)is bytes and len(chunk)<=LIMITS['chunk_bytes'],'bounded reconstructed chunk')
            actual=bytearray()
            while len(actual)<len(chunk):
                boundary.tick();part=os.read(fd,len(chunk)-len(actual))
                _need(bool(part),'original result ended before complete reconstructed BODY');actual.extend(part)
            _need(chunk==actual,'every full reconstructed BODY byte equals original')
            digest.update(actual);size+=len(actual);_need(size<=expected['bytes'],'complete result size cap')
        _need(source.completed is True,'explicit full reconstructed stream completion')
        boundary.tick();tail=os.read(fd,2);_need(tail==b'\n','one external LF and original full EOF')
        digest.update(tail);size+=1
        _need(size==expected['bytes']and digest.hexdigest()==expected['sha256'],'full original result bytes/hash/EOF')
    finally:
        os.close(fd);source.close()
    stats=prepared.statistics();phase['observer']=stats
    _need(stats['prepared']is True and stats['logical_documents']==1 and
        stats['wire_canonical_bytes']==row['forest']['bytes']and stats['aggregate_document_bytes']==size,
        'whole physical and expanded file ledgers')
    d=stats['documents'][DOCUMENT]
    _need(d['completed']is True and d['attempts']==1 and d['closed_incomplete']is False and
        d['copied_body_bytes']==d['emitted_body_bytes']==size-1 and
        d['stream_value_occurrences']==d['logical_value_occurrences'],'every full document byte/occurrence')
    _need(stats['callback_cadence_operations']==1024 and stats['maximum_callback_operation_gap']<=1024 and
        stats['pending_callback_operations']==0,'whole current callback cadence and completion')
    comparison=None
    if row['mode']=='symbolic':
        _need(stats['attempted_operations']==reference['attempted_operations']==21304533 and
            _canonical(stats['operations_by_kind'])==_canonical(reference['operations_by_kind']),
            'same complete V6 per-kind attempted-operation preimage, no V6 execution')
        comparison=dict(attempted_operations_equal=True,all_per_kind_equal=True,
            V6_callback_dispatches=reference['callback_dispatches'],V7_callback_dispatches=stats['callback_dispatches'],
            scope='Same complete valid input and same public traversal sequence; changed callback scheduling/profile, no speed claim.')
    boundary.full()
    return dict(schema='inverse-cadence-whole-input-qualification-v1',mode=row['mode'],
        status='complete',forest=row['forest'],original_result=row['result'],
        reconstructed_complete_file_bytes=size,full_original_file_sha256=digest.hexdigest(),
        explicit_completed=True,statistics=stats,V6_retained_reference_comparison=comparison,
        representation_only=True,mathematical_authority=False,
        prior_fixed_failure_recovered=False)


def run_inverse_qualification(*,inverse_module,inputs,reference_stats,check,source_guard,now,
                              work_deadline,closure_deadline,progress=None):
    """Only a separately reviewed Root once wrapper may invoke this function.

    Normal own deadline/private evidence limit returns UNKNOWN with completed
    prefix. Unexpected callback/data/Source exceptions propagate unchanged with
    best-effort bounded metadata attached; they are never passed fixtures.
    """
    boundary=_Boundary(check,source_guard,now,work_deadline)
    _need(type(closure_deadline)in(int,float)and math.isfinite(closure_deadline)and
        closure_deadline>work_deadline,'separate later metadata-only closure deadline')
    _need(progress is None or callable(progress),'optional progress callback')
    result=dict(schema=RESULT_SCHEMA,version=VERSION,status='NOT_STARTED',
        source_only_authorship_not_execution_authority=True,representation_only=True,
        mathematical_authority=False,scientific_acceptance=False,ROOT_resource_accepted=False,
        inputs=inputs,reference_stats=reference_stats,diagnostics=[],whole_inputs=[],
        limits=dict(inverse=LIMITS,diagnostics=FIXTURE_LIMITS,work_deadline=work_deadline,
            closure_deadline=closure_deadline,outer_worker_peak_bytes=1073741824,
            outer_physical_and_logical_bytes=134217728,outer_logs_bytes=4194304),
        stage='AUTHENTICATE',started_monotonic=None,completed_monotonic=None)
    phase=dict(stage='AUTHENTICATE',observer=None)
    try:
        boundary.full();result['started_monotonic']=boundary.last
        _need(_canonical(inputs)==_canonical(INPUTS)and _canonical(reference_stats)==_canonical(REFERENCE_STATS),
            'all and only exact two complete frozen input pairs and retained reference')
        original_inputs=inputs;original_reference=reference_stats
        original_input_bytes=_canonical(inputs);original_reference_bytes=_canonical(reference_stats)
        inputs=_clone(inputs);reference_stats=_clone(reference_stats)
        result['inputs']=inputs;result['reference_stats']=reference_stats
        result['owned_inverse_source']=_authenticate(inverse_module,boundary)
        reference= json.loads(_raw(reference_stats,boundary))['evidence_verification']['statistics']
        _need(reference['attempted_operations']==21304533 and reference['callback_dispatches']==21304533,
            'exact retained V6 reference counters')
        # Pin every original file before any diagnostic or preparation. Result
        # bodies are not JSON-decoded or retained as a second logical tree.
        raw_bytes=0
        for row in inputs:
            for key in ('forest','result'):
                raw=_raw(row[key],boundary);raw_bytes+=len(raw);del raw
        _need(raw_bytes==101004580 and raw_bytes<=134217728,'full four artifact aggregate, no smaller subset')
        result['complete_original_raw_input_bytes']=raw_bytes
        result['stage']='DIAGNOSTICS'
        _diagnostics(inverse_module,boundary,result['diagnostics'],phase,progress)
        result['stage']='WHOLE_INPUTS'
        for row in inputs:
            if progress is not None:boundary.call(lambda:progress(dict(stage='WHOLE_INPUT',mode=row['mode'])))
            started=boundary.call(now)
            packet=_whole(inverse_module,row,boundary,phase,reference)
            packet['started_monotonic']=started;packet['completed_monotonic']=boundary.call(now)
            result['whole_inputs'].append(packet)
        _need(_canonical(original_inputs)==original_input_bytes and
            _canonical(original_reference)==original_reference_bytes,
            'caller input/reference descriptors unchanged through complete qualification')
        boundary.full();result['stage']='COMPLETE';result['status']='FINITE_REPRESENTATION_QUALIFIED'
        result['completed_monotonic']=boundary.last
        _need(len(result['diagnostics'])==len(EXPECTED_DIAGNOSTICS)and len(result['whole_inputs'])==2,
            'no partial normal qualification authority')
        return result
    except BaseException as error:
        if boundary.foreign is not None:
            error=boundary.foreign
        work_stop=(type(error)is QualificationDeadline and error._owner is _TOKEN)
        normal=work_stop
        if not normal and boundary.foreign is None:
            normal=inverse_module.is_own_limit(error)
        result['stage']=phase['stage'];result['partial_phase']=phase
        result['completed_monotonic']=boundary.last
        result['status']=('UNKNOWN_WORK_DEADLINE'if work_stop else
                          'UNKNOWN_EVIDENCE_LIMIT'if normal else'FAILED_UNEXPECTED_EXCEPTION')
        result['error']=dict(type=type(error).__name__,message=str(error)[:4096],
                            reason=getattr(error,'reason',None))
        result['complete_output_qualified']=False
        if normal:return result
        try:error.inverse_qualification_prefix=result
        except BaseException:pass
        raise error
