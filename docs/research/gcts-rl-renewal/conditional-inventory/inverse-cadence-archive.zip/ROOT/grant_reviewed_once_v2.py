"""Root adoption of exact independently reviewed metadata; no component evaluation."""
from pathlib import Path
import hashlib
import json
D=Path('/private/tmp/gcts-inverse-cadence-ROOT-20261019')
C=Path('/private/tmp/gcts-inverse-cadence-peer-20261019')

def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def pin(p):
    p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def contains(v,w):
    if v==w:return True
    if type(v)is dict:return any(contains(x,w)for x in v.values())
    if type(v)is list:return any(contains(x,w)for x in v)
    return False
def write(name,v):
    p=D/name
    with p.open('x')as f:json.dump(v,f,sort_keys=True,indent=2,allow_nan=False);f.write('\n')
    return pin(p)

plan=json.loads((D/'plan-false-v2.json').read_bytes())
subject={k:v for k,v in plan.items()if k!='authorization'}
digest=hashlib.sha256(canonical(subject)).hexdigest()
assert len(subject)==13 and not Path(plan['actual_directory']).exists()
for k in ('python','worker','harness','inverse','runner','observer','reference','declaration'):
    assert pin(plan[k]['path'])==plan[k]
for row in plan['inputs']:
    for k in ('forest','result'):assert pin(row[k]['path'])==row[k]
schemas=dict(Source='inverse-cadence-qualification-components-Source-review-v1',
             plans='inverse-cadence-qualification-prospective-plan-review-v1')
reviews={};payloads={}
for role,schema in schemas.items():
    matches=[]
    for path in C.glob('*.json'):
        v=json.loads(path.read_bytes())
        if v.get('schema')==schema and v.get('source_review_passed' if role=='Source' else 'prospective_review_passed')is True:matches.append((path,v))
    assert len(matches)==1,(role,len(matches))
    path,v=matches[0]
    assert v['reviewer_identity']=='/root/conventional_control_review'
    assert v['source_only']is True and v['scientific_calls']==0
    assert v['actual_execution_authorized']is False and v['scientific_acceptance']is False
    if role=='Source':
        assert v['source_review_passed']is True and v['author_identities']==['/root','/root/conventional_library']
        for key in ('worker','harness','inverse','runner','observer'):assert contains(v,plan[key]),key
    else:
        assert v['prospective_review_passed']is True and v['subject']==subject and v['subject_sha256']==digest
        assert contains(v,plan['declaration'])
    reviews[role]=pin(path);payloads[role]=v

adoption=write('ROOT-scope-adoption-v1.json',dict(schema='ROOT-inverse-cadence-scope-adoption-v1',
    author_identity='/root',subject=subject,subject_sha256=digest,reviews=reviews,
    disposition='Adopt exact finite Source and prospective-plan review for one inverse-only qualification under unchanged global gates. No inherited mathematical soundness or search acceptance follows.',
    roles='Root coordinates/authors inverse and wrappers; Library authored new harness; Control independently reviews both. Historical helper/algorithm author overlaps remain disclosed in linked inverse Source review.',
    unresolved=['Actual30finite diagnostics and bothfullbyte comparisons','Known worker exit and all final gates before180; external terminal before210','Standalone worker1GiB peak','Fresh full matched pipeline pair after qualifier pass','No held-out theorem or RL/search-method advantage demonstrated'],
    mathematical_changes=False,scientific_acceptance=False,goal_complete=False))
auth=write('authorization-true-v1.json',dict(schema='ROOT-inverse-cadence-once-authorization-v1',
    author_identity='/root',actual_execution_authorized=True,maximum_actual_invocations=1,
    subject_sha256=digest,review_roles=reviews,ROOT_scope_adoption=adoption,
    scope='Exactly one fresh inverse-only worker; no Native/Arena/Model/search/oldinverse execution. No unchanged retry.'))
plan['authorization']=auth
assert {k:v for k,v in plan.items()if k!='authorization'}==subject
print(json.dumps(write('plan-authorized-v1.json',plan),sort_keys=True))
