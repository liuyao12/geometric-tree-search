"""Inert Source-only refinement after independent findings; no component calls."""
from pathlib import Path
import ast
import hashlib
D=Path('/private/tmp/gcts-inverse-cadence-ROOT-20261019')
s=(D/'qualify_inverse_worker_v2.py').read_text()
s=s.replace('inverse-cadence-qualification-worker-v2','inverse-cadence-qualification-worker-v3')
s=s.replace('inverse-cadence-qualification-worker-receipt-v1','inverse-cadence-qualification-worker-receipt-v3')
s=s.replace('calls = 0; deadline = [None]; progress_rows = []; payload = None; result_pin = None',
            'calls = 0; deadline = [None]; progress_rows = []; progress_bytes = 0; payload = None; result_pin = None')
a=s.index('    def progress(row):')
b=s.index('\n    try:\n        guard(); check()',a)
s=s[:a]+'''    def progress(row):
        nonlocal progress_bytes
        check()
        need(type(row) is dict, 'ordinary progress packet')
        body = canonical(row)
        need(len(body) <= 131072 and progress_bytes + len(body) <= 1048576,
             'bounded individual and aggregate progress bytes')
        need(len(progress_rows) < 256, 'finite progress census')
        progress_rows.append(json.loads(body)); progress_bytes += len(body)
''' +s[b:]
a=s.index('    except BaseException as error:\n        save_new(')
b=s.index('\n\n\nif __name__',a)
s=s[:a]+'''    except BaseException as error:
        # Failure diagnostics cannot replace the exact active exception.
        try:
            prefix = payload if payload is not None else getattr(error, 'inverse_qualification_prefix', None)
            if prefix is not None and len(canonical(prefix)) > 2097152: prefix = None
            status = ('UNKNOWN_WORK_DEADLINE' if deadline[0] is not None else
                      prefix['status'] if type(prefix) is dict and
                      prefix.get('status') in ('UNKNOWN_WORK_DEADLINE', 'UNKNOWN_EVIDENCE_LIMIT') else
                      'FAILED_QUALIFICATION')
            save_new(actual / 'worker-failure.json', dict(
                schema='inverse-cadence-qualification-worker-failure-v1', status=status,
                type=type(error).__name__, message=str(error)[:8192],
                progress_prefix=progress_rows, qualification_prefix=prefix,
                result_candidate=result_pin, delegated_callbacks=calls,
                representation_accepted=False, scientific_acceptance=False, Native_calls=0))
        except BaseException: pass
        raise
''' +s[b:]
out=D/'qualify_inverse_worker_v3.py';ast.parse(s);compile(s,str(out),'exec');out.write_text(s)

s=(D/'run_inverse_once_v2.py').read_text().replace('inverse-cadence-once-runner-v2','inverse-cadence-once-runner-v3')
s=s.replace('inverse-cadence-qualification-worker-receipt-v2','inverse-cadence-qualification-worker-receipt-v3')
out=D/'run_inverse_once_v3.py';ast.parse(s);compile(s,str(out),'exec');out.write_text(s)
old=(D/'observe_inverse_once_v2.py').read_text().replace('inverse-cadence-final-terminal-observer-v2','inverse-cadence-final-terminal-observer-v3')
old=old.replace(hashlib.sha256((D/'run_inverse_once_v2.py').read_bytes()).hexdigest(),hashlib.sha256(s.encode()).hexdigest())
out=D/'observe_inverse_once_v3.py';ast.parse(old);compile(old,str(out),'exec');out.write_text(old)
print('Refined three Source wrappers; three unused compiles; no evaluation.')
