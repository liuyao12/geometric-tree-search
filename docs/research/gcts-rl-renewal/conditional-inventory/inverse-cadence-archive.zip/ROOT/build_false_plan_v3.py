"""Prospective raw descriptors and AST literal census only. No component evaluation."""
from pathlib import Path
import ast
import hashlib
import json

D=Path('/private/tmp/gcts-inverse-cadence-ROOT-20261019')
L=Path('/private/tmp/gcts-inverse-cadence-library-20261019')

def pin(path):
    p=Path(path).resolve();b=p.read_bytes()
    return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())

def write(name,value):
    p=D/name
    with p.open('x')as f:json.dump(value,f,sort_keys=True,indent=2,allow_nan=False);f.write('\n')
    return pin(p)

harness=L/'inverse_cadence_qualification_v2.py'
tree=ast.parse(harness.read_text())
constants={}
for node in tree.body:
    if type(node)is ast.Assign and len(node.targets)==1 and type(node.targets[0])is ast.Name:
        try:constants[node.targets[0].id]=ast.literal_eval(node.value)
        except (ValueError,TypeError):pass
expected=list(constants['EXPECTED_DIAGNOSTICS'])
assert len(expected)==30 and len(set(expected))==30
inputs=constants['INPUTS'];reference=constants['REFERENCE_STATS']
assert [row['mode']for row in inputs]==['fixed','symbolic']
for row in inputs:
    for key in ('forest','result'):assert pin(row[key]['path'])==row[key]
assert pin(reference['path'])==reference
declaration=write('qualification-declaration-v2.json',dict(
    schema='ROOT-inverse-cadence-qualification-declaration-v1',source_only=True,
    author_identity='/root',component_authors=['/root','/root/conventional_library'],
    inverse_version=constants['INVERSE_VERSION'],execution_profile=constants['INVERSE_PROFILE'],
    expected_fixture_names=expected,diagnostic_groups=30,exact_inputs=inputs,exact_reference=reference,
    preserved_numeric_caps='180s positive including setup+known exit+whole final checks;210s external terminal;1GiB standalone worker highwater;128MiB both logical and physical+metadata;4MiB per log. No Native calls.',
    output_policy='All two complete BODY byte streams plus sole external LF compared to full ordinary saved results; no oldinverse evaluation or mathematical result decoding. Physical new result+all metadata bounded with9MiB reserved for outer.',
    scope='Fresh finite independent inverse qualification only. Fixed historical integration remains failed. No theorem/search/RL/control-performance acceptance. Complete new full matched pipeline pair still required after a pass.',
    algorithm_contract=dict(path='/private/tmp/gcts-owned-evidence-integration-ROOT-20261019/basic-tiling-algorithm.md',sha256='c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9',bytes=21657),
    mathematical_conformance='No Model, Native, t/m values, point/candidate graph, propagation, earliest-generation branching, rollback, mathematical rule or receiver input is changed or evaluated.',
    actual_execution_authorized=False,scientific_calls=0,scientific_acceptance=False))
auth=write('authorization-false-v2.json',dict(schema='ROOT-inverse-cadence-once-authorization-v1',
    author_identity='/root',actual_execution_authorized=False,maximum_actual_invocations=0))
plan=dict(schema='ROOT-inverse-cadence-once-plan-v1',
    invocation_id='inverse-cadence-two-full-forests-ROOT-20261019-v1',
    actual_directory=str(D/'actual-v1'),
    python=pin('/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12'),
    worker=pin(D/'qualify_inverse_worker_v3.py'),harness=pin(harness),inverse=pin(D/'independent_forest_inverse_v7.py'),
    runner=pin(D/'run_inverse_once_v3.py'),observer=pin(D/'observe_inverse_once_v3.py'),
    inputs=inputs,reference=reference,declaration=declaration,authorization=auth,
    limits=dict(work_seconds=180,overall_seconds=210,memory_bytes=1073741824,result_bytes=134217728,
                expanded_bytes=134217728,stdout_bytes=4194304,stderr_bytes=4194304))
p=write('plan-false-v2.json',plan)
print(json.dumps(p,sort_keys=True))
