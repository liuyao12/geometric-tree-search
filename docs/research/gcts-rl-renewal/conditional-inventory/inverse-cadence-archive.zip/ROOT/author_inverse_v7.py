from pathlib import Path
import ast,hashlib,json,difflib
D=Path('/private/tmp/gcts-inverse-cadence-ROOT-20261019');parent=Path('/private/tmp/gcts-incremental-arena-ROOT-20261019/independent_forest_inverse_v6.py');raw=parent.read_bytes();assert hashlib.sha256(raw).hexdigest()=='fbd655a86424ce5634ce0307af62549f5b1c4412cb9e58b752df0e13ae2397e4'
s=raw.decode();s=s.replace("VERSION='independent-evidence-forest-inverse-v6-full-scalar-and-ledger-bounds'","VERSION='independent-evidence-forest-inverse-v7-bounded-callback-cadence'")
s=s.replace("EXECUTION_PROFILE='independent-forest-actual-operations-v1'","EXECUTION_PROFILE='independent-forest-actual-operations-v2-callback-cadence1024'\nCHECKPOINT_OPERATIONS=1024\n_BOUNDARY_OPERATIONS=frozenset(('initial','yield_chunk','preparation_completion','document_completion'))")
s=s.replace("self.check=check;self.cap=cap;self.observer=observer;self.in_callback=False","self.check=check;self.cap=cap;self.observer=observer;self.in_callback=False\n        self.last_callback_operation=0")
s=s.replace("attempted_operations=0,operations_by_kind={},callback_dispatches=0,","attempted_operations=0,operations_by_kind={},callback_dispatches=0,\n            callback_cadence_operations=CHECKPOINT_OPERATIONS,callback_dispatches_by_reason={},\n            last_callback_operation=0,maximum_callback_operation_gap=0,")
a=s.index('    def tick(self,kind):');b=s.index('    def snapshot(self):',a)
old=s[a:b]
new='''    def dispatch(self,reason):
        # A checkpoint delegates the supplied clock/guard, not mathematical
        # authority. All attempted operations/cap tests remain in tick.
        self.gate();s=self.stats;n=s['attempted_operations']
        gap=n-self.last_callback_operation
        s['maximum_callback_operation_gap']=max(s['maximum_callback_operation_gap'],gap)
        self.last_callback_operation=n;s['last_callback_operation']=n
        s['callback_dispatches']+=1
        reasons=s['callback_dispatches_by_reason'];reasons[reason]=reasons.get(reason,0)+1
        self.in_callback=True
        try:self.check()
        except BaseException:
            self.publish_preserving_error();raise
        finally:self.in_callback=False
    def tick(self,kind):
        self.gate();s=self.stats;s['last_operation']=kind
        s['attempted_operations']+=1
        s['operations_by_kind'][kind]=s['operations_by_kind'].get(kind,0)+1
        if self.observer is not None:
            self.observer['phase']=s['phase'];self.observer['last_operation']=kind
        if s['attempted_operations']>self.cap['work']:_stop('work')
        if kind in _BOUNDARY_OPERATIONS:self.dispatch(kind)
        elif s['attempted_operations']-self.last_callback_operation>=CHECKPOINT_OPERATIONS:
            self.dispatch('operation_cadence')
'''
s=s[:a]+new+s[b:]
s=s.replace("s=dict(self.stats);s['operations_by_kind']=dict(self.stats['operations_by_kind'])","s=dict(self.stats);s['operations_by_kind']=dict(self.stats['operations_by_kind'])\n        s['callback_dispatches_by_reason']=dict(self.stats['callback_dispatches_by_reason'])\n        s['pending_callback_operations']=s['attempted_operations']-self.last_callback_operation")
s=s.replace("        try:part=self._advance()","        try:\n            state.dispatch('document_pull_entry')\n            part=self._advance()")
s=s.replace("        self._state.gate();out=[]","        self._state.gate();self._state.dispatch('documents_entry');out=[]")
s=s.replace("        self._state.gate();self._state.tick('catalogue_read');return self._catalogue","        self._state.gate();self._state.dispatch('catalogue_entry');self._state.tick('catalogue_read');return self._catalogue")
s=s.replace("        state=self._state;state.gate();state.metrics(label);found=[]","        state=self._state;state.gate();state.dispatch('document_stream_entry');state.metrics(label);found=[]")
s=s.replace('The forest\nprofile is new; old per-call and default20m qualifications are not inherited.','Only delegated callback scheduling/bookkeeping changes from V6. Every old\nvalidation operation and its work-cap test remains. New explicit profile;\nno old callback ordinal/timing coverage or qualification is inherited.\nThe cadence bounds operations, not elapsed latency; final work/terminal gates\nremain mandatory. Closed-stream next and passive statistics never delegate.')
p=D/'independent_forest_inverse_v7.py';assert not p.exists();p.write_text(s);ast.parse(s);compile(s,str(p),'exec')
forward=''.join(difflib.unified_diff(raw.decode().splitlines(True),s.splitlines(True),fromfile='a/inverse.py',tofile='b/inverse.py'));(D/'inverse-v6-v7.patch').write_text(forward)
def pin(q):
 b=q.read_bytes();return dict(path=str(q),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
record=dict(schema='ROOT-inverse-cadence-Source-contract-v1',author_identity='/root',source_only=True,scientific_calls=0,Source_evaluation=False,actual_execution_authorized=False,goal_complete=False,parent=pin(parent),source=pin(p),changed_execution_profile='independent-forest-actual-operations-v2-callback-cadence1024',cadence_operations=1024,forced_callbacks=['first operation','each document pull before work while not closed','public documents/catalogue/iter_document entry','before each emitted chunk','before preparation/doc successful completion'],unchanged='All validator branches, every old attempted operation/per-kind unit and unconditional work-cap test, all numeric/default caps, wire/API/body bytes and independent ledgers. No arena/adapter/Model/Native/search change.',callback_scope='Changed actual dispatch opportunities and ordinal/timing, not unchanged V6 fault coverage. Operation cadence is no elapsed-latency bound. Statistics and closed-stream next/cleanup do not invoke callbacks. Exact dispatched foreign exceptions and private reentrancy/quota ownership retained; no concurrent/hostile private-attribute sandbox claim.',count_semantics='Added dispatches do not add attempted-operation units. Valid complete inputs under same API call sequence/cache should retain exact old per-kind operation counts; new callback bookkeeping is separate.',pending=['Independent Source/inert-delta review','Fresh bounded finite qualification with full2 saved forest reconstructions and fault/cap/cadence checks','Fresh common-profile full original001 fixed/symbolic pair after qualification','Publication/live byte/browser validation'],patch=pin(D/'inverse-v6-v7.patch'),unused_compile_count=1)
(D/'Source-contract-v1.json').write_text(json.dumps(record,sort_keys=True,indent=2)+'\n');print(json.dumps(record['source']))
