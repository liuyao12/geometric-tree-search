"""Format saved metadata as HTML; archive raw evidence. No component evaluation."""
from pathlib import Path
import hashlib
import html
import json
import zipfile

D=Path('/private/tmp/gcts-inverse-cadence-ROOT-20261019')
L=Path('/private/tmp/gcts-inverse-cadence-library-20261019')
C=Path('/private/tmp/gcts-inverse-cadence-peer-20261019')
PUB=Path('/private/tmp/gcts-split-controls-publish-20261015')
WEB=PUB/'docs/research/gcts-rl-renewal/conditional-inventory'
OUT=D/'publication-v1'

def pin(p):
    p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def write(name,v):
    p=OUT/name;p.write_text(json.dumps(v,sort_keys=True,indent=2,allow_nan=False)+'\n');return pin(p)
def m(v):return '\\('+str(v)+'\\)'
def number(v):return m(format(v,',').replace(',',r'\,'))
def seconds(v):return m(f'{v:.3f}'+r'\,\mathrm{s}')
def block(v):return '<pre>'+html.escape(json.dumps(v,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False))+'</pre>'

audit=json.loads((D/'ROOT-saved-qualification-audit-v1.json').read_bytes())
assert audit['current_inverse_qualification_admitted']is True
peer=json.loads((C/'typed-saved-qualification-review-v1.json').read_bytes())
assert peer['saved_review_passed']is True
plan=json.loads((D/'plan-authorized-v1.json').read_bytes())
result=json.loads(Path(audit['references']['result']['path']).read_bytes());q=result['qualification']
OUT.mkdir()
write('inverse-cadence-summary.json',dict(audit=audit,independent_saved_review=peer))
write('inverse-cadence-result.json',result)

rows=''.join('<tr><th>'+html.escape(r['mode'])+'</th><td>'+number(r['forest_bytes'])+'</td><td>'+number(r['logical_file_bytes'])+'</td><td>'+number(r['attempted_operations'])+'</td><td>'+number(r['callback_dispatches'])+'</td><td>'+seconds(r['complete_reconstruction_seconds'])+'</td></tr>'for r in audit['whole_inputs'])
diagnostics=''.join('<details class="diagnostic"><summary>'+number(i)+' · '+html.escape(r['name'].replace('_',' '))+' <span>passed</span></summary>'+block(r)+'</details>'for i,r in enumerate(q['diagnostics'],1))
symbolic=audit['whole_inputs'][1];old=symbolic['symbolic_retained_reference_comparison']['V6_callback_dispatches']
style=(WEB/'owned-evidence.html').read_text().split('<style>',1)[1].split('</style>',1)[0]
head=(WEB/'owned-evidence.html').read_text().split('<script>',1)[1].split('</style>',1)[0].split('<style>',1)[0]
page='''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Inverse callback qualification — GCTS research</title><script>'''+head+'''<style>'''+style+'''
.diagnostic{background:white;border:1px solid var(--line);padding:14px 20px;margin:12px 0}.diagnostic summary{overflow-wrap:anywhere}.diagnostic summary span{float:right;color:var(--teal);font-size:13px}.counts{display:grid;grid-template-columns:1fr 1fr;gap:22px;margin:25px 0}.counts article{padding:25px;background:white;border-top:5px solid var(--purple)}.counts strong{display:block;font-size:28px}.scope{background:#e2efeb;padding:18px 24px;border-left:5px solid var(--teal)}@media(max-width:730px){.counts{grid-template-columns:1fr}}
</style></head><body><main><nav><a href="reader.html#inverse-cadence">Research notebook</a><a href="owned-evidence.html#proof">Existing proof, line by line</a><a href="#outcome">Qualification</a><a href="#diagnostics">Inspect diagnostics</a><a href="#next">Next experiment</a></nav><p class="eyebrow">19 October 2026 · Implementation, independent review, and coordination</p><h1>Full evidence reconstruction passes its finite qualification.</h1><p class="lead">Both saved forests reproduce their complete original results. Every original operation check remains; delegated clock callbacks now use bounded checkpoints.</p><p class="scope">This is an engineering prerequisite for the proof-search program. It discovers no new theorem, runs no proof search, and leaves the earlier fixed GCTS pipeline failure unchanged. The next test is a fresh full matched pipeline pair.</p>
<section id="outcome"><h2>One bounded run, two complete reconstructions.</h2><div class="cards"><article><b>Finite qualification passed</b><p>All '''+number(30)+''' diagnostic groups passed, including '''+number(27)+''' reached phase/error combinations in the two added groups. Every complete output byte was compared, including the sole final newline.</p></article><article><b>Resources admitted</b><p>External terminal: '''+seconds(audit['external_terminal_seconds'])+'''. Standalone worker peak: '''+m(f"{audit['worker_peak_bytes']/1048576:.2f}"+r'\,\mathrm{MiB}')+'''. No Native process was launched.</p></article></div><div class="table-wrap"><table><thead><tr><th>Historical input</th><th>Saved forest bytes</th><th>Reconstructed result bytes</th><th>Attempted operations</th><th>Delegated callbacks</th><th>Whole reconstruction</th></tr></thead><tbody>'''+rows+'''</tbody><caption>Times include fresh forest parsing, preparation, full streaming and byte comparison, and boundary guards for each input. These are standalone component observations under a changed execution profile, not full search timings or an old/new performance ablation.</caption></table></div><p>Total logical result bytes: '''+number(audit['logical_result_bytes'])+'''. Conservative physical output budget, including reserved outer metadata: '''+number(audit['conservative_physical_bytes'])+''' bytes. Both stay below '''+m(r'128\,\mathrm{MiB}')+'''. Known worker exit and complete final checks precede the original '''+m(r'180\,\mathrm{s}')+''' work deadline; external terminal precedes '''+m(r'210\,\mathrm{s}')+'''. The standalone worker highwater stays below '''+m(r'1\,\mathrm{GiB}')+''', and both logs stay within '''+m(r'4\,\mathrm{MiB}')+'''.</p></section>
<section id="change"><h2>What changed in the inverse.</h2><div class="path evidence"><article><strong>Every original operation</strong><p>Validation, type checks, exact counters and the owned work-cap test remain at each original operation.</p></article><div class="arrow" aria-hidden="true">→</div><article><strong>Bounded delegated checkpoints</strong><p>The supplied clock/guard is called at most '''+number(1024)+''' attempted operations apart, with forced calls at public entry, pull, chunk and completion boundaries.</p></article><div class="arrow" aria-hidden="true">→</div><article><strong>Explicit full completion</strong><p>Returning the last byte is insufficient. A final successful pull must confirm the complete stream; exact callback errors cannot create success.</p></article></div><div class="counts"><article>Retained symbolic V6 counters<strong>'''+number(old)+'''</strong>attempted operations and delegated callbacks</article><article>Fresh symbolic V7 counters<strong>'''+number(symbolic['attempted_operations'])+'''</strong>attempted operations; '''+number(symbolic['callback_dispatches'])+''' delegated callbacks</article></div><p>The symbolic reconstruction retains every per-kind operation count from the saved V6 record. The old inverse was not executed in this qualification. The smaller callback count follows the new schedule; elapsed-time benefit needs a separately matched old/new experiment. The cadence bounds counted operations between callbacks, not elapsed latency or OS interruption.</p></section>
<section id="parallel"><h2>How parallel agents helped.</h2><div class="time-legend"><article><b>Implementation</b><p>One agent authored the finite harness and its fault cases. Root authored the inverse scheduling change and bounded wrappers.</p></article><article><b>Independent review</b><p>A separate reviewer found error-reporting and deadline-classification gaps before execution. Withdrawn drafts and their negative reviews remain in the archive.</p></article><article><b>Coordination and experiment</b><p>Root froze the reviewed inputs and limits, granted one invocation, admitted the complete saved evidence, and prepared this report. Agents stopped their tools during the timed run.</p></article></div><p class="note">The standalone wrapper uses pinned raw Sources and trusted exclusive ownership during loading and execution. It does not independently seal every loaded callable, default, closure cell or in-memory object. Finite diagnostics are not a universal proof of inverse soundness. The future full pipeline retains its separate runtime and proof gates.</p></section>
<section id="diagnostics"><p class="eyebrow">Literal saved packets · Expand any group</p><h2>Inspect the finite checks.</h2><p>Coverage includes exact scalar types and signed zero, ordered repeated references, disabled-cache fallback, malformed inputs, exact quota boundaries, callback gaps, manual stream exhaustion, private reentrancy and foreign exception identity. The added phase groups explicitly require the intended callback to be reached.</p>'''+diagnostics+'''</section>
<section id="next"><h2>The research question remains open.</h2><p>The existing machine-selected control proof of '''+m(r'a=b,\;P(a)\vdash P(b)')+''' remains available <a href="owned-evidence.html#proof">as formulas, English and saved steps</a>. Reconstructing its historical bytes supplies no new mathematical authority. In particular, the old fixed GCTS run remains unqualified.</p><p>Next, couple this qualified inverse to fresh fixed and symbolic runs on the same original assertion, retaining the full point-region check, Native validation, current lemma inventory, exact evidence joins and numeric limits. That is needed before broader theorem benchmarks. A later held-out suite and conventional proof-search controls must establish whether GCTS or learned receptor families contribute useful search behavior. No new RL training or GCTS advantage is established here.</p><p>The larger assembly, sealing, export and guard interval remains unpartitioned. This qualification does not resolve that bottleneck or predict a successful full-pipeline outcome.</p></section>
<section id="reader"><h2>Records and reproduction.</h2><p><a href="inverse-cadence-summary.json">Root audit and independent saved-record review</a> · <a href="inverse-cadence-result.json">Full qualification result</a> · <a href="inverse-cadence-manifest.json">Archive manifest</a> · <a href="inverse-cadence-archive.zip">Sources, reviews, plans, receipts and full input bytes</a></p><p class="note">The archive includes raw historical input bytes and exact current Sources. Runtime executable and OS are external pinned prerequisites. Plans and grants are historical once-only records, not permission to replay scientific components.</p><details><summary>Complete saved qualification</summary>'''+block(q)+'''</details></section><footer>Research program active. Finite engineering milestone only. Earlier negative outcomes remain part of the record.</footer></main></body></html>'''
(OUT/'inverse-cadence.html').write_text(page)

members=[]
for prefix,folder in [('ROOT',D),('library',L),('peer',C)]:
    for p in sorted(folder.rglob('*')):
        if not p.is_file()or OUT in p.parents:continue
        assert p.suffix in ('.json','.py','.patch','.bin')
        members.append((prefix+'/'+str(p.relative_to(folder)),p))
for row in plan['inputs']:
    for key in ('forest','result'):members.append(('historical/'+row['mode']+'/'+key+'.json',Path(row[key]['path'])))
members.extend([('historical/symbolic-worker-receipt.json',Path(plan['reference']['path'])),
    ('historical/independent_forest_inverse_v6.py',Path('/private/tmp/gcts-incremental-arena-ROOT-20261019/independent_forest_inverse_v6.py')),
    ('contract/basic-tiling-algorithm.md',Path('/private/tmp/gcts-owned-evidence-integration-ROOT-20261019/basic-tiling-algorithm.md'))])
assert len({name for name,p in members})==len(members)
manifest=[dict(member=name,original=pin(p))for name,p in members]
with zipfile.ZipFile(OUT/'inverse-cadence-archive.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=6)as z:
    for name,p in members:z.writestr(name,p.read_bytes())
write('inverse-cadence-manifest.json',dict(schema='inverse-cadence-archive-manifest-v1',archive=pin(OUT/'inverse-cadence-archive.zip'),members=manifest,all_originals_raw=True))
with zipfile.ZipFile(OUT/'inverse-cadence-archive.zip')as z:
    assert z.namelist()==[row['member']for row in manifest]
    for row in manifest:
        b=z.read(row['member']);assert len(b)==row['original']['bytes']and hashlib.sha256(b).hexdigest()==row['original']['sha256']

prior=(WEB/'owned-evidence.html').read_text()
aside='<aside id="inverse-cadence-follow-up" class="scope"><b>Follow-up:</b> The inverse successor passed a standalone finite qualification on both complete saved forests. The original fixed failure below remains unchanged. <a href="inverse-cadence.html?v=20261019-ic1#outcome">Read the qualification and next full-pipeline test</a>.</aside>'
assert prior.count('<section id="outcome">')==1
(OUT/'owned-evidence.html').write_text(prior.replace('<section id="outcome">',aside+'\n<section id="outcome">',1))
reader=(WEB/'reader.html').read_text();marker='<section id="owned-evidence">'
section='<section id="inverse-cadence"><p class="eyebrow">19 OCTOBER 2026 · INVERSE QUALIFICATION</p><h2>Both full saved evidence forests reconstruct exactly.</h2><p>The successor passes '+number(30)+' finite diagnostics under the original numeric limits. This is a standalone representation prerequisite; the earlier fixed GCTS pipeline failure remains unchanged. <a href="inverse-cadence.html?v=20261019-ic1#outcome"><b>Read the outcome</b></a> · <a href="inverse-cadence.html?v=20261019-ic1#diagnostics">Inspect every diagnostic group</a>.</p></section>'
assert reader.count(marker)==1
(OUT/'reader.html').write_text(reader.replace(marker,section+marker,1))
assert (OUT/'owned-evidence.html').read_text().replace(aside+'\n','',1)==prior
assert (OUT/'reader.html').read_text().replace(section,'',1)==reader
candidate=dict(schema='inverse-cadence-publication-candidate-v1',files=[pin(p)for p in sorted(OUT.iterdir())],
    archive_members=len(manifest),existing_changes='One precise link-only addition each to owned-evidence.html and reader.html; removing each gives exact baseline bytes.',
    protected_overview_changed=False,primary_checkout_read_or_written=False,scientific_calls=0)
p=D/'publication-candidate-v1.json';p.write_text(json.dumps(candidate,sort_keys=True,indent=2)+'\n')
print(json.dumps(pin(p),sort_keys=True))
