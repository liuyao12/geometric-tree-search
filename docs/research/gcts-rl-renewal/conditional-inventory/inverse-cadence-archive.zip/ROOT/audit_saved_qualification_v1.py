"""Saved JSON assertions and raw hashes only; no inverse/fixture/proof replay."""
from pathlib import Path
import hashlib
import json
import math
D=Path('/private/tmp/gcts-inverse-cadence-ROOT-20261019')

def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def pin(p):
    p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
checks=[]
def need(v,label):
    checks.append(dict(check=label,passed=bool(v)))
    assert v,label
def exact(d):need(pin(d['path'])==d,'whole raw '+d['path']);return json.loads(Path(d['path']).read_bytes())

pp=D/'plan-authorized-v1.json';plan=json.loads(pp.read_bytes());actual=Path(plan['actual_directory'])
runner=json.loads((actual/'runner-receipt.json').read_bytes())
terminal=json.loads((D/(pp.stem+'-terminal-observation')/'terminal.json').read_bytes())
need(runner['resource_candidate_accepted']is True and runner['representation_candidate']is True,'outer resource candidate')
need(terminal['runner_exit_code']==0 and terminal['terminal_gate_passed']is True,'external terminal0 and gate')
need(runner['worker_exit_code']==0 and runner['worker_reaped']is True and runner['owned_group_absent']is True and runner['regular_logs_closed']is True and runner['worker_launch_attempts']==1,'owned worker exit group logs and once')
need(runner['plan']==pin(pp)and terminal['plan']==pin(pp),'exact joined subject')
need(runner['began_ns']<runner['worker_terminal_observed_ns']<=runner['closed_ns']<runner['work_deadline_ns'],'positive final checks before180')
need(terminal['terminal_observed_ns']<runner['overall_deadline_ns'],'external terminal before210')
need(runner['worker_peak_bytes']==runner['worker_wait4_usage']['ru_maxrss']<=1073741824,'Darwin worker highwater1GiB no Native')
need(runner['scientific_acceptance']is False and runner['Native_calls']==0,'representation-only scope')
header=exact(runner['worker_receipt']);result=exact(runner['result']);q=result['qualification']
need(header['result']==runner['result']and header['plan']==pin(pp),'exact final header/result')
need(header['work_completed_ns']<runner['work_deadline_ns'],'worker positive timestamp before180')
decl=exact(plan['declaration']);reference=exact(plan['reference'])['evidence_verification']['statistics']
need(q['status']=='FINITE_REPRESENTATION_QUALIFIED'and q['stage']=='COMPLETE','complete fresh qualification')
need([r['name']for r in q['diagnostics']]==decl['expected_fixture_names']and len(q['diagnostics'])==30,'whole30diagnostic names/order')
need(all(r['status']=='passed'and r['mathematical_authority']is False for r in q['diagnostics']),'all finite diagnostic statuses')
need(len(q['diagnostics'][-2]['details']['observations'])==9 and len(q['diagnostics'][-1]['details']['observations'])==18,'27actually reached phase/error observations')
need({r['exception_type']for r in q['diagnostics'][-2]['details']['observations']}=={'RuntimeError','ValueError','StopIteration'},'prepare exact foreign classes')
need({r['exception_type']for r in q['diagnostics'][-1]['details']['observations']}=={'RuntimeError','ValueError','StopIteration'},'public/stream exact foreign classes')
need([r['mode']for r in q['whole_inputs']]==['fixed','symbolic'],'both full ordered reconstructions')
rows=[];logical=0
for current,original in zip(q['whole_inputs'],plan['inputs']):
    need(current['forest']==original['forest']and current['original_result']==original['result'],'exact original pair '+current['mode'])
    for key in ('forest','result'):need(pin(original[key]['path'])==original[key],'unchanged full input '+current['mode']+key)
    n=current['reconstructed_complete_file_bytes'];logical+=n;s=current['statistics'];d=s['documents']['receiver:complete-legacy-result']
    need(current['explicit_completed']is True and current['status']=='complete'and n==original['result']['bytes']and current['full_original_file_sha256']==original['result']['sha256'],'whole BODY+LF byte evidence '+current['mode'])
    need(d['completed']is True and d['attempts']==1 and d['closed_incomplete']is False and d['copied_body_bytes']==d['emitted_body_bytes']==n-1 and d['stream_value_occurrences']==d['logical_value_occurrences'],'whole independent document ledger '+current['mode'])
    need(s['wire_canonical_bytes']==original['forest']['bytes']and s['aggregate_document_bytes']==n,'physical/logical independent ledger '+current['mode'])
    need(s['callback_cadence_operations']==1024 and s['maximum_callback_operation_gap']<=1024 and s['pending_callback_operations']==0 and s['last_callback_operation']==s['attempted_operations'],'new callback cadence '+current['mode'])
    need(sum(s['operations_by_kind'].values())==s['attempted_operations']and sum(s['callback_dispatches_by_reason'].values())==s['callback_dispatches'],'full operation/callback census '+current['mode'])
    need(d['chunks']==math.ceil((n-1)/65536),'all full output chunks '+current['mode'])
    need(current['prior_fixed_failure_recovered']is False and current['mathematical_authority']is False,'no historical proof reclassification '+current['mode'])
    if current['mode']=='symbolic':
        need(s['attempted_operations']==reference['attempted_operations']==21304533 and s['operations_by_kind']==reference['operations_by_kind'],'all old symbolic operation counts exact')
    rows.append(dict(mode=current['mode'],logical_file_bytes=n,forest_bytes=original['forest']['bytes'],
        attempted_operations=s['attempted_operations'],callback_dispatches=s['callback_dispatches'],
        callback_reasons=s['callback_dispatches_by_reason'],maximum_callback_operation_gap=s['maximum_callback_operation_gap'],
        complete_reconstruction_seconds=(current['completed_monotonic']-current['started_monotonic'])/1e9,
        symbolic_retained_reference_comparison=current['V6_retained_reference_comparison']))
need(logical==70916162==header['logical_result_bytes']==runner['logical_result_bytes']<=134217728,'aggregate full logical result cap')
physical=sum(f.stat().st_size for f in actual.iterdir()if f.is_file())
need(physical+1048576<=runner['conservative_physical_bytes']<=134217728,'all actual files plus observer reserve inside conservative physical cap')
for key in ('python','worker','harness','inverse','runner','observer','reference','declaration'):need(pin(plan[key]['path'])==plan[key],'final full Source/declaration '+key)
need(all(result[k]==0 for k in ('Native_calls','Model_calls','search_calls','mathematical_proof_replays','opaque_Native_decodes'))and result['scientific_acceptance']is False and result['new_theorem']is False,'zero scientific activity')
output=dict(schema='ROOT-inverse-cadence-saved-audit-v1',author_identity='/root',
    classification='FINITE REPRESENTATION QUALIFIED',checks=checks,check_count=len(checks),mismatch_count=0,
    current_inverse_qualification_admitted=True,whole_inputs=rows,diagnostic_groups=30,
    new_phase_exception_observations=27,external_terminal_seconds=terminal['runner_clock_elapsed_seconds'],
    worker_peak_bytes=runner['worker_peak_bytes'],logical_result_bytes=logical,
    actual_physical_files_bytes=physical,conservative_physical_bytes=runner['conservative_physical_bytes'],
    sources={k:plan[k]for k in ('worker','harness','inverse','runner','observer')},
    references=dict(plan=pin(pp),runner=pin(actual/'runner-receipt.json'),terminal=pin(D/(pp.stem+'-terminal-observation')/'terminal.json'),worker=runner['worker_receipt'],result=runner['result']),
    no_replay=True,scientific_calls_in_audit=0,mathematical_acceptance=False,new_theorem=False,
    GCTS_RL_advantage_established=False,full_successor_pipeline_pair_qualified=False,
    historical_fixed_integration_admitted=False,goal_complete=False,
    next_step='Couple this now-qualified inverse to a fresh independently reviewed common-profile full original001 fixed/symbolic pair, retaining old failures and all gates. No causal speed claim without a separate matched old/new inverse ablation.')
out=D/'ROOT-saved-qualification-audit-v1.json'
with out.open('x')as f:json.dump(output,f,sort_keys=True,indent=2,allow_nan=False);f.write('\n')
print(json.dumps(pin(out),sort_keys=True))
