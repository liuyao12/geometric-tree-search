"""Fresh inverse-only qualification. Evaluation occurs only in the granted worker."""
import time
NOW = time.monotonic_ns
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys

VERSION = 'inverse-cadence-qualification-worker-v1'
LIMITS = dict(work_seconds=180, overall_seconds=210, memory_bytes=1073741824,
              result_bytes=134217728, expanded_bytes=134217728,
              stdout_bytes=4194304, stderr_bytes=4194304)


class WorkDeadline(RuntimeError): pass


def need(value, message):
    if not value: raise ValueError(message)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=False, allow_nan=False).encode()


def descriptor(path, body):
    return dict(path=str(Path(path).resolve()), bytes=len(body),
                sha256=hashlib.sha256(body).hexdigest())


def checked(item):
    body = Path(item['path']).read_bytes()
    need(descriptor(item['path'], body) == item, 'whole raw descriptor')
    return body


def save_new(path, value):
    body = canonical(value) + b'\n'
    need(len(body) <= 4194304, 'bounded worker metadata')
    fd = os.open(str(path), os.O_CREAT | os.O_EXCL | os.O_WRONLY | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(body); stream.flush(); os.fsync(stream.fileno())
    return descriptor(path, body)


def load_source(name, item):
    checked(item)
    spec = importlib.util.spec_from_file_location(name, item['path'])
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def main(plan_path):
    path = Path(plan_path).resolve(); plan_body = path.read_bytes(); plan = json.loads(plan_body)
    actual = Path(plan['actual_directory'])
    consumed = json.loads((actual / 'CONSUMED.json').read_bytes())
    began = consumed['began_ns']; work = began + 180000000000; overall = began + 210000000000
    need(sys.platform == 'darwin' and os.getpid() == os.getpgrp(), 'owned Darwin worker')
    need(plan['limits'] == LIMITS, 'unchanged numeric gates')
    need(consumed['plan'] == descriptor(path, plan_body) and consumed['invocation_id'] == plan['invocation_id'], 'consumed exact plan')
    need(consumed['work_deadline_ns'] == work and consumed['overall_deadline_ns'] == overall, 'single external epoch')
    need(checked(plan['worker']) == Path(__file__).read_bytes(), 'whole worker Source')
    sources = {key: plan[key] for key in ('python', 'worker', 'inverse', 'harness', 'runner', 'observer')}
    declaration = json.loads(checked(plan['declaration']))
    reference = json.loads(checked(plan['reference']))
    need(declaration['schema'] == 'ROOT-inverse-cadence-qualification-declaration-v1', 'exact declaration')
    calls = 0; deadline = [None]; progress_rows = []; payload = None; result_pin = None

    def guard():
        for item in sources.values(): checked(item)

    def check():
        nonlocal calls
        calls += 1
        if NOW() >= work:
            error = WorkDeadline('original180s work deadline'); deadline[0] = error; raise error
        if calls % 32768 == 0: guard()

    def progress(row):
        check()
        need(type(row) is dict and len(canonical(row)) <= 131072, 'bounded completed progress packet')
        need(len(progress_rows) < 256, 'finite progress census')
        progress_rows.append(row)

    try:
        guard(); check()
        inverse = load_source('qualified_inverse_v7', plan['inverse'])
        harness = load_source('inverse_cadence_finite_harness', plan['harness'])
        need(inverse.VERSION == declaration['inverse_version'] and inverse.EXECUTION_PROFILE == declaration['execution_profile'], 'current inverse profile')
        need(list(harness.EXPECTED_FIXTURES) == declaration['expected_fixture_names'], 'exact new fixture census')
        payload = harness.run_inverse_qualification(
            inverse_module=inverse, inputs=plan['inputs'], reference_stats=reference,
            check=check, source_guard=guard, now=NOW, work_deadline=work,
            closure_deadline=overall, progress=progress)
        check(); guard()
        need(payload['status'] == 'INVERSE_QUALIFICATION_CANDIDATE', 'whole qualification candidate')
        need(payload['expected_fixture_names'] == declaration['expected_fixture_names'], 'whole returned fixture census')
        need([row['name'] for row in payload['fixtures']] == declaration['expected_fixture_names'] and all(row['passed'] is True for row in payload['fixtures']), 'every finite diagnostic passed')
        need([row['id'] for row in payload['complete_inputs']] == ['fixed', 'symbolic'], 'both complete inputs')
        need(payload['aggregate_logical_result_bytes'] <= LIMITS['expanded_bytes'], 'aggregate full logical output cap')
        result = dict(schema='inverse-cadence-qualification-result-v1', version=VERSION,
                      invocation_id=plan['invocation_id'], plan=descriptor(path, plan_body),
                      qualification=payload, progress=progress_rows,
                      sources=sources, callbacks=calls, reference=plan['reference'],
                      representation_only=True, Native_calls=0, Model_calls=0,
                      search_calls=0, mathematical_proof_replays=0, opaque_Native_decodes=0,
                      scientific_acceptance=False, new_theorem=False, goal_complete=False,
                      scope='Independent inverse finite qualification on immutable historical bytes. The fixed historical pipeline remains failed. No search/kernel/Model/Native admission or speed attribution.')
        result_pin = save_new(actual / 'result.json', result); check(); guard()
        for row in plan['inputs']:
            checked(row['forest']); checked(row['result']); check()
        physical = sum(item.stat().st_size for item in actual.iterdir() if item.is_file())
        need(physical + 9437184 + 4194304 <= LIMITS['result_bytes'], 'physical outputs plus receipt and outer reserves')
        save_new(actual / 'worker-receipt.json', dict(
            schema='inverse-cadence-qualification-worker-receipt-v1', version=VERSION,
            invocation_id=plan['invocation_id'], plan=descriptor(path, plan_body),
            began_ns=began, work_deadline_ns=work, overall_deadline_ns=overall,
            work_completed_ns=NOW(), result=result_pin, representation_qualification_candidate=True,
            logical_result_bytes=payload['aggregate_logical_result_bytes'],
            physical_before_worker_receipt=physical, outer_metadata_reservation=9437184,
            scientific_acceptance=False, mathematical_proof_accepted=False, Native_calls=0))
        check()
    except BaseException as error:
        save_new(actual / 'worker-failure.json', dict(
            schema='inverse-cadence-qualification-worker-failure-v1',
            status='UNKNOWN_WORK_DEADLINE' if deadline[0] is not None else 'FAILED_QUALIFICATION',
            type=type(error).__name__, message=str(error)[:8192],
            completed_progress_prefix=progress_rows, result_candidate=result_pin,
            delegated_callbacks=calls, representation_accepted=False,
            scientific_acceptance=False, Native_calls=0))
        raise


if __name__ == '__main__':
    need(len(sys.argv) == 2, 'one exact once plan'); main(sys.argv[1])
