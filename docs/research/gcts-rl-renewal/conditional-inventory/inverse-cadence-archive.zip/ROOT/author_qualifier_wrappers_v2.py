"""Inert Source templating and ordinary metadata only; never evaluate components."""
from pathlib import Path
import ast
import hashlib
import json

D = Path('/private/tmp/gcts-inverse-cadence-ROOT-20261019')
P = Path('/private/tmp/gcts-direct-reconcile-ROOT-20261019/run_arena_once_v4.py')
s = P.read_text()
s = s.replace('Exactly one representation worker; original numeric resource gates, no proof runtime.', 'Exactly one inverse qualification worker; unchanged global gates, no proof runtime.')
s = s.replace('direct-reconciliation-once-runner-v4-135-diagnostics', 'inverse-cadence-once-runner-v1')
s = s.replace("'encoder'", "'harness'")
s = s.replace("'declaration','authorization'", "'reference','declaration','authorization'")
s = s.replace("'observer','declaration']", "'observer','reference','declaration']")
s = s.replace("'exact-evidence-once-plan-v1'", "'ROOT-inverse-cadence-once-plan-v1'")
a = s.index("    need(type(plan['inputs'])")
b = s.index("    subject=", a)
s = s[:a] + '''    need(type(plan['inputs'])is list and len(plan['inputs'])==2,'complete frozen two-input set')
    need([r['id']for r in plan['inputs']]==['fixed','symbolic'],'whole artifact order')
    for r in plan['inputs']:
        need(set(r)=={'id','forest','result','kind'}and r['kind']=='complete_saved_forest_and_ordinary_result','input scope')
        checked(r['forest']);checked(r['result'])
    need(sum(r['result']['bytes']for r in plan['inputs'])<=LIMITS['expanded_bytes'],'aggregate logical original cap')
''' + s[b:]
s = s.replace("len(subject)==12,'full twelve-field subject'", "len(subject)==13,'full thirteen-field subject'")
s = s.replace("'exact-evidence-once-authorization-v1'", "'ROOT-inverse-cadence-once-authorization-v1'")
s = s.replace("'exact-evidence-components-Source-review-v1'", "'inverse-cadence-qualification-components-Source-review-v1'")
s = s.replace("'exact-evidence-prospective-plan-review-v1'", "'inverse-cadence-qualification-prospective-plan-review-v1'")
s = s.replace("'exact-evidence-consumed-v1'", "'inverse-cadence-consumed-v1'")
s = s.replace("'exact-evidence-once-receipt-v1'", "'inverse-cadence-once-receipt-v1'")
s = s.replace("'exact-evidence-qualification-worker-receipt-v1'", "'inverse-cadence-qualification-worker-receipt-v1'")
a = s.index("        payload=json.loads(checked(w['result']))")
b = s.index("        need(usage.ru_maxrss", a)
s = s[:a] + '''        payload=json.loads(checked(w['result']));q=payload['qualification']
        declaration=json.loads(checked(plan['declaration']))
        need(payload['schema']=='inverse-cadence-qualification-result-v1'and payload['plan']==descriptor(p,plan_raw)and payload['invocation_id']==plan['invocation_id'],'exact result subject')
        need(q['status']=='INVERSE_QUALIFICATION_CANDIDATE'and len(q['complete_inputs'])==2,'complete retained candidate')
        need([r['id']for r in q['complete_inputs']]==['fixed','symbolic'],'two whole input order')
        fixtures=q['fixtures'];expected=declaration['expected_fixture_names']
        need(q['expected_fixture_names']==expected and [f['name']for f in fixtures]==expected and len(set(expected))==len(expected),'complete fresh fixture census')
        need(all(f['passed']is True for f in fixtures),'strict finite diagnostic successes')
        need(payload['Native_calls']==payload['Model_calls']==payload['search_calls']==payload['mathematical_proof_replays']==payload['opaque_Native_decodes']==0 and payload['scientific_acceptance']is False and payload['new_theorem']is False,'no proof authority')
        need(q['aggregate_logical_result_bytes']==sum(r['result']['bytes']for r in plan['inputs'])==w['logical_result_bytes']<=LIMITS['expanded_bytes'],'full expanded logical ledger')
        need(w['outer_metadata_reservation']==9437184,'unchanged reserved outer9MiB')
        total=sum(f.stat().st_size for f in actual.iterdir()if f.is_file())
        need(total+9437184<=LIMITS['result_bytes'],'all physical outputs plus8MiB runner and1MiB observer reserves')
''' + s[b:]
s = s.replace("for r in plan['inputs']:checked(r['input'])", "for r in plan['inputs']:checked(r['forest']);checked(r['result'])")
s = s.replace("result=w['result'],tables=w['tables'],aggregate_encoded_result_bytes=total", "result=w['result'],physical_before_runner_receipt=total,conservative_physical_bytes=total+9437184,logical_result_bytes=q['aggregate_logical_result_bytes']")
# Use an8MiB runner receipt bound; this is exactly its reserved share.
s = s.replace("len(b)<=4194304,'bounded receipt'", "len(b)<=8388608,'bounded receipt'")
out = D / 'run_inverse_once_v1.py'
ast.parse(s); compile(s, str(out), 'exec')
out.write_text(s)

old = Path('/private/tmp/gcts-owned-evidence-integration-ROOT-20261019/observe_owned_evidence_runner_v1.py').read_text()
old = old.replace('owned-evidence-final-terminal-observer-v1','inverse-cadence-final-terminal-observer-v1')
old = old.replace('ROOT-owned-evidence-integration-once-plan-v1','ROOT-inverse-cadence-once-plan-v1')
old = old.replace('ecf8bfcc34fad0cc87af0c9dc1147e80fe5b08188ac3a10b308b8b8b1ed05497',hashlib.sha256(s.encode()).hexdigest())
a = old.index("        outcome['terminal_gate_passed']=")
b = old.index("    outcome['scope']=",a)
old = old[:a] + '''        outcome['terminal_gate_passed']=(code==0 and observed<receipt['overall_deadline_ns'] and
            receipt['resource_candidate_accepted']is True and receipt['representation_candidate']is True and
            receipt['invocation_id']==plan['invocation_id']and receipt['worker_launch_attempts']==1 and
            receipt['worker_reaped']is True and receipt['owned_group_absent']is True and
            receipt['regular_logs_closed']is True and receipt['conservative_physical_bytes']<=134217728 and
            receipt['Native_calls']==0 and receipt['scientific_acceptance']is False and
            receipt['plan']==pin(path,raw)and not (actual/'POST_RECEIPT_DEADLINE_FAILURE.json').exists()and
            not (actual/'POST_RECEIPT_WORK_FAILURE.json').exists())
''' + old[b:]
old=old.replace('Final compact-model cold outer terminal/group/EOF gate only. Parent Source-entry epoch excludes observer/Python prelude. Root separately admits exact native/point/knowledge/fullprofile evidence; no own mathematical acceptance.', 'Standalone inverse-only final outer terminal/group/regular-log gate. Source-entry epoch excludes observer/Python prelude. No Native or proof search; all scientific acceptance remains false.')
out = D / 'observe_inverse_once_v1.py'
ast.parse(old);compile(old,str(out),'exec');out.write_text(old)

# This reference contains only old ordinary diagnostic statistics, never a
# decoded mathematical result or executable component.
prior = Path('/private/tmp/gcts-owned-evidence-integration-ROOT-20261019/actual-symbolic-v1/worker-receipt.json')
raw=prior.read_bytes();metadata=json.loads(raw)['evidence_verification']
ref=dict(schema='inverse-cadence-retained-statistics-reference-v1',
    prior_header=dict(path=str(prior),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()),
    prior_execution_profile=metadata['declaration']['execution_profile'],
    sole_document=metadata['declaration']['sole_document'],
    inverse_limits=metadata['declaration']['limits'],
    symbolic_statistics=metadata['statistics'],
    reference_only=True,scientific_acceptance=False)
(D/'retained-statistics-reference-v1.json').write_text(json.dumps(ref,sort_keys=True,indent=2)+'\n')
print('Authored two inert wrappers and one metadata reference; no component evaluation.')
