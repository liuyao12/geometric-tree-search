One whole qualification failure, no qualified prefix or research target proof. All predecessor raw evidence preserved. No scientific code executed by packaging.
