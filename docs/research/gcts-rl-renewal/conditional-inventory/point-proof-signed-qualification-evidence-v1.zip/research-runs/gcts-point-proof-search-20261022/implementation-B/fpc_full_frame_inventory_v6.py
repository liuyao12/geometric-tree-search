"""Finite full-FPC row inventory. Authored Source only; never run at authorship.

No search, target names, proof/history intake, global syntax catalog or handle
registry. The caller owns scheduling, finite child-exhaustion authority and
whole custody. Every resulting certificate needs both external byte validators.
"""
VERSION = "FPC-POINT-FULL-FRAME-PROVIDER-v1"
IMPLEMENTATION_REVISION = "FPC-POINT-FULL-FRAME-PROVIDER-implementation-v6"
FEATURES = ("finite-full-kernel", "atomic-cursors", "rebind-classification",
            "dependency-rebind-classification", "conclusion-constructor-index", "constrained-output-slots")
_OWNER = object()
_SORTS = (("F", "F"), ("F", "F", "F"), ("F", "F"),
          ("F", "V", "T"), ("F", "F", "V"), ("F", "V"),
          ("T",), ("F", "V", "T", "T"))
_COUNTERS = ("committed_actions", "raw_tuples_complete", "intrinsic_refusals",
             "envelope_exclusions", "point_conflicts", "distinct_legal_inspected",
             "shortcut_candidates_proved", "fallback_eof_events", "branch_offers",
             "failed_children_recorded", "tried_prefix_advances")


class ProviderInputError(ValueError):
    """Message-constructible public type; ownership is private, not class-only."""


def is_owned_error(error):
    return type(error) is ProviderInputError and getattr(error, "_owner", None) is _OWNER


def _invalid(reason):
    error = ProviderInputError(reason)
    error._owner = _OWNER
    raise error


def _nat(value):
    return type(value) is int and value >= 0


class _Inventory:
    __slots__ = ("_owner", "_token", "_body", "_serial", "_fault", "_closed")

    def __setattr__(self, name, value):
        raise AttributeError("private immutable inventory interface")


class _Handle:
    __slots__ = ("_owner", "_inv", "_serial", "_data", "_closed")

    def __setattr__(self, name, value):
        raise AttributeError("private current-job handle")


class _State(_Handle):
    __slots__ = ()


class _Candidate(_Handle):
    __slots__ = ()


class _ClassCursor(_Handle):
    __slots__ = ()


class _BranchCursor(_Handle):
    __slots__ = ()


class _Offer(_Handle):
    __slots__ = ()


_TYPES = (_State, _Candidate, _ClassCursor, _BranchCursor, _Offer)


def _inventory(value):
    if type(value) is _Inventory and value._owner is _OWNER:
        return value
    if type(value) in _TYPES and value._owner is _OWNER:
        return value._inv
    _invalid("current private inventory or handle required")


class _Call:
    def __init__(self, inv, check):
        self.inv, self.check = inv, check
        if inv._fault is not None:
            raise inv._fault
        if not callable(check):
            raise TypeError("genuine bounded check required")
        if inv._closed:
            _invalid("closed inventory")

    def fault(self):
        if self.inv._fault is not None:
            raise self.inv._fault

    def tick(self):
        self.fault()
        try:
            self.check()
        except BaseException as error:
            object.__setattr__(self.inv, "_fault", error)
            raise

    def need(self, condition, reason):
        self.fault()
        if condition is not True:
            _invalid(reason)

    def helper(self, module, function, *args):
        self.tick()
        try:
            value = function(*args, check=self.tick)
        except BaseException as error:
            self.fault()
            if type(error) is getattr(module, "InvalidWitness", None):
                return False, str(error)
            raise
        self.fault()
        return True, value


def _begin(handle, check, allowed=None):
    inv = _inventory(handle)
    call = _Call(inv, check)
    call.tick()
    if allowed is not None:
        call.need(type(handle) in allowed and not handle._closed, "wrong or closed handle")
    return inv, call


def _keys(value, names, call):
    call.tick()
    call.need(type(value) is dict and len(value) == len(names), "strict keys")
    for key in names:
        call.tick()
        call.need(key in value, "missing strict key")


def _handle(cls, inv, data, serial=0):
    handle = object.__new__(cls)
    for name, value in (("_owner", _OWNER), ("_inv", inv), ("_serial", serial),
                        ("_data", data), ("_closed", False)):
        object.__setattr__(handle, name, value)
    return handle


def _commit_handle(cls, inv, data, call):
    serial = inv._serial + 1
    answer = _handle(cls, inv, data, serial)
    call.tick()
    object.__setattr__(inv, "_serial", serial)
    return answer


def _freeze_ast(raw, kind, inv, call):
    """Validate signature/core syntax, copying every expanded occurrence."""
    functions, predicates = inv._body["functions"], inv._body["predicates"]
    pending, built = [(False, kind, raw)], []
    while pending:
        call.tick()
        done, sort, item = pending.pop()
        if done:
            tag, symbol, arity = item
            children = tuple(built[-arity:]) if arity else ()
            if arity:
                del built[-arity:]
            if tag == "var":
                tree = (tag, symbol)
            elif tag in ("fun", "pred"):
                tree = (tag, symbol, children)
            elif tag == "all":
                tree = (tag, symbol, children[0])
            else:
                tree = (tag,) + children
            built.append(tree)
            continue
        call.need(type(item) in (tuple, list) and bool(item), "core AST")
        tag = item[0]
        if sort == "T" and tag == "var":
            call.need(len(item) == 2 and _nat(item[1]), "variable")
            pending.append((True, sort, (tag, item[1], 0)))
            continue
        if tag in ("fun", "pred"):
            expected = "T" if tag == "fun" else "F"
            table = functions if tag == "fun" else predicates
            call.need(sort == expected and len(item) == 3 and _nat(item[1]) and
                      item[1] < len(table) and type(item[2]) in (tuple, list) and
                      len(item[2]) == table[item[1]], "application")
            symbol, children, child_sort = item[1], item[2], "T"
        elif sort == "F" and tag == "all":
            call.need(len(item) == 3 and _nat(item[1]), "quantifier")
            symbol, children, child_sort = item[1], (item[2],), "F"
        else:
            call.need(sort == "F" and tag in ("eq", "not", "imp") and
                      len(item) == (2 if tag == "not" else 3), "connective")
            symbol, children = None, item[1:]
            child_sort = "T" if tag == "eq" else "F"
        pending.append((True, sort, (tag, symbol, len(children))))
        for child in reversed(children):
            call.tick()
            pending.append((False, child_sort, child))
    call.need(len(built) == 1, "one AST")
    return built[0]


def _nodes(tree, call):
    count, maximum, pending = 0, -1, [tree]
    while pending:
        call.tick()
        node = pending.pop()
        count += 1
        tag = node[0]
        if tag in ("var", "all"):
            maximum = max(maximum, node[1])
        children = node[2] if tag in ("fun", "pred") else (() if tag == "var" else
                   ((node[2],) if tag == "all" else node[1:]))
        for child in children:
            call.tick()
            pending.append(child)
    return count, maximum


def _equal(left, right, call):
    """Exact immutable structural equality without Python's recursive tuple walk."""
    pending = [(left, right)]
    while pending:
        call.tick()
        a, b = pending.pop()
        if a is b:
            continue
        if type(a) is not type(b):
            return False
        if type(a) is tuple:
            if len(a) != len(b):
                return False
            for x, y in zip(a, b):
                call.tick()
                pending.append((x, y))
        elif type(a) in (str, int, bool) or a is None:
            if a != b:
                return False
        else:
            # Private model token/handle identity, never user-defined equality.
            return False
    return True


def _within(tree, inv, call):
    count, maximum = _nodes(tree, call)
    return count <= inv._body["b"] and maximum < inv._body["b"]


def _ordinary(value, call):
    """Fresh JSON copy; never accepts a handle or operational token."""
    pending, built = [(False, value)], []
    while pending:
        call.tick()
        done, item = pending.pop()
        if done:
            kind, names = item
            n = len(names) if kind == "dict" else names
            children = built[-n:] if n else []
            if n:
                del built[-n:]
            if kind == "dict":
                result = {}
                for key, child in zip(names, children):
                    call.tick()
                    result[key] = child
            else:
                result = children
            built.append(result)
        elif type(item) is dict:
            names = tuple(sorted(item))
            call.need(all(type(x) is str for x in names), "ordinary string keys")
            pending.append((True, ("dict", names)))
            for key in reversed(names):
                call.tick()
                pending.append((False, item[key]))
        elif type(item) in (tuple, list):
            pending.append((True, ("list", len(item))))
            for child in reversed(item):
                call.tick()
                pending.append((False, child))
        else:
            call.need(item is None or type(item) in (int, bool, str), "ordinary scalar only")
            built.append(item)
    return built[0]


def _model(inv, call):
    body = inv._body
    return _ordinary({"schema": "FPC-point-model-identity-v1", "inventory_version": VERSION,
        "query_hex": body["raw"].hex(), "query": body["query_record"],
        "frame": {"schema": "FPC-point-frame-v1", "rows": body["n"], "syntax_nodes": body["b"]}}, call)


def create_inventory(query_bytes, *, frame, modules, check):
    inv = object.__new__(_Inventory)
    for name, value in (("_owner", _OWNER), ("_token", object()), ("_body", {}),
                        ("_serial", 0), ("_fault", None), ("_closed", False)):
        object.__setattr__(inv, name, value)
    call = _Call(inv, check)
    try:
        call.tick()
        call.need(type(query_bytes) is bytes, "immutable query bytes")
        _keys(frame, ("schema", "rows", "syntax_nodes"), call)
        call.need(frame["schema"] == "FPC-point-frame-v1" and _nat(frame["rows"]) and
                  frame["rows"] > 0 and _nat(frame["syntax_nodes"]) and frame["syntax_nodes"] > 0,
                  "strict positive frame")
        _keys(modules, ("checker", "builders"), call)
        ok, query = call.helper(modules["checker"], modules["checker"].decode_query, query_bytes)
        call.need(ok, "malformed query")
        body = {"n": frame["rows"], "b": frame["syntax_nodes"], "raw": query_bytes,
                "modules": dict(modules), "functions": tuple(query["function_arities"]),
                "predicates": tuple(query["predicate_arities"]), "profile": query["theory_profile"]}
        # No handle escapes until construction finishes. Signature context is
        # needed by checked freezing; this is not a public state transition.
        object.__setattr__(inv, "_body", body)
        gamma, finite = [], []
        for f in query["Gamma"]:
            call.tick()
            gamma.append(_freeze_ast(f, "F", inv, call))
        for f in query["finite_axioms"]:
            call.tick()
            finite.append(_freeze_ast(f, "F", inv, call))
        goal = _freeze_ast(query["goal"], "F", inv, call)
        table_source = finite if body["profile"] == 0 else (
            modules["builders"].PA_AXIOMS if body["profile"] == 1 else modules["builders"].INCIDENCE_AXIOMS)
        table, fv = [], set()
        for f in table_source:
            call.tick()
            table.append(_freeze_ast(f, "F", inv, call))
        for f in gamma:
            call.tick()
            permitted, values = call.helper(modules["builders"], modules["builders"].formula_free_variables, f)
            call.need(permitted, "valid full Gamma FV")
            for x in values:
                call.tick()
                call.need(_nat(x), "FV variable")
                fv.add(x)
        record = {"version": query["version"], "claim_mode": query["claim_mode"],
                  "function_arities": body["functions"], "predicate_arities": body["predicates"],
                  "theory_profile": body["profile"], "finite_axioms": tuple(finite),
                  "Gamma": tuple(gamma), "goal": goal}
        final = dict(body, gamma=tuple(gamma), goal=goal, table=tuple(table), full_FV=frozenset(fv),
                     query_record=record)
        call.tick()
        object.__setattr__(inv, "_body", final)
        return inv
    except BaseException:
        call.fault()
        raise


def _syntax(sort):
    return {"sort": sort, "size": 1, "prefix": (), "frames": (),
            "pending": ((sort, 1),), "next": 0, "composition": None, "phase": "CHOOSE"}


def _choice(sort, index, inv, size, call):
    b, fs, ps = inv._body["b"], inv._body["functions"], inv._body["predicates"]
    if sort == "T":
        if index < b:
            return ("var", index, ())
        k = index - b
        if k >= len(fs):
            return None
        arity, tag, symbol = fs[k], "fun", k
        if arity + 1 > size:
            return ("SKIP_IMPOSSIBLE_ARITY", symbol, ())
        kinds = []
        for _ in range(arity):
            call.tick()
            kinds.append("T")
        return (tag, symbol, tuple(kinds))
    if index < len(ps):
        if ps[index] + 1 > size:
            return ("SKIP_IMPOSSIBLE_ARITY", index, ())
        kinds = []
        for _ in range(ps[index]):
            call.tick()
            kinds.append("T")
        return ("pred", index, tuple(kinds))
    k = index - len(ps)
    if k < 3:
        return (("eq", None, ("T", "T")), ("not", None, ("F",)),
                ("imp", None, ("F", "F")))[k]
    return ("all", k - 3, ("F",)) if k - 3 < b else None


def _syntax_step(state, inv, call):
    s = dict(state)
    call.tick()
    if s["phase"] == "EOF":
        return "EOF", None, s
    if s["phase"] == "BUILD":
        values = []
        for tag, symbol, kinds in reversed(s["prefix"]):
            call.tick()
            children = []
            for _ in kinds:
                call.tick()
                children.append(values.pop())
            if tag == "var":
                value = (tag, symbol)
            elif tag in ("fun", "pred"):
                value = (tag, symbol, tuple(children))
            elif tag == "all":
                value = (tag, symbol, children[0])
            else:
                value = (tag,) + tuple(children)
            values.append(value)
        call.need(len(values) == 1, "syntax cursor tree")
        s["phase"] = "BACKTRACK"
        return "VALUE", values[0], s
    if s["phase"] == "BACKTRACK":
        if s["frames"]:
            pending, chosen, composition = s["frames"][-1]
            next_composition = _next_composition(composition, pending[0][1] - 1, call)
            s.update(frames=s["frames"][:-1], prefix=s["prefix"][:-1],
                     pending=pending, next=chosen if next_composition is not None else chosen + 1,
                     composition=next_composition, phase="CHOOSE")
        elif s["size"] < inv._body["b"]:
            size = s["size"] + 1
            s = dict(_syntax(s["sort"]), size=size, pending=((s["sort"], size),))
        else:
            s["phase"] = "EOF"
        return "PENDING", None, s
    pending = s["pending"]
    call.need(bool(pending), "syntax pending invariant")
    sort, size = pending[0]
    token = _choice(sort, s["next"], inv, size, call)
    if token is None:
        s["phase"] = "BACKTRACK"
        return "PENDING", None, s
    if token[0] == "SKIP_IMPOSSIBLE_ARITY":
        s["next"] += 1
        s["composition"] = None
        return "PENDING", None, s
    arity = len(token[2])
    if (arity == 0 and size != 1) or (arity > 0 and size - 1 < arity):
        s["next"] += 1
        s["composition"] = None
    else:
        composition = s["composition"]
        if composition is None:
            composition = () if not arity else (1,) * (arity - 1) + (size - arity,)
        child_slots = []
        for child_sort, child_size in zip(token[2], composition):
            call.tick()
            child_slots.append((child_sort, child_size))
        next_pending = tuple(child_slots) + pending[1:]
        s.update(frames=s["frames"] + ((pending, s["next"], composition),),
                 prefix=s["prefix"] + (token,), pending=next_pending, next=0, composition=None)
        if not next_pending:
            s["phase"] = "BUILD"
    return "PENDING", None, s


def _next_composition(parts, total, call):
    """Next lexicographic positive composition of fixed length, no table."""
    if len(parts) < 2:
        return None
    values = list(parts)
    suffix = values[-1]
    for i in range(len(values) - 2, -1, -1):
        call.tick()
        if suffix > len(values) - i - 1:
            values[i] += 1
            remaining = suffix - 1
            for j in range(i + 1, len(values) - 1):
                call.tick()
                values[j] = 1
                remaining -= 1
            values[-1] = remaining
            return tuple(values)
        suffix += values[i]
    return None


def _slot(kind, limit, fixed=None):
    if fixed is not None:
        return {"sort": "FIXED", "source_sort": kind, "value": fixed, "done": False}
    return _syntax(kind) if kind in ("F", "T") else {"sort": kind, "at": 0, "limit": limit}


def _slot_step(state, inv, call):
    if state["sort"] == "FIXED":
        call.tick()
        if state["done"]:
            return "EOF", None, state
        return "VALUE", state["value"], dict(state, done=True)
    if state["sort"] in ("F", "T"):
        return _syntax_step(state, inv, call)
    call.tick()
    if state["at"] >= state["limit"]:
        return "EOF", None, state
    return "VALUE", state["at"], dict(state, at=state["at"] + 1)


def _product(specs, fixed=None):
    empty = any(k not in ("F", "T") and limit == 0 for k, limit in specs)
    if fixed is None:
        return {"specs": specs, "states": tuple(_slot(k, limit) for k, limit in specs),
                "values": (None,) * len(specs), "at": 0, "phase": "EOF" if empty else "FILL"}
    return {"specs": specs, "fixed": fixed,
            "states": tuple(_slot(k, limit, fixed[i]) for i, (k, limit) in enumerate(specs)),
            "values": (None,) * len(specs), "at": 0, "phase": "EOF" if empty else "FILL"}


def _product_step(state, inv, call):
    p = dict(state)
    call.tick()
    if p["phase"] == "EOF":
        return "EOF", None, p
    n = len(p["specs"])
    if p["phase"] == "EMIT":
        p["phase"] = "NEXT"
        return "VALUE", p["values"], p
    if p["phase"] == "NEXT":
        if not n:
            p["phase"] = "EOF"
            return "PENDING", None, p
        p["at"], p["phase"] = n - 1, "FILL"
    if not n:
        p["phase"] = "EMIT"
        return "PENDING", None, p
    at = p["at"]
    kind, value, next_slot = _slot_step(p["states"][at], inv, call)
    states, values = list(p["states"]), list(p["values"])
    states[at] = next_slot
    if kind == "VALUE":
        values[at] = value
        if at + 1 == n:
            p["phase"] = "EMIT"
        else:
            p["at"] = at + 1
            k, limit = p["specs"][at + 1]
            states[at + 1] = _slot(k, limit, None if p.get("fixed") is None else p["fixed"][at + 1])
            values[at + 1] = None
    elif kind == "EOF":
        if at == 0:
            p["phase"] = "EOF"
        else:
            p["at"] = at - 1
            values[at] = None
    p["states"], p["values"] = tuple(states), tuple(values)
    return "PENDING", None, p


def _point(point, inv, call):
    call.need(type(point) is tuple and len(point) == 2 and
              all(type(x) is int for x in point) and point[1] == 0 and
              0 <= point[0] < inv._body["n"], "required frame cell")
    return point[0]


def root_state(inventory, *, check):
    inv, call = _begin(inventory, check, (_Inventory,))
    try:
        selected, totals = [], []
        for _ in range(inv._body["n"]):
            call.tick()
            selected.append(None)
            totals.append((0, 1))
        data = {"parent": None, "selected": tuple(selected), "t": tuple(totals),
                "m": (((inv._body["n"] - 1, 1), ("FPC", inv._body["goal"]), 1),)}
        return _commit_handle(_State, inv, data, call)
    except BaseException:
        call.fault()
        raise


def _counts():
    return dict.fromkeys(_COUNTERS, 0)


def _intrinsic(inv, row, rule, subtag, args, call):
    """A typed raw tuple -> exact base member or intrinsic refusal.

    This is not a proof checker: earlier references give formula-valued ports,
    and their agreement is enforced by the point state, not by proof replay.
    """
    body, builders = inv._body, inv._body["modules"]["builders"]
    references, formulas, terms, variables = (), [], [], []
    witness, formula = None, None
    if rule == 0:
        index = args[0]
        if index >= len(body["gamma"]):
            return None
        formula, witness = body["gamma"][index], index
    elif rule == 1:
        for kind, value in zip(_SORTS[subtag], args):
            call.tick()
            if kind == "F":
                formulas.append(value)
            elif kind == "T":
                terms.append(value)
            else:
                variables.append(value)
        ok, result = call.helper(builders, builders.logical_axiom, subtag, list(args))
        if not ok:
            return None
        formula = _freeze_ast(result, "F", inv, call)
        witness = tuple(args)
    elif rule == 2:
        if subtag == 2:
            a, x = args
            if body["profile"] != 1:
                return None
            ok, free = call.helper(builders, builders.formula_free_variables, a)
            if not ok:
                return None
            parameters = []
            for value in sorted(free):
                call.tick()
                if value != x:
                    parameters.append(value)
            ok, result = call.helper(builders, builders.pa_induction, a, x, parameters)
            if not ok:
                return None
            formula = _freeze_ast(result, "F", inv, call)
            witness = (a, x, tuple(parameters))
            formulas.append(a)
            variables.extend((x,) + tuple(parameters))
        else:
            expected = (0, 1, 3)[body["profile"]]
            index = args[0]
            if subtag != expected or index >= len(body["table"]):
                return None
            formula, witness = body["table"][index], index
    elif rule == 3:
        a, b, j, k = args
        if not (0 <= j < row and 0 <= k < row and j != k):
            return None
        implication = ("imp", a, b)
        formula, witness = b, (j, k)
        references = ((j, a), (k, implication))
        formulas.extend((a, b, implication))
    elif rule == 4:
        a, x, j = args
        if not (0 <= j < row) or x in body["full_FV"]:
            return None
        formula, witness = ("all", x, a), (j, x)
        references = ((j, a),)
        formulas.append(a)
        variables.append(x)
    else:
        _invalid("internal primitive family")
    t = (((row, 0), (1, 1)),)
    marks = [((row, 1), ("FPC", formula))]
    for index, value in references:
        call.tick()
        marks.append(((index, 1), ("FPC", value)))
    marks.sort(key=lambda item: item[0])
    m = tuple(marks)
    # The ordinary MP/GEN payload alone is intentionally NOT the identity.
    # Full formula-valued ports and output participate in this exact tuple.
    key = (inv._token, ("ROW", row), rule, subtag, witness, t, m)
    return {"row": row, "rule": rule, "subtag": subtag, "witness": witness,
            "formula": formula, "references": references, "t": t, "m": m,
            "key": key, "formula_witnesses": tuple(formulas),
            "term_witnesses": tuple(terms), "variables": tuple(variables)}


def _envelope(data, inv, call):
    for value in data["variables"]:
        call.tick()
        if not _nat(value) or value >= inv._body["b"]:
            return False
    for tree in (data["formula"],) + data["formula_witnesses"] + data["term_witnesses"]:
        call.tick()
        if not _within(tree, inv, call):
            return False
    for _, mark in data["m"]:
        call.tick()
        if not _within(mark[1], inv, call):
            return False
    return True


def _legal(state, data, call):
    row = data["row"]
    if state._data["selected"][row] is not None or state._data["t"][row] != (0, 1):
        return False
    for point, value in data["m"]:
        call.tick()
        for existing, mark, _ in state._data["m"]:
            call.tick()
            if existing == point and not _equal(mark, value, call):
                return False
    return True


def _member(inv, data, call):
    rule, subtag, witness = data["rule"], data["subtag"], data["witness"]
    if rule in (0, 2) and subtag != 2:
        args = (witness,)
    elif rule == 2:
        args = witness[:2]
    elif rule == 3:
        refs = data["references"]
        args = (refs[0][1], data["formula"], witness[0], witness[1])
    elif rule == 4:
        args = (data["references"][0][1], witness[1], witness[0])
    else:
        args = witness
    again = _intrinsic(inv, data["row"], rule, subtag, args, call)
    return again is not None and _equal(again["key"], data["key"], call) and _envelope(again, inv, call)


def place_state(state, candidate, *, check):
    inv, call = _begin(state, check, (_State,))
    try:
        call.need(type(candidate) is _Candidate and candidate._owner is _OWNER and
                  candidate._inv is inv and not candidate._closed, "same current member")
        data = candidate._data
        call.need(_member(inv, data, call) and _legal(state, data, call), "illegal placement")
        selected, totals = list(state._data["selected"]), list(state._data["t"])
        selected[data["row"]], totals[data["row"]] = candidate, (1, 1)
        marks = list(state._data["m"])
        for point, mark in data["m"]:
            call.tick()
            found = False
            for i in range(len(marks)):
                call.tick()
                if marks[i][0] == point:
                    marks[i] = (point, mark, marks[i][2] + 1)
                    found = True
                    break
            if not found:
                marks.append((point, mark, 1))
        marks.sort(key=lambda item: item[0])
        child = {"parent": state, "selected": tuple(selected), "t": tuple(totals), "m": tuple(marks)}
        return _commit_handle(_State, inv, child, call)
    except BaseException:
        call.fault()
        raise


def state_section(state, *, check):
    inv, call = _begin(state, check, (_State,))
    selected, totals = [], []
    for row, candidate in enumerate(state._data["selected"]):
        call.tick()
        selected.append(None if candidate is None else candidate._data["key"])
        totals.append(((row, 0), state._data["t"][row]))
    answer = ("FPC-point-state-section-v1", inv, state._serial, state._data["parent"],
              tuple(selected), tuple(totals), state._data["m"])
    call.tick()
    return answer


def _families(inv, row):
    b = inv._body["b"]
    result = [(0, None, (("I", len(inv._body["gamma"])),))]
    for tag, kinds in enumerate(_SORTS):
        result.append((1, tag, tuple((kind, b) for kind in kinds)))
    subtag = (0, 1, 3)[inv._body["profile"]]
    result.append((2, subtag, (("I", len(inv._body["table"])),)))
    if inv._body["profile"] == 1:
        result.append((2, 2, (("F", b), ("V", b))))
    result.extend(((3, None, (("F", b), ("F", b), ("J", row), ("K", row))),
                   (4, None, (("F", b), ("V", b), ("J", row)))))
    return tuple(result)


# Rigid output equations. Numeric meta names denote ORIGINAL raw-slot indices;
# '?' is an unconstrained subtree, never a generated or assumed formula.
_OUTPUT_PATTERNS = (
    ("imp", "$0", ("imp", "$1", "$0")),
    ("imp", ("imp", "$0", ("imp", "$1", "$2")),
     ("imp", ("imp", "$0", "$1"), ("imp", "$0", "$2"))),
    ("imp", ("imp", ("not", "$1"), ("not", "$0")), ("imp", "$0", "$1")),
    ("imp", ("all", "$1", "$0"), "?"),
    ("imp", ("all", "$2", ("imp", "$0", "$1")),
     ("imp", ("all", "$2", "$0"), ("all", "$2", "$1"))),
    ("imp", "$0", ("all", "$1", "$0")),
    ("eq", "$0", "$0"),
    ("imp", ("eq", "$2", "$3"), ("imp", "?", "?")),
)


def _restriction_start(inv, row, rule, subtag, hint, call):
    """Private equation plan; no member/EOF authority outside its caller.

    The public caller has already run the unchanged whole-output family skip.
    Direct white-box use requires a genuine Inventory and immutable core hint;
    this helper proves fixed-slot membership, not the entire output envelope.
    Only call.tick is required. No forward builder or external helper is called.
    """
    call.tick()
    specs = None
    for r, t, original in _families(inv, row):
        call.tick()
        if r == rule and t == subtag:
            specs = original
            break
    progress = {"stage": "DONE", "rule": rule, "subtag": subtag, "row": row,
                "hint": hint, "focus": hint, "specs": specs,
                "fixed": () if specs is None else (None,) * len(specs),
                "todo": None, "slot_index": 0, "nodes": 0,
                "member_started": False, "result": "FULL_RAW", "reason": None}
    if hint is None or specs is None or rule not in (1, 2, 3, 4):
        return progress
    if rule == 1:
        pattern = _OUTPUT_PATTERNS[subtag]
    elif rule == 2:
        if subtag != 2:
            return progress
        pattern = ("imp", "?", ("all", "$1", "$0"))
    elif rule == 3:
        pattern = "$1"
    else:
        pattern = ("all", "$1", "$0")
    progress.update(stage="PREFIX" if rule == 2 else "MATCH", result=None,
                    todo=(("MATCH", pattern, hint), None))
    return progress


def _restriction_step(progress, inv, call):
    """One checked work item, with persistent linked work stacks.

    Return (PENDING/FULL_RAW/RESTRICTED/EMPTY, fixed-or-None, new_progress).
    Immutable parent values are shared; no input progress/container is mutated.
    A genuine callback fault escapes before the public cursor's final commit.
    """
    call.tick()
    p = dict(progress)
    stage = p["stage"]
    if stage == "DONE":
        result = p["result"]
        return result, p["fixed"] if result == "RESTRICTED" else None, p
    if stage == "PREFIX":
        value = p["focus"]
        if type(value) is not tuple or not value:
            p.update(stage="DONE", result="EMPTY", reason="OUTPUT_EQUATION_MISMATCH")
        elif value[0] == "all":
            if len(value) != 3:
                p.update(stage="DONE", result="EMPTY", reason="OUTPUT_EQUATION_MISMATCH")
            else:
                p["focus"] = value[2]
        else:
            p.update(stage="MATCH", todo=(("MATCH", ("imp", "?", ("all", "$1", "$0")), value), None))
        return "PENDING", None, p
    if stage == "MATCH":
        if p["todo"] is None:
            p.update(stage="MEMBERSHIP", slot_index=0, nodes=0, member_started=False)
            return "PENDING", None, p
        task, rest = p["todo"]
        p["todo"] = rest
        mode = task[0]
        if mode == "CHILDREN":
            _, child_mode, left, right, at = task
            if at < len(left):
                tail = (("CHILDREN", child_mode, left, right, at + 1), rest)
                p["todo"] = ((child_mode, left[at], right[at]), tail)
            return "PENDING", None, p
        _, pattern, value = task
        if mode == "MATCH" and pattern == "?":
            return "PENDING", None, p
        if mode == "MATCH" and type(pattern) is str and pattern.startswith("$"):
            slot = int(pattern[1:])  # Trusted fixed calculus pattern, never user syntax.
            previous = p["fixed"][slot]
            if previous is None:
                fixed = list(p["fixed"])
                fixed[slot] = value
                p["fixed"] = tuple(fixed)
            else:
                p["todo"] = (("EQUAL", previous, value), rest)
            return "PENDING", None, p
        if type(pattern) is tuple:
            if type(value) is not tuple or len(pattern) != len(value):
                p.update(stage="DONE", result="EMPTY", reason="OUTPUT_EQUATION_MISMATCH")
            else:
                p["todo"] = (("CHILDREN", mode, pattern, value, 0), rest)
        elif type(pattern) is not type(value) or pattern != value:
            p.update(stage="DONE", result="EMPTY", reason="OUTPUT_EQUATION_MISMATCH")
        return "PENDING", None, p
    # Membership is exact original-slot language membership, not whole-row
    # output/premise membership. The complete forward/envelope stages still run.
    if p["todo"] is None:
        if p["member_started"]:
            p.update(slot_index=p["slot_index"] + 1, nodes=0, member_started=False)
        elif p["slot_index"] == len(p["fixed"]):
            p.update(stage="DONE", result="RESTRICTED")
        else:
            at = p["slot_index"]
            value, (kind, limit) = p["fixed"][at], p["specs"][at]
            if value is None:
                p["slot_index"] = at + 1
            elif kind in ("F", "T"):
                p.update(todo=(("AST", kind, value), None), member_started=True, nodes=0)
            elif not _nat(value) or value >= limit:
                p.update(stage="DONE", result="EMPTY", reason="FIXED_SLOT_OUTSIDE_ORIGINAL_LANGUAGE")
            else:
                p["slot_index"] = at + 1
        return "PENDING", None, p
    task, rest = p["todo"]
    p["todo"] = rest
    if task[0] == "AST_CHILDREN":
        _, kind, children, at = task
        if at < len(children):
            tail = (("AST_CHILDREN", kind, children, at + 1), rest)
            p["todo"] = (("AST", kind, children[at]), tail)
        return "PENDING", None, p
    _, kind, tree = task
    p["nodes"] += 1
    valid = p["nodes"] <= inv._body["b"] and type(tree) is tuple and bool(tree)
    children, child_kind = (), None
    if valid:
        tag = tree[0]
        if kind == "T" and tag == "var":
            valid = len(tree) == 2 and _nat(tree[1]) and tree[1] < inv._body["b"]
        elif tag in ("fun", "pred"):
            wanted = "T" if tag == "fun" else "F"
            table = inv._body["functions"] if tag == "fun" else inv._body["predicates"]
            valid = (kind == wanted and len(tree) == 3 and _nat(tree[1]) and
                     tree[1] < len(table) and type(tree[2]) is tuple and
                     len(tree[2]) == table[tree[1]])
            if valid:
                children, child_kind = tree[2], "T"
        elif kind == "F" and tag == "all":
            valid = len(tree) == 3 and _nat(tree[1]) and tree[1] < inv._body["b"]
            if valid:
                children, child_kind = (tree[2],), "F"
        else:
            valid = (kind == "F" and tag in ("eq", "not", "imp") and
                     len(tree) == (2 if tag == "not" else 3))
            if valid:
                children, child_kind = tree[1:], "T" if tag == "eq" else "F"
    if not valid:
        p.update(stage="DONE", result="EMPTY", reason="FIXED_SLOT_OUTSIDE_ORIGINAL_LANGUAGE")
    elif children:
        p["todo"] = (("AST_CHILDREN", child_kind, children, 0), rest)
    return "PENDING", None, p


def _raw(inv, row):
    return {"family": 0, "product": None, "phase": "NORMALIZE", "skipped": (),
            "args": None, "member": None, "raw_index": 0, "eof": False, "binding": None}


# Necessary output constructors, not inverse witnesses. Each entry is
# (child-slot path, constructor); ancestors precede paths through them.
# Omitted children/metadata are unconstrained. These are fixed calculus data.
_CONCLUSION_SHAPES = (
    (((), "imp"), ((2,), "imp")),
    (((), "imp"), ((1,), "imp"), ((1, 2), "imp"),
     ((2,), "imp"), ((2, 1), "imp"), ((2, 2), "imp")),
    (((), "imp"), ((1,), "imp"), ((1, 1), "not"),
     ((1, 2), "not"), ((2,), "imp")),
    (((), "imp"), ((1,), "all")),
    (((), "imp"), ((1,), "all"), ((1, 2), "imp"),
     ((2,), "imp"), ((2, 1), "all"), ((2, 2), "all")),
    (((), "imp"), ((2,), "all")),
    (((), "eq"),),
    (((), "imp"), ((1,), "eq"), ((2,), "imp")),
)
_INDUCTION_CONCLUSION_SHAPE = (
    ((), "imp"), ((1,), "not"), ((1, 1), "imp"),
    ((1, 1, 2), "not"), ((1, 1, 2, 1), "all"),
    ((1, 1, 2, 1, 2), "imp"), ((2,), "all"))


def _conclusion_compatible(hint, rule, subtag, call):
    """Conservative family-wide constructor test on an authenticated output.

    All logical constructors shown here are fixed by logical_axiom. For PA
    induction only its parameter closure is peeled; the remaining core must
    have the fixed antecedent/forall-consequent shape. Repeated witnesses,
    binder equalities, substitution results and guards are deliberately NOT
    decided here. True leaves the entire old raw product intact. False proves
    that no ground member of this family can agree with this exact output.
    """
    call.tick()
    if rule == 1:
        shape = _CONCLUSION_SHAPES[subtag]
    else:
        # The caller restricts this branch to THEORY's PA-induction subtag2.
        while hint[0] == "all":
            call.tick()
            hint = hint[2]
        shape = _INDUCTION_CONCLUSION_SHAPE
    for path, tag in shape:
        call.tick()
        value = hint
        for slot in path:
            call.tick()
            value = value[slot]
        if value[0] != tag:
            return False
    return True


def _family_skip(inv, state, row, rule, subtag, call):
    """Sound necessary conditions only; never an inverse-match miss.

    A term has >=1 constructor. With a variable available, predicate arity k
    gives 1+k; equality gives 3. Every other formula constructor is larger.
    Substitution cannot shrink a tree because an inserted term has >=1 node.
    The displayed structural lower bounds therefore cover every raw witness,
    including shadowed/no-op substitutions and induction closure parameters.
    """
    call.tick()
    minimum = 3
    for arity in inv._body["predicates"]:
        call.tick()
        minimum = min(minimum, 1 + arity)
    hint = _port(state, row, call)
    reason, bound = None, None
    if hint is not None and not _within(hint, inv, call):
        reason = "ASSIGNED_OUTPUT_OUTSIDE_ENVELOPE"
    elif rule == 1:
        bound = (2 + 3 * minimum, 6 + 7 * minimum, 5 + 4 * minimum,
                 2 + 2 * minimum, 6 + 4 * minimum, 2 + 2 * minimum,
                 3, 5 + 2 * minimum)[subtag]
        expected = "eq" if subtag == 6 else "imp"
        if hint is not None and hint[0] != expected:
            reason = "INCOMPATIBLE_ASSIGNED_OUTPUT_TAG"
    elif rule == 2 and subtag == 2:
        bound = 7 + 4 * minimum
        if hint is not None and hint[0] not in ("imp", "all"):
            reason = "INCOMPATIBLE_ASSIGNED_OUTPUT_TAG"
    elif rule == 3:
        bound = 1 + 2 * minimum  # The implication premise must also fit b.
        if row < 2:
            reason = "NO_TWO_DISTINCT_EARLIER_REFERENCES"
    elif rule == 4:
        bound = 1 + minimum
        if row == 0:
            reason = "NO_EARLIER_REFERENCE"
        elif hint is not None and hint[0] != "all":
            reason = "INCOMPATIBLE_ASSIGNED_OUTPUT_TAG"
    if reason is None and bound is not None and bound > inv._body["b"]:
        reason = "STRUCTURAL_MINIMUM_EXCEEDS_ENVELOPE"
    if reason is None and hint is not None and (rule == 1 or (rule == 2 and subtag == 2)):
        if not _conclusion_compatible(hint, rule, subtag, call):
            reason = "INCOMPATIBLE_ASSIGNED_OUTPUT_CONSTRUCTOR_SHAPE"
    if reason is None:
        return None
    return {"rule_tag": rule, "subtag": subtag, "reason": reason,
            "minimum_formula_nodes": minimum, "necessary_nodes": bound,
            "syntax_nodes": inv._body["b"],
            "assigned_output_tag": None if hint is None else hint[0]}


def _raw_step(raw, state, call):
    """One resumable raw-family/product or membership phase; never a generator."""
    inv = state._inv
    r = dict(raw)
    call.tick()
    if r["eof"]:
        return "EOF", None, r, "EOF", None
    families = _families(inv, r["row"] if "row" in r else 0)
    # row is installed by _raw_for; it is not taken from external cursor data.
    rule, subtag, specs = families[r["family"]]
    phase = r["phase"]
    if phase == "NORMALIZE":
        reason = _family_skip(inv, state, r["row"], rule, subtag, call)
        if reason is None:
            r.update(binding=_restriction_start(inv, r["row"], rule, subtag,
                                                _port(state, r["row"], call), call), phase="BIND")
        else:
            r["skipped"] += (reason,)
            index = r["family"] + 1
            if index == len(families):
                r.update(eof=True, phase="EOF")
                return "EOF", None, r, "EOF", "fallback_eof_events"
            r.update(family=index, product=None, binding=None)
        return "PENDING", None, r, phase, None
    if phase == "BIND":
        kind, fixed, binding = _restriction_step(r["binding"], inv, call)
        r["binding"] = binding
        if kind == "FULL_RAW":
            r.update(product=_product(specs), phase="ENUMERATE")
        elif kind == "RESTRICTED":
            r.update(product=_product(specs, fixed), phase="ENUMERATE")
        elif kind == "EMPTY":
            r["skipped"] += ({"rule_tag": rule, "subtag": subtag,
                              "reason": binding["reason"], "scope": "COMPLETE_OUTPUT_SLOT_EQUATION"},)
            index = r["family"] + 1
            if index == len(families):
                r.update(eof=True, phase="EOF")
                return "EOF", None, r, "EOF", "fallback_eof_events"
            r.update(family=index, product=None, binding=None, phase="NORMALIZE")
        return "PENDING", None, r, "NORMALIZE", None
    if phase == "ENUMERATE":
        kind, args, product = _product_step(r["product"], inv, call)
        r["product"] = product
        if kind == "EOF":
            index = r["family"] + 1
            if index == len(families):
                r.update(eof=True, phase="EOF")
                return "EOF", None, r, "EOF", "fallback_eof_events"
            r.update(family=index, product=None, binding=None, phase="NORMALIZE")
        elif kind == "VALUE":
            r.update(args=args, phase="INTRINSIC", raw_index=r["raw_index"] + 1)
            return "PENDING", None, r, "ENUMERATE", "raw_tuples_complete"
        return "PENDING", None, r, "ENUMERATE", None
    if phase == "INTRINSIC":
        member = _intrinsic(inv, r["row"], rule, subtag, r["args"], call)
        if member is None:
            r.update(phase="ENUMERATE", args=None, member=None)
            return "PENDING", None, r, phase, "intrinsic_refusals"
        r.update(member=member, phase="ENVELOPE")
        return "PENDING", None, r, phase, None
    if phase == "ENVELOPE":
        if not _envelope(r["member"], inv, call):
            r.update(phase="ENUMERATE", args=None, member=None)
            return "PENDING", None, r, phase, "envelope_exclusions"
        r["phase"] = "POINT_CHECK"
        return "PENDING", None, r, phase, None
    if phase == "POINT_CHECK":
        if not _legal(state, r["member"], call):
            r.update(phase="ENUMERATE", args=None, member=None)
            return "PENDING", None, r, phase, "point_conflicts"
        r["phase"] = "EMIT"
        return "PENDING", None, r, phase, None
    call.need(phase == "EMIT", "raw phase")
    member = r["member"]
    r.update(phase="ENUMERATE", args=None, member=None)
    return "CANDIDATE", _handle(_Candidate, inv, member), r, "EMIT", None


def _raw_for(inv, row):
    return dict(_raw(inv, row), row=row)


def _port(state, row, call):
    for point, mark, _ in state._data["m"]:
        call.tick()
        if point == (row, 1):
            return mark[1]
    return None


def _match(pattern, value, call):
    """Only a proposal matcher. A miss NEVER supplies a degree certificate."""
    bindings, pending = {}, [(pattern, value)]
    while pending:
        call.tick()
        p, v = pending.pop()
        if type(p) is str and p.startswith("$"):
            if p in bindings and not _equal(bindings[p], v, call):
                return None
            bindings[p] = v
        elif type(p) is tuple:
            if type(v) is not tuple or len(p) != len(v):
                return None
            for a, b in zip(p, v):
                call.tick()
                pending.append((a, b))
        elif p != v:
            return None
    return bindings


_SHORT_PATTERNS = (
    (0, ("imp", "$A", ("imp", "$B", "$A")), ("$A", "$B")),
    (1, ("imp", ("imp", "$A", ("imp", "$B", "$C")),
         ("imp", ("imp", "$A", "$B"), ("imp", "$A", "$C"))), ("$A", "$B", "$C")),
    (2, ("imp", ("imp", ("not", "$B"), ("not", "$A")),
         ("imp", "$A", "$B")), ("$A", "$B")),
    (4, ("imp", ("all", "$x", ("imp", "$A", "$B")),
         ("imp", ("all", "$x", "$A"), ("all", "$x", "$B"))), ("$A", "$B", "$x")),
    (5, ("imp", "$A", ("all", "$x", "$A")), ("$A", "$x")),
    (6, ("eq", "$t", "$t"), ("$t",)),
)


def _short():
    return {"stage": 0, "index": 0, "j": 0, "k": 0}


def _short_step(short, state, row, call):
    """One finite proposal position; the cache contains at most two members.

    HYP/table, six direct structural inverses, GEN and current implication-port
    MP are accelerators. Q1/E2/induction have no inverse shortcut here; every
    one of their tuples remains in the complete raw stream from the start.
    """
    inv, s = state._inv, dict(short)
    body = inv._body
    call.tick()
    stage, index = s["stage"], s["index"]
    descriptor = None
    if stage < 2:
        table = body["gamma"] if stage == 0 else body["table"]
        if index < len(table):
            descriptor = (0, None, (index,)) if stage == 0 else (
                2, (0, 1, 3)[body["profile"]], (index,))
            s["index"] += 1
        else:
            s.update(stage=stage + 1, index=0)
    elif stage == 2:
        hint = _port(state, row, call)
        if index < len(_SHORT_PATTERNS):
            tag, pattern, order = _SHORT_PATTERNS[index]
            match = None if hint is None else _match(pattern, hint, call)
            s["index"] += 1
            if match is not None:
                args = []
                for name in order:
                    call.tick()
                    args.append(match[name])
                descriptor = (1, tag, tuple(args))
        else:
            s.update(stage=3, index=0)
    elif stage == 3:
        hint = _port(state, row, call)
        if index < row:
            s["index"] += 1
            if hint is not None and hint[0] == "all":
                descriptor = (4, None, (hint[2], hint[1], index))
        else:
            s.update(stage=4, index=0, j=0, k=0)
    elif stage == 4:
        j, k = s["j"], s["k"]
        if k >= row:
            s["stage"] = 5
        else:
            premise = _port(state, k, call)
            hint = _port(state, row, call)
            if j != k and premise is not None and premise[0] == "imp" and (
                    hint is None or _equal(premise[2], hint, call)):
                descriptor = (3, None, (premise[1], premise[2], j, k))
            if j + 1 >= row:
                s.update(j=0, k=k + 1)
            else:
                s["j"] += 1
    else:
        return "EOF", None, s
    if descriptor is None:
        return "PENDING", None, s
    rule, tag, args = descriptor
    member = _intrinsic(inv, row, rule, tag, args, call)
    if member is not None and _envelope(member, inv, call) and _legal(state, member, call):
        return "CANDIDATE", _handle(_Candidate, inv, member), s
    return "PENDING", None, s


def _same_key(candidate, candidates, call):
    for previous in candidates:
        call.tick()
        if _equal(candidate._data["key"], previous._data["key"], call):
            return True
    return False


def _current_remainder(data, call):
    call.need(not data["state"]._closed, "closed parent state")
    branch = data["remainder"]
    if branch is not None:
        call.need(not branch._closed and branch._data["revision"] == data["revision"] and
                  branch._data["outstanding"] is None, "stale branch remainder")


def open_classification(state, point, *, remainder=None, check):
    inv, call = _begin(state, check, (_State,))
    try:
        row = _point(point, inv, call)
        raw, banned, revision = _raw_for(inv, row), (), None
        if remainder is not None:
            call.need(type(remainder) is _BranchCursor and remainder._owner is _OWNER and
                      remainder._inv is inv and not remainder._closed and
                      remainder._data["state"] is state and remainder._data["point"] == point and
                      remainder._data["outstanding"] is None, "exact parent branch remainder")
            raw = remainder._data["tried"]
            excluded = []
            for candidate, tried in zip(remainder._data["shortcuts"], remainder._data["short_tried"]):
                call.tick()
                if tried:
                    excluded.append(candidate)
            banned, revision = tuple(excluded), remainder._data["revision"]
        data = {"state": state, "point": point, "raw": raw, "short": _short(),
                "phase": "SHORT" if remainder is None else "RAW", "witnesses": (),
                "terminal": False, "kind": "UNRESOLVED", "complete": False,
                "banned": banned, "remainder": remainder, "revision": revision,
                "counts": _counts()}
        return _commit_handle(_ClassCursor, inv, data, call)
    except BaseException:
        call.fault()
        raise


def _step_record(cursor, data, kind, action, candidate=None, offer=None):
    return {"schema": "FPC-point-provider-step-v1", "kind": kind, "committed": True,
            "action": action, "candidate": candidate, "offer": offer,
            "cursor_serial": cursor._serial, "state_serial": data["state"]._serial,
            "classification_kind": data["kind"] if type(cursor) is _ClassCursor else None}


def _commit_cursor(cursor, data, answer, call):
    counts = dict(data["counts"])
    counts["committed_actions"] += 1
    data = dict(data, counts=counts)
    call.tick()
    object.__setattr__(cursor, "_data", data)
    return answer


def _advance_class(cursor, call):
    d = dict(cursor._data)
    _current_remainder(d, call)
    call.need(not d["terminal"], "terminal classifier")
    candidate, action, event = None, "ENUMERATE", None
    if d["phase"] == "SHORT":
        kind, candidate, short = _short_step(d["short"], d["state"], d["point"][0], call)
        d["short"] = short
        if kind == "EOF":
            d["phase"] = "RAW"
        elif candidate is not None:
            action, event = "EMIT", "shortcut_candidates_proved"
    else:
        kind, candidate, raw, action, event = _raw_step(d["raw"], d["state"], call)
        d["raw"] = raw
        if kind == "EOF":
            d.update(terminal=True, complete=True,
                     kind="EMPTY" if not d["witnesses"] else "SINGLE")
    if event is not None:
        d["counts"] = dict(d["counts"])
        d["counts"][event] += 1
    if candidate is not None:
        if _same_key(candidate, d["banned"], call) or _same_key(candidate, d["witnesses"], call):
            candidate = None
        else:
            d["witnesses"] += (candidate,)
            d["counts"] = dict(d["counts"])
            d["counts"]["distinct_legal_inspected"] += 1
            if len(d["witnesses"]) == 2:
                d.update(terminal=True, kind="MANY", complete=False)
    kind = "CANDIDATE" if candidate is not None else ("EOF" if d["terminal"] else "PENDING")
    answer = _step_record(cursor, d, kind, action, candidate)
    return _commit_cursor(cursor, d, answer, call)


def classification(cursor, *, check):
    inv, call = _begin(cursor, check, (_ClassCursor,))
    d = cursor._data
    _current_remainder(d, call)
    answer = {"schema": "FPC-point-classification-v1", "kind": d["kind"],
              "coverage_complete": d["complete"], "witnesses": tuple(d["witnesses"]),
              "state_serial": d["state"]._serial, "point": d["point"],
              "remainder_revision": d["revision"], "counts": dict(d["counts"])}
    call.tick()
    return answer


def open_branch(state, point, *, classified, check):
    inv, call = _begin(state, check, (_State,))
    try:
        _point(point, inv, call)
        call.need(type(classified) is _ClassCursor and classified._owner is _OWNER and
                  classified._inv is inv and not classified._closed, "current classification handle")
        c = classified._data
        _current_remainder(c, call)
        call.need(c["state"] is state and c["point"] == point and c["kind"] == "MANY" and
                  c["remainder"] is None, "initial parent MANY classifier")
        raw = _raw_for(inv, point[0])
        data = {"state": state, "point": point, "shortcuts": c["witnesses"],
                "short_tried": (False,) * len(c["witnesses"]), "raw": raw, "tried": raw,
                "phase": "SHORT", "outstanding": None, "revision": 0,
                "terminal": False, "counts": _counts()}
        return _commit_handle(_BranchCursor, inv, data, call)
    except BaseException:
        call.fault()
        raise


def _advance_branch(cursor, call):
    d = dict(cursor._data)
    call.need(not d["state"]._closed, "closed parent state")
    call.need(not d["terminal"] and d["outstanding"] is None, "terminal or outstanding branch")
    candidate, after, action, event = None, None, "ENUMERATE", None
    if d["phase"] == "SHORT":
        for index, tried in enumerate(d["short_tried"]):
            call.tick()
            if not tried:
                candidate, after, action = d["shortcuts"][index], ("SHORT", index), "EMIT"
                break
        if candidate is None:
            d["phase"] = "RAW"
    else:
        kind, candidate, raw, action, event = _raw_step(d["raw"], d["state"], call)
        d["raw"] = raw
        if kind == "EOF":
            d["terminal"] = True
        elif candidate is not None:
            # These at-most-two IDs are the sole off-prefix exclusion set.
            if _same_key(candidate, d["shortcuts"], call):
                candidate = None
            else:
                after = ("RAW", raw)
    if event is not None:
        d["counts"] = dict(d["counts"])
        d["counts"][event] += 1
    offer = None
    serial = cursor._inv._serial
    if candidate is not None:
        serial += 1
        offer = _handle(_Offer, cursor._inv, {"branch": cursor, "state": d["state"],
            "candidate": candidate, "revision": d["revision"], "after": after}, serial)
        d["outstanding"] = offer
        d["counts"] = dict(d["counts"])
        d["counts"]["branch_offers"] += 1
    kind = "CANDIDATE" if candidate is not None else ("EOF" if d["terminal"] else "PENDING")
    answer = _step_record(cursor, d, kind, action, candidate, offer)
    counts = dict(d["counts"])
    counts["committed_actions"] += 1
    d["counts"] = counts
    call.tick()
    object.__setattr__(cursor._inv, "_serial", serial)
    object.__setattr__(cursor, "_data", d)
    return answer


def advance(cursor, *, check):
    inv, call = _begin(cursor, check, (_ClassCursor, _BranchCursor))
    try:
        return _advance_class(cursor, call) if type(cursor) is _ClassCursor else _advance_branch(cursor, call)
    except BaseException:
        call.fault()
        raise


def reject_offer(branch_cursor, offer, *, check):
    inv, call = _begin(branch_cursor, check, (_BranchCursor,))
    try:
        d = dict(branch_cursor._data)
        call.need(type(offer) is _Offer and offer._owner is _OWNER and offer._inv is inv and
                  not offer._closed and d["outstanding"] is offer and
                  offer._data["branch"] is branch_cursor and offer._data["state"] is d["state"] and
                  offer._data["revision"] == d["revision"], "exact outstanding parent offer")
        where, value = offer._data["after"]
        if where == "SHORT":
            flags = list(d["short_tried"])
            flags[value] = True
            d["short_tried"] = tuple(flags)
        else:
            d["tried"] = value
        counts = dict(d["counts"])
        counts["failed_children_recorded"] += 1
        if where == "RAW":
            counts["tried_prefix_advances"] += 1
        d.update(outstanding=None, revision=d["revision"] + 1, counts=counts)
        call.tick()
        object.__setattr__(branch_cursor, "_data", d)
        object.__setattr__(offer, "_closed", True)
    except BaseException:
        call.fault()
        raise


def _projection(state, row, call):
    """Complete conservative dependency projection for one INITIAL row domain.

    All candidate t is at row; all possible m is at formula ports0..row.
    Retaining earlier selected keys/t is conservative. Marks include restored
    refcounts even when contributed by a later selected row. No later own-cell,
    output-only mark or selected member is relevant if it changes none of these.
    """
    selected, totals, marks = [], [], []
    for index in range(row + 1):
        call.tick()
        member = state._data["selected"][index]
        selected.append(None if member is None else member._data["key"])
        totals.append(state._data["t"][index])
    for point, mark, refcount in state._data["m"]:
        call.tick()
        if point[1] == 1 and 0 <= point[0] <= row:
            marks.append((point, mark, refcount))
    return tuple(selected), tuple(totals), tuple(marks)


def rebind_classification(cursor, state, *, check):
    inv, call = _begin(cursor, check, (_ClassCursor,))
    try:
        call.need(type(state) is _State and state._owner is _OWNER and state._inv is inv and
                  not state._closed, "same inventory immutable state")
        d = cursor._data
        _current_remainder(d, call)
        call.need(d["remainder"] is None or d["state"] is state, "remainder exact parent only")
        call.need(_equal(_projection(d["state"], d["point"][0], call),
                         _projection(state, d["point"][0], call), call),
                  "complete intrinsic legality projection changed")
        return _commit_handle(_ClassCursor, inv, dict(d, state=state, counts=dict(d["counts"])), call)
    except BaseException:
        call.fault()
        raise


def dependency_spec(inventory, point, *, check):
    inv, call = _begin(inventory, check, (_Inventory,))
    row = _point(point, inv, call)
    answer = {"cell": point, "formula_port_prefix": [0, row + 1], "inventory_version": VERSION}
    call.tick()
    return answer


def _public_key(data, inv, call):
    # Lossless, ordinary full identity. Private ownership/token never escapes.
    return _ordinary(("FPC-point-ground-key-v1", _model(inv, call),
                      ("ROW", data["row"]), data["rule"], data["subtag"], data["witness"],
                      data["t"], data["m"]), call)


def _candidate_record(candidate, call):
    d = candidate._data
    answer = {"key": _public_key(d, candidate._inv, call), "rule_tag": d["rule"],
              "subtag": d["subtag"], "witness": d["witness"], "formula": d["formula"],
              "references": d["references"], "t": d["t"], "m": d["m"]}
    return _ordinary(answer, call)


def candidate_record(candidate, *, check):
    inv, call = _begin(candidate, check, (_Candidate,))
    answer = _candidate_record(candidate, call)
    call.tick()
    return answer


def _frontier(raw, call):
    if raw is None:
        return None
    member = raw["member"]
    public_member = None
    if member is not None:
        public_member = {"row": member["row"], "rule_tag": member["rule"],
            "subtag": member["subtag"], "witness": member["witness"],
            "formula": member["formula"], "references": member["references"],
            "t": member["t"], "m": member["m"]}
    return _ordinary({"schema": "FPC-point-raw-frontier-v1", "row": raw["row"],
        "family": raw["family"], "product": raw["product"], "phase": raw["phase"],
        "args": raw["args"], "member": public_member, "raw_index": raw["raw_index"],
        "eof": raw["eof"], "skipped_families": raw["skipped"],
        "restriction": None if raw["binding"] is None else {
            "stage": raw["binding"]["stage"], "mode": raw["binding"]["result"],
            "fixed": raw["binding"]["fixed"], "slot_index": raw["binding"]["slot_index"],
            "current_slot_nodes": raw["binding"]["nodes"], "reason": raw["binding"]["reason"]}}, call)


def snapshot(handle, *, check):
    inv, call = _begin(handle, check, (_State, _ClassCursor, _BranchCursor))
    try:
        d, model = handle._data, _model(inv, call)
        if type(handle) is _State:
            selected, totals = [], []
            for row, member in enumerate(d["selected"]):
                call.tick()
                selected.append(None if member is None else _public_key(member._data, inv, call))
                totals.append(((row, 0), d["t"][row]))
            answer = {"schema": "FPC-point-state-snapshot-v1", "model": model,
                "state_serial": handle._serial,
                "parent_serial": None if d["parent"] is None else d["parent"]._serial,
                "selected_keys": selected, "t_items": totals, "m_items_with_refcounts": d["m"]}
        else:
            initial, flags = [], []
            if type(handle) is _ClassCursor:
                _current_remainder(d, call)
                inspection = {"short": d["short"], "raw": _frontier(d["raw"], call),
                              "kind": d["kind"], "coverage_complete": d["complete"]}
                scan, tried, outstanding, revision = None, None, None, d["revision"]
            else:
                inspection = None
                scan, tried = _frontier(d["raw"], call), _frontier(d["tried"], call)
                outstanding = None if d["outstanding"] is None else d["outstanding"]._serial
                revision = d["revision"]
                for member, flag in zip(d["shortcuts"], d["short_tried"]):
                    call.tick()
                    initial.append(_public_key(member._data, inv, call))
                    flags.append(flag)
            answer = {"schema": "FPC-point-cursor-snapshot-v1", "model": model,
                "cursor_serial": handle._serial,
                "kind": "CLASSIFICATION" if type(handle) is _ClassCursor else "BRANCH",
                "parent_state_serial": d["state"]._serial, "point": d["point"], "phase": d["phase"],
                "inspection_frontier": inspection, "canonical_scan_frontier": scan,
                "canonical_tried_frontier": tried, "initial_shortcut_keys": initial,
                "initial_shortcut_tried": flags, "outstanding_offer_serial": outstanding,
                "remainder_revision": revision, "terminal": d["terminal"], "counts": d["counts"]}
        answer = _ordinary(answer, call)
        call.tick()
        return answer
    except BaseException:
        call.fault()
        raise


def _uleb(number, output, call):
    call.need(_nat(number), "natural wire value")
    while True:
        call.tick()
        byte, number = number & 127, number >> 7
        output.append(byte | (128 if number else 0))
        if not number:
            return


def _ast_wire(tree, output, call):
    pending = [tree]
    while pending:
        call.tick()
        node = pending.pop()
        tag = node[0]
        if tag == "var":
            _uleb(0, output, call)
            _uleb(node[1], output, call)
            children = ()
        elif tag in ("fun", "pred"):
            _uleb(1 if tag == "fun" else 0, output, call)
            _uleb(node[1], output, call)
            _uleb(len(node[2]), output, call)
            children = node[2]
        elif tag == "all":
            _uleb(4, output, call)
            _uleb(node[1], output, call)
            children = (node[2],)
        else:
            _uleb({"eq": 1, "not": 2, "imp": 3}[tag], output, call)
            children = node[1:]
        for child in reversed(children):
            call.tick()
            pending.append(child)


def _row_wire(data, output, call):
    _ast_wire(data["formula"], output, call)
    rule, subtag, witness = data["rule"], data["subtag"], data["witness"]
    _uleb(rule, output, call)
    if rule == 0:
        _uleb(witness, output, call)
    elif rule == 1:
        _uleb(subtag, output, call)
        for kind, value in zip(_SORTS[subtag], witness):
            call.tick()
            if kind == "V":
                _uleb(value, output, call)
            else:
                _ast_wire(value, output, call)
    elif rule == 2:
        _uleb(subtag, output, call)
        if subtag == 2:
            _ast_wire(witness[0], output, call)
            _uleb(witness[1], output, call)
            _uleb(len(witness[2]), output, call)
            for x in witness[2]:
                call.tick()
                _uleb(x, output, call)
        else:
            _uleb(witness, output, call)
    else:
        for value in witness:
            call.tick()
            _uleb(value, output, call)


def export_candidate(state, *, check):
    inv, call = _begin(state, check, (_State,))
    try:
        output, rows = bytearray(b"FPP1"), []
        _uleb(inv._body["n"], output, call)
        for index, candidate in enumerate(state._data["selected"]):
            call.tick()
            call.need(candidate is not None and state._data["t"][index] == (1, 1), "incomplete frame")
            data = candidate._data
            call.need(data["row"] == index and _member(inv, data, call), "exact primitive member")
            _row_wire(data, output, call)
            rows.append({"row": index, "rule_tag": data["rule"], "subtag": data["subtag"],
                         "witness": data["witness"], "formula": data["formula"],
                         "references": data["references"]})
        call.need(_equal(state._data["selected"][-1]._data["formula"], inv._body["goal"], call), "exact final goal")
        receipt = _ordinary({"schema": "FPC-point-candidate-export-v1", "accepted": False,
            "inventory_version": VERSION, "model": _model(inv, call), "state_serial": state._serial,
            "exact_rows": inv._body["n"], "rows": rows,
            "scope": "Canonical primitive candidate only; same-byte original dual validators and whole admission required."}, call)
        answer = {"candidate_certificate_bytes": bytes(output), "receipt": receipt}
        call.tick()
        return answer
    except BaseException:
        call.fault()
        raise


def close(handle):
    """Callback-free local release. No registry walk or fault replacement."""
    inv = _inventory(handle)
    if type(handle) is _Inventory:
        object.__setattr__(inv, "_closed", True)
        object.__setattr__(inv, "_body", {})
    else:
        object.__setattr__(handle, "_closed", True)
        if type(handle) in (_ClassCursor, _BranchCursor, _Offer):
            object.__setattr__(handle, "_data", {})
