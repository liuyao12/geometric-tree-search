"""Independent finite-row CSP driver. Unrun Source at authorship.

Logical/state authority is the supplied pinned provider. This module owns one
column store and a reversible first-write journal, not a point graph/session
wrapper. It never imports or delegates to the point controller. All returned
certificates still require the two external original validators and whole gates.
"""
VERSION = "FPC-ROW-CSP-CONTROLLER-v1"
PROVIDER_VERSION = "FPC-POINT-FULL-FRAME-PROVIDER-v1"
REQUIRED_FEATURE = "dependency-rebind-classification"
FRAME_SCHEMA = "FPC-row-CSP-frame-search-v1"
DOVETAIL_SCHEMA = "FPC-row-CSP-dovetail-search-v1"
DIAGNOSTIC_SCHEMA = "matched-row-controller-diagnostics-v1"
PHASES = ("INVENTORY", "ROOT", "DEPENDENCY", "LOAD", "REUSE", "SCAN",
          "CLASSIFY_OPEN", "CLASSIFY_ADVANCE", "FORCE_PLACE", "BRANCH_OPEN",
          "OFFER", "OFFER_PLACE", "BACKTRACK", "EXPORT")
STEP_ACTIONS = ("NORMALIZE", "ENUMERATE", "INTRINSIC", "ENVELOPE",
                "POINT_CHECK", "EMIT", "EOF")
_FRAME_METRICS = ("atomic_steps", "callbacks", "state_creations", "classifier_opens",
                  "classifier_advances", "domain_completions", "global_scans",
                  "forced_moves", "branch_nodes", "offers", "backtracks",
                  "reject_offers", "max_path_depth", "max_frontier",
                  "classifiers_rebound", "domains_invalidated")
_DIAG_COUNTERS = ("atomic_steps_committed", "provider_calls_committed",
                  "provider_advances_committed", "domain_completions", "global_scans",
                  "forced_moves", "branch_nodes", "offers", "backtracks",
                  "reject_offers", "reuses", "invalidations")
DIAGNOSTIC_FIELDS = ('schema', 'arm', 'complete', 'snapshot_available', 'publish_seq', 'phase_in_progress', 'active_frame_round', 'active_frame_pair_index', 'active_frame_ordinal', 'active_frame_rows', 'active_frame_syntax_nodes', 'active_frame_limit', 'active_phase', 'active_atomic_steps_committed', 'active_provider_calls_committed', 'active_provider_advances_committed', 'active_domain_completions', 'active_global_scans', 'active_forced_moves', 'active_branch_nodes', 'active_offers', 'active_backtracks', 'active_reject_offers', 'active_reuses', 'active_invalidations', 'active_outstanding_offers', 'active_live_cursors', 'active_highwater_live_cursors', 'active_trail_entries', 'active_highwater_trail_entries', 'frames_completed', 'frames_exhausted', 'frames_fuel_limited', 'completed_atomic_steps_committed', 'completed_provider_calls_committed', 'completed_provider_advances_committed', 'completed_domain_completions', 'completed_global_scans', 'completed_forced_moves', 'completed_branch_nodes', 'completed_offers', 'completed_backtracks', 'completed_reject_offers', 'completed_reuses', 'completed_invalidations', 'completed_highwater_live_cursors', 'completed_highwater_trail_entries', 'raw_member_work_supported', 'raw_member_work')
_OWNER = object()


class RowCSPInputError(ValueError):
    """Public construction alone is unowned."""


class RowCSPProtocolError(RuntimeError):
    """A service disagreement is never an empty domain."""


def is_owned_error(error):
    return type(error) is RowCSPInputError and getattr(error, "_owner", None) is _OWNER


def _invalidate_diagnostics(sink):
    """Invalidate a reusable well-shaped sink before the first possible callback."""
    if (type(sink) is dict and len(sink) == 49 and
            all(type(key) is str for key in sink) and
            type(sink.get("snapshot_available")) is bool):
        sink["snapshot_available"] = False


def _nat(value):
    return type(value) is int and value >= 0


class _Call:
    def __init__(self, check):
        if not callable(check):
            raise TypeError("genuine bounded check required")
        self.check, self.first, self.callbacks = check, None, 0
        self.token = object()

    def tick(self):
        if self.first is not None:
            raise self.first
        self.callbacks += 1
        try:
            self.check()
        except BaseException as error:
            self.first = error
            raise

    def fault(self):
        if self.first is not None:
            raise self.first

    def need(self, condition, message):
        self.fault()
        if condition is not True:
            error = RowCSPInputError(message)
            error._owner, error._call = _OWNER, self.token
            raise error

    def protocol(self, condition, message):
        self.fault()
        if condition is not True:
            raise RowCSPProtocolError(message)


def _same(left, right, call):
    pending = [(left, right)]
    while pending:
        call.tick()
        a, b = pending.pop()
        if a is b:
            continue
        if type(a) is not type(b):
            return False
        if type(a) is tuple:
            if len(a) != len(b):
                return False
            for index in range(len(a)):
                call.tick()
                pending.append((a[index], b[index]))
        elif type(a) in (str, int, bool, bytes, type(None)):
            if a != b:
                return False
        else:
            return False  # No equality on opaque handles/tokens.
    return True


def _context(raw, provider, modules, call):
    call.tick()
    call.need(type(raw) is bytes, "exact immutable query bytes")
    call.need(type(modules) is dict and set(modules) == {"checker", "builders"},
              "exact checker/builders mapping")
    call.need(getattr(provider, "VERSION", None) == PROVIDER_VERSION and
              REQUIRED_FEATURE in getattr(provider, "FEATURES", ()),
              "dependency-aware authenticated provider service")
    return {"checker": modules["checker"], "builders": modules["builders"]}


def _frame(frame, call):
    call.tick()
    call.need(type(frame) is dict and set(frame) == {"schema", "rows", "syntax_nodes"},
              "strict frame fields")
    call.need(type(frame["schema"]) is str and frame["schema"] == "FPC-point-frame-v1" and
              _nat(frame["rows"]) and frame["rows"] > 0 and
              _nat(frame["syntax_nodes"]) and frame["syntax_nodes"] > 0,
              "positive exact frame bounds")
    return {"schema": frame["schema"], "rows": frame["rows"], "syntax_nodes": frame["syntax_nodes"]}


class _Observation:
    """Fixed primitive sink, published only at reviewed normal boundaries."""
    def __init__(self, sink, call):
        self.sink, self.call, self.serial = sink, call, 0
        self.finished = dict.fromkeys(_DIAG_COUNTERS, 0)
        self.frames = self.exhausted = self.fuel = 0
        self.peak_cursors = self.peak_trail = 0
        self.round = self.pair = self.ordinal = self.frame = self.limit = None
        if sink is not None:
            call.tick()
            call.need(type(sink) is dict and len(sink) == len(DIAGNOSTIC_FIELDS) and
                      all(type(key) is str for key in sink) and
                      set(sink) == set(DIAGNOSTIC_FIELDS), "strict diagnostic sink")
            call.need(type(sink["schema"]) is str and sink["schema"] == DIAGNOSTIC_SCHEMA and
                      type(sink["arm"]) is str and sink["arm"] == "C0", "C0 diagnostic identity")
            for key in DIAGNOSTIC_FIELDS:
                call.tick()
                value = sink[key]
                if key in ("schema", "arm"):
                    continue
                if key in ("complete", "snapshot_available", "phase_in_progress", "raw_member_work_supported"):
                    call.need(type(value) is bool, "strict diagnostic flags")
                elif key == "active_phase":
                    call.need(value is None or (type(value) is str and value in PHASES), "diagnostic phase marker")
                else:
                    call.need(value is None or _nat(value), "diagnostic primitive marker")
        # Initial values are discarded, never interpreted as history or work.

    def begin(self, frame, limit, ordinal, round_number=None, pair=None):
        self.frame, self.limit, self.ordinal = frame, limit, ordinal
        self.round, self.pair = round_number, pair

    def publish(self, session=None, *, phase=None, in_progress=False, complete=False):
        if self.sink is None:
            return
        c = self.call
        c.fault()
        record = {key: None for key in DIAGNOSTIC_FIELDS}
        record.update(schema=DIAGNOSTIC_SCHEMA, arm="C0", complete=complete,
            snapshot_available=False, publish_seq=self.serial + 1,
            phase_in_progress=in_progress, raw_member_work_supported=False,
            raw_member_work=None, frames_completed=self.frames, frames_exhausted=self.exhausted,
            frames_fuel_limited=self.fuel, completed_highwater_live_cursors=self.peak_cursors,
            completed_highwater_trail_entries=self.peak_trail,
            active_frame_round=self.round, active_frame_pair_index=self.pair,
            active_frame_ordinal=self.ordinal, active_frame_limit=self.limit,
            active_frame_rows=None if self.frame is None else self.frame["rows"],
            active_frame_syntax_nodes=None if self.frame is None else self.frame["syntax_nodes"],
            active_phase=None if session is None else (session.phase if phase is None else phase))
        active = dict.fromkeys(_DIAG_COUNTERS, 0) if session is None else session.diag_counts()
        for key in _DIAG_COUNTERS:
            c.tick()
            record["active_" + key] = active[key]
            record["completed_" + key] = self.finished[key]
        record.update(active_outstanding_offers=0 if session is None else len(session.choices),
            active_live_cursors=0 if session is None else len(session.live),
            active_highwater_live_cursors=0 if session is None else session.peak_live,
            active_trail_entries=0 if session is None else session.trail_size(),
            active_highwater_trail_entries=0 if session is None else session.peak_trail)
        for key in DIAGNOSTIC_FIELDS:
            c.tick()
            value = record[key]
            c.protocol(value is None or type(value) in (str, bool, int), "scalar observation only")
        c.tick()
        # Bounded publication has no callbacks/getters/scientific operations.
        # Failure partway leaves snapshot_available false; earlier E wins.
        self.sink["snapshot_available"] = False
        for key in DIAGNOSTIC_FIELDS:
            if key != "snapshot_available":
                self.sink[key] = record[key]
        self.sink["snapshot_available"] = True
        self.serial += 1

    def fold(self, session):
        for key, value in session.diag_counts().items():
            self.call.tick()
            self.finished[key] += value
        self.frames += 1
        self.exhausted += int(session.status == "EXHAUSTED_FRAME")
        self.fuel += int(session.status == "UNKNOWN_FUEL")
        self.peak_cursors = max(self.peak_cursors, session.peak_live)
        self.peak_trail = max(self.peak_trail, session.peak_trail)
        self.round = self.pair = self.ordinal = self.frame = self.limit = None
        self.publish()


class _Columns:
    """A single mutable domain table with a first-write row undo journal."""
    def __init__(self, rows, call):
        self.cursor, self.kind, self.covered = [], [], []
        self.w0, self.w1, self.source, self.revision, self.stamp = [], [], [], [], []
        for _ in range(rows):
            call.tick()
            self.cursor.append(None)
            self.kind.append(None)
            self.covered.append(False)
            self.w0.append(None)
            self.w1.append(None)
            self.source.append(None)
            self.revision.append(None)
            self.stamp.append(0)
        self.undo = []

    def value(self, row):
        return (self.cursor[row], self.kind[row], self.covered[row], self.w0[row],
                self.w1[row], self.source[row], self.revision[row])

    def assign(self, row, value):
        (self.cursor[row], self.kind[row], self.covered[row], self.w0[row],
         self.w1[row], self.source[row], self.revision[row]) = value

    def write(self, row, value, level, retired, call):
        call.tick()
        before = self.value(row)
        saved = level > 0 and self.stamp[row] != level
        if saved:
            self.undo.append((row, before, self.stamp[row]))
            self.stamp[row] = level
        elif before[0] is not None and before[0] is not value[0]:
            retired.append(before[0])
        self.assign(row, value)

    def clear(self):
        for column in (self.cursor, self.kind, self.covered, self.w0, self.w1,
                       self.source, self.revision, self.stamp, self.undo):
            column.clear()


_EMPTY = (None, None, False, None, None, None, None)


class _Rows:
    def __init__(self, query, provider, frame, modules, trace_limit, call, observation):
        self.query, self.p, self.frame, self.modules = query, provider, frame, modules
        self.c, self.obs, self.rows, self.trace_limit = call, observation, frame["rows"], trace_limit
        self.metrics = dict.fromkeys(_FRAME_METRICS, 0)
        self.calls = self.advances = 0
        self.live, self.peak_live, self.peak_trail = {}, 0, 0
        self.table = None
        self.choices, self.retired = [], []
        self.state = self.section = self.old_section = self.inv = None
        self.pending_state = self.pending_section = None
        self.context = None
        self.scope_rows, self.index = [], 0
        self.row, self.forced, self.phase, self.status = None, False, "INVENTORY", None
        self.trace, self.truncated = [], False
        self.certificate = self.export = None

    def api(self, name, *args, **kwargs):
        self.c.tick()
        result = getattr(self.p, name)(*args, check=self.c.tick, **kwargs)
        if name in ("open_classification", "rebind_classification", "open_branch"):
            try:
                self.live[id(result)] = result
            except BaseException:
                try:
                    self.p.close(result)
                except BaseException:
                    pass
                self.c.fault()
                raise
            self.peak_live = max(self.peak_live, len(self.live))
        self.calls += 1
        self.advances += int(name == "advance")
        return result

    def close_cursor(self, handle):
        key = id(handle)
        if key in self.live:
            self.p.close(handle)
            del self.live[key]

    def flush_retired(self):
        while self.retired:
            self.c.tick()
            self.close_cursor(self.retired.pop())

    def cleanup(self):
        first = None
        while self.live:
            key = next(iter(self.live))
            handle = self.live.pop(key)
            try:
                self.p.close(handle)
            except BaseException as error:
                if first is None:
                    first = error
        if self.inv is not None:
            try:
                self.p.close(self.inv)
            except BaseException as error:
                if first is None:
                    first = error
        if self.table is not None:
            self.table.clear()
        self.choices.clear()
        self.retired.clear()
        self.state = self.section = self.old_section = None
        self.pending_state = self.pending_section = self.context = None
        if self.c.first is not None:
            raise self.c.first
        if first is not None:
            raise first

    def trail_size(self):
        return (0 if self.table is None else len(self.table.undo)) + len(self.choices)

    def highwater(self):
        self.peak_trail = max(self.peak_trail, self.trail_size())

    def diag_counts(self):
        m = self.metrics
        return dict(atomic_steps_committed=m["atomic_steps"], provider_calls_committed=self.calls,
            provider_advances_committed=self.advances, domain_completions=m["domain_completions"],
            global_scans=m["global_scans"], forced_moves=m["forced_moves"],
            branch_nodes=m["branch_nodes"], offers=m["offers"], backtracks=m["backtracks"],
            reject_offers=m["reject_offers"], reuses=m["classifiers_rebound"],
            invalidations=m["domains_invalidated"])

    def want_trace(self):
        self.c.tick()
        if self.trace_limit == 0:
            return False
        if len(self.trace) >= self.trace_limit:
            self.truncated = True
            return False
        return True

    def emit(self, kind, **fields):
        self.c.tick()
        self.trace.append(dict(kind=kind, **fields))

    def checked_section(self, state):
        section = self.api("state_section", state)
        c = self.c
        c.protocol(type(section) is tuple and len(section) == 7 and
                   section[0] == "FPC-point-state-section-v1" and section[1] is self.inv and
                   _nat(section[2]), "exact current provider state section")
        c.protocol(type(section[4]) is tuple and type(section[5]) is tuple and
                   type(section[6]) is tuple and len(section[4]) == self.rows and
                   len(section[5]) == self.rows, "complete row assignment/occupancy")
        for row in range(self.rows):
            c.tick()
            expected = (0, 1) if section[4][row] is None else (1, 1)
            c.protocol(_same(section[5][row], ((row, 0), expected), c), "row occupancy disagrees")
        previous = -1
        for item in section[6]:
            c.tick()
            c.protocol(type(item) is tuple and len(item) == 3, "formula constraint entry")
            point, mark, count = item
            c.protocol(type(point) is tuple and len(point) == 2 and type(point[0]) is int and
                       point[1] == 1 and 0 <= point[0] < self.rows and point[0] > previous and
                       type(mark) is tuple and len(mark) == 2 and mark[0] == "FPC" and
                       _nat(count) and count > 0, "ordered full formula constraints/refcounts")
            previous = point[0]
        return section

    def projection(self, section, row):
        selected, totals, marks = [], [], []
        for index in range(row + 1):
            self.c.tick()
            selected.append(section[4][index])
            totals.append(section[5][index][1])
        for item in section[6]:
            self.c.tick()
            if item[0][0] <= row:
                marks.append(item)
        return tuple(selected), tuple(totals), tuple(marks)

    def read(self, cursor, row, source):
        data = self.api("classification", cursor)
        c = self.c
        c.protocol(type(data) is dict and data.get("schema") == "FPC-point-classification-v1" and
                   data.get("state_serial") == self.section[2] and
                   _same(data.get("point"), (row, 0), c), "domain belongs to current variable")
        kind, covered, witnesses = data.get("kind"), data.get("coverage_complete"), data.get("witnesses")
        c.protocol(type(kind) is str and type(covered) is bool and type(witnesses) is tuple, "typed classifier result")
        valid = ((kind == "EMPTY" and covered and len(witnesses) == 0) or
                 (kind == "SINGLE" and covered and len(witnesses) == 1) or
                 (kind == "MANY" and not covered and len(witnesses) == 2) or
                 (kind == "UNRESOLVED" and not covered and len(witnesses) <= 1))
        c.protocol(valid, "open prefix cannot be a complete domain")
        revision = data.get("remainder_revision")
        c.protocol((source == "INITIAL" and revision is None) or
                   (source == "REMAINDER" and _nat(revision)), "exact parent remainder label")
        return (cursor, kind, covered, witnesses[0] if witnesses else None,
                witnesses[1] if len(witnesses) == 2 else None, source, revision)

    def write(self, row, value):
        self.table.write(row, value, len(self.choices), self.retired, self.c)
        self.highwater()

    def log_domain(self, row):
        if self.want_trace():
            t = self.table
            witnesses = []
            for handle in (t.w0[row], t.w1[row]):
                self.c.tick()
                if handle is not None:
                    witnesses.append(self.api("candidate_record", handle))
            self.emit("DOMAIN", state_serial=self.section[2], row=row,
                domain_kind=t.kind[row], coverage_complete=t.covered[row], witnesses=witnesses,
                source=t.source[row], remainder_revision=t.revision[row])

    def log_decision(self, status, row, frontier):
        if self.want_trace():
            values = []
            for index in frontier:
                self.c.tick()
                values.append(dict(row=index, kind="UNRESOLVED" if self.table.cursor[index] is None
                                   else self.table.kind[index], coverage_complete=self.table.covered[index]))
            self.emit("DECISION", state_serial=self.section[2], status=status, row=row, all_unfilled=values)

    def choose(self, candidate, forced, branch_serial=None, offer_serial=None, from_offer=False):
        parent_state, parent_section = self.state, self.section
        child = self.api("place_state", parent_state, candidate)
        self.pending_state, self.pending_section = child, self.checked_section(child)
        self.c.protocol(self.pending_section[3] is parent_state, "exact child parent handle")
        self.metrics["state_creations"] += 1
        self.metrics["forced_moves"] += int(forced)
        if self.want_trace():
            self.emit("SELECT", parent_serial=parent_section[2], child_serial=self.pending_section[2],
                row=self.row, forced=forced, from_offer=from_offer,
                candidate=self.api("candidate_record", candidate),
                branch_serial=branch_serial, offer_serial=offer_serial)
        self.context, self.phase = None, "LOAD"

    def check_step(self, step, branch):
        self.c.protocol(type(step) is dict and step.get("schema") == "FPC-point-provider-step-v1" and
            step.get("committed") is True and step.get("state_serial") == self.section[2] and
            step.get("kind") in ("PENDING", "CANDIDATE", "EOF") and
            type(step.get("action")) is str and step.get("action") in STEP_ACTIONS, "declared provider Step categories")
        if branch:
            self.c.protocol((step.get("kind") == "CANDIDATE" and step.get("candidate") is not None
                             and step.get("offer") is not None) or
                            (step.get("kind") == "PENDING" and step.get("candidate") is None
                             and step.get("offer") is None), "nonempty parent choice stream")
        else:
            self.c.protocol(step.get("offer") is None, "classification is not a branch offer")

    def step(self):
        c, t, phase = self.c, self.table, self.phase
        c.tick()
        self.obs.publish(self, in_progress=True)
        if phase == "INVENTORY":
            self.inv = self.api("create_inventory", self.query, frame=self.frame, modules=self.modules)
            self.phase = "ROOT"
        elif phase == "ROOT":
            self.pending_state = self.api("root_state", self.inv)
            self.metrics["state_creations"] += 1
            self.phase, self.index = "DEPENDENCY", 0
        elif phase == "DEPENDENCY":
            scope = self.api("dependency_spec", self.inv, (self.index, 0))
            c.protocol(type(scope) is dict and _same(scope.get("cell"), (self.index, 0), c) and
                scope.get("formula_port_prefix") == [0, self.index + 1] and
                scope.get("inventory_version") == PROVIDER_VERSION, "complete row constraint scope")
            self.scope_rows.append((self.index, self.index + 1))
            self.index += 1
            if self.index == self.rows:
                self.phase = "LOAD"
        elif phase == "LOAD":
            section = self.pending_section
            if section is None:
                section = self.checked_section(self.pending_state)
            if self.table is None:
                self.table = _Columns(self.rows, c)
            self.old_section, self.state, self.section = self.section, self.pending_state, section
            self.pending_state = self.pending_section = None
            self.index, self.phase = 0, "REUSE"
            if self.want_trace():
                self.emit("STATE", depth=len(self.choices), state_serial=section[2],
                    parent_serial=None if section[3] is None else self.old_section[2],
                    snapshot=self.api("snapshot", self.state))
        elif phase == "REUSE":
            row, old = self.index, self.old_section
            if self.section[4][row] is not None:
                if t.cursor[row] is not None:
                    self.write(row, _EMPTY)
            elif old is not None and t.cursor[row] is not None:
                c.protocol(t.source[row] == "INITIAL", "only initial domains transport")
                equal = _same(self.projection(old, row), self.projection(self.section, row), c)
                if equal:
                    cursor = self.api("rebind_classification", t.cursor[row], self.state)
                    self.write(row, self.read(cursor, row, "INITIAL"))
                    self.metrics["classifiers_rebound"] += 1
                else:
                    self.write(row, _EMPTY)
                    self.metrics["domains_invalidated"] += 1
                if self.want_trace():
                    self.emit("REUSE" if equal else "INVALIDATE", row=row,
                              from_state_serial=old[2], state_serial=self.section[2])
            self.index += 1
            if self.index == self.rows:
                self.flush_retired()
                self.old_section, self.phase = None, "SCAN"
        elif phase == "SCAN":
            self.metrics["global_scans"] += 1
            frontier, dead, unresolved, units = [], None, None, None
            for row in range(self.rows):
                c.tick()
                if self.section[4][row] is not None:
                    continue
                frontier.append(row)
                kind = "UNRESOLVED" if t.cursor[row] is None else t.kind[row]
                if kind == "EMPTY" and dead is None:
                    dead = row
                elif kind == "UNRESOLVED" and unresolved is None:
                    unresolved = row
                elif kind == "SINGLE" and units is None:
                    units = row
            self.metrics["max_frontier"] = max(self.metrics["max_frontier"], len(frontier))
            if dead is not None:
                self.log_decision("DEAD", dead, frontier)
                self.phase = "BACKTRACK"
            elif unresolved is not None:
                self.row = unresolved
                self.phase = "CLASSIFY_OPEN" if t.cursor[unresolved] is None else "CLASSIFY_ADVANCE"
            elif not frontier:
                self.log_decision("EXACT", None, frontier)
                self.phase = "EXPORT"
            else:
                self.row, self.forced = (units, True) if units is not None else (frontier[0], False)
                self.log_decision("FORCED" if self.forced else "BRANCH", self.row, frontier)
                if self.context is not None:
                    c.protocol(self.context[0] == self.row, "restored choice row")
                    self.phase = "OFFER"
                else:
                    self.phase = "FORCE_PLACE" if self.forced else "BRANCH_OPEN"
        elif phase == "CLASSIFY_OPEN":
            branch = self.context[1] if self.context is not None and self.context[0] == self.row else None
            cursor = self.api("open_classification", self.state, (self.row, 0), remainder=branch)
            source = "INITIAL" if branch is None else "REMAINDER"
            self.write(self.row, self.read(cursor, self.row, source))
            self.metrics["classifier_opens"] += 1
            c.protocol(t.kind[self.row] == "UNRESOLVED", "new domain begins unresolved")
            self.phase = "CLASSIFY_ADVANCE"
        elif phase == "CLASSIFY_ADVANCE":
            cursor = t.cursor[self.row]
            step = self.api("advance", cursor)
            self.check_step(step, False)
            self.write(self.row, self.read(cursor, self.row, t.source[self.row]))
            self.metrics["classifier_advances"] += 1
            if t.kind[self.row] != "UNRESOLVED":
                self.metrics["domain_completions"] += 1
                self.log_domain(self.row)
                self.phase = "SCAN"
        elif phase == "FORCE_PLACE":
            self.choose(t.w0[self.row], True)
        elif phase == "BRANCH_OPEN":
            branch = self.api("open_branch", self.state, (self.row, 0), classified=t.cursor[self.row])
            self.context = (self.row, branch)
            self.metrics["branch_nodes"] += 1
            self.phase = "OFFER"
        elif phase == "OFFER":
            branch = self.context[1]
            step = self.api("advance", branch)
            self.check_step(step, True)
            if step["kind"] == "CANDIDATE":
                snap = self.api("snapshot", branch)
                bs, os = snap["cursor_serial"], snap["outstanding_offer_serial"]
                c.protocol(_nat(bs) and _nat(os), "owned offer association")
                entry = (self.state, self.section, self.row, branch, step["offer"],
                         step["candidate"], self.forced, len(t.undo), bs, os)
                self.choices.append(entry)
                self.highwater()
                self.metrics["offers"] += 1
                self.metrics["max_path_depth"] = max(self.metrics["max_path_depth"], len(self.choices))
                self.phase = "OFFER_PLACE"
                if self.want_trace():
                    self.emit("OFFER", state_serial=self.section[2], row=self.row,
                              branch_serial=bs, offer_serial=os,
                              candidate=self.api("candidate_record", step["candidate"]))
        elif phase == "OFFER_PLACE":
            state, section, row, branch, offer, candidate, forced, offset, bs, os = self.choices[-1]
            c.protocol(self.state is state and self.section is section and self.row == row,
                       "current exact outstanding parent")
            self.choose(candidate, forced, bs, os, True)
        elif phase == "BACKTRACK":
            if not self.choices:
                self.status = "EXHAUSTED_FRAME"
            else:
                parent, section, row, branch, offer, candidate, forced, offset, bs, os = self.choices[-1]
                c.protocol(_same(self.checked_section(parent), section, c), "exact retained CSP parent")
                dead_serial = self.section[2]
                reason = "CHILD_EXHAUSTED" if self.context is not None else "CHILD_DEAD"
                self.api("reject_offer", branch, offer)
                dead_context = self.context
                while len(t.undo) > offset:
                    c.tick()
                    changed_row, before, stamp = t.undo.pop()
                    current = t.cursor[changed_row]
                    if current is not None and current is not before[0]:
                        self.close_cursor(current)
                    t.assign(changed_row, before)
                    t.stamp[changed_row] = stamp
                if dead_context is not None and dead_context[1] is not branch:
                    self.close_cursor(dead_context[1])
                self.state, self.section, self.context = parent, section, (row, branch)
                self.choices.pop()
                self.write(row, _EMPTY)
                self.flush_retired()
                self.metrics["backtracks"] += 1
                self.metrics["reject_offers"] += 1
                if self.want_trace():
                    self.emit("REJECT", restored_parent_serial=section[2], failed_child_serial=dead_serial,
                        row=row, branch_serial=bs, offer_serial=os, reason=reason)
                self.phase = "SCAN"
        elif phase == "EXPORT":
            exported = self.api("export_candidate", self.state)
            c.protocol(type(exported) is dict and set(exported) == {"candidate_certificate_bytes", "receipt"} and
                type(exported["candidate_certificate_bytes"]) is bytes and
                type(exported["receipt"]) is dict and exported["receipt"].get("accepted") is False,
                "unaccepted canonical primitive export")
            self.certificate, self.export, self.status = exported["candidate_certificate_bytes"], exported["receipt"], "CANDIDATE"
        else:
            raise RowCSPProtocolError("unknown phase")
        c.tick()
        self.metrics["atomic_steps"] += 1
        self.obs.publish(self, phase=phase)


def _run(query, provider, frame, modules, max_steps, trace_limit, call, obs):
    session = None
    began = call.callbacks
    try:
        session = _Rows(query, provider, frame, modules, trace_limit, call, obs)
        obs.publish(session)
        while session.status is None:
            call.tick()
            if max_steps is not None and session.metrics["atomic_steps"] >= max_steps:
                session.status = "UNKNOWN_FUEL"
                break
            session.step()
        if session.want_trace():
            session.emit("TERMINAL", status=session.status, phase=session.phase,
                atomic_steps=session.metrics["atomic_steps"], outstanding_offers=len(session.choices))
        call.tick()
        result = dict(schema=FRAME_SCHEMA, status=session.status, frame=dict(frame), accepted=False,
            candidate_certificate_bytes=session.certificate, export_receipt=session.export,
            metrics=dict(session.metrics), trace=session.trace,
            trace_complete=trace_limit > 0 and not session.truncated)
        obs.fold(session)
        session.cleanup()
        result["metrics"]["callbacks"] = call.callbacks - began
        return result
    except BaseException:
        if session is not None:
            try:
                session.cleanup()
            except BaseException:
                pass
        call.fault()
        raise


def search_frame(query_bytes, *, provider, frame, modules, max_steps, trace_limit=0,
                 diagnostics=None, check):
    _invalidate_diagnostics(diagnostics)
    call = _Call(check)
    context = _context(query_bytes, provider, modules, call)
    copied = _frame(frame, call)
    call.need(max_steps is None or _nat(max_steps), "strict nonnegative phase fuel or None")
    call.need(_nat(trace_limit), "strict nonnegative trace limit")
    obs = _Observation(diagnostics, call)
    obs.begin(copied, max_steps, 1)
    answer = _run(query_bytes, provider, copied, context, max_steps, trace_limit, call, obs)
    obs.publish(complete=True)
    answer["metrics"]["callbacks"] = call.callbacks
    return answer


def _lower_bound(query, call):
    call.protocol(type(query) is dict and "goal" in query, "decoded original goal")
    pending, count, maximum = [query["goal"]], 0, -1
    while pending:
        call.tick()
        node = pending.pop()
        call.protocol(type(node) in (list, tuple) and bool(node), "decoded AST")
        count += 1
        tag = node[0]
        if tag == "var":
            call.protocol(len(node) == 2 and _nat(node[1]), "decoded variable")
            maximum = max(maximum, node[1])
        elif tag in ("fun", "pred"):
            call.protocol(len(node) == 3 and type(node[2]) in (list, tuple), "decoded application")
            for child in node[2]:
                call.tick()
                pending.append(child)
        elif tag == "all":
            call.protocol(len(node) == 3 and _nat(node[1]), "decoded binder")
            maximum = max(maximum, node[1])
            pending.append(node[2])
        elif tag == "not":
            call.protocol(len(node) == 2, "decoded negation")
            pending.append(node[1])
        elif tag in ("eq", "imp"):
            call.protocol(len(node) == 3, "decoded binary formula")
            pending.extend((node[1], node[2]))
        else:
            raise RowCSPProtocolError("unknown decoded constructor")
    return max(1, count, maximum + 1)


def search_dovetail(query_bytes, *, provider, modules, max_rounds, diagnostics=None, check):
    _invalidate_diagnostics(diagnostics)
    call = _Call(check)
    context = _context(query_bytes, provider, modules, call)
    call.need(max_rounds is None or _nat(max_rounds), "strict nonnegative round limit or None")
    obs = _Observation(diagnostics, call)
    call.tick()
    lower = _lower_bound(context["checker"].decode_query(query_bytes, check=call.tick), call)
    totals = dict.fromkeys(("rounds_completed", "frame_runs", "frame_atomic_steps", "sum_frame_limits",
        "frames_exhausted", "frames_fuel_limited", "callbacks", "max_path_depth", "max_frontier"), 0)
    last, raw, exported, status = None, None, None, "UNKNOWN_ROUND_LIMIT"
    round_number, ordinal = 1, 0
    while max_rounds is None or round_number <= max_rounds:
        call.tick()
        diagonal, n, pair = 1, 1, 1
        while pair <= round_number:
            call.tick()
            limit = 1 << (round_number - pair)
            frame = dict(schema="FPC-point-frame-v1", rows=n, syntax_nodes=lower + diagonal - n)
            ordinal += 1
            obs.begin(frame, limit, ordinal, round_number, pair)
            answer = _run(query_bytes, provider, frame, context, limit, 0, call, obs)
            m = answer["metrics"]
            totals["frame_runs"] += 1
            totals["frame_atomic_steps"] += m["atomic_steps"]
            totals["sum_frame_limits"] += limit
            totals["frames_exhausted"] += int(answer["status"] == "EXHAUSTED_FRAME")
            totals["frames_fuel_limited"] += int(answer["status"] == "UNKNOWN_FUEL")
            totals["max_path_depth"] = max(totals["max_path_depth"], m["max_path_depth"])
            totals["max_frontier"] = max(totals["max_frontier"], m["max_frontier"])
            last = dict(round=round_number, pair_index=pair, frame=dict(frame), max_steps=limit,
                        status=answer["status"], atomic_steps=m["atomic_steps"])
            if answer["status"] == "CANDIDATE":
                raw, exported, status = answer["candidate_certificate_bytes"], answer["export_receipt"], "CANDIDATE"
                break
            answer = None
            pair, n = pair + 1, n + 1
            if n > diagonal:
                diagonal, n = diagonal + 1, 1
        if status == "CANDIDATE":
            break
        totals["rounds_completed"] += 1
        round_number += 1
    call.tick()
    obs.publish(complete=True)
    totals["callbacks"] = call.callbacks
    return dict(schema=DOVETAIL_SCHEMA, status=status, accepted=False,
        candidate_certificate_bytes=raw, export_receipt=exported, metrics=totals, last_frame=last)
