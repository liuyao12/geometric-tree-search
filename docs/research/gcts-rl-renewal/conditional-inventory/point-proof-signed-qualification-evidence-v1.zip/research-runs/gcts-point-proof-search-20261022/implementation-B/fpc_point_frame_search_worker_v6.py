"""Fresh finite-frame point-search once worker; Source-only at authorship.

Every imported algorithm/control/codec operation belongs inside a separately
reviewed whole actual. All old controls keep their exact original subjects.
No prior output, target route, prefix, learned state or Native oracle is intake.
"""
from pathlib import Path
import hashlib
import importlib.util
import json
import math
import os
import resource
import sys
import time
import traceback

VERSION = 'FPC-full-frame-point-worker-v6'
EXPERIMENT = 'matched-row-csp-point-v1'
PROTOCOL_SCHEMA = "Root-FPC-point-frame-protocol-v1"
PRODUCTION_CONFIGURATION = {'schema': 'FPC-point-frame-worker-search-v1', 'entry': 'search_dovetail', 'max_rounds': None}
MODULE_ROLES = ('checker', 'builders', 'reference', 'baseline_search', 'codec', 'baseline_bank', 'producer', 'obligation_bank', 'point_adapter', 'point_bank', 'intro_bank', 'regression_bank', 'explicit_kernel', 'explicit_oracle', 'explicit_bank', 'provider', 'tiny_oracle', 'tiny_encoder', 'tiny_bank', 'controller', 'frame_oracle', 'controller_bank', 'conclusion_index_bank', 'legacy_provider', 'fixed_slot_bank', 'matched_point_controller', 'csp_controller', 'matched_controller_bank')
FIXED_PINS = {'checker': (31557, '140a9c4b7a6a18c4c20aa4294a0f3fa90f65fe319adbf47a22125170f32b2ef7'), 'builders': (11348, 'a42aa71f1e5482a1e1d9637290b4c7f8b52f366d86f7234a86cb11420171ed32'), 'reference': (24681, 'ecda2a10feb69e5aed6ae34dc6c2123dbbc3297ab5c0a431861d628e9cd4334a'), 'baseline_search': (54407, '53467e578ad7b512ae66e8e03cd85dadba1ded39b9ab0012c17e7e8f170a0902'), 'codec': (14061, '4c6366b1a3728608cedfd86f0c78ca38ffb9d65ffc1907b926fc5f5446ad0ab4'), 'baseline_bank': (35231, 'f0c2be3c99e866aea7a62dc012c6ec96be64c6a0f9b8619a82626d04603946af'), 'obligation_bank': (51653, '309fa0c9d5c068266faf96ff2f61f3ff15874cf24b0065bc83d216fa10152280'), 'point_adapter': (10972, '57eac1681fbb9e3a6494109a1b9ca43cbfa4d5bfc25ce87954537ae801acf32f'), 'point_bank': (18065, 'd49e554bc24fba8539224b7f4099e2f089639f36245a9ed4e47fc2753e7d387e'), 'intro_bank': (10141, '5390689c124393bed3ea8a19c84a1e43bb81d956945dbcebc5712b97892d90c2'), 'producer': (105517, 'fa135ec9e84cdb84b0be506d74a1f167e619b7ac82fcb6a1d8b8782c738523d1'), 'regression_bank': (13618, '2a20fd644b8370d1f6b8f07921075c72b227dc280d9502c9259ac6ed9eb41c7b'), 'explicit_kernel': (29002, '158174c8445997bedf5b17785840eb7a89dcd4d46098fcdfb35a84e2fef3849c'), 'explicit_oracle': (18338, 'ff34af27a491da3571fc02227333ca3ce048a8d7c6d49cb780d3b1c9ba14a995'), 'explicit_bank': (40853, 'eedf82a42ebae7f4133f2ee1781e33205980769f8164bd278641761e6d1a1029'), 'provider': (67637, '39da5195f815da0cceddd11b4d4b25671a50e926ca1885ccc3add6cd99a8d048'), 'tiny_oracle': (14647, 'bcf281fc7e19bf8c08a5b33456a6bb2eeebb33b2034f203f1540820e5e4eff9b'), 'tiny_encoder': (9018, '154615acacc813239d6cf005c82aa37fce96e631098f6408a8798a981a08455d'), 'tiny_bank': (30645, 'dadc7d7cad94fd80dbfe381e9d59f56c1af20d90149f292b9bd70ebe657442f7'), 'controller': (27604, 'e9198683dc830e0080fefde997e81adbcf5963c2671688b491c99bfde3ea9d61'), 'frame_oracle': (3981, 'e4d6f452cbda35b530fb469c10a2441bc694b523df8e46de74c96c4ab074de99'), 'legacy_provider': (58026, '7fc9ebe143513fa86e726c78832cdbb91589fbd9e8a5d2b21eb3183a5fbf5fd2'), 'fixed_slot_bank': (27942, '8a7b33c8729d6c9f40c9354058bbbef24568e885ec8bccf6d12fae04bdf8be03'), 'matched_point_controller': (37990, '16acece30e3420a1097989c8d580d0c9cf103488ac5b3a151d3ff2fc64285fac'), 'csp_controller': (38942, 'bd5adb783474eba00ee486698e5445fd0bf3da367f31a3f0f1321998fa88d5e8'), 'matched_controller_bank': (62115, '4de67bf9eb06235b39b6bcb43a5775e9e11897620775db41a558ca55f661b13d')}
CONTROL_IDS = {'baseline56': ('codec-hi-and-exists-literal', 'codec-pa-no-profile-payload', 'codec-metadata-query-invariance', 'codec-shadowed-binder-preserved', 'codec-bool-mode-refused', 'codec-open-theorem-refused', 'codec-signature-mismatch-refused', 'codec-binder-order-refused', 'codec-extra-proof-field-refused', 'codec-retained-fault-identity', 'product-two-by-three', 'product-three-binary-slots', 'product-closed-empty', 'product-zero-arity', 'product-open-request-not-eof', 'product-staggered-arrivals', 'product-known-empty-dominates-open', 'match-formula-meta', 'match-consistent-repeat', 'match-conflicting-repeat', 'match-rigid-binder', 'match-no-alpha-renaming', 'match-term-meta', 'match-sort-conflict', 'match-variable-meta', 'match-rigid-arity-conflict', 'builder-H1-literal', 'builder-H2-literal', 'builder-H3-literal', 'builder-Q1-literal', 'builder-Q2-literal', 'builder-Q3-literal', 'builder-E1-literal', 'builder-E2-literal', 'builder-Q1-capture-refused', 'builder-Q3-free-variable-refused', 'builder-E2-capture-refused', 'builder-induction-full-parameters-refused', 'search-antecedent-first-closure', 'search-implication-first-closure', 'search-duplicate-source-aliases', 'search-cyclic-demand-no-fact', 'search-long-source-witness-not-fact', 'search-shared-DAG-export', 'search-late-GEN', 'search-full-Gamma-GEN-refusal', 'search-source-variable-outside-grammar', 'search-source-depth-outside-grammar', 'search-priority-record-invariants', 'search-cutoff-live-prefix-no-exhaustion', 'fault-product-first-ValueError', 'fault-matcher-first-StopIteration', 'fault-search-retained-owned-codec', 'fault-search-later-RuntimeError', 'fault-final-validator-first-identity', 'fault-builder-public-class-identity'), 'obligation47': ('search-context-Gamma-present', 'search-context-Gamma-absent', 'search-context-theory-present', 'search-context-theory-absent', 'search-cycle-without-seed', 'search-premise-source-first', 'search-premise-implication-first', 'search-premise-duplicate-source', 'search-shared-context-diamond', 'guard-UI-capture-binder', 'guard-UI-closed-term-no-capture', 'guard-UI-shadowed-target-ID', 'guard-GEN-unused-Gamma-variable', 'guard-GEN-full-Gamma-clear', 'guard-GEN-unused-local-variable', 'guard-induction-wrong-profile', 'guard-induction-wrong-parameters', 'guard-induction-parameter-closure', 'compile-intro-identity', 'compile-intro-root-hypothesis', 'compile-intro-MP', 'compile-intro-GEN', 'compile-nested-equal-assumptions', 'compile-intro-finite-table', 'compile-intro-logical-axiom', 'compile-intro-PA-table', 'compile-intro-incidence-table', 'compile-intro-induction', 'compile-full-FPC-deep-term', 'compile-full-FPC-large-formula', 'refuse-MP-premise-order', 'refuse-rigid-binder-HYP', 'refuse-GEN-unused-root', 'refuse-GEN-unused-local', 'refuse-context-opener', 'refuse-forward-premise', 'refuse-duplicate-arena-row', 'product-diagonal-2x2', 'product-open-WAIT-growth', 'product-closed-empty-open-other', 'product-zero-arity', 'fault-search-first-RuntimeError', 'fault-guard-StopIteration', 'fault-compile-same-public-class', 'fault-retained-owned-through-guard', 'fault-late-compile-first-before-second', 'fault-dual-validators'), 'intro_integration1': ('producer-INTRO-local-HYP-dual-export',), 'point20': ('point-HYP-MP-agreement', 'point-wrong-MP-mark-conflict', 'point-final-goal-boundary-conflict', 'point-GEN-agreement', 'point-GEN-source-mark-conflict', 'point-GEN-unused-Gamma-refusal', 'point-HYP-declared-conclusion-refusal', 'point-LOGICAL-declared-conclusion-refusal', 'point-THEORY-profile-refusal', 'point-MP-forward-reference-refusal', 'point-MP-coincident-port-refusal', 'point-repeated-remote-port-agreement', 'point-long-range-mark-only-agreement', 'point-LOGICAL-Q3-agreement', 'point-THEORY-finite-agreement', 'point-first-RuntimeError-identity', 'point-first-public-refusal-class-identity', 'point-first-StopIteration-identity', 'point-later-first-fault-and-immutability', 'point-retained-family-refusal-identity'), 'regression2': ('refuse-extra-INTRO-reused-owned-context', 'constructor-StopIteration-first-fault-and-owned-cleanup'), 'point-kernel13': ('global-dead-before-forced', 'global-forced-before-earlier-branch', 'generation-before-degree', 'remote-mark-only-zero-is-assigned', 'remote-conflict-dead-before-other-force', 'shared-fractional-placement-once', 'distinct-inventory-identical-point-functions', 'rollback-parent-exclusion', 'mark-reference-count-rollback', 'generation-minimum-rollback', 'outside-support-global-legality', 'lazy-prefix-not-singleton', 'frame-boundary-growth'), 'point-kernel-safety3': ('normal-refusal-and-input-ownership', 'checkpoint-path-and-cursor-ownership', 'first-fault-and-retained-owned-identity'), 'tiny-full-provider10': ('duplicate-HYP-table-full-domain', 'GEN-full-formula-valued-identities', 'MP-full-formula-valued-identities', 'E1-singleton-requires-full-EOF', 'full-Gamma-outside-envelope-blocks-GEN', 'full-Gamma-unblocked-GEN-counterpart', 'out-of-envelope-goal-stays-boundary', 'remote-ports-rebind-retained-parent', 'initial-inspection-not-tried-remainder', 'inventory-first-fault-no-prefix'), 'full-frame-controller10': ('protocol-dead-before-forced', 'protocol-no-forcing-unresolved', 'protocol-global-single-before-earlier-branch', 'protocol-parent-offer-remainder', 'protocol-fuel-not-child-failure', 'protocol-first-fault-no-normal-result', 'real-tiny-candidate-frame-agreement', 'real-tiny-empty-frame-agreement', 'dovetail-first-prefix-budget-restarts', 'public-strict-int-and-input-identity'), 'constructor-index14': ('shape-H1-ancestor-descendant', 'shape-H2-ancestor-descendant', 'shape-H3-ancestor-descendant', 'shape-Q1-ancestor-descendant', 'shape-Q2-ancestor-descendant', 'shape-Q3-ancestor-descendant', 'shape-E1-ancestor-descendant', 'shape-E2-ancestor-descendant', 'shape-induction-empty-prefix-core', 'shape-induction-nonempty-prefix-core', 'helper-first-fault-identities', 'public-cursor-first-fault-poison', 'public-tiny-identities-order-remainders', 'public-incompatible-shape-EOF'), 'fixed-free-slot8': ('rigid-visible-logical-equations', 'Q1-free-terms-public-order-EOF', 'E2-free-body-binder-forward-aliases', 'induction-prefix-singleton-forward', 'MP-fixed-B-reset-unfilled-reference-order', 'GEN-full-Gamma-unfilled-reference-domain', 'absent-output-typed-slots-source-aliases', 'restriction-first-fault-parent-remainder'), 'matched-controller8': ('protocol-global-dead-before-singleton', 'protocol-unresolved-row-ties-no-MRV', 'protocol-remote-dependency-and-exact-undo', 'protocol-owned-offer-remainder-backtrack', 'protocol-phase-fuel-first-fault-and-diagnostics', 'real-duplicate-identities-and-empty-EOF', 'real-E1-two-row-Cartesian-reuse', 'real-full-Gamma-remote-contradictions')}
CAPS = {'work_seconds': 160, 'positive_seconds': 180, 'custody_seconds': 210, 'observer_fallback_seconds': 225, 'memory_bytes': 1073741824, 'physical_bytes': 134217728, 'result_bytes': 50331648, 'log_bytes': 4194304, 'reserved_outer_bytes': 9437184, 'root_callbacks': 400000000}
DECLARATIONS_PIN = (8614, "c6ae5f616b61e85f4b5cbd2b1e7619c047f42d83afd725e277475292cd904b0a")
AUTHORITY_PIN = (7910, "2e7cc31d6e72107d3811cf6a980ec261e0122c8736d4520db9cea119317eb54d")
RAW13_PIN = (15516, "18851c3488152f3743a61eacafc12322c94c48f98038cccf01bd95482793225a")
TINY_INPUT_PIN = (16186, "bd3cefe3f86700f0909d605bcac480e4c0f941dafc529716f68b20350699d708")
CONTROLLER_BANK_PIN = (45831, "41d964fb0075cd034d64ccb98d078c6290e71d09d14ca2bc7ec004d343348f79")

CONCLUSION_BANK_PIN = (29220, '3afd0cbd5c43419f7f8d23e46ef015cfd2232b2325a354e984535ccd14ad1ac5')
CONCLUSION_FIXTURES_PIN = (13490, 'b23d97e5bce2c28e288742d9173787905e0b18ce804cde7a1dc39e3db20695e2')
FIXED_SLOT_FIXTURES_PIN = (36196, '9b2d64e844900e3a5741e0792690bbf58f36ba2a3667d96ef9159d5d9911661a')

WORKER_DIAGNOSTIC_FIELDS = ('schema', 'arm', 'complete', 'snapshot_available', 'publish_seq', 'phase_in_progress', 'active_frame_round', 'active_frame_pair_index', 'active_frame_ordinal', 'active_frame_rows', 'active_frame_syntax_nodes', 'active_frame_limit', 'active_phase', 'active_atomic_steps_committed', 'active_provider_calls_committed', 'active_provider_advances_committed', 'active_domain_completions', 'active_global_scans', 'active_forced_moves', 'active_branch_nodes', 'active_offers', 'active_backtracks', 'active_reject_offers', 'active_reuses', 'active_invalidations', 'active_outstanding_offers', 'active_live_cursors', 'active_highwater_live_cursors', 'active_trail_entries', 'active_highwater_trail_entries', 'frames_completed', 'frames_exhausted', 'frames_fuel_limited', 'completed_atomic_steps_committed', 'completed_provider_calls_committed', 'completed_provider_advances_committed', 'completed_domain_completions', 'completed_global_scans', 'completed_forced_moves', 'completed_branch_nodes', 'completed_offers', 'completed_backtracks', 'completed_reject_offers', 'completed_reuses', 'completed_invalidations', 'completed_highwater_live_cursors', 'completed_highwater_trail_entries', 'raw_member_work_supported', 'raw_member_work')
MATCHED_FIXTURES_PIN = (20281, '71078f5a170cda30c3f7b2d6a699e9c260793f6c8d591316076f6bb86c3ee898')

class RootBudget(RuntimeError):
    """Only a genuine whole-worker limit may create this owned condition."""


def raw_pin(path):
    path = Path(path)
    if (not path.is_absolute() or path.is_symlink() or path.resolve() != path
            or not path.is_file() or '.partial' in path.name):
        raise ValueError('canonical complete ordinary raw body required')
    body = path.read_bytes()
    return dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def pin_fields(row):
    if not (type(row) is dict and {'path', 'bytes', 'sha256'} <= set(row)
            and type(row['path']) is str and type(row['bytes']) is int
            and row['bytes'] >= 0 and type(row['sha256']) is str
            and len(row['sha256']) == 64
            and all(c in '0123456789abcdef' for c in row['sha256'])):
        raise ValueError('typed raw identity required')
    return {key: row[key] for key in ('path', 'bytes', 'sha256')}


def byte_identity(body):
    if type(body) is not bytes:
        raise ValueError('exact immutable bytes required')
    return dict(bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def serialize(value, cap):
    body = (json.dumps(value, sort_keys=True, ensure_ascii=True, allow_nan=False,
                       separators=(',', ':')) + '\n').encode('ascii')
    if len(body) > cap:
        raise RootBudget('complete output ceiling; no truncation or prefix authority')
    return body


def write_body(path, body):
    if path.exists():
        raise ValueError('exclusive new complete output required')
    temporary = path.with_name(path.name + '.partial')
    with temporary.open('xb') as stream:
        stream.write(body)
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)


def load_exact(row, name, check):
    check()
    if name in sys.modules or raw_pin(row['path']) != pin_fields(row):
        raise ValueError('exact new module and unused owned import name required')
    spec = importlib.util.spec_from_file_location(name, row['path'])
    if spec is None or spec.loader is None:
        raise ValueError('ordinary Python Source loader required')
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    check()
    if (Path(module.__file__).resolve() != Path(row['path'])
            or raw_pin(row['path']) != pin_fields(row)):
        raise ValueError('stable exact imported Source origin required')
    return module


def main(plan_path, actual_dir, root_start):
    if not (sys.platform == 'darwin' and sys.flags.isolated and sys.flags.no_site
            and sys.dont_write_bytecode and os.getpid() == os.getpgrp()
            and type(root_start) is float and math.isfinite(root_start)
            and 0 <= root_start <= time.monotonic()):
        raise ValueError('isolated owned Darwin child and genuine parent start required')
    began = root_start
    directory, plan_path = Path(actual_dir), Path(plan_path)
    study = Path(__file__).resolve().parents[1]
    plan_pin = raw_pin(plan_path)
    plan_bytes = plan_path.read_bytes()
    if byte_identity(plan_bytes) != {key: plan_pin[key] for key in ('bytes', 'sha256')}:
        raise ValueError('stable complete plan body required')
    plan = json.loads(plan_bytes)
    del plan_bytes
    index, arm = plan['target_index'], plan['arm']
    if not (type(index) is int and 0 <= index < 6
            and type(arm) is str and arm in ('C0', 'G0')
            and plan['schema'] == 'proof-search-case-once-plan-v1'
            and plan['experiment'] == EXPERIMENT and plan['stage'] == 'evaluate'
            and plan['case_id'] == EXPERIMENT + '-' + arm + '-target-' + str(index)
            and plan['required_upstream_ids'] == []
            and type(plan['target_id']) is str
            and directory.is_absolute() and directory.resolve() == directory
            and not directory.is_symlink() and directory.is_dir()
            and directory == study / 'actual' / plan['case_id']
            and plan['actual_dir'] == str(directory)
            and plan_path.parent == study / 'root' / 'plans'
            and Path(plan['worker_path']) == Path(__file__).resolve()):
        raise ValueError('fresh exact generic target-index case and owned paths required')
    if not (type(plan['limits']) is dict and set(plan['limits']) == set(CAPS)
            and all(type(plan['limits'][key]) is int and plan['limits'][key] == value
                    for key, value in CAPS.items())):
        raise ValueError('all ten original exact whole caps required')
    resource.setrlimit(resource.RLIMIT_FSIZE, (CAPS['physical_bytes'], CAPS['physical_bytes']))
    consumed = json.loads((directory / 'CONSUMED.json').read_bytes())
    if not (consumed['schema'] == 'proof-search-case-consumed-v1'
            and consumed['plan_sha256'] == plan_pin['sha256']
            and consumed['case_id'] == plan['case_id']
            and type(consumed['uses']) is int and consumed['uses'] == 1):
        raise ValueError('fresh exact once consumption required')
    state = dict(stage='PIN_INTAKE', callbacks=0, first_fault=None, stages=[], versions={})
    primary, guards, source_unchanged = None, [], False
    control_subject_bindings = None
    search_diagnostics, search_controller_role = None, None
    qualification = input_freeze = search_result = subject_receipt = reference_receipt = point_receipt = None
    frozen_query = candidate_bytes = scientific = None

    def check():
        if state['first_fault'] is not None:
            raise state['first_fault']
        state['callbacks'] += 1
        fault = None
        if state['callbacks'] > CAPS['root_callbacks']:
            fault = RootBudget('cumulative Root callback ceiling')
        elif time.monotonic() - began >= CAPS['work_seconds']:
            fault = RootBudget('absolute whole-work deadline')
        elif resource.getrusage(resource.RUSAGE_SELF).ru_maxrss >= CAPS['memory_bytes']:
            fault = RootBudget('strict Python whole high-water ceiling')
        if fault is not None:
            state['first_fault'] = fault
            raise fault

    def stage(name, operation):
        check()
        state['stage'] = name
        item = dict(name=name, began=time.monotonic() - began, status='STARTED')
        state['stages'].append(item)
        answer = operation()
        check()
        item.update(status='COMPLETED', seconds=time.monotonic() - began - item['began'])
        return answer

    def verify_files(cooperative):
        for row in guards:
            if cooperative:
                check()
            if raw_pin(row['path']) != row:
                raise ValueError('changed closed Source/input: ' + row['path'])

    def canonical(value):
        check()
        answer = serialize(value, CAPS['result_bytes'])
        check()
        return answer

    def ordered_rows(value, name, counts, row_style):
        check()
        ids = list(CONTROL_IDS[name])
        if not (type(value) is dict and value.get('control_ids') == ids
                and type(value.get('controls')) is list
                and [row.get('id') if type(row) is dict else None for row in value['controls']] == ids
                and type(value.get('counts')) is dict
                and set(value['counts']) == set(counts)
                and all(type(value['counts'][key]) is int and value['counts'][key] == expected
                        for key, expected in counts.items())):
            raise ValueError('complete ordered population/counts required: ' + name)
        for row in value['controls']:
            check()
            if not ((row.get('passed') is True) if row_style == 'passed' else
                    (row.get('status') == 'PASSED')):
                raise ValueError('complete positive control row required: ' + name)

    def bank(name, operation, schema, counts, row_style='passed', population=None):
        result = stage('CONTROLS ' + name, operation)
        if not (type(result) is dict and result.get('schema') == schema
                and result.get('complete') is True
                and (population is None or result.get('population') == population)):
            raise ValueError('complete exact bank carrier required: ' + name)
        ordered_rows(result, name, counts, row_style)
        return result

    def copy_search_diagnostics():
        # Explicit fixed-primitive worker observation; no scientific API/getter/check.
        # In a fault receipt this executes within output/custody limits and cannot
        # replace the original error or qualify a scientific/control prefix.
        unavailable = dict(schema='Root-matched-search-diagnostic-observation-v1',
            available=False, non_authoritative=True, snapshot=None,
            controller_call_complete_at_checkpoint=None)
        try:
            if (type(search_diagnostics) is not dict or
                    len(search_diagnostics) != len(WORKER_DIAGNOSTIC_FIELDS) or
                    any(type(k) is not str for k in search_diagnostics) or
                    set(search_diagnostics) != set(WORKER_DIAGNOSTIC_FIELDS) or
                    search_diagnostics['snapshot_available'] is not True):
                return unavailable
            snapshot = {}
            for key in WORKER_DIAGNOSTIC_FIELDS:
                value = search_diagnostics[key]
                if key in ('complete', 'snapshot_available', 'phase_in_progress', 'raw_member_work_supported'):
                    good = type(value) is bool
                elif key == 'schema':
                    good = type(value) is str and value == 'matched-row-controller-diagnostics-v1'
                elif key == 'arm':
                    good = type(value) is str and value == arm
                elif key == 'active_phase':
                    good = value is None or (type(value) is str and value in (
                        'INVENTORY', 'ROOT', 'DEPENDENCY', 'LOAD', 'REUSE', 'SCAN',
                        'CLASSIFY_OPEN', 'CLASSIFY_ADVANCE', 'FORCE_PLACE', 'BRANCH_OPEN',
                        'OFFER', 'OFFER_PLACE', 'BACKTRACK', 'EXPORT'))
                else:
                    good = value is None or (type(value) is int and value >= 0)
                if not good:
                    return unavailable
                snapshot[key] = value
            if snapshot['raw_member_work_supported'] is not False or snapshot['raw_member_work'] is not None:
                return unavailable
            controller_complete = snapshot['complete']
            if primary is not None:
                snapshot['complete'] = False
            return dict(schema='Root-matched-search-diagnostic-observation-v1', available=True,
                non_authoritative=True, snapshot=snapshot,
                controller_call_complete_at_checkpoint=controller_complete,
                scope='Last published fixed-scalar checkpoint. Interrupted-phase work may be absent; '
                      'counts are not proof, control qualification, a resume input or a causal profile.')
        except BaseException:
            return unavailable

    try:
        check()
        if type(plan['files']) is not list or not plan['files']:
            raise ValueError('closed nonempty exact guards required')
        guards = [pin_fields(row) for row in plan['files']]
        if len({row['path'] for row in guards}) != len(guards):
            raise ValueError('unique guarded paths required')
        by_path = {row['path']: row for row in guards}
        if type(plan['module_pins']) is not dict or set(plan['module_pins']) != set(MODULE_ROLES):
            raise ValueError('exact twenty-eight namespace roles required')
        module_pins = {role: pin_fields(plan['module_pins'][role]) for role in MODULE_ROLES}
        fixed = dict(FIXED_PINS, controller_bank=CONTROLLER_BANK_PIN, conclusion_index_bank=CONCLUSION_BANK_PIN)
        for role, row in module_pins.items():
            check()
            if by_path.get(row['path']) != row or (row['bytes'], row['sha256']) != fixed[role]:
                raise ValueError('exact pinned current module in closed guards required: ' + role)
        control_subject_bindings = {
            'tiny-full-provider10': {'provider': module_pins['provider']},
            'full-frame-controller10': {'controller': module_pins['controller'], 'provider': module_pins['provider']},
            'constructor-index14': {'provider': module_pins['legacy_provider']},
            'fixed-free-slot8': {'provider': module_pins['provider'], 'baseline_provider': module_pins['legacy_provider']},
            'matched-controller8': {role: module_pins[role] for role in
                ('matched_point_controller', 'csp_controller', 'provider')}}
        for key in ('protocol', 'python', 'declarations', 'target_authority',
                    'explicit_raw_models', 'tiny_provider_declarations', 'conclusion_index_fixtures',
                    'fixed_free_slot_fixtures', 'matched_controller_fixtures'):
            row = pin_fields(plan[key])
            if by_path.get(row['path']) != row:
                raise ValueError('all runtime/phase pins must be guarded')
        for key, expected in (('declarations', DECLARATIONS_PIN), ('target_authority', AUTHORITY_PIN),
                              ('explicit_raw_models', RAW13_PIN), ('tiny_provider_declarations', TINY_INPUT_PIN),
                              ('conclusion_index_fixtures', CONCLUSION_FIXTURES_PIN),
                              ('fixed_free_slot_fixtures', FIXED_SLOT_FIXTURES_PIN),
                              ('matched_controller_fixtures', MATCHED_FIXTURES_PIN)):
            if (plan[key]['bytes'], plan[key]['sha256']) != expected:
                raise ValueError('unchanged exact public literal input required: ' + key)
        if (by_path.get(str(Path(__file__).resolve())) != raw_pin(Path(__file__).resolve())
                or raw_pin(Path(sys.executable).resolve()) != pin_fields(plan['python'])):
            raise ValueError('exact current worker/isolated runtime required')
        populations = plan['control_populations']
        if type(populations) is not dict or set(populations) != set(CONTROL_IDS):
            raise ValueError('all twelve scoped populations required')
        for name, ids in CONTROL_IDS.items():
            check()
            if type(populations[name]) is not dict or populations[name].get('control_ids') != list(ids):
                raise ValueError('exact unchanged ordered scoped ID vector required')
        protocol = json.loads(Path(plan['protocol']['path']).read_bytes())
        required = {'schema', 'experiment', 'limits', 'module_pins', 'control_populations', 'job_recipes'}
        if not (type(protocol) is dict and required <= set(protocol)
                and set(protocol) <= required | {'metadata'}
                and ('metadata' not in protocol or type(protocol['metadata']) is dict)
                and protocol['schema'] == PROTOCOL_SCHEMA and protocol['experiment'] == EXPERIMENT
                and canonical(protocol['limits']) == canonical(CAPS)
                and canonical(protocol['module_pins']) == canonical(plan['module_pins'])
                and canonical(protocol['control_populations']) == canonical(populations)):
            raise ValueError('exact current prospective protocol association required')
        declarations = json.loads(Path(plan['declarations']['path']).read_bytes())
        if not (declarations.get('schema') == 'FPC-H1-six-public-development-target-declarations-v1'
                and type(declarations.get('targets')) is list and len(declarations['targets']) == 6):
            raise ValueError('exact original six-declaration carrier required')
        expected_recipes = []
        for target_index, spec in enumerate(declarations['targets']):
            check()
            for recipe_arm in ('C0', 'G0'):
                expected_recipes.append(dict(case_id=EXPERIMENT + '-' + recipe_arm + '-target-' + str(target_index),
                    arm=recipe_arm, target_index=target_index, target_id=spec['id']))
        if canonical(protocol['job_recipes']) != canonical(expected_recipes):
            raise ValueError('all twelve exact generic arm/target recipes required')
        if plan['target_id'] != declarations['targets'][index]['id']:
            raise ValueError('literal declaration index/identity mismatch')
        configuration_frozen = canonical(PRODUCTION_CONFIGURATION)
        if canonical(plan['search_configuration']) != configuration_frozen:
            raise ValueError('exact generic fair-dovetail production configuration required')
        verify_files(True)
        modules = {}
        for role in MODULE_ROLES:
            name = 'explicit_point_literal_oracle_v1' if role == 'explicit_oracle' else (
                'owned_point_frame_worker_' + role + '_v1')
            modules[role] = stage('IMPORT ' + role,
                lambda role=role, name=name: load_exact(module_pins[role], name, check))
            state['versions'][role] = modules[role].VERSION
        if not (modules['provider'].VERSION == 'FPC-POINT-FULL-FRAME-PROVIDER-v1'
                and modules['provider'].IMPLEMENTATION_REVISION == 'FPC-POINT-FULL-FRAME-PROVIDER-implementation-v6'
                and 'dependency-rebind-classification' in modules['provider'].FEATURES
                and 'conclusion-constructor-index' in modules['provider'].FEATURES
                and 'constrained-output-slots' in modules['provider'].FEATURES
                and modules['legacy_provider'].VERSION == 'FPC-POINT-FULL-FRAME-PROVIDER-v1'
                and modules['legacy_provider'].IMPLEMENTATION_REVISION == 'FPC-POINT-FULL-FRAME-PROVIDER-implementation-v4'
                and modules['controller_bank'].VERSION == 'L-full-frame-controller-controls-v2'
                and modules['conclusion_index_bank'].VERSION == 'L-conclusion-index-independent-controls-v2'
                and modules['fixed_slot_bank'].VERSION == 'L-fixed-free-slot-independent-controls-v2'
                and modules['matched_point_controller'].VERSION == 'FPC-POINT-FRAME-CONTROLLER-v3'
                and modules['csp_controller'].VERSION == 'FPC-ROW-CSP-CONTROLLER-v1'
                and modules['matched_controller_bank'].VERSION == 'L-matched-row-controller-controls-v2'
                and modules['matched_point_controller'].DIAGNOSTIC_FIELDS == WORKER_DIAGNOSTIC_FIELDS
                and modules['csp_controller'].DIAGNOSTIC_FIELDS == WORKER_DIAGNOSTIC_FIELDS):
            raise ValueError('authenticated provider and current controller/index-bank revisions required')
        declaration_frozen = canonical(declarations)

        def freeze_input():
            check()
            spec = declarations['targets'][index]
            encoded = modules['codec'].encode_declared_query(spec, check=check)
            if not (type(encoded) is dict and set(encoded) == {'query_bytes', 'receipt'}
                    and type(encoded['query_bytes']) is bytes and type(encoded['receipt']) is dict):
                raise ValueError('complete exact immutable codec carrier required')
            query_bytes, codec = encoded['query_bytes'], encoded['receipt']
            parsed = modules['checker'].decode_query(query_bytes, check=check)
            if not (parsed['version'] == 1 and parsed['claim_mode'] == spec['mode']
                    and parsed['theory_profile'] == spec['profile_id']
                    and canonical(parsed['function_arities']) == canonical(spec['function_arities'])
                    and canonical(parsed['predicate_arities']) == canonical(spec['predicate_arities'])
                    and canonical(parsed['Gamma']) == canonical(spec['hypotheses'])
                    and parsed['finite_axioms'] == [] and parsed['EOF'] == len(query_bytes)):
                raise ValueError('exact encoded signature/profile/mode/Gamma/EOF required')
            association = dict(profile_id=spec['profile_id'], function_arities=spec['function_arities'],
                predicate_arities=spec['predicate_arities'], mode=spec['mode'], hypotheses=spec['hypotheses'],
                expanded_goal=parsed['goal'], query_identity=byte_identity(query_bytes))
            if not (codec.get('complete') is True and codec.get('declaration_id') == spec['id']
                    and canonical({key: codec.get(key) for key in association}) == canonical(association)):
                raise ValueError('exact independent codec/parsed query association required')
            write_body(directory / 'target-query.bin', query_bytes)
            record = dict(schema='FPC-point-frame-in-job-target-freeze-v1',
                declaration=pin_fields(plan['declarations']), target_index=index, literal_declaration=spec,
                codec_Source=module_pins['codec'], codec_receipt=codec, decoded_query=parsed,
                immutable_query=raw_pin(directory / 'target-query.bin'), search_started=False,
                scope='Fresh input association only; no proof, control qualification or admission')
            write_body(directory / 'target-input-freeze.json', serialize(record, CAPS['result_bytes']))
            check()
            return query_bytes, record

        frozen_query, input_freeze = stage('FREEZE independent target before controls/search', freeze_input)
        query_identity = byte_identity(frozen_query)
        query_fields = {key: input_freeze['decoded_query'][key] for key in
            ('version', 'claim_mode', 'function_arities', 'predicate_arities', 'theory_profile',
             'finite_axioms', 'Gamma', 'goal')}
        query_fields_frozen = canonical(query_fields)
        kernel_modules = {role: modules[role] for role in ('checker', 'builders', 'reference')}
        logical_modules = {role: modules[role] for role in ('checker', 'builders')}
        qualification = {}
        qualification['baseline56'] = bank('baseline56', lambda:
            modules['baseline_bank'].run_search_controls(search=modules['baseline_search'],
                codec=modules['codec'], modules=kernel_modules, check=check),
            'FPC-H1-independent-search-controls-v1', dict(total=56, passed=56, failed=0))
        qualification['obligation47'] = bank('obligation47', lambda:
            modules['obligation_bank'].run_obligation_controls(modules['producer'], modules=kernel_modules, check=check),
            'FPC-H1-independent-obligation-controls-v1', dict(groups=47, passed=47, failed=0))
        qualification['intro_integration1'] = bank('intro_integration1', lambda:
            modules['intro_bank'].run_intro_integration_control(modules['producer'], modules=kernel_modules, check=check),
            'FPC-H1-obligation-INTRO-integration-control-v1', dict(groups=1, passed=1, failed=0))
        qualification['regression2'] = bank('regression2', lambda:
            modules['regression_bank'].run_obligation_regression_controls(modules['producer'], modules=kernel_modules, check=check),
            'FPC-H1-obligation-two-defect-regressions-v1', dict(groups=2, passed=2, failed=0))
        qualification['point20'] = bank('point20', lambda:
            modules['point_bank'].run_point_row_controls(modules['point_adapter'], builders=modules['builders'], check=check),
            'FPC-H1-point-row-independent-controls-v1', dict(groups=20, passed=20, failed=0))
        raw_models = json.loads(Path(plan['explicit_raw_models']['path']).read_bytes())
        tiny_declarations = json.loads(Path(plan['tiny_provider_declarations']['path']).read_bytes())
        conclusion_fixtures = json.loads(Path(plan['conclusion_index_fixtures']['path']).read_bytes())
        raw_models_frozen, tiny_frozen = canonical(raw_models), canonical(tiny_declarations)
        conclusion_frozen = canonical(conclusion_fixtures)
        fixed_slot_fixtures = json.loads(Path(plan['fixed_free_slot_fixtures']['path']).read_bytes())
        fixed_slot_frozen = canonical(fixed_slot_fixtures)
        matched_fixtures = json.loads(Path(plan['matched_controller_fixtures']['path']).read_bytes())
        matched_frozen = canonical(matched_fixtures)
        explicit = stage('CONTROLS explicit-point16', lambda:
            modules['explicit_bank'].run_point_kernel_controls(modules['explicit_kernel'], raw_models=raw_models, check=check))
        if not (type(explicit) is dict and explicit.get('schema') == 'independent-explicit-point-controls-v1'
                and explicit.get('complete') is True and type(explicit.get('counts')) is dict
                and set(explicit['counts']) == {'raw_groups', 'additional_groups', 'groups', 'passed', 'failed'}
                and all(type(x) is int for x in explicit['counts'].values())
                and explicit['counts'] == dict(raw_groups=13, additional_groups=3, groups=16, passed=16, failed=0)):
            raise ValueError('complete independent explicit16 wrapper required')
        for field, name, count in (('raw_population', 'point-kernel13', 13),
                                   ('additional_population', 'point-kernel-safety3', 3)):
            if explicit[field].get('population') != name:
                raise ValueError('explicit population identity mismatch')
            ordered_rows(explicit[field], name, dict(groups=count, passed=count, failed=0), 'status')
        qualification['explicit16'] = explicit
        qualification['tiny-full-provider10'] = bank('tiny-full-provider10', lambda:
            modules['tiny_bank'].run_tiny_provider_controls(modules['provider'], declarations=tiny_declarations,
                oracle=modules['tiny_oracle'], encoder=modules['tiny_encoder'], modules=logical_modules, check=check),
            'independent-tiny-full-FPC-provider-controls-v1', dict(groups=10, passed=10, failed=0),
            'status', 'tiny-full-provider10')
        qualification['full-frame-controller10'] = bank('full-frame-controller10', lambda:
            modules['controller_bank'].run_frame_controller_controls(modules['controller'], provider=modules['provider'],
                declarations=tiny_declarations, row_oracle=modules['tiny_oracle'], frame_oracle=modules['frame_oracle'],
                encoder=modules['tiny_encoder'], modules=kernel_modules, check=check),
            'independent-full-frame-controller-controls-v1', dict(groups=10, passed=10, failed=0),
            'status', 'full-frame-controller10')
        if qualification['full-frame-controller10'].get('version') != 'L-full-frame-controller-controls-v2':
            raise ValueError('complete current controller-bank-v2 receipt required')
        qualification['constructor-index14'] = bank('constructor-index14', lambda:
            modules['conclusion_index_bank'].run_conclusion_index_controls(modules['legacy_provider'],
                fixtures=conclusion_fixtures, declarations=tiny_declarations, oracle=modules['tiny_oracle'],
                encoder=modules['tiny_encoder'], modules=kernel_modules, check=check),
            'independent-conclusion-index-controls-v1', dict(groups=14, passed=14, failed=0),
            'status', 'constructor-index14')
        if qualification['constructor-index14'].get('version') != 'L-conclusion-index-independent-controls-v2':
            raise ValueError('complete current constructor-index14 receipt required')
        qualification['fixed-free-slot8'] = bank('fixed-free-slot8', lambda:
            modules['fixed_slot_bank'].run_fixed_free_slot_controls(modules['provider'],
                baseline_provider=modules['legacy_provider'], fixtures=fixed_slot_fixtures,
                encoder=modules['tiny_encoder'], codec=modules['codec'], modules=kernel_modules, check=check),
            'independent-fixed-free-slot-controls-v1', dict(groups=8, passed=8, failed=0),
            'status', 'fixed-free-slot8')
        if qualification['fixed-free-slot8'].get('version') != 'L-fixed-free-slot-independent-controls-v2':
            raise ValueError('complete current fixed-free-slot8 receipt required')
        qualification['matched-controller8'] = bank('matched-controller8', lambda:
            modules['matched_controller_bank'].run_matched_controller_controls(
                modules['csp_controller'], modules['matched_point_controller'], provider=modules['provider'],
                fixtures=matched_fixtures, declarations=tiny_declarations, row_oracle=modules['tiny_oracle'],
                frame_oracle=modules['frame_oracle'], encoder=modules['tiny_encoder'], modules=kernel_modules, check=check),
            'independent-matched-row-controller-controls-v1', dict(groups=8, passed=8, failed=0),
            'status', 'matched-controller8')
        if qualification['matched-controller8'].get('version') != 'L-matched-row-controller-controls-v2':
            raise ValueError('complete matched-controller8 version required')
        if (canonical(raw_models) != raw_models_frozen or canonical(tiny_declarations) != tiny_frozen
                or canonical(declarations) != declaration_frozen
                or canonical(conclusion_fixtures) != conclusion_frozen
                or canonical(fixed_slot_fixtures) != fixed_slot_frozen
                or canonical(matched_fixtures) != matched_frozen):
            raise ValueError('scientific control/codec mutated immutable public declaration input')
        supplied_modules = dict(logical_modules)
        supplied_configuration = json.loads(configuration_frozen)
        search_controller_role = 'csp_controller' if arm == 'C0' else 'matched_point_controller'
        search_diagnostics = dict.fromkeys(WORKER_DIAGNOSTIC_FIELDS, None)
        search_diagnostics.update(schema='matched-row-controller-diagnostics-v1', arm=arm,
            complete=False, snapshot_available=False, phase_in_progress=False, raw_member_work_supported=False)
        search_result = stage('SEARCH ' + arm + ' fresh full-FPC matched dovetail', lambda:
            modules[search_controller_role].search_dovetail(frozen_query, provider=modules['provider'],
                modules=supplied_modules, max_rounds=supplied_configuration['max_rounds'],
                diagnostics=search_diagnostics, check=check))
        if not copy_search_diagnostics()['available'] or search_diagnostics['complete'] is not True:
            raise ValueError('normally completed exact bounded diagnostics required')
        check()
        if (canonical(plan['search_configuration']) != configuration_frozen
                or canonical(PRODUCTION_CONFIGURATION) != configuration_frozen
                or canonical(supplied_configuration) != configuration_frozen
                or set(supplied_modules) != set(logical_modules)
                or any(supplied_modules[key] is not logical_modules[key] for key in logical_modules)
                or byte_identity(frozen_query) != query_identity
                or canonical(query_fields) != query_fields_frozen):
            raise ValueError('production inputs/configuration/module mapping changed')
        expected_keys = {'schema', 'status', 'accepted', 'candidate_certificate_bytes',
                         'export_receipt', 'metrics', 'last_frame'}
        metric_keys = {'rounds_completed', 'frame_runs', 'frame_atomic_steps', 'sum_frame_limits',
                      'frames_exhausted', 'frames_fuel_limited', 'callbacks', 'max_path_depth', 'max_frontier'}
        if not (type(search_result) is dict and set(search_result) == expected_keys
                and search_result['schema'] == ('FPC-row-CSP-dovetail-search-v1' if arm == 'C0' else 'FPC-point-dovetail-search-v1')
                and search_result['accepted'] is False and type(search_result['metrics']) is dict
                and set(search_result['metrics']) == metric_keys
                and all(type(x) is int and x >= 0 for x in search_result['metrics'].values())):
            raise ValueError('exact nonadmitted public dovetail carrier required')
        status = search_result['status']
        if status != 'CANDIDATE':
            # max_rounds=None has no ordinary round-limit return. Resource
            # exhaustion propagates and withholds the entire positive result.
            raise ValueError('unbounded-round production cannot return a normal noncandidate')
        candidate_bytes = search_result['candidate_certificate_bytes']
        export = search_result['export_receipt']
        last = search_result['last_frame']
        if not (type(candidate_bytes) is bytes and bool(candidate_bytes) and type(export) is dict
                and export.get('schema') == 'FPC-point-candidate-export-v1' and export.get('accepted') is False
                and type(last) is dict and set(last) == {'round', 'pair_index', 'frame', 'max_steps', 'status', 'atomic_steps'}
                and last['status'] == 'CANDIDATE'
                and all(type(last[key]) is int and last[key] >= 1 for key in ('round', 'pair_index', 'max_steps'))
                and type(last['atomic_steps']) is int and last['atomic_steps'] >= 0
                and last['atomic_steps'] <= last['max_steps'] and type(last['frame']) is dict
                and set(last['frame']) == {'schema', 'rows', 'syntax_nodes'}
                and last['frame']['schema'] == 'FPC-point-frame-v1'
                and all(type(last['frame'][key]) is int and last['frame'][key] >= 1 for key in ('rows', 'syntax_nodes'))):
            raise ValueError('complete exact candidate and last frame required')
        expected_model = dict(schema='FPC-point-model-identity-v1',
            inventory_version='FPC-POINT-FULL-FRAME-PROVIDER-v1', query_hex=frozen_query.hex(),
            query=query_fields, frame=last['frame'])
        if not (canonical(export.get('model')) == canonical(expected_model)
                and type(export.get('exact_rows')) is int and export['exact_rows'] == last['frame']['rows']
                and type(export.get('rows')) is list and len(export['rows']) == export['exact_rows']):
            raise ValueError('candidate must bind full original query/model and exact frame')
        write_body(directory / 'candidate-certificate.bin', candidate_bytes)
        certificate_identity = byte_identity(candidate_bytes)
        subject_receipt = stage('VALIDATE original subject same bytes', lambda:
            modules['checker'].check_certificate(frozen_query, candidate_bytes, check=check))
        reference_receipt = stage('VALIDATE original independent reference same bytes', lambda:
            modules['reference'].reference_check_certificate(frozen_query, candidate_bytes, check=check))
        if not (type(subject_receipt) is dict and subject_receipt.get('status') == 'VALID_DERIVATION'
                and all(subject_receipt.get(key) is True for key in
                    ('complete', 'accepted', 'syntax_complete', 'derivation_complete', 'no_prefix_authority', 'final_goal_equal'))
                and subject_receipt['raw_inputs']['query'] == query_identity
                and subject_receipt['raw_inputs']['certificate'] == certificate_identity):
            raise ValueError('original complete subject/raw input proof gates failed')
        if not (type(reference_receipt) is dict
                and reference_receipt.get('schema') == 'FPC-H1-independent-flat-reference-v2'
                and reference_receipt.get('status') == 'VALID_DERIVATION'
                and reference_receipt.get('complete_check') is True
                and reference_receipt.get('final_goal_equal') is True):
            raise ValueError('original independent complete reference proof gates failed')
        point_input = canonical(dict(query=subject_receipt['query'], certificate=subject_receipt['certificate']))
        point_receipt = stage('REDUCE dual-validated same rows to points', lambda:
            modules['point_adapter'].check_rows_as_points(subject_receipt['query'], subject_receipt['certificate'],
                                                        builders=modules['builders'], check=check))
        if canonical(dict(query=subject_receipt['query'], certificate=subject_receipt['certificate'])) != point_input:
            raise ValueError('point adapter mutated the paired validated parser records')
        if not (type(point_receipt) is dict and point_receipt.get('schema') == 'FPC-H1-point-row-observation-v1'
                and point_receipt.get('complete') is True and point_receipt.get('point_compatible') is True
                and point_receipt.get('mismatches') == [] and point_receipt.get('proof_admitted') is False
                and point_receipt.get('search_engine') is False and point_receipt.get('GCTS_conformance') is False
                and type(point_receipt.get('row_count')) is int
                and point_receipt['row_count'] == subject_receipt['certificate']['row_count']):
            raise ValueError('complete immutable same-certificate point reduction failed')
        if byte_identity(frozen_query) != query_identity or byte_identity(candidate_bytes) != certificate_identity:
            raise ValueError('immutable final proof bytes changed')
        scientific = dict(status='FOUND_VALID_PENDING_ROOT_WHOLE_ADMISSION', query=query_identity,
            certificate=certificate_identity, same_immutable_inputs_to_both_validators=True,
            scope='New shared-provider matched row driver candidate validated by both original byte checkers; '
                  'point reduction is separate representation. No learned marking/RL/advantage/fixed Wang palette claim.')
        check()
    except BaseException as error:
        if type(error) is RootBudget and state['first_fault'] is None:
            state['first_fault'] = error
        primary = state['first_fault'] if state['first_fault'] is not None else error
    finally:
        try:
            verify_files(primary is None)
            source_unchanged = bool(guards)
        except BaseException as error:
            source_unchanged = False
            if primary is None:
                primary = state['first_fault'] if state['first_fault'] is not None else error

    def receipt():
        saved_search = None
        if primary is None and search_result is not None:
            saved_search = {key: value for key, value in search_result.items()
                            if key != 'candidate_certificate_bytes'}
            saved_search['candidate_certificate_hex'] = candidate_bytes.hex() if candidate_bytes is not None else None
        return dict(schema='FPC-point-frame-whole-worker-v1', case_id=plan['case_id'], stage='evaluate',
            worker_version=VERSION, arm=arm, status='COMPLETE' if primary is None else 'FAILED_CASE_NOT_ADMITTED',
            stages=state['stages'], callbacks=state['callbacks'], elapsed_seconds=time.monotonic() - began,
            source_unchanged=source_unchanged, python_peak_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            native_peak_bytes=0, native_requests_started=0, native_queries=[],
            native_transport=dict(closed=True, all_reaped=True, native_exit_code=0,
                native_high_water_bytes=0, subprocesses_started=0, scope='VACUOUS_NO_NATIVE_SUBPROCESS'),
            guard_compilations=[], work_snapshots=[], qualification_complete=primary is None,
            qualification_result=qualification if primary is None else None,
            input_freeze=input_freeze if primary is None else None, search_result=saved_search,
            subject_receipt=subject_receipt if primary is None else None,
            reference_receipt=reference_receipt if primary is None else None,
            point_receipt=point_receipt if primary is None else None,
            scientific_result=scientific if primary is None else None,
            error=None if primary is None else dict(type=type(primary).__name__, message=str(primary),
                traceback=''.join(traceback.format_exception(primary))),
            first_Root_fault=state['first_fault'] is not None, old_qualification_reused=False,
            component_versions=state['versions'],
            control_subject_bindings=control_subject_bindings,
            search_controller_role=search_controller_role,
            search_controller_Source=None if search_controller_role is None else module_pins[search_controller_role],
            search_diagnostic_observation=copy_search_diagnostics(),
            scope='Fresh six-target design, one generic metadata-selected target '
                'per once job; original126 keep original subjects; explicit16/tiny10/controller10 are separately scoped. '
                'Original184 subject bindings remain exact; matched8 applies separately to both new controllers/provider6. 192 is a scoped group count. '
                'No positive prefix authority, proof admission, target route, truth, full geometry, learned-GCTS/RL '
                'or universal finite Wang verifier claim. All final Root custody/C/disposition gates remain external.')

    try:
        if primary is None:
            check()
        body = serialize(receipt(), CAPS['result_bytes'])
        if primary is None:
            check()
    except BaseException as error:
        if primary is None:
            if type(error) is RootBudget and state['first_fault'] is None:
                state['first_fault'] = error
            primary = state['first_fault'] if state['first_fault'] is not None else error
        body = serialize(receipt(), CAPS['result_bytes'])
    result_path = directory / ('result.json' if primary is None else 'failure.json')
    write_body(result_path, body)
    del body
    result_pin = raw_pin(result_path)
    header = dict(schema='proof-search-case-worker-header-v1', case_id=plan['case_id'],
        status='COMPLETE' if primary is None else 'FAILED_CASE_NOT_ADMITTED',
        callbacks=state['callbacks'], seconds=time.monotonic() - began,
        python_peak_after_output_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        native_peak_bytes=0, source_unchanged=source_unchanged,
        native_closed_and_reaped=True, first_Root_fault=state['first_fault'] is not None,
        result=result_pin, native_scope='VACUOUS_NO_NATIVE_SUBPROCESS')
    write_body(directory / 'worker-header.json', serialize(header, CAPS['log_bytes']))
    print(json.dumps(dict(case_id=plan['case_id'], status=header['status'], callbacks=state['callbacks'],
                          seconds=time.monotonic() - began)))
    return 0 if (primary is None and source_unchanged
        and time.monotonic() - began < CAPS['positive_seconds']
        and resource.getrusage(resource.RUSAGE_SELF).ru_maxrss < CAPS['memory_bytes']) else 2


if __name__ == '__main__':
    if len(sys.argv) != 4:
        raise SystemExit('usage: fpc_point_frame_search_worker_v6.py PLAN ACTUAL_DIR ROOT_START')
    raise SystemExit(main(sys.argv[1], sys.argv[2], float(sys.argv[3])))
