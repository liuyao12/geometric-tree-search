"""Independent matched C0/G0 controls. Source authored before either new implementation read.
No scientific modules imported. All injected algorithms/encoding/fixtures run ONLY
inside a future independently reviewed bounded actual. Protocol members are NOT FPC.
The script scaffold is copied from L's earlier independent controller bank, not an
actual result or implementation. This population is additive, not a bank replacement.
"""
import json
import hashlib
import math

VERSION = "L-matched-row-controller-controls-v1"
RETURN_SCHEMA = "independent-matched-row-controller-controls-v1"
POPULATION = "matched-controller8"
CONTROL_IDS = ('protocol-global-dead-before-singleton', 'protocol-unresolved-row-ties-no-MRV', 'protocol-remote-dependency-and-exact-undo', 'protocol-owned-offer-remainder-backtrack', 'protocol-phase-fuel-first-fault-and-diagnostics', 'real-duplicate-identities-and-empty-EOF', 'real-E1-two-row-Cartesian-reuse', 'real-full-Gamma-remote-contradictions')
FIXTURE_CANONICAL_SHA256 = '2ad3addf6f68ce9b09fdff50ca8e91897512b5cbb4f079f17b1a45362d7905db'
TINY_CANONICAL_SHA256 = "0d72dce6742d07594fef597290c53b4582bd1743711c52f974ac6d29aa2f3b49"
DIAGNOSTIC_FIELDS = ('schema', 'arm', 'complete', 'snapshot_available', 'publish_seq', 'phase_in_progress', 'active_frame_round', 'active_frame_pair_index', 'active_frame_ordinal', 'active_frame_rows', 'active_frame_syntax_nodes', 'active_frame_limit', 'active_phase', 'active_atomic_steps_committed', 'active_provider_calls_committed', 'active_provider_advances_committed', 'active_domain_completions', 'active_global_scans', 'active_forced_moves', 'active_branch_nodes', 'active_offers', 'active_backtracks', 'active_reject_offers', 'active_reuses', 'active_invalidations', 'active_outstanding_offers', 'active_live_cursors', 'active_highwater_live_cursors', 'active_trail_entries', 'active_highwater_trail_entries', 'frames_completed', 'frames_exhausted', 'frames_fuel_limited', 'completed_atomic_steps_committed', 'completed_provider_calls_committed', 'completed_provider_advances_committed', 'completed_domain_completions', 'completed_global_scans', 'completed_forced_moves', 'completed_branch_nodes', 'completed_offers', 'completed_backtracks', 'completed_reject_offers', 'completed_reuses', 'completed_invalidations', 'completed_highwater_live_cursors', 'completed_highwater_trail_entries', 'raw_member_work_supported', 'raw_member_work')
PUBLIC_ACTIONS = ("NORMALIZE", "ENUMERATE", "INTRINSIC", "ENVELOPE", "POINT_CHECK", "EMIT", "EOF")
COUNTER_NAMES = ("committed_actions", "raw_tuples_complete", "intrinsic_refusals", "envelope_exclusions", "point_conflicts", "distinct_legal_inspected", "shortcut_candidates_proved", "fallback_eof_events", "branch_offers", "failed_children_recorded", "tried_prefix_advances")
EVENT_KEYS = {'STATE': {'kind', 'parent_serial', 'snapshot', 'depth', 'state_serial'}, 'DOMAIN': {'kind', 'remainder_revision', 'witnesses', 'row', 'coverage_complete', 'domain_kind', 'source', 'state_serial'}, 'DECISION': {'kind', 'status', 'all_unfilled', 'row', 'state_serial'}, 'SELECT': {'kind', 'forced', 'parent_serial', 'branch_serial', 'row', 'child_serial', 'candidate', 'from_offer', 'offer_serial'}, 'OFFER': {'kind', 'branch_serial', 'row', 'candidate', 'state_serial', 'offer_serial'}, 'REJECT': {'kind', 'branch_serial', 'row', 'restored_parent_serial', 'reason', 'failed_child_serial', 'offer_serial'}, 'REUSE': {'kind', 'state_serial', 'from_state_serial', 'row'}, 'INVALIDATE': {'kind', 'state_serial', 'from_state_serial', 'row'}, 'TERMINAL': {'kind', 'outstanding_offers', 'status', 'phase', 'atomic_steps'}}
_OWNER = object()

class MatchedControllerControlError(ValueError):
    pass

class _Call:
    def __init__(self, check):
        self.check, self.first = check, None

    def tick(self):
        if self.first is not None:
            raise self.first
        try:
            self.check()
        except BaseException as error:
            self.first = error
            raise

    def need(self, value, message):
        if self.first is not None:
            raise self.first
        if not value:
            error = MatchedControllerControlError(message)
            error._owner = _OWNER
            raise error

def _copy(value, call):
    call.tick()
    if value is None or type(value) in (str, int, bool):
        return value
    if type(value) is float:
        call.need(math.isfinite(value), "finite evidence float")
        return value
    if type(value) in (list, tuple):
        return [_copy(child, call) for child in value]
    call.need(type(value) is dict, "ordinary carrier")
    return {key: _copy(child, call) for key, child in value.items()}

def _same(a, b, call):
    return json.dumps(_copy(a, call), sort_keys=True, separators=(",", ":"), allow_nan=False) == json.dumps(
        _copy(b, call), sort_keys=True, separators=(",", ":"), allow_nan=False)

def _freeze(value):
    # Script declarations are finite immutable literal carriers, never a parser.
    if type(value) in (list, tuple):
        return tuple(_freeze(child) for child in value)
    return value

class _ScriptInputError(ValueError):
    pass

class _Handle:
    pass

class _ProtocolCopyCall:
    def __init__(self, provider, inventory, check):
        self.provider, self.inventory, self.check = provider, inventory, check

    def tick(self):
        self.provider._tick(self.inventory, self.check)

    def need(self, condition, message):
        self.provider._need(condition, message)

class _ScriptProvider:
    """Protocol surrogate: finite explicit point memberships, no FPC authority."""
    VERSION = "FPC-POINT-FULL-FRAME-PROVIDER-v1"
    FEATURES = ("finite-full-kernel", "atomic-cursors", "rebind-classification", "dependency-rebind-classification")
    ProviderInputError = _ScriptInputError

    def __init__(self, scenario, query, call):
        self.scenario, self.query, self.call = scenario, query, call
        self.log, self.frames, self.serial = [], [], 0
        self.cleanup_error = None
        self.external_error = None

    def _new(self, inventory, kind):
        handle = _Handle()
        self.serial += 1
        handle.serial, handle.inventory, handle.kind = self.serial, inventory, kind
        return handle

    def _tick(self, inventory, check):
        if inventory is not None and inventory.fault is not None:
            raise inventory.fault
        try:
            check()
        except BaseException as error:
            if inventory is not None:
                inventory.fault = error
            raise

    def _need(self, value, text):
        if not value:
            error = _ScriptInputError(text)
            error._owner = _OWNER
            raise error

    def is_owned_error(self, error):
        return type(error) is _ScriptInputError and getattr(error, "_owner", None) is _OWNER

    def _members(self, n):
        # A/B/C/D/G are opaque SCRIPT marks, not formulas or trusted rules.
        # They are represented as typed core trees only to exercise the public
        # diagnostic surface; they do not assert FPC inference membership.
        A = ("pred", 0, ())
        B = ("not", A)
        C = ("all", 0, A)
        D = ("not", B)
        G = A
        if self.scenario == "schedule":
            return []
        if self.scenario == "dead":
            declarations = [("a", 0, ((0, A),)), ("c", 2, ((2, G),)), ("d", 2, ((2, G),))]
        elif self.scenario == "wait":
            declarations = [("a", 0, ((0, A),)), ("b", 1, ((0, B), (1, G))), ("c", 1, ((0, C), (1, G)))]
        elif self.scenario == "force":
            declarations = [("a", 0, ((0, A),)), ("b", 0, ((0, B),)), ("c", 1, ((0, C), (1, G)))]
        elif self.scenario in ("parent", "fuel"):
            declarations = [("a", 0, ((0, A),)), ("b", 0, ((0, B),)),
                            ("c", 1, ((0, C), (1, G))), ("d", 1, ((0, C), (1, G)))]
        elif self.scenario == "unaffected":
            declarations = [("a", 0, ((0, A),)), ("b", 0, ((0, B),)), ("c", 1, ((1, G),))]
        else:
            self._need(self.scenario == "refcount", "known scripted scenario")
            declarations = [("a", 0, ((0, A),)), ("b", 0, ((0, A),)),
                            ("c", 1, ((0, A), (1, C))),
                            ("d", 2, ((0, A), (1, C), (2, G))),
                            ("e", 2, ((0, A), (1, D), (2, G)))]
        return declarations

    def create_inventory(self, query_bytes, *, frame, modules, check):
        self._tick(None, check)
        if self.external_error is not None:
            raise self.external_error
        inv = self._new(None, "INVENTORY")
        inv.inventory, inv.fault, inv.closed = inv, None, False
        inv.n, inv.frame = frame["rows"], dict(frame)
        inv.model = {"schema": "FPC-point-model-identity-v1", "inventory_version": self.VERSION,
                     "query_hex": query_bytes.hex(), "query": self.query, "frame": frame}
        inv.members = []
        for index, (label, row, marks) in enumerate(self._members(inv.n)):
            self._tick(inv, check)
            member = self._new(inv, "CANDIDATE")
            member.label, member.row, member.witness = label, row, index
            member.marks = tuple(((r, 1), ("FPC", formula)) for r, formula in marks)
            member.formula = dict(marks)[row]
            inv.members.append(member)
        self.frames.append(dict(frame))
        self.log.append(("INVENTORY", inv.serial, dict(frame)))
        return inv

    def _key(self, member):
        return ("FPC-point-ground-key-v1", member.inventory,
                ("ROW", member.row), 0, None, member.witness,
                (((member.row, 0), (1, 1)),), member.marks)

    def _state(self, inv, parent, selected):
        state = self._new(inv, "STATE")
        state.parent, state.selected = parent, tuple(selected)
        marks = {(inv.n - 1, 1): (("FPC", _freeze(self.query["goal"])), 1)}
        for member in selected:
            for point, value in member.marks:
                old = marks.get(point)
                self._need(old is None or old[0] == value, "script marking conflict")
                marks[point] = (value, 1 if old is None else old[1] + 1)
        state.m = tuple((point, value, count) for point, (value, count) in sorted(marks.items()))
        state.keys = tuple(next((self._key(member) for member in selected if member.row == row), None)
                           for row in range(inv.n))
        state.t = tuple(((row, 0), (int(state.keys[row] is not None), 1)) for row in range(inv.n))
        return state

    def root_state(self, inventory, *, check):
        self._tick(inventory, check)
        state = self._state(inventory, None, ())
        self.log.append(("ROOT", state.serial))
        return state

    def state_section(self, state, *, check):
        self._tick(state.inventory, check)
        return ("FPC-point-state-section-v1", state.inventory, state.serial,
                state.parent, state.keys, state.t, state.m)

    def _legal(self, state, row):
        if state.keys[row] is not None:
            return []
        marks = {point: value for point, value, count in state.m}
        return [member for member in state.inventory.members if member.row == row
                and all(point not in marks or marks[point] == value for point, value in member.marks)]

    def place_state(self, state, candidate, *, check):
        self._tick(state.inventory, check)
        self._need(candidate.inventory is state.inventory and candidate in self._legal(state, candidate.row), "legal script placement")
        child = self._state(state.inventory, state, state.selected + (candidate,))
        self.log.append(("PLACE", state.serial, child.serial, candidate.row, candidate.label))
        return child

    def dependency_spec(self, inventory, point, *, check):
        self._tick(inventory, check)
        return {"cell": point, "formula_port_prefix": [0, point[0] + 1], "inventory_version": self.VERSION}

    def _projection(self, state, row):
        return (state.keys[:row + 1], state.t[:row + 1],
                tuple(item for item in state.m if item[0][1] == 1 and 0 <= item[0][0] <= row))

    def _cursor(self, state, point, kind):
        cursor = self._new(state.inventory, kind)
        cursor.state, cursor.point = state, point
        cursor.counts = {key: 0 for key in COUNTER_NAMES}
        cursor.witnesses, cursor.position, cursor.terminal = [], 0, False
        cursor.status, cursor.coverage = "UNRESOLVED", False
        cursor.branch, cursor.revision = None, None
        cursor.tried, cursor.outstanding = [], None
        cursor.initial, cursor.initial_tried = [], []
        cursor.delay = (1024 if self.scenario == "schedule" or
                        (self.scenario == "fuel" and state.selected) else
                        5 if (self.scenario == "wait" and point[0] == 1) or
                        (self.scenario == "dead" and point[0] == 2) else 0)
        return cursor

    def open_classification(self, state, point, *, remainder=None, check):
        self._tick(state.inventory, check)
        self._need(type(point) is tuple and len(point) == 2 and point[1] == 0
                   and type(point[0]) is int and 0 <= point[0] < state.inventory.n, "script point")
        cursor = self._cursor(state, point, "CLASSIFICATION")
        if remainder is not None:
            self._need(remainder.state is state and remainder.outstanding is None, "remainder parent/offer")
            cursor.branch, cursor.revision = remainder, remainder.revision
            cursor.tried = list(remainder.tried)
        self.log.append(("OPEN", state.serial, point[0], cursor.serial, remainder is not None))
        return cursor

    def _current(self, cursor, check):
        self._tick(cursor.inventory, check)
        if cursor.branch is not None:
            self._need(cursor.branch.revision == cursor.revision and cursor.branch.state is cursor.state,
                       "stale script remainder")

    def classification(self, cursor, *, check):
        self._current(cursor, check)
        return {"schema": "FPC-point-classification-v1", "kind": cursor.status,
                "coverage_complete": cursor.coverage, "witnesses": tuple(cursor.witnesses),
                "state_serial": cursor.state.serial, "point": cursor.point,
                "remainder_revision": cursor.revision, "counts": dict(cursor.counts)}

    def advance(self, cursor, *, check):
        self._current(cursor, check)
        self._need(not cursor.terminal and cursor.outstanding is None, "advance active cursor")
        candidate, offer, kind, action = None, None, "PENDING", "ENUMERATE"
        if cursor.delay:
            cursor.delay -= 1
        else:
            members = [item for item in self._legal(cursor.state, cursor.point[0]) if item.label not in cursor.tried]
            if cursor.kind == "BRANCH":
                if members:
                    candidate = members[0]
                    offer = self._new(cursor.inventory, "OFFER")
                    offer.branch, offer.candidate = cursor, candidate
                    cursor.outstanding = offer
                    cursor.counts["branch_offers"] += 1
                    self.log.append(("OFFER", cursor.state.serial, cursor.serial, offer.serial, candidate.label))
                else:
                    kind, action, cursor.terminal = "EOF", "EOF", True
            elif cursor.position < len(members):
                candidate = members[cursor.position]
                cursor.position += 1
                cursor.witnesses.append(candidate)
                cursor.counts["distinct_legal_inspected"] += 1
                if len(cursor.witnesses) == 2:
                    cursor.status, cursor.terminal = "MANY", True
            else:
                kind, action, cursor.terminal, cursor.coverage = "EOF", "EOF", True, True
                cursor.status = "SINGLE" if cursor.witnesses else "EMPTY"
                cursor.counts["fallback_eof_events"] += 1
        if candidate is not None:
            kind, action = "CANDIDATE", "EMIT"
        cursor.counts["committed_actions"] += 1
        if cursor.kind == "CLASSIFICATION" and cursor.terminal:
            self.log.append(("CLASSIFIED", cursor.state.serial, cursor.point[0], cursor.status))
        return {"schema": "FPC-point-provider-step-v1", "kind": kind, "committed": True,
                "action": action, "candidate": candidate, "offer": offer,
                "cursor_serial": cursor.serial, "state_serial": cursor.state.serial,
                "classification_kind": cursor.status if cursor.kind == "CLASSIFICATION" else None}

    def open_branch(self, state, point, *, classified, check):
        self._current(classified, check)
        self._need(classified.state is state and classified.status == "MANY" and classified.branch is None,
                   "initial MANY branch")
        branch = self._cursor(state, point, "BRANCH")
        branch.initial = list(classified.witnesses)
        branch.initial_tried = [False for unused in branch.initial]
        branch.delay, branch.revision = 0, 0
        self.log.append(("BRANCH", state.serial, point[0], branch.serial))
        return branch

    def reject_offer(self, branch_cursor, offer, *, check):
        self._current(branch_cursor, check)
        self._need(branch_cursor.outstanding is offer and offer.branch is branch_cursor, "owned exact offer")
        branch_cursor.tried.append(offer.candidate.label)
        branch_cursor.outstanding = None
        branch_cursor.revision += 1
        branch_cursor.counts["failed_children_recorded"] += 1
        branch_cursor.counts["tried_prefix_advances"] += 1
        branch_cursor.initial_tried = [item.label in branch_cursor.tried for item in branch_cursor.initial]
        self.log.append(("REJECT", branch_cursor.state.serial, branch_cursor.serial, offer.serial, offer.candidate.label))

    def rebind_classification(self, cursor, state, *, check):
        self._current(cursor, check)
        self._need(cursor.kind == "CLASSIFICATION" and cursor.inventory is state.inventory, "initial classifier inventory")
        if cursor.branch is not None:
            self._need(cursor.state is state, "remainder exact parent")
        self._need(self._projection(cursor.state, cursor.point[0]) == self._projection(state, cursor.point[0]),
                   "dependency projection")
        new = self._cursor(state, cursor.point, "CLASSIFICATION")
        for name in ("position", "terminal", "status", "coverage", "delay", "branch", "revision"):
            setattr(new, name, getattr(cursor, name))
        new.witnesses, new.tried, new.counts = list(cursor.witnesses), list(cursor.tried), dict(cursor.counts)
        self.log.append(("REBIND", cursor.state.serial, state.serial, cursor.point[0]))
        return new

    def candidate_record(self, candidate, *, check):
        self._tick(candidate.inventory, check)
        record = {"rule_tag": 0, "subtag": None, "witness": candidate.witness,
                  "formula": candidate.formula, "references": [],
                  "t": (((candidate.row, 0), (1, 1)),), "m": candidate.marks}
        record["key"] = ["FPC-point-ground-key-v1", candidate.inventory.model, ["ROW", candidate.row],
                         0, None, candidate.witness, record["t"], record["m"]]
        return _copy(record, _ProtocolCopyCall(self, candidate.inventory, check))

    def snapshot(self, handle, *, check):
        self._tick(handle.inventory, check)
        if handle.kind == "STATE":
            selected = [None] * handle.inventory.n
            for item in handle.selected:
                selected[item.row] = self.candidate_record(item, check=check)["key"]
            return _copy({"schema": "FPC-point-state-snapshot-v1", "model": handle.inventory.model,
                          "state_serial": handle.serial, "parent_serial": None if handle.parent is None else handle.parent.serial,
                          "selected_keys": selected, "t_items": handle.t, "m_items_with_refcounts": handle.m},
                         _ProtocolCopyCall(self, handle.inventory, check))
        return _copy({"schema": "FPC-point-cursor-snapshot-v1", "model": handle.inventory.model,
                      "cursor_serial": handle.serial, "kind": handle.kind, "parent_state_serial": handle.state.serial,
                      "point": handle.point, "phase": "SCRIPT", "inspection_frontier": None,
                      "canonical_scan_frontier": None, "canonical_tried_frontier": None,
                      "initial_shortcut_keys": [self.candidate_record(item, check=check)["key"] for item in handle.initial],
                      "initial_shortcut_tried": handle.initial_tried,
                      "outstanding_offer_serial": None if handle.outstanding is None else handle.outstanding.serial,
                      "remainder_revision": handle.revision, "terminal": handle.terminal, "counts": handle.counts},
                     _ProtocolCopyCall(self, handle.inventory, check))

    def export_candidate(self, state, *, check):
        self._tick(state.inventory, check)
        self._need(all(item is not None for item in state.keys), "complete scripted frame")
        self.log.append(("EXPORT", state.serial))
        return {"candidate_certificate_bytes": b"SCRIPT_PROTOCOL_ONLY_NOT_AN_FPC_CERTIFICATE",
                "receipt": {"accepted": False, "scope": "SCRIPTED protocol only; no logical membership"}}

    def close(self, handle):
        if handle is None:
            return
        self.log.append(("CLOSE", handle.kind, handle.serial))
        if self.cleanup_error is not None:
            raise self.cleanup_error

class _MatchedScriptProvider(_ScriptProvider):
    """Finite protocol catalogs only; never a logical inference provider."""
    def _members(self, n):
        A = ("pred", 0, ())
        B, C = ("not", A), ("all", 0, A)
        D, G = ("not", B), A
        if self.scenario == "dead-late":
            return [("a", 0, ((0, A),)), ("b", 1, ((1, A),)), ("c", 1, ((1, A),))]
        if self.scenario == "wait":
            return [("a", 0, ((0, A),)), ("b", 1, ((0, B), (1, G))),
                    ("c", 1, ((0, C), (1, G)))]
        if self.scenario == "row-ties":
            return [(x, row, ((row, G),)) for row, labels in
                    ((0, ("a", "b", "c")), (1, ("d", "e")), (2, ("f", "g"))) for x in labels]
        if self.scenario == "late-single":
            return [(x, row, ((row, G),)) for row, labels in
                    ((0, ("a", "b")), (1, ("c", "d")), (2, ("e",))) for x in labels]
        if self.scenario == "unaffected":
            return [("a", 0, ((0, A),)), ("b", 0, ((0, B),)), ("c", 1, ((1, G),))]
        if self.scenario == "refcount":
            return [("a", 0, ((0, A),)), ("b", 0, ((0, A),)),
                    ("c", 1, ((0, A), (1, C))), ("d", 2, ((0, A), (1, C), (2, G))),
                    ("e", 2, ((0, A), (1, D), (2, G)))]
        if self.scenario == "remainder":
            return [("a", 0, ((0, A),)), ("b", 0, ((0, B),)),
                    ("c", 1, ((0, B), (1, G))), ("d", 1, ((0, C), (1, G)))]
        if self.scenario == "fuel":
            return [("a", 0, ((0, A),)), ("b", 0, ((0, B),)),
                    ("c", 1, ((0, C), (1, G))), ("d", 1, ((0, C), (1, G)))]
        self._need(self.scenario == "schedule", "declared matched script")
        return []


class _ObservedProvider:
    """Pass-through public observation, same wrapper in both arms; no new legality."""
    def __init__(self, source, call):
        self.source, self.call = source, call
        self.actions, self.calls = [], []

    def __getattr__(self, name):
        value = getattr(self.source, name)
        if name.startswith("_") or not callable(value) or isinstance(value, type):
            return value
        def observed(*args, **kwargs):
            self.calls.append(("BEGIN", name))
            result = value(*args, **kwargs)
            self.calls.append(("RETURN", name))
            if name == "advance":
                self.call.need(type(result) is dict and result.get("action") in PUBLIC_ACTIONS,
                               "closed seven-category public Step.action")
                self.actions.append((result.get("kind"), result["action"]))
            return result
        return observed


def _canonical(value, call):
    return json.dumps(_copy(value, call), sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False, allow_nan=False)


def _digest(value, call):
    return hashlib.sha256(_canonical(value, call).encode()).hexdigest()


def _sink(arm):
    value = {key: 0 for key in DIAGNOSTIC_FIELDS}
    value.update(schema="matched-row-controller-diagnostics-v1", arm=arm, complete=False,
                 snapshot_available=False, phase_in_progress=False,
                 active_phase=None, raw_member_work_supported=False, raw_member_work=None)
    for key in ("active_frame_round", "active_frame_pair_index", "active_frame_ordinal",
                "active_frame_rows", "active_frame_syntax_nodes", "active_frame_limit"):
        value[key] = None
    return value


def _diagnostic(value, arm, call, result=None, fault=False):
    call.need(type(value) is dict and set(value) == set(DIAGNOSTIC_FIELDS), "exact fixed diagnostic keys")
    call.need(value["schema"] == "matched-row-controller-diagnostics-v1" and value["arm"] == arm,
              "diagnostic association")
    for key in ("complete", "snapshot_available", "phase_in_progress", "raw_member_work_supported"):
        call.need(type(value[key]) is bool, "strict diagnostic boolean")
    call.need(value["raw_member_work_supported"] is False and value["raw_member_work"] is None,
              "unsupported raw work is null, never zero")
    call.need(value["active_phase"] in (None, "INVENTORY", "ROOT", "DEPENDENCY", "LOAD", "REUSE", "SCAN",
              "CLASSIFY_OPEN", "CLASSIFY_ADVANCE", "FORCE_PLACE", "BRANCH_OPEN", "OFFER", "OFFER_PLACE",
              "BACKTRACK", "EXPORT"), "public diagnostic phase")
    exceptions = {"schema", "arm", "active_phase", "complete", "snapshot_available",
                  "phase_in_progress", "raw_member_work_supported", "raw_member_work"}
    for key in set(value) - exceptions:
        call.need(value[key] is None or type(value[key]) is int and value[key] >= 0,
                  "primitive nonnegative diagnostic scalar")
    if result is not None:
        call.need(value["complete"] is True and value["snapshot_available"] is True
                  and value["phase_in_progress"] is False, "normal complete diagnostic publication")
        call.need(value["active_atomic_steps_committed"] == 0
                  and value["completed_atomic_steps_committed"] == result["metrics"]["atomic_steps"]
                  and value["frames_completed"] == 1, "standalone frame folded once, no active double count")
        call.need(value["frames_fuel_limited"] == int(result["status"] == "UNKNOWN_FUEL")
                  and value["frames_exhausted"] == int(result["status"] == "EXHAUSTED_FRAME"),
                  "normal status counters")
    if fault:
        call.need(value["complete"] is False, "fault cannot complete diagnostic controller call")
    return _copy(value, call)


def _result(result, arm, call, status=None, fuel=None):
    call.need(type(result) is dict and set(result) == {"schema", "status", "frame", "accepted",
              "candidate_certificate_bytes", "export_receipt", "metrics", "trace", "trace_complete"},
              "exact frame result keys")
    call.need(result["schema"] == ("FPC-row-CSP-frame-search-v1" if arm == "C0" else "FPC-point-frame-search-v1")
              and result["accepted"] is False, "arm schema, never admission")
    call.need(result["status"] in ("CANDIDATE", "EXHAUSTED_FRAME", "UNKNOWN_FUEL"), "normal frame status")
    if status is not None:
        call.need(result["status"] == status, "literal expected frame status")
    metrics = result["metrics"]
    call.need(type(metrics) is dict and set(metrics) == {"atomic_steps", "callbacks", "state_creations",
        "classifier_opens", "classifier_advances", "domain_completions", "global_scans", "forced_moves",
        "branch_nodes", "offers", "backtracks", "reject_offers", "max_path_depth", "max_frontier",
        "classifiers_rebound", "domains_invalidated"}, "exact metrics")
    call.need(all(type(x) is int and x >= 0 for x in metrics.values()), "strict metric integers")
    if fuel is not None:
        call.need(metrics["atomic_steps"] <= fuel, "committed phase fuel bound")
    if result["status"] == "CANDIDATE":
        call.need(type(result["candidate_certificate_bytes"]) is bytes
                  and result["export_receipt"]["accepted"] is False, "unadmitted immutable export")
    else:
        call.need(result["candidate_certificate_bytes"] is None and result["export_receipt"] is None,
                  "no noncandidate positive prefix")
    call.need(type(result["trace"]) is list and result["trace_complete"] is True
              and result["trace"][-1]["kind"] == "TERMINAL", "bounded complete tiny trace")
    for event in result["trace"]:
        call.tick()
        call.need(type(event) is dict and event.get("kind") in EVENT_KEYS
                  and set(event) == EVENT_KEYS[event["kind"]], "exact public event keys")
        if event["kind"] == "DOMAIN":
            kind, witnesses = event["domain_kind"], event["witnesses"]
            call.need(kind in ("EMPTY", "SINGLE", "MANY"), "only terminal public domain event")
            call.need(len(witnesses) == {"EMPTY": 0, "SINGLE": 1, "MANY": 2}[kind],
                      "MANY exposes exactly two, never complete catalog")
            call.need(event["coverage_complete"] is (kind != "MANY"), "public terminal coverage")
        if event["kind"] == "DECISION" and event["status"] in ("FORCED", "BRANCH"):
            call.need(all(x["kind"] != "UNRESOLVED" for x in event["all_unfilled"]),
                      "no force or branch while global domain unresolved")
        if event["kind"] == "REJECT":
            call.need(event["reason"] in ("CHILD_DEAD", "CHILD_EXHAUSTED"), "complete child required for reject")
    return result


def _semantic_trace(trace, call):
    states, branches, offers = {}, {}, {}
    def number(value, table):
        if value is None:
            return None
        if value not in table:
            table[value] = len(table)
        return table[value]
    output = []
    for original in trace:
        call.tick()
        event = _copy(original, call)
        for key in ("state_serial", "parent_serial", "child_serial", "from_state_serial",
                    "restored_parent_serial", "failed_child_serial"):
            if key in event:
                event[key] = number(event[key], states)
        for key, table in (("branch_serial", branches), ("offer_serial", offers)):
            if key in event:
                event[key] = number(event[key], table)
        if event["kind"] == "STATE":
            snapshot = event["snapshot"]
            for key in ("state_serial", "parent_serial"):
                if key in snapshot:
                    snapshot[key] = number(snapshot[key], states)
        output.append(event)
    return output


def _script_run(controller, arm, scenario, query, query_bytes, modules, call, steps=None):
    raw = _MatchedScriptProvider(scenario, query, call)
    observed = _ObservedProvider(raw, call)
    rows = 3 if scenario in ("dead-late", "row-ties", "late-single", "refcount") else 2
    frame = {"schema": "FPC-point-frame-v1", "rows": rows, "syntax_nodes": 5}
    frozen = _canonical(frame, call)
    sink = _sink(arm)
    result = controller.search_frame(query_bytes, provider=observed, frame=frame,
        modules={key: modules[key] for key in ("checker", "builders")}, max_steps=steps,
        trace_limit=4096, diagnostics=sink, check=call.tick)
    call.need(_canonical(frame, call) == frozen and _same(frame, result["frame"], call), "frame immutable")
    _result(result, arm, call, fuel=steps)
    diagnostic = _diagnostic(sink, arm, call, result=result)
    return raw, observed, result, diagnostic


def _pair(controllers, scenario, query, query_bytes, modules, call, steps=None):
    records, outputs = {}, {}
    for arm, controller in controllers:
        raw, observed, result, diagnostic = _script_run(controller, arm, scenario, query, query_bytes, modules, call, steps)
        outputs[arm] = (raw, result)
        records[arm] = {"status": result["status"], "metrics": result["metrics"], "diagnostics": diagnostic,
            "trace": _semantic_trace(result["trace"], call), "actions": observed.actions,
            "provider_call_word": [name for stage, name in observed.calls if stage == "RETURN" and name != "close"]}
    call.need(_same(records["C0"]["trace"], records["G0"]["trace"], call), "matched semantic phase trace")
    call.need(_same(records["C0"]["actions"], records["G0"]["actions"], call), "matched public advance/action order")
    call.need(_same(records["C0"]["provider_call_word"], records["G0"]["provider_call_word"], call),
              "matched normally returned public service-call order, callback-free close excluded")
    return records, outputs


def _protocol_groups(controllers, query, query_bytes, modules, call):
    groups = []
    evidence = []
    for scenario in ("dead-late", "late-single"):
        pair, runs = _pair(controllers, scenario, query, query_bytes, modules, call)
        for arm, (raw, result) in runs.items():
            if scenario == "dead-late":
                _result(result, arm, call, "EXHAUSTED_FRAME")
                call.need(not any(x[0] in ("PLACE", "BRANCH", "REJECT") for x in raw.log), "global dead before singleton")
                call.need(next(e for e in result["trace"] if e["kind"] == "DECISION")["row"] == 2,
                          "literal late dead row")
            else:
                chosen = [e for e in result["trace"] if e["kind"] == "SELECT"]
                call.need(chosen[0]["row"] == 2 and chosen[0]["forced"] is True, "late singleton before early branch")
        evidence.append({"scenario": scenario, "arms": pair})
    groups.append({"id": CONTROL_IDS[0], "status": "PASSED", "evidence": evidence})
    evidence = []
    for scenario in ("wait", "row-ties"):
        pair, runs = _pair(controllers, scenario, query, query_bytes, modules, call)
        for raw, result in runs.values():
            call.need(next(x for x in raw.log if x[0] == "OPEN")[2] == 0, "first unresolved row by exact row order")
            if scenario == "wait":
                first = next(i for i, x in enumerate(raw.log) if x[0] == "PLACE")
                call.need(any(x[0] == "CLASSIFIED" and x[2] == 1 and x[3] == "MANY" for x in raw.log[:first]),
                          "resolve delayed other row before known singleton")
            else:
                first = next(e for e in result["trace"] if e["kind"] == "DECISION" and e["status"] == "BRANCH")
                call.need(first["row"] == 0, "earliest row, no hidden MRV")
        evidence.append({"scenario": scenario, "arms": pair})
    groups.append({"id": CONTROL_IDS[1], "status": "PASSED", "evidence": evidence,
        "scope": "Fresh API cannot inject preclassified cache; wait is the mirrored known-singleton/later-unresolved facet plus first-open0. Catalog degree3 is never forwarded as public MANY3."})
    evidence = []
    for scenario in ("unaffected", "refcount"):
        pair, runs = _pair(controllers, scenario, query, query_bytes, modules, call)
        for raw, result in runs.values():
            selects = [e for e in result["trace"] if e["kind"] == "SELECT"]
            if scenario == "unaffected":
                call.need(selects[0]["row"] == 1 and any(e["kind"] == "REUSE" and e["row"] == 0 for e in result["trace"]),
                          "keep unaffected earlier domain")
            else:
                call.need([e["row"] for e in selects[:2]] == [1, 2], "literal refcount chain")
                call.need(any(e["kind"] == "INVALIDATE" and e["row"] == 0
                    and e["from_state_serial"] == selects[0]["child_serial"]
                    and e["state_serial"] == selects[1]["child_serial"] for e in result["trace"]),
                    "same value changed refcount invalidates remote domain")
        evidence.append({"scenario": scenario, "arms": pair})
    groups.append({"id": CONTROL_IDS[2], "status": "PASSED", "evidence": evidence})
    pair, runs = _pair(controllers, "remainder", query, query_bytes, modules, call)
    for raw, result in runs.values():
        offers = [e for e in result["trace"] if e["kind"] == "OFFER"]
        rejects = [e for e in result["trace"] if e["kind"] == "REJECT"]
        selects = [e for e in result["trace"] if e["kind"] == "SELECT" and e["from_offer"]]
        call.need(len(offers) == 2 and len(rejects) == 1 and len(selects) == 2, "one dead child then successful remainder")
        call.need(offers[0]["branch_serial"] == offers[1]["branch_serial"]
                  and selects[1]["forced"] is True, "same branch owns SINGLE remainder")
        call.need(rejects[0]["offer_serial"] == offers[0]["offer_serial"]
                  and rejects[0]["restored_parent_serial"] == offers[0]["state_serial"]
                  and rejects[0]["failed_child_serial"] == selects[0]["child_serial"], "exact offer-child-parent association")
        parents = [e["snapshot"] for e in result["trace"] if e["kind"] == "STATE"
                   and e["state_serial"] == offers[0]["state_serial"]]
        call.need(parents and all(x is None for x in parents[0]["selected_keys"]), "restored root has no selected child")
        call.need(raw.log.count(next(x for x in raw.log if x[0] == "REJECT")) == 1, "no repeated/global rejection")
        call.need(sum(x[0] == "OPEN" and x[1] == offers[0]["state_serial"] and x[2] == 1 for x in raw.log) == 1,
                  "retain other parent row cache across child rollback")
    groups.append({"id": CONTROL_IDS[3], "status": "PASSED", "evidence": pair,
        "scope": "Child b reaches EXACT after its remaining singleton, not immediately after filling row0. No positive child rejected."})
    return groups
def _faults(controller, arm, query, query_bytes, modules, call):
    helpers = {key: modules[key] for key in ("checker", "builders")}
    frame = {"schema": "FPC-point-frame-v1", "rows": 2, "syntax_nodes": 5}
    try:
        controller.search_frame(query_bytes, provider=_MatchedScriptProvider("fuel", query, call),
            frame=frame, modules=helpers, max_steps=True, check=call.tick)
    except BaseException as error:
        if call.first is not None:
            raise call.first
        if not controller.is_owned_error(error):
            raise
        retained = error
    else:
        call.need(False, "strict bool fuel owned refusal needed for retained recipe")
    attrs, args = dict(vars(retained)), retained.args
    public = getattr(controller, "RowCSPInputError" if arm == "C0" else "FrameInputError")
    unowned = public("authored callback object")
    call.need(not controller.is_owned_error(unowned), "public refusal constructor is unowned")
    recipes = []
    for where, name, sentinel in (
        ("ENTRY", "RuntimeError", RuntimeError("first E")),
        ("ENTRY", "StopIteration", StopIteration("first E")),
        ("AFTER_CHILD", "RuntimeError", RuntimeError("first E")),
        ("AFTER_CHILD", "StopIteration", StopIteration("first E")),
        ("AFTER_CHILD", "GeneratorExit", GeneratorExit("first E")),
        ("AFTER_CHILD", "unowned-public", unowned),
        ("AFTER_CHILD", "retained-owned", retained),
        ("AFTER_CHILD", "E-before-cleanup-F", RuntimeError("first E"))):
        raw = _MatchedScriptProvider("fuel", query, call)
        sink = _sink(arm)
        raised, later = [False], [0]
        def intentional_check():
            if raised[0]:
                later[0] += 1
                raise RuntimeError("forbidden later callback F")
            call.tick()
            active = any(x[0] == "PLACE" for x in raw.log)
            if where == "ENTRY" or (active and sink["snapshot_available"] is True
                                     and sink["phase_in_progress"] is True):
                raised[0] = True
                if name == "E-before-cleanup-F":
                    raw.cleanup_error = RuntimeError("callback-free later cleanup F")
                raise sentinel
        try:
            controller.search_frame(query_bytes, provider=raw, frame=frame, modules=helpers,
                max_steps=None, trace_limit=4096, diagnostics=sink, check=intentional_check)
        except BaseException as error:
            if call.first is not None:
                raise call.first
            if error is not sentinel:
                raise
        else:
            call.need(False, "first fault must not become normal/fuel/negative result")
        call.need(raised[0] and later[0] == 0, "nonvacuous same-first E with no later callback")
        call.need(not any(x[0] == "REJECT" for x in raw.log), "cancellation never rejects an active offer")
        if where == "AFTER_CHILD":
            call.need(any(x[0] == "PLACE" for x in raw.log), "fault occurred after real scripted placement")
        if name == "E-before-cleanup-F":
            call.need(any(x[0] == "CLOSE" for x in raw.log), "later cleanup F actually attempted")
        if sentinel is retained:
            call.need(vars(retained) == attrs and retained.args == args, "retained genuine refusal data untouched")
        recipes.append({"where": where, "recipe": name, "same_object": True,
            "later_callback_count": later[0], "normal_result": False,
            "diagnostics": _diagnostic(sink, arm, call, fault=True),
            "cleanup_success_observed": False, "cleanup_F_exercised": name == "E-before-cleanup-F"})
    return recipes


def _schedule(controller, arm, query, query_bytes, modules, call):
    cases = []
    expected_frames = [{"schema": "FPC-point-frame-v1", "rows": n, "syntax_nodes": b}
                       for n, b in ((1, 1), (1, 1), (1, 2), (1, 1), (1, 2), (2, 1))]
    for rounds in (0, 3):
        raw = _MatchedScriptProvider("schedule", query, call)
        sink = _sink(arm)
        result = controller.search_dovetail(query_bytes, provider=_ObservedProvider(raw, call),
            modules={key: modules[key] for key in ("checker", "builders")}, max_rounds=rounds,
            diagnostics=sink, check=call.tick)
        call.need(type(result) is dict and set(result) == {"schema", "status", "accepted",
            "candidate_certificate_bytes", "export_receipt", "metrics", "last_frame"}, "exact dovetail return")
        call.need(result["schema"] == ("FPC-row-CSP-dovetail-search-v1" if arm == "C0" else "FPC-point-dovetail-search-v1")
            and result["status"] == "UNKNOWN_ROUND_LIMIT" and result["accepted"] is False
            and result["candidate_certificate_bytes"] is None and result["export_receipt"] is None,
            "normal bounded schedule, no proof or nonprovability")
        m = result["metrics"]
        call.need(m["rounds_completed"] == rounds, "round boundary")
        diag = _diagnostic(sink, arm, call)
        call.need(diag["complete"] is True and diag["snapshot_available"] is True
                  and diag["phase_in_progress"] is False and diag["active_atomic_steps_committed"] == 0,
                  "normal schedule completes and folds active exactly once")
        if rounds == 0:
            call.need(not raw.frames and m["frame_runs"] == 0 and result["last_frame"] is None
                      and diag["frames_completed"] == 0, "zero rounds no fake frame")
        else:
            call.need(_same(raw.frames, expected_frames, call) and m["frame_runs"] == 6
                      and m["frame_atomic_steps"] == m["sum_frame_limits"] == 11
                      and m["frames_fuel_limited"] == 6 and m["frames_exhausted"] == 0,
                      "literal fair prefix/restart phase budgets")
            call.need(diag["frames_completed"] == diag["frames_fuel_limited"] == 6
                      and diag["completed_atomic_steps_committed"] == 11, "completed plus active has no double count")
            call.need(_same(result["last_frame"], {"round": 3, "pair_index": 3,
                "frame": expected_frames[-1], "max_steps": 1, "status": "UNKNOWN_FUEL", "atomic_steps": 1}, call),
                "last frame exact public association")
        cases.append({"rounds": rounds, "metrics": m, "diagnostics": diag, "frames": raw.frames,
                      "last_frame": result["last_frame"]})
    return cases


def _fifth_group(controllers, query, query_bytes, modules, call):
    fuel_cases = []
    for fuel in (0, 1, 2, 64):
        pair, runs = _pair(controllers, "fuel", query, query_bytes, modules, call, steps=fuel)
        for arm, (raw, result) in runs.items():
            _result(result, arm, call, "UNKNOWN_FUEL", fuel)
            call.need(not any(x[0] == "REJECT" for x in raw.log), "fuel never failed child")
            if fuel == 64:
                terminal = result["trace"][-1]
                call.need(terminal["phase"] == "CLASSIFY_ADVANCE" and terminal["outstanding_offers"] > 0
                    and any(x[0] == "PLACE" for x in raw.log), "fixed phase-bound nonvacuous child cutoff")
        fuel_cases.append({"fuel": fuel, "arms": pair})
    arms = {}
    for arm, controller in controllers:
        arms[arm] = {"faults": _faults(controller, arm, query, query_bytes, modules, call),
                     "dovetail": _schedule(controller, arm, query, query_bytes, modules, call)}
    return {"id": CONTROL_IDS[4], "status": "PASSED", "fuel": fuel_cases, "arms": arms,
        "scope": "Fixed scalar sink observations only; no worker postfault copy, heap census, all-cutoff sweep or cleanup-success qualification."}


def _encode(query, encoder, checker, call):
    literal = _copy(query, call)
    before = _canonical(literal, call)
    encoded = encoder.encode_tiny_declared_query(literal, check=call.tick)
    call.need(type(encoded) is dict and type(encoded.get("query_bytes")) is bytes, "immutable tiny query bytes")
    parsed = checker.decode_query(encoded["query_bytes"], check=call.tick)
    call.need(_canonical(literal, call) == before, "encoder did not mutate literal query")
    for key, value in literal.items():
        call.need(_same(parsed[key], value, call), "same bytes decoded to every unchanged literal field")
    call.need(parsed["EOF"] == len(encoded["query_bytes"]), "exact query EOF")
    return encoded["query_bytes"]


def _member_match(rows, option, call):
    if len(rows) != len(option):
        return False
    for index, (row, member) in enumerate(zip(rows, option)):
        call.tick()
        witness = row["witness"]
        if row["rule_tag"] == 0 or (row["rule_tag"] == 2 and row["subtag"] == 0):
            call.need(type(witness) in (list, tuple) and len(witness) == 1, "single-index physical payload")
            witness = witness[0]
        if not (row["index"] == index and row["rule_tag"] == member["rule_tag"]
                and row["subtag"] == member["subtag"] and _same(row["formula"], member["formula"], call)
                and _same(witness, member["witness"], call)):
            return False
    return True


def _real_case(controllers, provider, fixture, count, row_oracle, frame_oracle, encoder, modules, call):
    query, frame = fixture["literal_query"], fixture["frame"]
    query_bytes = _encode(query, encoder, modules["checker"], call)
    expected = frame_oracle.enumerate_literal_frame_completions(query, frame, row_oracle=row_oracle, check=call.tick)
    call.need(expected["complete"] is True and type(expected["solution_count"]) is int
              and expected["solution_count"] == count and len(expected["solutions"]) == count,
              "literal independent complete Cartesian count")
    arms, outputs, certs = {}, {}, {}
    for arm, controller in controllers:
        wrapped, sink = _ObservedProvider(provider, call), _sink(arm)
        frozen = _canonical(frame, call)
        result = controller.search_frame(query_bytes, provider=wrapped, frame=_copy(frame, call),
            modules={key: modules[key] for key in ("checker", "builders")}, max_steps=None,
            trace_limit=4096, diagnostics=sink, check=call.tick)
        _result(result, arm, call, "CANDIDATE" if count else "EXHAUSTED_FRAME")
        call.need(_canonical(frame, call) == frozen, "literal real frame unchanged")
        evidence = {"status": result["status"], "metrics": result["metrics"],
                    "trace": _semantic_trace(result["trace"], call),
                    "diagnostics": _diagnostic(sink, arm, call, result=result), "actions": wrapped.actions,
                    "provider_call_word": [name for stage, name in wrapped.calls if stage == "RETURN" and name != "close"]}
        if count:
            cert = result["candidate_certificate_bytes"]
            subject = modules["checker"].check_certificate(query_bytes, cert, check=call.tick)
            reference = modules["reference"].reference_check_certificate(query_bytes, cert, check=call.tick)
            call.need(subject["status"] == "VALID_DERIVATION" and subject["complete"] is True
                and subject["accepted"] is True and subject["final_goal_equal"] is True, "same-byte subject complete fixture gate")
            call.need(reference["status"] == "VALID_DERIVATION" and reference["complete_check"] is True
                and reference["final_goal_equal"] is True, "same-byte independent reference fixture gate")
            rows = subject["certificate"]["rows"]
            call.need(any(_member_match(rows, option, call) for option in expected["solutions"]),
                      "first exported rows belong to complete independent solution set")
            evidence.update(subject=subject, reference=reference,
                certificate_identity={"bytes": len(cert), "sha256": hashlib.sha256(cert).hexdigest()})
            certs[arm] = cert
        arms[arm], outputs[arm] = evidence, result
    call.need(_same(arms["C0"]["trace"], arms["G0"]["trace"], call), "real matched semantic decisions")
    call.need(_same(arms["C0"]["actions"], arms["G0"]["actions"], call), "real matched public advance order")
    call.need(_same(arms["C0"]["provider_call_word"], arms["G0"]["provider_call_word"], call),
              "real matched returned provider-call order")
    if count:
        call.need(certs["C0"] == certs["G0"], "same first immutable candidate bytes")
    return {"fixture": fixture["id"], "oracle": expected, "arms": arms,
            "scope": "Authored tiny qualification input; oracle counts all, each controller returns first only."}, outputs


def _real_groups(controllers, provider, fixtures, row_oracle, frame_oracle, encoder, modules, call):
    evidence = []
    for name, count in (("duplicate-base", 4), ("goal-outside", 0)):
        fixture = fixtures[name]
        members = row_oracle.enumerate_tiny_row_members(fixture["literal_query"], fixture["frame"], 0, check=call.tick)
        call.need(members["complete"] is True and len(members["members"]) == count, "complete literal row domain")
        if count:
            descriptors = [_canonical([x["rule_tag"], x["subtag"], x["witness"]], call) for x in members["members"]]
            wanted = [_canonical(x, call) for x in ((0, None, 0), (0, None, 1), (2, 0, 0), (2, 0, 1))]
            call.need(len(set(descriptors)) == 4 and set(descriptors) == set(wanted), "four distinct HYP/table identities, no formula quotient")
        record, outputs = _real_case(controllers, provider, fixture, count, row_oracle, frame_oracle, encoder, modules, call)
        record["independent_row_domain"] = members
        evidence.append(record)
    result = [{"id": CONTROL_IDS[5], "status": "PASSED", "evidence": evidence,
        "scope": "Public drivers first candidate/MANY2 only; complete provider positive-domain enumeration remains separate old tiny10 scope."}]
    evidence = []
    for name, count in (("E1-single", 1), ("E1-two-row-reuse", 4)):
        record, outputs = _real_case(controllers, provider, fixtures[name], count, row_oracle, frame_oracle, encoder, modules, call)
        if name == "E1-two-row-reuse":
            row0 = row_oracle.enumerate_tiny_row_members(fixtures[name]["literal_query"], fixtures[name]["frame"], 0, check=call.tick)
            call.need(len(row0["members"]) == 4, "independent E1 row0 four terms")
            wanted = {_canonical(x, call) for x in fixtures[name]["expected_row0_E1_terms"]}
            actual = set()
            for member in row0["members"]:
                call.need(member["rule_tag"] == 1 and member["subtag"] == 6 and len(member["witness"]) == 1,
                          "tiny row0 only E1")
                actual.add(_canonical(member["witness"][0], call))
            call.need(actual == wanted, "literal E1 term identity set, not assumed provider order")
            for output in outputs.values():
                trace = output["trace"]
                chosen = [e for e in trace if e["kind"] == "SELECT"]
                first = chosen[0]
                call.need(len(chosen) == 2 and first["row"] == 1 and first["forced"] is True
                    and first["from_offer"] is False and chosen[1]["row"] == 0
                    and chosen[1]["from_offer"] is True, "real later singleton then earliest branch")
                call.need(any(e["kind"] == "REUSE" and e["row"] == 0 and e["from_state_serial"] == first["parent_serial"]
                    and e["state_serial"] == first["child_serial"] for e in trace), "real unchanged prefix is retained")
                call.need(output["metrics"]["classifier_opens"] == 2
                          and output["metrics"]["classifiers_rebound"] >= 1, "no unnecessary earlier domain restart")
            for arm in ("C0", "G0"):
                call.need(any(action == "NORMALIZE" for kind, action in record["arms"][arm]["actions"]),
                          "nonvacuous public normalization category in both real arms")
            record["independent_row0_domain"] = row0
        evidence.append(record)
    result.append({"id": CONTROL_IDS[6], "status": "PASSED", "evidence": evidence})
    evidence = []
    for name, members_count in (("Gamma-block-zero", 0), ("Gamma-allow-one", 2)):
        fixture = fixtures[name]
        row = row_oracle.enumerate_tiny_row_members(fixture["literal_query"], fixture["frame"], 2, check=call.tick)
        call.need(row["complete"] is True and len(row["members"]) == members_count, "full Gamma guarded final row count")
        record, outputs = _real_case(controllers, provider, fixture, 0, row_oracle, frame_oracle, encoder, modules, call)
        for output in outputs.values():
            trace = output["trace"]
            if members_count == 0:
                call.need(not any(e["kind"] == "SELECT" for e in trace), "full Gamma blocks before any forced/branch selection")
            else:
                call.need(any(e["kind"] == "INVALIDATE" and e["row"] <= 1 for e in trace)
                          and any(e["kind"] == "REJECT" for e in trace), "remote marks cause genuine child contradiction/backtrack")
        record["independent_final_row_domain"] = row
        evidence.append(record)
    result.append({"id": CONTROL_IDS[7], "status": "PASSED", "evidence": evidence})
    return result


def _run_matched_controls(csp_controller, point_controller, *, provider, fixtures,
        declarations, row_oracle, frame_oracle, encoder, modules, call):
    """Additional8 only. No normal partial return; no current result exists."""
    call.tick()
    call.need(type(modules) is dict and set(modules) == {"checker", "builders", "reference"}, "exact helper roles")
    call.need(_digest(fixtures, call) == FIXTURE_CANONICAL_SHA256
              and fixtures["control_ids"] == list(CONTROL_IDS), "complete exact independent matched declarations")
    call.need(_digest(declarations, call) == TINY_CANONICAL_SHA256, "unchanged original tiny7 inputs")
    call.need(provider.VERSION == "FPC-POINT-FULL-FRAME-PROVIDER-v1"
              and provider.IMPLEMENTATION_REVISION == "FPC-POINT-FULL-FRAME-PROVIDER-implementation-v6",
              "exact current provider6 subject")
    call.need(csp_controller.VERSION == "FPC-ROW-CSP-CONTROLLER-v1"
              and point_controller.VERSION == "FPC-POINT-FRAME-CONTROLLER-v2", "exact public C0/G0 program binding")
    controllers = (("C0", csp_controller), ("G0", point_controller))
    for arm, controller in controllers:
        call.need(type(controller.DIAGNOSTIC_FIELDS) is tuple
                  and controller.DIAGNOSTIC_FIELDS == DIAGNOSTIC_FIELDS, "exact public diagnostic field tuple")
    fixed_inputs = _canonical([fixtures, declarations], call)
    real = {x["id"]: x for x in fixtures["real_input_projections"]}
    original = {x["id"]: x for x in declarations["fixtures"]}
    for name in ("duplicate-base", "E1-single", "Gamma-block-zero", "Gamma-allow-one", "goal-outside"):
        call.need(_same(real[name]["literal_query"], original[name]["query"], call)
                  and _same(real[name]["frame"], original[name]["frame"], call), "same old literal query/frame, not result uptake")
    call.need(_same(real["E1-two-row-reuse"]["literal_query"], original["E1-single"]["query"], call)
              and _same(real["E1-two-row-reuse"]["frame"], {"schema": "FPC-point-frame-v1", "rows": 2, "syntax_nodes": 3}, call),
              "exact separate controller-only two-row facet")
    query = real["duplicate-base"]["literal_query"]
    query_bytes = _encode(query, encoder, modules["checker"], call)
    rows = _protocol_groups(controllers, query, query_bytes, modules, call)
    rows.append(_fifth_group(controllers, query, query_bytes, modules, call))
    rows.extend(_real_groups(controllers, provider, real, row_oracle, frame_oracle, encoder, modules, call))
    call.need([x["id"] for x in rows] == list(CONTROL_IDS) and all(x["status"] == "PASSED" for x in rows),
              "complete exact ordered eight groups")
    call.need(_canonical([fixtures, declarations], call) == fixed_inputs, "all literal inputs unchanged")
    return {"schema": RETURN_SCHEMA, "version": VERSION, "population": POPULATION, "complete": True,
        "control_ids": list(CONTROL_IDS), "controls": _copy(rows, call),
        "counts": {"groups": 8, "passed": 8, "failed": 0},
        "scope": "Five protocol-only groups plus three real tiny-provider6 groups. First candidate only; independent Cartesian sets count all. Additional8, original184/six/ten caps unchanged. No target theorem, learning, performance or Root admission claim."}


def run_matched_controller_controls(csp_controller, point_controller, *, provider, fixtures,
        declarations, row_oracle, frame_oracle, encoder, modules, check):
    """First genuine callback fault wins, including generator-wrapped StopIteration."""
    call = _Call(check)
    try:
        result = _run_matched_controls(csp_controller, point_controller, provider=provider,
            fixtures=fixtures, declarations=declarations, row_oracle=row_oracle, frame_oracle=frame_oracle,
            encoder=encoder, modules=modules, call=call)
        if call.first is not None:
            raise call.first
        return result
    except BaseException:
        if call.first is not None:
            raise call.first
        raise
