"""Independent selector qualification Source; run only in a reviewed once actual.

No import-time fixture, selector, encoder, checker, search or file access. Literal
formulas below are qualification inputs, never selected donor/holdout outputs.
The production selector must not be read before this bank is frozen.
"""

VERSION = "L-two-donor-input-selector-controls-v1"
RETURN_SCHEMA = "independent-two-donor-input-selector-controls-v1"
POPULATION = "selector6"
CONTROL_IDS = (
    "selector-tree-order", "selector-atom-renaming",
    "selector-Boolean-eligibility", "selector-single-axiom-exclusion",
    "selector-distinct-prefix-and-stop", "selector-envelope-and-first-fault",
)


class SelectorControlError(ValueError):
    pass


class _Call:
    def __init__(self, check):
        self.check = check
        self.first = None

    def tick(self):
        if self.first is not None:
            raise self.first
        try:
            self.check()
        except BaseException as error:
            self.first = error
            raise

    def need(self, condition, message):
        if self.first is not None:
            raise self.first
        if not condition:
            raise SelectorControlError(message)


def _copy(value, call):
    call.tick()
    if type(value) in (list, tuple):
        return [_copy(child, call) for child in value]
    if type(value) is dict:
        call.need(all(type(key) is str for key in value), "ordinary record keys")
        return {key: _copy(child, call) for key, child in value.items()}
    call.need(value is None or type(value) in (str, int, bool), "ordinary selector evidence")
    return value


def _equal(left, right, call):
    call.tick()
    if type(left) in (list, tuple) or type(right) in (list, tuple):
        if type(left) not in (list, tuple) or type(right) not in (list, tuple) or len(left) != len(right):
            return False
        for a, b in zip(left, right):
            call.tick()
            if not _equal(a, b, call):
                return False
        return True
    if type(left) is dict or type(right) is dict:
        if type(left) is not dict or type(right) is not dict or set(left) != set(right):
            return False
        for key in left:
            call.tick()
            if not _equal(left[key], right[key], call):
                return False
        return True
    return type(left) is type(right) and left == right


def _oracle_tree(raw, call):
    """Fresh normal form from independent recursive grammar, not selector output."""
    names = {}

    def visit(tree, depth):
        call.tick()
        call.need(depth <= 32 and type(tree) in (list, tuple) and bool(tree), "reference tree carrier")
        tag = tree[0]
        if tag == "pred":
            call.need(len(tree) == 3 and type(tree[1]) is int and 0 <= tree[1] <= 2,
                      "reference atom ID")
            call.need(type(tree[2]) in (list, tuple) and len(tree[2]) == 0, "reference nullary atom")
            if tree[1] not in names:
                names[tree[1]] = len(names)
            atom = names[tree[1]]
            return ["pred", atom, []], 1, 0, [0, atom]
        if tag == "not":
            call.need(len(tree) == 2, "reference not arity")
            body, count, level, tokens = visit(tree[1], depth + 1)
            return ["not", body], count + 1, level + 1, [1] + tokens
        call.need(tag == "imp" and len(tree) == 3, "reference implication")
        a, na, da, ta = visit(tree[1], depth + 1)
        b, nb, db, tb = visit(tree[2], depth + 1)
        return ["imp", a, b], 1 + na + nb, 1 + max(da, db), [2] + ta + tb

    tree, count, depth, tokens = visit(raw, 0)
    call.need(count <= 256, "reference helper size")
    return tree, count, depth, tokens, len(names)


def _truth(tree, mask, atoms, call):
    call.tick()
    if tree[0] == "pred":
        return bool((mask >> (atoms - 1 - tree[1])) & 1)
    if tree[0] == "not":
        return not _truth(tree[1], mask, atoms, call)
    left = _truth(tree[1], mask, atoms, call)
    right = _truth(tree[2], mask, atoms, call)
    return (not left) or right


def _match(pattern, value, bindings, call):
    call.tick()
    if type(pattern) is str:
        if pattern in bindings:
            return _equal(bindings[pattern], value, call)
        bindings[pattern] = _copy(value, call)
        return True
    if type(value) not in (list, tuple) or len(pattern) != len(value):
        return False
    if pattern[0] != value[0]:
        return False
    for index in range(1, len(pattern)):
        call.tick()
        if not _match(pattern[index], value[index], bindings, call):
            return False
    return True


def _oracle_inspect(raw, call):
    tree, count, depth, tokens, atoms = _oracle_tree(raw, call)
    values = []
    for mask in range(1 << atoms):
        call.tick()
        values.append(_truth(tree, mask, atoms, call))
    patterns = (
        ["imp", "A", ["imp", "B", "A"]],
        ["imp", ["imp", "A", ["imp", "B", "C"]],
         ["imp", ["imp", "A", "B"], ["imp", "A", "C"]]],
        ["imp", ["imp", ["not", "B"], ["not", "A"]], ["imp", "A", "B"]],
    )
    matches = []
    for number, pattern in enumerate(patterns):
        call.tick()
        if _match(pattern, tree, {}, call):
            matches.append(number)
    tautology = all(values)
    return {"schema": "two-donor-formula-inspection-v1", "complete": True,
            "canonical_goal": tree, "tokens": tokens, "expanded_nodes": count,
            "depth": depth, "atom_count": atoms, "truth_values": values,
            "tautology": tautology, "single_axiom_subtags": matches,
            "eligible": count > 1 and tautology and not matches}


def _inspect(selector, raw, call):
    before = _copy(raw, call)
    expected = _oracle_inspect(raw, call)
    actual = selector.inspect_formula(raw, check=call.tick)
    call.need(type(actual) is dict and set(actual) == set(expected), "inspection exact fields")
    for key in ("complete", "tautology", "eligible"):
        call.need(type(actual[key]) is bool, "inspection strict bool")
    for key in ("expanded_nodes", "depth", "atom_count"):
        call.need(type(actual[key]) is int, "inspection strict int")
    call.need(type(actual["truth_values"]) is list and
              all(type(value) is bool for value in actual["truth_values"]), "truth vector bools")
    call.need(type(actual["tokens"]) is list and
              all(type(value) is int for value in actual["tokens"]), "prefix exact ints")
    call.need(type(actual["single_axiom_subtags"]) is list and
              all(type(value) is int for value in actual["single_axiom_subtags"]), "subtags exact ints")
    call.need(_equal(actual, expected, call), "independent formula inspection")
    call.need(_equal(raw, before, call), "inspection input immutability")
    return actual


def _next_tree(cursor, call):
    """Independent streaming prefix grammar: pending slots plus restricted-growth IDs.

    The DFS chooses structural tokens in order, with a fixed expanded-node budget.
    It does not call the selector or reuse a selected tree as its generator seed.
    """
    while cursor["nodes"] <= 11:
        call.tick()
        if not cursor["stack"]:
            if cursor["started"]:
                cursor["nodes"] += 1
                if cursor["nodes"] > 11:
                    return None
            cursor["started"] = True
            cursor["stack"] = [(cursor["nodes"], 1, 0, [])]
        remaining, pending, seen, headers = cursor["stack"].pop()
        if remaining == 0:
            call.need(pending == 0, "reference grammar closure")
            built = []
            for header in reversed(headers):
                call.tick()
                if header[0] == 0:
                    built.append(["pred", header[1], []])
                elif header[0] == 1:
                    built.append(["not", built.pop()])
                else:
                    left = built.pop()
                    right = built.pop()
                    built.append(["imp", left, right])
            call.need(len(built) == 1, "reference prefix parse")
            return built[0]
        choices = []
        for atom in range(min(seen, 2) + 1):
            call.tick()
            if pending - 1 <= remaining - 1 and (pending != 1 or remaining == 1):
                choices.append((remaining - 1, pending - 1, max(seen, atom + 1),
                                headers + [(0, atom)]))
        if pending <= remaining - 1:
            choices.append((remaining - 1, pending, seen, headers + [(1,)]))
        if pending + 1 <= remaining - 1:
            choices.append((remaining - 1, pending + 1, seen, headers + [(2,)]))
        for choice in reversed(choices):
            call.tick()
            cursor["stack"].append(choice)
    return None


def _subtree_tokens(tree, call):
    found = []
    stack = list(tree[1:]) if tree[0] in ("not", "imp") else []
    while stack:
        call.tick()
        child = stack.pop()
        found.append(_oracle_tree(child, call)[3])
        if child[0] in ("not", "imp"):
            stack.extend(child[1:])
    return found


def _query(info, call):
    return {"version": 1, "claim_mode": 0, "function_arities": [],
            "predicate_arities": [0, 0, 0], "theory_profile": 0,
            "finite_axioms": [], "Gamma": [], "goal": _copy(info["canonical_goal"], call)}


def _selection(selector, call):
    actual = selector.select_inputs(check=call.tick)
    call.need(type(actual) is dict and set(actual) == {"schema", "status", "complete", "slots", "prefix", "scope"}
              and actual.get("schema") == "two-donor-input-only-selection-v1",
              "selection schema")
    call.need(actual.get("complete") is True and actual.get("status") in
              ("SELECTED", "STOP_INPUT_CENSUS"), "selection complete status")
    prefix = actual.get("prefix")
    call.need(type(prefix) is list and bool(prefix), "complete explicit prefix")
    cursor = {"nodes": 1, "started": False, "stack": []}
    donors = []
    holdout = None
    chosen = {}
    previous_order = None
    for rank, row in enumerate(prefix):
        call.tick()
        call.need(type(row) is dict and set(row) == {"rank", "tokens", "expanded_nodes", "depth",
                  "truth_values", "tautology", "single_axiom_subtags", "eligible", "reason"}
                  and type(row.get("rank")) is int and row["rank"] == rank,
                  "contiguous prefix rank")
        tree = _next_tree(cursor, call)
        call.need(tree is not None, "prefix inside fixed language")
        info = _oracle_inspect(tree, call)
        for key in ("tokens", "expanded_nodes", "depth", "truth_values", "tautology",
                    "single_axiom_subtags", "eligible"):
            call.need(key in row and _equal(row[key], info[key], call), "full prefix property " + key)
        call.need(type(row["expanded_nodes"]) is int and type(row["depth"]) is int and
                  type(row["tautology"]) is bool and type(row["eligible"]) is bool,
                  "prefix strict scalar types")
        order = (info["expanded_nodes"], tuple(info["tokens"]))
        call.need(previous_order is None or previous_order < order, "strict prefix order")
        previous_order = order
        call.need(len(donors) == 2 or info["expanded_nodes"] <= 7,
                  "missing donor must stop at bound")
        if info["expanded_nodes"] == 1:
            reason = "ATOMIC"
        elif not info["tautology"]:
            reason = "NOT_TAUTOLOGY"
        elif info["single_axiom_subtags"]:
            reason = "SINGLE_AXIOM"
        elif len(donors) < 2:
            if info["depth"] <= 3 and info["expanded_nodes"] <= 7:
                name = "donor" + str(len(donors))
                reason = name.upper()
                call.need(all(info["tokens"] != prior["tokens"] for prior in donors),
                          "distinct canonical donor identity")
                donors.append(info)
                chosen[name] = info
            else:
                reason = "DONOR_BOUNDS"
        elif holdout is None:
            minimum_nodes = max(value["expanded_nodes"] for value in donors) + 2
            minimum_depth = max(value["depth"] for value in donors)
            forbidden = [value["tokens"] for value in donors]
            for donor in donors:
                forbidden.extend(_subtree_tokens(donor["canonical_goal"], call))
            if info["expanded_nodes"] < minimum_nodes or info["depth"] <= minimum_depth:
                reason = "HOLDOUT_BOUNDS"
            elif info["tokens"] in forbidden:
                reason = "HOLDOUT_SUBTREE"
            else:
                reason = "HOLDOUT0"
                holdout = info
                chosen["holdout0"] = info
                call.need(rank == len(prefix) - 1, "stop after first holdout prefix")
        else:
            call.need(False, "no candidate after holdout")
        call.need(row["reason"] == reason, "closed exact prefix reason")
    if len(donors) == 2 and holdout is not None:
        call.need(actual["status"] == "SELECTED", "complete eligible slots cannot STOP")
        slots = actual.get("slots")
        call.need(type(slots) is dict and set(slots) == {"donor0", "donor1", "holdout0"},
                  "three exact input slots")
        for name in ("donor0", "donor1", "holdout0"):
            call.tick()
            slot = slots[name]
            call.need(type(slot) is dict and set(slot) ==
                      {"query", "tokens", "expanded_nodes", "depth", "atom_count", "truth_values"},
                      "slot exact fields")
            info = chosen[name]
            for key in ("tokens", "expanded_nodes", "depth", "atom_count", "truth_values"):
                call.need(_equal(slot[key], info[key], call), "slot prefix association " + key)
            call.need(_equal(slot["query"], _query(info, call), call), "complete semantic query")
            for key in ("version", "claim_mode", "theory_profile"):
                call.need(type(slot["query"][key]) is int, "query strict integer")
        return actual, {name: _copy(info["tokens"], call) for name, info in chosen.items()}
    call.need(actual["status"] == "STOP_INPUT_CENSUS" and actual.get("slots") is None,
              "missing slot has no partial authority")
    following = _next_tree(cursor, call)
    if len(donors) < 2:
        call.need(following is None or _oracle_tree(following, call)[1] > 7, "complete donor bound")
    else:
        call.need(following is None, "complete holdout bound")
    return actual, {}


def _owned_refusal(selector, call):
    error = None
    raw = ["pred", True, []]
    before = _copy(raw, call)
    try:
        selector.inspect_formula(raw, check=call.tick)
    except BaseException as caught:
        error = caught
    call.need(error is not None and selector.is_owned_error(error), "owned bool-ID refusal")
    call.need(_equal(raw, before, call), "refusal input unchanged")
    return error


def _fault(selector, entry, error, call):
    callbacks = 0
    after_fault = 0
    caught = None
    args = error.args
    attributes = dict(vars(error))
    later = RuntimeError("selector control later callback must not replace first")

    def callback():
        nonlocal callbacks, after_fault
        if callbacks:
            after_fault += 1
            raise later
        call.tick()
        callbacks += 1
        raise error

    try:
        if entry == "inspect_formula":
            selector.inspect_formula(["not", ["pred", 0, []]], check=callback)
        else:
            selector.select_inputs(check=callback)
    except BaseException as value:
        caught = value
    call.need(callbacks == 1 and after_fault == 0 and caught is error,
              "public first callback identity/no later callback")
    call.need(error.args == args and dict(vars(error)) == attributes, "foreign attributes unchanged")
    return {"entry": entry, "exception_class": type(error).__name__, "first_object_preserved": True,
            "prefault_callbacks": callbacks, "postfault_callbacks": after_fault,
            "cleanup_observed": False}


def run_selector_controls(selector, *, check):
    """Six additive groups. Runtime only within exact future whole qualification."""
    call = _Call(check)
    rows = []
    try:
        call.tick()
        call.need(selector.VERSION == "FPC-TWO-DONOR-INPUT-SELECTOR-v1", "selector public version")
        ordering = (
            (["not", ["not", ["pred", 0, []]]], [1, 1, 0, 0], 3, 2),
            (["imp", ["pred", 0, []], ["pred", 0, []]], [2, 0, 0, 0, 0], 3, 1),
            (["imp", ["pred", 0, []], ["pred", 1, []]], [2, 0, 0, 0, 1], 3, 1),
        )
        evidence = []
        for raw, tokens, nodes, depth in ordering:
            item = _inspect(selector, raw, call)
            call.need(item["tokens"] == tokens and item["expanded_nodes"] == nodes and
                      item["depth"] == depth, "literal tree/order expectation")
            evidence.append({"tokens": tokens, "expanded_nodes": nodes, "depth": depth})
        rows.append({"id": CONTROL_IDS[0], "status": "PASSED", "scope": "literal helper properties",
                     "evidence": evidence})

        renamings = (
            (["imp", ["pred", 2, []], ["pred", 1, []]],
             ["imp", ["pred", 0, []], ["pred", 1, []]]),
            (["imp", ["pred", 2, []], ["pred", 2, []]],
             ["imp", ["pred", 0, []], ["pred", 0, []]]),
            (["imp", ["not", ["pred", 2, []]], ["imp", ["pred", 1, []], ["pred", 2, []]]],
             ["imp", ["not", ["pred", 0, []]], ["imp", ["pred", 1, []], ["pred", 0, []]]]),
        )
        for raw, expected in renamings:
            item = _inspect(selector, raw, call)
            call.need(item["canonical_goal"] == expected, "literal atom identity")
        rows.append({"id": CONTROL_IDS[1], "status": "PASSED", "scope": "literal canonicalization",
                     "evidence": {"cases": 3, "distinct_atom_not_collapsed": True}})

        boolean_cases = (
            (["imp", ["pred", 0, []], ["pred", 1, []]], [True, True, False, True], False),
            (["imp", ["pred", 0, []], ["imp", ["pred", 1, []], ["pred", 0, []]]],
             [True, True, True, True], True),
            (["not", ["imp", ["pred", 0, []], ["pred", 0, []]]], [False, False], False),
        )
        for raw, values, tautology in boolean_cases:
            item = _inspect(selector, raw, call)
            call.need(item["truth_values"] == values and item["tautology"] is tautology,
                      "literal Boolean vector")
        atom = _inspect(selector, ["pred", 0, []], call)
        call.need(atom["eligible"] is False, "atom not eligible")
        rows.append({"id": CONTROL_IDS[2], "status": "PASSED", "scope": "Boolean eligibility only",
                     "evidence": {"literal_vectors": 3, "certificate_claim": False}})

        schema_cases = (
            (["imp", ["pred", 0, []], ["imp", ["pred", 1, []], ["pred", 0, []]]], [0]),
            (["imp", ["pred", 0, []], ["imp", ["pred", 1, []], ["pred", 2, []]]], []),
            (["imp", ["imp", ["pred", 0, []], ["imp", ["pred", 1, []], ["pred", 2, []]]],
              ["imp", ["imp", ["pred", 0, []], ["pred", 1, []]],
               ["imp", ["pred", 0, []], ["pred", 2, []]]]], [1]),
            (["imp", ["imp", ["not", ["pred", 1, []]], ["not", ["pred", 0, []]]],
              ["imp", ["pred", 0, []], ["pred", 1, []]]], [2]),
            (["imp", ["imp", ["not", ["pred", 1, []]], ["not", ["pred", 0, []]]],
              ["imp", ["pred", 2, []], ["pred", 1, []]]], []),
        )
        for raw, expected in schema_cases:
            item = _inspect(selector, raw, call)
            call.need(item["single_axiom_subtags"] == expected, "literal single-axiom match")
        rows.append({"id": CONTROL_IDS[3], "status": "PASSED", "scope": "rigid full schema helper",
                     "evidence": {"cases": 5, "complete_schema_tags": [0, 1, 2]}})

        selection, selected_tokens = _selection(selector, call)
        rows.append({"id": CONTROL_IDS[4], "status": "PASSED", "scope": "real complete ordered prefix",
                     "evidence": {"selection_status": selection["status"],
                                  "prefix_rows": len(selection["prefix"]), "selected_tokens": selected_tokens,
                                  "STOP_branch_exercised": selection["status"] == "STOP_INPUT_CENSUS",
                                  "bounds_changed_to_force_STOP": False}})

        retained = _owned_refusal(selector, call)
        unowned = selector.SelectorInputError("selector bank unowned same-class callback")
        call.need(not selector.is_owned_error(unowned), "public refusal construction unowned")
        faults = []
        for entry in ("inspect_formula", "select_inputs"):
            for error in (BaseException("selector generic callback"),
                          StopIteration("selector StopIteration callback"), unowned, retained):
                call.tick()
                faults.append(_fault(selector, entry, error, call))
        fresh = selector.inspect_formula(["not", ["pred", 0, []]], check=call.tick)
        raw = ["not", ["pred", 0, []]]
        fresh["canonical_goal"][1][1] = 2
        again = selector.inspect_formula(raw, check=call.tick)
        call.need(again["canonical_goal"] == raw and raw == ["not", ["pred", 0, []]],
                  "fresh output/no mutable global template")
        if selection["status"] == "SELECTED":
            before = _copy(selection["slots"]["donor1"], call)
            selection["slots"]["donor0"]["query"]["predicate_arities"].append(0)
            call.need(_equal(selection["slots"]["donor1"], before, call), "slot no mutable aliases")
        rows.append({"id": CONTROL_IDS[5], "status": "PASSED", "scope": "semantic fields/selected fault endpoints",
                     "evidence": {"faults": faults, "encoded_bytes": False,
                                  "all_cutoff_or_cleanup_coverage": False}})
        call.need(tuple(row["id"] for row in rows) == CONTROL_IDS, "six exact ordered groups")
        return {"schema": RETURN_SCHEMA, "version": VERSION, "population": POPULATION,
                "complete": True, "control_ids": list(CONTROL_IDS), "controls": rows,
                "counts": {"groups": 6, "passed": 6, "failed": 0},
                "accepted": False,
                "scope": "Additive selector qualification, never proof/admission/holdout success authority."}
    except BaseException:
        if call.first is not None:
            raise call.first
        raise
