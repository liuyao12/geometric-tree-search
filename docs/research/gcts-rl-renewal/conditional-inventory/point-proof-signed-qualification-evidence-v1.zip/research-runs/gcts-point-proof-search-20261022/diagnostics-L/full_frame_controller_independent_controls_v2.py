"""Independent controller protocol + real tiny Cartesian controls, all unrun.

Only stdlib serialization is imported. Scripted members are assumed finite point
members, NOT FPC inference instances. No controller/provider executable was read.
All helper/module/fixture/encoder calls occur only in a future authenticated job.
"""
import json
import hashlib

VERSION = "L-full-frame-controller-controls-v2"
RETURN_SCHEMA = "independent-full-frame-controller-controls-v1"
DECLARATION_SHA256 = "0d72dce6742d07594fef597290c53b4582bd1743711c52f974ac6d29aa2f3b49"
CONTROL_IDS = (
    "protocol-dead-before-forced", "protocol-no-forcing-unresolved",
    "protocol-global-single-before-earlier-branch", "protocol-parent-offer-remainder",
    "protocol-fuel-not-child-failure", "protocol-first-fault-no-normal-result",
    "real-tiny-candidate-frame-agreement", "real-tiny-empty-frame-agreement",
    "dovetail-first-prefix-budget-restarts", "public-strict-int-and-input-identity",
)
FRAME_KEYS = {"schema", "status", "frame", "accepted", "candidate_certificate_bytes",
              "export_receipt", "metrics", "trace", "trace_complete"}
METRICS = {"atomic_steps", "callbacks", "state_creations", "classifier_opens",
           "classifier_advances", "domain_completions", "global_scans", "forced_moves",
           "branch_nodes", "offers", "backtracks", "reject_offers", "max_path_depth",
           "max_frontier", "classifiers_rebound", "domains_invalidated"}
EVENTS = {
    "STATE": {"kind", "depth", "state_serial", "parent_serial", "snapshot"},
    "DOMAIN": {"kind", "state_serial", "row", "domain_kind", "coverage_complete", "witnesses", "source", "remainder_revision"},
    "DECISION": {"kind", "state_serial", "status", "row", "all_unfilled"},
    "SELECT": {"kind", "parent_serial", "child_serial", "row", "forced", "from_offer", "candidate", "branch_serial", "offer_serial"},
    "OFFER": {"kind", "state_serial", "row", "branch_serial", "offer_serial", "candidate"},
    "REJECT": {"kind", "restored_parent_serial", "failed_child_serial", "row", "branch_serial", "offer_serial", "reason"},
    "REUSE": {"kind", "row", "from_state_serial", "state_serial"},
    "INVALIDATE": {"kind", "row", "from_state_serial", "state_serial"},
    "TERMINAL": {"kind", "status", "phase", "atomic_steps", "outstanding_offers"},
}
COUNTER_NAMES = ("committed_actions", "raw_tuples_complete", "intrinsic_refusals",
                 "envelope_exclusions", "point_conflicts", "distinct_legal_inspected",
                 "shortcut_candidates_proved", "fallback_eof_events", "branch_offers",
                 "failed_children_recorded", "tried_prefix_advances")
_OWNER = object()


class ControllerControlError(ValueError):
    pass


class _Call:
    def __init__(self, check):
        self.check, self.first = check, None

    def tick(self):
        if self.first is not None:
            raise self.first
        try:
            self.check()
        except BaseException as error:
            self.first = error
            raise

    def need(self, value, message):
        if self.first is not None:
            raise self.first
        if not value:
            error = ControllerControlError(message)
            error._owner = _OWNER
            raise error


def _copy(value, call):
    call.tick()
    if value is None or type(value) in (str, int, bool):
        return value
    if type(value) in (list, tuple):
        return [_copy(child, call) for child in value]
    call.need(type(value) is dict, "ordinary carrier")
    return {key: _copy(child, call) for key, child in value.items()}


def _same(a, b, call):
    return json.dumps(_copy(a, call), sort_keys=True, separators=(",", ":"), allow_nan=False) == json.dumps(
        _copy(b, call), sort_keys=True, separators=(",", ":"), allow_nan=False)


def _freeze(value):
    # Script declarations are finite immutable literal carriers, never a parser.
    if type(value) in (list, tuple):
        return tuple(_freeze(child) for child in value)
    return value


class _ScriptInputError(ValueError):
    pass


class _Handle:
    pass


class _ProtocolCopyCall:
    def __init__(self, provider, inventory, check):
        self.provider, self.inventory, self.check = provider, inventory, check

    def tick(self):
        self.provider._tick(self.inventory, self.check)

    def need(self, condition, message):
        self.provider._need(condition, message)


class _ScriptProvider:
    """Protocol surrogate: finite explicit point memberships, no FPC authority."""
    VERSION = "FPC-POINT-FULL-FRAME-PROVIDER-v1"
    FEATURES = ("finite-full-kernel", "atomic-cursors", "rebind-classification", "dependency-rebind-classification")
    ProviderInputError = _ScriptInputError

    def __init__(self, scenario, query, call):
        self.scenario, self.query, self.call = scenario, query, call
        self.log, self.frames, self.serial = [], [], 0
        self.cleanup_error = None
        self.external_error = None

    def _new(self, inventory, kind):
        handle = _Handle()
        self.serial += 1
        handle.serial, handle.inventory, handle.kind = self.serial, inventory, kind
        return handle

    def _tick(self, inventory, check):
        if inventory is not None and inventory.fault is not None:
            raise inventory.fault
        try:
            check()
        except BaseException as error:
            if inventory is not None:
                inventory.fault = error
            raise

    def _need(self, value, text):
        if not value:
            error = _ScriptInputError(text)
            error._owner = _OWNER
            raise error

    def is_owned_error(self, error):
        return type(error) is _ScriptInputError and getattr(error, "_owner", None) is _OWNER

    def _members(self, n):
        # A/B/C/D/G are opaque SCRIPT marks, not formulas or trusted rules.
        # They are represented as typed core trees only to exercise the public
        # diagnostic surface; they do not assert FPC inference membership.
        A = ("pred", 0, ())
        B = ("not", A)
        C = ("all", 0, A)
        D = ("not", B)
        G = A
        if self.scenario == "schedule":
            return []
        if self.scenario == "dead":
            declarations = [("a", 0, ((0, A),)), ("c", 2, ((2, G),)), ("d", 2, ((2, G),))]
        elif self.scenario == "wait":
            declarations = [("a", 0, ((0, A),)), ("b", 1, ((0, B), (1, G))), ("c", 1, ((0, C), (1, G)))]
        elif self.scenario == "force":
            declarations = [("a", 0, ((0, A),)), ("b", 0, ((0, B),)), ("c", 1, ((0, C), (1, G)))]
        elif self.scenario in ("parent", "fuel"):
            declarations = [("a", 0, ((0, A),)), ("b", 0, ((0, B),)),
                            ("c", 1, ((0, C), (1, G))), ("d", 1, ((0, C), (1, G)))]
        elif self.scenario == "unaffected":
            declarations = [("a", 0, ((0, A),)), ("b", 0, ((0, B),)), ("c", 1, ((1, G),))]
        else:
            self._need(self.scenario == "refcount", "known scripted scenario")
            declarations = [("a", 0, ((0, A),)), ("b", 0, ((0, A),)),
                            ("c", 1, ((0, A), (1, C))),
                            ("d", 2, ((0, A), (1, C), (2, G))),
                            ("e", 2, ((0, A), (1, D), (2, G)))]
        return declarations

    def create_inventory(self, query_bytes, *, frame, modules, check):
        self._tick(None, check)
        if self.external_error is not None:
            raise self.external_error
        inv = self._new(None, "INVENTORY")
        inv.inventory, inv.fault, inv.closed = inv, None, False
        inv.n, inv.frame = frame["rows"], dict(frame)
        inv.model = {"schema": "FPC-point-model-identity-v1", "inventory_version": self.VERSION,
                     "query_hex": query_bytes.hex(), "query": self.query, "frame": frame}
        inv.members = []
        for index, (label, row, marks) in enumerate(self._members(inv.n)):
            self._tick(inv, check)
            member = self._new(inv, "CANDIDATE")
            member.label, member.row, member.witness = label, row, index
            member.marks = tuple(((r, 1), ("FPC", formula)) for r, formula in marks)
            member.formula = dict(marks)[row]
            inv.members.append(member)
        self.frames.append(dict(frame))
        self.log.append(("INVENTORY", inv.serial, dict(frame)))
        return inv

    def _key(self, member):
        return ("FPC-point-ground-key-v1", member.inventory,
                ("ROW", member.row), 0, None, member.witness,
                (((member.row, 0), (1, 1)),), member.marks)

    def _state(self, inv, parent, selected):
        state = self._new(inv, "STATE")
        state.parent, state.selected = parent, tuple(selected)
        marks = {(inv.n - 1, 1): (("FPC", _freeze(self.query["goal"])), 1)}
        for member in selected:
            for point, value in member.marks:
                old = marks.get(point)
                self._need(old is None or old[0] == value, "script marking conflict")
                marks[point] = (value, 1 if old is None else old[1] + 1)
        state.m = tuple((point, value, count) for point, (value, count) in sorted(marks.items()))
        state.keys = tuple(next((self._key(member) for member in selected if member.row == row), None)
                           for row in range(inv.n))
        state.t = tuple(((row, 0), (int(state.keys[row] is not None), 1)) for row in range(inv.n))
        return state

    def root_state(self, inventory, *, check):
        self._tick(inventory, check)
        state = self._state(inventory, None, ())
        self.log.append(("ROOT", state.serial))
        return state

    def state_section(self, state, *, check):
        self._tick(state.inventory, check)
        return ("FPC-point-state-section-v1", state.inventory, state.serial,
                state.parent, state.keys, state.t, state.m)

    def _legal(self, state, row):
        if state.keys[row] is not None:
            return []
        marks = {point: value for point, value, count in state.m}
        return [member for member in state.inventory.members if member.row == row
                and all(point not in marks or marks[point] == value for point, value in member.marks)]

    def place_state(self, state, candidate, *, check):
        self._tick(state.inventory, check)
        self._need(candidate.inventory is state.inventory and candidate in self._legal(state, candidate.row), "legal script placement")
        child = self._state(state.inventory, state, state.selected + (candidate,))
        self.log.append(("PLACE", state.serial, child.serial, candidate.row, candidate.label))
        return child

    def dependency_spec(self, inventory, point, *, check):
        self._tick(inventory, check)
        return {"cell": point, "formula_port_prefix": [0, point[0] + 1], "inventory_version": self.VERSION}

    def _projection(self, state, row):
        return (state.keys[:row + 1], state.t[:row + 1],
                tuple(item for item in state.m if item[0][1] == 1 and 0 <= item[0][0] <= row))

    def _cursor(self, state, point, kind):
        cursor = self._new(state.inventory, kind)
        cursor.state, cursor.point = state, point
        cursor.counts = {key: 0 for key in COUNTER_NAMES}
        cursor.witnesses, cursor.position, cursor.terminal = [], 0, False
        cursor.status, cursor.coverage = "UNRESOLVED", False
        cursor.branch, cursor.revision = None, None
        cursor.tried, cursor.outstanding = [], None
        cursor.initial, cursor.initial_tried = [], []
        cursor.delay = (1024 if self.scenario == "schedule" or
                        (self.scenario == "fuel" and state.selected) else
                        5 if (self.scenario == "wait" and point[0] == 1) or
                        (self.scenario == "dead" and point[0] == 2) else 0)
        return cursor

    def open_classification(self, state, point, *, remainder=None, check):
        self._tick(state.inventory, check)
        self._need(type(point) is tuple and len(point) == 2 and point[1] == 0
                   and type(point[0]) is int and 0 <= point[0] < state.inventory.n, "script point")
        cursor = self._cursor(state, point, "CLASSIFICATION")
        if remainder is not None:
            self._need(remainder.state is state and remainder.outstanding is None, "remainder parent/offer")
            cursor.branch, cursor.revision = remainder, remainder.revision
            cursor.tried = list(remainder.tried)
        self.log.append(("OPEN", state.serial, point[0], cursor.serial, remainder is not None))
        return cursor

    def _current(self, cursor, check):
        self._tick(cursor.inventory, check)
        if cursor.branch is not None:
            self._need(cursor.branch.revision == cursor.revision and cursor.branch.state is cursor.state,
                       "stale script remainder")

    def classification(self, cursor, *, check):
        self._current(cursor, check)
        return {"schema": "FPC-point-classification-v1", "kind": cursor.status,
                "coverage_complete": cursor.coverage, "witnesses": tuple(cursor.witnesses),
                "state_serial": cursor.state.serial, "point": cursor.point,
                "remainder_revision": cursor.revision, "counts": dict(cursor.counts)}

    def advance(self, cursor, *, check):
        self._current(cursor, check)
        self._need(not cursor.terminal and cursor.outstanding is None, "advance active cursor")
        candidate, offer, kind, action = None, None, "PENDING", "ENUMERATE"
        if cursor.delay:
            cursor.delay -= 1
        else:
            members = [item for item in self._legal(cursor.state, cursor.point[0]) if item.label not in cursor.tried]
            if cursor.kind == "BRANCH":
                if members:
                    candidate = members[0]
                    offer = self._new(cursor.inventory, "OFFER")
                    offer.branch, offer.candidate = cursor, candidate
                    cursor.outstanding = offer
                    cursor.counts["branch_offers"] += 1
                    self.log.append(("OFFER", cursor.state.serial, cursor.serial, offer.serial, candidate.label))
                else:
                    kind, action, cursor.terminal = "EOF", "EOF", True
            elif cursor.position < len(members):
                candidate = members[cursor.position]
                cursor.position += 1
                cursor.witnesses.append(candidate)
                cursor.counts["distinct_legal_inspected"] += 1
                if len(cursor.witnesses) == 2:
                    cursor.status, cursor.terminal = "MANY", True
            else:
                kind, action, cursor.terminal, cursor.coverage = "EOF", "EOF", True, True
                cursor.status = "SINGLE" if cursor.witnesses else "EMPTY"
                cursor.counts["fallback_eof_events"] += 1
        if candidate is not None:
            kind, action = "CANDIDATE", "EMIT"
        cursor.counts["committed_actions"] += 1
        if cursor.kind == "CLASSIFICATION" and cursor.terminal:
            self.log.append(("CLASSIFIED", cursor.state.serial, cursor.point[0], cursor.status))
        return {"schema": "FPC-point-provider-step-v1", "kind": kind, "committed": True,
                "action": action, "candidate": candidate, "offer": offer,
                "cursor_serial": cursor.serial, "state_serial": cursor.state.serial,
                "classification_kind": cursor.status if cursor.kind == "CLASSIFICATION" else None}

    def open_branch(self, state, point, *, classified, check):
        self._current(classified, check)
        self._need(classified.state is state and classified.status == "MANY" and classified.branch is None,
                   "initial MANY branch")
        branch = self._cursor(state, point, "BRANCH")
        branch.initial = list(classified.witnesses)
        branch.initial_tried = [False for unused in branch.initial]
        branch.delay, branch.revision = 0, 0
        self.log.append(("BRANCH", state.serial, point[0], branch.serial))
        return branch

    def reject_offer(self, branch_cursor, offer, *, check):
        self._current(branch_cursor, check)
        self._need(branch_cursor.outstanding is offer and offer.branch is branch_cursor, "owned exact offer")
        branch_cursor.tried.append(offer.candidate.label)
        branch_cursor.outstanding = None
        branch_cursor.revision += 1
        branch_cursor.counts["failed_children_recorded"] += 1
        branch_cursor.counts["tried_prefix_advances"] += 1
        branch_cursor.initial_tried = [item.label in branch_cursor.tried for item in branch_cursor.initial]
        self.log.append(("REJECT", branch_cursor.state.serial, branch_cursor.serial, offer.serial, offer.candidate.label))

    def rebind_classification(self, cursor, state, *, check):
        self._current(cursor, check)
        self._need(cursor.kind == "CLASSIFICATION" and cursor.inventory is state.inventory, "initial classifier inventory")
        if cursor.branch is not None:
            self._need(cursor.state is state, "remainder exact parent")
        self._need(self._projection(cursor.state, cursor.point[0]) == self._projection(state, cursor.point[0]),
                   "dependency projection")
        new = self._cursor(state, cursor.point, "CLASSIFICATION")
        for name in ("position", "terminal", "status", "coverage", "delay", "branch", "revision"):
            setattr(new, name, getattr(cursor, name))
        new.witnesses, new.tried, new.counts = list(cursor.witnesses), list(cursor.tried), dict(cursor.counts)
        self.log.append(("REBIND", cursor.state.serial, state.serial, cursor.point[0]))
        return new

    def candidate_record(self, candidate, *, check):
        self._tick(candidate.inventory, check)
        record = {"rule_tag": 0, "subtag": None, "witness": candidate.witness,
                  "formula": candidate.formula, "references": [],
                  "t": (((candidate.row, 0), (1, 1)),), "m": candidate.marks}
        record["key"] = ["FPC-point-ground-key-v1", candidate.inventory.model, ["ROW", candidate.row],
                         0, None, candidate.witness, record["t"], record["m"]]
        return _copy(record, _ProtocolCopyCall(self, candidate.inventory, check))

    def snapshot(self, handle, *, check):
        self._tick(handle.inventory, check)
        if handle.kind == "STATE":
            selected = [None] * handle.inventory.n
            for item in handle.selected:
                selected[item.row] = self.candidate_record(item, check=check)["key"]
            return _copy({"schema": "FPC-point-state-snapshot-v1", "model": handle.inventory.model,
                          "state_serial": handle.serial, "parent_serial": None if handle.parent is None else handle.parent.serial,
                          "selected_keys": selected, "t_items": handle.t, "m_items_with_refcounts": handle.m},
                         _ProtocolCopyCall(self, handle.inventory, check))
        return _copy({"schema": "FPC-point-cursor-snapshot-v1", "model": handle.inventory.model,
                      "cursor_serial": handle.serial, "kind": handle.kind, "parent_state_serial": handle.state.serial,
                      "point": handle.point, "phase": "SCRIPT", "inspection_frontier": None,
                      "canonical_scan_frontier": None, "canonical_tried_frontier": None,
                      "initial_shortcut_keys": [self.candidate_record(item, check=check)["key"] for item in handle.initial],
                      "initial_shortcut_tried": handle.initial_tried,
                      "outstanding_offer_serial": None if handle.outstanding is None else handle.outstanding.serial,
                      "remainder_revision": handle.revision, "terminal": handle.terminal, "counts": handle.counts},
                     _ProtocolCopyCall(self, handle.inventory, check))

    def export_candidate(self, state, *, check):
        self._tick(state.inventory, check)
        self._need(all(item is not None for item in state.keys), "complete scripted frame")
        self.log.append(("EXPORT", state.serial))
        return {"candidate_certificate_bytes": b"SCRIPT_PROTOCOL_ONLY_NOT_AN_FPC_CERTIFICATE",
                "receipt": {"accepted": False, "scope": "SCRIPTED protocol only; no logical membership"}}

    def close(self, handle):
        if handle is None:
            return
        self.log.append(("CLOSE", handle.kind, handle.serial))
        if self.cleanup_error is not None:
            raise self.cleanup_error


def _result(result, call, expected=None, fuel=None):
    call.need(type(result) is dict and set(result) == FRAME_KEYS and result["schema"] == "FPC-point-frame-search-v1", "strict frame result")
    call.need(result["accepted"] is False and result["status"] in ("CANDIDATE", "EXHAUSTED_FRAME", "UNKNOWN_FUEL"), "candidate not admission")
    call.need(set(result["metrics"]) == METRICS, "strict frame metric set")
    for value in result["metrics"].values():
        call.need(type(value) is int and value >= 0, "strict scalar metric")
    if fuel is not None:
        call.need(result["metrics"]["atomic_steps"] <= fuel, "normal fuel committed bound")
    if expected is not None:
        call.need(result["status"] == expected, "expected frame disposition")
    if result["status"] == "CANDIDATE":
        call.need(type(result["candidate_certificate_bytes"]) is bytes and result["export_receipt"]["accepted"] is False,
                  "provisional immutable export")
    else:
        call.need(result["candidate_certificate_bytes"] is None and result["export_receipt"] is None, "no noncandidate prefix")
    call.need(result["trace_complete"] is True, "small control needs complete nontruncated trace")
    for event in result["trace"]:
        call.tick()
        call.need(event["kind"] in EVENTS and set(event) == EVENTS[event["kind"]], "exact public event fields")
        if event["kind"] == "DECISION" and event["status"] in ("FORCED", "BRANCH"):
            call.need(all(set(row) == {"row", "kind", "coverage_complete"} for row in event["all_unfilled"]),
                      "exact global row-label fields")
            call.need(all(row["kind"] != "UNRESOLVED" for row in event["all_unfilled"]), "no global decision on unresolved row")
        if event["kind"] == "REJECT":
            call.need(event["reason"] in ("CHILD_DEAD", "CHILD_EXHAUSTED"), "only completed child permits reject")
    call.need(result["trace"][-1]["kind"] == "TERMINAL", "terminal trace")
    return result


def _run_script(controller, scenario, query, query_bytes, modules, call, steps=None):
    scripted = _ScriptProvider(scenario, query, call)
    n = 3 if scenario in ("dead", "refcount") else 2
    frame = {"schema": "FPC-point-frame-v1", "rows": n, "syntax_nodes": 5}
    saved_frame = dict(frame)
    helper_roles = {key: modules[key] for key in ("checker", "builders")}
    result = controller.search_frame(query_bytes, provider=scripted, frame=frame,
                                     modules=helper_roles,
                                     max_steps=steps, trace_limit=4096, check=call.tick)
    call.need(_same(frame, saved_frame, call) and _same(result["frame"], saved_frame, call), "exact frame unchanged")
    call.need(set(helper_roles) == {"checker", "builders"}
              and all(helper_roles[key] is modules[key] for key in helper_roles), "helper role map unchanged")
    _result(result, call, fuel=steps)
    return scripted, result


def _protocol_groups(controller, query, query_bytes, modules, call):
    output = []
    stub, result = _run_script(controller, "dead", query, query_bytes, modules, call)
    _result(result, call, "EXHAUSTED_FRAME")
    call.need(not any(row[0] in ("PLACE", "BRANCH", "REJECT") for row in stub.log), "dead precedes forced")
    call.need(not any(row[0] == "OPEN" and row[2] == 2 for row in stub.log), "known dead stops irrelevant unresolved work")
    output.append({"id": CONTROL_IDS[0], "status": "PASSED", "trace": result["trace"], "protocol_log": stub.log})
    stub, result = _run_script(controller, "wait", query, query_bytes, modules, call)
    _result(result, call, "EXHAUSTED_FRAME")
    first_place = next(index for index, row in enumerate(stub.log) if row[0] == "PLACE")
    call.need(any(row[0] == "CLASSIFIED" and row[2] == 1 and row[3] == "MANY" for row in stub.log[:first_place]),
              "other delayed row resolved before forced placement")
    output.append({"id": CONTROL_IDS[1], "status": "PASSED", "trace": result["trace"]})
    stub, result = _run_script(controller, "force", query, query_bytes, modules, call)
    selects = [row for row in result["trace"] if row["kind"] == "SELECT"]
    call.need(selects[0]["row"] == 1 and selects[0]["forced"] is True and selects[0]["from_offer"] is False,
              "later SINGLE before earlier branch")
    unaffected, kept = _run_script(controller, "unaffected", query, query_bytes, modules, call)
    _result(kept, call, "CANDIDATE")
    call.need(any(row["kind"] == "REUSE" and row["row"] == 0 for row in kept["trace"]), "unaffected classifier retained")
    call.need(not any(row[0] == "REJECT" for row in unaffected.log), "positive leaf never rejected")
    output.append({"id": CONTROL_IDS[2], "status": "PASSED", "affected_trace": result["trace"],
                   "unaffected_trace": kept["trace"], "script_candidate_not_logical": True})
    stub, result = _run_script(controller, "parent", query, query_bytes, modules, call)
    _result(result, call, "EXHAUSTED_FRAME")
    offers = [row for row in result["trace"] if row["kind"] == "OFFER"]
    rejects = [row for row in result["trace"] if row["kind"] == "REJECT"]
    selects = [row for row in result["trace"] if row["kind"] == "SELECT"]
    call.need(len(offers) == len(rejects) == len(selects) == 2, "two fully failed owned children")
    call.need(offers[0]["branch_serial"] == offers[1]["branch_serial"], "same retained branch for SINGLE remainder")
    for offer, reject, select in zip(offers, rejects, selects):
        call.need(select["from_offer"] is True and select["offer_serial"] == offer["offer_serial"]
                  and reject["offer_serial"] == offer["offer_serial"]
                  and reject["restored_parent_serial"] == offer["state_serial"]
                  and reject["failed_child_serial"] == select["child_serial"], "exact parent/offer/child rollback association")
    call.need(selects[1]["forced"] is True, "singleton remainder still uses owned offer")
    ref_stub, ref_result = _run_script(controller, "refcount", query, query_bytes, modules, call)
    _result(ref_result, call, "CANDIDATE")
    chosen = [row for row in ref_result["trace"] if row["kind"] == "SELECT"]
    call.need([row["row"] for row in chosen[:2]] == [1, 2], "refcount literal forced chain")
    call.need(any(row["kind"] == "INVALIDATE" and row["row"] == 0
                  and row["from_state_serial"] == chosen[0]["child_serial"]
                  and row["state_serial"] == chosen[1]["child_serial"] for row in ref_result["trace"]),
              "same m value but changed owner count invalidates domain")
    output.append({"id": CONTROL_IDS[3], "status": "PASSED", "trace": result["trace"], "refcount_trace": ref_result["trace"]})
    facets = []
    for fuel in (0, 1, 2, 64):
        stub, result = _run_script(controller, "fuel", query, query_bytes, modules, call, steps=fuel)
        _result(result, call, "UNKNOWN_FUEL", fuel)
        call.need(not any(row[0] == "REJECT" for row in stub.log), "normal fuel is not child failure")
        if fuel == 64:
            terminal = result["trace"][-1]
            call.need(result["metrics"]["offers"] > 0 and any(row[0] == "PLACE" for row in stub.log)
                      and terminal["outstanding_offers"] > 0 and terminal["phase"] == "CLASSIFY_ADVANCE",
                      "nonvacuous outstanding child cutoff")
        facets.append({"fuel": fuel, "metrics": result["metrics"], "terminal": result["trace"][-1]})
    output.append({"id": CONTROL_IDS[4], "status": "PASSED", "facets": facets})
    return output


def _owned_refusal(controller, operation, call):
    try:
        operation()
    except BaseException as error:
        if call.first is not None:
            raise call.first
        if not controller.is_owned_error(error):
            raise
        return error
    call.need(False, "expected owned public refusal")


def _fault_group(controller, query, query_bytes, modules, call):
    helpers = {key: modules[key] for key in ("checker", "builders")}
    frame = {"schema": "FPC-point-frame-v1", "rows": 2, "syntax_nodes": 5}
    retained = _owned_refusal(controller, lambda: controller.search_frame(
        query_bytes, provider=_ScriptProvider("fuel", query, call), frame=frame,
        modules=helpers, max_steps=True, check=call.tick), call)
    old_attrs, old_args = dict(vars(retained)), retained.args
    unowned = controller.FrameInputError("authored same-class callback")
    call.need(not controller.is_owned_error(unowned), "public constructor unowned")
    records = []
    for phase in ("ENTRY", "AFTER_CHILD"):
        for name, sentinel in (("RuntimeError", RuntimeError("controller first fault")),
                               ("StopIteration", StopIteration("controller first fault")),
                               ("GeneratorExit", GeneratorExit("controller first fault")),
                               ("unowned-public-class", unowned), ("retained-owned", retained),
                               ("E-before-cleanup-F", RuntimeError("first E"))):
            if phase == "ENTRY" and name == "E-before-cleanup-F":
                continue  # No owned handle exists yet: do not claim cleanup F.
            call.tick()
            stub = _ScriptProvider("fuel", query, call)
            raised = [False]

            def diagnostic_check():
                call.tick()
                if raised[0]:
                    raise RuntimeError("callback after first fault")
                if phase == "ENTRY" or any(row[0] == "PLACE" for row in stub.log):
                    raised[0] = True
                    if name == "E-before-cleanup-F":
                        stub.cleanup_error = RuntimeError("later cleanup F")
                    raise sentinel

            try:
                controller.search_frame(query_bytes, provider=stub, frame=frame, modules=helpers,
                                        max_steps=None, trace_limit=4096, check=diagnostic_check)
            except BaseException as error:
                if call.first is not None:
                    raise call.first
                if error is not sentinel:
                    raise
            else:
                call.need(False, "fault cannot return UNKNOWN or any normal prefix")
            call.need(raised[0], "nonvacuous intentional fault")
            call.need(not any(row[0] == "REJECT" for row in stub.log), "callback cannot reject child")
            if name == "E-before-cleanup-F":
                call.need(any(row[0] == "CLOSE" for row in stub.log), "nonvacuous later cleanup F")
            if sentinel is retained:
                call.need(vars(retained) == old_attrs and retained.args == old_args, "retained refusal data unchanged")
            records.append({"phase": phase, "recipe": name, "same_object": True,
                            "normal_prefix": False, "cleanup_observed_success": False,
                            "later_cleanup_F_exercised": name == "E-before-cleanup-F"})
    return {"id": CONTROL_IDS[5], "status": "PASSED", "recipes": records}


def _encode(encoder, fixture, checker, call):
    literal = _copy(fixture["query"], call)
    result = encoder.encode_tiny_declared_query(literal, check=call.tick)
    query_bytes = result["query_bytes"]
    parsed = checker.decode_query(query_bytes, check=call.tick)
    for key, value in literal.items():
        call.need(_same(parsed[key], value, call), "literal same-byte query binding")
    call.need(_same(literal, fixture["query"], call), "literal query unchanged")
    return query_bytes


def _real_groups(controller, provider, fixtures, row_oracle, frame_oracle, encoder, modules, call):
    positive, negative = [], []
    helpers = {key: modules[key] for key in ("checker", "builders")}
    # The original seven query declarations and their frames remain unchanged.
    # This one NEW controller-only frame facet reuses E1-single query literally.
    cases = (("duplicate-base", "duplicate-base", 4, None),
             ("E1-single", "E1-single", 1, None),
             ("GEN-unfounded", "GEN-unfounded", 0, None),
             ("Gamma-block-zero", "Gamma-block-zero", 0, None),
             ("goal-outside", "goal-outside", 0, None),
             ("controller-only-E1-two-row-reuse", "E1-single", 4,
              {"schema": "FPC-point-frame-v1", "rows": 2, "syntax_nodes": 3}))
    for name, source_fixture, count, controller_frame in cases:
        call.tick()
        fixture = fixtures[source_fixture]
        if controller_frame is not None:
            fixture = {"query": fixtures[source_fixture]["query"], "frame": controller_frame}
        query_bytes = _encode(encoder, fixture, modules["checker"], call)
        expected = frame_oracle.enumerate_literal_frame_completions(
            fixture["query"], fixture["frame"], row_oracle=row_oracle, check=call.tick)
        call.need(expected["complete"] is True and expected["solution_count"] == count,
                  "independent complete Cartesian frame count")
        result = controller.search_frame(query_bytes, provider=provider, frame=_copy(fixture["frame"], call),
                                         modules=helpers, max_steps=None, trace_limit=4096, check=call.tick)
        _result(result, call, "CANDIDATE" if count else "EXHAUSTED_FRAME")
        if count:
            certificate = result["candidate_certificate_bytes"]
            subject = modules["checker"].check_certificate(query_bytes, certificate, check=call.tick)
            independent = modules["reference"].reference_check_certificate(query_bytes, certificate, check=call.tick)
            call.need(subject["complete"] is True and subject["accepted"] is True
                      and subject["status"] == "VALID_DERIVATION", "original subject same-byte complete fixture validator")
            call.need(independent["complete_check"] is True
                      and independent["status"] == "VALID_DERIVATION"
                      and independent["final_goal_equal"] is True,
                      "original independent flat-reference same-byte complete fixture validator")
            rows = subject["certificate"]["rows"]
            call.need(len(rows) == fixture["frame"]["rows"], "exact complete frame export length")
            matched = False
            for option in expected["solutions"]:
                call.tick()
                equal = len(rows) == len(option)
                for index, (row, member) in enumerate(zip(rows, option)):
                    call.tick()
                    # Positional byte-parser payload vectors differ from the
                    # scalar HYP/finite-table provider witness convention.
                    witness = row["witness"]
                    if row["rule_tag"] == 0 or (row["rule_tag"] == 2 and row["subtag"] == 0):
                        call.need(type(witness) in (list, tuple) and len(witness) == 1, "single-index wire payload")
                        witness = witness[0]
                    if not (_same(row["formula"], member["formula"], call)
                            and row["index"] == index
                            and row["rule_tag"] == member["rule_tag"]
                            and row["subtag"] == member["subtag"]
                            and _same(witness, member["witness"], call)):
                        equal = False
                if equal:
                    matched = True
            call.need(matched, "export is one complete independent member tuple")
            facet = {"fixture": name, "source_query_fixture": source_fixture,
                     "frame": _copy(fixture["frame"], call), "oracle": expected,
                     "metrics": result["metrics"], "subject": subject, "reference": independent,
                     "scope": "authored generic qualification input, not mathematical target discovery or Root admission"}
            if controller_frame is not None:
                trace = result["trace"]
                selected = [event for event in trace if event["kind"] == "SELECT"]
                first = selected[0]
                call.need(first["row"] == 1 and first["forced"] is True and first["from_offer"] is False,
                          "real later singleton forced before earlier branch")
                selected_index = next(index for index, event in enumerate(trace) if event is first)
                inspected = [event for event in trace[:selected_index]
                             if event["kind"] == "DOMAIN" and event["row"] == 0
                             and event["state_serial"] == first["parent_serial"]]
                call.need(bool(inspected) and inspected[-1]["domain_kind"] == "MANY",
                          "real earlier domain inspected before later forced placement")
                call.need(any(event["kind"] == "REUSE" and event["row"] == 0
                              and event["from_state_serial"] == first["parent_serial"]
                              and event["state_serial"] == first["child_serial"] for event in trace),
                          "real unchanged earlier classifier transported by provider rebind")
                call.need(result["metrics"]["classifiers_rebound"] >= 1
                          and result["metrics"]["classifier_opens"] == 2,
                          "real inspected row domain retained, not freshly reopened")
                call.need(len(selected) == 2 and selected[1]["row"] == 0
                          and selected[1]["from_offer"] is True,
                          "real earlier-row branch completes the exact two-row frame")
                facet["reuse_trace"] = trace
                facet["controller_only_frame_not_provider7_change"] = True
            positive.append(facet)
        else:
            negative.append({"fixture": name, "oracle": expected, "metrics": result["metrics"],
                             "trace": result["trace"], "scope": "frame exhaustion only, never global nonprovability"})
    return [{"id": CONTROL_IDS[6], "status": "PASSED", "cases": positive},
            {"id": CONTROL_IDS[7], "status": "PASSED", "cases": negative}]


def _schedule_group(controller, query, query_bytes, modules, call):
    cases = []
    helpers = {key: modules[key] for key in ("checker", "builders")}
    expected = [{"schema": "FPC-point-frame-v1", "rows": n, "syntax_nodes": b}
                for n, b in ((1, 1), (1, 1), (1, 2), (1, 1), (1, 2), (2, 1))]
    for rounds in (0, 3):
        stub = _ScriptProvider("schedule", query, call)
        result = controller.search_dovetail(query_bytes, provider=stub, modules=helpers,
                                            max_rounds=rounds, check=call.tick)
        call.need(set(result) == {"schema", "status", "accepted", "candidate_certificate_bytes", "export_receipt", "metrics", "last_frame"}
                  and result["schema"] == "FPC-point-dovetail-search-v1"
                  and result["status"] == "UNKNOWN_ROUND_LIMIT" and result["accepted"] is False,
                  "bounded dovetail never unprovable/admitted")
        call.need(result["candidate_certificate_bytes"] is None and result["export_receipt"] is None, "no schedule prefix")
        metrics = result["metrics"]
        call.need(set(metrics) == {"rounds_completed", "frame_runs", "frame_atomic_steps", "sum_frame_limits", "frames_exhausted", "frames_fuel_limited", "callbacks", "max_path_depth", "max_frontier"}, "exact scalar dovetail stats")
        call.need(all(type(value) is int and value >= 0 for value in metrics.values()), "strict dovetail scalar types")
        call.need(metrics["rounds_completed"] == rounds, "completed rounds")
        if rounds == 0:
            call.need(not stub.frames and metrics["frame_runs"] == 0 and result["last_frame"] is None, "zero-round no frame")
        else:
            call.need(_same(stub.frames, expected, call) and metrics["frame_runs"] == 6,
                      "fresh first-prefix diagonal restart order")
            call.need(metrics["frame_atomic_steps"] == metrics["sum_frame_limits"] == 11
                      and metrics["frames_fuel_limited"] == 6 and metrics["frames_exhausted"] == 0,
                      "exact repeated budgets, no free resume")
            call.need(_same(result["last_frame"], {"round": 3, "pair_index": 3, "frame": expected[-1],
                                                   "max_steps": 1, "status": "UNKNOWN_FUEL", "atomic_steps": 1}, call),
                      "last frame scalar binding")
        cases.append({"rounds": rounds, "metrics": metrics, "frames": stub.frames, "last_frame": result["last_frame"]})
    return {"id": CONTROL_IDS[8], "status": "PASSED", "cases": cases,
            "limitation": "first three lower1 rounds only; general fairness and large-ID bound are Source obligations"}


def _input_group(controller, query, query_bytes, modules, call):
    helpers = {key: modules[key] for key in ("checker", "builders")}
    frame = {"schema": "FPC-point-frame-v1", "rows": 2, "syntax_nodes": 5}
    recipes = [
        ("bool-steps", {"max_steps": True}), ("bool-trace", {"trace_limit": True}),
        ("bool-rows", {"frame": dict(frame, rows=True)}),
        ("bool-syntax", {"frame": dict(frame, syntax_nodes=True)}),
        ("mutable-bytes", {"query_bytes": bytearray(query_bytes)}),
    ]
    records = []
    for name, changes in recipes:
        call.tick()
        kwargs = {"provider": _ScriptProvider("fuel", query, call), "frame": _copy(frame, call),
                  "modules": helpers, "max_steps": 0, "trace_limit": 4096, "check": call.tick}
        q = changes.get("query_bytes", query_bytes)
        kwargs.update({key: value for key, value in changes.items() if key != "query_bytes"})
        _owned_refusal(controller, lambda: controller.search_frame(q, **kwargs), call)
        records.append({"recipe": name, "owned_refusal": True})
    _owned_refusal(controller, lambda: controller.search_dovetail(query_bytes,
        provider=_ScriptProvider("schedule", query, call), modules=helpers, max_rounds=True, check=call.tick), call)
    stub = _ScriptProvider("fuel", query, call)
    sentinel = RuntimeError("authored foreign provider protocol fault")
    stub.external_error = sentinel
    try:
        controller.search_frame(query_bytes, provider=stub, frame=frame,
                                modules=helpers, max_steps=None, check=call.tick)
    except BaseException as error:
        if call.first is not None:
            raise call.first
        if error is not sentinel:
            raise
    else:
        call.need(False, "foreign provider error is not DEAD/fuel/exhaustion")
    return {"id": CONTROL_IDS[9], "status": "PASSED", "facets": records + [
        {"recipe": "bool-rounds", "owned_refusal": True},
        {"recipe": "foreign-provider-error", "same_object": True, "normal_result": False}]}


def run_frame_controller_controls(controller, *, provider, declarations, row_oracle,
                                  frame_oracle, encoder, modules, check):
    """Additional controller10 only. No existing population is run or replaced."""
    call = _Call(check)
    call.tick()
    call.need(type(modules) is dict and set(modules) == {"checker", "builders", "reference"}, "exact roles")
    fixtures = {row["id"]: row for row in declarations["fixtures"]}
    call.need(set(fixtures) == {"duplicate-base", "GEN-unfounded", "MP-incoming", "E1-single",
                                "Gamma-block-zero", "Gamma-allow-one", "goal-outside"}, "seven frozen generic queries")
    before = json.dumps(_copy(declarations, call), sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)
    call.need(hashlib.sha256(before.encode("utf-8")).hexdigest() == DECLARATION_SHA256,
              "exact frozen seven-input declaration document")
    query = _copy(fixtures["duplicate-base"]["query"], call)
    query_bytes = _encode(encoder, fixtures["duplicate-base"], modules["checker"], call)
    controls = _protocol_groups(controller, query, query_bytes, modules, call)
    controls.append(_fault_group(controller, query, query_bytes, modules, call))
    controls.extend(_real_groups(controller, provider, fixtures, row_oracle, frame_oracle, encoder, modules, call))
    controls.append(_schedule_group(controller, query, query_bytes, modules, call))
    controls.append(_input_group(controller, query, query_bytes, modules, call))
    call.need(tuple(row["id"] for row in controls) == CONTROL_IDS, "complete ten ordered groups")
    call.need(json.dumps(_copy(declarations, call), sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False) == before,
              "literal declarations remain unchanged")
    call.tick()
    return {"schema": RETURN_SCHEMA, "version": VERSION, "population": "full-frame-controller10",
            "complete": True, "control_ids": list(CONTROL_IDS), "controls": controls,
            "counts": {"groups": 10, "passed": 10, "failed": 0},
            "scope": "Scripted protocol only versus separately labeled real tiny Cartesian/dual-validator checks; no six-target proof route, scheduler universality, Root admission, old126/generic16/provider10 replacement or runtime fit claim"}
