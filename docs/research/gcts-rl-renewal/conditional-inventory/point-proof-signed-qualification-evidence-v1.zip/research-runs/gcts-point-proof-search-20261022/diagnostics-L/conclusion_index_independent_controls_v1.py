"""Fourteen additive constructor-index groups. No fixture runs on import.

The first ten groups are explicitly white-box predicate observations, not a
second complete FPC inventory. Scientific roles and literal data are injected
only by a future exact reviewed worker. No filesystem or discovery intake.
"""

import hashlib
import json

VERSION = "L-conclusion-index-independent-controls-v1"
RETURN_SCHEMA = "independent-conclusion-index-controls-v1"
POPULATION = "constructor-index14"
FIXTURE_IDENTITY = "48f93a688d1a69333a2da528db1b31916f8e05054f4965e1a6513039319d9151"
DECLARATION_IDENTITY = "0d72dce6742d07594fef597290c53b4582bd1743711c52f974ac6d29aa2f3b49"
CONTROL_IDS = (
    "shape-H1-ancestor-descendant",
    "shape-H2-ancestor-descendant",
    "shape-H3-ancestor-descendant",
    "shape-Q1-ancestor-descendant",
    "shape-Q2-ancestor-descendant",
    "shape-Q3-ancestor-descendant",
    "shape-E1-ancestor-descendant",
    "shape-E2-ancestor-descendant",
    "shape-induction-empty-prefix-core",
    "shape-induction-nonempty-prefix-core",
    "helper-first-fault-identities",
    "public-cursor-first-fault-poison",
    "public-tiny-identities-order-remainders",
    "public-incompatible-shape-EOF",
)
QUERY_KEYS = ("version", "claim_mode", "function_arities", "predicate_arities",
              "theory_profile", "finite_axioms", "Gamma", "goal")
RECORD_KEYS = {"key", "rule_tag", "subtag", "witness", "formula", "references", "t", "m"}
STEP_KEYS = {"schema", "kind", "committed", "action", "candidate", "offer",
             "cursor_serial", "state_serial", "classification_kind"}
CLASS_KEYS = {"schema", "kind", "coverage_complete", "witnesses", "state_serial",
              "point", "remainder_revision", "counts"}
_OWNER = object()


class ConclusionControlError(ValueError):
    """Public message construction is unowned; no class-only error catching."""


def is_owned_error(error):
    return type(error) is ConclusionControlError and getattr(error, "_owner", None) is _OWNER


class _Call:
    def __init__(self, check):
        self.check, self.first, self.callbacks = check, None, 0

    def fault(self):
        if self.first is not None:
            raise self.first

    def tick(self):
        self.fault()
        try:
            self.check()
        except BaseException as error:
            self.first = error
            raise
        self.callbacks += 1

    def need(self, condition, message):
        self.fault()
        if condition is not True:
            error = ConclusionControlError(message)
            error._owner = _OWNER
            raise error


def _plain(value, call):
    call.tick()
    if value is None or type(value) in (bool, int, str):
        return value
    if type(value) in (tuple, list):
        answer = []
        for child in value:
            call.tick()
            answer.append(_plain(child, call))
        return answer
    call.need(type(value) is dict, "ordinary fixture/evidence carrier")
    answer = {}
    for key, child in value.items():
        call.tick()
        call.need(type(key) is str, "string carrier keys")
        answer[key] = _plain(child, call)
    return answer


def _identity(value, call):
    copied = _plain(value, call)
    call.tick()
    return json.dumps(copied, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False, allow_nan=False)


def _same(left, right, call):
    return _identity(left, call) == _identity(right, call)


def _digest(value, call):
    return hashlib.sha256(_identity(value, call).encode()).hexdigest()


def _immutable(value, call):
    """Representation-only literal array to tuple copy; no schema generation."""
    call.tick()
    if type(value) in (tuple, list):
        children = []
        for child in value:
            call.tick()
            children.append(_immutable(child, call))
        return tuple(children)
    call.need(value is None or type(value) in (str, int, bool), "literal scalar")
    return value


def _release(provider, handles, suppress):
    """Callback-free close only. No observed allocation-reclamation claim."""
    first = None
    for handle in reversed(handles):
        try:
            provider.close(handle)
        except BaseException as error:
            if first is None:
                first = error
    if not suppress and first is not None:
        raise first


class _Probe:
    """Only .tick is the private predicate's documented dependency here."""
    def __init__(self, call, trip=None, error=None):
        self.call, self.trip, self.error, self.calls = call, trip, error, 0

    def tick(self):
        self.calls += 1
        self.call.tick()
        if self.calls == self.trip:
            raise self.error


def _builder_observation(builders, group, case, hint, call):
    witnesses = _plain(case["builder_witnesses"], call)
    try:
        if group["kind"] == "LOGICAL":
            result = builders.logical_axiom(group["tag"], witnesses, check=call.tick)
        else:
            result = builders.pa_induction(witnesses[0], witnesses[1], witnesses[2], check=call.tick)
    except BaseException as error:
        call.fault()
        if type(error) is not builders.InvalidWitness:
            raise
        observed = "REFUSED"
    else:
        observed = "EQUAL_HINT" if _same(result, hint, call) else "DIFFERENT_HINT"
    call.need(observed == case["builder_result"], "literal builder observation")
    return observed


def _shape_group(provider, builders, group, call):
    rows = []
    for case in group["cases"]:
        call.tick()
        hint = _immutable(case["hint"], call)
        before = _identity(hint, call)
        probe = _Probe(call)
        rule = 1 if group["kind"] == "LOGICAL" else 2
        result = provider._conclusion_compatible(hint, rule, group["tag"], probe)
        call.need(type(result) is bool and result is case["shape"], "literal weak-shape outcome")
        call.need(probe.calls > 0, "predicate actually checked")
        call.need(_identity(hint, call) == before, "literal hint immutable")
        row = {"id": case["id"], "expected_shape": case["shape"],
               "observed_shape": result, "helper_callbacks": probe.calls,
               "scope": "PRIVATE_NECESSARY_PREDICATE_NOT_MEMBER_ADMISSION"}
        if "builder_witnesses" in case:
            row["builder_observation"] = _builder_observation(builders, group, case, hint, call)
            row["builder_observation_scope"] = "ONLY_THIS_LITERAL_WITNESS_NOT_COMPLETE_INVERSE"
        rows.append(row)
    return {"cases": rows, "predicate_scope": "WHITE_BOX_COMPONENT",
            "full_inventory_or_profile_qualification": False}


def _helper_faults(provider, data, call):
    logical = data["groups"][0]["cases"][0]["hint"]
    prefixes = data["groups"][9]["cases"][1]["hint"]
    recipes = (
        ("RuntimeError-entry", RuntimeError("index helper external fault"), 1, logical, 1, 0),
        ("StopIteration-entry", StopIteration("index helper external fault"), 1, logical, 1, 0),
        ("public-refusal-entry", provider.ProviderInputError("unowned external fault"), 1, logical, 1, 0),
        ("StopIteration-third-tick-prefix", StopIteration("second ALL prefix"), 3, prefixes, 2, 2),
    )
    rows = []
    for name, sentinel, trip, literal, rule, tag in recipes:
        call.tick()
        hint = _immutable(literal, call)
        probe = _Probe(call, trip, sentinel)
        caught = None
        try:
            provider._conclusion_compatible(hint, rule, tag, probe)
        except BaseException as error:
            call.fault()
            if error is not sentinel:
                raise
            caught = error
        call.need(caught is sentinel and probe.calls == trip, "helper exact fault, no later callback")
        rows.append({"id": name, "same_exception_object": True,
                     "helper_callbacks": probe.calls, "trip": trip})
    return {"recipes": rows, "inventory_poison_tested": False,
            "scope": "PRIVATE_HELPER_PROPAGATION_ONLY"}


def _new(provider, encoder, fixture, modules, handles, call):
    q = _plain(fixture["query"], call)
    before = _identity(q, call)
    encoded = encoder.encode_tiny_declared_query(q, check=call.tick)
    call.need(type(encoded) is dict and set(encoded) == {"query_bytes", "receipt"}, "encoder wrapper")
    raw, receipt = encoded["query_bytes"], encoded["receipt"]
    call.need(type(raw) is bytes and receipt["complete"] is True, "complete query-only encoder")
    call.need(_identity(q, call) == before and _same(receipt["semantic_query"], q, call),
              "literal query preserved")
    call.need(_same(receipt["query_identity"], {"bytes": len(raw),
              "sha256": hashlib.sha256(raw).hexdigest()}, call), "encoded raw identity")
    parsed = modules["checker"].decode_query(raw, check=call.tick)
    fields = {key: parsed[key] for key in QUERY_KEYS}
    call.need(_same(fields, q, call) and parsed["EOF"] == len(raw), "same-byte exact query parse")
    roles = {"checker": modules["checker"], "builders": modules["builders"]}
    inv = provider.create_inventory(raw, frame=_plain(fixture["frame"], call), modules=roles, check=call.tick)
    handles.append(inv)
    state = provider.root_state(inv, check=call.tick)
    handles.append(state)
    snapshot = provider.snapshot(state, check=call.tick)
    model = {"schema": "FPC-point-model-identity-v1", "inventory_version": provider.VERSION,
             "query_hex": raw.hex(), "query": q, "frame": _plain(fixture["frame"], call)}
    call.need(_same(snapshot["model"], model, call), "fresh exact public model")
    return {"inventory": inv, "state": state, "raw": raw, "query": q,
            "frame": _plain(fixture["frame"], call), "model": model,
            "root_snapshot": snapshot, "encoding": _plain(receipt, call)}


def _step(provider, cursor, call):
    step = provider.advance(cursor, check=call.tick)
    call.need(type(step) is dict and set(step) == STEP_KEYS and step["committed"] is True,
              "exact committed provider Step")
    call.need(step["schema"] == "FPC-point-provider-step-v1" and
              step["kind"] in ("PENDING", "CANDIDATE", "EOF"), "Step kind")
    call.need((step["candidate"] is not None) == (step["kind"] == "CANDIDATE"), "Step candidate association")
    return step


def _classify(provider, bundle, handles, call, remainder=None):
    cursor = provider.open_classification(bundle["state"], (0, 0), remainder=remainder, check=call.tick)
    handles.append(cursor)
    emitted = []
    while True:
        call.tick()
        classification = provider.classification(cursor, check=call.tick)
        call.need(type(classification) is dict and set(classification) == CLASS_KEYS, "classification carrier")
        if classification["kind"] != "UNRESOLVED":
            break
        step = _step(provider, cursor, call)
        call.need(step["offer"] is None, "classification has no branch offer")
        if step["candidate"] is not None:
            emitted.append(provider.candidate_record(step["candidate"], check=call.tick))
    call.need(type(classification["coverage_complete"]) is bool, "strict coverage flag")
    if classification["kind"] in ("EMPTY", "SINGLE"):
        call.need(classification["coverage_complete"] is True, "zero/one needs complete EOF")
    return cursor, classification, emitted


def _projection(record, call):
    call.need(type(record) is dict and set(record) == RECORD_KEYS, "exact member record")
    return {key: _plain(record[key], call) for key in RECORD_KEYS if key != "key"}


def _validate_record(record, bundle, expected, call):
    projected = _projection(record, call)
    call.need(_identity(projected, call) in expected, "member in independent complete tiny domain")
    key = ["FPC-point-ground-key-v1", bundle["model"], ["ROW", 0], record["rule_tag"],
           record["subtag"], record["witness"], record["t"], record["m"]]
    call.need(_same(record["key"], key, call), "lossless exact member identity")
    return record


def _record(provider, candidate, bundle, expected, call):
    return _validate_record(provider.candidate_record(candidate, check=call.tick), bundle, expected, call)


def _tiny_public(provider, declarations, oracle, encoder, modules, call):
    by_id = {row["id"]: row for row in declarations["fixtures"]}
    results = []
    for name, amount in (("duplicate-base", 4), ("E1-single", 1)):
        call.tick()
        fixture, handles = by_id[name], []
        try:
            bundle = _new(provider, encoder, fixture, modules, handles, call)
            reference = oracle.enumerate_tiny_row_members(bundle["query"], bundle["frame"], 0,
                                                         selected=(), check=call.tick)
            call.need(reference["complete"] is True and len(reference["members"]) == amount,
                      "independent literal tiny count")
            expected = {_identity(row, call): row for row in reference["members"]}
            call.need(len(expected) == amount, "oracle full identities distinct")
            cursor, classified, emitted = _classify(provider, bundle, handles, call)
            emitted_keys = []
            for item in emitted:
                call.tick()
                _validate_record(item, bundle, expected, call)
                emitted_keys.append(_identity(item["key"], call))
            witness_keys = []
            for handle in classified["witnesses"]:
                call.tick()
                item = _record(provider, handle, bundle, expected, call)
                witness_keys.append(_identity(item["key"], call))
            call.need(emitted_keys == witness_keys and len(set(emitted_keys)) == len(emitted_keys),
                      "distinct emitted/classified witness order")
            records = []
            if amount == 1:
                call.need(classified["kind"] == "SINGLE" and len(classified["witnesses"]) == 1,
                          "E1 complete singleton")
                candidate = classified["witnesses"][0]
                records.append(_record(provider, candidate, bundle, expected, call))
                child = provider.place_state(bundle["state"], candidate, check=call.tick)
                handles.append(child)
                exported = provider.export_candidate(child, check=call.tick)
                raw = exported["candidate_certificate_bytes"]
                call.need(type(raw) is bytes and exported["receipt"]["accepted"] is False,
                          "provisional canonical fixture export")
                subject = modules["checker"].check_certificate(bundle["raw"], raw, check=call.tick)
                ref = modules["reference"].reference_check_certificate(bundle["raw"], raw, check=call.tick)
                call.need(subject["complete"] is True and subject["accepted"] is True and
                          subject["syntax_complete"] is True and subject["derivation_complete"] is True and
                          subject["final_goal_equal"] is True and subject["status"] == "VALID_DERIVATION" and
                          ref["complete_check"] is True and ref["status"] == "VALID_DERIVATION" and
                          ref["final_goal_equal"] is True, "same-byte whole fixture validators")
                export_evidence = {"certificate_identity": {"bytes": len(raw),
                    "sha256": hashlib.sha256(raw).hexdigest()}, "subject": subject, "reference": ref}
            else:
                call.need(classified["kind"] == "MANY" and classified["coverage_complete"] is False,
                          "duplicates are distinct MANY, not complete count")
                branch = provider.open_branch(bundle["state"], (0, 0), classified=cursor, check=call.tick)
                handles.append(branch)
                while True:
                    call.tick()
                    step = _step(provider, branch, call)
                    if step["kind"] == "EOF":
                        break
                    if step["kind"] != "CANDIDATE":
                        continue
                    call.need(step["offer"] is not None, "owned branch offer")
                    candidate = step["candidate"]
                    record = _record(provider, candidate, bundle, expected, call)
                    records.append(record)
                    child = provider.place_state(bundle["state"], candidate, check=call.tick)
                    handles.append(child)
                    child_domain = oracle.enumerate_tiny_row_members(bundle["query"], bundle["frame"], 0,
                        selected=[_projection(record, call)], check=call.tick)
                    call.need(child_domain["complete"] is True and child_domain["members"] == [],
                              "fully occupied one-cell leaf completely enumerated")
                    # Acknowledgement enumerates a complete positive leaf. It
                    # is deliberately NOT a false unsatisfiable-child claim.
                    provider.reject_offer(branch, step["offer"], check=call.tick)
                    before_inspection = provider.snapshot(branch, check=call.tick)
                    rem_cursor, rem, rem_emitted = _classify(provider, bundle, handles, call, remainder=branch)
                    call.need(_same(provider.snapshot(branch, check=call.tick), before_inspection, call),
                              "remainder inspection never advances branch tried/scan")
                    remaining = amount - len(records)
                    want = "EMPTY" if remaining == 0 else "SINGLE" if remaining == 1 else "MANY"
                    call.need(rem["kind"] == want, "exact tried-parent remainder classification")
                    offered_ids = {_identity(item["key"], call) for item in records}
                    for handle in rem["witnesses"]:
                        call.tick()
                        item = _record(provider, handle, bundle, expected, call)
                        call.need(_identity(item["key"], call) not in offered_ids, "remainder excludes only tried offers")
                    for item in rem_emitted:
                        call.tick()
                        _validate_record(item, bundle, expected, call)
                        call.need(_identity(item["key"], call) not in offered_ids, "remainder emissions are untried members")
                    call.need(_same(provider.snapshot(bundle["state"], check=call.tick),
                                    bundle["root_snapshot"], call), "one-cell parent semantic snapshot unchanged")
                descriptors = [[r["rule_tag"], r["subtag"], r["witness"]] for r in records]
                call.need(_same(descriptors, [[0, None, 0], [0, None, 1], [2, 0, 0], [2, 0, 1]], call),
                          "literal surviving canonical/shortcut order")
                export_evidence = {"scope": "LOW_LEVEL_COMPLETE_POSITIVE_LEAF_ENUMERATION_NOT_UNSAT"}
            keys = [_identity(r["key"], call) for r in records]
            call.need(len(keys) == len(set(keys)) == amount, "all complete identities exactly once")
            call.need({_identity(_projection(r, call), call) for r in records} == set(expected),
                      "complete tiny set equality")
            results.append({"id": name, "expected_count": amount, "oracle": reference,
                            "records_in_observed_order": records, "initial_classification": {
                                k: _plain(v, call) for k, v in classified.items() if k != "witnesses"},
                            "export_or_enumeration": export_evidence})
        except BaseException:
            _release(provider, handles, True)
            call.fault()
            raise
        _release(provider, handles, False)
    return {"fixtures": results, "scope": "REAL_PUBLIC_TINY_DOMAIN_AND_IDENTITY_ONLY"}


def _public_empty(provider, encoder, modules, fixture, call):
    handles = []
    try:
        bundle = _new(provider, encoder, fixture, modules, handles, call)
        cursor, classification, emitted = _classify(provider, bundle, handles, call)
        call.need(classification["kind"] == "EMPTY" and emitted == [] and
                  classification["witnesses"] == (), "independent single-row structural nonmembership")
        snapshot = provider.snapshot(cursor, check=call.tick)
        frontier = snapshot["inspection_frontier"]["raw"]
        call.need(frontier["eof"] is True and classification["counts"]["raw_tuples_complete"] == 0,
                  "complete family skips are not completed raw tuples")
        tags = [row["subtag"] for row in frontier["skipped_families"] if
                row["rule_tag"] == 1 and
                row["reason"] == "INCOMPATIBLE_ASSIGNED_OUTPUT_CONSTRUCTOR_SHAPE"]
        call.need(tags == [0, 3, 5], "exact independently justified shape-excluded logical tags")
        call.need(_same(provider.snapshot(bundle["state"], check=call.tick), bundle["root_snapshot"], call),
                  "classification never places/prunes a parent branch")
        evidence = {"fixture": _plain(fixture, call), "classification": {
            k: _plain(v, call) for k, v in classification.items() if k != "witnesses"},
            "raw_frontier": snapshot["inspection_frontier"]["raw"],
            "oracle_scope": "MANUAL_EXACT_SINGLE_ROW_SCHEMA_ARGUMENT_NOT_B5_ORACLE_ENUMERATION"}
    except BaseException:
        _release(provider, handles, True)
        call.fault()
        raise
    _release(provider, handles, False)
    return evidence


def _prepare_H1_normalize(provider, bundle, handles, call):
    cursor = provider.open_classification(bundle["state"], (0, 0), check=call.tick)
    handles.append(cursor)
    sibling = provider.open_classification(bundle["state"], (0, 0), check=call.tick)
    handles.append(sibling)
    while True:
        call.tick()
        snapshot = provider.snapshot(cursor, check=call.tick)
        raw = snapshot["inspection_frontier"]["raw"]
        if snapshot["phase"] == "RAW" and raw["family"] == 1 and raw["phase"] == "NORMALIZE":
            call.need(raw["product"] is None and raw["raw_index"] == 0,
                      "exact prefault H1 phase before witness product")
            return cursor, sibling, snapshot
        call.need(raw["family"] <= 1 and not snapshot["terminal"], "must reach declared public phase")
        _step(provider, cursor, call)


def _error_unchanged(error, args, attributes, call):
    call.need(_same(error.args, args, call), "fault arguments unchanged")
    now = vars(error)
    call.need(set(now) == set(attributes), "fault attribute keys unchanged")
    for key, value in attributes.items():
        call.tick()
        other = now[key]
        if other is value:
            continue
        call.need(type(value) in (str, int, bool, list, tuple, dict) or value is None,
                  "opaque original error attribute identity changed")
        call.need(_same(other, value, call), "fault attribute unchanged")


def _public_faults(provider, encoder, modules, fixture, call):
    rows = []
    for name in ("RuntimeError", "StopIteration", "public-unowned-refusal", "retained-genuine-owned-refusal"):
        call.tick()
        handles = []
        try:
            bundle = _new(provider, encoder, fixture, modules, handles, call)
            if name == "retained-genuine-owned-refusal":
                sentinel = None
                try:
                    provider.open_classification(bundle["state"], (-1, 0), check=call.tick)
                except BaseException as error:
                    call.fault()
                    call.need(provider.is_owned_error(error) is True, "retain genuine prior public refusal")
                    sentinel = error
                call.need(sentinel is not None, "prior call truly refused")
            elif name == "public-unowned-refusal":
                sentinel = provider.ProviderInputError("constructor-index external public class")
                call.need(provider.is_owned_error(sentinel) is False, "public construction is unowned")
            elif name == "StopIteration":
                sentinel = StopIteration("constructor-index helper entry")
            else:
                sentinel = RuntimeError("constructor-index helper entry")
            args, attrs = tuple(sentinel.args), dict(vars(sentinel))
            cursor, sibling, prefix = _prepare_H1_normalize(provider, bundle, handles, call)
            trip = _Probe(call, 11, sentinel)
            caught = None
            try:
                provider.advance(cursor, check=trip.tick)
            except BaseException as error:
                call.fault()
                if error is not sentinel:
                    raise
                caught = error
            call.need(caught is sentinel and trip.calls == 11, "exact Source-bound new-helper entry fault")
            later = {"calls": 0}
            late_error = RuntimeError("must never replace the first fault")
            def forbidden_callback():
                later["calls"] += 1
                raise late_error
            operations = (
                lambda: provider.advance(cursor, check=forbidden_callback),
                lambda: provider.classification(cursor, check=forbidden_callback),
                lambda: provider.snapshot(cursor, check=forbidden_callback),
                lambda: provider.classification(sibling, check=forbidden_callback),
                lambda: provider.state_section(bundle["state"], check=forbidden_callback),
            )
            for operation in operations:
                call.tick()
                retained = None
                try:
                    operation()
                except BaseException as error:
                    call.fault()
                    if error is not sentinel:
                        raise
                    retained = error
                call.need(retained is sentinel and later["calls"] == 0, "inventory/cursor poison exact first fault")
            _error_unchanged(sentinel, args, attrs, call)
            rows.append({"id": name, "prefault_public_snapshot": prefix,
                         "source_local_callback_ordinal": 11,
                         "intended_fault_observed_identically": True,
                         "subsequent_provider_callbacks": later["calls"],
                         "all_five_poison_operations_same_object": True,
                         "error_args_and_attributes_preserved": True,
                         "cleanup_memory_reclamation_observed": False})
        except BaseException:
            _release(provider, handles, True)
            call.fault()
            raise
        _release(provider, handles, False)
    return {"recipes": rows, "scope": "SOURCE_BOUND_PUBLIC_NEW_HELPER_FAULT_NOT_ALL_CALLBACK_SWEEP"}


def run_conclusion_index_controls(provider, *, fixtures, declarations, oracle, encoder, modules, check):
    """Future reviewed actual only. Complete return is not Root admission."""
    call = _Call(check)
    call.tick()
    call.need(type(modules) is dict and set(modules) == {"checker", "builders", "reference"},
              "exact three authenticated role modules")
    call.need(provider.VERSION == "FPC-POINT-FULL-FRAME-PROVIDER-v1" and
              provider.IMPLEMENTATION_REVISION == "FPC-POINT-FULL-FRAME-PROVIDER-implementation-v4" and
              "conclusion-constructor-index" in provider.FEATURES and
              callable(provider._conclusion_compatible), "exact reviewed private/public hook binding")
    call.need(_digest(fixtures, call) == FIXTURE_IDENTITY and
              _digest(declarations, call) == DECLARATION_IDENTITY, "exact independently frozen inputs")
    data = _plain(fixtures, call)
    call.need(tuple(row["id"] for row in data["groups"]) == CONTROL_IDS, "exact fourteen IDs/order")
    controls = []
    for group in data["groups"][:10]:
        call.tick()
        evidence = _shape_group(provider, modules["builders"], group, call)
        controls.append({"id": group["id"], "population": POPULATION, "status": "PASSED", "evidence": evidence})
    additions = (
        _helper_faults(provider, data, call),
        _public_faults(provider, encoder, modules, data["public_empty_fixture"], call),
        _tiny_public(provider, declarations, oracle, encoder, modules, call),
        _public_empty(provider, encoder, modules, data["public_empty_fixture"], call),
    )
    for identity, evidence in zip(CONTROL_IDS[10:], additions):
        call.tick()
        controls.append({"id": identity, "population": POPULATION, "status": "PASSED", "evidence": evidence})
    answer = _plain({"schema": RETURN_SCHEMA, "version": VERSION, "population": POPULATION,
        "complete": True, "control_ids": CONTROL_IDS, "controls": controls,
        "counts": {"groups": 14, "passed": 14, "failed": 0},
        "scope": "Additive private constructor predicate and restricted public integration only; original162/six/caps unchanged. No complete inventory/profile/conformance/cleanup/speedup/admission claim."}, call)
    call.tick()
    return answer
