"""Eight additive, unrun fixed/free-slot controls. No fixture runs on import.

Private equation checks are not public inventory qualification. Public controls
are explicitly tiny, with literal membership sets independent of both providers.
The legacy provider is used only for order equality, never to derive membership.
"""
import hashlib
import json
import math

VERSION = "L-fixed-free-slot-independent-controls-v2"
RETURN_SCHEMA = "independent-fixed-free-slot-controls-v1"
POPULATION = "fixed-free-slot8"
FIXTURE_SHA256 = "68d2397c1a563ced18a9bc7b57054215a05bbb6e306a2522e94a478ccdc44a82"
CONTROL_IDS = (
    "rigid-visible-logical-equations",
    "Q1-free-terms-public-order-EOF",
    "E2-free-body-binder-forward-aliases",
    "induction-prefix-singleton-forward",
    "MP-fixed-B-reset-unfilled-reference-order",
    "GEN-full-Gamma-unfilled-reference-domain",
    "absent-output-typed-slots-source-aliases",
    "restriction-first-fault-parent-remainder",
)
QUERY_KEYS = ("version", "claim_mode", "function_arities", "predicate_arities",
              "theory_profile", "finite_axioms", "Gamma", "goal")
_ISSUER = object()


class FixedSlotControlError(ValueError):
    """Public construction is unowned; failures are never logical negatives."""


def is_owned_error(error):
    return type(error) is FixedSlotControlError and getattr(error, "_issuer", None) is _ISSUER


class _Call:
    def __init__(self, check):
        self.check, self.first, self.callbacks = check, None, 0

    def fault(self):
        if self.first is not None:
            raise self.first

    def tick(self):
        self.fault()
        try:
            self.check()
        except BaseException as error:
            self.first = error
            raise
        self.callbacks += 1

    def need(self, condition, message):
        self.fault()
        if condition is not True:
            error = FixedSlotControlError(message)
            error._issuer = _ISSUER
            raise error


def _plain(value, call):
    call.tick()
    if value is None or type(value) in (str, bool, int):
        return value
    if type(value) is float:
        call.need(math.isfinite(value), "finite diagnostic scalar")
        return value
    if type(value) in (list, tuple):
        result = []
        for child in value:
            call.tick()
            result.append(_plain(child, call))
        return result
    call.need(type(value) is dict, "ordinary evidence carrier")
    result = {}
    for key, child in value.items():
        call.tick()
        call.need(type(key) is str, "string evidence key")
        result[key] = _plain(child, call)
    return result


def _identity(value, call):
    return json.dumps(_plain(value, call), sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False, allow_nan=False)


def _same(left, right, call):
    return _identity(left, call) == _identity(right, call)


def _immutable(value, call):
    call.tick()
    if type(value) in (tuple, list):
        children = []
        for child in value:
            call.tick()
            children.append(_immutable(child, call))
        return tuple(children)
    call.need(value is None or type(value) in (str, int, bool), "literal immutable scalar")
    return value


def _close(provider, handles, suppress):
    error = None
    for handle in reversed(handles):
        try:
            provider.close(handle)
        except BaseException as caught:
            if error is None:
                error = caught
    if error is not None and not suppress:
        raise error


def _query(encoder, modules, query, call):
    query = _plain(query, call)
    frozen = _identity(query, call)
    answer = encoder.encode_tiny_declared_query(query, check=call.tick)
    call.need(type(answer) is dict and set(answer) == {"query_bytes", "receipt"}, "query-only encoder carrier")
    raw = answer["query_bytes"]
    call.need(type(raw) is bytes and answer["receipt"]["complete"] is True, "complete immutable query")
    parsed = modules["checker"].decode_query(raw, check=call.tick)
    call.need(parsed["EOF"] == len(raw) and _same({k: parsed[k] for k in QUERY_KEYS}, query, call), "literal same-byte query fields")
    call.need(_identity(query, call) == frozen, "query input immutable")
    return raw, query


def _inventory(provider, raw, query, frame, modules, handles, call):
    roles = {key: modules[key] for key in ("checker", "builders")}
    inv = provider.create_inventory(raw, frame=_plain(frame, call), modules=roles, check=call.tick)
    handles.append(inv)
    state = provider.root_state(inv, check=call.tick)
    handles.append(state)
    model = {"schema": "FPC-point-model-identity-v1", "inventory_version": provider.VERSION,
             "query_hex": raw.hex(), "query": query, "frame": frame}
    call.need(_same(provider.snapshot(state, check=call.tick)["model"], model, call), "exact current model")
    return inv, state, model


def _semantic(goal, *, gamma=(), axioms=(), functions=(0,), predicates=(0, 0, 0, 1)):
    return {"version": 1, "claim_mode": 1, "function_arities": list(functions),
            "predicate_arities": list(predicates), "theory_profile": 0,
            "finite_axioms": list(axioms), "Gamma": list(gamma), "goal": goal}


def _plan(provider, inv, row, rule, subtag, hint, call):
    progress = provider._restriction_start(inv, row, rule, subtag, _immutable(hint, call), call)
    steps = 0
    while True:
        call.tick()
        result = provider._restriction_step(progress, inv, call)
        call.need(type(result) is tuple and len(result) == 3, "restriction step triple")
        kind, fixed, progress = result
        steps += 1
        call.need(kind in ("PENDING", "FULL_RAW", "RESTRICTED", "EMPTY"), "restriction kind")
        if kind == "PENDING":
            call.need(fixed is None, "no partial fixed descriptor")
            continue
        call.need((type(fixed) is tuple) if kind == "RESTRICTED" else fixed is None, "completed descriptor carrier")
        return {"kind": kind, "fixed": _plain(fixed, call), "steps": steps}


def _private_case(provider, encoder, modules, hint, rule, tag, expected, call, *, bound=64, kind="RESTRICTED", row=0):
    raw, query = _query(encoder, modules, _semantic(hint), call)
    handles = []
    try:
        inv, state, unused = _inventory(provider, raw, query, {"schema": "FPC-point-frame-v1", "rows": row + 1, "syntax_nodes": bound}, modules, handles, call)
        answer = _plan(provider, inv, row, rule, tag, hint, call)
        call.need(answer["kind"] == kind and _same(answer["fixed"], expected, call), "independent fixed/free equation")
    except BaseException:
        _close(provider, handles, True)
        call.fault()
        raise
    _close(provider, handles, False)
    return answer


def _expected_record(model, row, spec, call):
    rule, tag, witness, formula, refs = spec
    refs = _plain(refs, call)
    marks = [[[row, 1], ["FPC", formula]]]
    for source, value in refs:
        call.tick()
        marks.append([[source, 1], ["FPC", value]])
    marks.sort(key=lambda pair: pair[0])
    t = [[[row, 0], [1, 1]]]
    return {"key": ["FPC-point-ground-key-v1", model, ["ROW", row], rule, tag, witness, t, marks],
            "rule_tag": rule, "subtag": tag, "witness": witness, "formula": formula,
            "references": refs, "t": t, "m": marks}


def _classify(provider, state, row, handles, call, remainder=None):
    cursor = provider.open_classification(state, (row, 0), remainder=remainder, check=call.tick)
    handles.append(cursor)
    while True:
        call.tick()
        step = provider.advance(cursor, check=call.tick)
        result = provider.classification(cursor, check=call.tick)
        if result["kind"] != "UNRESOLVED":
            return cursor, result
        call.need(step["kind"] != "EOF", "EOF cannot leave unresolved domain")


def _collect(provider, raw, query, frame, row, specs, modules, call, *, positive_leaf=False):
    handles, records = [], []
    remainder_checks = 0
    try:
        inv, state, model = _inventory(provider, raw, query, frame, modules, handles, call)
        before = provider.snapshot(state, check=call.tick)
        expected = {_identity(_expected_record(model, row, spec, call), call) for spec in specs}
        call.need(len(expected) == len(specs), "literal expected full identities distinct")
        cursor, classified = _classify(provider, state, row, handles, call)
        if not specs:
            call.need(classified["kind"] == "EMPTY" and classified["coverage_complete"] is True, "complete literal EMPTY")
        else:
            call.need(classified["kind"] == "MANY" and len(classified["witnesses"]) == 2, "all positive controls intentionally MANY")
            branch = provider.open_branch(state, (row, 0), classified=cursor, check=call.tick)
            handles.append(branch)
            while True:
                call.tick()
                step = provider.advance(branch, check=call.tick)
                if step["kind"] == "EOF":
                    break
                if step["kind"] != "CANDIDATE":
                    continue
                record = provider.candidate_record(step["candidate"], check=call.tick)
                identity = _identity(record, call)
                call.need(identity in expected and all(not _same(record, old, call) for old in records), "member is literal distinct full identity")
                records.append(record)
                child = provider.place_state(state, step["candidate"], check=call.tick)
                handles.append(child)
                if positive_leaf:
                    # n1 complete leaf enumeration, NEVER an unsatisfiable-child claim.
                    call.need(frame["rows"] == 1, "positive leaf scope is n1 only")
                    leaf = provider.snapshot(child, check=call.tick)
                    call.need(_same(leaf["t_items"], [[[0, 0], [1, 1]]], call) and
                              len(leaf["selected_keys"]) == 1 and leaf["selected_keys"][0] is not None,
                              "entire n1 positive leaf is filled; no child choice remains")
                else:
                    # For the declared MP/GEN examples row0 has a fully EMPTY
                    # domain even when its required formula is unassigned.
                    unused, dead = _classify(provider, child, 0, handles, call)
                    call.need(dead["kind"] == "EMPTY" and dead["coverage_complete"] is True, "independent failed-child row0 certificate")
                provider.reject_offer(branch, step["offer"], check=call.tick)
                parent = provider.snapshot(branch, check=call.tick)
                unused, remainder = _classify(provider, state, row, handles, call, remainder=branch)
                call.need(_same(parent, provider.snapshot(branch, check=call.tick), call), "inspection is not tried-prefix advancement")
                remaining = len(specs) - len(records)
                want = "EMPTY" if remaining == 0 else "SINGLE" if remaining == 1 else "MANY"
                call.need(remainder["kind"] == want, "exact restored-parent remainder")
                remainder_checks += 1
        call.need({_identity(record, call) for record in records} == expected, "complete independently literal domain equality")
        call.need(_same(before, provider.snapshot(state, check=call.tick), call), "parent snapshot restored/unchanged")
        evidence = {"records": _plain(records, call), "complete_EOF": True,
                    "remainder_checks": remainder_checks,
                    "acknowledgement_scope": "COMPLETE_POSITIVE_N1_LEAF_ENUMERATION" if positive_leaf else "COMPLETE_EMPTY_ROW0_CHILD_DOMAIN"}
    except BaseException:
        _close(provider, handles, True)
        call.fault()
        raise
    _close(provider, handles, False)
    return evidence


def _compare(provider, baseline, encoder, modules, query, frame, row, specs, call, *, positive_leaf=False):
    raw, query = _query(encoder, modules, query, call)
    fresh = _collect(provider, raw, query, frame, row, specs, modules, call, positive_leaf=positive_leaf)
    old = _collect(baseline, raw, query, frame, row, specs, modules, call, positive_leaf=positive_leaf)
    call.need(_same(fresh["records"], old["records"], call), "same complete tiny order, independently literal membership")
    return {"current": fresh, "legacy_order_equal": True,
            "legacy_not_membership_oracle": True}


def _pa_inventory(provider, codec, modules, handles, call):
    spec = {"id": "fixed-slot-generic-PA-inventory-control", "profile": "PA_0S_PLUS_TIMES_V1",
            "profile_id": 1, "function_arities": [0, 1, 2, 2], "predicate_arities": [],
            "mode": 0, "hypotheses": [], "goal_latex": r"\(0=0\)",
            "binder_order": [], "goal_tree": ["eq", ["fun", 0, []], ["fun", 0, []]],
            "classification": "HAND_AUTHORED_PRIVATE_INVENTORY_QUALIFICATION_INPUT_NOT_SEARCH_TARGET"}
    frozen = _identity(spec, call)
    encoded = codec.encode_declared_query(spec, check=call.tick)
    raw = encoded["query_bytes"]
    call.need(type(raw) is bytes and encoded["receipt"]["complete"] is True and _identity(spec, call) == frozen, "generic PA query only")
    parsed = modules["checker"].decode_query(raw, check=call.tick)
    query = {key: parsed[key] for key in QUERY_KEYS}
    call.need(parsed["EOF"] == len(raw) and query == {"version": 1, "claim_mode": 0,
        "function_arities": [0, 1, 2, 2], "predicate_arities": [], "theory_profile": 1,
        "finite_axioms": [], "Gamma": [], "goal": ["eq", ["fun", 0, []], ["fun", 0, []]]}, "literal PA query association")
    return _inventory(provider, raw, query, {"schema": "FPC-point-frame-v1", "rows": 1, "syntax_nodes": 64}, modules, handles, call)[0]


def _induction(provider, codec, modules, call):
    # Complete hand-authored fixture trees, never an invocation of an expected builder.
    a = ["eq", ["var", 0], ["var", 0]]
    empty = ["imp", ["not", ["imp", ["eq", ["fun", 0, []], ["fun", 0, []]],
        ["not", ["all", 0, ["imp", ["eq", ["var", 0], ["var", 0]],
            ["eq", ["fun", 1, [["var", 0]]], ["fun", 1, [["var", 0]]]]]]]]],
        ["all", 0, ["eq", ["var", 0], ["var", 0]]]]
    b = ["eq", ["var", 1], ["var", 1]]
    parameter = ["all", 1, ["imp", ["not", ["imp", ["eq", ["var", 1], ["var", 1]],
        ["not", ["all", 0, ["imp", ["eq", ["var", 1], ["var", 1]],
            ["eq", ["var", 1], ["var", 1]]]]]]], ["all", 0, ["eq", ["var", 1], ["var", 1]]]]]
    handles = []
    try:
        inv = _pa_inventory(provider, codec, modules, handles, call)
        results = []
        for hint, body, parameters in ((empty, a, []), (parameter, b, [1])):
            call.tick()
            plan = _plan(provider, inv, 0, 2, 2, hint, call)
            call.need(plan["kind"] == "RESTRICTED" and _same(plan["fixed"], [body, 0], call), "unique induction body/variable")
            actual = modules["builders"].pa_induction(_plain(body, call), 0, parameters, check=call.tick)
            call.need(_same(actual, hint, call), "full independent literal induction equation")
            results.append(plan)
        bad = _plan(provider, inv, 0, 2, 2, ["imp", ["eq", ["fun", 0, []], ["fun", 0, []]], ["eq", ["fun", 0, []], ["fun", 0, []]]], call)
        call.need(bad["kind"] == "EMPTY", "induction requires core right ALL")
    except BaseException:
        _close(provider, handles, True)
        call.fault()
        raise
    _close(provider, handles, False)
    return {"literal_complete_hints": [empty, parameter], "plans": results, "bad_core": bad,
            "public_PA_domain_enumerated": False}


class _FaultProbe:
    def __init__(self, call, error):
        self.call, self.error, self.count = call, error, 0

    def tick(self):
        self.call.tick()
        self.count += 1
        raise self.error


def _faults(provider, encoder, modules, query, call):
    raw, query = _query(encoder, modules, query, call)
    results = []
    for name in ("RuntimeError", "StopIteration", "public-unowned", "retained-owned"):
        handles = []
        try:
            inv, state, unused = _inventory(provider, raw, query, {"schema": "FPC-point-frame-v1", "rows": 1, "syntax_nodes": 4}, modules, handles, call)
            if name == "retained-owned":
                error = None
                try:
                    provider.open_classification(state, (-1, 0), check=call.tick)
                except BaseException as caught:
                    call.fault()
                    call.need(provider.is_owned_error(caught) is True, "genuine earlier public refusal")
                    error = caught
                call.need(error is not None, "retained refusal exists")
            else:
                error = (RuntimeError("fixed slot deliberate fault") if name == "RuntimeError" else
                         StopIteration("fixed slot deliberate fault") if name == "StopIteration" else
                         provider.ProviderInputError("unowned fixed slot callback"))
            args, attrs = tuple(error.args), dict(vars(error))
            cursor = provider.open_classification(state, (0, 0), check=call.tick)
            handles.append(cursor)
            sibling = provider.open_classification(state, (0, 0), check=call.tick)
            handles.append(sibling)
            while True:
                call.tick()
                snapshot = provider.snapshot(cursor, check=call.tick)
                if snapshot["inspection_frontier"]["raw"]["phase"] == "BIND":
                    break
                call.need(not snapshot["terminal"], "nonvacuous public BIND phase")
                provider.advance(cursor, check=call.tick)
            probe = _FaultProbe(call, error)
            caught = None
            try:
                provider.advance(cursor, check=probe.tick)
            except BaseException as value:
                call.fault()
                if value is not error:
                    raise
                caught = value
            call.need(caught is error and probe.count == 1, "public BIND active first fault")
            later = {"count": 0}
            def forbidden():
                later["count"] += 1
                raise RuntimeError("must not replace first fault")
            for operation in (lambda: provider.advance(cursor, check=forbidden),
                              lambda: provider.classification(cursor, check=forbidden),
                              lambda: provider.snapshot(cursor, check=forbidden),
                              lambda: provider.classification(sibling, check=forbidden),
                              lambda: provider.state_section(state, check=forbidden)):
                call.tick()
                caught = None
                try:
                    operation()
                except BaseException as value:
                    call.fault()
                    if value is not error:
                        raise
                    caught = value
                call.need(caught is error and later["count"] == 0, "exact inventory poison, no F callback")
            call.need(error.args == args and vars(error) == attrs, "fault args/attributes unchanged")
            results.append({"id": name, "public_prefault_phase": "BIND", "same_first_fault": True,
                            "later_provider_callbacks": later["count"], "cleanup_observed": False})
        except BaseException:
            _close(provider, handles, True)
            call.fault()
            raise
        _close(provider, handles, False)
    # Direct hook fault is distinct from public inventory poisoning.
    handles = []
    try:
        inv, unused, ignored = _inventory(provider, raw, query, {"schema": "FPC-point-frame-v1", "rows": 1, "syntax_nodes": 4}, modules, handles, call)
        progress = provider._restriction_start(inv, 0, 1, 3, _immutable(query["goal"], call), call)
        error = StopIteration("direct private restriction callback")
        caught = None
        try:
            provider._restriction_step(progress, inv, _FaultProbe(call, error))
        except BaseException as value:
            call.fault()
            if value is not error:
                raise
            caught = value
        call.need(caught is error, "direct private callback exact identity")
    except BaseException:
        _close(provider, handles, True)
        call.fault()
        raise
    _close(provider, handles, False)
    return {"public_recipes": results, "direct_private_StopIteration": True,
            "scope": "BIND_ACTIVE_ENTRY_AND_PRIVATE_ENTRY_NOT_ALL_INTERNAL_CUTOFFS"}


def run_fixed_free_slot_controls(provider, *, baseline_provider, fixtures, encoder, codec, modules, check):
    """Future reviewed whole actual only; return supplies no proof admission."""
    call = _Call(check)
    call.tick()
    call.need(type(modules) is dict and set(modules) == {"checker", "builders", "reference"}, "three authenticated modules")
    call.need(provider.VERSION == baseline_provider.VERSION == "FPC-POINT-FULL-FRAME-PROVIDER-v1" and
              provider.IMPLEMENTATION_REVISION == "FPC-POINT-FULL-FRAME-PROVIDER-implementation-v6" and
              baseline_provider.IMPLEMENTATION_REVISION == "FPC-POINT-FULL-FRAME-PROVIDER-implementation-v4" and
              "constrained-output-slots" in provider.FEATURES, "current5 and separate legacy4")
    frozen = _identity(fixtures, call)
    call.need(hashlib.sha256(frozen.encode()).hexdigest() == FIXTURE_SHA256, "frozen independent declarations")
    by_id = {row["id"]: row for row in fixtures["fixtures"]}
    p, q, r, c = ["pred", 0, []], ["pred", 1, []], ["pred", 2, []], ["fun", 0, []]
    controls = []
    evidence = []
    for identity, tag in (("H1-visible-unique", 0), ("H2-visible-unique", 1),
                          ("H3-visible-unique", 2), ("Q2-visible-unique", 4)):
        item = by_id[identity]
        evidence.append(_private_case(provider, encoder, modules, item["hint"], 1, tag, item["fixed"], call))
    for identity, tag in (("H1-repeat-conflict", 0), ("H2-repeat-conflict", 1),
                          ("H3-repeat-conflict", 2), ("Q2-rigid-binder-conflict", 4)):
        evidence.append(_private_case(provider, encoder, modules, by_id[identity]["hint"], 1, tag, None, call, kind="EMPTY"))
    evidence.append(_private_case(provider, encoder, modules, ["imp", p, ["all", 0, p]], 1, 5, [p, 0], call))
    evidence.append(_private_case(provider, encoder, modules, ["eq", c, c], 1, 6, [c], call))
    evidence.append(_private_case(provider, encoder, modules, ["eq", c, ["var", 0]], 1, 6, None, call, kind="EMPTY"))
    controls.append(evidence)
    q1 = by_id["Q1-unused-term-aliases"]
    controls.append({"plan": _private_case(provider, encoder, modules, q1["hint"], 1, 3, [p, 0, None], call, bound=4),
        "public": _compare(provider, baseline_provider, encoder, modules, _semantic(q1["hint"]),
            {"schema": "FPC-point-frame-v1", "rows": 1, "syntax_nodes": 4}, 0,
            [[1, 3, w, q1["hint"], []] for w in q1["expected_full_witnesses"]], call, positive_leaf=True)})
    e2 = by_id["E2-body-and-unused-binder-aliases"]
    plan = _private_case(provider, encoder, modules, e2["hint"], 1, 7, [None, None, c, c], call, bound=9)
    for a, x in e2["expected_survivor_pairs_in_original_A_then_x_order"]:
        call.tick()
        value = modules["builders"].logical_axiom(7, [_plain(a, call), x, c, c], check=call.tick)
        call.need(_same(value, e2["hint"], call), "manual E2 alias forward equality")
    controls.append({"plan": plan, "manual_forward_aliases": 18, "public_F9_enumeration": False})
    controls.append(_induction(provider, codec, modules, call))
    mp_specs = [[3, None, [0, 1], p, [[0, p], [1, ["imp", p, p]]]],
                [3, None, [1, 0], p, [[1, p], [0, ["imp", p, p]]]],
                [3, None, [0, 1], p, [[0, q], [1, ["imp", q, p]]]],
                [3, None, [1, 0], p, [[1, q], [0, ["imp", q, p]]]]]
    controls.append({"fixed": _private_case(provider, encoder, modules, p, 3, None, [None, p, None, None], call, bound=3, row=2),
        "public": _compare(provider, baseline_provider, encoder, modules, _semantic(p, functions=(), predicates=(0, 0)),
            {"schema": "FPC-point-frame-v1", "rows": 3, "syntax_nodes": 3}, 2, mp_specs, call),
        "fixed_B_suffix_reset_nonvacuous": True})
    gen_goal = ["all", 0, p]
    gen_frame = {"schema": "FPC-point-frame-v1", "rows": 3, "syntax_nodes": 2}
    clear = [["all", 0, ["pred", 2, [["var", 0]]]]]
    blocked = [["not", ["not", ["pred", 2, [["var", 0]]]]]]
    gen_specs = [[4, None, [0, 0], gen_goal, [[0, p]]], [4, None, [1, 0], gen_goal, [[1, p]]]]
    controls.append({"fixed": _private_case(provider, encoder, modules, gen_goal, 4, None, [p, 0, None], call, bound=2, row=2),
        "clear": _compare(provider, baseline_provider, encoder, modules, _semantic(gen_goal, gamma=clear, functions=(), predicates=(0, 0, 1)), gen_frame, 2, gen_specs, call),
        "blocked": _compare(provider, baseline_provider, encoder, modules, _semantic(gen_goal, gamma=blocked, functions=(), predicates=(0, 0, 1)), gen_frame, 2, [], call)})
    evidence = []
    raw, query = _query(encoder, modules, _semantic(p), call)
    handles = []
    try:
        inv, unused, ignored = _inventory(provider, raw, query, {"schema": "FPC-point-frame-v1", "rows": 4, "syntax_nodes": 4}, modules, handles, call)
        for rule, tag in ((0, None), (1, 0), (1, 1), (1, 2), (1, 3), (1, 4), (1, 5), (1, 6), (1, 7), (2, 0), (3, None), (4, None)):
            result = _plan(provider, inv, 2, rule, tag, None, call)
            call.need(result["kind"] == "FULL_RAW", "no output retains entire family")
            evidence.append(result)
    except BaseException:
        _close(provider, handles, True)
        call.fault()
        raise
    _close(provider, handles, False)
    evidence.append(_private_case(provider, encoder, modules, ["eq", ["var", 4], ["var", 4]], 1, 6, None, call, bound=4, kind="EMPTY"))
    evidence.append(_private_case(provider, encoder, modules, ["eq", ["var", 0], ["var", 0]], 1, 6, [["var", 0]], call, bound=1))
    source_specs = [[0, None, 0, p, []], [0, None, 1, p, []], [2, 0, 0, p, []], [2, 0, 1, p, []]]
    source = _compare(provider, baseline_provider, encoder, modules, _semantic(p, gamma=(p, p, q), axioms=(p, p, q), functions=(), predicates=(0, 0)),
        {"schema": "FPC-point-frame-v1", "rows": 1, "syntax_nodes": 1}, 0, source_specs, call, positive_leaf=True)
    whole_outside = _compare(provider, baseline_provider, encoder, modules, _semantic(["eq", ["var", 0], ["var", 0]]),
        {"schema": "FPC-point-frame-v1", "rows": 1, "syntax_nodes": 1}, 0, [], call)
    controls.append({"private": evidence, "sources": source, "public_whole_output_outside": whole_outside})
    controls.append(_faults(provider, encoder, modules, _semantic(q1["hint"]), call))
    call.need(len(controls) == 8 and _identity(fixtures, call) == frozen, "eight groups and immutable input")
    diagnostic = _plain({"elapsed_seconds": 0.0}, call)
    call.need(type(diagnostic["elapsed_seconds"]) is float and diagnostic == {"elapsed_seconds": 0.0},
              "finite diagnostic float carrier")
    rows = []
    for identity, evidence in zip(CONTROL_IDS, controls):
        call.tick()
        rows.append({"id": identity, "population": POPULATION, "status": "PASSED", "evidence": evidence})
    answer = _plain({"schema": RETURN_SCHEMA, "version": VERSION, "population": POPULATION,
        "complete": True, "control_ids": CONTROL_IDS, "controls": rows,
        "counts": {"groups": 8, "passed": 8, "failed": 0},
        "scope": "Additive private equation/typed-slot and restricted public tiny identity/order/EOF/fault observations only. No full-profile inverse, performance, proof, cleanup or Root admission claim."}, call)
    call.tick()
    return answer
