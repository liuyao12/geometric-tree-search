"""Independent tiny whole-frame Cartesian oracle; no function runs on import.

An authenticated independent row oracle is injected only inside future custody.
No provider/controller/checker/builder/encoder/fixture or other module is imported.
No scheduler, generation, branch cursor, exclusion or certificate is produced.
"""

VERSION = "L-tiny-FPC-frame-completion-reference-v1"
_OWNER = object()


class TinyFrameReferenceInputError(ValueError):
    pass


def is_owned_error(error):
    return type(error) is TinyFrameReferenceInputError and getattr(error, "_owner", None) is _OWNER


class _Call:
    def __init__(self, check):
        self.check = check
        self.first = None

    def tick(self):
        if self.first is not None:
            raise self.first
        try:
            self.check()
        except BaseException as error:
            self.first = error
            raise

    def need(self, condition, message):
        if self.first is not None:
            raise self.first
        if not condition:
            error = TinyFrameReferenceInputError(message)
            error._owner = _OWNER
            raise error


def _copy(value, call):
    call.tick()
    if value is None or type(value) in (str, int, bool):
        return value
    if type(value) in (list, tuple):
        result = []
        for child in value:
            call.tick()
            result.append(_copy(child, call))
        return result
    call.need(type(value) is dict, "ordinary literal/reference carrier")
    result = {}
    for key, child in value.items():
        call.tick()
        call.need(type(key) is str, "string field")
        result[key] = _copy(child, call)
    return result


def enumerate_literal_frame_completions(query, frame, *, row_oracle, check):
    """All compatible fixed-row member tuples for an explicitly tiny input.

    Finite enumeration may still exceed the unchanged whole caps. A fault yields
    no normal output and no empty/completed-prefix authority. Runtime controls
    will use only the already frozen seven literal tiny queries, not six targets.
    """
    call = _Call(check)
    call.tick()
    call.need(type(frame) is dict and set(frame) == {"schema", "rows", "syntax_nodes"}, "exact frame")
    call.need(frame["schema"] == "FPC-point-frame-v1", "frame schema")
    n, b = frame["rows"], frame["syntax_nodes"]
    call.need(type(n) is int and 1 <= n <= 4 and type(b) is int and 1 <= b <= 3,
              "tiny diagnostic frame only")
    source = _copy(query, call)
    selected = []
    solutions = []
    metrics = {"prefixes": 0, "row_domain_queries": 0, "member_choices": 0}

    def visit(row):
        call.tick()
        metrics["prefixes"] += 1
        if row == n:
            solutions.append(_copy(selected, call))
            return
        result = row_oracle.enumerate_tiny_row_members(
            source, frame, row, selected=selected, check=call.tick)
        call.need(result["schema"] == "independent-tiny-FPC-row-members-v1"
                  and result["complete"] is True, "complete current row oracle")
        call.need(result["row"] == row and result["selected_rows"] == list(range(row)),
                  "fixed ascending Cartesian prefix")
        metrics["row_domain_queries"] += 1
        for member in result["members"]:
            call.tick()
            metrics["member_choices"] += 1
            selected.append(_copy(member, call))
            try:
                visit(row + 1)
            finally:
                selected.pop()

    visit(0)
    call.tick()
    return {"schema": "independent-tiny-FPC-frame-completions-v1",
            "version": VERSION, "complete": True, "frame": _copy(frame, call),
            "solution_count": len(solutions), "solutions": solutions,
            "metrics": metrics,
            "scope": "Fixed-row Cartesian completion of tiny profile0 literal inputs only; no controller/scheduler trace, proof bytes, admission or full-frame performance claim"}
