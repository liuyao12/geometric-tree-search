"""Prepare six prospective JSON plans only, after exact component reviews.

AST literal constants and raw metadata are read, never executed research code.
No query, certificate, scientific input, control, search or actual is generated.
"""
from pathlib import Path
import ast
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parent
N = ROOT.parent
EXPERIMENT = 'point-frame-constructor-index-v2'


def read(path):
    return json.loads(Path(path).read_bytes())


def pin(path):
    p = Path(path).resolve()
    assert p.is_file() and not p.is_symlink() and '.partial' not in p.name
    raw = p.read_bytes()
    return {'path': str(p), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def verify(ref):
    assert pin(ref['path']) == ref


def emit(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as f:
        f.write((json.dumps(value, indent=2) + '\n').encode())
    return pin(path)


assert len(sys.argv) == 3
worker_review_path, bank_review_path = [Path(x).resolve() for x in sys.argv[1:]]
assert worker_review_path.is_relative_to(N / 'diagnostics-L')
assert bank_review_path.is_relative_to(N / 'review-C')
worker_review, bank_review = read(worker_review_path), read(bank_review_path)
assert worker_review['review_passed'] is True and bank_review['review_passed'] is True
worker = N / 'implementation-B/fpc_point_frame_search_worker_v2.py'
worker_raw = worker.read_bytes()
worker_pin = pin(worker)
assert worker_pin['sha256'] in json.dumps(worker_review)
constants = {}
wanted = {'EXPERIMENT', 'PROTOCOL_SCHEMA', 'MODULE_ROLES', 'CONTROL_IDS', 'CAPS', 'PRODUCTION_CONFIGURATION'}
for node in ast.parse(worker_raw).body:
    if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
        if node.targets[0].id in wanted:
            constants[node.targets[0].id] = ast.literal_eval(node.value)
assert set(constants) == wanted and constants['EXPERIMENT'] == EXPERIMENT
assert constants['PROTOCOL_SCHEMA'] == 'Root-FPC-point-frame-protocol-v1'
old = read(ROOT / 'plans/point-frame-full-FPC-v1-target-0.json')
assert constants['CAPS'] == old['limits'] and constants['PRODUCTION_CONFIGURATION'] == old['search_configuration']
api_path = N / 'implementation-B/point-frame-worker-API-v2.json'
offer_path = N / 'implementation-B/point-frame-worker-dependency-offer-v2.json'
api, offer = read(api_path), read(offer_path)
modules = {x['role']: x['rawpin'] for x in offer['runtime_roles']}
assert len(modules) == 23 and set(modules) == set(constants['MODULE_ROLES'])
assert set(modules) == set(old['module_pins']) | {'conclusion_index_bank'}
assert {x['role']: {k: x[k] for k in ('path', 'bytes', 'sha256')} for x in api['runtime_roles']} == modules
for role, ref in modules.items():
    verify(ref)
    assert ref['sha256'].encode() in worker_raw, 'worker lacks fixed pin: ' + role
    if role in old['module_pins'] and role != 'provider':
        assert ref == old['module_pins'][role]
assert modules['provider'] == pin(N / 'implementation-B/fpc_full_frame_inventory_v4.py')
assert modules['conclusion_index_bank']['sha256'] in json.dumps(bank_review)
populations = {x['population']: {k: x[k] for k in ('control_ids', 'groups', 'bank_role', 'subject_role', 'scope')}
               for x in api['scoped_populations']}
assert len(populations) == 10 and set(populations) == set(constants['CONTROL_IDS'])
for name, item in old['control_populations'].items():
    assert populations[name] == item and list(constants['CONTROL_IDS'][name]) == item['control_ids']
assert populations['constructor-index14']['groups'] == 14
for name, item in populations.items():
    assert item['control_ids'] == list(constants['CONTROL_IDS'][name]) and item['groups'] == len(item['control_ids'])
assert sum(x['groups'] for x in populations.values()) == 176
assert api['limits'] == old['limits'] and api['search_configuration'] == old['search_configuration']
custody = {x['role']: x['rawpin'] for x in offer['custody_runtime']}
assert set(custody) == {'runner', 'observer', 'python'}
assert custody['python'] == old['python'] and custody['runner']['path'] == old['runner_path']
inputs = {x['role']: x['rawpin'] for x in offer['raw_inputs']}
assert set(inputs) == {'six_declarations', 'target_authority_reference', 'explicit_raw13',
                       'tiny_seven_declarations', 'conclusion_index_fixtures'}
for key, role in (('declarations', 'six_declarations'), ('target_authority', 'target_authority_reference'),
                  ('explicit_raw_models', 'explicit_raw13'), ('tiny_provider_declarations', 'tiny_seven_declarations')):
    assert inputs[role] == old[key]
declarations = read(inputs['six_declarations']['path'])
assert len(declarations['targets']) == 6
recipes = [{'case_id': EXPERIMENT + '-target-' + str(i), 'target_index': i, 'target_id': x['id']}
           for i, x in enumerate(declarations['targets'])]
guards = {}


def guard(ref):
    verify(ref)
    assert ref['path'] not in guards or guards[ref['path']] == ref
    assert '/actual/' not in ref['path'] and not ref['path'].endswith('.bin')
    guards[ref['path']] = ref


# Retain the full original70 guard set as historical Source/input guards;
# only new23 explicit runtime roles execute. No accepting record is intake.
for ref in (old['files'] + list(modules.values()) + list(custody.values()) + list(inputs.values())
            + offer['semantic_guards']):
    guard(ref)
for path in (
    worker, Path(__file__), worker_review_path, bank_review_path, api_path, offer_path,
    N / 'implementation-B/point-frame-worker-Source-handoff-v2.json',
    N / 'implementation-B/point-frame-worker-manual-conformance-v2.json',
    N / 'implementation-B/point-frame-worker-static-v2.json',
    N / 'implementation-B/full-frame-provider-Source-handoff-v4-r2.json',
    N / 'implementation-B/full-frame-provider-conclusion-index-API-v4.json',
    N / 'implementation-B/full-frame-provider-conclusion-index-manual-v4-r2.json',
    N / 'implementation-B/full-frame-provider-dependency-closure-v4.json',
    N / 'review-C/typed-full-frame-provider-conclusion-index-complete-Source-review-v4-r2.json',
    N / 'diagnostics-L/structural-provider-index-independent-handoff-v1.json',
    N / 'diagnostics-L/primitive-conclusion-constructor-facts-v1.json',
    N / 'diagnostics-L/structural-provider-index-independent-fixtures-v1.json',
    N / 'diagnostics-L/typed-full-frame-provider-conclusion-index-component-Source-review-v4.json',
    N / 'diagnostics-L/typed-full-frame-provider-conclusion-index-documentation-r2-review-v1.json',
    ROOT / 'point-frame-provider-v4-r2-Root-component-Source-acceptance-v1.json'):
    guard(pin(path))
metadata = read(ROOT / 'point-frame-whole-protocol-v1.json')['metadata']
metadata.update({
    'status': 'PROSPECTIVE_CONSTRUCTOR_INDEX_STUDY_NO_EXECUTION',
    'current_worker': worker_pin, 'component_review': pin(worker_review_path),
    'additive_bank_review': pin(bank_review_path),
    'original_guard_count_retained': 70,
    'active_namespaces': 23, 'scoped_group_count': 176,
    'structural_index_scope': 'New common syntactic generation index only. Same finite member universe/order/identity and unchanged point/controller/six-declaration semantics. Not a learned marking, lemma-family or RL effect; no matched performance baseline.',
    'control_extension': 'All original162/nine ordered scoped populations/subjects unchanged. Fourteen explicitly additional constructor-index groups: labeled helper properties and separately tiny public integration/fault checks, not all-profile membership/completeness proof.',
    'old_case_boundary': 'All six previous point-frame-full-FPC-v1 actuals remain consumed. This changed-Source new study uses fresh cases and no previous proof/query bytes/result/qualification/cache/policy.',
    'six_statuses': [{'target_index': x['target_index'], 'target_id': x['target_id'], 'status': 'NOT_RUN'} for x in recipes],
    'initial_selection': recipes[0]})
metadata['stages'].insert(4, 'Additive constructor-index14 under separately reviewed exact Source/data/API')
metadata['admission'] = metadata['admission'].replace('complete scoped162', 'complete original162 plus additional14 (176 total)')
protocol = {'schema': constants['PROTOCOL_SCHEMA'], 'experiment': EXPERIMENT,
            'limits': constants['CAPS'], 'module_pins': modules,
            'control_populations': populations, 'job_recipes': recipes, 'metadata': metadata}
protocol_pin = emit(ROOT / 'constructor-index-whole-protocol-v1.json', protocol)
guard(protocol_pin)
files = [guards[k] for k in sorted(guards)]
cases = []
for recipe in recipes:
    i = recipe['target_index']
    actual = N / 'actual' / recipe['case_id']
    grant_path = ROOT / 'grants' / (recipe['case_id'] + '.json')
    for p in (actual, Path(str(actual) + '.observer'), grant_path):
        assert not p.exists() and not p.is_symlink()
    plan = dict(old, **recipe, experiment=EXPERIMENT, actual_dir=str(actual), worker_path=str(worker),
                protocol=protocol_pin, files=files, module_pins=modules, control_populations=populations,
                conclusion_index_fixtures=inputs['conclusion_index_fixtures'])
    plan_pin = emit(ROOT / 'plans' / (recipe['case_id'] + '.json'), plan)
    closure_pin = emit(ROOT / f'constructor-index-target-{i}-Source-closure-v1.json', {
        'schema': 'Root-constructor-index-closed-Source-v1',
        'status': 'PROSPECTIVE_EXACT_CLOSED_GUARDS_NOT_EXECUTION_AUTHORITY',
        'plan': plan_pin, 'protocol': protocol_pin, 'files': files,
        'namespace_count': 23, 'module_roles_in_execution_order': list(constants['MODULE_ROLES']),
        'scoped_group_count': 176, 'scoped_population_count': 10, 'six_recipes': recipes,
        'closure_rule': 'Original70 raw guards preserved, plus explicit current23 runtime/five raw inputs and named Source/API/review guards. No recursive citation eligibility or actual/accepting record intake. Plan/closure separately reviewed and grant-bound; no self-hash.',
        'scientific_imports_calls': 0, 'query_proof_encoding': 0, 'actuals_created': 0})
    proposal_pin = emit(ROOT / f'constructor-index-target-{i}-grant-proposal-v1.json', {
        'schema': 'Root-point-frame-once-grant-proposal-v1', 'authorized': False, 'review_passed': False,
        'uses': 1, 'case_id': recipe['case_id'], 'plan_sha256': plan_pin['sha256'],
        'runner_sha256': custody['runner']['sha256'], 'observer_sha256': custody['observer']['sha256'],
        'plan': plan_pin, 'protocol': protocol_pin, 'closure': closure_pin,
        'component_review': pin(worker_review_path), 'additive_bank_review': pin(bank_review_path),
        'prospective_grant_path': str(grant_path),
        'prospective_command': [custody['python']['path'], '-I', '-S', '-B', custody['observer']['path'], plan_pin['path'], str(grant_path)],
        'required_before_separate_grant': ['Independent complete exact new whole Source/phase/plan/closure/proposal review', 'Root acceptance, current exact raw pins and absent actual/observer/finalgrant paths', 'Fresh all-agents/tools-idle observation and separately bound Root one-use true grant'],
        'scope': 'False proposal only; no runtime or resource qualification, oldcase retry or positive prefix authority.'})
    cases.append({'recipe': recipe, 'plan': plan_pin, 'closure': closure_pin, 'proposal': proposal_pin})
preparation = emit(ROOT / 'constructor-index-study-preparation-v1.json', {
    'schema': 'Root-constructor-index-six-target-preparation-v1',
    'status': 'PROSPECTIVE_METADATA_REQUIRES_WHOLE_REVIEW_AND_DISTINCT_TRUE_GRANTS',
    'metadata_builder': pin(Path(__file__)), 'worker': worker_pin,
    'worker_component_review': pin(worker_review_path), 'bank_component_review': pin(bank_review_path),
    'protocol': protocol_pin, 'cases': cases, 'shared_guards': len(files),
    'namespaces': 23, 'scoped_populations': 10, 'scoped_groups': 176,
    'original162_and70guards_preserved': True, 'original_six_statements_caps_and_configuration_unchanged': True,
    'all18_actual_observer_finalgrant_paths_absent': True,
    'all_new_false_proposals': True, 'scientific_imports_calls': 0, 'query_proof_encoding': 0,
    'old_case_replay': False, 'goal_complete': False})
print(json.dumps(preparation, indent=2))
