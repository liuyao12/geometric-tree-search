"""Prepare exact prospective metadata only; never import scientific code.

The worker's literal constants are read through AST, not executed. No codec,
checker, helper, fixture, query, proof, search or actual is constructed or run.
The resulting unauthorized grant proposal is NOT a runnable grant.
"""
from pathlib import Path
import ast
import hashlib
import json
import sys


STUDY = Path(__file__).resolve().parents[1]
ROOT = STUDY / "root"
REPO = STUDY.parents[1]


def pin(path):
    path = Path(path)
    assert path.is_absolute() and path.resolve() == path and not path.is_symlink()
    assert path.is_file() and ".partial" not in path.name
    raw = path.read_bytes()
    return {"path": str(path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def save(path, value):
    assert not path.exists(), "frozen output exists"
    path.parent.mkdir(parents=True, exist_ok=True)
    raw = (json.dumps(value, indent=2, ensure_ascii=True, allow_nan=False) + "\n").encode()
    with path.open("xb") as stream:
        stream.write(raw)
    return pin(path)


review_path = Path(sys.argv[1]).resolve()
assert review_path.is_relative_to(STUDY / "review-C")
review = json.loads(review_path.read_bytes())
assert review.get("review_passed") is True
worker = STUDY / "implementation-B/fpc_point_frame_search_worker_v1.py"
assert pin(worker)["sha256"] == "e9dad16f64a2f596342f5081b19318b72e2a7f0e788ebc8e57235de8af85fc0a"
assert pin(worker)["sha256"] in json.dumps(review)
tree = ast.parse(worker.read_bytes())
wanted = {"MODULE_ROLES", "CONTROL_IDS", "CAPS", "PRODUCTION_CONFIGURATION", "FIXED_PINS", "CONTROLLER_BANK_PIN"}
constants = {}
for node in tree.body:
    if type(node) is ast.Assign and len(node.targets) == 1 and type(node.targets[0]) is ast.Name:
        name = node.targets[0].id
        if name in wanted:
            constants[name] = ast.literal_eval(node.value)
assert set(constants) == wanted
api = json.loads((STUDY / "implementation-B/point-frame-worker-API-v1.json").read_bytes())
offer = json.loads((STUDY / "implementation-B/point-frame-worker-dependency-offer-v1.json").read_bytes())
module_pins = {row["role"]: row["rawpin"] for row in offer["runtime_roles"]}
assert len(module_pins) == 22 and set(module_pins) == set(constants["MODULE_ROLES"])
fixed = dict(constants["FIXED_PINS"], controller_bank=constants["CONTROLLER_BANK_PIN"])
for role, row in module_pins.items():
    assert pin(row["path"]) == row
    assert (row["bytes"], row["sha256"]) == fixed[role]
assert {row["role"]: {k: row[k] for k in ("path", "bytes", "sha256")} for row in api["runtime_roles"]} == module_pins
populations = {row["population"]: {k: row[k] for k in ("control_ids", "groups", "bank_role", "subject_role", "scope")}
               for row in api["scoped_populations"]}
assert set(populations) == set(constants["CONTROL_IDS"])
for name, ids in constants["CONTROL_IDS"].items():
    assert populations[name]["control_ids"] == list(ids)
    assert populations[name]["groups"] == len(ids)
assert sum(len(row["control_ids"]) for row in populations.values()) == 162
assert constants["CAPS"] == api["limits"] and constants["PRODUCTION_CONFIGURATION"] == api["search_configuration"]
runtime = {row["role"]: row["rawpin"] for row in offer["custody_runtime"]}
assert set(runtime) == {"runner", "observer", "python"}
inputs = {row["role"]: row["rawpin"] for row in offer["raw_inputs"]}
assert set(inputs) == {"six_declarations", "target_authority_reference", "explicit_raw13", "tiny_seven_declarations"}
declarations = json.loads(Path(inputs["six_declarations"]["path"]).read_bytes())
assert len(declarations["targets"]) == 6
experiment = "point-frame-full-FPC-v1"
recipes = [{"case_id": experiment + "-target-" + str(i), "target_index": i, "target_id": row["id"]}
           for i, row in enumerate(declarations["targets"])]
assert recipes[0]["target_id"] == "PA-reflexivity"
case = recipes[0]
actual = STUDY / "actual" / case["case_id"]
assert not actual.exists() and not Path(str(actual) + ".observer").exists()
guards = {}


def guard(row):
    assert pin(row["path"]) == row
    old = guards.get(row["path"])
    assert old is None or old == row
    guards[row["path"]] = row


for row in list(module_pins.values()) + list(runtime.values()) + list(inputs.values()) + offer["semantic_guards"]:
    guard(row)
additional = [
    worker, Path(__file__).resolve(), review_path,
    STUDY / "implementation-B/point-frame-worker-API-v1.json",
    STUDY / "implementation-B/point-frame-worker-manual-conformance-v1.json",
    STUDY / "implementation-B/point-frame-worker-dependency-offer-v1.json",
    STUDY / "implementation-B/point-frame-worker-Source-handoff-v1.json",
    STUDY / "review-C/typed-full-frame-controller-independent-bank-full-Source-review-v1.json",
    STUDY / "review-C/typed-full-frame-controller-independent-bank-successor-Source-review-v2.json",
    STUDY / "review-C/typed-explicit-point-kernel-full-Source-review-v2.json",
    STUDY / "review-C/typed-explicit-point-independent-oracle-bank-Source-review-v1.json",
    STUDY / "review-C/typed-tiny-full-provider-reference-encoder-controls-full-Source-review-v1.json",
    STUDY / "diagnostics-L/typed-controller-bank-provider-post-freeze-Source-interoperability-review-v1.json",
    ROOT / "point-frame-worker-metadata-directive-v1.json",
    ROOT / "point-proof-search-integration-decision-v1.json",
    ROOT / "point-proof-new-model-selection-v1.json",
]
for path in additional:
    guard(pin(path))
protocol = {
    "schema": "Root-FPC-point-frame-protocol-v1", "experiment": experiment,
    "limits": constants["CAPS"], "module_pins": module_pins,
    "control_populations": populations, "job_recipes": recipes,
    "metadata": {
        "status": "PROSPECTIVE_EXACT_WHOLE_DECLARATION_NO_EXECUTION",
        "source_scope": "Closed named runtime/input/semantic sources; no old proof, query bytes, accepting state, policy, library or actual-result intake. No physical query or proof is prepared here.",
        "current_worker": pin(worker), "component_review": pin(review_path),
        "search_configuration": constants["PRODUCTION_CONFIGURATION"],
        "model": "Full declared finite-FPC row inventory; exactly one unit occupancy tile per required generation-zero row; translations only, complete formula markings at own/earlier ports. No geometry or additional learned marking. All fixed Gamma governs GEN, even outside syntax envelope. Every primitive family available from start.",
        "domain_and_scheduler": "Provider exact immutable state_section is t/m authority. Complete intensional domains include unseen placements. Any complete EMPTY kills; otherwise resolve every row before SINGLE propagation or earliest-root branching. MANY certifies at least two only. Exact dependency-prefix reuse includes incoming remote marks/refcounts. Exact parent/actual offer/revision remainder retained; unknown fuel/errors never reject a child.",
        "coverage": "Fresh fair diagonal frame restarts with goal-only lower bound and increasing local fuel; Source-conditional unlimited finite-proof coverage, no fixed-budget fit or global nonprovability claim. No supplied proof, frame size, proof length, strategy or target-ID algorithm dispatch.",
        "stages": ["Fresh observer/parent/worker clocks and exact pin intake", "Cold authenticated imports and independent in-job target encoding/freezing before controls", "Original baseline56, obligation47, INTRO1, regression2 and point20 on their original subjects", "Generic explicit13 plus safety3, tiny-provider10, controller10-v2", "Cold generic current point-frame dovetail", "On candidate: same immutable bytes to both original validators, then paired point reduction and mutation check", "Full Source rehash, complete serialization/output and post-output resources", "Waited/reaped parent and separate observer whole gates, independent actual review, Root disposition"],
        "resource_semantics": "All ten original caps unchanged. Root work includes hashes/imports/encoding/controls/setup/search/validation/serialization; no off-clock preparation. Worker180/parent210/observer225 fallback use original exact sources and independent whole post-output peak/physical/EOF checks. Whole memory is strictly below1GiB; unavailable qualified peak is null, never measured zero. Native fields zero explicitly vacuous; no Native process/table/oracle.",
        "output_semantics": "One complete result or failure at most48MiB, no truncation/sharding. Worker log_bytes ceiling is per stdout/stderr stream as implemented by unchanged runner. Observer logs1MiB each plus1MiB receipt and parent terminal4MiB are covered by9MiB reserved outer allowance; aggregate physical128MiB remains mandatory. Every output copy/allocation belongs to final custody/observer gates.",
        "once_and_failure": "Actual and observer directories must not exist. One separately issued Root grant; CONSUMED enforces same plan/grant/case/uses1. Do not restart a consumed case, rescue a prefix, repeat for diagnostics or shrink population/caps. Poll a still-live tool handle rather than restarting. Partial files may be hashed/archived but never parsed. Any fault suppresses all seven positive payloads; complete raw input/candidate files confer no prefix authority. Stage labels alone are not a qualified bank result. No negative theorem or non-tiling claim from timeout/memory/UNKNOWN.",
        "admission": "Worker membership export accepted=false is provisional. Require original subject complete/accepted/syntax/derivation/no-prefix/final-goal/raw-byte gates and independent reference distinct complete_check/status/final_goal gates on identical query/certificate bytes. Only then same subject parsed rows point reduction, before/after immutability and exact row count. Require complete scoped162, stable Source/input/config/model associations, positive normal worker/parent/observer exits, strict whole resources, complete EOF/logs, current independent actual review and separate Root disposition.",
        "metrics_and_claim_limits": "No GCTS/RL benefit, general geometry theorem, strict fixed finite Wang palette or plane-tiling claim. Current controller lacks aggregate provider elimination counts; report unsupported, never zero. Do not claim complete benchmark reporting or speedup. Generic shared/fractional/nontrivial-generation controls remain separately scoped from logical unit rows. Initial reflexivity is an elementary equality development target, not substantive arithmetic discovery.",
        "six_statuses": [{"target_index": row["target_index"], "target_id": row["target_id"], "status": "NOT_RUN"} for row in recipes],
        "initial_selection": case,
    },
}
protocol_pin = save(ROOT / "point-frame-whole-protocol-v1.json", protocol)
guard(protocol_pin)
plan = {
    "schema": "proof-search-case-once-plan-v1", **case, "stage": "evaluate", "experiment": experiment,
    "required_upstream_ids": [], "actual_dir": str(actual), "worker_path": str(worker),
    "runner_path": runtime["runner"]["path"], "python": runtime["python"], "protocol": protocol_pin,
    "files": [guards[name] for name in sorted(guards)], "module_pins": module_pins,
    "declarations": inputs["six_declarations"], "target_authority": inputs["target_authority_reference"],
    "control_populations": populations, "search_configuration": constants["PRODUCTION_CONFIGURATION"],
    "explicit_raw_models": inputs["explicit_raw13"], "tiny_provider_declarations": inputs["tiny_seven_declarations"],
    "limits": constants["CAPS"],
}
plan_pin = save(ROOT / "plans" / (case["case_id"] + ".json"), plan)
closure_pin = save(ROOT / "point-frame-whole-Source-closure-v1.json", {
    "schema": "Root-point-frame-closed-Source-v1", "status": "PROSPECTIVE_EXACT_CLOSED_GUARDS_NOT_EXECUTION_AUTHORITY",
    "plan": plan_pin, "protocol": protocol_pin, "files": plan["files"],
    "namespace_count": len(module_pins), "module_roles_in_execution_order": list(constants["MODULE_ROLES"]),
    "scoped_group_count": 162, "scoped_population_count": len(populations), "six_recipes": recipes,
    "closure_rule": "Exact named runtime22, custody3, rawinputs4 and semantic/Source/review guards. No recursive pin chasing, old accepting results, actuals or partials. Plan and closure themselves are separately pinned by reviews/grant; no self-referential hash required.",
    "operations": {"scientific_imports_calls": 0, "query_proof_encoding": 0, "actuals_created": 0},
})
proposal_pin = save(ROOT / "point-frame-target-0-grant-proposal-v1.json", {
    "schema": "Root-point-frame-once-grant-proposal-v1", "authorized": False, "review_passed": False,
    "uses": 1, "case_id": case["case_id"], "plan_sha256": plan_pin["sha256"],
    "runner_sha256": runtime["runner"]["sha256"], "observer_sha256": runtime["observer"]["sha256"],
    "plan": plan_pin, "protocol": protocol_pin, "closure": closure_pin,
    "component_review": pin(review_path), "prospective_grant_path": str(ROOT / "grants" / (case["case_id"] + ".json")),
    "prospective_command": [runtime["python"]["path"], "-I", "-S", "-B", runtime["observer"]["path"], plan_pin["path"], str(ROOT / "grants" / (case["case_id"] + ".json"))],
    "required_before_separate_grant": ["Independent exact whole-composition/protocol/plan/closure/proposal review", "Root acceptance of complete review and unchanged exact pins/fresh absent directories", "Fresh all-tools-idle barrier across agents, no active scientific/browser/network/server work", "Separately issue one Root grant authorized=true/review_passed=true, bind exact review+barrier, then execute once"],
    "scope": "Unauthorized proposal only. No worker/helper/checker/codec/search/fixture operation or actual performed. Original six,162scoped IDs,ten caps and consumed negatives preserved.",
})
readiness = save(ROOT / "point-frame-whole-preparation-v1.json", {
    "schema": "Root-point-frame-whole-preparation-v1", "status": "EXACT_METADATA_PREPARED_REVIEW_REQUIRED",
    "metadata_builder": pin(Path(__file__).resolve()), "worker": pin(worker), "component_review": pin(review_path),
    "protocol": protocol_pin, "closure": closure_pin, "plan": plan_pin, "grant_proposal": proposal_pin,
    "guards": len(guards), "namespaces": 22, "scoped_groups": 162, "six_recipes": 6,
    "actual_and_observer_absent": True, "scientific_imports_calls": 0, "query_proof_encoding": 0,
    "grant_issued": False, "goal": "ACTIVE/unbudgeted/incomplete",
})
print(json.dumps(readiness, indent=2))
