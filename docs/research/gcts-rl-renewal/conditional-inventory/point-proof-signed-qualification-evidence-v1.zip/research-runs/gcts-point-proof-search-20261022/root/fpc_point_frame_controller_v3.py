"""Full finite-frame point search with fixed diagnostic checkpoints. Source only.

Diagnostics are observations through committed phase checkpoints, never proof
or qualified-prefix authority; interrupted-phase work can be absent.

The provider owns logical membership and immutable point state. This controller
owns global scheduling and finite child-exhaustion authority. A returned candidate
is NOT an accepted proof; the original same-byte dual validators remain required.
No proof routes, imported histories, learner policy or external state are inputs.
"""
VERSION = "FPC-POINT-FRAME-CONTROLLER-v3"
PROVIDER_VERSION = "FPC-POINT-FULL-FRAME-PROVIDER-v1"
REQUIRED_FEATURE = "dependency-rebind-classification"
_OWNER = object()
_METRICS = ("atomic_steps", "callbacks", "state_creations", "classifier_opens",
            "classifier_advances", "domain_completions", "global_scans",
            "forced_moves", "branch_nodes", "offers", "backtracks",
            "reject_offers", "max_path_depth", "max_frontier",
            "classifiers_rebound", "domains_invalidated")
PHASES = ("INVENTORY", "ROOT", "DEPENDENCY", "LOAD", "REUSE", "SCAN",
          "CLASSIFY_OPEN", "CLASSIFY_ADVANCE", "FORCE_PLACE", "BRANCH_OPEN",
          "OFFER", "OFFER_PLACE", "BACKTRACK", "EXPORT")


class FrameInputError(ValueError):
    """Public constructor alone does not mint an owned refusal."""


class FrameProtocolError(RuntimeError):
    """Unexpected provider/controller disagreement, never an empty domain."""


def is_owned_error(error):
    return type(error) is FrameInputError and getattr(error, "_owner", None) is _OWNER


class _Call:
    def __init__(self, check):
        if not callable(check):
            raise TypeError("genuine bounded check required")
        self.check, self.first, self.callbacks = check, None, 0
        self.token = object()

    def tick(self):
        if self.first is not None:
            raise self.first
        self.callbacks += 1
        try:
            self.check()
        except BaseException as error:
            self.first = error
            raise

    def need(self, condition, message):
        if self.first is not None:
            raise self.first
        if condition is not True:
            error = FrameInputError(message)
            error._owner, error._call = _OWNER, self.token
            raise error

    def protocol(self, condition, message):
        if self.first is not None:
            raise self.first
        if condition is not True:
            raise FrameProtocolError(message)


def _nat(value):
    return type(value) is int and value >= 0


def _equal(left, right, call):
    """No recursive Python equality, hashes, or equality on opaque handles."""
    pending = [(left, right)]
    while pending:
        call.tick()
        a, b = pending.pop()
        if a is b:
            continue
        if type(a) is not type(b):
            return False
        if type(a) is tuple:
            if len(a) != len(b):
                return False
            for i in range(len(a)):
                call.tick()
                pending.append((a[i], b[i]))
        elif type(a) in (str, int, bool, bytes, type(None)):
            if a != b:
                return False
        else:
            return False
    return True


def _context(query_bytes, provider, modules, call):
    call.tick()
    call.need(type(query_bytes) is bytes, "exact immutable query bytes required")
    call.need(type(modules) is dict and len(modules) == 2 and
              "checker" in modules and "builders" in modules, "exact checker/builders modules")
    call.need(getattr(provider, "VERSION", None) == PROVIDER_VERSION and
              REQUIRED_FEATURE in getattr(provider, "FEATURES", ()), "dependency-aware provider required")
    return {"checker": modules["checker"], "builders": modules["builders"]}


def _frame_copy(frame, call):
    call.tick()
    call.need(type(frame) is dict and len(frame) == 3 and
              set(frame) == {"schema", "rows", "syntax_nodes"}, "strict frame keys")
    call.need(frame["schema"] == "FPC-point-frame-v1" and
              _nat(frame["rows"]) and frame["rows"] > 0 and
              _nat(frame["syntax_nodes"]) and frame["syntax_nodes"] > 0, "positive exact frame")
    return {"schema": "FPC-point-frame-v1", "rows": frame["rows"], "syntax_nodes": frame["syntax_nodes"]}


DIAGNOSTIC_FIELDS = ('schema', 'arm', 'complete', 'snapshot_available', 'publish_seq', 'phase_in_progress', 'active_frame_round', 'active_frame_pair_index', 'active_frame_ordinal', 'active_frame_rows', 'active_frame_syntax_nodes', 'active_frame_limit', 'active_phase', 'active_atomic_steps_committed', 'active_provider_calls_committed', 'active_provider_advances_committed', 'active_domain_completions', 'active_global_scans', 'active_forced_moves', 'active_branch_nodes', 'active_offers', 'active_backtracks', 'active_reject_offers', 'active_reuses', 'active_invalidations', 'active_outstanding_offers', 'active_live_cursors', 'active_highwater_live_cursors', 'active_trail_entries', 'active_highwater_trail_entries', 'frames_completed', 'frames_exhausted', 'frames_fuel_limited', 'completed_atomic_steps_committed', 'completed_provider_calls_committed', 'completed_provider_advances_committed', 'completed_domain_completions', 'completed_global_scans', 'completed_forced_moves', 'completed_branch_nodes', 'completed_offers', 'completed_backtracks', 'completed_reject_offers', 'completed_reuses', 'completed_invalidations', 'completed_highwater_live_cursors', 'completed_highwater_trail_entries', 'raw_member_work_supported', 'raw_member_work')
_D_BOOL = ("complete", "snapshot_available", "phase_in_progress", "raw_member_work_supported")
_D_MAP = (("atomic_steps_committed", "atomic_steps"),
          ("domain_completions", "domain_completions"), ("global_scans", "global_scans"),
          ("forced_moves", "forced_moves"), ("branch_nodes", "branch_nodes"),
          ("offers", "offers"), ("backtracks", "backtracks"),
          ("reject_offers", "reject_offers"), ("reuses", "classifiers_rebound"),
          ("invalidations", "domains_invalidated"))


def _invalidate_diagnostics(sink):
    """Invalidate a well-shaped output marker before any possible callback.

    Bounded primitive output mutation only. Full strict intake still follows;
    an initial snapshot never supplies authority for a new call.
    """
    if type(sink) is dict and len(sink) == len(DIAGNOSTIC_FIELDS):
        if all(type(key) is str for key in sink):
            if type(sink.get("snapshot_available")) is bool:
                sink["snapshot_available"] = False


class _Observation:
    """Fixed scalar checkpoints only, never a search input or a resume record.

    Publish at phase entry/commit and normal frame/call boundaries. Returned
    services within an interrupted phase may be missing from the last checkpoint.
    Callback-free cleanup never publishes. Cursor counts exclude inventory/state/
    member/offer handles; point trail entries are saved branch-stack records.
    """
    def __init__(self, sink, call):
        call.tick()
        call.need(type(sink) is dict and len(sink) == len(DIAGNOSTIC_FIELDS) and
                  all(type(k) is str for k in sink) and set(sink) == set(DIAGNOSTIC_FIELDS),
                  "exact fixed diagnostic sink keys required")
        for key in DIAGNOSTIC_FIELDS:
            call.tick()
            value = sink[key]
            if key == "schema":
                good = type(value) is str and value == "matched-row-controller-diagnostics-v1"
            elif key == "arm":
                good = type(value) is str and value == "G0"
            elif key in _D_BOOL:
                good = type(value) is bool
            elif key == "active_phase":
                good = value is None or (type(value) is str and value in PHASES)
            else:
                good = value is None or _nat(value)
            call.need(good, "strict primitive diagnostic sink values required")
        self.sink, self.call = sink, call
        self.record = dict.fromkeys(DIAGNOSTIC_FIELDS, 0)
        self.record.update(schema="matched-row-controller-diagnostics-v1", arm="G0",
            complete=False, snapshot_available=False, phase_in_progress=False,
            active_frame_round=None, active_frame_pair_index=None,
            active_frame_ordinal=None, active_frame_rows=None,
            active_frame_syntax_nodes=None, active_frame_limit=None, active_phase=None,
            raw_member_work_supported=False, raw_member_work=None)
        self.calls, self.advances, self.high_cursors, self.high_trail = 0, 0, 0, 0
        self.live, self.ordinal = {}, 0

    def service(self, name, result):
        # api() has already charged this normally returned public service.
        self.calls += 1
        self.advances += int(name == "advance")
        if name in ("open_classification", "rebind_classification", "open_branch"):
            self.live[id(result)] = result
            self.high_cursors = max(self.high_cursors, len(self.live))

    def closed(self, cursor):
        self.live.pop(id(cursor), None)

    def close_remaining(self, provider):
        # Fault-safe release, not a scientific snapshot or diagnostic publication.
        for cursor in tuple(self.live.values()):
            provider.close(cursor)
            self.closed(cursor)

    def publish(self, session=None, phase=None, in_progress=False):
        c, row = self.call, self.record
        c.tick()
        if session is not None:
            for suffix, metric in _D_MAP:
                c.tick()
                row["active_" + suffix] = session.metrics[metric]
            self.high_trail = max(self.high_trail, len(session.stack))
            row.update(active_provider_calls_committed=self.calls,
                active_provider_advances_committed=self.advances,
                active_outstanding_offers=len(session.stack),
                active_live_cursors=len(self.live),
                active_highwater_live_cursors=self.high_cursors,
                active_trail_entries=len(session.stack),
                active_highwater_trail_entries=self.high_trail)
        row.update(active_phase=phase, phase_in_progress=in_progress)
        next_record = {}
        for key in DIAGNOSTIC_FIELDS:
            c.tick()
            next_record[key] = row[key]
        next_record["publish_seq"] = row["publish_seq"] + 1
        c.tick()
        # Fixed primitive publication: no callback, scientific API or equality.
        self.sink["snapshot_available"] = False
        for key in DIAGNOSTIC_FIELDS:
            if key != "snapshot_available":
                self.sink[key] = next_record[key]
        self.sink["snapshot_available"] = True
        row["publish_seq"] = next_record["publish_seq"]

    def start_frame(self, frame, limit, round_number, pair_index):
        self.call.tick()
        self.ordinal += 1
        self.calls, self.advances, self.high_cursors, self.high_trail = 0, 0, 0, 0
        self.call.protocol(not self.live, "previous frame cursors still owned")
        self.record.update(complete=False, active_frame_round=round_number,
            active_frame_pair_index=pair_index, active_frame_ordinal=self.ordinal,
            active_frame_rows=frame["rows"], active_frame_syntax_nodes=frame["syntax_nodes"],
            active_frame_limit=limit)
        for key in DIAGNOSTIC_FIELDS:
            self.call.tick()
            if key.startswith("active_") and key not in (
                    "active_frame_round", "active_frame_pair_index", "active_frame_ordinal",
                    "active_frame_rows", "active_frame_syntax_nodes", "active_frame_limit", "active_phase"):
                self.record[key] = 0
        self.publish(phase="INVENTORY")

    def finish_frame(self, session):
        self.call.tick()
        # The phase-commit checkpoint already published all normal service work.
        for suffix, unused in _D_MAP:
            self.call.tick()
            self.record["completed_" + suffix] += self.record["active_" + suffix]
        for suffix in ("provider_calls_committed", "provider_advances_committed"):
            self.call.tick()
            self.record["completed_" + suffix] += self.record["active_" + suffix]
        self.record["frames_completed"] += 1
        self.record["frames_exhausted"] += int(session.status == "EXHAUSTED_FRAME")
        self.record["frames_fuel_limited"] += int(session.status == "UNKNOWN_FUEL")
        self.record["completed_highwater_live_cursors"] = max(
            self.record["completed_highwater_live_cursors"], self.high_cursors)
        self.record["completed_highwater_trail_entries"] = max(
            self.record["completed_highwater_trail_entries"], self.high_trail)
        for key in DIAGNOSTIC_FIELDS:
            self.call.tick()
            if key.startswith("active_"):
                self.record[key] = None if key.startswith("active_frame_") or key == "active_phase" else 0
        self.publish()

    def complete_call(self):
        self.call.tick()
        self.record["complete"] = True
        self.publish()


class _Domain:
    def __init__(self, cursor, data, source):
        self.cursor, self.data, self.source = cursor, data, source


class _Graph:
    def __init__(self, state, section, rows):
        self.state, self.section = state, section
        self.domains, self.context = [None] * rows, None


class _Session:
    def __init__(self, query, provider, frame, modules, trace_limit, call, observation=None):
        self.query, self.p, self.frame, self.modules, self.call = query, provider, frame, modules, call
        self.observation = observation
        self.rows, self.trace_limit = frame["rows"], trace_limit
        self.metrics = dict.fromkeys(_METRICS, 0)
        self.trace, self.truncated = [], False
        self.inv, self.graph, self.pending_state, self.reuse_parent = None, None, None, None
        self.pending_section, self.dependencies = None, []
        self.stack, self.phase, self.index = [], "INVENTORY", 0
        self.row, self.forced, self.status = None, False, None
        self.candidate_bytes, self.receipt = None, None

    def api(self, name, *args, **kwargs):
        self.call.tick()
        result = getattr(self.p, name)(*args, check=self.call.tick, **kwargs)
        if self.observation is not None:
            self.observation.service(name, result)
        return result

    def want_trace(self):
        self.call.tick()
        if self.trace_limit == 0:
            return False
        if len(self.trace) >= self.trace_limit:
            self.truncated = True
            return False
        return True

    def emit(self, kind, **fields):
        self.call.tick()
        self.trace.append(dict(kind=kind, **fields))

    def section(self, state):
        s = self.api("state_section", state)
        c = self.call
        c.protocol(type(s) is tuple and len(s) == 7 and s[0] == "FPC-point-state-section-v1" and
                   s[1] is self.inv and _nat(s[2]), "malformed state section")
        c.protocol(type(s[4]) is tuple and type(s[5]) is tuple and type(s[6]) is tuple and
                   len(s[4]) == self.rows and len(s[5]) == self.rows, "frame state shape")
        for r in range(self.rows):
            c.tick()
            expected = (0, 1) if s[4][r] is None else (1, 1)
            c.protocol(_equal(s[5][r], ((r, 0), expected), c), "selected/occupancy disagreement")
        previous = -1
        for item in s[6]:
            c.tick()
            c.protocol(type(item) is tuple and len(item) == 3, "mark shape")
            point, mark, count = item
            c.protocol(type(point) is tuple and len(point) == 2 and type(point[0]) is int and
                       point[1] == 1 and 0 <= point[0] < self.rows and point[0] > previous and
                       type(mark) is tuple and len(mark) == 2 and mark[0] == "FPC" and
                       _nat(count) and count > 0, "ordered assigned marks/refcounts")
            previous = point[0]
        return s

    def projection(self, section, row):
        marks = []
        for item in section[6]:
            self.call.tick()
            if item[0][0] <= row:
                marks.append(item)
        selected, totals = [], []
        for i in range(row + 1):
            self.call.tick()
            selected.append(section[4][i])
            totals.append(section[5][i][1])
        return tuple(selected), tuple(totals), tuple(marks)

    def read_domain(self, cursor, row, source):
        d = self.api("classification", cursor)
        c = self.call
        c.protocol(type(d) is dict and d.get("schema") == "FPC-point-classification-v1" and
                   d.get("state_serial") == self.graph.section[2] and
                   _equal(d.get("point"), (row, 0), c), "wrong domain parent or point")
        kind, complete, witnesses = d.get("kind"), d.get("coverage_complete"), d.get("witnesses")
        c.protocol(type(witnesses) is tuple and type(complete) is bool, "domain data shape")
        valid = ((kind == "EMPTY" and complete and len(witnesses) == 0) or
                 (kind == "SINGLE" and complete and len(witnesses) == 1) or
                 (kind == "MANY" and not complete and len(witnesses) == 2) or
                 (kind == "UNRESOLVED" and not complete and len(witnesses) <= 1))
        c.protocol(valid, "incomplete domain misclassified")
        c.protocol((source == "INITIAL" and d.get("remainder_revision") is None) or
                   (source == "REMAINDER" and _nat(d.get("remainder_revision"))), "wrong remainder label")
        return _Domain(cursor, d, source)

    def trace_domain(self, row, domain):
        if self.want_trace():
            witnesses = []
            for item in domain.data["witnesses"]:
                self.call.tick()
                witnesses.append(self.api("candidate_record", item))
            self.emit("DOMAIN", state_serial=self.graph.section[2], row=row,
                      domain_kind=domain.data["kind"], coverage_complete=domain.data["coverage_complete"],
                      witnesses=witnesses, source=domain.source,
                      remainder_revision=domain.data["remainder_revision"])

    def close_cursor(self, cursor):
        self.p.close(cursor)
        if self.observation is not None:
            self.observation.closed(cursor)

    def retire(self, graph):
        """Callback-free: close local cursors, never provider states or members."""
        if graph is not None:
            for domain in graph.domains:
                if domain is not None:
                    self.close_cursor(domain.cursor)
            if graph.context is not None:
                self.close_cursor(graph.context[1])

    def cleanup(self):
        self.retire(self.graph)
        self.retire(self.reuse_parent)
        for entry in self.stack:
            self.retire(entry[0])
            self.close_cursor(entry[2])
        if self.observation is not None:
            self.observation.close_remaining(self.p)
        if self.inv is not None:
            self.p.close(self.inv)

    def decision(self, status, row, frontier):
        if self.want_trace():
            all_domains = []
            for r in frontier:
                self.call.tick()
                d = self.graph.domains[r]
                all_domains.append({"row": r, "kind": "UNRESOLVED" if d is None else d.data["kind"],
                                    "coverage_complete": False if d is None else d.data["coverage_complete"]})
            self.emit("DECISION", state_serial=self.graph.section[2], status=status,
                      row=row, all_unfilled=all_domains)

    def select(self, candidate, forced, branch=None, offer=None, branch_serial=None, offer_serial=None):
        parent = self.graph
        child = self.api("place_state", parent.state, candidate)
        self.pending_state = child
        self.reuse_parent = parent
        self.pending_section = self.section(child)
        self.call.protocol(self.pending_section[3] is parent.state, "child must name exact parent")
        self.metrics["state_creations"] += 1
        self.metrics["forced_moves"] += int(forced)
        if self.want_trace():
            self.emit("SELECT", parent_serial=parent.section[2], child_serial=self.pending_section[2],
                      row=self.row, forced=forced, from_offer=offer is not None,
                      candidate=self.api("candidate_record", candidate),
                      branch_serial=branch_serial, offer_serial=offer_serial)
        self.graph, self.phase = None, "LOAD"

    def step(self):
        c, p, phase = self.call, self.p, self.phase
        c.tick()
        if self.observation is not None:
            self.observation.publish(self, phase, True)
        if phase == "INVENTORY":
            self.inv = self.api("create_inventory", self.query, frame=self.frame, modules=self.modules)
            self.phase = "ROOT"
        elif phase == "ROOT":
            self.pending_state = self.api("root_state", self.inv)
            self.metrics["state_creations"] += 1
            self.phase, self.index = "DEPENDENCY", 0
        elif phase == "DEPENDENCY":
            d = self.api("dependency_spec", self.inv, (self.index, 0))
            c.protocol(type(d) is dict and _equal(d.get("cell"), (self.index, 0), c) and
                       d.get("formula_port_prefix") == [0, self.index + 1] and
                       d.get("inventory_version") == PROVIDER_VERSION, "complete prefix dependencies required")
            self.dependencies.append((self.index, self.index + 1))
            self.index += 1
            if self.index == self.rows:
                self.phase = "LOAD"
        elif phase == "LOAD":
            section = self.pending_section
            if section is None:
                section = self.section(self.pending_state)
            self.graph = _Graph(self.pending_state, section, self.rows)
            self.pending_state, self.pending_section = None, None
            self.index, self.phase = 0, "REUSE"
            if self.want_trace():
                self.emit("STATE", depth=len(self.stack), state_serial=section[2],
                          parent_serial=None if section[3] is None else self.reuse_parent.section[2],
                          snapshot=self.api("snapshot", self.graph.state))
        elif phase == "REUSE":
            r, old = self.index, self.reuse_parent
            if self.graph.section[4][r] is None and old is not None and old.domains[r] is not None:
                domain = old.domains[r]
                c.protocol(domain.source == "INITIAL", "cannot transport a branch remainder")
                same = _equal(self.projection(old.section, r), self.projection(self.graph.section, r), c)
                if same:
                    cursor = self.api("rebind_classification", domain.cursor, self.graph.state)
                    self.graph.domains[r] = self.read_domain(cursor, r, "INITIAL")
                    self.metrics["classifiers_rebound"] += 1
                else:
                    self.metrics["domains_invalidated"] += 1
                if self.want_trace():
                    self.emit("REUSE" if same else "INVALIDATE", row=r,
                              from_state_serial=old.section[2], state_serial=self.graph.section[2])
            self.index += 1
            if self.index == self.rows:
                if old is not None and old.context is None:
                    self.retire(old)
                self.reuse_parent, self.phase = None, "SCAN"
        elif phase == "SCAN":
            self.metrics["global_scans"] += 1
            frontier, empty, unresolved, singles = [], [], [], []
            for r in range(self.rows):
                c.tick()
                if self.graph.section[4][r] is not None:
                    continue
                frontier.append(r)
                d = self.graph.domains[r]
                kind = "UNRESOLVED" if d is None else d.data["kind"]
                if kind == "EMPTY":
                    empty.append(r)
                elif kind == "UNRESOLVED":
                    unresolved.append(r)
                elif kind == "SINGLE":
                    singles.append(r)
            self.metrics["max_frontier"] = max(self.metrics["max_frontier"], len(frontier))
            if empty:
                self.decision("DEAD", empty[0], frontier)
                self.phase = "BACKTRACK"
            elif unresolved:
                self.row = unresolved[0]
                self.phase = "CLASSIFY_OPEN" if self.graph.domains[self.row] is None else "CLASSIFY_ADVANCE"
            elif not frontier:
                self.decision("EXACT", None, frontier)
                self.phase = "EXPORT"
            else:
                self.row, self.forced = (singles[0], True) if singles else (frontier[0], False)
                self.decision("FORCED" if self.forced else "BRANCH", self.row, frontier)
                if self.graph.context is not None:
                    c.protocol(self.graph.context[0] == self.row, "restored parent must retain chosen point")
                    self.phase = "OFFER"
                else:
                    self.phase = "FORCE_PLACE" if self.forced else "BRANCH_OPEN"
        elif phase == "CLASSIFY_OPEN":
            context = self.graph.context
            remainder = context[1] if context is not None and context[0] == self.row else None
            cursor = self.api("open_classification", self.graph.state, (self.row, 0), remainder=remainder)
            source = "INITIAL" if remainder is None else "REMAINDER"
            self.graph.domains[self.row] = self.read_domain(cursor, self.row, source)
            self.metrics["classifier_opens"] += 1
            c.protocol(self.graph.domains[self.row].data["kind"] == "UNRESOLVED", "new classifier must be unresolved")
            self.phase = "CLASSIFY_ADVANCE"
        elif phase == "CLASSIFY_ADVANCE":
            old = self.graph.domains[self.row]
            self.api("advance", old.cursor)
            domain = self.read_domain(old.cursor, self.row, old.source)
            self.graph.domains[self.row] = domain
            self.metrics["classifier_advances"] += 1
            if domain.data["kind"] != "UNRESOLVED":
                self.metrics["domain_completions"] += 1
                self.trace_domain(self.row, domain)
                self.phase = "SCAN"
        elif phase == "FORCE_PLACE":
            self.select(self.graph.domains[self.row].data["witnesses"][0], True)
        elif phase == "BRANCH_OPEN":
            branch = self.api("open_branch", self.graph.state, (self.row, 0),
                              classified=self.graph.domains[self.row].cursor)
            self.graph.context = (self.row, branch)
            self.metrics["branch_nodes"] += 1
            self.phase = "OFFER"
        elif phase == "OFFER":
            branch = self.graph.context[1]
            step = self.api("advance", branch)
            c.protocol(type(step) is dict and step.get("committed") is True and
                       step.get("schema") == "FPC-point-provider-step-v1" and
                       step.get("state_serial") == self.graph.section[2], "branch step association")
            if step.get("kind") == "CANDIDATE":
                candidate, offer = step.get("candidate"), step.get("offer")
                c.protocol(candidate is not None and offer is not None, "actual offer required")
                # Snapshot is also the public association for opaque offer serials.
                snap = self.api("snapshot", branch)
                bs, os = snap["cursor_serial"], snap["outstanding_offer_serial"]
                c.protocol(_nat(bs) and _nat(os), "owned branch/offer serials")
                self.stack.append((self.graph, branch, offer, candidate, self.row, self.forced, bs, os))
                self.metrics["offers"] += 1
                self.metrics["max_path_depth"] = max(self.metrics["max_path_depth"], len(self.stack))
                self.phase = "OFFER_PLACE"
                if self.want_trace():
                    self.emit("OFFER", state_serial=self.graph.section[2], row=self.row,
                              branch_serial=bs, offer_serial=os, candidate=self.api("candidate_record", candidate))
            else:
                c.protocol(step.get("kind") == "PENDING", "nonempty classified branch unexpectedly ended")
        elif phase == "OFFER_PLACE":
            parent, branch, offer, candidate, row, forced, bs, os = self.stack[-1]
            c.protocol(self.graph is parent and self.row == row, "outstanding offer parent")
            self.select(candidate, forced, branch, offer, bs, os)
        elif phase == "BACKTRACK":
            if not self.stack:
                self.status = "EXHAUSTED_FRAME"
            else:
                dead = self.graph
                parent, branch, offer, candidate, row, forced, bs, os = self.stack[-1]
                c.protocol(_equal(self.section(parent.state), parent.section, c), "exact parent restoration failed")
                reason = "CHILD_EXHAUSTED" if dead.context is not None else "CHILD_DEAD"
                # No normal fuel/error path can enter this phase. Only a complete
                # EMPTY classified domain gives finite child-failure authority.
                self.api("reject_offer", branch, offer)
                self.retire(dead)
                if parent.domains[row] is not None:
                    self.close_cursor(parent.domains[row].cursor)
                parent.domains[row] = None
                self.graph = parent
                self.stack.pop()
                self.metrics["backtracks"] += 1
                self.metrics["reject_offers"] += 1
                if self.want_trace():
                    self.emit("REJECT", restored_parent_serial=parent.section[2],
                              failed_child_serial=dead.section[2], row=row, branch_serial=bs,
                              offer_serial=os, reason=reason)
                self.phase = "SCAN"
        elif phase == "EXPORT":
            exported = self.api("export_candidate", self.graph.state)
            c.protocol(type(exported) is dict and set(exported) == {"candidate_certificate_bytes", "receipt"} and
                       type(exported["candidate_certificate_bytes"]) is bytes and
                       type(exported["receipt"]) is dict and exported["receipt"].get("accepted") is False,
                       "canonical unaccepted export required")
            self.candidate_bytes, self.receipt = exported["candidate_certificate_bytes"], exported["receipt"]
            self.status = "CANDIDATE"
        else:
            raise FrameProtocolError("unknown controller phase")
        c.tick()
        self.metrics["atomic_steps"] += 1
        if self.observation is not None:
            self.observation.publish(self, phase, False)


def _run_frame(query_bytes, provider, frame, modules, max_steps, trace_limit, call,
               observation=None, round_number=None, pair_index=None):
    session = _Session(query_bytes, provider, frame, modules, trace_limit, call, observation)
    callback_start = call.callbacks
    try:
        if observation is not None:
            observation.start_frame(frame, max_steps, round_number, pair_index)
        while session.status is None:
            call.tick()
            if max_steps is not None and session.metrics["atomic_steps"] >= max_steps:
                session.status = "UNKNOWN_FUEL"
                break
            session.step()
        if session.want_trace():
            session.emit("TERMINAL", status=session.status, phase=session.phase,
                         atomic_steps=session.metrics["atomic_steps"], outstanding_offers=len(session.stack))
        call.tick()
        session.metrics["callbacks"] = call.callbacks - callback_start
        result = {"schema": "FPC-point-frame-search-v1", "status": session.status,
                  "frame": dict(frame), "accepted": False,
                  "candidate_certificate_bytes": session.candidate_bytes, "export_receipt": session.receipt,
                  "metrics": dict(session.metrics), "trace": session.trace,
                  "trace_complete": trace_limit > 0 and not session.truncated}
    except BaseException:
        try:
            session.cleanup()
        except BaseException:
            pass
        if call.first is not None:
            raise call.first
        raise
    session.cleanup()
    if observation is not None:
        observation.finish_frame(session)
    result["metrics"]["callbacks"] = call.callbacks - callback_start
    return result


def search_frame(query_bytes, *, provider, frame, modules, max_steps, trace_limit=0, diagnostics=None, check):
    _invalidate_diagnostics(diagnostics)
    call = _Call(check)
    context = _context(query_bytes, provider, modules, call)
    copied = _frame_copy(frame, call)
    call.need(max_steps is None or _nat(max_steps), "strict nonnegative step limit or None")
    call.need(_nat(trace_limit), "strict nonnegative trace limit")
    before = call.callbacks
    observation = None if diagnostics is None else _Observation(diagnostics, call)
    result = _run_frame(query_bytes, provider, copied, context, max_steps, trace_limit, call, observation)
    # Include public validation/setup callbacks, not only the private session.
    if observation is not None:
        observation.complete_call()
    result["metrics"]["callbacks"] = call.callbacks
    return result


def _goal_lower_bound(query, call):
    call.protocol(type(query) is dict and "goal" in query, "decoded goal required")
    pending, count, largest = [query["goal"]], 0, -1
    while pending:
        call.tick()
        node = pending.pop()
        # The fixed checker's parse-only public copy uses lists; accept that
        # documented representation as well as immutable internal tuples.
        call.protocol(type(node) in (list, tuple) and len(node) >= 1, "decoded core AST required")
        count += 1
        tag = node[0]
        if tag == "var":
            call.protocol(len(node) == 2 and _nat(node[1]), "decoded variable")
            largest = max(largest, node[1])
        elif tag in ("fun", "pred"):
            call.protocol(len(node) == 3 and type(node[2]) in (list, tuple), "decoded application")
            for child in node[2]:
                call.tick()
                pending.append(child)
        elif tag == "all":
            call.protocol(len(node) == 3 and _nat(node[1]), "decoded binder")
            largest = max(largest, node[1])
            pending.append(node[2])
        elif tag == "not":
            call.protocol(len(node) == 2, "decoded negation")
            pending.append(node[1])
        elif tag in ("imp", "eq"):
            call.protocol(len(node) == 3, "decoded binary AST")
            pending.extend((node[1], node[2]))
        else:
            raise FrameProtocolError("unknown decoded core AST tag")
    return max(1, count, largest + 1)


def search_dovetail(query_bytes, *, provider, modules, max_rounds, diagnostics=None, check):
    _invalidate_diagnostics(diagnostics)
    call = _Call(check)
    context = _context(query_bytes, provider, modules, call)
    call.need(max_rounds is None or _nat(max_rounds), "strict nonnegative round limit or None")
    observation = None if diagnostics is None else _Observation(diagnostics, call)
    call.tick()
    query = context["checker"].decode_query(query_bytes, check=call.tick)
    lower = _goal_lower_bound(query, call)
    metrics = dict.fromkeys(("rounds_completed", "frame_runs", "frame_atomic_steps", "sum_frame_limits",
                             "frames_exhausted", "frames_fuel_limited", "callbacks", "max_path_depth",
                             "max_frontier"), 0)
    last, candidate, receipt, status = None, None, None, "UNKNOWN_ROUND_LIMIT"
    round_number = 1
    while max_rounds is None or round_number <= max_rounds:
        call.tick()
        diagonal, n, index = 1, 1, 1
        while index <= round_number:
            call.tick()
            limit = 1 << (round_number - index)
            frame = {"schema": "FPC-point-frame-v1", "rows": n, "syntax_nodes": lower + diagonal - n}
            result = _run_frame(query_bytes, provider, frame, context, limit, 0, call,
                                observation, round_number, index)
            fm = result["metrics"]
            metrics["frame_runs"] += 1
            metrics["frame_atomic_steps"] += fm["atomic_steps"]
            metrics["sum_frame_limits"] += limit
            metrics["frames_exhausted"] += int(result["status"] == "EXHAUSTED_FRAME")
            metrics["frames_fuel_limited"] += int(result["status"] == "UNKNOWN_FUEL")
            metrics["max_path_depth"] = max(metrics["max_path_depth"], fm["max_path_depth"])
            metrics["max_frontier"] = max(metrics["max_frontier"], fm["max_frontier"])
            last = {"round": round_number, "pair_index": index, "frame": dict(frame),
                    "max_steps": limit, "status": result["status"], "atomic_steps": fm["atomic_steps"]}
            if result["status"] == "CANDIDATE":
                candidate, receipt, status = result["candidate_certificate_bytes"], result["export_receipt"], "CANDIDATE"
                break
            # No prior frame result, candidate handle, trace or state is retained.
            result = None
            index, n = index + 1, n + 1
            if n > diagonal:
                diagonal, n = diagonal + 1, 1
        if status == "CANDIDATE":
            break
        metrics["rounds_completed"] += 1
        round_number += 1
    call.tick()
    if observation is not None:
        observation.complete_call()
    metrics["callbacks"] = call.callbacks
    return {"schema": "FPC-point-dovetail-search-v1", "status": status, "accepted": False,
            "candidate_certificate_bytes": candidate, "export_receipt": receipt, "metrics": metrics, "last_frame": last}
