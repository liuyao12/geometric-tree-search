"""Raw post-terminal census only; partial files are opaque bytes, never JSON."""
from pathlib import Path
import datetime
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parent
N = ROOT.parent
assert len(sys.argv) == 5 and sys.argv[1] in ('C0', 'G0') and sys.argv[2] in ('0', '1', '2', '3', '4', '5')
arm = sys.argv[1]
index, session, exit_code = (int(value) for value in sys.argv[2:])
case = 'matched-row-csp-point-v1-' + arm + '-target-' + str(index)
actual = N / 'actual' / case
observer = Path(str(actual) + '.observer')
files = []
for directory in (actual, observer):
    assert directory.is_dir() and not directory.is_symlink()
    for path in sorted(directory.rglob('*')):
        assert not path.is_symlink()
        if path.is_file():
            body = path.read_bytes()
            files.append({'path': str(path), 'bytes': len(body),
                          'sha256': hashlib.sha256(body).hexdigest(),
                          'partial_opaque': '.partial' in path.name})
record = {'schema': 'Root-point-frame-first-terminal-raw-census-v1', 'case_id': case,
          'issued_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'exec_session_id': session, 'exec_exit_code': exit_code, 'files': files,
          'partial_policy': 'Raw bytes only; never parse partial files.',
          'scientific_imports_calls': 0}
path = ROOT / ('matched-row-' + arm + '-target-' + str(index) + '-first-terminal-raw-census-v1.json')
with path.open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps({'record': str(path), 'files': len(files),
                  'bytes': sum(item['bytes'] for item in files),
                  'partials': sum(item['partial_opaque'] for item in files),
                  'names': [Path(item['path']).name for item in files]}))
