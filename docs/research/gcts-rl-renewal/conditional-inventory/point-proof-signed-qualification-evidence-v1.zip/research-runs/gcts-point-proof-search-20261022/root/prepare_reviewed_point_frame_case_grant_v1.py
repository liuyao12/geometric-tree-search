"""Root metadata-only grant issuance; call only after a fresh live idle inventory."""
from pathlib import Path
import datetime
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parent
N = ROOT.parent


def read(path):
    return json.loads(Path(path).read_bytes())


def pin(path):
    path = Path(path)
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def verify(ref):
    assert pin(ref['path']) == ref


def emit(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write((json.dumps(value, indent=2) + '\n').encode())
    return pin(path)


assert len(sys.argv) == 2 and sys.argv[1] in ('1', '2', '3', '4', '5')
index = int(sys.argv[1])
batch_path = ROOT / 'remaining-five-point-frame-metadata-preparation-v1.json'
acceptance_path = ROOT / 'remaining-five-prospective-batch-Root-acceptance-v1.json'
batch, accepted = read(batch_path), read(acceptance_path)
assert pin(batch_path)['sha256'] == '24a0323c8ff63c4e2c4f3de7436fb2076e17708aec62669a27b8124a553438db'
assert accepted['accepted_prospective_metadata'] is True
for key in ('batch', 'whole_batch_review', 'grant_proposal_batch_review', 'L_metadata_review'):
    verify(accepted[key])
for key in ('whole_batch_review', 'grant_proposal_batch_review', 'L_metadata_review'):
    assert read(accepted[key]['path'])['review_passed'] is True
row = batch['cases'][index - 1]
assert row['recipe']['target_index'] == index
for key in ('plan', 'closure', 'proposal'):
    verify(row[key])
proposal = read(row['proposal']['path'])
plan = read(row['plan']['path'])
assert proposal['authorized'] is False and proposal['review_passed'] is False
assert type(proposal['uses']) is int and proposal['uses'] == 1
assert proposal['plan'] == row['plan'] and proposal['closure'] == row['closure']
assert proposal['case_id'] == plan['case_id'] == row['recipe']['case_id']
for key in ('plan', 'protocol', 'closure', 'component_review'):
    verify(proposal[key])
protocol = read(proposal['protocol']['path'])
assert protocol['job_recipes'][index] == row['recipe']
assert len(plan['files']) == 70 and len(plan['module_pins']) == 22
assert plan['limits'] == protocol['limits'] and len(plan['limits']) == 10
assert plan['control_populations'] == protocol['control_populations']
assert sum(item['groups'] for item in plan['control_populations'].values()) == 162
for ref in plan['files']:
    verify(ref)
assert read(proposal['closure']['path'])['files'] == plan['files']
absences = [Path(plan['actual_dir']), Path(plan['actual_dir'] + '.observer'),
            Path(proposal['prospective_grant_path'])]
for path in absences:
    assert not path.exists() and not path.is_symlink()
now = datetime.datetime.now(datetime.timezone.utc).isoformat()
case = plan['case_id']
fresh_acceptance = emit(ROOT / ('point-frame-target-' + str(index) + '-Root-prospective-acceptance-v1.json'), {
    'schema': 'Root-point-frame-per-case-prospective-acceptance-v1', 'issued_utc': now,
    'accepted': True, 'case_id': case, 'plan': row['plan'], 'closure': row['closure'],
    'proposal': row['proposal'], 'whole_review': accepted['whole_batch_review'],
    'proposal_review': accepted['grant_proposal_batch_review'],
    'Root_batch_acceptance': pin(acceptance_path), 'metadata_issuer': pin(Path(__file__)),
    'guards_rehashed': 70, 'namespaces': 22, 'scoped_groups': 162,
    'limits_and_generic_configuration_unchanged': True,
    'absent_paths': [str(path) for path in absences], 'scientific_imports_calls': 0,
    'scope': 'Fresh case eligibility only; no prior proof, control qualification or resource-fit adoption.'})
barrier = emit(ROOT / ('point-frame-target-' + str(index) + '-all-tools-idle-barrier-v1.json'), {
    'schema': 'Root-point-frame-per-case-tools-idle-barrier-v1', 'issued_utc': now,
    'case_id': case, 'acceptance': fresh_acceptance,
    'live_inventory_observation': 'Root called collaboration.list_agents immediately before issuance. All three non-root agents completed/tools idle. Root has no active command session, local server, browser/network operation or scientific work.',
    'agents': ['/root/recovered_batch_diagnostics', '/root/recovered_batch_integration', '/root/recovered_batch_review'],
    'source_checks': 70, 'fresh_absence_checks': 3,
    'scope': 'Root procedural tool-idle observation, not exclusive ownership of all operating-system activity. No parallel tool work during this actual.'})
grant = {key: proposal[key] for key in ('uses', 'case_id', 'plan_sha256', 'runner_sha256',
                                      'observer_sha256', 'plan', 'protocol', 'closure', 'component_review')}
grant.update(schema='Root-point-frame-once-grant-v1', authorized=True, review_passed=True,
             issued_utc=now, whole_review=accepted['whole_batch_review'],
             grant_proposal_review=accepted['grant_proposal_batch_review'],
             case_proposal=row['proposal'], Root_prospective_acceptance=fresh_acceptance,
             all_tools_idle_barrier=barrier,
             scope='One-use authority for this exact reviewed bounded independent case only. No rerun, alternate plan, prefix rescue or automatic positive admission.')
final = emit(Path(proposal['prospective_grant_path']), grant)
print(json.dumps({'grant': final, 'acceptance': fresh_acceptance, 'barrier': barrier,
                  'prospective_command': proposal['prospective_command']}))
