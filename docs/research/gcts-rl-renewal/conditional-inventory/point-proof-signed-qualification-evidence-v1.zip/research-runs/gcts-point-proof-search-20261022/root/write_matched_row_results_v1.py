"""Accept saved whole-negative evidence and compose display metadata only."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

ROOT = Path(__file__).resolve().parent
N = ROOT.parent


def read(path):
    return json.loads(Path(path).read_bytes())


def pin(path):
    p = Path(path).resolve()
    assert p.is_file() and not p.is_symlink() and '.partial' not in p.name
    b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())


def emit(path, value):
    with path.open('xb') as f:
        f.write((json.dumps(value, indent=2) + '\n').encode())
    return pin(path)


fields = ('qualification_result', 'input_freeze', 'search_result', 'subject_receipt',
          'reference_receipt', 'point_receipt', 'scientific_result')
evidence, cases = {}, []


def add(path):
    ref = pin(path)
    evidence[ref['path']] = ref
    return ref


prep = read(ROOT / 'matched-row-study-preparation-v1.json')
for arm, session, tool_seconds, label in (
        ('C0', 23335, 160.25124654101091, 'Conventional CSP'),
        ('G0', 83260, 179.96715850001783, 'Point controller')):
    review_path = N / f'review-C/typed-matched-row-{arm}-target-3-complete-negative-actual-review-v1.json'
    c = read(review_path)
    assert c['review_passed'] is False and c['negative_review_accepted'] is True
    assert c['all_negative_review_checks_passed'] is True and c['failures'] == []
    assert all(x['passed'] is True for x in c['checks'])
    ap = N / f'actual/matched-row-csp-point-v1-{arm}-target-3'
    f = read(ap / 'failure.json')
    o = read(Path(str(ap) + '.observer') / 'observer.json')
    cp = ROOT / f'matched-row-{arm}-target-3-first-terminal-raw-census-v1.json'
    cc = read(cp)
    assert cc['exec_session_id'] == session and cc['exec_exit_code'] == 2
    assert len(cc['files']) == 12 and all(x['partial_opaque'] is False for x in cc['files'])
    for ref in cc['files']:
        assert pin(ref['path']) == {k: ref[k] for k in ('path', 'bytes', 'sha256')}
        add(ref['path'])
    assert all(f[k] is None for k in fields) and f['qualification_complete'] is False
    assert f['first_Root_fault'] is True and f['error']['message'] == 'absolute whole-work deadline'
    controls = [x for x in f['stages'] if x['name'].startswith('CONTROLS ')]
    searches = [x for x in f['stages'] if x['name'].startswith('SEARCH ')]
    assert len(controls) == 11 and all(x['status'] == 'COMPLETED' for x in controls)
    assert len(searches) == 1 and searches[0]['status'] == 'STARTED'
    obs = f['search_diagnostic_observation']
    assert obs['available'] is True and obs['non_authoritative'] is True
    assert obs['snapshot']['complete'] is False and len(obs['snapshot']) == 49
    dp = ROOT / f'matched-row-{arm}-target-3-Root-whole-negative-disposition-v1.json'
    if arm == 'G0':
        emit(dp, dict(schema='Root-matched-row-case-whole-negative-disposition-v1',
            issued_utc=datetime.now(timezone.utc).isoformat(), case_id=c['case_id'],
            arm=arm, target_index=3, target_id='HI-point-not-line',
            status='WHOLE_NEGATIVE_ACCEPTED_NO_SCIENTIFIC_PREFIX',
            negative_review_accepted=True, admitted=False, C_complete_negative_review=pin(review_path),
            raw_census=pin(cp), failure=pin(ap / 'failure.json'),
            observer=pin(Path(str(ap) + '.observer') / 'observer.json'),
            exec_session_id=session, exec_exit_code=2, consumed=True, retry_authority=False,
            target_search_started=True, observer_elapsed_seconds=o['elapsed_seconds'],
            observer_tool_summary_seconds=tool_seconds, worker_receipt_elapsed_seconds=f['elapsed_seconds'],
            qualification_complete=False, positive_payloads={k: None for k in fields},
            qualified_whole_peak_bytes=None, search_diagnostic_observation=obs,
            finding='First sticky RootBudget whole-work deadline during search; no proof. Actual observer elapsed is179.966461seconds despite configured160second work ceiling. Cause and first-fault timestamp are not established by the saved terminal record. No qualified control/input prefix or speed comparison.',
            limits='No replay, exhaustive-search/nonprovability, cause profile, learned marking or RL finding. Other ten recipes remain ungranted and unrun.',
            scientific_imports_calls=0, goal_complete=False))
    dp_data = read(dp)
    assert dp_data['negative_review_accepted'] is True and dp_data['admitted'] is False
    cases.append(dict(case_id=c['case_id'], arm=arm, arm_label=label,
        target_index=3, target_id='HI-point-not-line', display_outcome='Whole-work deadline; no proof',
        admitted=False, observer_elapsed_seconds=o['elapsed_seconds'],
        observer_tool_summary_seconds=tool_seconds, worker_receipt_elapsed_seconds=f['elapsed_seconds'],
        diagnostic_search_start_worker_seconds=searches[0]['began'],
        qualification_complete=False, positive_payloads={k: None for k in fields},
        qualified_whole_peak_bytes=None, search_diagnostic_observation=obs,
        callbacks=f['callbacks'], physical_files=12,
        physical_bytes=sum(x['bytes'] for x in cc['files']), partial_files=0,
        C_negative_review=add(review_path), Root_disposition=add(dp)))
    for p in (cp, ROOT / f'matched-row-{arm}-target-3-Root-prospective-acceptance-v1.json',
              ROOT / f'matched-row-{arm}-target-3-all-tools-idle-barrier-v1.json',
              ROOT / f'grants/matched-row-csp-point-v1-{arm}-target-3.json'):
        add(p)

for row in prep['cases']:
    for key in ('plan', 'closure', 'proposal'):
        assert pin(row[key]['path']) == row[key]
        add(row[key]['path'])
for ref in read(prep['cases'][6]['plan']['path'])['files']:
    assert pin(ref['path']) == ref
    add(ref['path'])
for p in (ROOT / 'matched-row-study-preparation-v1.json',
          ROOT / 'matched-row-study-Root-whole-prospective-acceptance-v1.json',
          ROOT / 'matched-row-Root-component-Source-acceptance-v1.json',
          ROOT / 'matched-row-Root-design-and-declaration-acceptance-v1.json',
          N / 'review-C/typed-matched-row-twelve-recipe-complete-whole-prospective-Source-plan-proposal-review-v1.json',
          N / 'review-C/typed-point-controller-diagnostics-complete-Source-review-v1-negative.json',
          N / 'diagnostics-L/typed-row-CSP-controller-complete-component-Source-review-v1-negative.json',
          N / 'diagnostics-L/typed-row-CSP-controller-v1-negative-line-reference-addendum-v1.json',
          N / 'diagnostics-L/matched-row-paired-negative-and-receptor-next-measurement-v1.json',
          Path(__file__), ROOT / 'build_matched_row_publication_v1.py'):
    add(p)

a, b = [c['search_diagnostic_observation']['snapshot'] for c in cases]
comparable = [k for k in a if k.startswith('completed_') and 'trail_entries' not in k]
assert all(a[k] == b[k] for k in comparable)
assert a['frames_completed'] == b['frames_completed'] == 330
assert (a['active_frame_round'], a['active_frame_pair_index'], a['active_frame_rows'],
        a['active_frame_syntax_nodes']) == (26, 6, 3, 7)
assert all(a[k] == b[k] for k in ('active_frame_round', 'active_frame_pair_index',
                                'active_frame_rows', 'active_frame_syntax_nodes'))
data = dict(schema='Root-matched-row-study-whole-results-v1',
    issued_utc=datetime.now(timezone.utc).isoformat(), whole_actual_reviews_accepted=True,
    scope='Two complete separately consumed whole negatives; saved diagnostic checkpoints only.',
    summary='Neither the conventional CSP arm nor the point-controller arm returned a proof of the unchanged incidence statement. Their saved completed-frame counters agree; no practical proof-search advantage is established.',
    interpretation=r'Both jobs reached SEARCH after eleven completed control-wrapper labels, then failed with the first sticky whole-work deadline and all seven positive payloads null. C0 observer elapsed was \(160.251\,\mathrm{s}\); G0 was \(179.966\,\mathrm{s}\), despite the same configured \(160\,\mathrm{s}\) work ceiling. That ceiling is checked cooperatively; the saved record does not explain the overrun or timestamp its first fault. The completed checkpoints agree on \(330\) frames and the corresponding common counters; both active frames have \(n=3,\ b=7\), but progress differs. Unequal observed costs and incomplete checkpoints do not support a throughput or speedup claim. Qualified whole memory remains unknown.',
    contribution_assessment='The current evidence establishes an implemented, independently inspected comparison and bounded automatic search attempts. It establishes no new theorem, learned failure marking, reusable receptor family, RL benefit or advantage over an existing prover. The shared provider means this is a bookkeeping comparison, not an independent logical-inference test. The one historical elementary reflexivity theorem remains the only distinct admitted theorem.',
    next_step='The next priority is a small fresh propositional donor study within the common logical backend. Acquire at least two wholly checked proofs without supplied intermediate lemmas, or stop and report acquisition unavailable. Extract connected primitive-proof clusters with typed receptors; validate every expansion and preserve primitive fallback. Only then compare structurally held-out search with no library, fixed selection and uniform selection of the same library, on both controllers and including acquisition and checking costs. RL follows only after reusable-family feasibility is demonstrated. The original consumed trials remain immutable.',
    cases=cases, original_development_targets_retained=6, prospective_recipes=12,
    unexecuted_recipes=[x['recipe'] for x in prep['cases'] if x['recipe']['target_index'] != 3],
    declared_scoped_populations=12, declared_scoped_groups=192,
    original184_population_objects_preserved=True, additional_matched_groups=8,
    current_population_qualified=False, qualified_current_group_result=None,
    completed_common_diagnostic_fields_equal=comparable,
    diagnostic_snapshots_authoritative=False, raw_member_work_supported=False,
    same_configured_caps=True, clock_discrepancy_unexplained=True,
    new_target_proof_admitted=False, new_distinct_theorems=0, unique_theorems=1,
    RL_used=False, learned_markings_used=False, receptor_library_used=False,
    GCTS_or_RL_advantage_established=False, matched_bookkeeping_pilot_run=True,
    matched_existing_prover_run=False, evidence_records=[evidence[k] for k in sorted(evidence)],
    scientific_imports_calls=0, proof_or_control_replays=0, goal_status='ACTIVE_UNBUDGETED_INCOMPLETE')
print(json.dumps(emit(ROOT / 'matched-row-study-Root-whole-results-v1.json', data), indent=2))
