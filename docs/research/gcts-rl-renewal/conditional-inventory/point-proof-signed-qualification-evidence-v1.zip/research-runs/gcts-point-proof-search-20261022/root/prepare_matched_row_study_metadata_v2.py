"""Prepare prospective once plans from reviewed Source metadata only.

No research imports, semantic fixture generation, query encoding, search or
certificate checking. Running this script does not authorize an actual.
"""
from pathlib import Path
import ast
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parent
N = ROOT.parent
EXPERIMENT = 'matched-row-csp-point-v1'


def read(path):
    return json.loads(Path(path).read_bytes())


def pin(path):
    p = Path(path).resolve()
    assert p.is_file() and not p.is_symlink() and '.partial' not in p.name
    raw = p.read_bytes()
    return dict(path=str(p), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def verify(ref):
    assert pin(ref['path']) == ref


def emit(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write((json.dumps(value, indent=2) + '\n').encode())
    return pin(path)


assert len(sys.argv) == 5
worker_review_path, bank_review_path, csp_review_path, point_review_path = map(Path, sys.argv[1:])
reviews = [read(p) for p in (worker_review_path, bank_review_path, csp_review_path, point_review_path)]
assert all(x['review_passed'] is True for x in reviews)
worker = N / 'implementation-B/fpc_point_frame_search_worker_v7.py'
api_path = N / 'implementation-B/point-frame-worker-API-v7.json'
offer_path = N / 'implementation-B/point-frame-worker-dependency-offer-v7.json'
worker_raw = worker.read_bytes()
assert pin(worker)['sha256'] in json.dumps(reviews[0])
constants = {}
wanted = {'EXPERIMENT', 'PROTOCOL_SCHEMA', 'MODULE_ROLES', 'CONTROL_IDS', 'CAPS', 'PRODUCTION_CONFIGURATION'}
for node in ast.parse(worker_raw).body:
    if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
        name = node.targets[0].id
        if name in wanted:
            constants[name] = ast.literal_eval(node.value)
assert set(constants) == wanted and constants['EXPERIMENT'] == EXPERIMENT
assert constants['PROTOCOL_SCHEMA'] == 'Root-FPC-point-frame-protocol-v1'
old = read(ROOT / 'plans/point-frame-fixed-slots-v2-target-0.json')
selection_path = ROOT / 'matched-row-prospective-selection-v1.json'
selection = read(selection_path)
assert selection['new_experiment_name'] == EXPERIMENT
assert selection['pilot_target_index'] == 3 and selection['pilot_target_id'] == 'HI-point-not-line'
assert constants['CAPS'] == old['limits'] == selection['limits']
assert constants['PRODUCTION_CONFIGURATION'] == old['search_configuration'] == selection['search_configuration']
api, offer = read(api_path), read(offer_path)
modules = {x['role']: x['rawpin'] for x in offer['runtime_roles']}
assert len(modules) == len(offer['runtime_roles']) == len(set(constants['MODULE_ROLES']))
assert len(api['runtime_roles']) == len(modules)
assert set(modules) == set(constants['MODULE_ROLES'])
assert {x['role']: {k: x[k] for k in ('path', 'bytes', 'sha256')} for x in api['runtime_roles']} == modules
assert set(old['module_pins']) <= set(modules)
for role, ref in modules.items():
    verify(ref)
    assert ref['sha256'].encode() in worker_raw
    if role in old['module_pins'] and role != 'provider':
        assert ref == old['module_pins'][role]
assert modules['provider'] == pin(N / 'implementation-B/fpc_full_frame_inventory_v6.py')
assert modules['provider'] == old['module_pins']['provider']
assert modules['csp_controller']['sha256'] in json.dumps(reviews[2])
assert modules['matched_point_controller']['sha256'] in json.dumps(reviews[3])
assert modules['legacy_provider'] == old['module_pins']['legacy_provider']
assert modules['matched_controller_bank']['sha256'] in json.dumps(reviews[1])
populations = {x['population']: {k: x[k] for k in ('control_ids', 'groups', 'bank_role', 'subject_role', 'scope')}
               for x in api['scoped_populations']}
assert len(populations) == len(api['scoped_populations'])
assert set(populations) == set(constants['CONTROL_IDS']) and set(old['control_populations']) < set(populations)
for name, item in old['control_populations'].items():
    current = populations[name]
    for key in ('control_ids', 'groups', 'bank_role'):
        assert current[key] == item[key]
    if name == 'constructor-index14':
        assert current['subject_role'] == 'legacy_provider'
    else:
        assert current['subject_role'] == item['subject_role']
    assert current == item
for name, item in populations.items():
    assert item['control_ids'] == list(constants['CONTROL_IDS'][name])
    assert item['groups'] == len(item['control_ids'])
groups = sum(x['groups'] for x in populations.values())
assert groups == 192
assert api['limits'] == old['limits'] and api['search_configuration'] == old['search_configuration']
custody = {x['role']: x['rawpin'] for x in offer['custody_runtime']}
assert set(custody) == {'runner', 'observer', 'python'}
assert custody['python'] == old['python'] and custody['runner']['path'] == old['runner_path']
inputs = {x['role']: x['rawpin'] for x in offer['raw_inputs']}
assert len(inputs) == len(offer['raw_inputs'])
input_plan_keys = dict(six_declarations='declarations', target_authority_reference='target_authority',
                       explicit_raw13='explicit_raw_models', tiny_seven_declarations='tiny_provider_declarations',
                       conclusion_index_fixtures='conclusion_index_fixtures',
                       fixed_free_slot_fixtures='fixed_free_slot_fixtures')
for row in offer['raw_inputs']:
    if row['role'] not in input_plan_keys:
        key = row['plan_key']
        assert type(key) is str and key and key not in old and key not in input_plan_keys.values()
        assert key not in {'schema', 'case_id', 'target_index', 'target_id', 'experiment', 'actual_dir', 'worker_path', 'protocol', 'files', 'module_pins', 'control_populations'}
        input_plan_keys[row['role']] = key
assert set(inputs) == set(input_plan_keys)
for role, key in input_plan_keys.items():
    verify(inputs[role])
    if key in old:
        assert inputs[role] == old[key]
declarations = read(inputs['six_declarations']['path'])
assert len(declarations['targets']) == 6 and selection['declarations'] == inputs['six_declarations']
assert declarations['targets'][3] == selection['unchanged_original_literal_declaration']
recipes = [dict(case_id=EXPERIMENT + '-' + arm + '-target-' + str(i), arm=arm, target_index=i, target_id=x['id'])
           for i, x in enumerate(declarations['targets']) for arm in ('C0', 'G0')]
assert recipes == selection['prospective_generic_recipes']
guards = {}


def guard(ref):
    verify(ref)
    assert ref['path'] not in guards or guards[ref['path']] == ref
    assert '/actual/' not in ref['path'] and not ref['path'].endswith('.bin')
    guards[ref['path']] = ref


previous_guard_plan = read(ROOT / 'plans/point-frame-fixed-slots-v2-target-0.json')
for ref in previous_guard_plan['files'] + list(modules.values()) + list(custody.values()) + list(inputs.values()) + offer['semantic_guards']:
    guard(ref)
for path in (worker, Path(__file__), api_path, offer_path, selection_path,
             worker_review_path, bank_review_path, csp_review_path, point_review_path):
    guard(pin(path))
for path in (ROOT / 'fixed-free-provider-v6-Root-component-Source-acceptance-v1.json',
             ROOT / 'issue_matched_row_case_grant_v1.py',
             ROOT / 'census_completed_matched_row_case_v1.py'):
    guard(pin(path))
for handoff, field in ((N / 'implementation-B/point-frame-worker-Source-handoff-v7.json', 'files'),
                       (N / 'implementation-B/full-frame-provider-Source-handoff-v6.json', 'files'),
                       (N / 'diagnostics-L/fixed-free-slot-independent-controls-handoff-v2.json', 'artifacts')):
    guard(pin(handoff))
    for ref in read(handoff)[field]:
        guard(ref)
for handoff in (N / 'implementation-B/row-CSP-controller-Source-handoff-v2.json',
                N / 'diagnostics-L/matched-row-controller-independent-controls-handoff-v2.json',
                ROOT / 'point-controller-diagnostics-Source-handoff-v2.json'):
    guard(pin(handoff))
    for ref in read(handoff)['files']:
        guard(ref)
for path in (ROOT / 'matched-row-Root-design-and-declaration-acceptance-v1.json',
             N / 'review-C/typed-preimplementation-CSP-point-equivalence-measurement-obligations-v1.json',
             N / 'review-C/typed-matched-controller8-declarations-and-C0-design-component-review-v1.json',
             N / 'review-C/typed-point-controller-diagnostics-complete-Source-review-v1-negative.json',
             N / 'diagnostics-L/typed-row-CSP-controller-complete-component-Source-review-v1-negative.json',
             N / 'diagnostics-L/typed-row-CSP-controller-v1-negative-line-reference-addendum-v1.json',
             ROOT / 'fpc_point_frame_controller_v2.py',
             N / 'implementation-B/fpc_row_csp_controller_v1.py',
             ROOT / 'author_matched_row_worker_v1.py',
             ROOT / 'author_matched_row_worker_v2.py',
             N / 'implementation-B/fpc_point_frame_search_worker_v6.py'):
    guard(pin(path))
metadata = read(ROOT / 'point-frame-whole-protocol-v1.json')['metadata']
metadata.update(status='PROSPECTIVE_MATCHED_ROW_PAIRED_PILOT_NO_EXECUTION', current_worker=pin(worker),
    component_review=pin(worker_review_path), additive_bank_review=pin(bank_review_path),
    csp_component_review=pin(csp_review_path), point_component_review=pin(point_review_path), original_guard_count_retained=len(old['files']), previous_guard_count_retained=len(previous_guard_plan['files']),
    active_namespaces=len(modules), scoped_group_count=groups,
    control_extension='Original176 retained with explicit subject binding: constructor14 stays on exact legacy provider4; current tiny10/controller10 and new separately scoped fixed-slot controls use provider6. Original126 and explicit16 retain their subjects. No all176-on-v6 claim.',
    mechanism='Shared exact FIXED/FREE witness generation under an assigned own output; preserve complete original members, aliases, order, fallback, guards and EOF. Common symbolic/CSP optimization, no learned marking, lemma-family, RL, bottleneck or speedup claim.',
    repair_boundary='Consumed fixed-slots-v1target3 stopped before search on public Step.action; narrow current Source6 restores NORMALIZE category without changing any expectation or logical candidate generation.',
    old_case_boundary='All six original full-FPC-v1, six constructor-index-v3 and v2 carrier0 remain consumed. No old proof/query/result/control/policy uptake or prefix salvage.',
    initial_selection=[recipes[6], recipes[7]], prospective_selection=pin(selection_path),
    six_statuses=[dict(target_index=x['target_index'], target_id=x['target_id'], status='NOT_RUN') for x in recipes])
metadata['stages'].insert(4, 'Original184 scoped groups on exact previous subjects; additive matched8 on both new controllers, using common provider6')
metadata.update(mechanism='Independent flat-domain/journal CSP driver versus point graph driver, same mandatory logical provider6/candidate universe/order/14phase fuel and frame schedule. Common fixed49scalar diagnostics, no learned marking/RL/receptor library or inference advantage claim.',
    control_extension='All25 previous runtime role pins and184 population objects unchanged. Add matched_point_controller, csp_controller, matched_controller_bank; new matched8 has5protocol and3realprovider scopes. Total28roles/12scopes/192groups,11wrappercalls. Not192 direct tests of any one component.',
    repair_boundary='Point diagnostic Source2 was rejected for stale initial availability; Source3 invalidates a typed output marker before anycallback. Both drivers share this boundary. No new actual has run.',
    six_statuses=[dict(case_id=x['case_id'],arm=x['arm'],target_index=x['target_index'],target_id=x['target_id'],status='NOT_RUN') for x in recipes],
    initial_selection=[recipes[6],recipes[7]],
    diagnostic_scope='Last published fixed-scalar checkpoint only; phase-entry/commit/frame-fold/call-end. All7positive fields null on wholefailure. No afterfault scientific getter or snapshot; worker bounded primitive copy only. Interrupted-phase work may be absent; not a causal profile.')
metadata['admission'] = 'Fresh complete exact scoped populations, same-byte dual proof validators, point representation and complete whole-resource/Source custody. Any fault withholds all seven positive payloads and all prefix qualification; separate Root admission required.'
for recipe in recipes:
    actual = N / 'actual' / recipe['case_id']
    for path in (actual, Path(str(actual) + '.observer'),
                 ROOT / 'grants' / (recipe['case_id'] + '.json'),
                 ROOT / 'plans' / (recipe['case_id'] + '.json'),
                 ROOT / f"matched-row-{recipe['arm']}-target-{recipe['target_index']}-Source-closure-v1.json",
                 ROOT / f"matched-row-{recipe['arm']}-target-{recipe['target_index']}-grant-proposal-v1.json"):
        assert not path.exists() and not path.is_symlink()
for path in (ROOT / 'matched-row-whole-protocol-v1.json', ROOT / 'matched-row-study-preparation-v1.json'):
    assert not path.exists() and not path.is_symlink()
protocol_pin = emit(ROOT / 'matched-row-whole-protocol-v1.json', dict(schema=constants['PROTOCOL_SCHEMA'],
    experiment=EXPERIMENT, limits=constants['CAPS'], module_pins=modules, control_populations=populations,
    job_recipes=recipes, metadata=metadata))
guard(protocol_pin)
files = [guards[k] for k in sorted(guards)]
cases = []
for recipe in recipes:
    i, arm = recipe['target_index'], recipe['arm']
    actual = N / 'actual' / recipe['case_id']
    grant_path = ROOT / 'grants' / (recipe['case_id'] + '.json')
    for path in (actual, Path(str(actual) + '.observer'), grant_path):
        assert not path.exists() and not path.is_symlink()
    plan = dict(old, **recipe, experiment=EXPERIMENT, actual_dir=str(actual), worker_path=str(worker),
                protocol=protocol_pin, files=files, module_pins=modules, control_populations=populations)
    for role, key in input_plan_keys.items():
        plan[key] = inputs[role]
    plan_pin = emit(ROOT / 'plans' / (recipe['case_id'] + '.json'), plan)
    closure_pin = emit(ROOT / f'matched-row-{arm}-target-{i}-Source-closure-v1.json', dict(
        schema='Root-matched-row-closed-Source-v1', status='PROSPECTIVE_GUARDS_NOT_EXECUTION_AUTHORITY',
        plan=plan_pin, protocol=protocol_pin, files=files, namespace_count=len(modules),
        module_roles_in_execution_order=list(constants['MODULE_ROLES']), scoped_group_count=groups,
        scoped_population_count=len(populations), twelve_recipes=recipes,
        closure_rule='All previous176 guarded files retained as Source/input guards; explicit current runtime roles and raw inputs only. No recursive citation eligibility or prior actual/qualification intake.',
        scientific_imports_calls=0, query_proof_encoding=0, actuals_created=0))
    proposal_pin = emit(ROOT / f'matched-row-{arm}-target-{i}-grant-proposal-v1.json', dict(
        schema='Root-point-frame-once-grant-proposal-v1', authorized=False, review_passed=False, uses=1,
        case_id=recipe['case_id'], plan_sha256=plan_pin['sha256'], runner_sha256=custody['runner']['sha256'],
        observer_sha256=custody['observer']['sha256'], plan=plan_pin, protocol=protocol_pin, closure=closure_pin,
        component_review=pin(worker_review_path), additive_bank_review=pin(bank_review_path),
        prospective_grant_path=str(grant_path),
        prospective_command=[custody['python']['path'], '-I', '-S', '-B', custody['observer']['path'], plan_pin['path'], str(grant_path)],
        required_before_separate_grant=['Independent complete exact whole Source/phase/plan/closure/proposal review',
            'Root acceptance and fresh exact guards/path checks', 'Fresh all-agents/tools-idle observation and distinct one-use true grant'],
        scope='False proposal only; no execution, consumed-case replay, prefix salvage or positive admission.'))
    cases.append(dict(recipe=recipe, plan=plan_pin, closure=closure_pin, proposal=proposal_pin))
print(json.dumps(emit(ROOT / 'matched-row-study-preparation-v1.json', dict(
    schema='Root-matched-row-twelve-recipe-preparation-v1', status='PROSPECTIVE_REQUIRES_WHOLE_REVIEW_AND_DISTINCT_TRUE_GRANTS',
    metadata_builder=pin(Path(__file__)), worker=pin(worker), worker_component_review=pin(worker_review_path),
    bank_component_review=pin(bank_review_path), csp_component_review=pin(csp_review_path), point_component_review=pin(point_review_path),
    protocol=protocol_pin, cases=cases, shared_guards=len(files), namespaces=len(modules),
    scoped_populations=len(populations), scoped_groups=groups, pilot_target_index=3,
    original184_and_all_previous_guards_preserved=True, legacy_constructor14_subject='legacy_provider',
    original_six_statements_caps_and_configuration_unchanged=True, all36_paths_absent=True,
    all_false_proposals=True, scientific_imports_calls=0, query_proof_encoding=0, goal_complete=False)), indent=2))
