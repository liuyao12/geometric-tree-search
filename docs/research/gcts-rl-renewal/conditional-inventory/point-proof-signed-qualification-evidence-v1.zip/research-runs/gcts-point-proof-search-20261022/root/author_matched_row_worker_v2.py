"""Source authoring/metadata only. Does not import or call research code."""
from pathlib import Path
import ast
import hashlib
import json

root = Path(__file__).resolve().parent
study = root.parent


def pin(path):
    path = Path(path)
    body = path.read_bytes()
    return dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def read(path):
    return json.loads(Path(path).read_bytes())


def emit(path, data):
    with Path(path).open("x") as handle:
        handle.write(json.dumps(data, indent=2) + "\n")
    return pin(path)


old_source = root.parent / "implementation-B/fpc_point_frame_search_worker_v5.py"
source = old_source.read_text()
old = read(root / "plans/point-frame-fixed-slots-v2-target-0.json")
design = read(study / "implementation-B/matched-conventional-full-frame-baseline-DESIGN-v2.json")
declarations_path = study / "diagnostics-L/matched-row-CSP-point-independent-declarations-v1.json"
declarations = read(declarations_path)
new_roles = {
    "matched_point_controller": pin(root / "fpc_point_frame_controller_v3.py"),
    "csp_controller": pin(study / "implementation-B/fpc_row_csp_controller_v2.py"),
    "matched_controller_bank": pin(study / "diagnostics-L/matched_row_controller_independent_controls_v2.py")}
old_constants = {}
for node in ast.parse(source).body:
    if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
        if node.targets[0].id in ("MODULE_ROLES", "FIXED_PINS", "CONTROL_IDS", "CAPS", "PRODUCTION_CONFIGURATION"):
            old_constants[node.targets[0].id] = ast.literal_eval(node.value)
new_constants = dict(old_constants)
new_constants.update(VERSION="FPC-full-frame-point-worker-v7", EXPERIMENT="matched-row-csp-point-v1",
    MODULE_ROLES=old_constants["MODULE_ROLES"] + tuple(new_roles),
    FIXED_PINS=dict(old_constants["FIXED_PINS"], **{k: (v["bytes"], v["sha256"]) for k, v in new_roles.items()}),
    CONTROL_IDS=dict(old_constants["CONTROL_IDS"], **{"matched-controller8": tuple(declarations["control_ids"])}))
lines = source.splitlines(keepends=True)
for node in reversed(ast.parse(source).body):
    if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
        name = node.targets[0].id
        if name in new_constants:
            lines[node.lineno - 1:node.end_lineno] = [name + " = " + repr(new_constants[name]) + "\n"]
source = "".join(lines)


def replace(old_text, new_text):
    global source
    assert source.count(old_text) == 1, (old_text, source.count(old_text))
    source = source.replace(old_text, new_text, 1)


fields = tuple(design["diagnostics_API"]["fixed_fields"])
replace("\n\nclass RootBudget", "\nWORKER_DIAGNOSTIC_FIELDS = " + repr(fields) +
        "\nMATCHED_FIXTURES_PIN = " + repr((pin(declarations_path)["bytes"], pin(declarations_path)["sha256"])) +
        "\n\nclass RootBudget")
replace("    index = plan['target_index']", "    index, arm = plan['target_index'], plan['arm']")
replace("if not (type(index) is int and 0 <= index < 6", "if not (type(index) is int and 0 <= index < 6\n            and type(arm) is str and arm in ('C0', 'G0')")
replace("plan['case_id'] == EXPERIMENT + '-target-' + str(index)",
        "plan['case_id'] == EXPERIMENT + '-' + arm + '-target-' + str(index)")
replace("    control_subject_bindings = None", "    control_subject_bindings = None\n    search_diagnostics, search_controller_role = None, None")
replace("exact twenty-five namespace roles required", "exact twenty-eight namespace roles required")
replace("'fixed-free-slot8': {'provider': module_pins['provider'], 'baseline_provider': module_pins['legacy_provider']}}",
        "'fixed-free-slot8': {'provider': module_pins['provider'], 'baseline_provider': module_pins['legacy_provider']},\n            'matched-controller8': {role: module_pins[role] for role in\n                ('matched_point_controller', 'csp_controller', 'provider')}}")
replace("'fixed_free_slot_fixtures'):", "'fixed_free_slot_fixtures', 'matched_controller_fixtures'):")
replace("('fixed_free_slot_fixtures', FIXED_SLOT_FIXTURES_PIN)):",
        "('fixed_free_slot_fixtures', FIXED_SLOT_FIXTURES_PIN),\n                              ('matched_controller_fixtures', MATCHED_FIXTURES_PIN)):")
replace("all eleven scoped populations required", "all twelve scoped populations required")
replace("            expected_recipes.append(dict(case_id=EXPERIMENT + '-target-' + str(target_index),\n                                         target_index=target_index, target_id=spec['id']))",
        "            for recipe_arm in ('C0', 'G0'):\n                expected_recipes.append(dict(case_id=EXPERIMENT + '-' + recipe_arm + '-target-' + str(target_index),\n                    arm=recipe_arm, target_index=target_index, target_id=spec['id']))")
replace("all six exact generic case recipes required", "all twelve exact generic arm/target recipes required")
replace("and modules['fixed_slot_bank'].VERSION == 'L-fixed-free-slot-independent-controls-v2'):",
        "and modules['fixed_slot_bank'].VERSION == 'L-fixed-free-slot-independent-controls-v2'\n                and modules['matched_point_controller'].VERSION == 'FPC-POINT-FRAME-CONTROLLER-v3'\n                and modules['csp_controller'].VERSION == 'FPC-ROW-CSP-CONTROLLER-v1'\n                and modules['csp_controller'].IMPLEMENTATION_REVISION == 'FPC-ROW-CSP-CONTROLLER-implementation-v2'\n                and modules['matched_controller_bank'].VERSION == 'L-matched-row-controller-controls-v2'\n                and modules['matched_point_controller'].DIAGNOSTIC_FIELDS == WORKER_DIAGNOSTIC_FIELDS\n                and modules['csp_controller'].DIAGNOSTIC_FIELDS == WORKER_DIAGNOSTIC_FIELDS):")
replace("        fixed_slot_frozen = canonical(fixed_slot_fixtures)",
        "        fixed_slot_frozen = canonical(fixed_slot_fixtures)\n        matched_fixtures = json.loads(Path(plan['matched_controller_fixtures']['path']).read_bytes())\n        matched_frozen = canonical(matched_fixtures)")
replace("        if (canonical(raw_models) != raw_models_frozen", """        qualification['matched-controller8'] = bank('matched-controller8', lambda:
            modules['matched_controller_bank'].run_matched_controller_controls(
                modules['csp_controller'], modules['matched_point_controller'], provider=modules['provider'],
                fixtures=matched_fixtures, declarations=tiny_declarations, row_oracle=modules['tiny_oracle'],
                frame_oracle=modules['frame_oracle'], encoder=modules['tiny_encoder'], modules=kernel_modules, check=check),
            'independent-matched-row-controller-controls-v1', dict(groups=8, passed=8, failed=0),
            'status', 'matched-controller8')
        if qualification['matched-controller8'].get('version') != 'L-matched-row-controller-controls-v2':
            raise ValueError('complete matched-controller8 version required')
        if (canonical(raw_models) != raw_models_frozen""")
replace("or canonical(fixed_slot_fixtures) != fixed_slot_frozen):", "or canonical(fixed_slot_fixtures) != fixed_slot_frozen\n                or canonical(matched_fixtures) != matched_frozen):")
replace("        search_result = stage('SEARCH fresh full-FPC point-frame dovetail', lambda:\n            modules['controller'].search_dovetail(frozen_query, provider=modules['provider'],\n                modules=supplied_modules, max_rounds=supplied_configuration['max_rounds'], check=check))", """        search_controller_role = 'csp_controller' if arm == 'C0' else 'matched_point_controller'
        search_diagnostics = dict.fromkeys(WORKER_DIAGNOSTIC_FIELDS, None)
        search_diagnostics.update(schema='matched-row-controller-diagnostics-v1', arm=arm,
            complete=False, snapshot_available=False, phase_in_progress=False, raw_member_work_supported=False)
        search_result = stage('SEARCH ' + arm + ' fresh full-FPC matched dovetail', lambda:
            modules[search_controller_role].search_dovetail(frozen_query, provider=modules['provider'],
                modules=supplied_modules, max_rounds=supplied_configuration['max_rounds'],
                diagnostics=search_diagnostics, check=check))
        if not copy_search_diagnostics()['available'] or search_diagnostics['complete'] is not True:
            raise ValueError('normally completed exact bounded diagnostics required')""")
replace("and search_result['schema'] == 'FPC-point-dovetail-search-v1'", "and search_result['schema'] == ('FPC-row-CSP-dovetail-search-v1' if arm == 'C0' else 'FPC-point-dovetail-search-v1')")
replace("scope='New finite-frame unit-row point search candidate validated by both original byte checkers; '",
        "scope='New shared-provider matched row driver candidate validated by both original byte checkers; '")
copy_source = '''    def copy_search_diagnostics():
        # Explicit fixed-primitive worker observation; no scientific API/getter/check.
        # In a fault receipt this executes within output/custody limits and cannot
        # replace the original error or qualify a scientific/control prefix.
        unavailable = dict(schema='Root-matched-search-diagnostic-observation-v1',
            available=False, non_authoritative=True, snapshot=None,
            controller_call_complete_at_checkpoint=None)
        try:
            if (type(search_diagnostics) is not dict or
                    len(search_diagnostics) != len(WORKER_DIAGNOSTIC_FIELDS) or
                    any(type(k) is not str for k in search_diagnostics) or
                    set(search_diagnostics) != set(WORKER_DIAGNOSTIC_FIELDS) or
                    search_diagnostics['snapshot_available'] is not True):
                return unavailable
            snapshot = {}
            for key in WORKER_DIAGNOSTIC_FIELDS:
                value = search_diagnostics[key]
                if key in ('complete', 'snapshot_available', 'phase_in_progress', 'raw_member_work_supported'):
                    good = type(value) is bool
                elif key == 'schema':
                    good = type(value) is str and value == 'matched-row-controller-diagnostics-v1'
                elif key == 'arm':
                    good = type(value) is str and value == arm
                elif key == 'active_phase':
                    good = value is None or (type(value) is str and value in (
                        'INVENTORY', 'ROOT', 'DEPENDENCY', 'LOAD', 'REUSE', 'SCAN',
                        'CLASSIFY_OPEN', 'CLASSIFY_ADVANCE', 'FORCE_PLACE', 'BRANCH_OPEN',
                        'OFFER', 'OFFER_PLACE', 'BACKTRACK', 'EXPORT'))
                else:
                    good = value is None or (type(value) is int and value >= 0)
                if not good:
                    return unavailable
                snapshot[key] = value
            if snapshot['raw_member_work_supported'] is not False or snapshot['raw_member_work'] is not None:
                return unavailable
            controller_complete = snapshot['complete']
            if primary is not None:
                snapshot['complete'] = False
            return dict(schema='Root-matched-search-diagnostic-observation-v1', available=True,
                non_authoritative=True, snapshot=snapshot,
                controller_call_complete_at_checkpoint=controller_complete,
                scope='Last published fixed-scalar checkpoint. Interrupted-phase work may be absent; '
                      'counts are not proof, control qualification, a resume input or a causal profile.')
        except BaseException:
            return unavailable

'''
# Define the fixed-copy helper before the first SEARCH; it closes over primary.
replace("    try:\n        check()\n        if type(plan['files'])", copy_source + "    try:\n        check()\n        if type(plan['files'])")
replace("worker_version=VERSION, status=", "worker_version=VERSION, arm=arm, status=")
replace("            control_subject_bindings=control_subject_bindings,", "            control_subject_bindings=control_subject_bindings,\n            search_controller_role=search_controller_role,\n            search_controller_Source=None if search_controller_role is None else module_pins[search_controller_role],\n            search_diagnostic_observation=copy_search_diagnostics(),")
replace("'Constructor14 uses exact legacy4; fixed-free-slot8 and current provider controls use6; 184 groups do not mean 184 tests of provider6. '",
        "'Original184 subject bindings remain exact; matched8 applies separately to both new controllers/provider6. 192 is a scoped group count. '")
replace("usage: fpc_point_frame_search_worker_v5.py PLAN ACTUAL_DIR ROOT_START", "usage: fpc_point_frame_search_worker_v7.py PLAN ACTUAL_DIR ROOT_START")
source_path = study / "implementation-B/fpc_point_frame_search_worker_v7.py"
assert not source_path.exists()
ast.parse(source)
compile(source, str(source_path), "exec")
source_path.write_text(source)

old_offer = read(study / "implementation-B/point-frame-worker-dependency-offer-v5.json")
modules = dict(old["module_pins"], **new_roles)
populations = dict(old["control_populations"])
populations["matched-controller8"] = dict(control_ids=declarations["control_ids"], groups=8,
    bank_role="matched_controller_bank", subject_role="csp_controller",
    scope="Five independent protocol groups and three real provider6 facets for BOTH matched_point_controller and csp_controller; same49field observation and common14phase clock. Oracle complete tiny sets, driver first exports only. No all-profile equivalence or cleanup/fault-sweep proof.")
raw_inputs = list(old_offer["raw_inputs"])
raw_inputs.append(dict(role="matched_controller_fixtures", plan_key="matched_controller_fixtures", rawpin=pin(declarations_path)))
extra_semantic = [pin(p) for p in [
    study / "implementation-B/matched-conventional-full-frame-baseline-DESIGN-v2.json",
    study / "diagnostics-L/matched-row-CSP-point-benchmark-contract-v1.json",
    study / "diagnostics-L/matched-row-CSP-point-declarations-binding-addendum-v1.json",
    root / "point-controller-diagnostics-API-v2.json",
    root / "point-controller-diagnostics-Source-handoff-v2.json"]]
api_path = study / "implementation-B/point-frame-worker-API-v7.json"
api_pin = emit(api_path, dict(schema="Root-matched-row-worker-API-v1",
    status="FROZEN_SOURCE_ONLY_UNRUN_REQUIRES_COMPONENT_AND_WHOLE_REVIEW", worker=pin(source_path),
    VERSION=new_constants["VERSION"], experiment=new_constants["EXPERIMENT"],
    entry="main(plan_path, actual_dir, root_start); isolated once observer/runner only",
    runtime_roles=[dict(role=k, **modules[k]) for k in new_constants["MODULE_ROLES"]],
    scoped_populations=[dict(population=k, **v) for k, v in populations.items()],
    limits=old["limits"], search_configuration=old["search_configuration"],
    arms={"C0": "csp_controller", "G0": "matched_point_controller"},
    recipes="All six original declarations times C0/G0, target index generic, no theorem dispatch. First originaltarget3 C0 thenG0 under Root prospective selection.",
    preserved="All25old runtime roles and184 scoped IDs/populationobjects exact; original controller10 stays oldcontroller1; original constructor14 stays provider4. Add3roles/matched8, yielding28roles/12scopes/192groups. Same10caps and complete seven-positive-field null gates.",
    raw_inputs=raw_inputs,
    staged_execution="Cold exact Source intake/imports; independent in-job original target encoding/freeze before controls; all original10control wrappers plus matched8; selected generic same-provider driver; same immutable proof bytes to original subject+reference, then paired point reduction; Source rehash/complete output/final custody gates.",
    diagnostics="Both SEARCH arms receive the same exact49field strict primitive sink; lastpublished checkpoint only. Worker fixed-key primitive copy is the sole after-fault observation, no module/helper/getter/check or proof state access. Copy failure yields unavailable without replacing first error; all7positive fields stay null. Interrupted-phase returns may be absent; completed+active sums and highwaters retain API meaning. Raw-member work unsupported/None.",
    scientific_claims="Source only. No new theorem, controls qualified, learned marking/RL/receptor benefit, independent kernel or practical/speed advantage. Shared provider still enforces mandatory logical marks.",
    scientific_imports_calls_by_authoring=0))
offer_path = study / "implementation-B/point-frame-worker-dependency-offer-v7.json"
offer_pin = emit(offer_path, dict(schema="Root-matched-row-worker-dependency-offer-v1", worker=pin(source_path),
    runtime_roles=[dict(role=k, rawpin=modules[k]) for k in new_constants["MODULE_ROLES"]],
    custody_runtime=old_offer["custody_runtime"], raw_inputs=raw_inputs,
    semantic_guards=old_offer["semantic_guards"] + extra_semantic,
    scientific_imports_calls=0, scope="Closed explicit Source/input role offer, no prior actual/query/proof/control/library/policy uptake. Root alone creates/reviews plans and true grants."))
static_pin = emit(study / "implementation-B/point-frame-worker-static-v7.json", dict(
    schema="Root-matched-row-worker-static-v1", worker=pin(source_path), author=pin(Path(__file__)),
    unused_compile=True, AST_parse=True, original25_role_pins_retained=True,
    original184_populationobjects_retained=True, new_roles=3, namespaces=28, scoped_populations=12,
    scoped_groups=192, ten_caps_unchanged=True, production_configuration_unchanged=True,
    scope="Source metadata/AST only, no scientific call, test, query or certificate encoding."))
handoff_pin = emit(study / "implementation-B/point-frame-worker-Source-handoff-v7.json", dict(
    schema="Root-matched-row-worker-Source-handoff-v1", status="FROZEN_SOURCE_UNRUN_NO_EXECUTION_AUTHORITY",
    source=pin(source_path), files=[pin(source_path), api_pin, offer_pin, static_pin],
    entry="New once observer/runner under fresh prospectively reviewed Root plans/grants only",
    original_roles=25, namespaces=28, scoped_groups=192, scientific_imports_calls=0))
print(json.dumps(dict(worker=pin(source_path), api=api_pin, offer=offer_pin,
                     static=static_pin, handoff=handoff_pin), indent=2))
