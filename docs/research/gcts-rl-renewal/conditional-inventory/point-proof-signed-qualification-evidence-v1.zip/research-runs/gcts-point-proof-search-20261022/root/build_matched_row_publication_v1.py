"""Render reviewed saved records and package raw evidence; no research calls."""
from pathlib import Path, PurePosixPath
from html import escape
from html.parser import HTMLParser
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
OLD = ROOT / 'fixed-slots-publication-v1'
OUT = ROOT / 'matched-row-publication-v1'


def read(path):
    return json.loads(Path(path).read_bytes())


def pin(path):
    p = Path(path).resolve()
    b = p.read_bytes()
    return dict(path=str(p.relative_to(REPO)), bytes=len(b),
                sha256=hashlib.sha256(b).hexdigest())


def refs(value):
    if isinstance(value, dict):
        if {'path', 'bytes', 'sha256'} <= value.keys():
            yield value
        for child in value.values():
            yield from refs(child)
    elif isinstance(value, list):
        for child in value:
            yield from refs(child)


def emit(path, value):
    with path.open('xb') as f:
        f.write((json.dumps(value, indent=2) + '\n').encode())


data_path = ROOT / 'matched-row-study-Root-whole-results-v1.json'
data = read(data_path)
assert data['whole_actual_reviews_accepted'] is True
assert len(data['cases']) == 2 and [c['arm'] for c in data['cases']] == ['C0', 'G0']
assert data['new_target_proof_admitted'] is False and data['GCTS_or_RL_advantage_established'] is False
files, external = {}, {}


def add(ref):
    p = Path(ref['path'])
    if not p.is_absolute():
        p = REPO / p
    assert p.is_file() and not p.is_symlink()
    b = p.read_bytes()
    assert len(b) == ref['bytes'] and hashlib.sha256(b).hexdigest() == ref['sha256']
    if p.is_relative_to(REPO):
        files[str(p.relative_to(REPO))] = pin(p)
    else:
        external[str(p)] = ref


for ref in read(OLD / 'point-proof-fixed-slots-manifest-v1.json')['members']:
    add(ref)
for record in data['evidence_records']:
    add(record)
    assert '.partial' not in Path(record['path']).name
    if Path(record['path']).suffix == '.json':
        for ref in refs(read(record['path'])):
            add(ref)
for p in (Path(__file__), data_path, OLD / 'point-proof-search-v1.html',
          OLD / 'point-proof-fixed-slots-data-v1.json', OLD / 'point-proof-fixed-slots-manifest-v1.json'):
    add(pin(p))


def number(value):
    return r'\(' + format(value, ',').replace(',', '{,}') + r'\)'


rows, diagnostic_rows = [], []
for c in data['cases']:
    rows.append('<tr><td><strong>' + escape(c['arm_label']) + '</strong></td><td>' +
                escape(c['display_outcome']) + r'</td><td>\(' +
                format(c['observer_elapsed_seconds'], '.3f') + r'\,\mathrm{s}\)</td></tr>')
    d = c['search_diagnostic_observation']['snapshot']
    diagnostic_rows.append('<tr><td>' + escape(c['arm']) + '</td><td>' +
                           number(d['frames_completed']) + '</td><td>' +
                           number(d['completed_atomic_steps_committed'] + d['active_atomic_steps_committed']) +
                           '</td><td>' + number(d['completed_provider_advances_committed'] + d['active_provider_advances_committed']) +
                           r'</td><td>\(n=' + str(d['active_frame_rows']) + ',\ b=' +
                           str(d['active_frame_syntax_nodes']) + r'\)</td></tr>')

section = r'''<section class="panel" id="matched-csp"><p class="eyebrow">Current pilot · ordinary CSP versus point bookkeeping</p><h2>The same proof problem, two search controllers</h2><p>Both arms searched the original symbolic incidence statement \(\forall p\,(\mathrm{Pt}(p)\to\neg\mathrm{Ln}(p))\). Each received the same complete primitive inventory, formula markings, full hypothesis context, member order and fair frame schedule. No intermediate lemma or proof route was supplied.</p><div class="grid"><article class="card"><h3>Shared logical constraints</h3><p>The provider determines legal candidates and mandatory formula-mark agreement. Both controllers check global dead ends, resolve unfinished domains, propagate forced moves and use the same row-order ties.</p></article><article class="card"><h3>Different bookkeeping</h3><p><strong>C0:</strong> flat CSP columns with an undo journal.<br><strong>G0:</strong> an explicit point–candidate graph with saved branch state.<br>This isolates a bookkeeping comparison in the specialized unit-row model.</p></article><article class="card"><h3>Same acceptance boundary</h3><p>A candidate must pass both original byte validators and the point-representation check. Whole costs include fresh controls, search, validation, output and custody.</p></article></div><div class="scroll" style="margin-top:20px"><table><thead><tr><th>Arm</th><th>Whole outcome</th><th>Observer elapsed</th></tr></thead><tbody>''' + ''.join(rows) + r'''</tbody></table></div><p style="margin-top:16px">''' + escape(data['interpretation']) + r'''</p><details open><summary>Last published checkpoints — diagnostic only</summary><div class="scroll" style="margin-top:12px"><table><thead><tr><th>Arm</th><th>Completed frames</th><th>Committed controller steps</th><th>Provider advances</th><th>Active frame</th></tr></thead><tbody>''' + ''.join(diagnostic_rows) + r'''</tbody></table></div><p class="small" style="margin-top:12px">Steps and advances combine completed frames and the active frame, without double counting. Frame visits include restarts and local fuel stops. An interrupted phase may have work missing from its last checkpoint. Raw member work is unsupported, not zero. These observations are neither proof certificates nor a causal profile, and do not establish a speedup.</p></details><p>The original \(160\,\mathrm{s}\) work ceiling and every other cap were retained. Both timed jobs ran serially with other task tools idle. Each reran all eleven control wrappers: the \(184\) earlier scoped groups keep their original subjects, and \(8\) additional groups cover selected protocol endpoints and three tiny-provider facets of the current drivers. The declared total of \(192\) is not a count of direct tests of either driver. Completed stage labels in a failed whole job confer no qualified control prefix.</p><div class="campaign-note"><p>''' + escape(data['contribution_assessment']) + r'''</p></div><p><a href="point-proof-matched-row-evidence-v1.zip">Complete paired-study evidence</a> · <a href="point-proof-matched-row-manifest-v1.json">Manifest</a> · <a href="point-proof-matched-row-data-v1.json">Saved results and diagnostics</a></p></section>'''

page = (OLD / 'point-proof-search-v1.html').read_text()
start, end = page.index('<header>'), page.index('</header>') + len('</header>')
header = r'''<header><p class="eyebrow">22 October 2026 · reproducible proof-search experiments</p><h1>Matched proof search: CSP and point graphs</h1><p class="lead">''' + escape(data['summary']) + r'''</p><p class="notice"><strong>Useful automated theorem search remains unestablished.</strong> The unique admitted theorem count stays \(1\). No learned marking, RL policy or receptor-family benefit is demonstrated.</p><nav><a href="#matched-csp">Current comparison</a><a href="#fixed-slots">Witness fields</a><a href="#cohort">Original study</a><a href="#proof">Read the saved tiles</a><a href="#parallel">Parallel roles</a><a href="#next">Next work</a></nav></header>'''
page = page[:start] + header + section + page[end:]
old_next = read(OLD / 'point-proof-fixed-slots-data-v1.json')['next_step']
assert escape(old_next) in page
page = page.replace(escape(old_next), escape(data['next_step']))
start, end = page.index('<section class="panel" id="parallel">'), page.index('<section class="panel" id="next">')
parallel = r'''<section class="panel" id="parallel"><h2>Parallel agents, separate responsibilities</h2><div class="grid"><article class="card"><h3>Implementation</h3><p>One agent implemented the conventional CSP controller. Root integrated it with the common provider and wrote the point-controller diagnostic successor.</p></article><article class="card"><h3>Independent expectations</h3><p>A second agent declared protocol and tiny-instance expectations before reading the new controller, implemented the controls, then independently reviewed the CSP code.</p></article><article class="card"><h3>Critical review</h3><p>A third agent reviewed the point-controller changes, test bank and complete paired plan, then checked each saved terminal record without replay.</p></article></div><p style="margin-top:18px">Parallel source review found two observation defects: a stale diagnostic sink could appear current after an early fault, and completed-frame counters could be folded before cleanup succeeded. Narrow successors repaired both; earlier versions and negative reviews remain in the archive. Root integrates, accepts and publishes the evidence. The agents do not supply target proofs. Timed experiments run serially with the other task tools idle; implementation, independent checking and future benchmark design can proceed in parallel.</p></section>\n'''
page = page[:start] + parallel + page[end:]
page = page.replace('</section>\\n<section', '</section>\n<section')


class Check(HTMLParser):
    def __init__(self):
        super().__init__()
        self.ids, self.links = [], []
    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if 'id' in attrs:
            self.ids.append(attrs['id'])
        if tag == 'a':
            self.links.append(attrs.get('href', ''))


check = Check()
check.feed(page)
assert len(check.ids) == len(set(check.ids))
assert all(link[1:] in check.ids for link in check.links if link.startswith('#'))
assert page.count('class="proof-line') == 3
assert 'id="matched-csp"' in page and '\\n<section' not in page
OUT.mkdir(exist_ok=False)
with (OUT / 'point-proof-search-v1.html').open('x') as f:
    f.write(page)
emit(OUT / 'point-proof-matched-row-data-v1.json', data)
manifest = dict(schema='GCTS-point-proof-matched-row-manifest-v1',
    members=[files[k] for k in sorted(files)], external_runtime=list(external.values()),
    raw_member_count=len(files), raw_member_bytes=sum(x['bytes'] for x in files.values()),
    public_page=pin(OUT / 'point-proof-search-v1.html'),
    public_status=pin(OUT / 'point-proof-matched-row-data-v1.json'), scientific_imports_calls=0,
    scope='Complete preserved earlier studies plus frozen current components, prospective twelve recipes and two whole negative actuals. External interpreter pinned, not bundled; no scientific replay.')
emit(OUT / 'point-proof-matched-row-manifest-v1.json', manifest)
with zipfile.ZipFile(OUT / 'point-proof-matched-row-evidence-v1.zip', 'x',
                     compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    bodies = [(name, (REPO / name).read_bytes()) for name in sorted(files)]
    bodies += [('MANIFEST.json', (OUT / 'point-proof-matched-row-manifest-v1.json').read_bytes()),
               ('PUBLIC-RESULT.json', (OUT / 'point-proof-matched-row-data-v1.json').read_bytes()),
               ('README.txt', (data['summary'] + '\n' + data['interpretation'] +
                               '\nPackaging made no research calls or proof replay.\n').encode())]
    assert len({name for name, _ in bodies}) == len(bodies)
    for name, raw in bodies:
        assert not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts
        item = zipfile.ZipInfo(name, (2026, 10, 22, 0, 0, 0))
        item.compress_type = zipfile.ZIP_DEFLATED
        z.writestr(item, raw)
with zipfile.ZipFile(OUT / 'point-proof-matched-row-evidence-v1.zip') as z:
    assert z.testzip() is None and len(z.namelist()) == len(files) + 3
    for name in files:
        assert z.read(name) == (REPO / name).read_bytes()
print(json.dumps(dict(public_files=[pin(p) for p in sorted(OUT.iterdir())],
                      raw_members=len(files), scientific_imports_calls=0), indent=2))
