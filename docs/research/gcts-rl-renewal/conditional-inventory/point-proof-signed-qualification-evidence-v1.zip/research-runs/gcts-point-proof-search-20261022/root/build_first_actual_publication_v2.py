"""Display and raw packaging of a completed admitted actual. No research imports/calls."""
from pathlib import Path
import hashlib
import json
import zipfile
from html.parser import HTMLParser

ROOT = Path(__file__).resolve().parent
N = ROOT.parent
REPO = N.parents[1]
OUT = ROOT / 'first-actual-publication-v2'
ACTUAL = N / 'actual/point-frame-full-FPC-v1-target-0'


def pin(path):
    path = Path(path).resolve()
    raw = path.read_bytes()
    return {'path': str(path.relative_to(REPO)) if path.is_relative_to(REPO) else str(path),
            'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def read(path):
    return json.loads(Path(path).read_bytes())


def emit(path, value):
    with path.open('xb') as output:
        output.write((json.dumps(value, indent=2) + '\n').encode())


disposition_path = ROOT / 'point-frame-target-0-Root-whole-disposition-v1.json'
disposition = read(disposition_path)
assert disposition['admitted'] is True
assert disposition['status'] == 'FOUND_VALID_ROOT_WHOLE_ADMITTED'
C_review_path = Path(disposition['C_actual_review']['path'])
assert pin(C_review_path)['sha256'] == disposition['C_actual_review']['sha256']
result = read(ACTUAL / 'result.json')
plan_path = ROOT / 'plans/point-frame-full-FPC-v1-target-0.json'
plan = read(plan_path)
observer = read(Path(str(ACTUAL) + '.observer') / 'observer.json')
assert observer['resource_candidate_accepted'] is True
assert result['qualification_complete'] is True and result['status'] == 'COMPLETE'
assert result['subject_receipt']['accepted'] is True
assert result['reference_receipt']['status'] == 'VALID_DERIVATION'
assert result['point_receipt']['point_compatible'] is True
assert result['source_unchanged'] is True and result['first_Root_fault'] is False

files = {}
external = []
for ref in plan['files']:
    path = Path(ref['path']).resolve()
    current = pin(path)
    assert current['bytes'] == ref['bytes'] and current['sha256'] == ref['sha256']
    if path.is_relative_to(REPO):
        files[str(path)] = current
    else:
        external.append(ref)
assert len(external) == 1 and external[0] == plan['python']

extra = [plan_path, disposition_path, C_review_path, Path(__file__),
         ROOT / 'point-frame-whole-Source-closure-v1.json',
         ROOT / 'point-frame-whole-preparation-v1.json',
         ROOT / 'point-frame-target-0-grant-proposal-v1.json',
         ROOT / 'point-frame-target-0-Root-prospective-acceptance-v1.json',
         ROOT / 'point-frame-target-0-all-tools-idle-barrier-v1.json',
         ROOT / 'point-frame-target-0-first-terminal-raw-census-v1.json',
         ROOT / 'point-frame-target-0-Root-saved-group-census-v1.json',
         ROOT / 'grants/point-frame-full-FPC-v1-target-0.json',
         N / 'review-C/typed-point-frame-target-0-whole-prospective-Source-plan-review-v1.json',
         N / 'review-C/typed-point-frame-target-0-grant-proposal-component-review-v1.json',
         N / 'diagnostics-L/typed-point-proof-first-actual-draft-display-review-v1.json',
         N / 'review-C/passive_point_frame_target0_actual_review_v1.py',
         N / 'review-C/typed-point-frame-target-0-actual-passive-audit-v1.json',
         ROOT / 'first-actual-publication-v1/point-proof-search-v1.draft.html',
         OUT / 'point-proof-search-v1.draft-v2.html',
         N / 'implementation-B/matched-conventional-full-frame-baseline-handoff-v1.json',
         N / 'implementation-B/matched-conventional-full-frame-baseline-DESIGN-v1.json']
for directory in (ACTUAL, Path(str(ACTUAL) + '.observer')):
    extra.extend(sorted(path for path in directory.rglob('*') if path.is_file()))
for path in extra:
    path = path.resolve()
    assert path.is_relative_to(REPO) and path.is_file()
    assert '.partial' not in path.name
    files[str(path)] = pin(path)

search = result['search_result']
status = {
    'schema': 'GCTS-point-proof-first-actual-public-result-v1', 'date': '2026-10-22',
    'status': 'FOUND_VALID_ROOT_WHOLE_ADMITTED', 'case_id': plan['case_id'],
    'target_id': plan['target_id'], 'theorem_latex': r'\forall x\,(x=x)',
    'scope': 'Elementary equality/generalization development control; not substantive arithmetic discovery.',
    'actual_review': pin(C_review_path), 'Root_disposition': pin(disposition_path),
    'result': pin(ACTUAL / 'result.json'), 'query': pin(ACTUAL / 'target-query.bin'),
    'certificate': pin(ACTUAL / 'candidate-certificate.bin'),
    'controls': read(ROOT / 'point-frame-target-0-Root-saved-group-census-v1.json'),
    'proof_rows': [
        {'row': 0, 'formula_latex': 'x=x', 'rule': 'E1', 'references': [],
         'English': 'The arbitrary object x equals itself.'},
        {'row': 1, 'formula_latex': 'x=x', 'rule': 'E1', 'references': [],
         'English': 'The same equality is asserted again; this duplicate is unused.'},
        {'row': 2, 'formula_latex': r'\forall x\,(x=x)', 'rule': 'GEN', 'references': [0],
         'English': 'Generalize row 0; the fixed hypothesis set is empty.'}],
    'saved_export': search['export_receipt'], 'search_metrics': search['metrics'],
    'last_frame': search['last_frame'],
    'same_byte_subject_receipt': result['subject_receipt'],
    'same_byte_reference_receipt': result['reference_receipt'],
    'point_observation': result['point_receipt'],
    'costs': {'whole_observer_elapsed_seconds': observer['elapsed_seconds'],
              'final_observer_gate_seconds': observer['final_observer_gate_seconds'],
              'conservative_whole_peak_bytes': observer['conservative_whole_peak_bytes'],
              'worker_header_callbacks': read(ACTUAL / 'worker-header.json')['callbacks'],
              'stages': result['stages'], 'all_ten_limits': plan['limits']},
    'six_recipes': read(plan['protocol']['path'])['job_recipes'],
    'other_five_status': 'NOT_RUN_IN_THIS_STUDY',
    'learned_markings': False, 'RL_used': False, 'learned_lemma_families': False,
    'GCTS_or_RL_advantage_established': False, 'strict_finite_Wang_palette_constructed': False,
    'minimal_proof_claim': False, 'packaging_scientific_imports_calls': 0,
    'historical_consumed_failures_replayed': False, 'goal_complete': False}
emit(OUT / 'point-proof-first-actual-data-v1.json', status)
page = (OUT / 'point-proof-search-v1.draft-v2.html').read_text()
assert page.count('ACTUAL_REVIEW_STATUS') == 1
page = page.replace('ACTUAL_REVIEW_STATUS', 'passed')
with (OUT / 'point-proof-search-v1.html').open('x') as output:
    output.write(page)


class PageCheck(HTMLParser):
    def __init__(self):
        super().__init__()
        self.ids, self.links = [], []

    def handle_starttag(self, tag, attrs):
        data = dict(attrs)
        if 'id' in data:
            self.ids.append(data['id'])
        if tag == 'a':
            self.links.append(data.get('href', ''))


parser = PageCheck()
parser.feed(page)
assert len(parser.ids) == len(set(parser.ids))
assert all(link[1:] in parser.ids for link in parser.links if link.startswith('#'))
assert page.count('class="proof-line') == 3
assert 'The arbitrary object \\(x\\) equals itself.' in page
assert 'GCTS_conformance=false' in page and 'No matched baseline was run' in page
manifest = {
    'schema': 'GCTS-point-proof-first-actual-manifest-v1', 'date': '2026-10-22',
    'scope': 'Complete target-0 saved actual and custody packet, original guarded project files, current reviews and Root disposition. External interpreter pinned, not bundled. Packaging never executes research sources.',
    'members': [files[key] for key in sorted(files)], 'external_runtime': external,
    'raw_member_count': len(files), 'raw_member_bytes': sum(x['bytes'] for x in files.values()),
    'all_guarded_inputs_rehashed': 70,
    'public_page': pin(OUT / 'point-proof-search-v1.html'),
    'public_status': pin(OUT / 'point-proof-first-actual-data-v1.json'),
    'packaging_scientific_imports_calls': 0}
emit(OUT / 'point-proof-first-actual-manifest-v1.json', manifest)
readme = ('First complete point-tile search actual, 22 October 2026.\n\n'
          'Original PA-reflexivity statement; automatic three-row E1/E1/GEN certificate.\n'
          'Whole actual, independent review and Root disposition are distinct included records.\n'
          'The unused duplicate row is retained. No proof minimality, arithmetic discovery, RL, learned marking, reusable family or speed advantage is claimed.\n'
          'Original consumed negatives are not replayed. Other five statements remain unrun in this study.\n'
          'Source/record packaging only. Pinned external Python binary is not bundled.\n')
archive = OUT / 'point-proof-first-actual-evidence-v1.zip'
assert not archive.exists()
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    bodies = [(files[key]['path'], Path(key).read_bytes()) for key in sorted(files)]
    bodies += [('MANIFEST.json', (OUT / 'point-proof-first-actual-manifest-v1.json').read_bytes()),
               ('PUBLIC-RESULT.json', (OUT / 'point-proof-first-actual-data-v1.json').read_bytes()),
               ('README.txt', readme.encode())]
    for name, body in bodies:
        info = zipfile.ZipInfo(name, (2026, 10, 22, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        bundle.writestr(info, body)
with zipfile.ZipFile(archive) as bundle:
    assert bundle.testzip() is None and len(bundle.namelist()) == len(files) + 3
    for key in sorted(files):
        assert bundle.read(files[key]['path']) == Path(key).read_bytes()
print(json.dumps({'public_files': [pin(OUT / name) for name in (
    'point-proof-search-v1.html', 'point-proof-first-actual-data-v1.json',
    'point-proof-first-actual-manifest-v1.json', 'point-proof-first-actual-evidence-v1.zip')],
    'raw_members': len(files), 'raw_bytes': manifest['raw_member_bytes'],
    'packaging_scientific_imports_calls': 0}, indent=2))
