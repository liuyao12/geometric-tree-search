"""Render admitted saved metadata and package evidence; no scientific calls."""
from pathlib import Path, PurePosixPath
from html import escape
from html.parser import HTMLParser
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
OUT = ROOT / 'fixed-slots-publication-v1'
OLD = ROOT / 'constructor-index-publication-v2'


def read(path):
    return json.loads(Path(path).read_bytes())


def pin(path):
    path = Path(path).resolve()
    raw = path.read_bytes()
    return dict(path=str(path.relative_to(REPO)), bytes=len(raw),
                sha256=hashlib.sha256(raw).hexdigest())


def refs(value):
    if isinstance(value, dict):
        if {'path', 'bytes', 'sha256'} <= value.keys():
            yield value
        for child in value.values():
            yield from refs(child)
    elif isinstance(value, list):
        for child in value:
            yield from refs(child)


def emit(path, value):
    with path.open('xb') as stream:
        stream.write((json.dumps(value, indent=2) + '\n').encode())


data_path = ROOT / 'fixed-slot-study-Root-whole-results-v1.json'
data = read(data_path)
assert data['whole_actual_review_accepted'] is True
assert data['RL_used'] is False and data['GCTS_or_RL_advantage_established'] is False
files, external = {}, {}


def add(ref):
    path = Path(ref['path'])
    if not path.is_absolute():
        path = REPO / path
    assert path.is_file() and not path.is_symlink()
    raw = path.read_bytes()
    assert len(raw) == ref['bytes'] and hashlib.sha256(raw).hexdigest() == ref['sha256']
    if path.is_relative_to(REPO):
        files[str(path.relative_to(REPO))] = pin(path)
    else:
        external[str(path)] = ref


for ref in read(OLD / 'point-proof-constructor-index-manifest-v1.json')['members']:
    add(ref)
for record in data['evidence_records']:
    add(record)
    assert '.partial' not in Path(record['path']).name
    if Path(record['path']).suffix == '.json':
        for ref in refs(read(record['path'])):
            add(ref)
for path in (Path(__file__), data_path, OLD / 'point-proof-search-v1.html',
             OLD / 'point-proof-constructor-index-data-v1.json',
             OLD / 'point-proof-constructor-index-manifest-v1.json'):
    add(pin(path))

rows = []
for case in data['cases']:
    rows.append('<tr><td><code>' + escape(case['case_id']) + '</code></td><td>' +
                escape(case['display_outcome']) + '</td><td>\\(' +
                format(case['observer_elapsed_seconds'], '.3f') +
                r'\,\mathrm{s}\)</td></tr>')
section = r'''<section class="panel" id="fixed-slots"><p class="eyebrow">Current experiment · unchanged incidence statement</p><h2>Use the output formula to fix witness fields</h2><p>The next generator uses an actually assigned row output to determine the witness coordinates that its rule exposes. Every remaining free coordinate stays available in its original order. This is a shared symbolic/CSP optimization, with the same logical tiles and proof checker.</p><div class="grid"><article class="card"><h3>Rigid output</h3><p>\(A\to(B\to A)\) determines both \(A\) and \(B\). Repeated occurrences must agree exactly.</p></article><article class="card"><h3>Residual choices</h3><p>\((\forall x\,A)\to A[t/x]\) exposes \(A,x\). The generator retains every term \(t\), including distinct witnesses that leave \(A\) unchanged.</p></article><article class="card"><h3>Full checks</h3><p>Each candidate still passes construction, side conditions, the finite syntax envelope and every formula-mark agreement. Complete exhaustion remains necessary for a forced move.</p></article></div><p style="margin-top:18px">The prospectively selected target is \(\forall p\,(\mathrm{Pt}(p)\to\neg\mathrm{Ln}(p))\), in the declared symbolic incidence fragment. No drawing or supplied intermediate lemma enters search. It is a public development statement, not a blind holdout.</p><div class="scroll"><table><thead><tr><th>Separate once attempt</th><th>Whole outcome</th><th>Observer elapsed</th></tr></thead><tbody>''' + ''.join(rows) + r'''</tbody></table></div><p class="small" style="margin-top:14px">The same \(160\,\mathrm{s}\) work limit and all other original caps apply. Each fresh job includes its own imports, encoding, controls, search, checking and output. Failed jobs qualify no proof or control prefix; qualified whole memory remains unknown.</p><div class="campaign-note"><p>''' + escape(data['interpretation']) + r'''</p></div><details><summary>The first attempt caught a public-interface defect</summary><p style="margin-top:12px">The new internal normalization phase leaked into the public action label. The unchanged tiny-provider test rejected that label before target search. Earlier source reviews had missed the closed action vocabulary. The narrow successor restores the existing normalization action while retaining internal progress and every test expectation. The original attempt and reviews are preserved, with no passing prefix transferred.</p></details><p style="margin-top:16px">The prospective population is \(176+8=184\) scoped groups. The original constructor-index groups retain the legacy provider; current-provider and new fixed-slot groups have explicit version bindings. This is not a count of direct tests of one provider, nor an exhaustive all-profile verification.</p><p>Learned markings, an RL policy and a reusable receptor-family inventory are still absent from this experiment. A matched conventional search must receive this same generator.</p><p><a href="point-proof-fixed-slots-evidence-v1.zip">Complete fixed-slot evidence</a> · <a href="point-proof-fixed-slots-manifest-v1.json">Manifest</a> · <a href="point-proof-fixed-slots-data-v1.json">Saved results</a></p></section>'''

page = (OLD / 'point-proof-search-v1.html').read_text()
start, end = page.index('<header>'), page.index('</header>') + len('</header>')
header = r'''<header><p class="eyebrow">22 October 2026 · reproducible proof-search experiments</p><h1>Fixed witness fields: the first incidence pilot</h1><p class="lead">''' + escape(data['summary']) + r'''</p><p class="notice"><strong>Useful automated theorem search remains unestablished.</strong> The unique admitted theorem count is \(''' + str(data['unique_theorems']) + r'''\). No learned marking, RL policy, receptor-family benefit or advantage over a conventional prover is demonstrated.</p><nav><a href="#fixed-slots">Current pilot</a><a href="#constructor-index">Indexing study</a><a href="#cohort">Original study</a><a href="#proof">Read the saved tiles</a><a href="#parallel">Parallel roles</a><a href="#next">Next work</a></nav></header>'''
page = page[:start] + header + section + page[end:]
old_next = 'The original six cases and the new indexing-study cases remain separate immutable experiments. Structural rule-family exclusion has now been tested; it belongs in the common baseline. The smallest proposed next change uses a required conclusion to fix candidate witness fields before enumeration, while retaining every residual choice and full candidate identity. That mechanism has not been implemented or timed. A conventional CSP comparison must use the same inventory, propagation and exact scheduler. The next practical milestone is fresh automatic discovery of a harder unchanged goal under the original limits, with no supplied intermediate lemma or proof route. Learned markings, reusable receptor families and RL need separate evidence.'
assert old_next in page
page = page.replace(old_next, escape(data['next_step']))
page = page.replace('Parallel agents have helped with independent work',
                    'Separate agents: implementation, expectations and critical review')
page = page.replace('Independent agents improve coverage; execution remains essential.',
    'In the current cycle, literal equations and aliases were frozen before implementation, '
    'a separate agent built the generator, and a reviewer checked the source and whole plan. '
    'The public-action failure still escaped review and was caught by execution. '
    'Root integrates and publishes the evidence. Parallelism helps development and checking; '
    'it is not evidence of better automated proof search.')


class Check(HTMLParser):
    def __init__(self):
        super().__init__()
        self.ids, self.links = [], []
    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if 'id' in attrs:
            self.ids.append(attrs['id'])
        if tag == 'a':
            self.links.append(attrs.get('href', ''))


check = Check()
check.feed(page)
assert len(check.ids) == len(set(check.ids))
assert all(link[1:] in check.ids for link in check.links if link.startswith('#'))
assert page.count('class="proof-line') == 3
assert data['new_target_proof_admitted'] is False
OUT.mkdir(exist_ok=True)
with (OUT / 'point-proof-search-v1.html').open('x') as stream:
    stream.write(page)
emit(OUT / 'point-proof-fixed-slots-data-v1.json', data)
manifest = dict(schema='GCTS-point-proof-fixed-slots-manifest-v1',
    members=[files[k] for k in sorted(files)], external_runtime=list(external.values()),
    raw_member_count=len(files), raw_member_bytes=sum(x['bytes'] for x in files.values()),
    public_page=pin(OUT / 'point-proof-search-v1.html'),
    public_status=pin(OUT / 'point-proof-fixed-slots-data-v1.json'),
    scientific_imports_calls=0,
    scope='Selected complete historical studies, current failed attempt and narrow successor. '
          'Source reviews retain their declared limits. External interpreter pinned, not bundled.')
emit(OUT / 'point-proof-fixed-slots-manifest-v1.json', manifest)
with zipfile.ZipFile(OUT / 'point-proof-fixed-slots-evidence-v1.zip', 'x',
                     compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    bodies = [(name, (REPO / name).read_bytes()) for name in sorted(files)]
    bodies += [('MANIFEST.json', (OUT / 'point-proof-fixed-slots-manifest-v1.json').read_bytes()),
               ('PUBLIC-RESULT.json', (OUT / 'point-proof-fixed-slots-data-v1.json').read_bytes()),
               ('README.txt', (data['summary'] + '\n' + data['interpretation'] +
                               '\nPackaging made no research calls or proof replay.\n').encode())]
    assert len({name for name, _ in bodies}) == len(bodies)
    for name, raw in bodies:
        assert not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts
        item = zipfile.ZipInfo(name, (2026, 10, 22, 0, 0, 0))
        item.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(item, raw)
with zipfile.ZipFile(OUT / 'point-proof-fixed-slots-evidence-v1.zip') as archive:
    assert archive.testzip() is None and len(archive.namelist()) == len(files) + 3
    for name in files:
        assert archive.read(name) == (REPO / name).read_bytes()
print(json.dumps(dict(public_files=[pin(p) for p in sorted(OUT.iterdir())],
                      raw_members=len(files), scientific_imports_calls=0), indent=2))
