"""Narrow historical-display successor; raw packaging only, no research imports."""
from pathlib import Path, PurePosixPath
import hashlib
import json
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
OLD = ROOT / 'cohort-publication-v1'
OUT = ROOT / 'cohort-publication-v2'


def pin(path):
    p = Path(path).resolve()
    raw = p.read_bytes()
    return {'path': str(p.relative_to(REPO)), 'bytes': len(raw),
            'sha256': hashlib.sha256(raw).hexdigest()}


def emit(path, value):
    with path.open('xb') as f:
        f.write((json.dumps(value, indent=2) + '\n').encode())


review_path = Path(sys.argv[1]).resolve()
review = json.loads(review_path.read_bytes())
assert review_path.is_relative_to(ROOT.parent / 'review-C')
OUT.mkdir(exist_ok=True)
old_manifest = json.loads((OLD / 'point-proof-cohort-manifest-v1.json').read_bytes())
files = {}
for ref in old_manifest['members']:
    p = REPO / ref['path']
    assert pin(p) == ref
    files[ref['path']] = ref
page = (OLD / 'point-proof-search-v1.html').read_text()
before = 'These are preserved historical snapshots, before runtime qualification.'
after = ('These historical snapshots preserve their original scope. The first admitted proof archive records '
         'the qualified reflexivity run before the other five were attempted; the three earlier source '
         'archives precede runtime qualification.')
assert page.count(before) == 1 and page.count('This first run contains no such learned inventory.') == 1
page = page.replace(before, after).replace('This first run contains no such learned inventory.',
                                         'This experiment contains no such learned inventory.')
with (OUT / 'point-proof-search-v1.html').open('x') as f:
    f.write(page)
with (OUT / 'point-proof-cohort-data-v1.json').open('xb') as f:
    f.write((OLD / 'point-proof-cohort-data-v1.json').read_bytes())
for p in (Path(__file__), review_path, OLD / 'point-proof-search-v1.html',
          OLD / 'point-proof-cohort-manifest-v1.json'):
    ref = pin(p)
    files[ref['path']] = ref
manifest = dict(old_manifest)
manifest.update({
    'schema': 'GCTS-point-proof-cohort-manifest-v2',
    'revision': 'Historical first-case qualification wording repaired; scientific records/data unchanged.',
    'prior_package_review': pin(review_path),
    'members': [files[k] for k in sorted(files)],
    'raw_member_count': len(files), 'raw_member_bytes': sum(x['bytes'] for x in files.values()),
    'public_page': pin(OUT / 'point-proof-search-v1.html'),
    'public_status': pin(OUT / 'point-proof-cohort-data-v1.json')})
emit(OUT / 'point-proof-cohort-manifest-v1.json', manifest)
readme = ('Six original public development targets; one admitted elementary reflexivity proof and five whole-work deadline failures.\n'
          'V2 repairs only a temporal description of the first proof archive; identical current cohort data.\n'
          'V1 display and its independent negative review are preserved historical evidence, not the current page.\n'
          'Old first-case files saying other targets were unrun describe their original checkpoint. PUBLIC-RESULT gives current six-case outcomes.\n'
          'Case0 alone has 162 qualified scoped control groups. Five failures supply no positive prefix and no qualified whole memory.\n'
          'No practical theorem-search, matched-baseline, learned marking, RL or receptor-family advantage established.\n'
          'Full selected Source/records only; no research invocation by packaging. External interpreter pinned, not bundled.\n')
with zipfile.ZipFile(OUT / 'point-proof-cohort-evidence-v1.zip', 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    bodies = [(name, (REPO / name).read_bytes()) for name in sorted(files)]
    bodies += [('MANIFEST.json', (OUT / 'point-proof-cohort-manifest-v1.json').read_bytes()),
               ('PUBLIC-RESULT.json', (OUT / 'point-proof-cohort-data-v1.json').read_bytes()),
               ('README.txt', readme.encode())]
    assert len({name for name, _ in bodies}) == len(bodies)
    for name, raw in bodies:
        assert not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts
        info = zipfile.ZipInfo(name, (2026, 10, 22, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        z.writestr(info, raw)
with zipfile.ZipFile(OUT / 'point-proof-cohort-evidence-v1.zip') as z:
    assert z.testzip() is None and len(z.namelist()) == len(files) + 3
    for name in sorted(files):
        assert z.read(name) == (REPO / name).read_bytes()
print(json.dumps({'public_files': [pin(OUT / name) for name in (
    'point-proof-search-v1.html', 'point-proof-cohort-data-v1.json',
    'point-proof-cohort-manifest-v1.json', 'point-proof-cohort-evidence-v1.zip')],
    'raw_members': len(files), 'raw_bytes': manifest['raw_member_bytes'],
    'scientific_imports_calls': 0}, indent=2))
