"""Disposition saved whole negatives and compose publication metadata only."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

ROOT = Path(__file__).resolve().parent
N = ROOT.parent


def read(path):
    return json.loads(Path(path).read_bytes())


def pin(path):
    path = Path(path).resolve()
    assert path.is_file() and not path.is_symlink() and '.partial' not in path.name
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def emit(path, value):
    with path.open('xb') as stream:
        stream.write((json.dumps(value, indent=2) + '\n').encode())
    return pin(path)


fields = ['qualification_result', 'input_freeze', 'search_result', 'subject_receipt',
          'reference_receipt', 'point_receipt', 'scientific_result']
review_path = N / 'review-C/typed-fixed-slot-v2-target-3-complete-negative-actual-review-v1.json'
review = read(review_path)
failure_path = N / 'actual/point-frame-fixed-slots-v2-target-3/failure.json'
failure = read(failure_path)
assert review['negative_classification_supported'] is True
assert review['negative_review_checks_passed'] is True and review['review_passed'] is False
assert review['failures'] == [] and all(failure[k] is None for k in fields)
assert failure['qualification_complete'] is False and failure['first_Root_fault'] is True
assert failure['error']['message'] == 'absolute whole-work deadline'
stages = failure['stages']
controls = [x for x in stages if x['name'].startswith('CONTROLS ')]
search = [x for x in stages if x['name'].startswith('SEARCH ')]
assert len(controls) == 10 and all(x['status'] == 'COMPLETED' for x in controls)
assert len(search) == 1 and search[0]['status'] == 'STARTED'
disposition_path = ROOT / 'fixed-slot-v2-target-3-Root-whole-negative-disposition-v1.json'
emit(disposition_path, dict(
    schema='Root-fixed-slot-v2-target3-whole-negative-disposition-v1',
    issued_utc=datetime.now(timezone.utc).isoformat(),
    status='WHOLE_NEGATIVE_ACCEPTED_NO_SCIENTIFIC_PREFIX',
    case_id=review['case_id'], target_index=3, target_id='HI-point-not-line',
    admitted=False, negative_review_accepted=True,
    C_complete_negative_review=pin(review_path), failure=pin(failure_path),
    raw_census=pin(ROOT / 'fixed-slot-target-3-first-terminal-raw-census-v2.json'),
    owned_terminal_observation=pin(ROOT / 'fixed-slot-v2-owned-process-terminal-observation-v1.json'),
    exec_session_id=95792, exec_exit_code=2, consumed=True, retry_authority=False,
    target_search_started=True, search_start_worker_seconds=search[0]['began'],
    diagnostic_completed_bank_wrappers=10, qualified_current_control_result=None,
    first_Root_fault=True, qualification_complete=False,
    positive_payloads={k: None for k in fields}, qualified_whole_peak_bytes=None,
    observer_elapsed_seconds=review['costs']['observer_elapsed_seconds'],
    observer_tool_summary_seconds=review['costs']['observer_tool_summary_seconds'],
    callbacks=failure['callbacks'], physical_files=12, physical_bytes=22117, partial_files=0,
    finding='Fresh repaired pipeline progressed beyond all ten control wrappers and reached target search, then the whole-work deadline interrupted it. All seven positive payloads are null. Diagnostic completed-stage labels confer no qualified bank/input prefix. No result/certificate or new theorem.',
    limits='No finite exhaustion/nonprovability, cause profile, admitted memory bound, speed/fit/GCTS/RL advantage. Current five sibling plans remain unexecuted/ungranted; no additional actual this cycle.',
    scientific_imports_calls=0, goal_complete=False))

evidence = {}


def add(path):
    ref = pin(path)
    evidence[ref['path']] = ref


for version in (1, 2):
    for name in (
        f'fixed-slot-study-preparation-v{version}.json',
        f'fixed-slot-whole-protocol-v{version}.json',
        f'fixed-slot-prospective-pilot-selection-v{version}.json',
        f'fixed-slot-study-Root-whole-prospective-acceptance-v{version}.json',
        f'fixed-slot-target-3-Root-prospective-acceptance-v{version}.json',
        f'fixed-slot-target-3-all-tools-idle-barrier-v{version}.json',
        f'fixed-slot-target-3-first-terminal-raw-census-v{version}.json',
        f'fixed-slot-v{version}-owned-process-terminal-observation-v1.json',
        f'fixed-slot-v{version}-target-3-Root-whole-negative-disposition-v1.json'):
        add(ROOT / name)
    add(ROOT / f'grants/point-frame-fixed-slots-v{version}-target-3.json')
    prep = read(ROOT / f'fixed-slot-study-preparation-v{version}.json')
    for row in prep['cases']:
        for key in ('plan', 'closure', 'proposal'):
            add(row[key]['path'])
    for row in read(ROOT / f'fixed-slot-target-3-first-terminal-raw-census-v{version}.json')['files']:
        assert row['partial_opaque'] is False
        assert pin(row['path']) == {k: row[k] for k in ('path', 'bytes', 'sha256')}
        add(row['path'])
    add(N / f'review-C/typed-fixed-slot-six-target-complete-whole-prospective-Source-plan-proposal-review-v{version}.json')
    add(N / f'review-C/typed-fixed-slot-v{version}-target-3-complete-negative-actual-review-v1.json')
for path in (
    N / 'implementation-B/full-frame-provider-Source-handoff-v5.json',
    N / 'implementation-B/full-frame-provider-Source-handoff-v6.json',
    N / 'implementation-B/point-frame-worker-Source-handoff-v4.json',
    N / 'implementation-B/point-frame-worker-Source-handoff-v5.json',
    N / 'diagnostics-L/fixed-free-slot-independent-controls-handoff-v1.json',
    N / 'diagnostics-L/fixed-free-slot-independent-controls-handoff-v2.json',
    N / 'review-C/typed-full-frame-provider-fixed-free-complete-Source-review-v5.json',
    N / 'review-C/typed-fixed-free-slot-independent-bank-complete-Source-review-v1.json',
    N / 'review-C/typed-fixed-slot-provider6-bank2-narrow-component-Source-review-v1.json',
    N / 'diagnostics-L/typed-point-frame-worker4-caller-component-Source-review-v1.json',
    N / 'diagnostics-L/typed-point-frame-worker5-caller-successor-component-Source-review-v1.json',
    N / 'diagnostics-L/fixed-slots-v2-evidence-and-minimum-matched-study-v1.json',
    ROOT / 'fixed-free-provider-v5-Root-component-Source-acceptance-v1.json',
    ROOT / 'fixed-free-provider-v6-Root-component-Source-acceptance-v1.json',
    ROOT / 'verify_published_fixed_slot_v1.py', Path(__file__)):
    add(path)

cases = []
for version, label in ((1, 'Interface failure before target search'),
                       (2, 'Whole-work deadline during target search; no proof')):
    c = read(N / f'review-C/typed-fixed-slot-v{version}-target-3-complete-negative-actual-review-v1.json')
    cases.append(dict(
        case_id=c['case_id'], target_index=3, target_id='HI-point-not-line',
        display_outcome=label, admitted=False,
        observer_elapsed_seconds=c['costs']['observer_elapsed_seconds'],
        observer_tool_summary_seconds=c['costs']['observer_tool_summary_seconds'],
        target_search_started=version == 2, qualification_complete=False,
        positive_payloads={k: None for k in fields},
        qualified_whole_peak_bytes=None, callbacks=c['costs']['callbacks'],
        physical_bytes=c['costs']['physical_bytes'], physical_files=12, partial_files=0,
        C_negative_review=pin(N / f'review-C/typed-fixed-slot-v{version}-target-3-complete-negative-actual-review-v1.json'),
        Root_disposition=pin(ROOT / f'fixed-slot-v{version}-target-3-Root-whole-negative-disposition-v1.json')))

data = dict(
    schema='Root-fixed-slot-study-whole-results-v1',
    issued_utc=datetime.now(timezone.utc).isoformat(),
    whole_actual_review_accepted=True,
    scope='Two complete separately consumed WHOLE NEGATIVES, no admitted current proof or control prefix.',
    summary='Fixing output-determined witness fields did not yet solve the selected incidence statement. The first attempt caught an interface defect; the narrow repaired run reached search and then the original work deadline.',
    interpretation='The repaired job completed all ten control-stage wrappers and entered search at about 19.81 worker seconds, then hit the 160-second whole-work deadline without returning a proof. Those stage labels are diagnostic: all seven positive payloads and the current qualification result remain null. The unique admitted theorem count stays one, elementary reflexivity from the earlier studies. No learned marking, RL or receptor-family advantage is established.',
    next_step='The next decisive experiment is a matched conventional CSP versus point-bookkeeping comparison using the same provider, full context, guards, frame/fuel schedule and current row-order ties. In this unit-row model the semantic decisions should coincide; compare actually saved diagnostics and total cost. A separate receptor-family study must acquire reusable primitive-proof clusters on fresh training tasks, validate every expansion and test structurally different problems against fixed and uniform selection of the same library. Original consumed cases remain immutable; no proof route is supplied.',
    cases=cases, original_development_targets_retained=6,
    current_other_five=[dict(target_index=i, status='NOT_RUN_UNGRANTED') for i in range(6) if i != 3],
    declared_scoped_groups=184, declared_scoped_populations=11,
    original_scoped_groups_retained=176, additional_fixed_slot_groups=8,
    current_population_qualified=False, qualified_current_group_result=None,
    diagnostic_search_stage_start_worker_seconds=search[0]['began'],
    new_target_proof_admitted=False, new_distinct_theorems=0, unique_theorems=1,
    RL_used=False, learned_markings_used=False, receptor_library_used=False,
    GCTS_or_RL_advantage_established=False, matched_conventional_baseline_run=False,
    provider_census='UNSUPPORTED production-wide provider counters under unchanged trace0 controller.',
    evidence_records=[evidence[k] for k in sorted(evidence)],
    scientific_imports_calls=0, proof_or_control_replays=0,
    goal_status='ACTIVE_UNBUDGETED_INCOMPLETE')
print(json.dumps(emit(ROOT / 'fixed-slot-study-Root-whole-results-v1.json', data), indent=2))
