"""Package selected complete evidence and render saved results; no research calls."""
from pathlib import Path, PurePosixPath
from html import escape
from html.parser import HTMLParser
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
OUT = ROOT / 'constructor-index-publication-v1'


def read(p):
    return json.loads(Path(p).read_bytes())


def pin(p):
    p = Path(p).resolve()
    b = p.read_bytes()
    return {'path': str(p.relative_to(REPO)), 'bytes': len(b),
            'sha256': hashlib.sha256(b).hexdigest()}


def refs(v):
    if isinstance(v, dict):
        if {'path', 'bytes', 'sha256'} <= v.keys():
            yield v
        for child in v.values():
            yield from refs(child)
    elif isinstance(v, list):
        for child in v:
            yield from refs(child)


def emit(p, v):
    with p.open('xb') as f:
        f.write((json.dumps(v, indent=2) + '\n').encode())


result_path = ROOT / 'constructor-index-study-Root-whole-results-v1.json'
data = read(result_path)
assert data['whole_actual_review_accepted'] is True
assert len(data['cases']) == 6
assert data['RL_used'] is False and data['GCTS_or_RL_advantage_established'] is False
old = ROOT / 'cohort-publication-v2'
old_data = read(old / 'point-proof-cohort-data-v1.json')
files = {}
external = {}


def add(ref):
    p = Path(ref['path'])
    if not p.is_absolute():
        p = REPO / p
    assert p.is_file() and not p.is_symlink()
    b = p.read_bytes()
    assert len(b) == ref['bytes'] and hashlib.sha256(b).hexdigest() == ref['sha256']
    if p.is_relative_to(REPO):
        files[str(p.relative_to(REPO))] = pin(p)
    else:
        external[str(p)] = ref


for ref in read(old / 'point-proof-cohort-manifest-v1.json')['members']:
    add(ref)
for record in data['evidence_records']:
    add(record)
    assert '.partial' not in Path(record['path']).name
    for ref in refs(read(record['path'])):
        add(ref)
for p in (Path(__file__), result_path, old / 'point-proof-search-v1.html',
          old / 'point-proof-cohort-data-v1.json', old / 'point-proof-cohort-manifest-v1.json'):
    add(pin(p))

rows = []
for previous, current in zip(old_data['cases'], data['cases']):
    assert previous['target_id'] == current['target_id']
    name = escape(current['display_name'])
    cells = []
    for row in (previous, current):
        solved = row['admitted']
        label = 'Checked proof' if solved else 'Work deadline; no proof'
        sec = row['whole_observer_elapsed_seconds']
        css = 'solved' if solved else ''
        cells.append(f'<td><span class="outcome {css}">{label}</span><br>'
                     f'\\({sec:.3f}\\,\\mathrm{{s}}\\)'
                     f'<div class="campaign-bar"><span class="{css}" '
                     f'style="width:{min(100, sec / 161 * 100):.3f}%"></span></div></td>')
    rows.append('<tr><td>' + name + '</td>' + ''.join(cells) + '</tr>')

section = r'''<section class="panel" id="constructor-index"><p class="eyebrow">New changed-source study · original statements and limits</p><h2>Does indexing rule shapes make the search useful?</h2><p>The new provider rejects a whole rule family when a required conclusion has an incompatible syntax shape. For example, an equality axiom can only produce an equality. The complete legal tile inventory, witness identities and search order remain the same. This is ordinary symbolic indexing; it is not a learned geometric marking or an RL policy.</p><div class="scroll"><table><thead><tr><th>Statement</th><th>Original inventory</th><th>Constructor index</th></tr></thead><tbody>''' + ''.join(rows) + r'''</tbody></table></div><p class="small" style="margin-top:14px">Bars show whole elapsed time, including fresh controls and custody. The original run used (162) scoped control groups; the new run adds (14) explicitly scoped groups. Both retain the (160,mathrm{s}) work ceiling and every other resource limit. This comparison is not a matched comparison with a conventional prover.</p><div class="campaign-note"><p>''' + escape(data['interpretation']) + r'''</p><p style="margin:0">A failed whole job supplies no qualified proof, input or control prefix. Its qualified whole memory stays unknown. A deadline is neither exhaustive search nor a nonprovability result.</p></div><details><summary>An end-to-end run caught a missed test-bank defect</summary><p style="margin-top:12px">The first indexing-study attempt stopped before target search: the added bank rejected its own evidence carrier. Source inspection found that the bank embedded a checker receipt containing a finite elapsed-time float, while its final copier accepted no floats. Prior source reviews missed this incompatibility. The corrected bank accepts finite diagnostic floats, with the same tests, expectations and search. The consumed failed job is preserved; its five unexecuted sibling plans were superseded. No proof or control prefix was transferred to the new study.</p></details><p style="margin-top:16px"><a href="point-proof-constructor-index-evidence-v1.zip">Full indexing-study evidence</a> · <a href="point-proof-constructor-index-manifest-v1.json">Manifest</a> · <a href="point-proof-constructor-index-data-v1.json">Saved results</a></p></section>'''

section = section.replace('(162)', r'\(162\)').replace('(14)', r'\(14\)')
section = section.replace('(160,mathrm{s})', r'\(160\,\mathrm{s}\)')
success = data['current_success']
peak_latex = format(success['whole_peak_bytes'], ',').replace(',', '{,}')
costs = (f'<p>The successful indexing run passed \\(176/176\\) scoped groups and took '
         f'\\({success["whole_seconds"]:.3f}\\,\\mathrm{{s}}\\) overall, including '
         f'\\({success["search_seconds"]:.3f}\\,\\mathrm{{s}}\\) for target search. '
         f'Its qualified whole peak was \\({peak_latex}\\) bytes. '
         'It rediscovered the identical certificate with the same '
         '\\(97\\) frame visits and \\(7{,}380\\) controller steps. '
         'The tile reader below shows those same saved rows. The unique proved theorem count remains \\(1\\).</p>')
section = section.replace('<div class="campaign-note">', costs + '<div class="campaign-note">', 1)
page = (old / 'point-proof-search-v1.html').read_text()
start, end = page.index('<header>'), page.index('</header>') + len('</header>')
header = r'''<header><p class="eyebrow">22 October 2026 · reproducible proof-search experiments</p><h1>Structural indexing tested on the same six statements</h1><p class="lead">''' + escape(data['summary']) + r'''</p><p class="notice"><strong>Useful automated theorem search remains unestablished.</strong> The admitted theorem is elementary reflexivity. No learned marking, RL policy, receptor family or advantage over an existing prover has been demonstrated.</p><nav><a href="#constructor-index">New experiment</a><a href="#cohort">Original experiment</a><a href="#proof">Read the actual tiles</a><a href="#parallel">Parallel work</a><a href="#next">Research direction</a><a href="#evidence">Earlier evidence</a></nav></header>'''
page = page[:start] + header + section + page[end:]
page = page.replace('The elementary success did not extend to the other targets',
                    'Original experiment: one elementary success, five deadlines')
page = page.replace('The admitted reflexivity run</h2>', 'The original admitted reflexivity run</h2>')
old_next = 'All six current cases are now consumed; the five failed cases will not be replayed for diagnostics. Next, examine candidate generation and a conventional search under the same logical semantics, with prospectively declared new experiments. A source-only investigation asks whether whole rule families can be excluded from a constrained row before enumerating their witnesses. This is ordinary symbolic indexing and belongs in the common baseline. Learned markings, reusable receptor families and RL still need separate evidence.'
new_next = 'The original six cases and the new indexing-study cases remain separate immutable experiments. Structural rule-family exclusion has now been tested; it belongs in the common baseline. The smallest proposed next change uses a required conclusion to fix candidate witness fields before enumeration, while retaining every residual choice and full candidate identity. That mechanism has not been implemented or timed. A conventional CSP comparison must use the same inventory, propagation and exact scheduler. The next practical milestone is fresh automatic discovery of a harder unchanged goal under the original limits, with no supplied intermediate lemma or proof route. Learned markings, reusable receptor families and RL need separate evidence.'
assert old_next in page
page = page.replace(old_next, new_next)
page = page.replace(
    'Development can proceed in parallel, while timing experiments remain isolated.',
    'Development can proceed in parallel, while timing experiments remain isolated. '
    'In the indexing cycle, an end-to-end run exposed an evidence-carrier defect that '
    'the source reviews had missed. The failed run, reviews and narrowly corrected '
    'successor are all preserved. Independent agents improve coverage; execution remains essential.')


class Check(HTMLParser):
    def __init__(self):
        super().__init__()
        self.ids, self.links = [], []
    def handle_starttag(self, tag, attrs):
        d = dict(attrs)
        if 'id' in d:
            self.ids.append(d['id'])
        if tag == 'a':
            self.links.append(d.get('href', ''))


c = Check()
c.feed(page)
assert len(c.ids) == len(set(c.ids))
assert all(x[1:] in c.ids for x in c.links if x.startswith('#'))
assert page.count('class="proof-line') == 3
OUT.mkdir(exist_ok=True)
with (OUT / 'point-proof-search-v1.html').open('x') as f:
    f.write(page)
emit(OUT / 'point-proof-constructor-index-data-v1.json', data)
manifest = {'schema': 'GCTS-point-proof-constructor-index-manifest-v1',
            'members': [files[k] for k in sorted(files)],
            'external_runtime': list(external.values()), 'raw_member_count': len(files),
            'raw_member_bytes': sum(x['bytes'] for x in files.values()),
            'public_page': pin(OUT / 'point-proof-search-v1.html'),
            'public_status': pin(OUT / 'point-proof-constructor-index-data-v1.json'),
            'scientific_imports_calls': 0,
            'scope': 'Selected complete original cohort, failed carrier attempt and corrected new study; current and historical Source/reviews retain their original scope. External runtime pinned, not bundled.'}
emit(OUT / 'point-proof-constructor-index-manifest-v1.json', manifest)
with zipfile.ZipFile(OUT / 'point-proof-constructor-index-evidence-v1.zip', 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    bodies = [(name, (REPO / name).read_bytes()) for name in sorted(files)]
    bodies += [('MANIFEST.json', (OUT / 'point-proof-constructor-index-manifest-v1.json').read_bytes()),
               ('PUBLIC-RESULT.json', (OUT / 'point-proof-constructor-index-data-v1.json').read_bytes()),
               ('README.txt', (data['summary'] + '\n' + data['interpretation'] + '\nNo research calls or proof replay by packaging.\n').encode())]
    assert len({name for name, _ in bodies}) == len(bodies)
    for name, raw in bodies:
        assert not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts
        item = zipfile.ZipInfo(name, (2026, 10, 22, 0, 0, 0))
        item.compress_type = zipfile.ZIP_DEFLATED
        z.writestr(item, raw)
with zipfile.ZipFile(OUT / 'point-proof-constructor-index-evidence-v1.zip') as z:
    assert z.testzip() is None and len(z.namelist()) == len(files) + 3
    for name in files:
        assert z.read(name) == (REPO / name).read_bytes()
print(json.dumps({'public_files': [pin(p) for p in sorted(OUT.iterdir())],
                  'raw_members': len(files), 'scientific_imports_calls': 0}, indent=2))
