"""Raw metadata dispositions and display packaging; never import or run research code."""
from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
from html.parser import HTMLParser
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent
N = ROOT.parent
REPO = N.parents[1]
OUT = ROOT / 'cohort-publication-v1'


def read(path):
    return json.loads(Path(path).read_bytes())


def pin(path, relative=False):
    p = Path(path).resolve()
    raw = p.read_bytes()
    return {'path': str(p.relative_to(REPO)) if relative else str(p),
            'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def verify(ref):
    p = Path(ref['path'])
    if not p.is_absolute():
        p = REPO / p
    assert not p.is_symlink() and p.is_file()
    now = pin(p)
    assert (now['bytes'], now['sha256']) == (ref['bytes'], ref['sha256']), str(p)
    return p


def emit(path, data):
    with Path(path).open('xb') as f:
        f.write((json.dumps(data, indent=2) + '\n').encode())


def pins_in(value):
    if isinstance(value, dict):
        if {'path', 'bytes', 'sha256'} <= value.keys():
            yield value
        else:
            for v in value.values():
                yield from pins_in(v)
    elif isinstance(value, list):
        for v in value:
            yield from pins_in(v)


batch_path = N / 'review-C/typed-remaining-five-point-frame-complete-negative-actual-batch-review-v1.json'
batch = read(batch_path)
assert batch['review_complete'] and batch['negative_classification_supported']
assert batch['positive_jobs_admitted'] == 0 and batch['failed_whole_jobs'] == 5
assert batch['review_defects'] == []
assert batch['counts']['complete_raw_files'] == 60 and batch['counts']['partial_files'] == 0
for ref in pins_in(batch):
    verify(ref)

dispositions = []
reviews = []
all_raw = []
for i, entry in enumerate(batch['cases'], 1):
    review_path = verify(entry['review'])
    d = read(review_path)
    assert d['target_index'] == i and d['review_complete'] and d['negative_classification_supported']
    assert d['review_defects'] == [] and len(d['checks']) == 6
    assert all(x['passed'] is True for x in d['checks'])
    assert all(d[k] is False for k in ('review_passed', 'resource_admitted', 'scientific_qualified', 'stage_complete'))
    assert d['whole_peak_bytes'] is None and d['qualification_complete'] is False
    assert all(v is None for v in d['positive_payload_fields'].values())
    assert d['error']['type'] == 'RootBudget' and d['error']['message'] == 'absolute whole-work deadline'
    assert 160 <= d['whole_seconds'] < 180 and d['exec_exit_code'] == 2
    for ref in pins_in(d):
        verify(ref)
    raw = d['complete_actual_file_census']['files']
    assert len(raw) == 12 and not any(x['partial_opaque'] for x in raw)
    all_raw.extend(raw)
    value = {
        'schema': 'Root-point-frame-whole-negative-disposition-v1',
        'issued_utc': datetime.now(timezone.utc).isoformat(),
        'case_id': d['case_id'], 'target_index': i, 'target_id': d['target_id'],
        'status': 'FAILED_CASE_NOT_ADMITTED', 'admitted': False,
        'negative_review_accepted': True,
        'review_passed': False, 'resource_admitted': False,
        'scientific_qualified': False, 'stage_complete': False,
        'gate_semantics': 'Accept the complete negative classification only; all four positive whole-job qualification gates remain false.',
        'C_actual_review': pin(review_path), 'C_batch_review': pin(batch_path),
        'plan': d['plan'], 'grant': d['grant'], 'closure': d['closure'],
        'failure': d['failure'], 'terminal': d['terminal'], 'observer': d['observer'],
        'raw_census': d['raw_census'],
        'whole_observer_elapsed_seconds': d['whole_seconds'],
        'qualified_whole_peak_bytes': None, 'worker_header_callbacks': d['callbacks'],
        'all70_guards_current': True, 'complete12_raw_files_current': True,
        'positive_payloads': d['positive_payload_fields'],
        'controls_qualified': False, 'query_freeze_admitted': False,
        'cause': 'absolute whole-work deadline',
        'interpretation': 'No proof found within this work budget. Not search exhaustion, nonprovability, a memory diagnosis, or evidence of GCTS/RL advantage. Failed header keeps qualified whole peak null. Interrupt stacks do not identify the current frame or dominant cost.',
        'consumed': True, 'retry_authority': False, 'prefix_salvage': False,
        'scientific_imports_calls_by_disposition': 0, 'goal_complete': False}
    path = ROOT / f'point-frame-target-{i}-Root-whole-negative-disposition-v1.json'
    emit(path, value)
    dispositions.append(pin(path))
    reviews.append(d)

batch_disposition_path = ROOT / 'remaining-five-Root-whole-negative-batch-disposition-v1.json'
emit(batch_disposition_path, {
    'schema': 'Root-point-frame-remaining-five-negative-batch-disposition-v1',
    'issued_utc': datetime.now(timezone.utc).isoformat(),
    'C_batch_review': pin(batch_path), 'cases': dispositions,
    'accepted_complete_negatives': 5, 'positive_admissions': 0,
    'complete_raw_files_verified': len(all_raw),
    'complete_raw_bytes_verified': sum(x['bytes'] for x in all_raw),
    'partial_files': 0, 'all_shared70_guards_current': True,
    'scientific_imports_calls': 0, 'prefix_salvage': False, 'retry_authority': False})

# Start with the already published, reviewed complete first-case packet. Keep its
# historical status in its historical file, and supersede it in the cohort data.
old = ROOT / 'first-actual-publication-v2'
old_manifest = read(old / 'point-proof-first-actual-manifest-v1.json')
files = {}
external = old_manifest['external_runtime']
for ref in old_manifest['members']:
    p = verify(ref)
    files[str(p)] = pin(p, relative=True)

extra = [Path(__file__), batch_path, batch_disposition_path,
         ROOT / 'cohort-publication-v1/point-proof-search-v1.draft.html',
         old / 'point-proof-first-actual-data-v1.json',
         old / 'point-proof-first-actual-manifest-v1.json']
for ref in pins_in(batch):
    extra.append(verify(ref))
for ref in dispositions:
    extra.append(verify(ref))
for d in reviews:
    for ref in pins_in(d):
        p = verify(ref)
        if p.is_relative_to(REPO):
            extra.append(p)
        else:
            assert any(ref['sha256'] == x['sha256'] for x in external)
for p in extra:
    p = p.resolve()
    assert p.is_relative_to(REPO) and '.partial' not in p.name
    files[str(p)] = pin(p, relative=True)

first = read(old / 'point-proof-first-actual-data-v1.json')
cases = [{
    'target_index': 0, 'target_id': first['target_id'],
    'status': first['status'], 'admitted': True,
    'goal_latex': first['theorem_latex'],
    'whole_observer_elapsed_seconds': first['costs']['whole_observer_elapsed_seconds'],
    'qualified_whole_peak_bytes': first['costs']['conservative_whole_peak_bytes'],
    'controls_qualified': True, 'scoped_control_groups': 162,
    'C_actual_review': first['actual_review'], 'Root_disposition': first['Root_disposition'],
    'query': first['query'], 'certificate': first['certificate'],
    'proof_rows': first['proof_rows'], 'minimal_proof_claim': False}]
for i, d in enumerate(reviews, 1):
    cases.append({
        'target_index': i, 'target_id': d['target_id'], 'status': d['status'],
        'admitted': False, 'goal_latex': d['saved_literal_input_scope']['goal_latex'][2:-2],
        'whole_observer_elapsed_seconds': d['whole_seconds'],
        'qualified_whole_peak_bytes': None, 'worker_header_callbacks': d['callbacks'],
        'controls_qualified': False, 'query_freeze_admitted': False,
        'C_actual_review': pin(Path(batch['cases'][i-1]['review']['path'])),
        'Root_disposition': dispositions[i-1], 'proof': None,
        'positive_payloads': d['positive_payload_fields'],
        'cause': 'absolute whole-work deadline', 'consumed': True, 'retry_authority': False})
data = {
    'schema': 'GCTS-point-proof-six-target-cohort-result-v1', 'date': '2026-10-22',
    'summary': 'One elementary automatically discovered checked proof; five whole-work deadline failures.',
    'cases': cases, 'admitted_proofs': 1, 'whole_deadline_failures': 5,
    'all_six_consumed': True, 'same_runtime_Source_configuration_caps': True,
    'limits': first['costs']['all_ten_limits'],
    'development_set_not_blind_holdout': True,
    'negative_batch_review': pin(batch_path), 'Root_negative_batch_disposition': pin(batch_disposition_path),
    'first_case_details': pin(old / 'point-proof-first-actual-data-v1.json', relative=True),
    'interpretation': 'Case0 is an equality/generalization control, not substantive arithmetic discovery. No qualified proof/control/input prefix is salvaged from failed cases. Null qualified peaks do not mean zero or a memory failure. No finite exhaustion or unprovability conclusion follows. No current-frame or elimination metrics survive the failed result gate.',
    'matched_baseline_run': False, 'learned_markings': False, 'RL_used': False,
    'learned_lemma_families': False, 'GCTS_or_RL_advantage_established': False,
    'strict_finite_Wang_palette_constructed': False,
    'candidate_generation_investigation': 'Source-only structural indexing proposal, not a measured bottleneck or learned effect. Requires independent fixtures and a prospectively reviewed experiment before execution.',
    'scientific_imports_calls_by_packaging': 0, 'goal_complete': False}
emit(OUT / 'point-proof-cohort-data-v1.json', data)
page = (OUT / 'point-proof-search-v1.draft.html').read_text()
assert page.count('NEGATIVE_REVIEW_STATUS') == 1
page = page.replace('NEGATIVE_REVIEW_STATUS', 'passed')
with (OUT / 'point-proof-search-v1.html').open('x') as f:
    f.write(page)


class Check(HTMLParser):
    def __init__(self):
        super().__init__()
        self.ids, self.links = [], []
    def handle_starttag(self, tag, attrs):
        d = dict(attrs)
        if 'id' in d:
            self.ids.append(d['id'])
        if tag == 'a':
            self.links.append(d.get('href', ''))


parser = Check()
parser.feed(page)
assert len(parser.ids) == len(set(parser.ids))
assert all(x[1:] in parser.ids for x in parser.links if x.startswith('#'))
assert page.count('class="proof-line') == 3
assert 'NEGATIVE_REVIEW_STATUS' not in page
assert 'GCTS_conformance=false' in page and 'No matched baseline was run' in page
manifest = {
    'schema': 'GCTS-point-proof-cohort-manifest-v1', 'date': '2026-10-22',
    'scope': 'Full published target0 packet plus five complete original negatives, immutable reviews and separate Root dispositions. Only selected research Source and records; external interpreter pinned, not bundled. Historical records keep their original temporal scope.',
    'members': [files[k] for k in sorted(files)], 'external_runtime': external,
    'raw_member_count': len(files), 'raw_member_bytes': sum(x['bytes'] for x in files.values()),
    'all_guarded_inputs_rehashed': 70,
    'public_page': pin(OUT / 'point-proof-search-v1.html', relative=True),
    'public_status': pin(OUT / 'point-proof-cohort-data-v1.json', relative=True),
    'scientific_imports_calls': 0}
emit(OUT / 'point-proof-cohort-manifest-v1.json', manifest)
readme = ('Six original public development targets, 22 October 2026.\n'
          'One automatically discovered E1/E1/GEN reflexivity proof; five 160-second whole-work deadline failures.\n'
          'Each actual is consumed; no replay or prefix salvage. Case0 alone supplies 162 qualified scoped control groups.\n'
          'Complete negative review acceptance is distinct from failed positive qualification. Null qualified memory is unknown, not zero.\n'
          'Historical first-case records saying other cases were unrun describe their original checkpoint; PUBLIC-RESULT supersedes that status.\n'
          'No practical theorem-search, matched-baseline, learned marking, RL or lemma-family benefit established.\n'
          'Ordinary source and metadata packaging; does not execute the research system. External Python pin only.\n')
archive = OUT / 'point-proof-cohort-evidence-v1.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    bodies = [(files[k]['path'], Path(k).read_bytes()) for k in sorted(files)]
    bodies += [('MANIFEST.json', (OUT / 'point-proof-cohort-manifest-v1.json').read_bytes()),
               ('PUBLIC-RESULT.json', (OUT / 'point-proof-cohort-data-v1.json').read_bytes()),
               ('README.txt', readme.encode())]
    assert len({name for name, _ in bodies}) == len(bodies)
    for name, body in bodies:
        assert not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts
        info = zipfile.ZipInfo(name, (2026, 10, 22, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        z.writestr(info, body)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist()) == len(files)+3
    for k in sorted(files):
        assert z.read(files[k]['path']) == Path(k).read_bytes()
print(json.dumps({'public_files': [pin(OUT / name) for name in (
    'point-proof-search-v1.html', 'point-proof-cohort-data-v1.json',
    'point-proof-cohort-manifest-v1.json', 'point-proof-cohort-evidence-v1.zip')],
    'negative_batch_disposition': pin(batch_disposition_path),
    'raw_members': len(files), 'raw_bytes': manifest['raw_member_bytes'],
    'scientific_imports_calls': 0}, indent=2))
