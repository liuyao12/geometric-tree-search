"""Metadata-only one-use issuance, after Root's fresh live tools-idle observation."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parent
N = ROOT.parent


def read(path):
    return json.loads(Path(path).read_bytes())


def pin(path):
    p = Path(path)
    assert p.is_absolute() and p.resolve() == p and not p.is_symlink() and p.is_file()
    raw = p.read_bytes()
    return {'path': str(p), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def verify(ref):
    assert pin(ref['path']) == ref


def emit(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as f:
        f.write((json.dumps(value, indent=2) + '\n').encode())
    return pin(path)


assert len(sys.argv) == 2 and sys.argv[1] in ('0', '1', '2', '3', '4', '5')
index = int(sys.argv[1])
prep_path = ROOT / 'fixed-slot-study-preparation-v2.json'
accept_path = ROOT / 'fixed-slot-study-Root-whole-prospective-acceptance-v2.json'
prep, accepted = read(prep_path), read(accept_path)
assert accepted['accepted_prospective_metadata'] is True
assert accepted['preparation'] == pin(prep_path)
for key in ('preparation', 'whole_review', 'worker_component_review', 'bank_component_review'):
    verify(accepted[key])
for key in ('whole_review', 'worker_component_review', 'bank_component_review'):
    assert read(accepted[key]['path'])['review_passed'] is True
row = prep['cases'][index]
assert row['recipe']['target_index'] == index
for key in ('plan', 'closure', 'proposal'):
    verify(row[key])
plan, closure, proposal = [read(row[k]['path']) for k in ('plan', 'closure', 'proposal')]
assert plan['experiment'] == 'point-frame-fixed-slots-v2'
assert plan['case_id'] == proposal['case_id'] == row['recipe']['case_id']
assert proposal['authorized'] is False and proposal['review_passed'] is False
assert type(proposal['uses']) is int and proposal['uses'] == 1
assert proposal['plan'] == closure['plan'] == row['plan']
assert proposal['closure'] == row['closure']
assert proposal['component_review'] == accepted['worker_component_review']
assert proposal['additive_bank_review'] == accepted['bank_component_review']
for key in ('protocol', 'component_review', 'additive_bank_review'):
    verify(proposal[key])
protocol = read(plan['protocol']['path'])
assert plan['protocol'] == closure['protocol'] == proposal['protocol'] == prep['protocol']
assert protocol['job_recipes'][index] == row['recipe']
assert closure['files'] == plan['files'] and len(plan['files']) == prep['shared_guards']
assert len(plan['module_pins']) == prep['namespaces'] and len(plan['control_populations']) == prep['scoped_populations']
assert plan['module_pins'] == protocol['module_pins']
assert plan['control_populations'] == protocol['control_populations']
assert sum(x['groups'] for x in plan['control_populations'].values()) == prep['scoped_groups'] > 176
old = read(ROOT / 'plans/point-frame-full-FPC-v1-target-0.json')
legacy = read(ROOT / 'plans/point-frame-constructor-index-v3-target-0.json')
assert plan['control_populations']['constructor-index14']['subject_role'] == 'legacy_provider'
for field in ('control_ids', 'groups', 'bank_role'):
    assert plan['control_populations']['constructor-index14'][field] == legacy['control_populations']['constructor-index14'][field]
assert plan['module_pins']['legacy_provider'] == legacy['module_pins']['provider']
assert len(plan['limits']) == 10 and plan['limits'] == protocol['limits'] == old['limits']
assert plan['search_configuration'] == old['search_configuration']
for k, v in old['control_populations'].items():
    assert all(plan['control_populations'][k][field] == v[field] for field in ('control_ids', 'groups', 'bank_role', 'subject_role'))
previous = read(ROOT / 'plans/point-frame-fixed-slots-v1-target-0.json')
assert all(ref in plan['files'] for ref in previous['files'])
for ref in plan['files']:
    verify(ref)
absent = [Path(plan['actual_dir']), Path(plan['actual_dir'] + '.observer'),
          Path(proposal['prospective_grant_path'])]
assert all(not p.exists() and not p.is_symlink() for p in absent)
now = datetime.now(timezone.utc).isoformat()
case_accept = emit(ROOT / f'fixed-slot-target-{index}-Root-prospective-acceptance-v2.json', {
    'schema': 'Root-fixed-slot-case-prospective-acceptance-v1', 'issued_utc': now,
    'accepted': True, 'case_id': plan['case_id'], 'plan': row['plan'], 'closure': row['closure'],
    'proposal': row['proposal'], 'Root_batch_acceptance': pin(accept_path),
    'whole_review': accepted['whole_review'], 'metadata_issuer': pin(Path(__file__).resolve()),
    'guards_current': len(plan['files']), 'namespaces': prep['namespaces'], 'scoped_groups': prep['scoped_groups'],
    'original176_all_previous_guards_six_targets_ten_caps_and_configuration_preserved': True,
    'absent_paths': [str(p) for p in absent], 'scientific_imports_calls': 0})
barrier = emit(ROOT / f'fixed-slot-target-{index}-all-tools-idle-barrier-v2.json', {
    'schema': 'Root-fixed-slot-case-tools-idle-barrier-v1', 'issued_utc': now,
    'case_id': plan['case_id'], 'acceptance': case_accept,
    'observation': 'Root called collaboration.list_agents immediately before issuance: B/L/C completed/tools idle. No current Root command session, server, browser/network or scientific operation is running. All earlier actual handles are terminal. No parallel tool work during the new once actual.',
    'scope': 'Current task tools only, not exclusive operating-system ownership.',
    'guards_rehashed': len(plan['files']), 'fresh_absence_checks': 3})
grant = {k: proposal[k] for k in ('uses', 'case_id', 'plan_sha256', 'runner_sha256', 'observer_sha256',
                                 'plan', 'protocol', 'closure', 'component_review', 'additive_bank_review')}
grant.update(schema='Root-point-frame-once-grant-v1', authorized=True, review_passed=True,
             issued_utc=now, whole_review=accepted['whole_review'], case_proposal=row['proposal'],
             Root_prospective_acceptance=case_accept, all_tools_idle_barrier=barrier,
             scope='One exact new changed-Source bounded case, one use. No original consumed-case replay, prefix rescue, stale qualification or automatic positive admission.')
final = emit(Path(proposal['prospective_grant_path']), grant)
print(json.dumps({'grant': final, 'acceptance': case_accept, 'barrier': barrier,
                  'command': proposal['prospective_command']}))
