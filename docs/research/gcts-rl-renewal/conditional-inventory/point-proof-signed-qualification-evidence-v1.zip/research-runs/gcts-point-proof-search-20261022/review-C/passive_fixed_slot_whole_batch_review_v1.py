"""C-only whole-study raw/metadata/AST audit. Never imports research modules."""
from pathlib import Path
from datetime import datetime, timezone
import ast
import difflib
import hashlib
import json

BASE = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
S = BASE / 'research-runs/gcts-point-proof-search-20261022'
R, B, C = S/'root', S/'implementation-B', S/'review-C'


def raw(p):
    p = Path(p)
    assert p.is_absolute() and p.resolve() == p and p.is_file() and not p.is_symlink()
    assert '.partial' not in p.name
    return p.read_bytes()


def pin(p):
    p = Path(p).resolve()
    body = raw(p)
    return dict(path=str(p),bytes=len(body),sha256=hashlib.sha256(body).hexdigest())


def load(p):
    return json.loads(raw(p))


def verify(ref):
    assert pin(ref['path']) == {k:ref[k] for k in ('path','bytes','sha256')}


def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode()


def metadata_assignments(tree):
    return {x.targets[0].id:x.value for x in tree.body if isinstance(x,ast.Assign)
            and len(x.targets)==1 and isinstance(x.targets[0],ast.Name)}


prep_path = R/'fixed-slot-study-preparation-v1.json'
prep = load(prep_path)
assert pin(prep_path)['bytes'] == 9126 and pin(prep_path)['sha256'] == 'f89b86d12f9cc1df6462f78f5b70cf4471c364237de7c33de8b73646797dc227'
assert prep['shared_guards']==142 and prep['namespaces']==25 and prep['scoped_populations']==11 and prep['scoped_groups']==184
assert prep['pilot_target_index']==3 and len(prep['cases'])==6
for key in ('metadata_builder','worker','worker_component_review','bank_component_review','provider_component_review','protocol'):
    verify(prep[key])
for key in ('worker_component_review','bank_component_review','provider_component_review'):
    assert load(prep[key]['path'])['review_passed'] is True
worker_path = Path(prep['worker']['path'])
worker_text = raw(worker_path).decode()
old_worker = B/'fpc_point_frame_search_worker_v3.py'
old_text = raw(old_worker).decode()
tree, old_tree = ast.parse(worker_text), ast.parse(old_text)
new_defs = {n.name:n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
old_defs = {n.name:n for n in old_tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
assert set(new_defs)==set(old_defs)
unchanged = []
for name,node in old_defs.items():
    if name!='main':
        assert ast.dump(node,include_attributes=False)==ast.dump(new_defs[name],include_attributes=False)
        assert ast.get_source_segment(old_text,node)==ast.get_source_segment(worker_text,new_defs[name])
        unchanged.append(name)
assert len(unchanged)==7
a,oa = metadata_assignments(tree),metadata_assignments(old_tree)
for name in ('CAPS','PRODUCTION_CONFIGURATION'):
    assert ast.dump(a[name],include_attributes=False)==ast.dump(oa[name],include_attributes=False)
roles = [x.value for x in a['MODULE_ROLES'].elts]
assert len(roles)==len(set(roles))==25
old_roles = [x.value for x in oa['MODULE_ROLES'].elts]
assert roles[:len(old_roles)]==old_roles and roles[-2:]==['legacy_provider','fixed_slot_bank']
vectors = {k.value:[x.value for x in v.elts] for k,v in zip(a['CONTROL_IDS'].keys,a['CONTROL_IDS'].values)}
old_vectors = {k.value:[x.value for x in v.elts] for k,v in zip(oa['CONTROL_IDS'].keys,oa['CONTROL_IDS'].values)}
assert len(vectors)==11 and sum(map(len,vectors.values()))==184
assert all(vectors[k]==v for k,v in old_vectors.items()) and sum(map(len,old_vectors.values()))==176
assert vectors['fixed-free-slot8']==load(S/'diagnostics-L/fixed-free-slot-independent-controls-API-v1.json')['control_ids']
forward = raw(B/'point-frame-worker-v3-v4.patch').decode()
inverse = raw(B/'point-frame-worker-v4-v3.inverse.patch').decode()
assert forward==''.join(difflib.unified_diff(old_text.splitlines(keepends=True),worker_text.splitlines(keepends=True),fromfile=old_worker.name,tofile=worker_path.name))
assert inverse==''.join(difflib.unified_diff(worker_text.splitlines(keepends=True),old_text.splitlines(keepends=True),fromfile=worker_path.name,tofile=old_worker.name))
api_path = B/'point-frame-worker-API-v4.json'
offer_path = B/'point-frame-worker-dependency-offer-v4.json'
api,offer = load(api_path),load(offer_path)
modules = {x['role']:x['rawpin'] for x in offer['runtime_roles']}
assert len(modules)==len(offer['runtime_roles'])==25 and set(modules)==set(roles)
assert len({x['path'] for x in modules.values()})==25
assert {x['role']:{k:x[k] for k in ('path','bytes','sha256')} for x in api['runtime_roles']}==modules
assert len(api['runtime_roles'])==25
inputs = {x['role']:x for x in offer['raw_inputs']}
assert len(inputs)==len(offer['raw_inputs'])==6
assert len({x['plan_key'] for x in inputs.values()})==6
assert len(api['raw_inputs'])==6
assert {x['role']:{k:x[k] for k in ('plan_key','rawpin')} for x in api['raw_inputs']}=={x['role']:{k:x[k] for k in ('plan_key','rawpin')} for x in offer['raw_inputs']}
populations = {x['population']:{k:x[k] for k in ('control_ids','groups','bank_role','subject_role','scope')} for x in api['scoped_populations']}
assert len(populations)==len(api['scoped_populations'])==11
assert all(x['control_ids']==vectors[k] and type(x['groups']) is int and x['groups']==len(vectors[k]) for k,x in populations.items())
custody = {x['role']:x['rawpin'] for x in offer['custody_runtime']}
assert set(custody)=={'runner','observer','python'} and len(offer['custody_runtime'])==3
for ref in list(modules.values())+list(custody.values()):
    verify(ref)
protocol = load(prep['protocol']['path'])
assert set(protocol)=={'schema','experiment','limits','module_pins','control_populations','job_recipes','metadata'}
assert protocol['schema']=='Root-FPC-point-frame-protocol-v1' and protocol['experiment']=='point-frame-fixed-slots-v1'
assert protocol['module_pins']==modules and protocol['control_populations']==populations
old_plan = load(R/'plans/point-frame-constructor-index-v3-target-0.json')
assert protocol['limits']==old_plan['limits']==api['limits']
assert all(type(x) is int for x in protocol['limits'].values()) and len(protocol['limits'])==10
assert api['search_configuration']==old_plan['search_configuration']=={'schema':'FPC-point-frame-worker-search-v1','entry':'search_dovetail','max_rounds':None}
assert modules['legacy_provider']==old_plan['module_pins']['provider']
assert modules['provider']==pin(B/'fpc_full_frame_inventory_v5.py')
assert modules['fixed_slot_bank']==pin(S/'diagnostics-L/fixed_free_slot_independent_controls_v1.py')
for role,ref in old_plan['module_pins'].items():
    if role!='provider':
        assert modules[role]==ref
for name,pop in old_plan['control_populations'].items():
    for field in ('control_ids','groups','bank_role'):
        assert populations[name][field]==pop[field]
    assert populations[name]['subject_role']==('legacy_provider' if name=='constructor-index14' else pop['subject_role'])
assert populations['fixed-free-slot8']['subject_role']=='provider'
declarations = load(inputs['six_declarations']['rawpin']['path'])
recipes = [dict(case_id='point-frame-fixed-slots-v1-target-'+str(i),target_index=i,target_id=x['id']) for i,x in enumerate(declarations['targets'])]
assert protocol['job_recipes']==recipes and len(recipes)==6
selection_path = R/'fixed-slot-prospective-pilot-selection-v1.json'
selection = load(selection_path)
assert selection['pilot_target_index']==3 and selection['pilot_target_id']==recipes[3]['target_id']=='HI-point-not-line'
assert selection['unchanged_original_literal_declaration']==declarations['targets'][3]
assert selection['limits']==protocol['limits'] and selection['search_configuration']==api['search_configuration']
assert protocol['metadata']['initial_selection']==recipes[3]
assert protocol['metadata']['current_worker']==prep['worker']
for key,pk in (('component_review','worker_component_review'),('additive_bank_review','bank_component_review'),('provider_review','provider_component_review')):
    assert protocol['metadata'][key]==prep[pk]
issuer_path = R/'issue_fixed_slot_case_grant_v1.py'
census_path = R/'census_completed_fixed_slot_case_v1.py'
assert pin(issuer_path)['bytes']==6406 and pin(issuer_path)['sha256']=='dc94fdba1fdce458c693733d995f97a2fde4d1a2d52c31121d28f9ab596b3888'
assert pin(census_path)['bytes']==1774 and pin(census_path)['sha256']=='5f6539642692a2f9d0f1f5595a8e7d2c3c17acecca213410e4ea384bb60222f5'
case_reviews,first_plan,guard_refs = [],None,None
future_paths=[]
for i,row in enumerate(prep['cases']):
    assert row['recipe']==recipes[i]
    for key in ('plan','closure','proposal'):
        verify(row[key])
    plan,closure,proposal = [load(row[k]['path']) for k in ('plan','closure','proposal')]
    assert all(plan[k]==v for k,v in recipes[i].items()) and type(plan['target_index']) is int
    assert plan['schema']=='proof-search-case-once-plan-v1' and plan['experiment']==protocol['experiment'] and plan['stage']=='evaluate'
    assert plan['required_upstream_ids']==[] and plan['limits']==protocol['limits'] and plan['search_configuration']==api['search_configuration']
    assert plan['module_pins']==modules and plan['control_populations']==populations and plan['protocol']==prep['protocol']
    assert plan['worker_path']==str(worker_path) and plan['runner_path']==custody['runner']['path'] and plan['python']==custody['python']
    assert plan['actual_dir']==str(S/'actual'/recipes[i]['case_id'])
    assert len(plan['files'])==len({x['path'] for x in plan['files']})==142
    assert [x['path'] for x in plan['files']]==sorted(x['path'] for x in plan['files'])
    if first_plan is None:
        first_plan,guard_refs=plan,plan['files']
    else:
        ignored={'case_id','target_index','target_id','actual_dir'}
        assert {k:v for k,v in plan.items() if k not in ignored}=={k:v for k,v in first_plan.items() if k not in ignored}
    assert all(x in plan['files'] for x in old_plan['files']) and len(old_plan['files'])==109
    for ref in list(modules.values())+list(custody.values())+[prep['protocol']]:
        assert ref in plan['files']
    for inp in inputs.values():
        assert plan[inp['plan_key']]==inp['rawpin'] and inp['rawpin'] in plan['files']
    for key in ('metadata_builder','worker_component_review','bank_component_review','provider_component_review'):
        assert prep[key] in plan['files']
    assert pin(issuer_path) in plan['files'] and pin(census_path) in plan['files']
    assert closure['plan']==row['plan'] and closure['protocol']==prep['protocol'] and closure['files']==plan['files']
    assert closure['namespace_count']==25 and closure['scoped_population_count']==11 and closure['scoped_group_count']==184
    assert closure['module_roles_in_execution_order']==roles and closure['six_recipes']==recipes
    assert proposal['schema']=='Root-point-frame-once-grant-proposal-v1'
    assert proposal['authorized'] is False and proposal['review_passed'] is False and type(proposal['uses']) is int and proposal['uses']==1
    assert proposal['case_id']==plan['case_id'] and proposal['plan']==row['plan'] and proposal['closure']==row['closure'] and proposal['protocol']==prep['protocol']
    assert proposal['plan_sha256']==row['plan']['sha256'] and proposal['runner_sha256']==custody['runner']['sha256'] and proposal['observer_sha256']==custody['observer']['sha256']
    assert proposal['component_review']==prep['worker_component_review'] and proposal['additive_bank_review']==prep['bank_component_review']
    assert proposal['prospective_grant_path']==str(R/'grants'/(plan['case_id']+'.json'))
    assert proposal['prospective_command']==[custody['python']['path'],'-I','-S','-B',custody['observer']['path'],row['plan']['path'],proposal['prospective_grant_path']]
    paths=[Path(plan['actual_dir']),Path(plan['actual_dir']+'.observer'),Path(proposal['prospective_grant_path'])]
    assert all(not p.exists() and not p.is_symlink() for p in paths)
    future_paths.extend(map(str,paths))
    case_reviews.append(dict(recipe=recipes[i],plan=row['plan'],closure=row['closure'],proposal=row['proposal'],review_passed=True,
        checks=[dict(id='exact-Source-protocol-recipe-phase-caps-and-inputs',passed=True),dict(id='false-proposal-exact-CLI-and-fresh-output-absence',passed=True)]))
before={ref['path']:pin(ref['path']) for ref in guard_refs}
assert all(before[ref['path']]==ref for ref in guard_refs)
assert not any('/actual/' in x['path'] or '.partial' in x['path'] or x['path'].endswith('.bin') for x in guard_refs)
assert len({x['path'] for x in guard_refs})==142
assert sum(not Path(x['path']).is_relative_to(BASE) for x in guard_refs)==1
all_new_metadata={row[key]['path'] for row in prep['cases'] for key in ('plan','closure','proposal')}
assert not (all_new_metadata & set(before))
assert str(prep_path) not in before
for p in [worker_path,Path(prep['metadata_builder']['path']),issuer_path,census_path,Path(custody['runner']['path']),Path(custody['observer']['path'])]:
    unused=compile(raw(p),str(p),'exec')
    del unused
assert all(pin(Path(path))==ref for path,ref in before.items())
assert all(not Path(p).exists() and not Path(p).is_symlink() for p in future_paths)
checks = [
    ('current-complete-Source-components-and-delta','Full current worker4 read, exact provider5/bank8 C reviews and L caller review bound; only main changes, seven engineering definitions raw/AST exact. Exact raw forward/inverse patches, caps/config AST and current public inputs/versions verified. No Source import/call.'),
    ('all142-current-acyclic-guards-and-original109','All 142 unique canonical ordinary guards rehashed before/after; all previous109 retained. Current plans/closures/proposals/preparation are outside their own guards; protocol pins only earlier immutable inputs/reviews, so future whole review can bind externally without a cycle. One Python binary is the only external runtime. No actual/proof/partial input or recursive eligibility.'),
    ('25roles-raw6-exact-phase-and-version-binding','25 distinct current runtime roles, exact Source/API/offer pins, six unique explicit role/plan_key inputs, correct cold import order and current/legacy versions. New plan_key is collision-free; no hidden runtime namespace, Native executable or result uptake.'),
    ('ten-bankcalls-eleven-scopes184-and-subjects','Original176 ordered ID/bank bindings preserved plus fixed8. Explicit16 wraps13+3, so operative ten bank calls yield11 scopes/184. Original126 and explicit16 subjects unchanged; tiny/controller/current8 use5 where declared; constructor14 uses exact4. No 184-tests-of5 assertion.'),
    ('independent-query-freeze-production-and-dual-byte-proof-gates','Original six declarations/authority and mode/signature/profile/fullGamma/expanded goal remain guarded; charged independent in-job codec/decode association precedes all controls/search. Only fresh immutable query and generic max_rounds=None flow into unchanged fair controller; no target route/frame/length/lemma or old proof. Original same-byte subject/reference acceptance precedes immutable paired point reduction, which remains nonadmitted representation.'),
    ('whole-cost-firstfault-seven-null-and-complete-output','Same ten original caps; hashes/imports/codec/fixtures/all184/search/check/copies/rehash/serialization/output included. Sticky first Root fault wins; all seven positive payloads suppressed on any captured failure, and raw files/stage labels have no prefix authority. Complete bounded output only, no truncation/fit claim. Native0 is explicitly vacuous.'),
    ('unchanged-runner-observer-ABI-and-resource-gates','Exact inherited runner98c553/observer24804 read at active grant/CONSUMED/header/final custody points and bound by current hashes. Same process-group/root-start/CLI/header ABI, EOF/log/thread/waited-child checks, strict whole post-output/observer memory and physical limits. Invalid header yields null qualified peak, not zero.225s fallback distinct from210s positive observer custody.'),
    ('original-six-recipes-pilot3-and-no-authority-transfer','All six exact original IDs/order and common settings remain in six new prospective cases; initial pilot3 HI-point-not-line selected before implementation, no supplied intermediate fact. All18 actual/observer/finalgrant paths absent. Consumed predecessors remain untouched and unadopted; false proposals grant no scientific execution.'),
    ('issuer-and-census-metadata-only-boundaries','Full issuer/census Source read and unused-compiled only. Issuer rehashes exact preparation/whole/component/case/proposal/142guards, verifies prior scopes/caps and outputs absent, then creates separate Root acceptance/barrier/true uses1 grant. Its idle observation text is a Root procedural duty, not an automated OS/agent check. Census hashes owned post-terminal files and treats partials opaquely; it does not qualify results.'),
    ('reject-only-proposals-and-exact-future-command','Each proposal is technically rejected by generic runner/observer booleans and binds exact per-case plan/protocol/closure/current component pins, runner/observer hashes and isolated Python observer argv. Final issuance changes no operative plan/source/limit/recipe; must bind this whole review and fresh Root acceptance/barrier. Generic custodian enforces only its documented subset; additional provenance remains Root workflow.'),
]
receipt=dict(schema='GCTS-C-fixed-slot-six-target-whole-prospective-Source-plan-proposal-review-v1',
    issued_utc=datetime.now(timezone.utc).isoformat(),review_complete=True,review_passed=True,
    scope='Whole prospective Source/phase/metadata review of exact six cases and reject-only proposals. Initial Root pilot3 only; no actual, qualification, grant or publication issued by C.',
    preparation=pin(prep_path),protocol=prep['protocol'],worker=prep['worker'],
    worker_component_review=prep['worker_component_review'],provider_component_review=prep['provider_component_review'],bank_component_review=prep['bank_component_review'],
    worker_API=pin(api_path),dependency_offer=pin(offer_path),metadata_builder=prep['metadata_builder'],
    grant_issuer=pin(issuer_path),postterminal_census_Source=pin(census_path),
    custody_runtime=custody,pilot_selection=pin(selection_path),review_program=pin(Path(__file__)),
    checks=[dict(id=k,passed=True,finding=v) for k,v in checks],cases=case_reviews,
    counts=dict(shared_guards=142,retained_previous_guards=109,runtime_roles=25,raw_JSON_inputs=6,
        fresh_bank_calls=10,scoped_populations=11,scoped_groups=184,prospective_cases=6,false_proposals=6,absent_future_paths=18),
    limits=protocol['limits'],search_configuration=api['search_configuration'],
    guarded_row_digest_sha256=hashlib.sha256(canonical(guard_refs)).hexdigest(),guarded_raw_bytes=sum(x['bytes'] for x in guard_refs),
    guard_inventory_authority='Exact shared plan.files list bound by each of the six reviewed raw plan pins; no duplicate expanded manifest is fabricated.',
    method='Complete manual current worker/main/API/manual/offer/protocol descriptive fields and builder/issuer/census read; exact inherited custody/component reviews reused by equality. Pure stdlib complete saved-JSON/raw hashing and Source AST/unusedcompile checks only. No ast.literal_eval or semantic input generation by C.',
    documentation_limits=[
        'Worker API entry prose still names worker_v3.py; current API Source pin, worker4 CLI, exact plan.worker_path and observer argv bind current4. No old worker is operative.',
        'Inherited API namespaced_identity/manual count phrases say nine calls/ten populations or eight-bank work. Operative ten calls/eleven scopes/184 are exact and Root explicitly accepted this interpretation.',
        'Provider5 inherited raw-tuple comment and author AST serialization limits remain exactly scoped in its separate C Source review. No new algorithm/counter authority follows from these notes.'],
    limitations=[
        'Source/manual/static reasoning is not runtime/fit or all-profile proof. All groups in this fresh study remain unrun until a distinct Root grant; current actual review and Root disposition remain future.',
        'No OS exclusivity/adversarial sandbox/realtime guarantee or controller-wide allocation/candidate census. No proof, learned marking/RL/GCTS advantage or fixed finite Wang palette claim.',
        'Root must genuinely observe fresh all-tools-idle state before calling its issuer; issuer writes the supplied procedural claim and does not query agents/processes. C performed no liveness probe.'],
    failures=[],concrete_blockers=[],scientific_imports_calls=0,ast_literal_evaluation=False,
    query_AST_fixture_proof_or_expected_semantic_set_generation=0,actual_or_partial_bodies_parsed=0,
    Root_or_Publisher_mutations=False,Root_admission_issued=False,execution_or_publication_authority=False,tools_idle_on_return=True)
out=C/'typed-fixed-slot-six-target-complete-whole-prospective-Source-plan-proposal-review-v1.json'
with out.open('xb') as f:
    f.write((json.dumps(receipt,indent=2)+'\n').encode())
print(json.dumps(dict(receipt=pin(out),program=pin(Path(__file__)),counts=receipt['counts']),indent=2))
