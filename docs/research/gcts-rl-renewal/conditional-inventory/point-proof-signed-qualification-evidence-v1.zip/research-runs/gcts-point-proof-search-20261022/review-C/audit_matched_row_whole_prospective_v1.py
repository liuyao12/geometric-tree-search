"""C passive metadata/raw/AST audit. Never imports or calls research modules."""
from pathlib import Path
import ast
import hashlib
import json

N = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022')
R, B, C = N / 'root', N / 'implementation-B', N / 'review-C'

def read(path):
    path = Path(path)
    assert '.partial' not in path.name
    return json.loads(path.read_bytes())

def pin(path):
    path = Path(path)
    assert path.is_absolute() and path.resolve() == path and not path.is_symlink() and path.is_file()
    assert '.partial' not in path.name
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

def verify(ref):
    assert set(ref) == {'path', 'bytes', 'sha256'}
    assert type(ref['bytes']) is int and ref['bytes'] >= 0
    assert pin(ref['path']) == ref, ref['path']

def dump(node):
    class TupleList(ast.NodeTransformer):
        def visit_Tuple(self, node):
            return ast.List(elts=[self.visit(x) for x in node.elts], ctx=ast.Load())
    return ast.dump(TupleList().visit(node), include_attributes=False)

def metadata_equal(node, value):
    # Native AST comparison only: no literal_eval or experimental Source execution.
    return dump(node) == dump(ast.parse(repr(value), mode='eval').body)

def module_tree(path):
    raw = Path(path).read_bytes()
    tree = ast.parse(raw, filename=str(path))
    compile(raw, str(path), 'exec')  # unused code object; never executed
    return raw, tree

def assignments(tree):
    return {n.targets[0].id: n.value for n in tree.body
            if isinstance(n, ast.Assign) and len(n.targets) == 1 and isinstance(n.targets[0], ast.Name)}

prep_path = R / 'matched-row-study-preparation-v1.json'
prep = read(prep_path)
assert pin(prep_path) == dict(path=str(prep_path), bytes=16482,
    sha256='0ef7551a030701605559938d0bf32b0fd6f6e4d1c2ed05cb4d4d34c51dc5663b')
assert prep['schema'] == 'Root-matched-row-twelve-recipe-preparation-v1'
assert prep['shared_guards'] == 225 and prep['namespaces'] == 28
assert prep['scoped_populations'] == 12 and prep['scoped_groups'] == 192
assert prep['pilot_target_index'] == 3 and len(prep['cases']) == 12
for key in ('metadata_builder', 'worker', 'protocol', 'worker_component_review', 'bank_component_review',
            'csp_component_review', 'point_component_review'):
    verify(prep[key])
for key in ('worker_component_review', 'bank_component_review', 'csp_component_review', 'point_component_review'):
    assert read(prep[key]['path'])['review_passed'] is True
protocol = read(prep['protocol']['path'])
api = read(B / 'point-frame-worker-API-v7.json')
offer = read(B / 'point-frame-worker-dependency-offer-v7.json')
old = read(R / 'plans/point-frame-fixed-slots-v2-target-0.json')
selection = read(R / 'matched-row-prospective-selection-v1.json')
first = read(prep['cases'][0]['plan']['path'])
raw, tree = module_tree(prep['worker']['path'])
const = assignments(tree)
assert metadata_equal(const['EXPERIMENT'], 'matched-row-csp-point-v1')
assert metadata_equal(const['PROTOCOL_SCHEMA'], protocol['schema'])
assert metadata_equal(const['CAPS'], first['limits'])
assert metadata_equal(const['PRODUCTION_CONFIGURATION'], first['search_configuration'])
module_roles = [x['role'] for x in api['runtime_roles']]
# API registry order need not be import order. Source MODULE_ROLES is operative.
source_roles_node = const['MODULE_ROLES']
assert isinstance(source_roles_node, ast.Tuple)
source_roles = [x.value for x in source_roles_node.elts]
assert len(source_roles) == len(set(source_roles)) == 28
modules = {x['role']: {k: x[k] for k in ('path', 'bytes', 'sha256')} for x in api['runtime_roles']}
assert len(module_roles) == len(set(module_roles)) == 28 and set(module_roles) == set(source_roles)
assert modules == first['module_pins'] == protocol['module_pins']
assert modules == {x['role']: x['rawpin'] for x in offer['runtime_roles']}
fixed = {k.value: v for k, v in zip(const['FIXED_PINS'].keys, const['FIXED_PINS'].values)}
fixed['controller_bank'], fixed['conclusion_index_bank'] = const['CONTROLLER_BANK_PIN'], const['CONCLUSION_BANK_PIN']
assert set(fixed) == set(modules)
for role, ref in modules.items():
    verify(ref)
    assert metadata_equal(fixed[role], [ref['bytes'], ref['sha256']]), role
assert all(modules[k] == v for k, v in old['module_pins'].items())
assert len(old['module_pins']) == 25
populations = {x['population']: {k: x[k] for k in ('control_ids', 'groups', 'bank_role', 'subject_role', 'scope')}
               for x in api['scoped_populations']}
assert populations == first['control_populations'] == protocol['control_populations']
assert metadata_equal(const['CONTROL_IDS'], {k: v['control_ids'] for k, v in populations.items()})
assert len(populations) == 12 and sum(x['groups'] for x in populations.values()) == 192
assert all(type(x['groups']) is int and x['groups'] == len(x['control_ids'])
           and len(set(x['control_ids'])) == len(x['control_ids']) for x in populations.values())
assert sum(x['groups'] for x in old['control_populations'].values()) == 184
assert all(populations[k] == v for k, v in old['control_populations'].items())
assert populations['constructor-index14']['subject_role'] == 'legacy_provider'
assert modules['controller'] == old['module_pins']['controller']
assert modules['legacy_provider'] == old['module_pins']['legacy_provider']
assert first['limits'] == protocol['limits'] == old['limits'] == api['limits'] == selection['limits']
assert len(first['limits']) == 10 and all(type(x) is int for x in first['limits'].values())
assert first['search_configuration'] == old['search_configuration'] == api['search_configuration'] == selection['search_configuration']
assert first['search_configuration']['max_rounds'] is None

files = first['files']
assert len(files) == 225 and files == sorted(files, key=lambda x: x['path'])
by_path = {x['path']: x for x in files}
assert len(by_path) == 225 and len(old['files']) == 176
assert all(by_path.get(x['path']) == x for x in old['files'])
for ref in files:
    verify(ref)
    assert '/actual/' not in ref['path'] and not ref['path'].endswith('.bin')
for ref in [prep['worker'], prep['protocol'], prep['metadata_builder'],
            prep['worker_component_review'], prep['bank_component_review'],
            prep['csp_component_review'], prep['point_component_review']]:
    assert by_path[ref['path']] == ref
for ref in list(modules.values()) + [x['rawpin'] for x in offer['custody_runtime']] + offer['semantic_guards']:
    verify(ref)
    assert by_path[ref['path']] == ref
raw_inputs = offer['raw_inputs']
assert len(raw_inputs) == 7 and len({x['role'] for x in raw_inputs}) == 7
assert len({x['plan_key'] for x in raw_inputs}) == 7
for item in raw_inputs:
    verify(item['rawpin'])
    assert by_path[item['rawpin']['path']] == item['rawpin']
    assert first[item['plan_key']] == item['rawpin']
    if item['plan_key'] in old:
        assert first[item['plan_key']] == old[item['plan_key']]
# Explicit current handoff members: no recursive citation eligibility.
handoffs = [B / 'point-frame-worker-Source-handoff-v7.json', B / 'full-frame-provider-Source-handoff-v6.json',
            N / 'diagnostics-L/fixed-free-slot-independent-controls-handoff-v2.json',
            B / 'row-CSP-controller-Source-handoff-v2.json',
            N / 'diagnostics-L/matched-row-controller-independent-controls-handoff-v2.json',
            R / 'point-controller-diagnostics-Source-handoff-v2.json']
for path in handoffs:
    assert by_path[str(path)] == pin(path)
    doc = read(path)
    members = doc['artifacts'] if path.name == 'fixed-free-slot-independent-controls-handoff-v2.json' else doc['files']
    for ref in members:
        verify(ref)
        assert by_path[ref['path']] == ref

decl = read(first['declarations']['path'])
targets = decl['targets']
assert len(targets) == 6
recipes = [dict(case_id='matched-row-csp-point-v1-' + arm + '-target-' + str(i), arm=arm,
                target_index=i, target_id=spec['id']) for i, spec in enumerate(targets) for arm in ('C0', 'G0')]
assert recipes == protocol['job_recipes'] == selection['prospective_generic_recipes']
assert protocol['metadata']['initial_selection'] == recipes[6:8]
assert selection['pilot_target_index'] == 3 and selection['pilot_target_id'] == targets[3]['id'] == 'HI-point-not-line'
assert selection['unchanged_original_literal_declaration'] == targets[3]
assert protocol['metadata']['six_statuses'] == [dict(x, status='NOT_RUN') for x in recipes]
assert protocol['metadata']['current_worker'] == prep['worker']
for mkey, pkey in [('component_review','worker_component_review'),('additive_bank_review','bank_component_review'),
                  ('csp_component_review','csp_component_review'),('point_component_review','point_component_review')]:
    assert protocol['metadata'][mkey] == prep[pkey]

custody = {x['role']: x['rawpin'] for x in offer['custody_runtime']}
assert set(custody) == {'python','runner','observer'}
assert first['python'] == custody['python'] == old['python']
assert first['runner_path'] == custody['runner']['path'] == old['runner_path']
expected_plan_changes = {'case_id','arm','target_index','target_id','experiment','actual_dir','worker_path','protocol',
                         'files','module_pins','control_populations','matched_controller_fixtures'}
assert {k for k in set(first) | set(old) if first.get(k) != old.get(k)} <= expected_plan_changes
per_case = []
absence_paths = []
for i, row in enumerate(prep['cases']):
    assert row['recipe'] == recipes[i]
    for key in ('plan','closure','proposal'):
        verify(row[key])
    plan, closure, proposal = [read(row[k]['path']) for k in ('plan','closure','proposal')]
    recipe = recipes[i]
    target_index, arm = recipe['target_index'], recipe['arm']
    expected_plan = dict(first, **recipe, actual_dir=str(N/'actual'/recipe['case_id']))
    assert plan == expected_plan
    assert plan['schema'] == 'proof-search-case-once-plan-v1' and plan['stage'] == 'evaluate'
    assert plan['required_upstream_ids'] == []
    assert Path(row['plan']['path']) == R/'plans'/(recipe['case_id']+'.json')
    assert plan['worker_path'] == prep['worker']['path']
    assert closure['schema'] == 'Root-matched-row-closed-Source-v1'
    assert closure['plan'] == row['plan'] and closure['protocol'] == prep['protocol']
    assert closure['files'] == files and closure['module_roles_in_execution_order'] == source_roles
    assert closure['namespace_count'] == 28 and closure['scoped_group_count'] == 192
    assert closure['scoped_population_count'] == 12 and closure['twelve_recipes'] == recipes
    assert closure['scientific_imports_calls'] == closure['query_proof_encoding'] == closure['actuals_created'] == 0
    assert str(Path(row['plan']['path'])) not in by_path
    assert row['closure']['path'] not in by_path and row['proposal']['path'] not in by_path
    assert proposal['schema'] == 'Root-point-frame-once-grant-proposal-v1'
    assert proposal['authorized'] is False and proposal['review_passed'] is False
    assert type(proposal['uses']) is int and proposal['uses'] == 1
    assert proposal['case_id'] == recipe['case_id'] and proposal['plan_sha256'] == row['plan']['sha256']
    assert proposal['plan'] == row['plan'] and proposal['closure'] == row['closure']
    assert proposal['protocol'] == plan['protocol'] == prep['protocol']
    assert proposal['component_review'] == prep['worker_component_review']
    assert proposal['additive_bank_review'] == prep['bank_component_review']
    assert proposal['runner_sha256'] == custody['runner']['sha256']
    assert proposal['observer_sha256'] == custody['observer']['sha256']
    grant = R/'grants'/(recipe['case_id']+'.json')
    assert proposal['prospective_grant_path'] == str(grant)
    assert proposal['prospective_command'] == [custody['python']['path'],'-I','-S','-B',custody['observer']['path'],row['plan']['path'],str(grant)]
    paths = [Path(plan['actual_dir']), Path(plan['actual_dir']+'.observer'), grant]
    for path in paths:
        assert not path.exists() and not path.is_symlink(), str(path)
    absence_paths.extend(str(p) for p in paths)
    assert not (Path(plan['actual_dir'])/'CONSUMED.json').exists()
    per_case.append(dict(recipe=recipe, plan=row['plan'], closure=row['closure'], proposal=row['proposal'],
                         exact_invariant_plan=True, exact_closure=True, reject_only_proposal=True,
                         expected_isolated_CLI=True, three_future_paths_absent=True))
assert len(set(absence_paths)) == 36

# Verify old helper bodies and exact v6->v7 carrier successor structurally.
oldraw, oldtree = module_tree(B/'fpc_point_frame_search_worker_v5.py')
olddefs = {x.name:x for x in oldtree.body if isinstance(x,(ast.FunctionDef,ast.ClassDef))}
defs = {x.name:x for x in tree.body if isinstance(x,(ast.FunctionDef,ast.ClassDef))}
helpers = ['RootBudget','raw_pin','pin_fields','byte_identity','serialize','write_body','load_exact']
assert all(ast.dump(defs[k],include_attributes=False)==ast.dump(olddefs[k],include_attributes=False) for k in helpers)
v6 = (B/'fpc_point_frame_search_worker_v6.py').read_bytes()
reversed_raw = raw.replace(b"FPC-full-frame-point-worker-v7", b"FPC-full-frame-point-worker-v6")
reversed_raw = reversed_raw.replace(b"(39011, 'c9ec1b7a54d18b6d04056cb38039434bf287711cf6f430d38c14a0a97988d59a')", b"(38942, 'bd5adb783474eba00ee486698e5445fd0bf3da367f31a3f0f1321998fa88d5e8')")
reversed_raw = reversed_raw.replace(b"                and modules['csp_controller'].IMPLEMENTATION_REVISION == 'FPC-ROW-CSP-CONTROLLER-implementation-v2'\n", b'')
reversed_raw = reversed_raw.replace(b'fpc_point_frame_search_worker_v7.py PLAN', b'fpc_point_frame_search_worker_v6.py PLAN')
assert reversed_raw == v6
for path in [R/'prepare_matched_row_study_metadata_v2.py', R/'issue_matched_row_case_grant_v1.py',
             R/'census_completed_matched_row_case_v1.py']:
    module_tree(path)
    assert by_path[str(path)] == pin(path)
assert prep['metadata_builder'] == pin(R/'prepare_matched_row_study_metadata_v2.py')

out = dict(schema='C-passive-matched-row-whole-metadata-audit-v1', all_checks_passed=True,
    preparation=pin(prep_path), protocol=prep['protocol'], worker=prep['worker'],
    component_reviews={k:prep[k] for k in ('worker_component_review','bank_component_review','csp_component_review','point_component_review')},
    guards_current=len(files), old_guards_retained=len(old['files']), modules_current=len(modules),
    old_module_pins_retained=len(old['module_pins']), raw_inputs=7, scoped_populations=12, groups=192,
    original_population_objects_retained=184, metadata_cases=per_case, future_paths_absent=absence_paths,
    source_import_order=source_roles, original_ten_caps=first['limits'], production_configuration=first['search_configuration'],
    independent_current_handoff_members_guarded=True, plan_closure_proposal_runtime_acyclic=True,
    seven_old_helper_definitions_exact=True, worker7_inverse_recovers_worker6=True,
    source_ast_parse_unused_compile_only=True, source_or_semantic_code_executed=False,
    scientific_imports_calls=0, actuals_or_grants_created=0, query_certificate_encoding=0,
    tools_idle_on_return=True)
outpath=C/'matched-row-whole-prospective-passive-audit-v1.json'
with outpath.open('x') as stream:
    json.dump(out,stream,indent=2,allow_nan=False);stream.write('\n')
print(json.dumps(dict(audit_output=pin(outpath), **{k:out[k] for k in ('all_checks_passed','guards_current','old_guards_retained','modules_current','groups')})))
