"""Complete raw metadata/AST/unused-compile audit; never executes bank code."""
from pathlib import Path
import ast
import hashlib
import json

BASE = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
S = BASE / 'research-runs/gcts-point-proof-search-20261022'
L, C = S / 'diagnostics-L', S / 'review-C'


def pin(p):
    p = Path(p).resolve()
    assert p.is_file() and not p.is_symlink()
    b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())


def refs(value):
    if isinstance(value, dict):
        if {'path','bytes','sha256'} <= value.keys():
            yield {k:value[k] for k in ('path','bytes','sha256')}
        for child in value.values():
            yield from refs(child)
    elif isinstance(value, list):
        for child in value:
            yield from refs(child)


offer_path = L / 'fixed-free-slot-independent-controls-handoff-v1.json'
offer = json.loads(offer_path.read_bytes())
documents = [offer_path] + [Path(x['path']) for x in offer['artifacts'] if x['path'].endswith('.json')]
verified = {}
for p in documents:
    for ref in refs(json.loads(p.read_bytes())):
        assert pin(ref['path']) == ref
        verified[ref['path']] = ref
source = L / 'fixed_free_slot_independent_controls_v1.py'
raw = source.read_bytes()
assert (len(raw), hashlib.sha256(raw).hexdigest()) == (27942,'56257d580e562c484287d2177ee56607ddf77a75236354c69a4d8602d9112af8')
tree = ast.parse(raw)
assert len(raw.decode().splitlines()) == 522
imports = [alias.name for node in tree.body if isinstance(node,ast.Import) for alias in node.names]
assert imports == ['hashlib','json','math']
assert not any(isinstance(node,ast.ImportFrom) for node in ast.walk(tree))
assignments = {node.targets[0].id:node.value for node in tree.body if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name)}
assert isinstance(assignments['CONTROL_IDS'],ast.Tuple)
ids = [node.value for node in assignments['CONTROL_IDS'].elts]
assert len(ids)==len(set(ids))==8 and ids==offer['control_ids']
entry = next(node for node in tree.body if isinstance(node,ast.FunctionDef) and node.name=='run_fixed_free_slot_controls')
assert [x.arg for x in entry.args.args]==['provider']
assert [x.arg for x in entry.args.kwonlyargs]==['baseline_provider','fixtures','encoder','codec','modules','check']
assert not entry.args.defaults and entry.args.kw_defaults == [None]*6
fixtures_path = L / 'fixed-free-output-independent-equation-declarations-v1.json'
fixtures = json.loads(fixtures_path.read_bytes())
canonical = json.dumps(fixtures,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
canonical_sha = hashlib.sha256(canonical.encode()).hexdigest()
assert canonical_sha == assignments['FIXTURE_SHA256'].value == '68d2397c1a563ced18a9bc7b57054215a05bbb6e306a2522e94a478ccdc44a82'
assert len(fixtures['fixtures'])==26
unused = compile(raw,str(source),'exec')
del unused
audit = dict(schema='GCTS-C-fixed-free-bank8-Source-static-audit-v1',all_checks_passed=True,
    Source=pin(source),handoff=pin(offer_path),program=pin(Path(__file__)),source_lines=522,
    imports=imports,entry_signature_exact=True,control_ids=ids,groups=8,
    literal_declaration_records=26,fixture_canonical_sha256=canonical_sha,
    verified_named_raw_pins=[verified[k] for k in sorted(verified)],named_pin_count=len(verified),
    AST_parse=True,unused_compile_object_discarded=True,bank_or_subject_Source_executed=False,
    ast_literal_evaluation=False,scientific_imports_calls=0,
    semantic_expected_sets_or_query_fixture_proof_generation=False,Root_or_Publisher_mutations=False)
out = C / 'fixed-free-bank8-Source-static-audit-v1.json'
with out.open('xb') as f:
    f.write((json.dumps(audit,indent=2)+'\n').encode())
print(json.dumps(dict(audit=pin(out),program=pin(Path(__file__)),named_pins=len(verified),groups=8),indent=2))
