"""Complete current negative packet: stdlib raw/saved JSON/Source AST only."""
import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

S=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022')
R,C=S/'root',S/'review-C';CASE='point-frame-fixed-slots-v2-target-3'
A,O=S/'actual'/CASE,S/'actual'/(CASE+'.observer')
def pin(p):
    p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def read(p):
    assert '.partial' not in str(p)
    return json.loads(Path(p).read_bytes())
def verify(row):
    got=pin(row['path']);assert all(got[k]==row[k] for k in ('path','bytes','sha256')),row['path'];return got
def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True).encode()
checks=[]
def passed(key,evidence):checks.append({'id':key,'passed':True,'evidence':evidence})

planpath=R/'plans'/(CASE+'.json');p=read(planpath)
wholepath=C/'typed-fixed-slot-six-target-complete-whole-prospective-Source-plan-proposal-review-v2.json';whole=read(wholepath)
assert pin(planpath)['sha256']=='9e653fd338f453173bb6a84f286c59c00ce77dacbd9fa721f662bd2ff67c5a93'
assert p['case_id']==CASE and p['target_index']==3 and p['target_id']=='HI-point-not-line'
assert whole['review_passed'] is True and len(p['files'])==len({x['path'] for x in p['files']})==176
pins=[verify(x) for x in sorted(p['files'],key=lambda x:x['path'])]
assert p['limits']==whole['limits'] and p['search_configuration']==whole['search_configuration']
assert len(p['module_pins'])==25 and len(p['control_populations'])==11
assert sum(x['groups'] for x in p['control_populations'].values())==184
assert p['required_upstream_ids']==[]
passed('current-plan-Source-176-guards-and-inherited-scopes',
 'All176 unique plan.files raw guards rehashed current, current exact whole2/Source6/bank2/worker5/custody joins retained.25 roles/raw6/10bankcalls/11scopes184 and same six declarations/ten caps/configuration. Unchanged full Source findings reused by raw identity, not re-audited or executed.')

censuspath=R/'fixed-slot-target-3-first-terminal-raw-census-v2.json';census=read(censuspath)
assert census['case_id']==CASE and census['exec_session_id']==95792 and census['exec_exit_code']==2
assert len(census['files'])==12 and all(x['partial_opaque'] is False for x in census['files'])
rows=[verify(x) for x in census['files']]
physical=sorted(str(x) for d in (A,O) for x in d.iterdir())
assert physical==sorted(x['path'] for x in rows) and sum(x['bytes'] for x in rows)==22117
assert all(Path(x).is_file() and not Path(x).is_symlink() and '.partial' not in x for x in physical)
assert not (A/'result.json').exists() and not (A/'candidate-certificate.bin').exists()
passed('complete-current-owned-raw-census',
 'Exactly12 complete ordinary owned files/22,117bytes match full census lengths/SHA256 before and after review; actual9/observer3, zero partials, no result/certificate. No unrelated directory or process inventory.')

grantpath=R/'grants'/(CASE+'.json');g=read(grantpath)
for k in ('plan','protocol','closure','component_review','additive_bank_review','whole_review','case_proposal','Root_prospective_acceptance','all_tools_idle_barrier'):verify(g[k])
assert g['schema']=='Root-point-frame-once-grant-v1' and g['case_id']==CASE
assert g['authorized'] is g['review_passed'] is True and type(g['uses']) is int and g['uses']==1
assert g['plan']==pin(planpath) and g['whole_review']==pin(wholepath) and g['plan_sha256']==pin(planpath)['sha256']
assert g['protocol']==p['protocol'] and g['runner_sha256']=='98c55321bb87a8c04b2c6d56b357aba9c3a8f5fc98660474ae3ac1c9d00b0aca'
assert g['observer_sha256']=='24804c7d4558d8df511942d9e6b2e4d8d2cfd88ce7df6f5b5f775f87d0c20ca9'
cl=read(g['closure']['path']);assert cl['plan']==pin(planpath) and cl['protocol']==p['protocol'] and cl['files']==p['files']
proposal=read(g['case_proposal']['path'])
assert proposal['authorized'] is proposal['review_passed'] is False and proposal['plan']==pin(planpath)
assert proposal['closure']==g['closure'] and proposal['component_review']==g['component_review'] and proposal['additive_bank_review']==g['additive_bank_review']
ac=read(g['Root_prospective_acceptance']['path']);barrier=read(g['all_tools_idle_barrier']['path'])
verify(ac['Root_batch_acceptance']);ba=read(ac['Root_batch_acceptance']['path'])
assert ac['accepted'] is True and ac['plan']==pin(planpath) and ac['closure']==g['closure'] and ac['proposal']==g['case_proposal']
assert ac['whole_review']==ba['whole_review']==pin(wholepath) and ba['accepted_prospective_metadata'] is True
assert ba['preparation']==whole['preparation'] and ba['worker_component_review']==g['component_review'] and ba['bank_component_review']==g['additive_bank_review']
assert barrier['case_id']==CASE and barrier['acceptance']==g['Root_prospective_acceptance'] and barrier['guards_rehashed']==176
cons=read(A/'CONSUMED.json');owned=read(A/'owned-child.json')
assert cons['case_id']==CASE and cons['plan_sha256']==pin(planpath)['sha256'] and cons['grant_sha256']==pin(grantpath)['sha256']
assert type(cons['uses']) is int and cons['uses']==1
assert owned['case_id']==CASE and owned['plan_sha256']==pin(planpath)['sha256'] and owned['parent_pid']==73611 and owned['child_pid']==owned['child_pgid']==73612
passed('fresh-exact-grant-consumption-Root-chain',
 'Distinct true uses1 grant/CONSUMED exact plan+grant hashes match current reviewed case/protocol/closure/false proposal/C+L component and whole2 reviews, Root batch/case acceptance and fresh barrier. Owned parent73611/child-group73612 bound. Source issuer provenance is metadata-only; fresh idle claim remains Root procedural observation, generic runtime enforces documented subset only.')

f,h,t,o=[read(x) for x in (A/'failure.json',A/'worker-header.json',A/'terminal.json',O/'observer.json')]
nulls=['qualification_result','input_freeze','search_result','subject_receipt','reference_receipt','point_receipt','scientific_result']
assert all(f[k] is None for k in nulls) and f['qualification_complete'] is False
assert f['status']==h['status']=='FAILED_CASE_NOT_ADMITTED' and f['first_Root_fault'] is h['first_Root_fault'] is True
assert f['error']['type']=='RootBudget' and f['error']['message']=='absolute whole-work deadline'
assert f['old_qualification_reused'] is t['old_qualification_reused'] is False
assert f['source_unchanged'] is h['source_unchanged'] is t['sources_unchanged'] is True
assert f['callbacks']==h['callbacks']==191940340 and f['callbacks']<p['limits']['root_callbacks']
assert f['elapsed_seconds']==160.0778901670128 and f['elapsed_seconds']>=p['limits']['work_seconds']==160
assert h['result']==pin(A/'failure.json') and t['header']==h and t['result'] is None and t['header_valid'] is False
assert f['guard_compilations']==f['work_snapshots']==[]
stages=f['stages'];imports=[x for x in stages if x['name'].startswith('IMPORT ')]
tree=ast.parse(Path(p['worker_path']).read_text())
roles=next(n.value for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(k,ast.Name) and k.id=='MODULE_ROLES' for k in n.targets))
assert [x['name'][7:] for x in imports]==[x.value for x in roles.elts]
assert len(imports)==25 and all(x['status']=='COMPLETED' for x in imports)
controls=[x for x in stages if x['name'].startswith('CONTROLS ')]
expected=['baseline56','obligation47','intro_integration1','regression2','point20','explicit-point16','tiny-full-provider10','full-frame-controller10','constructor-index14','fixed-free-slot8']
assert [x['name'] for x in controls]==['CONTROLS '+x for x in expected] and all(x['status']=='COMPLETED' for x in controls)
assert stages[-1]=={'began':19.80883675001678,'name':'SEARCH fresh full-FPC point-frame dovetail','status':'STARTED'}
assert f['worker_version']=='FPC-full-frame-point-worker-v5'
for role,ref in p['module_pins'].items():
    tr=ast.parse(Path(ref['path']).read_text())
    v=[n.value.value for n in tr.body if isinstance(n,ast.Assign) and any(isinstance(k,ast.Name) and k.id=='VERSION' for k in n.targets) and isinstance(n.value,ast.Constant)]
    assert v==[f['component_versions'][role]],role
for name in ('tiny-full-provider10','full-frame-controller10','fixed-free-slot8'):assert f['control_subject_bindings'][name]['provider']==p['module_pins']['provider']
assert f['control_subject_bindings']['constructor-index14']['provider']==p['module_pins']['legacy_provider']
assert f['control_subject_bindings']['fixed-free-slot8']['baseline_provider']==p['module_pins']['legacy_provider']
passed('deadline-whole-failure-no-qualified-bank-prefix',
 'Literal first RootBudget absolute whole-work deadline in SEARCH, sticky first_Root_faulttrue;25 imports/freeze/10 COMPLETED bank wrappers before search STARTED19.80883675001678. All7 positive payloads null/qualificationfalse; no saved184-row qualification result, candidate or proof. Completed wrappers and raw query freeze are diagnostic only, zero qualified groups. Exact25 component versions/scoped current6-vslegacy4 bindings match guarded Sources.')

freeze=read(A/'target-input-freeze.json');declarations=read(p['declarations']['path']);decl=declarations['targets'][3]
assert freeze['literal_declaration']==decl and freeze['target_index']==3 and freeze['search_started'] is False
assert freeze['codec_Source']==p['module_pins']['codec'] and freeze['declaration']==p['declarations']
q,cr=freeze['decoded_query'],freeze['codec_receipt']
assert q['goal']==cr['expanded_goal']==decl['goal_tree'] and q['Gamma']==cr['hypotheses']==decl['hypotheses']==[]
assert q['function_arities']==cr['function_arities']==decl['function_arities']==[]
assert q['predicate_arities']==cr['predicate_arities']==decl['predicate_arities']==[1,1,2]
assert q['theory_profile']==cr['profile_id']==decl['profile_id']==2 and q['claim_mode']==cr['mode']==decl['mode']==0
assert q['version']==cr['query_version']==1 and q['EOF']==cr['EOF']==27
assert cr['complete'] is True and cr['declaration_id']==decl['id']==p['target_id']
assert cr['declaration_canonical_sha256']==hashlib.sha256(canonical(decl)).hexdigest()
assert freeze['immutable_query']==pin(A/'target-query.bin') and cr['query_identity']=={k:freeze['immutable_query'][k] for k in ('bytes','sha256')}
passed('fresh-saved-target-association-without-codec-replay',
 'Complete physical freeze equals original target3 literal declaration/full saved codec and decoded fields/profile2/mode0/signature/emptyGamma/goal/EOF27, raw27-byte query identity and Source associations. The physical freeze search_startedfalse is its pre-search snapshot; later ledger starts SEARCH. No query was encoded/decoded or validator called by C, and this raw input has no whole-admitted prefix.')

assert t['process_exit_code']==o['parent_exit_code']==2 and t['final_custody_gate_passed'] is t['threads_terminal'] is True
assert t['conservative_combined_peak_bytes'] is o['conservative_whole_peak_bytes'] is o['final_conservative_whole_peak_bytes'] is None
assert o['resource_candidate_accepted'] is o['resource_candidate_before_receipt'] is False
assert t['errors']==o['errors']==[] and t['reason'] is o['reason'] is o['fallback_trigger_seconds'] is None
assert read(O/'stdout.bin')==t
stdout=read(A/'stdout.bin');assert stdout['case_id']==CASE and stdout['status']==f['status'] and stdout['callbacks']==f['callbacks']
for payload,directory in [(t,A),(o,O)]:
    for stream in ('stdout','stderr'):
        log=payload['logs'][stream];assert log['eof'] is True and log['overflow'] is False
        assert log['bytes']==log['stored']==(directory/(stream+'.bin')).stat().st_size
assert o['owned_child']==owned and o['partial_files_parsed'] is False
assert f['native_requests_started']==f['native_peak_bytes']==h['native_peak_bytes']==0 and f['native_queries']==[]
assert f['native_transport']=={'all_reaped':True,'closed':True,'native_exit_code':0,'native_high_water_bytes':0,'scope':'VACUOUS_NO_NATIVE_SUBPROCESS','subprocesses_started':0}
assert h['native_closed_and_reaped'] is True
assert o['elapsed_seconds']==160.30486008399748 and o['final_observer_gate_seconds']==160.30526562497835
assert o['elapsed_seconds']<p['limits']['custody_seconds'] and sum(x['bytes'] for x in rows)<p['limits']['physical_bytes']
passed('terminal-EOF-source-resource-nullpeak-and-direct-costs',
 'Exit2, complete failure/header/terminal association, EOF logs/no overflow/threads terminal and source stable; no observer/custody error/fallback. Native0 explicitly vacuous. Failed header correctly rejects resource candidate and leaves all qualified whole/combined peaks null; diagnostic RSS is not a positive whole bound or memory diagnosis. Direct observer160.30486008399748/finalgate160.30526562497835/toolsummary160.3055588339921 are separately labeled.')

ownedpath=R/'fixed-slot-v2-owned-process-terminal-observation-v1.json';ob=read(ownedpath)
assert pin(ownedpath)['sha256']=='bb732ea8be0f3047f1cba4723acd7912a349a21d306dd35c82460f54e9293445'
assert ob['authoritative_exec_session']==95792 and ob['exec_exit_code']==2 and ob['case_id']==CASE
assert ob['zero_signal_owned_checks']==[{'kind':'parent_pid','id':73611,'outcome':'ABSENT_AT_PROBE'},{'kind':'child_pgid','id':73612,'outcome':'ABSENT_AT_PROBE'}]
source=Path(p['worker_path']).read_text()
assert "elif time.monotonic() - began >= CAPS['work_seconds']:" in source and "fault = RootBudget('absolute whole-work deadline')" in source
assert "state['first_fault'] = fault" in source
assert 'classification' in f['error']['traceback'] and 'RootBudget: absolute whole-work deadline' in f['error']['traceback']
passed('bounded-deadline-diagnosis-ownership-and-claim-limits',
 'Worker callback Source tests whole160-second deadline and latches exact first fault; saved error and elapsed support deadline classification. Interrupt stack is only a location in controller classification, not causal allocation/bottleneck/profile or eliminated search count. Root momentary exact-parent73611/group73612 absence observed; C performs no probe. No nonprovability/exhaustion, speedup, fit, learned-GCTS/RL claim or consumed-v1/v2 retry.')

priornegative=C/'typed-fixed-slot-v1-target-3-complete-negative-actual-review-v1.json'
assert read(priornegative)['negative_classification_supported'] is True and read(priornegative)['review_passed'] is False
priorroot=ba['prior_negative'];verify(priorroot)
passed('preserved-carrier-negative-and-separate-current-disposition',
 'Prior fixed-slots-v1 target3 Step.action carrier failure/C negative/Root negative remain immutable and distinct. Current v2 reaches SEARCH but is whole deadline-negative; no old input/control/result/qualification uptake and no bank prefix salvage. Other5 new plans stay future/unexecuted. C reviews evidence only; separate Root negative disposition and later package claims review remain external.')
for ref in pins+rows:verify(ref)
receipt={'schema':'GCTS-C-point-frame-whole-actual-review-v1','issued_utc':datetime.now(timezone.utc).isoformat(),
 'review_complete':True,'negative_classification_supported':True,'negative_review_checks_passed':True,
 'review_passed':False,'resource_admitted':False,'scientific_qualified':False,'stage_complete':False,
 'gate_semantics':'Four false whole-positive gates; all8 passive complete negative-review checks passed. No C Root disposition or passing control prefix.',
 'case_id':CASE,'target_index':3,'target_id':p['target_id'],'stage':'evaluate','status':f['status'],
 'plan':pin(planpath),'protocol':p['protocol'],'closure':g['closure'],'grant':pin(grantpath),'case_proposal':g['case_proposal'],
 'Root_acceptance':g['Root_prospective_acceptance'],'Root_batch_acceptance':ac['Root_batch_acceptance'],'Root_idle_barrier':g['all_tools_idle_barrier'],
 'whole_prospective_batch_review':pin(wholepath),'worker_component_review':g['component_review'],'provider_component_review':whole['provider_component_review'],'bank_component_review':g['additive_bank_review'],
 'failure':pin(A/'failure.json'),'result':None,'header':pin(A/'worker-header.json'),'terminal':pin(A/'terminal.json'),'observer':pin(O/'observer.json'),
 'raw_census':pin(censuspath),'Root_owned_terminal_observation':pin(ownedpath),'complete_actual_file_census':rows,'input_pins':pins,
 'review_program':pin(__file__),'checks':checks,'failures':[],'observed_failure':{'type':f['error']['type'],'message':f['error']['message'],'first_Root_fault':True,'traceback_raw_body':pin(A/'failure.json')},
 'costs':{'observer_elapsed_seconds':o['elapsed_seconds'],'final_observer_gate_seconds':o['final_observer_gate_seconds'],'observer_tool_summary_seconds':160.3055588339921,
 'worker_elapsed_seconds':f['elapsed_seconds'],'worker_header_seconds':h['seconds'],'worker_stdout_seconds':stdout['seconds'],'search_stage_started_worker_seconds':stages[-1]['began'],
 'custodian_outer_seconds':t['outer_seconds'],'final_custody_gate_seconds':t['final_custody_gate_seconds'],'callbacks':f['callbacks'],
 'worker_python_peak_bytes':f['python_peak_bytes'],'worker_after_output_peak_bytes':h['python_peak_after_output_bytes'],'reaped_child_peak_bytes':t['child_usage']['ru_maxrss'],
 'custodian_peak_bytes':t['parent_usage']['ru_maxrss'],'observer_peak_bytes':o['final_observer_peak_bytes'],'qualified_whole_peak_bytes':None,'qualified_combined_peak_bytes':None,'physical_bytes':22117},
 'preserved_null_positive_fields':nulls,'qualification_complete':False,'qualified_control_groups':0,'diagnostic_completed_bank_wrappers':10,
 'observed_stage_ledger':stages,'input_freeze_diagnostic_only':pin(A/'target-input-freeze.json'),'prior_C_negative':pin(priornegative),'prior_Root_negative':priorroot,
 'limitations':['No saved bank-row receipt qualifies a prefix after this whole fault. Completed wrappers are not184 admitted controls.',
 'No local candidate/domain/family/round counts or practical performance attribution inferred from interrupt stack. Deadline failure gives no theorem nonprovability or exhausted finite-frame conclusion.',
 'Unavailable qualified whole peak remains null; individual RSS/elapsed samples are diagnostic, no whole-positive resource certificate. Root zero-signal observations are momentary exact-owned scope only.'],
 'partial_files_parsed':0,'scientific_imports_calls':0,'subject_helpers_or_fixtures_replayed':0,'queries_certificates_or_semantic_expectations_generated':0,
 'process_probes':0,'Root_admission_issued':False,'execution_or_publication_authority':False,'tools_idle_on_return':True}
out=C/'typed-fixed-slot-v2-target-3-complete-negative-actual-review-v1.json'
with out.open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps({'receipt':pin(out),'checks':len(checks),'guards':len(pins),'files':len(rows)}))
