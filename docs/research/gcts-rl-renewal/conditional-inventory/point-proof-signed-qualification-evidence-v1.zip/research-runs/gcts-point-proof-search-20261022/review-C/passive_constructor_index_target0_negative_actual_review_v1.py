"""C raw/complete-saved-JSON audit only; no research imports or replay."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import stat

BASE = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
S = BASE / 'research-runs/gcts-point-proof-search-20261022'
R, C = S / 'root', S / 'review-C'
CASE = 'point-frame-constructor-index-v2-target-0'
A = S / 'actual' / CASE
O = Path(str(A) + '.observer')


def pin(path):
    p = Path(path)
    assert p.is_absolute() and p.resolve() == p and not p.is_symlink() and p.is_file()
    raw = p.read_bytes()
    return dict(path=str(p), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def load(path):
    p = Path(path)
    assert '.partial' not in p.name
    return json.loads(p.read_bytes())


def current(row):
    assert pin(row['path']) == {k: row[k] for k in ('path', 'bytes', 'sha256')}
    return Path(row['path'])


def same(a, b):
    return json.dumps(a, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False) == json.dumps(b, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False)


def finding(name, text, lines=()):
    return dict(check=name, passed=True, source_lines=list(lines), finding=text)


censuspath = R / 'constructor-index-target-0-first-terminal-raw-census-v1.json'
census = load(censuspath)
assert census['case_id'] == CASE and census['exec_session_id'] == 99899 and census['exec_exit_code'] == 2
files = []
for directory in (A, O):
    assert directory.is_dir() and directory.resolve() == directory and not directory.is_symlink()
    for p in sorted(directory.rglob('*')):
        assert not p.is_symlink() and stat.S_ISREG(p.stat().st_mode)
        files.append(dict(pin(p), partial_opaque='.partial' in p.name))
assert files == census['files']
assert len(files) == 12 and sum(x['bytes'] for x in files) == 20704
assert not any(x['partial_opaque'] for x in files)
failurepath, headerpath, terminalpath, observerpath = A/'failure.json', A/'worker-header.json', A/'terminal.json', O/'observer.json'
failure, header, terminal, observer = [load(p) for p in (failurepath, headerpath, terminalpath, observerpath)]
assert pin(failurepath)['sha256'] == 'd025279cab7aa0827c4f55ae4c5237402d57940d3e7fde97465c5596601cb2d3'
assert pin(terminalpath)['sha256'] == '4602e4f5cdaca5d92d7e82bb7d8331dfa44de5df80a1453607685fc79bac20e8'
assert pin(observerpath)['sha256'] == '4836d5fd36457524bc844f0d807d9014378c6feb0f798d5493041685314ac923'
prep_path = R/'constructor-index-study-preparation-v1.json'
prep = load(prep_path)
row = prep['cases'][0]
planpath, closurepath, proposalpath = [current(row[k]) for k in ('plan','closure','proposal')]
plan, closure, proposal = [load(p) for p in (planpath, closurepath, proposalpath)]
guards = plan['files']
assert len(guards) == len({x['path'] for x in guards}) == 99
assert guards == sorted(guards, key=lambda x:x['path'])
for x in guards:
    current(x)
assert closure['files'] == guards and closure['plan'] == row['plan']
assert plan['protocol'] == closure['protocol'] == prep['protocol']
current(plan['protocol'])
assert plan['experiment'] == 'point-frame-constructor-index-v2' and plan['case_id'] == CASE
assert plan['target_index'] == 0 and plan['target_id'] == 'PA-reflexivity'
assert len(plan['module_pins']) == 23 and len(plan['control_populations']) == 10
assert sum(x['groups'] for x in plan['control_populations'].values()) == 176
assert all(x in guards for x in load(R/'plans/point-frame-full-FPC-v1-target-0.json')['files'])
grantpath = R/'grants'/(CASE+'.json')
grant = load(grantpath)
assert grant['schema'] == 'Root-point-frame-once-grant-v1' and grant['authorized'] is True and grant['review_passed'] is True
assert type(grant['uses']) is int and grant['uses'] == 1
assert grant['plan_sha256'] == row['plan']['sha256'] and grant['case_id'] == CASE
assert grant['plan'] == row['plan'] and grant['closure'] == row['closure'] and grant['protocol'] == plan['protocol']
assert grant['case_proposal'] == row['proposal']
for key in ('component_review','additive_bank_review'):
    assert grant[key] == proposal[key]
    current(grant[key])
assert grant['runner_sha256'] == pin(plan['runner_path'])['sha256']
assert grant['observer_sha256'] == '24804c7d4558d8df511942d9e6b2e4d8d2cfd88ce7df6f5b5f775f87d0c20ca9'
wholepath = current(grant['whole_review'])
assert pin(wholepath)['sha256'] == 'c4151d8b37d3a492cf58624b78ae8fef8d2b893870a8f87c185b92248d514fb6'
acceptpath, barrierpath = current(grant['Root_prospective_acceptance']), current(grant['all_tools_idle_barrier'])
accept, barrier = load(acceptpath), load(barrierpath)
assert accept['accepted'] is True and accept['case_id'] == barrier['case_id'] == CASE
assert accept['plan'] == row['plan'] and accept['closure'] == row['closure'] and accept['proposal'] == row['proposal']
assert accept['whole_review'] == grant['whole_review'] and barrier['acceptance'] == pin(acceptpath)
batchacceptpath = current(accept['Root_batch_acceptance'])
batchaccept = load(batchacceptpath)
assert batchaccept['preparation'] == pin(prep_path) and batchaccept['whole_review'] == grant['whole_review']
current(accept['metadata_issuer'])
consumed, owner = load(A/'CONSUMED.json'), load(A/'owned-child.json')
assert consumed['schema'] == 'proof-search-case-consumed-v1' and consumed['case_id'] == CASE
assert consumed['plan_sha256'] == row['plan']['sha256'] and consumed['grant_sha256'] == pin(grantpath)['sha256']
assert type(consumed['uses']) is int and consumed['uses'] == 1
assert owner == observer['owned_child'] and owner['case_id'] == CASE and owner['plan_sha256'] == row['plan']['sha256']
assert owner['parent_pid'] == 55856 and owner['child_pid'] == owner['child_pgid'] == 55857
ownershippath=R/'constructor-index-v2-target0-owned-process-terminal-observation-v1.json'
ownership=load(ownershippath)
assert ownership['case_id'] == CASE
assert ownership['owned_processes'] == [dict(pid=55856,absent_at_observation=True),dict(pid=55857,absent_at_observation=True)]
assert ownership['owned_group'] == 55857 and ownership['owned_group_absent_at_observation'] is True
assert failure['schema'] == 'FPC-point-frame-whole-worker-v1' and failure['case_id'] == CASE
assert failure['worker_version'] == 'FPC-full-frame-point-worker-v2' and failure['status'] == 'FAILED_CASE_NOT_ADMITTED'
positive_keys = ('qualification_result','input_freeze','search_result','subject_receipt','reference_receipt','point_receipt','scientific_result')
assert all(failure[x] is None for x in positive_keys)
assert failure['qualification_complete'] is False and failure['first_Root_fault'] is False
assert failure['source_unchanged'] is True and failure['old_qualification_reused'] is False
assert failure['error']['type'] == 'ConclusionControlError' and failure['error']['message'] == 'ordinary fixture/evidence carrier'
assert 'line 566, in run_conclusion_index_controls' in failure['error']['traceback']
assert 'line 85, in _plain' in failure['error']['traceback']
assert failure['callbacks'] == header['callbacks'] == 13260246 and len(failure['component_versions']) == 23
stages = failure['stages']
assert len(stages) == 33 and all(x['status'] == 'COMPLETED' for x in stages[:-1])
assert stages[-1]['name'] == 'CONTROLS constructor-index14' and stages[-1]['status'] == 'STARTED'
assert not any(x['name'].startswith(('SEARCH ', 'VALIDATE ', 'REDUCE ')) for x in stages)
assert [x['name'] for x in stages[24:-1]] == ['CONTROLS '+x for x in ('baseline56','obligation47','intro_integration1','regression2','point20','explicit-point16','tiny-full-provider10','full-frame-controller10')]
assert header['result'] == pin(failurepath) and terminal['header'] == header
assert header['status'] == 'FAILED_CASE_NOT_ADMITTED' and header['first_Root_fault'] is False
assert header['source_unchanged'] is True and header['native_closed_and_reaped'] is True
assert terminal['process_exit_code'] == observer['parent_exit_code'] == 2
assert terminal['header_valid'] is False and terminal['result'] is None
assert terminal['conservative_combined_peak_bytes'] is None and observer['conservative_whole_peak_bytes'] is None
assert observer['final_conservative_whole_peak_bytes'] is None and observer['resource_candidate_accepted'] is False
assert observer['resource_candidate_before_receipt'] is False
assert terminal['errors'] == observer['errors'] == [] and terminal['reason'] is None and observer['reason'] is None
assert terminal['threads_terminal'] is True and terminal['sources_unchanged'] is True
assert terminal['final_custody_gate_passed'] is True and observer['fallback_trigger_seconds'] is None
assert observer['partial_files_parsed'] is False
for packet,directory in ((terminal,A),(observer,O)):
    for label in ('stdout','stderr'):
        log=packet['logs'][label]
        assert log['eof'] is True and log['overflow'] is False
        assert log['bytes'] == log['stored'] == pin(directory/(label+'.bin'))['bytes']
assert load(O/'stdout.bin') == terminal
assert (A/'stderr.bin').read_bytes() == (O/'stderr.bin').read_bytes() == b''
stdout = load(A/'stdout.bin')
assert stdout['case_id'] == CASE and stdout['status'] == 'FAILED_CASE_NOT_ADMITTED' and stdout['callbacks'] == failure['callbacks']
assert failure['native_requests_started'] == failure['native_peak_bytes'] == 0 and failure['native_queries'] == []
assert failure['native_transport'] == dict(all_reaped=True,closed=True,native_exit_code=0,native_high_water_bytes=0,scope='VACUOUS_NO_NATIVE_SUBPROCESS',subprocesses_started=0)
assert failure['guard_compilations'] == failure['work_snapshots'] == []
freeze = load(A/'target-input-freeze.json')
querypin = pin(A/'target-query.bin')
assert freeze['schema'] == 'FPC-point-frame-in-job-target-freeze-v1' and freeze['target_index'] == 0 and freeze['search_started'] is False
assert freeze['immutable_query'] == querypin and querypin['bytes'] == 21
assert freeze['declaration'] == plan['declarations'] and freeze['codec_Source'] == plan['module_pins']['codec']
decl = load(plan['declarations']['path'])['targets'][0]
assert same(freeze['literal_declaration'], decl)
decoded, codec = freeze['decoded_query'], freeze['codec_receipt']
assert decoded['EOF'] == codec['EOF'] == 21 and decoded['version'] == 1
assert decoded['claim_mode'] == decl['mode'] == codec['mode'] == 0
assert decoded['theory_profile'] == decl['profile_id'] == codec['profile_id'] == 1
assert decoded['function_arities'] == decl['function_arities'] == codec['function_arities']
assert decoded['predicate_arities'] == decl['predicate_arities'] == codec['predicate_arities'] == []
assert decoded['Gamma'] == decl['hypotheses'] == codec['hypotheses'] == [] and decoded['finite_axioms'] == []
assert same(decoded['goal'], decl['goal_tree']) and same(decoded['goal'], codec['expanded_goal'])
assert codec['query_identity'] == {k:querypin[k] for k in ('bytes','sha256')}
assert not (A/'result.json').exists() and not (A/'candidate-certificate.bin').exists()
pending=[]
for item in prep['cases'][1:]:
    p=load(current(item['plan']))
    grantfile=R/'grants'/(p['case_id']+'.json')
    absent=[Path(p['actual_dir']),Path(p['actual_dir']+'.observer'),grantfile]
    assert all(not x.exists() and not x.is_symlink() for x in absent)
    pending.append(dict(case_id=p['case_id'],plan=item['plan'],status='NOT_RUN',absent_paths=list(map(str,absent))))
for x in guards:
    current(x)
assert [dict(pin(Path(x['path'])),partial_opaque=False) for x in files] == files
checks=[
 finding('exact-current-once-authority-and-closed-Source', 'Current plan/protocol/closure and all99 unique sorted plan.files hashes agree with frozen whole review. The true one-use grant binds exact proposal, worker/bank/whole reviews, Root batch/case acceptance and fresh idle barrier. CONSUMED records exact current plan/grant/case/uses1. No old result/qualification input; all five sibling cases remain unexecuted/ungranted.'),
 finding('complete-physical-census-and-raw-output-joins', 'Independently enumerated only the two owned actual/observer directories:12 complete ordinary files,20704 bytes,zero partial paths. Every raw SHA/length matches Root census. Header points to complete failure, embedded terminal header and observer stdout equal saved records, bounded logs reach EOF without overflow/errors. No result.json or candidate certificate exists.'),
 finding('whole-failure-and-no-positive-prefix', 'All23 imports, independent target freeze and eight earlier control-stage wrappers are diagnostic COMPLETED; constructor-index14 is STARTED with no completed bank return. Target SEARCH/dual validation/point reduction never started. qualification_complete=false and all seven positive fields are null. No claimed176/162/14 passed result, target-query authority, proof, control prefix or discovered nonprovability can be rescued.'),
 finding('observed-final-evidence-carrier-refusal-and-Source-cause', 'Saved traceback is owned bank ConclusionControlError ordinary fixture/evidence carrier at run_conclusion_index_controls566 through _plain85. first_Root_fault=false: no RootBudget/deadline/memory classification. Source _plain accepts only None/bool/int/str/list/tuple/dict; _tiny_public retains its E1 original checker receipt, whose mandatory cost.elapsed_seconds is float. Thus a definite Source carrier incompatibility exists. The actual rejected leaf/path/value was not saved, so do not invent it or claim captured inner rows. This gap was missed by the prior preserved C Source PASS.', (75,92,330,339,566,570)),
 finding('charged-in-job-freeze-diagnostic-only', 'Saved current21-byte query and complete freezing record match exact declaration0, codec Source, profile/mode/signatures/full empty Gamma/finite axioms/goal/EOF/raw hash associations by literal saved data comparison only. No decoder/encoder was called and no query reconstructed. The complete raw input files remain unadmitted because whole-case payload is null.'),
 finding('custody-resource-failure-and-honest-cost-labels', 'Worker and authoritative exec session99899 end2; parent2/header_validfalse/resultnull, separate observer2/resourcecandidatefalse. Whole qualified peak is null at parent/observer and is preserved. Direct elapsed9.96880154099199s differs from finalgate9.969176874990808s and worker9.799741958006052s; diagnostic worker/post-output/waited-child/observer RSS samples are separate, not a qualified sum or memory diagnosis. All original cap comparisons, source stability, EOF, threads-terminal, ordinary custody and no-fallback records are retained.'),
 finding('ownership-cleanup-evidence-and-limit', 'Owned custodian55856/worker-group55857 agree across current plan/owned/observer records. Native counts0 and closed/reaped flags are explicitly vacuous. Unchanged runner waits the worker, kills its known group in finally, joins/drains logs and observer closes an abnormal known group. After authoritative terminalexit2, Root froze read-only zero-signal absence observations for exactly parent55856,child55857,group55857. This is a momentary owned-identity observation plus complete custody/EOF/threads evidence, not a global process/exclusivity claim. C performed no process probe.'),
 finding('negative-disposition-scope-and-future-boundary', 'Complete negative review supports four false whole-positive gates and a separate Root whole-negative disposition only. No search/performance/family/allocation/RL/GCTS conclusion follows. Preserve this consumed case and all prior Sources/PASS receipts as history; no rerun, partial parsing, shorter bank or prefix adoption. Any corrected new study requires separate Source/bank/worker/whole review plus fresh Root cleanup/idle/grant; other five v2 cases remain NOT_RUN.')]
result=dict(schema='GCTS-C-point-frame-whole-actual-review-v1',issued_utc=datetime.now(timezone.utc).isoformat(),
 review_complete=True,negative_classification_supported=True,negative_review_checks_passed=True,
 review_passed=False,resource_admitted=False,scientific_qualified=False,stage_complete=False,
 gate_semantics='Four false booleans denote failed whole positive qualification; all eight complete passive negative-review checks passed.',
 case_id=CASE,target_index=0,target_id=plan['target_id'],stage='evaluate',status='FAILED_CASE_NOT_ADMITTED',
 plan=row['plan'],protocol=plan['protocol'],closure=row['closure'],grant=pin(grantpath),case_proposal=row['proposal'],
 Root_acceptance=pin(acceptpath),Root_batch_acceptance=pin(batchacceptpath),Root_idle_barrier=pin(barrierpath),
 whole_prospective_batch_review=grant['whole_review'],worker_component_review=grant['component_review'],bank_component_review=grant['additive_bank_review'],
 failure=pin(failurepath),result=None,header=pin(headerpath),terminal=pin(terminalpath),observer=pin(observerpath),
 raw_census=pin(censuspath),Root_owned_terminal_observation=pin(ownershippath),complete_actual_file_census=dict(files=files,total_bytes=20704,file_count=12,partial_paths=0),
 input_pins=guards,review_program=pin(__file__),checks=checks,failures=[],
 observed_failure=dict(type=failure['error']['type'],message=failure['error']['message'],first_Root_fault=False,
    failing_stage='CONTROLS constructor-index14',stage_returned=False,search_started=False,
    exact_runtime_rejected_leaf_saved=False,Source_incompatibility='Original checker cost.elapsed_seconds float is outside bank final _plain carrier.'),
 costs=dict(whole_seconds=observer['elapsed_seconds'],qualified_whole_peak_bytes=None,
    observer_final_gate_seconds=observer['final_observer_gate_seconds'],observer_known_parent_exit_seconds=observer['known_parent_exit_seconds'],
    parent_known_worker_exit_seconds=terminal['known_exit_seconds'],parent_final_custody_gate_seconds=terminal['final_custody_gate_seconds'],
    worker_elapsed_seconds=failure['elapsed_seconds'],worker_header_seconds=header['seconds'],worker_stdout_seconds=stdout['seconds'],
    worker_python_peak_bytes=failure['python_peak_bytes'],worker_post_output_peak_bytes=header['python_peak_after_output_bytes'],
    reaped_child_peak_bytes=terminal['child_usage']['ru_maxrss'],parent_peak_bytes=terminal['parent_usage']['ru_maxrss'],
    observer_final_peak_bytes=observer['final_observer_peak_bytes'],callbacks=failure['callbacks'],physical_actual_bytes=20704,
    scope='Direct saved complete samples only; no qualified whole memory bound or search-performance comparison.'),
 preserved_null_positive_fields=list(positive_keys),qualification_complete=False,qualified_control_groups=0,
 observed_stage_ledger=stages,remaining_five=pending,partial_files_parsed=0,scientific_imports_calls=0,
 subject_helpers_or_fixtures_replayed=0,queries_certificates_or_semantic_expectations_generated=0,
 process_probes=0,Root_admission_issued=False,execution_or_publication_authority=False,tools_idle_on_return=True)
out=C/'typed-constructor-index-target-0-complete-negative-actual-review-v1.json'
with out.open('x') as stream:
    json.dump(result,stream,indent=2,ensure_ascii=True,allow_nan=False)
    stream.write('\n')
print(json.dumps(pin(out),sort_keys=True))
