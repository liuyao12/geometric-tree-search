"""C raw/Python-Source-AST/unused-compile metadata audit; no subject imports/calls."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import re

BASE = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
S = BASE / 'research-runs/gcts-point-proof-search-20261022'
B, C, L = S / 'implementation-B', S / 'review-C', S / 'diagnostics-L'


def pin(path):
    path = Path(path)
    body = path.read_bytes()
    return {'path': str(path), 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}


def load(path):
    return json.loads(Path(path).read_bytes())


def verify(ref):
    assert pin(ref['path']) == {key: ref[key] for key in ('path', 'bytes', 'sha256')}
    return Path(ref['path'])


def patch_text(body, patch):
    source, result, position = body.splitlines(keepends=True), [], 0
    lines = patch.splitlines(keepends=True)
    i = 2
    while i < len(lines):
        header = re.match(r'^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@', lines[i])
        assert header is not None
        start = int(header.group(1)) - 1
        assert start >= position
        result.extend(source[position:start])
        position = start
        i += 1
        removed, added = 0, 0
        while i < len(lines) and not lines[i].startswith('@@ '):
            line = lines[i]
            assert line[0] in ' +-'
            if line[0] in ' -':
                assert source[position] == line[1:]
                position += 1
                removed += 1
            if line[0] in ' +':
                result.append(line[1:])
                added += 1
            i += 1
        assert removed == int(header.group(2) or '1') and added == int(header.group(4) or '1')
    result.extend(source[position:])
    return ''.join(result)


handoffpath = B / 'full-frame-provider-Source-handoff-v4-r2.json'
assert pin(handoffpath)['sha256'] == 'c1788a5896f12de308da0ad5a088baf778dd059da6bd53cea29e53c92c7246d9'
handoff = load(handoffpath)
inputs = [pin(handoffpath)]
for ref in handoff['files']:
    inputs.append(pin(verify(ref)))
for key in ['original_v4_handoff_preserved', 'original_manual_preserved']:
    inputs.append(pin(verify(handoff[key])))
newpath = verify(handoff['Source'])
oldpath = B / 'fpc_full_frame_inventory_v3.py'
assert pin(oldpath)['sha256'] == '9411bc96d89670c22c8e27ccacaee41a9942563587a5f2a41bfe18aae3b54740'
assert pin(newpath)['sha256'] == '7fc9ebe143513fa86e726c78832cdbb91589fbd9e8a5d2b21eb3183a5fbf5fd2'
old, new = oldpath.read_text(), newpath.read_text()
oa, na = ast.parse(old), ast.parse(new)
compile(new, str(newpath), 'exec')  # unused only
assert not any(isinstance(node, (ast.Import, ast.ImportFrom)) for node in ast.walk(na))
old_defs = {node.name: node for node in oa.body if isinstance(node, (ast.FunctionDef, ast.ClassDef, ast.AsyncFunctionDef))}
new_defs = {node.name: node for node in na.body if isinstance(node, (ast.FunctionDef, ast.ClassDef, ast.AsyncFunctionDef))}
assert len(old_defs) == 74 and len(new_defs) == 75
assert set(new_defs) - set(old_defs) == {'_conclusion_compatible'}
same_defs, changed_defs = [], []
for name, node in old_defs.items():
    same_ast = ast.dump(node, include_attributes=False) == ast.dump(new_defs[name], include_attributes=False)
    same_raw = ast.get_source_segment(old, node) == ast.get_source_segment(new, new_defs[name])
    assert same_ast == same_raw
    (same_defs if same_ast else changed_defs).append(name)
assert changed_defs == ['_family_skip'] and len(same_defs) == 73
old_assign = {node.targets[0].id: node for node in oa.body if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name)}
new_assign = {node.targets[0].id: node for node in na.body if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name)}
assert set(new_assign) - set(old_assign) == {'_CONCLUSION_SHAPES', '_INDUCTION_CONCLUSION_SHAPE'}
assert [name for name in old_assign if ast.dump(old_assign[name], include_attributes=False) != ast.dump(new_assign[name], include_attributes=False)] == ['IMPLEMENTATION_REVISION', 'FEATURES']
forwardpath = B / 'full-frame-provider-v3-v4-conclusion-index.patch'
inversepath = B / 'full-frame-provider-v4-v3-conclusion-index.inverse.patch'
forward, inverse = forwardpath.read_text(), inversepath.read_text()
assert forward == ''.join(difflib.unified_diff(old.splitlines(keepends=True), new.splitlines(keepends=True), fromfile='fpc_full_frame_inventory_v3.py', tofile='fpc_full_frame_inventory_v4.py'))
assert inverse == ''.join(difflib.unified_diff(new.splitlines(keepends=True), old.splitlines(keepends=True), fromfile='fpc_full_frame_inventory_v4.py', tofile='fpc_full_frame_inventory_v3.py'))
assert patch_text(old, forward) == new and patch_text(new, inverse) == old
api = load(B / 'full-frame-provider-conclusion-index-API-v4.json')
inputs.append(pin(verify(api['normative_inherited_API'])))
closure = load(B / 'full-frame-provider-dependency-closure-v4.json')
for key in ['previous_dependency_offer', 'previous_full_Source_review', 'current_API_binding']:
    inputs.append(pin(verify(closure[key])))
for key in ['runtime_roles', 'semantic_guards', 'unchanged_public_layout_bindings']:
    for ref in closure[key]:
        inputs.append(pin(verify(ref)))
assert [ref['role'] for ref in closure['runtime_roles']] == ['checker', 'builders']
assert api['VERSION'] == 'FPC-POINT-FULL-FRAME-PROVIDER-v1'
assert api['IMPLEMENTATION_REVISION'] == 'FPC-POINT-FULL-FRAME-PROVIDER-implementation-v4'
manualpath = B / 'full-frame-provider-conclusion-index-manual-v4-r2.json'
oldmanualpath = B / 'full-frame-provider-conclusion-index-manual-v4.json'
correction = load(B / 'full-frame-provider-manual-v4-r2-correction-v1.json')
manual_before, manual_after = oldmanualpath.read_text(), manualpath.read_text()
fixed = manual_before
for change in correction['changes']:
    before = json.dumps(change['before_latex'])[1:-1]
    after = json.dumps(change['after_latex'])[1:-1]
    assert fixed.count(before) == 1
    fixed = fixed.replace(before, after)
assert fixed == manual_after and len(correction['changes']) == 2
back = manual_after
for change in reversed(correction['changes']):
    back = back.replace(json.dumps(change['after_latex'])[1:-1], json.dumps(change['before_latex'])[1:-1])
assert back == manual_before
manual_json = load(manualpath)
assert [row['tag'] for row in manual_json['necessary_logical_shapes']] == list(range(8))
assert manual_json['Source'] == pin(newpath) and manual_json['API'] == pin(B / 'full-frame-provider-conclusion-index-API-v4.json')
oldreviewpath = C / 'typed-full-frame-provider-dependency-rebind-complete-Source-review-v3.json'
assert pin(oldreviewpath)['sha256'] == '55c6524c944df464c5957f96016a838c9345278be0326d476efca3492c12bac7'
assert load(oldreviewpath)['review_passed'] is True
inputs.extend([pin(oldpath), pin(oldreviewpath)])
Lhandoffpath = L / 'structural-provider-index-independent-handoff-v1.json'
assert pin(Lhandoffpath)['sha256'] == '08740f6de377cfc2176a7d2f039b7da11c8eb44d767e61c04f78c473d7bb0d06'
Lhandoff = load(Lhandoffpath)
inputs.append(pin(Lhandoffpath))
for ref in Lhandoff['artifacts'] + Lhandoff['formal_source_inputs'] + Lhandoff['existing_public_contract_inputs']:
    inputs.append(pin(verify(ref)))
assert Lhandoff['population']['declarative_fixtures'] == 26 and Lhandoff['population']['executable_bank_declared'] is False and Lhandoff['population']['runtime_pass_count'] is None
Lreviewpath = L / 'typed-full-frame-provider-conclusion-index-component-Source-review-v4.json'
assert pin(Lreviewpath)['sha256'] == '0c47da910f47d439010f513e0ec1c0e7f0f94708b0298d5dfa7d46791503d650'
assert load(Lreviewpath)['review_passed'] is True
inputs.append(pin(Lreviewpath))
assert all(pin(ref['path']) == ref for ref in inputs)
out = {'schema': 'C-passive-full-frame-provider-v4-Source-audit-v1', 'all_raw_AST_inverse_documentation_checks_passed': True, 'Source': pin(newpath), 'predecessor': pin(oldpath), 'handoff': pin(handoffpath), 'inputs': list({ref['path']: ref for ref in inputs}.values()), 'old_top_definitions': 74, 'new_top_definitions': 75, 'unchanged_raw_and_AST_definitions': same_defs, 'changed_old_definitions': changed_defs, 'added_definitions': ['_conclusion_compatible'], 'changed_existing_assignments': ['IMPLEMENTATION_REVISION', 'FEATURES'], 'added_assignments': ['_CONCLUSION_SHAPES', '_INDUCTION_CONCLUSION_SHAPE'], 'exact_raw_forward_and_inverse': True, 'manual_r2_exact_two_string_forward_inverse': True, 'subject_imports': 0, 'subject_calls': 0, 'unused_compile_only': True, 'literal_eval_or_semantic_generation': False, 'runtime_qualification': False, 'program': pin(__file__)}
outpath = C / 'typed-full-frame-provider-v4-passive-Source-audit-v1.json'
with outpath.open('x') as stream:
    json.dump(out, stream, indent=2, ensure_ascii=True)
    stream.write('\n')
print(json.dumps(pin(outpath), sort_keys=True))
