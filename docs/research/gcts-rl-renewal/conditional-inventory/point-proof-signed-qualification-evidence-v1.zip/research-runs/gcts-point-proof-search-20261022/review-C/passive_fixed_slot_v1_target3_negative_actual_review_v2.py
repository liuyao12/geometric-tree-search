"""C-only passive complete saved-packet audit. No experimental imports or calls."""
import ast
import datetime
import hashlib
import json
from pathlib import Path

BASE = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
S = BASE / 'research-runs/gcts-point-proof-search-20261022'
R, C = S / 'root', S / 'review-C'
CASE = 'point-frame-fixed-slots-v1-target-3'
A, O = S / 'actual' / CASE, S / 'actual' / (CASE + '.observer')

def pin(p):
    p = Path(p)
    raw = p.read_bytes()
    return {'path': str(p), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def read(p):
    assert '.partial' not in str(p)
    return json.loads(Path(p).read_bytes())

def verify(row):
    actual = pin(row['path'])
    assert all(actual[k] == row[k] for k in ('path', 'bytes', 'sha256')), row['path']
    return actual

def canonical(obj):
    return json.dumps(obj, sort_keys=True, separators=(',', ':'), ensure_ascii=True)

checks = []
def checked(name, evidence):
    checks.append({'id': name, 'passed': True, 'evidence': evidence})

planpath = R / 'plans' / (CASE + '.json')
plan = read(planpath)
prep = read(R / 'fixed-slot-study-preparation-v1.json')
wholepath = C / 'typed-fixed-slot-six-target-complete-whole-prospective-Source-plan-proposal-review-v1.json'
whole = read(wholepath)
grantpath = R / 'grants' / (CASE + '.json')
grant = read(grantpath)
assert pin(planpath)['sha256'] == 'b51dd6a9c03eaa06f1e13d39ae3e2228d7b2c8b5080f7e8c7f45404e21fef94f'
assert plan['case_id'] == CASE and plan['target_index'] == 3 and plan['target_id'] == 'HI-point-not-line'
assert len(plan['files']) == 142 and len({x['path'] for x in plan['files']}) == 142
input_pins = [verify(x) for x in sorted(plan['files'], key=lambda x: x['path'])]
assert len(plan['module_pins']) == 25 and sum(len(x['control_ids']) for x in plan['control_populations'].values()) == 184
assert len(plan['control_populations']) == 11 and plan['limits'] == whole['limits']
assert plan['search_configuration'] == whole['search_configuration']
verify(plan['protocol'])
assert whole['review_passed'] is True and prep['shared_guards'] == 142
checked('current-original-plan-142-guards-and-scoped-subjects',
        'All 142 unique plan.files raw bodies rehashed current; 25 module roles, 11 scoped populations/184 declared groups, original target3/configuration/ten caps equal the frozen whole review. This checks custody/identity, not passing controls.')

censuspath = R / 'fixed-slot-target-3-first-terminal-raw-census-v1.json'
census = read(censuspath)
assert census['exec_session_id'] == 2744 and census['exec_exit_code'] == 2 and census['case_id'] == CASE
rows = census['files']
assert len(rows) == 12 and not any(x['partial_opaque'] for x in rows)
fullcensus = [verify(x) for x in rows]
physical = sorted(str(p) for directory in (A, O) for p in directory.iterdir())
assert physical == sorted(x['path'] for x in rows)
assert all(Path(x).is_file() and not Path(x).is_symlink() for x in physical)
assert sum(x['bytes'] for x in rows) == 21172
assert not any('.partial' in x for x in physical)
assert not (A / 'result.json').exists() and not (A / 'candidate-certificate.bin').exists()
checked('complete-owned-physical-census-no-positive-artifact',
        'Exactly 12 complete ordinary files/21,172 bytes match the Root census, lengths and SHA256; actual9 plus observer3, zero partials, no result or certificate. Only these owned directories were enumerated.')

f, h, t, o = (read(p) for p in (A/'failure.json', A/'worker-header.json', A/'terminal.json', O/'observer.json'))
consumed, owned = read(A/'CONSUMED.json'), read(A/'owned-child.json')
assert grant['schema'] == 'Root-point-frame-once-grant-v1'
assert grant['authorized'] is True and grant['review_passed'] is True and type(grant['uses']) is int and grant['uses'] == 1
assert grant['case_id'] == CASE and grant['plan'] == pin(planpath)
for k in ('plan', 'protocol', 'closure', 'component_review', 'additive_bank_review', 'whole_review', 'case_proposal', 'Root_prospective_acceptance', 'all_tools_idle_barrier'):
    verify(grant[k])
assert grant['whole_review'] == pin(wholepath) and grant['plan_sha256'] == pin(planpath)['sha256']
assert grant['runner_sha256'] == pin(plan['runner_path'])['sha256']
assert grant['observer_sha256'] == '24804c7d4558d8df511942d9e6b2e4d8d2cfd88ce7df6f5b5f775f87d0c20ca9'
assert consumed['case_id'] == CASE and type(consumed['uses']) is int and consumed['uses'] == 1
assert consumed['plan_sha256'] == pin(planpath)['sha256'] and consumed['grant_sha256'] == pin(grantpath)['sha256']
accept = read(grant['Root_prospective_acceptance']['path'])
barrier = read(grant['all_tools_idle_barrier']['path'])
batchaccept = read(accept['Root_batch_acceptance']['path'])
verify(accept['Root_batch_acceptance'])
assert accept['accepted'] is True and accept['whole_review'] == pin(wholepath)
assert accept['plan'] == pin(planpath) and accept['closure'] == grant['closure'] and accept['proposal'] == grant['case_proposal']
assert barrier['case_id'] == CASE and barrier['acceptance'] == grant['Root_prospective_acceptance'] and barrier['guards_rehashed'] == 142
assert batchaccept['accepted_prospective_metadata'] is True and batchaccept['whole_review'] == pin(wholepath)
assert owned == o['owned_child'] and owned['parent_pid'] == 70188 and owned['child_pid'] == owned['child_pgid'] == 70189
assert owned['plan_sha256'] == pin(planpath)['sha256']
checked('one-use-consumption-grant-current-Root-chain',
        'Exact true uses1 grant, consumed plan/grant hashes, current proposal/closure/Root batch and case acceptance/barrier/C Source reviews joined. Owned IDs are parent70188/child and group70189. Freshness/exclusivity is limited to Root workflow observations; generic runtime checks only its documented grant subset.')

nulls = ['qualification_result', 'input_freeze', 'search_result', 'subject_receipt', 'reference_receipt', 'point_receipt', 'scientific_result']
assert all(f[k] is None for k in nulls)
assert f['qualification_complete'] is False and f['status'] == h['status'] == 'FAILED_CASE_NOT_ADMITTED'
assert f['first_Root_fault'] is h['first_Root_fault'] is False
assert f['old_qualification_reused'] is t['old_qualification_reused'] is False
assert f['source_unchanged'] is h['source_unchanged'] is t['sources_unchanged'] is True
assert f['error']['type'] == 'TinyProviderControlError' and f['error']['message'] == 'Step action'
assert h['result'] == pin(A/'failure.json') and t['header'] == h and t['result'] is None and t['header_valid'] is False
assert f['callbacks'] == h['callbacks'] == 8923368
assert f['guard_compilations'] == f['work_snapshots'] == []
stages = f['stages']
imports = [x for x in stages if x['name'].startswith('IMPORT ')]
assert len(imports) == 25 and all(x['status'] == 'COMPLETED' for x in imports)
worker_ast = ast.parse(Path(plan['worker_path']).read_text())
role_node = next(n.value for n in worker_ast.body if isinstance(n,ast.Assign) and any(isinstance(k,ast.Name) and k.id == 'MODULE_ROLES' for k in n.targets))
assert isinstance(role_node,ast.Tuple) and all(isinstance(k,ast.Constant) and isinstance(k.value,str) for k in role_node.elts)
assert [x['name'][7:] for x in imports] == [k.value for k in role_node.elts]
assert set(x['name'][7:] for x in imports) == set(plan['module_pins'])
controls = [x for x in stages if x['name'].startswith('CONTROLS ')]
assert [(x['name'], x['status']) for x in controls] == [
 ('CONTROLS baseline56','COMPLETED'),('CONTROLS obligation47','COMPLETED'),
 ('CONTROLS intro_integration1','COMPLETED'),('CONTROLS regression2','COMPLETED'),
 ('CONTROLS point20','COMPLETED'),('CONTROLS explicit-point16','COMPLETED'),
 ('CONTROLS tiny-full-provider10','STARTED')]
assert stages[-1] == controls[-1] and not any('SEARCH' in x['name'] for x in stages)
for role, mpin in plan['module_pins'].items():
    source = Path(mpin['path']).read_text()
    tree = ast.parse(source)
    versions = [node.value.value for node in tree.body if isinstance(node, ast.Assign)
                and any(isinstance(tgt, ast.Name) and tgt.id == 'VERSION' for tgt in node.targets)
                and isinstance(node.value, ast.Constant) and isinstance(node.value.value, str)]
    assert versions == [f['component_versions'][role]], role
assert f['control_subject_bindings']['constructor-index14']['provider'] == plan['module_pins']['legacy_provider']
for label in ('tiny-full-provider10', 'full-frame-controller10', 'fixed-free-slot8'):
    assert f['control_subject_bindings'][label]['provider'] == plan['module_pins']['provider']
checked('whole-failure-all-seven-null-zero-qualified-prefix',
        'All seven positive payloads null/qualificationfalse/Rootfaultfalse. Complete25 imports and input-freeze plus six COMPLETED bank wrappers are diagnostic only; tiny10 STARTED then failed, before controller/constructor/fixed8/target search or dual/point output. Current literal component versions and scoped subjects match all25 guarded Sources. No prefix qualifies.')

freeze = read(A/'target-input-freeze.json')
decls = read(plan['declarations']['path'])
declrows = decls['targets'] if 'targets' in decls else decls['declarations']
assert freeze['literal_declaration'] == declrows[3]
assert freeze['target_index'] == 3 and freeze['search_started'] is False
q = freeze['decoded_query']; cr = freeze['codec_receipt']; decl = freeze['literal_declaration']
assert q['goal'] == cr['expanded_goal'] == decl['goal_tree']
assert q['Gamma'] == cr['hypotheses'] == decl['hypotheses'] == []
assert q['function_arities'] == cr['function_arities'] == decl['function_arities'] == []
assert q['predicate_arities'] == cr['predicate_arities'] == decl['predicate_arities'] == [1,1,2]
assert q['theory_profile'] == cr['profile_id'] == decl['profile_id'] == 2
assert q['claim_mode'] == cr['mode'] == decl['mode'] == 0
assert q['version'] == cr['query_version'] == 1 and q['EOF'] == cr['EOF'] == 27
assert freeze['immutable_query'] == pin(A/'target-query.bin')
assert cr['query_identity'] == {k: freeze['immutable_query'][k] for k in ('bytes','sha256')}
assert cr['declaration_id'] == decl['id'] == plan['target_id'] and cr['complete'] is True
assert cr['declaration_canonical_sha256'] == hashlib.sha256(canonical(decl).encode()).hexdigest()
assert freeze['codec_Source'] == plan['module_pins']['codec'] and freeze['declaration'] == plan['declarations']
checked('saved-independent-target-freeze-literal-association-only',
        'Complete physical freeze target3 equals original literal HI-point-not-line declaration; exact raw27-byte query identity, saved codec/decoded goal/signature/profile2/mode0/emptyGamma/EOF fields join. No binary decoder/codec/checker was called. The saved freeze has no admitted input or proof prefix after whole failure.')

tiny_source = Path(plan['module_pins']['tiny_bank']['path']).read_text()
provider_source = Path(plan['module_pins']['provider']['path']).read_text()
assert 'step["action"] in ("NORMALIZE", "ENUMERATE", "INTRINSIC", "ENVELOPE",' in tiny_source
assert '"POINT_CHECK", "EMIT", "EOF")' in tiny_source
assert 'return "PENDING", None, r, phase, None' in provider_source
assert 'if phase == "BIND":' in provider_source
assert 'tiny_fpc_provider_controls_v1.py\", line 218' in f['error']['traceback']
checked('exact-public-action-carrier-defect-not-search-or-memory',
        'Traceback ends at tiny bank line218 closed seven-action enum. Guarded provider5 _raw_step BIND branch returns internal phase as public action, and _advance_class/_step_record pass it through. BIND is a valid internal restriction phase but absent from public action enum. BIND attribution is Source+traceback reasoning, not a separately saved step object or replay. Prior C provider5/whole Source PASS missed this compatibility defect and remains preserved; minimal successor must normalize the public category without widening old expectations.')

assert t['process_exit_code'] == o['parent_exit_code'] == 2
assert t['final_custody_gate_passed'] is t['threads_terminal'] is True
assert t['conservative_combined_peak_bytes'] is o['conservative_whole_peak_bytes'] is o['final_conservative_whole_peak_bytes'] is None
assert o['resource_candidate_before_receipt'] is o['resource_candidate_accepted'] is False
assert t['errors'] == o['errors'] == [] and t['reason'] is o['reason'] is o['fallback_trigger_seconds'] is None
assert read(O/'stdout.bin') == t
stdout = read(A/'stdout.bin')
assert stdout['case_id'] == CASE and stdout['status'] == f['status'] and stdout['callbacks'] == f['callbacks']
for payload,directory in ((t,A),(o,O)):
    for stream in ('stdout','stderr'):
        log = payload['logs'][stream]
        assert log['eof'] is True and log['overflow'] is False
        assert log['bytes'] == log['stored'] == (directory/(stream+'.bin')).stat().st_size
assert f['native_requests_started'] == f['native_peak_bytes'] == h['native_peak_bytes'] == 0 and f['native_queries'] == []
assert f['native_transport'] == {'all_reaped':True,'closed':True,'native_exit_code':0,'native_high_water_bytes':0,'scope':'VACUOUS_NO_NATIVE_SUBPROCESS','subprocesses_started':0}
assert h['native_closed_and_reaped'] is True
assert o['elapsed_seconds'] == 6.513863375002984 and o['final_observer_gate_seconds'] == 6.5142421670025215
assert f['elapsed_seconds'] < plan['limits']['work_seconds'] and o['elapsed_seconds'] < plan['limits']['custody_seconds']
assert 21172 < plan['limits']['physical_bytes']
checked('terminal-resource-cost-EOF-native-vacuous-fail-closed',
        'Authoritative terminal exit2, complete header-failure association, closed EOF logs/thread joins and no custody/observer error or fallback. Native0 is explicitly vacuous. Failed header makes resource candidate false and qualified whole/combined peaks null; individual worker/observer/reaped RSS samples do not establish an admitted whole bound. Direct observer elapsed6.513863375002984, final gate6.5142421670025215 and tool summary6.514508499996737 are distinct; this is neither deadline nor memory/search failure.')

ownedpath = R/'fixed-slot-v1-owned-process-terminal-observation-v1.json'
owned_observation = read(ownedpath)
assert owned_observation['case_id'] == CASE and owned_observation['exec_exit_code'] == 2 and owned_observation['authoritative_exec_session'] == 2744
assert owned_observation['zero_signal_owned_checks'] == [
 {'kind':'parent_pid','id':70188,'outcome':'ABSENT_AT_PROBE'},
 {'kind':'child_pgid','id':70189,'outcome':'ABSENT_AT_PROBE'}]
checked('exact-owned-Root-terminal-observation-and-no-retry-scope',
        'Root saved momentary zero-signal observations identify exact parent70188 and child group70189 absent; authoritative exec2744 terminal2 and custody records support cleanup. C made no process probe; no unrelated-process/OS exclusivity or all-descendant census claim. This exact consumed v1 target3 remains whole negative, never rerun or prefix-salvaged; the other five original v1 plans remain separate unexecuted plans.')

for row in input_pins + fullcensus:
    verify(row)
receipt = {
 'schema':'GCTS-C-point-frame-whole-actual-review-v1',
 'issued_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'review_complete':True,'negative_classification_supported':True,'negative_review_checks_passed':True,
 'review_passed':False,'resource_admitted':False,'scientific_qualified':False,'stage_complete':False,
 'gate_semantics':'Four false whole-positive gates; all eight complete passive negative-review checks passed. No Root disposition is issued by C.',
 'case_id':CASE,'target_index':3,'target_id':plan['target_id'],'stage':'evaluate','status':f['status'],
 'plan':pin(planpath),'protocol':plan['protocol'],'closure':grant['closure'],'grant':pin(grantpath),
 'case_proposal':grant['case_proposal'],'Root_acceptance':grant['Root_prospective_acceptance'],
 'Root_batch_acceptance':accept['Root_batch_acceptance'],'Root_idle_barrier':grant['all_tools_idle_barrier'],
 'whole_prospective_batch_review':pin(wholepath),'worker_component_review':grant['component_review'],
 'provider_component_review':whole['provider_component_review'],'bank_component_review':grant['additive_bank_review'],
 'failure':pin(A/'failure.json'),'result':None,'header':pin(A/'worker-header.json'),
 'terminal':pin(A/'terminal.json'),'observer':pin(O/'observer.json'),'raw_census':pin(censuspath),
 'Root_owned_terminal_observation':pin(ownedpath),'complete_actual_file_census':fullcensus,'input_pins':input_pins,
 'review_program':pin(__file__),'checks':checks,'failures':[],
 'observed_failure':f['error'],
 'source_causal_evidence':{'tiny_bank':plan['module_pins']['tiny_bank'],'provider':plan['module_pins']['provider'],
  'lines':'tinybank218-219; provider5 _raw_step1051-1126, _step_record1290-1294, _advance_class1306-1338',
  'classification':'Public Step.action closed-enum compatibility failure before search. No semantic membership counterexample, theorem nonprovability, resource/performance or allocation inference.'},
 'costs':{'observer_elapsed_seconds':o['elapsed_seconds'],'final_observer_gate_seconds':o['final_observer_gate_seconds'],
  'observer_tool_summary_seconds':6.514508499996737,'worker_elapsed_seconds':f['elapsed_seconds'],
  'worker_header_seconds':h['seconds'],'worker_stdout_seconds':stdout['seconds'],'custodian_outer_seconds':t['outer_seconds'],
  'final_custody_gate_seconds':t['final_custody_gate_seconds'],'callbacks':f['callbacks'],
  'worker_python_peak_bytes':f['python_peak_bytes'],'worker_after_output_peak_bytes':h['python_peak_after_output_bytes'],
  'reaped_child_peak_bytes':t['child_usage']['ru_maxrss'],'custodian_peak_bytes':t['parent_usage']['ru_maxrss'],
  'observer_peak_bytes':o['final_observer_peak_bytes'],'qualified_whole_peak_bytes':None,'qualified_combined_peak_bytes':None,
  'physical_bytes':21172},
 'preserved_null_positive_fields':nulls,'qualification_complete':False,'qualified_control_groups':0,
 'observed_stage_ledger':stages,'input_freeze_diagnostic_only':pin(A/'target-input-freeze.json'),
 'source_review_correction':'Earlier immutable C provider5 and whole prospective Source PASS missed the closed Step.action enum; preserve them and this negative. No claim that Source review or diagnostic completed controls qualify the consumed whole attempt.',
 'partial_files_parsed':0,'scientific_imports_calls':0,'subject_helpers_or_fixtures_replayed':0,
 'queries_certificates_or_semantic_expectations_generated':0,'process_probes':0,'Root_admission_issued':False,
 'execution_or_publication_authority':False,'tools_idle_on_return':True}
out = C/'typed-fixed-slot-v1-target-3-complete-negative-actual-review-v1.json'
with out.open('x') as stream:
    json.dump(receipt,stream,indent=2,ensure_ascii=True); stream.write('\n')
print(json.dumps({'receipt':pin(out),'checks':len(checks),'guards':len(input_pins),'files':len(fullcensus)}))
