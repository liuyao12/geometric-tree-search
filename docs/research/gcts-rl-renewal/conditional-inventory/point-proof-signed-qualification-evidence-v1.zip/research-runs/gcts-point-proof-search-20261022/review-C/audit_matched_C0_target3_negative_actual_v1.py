"""C passive complete saved-JSON/raw-custody review; no scientific imports/calls."""
from pathlib import Path
import ast
import hashlib
import json

N=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022')
R,C=N/'root',N/'review-C'
case='matched-row-csp-point-v1-C0-target-3'
A=N/'actual'/case
O=Path(str(A)+'.observer')
def read(p):
    assert '.partial' not in Path(p).name
    return json.loads(Path(p).read_bytes())
def pin(p):
    p=Path(p);assert p.is_absolute() and p.resolve()==p and p.is_file() and not p.is_symlink()
    raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def verify(x):
    assert type(x['bytes']) is int and pin(x['path'])=={k:x[k] for k in ('path','bytes','sha256')}

prep_path=R/'matched-row-study-preparation-v1.json'
prep=read(prep_path);row=prep['cases'][6]
for k in ('plan','closure','proposal'):verify(row[k])
P,K,F=[read(row[k]['path']) for k in ('plan','closure','proposal')]
Q=read(P['protocol']['path']);verify(P['protocol'])
assert P['case_id']==case and P['arm']=='C0' and P['target_index']==3 and P['target_id']=='HI-point-not-line'
assert Q['job_recipes'][6]==row['recipe'] and Q['module_pins']==P['module_pins']
assert Q['control_populations']==P['control_populations'] and K['files']==P['files']
assert len(P['files'])==225 and len(P['module_pins'])==28 and len(P['control_populations'])==12
assert sum(x['groups'] for x in P['control_populations'].values())==192
old=read(R/'plans/point-frame-fixed-slots-v2-target-0.json')
assert len(old['files'])==176 and all(x in P['files'] for x in old['files'])
assert all(P['module_pins'][k]==v for k,v in old['module_pins'].items())
assert all(P['control_populations'][k]==v for k,v in old['control_populations'].items())
assert P['limits']==old['limits'] and P['search_configuration']==old['search_configuration']
for ref in P['files']:verify(ref)

batch_path=R/'matched-row-study-Root-whole-prospective-acceptance-v1.json'
accept_path=R/'matched-row-C0-target-3-Root-prospective-acceptance-v1.json'
barrier_path=R/'matched-row-C0-target-3-all-tools-idle-barrier-v1.json'
grant_path=R/'grants'/(case+'.json')
batch,accept,barrier,grant=[read(p) for p in (batch_path,accept_path,barrier_path,grant_path)]
assert batch['accepted_prospective_metadata'] is True and batch['preparation']==pin(prep_path)
assert batch['protocol']==P['protocol'] and batch['whole_review']['sha256']=='e7cdf43d997906999f48bf5b39ce6fe7d12b2a9be27da183de3fa69b2c245710'
for k in ('preparation','protocol','whole_review','worker_component_review','bank_component_review','csp_component_review','point_component_review','component_Source_acceptance'):verify(batch[k])
assert accept['accepted'] is True and accept['case_id']==case and accept['Root_batch_acceptance']==pin(batch_path)
assert accept['whole_review']==batch['whole_review'] and accept['plan']==row['plan'] and accept['closure']==row['closure'] and accept['proposal']==row['proposal']
assert accept['metadata_issuer']==pin(R/'issue_matched_row_case_grant_v1.py')
assert barrier['case_id']==case and barrier['acceptance']==pin(accept_path) and barrier['guards_rehashed']==225
assert grant['authorized'] is True and grant['review_passed'] is True and type(grant['uses']) is int and grant['uses']==1
for k in ('uses','case_id','plan_sha256','runner_sha256','observer_sha256','plan','protocol','closure','component_review','additive_bank_review'):
    assert grant[k]==F[k]
assert grant['whole_review']==batch['whole_review'] and grant['case_proposal']==row['proposal']
assert grant['Root_prospective_acceptance']==pin(accept_path) and grant['all_tools_idle_barrier']==pin(barrier_path)
assert grant['issued_utc']==barrier['issued_utc']==accept['issued_utc']

census_path=R/'matched-row-C0-target-3-first-terminal-raw-census-v1.json'
census=read(census_path)
assert census['case_id']==case and census['exec_session_id']==23335 and census['exec_exit_code']==2
physical=[]
for directory in (A,O):
    assert directory.is_dir() and not directory.is_symlink()
    for path in sorted(directory.rglob('*')):
        assert not path.is_symlink()
        if path.is_file():physical.append(dict(pin(path),partial_opaque='.partial' in path.name))
assert physical==census['files'] and len(physical)==12 and not any(x['partial_opaque'] for x in physical)
assert sum(x['bytes'] for x in physical)==26038
assert {Path(x['path']).name for x in physical}=={'CONSUMED.json','failure.json','owned-child.json','stderr.bin','stdout.bin','target-input-freeze.json','target-query.bin','terminal.json','worker-header.json','observer.json'}
assert not (A/'result.json').exists() and not (A/'candidate-certificate.bin').exists()
failure,header,terminal,observer,owned,consumed,freeze=[read(p) for p in (
    A/'failure.json',A/'worker-header.json',A/'terminal.json',O/'observer.json',A/'owned-child.json',A/'CONSUMED.json',A/'target-input-freeze.json')]
assert consumed==dict(schema='proof-search-case-consumed-v1',case_id=case,plan_sha256=row['plan']['sha256'],grant_sha256=pin(grant_path)['sha256'],uses=1)
assert all(x['case_id']==case for x in (failure,header,terminal,observer,owned))
assert owned==observer['owned_child'] and owned['plan_sha256']==row['plan']['sha256']
assert owned['parent_pid']==84590 and owned['child_pid']==owned['child_pgid']==84591
assert failure['status']==header['status']=='FAILED_CASE_NOT_ADMITTED'
assert failure['first_Root_fault'] is header['first_Root_fault'] is True
assert failure['error']['type']=='RootBudget' and failure['error']['message']=='absolute whole-work deadline'
assert failure['worker_version']=='FPC-full-frame-point-worker-v7'
assert failure['arm']=='C0' and failure['search_controller_role']=='csp_controller'
assert failure['search_controller_Source']==P['module_pins']['csp_controller']
assert failure['source_unchanged'] is header['source_unchanged'] is terminal['sources_unchanged'] is True
assert header['result']==pin(A/'failure.json') and terminal['header']==header
assert terminal['header_valid'] is False and terminal['result'] is None and terminal['process_exit_code']==2
assert terminal['threads_terminal'] is terminal['final_custody_gate_passed'] is True
assert terminal['errors']==observer['errors']==[] and terminal['reason'] is observer['reason'] is None
assert terminal['conservative_combined_peak_bytes'] is None
assert observer['parent_exit_code']==2 and observer['resource_candidate_accepted'] is False
assert observer['resource_candidate_before_receipt'] is False
assert observer['conservative_whole_peak_bytes'] is observer['final_conservative_whole_peak_bytes'] is None
assert observer['partial_files_parsed'] is False and observer['fallback_trigger_seconds'] is None
assert failure['qualification_complete'] is False and failure['old_qualification_reused'] is False
positive=('qualification_result','input_freeze','search_result','subject_receipt','reference_receipt','point_receipt','scientific_result')
assert all(failure[k] is None for k in positive)
assert failure['native_requests_started']==0 and failure['native_queries']==[]
assert failure['native_transport']==dict(all_reaped=True,closed=True,native_exit_code=0,native_high_water_bytes=0,scope='VACUOUS_NO_NATIVE_SUBPROCESS',subprocesses_started=0)
assert header['native_closed_and_reaped'] is True and header['native_peak_bytes']==0
for directory,record in ((A,terminal),(O,observer)):
    for stream in ('stdout','stderr'):
        log=record['logs'][stream]
        assert log['eof'] is True and log['overflow'] is False
        assert log['bytes']==log['stored']==(directory/(stream+'.bin')).stat().st_size
assert read(A/'stdout.bin')['status']=='FAILED_CASE_NOT_ADMITTED'
assert read(O/'stdout.bin')==terminal

# Saved input association only; no byte parser/codec/checker called here.
decl=read(P['declarations']['path'])['targets'][3]
assert freeze['literal_declaration']==decl and freeze['target_index']==3 and freeze['search_started'] is False
assert freeze['declaration']==P['declarations'] and freeze['codec_Source']==P['module_pins']['codec']
querypin=pin(A/'target-query.bin');identity={k:querypin[k] for k in ('bytes','sha256')}
assert freeze['immutable_query']==querypin
dq,codec=freeze['decoded_query'],freeze['codec_receipt']
assert dq['goal']==decl['goal_tree']==codec['expanded_goal']
assert dq['Gamma']==decl['hypotheses']==codec['hypotheses']==[]
assert dq['function_arities']==decl['function_arities']==codec['function_arities']
assert dq['predicate_arities']==decl['predicate_arities']==codec['predicate_arities']
assert dq['theory_profile']==decl['profile_id']==codec['profile_id']==2
assert dq['claim_mode']==decl['mode']==codec['mode']==0 and dq['version']==1
assert dq['finite_axioms']==[] and dq['EOF']==codec['EOF']==querypin['bytes']==27
assert codec['query_identity']==identity and codec['declaration_id']==decl['id'] and codec['complete'] is True

stages=failure['stages'];search=stages[-1]
assert search['name']=='SEARCH C0 fresh full-FPC matched dovetail' and search['status']=='STARTED' and 'seconds' not in search
controls=[x for x in stages if x['name'].startswith('CONTROLS ')]
assert [x['name'] for x in controls]==['CONTROLS '+x for x in ('baseline56','obligation47','intro_integration1','regression2','point20','explicit-point16','tiny-full-provider10','full-frame-controller10','constructor-index14','fixed-free-slot8','matched-controller8')]
assert len(controls)==11 and all(x['status']=='COMPLETED' for x in controls)
assert all(x['status']=='COMPLETED' for x in stages[:-1]) and len(stages)==41
assert len(failure['component_versions'])==28
assert failure['control_subject_bindings']=={
 'tiny-full-provider10':{'provider':P['module_pins']['provider']},
 'full-frame-controller10':{k:P['module_pins'][k] for k in ('controller','provider')},
 'constructor-index14':{'provider':P['module_pins']['legacy_provider']},
 'fixed-free-slot8':{'provider':P['module_pins']['provider'],'baseline_provider':P['module_pins']['legacy_provider']},
 'matched-controller8':{k:P['module_pins'][k] for k in ('matched_point_controller','csp_controller','provider')}}
diag=failure['search_diagnostic_observation'];s=diag['snapshot']
worker_tree=ast.parse(Path(P['worker_path']).read_bytes())
node=next(x.value for x in worker_tree.body if isinstance(x,ast.Assign) and isinstance(x.targets[0],ast.Name) and x.targets[0].id=='WORKER_DIAGNOSTIC_FIELDS')
fields=[x.value for x in node.elts]
assert len(s)==len(fields)==49 and set(s)==set(fields)
assert diag['available'] is diag['non_authoritative'] is True and diag['controller_call_complete_at_checkpoint'] is False
assert s['schema']=='matched-row-controller-diagnostics-v1' and s['arm']=='C0'
assert s['complete'] is False and s['snapshot_available'] is True and s['phase_in_progress'] is True
assert s['raw_member_work_supported'] is False and s['raw_member_work'] is None
for k,v in s.items():
    if k in ('complete','snapshot_available','phase_in_progress','raw_member_work_supported'):assert type(v) is bool
    elif k not in ('schema','arm','active_phase'):assert v is None or (type(v) is int and v>=0)
assert s['frames_completed']==s['frames_exhausted']+s['frames_fuel_limited']==330
assert s['active_frame_ordinal']==331==(26*25)//2+6
assert s['active_frame_round']==26 and s['active_frame_pair_index']==6
assert s['active_frame_limit']==2**(26-6) and s['active_atomic_steps_committed']<=s['active_frame_limit']
assert s['active_frame_rows']==3 and s['active_frame_syntax_nodes']==7
assert s['active_phase']=='CLASSIFY_ADVANCE'
assert s['active_live_cursors']<=s['active_highwater_live_cursors']
assert s['active_trail_entries']<=s['active_highwater_trail_entries']
assert s['active_outstanding_offers']<=s['active_offers'] and s['active_reject_offers']==0
assert s['active_provider_advances_committed']<=s['active_provider_calls_committed']
assert s['completed_provider_advances_committed']<=s['completed_provider_calls_committed']
assert failure['callbacks']==header['callbacks']==229420343<P['limits']['root_callbacks']
assert failure['elapsed_seconds']>=P['limits']['work_seconds']
assert observer['elapsed_seconds']==160.25059800001327
assert terminal['final_custody_gate_seconds']<P['limits']['custody_seconds']
assert observer['final_observer_gate_seconds']<P['limits']['observer_fallback_seconds']
assert max(x['bytes'] for x in physical)<P['limits']['result_bytes']
assert sum(x['bytes'] for x in physical)<P['limits']['physical_bytes']
assert failure['python_peak_bytes']==header['python_peak_after_output_bytes']==61849600
assert terminal['child_usage']['ru_maxrss']==71352320
assert all(v<P['limits']['memory_bytes'] for v in (failure['python_peak_bytes'],terminal['child_usage']['ru_maxrss'],terminal['parent_usage']['ru_maxrss'],observer['final_observer_peak_bytes']))
for path in (N/'actual/matched-row-csp-point-v1-G0-target-3',N/'actual/matched-row-csp-point-v1-G0-target-3.observer',R/'grants/matched-row-csp-point-v1-G0-target-3.json'):
    assert not path.exists() and not path.is_symlink()

out=dict(schema='C-passive-matched-C0-target3-complete-negative-audit-v1',all_checks_passed=True,
 plan=row['plan'],closure=row['closure'],proposal=row['proposal'],protocol=P['protocol'],preparation=pin(prep_path),
 Root_batch_acceptance=pin(batch_path),Root_case_acceptance=pin(accept_path),Root_barrier=pin(barrier_path),grant=pin(grant_path),
 census=pin(census_path),raw_files=physical,guards_current=225,original_guards_retained=176,scoped_groups=192,
 seven_positive_fields_null=list(positive),stage_labels=stages,snapshot=s,
 direct_observer_elapsed_seconds=observer['elapsed_seconds'],final_observer_gate_seconds=observer['final_observer_gate_seconds'],
 qualified_whole_peak_bytes=None,resource_candidate_accepted=False,negative_review_supported=True,positive_review_passed=False,
 functional_control_failure_recorded=False,owned_process_record=owned,
 liveness_scope='Authoritative terminal tool exit2 plus waited/reaped child/parent, EOF and joined collector records. No independent current signal0 process probe performed by C; no global exclusivity claim.',
 G0_target3_ungranted_and_absent=True,scientific_imports_calls=0,query_or_certificate_generation=0,tools_idle_on_return=True)
path=C/'matched-C0-target3-complete-negative-passive-audit-v1.json'
with path.open('x') as stream:json.dump(out,stream,indent=2,allow_nan=False);stream.write('\n')
print(json.dumps(dict(output=pin(path),all_checks_passed=True,files=len(physical),bytes=sum(x['bytes'] for x in physical))))
