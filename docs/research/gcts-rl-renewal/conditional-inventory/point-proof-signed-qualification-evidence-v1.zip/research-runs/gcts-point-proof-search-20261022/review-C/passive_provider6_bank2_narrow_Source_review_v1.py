"""Metadata/raw/AST-only narrow successor audit; no subject code is executed."""
import ast
import datetime
import hashlib
import json
from pathlib import Path

S = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022')
B,L,C = S/'implementation-B',S/'diagnostics-L',S/'review-C'
def pin(p):
    p=Path(p); raw=p.read_bytes()
    return {'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def read(p): return json.loads(Path(p).read_bytes())
def verify(row):
    got=pin(row['path'])
    assert all(got[k]==row[k] for k in ('path','bytes','sha256')),row['path']
    return got
def definitions(raw):
    tree=ast.parse(raw)
    return {n.name:n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef,ast.AsyncFunctionDef))}
def dump(node): return ast.dump(node,include_attributes=False)
def body(raw,node): return '\n'.join(raw.splitlines()[node.lineno-1:node.end_lineno])

ph=B/'full-frame-provider-Source-handoff-v6.json'; bh=L/'fixed-free-slot-independent-controls-handoff-v2.json'
pd,bd=read(ph),read(bh)
assert pin(ph)['sha256']=='f31de58b146b2b02a0f3bded1493ac185060b1f7b65d57674a733734e4b9cef9'
assert pin(bh)['sha256']=='7845f70b889a492c75474fb87063217521944e67d8eacfc2eede845b63aeeb6f'
inputs={}
def keep(row):
    checked=verify(row);inputs[checked['path']]=checked;return checked
for row in pd['files']+bd['artifacts']:
    keep(row)
for row in [pd['preserved_predecessor_offer'],bd['predecessor'],bd['predecessor_independent_C_Source_review'],bd['declaration_C_review'],bd['current_provider'],bd['current_provider_API'],bd['current_provider_handoff']]:
    keep(row)
ps=B/'fpc_full_frame_inventory_v6.py';po=B/'fpc_full_frame_inventory_v5.py'
bs=L/'fixed_free_slot_independent_controls_v2.py';bo=L/'fixed_free_slot_independent_controls_v1.py'
pnew,pold,bnew,bold=(p.read_text() for p in (ps,po,bs,bo))
assert pnew.count('IMPLEMENTATION_REVISION = "FPC-POINT-FULL-FRAME-PROVIDER-implementation-v6"')==1
assert pnew.count('return "PENDING", None, r, "NORMALIZE", None')==1
assert pnew.replace('IMPLEMENTATION_REVISION = "FPC-POINT-FULL-FRAME-PROVIDER-implementation-v6"','IMPLEMENTATION_REVISION = "FPC-POINT-FULL-FRAME-PROVIDER-implementation-v5"').replace('return "PENDING", None, r, "NORMALIZE", None','return "PENDING", None, r, phase, None')==pold
assert bnew.replace('VERSION = "L-fixed-free-slot-independent-controls-v2"','VERSION = "L-fixed-free-slot-independent-controls-v1"').replace('provider.IMPLEMENTATION_REVISION == "FPC-POINT-FULL-FRAME-PROVIDER-implementation-v6"','provider.IMPLEMENTATION_REVISION == "FPC-POINT-FULL-FRAME-PROVIDER-implementation-v5"')==bold
pdefs,oldpdefs,bdefs,oldbdefs=(definitions(x) for x in (pnew,pold,bnew,bold))
assert pdefs.keys()==oldpdefs.keys() and bdefs.keys()==oldbdefs.keys()
pchanges=[k for k in pdefs if dump(pdefs[k])!=dump(oldpdefs[k])]
bchanges=[k for k in bdefs if dump(bdefs[k])!=dump(oldbdefs[k])]
assert pchanges==['_raw_step'] and bchanges==['run_fixed_free_slot_controls']
assert len(pdefs)==77 and len(bdefs)==22
assert all(body(pnew,pdefs[k])==body(pold,oldpdefs[k]) for k in pdefs if k not in pchanges)
assert all(body(bnew,bdefs[k])==body(bold,oldbdefs[k]) for k in bdefs if k not in bchanges)
compile(pnew,str(ps),'exec');compile(bnew,str(bs),'exec')

papi=read(B/'full-frame-provider-fixed-free-slot-API-v6.json')
pc=read(B/'full-frame-provider-dependency-closure-v6.json')
bapi=read(L/'fixed-free-slot-independent-controls-API-v2.json')
bc=read(L/'fixed-free-slot-independent-controls-role-closure-v2.json')
for row in pc['runtime_roles']+pc['semantic_guards']+pc['unchanged_public_layout_bindings']+bc['runtime_namespaces']+bc['phase_JSON_inputs']:
    keep(row)
for row in [pc['previous_dependency_offer'],pc['previous_full_Source_review'],pc['current_API_binding'],papi['normative_inherited_API'],papi['closed_enum_audit']['normative'],papi['closed_enum_audit']['original_API'],papi['closed_enum_audit']['enforcement']]:keep(row)
priorp=C/'typed-full-frame-provider-fixed-free-complete-Source-review-v5.json'
priorb=C/'typed-fixed-free-slot-independent-bank-complete-Source-review-v1.json'
negative=C/'typed-fixed-slot-v1-target-3-complete-negative-actual-review-v1.json'
assert read(priorp)['review_passed'] is read(priorb)['review_passed'] is True
assert read(negative)['negative_classification_supported'] is True and read(negative)['review_passed'] is False
keep(pin(priorp));keep(pin(priorb));keep(pin(negative));keep(pin(po));keep(pin(bo));keep(pin(ph));keep(pin(bh))
assert pc['raw_inputs']==[]
assert papi['Source']==pin(ps) and bapi['Source']==pin(bs) and bd['current_provider']==pin(ps)
assert bd['control_ids']==read(L/'fixed-free-slot-independent-controls-handoff-v1.json')['control_ids']==bapi['control_ids']
assert len(bd['control_ids'])==8 and bapi['RETURN_SCHEMA']=='independent-fixed-free-slot-controls-v1'
assert papi['public_Step_action_exact']==['NORMALIZE','ENUMERATE','INTRINSIC','ENVELOPE','POINT_CHECK','EMIT','EOF']
tiny=Path(papi['closed_enum_audit']['enforcement']['path']).read_text()
assert 'step["action"] in ("NORMALIZE", "ENUMERATE", "INTRINSIC", "ENVELOPE",' in tiny
assert '"POINT_CHECK", "EMIT", "EOF")' in tiny
assert 'if phase == "BIND":' in pnew and 'r.update(eof=True, phase="EOF")' in body(pnew,pdefs['_raw_step'])
assert 'r["phase"]' in pnew and 'BIND' in bnew
provider_binding = next(x for x in bc['runtime_namespaces'] if x['role']=='provider')
legacy_binding = next(x for x in bc['runtime_namespaces'] if x['role']=='baseline_provider')
assert provider_binding['sha256']==pin(ps)['sha256'] and legacy_binding['sha256']=='7fc9ebe143513fa86e726c78832cdbb91589fbd9e8a5d2b21eb3183a5fbf5fd2'
assert bapi['arguments']['fixtures']['rawpin']==bc['phase_JSON_inputs'][0] or {k:v for k,v in bc['phase_JSON_inputs'][0].items() if k!='role'}==bapi['arguments']['fixtures']['rawpin']

checks=[
 {'id':'exact-two-literal-provider-successor','passed':True,'evidence':'Full raw inverse recovers every provider5 byte using only revision6→5 and the one BIND nonterminal NORMALIZE→phase return. AST77 top-level definitions;76 raw/AST exact; only _raw_step differs. All public signatures and module VERSION/model/wire identity unchanged.'},
 {'id':'closed-seven-action-enum-restored','passed':True,'evidence':'Full _raw_step and class/branch pass-through paths read. NORMALIZE/BIND nonterminal emits NORMALIZE; terminal family-exhaustion remains EOF; other phases and shortcut actions retain original seven categories. Internal phase BIND/progress/hook and final callback-before-commit behavior unchanged. Tiny10 Source and normative enum remain exact; no test widening.'},
 {'id':'inventory-order-EOF-callbacks-remainders-inherited-by-raw-equality','passed':True,'evidence':'The repaired return label neither changes candidate/member state nor adds/removes callback/counter/cursor/product/reset/family work. Same full-Gamma, typed expanded-envelope membership, complete residual free dimensions, all8 schemas/tables/induction, identities, raw order, EOF, prefix reuse and exact-parent remainders retain prior complete Source findings and limits. This is Source reasoning, not runtime evidence.'},
 {'id':'exact-two-literal-bank-binding-successor','passed':True,'evidence':'Bank2 raw inverse recovers every bank1 byte using only VERSION2→1 and required implementation6→5. AST22 definitions;21 raw/AST exact; only public entry revision literal changes. Exact8 IDs/order/all expected sets/26 declaration input/return schema/finitefloat copier/fault recipes unchanged.'},
 {'id':'public-phase-fault-and-lowlevel-leaf-scopes-preserved','passed':True,'evidence':'Public first-fault watches raw.phase BIND, which remains exact under public action normalization; same-object poison/no-later-F obligations unchanged. Private entry fault is separate. n1 positive leaf acknowledgements enumerate complete positive leaves; MP/GEN rejection requires complete EMPTY child. No UNSAT prefix/cleanup witness or all-cutoff coverage inferred.'},
 {'id':'current-explicit-Source-docs-dependencies-and-legacy-subjects','passed':True,'evidence':'Complete current APIs/manuals/handoffs/static/closures and exact raw forward/inverse patches read and all declared direct Source/fixture/semantic guards rehashed. Current fixed8/tiny/controller subject6, original constructor14 and fixed8 order comparator exact4; no184-direct-tests-of6 claim. L diagnosis memo is a shallow preserved Source/API provenance body, never a runtime result/query/control/certificate input; B assessment is citation-only outside operative Source files. No recursive citation intake.'},
 {'id':'actual-negative-preserved-and-no-runtime-authority','passed':True,'evidence':'Consumed v1 target3 remains whole negative/all7null/resourcefalse/null qualified peak. Earlier immutable provider5/whole Source PASS missed the public enum defect and is preserved with current negative. Static counts PASSED8/complete in handoff/API describe prospective return contract, all8 are unrun. Fresh worker5/case metadata/grant/barrier/actual/C/Root gates remain separate; no proof/fit/performance/GCTS/RL/admission follows.'}
]
receipt={'schema':'GCTS-C-fixed-slot-provider6-bank2-narrow-component-Source-review-v1',
 'issued_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'review_complete':True,'review_passed':True,
 'scope':'Narrow immutable provider6 public-action and bank2 revision-binding repair, inherited full Source findings under exact raw/AST equality. Source only; not a control test, whole composition or actual approval.',
 'provider_source':pin(ps),'bank_source':pin(bs),'provider_handoff':pin(ph),'bank_handoff':pin(bh),
 'provider_API':pin(B/'full-frame-provider-fixed-free-slot-API-v6.json'),'bank_API':pin(L/'fixed-free-slot-independent-controls-API-v2.json'),
 'inherited_provider_complete_Source_review':pin(priorp),'inherited_bank_complete_Source_review':pin(priorb),
 'preserved_consumed_whole_negative':pin(negative),'input_pins':sorted(inputs.values(),key=lambda x:x['path']),
 'review_program':pin(__file__),'checks':checks,'failures':[],'concrete_blockers':[],
 'static':{'provider_definitions':77,'provider_unchanged_raw_AST_definitions':76,'provider_changed_definition':'_raw_step',
  'bank_definitions':22,'bank_unchanged_raw_AST_definitions':21,'bank_changed_definition':'run_fixed_free_slot_controls',
  'full_raw_inverse_exact':True,'AST_parse':True,'unused_compile_discarded':True,'compiled_subject_code_executed':False},
 'documentation_limits':['Provider5 _short_step inherited commentary overstates unrestricted raw testing; current v5/v6 API/manual complete legal-output coverage controls. Nonoperative unchanged wording.',
  'Bank2 inherited error text current5/closure scope/open-gate wording may name5 historically; exact executable required revision6/API/current Source pins govern. No expectation or ABI widening.',
  'Author AST serialization hashes remain opaque metadata; C uses direct current-interpreter old/new native AST equality and full raw inverse.'],
 'limits':['Component Source review only. Independent8 remain unrun, not all26 declarative properties or all possible cutoffs.',
  'No full public induction/table/inverse-substitution exhaustion, cleanup/allocation observation, standalone malformed-parser conformance or controller/proof qualification.',
  'Old176 scopes and six statements/ten caps remain unchanged; no consumed actual prefix is adopted. Exact future whole metadata/custody/current once review remains necessary.'],
 'scientific_imports_calls':0,'subject_fixtures_or_helpers_called':0,'ast_literal_evaluation':0,
 'queries_certificates_or_expected_sets_generated':0,'Root_admission_issued':False,
 'execution_or_publication_authority':False,'tools_idle_on_return':True}
for row in inputs.values():verify(row)
out=C/'typed-fixed-slot-provider6-bank2-narrow-component-Source-review-v1.json'
with out.open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps({'receipt':pin(out),'checks':len(checks),'input_pins':len(inputs)}))
