"""C-only saved JSON/raw custody audit. Never imports or calls study code.

Literal comparison/hashing of already saved records only; no semantic checker,
query decoder, fixture, oracle, search, codec, AST expansion or expected closure.
"""
from pathlib import Path
import hashlib
import json
import os

BASE = Path(__file__).resolve().parents[3]
STUDY = Path(__file__).resolve().parents[1]
ROOT = STUDY / "root"
ACTUAL = STUDY / "actual/point-frame-full-FPC-v1-target-0"
OBSERVER = Path(str(ACTUAL) + ".observer")


def load(path):
    path = Path(path)
    assert ".partial" not in path.name
    return json.loads(path.read_bytes())


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=True,
                      allow_nan=False, separators=(",", ":"))


def identity(raw):
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def pin(path):
    path = Path(path)
    return dict(path=str(path), **identity(path.read_bytes()))


def verify(row):
    path = Path(row["path"])
    assert path.is_absolute() and path.resolve() == path
    assert path.is_file() and not path.is_symlink()
    assert ".partial" not in path.name
    assert pin(path) == {k: row[k] for k in ("path", "bytes", "sha256")}


def walk(value):
    pending = [("$", value)]
    while pending:
        path, item = pending.pop()
        yield path, item
        if isinstance(item, dict):
            pending.extend((path + "." + str(k), v) for k, v in item.items())
        elif isinstance(item, list):
            pending.extend((path + "[" + str(i) + "]", v)
                           for i, v in enumerate(item))


def subset(expected, observed):
    if isinstance(expected, dict):
        assert isinstance(observed, dict)
        for k, v in expected.items():
            subset(v, observed[k])
    else:
        assert canonical(expected) == canonical(observed)


plan_path = ROOT / "plans/point-frame-full-FPC-v1-target-0.json"
grant_path = ROOT / "grants/point-frame-full-FPC-v1-target-0.json"
plan, grant = load(plan_path), load(grant_path)
protocol = load(plan["protocol"]["path"])
case = plan["case_id"]
assert case == "point-frame-full-FPC-v1-target-0"
assert len(plan["files"]) == 70
for row in plan["files"]:
    verify(row)
for field in ("plan", "protocol", "closure", "component_review", "whole_review",
              "grant_proposal_review", "all_tools_idle_barrier", "Root_prospective_acceptance"):
    verify(grant[field])
assert grant["schema"] == "Root-point-frame-once-grant-v1"
assert grant["authorized"] is True and grant["review_passed"] is True
assert type(grant["uses"]) is int and grant["uses"] == 1
assert grant["plan"] == pin(plan_path)
assert grant["protocol"] == plan["protocol"]
assert grant["case_id"] == case
assert grant["plan_sha256"] == pin(plan_path)["sha256"]
acceptance = load(grant["Root_prospective_acceptance"]["path"])
barrier = load(grant["all_tools_idle_barrier"]["path"])
assert acceptance["accepted"] is True and acceptance["guards_verified"] == 70
assert barrier["fresh_guard_checks"] == 70 and barrier["fresh_absence_checks"] == 18
assert barrier["scientific_work_in_progress"] is False
assert barrier["parallel_operations_during_actual"] is False
assert barrier["acceptance"] == grant["Root_prospective_acceptance"]
consumed = load(ACTUAL / "CONSUMED.json")
assert consumed == dict(schema="proof-search-case-consumed-v1", case_id=case,
                       uses=1, plan_sha256=pin(plan_path)["sha256"],
                       grant_sha256=pin(grant_path)["sha256"])

raw_census_path = ROOT / "point-frame-target-0-first-terminal-raw-census-v1.json"
raw_census = load(raw_census_path)
assert raw_census["exec_session_id"] == 84772 and raw_census["exec_exit_code"] == 0
physical = []
for directory in (ACTUAL, OBSERVER):
    for path in sorted(directory.iterdir()):
        assert path.is_file() and not path.is_symlink()
        physical.append(pin(path))
assert len(physical) == 13
assert not any(".partial" in Path(p["path"]).name for p in physical)
assert sorted(physical, key=lambda p: p["path"]) == sorted(
    [{k: p[k] for k in ("path", "bytes", "sha256")} for p in raw_census["files"]],
    key=lambda p: p["path"])
for row in raw_census["files"]:
    assert row["partial_opaque"] is False
    verify(row)

result = load(ACTUAL / "result.json")
header = load(ACTUAL / "worker-header.json")
terminal = load(ACTUAL / "terminal.json")
observer = load(OBSERVER / "observer.json")
owner = load(ACTUAL / "owned-child.json")
assert result["status"] == header["status"] == "COMPLETE"
assert result["error"] is None and result["first_Root_fault"] is False
assert result["source_unchanged"] is header["source_unchanged"] is True
assert result["old_qualification_reused"] is False
assert header["result"] == terminal["result"] == pin(ACTUAL / "result.json")
assert header == terminal["header"]
assert load(OBSERVER / "stdout.bin") == terminal
assert not (ACTUAL / "stderr.bin").read_bytes()
assert not (OBSERVER / "stderr.bin").read_bytes()
assert terminal["process_exit_code"] == observer["parent_exit_code"] == 0
assert terminal["header_valid"] is terminal["threads_terminal"] is True
assert terminal["sources_unchanged"] is terminal["final_custody_gate_passed"] is True
assert terminal["reason"] is observer["reason"] is None
assert terminal["errors"] == observer["errors"] == []
assert owner == observer["owned_child"]
assert owner["child_pid"] == owner["child_pgid"] == 39942
assert owner["parent_pid"] == 39941 and owner["plan_sha256"] == pin(plan_path)["sha256"]
limits = plan["limits"]
assert result["elapsed_seconds"] < limits["work_seconds"]
assert header["seconds"] < limits["positive_seconds"]
assert terminal["known_exit_seconds"] <= limits["positive_seconds"]
assert terminal["final_custody_gate_seconds"] <= limits["custody_seconds"]
assert observer["final_observer_gate_seconds"] <= limits["custody_seconds"]
assert observer["fallback_trigger_seconds"] is None
assert observer["partial_files_parsed"] is False
assert observer["resource_candidate_accepted"] is True
assert observer["resource_candidate_before_receipt"] is True
assert result["callbacks"] + 1 == header["callbacks"] <= limits["root_callbacks"]
for d, logs, cap in ((ACTUAL, terminal["logs"], limits["log_bytes"]),
                     (OBSERVER, observer["logs"], 1048576)):
    for name, row in logs.items():
        assert row["eof"] is True and row["overflow"] is False
        assert row["bytes"] == row["stored"] == (d / (name + ".bin")).stat().st_size <= cap
assert terminal["conservative_combined_peak_bytes"] == (
    terminal["parent_usage"]["ru_maxrss"] +
    max(terminal["child_usage"]["ru_maxrss"], header["python_peak_after_output_bytes"]) +
    header["native_peak_bytes"] + terminal["memory_terminal_output_reserve_bytes"])
assert observer["final_conservative_whole_peak_bytes"] == (
    terminal["conservative_combined_peak_bytes"] + observer["final_observer_peak_bytes"] +
    observer["final_output_memory_reserve_bytes"])
assert 0 < observer["final_conservative_whole_peak_bytes"] < limits["memory_bytes"]
assert sum(p["bytes"] for p in physical) < limits["physical_bytes"]
assert result["native_peak_bytes"] == result["native_requests_started"] == 0
assert result["native_queries"] == result["guard_compilations"] == result["work_snapshots"] == []
assert result["native_transport"] == dict(all_reaped=True, closed=True,
    native_exit_code=0, native_high_water_bytes=0, scope="VACUOUS_NO_NATIVE_SUBPROCESS",
    subprocesses_started=0)

qualification = result["qualification_result"]
assert result["qualification_complete"] is True
ledger = []
populations = dict(qualification)
explicit = populations.pop("explicit16")
populations["point-kernel13"] = explicit["raw_population"]
populations["point-kernel-safety3"] = explicit["additional_population"]
assert set(populations) == set(plan["control_populations"])
for name, spec in plan["control_populations"].items():
    packet = populations[name]
    assert packet["control_ids"] == spec["control_ids"]
    assert [r["id"] for r in packet["controls"]] == spec["control_ids"]
    assert packet["counts"]["passed"] == spec["groups"]
    assert packet["counts"]["failed"] == 0
    for row in packet["controls"]:
        assert row.get("passed") is True or row.get("status") == "PASSED"
        ledger.append(dict(population=name, id=row["id"],
                           complete_saved_row_sha256=hashlib.sha256(canonical(row).encode()).hexdigest()))
assert len(ledger) == 162 and len({(x["population"], x["id"]) for x in ledger}) == 162
assert all(p["complete"] is True for p in qualification.values())

literal_pairs = guard_subsets = fault_fields = byte_pairs = 0
subjects, references, paired_validators = [], [], []
for path, item in walk(result):
    if not isinstance(item, dict):
        continue
    if "expected" in item and "observed" in item and type(item["expected"]) is type(item["observed"]):
        assert canonical(item["expected"]) == canonical(item["observed"])
        literal_pairs += 1
    for key in ("identity_preserved", "same_exception_identity", "same_object", "identical",
                "exception_attributes_unchanged", "args_and_attributes_unchanged", "input_unchanged",
                "exception_args_attributes_unchanged"):
        if key in item:
            assert item[key] is True, (path, key)
            fault_fields += 1
    for key in ("returned_point_or_proof_prefix", "candidate_or_prefix_admitted", "normal_prefix",
                "faulted_state_resumed"):
        if key in item:
            assert item[key] is False, (path, key)
    if item.get("schema") == "FPC-H1-finite-byte-check-receipt-v1":
        assert item["status"] == "VALID_DERIVATION"
        for key in ("accepted", "complete", "syntax_complete", "derivation_complete", "no_prefix_authority", "final_goal_equal"):
            assert item[key] is True
        cert = item["certificate"]
        assert cert["row_count"] == len(cert["rows"])
        assert cert["EOF"] == item["raw_inputs"]["certificate"]["bytes"]
        assert item["query"]["EOF"] == item["raw_inputs"]["query"]["bytes"]
        for i, row in enumerate(cert["rows"]):
            assert row["index"] == i and row["validation"]["status"] == "VALID"
            assert all(x["passed"] is True for x in row["validation"]["side_conditions"])
            assert all(type(j) is int and 0 <= j < i for j in row["validation"]["references"])
        subjects.append((path, cert["row_count"]))
    if item.get("schema") == "FPC-H1-independent-flat-reference-v2":
        assert item["status"] == "VALID_DERIVATION"
        assert item["complete_check"] is item["final_goal_equal"] is True
        references.append((path, len(item["rows"])))
    a, b = item.get("subject"), item.get("reference")
    if isinstance(a, dict) and isinstance(b, dict) and a.get("schema") == "FPC-H1-finite-byte-check-receipt-v1" and b.get("schema") == "FPC-H1-independent-flat-reference-v2":
        assert len(a["certificate"]["rows"]) == len(b["rows"])
        paired_validators.append(path)
        for label in ("query", "certificate"):
            if label + "_hex" in item:
                raw = bytes.fromhex(item[label + "_hex"])
                assert identity(raw) == item[label]
                assert identity(raw) == a["raw_inputs"][label]
                byte_pairs += 1

for row in populations["obligation47"]["controls"]:
    e = row["evidence"]
    if row["id"].startswith("guard-"):
        subset(e["expected"], e["receipt"])
        guard_subsets += 1
    if row["id"].startswith("refuse-"):
        assert e["expected"] == "OWNED_ProducerInputError"
        assert e["observed"]["class"] == "ProducerInputError"
for row in populations["baseline56"]["controls"]:
    e = row["evidence"]
    if "expected_known" in e:
        assert {canonical(v) for v in e["expected_known"]} == {canonical(v["formula"]) for v in e["receipt"]["known"]}
    if "expected_hex" in e:
        assert identity(bytes.fromhex(e["expected_hex"])) == e["receipt"]["query_identity"]

tiny = populations["tiny-full-provider10"]
assert [r["expected_count"] for r in tiny["controls"][:7]] == [4, 8, 4, 1, 0, 2, 0]
fields = ("formula", "m", "references", "rule_tag", "subtag", "t", "witness")
for row in tiny["controls"][:7]:
    members, expected = row["members"], row["oracle"]["members"]
    assert len(members) == len(expected) == row["expected_count"]
    assert {canonical({k: m[k] for k in fields}) for m in members} == {canonical(m) for m in expected}
    assert len({canonical(m["key"]) for m in members}) == len(members)
    d = row["classification"]
    if row["expected_count"] < 2:
        assert d["coverage_complete"] is True and d["counts"]["fallback_eof_events"] >= 1
        assert d["kind"] == ("EMPTY" if not members else "SINGLE")
    else:
        assert d["kind"] == "MANY" and len(d["witnesses"]) == 2
    for m in members:
        key = m["key"]
        assert len(key) == 8 and key[0] == "FPC-point-ground-key-v1"
        assert key[3:6] == [m["rule_tag"], m["subtag"], m["witness"]]
        assert key[6:] == [m["t"], m["m"]]

kernel_solutions = 0
controller_traces = 0
for _, item in walk(qualification):
    if not isinstance(item, dict):
        continue
    a, b = item.get("oracle"), item.get("kernel")
    if isinstance(a, dict) and isinstance(b, dict) and "solution_subsets" in a:
        assert a["complete"] is b["complete"] is True
        assert {canonical(sorted(x)) for x in a["solution_subsets"]} == {canonical(sorted(x)) for x in b["solution_subsets"]}
        assert item["entry_restored"] is True
        kernel_solutions += 1
    if item.get("kind") == "DECISION" and "all_unfilled" in item:
        if item["status"] in ("FORCED", "BRANCH"):
            assert not any(r["kind"] in ("EMPTY", "UNRESOLVED") for r in item["all_unfilled"])
        if item["status"] == "BRANCH":
            assert not any(r["kind"] == "SINGLE" for r in item["all_unfilled"])
        controller_traces += 1
    if item.get("kind") == "REJECT":
        assert item["reason"] in ("CHILD_DEAD", "CHILD_EXHAUSTED")

ctrl = populations["full-frame-controller10"]["controls"]
fuel64 = ctrl[4]["facets"][-1]
assert fuel64["fuel"] == 64 and fuel64["terminal"]["phase"] == "CLASSIFY_ADVANCE"
assert fuel64["terminal"]["outstanding_offers"] == 1 and fuel64["metrics"]["reject_offers"] == 0
assert len(ctrl[5]["recipes"]) == 11 and ctrl[5]["recipes"][-1]["later_cleanup_F_exercised"] is True
real = ctrl[6]["cases"][-1]
assert real["fixture"] == "controller-only-E1-two-row-reuse"
assert real["oracle"]["solution_count"] == 4
assert real["metrics"]["classifier_opens"] == 2 and real["metrics"]["classifiers_rebound"] == 1
trace = real["reuse_trace"]
selected = [e for e in trace if e["kind"] == "SELECT"]
assert [e["row"] for e in selected] == [1, 0]
first = selected[0]
assert first["forced"] is True and first["from_offer"] is False and selected[1]["from_offer"] is True
assert any(e["kind"] == "REUSE" and e["row"] == 0 and e["from_state_serial"] == first["parent_serial"] and e["state_serial"] == first["child_serial"] for e in trace)

frozen = result["input_freeze"]
assert frozen == load(ACTUAL / "target-input-freeze.json")
query_raw = (ACTUAL / "target-query.bin").read_bytes()
cert_raw = (ACTUAL / "candidate-certificate.bin").read_bytes()
assert frozen["immutable_query"] == pin(ACTUAL / "target-query.bin")
declarations = load(plan["declarations"]["path"])
assert frozen["literal_declaration"] == declarations["targets"][0]
assert frozen["search_started"] is False and frozen["target_index"] == 0
assert frozen["decoded_query"] == result["subject_receipt"]["query"]
assert frozen["codec_receipt"]["expanded_goal"] == frozen["decoded_query"]["goal"]
assert frozen["codec_receipt"]["query_identity"] == identity(query_raw)
search = result["search_result"]
assert bytes.fromhex(search["candidate_certificate_hex"]) == cert_raw
assert search["accepted"] is False and search["status"] == "CANDIDATE"
assert search["export_receipt"]["model"]["query_hex"] == query_raw.hex()
assert search["export_receipt"]["model"]["frame"] == search["last_frame"]["frame"]
assert search["export_receipt"]["accepted"] is False
assert search["export_receipt"]["exact_rows"] == 3
subject = result["subject_receipt"]
assert subject["raw_inputs"] == dict(query=identity(query_raw), certificate=identity(cert_raw))
assert [r["formula"] for r in subject["certificate"]["rows"]] == [r["formula"] for r in search["export_receipt"]["rows"]]
assert [r["witness"] for r in subject["certificate"]["rows"]] == [r["witness"] for r in search["export_receipt"]["rows"]]
assert [r["rule_tag"] for r in subject["certificate"]["rows"]] == [1, 1, 4]
assert subject["certificate"]["rows"][2]["witness"] == [0, 0]
point = result["point_receipt"]
assert point["complete"] is point["point_compatible"] is True and point["mismatches"] == []
assert point["proof_admitted"] is point["search_engine"] is point["GCTS_conformance"] is False
assert point["row_count"] == 3 and [x[1] for x in point["t_totals"]] == [1, 1, 1]
assert [t["conclusion"] for t in point["tiles"]] == [x["formula"] for x in subject["certificate"]["rows"]]
m = search["metrics"]
assert (m["frame_runs"], m["frame_atomic_steps"], m["sum_frame_limits"]) == (97, 7380, 32497)
assert m["frames_exhausted"] + m["frames_fuel_limited"] + 1 == m["frame_runs"]
assert search["last_frame"] == dict(round=14, pair_index=6,
    frame=dict(schema="FPC-point-frame-v1", rows=3, syntax_nodes=4),
    max_steps=256, status="CANDIDATE", atomic_steps=228)

output = dict(schema="C-point-frame-target0-passive-raw-evidence-audit-v1",
    all_checks_passed=True, Source_program=pin(__file__), result=pin(ACTUAL / "result.json"),
    plan=pin(plan_path), grant=pin(grant_path), raw_census=pin(raw_census_path),
    physical_census=dict(files=physical, total_bytes=sum(p["bytes"] for p in physical), partials=0),
    checks_summary=dict(current_guard_count=70, complete_namespaced_control_rows=len(ledger),
        literal_expected_observed_pairs=literal_pairs, guard_expected_subsets=guard_subsets,
        first_fault_identity_immutability_fields=fault_fields,
        saved_subject_receipt_occurrences=len(subjects), saved_subject_rows=sum(n for _, n in subjects),
        saved_reference_occurrences=len(references), paired_validator_occurrences=len(paired_validators),
        exact_saved_hex_raw_identity_joins=byte_pairs, generic_oracle_kernel_solution_pairs=kernel_solutions,
        controller_saved_decisions=controller_traces),
    control_row_digest_ledger=ledger,
    clocks=dict(observer_elapsed_seconds=observer["elapsed_seconds"],
        observer_final_gate_seconds=observer["final_observer_gate_seconds"],
        tool_summary_seconds=raw_census["terminal_stdout"]["seconds"]),
    whole_peak_bytes=observer["final_conservative_whole_peak_bytes"],
    display_only_audit_note="An exploratory display queried nonexistent witness_count and stopped before writes. Actual ABI uses len(witnesses); no study Source/call/run changed.",
    scientific_imports_calls=0, semantic_decoding_or_expected_generation=0,
    scope="Saved literal/metadata evidence and Source provenance audit, not checker/oracle/kernel/search replay or Root admission.")
out = STUDY / "review-C/typed-point-frame-target-0-actual-passive-audit-v1.json"
raw = (json.dumps(output, indent=2, ensure_ascii=True, allow_nan=False) + "\n").encode()
with out.open("xb") as stream:
    stream.write(raw)
print(json.dumps(dict(output=pin(out), summary=output["checks_summary"],
                      physical_bytes=output["physical_census"]["total_bytes"])))
