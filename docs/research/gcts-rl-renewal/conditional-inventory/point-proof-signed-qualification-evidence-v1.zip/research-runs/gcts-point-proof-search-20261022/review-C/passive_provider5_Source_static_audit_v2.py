"""Raw/AST/unused-compile checks only. Never import or execute research Source."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import re

BASE = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
S = BASE / 'research-runs/gcts-point-proof-search-20261022'
B, C = S / 'implementation-B', S / 'review-C'


def raw(p):
    p = Path(p)
    assert p.is_file() and not p.is_symlink()
    return p.read_bytes()


def pin(p):
    p = Path(p).resolve()
    b = raw(p)
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())


def load(p):
    return json.loads(raw(p))


def refs(v):
    if isinstance(v, dict):
        if {'path','bytes','sha256'} <= v.keys():
            yield {k:v[k] for k in ('path','bytes','sha256')}
        for child in v.values():
            yield from refs(child)
    elif isinstance(v, list):
        for child in v:
            yield from refs(child)


def apply_unified(text, patch):
    old = text.splitlines(keepends=True)
    lines = patch.splitlines(keepends=True)
    assert lines[0].startswith('--- ') and lines[1].startswith('+++ ')
    out, at, i = [], 0, 2
    while i < len(lines):
        match = re.match(r'^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@', lines[i])
        assert match
        start = int(match[1]) - 1
        out.extend(old[at:start])
        at, i = start, i + 1
        old_count = new_count = 0
        while i < len(lines) and not lines[i].startswith('@@ '):
            item = lines[i]
            assert item[0] in ' +-'
            if item[0] in ' -':
                assert old[at] == item[1:]
                at += 1
                old_count += 1
            if item[0] in ' +':
                out.append(item[1:])
                new_count += 1
            i += 1
        assert old_count == int(match[2] or 1) and new_count == int(match[4] or 1)
    return ''.join(out + old[at:])


offer_path = B / 'full-frame-provider-Source-handoff-v5.json'
offer = load(offer_path)
documents = [offer_path] + [Path(x['path']) for x in offer['files'] if x['path'].endswith('.json')]
verified = {}
for document in documents:
    for ref in refs(load(document)):
        assert pin(ref['path']) == ref
        verified[ref['path']] = ref
old_path = B / 'fpc_full_frame_inventory_v4.py'
new_path = B / 'fpc_full_frame_inventory_v5.py'
old_raw, new_raw = raw(old_path), raw(new_path)
assert len(new_raw) == 67631 and hashlib.sha256(new_raw).hexdigest() == '2bdc125646ec3d54ac55718b85d0dd3a4fa69ba2c1de91d29e589ded95fe31e6'
old_text, new_text = old_raw.decode(), new_raw.decode()
old_tree, new_tree = ast.parse(old_text), ast.parse(new_text)
assert not any(isinstance(x, (ast.Import,ast.ImportFrom)) for x in ast.walk(new_tree))
unused = compile(new_raw, str(new_path), 'exec')
del unused
old_defs = {x.name:x for x in old_tree.body if isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))}
new_defs = {x.name:x for x in new_tree.body if isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))}
changed, unchanged = [], []
for name, node in old_defs.items():
    other = new_defs[name]
    a, b = ast.dump(node,include_attributes=False), ast.dump(other,include_attributes=False)
    if a == b:
        assert ast.get_source_segment(old_text,node) == ast.get_source_segment(new_text,other)
        unchanged.append(name)
    else:
        changed.append(name)
added = sorted(set(new_defs) - set(old_defs))
assert len(old_defs) == 75 and len(new_defs) == 77 and len(unchanged) == 68
assert changed == ['_slot','_slot_step','_product','_product_step','_raw','_raw_step','_frontier']
assert added == ['_restriction_start','_restriction_step']
for name, node in old_defs.items():
    if isinstance(node,ast.FunctionDef) and not name.startswith('_'):
        assert ast.dump(node.args,include_attributes=False) == ast.dump(new_defs[name].args,include_attributes=False)
old_assign = {x.targets[0].id:x for x in old_tree.body if isinstance(x,ast.Assign) and len(x.targets)==1 and isinstance(x.targets[0],ast.Name)}
new_assign = {x.targets[0].id:x for x in new_tree.body if isinstance(x,ast.Assign) and len(x.targets)==1 and isinstance(x.targets[0],ast.Name)}
assert set(new_assign) - set(old_assign) == {'_OUTPUT_PATTERNS'}
assert {k for k in old_assign if ast.dump(old_assign[k],include_attributes=False) != ast.dump(new_assign[k],include_attributes=False)} == {'IMPLEMENTATION_REVISION','FEATURES'}
forward_path = B / 'full-frame-provider-v4-v5-fixed-free-slots.patch'
inverse_path = B / 'full-frame-provider-v5-v4-fixed-free-slots.inverse.patch'
forward, inverse = raw(forward_path).decode(), raw(inverse_path).decode()
assert forward == ''.join(difflib.unified_diff(old_text.splitlines(keepends=True),new_text.splitlines(keepends=True),fromfile=old_path.name,tofile=new_path.name))
assert inverse == ''.join(difflib.unified_diff(new_text.splitlines(keepends=True),old_text.splitlines(keepends=True),fromfile=new_path.name,tofile=old_path.name))
assert apply_unified(old_text,forward) == new_text
assert apply_unified(new_text,inverse) == old_text
declared = load(B / 'full-frame-provider-v5-static.json')
assert declared['changed_existing_definitions'] == changed and declared['new_definitions'] == added
for item in declared['definitions']:
    node = new_defs[item['name']]
    assert item['line'] == node.lineno and item['end_line'] == node.end_lineno
    legacy = ast.parse(ast.get_source_segment(new_text, node)).body[0]
    for part in ast.walk(legacy):
        if 'type_params' in part._fields:
            part._fields = tuple(k for k in part._fields if k != 'type_params')
    assert item['ast_sha256'] == hashlib.sha256(ast.dump(legacy,include_attributes=False).encode()).hexdigest()
assert pin(new_path) == offer['Source']
result = dict(schema='GCTS-C-provider5-raw-AST-inverse-static-audit-v1',
    all_checks_passed=True, Source=pin(new_path), predecessor=pin(old_path),
    offer=pin(offer_path), review_program=pin(Path(__file__)),
    source_lines=len(new_text.splitlines()), old_definitions=75,new_definitions=77,
    exact_raw_and_AST_unchanged_definitions=unchanged, changed_private_definitions=changed,
    added_private_definitions=added, no_imports=True,public_signatures_exact=True,
    top_level_constant_changes=['IMPLEMENTATION_REVISION','FEATURES'],new_constant='_OUTPUT_PATTERNS',
    forward_patch=pin(forward_path),inverse_patch=pin(inverse_path),
    forward_and_inverse_raw_application_exact=True,author_all_definition_AST_hashes_verified_under_type_params_omitted_projection=True,
    native_AST_hashes_not_claimed_equal=True,
    author_AST_serialization_limit='Author interpreter is unspecified. All77 hashes reproduce with the legacy schema omitting only type_params; direct CPython3.12 old/new raw+AST comparison is independent.',
    unused_compile_object_discarded=True,verified_named_raw_pins=[verified[k] for k in sorted(verified)],
    named_pin_count=len(verified),scientific_imports_calls=0,subject_Source_executed=False,
    ast_literal_evaluation=False,semantic_fixture_or_expected_set_generation=False,
    old_frozen_edits=False,Root_or_Publisher_mutations=False)
out = C / 'provider5-raw-AST-inverse-static-audit-v2.json'
with out.open('xb') as f:
    f.write((json.dumps(result,indent=2)+'\n').encode())
print(json.dumps(dict(audit=pin(out),program=pin(Path(__file__)),lines=result['source_lines'],
    changed=changed,added=added,exact_unchanged=len(unchanged),named_pins=len(verified)),indent=2))
