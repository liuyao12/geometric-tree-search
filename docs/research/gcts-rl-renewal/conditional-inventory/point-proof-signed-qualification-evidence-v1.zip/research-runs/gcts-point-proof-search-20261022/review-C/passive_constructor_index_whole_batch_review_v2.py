"""C-owned Source/complete-JSON/raw audit. Never imports or calls research code."""
from pathlib import Path
from datetime import datetime, timezone
import ast
import difflib
import hashlib
import json

BASE = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
S = BASE / 'research-runs/gcts-point-proof-search-20261022'
R, B, L, C = [S / x for x in ('root', 'implementation-B', 'diagnostics-L', 'review-C')]


def rawpin(path):
    p = Path(path)
    if not p.is_absolute():
        p = BASE / p
    assert p.resolve() == p and not p.is_symlink() and p.is_file() and '.partial' not in p.name
    raw = p.read_bytes()
    return dict(path=str(p), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def current(row):
    p = rawpin(row['path'])
    assert p == {k: row[k] for k in ('path', 'bytes', 'sha256')}, row['path']
    return Path(p['path'])


def load(path):
    return json.loads(Path(path).read_bytes())


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False)


def literal(node):
    # Read only authored top-level literal declarations; no eval/literal_eval.
    if isinstance(node, ast.Constant):
        return node.value
    if isinstance(node, (ast.Tuple, ast.List)):
        items = [literal(x) for x in node.elts]
        return tuple(items) if isinstance(node, ast.Tuple) else items
    if isinstance(node, ast.Dict):
        return {literal(k): literal(v) for k, v in zip(node.keys, node.values, strict=True)}
    raise ValueError('not a selected literal declaration')


def source(path, names=()):
    text = Path(path).read_text()
    tree = ast.parse(text)
    compile(text, str(path), 'exec')  # unused code object only
    values = {}
    for node in tree.body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            if node.targets[0].id in names:
                values[node.targets[0].id] = literal(node.value)
    return text, tree, values


def passed(name, finding, lines=()):
    return dict(check=name, passed=True, source_lines=list(lines), finding=finding)


prep_path = R / 'constructor-index-study-preparation-v2.json'
assert rawpin(prep_path)['bytes'] == 8954
assert rawpin(prep_path)['sha256'] == '8e320def229a248a08609d167446c29a3290b11a2113364160c9d70cc45e6475'
prep = load(prep_path)
builder = current(prep['metadata_builder'])
assert rawpin(builder)['sha256'] == '257a82b5b67da7b021c1304121518bef78766761f5e42d08640035a80584ea90'
source(builder)
issuer = R / 'issue_constructor_index_case_grant_v2.py'
source(issuer)
census_helper = R / 'census_completed_constructor_index_case_v2.py'
source(census_helper)
observation = R / 'constructor-index-metadata-authoring-observation-v1.json'
obs = load(observation)
assert obs['outputs_before_stop'] == 0 and obs['scientific_imports_calls'] == 0
assert obs['actual_or_grant_created'] is False and obs['subject_source_or_expectation_changed'] is False
protocol_path = current(prep['protocol'])
protocol = load(protocol_path)
assert rawpin(protocol_path)['sha256'] == 'bec4cf0c6f83ecfeff3aa60ee4dc728db87f0b2c8767c8c4874f70acda1721bd'
worker_path = current(prep['worker'])
assert rawpin(worker_path)['sha256'] == '16cd87d911692f5e8378fa46f87339e75c92b88cc738414d976b4ac66e830fd2'
names = ('VERSION', 'EXPERIMENT', 'PROTOCOL_SCHEMA', 'MODULE_ROLES', 'FIXED_PINS', 'CONTROL_IDS', 'CAPS',
         'PRODUCTION_CONFIGURATION', 'CONTROLLER_BANK_PIN', 'CONCLUSION_BANK_PIN', 'CONCLUSION_FIXTURES_PIN')
wtext, wtree, constants = source(worker_path, names)
oldworker = B / 'fpc_point_frame_search_worker_v2.py'
otext, otree, oldconstants = source(oldworker, names)
defs = lambda tree: {n.name: n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}
newdefs, olddefs = defs(wtree), defs(otree)
assert set(newdefs) == set(olddefs) and len(newdefs) == 8
changed = [name for name in newdefs if ast.dump(newdefs[name], include_attributes=False) != ast.dump(olddefs[name], include_attributes=False)]
assert changed == ['main']
assert ast.get_source_segment(otext, olddefs['main']).replace('L-conclusion-index-independent-controls-v1', 'L-conclusion-index-independent-controls-v2') == ast.get_source_segment(wtext, newdefs['main'])
for name in set(newdefs) - {'main'}:
    assert ast.get_source_segment(wtext, newdefs[name]) == ast.get_source_segment(otext, olddefs[name])
for a, b, patch in ((otext, wtext, B / 'point-frame-worker-v2-v3-bank-carrier.patch'),
                    (wtext, otext, B / 'point-frame-worker-v3-v2-bank-carrier.inverse.patch')):
    labels = ('fpc_point_frame_search_worker_v2.py', 'fpc_point_frame_search_worker_v3.py')
    if a == wtext:
        labels = labels[::-1]
    assert ''.join(difflib.unified_diff(a.splitlines(True), b.splitlines(True), fromfile=labels[0], tofile=labels[1])) == patch.read_text()
assert constants['MODULE_ROLES'] == oldconstants['MODULE_ROLES']
assert constants['MODULE_ROLES'][-1] == 'conclusion_index_bank'
assert constants['CONTROL_IDS'] == oldconstants['CONTROL_IDS']
assert constants['CAPS'] == oldconstants['CAPS'] and constants['PRODUCTION_CONFIGURATION'] == oldconstants['PRODUCTION_CONFIGURATION']
api = load(B / 'point-frame-worker-API-v3.json')
offer = load(B / 'point-frame-worker-dependency-offer-v3.json')
handoff = load(B / 'point-frame-worker-Source-handoff-v3.json')
for row in handoff['files']:
    current(row)
modules = {x['role']: x['rawpin'] for x in offer['runtime_roles']}
assert modules == {x['role']: {k: x[k] for k in ('path', 'bytes', 'sha256')} for x in api['runtime_roles']}
assert set(modules) == set(constants['MODULE_ROLES']) and len(modules) == 23
fixed = dict(constants['FIXED_PINS'], controller_bank=constants['CONTROLLER_BANK_PIN'], conclusion_index_bank=constants['CONCLUSION_BANK_PIN'])
assert all((row['bytes'], row['sha256']) == fixed[role] for role, row in modules.items())
assert protocol['module_pins'] == modules
populations = {x['population']: {k: x[k] for k in ('control_ids', 'groups', 'bank_role', 'subject_role', 'scope')} for x in api['scoped_populations']}
assert protocol['control_populations'] == populations
assert {k: tuple(v['control_ids']) for k, v in populations.items()} == constants['CONTROL_IDS']
assert sum(x['groups'] for x in populations.values()) == 176 and len(populations) == 10
assert all(type(x['groups']) is int and x['groups'] == len(x['control_ids']) for x in populations.values())
scoped_ids = [(p, identifier) for p, x in populations.items() for identifier in x['control_ids']]
assert len(scoped_ids) == len(set(scoped_ids)) == 176
assert set(protocol) == {'schema', 'experiment', 'limits', 'module_pins', 'control_populations', 'job_recipes', 'metadata'}
assert protocol['schema'] == constants['PROTOCOL_SCHEMA'] and protocol['experiment'] == constants['EXPERIMENT']
assert protocol['limits'] == constants['CAPS'] and len(protocol['limits']) == 10
assert all(type(value) is int for value in protocol['limits'].values())
oldplan_path = R / 'plans/point-frame-full-FPC-v1-target-0.json'
oldplan = load(oldplan_path)
assert len(oldplan['files']) == 70
assert all(populations[k] == value for k, value in oldplan['control_populations'].items())
assert all(modules[k] == value for k, value in oldplan['module_pins'].items() if k != 'provider')
declarations = load(oldplan['declarations']['path'])
recipes = [dict(case_id=constants['EXPERIMENT'] + '-target-' + str(i), target_index=i, target_id=spec['id']) for i, spec in enumerate(declarations['targets'])]
assert len(recipes) == 6 and protocol['job_recipes'] == recipes
assert [x['recipe'] for x in prep['cases']] == recipes
component = current(prep['worker_component_review'])
bankreview = current(prep['bank_component_review'])
assert rawpin(component)['sha256'] == '918160e17997592688262a81828785db4bdd8006a9a90797147fa7dae6479ad8'
assert rawpin(bankreview)['sha256'] == '428c6200e9a6032ef79a8b286732de10674c10e5bc27d856fb579dc4fbab847f'
assert load(component)['review_passed'] is True and load(bankreview)['review_passed'] is True
assert protocol['metadata']['component_review'] == prep['worker_component_review']
assert protocol['metadata']['additive_bank_review'] == prep['bank_component_review']
assert protocol['metadata']['current_worker'] == prep['worker']

first = load(current(prep['cases'][0]['plan']))
guards = first['files']
assert len(guards) == len({x['path'] for x in guards}) == 109
assert guards == sorted(guards, key=lambda x: x['path'])
for row in guards:
    current(row)
before = [rawpin(x['path']) for x in guards]
assert all(row in guards for row in oldplan['files'])
assert all(row in guards for row in modules.values())
assert not any('/actual/' in x['path'] or '/admission/' in x['path'] or '/grants/' in x['path']
               or x['path'].endswith(('.bin', '.partial')) for x in guards)
assert prep['shared_guards'] == 109 and prep['namespaces'] == 23 and prep['scoped_groups'] == 176
assert prep['scoped_populations'] == 10
assert prep['metadata_builder'] in guards and prep['protocol'] in guards
assert rawpin(issuer)['path'] not in {x['path'] for x in guards}
raw_inputs = {x['role']: x['rawpin'] for x in offer['raw_inputs']}
assert len(raw_inputs) == 5 and all(x in guards for x in raw_inputs.values())
assert first['conclusion_index_fixtures'] == raw_inputs['conclusion_index_fixtures']
custody = {x['role']: x['rawpin'] for x in offer['custody_runtime']}
assert set(custody) == {'runner', 'observer', 'python'} and all(x in guards for x in custody.values())
source(custody['runner']['path'])
source(custody['observer']['path'])
assert first['runner_path'] == custody['runner']['path'] and first['python'] == custody['python']
assert first['required_upstream_ids'] == [] and first['stage'] == 'evaluate'
assert first['limits'] == oldplan['limits'] == protocol['limits']
assert first['search_configuration'] == oldplan['search_configuration'] == constants['PRODUCTION_CONFIGURATION']
assert set(first) == set(oldplan) | {'conclusion_index_fixtures'}
for key in ('declarations', 'target_authority', 'explicit_raw_models', 'tiny_provider_declarations'):
    assert first[key] == oldplan[key]
case_results = []
absences = []
proposal0 = load(current(prep['cases'][0]['proposal']))
closure0 = load(current(prep['cases'][0]['closure']))
for index, item in enumerate(prep['cases']):
    planpath, closurepath, proposalpath = [current(item[key]) for key in ('plan', 'closure', 'proposal')]
    plan, closure, proposal = [load(p) for p in (planpath, closurepath, proposalpath)]
    assert planpath == R / 'plans' / (recipes[index]['case_id'] + '.json')
    assert {k: plan[k] for k in recipes[index]} == recipes[index]
    delta = sorted(k for k in first if canonical(first[k]) != canonical(plan[k]))
    assert delta == (['actual_dir', 'case_id', 'target_id', 'target_index'] if index else [])
    assert plan['worker_path'] == str(worker_path) and plan['experiment'] == constants['EXPERIMENT']
    assert plan['files'] == guards and plan['protocol'] == prep['protocol']
    assert plan['module_pins'] == modules and plan['control_populations'] == populations
    assert plan['actual_dir'] == str(S / 'actual' / recipes[index]['case_id'])
    assert closure['plan'] == item['plan'] and closure['protocol'] == prep['protocol'] and closure['files'] == guards
    assert set(closure) == set(closure0)
    assert [k for k in closure if canonical(closure[k]) != canonical(closure0[k])] == (['plan'] if index else [])
    assert closure['module_roles_in_execution_order'] == list(constants['MODULE_ROLES'])
    assert closure['namespace_count'] == 23 and closure['scoped_group_count'] == 176 and closure['scoped_population_count'] == 10
    assert closure['six_recipes'] == recipes
    assert all(str(p) not in {x['path'] for x in guards} for p in (planpath, closurepath, proposalpath, prep_path))
    assert proposal['schema'] == 'Root-point-frame-once-grant-proposal-v1'
    assert proposal['authorized'] is False and proposal['review_passed'] is False
    assert type(proposal['uses']) is int and proposal['uses'] == 1
    assert proposal['case_id'] == recipes[index]['case_id'] and proposal['plan_sha256'] == item['plan']['sha256']
    assert proposal['plan'] == item['plan'] and proposal['closure'] == item['closure'] and proposal['protocol'] == prep['protocol']
    assert proposal['component_review'] == prep['worker_component_review'] and proposal['additive_bank_review'] == prep['bank_component_review']
    assert proposal['runner_sha256'] == custody['runner']['sha256'] and proposal['observer_sha256'] == custody['observer']['sha256']
    grant = R / 'grants' / (recipes[index]['case_id'] + '.json')
    assert proposal['prospective_grant_path'] == str(grant)
    assert proposal['prospective_command'] == [custody['python']['path'], '-I', '-S', '-B', custody['observer']['path'], str(planpath), str(grant)]
    pdiff = sorted(k for k in proposal0 if canonical(proposal[k]) != canonical(proposal0[k]))
    assert pdiff == (['case_id', 'closure', 'plan', 'plan_sha256', 'prospective_command', 'prospective_grant_path'] if index else [])
    paths = [Path(plan['actual_dir']), Path(plan['actual_dir'] + '.observer'), grant]
    assert all(not p.exists() and not p.is_symlink() for p in paths)
    absences.extend(map(str, paths))
    case_results.append(dict(recipe=item['recipe'], plan=item['plan'], closure=item['closure'], proposal=item['proposal'],
        review_passed=True, plan_delta_keys=delta, closure_delta_keys=['plan'] if index else [], proposal_delta_keys=pdiff,
        checks=[passed('exact-whole-plan-and-phase-association', 'Current shared109/23 roles/176 scopes, complete original target row and all ten caps; no earlier actual/accepting result or prefix is intake.'),
                passed('exact-acyclic-closure-and-reject-only-proposal', 'Exact plan/protocol/closure/component pins and isolated CLI; false authorization flags are technically rejected. No self-hash, final grant, actual or observer directory exists.')],
        absent_paths=list(map(str, paths))))
assert len(absences) == len(set(absences)) == 18
assert [rawpin(x['path']) for x in guards] == before
assert all(not Path(x).exists() and not Path(x).is_symlink() for x in absences)

extra_paths = [B / 'point-frame-worker-Source-handoff-v3.json', B / 'point-frame-worker-API-v3.json',
 B / 'point-frame-worker-dependency-offer-v3.json', B / 'point-frame-worker-manual-conformance-v3.json',
 B / 'point-frame-worker-static-v3.json', B / 'point-frame-worker-v2-v3-bank-carrier.patch',
 B / 'point-frame-worker-v3-v2-bank-carrier.inverse.patch', observation, issuer,
 C / 'typed-point-frame-search-worker-complete-component-Source-review-v1.json',
 C / 'typed-point-frame-target-0-whole-prospective-Source-plan-review-v1.json',
 C / 'typed-full-frame-provider-conclusion-index-complete-Source-review-v4-r2.json',
 C / 'typed-full-frame-point-controller-complete-Source-review-v1.json', component, bankreview]
inputs = [rawpin(p) for p in extra_paths]
inputs.extend(rawpin(p) for p in [census_helper, C / 'typed-constructor-index-six-target-complete-whole-prospective-Source-plan-proposal-review-v1.json', C / 'typed-constructor-index-target-0-complete-negative-actual-review-v1.json'])
assert all(load(p)['review_passed'] is True for p in [component, bankreview, extra_paths[9], extra_paths[10], extra_paths[11], extra_paths[12]])
checks = [
 passed('finite-float-repair-and-consumed-failure-boundary', 'C bank2 Source PASS428c6200 binds exact finite-float copying with unchanged discrete syntax,14 IDs/54 literals/ordinal11/provider4/first-fault behavior. Consumed v2-target0 failed at final evidence copying before target search, all seven positive payloads null; complete C negativeb97991e5 is preserved. Its raw input freeze or earlier diagnostic stages do not qualify this fresh v3 study. Other five v2 cases remain superseded unexecuted. Metadata-only census2 hashes ordinary or opaque-partial bytes, never parses scientific/partial values. No changed production algorithm, expected outcome or resource cap.'),
 passed('complete-current-worker-API-offer-and-Source-delta', 'Current553-line worker3 covered by full inherited worker2 Source plus exact full-byte inverse and reread current version gates; complete current API/dependency/manual/static/handoff and inherited C worker1/whole-v1 plus L worker3 reviews. Exact forward/inverse diffs independently regenerate. Only main changes among8 definitions and exactly its two bank2 VERSION literals differ; seven helpers raw/AST exact. Source-controlled import order differs legitimately from role-map registry order.', (1,553)),
 passed('new-provider-index-and-all176-scoped-populations', 'Provider4 is authenticated by exact bytes/revision/features, retaining reviewed finite universe/identity/order and full Gamma. Original nine vectors/162 attachments are exact; constructor-index14 retains the same14 expectations with bank2 finite diagnostic-float carrier repair, with strict complete/schema/version/population/ordered rows and integer14/14/0 counts. It has54 private predicate cases, not54 separate group qualifications. No old PASS is transferred.', (210,286,329,389)),
 passed('exact-independent-bank-caller-and-input-ownership', 'New bank gets the whole fixed fixture value, unchanged seven declarations, exact tiny oracle/encoder/provider and original checker/builders/reference plus genuine Root check. Five raw JSON inputs are explicitly pinned. Original declarations/raw13/tiny7/new fixtures have canonical before/after checks. The fixed Source-bound eleven-callback fault recipe remains exact for provider4; public positives/white-box limitations remain as C bank receipt.', (221,235,346,389)),
 passed('generic-target-freeze-before-all-controls-and-production', 'One original declaration is independently encoded/parsed and physically frozen inside charged work before any control or target search. Full codec/query bytes/profile/signature/mode/Gamma/goal/EOF association is unchanged. Target receives no fixture, theorem-specific hint/frame/proof/strategy/old accepting state. Fresh mapping and canonical configuration/query guards remain.', (287,328,390,403)),
 passed('whole-current-protocol-and-six-concrete-plans', 'Complete canonical protocol has exact operative schema/experiment/roles/populations/ten caps/six ordered recipes and descriptive-only metadata. All six plans match worker intake, same shared109 file manifest/configuration and empty upstream; only case/index/name/output path differ within the batch. Root builder emitted metadata only, not scientific queries or expected sets.'),
 passed('closed99-guards-acyclic-phase-and-no-old-actual-intake', 'All109 unique sorted ordinary file pins freshly rehashed before/after; every original70 identity retained and39 explicitly added. Current23 modules, custodians/Python/five raw inputs and current protocol/reviews are covered. Older worker/provider/protocol remain raw historical guards only. Plan/closure/proposal/preparation and forthcoming whole review are outside their own guarded list; no old actual/admission/certificate/binary/partial input or recursive citation eligibility.'),
 passed('unchanged-controller-model-and-fairness-scope', 'Current controller and original generic max_rounds=None schedule remain exact. Full model includes lossless query hex/eight decoded fields/exact frame and complete formula-valued marks. EMPTY/SINGLE require complete domains, MANY onlyatleast2, global unresolved barrier, exact parent/actual offer remainder and prefix-refcount reuse are inherited reviewed code. Specialized all-root0/unit rows do not alone qualify generic fractional/shared/generation geometry; unlimited finite-proof coverage is Source-conditional, not fixed-budget fit/nonprovability.', (390,439)),
 passed('same-byte-two-original-validators-then-point-reduction', 'Candidate bytes first bind exact model/frame/row count. The unchanged original subject and independent reference inspect identical immutable query/certificate bytes with their distinct whole gates; only then paired subject parser rows enter point adapter with mutation/no-mismatch/exact row-count checks. Point observation is nonadmitted/nonsearch/non-GCTS. No AST/span auto-normalizer or empirical advantage claim.', (440,476)),
 passed('sticky-first-fault-and-no-positive-prefix-or-late-salvage', 'All control/codec/search/validation/copy/hash/serialization resource checks remain genuine whole callbacks. First Root fault is sticky; worker-origin output limit is latched. Any captured fault nulls all seven positive payloads even after diagnostic stages COMPLETED; physical query/candidate files cannot rescue a prefix. Unexpected intake/write failures fail outer custody closed. No sampled-frame inference or retry is allowed.', (146,182,478,547)),
 passed('complete-cold-costs-and-original-custody-gates', 'Reread all275 runner and213 observer lines. Every hash/import/encoding/control/index/setup/search/check/copy/serialization/output cost is charged. Exact160 work/180 positive/210 custody/225 independent fallback, strict1GiB plus output reserves,48MiB complete result,128MiB aggregate output,4MiB per-stream logs and400million callbacks remain. Post-output/waited-child/parent/observer/EOF/threads/source/physical gates are mandatory; failed header yields null whole peak, not0 or a guessed sum. Native0 is explicitly vacuous, no Native intake.'),
 passed('all-six-proposals-technically-reject-only', 'All six exact proposals keep strict false authorized/review_passed and integer uses1, current per-case plan digest/pin/closure, common protocol/runner/observer/L worker/C bank pins, canonical fresh final-grant path and pinned Python -I -S -B observer CLI. Runner and observer would reject these false bytes. All18 actual/observer/final-grant paths are absent now.'),
 passed('future-Root-grant-composition-and-enforcement-limit', 'Read the separately uninvoked metadata-only issuer. It rehashes accepted prep/reviews, per-case plan/closure/proposal and all109 guards, checks fresh paths, then emits case acceptance/barrier and a distinct true uses1 grant retaining exact operative fields plus whole review/proposal/Root acceptance/idle barrier/timestamp. Its live-idle sentence relies on a fresh Root observation; code does not observe agents. Generic custody enforces only documented booleans/uses/plan/runner subset, not extra schema/path/observer/review/barrier/proposal provenance. Root must bind/check these procedural associations; this receipt issues no grant.'),
 passed('preserved-authoring-negative-and-current-selfpin', 'Read preserved pre-output role-map iteration assertion negative. Current12634-byte builder inherits the exact set equality and changes only new worker/API/offer/output labels plus the explicit repair boundary; emitted closure separately preserves Source MODULE_ROLES. All metadata binds current builder selfpin257a82b5. Zero outputs/science before that assertion; no Source/expectation/cap change or scientific rerun.'),
 passed('complete-prospective-verdict-and-remaining-actual-gates', 'No concrete current whole Source/phase/plan/closure/proposal blocker found. All176 groups/new six cases remain UNRUN. No fit/speed/RL/GCTS benefit forecast. Root acceptance/current rehash/absence/fresh all-tools-idle barrier and distinct one-use grant per case are still required; every subsequent whole actual needs full saved census/resources/custody/control/scientific C review and separate Root disposition. All six original consumed cases remain untouched.')]
result = dict(schema='GCTS-C-constructor-index-six-target-whole-prospective-Source-plan-proposal-review-v2',
 issued_utc=datetime.now(timezone.utc).isoformat(), review_passed=True, whole_prospective_plan_review_passed=True,
 reject_only_proposal_component_review_passed=True, scope='One independent complete current whole Source/phase/protocol/six-plan/closure/false-proposal review. No runtime, admission or execution authority.',
 preparation=rawpin(prep_path), protocol=rawpin(protocol_path), metadata_builder=rawpin(builder), metadata_census_helper=rawpin(census_helper), worker=rawpin(worker_path),
 worker_component_review=prep['worker_component_review'], additive_bank_component_review=prep['bank_component_review'],
 review_program=rawpin(__file__), explicit_supporting_inputs=inputs, checks=checks, failures=[], cases=case_results,
 shared_guard_manifest=dict(plan=prep['cases'][0]['plan'], field='files', count=109, original70_preserved=True,
     added_count=39, ordinary_project_files=108, external_runtime_files=1, all_before_after_rawpins_current=True,
     total_bytes=sum(x['bytes'] for x in guards), canonical_sorted_manifest_sha256=hashlib.sha256(canonical(guards).encode()).hexdigest()),
 module_roles_in_execution_order=list(constants['MODULE_ROLES']), scoped_population_counts={k:v['groups'] for k,v in populations.items()},
 counts=dict(cases=6, plans=6, closures=6, false_proposals=6, guarded_files_each=109, module_roles=23, raw_JSON_inputs=5, scoped_populations=10, scoped_groups=176, currently_absent_paths=18),
 limits=protocol['limits'], search_configuration=first['search_configuration'],
 limitations=['Current176 controls are unrun in this changed-Source study. Original162 retain their exact original subjects; old results supply no qualification.',
 'Constructor14 all8/induction positives are private necessary-shape plus selected builder observations; public positives remain tiny HYP/table/E1, not full-profile membership/EOF equivalence or every callback cutoff.',
 'Source-authenticated trusted modules/canonical inputs are not an adversarial Python sandbox. Atomic builtin latency and large retained receipts have no fit promise.',
 'Provider aggregate elimination counters remain unsupported. No benchmark speed, learned marking/RL, general geometric conformance or strict fixed finite Wang palette claim.',
 'Root fresh live-idle/guard/absence observations and per-case true grants are future procedural duties; this review is not any such observation or authority.'],
 passive_authoring_note='An in-memory C reviewer-authoring replacement asserted a second occurrence after the first replacement had already removed it. It stopped before any file write, Source/Root invocation or mutation; corrected authoring produced this separately named passive Source. No subject or runtime negative was created.', scientific_imports_calls=0, controls_fixtures_queries_certificates_generated_or_run=0, metadata_builder_issuer_or_census_invocations=0,
 actual_bodies_read=0, old_frozen_mutations=0, Root_or_publisher_edits=0, grants_issued=0, actuals_started=0,
 runtime_qualified=False, Root_admission_issued=False, execution_or_publication_authority=False, tools_idle_on_return=True)
for row in guards:
    current(row)
assert rawpin(prep_path)['sha256'] == '8e320def229a248a08609d167446c29a3290b11a2113364160c9d70cc45e6475'
out = C / 'typed-constructor-index-six-target-complete-whole-prospective-Source-plan-proposal-review-v2.json'
with out.open('x') as stream:
    json.dump(result, stream, indent=2, ensure_ascii=True, allow_nan=False)
    stream.write('\n')
print(json.dumps(rawpin(out), sort_keys=True))
