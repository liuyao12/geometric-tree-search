"""C pure stdlib raw/complete saved-JSON failure audit. No subject imports/calls."""
from pathlib import Path
from datetime import datetime, timezone
import ast
import hashlib
import json
import re

BASE = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
S = BASE / 'research-runs/gcts-point-proof-search-20261022'
R, C = S / 'root', S / 'review-C'


def pin(path):
    path = Path(path)
    body = path.read_bytes()
    return {'path': str(path), 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}


def verify(ref):
    assert pin(ref['path']) == {key: ref[key] for key in ('path', 'bytes', 'sha256')}
    return Path(ref['path'])


def load(path):
    assert '.partial' not in Path(path).name
    return json.loads(Path(path).read_bytes())


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode('utf-8')


def equal(a, b):
    return canonical(a) == canonical(b)


def check(identifier, finding):
    return {'id': identifier, 'passed': True, 'finding': finding}


def freeze(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, ensure_ascii=True)
        stream.write('\n')
    return pin(path)


offerpath = R / 'remaining-five-complete-terminal-observations-v1.json'
assert pin(offerpath)['bytes'] == 38047 and pin(offerpath)['sha256'] == '65d2cdb46d02f4dae0e9973166a3dd47b31d0e9fd1d9c6043918d01864ed0541'
offer = load(offerpath)
batchpath = R / 'remaining-five-point-frame-metadata-preparation-v1.json'
batch = load(batchpath)
wholepath = C / 'typed-remaining-five-point-frame-whole-prospective-batch-review-v1.json'
proposalreviewpath = C / 'typed-remaining-five-point-frame-grant-proposal-batch-review-v1.json'
whole, proposalreview = load(wholepath), load(proposalreviewpath)
assert whole['review_passed'] is True and proposalreview['review_passed'] is True
assert pin(wholepath)['sha256'] == 'a102c00be8abbdf237d057f558b1830efa72308ac288a5d1182f7f5683e90c5b'
assert pin(proposalreviewpath)['sha256'] == '21f1578409db64668ec06cfd94f5979d47a706ae5a4c5fc37a7f1e1e93f8bdae'
acceptpath = R / 'remaining-five-prospective-batch-Root-acceptance-v1.json'
accepted = load(acceptpath)
assert accepted['accepted_prospective_metadata'] is True and accepted['cases'] == batch['cases']
assert accepted['whole_batch_review'] == pin(wholepath) and accepted['grant_proposal_batch_review'] == pin(proposalreviewpath)
for key in ('batch', 'whole_batch_review', 'grant_proposal_batch_review', 'L_metadata_review'):
    verify(accepted[key])
issuers = [R / 'prepare_reviewed_point_frame_case_grant_v1.py', R / 'census_completed_point_frame_case_v1.py']
for path in issuers:
    text = path.read_text()
    ast.parse(text)
    compile(text, str(path), 'exec')  # unused only
assert len(offer['cases']) == len(batch['cases']) == 5
assert offer['partials'] == offer['new_proofs'] == offer['scientific_imports_calls_by_summary'] == 0
common = load(verify(batch['parent_plan']))
protocol = load(verify(common['protocol']))
assert len(common['files']) == 70 and len(common['module_pins']) == 22
before = [pin(verify(ref)) for ref in common['files']]
declarations = load(verify(common['declarations']))
assert len(declarations['targets']) == len(protocol['job_recipes']) == 6
expected_sessions = [50759, 74139, 62004, 43139, 58590]
null_keys = ['qualification_result', 'input_freeze', 'search_result', 'subject_receipt', 'reference_receipt', 'point_receipt', 'scientific_result']
stage_names = None
version_fields = None
all_raw = []
reviews = []
previous_census_utc = None
for n, (metadata, observation) in enumerate(zip(batch['cases'], offer['cases']), 1):
    recipe = metadata['recipe']
    assert observation['target_index'] == n and observation['case_id'] == recipe['case_id'] and observation['target_id'] == recipe['target_id']
    case = recipe['case_id']
    planpath = verify(metadata['plan'])
    plan = load(planpath)
    assert equal(plan['files'], common['files']) and equal(plan['module_pins'], common['module_pins'])
    assert equal(plan['control_populations'], common['control_populations']) and equal(plan['limits'], common['limits'])
    assert equal(plan['search_configuration'], common['search_configuration']) and plan['required_upstream_ids'] == []
    assert protocol['job_recipes'][n] == recipe
    closure = load(verify(metadata['closure']))
    assert closure['plan'] == metadata['plan'] and equal(closure['files'], plan['files'])
    proposal = load(verify(metadata['proposal']))
    assert proposal['authorized'] is False and proposal['review_passed'] is False
    actual = Path(plan['actual_dir'])
    observed = Path(str(actual) + '.observer')
    censuspath = verify(observation['raw_census'])
    census = load(censuspath)
    assert census['case_id'] == case and census['exec_session_id'] == expected_sessions[n-1] and census['exec_exit_code'] == 2
    assert len(census['files']) == 12 and all(ref['partial_opaque'] is False for ref in census['files'])
    expected_files = {actual / name for name in ['CONSUMED.json', 'failure.json', 'owned-child.json', 'stderr.bin', 'stdout.bin', 'target-input-freeze.json', 'target-query.bin', 'terminal.json', 'worker-header.json']} | {observed / name for name in ['observer.json', 'stdout.bin', 'stderr.bin']}
    actual_files = set()
    for directory in (actual, observed):
        assert directory.is_dir() and not directory.is_symlink()
        for path in directory.rglob('*'):
            assert not path.is_symlink()
            if path.is_file():
                actual_files.add(path)
    assert actual_files == expected_files == {Path(ref['path']) for ref in census['files']}
    for ref in census['files']:
        verify(ref)
    all_raw.extend(census['files'])
    assert not (actual / 'result.json').exists() and not (actual / 'candidate-certificate.bin').exists()
    failurepath, terminalpath, observerpath = [verify(observation[key]) for key in ['failure', 'terminal', 'observer']]
    headerpath = actual / 'worker-header.json'
    f, h, t, o = [load(path) for path in [failurepath, headerpath, terminalpath, observerpath]]
    owner = load(actual / 'owned-child.json')
    consumed = load(actual / 'CONSUMED.json')
    grantpath = Path(proposal['prospective_grant_path'])
    grant = load(grantpath)
    assert grant['schema'] == 'Root-point-frame-once-grant-v1' and grant['authorized'] is True and grant['review_passed'] is True
    assert type(grant['uses']) is int and grant['uses'] == 1
    assert all(grant[key] == proposal[key] for key in ['uses', 'case_id', 'plan_sha256', 'runner_sha256', 'observer_sha256', 'plan', 'protocol', 'closure', 'component_review'])
    assert grant['whole_review'] == pin(wholepath) and grant['grant_proposal_review'] == pin(proposalreviewpath)
    assert grant['case_proposal'] == metadata['proposal']
    for key in ['plan', 'protocol', 'closure', 'component_review', 'whole_review', 'grant_proposal_review', 'case_proposal', 'Root_prospective_acceptance', 'all_tools_idle_barrier']:
        verify(grant[key])
    case_accept = load(grant['Root_prospective_acceptance']['path'])
    barrier = load(grant['all_tools_idle_barrier']['path'])
    assert case_accept['accepted'] is True and case_accept['case_id'] == barrier['case_id'] == case
    assert case_accept['plan'] == metadata['plan'] and case_accept['closure'] == metadata['closure'] and case_accept['proposal'] == metadata['proposal']
    assert case_accept['whole_review'] == grant['whole_review'] and case_accept['proposal_review'] == grant['grant_proposal_review']
    assert case_accept['Root_batch_acceptance'] == pin(acceptpath) and case_accept['metadata_issuer'] == pin(issuers[0])
    assert barrier['acceptance'] == grant['Root_prospective_acceptance']
    assert barrier['source_checks'] == case_accept['guards_rehashed'] == 70 and barrier['fresh_absence_checks'] == 3
    assert case_accept['namespaces'] == 22 and case_accept['scoped_groups'] == 162 and case_accept['limits_and_generic_configuration_unchanged'] is True
    assert case_accept['issued_utc'] == barrier['issued_utc'] == grant['issued_utc']
    if previous_census_utc is not None:
        assert datetime.fromisoformat(grant['issued_utc']) > datetime.fromisoformat(previous_census_utc)
    previous_census_utc = census['issued_utc']
    assert consumed == {'schema': 'proof-search-case-consumed-v1', 'case_id': case, 'plan_sha256': metadata['plan']['sha256'], 'grant_sha256': pin(grantpath)['sha256'], 'uses': 1}
    assert owner == o['owned_child'] and owner['case_id'] == case and owner['plan_sha256'] == metadata['plan']['sha256']
    assert type(owner['parent_pid']) is int and owner['parent_pid'] > 0 and owner['child_pid'] == owner['child_pgid'] > 0
    assert f['case_id'] == h['case_id'] == t['case_id'] == o['case_id'] == case
    assert f['schema'] == 'FPC-point-frame-whole-worker-v1' and f['status'] == h['status'] == 'FAILED_CASE_NOT_ADMITTED'
    assert f['first_Root_fault'] is h['first_Root_fault'] is True and f['source_unchanged'] is h['source_unchanged'] is t['sources_unchanged'] is True
    assert f['error']['type'] == 'RootBudget' and f['error']['message'] == 'absolute whole-work deadline'
    assert f['error']['traceback'].endswith('RootBudget: absolute whole-work deadline\n')
    assert 'fpc_point_frame_search_worker_v1.py\", line 156, in check' in f['error']['traceback']
    assert all(f[key] is None for key in null_keys) and f['qualification_complete'] is False
    assert f['old_qualification_reused'] is t['old_qualification_reused'] is False
    assert f['guard_compilations'] == f['work_snapshots'] == f['native_queries'] == []
    assert f['native_requests_started'] == f['native_peak_bytes'] == 0
    assert f['native_transport'] == {'all_reaped': True, 'closed': True, 'native_exit_code': 0, 'native_high_water_bytes': 0, 'scope': 'VACUOUS_NO_NATIVE_SUBPROCESS', 'subprocesses_started': 0}
    assert h['native_closed_and_reaped'] is True and h['native_scope'] == 'VACUOUS_NO_NATIVE_SUBPROCESS' and h['native_peak_bytes'] == 0
    assert h['result'] == pin(failurepath) and t['header'] == h
    assert f['callbacks'] == h['callbacks'] == observation['header_callbacks'] < plan['limits']['root_callbacks']
    assert f['elapsed_seconds'] >= plan['limits']['work_seconds'] == 160
    assert f['python_peak_bytes'] <= h['python_peak_after_output_bytes'] <= t['child_usage']['ru_maxrss']
    assert t['process_exit_code'] == o['parent_exit_code'] == census['exec_exit_code'] == 2
    assert t['result'] is None and t['header_valid'] is False
    assert t['conservative_combined_peak_bytes'] is o['conservative_whole_peak_bytes'] is o['final_conservative_whole_peak_bytes'] is observation['qualified_whole_peak_bytes'] is None
    assert o['resource_candidate_before_receipt'] is o['resource_candidate_accepted'] is False
    assert t['threads_terminal'] is t['final_custody_gate_passed'] is True
    assert t['reason'] is o['reason'] is o['fallback_trigger_seconds'] is None and t['errors'] == o['errors'] == []
    assert o['partial_files_parsed'] is False
    assert t['final_custody_gate_seconds'] <= plan['limits']['custody_seconds'] and o['final_observer_gate_seconds'] <= plan['limits']['custody_seconds']
    assert o['known_parent_exit_seconds'] <= o['elapsed_seconds'] <= o['final_observer_gate_seconds']
    assert o['elapsed_seconds'] == observation['whole_observer_elapsed_seconds']
    for packet, directory in [(t, actual), (o, observed)]:
        for label, log in packet['logs'].items():
            assert log['eof'] is True and log['overflow'] is False
            assert log['bytes'] == log['stored'] == (directory / (label + '.bin')).stat().st_size <= plan['limits']['log_bytes']
    assert (actual / 'stderr.bin').read_bytes() == (observed / 'stderr.bin').read_bytes() == b''
    assert equal(load(observed / 'stdout.bin'), t)
    stdout = load(actual / 'stdout.bin')
    assert stdout['case_id'] == case and stdout['status'] == f['status'] and stdout['callbacks'] == h['callbacks']
    assert h['seconds'] <= stdout['seconds']
    assert f['stages'] == observation['stage_log_only_not_qualified_controls']
    assert len(f['stages']) == 32 and all(stage['status'] == 'COMPLETED' for stage in f['stages'][:-1])
    assert f['stages'][-1]['status'] == 'STARTED' and f['stages'][-1]['name'] == 'SEARCH fresh full-FPC point-frame dovetail'
    assert len([stage for stage in f['stages'] if stage['name'].startswith('IMPORT ')]) == 22
    assert len([stage for stage in f['stages'] if stage['name'].startswith('CONTROLS ')]) == 8
    if stage_names is None:
        stage_names = [stage['name'] for stage in f['stages']]
        version_fields = f['component_versions']
    assert [stage['name'] for stage in f['stages']] == stage_names
    assert f['component_versions'] == version_fields and set(version_fields) == set(plan['module_pins'])
    frpath = actual / 'target-input-freeze.json'
    fr = load(frpath)
    literal, codec, decoded = fr['literal_declaration'], fr['codec_receipt'], fr['decoded_query']
    assert fr['schema'] == 'FPC-point-frame-in-job-target-freeze-v1' and fr['target_index'] == n and fr['search_started'] is False
    assert equal(literal, declarations['targets'][n]) and literal['id'] == recipe['target_id']
    assert fr['declaration'] == plan['declarations'] and fr['codec_Source'] == plan['module_pins']['codec']
    querypath = verify(fr['immutable_query'])
    assert querypath == actual / 'target-query.bin'
    assert codec['declaration_canonical_sha256'] == hashlib.sha256(canonical(literal)).hexdigest()
    assert codec['complete'] is True and codec['profile_payload_octets'] == 0
    assert codec['declaration_id'] == literal['id'] and codec['query_identity'] == {key: fr['immutable_query'][key] for key in ('bytes', 'sha256')}
    assert codec['EOF'] == decoded['EOF'] == fr['immutable_query']['bytes']
    assert equal(codec['expanded_goal'], decoded['goal'])
    for left, right, declared in [('query_version', 'version', None), ('mode', 'claim_mode', 'mode'), ('function_arities', 'function_arities', 'function_arities'), ('predicate_arities', 'predicate_arities', 'predicate_arities'), ('profile_id', 'theory_profile', 'profile_id'), ('hypotheses', 'Gamma', 'hypotheses')]:
        assert equal(codec[left], decoded[right])
        if declared is not None:
            assert equal(decoded[right], literal[declared])
    assert decoded['version'] == 1 and decoded['finite_axioms'] == [] and decoded['Gamma'] == []
    assert [binder['id'] for binder in codec['binders']] == literal['binder_order']
    assert [binder['kind'] for binder in codec['binders']] == literal.get('binder_kinds', ['all'] * len(literal['binder_order']))
    if n in (1, 2, 3):
        assert equal(literal['goal_tree'], decoded['goal'])
    byte_fields = decoded['source_fields']
    assert byte_fields[0]['span'][0] == 4 and byte_fields[-1]['span'] == codec['goal_byte_span']
    assert codec['goal_byte_span'][1] == decoded['EOF']
    assert all(0 <= record['query_byte_span'][0] < record['query_byte_span'][1] <= decoded['EOF'] for record in codec['source_map'])
    raw_count = sum(ref['bytes'] for ref in census['files'])
    assert raw_count < plan['limits']['physical_bytes']
    assert t['stored_bytes_before_terminal_receipt'] == sum(ref['bytes'] for ref in census['files'] if Path(ref['path']).parent == actual and Path(ref['path']).name != 'terminal.json')
    assert o['stored_bytes_before_observer_receipt'] == raw_count - pin(observerpath)['bytes']
    traceback_frames = re.findall(r'File "([^"]+)", line (\d+), in ([^\n]+)', f['error']['traceback'])
    checks = [
        check('current-original-plan-Source-phase-configuration', 'All exact 70 guards/22 module pins/six original statements/nine scoped populations/162 ordered groups/ten caps and generic search configuration equal the reviewed plan and remain raw-current. No target0 proof, prior result or qualification was intake.'),
        check('once-grant-batch-reviews-Root-barrier-consumption', 'Strict true one-use grant matches the exact reviewed case proposal/plan/closure/protocol/component and both C batch reviews, fresh Root case acceptance and idle barrier. CONSUMED binds exact plan/grant digests. Root procedural live-idle observation is preserved; generic runner does not enforce its extra review/barrier schema fields.'),
        check('complete-raw-census-ownership-logs-and-cleanup', 'Exactly 12 complete regular non-symlink files match the explicit raw census, with no partial/result/certificate. Owned parent/worker/group matches observer. Worker/parent exit2, awaited child usage, terminal threads and both captured stdout/stderr EOF/no-overflow/errors[] agree with unchanged cleanup Source. No C OS/process probe or claim about unrelated processes.'),
        check('whole-first-deadline-fault-and-fail-closed-resources', 'Sticky first RootBudget absolute whole-work deadline during target SEARCH agrees with worker callback order and >=160-second work clock; cumulative callbacks are below400M. Failed header_valid=false and combined/whole qualified peak null are expected. Observer/resource acceptance false, no fallback/error, bounded custody true. Direct Python/child/parent/observer peaks remain diagnostics, never a reconstructed positive whole bound or memory diagnosis.'),
        check('original-in-job-query-freeze-literal-association', 'Separate pre-search freeze contains exact original declaration and current codec pin, exact immutable query raw identity, complete codec EOF/profile/signature/mode/full empty Gamma/finite table association and parsed-query equality. The PA/core goals compare literally; saved HI conjunction/existential expansions were manually checked against the frozen templates. No query decoding, encoding or semantic AST generation was replayed. This saved prefix is not an admitted input qualification.'),
        check('no-positive-payload-control-prefix-or-theorem-claim', 'All seven positive payloads are null, qualification_complete=false, no candidate/result output. The 22 import, one freeze and eight control wrappers are only COMPLETED stage diagnostics; target SEARCH is STARTED and has no completed receipt/metrics. No control/query/proof prefix is qualified, no finite search exhaustion/nonprovability, allocation culprit, GCTS/RL benefit or retry authority follows.')
    ]
    review = {'schema': 'GCTS-C-point-frame-whole-actual-review-v1', 'issued_utc': datetime.now(timezone.utc).isoformat(), 'review_complete': True, 'negative_classification_supported': True, 'review_passed': False, 'resource_admitted': False, 'scientific_qualified': False, 'stage_complete': False, 'gate_semantics': 'Four false booleans denote failed whole positive qualification; all passive negative-review checks completed successfully.', 'case_id': case, 'target_index': n, 'target_id': recipe['target_id'], 'stage': 'evaluate', 'status': 'FAILED_CASE_NOT_ADMITTED', 'plan': metadata['plan'], 'protocol': plan['protocol'], 'closure': metadata['closure'], 'grant': pin(grantpath), 'case_proposal': metadata['proposal'], 'Root_acceptance': grant['Root_prospective_acceptance'], 'Root_idle_barrier': grant['all_tools_idle_barrier'], 'whole_prospective_batch_review': pin(wholepath), 'grant_proposal_batch_review': pin(proposalreviewpath), 'failure': pin(failurepath), 'result': None, 'header': pin(headerpath), 'terminal': pin(terminalpath), 'observer': pin(observerpath), 'raw_census': pin(censuspath), 'complete_actual_file_census': {'files': census['files'], 'total_bytes': raw_count, 'file_count': 12}, 'input_pins': sorted(plan['files'], key=lambda ref: ref['path']), 'query_freeze_diagnostic_only': pin(frpath), 'query_binary_diagnostic_only': pin(querypath), 'owned_child': owner, 'consumption': pin(actual / 'CONSUMED.json'), 'error': f['error'], 'traceback_frames': [{'path': p, 'line': int(line), 'function': function} for p, line, function in traceback_frames], 'checks': checks, 'review_defects': [], 'failures': [{'type': 'RootBudget', 'message': 'absolute whole-work deadline', 'positive_whole_qualification': False}], 'whole_seconds': o['elapsed_seconds'], 'whole_peak_bytes': None, 'distinct_clocks': {'worker_failure_seconds': f['elapsed_seconds'], 'worker_header_seconds': h['seconds'], 'worker_stdout_seconds': stdout['seconds'], 'parent_known_exit_seconds': t['known_exit_seconds'], 'parent_outer_seconds': t['outer_seconds'], 'final_custody_gate_seconds': t['final_custody_gate_seconds'], 'observer_known_parent_exit_seconds': o['known_parent_exit_seconds'], 'observer_elapsed_seconds': o['elapsed_seconds'], 'final_observer_gate_seconds': o['final_observer_gate_seconds']}, 'direct_diagnostic_memory_samples_only': {'worker_failure_python_peak_bytes': f['python_peak_bytes'], 'worker_post_output_peak_bytes': h['python_peak_after_output_bytes'], 'waited_child_peak_bytes': t['child_usage']['ru_maxrss'], 'parent_peak_bytes': t['parent_usage']['ru_maxrss'], 'observer_peak_bytes': o['final_observer_peak_bytes']}, 'callbacks': f['callbacks'], 'positive_payload_fields': {key: f[key] for key in null_keys}, 'qualification_complete': False, 'stage_log_diagnostic_only': f['stages'], 'saved_literal_input_scope': {'target_id': literal['id'], 'goal_latex': literal['goal_latex'], 'query_bytes': fr['immutable_query']['bytes'], 'profile_id': decoded['theory_profile'], 'binder_order': literal['binder_order'], 'empty_Gamma': True, 'admitted': False}, 'exec_session_id': census['exec_session_id'], 'exec_exit_code': 2, 'Root_terminal_offer': pin(offerpath), 'metadata_issuance_Source': pin(issuers[0]), 'raw_census_Source': pin(issuers[1]), 'review_program': pin(__file__), 'partial_files_parsed': 0, 'scientific_imports_calls_outside_actual_by_C': 0, 'Root_admission_issued': False, 'no_prefix_salvage': True, 'retry_authority': False, 'publication_authority': False, 'tools_idle_on_return': True}
    reviews.append(review)

assert len(all_raw) == len({ref['path'] for ref in all_raw}) == 60
assert [pin(verify(ref)) for ref in common['files']] == before
for ref in all_raw:
    verify(ref)
pins = []
for review in reviews:
    path = C / ('typed-point-frame-target-' + str(review['target_index']) + '-complete-negative-actual-review-v1.json')
    receipt = freeze(path, review)
    pins.append({'case_id': review['case_id'], 'target_index': review['target_index'], 'target_id': review['target_id'], 'review': receipt, 'whole_seconds': review['whole_seconds'], 'whole_peak_bytes': None, 'callbacks': review['callbacks'], 'physical_bytes': review['complete_actual_file_census']['total_bytes'], 'negative_classification_supported': True, 'four_positive_gates': False})
batch_review = {'schema': 'GCTS-C-point-frame-remaining-five-complete-negative-actual-batch-review-v1', 'issued_utc': datetime.now(timezone.utc).isoformat(), 'review_complete': True, 'negative_classification_supported': True, 'positive_jobs_admitted': 0, 'failed_whole_jobs': 5, 'Root_terminal_offer': pin(offerpath), 'whole_prospective_batch_review': pin(wholepath), 'proposal_batch_review': pin(proposalreviewpath), 'Root_batch_acceptance': pin(acceptpath), 'review_program': pin(__file__), 'metadata_issuer_Source': pin(issuers[0]), 'raw_census_Source': pin(issuers[1]), 'cases': pins, 'counts': {'complete_raw_files': 60, 'physical_bytes': sum(ref['bytes'] for ref in all_raw), 'partial_files': 0, 'current_shared_guards': 70, 'module_namespaces': 22, 'original_targets': 6, 'scoped_control_groups_per_unqualified_job': 162, 'new_proofs': 0}, 'checks': [check('five-complete-current-negative-reviews', 'All five original plans, grants/consumptions and twelve-file terminal packets reviewed independently; each has six complete negative findings and four false qualification gates.'), check('source-currentness-and-serial-provenance', 'All seventy shared guards verified before/after; each distinct grant has fresh case acceptance/barrier and review bindings. Issuance of each following grant is after the preceding complete terminal census, consistent with the declared serial window; no C runtime probe.'), check('null-qualified-peak-and-no-prefix-boundaries', 'All five remain work-deadline failures with null qualified peak and null positive payloads. Diagnostic in-job freezes/stage completions are preserved without qualification, exhaustion/nonprovability or memory/advantage claim.')], 'review_defects': [], 'scientific_imports_calls_outside_actual_by_C': 0, 'partial_files_parsed': 0, 'Root_admissions_issued_by_C': 0, 'next_authority': 'Root may separately issue exact whole-negative dispositions. No positive helper, retry, new actual, changed Source/cap or publication authority.', 'tools_idle_on_return': True}
indexpin = freeze(C / 'typed-remaining-five-point-frame-complete-negative-actual-batch-review-v1.json', batch_review)
print(json.dumps({'batch': indexpin, 'per_case': pins}, sort_keys=True))
