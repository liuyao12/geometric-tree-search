"""C saved-JSON/raw audit only. No research module imports or semantic replay."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import math
import stat

BASE=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
S=BASE/'research-runs/gcts-point-proof-search-20261022'
R,C=S/'root',S/'review-C'

def load(path):
 p=Path(path);assert '.partial' not in p.name
 return json.loads(p.read_bytes())
def canonical(v):return json.dumps(v,sort_keys=True,ensure_ascii=True,allow_nan=False,separators=(',',':'))
def identity(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def pin(path):
 p=Path(path);assert p.is_absolute() and p.resolve()==p and not p.is_symlink() and p.is_file()
 return dict(path=str(p),**identity(p.read_bytes()))
def verify(row):assert pin(row['path'])=={k:row[k] for k in ('path','bytes','sha256')}
def walk(value):
 pending=[('$',value)]
 while pending:
  path,item=pending.pop();yield path,item
  if isinstance(item,dict):pending.extend((path+'.'+str(k),v) for k,v in item.items())
  elif isinstance(item,list):pending.extend((path+'['+str(i)+']',v) for i,v in enumerate(item))
def subset(expected,observed):
 if isinstance(expected,dict):
  assert isinstance(observed,dict)
  for k,v in expected.items():subset(v,observed[k])
 else:assert canonical(expected)==canonical(observed)
def check(n,t):return dict(check=n,passed=True,finding=t)
def freeze(path,value):
 with path.open('x') as f:json.dump(value,f,indent=2,ensure_ascii=True,allow_nan=False);f.write('\n')
 return pin(path)

def positive_audit(result,plan,ACTUAL):
    qualification = result["qualification_result"]
    assert result["qualification_complete"] is True
    ledger = []
    populations = dict(qualification)
    explicit = populations.pop("explicit16")
    populations["point-kernel13"] = explicit["raw_population"]
    populations["point-kernel-safety3"] = explicit["additional_population"]
    assert set(populations) == set(plan["control_populations"])
    for name, spec in plan["control_populations"].items():
        packet = populations[name]
        assert packet["control_ids"] == spec["control_ids"]
        assert [r["id"] for r in packet["controls"]] == spec["control_ids"]
        assert packet["counts"]["passed"] == spec["groups"]
        assert packet["counts"]["failed"] == 0
        for row in packet["controls"]:
            assert row.get("passed") is True or row.get("status") == "PASSED"
            ledger.append(dict(population=name, id=row["id"],
                               complete_saved_row_sha256=hashlib.sha256(canonical(row).encode()).hexdigest()))
    assert len(ledger) == 176 and len({(x["population"], x["id"]) for x in ledger}) == 176
    assert all(p["complete"] is True for p in qualification.values())

    literal_pairs = guard_subsets = fault_fields = byte_pairs = 0
    subjects, references, paired_validators = [], [], []
    for path, item in walk(result):
        if not isinstance(item, dict):
            continue
        if "expected" in item and "observed" in item and type(item["expected"]) is type(item["observed"]):
            assert canonical(item["expected"]) == canonical(item["observed"])
            literal_pairs += 1
        for key in ("identity_preserved", "same_exception_identity", "same_object", "identical",
                    "exception_attributes_unchanged", "args_and_attributes_unchanged", "input_unchanged",
                    "exception_args_attributes_unchanged"):
            if key in item:
                assert item[key] is True, (path, key)
                fault_fields += 1
        for key in ("returned_point_or_proof_prefix", "candidate_or_prefix_admitted", "normal_prefix",
                    "faulted_state_resumed"):
            if key in item:
                assert item[key] is False, (path, key)
        if item.get("schema") == "FPC-H1-finite-byte-check-receipt-v1":
            assert item["status"] == "VALID_DERIVATION"
            for key in ("accepted", "complete", "syntax_complete", "derivation_complete", "no_prefix_authority", "final_goal_equal"):
                assert item[key] is True
            cert = item["certificate"]
            assert cert["row_count"] == len(cert["rows"])
            assert cert["EOF"] == item["raw_inputs"]["certificate"]["bytes"]
            assert item["query"]["EOF"] == item["raw_inputs"]["query"]["bytes"]
            for i, row in enumerate(cert["rows"]):
                assert row["index"] == i and row["validation"]["status"] == "VALID"
                assert all(x["passed"] is True for x in row["validation"]["side_conditions"])
                assert all(type(j) is int and 0 <= j < i for j in row["validation"]["references"])
            subjects.append((path, cert["row_count"]))
        if item.get("schema") == "FPC-H1-independent-flat-reference-v2":
            assert item["status"] == "VALID_DERIVATION"
            assert item["complete_check"] is item["final_goal_equal"] is True
            references.append((path, len(item["rows"])))
        a, b = item.get("subject"), item.get("reference")
        if isinstance(a, dict) and isinstance(b, dict) and a.get("schema") == "FPC-H1-finite-byte-check-receipt-v1" and b.get("schema") == "FPC-H1-independent-flat-reference-v2":
            assert len(a["certificate"]["rows"]) == len(b["rows"])
            paired_validators.append(path)
            for label in ("query", "certificate"):
                if label + "_hex" in item:
                    raw = bytes.fromhex(item[label + "_hex"])
                    assert identity(raw) == item[label]
                    assert identity(raw) == a["raw_inputs"][label]
                    byte_pairs += 1

    for row in populations["obligation47"]["controls"]:
        e = row["evidence"]
        if row["id"].startswith("guard-"):
            subset(e["expected"], e["receipt"])
            guard_subsets += 1
        if row["id"].startswith("refuse-"):
            assert e["expected"] == "OWNED_ProducerInputError"
            assert e["observed"]["class"] == "ProducerInputError"
    for row in populations["baseline56"]["controls"]:
        e = row["evidence"]
        if "expected_known" in e:
            assert {canonical(v) for v in e["expected_known"]} == {canonical(v["formula"]) for v in e["receipt"]["known"]}
        if "expected_hex" in e:
            assert identity(bytes.fromhex(e["expected_hex"])) == e["receipt"]["query_identity"]

    tiny = populations["tiny-full-provider10"]
    assert [r["expected_count"] for r in tiny["controls"][:7]] == [4, 8, 4, 1, 0, 2, 0]
    fields = ("formula", "m", "references", "rule_tag", "subtag", "t", "witness")
    for row in tiny["controls"][:7]:
        members, expected = row["members"], row["oracle"]["members"]
        assert len(members) == len(expected) == row["expected_count"]
        assert {canonical({k: m[k] for k in fields}) for m in members} == {canonical(m) for m in expected}
        assert len({canonical(m["key"]) for m in members}) == len(members)
        d = row["classification"]
        if row["expected_count"] < 2:
            assert d["coverage_complete"] is True and d["counts"]["fallback_eof_events"] >= 1
            assert d["kind"] == ("EMPTY" if not members else "SINGLE")
        else:
            assert d["kind"] == "MANY" and len(d["witnesses"]) == 2
        for m in members:
            key = m["key"]
            assert len(key) == 8 and key[0] == "FPC-point-ground-key-v1"
            assert key[3:6] == [m["rule_tag"], m["subtag"], m["witness"]]
            assert key[6:] == [m["t"], m["m"]]

    kernel_solutions = 0
    controller_traces = 0
    for _, item in walk(qualification):
        if not isinstance(item, dict):
            continue
        a, b = item.get("oracle"), item.get("kernel")
        if isinstance(a, dict) and isinstance(b, dict) and "solution_subsets" in a:
            assert a["complete"] is b["complete"] is True
            assert {canonical(sorted(x)) for x in a["solution_subsets"]} == {canonical(sorted(x)) for x in b["solution_subsets"]}
            assert item["entry_restored"] is True
            kernel_solutions += 1
        if item.get("kind") == "DECISION" and "all_unfilled" in item:
            if item["status"] in ("FORCED", "BRANCH"):
                assert not any(r["kind"] in ("EMPTY", "UNRESOLVED") for r in item["all_unfilled"])
            if item["status"] == "BRANCH":
                assert not any(r["kind"] == "SINGLE" for r in item["all_unfilled"])
            controller_traces += 1
        if item.get("kind") == "REJECT":
            assert item["reason"] in ("CHILD_DEAD", "CHILD_EXHAUSTED")

    ctrl = populations["full-frame-controller10"]["controls"]
    fuel64 = ctrl[4]["facets"][-1]
    assert fuel64["fuel"] == 64 and fuel64["terminal"]["phase"] == "CLASSIFY_ADVANCE"
    assert fuel64["terminal"]["outstanding_offers"] == 1 and fuel64["metrics"]["reject_offers"] == 0
    assert len(ctrl[5]["recipes"]) == 11 and ctrl[5]["recipes"][-1]["later_cleanup_F_exercised"] is True
    real = ctrl[6]["cases"][-1]
    assert real["fixture"] == "controller-only-E1-two-row-reuse"
    assert real["oracle"]["solution_count"] == 4
    assert real["metrics"]["classifier_opens"] == 2 and real["metrics"]["classifiers_rebound"] == 1
    trace = real["reuse_trace"]
    selected = [e for e in trace if e["kind"] == "SELECT"]
    assert [e["row"] for e in selected] == [1, 0]
    first = selected[0]
    assert first["forced"] is True and first["from_offer"] is False and selected[1]["from_offer"] is True
    assert any(e["kind"] == "REUSE" and e["row"] == 0 and e["from_state_serial"] == first["parent_serial"] and e["state_serial"] == first["child_serial"] for e in trace)

    frozen = result["input_freeze"]
    assert frozen == load(ACTUAL / "target-input-freeze.json")
    query_raw = (ACTUAL / "target-query.bin").read_bytes()
    cert_raw = (ACTUAL / "candidate-certificate.bin").read_bytes()
    assert frozen["immutable_query"] == pin(ACTUAL / "target-query.bin")
    declarations = load(plan["declarations"]["path"])
    assert frozen["literal_declaration"] == declarations["targets"][0]
    assert frozen["search_started"] is False and frozen["target_index"] == 0
    assert frozen["decoded_query"] == result["subject_receipt"]["query"]
    assert frozen["codec_receipt"]["expanded_goal"] == frozen["decoded_query"]["goal"]
    assert frozen["codec_receipt"]["query_identity"] == identity(query_raw)
    search = result["search_result"]
    assert bytes.fromhex(search["candidate_certificate_hex"]) == cert_raw
    assert search["accepted"] is False and search["status"] == "CANDIDATE"
    assert search["export_receipt"]["model"]["query_hex"] == query_raw.hex()
    assert search["export_receipt"]["model"]["frame"] == search["last_frame"]["frame"]
    assert search["export_receipt"]["accepted"] is False
    assert search["export_receipt"]["exact_rows"] == 3
    subject = result["subject_receipt"]
    assert subject["raw_inputs"] == dict(query=identity(query_raw), certificate=identity(cert_raw))
    assert [r["formula"] for r in subject["certificate"]["rows"]] == [r["formula"] for r in search["export_receipt"]["rows"]]
    assert [r["witness"] for r in subject["certificate"]["rows"]] == [r["witness"] for r in search["export_receipt"]["rows"]]
    assert [r["rule_tag"] for r in subject["certificate"]["rows"]] == [1, 1, 4]
    assert subject["certificate"]["rows"][2]["witness"] == [0, 0]
    point = result["point_receipt"]
    assert point["complete"] is point["point_compatible"] is True and point["mismatches"] == []
    assert point["proof_admitted"] is point["search_engine"] is point["GCTS_conformance"] is False
    assert point["row_count"] == 3 and [x[1] for x in point["t_totals"]] == [1, 1, 1]
    assert [t["conclusion"] for t in point["tiles"]] == [x["formula"] for x in subject["certificate"]["rows"]]
    m = search["metrics"]
    assert (m["frame_runs"], m["frame_atomic_steps"], m["sum_frame_limits"]) == (97, 7380, 32497)
    assert m["frames_exhausted"] + m["frames_fuel_limited"] + 1 == m["frame_runs"]
    assert search["last_frame"] == dict(round=14, pair_index=6,
        frame=dict(schema="FPC-point-frame-v1", rows=3, syntax_nodes=4),
        max_steps=256, status="CANDIDATE", atomic_steps=228)

    fixture_data=load(plan['conclusion_index_fixtures']['path'])
    constructor=populations['constructor-index14']
    assert constructor['version']=='L-conclusion-index-independent-controls-v2'
    assert constructor['complete'] is True and constructor['counts']==dict(groups=14,passed=14,failed=0)
    shape_count=builder_count=0
    builder_totals={'EQUAL_HINT':0,'DIFFERENT_HINT':0,'REFUSED':0}
    for declared,saved in zip(fixture_data['groups'][:10],constructor['controls'][:10],strict=True):
        assert declared['id']==saved['id'] and saved['population']=='constructor-index14' and saved['status']=='PASSED'
        evidence=saved['evidence'];assert evidence['predicate_scope']=='WHITE_BOX_COMPONENT'
        assert evidence['full_inventory_or_profile_qualification'] is False
        for expected,observed in zip(declared['cases'],evidence['cases'],strict=True):
            assert expected['id']==observed['id']
            assert type(observed['expected_shape']) is bool and type(observed['observed_shape']) is bool
            assert observed['expected_shape'] is observed['observed_shape'] is expected['shape']
            assert observed['helper_callbacks']>0
            shape_count+=1
            if 'builder_result' in expected:
                assert observed['builder_observation']==expected['builder_result']
                builder_count+=1;builder_totals[observed['builder_observation']]+=1
    assert shape_count==54 and builder_count==18
    assert builder_totals=={'EQUAL_HINT':11,'DIFFERENT_HINT':4,'REFUSED':3}
    helper=constructor['controls'][10]['evidence']
    assert helper['inventory_poison_tested'] is False
    assert [(x['id'],x['trip'],x['helper_callbacks'],x['same_exception_object']) for x in helper['recipes']]==[('RuntimeError-entry',1,1,True),('StopIteration-entry',1,1,True),('public-refusal-entry',1,1,True),('StopIteration-third-tick-prefix',3,3,True)]
    faults=constructor['controls'][11]['evidence']['recipes']
    assert [x['id'] for x in faults]==['RuntimeError','StopIteration','public-unowned-refusal','retained-genuine-owned-refusal']
    for x in faults:
        assert x['source_local_callback_ordinal']==11 and x['subsequent_provider_callbacks']==0
        assert x['all_five_poison_operations_same_object'] is x['intended_fault_observed_identically'] is x['error_args_and_attributes_preserved'] is True
        assert x['cleanup_memory_reclamation_observed'] is False
        snap=x['prefault_public_snapshot'];raw=snap['inspection_frontier']['raw']
        assert snap['kind']=='CLASSIFICATION' and snap['phase']=='RAW' and snap['point']==[0,0]
        assert raw['family']==1 and raw['phase']=='NORMALIZE' and raw['raw_index']==0 and raw['product'] is None
    fixed=constructor['controls'][12]['evidence']['fixtures']
    assert [(x['id'],x['expected_count']) for x in fixed]==[('duplicate-base',4),('E1-single',1)]
    for x in fixed:
        records=x['records_in_observed_order'];oracle=x['oracle']['members']
        assert len(records)==len(oracle)==x['expected_count']
        assert {canonical({k:r[k] for k in fields}) for r in records}=={canonical(r) for r in oracle}
        assert len({canonical(r['key']) for r in records})==len(records)
        for rec in records:
            assert rec['key'][0]=='FPC-point-ground-key-v1' and len(rec['key'])==8
            assert rec['key'][2]==['ROW',0] and rec['key'][3:]==[rec['rule_tag'],rec['subtag'],rec['witness'],rec['t'],rec['m']]
    assert [[r['rule_tag'],r['subtag'],r['witness']] for r in fixed[0]['records_in_observed_order']]==[[0,None,0],[0,None,1],[2,0,0],[2,0,1]]
    assert fixed[0]['initial_classification']['kind']=='MANY' and fixed[0]['initial_classification']['coverage_complete'] is False
    assert fixed[0]['export_or_enumeration']['scope']=='LOW_LEVEL_COMPLETE_POSITIVE_LEAF_ENUMERATION_NOT_UNSAT'
    single=fixed[1];assert single['initial_classification']['kind']=='SINGLE' and single['initial_classification']['coverage_complete'] is True
    ev=single['export_or_enumeration'];assert ev['certificate_identity']==ev['subject']['raw_inputs']['certificate']
    elapsed=ev['subject']['cost']['elapsed_seconds'];assert type(elapsed) is float and math.isfinite(elapsed) and elapsed>=0
    empty=constructor['controls'][13]['evidence'];assert empty['fixture']==fixture_data['public_empty_fixture']
    assert empty['classification']['kind']=='EMPTY' and empty['classification']['coverage_complete'] is True
    assert empty['classification']['counts']['raw_tuples_complete']==0 and empty['raw_frontier']['eof'] is True
    assert [x['subtag'] for x in empty['raw_frontier']['skipped_families'] if x['reason']=='INCOMPATIBLE_ASSIGNED_OUTPUT_CONSTRUCTOR_SHAPE']==[0,3,5]
    for path,item in walk(result):
        if type(item) is float:assert math.isfinite(item),path
    assert result['scientific_result']['same_immutable_inputs_to_both_validators'] is True
    assert result['scientific_result']['status']=='FOUND_VALID_PENDING_ROOT_WHOLE_ADMISSION'
    return dict(control_row_digest_ledger=ledger,complete_scoped_rows=len(ledger),literal_pairs=literal_pairs,guard_subsets=guard_subsets,fault_identity_fields=fault_fields,
        subject_receipt_occurrences=len(subjects),subject_rows=sum(n for _,n in subjects),reference_receipt_occurrences=len(references),paired_validators=len(paired_validators),hex_raw_joins=byte_pairs,
        kernel_oracle_pairs=kernel_solutions,controller_decisions=controller_traces,constructor_literal_cases=shape_count,constructor_selected_builder_observations=builder_totals,
        constructor_helper_faults=4,constructor_public_faults=4,constructor_later_poison_operations=20,constructor_diagnostic_float=elapsed,
        query=identity(query_raw),certificate=identity(cert_raw),search_metrics=m,last_frame=search['last_frame'],point_rows=point['row_count'])


prep_path=R/'constructor-index-study-preparation-v2.json'
prep=load(prep_path)
assert pin(prep_path)['sha256']=='8e320def229a248a08609d167446c29a3290b11a2113364160c9d70cc45e6475'
whole_path=C/'typed-constructor-index-six-target-complete-whole-prospective-Source-plan-proposal-review-v2.json'
assert pin(whole_path)['sha256']=='d3061e59faf2dec469dedec33ee4c6b03a603babe5bf9b36aea125470f4c89ca'
whole=load(whole_path)
assert whole['review_passed'] is True and whole['counts']['guarded_files_each']==109
clarification=C/'constructor-index-whole-review-v2-check-identifier-clarification-v1.json'
assert pin(clarification)['sha256']=='88bc7b5b474b5db6fc136c20fc76fb8a7d3e93c6b8effff7e9474329ca1211d0'
owned_path=R/'constructor-index-v3-six-owned-process-terminal-observation-v1.json'
owned=load(owned_path)
assert len(owned['cases'])==6
first=load(prep['cases'][0]['plan']['path'])
guards=first['files']
assert len(guards)==len({x['path'] for x in guards})==109
assert guards==sorted(guards,key=lambda x:x['path'])
for x in guards:verify(x)
before=[pin(x['path']) for x in guards]
protocol=load(first['protocol']['path'])
assert first['protocol']==prep['protocol'] and first['module_pins']==protocol['module_pins']
assert first['control_populations']==protocol['control_populations'] and len(first['module_pins'])==23
assert len(first['control_populations'])==10 and sum(x['groups'] for x in first['control_populations'].values())==176
assert first['limits']==protocol['limits'] and len(first['limits'])==10
assert all(x in guards for x in load(R/'plans/point-frame-full-FPC-v1-target-0.json')['files'])
limits=first['limits']
sessions=[95005,48167,79156,99546,37048,22186]
direct_clocks=[10.267159999988507,160.46307937501115,160.20607174999896,160.25010483301594,160.1684541659779,160.16252187499776]
negative_callbacks=[206799385,219434430,213730479,209103901,218780934]
positive_keys=['qualification_result','input_freeze','search_result','subject_receipt','reference_receipt','point_receipt','scientific_result']
case_receipts=[]
total_physical=0
ledger_pin=None
for index,row in enumerate(prep['cases']):
    for key in ('plan','closure','proposal'):verify(row[key])
    plan,closure,proposal=[load(row[k]['path']) for k in ('plan','closure','proposal')]
    case=plan['case_id'];actual=S/'actual'/case;obs=Path(str(actual)+'.observer')
    assert case=='point-frame-constructor-index-v3-target-'+str(index)
    assert plan['experiment']=='point-frame-constructor-index-v3' and plan['target_index']==index
    assert plan['files']==guards and plan['required_upstream_ids']==[] and plan['stage']=='evaluate'
    assert plan['search_configuration']==first['search_configuration'] and plan['limits']==limits
    assert closure['plan']==row['plan'] and closure['files']==guards and closure['protocol']==prep['protocol']
    grant_path=R/'grants'/(case+'.json');grant=load(grant_path)
    assert grant['authorized'] is True and grant['review_passed'] is True and type(grant['uses']) is int and grant['uses']==1
    assert grant['schema']=='Root-point-frame-once-grant-v1' and grant['case_id']==case
    assert grant['plan']==row['plan'] and grant['plan_sha256']==row['plan']['sha256']
    assert grant['protocol']==prep['protocol'] and grant['closure']==row['closure'] and grant['case_proposal']==row['proposal']
    assert grant['whole_review']==pin(whole_path)
    for key in ('plan','protocol','closure','component_review','additive_bank_review','whole_review','case_proposal','Root_prospective_acceptance','all_tools_idle_barrier'):verify(grant[key])
    assert grant['component_review']==prep['worker_component_review'] and grant['additive_bank_review']==prep['bank_component_review']
    assert grant['runner_sha256']==pin(plan['runner_path'])['sha256']
    assert grant['observer_sha256']=='24804c7d4558d8df511942d9e6b2e4d8d2cfd88ce7df6f5b5f775f87d0c20ca9'
    accept=load(grant['Root_prospective_acceptance']['path']);barrier=load(grant['all_tools_idle_barrier']['path'])
    assert accept['accepted'] is True and accept['plan']==row['plan'] and accept['closure']==row['closure'] and accept['proposal']==row['proposal']
    assert accept['whole_review']==grant['whole_review'] and accept['guards_current']==109
    assert barrier['acceptance']==grant['Root_prospective_acceptance'] and barrier['guards_rehashed']==109 and barrier['fresh_absence_checks']==3
    verify(accept['Root_batch_acceptance']);verify(accept['metadata_issuer'])
    batchaccept=load(accept['Root_batch_acceptance']['path'])
    assert batchaccept['preparation']==pin(prep_path) and batchaccept['whole_review']==pin(whole_path)
    consumed=load(actual/'CONSUMED.json')
    assert consumed==dict(schema='proof-search-case-consumed-v1',case_id=case,uses=1,plan_sha256=row['plan']['sha256'],grant_sha256=pin(grant_path)['sha256'])
    census_path=R/('constructor-index-target-'+str(index)+'-first-terminal-raw-census-v2.json');census=load(census_path)
    assert census['case_id']==case and census['exec_session_id']==sessions[index] and census['exec_exit_code']==(0 if index==0 else 2)
    physical=[]
    for folder in (actual,obs):
        assert folder.is_dir() and not folder.is_symlink() and folder.resolve()==folder
        for p in sorted(folder.rglob('*')):
            assert not p.is_symlink() and stat.S_ISREG(p.stat().st_mode)
            physical.append(dict(pin(p),partial_opaque='.partial' in p.name))
    assert physical==census['files'] and len(physical)==(13 if index==0 else 12)
    assert all(x['partial_opaque'] is False for x in physical)
    physical_bytes=sum(x['bytes'] for x in physical);total_physical+=physical_bytes
    assert physical_bytes<=limits['physical_bytes']
    bodypath=actual/('result.json' if index==0 else 'failure.json')
    result=load(bodypath);header=load(actual/'worker-header.json');terminal=load(actual/'terminal.json');observer=load(obs/'observer.json');owner=load(actual/'owned-child.json')
    assert result['case_id']==header['case_id']==terminal['case_id']==observer['case_id']==case
    assert result['worker_version']=='FPC-full-frame-point-worker-v3' and result['source_unchanged'] is header['source_unchanged'] is terminal['sources_unchanged'] is True
    assert result['schema']=='FPC-point-frame-whole-worker-v1' and result['stage']=='evaluate'
    assert result['old_qualification_reused'] is terminal['old_qualification_reused'] is False
    assert set(result['component_versions'])==set(plan['module_pins']) and result['component_versions']['conclusion_index_bank']=='L-conclusion-index-independent-controls-v2'
    assert header['result']==pin(bodypath) and terminal['header']==header and load(obs/'stdout.bin')==terminal
    assert terminal['process_exit_code']==observer['parent_exit_code']==(0 if index==0 else 2)
    assert terminal['reason'] is observer['reason'] is None and terminal['errors']==observer['errors']==[]
    assert terminal['threads_terminal'] is terminal['final_custody_gate_passed'] is True
    assert observer['fallback_trigger_seconds'] is None and observer['partial_files_parsed'] is False
    assert terminal['known_exit_seconds']<=limits['positive_seconds'] and terminal['final_custody_gate_seconds']<=limits['custody_seconds']
    assert observer['known_parent_exit_seconds']<=limits['custody_seconds'] and observer['final_observer_gate_seconds']<=limits['custody_seconds']
    assert observer['elapsed_seconds']==direct_clocks[index]
    for folder,logs,cap in ((actual,terminal['logs'],limits['log_bytes']),(obs,observer['logs'],1048576)):
        for name,x in logs.items():
            assert x['eof'] is True and x['overflow'] is False
            assert x['bytes']==x['stored']==pin(folder/(name+'.bin'))['bytes']<=cap
    assert (actual/'stderr.bin').read_bytes()==(obs/'stderr.bin').read_bytes()==b''
    stdout=load(actual/'stdout.bin');assert stdout['case_id']==case and stdout['status']==header['status'] and stdout['callbacks']==header['callbacks']
    assert owner==observer['owned_child'] and owner['plan_sha256']==row['plan']['sha256'] and owner['case_id']==case
    owned_row=owned['cases'][index];assert owned_row['case_id']==case and owned_row['owned_record']==pin(actual/'owned-child.json')
    assert owned_row['processes']==[dict(pid=owner['parent_pid'],absent=True),dict(pid=owner['child_pid'],absent=True)]
    assert owned_row['group']==owner['child_pgid']==owner['child_pid'] and owned_row['group_absent'] is True
    assert result['native_peak_bytes']==result['native_requests_started']==header['native_peak_bytes']==0
    assert result['native_queries']==result['guard_compilations']==result['work_snapshots']==[]
    assert header['native_closed_and_reaped'] is True and header['native_scope']=='VACUOUS_NO_NATIVE_SUBPROCESS'
    assert result['native_transport']==dict(closed=True,all_reaped=True,native_exit_code=0,native_high_water_bytes=0,subprocesses_started=0,scope='VACUOUS_NO_NATIVE_SUBPROCESS')
    frozen=load(actual/'target-input-freeze.json');querypin=pin(actual/'target-query.bin')
    declaration=load(plan['declarations']['path'])['targets'][index]
    assert frozen['literal_declaration']==declaration and frozen['declaration']==plan['declarations'] and frozen['target_index']==index and frozen['search_started'] is False
    assert frozen['immutable_query']==querypin and frozen['codec_Source']==plan['module_pins']['codec']
    q,co=frozen['decoded_query'],frozen['codec_receipt']
    assert q['EOF']==co['EOF']==querypin['bytes'] and co['query_identity']=={k:querypin[k] for k in ('bytes','sha256')}
    assert q['claim_mode']==declaration['mode']==co['mode'] and q['theory_profile']==declaration['profile_id']==co['profile_id']
    assert canonical(q['function_arities'])==canonical(co['function_arities'])==canonical(declaration['function_arities'])
    assert canonical(q['predicate_arities'])==canonical(co['predicate_arities'])==canonical(declaration['predicate_arities'])
    assert canonical(q['Gamma'])==canonical(co['hypotheses'])==canonical(declaration['hypotheses']) and q['finite_axioms']==[]
    assert canonical(q['goal'])==canonical(co['expanded_goal']) and co['complete'] is True and co['declaration_id']==declaration['id']
    stage_names=[x['name'] for x in result['stages']]
    assert stage_names[:23]==['IMPORT '+x for x in whole['module_roles_in_execution_order']]
    assert stage_names[23]=='FREEZE independent target before controls/search'
    assert stage_names[24:33]==['CONTROLS '+x for x in ('baseline56','obligation47','intro_integration1','regression2','point20','explicit-point16','tiny-full-provider10','full-frame-controller10','constructor-index14')]
    qualified=index==0
    detail=None
    if qualified:
        assert pin(bodypath)['sha256']=='22151d5ca5267d94f6d47dbaa2d490e4e215f653a1003700a749b7fa45f08b8b'
        assert result['status']==header['status']=='COMPLETE' and result['error'] is None
        assert result['first_Root_fault'] is header['first_Root_fault'] is False
        assert result['qualification_complete'] is terminal['header_valid'] is observer['resource_candidate_accepted'] is observer['resource_candidate_before_receipt'] is True
        assert result['callbacks']+1==header['callbacks']<=limits['root_callbacks']
        assert result['elapsed_seconds']<limits['work_seconds'] and header['seconds']<limits['positive_seconds']
        assert len(result['stages'])==37 and all(x['status']=='COMPLETED' for x in result['stages'])
        assert terminal['result']==pin(bodypath) and not (actual/'failure.json').exists()
        combined=terminal['parent_usage']['ru_maxrss']+max(terminal['child_usage']['ru_maxrss'],header['python_peak_after_output_bytes'])+header['native_peak_bytes']+terminal['memory_terminal_output_reserve_bytes']
        assert terminal['conservative_combined_peak_bytes']==combined
        assert observer['final_conservative_whole_peak_bytes']==combined+observer['final_observer_peak_bytes']+observer['final_output_memory_reserve_bytes']==165265408
        assert 0<observer['final_conservative_whole_peak_bytes']<limits['memory_bytes']
        detail=positive_audit(result,plan,actual)
        point=result['point_receipt'];subject=result['subject_receipt'];reference=result['reference_receipt']
        assert [x['byte_span'] for x in reference['rows']]==[x['span'] for x in subject['certificate']['rows']]
        assert point['tiles'][2]['m'][0][0]==[-2,1] and point['tiles'][2]['m'][0][1]==subject['certificate']['rows'][0]['formula']
        assert point['boundary']['final_goal_port']==[2,1] and point['boundary']['final_goal_value']==q['goal']
        assert detail['certificate']==dict(bytes=33,sha256='116c31813cba90ba9ffec2eabc88a1cbed6158b4b8ae296a9d01fd41115598b5')
        assert [x['formula'] for x in subject['certificate']['rows'][:2]]==[subject['certificate']['rows'][0]['formula']]*2
        detail['same_previously_reported_certificate']=True;detail['unused_middle_row_preserved']=True;detail['new_distinct_statement_count_relative_to_previous_main_cohort']=0
        ledger_path=C/'constructor-index-v3-target0-complete-passive-evidence-audit-v1.json'
        ledger_pin=freeze(ledger_path,dict(schema='GCTS-C-constructor-index-v3-positive-passive-evidence-audit-v1',all_checks_passed=True,result=pin(bodypath),review_program=pin(__file__),**detail))
    else:
        assert result['status']==header['status']=='FAILED_CASE_NOT_ADMITTED'
        assert result['first_Root_fault'] is header['first_Root_fault'] is True
        assert result['error']['type']=='RootBudget' and result['error']['message']=='absolute whole-work deadline'
        assert result['qualification_complete'] is False and all(result[k] is None for k in positive_keys)
        assert result['callbacks']==header['callbacks']==negative_callbacks[index-1]<limits['root_callbacks']
        assert result['elapsed_seconds']>=limits['work_seconds']
        assert len(result['stages'])==34 and all(x['status']=='COMPLETED' for x in result['stages'][:-1])
        assert result['stages'][-1]['name']=='SEARCH fresh full-FPC point-frame dovetail' and result['stages'][-1]['status']=='STARTED'
        assert terminal['header_valid'] is observer['resource_candidate_accepted'] is observer['resource_candidate_before_receipt'] is False
        assert terminal['result'] is None and terminal['conservative_combined_peak_bytes'] is None
        assert observer['conservative_whole_peak_bytes'] is observer['final_conservative_whole_peak_bytes'] is None
        assert not (actual/'result.json').exists() and not (actual/'candidate-certificate.bin').exists()
    checks=[
      check('current-exact-once-authority-and-source-chain','Exact current preparation/protocol2/plan/closure/proposal, worker3/bank2/wholePASS2 and fresh Root batch/case acceptance/idle barrier/true uses1 grant all join. CONSUMED binds current case/plan/grant once. All109 plan.files hashes are freshly current; all70 original guards/176 scoped vectors/23 roles/six inputs and ten caps preserved. No old qualification/result or failed prefix is intake.'),
      check('complete-postterminal-physical-census-and-custody','Exact complete owned actual+observer ordinary file census equals Root raw census, with every SHA/length and zero partial paths. Current header/terminal/observer/log stdout objects and pins join; all EOF/nooverflow/noerror/thread/Source/ordinary custody/fallback gates are checked. Native0 explicitly vacuous; no Native proof/process input. Root six-owned zero-signal observations match exact records and are momentary only; C performed no process probe.'),
      check('independent-input-freeze-association','Complete saved query/freeze fields join unchanged metadata-selected declaration, codec Source/raw query hash and exact parsed signature/profile/mode/full Gamma/goal/physical EOF. No query decoder/encoder or formula expansion is run by C. Non-core declaration expansion rests on the pinned independently reviewed codec. Raw input freeze alone is never an admitted result.'),
      check('current-whole-control-and-scientific-scope' if qualified else 'whole-deadline-and-no-prefix','Case0 complete current result retains all176 exact ordered namespaced PASS rows, including all54 constructor expected/actual literals, selected builder observations, helper/public first-fault/no-mutation/poison/ordinal11 and corrected finite E1 diagnostic cost. Full existing expected/observed guards/products/domain/graph/oracle/remainder/fuel/restore/dual rows were passively joined; limited private/public scopes remain.' if qualified else 'Whole RootBudget absolute work deadline in genuine callback, not normal EXHAUSTED/UNKNOWN, memory failure or theorem nonprovability. All earlier completed control wrappers are diagnostics only: qualificationfalse and all seven positive fields null; no passing prefix, current frame, candidate or proof record is rescued.'),
      check('complete-original-byte-proof-and-point-gates' if qualified else 'error-traceback-and-diagnostic-limit','Fresh immutable21-byte query and33-byte certificate join complete subject/reference VALID DERIVATION whole flags/EOF/all three rows/earlier refs/GEN full empty-Gamma guard. Search export/model/query/rows and paired point tiles/totals/m/no-conflict boundary agree. Both E1 rows remain; GEN uses source0 and middle row1 is unused. Point observation remains nonadmitted/nonsearch/non-GCTS.' if qualified else 'Full saved error/traceback and first_Root_faulttrue show propagation through the unchanged controller/provider into Root whole-work check. Interrupt locations are single snapshots only, not cumulative time/allocation/family/current-frame diagnosis; search metrics and positive receipts are unavailable.'),
      check('direct-resource-samples-and-no-advantage-claim','All positive worker/post-output/parent/waited-child/observer+reserve time/memory/physical gates independently pass; direct observer elapsed10.267159999988507s and final165265408B are whole-stage costs, distinct from search0.15698224998777732s. Same repeated elementary33B certificate, not an additional distinct theorem or matched speed/GCTS/RL advantage.' if qualified else 'Parent/observer exit2 and invalid success header fail closed: qualified whole peaks stay null, never zero or a reconstructed sum of separate RSS samples. Direct observer elapsed/finalgate/worker/header costs remain distinct. No memory/engine speed or matched comparison conclusion follows.'),
      check('separate-root-disposition-and-consumed-case-boundary','C qualifies this one complete current finite result only; Root admission remains separate. No global completeness/minimality/fixed finite Wang/general geometry/learned mark/RL effect follows. The earlier constructor-index-v2 carrier failure remains a preserved whole negative, and every current case is consumed.' if qualified else 'Complete passive review supports only a whole-negative Root disposition with four false positive gates. No retry, reduced cohort/caps, partial parsing or prefix salvage; current case remains consumed and old v2 carrier failure remains separately negative.')]
    costs=dict(whole_seconds=observer['elapsed_seconds'],whole_peak_bytes=observer['final_conservative_whole_peak_bytes'],observer_final_gate_seconds=observer['final_observer_gate_seconds'],worker_elapsed_seconds=result['elapsed_seconds'],worker_header_seconds=header['seconds'],worker_stdout_seconds=stdout['seconds'],parent_known_exit_seconds=terminal['known_exit_seconds'],parent_final_gate_seconds=terminal['final_custody_gate_seconds'],callbacks=result['callbacks'],worker_peak_bytes=result['python_peak_bytes'],post_output_worker_peak_bytes=header['python_peak_after_output_bytes'],reaped_child_peak_bytes=terminal['child_usage']['ru_maxrss'],parent_peak_bytes=terminal['parent_usage']['ru_maxrss'],observer_peak_bytes=observer['final_observer_peak_bytes'],physical_actual_bytes=physical_bytes)
    receipt=dict(schema='GCTS-C-point-frame-whole-actual-review-v1',issued_utc=datetime.now(timezone.utc).isoformat(),review_complete=True,negative_classification_supported=not qualified,review_passed=qualified,resource_admitted=qualified,scientific_qualified=qualified,stage_complete=qualified,case_id=case,target_index=index,target_id=plan['target_id'],stage='evaluate',status=result['status'],plan=row['plan'],protocol=prep['protocol'],closure=row['closure'],grant=pin(grant_path),case_proposal=row['proposal'],Root_acceptance=grant['Root_prospective_acceptance'],Root_batch_acceptance=accept['Root_batch_acceptance'],Root_idle_barrier=grant['all_tools_idle_barrier'],whole_prospective_batch_review=pin(whole_path),whole_review_identifier_clarification=pin(clarification),worker_component_review=prep['worker_component_review'],bank_component_review=prep['bank_component_review'],result=pin(bodypath) if qualified else None,failure=None if qualified else pin(bodypath),header=pin(actual/'worker-header.json'),terminal=pin(actual/'terminal.json'),observer=pin(obs/'observer.json'),raw_census=pin(census_path),Root_owned_terminal_observation=pin(owned_path),complete_actual_file_census=dict(files=physical,total_bytes=physical_bytes,file_count=len(physical),partial_paths=0),input_pins=guards,review_program=pin(__file__),checks=checks,failures=[],costs=costs,passive_evidence_audit=ledger_pin if qualified else None,scientific_summary=detail if qualified else None,error=None if qualified else result['error'],qualification_complete=result['qualification_complete'],qualified_control_groups=176 if qualified else 0,observed_stage_ledger=result['stages'],preserved_null_positive_fields=[] if qualified else positive_keys,partial_files_parsed=0,scientific_imports_calls=0,semantic_helpers_or_subjects_replayed=0,queries_certificates_or_expected_semantic_sets_generated=0,process_probes=0,Root_admission_issued=False,execution_or_publication_authority=False,tools_idle_on_return=True)
    name='typed-constructor-index-v3-target-'+str(index)+'-complete-'+('actual' if qualified else 'negative-actual')+'-review-v1.json'
    ref=freeze(C/name,receipt)
    case_receipts.append(dict(case_id=case,target_index=index,target_id=plan['target_id'],review=ref,positive_qualified=qualified,whole_peak_bytes=costs['whole_peak_bytes'],whole_seconds=costs['whole_seconds'],complete_files=len(physical),physical_bytes=physical_bytes))
for x in guards:verify(x)
assert before==[pin(x['path']) for x in guards]
assert sum(x['positive_qualified'] for x in case_receipts)==1
batch=dict(schema='GCTS-C-constructor-index-v3-six-case-complete-actual-batch-review-v1',issued_utc=datetime.now(timezone.utc).isoformat(),review_complete=True,review_passed=True,scope='All six current once packets reviewed: one complete finite positive candidate and five whole deadline negatives. This batch review is not all-six scientific success or Root admission.',preparation=pin(prep_path),protocol=prep['protocol'],whole_prospective_review=pin(whole_path),whole_review_identifier_clarification=pin(clarification),Root_owned_terminal_observation=pin(owned_path),review_program=pin(__file__),cases=case_receipts,checks=[check('all-original-six-reviewed-current-terminal-packets','All six exact original targets retain current once authority/109 guards/176 scope/23 roles/ten caps.13+five12=73 complete files, no partials; authoritative tool sessions/exits and Root exact-owned momentary absence joined.'),check('one-positive-five-unsalvaged-whole-negatives','Case0 satisfies all current complete controls/dual-byte proof/point/custody/resource C gates. Five RootBudget whole deadlines retain all seven null payloads and false qualification/positive gates/null qualified whole peak. No old or failed passing prefix is admitted.'),check('repeat-certificate-and-claim-limits','Case0 repeats previously reported33B elementary E1/E1/GENsource0 certificate with unused middle row; zero additional distinct statement relative to earlier main cohort. No useful new theorem, matched speedup, learned marking/RL/GCTS/general geometry or fixed finite Wang palette qualification. Separate Root dispositions remain required.')],failures=[],counts=dict(cases=6,current_positive_candidates_qualified_by_C=1,current_whole_negative_cases=5,complete_files=73,partial_files=0,total_physical_bytes=total_physical,current_complete_positive_control_groups=176,additional_distinct_statements_relative_to_previous_main_cohort=0),preserved_v2_whole_negative_review=pin(C/'typed-constructor-index-target-0-complete-negative-actual-review-v1.json'),passive_authoring_note='A read-only exploratory display requested nonexistent snapshot state_serial; actual public key is parent_state_serial. It stopped before any write or scientific call; subsequent complete JSON joins use the documented current keys.',scientific_imports_calls=0,scientific_helpers_or_subjects_replayed=0,partial_files_parsed=0,Root_admission_issued=False,execution_or_publication_authority=False,tools_idle_on_return=True)
batchpin=freeze(C/'typed-constructor-index-v3-six-case-complete-actual-batch-review-v1.json',batch)
print(json.dumps(dict(batch=batchpin,cases=case_receipts,total_physical_bytes=total_physical),indent=2))
