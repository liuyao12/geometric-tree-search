"""C-only narrow current whole successor metadata/Source audit. No subjects called."""
import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

BASE=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
S=BASE/'research-runs/gcts-point-proof-search-20261022'
R,B,L,C=S/'root',S/'implementation-B',S/'diagnostics-L',S/'review-C'
def pin(p):
    p=Path(p);assert p.is_absolute() and not p.is_symlink() and p.is_file() and p.resolve()==p
    raw=p.read_bytes();return {'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def read(p):return json.loads(Path(p).read_bytes())
def verify(row):
    result=pin(row['path']);assert all(result[k]==row[k] for k in ('path','bytes','sha256')),row['path'];return result
def defs(text):return {n.name:n for n in ast.parse(text).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
def assignments(text):return {k.id:n.value for n in ast.parse(text).body if isinstance(n,ast.Assign) for k in n.targets if isinstance(k,ast.Name)}
def dump(node):return ast.dump(node,include_attributes=False)
def canonical(obj):return json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=True).encode()

prep_path=R/'fixed-slot-study-preparation-v2.json';prep=read(prep_path)
assert pin(prep_path)['sha256']=='6034f9fe7238a75a422e07cadaad38043d279271f9920306f2bf9ffa191fc9aa'
previous_path=C/'typed-fixed-slot-six-target-complete-whole-prospective-Source-plan-proposal-review-v1.json'
previous=read(previous_path)
assert previous['review_passed'] is True
for k in ('metadata_builder','worker','worker_component_review','bank_component_review','provider_component_review','protocol'):verify(prep[k])
for k in ('worker_component_review','bank_component_review','provider_component_review'):assert read(prep[k]['path'])['review_passed'] is True
assert prep['bank_component_review']==prep['provider_component_review']
combined=read(prep['bank_component_review']['path'])
worker_path=Path(prep['worker']['path']);text=worker_path.read_text()
oldworker=B/'fpc_point_frame_search_worker_v4.py';oldtext=oldworker.read_text()
replacements=[
 ('FPC-full-frame-point-worker-v5','FPC-full-frame-point-worker-v4'),
 ('point-frame-fixed-slots-v2','point-frame-fixed-slots-v1'),
 ("'provider': (67637, '39da5195f815da0cceddd11b4d4b25671a50e926ca1885ccc3add6cd99a8d048')","'provider': (67631, '2bdc125646ec3d54ac55718b85d0dd3a4fa69ba2c1de91d29e589ded95fe31e6')"),
 ('8a7b33c8729d6c9f40c9354058bbbef24568e885ec8bccf6d12fae04bdf8be03','56257d580e562c484287d2177ee56607ddf77a75236354c69a4d8602d9112af8'),
 ('FPC-POINT-FULL-FRAME-PROVIDER-implementation-v6','FPC-POINT-FULL-FRAME-PROVIDER-implementation-v5'),
 ('L-fixed-free-slot-independent-controls-v2','L-fixed-free-slot-independent-controls-v1'),
 ('controls use6; 184 groups do not mean 184 tests of provider6.','controls use5; 184 groups do not mean 184 tests of provider5.'),
 ('fpc_point_frame_search_worker_v5.py PLAN','fpc_point_frame_search_worker_v4.py PLAN')]
inverse=text
for new,old in replacements:
    assert new in inverse,new
    inverse=inverse.replace(new,old)
assert inverse==oldtext
nd,od=defs(text),defs(oldtext)
assert nd.keys()==od.keys()
unchanged=[k for k in nd if dump(nd[k])==dump(od[k])]
assert len(unchanged)==7 and set(nd)-set(unchanged)=={'main'}
a,old_a=assignments(text),assignments(oldtext)
for k in set(a)-{'VERSION','EXPERIMENT','FIXED_PINS'}:assert dump(a[k])==dump(old_a[k]),k
roles=[x.value for x in a['MODULE_ROLES'].elts]
vectors={k.value:[e.value for e in v.elts] for k,v in zip(a['CONTROL_IDS'].keys,a['CONTROL_IDS'].values)}
fixed={k.value:(v.elts[0].value,v.elts[1].value) for k,v in zip(a['FIXED_PINS'].keys,a['FIXED_PINS'].values)}
for role,name in [('controller_bank','CONTROLLER_BANK_PIN'),('conclusion_index_bank','CONCLUSION_BANK_PIN')]:
    fixed[role]=tuple(x.value for x in a[name].elts)
assert len(roles)==25 and len(set(roles))==25 and len(vectors)==11 and sum(map(len,vectors.values()))==184

api_path=B/'point-frame-worker-API-v5.json';offer_path=B/'point-frame-worker-dependency-offer-v5.json'
api,offer=read(api_path),read(offer_path)
modules={x['role']:x['rawpin'] for x in offer['runtime_roles']}
assert set(modules)==set(roles) and len(offer['runtime_roles'])==25 and len({x['path'] for x in modules.values()})==25
assert {x['role']:{k:x[k] for k in ('path','bytes','sha256')} for x in api['runtime_roles']}==modules
for role,ref in modules.items():verify(ref);assert fixed[role]==(ref['bytes'],ref['sha256'])
assert modules['provider']==combined['provider_source'] and modules['fixed_slot_bank']==combined['bank_source']
oldplan0=read(R/'plans/point-frame-fixed-slots-v1-target-0.json')
for role,ref in oldplan0['module_pins'].items():
    if role not in ('provider','fixed_slot_bank'):assert modules[role]==ref
assert modules['legacy_provider']['sha256']=='7fc9ebe143513fa86e726c78832cdbb91589fbd9e8a5d2b21eb3183a5fbf5fd2'
populations={x['population']:{k:x[k] for k in ('control_ids','groups','bank_role','subject_role','scope')} for x in api['scoped_populations']}
assert len(populations)==11
for k,pop in populations.items():
    assert pop['control_ids']==vectors[k] and pop['groups']==len(vectors[k])
    assert all(pop[field]==oldplan0['control_populations'][k][field] for field in ('control_ids','groups','bank_role','subject_role'))
assert populations['constructor-index14']['subject_role']=='legacy_provider' and populations['fixed-free-slot8']['subject_role']=='provider'
inputs={x['role']:x for x in offer['raw_inputs']}
assert len(inputs)==len(offer['raw_inputs'])==6 and len({x['plan_key'] for x in inputs.values()})==6
assert {x['role']:(x['plan_key'],x['rawpin']) for x in api['raw_inputs']}=={k:(x['plan_key'],x['rawpin']) for k,x in inputs.items()}
for row in list(inputs.values()):verify(row['rawpin'])
custody={x['role']:x['rawpin'] for x in offer['custody_runtime']}
assert custody==previous['custody_runtime'] and set(custody)=={'runner','observer','python'}
for row in custody.values():verify(row)
for row in offer['semantic_guards']:verify(row)
protocol=read(prep['protocol']['path']);oldprotocol=read(oldplan0['protocol']['path'])
assert set(protocol)==set(oldprotocol)=={'schema','experiment','limits','module_pins','control_populations','job_recipes','metadata'}
assert protocol['schema']=='Root-FPC-point-frame-protocol-v1' and protocol['experiment']=='point-frame-fixed-slots-v2'
assert protocol['module_pins']==modules and protocol['control_populations']==populations
assert protocol['limits']==api['limits']==oldplan0['limits']==previous['limits']
assert api['search_configuration']==oldplan0['search_configuration']==previous['search_configuration']
assert len(protocol['limits'])==10 and all(type(x) is int for x in protocol['limits'].values())
decls=read(inputs['six_declarations']['rawpin']['path'])
recipes=[{'case_id':'point-frame-fixed-slots-v2-target-'+str(i),'target_index':i,'target_id':target['id']} for i,target in enumerate(decls['targets'])]
assert protocol['job_recipes']==recipes and len(recipes)==6
md=protocol['metadata'];oldmd=oldprotocol['metadata']
changed_metadata={k for k in md if md[k]!=oldmd.get(k)}
assert changed_metadata <= {'current_worker','component_review','stages','six_statuses','initial_selection','additive_bank_review','provider_review','control_extension','prospective_selection','repair_boundary','previous_guard_count_retained'}
for k,pk in [('current_worker','worker'),('component_review','worker_component_review'),('additive_bank_review','bank_component_review'),('provider_review','provider_component_review')]:assert md[k]==prep[pk]
assert md['initial_selection']==recipes[3] and md['previous_guard_count_retained']==142
selection_path=R/'fixed-slot-prospective-pilot-selection-v2.json';selection=read(selection_path)
assert md['prospective_selection']==pin(selection_path) and selection['pilot_target_index']==3
assert selection['unchanged_original_literal_declaration']==decls['targets'][3]
assert selection['limits']==protocol['limits'] and selection['search_configuration']==api['search_configuration']
assert selection['pilot_target_id']==recipes[3]['target_id']=='HI-point-not-line'
issuer=R/'issue_fixed_slot_case_grant_v2.py';census=R/'census_completed_fixed_slot_case_v2.py'
assert pin(issuer)['sha256']=='dd00a72830e017fc6a35c01e964a0cdd0d0dd33dd8dfa2ff21e7f8d4272697a4'
assert pin(census)['sha256']=='d6a6cf3ffbafd8825cd4f7b953442b702243855dcf357095db87933c584664dd'
assert pin(prep['metadata_builder']['path'])==prep['metadata_builder'] and prep['shared_guards']==176

case_reviews=[];future=[];first=None;guards=None
for i,row in enumerate(prep['cases']):
    assert row['recipe']==recipes[i]
    for key in ('plan','closure','proposal'):verify(row[key])
    p,cl,proposal=(read(row[k]['path']) for k in ('plan','closure','proposal'))
    old=read(R/'plans'/('point-frame-fixed-slots-v1-target-'+str(i)+'.json'))
    assert set(p)==set(old)
    changed={k for k in p if p[k]!=old[k]}
    assert changed=={'case_id','experiment','actual_dir','worker_path','protocol','files','module_pins','control_populations'}
    assert all(p[k]==v for k,v in recipes[i].items()) and type(p['target_index']) is int
    assert p['stage']=='evaluate' and p['required_upstream_ids']==[] and p['experiment']==protocol['experiment']
    assert p['limits']==protocol['limits'] and p['search_configuration']==api['search_configuration']
    assert p['module_pins']==modules and p['control_populations']==populations and p['protocol']==prep['protocol']
    assert p['worker_path']==str(worker_path) and p['runner_path']==custody['runner']['path'] and p['python']==custody['python']
    assert p['actual_dir']==str(S/'actual'/p['case_id'])
    assert len(p['files'])==len({x['path'] for x in p['files']})==176
    assert [x['path'] for x in p['files']]==sorted(x['path'] for x in p['files'])
    assert all(x in p['files'] for x in old['files']) and len(old['files'])==142
    for ref in list(modules.values())+list(custody.values())+[prep['protocol'],prep['metadata_builder'],prep['worker_component_review'],prep['bank_component_review'],pin(issuer),pin(census)]:assert ref in p['files']
    for inp in inputs.values():assert p[inp['plan_key']]==inp['rawpin'] and inp['rawpin'] in p['files']
    if first is None:first,guards=p,p['files']
    else:assert {k:v for k,v in p.items() if k not in ('case_id','target_index','target_id','actual_dir')}=={k:v for k,v in first.items() if k not in ('case_id','target_index','target_id','actual_dir')}
    assert cl['plan']==row['plan'] and cl['protocol']==prep['protocol'] and cl['files']==p['files']
    assert cl['module_roles_in_execution_order']==roles and cl['namespace_count']==25 and cl['six_recipes']==recipes
    assert cl['scoped_group_count']==184 and cl['scoped_population_count']==11 and cl['actuals_created']==cl['scientific_imports_calls']==cl['query_proof_encoding']==0
    assert proposal['schema']=='Root-point-frame-once-grant-proposal-v1' and proposal['authorized'] is proposal['review_passed'] is False
    assert type(proposal['uses']) is int and proposal['uses']==1 and proposal['case_id']==p['case_id']
    assert proposal['plan']==row['plan'] and proposal['closure']==row['closure'] and proposal['protocol']==prep['protocol']
    assert proposal['component_review']==prep['worker_component_review'] and proposal['additive_bank_review']==prep['bank_component_review']
    assert proposal['plan_sha256']==row['plan']['sha256'] and proposal['runner_sha256']==custody['runner']['sha256'] and proposal['observer_sha256']==custody['observer']['sha256']
    assert proposal['prospective_grant_path']==str(R/'grants'/(p['case_id']+'.json'))
    assert proposal['prospective_command']==[custody['python']['path'],'-I','-S','-B',custody['observer']['path'],row['plan']['path'],proposal['prospective_grant_path']]
    absent=[p['actual_dir'],p['actual_dir']+'.observer',proposal['prospective_grant_path']]
    assert all(not Path(x).exists() and not Path(x).is_symlink() for x in absent)
    future.extend(absent)
    case_reviews.append({'recipe':recipes[i],'plan':row['plan'],'closure':row['closure'],'proposal':row['proposal'],'review_passed':True,
      'checks':[{'id':'current-whole-Source-phase-and-exact-original-recipe','passed':True},{'id':'closure-false-proposal-isolated-CLI-and-absent-outputs','passed':True}]})
for ref in guards:verify(ref)
assert not any('/actual/' in x['path'] or '.partial' in x['path'] or x['path'].endswith('.bin') for x in guards)
assert sum(not Path(x['path']).is_relative_to(BASE) for x in guards)==1
newmeta={row[k]['path'] for row in prep['cases'] for k in ('plan','closure','proposal')}
assert not (newmeta & {x['path'] for x in guards}) and str(prep_path) not in {x['path'] for x in guards}
assert all(not Path(x).exists() and not Path(x).is_symlink() for x in future)
for p in [worker_path,Path(prep['metadata_builder']['path']),issuer,census]:compile(p.read_bytes(),str(p),'exec')

checks=[
 ('narrow-current-worker-provider-bank-component-association','Exact current Source5 raw inverse to reviewed worker4 contains only labels/current6+bank2 pins/revision gates/scope/CLI literals; seven helpers and all other constants raw/AST unchanged. Current combined provider6/bank2 Source PASS and L caller5 PASS independently raw-bound. Closed public action repaired, old tests not widened.'),
 ('all176-acyclic-guards-retain-previous142','All176 unique canonical ordinary shared plan.files raw bodies rehashed current, allprevious142 retained including original109. Current modules/metadata builder/docs/Source reviews/protocol/issuer/census present, one external Python binary only. New plans/closures/proposals/preparation/this review outside guards avoid self cycles. No direct actual/result/proof/partial input.'),
 ('25-current-roles-six-inputs-ten-calls-eleven-scopes184','Source MODULE_ROLES controls cold import order; metadata role objects are unique sets. All25 Source hard pins/API/offer/plan/protocol joins exact, six raw role/plan_key triples unchanged. Original184 IDs/order/bank/subject roles preserved, constructor14 exact4; applicable tiny/controller/fixed8 use6. No184-direct-tests-of6 assertion.'),
 ('all-six-original-recipes-and-exact-six-current-plans','All6 original statements/indices/order/mode/profile/signature/Gamma intake retained. Six new same-configuration cases differ only recipe fields across cohort; compared with v1 their complete changed key set is labels/Source/currentpins/protocol/guard additions. Pilot3 reaffirmed exact original HI-point-not-line, no hint/frame/lemma/route.'),
 ('inherited-charged-phase-proof-and-seven-null-custody-gates','Unchanged active Source pipeline includes hash/import/independent inputfreeze/allcontrols/search/same-byte original dual validators/paired nonadmitted point representation/fulloutput under same10caps/config/firstfault. All7 positive payloads suppressed on failure. Prior runner98c553/observer24804 exact hashes bind inherited CONSUMED/process-group/header/EOF/reaping/strict whole resource/null-peak semantics; no repetitive unchanged algorithm audit or scientific call.'),
 ('metadata-builder-issuer-census-current-provenance','Current builder6 full diff to reviewed builder4 changes only successor paths/bindings/preserving previous142/source-repair descriptions; emitted selfpin exact. Full issuer2 read: current case/plan/closure/protocol/components/guards/caps/absences checked, then exclusive new Root acceptance/barrier/true uses1 grant. Census2 is only raw terminal hashing/partial-opaque. Neither is invoked by C.'),
 ('six-reject-only-proposals-and-fresh-once-boundary','All6 proposals false/false strictintuses1 bind exact caseplan/protocol/closure/components/runnerobserver and isolated -I-S-B observer argv. All18 actual/observer/finalgrant paths absent. Root final grant must bind this whole review, exact per-case proposal/Root acceptance and genuinely fresh tools-idle barrier without operative changes. Generic runner enforces documented subset only; issuer text does not itself observe agents/OS.'),
 ('consumed-whole-negative-preserved-no-citation-adoption','Consumed v1target3 Step.action failure and all7null/nullpeak remain negative, no retry/prefix qualification. L shallow diagnosis memo is explicit Source provenance; it cites the failure but worker never parses its cited bodies. No recursive citation eligibility or runtime result intake; unchanged histories/source reviews retained. No current runtime/test/fit/proof/advantage claim.')]
receipt={'schema':'GCTS-C-fixed-slot-six-target-whole-prospective-Source-plan-proposal-review-v2',
 'issued_utc':datetime.now(timezone.utc).isoformat(),'review_complete':True,'review_passed':True,
 'scope':'Exact narrow successor whole Source/phase/protocol/six-plan/closure/reject-only proposal composition. Initial fresh Root pilot3 only; C issues no grant/actual/admission.',
 'preparation':pin(prep_path),'protocol':prep['protocol'],'worker':prep['worker'],'worker_API':pin(api_path),'dependency_offer':pin(offer_path),
 'worker_component_review':prep['worker_component_review'],'provider_component_review':prep['provider_component_review'],'bank_component_review':prep['bank_component_review'],
 'inherited_whole_prospective_review':pin(previous_path),'preserved_consumed_negative':pin(C/'typed-fixed-slot-v1-target-3-complete-negative-actual-review-v1.json'),
 'metadata_builder':prep['metadata_builder'],'grant_issuer':pin(issuer),'postterminal_census_Source':pin(census),
 'custody_runtime':custody,'pilot_selection':pin(selection_path),'review_program':pin(__file__),
 'checks':[{'id':key,'passed':True,'finding':value} for key,value in checks],'cases':case_reviews,
 'counts':{'shared_guards':176,'retained_previous_guards':142,'retained_original_guards':109,'runtime_roles':25,'raw_JSON_inputs':6,'fresh_bank_calls':10,'scoped_populations':11,'scoped_groups':184,'prospective_cases':6,'false_proposals':6,'absent_future_paths':18},
 'limits':protocol['limits'],'search_configuration':api['search_configuration'],
 'guarded_row_digest_sha256':hashlib.sha256(canonical(guards)).hexdigest(),'guarded_raw_bytes':sum(x['bytes'] for x in guards),
 'guard_inventory_authority':'Exact shared sorted plan.files list bound by all6 raw plan pins; no recursive eligibility or fabricated duplicate guard expansion.',
 'method':'Complete current changed Source contexts/raw inverse/AST metadata and complete emitted saved JSON joined; unchanged full Source/custody findings inherited by exact hashes. Current builder/issuer/census deltas and issuer/census body read. Pure stdlib raw/metadata/AST/unusedcompile only; no ast.literal_eval/experimental imports or calls.',
 'documentation_limits':['Operative current worker5 Source CLI/plans override inherited API entry worker_v3/old dependency descriptive experiment/provider text. Current10calls/11scopes184 fixed by explicit metadata and manual.',
 'Inherited provider raw-tuple commentary/author AST serialization limits remain scoped in current combined Source review. Component PASS is Source reasoning, not test qualification.'],
 'limitations':['No runtime/fit or all-profile proof follows; all fresh scopes remain unrun until a separate Root once grant. Future complete current actual/C/Root gates remain mandatory.',
 'Root must genuinely observe fresh all-tools-idle state before issuer; hardcoded barrier prose is not automatic OS/agent verification. No liveness probe by C.',
 'No GCTS/RL advantage, full geometric/fractional/generation conformance transfer, allocation census or finite Wang verifier claim. Same-byte point reduction remains nonadmitted representation.'],
 'failures':[],'concrete_blockers':[],'scientific_imports_calls':0,'ast_literal_evaluation':False,'query_AST_fixture_proof_or_expected_semantic_set_generation':0,
 'actual_or_partial_bodies_parsed':0,'Root_or_Publisher_mutations':False,'Root_admission_issued':False,'execution_or_publication_authority':False,'tools_idle_on_return':True}
for ref in guards:verify(ref)
assert all(not Path(x).exists() and not Path(x).is_symlink() for x in future)
out=C/'typed-fixed-slot-six-target-complete-whole-prospective-Source-plan-proposal-review-v2.json'
with out.open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps({'receipt':pin(out),'checks':len(checks),'counts':receipt['counts']}))
