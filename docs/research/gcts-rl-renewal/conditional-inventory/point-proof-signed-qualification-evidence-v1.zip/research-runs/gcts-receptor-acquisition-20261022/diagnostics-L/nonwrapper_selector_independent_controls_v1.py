"""Independent prospective public-endpoint controls; never run while authoring.

The literal expectations precede any selector implementation intake.  This bank
has its own prefix grammar walk, Boolean interpretation and full pattern match.
It neither supplies research inputs nor grants authority to a returned prefix.
"""

VERSION = 'FPC-NONWRAPPER-SELECTOR-INDEPENDENT-CONTROLS-v1'
RETURN_SCHEMA = 'FPC-nonwrapper-selector-independent-controls-v1'
POPULATION = 'nonwrapper_selector6'
SELECTOR_VERSION = 'FPC-NONWRAPPER-TWO-DONOR-INPUT-SELECTOR-v1'
FIXTURE_SCHEMA = 'L-nonwrapper-selector-independent-literal-expectations-v1'
CONTROL_IDS = (
    'literal-helper-facts',
    'canonical-occurrence-and-copying',
    'malformed-envelope-owned-refusals',
    'complete-ordered-winning-prefixes',
    'first-and-retained-callback-identity',
    'fresh-call-and-slot-isolation',
)
STAGES = ('donor0', 'donor1', 'holdout0')
BOUNDS = ((11, 6, 2, 1, None), (13, 6, 3, 0, 0), (15, 7, 3, 1, None))
INSPECTION_KEYS = (
    'schema', 'complete', 'canonical_goal', 'tokens', 'expanded_nodes',
    'depth', 'atom_count', 'atom_occurrences', 'not_count', 'root_is_imp',
    'has_adjacent_not', 'whole_identity', 'truth_values', 'tautology',
    'proper_tautologies', 'single_axiom_subtags',
)
PREFIX_KEYS = (
    'rank', 'tokens', 'expanded_nodes', 'depth', 'atom_count',
    'atom_occurrences', 'not_count', 'truth_values', 'tautology',
    'proper_tautologies', 'single_axiom_subtags', 'whole_donor_matches',
    'eligible', 'reason',
)
_OWNER = object()


class NonwrapperControlError(ValueError):
    pass


class _Call:
    def __init__(self, check):
        self.check = check
        self.first = None
        self.token = object()
        self.callbacks = 0

    def tick(self):
        if self.first is not None:
            raise self.first
        if not callable(self.check):
            self.fail('check must be callable')
        try:
            self.check()
            self.callbacks += 1
        except BaseException as error:
            if self.first is None:
                self.first = error
            raise self.first

    def fail(self, message):
        if self.first is not None:
            raise self.first
        error = NonwrapperControlError(message)
        error._owner = _OWNER
        error._call = self.token
        raise error

    def need(self, condition, message):
        if not condition:
            self.fail(message)


def _same(left, right, call):
    pending = [(left, right)]
    while pending:
        call.tick()
        a, b = pending.pop()
        if type(a) is not type(b):
            return False
        if type(a) is dict:
            if set(a) != set(b):
                return False
            for key in a:
                call.tick()
                pending.append((a[key], b[key]))
        elif type(a) in (list, tuple):
            if len(a) != len(b):
                return False
            for index in range(len(a)):
                call.tick()
                pending.append((a[index], b[index]))
        elif type(a) in (str, int, bool, type(None)):
            if a != b:
                return False
        else:
            call.fail('non-discrete comparison carrier')
    return True


def _plain(value, call):
    call.tick()
    if type(value) in (str, int, bool, type(None)):
        return value
    if type(value) is float:
        call.need(value == value and value not in (float('inf'), -float('inf')),
                  'nonfinite evidence scalar')
        return value
    if type(value) in (list, tuple):
        result = []
        for item in value:
            call.tick()
            result.append(_plain(item, call))
        return result
    if type(value) is dict:
        result = {}
        for key, item in value.items():
            call.tick()
            call.need(type(key) is str, 'evidence dictionary key')
            result[key] = _plain(item, call)
        return result
    call.fail('ordinary fixture/evidence carrier')


def _container_ids(value, call):
    ids = set()
    pending = [value]
    while pending:
        call.tick()
        item = pending.pop()
        if type(item) not in (list, tuple, dict):
            continue
        number = id(item)
        if number in ids:
            continue
        ids.add(number)
        if type(item) is dict:
            for child in item.values():
                call.tick()
                pending.append(child)
        else:
            for child in item:
                call.tick()
                pending.append(child)
    return ids


def _canonical(formula, call):
    names = {}
    occurrences = []
    ancestors = set()
    counters = {'nodes': 0, 'depth': 0, 'not': 0, 'adjacent': False}

    def visit(node, depth, parent_not):
        call.tick()
        call.need(type(node) in (list, tuple) and len(node) > 0, 'reference AST')
        call.need(id(node) not in ancestors, 'reference cyclic AST')
        call.need(depth <= 32, 'reference depth envelope')
        counters['nodes'] += 1
        call.need(counters['nodes'] <= 256, 'reference expanded-node envelope')
        counters['depth'] = max(counters['depth'], depth)
        ancestors.add(id(node))
        try:
            tag = node[0]
            call.need(type(tag) is str, 'reference tag')
            if tag == 'pred':
                call.need(len(node) == 3 and type(node[1]) is int
                          and 0 <= node[1] <= 2 and type(node[2]) in (list, tuple)
                          and len(node[2]) == 0, 'reference atom')
                if node[1] not in names:
                    names[node[1]] = len(names)
                    occurrences.append(0)
                index = names[node[1]]
                occurrences[index] += 1
                return ['pred', index, []]
            if tag == 'not':
                call.need(len(node) == 2, 'reference NOT arity')
                counters['not'] += 1
                if parent_not:
                    counters['adjacent'] = True
                return ['not', visit(node[1], depth + 1, True)]
            call.need(tag == 'imp' and len(node) == 3, 'reference IMP arity')
            return ['imp', visit(node[1], depth + 1, False),
                    visit(node[2], depth + 1, False)]
        finally:
            ancestors.remove(id(node))

    goal = visit(formula, 0, False)
    return goal, occurrences, counters


def _tokens(formula, call):
    result = []
    pending = [formula]
    while pending:
        call.tick()
        node = pending.pop()
        if node[0] == 'pred':
            result.extend((0, node[1]))
        elif node[0] == 'not':
            result.append(1)
            pending.append(node[1])
        else:
            result.append(2)
            pending.append(node[2])
            pending.append(node[1])
    return result


def _truth(formula, atom_count, call):
    def evaluate(node, bits):
        call.tick()
        if node[0] == 'pred':
            return bits[node[1]]
        if node[0] == 'not':
            return not evaluate(node[1], bits)
        left = evaluate(node[1], bits)
        right = evaluate(node[2], bits)
        return (not left) or right

    values = []
    for assignment in range(1 << atom_count):
        call.tick()
        bits = []
        for index in range(atom_count):
            call.tick()
            bits.append(bool((assignment >> (atom_count - index - 1)) & 1))
        values.append(evaluate(formula, bits))
    return values


def _pattern_match(pattern, formula, bindings, call):
    call.tick()
    if pattern[0] == 'F':
        key = pattern[1]
        if key in bindings:
            return _same(bindings[key], formula, call)
        bindings[key] = formula
        return True
    if formula[0] != pattern[0] or len(formula) != len(pattern):
        return False
    if pattern[0] == 'not':
        return _pattern_match(pattern[1], formula[1], bindings, call)
    return (_pattern_match(pattern[1], formula[1], bindings, call)
            and _pattern_match(pattern[2], formula[2], bindings, call))


def _single_axioms(formula, call):
    a, b, c = ['F', 'A'], ['F', 'B'], ['F', 'C']
    patterns = [
        ['imp', a, ['imp', b, a]],
        ['imp', ['imp', a, ['imp', b, c]],
         ['imp', ['imp', a, b], ['imp', a, c]]],
        ['imp', ['imp', ['not', a], ['not', b]], ['imp', b, a]],
    ]
    matches = []
    for index in range(3):
        call.tick()
        if _pattern_match(patterns[index], formula, {}, call):
            matches.append(index)
    return matches


def _donor_match(pattern, formula, call):
    bindings = {}

    def visit(left, right):
        call.tick()
        if left[0] == 'pred':
            number = left[1]
            if number in bindings:
                return _same(bindings[number], right, call)
            bindings[number] = right
            return True
        if left[0] != right[0] or len(left) != len(right):
            return False
        if left[0] == 'not':
            return visit(left[1], right[1])
        return visit(left[1], right[1]) and visit(left[2], right[2])

    return visit(pattern, formula)


def _facts(formula, call):
    goal, occurrences, counters = _canonical(formula, call)
    truth = _truth(goal, len(occurrences), call)
    proper = []
    pending = [(goal, [])]
    while pending:
        call.tick()
        node, path = pending.pop()
        if path:
            local, local_occurrences, unused = _canonical(node, call)
            local_truth = _truth(local, len(local_occurrences), call)
            if all(local_truth):
                proper.append({'path': list(path), 'tokens': _tokens(local, call),
                               'atom_count': len(local_occurrences),
                               'truth_values': local_truth})
        if node[0] == 'not':
            pending.append((node[1], path + [0]))
        elif node[0] == 'imp':
            pending.append((node[2], path + [1]))
            pending.append((node[1], path + [0]))
    identity = goal[0] == 'imp' and _same(goal[1], goal[2], call)
    return {
        'schema': 'nonwrapper-formula-inspection-v1', 'complete': True,
        'canonical_goal': goal, 'tokens': _tokens(goal, call),
        'expanded_nodes': counters['nodes'], 'depth': counters['depth'],
        'atom_count': len(occurrences), 'atom_occurrences': occurrences,
        'not_count': counters['not'], 'root_is_imp': goal[0] == 'imp',
        'has_adjacent_not': counters['adjacent'], 'whole_identity': identity,
        'truth_values': truth, 'tautology': all(truth),
        'proper_tautologies': proper, 'single_axiom_subtags': _single_axioms(goal, call),
    }


def _decode_tokens(tokens, call):
    position = [0]

    def read():
        call.tick()
        call.need(position[0] < len(tokens), 'independent token EOF')
        tag = tokens[position[0]]
        position[0] += 1
        if tag == 0:
            call.need(position[0] < len(tokens), 'independent atom EOF')
            number = tokens[position[0]]
            position[0] += 1
            return ['pred', number, []]
        if tag == 1:
            return ['not', read()]
        call.need(tag == 2, 'independent token constructor')
        left = read()
        right = read()
        return ['imp', left, right]

    result = read()
    call.need(position[0] == len(tokens), 'independent trailing tokens')
    return result


class _PrefixWalk:
    """A non-generator grammar DFS; no sort or complete postwinner census.

    A pending slot records its depth and whether its parent is NOT.  Prefix
    choices are atom0/atom1/atom2, NOT, IMP in lexical order.  Atom labels are
    restricted to existing labels or exactly the next first-use label.  Thus
    each canonical ordered syntax tree of the requested size appears once.
    """

    def __init__(self, bounds, call):
        self.bounds = bounds
        self.call = call
        self.size = 2
        self.stack = []

    def next(self):
        call = self.call
        max_nodes, max_depth, atoms, min_not, max_not = self.bounds
        while True:
            call.tick()
            if not self.stack:
                self.size += 1
                if self.size > max_nodes:
                    return None
                # IMP root is mandatory; the final slot is visited first.
                self.stack.append(((2,), ((1, False), (1, False)),
                                   1, (0, 0, 0), 0, 0))
            tokens, slots, used, occurrences, seen, not_count = self.stack.pop()
            if not slots:
                if used != self.size or seen != atoms:
                    continue
                if any(occurrences[index] < 2 for index in range(atoms)):
                    continue
                if not_count < min_not or (max_not is not None and not_count > max_not):
                    continue
                formula = _decode_tokens(tokens, call)
                if _same(formula[1], formula[2], call):
                    continue
                return formula
            remaining = self.size - used
            if remaining < len(slots):
                continue
            depth, parent_not = slots[-1]
            if depth > max_depth:
                continue
            rest = slots[:-1]
            children = []
            # Build choices in increasing lexicographic prefix-token order.
            for number in range(min(seen + 1, atoms)):
                call.tick()
                counts = list(occurrences)
                counts[number] += 1
                children.append((tokens + (0, number), rest, used + 1,
                                 tuple(counts), max(seen, number + 1), not_count))
            if not parent_not and (max_not is None or not_count < max_not):
                children.append((tokens + (1,), rest + ((depth + 1, True),),
                                 used + 1, occurrences, seen, not_count + 1))
            children.append((tokens + (2,), rest + ((depth + 1, False),
                                                     (depth + 1, False)),
                             used + 1, occurrences, seen, not_count))
            for child in reversed(children):
                call.tick()
                if child[2] <= self.size and self.size - child[2] >= len(child[1]):
                    self.stack.append(child)


def _prefix_row(rank, facts, stage, donors, call):
    proper = None
    single = None
    matches = None
    if not facts['tautology']:
        reason = 'NOT_TAUTOLOGY'
    else:
        proper = facts['proper_tautologies']
        if proper:
            reason = 'PROPER_TAUTOLOGY'
        else:
            single = facts['single_axiom_subtags']
            if single:
                reason = 'SINGLE_AXIOM'
            elif stage < 2:
                reason = 'SELECTED'
            else:
                matches = []
                for donor in donors:
                    call.tick()
                    matches.append(_donor_match(donor, facts['canonical_goal'], call))
                reason = 'WHOLE_DONOR_INSTANCE' if any(matches) else 'SELECTED'
    result = {}
    for key in ('tokens', 'expanded_nodes', 'depth', 'atom_count',
                'atom_occurrences', 'not_count', 'truth_values', 'tautology'):
        call.tick()
        result[key] = facts[key]
    result.update(rank=rank, proper_tautologies=proper,
                  single_axiom_subtags=single, whole_donor_matches=matches,
                  eligible=reason == 'SELECTED', reason=reason)
    return result


def _query(goal):
    return {'version': 1, 'claim_mode': 0, 'function_arities': [],
            'predicate_arities': [0, 0, 0], 'theory_profile': 0,
            'finite_axioms': [], 'Gamma': [], 'goal': goal}


def _expect_owned(selector, invoke, call):
    caught = None
    try:
        invoke()
    except BaseException as error:
        if call.first is not None:
            raise call.first
        caught = error
    call.need(caught is not None, 'expected owned selector refusal')
    call.need(isinstance(caught, selector.SelectorInputError),
              'normal selector refusal class')
    call.need(selector.is_owned_error(caught) is True, 'normal refusal provenance')
    return caught


def _literal_controls(selector, fixtures, call):
    rows = fixtures['literal_helper_fixtures']
    call.need(type(rows) is list and len(rows) == 6, 'six frozen helper records')
    checked = []
    for row in rows:
        call.tick()
        formula = _plain(row['input'], call)
        before = _plain(formula, call)
        expected = row['expected']
        # This also checks reference semantics against the pre-frozen literals.
        call.need(_same(_facts(formula, call), expected, call), 'independent literal fact')
        actual = selector.inspect_formula(formula, check=call.tick)
        call.need(type(actual) is dict and set(actual) == set(INSPECTION_KEYS),
                  'inspection exact keys')
        call.need(_same(actual, expected, call), 'literal public inspection')
        call.need(_same(formula, before, call), 'inspection input unchanged')
        call.need(not (_container_ids(formula, call) & _container_ids(actual, call)),
                  'caller container escaped')
        checked.append(row['id'])
    return {'fixture_ids': checked, 'literal_records_checked': len(checked)}


def _copy_controls(selector, fixtures, call):
    leaf = ['pred', 2, []]
    shared = ['imp', leaf, leaf]
    formula = ['imp', shared, shared]
    expected = fixtures['literal_helper_fixtures'][3]['expected']
    before = _plain(formula, call)
    left = selector.inspect_formula(formula, check=call.tick)
    right = selector.inspect_formula(formula, check=call.tick)
    call.need(_same(left, expected, call) and _same(right, expected, call),
              'expanded shared occurrence facts')
    call.need(_same(formula, before, call), 'shared caller tree unchanged')
    call.need(not (_container_ids(left, call) & _container_ids(right, call)),
              'cross-call output alias')
    call.need(left['proper_tautologies'][0] is not left['proper_tautologies'][1],
              'separate proper-occurrence records')
    renamed = ('imp', ('pred', 1, ()), ('imp', ('pred', 0, ()), ('pred', 1, ())))
    actual = selector.inspect_formula(renamed, check=call.tick)
    call.need(_same(actual, fixtures['literal_helper_fixtures'][4]['expected'], call),
              'tuple intake and first-seen atom quotient')
    return {'shared_expanded_nodes': 7, 'proper_occurrence_paths': [[0], [1]],
            'tuple_and_renaming': True, 'cross_call_containers_disjoint': True}


def _malformed_controls(selector, call):
    class ListSubclass(list):
        pass

    cycle = ['not', None]
    cycle[1] = cycle
    deep = ['pred', 0, []]
    for unused in range(33):
        call.tick()
        deep = ['not', deep]
    wide = ['pred', 0, []]
    for unused in range(8):
        call.tick()
        wide = ['imp', wide, wide]
    cases = [
        ['pred', True, []], ['pred', 3, []], ['pred', 0, [0]],
        ['not'], ['imp', ['pred', 0, []]], ['unknown', ['pred', 0, []]],
        {'tag': 'pred'}, ListSubclass(['pred', 0, []]), cycle, deep, wide,
    ]
    for formula in cases:
        call.tick()
        _expect_owned(selector, lambda f=formula: selector.inspect_formula(f, check=call.tick), call)
    unowned = selector.SelectorInputError('authored unowned message')
    call.need(selector.is_owned_error(unowned) is False, 'public construction unowned')
    _expect_owned(selector, lambda: selector.inspect_formula(['pred', 0, []], check=None), call)
    _expect_owned(selector, lambda: selector.select_inputs(check=None), call)
    return {'malformed_or_envelope_cases': 11, 'invalid_callback_entries': 2,
            'public_message_error_unowned': True, 'envelope_is_not_EOF': True}


def _selection_controls(selector, call):
    result = selector.select_inputs(check=call.tick)
    call.need(type(result) is dict and set(result) ==
              {'schema', 'program_id', 'status', 'complete', 'slots', 'prefixes', 'scope'},
              'selection exact keys')
    call.need(result['schema'] == 'nonwrapper-two-donor-input-selection-v1'
              and result['program_id'] == SELECTOR_VERSION and result['complete'] is True,
              'selection schema/version/complete')
    call.need(result['status'] in ('SELECTED', 'STOP_INPUT_CENSUS'), 'selection status')
    call.need(result['scope'] == 'Input-only eligibility, not primitive proof admission.',
              'exact selection scope literal')
    prefixes = result['prefixes']
    call.need(type(prefixes) is dict and list(prefixes) == list(STAGES), 'ordered stage prefixes')
    donors = []
    expected_winners = {}
    evidence = []
    stopped = False
    for stage_index, stage in enumerate(STAGES):
        call.tick()
        prefix = prefixes[stage]
        call.need(type(prefix) is dict and set(prefix) ==
                  {'stage', 'status', 'records', 'exhausted'} and prefix['stage'] == stage,
                  'stage prefix keys')
        records = prefix['records']
        call.need(type(records) is list, 'prefix records list')
        if stopped:
            call.need(prefix['status'] == 'NOT_STARTED' and records == []
                      and prefix['exhausted'] is None, 'not-started after EOF')
            evidence.append({'stage': stage, 'status': 'NOT_STARTED', 'records_checked': 0})
            continue
        walk = _PrefixWalk(BOUNDS[stage_index], call)
        winner = None
        for rank, row in enumerate(records):
            call.tick()
            call.need(type(row) is dict and set(row) == set(PREFIX_KEYS), 'prefix row keys')
            formula = walk.next()
            call.need(formula is not None, 'reported row after independent bounded EOF')
            facts = _facts(formula, call)
            expected = _prefix_row(rank, facts, stage_index, donors, call)
            call.need(_same(row, expected, call), 'independent next universe member/facts/reason')
            if expected['eligible']:
                call.need(rank == len(records) - 1, 'first winner must terminate prefix')
                winner = facts
        if winner is not None:
            call.need(prefix['status'] == 'SELECTED' and prefix['exhausted'] is False,
                      'selected prefix exhaustion carrier')
            expected_winners[stage] = winner
            if stage_index < 2:
                donors.append(winner['canonical_goal'])
            # Deliberately do not advance beyond this winner.
            evidence.append({'stage': stage, 'status': 'SELECTED',
                             'records_checked': len(records),
                             'winner_tokens': list(winner['tokens']),
                             'postwinner_members_inspected': 0})
        else:
            call.need(prefix['status'] == 'EOF' and prefix['exhausted'] is True,
                      'nonwinning stage must be actual EOF')
            call.need(walk.next() is None, 'omitted universe member before EOF')
            stopped = True
            evidence.append({'stage': stage, 'status': 'EOF', 'records_checked': len(records)})
    if stopped:
        call.need(result['status'] == 'STOP_INPUT_CENSUS' and result['slots'] is None,
                  'EOF suppresses all slots/acquisition authority')
    else:
        call.need(result['status'] == 'SELECTED', 'three winners status')
        slots = result['slots']
        call.need(type(slots) is dict and list(slots) == list(STAGES), 'ordered slots')
        for stage in STAGES:
            call.tick()
            slot = slots[stage]
            facts = expected_winners[stage]
            call.need(type(slot) is dict and set(slot) == {'query', 'inspection'}, 'slot exact keys')
            call.need(_same(slot['query'], _query(facts['canonical_goal']), call), 'all eight query fields')
            call.need(_same(slot['inspection'], facts, call), 'selected complete inspection')
        call.need(not _same(donors[0], donors[1], call), 'distinct complete donor trees')
    return result, {'stages': evidence, 'status': result['status'],
                    'independent_ordered_prefix_walk': True,
                    'finite_EOF_observed': stopped, 'no_postwinner_census': True}


def _fault_controls(selector, call):
    retained = _expect_owned(
        selector, lambda: selector.inspect_formula(['pred', True, []], check=call.tick), call)
    retained_args = retained.args
    retained_attributes = dict(vars(retained))
    cases = [StopIteration('intentional selector callback'),
             selector.SelectorInputError('unowned callback error'), retained,
             MemoryError('intentional selector callback')]
    observed = []
    for entry in ('inspect_formula', 'select_inputs'):
        for index, sentinel in enumerate(cases):
            call.tick()
            callback_count = [0]
            postfault_count = [0]
            later = RuntimeError('forbidden later callback F')

            def diagnostic_check():
                if callback_count[0]:
                    postfault_count[0] += 1
                    raise later
                call.tick()
                callback_count[0] += 1
                raise sentinel

            caught = None
            try:
                if entry == 'inspect_formula':
                    selector.inspect_formula(['pred', 0, []], check=diagnostic_check)
                else:
                    selector.select_inputs(check=diagnostic_check)
            except BaseException as error:
                if call.first is not None:
                    raise call.first
                caught = error
            call.need(callback_count[0] == 1 and postfault_count[0] == 0
                      and caught is sentinel, 'identical first callback/no later callback')
            if sentinel is retained:
                call.need(retained.args == retained_args and vars(retained) == retained_attributes,
                          'retained refusal data changed')
            observed.append({'entry': entry, 'fault_case': index,
                             'identity_preserved': True, 'postfault_callbacks': 0})
    return {'endpoints': observed, 'fault_positions': 'FIRST_PUBLIC_CALLBACK_ONLY',
            'retained_data_checked': 'args and vars; traceback/context not compared',
            'cleanup_observed': False}


def _isolation_controls(selector, selection, call):
    slots = selection['slots']
    if slots is None:
        return {'status': 'STOP_BRANCH_NO_SLOTS', 'selected_slot_checks': 0,
                'cross_call_check': 'covered by generic helper group'}
    sets = []
    for stage in STAGES:
        call.tick()
        slot = slots[stage]
        sets.append(_container_ids(slot, call))
        goal = slot['query']['goal']
        expected = _facts(goal, call)
        first = selector.inspect_formula(goal, check=call.tick)
        call.need(_same(first, expected, call), 'fresh selected-goal inspection')
        call.need(not (_container_ids(goal, call) & _container_ids(first, call)),
                  'selected caller goal alias')
        first['truth_values'].append(False)
        first['canonical_goal'].append('intentional mutation of returned copy')
        second = selector.inspect_formula(goal, check=call.tick)
        call.need(_same(second, expected, call), 'returned copy mutation affected later call')
        call.need(_same(slot['inspection'], expected, call), 'returned copy mutation affected slot')
        call.need(not (_container_ids(first, call) & _container_ids(second, call)),
                  'fresh repeated-call containers')
    for left in range(3):
        for right in range(left + 1, 3):
            call.tick()
            call.need(not (sets[left] & sets[right]), 'cross-slot mutable alias')
    return {'selected_slot_checks': 3, 'cross_slot_containers_disjoint': True,
            'returned_copy_mutation_isolated': True, 'selection_reused_for_search': False}


def run_nonwrapper_selector_controls(selector, *, fixtures, check):
    call = _Call(check)
    try:
        call.tick()
        call.need(type(fixtures) is dict and fixtures.get('schema') == FIXTURE_SCHEMA,
                  'frozen fixture document schema')
        before = _plain(fixtures, call)
        call.need(getattr(selector, 'VERSION', None) == SELECTOR_VERSION,
                  'exact prospective selector version')
        controls = []

        def add(index, evidence):
            call.tick()
            controls.append({'population': POPULATION, 'id': CONTROL_IDS[index],
                             'status': 'PASSED', 'evidence': _plain(evidence, call)})

        add(0, _literal_controls(selector, fixtures, call))
        add(1, _copy_controls(selector, fixtures, call))
        add(2, _malformed_controls(selector, call))
        selection, prefix_evidence = _selection_controls(selector, call)
        add(3, prefix_evidence)
        add(4, _fault_controls(selector, call))
        add(5, _isolation_controls(selector, selection, call))
        call.need(_same(fixtures, before, call), 'fixture document mutated')
        result = {'schema': RETURN_SCHEMA, 'version': VERSION, 'population': POPULATION,
                  'complete': True, 'control_ids': list(CONTROL_IDS), 'controls': controls,
                  'counts': {'groups': 6, 'passed': 6, 'failed': 0},
                  'scope': 'Independent selector endpoint qualification only; no proof/input admission',
                  'limits': ['EOF paths only if actually returned; no forced constant changes',
                             'Whole-donor match seen only through the fixed selection prefix',
                             'Callback probes only the first public callback of each endpoint',
                             'No observed cleanup or exhaustive fault-position claim',
                             'No runtime/resource-fit or semantic proof-method split claim'],
                  'callbacks': call.callbacks}
        ordinary = _plain(result, call)
        ordinary['callbacks'] = call.callbacks
        return ordinary
    except BaseException:
        if call.first is not None:
            raise call.first
        raise
