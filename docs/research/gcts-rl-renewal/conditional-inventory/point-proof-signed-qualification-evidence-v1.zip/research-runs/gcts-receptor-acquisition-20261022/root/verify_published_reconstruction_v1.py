"""Metadata-only complete HTTPS body comparison, no research imports or calls."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import urllib.parse


repo = Path(__file__).resolve().parents[3]
root = Path(__file__).resolve().parent
publisher = repo / "research-runs/gcts-batch-20261020/publisher-recovery-6338a77"
prefix = "docs/research/gcts-rl-renewal/conditional-inventory/"
names = ('point-proof-reconstruction-plan-data-v1.json', 'point-proof-reconstruction-plan-manifest-v1.json', 'point-proof-reconstruction-plan-evidence-v1.zip', 'point-proof-receptor-acquisition-manifest-v2.json', 'point-proof-receptor-acquisition-evidence-v2.zip', 'point-proof-receptor-acquisition-data-v1.json', 'point-proof-receptor-acquisition-manifest-v1.json', 'point-proof-receptor-acquisition-evidence-v1.zip', 'point-proof-matched-row-data-v1.json', 'point-proof-matched-row-manifest-v1.json', 'point-proof-matched-row-evidence-v1.zip', 'point-proof-fixed-slots-data-v1.json', 'point-proof-fixed-slots-manifest-v1.json', 'point-proof-fixed-slots-evidence-v1.zip', 'point-proof-constructor-index-data-v1.json', 'point-proof-constructor-index-manifest-v1.json', 'point-proof-constructor-index-evidence-v1.zip', 'point-proof-cohort-data-v1.json', 'point-proof-cohort-manifest-v1.json', 'point-proof-cohort-evidence-v1.zip', 'point-proof-search-v1.html', 'point-proof-first-actual-data-v1.json', 'point-proof-first-actual-manifest-v1.json', 'point-proof-first-actual-evidence-v1.zip', 'point-proof-controller-data-v1.json', 'point-proof-controller-manifest-v1.json', 'point-proof-controller-evidence-v1.zip', 'point-proof-source-data-v1.json', 'point-proof-source-manifest-v1.json', 'point-proof-source-evidence-v1.zip', 'point-proof-search-data-v1.json', 'point-proof-search-manifest-v1.json', 'point-proof-search-evidence-v1.zip', 'reader.html')
commit = sys.argv[1]
assert len(commit) == 40 and all(x in "0123456789abcdef" for x in commit)
out = root / "live-reconstruction-bodies-v1"
out.mkdir(exist_ok=True)
rows = []
for name in names:
    expected = (publisher / prefix / name).read_bytes()
    url = ("https://liuyao12.github.io/geometric-tree-search/" + prefix + name +
           "?" + urllib.parse.urlencode({"v": commit[:12]}))
    response = subprocess.run(("/usr/bin/curl", "--fail", "--silent", "--show-error", "--location",
                               "--max-time", "30", "--retry", "2", "--retry-delay", "1", "--retry-max-time", "60", url), stdout=subprocess.PIPE,
                              stderr=subprocess.PIPE, check=True)
    assert response.stdout == expected, "live complete body differs: " + name
    (out / name).write_bytes(response.stdout)
    rows.append({"name": name, "url": url, "bytes": len(response.stdout),
                 "sha256": hashlib.sha256(response.stdout).hexdigest(),
                 "complete": True, "matches_publisher": True})
record = {"schema": "Root-published-reconstruction-progress-live-body-verification-v1", "commit": commit,
          "normal_TLS_verification": True, "all_complete_bodies_match": True, "files": rows,
          "scientific_imports_calls": 0, "scientific_execution": False}
path = root / "published-reconstruction-live-body-verification-v1.json"
assert not path.exists()
path.write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({"record": str(path), "bytes": path.stat().st_size,
                  "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                  "all_complete_bodies_match": True, "files": len(rows)}, indent=2))
