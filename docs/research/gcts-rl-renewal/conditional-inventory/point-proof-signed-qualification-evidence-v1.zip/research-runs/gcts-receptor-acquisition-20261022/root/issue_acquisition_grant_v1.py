"""One exact metadata-only issuance after Root's fresh tools-idle observation."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import sys

ROOT=Path(__file__).resolve().parent


def read(path):
    return json.loads(Path(path).read_bytes())


def pin(path):
    p=Path(path)
    assert p.is_absolute() and p.resolve()==p and p.is_file() and not p.is_symlink()
    raw=p.read_bytes()
    return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


def verify(ref):
    assert pin(ref['path'])==ref


def emit(path,obj):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as f:
        f.write((json.dumps(obj,indent=2)+'\n').encode())
    return pin(path)


assert len(sys.argv)==2 and sys.argv[1] in ('0','1')
index=int(sys.argv[1])
prep_path=ROOT/'acquisition-study-preparation-v1.json'
accept_path=ROOT/'acquisition-Root-whole-prospective-acceptance-v1.json'
prep,accept=read(prep_path),read(accept_path)
assert accept['accepted_prospective_metadata'] is True and accept['preparation']==pin(prep_path)
for key in ('preparation','whole_review','worker_component_review','selector_component_review','bank_component_review'):
    verify(accept[key])
    if key!='preparation':
        assert read(accept[key]['path'])['review_passed'] is True
row=prep['cases'][index]
for key in ('plan','closure','proposal'):
    verify(row[key])
plan,closure,proposal=[read(row[k]['path'])for k in ('plan','closure','proposal')]
assert plan['donor_index']==index and plan['input_slot']=='donor'+str(index)
assert plan['experiment']=='receptor-two-donor-acquisition-v1'
assert plan['case_id']==proposal['case_id']==row['recipe']['case_id']
assert proposal['authorized'] is False and proposal['review_passed'] is False
assert type(proposal['uses'])is int and proposal['uses']==1
assert proposal['plan']==closure['plan']==row['plan'] and proposal['closure']==row['closure']
for key in ('protocol','component_review','selector_component_review','additive_bank_review'):
    verify(proposal[key])
assert proposal['component_review']==accept['worker_component_review']
assert proposal['selector_component_review']==accept['selector_component_review']
assert proposal['additive_bank_review']==accept['bank_component_review']
protocol=read(plan['protocol']['path'])
assert plan['protocol']==closure['protocol']==proposal['protocol']==prep['protocol']
assert protocol['job_recipes'][index]==row['recipe']
assert closure['files']==plan['files'] and len(plan['files'])==prep['shared_guards']
assert plan['module_pins']==protocol['module_pins'] and len(plan['module_pins'])==30
assert plan['control_populations']==protocol['control_populations'] and len(plan['control_populations'])==13
assert sum(x['groups']for x in plan['control_populations'].values())==198
assert plan['limits']==protocol['limits'] and len(plan['limits'])==10
assert plan['search_configuration']==protocol['search_configuration']
for ref in plan['files']:
    verify(ref)
absent=[Path(plan['actual_dir']),Path(plan['actual_dir']+'.observer'),Path(proposal['prospective_grant_path'])]
assert all(not p.exists()and not p.is_symlink()for p in absent)
now=datetime.now(timezone.utc).isoformat()
case=emit(ROOT/f'acquisition-donor-{index}-Root-prospective-acceptance-v1.json',dict(
    schema='Root-receptor-acquisition-case-prospective-acceptance-v1',issued_utc=now,accepted=True,
    case_id=plan['case_id'],plan=row['plan'],closure=row['closure'],proposal=row['proposal'],
    Root_batch_acceptance=pin(accept_path),whole_review=accept['whole_review'],
    metadata_issuer=pin(Path(__file__)),guards_current=len(plan['files']),
    namespaces=30,scoped_groups=198,absent_paths=[str(p)for p in absent],scientific_imports_calls=0))
barrier=emit(ROOT/f'acquisition-donor-{index}-all-tools-idle-barrier-v1.json',dict(
    schema='Root-receptor-acquisition-tools-idle-barrier-v1',issued_utc=now,case_id=plan['case_id'],
    acceptance=case,observation='Root called collaboration.list_agents immediately before issuance; B/L/C completed and tools idle. All earlier Root tool handles terminal, no server/browser/network or scientific work running. During actual only the same owned exec handle is polled.',
    scope='Current task tools; no exclusive operating-system ownership.',guards_rehashed=len(plan['files']),fresh_absence_checks=3))
grant={k:proposal[k]for k in ('uses','case_id','plan_sha256','runner_sha256','observer_sha256','plan','protocol','closure','component_review','selector_component_review','additive_bank_review')}
grant.update(schema='Root-receptor-acquisition-once-grant-v1',authorized=True,review_passed=True,
    issued_utc=now,whole_review=accept['whole_review'],case_proposal=row['proposal'],
    Root_prospective_acceptance=case,all_tools_idle_barrier=barrier,
    scope='One exact fixed donor once job. No consumed replay, retry/replacement, prefix adoption, library or automatic proof admission.')
gp=emit(Path(proposal['prospective_grant_path']),grant)
print(json.dumps(dict(grant=gp,acceptance=case,barrier=barrier,command=proposal['prospective_command'])))
