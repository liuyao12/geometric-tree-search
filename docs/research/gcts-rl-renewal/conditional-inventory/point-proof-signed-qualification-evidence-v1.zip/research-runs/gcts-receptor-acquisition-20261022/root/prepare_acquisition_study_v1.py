"""Metadata-only prospective plans. Never import or run scientific code."""
from pathlib import Path
import ast
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parent
R = ROOT.parent
REPO = R.parents[1]
N = REPO / 'research-runs/gcts-point-proof-search-20261022'


def read(path):
    return json.loads(Path(path).read_bytes())


def pin(path):
    path = Path(path).resolve()
    assert path.is_file() and not path.is_symlink() and '.partial' not in path.name
    body = path.read_bytes()
    return dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def verify(ref):
    assert pin(ref['path']) == ref


def emit(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write((json.dumps(value, indent=2) + '\n').encode())
    return pin(path)


assert len(sys.argv) == 2
worker_review_path = Path(sys.argv[1]).resolve()
selector_review_path = R / 'review-C/typed-two-donor-input-selector-complete-component-Source-review-v1.json'
bank_review_path = R / 'implementation-B/typed-two-donor-selector6-independent-bank-Source-review-v1.json'
reviews = [read(p) for p in (worker_review_path, selector_review_path, bank_review_path)]
assert all(x['review_passed'] is True for x in reviews)
worker = R / 'implementation-B/fpc_receptor_acquisition_worker_v1.py'
api_path = R / 'implementation-B/acquisition-worker-API-v1.json'
offer_path = R / 'implementation-B/acquisition-worker-dependency-offer-v1.json'
handoff_path = R / 'implementation-B/acquisition-worker-Source-handoff-v1.json'
api, offer = read(api_path), read(offer_path)
source = worker.read_bytes()
assert pin(worker)['sha256'] in json.dumps(reviews[0])
names = {'EXPERIMENT', 'PROTOCOL_SCHEMA', 'MODULE_ROLES', 'CONTROL_IDS', 'CAPS', 'PRODUCTION_CONFIGURATION'}
constants = {}
for node in ast.parse(source).body:
    if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
        if node.targets[0].id in names:
            constants[node.targets[0].id] = ast.literal_eval(node.value)
assert set(constants) == names
assert constants['EXPERIMENT'] == 'receptor-two-donor-acquisition-v1'
assert constants['PROTOCOL_SCHEMA'] == 'Root-FPC-receptor-acquisition-protocol-v1'
old = read(N / 'root/plans/matched-row-csp-point-v1-C0-target-3.json')
assert constants['CAPS'] == old['limits'] and len(constants['CAPS']) == 10
configuration = constants['PRODUCTION_CONFIGURATION']
assert configuration == dict(schema='FPC-H1-obligation-configuration-v1', control_only=False,
    variables=8, term_depth=2, fallback_witness_nodes=9, obligation_nodes=512,
    priority_subformula_nodes=512, intro_depth=8, oldest_period=4, ordering='FOCUSED')
modules = {x['role']: x['rawpin'] for x in offer['runtime_roles']}
assert len(modules) == len(offer['runtime_roles']) == len(constants['MODULE_ROLES']) == 30
assert set(modules) == set(constants['MODULE_ROLES'])
assert all(modules[role] == ref for role, ref in old['module_pins'].items())
assert {x['role']: {k: x[k] for k in ('path', 'bytes', 'sha256')} for x in api['runtime_roles']} == modules
for role, ref in modules.items():
    verify(ref)
    assert ref['sha256'].encode() in source
assert modules['selector']['sha256'] in json.dumps(reviews[1])
assert modules['selector_bank']['sha256'] in json.dumps(reviews[2])
populations = {x['population']: {k: x[k] for k in ('control_ids','groups','bank_role','subject_role','scope')}
    for x in api['scoped_populations']}
assert len(populations) == len(api['scoped_populations']) == 13
assert set(populations) == set(constants['CONTROL_IDS'])
assert all(populations[name] == obj for name, obj in old['control_populations'].items())
assert sum(x['groups'] for x in populations.values()) == 198
assert populations['selector6']['bank_role'] == 'selector_bank'
assert populations['selector6']['subject_role'] == 'selector'
for name, item in populations.items():
    assert item['control_ids'] == list(constants['CONTROL_IDS'][name])
    assert item['groups'] == len(item['control_ids'])
custody = {x['role']: x['rawpin'] for x in offer['custody_runtime']}
assert set(custody) == {'runner','observer','python'}
assert custody['python'] == old['python'] and custody['runner']['path'] == old['runner_path']
input_keys = {}
for row in offer['raw_inputs']:
    key = row['plan_key']
    assert key not in input_keys
    input_keys[key] = row['rawpin']
    verify(row['rawpin'])
    if key in old:
        assert row['rawpin'] == old[key]
guards = {}


def guard(ref):
    verify(ref)
    assert '/actual/' not in ref['path'] and not ref['path'].endswith('.bin')
    assert ref['path'] not in guards or guards[ref['path']] == ref
    guards[ref['path']] = ref


for ref in old['files'] + list(modules.values()) + list(custody.values()) + list(input_keys.values()) + offer['semantic_guards']:
    guard(ref)
for path in (worker, api_path, offer_path, handoff_path, Path(__file__), worker_review_path,
    selector_review_path, bank_review_path, ROOT/'receptor-acquisition-Root-design-decision-v1.json',
    ROOT/'two-donor-selector-Root-API-acceptance-v1.json',
    ROOT/'issue_acquisition_grant_v1.py', ROOT/'census_acquisition_case_v1.py',
    R/'diagnostics-L/ordinary-acquisition-independent-expectations-v1.json'):
    guard(pin(path))
for path, field in ((ROOT/'two-donor-input-selector-Source-handoff-v1.json','files'),
    (N/'diagnostics-L/two-donor-input-selector-handoff-v1.json','files'),
    (N/'diagnostics-L/two-donor-selector-independent-controls-handoff-v1.json','files'),
    (handoff_path,'files')):
    obj = read(path)
    guard(pin(path))
    for ref in obj[field]:
        guard(ref)
recipes = [dict(case_id=constants['EXPERIMENT']+'-donor-'+str(i), donor_index=i, input_slot='donor'+str(i)) for i in range(2)]
for recipe in recipes:
    actual = R/'actual'/recipe['case_id']
    for path in (actual, Path(str(actual)+'.observer'), ROOT/'grants'/(recipe['case_id']+'.json'),
        ROOT/'plans'/(recipe['case_id']+'.json')):
        assert not path.exists() and not path.is_symlink()
protocol = emit(ROOT/'acquisition-whole-protocol-v1.json', dict(
    schema=constants['PROTOCOL_SCHEMA'], experiment=constants['EXPERIMENT'], limits=constants['CAPS'],
    module_pins=modules, control_populations=populations, job_recipes=recipes, search_configuration=configuration,
    metadata=dict(status='PROSPECTIVE_NO_EXECUTION',
        design=pin(ROOT/'receptor-acquisition-Root-design-decision-v1.json'),
        selector_contract=pin(N/'diagnostics-L/two-donor-input-selector-contract-v1.json'),
        acquisition='Two separately cold once jobs. Each freezes/encodes allthree fixed input slots before controls/search; search only its chosen donor with unchanged ordinaryproducer2 full FOCUSED, modules checker/builders, progressNone. No targetproof/route/library.',
        population='All28 original namespacepins/all192 complete scoped subject objects preserved; selector6 additive. 30roles/13populations/198groups, not198 directtests of one component.',
        stages=['Exact Source/protocol/plan custody and cold imports','Fixed input-only selection; all3semanticquery/byte freezes','Fresh complete198 scopedgroups','Chosen donor ordinary acquisition only','Same-byte original subject/reference complete validation','Nonadmitting point representation','Complete output/resource custody then external C/Root review'],
        success='Both distinct whole-qualified proofs and C/Root admissions or STOP_ACQUISITION. No replacement/retry/prefix uptake. A candidate is not an admitted proof. Library extraction separately reviewed after BOTH admissions.',
        negative='Deadline/resource/fault/missing proof/UNKNOWN/outside gives no unprovability. Fault sets allsevenpositivefieldsnull/qualificationfalse. No failed search progress/getter.',
        cohort_failure='Both prescribed jobs may run once independently even if the first has a normal resource/search negative; no extraction unless both admitted. A shared functional Source/custody defect stops the remaining unrun job.',
        holdout='Structural input-only split, frozen before donor outcomes; unsearched in acquisition-only stage. No proof-method/formula-substitution independence claim.',
        science='Ordinary symbolic training acquisition, not GCTS/RL or provider6/frame equivalence, no discovery novelty/speed advantage inferred.',
        cost='All cold hashing/imports/selector/encoding/198 scoped controls/search/validation/output included within each unchangedten-cap once envelope. No amortization.',
        execution_authority=False)))
guard(protocol)
files = [guards[k] for k in sorted(guards)]
cases=[]
for recipe in recipes:
    actual=R/'actual'/recipe['case_id']
    plan=dict(old, **recipe, stage='acquire', experiment=constants['EXPERIMENT'], actual_dir=str(actual),
        worker_path=str(worker), protocol=protocol, files=files, module_pins=modules,
        control_populations=populations, search_configuration=configuration)
    for stale in ('arm','target_index','target_id'):
        plan.pop(stale,None)
    plan.update(input_keys)
    pp=emit(ROOT/'plans'/(recipe['case_id']+'.json'),plan)
    cp=emit(ROOT/f"acquisition-donor-{recipe['donor_index']}-Source-closure-v1.json",dict(
        schema='Root-receptor-acquisition-closed-Source-v1',status='PROSPECTIVE_NOT_AUTHORITY',
        plan=pp,protocol=protocol,files=files,namespace_count=30,scoped_group_count=198,
        module_roles_in_execution_order=list(constants['MODULE_ROLES']),
        original_guard_count_retained=len(old['files']),original192_complete_population_objects_retained=True,
        scope='Explicit current runtime/input roles plus original Sourceguards, no recursive citation or prior actual intake.',
        scientific_imports_calls=0))
    gp=emit(ROOT/f"acquisition-donor-{recipe['donor_index']}-grant-proposal-v1.json",dict(
        schema='Root-receptor-acquisition-once-proposal-v1',authorized=False,review_passed=False,uses=1,
        case_id=recipe['case_id'],plan_sha256=pp['sha256'],runner_sha256=custody['runner']['sha256'],
        observer_sha256=custody['observer']['sha256'],plan=pp,protocol=protocol,closure=cp,
        component_review=pin(worker_review_path),selector_component_review=pin(selector_review_path),
        additive_bank_review=pin(bank_review_path),
        prospective_grant_path=str(ROOT/'grants'/(recipe['case_id']+'.json')),
        prospective_command=[custody['python']['path'],'-I','-S','-B',custody['observer']['path'],pp['path'],str(ROOT/'grants'/(recipe['case_id']+'.json'))],
        required_before_grant=['Complete independent whole Source/plan/proposal review','Root acceptance/current guards/fresh tools-idle','Separate exact one-use true grant'],execution_authority=False))
    cases.append(dict(recipe=recipe,plan=pp,closure=cp,proposal=gp))
print(json.dumps(emit(ROOT/'acquisition-study-preparation-v1.json',dict(
    schema='Root-two-donor-acquisition-preparation-v1',status='PROSPECTIVE_REQUIRES_WHOLE_REVIEW',
    metadata_builder=pin(Path(__file__)),worker=pin(worker),worker_component_review=pin(worker_review_path),
    selector_component_review=pin(selector_review_path),bank_component_review=pin(bank_review_path),
    protocol=protocol,cases=cases,shared_guards=len(files),namespaces=30,scoped_populations=13,scoped_groups=198,
    all225previous_guards_preserved=True,original192_population_objects_preserved=True,
    ten_caps_unchanged=True,all_false_proposals=True,scientific_imports_calls=0,goal_complete=False)),indent=2))
