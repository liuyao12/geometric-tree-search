"""Display and raw evidence packaging only; never imports research components."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent
STUDY = ROOT.parent
REPO = ROOT.parents[2]
OLD = ROOT / 'publication-reconstruction-v1'
OUT = ROOT / 'publication-signed-qualification-v1'


def pin(path):
    body = path.read_bytes()
    return dict(path=str(path.relative_to(REPO)), bytes=len(body),
                sha256=hashlib.sha256(body).hexdigest())


def emit(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


disposition_path = ROOT / 'signed-qualification-Root-whole-disposition-v1.json'
disposition = json.loads(disposition_path.read_bytes())
assert disposition['accepted_whole_negative_evidence'] is True
assert disposition['qualification_admitted'] is False
assert disposition['new_target_proofs'] == 0
review = disposition['independent_whole_review']
review_path = Path(review['path'])
body = review_path.read_bytes()
assert len(body) == review['bytes'] and hashlib.sha256(body).hexdigest() == review['sha256']
assert json.loads(body)['review_passed'] is True
metrics = disposition['metrics']
OUT.mkdir(exist_ok=False)

status = dict(schema='GCTS-signed-qualification-negative-public-result-v1',
    published_snapshot_utc=datetime.now(timezone.utc).isoformat(),
    status='WHOLE_WORK_DEADLINE_NOT_QUALIFIED', new_actuals=1, new_target_proofs=0,
    qualification_admitted=False, gcts_advantage_established=False,
    rl_advantage_established=False, learned_inventory=False,
    population=dict(groups=212, scopes=15, wrappers=14, namespaces=35,
                    retained_groups=198, added_selector_groups=6, added_signed_groups=8),
    metrics=metrics, disposition=pin(disposition_path), independent_review=pin(review_path),
    source_status='Selector, compiler, producer and independent banks written and manually reviewed. Whole runtime qualification failed; no completed-bank prefix admitted.',
    interpretation='The stopped stack is in primitive export/formula encoding. It identifies a cutoff location, not a measured dominant cost or allocation profile. Static reachability/expansion/encoding amplification and proposed improvements remain untested.',
    next='Review generic compiler cost and bounded scalar observability before any distinct prospective successor study. Preserve all original caps/populations and the consumed case. No retry, proof recovery or research donor uptake.',
    scope='Ordinary baseline infrastructure, no new research theorem, learned lemma family, GCTS/RL or transfer result. Original acquisition cohort remains STOP. Earlier Source-only panel is a historical frozen snapshot.')
data_path = OUT / 'point-proof-signed-qualification-data-v1.json'
emit(data_path, status)

bs = chr(92)
def math(text):
    return bs + '(' + text.replace('@', bs) + bs + ')'

panel = '''<section class="panel" id="signed-qualification">
<p class="eyebrow">Latest experiment · whole failure retained</p>
<h2>Parallel development exposed a practical compiler limit</h2>
<p>The selector, ordinary signed searcher, primitive compiler and independent test banks are now written. Separate source reviews found and closed a diagnostic-schema mismatch and a metadata-carrier mismatch before execution. One fresh combined qualification run then failed at its work deadline. No complete test-suite qualification or research proof was admitted.</p>
<div class="baseline-flow qualification-flow" role="group" aria-label="Parallel responsibilities and observed whole-run outcome">
<article><span class="pill">Implementation agent</span><h3>Search and compilation</h3><p>Generic signed search and expansion into the original primitive proof calculus. No target proof was supplied.</p></article>
<article><span class="pill">Independent test agent</span><h3>Separate expectations</h3><p>Literal rule cases, malformed inputs, countermodels, ownership and fault checks were specified independently of the new algorithm.</p></article>
<article><span class="pill">Review agent</span><h3>Source and evidence</h3><p>Reviewed the complete components, frozen run plan and saved whole failure. This review does not replace execution.</p></article>
<article class="qualification-negative"><span class="pill">Root integration</span><h3>Whole run failed</h3><p>All agents were idle during the one timed run. The complete combined suite did not finish within its work budget.</p></article>
</div>
<div class="scroll"><table><thead><tr><th>Recorded quantity</th><th>Evidence</th></tr></thead><tbody>
<tr><td>Frozen test population</td><td>GROUPS groups across SCOPES scopes and WRAPPERS bank wrappers; original OLDGROUPS retained, SELECTOR new selector groups and SIGNED signed groups added.</td></tr>
<tr><td>Configured whole-work limit</td><td>WORKLIMIT; the first Root fault says <code>absolute whole-work deadline</code>.</td></tr>
<tr><td>Observer completion clock</td><td>OBSERVED, including the complete run and its termination. This differs from the work-limit setting.</td></tr>
<tr><td>Saved Root callback count</td><td>CALLBACKS. No complete compiler row or expanded-byte census was returned.</td></tr>
<tr><td>Cutoff location</td><td>The signed test bank was active; the saved stack ends in primitive proof export and formula encoding. This is not a cost profile.</td></tr>
<tr><td>Admission</td><td>Qualification false; all seven positive payloads null; no partial suite, target proof, learned family or transfer result admitted.</td></tr>
</tbody></table></div>
<p style="margin-top:18px">The worker reported unchanged sources. The custodian and observer both rejected the case, with no qualified whole-memory bound. The configured budget and test population remain fixed; the consumed case is closed.</p>
<details style="margin-top:18px"><summary>What the negative result tells us</summary><p style="margin-top:12px">Primitive proof expansion is a practical obstacle even before comparing learned search strategies. Source inspection shows repeated scans of retained intermediate rows and repeated serialization of expanded formulas. Those are concrete static costs; the saved failure does not show which dominates this run. The next design work concerns generic reachability and encoding reuse, plus inexpensive scalar diagnostics. No optimization has been tested or accepted by this update.</p></details>
<p style="margin-top:18px"><strong>Research assessment.</strong> Parallel implementation, independent testing and review are producing useful engineering evidence. They have not yet established a useful learned inventory, a GCTS/RL search advantage or a new research theorem. This update supersedes the runtime status of the earlier Source-only snapshot below.</p>
<p><a href="point-proof-signed-qualification-data-v1.json">Result and scope</a> · <a href="point-proof-signed-qualification-evidence-v1.zip">Complete source and failure evidence</a> · <a href="point-proof-signed-qualification-manifest-v1.json">Manifest</a></p>
</section>'''
replacements = dict(GROUPS=math('212'), SCOPES=math('15'), WRAPPERS=math('14'),
                       OLDGROUPS=math('198'), SELECTOR=math('6'), SIGNED=math('8'),
                       WORKLIMIT=math('160@,@mathrm{s}'),
                       OBSERVED=math(f"{metrics['observer_elapsed_seconds']:.3f}@,@mathrm{{s}}"),
                       CALLBACKS=math(str(metrics['Root_callbacks'])))
for key in sorted(replacements, key=len, reverse=True):
    panel = panel.replace(key, replacements[key])
page = (OLD / 'point-proof-search-v1.html').read_text()
anchor = '<section class="panel" id="compiler-progress">'
assert page.count(anchor) == 1 and 'id="signed-qualification"' not in page
page = page.replace(anchor, panel + anchor, 1)
page = page.replace('<nav><a href="#compiler-progress">', '<nav><a href="#signed-qualification">Latest qualification</a><a href="#compiler-progress">', 1)
page = page.replace('</style>', '.qualification-negative{border-top-color:var(--red,#a83735)!important;background:#fff4f1!important}</style>', 1)
page_path = OUT / 'point-proof-search-v1.html'
page_path.write_text(page)

old_manifest_path = OLD / 'point-proof-reconstruction-plan-manifest-v1.json'
old_manifest = json.loads(old_manifest_path.read_bytes())
with zipfile.ZipFile(OLD / 'point-proof-reconstruction-plan-evidence-v1.zip') as archive:
    bodies = {row['path']: archive.read(row['path']) for row in old_manifest['members']}
references = {row['path']: row for row in old_manifest['members']}
extras = [Path(__file__), disposition_path, review_path, old_manifest_path,
          OLD / 'point-proof-search-v1.html']
for folder in [ROOT, STUDY / 'implementation-B', STUDY / 'diagnostics-L', STUDY / 'review-C']:
    extras.extend(p for p in folder.iterdir() if p.is_file() and not p.is_symlink()
                  and p.suffix in ('.py', '.json', '.patch'))
case = disposition['case_id']
for folder in [STUDY / 'actual' / case, STUDY / 'actual' / (case + '.observer')]:
    extras.extend(p for p in folder.iterdir() if p.is_file() and not p.is_symlink())
for folder in [ROOT / 'plans', ROOT / 'grants']:
    extras.append(folder / (case + '.json'))
for path in extras:
    ref = pin(path)
    body = path.read_bytes()  # Partial files, if present, are opaque raw bodies only.
    if ref['path'] in references:
        assert references[ref['path']] == ref and bodies[ref['path']] == body
    references[ref['path']], bodies[ref['path']] = ref, body
manifest = dict(schema='GCTS-signed-qualification-negative-manifest-v1',
    members=[references[name] for name in sorted(references)],
    raw_member_count=len(references), raw_member_bytes=sum(x['bytes'] for x in references.values()),
    predecessor_raw_members_preserved=len(old_manifest['members']),
    external_runtime=old_manifest['external_runtime'], public_page=pin(page_path),
    public_status=pin(data_path), scientific_imports_calls=0,
    scope='Raw preservation and display only. One reviewed whole negative actual; zero new target proofs or admitted qualification. Historical evidence remains byte-identical. Partial bodies are never parsed. No scientific implementation imported/called by this builder.')
manifest_path = OUT / 'point-proof-signed-qualification-manifest-v1.json'
emit(manifest_path, manifest)
archive_path = OUT / 'point-proof-signed-qualification-evidence-v1.zip'
with zipfile.ZipFile(archive_path, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name in sorted(bodies):
        body, ref = bodies[name], references[name]
        assert len(body) == ref['bytes'] and hashlib.sha256(body).hexdigest() == ref['sha256']
        archive.writestr(name, body)
    archive.writestr('MANIFEST.json', manifest_path.read_bytes())
    archive.writestr('PUBLIC-RESULT.json', data_path.read_bytes())
    archive.writestr('README.txt', 'One whole qualification failure, no qualified prefix or research target proof. All predecessor raw evidence preserved. No scientific code executed by packaging.\n')
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None and len(archive.namelist()) == len(references) + 3
    for name, body in bodies.items():
        assert archive.read(name) == body
print(json.dumps(dict(files=[pin(p) for p in sorted(OUT.iterdir())],
                      raw_members=len(references)), indent=2))
