"""Fixed non-wrapper input selector. Source only until a reviewed once actual.

Boolean classification selects inputs; it never supplies proof authority.
No search, codec, prior result, learned state, or filesystem is a dependency.
"""

VERSION = 'FPC-NONWRAPPER-TWO-DONOR-INPUT-SELECTOR-v1'
_OWNER = object()
_SCOPE = 'Input-only eligibility, not primitive proof admission.'
_STAGES = (('donor0', 11, 6, 2, 1, None),
           ('donor1', 13, 6, 3, 0, 0),
           ('holdout0', 15, 7, 3, 1, None))
_PATTERNS = (
    ('imp', 'A', ('imp', 'B', 'A')),
    ('imp', ('imp', 'A', ('imp', 'B', 'C')),
     ('imp', ('imp', 'A', 'B'), ('imp', 'A', 'C'))),
    ('imp', ('imp', ('not', 'B'), ('not', 'A')), ('imp', 'A', 'B')),
)


class SelectorInputError(ValueError):
    """Public construction alone has no refusal provenance."""


def is_owned_error(error):
    return type(error) is SelectorInputError and getattr(error, '_owner', None) is _OWNER


class _Call:
    def __init__(self, check):
        self.check, self.first, self.token = check, None, object()

    def fault(self):
        if self.first is not None:
            raise self.first

    def need(self, condition, message):
        self.fault()
        if not condition:
            error = SelectorInputError(message)
            error._owner, error._call = _OWNER, self.token
            raise error

    def tick(self):
        self.fault()
        try:
            self.check()
        except BaseException as error:
            self.first = error
            raise

    def start(self):
        self.need(callable(self.check), 'genuine callable check required')
        self.tick()


def _equal(left, right, call):
    pending = [(left, right)]
    while pending:
        call.tick()
        a, b = pending.pop()
        if type(a) is not type(b):
            return False
        if type(a) is tuple:
            if len(a) != len(b):
                return False
            for index in range(len(a) - 1, -1, -1):
                call.tick()
                pending.append((a[index], b[index]))
        elif a != b:
            return False
    return True


def _canonical(raw, call):
    atoms, count = {}, [0]

    def visit(node, depth):
        call.tick()
        count[0] += 1
        call.need(depth <= 32 and count[0] <= 256, 'bounded expanded formula tree')
        call.need(type(node) in (list, tuple) and len(node) > 0 and type(node[0]) is str,
                  'ordinary typed formula node')
        tag = node[0]
        if tag == 'pred':
            call.need(len(node) == 3 and type(node[1]) is int and 0 <= node[1] <= 2,
                      'exact nullary predicate ID')
            call.need(type(node[2]) in (list, tuple) and len(node[2]) == 0,
                      'nullary predicate arguments')
            if node[1] not in atoms:
                atoms[node[1]] = len(atoms)
            return ('pred', atoms[node[1]], ()), 0
        if tag == 'not':
            call.need(len(node) == 2, 'negation fields')
            body, height = visit(node[1], depth + 1)
            return ('not', body), height + 1
        call.need(tag == 'imp' and len(node) == 3, 'propositional constructor')
        left, left_height = visit(node[1], depth + 1)
        right, right_height = visit(node[2], depth + 1)
        return ('imp', left, right), 1 + max(left_height, right_height)

    tree, depth = visit(raw, 0)
    return tree, count[0], depth, len(atoms)


def _vector(values, call):
    result = []
    for value in values:
        call.tick()
        result.append(value)
    return result


def _ordinary(tree, call):
    call.tick()
    if tree[0] == 'pred':
        return ['pred', tree[1], []]
    if tree[0] == 'not':
        return ['not', _ordinary(tree[1], call)]
    return ['imp', _ordinary(tree[1], call), _ordinary(tree[2], call)]


def _tokens(tree, call):
    result, pending = [], [tree]
    while pending:
        call.tick()
        node = pending.pop()
        if node[0] == 'pred':
            result.extend((0, node[1]))
        elif node[0] == 'not':
            result.append(1)
            pending.append(node[1])
        else:
            result.append(2)
            pending.append(node[2])
            pending.append(node[1])
    return result


def _evaluate(tree, assignment, atom_count, call):
    call.tick()
    if tree[0] == 'pred':
        return bool((assignment >> (atom_count - 1 - tree[1])) & 1)
    if tree[0] == 'not':
        return not _evaluate(tree[1], assignment, atom_count, call)
    left = _evaluate(tree[1], assignment, atom_count, call)
    right = _evaluate(tree[2], assignment, atom_count, call)
    return (not left) or right


def _truth(tree, atom_count, call):
    values, tautology = [], True
    for assignment in range(1 << atom_count):
        call.tick()
        value = _evaluate(tree, assignment, atom_count, call)
        values.append(value)
        tautology = tautology and value
    return values, tautology


def _structure(tree, atom_count, call):
    counts, not_count, adjacent = [0] * atom_count, 0, False
    pending = [tree]
    while pending:
        call.tick()
        node = pending.pop()
        if node[0] == 'pred':
            counts[node[1]] += 1
        elif node[0] == 'not':
            not_count += 1
            adjacent = adjacent or node[1][0] == 'not'
            pending.append(node[1])
        else:
            pending.append(node[2])
            pending.append(node[1])
    identity = tree[0] == 'imp' and _equal(tree[1], tree[2], call)
    return counts, not_count, adjacent, identity


def _match(pattern, tree, bindings, call):
    call.tick()
    if type(pattern) is str:
        if pattern in bindings:
            return _equal(bindings[pattern], tree, call)
        bindings[pattern] = tree
        return True
    if pattern[0] != tree[0] or len(pattern) != len(tree):
        return False
    for index in range(1, len(pattern)):
        call.tick()
        if not _match(pattern[index], tree[index], bindings, call):
            return False
    return True


def _axioms(tree, call):
    result = []
    for tag, pattern in enumerate(_PATTERNS):
        call.tick()
        if _match(pattern, tree, {}, call):
            result.append(tag)
    return result


def _donor_match(pattern, tree, bindings, call):
    call.tick()
    if pattern[0] == 'pred':
        key = pattern[1]
        if key in bindings:
            return _equal(bindings[key], tree, call)
        bindings[key] = tree
        return True
    if pattern[0] != tree[0] or len(pattern) != len(tree):
        return False
    for index in range(1, len(pattern)):
        call.tick()
        if not _donor_match(pattern[index], tree[index], bindings, call):
            return False
    return True


def _proper(tree, call):
    result, pending = [], []

    def children(node, path):
        call.tick()
        if node[0] == 'not':
            pending.append((node[1], path + (0,)))
        elif node[0] == 'imp':
            pending.append((node[2], path + (1,)))
            pending.append((node[1], path + (0,)))

    children(tree, ())
    while pending:
        call.tick()
        node, path = pending.pop()
        local, _, _, atom_count = _canonical(node, call)
        truth, tautology = _truth(local, atom_count, call)
        if tautology:
            result.append(dict(path=_vector(path, call), tokens=_tokens(local, call),
                               atom_count=atom_count, truth_values=truth))
        children(node, path)
    return result


def _inspect(raw, call):
    tree, size, depth, atom_count = _canonical(raw, call)
    counts, not_count, adjacent, identity = _structure(tree, atom_count, call)
    values, tautology = _truth(tree, atom_count, call)
    return tree, dict(schema='nonwrapper-formula-inspection-v1', complete=True,
        canonical_goal=_ordinary(tree, call), tokens=_tokens(tree, call),
        expanded_nodes=size, depth=depth, atom_count=atom_count,
        atom_occurrences=counts, not_count=not_count, root_is_imp=tree[0] == 'imp',
        has_adjacent_not=adjacent, whole_identity=identity, truth_values=values,
        tautology=tautology, proper_tautologies=_proper(tree, call),
        single_axiom_subtags=_axioms(tree, call))


def inspect_formula(formula, *, check):
    call = _Call(check)
    try:
        call.start()
        result = _inspect(formula, call)[1]
        call.tick()
        return result
    except BaseException:
        call.fault()
        raise


def _from_tokens(tokens, call):
    cursor = [0]

    def visit():
        call.tick()
        tag = tokens[cursor[0]]
        cursor[0] += 1
        if tag == 0:
            atom = tokens[cursor[0]]
            cursor[0] += 1
            return ('pred', atom, ())
        if tag == 1:
            return ('not', visit())
        left = visit()
        return ('imp', left, visit())

    result = visit()
    call.need(cursor[0] == len(tokens), 'internal complete prefix encoding')
    return result


def _constrained(stage, call):
    _, max_size, max_depth, atom_count, min_not, max_not = stage

    def walk(tokens, pending, built, next_atom, counts, not_count, target):
        call.tick()
        remaining = target - built
        if remaining < len(pending):
            return
        needed = 0
        for count in counts:
            call.tick()
            needed += max(0, 2 - count)
        if remaining < needed:
            return
        if not pending:
            if remaining != 0 or next_atom != atom_count or not_count < min_not:
                return
            tree = _from_tokens(tokens, call)
            if not _equal(tree[1], tree[2], call):
                yield tree
            return
        depth, parent_not = pending[-1]
        if depth > max_depth or remaining == 0:
            return
        rest = pending[:-1]
        # Every prefix has at most thirty tokens; these bounded copies are
        # charged by the enclosing choice checkpoint and per-element loops.
        for atom in range(min(next_atom + 1, atom_count)):
            call.tick()
            copied_tokens = _vector(tokens, call)
            copied_tokens.extend((0, atom))
            copied_counts = _vector(counts, call)
            copied_counts[atom] += 1
            yield from walk(copied_tokens, rest, built + 1,
                            max(next_atom, atom + 1), copied_counts, not_count, target)
        if not parent_not and (max_not is None or not_count < max_not):
            call.tick()
            copied_tokens = _vector(tokens, call)
            copied_tokens.append(1)
            children = _vector(rest, call)
            children.append((depth + 1, True))
            yield from walk(copied_tokens, children, built + 1, next_atom,
                            counts, not_count + 1, target)
        call.tick()
        copied_tokens = _vector(tokens, call)
        copied_tokens.append(2)
        children = _vector(rest, call)
        children.extend(((depth + 1, False), (depth + 1, False)))
        yield from walk(copied_tokens, children, built + 1, next_atom,
                        counts, not_count, target)

    for size in range(1, max_size + 1):
        call.tick()
        yield from walk([2], [(1, False), (1, False)], 1, 0,
                        [0] * atom_count, 0, size)


def _prefix_row(tree, rank, donors, is_holdout, call):
    canonical, size, depth, atom_count = _canonical(tree, call)
    counts, not_count, adjacent, identity = _structure(canonical, atom_count, call)
    call.need(not adjacent and not identity, 'internal constrained universe')
    values, tautology = _truth(canonical, atom_count, call)
    proper, axioms, matches = None, None, None
    if not tautology:
        reason = 'NOT_TAUTOLOGY'
    else:
        proper = _proper(canonical, call)
        if proper:
            reason = 'PROPER_TAUTOLOGY'
        else:
            axioms = _axioms(canonical, call)
            if axioms:
                reason = 'SINGLE_AXIOM'
            else:
                if is_holdout:
                    matches = []
                    for donor in donors:
                        call.tick()
                        matches.append(_donor_match(donor, canonical, {}, call))
                    call.need(len(matches) == 2, 'two frozen donor inputs')
                reason = ('WHOLE_DONOR_INSTANCE' if matches is not None and
                          (matches[0] or matches[1]) else 'SELECTED')
    return dict(rank=rank, tokens=_tokens(canonical, call), expanded_nodes=size,
        depth=depth, atom_count=atom_count, atom_occurrences=counts, not_count=not_count,
        truth_values=values, tautology=tautology, proper_tautologies=proper,
        single_axiom_subtags=axioms, whole_donor_matches=matches,
        eligible=reason == 'SELECTED', reason=reason)


def _slot(tree, call):
    _, inspection = _inspect(tree, call)
    query = dict(version=1, claim_mode=0, function_arities=[], predicate_arities=[0, 0, 0],
                 theory_profile=0, finite_axioms=[], Gamma=[], goal=_ordinary(tree, call))
    return dict(query=query, inspection=inspection)


def _selection(call):
    prefixes, slots, donors = {}, {}, []
    for stage in _STAGES:
        call.tick()
        key = stage[0]
        prefixes[key] = dict(stage=key, status='NOT_STARTED', records=[], exhausted=None)
    for stage in _STAGES:
        call.tick()
        key, records, winner = stage[0], [], None
        for tree in _constrained(stage, call):
            call.tick()
            row = _prefix_row(tree, len(records), donors, key == 'holdout0', call)
            records.append(row)
            if row['eligible']:
                winner = tree
                break
        if winner is None:
            prefixes[key] = dict(stage=key, status='EOF', records=records, exhausted=True)
            call.tick()
            return dict(schema='nonwrapper-two-donor-input-selection-v1', program_id=VERSION,
                        status='STOP_INPUT_CENSUS', complete=True, slots=None,
                        prefixes=prefixes, scope=_SCOPE)
        prefixes[key] = dict(stage=key, status='SELECTED', records=records, exhausted=False)
        slots[key] = _slot(winner, call)
        if key != 'holdout0':
            if donors:
                call.need(not _equal(donors[0], winner, call), 'distinct donor inputs')
            donors.append(winner)
    call.tick()
    return dict(schema='nonwrapper-two-donor-input-selection-v1', program_id=VERSION,
                status='SELECTED', complete=True, slots=slots, prefixes=prefixes, scope=_SCOPE)


def select_inputs(*, check):
    call = _Call(check)
    try:
        call.start()
        return _selection(call)
    except BaseException:
        call.fault()
        raise
