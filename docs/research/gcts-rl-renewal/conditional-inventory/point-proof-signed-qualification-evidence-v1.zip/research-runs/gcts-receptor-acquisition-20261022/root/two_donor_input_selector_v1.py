"""Fixed input-only propositional selection; Source only until a reviewed actual.

No search, query writer, proof, file, prior result or learned state is imported.
Truth tables classify inputs only. They never issue proof authority.
"""

VERSION = 'FPC-TWO-DONOR-INPUT-SELECTOR-v1'
_OWNER = object()
_SCOPE = 'Input-only propositional acquisition; Boolean eligibility is not proof admission.'
_PATTERNS = (
    ('imp', 'A', ('imp', 'B', 'A')),
    ('imp', ('imp', 'A', ('imp', 'B', 'C')),
     ('imp', ('imp', 'A', 'B'), ('imp', 'A', 'C'))),
    ('imp', ('imp', ('not', 'B'), ('not', 'A')), ('imp', 'A', 'B')),
)


class SelectorInputError(ValueError):
    """Public construction alone has no refusal provenance."""


def is_owned_error(error):
    return type(error) is SelectorInputError and getattr(error, '_owner', None) is _OWNER


class _Call:
    def __init__(self, check):
        self.check, self.first, self.token = check, None, object()

    def fault(self):
        if self.first is not None:
            raise self.first

    def tick(self):
        self.fault()
        try:
            self.check()
        except BaseException as error:
            self.first = error
            raise

    def need(self, condition, message):
        self.fault()
        if not condition:
            error = SelectorInputError(message)
            error._owner, error._call = _OWNER, self.token
            raise error


def _canonical(raw, call):
    atoms, count = {}, [0]

    def visit(node, depth):
        call.tick()
        count[0] += 1
        call.need(depth <= 32 and count[0] <= 256, 'bounded expanded tree')
        call.need(type(node) in (list, tuple) and len(node) > 0 and type(node[0]) is str,
                  'ordinary typed formula node')
        tag = node[0]
        if tag == 'pred':
            call.need(len(node) == 3 and type(node[1]) is int and 0 <= node[1] <= 2,
                      'exact nullary predicate ID')
            call.need(type(node[2]) in (list, tuple) and len(node[2]) == 0, 'nullary atom')
            if node[1] not in atoms:
                atoms[node[1]] = len(atoms)
            return ('pred', atoms[node[1]], ()), 0
        if tag == 'not':
            call.need(len(node) == 2, 'negation fields')
            body, height = visit(node[1], depth + 1)
            return ('not', body), height + 1
        call.need(tag == 'imp' and len(node) == 3, 'propositional constructor')
        left, left_height = visit(node[1], depth + 1)
        right, right_height = visit(node[2], depth + 1)
        return ('imp', left, right), 1 + max(left_height, right_height)

    tree, depth = visit(raw, 0)
    return tree, count[0], depth, len(atoms)


def _equal(left, right, call):
    pending = [(left, right)]
    while pending:
        call.tick()
        a, b = pending.pop()
        if type(a) is not type(b):
            return False
        if type(a) is tuple:
            if len(a) != len(b):
                return False
            for index in range(len(a) - 1, -1, -1):
                call.tick()
                pending.append((a[index], b[index]))
        elif a != b:
            return False
    return True


def _ordinary(tree, call):
    call.tick()
    if tree[0] == 'pred':
        return ['pred', tree[1], []]
    if tree[0] == 'not':
        return ['not', _ordinary(tree[1], call)]
    return ['imp', _ordinary(tree[1], call), _ordinary(tree[2], call)]


def _tokens(tree, call):
    result, pending = [], [tree]
    while pending:
        call.tick()
        node = pending.pop()
        if node[0] == 'pred':
            result.extend((0, node[1]))
        elif node[0] == 'not':
            result.append(1)
            pending.append(node[1])
        else:
            result.append(2)
            pending.append(node[2])
            pending.append(node[1])
    return result


def _match(pattern, tree, bindings, call):
    call.tick()
    if type(pattern) is str:
        if pattern in bindings:
            return _equal(bindings[pattern], tree, call)
        bindings[pattern] = tree
        return True
    if pattern[0] != tree[0] or len(pattern) != len(tree):
        return False
    for index in range(1, len(pattern)):
        call.tick()
        if not _match(pattern[index], tree[index], bindings, call):
            return False
    return True


def _evaluate(tree, assignment, atom_count, call):
    call.tick()
    if tree[0] == 'pred':
        return bool((assignment >> (atom_count - 1 - tree[1])) & 1)
    if tree[0] == 'not':
        return not _evaluate(tree[1], assignment, atom_count, call)
    left = _evaluate(tree[1], assignment, atom_count, call)
    right = _evaluate(tree[2], assignment, atom_count, call)
    return (not left) or right


def _inspect(formula, call):
    tree, size, depth, atom_count = _canonical(formula, call)
    values, matches = [], []
    for assignment in range(1 << atom_count):
        call.tick()
        values.append(_evaluate(tree, assignment, atom_count, call))
    for tag, pattern in enumerate(_PATTERNS):
        call.tick()
        if _match(pattern, tree, {}, call):
            matches.append(tag)
    tautology = True
    for value in values:
        call.tick()
        tautology = tautology and value
    return tree, dict(schema='two-donor-formula-inspection-v1', complete=True,
        canonical_goal=_ordinary(tree, call), tokens=_tokens(tree, call),
        expanded_nodes=size, depth=depth, atom_count=atom_count, truth_values=values,
        tautology=tautology, single_axiom_subtags=matches,
        eligible=size > 1 and tautology and not matches)


def inspect_formula(formula, *, check):
    call = _Call(check)
    try:
        call.tick()
        return _inspect(formula, call)[1]
    except BaseException:
        call.fault()
        raise


def _lex_less_equal(left, right, call):
    for index in range(min(len(left), len(right))):
        call.tick()
        if left[index] != right[index]:
            return left[index] < right[index]
    return len(left) <= len(right)


def _sort(rows, call):
    width, ordered = 1, rows
    while width < len(ordered):
        call.tick()
        output = []
        for start in range(0, len(ordered), 2 * width):
            call.tick()
            middle, end = min(start + width, len(ordered)), min(start + 2 * width, len(ordered))
            left, right = start, middle
            while left < middle or right < end:
                call.tick()
                take_left = (right == end or
                    (left < middle and _lex_less_equal(ordered[left][0], ordered[right][0], call)))
                if take_left:
                    output.append(ordered[left])
                    left += 1
                else:
                    output.append(ordered[right])
                    right += 1
        ordered, width = output, 2 * width
    return ordered


def _size_pool(size, pools, call):
    if size in pools:
        return pools[size]
    rows = []
    for body in pools[size - 1]:
        call.tick()
        rows.append(('not', body))
    for left_size in range(1, size - 1):
        call.tick()
        right_size = size - 1 - left_size
        for left in pools[left_size]:
            call.tick()
            for right in pools[right_size]:
                call.tick()
                rows.append(('imp', left, right))
    pools[size] = rows
    return rows


def _ordered_size(size, pools, call):
    candidates = []
    for tree in _size_pool(size, pools, call):
        call.tick()
        canonical, _, _, _ = _canonical(tree, call)
        if _equal(tree, canonical, call):
            candidates.append((_tokens(tree, call), tree))
    return _sort(candidates, call)


def _copy_vector(values, call):
    result = []
    for value in values:
        call.tick()
        result.append(value)
    return result


def _slot(tree, info, call):
    call.tick()
    query = dict(version=1, claim_mode=0, function_arities=[], predicate_arities=[0, 0, 0],
                 theory_profile=0, finite_axioms=[], Gamma=[], goal=_ordinary(tree, call))
    return dict(query=query, tokens=_copy_vector(info['tokens'], call),
                expanded_nodes=info['expanded_nodes'], depth=info['depth'],
                atom_count=info['atom_count'], truth_values=_copy_vector(info['truth_values'], call))


def _proper_subtree_tokens(tree, call):
    result, pending = set(), []
    if tree[0] == 'not':
        pending.append(tree[1])
    elif tree[0] == 'imp':
        pending.extend((tree[2], tree[1]))
    while pending:
        call.tick()
        node = pending.pop()
        canonical, _, _, _ = _canonical(node, call)
        result.add(tuple(_tokens(canonical, call)))
        if node[0] == 'not':
            pending.append(node[1])
        elif node[0] == 'imp':
            pending.extend((node[2], node[1]))
    return result


def _selection(call):
    pools = {1: [('pred', 0, ()), ('pred', 1, ()), ('pred', 2, ())]}
    slots, donors, prefix, forbidden = {}, [], [], set()
    for size in range(1, 12):
        call.tick()
        if size > 7 and len(donors) < 2:
            return dict(schema='two-donor-input-only-selection-v1', status='STOP_INPUT_CENSUS',
                        complete=True, slots=None, prefix=prefix, scope=_SCOPE)
        for tokens, tree in _ordered_size(size, pools, call):
            call.tick()
            _, info = _inspect(tree, call)
            if info['expanded_nodes'] == 1:
                reason = 'ATOMIC'
            elif not info['tautology']:
                reason = 'NOT_TAUTOLOGY'
            elif info['single_axiom_subtags']:
                reason = 'SINGLE_AXIOM'
            elif len(donors) < 2:
                if size <= 7 and info['depth'] <= 3:
                    number = len(donors)
                    slots['donor' + str(number)] = _slot(tree, info, call)
                    donors.append((tree, size, info['depth']))
                    reason = 'DONOR' + str(number)
                    forbidden.add(tuple(tokens))
                    forbidden.update(_proper_subtree_tokens(tree, call))
                else:
                    reason = 'DONOR_BOUNDS'
            elif (size < max(row[1] for row in donors) + 2 or
                  info['depth'] <= max(row[2] for row in donors)):
                reason = 'HOLDOUT_BOUNDS'
            elif tuple(tokens) in forbidden:
                reason = 'HOLDOUT_SUBTREE'
            else:
                slots['holdout0'] = _slot(tree, info, call)
                reason = 'HOLDOUT0'
            prefix.append(dict(rank=len(prefix), tokens=_copy_vector(tokens, call),
                expanded_nodes=info['expanded_nodes'], depth=info['depth'],
                truth_values=_copy_vector(info['truth_values'], call), tautology=info['tautology'],
                single_axiom_subtags=_copy_vector(info['single_axiom_subtags'], call),
                eligible=info['eligible'], reason=reason))
            if reason == 'HOLDOUT0':
                call.tick()
                return dict(schema='two-donor-input-only-selection-v1', status='SELECTED',
                            complete=True, slots=slots, prefix=prefix, scope=_SCOPE)
    call.tick()
    return dict(schema='two-donor-input-only-selection-v1', status='STOP_INPUT_CENSUS',
                complete=True, slots=None, prefix=prefix, scope=_SCOPE)


def select_inputs(*, check):
    call = _Call(check)
    try:
        call.tick()
        return _selection(call)
    except BaseException:
        call.fault()
        raise
