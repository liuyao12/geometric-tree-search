"""Display saved admitted records and archive raw evidence. No proof execution."""
from pathlib import Path, PurePosixPath
from html import escape
from html.parser import HTMLParser
import hashlib
import json
import zipfile

ROOT=Path(__file__).resolve().parent
R=ROOT.parent
REPO=R.parents[1]
N=REPO/'research-runs/gcts-point-proof-search-20261022'
OLD=N/'root/matched-row-publication-v1'
OUT=ROOT/'publication-v1'


def read(p):
    return json.loads(Path(p).read_bytes())


def pin(p):
    p=Path(p).resolve();body=p.read_bytes()
    return dict(path=str(p.relative_to(REPO)),bytes=len(body),sha256=hashlib.sha256(body).hexdigest())


def emit(p,obj):
    with p.open('xb')as f:
        f.write((json.dumps(obj,indent=2,allow_nan=False)+'\n').encode())


def math(s):
    return r'\('+s+r'\)'


def formula(f):
    """Display-only core AST to LaTeX; this function proves nothing."""
    tag=f[0]
    if tag=='pred' and not f[2]:
        return ('p','q','r')[f[1]] if f[1]<3 else 'P_{'+str(f[1])+'}'
    if tag=='not':
        return r'\neg '+formula(f[1])
    if tag=='imp':
        return r'\left('+formula(f[1])+r'\to '+formula(f[2])+r'\right)'
    raise ValueError('reader scope is nullary propositional core only')


def num(n):
    return math(str(n))


data_path=ROOT/'acquisition-Root-results-v1.json'
data=read(data_path)
assert data['whole_actual_reviews_accepted'] is True and len(data['cases'])==2
assert data['GCTS_or_RL_advantage_established'] is False
page=(OLD/'point-proof-search-v1.html').read_text()
cards=[]
proofs=[]
for c in data['cases']:
    title='Donor '+str(c['donor_index']+1)
    cards.append('<tr><td>'+title+'</td><td>'+escape(c['display_outcome'])+'</td><td>'+math(format(c['observer_seconds'],'.3f')+r'\,\mathrm{s}')+'</td><td>'+(num(len(c['proof_rows'])) if c['admitted'] else 'Unavailable')+'</td></tr>')
    if not c['admitted']:
        continue
    lines=[]
    for row in c['proof_rows']:
        i=row['index'];refs=row.get('validation',{}).get('references',[])
        if row['rule_tag']==1:
            label=('H','H','H','Q','Q','Q','E','E')[row['subtag']]
            ordinal=(1,2,3,1,2,3,1,2)[row['subtag']]
            rule='Logical axiom '+math(label+'_{'+str(ordinal)+'}')
            english='This is an instance of '+rule+'. Its formula witnesses are shown in the saved receipt.'
        elif row['rule_tag']==3:
            rule='Modus ponens'
            english='Use line '+num(refs[0]+1)+' as the premise and line '+num(refs[1]+1)+' as its implication; conclude the displayed formula.'
        elif row['rule_tag']==0:
            rule='Hypothesis'
            english='Read the indicated hypothesis from the exact query context.'
        else:
            rule=row['rule'];english='Apply '+escape(row['rule'])+' with the original checked witnesses.'
        ref_links=' '.join('<a href="#donor-'+str(c['donor_index'])+'-line-'+str(j+1)+'">'+num(j+1)+'</a>'for j in refs) or 'None'
        lines.append('<article class="donor-proof-tile" id="donor-'+str(c['donor_index'])+'-line-'+str(i+1)+'"><div class="donor-rule">Line '+num(i+1)+' · '+escape(rule)+'</div><div class="donor-output math">'+math(formula(row['formula']))+'</div><div class="donor-ports">Earlier reference ports: '+ref_links+'</div><p>'+english+'</p></article>')
    proofs.append('<details'+(' open'if not proofs else '')+'><summary>'+title+': '+math(formula(c['goal']))+' · '+num(len(c['proof_rows']))+' primitive lines</summary><div class="donor-proof-grid">'+''.join(lines)+'</div><p class="small">The formulas and ordered references come from the saved original checker receipt. All emitted rows are shown, including any unused rows; this view does not minimize the proof. The ordinary prover discovered the derivation. This colored translation is not evidence that GCTS found it.</p></details>')

inputs=''
if data['frozen_inputs'] is not None:
    ins=[]
    for name,slot in data['frozen_inputs']['slots'].items():
        ins.append('<tr><td>'+escape(name)+'</td><td class="math">'+math(formula(slot['query']['goal']))+'</td><td>'+num(slot['expanded_nodes'])+'</td><td>'+num(slot['depth'])+'</td></tr>')
    inputs='<details><summary>Input-only selection, frozen before search</summary><p>A fixed syntax census uses atom-renaming normalization, Boolean eligibility and exclusion of complete single-axiom instances. It supplies two distinct donor inputs and a larger structural holdout. No proof route or intermediate lemma is supplied. The holdout is unsearched here; structural separation does not establish proof-method independence.</p><div class="scroll"><table><thead><tr><th>Slot</th><th>Formula</th><th>Expanded nodes</th><th>Depth</th></tr></thead><tbody>'+''.join(ins)+'</tbody></table></div></details>'

section=r'''<section class="panel" id="receptor-acquisition"><p class="eyebrow">Current experiment · acquire training proofs before learning clusters</p><h2>Two fresh ordinary proof searches</h2><p>'''+escape(data['summary'])+r'''</p><div class="scroll"><table><thead><tr><th>Input</th><th>Whole outcome</th><th>Observer elapsed</th><th>Checked proof lines</th></tr></thead><tbody>'''+''.join(cards)+r'''</tbody></table></div><p style="margin-top:18px">'''+escape(data['interpretation'])+r'''</p>'''+inputs+r'''<div class="campaign-note"><strong>What this measures.</strong> The unchanged ordinary symbolic prover searches for each proof. The original two byte checkers validate the same complete query and certificate. A point-row translation is a consistency observation. This stage supplies no learned GCTS marking, RL policy, receptor inventory, transfer result or speedup.</div><p>Each cold job includes input selection and encoding, fresh controls, search, checking and output under the same ten resource caps. The declared total of (198) groups comprises (13) scopes: the original (192) keep their exact subjects, and (6) test the new input selector. It is not (198) direct tests of one searcher. Timed jobs run serially with the other task tools idle.</p><p><a href="point-proof-receptor-acquisition-data-v1.json">Saved results</a> · <a href="point-proof-receptor-acquisition-evidence-v1.zip">Complete evidence</a> · <a href="point-proof-receptor-acquisition-manifest-v1.json">Manifest</a></p></section>'''
if proofs:
    section+=r'''<section class="panel" id="donor-reader"><h2>Read the acquired proof rows</h2><p>Translation only: the row direction and reference ports have fixed roles. Teal identifies the inference, purple its output formula and amber its distant reference markings. Click a reference to inspect that earlier proof line. These are parametric symbolic proof rows, not a fixed finite adjacency-only Wang palette.</p>'''+''.join(proofs)+'</section>'
start,end=page.index('<header>'),page.index('</header>')+len('</header>')
header=r'''<header><p class="eyebrow">22 October 2026 · automatic proof-search research</p><h1>From discovered proofs to reusable clusters</h1><p class="lead">'''+escape(data['summary'])+r'''</p><p class="notice"><strong>The research question remains open.</strong> We have not established a learned GCTS or RL advantage over conventional proof search.</p><nav><a href="#receptor-acquisition">Current experiment</a>'''+('<a href="#donor-reader">Read new proofs</a>'if proofs else '')+r'''<a href="#matched-csp">Earlier CSP comparison</a><a href="#parallel">Parallel agents</a><a href="#next">Next work</a></nav></header>'''
page=page[:start]+header+section+page[end:]
page=page.replace('<title>Six-statement proof-search results · GCTS research</title>','<title>Training proofs and receptor families · GCTS research</title>')
css='''.donor-proof-grid{display:grid;gap:16px;margin:20px 0}.donor-proof-tile{border:1px solid var(--rule);border-radius:7px;overflow:hidden;scroll-margin-top:18px}.donor-rule{background:#e0f2ec;border-left:6px solid var(--teal);padding:9px 15px;font-weight:700}.donor-output{background:#f1eafa;border-left:6px solid var(--purple);padding:15px;font-size:1.05rem}.donor-ports{background:#fff2df;border-left:6px solid var(--amber);padding:9px 15px;font-size:.9rem}.donor-proof-tile p{padding:12px 16px;margin:0;font-size:.92rem}details+details{margin-top:18px}'''
page=page.replace('</style>',css+'</style>')
start,end=page.index('<section class="panel" id="parallel">'),page.index('<section class="panel" id="next">')
parallel=r'''<section class="panel" id="parallel"><h2>Several agents, independent roles</h2><div class="grid"><article class="card"><h3>Implementation</h3><p>One agent wrote the acquisition worker around the unchanged ordinary prover. The cluster design preserves shared steps and distinct equal-formula occurrences.</p></article><article class="card"><h3>Independent tests</h3><p>A second agent froze selector expectations before reading the selector implementation, wrote an independent census check, and reviewed the complete worker.</p></article><article class="card"><h3>Critical review</h3><p>A third agent reviewed the selector, cluster interfaces, exact whole experiment and saved terminal evidence. Root integrates, runs the bounded jobs and publishes.</p></article></div><p style="margin-top:18px">Agents develop algorithms and checking machinery; they do not supply target proofs. Research and review can run in parallel. Timed experiments run serially so that concurrent task tools do not distort their cost measurements.</p></section>'''
page=page[:start]+parallel+page[end:]
old_next=read(OLD/'point-proof-matched-row-data-v1.json')['next_step']
assert escape(old_next)in page
page=page.replace(escape(old_next),escape(data['next_step']))


class Check(HTMLParser):
    def __init__(self):
        super().__init__();self.ids=[];self.links=[]
    def handle_starttag(self,tag,attrs):
        a=dict(attrs)
        if 'id'in a:self.ids.append(a['id'])
        if tag=='a':self.links.append(a.get('href',''))


check=Check();check.feed(page)
assert len(check.ids)==len(set(check.ids))
assert all(link[1:]in check.ids for link in check.links if link.startswith('#'))
assert '\\n<section'not in page and '\x0c'not in page
OUT.mkdir(exist_ok=False)
with (OUT/'point-proof-search-v1.html').open('x')as f:f.write(page)
emit(OUT/'point-proof-receptor-acquisition-data-v1.json',data)
files={}
external={}


def add_ref(ref):
    p=Path(ref['path']);p=p if p.is_absolute()else REPO/p
    raw=p.read_bytes()
    assert len(raw)==ref['bytes']and hashlib.sha256(raw).hexdigest()==ref['sha256']
    if p.is_relative_to(REPO):files[str(p.relative_to(REPO))]=pin(p)
    else:external[str(p)]=ref


old_manifest=read(OLD/'point-proof-matched-row-manifest-v1.json')
for ref in old_manifest['members']:add_ref(ref)
for ref in old_manifest['external_runtime']:external[ref['path']]=ref
for p in sorted(R.rglob('*')):
    if p.is_file()and not p.is_symlink()and not p.is_relative_to(OUT)and 'live-acquisition-bodies-v1'not in p.parts and p.suffix!='.png':
        add_ref(pin(p))
for name in ('two-donor-input-selector-handoff-v1.json','two-donor-selector-independent-controls-handoff-v1.json','two-donor-receptor-DAG-declarations-handoff-v1.json'):
    p=N/'diagnostics-L'/name;add_ref(pin(p))
    for ref in read(p)['files']:add_ref(ref)
for p in (N/'implementation-B/prospective-propositional-receptor-cluster-experiment-v3.json',N/'review-C/typed-propositional-acquisition-and-receptor-design-assessment-v1.json',OLD/'point-proof-search-v1.html',OLD/'point-proof-matched-row-data-v1.json',OLD/'point-proof-matched-row-manifest-v1.json'):
    add_ref(pin(p))
manifest=dict(schema='GCTS-receptor-acquisition-manifest-v1',members=[files[k]for k in sorted(files)],external_runtime=list(external.values()),raw_member_count=len(files),raw_member_bytes=sum(x['bytes']for x in files.values()),public_page=pin(OUT/'point-proof-search-v1.html'),public_status=pin(OUT/'point-proof-receptor-acquisition-data-v1.json'),scientific_imports_calls=0,scope='Preserves earlier evidence and adds the complete current two-donor preparation/actual/review records. Partial bodies, if any, opaque archived bytes only. No research replay.')
emit(OUT/'point-proof-receptor-acquisition-manifest-v1.json',manifest)
with zipfile.ZipFile(OUT/'point-proof-receptor-acquisition-evidence-v1.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
    bodies=[(name,(REPO/name).read_bytes())for name in sorted(files)]
    bodies += [('MANIFEST.json',(OUT/'point-proof-receptor-acquisition-manifest-v1.json').read_bytes()),('PUBLIC-RESULT.json',(OUT/'point-proof-receptor-acquisition-data-v1.json').read_bytes()),('README.txt',(data['summary']+'\n'+data['interpretation']+'\nDisplay and archive only; no scientific replay.\n').encode())]
    assert len({name for name,_ in bodies})==len(bodies)
    for name,raw in bodies:
        assert not PurePosixPath(name).is_absolute()and '..'not in PurePosixPath(name).parts
        item=zipfile.ZipInfo(name,(2026,10,22,0,0,0));item.compress_type=zipfile.ZIP_DEFLATED;z.writestr(item,raw)
with zipfile.ZipFile(OUT/'point-proof-receptor-acquisition-evidence-v1.zip')as z:
    assert z.testzip()is None and len(z.namelist())==len(files)+3
    for name in files:assert z.read(name)==(REPO/name).read_bytes()
print(json.dumps(dict(public_files=[pin(p)for p in sorted(OUT.iterdir())],raw_members=len(files),scientific_imports_calls=0),indent=2))
