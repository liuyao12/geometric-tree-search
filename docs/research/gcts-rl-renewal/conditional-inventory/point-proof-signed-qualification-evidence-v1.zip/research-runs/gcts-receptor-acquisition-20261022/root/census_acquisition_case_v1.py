"""Raw complete terminal file census. Partial bodies stay opaque."""
from pathlib import Path
import hashlib
import json
import stat
import sys

ROOT=Path(__file__).resolve().parent
assert len(sys.argv)==2 and sys.argv[1] in ('0','1')
index=int(sys.argv[1])
case='receptor-two-donor-acquisition-v1-donor-'+str(index)
base=ROOT.parent/'actual'/case
rows=[]
for folder in (base,Path(str(base)+'.observer')):
    assert folder.is_dir() and not folder.is_symlink()
    for path in sorted(folder.rglob('*')):
        info=path.lstat()
        assert not stat.S_ISLNK(info.st_mode)
        if stat.S_ISREG(info.st_mode):
            raw=path.read_bytes()
            rows.append(dict(path=str(path.resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),
                partial_opaque='.partial'in path.name))
out=ROOT/f'acquisition-donor-{index}-terminal-raw-census-v1.json'
with out.open('xb')as f:
    f.write((json.dumps(dict(schema='Root-receptor-acquisition-terminal-census-v1',case_id=case,
        files=rows,file_count=len(rows),physical_bytes=sum(r['bytes']for r in rows),
        partial_count=sum(r['partial_opaque']for r in rows),
        scope='Raw byte custody only, no scientific helper/validator call or prefix authority.'),indent=2)+'\n').encode())
raw=out.read_bytes()
print(json.dumps(dict(path=str(out),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())))
