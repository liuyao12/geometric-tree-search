"""Metadata/display packaging only; never imports the scientific implementation."""
from pathlib import Path
import datetime
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
STUDY = ROOT.parent
OLD = ROOT / 'publication-v2'
OUT = ROOT / 'publication-reconstruction-v1'


def pin(path):
    body = path.read_bytes()
    return dict(path=str(path.relative_to(REPO)), bytes=len(body),
                sha256=hashlib.sha256(body).hexdigest())


def emit(path, value):
    with path.open('xb') as stream:
        stream.write((json.dumps(value, indent=2) + '\n').encode())


relative_members = [
    'root/nonwrapper-two-donor-input-selector-API-DESIGN-v1.json',
    'root/nonwrapper-selector-public-literal-bindings-v1.json',
    'root/nonwrapper-selector-constrained-enumeration-argument-v1.json',
    'root/nonwrapper-selector-constrained-enumeration-argument-v2.json',
    'root/nonwrapper-selector-Root-Source-authorship-acceptance-v1.json',
    'root/nonwrapper-selector-Source-handoff-v1.json',
    'root/nonwrapper-selector-Root-component-Source-acceptance-v1.json',
    'root/nonwrapper_two_donor_input_selector_v1.py',
    'root/signed-propositional-strict-ABI-addendum-v1.json',
    'root/signed-propositional-strict-ABI-addendum-v2.json',
    'root/signed-propositional-strict-ABI-addendum-v3.json',
    'root/signed-propositional-Root-Source-authorship-acceptance-v1.json',
    'root/signed-subformula-Root-scoped-design-adoption-v1.json',
    'root/analytic-baseline-contribution-boundary-v1.json',
    'implementation-B/signed-subformula-propositional-producer-API-DESIGN-v1.json',
    'implementation-B/signed-primitive-reconstruction-contract-v1.json',
    'implementation-B/signed-primitive-reconstruction-contract-v2.json',
    'implementation-B/signed-primitive-reconstruction-handoff-v1.json',
    'implementation-B/signed-primitive-reconstruction-handoff-v2.json',
    'implementation-B/signed-primitive-reconstruction-contract-delta-v2.json',
    'implementation-B/signed-primitive-reconstruction-v1-to-v2.patch',
    'implementation-B/signed-primitive-reconstruction-v2-to-v1.inverse.patch',
    'diagnostics-L/prospective-nonwrapper-two-donor-input-design-v1.json',
    'diagnostics-L/nonwrapper-selector-independent-literal-expectations-v1.json',
    'diagnostics-L/nonwrapper-selector-independent-expectations-handoff-v1.json',
    'diagnostics-L/signed-subformula-independent-symbolic-expectations-v1.json',
    'diagnostics-L/signed-subformula-independent-symbolic-expectations-handoff-v1.json',
    'diagnostics-L/signed-subformula-independent-strict-ABI-binding-v1.json',
    'diagnostics-L/signed-subformula-independent-strict-ABI-binding-v2.json',
    'diagnostics-L/signed-subformula-independent-expectations-handoff-v2.json',
    'review-C/typed-signed-subformula-producer-and-nonwrapper-input-design-assessment-v1.json',
    'review-C/typed-signed-subformula-primitive-reconstruction-requirements-v1.json',
    'review-C/typed-nonwrapper-two-donor-selector-public-API-design-review-v1.json',
    'review-C/typed-nonwrapper-two-donor-selector-complete-Source-enumeration-review-v1.json',
    'review-C/typed-signed-propositional-strict-ABI-design-review-v3.json',
    'review-C/typed-signed-primitive-reconstruction-contract-manual-review-v1.json',
    'review-C/typed-signed-primitive-reconstruction-contract-manual-successor-review-v2.json',
    'diagnostics-L/nonwrapper_selector_independent_controls_v1.py',
    'diagnostics-L/nonwrapper-selector-independent-controls-handoff-v1.json',
    'diagnostics-L/nonwrapper-selector-independent-controls-API-v1.json',
    'diagnostics-L/nonwrapper-selector-independent-controls-manual-v1.json',
    'diagnostics-L/nonwrapper-selector-independent-controls-static-v1.json',
    'diagnostics-L/nonwrapper-selector-independent-controls-closure-v1.json',
]
for name in relative_members:
    path = STUDY / name
    assert path.is_file() and not path.is_symlink()

contract = json.loads((STUDY / relative_members[16]).read_bytes())
programs = contract['schematic_programs']
assert len(programs) == 7 and sum(len(p['rows']) for p in programs) == 82
OUT.mkdir(exist_ok=False)
status = dict(
    schema='GCTS-reconstruction-progress-source-snapshot-v1',
    snapshot_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    status='SOURCE_AND_MANUAL_CONSTRUCTION_PROGRESS_NO_NEW_ACTUAL',
    new_scientific_actuals=0, new_target_proofs=0,
    compiler_programs=7, schematic_instruction_rows=82,
    manual_generic_construction_reviewed=True,
    compiler_source='IMPLEMENTATION_IN_PROGRESS_NOT_INCLUDED_IN_THIS_SNAPSHOT',
    producer_source='IMPLEMENTATION_IN_PROGRESS_NOT_INCLUDED_IN_THIS_SNAPSHOT',
    selector_source=pin(STUDY / 'root/nonwrapper_two_donor_input_selector_v1.py'),
    selector_review=pin(STUDY / 'review-C/typed-nonwrapper-two-donor-selector-complete-Source-enumeration-review-v1.json'),
    selector_executed=False, all_required_executable_banks_frozen=False,
    selector_bank_source=pin(STUDY / 'diagnostics-L/nonwrapper_selector_independent_controls_v1.py'),
    selector_bank_executed=False,
    next_actual_authorized=False, runtime_qualification=False,
    current_contract=pin(STUDY / 'implementation-B/signed-primitive-reconstruction-contract-v2.json'),
    current_public_ABI=pin(STUDY / 'root/signed-propositional-strict-ABI-addendum-v3.json'),
    artifacts=[pin(STUDY / name) for name in relative_members],
    scope='Generic compiler programs are hand-specified baseline infrastructure, not learned families or target proofs. All prior actuals are unchanged; closed acquisition remains STOP. No GCTS/RL advantage, runtime fit or fixed finite Wang palette is established.')
data_path = OUT / 'point-proof-reconstruction-plan-data-v1.json'
emit(data_path, status)

bs = chr(92)
def math(source):
    return bs + '(' + source.replace('@', bs) + bs + ')'

rows = [
    ('Explosion', 'A@to(@neg A@to C)', 'A contradiction permits any conclusion.'),
    ('Double negation', '@neg@neg A@to A', 'Eliminate a double negation.'),
    ('Negative implication, left', '@neg(A@to B)@to A', 'A false implication has a true antecedent.'),
    ('Negative implication, right', '@neg(A@to B)@to@neg B', 'A false implication has a false consequent.'),
    ('Classical branch join', '(A@to B)@to((@neg A@to C)@to((B@to C)@to C))', 'Combine the two closed implication branches.'),
    ('Classical root elimination', '(@neg A@to A)@to A', 'Discharge the search root’s negated conclusion.'),
]
row_html = ''.join('<tr><td>' + name + '</td><td class="math">' + math(formula) +
                   '</td><td>' + meaning + '</td></tr>' for name, formula, meaning in rows)
panel = '''<section class="panel" id="compiler-progress">
<p class="eyebrow">New source milestone · not a new proof-search result</p>
<h2>Building a baseline that handles negation</h2>
<p>The missing primitive reconstruction rules now have a finite manual construction: identity plus six generic compiler programs, with NUMPROGRAMS programs and NUMROWS explicit schematic instructions. Independent review checked their axiom witnesses, premise order, assumption discharge and acyclic dependencies. This is a reviewed construction plan; no new instance has been executed.</p>
<div class="baseline-flow" role="group" aria-label="Intended proof-search pipeline; new runtime validation is pending">
<article><span class="pill">Input</span><h3>Frozen formula selection</h3><p>A varied input population replaces the earlier wrapper split. The new selector source is written and manually reviewed; it has not run.</p></article>
<article><span class="pill">Search</span><h3>Signed subformulas</h3><p>An ordinary deterministic search decomposes the input formulas. Every required branch must close, or a complete countermodel must be checked.</p></article>
<article><span class="pill">Compile</span><h3>Primitive proof rows</h3><p>Expand generic programs and discharge exact assumption occurrences into AXIOMS and modus ponens. Compiler implementation is underway.</p></article>
<article><span class="pill">Check</span><h3>Original validators</h3><p>Both existing byte checkers must validate the same complete query and certificate before any proof is admitted.</p></article>
</div>
<div class="campaign-note"><strong>Where GCTS must earn its contribution.</strong> These manually specified compiler programs belong to the common baseline. They do not count as a learned lemma inventory. Later, automatically acquired proof clusters must actually occur in a new checked proof, and fixed or uniform cluster use must be compared with learned selection. Saving compilation work alone would not establish better proof search.</div>
<details style="margin-top:18px"><summary>The six generic obligations and their meanings</summary><p style="margin-top:12px">The letters denote arbitrary formulas. These are compiler obligations, not selected research theorems or automatically discovered proofs. Every invocation must expand into the original primitive calculus.</p><div class="scroll"><table><thead><tr><th>Program</th><th>Formula</th><th>Meaning</th></tr></thead><tbody>ROWS</tbody></table></div></details>
<details style="margin-top:18px"><summary>A more varied input population, still unselected</summary><div class="grid" style="margin-top:14px"><article class="card"><h3>First donor stratum</h3><p>Two repeated atoms with negation, at most DONORZERO expanded nodes.</p></article><article class="card"><h3>Second donor stratum</h3><p>Three repeated atoms using implication, at most DONORONE expanded nodes.</p></article><article class="card"><h3>Holdout stratum</h3><p>Three repeated atoms with negation, at most HOLDOUT expanded nodes.</p></article></div><p style="margin-top:14px">Every stratum excludes whole identities and adjacent negations. Eligibility rejects proper tautological subtrees and direct logical axiom instances; the holdout also excludes whole-donor substitution instances. Selection must retain the complete ordered prefix through the first eligible member. A true empty census stops the study. These syntactic distinctions do not prove independent proof methods or affordable search.</p></details>
<p style="margin-top:18px">An independent selector test bank has also been written. Its reference walk checks every constrained input before the reported winner, with literal, copying and selected fault tests. No new test has run; complete runtime coverage is not claimed.</p>
<p><strong>Next:</strong> finish the compiler, ordinary searcher and remaining independently written test bank; review the complete sources and whole experiment before running. The earlier cohort stays closed. No new theorem, runtime qualification, resource-fit result or GCTS/RL advantage is claimed here.</p>
<p><a href="point-proof-reconstruction-plan-data-v1.json">Source milestone</a> · <a href="point-proof-reconstruction-plan-evidence-v1.zip">Complete source and review snapshot</a> · <a href="point-proof-reconstruction-plan-manifest-v1.json">Manifest</a></p>
</section>'''
panel = panel.replace('NUMPROGRAMS', math('7')).replace('NUMROWS', math('82')).replace('ROWS', row_html)
panel = panel.replace('AXIOMS', math('H_1,H_2,H_3')).replace('DONORZERO', math('11')).replace('DONORONE', math('13')).replace('HOLDOUT', math('15'))
page = (OLD / 'point-proof-search-v1.html').read_text()
anchor = '<section class="panel" id="receptor-acquisition">'
assert page.count(anchor) == 1 and 'id="compiler-progress"' not in page
page = page.replace(anchor, panel + anchor, 1)
page = page.replace('<nav><a href="#receptor-acquisition">', '<nav><a href="#compiler-progress">Compiler progress</a><a href="#receptor-acquisition">', 1)
css = '.baseline-flow{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin:20px 0}.baseline-flow article{padding:15px;border:1px solid var(--rule);border-top:4px solid var(--teal);background:#f5f8f7}.baseline-flow h3{margin-top:12px}.baseline-flow p{font-size:.91rem;margin:0}@media(max-width:850px){.baseline-flow{grid-template-columns:repeat(2,minmax(0,1fr))}}@media(max-width:520px){.baseline-flow{grid-template-columns:1fr}}'
page = page.replace('</style>', css + '</style>', 1)
page_path = OUT / 'point-proof-search-v1.html'
page_path.write_text(page)
old_manifest = json.loads((OLD / 'point-proof-receptor-acquisition-manifest-v2.json').read_bytes())
with zipfile.ZipFile(OLD / 'point-proof-receptor-acquisition-evidence-v2.zip') as archive:
    bodies = {row['path']: archive.read(row['path']) for row in old_manifest['members']}
references = {row['path']: row for row in old_manifest['members']}
extras = [STUDY / name for name in relative_members] + [Path(__file__),
    OLD / 'point-proof-search-v1.html', OLD / 'point-proof-receptor-acquisition-manifest-v2.json']
for path in extras:
    ref = pin(path)
    body = path.read_bytes()
    if ref['path'] in references:
        assert references[ref['path']] == ref and bodies[ref['path']] == body
    references[ref['path']], bodies[ref['path']] = ref, body
manifest = dict(schema='GCTS-reconstruction-progress-source-manifest-v1',
    members=[references[name] for name in sorted(references)],
    raw_member_count=len(references), raw_member_bytes=sum(ref['bytes'] for ref in references.values()),
    external_runtime=old_manifest['external_runtime'], public_page=pin(page_path),
    public_status=pin(data_path), scientific_imports_calls=0,
    scope='Display/source milestone only. All predecessor raw bodies preserved exactly; no scientific implementation imported or executed. New selector and independent selector-bank Source are bundled, unexecuted. New compiler/producer/signed-bank implementation is not bundled or runtime-qualified by this snapshot.')
manifest_path = OUT / 'point-proof-reconstruction-plan-manifest-v1.json'
emit(manifest_path, manifest)
with zipfile.ZipFile(OUT / 'point-proof-reconstruction-plan-evidence-v1.zip', 'x',
                     compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name in sorted(bodies):
        body, ref = bodies[name], references[name]
        assert len(body) == ref['bytes'] and hashlib.sha256(body).hexdigest() == ref['sha256']
        archive.writestr(name, body)
    archive.writestr('MANIFEST.json', manifest_path.read_bytes())
    archive.writestr('PUBLIC-RESULT.json', data_path.read_bytes())
    archive.writestr('README.txt', 'Source and manual reconstruction milestone only. No new scientific actual or target proof. Original evidence remains byte-identical.\n')
with zipfile.ZipFile(OUT / 'point-proof-reconstruction-plan-evidence-v1.zip') as archive:
    assert archive.testzip() is None and len(archive.namelist()) == len(references) + 3
    for name, body in bodies.items():
        assert archive.read(name) == body
print(json.dumps(dict(files=[pin(p) for p in sorted(OUT.iterdir())],
                      raw_members=len(references)), indent=2))
