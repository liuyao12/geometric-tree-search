"""Display-only notation successor, preserving every frozen scientific body."""
from pathlib import Path
import json,hashlib,zipfile
ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[2]
OLD=ROOT/'publication-v1'
OUT=ROOT/'publication-v2'
def pin(p):
 b=p.read_bytes();return dict(path=str(p.relative_to(REPO)),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def emit(p,j):
 with p.open('xb')as f:f.write((json.dumps(j,indent=2)+'\n').encode())
s=(OLD/'point-proof-search-v1.html').read_text()
start=s.index('<section class="panel" id="receptor-acquisition">');end=s.index('<section class="panel" id="donor-reader">')
section=s[start:end];original=section;bs=chr(92)
for n,count in [('198',2),('13',1),('192',1),('6',1)]:
 assert section.count('('+n+')')==count
 section=section.replace('('+n+')',bs+'('+n+bs+')')
s=s[:start]+section+s[end:]
s=s.replace('point-proof-receptor-acquisition-evidence-v1.zip','point-proof-receptor-acquisition-evidence-v2.zip').replace('point-proof-receptor-acquisition-manifest-v1.json','point-proof-receptor-acquisition-manifest-v2.json')
OUT.mkdir(exist_ok=False)
(OUT/'point-proof-search-v1.html').write_text(s)
old_manifest=json.loads((OLD/'point-proof-receptor-acquisition-manifest-v1.json').read_bytes())
with zipfile.ZipFile(OLD/'point-proof-receptor-acquisition-evidence-v1.zip')as z:
 bodies={ref['path']:z.read(ref['path'])for ref in old_manifest['members']}
refs={ref['path']:ref for ref in old_manifest['members']}
for p in [Path(__file__),OLD/'point-proof-search-v1.html',OLD/'point-proof-receptor-acquisition-data-v1.json',OLD/'point-proof-receptor-acquisition-manifest-v1.json',ROOT.parent/'review-C/typed-two-donor-acquisition-four-asset-publication-readiness-review-v1.json',ROOT/'acquisition-Root-publication-readiness-acceptance-v1.json']:
 ref=pin(p);refs[ref['path']]=ref;bodies[ref['path']]=p.read_bytes()
manifest=dict(schema='GCTS-receptor-acquisition-notation-successor-manifest-v2',members=[refs[k]for k in sorted(refs)],external_runtime=old_manifest['external_runtime'],raw_member_count=len(refs),raw_member_bytes=sum(x['bytes']for x in refs.values()),public_page=pin(OUT/'point-proof-search-v1.html'),public_status=pin(OLD/'point-proof-receptor-acquisition-data-v1.json'),scientific_imports_calls=0,scope='Notation-only successor: five counts regain LaTeX delimiters and links point to this successor. All original981 raw scientific/evidence bodies remain byte-identical. Data/actuals immutable; no scientific replay.')
mp=OUT/'point-proof-receptor-acquisition-manifest-v2.json';emit(mp,manifest)
with zipfile.ZipFile(OUT/'point-proof-receptor-acquisition-evidence-v2.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for name in sorted(bodies):
  b=bodies[name];ref=refs[name];assert len(b)==ref['bytes']and hashlib.sha256(b).hexdigest()==ref['sha256'];z.writestr(name,b)
 z.writestr('MANIFEST.json',mp.read_bytes());z.writestr('PUBLIC-RESULT.json',(OLD/'point-proof-receptor-acquisition-data-v1.json').read_bytes());z.writestr('README.txt','Notation-only successor. Five counts now use LaTeX. All scientific bytes preserved; no research execution.\n')
with zipfile.ZipFile(OUT/'point-proof-receptor-acquisition-evidence-v2.zip')as z:
 assert z.testzip()is None and len(z.namelist())==len(refs)+3
 for name,b in bodies.items():assert z.read(name)==b
print(json.dumps(dict(files=[pin(p)for p in sorted(OUT.iterdir())],raw_members=len(refs)),indent=2))
