"""Complete finite signed propositional DFS; ordinary common infrastructure.

Source authored only. No target IDs, old proofs, supplied trees or library enter
search. Analytic closure requires generic primitive reconstruction and external
same-byte validation before any Root admission. Genuine budget faults escape.
"""

import hashlib
from types import MappingProxyType

VERSION = "FPC-H1-SIGNED-PROPOSITIONAL-PRODUCER-v1"
EMITTER_VERSION = "FPC-H1-SIGNED-PRIMITIVE-EMITTERS-v1"
_OWNER = object()
_QUERY_FIELDS = ("version", "claim_mode", "function_arities", "predicate_arities",
                 "theory_profile", "finite_axioms", "Gamma", "goal")
DIAGNOSTIC_FIELDS = (
    "schema", "snapshot_available", "phase", "phase_in_progress",
    "completed_atomic_steps", "states_started", "closed_branches", "split_nodes",
    "active_stack_depth", "active_entry_count", "pending_child_count",
    "retained_closed_rule_nodes", "primitive_rows_emitted",
    "compiler_emitter_instances", "observed_through_atomic_step")
_COUNT_FIELDS = (
    "completed_atomic_steps", "states_started", "closed_branches", "split_nodes",
    "active_stack_depth", "active_entry_count", "pending_child_count",
    "retained_closed_rule_nodes", "primitive_rows_emitted", "compiler_emitter_instances")
_DIAGNOSTIC_SCHEMA = "FPC-H1-signed-propositional-diagnostics-v1"

class PropositionalInputError(ValueError):
    """Public constructor is unowned; only this call's private mint is a refusal."""


def is_owned_error(error):
    return (type(error) is PropositionalInputError and
            getattr(error, "_module_owner", None) is _OWNER and
            getattr(error, "_call_owner", None) is not None)


class _Call:
    def __init__(self, check):
        self.check, self.owner, self.first = check, object(), None

    def tick(self):
        if self.first is not None:
            raise self.first
        try:
            self.check()
        except BaseException as error:
            self.first = error
            raise

    def fault(self):
        if self.first is not None:
            raise self.first

    def fail(self, code, path, message):
        self.fault()
        error = PropositionalInputError(message)
        error._module_owner, error._call_owner = _OWNER, self.owner
        error.detail = {"code": code, "path": list(path), "message": message}
        raise error

    def need(self, condition, path, message, code="INVALID_CALL"):
        self.tick()
        if not condition:
            self.fail(code, path, message)


def _nat(x):
    return type(x) is int and x >= 0


def _keys(value, names, c, path, code="INVALID_CALL"):
    c.need(type(value) in (dict, MappingProxyType), path, "ordinary mapping required", code)
    c.need(len(value) == len(names), path, "exact keys required", code)
    for key in value:
        c.need(type(key) is str and key in names, path, "unknown key", code)


def _snapshot(value, c, path=()):
    """Fresh immutable JSON snapshot; aliases copy, ancestor cycles refuse."""
    pending, values, active = [("read", value, path)], [], set()
    while pending:
        c.tick()
        mode, node, at = pending.pop()
        if mode == "map":
            source_id, keys = node
            n = len(keys)
            kids = values[-n:] if n else []
            if n:
                del values[-n:]
            copied = {}
            for key, child in zip(keys, kids):
                c.tick()
                copied[key] = child
            values.append(MappingProxyType(copied))
            active.remove(source_id)
        elif mode == "list":
            source_id, n = node
            kids = values[-n:] if n else []
            if n:
                del values[-n:]
            values.append(tuple(kids))
            active.remove(source_id)
        elif type(node) is dict:
            c.need(id(node) not in active, at, "cyclic mapping")
            active.add(id(node))
            keys = []
            for key in node:
                c.need(type(key) is str, at, "string keys required")
                keys.append(key)
            pending.append(("map", (id(node), tuple(keys)), at))
            for key in reversed(keys):
                c.tick()
                pending.append(("read", node[key], at + (key,)))
        elif type(node) is list:
            c.need(id(node) not in active, at, "cyclic list")
            active.add(id(node))
            pending.append(("list", (id(node), len(node)), at))
            for j in range(len(node) - 1, -1, -1):
                c.tick()
                pending.append(("read", node[j], at + (j,)))
        elif node is None or type(node) in (str, int, bool):
            values.append(node)
        else:
            c.fail("INVALID_CALL", at, "JSON scalar/plain container required")
    return values[0]


def _plain(value, c):
    pending, values = [(False, value)], []
    while pending:
        c.tick()
        built, node = pending.pop()
        if built:
            kind, keys, n = node
            kids = values[-n:] if n else []
            if n:
                del values[-n:]
            if kind == "map":
                out = {}
                for key, child in zip(keys, kids):
                    c.tick()
                    out[key] = child
                values.append(out)
            else:
                values.append(list(kids))
        elif type(node) is MappingProxyType:
            keys = tuple(node)
            pending.append((True, ("map", keys, len(keys))))
            for key in reversed(keys):
                c.tick()
                pending.append((False, node[key]))
        elif type(node) is tuple:
            pending.append((True, ("list", (), len(node))))
            for child in reversed(node):
                c.tick()
                pending.append((False, child))
        else:
            values.append(node)
    return values[0]


def _scope(q, c):
    if q["theory_profile"] != 0:
        return "UNSUPPORTED_THEORY_PROFILE", ("theory_profile",)
    if q["function_arities"]:
        return "NONEMPTY_FUNCTION_SIGNATURE", ("function_arities",)
    for j, arity in enumerate(q["predicate_arities"]):
        c.tick()
        if arity != 0:
            return "NONNULLARY_PREDICATE", ("predicate_arities", j)
    sources = []
    for field in ("finite_axioms", "Gamma"):
        for j, f in enumerate(q[field]):
            c.tick()
            sources.append((f, (field, j)))
    sources.append((q["goal"], ("goal",)))
    for f, path in sources:
        pending = [(f, path)]
        while pending:
            c.tick()
            node, at = pending.pop()
            tag = node[0]
            if tag not in ("pred", "not", "imp"):
                return "UNSUPPORTED_FORMULA_CONSTRUCTOR", at + (0,)
            if tag == "not":
                pending.append((node[1], at + (1,)))
            elif tag == "imp":
                pending.append((node[2], at + (2,)))
                pending.append((node[1], at + (1,)))
    return None



def _invalidate_diagnostics(sink):
    # Before _Call and before any genuine callback; bounded fifteen-field work.
    if (type(sink) is dict and len(sink) == 15 and
            all(type(key) is str for key in sink) and
            type(sink.get("snapshot_available")) is bool):
        sink["snapshot_available"] = False


class _Observation:
    def __init__(self, sink, c):
        self.sink, self.c = sink, c
        self.counts = {}
        for key in _COUNT_FIELDS:
            c.tick()
            self.counts[key] = 0
        self.phase, self.in_progress = None, False
        if sink is not None:
            c.need(type(sink) is dict, ("diagnostics",), "plain diagnostic dict")
            _keys(sink, DIAGNOSTIC_FIELDS, c, ("diagnostics",), "INVALID_CALL")
            c.need(type(sink["schema"]) is str and sink["schema"] == _DIAGNOSTIC_SCHEMA,
                   ("diagnostics",), "diagnostic schema")
            for key in ("snapshot_available", "phase_in_progress"):
                c.need(type(sink[key]) is bool, ("diagnostics", key), "diagnostic boolean")
            c.need(sink["phase"] is None or (type(sink["phase"]) is str and
                   sink["phase"] in ("INTAKE", "SEARCH", "RECONSTRUCT", "FINAL")),
                   ("diagnostics", "phase"), "diagnostic phase")
            for key in _COUNT_FIELDS + ("observed_through_atomic_step",):
                c.need(sink[key] is None or _nat(sink[key]), ("diagnostics", key), "diagnostic scalar")

    def publish(self):
        if self.sink is None:
            return
        self.sink["snapshot_available"] = False
        self.sink["schema"] = _DIAGNOSTIC_SCHEMA
        self.sink["phase"] = self.phase
        self.sink["phase_in_progress"] = self.in_progress
        for key in _COUNT_FIELDS:
            self.sink[key] = self.counts[key]
        self.sink["observed_through_atomic_step"] = self.counts["completed_atomic_steps"]
        self.sink["snapshot_available"] = True

    def enter(self, phase):
        self.c.tick()
        self.phase, self.in_progress = phase, True
        self.publish()

    def commit(self):
        self.c.tick()
        self.counts["completed_atomic_steps"] += 1
        self.in_progress = False
        self.publish()

    def clear_live(self):
        # Only normal completion uses this; failure cleanup never publishes.
        for key in ("active_stack_depth", "active_entry_count", "pending_child_count", "retained_closed_rule_nodes"):
            self.counts[key] = 0

    def final(self):
        # Called only after successful bounded cleanup and final genuine callback.
        self.phase, self.in_progress = "FINAL", False
        self.publish()


def _configuration(value, c):
    c.need(type(value) is dict, ("configuration",), "plain configuration")
    _keys(value, ("schema", "principal_order", "split_order", "memoization", "trace_limit"),
          c, ("configuration",), "INVALID_CALL")
    frozen = _snapshot(value, c, ("configuration",))
    expected = (("schema", "FPC-H1-signed-propositional-configuration-v1"),
                ("principal_order", "FIRST_DECOMPOSABLE_OCCURRENCE"),
                ("split_order", "NEGATIVE_ANTECEDENT_FIRST"), ("memoization", "NONE"))
    for key, literal in expected:
        c.need(type(frozen[key]) is str and frozen[key] == literal, ("configuration", key), "configuration literal")
    c.need(type(frozen["trace_limit"]) is int and frozen["trace_limit"] == 0,
           ("configuration", "trace_limit"), "production trace_limit0")
    return frozen


def _query(raw, modules, c):
    c.need(type(raw) is bytes, (), "immutable query bytes required")
    c.need(type(modules) is dict, ("modules",), "plain modules")
    _keys(modules, ("checker", "builders", "compiler"), c, ("modules",), "INVALID_CALL")
    checker = modules["checker"]
    try:
        decoded = checker.decode_query(raw, check=c.tick)
    except BaseException as error:
        c.fault()
        if type(error) is checker.InvalidWitness and checker.is_owned_error(error):
            c.fail("MALFORMED_QUERY", (), "original query decoder refusal")
        raise
    c.fault()
    c.need(type(decoded) is dict and decoded.get("EOF") == len(raw), (), "decoder EOF")
    fields = {}
    for key in _QUERY_FIELDS:
        c.tick()
        fields[key] = decoded[key]
    frozen = _snapshot(fields, c)
    digest = hashlib.sha256()
    for start in range(0, len(raw), 65536):
        c.tick()
        digest.update(raw[start:start + 65536])
    identity = _plain(frozen, c)
    identity.update(query_hex=raw.hex(), bytes=len(raw), sha256=digest.hexdigest())
    c.tick()
    return frozen, identity, _scope(frozen, c)


def _equal(left, right, c):
    pending = [(left, right)]
    while pending:
        c.tick()
        a, b = pending.pop()
        if type(a) is not type(b):
            return False
        if type(a) in (list, tuple):
            if len(a) != len(b):
                return False
            for j in range(len(a) - 1, -1, -1):
                c.tick()
                pending.append((a[j], b[j]))
        elif type(a) is dict:
            if len(a) != len(b):
                return False
            for key in a:
                c.tick()
                if key not in b:
                    return False
                pending.append((a[key], b[key]))
        elif a != b:
            return False
    return True


def _initial(q, c):
    entries = []
    for field, source in (("Gamma", "GAMMA"), ("finite_axioms", "AXIOM")):
        for i, formula in enumerate(q[field]):
            c.tick()
            entries.append(("T", (source, i, ()), formula))
    entries.append(("F", ("GOAL", 0, ()), q["goal"]))
    return tuple(entries)


def _closure(entries, c):
    for i in range(len(entries)):
        for j in range(i + 1, len(entries)):
            c.tick()
            if entries[i][0] != entries[j][0] and _equal(entries[i][2], entries[j][2], c):
                return i, j
    return None


def _replace(entries, principal, added, c):
    out = []
    for j, entry in enumerate(entries):
        c.tick()
        if j == principal:
            for child in added:
                c.tick()
                out.append(child)
        else:
            out.append(entry)
    return tuple(out)


def _children(entries, principal, c):
    sign, origin, formula = entries[principal]
    source, index, path = origin
    tag = formula[0]
    if tag == "not":
        child = ("F" if sign == "T" else "T", (source, index, path + (0,)), formula[1])
        return ("T_NOT" if sign == "T" else "F_NOT"), (_replace(entries, principal, (child,), c),)
    left = ("F" if sign == "T" else "T", (source, index, path + (0,)), formula[1])
    right = ("T" if sign == "T" else "F", (source, index, path + (1,)), formula[2])
    if sign == "F":
        return "F_IMP", (_replace(entries, principal, (left, right), c),)
    return "T_IMP", (_replace(entries, principal, (left,), c), _replace(entries, principal, (right,), c))


def _entry_records(entries, c):
    out = []
    for sign, origin, formula in entries:
        c.tick()
        source, index, path = origin
        copied_path = []
        for step in path:
            c.tick()
            copied_path.append(step)
        out.append({"sign": sign, "origin": {"source": source, "index": index, "path": copied_path},
                    "formula": _plain(formula, c)})
    return out


def _evaluate(formula, values, c):
    pending, stack = [(False, formula)], []
    while pending:
        c.tick()
        ready, node = pending.pop()
        if ready:
            if node == "not":
                stack.append(not stack.pop())
            else:
                right, left = stack.pop(), stack.pop()
                stack.append((not left) or right)
        elif node[0] == "pred":
            stack.append(values[node[1]])
        else:
            pending.append((True, node[0]))
            for child in reversed(node[1:]):
                c.tick()
                pending.append((False, child))
    return stack[0]


def _countermodel(entries, q, query_hex, c):
    values = []
    for _ in q["predicate_arities"]:
        c.tick()
        values.append(False)
    for sign, _, formula in entries:
        c.need(formula[0] == "pred", (), "saturated atom")
        values[formula[1]] = sign == "T"
    for field in ("finite_axioms", "Gamma"):
        for formula in q[field]:
            c.need(_evaluate(formula, values, c) is True, (), "countermodel source truth")
    c.need(_evaluate(q["goal"], values, c) is False, (), "countermodel goal false")
    return {"predicate_values": values, "saturated": True, "source_query_hex": query_hex}


def _push(stack, entries, obs):
    stack.append({"entries": entries, "phase": "ENTER", "rule": None, "principal": None,
                  "children": (), "next": 0, "roots": []})
    obs.counts["states_started"] += 1
    obs.counts["active_stack_depth"] += 1
    obs.counts["active_entry_count"] += len(entries)


def _finish_node(stack, nodes, node, obs):
    number = len(nodes)
    nodes.append(node)
    frame = stack.pop()
    obs.counts["active_stack_depth"] -= 1
    obs.counts["active_entry_count"] -= len(frame["entries"])
    obs.counts["retained_closed_rule_nodes"] += 1
    if stack:
        stack[-1]["roots"].append(number)


def _search(q, query_hex, stack, nodes, obs, c):
    obs.enter("SEARCH")
    _push(stack, _initial(q, c), obs)
    obs.commit()
    while stack:
        obs.enter("SEARCH")
        frame = stack[-1]
        entries = frame["entries"]
        if frame["phase"] == "ENTER":
            pair = _closure(entries, c)
            if pair is not None:
                node = {"id": len(nodes), "entries": _entry_records(entries, c), "rule": "CLOSE",
                        "principal": None, "premises": [], "close_pair": list(pair)}
                obs.counts["closed_branches"] += 1
                _finish_node(stack, nodes, node, obs)
                obs.commit()
                continue
            principal = None
            for j, entry in enumerate(entries):
                c.tick()
                if entry[2][0] != "pred":
                    principal = j
                    break
            if principal is None:
                leaf = _countermodel(entries, q, query_hex, c)
                obs.commit()
                return leaf
            rule, children = _children(entries, principal, c)
            frame.update(phase="WAIT", rule=rule, principal=principal, children=children)
            obs.counts["pending_child_count"] += len(children)
            if rule == "T_IMP":
                obs.counts["split_nodes"] += 1
            obs.commit()
        elif frame["next"] < len(frame["children"]):
            child = frame["children"][frame["next"]]
            frame["next"] += 1
            obs.counts["pending_child_count"] -= 1
            _push(stack, child, obs)
            obs.commit()
        else:
            copied_refs = []
            for ref in frame["roots"]:
                c.tick()
                copied_refs.append(ref)
            node = {"id": len(nodes), "entries": _entry_records(entries, c), "rule": frame["rule"],
                    "principal": frame["principal"], "premises": copied_refs, "close_pair": None}
            _finish_node(stack, nodes, node, obs)
            obs.commit()
    return None


def _compiler(query_bytes, tree, modules, identity, c):
    compiler = modules["compiler"]
    result = compiler.compile_closed_signed_tree(query_bytes, tree,
        modules={"checker": modules["checker"], "builders": modules["builders"]}, check=c.tick)
    c.fault()
    c.need(type(result) is dict, (), "compiler carrier")
    _keys(result, ("candidate_certificate_bytes", "receipt"), c, (), "INVALID_CALL")
    candidate, receipt = result["candidate_certificate_bytes"], result["receipt"]
    c.need(type(candidate) is bytes and bool(candidate), (), "compiler candidate bytes")
    c.need(type(receipt) is dict, (), "compiler receipt")
    _keys(receipt, ("schema", "accepted", "query", "primitive_rows", "emitter_instances",
                   "emitter_version", "tree_nodes", "validation"), c, (), "INVALID_CALL")
    c.need(receipt["schema"] == "FPC-H1-signed-compiler-receipt-v2" and receipt["accepted"] is False
           and receipt["validation"] == "NOT_RUN_EXTERNAL_DUAL_GATE_REQUIRED", (), "compiler receipt scope")
    for field in ("primitive_rows", "emitter_instances", "tree_nodes"):
        c.need(_nat(receipt[field]), ("receipt", field), "compiler count")
    c.need(receipt["primitive_rows"] > 0 and receipt["tree_nodes"] == len(tree["nodes"])
           and receipt["emitter_version"] == EMITTER_VERSION, (), "compiler version/count association")
    c.need(_equal(receipt["query"], identity, c), (), "compiler full original query")
    return candidate, receipt["primitive_rows"], receipt["emitter_instances"]


def search_propositional(query_bytes, *, configuration, modules, check, diagnostics=None):
    _invalidate_diagnostics(diagnostics)
    c, obs = _Call(check), None
    stack, nodes = [], []
    tree = q = config = None
    result = None
    normal_cleanup_done = False
    try:
        if not callable(check):
            c.fail("INVALID_CALL", (), "check must be callable")
        obs = _Observation(diagnostics, c)
        obs.enter("INTAKE")
        config = _configuration(configuration, c)
        q, identity, unsupported = _query(query_bytes, modules, c)
        obs.commit()
        candidate, leaf, primitive_rows = None, None, None
        if unsupported is not None:
            status, closed = "UNSUPPORTED_PROPOSITIONAL_SCOPE", None
            scope = {"supported": False, "reason": unsupported[0], "path": list(unsupported[1])}
            reconstruction = {"complete": False, "reason": "UNSUPPORTED_SCOPE", "primitive_rows": None,
                              "emitter_version": None}
        else:
            scope = {"supported": True, "reason": None, "path": []}
            leaf = _search(q, identity["query_hex"], stack, nodes, obs, c)
            if leaf is not None:
                status, closed = "COUNTERMODEL_FOUND", False
                reconstruction = {"complete": False, "reason": "OPEN_ANALYTIC_LEAF", "primitive_rows": None,
                                  "emitter_version": None}
            else:
                obs.enter("RECONSTRUCT")
                tree = {"schema": "FPC-H1-closed-signed-tree-v1", "query_hex": identity["query_hex"],
                        "nodes": nodes, "root": len(nodes) - 1}
                candidate, primitive_rows, emitter_instances = _compiler(query_bytes, tree, modules, identity, c)
                obs.counts["primitive_rows_emitted"] = primitive_rows
                obs.counts["compiler_emitter_instances"] = emitter_instances
                obs.commit()
                status, closed = "CANDIDATE_FOUND", True
                reconstruction = {"complete": True, "reason": None, "primitive_rows": primitive_rows,
                                  "emitter_version": EMITTER_VERSION}
        # Normal owned cleanup first. No caller tree/formula/reference is retained.
        stack.clear()
        nodes.clear()
        tree = q = None
        obs.clear_live()
        counts = {}
        for key in _COUNT_FIELDS:
            c.tick()
            counts[key] = obs.counts[key]
        result = {"status": status, "candidate_certificate_bytes": candidate, "receipt": {
            "schema": "FPC-H1-signed-propositional-receipt-v1", "version": 1,
            "status": status, "accepted": False, "query": identity,
            "configuration": _plain(config, c), "scope": scope,
            "analytic": {"closed": closed, "open_leaf": leaf, "counters": counts},
            "reconstruction": reconstruction,
            "candidate_validation": "NOT_RUN_EXTERNAL_DUAL_GATE_REQUIRED"}}
        config = None
        normal_cleanup_done = True
        c.tick()
        obs.final()
        return result
    except BaseException:
        c.fault()
        raise
    finally:
        # No postfault publication, callback, scientific getter or reconstruction.
        if not normal_cleanup_done:
            stack.clear()
            nodes.clear()
            tree = q = config = None
